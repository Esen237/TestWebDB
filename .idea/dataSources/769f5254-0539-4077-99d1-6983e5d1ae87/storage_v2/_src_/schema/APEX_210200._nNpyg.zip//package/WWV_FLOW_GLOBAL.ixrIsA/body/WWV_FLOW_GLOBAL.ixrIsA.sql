create package body wwv_flow_global as
g_cloud_value constant boolean := false;

function g_cloud return boolean
is
begin
    return g_cloud_value;
end g_cloud;
end wwv_flow_global;
/

