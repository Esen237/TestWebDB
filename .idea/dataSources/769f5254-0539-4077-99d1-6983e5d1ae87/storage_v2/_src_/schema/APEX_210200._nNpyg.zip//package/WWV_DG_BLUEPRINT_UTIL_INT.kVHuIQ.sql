create PACKAGE wwv_dg_blueprint_util_int authid definer as
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2021. All Rights Reserved.
--
-- This package contains the implementation for data generation in APEX.
--
--
-- Since: 21.1
--
--    MODIFIED   (MM/DD/YYYY)
--     jstraub    01/11/2021 - Created from Anton Nielsen, Neelesh Shah
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Misc Globals
--------------------------------------------------------------------------------
LF                              constant varchar2(1) := unistr('\000a');
c_comma                         constant varchar2 (1)  := ',';

$IF sys.dbms_db_version.version < 18 $THEN

$ELSE


--==================================================================================================================
-- This procedures adds table information to wwv_dg_builtin_table based upon user tables prefixed with wwv_dg_builtin.
-- Adds columns from these tables to wwv_dg_builtin_tab_col.
--
--
-- Example:
--
--
--   begin
--       wwv_dg_blueprint_util_int.add_builtin_data_sources;
--   end;
--==================================================================================================================
procedure add_builtin_data_sources;



--==================================================================================================================
-- This function will generate create scripts for blueprint tables.
--
-- Returns:
-- Returns a SQL statement as a CLOB.
--
-- Parameters:
-- * p_blueprint      Name of the blueprint
--   p_schema         Schema of the table, null if not required
--   p_table_name     Table name if generating ddl for a specific table
--   p_include_drop   Drop tables, by default not generated
--   p_run            Run the statements as they are generated - can be  'DROP_AND_CREATE', 'DROP' or 'CREATE'
--
--
-- Example:
--
--   declare
--       l_sql clob;
--   begin
--       l_sql := wwv_dg_blueprint_util_int.generate_ddl_from_blueprint(
--                    p_blueprint    => 'hr schema',
--                    p_include_drop => 'N');
--   end;
--==================================================================================================================
function generate_ddl_from_blueprint
    (p_blueprint    in varchar2,
     p_schema       in varchar2 default null,
     p_table_name   in varchar2 default null,
     p_include_drop in varchar2 default 'N',
     p_run          in varchar2 default null
    ) return clob;



--       generate the ddl to create the schema and drop the schema
--==================================================================================================================
-- This procedure will add to the wwv_dg_blueprint_sample table
--
-- Parameters:
-- * p_sample_name          Name of the blueprint
--   p_description          Schema of the table, null if not required
--   p_expected_runtime     Table name if generating ddl for a specific table
--   p_blueprint_json       Drop tables, by default not generated
--
--
-- Example:
--
--
--    begin
--        wwv_dg_blueprint_util_int.add_sample(p_sample_name  => q'[sample table data source]',
--                                          p_description      => q'[Example of database table data source]',
--                                          p_expected_runtime => 2,
--                                          p_blueprint_json   =>
--            q'[
--              {
--                "blueprint_format_version" : "0.1",
--                "blueprint" : "sample table data source",
--                "description" : "Example of database table data source",
--                "lang" : "en",
--                "data_sources" :
--                [
--                  {
--                    "name" : "departments",
--                    "data_source_type" : "TABLE",
--                    "table" : "dept",
--                    "preserve_name" : "N",
--                    "sql_query" : null,
--                    "where_clause" : null,
--                    "order_by_column" : null
--                  }
--                ],
--                "tables" :
--                [
--                  {
--                    "sequence" : 1,
--                    "table_name" : "sample_table",
--                    "preserve_name" : "N",
--                    "display_name" : "Database Table Data Source Example",
--                    "singular_name" : "Database Table Data Source Example",
--                    "plural_name" : "Database Table Data Source Example",
--                    "pk_col" : null,
--                    "rows" : 5,
--                    "columns" :
--                    [
--                      {
--                        "sequence" : 4,
--                        "column_name" : "dept_deptno",
--                        "preserve_name" : "N",
--                        "display_name" : "deptno column from dept table",
--                        "multi_value" : "N",
--                        "mv_format" : null,
--                        "mv_delimiter" : null,
--                        "mv_min_entries" : null,
--                        "mv_max_entries" : null,
--                        "mv_partition_by" : null,
--                        "lang" : "en",
--                        "data_source_type" : "DATA_SOURCE",
--                        "data_source" : "departments.deptno",
--                        "min_numeric_value" : 1,
--                        "max_numeric_value" : 10,
--                        "numeric_precision" : 0,
--                        "min_date_value" : null,
--                        "max_date_value" : null,
--                        "date_precision" : null,
--                        "format_mask" : null,
--                        "sequence_start_with" : 1,
--                        "sequence_increment" : 1,
--                        "depends_on" : null,
--                        "formula" : null,
--                        "formula_lang" : null,
--                        "custom_attributes" : null,
--                        "percent_blank" : 0,
--                        "max_length" : null
--                      },
--                      {
--                        "sequence" : 2,
--                        "column_name" : "dept_dname",
--                        "preserve_name" : "N",
--                        "display_name" : "dname column from dept table",
--                        "multi_value" : "N",
--                        "mv_format" : null,
--                        "mv_delimiter" : null,
--                        "mv_min_entries" : null,
--                        "mv_max_entries" : null,
--                        "mv_partition_by" : null,
--                        "lang" : "en",
--                        "data_source_type" : "DATA_SOURCE",
--                        "data_source" : "departments.dname",
--                        "min_numeric_value" : 1,
--                        "max_numeric_value" : 10,
--                        "numeric_precision" : 0,
--                        "min_date_value" : null,
--                        "max_date_value" : null,
--                        "date_precision" : null,
--                        "format_mask" : null,
--                        "sequence_start_with" : 1,
--                        "sequence_increment" : 1,
--                        "depends_on" : null,
--                        "formula" : null,
--                        "formula_lang" : null,
--                        "custom_attributes" : null,
--                        "percent_blank" : 0,
--                        "max_length" : null
--                      }
--                    ]
--                  }
--                ]
--              }
--
--            ]'
--            );
--    end;
--==================================================================================================================
procedure add_sample
    (p_sample_name      in varchar2,
     p_description      in varchar2,
     p_expected_runtime in number default null,
     p_blueprint_json   in clob
    );



--==================================================================================================================
-- This procedure will, given p_blueprint_id, create a sample in the wwv_dg_blueprint_sample table.
--
-- Parameters:
-- * p_blueprint_id         Identifies blueprint
--
--
-- Example:
--
--
--   begin
--       wwv_dg_blueprint_util_int.make_blueprint_sample(
--                    p_blueprint_id           => 245047891814095125902038531392778837662
--                    );
--   end;
--==================================================================================================================
procedure make_blueprint_sample
    (p_blueprint_id in number
    );



--==================================================================================================================
-- This procedure will, retrieve additional builtin data (only used for wwv_dg_BUILTIN% AND wwv_dg_HELPER% tables).
-- Calls a web service at p_rest_endpoint and inserts response data by calling the persist_builtin_data procedure into p_table_name.
--
-- Parameters:
-- * p_table_name           Name of the target table
-- * p_rest_endpoint        End point of the service returning json data
--   p_rows                 Number of rows to get, min 1, defaults to 500000
--   p_mode                 APPEND to OR REPLACE data in target table, defaults to APPEND
--   p_lang                 Language of the data retrieved, defaults to en
--   p_domain               Used only when p_table_name is wwv_dg_HELPER_DATA to retrieve data for the specified domain
--
--
-- Example:
--
--
--   begin
--      wwv_dg_blueprint_util_int.get_builtin_data(
--          p_table_name => 'wwv_dg_BUILTIN_LOCATIONS',
--          p_rest_endpoint => 'https://insumlabs.com/webapps/odg/builtindata/location',
--          p_mode => 'REPLACE'
--      );
--   end;
--==================================================================================================================
procedure get_builtin_data
    (p_table_name    in varchar2,
     p_rest_endpoint in varchar2,
     p_rows          in pls_integer default 500000,
     p_mode          in varchar2 default 'APPEND',
     p_lang          in varchar2 default 'en',
     p_domain        in varchar2 default null
    );



--==================================================================================================================
-- This procedure will, insert response data from REST call to end point or passed in JSON into p_table_name.
--
-- Parameters:
-- * p_sample_name          Name of the target table
-- * p_json_data            End point of the service returning json data
--   p_source               Source set to JSON if this procedure is called with a JSON file, if called from get_builtin_data, it will be REST.
--                          Defaults to JSON
--   p_mode                 APPEND to OR REPLACE data in target table, defaults to APPEND
--   p_lang                 Language of the data retrieved, defaults to en
--   p_domain               Used only when p_table_name is wwv_dg_HELPER_DATA to REPLACE data in specified DOMAIN. Pass ALL to replace data in all domains.
--
--
-- Example:
--
--
--    begin
--        wwv_dg_blueprint_util_int.persist_builtin_data
--            (p_table_name       => 'wwv_dg_BUILTIN_LOCATIONS',
--            p_source           => 'JSON',
--            p_mode             => 'APPEND',
--            p_lang             => 'en',
--            p_json_data        => '
--        {
--          "items": [
--            {
--              "latitude": 42.10081,
--              "longitude": -73.46335,
--              "city": "South Egremont",
--              "state_id": "MA",
--              "state_name": "Massachusetts",
--              "zcta": "TRUE",
--              "population": 513,
--              "county_fips": 25003,
--              "county_name": "Berkshire",
--              "military": "FALSE",
--              "timezone": "America/New_York",
--              "zip_vc": "01258",
--              "lang": "en"
--            },
--            {
--              "latitude": 42.0755,
--              "longitude": -73.26273,
--              "city": "Southfield",
--              "state_id": "MA",
--              "state_name": "Massachusetts",
--              "zcta": "TRUE",
--              "population": 486,
--              "county_fips": 25003,
--              "county_name": "Berkshire",
--              "military": "FALSE",
--              "timezone": "America/New_York",
--              "zip_vc": "01259",
--              "lang": "en"
--            },
--            {
--              "latitude": 18.1675462,
--              "longitude": -66.7265305,
--              "city": "Adjuntas",
--              "state_id": "PR",
--              "state_name": "Puerto Rico",
--              "zcta": "TRUE",
--              "population": 18488,
--              "county_fips": 72001,
--              "county_name": "Adjuntas",
--              "military": "FALSE",
--              "timezone": "America/Puerto_Rico",
--              "zip_vc": "00601",
--              "lang": "en"
--            },
--            {
--              "latitude": 18.37111,
--              "longitude": -67.18451,
--              "city": "Aguada",
--              "state_id": "PR",
--              "state_name": "Puerto Rico",
--              "zcta": "TRUE",
--              "population": 39098,
--              "county_fips": 72003,
--              "county_name": "Aguada",
--              "military": "FALSE",
--              "timezone": "America/Puerto_Rico",
--              "zip_vc": "00602",
--              "lang": "en"
--            },
--            {
--              "latitude": 18.4618437,
--              "longitude": -67.1208146,
--              "city": "Aguadilla",
--              "state_id": "PR",
--              "state_name": "Puerto Rico",
--              "zcta": "TRUE",
--              "population": 44508,
--              "county_fips": 72005,
--              "county_name": "Aguadilla",
--              "military": "FALSE",
--              "timezone": "America/Puerto_Rico",
--              "zip_vc": "00603",
--              "lang": "en"
--            }
--          ]
--        }
--        '
--        );
--   end;
--==================================================================================================================
procedure persist_builtin_data
    (p_table_name     in varchar2,
     p_json_data      in clob,
     p_source         in varchar2 default 'JSON',
     p_mode           in varchar2 default 'APPEND',
     p_lang           in varchar2 default 'en',
     p_domain         in varchar2 default null
    ) ;



--==================================================================================================================
-- This procedure will, test a blueprint using FAST INSERT and generate counts reports for dataset and duplicates.
-- Delete and import the blueprint if needed, drop and recreate all the tables in the blueprint,generate and insert data and report record count from tables.
--
-- Parameters:
-- * p_blueprint          Blueprint name if in wwv_dg_BLUEPRINT table or json must be passed to import with this name.
--   p_clob               Blueprint JSON, if it is not present already in the wwv_dg_BLUEPRINT table.
--   p_replace            forcing user to pass TRUE if json is passed, replace TRUE will overwrite if blueprint exists otherwise it will error if blueprint exists, not needed if clob is null.
--   p_drop_and_create    Indicates if the tables associated with the blueprint should be dropped and replaced.
--   p_expected_runtime   Amount of time in seconds that this should complete within to pass. NULL indicates no time restriction.
-- * p_result             Returns a PASS or a FAIL
-- * p_output             Returns a verbose list of steps that were performed
--
--
-- Example:
--
--   declare
--       l_result    varchar2(255);
--       l_output    clob;
--   begin
--       wwv_dg_blueprint_util_int.test_blueprint(
--                    p_blueprint      => 'alumni mailing lists 20210114 19:51:07',
--                    p_result         => l_result,
--                    p_output         => l_output);
--   end;
--==================================================================================================================
procedure test_blueprint
    (p_blueprint        in         varchar2,
     p_clob             in         clob    default null,
     p_replace          in         boolean default FALSE,
     p_drop_and_create  in         boolean default FALSE,
     p_expected_runtime in         number  default null,
     p_result           out nocopy varchar2,
     p_output           out nocopy clob
    );



--==================================================================================================================
-- This procedure will, test a specific sample blueprint to see if the sample creates a valid blueprint and if the blueprint runs and gives expected results
--
-- Parameters:
-- * p_sample_id          Id from wwv_dg_blueprint_sample table
--   p_replace            If a blueprint exists with the name = lower(substr(l_sample.sample_name ||' '|| to_char(sysdate, 'yyyymmdd hh24:mi:ss'), 1, 200)), replace it
--   p_drop_and_create    Indicate if the tables associated with the blueprint should be dropped and replaced
--   p_cleanup            Drop the blueprint that were created by the sample
--   p_cleanup_tables     Drop the tables that were created by the sample
--   p_runtime_scaling    Multiplier for expected_runtime. E.g. on a slow server pass 2, on a fast server pass .5
-- * p_result             Returns a PASS or a FAIL
-- * p_output             Returns a verbose list of steps that were performed
--
--
-- Example:
--
--   declare
--       l_output  clob;
--       l_result  varchar2(255);
--   begin
--       wwv_dg_blueprint_util_int.test_sample(
--           p_sample_id      => 243224857046844111948941702492793651232,
--           p_result         => l_result,
--           p_output         => l_output);
--   end;
--==================================================================================================================
procedure test_sample
    (p_sample_id       in         number,
     p_replace         in         boolean default FALSE,
     p_drop_and_create in         boolean default FALSE,
     p_cleanup         in         boolean default FALSE,
     p_cleanup_tables  in         boolean default FALSE,
     p_runtime_scaling in         number default 1,
     p_result          out nocopy varchar2,
     p_output          out nocopy clob
    );



--==================================================================================================================
-- This procedure will, call test_sample for all samples
--
-- Parameters:
--   p_runtime_scaling    Multiplier for expected_runtime. E.g. on a slow server pass 2, on a fast server pass .5
--   p_replace            If a blueprint exists with the name = lower(substr(l_sample.sample_name ||' '|| to_char(sysdate, 'yyyymmdd hh24:mi:ss'), 1, 200)), replace it.
--   p_drop_and_create    Indicates if the tables associated with the blueprint should be dropped and replaced.
--   p_cleanup            Drop the blueprint that were created by the sample
--   p_cleanup_tables     Drop the tables that were created by the sample
-- * x_pass_fail          PASS if all samples pass, FAIL if one or more samples fail
-- * x_details            List of all samples and if the passed or failed. For details information, call test_sample for a specific blueprint sample.
--
--
-- Example:
--
--   declare
--       l_pass_fail   varchar2(255);
--       l_details     clob;
--   begin
--       wwv_dg_blueprint_util_int.test_all_samples(
--           x_pass_fail          => l_pass_fail,
--           x_details            => l_details);
--   end;
--==================================================================================================================
procedure test_all_samples
    (p_runtime_scaling in         number  default 1,
     p_replace         in         boolean default FALSE,
     p_drop_and_create in         boolean default TRUE,
     p_cleanup         in         boolean default TRUE,
     p_cleanup_tables  in         boolean default TRUE,
     x_pass_fail       out nocopy varchar2,
     x_details         out nocopy clob
    );



--==================================================================================================================
-- This function will, fetch a setting name value for the passed in name, returns null if not found.
--
-- Returns:
-- Returns a setting value as a varchar2.
--
-- Parameters:
-- * p_setting_name           Any setting name
--
--
-- Example:
--
--   declare
--       l_result varchar2(255);
--   begin
--       l_result := wwv_dg_blueprint_util_int.get_instance_setting(
--          p_setting_name => 'use powerset if available');
--   end;
--==================================================================================================================
function get_instance_setting
    (p_setting_name in varchar2
    ) return varchar2;




--==================================================================================================================
-- This utility function replaces listagg selects in order to process very large comma separated data.
--
-- Parameters:
-- * p_select_type
-- * p_blueprint_id       Identifies blueprint
-- * p_table_name         Name of table associated with blueprint
--   p_format
--   p_delimiter
--
--
-- Example:
--
--   declare
--      l_return clob;
--   begin
--       l_return := wwv_dg_blueprint_util_int.wwv_dg_listagg(
--                      p_select_type  => 'COL LIST FOR DDL',
--                      p_blueprint_id => 245831952590108797212700726123395346563,
--                      p_table_name   => 'dept');
--   end;
--==================================================================================================================
function wwv_dg_listagg
    (p_select_type  in varchar2,
     p_blueprint_id in number,
     p_table_name   in varchar2,
     p_format       in varchar2 default null,
     p_delimiter    in varchar2 default c_comma
    ) return clob;


--==================================================================================================================
--
--
-- This procedure will use dbms_assert.qualified_sql_name to cross check all table and col names that are part of
-- the blueprint specified in p_blueprint.
--     It also returns a message with the invalid names
--     p_a_ok flag indicates success or failure, p_message is just for information
--
-- Parameters:
-- * p_blueprint      Name of a blueprint
-- * p_a_ok           Indicates success or failure
-- * p_message        For additional information, returned as JSON
--
--
-- Example:
--
--   declare
--      l_output varchar2(255);
--      l_message clob;
--   begin
--       wwv_dg_blueprint_util_int.wwv_dg_assert(
--                    p_blueprint  => 'hr schema',
--                    p_a_ok       => l_output,
--                    p_message    => l_message);
--   end;
--==================================================================================================================
--==================================================================================================================
procedure wwv_dg_assert
    (p_blueprint in         varchar2,
     p_a_ok      out nocopy varchar2,
     p_message   out nocopy clob
    );

$END

end wwv_dg_blueprint_util_int;
/

