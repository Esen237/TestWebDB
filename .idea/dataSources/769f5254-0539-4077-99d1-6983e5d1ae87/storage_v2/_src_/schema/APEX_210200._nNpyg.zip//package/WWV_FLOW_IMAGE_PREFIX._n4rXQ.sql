create package wwv_flow_image_prefix is
function g_image_prefix return varchar2;
end;
/

