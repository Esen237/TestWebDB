create package wwv_flow_data_upload

as
empty_vc_arr               wwv_flow_global.vc_arr2;

function de_quote (
    p_str    in varchar2,
    p_enc_by in varchar2 )
    return varchar2;

function get_line (
    p_data          in clob,
    p_line          out varchar2,
    p_line_num      in out pls_integer,
    p_nxtlineoffset in out pls_integer )
    return boolean;

function get_column (
    p_line          in     varchar2,
    p_delim         in     varchar2,
    p_column           out varchar2,
    p_col_elmt      in out pls_integer,
    p_nxtcoloffset  in out pls_integer )
    return boolean;
--==============================================================================
-- While loading data, read line by line and column by column
-- and store the parsed data into temp collection
--==============================================================================

procedure create_collections_from_data (
    p_first_row_is_col_name   in varchar2 default 'N',
	p_data_type				  in varchar2 default 'PASTE',
	p_file_name 			  in varchar2 default null,
	p_use_app_date_format     in varchar2 default 'N',
    --
    p_separator               in varchar2 default chr(9),
    p_enclosed_by             in varchar2 default null,
    --
    p_currency                in varchar2 default '$',
    p_group_separator         in varchar2 default '.',
    p_decimal_char            in varchar2 default ',',
    p_charset                 in varchar2 default null,
    p_file_upload_table       in varchar2 default 'WWV_FLOW_FILES');

--==============================================================================
-- Read the table columns or data load column names LOV and render as select list
--==============================================================================

procedure display_table_mapping (
    p_load_table_id     in number,
	p_flow_id			in number);

--==============================================================================
-- Save the User mapping of columns from spreasheet to table column names
--==============================================================================

procedure save_column_mapping (
    p_cnames                in wwv_flow_global.vc_arr2,
    p_data_format           in wwv_flow_global.vc_arr2 default empty_vc_arr);

--==============================================================================
-- Load the data from the user spreadsheet or file into temp collection
--==============================================================================

procedure create_load_collection;

--==============================================================================
-- In order to do validation, check data to be updated/inserted/etc
-- Make Data manipulation like data lookup, data transformation, etc,
-- All those operations are done and stored into session collections
--==============================================================================

procedure create_verify_collection (
    p_id    in number);

--==============================================================================
-- After data validation,
-- This procedure will load data into underlying table
--==============================================================================

procedure load_data (
    p_id                    in number,
    p_session_id            in number,
    p_insert_count          out varchar2,
    p_update_count          out varchar2,
    p_error_count           out varchar2,
    p_review_count          out varchar2);

--==============================================================================
-- Checks the owner name and if same as parsing schema
-- Returns the #OWNER#
-- otherwise return the schema name
--==============================================================================

function get_owner_name(
    p_owner_name            in varchar2,
    p_flow_id               in number)
    return varchar2;



procedure fix_pre42(p_flow_id          in number );
end wwv_flow_data_upload;
/

