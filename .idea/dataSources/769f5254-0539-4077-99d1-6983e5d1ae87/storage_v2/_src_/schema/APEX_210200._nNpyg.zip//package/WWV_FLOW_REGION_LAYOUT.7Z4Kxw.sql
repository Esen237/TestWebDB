create package wwv_flow_region_layout
as

g_first_process boolean := true;

procedure set_lock_status (
    p_flow in number,
    p_page in number);

procedure page_template_substitution (
    p_flow          in number,
    p_template_id   in number);

procedure region_template_substitution (
    p_flow          in number,
    p_template_id   in number);

end wwv_flow_region_layout;
/

