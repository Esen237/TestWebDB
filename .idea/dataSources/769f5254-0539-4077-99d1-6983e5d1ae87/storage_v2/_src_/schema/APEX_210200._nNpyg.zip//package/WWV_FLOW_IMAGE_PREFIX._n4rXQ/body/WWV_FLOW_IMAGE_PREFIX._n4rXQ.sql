create package body wwv_flow_image_prefix wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
f3 ff
yhlKYN3CB4mYx9qgjUCyXf39fMIwg3ncmMusfI4yueposlR2WlQUy2No4O+gGo5QKdT7dPRg
hso/vEYEjNSCQb/6lacX5/Sh/nxKv/yunPdATu60s4E8gWodw5VlCZVdUSVRw9onMIfv54zV
xg3WQLot7t/SahaecA1AYXlai+hjZcHcq7pWgvXHBGInN7z+k8FEfwvCPBU+jO4SnlZFg/z+
NhP/FHU+13AVDOT+0clN6ywBiwaVtqXxono=
/

