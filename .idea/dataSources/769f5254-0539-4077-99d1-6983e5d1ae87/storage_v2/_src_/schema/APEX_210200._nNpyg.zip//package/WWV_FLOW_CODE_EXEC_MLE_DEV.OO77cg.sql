create package wwv_flow_code_exec_mle_dev authid definer as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020. All Rights Reserved.
--
--    NAME
--      wwv_flow_code_exec_mle_dev.sql
--
--    DESCRIPTION
--      This package is a helper package for MLE code in the Builder.
--
--      Package must be authid definer, see qkscollIsBinException.
--
--    RUNTIME DEPLOYMENT: YES
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    07/24/2020 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================

--==============================================================================
-- Global constants
--==============================================================================

--==============================================================================
-- Global variables
--==============================================================================

--==============================================================================
-- Returns all the MLE languages supported by the specified parsing schema.
--==============================================================================
function get_languages (
    p_parsing_schema in varchar2 )
    return wwv_flow_t_varchar2;

end wwv_flow_code_exec_mle_dev;
/

