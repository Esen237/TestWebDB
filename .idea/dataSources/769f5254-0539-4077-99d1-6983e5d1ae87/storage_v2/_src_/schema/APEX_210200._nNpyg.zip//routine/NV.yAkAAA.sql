create function nv wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
108 e3
Uk2iNAbY6/+NTuvHB+4xhllV3XYwgxBKAMsVfHQCWBKe0PBGe0ufwG26ZmPcXVcpff18wD+e
9WepztT+sHiUHD2AQB6yo1qLjW+ldJQBNA5u3TfIbziPwnQUqb46kQ4xxx39EsOMzSkzPp2o
ieFK0nl6VLEnXuMKAZdC2gGTzCYKzR6c2vnVMoImUoXfDFbeE1oWTcw/p1NGpv+BsgiIUzMH
2tYKVzc=
/

