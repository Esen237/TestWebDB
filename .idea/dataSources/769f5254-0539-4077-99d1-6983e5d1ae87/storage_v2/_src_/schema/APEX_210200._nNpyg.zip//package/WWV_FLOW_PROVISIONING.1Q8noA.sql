create package wwv_flow_provisioning as

------------------------------------
-- U T I L I T Y   F U N C T I O N S
--

procedure set_commit( p_commit_transactions in boolean default TRUE );

procedure create_flow_super_user (
    p_user_id in number,
    p_user_adminid in varchar2,
    p_security_group_id in number)
    ;

procedure create_cookie_based_user (
    p_provision_id in number,
    p_password     in varchar2)
    ;

function site_admin_is_restricted
    return boolean
    ;

function site_admin_is_restricted_i
    return integer
    ;

function restricted_schema(
    p_schema         in varchar2,
    p_workspace_name in varchar2)
    return boolean
    ;

function restricted_schema(
    p_schema            in varchar2,
    p_security_group_id in number)
    return boolean
    ;


function restricted_schema_i(
    p_schema         in varchar2,
    p_workspace_name in varchar2)
    return integer
    ;

function reserved_schema(
    p_schema in varchar2)
    return boolean
    ;

function reserved_schema_i(
    p_schema in varchar2)
    return integer
    ;

function validate_schema_name(
    p_schema         in varchar2,
    p_workspace_name in varchar2)
    return varchar2
    ;

function total_service_requests
    return number
    ;

function total_open_service_requests
    return number
    ;

function total_change_requests
    return number
    ;

function total_open_change_requests
    return number
    ;

function generate_schema_for_workspace (
    p_workspace_name in varchar2)
    return varchar2
    ;

-----------------------------
-- D E M O   R E Q U E S T S
--

procedure install_demo_tables(
    p_security_group_id in number,
    p_schema            in varchar2 default null)
    ;

procedure remove_demo_tables(
    p_security_group_id in varchar2,
    p_schema            in varchar2 default null)
    ;

procedure install_demo_restful_service(
    p_security_group_id in number,
    p_schema            in varchar2 default null)
    ;

----------------------------------------------
-- A U T O   P R O V I S I O N   C O M P A N Y
--
procedure auto_provision_company (
    p_company_name              in varchar2 default null,
    p_schema_name               in varchar2 default null,
    p_schema_password           in varchar2 default null,
    p_database_size             in varchar2 default 'SMALL',
    p_database_initial_size     in varchar2 default null,
    p_admin_userid              in varchar2 default null,
    p_admin_password            in varchar2 default null,
    p_admin_first_name          in varchar2 default null,
    p_admin_last_name           in varchar2 default null,
    p_admin_title               in varchar2 default null,
    p_admin_email               in varchar2 default null,
    p_project_description       in varchar2 default null,
    p_security_group_id         in varchar2 default null,
    p_install_sample_app        in varchar2 default null,
    p_install_sample_ws         in varchar2 default null,
    p_install_team_dev_files    in varchar2 default null,
    p_workspace_type            in varchar2 default null);


----------------------------
-- M A K E   R E Q U E S T S
--
procedure make_request (
    p_company_name              in varchar2 default null,
    p_admin_first_name          in varchar2 default null,
    p_admin_last_name           in varchar2 default null,
    p_admin_title               in varchar2 default null,
    p_admin_email               in varchar2 default null,
    p_admin_phone               in varchar2 default null,
    p_admin_userid              in varchar2 default null,
    p_company_address           in varchar2 default null,
    p_city                      in varchar2 default null,
    p_state                     in varchar2 default null,
    p_zip                       in varchar2 default null,
    p_country                   in varchar2 default null,
    p_usage_type                in varchar2 default null,
    p_org_name                  in varchar2 default null,
    p_company_type              in varchar2 default null,
    p_company_web_site          in varchar2 default null,
    p_number_of_employees       in varchar2 default null,
    p_company_phone             in varchar2 default null,
    p_company_fax               in varchar2 default null,
    p_oracle_partner            in varchar2 default null,
    p_how_did_you_hear_about_us in varchar2 default null,
    p_service_use_status        in varchar2 default null,
    p_database_size             in varchar2 default null,
    p_database_initial_size     in varchar2 default null,
    p_service_start_date        in varchar2 default null,
    p_service_termination_date  in varchar2 default null,
    p_schema_name               in varchar2 default null,
    p_estimated_end_users       in varchar2 default null,
    p_page_views_per_day        in varchar2 default null,
    p_project_description       in varchar2 default null,
    p_project_justification     in varchar2 default null,
    p_security_group_id         in varchar2 default null,
    p_workspace_type            in varchar2 default null,
    --
    p_question_1                in varchar2 default null,
    p_answer_1                  in varchar2 default null,
    p_question_2                in varchar2 default null,
    p_answer_2                  in varchar2 default null,
    p_question_3                in varchar2 default null,
    p_answer_3                  in varchar2 default null,
    p_question_4                in varchar2 default null,
    p_answer_4                  in varchar2 default null,
    p_question_5                in varchar2 default null,
    p_answer_5                  in varchar2 default null,
    p_question_6                in varchar2 default null,
    p_answer_6                  in varchar2 default null,
    p_question_7                in varchar2 default null,
    p_answer_7                  in varchar2 default null,
    p_question_8                in varchar2 default null,
    p_answer_8                  in varchar2 default null,
    p_question_9                in varchar2 default null,
    p_answer_9                  in varchar2 default null,
    p_question_10               in varchar2 default null,
    p_answer_10                 in varchar2 default null,
    --
    p_ip_address                in varchar2 default null
    );

-----------------------------------------
-- P R E   P R O C E S S   R E Q U E S T
--
procedure pre_process_request (
    p_id                        in number)
    ;


------------------------------------
-- P R O V I S I O N   R E Q U E S T
--
procedure provision_request (
    p_id                        in number,
    p_password                  in varchar2,
    p_admin_password            in varchar2,
    p_install_sample_app        in varchar2 default null,
    p_install_sample_ws         in varchar2 default null,
    p_install_team_dev_files    in varchar2 default null );

------------------------------------
-- A C C E P T   R E Q U E S T
--
procedure accept_request (
    p_id                        in number)
    ;


-----------------------------------------------------
-- P R O V I S I O N   A C C E P T E D  R E Q U E S T
--
procedure provision_accept_request (
    p_id                        in number,
    email_id                    in varchar2,
    p_password                  in varchar2,
    p_admin_password            in varchar2)
    ;


-------------------------------------------------
-- D E L E T E  A C C E P T E D   R E Q U E S T
--
procedure delete_accepted_request (
    p_id  in number)
    ;


------------------------------------
-- D E N Y   R E Q U E S T
--
procedure deny_request (
    p_id                        in number)
    ;

------------------------------------
-- T E R M I N A T E   S E R V I C E
--
procedure terminate_service (
    p_id                        in number)
    ;
procedure terminate_service_by_sgid (
    p_security_group_id  in number,
    p_drop_users         in varchar2 default 'N',
    p_drop_tablespaces   in varchar2 default 'N',
    p_remove_request     in varchar2 default 'N')
    ;

-------------------------------------------------
-- D E L E T E  P R O V I S I O N   R E Q U E S T
--
procedure delete_provision_request (
    p_id  in number)
    ;


----------------------------------------------------
-- M A K E   M O D I F I C A T I O N   R E Q U E S T
--
procedure make_modification_request (
    p_security_group_id     in number   default wwv_flow_security.g_security_group_id,
    p_service_name          in varchar2,
    p_service_attribute_1   in varchar2 default null,
    p_service_attribute_2   in varchar2 default null,
    p_service_attribute_3   in varchar2 default null,
    p_service_attribute_4   in varchar2 default null,
    p_service_attribute_5   in varchar2 default null,
    p_service_attribute_6   in varchar2 default null,
    p_service_attribute_7   in varchar2 default null,
    p_service_attribute_8   in varchar2 default null)
    ;

procedure reject_modification_request (
    p_request_id in number)
    ;


procedure delete_modification_request (
    p_request_id in number)
    ;

-------------------------------------
-- S C H E M A   M O D I F I C A T I O N S
--
-- p_security_group_id = identifies company
-- p_schema_name       = identifies the new schema to be created
-- p_db_size           = megabytes
--

procedure add_schema_by_request (
    p_request_id      in number,
    p_use_existing    in boolean default false)
    ;

procedure add_schema (
    p_request_id            in number,
    p_security_group_id     in number,
    p_schema_name           in varchar2,
    p_default_ts            in varchar2,
    p_temporary_ts          in varchar2,
    p_use_existing          in boolean default false)
    ;

procedure remove_schema (
    p_security_group_id     in number,
    p_schema_name           in varchar2)
    ;

procedure update_user_default_schema (
    p_security_group_id     in number,
    p_new_schema            in varchar2,
    p_old_schema            in varchar2)
    ;

procedure remove_schema_by_request (
    p_request_id               in number)
    ;

procedure provision_storage_by_request (
    p_request_id      in number)
    ;

function reset_password (
    p_company                  in varchar2,
    p_username                 in varchar2,
    p_size                     in number default 6)
    return varchar2
    ;

--
-- For a given security_group_id, return a delimited list of workspace schemas
--
function get_schemas_by_sgid (
    p_security_group_id in number,
    p_separator         in varchar2 default null )
    return varchar2
    ;
--
-- For a given security_group_id, return a delimited list of default tablespaces
-- associated with the workspace schemas
--
function get_tablespaces_by_sgid (
    p_security_group_id in number,
    p_separator         in varchar2 default null )
    return varchar2
    ;


-- function that catches errors and returns NULL if p_in is not a number
function safe2num (
    p_in in varchar2 )
    return number
    ;

--
-- procedure called by the ORACLE_APEX_AUTO_APPROVAL job
--
procedure auto_approve;

end wwv_flow_provisioning;
/

