create package wwv_flow_maint
as
--  Copyright (c) Oracle Corporation 2009. All Rights Reserved.
--
--    DESCRIPTION
--      Maintenance procedures for Oracle Appliation Express
--

procedure archive_activity_summary;

procedure kill_network_waiting_sessions;

procedure daily_maintenance;

end wwv_flow_maint;
/

