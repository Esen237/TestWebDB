create package wwv_flow_dev as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2012-2020. All Rights Reserved.
--
--    NAME
--      wwv_flow_dev.sql
--
--    DESCRIPTION
--      This package is responsible for handling an application in the Builder.
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    03/16/2012 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================


--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Returns the run URL for the specified application and page.
--==============================================================================
function get_run_url (
    p_application_id in number,
    p_page_id        in number   default null,
    p_debug          in varchar2 default null,
    p_friendly_url   in boolean  default false )
    return varchar2;
--
--==============================================================================
-- utility procedure on 4000:1 (set flow, page, and run link)
--==============================================================================
procedure set_flow_builder_state;
--
end wwv_flow_dev;
/

