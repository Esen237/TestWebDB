create package wwv_flow_db_version              is 
    c_ver_le_11_2_0_1 constant boolean := false;
    c_ver_le_11_2_0_2 constant boolean := false;
    c_ver_le_12_1_0_1 constant boolean := false;
    c_has_sql_json constant boolean := true;
    c_has_soda constant boolean := true;
    c_has_locator constant boolean := true;
    c_has_extended_string_size constant boolean := false;
    c_has_dbms_crypto_pkencrypt constant boolean := true;
    c_has_javavm constant boolean := true;
    c_has_dbms_cloud constant boolean := false;
    c_dbms_cloud_owner constant varchar2(1) := '';
    c_actual_dbms_id_length constant pls_integer := 128;
    c_checksum constant varchar2(13) := 'ffftttfttf128';
end wwv_flow_db_version;
/

