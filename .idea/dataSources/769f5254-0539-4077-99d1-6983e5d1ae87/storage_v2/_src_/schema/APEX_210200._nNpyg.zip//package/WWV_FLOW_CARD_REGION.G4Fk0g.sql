create package wwv_flow_card_region
as
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2020. All Rights Reserved.
--
-- NAME
--   wwv_flow_card_region.sql
--
-- DESCRIPTION
--   This package is responsible for handling Card native region plugin.
--
-- RUNTIME DEPLOYMENT: YES
-- PUBLIC:             NO
--
-- MODIFIED   (MM/DD/YYYY)
--   cbcho     06/05/2020 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- This function describes Cards data source and gets the column
-- Note:       Used in facted search rendering as well
--
-- PARAMETERS
--     p_region_id:
--
-- RETURN
--     wwv_flow_exec_api.t_columns
--==============================================================================
function get_card_columns(
    p_region_id in number )
    return wwv_flow_exec_api.t_columns;

--==============================================================================================
-- This function renders a Cards Region
--
-- PARAMETERS
--     p_plugin:
--     p_region:
--     p_plug:
--     p_is_printer_friendly:
--
-- RETURN
--     wwv_flow_plugin_api.t_region_render_result
--==============================================================================================
function render (
    p_plugin              in wwv_flow_plugin_api.t_plugin,
    p_region              in wwv_flow_plugin_api.t_region,
    p_plug                in wwv_flow_meta_data.t_plug,
    p_is_printer_friendly in boolean )
    return wwv_flow_plugin_api.t_region_render_result;

--==============================================================================
-- This function is ajax callback for a Cards Region
--
-- PARAMETERS
--     p_plugin:
--     p_region:
--     p_json_path:
--
-- RETURN
--     wwv_flow_plugin_api.t_region_ajax_result;
--==============================================================================================
function ajax (
    p_plugin               in wwv_flow_plugin_api.t_plugin,
    p_region               in wwv_flow_plugin_api.t_region,
    p_json_path            in varchar2 )
    return wwv_flow_plugin_api.t_region_ajax_result;

end wwv_flow_card_region;
/

