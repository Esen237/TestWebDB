create package wwv_flow_map_region as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2021. All Rights Reserved.
--
--  Implementation package for the map region.
--
--  Since: 21.1
--
--------------------------------------------------------------------------------
--
--    MODIFIED   (MM/DD/YYYY)
--    cczarski    09/21/2020 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================

--==============================================================================
-- Constants
--==============================================================================

subtype t_map_layer_type    is pls_integer range 1..5;

c_map_layer_points             constant t_map_layer_type          := 1;
c_map_layer_lines              constant t_map_layer_type          := 2;
c_map_layer_polygons           constant t_map_layer_type          := 3;
c_map_layer_3d_polygons        constant t_map_layer_type          := 4;
c_map_layer_heat_map           constant t_map_layer_type          := 5;

subtype t_feature_data_type is pls_integer range 1..3;

c_feature_sdo_geometry         constant t_feature_data_type       := 1;
c_feature_geojson              constant t_feature_data_type       := 2;
c_feature_number_columns       constant t_feature_data_type       := 3;

--==============================================================================
-- Globals
--==============================================================================

--
--==============================================================================
-- Renders a Map Region.
--==============================================================================
function render (
    p_plugin              in wwv_flow_plugin_api.t_plugin,
    p_region              in wwv_flow_plugin_api.t_region,
    p_plug                in wwv_flow_meta_data.t_plug,
    p_is_printer_friendly in boolean )
    return wwv_flow_plugin_api.t_region_render_result;
--
--==============================================================================
-- Ajax callback for a Map Region.
--==============================================================================
function ajax (
    p_plugin               in wwv_flow_plugin_api.t_plugin,
    p_region               in wwv_flow_plugin_api.t_region,
    p_json_path            in varchar2 )
    return wwv_flow_plugin_api.t_region_ajax_result;

--
--==============================================================================
-- get columns returned by the region source, in order to be called by
-- faceted search code.
--==============================================================================
function get_map_region_columns(
    p_region_id  in number )
    return wwv_flow_exec_api.t_columns;

end wwv_flow_map_region;
/

