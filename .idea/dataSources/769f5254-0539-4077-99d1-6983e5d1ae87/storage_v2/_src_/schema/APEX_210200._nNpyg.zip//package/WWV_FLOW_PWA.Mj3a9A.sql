create package wwv_flow_pwa as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2021. All Rights Reserved.
--
--    NAME
--      wwv_flow_pwa.sql
--
--    DESCRIPTION
--      This package is used to emit content to the page
--      for applications that have enabled Progressive Web App
--      such as:
--      * Web App Manifest in the head section of a page
--      * Meta tags in the head section of a page
--      * Service worker registration
--      * Web App Manifest file rendering (JSON)
--      * Service Worker file rendering (JavaScript)
--
--    Since: 21.2
--
--    MODIFIED   (MM/DD/YYYY)
--    vmorneau   04/28/2121 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Internal:
--
-- This procedure is used to emit the Web App Manifest for an APEX app
--
-- The Web App Manifest is responsible for holding the definition on the
-- application that will be installed on devices (mobile and desktop).
--
-- The APEX engine will generate a Web App Manifest file will be based on
-- declarative options in the application properties.
--
-- At runtime, the Web App Manifest will be included in the <head> section of the page.
--
-- In addition to those APEX declarative options, developers will be able to
-- enter a custom manifest textarea, with additional JSON data. If a property
-- in custom manifest exists in the declarative options, that property
-- takes precedence (overrides) over the declarative option
--
-- In the end the final Web App Manifest file will consist of
-- * Some default values defined in APEX (home URL, app name, etc.)
-- * Declarative options
-- * Custom options from pwa_manifest_custom
--==============================================================================
procedure emit_manifest;

--==============================================================================
-- Internal:
--
-- This procedure is used to emit the Service Worker for an APEX app
--
-- Service workers are JavaScript files that can execute code even when the app is not in use.
-- It can listen to events like fetching resources or handling notifications.

-- At runtime, the service worker will be invoked on page load.

-- We will not have declarative options for the service worker.
-- The APEX engine will generate it with the following strategy:
-- * Install and activate the service worker
-- * Serve ressources from cache if cache exists
-- * Otherwise serve from network, then put ressource in cache
-- * Serve an offline page if network fails
--==============================================================================
procedure emit_service_worker;

--==============================================================================
-- Internal:
--
-- This procedure is used to emit the Service Worker
-- registration JavaScript on an APEX page rendering
--==============================================================================
procedure emit_register_service_worker;

--==============================================================================
-- Internal:
--
-- This procedure is used to emit <head> HTML tags that are useful
-- for a Progressive Web App on an APEX page rendering
--==============================================================================
procedure emit_header;

end wwv_flow_pwa;
/

