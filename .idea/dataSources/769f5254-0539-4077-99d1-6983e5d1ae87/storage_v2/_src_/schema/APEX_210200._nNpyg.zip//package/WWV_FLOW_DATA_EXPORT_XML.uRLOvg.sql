create package wwv_flow_data_export_xml as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020 All Rights Reserved.
--
--    NAME
--      wwv_flow_data_export_xml.sql
--
--    DESCRIPTION
--      This package is responsible for XML data exports
--
--

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--

--==============================================================================
-- The procedure initializes attributes needed for data export.
--
-- p_xml_for_print_server       Format the XML for the print server
--==============================================================================
procedure init(
    p_for_print_server     in boolean,
    p_include_declaration  in boolean );

--==============================================================================
-- The procedure emits top header and necessary logic to emit headings
--==============================================================================
procedure emit_header;

--==============================================================================
-- The procedure emits bottom footer and necessary logic to finish
--==============================================================================
procedure emit_footer;

--==============================================================================
-- The procedure emits a row with highlights if defined.
--==============================================================================
procedure emit_row;

--==============================================================================
-- The function returns the clob buffer.
--==============================================================================
function get_clob_output return clob;

--==============================================================================
-- The function returns the clob buffer as a blob.
--==============================================================================
function get_blob_output return blob;

--==============================================================================
-- Clears all the memory structures
--==============================================================================
procedure free;

end wwv_flow_data_export_xml;
/

