create package wwv_flow_faceted_search as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2019 All Rights Reserved.
--
--    NAME
--      wwv_flow_faceted_search.plb
--
--    DESCRIPTION
--      This package is responsible for handling faceted search regions.
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    04/15/2019 - Created
--

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--
c_facet                   constant varchar2(40) := 'FACET_COLUMN';
c_list                    constant varchar2(40) := 'list';
c_range                   constant varchar2(40) := 'range';
c_range_list              constant varchar2(40) := 'rangeList';
c_search                  constant varchar2(40) := 'search';
c_select_list             constant varchar2(40) := 'selectList';
c_select_range            constant varchar2(40) := 'selectRange';
c_input                   constant varchar2(40) := 'input';
c_group                   constant varchar2(40) := 'group';
c_checkbox                constant varchar2(40) := 'checkbox';

--==============================================================================
-- Renders a Faceted Search Region.
--==============================================================================
function render (
    p_plugin              in wwv_flow_plugin_api.t_plugin,
    p_region              in wwv_flow_plugin_api.t_region,
    p_plug                in wwv_flow_meta_data.t_plug,
    p_is_printer_friendly in boolean )
    return wwv_flow_plugin_api.t_region_render_result;
--
--==============================================================================
-- Ajax callback for a Faceted Search Region.
--==============================================================================
function ajax (
    p_plugin               in wwv_flow_plugin_api.t_plugin,
    p_region               in wwv_flow_plugin_api.t_region,
    p_json_path            in varchar2,
    p_in_accept            in boolean,
    p_in_set_session_state in boolean )
    return wwv_flow_plugin_api.t_region_ajax_result;

--==============================================================================
-- returns filters to apply to query execution of the given filtered region id (19.2: classic report). This
-- function looks up the Faceted Search region, the facets and the submitted values.
-- A wwv_flow_exec_api.t_filters array is built and returned to the calling component.
--
-- PARAMETERS
--     P_FILTERED_REGION_ID             ID of the filtered region (e.g. classic report)
--
-- RETURNS
--     filters as wwv_flow_exec_api.t_filters array
--==============================================================================
function get_filters_for_region(
    p_filtered_region_id in number ) return wwv_flow_exec_api.t_filters;

--==============================================================================
-- Function:   get_facets_for_region
--
-- Purpose:    This function is being called by the filtered region (the classic report)
--             in order to get the list of facet names
--
-- PARAMETERS
--     p_filtered_region_id:    ID of the filtered region (classic report)
--
-- RETURN
--     list of facets item names as VARCHAR2
--==============================================================================
function get_facets_for_region(
    p_filtered_region_id in number ) return varchar2;

--==============================================================================
-- Function:   get_facets_region_id
--
-- Purpose:    This function is being called by the filtered region (the classic report)
--             in order to get the id of the faceted search region
--
-- PARAMETERS
--     p_filtered_region_id:    ID of the filtered region (classic report)
--
-- RETURN
--     ID of the facets region
--==============================================================================
function get_facets_region_id(
    p_filtered_region_id in number ) return varchar2;

--==============================================================================
-- Function:   reset_state
--
-- Purpose:    resets package state and cached meta data; used for the testing
--             framework.
--==============================================================================
procedure reset_state;

--
end wwv_flow_faceted_search;
/

