create package wwv_flow_data_export_xlsx as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020 All Rights Reserved.
--
--    NAME
--      wwv_flow_data_export_xlsx.sql
--
--    DESCRIPTION
--      This package is responsible for XLSX data exports
--
--

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--

--==============================================================================
-- The procedure initializes attributes needed for data export.
--
-- p_as_table    Generate the data as XLSX Table without features as control breaks and aggregates
--==============================================================================
procedure init(
    p_as_table in boolean );

--==============================================================================
-- The procedure emits top header and necessary logic to emit headings
--==============================================================================
procedure emit_header;

--==============================================================================
-- The procedure emits bottom footer and necessary logic to finish
--==============================================================================
procedure emit_footer;

--==============================================================================
-- The procedure emits a new column break
--==============================================================================
procedure emit_column_break;

--==============================================================================
-- The procedure emits a row with highlights if defined.
--==============================================================================
procedure emit_row;

--==============================================================================
-- The procedure emits previous column break aggregate values.
--==============================================================================
procedure emit_aggregates;

--==============================================================================
-- The procedure emits the overall aggregate values.
--==============================================================================
procedure emit_overall;

--==============================================================================
-- The function returns the clob buffer as a blob.
--==============================================================================
function get_blob_output return blob;

--==============================================================================
-- Clears all the memory structures
--==============================================================================
procedure free;

end wwv_flow_data_export_xlsx;
/

