create package wwv_flow_css_calendar
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2013 - 2021. All Rights Reserved.
--
--    NAME
--      wwv_flow_css_calendar.sql
--
--    DESCRIPTION
--      This package is resonsible for handling css calendar native region plugin.
--
--    MODIFIED      (MM/DD/YYYY)
--    pmanirah       07/30/2013  - Created
--


--==============================================================================
-- global variables
--==============================================================================
c_fullcalendar3_version   constant varchar2(6)  := '3.10.2';
c_fullcalendar5_version   constant varchar2(6)  := '5.5.1';

--==============================================================================
--  This function will return the column definition of the defined
--  calendar region source, mainly used for faceted search integration
--==============================================================================
function get_calendar_columns (
    p_region_id in number )
    return wwv_flow_exec_api.t_columns;

--==============================================================================
-- Renders the CSS Calendar region type based on the configuration of
-- the region.
--==============================================================================
procedure render_css_calendar (
    p_plugin              in wwv_flow_plugin_api.t_plugin,
    p_region              in wwv_flow_plugin_api.t_region,
    p_plug                in wwv_flow_meta_data.t_plug,
    p_is_printer_friendly in boolean );

--==============================================================================
-- Returns the CSS Calendar events.
--==============================================================================

procedure ajax_css_calendar (
    p_region in wwv_flow_plugin_api.t_region );

end wwv_flow_css_calendar;
/

