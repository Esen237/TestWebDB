create package wwv_dg_output_api authid current_user as
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2021. All Rights Reserved.
--
-- This package contains the implementation for data generation in APEX.
--
--
-- Since: 21.1
--
--    MODIFIED   (MM/DD/YYYY)
--     jstraub    01/11/2021 - Created from Anton Nielsen, Neelesh Shah
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Misc Globals
--------------------------------------------------------------------------------
c_ds_data_source_type_table    constant varchar2(30)  := 'TABLE';
c_ds_data_source_type_query    constant varchar2(30)  := 'QUERY';
--
c_col_ds_type_blueprint        constant varchar2(30)  := 'BLUEPRINT';
c_col_ds_type_builtin          constant varchar2(30)  := 'BUILTIN';
c_col_ds_type_data_source      constant varchar2(30)  := 'DATA_SOURCE';
c_col_ds_type_formula          constant varchar2(30)  := 'FORMULA';
c_col_ds_type_inline           constant varchar2(30)  := 'INLINE';
c_col_ds_type_sequence         constant varchar2(30)  := 'SEQUENCE';
c_col_ds_type_table_column     constant varchar2(30)  := 'TABLE_COLUMN';
--
c_max_error_count              constant number        := 10000;
c_comma                        constant varchar2 (1)  := ',';
c_nl                           constant varchar2 (15) := chr (13) || chr(10);
c_json_date_format             constant varchar2 (32) := 'YYYY-MM-DD"T"HH24:MI:SS"Z"';

$IF sys.dbms_db_version.version < 18 $THEN

$ELSE
--==================================================================================================================
-- This function is the download functionality.
--
-- Returns:
-- Returns a file as a BLOB.
--
-- Parameters:
-- * p_blueprint            Name of the blueprint. This value not
--   p_blueprint_table      Null for all tables. If not null, will generate data only for designated table.
--                          If not null, must be table name of a table within the blueprint. Note: this value is
--                          case sensitive.
--   p_row_scaling          Will scale the number of rows defined into the blueprint by this percentage value.
-- * p_format               When p_format = SQL INSERT then function outputs a sql script
--                                        = CSV then function outputs a ZIP for multiple tables
--                                        = JSON then function outputs JSON
--                                        = INSERT INTO then function runs insert into statements
--                                        = FAST INSERT INTO then function runs insert into select statements
-- Example:
--
--    declare
--        l_output    blob;
--    begin
--        l_output :=
--        apex_dg_output.generate_data
--            (p_blueprint          => 'Cars',
--             p_blueprint_table    => null,
--             p_format             => 'CSV'
--            );
--    end;
--==================================================================================================================
function generate_data
    (p_blueprint       in varchar2,
     p_blueprint_table in varchar2 default null,
     p_row_scaling     in number default 100,
     p_format          in varchar2
    ) return blob;



--==================================================================================================================
-- This procedure is the download functionality.
--
-- Parameters:
-- * p_blueprint            Name of the blueprint
-- * p_format               When p_format = SQL INSERT then function outputs a sql script
--                                        = CSV then function outputs a ZIP for multiple tables
--                                        = JSON then function outputs JSON
--                                        = INSERT INTO then function runs insert into statements
--   p_row_scaling          Will scale the number of rows defined into the blueprint by this percentage value.
-- * p_output               The blob to hold the output
-- Example:
--
--
--    declare
--        l_output    blob;
--    begin
--        apex_dg_output.generate_data
--            (p_blueprint          => 'Cars',
--             p_format             => 'CSV',
--             p_output             => l_output
--            );
--    end;
--==================================================================================================================
procedure generate_data
    (p_blueprint    in         varchar2,
     p_format       in         varchar2,
     p_row_scaling  in         number default 100,
     p_output       out nocopy blob
    );



--==================================================================================================================
-- This procedure is the download functionality, returning file extension and mime type.
--
-- Parameters:
-- * p_blueprint            Name of the blueprint
-- * p_format               When p_format = SQL INSERT then function outputs a sql script
--                                        = CSV then function outputs a ZIP for multiple tables
--                                        = JSON then function outputs JSON
--                                        = INSERT INTO then function runs insert into statements
--   p_row_scaling          Will scale the number of rows defined into the blueprint by this percentage value.
-- * p_file_ext             The file extention of the output
-- * p_mime_type            The mime type of the output
-- * p_output               The blob to hold the output
--
--
-- Example:
--
--
--    declare
--        l_blob blob;
--        l_file_ext      varchar2(200);
--        l_mime_type     varchar2(200);
--    begin
--        apex_dg_output.generate_data (
--            p_blueprint  => 'Cars',
--            p_format     => 'CSV',
--            p_file_ext   => l_file_ext,
--            p_mime_type  => l_mime_type,
--            p_output     => l_blob);
--    end;
--==================================================================================================================
procedure generate_data
    (p_blueprint    in         varchar2,
     p_format       in         varchar2,
     p_row_scaling  in         number default 100,
     p_file_ext     out nocopy varchar2,
     p_mime_type    out nocopy varchar2,
     p_output       out nocopy blob
    );



--==================================================================================================================
-- This procedure is the download functionality, returning file extension and mime type.
--
-- Parameters:
-- * p_blueprint            Name of the blueprint
-- * p_blueprint_table      Only tables that will be generate
--   p_row_scaling          Will scale the number of rows defined into the blueprint by this percentage value.
--   p_stop_after_errors    How many errors can happen before the process is stopped
-- * p_errors               Blob holds error output
--
--
-- Example:
--
--
--    declare
--        l_output    blob;
--    begin
--        apex_dg_output.generate_data
--            (p_blueprint          => 'Cars',
--             p_blueprint_table    => 'my_cars',
--             p_stop_after_errors  => 100,
--             p_errors             => l_output
--            );
--    end;
--==================================================================================================================
procedure generate_data
    (p_blueprint            in         varchar2,
     p_blueprint_table      in         varchar2,
     p_row_scaling          in         number default 100,
     p_stop_after_errors    in         number default c_max_error_count,
     p_errors               out nocopy blob
    );



--==================================================================================================================
-- This procedure is the download functionality, returning file extension and mime type.
--
-- Parameters:
-- * p_blueprint            Name of the blueprint
-- * p_blueprint_table      Only tables that will be generate
--   p_row_scaling          Will scale the number of rows defined into the blueprint by this percentage value.
--   p_stop_after_errors    How many errors can happen before the process is stopped
-- * p_file_ext             The file extention of the output
-- * p_mime_type            The mime type of the output
-- * p_output               The blob to hold the output
--
--
-- Example:
--
--
--    declare
--        l_output    blob;
--        l_file_ext  varchar2(255);
--        l_mime_type varchar2(255);
--    begin
--        apex_dg_output.generate_data
--            (p_blueprint          => 'Cars',
--             p_blueprint_table    => 'my_cars',
--             p_stop_after_errors  => 100,
--             p_file_ext           => l_file_ext,
--             p_mime_type          => l_mime_type,
--             p_errors             => l_output
--            );
--    end;
--==================================================================================================================
procedure generate_data
    (p_blueprint            in         varchar2,
     p_blueprint_table      in         varchar2,
     p_row_scaling          in         number default 100,
     p_stop_after_errors    in         number default c_max_error_count,
     p_file_ext             out nocopy varchar2,
     p_mime_type            out nocopy varchar2,
     p_errors               out nocopy blob
    );



--==================================================================================================================
-- This procedure will return the current process status.
--
-- Parameters:
-- * x_current_step   What step the process is on
-- * x_total_steps    How many steps the process has
-- * x_message        For additional information
--
--
-- Example:
--
--   declare
--      l_output varchar2(4000);
--      l_current number;
--      l_total number;
--   begin
--       apex_dg_output.process_status(
--                    x_current_step    => l_current,
--                    x_total_steps     => l_total,
--                    x_message         => l_output);
--   end;
--==================================================================================================================
procedure process_status
    (x_current_step out        number,
     x_total_steps  out        number,
     x_message      out nocopy varchar2
    );



--==================================================================================================================
-- This function is a wrapper for the procedure to return the current process status.
--
--
-- Example:
--
--
--   begin
--       apex_dg_output.process_status;
--   end;
--==================================================================================================================
function process_status
    return varchar2;

$END
end wwv_dg_output_api;
/

