create package wwv_flow_data_export as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020 - 2021. All Rights Reserved.
--
--    NAME
--      wwv_flow_data_export.sql
--
--    DESCRIPTION
--      This package is responsible for common functionality for data exports
--
--

--------------------------------------------------------------------------------
-- Global types
--------------------------------------------------------------------------------
subtype t_column_type           is pls_integer range 1..4;

c_column_type_plain             constant t_column_type          := 1;
c_column_type_html              constant t_column_type          := 2;
c_column_type_markdown          constant t_column_type          := 3;
c_column_type_image             constant t_column_type          := 4;

subtype t_blob_display_mode     is varchar2( 8 );

c_blob_image                    constant t_blob_display_mode    := 'IMAGE';
c_blob_download                 constant t_blob_display_mode    := 'DOWNLOAD';

type t_column_group is record (
    heading                     wwv_flow_data_export_api.t_label,
    label                       wwv_flow_data_export_api.t_label,
    alignment                   wwv_flow_data_export_api.t_alignment,
    parent_group_idx            pls_integer );-- references the parent entry in t_column_groups

-- Cascading LOVs are not yet part of the EXEC infrastructure because they need the current row values as bind variables
type t_column_cascading_lov is record (
    sql_statement               varchar2(32767), -- Must have two columns: display and return
    shared_id                   number,
    display_extra               boolean, -- If no data found, use return value for display
    is_legacy                   boolean ); -- Legacy LOVs use the plugin architecture (local SQL only, 2 columns)

type t_column_blob is record (
    display_mode                t_blob_display_mode,
    table_name                  varchar2( 32767 ),
    pk1_column                  wwv_flow_exec_api.t_column_name,
    pk2_column                  wwv_flow_exec_api.t_column_name,
    blob_column                 wwv_flow_exec_api.t_column_name,
    mime_type_column            wwv_flow_exec_api.t_column_name,
    file_name_column            wwv_flow_exec_api.t_column_name,
    last_update_column          wwv_flow_exec_api.t_column_name,
    char_set_column             wwv_flow_exec_api.t_column_name,
    content_disposition         wwv_flow_data_export_api.t_content_disposition,
    text                        varchar2( 32767 ),
    table_owner                 varchar2( 32767 ) );

 type t_column is record (
    name                        wwv_flow_exec_api.t_column_name,
    generic_name                varchar2(4000),
    type                        t_column_type                        default c_column_type_plain,
    heading                     wwv_flow_data_export_api.t_label,
    label                       wwv_flow_data_export_api.t_label,
    format_mask                 varchar2(4000),
    html_expression             varchar2(4000),
    heading_alignment           wwv_flow_data_export_api.t_alignment,
    value_alignment             wwv_flow_data_export_api.t_alignment,
    width                       number,
    is_escaped                  boolean,
    strip_rich_text             boolean,
    is_multi_value              boolean,
    group_idx                   pls_integer, -- references an entry in t_column_groups
    is_column_break             boolean,
    is_frozen                   boolean,
    display_column              wwv_flow_exec_api.t_column_name,  -- The column that contains the display value (for lookup columns)
    cascading_lov               t_column_cascading_lov,
    blob_attributes             t_column_blob );

type t_columns                  is table of t_column       index by pls_integer;
type t_column_groups            is table of t_column_group index by pls_integer;

type t_feature is record (
    column_heading              boolean,
    column_group                boolean,
    column_break                boolean,
    highlight                   boolean,
    aggregate                   boolean,
    overall                     boolean,
    frozen_column               boolean,
    html_text                   boolean,
    html_value                  boolean,
    html_expression             boolean );

type t_columns_in_group is record (
    group_idx                   pls_integer,
    column_ids                  wwv_flow_global.n_arr,
    width                       number );

type t_column_group_heading     is table of t_columns_in_group index by pls_integer;

type t_column_group_headings    is table of t_column_group_heading index by pls_integer;

type t_highlight_ids            is table of pls_integer index by pls_integer;
type t_column_highlight_ids     is table of t_highlight_ids index by wwv_flow_exec_api.t_column_name;

type t_used_highlights is record (
    row_highlight_id            pls_integer,
    apply_row_text_color        boolean,
    apply_row_bg_color          boolean,
    column_highlight_ids        t_column_highlight_ids );

subtype t_aggregate_label       is varchar2( 255 );

type t_escaped_col_names        is table of varchar2(32767) index by wwv_flow_exec_api.t_column_name;

type t_nls_params               is table of sys.nls_session_parameters.value%type index by sys.nls_session_parameters.parameter%type;

type t_blob_value is record (
    content                     blob,
    file_name                   varchar2( 32767 ),
    mime_type                   varchar2( 32767 ),
    last_update                 date,
    character_set               varchar2( 32767 ) );

--------------------------------------------------------------------------------
-- Public constant definitions
--------------------------------------------------------------------------------
c_empty_columns                 t_columns;
c_empty_column_groups           t_column_groups;
c_empty_filters                 wwv_flow_global.vc_arr2;
c_empty_searches                wwv_flow_global.vc_arr2;

-- Don't use wwv_flow_json date format constants for date and timestamp because it adds the Z (UTC timezone)
c_date_iso8601                  constant varchar2(30)           := 'yyyy-mm-dd"T"hh24:mi:ss';
c_timestamp_iso8601_ff          constant varchar2(30)           := 'yyyy-mm-dd"T"hh24:mi:ss.ff';

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--
g_format                        varchar2(255);
g_columns                       t_columns;
g_column_groups                 t_column_groups;
g_aggregates                    wwv_flow_data_export_api.t_aggregates;
g_highlights                    wwv_flow_data_export_api.t_highlights;
g_filters                       wwv_flow_global.vc_arr2;
g_searches                      wwv_flow_global.vc_arr2;
g_file_name                     varchar2(255);
g_supplemental_text             varchar2(4000);
g_attribute_value_pairs         wwv_flow_global.vc_map;
g_print_config                  wwv_flow_data_export_api.t_print_config;


g_real_column_idx               number;
g_column_group_levels           pls_integer;
g_feature                       t_feature;

g_exec_columns                  wwv_flow_exec_api.t_columns;

g_escaped_col_names             t_escaped_col_names;

--==============================================================================
-- The procedure runs the data export.
--
-- p_context                    Context object from the EXEC infrastructure
-- p_format                     Export format (CSV or HTML)
-- p_columns                    Collection of column attributes with column breaks in the beginning and rest in the order of display.
-- p_column_groups              Collection of column group attributes in the order of levels and display.
-- p_aggregates                 Collection of report aggregates
-- p_highlights                 Collection of report highlights
-- p_column_break_column        Name of the column that indicates then end of a column break. If null, apply internal logic to check previous & current row
-- p_column_break_value         The value that indicates the end of a column break
-- p_filters                    Collection of filter names
-- p_searches                   Collection of search names
-- p_title                      File page title (HTML)
-- p_file_name                  File name for the export
-- p_supplemental_text          Text at the top of all download formats
-- p_report_layout_name         The name of the report layout for external printing.
-- p_attribute_value_pairs      Used for p_format = c_format_xml and c_format_xml for extra metadata
-- p_ignore_features            Used to only export columns and rows, not column groups, aggregates, highlights and control breaks
-- p_emit_column_headings       Whether to emit column headers
-- p_csv_enclosed_by            Used for p_format = c_format_csv to enclose the output
-- p_csv_separator              Used for p_format = c_format_csv to separate the column values
-- p_csv_null_value             Used for p_format = c_format_csv to display null values as
-- p_print_config               Used for p_format = c_format_pdf to set the print attributes
-- p_pdf_accessible             Used for p_format = c_format_pdf to create an accessible PDF
-- p_pdf_exact_widths           Used for p_format = c_format_pdf to use the exact column widths
-- p_xml_include_declaration    Used for p_format = c_format_xml to generate XML without declaration
--==============================================================================
procedure run (
    p_context                   in wwv_flow_exec.t_context,
    p_format                    in varchar2,
    p_columns                   in t_columns                                default c_empty_columns,
    p_column_groups             in t_column_groups                          default c_empty_column_groups,
    p_aggregates                in wwv_flow_data_export_api.t_aggregates    default wwv_flow_data_export_api.c_empty_aggregates,
    p_highlights                in wwv_flow_data_export_api.t_highlights    default wwv_flow_data_export_api.c_empty_highlights,
    p_column_break_column       in wwv_flow_exec_api.t_column_name          default null,
    p_column_break_value        in varchar2                                 default null,
    p_filters                   in wwv_flow_global.vc_arr2                  default c_empty_filters,
    p_searches                  in wwv_flow_global.vc_arr2                  default c_empty_searches,
    --
    p_file_name                 in varchar2                                 default null,
    p_supplemental_text         in varchar2                                 default null,
    p_report_layout_name        in varchar2                                 default null,
    p_attribute_value_pairs     in wwv_flow_global.vc_map                   default wwv_flow_global.c_empty_vc_map,
    p_ignore_features           in boolean                                  default false,
    p_emit_column_headings      in boolean                                  default true,
    --
    p_csv_enclosed_by           in varchar2                                 default null,
    p_csv_separator             in varchar2                                 default null,
    p_csv_null_value            in varchar2                                 default null,
    --
    p_print_config              in wwv_flow_data_export_api.t_print_config  default wwv_flow_data_export_api.c_empty_print_config,
    --
    p_pdf_accessible            in boolean                                  default null,
    p_pdf_exact_widths          in boolean                                  default null,
    --
    p_xml_include_declaration   in boolean                                  default null );

--==============================================================================
-- The procedure will determine which features are used in the export
--==============================================================================
procedure init_features(
    p_column_heading    in boolean default null,
    p_column_group      in boolean default null,
    p_column_break      in boolean default null,
    p_highlight         in boolean default null,
    p_aggregate         in boolean default null,
    p_overall           in boolean default null,
    p_frozen_column     in boolean default false,
    p_html_text         in boolean default false,
    p_html_value        in boolean default true,
    p_html_expression   in boolean default false );

--==============================================================================
-- Returns true if there is a next group level
--==============================================================================
function next_column_group_level return boolean;

--==============================================================================
-- Returns true if there is a next group
--==============================================================================
function next_column_group return boolean;

--==============================================================================
-- Returns the columns of the current group
--==============================================================================
function get_columns_in_group return t_columns_in_group;

--==============================================================================
-- This function advances the cursor of an open query context, after execution, by one row.
--==============================================================================
function next_row return boolean;

--==============================================================================
-- The procedure will reset the memory state the the first real column
--==============================================================================
procedure reset_to_real_column;

--==============================================================================
-- The procedure will reset the memory state the the first column
--==============================================================================
procedure reset_to_first_column;

--==============================================================================
-- Returns true if there is a next real column
--==============================================================================
function next_column return boolean;

--==============================================================================
-- Returns the column specified by id or the current real column
--==============================================================================
function get_column return t_column;

--==============================================================================
-- Returns the EXEC column specified by id or the current real column
--==============================================================================
function get_exec_column return wwv_flow_exec_api.t_column;

--==============================================================================
-- Get the EXEC column position of the current column
--==============================================================================
function get_exec_column_position (
    p_column_name in varchar2 default null )
    return pls_integer;

--==============================================================================
-- Returns the current column id
--==============================================================================
function get_column_id return pls_integer;

--==============================================================================
-- Returns true if the current column is the first real column
--==============================================================================
function is_first_column return boolean;

--==============================================================================
-- Returns the value for the column in an EXEC structure
--==============================================================================
function get_column_value (
    p_as_varchar2 in boolean default false )
    return wwv_flow_exec_api.t_value;

--==============================================================================
-- Get the value in varchar2 of the current column
--==============================================================================
function get_column_value_as_varchar2 return varchar2;

--==============================================================================
-- Get the value in blob of the current column
--==============================================================================
function get_column_value_as_blob return t_blob_value;

--==============================================================================
-- Returns the value for the current aggregate in an EXEC structure
-- p_as_varchar2        always try to convert the value to varchar2
--==============================================================================
function get_aggr_value (
    p_as_varchar2 in boolean default false )
    return wwv_flow_exec_api.t_value;

--==============================================================================
-- Get the value in varchar2 of the current aggregate
--==============================================================================
function get_aggr_value_as_varchar2 return varchar2;

--==============================================================================
-- Get the highlight information for the current row
--==============================================================================
function get_used_highlights return t_used_highlights;

--==============================================================================
-- Get the colspan for a column break row
--==============================================================================
function get_column_break_colspan return pls_integer;

--==============================================================================
-- The procedure will reset the memory state the the first aggregate group
--==============================================================================
procedure reset_to_first_aggregate_group;

--==============================================================================
-- Returns true if there is a next aggregate group
--==============================================================================
function next_aggregate_group return boolean;

--==============================================================================
-- Returns true if the current column is in the aggregate group
--==============================================================================
function column_in_aggregate_group return boolean;

--==============================================================================
-- Returns the label of the current aggregate group
--==============================================================================
function get_aggregate_group_label return t_aggregate_label;

--==============================================================================
-- Returns the current aggregate id
--==============================================================================
function get_aggregate_id return pls_integer;

--==============================================================================
-- Returns the current aggregate
--==============================================================================
function get_aggregate return wwv_flow_data_export_api.t_aggregate;

--==============================================================================
-- Returns the current aggregate column
--==============================================================================
function get_aggregate_exec_column return wwv_flow_exec_api.t_column;

--==============================================================================
-- Returns true if there current column break group has ended
--==============================================================================
function end_of_column_break return boolean;

--==============================================================================
-- Returns the label of a column break
--==============================================================================
function get_column_break_label return varchar2;

--==============================================================================
-- Changes the underlying object for aggregation functions / procedures
--==============================================================================
procedure set_pivoted_aggregated(
    p_overall in boolean );

--==============================================================================
-- Returns true is the font weight is "bold"
--
-- p_font_weight        Font weight value from printing attributes
--==============================================================================
function is_bold(
    p_font_weight in varchar2 )
    return boolean;

--==============================================================================
-- The function returns the clob;
--==============================================================================
function get_clob_output return clob;

--==============================================================================
-- The function returns the blob.
--==============================================================================
function get_blob_output return blob;

--==============================================================================
-- The function returns the mimetype for the specified format
--==============================================================================
function get_mime_type(
    p_format in varchar2 default g_format )
    return varchar2;

--==============================================================================
-- The function checks if the format is valid
--==============================================================================
function valid_format(
    p_format in varchar2
    ) return boolean;

--==============================================================================
-- The function remove the .ext from a file name
--==============================================================================
function remove_extension (
    p_file_name in varchar2
    ) return varchar2;

--==============================================================================
-- Uses the export as input for an external print server and downloads the file
--
-- p_format                    The final file format for the external print server
-- p_extension                 The final file extension
-- p_content_type              The final file content type
-- p_template_id               The id of the custom report template
--==============================================================================
procedure print_external(
    p_format                    in varchar2,
    p_extension                 in varchar2,
    p_content_type              in varchar2,
    p_template_id               in wwv_flow_report_layouts.id%type                  default null,
    p_content_disposition       in wwv_flow_data_export_api.t_content_disposition   default wwv_flow_data_export_api.c_attachment );

--==============================================================================
-- Get a key value pair map of NLS settings
--==============================================================================
function get_nls_params return t_nls_params;

--==============================================================================
-- Get the image placeholder for invalid images
--==============================================================================
function get_image_placeholder return t_blob_value;

--==============================================================================
-- The function gets the output of a data export run
--==============================================================================
function get_output (
    p_as_clob       in boolean      default false )
    return wwv_flow_data_export_api.t_export;

--==============================================================================
-- The procedure downloads the data export
-- Note that this procedure calls apex_application.stop_apex_engine
--==============================================================================
procedure download (
    p_export                in out nocopy wwv_flow_data_export_api.t_export,
    p_content_disposition   in wwv_flow_data_export_api.t_content_disposition   default wwv_flow_data_export_api.c_attachment,
    p_preserve_filename     in boolean                                          default false,
    p_stop_apex_engine      in boolean                                          default true );

--==============================================================================
-- Clears all the memory structures
--==============================================================================
procedure free;

--
end wwv_flow_data_export;
/

