create package wwv_flow_spotlight_dev as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2009 - 2017. All Rights Reserved.
--
--    NAME
--      wwv_flow_spotlight_dev.sql
--
--    DESCRIPTION
--      This package is for Spotlight Search in App Builder
--
--    MODIFIED   (MM/DD/YYYY)
--    xhu         08/01/2017 - Created
--    hfarrell    08/22/2017 - Added set define at end of file (resolving Hudson install issue)
--    xhu         01/01/2018 - Added custom entries defined in App 4411 > Shared Components > Lists
--                             Added wwv_flow_list_items.list_text_10 as tokens
--
--------------------------------------------------------------------------------
--
--
--------------------------------------------------------------------------------
-- Type and procedure to store and use all shared components lists and
-- sublists with static IDs
--------------------------------------------------------------------------------
type t_shared_components_path is varray(3) of varchar2(50);

type t_shared_components_list is record (
    list_id             number default 0,
    list_path           t_shared_components_path,
    list_is_parent      boolean default false,
    list_app_id         number default 0,
    list_icon           varchar2(500),
    list_description    varchar2(500),
    list_priority       number default 0,
    list_scope          varchar2(500) );
type t_sh_comp_list_table is table of t_shared_components_list index by binary_integer;

type t_shared_components_actions is record (
    action_name         varchar2(255),
    action_label        varchar2(255),
    action_path         t_shared_components_path,
    action_page         number default 0,
    action_app_id       number default 0);
type t_actions_table is table of t_shared_components_actions index by binary_integer;

--==============================================================================
-- Emit a global JSON structure of Nav menus, global index of apps
--==============================================================================
procedure emit_common_spotlight_index(
    p_is_page_designer  in boolean default false );

--==============================================================================
-- Main procedure called from AJAX
--==============================================================================
procedure emit_spotlight_index(
   p_app_id             in number default null,
   p_get_apps_list      in varchar2 default null,
   p_is_page_designer   in boolean default false);

--==============================================================================
-- Emit a JSON structure of apps for the user
--==============================================================================
procedure emit_apps_spotlight_index;

--------------------------------------------------------------------------------
-- Emit a JSON structure of all pages within an app id
--------------------------------------------------------------------------------
procedure emit_spotlight_app_index (
    p_app_id            in number  default null,
    p_is_page_designer  in boolean default false);

end wwv_flow_spotlight_dev;
/

