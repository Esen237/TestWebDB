create package wwv_flow_page_map as
--------------------------------------------------------------------------------
--
--
--    MODIFIED   (MM/DD/YYYY)
--    mhichwa     11/20/2006 - Created
--    mhichwa     12/08/2006 - Added set_current_application, removed set_application
--
--------------------------------------------------------------------------------

function page_type (
   p_application_id in number,
   p_page_id in number)
return varchar2;

procedure set_page (
   p_application_id in number,
   p_page_id        in number);

procedure set_current_application (
   p_application_id in number,
   p_date           in date default null);

end wwv_flow_page_map;
/

