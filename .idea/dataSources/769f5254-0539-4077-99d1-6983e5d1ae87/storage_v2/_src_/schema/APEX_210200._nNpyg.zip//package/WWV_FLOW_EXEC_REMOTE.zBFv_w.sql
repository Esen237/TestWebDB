create package wwv_flow_exec_remote is
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2020. All Rights Reserved.
--
--    NAME
--      wwv_flow_remote_exec.sql
--
--    DESCRIPTION
--      SQL Data Access for remote ORDS instances (feature #2109).
--
--
--    MODIFIED   (MM/DD/YYYY)
--    cczarski    03/14/2017 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Constants
--==============================================================================

--======================================================================================================================
-- global types
--======================================================================================================================
type t_remote_server is record(
    endpoint_url      wwv_remote_servers.base_url%type,
    https_host        wwv_remote_servers.https_host%type,
    --
    ords_timezone     wwv_remote_servers.ords_timezone%type,
    ords_init_code    wwv_remote_servers.ords_init_code%type,
    ords_cleanup_code wwv_remote_servers.ords_cleanup_code%type,
    --
    credential_id     wwv_remote_servers.credential_id%type );

--======================================================================================================================
-- retrieves remote server details based on remote server ID
--======================================================================================================================
function get_remote_server(
    p_remote_server_id wwv_remote_servers.id%type
) return t_remote_server;

--======================================================================================================================
-- finds the remote server ID by static ID
--
-- PARAMETERS
--     p_server_static_id        IN remote server static ID
--======================================================================================================================
function find_remote_server_id(
    p_server_static_id in varchar2 ) return wwv_remote_servers.static_id%type;

--==============================================================================
-- Performs the "open_query_context" operation for execution on a remote server.
--
-- For a DML context, the procedure does nothing; a query context will be
-- executed so that the component can continue with fetching rows.
--
-- p_context: context object with execution details
--==============================================================================
procedure open_query_context (
    p_context              in out nocopy wwv_flow_exec.t_context,
    p_columns              in            wwv_flow_exec_api.t_columns default wwv_flow_exec_api.c_empty_columns,
    p_cache                in            varchar2                    default null,
    p_cache_invalidation   in            varchar2                    default null,
    p_cache_component_id   in            number                      default null,
    p_cache_component_type in            number                      default null);

--==============================================================================
-- Performs a describe operation for the query on the remote server and
-- populates the context object with result set metadata
--
-- p_sql_query: SQL    Query to describe
-- p_remote_server_id: Remote Server ID to execute the describe on
-- p_columns:          Array of columns
--==============================================================================

function describe_query (
    p_remote_server_id in number,
    p_sql_query        in wwv_flow_global.vc_arr2,
    p_test_for_rowid   in boolean  default false,
    p_optimizer_hint   in varchar2 default null )
    return wwv_flow_exec_api.t_columns;

--==============================================================================
-- Executes the DML operation on the remote server.
--
-- PARAMETERS:
--     p_context             context object with execution details
--     p_continue_on_error   continue with processing the remaining rows when
--                           an error occurs on one row
--==============================================================================
procedure execute_dml (
    p_context           in out nocopy wwv_flow_exec.t_context,
    p_continue_on_error in            boolean                     default false );

--==============================================================================
-- Computes the row version checksum for the current row. This is a special
-- implementation for Remote SQL for the following reasons:
--
-- * We cannot compute the checksum locally - it has to be the same HTTP request
--   as the actual DML update statement. This is because REST Enabled SQL is
--   stateless.
-- * We cannot rely on any APEX package on the remote side
-- * We cannot rely on DBMS_CRYPTO on the remote side; a DB user has no privs
--   on this by default.
--
-- So we cpompute a very simple "checksum" using plain SQL functions. This function
-- computes the "checksum" based on simple LENGTH and "+"/"-" arithmetic operations.
--
-- PARAMETERS
--     p_context: context object with execution details
--
-- RETURNS:
--     the computed checksum
--==============================================================================
function get_row_version_checksum(
    p_context in wwv_flow_exec.t_context ) return varchar2;

--==============================================================================
-- Executes the PL/SQL operation on the remote server.
--
-- p_context: context object with execution details
--==============================================================================
procedure execute_plsql (
    p_context in out nocopy wwv_flow_exec.t_context );

--==============================================================================
-- Fetches the next page for a query context.
--
-- p_context: context object with execution details
--==============================================================================
function next_page (
    p_context in out nocopy wwv_flow_exec.t_context )
    return boolean;

--==============================================================================
-- Tests whether credentials for this remote server are correct
--
-- p_remote_server_id: Remote Server ID to execute the describe on
--==============================================================================
function test_authentication(
    p_remote_server_id in number ) return boolean;

--==============================================================================
-- Executes a PL/SQL function code block and returns a VARCHAR2 result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_plsql_function: PL/SQL function which returns string.
--                   For example:
--                   declare
--                       l_test varchar2(10);
--                   begin
--                       -- do something
--                       return l_test;
--                   end;
--==============================================================================
function get_plsql_func_result_varchar2(
    p_plsql_expression in varchar2,
    p_remote_server_id in number,
    p_binds            in wwv_flow_exec_api.t_parameters  default wwv_flow_exec_api.c_empty_parameters
) return varchar2;

--==============================================================================
-- Executes a PL/SQL function code block and returns a BOOLEAN result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_plsql_function: PL/SQL function which returns boolean.
--                   For example:
--                   declare
--                       l_test boolean;
--                   begin
--                       -- do something
--                       return l_test;
--                   end;
--==============================================================================
function get_plsql_func_result_boolean(
    p_plsql_function   in varchar2,
    p_remote_server_id in number,
    p_binds            in wwv_flow_exec_api.t_parameters  default wwv_flow_exec_api.c_empty_parameters
) return boolean;

--==============================================================================
-- Executes a SQL statement which contains one VARCHAR2 column and returns the
-- value of the first row. If the SQL statement doesn't return any rows or the
-- SQL statement itself is NULL then NULL will be returned.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_sql_statement: SQL statement with one VARCHAR2 column.
--==============================================================================
function get_first_row_result_varchar2 (
    p_sql_statement    in varchar2,
    p_remote_server_id in number,
    p_binds            in wwv_flow_exec_api.t_parameters  default wwv_flow_exec_api.c_empty_parameters
) return varchar2;

--==============================================================================
-- Checks PL/SQL code in the remote database
--
-- PARAMETERS
--    p_plsql_code        PL/SQL code to verify
--    p_remote_server_id  The ID of the remote server
--
-- RETURNS
--    the error message in case of an error, NULL on success
--==============================================================================
function check_plsql(
    p_plsql_code       in varchar2,
    p_remote_server_id in number ) return varchar2;

--==============================================================================
-- Tests a ORDS Remote SQL server.
--
-- PARAMETERS:
--    * p_remote_sql_server_id  The ID of the remote server
--    * p_update_timezone       Update the time zone information based on the server response
--
-- RETURNS
--    * p_sql_response:         The remote SQL server response of the test query
--    * p_http_status:          HTTP Status Code (e.g. 401 for Unauthorized)
--    * p_sqlcode:              Remote SQL ORA Error code, if applicable
--    * p_is_remote_sql:        "1" when the server is a Remote SQL server 0 otherwise
--==============================================================================
procedure test_remote_sql_server(
    p_remote_sql_server_id in  number,
    p_update_timezone      in  boolean default true,
    p_sql_response         out varchar2,
    p_http_status          out number,
    p_sqlcode              out number,
    p_is_remote_sql        out number );

end wwv_flow_exec_remote;
/

