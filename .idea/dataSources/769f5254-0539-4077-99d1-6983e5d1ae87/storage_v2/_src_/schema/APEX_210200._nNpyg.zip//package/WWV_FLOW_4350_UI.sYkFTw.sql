create package wwv_flow_4350_ui as
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2020. All Rights Reserved.
--
-- NAME
--   wwv_flow_4350_ui.sql
--
-- DESCRIPTION
--   UI code for workspace administration app
--
-- RUNTIME DEPLOYMENT: NO
-- PUBLIC:             NO
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  10/28/2020 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Send a workspace usage email.
--==============================================================================
procedure p83_send_ws_usage_mail (
    p_security_group_id in number default null,
    p_to                in varchar2,
    p_subject           in varchar2,
    p_body              in varchar2,
    p_reporting_period  in varchar2,
    p_date_time_format  in varchar2 );

end wwv_flow_4350_ui;
/

