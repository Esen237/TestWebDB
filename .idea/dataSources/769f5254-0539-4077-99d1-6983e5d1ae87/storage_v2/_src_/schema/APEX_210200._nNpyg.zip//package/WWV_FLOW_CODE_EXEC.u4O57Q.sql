create package wwv_flow_code_exec authid definer as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020 - 2021. All Rights Reserved.
--
--    NAME
--      wwv_flow_code_exec.sql
--
--    DESCRIPTION
--      This package is responsible for executing code in the specified language.
--
--      Package must be authid definer, see qkscollIsBinException.
--
--    RUNTIME DEPLOYMENT: YES
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    07/24/2020 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================
type t_bind_value is record (
    name  varchar2( 255 ),
    value varchar2( 32767 ) );

type t_bind_values is table of t_bind_value index by pls_integer;

subtype vc_arr2 is wwv_flow_global.vc_arr2;
subtype t_language is wwv_flow_exec_api.t_language;

--==============================================================================
-- Global constants
--==============================================================================

-- Note: keep in sync with api.plb / migrate_source_code_lang!
c_plsql      constant t_language := wwv_flow_exec_api.c_lang_plsql;
c_javascript constant t_language := wwv_flow_exec_api.c_lang_javascript;
c_java       constant t_language := 'JAVA';
c_python     constant t_language := 'PYTHON';
c_sql        constant t_language := 'SQL'; -- only supported for get_expression_*

c_empy_binds   t_bind_values;
c_empty_names  vc_arr2;
c_empty_values vc_arr2;

--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Executes an expression and returns a VARCHAR2 result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_expression: expression in the language specified which returns string.
-- p_language:   language of the expression.
--==============================================================================
function get_expression_result_varchar2 (
    p_expression       in varchar2,
    p_language         in t_language,
    p_auto_bind_items  in boolean    default true,
    p_names            in vc_arr2    default c_empty_names,
    p_values           in vc_arr2    default c_empty_values,
    p_parse_as_schema  in varchar2   default wwv_flow_security.g_parse_as_schema )
    return varchar2;

--==============================================================================
-- Executes an expression and returns a BOOLEAN result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_expression: expression in the language specified which returns boolean.
-- p_language:   language of the expression.
--==============================================================================
function get_expression_result_boolean (
    p_expression       in varchar2,
    p_language         in t_language,
    p_auto_bind_items  in boolean    default true,
    p_names            in vc_arr2    default c_empty_names,
    p_values           in vc_arr2    default c_empty_values,
    p_parse_as_schema  in varchar2   default wwv_flow_security.g_parse_as_schema )
    return boolean;

--==============================================================================
-- Executes a function body and returns a VARCHAR2 result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_function_body: function body in the language specified which returns string.
-- p_language:      language of the function body.
--
--                  PL/SQL example:
--                  declare
--                      l_test varchar2(10);
--                  begin
--                      -- do something
--                      return l_test;
--                  end;
--==============================================================================
function get_func_body_result_varchar2 (
    p_function_body    in varchar2,
    p_language         in t_language,
    p_auto_bind_items  in boolean    default true,
    p_names            in vc_arr2    default c_empty_names,
    p_values           in vc_arr2    default c_empty_values,
    p_parse_as_schema  in varchar2   default wwv_flow_security.g_parse_as_schema,
    p_do_substitutions in boolean    default true ) -- $$$ remove????
    return varchar2;

--==============================================================================
-- Executes a function body and returns a CLOB result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_function_body: function body in the language specified which returns a clob.
-- p_language:      language of the expression.
--
--                  PL/SQL example:
--                  declare
--                      l_test clob;
--                  begin
--                      -- do something
--                      return l_test;
--                  end;
--==============================================================================
function get_func_body_result_clob (
    p_function_body   in varchar2,
    p_language        in t_language,
    p_auto_bind_items in boolean    default true,
    p_names           in vc_arr2    default c_empty_names,
    p_values          in vc_arr2    default c_empty_values,
    p_parse_as_schema in varchar2   default wwv_flow_security.g_parse_as_schema )
    return clob;

--==============================================================================
-- Executes a function body and returns a BOOLEAN result.
--
-- The function automatically performs the necessary binding of bind variables.
--
-- p_function_body: function body in the language specified which returns boolean.
-- p_language:      language of the expression.
--
--                  PL/SQL example:
--                  declare
--                      l_test boolean;
--                  begin
--                      -- do something
--                      return l_test;
--                  end;
--==============================================================================
function get_func_body_result_boolean (
    p_function_body   in varchar2,
    p_language        in t_language,
    p_auto_bind_items in boolean    default true,
    p_names           in vc_arr2    default c_empty_names,
    p_values          in vc_arr2    default c_empty_values,
    p_parse_as_schema in varchar2   default wwv_flow_security.g_parse_as_schema )
    return boolean;

--==============================================================================
-- Executes code.
--
-- The procedure automatically performs the necessary binding of bind variables.
--
-- p_code:     code in the language specified which should get executed.
-- p_language: language of the expression.
--==============================================================================
procedure execute (
    p_code                 in varchar2,
    p_language             in t_language,
    p_auto_bind_items      in boolean  default true,
    p_names                in vc_arr2  default c_empty_names,
    p_values               in vc_arr2  default c_empty_values,
    p_parse_as_schema      in varchar2 default wwv_flow_security.g_parse_as_schema,
    p_is_user_schema       in boolean  default null,
    p_commit_session_state in boolean  default true,
    p_plugin_cache_key     in varchar2 default null );

--==============================================================================
-- Executes code and returns OUT bind variables.
--
-- The procedure automatically performs the necessary binding of bind variables
-- and returns the new bind variable values after processing in the p_names and
-- p_values arguments (IN OUT NOCOPY)
--
-- When wwv_flow_plugin passes a cache key (type:name) in, the cursor gets
-- cached and reused on the next call with the same cache key.
--==============================================================================
procedure execute_return_out_binds (
    p_code                 in            varchar2,
    p_language             in            t_language,
    p_auto_bind_items      in            boolean  default true,
    p_names                in out nocopy vc_arr2,
    p_values               in out nocopy vc_arr2,
    p_parse_as_schema      in            varchar2 default wwv_flow_security.g_parse_as_schema,
    p_is_user_schema       in            boolean  default null,
    p_commit_session_state in            boolean  default true,
    p_plugin_cache_key     in            varchar2 default null );

--==============================================================================
-- Close any cached cursors (called from wwv_flow_security.teardown).
--==============================================================================
procedure teardown;

end wwv_flow_code_exec;
/

