create package wwv_flow_data_export_csv as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2020 All Rights Reserved.
--
--    NAME
--      wwv_flow_data_export_csv.sql
--
--    DESCRIPTION
--      This package is responsible for CSV data exports
--
--

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--

--==============================================================================
-- The procedure initializes attributes needed for data export.
--
-- p_csv_enclosed_by            Used to enclose the output
-- p_csv_separator              Used to separate the column values
-- p_csv_null_value             Used to display null values as
-- p_csv_legacy                 Wether to force enclosing values and strip html
--==============================================================================
procedure init (
    p_csv_enclosed_by       in varchar2,
    p_csv_separator         in varchar2,
    p_csv_null_value        in varchar2,
    p_csv_legacy            in boolean );

--==============================================================================
-- The procedure emits top header and necessary logic to emit headings
--==============================================================================
procedure emit_header;

--==============================================================================
-- The procedure emits bottom footer and necessary logic to finish
--==============================================================================
procedure emit_footer;

--==============================================================================
-- The procedure emits a row with highlights if defined.
--==============================================================================
procedure emit_row;

--==============================================================================
-- The procedure emits previous column break aggregate values.
--==============================================================================
procedure emit_aggregates;

--==============================================================================
-- The procedure emits the overall aggregate values.
--==============================================================================
procedure emit_overall;

--==============================================================================
-- The function returns the clob buffer.
--==============================================================================
function get_clob_output return clob;

--==============================================================================
-- The function returns the clob buffer as a blob.
--==============================================================================
function get_blob_output return blob;

--==============================================================================
-- Clears all the memory structures
--==============================================================================
procedure free;

end wwv_flow_data_export_csv;
/

