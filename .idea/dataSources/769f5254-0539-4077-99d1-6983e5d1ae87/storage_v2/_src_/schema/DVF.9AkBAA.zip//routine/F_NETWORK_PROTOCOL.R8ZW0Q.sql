create FUNCTION     "F$NETWORK_PROTOCOL" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Network_Protocol'); END;
/

