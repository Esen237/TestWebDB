create FUNCTION     "F$DOMAIN" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Domain'); END;
/

