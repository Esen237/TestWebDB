create PACKAGE body            MGMT_CONFIG_UTL AS

PLATFORM_WINDOWS32    CONSTANT BINARY_INTEGER := 7;
PLATFORM_WINDOWS64    CONSTANT BINARY_INTEGER := 8;
PLATFORM_WINDOWS64AMD CONSTANT BINARY_INTEGER := 12;
PLATFORM_OPENVMS      CONSTANT BINARY_INTEGER := 15;


-- ###############################################
-- The two local functions ENQUOTE_INTERNAL and
-- ENQUOTE_LITERAL below are copied from
-- rdbms/src/server/dict/sqlddl/prvtasrt.sql
-- label RDBMS_10.2.0.5.0_LINUX_100201
-- as a local implementation.
-- ###############################################

  --
  -- Enquote a string using a given quote character
  --
  function ENQUOTE_INTERNAL(Str varchar2, Quote varchar2)
           return varchar2 is
    already_quoted boolean := substr(Str, 1, 1) = Quote;
    len            binary_integer := length(Str);
    pos            binary_integer;
  begin
    -- debug
    -- dbms_output.put_line('Str: ' || Str);
    -- dbms_output.put_line('Quote: ' || Quote);

    if (already_quoted) then
      pos := 2;
      -- if the last character of this string which is supposedly already
      -- quoted is NOT the quote character, the string is clearly not
      -- quoted. Raise value error
      if (substr(Str, len, 1) <> Quote) then
        raise value_error;
      end if;
      -- we change the number of characters we need to examine to one
      -- less since we should not need to examine the last character.
      -- See the comment on raising an error when
      -- pos = len and already_quoted
      len := len - 1;
    else
      pos := 1;
    end if;
    while (pos <= len) loop
      -- debug
      --  dbms_output.put_line('pos: ' || pos || ' len: ' || len ||
      --                       ' Char: ' || substr(Str, pos, 1));
      if (substr(Str, pos, 1) = Quote) then
        -- if the current character is a quote then we have
        --   to check a couple of things

        if ((pos < len) AND (substr(Str, pos + 1, 1) = Quote)) then
          pos := pos + 1;
        else
          raise value_error;
        end if;
      end if;
      pos := pos + 1;
    end loop;
    if (already_quoted) then
      return Str;
    else
      return Quote || Str || Quote;
    end if;
  end ENQUOTE_INTERNAL;


  --
  -- ENQUOTE_LITERAL
  --
  -- Enquote a string literal.  Add leading and trailing single quotes
  -- to a string literal.  Verify that all single quotes except leading
  -- and trailing characters are paired with adjacent single quotes.
  --
  function ENQUOTE_LITERAL(Str varchar2)
           return varchar2 is
  begin
    return ENQUOTE_INTERNAL(Str, '''');
  end ENQUOTE_LITERAL;

/*
   Dummy funtion for fix Bug 12380852
*/
FUNCTION no_opp(l_ocm_dir_path IN  VARCHAR) RETURN VARCHAR IS
BEGIN
   return l_ocm_dir_path;
END no_opp;

/*
Create or replace the directory object to recreate the path based on
new ORACLE_HOME.
Notes:
  1. This procedure is executed with invoker's rights. This is needed so that
     ORACLE_OCM user does not need to be granted "execute" permission on "dbms_system" package.
     Only SYS would be able to run this procedure without error as it has the privilege to execute "dbms_system" and re-create
     the directory object ORACLE_OCM_CONFIG_DIR owned by it.
  2. This procedure is only supported on release 10g onwards.
     DBMS_SYSTEM.GET_ENV is supported 10g onwards.
     DBMS_ASSERT.ENQUOTE_LITERAL is used if the DB version is 10gR2 onwards.
  3. Starting with 12c, per bug 21456791, this procedure should only be called from the execocm.sql script.
     This procedure should not be called standalone.
     A privilege is granted in execocm.sql that is required to run this procedure.
     Contact the OCM product team if you have questions about this requirement.
*/
PROCEDURE create_replace_dir_obj IS
  -- local variables
  pfid            NUMBER;
  root            VARCHAR2(2000);
  hname           VARCHAR2(2000);
  l_ocm_dir_path  VARCHAR2(4000);
  l_ocm_dir_path2 VARCHAR2(4000);
  l_dirsep        VARCHAR2(2);
  l_vers          v$instance.version%TYPE;
  l_obh           NUMBER := 0;
  l_is_cdb        VARCHAR2(4) := 'NO';
  l_con_id        NUMBER;
BEGIN
  -- The following code was added to ensure that create_replace_dir_obj is not executed while connected
  -- to a PDB database. The associated bug number is 19792374.
  -- This next select returns information required to determine if connected to a PDB or not.
  BEGIN
    execute immediate 'SELECT UPPER(CDB), SYS_CONTEXT(''USERENV'', ''CON_ID'') FROM V$DATABASE' into l_is_cdb, l_con_id;
  EXCEPTION
    WHEN OTHERS THEN
      null;
  END;
  -- The pseudo logic is do nothing if connected to a PDB, all other scenarios run the code.
  -- YES and con_id = 1, means connected to root container.
  -- YES and con_id > 1, means connected to a PDB.
  -- NO or NULL means connected to a normal (non-container/PDB) database.
  IF l_is_cdb = 'YES' and l_con_id > 1  THEN
    -- Inside PDB, do nothing.
    NULL;
  ELSE
    -- If not connected to a PDB, then execute the code.
    -- get the platform id
    SELECT platform_id INTO pfid FROM v$database;

    IF pfid = PLATFORM_OPENVMS THEN
      -- ORA_ROOT is a VMS logical name
      l_ocm_dir_path  := 'ORA_ROOT:[ccr.state]';
      l_ocm_dir_path2 := 'ORA_ROOT:[ccr.state]';
    ELSE
      -- Determine if dbms_system.get_obh exists, count will be 1 or more if exists
      select count(*) into l_obh from all_procedures
      where owner='SYS' and procedure_name='GET_OBH' and object_name='DBMS_SYSTEM';
      IF l_obh > 0 THEN
        -- Get ORACLE_BASE_HOME
        execute immediate 'BEGIN DBMS_SYSTEM.GET_OBH(:1); END;' using out root;
      ELSE
        -- Get ORACLE_HOME
        execute immediate 'BEGIN DBMS_SYSTEM.GET_ENV(''ORACLE_HOME'', :1); END;' using out root;
      END IF;
      -- Get HOSTNAME
      execute immediate 'BEGIN DBMS_SYSTEM.GET_ENV(''HOSTNAME'', :1); END;' using out hname;
      -- Return platform-specific string
      IF pfid = PLATFORM_WINDOWS32 OR pfid = PLATFORM_WINDOWS64 OR pfid = PLATFORM_WINDOWS64AMD
      THEN
        l_dirsep := '\';
      ELSE
        l_dirsep := '/';
      END IF;

      -- If GET_OBH exists, then set path to OBH/ccr/state
      IF l_obh > 0 THEN
        l_ocm_dir_path := root || l_dirsep|| 'ccr' || l_dirsep || 'state';
      ELSE
        IF HNAME IS NULL THEN
          l_ocm_dir_path := root || l_dirsep|| 'ccr' || l_dirsep || 'state';
        ELSE
          l_ocm_dir_path := root || l_dirsep|| 'ccr' || l_dirsep || 'hosts' || l_dirsep || hname || l_dirsep || 'state';
        END IF;
      END IF;
      l_ocm_dir_path2:= root || l_dirsep|| 'ccr' || l_dirsep || 'state';

    END IF;
    select LPAD(version,10,'0') into l_vers from v$instance;
    IF l_vers < '10.2.0.0.0' THEN
        l_ocm_dir_path := ENQUOTE_LITERAL(l_ocm_dir_path);
        l_ocm_dir_path2 := ENQUOTE_LITERAL(l_ocm_dir_path2);
    ELSE
        execute immediate 'SELECT DBMS_ASSERT.ENQUOTE_LITERAL(:1) FROM DUAL' into l_ocm_dir_path using l_ocm_dir_path;
        execute immediate 'SELECT DBMS_ASSERT.ENQUOTE_LITERAL(:1) FROM DUAL' into l_ocm_dir_path2 using l_ocm_dir_path2;
    END IF;
    execute immediate 'CREATE OR REPLACE DIRECTORY ORACLE_OCM_CONFIG_DIR AS ' || no_opp(l_ocm_dir_path);
    execute immediate 'CREATE OR REPLACE DIRECTORY ORACLE_OCM_CONFIG_DIR2 AS ' || no_opp(l_ocm_dir_path2);
    COMMIT;
  END IF; -- IF connected to a PDB or not.
END create_replace_dir_obj;

END MGMT_CONFIG_UTL;
/

