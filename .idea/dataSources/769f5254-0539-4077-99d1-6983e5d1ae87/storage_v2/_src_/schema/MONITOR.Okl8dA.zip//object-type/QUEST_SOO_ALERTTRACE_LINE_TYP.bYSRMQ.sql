create TYPE           "QUEST_SOO_ALERTTRACE_LINE_TYP"                                          IS OBJECT (linedate DATE, linetext VARCHAR2(4000), filestatus NUMBER )
/

