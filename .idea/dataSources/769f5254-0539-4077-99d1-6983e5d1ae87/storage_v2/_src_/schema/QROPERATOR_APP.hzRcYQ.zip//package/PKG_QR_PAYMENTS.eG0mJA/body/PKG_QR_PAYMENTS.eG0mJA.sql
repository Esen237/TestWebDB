create PACKAGE BODY                "PKG_QR_PAYMENTS" IS
--STEP1

PROCEDURE Participant_Banks_Add (ps_bank_id              NUMBER,
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2 DEFAULT '0',
                                 pd_registration_date    DATE DEFAULT SYSDATE,
                                 pd_closing_date         DATE DEFAULT NULL,
                                 pd_closed_user         VARCHAR2 DEFAULT NULL                       
                                 ) IS 




BEGIN

 
 INSERT INTO qroperator_app.participant_banks
        (bank_id,
         bank_name,
         tax_no,
         bic,
         --bank_account,
         website,
         contact_email,
         contact_phone,
         ip,
         registration_date,
         status,
         closing_date,
         closed_user)
 VALUES(ps_bank_id,
        ps_bank_name,        
        pn_tax_no,
        pn_bic,
        ps_website,
        ps_contact_email,
        ps_contact_phone,
        ps_ip,       
        pd_registration_date,
        ps_status,
        pd_closing_date,
        pd_closed_user);  
          
 COMMIT;
 
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 

END;

PROCEDURE Participant_Banks_Update (ps_bank_id              NUMBER, --add unique constraint 
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2,
                                 pd_registration_date    DATE ,  
                                 pd_closing_date         DATE, 
                                 pd_closed_user         VARCHAR2                     
                                 ) IS 




BEGIN

 
 UPDATE qroperator_app.participant_banks
       SET 
           --bank_name=ps_bank_name,
           tax_no=pn_tax_no,
           bic=pn_bic,
           website=ps_website,
           contact_email=ps_contact_email,
           contact_phone=ps_contact_phone,
           ip=ps_ip,
--           registration_date=pd_registration_date,
           status=ps_status,
           closed_user=pd_closed_user,
           closing_date=pd_closing_date
     WHERE bank_id=ps_bank_id;
          
 COMMIT;
 
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 

END;


PROCEDURE  Participant_Apps_Add (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER , --add unique constraint 
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         NUMBER,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             pd_registration_date    DATE DEFAULT SYSDATE, 
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE DEFAULT NULL,
                             ps_closed_user          VARCHAR2 DEFAULT NULL ,
                             ps_port                 VARCHAR2                                        
                               ) IS 


BEGIN

  INSERT INTO qroperator_app.participant_apps
        (bank_id,
         app_id,
         app_name,
         app_type,
         bank_account,
         app_tax_number,
         address,
         qr_provider,
         ip_address,
         contact_email,
         contact_phone,
         status,
         registration_date,
         created_user,
         closing_date,
         closed_user,
         port )
 VALUES(pn_bank_id,
        pn_app_id,
        ps_app_name,
        ps_app_type,
        pn_bank_account,
        ps_app_tax_number,
        ps_address ,
        ps_qr_provider,
        ps_ip_address,
        ps_contact_email, 
        ps_contact_phone,
        ps_status,
        pd_registration_date,
        ps_created_user,                         
        pd_closing_date, 
        ps_closed_user,
        ps_port 
       ); 
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END;

PROCEDURE  Participant_Apps_Update (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER,
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         NUMBER,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE,
                             ps_closed_user          VARCHAR2,
                             ps_port                 VARCHAR2                                        
                               ) IS 


BEGIN

  UPDATE qroperator_app.participant_apps
     SET 
         
         --app_name=ps_app_name,
         app_type=ps_app_type,
         bank_account=pn_bank_account,
         app_tax_number=ps_app_tax_number,
         address=ps_app_tax_number,
        -- qr_provider=ps_qr_provider,
         ip_address=ps_ip_address,
         contact_email=ps_contact_email,
         contact_phone=ps_contact_phone,
         status=ps_status,
         created_user=ps_created_user,
         closing_date=pd_closing_date,
         closed_user=ps_closed_user,
         port=ps_port
   WHERE bank_id=pn_bank_id and  app_id=pn_app_id;
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END;


PROCEDURE  Bank_Limit_Setting(pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              ) IS                            
  ln_count_rec NUMBER;                            
                              
BEGIN

/*log_at('Bank_Limit_Setting',1,'pn_bank_id'||' '||pn_bank_id||' / '||
                           'pn_bank_limit'||' '||pn_bank_limit||' / '||
                         'ps_created_user'||' '||ps_created_user||' / '||
                        'pd_creation_date'||' '||pd_creation_date);*/

     SELECT COUNT(*)
        INTO ln_count_rec
         FROM qroperator_app.bank_limit_settings 
       WHERE bank_id = pn_bank_id;


 IF ln_count_rec>0 THEN
 
    INSERT INTO qroperator_app.bank_limit_settings_log
            (bank_id,
             bank_limit,
             created_user,
             creation_date,
             is_active)
    (SELECT bank_id,
            bank_limit,
            created_user,
            creation_date,
            'NO'       
    FROM qroperator_app.bank_limit_settings WHERE bank_id = pn_bank_id );


    UPDATE qroperator_app.bank_limit_settings
       SET bank_id=pn_bank_id,
           bank_limit=pn_bank_limit,
           created_user=ps_created_user,
           creation_date=pd_creation_date;
 
 ELSE
 
    INSERT INTO qroperator_app.bank_limit_settings
            (bank_id,
             bank_limit,
             created_user,
             creation_date
            )
    VALUES(pn_bank_id,
           pn_bank_limit,
           ps_created_user,
           pd_creation_date       
           );
 
 END IF;

 COMMIT;

EXCEPTION
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;


PROCEDURE  App_Limit_Setting (pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              pn_app_id              NUMBER,
                              pn_app_limit           NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              ) IS
   ln_count_rec NUMBER;                            
BEGIN

      SELECT COUNT(*)
        INTO ln_count_rec
         FROM qroperator_app.app_limit_settings 
       WHERE bank_id = pn_bank_id AND app_id=pn_app_id;
       
    

 IF ln_count_rec>0 THEN

     INSERT INTO qroperator_app.app_limit_settings_log
            (bank_id,
             bank_limit,
             app_id,
             app_limit,
             created_user,
             creation_date,
             is_active
            )
    (SELECT bank_id,
            bank_limit,
            app_id,
            app_limit,
            created_user,
            creation_date,
            'NO'  
     FROM qroperator_app.app_limit_settings  WHERE bank_id = pn_bank_id AND app_id=pn_app_id     
           );
           
     UPDATE qroperator_app.app_limit_settings
           SET bank_id=pn_bank_id,
               bank_limit=pn_bank_limit,
               app_id=pn_app_id,
               app_limit=pn_app_limit,
               created_user=ps_created_user,
               creation_date=pd_creation_date;
 ELSE
        
     INSERT INTO qroperator_app.app_limit_settings
            (bank_id,
             bank_limit,
             app_id,
             app_limit,
             created_user,
             creation_date
            )
     VALUES(pn_bank_id,
            pn_bank_limit,
            pn_app_id,
            pn_app_limit,
            ps_created_user,
            pd_creation_date       
           );
 
 END IF;

  COMMIT;

EXCEPTION
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
           
END;

PROCEDURE  App_Comission_Def (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              ps_comission_code      VARCHAR2,
                              ps_comission_rate      VARCHAR2,
                              ps_is_fix_comission    VARCHAR2,                         
                              ps_is_exemption        VARCHAR2
                              ) IS
BEGIN

 INSERT INTO qroperator_app.app_commission_def
        (bank_id,         
         app_id,
         comission_code,
         comission_rate,
         is_fix_comission,
         is_exemption
        )
 VALUES(pn_bank_id,
        pn_app_id,
        ps_comission_code,
        ps_comission_rate,
        ps_is_fix_comission,                         
        ps_is_exemption            
       );
 COMMIT;

EXCEPTION
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
           
END;


PROCEDURE  Add_App_Users (pn_bank_id             NUMBER,                        
                          ps_username            VARCHAR2,
                          ps_password            VARCHAR2,
                          pn_role                NUMBER,
                          ps_status              VARCHAR2,                         
                          ps_is_exemption        VARCHAR2,
                          ps_created_user        VARCHAR2,
                          pd_create_date         DATE DEFAULT SYSDATE,
                          ps_deactivate_user     VARCHAR2,
                          pd_deactivate_date     DATE 
                          ) IS
BEGIN

 INSERT INTO qroperator_app.remote_users
        (bank_id,
        username,
        password,
        role,
        status,
        created_user,
        create_date,
        deactivate_user,
        deactivate_date         
        )
 VALUES(pn_bank_id,                        
        ps_username,
        ps_password,
        pn_role,
        ps_status,                                
        ps_created_user,
        pd_create_date,
        ps_deactivate_user,
        pd_deactivate_date             
       );

 COMMIT;
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;


PROCEDURE  Update_App_Users (pn_bank_id             NUMBER,                        
                             ps_username            VARCHAR2,
                             --ps_password            VARCHAR2,
                             pn_role                NUMBER,
                             ps_status              VARCHAR2,                                                   
                             ps_deactivate_user     VARCHAR2,
                             pd_deactivate_date     DATE,
                             ps_force_password       VARCHAR2 DEFAULT 'YES'
                          ) IS
BEGIN

 UPDATE qroperator_app.remote_users
     SET 
        --password=ps_password,
        role=pn_role,
        status=ps_status,        
        deactivate_user=ps_deactivate_user,
        deactivate_date=pd_deactivate_date,
        force_password = ps_force_password     
 WHERE username=ps_username AND bank_id=pn_bank_id;  

 COMMIT;
 
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;


PROCEDURE  Eod_Daily_Transactions IS

ls_expl VARCHAR2(200);
ls_ist_code VARCHAR2(200);
ls_code VARCHAR2(200);
ls_expl_1 VARCHAR2(2000);

CURSOR c1_eod_daily_transactions IS 
    SELECT *
    FROM qroperator_app.transactions
 WHERE execute_process_time >=SYSDATE-1 AND execute_process_time < SYSDATE AND execute_status='50';

r_c1_eod_daily_transactions c1_eod_daily_transactions%ROWTYPE;

ls_tag varchar2(2000);
ln_count number;

BEGIN

   LOOP
       FETCH c1_eod_daily_transactions INTO r_c1_eod_daily_transactions;
       EXIT WHEN c1_eod_daily_transactions%NOTFOUND; 
 
        INSERT INTO qroperator_app.eod_daily_transactions      
          (operator_transaction_id,  
           bank_date ,
           bank_bic,
           bank_id,
           app_id,
           app_name,
           app_bank_account,
           transaction_type ,
           amount,
           comission,
           db_cr_flag ,
           original_receipt_id ,
           execute_request_time,
           execute_process_time,
           status ,
           is_our_network,
           is_internal)

        VALUES
           (r_c1_eod_daily_transactions.operator_transaction_id,--индекс
            trunc(SYSDATE-1),
            r_c1_eod_daily_transactions.sender_bank_bic,
            pkg_qr_payments.Get_Bank_ID_By_App(r_c1_eod_daily_transactions.sender_app_id),--r_c1_eod_daily_transactions.bank_id,--найти по app_id          с  participant apps
            r_c1_eod_daily_transactions.sender_app_id,
            pkg_qr_payments.Get_App_Name_By_App(r_c1_eod_daily_transactions.sender_app_id),-- r_c1_eod_daily_transactions.app_name,--найти по app_id       с     participant apps    
            pkg_qr_payments.Get_Bank_Account_By_App(r_c1_eod_daily_transactions.sender_app_id),-- r_c1_eod_daily_transactions.app_bank_account,--найти по app_id       с     participant apps
            r_c1_eod_daily_transactions.transaction_type,
            r_c1_eod_daily_transactions.qr_amount,
            r_c1_eod_daily_transactions.comission,
            'DT',--r_c1_eod_daily_transactions.db_cr_flag,--вручную DT или CR
            r_c1_eod_daily_transactions.sender_receipt_no,   
            r_c1_eod_daily_transactions.execute_request_time,
            r_c1_eod_daily_transactions.execute_process_time,
            r_c1_eod_daily_transactions.execute_status,
            r_c1_eod_daily_transactions.is_our_network,
            pkg_qr_payments.Is_Internal(r_c1_eod_daily_transactions.sender_bank_bic,  r_c1_eod_daily_transactions.beneficiary_bank_bic)
           -- r_c1_eod_daily_transactions.is_internal--через функ YES NO
            );
         

        INSERT INTO qroperator_app.eod_daily_transactions      
          (operator_transaction_id,  
           bank_date ,
           bank_bic,
           bank_id,
           app_id,
           app_name,
           app_bank_account,
           transaction_type ,
           amount,
           comission,
           db_cr_flag ,
           original_receipt_id ,
           execute_request_time,
           execute_process_time,
           status ,
           is_our_network,
           is_internal)

        VALUES
           (r_c1_eod_daily_transactions.operator_transaction_id,--индекс
            TRUNC(SYSDATE-1),
            r_c1_eod_daily_transactions.beneficiary_bank_bic,
            pkg_qr_payments.Get_Bank_ID_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),--r_c1_eod_daily_transactions.bank_id,--найти по app_id          с  participant apps
            r_c1_eod_daily_transactions.beneficiary_app_id,
            pkg_qr_payments.Get_App_Name_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),-- r_c1_eod_daily_transactions.app_name,--найти по app_id       с     participant apps    
            pkg_qr_payments.Get_Bank_Account_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),-- r_c1_eod_daily_transactions.app_bank_account,--найти по app_id       с     participant apps
            r_c1_eod_daily_transactions.transaction_type,
            r_c1_eod_daily_transactions.qr_amount,
            r_c1_eod_daily_transactions.comission,
            'CR',--r_c1_eod_daily_transactions.db_cr_flag,--вручную DT или CR
            r_c1_eod_daily_transactions.ben_receipt_no,   
            r_c1_eod_daily_transactions.execute_request_time,
            r_c1_eod_daily_transactions.execute_process_time,
            r_c1_eod_daily_transactions.execute_status,
            r_c1_eod_daily_transactions.is_our_network,
            pkg_qr_payments.Is_Internal(r_c1_eod_daily_transactions.sender_bank_bic,  r_c1_eod_daily_transactions.beneficiary_bank_bic)
           -- r_c1_eod_daily_transactions.is_internal--через функ YES NO
            );  
    
    
    END LOOP;
CLOSE c1_eod_daily_transactions;
COMMIT;
END;

FUNCTION Get_Bank_ID_By_App (pn_app_id NUMBER) RETURN NUMBER IS

ln_bank_id NUMBER;
  
  BEGIN
  
   SELECT bank_id 
     INTO  ln_bank_id
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;
  
  RETURN ln_bank_id; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;

FUNCTION Get_App_Name_By_App (pn_app_id NUMBER) RETURN VARCHAR IS

ls_app_name VARCHAR2(200 BYTE);
  
  BEGIN
  
     SELECT app_name 
     INTO  ls_app_name
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;

  RETURN ls_app_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;


FUNCTION Get_Bank_Account_By_App (pn_app_id NUMBER) RETURN NUMBER IS

ln_bank_account VARCHAR2(200 BYTE);
  
  BEGIN
  
     SELECT bank_account 
     INTO  ln_bank_account
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;

  RETURN ln_bank_account; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;

PROCEDURE  QR_Transactions (pn_sender_bank_bic             NUMBER,
                            pn_sender_app_id               NUMBER,
                            pn_sender_customer_type        NUMBER,
                            pn_sender_transaction_no       NUMBER,
                            pn_sender_receipt_no           NUMBER,
                            pn_transaction_type            NUMBER,
                            ps_qr_type                     VARCHAR2,
                            ps_qr_merchant_provider        VARCHAR2,
                            ps_qr_merchant_id              VARCHAR2,
                            ps_qr_service_id               VARCHAR2,
                            ps_qr_service_name             VARCHAR2,
                            pn_qr_ben_account_number       NUMBER,
                            pn_qr_merchant_code            NUMBER,
                            pn_qr_currency_code            NUMBER,
                            pn_qr_transaction_id           NUMBER,
                            ps_qr_comment                  VARCHAR2,
                            pn_qr_amount                   NUMBER,
                            pn_comission                   NUMBER, 
                            ps_qr_link_hash                VARCHAR2, 
                            pd_create_request_time         DATE                 DEFAULT SYSDATE,
                            pn_beneficiary_bank_bic        NUMBER,
                            pn_beneficiary_app_id          NUMBER,
                            ps_beneficiary_name            VARCHAR2,
                            pn_ben_customer_type           NUMBER,
                            pn_ben_receipt_no              NUMBER,
                            pd_create_response_time        DATE,
                            pn_create_status               NUMBER,
                            pd_execute_request_time        DATE,
                            pd_execute_process_time        DATE,
                            pd_error_time                  DATE,
                            pd_execute_status              NUMBER,
                            ps_is_our_network              VARCHAR2                       
                               ) IS 


BEGIN

   INSERT INTO qroperator_app.transactions 
     (operator_transaction_id,
      sender_bank_bic,
      sender_app_id,
      sender_customer_type,
      sender_transaction_no,
      sender_receipt_no,
      transaction_type,
      qr_type,
      qr_merchant_provider,
      qr_merchant_id,
      qr_service_id,
      qr_service_name,
      qr_ben_account_number,
      qr_merchant_code,
      qr_currency_code,
      qr_transaction_id,
      qr_comment,
      qr_amount,
      comission,
      qr_link_hash,
      create_request_time,
      beneficiary_bank_bic,
      beneficiary_app_id,
      beneficiary_name ,
      ben_customer_type ,
      ben_receipt_no,
      create_response_time,
      create_status,
      execute_request_time,
      execute_process_time,
      error_time,
      execute_status,
      is_our_network)
      
   VALUES(SYS_GUID(),
          pn_sender_bank_bic,
          pn_sender_app_id,
          pn_sender_customer_type ,
          pn_sender_transaction_no,
          pn_sender_receipt_no,
          pn_transaction_type,
          ps_qr_type ,
          ps_qr_merchant_provider,
          ps_qr_merchant_id,
          ps_qr_service_id,
          ps_qr_service_name,
          pn_qr_ben_account_number ,
          pn_qr_merchant_code,
          pn_qr_currency_code,
          pn_qr_transaction_id,
          ps_qr_comment,
          pn_qr_amount ,
          pn_comission, 
          ps_qr_link_hash, 
          pd_create_request_time,
          pn_beneficiary_bank_bic,
          pn_beneficiary_app_id ,
          ps_beneficiary_name,
          pn_ben_customer_type,
          pn_ben_receipt_no ,
          pd_create_response_time ,
          pn_create_status,
          pd_execute_request_time,
          pd_execute_process_time,
          pd_error_time,
          pd_execute_status,
          ps_is_our_network);
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 

PROCEDURE  QR_Check_Transactions (pn_sender_app_id              NUMBER,
                                  pn_sender_customer_type       NUMBER,
                                  ps_qr_type                    VARCHAR2,
                                  ps_qr_merchant_provider       VARCHAR2,
                                  ps_qr_merchant_id             VARCHAR2,
                                  ps_qr_service_id              VARCHAR2,
                                  ps_qr_service_name            VARCHAR2,
                                  pn_qr_ben_account_number      NUMBER,
                                  pn_qr_merchant_code           NUMBER,
                                  pn_qr_currency_code           NUMBER,
                                  pn_qr_transaction_id          NUMBER,
                                  ps_qr_comment                 VARCHAR2,
                                  pn_qr_amount                  NUMBER,
                                  ps_qr_link_hash               VARCHAR2,
                                  pd_requested_date             DATE ,
                                  pn_beneficiary_app_id_number  NUMBER,
                                  ps_beneficiary_name           VARCHAR2,
                                  pn_ben_customer_type          NUMBER,
                                  pn_operator_tran_type         NUMBER,
                                  pn_check_status               NUMBER,
                                  pd_response_date              DATE            
                               ) IS 


BEGIN

   INSERT INTO qroperator_app.check_transactions 
                          (operator_request_id,
                           sender_app_id,
                           sender_customer_type,
                           qr_type,
                           qr_merchant_provider,
                           qr_merchant_id ,
                           qr_service_id,
                           qr_service_name,
                           qr_ben_account_number ,
                           qr_merchant_code,
                           qr_currency_code ,
                           qr_transaction_id,
                           qr_comment,
                           qr_amount  ,
                           qr_link_hash  ,
                           requested_date    ,
                           beneficiary_app_id_number ,
                           beneficiary_name  ,
                           ben_customer_type,
                           operator_tran_type,
                           check_status     ,
                           response_date )
      
                   VALUES(corpint.pkg_common.getsequenceid('sqQR_TRX'),--pn_operator_request_id,
                          pn_sender_app_id,
                          pn_sender_customer_type,
                          ps_qr_type ,
                          ps_qr_merchant_provider,
                          ps_qr_merchant_id,
                          ps_qr_service_id,
                          ps_qr_service_name ,
                          pn_qr_ben_account_number,
                          pn_qr_merchant_code,
                          pn_qr_currency_code,
                          pn_qr_transaction_id,
                          ps_qr_comment,
                          pn_qr_amount,
                          ps_qr_link_hash ,
                          pd_requested_date,
                          pn_beneficiary_app_id_number,
                          ps_beneficiary_name ,
                          pn_ben_customer_type ,
                          pn_operator_tran_type ,
                          pn_check_status ,
                          pd_response_date );
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 

FUNCTION Is_Internal (pn_sender_bic NUMBER, pn_beneficiary_bic NUMBER) RETURN VARCHAR IS

ln_bank_account VARCHAR2(200 BYTE);
  
  BEGIN
  
     IF SUBSTR(pn_sender_bic,1,6)=118000 AND SUBSTR(pn_beneficiary_bic,1,6)=118000 THEN
        RETURN 'YES';
     ELSE 
        RETURN 'NO';
     END IF;
  
      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;

BEGIN
--STEP2
    Null;
End;
/

