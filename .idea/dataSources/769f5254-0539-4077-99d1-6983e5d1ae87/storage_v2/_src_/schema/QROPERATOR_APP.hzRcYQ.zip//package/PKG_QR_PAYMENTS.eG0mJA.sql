create PACKAGE                "PKG_QR_PAYMENTS" IS

PROCEDURE Participant_Banks_Add (ps_bank_id              NUMBER,
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2 DEFAULT '0',
                                 pd_registration_date    DATE DEFAULT SYSDATE,
                                 pd_closing_date         DATE DEFAULT NULL,
                                 pd_closed_user         VARCHAR2 DEFAULT NULL                       
                                 ) ;
PROCEDURE Participant_Banks_Update (ps_bank_id              NUMBER,
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2,
                                 pd_registration_date    DATE,
                                 pd_closing_date         DATE,
                                 pd_closed_user         VARCHAR2                              
                                 );                                
                               
PROCEDURE  Participant_Apps_Add (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER,
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         NUMBER,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             pd_registration_date    DATE DEFAULT SYSDATE, 
                             ps_created_user         VARCHAR2 ,                         
                             pd_closing_date         DATE DEFAULT NULL,
                             ps_closed_user          VARCHAR2 DEFAULT NULL,
                             ps_port                 VARCHAR2                                       
                               );
PROCEDURE  Participant_Apps_Update (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER,
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         NUMBER,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,                            
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE,
                             ps_closed_user          VARCHAR2,
                             ps_port                 VARCHAR2                                        
                               );                                                                                
PROCEDURE  Bank_Limit_Setting(pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              ); 
PROCEDURE  App_Limit_Setting (pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              pn_app_id              NUMBER,
                              pn_app_limit           NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              );                              
PROCEDURE  App_Comission_Def (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              ps_comission_code      VARCHAR2,
                              ps_comission_rate      VARCHAR2,
                              ps_is_fix_comission    VARCHAR2,                         
                              ps_is_exemption        VARCHAR2
                              );                             
PROCEDURE  Add_App_Users (pn_bank_id             NUMBER,                        
                          ps_username            VARCHAR2,
                          ps_password            VARCHAR2,
                          pn_role                NUMBER,
                          ps_status              VARCHAR2,                         
                          ps_is_exemption        VARCHAR2,
                          ps_created_user        VARCHAR2,
                          pd_create_date         DATE DEFAULT SYSDATE,
                          ps_deactivate_user     VARCHAR2,
                          pd_deactivate_date     DATE 
                          ); 
PROCEDURE  Update_App_Users (pn_bank_id             NUMBER,                        
                             ps_username            VARCHAR2,
                             --ps_password            VARCHAR2,
                             pn_role                NUMBER,
                             ps_status              VARCHAR2,                                                   
                             ps_deactivate_user     VARCHAR2,
                             pd_deactivate_date     DATE,
                             ps_force_password       VARCHAR2 DEFAULT 'YES'
                          );                                                                                     
PROCEDURE  Eod_Daily_Transactions;
FUNCTION Get_Bank_ID_By_App (pn_app_id NUMBER) RETURN NUMBER;
FUNCTION Get_App_Name_By_App (pn_app_id NUMBER) RETURN VARCHAR;   
FUNCTION Get_Bank_Account_By_App (pn_app_id NUMBER) RETURN NUMBER;  
PROCEDURE  QR_Transactions (pn_sender_bank_bic             NUMBER,
                            pn_sender_app_id               NUMBER,
                            pn_sender_customer_type        NUMBER,
                            pn_sender_transaction_no       NUMBER,
                            pn_sender_receipt_no           NUMBER,
                            pn_transaction_type            NUMBER,
                            ps_qr_type                     VARCHAR2,
                            ps_qr_merchant_provider        VARCHAR2,
                            ps_qr_merchant_id              VARCHAR2,
                            ps_qr_service_id               VARCHAR2,
                            ps_qr_service_name             VARCHAR2,
                            pn_qr_ben_account_number       NUMBER,
                            pn_qr_merchant_code            NUMBER,
                            pn_qr_currency_code            NUMBER,
                            pn_qr_transaction_id           NUMBER,
                            ps_qr_comment                  VARCHAR2,
                            pn_qr_amount                   NUMBER,
                            pn_comission                   NUMBER, 
                            ps_qr_link_hash                VARCHAR2, 
                            pd_create_request_time         DATE                 DEFAULT SYSDATE,
                            pn_beneficiary_bank_bic        NUMBER,
                            pn_beneficiary_app_id          NUMBER,
                            ps_beneficiary_name            VARCHAR2,
                            pn_ben_customer_type           NUMBER,
                            pn_ben_receipt_no              NUMBER,
                            pd_create_response_time        DATE,
                            pn_create_status               NUMBER,
                            pd_execute_request_time        DATE,
                            pd_execute_process_time        DATE,
                            pd_error_time                  DATE,
                            pd_execute_status              NUMBER,
                            ps_is_our_network              VARCHAR2                       
                               );  
PROCEDURE  QR_Check_Transactions (pn_sender_app_id              NUMBER,
                                  pn_sender_customer_type       NUMBER,
                                  ps_qr_type                    VARCHAR2,
                                  ps_qr_merchant_provider       VARCHAR2,
                                  ps_qr_merchant_id             VARCHAR2,
                                  ps_qr_service_id              VARCHAR2,
                                  ps_qr_service_name            VARCHAR2,
                                  pn_qr_ben_account_number      NUMBER,
                                  pn_qr_merchant_code           NUMBER,
                                  pn_qr_currency_code           NUMBER,
                                  pn_qr_transaction_id          NUMBER,
                                  ps_qr_comment                 VARCHAR2,
                                  pn_qr_amount                  NUMBER,
                                  ps_qr_link_hash               VARCHAR2,
                                  pd_requested_date             DATE ,
                                  pn_beneficiary_app_id_number  NUMBER,
                                  ps_beneficiary_name           VARCHAR2,
                                  pn_ben_customer_type          NUMBER,
                                  pn_operator_tran_type         NUMBER,
                                  pn_check_status               NUMBER,
                                  pd_response_date              DATE            
                               ); 
FUNCTION Is_Internal (pn_sender_bic NUMBER, pn_beneficiary_bic NUMBER) RETURN VARCHAR;                              
                               
  END;
/

