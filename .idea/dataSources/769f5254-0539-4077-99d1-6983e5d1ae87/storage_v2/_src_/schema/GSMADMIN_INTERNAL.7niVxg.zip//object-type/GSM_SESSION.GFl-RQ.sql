create TYPE gsm_session IS OBJECT (
   sessionid        NUMBER,    -- session id
   gsmname          VARCHAR2(256)  -- gsm name
);
/

