create TYPE t_shdcol_row AS OBJECT (
  col_cnt               number,
  position              number,
  col_name              VARCHAR2(128)
)
/

