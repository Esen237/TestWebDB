create PACKAGE dbms_gsm_nopriv
AUTHID CURRENT_USER AS

--*****************************************************************************
-- NOTE: This package is executeable by public. We *MUST* ensure that the
-- calling user has the correct catalog privileges at the start of every
-- procedure before executing any other code with the package.
--*****************************************************************************


--*****************************************************************************
-- Package Public Types
--*****************************************************************************

-- Update modes for catalog lock
noUpdate constant  number := 0;  -- catalog is not updated
updNoGSM constant  number := 1;  -- catalog Update does not require running GSM
updGSM   constant  number := 2;  -- catalog update requires running GSM

--*****************************************************************************
-- Package Public Constants
--*****************************************************************************

--*****************************************************************************
-- Package Public Exceptions
--*****************************************************************************


--*****************************************************************************
-- Package Public Procedures
--*****************************************************************************
-------------------------------------------------------------------------------
--
-- PROCEDURE     getCatalogLock
--
-- Description:
--       Gets the catalog lock prior to making a change to the cloud catalog.
--
-- Parameters:
--       currentChangeSeq -    The current value of cloud.change_seq#
--                             This is the sequence # of the last committed
--                             change.
--       privs                 Privilege required for this lock operation
--       gdsctl_version        Version of gdsctl (GDSCTL interface only)
--       gsm_version           Version of GSM (GSM interface only)
--       gsm_name              Name of GSM (GSM interface only)
--       catalog_version       Version of the catalog
--
-- Notes:
--       WARNING: This function is executabble by "public" and runs with
--       gsmadmin_internal privileges. It *MUST* check that the real calling
--       session user has the privilege to peform catalog operations first
--       (before anything else is done). The "privs" and "pool_name"
--       parameters provide the require privileges for the current "lock"
--       operation. The sequence of events is that the user "locks" the catalog,
--       performs the desired operation, and then unlocks the catalog
--
-------------------------------------------------------------------------------

GSMAdmin                    constant    number := 1;
GSMPoolAdmin                constant    number := 2;

-- overloaded old version for backwards compatibility
PROCEDURE getCatalogLock( currentChangeSeq OUT number,
                          privs IN number default GSMAdmin);
-- version called by GDSCTL
PROCEDURE getCatalogLock( currentChangeSeq OUT    number,
                          privs            IN     number default GSMAdmin,
                          gdsctl_version   IN     varchar2 default NULL,
                          catalog_version  OUT    number,
                          update_mode      IN     number
                               default updNoGSM);
-- version called by GSM servers
PROCEDURE getCatalogLock( currentChangeSeq OUT    number,
                          privs            IN     number default GSMAdmin,
                          gsm_version      IN     varchar2 default NULL,
                          gsm_name         IN     varchar2 default NULL,
                          catalog_version  OUT    number,
                          update_mode      IN     number
                               default noUpdate);

-------------------------------------------------------------------------------
--
-- PROCEDURE     releaseCatalogLock
--
-- Description:
--      Releases the catalog lock and commits or rolls back the changes
--      made under the lock.
--
-- Parameters:
--      action:  "releaseLockCommit" -> release lock and commit all
--                             changes
--               "releaseLockRollback" -> release lock and rollback
--                             all changes
--      changeSeq: If "action" = "releaseLockCommit" this is the change
--                 sequence number of the the last change made under this lock.
--                 If "action" = "releaseLockRollback" then will be set to 0.
--
--
-- Notes:
--
-------------------------------------------------------------------------------

releaseLockCommit           constant  number := 1;
releaseLockRollback         constant  number := 2;


PROCEDURE releaseCatalogLock( action    IN number default releaseLockCommit,
                              changeSeq OUT number );


END dbms_gsm_nopriv;
/

