create PACKAGE dbms_gsm_xdb AUTHID CURRENT_USER AS

--*****************************************************************************
-- NOTE: This package is executable by GSM admins in order for GDSCTL
--       to set the XDB port during 'create shardcatalog'.  It runs as
--       an invoker's rights package.
--*****************************************************************************

--*****************************************************************************
-- Package Public Procedures
--*****************************************************************************
-------------------------------------------------------------------------------
--
-- PROCEDURE     setXDBPort
--
-- Description:
--       Set the XDB port for the Scheduler Agent using
--       DBMS_XDB_CONFIG.SETHTTPPORT()
--
-- Parameters:
--       agent_port            Port number for XDB to use.  If NULL and
--                             not current value is set, then will
--                             default to 8080.
--
-------------------------------------------------------------------------------

PROCEDURE setXDBPort(agent_port IN number default NULL);

END dbms_gsm_xdb;
/

