create view DBA_DV_USER_PRIVS (USERNAME, ACCESS_TYPE, PRIVILEGE, OWNER, OBJECT_NAME) as
SELECT
      dbu.name
    , decode(ue.name,dbu.name,'DIRECT',ue.name)
    , tpm.name
    , u.name
    , o.name
FROM sys.objauth$ oa,
    sys.obj$ o,
    sys."_BASE_USER" u,
    sys."_BASE_USER" ue,
    sys."_BASE_USER" dbu,
    sys.table_privilege_map tpm
WHERE oa.obj# = o.obj#
  AND oa.col# IS NULL
  AND oa.privilege# = tpm.privilege
  AND u.user# = o.owner#
  AND oa.grantee# = ue.user#
  AND dbu.type# = 1
  AND (oa.grantee# = dbu.user#
        or
       oa.grantee# in (SELECT /*+ connect_by_filtering */ DISTINCT privilege#
                        FROM (select * from sys.sysauth$ where privilege#>0)
                        CONNECT BY grantee#=prior privilege#
                        START WITH grantee#=dbu.user#))
/

