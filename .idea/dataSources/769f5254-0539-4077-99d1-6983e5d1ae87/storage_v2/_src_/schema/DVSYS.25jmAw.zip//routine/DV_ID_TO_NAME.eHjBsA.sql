create function       dv_id_to_name (A   in dvsys.simulation_ids,
                                                dv_obj_type in pls_integer)
return dvsys.dv_obj_name as
name_list dv_obj_name := dv_obj_name();
i         integer := 0;
dv_name   varchar2(128);
stmt      varchar2(50);
begin
  IF (A.count > 0) THEN

    -- Set Execute Statement
    IF (dv_obj_type = 1) THEN -- Realm
      stmt := 'SELECT name FROM dvsys.dv$realm where id# = :1';
    ELSIF (dv_obj_type = 2) THEN -- Rule Set
      stmt := 'SELECT name FROM dvsys.dv$rule_set where id# = :1';
    ELSE
      raise_application_error(-20000,
                              'invalid input value for parameter dv_obj_type');
    END IF;

    FOR i in 1..A.count LOOP
      name_list.extend;
      EXECUTE IMMEDIATE stmt INTO dv_name USING IN A(i);
      name_list(i) := dv_name;
    END LOOP;
  END IF;
  RETURN name_list;
end;
/

