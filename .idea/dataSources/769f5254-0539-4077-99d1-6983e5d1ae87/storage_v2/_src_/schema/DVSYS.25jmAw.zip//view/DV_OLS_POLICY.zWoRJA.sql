create view DV$OLS_POLICY as
SELECT
     d1.pol#
    , d1.pol_name
FROM
    lbacsys.ols$pol d1
/

