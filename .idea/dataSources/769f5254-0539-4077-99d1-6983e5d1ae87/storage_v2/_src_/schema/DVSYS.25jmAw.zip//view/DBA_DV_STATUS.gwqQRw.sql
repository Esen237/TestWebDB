create view DBA_DV_STATUS as
select 'DV_CONFIGURE_STATUS' as name,
       DECODE(status, '1', 'TRUE', 'FALSE') as status
from dvsys.config$
union
select 'DV_ENABLE_STATUS' AS name, value AS status
from sys.v_$option
where parameter = 'Oracle Database Vault'
union
(
  select 'DV_APP_PROTECTION' as name,
         DECODE(status, 1, 'ENABLED', 'DISABLED') as status
  from dvsys.status$
  where type = 1
  union all
  select 'DV_APP_PROTECTION' as name,
         'NOT CONFIGURED' as status
  from sys.dual
  where not exists (select * from dvsys.status$ where type=1)
)
/

