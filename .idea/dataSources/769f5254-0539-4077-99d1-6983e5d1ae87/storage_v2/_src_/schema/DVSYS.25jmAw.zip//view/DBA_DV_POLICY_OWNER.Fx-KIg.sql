create view DBA_DV_POLICY_OWNER as
SELECT
    p.name
  , u.username
FROM dvsys.policy_t$ p, dvsys.policy_owner$ po, sys.dba_users u
WHERE
  p.id# = po.policy_id# AND po.owner_id# = u.user_id AND
  p.language = DVSYS.dvlang(p.id#, 7)
/

