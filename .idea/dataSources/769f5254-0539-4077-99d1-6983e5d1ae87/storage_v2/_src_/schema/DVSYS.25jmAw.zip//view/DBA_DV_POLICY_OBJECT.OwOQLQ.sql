create view DBA_DV_POLICY_OBJECT
            (POLICY_NAME, OBJECT_TYPE, REALM_NAME, COMMAND, COMMAND_OBJ_OWNER, COMMAND_OBJ_NAME, COMMAND_CLAUSE,
             COMMAND_PARAMETER, COMMAND_EVENT, COMMAND_COMPONENT, COMMAND_ACTION, COMMON, INHERITED)
as
SELECT
    p.name
  , decode(po.object_type, 1, 'REALM',
                           2, 'COMMAND RULE')
  , case when po.object_type = 1
           then (select r.name
                 from dvsys.dv$realm r
                 where r.id# = po.object_id#)
         else NULL
    end
  , case when po.object_type = 2
           then (select c.command
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.object_owner
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.object_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.clause_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.parameter_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.event_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.component_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 2
           then (select c.action_name
                 from dvsys.dba_dv_command_rule_id c
                 where c.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 1
           then (select r.common
                 from dvsys.dv$realm r
                 where r.id# = po.object_id#)
         else NULL
     end
  , case when po.object_type = 1
           then (select r.inherited
                 from dvsys.dv$realm r
                 where r.id# = po.object_id#)
         else NULL
     end
FROM dvsys.policy_t$ p, dvsys.policy_object$ po
WHERE
  p.id# = po.policy_id# AND p.language = DVSYS.dvlang(p.id#, 7)
/

