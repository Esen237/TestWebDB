create type       ku$_dv_auth_dp_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  oidval        raw(16),                                       /* unique id */
  grantee_name  varchar2(128),                           /* name of grantee */
  schema_name   varchar2(128),                    /* name of granted schema */
  object_name   varchar2(128),                    /* name of granted object */
  action        varchar2(30)                           /* authorized action */
)
/

