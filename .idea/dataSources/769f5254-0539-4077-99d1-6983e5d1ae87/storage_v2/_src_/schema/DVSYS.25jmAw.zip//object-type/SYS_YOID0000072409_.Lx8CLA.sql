create type         "SYS_YOID0000072409$"              as object( "SYS_NC00001$" RAW(16))
/

