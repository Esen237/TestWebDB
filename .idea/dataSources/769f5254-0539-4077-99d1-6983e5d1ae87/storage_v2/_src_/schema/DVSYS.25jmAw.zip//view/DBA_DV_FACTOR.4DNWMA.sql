create view DBA_DV_FACTOR
            (NAME, DESCRIPTION, FACTOR_TYPE_NAME, ASSIGN_RULE_SET_NAME, GET_EXPR, VALIDATE_EXPR, IDENTIFIED_BY,
             IDENTIFIED_BY_MEANING, NAMESPACE, NAMESPACE_ATTRIBUTE, LABELED_BY, LABELED_BY_MEANING, EVAL_OPTIONS,
             EVAL_OPTIONS_MEANING, AUDIT_OPTIONS, FAIL_OPTIONS, FAIL_OPTIONS_MEANING, ID#, ORACLE_SUPPLIED)
as
SELECT
      m.name
    , d.description
    , dft.name
    , drs.name
    , m.get_expr
    , m.validate_expr
    , m.identified_by
    , did.value
    , m.namespace
    , m.namespace_attribute
    , m.labeled_by
    , dlabel.value
    , m.eval_options
    , deval.value
    , m.audit_options
    , m.fail_options
    , dfail.value
    , m.id#
    , CASE WHEN m.id# < 5000 THEN 'YES' ELSE 'NO' END
FROM dvsys.factor$ m
    , dvsys.factor_t$ d
    , dvsys.dv$factor_type dft
    , dvsys.dv$rule_set drs
    , dvsys.dv$code did
    , dvsys.dv$code dlabel
    , dvsys.dv$code deval
    , dvsys.dv$code dfail
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 2)
    AND dft.id# = m.factor_type_id#
    AND did.code    = TO_CHAR(m.identified_by)  and did.code_group = 'FACTOR_IDENTIFY'
    AND dlabel.code = TO_CHAR(m.labeled_by)  and dlabel.code_group = 'FACTOR_LABEL'
    AND deval.code  = TO_CHAR(m.eval_options) and deval.code_group = 'FACTOR_EVALUATE'
    AND dfail.code  = TO_CHAR(m.fail_options) and dfail.code_group = 'FACTOR_FAIL'
    AND drs.id#  (+)= m.assign_rule_set_id#
/

