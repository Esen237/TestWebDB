create type         "SYS_YOID0000072397$"              as object( "SYS_NC00001$" RAW(16))
/

