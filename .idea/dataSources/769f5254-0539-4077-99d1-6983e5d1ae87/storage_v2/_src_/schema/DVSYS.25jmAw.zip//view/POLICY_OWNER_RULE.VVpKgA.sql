create view POLICY_OWNER_RULE (NAME, RULE_EXPR, ID#, ORACLE_SUPPLIED) as
SELECT
      d.name
    , m.rule_expr
    , m.id#
    , CASE WHEN (m.id# < 5000)
           THEN 'YES'
           ELSE 'NO'
      END
FROM dvsys.rule$ m, dvsys.rule_t$ d
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 4)
    AND name in (SELECT porsr.rule_name
                 FROM dvsys.policy_owner_rule_set_rule porsr)
/

