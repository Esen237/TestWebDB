create FUNCTION       get_trust_level_for_identity(p_factor IN VARCHAR2,
                           p_identity IN VARCHAR2) RETURN NUMBER
IS
BEGIN
  RETURN dvsys.dbms_macsec.get_trust_level(p_factor => p_factor, p_identity => p_identity);
END;
/

