create view DBA_DV_DATAPUMP_AUTH as
SELECT
    u1.name
  , u2.name
  , da.object_name
  , da.object_type
  , da.action
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1,
     sys."_BASE_USER" u2
WHERE da.grant_type = 'DATAPUMP' and da.grantee_id = u1.user# and
      da.object_owner_id = u2.user#
UNION
SELECT
    u1.name
  , '%'
  , da.object_name
  , da.object_type
  , da.action
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1
WHERE da.grant_type = 'DATAPUMP' and da.grantee_id = u1.user# and
      da.object_owner_id = 2147483636
/

