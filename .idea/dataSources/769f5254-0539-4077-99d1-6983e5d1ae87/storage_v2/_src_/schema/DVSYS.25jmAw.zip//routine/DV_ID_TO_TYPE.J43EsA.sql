create function       dv_id_to_type (A in dvsys.simulation_ids)
return VARCHAR2 as
i         integer := 0;
rlm_type  VARCHAR2(9) := NULL;
begin
  IF (A.count > 0) THEN
    SELECT realm_type INTO rlm_type FROM dba_dv_realm
    WHERE id# = A(1);
  END IF;
  RETURN rlm_type;
end;
/

