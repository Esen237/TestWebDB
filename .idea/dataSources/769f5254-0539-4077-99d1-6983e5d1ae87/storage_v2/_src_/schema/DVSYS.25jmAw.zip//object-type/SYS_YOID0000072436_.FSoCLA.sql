create type         "SYS_YOID0000072436$"              as object( "SYS_NC00001$" VARCHAR2(8 BYTE))
/

