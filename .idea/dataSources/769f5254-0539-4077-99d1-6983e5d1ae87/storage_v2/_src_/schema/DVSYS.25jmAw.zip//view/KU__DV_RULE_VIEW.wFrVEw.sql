create view KU$_DV_RULE_VIEW (VERS_MAJOR, VERS_MINOR, RULE_NAME, RULE_EXPR, LANGUAGE, SCOPE) as
select '0','0',
          rult.name,
          rul.rule_expr,
          rult.language,
          decode(rul.scope, 1, 1,
                            2, 2,
                            3, 2)
  from    dvsys.rule$                   rul,
          dvsys.rule_t$                 rult
  where   rul.id# = rult.id#
    and   rul.id# >= 5000
    and   rul.id# not in (select rule_id#
                            from dvsys.rule_set_rule$
                           where rule_set_id# = 8)
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

