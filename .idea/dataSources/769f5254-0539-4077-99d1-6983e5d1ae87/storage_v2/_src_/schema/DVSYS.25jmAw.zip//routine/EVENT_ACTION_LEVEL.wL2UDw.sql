create function       EVENT_ACTION_LEVEL return VARCHAR2 as
begin
  return TO_NUMBER(SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'EVENT_ACTION_LEVEL'));
end;
/

