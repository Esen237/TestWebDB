create view KU$_DV_POLICY_OWNER_V (VERS_MAJOR, VERS_MINOR, POLICY_NAME, OWNER_NAME) as
select '0','0',
          pov.policy_name,
          pov.policy_owner
  from    dvsys.dba_dv_policy_owner pov
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

