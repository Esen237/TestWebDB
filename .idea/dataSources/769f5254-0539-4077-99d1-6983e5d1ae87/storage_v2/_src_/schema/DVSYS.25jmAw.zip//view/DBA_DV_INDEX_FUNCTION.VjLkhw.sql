create view DBA_DV_INDEX_FUNCTION as
SELECT
    object_name
FROM dvsys.dv_auth$ da
WHERE da.grant_type = 'INDEX_FUNCTION'
/

