create type       ku$_dv_policy_obj_c_alts_t as object
(
  vers_major      char(1),                           /* UDT major version # */
  vers_minor      char(1),                           /* UDT minor version # */
  oidval          raw(16),                                     /* unique id */
  policy_name     varchar2(128),                       /* name of DV policy */
  command         varchar2(128),                                 /* command */
  object_owner    varchar2(128),                            /* object owner */
  object_name     varchar2(128),                             /* object name */
  clause_name     varchar2(100),    /* name of clause (may be wildcard '%') */
  parameter_name  varchar2(128),                   /* clause parameter name */
  event_name      varchar2(128),                              /* event name */
  component_name  varchar2(128),                       /* event target name */
  action_name     varchar2(128),                       /* event action name */
  scope           number
)
/

