create FUNCTION       predicate_true(p_owner IN VARCHAR2,
  p_object_name IN VARCHAR2)
RETURN VARCHAR2 IS
BEGIN
    return '0=0';
END;
/

