create view DBA_DV_COMMAND_RULE
            (COMMAND, CLAUSE_NAME, PARAMETER_NAME, EVENT_NAME, COMPONENT_NAME, ACTION_NAME, RULE_SET_NAME, OBJECT_OWNER,
             OBJECT_NAME, ENABLED, PRIVILEGE_SCOPE, COMMON, INHERITED, ID#, ORACLE_SUPPLIED, PL_SQL_STACK)
as
SELECT
      s.code
    , NVL(c.clause_name, '%')
    , s.parameter_name
    , s.event_name
    , s.component_name
    , s.action_name
    , s.rule_set_name
    , s.object_owner
    , s.object_name
    , s.enabled
    , s.privilege_scope
    , s.common
    , s.inherited
    , s.id#
    , CASE WHEN (s.id# < 5000)
           THEN 'YES'
           ELSE 'NO'
      END
    , s.pl_sql_stack
FROM
    (SELECT
           m.code_id#
         , d2.code
         , m.clause_id#
         , m.parameter_name
         , m.event_name
         , m.component_name
         , m.action_name
         , d1.name as rule_set_name
         , u.name as object_owner
         , m.object_name
         , m.enabled
         , m.privilege_scope
         , decode(m.scope, 1, 'NO',
                           2, 'YES',
                           3, 'YES') common
         , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                     (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
                THEN 'YES'
                ELSE 'NO'
           END inherited
         , m.id#
         , decode(m.pl_sql_stack, 0, 'NO',
                                  1, 'YES') pl_sql_stack
     FROM dvsys.command_rule$ m
         ,dvsys.dv$rule_set d1
         ,dvsys.dv$code d2
         ,sys."_BASE_USER" u
     WHERE
         d1.id# = m.rule_set_id#
         AND d2.id# = m.code_id#
         AND m.object_owner_uid# = u.user#
     UNION
     SELECT
           m.code_id#
         , d2.code
         , m.clause_id#
         , m.parameter_name
         , m.event_name
         , m.component_name
         , m.action_name
         , d1.name
         , '%'
         , m.object_name
         , m.enabled
         , m.privilege_scope
         , decode(m.scope, 1, 'NO',
                           2, 'YES',
                           3, 'YES') common
         , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                     (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
                THEN 'YES'
                ELSE 'NO'
           END inherited
         , m.id#
         , decode(m.pl_sql_stack, 0, 'NO',
                                  1, 'YES') pl_sql_stack
     FROM dvsys.command_rule$ m
         ,dvsys.dv$rule_set d1
         ,dvsys.dv$code d2
     WHERE
         d1.id# = m.rule_set_id#
         AND d2.id# = m.code_id#
         AND m.object_owner_uid# = 2147483636) s
LEFT JOIN (select distinct code_id#, clause_id#, clause_name from sys.v_$code_clause ) c
    ON s.code_id# = c.code_id#
       AND s.clause_id# = c.clause_id#
/

