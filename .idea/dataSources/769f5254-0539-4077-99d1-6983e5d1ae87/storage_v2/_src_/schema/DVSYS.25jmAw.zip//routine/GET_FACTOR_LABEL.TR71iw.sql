create FUNCTION       get_factor_label
                            (p_factor IN VARCHAR2, p_policy_name IN VARCHAR2) RETURN VARCHAR2
IS
BEGIN
  RETURN dvsys.dbms_macsec.get_factor_label(p_factor => p_factor, p_policy_name => p_policy_name);
END;
/

