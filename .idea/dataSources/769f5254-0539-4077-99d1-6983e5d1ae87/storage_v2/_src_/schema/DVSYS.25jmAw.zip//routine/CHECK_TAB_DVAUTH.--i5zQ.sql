create FUNCTION       check_tab_dvauth
                             (schema_name IN VARCHAR2,
                              table_name  IN VARCHAR2) RETURN BINARY_INTEGER
IS
BEGIN
  RETURN dvsys.dbms_macutl.check_tab_dvauth(schema_name, table_name);
END;
/

