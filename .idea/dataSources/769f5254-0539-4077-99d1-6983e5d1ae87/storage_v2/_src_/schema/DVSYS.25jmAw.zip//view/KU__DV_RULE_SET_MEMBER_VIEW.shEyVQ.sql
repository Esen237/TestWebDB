create view KU$_DV_RULE_SET_MEMBER_VIEW
            (VERS_MAJOR, VERS_MINOR, OIDVAL, RULE_SET_NAME, RULE_NAME, RULE_ORDER, ENABLED) as
select '0','0', sys_guid(),
          rulst.name,
          rult.name,
          rsr.rule_order,
          rsr.enabled
  from    dvsys.rule_set_rule$          rsr,
          dvsys.rule_set$               ruls,
          dvsys.rule_set_t$             rulst,
          dvsys.rule$                   rul,
          dvsys.rule_t$                 rult
  where   ruls.id# = rsr.rule_set_id#
    and   ruls.id# = rulst.id#
    and    rul.id# = rsr.rule_id#
    and    rul.id# = rult.id#
    and   ruls.id# >= 5000
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

