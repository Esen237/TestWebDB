create view DBA_DV_SIMULATION_LOG
            (ID, USERNAME, COMMAND, VIOLATION_TYPE, REALM_NAME, REALM_TYPE, OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE,
             RULE_SET_NAME, RETURNCODE, SQLTEXT, AUTHENTICATION_METHOD, CLIENT_IP, DB_DOMAIN, DATABASE_HOSTNAME,
             DATABASE_INSTANCE, DATABASE_IP, DATABASE_NAME, DOMAIN, ENTERPRISE_IDENTITY, IDENTIFICATION_TYPE, LANG,
             LANGUAGE, MACHINE, NETWORK_PROTOCOL, PROXY_ENTERPRISE_IDENTITY, PROXY_USER, SESSION_USER, DV$_DBLINK_INFO,
             DV$_MODULE, DV$_CLIENT_IDENTIFIER, FACTOR_CONTEXT, TIMESTAMP, PL_SQL_STACK)
as
SELECT
  tl.id#,
  tl.username,
  c1.code,
  c2.value,
  dvsys.dv_id_to_name(tl.realm_id_list, 1),
  substr(dvsys.dv_id_to_type(tl.realm_id_list), 0, 9),
  tl.object_owner,
  tl.object_name,
  tl.object_type,
  dvsys.dv_id_to_name(tl.rule_set_id_list, 2),
  tl.returncode,
  tl.sqltext,
  tl.authentication_method,
  tl.client_ip,
  tl.db_domain,
  tl.database_hostname,
  tl.database_instance,
  tl.database_ip,
  tl.database_name,
  tl.domain,
  tl.enterprise_identity,
  tl.identification_type,
  tl.lang,
  tl.language,
  tl.machine,
  tl.network_protocol,
  tl.proxy_enterprise_identity,
  tl.proxy_user,
  tl.session_user,
  tl.dv$_dblink_info,
  tl.dv$_module,
  tl.dv$_client_identifier,
  tl.factor_context,
  tl.timestamp,
  dvsys.stack_varray_to_clob(tl.pl_sql_stack)
  FROM DVSYS.SIMULATION_LOG$ tl, dvsys.dv$code c1, dvsys.dv$code c2
  WHERE c1.id# = tl.action and c1.code_group = 'SQL_CMDS' and
        c2.code = TO_CHAR(tl.violation_type) and
        c2.code_group = 'SIMULATION_VIOLATION'
/

