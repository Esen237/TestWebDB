create trigger TRG_WLS_HVST_INSERT
    before insert
    on WLS_HVST
    for each row
BEGIN 
      IF :newRow.RECORDID IS NULL THEN 
        SELECT SEQ_WLS_HVST_RECORDID.nextval INTO :newRow.RECORDID FROM DUAL; 
      END IF; 
    END;
/

