create trigger STEPEXECUTIONINSTANCEDATA_TRG
    before insert
    on STEPEXECUTIONINSTANCEDATA
    for each row
BEGIN
                   SELECT STEPEXECUTIONINSTANCEDATA_SEQ.nextval INTO :new.stepexecid FROM dual;
                 END;
/

