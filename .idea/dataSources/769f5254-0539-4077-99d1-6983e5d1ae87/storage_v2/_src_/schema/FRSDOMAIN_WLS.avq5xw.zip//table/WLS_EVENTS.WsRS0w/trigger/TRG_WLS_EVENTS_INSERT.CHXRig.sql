create trigger TRG_WLS_EVENTS_INSERT
    before insert
    on WLS_EVENTS
    for each row
BEGIN 
      IF :newRow.RECORDID IS NULL THEN 
        SELECT SEQ_WLS_EVENTS_RECORDID.nextval INTO :newRow.RECORDID FROM DUAL; 
      END IF; 
    END;
/

