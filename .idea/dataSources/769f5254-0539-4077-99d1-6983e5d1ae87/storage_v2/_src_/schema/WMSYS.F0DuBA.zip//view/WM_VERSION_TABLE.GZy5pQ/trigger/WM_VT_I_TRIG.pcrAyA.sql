create trigger WM$VT_I_TRIG
    instead of insert
    on WM$VERSION_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#1   integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
  ws#2   integer := wmsys.ltUtil.getWorkspaceLockId(:new.anc_workspace) ;


  refcount integer := :new.refcount ;
begin
  if (refcount is null) then
    refcount := 0 ;
  end if ;

  insert into wmsys.wm$version_table$(workspace#, anc_workspace#, anc_version, anc_depth, refcount)
  values (ws#1, ws#2, :new.anc_version, :new.anc_depth, refcount) ;
end;
/

