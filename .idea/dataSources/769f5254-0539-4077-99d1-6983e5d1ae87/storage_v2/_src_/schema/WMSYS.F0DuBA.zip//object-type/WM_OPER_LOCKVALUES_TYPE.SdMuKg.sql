create type       wm$oper_lockvalues_type authid definer
         as object (parValue    integer,
                    curValue    integer,
                    interValue  integer)
/

