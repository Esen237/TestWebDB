create view WM$DBA_TAB_COLS as
select dtc.owner, dtc.table_name, dtc.column_name, dtc.data_type, dtc.data_type_mod, dtc.data_type_owner, dtc.data_length, dtc.data_precision, dtc.data_scale,
       dtc.column_id, dtc.default_length, dtc.data_default, dtc.char_length, dtc.char_used, dtc.hidden_column, dtc.user_generated,
       (case dtc.virtual_column
        when 'NO' then 'NO'
        else decode((select bitand(c.property, 65536)
                     from all_users u, sys.obj$ o, sys.col$ c
                     where u.username = dtc.owner and
                           u.user_id = o.owner# and
                           o.name = dtc.table_name and
                           c.obj# = o.obj# and
                           c.name = dtc.column_name),
                    65536, 'YES', 'NO')
        end) virtual_column,
       dtc.identity_column, ic.sequence_name identity_sequence, ic.identity_options,
       (case ic.generation_type when 'ALWAYS' then 'IA' else (case dtc.default_on_null when 'NO' then 'ID' else 'IN' end) end) identity_type
from sys.dba_tab_cols dtc, dba_tab_identity_cols ic
where dtc.owner = ic.owner(+) and
      dtc.table_name = ic.table_name(+) and
      dtc.column_name = ic.column_name(+)
/

