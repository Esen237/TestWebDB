create view WM$MP_GRAPH_REMAINING_VERSIONS as
select vht.version
 from wmsys.wm$version_hierarchy_table vht, wmsys.wm$version_table vt
 where vt.anc_workspace = sys_context('lt_ctx', 'mp_workspace') and
       vht.workspace = vt.workspace
union all
 select vht.version
 from wmsys.wm$version_hierarchy_table vht
 where vht.workspace = sys_context('lt_ctx', 'mp_workspace')
WITH READ ONLY
/

