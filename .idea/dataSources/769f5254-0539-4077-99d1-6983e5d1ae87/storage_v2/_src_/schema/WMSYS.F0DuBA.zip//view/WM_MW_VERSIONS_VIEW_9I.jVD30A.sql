create view WM$MW_VERSIONS_VIEW_9I as
select version, modified_by, wmsys.ltUtil.wm$concat(cast(collect(workspace) as wmsys.wm$ident_tab_type)) seen_by
from (select vht.version, vht.workspace modified_by, mw.workspace
      from wmsys.wm$mw_table mw, wmsys.wm$version_table vt, wmsys.wm$version_hierarchy_table vht
      where mw.workspace = vt.workspace and
            vt.anc_workspace = vht.workspace and
            vht.version <= vt.anc_version
     union all
      select vht.version, vht.workspace modified_by, mw.workspace
      from wmsys.wm$mw_table mw, wmsys.wm$version_hierarchy_table vht
      where mw.workspace = vht.workspace
     )
group by (version,modified_by)
WITH READ ONLY
/

