create trigger WM$RTT_I_TRIG
    instead of insert
    on WM$RIC_TRIGGERS_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid1  integer := wmsys.ltUtil.getVtid(:new.pt_owner, :new.pt_name) ;
  vtid2  integer := wmsys.ltUtil.getVtid(:new.ct_owner, :new.ct_name) ;
begin
  insert into wmsys.wm$ric_triggers_table$(pt_vtid#, ct_vtid#, trig#)
  values (vtid1, vtid2, regexp_substr(:new.update_trigger_name, '[[:digit:]]+$')) ;
end;
/

