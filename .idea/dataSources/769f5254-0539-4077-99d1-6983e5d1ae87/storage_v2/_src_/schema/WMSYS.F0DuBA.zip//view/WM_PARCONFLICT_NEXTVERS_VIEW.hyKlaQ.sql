create view WM$PARCONFLICT_NEXTVERS_VIEW as
select nt.version, nt.next_vers, nt.split, ppv.vtid
from wmsys.wm$nextver_table$ nt, wmsys.wm$parConflict_parvers_view ppv
where nt.version = ppv.parent_vers
WITH READ ONLY
/

