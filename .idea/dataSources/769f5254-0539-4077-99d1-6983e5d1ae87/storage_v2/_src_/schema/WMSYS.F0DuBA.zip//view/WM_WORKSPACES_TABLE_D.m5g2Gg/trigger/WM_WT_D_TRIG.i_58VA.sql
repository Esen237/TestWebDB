create trigger WM$WT_D_TRIG
    instead of delete
    on WM$WORKSPACES_TABLE$D
    for each row
begin
  delete wmsys.wm$batch_compressible_tables$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$lockrows_info$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$mp_graph_workspaces_table$
  where mp_leaf_workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$mp_graph_workspaces_table$
  where mp_graph_workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$mp_parent_workspaces_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$mp_parent_workspaces_table$
  where parent_workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$mw_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$resolve_workspaces_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$version_hierarchy_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$version_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$version_table$
  where anc_workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$workspace_priv_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$workspace_savepoints_table$
  where workspace#=:old.workspace_lock_id ;

  delete wmsys.wm$workspaces_table$
  where workspace_lock_id=:old.workspace_lock_id ;
end;
/

