create type       wm$metadata_map_type authid definer
         as object (code           integer,
                    nfield1        number,
                    nfield2        number,
                    nfield3        number,
                    vfield1        varchar2(128),
                    vfield2        varchar2(128),
                    vfield3        clob,
                    wm_version     integer,
                    wm_nextver     varchar2(500),
                    wm_delstatus   number,
                    wm_ltlock      varchar2(150),
                    wm_createtime  timestamp with time zone,
                    wm_retiretime  timestamp with time zone,
                    wm_validfrom   timestamp with time zone,
                    wm_validtill   timestamp with time zone)
/

