create view WM$WORKSPACES_TABLE$I
            (WORKSPACE, CURRENT_VERSION, PARENT_VERSION, POST_VERSION, VERLIST, OWNER, CREATETIME, DESCRIPTION,
             WORKSPACE_LOCK_ID, FREEZE_STATUS, FREEZE_MODE, FREEZE_WRITER, OPER_STATUS, WM_LOCKMODE, ISREFRESHED,
             FREEZE_OWNER, SESSION_DURATION, IMPLICIT_SP_CNT, CR_STATUS, SYNC_PARVER, LAST_CHANGE, DEPTH, MP_ROOT, KEEP,
             PARENT_WORKSPACE#, PARENT_WORKSPACE, PARENT_CURRENT_VERSION)
as
select wt1.workspace,
       wt1.current_version,
       wt1.parent_version,
       wt1.post_version,
       null verlist,
       wt1.owner,
       wt1.createtime,
       wt1.description,
       wt1.workspace_lock_id,
       decode(bitand(wt1.wm$flag, 1), 0, 'UNLOCKED', 1, 'LOCKED') freeze_status,
       decode(bitand(wt1.wm$flag, 14), 0, null, 2, '1WRITER', 4, '1WRITER_SESSION', 6, 'NO_ACCESS', 8, 'READ_ONLY', 10, 'WM_ONLY', 12, 'REMOVED', 14, 'DEFERRED_REMOVAL') freeze_mode,
       wt1.freeze_writer,
       null oper_status,
       decode(bitand(wt1.wm$flag, 112), 0, null, 16, 'S', 32, 'E', 48, 'WE', 64, 'VE', 80, 'C', 96, 'D') ||
         decode(bitand(wt1.wm$flag, 496),  0, null, ',') ||
         decode(bitand(wt1.wm$flag, 384), 0, null, 128, 'Y', 256, 'N') wm_lockmode,
       decode(bitand(wt1.wm$flag, 512), 0, 0, 1) isRefreshed,
       wt1.freeze_owner,
       decode(bitand(wt1.wm$flag, 1024), 0, 0, 1) session_duration,
       (select nvl(max(to_number(substr(st.savepoint, 5))), 0)
        from wmsys.wm$workspace_savepoints_table$ st
        where st.workspace# = wt1.workspace_lock_id and st.savepoint like 'ICP-%') implicit_sp_cnt,
       decode(bitand(wt1.wm$flag, 6144), 0, 'CRS_ALLCR', 2048, 'CRS_ALLNONCR', 4096, 'CRS_LEAF', 6144, 'CRS_MIXED') cr_status,
       wt1.sync_parver,
       wt1.last_change,
       wt1.depth,
       wt1.mp_root,
       decode(bitand(wt1.wm$flag, 8192), 0, 0, 8192, 1) keep,
       wt1.parent_workspace#,
       wt2.workspace parent_workspace,
       wt2.current_version parent_current_version
from wmsys.wm$workspaces_table$ wt1, wmsys.wm$workspaces_table$ wt2
where wt1.parent_workspace# = wt2.workspace_lock_id(+) and
      bitand(wt1.wm$flag, 14) not in (12, 14)
/

