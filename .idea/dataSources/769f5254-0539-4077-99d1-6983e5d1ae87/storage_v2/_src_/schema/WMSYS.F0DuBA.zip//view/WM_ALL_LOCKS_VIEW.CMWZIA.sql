create view WM$ALL_LOCKS_VIEW as
select vt.owner, vt.table_name,
       decode(wmsys.lt_ctx_pkg.getltlockinfo(translate(t.info USING CHAR_CS), 'ROW_LOCKMODE'),
              'E', 'EXCLUSIVE', 'S', 'SHARED', 'VE', 'VERSION EXCLUSIVE', 'WE', 'WORKSPACE EXCLUSIVE') lock_mode,
       wmsys.lt_ctx_pkg.getltlockinfo(translate(t.info USING CHAR_CS), 'ROW_LOCKUSER') lock_owner,
       wmsys.lt_ctx_pkg.getltlockinfo(translate(t.info USING CHAR_CS), 'ROW_LOCKSTATE') locking_state
from wmsys.wm$versioned_tables vt,
     table(wmsys.owm_dynsql_access.get_lock_table(vt.owner, vt.table_name)) t
with READ ONLY
/

