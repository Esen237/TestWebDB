create view WM$ALL_VERSION_HVIEW_WDEPTH as
select vht.version, vht.parent_version, wt.workspace, vht.workspace# workspace_id, wt.depth, wt.wm_lockmode
from wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$workspaces_table$i wt
where vht.workspace# = wt.workspace_lock_id
WITH READ ONLY
/

