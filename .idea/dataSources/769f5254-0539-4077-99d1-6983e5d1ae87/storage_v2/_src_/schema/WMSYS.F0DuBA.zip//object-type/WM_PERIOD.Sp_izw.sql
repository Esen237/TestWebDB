create type       wm_period                                                                        authid definer
         as object (validfrom timestamp with time zone,
                    validtill timestamp with time zone)
 alter type       wm_period add MAP member function wm_period_map return varchar2 cascade
/

