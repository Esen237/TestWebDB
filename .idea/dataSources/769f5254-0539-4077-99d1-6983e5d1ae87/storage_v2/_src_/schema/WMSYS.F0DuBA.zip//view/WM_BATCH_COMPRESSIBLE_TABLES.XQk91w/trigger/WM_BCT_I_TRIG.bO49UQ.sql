create trigger WM$BCT_I_TRIG
    instead of insert
    on WM$BATCH_COMPRESSIBLE_TABLES
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
  vtid   integer := wmsys.ltUtil.getVtid(substr(upper(:new.table_name), 1, instr(:new.table_name, '.')-1),
                                         substr(upper(:new.table_name), instr(:new.table_name, '.')+1)) ;
begin
  insert into wmsys.wm$batch_compressible_tables$(workspace#, vtid#, begin_version, end_version, where_clause)
  values (ws#, vtid, :new.begin_version, :new.end_version, :new.where_clause) ;
end;
/

