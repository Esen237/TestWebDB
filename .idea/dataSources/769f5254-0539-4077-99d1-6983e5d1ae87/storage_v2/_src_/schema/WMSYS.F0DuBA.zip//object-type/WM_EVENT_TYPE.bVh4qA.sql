create type       wm$event_type                                                                        authid definer
         as object (event_name             varchar2(128),
                    workspace_name         varchar2(128),
                    parent_workspace_name  varchar2(128),
                    user_name              varchar2(128),
                    table_name             varchar2(128),
                    aux_params             wmsys.wm$nv_pair_nt_type)
/

