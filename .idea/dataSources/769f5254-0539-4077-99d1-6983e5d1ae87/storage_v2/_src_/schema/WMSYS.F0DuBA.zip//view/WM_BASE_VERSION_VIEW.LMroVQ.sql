create view WM$BASE_VERSION_VIEW as
select decode(sign(vt1.anc_version - vt2.anc_version), 1, vt2.anc_version, vt1.anc_version) version,
       decode(sign(vt1.anc_version - vt2.anc_version), 1, vt2.anc_workspace#, vt1.anc_workspace#) workspace#
from (select vt1.anc_version, vt1.anc_workspace#
      from wmsys.wm$version_table$ vt1
      where vt1.workspace# = sys_context('lt_ctx', 'diffWspc1_id') and
            vt1.anc_workspace# = sys_context('lt_ctx', 'anc_workspace_id')
      union all
      select decode(sys_context('lt_ctx', 'diffver1'),
                    -1, (select current_version
                         from wmsys.wm$workspaces_table$
                         where workspace_lock_id = sys_context('lt_ctx', 'diffWspc1_id')),
                     sys_context('lt_ctx', 'diffver1')) version,
              cast(sys_context('lt_ctx', 'diffWspc1_id') as number)
      from sys.dual
      where sys_context('lt_ctx', 'anc_workspace_id') = sys_context('lt_ctx', 'diffWspc1_id')
      ) vt1,
      (select vt2.anc_version, vt2.anc_workspace#
       from wmsys.wm$version_table$ vt2
       where vt2.workspace# = sys_context('lt_ctx', 'diffWspc2_id') and
             vt2.anc_workspace# = sys_context('lt_ctx', 'anc_workspace_id')
       union all
       select decode(sys_context('lt_ctx', 'diffver2'),
                     -1, (select current_version
                          from wmsys.wm$workspaces_table$
                          where workspace_lock_id = sys_context('lt_ctx', 'diffWspc2_id')),
                     sys_context('lt_ctx', 'diffver2')) version,
              cast(sys_context('lt_ctx', 'diffWspc2_id') as number)
       from sys.dual
       where sys_context('lt_ctx', 'anc_workspace_id') = sys_context('lt_ctx', 'diffWspc2_id')
      ) vt2
WITH READ ONLY
/

