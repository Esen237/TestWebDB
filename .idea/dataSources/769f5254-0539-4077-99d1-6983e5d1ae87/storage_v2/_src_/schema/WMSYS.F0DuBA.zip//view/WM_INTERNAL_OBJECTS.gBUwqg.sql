create view WM$INTERNAL_OBJECTS as
select code vtid,
       vfield1 obj_owner,
       vfield2 obj_name,
       decode(nfield1, 0, 'TABLE', 1, 'INDEX', 2, 'CONSTRAINT', 3, 'PROCEDURE', 4, 'VIEW', 5, 'TRIGGER', 6, 'PACKAGE', 7, 'PACKAGE BODY', null) obj_type,
       (case nfield2 when 0 then 'VALID' when 1 then 'INVALID' when 2 then 'MISSING' else null end) obj_status,
       (case nfield3 when 0 then 'NO' else 'YES' end) exported
from table(wmsys.lt_export_pkg.get_internal_objects())
/

