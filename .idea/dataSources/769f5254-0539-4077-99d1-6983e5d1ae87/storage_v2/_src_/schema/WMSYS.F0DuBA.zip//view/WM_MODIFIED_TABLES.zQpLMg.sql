create view WM$MODIFIED_TABLES as
select mt.vtid# vtid, vt.owner || '.' || vt.table_name table_name, mt.version, wt.workspace,
       wmsys.ltUtil.rowsInVersFromHistogram(vt.owner, vt.table_name, wt.workspace, mt.version, mt.version) num_rows
from wmsys.wm$modified_tables$ mt, wmsys.wm$versioned_tables$ vt, wmsys.wm$workspaces_table$i wt
where mt.vtid# = vt.vtid# and
      mt.workspace# = wt.workspace_lock_id
/

