create trigger WM$RWT_I_TRIG
    instead of insert
    on WM$RESOLVE_WORKSPACES_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$resolve_workspaces_table$f(:new.oldfreezemode) ;

  insert into wmsys.wm$resolve_workspaces_table$(workspace#, resolve_user, undo_sp#, oldfreezewriter, wm$flag)
  values (ws#, :new.resolve_user, :new.undo_sp_ver, :new.oldfreezewriter, flag_v) ;
end;
/

