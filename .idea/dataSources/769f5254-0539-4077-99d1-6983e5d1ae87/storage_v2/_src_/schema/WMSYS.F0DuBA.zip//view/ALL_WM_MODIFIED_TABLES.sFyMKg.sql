create view ALL_WM_MODIFIED_TABLES as
select table_name, workspace, savepoint
from (select o.table_name, o.workspace,
             nvl(s.savepoint, 'LATEST') savepoint,
             s.is_implicit imp,
             count(*) over (partition by o.table_name, o.workspace, s.version) counter
      from wmsys.wm$modified_tables o, wmsys.wm$workspace_savepoints_table s, all_views a
      where substr(o.table_name, 1, instr(o.table_name, '.')-1) = a.owner and
            substr(o.table_name, instr(o.table_name, '.')+1) = a.view_name and
            o.version = s.version (+))
where (imp = 0 or imp is null or counter = 1)
WITH READ ONLY
/

