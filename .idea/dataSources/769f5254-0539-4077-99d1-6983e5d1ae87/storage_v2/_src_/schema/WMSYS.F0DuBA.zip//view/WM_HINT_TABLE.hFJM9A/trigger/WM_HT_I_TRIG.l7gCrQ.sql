create trigger WM$HT_I_TRIG
    instead of insert
    on WM$HINT_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$hint_table$f(:new.isdefault) ;

  insert into wmsys.wm$hint_table$(hint_id, vtid#, hint_text, wm$flag)
  values (:new.hint_id, vtid, :new.hint_text, flag_v) ;
end;
/

