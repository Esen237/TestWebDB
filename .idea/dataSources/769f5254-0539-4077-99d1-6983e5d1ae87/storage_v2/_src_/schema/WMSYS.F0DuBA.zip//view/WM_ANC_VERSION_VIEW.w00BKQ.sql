create view WM$ANC_VERSION_VIEW as
select vht1.version, vht2.version parent_vers, vht1.workspace
from wmsys.wm$version_hierarchy_table vht1, wmsys.wm$version_hierarchy_table vht2, wmsys.wm$version_table vt
where vht1.workspace = vt.workspace and
      vht2.workspace = vt.anc_workspace and
      vht2.version  <= vt.anc_version
WITH READ ONLY
/

