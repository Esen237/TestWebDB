create view WM$MP_GRAPH_WORKSPACES_TABLE as
select wt1.workspace mp_leaf_workspace, wt2.workspace mp_graph_workspace, mgwt.anc_version,
       decode(bitand(mgwt.wm$flag, 3), 0, 'I', 1, 'L', 2, 'R') mp_graph_flag
from wmsys.wm$mp_graph_workspaces_table$ mgwt, wmsys.wm$workspaces_table$i wt1, wmsys.wm$workspaces_table$i wt2
where mgwt.mp_leaf_workspace# = wt1.workspace_lock_id and
      mgwt.mp_graph_workspace# = wt2.workspace_lock_id
/

