create trigger WM$CT_U_TRIG
    instead of update
    on WM$CONSTRAINTS_TABLE
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
  vtid    integer := wmsys.ltUtil.getVtid(:old.owner, :old.table_name) ;
begin
  if (updating('STATUS')) then
    flag_v := wmsys.owm_dml_pkg.wm$constraints_table$f(:new.constraint_type, :new.status, :new.index_type) ;
    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (updating('CONSTRAINT_NAME')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' constraint_name=:2' ;
  end if;

  if (updating('INDEX_NAME')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' index_name=:3' ;
  end if;

  if (updating('ALIASEDCOLUMNS')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' aliasedcolumns=:4' ;
  end if;

  if (updating('NUMINDEXCOLS')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' numindexcols=:5' ;
  end if;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null or :4 is null or :5 is null or :6 is null or :7 is null or :8 is null)) then
           null ;
         end if;

         update wmsys.wm$constraints_table$
         set ' || substr(sqlstr, 2) || '
         where vtid#=:6 and constraint_name=:7 and bitand(wm$flag, 8)=decode(:8, ''DISABLED'', 0, ''ENABLED'', 8);
       end;' using flag_v, :new.constraint_name, :new.index_name, :new.aliasedcolumns, :new.numindexcols,
                   vtid, :old.constraint_name, :old.status ;
  end if ;
end;
/

