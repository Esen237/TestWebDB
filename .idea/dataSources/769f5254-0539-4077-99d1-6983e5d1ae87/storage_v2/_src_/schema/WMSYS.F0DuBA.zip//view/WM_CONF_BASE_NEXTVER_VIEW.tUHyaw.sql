create view WM$CONF_BASE_NEXTVER_VIEW as
select next_vers
from wmsys.wm$nextver_table
where version in (select version from wmsys.wm$conf_base_hierarchy_view)
WITH READ ONLY
/

