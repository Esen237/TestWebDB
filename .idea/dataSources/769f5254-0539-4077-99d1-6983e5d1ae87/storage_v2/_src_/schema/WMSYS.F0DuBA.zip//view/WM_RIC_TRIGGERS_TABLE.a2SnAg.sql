create view WM$RIC_TRIGGERS_TABLE as
select vt2.owner pt_owner, vt2.table_name pt_name, vt1.owner ct_owner, vt1.table_name ct_name,
       'WMSYS.WM$' || vt1.vtid# || '$LT_AU_' || rtt.trig# update_trigger_name,
       'WMSYS.WM$' || vt1.vtid# || '$LT_AD_' || rtt.trig# delete_trigger_name
from wmsys.wm$ric_triggers_table$ rtt, wmsys.wm$versioned_tables$ vt1, wmsys.wm$versioned_tables$ vt2
where rtt.ct_vtid# = vt1.vtid# and
      rtt.pt_vtid# = vt2.vtid#
/

