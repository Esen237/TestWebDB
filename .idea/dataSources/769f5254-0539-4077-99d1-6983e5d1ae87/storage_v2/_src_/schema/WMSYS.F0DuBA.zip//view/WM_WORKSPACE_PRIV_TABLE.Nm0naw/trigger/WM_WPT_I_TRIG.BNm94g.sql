create trigger WM$WPT_I_TRIG
    instead of insert
    on WM$WORKSPACE_PRIV_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$workspace_priv_table$f(:new.priv, :new.admin) ;

  insert into wmsys.wm$workspace_priv_table$(grantee, workspace#, grantor, wm$flag)
  values (:new.grantee, ws#, :new.grantor, flag_v) ;
end;
/

