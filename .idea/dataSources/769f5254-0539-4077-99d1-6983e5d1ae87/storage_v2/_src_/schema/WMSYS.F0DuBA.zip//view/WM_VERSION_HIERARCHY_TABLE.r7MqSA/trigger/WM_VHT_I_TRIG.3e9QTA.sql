create trigger WM$VHT_I_TRIG
    instead of insert
    on WM$VERSION_HIERARCHY_TABLE
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
begin
  insert into wmsys.wm$version_hierarchy_table$(version, parent_version, workspace#)
  values (:new.version, :new.parent_version, ws#) ;
end;
/

