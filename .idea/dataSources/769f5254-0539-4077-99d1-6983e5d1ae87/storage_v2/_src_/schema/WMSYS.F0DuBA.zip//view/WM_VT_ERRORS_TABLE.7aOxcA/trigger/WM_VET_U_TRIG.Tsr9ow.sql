create trigger WM$VET_U_TRIG
    instead of update
    on WM$VT_ERRORS_TABLE
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
  vtid    integer := wmsys.ltUtil.getVtid(:old.owner, :old.table_name) ;
begin
  if (updating('STATUS')) then
    flag_v := wmsys.owm_dml_pkg.wm$vt_errors_table$f(:new.status) ;
    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (updating('ERROR_MSG')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' error_msg=:2' ;
  end if;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null)) then
           null ;
         end if;

         update wmsys.wm$vt_errors_table$
         set ' || substr(sqlstr, 2) || '
         where vtid#=:3;
       end;' using flag_v, :new.error_msg, vtid ;
  end if ;
end;
/

