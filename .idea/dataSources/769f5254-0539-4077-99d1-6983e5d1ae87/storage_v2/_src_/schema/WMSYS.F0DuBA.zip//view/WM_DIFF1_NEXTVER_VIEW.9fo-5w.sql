create view WM$DIFF1_NEXTVER_VIEW as
select next_vers
from wmsys.wm$nextver_table$
where version in (select version from wmsys.wm$diff1_hierarchy_view)
WITH READ ONLY
/

