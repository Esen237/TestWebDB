create view WM$PARCONFLICT_PARVERS_VIEW as
select mt.version parent_vers, mt.vtid# vtid
from wmsys.wm$modified_tables$ mt, wmsys.wm$workspaces_table$i wt
where mt.workspace# = sys_context('lt_ctx', 'parent_conflict_state_id') and
      wt.workspace_lock_id = sys_context('lt_ctx', 'conflict_state_id') and
      mt.version >= decode(sign(wt.parent_version - wt.sync_parver), -1, (wt.parent_version+1), sync_parver)
WITH READ ONLY
/

