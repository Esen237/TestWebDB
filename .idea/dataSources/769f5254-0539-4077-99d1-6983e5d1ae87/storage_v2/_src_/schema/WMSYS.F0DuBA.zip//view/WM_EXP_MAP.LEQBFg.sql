create view WM$EXP_MAP as
select code, nfield1, nfield2, nfield3, vfield1, vfield2, vfield3
from table(wmsys.lt_export_pkg.export_mapping_view_func())
WITH READ ONLY
/

