create view WM$CURRENT_CONS_NEXTVERS_VIEW as
select /*+ INDEX(nvt WM$NEXTVER_TABLE_NV_INDX) */ nvt.next_vers
from wmsys.wm$nextver_table nvt
where (nvt.workspace = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
       nvt.version <= decode(sys_context('lt_ctx', 'version'),
                             -1, (select current_version
                                  from wmsys.wm$workspaces_table
                                  where workspace = sys_context('lt_ctx', 'state')),
                             null, (select current_version
                                    from wmsys.wm$workspaces_table
                                    where workspace = wmsys.ltUtil.getDefaultWorkspaceName),
                             sys_context('lt_ctx', 'version')
                            ) and
       not (nvl(sys_context('lt_ctx', 'rowlock_status'), 'X') = 'F' and nvl(sys_context('lt_ctx', 'flip_version'), 'N') = 'Y')
      )
      or
      (exists (select 1
               from wmsys.wm$version_table vt
               where vt.workspace  = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
                     nvt.workspace = vt.anc_workspace and
                     nvt.version  <= vt.anc_version)
      )
WITH READ ONLY
/

