create view WM$BATCH_COMPRESSIBLE_TABLES as
select wt.workspace,
       vt.owner || '.' || vt.table_name table_name,
       bct.begin_version,
       bct.end_version,
       bct.where_clause
from wmsys.wm$batch_compressible_tables$ bct, wmsys.wm$workspaces_table$i wt, wmsys.wm$versioned_tables$ vt
where bct.workspace# = wt.workspace_lock_id and
      bct.vtid# = vt.vtid#
/

