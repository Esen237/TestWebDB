create PACKAGE BODY                                              Pkg_Notification IS

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send Android Push Notification
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('ANDROID_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
      
    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send Android Push Notification
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('ANDROID_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    PKG_REST.ADDPARAM(content,'regId',reg_id);
    
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
      
    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send iOS Push Notification
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('IOS_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
  
    OPEN pc_ref FOR SELECT resp_str FROM dual;
  
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send iOS Push Notification
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('IOS_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    PKG_REST.ADDPARAM(content,'regId',reg_id);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
  
    OPEN pc_ref FOR SELECT resp_str FROM dual;
  
    RETURN ls_returncode;
end;


/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add Push Notification to Queue
******************************************************************************/
FUNCTION addPushToQueue(message IN VARCHAR2, devices IN DeviceList) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number;
BEGIN
    select seq_notif.nextVal into notif_id from dual;
    
    insert into TBL_NOTIFICATION
    (NOTIF_ID, MSG_CONTENT, NOTIF_TYPE_CD)
    values
    (notif_id, message, 'PUSH');
    
    for i in 1..devices.count loop

        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, DEVICE_ID, STATUS_CD)
        values
        (notif_id, seq_notif_result.nextVal, devices(i), 'sQUEUED');
    end loop;
    
    RETURN ls_returncode;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued push notifications
******************************************************************************/
FUNCTION sendQueuedPush(pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_QUEUED_PUSH_URL',url);
    resp_str := PKG_REST.SENDREQUEST(url, 'GET', '');

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send plain text email
******************************************************************************/
FUNCTION sendEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_MAIL_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'subject',subject);
    PKG_REST.ADDPARAM(content,'body',message);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send plain text email with clob attachment
******************************************************************************/
FUNCTION sendEmailClobAttach(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);

BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_MAIL_CLOB_ATTACH_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'subject',subject);
    PKG_REST.ADDPARAM(content,'body',message);
    PKG_REST.ADDPARAM(content,'filename',attachname);
    PKG_REST.ADDPARAM(content,'file',attach);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send html email
******************************************************************************/
FUNCTION sendHtmlEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_HTML_MAIL_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'subject',subject);
    PKG_REST.ADDPARAM(content,'body',message);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send html email with template
******************************************************************************/
FUNCTION sendHtmlEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, mtemplate IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_HTML_MAIL_TEMPLATE_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'subject',subject);
    PKG_REST.ADDPARAM(content,'body',message);
    PKG_REST.ADDPARAM(content,'template',mtemplate);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send html email with clob attachment
******************************************************************************/
FUNCTION sendHtmlEmailClobAttach(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);

BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_HTML_MAIL_CLOB_ATTACH_URL',url);
    PKG_REST.ADDPARAM(content,'to', receiver);
    PKG_REST.ADDPARAM(content,'subject', subject);
    PKG_REST.ADDPARAM(content,'body', message);
    PKG_REST.ADDPARAM(content,'filename',attachname);
    PKG_REST.ADDPARAM(content,'file', attach);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add email to queue
******************************************************************************/
FUNCTION addEmailToQueue(message IN VARCHAR2, subject IN VARCHAR2, sender IN VARCHAR2, recipients IN RecipientList, contentType IN VARCHAR2, 
    emailTemplate IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number;
BEGIN
   
    IF  recipients.count <= 0 THEN
       return ls_returncode;
    END IF;
    IF recipients(1) is null or TRIM(recipients(1)) = '' THEN
       return ls_returncode;
    END IF;
    
    select seq_notif.nextVal into notif_id from dual;
    
    insert into TBL_NOTIFICATION
    (NOTIF_ID, MSG_CONTENT, MSG_SUBJECT, SENDER, CONTENT_TYPE, ATTACHMENT_NAME, ATTACHMENT, NOTIF_TYPE_CD, TEMPLATE)
    values
    (notif_id, message, subject, sender, contentType, attachname, attach, 'EMAIL', emailTemplate);
    
    for i in 1..recipients.count loop

        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, RECIPIENT, STATUS_CD)
        values
        (notif_id, seq_notif_result.nextVal, recipients(i), 'sQUEUED');
    end loop;
    
    RETURN ls_returncode;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued emails
******************************************************************************/
FUNCTION sendQueuedEmails(pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_QUEUED_MAILS_URL',url);
    resp_str := PKG_REST.SENDREQUEST(url, 'GET', '');

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send sms
******************************************************************************/
FUNCTION sendSMS(receiver IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_SMS_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'body',message);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send otp
******************************************************************************/
FUNCTION sendOTP(receiver IN VARCHAR2, message IN VARCHAR2, person_id IN VARCHAR2, otp IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
BEGIN
    CBS.PKG_PARAMETRE.deger('SEND_SMS_URL',url);
    PKG_REST.ADDPARAM(content,'to',receiver);
    PKG_REST.ADDPARAM(content,'body',message);
    PKG_REST.ADDPARAM(content,'personId',person_id);
    PKG_REST.ADDPARAM(content,'otp',otp);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);

    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add sms to queue
******************************************************************************/
FUNCTION addSMSToQueue(message IN VARCHAR2, recipients IN RecipientList) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number;
BEGIN
    select seq_notif.nextVal into notif_id from dual;
    
    insert into TBL_NOTIFICATION
    (NOTIF_ID, MSG_CONTENT, NOTIF_TYPE_CD)
    values
    (notif_id, message, 'SMS');
    
    for i in 1..recipients.count loop

        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, RECIPIENT, STATUS_CD)
        values
        (notif_id, seq_notif_result.nextVal, recipients(i), 'sQUEUED');
    end loop;
    
    RETURN ls_returncode;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued sms messages
******************************************************************************/
FUNCTION sendQueuedSMS(pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
ls_returncode        VARCHAR2 (3)  := '000';

url varchar2(200);
resp_str varchar2(4000);
BEGIN
CBS.PKG_PARAMETRE.deger('SEND_QUEUED_SMS_URL',url);
resp_str := PKG_REST.SENDREQUEST(url, 'GET', '');

OPEN pc_ref FOR SELECT resp_str FROM dual;
  
RETURN ls_returncode;
end;
/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 30.05.2019
   Purpose    : send Push Notification to Customer Devices
******************************************************************************/
FUNCTION sendPushNotification(message IN VARCHAR2, pn_customer_no IN NUMBER, title varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 is
    ls_returncode        VARCHAR2 (3);

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
    cursor cur_devices is select * from CORPINT2.TBL_device
        where person_id = (select person_id from CORPINT2.TBL_IDENTIFICATION where customer_no = pn_customer_no);
    rec_devices cur_devices%rowtype;
 
BEGIN
    open cur_devices;
    loop
        fetch cur_devices into rec_devices;
        exit when cur_devices%notfound;
        if rec_devices.os_type = 'ANDROID' then
            ls_returncode := sendAndroidPushNotification(message, rec_devices.registr_id, title, pc_ref);
        else
            ls_returncode := sendIOSPushNotification(message, rec_devices.registr_id, title, pc_ref);
        end if;
    end loop;
    
    RETURN ls_returncode;
end;

/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 09.09.2019
   Purpose    : send Android Push Notification with title
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, title varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('ANDROID_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    PKG_REST.ADDPARAM(content,'regId',reg_id);
    PKG_REST.ADDPARAM(content,'title',title);
    
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
      
    OPEN pc_ref FOR SELECT resp_str FROM dual;
      
    RETURN ls_returncode;
end;
/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 09.09.2019
   Purpose    : send iOS Push Notification with title
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, title in varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';

    url varchar2(200);
    content VARCHAR2(4000);
    resp_str varchar2(4000);
 
BEGIN
 
    CBS.PKG_PARAMETRE.deger('IOS_PUSH_URL',url);
    PKG_REST.ADDPARAM(content,'message',message);
    PKG_REST.ADDPARAM(content,'regId',reg_id);
    PKG_REST.ADDPARAM(content,'title',title);
    resp_str := PKG_REST.SENDREQUEST(url, 'POST', content);
  
    OPEN pc_ref FOR SELECT resp_str FROM dual;
  
    RETURN ls_returncode;
end;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 20.04.2021
   Purpose    : add Email Notification to Queue with new status
******************************************************************************/
FUNCTION addEmailToQueueNew(message IN CLOB, subject IN VARCHAR2, sender IN VARCHAR2, recipients IN RecipientList, contentType IN VARCHAR2, 
    emailTemplate IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB ,pd_Date date default pkg_muhasebe.banka_tarihi_bul) RETURN VARCHAR2 IS --bahianab CBS-649  01042022
    
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number;
    ld_tarih date; --bahianab cbs-629 03032022
    
BEGIN
    IF  recipients.count <= 0 THEN
       return ls_returncode;
    END IF;
    IF recipients(1) is null or TRIM(recipients(1)) = '' THEN
       return ls_returncode;
    END IF;
    select seq_notif.nextVal into notif_id from dual;
    ld_tarih:= nvl(pd_Date,cbs.pkg_muhasebe.Banka_Tarihi_Bul);  --bahianab cbs-649 01042022 --bahianab cbs-629 03032022 
    
    insert into TBL_NOTIFICATION
    (NOTIF_ID, MSG_CONTENT, MSG_SUBJECT, SENDER, CONTENT_TYPE, ATTACHMENT_NAME, ATTACHMENT, NOTIF_TYPE_CD, TEMPLATE, BANK_DATE) --bahianab cbs-629 03032022
    values
    (notif_id, message, subject, sender, contentType, attachname, attach, 'EMAIL', emailTemplate, ld_tarih); --bahianab cbs-629 03032022
    
    for i in 1..recipients.count loop

        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, RECIPIENT, STATUS_CD)
        values
        (notif_id, seq_notif_result.nextVal, recipients(i), 'sQUEUED2');
    end loop;
    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        LOG_AT('ADD_EMAIL_QUEUE', SQLERRM || ' ' || emailTemplate , dbms_utility.format_error_backtrace);
END;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 20.04.2021
   Purpose    : add Sms Notification to Queue with new status
******************************************************************************/
FUNCTION addSMSToQueueNew(message IN VARCHAR2, recipients IN RecipientList) RETURN VARCHAR2 IS
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number;
    ld_tarih date; --bahianab cbs-629 03032022
    
BEGIN
    select seq_notif.nextVal into notif_id from dual;
    ld_tarih:=cbs.pkg_muhasebe.Banka_Tarihi_Bul; --bahianab cbs-629 03032022
    
    insert into TBL_NOTIFICATION
    (NOTIF_ID, MSG_CONTENT, NOTIF_TYPE_CD, BANK_DATE) --bahianab cbs-629 03032022
    values
    (notif_id, message, 'SMS', ld_tarih); --bahianab cbs-629 03032022
    
    for i in 1..recipients.count loop

        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, RECIPIENT, STATUS_CD)
        values
        (notif_id, seq_notif_result.nextVal, recipients(i), 'sQUEUED2');
    end loop;
    
    RETURN ls_returncode;
END;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 06.04.2021
   Purpose    : add Push Notification to Queue with new status
******************************************************************************/
FUNCTION addPushToQueueNew(message IN VARCHAR2, pn_customer_no IN NUMBER) RETURN VARCHAR2 IS
    
    ls_returncode        VARCHAR2 (3)  := '000';
    notif_id number; 
    ld_tarih date; --bahianab cbs-629 03032022
    
      CURSOR cur_devices IS
      SELECT * FROM CORPINT2.TBL_DEVICE 
          WHERE person_id in (SELECT person_id FROM CORPINT2.TBL_IDENTIFICATION WHERE customer_no = pn_customer_no and status_cd= 'sENAB') and status_cd= 'sACTIVE';
      rec_devices cur_devices%rowtype;
    TYPE person_notifs IS TABLE OF NUMBER INDEX BY VARCHAR2(30);
    person_notifs_list person_notifs ;
BEGIN
   
    OPEN cur_devices;
   LOOP
      FETCH cur_devices INTO rec_devices;
      EXIT WHEN cur_devices%NOTFOUND;
      
        IF NOT person_notifs_list.EXISTS(rec_devices.Person_id || '_id')THEN
           select seq_notif.nextVal into notif_id from dual;
           ld_tarih:=cbs.pkg_muhasebe.Banka_Tarihi_Bul; --bahianab cbs-629 03032022
           
            insert into TBL_NOTIFICATION
            (NOTIF_ID, MSG_CONTENT, NOTIF_TYPE_CD, MSG_SUBJECT,PERSON_ID, BANK_DATE,CUSTOMER_NO) --bahianab cbs-629 03032022
            values
            (notif_id, message, 'PUSH', 'DemirBank',rec_devices.Person_id,ld_tarih,pn_customer_no); --bahianab cbs-629 03032022
            person_notifs_list(rec_devices.Person_id || '_id') :=notif_id;
        ELSE
           notif_id :=person_notifs_list(rec_devices.Person_id || '_id');
        END IF;
    
        --bahianab cbs-469 fixing  duplicated push notifications
        insert into TBL_NOTIFICATION_RESULT
        (NOTIF_ID, NOTIF_RESULT_ID, RECIPIENT, PERSON_ID, DEVICE_ID, STATUS_CD,CUSTOMER_NO)
        values
        (notif_id, seq_notif_result.nextVal, rec_devices.registr_id, rec_devices.Person_id, rec_devices.Device_id, 'sQUEUED2',pn_customer_no);
        
        END LOOP;
       CLOSE cur_devices;
        
    RETURN ls_returncode;
END;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 06.04.2021
   Purpose    : Get Customer Devices
******************************************************************************/
FUNCTION getCustDevice (PN_CUSTOMER_NO IN NUMBER) RETURN VARCHAR2 IS

      CURSOR cur_devices IS
      SELECT registr_id FROM CORPINT2.TBL_DEVICE WHERE person_id in (SELECT person_id FROM CORPINT2.TBL_IDENTIFICATION WHERE customer_no = pn_customer_no and status_cd= 'sENAB') and status_cd= 'sACTIVE';
      
   rec_devices   cur_devices%rowtype;
   ls_device     varchar2(300);
   
   BEGIN
   OPEN cur_devices;
   LOOP
      FETCH cur_devices INTO rec_devices;
      EXIT WHEN cur_devices%NOTFOUND;
      
      IF rec_devices.registr_id IS NOT NULL
      THEN
         ls_device := rec_devices.registr_id;
      END IF;
   END LOOP;
   CLOSE cur_devices;

   RETURN ls_device;
   END;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 19.08.2021
   Purpose    : Split text
******************************************************************************/
  FUNCTION SplitText (p_text IN  VARCHAR2, p_delimeter  IN  VARCHAR2 DEFAULT ';') RETURN RecipientList IS
      l_array  RecipientList   := RecipientList();
      l_text   VARCHAR2(300) := p_text;
      l_idx    NUMBER;
      
    BEGIN
      l_array.delete;

      IF l_text IS NULL THEN
        RAISE_APPLICATION_ERROR(-20000, 'P_TEXT parameter cannot be NULL');
      END IF;

      WHILE l_text IS NOT NULL LOOP
        l_idx := INSTR(l_text, p_delimeter);
        l_array.extend;
        IF l_idx > 0 THEN
          l_array(l_array.last) := SUBSTR(l_text, 1, l_idx - 1);
          l_text := SUBSTR(l_text, l_idx + 1);
        ELSE
          l_array(l_array.last) := l_text;
          l_text := NULL;
        END IF;
      END LOOP;
      RETURN l_array;
    END SplitText;
 end pkg_notification;
/

