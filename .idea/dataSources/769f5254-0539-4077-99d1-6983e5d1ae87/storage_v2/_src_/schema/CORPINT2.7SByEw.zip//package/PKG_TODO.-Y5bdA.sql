create PACKAGE          Pkg_Todo IS
type cursorreferencetype is ref cursor;

function createtaxpayments (ps_trancd                varchar2,
                               ps_makerid             varchar2,
                               ps_status              varchar2,
                               ps_tax_from_account    varchar2,
                               ps_tax_tin             varchar2,
                               ps_tax_address_id      varchar2,
                               ps_tax_amount          varchar2,
                               ps_tax_currency        varchar2,
                               ps_tax_to_account      varchar2,
                               ps_tax_description     varchar2,
                               pc_ref                 out   cursorreferencetype) return varchar2; 

END Pkg_Todo;
/

