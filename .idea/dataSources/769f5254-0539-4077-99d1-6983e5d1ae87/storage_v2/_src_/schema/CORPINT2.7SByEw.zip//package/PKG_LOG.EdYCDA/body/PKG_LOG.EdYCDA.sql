create PACKAGE BODY          Pkg_Log IS

TYPE CursorReferenceType IS REF CURSOR;

PROCEDURE AddLog(pid1 clob,
                 pid2 clob DEFAULT NULL,
                 pid3 clob DEFAULT NULL,
                 pid4 clob DEFAULT NULL) is
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    INSERT INTO TBL_LOG
    (FIELD1, FIELD2, FIELD3, FIELD4)
    VALUES
    (pid1, pid2, pid3, pid4);

    COMMIT;
END;

END Pkg_Log;
/

