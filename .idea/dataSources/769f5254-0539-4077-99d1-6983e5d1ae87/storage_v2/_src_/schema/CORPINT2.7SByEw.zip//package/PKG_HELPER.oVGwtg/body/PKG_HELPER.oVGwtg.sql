create PACKAGE BODY                   PKG_HELPER IS
-------------------------------------------------------------------
FUNCTION getNumberFromVarchar2(ps_number IN VARCHAR2, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN NUMBER IS
    ls_decimal_point varchar2(1);
    ls_thousand_point varchar2(1);
    
    ls_number varchar2(100) := substr(ps_number, 1, 100);
BEGIN
    SELECT SUBSTR(VALUE, 1, 1), SUBSTR(VALUE, 2, 1) INTO ls_decimal_point, ls_thousand_point
    FROM nls_session_parameters
    WHERE parameter = 'NLS_NUMERIC_CHARACTERS';
    
    ls_number := replace(ps_number, SUBSTR(ps_numeric_chars, 2, 1), ''); --remove thousands point
    ls_number := replace(ls_number, SUBSTR(ps_numeric_chars, 1, 1), ls_decimal_point); --replace decimal point to nls one
    
    RETURN to_number(ls_number);
EXCEPTION
    WHEN OTHERS THEN
        return null;
END;
-------------------------------------------------------------------
FUNCTION getVarchar2FromNumber(ps_number IN NUMBER, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN VARCHAR2 IS
    ls_decimal_point varchar2(1);
    ls_thousand_point varchar2(1);

    ls_number varchar2(100);
BEGIN
    SELECT SUBSTR(VALUE, 1, 1), SUBSTR(VALUE, 2, 1) INTO ls_decimal_point, ls_thousand_point
    FROM nls_session_parameters
    WHERE parameter = 'NLS_NUMERIC_CHARACTERS';

    ls_number := trim(to_char(ps_number, '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_thousand_point || '999' || ls_decimal_point || '99'));
    
    IF (length(ps_numeric_chars)=1) THEN
        ls_number := replace(ls_number, ls_thousand_point, ''); --remove thousands point
        return replace(ls_number, ls_decimal_point, ps_numeric_chars);
    ELSIF (length(ps_numeric_chars)=2) THEN
        ls_number := replace(ls_number, ls_thousand_point, 'X'); --change thousands point to X temporarily
        ls_number := replace(ls_number, ls_decimal_point, SUBSTR(ps_numeric_chars, 1, 1)); --change real decimal point to param
        return replace(ls_number, 'X', SUBSTR(ps_numeric_chars, 2, 1));
    ELSE
        return ls_number;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        return null;
END;
-------------------------------------------------------------------
FUNCTION getCustomerNoFromPerson(pn_personid IN NUMBER) RETURN NUMBER IS
    ln_customer_no number;
BEGIN

    select customer_no into ln_customer_no
    from tbl_identification
    where person_id=pn_PersonId;

    return ln_customer_no;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        return 0;
    WHEN OTHERS THEN
        pkg_log.addlog('getCustomerNoFromPerson', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return null;
END;
-------------------------------------------------------------------
FUNCTION getFullNameFromPerson(pn_personid IN NUMBER) RETURN VARCHAR2 IS
    ls_fullname tbl_identification.fullname%type;
BEGIN

    select fullname into ls_fullname
    from tbl_identification 
    where person_id=to_number(pn_PersonId);

    return ls_fullname;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        return null;
    WHEN OTHERS THEN
        pkg_log.addlog('getFullNameFromPerson', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return null;
END;
-------------------------------------------------------------------
FUNCTION getBankDatePlusTime RETURN DATE IS
BEGIN
    return PKG_MUHASEBE.BANKA_TARIHI_BUL + (sysdate - trunc(sysdate));
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('getBankDatePlusTime', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return null;
END;
-------------------------------------------------------------------
FUNCTION getConfigValueFromKey(ps_key IN VARCHAR2) RETURN VARCHAR2 IS
    ls_val TBL_CONFIGURATION.VALUE%type;
BEGIN
    select value into ls_val
    from TBL_CONFIGURATION
    where key=ps_key
    and rownum=1;

    return ls_val;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        return '';
    WHEN OTHERS THEN
        pkg_log.addlog('getConfigValueFromKey', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return null;
END;
-------------------------------------------------------------------
FUNCTION getAuthorizedUsers(pn_customer_no IN VARCHAR2,
                            pc_ref      OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode   VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
    
    /*replaced by GulkaiyrK DEN-17 -select auth_cd, wm_concat(pkg_helper.getfullnamefromperson(aa.person_id)) full_names from tbl_identification aa, tbl_person_auth bb*/ 
        select auth_cd, LISTAGG(corpint2.pkg_helper.getfullnamefromperson(aa.person_id), ', ') WITHIN GROUP (ORDER BY null)  
        from corpint2.tbl_identification aa, corpint2.tbl_person_auth bb 
        where aa.person_id = bb.person_id
        and instr(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level.status'), auth_cd) > 1
        and status_cd in ('sENAB', 'sLOCKED')
        and aa.customer_no=1013
        group by auth_cd;

    return ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('getAuthorizedUsers', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
END;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Set Security Info
******************************************************************************/
FUNCTION SetSecurityInfo(pn_PersonId   IN VARCHAR2,
                         ps_SecurityInfo  IN CLOB) RETURN VARCHAR2 IS
    ls_returncode   VARCHAR2(3):='000';
    ln_PersonId NUMBER:=TO_NUMBER(pn_PersonId);
    ln_count NUMBER;
BEGIN

    SELECT COUNT(*)
    INTO ln_count
    FROM TBL_IBSECURITY
    WHERE PERSON_ID=ln_PersonId;

    IF ln_count=0 THEN

       INSERT INTO TBL_IBSECURITY
       VALUES(ln_PersonId, SYSDATE, ps_SecurityInfo);

    ELSE

        UPDATE TBL_IBSECURITY
        SET SECURITY_INFO = ps_SecurityInfo,
            LAST_UPDATE_DATE = SYSDATE
         WHERE PERSON_ID = ln_PersonId;
    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('SetSecurityInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Get Security Info
******************************************************************************/
FUNCTION GetSecurityInfo(pn_PersonId IN VARCHAR2,
                         pc_ref      OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR 
        SELECT * FROM TBL_IBSECURITY
        WHERE PERSON_ID=to_number(pn_PersonId);

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('GetSecurityInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Get Security Info
******************************************************************************/
FUNCTION GetJSONValue(ps_source IN VARCHAR2, ps_key IN VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(500):='';
    ln_index number:=0;
    ln_index2 number:=0;
BEGIN
    -- find key index from source
    select instr(ps_source, '"' || ps_key || '"') into ln_index from dual;

    -- if there is no key then return empty string
    if (ln_index = 0) then
        return '';
    end if;

    select instr(ps_source, '"', ln_index + length(ps_key) + 1) into ln_index from dual;

    -- ensure that this key is key
    select substr(ps_source, ln_index + 1, instr(ps_source, '"', ln_index + 1) - ln_index - 1) into ls_returncode from dual;

    if (instr(ls_returncode, ',') > 0 or instr(ls_returncode, ':') = 0) then
        return '';
    end if;

    select instr(ps_source, '"', ln_index + 1) into ln_index from dual;

    -- if there is no key then return empty string
    if (ln_index = 0) then
        return '';
    end if;

    select instr(ps_source, '"', ln_index + 1) into ln_index2 from dual;

    select substr(ps_source, ln_index + 1, instr(ps_source, '"', ln_index + 2) - ln_index - 1) into ls_returncode from dual;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('GetJSONValue', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '';
END;
-------------------------------------------------------------------

/******************************************************************************
   Created By : Aibek Osmonov
   Date       : 28.07.2016
   Purpose    : returns QRCodes registered wich are not expired yet
******************************************************************************/
FUNCTION getQRCode(pn_qr_value IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is
    ls_returncode varchar2(3):='000';
begin
    OPEN pc_ref FOR
        SELECT * FROM tbl_qrcode
        where QRCODE_VALUE=pn_qr_value AND expiry_date > sysdate
        order by QRCODE_ID desc
        OFFSET 0 ROWS FETCH NEXT 1 ROWS ONLY;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getQrCode', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Aibek Osmonov
   Date       : 28.07.2016
   Purpose    : inserts new qrcode value
******************************************************************************/
FUNCTION setQRCode(pn_qr_value IN VARCHAR2, pn_personid IN NUMBER, pn_qr_data IN VARCHAR2, 
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is
    ls_returncode varchar2(3):='000';
    ln_person_id_in number;
    l_count NUMBER;
begin
  IF pn_personid =0 THEN
     ln_person_id_in:=NULL;
  ELSE
    ln_person_id_in:=pn_personid;
  END IF;
  IF ln_person_id_in IS NULL     THEN
     SELECT count(*) into l_count FROM CORPINT2.TBL_QRCODE WHERE QRCODE_VALUE=pn_qr_value AND PERSON_ID IS NULL AND QRDATA='INIT'  AND expiry_date > sysdate;
     IF l_count=0 THEN 
         INSERT INTO CORPINT2.TBL_QRCODE (
                QRCODE_ID, 
                QRCODE_VALUE,
                QRDATA,
                PERSON_ID,
                CREATED_DATE, 
                EXPIRY_DATE) 
            VALUES (
                seq_qrcode.nextVal,
                pn_qr_value,
                'INIT',
                ln_person_id_in,
                SYSDATE,
                SYSDATE + interval '30' minute);
     END IF; 
 ELSIF pn_qr_data='AUTH' THEN
   UPDATE CORPINT2.TBL_QRCODE
    SET PERSON_ID=pn_personid, QRDATA=pn_qr_data
    WHERE QRCODE_VALUE=pn_qr_value AND (PERSON_ID IS NULL or PERSON_ID=ln_person_id_in) AND (QRDATA='INIT' or QRDATA='AUTH')    AND expiry_date > sysdate;
    IF sql%rowcount = 0 then
       ls_returncode:='996';
    END IF;
 ELSIF pn_qr_data='USED' THEN
   UPDATE CORPINT2.TBL_QRCODE
    SET QRDATA=pn_qr_data
    WHERE QRCODE_VALUE=pn_qr_value AND  PERSON_ID=ln_person_id_in AND QRDATA='AUTH'   AND expiry_date > sysdate;
    IF sql%rowcount = 0 then
       ls_returncode:='997';
    END IF;
 ELSE
    ls_returncode:='998';
 END IF;
    return ls_returncode;
exception
    when others then
        pkg_log.addlog('setQRCode', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;
-------------------------------------------------------------------

/******************************************************************************
   Created By : ErkinZununbekov
   Date       : 12.03.2017
   Purpose    : get list of user authorities
******************************************************************************/
FUNCTION getUserAuthorities(pn_personId IN VARCHAR2, 
                                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is
    ls_returncode varchar2(3):='000';
begin
    OPEN pc_ref FOR
        SELECT AUTH_CD FROM TBL_PERSON_AUTH
        where person_id=to_number(pn_personId);

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getUserAuthorities', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;
-------------------------------------------------------------------

END PKG_HELPER;
/

