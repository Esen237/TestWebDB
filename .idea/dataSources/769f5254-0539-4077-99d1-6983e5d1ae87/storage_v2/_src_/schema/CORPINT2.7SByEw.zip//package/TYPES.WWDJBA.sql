create package types AS 
	type rc is ref cursor; 
end;
/

