create PACKAGE BODY          Pkg_Todo IS

function createtaxpayments (ps_trancd                varchar2,
                               ps_makerid             varchar2,
                               ps_status              varchar2,
                               ps_tax_from_account    varchar2,
                               ps_tax_tin             varchar2,
                               ps_tax_address_id      varchar2,
                               ps_tax_amount          varchar2,
                               ps_tax_currency        varchar2,
                               ps_tax_to_account      varchar2,
                               ps_tax_description     varchar2,
                               pc_ref                 out   cursorreferencetype) return varchar2
is
 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 ls_paycode VARCHAR2(500);

 ls_status VARCHAR (10); 

BEGIN

 OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

 select corpint2.seq_txtodo.nextval into ln_txid from dual;


  INSERT INTO TBL_TAX_PAYMENTS_TODO
   (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   TAX_FROM_ACCOUNT,TAX_TIN,TAX_ADDRESS_ID,TAX_AMOUNT,TAX_CURRENCY,
   TAX_TO_ACCOUNT,TAX_DESCRIPTION) 
  VALUES
   (ln_txid,ps_trancd,ps_makerid,SYSDATE,ps_status,
    ps_tax_from_account, ps_tax_tin, ps_tax_address_id, ps_tax_amount, ps_tax_currency,
    ps_tax_to_account, ps_tax_description);

   OPEN pc_ref FOR select ln_txid from dual;
   
   RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS THEN
    cbs.log_at('createtaxpayments', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    RETURN '999';
END;

END Pkg_Todo;
/

