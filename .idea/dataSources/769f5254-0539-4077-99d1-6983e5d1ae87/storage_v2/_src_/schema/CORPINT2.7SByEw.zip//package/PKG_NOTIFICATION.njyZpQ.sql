create PACKAGE                   Pkg_Notification IS
TYPE CursorReferenceType IS REF CURSOR;
TYPE DeviceList IS VARRAY(100) OF NUMBER;
TYPE RecipientList IS VARRAY(100) OF VARCHAR2(300);--bahianab

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send Android Push Notification
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send Android Push Notification
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send iOS Push Notification
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send iOS Push Notification
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add Push Notification to Queue
******************************************************************************/
FUNCTION addPushToQueue(message IN VARCHAR2, devices IN DeviceList) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued push notifications
******************************************************************************/
FUNCTION sendQueuedPush(pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send plain text email
******************************************************************************/
FUNCTION sendEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send plain text email with clob attachment
******************************************************************************/
FUNCTION sendEmailClobAttach(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send html email
******************************************************************************/
FUNCTION sendHtmlEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send html email with attachments TODO
******************************************************************************/
FUNCTION sendHtmlEmail(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, mtemplate IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send html email with clob attachment
******************************************************************************/
FUNCTION sendHtmlEmailClobAttach(receiver IN VARCHAR2, subject IN VARCHAR2, message IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add email to queue
******************************************************************************/
FUNCTION addEmailToQueue(message IN VARCHAR2, subject IN VARCHAR2, sender IN VARCHAR2, recipients IN RecipientList, contentType IN VARCHAR2, emailTemplate IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued emails
******************************************************************************/
FUNCTION sendQueuedEmails(pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send sms
******************************************************************************/
FUNCTION sendSMS(receiver IN VARCHAR2, message IN VARCHAR2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 13.01.2017
   Purpose    : send otp
******************************************************************************/
FUNCTION sendOTP(receiver IN VARCHAR2, message IN VARCHAR2, person_id IN VARCHAR2, otp IN VARCHAR2,pc_ref OUT cursorreferencetype) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add sms to queue
******************************************************************************/
FUNCTION addSMSToQueue(message IN VARCHAR2, recipients IN RecipientList) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send queued sms messages
******************************************************************************/
FUNCTION sendQueuedSMS(pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 30.05.2019
   Purpose    : send Push Notification to Customer Devices
******************************************************************************/
FUNCTION sendPushNotification(message IN VARCHAR2, pn_customer_no IN NUMBER, title varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 09.09.2019
   Purpose    : send Android Push Notification with title
******************************************************************************/
FUNCTION sendAndroidPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, title varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   Created By : Nurzalat Alimzhan uulu
   Date       : 09.09.2019
   Purpose    : send iOS Push Notification with title
******************************************************************************/
FUNCTION sendIOSPushNotification(message IN VARCHAR2, reg_id IN VARCHAR2, title in varchar2, pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 20.04.2021
   Purpose    : add Email Notification to Queue with new status
******************************************************************************/
FUNCTION addEmailToQueueNew(message IN CLOB, subject IN VARCHAR2, sender IN VARCHAR2, recipients IN RecipientList, contentType IN VARCHAR2,emailTemplate IN VARCHAR2, attachname IN VARCHAR2, attach IN CLOB ,pd_Date date default pkg_muhasebe.banka_tarihi_bul) RETURN VARCHAR2 ; --bahianab  01042022 pd_Date default pkg_muhasebe.banka_tarihi_bul eklendi
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 20.04.2021
   Purpose    : add Sms Notification to Queue with new status
******************************************************************************/
FUNCTION addSMSToQueueNew(message IN VARCHAR2, recipients IN RecipientList) RETURN VARCHAR2;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 06.04.2021
   Purpose    : add Push Notification to Queue with new status
******************************************************************************/
FUNCTION addPushToQueueNew(message IN VARCHAR2, pn_customer_no IN NUMBER) RETURN VARCHAR2;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 06.04.2021
   Purpose    : Get Customer Devices
******************************************************************************/
FUNCTION getCustDevice (PN_CUSTOMER_NO IN NUMBER) RETURN VARCHAR2;
/******************************************************************************
   Created By : Bahiana Bektemir kyzy
   Date       : 19.08.2021
   Purpose    : Split text
******************************************************************************/
FUNCTION SplitText (p_text IN  VARCHAR2, p_delimeter  IN  VARCHAR2 DEFAULT ';') RETURN RecipientList;  
END pkg_notification;
/

