create package          reencode_pkg is
   FUNCTION reencode(string IN VARCHAR2) RETURN VARCHAR2;
end;
/

