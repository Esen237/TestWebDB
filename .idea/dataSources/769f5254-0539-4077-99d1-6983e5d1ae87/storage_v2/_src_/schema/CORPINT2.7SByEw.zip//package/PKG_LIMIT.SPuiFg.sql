create PACKAGE          Pkg_Limit IS

TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : if there is no limit, then creates new limit from default value
******************************************************************************/
function initLimitInfo(pn_PersonId IN VARCHAR2,
                        ps_tran_cd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : removes additional rows for limit, and resets limit to default
******************************************************************************/
function resetPersonLimit(pn_PersonId IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : removes additional rows for limit, and resets limit to default
******************************************************************************/
function resetCustomerLimit(pn_PersonId IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current person, empty if there are no data
******************************************************************************/
function getPersonLimit(pn_PersonId IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current person, empty if there are no data
******************************************************************************/
function getPersonLimitOver(pn_PersonId IN VARCHAR2,
                        ps_TranCd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current customer, empty if there are no data
******************************************************************************/
function getCustomerLimit(pn_PersonId IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns all limits of current customer, empty if there are no data
******************************************************************************/
function getAllLimit(pn_PersonId IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 26.02.2016
   Purpose    : return all bank limits
******************************************************************************/
function getBankLimit(pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 26.02.2016
   Purpose    : return all limits groupped
******************************************************************************/
function getGrouppedLimit(pn_PersonId IN VARCHAR2, pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : checks available limit, compares with current currency
******************************************************************************/
function checkLimit(pn_PersonId IN VARCHAR2,
                    ps_TranCd IN VARCHAR2,
                    pn_Amount IN VARCHAR2,
                    ps_CurrencyCd IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : updates limits with params, compares with current currency
******************************************************************************/
function updateLimit(pn_PersonId IN VARCHAR2,
                     ps_TranCd IN VARCHAR2,
                     pn_Amount IN VARCHAR2,
                     ps_CurrencyCd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 03.03.2016
   Purpose    : change limits
******************************************************************************/
function changeLimit(pn_PersonId IN VARCHAR2,
                     ps_TranCd IN VARCHAR2,
                     ps_Type IN VARCHAR2,
                     pn_Amount IN VARCHAR2,
                     ps_CurrencyCd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2;

END Pkg_Limit;
/

