create PACKAGE BODY          Pkg_Auth IS

/******************************************************************************
 Created By : Aisuluu Kasymova
 Date : 15.09.2015
 Purpose : validate user against IBSecurity parameters
******************************************************************************/
FUNCTION CheckIBSecurity(pn_personid IN NUMBER, pn_ClientIP IN VARCHAR2) RETURN VARCHAR2 IS

 CURSOR cursor_security(pn_personid NUMBER) IS
 SELECT * FROM TBL_IBSECURITY i
 WHERE i.PERSON_ID=pn_personid;
 
 row_security cursor_security%ROWTYPE;
 ls_returncode VARCHAR2(3):='000';
 TransactionError EXCEPTION;
 ls_sysday VARCHAR2(1):=TO_CHAR(SYSDATE,'D');
 
 BEGIN
 
 OPEN cursor_security(pn_personid);
 FETCH cursor_security INTO row_security;
 IF cursor_security%FOUND THEN
 IF PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'IP_STATUS')='E' THEN
 ls_returncode:=CORPINT.pkg_cint_main.IpCheck(pn_ClientIP,PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'IP_1_1'),PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'IP_1_2'),PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'IP_2_1'),PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'IP_2_2'));
 IF ls_returncode<>'000' THEN
 RAISE TransactionError;
 END IF;
 END IF;

 IF PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'TIME_STATUS')='E' THEN
 ls_returncode:=CORPINT.pkg_cint_main.TimeCheck(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'START_TIME'),PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'END_TIME'));
 IF ls_returncode<>'000' THEN
 RAISE TransactionError;
 END IF;
 END IF;

 IF (ls_sysday='2' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'MONDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'MONDAY'),'X')='X')) or 
 (ls_sysday='3' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'TUESDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'TUESDAY'),'X')='X')) or 
 (ls_sysday='4' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'WEDNESDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'WEDNESDAY'),'X')='X')) or 
 (ls_sysday='5' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'THURSDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'THURSDAY'),'X')='X')) or 
 (ls_sysday='6' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'FRIDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'FRIDAY'),'X')='X')) or 
 (ls_sysday='7' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'SATURDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'SATURDAY'),'X')='X')) or 
 (ls_sysday='1' and (PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'SUNDAY')='E' or nvl(PKG_HELPER.GETJSONVALUE(row_security.SECURITY_INFO, 'SUNDAY'),'X')='X')) then
 ls_returncode:='000';
 ELSE
 ls_returncode:='102';
 RAISE TransactionError;
 END IF;
 END IF;
 CLOSE cursor_security;

 RETURN ls_returncode;
EXCEPTION
 WHEN TransactionError THEN
 pkg_log.addlog('CheckIBSecurity', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN ls_returncode;
END;

/******************************************************************************
 Created By : Aisuluu Kasymova
 Date : 11.11.2015
 Purpose : check submitted OTP number
******************************************************************************/
FUNCTION CheckOTP(pn_personid IN NUMBER, ps_otp_pwd IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_otp_pwd VARCHAR2(35);
 ln_otp_id NUMBER:=0;
 ln_count NUMBER;
BEGIN
 SELECT OTP_ID INTO ln_otp_id FROM TBL_OTP
 WHERE CREATED_DATE = (SELECT MAX(CREATED_DATE) FROM TBL_OTP
 WHERE PERSON_ID = pn_personid) and rownum=1;
 
 IF ln_otp_id=0 THEN
 RETURN '061';
 END IF;
 
 SELECT OTP_PWD INTO ls_otp_pwd FROM TBL_OTP
 WHERE OTP_ID=ln_otp_id;
 
 IF ls_otp_pwd <> ps_otp_pwd THEN
 RETURN '062';
 END IF;

 SELECT COUNT(1) INTO ln_count
 FROM TBL_OTP
 WHERE OTP_ID = ln_otp_id
 AND EXPIRY_DATE>SYSDATE;

 IF ln_count=0 THEN
 RETURN '063';
 END IF;
 
 RETURN ls_returncode;
 
 EXCEPTION
 WHEN OTHERS THEN
 pkg_log.addlog('CheckOTP', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';

END;

/******************************************************************************
 Created By : Aisuluu Kasymova
 Date : 12.11.2015
 Purpose : check if user has etoken
******************************************************************************/
FUNCTION CheckEToken(ps_username IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_etoken VARCHAR2(22):='';

BEGIN
 SELECT DIGIPASS
 INTO ls_etoken
 FROM TBL_TOKEN T
 INNER JOIN TBL_IDENTIFICATION I
 ON T.PERSON_ID=I.PERSON_ID
 WHERE I.USERNAME = ps_username or I.USERALIAS = ps_username;

 OPEN pc_ref FOR SELECT ls_etoken FROM dual;
 
 RETURN ls_returncode;
 
 EXCEPTION
 WHEN OTHERS THEN
 OPEN pc_ref FOR SELECT ls_etoken FROM dual;
 pkg_log.addlog('CheckEToken', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN ls_etoken;
END;

/******************************************************************************
 Created By : Aisuluu Kasymova
 Date : 12.11.2015
 Purpose : Get Token Data
******************************************************************************/
FUNCTION GetTokenData(ps_username IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ls_digidata VARCHAR2(255);
 ls_digipass VARCHAR2(22);
 otp_validity_period NUMBER;
 
BEGIN
 SELECT DP_DATA,DIGIPASS,OTP_VALIDITY_PERIOD
 INTO ls_digidata,ls_digipass,otp_validity_period
 FROM TBL_TOKEN T
 INNER JOIN TBL_IDENTIFICATION I
 ON T.PERSON_ID=I.PERSON_ID
 WHERE I.USERNAME = ps_username or I.USERALIAS = ps_username;

 OPEN pc_ref FOR
 SELECT ls_digidata,ls_digipass,otp_validity_period FROM dual;

 RETURN ls_returncode;

EXCEPTION
 WHEN NO_DATA_FOUND THEN
 ls_returncode:='112';--token no found
 OPEN pc_ref FOR SELECT ls_digidata,ls_digipass FROM dual;
 RETURN ls_returncode;
 WHEN OTHERS THEN
 pkg_log.addlog('GetTokenData', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';
END;

/******************************************************************************
 Created By : Aisuluu Kasymova
 Date : 12.11.2015
 Purpose : Set Token Data
******************************************************************************/
FUNCTION SetTokenData(ps_digipass IN VARCHAR2, ps_digidata IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';

BEGIN
 UPDATE TBL_TOKEN
 SET DP_DATA=ps_digidata
 WHERE RTRIM(digipass)=RTRIM(ps_digipass);
 
 RETURN ls_returncode;

 EXCEPTION
 WHEN OTHERS THEN
 pkg_log.addlog('SetTokenData', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';
 
END;

/******************************************************************************
 Created By : Almas Nurkhozhayev
 Date : 04.03.2016
 Purpose : Set UserAlias
******************************************************************************/
FUNCTION SetUserAlias(ps_person_id IN VARCHAR2, ps_username IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ln_count number:=0;
 lx_existing_alias Exception;
BEGIN
 
 select count(1) into ln_count
 from tbl_identification
 where upper(trim(username)) = upper(trim(ps_username))
 and upper(trim(useralias)) = upper(trim(ps_username));

 -- check existance of entere username
 if (ln_count > 0) then
 raise lx_existing_alias;
 end if;

 -- make changes
 update tbl_identification
 set useralias=ps_username
 where person_id=to_number(ps_person_id);

 RETURN ls_returncode;
EXCEPTION
 WHEN lx_existing_alias THEN
 RETURN '011';
 WHEN OTHERS THEN
 pkg_log.addlog('SetUserAlias', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';
END;

/******************************************************************************
 Created By : Almas Nurkhozhayev
 Date : 04.03.2016
 Purpose : Set Password
******************************************************************************/
FUNCTION SetPassword(ps_person_id IN VARCHAR2, ps_password_old IN VARCHAR2, ps_password IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ln_count number:=0;
 lx_password_length Exception;
 lx_user_not_found Exception;
 lx_not_old_password Exception;
BEGIN
 
 -- check if encoded password not 32 length
 if length(ps_password)<>32 then
 raise lx_password_length;
 end if;

 -- check existance of entere username
 select count(1) into ln_count
 from tbl_identification
 where person_id=to_number(ps_person_id)
 and upper(trim(PASSCODE)) = upper(trim(ps_password_old));

 if (ln_count = 0) then
 raise lx_user_not_found;
 end if;

 -- check entered password from history
 SELECT count(1) into ln_count
 FROM TBL_PWD_HISTORY
 WHERE PERSON_ID=TO_NUMBER(ps_person_id)
 AND PASSTYPE='PASSWORD'
 AND ps_password IN (SELECT PASSWD
 FROM( SELECT ROWNUM, a.DLM tarih,PASSWD
 FROM TBL_PWD_HISTORY a
 WHERE PERSON_ID=TO_NUMBER(ps_person_id)
 AND PASSTYPE='PASSWORD'
 ORDER BY dlm DESC)
 WHERE ROWNUM < to_number(PKG_HELPER.GETCONFIGVALUEFROMKEY('allowed.password.history'))
 );

 if (ln_count > 0) then
 raise lx_not_old_password;
 end if;

 -- make changes
 UPDATE TBL_IDENTIFICATION
 SET PASSCODE = ps_password, 
 EXPIREDATE = SYSDATE+60
 WHERE PERSON_ID = TO_NUMBER(ps_person_id);

 -- add history
 INSERT INTO TBL_PWD_HISTORY
 (PERSON_ID, PASSWD, PASSTYPE)
 VALUES
 (ps_person_id, ps_password, 'PASSWORD');

 RETURN ls_returncode;
EXCEPTION
 WHEN lx_password_length THEN
 RETURN '014';
 WHEN lx_user_not_found THEN
 RETURN '010';
 WHEN lx_not_old_password THEN
 RETURN '012';
 WHEN OTHERS THEN
 pkg_log.addlog('SetPassword', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';
END;

/******************************************************************************
 Created By : Almas Nurkhozhayev
 Date : 04.03.2016
 Purpose : Set Pin
******************************************************************************/
FUNCTION SetPin(ps_person_id IN VARCHAR2, ps_pin_old IN VARCHAR2, ps_pin IN VARCHAR2) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ln_count number:=0;
 lx_pin_length Exception;
 lx_user_not_found Exception;
 lx_not_old_pin Exception;
BEGIN
 
 -- check if encoded pin not 32 length
 if length(ps_pin)<>32 then
 raise lx_pin_length;
 end if;

 -- check existance of entere username
 select count(1) into ln_count
 from tbl_identification
 where person_id=to_number(ps_person_id)
 and upper(trim(PINCODE)) = upper(trim(ps_pin_old));

 if (ln_count = 0) then
 raise lx_user_not_found;
 end if;

 -- check entered pin from history
 SELECT count(1) into ln_count
 FROM TBL_PWD_HISTORY
 WHERE PERSON_ID=TO_NUMBER(ps_person_id)
 AND PASSTYPE='PIN'
 AND ps_pin IN (SELECT PASSWD
 FROM( SELECT ROWNUM, a.DLM tarih,PASSWD
 FROM TBL_PWD_HISTORY a
 WHERE PERSON_ID=TO_NUMBER(ps_person_id)
 AND PASSTYPE='PIN'
 ORDER BY dlm DESC)
 WHERE ROWNUM < to_number(PKG_HELPER.GETCONFIGVALUEFROMKEY('allowed.pin.history'))
 );

 if (ln_count > 0) then
 raise lx_not_old_pin;
 end if;

 -- make changes
 UPDATE TBL_IDENTIFICATION
 SET PINCODE = ps_pin, 
 EXPIREDATE = SYSDATE+60
 WHERE PERSON_ID = TO_NUMBER(ps_person_id);

 -- add history
 INSERT INTO TBL_PWD_HISTORY
 (PERSON_ID, PASSWD, PASSTYPE)
 VALUES
 (ps_person_id, ps_pin, 'PIN');

 RETURN ls_returncode;
EXCEPTION
 WHEN lx_pin_length THEN
 RETURN '015';
 WHEN lx_user_not_found THEN
 RETURN '009';
 WHEN lx_not_old_pin THEN
 RETURN '013';
 WHEN OTHERS THEN
 pkg_log.addlog('SetPin', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 RETURN '999';
END;

END Pkg_Auth;
/

