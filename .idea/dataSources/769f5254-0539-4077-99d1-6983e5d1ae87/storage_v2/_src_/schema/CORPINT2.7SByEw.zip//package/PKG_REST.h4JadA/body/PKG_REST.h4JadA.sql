create PACKAGE BODY          PKG_REST IS

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : send http request to rest service
******************************************************************************/
FUNCTION sendRequest(url IN VARCHAR2, method_type IN VARCHAR2, req_content IN VARCHAR2) RETURN VARCHAR2 IS
req utl_http.req;
resp utl_http.resp;
req_length number;
req_buffer varchar2(2000);
resp_buffer varchar2(4000);
resp_str varchar2(4000);
offset number:=1;
amount number:=2000;
ls_req_content varchar2(32767) := req_content || ' ';
BEGIN
  utl_http.set_body_charset('UTF-8');
  req := utl_http.begin_request(url, method_type,'HTTP/1.1');
  utl_http.set_header(req, 'User-Agent', 'Mozilla/4.0');

  --if req_content<>'' then
     -- req_length:=length(convert(req_content, 'UTF8', 'WE8ISO8859P1'));
      req_length:=length(convert(ls_req_content, 'UTF8', 'WE8ISO8859P1'));
      utl_http.set_header(req, 'Content-Type', 'application/x-www-form-urlencoded');
      
      if req_length <= 32767 then
        utl_http.set_header(req, 'Content-Length', req_length);  
        utl_http.write_text(req, ls_req_content);
      elsif req_length > 32767 then
        utl_http.set_header(req, 'Transfer_Encoding', 'chunked');
        
        while(offset<req_length) loop
            dbms_lob.read(ls_req_content,amount,offset, req_buffer);
            utl_http.write_text(req, req_buffer);
            offset:=offset+amount;
        end loop;
      end if;
  --end if;

  resp := utl_http.get_response(req);  
  resp_str:=''; 
  -- process the response from the HTTP call
  begin
    loop
      utl_http.read_line(resp, resp_buffer);
      resp_str:=resp_str || resp_buffer;
    end loop;
    utl_http.end_response(resp);
  exception
    when utl_http.end_of_body 
    then
      utl_http.end_response(resp);
  end;
  
  RETURN resp_str;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add varchar2 url parameter
******************************************************************************/
PROCEDURE addParam(params IN OUT VARCHAR2, param_key IN VARCHAR2, param_value IN VARCHAR2) IS
BEGIN
  IF params IS NOT NULL THEN
    params:=params || '&' || param_key || '=' || param_value;
  ELSE
    params:=params || param_key || '=' || param_value;
  END IF;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 28.10.2015
   Purpose    : add clob url parameter
******************************************************************************/
PROCEDURE addParam(params IN OUT VARCHAR2, param_key IN VARCHAR2, param_value IN CLOB) IS
BEGIN

  IF params IS NOT NULL THEN
    params:=params || '&' || param_key || '=' || param_value;
  ELSE
    params:=params || param_key || '=' || param_value;
  END IF;
END;

/******************************************************************************
Created By : Bahiana Bektemir kyzy
Date        : 27.05.2021
Purpose     : Send http request with JSON payload to rest service   
******************************************************************************/
FUNCTION sendRequestJson (ps_url           IN     VARCHAR2,
                          ps_method_type   IN     VARCHAR2,
                          ps_req_content   IN     VARCHAR2,
                          ps_res_content   IN OUT CLOB)
   RETURN VARCHAR2
IS
   req              UTL_HTTP.req;
   resp             UTL_HTTP.resp;
   req_length       NUMBER;
   req_buffer       VARCHAR2 (2000);
   resp_buffer      VARCHAR2 (32767) := '';
   offset           NUMBER := 1;
   amount           NUMBER := 2000;
   ls_req_content   VARCHAR2 (32767) := ps_req_content || ' ';
   ls_returncode    VARCHAR2 (3) := '000';
   
BEGIN

   -- Prepare a HTTP request
   req := UTL_HTTP.begin_request (ps_url, ps_method_type, ' HTTP/1.1');
   UTL_HTTP.set_header (req, 'User-Agent', 'Mozilla/4.0');
   req_length := LENGTH (CONVERT (ls_req_content, 'UTF8', 'WE8ISO8859P1'));
   UTL_HTTP.set_header (req,'Content-Type','application/json; charset=utf-8');
   UTL_HTTP.set_header (req, 'Content-Length', req_length);
   UTL_HTTP.write_text (req, ls_req_content);

   -- Make a HTTP request and get the response.
   resp := UTL_HTTP.get_response (req);

   -- Loop through the response.
   BEGIN
      LOOP
         UTL_HTTP.read_text (resp, resp_buffer, 32766);
         ps_res_content := ps_res_content || resp_buffer;
      END LOOP;

      UTL_HTTP.end_response (resp);
   EXCEPTION
      WHEN UTL_HTTP.end_of_body
      THEN
         UTL_HTTP.end_response (resp);
   END;

   RETURN ls_returncode;
EXCEPTION
   WHEN OTHERS
   THEN UTL_HTTP.end_response (resp);
      log_at ('sendRequestJSON',SQLCODE,SQLERRM,DBMS_UTILITY.format_error_backtrace);
      RETURN '999';
END;
END PKG_REST;
/

