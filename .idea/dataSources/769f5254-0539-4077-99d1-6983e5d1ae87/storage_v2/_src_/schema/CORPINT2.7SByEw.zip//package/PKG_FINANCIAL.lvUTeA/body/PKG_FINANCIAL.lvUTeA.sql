create PACKAGE BODY          Pkg_Financial IS

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : get txtodo
******************************************************************************/
FUNCTION GetTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER:=0;
BEGIN

    -- check if tx exists
    select count(*) into ln_count
    from tbl_txtodo
    where tx_no = pn_txno;

    if (ln_count = 0) then
        return '404';
    end if;

    -- check if tx belongs to customer
    select PKG_FINANCIAL.checkTxCustomer(pn_personid, pn_txno) into ls_returncode from dual;
            
    if (ls_returncode <> '000') then
        return ls_returncode;
    end if;

    OPEN pc_ref FOR
        SELECT * FROM tbl_txtodo
        WHERE tx_no = pn_txno;

EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('GetTxtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 26.07.2016
   Purpose    : get wait txtodo
******************************************************************************/
FUNCTION GetWaitTxtodo(pn_personid IN NUMBER, ps_txnos IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER:=0;
    ln_customer_no NUMBER;
BEGIN

    ln_customer_no := PKG_HELPER.GETCUSTOMERNOFROMPERSON(pn_personid);

    OPEN pc_ref FOR
        SELECT t.*, pkg_financial.checkTxtodoAuthority(pn_personid, t.TX_NO) CHECK_AUTHORITY FROM tbl_txtodo t
        WHERE t.CREATED_BY in (select person_id from tbl_identification where customer_no = ln_customer_no)
        AND INSTR(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.waiting.status'), t.STATUS_CD) > 0
        AND INSTR(NVL(ps_txnos, ','||t.TX_NO||','), ','||t.TX_NO||',') > 0;

    return ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('GetWaitTxtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : force save txtodo
******************************************************************************/
FUNCTION ForceSaveTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, ps_txinfo in CLOB, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER:=0;
    ls_status TBL_STATUS.STATUS_CD%type;
    ls_authcd TBL_AUTHORITY.AUTH_CD%type;

BEGIN

    select count(*) into ln_count
    from tbl_txtodo
    where tx_no = pn_txno;
    
    if (ln_count = 0) then
        return '404';
    end if;

    update tbl_txtodo
        set tx_info = ps_txinfo
    where tx_no = pn_txno;

    OPEN pc_ref FOR
        SELECT * FROM tbl_txtodo
        WHERE tx_no = pn_txno;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('ForceSaveTxtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : save txtodo
******************************************************************************/
/*FUNCTION SaveTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, ps_txinfo in CLOB, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER:=0;
    ln_index NUMBER:=0;
    ls_status TBL_STATUS.STATUS_CD%type;
    ls_authcd TBL_AUTHORITY.AUTH_CD%type;
    ln_txno NUMBER:=pn_txno;

BEGIN

    WHILE TRUE LOOP
        ln_index := ln_index + 1;
        
        select PKG_HELPER.GETJSONVALUE(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level'), to_char(ln_index))
        into ls_status
        from dual;

        select PKG_HELPER.GETJSONVALUE(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level.status'), ls_status)
        into ls_authcd
        from dual;
        
        select count(*) into ln_count
        from tbl_person_auth
        where person_id=pn_personid
        and auth_cd=ls_authcd;
        
        if (ln_count > 0 or ln_index > 10) then
            exit;
        end if;

    END LOOP;

    select count(*) into ln_count
    from tbl_txtodo
    where tx_no = ln_txno;
    
    if (ln_count = 0) then
    
        select CORPINT2.SEQ_TXTODO.nextval into ln_txno from dual;

        insert into tbl_txtodo values (ln_txno, pn_personid, sysdate, ls_status, ps_txinfo, 'txcode');
    else

        -- check if tx belongs to customer
        select PKG_FINANCIAL.checkTxCustomer(pn_personid, ln_txno) into ls_returncode from dual;
            
        if (ls_returncode <> '000') then
            return ls_returncode;
        end if;

        -- check if customer has rights
        select PKG_FINANCIAL.CHECKTXTODOAUTHORITY(pn_personid, ln_txno) into ls_returncode from dual;
            
        if (ls_returncode <> '000') then
            return ls_returncode;
        end if;
        
        ls_returncode := ForceSaveTxtodo(pn_personid, ln_txno, ps_txinfo, pc_ref);

    end if;

    OPEN pc_ref FOR
        SELECT * FROM tbl_txtodo
        WHERE tx_no = ln_txno;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('SaveTxtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;*/

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : checkTxtodoAuthority
******************************************************************************/
FUNCTION checkTxtodoAuthority(pn_personid IN NUMBER, ps_txno in NUMBER) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ls_status_cd TBL_STATUS.STATUS_CD%type;
    ln_index number:=0;
    ls_authority TBL_AUTHORITY.AUTH_CD%type;
    ln_count number:=0;
    
BEGIN

    select status_cd into ls_status_cd
    from tbl_txtodo
    where tx_no = ps_txno;
    
    select PKG_HELPER.GETJSONVALUE(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level.status'), ls_status_cd) 
    into ls_authority from dual;
    
    select count(*) into ln_count
    from TBL_PERSON_AUTH
    where person_id = pn_personid
    and auth_cd = ls_authority;
    
    if (ln_count = 0) then
        RETURN '030';
    end if;

    RETURN ls_returncode;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '030';
    WHEN OTHERS THEN
        pkg_log.addlog('checkTxtodoAuthority', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : check tx belongs to customer
******************************************************************************/
FUNCTION checkTxCustomer(pn_personid IN NUMBER, ps_txno in NUMBER) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_customer_no NUMBER;
    ln_count number:=0;
    
BEGIN

    ln_customer_no := PKG_HELPER.GETCUSTOMERNOFROMPERSON(pn_personid);

    select count(*) into ln_count
    from TBL_TXTODO
    where created_by in (select person_id from tbl_identification where customer_no = ln_customer_no)
    and tx_no = ps_txno;

    if (ln_count = 0) then
        return '030';
    end if;

    RETURN ls_returncode;
    
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('checkTxCustomer', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 25.07.2016
   Purpose    : pre process txtodo
******************************************************************************/
FUNCTION PreProcessTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER:=0;
    ln_index NUMBER:=0;
    ls_status_cd TBL_STATUS.STATUS_CD%type;
    ls_authcd TBL_AUTHORITY.AUTH_CD%type;
    lb_found BOOLEAN:=false;
    ln_customer_no TBL_IDENTIFICATION.CUSTOMER_NO%type;

BEGIN

    -- check if tx belongs to customer
    select PKG_FINANCIAL.checkTxCustomer(pn_personid, pn_txno) into ls_returncode from dual;
        
    if (ls_returncode <> '000') then
        return ls_returncode;
    end if;

    -- check if customer has rights
    select PKG_FINANCIAL.CHECKTXTODOAUTHORITY(pn_personid, pn_txno) into ls_returncode from dual;
        
    if (ls_returncode <> '000') then
        return ls_returncode;
    end if;

    ln_customer_no := PKG_HELPER.GETCUSTOMERNOFROMPERSON(pn_personid);
  
    WHILE TRUE LOOP
        ln_index := ln_index + 1;
        
        select PKG_HELPER.GETJSONVALUE(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level'), to_char(ln_index))
        into ls_status_cd
        from dual;

        select PKG_HELPER.GETJSONVALUE(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.level.status'), ls_status_cd)
        into ls_authcd
        from dual;
        
        if ls_status_cd = 'sDONE' then
            exit;
        end if;
        
        -- found initial status, looking for next
        if (lb_found) then          

            select count(*) into ln_count
            from tbl_person_auth
            where person_id in (select person_id from tbl_identification where status_cd in ('sENAB','sLOCKED') and customer_no=ln_customer_no)
            and auth_cd=ls_authcd;

            if (ln_count > 0 or INSTR(PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.notskipping.status'), ls_status_cd) > 0) then
                exit;
            end if;

        else

            select count(*) into ln_count
            from tbl_txtodo
            where tx_no = pn_txno
            and status_cd = ls_status_cd;

            if (ln_count > 0) then
                lb_found:=true;
            end if;

        end if;
        
        if (ln_index > 10) then
            return '404';
        end if;

    END LOOP;

    -- make status as in process if this is last status
    if (ls_status_cd = 'sDONE') then
        update tbl_txtodo
        set status_cd = PKG_HELPER.GETCONFIGVALUEFROMKEY('corporate.ib.authorization.process.status')
        where tx_no = pn_txno;
        
        ls_returncode := '400';
    else
        update tbl_txtodo
        set status_cd = ls_status_cd
        where tx_no = pn_txno;
    end if;

    OPEN pc_ref FOR
        SELECT * FROM tbl_txtodo
        WHERE tx_no = pn_txno;


    COMMIT;
    
    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('ProcessTxtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;


FUNCTION PostProcessTxTodo(pn_txno IN NUMBER, ps_process_result IN VARCHAR2, ps_previous_status IN VARCHAR2) RETURN VARCHAR2
IS
      ls_returncode VARCHAR2(3):='000';
      ls_new_status VARCHAR2(3);
BEGIN

    IF ps_process_result = '000' THEN
        ls_new_status := 'sDONE';
    ELSE
        ls_new_status := ps_previous_status;
    END IF;
    
    UPDATE CORPINT2.TBL_TXTODO
    SET STATUS_CD = ls_new_status
    WHERE TX_NO = pn_txno;
    
    COMMIT;
    
    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('PostProcessTxTodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;


/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : To get next authorization status for txtodo
******************************************************************************/
FUNCTION get_next_status_code( pn_customer_no NUMBER,
                                                            ps_tx_code VARCHAR2,
                                                            ps_status_code VARCHAR2 ) RETURN VARCHAR2
IS
    ls_next_status VARCHAR2(20);
BEGIN

    if ps_status_code = 'sMAKER' then
        ls_next_status := 'sVERIFIER';
    elsif ps_status_code = 'sVERIFIER' then
        ls_next_status := 'sCHECKER';
    elsif ps_status_code = 'sCHECKER' then
        ls_next_status := 'sAPPROVER';
    elsif ps_status_code = 'sAPPROVER' then
        ls_next_status :=  'sDONE';
    else
        ls_next_status := 'UNKNOWN STATUS';
    end if;
    
    
    return ls_next_status;   

END;              


/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : To get authorization code for given status code
******************************************************************************/
FUNCTION get_auth_code(   pn_customer_no NUMBER,
                                                  ps_tx_code VARCHAR2,
                                                  ps_status_code VARCHAR2 ) RETURN VARCHAR2 
is
    ls_auth_cd VARCHAR2(20);
begin
    
   if ps_status_code = 'sMAKER' then
        ls_auth_cd := 'aMAKER';
    elsif ps_status_code = 'sVERIFIER' then
        ls_auth_cd := 'aVERIFIER';
    elsif ps_status_code = 'sCHECKER' then
        ls_auth_cd := 'aCHECKER';
    elsif ps_status_code = 'sAPPROVER' then
        ls_auth_cd :=  'aAPPROVER';
    else
        ls_auth_cd := 'aAPPROVER';
    end if;
    
    
    return ls_auth_cd;   
end;
                                                  
/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : Save txtodo
******************************************************************************/
FUNCTION save_txtodo(      pn_person_id NUMBER,
                                                ps_tx_code VARCHAR2,
                                                pc_tx_info CLOB,
                                                ps_status_code VARCHAR2 default 'sMAKER',
                                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
    ln_txno NUMBER;
    ln_customer_no NUMBER;
    ls_authcd TBL_AUTHORITY.AUTH_CD%TYPE;
    
BEGIN
        
    select corpint2.seq_txtodo.nextval into ln_txno from dual;
   
    ln_customer_no := PKG_HELPER.getCustomerNoFromPerson(pn_person_id);
    ls_authcd := get_auth_code(ln_customer_no, ps_tx_code, ps_status_code);
    
    insert into tbl_txtodo(TX_NO, CREATED_BY, CREATED_AT, STATUS_CD, TX_INFO, TX_CODE, AUTH_CD) 
    values (ln_txno, pn_person_id, sysdate, NVL(ps_status_code, 'sMAKER'), pc_tx_info, ps_tx_code, ls_authcd );
    
    OPEN pc_ref FOR SELECT ln_txno TX_NO FROM DUAL;
    
    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        OPEN pc_ref FOR SELECT 0 FROM DUAL;
        pkg_log.addlog('save_txtodo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
END;                                                
                                                                                          

END Pkg_Financial;
/

