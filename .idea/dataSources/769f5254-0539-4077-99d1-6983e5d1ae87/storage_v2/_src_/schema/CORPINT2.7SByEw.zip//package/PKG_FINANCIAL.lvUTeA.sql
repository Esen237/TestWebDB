create PACKAGE          Pkg_Financial IS

TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : get txtodo
******************************************************************************/
FUNCTION GetTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 26.07.2016
   Purpose    : get wait txtodo
******************************************************************************/
FUNCTION GetWaitTxtodo(pn_personid IN NUMBER, ps_txnos IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : force save txtodo
******************************************************************************/
FUNCTION ForceSaveTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, ps_txinfo in CLOB, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : save txtodo
******************************************************************************/
--FUNCTION SaveTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, ps_txinfo in CLOB, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : checkTxtodoAuthority
******************************************************************************/
FUNCTION checkTxtodoAuthority(pn_personid IN NUMBER, ps_txno in NUMBER) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 18.07.2016
   Purpose    : check tx belongs to customer
******************************************************************************/
FUNCTION checkTxCustomer(pn_personid IN NUMBER, ps_txno in NUMBER) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhzohayev
   Date       : 25.07.2016
   Purpose    : pre process txtodo
******************************************************************************/
FUNCTION PreProcessTxtodo(pn_personid IN NUMBER, pn_txno IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 25.08.2016
   Purpose    : Post Process Tx Todo
******************************************************************************/
FUNCTION PostProcessTxTodo(pn_txno IN NUMBER, ps_process_result IN VARCHAR2,   ps_previous_status IN VARCHAR2) RETURN VARCHAR2;



/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : To get next authorization status for txtodo
******************************************************************************/
FUNCTION get_next_status_code( pn_customer_no NUMBER,
                                                            ps_tx_code VARCHAR2,
                                                            ps_status_code VARCHAR2 ) RETURN VARCHAR2 ;

/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : To get authorization code for given status code
******************************************************************************/
FUNCTION get_auth_code( pn_customer_no NUMBER,
                                                ps_tx_code VARCHAR2,
                                                ps_status_code VARCHAR2 ) RETURN VARCHAR2 ;


/******************************************************************************
   Created By : Chyngyz Omurov
   Date       : 26.08.2016
   Purpose    : Save txtodo
******************************************************************************/
FUNCTION save_txtodo(  pn_person_id NUMBER,
                                                ps_tx_code VARCHAR2,
                                                pc_tx_info CLOB,
                                                ps_status_code VARCHAR2 default 'sMAKER',
                                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                                                        
END Pkg_Financial;
/

