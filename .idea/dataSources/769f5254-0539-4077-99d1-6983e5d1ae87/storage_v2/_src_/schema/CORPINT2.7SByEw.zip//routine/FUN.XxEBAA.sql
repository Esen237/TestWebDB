create function fun(a in number,b out number, c in out number) return number is
begin
	b:=a+10;
	c:=c+a;
	return(100);
end;
/

