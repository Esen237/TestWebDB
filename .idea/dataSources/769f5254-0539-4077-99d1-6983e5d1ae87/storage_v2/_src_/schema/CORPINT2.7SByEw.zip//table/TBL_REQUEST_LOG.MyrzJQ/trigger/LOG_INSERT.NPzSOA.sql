create trigger LOG_INSERT
    before update
    on TBL_REQUEST_LOG
    for each row
begin
SELECT sysdate 
  INTO :new.timestamp
  FROM dual;    
end;

/

