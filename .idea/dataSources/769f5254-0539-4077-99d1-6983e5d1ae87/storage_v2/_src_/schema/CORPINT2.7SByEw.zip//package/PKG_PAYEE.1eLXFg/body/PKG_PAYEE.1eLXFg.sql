create PACKAGE BODY          Pkg_Payee IS

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 07.12.2015
   Purpose    :get payee info
******************************************************************************/
FUNCTION GetPayeeInfo(pn_personid IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';

BEGIN
log_at('gross_clearing',1,pn_personid);
    OPEN pc_ref FOR
        SELECT * FROM tbl_payee
        WHERE created_by=pn_personid
        ORDER BY payee_id;
    
    RETURN ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('GetPayeeInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
END;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 07.12.2015
   Purpose    : add or update payee info
******************************************************************************/
FUNCTION AddPayeeInfo(pn_payeeid IN NUMBER, pn_personid IN NUMBER, pc_payee_info IN CLOB, ps_statuscd IN VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    cbs.log_at('akmaralpayee1', pn_payeeid, to_char(pc_payee_info), pn_personid);
    /* NEW PAYEE */
    IF pn_payeeid=0 THEN
    
        INSERT INTO CORPINT2.TBL_PAYEE (
            PAYEE_ID, 
            CREATED_BY, 
            CREATED_AT, 
            PAYEE_INFO, 
            STATUS_CD) 
        VALUES (
            seq_payee.nextVal,
            pn_personid,
            SYSDATE,
            pc_payee_info,
            ps_statuscd);
     cbs.log_at('akmaralpayee2', 'insert end', pn_personid);       
    /* UPDATE EXISTING PAYEE*/
    ELSE
        UPDATE TBL_PAYEE
        SET CREATED_BY=pn_personid,
            PAYEE_INFO=pc_payee_info,
            STATUS_CD=ps_statuscd
        WHERE PAYEE_ID=pn_payeeid;
    END IF;
    cbs.log_at('akmaralpayee3',ls_returncode );
    RETURN ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
    cbs.log_at('akmaralpayee4',ls_returncode, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );
        pkg_log.addlog('AddPayeeInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
             RAISE;
END;

FUNCTION AddPayeeInfoNew(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER, pc_payee_info IN CLOB, ps_statuscd IN VARCHAR2, ps_payee_type IN VARCHAR2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    cbs.log_at('akmaralpayee1', pn_payeeid, to_char(pc_payee_info), '');
    /* NEW PAYEE */
    IF pn_payeeid=0 THEN
    
        INSERT INTO CORPINT2.TBL_PAYEE (
            PAYEE_ID, 
            CREATED_BY, 
            CREATED_AT, 
            PAYEE_INFO,
            STATUS_CD) 
        VALUES (
            seq_payee.nextVal,
            null,
            SYSDATE,
            pc_payee_info,
            ps_statuscd);
     cbs.log_at('akmaralpayee2', 'insert end', '');       
    /* UPDATE EXISTING PAYEE*/
    ELSE
        UPDATE TBL_PAYEE
        SET PAYEE_INFO=pc_payee_info,
            STATUS_CD=ps_statuscd
        WHERE PAYEE_ID=pn_payeeid;
    END IF;
    cbs.log_at('akmaralpayee3',ls_returncode );
    RETURN ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
    cbs.log_at('akmaralpayee4',ls_returncode, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );
        pkg_log.addlog('AddPayeeInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
END;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 03.02.2016
   Purpose    : remove payee
******************************************************************************/
FUNCTION RemovePayee(pn_payeeid IN NUMBER, pn_personid IN NUMBER) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    DELETE FROM TBL_PAYEE
    WHERE PAYEE_ID=pn_payeeid
    AND CREATED_BY=pn_personid;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('RemovePayee', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
END;

FUNCTION RemovePayeeNew(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    DELETE FROM TBL_PAYEE
    WHERE PAYEE_ID=pn_payeeid
    AND CREATED_BY=pn_customer_number;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        pkg_log.addlog('RemovePayee', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
END;

FUNCTION GetOnePayeeInfo(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT * FROM tbl_payee
        WHERE CREATED_BY=pn_customer_number and payee_id=pn_payeeid and ROWNUM = 1;
    
    RETURN ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
            RAISE;
END;

FUNCTION GetPayeeInfoByTypeAndCustomer( pn_customer_number IN NUMBER, pl_payee_type IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT * FROM tbl_payee
        WHERE CREATED_BY=pn_customer_number order by payee_id;
    
    RETURN ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
        RAISE;
END;

END Pkg_Payee;
/

