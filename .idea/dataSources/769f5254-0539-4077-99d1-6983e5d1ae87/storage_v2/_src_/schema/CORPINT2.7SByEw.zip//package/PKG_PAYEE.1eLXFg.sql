create PACKAGE          Pkg_Payee IS

TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 07.12.2015
   Purpose    : get payee info
******************************************************************************/
FUNCTION GetPayeeInfo(pn_personid IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 07.12.2015
   Purpose    : add or update payee info
******************************************************************************/
FUNCTION AddPayeeInfo(pn_payeeid IN NUMBER, pn_personid IN NUMBER, pc_payee_info IN CLOB, ps_statuscd IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 03.02.2016
   Purpose    : remove payee
******************************************************************************/
FUNCTION RemovePayee(pn_payeeid IN NUMBER, pn_personid IN NUMBER) RETURN VARCHAR2;

FUNCTION AddPayeeInfoNew(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER, pc_payee_info IN CLOB, ps_statuscd IN VARCHAR2, ps_payee_type IN VARCHAR2) RETURN VARCHAR2;

FUNCTION RemovePayeeNew(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER) RETURN VARCHAR2;

FUNCTION GetOnePayeeInfo(pn_payeeid IN NUMBER, pn_customer_number IN NUMBER, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

FUNCTION GetPayeeInfoByTypeAndCustomer( pn_customer_number IN NUMBER, pl_payee_type IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

END Pkg_Payee;
/

