create package          "PKG_AUTOPAYMENT" is
type cursorreferencetype is ref cursor;                                          

function createautopayment(ps_payment_name varchar2,
                                              pn_person_id number,
                                              pn_tran_code number,
                                              ps_tran_cd varchar2,
                                              ps_payment_type varchar2,
                                              ps_status varchar2,
                                              ps_payment_details clob,
                                              ps_user_created varchar2,
                                              ps_amount       varchar2,
                                              ps_cron         varchar2 default null,
                                              ps_defined_date varchar2 default null,
                                              ps_exec_time varchar2 default null,
                                              ps_period varchar2 default null,
                                              pn_account_no varchar2 default null,
                                              pn_account_to  varchar2 default null,
                                              pn_customer_id varchar2 default null,
                                              ps_channel_cd varchar2 default null,
                                              ps_next_date varchar2 default null
                                              ,pc_ref out cursorreferencetype
                                              ) return varchar2;

 
/* Formatted on 03/07/2018 11:44:47 (QP5 v5.256.13226.35510) */
function modifyautopayment (pn_person_id         in     number,
                            ps_operation         in     varchar2,
                            ps_maker             in     varchar2,
                            ps_seqid             in     varchar2,
                            ps_title             in     varchar2,
                            ps_fromaccount       in     varchar2,
                            ps_toaccount         in     varchar2,
                            ps_amount            in     varchar2,
                            ps_type              in     varchar2,
                            ps_border            in     varchar2,
                            ps_nextdatetime      in     varchar2,
                            ps_cron              in     varchar2,
                            ps_status            in     varchar2,
                            ps_payment_details   in     clob,
                            pc_ref                  out cursorreferencetype) return varchar2;
function getallautopayments(pn_person_id in varchar2,pc_ref out cursorreferencetype) return varchar2;

function processautopayment(pn_seq_id in number) return varchar2;

function processservicepayments (ps_seq_id      in     number,
                                    pn_person_id   in     number,
                                    pc_ref            out cursorreferencetype) return varchar2;

function processb2bpayments (ps_seq_id      in     number,
                                    pn_person_id   in     number,
                                    pc_ref            out cursorreferencetype) return varchar2;

function processclearingpayments(ps_seq_id      in     number,
                         pn_person_id   in     number,
                         pc_ref         out    cursorreferencetype) return varchar2;

function processswiftpayments (ps_seq_id      in     number,
                                 pn_person_id   in     number,
                                 pc_ref         out    cursorreferencetype) return varchar2;

function processexch_buy_sell_payments(ps_seq_id      in     number,
                         pn_person_id   in     number,
                         pc_ref         out    cursorreferencetype) return varchar2;   
                         
function processarbitrajpayemtnts (ps_seq_id      in     number,
                         pn_person_id   in     number,
                         pc_ref         out    cursorreferencetype) return varchar2;    
                            
function processcardpayments (ps_seq_id      in     number,
                         pn_person_id   in     number,
                         pc_ref         out    cursorreferencetype) return varchar2;
function createtaxpayments (ps_trancd                varchar2,
                               ps_makerid             varchar2,
                               ps_status              varchar2,
                               ps_tax_from_account    varchar2,
                               ps_tax_tin             varchar2,
                               ps_tax_address_id      varchar2,
                               ps_tax_amount          varchar2,
                               ps_tax_currency        varchar2,
                               ps_tax_to_account      varchar2,
                               ps_tax_description     varchar2,
                               pc_ref                 out   cursorreferencetype) return varchar2; 

function  processtaxpayments (ps_seq_id      in     number,
                                     pn_person_id   in     number,
                                     pc_details     in     clob,
                                     pc_ref         out    cursorreferencetype) return varchar2;     
function processscheduled(pn_person_id varchar2,
                              pc_ref      out cursorreferencetype) return varchar2;    
function processtriggered(pn_person_id varchar2,
                              pc_ref      out cursorreferencetype) return varchar2;                                                                                                                             
procedure notifyperson(pn_musteri_no in varchar2,pn_notify_type varchar2);

function checkbalance (pn_account_no in varchar2,pn_sum_repl in varchar2) return varchar2;

function checkiftime(pn_person_id varchar2,pc_ref out cursorreferencetype) return varchar2;  


function getautopayemntinfo (pn_seq_id varchar2, pc_ref out cursorreferencetype) return varchar2;

 function getexchangeratesib (pd_date     in     date,
                                pn_option   in     number,
                                ps_result      out varchar2) return varchar2;
/******************************************************************************
   Name       : FUNCTION getExchangeRatioIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange ratios for currencies
******************************************************************************/   
function getexchangeratioib(pc_ref in cursorreferencetype,
                                               rate_type in varchar2,
                                               ps_fc_amount out varchar2,
                                               ps_total_amount out varchar2,
                                               ps_rate out varchar2) return varchar2;
                                               
/******************************************************************************
   Name       : FUNCTION getExchangeParityIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get exchange parity for currencies
******************************************************************************/   
function getexchangeparityib(pc_ref in cursorreferencetype,
                                                pc_ref2 in cursorreferencetype,
                                                ps_amount_currency in varchar2,
                                                ps_parity out varchar2,
                                                ps_from_amount out varchar2,
                                                ps_to_amount out varchar2) return varchar2;                                               

/******************************************************************************
   Name       : FUNCTION getCommissionIB
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get commission amounts for IB transactions
******************************************************************************/   
function getcommissionib(ps_trancd     in varchar2,
                                           pn_fromaccno  in varchar2,
                                           pn_toaccno    in varchar2,
                                           pn_amount     in varchar2,
                                           ps_currcd     in varchar2,
                                           ps_channelcd in varchar2,
                                           ps_amountcomm out varchar2,
                                           ps_taxcomm out varchar2) return varchar2;
                                           
/******************************************************************************
   Name       : FUNCTION getMaturityDate
   Created By : Adilet Kachkeev 10.12.2015
   Purpose      : get maturity date for clearing and swift
******************************************************************************/   
function getmaturitydate(ps_tran_date in varchar2,
                                          ps_tran_cd in varchar2,
                                          ps_type in varchar2,
                                          ps_maturity_date out varchar2) return varchar2;                                           

function checkifatpexist(personid in varchar2, pn_payment_name in varchar2, pn_account_to in varchar2) return varchar2;

function deletebyid(pn_seq_id varchar2, pc_ref out cursorreferencetype) return varchar2;
end;
/

