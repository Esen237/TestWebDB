create FUNCTION  TEST_CUR RETURN types.rc
AS
   VAR_REF types.rc;
BEGIN
    OPEN VAR_REF FOR
        SELECT 1
        FROM DUAL
        UNION
        SELECT 2
        FROM DUAL;

    RETURN VAR_REF;
END;
/

