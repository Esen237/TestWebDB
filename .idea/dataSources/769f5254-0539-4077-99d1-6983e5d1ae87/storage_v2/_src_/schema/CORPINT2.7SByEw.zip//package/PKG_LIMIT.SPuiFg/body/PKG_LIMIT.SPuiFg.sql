create PACKAGE BODY          Pkg_Limit IS

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : if there is no limit, then creates new limit from default value
******************************************************************************/
function initLimitInfo(pn_PersonId IN VARCHAR2,
                        ps_tran_cd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_count number:=0;
    ln_customer_no number;
    ln_channel_cnt number;
begin
    ln_customer_no := pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId));

    -- remove all customer duplicated daily limit definitions
    -- remove all person duplicated daily limit definitions
    -- remove all customer duplicated transactional limit definitions
    -- remove all person duplicated transactional limit definitions
    /*delete from tbl_limit t
    where rowid not in (
        select rowid from tbl_limit t
        where customer_no=ln_customer_no
        and person_id is null
        and limit_type='DAILY'
        and rownum=1
            union all
        select rowid from tbl_limit t
        where person_id = to_number(pn_PersonId)
        and limit_type = 'DAILY'
        and rownum=1
            union all
        select rowid from tbl_limit t
        where customer_no=ln_customer_no
        and person_id is null
        and limit_type='ONETIME'
        and rownum=1
            union all
        select rowid from tbl_limit t
        where person_id = to_number(pn_PersonId)
        and limit_type = 'ONETIME'
        and rownum=1
    )
    and (person_id is null or person_id = to_number(pn_PersonId))
    and customer_no = ln_customer_no;*/

    pkg_log.addlog('test_limits', '0', pn_PersonId || ' ' || ln_customer_no, ps_tran_cd);

--    IF ps_tran_cd is null OR length(trim(ps_tran_cd)) = 0 THEN

        select count(1) into ln_count
        from tbl_limit
        where customer_no = ln_customer_no
        and person_id is null
        and tran_cd = nvl(ps_tran_cd, tran_cd);

        if (ln_count = 0) then
            -- if there is no customer defined limit, then use default auth limit
            insert into tbl_limit
            select ln_customer_no, null, TRAN_CD, CURRENCY_CD, LIMIT_TYPE, TOTAL_LIMIT, USED_LIMIT, pkg_helper.getBankDatePlusTime, null, null
            from tbl_limit
            where customer_no is null and person_id is null and
                      tran_cd = nvl(ps_tran_cd, tran_cd) and
                      auth_cd in (select auth_cd from corpint2.tbl_person_auth
                                        where person_id = pn_PersonId);
        end if;

        select count(1) into ln_count
        from tbl_limit
        where person_id=to_number(pn_PersonId)
        and tran_cd = nvl(ps_tran_cd, tran_cd);

        -- if already have personal limit
        if (ln_count > 0) then
            return ls_returncode;
        end if;

        -- if there are any customer defined limit, then use it
        insert into tbl_limit
        select CUSTOMER_NO, to_number(pn_PersonId), TRAN_CD, CURRENCY_CD, LIMIT_TYPE, TOTAL_LIMIT, USED_LIMIT, pkg_helper.getBankDatePlusTime, null, null
        from tbl_limit
        where customer_no = ln_customer_no
        and person_id is null
        and tran_cd = nvl(ps_tran_cd, tran_cd);

/*        return ls_returncode;

        --ls_returncode := getPersonLimit(pn_PersonId, pc_ref);
    ELSE
        select count(1) into ln_count
        from tbl_limit
        where person_id=to_number(pn_PersonId)
        and tran_cd = ps_tran_cd;

        pkg_log.addlog('test_limits', '2', pn_PersonId || ' ' || ln_count);
        -- if already have personal limit
        if (ln_count > 0) then
            return ls_returncode;
        end if;

        select count(1) into ln_count
        from corpint2.tbl_person_auth a,
                corpint2.tbl_auth_tran t,
                corpint2.tbl_limit l
        where a.person_id = pn_PersonId and
                  a.auth_cd = t.auth_cd and
                  t.tran_cd = l.tran_cd and
                  l.tran_cd = ps_tran_cd;

        if ln_count > 0 then
            insert into tbl_limit
            select ln_customer_no, to_number(pn_PersonId), TRAN_CD, CURRENCY_CD, LIMIT_TYPE, TOTAL_LIMIT, USED_LIMIT, pkg_helper.getBankDatePlusTime, null, null
            from tbl_limit
            where customer_no is null and
                      tran_cd in (select distinct t.tran_cd from corpint2.tbl_person_auth a,
                                        corpint2.tbl_auth_tran t,
                                        corpint2.tbl_limit l
                                        where a.person_id = pn_PersonId and
                                                  a.auth_cd = t.auth_cd and
                                                  l.person_id is null and
                                                  l.customer_no is null and
                                                  t.tran_cd = l.tran_cd) and
                     tran_cd = ps_tran_cd;
        else
            ls_returncode := '030'; -- transaction authorization failed
        end if;
    END IF;*/
    pkg_log.addlog('initLimitInfo1', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return ls_returncode;
exception
    when others then
        pkg_log.addlog('initLimitInfo', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : removes additional rows for limit, and resets limit to default
******************************************************************************/
function resetPersonLimit(pn_PersonId IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin

    update tbl_limit
    set used_limit = 0,
        datetime = pkg_helper.getBankDatePlusTime
    where person_id = to_number(pn_PersonId);

    ls_returncode := getPersonLimit(pn_PersonId, pc_ref);

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('resetPersonLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : removes additional rows for limit, and resets limit to default
******************************************************************************/
function resetCustomerLimit(pn_PersonId IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_customer_no number;
begin

    ln_customer_no := pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId));

    update tbl_limit
    set used_limit = 0,
        datetime = pkg_helper.getBankDatePlusTime
    where customer_no = ln_customer_no;

    ls_returncode := getPersonLimit(pn_PersonId, pc_ref);

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('resetCustomerLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;


/******************************************************************************
   Created By : Nurmila Zhetimihsova
   Date       : 03112021
   Purpose    : returns limits of current person, empty if there are no data
******************************************************************************/
function NewGetPersonLimit(pn_PersonId IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin
    ls_returncode := initLimitInfo(pn_PersonId, '', pc_ref);

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where person_id=to_number(pn_PersonId)
        and auth_cd is null
        order by tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('NewGetPersonLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current person, empty if there are no data
******************************************************************************/
function getPersonLimit(pn_PersonId IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin
    ls_returncode := initLimitInfo(pn_PersonId, '', pc_ref);

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where person_id=to_number(pn_PersonId)
        and auth_cd is null
        order by tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getPersonLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current person, empty if there are no data
******************************************************************************/
function getPersonLimitOver(pn_PersonId IN VARCHAR2,
                        ps_TranCd IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin
    ls_returncode := initLimitInfo(pn_PersonId, ps_TranCd, pc_ref);

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where person_id=to_number(pn_PersonId)
        and tran_cd=ps_TranCd
        and auth_cd is null
        order by limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getPersonLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns limits of current customer, empty if there are no data
******************************************************************************/
function getCustomerLimit(pn_PersonId IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_customer_no number;
begin

    ln_customer_no := pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId));

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where customer_no=to_number(ln_customer_no)
        and person_id is null
        and auth_cd is null
        order by tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getCustomerLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : returns all limits of current customer, empty if there are no data
******************************************************************************/
function getAllLimit(pn_PersonId IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_customer_no number;
begin

    ln_customer_no := pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId));

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where person_id in (select person_id from tbl_identification
                                where customer_no = ln_customer_no)
        and auth_cd is null
        order by person_id, tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getAllLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 26.02.2016
   Purpose    : return all bank limits
******************************************************************************/
function getBankLimit(pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where customer_no is null
        and person_id is null
        and auth_cd is null
        order by tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getBankLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 26.02.2016
   Purpose    : return all limits groupped
******************************************************************************/
function getGrouppedLimit(pn_PersonId IN VARCHAR2, pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
begin

    OPEN pc_ref FOR
        SELECT * FROM tbl_limit
        where customer_no is null
        and person_id is null
        and auth_cd is null
        order by tran_cd, limit_type;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('getBankLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;


/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : checks available limit, compares with current currency
******************************************************************************/
function checkLimit(pn_PersonId IN VARCHAR2,
                    ps_TranCd IN VARCHAR2,
                    pn_Amount IN VARCHAR2,
                    ps_CurrencyCd IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_total_limit number := 0;
    ln_used_limit number := 0;
    ln_amount number := 0;
    ld_datetime date := sysdate;

    temp_ref CursorReferenceType;
    limit_row tbl_limit%rowtype;

    DailyLimitExceededException EXCEPTION;
    OneTimeLimitExceededException EXCEPTION;
    CustDailyLimitExceedException EXCEPTION;
    CustOneTmLimitExceedException EXCEPTION;
    BnkDailyLimitExceedException EXCEPTION;
    BnkOneTimeLimitExceedException EXCEPTION;
begin

    pkg_log.addlog('CheckLimit','params', pn_PersonId || ps_TranCd || pn_Amount || ps_CurrencyCd);

    ls_returncode := initLimitInfo(pn_PersonId, ps_TranCd, pc_ref);

    if ls_returncode <> '000' then
     pkg_log.addlog('checkLimit1', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return ls_returncode;
    end if;

    select min(datetime) into ld_datetime
    from tbl_limit
    where person_id = to_number(pn_PersonId)
    and tran_cd = ps_TranCd
    and limit_type = 'DAILY';

    if (ld_datetime < PKG_MUHASEBE.BANKA_TARIHI_BUL) then
        ls_returncode := resetPersonLimit(pn_PersonId, pc_ref);
        ls_returncode := resetCustomerLimit(pn_PersonId, pc_ref);
    end if;

    ln_amount := TO_NUMBER(pn_Amount,'99999999999.9999');
    ln_amount := Pkg_Kur.doviz_doviz_karsilik(ps_CurrencyCd, Pkg_Genel.lc_al, NULL, ln_amount, 1, NULL, NULL, 'O', 'A');

    ls_returncode := getPersonLimitOver(pn_PersonId, ps_TranCd, temp_ref);
   pkg_log.addlog('checkLimit2', ls_returncode, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    loop
        fetch temp_ref into limit_row;
        exit when temp_ref%notfound;

        -- check person limits
        ln_total_limit := Pkg_Kur.doviz_doviz_karsilik(limit_row.currency_cd, Pkg_Genel.lc_al, NULL, limit_row.total_limit, 1, NULL, NULL, 'O', 'A');
        ln_used_limit := Pkg_Kur.doviz_doviz_karsilik(limit_row.currency_cd, Pkg_Genel.lc_al, NULL, limit_row.used_limit, 1, NULL, NULL, 'O', 'A');

        if (limit_row.limit_type = 'ONETIME' and ln_amount > ln_total_limit - ln_used_limit) then
            raise OneTimeLimitExceededException;
        end if;

        if (limit_row.limit_type = 'DAILY' and ln_amount > ln_total_limit - ln_used_limit) then
            raise DailyLimitExceededException;
        end if;

        -- skip rest limit check if user has special private limit
        if (NVL(limit_row.is_private,0) = 1 and limit_row.tran_cd not in ('EXCHNGBUY','EXCHNGSELL')) then
            goto end_loop;
        end if;

        -- check customer limits
        select Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, total_limit, 1, NULL, NULL, 'O', 'A')
        into ln_total_limit
        from tbl_limit
        where limit_type=limit_row.limit_type
        and tran_cd=ps_TranCd
        and customer_no=pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId))
        and person_id is not null --changed by pentest Esen Omurchiev 04.03.2022
        and rownum=1;

        select sum(used_lc) into ln_used_limit
        from (
            select customer_no, person_id, tran_cd, total_limit, used_limit, currency_cd,
                   Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, total_limit, 1, NULL, NULL, 'O', 'A') total_lc,
                   Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, used_limit, 1, NULL, NULL, 'O', 'A') used_lc from tbl_limit
            where limit_type=limit_row.limit_type
            and tran_cd=ps_TranCd
            and customer_no=pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId))
            and person_id is not null
            and auth_cd is null
        );

        if (limit_row.limit_type = 'ONETIME' and ln_amount > ln_total_limit - ln_used_limit) then
            raise CustOneTmLimitExceedException;
        end if;

        if (limit_row.limit_type = 'DAILY' and ln_amount > ln_total_limit - ln_used_limit) then
            raise CustDailyLimitExceedException;
        end if;

        -- skip rest limit check if customer has special private limit
        if (NVL(limit_row.is_private,0) = 1 and limit_row.tran_cd not in ('EXCHNGBUY','EXCHNGSELL')) then
            goto end_loop;
        end if;
        
        -- check bank limits
        select Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, total_limit, 1, NULL, NULL, 'O', 'A')
        into ln_total_limit
        from tbl_limit
        where limit_type=limit_row.limit_type
        and tran_cd=ps_TranCd
        and customer_no is null
        and person_id is null
        and auth_cd is null
        and rownum=1;

        select sum(used_lc) into ln_used_limit
        from (
            select customer_no, person_id, tran_cd, total_limit, used_limit, currency_cd,
                   Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, total_limit, 1, NULL, NULL, 'O', 'A') total_lc,
                   Pkg_Kur.doviz_doviz_karsilik(currency_cd, Pkg_Genel.lc_al, NULL, used_limit, 1, NULL, NULL, 'O', 'A') used_lc from tbl_limit
            where limit_type=limit_row.limit_type
            and tran_cd=ps_TranCd
            and customer_no=pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId))
            and person_id is not null
            and auth_cd is null
        );

        if (limit_row.limit_type = 'ONETIME' and ln_amount > ln_total_limit - ln_used_limit) then
            raise BnkOneTimeLimitExceedException;
        end if;

        if (limit_row.limit_type = 'DAILY' and ln_amount > ln_total_limit - ln_used_limit) then
            raise BnkDailyLimitExceedException;
        end if;

        <<end_loop>>  -- not allowed unless an executable statement follows
        NULL; -- add NULL statement to avoid error
    end loop;
    
    cbs.log_at('checkLimit_done', ln_amount, ln_total_limit, ln_used_limit);
    return ls_returncode;
exception
    when OneTimeLimitExceededException then
        return '504';
    when DailyLimitExceededException then
        return '503';
    when CustOneTmLimitExceedException then
        return '508';
    when CustDailyLimitExceedException then
        return '507';
    when BnkOneTimeLimitExceedException then
        return '499';
    when BnkDailyLimitExceedException then
        return '498';
    when others then
        cbs.log_at('checkLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        pkg_log.addlog('checkLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 20.10.2015
   Purpose    : updates limits with params, compares with current currency
******************************************************************************/
function updateLimit(pn_PersonId IN VARCHAR2,
                     ps_TranCd IN VARCHAR2,
                     pn_Amount IN VARCHAR2,
                     ps_CurrencyCd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_used_limit number := 0;
    ln_amount number := 0;
    ld_datetime date := sysdate;

    temp_ref CursorReferenceType;
    limit_row tbl_limit%rowtype;
begin
    ls_returncode := initLimitInfo(pn_PersonId, ps_TranCd, pc_ref);

    if ls_returncode <> '000' then
        return ls_returncode;
    end if;

    select min(datetime) into ld_datetime
    from tbl_limit
    where customer_no = pkg_helper.getCustomerNoFromPerson(to_number(pn_PersonId))
    and tran_cd = ps_TranCd
    and limit_type = 'DAILY';

    if (ld_datetime < PKG_MUHASEBE.BANKA_TARIHI_BUL) then
        ls_returncode := resetPersonLimit(pn_PersonId, pc_ref);
        ls_returncode := resetCustomerLimit(pn_PersonId, pc_ref);
    end if;

    ln_amount := TO_NUMBER(pn_Amount,'99999999999.9999');
    ln_amount := Pkg_Kur.doviz_doviz_karsilik(ps_CurrencyCd, Pkg_Genel.lc_al, NULL, ln_amount, 1, NULL, NULL, 'O', 'A');

    ls_returncode := getPersonLimitOver(pn_PersonId, ps_TranCd, temp_ref);

    loop
        fetch temp_ref into limit_row;
        exit when temp_ref%notfound;

        if (limit_row.limit_type = 'DAILY') then
            ln_used_limit := Pkg_Kur.doviz_doviz_karsilik(limit_row.currency_cd, Pkg_Genel.lc_al, NULL, limit_row.used_limit, 1, NULL, NULL, 'O', 'A');
            ln_used_limit := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al, limit_row.currency_cd, NULL, ln_used_limit + ln_amount, 1, NULL, NULL, 'O', 'S');
            
            cbs.log_at('updateLimit', 'limit_row.used_limit', limit_row.used_limit);
            cbs.log_at('updateLimit', 'ln_amount', ln_amount);
            cbs.log_at('updateLimit', 'used_limit', ln_used_limit);
           
            update tbl_limit
            set used_limit = ln_used_limit
            where person_id = to_number(pn_PersonId)
            and tran_cd = ps_TranCd
            and limit_type = limit_row.limit_type;
        end if;

    end loop;

    return ls_returncode;
exception
    when others then
        pkg_log.addlog('updateLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 03.03.2016
   Purpose    : change limits
******************************************************************************/
function changeLimit(pn_PersonId IN VARCHAR2,
                     ps_TranCd IN VARCHAR2,
                     ps_Type IN VARCHAR2,
                     pn_Amount IN VARCHAR2,
                     ps_CurrencyCd IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) return varchar2 is
    ls_returncode varchar2(3):='000';
    ln_count number:=0;
    lx_limit_bg_bank Exception;
    lx_limit_ls_0 Exception;
begin

    select total_limit into ln_count
    from tbl_limit
    where person_id is null
    and customer_no is null
    and tran_cd = ps_TranCd
    and limit_type = ps_Type;

    -- new limit amount should not be more than bank limit
    if (pn_Amount is not null and to_number(pn_Amount) > ln_count) then
        raise lx_limit_bg_bank;
    end if;

    -- new limit amount should not be less than 0
    if (pn_Amount is not null and to_number(pn_Amount) < 0) then
        raise lx_limit_ls_0;
    end if;

    update tbl_limit
    set total_limit = nvl2(pn_Amount, to_number(pn_Amount), total_limit),
        currency_cd = nvl(ps_CurrencyCd, currency_cd)
    where person_id = to_number(pn_PersonId)
    and tran_cd = ps_TranCd
    and limit_type = ps_Type;

    return ls_returncode;
exception
    when lx_limit_bg_bank then
        return '971';
    when lx_limit_ls_0 then
        return '972';
    when others then
        pkg_log.addlog('chnageLimit', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
end;

END Pkg_Limit;
/

