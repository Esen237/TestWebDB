create PACKAGE BODY          pkg_autopayment
IS
   /******************************************************************************
      Name       : FUNCTION createAutopayment
      Created By : Adilet Kachkeev 10.12.2015
      Modifyed by : Guzal Zainulina 11.01.2018
      Purpose      : create automatic payment
   ******************************************************************************/
   FUNCTION createAutopayment (
      ps_payment_name          VARCHAR2,
      pn_person_id             NUMBER,
      pn_tran_code             NUMBER,
      ps_tran_cd               VARCHAR2,
      ps_payment_type          VARCHAR2,
      ps_status                VARCHAR2,
      ps_payment_details       CLOB,
      ps_user_created          VARCHAR2,
      ps_amount                VARCHAR2,
      ps_cron                  VARCHAR2 DEFAULT NULL,
      ps_defined_date          VARCHAR2 DEFAULT NULL,
      ps_exec_time             VARCHAR2 DEFAULT NULL,
      ps_period                VARCHAR2 DEFAULT NULL,
      pn_account_no            VARCHAR2 DEFAULT NULL,
      pn_account_to            VARCHAR2 DEFAULT NULL,
      pn_customer_id           VARCHAR2 DEFAULT NULL,
      ps_channel_cd            VARCHAR2 DEFAULT NULL,
      ps_next_date             VARCHAR2 DEFAULT NULL,
      pc_ref               OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_details        VARCHAR2 (500);
      ln_seq_id         NUMBER;
      ld_next_date      DATE;
      ld_defined_date   DATE;
      ls_returncode     VARCHAR2 (3) := '000';
      ls_user_created   VARCHAR2 (50) := SUBSTR (ps_user_created, 1, 50);
      ls_account_to     VARCHAR2 (100);
      ls_account_no     NUMBER;
      ls_next_date      VARCHAR2 (100);
      json_txinfo       CORPINT2.JSON;

      CURSOR exautopmnt
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE     CREATED_BY = ps_user_created
                AND person_id = pn_person_id
                AND PAYMENT_NAME = ps_payment_name;

      res_pmnt          exautopmnt%ROWTYPE;
   BEGIN
      log_at ('pkg_atp.create', 'IN');
      json_txinfo := corpint2.json (ps_payment_details);
      ls_account_no := pn_account_no;
      ls_account_to := pn_account_to;
      log_at ('pkg_atp.create step2', ls_account_to);

      OPEN exautopmnt;

      FETCH exautopmnt INTO res_pmnt;

      IF (CHECKIFATPEXIST (pn_person_id, ps_payment_name, ls_account_to) =
             '000')
      THEN
         IF exautopmnt%NOTFOUND
         THEN
            IF ps_payment_type = 'SCHEDULED'
            THEN
               log_at ('pkg_atp.create step3 SCHEDULED', ls_account_to);
               ls_next_date := TO_DATE (ps_next_date, 'DD.MM.YYYY HH24:MI:SS');
               INSERT INTO CORPINT2.TBL_AUTOPAYMENT (payment_name,
                                                    person_id,
                                                    customer_id,
                                                    tran_code,
                                                    tran_cd,
                                                    channel_cd,
                                                    payment_type,
                                                    status,
                                                    payment_details,
                                                    defined_date,
                                                    cron_time,
                                                    next_date_time,
                                                    created_by,
                                                    created_date,
                                                    approved_by,
                                                    approved_date,
                                                    account_no,
                                                    account_to,
                                                    TRY_NUM,
                                                    amount)
                    VALUES (ps_payment_name,
                            pn_person_id,
                            pn_customer_id,
                            pn_tran_code,
                            ps_tran_cd,
                            ps_channel_cd,
                            ps_payment_type,
                            ps_status,
                            ps_payment_details,
                            SYSDATE,
                            ps_cron,
                            ls_next_date,
                            ls_user_created,
                            SYSDATE,
                            ls_user_created,
                            SYSDATE,
                            pn_account_no,
                            ls_account_to,
                            0,
                            ps_amount);

               ls_details := 'NEW SCHEDULED AUTOPAYMENT IS CREATED';
            ELSIF ps_payment_type = 'TRIGGERED'
            THEN
               log_at ('pkg_atp.create step3 TRIGGERED', ls_account_to);

               INSERT INTO CORPINT2.TBL_AUTOPAYMENT (payment_name,
                                                    person_id,
                                                    customer_id,
                                                    tran_code,
                                                    tran_cd,
                                                    channel_cd,
                                                    payment_type,
                                                    status,
                                                    payment_details,
                                                    defined_date,
                                                    created_by,
                                                    created_date,
                                                    approved_by,
                                                    approved_date,
                                                    account_no,
                                                    account_to,
                                                    TRY_NUM,
                                                    amount)
                    VALUES (ps_payment_name,
                            pn_person_id,
                            pn_customer_id,
                            pn_tran_code,
                            ps_tran_cd,
                            ps_channel_cd,
                            ps_payment_type,
                            ps_status,
                            ps_payment_details,
                            SYSDATE,
                            ls_user_created,
                            SYSDATE,
                            ls_user_created,
                            SYSDATE,
                            pn_account_no,
                            ls_account_to,
                            0,
                            ps_amount);

               ls_details := 'NEW TRIGGERED AUTOPAYMENT IS CREATED';
            END IF;

            BEGIN
               SELECT MAX (seq_id)
                 INTO ln_seq_id
                 FROM CORPINT2.TBL_AUTOPAYMENT
                WHERE     person_id = pn_person_id
                      AND tran_code LIKE pn_tran_code
                      AND payment_type = ps_payment_type
                      AND payment_name = ps_payment_name;
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  ln_seq_id := 0;
            END;

            log_at ('pkg_atp.create step4', ls_account_to);
--            PKG_LOG.addAutopaymentLog ('',
--                                       ps_payment_name,
--                                       pn_person_id,
--                                       pn_customer_id,
--                                       pn_tran_code,
--                                       ps_tran_cd,
--                                       ps_channel_cd,
--                                       ps_payment_type,
--                                       ps_status,
--                                       ps_payment_details,
--                                       ld_defined_date,
--                                       ps_exec_time,
--                                       ps_period,
--                                       ls_user_created,
--                                       SYSDATE,
--                                       ls_user_created,
--                                       SYSDATE,
--                                       ln_seq_id,
--                                       ld_next_date,
--                                       pn_account_no,
--                                       '',
--                                       '',
--                                       '',
--                                       ls_details);

            OPEN pc_ref FOR
               SELECT *
                 FROM CORPINT2.TBL_AUTOPAYMENT p
                WHERE     P.PAYMENT_NAME = ps_payment_name
                      AND P.PERSON_ID = pn_person_id
                      AND P.TRAN_CODE = pn_tran_code;

            COMMIT;
         ELSE
--            PKG_LOG.addAutopaymentLog ('Autopayment already exist',
--                                       ps_payment_name,
--                                       pn_person_id,
--                                       pn_customer_id,
--                                       pn_tran_code,
--                                       ps_tran_cd,
--                                       ps_channel_cd,
--                                       ps_payment_type,
--                                       ps_status,
--                                       ps_payment_details,
--                                       ld_defined_date,
--                                       ps_exec_time,
--                                       ps_period,
--                                       ls_user_created,
--                                       SYSDATE,
--                                       ls_user_created,
--                                       SYSDATE,
--                                       ln_seq_id,
--                                       ld_next_date,
--                                       pn_account_no,
--                                       '',
--                                       '',
--                                       '',
--                                       ls_details);
            ls_returncode := '023';
         END IF;
      ELSE
         ls_returncode := '826';
      END IF;

      OPEN pc_ref FOR SELECT ls_returncode FROM DUAL;

      log_at ('pkg_atp.create finish', ls_returncode);
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         --rollback;
         log_at ('pkg_atp.create', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN '999';
   END;

   /******************************************************************************
      Name       : FUNCTION modifyAutopayment
      Created By : Adilet Kachkeev 10.12.2015
      Modifyed by : Guzal Zainulina 11.01.2018
      Purpose      : modify automatic payment
   ******************************************************************************/
   FUNCTION modifyAutopayment (
      pn_person_id         IN     NUMBER,
      ps_operation         IN     VARCHAR2,
      ps_maker             IN     VARCHAR2,
      ps_seqId             IN     VARCHAR2,
      ps_title             IN     VARCHAR2,
      ps_fromAccount       IN     VARCHAR2,
      ps_toAccount         IN     VARCHAR2,
      ps_amount            IN     VARCHAR2,
      ps_type              IN     VARCHAR2,
      ps_border            IN     VARCHAR2,
      ps_nextDateTime      IN     VARCHAR2,
      ps_cron              IN     VARCHAR2,
      ps_status            IN     VARCHAR2,
      ps_payment_details      IN     CLOB,
      pc_ref                  OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_status       VARCHAR2 (10) := '';
      ls_returncode   VARCHAR2 (3) := '000';
      ls_name         VARCHAR2 (100) := '';
      ls_type         VARCHAR2 (100) := '';
      ls_account_to   VARCHAR (100);

      CURSOR autopmnt
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE     PERSON_ID = pn_person_id
                AND seq_id = ps_seqId;

      res_pmnt        autopmnt%ROWTYPE;
      json_txinfo     CORPINT2.JSON;
   BEGIN
      --json_txinfo := corpint2.json (ps_payment_details);

      IF ps_operation = 'ENABLE'
      THEN
         ls_status := 'sENAB';
      ELSIF ps_operation = 'DISABLE'
      THEN
         ls_status := 'sDISAB';
      ELSIF ps_operation = 'DELETE'
      THEN
         ls_status := 'sDLTED';
      ELSIF ps_operation = 'MODIFY'
      THEN
         ls_status := 'sMDFY';
      END IF;

      IF ls_status IN ('sENAB',
                       'sDISAB',
                       'sDLTED',
                       'sMDFY')
      THEN
         OPEN autopmnt;

         FETCH autopmnt INTO res_pmnt;

         IF autopmnt%FOUND
         THEN
            log_at ('PKG_AUTOPAYMENT.modifyAutopayment',
                    'ls_name' || ps_title,
                    ps_title);

            UPDATE CORPINT2.tbl_autopayment
               SET status = 'sENAB',
                   payment_name = ps_title,
                   payment_type = ps_type,
                   payment_details = ps_payment_details,
                   account_no = ps_fromAccount,
                   account_to = ps_toAccount,
                   amount = ps_amount,
                   cron_time=ps_cron,
                   NEXT_DATE_TIME = to_date(ps_nextDateTime,'dd.mm.yyyy hh24:mi')
             WHERE     PERSON_ID = pn_person_id
                   AND SEQ_ID  = ps_seqId;

            OPEN pc_ref FOR
               SELECT *
                 FROM CORPINT2.TBL_AUTOPAYMENT p
                WHERE     PERSON_ID = pn_person_id
                      AND PAYMENT_NAME = ls_name
                      AND ACCOUNT_TO = ls_account_to;

            COMMIT;
         ELSE
            ls_returncode := '072';
            log_at ('pkg_autopayment.modifyAutopayment', ls_returncode);
         END IF;

         CLOSE autopmnt;
      ELSE
         ls_returncode := '078';
         log_at ('pkg_autopayment.modifyAutopayment', ls_returncode);
      END IF;

      log_at ('pkg_autopayment.modifyAutopayment',
              ls_returncode,
              ls_status,
              ps_operation);
      COMMIT;
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '999';
         log_at ('pkg_autopayment.modifyAutopayment',
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         --    OPEN pc_ref FOR SELECT sysdate FROM dual;
         RETURN ls_returncode;
   END;

   /******************************************************************************
      Name       : FUNCTION getAllAutopayments
      Created By : Guzal Zainulina 23.11.2017
      Purpose      : get Autopayment information
   ******************************************************************************/
   FUNCTION getAllAutopayments (pn_person_id   IN     VARCHAR2,
                                pc_ref            OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_returncode      VARCHAR2 (3) := '000';
      ls_autopay_count   NUMBER := 0;
      p_personid         VARCHAR2 (10) := '000';
      noCustomerFound    EXCEPTION;
   BEGIN
      IF (pn_person_id IS NULL)
      THEN
         RAISE noCustomerFound;
      END IF;

      OPEN pc_ref FOR SELECT '-' FROM DUAL;

      --    log_at('pkg_autopayment.getAutoPaymentInfo',custNo);
      --    getPersonIDByCustomerId(custNo,p_personid) ;
      OPEN pc_ref FOR
           SELECT *
             FROM TBL_AUTOPAYMENT atp
            WHERE ATP.PERSON_ID = pn_person_id
            and STATUS = 'sENAB'
         ORDER BY seq_id DESC;

      RETURN ls_returncode;
   EXCEPTION
      WHEN noCustomerFound
      THEN
         ls_returncode := '999';
         RETURN ls_returncode;
      WHEN NO_DATA_FOUND
      THEN
         ls_returncode := '503';
         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         Log_At ('PKG_AUTOPAYMENT.GetAutopaymentInfo', SQLERRM);
         ls_returncode := '999';
         RAISE_APPLICATION_ERROR (-20100, SQLERRM);

         OPEN pc_ref FOR SELECT '-' FROM DUAL;

         RETURN ls_returncode;
   END;

   /******************************************************************************
      Name       : FUNCTION processAutopayment
      Created By : Guzal Zainulina 15.01.2018
      Purpose      : process Autopayment
   ******************************************************************************/
   FUNCTION processAutopayment (pn_seq_id IN NUMBER)
      RETURN VARCHAR2
   IS
      ls_return         VARCHAR2 (100) := '000';
      ls_debitAccount   VARCHAR2 (1000);
      ls_amount         VARCHAR2 (1000);
      ls_balance        VARCHAR2 (3) := '000';
      ls_tries          NUMBER;
      const_tries       NUMBER;
      ls_type           VARCHAR2 (5) := 'EMAIL';
      json_txinfo       CORPINT2.JSON;
      pc_ref            CursorReferenceType;

      CURSOR payments
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE SEQ_ID = pn_seq_id;


      res_pmt           payments%ROWTYPE;
   BEGIN

      OPEN payments;

      FETCH payments INTO res_pmt;

      json_txinfo := corpint2.json (res_pmt.payment_details);
      pkg_parametre.deger ('AUTOPAYEMNT_TRIES', const_tries);
      IF (res_pmt.TRY_NUM < const_tries AND res_pmt.STATUS != 'sDISAB')
      THEN

            IF (res_pmt.TRAN_CODE = '9503' OR res_pmt.TRAN_CODE = '6330')
            THEN
                ls_return := processServicePayments(pn_seq_id,
                                                    res_pmt.PERSON_ID,
                                                    pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '1203' OR res_pmt.TRAN_CODE = '9501') THEN
                 log_at ('PKG_AUTOPAYMENT.processB2BPayments','res_pmt.TRAN_CODE',res_pmt.TRAN_CODE);
                ls_return :=
                      processB2BPayments (pn_seq_id,
                                          res_pmt.PERSON_ID,
                                           pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '3555' OR res_pmt.TRAN_CODE = '9502')   THEN
               ls_return :=
                      processClearingPayments (pn_seq_id,
                                    res_pmt.PERSON_ID,
                                    pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '4003')   THEN
               ls_return :=
                      processSWIFTPayments (pn_seq_id,
                                    res_pmt.PERSON_ID,
                                    pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '4025' OR res_pmt.TRAN_CODE = '1202')   THEN
               ls_return :=
                      processEXCH_BUY_SELL_Payments (pn_seq_id,
                                    res_pmt.PERSON_ID,
                                    pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '1207')   THEN
               ls_return :=
                      processArbitrajPayemtnts (pn_seq_id,
                                    res_pmt.PERSON_ID,
                                    pc_ref);

            ELSIF (res_pmt.TRAN_CODE = '7723')   THEN
               ls_return :=
                      processCardPayments (pn_seq_id,
                                    res_pmt.PERSON_ID,
                                    pc_ref);
            ELSE
               ls_return := '053';
            END IF;
      ELSE
         ls_return := '999';

      END IF;
    IF (ls_return='000') THEN
    UPDATE CORPINT2.TBL_AUTOPAYMENT
                  SET PREV_ERR_DETAILS ='',
                      EXECUTION_TIME = SYSDATE,
                      PREV_RET_CODE = '000',
                      PREV_DATE = res_pmt.EXECUTION_TIME
                WHERE SEQ_ID = pn_seq_id;
    END IF;

    IF (ls_return<>'000') THEN
        UPDATE CORPINT2.TBL_AUTOPAYMENT
                  SET PREV_ERR_DETAILS ='ERROR '||ls_return,
                      STATUS = 'sDISAB',
                      EXECUTION_TIME = SYSDATE,
                      --PREV_RET_CODE = ls_return,
                      PREV_DATE = SYSDATE,
                      TRY_NUM = TRY_NUM + 1
                WHERE SEQ_ID = pn_seq_id;

        notifyPerson (res_pmt.CUSTOMER_ID, ls_type);
    END IF;

      COMMIT;
      RETURN ls_return;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         log_at ('PKG_AUTOPAYMENT.processAutopayment',UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN SQLERRM;
   END;


   FUNCTION processServicePayments (ps_seq_id      IN     NUMBER,
                                    pn_person_id   IN     NUMBER,
                                    pc_ref            OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_currency      VARCHAR2 (10);
      ls_amount        VARCHAR2 (15);
      ls_trig_type     VARCHAR2 (10);
      ls_returncode    VARCHAR2 (3) := '000';

      ps_trig_curr     VARCHAR2 (10);
      ps_trig_amount   VARCHAR2 (15);
      ps_from_account    VARCHAR2 (100);
      ps_phone_code    VARCHAR (10);
      ps_phone_no      VARCHAR2 (30);
      ps_phone         VARCHAR (40);

      json_txinfo      CORPINT2.JSON;

      cursor cur_details is
      select * from CORPINT2.TBL_AUTOPAYMENT p
      where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

      r_detail         cur_details%rowtype;

   BEGIN

      for cur_detail in cur_details  loop
            r_detail :=cur_detail;
      end loop;

      json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);
      ls_currency := json_txinfo.get ('localCurrency').get_string ();
      ps_trig_curr := json_txinfo.get ('fromCurrency').get_string ();
      ps_trig_amount := json_txinfo.get ('amount').get_string ();
      ps_from_account := json_txinfo.get ('debitAccount').get_string ();
      ps_phone := json_txinfo.get ('creditAccount').get_string ();
      ps_phone_code :=
         SUBSTR (ps_phone, INSTR (ps_phone, '(', 1, 1) + 1, INSTR (ps_phone, ')', 1, 1)- INSTR (ps_phone, '(', 1, 1) - 1);
      ps_phone_no :=
         REPLACE (SUBSTR (ps_phone, INSTR (ps_phone, ')', 1, 1) + 1), '-', '');
      ls_trig_type := json_txinfo.get ('type').get_string ();

      IF ls_currency = ps_trig_curr
      THEN
         ls_amount := ps_trig_amount;
      ELSE
         ls_amount :=
            TO_CHAR (Pkg_Kur.doviz_doviz_karsilik (ps_trig_curr,
                                                   ls_currency,
                                                   NULL,
                                                   ps_trig_amount,
                                                   1,
                                                   NULL,
                                                   NULL,
                                                   'N',
                                                   'A'),
                     '999999999.99');
          log_at ('PKG_AUTOPAYMENT.processServicePayments', ls_amount);
      END IF;


      ls_returncode :=
         cbs.pkg_soa_common.BakiyeYeterlimi (ps_from_account,         -- account
                                             ls_amount,              -- amount
                                             pc_ref);
     log_at ('PKG_AUTOPAYMENT.cbs.pkg_soa_common.BakiyeYeterlimi', ls_returncode);
     IF ls_returncode <> '000'
      THEN
         RETURN ls_returncode;
      END IF;

      ls_returncode :=
         cbs.pkg_soa_transaction.PayForServices (
            ps_from_account,                                     -- from account
            ps_trig_amount,                                               -- amount
            json_txinfo.get ('title').get_string (),         -- description
            ps_trig_curr,                                     -- currency code
            json_txinfo.get ('institution').get_string (),      -- institution
            ps_phone_code,                                  -- phone area code
            ps_phone_no,                                           -- phone no
            '',                                                -- service code
            '',                                                  -- service no
            pc_ref);
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('PKG_AUTOPAYMENT.makePAYMENTS', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
         RETURN '999';
   END;

    FUNCTION processB2BPayments(ps_seq_id      IN     NUMBER,
                                pn_person_id   IN     NUMBER,
                                pc_ref         OUT    CursorReferenceType) RETURN varchar2 IS

    ls_currency      VARCHAR2 (10);
    ls_amount        VARCHAR2 (15);
    ls_returncode    VARCHAR2 (3) := '000';
    ps_trig_curr     VARCHAR2 (10);
    ps_from_account    VARCHAR2 (100);
    ps_to_account     VARCHAR2 (1000);
    ps_tran_cd       VARCHAR2 (15);
    ps_customer_id   VARCHAR2 (50);
    ls_fx_rates      VARCHAR2(50);
    ld_date          DATE;
    ls_details       CLOB;

    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

    json_txinfo      CORPINT2.JSON;
    r_detail         cur_details%rowtype;
    BEGIN
        for cur_detail in cur_details  loop
            r_detail :=cur_detail;
        end loop;
        log_at ('PKG_AUTOPAYMENT.processB2BPayments','parse','start');
        json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);
        ls_currency := json_txinfo.get ('fromCurrCode').get_string ();
        ls_amount := r_detail.amount;
        ps_trig_curr := json_txinfo.get ('fromCurrCode').get_string ();
        ps_from_account := json_txinfo.get ('debitAccount').get_string ();
        ps_to_account := json_txinfo.get ('toAccountExternal').get_string ();
        ps_customer_id := r_detail.CUSTOMER_ID;
        log_at ('PKG_AUTOPAYMENT.processB2BPayments','parse','end');
        ps_tran_cd := r_detail.tran_cd;
        IF (ps_tran_cd = 'B2BTRANSF') THEN
        log_at ('PKG_AUTOPAYMENT.processB2BPayments','ps_tran_cd',ps_tran_cd);
            --ls_amount :=ps_trig_amount;
            ls_returncode := cbs.pkg_soa_common.HesapMusteriKontrol(ps_from_account, --  from account
                                                                                                     ps_customer_id, --  customer id
                                                                                                     pc_ref);


            log_at ('PKG_AUTOPAYMENT.processB2BPayments','HesapMusteriKontrol',ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ls_amount, -- amount
                                               ls_currency, -- currency code
                                                pc_ref);
            log_at ('PKG_AUTOPAYMENT.processB2BPayments','CheckLimit',ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

            ls_returncode := cbs.pkg_soa_transaction.BooktoBookTransfer(ps_from_account, -- from account
                                                                                                       ps_to_account, -- to account
                                                                                                        ls_amount, -- amount
                                                                                                        json_txinfo.get ('description').get_string (), -- description
                                                                                                        json_txinfo.get ('fromCurrCode').get_string (), -- currency code
                                                                                                        'X', -- dekont istemiyorum 'X'
                                                                                                        json_txinfo.get ('paymentCode').get_string (), -- payment code
                                                                                                        pc_ref);
               log_at ('PKG_AUTOPAYMENT.processB2BPayments','BooktoBookTransfer',ls_returncode);
               IF ls_returncode <> '000' THEN
                return ls_returncode;
               END IF;

               ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
               IF ls_returncode <> '000' THEN
                rollback;
                return 'getExchangeRatesIB'||ls_returncode;
               END IF;

               ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                ps_tran_cd, -- tran cd
                                                                                ls_amount, -- amount
                                                                                ps_trig_curr, -- currency code
                                                                                pc_ref);
             log_at ('PKG_AUTOPAYMENT.processB2BPayments','UpdateLimit',ls_returncode);
                IF ls_returncode <> '000' THEN
                    rollback;
                    return 'UpdateLimit'||ls_returncode;
                END IF;
        ELSIF (ps_tran_cd = 'B2OBTRANSF') THEN
--            IF ls_currency = ps_trig_curr THEN
--                        ls_amount := ps_trig_amount;
--                    ELSE
--                        ls_amount := to_char(Pkg_Kur.doviz_doviz_karsilik(ps_trig_curr, ls_currency, NULL,
--                                                                                        ps_trig_amount, 1, NULL, NULL, 'N', 'A'), '999999999.99');
--            END IF;
             log_at ('PKG_AUTOPAYMENT.processB2BPayments','ps_tran_cd',ps_tran_cd);
            ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);
            log_at ('PKG_AUTOPAYMENT.processB2BPayments','getExchangeRatesIB',ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ls_amount, -- amount
                                               ls_currency, -- currency code
                                                pc_ref);
             log_at ('PKG_AUTOPAYMENT.processB2BPayments','CheckLimit',ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
            ls_returncode := cbs.pkg_soa_transaction.BooktoBookTransfer(ps_from_account, -- from account
                                                                                                       ps_to_account, -- to account
                                                                                                        ls_amount, -- amount
                                                                                                        json_txinfo.get ('description').get_string (), -- description
                                                                                                        json_txinfo.get ('fromCurrCode').get_string (), -- currency code
                                                                                                        'X', -- dekont istemiyorum 'X'
                                                                                                        json_txinfo.get ('paymentCode').get_string (), -- payment code
                                                                                                        pc_ref);
                 log_at ('PKG_AUTOPAYMENT.processB2BPayments','BooktoBookTransfer',ls_returncode);
             ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                ps_tran_cd, -- tran cd
                                                                                ls_amount, -- amount
                                                                                ps_trig_curr, -- currency code
                                                                                pc_ref);
              log_at ('PKG_AUTOPAYMENT.processB2BPayments','UpdateLimit',ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;
        END IF;

     RETURN ls_returncode;

   EXCEPTION
      WHEN OTHERS
      THEN
      log_at ('PKG_AUTOPAYMENT.processB2BPayments',UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
         RETURN '999';
    END;

FUNCTION processClearingPayments(ps_seq_id      IN     NUMBER,
                         pn_person_id   IN     NUMBER,
                         pc_ref         OUT    CursorReferenceType) RETURN varchar2 IS

    ls_currency      VARCHAR2 (10);
    ls_amount        VARCHAR2 (15);
    ls_returncode    VARCHAR2 (3) := '000';
    ps_trig_amount   VARCHAR2 (15);
    ps_from_account    VARCHAR2 (100);
    ps_to_account     VARCHAR2 (100);
    ps_tran_cd       VARCHAR2 (15);
    ps_customer_id   VARCHAR2 (50);
    ls_fx_rates      VARCHAR2(50);
    ls_maturity_date VARCHAR2(50);
    ld_date          DATE;
    ls_commAmount VARCHAR2(15);
    ls_commTax    VARCHAR2(15);
    json_txinfo      CORPINT2.JSON;

    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

    r_detail         cur_details%rowtype;

BEGIN
    for cur_detail in cur_details  loop
            r_detail :=cur_detail;
    end loop;

 json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);
 ls_currency := json_txinfo.get ('fromCurrCode').get_string ();
 ps_from_account := json_txinfo.get ('debitAccount').get_string ();
 ps_to_account := json_txinfo.get ('receiverAccount').get_string ();
 ps_customer_id := r_detail.CUSTOMER_ID;
 ls_amount := r_detail.amount;
 log_at ('PKG_AUTOPAYMENT.processClearing', 'PARSED' ,ps_customer_id);
 ps_tran_cd := r_detail.tran_cd;
  log_at ('PKG_AUTOPAYMENT.processClearingPayments', 'Pkg_Kur.doviz_doviz_karsilik',ls_returncode);

 ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);


 IF ls_returncode <> '000' THEN
    return ls_returncode;
 END IF;
 ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ls_amount, -- amount
                                               ls_currency, -- currency code
                                                pc_ref);


 IF ls_returncode <> '000' THEN
    return ls_returncode;
 END IF;

 ls_returncode := CORPINT2.pkg_autopayment.getMaturityDate(json_txinfo.get ('tranDate').get_string (), -- tran date
                                                          ps_tran_cd, -- tran cd
                                                          '', -- type
                                                          ls_maturity_date); --  return maturity date


 IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

 IF (ps_tran_cd='GROSS') THEN
       ls_returncode := cbs.PKG_INT_TRANSFER.MAKEEFT(ps_from_account, --ps_from_acc
                                                  json_txinfo.get ('payeeDescription').get_string (), --ps_payee_info
                                                  json_txinfo.get ('tranDate').get_string (), -- pd_trandate
                                                  json_txinfo.get ('senderName').get_string (), -- ps_sender_name
                                                  '', -- ps_sender_phone
                                                  json_txinfo.get ('bankCode').get_string (), -- ps_bank_code
                                                  json_txinfo.get ('receiverName').get_string (), -- ps_payee_name
                                                  ps_to_account, -- ps_to_account
                                                  ls_amount, -- pn_amount
                                                  json_txinfo.get ('description').get_string (), -- ps_description
                                                  '', --ps_save_payee_flag
                                                  '', -- ps_payee_nick
                                                  json_txinfo.get ('paymentCode').get_string (), -- pn_paycode
                                                  '', --pn_subaccount
                                                  '', --ps_subname
                                                  '', --ps_payforservice
                                                  ps_tran_cd, --ps_transfer_option
                                                  json_txinfo.get ('orderNumber').get_string (), --ps_order_number
                                                  pc_ref);
  ELSE
 ls_returncode := cbs.pkg_soa_transaction.MakeEFT(ps_from_account, --ps_from_acc
                                                  json_txinfo.get ('payeeDescription').get_string (), --ps_payee_info
                                                  json_txinfo.get ('tranDate').get_string (), -- pd_trandate
                                                  json_txinfo.get ('senderName').get_string (), -- ps_sender_name
                                                  '', -- ps_sender_phone
                                                  json_txinfo.get ('bankCode').get_string (), -- ps_bank_code
                                                  json_txinfo.get ('receiverName').get_string (), -- ps_payee_name
                                                  ps_to_account, -- ps_to_account
                                                  ls_amount, -- pn_amount
                                                  json_txinfo.get ('description').get_string (), -- ps_description
                                                  '', --ps_save_payee_flag
                                                  '', -- ps_payee_nick
                                                  '', -- ps_payee_phone
                                                  '', --pn_rnn
                                                  '', --pn_doc_no
                                                  '', --pn_stat
                                                  json_txinfo.get ('paymentCode').get_string (), --pn_paycode
                                                  '', --pn_income
                                                  ps_tran_cd, --ps_payment_type
                                                  pc_ref);
    END IF;
 IF ls_returncode <> '000' THEN
    return ls_returncode;
 END IF;
IF ls_returncode <> '000' THEN
   return ls_returncode;
END IF;
 ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                ps_tran_cd, -- tran cd
                                                                                ls_amount, -- amount
                                                                                ls_currency, -- currency code
                                                                                pc_ref);


RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processClearingPayments', SQLERRM);
--    raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    RETURN '999';
END;

FUNCTION processSWIFTPayments (ps_seq_id      IN     NUMBER,
                                 pn_person_id   IN     NUMBER,
                                 pc_ref         OUT    CursorReferenceType) RETURN varchar2 IS
    ls_accountCurrency varchar2(500);
    ls_currency      VARCHAR2 (10);
    ls_amount        VARCHAR2 (15);
    ls_returncode    VARCHAR2 (3) := '000';
    ls_benBankCountry     VARCHAR2 (100);
    ls_paymentCode      VARCHAR2 (100);
    ls_execType         varchar(100);
    ps_trig_amount   VARCHAR2 (15);
    ps_from_account    VARCHAR2 (100);
    ps_to_account     VARCHAR2 (100);
    ps_tran_cd       VARCHAR2 (15);
    ps_customer_id   VARCHAR2 (50);
    ls_fx_rates      VARCHAR2(50);
    ls_maturity_date VARCHAR2(50);
    ld_date          DATE;
    ls_commAmount VARCHAR2(15);
    ls_commTax    VARCHAR2(15);
    ls_swift_code VARCHAR2(30);
    ls_ben_bank   VARCHAR2(300);
    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

    json_txinfo      CORPINT2.JSON;
    r_detail         cur_details%rowtype;

      BEGIN
        for cur_detail in cur_details  loop
            r_detail :=cur_detail;
        end loop;


     json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);

     ls_accountCurrency:=json_txinfo.get ('accountNo').get_string ();
     ls_currency := SUBSTR(ls_accountCurrency, INSTR(ls_accountCurrency, '#') + 1);
     ps_trig_amount := r_detail.amount;
     ps_from_account := SUBSTR(ls_accountCurrency, 0,INSTR(ls_accountCurrency, '#')-1);
     ps_to_account := REGEXP_REPLACE(json_txinfo.get ('benAccountNo').get_string (), '\s');
     ps_customer_id := r_detail.CUSTOMER_ID;
     ls_ben_bank := json_txinfo.get ('benBank').get_string ();
     ls_benBankCountry := json_txinfo.get ('benBankCountry').get_string ();
     ls_swift_code := SUBSTR(ls_ben_bank, 0,INSTR(ls_ben_bank, '#')-1);
     log_at ('PKG_AUTOPAYMENT.processSWIFTPayments', 'PARSED' ,ps_customer_id);
     log_at('PKG_AUTOPAYMENT.processSWIFTPayments','1',' PARSED ');
     ps_tran_cd := r_detail.tran_cd;
     ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(ps_from_account, -- account
                                                         ps_trig_amount, -- amount
                                                         pc_ref);
    IF ls_returncode <> '000' THEN
        return ls_returncode;
     END IF;

     ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 2, ls_fx_rates);

            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

     ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ps_trig_amount, -- amount
                                               ls_currency, -- currency code
                                                pc_ref);
     log_at('PKG_AUTOPAYMENT.processSWIFTPayments','4', ls_returncode);
     IF ls_returncode <> '000' THEN
        return ls_returncode;
     END IF;

     ls_returncode := CORPINT2.pkg_autopayment.getMaturityDate(TO_CHAR(sysdate, 'YYYYMMDD'), -- tran date
                                                          ps_tran_cd, -- tran cd
                                                          '', -- type
                                                          ls_maturity_date); --  return maturity date

    log_at('PKG_AUTOPAYMENT.getMaturityDate','5', ls_returncode);
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;

    IF (json_txinfo.get ('commissionType').get_string()='OUR') THEN
       ls_execType:='N'||'###'||json_txinfo.get ('execType').get_string();
    ELSE ls_execType:='B'||'###'||json_txinfo.get ('execType').get_string();
    END IF;

    ls_returncode := cbs.pkg_soa_transaction.MAKESwift(ps_trig_amount       ,
                                                        ls_currency     ,
                                                        ps_from_account    ,
                                                        SUBSTR(ls_benBankCountry, 0,INSTR(ls_benBankCountry, '#')-1),
                                                        TO_CHAR(sysdate, 'YYYYMMDD'),
                                                        json_txinfo.get ('transferAim').get_string (),
                                                        TO_CHAR(sysdate, 'YYYYMMDD'),
                                                        json_txinfo.get ('benName').get_string (),
                                                        json_txinfo.get ('benAddress').get_string (),
                                                        ps_to_account,
                                                        ls_execType,
                                                        json_txinfo.get ('paymentCode').get_string (),
                                                        ls_swift_code,
                                                         concat(json_txinfo.get ('statCode1').get_string (),json_txinfo.get ('statCode2').get_string ()),
                                                        SUBSTR(ls_ben_bank, 0,INSTR(ls_ben_bank, '#')+1),
                                                        json_txinfo.get ('commissionAmount').get_string (),
                                                        json_txinfo.get ('benPhone').get_string (),
                                                        '',
                                                        json_txinfo.get ('contractCheck').get_string(),
                                                        json_txinfo.get ('benBankCity').get_string (),
                                                        ps_from_account,
                                                        pc_ref);

            log_at('PKG_AUTOPAYMENT.MAKESwift','6', ls_returncode);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

    ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                ps_tran_cd, -- tran cd
                                                                                ps_trig_amount, -- amount
                                                                                ls_currency, -- currency code
                                                                                pc_ref);
        log_at('PKG_AUTOPAYMENT.UpdateLimit','7', ls_returncode);
RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processSWIFTPayments', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    RETURN '999';
END;

FUNCTION processEXCH_BUY_SELL_Payments(ps_seq_id      IN     NUMBER,
                         pn_person_id   IN     NUMBER,
                         pc_ref         OUT    CursorReferenceType) RETURN varchar2 IS
    ls_amount        VARCHAR2 (15);
    ls_returncode    VARCHAR2 (3) := '000';
    ps_from_curr     VARCHAR2 (10);
    ps_to_curr       VARCHAR2 (10);
    ps_trig_amount   VARCHAR2 (15);
    ps_from_account    VARCHAR2 (100);
    ps_to_account     VARCHAR2 (100);
    ps_tran_cd       VARCHAR2 (15);
    ps_tran_type     VARCHAR2 (10);
    ps_customer_id   VARCHAR2 (50);
    ls_rate          varchar2(50);
    ls_fx_rates      VARCHAR2(50);
    ls_maturity_date VARCHAR2(50);
    ls_foreigncurr   VARCHAR2(50);
    lc_amount_curr   VARCHAR2(50);
    ld_date          DATE;
    ls_commAmount VARCHAR2(15);
    ls_commTax    VARCHAR2(15);
    ls_curr_amount     VARCHAR2 (15);
    ls_total_amount    VARCHAR2 (15);

    json_txinfo      CORPINT2.JSON;

    pc_ref_1           cursorreferencetype;
    pc_ref_2           cursorreferencetype;
    pc_ref_3           cursorreferencetype;
    pc_ref_4           cursorreferencetype;
    pc_ref_5           cursorreferencetype;

    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

    r_detail         cur_details%rowtype;

   BEGIN

     for cur_detail in cur_details  loop
            r_detail :=cur_detail;
     end loop;

     json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);

     ps_from_curr := json_txinfo.get ('fromAccountCurrency').get_string ();
     ps_to_curr := json_txinfo.get ('toAccountCurrency').get_string ();
     ps_trig_amount := r_detail.amount;
     ps_from_account := json_txinfo.get ('fromAccountNo').get_string ();
     ps_to_account := json_txinfo.get ('toAccountNo').get_string ();
     ps_customer_id := r_detail.CUSTOMER_ID;

     ps_tran_cd := r_detail.tran_cd;
     ps_tran_type := json_txinfo.get ('tranType').get_string (); -- A or S
     lc_amount_curr:=json_txinfo.get ('amountCurrency').get_string();

     if (ps_from_curr = 'KGS') then
        ls_foreigncurr :=ps_to_curr;
     else ls_foreigncurr :=ps_from_curr;
     end if;
     ls_returncode :=
               cbs.pkg_soa_inquiry.ExchangeTransactions (
                  '',                         -- option
                  ps_customer_id,                   -- customer id
                  pn_person_id,                                   -- person id
                  r_detail.CHANNEL_CD,                    -- channel cd
                  ps_tran_cd,                       -- tran cd
                  ps_tran_type,                      -- tran type
                  ls_amount,                                         -- amount
                  lc_amount_curr,                                     -- currency
                  ls_foreigncurr,             --  foreign currency
                  '',                -- reservation no
                  pc_ref_1,
                  pc_ref_2,
                  pc_ref_3,
                  pc_ref_4,
                  pc_ref_5);

      log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments','ExchangeTransactions',ls_returncode);
      IF ls_returncode <> '000'
      THEN
         RETURN ls_returncode;
      END IF;

      ls_returncode :=
               CORPINT2.pkg_autopayment.getExchangeRatioIB (
                  pc_ref_2,
                  ps_tran_type,
                  ls_curr_amount,
                  ls_total_amount,
                  ls_rate);

      log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments','getExchangeRatioIB',ls_returncode);
      ls_returncode :=
               cbs.pkg_soa_common.BakiyeYeterlimi (ps_from_account, -- account
                                                   ls_total_amount,  -- amount
                                                   pc_ref);

      IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
            END IF;

     ls_returncode :=
               CORPINT2.pkg_autopayment.getExchangeRatesIB (ld_date,
                                                           3,
                                                           ls_fx_rates);

      log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments','getExchangeRatesIB',ls_returncode);
      IF ls_returncode <> '000'
        THEN
      RETURN ls_returncode;
      END IF;

      ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ls_amount, -- amount
                                               ps_from_curr, -- currency code
                                                pc_ref);


      log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments','CheckLimit',ls_returncode);
      IF ls_returncode <> '000'
      THEN
      RETURN ls_returncode;
      END IF;

      ls_returncode :=
               cbs.pkg_soa_inquiry.CallExchangeTran (
                 '',                         -- option
                 ps_customer_id,                    -- customer id
                 pn_person_id,                      -- person_id
                 r_detail.CHANNEL_CD,                     -- channel cd
                 ps_tran_cd,                        -- tran cd
                 ps_tran_type,                      -- tran type
                 ps_from_account,                   -- from account
                 ps_to_account,                     -- to account
                 ps_trig_amount,                    -- amount
                 lc_amount_curr,                      -- amount currency
                 ls_rate,                                             -- rate
                 '',                -- reservation no
                 ps_tran_cd,                   -- description
                 '',                       -- expense
                 '',                -- statistic code
                 ls_total_amount,                             -- total amount
                  pc_ref,
                  pc_ref_2,
                  pc_ref_3,
                  pc_ref_4,
                  pc_ref_5);


     log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments','CallExchangeTran',ls_returncode);
     if ls_returncode <> '000' then
     return '999';
     end if;
     return ls_returncode;
     EXCEPTION
 WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processEXCH_BUY_SELL_Payments', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    RETURN '999';
     END;

FUNCTION processArbitrajPayemtnts (ps_seq_id      IN     NUMBER,
                         pn_person_id   IN     NUMBER,
                         pc_ref         OUT    CursorReferenceType) RETURN varchar2 IS
    ls_amount        VARCHAR2 (15);
    ls_amount_curr   VARCHAR2 (15);
    ls_returncode    VARCHAR2 (3) := '000';
    ps_from_curr     VARCHAR2 (10);
    ps_to_curr       VARCHAR2 (10);
    ps_trig_amount   VARCHAR2 (15);
    ps_from_account    VARCHAR2 (100);
    ps_to_account     VARCHAR2 (100);
    ps_tran_cd       VARCHAR2 (15);
    ps_tran_type     VARCHAR2 (10);
    ps_customer_id   VARCHAR2 (50);
    ls_rate          varchar2(50);
    ls_fx_rates      VARCHAR2(50);
    ls_maturity_date VARCHAR2(50);
    ls_foreigncurr   VARCHAR2(50);
    ls_parity VARCHAR2(100);
    ld_date          DATE;
    ls_commAmount VARCHAR2(15);
    ls_commTax    VARCHAR2(15);
    ls_curr_amount     VARCHAR2 (15);
    ls_total_amount    VARCHAR2 (15);
    ls_from_amount VARCHAR2(100);
    ls_to_amount VARCHAR2(100);
    lc_fc       VARCHAR2(15);
    json_txinfo      CORPINT2.JSON;

    pc_ref_1           cursorreferencetype;
    pc_ref_2           cursorreferencetype;
    pc_ref_3           cursorreferencetype;
    pc_ref_4           cursorreferencetype;
    pc_ref_5           cursorreferencetype;

    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

    r_detail         cur_details%rowtype;

   BEGIN

     for cur_detail in cur_details  loop
            r_detail :=cur_detail;
     end loop;

     json_txinfo := corpint2.json (r_detail.PAYMENT_DETAILS);
     ps_from_curr := json_txinfo.get ('fromAccountCurrency').get_string ();
     ps_to_curr := json_txinfo.get ('toAccountCurrency').get_string ();
     ls_amount := r_detail.amount;
     ls_amount_curr := json_txinfo.get ('amountCurrency').get_string ();
     ps_from_account := json_txinfo.get ('fromAccountNo').get_string ();
     ps_to_account := json_txinfo.get ('toAccountNo').get_string ();
     ps_customer_id := r_detail.CUSTOMER_ID;

     ps_tran_cd := r_detail.tran_cd;

     IF (ps_from_curr = ls_amount_curr) THEN
            lc_fc :='LC';
     ELSE lc_fc :='FC';
     END IF;
     ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 4, ls_fx_rates);
            IF ls_returncode <> '000' THEN
                return ls_returncode;
            END IF;

     log_at ('PKG_AUTOPAYMENT.processArbitrajPayemtnts','getExchangeRatesIB',ls_returncode);

     ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               ps_tran_cd, -- tran cd
                                               ls_amount, -- amount
                                               ps_from_curr, -- currency code
                                                pc_ref);
     DBMS_OUTPUT.put_line('1 '||ls_returncode);
     IF ls_returncode <> '000' THEN
        return ls_returncode;
     END IF;

      ls_returncode := cbs.pkg_soa_inquiry.CheckArbitraje('NULLOPTION', -- option
                                                           ps_customer_id, -- customer id
                                                           pn_person_id, -- person id
                                                           r_detail.CHANNEL_CD, -- channel cd
                                                           ps_tran_cd, -- tran cd
                                                           ps_to_account, -- to account
                                                           ps_from_account, -- from account
                                                           ps_to_curr, -- to account currency
                                                           ps_from_curr, -- from account currency
                                                           ls_amount, -- amount
                                                           lc_fc, -- amount currency
                                                           pc_ref_1,
                                                           pc_ref_2,
                                                           pc_ref_3,
                                                           pc_ref_4,
                                                           pc_ref_5);

     log_at ('PKG_AUTOPAYMENT.processArbitrajPayemtnts','CheckArbitraje',ls_returncode);
     IF ls_returncode <> '000' THEN
             return ls_returncode;
     END IF;

     ls_returncode := pkg_autopayment.getExchangeParityIB(pc_ref_1,
                                                          pc_ref_2,
                                                          lc_fc,
                                                          ls_parity,
                                                          ls_from_amount,
                                                          ls_to_amount);

   log_at ('PKG_AUTOPAYMENT.processArbitrajPayemtnts','getExchangeParityIB',ls_returncode);

       IF ls_returncode <> '000' THEN
           return ls_returncode;
       END IF;

       ls_returncode := cbs.pkg_soa_inquiry.CallArbitTran('NULLOPTION', -- option
                                                           ps_customer_id, -- customer id
                                                           pn_person_id, -- person_id
                                                           r_detail.CHANNEL_CD, -- channel cd
                                                           ps_tran_cd, -- tran cd
                                                           ps_to_account, -- to account
                                                           ps_from_account, -- from account
                                                           ps_to_curr, -- to account currency
                                                           ps_from_curr, -- from account currency
                                                           ls_parity, -- parity
                                                                                        ls_to_amount, -- to amount
                                                                                        ls_from_amount, -- from amount
                                                                                        pc_ref_1,
                                                                                        pc_ref_2,
                                                                                        pc_ref_3,
                                                                                        pc_ref_4,
                                                                                        pc_ref_5);

    log_at ('PKG_AUTOPAYMENT.processArbitrajPayemtnts','CallArbitTran',ls_returncode);

    IF ls_returncode <> '000' THEN
           return ls_returncode;
       END IF;
   return ls_returncode;
   EXCEPTION
 WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processArbitrajPayemtnts', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    RETURN '999';
END;

FUNCTION processCardPayments (ps_seq_id      IN     NUMBER,
                         pn_person_id   IN     NUMBER,
                         pc_ref         OUT    CursorReferenceType) RETURN VARCHAR2 IS

ls_returncode  VARCHAR2(3) :='000';
ls_account_no  VARCHAR2(100);
ls_amount      VARCHAR2(300);
ls_customer_id VARCHAR2(100);
ls_tran_cd     VARCHAR2(50);
ls_channel_cd  VARCHAR2(50);
ls_from_curr   VARCHAR2(50);
ld_date        DATE;
ls_amountType VARCHAR2(50);
ls_fx_rates    VARCHAR2(50);
ls_card_no     VARCHAR2(300);
ls_pan          VARCHAR2(100);
json_txinfo      CORPINT2.JSON;

    cursor cur_details is
    select * from CORPINT2.TBL_AUTOPAYMENT p
    where P.PERSON_ID = pn_person_id and P.SEQ_ID = ps_seq_id;

r_detail         cur_details%rowtype;


BEGIN

    for cur_detail in cur_details  loop
            r_detail :=cur_detail;
    end loop;

    json_txinfo := corpint2.json(r_detail.PAYMENT_DETAILS);
    ls_account_no := json_txinfo.get ('fromAccountNo').get_string ();
    ls_amountType := json_txinfo.get ('amountType').get_string ();
    ls_amount := r_detail.amount;
    ls_customer_id := r_detail.CUSTOMER_ID;
    ls_tran_cd := r_detail.tran_cd;
    ls_from_curr := json_txinfo.get ('fromAccountCurrency').get_string ();
    ls_card_no := json_txinfo.get ('selectedCardNumber').get_string ();
    ls_pan := json_txinfo.get ('pseudopan').get_string ();
    ls_returncode := cbs.pkg_soa_common.BakiyeYeterlimi(ls_account_no, -- account
                                                         ls_amount, -- amount
                                                         pc_ref);
    IF ls_returncode <> '000' THEN
       return ls_returncode;
    END IF;

    ls_returncode := CORPINT2.pkg_autopayment.getExchangeRatesIB(ld_date, 3, ls_fx_rates);

    IF ls_returncode <> '000' THEN
       return ls_returncode;
    END IF;

    ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                                   ls_tran_cd, -- tran cd
                                                   ls_amount, -- amount
                                                   ls_from_curr, -- currency code
                                                   pc_ref);

    IF ls_returncode <> '000' THEN
       return ls_returncode;
    END IF;

    ls_returncode := cbs.pkg_int_tx.CreditCardCPaymentTx(ls_customer_id, -- customer id
                                                         pn_person_id, -- person id
                                                         ls_account_no, -- from account
                                                         ls_amount, -- amount
                                                         ls_card_no, -- credit card no
                                                          ls_pan, --pseudopan
                                                          pc_ref);

    IF ls_returncode <> '000' THEN
       return ls_returncode;
    END IF;

    ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                ls_tran_cd, -- tran cd
                                                                                ls_amount, -- amount
                                                                                ls_from_curr, -- currency code
                                                                                pc_ref);

RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processCardPayments', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    RETURN '999';
END;
function createtaxpayments (ps_trancd                varchar2,
                               ps_makerid             varchar2,
                               ps_status              varchar2,
                               ps_tax_from_account    varchar2,
                               ps_tax_tin             varchar2,
                               ps_tax_address_id      varchar2,
                               ps_tax_amount          varchar2,
                               ps_tax_currency        varchar2,
                               ps_tax_to_account      varchar2,
                               ps_tax_description     varchar2,
                               pc_ref                 out   cursorreferencetype) return varchar2
is
 ln_txid NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 ls_paycode VARCHAR2(500);

 ls_status VARCHAR (10); 

BEGIN

 OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

 select corpint2.seq_txtodo.nextval into ln_txid from dual;


  INSERT INTO TBL_TAX_PAYMENTS_TODO
   (TX_NO,TRANCD,MAKERID,MAKEDATE,STATUS,
   TAX_FROM_ACCOUNT,TAX_TIN,TAX_ADDRESS_ID,TAX_AMOUNT,TAX_CURRENCY,
   TAX_TO_ACCOUNT,TAX_DESCRIPTION) 
  VALUES
   (ln_txid,ps_trancd,ps_makerid,SYSDATE,ps_status,
    ps_tax_from_account, ps_tax_tin, ps_tax_address_id, ps_tax_amount, ps_tax_currency,
    ps_tax_to_account, ps_tax_description);

   OPEN pc_ref FOR select ln_txid from dual;
   
   RETURN ls_returncode;

EXCEPTION
 WHEN OTHERS THEN
    cbs.log_at('clearingtodo', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    RETURN '708';
END;
FUNCTION  processTAXPayments (ps_seq_id      IN     NUMBER,
                                     pn_person_id   IN     NUMBER,
                                     pc_details     IN     CLOB,
                                     pc_ref         OUT    CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3) :='000';
    ls_account_from  VARCHAR2(100);
    ls_account_to  VARCHAR2(100);
    ls_amount      VARCHAR2(300);
    ls_customer_id VARCHAR2(100);
    ls_tran_cd     VARCHAR2(50);
    ls_channel_cd  VARCHAR2(50);
    ls_from_curr   VARCHAR2(50);
    ld_date        DATE;
    ls_fx_rates    VARCHAR2(50);
    ls_card_no     VARCHAR2(300);
    ls_commAmount  VARCHAR2(15);
    ls_commTax     VARCHAR2(15);
    ls_firstName        VARCHAR2(100);
    ls_secondName        VARCHAR2(100);
    ls_surName        VARCHAR2(100);
    pc_refName       CursorReferenceType;
    json_txinfo      CORPINT2.JSON;

BEGIN
    json_txinfo := corpint2.json(pc_details);
    ls_account_from := json_txinfo.get ('debitAccount').get_string ();
    ls_account_to:= json_txinfo.get ('creditAccount').get_string ();
    ls_amount := json_txinfo.get('amount').get_string();
    ls_customer_id := json_txinfo.get ('customerID').get_string ();
    ls_tran_cd := json_txinfo.get ('tranCode').get_string ();
    ls_channel_cd :=json_txinfo.get('channelCD').get_string();
    ls_from_curr := json_txinfo.get ('fromCurrency').get_string ();

    ls_returncode :=
               CORPINT2.pkg_autopayment.getCommissionIB (
                  ls_tran_cd,                       -- tran cd
                  ls_account_from,                   -- from account
                  ls_account_to,                   -- to account
                  ls_amount,                         -- amount
                  ls_from_curr,                      -- currency
                  ls_channel_cd,                         -- channel cd
                  ls_commAmount,
                  ls_commTax);

     IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

     ls_returncode :=
               cbs.pkg_soa_common.BakiyeYeterlimi (
                  ls_account_from,                        -- account
                  ls_amount,                        -- amount
                  pc_ref);

     IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

     ls_returncode :=
               cbs.pkg_soa_inquiry.getWsTaxInfo (json_txinfo.get ('TIN').get_string (),
                                                 pc_ref);

     IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

    ls_returncode :=
               CORPINT2.pkg_autopayment.getExchangeRatesIB (ld_date,
                                                           3,
                                                           ls_fx_rates);
    IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

      ls_returncode := corpint2.pkg_limit.CheckLimit(pn_person_id, -- person id
                                               'CLEARING', -- tran cd
                                               ls_amount, -- amount
                                               ls_from_curr, -- currency code
                                                pc_ref);

     IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

    ls_returncode := CBS.PKG_INT.GETCUSTOMERFULLNAME(ls_customer_id,pc_refName);
    IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
     END IF;

    fetch pc_refName into ls_firstName,ls_secondName,ls_surName;

    ls_returncode :=
               cbs.pkg_soa_transaction.makeTaxPayment (
                  json_txinfo.get ('TIN').get_string (),                     -- tin number
                  ls_firstName||' '||ls_secondName||' '||ls_surName,                   -- name surname
                  json_txinfo.get ('taxType').get_string (),                        -- type id
                  json_txinfo.get ('taxRegion').get_string (),                      -- region id
                  json_txinfo.get ('taxDistrict').get_string (),                    -- district id
                  json_txinfo.get ('taxSubDistrict').get_string (),                 -- subdistrict id
                  ls_amount,                         -- amount
                  json_txinfo.get ('description').get_string (),                 -- explanation id
                  ls_account_from,                    -- fom account
                  pn_person_id,                      -- person id
                  '',                                         -- vehicle plate
                  pc_ref);

            IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
            END IF;

    ls_returncode := corpint2.pkg_limit.UpdateLimit(pn_person_id, -- customer id
                                                                                'CLEARING', -- tran cd
                                                                                ls_amount, -- amount
                                                                                ls_from_curr, -- currency code
                                                                                pc_ref);
    IF ls_returncode <> '000'
            THEN
               RETURN ls_returncode;
    END IF;
return ls_returncode;
EXCEPTION
WHEN OTHERS
   THEN
    log_at ('PKG_AUTOPAYMENT.processTAXPayments', SQLERRM);
    raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ps_seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    RETURN '999';
END;

FUNCTION processSCHEDULED(pn_person_id VARCHAR2,
                              pc_ref      OUT CursorReferenceType) RETURN VARCHAR2
    IS
    ls_result   VARCHAR2 (3) := '000';
    CURSOR allATP
      IS
         SELECT seq_id
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE     person_id = pn_person_id
                AND PAYMENT_TYPE = 'SCHEDULED'
                AND TRUNC (NEXT_DATE_TIME) =
                       TRUNC (SYSDATE);

    res_atp           allATP%ROWTYPE;
    BEGIN

    FOR atp in allATP
    LOOP
      ls_result := PROCESSAUTOPAYMENT(atp.seq_id);
      log_at('PKG_AUTOPAYMENT.processSCHEDULED',atp.seq_id,ls_result);
      open pc_ref for select atp.seq_id,ls_result from dual;
    END LOOP;
    RETURN ls_result;

    EXCEPTION
    WHEN OTHERS
        THEN
        log_at ('PKG_AUTOPAYMENT.processSCHEDULED', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        --raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| atp.seq_id  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
        RETURN '999';
    END;

FUNCTION processTRIGGERED(pn_person_id VARCHAR2,
                              pc_ref      OUT CursorReferenceType) RETURN VARCHAR2
   IS

   ls_result   VARCHAR2 (3) := '000';
   ls_details    CLOB;
   ls_border    VARCHAR2(100);
   ls_currency  VARCHAR2(10);
   ls_account   NUMBER;
   CURSOR allATP
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE     person_id = pn_person_id
                AND PAYMENT_TYPE = 'TRIGGERED' and status='sENAB' and tran_cd in ('B2BTRANSF','B2OBTRANSF','EXCHNGSELL','EXCHNGBUY','ARBITRAGE');

    res_atp           allATP%ROWTYPE;

   BEGIN

   FOR atp in allATP

    LOOP

     ls_details :=atp.PAYMENT_DETAILS;
     ls_border := SUBSTR(ls_details, INSTR(ls_details, '"border":') + 9,INSTR(ls_details, '"borderInStr"')-INSTR(ls_details, '"border":')-10);
     ls_currency := SUBSTR(ls_details, INSTR(ls_details, '"toCurrency":') + 14,INSTR(ls_details, '"availableBalance":') - INSTR(ls_details, '"toCurrency":')-16);
     IF(ATP.ACCOUNT_TO >=16) THEN
      ls_account :=PKG_HESAP.GETHESAPNOFROMEXTERNAL(ATP.ACCOUNT_TO,ls_currency);
     ELSE
      ls_account := ATP.ACCOUNT_TO;
     END IF;
     IF (Pkg_Hesap.Kullanilabilir_Bakiye_Al(ls_account) < TO_NUMBER(ls_border,'99999999999.9999999999999')) THEN
        DBMS_OUTPUT.PUT_LINE('LESS');
        --ls_result := PROCESSAUTOPAYMENT(atp.seq_id);
        open pc_ref for select atp.seq_id,ls_result from dual;
     END IF;

    END LOOP;
    RETURN ls_result;

   EXCEPTION
   WHEN OTHERS
        THEN
        log_at ('PKG_AUTOPAYMENT.processTRIGGERED', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';
   END;

   PROCEDURE notifyPerson (pn_musteri_no    IN VARCHAR2,
                           pn_notify_type      VARCHAR2)
   IS
      ls_result         VARCHAR2 (3) := '000';

      CURSOR cur_person_info
      IS
         SELECT *
           FROM cbs.cbs_musteri_adres
          WHERE musteri_no = pn_musteri_no;

      res_person_info   cur_person_info%ROWTYPE;
   BEGIN
      OPEN cur_person_info;

      FETCH cur_person_info INTO res_person_info;

      IF (cur_person_info%FOUND)
      THEN
         IF (LOWER (pn_notify_type) = 'email')
         THEN
            ls_result := 'EML';                         --TODO notify by email
         ELSIF (LOWER (pn_notify_type) = 'phone')
         THEN
            ls_result := 'PHN';
         ELSE
            ls_result := '999';
         END IF;
      ELSE
         RAISE NO_DATA_FOUND;
      END IF;

      log_at ('PKG_AUTOPAYMENT.notifyPerson', 'Person_notifyed');

      CLOSE cur_person_info;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RAISE_APPLICATION_ERROR (-20100, SQLERRM);
      WHEN OTHERS
      THEN
         RAISE_APPLICATION_ERROR (-20100, SQLERRM);
   END;

   /******************************************************************************
      Name       : FUNCTION createAutopayment
      Created By : Guzal Zainulina 15.01.2018
      Purpose      : check account BALANCE
   ******************************************************************************/

   FUNCTION checkBalance (pn_account_no IN VARCHAR2, pn_sum_repl IN VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_return   VARCHAR2 (3) := '000';

      CURSOR accounts
      IS
         SELECT *
           FROM CBS_vw_hesap_izleme
          WHERE hesap_no = pn_account_no;

      res_acnt    accounts%ROWTYPE;
   BEGIN
      log_at ('PKG_AUTOPAYMENT.checkBalance', pn_account_no, pn_sum_repl);

      OPEN accounts;

      FETCH accounts INTO res_acnt;

      IF accounts%FOUND
      THEN
         IF res_acnt.BAKIYE < pn_sum_repl
         THEN
            ls_return := '071';
            log_at ('PKG_AUTOPAYMENT.checkBalance',
                    pn_account_no,
                    'ERROR: NOT ENOUGH MONEY');
         END IF;
      ELSE
         ls_return := '072';
         RAISE NO_DATA_FOUND;
      END IF;

      -- open pc_ref for  select ls_return from dual;
      RETURN ls_return;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         log_at ('PKG_AUTOPAYMENT.checkBalance NO_DATA_FOUND', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RAISE_APPLICATION_ERROR (-20100, SQLERRM);
      WHEN OTHERS
      THEN
         log_at ('PKG_AUTOPAYMENT.checkBalance OTHERS', UTL_HTTP.GET_DETAILED_SQLERRM,sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RAISE_APPLICATION_ERROR (-20100, SQLERRM);
         RETURN ls_return;
   END;

   /******************************************************************************
     Name       : FUNCTION checkIfTime
     Created By : Guzal Zainulina 18.01.2018
     Purpose      : check if time has come for scheduled payment
  ******************************************************************************/
   FUNCTION checkIfTime (pn_person_id       VARCHAR2,
                         pc_ref         OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_result   VARCHAR2 (3) := '000';

   BEGIN
      OPEN pc_ref FOR
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE     person_id = pn_person_id
                AND PAYMENT_TYPE = 'SCHEDULED'
                AND TRUNC (NEXT_DATE_TIME) =
                       TRUNC (SYSDATE);

      RETURN ls_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '62'
            || pkg_hata.getdelimiter
            || TO_CHAR (SQLCODE)
            || ' '
            || SQLERRM
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
   END;




   FUNCTION getAutopayemntINFO (pn_seq_id       VARCHAR2,
                                pc_ref      OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_result   VARCHAR2 (3) := '000';
   BEGIN
      OPEN pc_ref FOR
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE seq_id = pn_seq_id;

      RETURN ls_result;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '62'
            || pkg_hata.getdelimiter
            || TO_CHAR (SQLCODE)
            || ' '
            || SQLERRM
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
   END;


     /******************************************************************************
      Name       : FUNCTION getExchangeRatesIB
      Created By : Adilet Kachkeev 10.12.2015
      Purpose      : get exchange rates for IB transactions
   ******************************************************************************/
   FUNCTION getExchangeRatesIB (pd_date     IN     DATE,
                                pn_option   IN     NUMBER,
                                ps_result      OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      pc_ref          cursorreferencetype;
      ls_returncode   VARCHAR2 (3) := '000';
      str1            VARCHAR2 (15);
      str2            VARCHAR2 (15);
      str3            VARCHAR2 (15);
      str4            VARCHAR2 (15);
      str5            VARCHAR2 (15);
      str6            VARCHAR2 (50);
      str7            VARCHAR2 (15);
      str_usd         VARCHAR2 (10);
      str_eur         VARCHAR2 (10);
      str_kzt         VARCHAR2 (10);
      str_rub         VARCHAR2 (10);
   BEGIN
      ls_returncode := cbs.pkg_int_currency.GetExchangeRates (pd_date, pc_ref);

      IF ls_returncode <> '000'
      THEN
         RETURN ls_returncode;
      END IF;

      LOOP
         FETCH pc_ref
            INTO str1,
                 str2,
                 str3,
                 str4,
                 str5,
                 str6,
                 str7;

         EXIT WHEN pc_ref%NOTFOUND;

         IF str1 = 'USD'
         THEN
            str_usd := str2;
         ELSIF str1 = 'EUR'
         THEN
            str_eur := str2;
         ELSIF str1 = 'KZT' AND pn_option = 3
         THEN
            str_kzt := str2;
         ELSIF str1 = 'RUB' AND pn_option = 4
         THEN
            str_rub := str2;
         END IF;
      END LOOP;

      CLOSE pc_ref;

      IF pn_option = 2
      THEN
         ps_result := str_usd || ';' || str_eur;
      ELSIF pn_option = 3
      THEN
         ps_result := str_usd || ';' || str_eur || ';' || str_kzt;
      ELSIF pn_option = 4
      THEN
         ps_result := str_usd || ';' || str_eur || ';' || str_rub;
      END IF;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('pkg_autopayment.getExchangeRatesIB',
                 pd_date || ' ' || pn_option,
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;

   /******************************************************************************
      Name       : FUNCTION getExchangeRatioIB
      Created By : Adilet Kachkeev 10.12.2015
      Purpose      : get exchange ratios for currencies
   ******************************************************************************/
   FUNCTION getExchangeRatioIB (pc_ref            IN     CursorReferenceType,
                                rate_type         IN     VARCHAR2,
                                ps_fc_amount         OUT VARCHAR2,
                                ps_total_amount      OUT VARCHAR2,
                                ps_rate              OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      str1            VARCHAR2 (15);
      str2            VARCHAR2 (15);
      str3            VARCHAR2 (15);
      str4            VARCHAR2 (15);
      str5            VARCHAR2 (15);
      str6            VARCHAR2 (50);
      str7            VARCHAR2 (15);
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      LOOP
         FETCH pc_ref
            INTO str1,
                 str2,
                 str3,
                 str4,
                 str5,
                 str6,
                 str7;

         EXIT WHEN pc_ref%NOTFOUND;
         ps_total_amount := str5;
         ps_fc_amount := str6;

         IF rate_type = 'A'
         THEN
            ps_rate := str4;
         ELSE
            ps_rate := str3;
         END IF;
      END LOOP;

      CLOSE pc_ref;

      log_at (
         'exchange_ratio',
            '0: '
         || str1
         || ' 1: '
         || str2
         || ' 2: '
         || str3
         || ' 3: '
         || str4
         || ' 4: '
         || str5
         || ' 5: '
         || str6
         || ' 6: '
         || str7);
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('pkg_autopayment.getExchangeRatioIB',
                 ps_total_amount || ' ' || ps_rate,
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;

   /******************************************************************************
      Name       : FUNCTION getExchangeParityIB
      Created By : Adilet Kachkeev 10.12.2015
      Purpose      : get exchange parity for currencies
   ******************************************************************************/
   FUNCTION getExchangeParityIB (pc_ref               IN     CursorReferenceType,
                                 pc_ref2              IN     CursorReferenceType,
                                 ps_amount_currency   IN     VARCHAR2,
                                 ps_parity               OUT VARCHAR2,
                                 ps_from_amount          OUT VARCHAR2,
                                 ps_to_amount            OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      str1            VARCHAR2 (100);
      str2            VARCHAR2 (100);
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      LOOP
         FETCH pc_ref INTO str1;

         EXIT WHEN pc_ref%NOTFOUND;
         ps_parity := str1;
      END LOOP;

      CLOSE pc_ref;

      LOOP
         FETCH pc_ref2 INTO str1, str2;

         EXIT WHEN pc_ref2%NOTFOUND;

         IF ps_amount_currency = 'LC'
         THEN
            ps_from_amount := str1;
            ps_to_amount := str2;
         ELSE
            ps_from_amount := str2;
            ps_to_amount := str1;
         END IF;
      END LOOP;

      CLOSE pc_ref2;
        log_at ('pkg_autopayment.getExchangeParityIB', 'ps_parity = '||ps_parity|| 'ps_from_amount = '||ps_from_amount,'ps_to_amount = '||ps_to_amount);
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('pkg_autopayment.getExchangeParityIB',
                 ps_parity || ' ' || ps_from_amount || ' ' || ps_to_amount,
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN '999';
   END;

   /******************************************************************************
      Name       : FUNCTION getCommissionIB
      Created By : Adilet Kachkeev 10.12.2015
      Purpose      : get commission amounts for IB transactions
   ******************************************************************************/
   FUNCTION getCommissionIB (ps_TranCd       IN     VARCHAR2,
                             pn_FromAccNo    IN     VARCHAR2,
                             pn_ToAccNo      IN     VARCHAR2,
                             pn_Amount       IN     VARCHAR2,
                             ps_CurrCd       IN     VARCHAR2,
                             ps_ChannelCd    IN     VARCHAR2,
                             ps_amountComm      OUT VARCHAR2,
                             ps_taxComm         OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
      pc_ref          cursorreferencetype;
      str1            VARCHAR2 (15);
      str2            VARCHAR2 (15);
      str3            VARCHAR2 (15);
      str4            VARCHAR2 (15);
      str5            VARCHAR2 (15);
      str6            VARCHAR2 (15);
      str7            VARCHAR2 (15);
      str8            VARCHAR2 (15);
      str9            VARCHAR2 (15);
   BEGIN
      IF ps_ChannelCd = 'cDKBRIB'
      THEN
         ls_returncode :=
            cbs.pkg_soa_inquiry.GetCommission (ps_TranCd,
                                               pn_FromAccNo,
                                               pn_ToAccNo,
                                               pn_Amount,
                                               ps_CurrCd,
                                               pc_ref);

         IF ls_returncode <> '000'
         THEN
            RETURN ls_returncode;
         END IF;

         LOOP
            FETCH pc_ref
               INTO str1,
                    str2,
                    str3,
                    str4,
                    str5,
                    str6,
                    str7,
                    str8,
                    str9;

            EXIT WHEN pc_ref%NOTFOUND;
            ps_amountComm := str1;
            ps_taxComm := str3;
         END LOOP;

         CLOSE pc_ref;
      ELSE
         ls_returncode :=
            cbs.pkg_int.GetCommission (ps_TranCd,
                                       pn_FromAccNo,
                                       pn_ToAccNo,
                                       pn_Amount,
                                       ps_CurrCd,
                                       pc_ref);

         IF ls_returncode <> '000'
         THEN
            RETURN ls_returncode;
         END IF;

         LOOP
            FETCH pc_ref INTO str1, str2, str3;

            EXIT WHEN pc_ref%NOTFOUND;
            ps_amountComm := str1;
            ps_taxComm := str3;
         END LOOP;

         CLOSE pc_ref;
      END IF;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'pkg_autopayment.getCommissionIB',
               ps_TranCd
            || ' '
            || pn_FromAccNo
            || ' '
            || pn_ToAccNo
            || ' '
            || pn_Amount
            || ' '
            || ps_CurrCd,
            SQLERRM,
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;

   /******************************************************************************
      Name       : FUNCTION getMaturityDate
      Created By : Adilet Kachkeev 10.12.2015
      Purpose      : get maturity date for clearing and swift
   ******************************************************************************/
   FUNCTION getMaturityDate (ps_tran_date       IN     VARCHAR2,
                             ps_tran_cd         IN     VARCHAR2,
                             ps_type            IN     VARCHAR2,
                             ps_maturity_date      OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
      ls_tran_date    VARCHAR2 (50);
      pc_ref          cursorreferencetype;
      str1            VARCHAR2 (50);
      str2            VARCHAR2 (50);
      str3            VARCHAR2 (50);
      str4            VARCHAR2 (50);
      str5            VARCHAR2 (50);
      str6            VARCHAR2 (50);
      clearing_str    VARCHAR2 (50);
      swift_str1      VARCHAR2 (50);
      swift_str2      VARCHAR2 (50);
   BEGIN
      IF TO_DATE (ps_tran_date, 'YYYYMMDD') <= TRUNC (SYSDATE)
      THEN
         ls_tran_date := TO_CHAR (TRUNC (SYSDATE), 'YYYYMMDD');
      ELSE
         ls_tran_date := ps_tran_date;
      END IF;

      ls_returncode :=
         cbs.pkg_soa_inquiry.GetEFTDate (ls_tran_date, ps_tran_cd, pc_ref);

      IF ls_returncode <> '000'
      THEN
         RETURN ls_returncode;
      END IF;

      LOOP
         FETCH pc_ref
            INTO str1,
                 str2,
                 str3,
                 str4,
                 str5;

         EXIT WHEN pc_ref%NOTFOUND;
         clearing_str := str1;
         swift_str1 := str3;
         swift_str2 := str4;
      END LOOP;

      CLOSE pc_ref;

      log_at ('autopayment_maturity',
              clearing_str || ' ' || swift_str1,
              ps_type || ' ' || swift_str2);

      IF ps_type = 'NORMAL'
      THEN
         ps_maturity_date := swift_str1;
      ELSIF ps_type = 'URGENT'
      THEN
         ps_maturity_date := swift_str2;
      ELSE
         ps_maturity_date := clearing_str;
      END IF;

      log_at ('autopayment_maturity',
              ps_tran_date || ' ' || ps_tran_cd,
              ps_type || ' ' || ps_maturity_date);
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         log_at ('pkg_autopayment.getMaturityDate',
                 ps_tran_date || ' ' || ps_tran_cd || ' ' || ps_type,
                 SQLERRM,
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;


   /******************************************************************************
      Name       : FUNCTION createAutopayment
      Created By : Guzal Zainulina 15.01.2018
      Purpose      : check if autopayment already exists
   ******************************************************************************/
   FUNCTION checkIfATPExist (personID          IN VARCHAR2,
                             pn_payment_name   IN VARCHAR2,
                             pn_account_to     IN VARCHAR2)
      RETURN VARCHAR2
   IS
      ls_returncode     VARCHAR2 (3) := '000';
      noCustomerFound   EXCEPTION;

      CURSOR allATP
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE PERSON_ID = personID and STATUS = 'sENAB';

      CURSOR accountATP
      IS
         SELECT *
           FROM CORPINT2.TBL_AUTOPAYMENT
          WHERE ACCOUNT_TO = pn_account_to and STATUS = 'sENAB';

      res_pmnt          allATP%ROWTYPE;
      res_atp           accountATP%ROWTYPE;
   BEGIN
      OPEN allATP;

      OPEN accountATP;

      FETCH accountATP INTO res_atp;
        log_at ('pkg_autopayment.checkIfATPExist',pn_account_to);
      IF accountATP%FOUND
      THEN
         RETURN '004';
      ELSE
         LOOP
            FETCH allATP INTO res_pmnt;

            EXIT WHEN allATP%NOTFOUND;

            IF (    res_pmnt.PAYMENT_NAME = pn_payment_name
                AND res_pmnt.ACCOUNT_TO = pn_account_to)
            THEN
               RETURN '001';
            ELSIF (res_pmnt.PAYMENT_NAME = pn_payment_name)
            THEN
               RETURN '002';
            ELSIF (res_pmnt.ACCOUNT_TO = pn_account_to)
            THEN
               RETURN '003';
            END IF;
         END LOOP;
      END IF;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '999';
         RETURN ls_returncode;
   END;

FUNCTION deleteByID(pn_seq_id varchar2, pc_ref out CursorReferenceType) return varchar2
IS
ls_returncode     VARCHAR2 (3) := '000';
BEGIN

UPDATE CORPINT2.TBL_AUTOPAYMENT set status = 'sDELETE' WHERE seq_id = pn_seq_id;

return ls_returncode;

EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '999';
         RETURN ls_returncode;
END;

END;
/

