create trigger TRG_IDENTIFICATION_BEF_INS
    before insert
    on TBL_IDENTIFICATION_TX
    for each row
declare
    p_seq_num number;
  begin
      select corpint2.seq_txidno.nextval into p_seq_num from dual;
      :new.tx_no:=p_seq_num;
  end;

/

