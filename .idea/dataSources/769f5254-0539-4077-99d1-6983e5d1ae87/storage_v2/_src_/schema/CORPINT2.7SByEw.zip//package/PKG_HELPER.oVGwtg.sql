create PACKAGE                   PKG_HELPER IS
TYPE CursorReferenceType IS REF CURSOR;
-------------------------------------------------------------------
FUNCTION getNumberFromVarchar2(ps_number IN VARCHAR2, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN NUMBER;
-------------------------------------------------------------------
FUNCTION getVarchar2FromNumber(ps_number IN NUMBER, ps_numeric_chars VARCHAR2 DEFAULT '.,') RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION getCustomerNoFromPerson(pn_personid IN NUMBER) RETURN NUMBER;
-------------------------------------------------------------------
FUNCTION getFullNameFromPerson(pn_personid IN NUMBER) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION getBankDatePlusTime RETURN DATE;
-------------------------------------------------------------------
FUNCTION getConfigValueFromKey(ps_key IN VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
FUNCTION getAuthorizedUsers(pn_customer_no IN VARCHAR2,
                            pc_ref      OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Set Security Info
******************************************************************************/
FUNCTION SetSecurityInfo(pn_PersonId   IN VARCHAR2,
                         ps_SecurityInfo  IN CLOB) RETURN VARCHAR2;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Get Security Info
******************************************************************************/
FUNCTION GetSecurityInfo(pn_PersonId IN VARCHAR2,
                         pc_ref      OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 09.03.2016
   Purpose    : Get Security Info
******************************************************************************/
FUNCTION GetJSONValue(ps_source IN VARCHAR2, ps_key IN VARCHAR2) RETURN VARCHAR2;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Aibek Osmonov
   Date       : 28.07.2016
   Purpose    : Get QRCode 
******************************************************************************/
FUNCTION getQRCode(pn_qr_value IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------
/******************************************************************************
   Created By : Aibek Osmonov
   Date       : 28.07.2016
   Purpose    : Add QRCode 
******************************************************************************/
FUNCTION setQRCode(pn_qr_value IN VARCHAR2, pn_personid IN NUMBER, pn_qr_data IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-------------------------------------------------------------------

/******************************************************************************
   Created By : ErkinZununbekov
   Date       : 12.03.2017
   Purpose    : get list of user authorities
******************************************************************************/
FUNCTION getUserAuthorities(pn_personId IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

END PKG_HELPER;
/

