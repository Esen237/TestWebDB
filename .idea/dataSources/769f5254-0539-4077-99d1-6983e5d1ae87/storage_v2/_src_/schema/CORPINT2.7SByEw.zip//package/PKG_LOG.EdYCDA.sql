create PACKAGE          Pkg_Log IS

TYPE CursorReferenceType IS REF CURSOR;

PROCEDURE AddLog(pid1 clob,
                 pid2 clob DEFAULT NULL,
                 pid3 clob DEFAULT NULL,
                 pid4 clob DEFAULT NULL);

END Pkg_Log;
/

