create PACKAGE          Pkg_Auth IS

TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 15.09.2015
   Purpose    : validate user against IBSecurity parameters
******************************************************************************/
FUNCTION CheckIBSecurity(pn_personid IN NUMBER, pn_ClientIP IN VARCHAR2)
RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 11.11.2015
   Purpose    : check submitted OTP number
******************************************************************************/
FUNCTION CheckOTP(pn_personid IN NUMBER, ps_otp_pwd IN VARCHAR2)
RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 12.11.2015
   Purpose    : check if user has etoken
******************************************************************************/
FUNCTION CheckEToken(ps_username IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 12.11.2015
   Purpose    : Get Token Data
******************************************************************************/
FUNCTION GetTokenData(ps_username IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   Created By : Aisuluu Kasymova
   Date       : 12.11.2015
   Purpose    : Set Token Data
******************************************************************************/
FUNCTION SetTokenData(ps_digipass IN VARCHAR2, ps_digidata IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 04.03.2016
   Purpose    : Set UserAlias
******************************************************************************/
FUNCTION SetUserAlias(ps_person_id IN VARCHAR2, ps_username IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 04.03.2016
   Purpose    : Set Password
******************************************************************************/
FUNCTION SetPassword(ps_person_id IN VARCHAR2, ps_password_old IN VARCHAR2, ps_password IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Created By : Almas Nurkhozhayev
   Date       : 04.03.2016
   Purpose    : Set Pin
******************************************************************************/
FUNCTION SetPin(ps_person_id IN VARCHAR2, ps_pin_old IN VARCHAR2, ps_pin IN VARCHAR2) RETURN VARCHAR2;

END Pkg_Auth;
/

