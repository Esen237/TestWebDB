create FUNCTION         numeric_merge_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
150 eb
1sjgH+KmM2dD/q7xrHW3VxIzS3Mwg8eZgcfLCNL+XoXV1y5il1lKW/EpJgit9KEmratxntsd
LIBJ6iyERK4kRJ1pD0mxyqTxKv33JjGxKoVVKhnXJIWxfzaRonULyAMHC8j3G+rI9loRL0dZ
RHJw0Unqv64kDjFpvSxJgMGPhXDtcMbOUC8sAOM1cMQRZzSMHTJYyxhs7Dxx4j/RygtM1nqQ
hvegk4KmppF0WhU=
/

