create view ALL_SA_USER_PRIVS as
SELECT user_name,
         policy_name,
         user_privileges
    FROM LBACSYS.all_sa_users
   WHERE user_privileges IS NOT NULL
/

