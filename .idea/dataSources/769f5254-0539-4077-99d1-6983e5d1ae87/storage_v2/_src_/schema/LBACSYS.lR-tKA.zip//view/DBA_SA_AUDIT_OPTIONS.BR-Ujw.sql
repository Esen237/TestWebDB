create view DBA_SA_AUDIT_OPTIONS as
SELECT a.policy_name, a.user_name, APY, REM, SET_, PRV
  FROM LBACSYS.dba_lbac_policies p, LBACSYS.dba_ols_audit_options a
  WHERE p.policy_name = a.policy_name AND
        p.package = 'LBAC$SA'
/

