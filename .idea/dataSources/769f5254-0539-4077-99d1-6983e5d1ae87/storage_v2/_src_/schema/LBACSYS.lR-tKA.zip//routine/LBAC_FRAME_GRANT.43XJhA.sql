create PROCEDURE         lbac_frame_grant wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
418 144
E0h61aZlNQiArN6CuLGdWcB/FEAwgzvxcp6sZy/U2viOx048mTCjMvECd6Uod96TMgoCLgu/
mSP428ovRRqZx+w4P8+az8cWm+eGRWdpsiAxk04TcB/XEpmg0uZZEYtCpgvu84xF5g7eGH9s
lEoApbeskT2/pxdLKKHDQZfNRl40857ldssyU7D3LNjufGzwMqaY9johgv9m1p9w4npKTflS
tqNFvLTnSGRxZIbXGnOi0doZu1m1Fy5CRS17hUr0QXjy9ctlfJbrKnaKfA2TdvFDFjhfdiNb
URyf+YccyQiAmuLKPsLe2rQ0++6hyvg=
/

