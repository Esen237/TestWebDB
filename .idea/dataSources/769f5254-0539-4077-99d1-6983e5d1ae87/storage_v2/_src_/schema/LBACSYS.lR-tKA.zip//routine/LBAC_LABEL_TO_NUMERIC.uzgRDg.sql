create FUNCTION         lbac_label_to_numeric wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
a7 c2
aTkbke4lwCjOVS1iHwZUwZLDt9swg8eZgcfLCNL+XoWh8llKcqFZ8tf0lvrQctXXLmKXWStQ
jwnd4c92kHEQjnpzjs9udpDW79aBZ/V6VMO31YUqFCGFrq+Wd7H6KlqvgnXZ+j1V6ygRy8Ph
ayuW2yQi27NMHVGz7Nk9ckSh3xwWmSHbKoXrMez7pg5i1Y8=
/

