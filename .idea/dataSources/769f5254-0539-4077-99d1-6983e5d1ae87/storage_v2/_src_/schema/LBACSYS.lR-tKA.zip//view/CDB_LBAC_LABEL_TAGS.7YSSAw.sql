create view CDB_LBAC_LABEL_TAGS as
SELECT k."POLICY_NAME",k."LABELVALUE",k."LABELTAG",k."LABELTYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_LBAC_LABEL_TAGS") k
/

comment on table CDB_LBAC_LABEL_TAGS is ' in all containers'
/

comment on column CDB_LBAC_LABEL_TAGS.CON_ID is 'container id'
/

