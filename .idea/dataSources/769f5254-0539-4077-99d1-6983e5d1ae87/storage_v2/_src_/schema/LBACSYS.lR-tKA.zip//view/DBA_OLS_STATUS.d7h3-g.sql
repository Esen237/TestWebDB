create view DBA_OLS_STATUS as
SELECT DECODE(name, 'OLS_STATUS_FLAG', 'OLS_ENABLE_STATUS',
                      'OLS_CONFIGURED_FLAG','OLS_CONFIGURE_STATUS',
                      'OID_STATUS_FLAG','OLS_DIRECTORY_STATUS') AS name,
         DECODE(value$, '0', 'FALSE','TRUE') AS status,
         comment$ AS description
  FROM LBACSYS.ols$props
  WHERE name IN ('OLS_STATUS_FLAG', 'OLS_CONFIGURED_FLAG', 'OID_STATUS_FLAG')
  ORDER BY name
/

