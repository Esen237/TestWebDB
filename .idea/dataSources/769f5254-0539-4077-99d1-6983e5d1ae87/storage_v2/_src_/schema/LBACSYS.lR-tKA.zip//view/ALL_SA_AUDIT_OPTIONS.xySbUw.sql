create view ALL_SA_AUDIT_OPTIONS as
SELECT a.policy_name, a.user_name, APY, REM, SET_, PRV
    FROM LBACSYS.sa$pol p, LBACSYS.dba_ols_audit_options a
   WHERE p.pol_name = a.policy_name
     AND p.pol# in (select pol# from LBACSYS.sa$admin
                    where usr_name = SYS_CONTEXT('USERENV', 'CURRENT_USER'))
/

