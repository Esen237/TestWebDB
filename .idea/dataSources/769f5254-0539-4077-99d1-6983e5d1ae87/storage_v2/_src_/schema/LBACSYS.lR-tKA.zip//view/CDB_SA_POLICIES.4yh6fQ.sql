create view CDB_SA_POLICIES as
SELECT k."POLICY_NAME",k."COLUMN_NAME",k."STATUS",k."POLICY_OPTIONS",k."POLICY_SUBSCRIBED",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_POLICIES") k
/

comment on table CDB_SA_POLICIES is ' in all containers'
/

comment on column CDB_SA_POLICIES.CON_ID is 'container id'
/

