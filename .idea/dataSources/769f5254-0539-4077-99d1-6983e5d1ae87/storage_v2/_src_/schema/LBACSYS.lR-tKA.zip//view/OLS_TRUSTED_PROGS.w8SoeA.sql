create view OLS$TRUSTED_PROGS as
SELECT l.pol#, l.owner, l.pgm_name, l.privs,
         po.pol_name, po.package
  FROM LBACSYS.ols$prog l, LBACSYS.ols$pol po
  where l.pol#=po.pol#
/

