create FUNCTION         numeric_label_to_char wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
160 134
SqIVxAixuX2QDr7YLDCP2etEh+IwgwJK1xjhfy9G/nqus+NbRAjKGXqB2wQdLYB7AJgePk3n
nsyvT22uINSIL/MtIEwPzFy38Ym0rI+4VSDcmDLj2T0bQNl/2MTZXjlPZB3Lx82sDvsMfL8i
VNN5Ib+CPAllr5bC7GYoZR63WFn0YNbl5r0Xq6PEBF5VQ3a6jYt+/4WZuK3FnaVzFTqf5eeh
nBi1k1isxQnGtYZP77COs4prXih5cGT5QU7PIort2KS6Agm44dbUaFY/aHi5IVghY/IQB4e0
8SaBuX3By71xw1c=
/

