create PACKAGE mds_internal_shredded 

-- ###### Use AUTHID CURRENT_USER to execute with
-- the privileges of current user, not the owner.
AUTHID CURRENT_USER
AS

  -- This is used to verify that the repository API and MDS java code are
  -- compatible.  REPOS_VERSION should be updated every time repository schema/ 
  -- stored procedures are modified to current version of MDS.
  --
  -- In addition, if MDS java code is not compatible with older repository,
  -- OracleDB.MIN_SHREDDED_REPOS_VERSION should be changed to this value.
  REPOS_VERSION    CONSTANT VARCHAR2(32) := '12.2.1.3.0_20170321';

  ------------------------------------------------------------------------------
  ---------------------------- PUBLIC PROCEDURES -------------------------------
  ------------------------------------------------------------------------------
  --
  -- Deletes the tenant in the given partition. If there are any documents
  -- associated with the tenant in the given partition, this method will delete 
  -- all those documents. 
  -- This procedure is now no-op as multitenancy is only supported using PDB.
  --
  -- Parameters:
  --   partitionId - Partition Id.
  --   tenantId - Enterprise Id.
  --
  PROCEDURE deprovisionTenant(partitionID MDS_PATHS.PATH_PARTITION_ID%TYPE,
                              tenantID MDS_PATHS.ENTERPRISE_ID%TYPE);

  --
  -- Deletes the given partition. If there are any documents in the given
  -- partition, this method will delete all those documents.
  --
  -- Parameters:
  --   partitionName - Name of the partition.
  --
  PROCEDURE deletePartition(partitionName VARCHAR2);


  --
  -- Export the XML for tip version of a document and pass it back in
  -- 32k chunks.  This function will return XML chunks, with a
  -- maximum size of 32k.
  --
  -- Specifying a document name will initiate the export.  Thereafter, a NULL
  -- document name should be passed in until the export is complete.
  -- That is, to export an entire document, you should do:
  --
  -- firstChunk := mds_internal.exportDocumentByName(chunk,
  --                                                 exportFinished,
  --                                                 partitionID,
  --                                                 '/oracle/apps/fnd/mydoc',
  --                                                 formatted);
  -- WHILE (isDone = 0)
  --   nextChunk := mds_internal.exportDocumentByName(chunk, NULL, NULL, 
  --                                                         NULL, NULL);
  -- END LOOP;
  --
  -- Parameters:
  --   chunk          - OUT The exported XML, in 32 chunks.
  --   exportFinished - OUT parameter which indicates whether or not the export
  --                    is complete.  1 indicates the entire document is
  --                    exported, 0 indicates that there are more chunks
  --                    remaining.
  --
  --   partitionID  - the partition where the document exists.
  --   fullName  - the fully qualifued name of the document.  however,
  --               after the first chunk of text is exported, a NULL value
  --               should be passed in.
  --
  --
  --   formatted - a non-zero value indicates that the XML is formatted nicely
  --               (i.e. whether or not the elements are indented)
  --
  PROCEDURE exportDocumentByName(
    chunk          OUT VARCHAR2,
    exportFinished OUT INTEGER,
    partitionID        NUMBER,
    fullName           VARCHAR2,
    formatted          INTEGER DEFAULT 1);


  -- Retained for backward compatibility.
  -- Latest mid-tier code is supposed to use readDocument() instead.
  -- See comments for readDocument for more information.
  --
  -- Specifying a document ID will initiate the export.  Thereafter, a NULL
  -- document ID should be passed in until the export is complete.
  --
  -- Parameters:
  --   chunk          - OUT The exported XML, in 32 chunks.
  --   exportFinished - OUT parameter which indicates whether or not the export
  --                    is complete.  1 indicates the entire document is
  --                    exported, 0 indicates that there are more chunks
  --                    remaining.
  --
  --   docID          - PATH_DOCID of the document, obtained using 
  --                    getDocumentID(), however after the first chunk of text 
  --                    is exported, a NULL value should be passed in.
  --
  --   partitionID    - the partition where the document exists.
  --   isFormatted    - a non-zero value indicates that the XML is formatted
  --                    nicely (i.e. whether or not the elements are indented)
  --
  PROCEDURE exportDocumentByID(
    chunk          OUT VARCHAR2,
    exportFinished OUT INTEGER,
    partitionID        MDS_PATHS.PATH_PARTITION_ID%TYPE,
    docID              MDS_PATHS.PATH_DOCID%TYPE,
    contentID          MDS_PATHS.PATH_CONTENTID%TYPE,
    versionNum         MDS_PATHS.PATH_VERSION%TYPE,
    isFormatted        INTEGER DEFAULT 1);


  --
  -- Retrieve XML content for shredded document and pass it back in 32k chunks.
  -- This function will return XML chunks, with a maximum size of 32k.
  --
  -- Specifying a document ID will initiate the export.  Thereafter, a NULL
  -- document ID should be passed in until the export is complete.
  --
  -- Parameters:
  --   chunk          - OUT The exported XML, in 32 chunks.
  --   exportFinished - OUT parameter which indicates whether or not the export
  --                    is complete.  1 indicates the entire document is
  --                    exported, 0 indicates that there are more chunks
  --                    remaining.
  --
  --   docID          - PATH_DOCID of the document, obtained using getDocumentID(),
  --                    however after the first chunk of text is exported,
  --                    a NULL value should be passed in.
  --
  --   partitionID    - the partition where the document exists.
  --   isFormatted    - a non-zero value indicates that the XML is formatted
  --                    nicely (i.e. whether or not the elements are indented)
  --
  --   xmlHeaderParamsPresent - used to indicate the availability of XML header
  --                    parameters. Pass 1 if values are provided, 0 otherwise.
  --                    We can avoid an extra query to DB, if the header params
  --                    are provided. 
  --   xmlVersion     - the xmlVersion value used to construct XML header.
  --   xmlEncoding    - the xmlEncoding value used to construct XML header.
  --   pathGuid       - GUID of the document.
  --
  PROCEDURE readDocument(
    chunk          OUT VARCHAR2,
    exportFinished OUT INTEGER,
    partitionID        MDS_PATHS.PATH_PARTITION_ID%TYPE,
    docID              MDS_PATHS.PATH_DOCID%TYPE,
    contentID          MDS_PATHS.PATH_CONTENTID%TYPE,
    versionNum         MDS_PATHS.PATH_VERSION%TYPE,
    isFormatted            INTEGER DEFAULT 1,
    xmlHeaderParamsPresent INTEGER DEFAULT 0,
    xmlVersion         MDS_PATHS.PATH_XML_VERSION%TYPE  DEFAULT NULL,
    xmlEncoding        MDS_PATHS.PATH_XML_ENCODING%TYPE DEFAULT NULL,
    pathGuid           MDS_PATHS.PATH_GUID%TYPE         DEFAULT NULL);

  --
  -- Retrieves the namespace id for the specified uri.  If the namespace
  -- does not already exist, it will be created.  No validation occurs on the
  -- uri.
  --
  -- Parameters:
  --   namespaceID   - Returns the ID for the uri
  --   partitionID   - Partition Id
  --   uri           - uri
  --

  PROCEDURE getNamespaceID(namespaceID OUT mds_namespaces.ns_id%TYPE,
                           partitionID     mds_namespaces.ns_partition_id%TYPE,
                           uri             mds_namespaces.ns_uri%TYPE);

  --
  -- Gets the minimun version of MDS with which the repository is
  -- compatible.  That is, the actual MDS version must be >= to the
  -- minimum version of MDS in order for the repositroy and java code to
  -- be compatible.
  --
  -- Returns:
  --   Returns the mimumum version of MDS
  --
  FUNCTION getMinMDSVersion RETURN VARCHAR2;

  --
  -- Gets the features supported by the repository.
  --
  -- Returns:
  --   Returns a BIGINT of bits representing the supported features.
  --
  FUNCTION getRepositoryFeatures RETURN NUMBER;
  
  --
  -- Gets the version of the repository API.  This API version must >= to the
  -- java constant CompatibleVersions.MIN_REPOS_VERSION.
  --
  -- Returns:
  --   Returns the version of the repository
  --
  FUNCTION getRepositoryVersion RETURN VARCHAR2;

  --
  -- Gets the version and encoding of the repository API. 
  -- 
  -- Returns:
  --   Returns the version and encoding of the repository
  --
  PROCEDURE getReposVersionAndEncoding(reposVersion   OUT VARCHAR2,
                                       dbEncoding     OUT VARCHAR2);

  --
  -- Purges document versions from the repository.
  -- Only those document versions which were created older than secondsToLive,
  -- which are not labeled and are not the tip versions are purged.
  -- 
  -- For all such purgeable versions, this method purges corresponding 
  -- content from base and content tables like mds_paths,
  -- mds_attributes, mds_components, mds_dependencies, mds_streamed_docs etc.
  --
  -- Parameters  
  --  numVersionsPurged - Out parameter indicating number of versions purged
  --  partitionID       - PartitionID for the repository partition
  --  purgeCompareTime  - Creation time prior to which versions can be purged
  --  isAutoPurge       - 0 if manual purge and 1 if auto-purge
  --  commitNumber      - Commit number used for purging path and content tables
  --
  PROCEDURE purgeMetadata(numVersionsPurged  OUT NUMBER,
                          partitionID        NUMBER,
                          purgeCompareTime   TIMESTAMP,
                          secondsToLive      NUMBER,
                          isAutoPurge        NUMBER,      
                          commitNumber       OUT NUMBER);  

  -- Used in the queryapi. The attr_value column contains both strings and
  -- number values in a varchar2. In the query api we need to be able to
  -- complete number and string comparisions against the values in the column.
  -- However if we use to_number() on the column the string values are going to
  -- fall over in a big heap and give the  ORA-01722: invalid number exception.
  -- This function allows us to handle this scenario more gracefully.
  --
  -- Returns:
  --   Returns null if the attr_value is a string else returns the number value.
  --
  FUNCTION toNumber(attribute_value VARCHAR2) RETURN NUMBER;

  -- Functions used in the queryapi to compare with a CLOB column such as
  -- ATTR_LONG_VALUE. Used to avoid ORA-00932 errors.
  -- Not required in SQLServer.
  -- Does the indicated comparison on its operands and returns 1 if true,
  -- 0 if false.
  -- ######: comparisons of CLOB to VARCHAR2 can fail to work as
  -- expected: if the DB charset is multibyte, CLOB will be UCS-2, not
  -- DB charset(!).
  FUNCTION clobEQ(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
  FUNCTION clobLT(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
  FUNCTION clobGT(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
  FUNCTION clobNE(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
  FUNCTION clobLE(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
  FUNCTION clobGE(clobVal       CLOB,
                  val2          CLOB) RETURN NUMBER;
END;
/

