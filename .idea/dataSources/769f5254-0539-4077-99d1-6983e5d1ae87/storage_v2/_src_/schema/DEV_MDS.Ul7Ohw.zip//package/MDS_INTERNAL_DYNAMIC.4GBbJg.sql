create PACKAGE                 mds_internal_dynamic 


AS

  -----------------------------------------------------------------------------
  ---------------------------- PRIVATE VARIABLES ------------------------------
  -----------------------------------------------------------------------------

  --
  -- Get next value from mds_content_id sequence for the specified partition.
  --
  -- Parameters:
  --   partitionID  -  Partition ID.
  --   contentID    - Out parameter, content ID for the inserted path.

  PROCEDURE getNextContentId( partitionID NUMBER,
                              contentID  OUT  MDS_PATHS.PATH_CONTENTID%TYPE);
 

  --
  -- Get next value from mds_doc_id sequence for the specified partition.
  --
  -- Parameters:
  --   partitionID  -  Partition ID.
  --   documentID    - Out parameter, Document ID of the document being saved.

  PROCEDURE getNextDocId( partitionID NUMBER, documentID  OUT NUMBER);


  --
  -- Get next value from mds_lineage_id sequence for the specified partition.
  --
  -- Parameters:
  --   partitionID  -  Partition ID.
  --   lineageID    -  Out parameter
  PROCEDURE getNextLineageId( partitionID NUMBER, lineageID   OUT NUMBER);


  --
  --
  -- Creates Document, Content and Lineage ID sequences for the partition 
  --
  -- Parameters:
  --   partitionID  -  Partition ID.
  --
  PROCEDURE createSequences(partitionID   MDS_PATHS.PATH_PARTITION_ID%TYPE);


  --
  -- Delete sequences for the partition.
  --
  -- Parameters:
  --   partitionID    -  Partition Id.
  --
  PROCEDURE deleteSequences(partitionID MDS_PATHS.PATH_PARTITION_ID%TYPE);


  --
  -- Recreates Document, Content and Lineage ID sequences with the minimum
  -- documentID, contentID and lineageID set to the values provided as input
  -- parameters.
  --
  -- Parameters:
  --   partitionID  -  Partition ID.
  --   minDocId     -  Minimum Document ID
  --   minContentId -  Minimum Content ID
  --   minLineageId -  Minimum Lineage ID
  --
  PROCEDURE recreateSequences(partitionID   MDS_PATHS.PATH_PARTITION_ID%TYPE,
                              minDocId      NUMBER,
                              minContentId  NUMBER,
                              minLineageId  NUMBER DEFAULT NULL);

END;

/

