create PACKAGE MDS_UTILS AS

  -- This is used by data migration utility(DMU) to transform partition id
  -- during MDS schema export. During export, PartitionId column value in 
  -- every row of all MDS tables in the source schema is passed as param to
  -- this function by DataPump export tool and returned value will replace 
  -- the original value in the exported dump file.
  --
  -- -- Parameters:
  --  partitionId - Partition ID in the source schema being exported.
  --
  function remapPartitionId(partitionId IN NUMBER) return NUMBER;
 
  -- This is used by data migration utility(DMU) to transform partition name
  -- during MDS schema export. During export, PARTITION_NAME column value in 
  -- every row of MDS_PARTITIONS table in the source schema is passed as 
  -- param to this function by DataPump export tool and returned value will 
  -- replace the original value in the exported dump file.
  --
  -- -- Parameters:
  --  partitionName - Partition name in the source schema being exported.
  --
  function remapPartitionName(partitionName IN VARCHAR2) return VARCHAR2;
  

END;

/

