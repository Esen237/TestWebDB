create view WORKFLOWINSTANCEEXPIREDTASKVIEW as
select distinct wi.Id as WORKFLOWINSTANCEID from WORKFLOWINSTANCE wi 
                join WORKFLOWINSTANCETASK wit on wi.LASTEXECUTEDTASKID=wit.Id
                join WORKFLOWTASKDEFINITION wtd on wtd.Id=wit.TASKDEFINITIONID 
                where wi.STATUS=10 and wi.CREATEDAT> sysdate-120 and wit.STATUS=10  and wit.LASTEXECUTIONDATE<= (sysdate- wtd.EXPIRETIMEINSECONDS/24/60/60)
/

