create trigger EXECUTIONINSTANCEDATA_TRG
    before insert
    on EXECUTIONINSTANCEDATA
    for each row
BEGIN
                   SELECT EXECUTIONINSTANCEDATA_SEQ.nextval INTO :new.jobexecid FROM dual;
                 END;
/

