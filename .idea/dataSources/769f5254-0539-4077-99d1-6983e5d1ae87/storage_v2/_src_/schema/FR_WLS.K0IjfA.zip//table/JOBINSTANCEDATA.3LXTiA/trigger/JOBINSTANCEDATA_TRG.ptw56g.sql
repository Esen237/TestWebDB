create trigger JOBINSTANCEDATA_TRG
    before insert
    on JOBINSTANCEDATA
    for each row
BEGIN
                   SELECT JOBINSTANCEDATA_SEQ.nextval INTO :new.jobinstanceid FROM dual;
                 END;
/

