create TYPE SI_Color
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
    (
      ---SI_Color Type attributes
     redValue   INTEGER,
     greenValue INTEGER,
     blueValue  INTEGER,
     --
     MEMBER PROCEDURE SI_RGBColor
     (SELF       IN OUT NOCOPY SI_Color,
      redValue   IN INTEGER,
      greenValue IN INTEGER,
      blueValue  IN INTEGER)
) INSTANTIABLE
NOT FINAL;
/

