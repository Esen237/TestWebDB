create PACKAGE BODY         ORDError wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
2f2 1a1
vuBqm12n2ebQRk4L2IYDbDeVddIwg5D3f/ZqfC8C2vjqEXzbN3ARg9HXFLofwU1i9Os+d7fn
a14HrCm1sPG3UCEuHeI1ezrOQRwjFwFzZv0vjcztfBpwBCJAWUVWtuYaAfp3Dno3yvTLGHfa
+HuxEZqQ+WnQY+ZiJihNiKsOlSD0BRkPWmHx/PAaQ1wwrUQ/deEk3DdP+amVerN9JYc11pLK
HE7yWEUZjSYErird9rKns313tzKZa05iC1ueAWmPNA1ABHfFTOF7PE9eS44LMnbG1MzL6pDH
cW160KcfS4VCHYBgXJCZ1AOBcdSUo3dpR9QImf6+BZ0kcosK/X200l9iwA/isjLxHS+InowP
f50mIqtcs4ClSwWdcwU7ewC5BX/QLaTcg8TNk8jenfjhErDYtQ==
/

