create FUNCTION
  SI_ScoreByClrHstgr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
138 11f
8bqJGqtDQp2t0Qu/g0pi7/6mPdAwg3ncf8sVfHSRudV6Cb0IN9x5/N+nJTYx/913+6hvFBoV
Fbuh5vPmFW07mE5VsrP9Y481Eafrea2/rsdMinNSk2EdYauIN572rJl+oSFfaNyYnvmyLs3j
Qp2yjW7VaZBdX/rXhCzgwS/LX0AUbEno8CcmW7ZYsx52RK1rAMWboiLp8fvx5Wr3wnYRqSCt
+yyQCjVikg137IkI6Gd9Nqq+gRBPuuzdUxCxVsDSEBgWF4270Ojaq8Yr9V3JTuFyMi4Q
/

