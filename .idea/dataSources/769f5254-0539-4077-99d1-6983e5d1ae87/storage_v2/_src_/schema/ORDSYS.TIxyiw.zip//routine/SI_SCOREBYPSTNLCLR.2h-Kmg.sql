create FUNCTION
  SI_ScoreByPstnlClr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
139 11f
dcOgKYM6RednYJ7U0qEBXQx/eQ8wg3lKLcsVfHSiWPiUHDXm5KZeE0WV8R7Dn2V8f8phnhRw
7ruhJWZGom+6v5bBHlFTZ4fdfZHBBXMlNNTGTnu+Kby5S8vM801TjHiXkdf/A7F5RLUcsjLQ
Qv/0N3VtoKFT4Bi2ERB+BDjD9ZE+fK0ydFsnr+lcibgYQOx3bx38Z+Y+1PuTPXCuiFv8jwX/
Z2ZOORX7AT4NcZeSvFqFQJ0ZmxCcuntkU0H2b3ZjLkmXo0NzaiHGs6xLC1VkGTWtLoY=
/

