create PACKAGE ORDImageExceptions AS

  NULL_CONTENT                          EXCEPTION;
  NULL_PROPERTIES_DESCRIPTION           EXCEPTION;
  NULL_LOCAL_DATA                       EXCEPTION;
  NULL_DESTINATION                      EXCEPTION;
  DATA_NOT_LOCAL                        EXCEPTION;
  NULL_SOURCE                           EXCEPTION;
  INDEX_CREATE_STR_PARSE_ERR            EXCEPTION;
  DUPL_PARAM_STR                        EXCEPTION;
  THRESHOLD_OUT_OF_RANGE                EXCEPTION;
  INVALID_MIME_TYPE                     EXCEPTION;

END ORDImageExceptions;
/

