create PACKAGE        CARTRIDGE wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
159 db
qsWpmstsDngkv2ChcnDzpdHXpSAwg+3INZ7hf3TpTP6Ok8Uw1pNjLuWvYYh7slMecyA4ZweT
59FzL4XBJBVJ1ehbGQTTM7MCz5kRhtE225Or/sq65/twzex12IJp2AVHX2rX2CtAwxs1F/8i
4gBt5QIt+02yqckqwJ2886DBWSd53YCahT/pozwdoemMwZxDgEnxGoG7MlOzCJVD0uFhWmmg

/

