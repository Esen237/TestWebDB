create FUNCTION
  SI_getWidth wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
dd e3
vkAEEGydAp0Uf7bz+v53W8IMd/owg1xKLcsVfHSiWPiUHCkVKPXF1yoNias+Unctmee0+LXl
9jbTt2P+udwcCnSXeGsVHk4tYrv4M3tOaIAv2laXPq0R/VF0O5NZPmbCN7z82zdA7IKisaNu
ORabRxU8HOMMx+mRfzV6Jb+8yHeJoyW94n14qqX/8wmvnU6blRy6V31dPlpLVeKt4vTnc1Pr
y4SjeMQ=
/

