create FUNCTION
  SI_getAvgClrFtr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
10e f7
VM3V7kN76/2KxbwAYk3AysDfx4Iwg1xKLcsVfHSiWE6UHCkVKHwC0iWjniZdV9iQaR/o5Qb4
oWYvO0n4GTEXT4xeQWZsQZzByZptEjs/unIcKwPKuAkGQL/yF+M2ASfdIsqfqRMVFES02O/+
XcLnUf+ta+UAjsDBVGEx80nHat0tpuCuxqCifwdQ90oRQA8QttU036Sor3a0uf9jEN9Tyodj
OvP40zyjXviS+KZzE9wsQqbplA==
/

