create package        ORD_DICOM_ADMIN
authid current_user
AS
  --
  -- public constants
  --
  DT_URL CONSTANT VARCHAR2(700) := 'xmlns:dt="http://xmlns.oracle.com/ord/dicom/datatype_1_0"';

  STORED_TAGLIST_DOC_SET CONSTANT VARCHAR2(64) :='USER';
  DMDL_DOC_SET           CONSTANT VARCHAR2(64) :='USER';

--==============================================================================
--loads a single document of the specified docType into repos
-- docName must be unique
--==============================================================================
 PROCEDURE insertDocument(
                docName IN VARCHAR2,
                docType IN VARCHAR2,
                xmlDoc XMLTYPE
           );


--==============================================================================
-- return the configuration document as an XMLType.
--docName uniquely identfies the document
--==============================================================================
 FUNCTION  getDocumentContent(docName IN VARCHAR2) return XMLTYPE;

 --==============================================================================
-- export the document to a file specfied by fileName in the location specfied
-- by dirName is the directory object created  by
-- create or replace directory command
-- the dirName must match the name listed in all_directories
 --==============================================================================
 PROCEDURE exportDocument(
             docName IN VARCHAR2,
             dirName IN VARCHAR2,
             fileName IN VARCHAR2
           );

--==============================================================================
-- Documents installed by Oracle cannot be removed
--delete of dictionary documents is not supported in this release
--==============================================================================
 PROCEDURE deleteDocument(docName IN VARCHAR2 ) ;

--==============================================================================
--   Starts the data model edits , locks the data model
--==============================================================================
 PROCEDURE editDataModel;

--==============================================================================
--    Commits changes and publishes the new data model
--    unlocks the data model
--==============================================================================
 PROCEDURE publishDataModel;

--==============================================================================
--    aborts the changes to the data model
--    unlocks the data model
--==============================================================================
 PROCEDURE rollbackDataModel;

--==============================================================================
--   Generates the STORED_TAG_LIST document as an XMLType
--   for the specified set of constraint and mapping documents in the repository
--   Useful for keeping the STORED_TAG_LIST in sync with the repos docs
--   args: docSet: the allowed values are 'ALL', 'ORACLE' 'USER'
--                The default value 'USER' is represented by the constant
--                 STORED_TAGLIST_DOC_SET
--
--==============================================================================
 FUNCTION generateTagListDocument(docSet in varchar2 default STORED_TAGLIST_DOC_SET)
 return XMLType;

--==============================================================================

END ORD_DICOM_ADMIN;
/

