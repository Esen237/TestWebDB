create view CDB_MVIEW_REFRESH_TIMES (OWNER, NAME, MASTER_OWNER, MASTER, LAST_REFRESH, CON_ID) as
SELECT k."OWNER",k."NAME",k."MASTER_OWNER",k."MASTER",k."LAST_REFRESH",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_MVIEW_REFRESH_TIMES") k
/

comment on table CDB_MVIEW_REFRESH_TIMES is 'All fast refreshable materialized views and their last refresh times for each master table in all containers'
/

comment on column CDB_MVIEW_REFRESH_TIMES.OWNER is 'Owner of the materialized view'
/

comment on column CDB_MVIEW_REFRESH_TIMES.NAME is 'The view used by users and applications for viewing the MV'
/

comment on column CDB_MVIEW_REFRESH_TIMES.MASTER_OWNER is 'Owner of the master table'
/

comment on column CDB_MVIEW_REFRESH_TIMES.MASTER is 'Name of the master table'
/

comment on column CDB_MVIEW_REFRESH_TIMES.LAST_REFRESH is 'SYSDATE from the master site at the time of the last refresh'
/

comment on column CDB_MVIEW_REFRESH_TIMES.CON_ID is 'container id'
/

