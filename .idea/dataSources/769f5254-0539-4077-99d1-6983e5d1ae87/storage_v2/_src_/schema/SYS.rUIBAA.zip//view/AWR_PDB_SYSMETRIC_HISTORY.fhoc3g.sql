create view AWR_PDB_SYSMETRIC_HISTORY
            (SNAP_ID, DBID, INSTANCE_NUMBER, BEGIN_TIME, END_TIME, INTSIZE, GROUP_ID, METRIC_ID, METRIC_NAME, VALUE,
             METRIC_UNIT, CON_DBID, CON_ID)
as
select m.snap_id, m.dbid, m.instance_number,
       begin_time, end_time, intsize,
       m.group_id, m.metric_id, mn.metric_name, value, mn.metric_unit,
       decode(m.con_dbid, 0, m.dbid, m.con_dbid),
       con_dbid_to_id(decode(m.con_dbid, 0, m.dbid, m.con_dbid)) con_id
from AWR_PDB_SNAPSHOT sn, WRH$_SYSMETRIC_HISTORY m, WRH$_METRIC_NAME mn
where       m.group_id       = mn.group_id
      and   m.metric_id      = mn.metric_id
      and   m.dbid           = mn.dbid
      and   sn.snap_id       = m.snap_id
      and sn.dbid            = m.dbid
      and sn.instance_number = m.instance_number
/

comment on table AWR_PDB_SYSMETRIC_HISTORY is 'System Metrics History'
/

