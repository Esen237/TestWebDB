create view KU$_SUBCOLTYPE_VIEW
            (OBJ_NUM, INTCOL_NUM, TOID, SCHEMA_OBJ, VERSION, HASHCODE, TYPEID, INTCOLS, INTCOL_NUMS, FLAGS) as
select sct.obj#, sct.intcol#,
         sct.toid,
         value(o),           /* always get schema object */
         t.version#,
         sys.dbms_metadata.get_hashcode(o.owner_name,o.name),
         t.typeid,
         sct.intcols, sct.intcol#s, bitand(sct.flags, (power(2, 32)-1))
    from ku$_schemaobj_view o, type$ t, subcoltype$ sct
    where o.oid=sct.toid
      and o.oid=t.toid
      and t.toid=t.tvoid     /* only the latest type */
/

