create view REDACTION_POLICIES (OBJECT_OWNER, OBJECT_NAME, POLICY_NAME, EXPRESSION, ENABLE, POLICY_DESCRIPTION) as
select u.name                               object_owner,
       o.name                               object_name,
       r.pname                              policy_name,
       rpe.pe_pexpr                         policy_expression,
       DECODE(r.enable_flag, 0, 'NO',
                                'YES')      enable,
       d.pdesc                              policy_description
from   radm$    r,
       radm_pe$ rpe,
       obj$     o,
       user$    u,
       radm_td$ d
where  r.obj#   = o.obj#
   and o.owner# = u.user#
   and r.obj#   = rpe.pe_obj#
   and r.obj#   = d.obj#(+)
   and r.pname  = d.pname(+)
/

comment on table REDACTION_POLICIES is 'All Redaction Policies in the database'
/

comment on column REDACTION_POLICIES.OBJECT_OWNER is 'Owner of the table, or view'
/

comment on column REDACTION_POLICIES.OBJECT_NAME is 'Name of the table, or view'
/

comment on column REDACTION_POLICIES.POLICY_NAME is 'Name of the policy'
/

comment on column REDACTION_POLICIES.EXPRESSION is 'Expression defined for this policy'
/

comment on column REDACTION_POLICIES.ENABLE is 'If YES, redaction policy is enforced on this object'
/

comment on column REDACTION_POLICIES.POLICY_DESCRIPTION is 'Description of this policy'
/

