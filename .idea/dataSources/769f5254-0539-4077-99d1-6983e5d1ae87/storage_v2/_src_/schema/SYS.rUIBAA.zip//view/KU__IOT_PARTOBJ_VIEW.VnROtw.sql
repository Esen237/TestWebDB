create view KU$_IOT_PARTOBJ_VIEW
            (OBJ_NUM, TABPARTOBJ, PARTCOLS, SUBPARTCOLS, INDPARTOBJ, OVPARTOBJ, PART_LIST, IOV_LIST, IMAP_LIST) as
select t.obj#,
         (select value (tpo) from ku$_partobj_view tpo
          where t.obj# = tpo.obj_num),
         cast(multiset(select * from ku$_tab_part_col_view pc
                       where pc.obj_num = t.obj#
                        order by pc.pos_num
                      ) as ku$_part_col_list_t
             ),
         cast(multiset(select * from ku$_tab_subpart_col_view sc
                       where sc.obj_num = t.obj#
                        order by sc.pos_num
                      ) as ku$_part_col_list_t
             ),
         (select value (ipo) from ku$_partobj_view ipo
          where i.obj# = ipo.obj_num),
         (select value (ovpo) from ku$_partobj_view ovpo
          where t.bobj# = ovpo.obj_num),
         cast(multiset(select * from ku$_piot_part_view ip
                       where ip.base_obj_num = i.obj#
                        order by ip.part_num
                      ) as ku$_piot_part_list_t
             ),
         cast(multiset(select * from ku$_ov_tabpart_view ovp
                       where ovp.bobj_num = t.bobj#
                        order by ovp.part_num
                      ) as ku$_ov_tabpart_list_t
             ),
         cast(multiset(select value(mp) from ku$_map_tabpart_view mp
                       -- Mapping table object number exists in tab$.pctfree$
                       where mp.bobj_num = t.pctfree$
                        order by mp.part_num
                      ) as ku$_map_tabpart_list_t
             )
  from tab$ t, ind$ i
  where i.bo#=t.obj#
    and i.type#=4                       -- iot index
    and bitand(t.property,32)=32        -- partitioned table
/

