create view NACL$_ACE_EXP
            (ACL, OWNER, ACE_ORDER, START_DATE, END_DATE, GRANT_TYPE, INVERTED_PRINCIPAL, PRINCIPAL, PRINCIPAL_TYPE,
             PRIVILEGE, SECURITY_CLASS, SECURITY_CLASS_OWNER)
as
select acl, owner, ace_order, start_date, end_date, grant_type,
       inverted_principal, principal,
       decode(principal_type, 'APPLICATION', 'APPLICATION USER',
                              'DATABASE', 'DATABASE USER',
                              'EXTERNAL', 'EXTERNAL USER',
                              principal_type) principal_type,
       privilege, security_class, security_class_owner
  from dba_xs_aces
 where (acl, owner) in
       (select name, owner from dba_xs_objects
         where id in (select acl# from sys.nacl$_host
                       union all
                      select acl# from sys.nacl$_wallet)) and
       (principal, principal_type) not in
       (select username, 'DATABASE' from dba_users
         where oracle_maintained = 'Y')
/

