create view DBA_STREAMS_RENAME_TABLE
            (RULE_OWNER, RULE_NAME, FROM_SCHEMA_NAME, TO_SCHEMA_NAME, FROM_TABLE_NAME, TO_TABLE_NAME, PRECEDENCE,
             STEP_NUMBER) as
select rule_owner, rule_name, from_schema_name, to_schema_name,
       from_table_name, to_table_name, precedence, step_number
  from DBA_STREAMS_TRANSFORMATIONS
  where declarative_type = 'RENAME TABLE'
/

comment on table DBA_STREAMS_RENAME_TABLE is 'Rename table transformations'
/

comment on column DBA_STREAMS_RENAME_TABLE.RULE_OWNER is 'Owner of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_RENAME_TABLE.RULE_NAME is 'Name of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_RENAME_TABLE.FROM_SCHEMA_NAME is 'The schema to be renamed'
/

comment on column DBA_STREAMS_RENAME_TABLE.TO_SCHEMA_NAME is 'The new schema name'
/

comment on column DBA_STREAMS_RENAME_TABLE.FROM_TABLE_NAME is 'The table to be renamed'
/

comment on column DBA_STREAMS_RENAME_TABLE.TO_TABLE_NAME is 'The new table name'
/

comment on column DBA_STREAMS_RENAME_TABLE.PRECEDENCE is 'Execution order relative to other declarative transformations on the same step_number'
/

comment on column DBA_STREAMS_RENAME_TABLE.STEP_NUMBER is 'The order that this transformation should be executed'
/

