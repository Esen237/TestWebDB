create view EXU8ANAL (ID, ROWCNT) as
SELECT  obj#, SIGN(NVL(rowcnt, -1))
        FROM    sys.tab$
/

