create view AWR_CDB_CELL_DISKTYPE
            (DBID, SNAP_ID, CELL_HASH, CELL_NAME, HARD_DISK_TYPE, FLASH_DISK_TYPE, NUM_CELL_DISKS, NUM_GRID_DISKS,
             NUM_HARD_DISKS, NUM_FLASH_DISKS, MAX_DISK_IOPS, MAX_FLASH_IOPS, MAX_DISK_MBPS, MAX_FLASH_MBPS,
             MAX_CELL_DISK_IOPS, MAX_CELL_FLASH_IOPS, MAX_CELL_DISK_MBPS, MAX_CELL_FLASH_MBPS, CONFVAL, CON_DBID,
             CON_ID)
as
select d.dbid,
       d.snap_id,
       c.cellhash cell_hash,
       extractvalue(xmltype(c.confval),'/cli-output/context/@cell') cell_name,
       extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/hardDiskType') hard_disk_type,
       extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/flashDiskType') flash_disk_type,
       to_number(extractvalue(xmltype(c.confval),
                   '/cli-output/not-set/numCellDisks'))  num_cell_disks,
       to_number(extractvalue(xmltype(c.confval),
                   '/cli-output/not-set/numGridDisks'))  num_grid_disks,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numHardDisks'))  num_hard_disks,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numFlashDisks'))  num_flash_disks,
       to_number(
         extractvalue(xmltype(c.confval),'/cli-output/not-set/maxPDIOPS'))
                                                            max_disk_iops,
       to_number(
         extractvalue(xmltype(c.confval),'/cli-output/not-set/maxFDIOPS'))
                                                           max_flash_iops,
       to_number(
         extractvalue(xmltype(c.confval),'/cli-output/not-set/maxPDMBPS'))
                                                           max_disk_mbps,
       to_number(
         extractvalue(xmltype(c.confval),'/cli-output/not-set/maxFDMBPS'))
                                                         max_flash_mbps,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numHardDisks')) *
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/maxPDIOPS'))  max_cell_disk_iops,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numFlashDisks')) *
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/maxFDIOPS'))  max_cell_flash_iops,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numHardDisks')) *
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/maxPDMBPS'))  max_cell_disk_mbps,
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/numFlashDisks')) *
       to_number(extractvalue(xmltype(c.confval),
                    '/cli-output/not-set/maxFDMBPS'))  max_cell_flash_mbps,
       c.confval,
       decode(d.con_dbid, 0, d.dbid, d.con_dbid) con_dbid,
       decode(d.per_pdb, 0, 0,
         con_dbid_to_id(decode(d.con_dbid, 0, d.dbid, d.con_dbid))) con_id
  from wrh$_cell_config_detail d,
       wrh$_cell_config c
 where d.dbid = c.dbid
   and d.cellhash = c.cellhash
   and d.conftype = c.conftype
   and d.confval_hash = c.confval_hash
   and c.conftype = 'AWRXML'
/

comment on table AWR_CDB_CELL_DISKTYPE is 'Exadata Cell disk types'
/

