create view AWR_PDB_MTTR_TARGET_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, MTTR_TARGET_FOR_ESTIMATE, ADVICE_STATUS, DIRTY_LIMIT, ESTD_CACHE_WRITES,
             ESTD_CACHE_WRITE_FACTOR, ESTD_TOTAL_WRITES, ESTD_TOTAL_WRITE_FACTOR, ESTD_TOTAL_IOS, ESTD_TOTAL_IO_FACTOR,
             CON_DBID, CON_ID)
as
select mt.snap_id, mt.dbid, mt.instance_number, mttr_target_for_estimate,
       advice_status, dirty_limit,
       estd_cache_writes, estd_cache_write_factor,
       estd_total_writes, estd_total_write_factor,
       estd_total_ios, estd_total_io_factor,
       decode(mt.con_dbid, 0, mt.dbid, mt.con_dbid),
       decode(mt.per_pdb, 0, 0,
         con_dbid_to_id(decode(mt.con_dbid, 0, mt.dbid, mt.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_MTTR_TARGET_ADVICE mt
  where     sn.snap_id         = mt.snap_id
        and sn.dbid            = mt.dbid
        and sn.instance_number = mt.instance_number
/

comment on table AWR_PDB_MTTR_TARGET_ADVICE is 'Mean-Time-To-Recover Target Advice History'
/

