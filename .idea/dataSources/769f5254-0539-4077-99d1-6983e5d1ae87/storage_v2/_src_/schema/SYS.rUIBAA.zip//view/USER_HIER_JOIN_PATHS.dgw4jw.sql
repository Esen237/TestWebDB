create view USER_HIER_JOIN_PATHS (HIER_NAME, JOIN_PATH_NAME, ORDER_NUM, ORIGIN_CON_ID) as
select HIER_NAME, JOIN_PATH_NAME, ORDER_NUM, ORIGIN_CON_ID
from   NO_ROOT_SW_FOR_LOCAL(INT$DBA_HIER_JOIN_PATHS)
where  owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_HIER_JOIN_PATHS is 'Hierarchy join paths in the database'
/

comment on column USER_HIER_JOIN_PATHS.HIER_NAME is 'Name of the owning hierarchy join path'
/

comment on column USER_HIER_JOIN_PATHS.JOIN_PATH_NAME is 'Name of the hierarchy join path'
/

comment on column USER_HIER_JOIN_PATHS.ORDER_NUM is 'Order number of join path within the hierarchy'
/

comment on column USER_HIER_JOIN_PATHS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

