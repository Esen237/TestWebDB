create view ALL_ANALYTIC_VIEW_LEVELS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, HIER_ALIAS, LEVEL_NAME, ORDER_NUM, ORIGIN_CON_ID) as
select owner,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       HIER_ALIAS,
       LEVEL_NAME,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_LEVELS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

comment on table ALL_ANALYTIC_VIEW_LEVELS is 'Analytic view levels in the database'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.OWNER is 'Owner of the analytic view level'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.ANALYTIC_VIEW_NAME is 'Name of analytic view'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.DIMENSION_ALIAS is 'Alias of the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.HIER_ALIAS is 'Alias of the hierarchy within the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.LEVEL_NAME is 'Name of the level within the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.ORDER_NUM is 'Order number of analytic view level'
/

comment on column ALL_ANALYTIC_VIEW_LEVELS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

