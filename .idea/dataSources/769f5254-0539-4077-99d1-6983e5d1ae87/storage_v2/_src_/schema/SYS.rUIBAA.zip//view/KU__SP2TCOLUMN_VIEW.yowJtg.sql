create view KU$_SP2TCOLUMN_VIEW
            (OBJ_NUM, COL_NUM, INTCOL_NUM, SEGCOL_NUM, SEGCOLLENGTH, OFFSET, PROPERTY, PROPERTY2, NAME, TYPE_NUM,
             LENGTH, FIXEDSTORAGE, PRECISION_NUM, SCALE, NOT_NULL, DEFLENGTH, DEFAULT_VAL, DEFAULT_VALC, PARSED_DEF,
             BINARYDEFVAL, GUARD_ID, CHARSETID, CHARSETFORM, CON, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6,
             IDENTITY_COL, EVALEDITION_NUM, UNUSABLEBEF_NUM, UNUSABLEBEG_NUM, ATTRNAME2, COL_SORTKEY, COLLNAME,
             COLLINTCOL_NUM, ATTRNAME, FULLATTRNAME, BASE_INTCOL_NUM, BASE_COL_TYPE, BASE_COL_NAME, TYPEMD, OIDINDEX,
             LOBMD, OPQMD, PLOBMD, PART_OBJNUM)
as
select *
 from ku$_sp2tpartcol_view c
UNION ALL
 select *
 from ku$_column_view c
 where not (c.type_num in (112,113)
            or (c.type_num = 58 and
                EXISTS ( SELECT 1
                         from sys.opqtype$ op
                         where op.obj#=c.obj_num and op.intcol#=c.intcol_num
                               and (op.type != 1 or (bitand(op.flags,4) = 0) )
            or (c.type_num in (1,23) and  bitand(c.property,128)!=0))))
/

