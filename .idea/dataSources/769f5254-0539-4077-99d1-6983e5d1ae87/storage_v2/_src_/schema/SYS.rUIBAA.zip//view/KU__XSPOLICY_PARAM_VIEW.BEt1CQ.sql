create view KU$_XSPOLICY_PARAM_VIEW (VERS_MAJOR, VERS_MINOR, XDSID, POLICY_NAME, POLICY_OWNER, NAME, TYPE) as
select '1','0',
  p.xdsid#,
  (select name from xs$obj where id = p.xdsid#),
  (select owner from xs$obj where id = p.xdsid#),
  p.pname,
  p.type
  from xs$policy_param p
/

