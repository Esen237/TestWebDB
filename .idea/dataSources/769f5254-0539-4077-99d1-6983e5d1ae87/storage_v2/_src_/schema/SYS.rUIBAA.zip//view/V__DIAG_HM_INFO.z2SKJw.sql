create view V_$DIAG_HM_INFO (INFO_ID, NAME, VALUE, TYPE, FLAGS, CON_ID) as
select
   "INFO_ID",
   "NAME",
   "VALUE",
   "TYPE",
   "FLAGS",
   "CON_ID"
  from x$diag_HM_INFO
/

