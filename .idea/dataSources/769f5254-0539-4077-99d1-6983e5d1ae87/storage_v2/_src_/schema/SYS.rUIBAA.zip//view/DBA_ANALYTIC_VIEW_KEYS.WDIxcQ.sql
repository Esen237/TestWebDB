create view DBA_ANALYTIC_VIEW_KEYS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, AV_KEY_TABLE_ALIAS, AV_KEY_COLUMN, REF_DIMENSION_ATTR,
             ORDER_NUM, ORIGIN_CON_ID)
as
select OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, AV_KEY_TABLE_ALIAS,
    AV_KEY_COLUMN, REF_DIMENSION_ATTR, ORDER_NUM, ORIGIN_CON_ID
from INT$DBA_AVIEW_KEYS
/

comment on table DBA_ANALYTIC_VIEW_KEYS is 'Analytic_view keys in the database'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.OWNER is 'Owner of analytic view'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.ANALYTIC_VIEW_NAME is 'Name of the analytic view'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.DIMENSION_ALIAS is 'Alias of the attribute dimension in the analytic view'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.AV_KEY_TABLE_ALIAS is 'Table alias of the analytic view key column'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.AV_KEY_COLUMN is 'Name of the column for the analytic view key'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.REF_DIMENSION_ATTR is 'Name of the referenced dimension attribute'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.ORDER_NUM is 'Order number of the key in the list'
/

comment on column DBA_ANALYTIC_VIEW_KEYS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

