create view CDB_DATAPUMP_JOBS
            (OWNER_NAME, JOB_NAME, OPERATION, JOB_MODE, STATE, DEGREE, ATTACHED_SESSIONS, DATAPUMP_SESSIONS, CON_ID) as
SELECT k."OWNER_NAME",k."JOB_NAME",k."OPERATION",k."JOB_MODE",k."STATE",k."DEGREE",k."ATTACHED_SESSIONS",k."DATAPUMP_SESSIONS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DATAPUMP_JOBS") k
/

comment on table CDB_DATAPUMP_JOBS is 'Datapump jobs in all containers'
/

comment on column CDB_DATAPUMP_JOBS.OWNER_NAME is 'User that initiated the job'
/

comment on column CDB_DATAPUMP_JOBS.JOB_NAME is 'Job name'
/

comment on column CDB_DATAPUMP_JOBS.OPERATION is 'Type of operation being performed'
/

comment on column CDB_DATAPUMP_JOBS.JOB_MODE is 'Mode of operation being performed'
/

comment on column CDB_DATAPUMP_JOBS.STATE is 'Current job state'
/

comment on column CDB_DATAPUMP_JOBS.DEGREE is 'Number of worker proceses performing the operation'
/

comment on column CDB_DATAPUMP_JOBS.ATTACHED_SESSIONS is 'Number of sessions attached to the job'
/

comment on column CDB_DATAPUMP_JOBS.DATAPUMP_SESSIONS is 'Number of Datapump sessions participating in the job'
/

comment on column CDB_DATAPUMP_JOBS.CON_ID is 'container id'
/

