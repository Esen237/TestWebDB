create view AWR_ROOT_SNAP_ERROR (SNAP_ID, DBID, INSTANCE_NUMBER, TABLE_NAME, ERROR_NUMBER, STEP_ID, CON_ID) as
select snap_id, dbid, instance_number, table_name, error_number, step_id,
          decode(con_dbid_to_id(dbid), 1, 0, con_dbid_to_id(dbid)) con_id
  from wrm$_snap_error
/

comment on table AWR_ROOT_SNAP_ERROR is 'Snapshot Error Information'
/

