create view AWR_ROOT_APPLY_SUMMARY
            (SNAP_ID, DBID, INSTANCE_NUMBER, APPLY_NAME, STARTUP_TIME, READER_TOTAL_MESSAGES_DEQUEUED, READER_LAG,
             COORD_TOTAL_RECEIVED, COORD_TOTAL_APPLIED, COORD_TOTAL_ROLLBACKS, COORD_TOTAL_WAIT_DEPS,
             COORD_TOTAL_WAIT_CMTS, COORD_LWM_LAG, SERVER_TOTAL_MESSAGES_APPLIED, SERVER_ELAPSED_DEQUEUE_TIME,
             SERVER_ELAPSED_APPLY_TIME, CON_DBID, REPLICAT_NAME, UNASSIGNED_COMPLETE_TXN, TOTAL_LCRS_RETRIED,
             TOTAL_TRANSACTIONS_RETRIED, TOTAL_ERRORS, SESSION_MODULE, CON_ID)
as
select sas.snap_id, sas.dbid, sas.instance_number, sas.apply_name,
       sas.startup_time, sas.reader_total_messages_dequeued, sas.reader_lag,
       sas.coord_total_received, sas.coord_total_applied,
       sas.coord_total_rollbacks, sas.coord_total_wait_deps,
       sas.coord_total_wait_cmts, sas.coord_lwm_lag,
       sas.server_total_messages_applied, sas.server_elapsed_dequeue_time,
       sas.server_elapsed_apply_time,
       decode(sas.con_dbid, 0, sas.dbid, sas.con_dbid),
       sas.replicat_name, sas.unassigned_complete_txn,
       sas.total_lcrs_retried,
       sas.total_transactions_retried, sas.total_errors, sas.session_module,
       decode(sas.per_pdb, 0, 0,
         con_dbid_to_id(decode(sas.con_dbid, 0, sas.dbid, sas.con_dbid))) con_id
  from wrh$_streams_apply_sum sas, AWR_ROOT_SNAPSHOT sn
  where sn.snap_id              = sas.snap_id
        and sn.dbid             = sas.dbid
        and sn.instance_number  = sas.instance_number
/

comment on table AWR_ROOT_APPLY_SUMMARY is 'Streams/Goldengate/XStream Apply Historical Statistics Information'
/

