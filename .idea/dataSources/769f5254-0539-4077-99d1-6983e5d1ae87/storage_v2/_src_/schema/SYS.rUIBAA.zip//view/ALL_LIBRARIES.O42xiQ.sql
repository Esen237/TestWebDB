create view ALL_LIBRARIES (OWNER, LIBRARY_NAME, FILE_SPEC, DYNAMIC, STATUS, AGENT, LEAF_FILENAME, ORIGIN_CON_ID) as
select OWNER, LIBRARY_NAME, FILE_SPEC, DYNAMIC, STATUS, AGENT,
       LEAF_FILENAME, ORIGIN_CON_ID
from   INT$DBA_LIBRARIES
where  (OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER = 'PUBLIC'
       or OBJ_ID(OWNER, LIBRARY_NAME, 22, OBJECT_ID) in
          ( select oa.obj#
            from sys.objauth$ oa
            where grantee# in (select kzsrorol from x$kzsro)
          )
       or (
            exists (select NULL from v$enabledprivs
                    where priv_number in (
                                      -189 /* CREATE ANY LIBRARY */,
                                      -190 /* ALTER ANY LIBRARY */,
                                      -191 /* DROP ANY LIBRARY */,
                                      -192 /* EXECUTE ANY LIBRARY */
                                         )
                   )
          )
      )
/

comment on table ALL_LIBRARIES is 'Description of libraries accessible to the user'
/

comment on column ALL_LIBRARIES.OWNER is 'Owner of the library'
/

comment on column ALL_LIBRARIES.LIBRARY_NAME is 'Name of the library'
/

comment on column ALL_LIBRARIES.FILE_SPEC is 'Operating system file specification of the library'
/

comment on column ALL_LIBRARIES.DYNAMIC is 'Is the library dynamically loadable'
/

comment on column ALL_LIBRARIES.STATUS is 'Status of the library'
/

comment on column ALL_LIBRARIES.AGENT is 'Agent of the library'
/

comment on column ALL_LIBRARIES.LEAF_FILENAME is 'Leaf filename of the library'
/

comment on column ALL_LIBRARIES.ORIGIN_CON_ID is 'ID of Container where row originates'
/

