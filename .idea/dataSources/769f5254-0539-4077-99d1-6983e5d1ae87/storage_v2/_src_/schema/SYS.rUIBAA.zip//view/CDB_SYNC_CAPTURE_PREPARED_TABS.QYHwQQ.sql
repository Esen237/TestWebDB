create view CDB_SYNC_CAPTURE_PREPARED_TABS (TABLE_OWNER, TABLE_NAME, SCN, TIMESTAMP, CON_ID) as
SELECT k."TABLE_OWNER",k."TABLE_NAME",k."SCN",k."TIMESTAMP",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SYNC_CAPTURE_PREPARED_TABS") k
/

comment on table CDB_SYNC_CAPTURE_PREPARED_TABS is 'All tables prepared for synchronous capture instantiation in all containers'
/

comment on column CDB_SYNC_CAPTURE_PREPARED_TABS.TABLE_OWNER is 'Owner of the table prepared for synchronous capture instantiation'
/

comment on column CDB_SYNC_CAPTURE_PREPARED_TABS.TABLE_NAME is 'Name of the table prepared for synchronous capture instantiation'
/

comment on column CDB_SYNC_CAPTURE_PREPARED_TABS.SCN is 'SCN from which changes can be captured'
/

comment on column CDB_SYNC_CAPTURE_PREPARED_TABS.TIMESTAMP is 'Time at which the table was ready to be instantiated'
/

comment on column CDB_SYNC_CAPTURE_PREPARED_TABS.CON_ID is 'container id'
/

