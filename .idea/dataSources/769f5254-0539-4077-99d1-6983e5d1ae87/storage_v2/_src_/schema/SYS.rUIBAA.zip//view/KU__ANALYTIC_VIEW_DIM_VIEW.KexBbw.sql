create view KU$_ANALYTIC_VIEW_DIM_VIEW
            (AV_OBJ#, DIM_OBJ#, DIM_OWNER, OWNER_IN_DDL, NAME, DIM_ALIAS, REF_DISTINCT, KEY_LIST, HIER_LIST,
             CLSFCTN_LIST, ORDER_NUM)
as
select avd.av#,
       avd.av_dim#,
       avd.dim_owner,
       avd.owner_in_ddl,
       avd.dim_name,
       avd.alias,
       avd.ref_distinct,
       cast(multiset(select k.*
                       from ku$_analytic_view_keys_view k
                       where k.av_obj# = avd.av#
                       and k.dim_obj# = avd.av_dim#
                       order by k.order_num
                      ) as ku$_analytic_view_keys_list_t
         ),
       cast(multiset(select avh.*
                       from ku$_analytic_view_hiers_view avh
                       where avh.av_obj# = avd.av#
                       and avh.dim_obj# = avd.av_dim#
                       order by avh.order_num
                      ) as ku$_analytic_view_hiers_list_t
         ),
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = avd.av#
                       and c.sub_obj# = avd.av_dim#
                       and c.obj_type = 6    --HCSDDL_DICT_TYPE_AVDIM
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
       avd.order_num
from hcs_av_dim$ avd
/

