create view DBA_ATTRIBUTE_DIM_ATTRS
            (OWNER, DIMENSION_NAME, ATTRIBUTE_NAME, TABLE_ALIAS, COLUMN_NAME, ORDER_NUM, ORIGIN_CON_ID) as
select OWNER, DIMENSION_NAME, ATTRIBUTE_NAME, TABLE_ALIAS, COLUMN_NAME,
    ORDER_NUM, origin_con_id
from INT$DBA_ATTR_DIM_ATTRS
/

comment on table DBA_ATTRIBUTE_DIM_ATTRS is 'Attribute dimension attributes in the database'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.OWNER is 'Owner of the attribute dimension attribute'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.DIMENSION_NAME is 'Name of the owning attribute dimension of the Attribute'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.ATTRIBUTE_NAME is 'Name of the attribute owned by the attribute dimension'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.TABLE_ALIAS is 'Alias of the table or view in the USING clause to which the column belongs'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.COLUMN_NAME is 'Column name in the table or view on which this attribute is defined'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.ORDER_NUM is 'Order number of attribute dimension attribute within the Dimension'
/

comment on column DBA_ATTRIBUTE_DIM_ATTRS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

