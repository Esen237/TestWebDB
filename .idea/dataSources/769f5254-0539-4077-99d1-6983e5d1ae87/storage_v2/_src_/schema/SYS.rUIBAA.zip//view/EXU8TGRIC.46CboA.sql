create view EXU8TGRIC
            (OWNERID, OWNER, BASEOBJECT, DEFINITION, WHENCLAUSE, ACTION, ENABLED, NAME, BASENAME, BASETYPE, PROPERTY,
             BTOWNER, BTOWNERID, ACTIONSIZE)
as
SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE"
        FROM    sys.exu8tgr
        WHERE   (ownerid, basename) IN (
                    SELECT  i.owner#, i.name
                    FROM    sys.incexp i, sys.incvid v
                    WHERE   i.expid > v.expid AND
                            i.type# IN (2, 4))
/

