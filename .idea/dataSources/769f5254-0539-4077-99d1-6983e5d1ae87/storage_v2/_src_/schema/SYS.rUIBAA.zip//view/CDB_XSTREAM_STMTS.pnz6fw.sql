create view CDB_XSTREAM_STMTS (HANDLER_NAME, EXECUTION_SEQUENCE, STATEMENT, CREATION_TIME, MODIFICATION_TIME, CON_ID) as
SELECT k."HANDLER_NAME",k."EXECUTION_SEQUENCE",k."STATEMENT",k."CREATION_TIME",k."MODIFICATION_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XSTREAM_STMTS") k
/

comment on table CDB_XSTREAM_STMTS is ' in all containers'
/

comment on column CDB_XSTREAM_STMTS.HANDLER_NAME is 'Name of the stmt handler'
/

comment on column CDB_XSTREAM_STMTS.EXECUTION_SEQUENCE is 'Execution sequence of the statement'
/

comment on column CDB_XSTREAM_STMTS.STATEMENT is 'text of the statement'
/

comment on column CDB_XSTREAM_STMTS.CREATION_TIME is 'timestamp for statement creation'
/

comment on column CDB_XSTREAM_STMTS.MODIFICATION_TIME is 'timestamp for statement modification'
/

comment on column CDB_XSTREAM_STMTS.CON_ID is 'container id'
/

