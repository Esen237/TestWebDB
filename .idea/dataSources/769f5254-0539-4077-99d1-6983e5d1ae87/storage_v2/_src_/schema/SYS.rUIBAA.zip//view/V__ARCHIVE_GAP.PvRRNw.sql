create view V_$ARCHIVE_GAP (THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE#, CON_ID) as
select "THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#","CON_ID" from v$archive_gap
/

