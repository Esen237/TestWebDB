create view NACL$_WALLET_EXP (WALLET_PATH, ACL_NAME, ACL_OWNER) as
select w.wallet_path, o.name, o.owner
  from sys.nacl$_wallet w, dba_xs_objects o
 where w.acl# = o.id
/

