create view KU$_IONT_VIEW
            (OBJ_NUM, PROPERTY, PROPERTY2, PROPERTY3, STORAGE, DEFERRED_STG, TS_NAME, BLOCKSIZE, PCT_FREE, INITRANS,
             MAXTRANS, FLAGS, CON0_LIST, CON1_LIST, CON2_LIST, PKREF_LIST, PARTOBJ, PCT_USED, PCT_THRESH, NUMKEYCOLS,
             INCLCOL_NAME, IOV)
as
select t.obj#,
        bitand(t.property, (power(2, 32)-1)),
        bitand(trunc(t.property / power(2, 32)), (power(2, 32)-1)),
        trunc(t.property / power(2, 64)),
        (select value(s) from ku$_storage_view s
         where st.file#  = s.file_num
           and st.block# = s.block_num
           and st.ts#    = s.ts_num),
        (select value(s) from ku$_deferred_stg_view s
         where s.obj_num = st.obj#),
        (select ts.name from ts$ ts where st.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where st.ts# = ts.ts#),
        st.pctfree$, st.initrans, st.maxtrans,
        bitand(t.flags, (power(2, 32)-1)),
         cast( multiset(select * from ku$_constraint0_view con
                        where con.obj_num = t.obj#
                        and con.contype not in (7,11)
                       ) as ku$_constraint0_list_t
             ),
         cast( multiset(select * from ku$_constraint1_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint1_list_t
             ),
         cast( multiset(select * from ku$_constraint2_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint2_list_t
             ),
         cast( multiset(select * from ku$_pkref_constraint_view con
                        where con.obj_num = t.obj#
                       ) as ku$_pkref_constraint_list_t
             ),
         
         null, null,
         mod(st.pctthres$,256), st.spare2,
        (select c.name from col$ c
                 where c.obj# = st.bo#
                 and   c.col# = st.trunccnt and st.trunccnt != 0),
        (select value(ov) from ku$_ov_table_view ov
         where ov.bobj_num = t.obj#
         and bitand(t.property, 128) = 128)
   from   tab$ t, ind$ st 
   where bitand(t.property,64+512) = 64
    and t.pctused$ = st.obj#
/

