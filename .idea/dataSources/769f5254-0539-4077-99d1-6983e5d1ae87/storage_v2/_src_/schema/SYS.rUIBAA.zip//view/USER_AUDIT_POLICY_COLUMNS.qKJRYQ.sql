create view USER_AUDIT_POLICY_COLUMNS (OBJECT_SCHEMA, OBJECT_NAME, POLICY_NAME, POLICY_COLUMN) as
select OBJECT_SCHEMA, OBJECT_NAME,
          POLICY_NAME, POLICY_COLUMN
from DBA_AUDIT_POLICY_COLUMNS
WHERE OBJECT_SCHEMA = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_AUDIT_POLICY_COLUMNS is 'Users fine grained auditing policy columns in the database'
/

comment on column USER_AUDIT_POLICY_COLUMNS.OBJECT_SCHEMA is 'Owner of the table or view'
/

comment on column USER_AUDIT_POLICY_COLUMNS.OBJECT_NAME is 'Object on which the policy is created'
/

comment on column USER_AUDIT_POLICY_COLUMNS.POLICY_NAME is 'Name of the Fine Grain Audit policy'
/

comment on column USER_AUDIT_POLICY_COLUMNS.POLICY_COLUMN is 'Audit relevant column of the policy'
/

