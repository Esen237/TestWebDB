create view USER_XS_SECURITY_CLASS_DEP (SECURITY_CLASS, PARENT, PARENT_OWNER) as
select security_class, parent, parent_owner from sys.dba_xs_security_class_dep
where owner = sys_context('USERENV','CURRENT_USER')
/

comment on table USER_XS_SECURITY_CLASS_DEP is 'All the Real Application Security class dependencies of the security classes
that are owned by the current user'
/

comment on column USER_XS_SECURITY_CLASS_DEP.SECURITY_CLASS is 'Name of the security class'
/

comment on column USER_XS_SECURITY_CLASS_DEP.PARENT is 'Name of the parent security class'
/

comment on column USER_XS_SECURITY_CLASS_DEP.PARENT_OWNER is 'Owner of the parent security class'
/

