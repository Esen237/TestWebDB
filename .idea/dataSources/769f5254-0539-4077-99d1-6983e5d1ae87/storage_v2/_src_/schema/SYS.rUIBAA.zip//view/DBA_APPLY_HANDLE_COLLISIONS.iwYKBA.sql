create view DBA_APPLY_HANDLE_COLLISIONS
            (APPLY_NAME, OBJECT_OWNER, OBJECT_NAME, SOURCE_OBJECT_OWNER, SOURCE_OBJECT_NAME, ENABLED, SET_BY) as
select
  apply_name, schema_name, table_name, source_schema_name, source_table_name,
  handle_collisions,
  decode(set_by, NULL,'USER',
                 1   ,'GOLDENGATE')
from sys."_DBA_APPLY_HANDLE_COLLISIONS"
/

comment on table DBA_APPLY_HANDLE_COLLISIONS is 'Details about apply collision handlers'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.APPLY_NAME is 'Name of the apply process'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.OBJECT_OWNER is 'Owner of the target object'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.OBJECT_NAME is 'Name of the target object'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_OWNER is 'Owner of the source object'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.SOURCE_OBJECT_NAME is 'Name of the source object'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.ENABLED is 'State of the collision handlers'
/

comment on column DBA_APPLY_HANDLE_COLLISIONS.SET_BY is 'Entity that set up the handler: USER, GOLDENGATE'
/

