create view CDB_ANALYTIC_VIEW_CLASS
            (OWNER, ANALYTIC_VIEW_NAME, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM, ORIGIN_CON_ID, CON_ID) as
SELECT k."OWNER",k."ANALYTIC_VIEW_NAME",k."CLASSIFICATION",k."VALUE",k."LANGUAGE",k."ORDER_NUM",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ANALYTIC_VIEW_CLASS") k
/

comment on table CDB_ANALYTIC_VIEW_CLASS is 'Analytic View Classifications in the database in all containers'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.OWNER is 'Owner of the analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.ANALYTIC_VIEW_NAME is 'analytic view name of owning analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.CLASSIFICATION is 'Name of analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.VALUE is 'Value of analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.LANGUAGE is 'Language of analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.ORDER_NUM is 'Order number of analytic view classification'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column CDB_ANALYTIC_VIEW_CLASS.CON_ID is 'container id'
/

