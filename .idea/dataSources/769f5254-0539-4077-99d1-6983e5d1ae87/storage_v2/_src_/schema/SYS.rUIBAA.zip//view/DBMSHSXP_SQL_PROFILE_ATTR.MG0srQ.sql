create view DBMSHSXP_SQL_PROFILE_ATTR (PROFILE_NAME, COMP_DATA) as
select so.name, od.comp_data
from  sqlobj$ so,
      sqlobj$data od
where so.signature = od.signature and
      so.category = od.category and
      so.obj_type = 1 and
      od.obj_type = 1
/

