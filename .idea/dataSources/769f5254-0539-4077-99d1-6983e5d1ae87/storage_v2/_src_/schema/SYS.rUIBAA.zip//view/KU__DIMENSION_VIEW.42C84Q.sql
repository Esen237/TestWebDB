create view KU$_DIMENSION_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, DIMTEXTLEN, DIMTEXT) as
select '1','0',
         d.obj#, value(o),
         d.dimtextlen,
         sys.dbms_metadata_util.long2clob(d.dimtextlen,
                                        'SYS.DIM$',
                                        'DIMTEXT',
                                        d.rowid)
  from sys.ku$_schemaobj_view o, sys.dim$ d
  where d.obj# = o.obj_num  AND
         (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                         WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

