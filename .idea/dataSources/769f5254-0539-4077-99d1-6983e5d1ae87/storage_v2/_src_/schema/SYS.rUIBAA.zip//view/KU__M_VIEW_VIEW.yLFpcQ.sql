create view KU$_M_VIEW_VIEW
            (VERS_MAJOR, VERS_MINOR, OIDVAL, SOWNER, VNAME, TNAME, MOWNER, MASTER, MLINK, DFLCOLLNAME, BASE_OBJ_NUM,
             SNAPSHOT, SNAPID, AUTO_FAST, AUTO_FUN, AUTO_DATE, USLOG, STATUS, MASTER_VERSION, TABLES, FLAG, FLAG2,
             FLAG3, LOBMASKVEC, MAS_ROLL_SEG, RSCN, INSTSITE, FLAVOR_ID, OBJFLAG, SNA_TYPE_OWNER, SNA_TYPE_NAME,
             MAS_TYPE_OWNER, MAS_TYPE_NAME, PARENT_SOWNER, PARENT_VNAME, QUERY_LEN, QUERY_TXT, PARSED_QUERY_TXT,
             QUERY_VCNT, REL_QUERY, LOC_ROLL_SEG, GLOBAL_DB_NAME, SYN_COUNT, SRT_LIST, MFLAGS, XPFLAGS, XPFLAGS2,
             ZMAPSCALE, EVALEDITION_NUM, UNUSABLEBEF_NUM, UNUSABLEBEG_NUM)
as
select * from ku$_m_view_view_base b
  where  bitand(b.flag2,33554432) != 33554432
    and (bitand(b.flag3, 512) = 0       /* snapshot != zonemap */
     or bitand(b.xpflags2, 8) = 0)      /* summary != zonemap */
     and(((
     case
         when  nvl(b.unusablebef_num,0) = 0 then (0)
	 else   dbms_editions_utilities.compare_edition(
               dbms_metadata.get_edition_id, b.unusablebef_num)
	 end) in (0,2) )
      and((
      case
	   when nvl(b.unusablebeg_num,0) = 0 then (1)
	   else dbms_editions_utilities.compare_edition(
	        dbms_metadata.get_edition_id, b.unusablebeg_num)
      end) = 1  ))
/

