create view ROLE_SYS_PRIVS (ROLE, PRIVILEGE, ADMIN_OPTION, COMMON, INHERITED) as
select u.name,spm.name,decode(min(mod(option$, 2)),1,'YES','NO'), 'NO', 'NO'
from  sys.user$ u, sys.system_privilege_map spm, sys.sysauth$ sa
where grantee# in
   (select /*+ index(sa I_SYSAUTH1) */ distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
  and u.user#=sa.grantee# and sa.privilege#=spm.privilege
  and bitand(nvl(option$, 0), 4) = 0
group by u.name, spm.name
union all
/* Commonly granted Privileges */
select u.name,spm.name,decode(min(bitand(option$,16)),16,'YES','NO'), 'YES',
       decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES')
from  sys.user$ u, sys.system_privilege_map spm, sys.sysauth$ sa
where grantee# in
   (select /*+ index(sa I_SYSAUTH1) */ distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
  and u.user#=sa.grantee# and sa.privilege#=spm.privilege
  and bitand(option$,8) = 8
group by u.name, spm.name
union all
/* Federationally granted Privileges */
select u.name,spm.name,decode(min(bitand(option$,128)),128,'YES','NO'),
       'YES',
       decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'), 'YES', 'YES', 'NO')
from  sys.user$ u, sys.system_privilege_map spm, sys.sysauth$ sa
where grantee# in
   (select /*+ index(sa I_SYSAUTH1) */ distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
  and u.user#=sa.grantee# and sa.privilege#=spm.privilege
  and bitand(option$,64) = 64
group by u.name, spm.name
/

comment on table ROLE_SYS_PRIVS is 'System privileges granted to roles'
/

comment on column ROLE_SYS_PRIVS.ROLE is 'Role name'
/

comment on column ROLE_SYS_PRIVS.PRIVILEGE is 'System Privilege'
/

comment on column ROLE_SYS_PRIVS.ADMIN_OPTION is 'Grant was with the ADMIN option'
/

comment on column ROLE_SYS_PRIVS.COMMON is 'Privilege was granted commonly'
/

comment on column ROLE_SYS_PRIVS.INHERITED is 'Was privilege grant inherited from another container'
/

