create view AWR_PDB_DLM_MISC (SNAP_ID, DBID, INSTANCE_NUMBER, STATISTIC#, NAME, VALUE, CON_DBID, CON_ID) as
select dlm.snap_id, dlm.dbid, dlm.instance_number,
       statistic#, name, value,
       decode(dlm.con_dbid, 0, dlm.dbid, dlm.con_dbid),
       decode(dlm.per_pdb, 0, 0,
         con_dbid_to_id(decode(dlm.con_dbid, 0, dlm.dbid, dlm.con_dbid))) con_id
  from AWR_PDB_SNAPSHOT sn, WRH$_DLM_MISC dlm
  where     sn.snap_id         = dlm.snap_id
        and sn.dbid            = dlm.dbid
        and sn.instance_number = dlm.instance_number
/

comment on table AWR_PDB_DLM_MISC is 'Distributed Lock Manager Miscellaneous Historical Statistics Information'
/

