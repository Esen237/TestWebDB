create view DBA_DB_LINKS (OWNER, DB_LINK, USERNAME, HOST, CREATED, HIDDEN, SHARD_INTERNAL, VALID, INTRA_CDB) as
select u.name, l.name, l.userid, l.host, l.ctime,
       decode(bitand(l.flag, 4), 4, 'YES', 'NO'),
       decode(bitand(l.flag, 8), 8, 'YES', 'NO'),
       decode(bitand(l.flag, 16), 16, 'NO', 'YES'),
       decode(bitand(l.flag, 32), 32, 'YES', 'NO')
from sys.link$ l, sys.user$ u
where l.owner# = u.user#
/

comment on table DBA_DB_LINKS is 'All database links in the database'
/

comment on column DBA_DB_LINKS.DB_LINK is 'Name of the database link'
/

comment on column DBA_DB_LINKS.USERNAME is 'Name of user to log on as'
/

comment on column DBA_DB_LINKS.HOST is 'SQL*Net string for connect'
/

comment on column DBA_DB_LINKS.CREATED is 'Creation time of the database link'
/

comment on column DBA_DB_LINKS.HIDDEN is 'Whether database link is hidden or not'
/

comment on column DBA_DB_LINKS.SHARD_INTERNAL is 'Whether database link is internally managed for sharding'
/

comment on column DBA_DB_LINKS.VALID is 'Whether database link is usable or not'
/

comment on column DBA_DB_LINKS.INTRA_CDB is 'Whether database link is intra-CDB or not'
/

