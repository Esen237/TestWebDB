create view KU$_DUMMY_DV_AUTH_DP_V (VERS_MAJOR, VERS_MINOR, GRANTEE_NAME) as
select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

