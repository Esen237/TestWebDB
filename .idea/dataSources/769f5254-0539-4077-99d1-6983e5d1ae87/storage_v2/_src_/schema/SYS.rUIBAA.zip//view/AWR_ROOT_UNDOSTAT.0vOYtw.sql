create view AWR_ROOT_UNDOSTAT
            (BEGIN_TIME, END_TIME, DBID, INSTANCE_NUMBER, SNAP_ID, UNDOTSN, UNDOBLKS, TXNCOUNT, MAXQUERYLEN,
             MAXQUERYSQLID, MAXCONCURRENCY, UNXPSTEALCNT, UNXPBLKRELCNT, UNXPBLKREUCNT, EXPSTEALCNT, EXPBLKRELCNT,
             EXPBLKREUCNT, SSOLDERRCNT, NOSPACEERRCNT, ACTIVEBLKS, UNEXPIREDBLKS, EXPIREDBLKS, TUNED_UNDORETENTION,
             CON_DBID, CON_ID)
as
select begin_time, end_time, ud.dbid, ud.instance_number,
       ud.snap_id, undotsn,
       undoblks, txncount, maxquerylen, maxquerysqlid,
       maxconcurrency, unxpstealcnt, unxpblkrelcnt, unxpblkreucnt,
       expstealcnt, expblkrelcnt, expblkreucnt, ssolderrcnt,
       nospaceerrcnt, activeblks, unexpiredblks, expiredblks,
       tuned_undoretention,
       decode(ud.con_dbid, 0, ud.dbid, ud.con_dbid),
       decode(ud.per_pdb, 0, 0,
         con_dbid_to_id(decode(ud.con_dbid, 0, ud.dbid, ud.con_dbid))) con_id
  from AWR_ROOT_SNAPSHOT sn, WRH$_UNDOSTAT ud
  where     sn.snap_id         = ud.snap_id
        and sn.dbid            = ud.dbid
        and sn.instance_number = ud.instance_number
/

comment on table AWR_ROOT_UNDOSTAT is 'Undo Historical Statistics Information'
/

