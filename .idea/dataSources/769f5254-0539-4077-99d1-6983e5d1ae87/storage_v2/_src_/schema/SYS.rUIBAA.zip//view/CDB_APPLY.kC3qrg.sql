create view CDB_APPLY
            (APPLY_NAME, QUEUE_NAME, QUEUE_OWNER, APPLY_CAPTURED, RULE_SET_NAME, RULE_SET_OWNER, APPLY_USER,
             APPLY_DATABASE_LINK, APPLY_TAG, DDL_HANDLER, PRECOMMIT_HANDLER, MESSAGE_HANDLER, STATUS,
             MAX_APPLIED_MESSAGE_NUMBER, NEGATIVE_RULE_SET_NAME, NEGATIVE_RULE_SET_OWNER, STATUS_CHANGE_TIME,
             ERROR_NUMBER, ERROR_MESSAGE, MESSAGE_DELIVERY_MODE, PURPOSE, LCRID_VERSION, CON_ID)
as
SELECT k."APPLY_NAME",k."QUEUE_NAME",k."QUEUE_OWNER",k."APPLY_CAPTURED",k."RULE_SET_NAME",k."RULE_SET_OWNER",k."APPLY_USER",k."APPLY_DATABASE_LINK",k."APPLY_TAG",k."DDL_HANDLER",k."PRECOMMIT_HANDLER",k."MESSAGE_HANDLER",k."STATUS",k."MAX_APPLIED_MESSAGE_NUMBER",k."NEGATIVE_RULE_SET_NAME",k."NEGATIVE_RULE_SET_OWNER",k."STATUS_CHANGE_TIME",k."ERROR_NUMBER",k."ERROR_MESSAGE",k."MESSAGE_DELIVERY_MODE",k."PURPOSE",k."LCRID_VERSION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY") k
/

comment on table CDB_APPLY is 'Details about the apply process in all containers'
/

comment on column CDB_APPLY.APPLY_NAME is 'Name of the apply process'
/

comment on column CDB_APPLY.QUEUE_NAME is 'Name of the queue the apply process dequeues from'
/

comment on column CDB_APPLY.QUEUE_OWNER is 'Owner of the queue the apply process dequeues from'
/

comment on column CDB_APPLY.APPLY_CAPTURED is 'Yes, if applying captured messages; No, if applying enqueued messages'
/

comment on column CDB_APPLY.RULE_SET_NAME is 'Rule set used by apply process for filtering'
/

comment on column CDB_APPLY.RULE_SET_OWNER is 'Owner of the negative rule set'
/

comment on column CDB_APPLY.APPLY_USER is 'Current user who is applying the messages'
/

comment on column CDB_APPLY.APPLY_DATABASE_LINK is 'For remote objects, the database link pointing to the remote database'
/

comment on column CDB_APPLY.APPLY_TAG is 'Tag associated with DDL and DML change records that will be applied'
/

comment on column CDB_APPLY.DDL_HANDLER is 'Name of the user specified ddl handler'
/

comment on column CDB_APPLY.PRECOMMIT_HANDLER is 'Name of the user specified precommit handler'
/

comment on column CDB_APPLY.MESSAGE_HANDLER is 'User specified procedure to handle messages other than DDL and DML messages'
/

comment on column CDB_APPLY.STATUS is 'Status of the apply process: DISABLED, ENABLED, ABORTED'
/

comment on column CDB_APPLY.MAX_APPLIED_MESSAGE_NUMBER is 'Maximum value of message that has been applied'
/

comment on column CDB_APPLY.NEGATIVE_RULE_SET_NAME is 'Negative rule set used by apply process for filtering'
/

comment on column CDB_APPLY.STATUS_CHANGE_TIME is 'The time that STATUS of the apply process was changed'
/

comment on column CDB_APPLY.ERROR_NUMBER is 'Error number if the apply process was aborted'
/

comment on column CDB_APPLY.ERROR_MESSAGE is 'Error message if the apply process was aborted'
/

comment on column CDB_APPLY.PURPOSE is 'Purpose of this apply process '
/

comment on column CDB_APPLY.LCRID_VERSION is 'LCRID format currently being used'
/

comment on column CDB_APPLY.CON_ID is 'container id'
/

