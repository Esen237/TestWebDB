create view CDB_OBJECTS
            (OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE, CREATED, LAST_DDL_TIME,
             TIMESTAMP, STATUS, TEMPORARY, GENERATED, SECONDARY, NAMESPACE, EDITION_NAME, SHARING, EDITIONABLE,
             ORACLE_MAINTAINED, APPLICATION, DEFAULT_COLLATION, DUPLICATED, SHARDED, CREATED_APPID, CREATED_VSNID,
             MODIFIED_APPID, MODIFIED_VSNID, CON_ID)
as
SELECT k."OWNER",k."OBJECT_NAME",k."SUBOBJECT_NAME",k."OBJECT_ID",k."DATA_OBJECT_ID",k."OBJECT_TYPE",k."CREATED",k."LAST_DDL_TIME",k."TIMESTAMP",k."STATUS",k."TEMPORARY",k."GENERATED",k."SECONDARY",k."NAMESPACE",k."EDITION_NAME",k."SHARING",k."EDITIONABLE",k."ORACLE_MAINTAINED",k."APPLICATION",k."DEFAULT_COLLATION",k."DUPLICATED",k."SHARDED",k."CREATED_APPID",k."CREATED_VSNID",k."MODIFIED_APPID",k."MODIFIED_VSNID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_OBJECTS") k
/

comment on table CDB_OBJECTS is 'All objects in the database in all containers'
/

comment on column CDB_OBJECTS.OWNER is 'Username of the owner of the object'
/

comment on column CDB_OBJECTS.OBJECT_NAME is 'Name of the object'
/

comment on column CDB_OBJECTS.SUBOBJECT_NAME is 'Name of the sub-object (for example, partititon)'
/

comment on column CDB_OBJECTS.OBJECT_ID is 'Object number of the object'
/

comment on column CDB_OBJECTS.DATA_OBJECT_ID is 'Object number of the segment which contains the object'
/

comment on column CDB_OBJECTS.OBJECT_TYPE is 'Type of the object'
/

comment on column CDB_OBJECTS.CREATED is 'Timestamp for the creation of the object'
/

comment on column CDB_OBJECTS.LAST_DDL_TIME is 'Timestamp for the last DDL change (including GRANT and REVOKE) to the object'
/

comment on column CDB_OBJECTS.TIMESTAMP is 'Timestamp for the specification of the object'
/

comment on column CDB_OBJECTS.STATUS is 'Status of the object'
/

comment on column CDB_OBJECTS.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column CDB_OBJECTS.GENERATED is 'Was the name of this object system generated?'
/

comment on column CDB_OBJECTS.SECONDARY is 'Is this a secondary object created as part of icreate for domain indexes?'
/

comment on column CDB_OBJECTS.NAMESPACE is 'Namespace for the object'
/

comment on column CDB_OBJECTS.EDITION_NAME is 'Name of the edition in which the object is actual'
/

comment on column CDB_OBJECTS.SHARING is 'Is this a Metadata Link, an Object Link or neither?'
/

comment on column CDB_OBJECTS.EDITIONABLE is 'Object is considered editionable'
/

comment on column CDB_OBJECTS.ORACLE_MAINTAINED is 'Denotes whether the object was created, and is maintained, by Oracle-supplied scripts. An object for which this has the value Y must not be changed in any way except by running an Oracle-supplied script.'
/

comment on column CDB_OBJECTS.APPLICATION is 'Denotes whether the object is part of an Application Container.'
/

comment on column CDB_OBJECTS.DEFAULT_COLLATION is 'Default collation for the object'
/

comment on column CDB_OBJECTS.CREATED_APPID is 'ID of Application that created object'
/

comment on column CDB_OBJECTS.CREATED_VSNID is 'ID of Application Version that created object'
/

comment on column CDB_OBJECTS.MODIFIED_APPID is 'ID of Application that last modified object'
/

comment on column CDB_OBJECTS.MODIFIED_VSNID is 'ID of Application Version that last modified object'
/

comment on column CDB_OBJECTS.CON_ID is 'container id'
/

