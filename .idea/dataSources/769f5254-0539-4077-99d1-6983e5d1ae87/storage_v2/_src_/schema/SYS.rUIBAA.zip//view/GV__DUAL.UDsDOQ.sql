create view GV_$DUAL (INST_ID, DUMMY, CON_ID) as
select "INST_ID","DUMMY","CON_ID" from gv$dual
/

