create view CDB_ILMTASKS (TASK_ID, TASK_OWNER, STATE, CREATION_TIME, START_TIME, COMPLETION_TIME, CON_ID) as
SELECT k."TASK_ID",k."TASK_OWNER",k."STATE",k."CREATION_TIME",k."START_TIME",k."COMPLETION_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ILMTASKS") k
/

comment on table CDB_ILMTASKS is 'Information on ILM execution in all containers'
/

comment on column CDB_ILMTASKS.TASK_ID is 'Number that uniquely identifies a specific ILM execution'
/

comment on column CDB_ILMTASKS.TASK_OWNER is 'Owner of the specific ILM execution'
/

comment on column CDB_ILMTASKS.STATE is 'State of the ILM task'
/

comment on column CDB_ILMTASKS.CREATION_TIME is 'Creation time of the ILM task'
/

comment on column CDB_ILMTASKS.START_TIME is 'Time of start of a specific ILM execution'
/

comment on column CDB_ILMTASKS.CON_ID is 'container id'
/

