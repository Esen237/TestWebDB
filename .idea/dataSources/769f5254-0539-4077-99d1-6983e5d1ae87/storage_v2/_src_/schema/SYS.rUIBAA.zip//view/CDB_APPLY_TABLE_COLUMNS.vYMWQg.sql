create view CDB_APPLY_TABLE_COLUMNS
            (OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, COMPARE_OLD_ON_DELETE, COMPARE_OLD_ON_UPDATE, APPLY_DATABASE_LINK,
             CON_ID) as
SELECT k."OBJECT_OWNER",k."OBJECT_NAME",k."COLUMN_NAME",k."COMPARE_OLD_ON_DELETE",k."COMPARE_OLD_ON_UPDATE",k."APPLY_DATABASE_LINK",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_APPLY_TABLE_COLUMNS") k
/

comment on table CDB_APPLY_TABLE_COLUMNS is 'Details about the destination table columns in all containers'
/

comment on column CDB_APPLY_TABLE_COLUMNS.OBJECT_OWNER is 'Owner of the table'
/

comment on column CDB_APPLY_TABLE_COLUMNS.OBJECT_NAME is 'Name of the table'
/

comment on column CDB_APPLY_TABLE_COLUMNS.COLUMN_NAME is 'Name of column'
/

comment on column CDB_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_DELETE is 'Compare old value of column on deletes'
/

comment on column CDB_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_UPDATE is 'Compare old value of column on updates'
/

comment on column CDB_APPLY_TABLE_COLUMNS.APPLY_DATABASE_LINK is 'For remote table, name of database link pointing to remote database'
/

comment on column CDB_APPLY_TABLE_COLUMNS.CON_ID is 'container id'
/

