create view KU$_VIEWPROP_VIEW (OBJ_NUM, NAME, SCHEMA, PROPERTY, DFLCOLLNAME) as
select o.obj#, o.name, u.name, bitand(v.property, (power(2, 32)-1)),
        nls_collation_name(nvl(o.dflcollid, 16382))
 from obj$ o, user$ u, view$ v
 where o.owner# = u.user#
 and   o.obj#   = v.obj#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                         WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

