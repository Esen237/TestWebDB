create view DBA_HIVE_TABLES
            (CLUSTER_ID, DATABASE_NAME, TABLE_NAME, LOCATION, NO_OF_COLS, CREATION_TIME, LAST_ACCESSED_TIME, OWNER,
             TABLE_TYPE, PARTITIONED, NO_OF_PART_KEYS, INPUT_FORMAT, OUTPUT_FORMAT, SERIALIZATION, COMPRESSED, HIVE_URI)
as
SELECT HT.C15 AS CLUSTER_ID,
       HT.C0 AS DATABASE_NAME,
       HT.C1 AS TABLE_NAME,
       HT.C5 AS LOCATION,
       HT.C6 AS NO_OF_COLS,
       DBMS_HADOOP_INTERNAL.UNIX_TS_TO_DATE(HT.C8) AS CREATION_TIME,
       DBMS_HADOOP_INTERNAL.UNIX_TS_TO_DATE(HT.C9) AS LAST_ACCESSED_TIME,
       HT.C2 AS OWNER,
       HT.C3 AS TABLE_TYPE,
       HT.C10 AS PARTITIONED,
       HT.C7 AS NO_OF_PART_KEYS,
       HT.C11 AS INPUT_FORMAT,
       HT.C12 AS OUTPUT_FORMAT,
       HT.C13 AS SERIALIZATION,
       HT.C14 AS COMPRESSED,
       HT.C16 AS HIVE_URI
  FROM
    (SELECT DIRECTORY_PATH AS configDir
     FROM DBA_DIRECTORIES
     WHERE UPPER(DIRECTORY_NAME) = 'ORACLE_BIGDATA_CONFIG') HU,
    (SELECT DIRECTORY_PATH AS debugDir
     FROM DBA_DIRECTORIES
     WHERE UPPER(DIRECTORY_NAME) = 'ORACLE_BIGDATA_DEBUG'
     UNION ALL
     SELECT 'InvalidDir' FROM DUAL WHERE
           NOT EXISTS (SELECT DIRECTORY_PATH AS debugDir
                       FROM DBA_DIRECTORIES
                       WHERE UPPER(DIRECTORY_NAME) = 'ORACLE_BIGDATA_DEBUG')
    ) HV,
     LATERAL(SELECT * FROM
         TABLE(DBMS_HADOOP_INTERNAL.GetHiveTable(HU.configDir, HV.debugDir, '*', '*', '*', 'TRUE', 1))) HT
/

comment on table DBA_HIVE_TABLES is 'All hive tables in the given database'
/

comment on column DBA_HIVE_TABLES.CLUSTER_ID is 'Hadoop cluster name'
/

comment on column DBA_HIVE_TABLES.DATABASE_NAME is 'Database where hive table resides'
/

comment on column DBA_HIVE_TABLES.TABLE_NAME is 'Hive table name'
/

comment on column DBA_HIVE_TABLES.LOCATION is 'Physical location of the hive table'
/

comment on column DBA_HIVE_TABLES.NO_OF_COLS is 'Number of columns in the hive table'
/

comment on column DBA_HIVE_TABLES.CREATION_TIME is 'Creation time of the hive table'
/

comment on column DBA_HIVE_TABLES.LAST_ACCESSED_TIME is 'Last accessed time of hive table'
/

comment on column DBA_HIVE_TABLES.OWNER is 'Owner of hive table'
/

comment on column DBA_HIVE_TABLES.TABLE_TYPE is 'Type of hive table'
/

comment on column DBA_HIVE_TABLES.PARTITIONED is 'Is this hive table partitioned?'
/

comment on column DBA_HIVE_TABLES.NO_OF_PART_KEYS is 'No of partition keys in hive table'
/

comment on column DBA_HIVE_TABLES.INPUT_FORMAT is 'Hive table input format'
/

comment on column DBA_HIVE_TABLES.OUTPUT_FORMAT is 'Hive table output format'
/

comment on column DBA_HIVE_TABLES.SERIALIZATION is 'Hive table serialization'
/

comment on column DBA_HIVE_TABLES.COMPRESSED is 'Is this hive table compressed?'
/

