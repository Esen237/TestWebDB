create view DBA_APPLY_PROGRESS
            (APPLY_NAME, SOURCE_DATABASE, APPLIED_MESSAGE_NUMBER, OLDEST_MESSAGE_NUMBER, APPLY_TIME,
             APPLIED_MESSAGE_CREATE_TIME, OLDEST_TRANSACTION_ID, SPILL_MESSAGE_NUMBER, SOURCE_ROOT_NAME)
as
select ap.apply_name, am.source_db_name,
       am.commit_scn,
       am.oldest_scn,
       apply_time,
       am.applied_message_create_time,
       oldest_transaction_id,
       spill_lwm_scn,
       am.source_root_name
  from streams$_apply_process ap, "_DBA_APPLY_MILESTONE" am,
        sys.xstream$_server xs
 where ap.apply# = am.apply#
   and ap.apply_name = xs.server_name (+)
/

comment on table DBA_APPLY_PROGRESS is 'Information about the progress made by apply process'
/

comment on column DBA_APPLY_PROGRESS.APPLY_NAME is 'Name of the apply process'
/

comment on column DBA_APPLY_PROGRESS.SOURCE_DATABASE is 'Applying messages originating from this database'
/

comment on column DBA_APPLY_PROGRESS.APPLIED_MESSAGE_NUMBER is 'All messages before this number have been successfully applied'
/

comment on column DBA_APPLY_PROGRESS.OLDEST_MESSAGE_NUMBER is 'Earliest commit number of the transactions currently being applied'
/

comment on column DBA_APPLY_PROGRESS.APPLY_TIME is 'Time at which the message was applied'
/

comment on column DBA_APPLY_PROGRESS.APPLIED_MESSAGE_CREATE_TIME is 'Time at which the message to be applied was created'
/

comment on column DBA_APPLY_PROGRESS.OLDEST_TRANSACTION_ID is 'Earliest transaction id currently being applied'
/

comment on column DBA_APPLY_PROGRESS.SPILL_MESSAGE_NUMBER is 'Spill low water mark SCN'
/

comment on column DBA_APPLY_PROGRESS.SOURCE_ROOT_NAME is 'Global name of the source root database'
/

