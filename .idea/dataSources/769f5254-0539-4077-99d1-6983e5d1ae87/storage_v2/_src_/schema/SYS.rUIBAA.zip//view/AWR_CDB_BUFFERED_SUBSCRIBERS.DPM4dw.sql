create view AWR_CDB_BUFFERED_SUBSCRIBERS
            (SNAP_ID, DBID, INSTANCE_NUMBER, QUEUE_SCHEMA, QUEUE_NAME, SUBSCRIBER_ID, SUBSCRIBER_NAME,
             SUBSCRIBER_ADDRESS, SUBSCRIBER_TYPE, STARTUP_TIME, LAST_BROWSED_SEQ, LAST_BROWSED_NUM, LAST_DEQUEUED_SEQ,
             LAST_DEQUEUED_NUM, CURRENT_ENQ_SEQ, NUM_MSGS, CNUM_MSGS, TOTAL_DEQUEUED_MSG, TOTAL_SPILLED_MSG,
             EXPIRED_MSGS, MESSAGE_LAG, ELAPSED_DEQUEUE_TIME, DEQUEUE_CPU_TIME, LAST_DEQUEUE_TIME, OLDEST_MSGID,
             OLDEST_MSG_ENQTM, CON_DBID, CON_ID)
as
select ss.snap_id, ss.dbid, ss.instance_number, ss.queue_schema, ss.queue_name,
       ss.subscriber_id, ss.subscriber_name, ss.subscriber_address,
       ss.subscriber_type, ss.startup_time, ss.last_browsed_seq,
       ss.last_browsed_num, ss.last_dequeued_seq, ss.last_dequeued_num,
       ss.current_enq_seq, ss.num_msgs, ss.cnum_msgs,
       ss.total_dequeued_msg, ss.total_spilled_msg, ss.expired_msgs,
       ss.message_lag, ss.elapsed_dequeue_time, ss.dequeue_cpu_time,
       ss.last_dequeue_time, ss.oldest_msgid, ss.oldest_msg_enqtm,
       decode(ss.con_dbid, 0, ss.dbid, ss.con_dbid),
       decode(ss.per_pdb, 0, 0,
         con_dbid_to_id(decode(ss.con_dbid, 0, ss.dbid, ss.con_dbid))) con_id
  from wrh$_buffered_subscribers ss, AWR_CDB_SNAPSHOT sn
  where     sn.snap_id          = ss.snap_id
        and sn.dbid             = ss.dbid
        and sn.instance_number  = ss.instance_number
/

comment on table AWR_CDB_BUFFERED_SUBSCRIBERS is 'STREAMS Buffered Queue Subscribers Historical Statistics Information'
/

