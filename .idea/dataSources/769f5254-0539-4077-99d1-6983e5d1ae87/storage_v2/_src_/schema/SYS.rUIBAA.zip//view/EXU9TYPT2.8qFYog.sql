create view EXU9TYPT2
            (TNAME, TOWNER, OWNERID, TOID, MTIME, TYPOBJNO, TABOBJNO, AUDIT$, SQLVER, PROPERTY, TYPOBJSTATUS, TVERSION,
             THASHCODE, SYNOBJNO, COLSYNOBJNO)
as
SELECT  o.name, u.name, o.owner#, t.toid,
                TO_CHAR(o.mtime, 'YYYY-MM-DD:HH24:MI:SS'), o.obj#, c.obj#,
                tm.audit$, sv.sql_version, t.properties,
                o.status, t.version#, t.hashcode, c.synobj#, c.synobj#
        FROM    sys.coltype$ c, sys.user$ u, sys.obj$ o, sys.type$ t,
                sys.type_misc$ tm, sys.exu816sqv sv
        WHERE   t.toid = c.toid AND
                o.oid$ = c.toid AND
                u.user# = o.owner# AND
                o.obj# = tm.obj# AND
                BITAND(t.properties, 2128) = 0 AND /* skip system gen'd types*/
                NVL(o.type#, -1) != 10 AND
                t.toid  = t.tvoid AND                    /* Latest type only */
                o.spare1 = sv.version# (+)
/

