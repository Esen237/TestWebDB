create view KU$_TAB_SUBPART_COL_VIEW (OBJ_NUM, INTCOL_NUM, COL, POS_NUM, SPARE1) as
select sc.obj#, sc.intcol#, value(c), sc.pos#, sc.spare1
  from ku$_simple_col_view c, subpartcol$ sc
  where  sc.obj#=c.obj_num
  and    sc.intcol#=c.intcol_num
/

