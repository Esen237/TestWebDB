create view DBA_SEGMENTS
            (OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, SEGMENT_SUBTYPE, TABLESPACE_NAME, HEADER_FILE,
             HEADER_BLOCK, BYTES, BLOCKS, EXTENTS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, MAX_SIZE,
             RETENTION, MINRETENTION, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, RELATIVE_FNO, BUFFER_POOL, FLASH_CACHE,
             CELL_FLASH_CACHE, INMEMORY, INMEMORY_PRIORITY, INMEMORY_DISTRIBUTE, INMEMORY_DUPLICATE,
             INMEMORY_COMPRESSION, CELLMEMORY)
as
select owner, segment_name, partition_name, segment_type,
       segment_subtype, tablespace_name,
       header_file, header_block,
       decode(bitand(segment_flags, 131072), 131072, blocks,
           (decode(bitand(segment_flags,1),1,
            dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
            header_block, segment_type_id, buffer_pool_id, segment_flags,
            segment_objd, blocks), blocks)))*blocksize,
       decode(bitand(segment_flags, 131072), 131072, blocks,
           (decode(bitand(segment_flags,1),1,
            dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
            header_block, segment_type_id, buffer_pool_id, segment_flags,
            segment_objd, blocks), blocks))),
       decode(bitand(segment_flags, 131072), 131072, extents,
           (decode(bitand(segment_flags,1),1,
           dbms_space_admin.segment_number_extents(tablespace_id, relative_fno,
           header_block, segment_type_id, buffer_pool_id, segment_flags,
           segment_objd, extents) , extents))),
       initial_extent, next_extent, min_extents, max_extents, max_size,
       retention, minretention,
       pct_increase, freelists, freelist_groups, relative_fno,
       decode(buffer_pool_id, 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(flash_cache, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(cell_flash_cache, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       -- INMEMORY
       decode (bitand(segment_flags, 4294967296),
                          4294967296, 'ENABLED', 'DISABLED'),
       -- INMEMORY_PRIORITY
       decode(bitand(segment_flags, 4294967296), 4294967296,
                decode(bitand(segment_flags, 34359738368), 34359738368,
                decode(bitand(segment_flags, 61572651155456),
                8796093022208, 'LOW',
                17592186044416, 'MEDIUM',
                35184372088832, 'HIGH',
                52776558133248, 'CRITICAL', 'NONE'),
                'NONE'),
                null),
       -- INMEMORY_DISTRIBUTE
       decode(bitand(segment_flags, 4294967296), 4294967296,
                decode(bitand(segment_flags, 8589934592), 8589934592,
                        decode(bitand(segment_flags, 206158430208),
                        68719476736,   'BY ROWID RANGE',
                        137438953472,  'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        'UNKNOWN'),
                  null),
       -- INMEMORY_DUPLICATE
       decode(bitand(segment_flags, 4294967296), 4294967296,
                   decode(bitand(segment_flags, 6597069766656),
                           2199023255552, 'NO DUPLICATE',
                           4398046511104, 'DUPLICATE',
                           6597069766656, 'DUPLICATE ALL', 'UNKNOWN'),
                 null),
       -- INMEMORY_COMPRESSSION
       decode(bitand(segment_flags, 4294967296), 4294967296,
                decode(bitand(segment_flags, 841813590016),
                              17179869184,  'NO MEMCOMPRESS',
                              274877906944, 'FOR DML',
                              292057776128, 'FOR QUERY LOW',
                              549755813888, 'FOR QUERY HIGH',
                              566935683072, 'FOR CAPACITY LOW',
                              824633720832, 'FOR CAPACITY HIGH', 'UNKNOWN'),
                 null),
       decode(bitand(segment_flags, 4362862139015168),
            281474976710656, 'DISABLED',
            703687441776640, 'NO MEMCOMPRESS',
           1266637395197952, 'MEMCOMPRESS FOR QUERY',
           2392537302040576, 'MEMCOMPRESS FOR CAPACITY', null)
from sys_dba_segs
/

comment on table DBA_SEGMENTS is 'Storage allocated for all database segments'
/

comment on column DBA_SEGMENTS.OWNER is 'Username of the segment owner'
/

comment on column DBA_SEGMENTS.SEGMENT_NAME is 'Name, if any, of the segment'
/

comment on column DBA_SEGMENTS.PARTITION_NAME is 'Partition/Subpartition Name, if any, of the segment'
/

comment on column DBA_SEGMENTS.SEGMENT_TYPE is 'Type of segment:  "TABLE", "CLUSTER", "INDEX", "ROLLBACK",
"DEFERRED ROLLBACK", "TEMPORARY","SPACE HEADER", "TYPE2 UNDO"
 or "CACHE"'
/

comment on column DBA_SEGMENTS.SEGMENT_SUBTYPE is 'SubType of Lob segment:  "SECUREFILE", "ASSM", "MSSM", NULL'
/

comment on column DBA_SEGMENTS.TABLESPACE_NAME is 'Name of the tablespace containing the segment'
/

comment on column DBA_SEGMENTS.HEADER_FILE is 'ID of the file containing the segment header'
/

comment on column DBA_SEGMENTS.HEADER_BLOCK is 'ID of the block containing the segment header'
/

comment on column DBA_SEGMENTS.BYTES is 'Size, in bytes, of the segment'
/

comment on column DBA_SEGMENTS.BLOCKS is 'Size, in Oracle blocks, of the segment'
/

comment on column DBA_SEGMENTS.EXTENTS is 'Number of extents allocated to the segment'
/

comment on column DBA_SEGMENTS.INITIAL_EXTENT is 'Size, in bytes, of the initial extent of the segment'
/

comment on column DBA_SEGMENTS.NEXT_EXTENT is 'Size, in bytes, of the next extent to be allocated to the segment'
/

comment on column DBA_SEGMENTS.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS.MAX_SIZE is 'Maximum number of blocks allowed in the segment'
/

comment on column DBA_SEGMENTS.RETENTION is 'Retention option for SECUREFILE segment'
/

comment on column DBA_SEGMENTS.MINRETENTION is 'Minimum Retention Duration for SECUREFILE segment'
/

comment on column DBA_SEGMENTS.PCT_INCREASE is 'Percent by which to increase the size of the next extent to be allocated'
/

comment on column DBA_SEGMENTS.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column DBA_SEGMENTS.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column DBA_SEGMENTS.RELATIVE_FNO is 'Relative number of the file containing the segment header'
/

comment on column DBA_SEGMENTS.BUFFER_POOL is 'The default buffer pool to be used for segments blocks'
/

comment on column DBA_SEGMENTS.INMEMORY is 'Whether in-memory is enabled or not'
/

comment on column DBA_SEGMENTS.INMEMORY_PRIORITY is 'User defined priority in which in-memory column store object is loaded'
/

comment on column DBA_SEGMENTS.INMEMORY_DISTRIBUTE is 'How the in-memory columnar store object is distributed'
/

comment on column DBA_SEGMENTS.INMEMORY_DUPLICATE is 'How the in-memory column store object is duplicated'
/

comment on column DBA_SEGMENTS.INMEMORY_COMPRESSION is 'Compression level for the in-memory column store option'
/

comment on column DBA_SEGMENTS.CELLMEMORY is 'Cell columnar cache'
/

