create view ALL_SCHEDULER_CHAIN_STEPS
            (OWNER, CHAIN_NAME, STEP_NAME, PROGRAM_OWNER, PROGRAM_NAME, EVENT_SCHEDULE_OWNER, EVENT_SCHEDULE_NAME,
             EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, CREDENTIAL_OWNER, CREDENTIAL_NAME,
             DESTINATION, SKIP, PAUSE, PAUSE_BEFORE, RESTART_ON_RECOVERY, RESTART_ON_FAILURE, STEP_TYPE, TIMEOUT)
as
SELECT u.name, o.name, cs.var_name,
  DECODE(BITAND(cs.flags,4), 4,
    substrb(cs.object_name,1,instrb(cs.object_name,'"')-1), NULL),
  DECODE(BITAND(cs.flags,4), 4,
    substrb(cs.object_name,instrb(cs.object_name,'"')+1,
      lengthb(cs.object_name)-instrb(cs.object_name,'"')), NULL),
  DECODE(BITAND(cs.flags,8), 8,
    substrb(cs.object_name,1,instrb(cs.object_name,'"')-1), NULL),
  DECODE(BITAND(cs.flags,8), 8,
    substrb(cs.object_name,instrb(cs.object_name,'"')+1,
      lengthb(cs.object_name)-instrb(cs.object_name,'"')), NULL),
  cs.queue_owner, cs.queue_name, cs.queue_agent, cs.condition,
  cs.credential_owner, cs.credential_name, cs.destination,
  DECODE(BITAND(cs.flags,1),0,'FALSE',1,'TRUE'),
  DECODE(BITAND(cs.flags,2),0,'FALSE',2,'TRUE'),
  DECODE(BITAND(cs.flags,512),0,'FALSE',512,'TRUE'),
  DECODE(BITAND(cs.flags,64),0,'FALSE',64,'TRUE'),
  DECODE(BITAND(cs.flags,128),0,'FALSE',128,'TRUE'),
  DECODE(BITAND(cs.flags,8+16+32+1024+2048),8,'EVENT_SCHEDULE',16,'INLINE_EVENT',
  32,'SUBCHAIN',1040,'INLINE_FILE_WATCHER', 2056, 'FILE_WATCHER_SCHEDULE',
  'PROGRAM'), cs.timeout
  FROM obj$ o, user$ u, sys.scheduler$_step cs
  WHERE cs.oid = o.obj# AND u.user# = o.owner# AND
    (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         (exists (select null from v$enabledprivs
                 where priv_number in (-265 /* CREATE ANY JOB */,
                                       -266 /* EXECUTE ANY PROGRAM */ )
                 )
          and o.owner#!=0)
      )
/

comment on table ALL_SCHEDULER_CHAIN_STEPS is 'All steps of scheduler chains visible to the current user'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.OWNER is 'Owner of the scheduler chain the step is in'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.CHAIN_NAME is 'Name of the scheduler chain the step is in'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.STEP_NAME is 'Name of the chain step'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.PROGRAM_OWNER is 'Owner of the program that runs during this step'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.PROGRAM_NAME is 'Name of the program that runs during this step'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_SCHEDULE_OWNER is 'Owner of the event schedule that this step waits for'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_SCHEDULE_NAME is 'Name of the event schedule that this step waits for'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_QUEUE_OWNER is 'Owner of source queue into which event will be raised'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_QUEUE_NAME is 'Name of source queue into which event will be raised'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_QUEUE_AGENT is 'Name of AQ agent used by user on the event source queue (for a secure queue)'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.EVENT_CONDITION is 'Boolean expression used as the subscription rule for event on the source queue'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.CREDENTIAL_OWNER is 'Owner of the credential to be used for an external step job'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.CREDENTIAL_NAME is 'Name of the credential to be used for an external step job'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.DESTINATION is 'Destination host on which a remote step job will run'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.SKIP is 'Whether this step should be skipped or not'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.PAUSE is 'Whether this step should be paused after running or not'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.PAUSE_BEFORE is 'Whether this step should be paused before running or not'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.RESTART_ON_RECOVERY is 'Whether this step should be restarted on database recovery'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.RESTART_ON_FAILURE is 'Whether this step should be retried on application failure'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.STEP_TYPE is 'Type of this step'
/

comment on column ALL_SCHEDULER_CHAIN_STEPS.TIMEOUT is 'Timeout for waiting on an event schedule'
/

