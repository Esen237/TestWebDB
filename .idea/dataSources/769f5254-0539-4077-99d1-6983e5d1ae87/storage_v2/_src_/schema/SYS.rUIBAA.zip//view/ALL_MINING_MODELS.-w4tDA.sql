create view ALL_MINING_MODELS
            (OWNER, MODEL_NAME, MINING_FUNCTION, ALGORITHM, ALGORITHM_TYPE, CREATION_DATE, BUILD_DURATION, MODEL_SIZE,
             PARTITIONED, COMMENTS)
as
select u.name, o.name,
       cast(decode(func, /* Mining Function */
              1, 'CLASSIFICATION',
              2, 'REGRESSION',
              3, 'CLUSTERING',
              4, 'FEATURE_EXTRACTION',
              5, 'ASSOCIATION_RULES',
              6, 'ATTRIBUTE_IMPORTANCE', /*7 reserved for anomaly */
              8, 'TIME_SERIES',
                 'UNDEFINED') as varchar2(30)),
       cast(decode(alg, /* Mining Algorithm */
              1, 'NAIVE_BAYES',
              2, 'ADAPTIVE_BAYES_NETWORK',
              3, 'DECISION_TREE',
              4, 'SUPPORT_VECTOR_MACHINES',
              5, 'KMEANS',
              6, 'O_CLUSTER',
              7, 'NONNEGATIVE_MATRIX_FACTOR',
              8, 'GENERALIZED_LINEAR_MODEL',
              9, 'APRIORI_ASSOCIATION_RULES',
             10, 'MINIMUM_DESCRIPTION_LENGTH',
             11, 'SINGULAR_VALUE_DECOMP',
             12, 'EXPECTATION_MAXIMIZATION',
             13,  NVL(s.value, 'R_EXTENSIBLE'),
             14, 'EXPLICIT_SEMANTIC_ANALYS',
             15, 'RANDOM_FOREST',
             16, 'NEURAL_NETWORK',
             17, 'EXPONENTIAL_SMOOTHING',
             18, 'CUR_DECOMPOSITION',
                 'UNDEFINED') as varchar2(30)),
       cast(decode(alg, 13, 'R', 'NATIVE') as varchar2(10)),
       o.ctime, bdur, msize,
       decode(bitand(m.properties,1),1,'YES','NO'), c.comment$
from sys.model$ m, sys.obj$ o, sys.user$ u, sys.com$ c,
         (select mod#, value from sys.modelset$
          where bitand(properties,2) != 2 and name = 'ALGO_NAME') s
where o.obj#=m.obj#
  and o.obj#=c.obj#(+)
  and o.type#=82
  and o.owner#=u.user#
  and o.obj#=s.mod#(+)
  and (o.owner#=userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
/

comment on table ALL_MINING_MODELS is 'Description of the models accessible to the user'
/

comment on column ALL_MINING_MODELS.MODEL_NAME is 'Name of the model'
/

comment on column ALL_MINING_MODELS.MINING_FUNCTION is 'Mining function of the model'
/

comment on column ALL_MINING_MODELS.ALGORITHM is 'Algorithm of the model'
/

comment on column ALL_MINING_MODELS.ALGORITHM_TYPE is 'Algorithm type of the model'
/

comment on column ALL_MINING_MODELS.CREATION_DATE is 'Creation date of the model'
/

comment on column ALL_MINING_MODELS.BUILD_DURATION is 'Model build time (in seconds)'
/

comment on column ALL_MINING_MODELS.MODEL_SIZE is 'Model size (in Mb)'
/

comment on column ALL_MINING_MODELS.COMMENTS is 'Model comments'
/

