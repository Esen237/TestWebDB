create view GV_$GOLDENGATE_CAPABILITIES (INST_ID, NAME, COUNT, LAST_USED, CON_ID) as
select "INST_ID","NAME","COUNT","LAST_USED","CON_ID" from gv$goldengate_capabilities
/

