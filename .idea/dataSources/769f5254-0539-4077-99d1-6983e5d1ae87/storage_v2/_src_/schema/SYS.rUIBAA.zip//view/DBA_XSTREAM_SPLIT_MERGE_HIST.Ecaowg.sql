create view DBA_XSTREAM_SPLIT_MERGE_HIST
            (ORIGINAL_CAPTURE_NAME, CLONED_CAPTURE_NAME, ORIGINAL_QUEUE_OWNER, ORIGINAL_QUEUE_NAME, CLONED_QUEUE_OWNER,
             CLONED_QUEUE_NAME, ORIGINAL_CAPTURE_STATUS, CLONED_CAPTURE_STATUS, ORIGINAL_XSTREAM_NAME,
             CLONED_XSTREAM_NAME, XSTREAM_TYPE, RECOVERABLE_SCRIPT_ID, SCRIPT_STATUS, ACTION_TYPE, ACTION_THRESHOLD,
             STATUS, STATUS_UPDATE_TIME, CREATION_TIME, LAG, JOB_OWNER, JOB_NAME, ERROR_NUMBER, ERROR_MESSAGE)
as
select
   original_capture_name,    cloned_capture_name,
   original_queue_owner,     original_queue_name,
   cloned_queue_owner,       cloned_queue_name,
   original_capture_status,  cloned_capture_status,
   original_streams_name original_xstream_name,
   cloned_streams_name  cloned_xstream_name,
   streams_type xstream_type,
   recoverable_script_id,    script_status,
   action_type,              action_threshold,
   status,                   status_update_time,
   creation_time,
   lag,
   job_owner,                job_name,
   error_number,             error_message
from "_DBA_SXGG_SPLIT_MERGE_HIST"
where purpose = 'XStream Out'
/

comment on table DBA_XSTREAM_SPLIT_MERGE_HIST is 'history view of details of split/merge jobs/status about XStream'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ORIGINAL_CAPTURE_NAME is 'name of the original capture'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CLONED_CAPTURE_NAME is 'name of the cloned capture'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ORIGINAL_QUEUE_OWNER is 'name of original queue owner'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ORIGINAL_QUEUE_NAME is 'name of original queue'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CLONED_QUEUE_OWNER is 'name of cloned queue owner'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CLONED_QUEUE_NAME is 'name of cloned queue'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ORIGINAL_CAPTURE_STATUS is 'status of the original capture'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CLONED_CAPTURE_STATUS is 'status of the cloned capture'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ORIGINAL_XSTREAM_NAME is 'name of original XStream (propagation or local apply)'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CLONED_XSTREAM_NAME is 'name of cloned XStream (propagation or local apply)'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.XSTREAM_TYPE is 'type of XStream (propagation or local apply)'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.RECOVERABLE_SCRIPT_ID is 'unique oid of the script to split or merge XStream'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.SCRIPT_STATUS is 'status of the script to split or merge XStream'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ACTION_TYPE is 'type of action performed on this XStream (either split or merge)'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ACTION_THRESHOLD is 'value of split_threshold or merge_threshold'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.STATUS is 'status of XStream'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.STATUS_UPDATE_TIME is 'time when status was last updated'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.CREATION_TIME is 'time when this row was created'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.LAG is 'the time in seconds that the cloned capture lags behind the original capture'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.JOB_OWNER is 'name of the owner of the job'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.JOB_NAME is 'name of the job to split or merge XStream'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ERROR_NUMBER is 'Error number if the capture process was aborted'
/

comment on column DBA_XSTREAM_SPLIT_MERGE_HIST.ERROR_MESSAGE is 'Error message if the capture process was aborted'
/

