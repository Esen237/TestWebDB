create view KU$_QUEUE_TABLE_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, STORAGE_CLAUSE, UDATA_TYPE, OBJECT_TYPE, SORT_COLS, FLAGS,
             TABLE_COMMENT, PRIMARY_INSTANCE, SECONDARY_INSTANCE, OWNER_INSTANCE)
as
select '1','1',
          t.objno,
          (select value(qo) from  sys.ku$_schemaobj_view qo where
             qo.obj_num=t.objno),
          (select value(s) from sys.ku$_qtab_storage_view s where
             s.obj_num = t.objno),
          t.udata_type,
         (select u.name || '.' || o.name
            from sys.ku$_schemaobj_view o, sys.user$ u,
                 sys.col$ c, sys.coltype$ ct
             where c.intcol# = ct.intcol#
                and c.obj# = ct.obj#
                and c.name = 'USER_DATA'
                and t.objno = c.obj#
                and o.oid = ct.toid
                and o.type_num = 13
                and o.owner_num = u.user#),
         t.sort_cols,
         bitand(t.flags, (power(2, 32)-1)),
         t.table_comment,
         aft.primary_instance,
         aft.secondary_instance,
         aft.owner_instance
  from   system.aq$_queue_tables t,
         sys.aq$_queue_table_affinities aft
  where  t.objno = aft.table_objno
  and    (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0
          OR EXISTS (SELECT * FROM sys.session_roles
                     WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

