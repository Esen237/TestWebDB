create view AWR_CDB_SHARED_SERVER_SUMMARY
            (SNAP_ID, DBID, INSTANCE_NUMBER, NUM_SAMPLES, SAMPLE_TIME, SAMPLED_TOTAL_CONN, SAMPLED_ACTIVE_CONN,
             SAMPLED_TOTAL_SRV, SAMPLED_ACTIVE_SRV, SAMPLED_TOTAL_DISP, SAMPLED_ACTIVE_DISP, SRV_BUSY, SRV_IDLE,
             SRV_IN_NET, SRV_OUT_NET, SRV_MESSAGES, SRV_BYTES, CQ_WAIT, CQ_TOTALQ, DQ_TOTALQ, CON_DBID, CON_ID)
as
select
  sn.snap_id, sn.dbid, sn.instance_number,
  s.num_samples, s.sample_time,
  s.sampled_total_conn, s.sampled_active_conn,
  s.sampled_total_srv, s.sampled_active_srv,
  s.sampled_total_disp, s.sampled_active_disp,
  s.srv_busy, s.srv_idle, s.srv_in_net, s.srv_out_net,
  s.srv_messages, s.srv_bytes,
  s.cq_wait, s.cq_totalq,
  s.dq_totalq,
  decode(s.con_dbid, 0, s.dbid, s.con_dbid),
  decode(s.per_pdb, 0, 0,
    con_dbid_to_id(decode(s.con_dbid, 0, s.dbid, s.con_dbid))) con_id
from AWR_CDB_SNAPSHOT sn, WRH$_SHARED_SERVER_SUMMARY s
where     sn.snap_id         = s.snap_id
      and sn.dbid            = s.dbid
      and sn.instance_number = s.instance_number
/

comment on table AWR_CDB_SHARED_SERVER_SUMMARY is 'Shared Server summary statistics'
/

