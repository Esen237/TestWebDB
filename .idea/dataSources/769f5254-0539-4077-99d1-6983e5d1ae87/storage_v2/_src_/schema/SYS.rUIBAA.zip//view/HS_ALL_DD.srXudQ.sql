create view HS_ALL_DD
            (DD_TABLE_NAME, TRANSLATION_TYPE, TRANSLATION_TEXT, FDS_CLASS_NAME, FDS_INST_NAME, DD_TABLE_DESC) as
select bd.dd_table_name, id.translation_type, id.translation_text,
  fc.fds_class_name, fi.fds_inst_name, bd.dd_table_desc
from hs$_inst_dd id, hs$_base_dd bd, hs$_fds_inst fi, hs$_fds_class fc
where id.fds_inst_id = fi.fds_inst_id
and id.dd_table_id = bd.dd_table_id
and fc.fds_class_id = fi.fds_class_id
union
/*clause for the class level minus the inst level*/
select bd2.dd_table_name, cd.translation_type, cd.translation_text,
  fc2.fds_class_name, fi2.fds_inst_name, bd2.dd_table_desc
from hs$_class_dd cd, hs$_base_dd bd2, hs$_fds_inst fi2, hs$_fds_class fc2
where cd.fds_class_id = fi2.fds_class_id
and cd.dd_table_id = bd2.dd_table_id
and fc2.fds_class_id = fi2.fds_class_id
and not exists
  (select 1 from hs$_inst_dd id2
   where id2.dd_table_id = cd.dd_table_id
   and id2.fds_inst_id = fi2.fds_inst_id)
union
/*clause for the base level minus the class and inst levels*/
select bd.dd_table_name,NULL,NULL,fc.fds_class_name,fi.fds_inst_name,
  bd.dd_table_desc
from hs$_base_dd bd, hs$_fds_class fc, hs$_fds_inst fi
where fi.fds_class_id = fc.fds_class_id
and not exists
  (select 1 from hs$_class_dd cd2
   where cd2.dd_table_id = bd.dd_table_id
   and cd2.fds_class_id = fc.fds_class_id)
and not exists
  (select 1 from hs$_inst_dd id2
   where id2.dd_table_id = bd.dd_table_id
   and id2.fds_inst_id = fi.fds_inst_id)
/

