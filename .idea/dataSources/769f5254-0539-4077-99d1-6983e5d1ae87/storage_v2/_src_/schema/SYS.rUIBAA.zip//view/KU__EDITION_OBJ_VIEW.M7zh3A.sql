create view KU$_EDITION_OBJ_VIEW
            (OBJ#, DATAOBJ#, DEFINING_OWNER#, NAME, NAMESPACE, SUBNAME, TYPE#, CTIME, MTIME, STIME, STATUS, REMOTEOWNER,
             LINKNAME, FLAGS, OID$, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6, SIGNATURE, SPARE7, SPARE8, SPARE9,
             DFLCOLLID, CREAPPID, CREVERID, CREPATCHID, MODAPPID, MODVERID, MODPATCHID, SPARE10, SPARE11, SPARE12,
             SPARE13, SPARE14, OWNER#, DEFINING_EDITION)
as
select o."OBJ#",o."DATAOBJ#",o."OWNER#",o."NAME",o."NAMESPACE",o."SUBNAME",o."TYPE#",o."CTIME",o."MTIME",o."STIME",o."STATUS",o."REMOTEOWNER",o."LINKNAME",o."FLAGS",o."OID$",o."SPARE1",o."SPARE2",o."SPARE3",o."SPARE4",o."SPARE5",o."SPARE6",o."SIGNATURE",o."SPARE7",o."SPARE8",o."SPARE9",o."DFLCOLLID",o."CREAPPID",o."CREVERID",o."CREPATCHID",o."MODAPPID",o."MODVERID",o."MODPATCHID",o."SPARE10",o."SPARE11",o."SPARE12",o."SPARE13",o."SPARE14",
  
       o.spare3,
       case when (o.type# not in (select ue.type# from user_editioning$ ue
                                  where ue.user# = o.spare3) or
                  bitand(o.flags, 1048576) = 1048576 or
                  bitand(u.spare1, 16) = 0) then
         null
       when (u.type# = 2) then
        (select eo.name from obj$ eo where eo.obj# = u.spare2)
       else
        'ORA$BASE'
       end
from obj$ o, user$ u
where o.owner# = u.user#
  and (   /* non-versionable object */
          (   (    o.type# not in (select type# from user_editioning$ ue
                                  where ue.user# = o.spare3)
               and o.type# != 88)
           or bitand(o.flags, 1048576) = 1048576
           or bitand(u.spare1, 16) = 0)
          /* versionable object visible in designated edition */
       or (    o.type# in (select ue.type# from user_editioning$ ue
                           where ue.user# = o.spare3)
           and (   (u.type# <> 2 and
                    (select distinct sys.dbms_metadata.get_edition from dual)
                        = 'ORA$BASE')
                or (u.type# = 2 and
                    u.spare2 =
                        (select distinct sys.dbms_metadata.get_edition_id from dual))
                or exists (select 1 from obj$ o2, user$ u2
                           where o2.type# = 88
                             and o2.dataobj# = o.obj#
                             and o2.owner# = u2.user#
                             and u2.type#  = 2
                             and u2.spare2 =
                        (select distinct sys.dbms_metadata.get_edition_id from dual))
               )
          )
      )
/

