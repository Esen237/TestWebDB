create view CDB_GOLDENGATE_RULES
            (COMPONENT_NAME, COMPONENT_TYPE, COMPONENT_RULE_TYPE, RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_TYPE,
             RULE_OWNER, RULE_NAME, RULE_TYPE, RULE_CONDITION, SCHEMA_NAME, OBJECT_NAME, INCLUDE_TAGGED_LCR,
             SUBSETTING_OPERATION, DML_CONDITION, SOURCE_DATABASE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION,
             SOURCE_ROOT_NAME, SOURCE_CONTAINER_NAME, CON_ID)
as
SELECT k."COMPONENT_NAME",k."COMPONENT_TYPE",k."COMPONENT_RULE_TYPE",k."RULE_SET_OWNER",k."RULE_SET_NAME",k."RULE_SET_TYPE",k."RULE_OWNER",k."RULE_NAME",k."RULE_TYPE",k."RULE_CONDITION",k."SCHEMA_NAME",k."OBJECT_NAME",k."INCLUDE_TAGGED_LCR",k."SUBSETTING_OPERATION",k."DML_CONDITION",k."SOURCE_DATABASE",k."ORIGINAL_RULE_CONDITION",k."SAME_RULE_CONDITION",k."SOURCE_ROOT_NAME",k."SOURCE_CONTAINER_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_GOLDENGATE_RULES") k
/

comment on table CDB_GOLDENGATE_RULES is 'Details about the GoldenGate server rules in all containers'
/

comment on column CDB_GOLDENGATE_RULES.COMPONENT_NAME is 'Name of the GoldenGate process'
/

comment on column CDB_GOLDENGATE_RULES.COMPONENT_TYPE is 'Type of the GoldenGate process: CAPTURE or APPLY'
/

comment on column CDB_GOLDENGATE_RULES.COMPONENT_RULE_TYPE is 'For global, schema or table rules, type of rule: TABLE, SCHEMA or GLOBAL'
/

comment on column CDB_GOLDENGATE_RULES.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column CDB_GOLDENGATE_RULES.RULE_SET_NAME is 'Name of the rule set'
/

comment on column CDB_GOLDENGATE_RULES.RULE_SET_TYPE is 'Type of the rule set: POSITIVE or NEGATIVE'
/

comment on column CDB_GOLDENGATE_RULES.RULE_OWNER is 'Owner of the rule'
/

comment on column CDB_GOLDENGATE_RULES.RULE_NAME is 'Name of the rule'
/

comment on column CDB_GOLDENGATE_RULES.RULE_TYPE is 'For global, schema or table rules, type of rule: DML, DDL or PROCEDURE'
/

comment on column CDB_GOLDENGATE_RULES.RULE_CONDITION is 'Current rule condition'
/

comment on column CDB_GOLDENGATE_RULES.SCHEMA_NAME is 'For table and schema rules, the schema name'
/

comment on column CDB_GOLDENGATE_RULES.OBJECT_NAME is 'For table rules, the table name'
/

comment on column CDB_GOLDENGATE_RULES.INCLUDE_TAGGED_LCR is 'For global, schema or table rules, whether or not to include tagged LCRs'
/

comment on column CDB_GOLDENGATE_RULES.SUBSETTING_OPERATION is 'For subset rules, the type of operation: INSERT, UPDATE, or DELETE'
/

comment on column CDB_GOLDENGATE_RULES.DML_CONDITION is 'For subset rules, the row subsetting condition'
/

comment on column CDB_GOLDENGATE_RULES.SOURCE_DATABASE is 'For global, schema or table rules, the name of the database where the LCRs originated'
/

comment on column CDB_GOLDENGATE_RULES.ORIGINAL_RULE_CONDITION is 'For rules created by GoldenGate administrative APIs, the original rule condition when the rule was created'
/

comment on column CDB_GOLDENGATE_RULES.SAME_RULE_CONDITION is 'For rules created by GoldenGate administrative APIs, whether or not the current rule condition is the same as the original rule condition'
/

comment on column CDB_GOLDENGATE_RULES.SOURCE_ROOT_NAME is 'Root Database where the transactions originated'
/

comment on column CDB_GOLDENGATE_RULES.SOURCE_CONTAINER_NAME is 'The short container name of the database where the LCRs originated'
/

comment on column CDB_GOLDENGATE_RULES.CON_ID is 'container id'
/

