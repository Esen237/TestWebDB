create view DBA_AUTO_INDEX_IND_ACTIONS
            (EXECUTION_NAME, ACTION_ID, INDEX_NAME, INDEX_OWNER, TABLE_NAME, TABLE_OWNER, COMMAND, STATEMENT,
             START_TIME, END_TIME, ERROR#)
as
select /*+ opt_param('_optimizer_cartesian_enabled' 'false') */
       a.exec_name    execution_name,
       a.id           action_id,
       o.attr3        index_name,
       o.attr5        index_owner,
       o.attr1        table_name,
       o.attr2        table_owner,
       c.command_name command,
       a.attr5        statement,
       to_date(a.attr1, 'YYYY-MM-DD/HH24:MI:SS' /* AI_TIME_FORMAT */)
         start_time,
       to_date(a.attr2, 'YYYY-MM-DD/HH24:MI:SS' /* AI_TIME_FORMAT */)
         end_time,
       a.num_attr1 error#
from wri$_adv_tasks t, wri$_adv_actions a, wri$_adv_objects o, x$keacmdn c
where t.owner# = 0                   /* AI_TASK_OWNID */
  and t.name = 'SYS_AUTO_INDEX_TASK' /* AI_TASK_NAME */
  and t.id = a.task_id
  and a.task_id = o.task_id
  and a.obj_id = o.id
  and o.type  = 2                    /* AI_KEA_OBJ_INDX */
  and a.command = c.indx
/

