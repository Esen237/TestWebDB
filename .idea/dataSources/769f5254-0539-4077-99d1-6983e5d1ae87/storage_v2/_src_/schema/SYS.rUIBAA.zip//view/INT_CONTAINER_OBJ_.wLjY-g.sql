create view INT$CONTAINER_OBJ$ (NAME, CON_ID) as
select o.name, c.con_id#
  from obj$ o, container$ c
  where o.type# = 111
    and c.obj# = o.obj# (+)
/

