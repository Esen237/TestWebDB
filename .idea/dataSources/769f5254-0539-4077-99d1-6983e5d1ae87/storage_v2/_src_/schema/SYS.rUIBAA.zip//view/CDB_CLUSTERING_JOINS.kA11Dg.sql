create view CDB_CLUSTERING_JOINS
            (OWNER, TABLE_NAME, TAB1_OWNER, TAB1_NAME, TAB1_COLUMN, TAB2_OWNER, TAB2_NAME, TAB2_COLUMN, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."TAB1_OWNER",k."TAB1_NAME",k."TAB1_COLUMN",k."TAB2_OWNER",k."TAB2_NAME",k."TAB2_COLUMN",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CLUSTERING_JOINS") k
/

comment on table CDB_CLUSTERING_JOINS is 'All join details about clustering tables in the database in all containers'
/

comment on column CDB_CLUSTERING_JOINS.OWNER is 'Owner of the clustering table'
/

comment on column CDB_CLUSTERING_JOINS.TABLE_NAME is 'Name of the clustering table'
/

comment on column CDB_CLUSTERING_JOINS.TAB1_OWNER is 'Owner of the first dimension table'
/

comment on column CDB_CLUSTERING_JOINS.TAB1_NAME is 'Name of the first dimension table'
/

comment on column CDB_CLUSTERING_JOINS.TAB1_COLUMN is 'Name of the first dimension table column'
/

comment on column CDB_CLUSTERING_JOINS.TAB2_OWNER is 'Owner of the second dimension table'
/

comment on column CDB_CLUSTERING_JOINS.TAB2_NAME is 'Name of the second dimension table'
/

comment on column CDB_CLUSTERING_JOINS.TAB2_COLUMN is 'Name of the second dimension table column'
/

comment on column CDB_CLUSTERING_JOINS.CON_ID is 'container id'
/

