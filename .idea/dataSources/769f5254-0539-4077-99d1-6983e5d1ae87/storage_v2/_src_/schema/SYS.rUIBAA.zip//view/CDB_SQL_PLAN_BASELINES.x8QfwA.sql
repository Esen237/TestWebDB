create view CDB_SQL_PLAN_BASELINES
            (SIGNATURE, SQL_HANDLE, SQL_TEXT, PLAN_NAME, CREATOR, ORIGIN, PARSING_SCHEMA_NAME, DESCRIPTION, VERSION,
             CREATED, LAST_MODIFIED, LAST_EXECUTED, LAST_VERIFIED, ENABLED, ACCEPTED, FIXED, REPRODUCED, AUTOPURGE,
             ADAPTIVE, OPTIMIZER_COST, MODULE, ACTION, EXECUTIONS, ELAPSED_TIME, CPU_TIME, BUFFER_GETS, DISK_READS,
             DIRECT_WRITES, ROWS_PROCESSED, FETCHES, END_OF_FETCH_COUNT, CON_ID)
as
SELECT k."SIGNATURE",k."SQL_HANDLE",k."SQL_TEXT",k."PLAN_NAME",k."CREATOR",k."ORIGIN",k."PARSING_SCHEMA_NAME",k."DESCRIPTION",k."VERSION",k."CREATED",k."LAST_MODIFIED",k."LAST_EXECUTED",k."LAST_VERIFIED",k."ENABLED",k."ACCEPTED",k."FIXED",k."REPRODUCED",k."AUTOPURGE",k."ADAPTIVE",k."OPTIMIZER_COST",k."MODULE",k."ACTION",k."EXECUTIONS",k."ELAPSED_TIME",k."CPU_TIME",k."BUFFER_GETS",k."DISK_READS",k."DIRECT_WRITES",k."ROWS_PROCESSED",k."FETCHES",k."END_OF_FETCH_COUNT",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_SQL_PLAN_BASELINES") k
/

comment on table CDB_SQL_PLAN_BASELINES is 'set of plan baselines in all containers'
/

comment on column CDB_SQL_PLAN_BASELINES.SIGNATURE is 'unique SQL identifier generated from normalized SQL text'
/

comment on column CDB_SQL_PLAN_BASELINES.SQL_HANDLE is 'unique SQL identifier in string form as a search key'
/

comment on column CDB_SQL_PLAN_BASELINES.SQL_TEXT is 'un-normalized SQL text'
/

comment on column CDB_SQL_PLAN_BASELINES.PLAN_NAME is 'unique plan identifier in string form as a search key'
/

comment on column CDB_SQL_PLAN_BASELINES.CREATOR is 'user who created the plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.ORIGIN is 'how plan baseline was created'
/

comment on column CDB_SQL_PLAN_BASELINES.PARSING_SCHEMA_NAME is 'name of parsing schema'
/

comment on column CDB_SQL_PLAN_BASELINES.DESCRIPTION is 'text description provided for plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.VERSION is 'database version at time of plan baseline creation'
/

comment on column CDB_SQL_PLAN_BASELINES.CREATED is 'time when plan baseline was created'
/

comment on column CDB_SQL_PLAN_BASELINES.LAST_MODIFIED is 'time when plan baseline was last modified'
/

comment on column CDB_SQL_PLAN_BASELINES.LAST_EXECUTED is 'time when plan baseline was last executed'
/

comment on column CDB_SQL_PLAN_BASELINES.LAST_VERIFIED is 'time when plan baseline was last verified'
/

comment on column CDB_SQL_PLAN_BASELINES.ENABLED is 'enabled status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.ACCEPTED is 'accepted status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.FIXED is 'fixed status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.REPRODUCED is 'reproduced status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.AUTOPURGE is 'auto-purge status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.ADAPTIVE is 'adaptive status of plan baseline'
/

comment on column CDB_SQL_PLAN_BASELINES.OPTIMIZER_COST is 'plan baseline optimizer cost'
/

comment on column CDB_SQL_PLAN_BASELINES.MODULE is 'application module name'
/

comment on column CDB_SQL_PLAN_BASELINES.ACTION is 'application action'
/

comment on column CDB_SQL_PLAN_BASELINES.EXECUTIONS is 'number of plan baseline executions'
/

comment on column CDB_SQL_PLAN_BASELINES.ELAPSED_TIME is 'total elapse time'
/

comment on column CDB_SQL_PLAN_BASELINES.CPU_TIME is 'total CPU time'
/

comment on column CDB_SQL_PLAN_BASELINES.BUFFER_GETS is 'total buffer gets'
/

comment on column CDB_SQL_PLAN_BASELINES.DISK_READS is 'total disk reads'
/

comment on column CDB_SQL_PLAN_BASELINES.DIRECT_WRITES is 'total direct writes'
/

comment on column CDB_SQL_PLAN_BASELINES.ROWS_PROCESSED is 'total rows processed'
/

comment on column CDB_SQL_PLAN_BASELINES.FETCHES is 'total number of fetches'
/

comment on column CDB_SQL_PLAN_BASELINES.END_OF_FETCH_COUNT is 'total number of full fetches'
/

comment on column CDB_SQL_PLAN_BASELINES.CON_ID is 'container id'
/

