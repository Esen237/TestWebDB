create view KU$_DEFROLE_LIST_VIEW (USER_ID, USER_NAME, ROLE, ROLE_ID) as
select  d$.user#, u$.name, u1$.name, d$.role#
  from    sys.user$ u$, sys.user$ u1$, sys.defrole$ d$
  where   u$.user# = d$.user# AND
          u1$.user# = d$.role#
/

