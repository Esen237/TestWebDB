create view V_$DIAG_V_INCCOUNT (PROBLEM_ID, INCIDENT_CNT, CON_ID) as
select
   "PROBLEM_ID",
   "INCIDENT_CNT",
   "CON_ID"
  from x$diag_V_INCCOUNT
/

