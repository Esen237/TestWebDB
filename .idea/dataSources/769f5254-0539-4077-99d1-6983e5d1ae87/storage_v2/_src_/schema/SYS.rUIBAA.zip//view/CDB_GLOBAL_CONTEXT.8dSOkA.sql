create view CDB_GLOBAL_CONTEXT (NAMESPACE, SCHEMA, PACKAGE, CON_ID) as
SELECT k."NAMESPACE",k."SCHEMA",k."PACKAGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_GLOBAL_CONTEXT") k
/

comment on table CDB_GLOBAL_CONTEXT is 'Description of all context information accessible globally in all containers'
/

comment on column CDB_GLOBAL_CONTEXT.SCHEMA is 'Schema of the package that administers the globally accessible context'
/

comment on column CDB_GLOBAL_CONTEXT.PACKAGE is 'Package that administers the globally accessible context'
/

comment on column CDB_GLOBAL_CONTEXT.CON_ID is 'container id'
/

