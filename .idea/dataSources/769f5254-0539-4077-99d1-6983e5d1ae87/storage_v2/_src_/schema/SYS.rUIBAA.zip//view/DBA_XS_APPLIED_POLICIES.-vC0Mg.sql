create view DBA_XS_APPLIED_POLICIES
            (SCHEMA, OBJECT, POLICY, POLICY_OWNER, SEL, INS, UPD, DEL, IDX, ROW_ACL, OWNER_BYPASS, STATUS) as
select u.name, o.name, r.pname, r.pfschma,
       decode(bitand(r.stmt_type,1), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,2), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,4), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,8), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,2048), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,16384), 0, 'NO', 'YES'),
       decode(bitand(r.stmt_type,2097152), 0, 'NO', 'YES'),
       decode(r.enable_flag, 0, 'DISABLED', 'ENABLED')
  from sys.user$ u, sys.obj$ o, sys.rls$ r
 where u.user# = o.owner# and r.obj# = o.obj# and
       r.gname = 'SYS_XDS$POLICY_GROUP'
/

comment on table DBA_XS_APPLIED_POLICIES is 'All the database objects on which Real Application Security data security policies are enabled'
/

comment on column DBA_XS_APPLIED_POLICIES.SCHEMA is 'Schema of the object'
/

comment on column DBA_XS_APPLIED_POLICIES.OBJECT is 'Name of the object'
/

comment on column DBA_XS_APPLIED_POLICIES.POLICY is 'Name of the data security policy'
/

comment on column DBA_XS_APPLIED_POLICIES.POLICY_OWNER is 'Owner of the data security policy'
/

comment on column DBA_XS_APPLIED_POLICIES.SEL is 'Policy enabled for SELECT statements'
/

comment on column DBA_XS_APPLIED_POLICIES.INS is 'Policy enabled for INSERT statements'
/

comment on column DBA_XS_APPLIED_POLICIES.UPD is 'Policy enabled for UPDATE statements'
/

comment on column DBA_XS_APPLIED_POLICIES.DEL is 'Policy enabled for DELETE statements'
/

comment on column DBA_XS_APPLIED_POLICIES.IDX is 'Policy enabled for INDEX statements'
/

comment on column DBA_XS_APPLIED_POLICIES.ROW_ACL is 'Object has row ACL column'
/

comment on column DBA_XS_APPLIED_POLICIES.OWNER_BYPASS is 'Policy bypassed by object owner'
/

comment on column DBA_XS_APPLIED_POLICIES.STATUS is 'Indicates whether the data security policy is enabled or disabled'
/

