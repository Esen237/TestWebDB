create view CDB_LOGSTDBY_UNSUPPORTED_TABLE (OWNER, TABLE_NAME, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_LOGSTDBY_UNSUPPORTED_TABLE") k
/

comment on table CDB_LOGSTDBY_UNSUPPORTED_TABLE is 'List of all the data tables that are not supported by Logical Standby in all containers'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED_TABLE.OWNER is 'Schema name of unsupported table'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED_TABLE.TABLE_NAME is 'Table name of unsupported table'
/

comment on column CDB_LOGSTDBY_UNSUPPORTED_TABLE.CON_ID is 'container id'
/

