create view CDB_INMEMORY_AIMTASKDETAILS (TASK_ID, OBJECT_OWNER, OBJECT_NAME, SUBOBJECT_NAME, ACTION, STATE, CON_ID) as
SELECT k."TASK_ID",k."OBJECT_OWNER",k."OBJECT_NAME",k."SUBOBJECT_NAME",k."ACTION",k."STATE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_INMEMORY_AIMTASKDETAILS") k
/

comment on table CDB_INMEMORY_AIMTASKDETAILS is 'Information on details for an automatic inmemory management task in all containers'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.TASK_ID is 'Number that uniquely identifies a specific AIM task'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.OBJECT_OWNER is 'Owner of the object subject to AIM action'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.OBJECT_NAME is 'Name of the object subject to AIM action'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.SUBOBJECT_NAME is 'Name of the subobject subject to AIM action'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.ACTION is 'Action taken on the object'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.STATE is 'Status of the action on the object'
/

comment on column CDB_INMEMORY_AIMTASKDETAILS.CON_ID is 'container id'
/

