create view KU$_M_ZONEMAP_PH_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SOWNER, VNAME, MVIEW, MVIEW_TAB, MVIEW_IDX_LIST) as
select '2','0',
         ot.obj#,
         mvv.sowner,
         mvv.vname,
         value(mvv),
         value(phtv),
         cast(multiset(select value(iv) from sys.ku$_all_index_view iv, sys.ind$ i
                       where i.bo# = ot.obj# and
                             bitand(i.property,8192) = 8192 and
                             iv.obj_num = i.obj#) as ku$_index_list_t)
  from   sys.obj$ ot, sys.user$ u, sys.ku$_phtable_view phtv,
         sys.ku$_m_zonemap_view mvv
  where  ot.name     = mvv.tname
     and ot.owner#   = u.user#
     and u.name      = mvv.sowner
     and ot.type#    = 2
     and phtv.obj_num = ot.obj#
     and BITAND(mvv.flag,33554432) != 33554432
     and (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (ot.owner#, 0) OR
          EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

