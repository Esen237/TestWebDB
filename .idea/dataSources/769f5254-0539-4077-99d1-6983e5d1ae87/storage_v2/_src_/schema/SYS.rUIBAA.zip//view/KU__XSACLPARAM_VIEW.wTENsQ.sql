create view KU$_XSACLPARAM_VIEW
            (VERS_MAJOR, VERS_MINOR, XDSID, POLICY_NAME, POLICY_OWNER, ACLID, NAME, PVALUE1, PVALUE2, TYPE) as
select '1','0',
  ap.xdsid#,
  (select name from xs$obj where id = ap.xdsid#),
  (select owner from xs$obj where id = ap.xdsid#),
  ap.acl#,
  ap.pname,
  ap.pvalue1,
  ap.pvalue2,
  (select type from xs$policy_param p where p.xdsid#=ap.xdsid# and p.pname=ap.pname)
  from xs$acl_param ap
/

