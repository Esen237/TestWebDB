create view USER_XS_ACL_PARAMETERS (POLICY, ACL, ACL_OWNER, PARAMETER, DATATYPE, VALUE, REALM_ORDER, REALM) as
select policy, acl, acl_owner, parameter, datatype, value, realm_order, realm
  from sys.dba_xs_acl_parameters
 where policy_owner = sys_context('USERENV','CURRENT_USER')
/

comment on table USER_XS_ACL_PARAMETERS is 'All the Real Application Security ACL parameters defined in the data security policies owned by the current user'
/

comment on column USER_XS_ACL_PARAMETERS.POLICY is 'Name of the data security policy where the ACL parameter is defined'
/

comment on column USER_XS_ACL_PARAMETERS.ACL is 'Name of the ACL'
/

comment on column USER_XS_ACL_PARAMETERS.ACL_OWNER is 'Owner of the ACL'
/

comment on column USER_XS_ACL_PARAMETERS.PARAMETER is 'Name of the ACL parameter'
/

comment on column USER_XS_ACL_PARAMETERS.DATATYPE is 'Datatype of the ACL parameter'
/

comment on column USER_XS_ACL_PARAMETERS.VALUE is 'Value of the ACL parameter'
/

comment on column USER_XS_ACL_PARAMETERS.REALM_ORDER is 'The order of the realm within the data security policy'
/

comment on column USER_XS_ACL_PARAMETERS.REALM is 'The realm that contains the ACL parameter'
/

