create view KU$_DEFERRED_STG_VIEW
            (OBJ_NUM, PCTFREE_STG, PCTUSED_STG, SIZE_STG, INITIAL_STG, NEXT_STG, MINEXT_STG, MAXEXT_STG, MAXSIZ_STG,
             LOBRET_STG, MINTIM_STG, PCTINC_STG, INITRA_STG, MAXTRA_STG, OPTIMAL_STG, MAXINS_STG, FRLINS_STG, FLAGS_STG,
             BFP_STG, ENC_STG, CMPFLAG_STG, CMPLVL_STG, IMCFLAG_STG, CCFLAG_STG, FLAGS2_STG)
as
select
  obj#          ,                            /* object number */
  pctfree_stg   ,                                  /* PCTFREE */
  pctused_stg   ,                                  /* PCTUSED */
  size_stg      ,                                     /* SIZE */
  initial_stg   ,                                  /* INITIAL */
  next_stg      ,                                     /* NEXT */
  minext_stg    ,                               /* MINEXTENTS */
  maxext_stg    ,                               /* MAXEXTENTS */
  maxsiz_stg    ,                                  /* MAXSIZE */
  lobret_stg    ,                             /* LOBRETENTION */
  mintim_stg    ,                                  /* MIN tim */
  pctinc_stg    ,                              /* PCTINCREASE */
  initra_stg    ,                                 /* INITRANS */
  maxtra_stg    ,                                 /* MAXTRANS */
  optimal_stg   ,                                  /* OPTIMAL */
  decode(maxins_stg,0,1,maxins_stg) ,      /* FREELIST GROUPS */
  decode(frlins_stg,0,1,frlins_stg) ,            /* FREELISTS */
  flags_stg     ,                                    /* flags */
  bfp_stg       ,                              /* BUFFER_POOL */
  enc_stg       ,                               /* encryption */
  cmpflag_stg   ,                         /* compression type */
  cmplvl_stg    ,                        /* compression level */  bitand(imcflag_stg, (power(2, 32)-1)) ,
    bitand(ccflag_stg, (power(2, 32)-1))  ,
    bitand(flags2_stg, (power(2, 32)-1))

 from sys.deferred_stg$
/

