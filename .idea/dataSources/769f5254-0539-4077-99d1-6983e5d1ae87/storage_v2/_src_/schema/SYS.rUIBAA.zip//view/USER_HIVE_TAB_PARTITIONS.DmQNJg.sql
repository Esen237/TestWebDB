create view USER_HIVE_TAB_PARTITIONS
            (CLUSTER_ID, DATABASE_NAME, TABLE_NAME, LOCATION, OWNER, PARTITION_SPECS, PART_SIZE, CREATION_TIME) as
SELECT M."CLUSTER_ID",M."DATABASE_NAME",M."TABLE_NAME",M."LOCATION",M."OWNER",M."PARTITION_SPECS",M."PART_SIZE",M."CREATION_TIME" FROM DBA_HIVE_TAB_PARTITIONS M, SYS.USER$ U
WHERE U.user# = USERENV('SCHEMAID') AND
-- Current user has system privileges
      ((
        ora_check_sys_privilege(U.user#, 2) = 1
       )
       OR
-- If current user is neither SYS nor DBA, then do the following checks
-- User must have read privilege on ORACLE_BIGDATA_CONFIG directory
      (
        DBMS_HADOOP.USER_PRIVILEGED('BDSQL_USER', M.CLUSTER_ID) = 1
      )
     )
/

comment on table USER_HIVE_TAB_PARTITIONS is 'All hive table partitions'
/

comment on column USER_HIVE_TAB_PARTITIONS.CLUSTER_ID is 'Hadoop cluster name'
/

comment on column USER_HIVE_TAB_PARTITIONS.DATABASE_NAME is 'Database where hive table resides'
/

comment on column USER_HIVE_TAB_PARTITIONS.TABLE_NAME is 'Hive table name'
/

comment on column USER_HIVE_TAB_PARTITIONS.LOCATION is 'Physical location of the hive partition'
/

comment on column USER_HIVE_TAB_PARTITIONS.OWNER is 'Owner of hive table'
/

comment on column USER_HIVE_TAB_PARTITIONS.PARTITION_SPECS is 'Spec of the currrent Hive partition'
/

comment on column USER_HIVE_TAB_PARTITIONS.PART_SIZE is 'Partition size in bytes'
/

