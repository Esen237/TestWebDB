create view KU$_SIMPLE_PKREF_COL_VIEW
            (OBJ_NUM, COL_NUM, INTCOL_NUM, SEGCOL_NUM, PROPERTY, PROPERTY2, NAME, ATTRNAME, TYPE_NUM, DEFLENGTH,
             DEFAULT_VAL, DEFAULT_VALC, COL_EXPR, ORG_COLNAME)
as
select c.obj#,
         c.col#,
         c.intcol#,
         c.segcol#,
         bitand(c.property, (power(2, 32)-1)),
         bitand(trunc(c.property / power(2, 32)), (power(2, 32)-1)),
         c2.name,
         (select a.name
          from attrcol$ a
          where a.obj# = c2.obj# and
                a.intcol# = c2.intcol#),
         c.type#,
         c.deflength,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength > 4000
           then null
           else
             sys.dbms_metadata_util.func_index_default(c.deflength,
                                                       c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength <= 4000
           then null
           when c.deflength <= 32000
           then
             sys.dbms_metadata_util.func_index_defaultc(c.deflength,
                                                        c.rowid)
           else
             sys.dbms_metadata_util.long2clob(c.deflength,
                                              'SYS.COL$',
                                              'DEFAULT$',
                                              c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
           then null
           else
            (select sys.dbms_metadata.parse_default(
                                SYS_CONTEXT('USERENV','CURRENT_USERID'),
                                u.name, o.name, c.deflength,c.rowid)
             from obj$ o, user$ u
             where o.obj#=c.obj# and o.owner#=u.user#)
         end,
         NULL
  from  col$ c, col$ c2, ccol$ cc, cdef$ cd, coltype$ ct
  where cc.obj# = c.obj# and
        cc.intcol# = c.intcol# and
        cd.con# = cc.con# and
        ct.obj# = c.obj# and
        ct.col# = c.col# and
        ct.intcols = cd.intcols and
        UTL_RAW.CAST_TO_BINARY_INTEGER(
          SUBSTRB(ct.intcol#s, (cc.pos# * 2 - 1), 2), 3) = c.intcol# and
        c2.obj# = c.obj# and
        c2.intcol# = ct.intcol#
/

