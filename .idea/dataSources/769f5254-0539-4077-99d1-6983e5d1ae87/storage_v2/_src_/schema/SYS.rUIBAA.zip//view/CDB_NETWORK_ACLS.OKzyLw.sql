create view CDB_NETWORK_ACLS (HOST, LOWER_PORT, UPPER_PORT, ACL, ACLID, ACL_OWNER, CON_ID) as
SELECT k."HOST",k."LOWER_PORT",k."UPPER_PORT",k."ACL",k."ACLID",k."ACL_OWNER",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_NETWORK_ACLS") k
/

comment on table CDB_NETWORK_ACLS is 'Access control lists assigned to restrict access to network hosts through PL/SQL network utility packages in all containers'
/

comment on column CDB_NETWORK_ACLS.HOST is 'Network host'
/

comment on column CDB_NETWORK_ACLS.LOWER_PORT is 'Lower bound of the port range'
/

comment on column CDB_NETWORK_ACLS.UPPER_PORT is 'Upper bound of the port range'
/

comment on column CDB_NETWORK_ACLS.ACL is 'The name of the access control list'
/

comment on column CDB_NETWORK_ACLS.ACLID is 'The object ID of the access control list'
/

comment on column CDB_NETWORK_ACLS.ACL_OWNER is 'The owner of the access control list'
/

comment on column CDB_NETWORK_ACLS.CON_ID is 'container id'
/

