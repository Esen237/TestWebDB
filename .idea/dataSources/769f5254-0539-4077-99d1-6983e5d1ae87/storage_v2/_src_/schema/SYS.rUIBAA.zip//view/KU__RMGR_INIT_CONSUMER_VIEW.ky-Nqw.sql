create view KU$_RMGR_INIT_CONSUMER_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_NUM, GRANTEE, GRANTED_GROUP, GRANT_OPTION, DEFSCHCLASS) as
select '1','0',
        ue.user#,
        ue.name, g.name,
        a.option$,
        ue.defschclass
  from sys.user$ ue, sys.resource_consumer_group$ g, sys.objauth$ a,
       sys.dba_rsrc_consumer_group_privs dr
  where a.obj# = g.obj# and a.grantee# = ue.user#
  and   ue.name = dr.grantee
  and   g.name = dr.granted_group
  and   dr.initial_group = 'YES'
/

