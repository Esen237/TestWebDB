create view ALL_EVALUATION_CONTEXT_TABLES
            (EVALUATION_CONTEXT_OWNER, EVALUATION_CONTEXT_NAME, TABLE_ALIAS, TABLE_NAME) as
SELECT /*+ all_rows */
       u.name, o.name, ect.tab_alias, ect.tab_name
FROM   rec_tab$ ect, obj$ o, user$ u
WHERE  ect.ec_obj# = o.obj# and
       (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
        o.obj# in (select oa.obj# from sys.objauth$ oa
                   where grantee# in (select kzsrorol from x$kzsro)) or
       -- bug 20339374,V$ENABLEDPRIVS replaced with
       -- ora_check_sys_privilege operator to protect sys owned object
       ora_check_sys_privilege (o.owner#, o.type#) = 1) and
       o.owner# = u.user#
/

comment on table ALL_EVALUATION_CONTEXT_TABLES is 'tables in all rule evaluation contexts seen by the user'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.EVALUATION_CONTEXT_OWNER is 'Owner of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.TABLE_ALIAS is 'Alias of the table'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.TABLE_NAME is 'Name of the table'
/

