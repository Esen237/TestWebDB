create view DBA_HIST_REPORTS_CONTROL (DBID, EXECUTION_MODE) as
select dbid, decode(execution_mode, 0, 'REGULAR', 1, 'FULL_CAPTURE')
                execution_mode
from wrp$_reports_control
/

