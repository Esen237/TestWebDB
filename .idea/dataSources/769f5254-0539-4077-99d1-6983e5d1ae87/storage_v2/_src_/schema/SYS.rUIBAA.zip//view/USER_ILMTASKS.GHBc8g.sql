create view USER_ILMTASKS (TASK_ID, STATE, CREATION_TIME, START_TIME, COMPLETION_TIME) as
SELECT a.execution_id,
       DECODE(a.execution_state, 1, 'INACTIVE',
                                 2, 'ACTIVE',
                                 3, 'COMPLETED',
                                 'UNKNOWN'),
       a.creation_time,
       a.start_time,
       a.completion_time
  FROM sys.ilm_execution$ a
 WHERE a.owner = userenv('SCHEMAID')
/

comment on table USER_ILMTASKS is 'Information on ILM execution for a user'
/

comment on column USER_ILMTASKS.TASK_ID is 'Number that uniquely identifies a specific ILM task'
/

comment on column USER_ILMTASKS.STATE is 'State of the ILM task'
/

comment on column USER_ILMTASKS.CREATION_TIME is 'Creation time of the ILM task'
/

comment on column USER_ILMTASKS.START_TIME is 'Time of start of a specific ILM task'
/

comment on column USER_ILMTASKS.COMPLETION_TIME is 'Time of completion of ILM task'
/

