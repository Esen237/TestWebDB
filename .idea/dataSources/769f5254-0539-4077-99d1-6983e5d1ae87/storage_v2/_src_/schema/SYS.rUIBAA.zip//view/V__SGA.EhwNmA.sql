create view V_$SGA (NAME, VALUE, CON_ID) as
select "NAME","VALUE","CON_ID" from v$sga
/

