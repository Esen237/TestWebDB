create view ALL_DIM_LEVELS
            (OWNER, DIMENSION_NAME, LEVEL_NAME, NUM_COLUMNS, DETAILOBJ_OWNER, DETAILOBJ_NAME, SKIP_WHEN_NULL) as
select u.name, o.name, dl.levelname,
       temp.num_col,
       u1.name, o1.name, decode (dl.flags, 1, 'Y', 'N')
from (select dlk.dimobj#, dlk.levelid#, dlk.detailobj#,
             COUNT(*) as num_col
      from sys.dimlevelkey$ dlk
      group by dlk.dimobj#, dlk.levelid#, dlk.detailobj#) temp,
      sys.dimlevel$ dl, sys.obj$ o, sys.user$ u,
      sys.obj$ o1, sys.user$ u1
where dl.dimobj# = o.obj#   and
      o.owner# = u.user#    and
      dl.dimobj# = temp.dimobj# and
      dl.levelid# = temp.levelid# and
      temp.detailobj# = o1.obj# and
      o1.owner# = u1.user# and
      (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         ora_check_sys_privilege(o.owner#, o.type#) = 1
      )
/

comment on table ALL_DIM_LEVELS is 'Description of dimension levels visible to DBA'
/

comment on column ALL_DIM_LEVELS.OWNER is 'Owner of the dimension'
/

comment on column ALL_DIM_LEVELS.DIMENSION_NAME is 'Name of the dimension'
/

comment on column ALL_DIM_LEVELS.LEVEL_NAME is 'Name of the dimension level (unique within a dimension)'
/

comment on column ALL_DIM_LEVELS.NUM_COLUMNS is 'Number of columns in the level definition'
/

comment on column ALL_DIM_LEVELS.DETAILOBJ_OWNER is 'Owner of the detail object that the keys of this level come from'
/

comment on column ALL_DIM_LEVELS.DETAILOBJ_NAME is 'Name of the table that the keys of this level come from'
/

comment on column ALL_DIM_LEVELS.SKIP_WHEN_NULL is 'Is the level declared with SKIP WHEN NULL clause? (Y/N)'
/

