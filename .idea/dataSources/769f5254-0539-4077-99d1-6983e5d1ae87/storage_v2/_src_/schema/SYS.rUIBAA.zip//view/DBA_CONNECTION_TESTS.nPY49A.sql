create view DBA_CONNECTION_TESTS (PREDEFINED, CONNECTION_TEST_TYPE, SQL_CONNECTION_TEST, SERVICE_NAME, ENABLED) as
select decode(predefined, '0','N', '1', 'Y') "PREDEFINED",
       decode(connection_test_type, '0', 'SQL_TEST', '1', 'PING_TEST', '2',
              'ENDREQUEST_TEST') "CONNECTION TEST TYPE",
       SQL_CONNECTION_TEST, service_name,
       decode(enabled, '0', 'N', '1', 'Y')
from sys.connection_tests$
/

comment on table DBA_CONNECTION_TESTS is 'Information about Draining rules'
/

comment on column DBA_CONNECTION_TESTS.PREDEFINED is 'Set if this rule is default'
/

comment on column DBA_CONNECTION_TESTS.CONNECTION_TEST_TYPE is '0:SQL test, 1:Ping test, 2:End Request test'
/

comment on column DBA_CONNECTION_TESTS.SQL_CONNECTION_TEST is 'SQL entry. NA for non-SQL tests'
/

comment on column DBA_CONNECTION_TESTS.SERVICE_NAME is 'Service associated with the SQL/non-SQL test'
/

comment on column DBA_CONNECTION_TESTS.ENABLED is 'True if enabled'
/

