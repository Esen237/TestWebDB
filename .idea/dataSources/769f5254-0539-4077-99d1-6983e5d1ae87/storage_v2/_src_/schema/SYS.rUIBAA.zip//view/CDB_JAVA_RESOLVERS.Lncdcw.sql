create view CDB_JAVA_RESOLVERS (OWNER, NAME, TERM_INDEX, PATTERN, SCHEMA, CON_ID) as
SELECT k."OWNER",k."NAME",k."TERM_INDEX",k."PATTERN",k."SCHEMA",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_JAVA_RESOLVERS") k
/

comment on table CDB_JAVA_RESOLVERS is 'resolver of java class owned by user in all containers'
/

comment on column CDB_JAVA_RESOLVERS.OWNER is 'owner of the java class object'
/

comment on column CDB_JAVA_RESOLVERS.NAME is 'name of the java class object'
/

comment on column CDB_JAVA_RESOLVERS.TERM_INDEX is 'index of the resolver term in this row'
/

comment on column CDB_JAVA_RESOLVERS.PATTERN is 'resolver pattern of the resolver term identified by TERM_INDEX column'
/

comment on column CDB_JAVA_RESOLVERS.SCHEMA is 'resolver schema of the resolver term identified by TERM_INDEX column'
/

comment on column CDB_JAVA_RESOLVERS.CON_ID is 'container id'
/

