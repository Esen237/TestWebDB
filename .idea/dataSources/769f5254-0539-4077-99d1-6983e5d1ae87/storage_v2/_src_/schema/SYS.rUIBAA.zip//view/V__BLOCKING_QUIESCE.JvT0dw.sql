create view V_$BLOCKING_QUIESCE (SID, CON_ID) as
select "SID","CON_ID" from v$blocking_quiesce
/

