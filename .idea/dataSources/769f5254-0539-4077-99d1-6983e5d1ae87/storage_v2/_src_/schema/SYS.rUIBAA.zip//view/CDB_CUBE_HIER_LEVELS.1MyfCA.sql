create view CDB_CUBE_HIER_LEVELS
            (OWNER, DIMENSION_NAME, HIERARCHY_NAME, LEVEL_NAME, HIERARCHY_LEVEL_ID, ORDER_NUM, DESCRIPTION, CON_ID) as
SELECT k."OWNER",k."DIMENSION_NAME",k."HIERARCHY_NAME",k."LEVEL_NAME",k."HIERARCHY_LEVEL_ID",k."ORDER_NUM",k."DESCRIPTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_CUBE_HIER_LEVELS") k
/

comment on table CDB_CUBE_HIER_LEVELS is 'OLAP Hierarchy Levels in the database in all containers'
/

comment on column CDB_CUBE_HIER_LEVELS.OWNER is 'Owner of the OLAP Hierarchy Level'
/

comment on column CDB_CUBE_HIER_LEVELS.DIMENSION_NAME is 'Name of the owning Dimension of the OLAP Hierarchy Level'
/

comment on column CDB_CUBE_HIER_LEVELS.HIERARCHY_NAME is 'Name of the owning Hierarchy of the OLAP Hierarchy Level'
/

comment on column CDB_CUBE_HIER_LEVELS.LEVEL_NAME is 'Name of the OLAP Dimension Level'
/

comment on column CDB_CUBE_HIER_LEVELS.HIERARCHY_LEVEL_ID is 'Dictionary Id of the OLAP Hierarchy Level'
/

comment on column CDB_CUBE_HIER_LEVELS.ORDER_NUM is 'Order number of the OLAP Hierarchy Level within the hierarchy'
/

comment on column CDB_CUBE_HIER_LEVELS.DESCRIPTION is 'Long Description of the OLAP Hierarchy Level'
/

comment on column CDB_CUBE_HIER_LEVELS.CON_ID is 'container id'
/

