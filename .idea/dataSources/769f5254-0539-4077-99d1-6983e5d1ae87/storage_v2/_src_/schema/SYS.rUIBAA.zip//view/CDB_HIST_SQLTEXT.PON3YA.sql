create view CDB_HIST_SQLTEXT (DBID, SQL_ID, SQL_TEXT, COMMAND_TYPE, CON_DBID, CON_ID) as
SELECT k."DBID",k."SQL_ID",k."SQL_TEXT",k."COMMAND_TYPE",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_SQLTEXT") k
/

comment on table CDB_HIST_SQLTEXT is 'SQL Text in all containers'
/

comment on column CDB_HIST_SQLTEXT.CON_ID is 'container id'
/

