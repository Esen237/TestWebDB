create view CDB_DMT_USED_EXTENTS
            (SEGMENT_FILEID, SEGMENT_BLOCK, TABLESPACE_ID, EXTENT_ID, FILEID, BLOCK, LENGTH, CON_ID) as
SELECT k."SEGMENT_FILEID",k."SEGMENT_BLOCK",k."TABLESPACE_ID",k."EXTENT_ID",k."FILEID",k."BLOCK",k."LENGTH",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_DMT_USED_EXTENTS") k
/

comment on table CDB_DMT_USED_EXTENTS is 'All extents in the dictionary managed tablespaces in all containers'
/

comment on column CDB_DMT_USED_EXTENTS.SEGMENT_FILEID is 'File number of segment header of the extent'
/

comment on column CDB_DMT_USED_EXTENTS.SEGMENT_BLOCK is 'Block number of segment header of the extent'
/

comment on column CDB_DMT_USED_EXTENTS.TABLESPACE_ID is 'ID of the tablespace containing the extent'
/

comment on column CDB_DMT_USED_EXTENTS.EXTENT_ID is 'Extent number in the segment'
/

comment on column CDB_DMT_USED_EXTENTS.FILEID is 'File Number of the extent'
/

comment on column CDB_DMT_USED_EXTENTS.BLOCK is 'Starting block number of the extent'
/

comment on column CDB_DMT_USED_EXTENTS.LENGTH is 'Number of blocks in the extent'
/

comment on column CDB_DMT_USED_EXTENTS.CON_ID is 'container id'
/

