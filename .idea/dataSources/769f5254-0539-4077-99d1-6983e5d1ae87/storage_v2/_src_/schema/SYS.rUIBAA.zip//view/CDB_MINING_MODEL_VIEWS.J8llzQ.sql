create view CDB_MINING_MODEL_VIEWS (OWNER, MODEL_NAME, VIEW_NAME, VIEW_TYPE, CON_ID) as
SELECT k."OWNER",k."MODEL_NAME",k."VIEW_NAME",k."VIEW_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_MINING_MODEL_VIEWS") k
/

comment on table CDB_MINING_MODEL_VIEWS is 'Description of all the model views in the database in all containers'
/

comment on column CDB_MINING_MODEL_VIEWS.MODEL_NAME is 'Name of the model to which the model views belongs'
/

comment on column CDB_MINING_MODEL_VIEWS.VIEW_NAME is 'Name of the model view'
/

comment on column CDB_MINING_MODEL_VIEWS.VIEW_TYPE is 'Type of the model view'
/

comment on column CDB_MINING_MODEL_VIEWS.CON_ID is 'container id'
/

