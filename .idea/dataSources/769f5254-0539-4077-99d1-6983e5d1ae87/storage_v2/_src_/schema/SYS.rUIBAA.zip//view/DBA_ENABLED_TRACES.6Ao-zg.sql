create view DBA_ENABLED_TRACES
            (TRACE_TYPE, PRIMARY_ID, QUALIFIER_ID1, QUALIFIER_ID2, WAITS, BINDS, PLAN_STATS, INSTANCE_NAME) as
select decode(trace_type, 1, 'CLIENT_ID', 3, 'SERVICE',
                 4, 'SERVICE_MODULE', 5, 'SERVICE_MODULE_ACTION',
                 6, 'DATABASE', 'UNDEFINED'),
                 primary_id, qualifier_id1, qualifier_id2,
                 decode(bitand(flags,8), 8, 'TRUE', 'FALSE'),
                 decode(bitand(flags,4), 4, 'TRUE', 'FALSE'),
                 decode(bitand(flags,16) + bitand(flags,32),
                        16,'ALL_EXEC',32,'NEVER',0,'FIRST_EXEC'),
                 instance_name
  from WRI$_TRACING_ENABLED
/

comment on table DBA_ENABLED_TRACES is 'Information about enabled SQL traces'
/

comment on column DBA_ENABLED_TRACES.TRACE_TYPE is 'Type of the trace (CLIENT_ID, SERVICE, etc.)'
/

comment on column DBA_ENABLED_TRACES.PRIMARY_ID is 'Primary qualifier (specific Client Identifier or Service name)'
/

comment on column DBA_ENABLED_TRACES.QUALIFIER_ID1 is 'Secondary qualifier (specific MODULE name)'
/

comment on column DBA_ENABLED_TRACES.QUALIFIER_ID2 is 'Additional qualifier (specific ACTION name)'
/

comment on column DBA_ENABLED_TRACES.WAITS is 'TRUE of waits are traced'
/

comment on column DBA_ENABLED_TRACES.BINDS is 'TRUE of binds are traced'
/

comment on column DBA_ENABLED_TRACES.INSTANCE_NAME is 'Instance name for tracing restricted to named instances'
/

