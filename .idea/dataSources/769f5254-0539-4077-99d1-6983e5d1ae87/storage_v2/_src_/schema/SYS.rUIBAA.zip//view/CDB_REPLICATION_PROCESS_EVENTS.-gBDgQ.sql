create view CDB_REPLICATION_PROCESS_EVENTS
            (STREAMS_TYPE, PROCESS_TYPE, STREAMS_NAME, EVENT_NAME, DESCRIPTION, EVENT_TIME, ERROR_NUMBER, ERROR_MESSAGE,
             CON_ID) as
SELECT k."STREAMS_TYPE",k."PROCESS_TYPE",k."STREAMS_NAME",k."EVENT_NAME",k."DESCRIPTION",k."EVENT_TIME",k."ERROR_NUMBER",k."ERROR_MESSAGE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_REPLICATION_PROCESS_EVENTS") k
/

comment on table CDB_REPLICATION_PROCESS_EVENTS is 'Dictionary table for the replication processes events'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.STREAMS_TYPE is 'Streams type: Streams, XStream, GoldenGate'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.PROCESS_TYPE is 'Process type: Capture, Capture server, Apply Coordinator, Apply Server,
Apply Network Receiver, Apply Reader, Apply Hash server.'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.STREAMS_NAME is 'Streams name'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.EVENT_NAME is 'EVENT NAME: START, STOP, ABORT, CREATE, DROP, PARAMETER CHANGE,
 HANDLER CREATE, HANDLER REMOVE'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.DESCRIPTION is 'Event Description'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.EVENT_TIME is 'Time when the event ocurred'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.ERROR_NUMBER is 'Error Number (valid when event is Error)'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.ERROR_MESSAGE is 'Error Message (valid when event is Error)'
/

comment on column CDB_REPLICATION_PROCESS_EVENTS.CON_ID is 'container id'
/

