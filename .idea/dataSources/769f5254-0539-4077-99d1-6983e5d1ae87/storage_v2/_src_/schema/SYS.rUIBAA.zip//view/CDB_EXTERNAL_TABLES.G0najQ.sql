create view CDB_EXTERNAL_TABLES
            (OWNER, TABLE_NAME, TYPE_OWNER, TYPE_NAME, DEFAULT_DIRECTORY_OWNER, DEFAULT_DIRECTORY_NAME, REJECT_LIMIT,
             ACCESS_TYPE, ACCESS_PARAMETERS, PROPERTY, INMEMORY, INMEMORY_COMPRESSION, CON_ID)
as
SELECT k."OWNER",k."TABLE_NAME",k."TYPE_OWNER",k."TYPE_NAME",k."DEFAULT_DIRECTORY_OWNER",k."DEFAULT_DIRECTORY_NAME",k."REJECT_LIMIT",k."ACCESS_TYPE",k."ACCESS_PARAMETERS",k."PROPERTY",k."INMEMORY",k."INMEMORY_COMPRESSION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EXTERNAL_TABLES") k
/

comment on table CDB_EXTERNAL_TABLES is 'Description of the external tables accessible to the DBA in all containers'
/

comment on column CDB_EXTERNAL_TABLES.OWNER is 'Owner of the external table'
/

comment on column CDB_EXTERNAL_TABLES.TABLE_NAME is 'Name of the external table'
/

comment on column CDB_EXTERNAL_TABLES.TYPE_OWNER is 'Owner of the implementation type for the external table access driver'
/

comment on column CDB_EXTERNAL_TABLES.TYPE_NAME is 'Name of the implementation type for the external table access driver'
/

comment on column CDB_EXTERNAL_TABLES.DEFAULT_DIRECTORY_OWNER is 'Owner of the default directory for the external table'
/

comment on column CDB_EXTERNAL_TABLES.DEFAULT_DIRECTORY_NAME is 'Name of the default directory for the external table'
/

comment on column CDB_EXTERNAL_TABLES.REJECT_LIMIT is 'Reject limit for the external table'
/

comment on column CDB_EXTERNAL_TABLES.ACCESS_TYPE is 'Type of access parameters for the external table (CLOB/BLOB)'
/

comment on column CDB_EXTERNAL_TABLES.ACCESS_PARAMETERS is 'Access parameters for the external table'
/

comment on column CDB_EXTERNAL_TABLES.PROPERTY is 'Property of the external table'
/

comment on column CDB_EXTERNAL_TABLES.INMEMORY is 'Whether inmemory is enabled on the external table'
/

comment on column CDB_EXTERNAL_TABLES.INMEMORY_COMPRESSION is 'Compression level for the in-memory column store option'
/

comment on column CDB_EXTERNAL_TABLES.CON_ID is 'container id'
/

