create view ALL_MVIEW_LOGS
            (LOG_OWNER, MASTER, LOG_TABLE, LOG_TRIGGER, ROWIDS, PRIMARY_KEY, OBJECT_ID, FILTER_COLUMNS, SEQUENCE,
             INCLUDE_NEW_VALUES, PURGE_ASYNCHRONOUS, PURGE_DEFERRED, PURGE_START, PURGE_INTERVAL, LAST_PURGE_DATE,
             LAST_PURGE_STATUS, NUM_ROWS_PURGED, COMMIT_SCN_BASED, STAGING_LOG)
as
select s."LOG_OWNER",s."MASTER",s."LOG_TABLE",s."LOG_TRIGGER",s."ROWIDS",s."PRIMARY_KEY",s."OBJECT_ID",s."FILTER_COLUMNS",s."SEQUENCE",s."INCLUDE_NEW_VALUES",s."PURGE_ASYNCHRONOUS",s."PURGE_DEFERRED",s."PURGE_START",s."PURGE_INTERVAL",s."LAST_PURGE_DATE",s."LAST_PURGE_STATUS",s."NUM_ROWS_PURGED",s."COMMIT_SCN_BASED",s."STAGING_LOG" from dba_mview_logs s, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and s.log_table = o.name
  and u.name       = s.log_owner
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
       or /* user has system privileges */
         ora_check_sys_privilege(o.owner#, o.type#) = 1
      )
/

comment on table ALL_MVIEW_LOGS is 'All materialized view logs in the database that the user can see'
/

comment on column ALL_MVIEW_LOGS.LOG_OWNER is 'Owner of the materialized view log'
/

comment on column ALL_MVIEW_LOGS.MASTER is 'Name of the master table which changes are logged'
/

comment on column ALL_MVIEW_LOGS.LOG_TABLE is 'Log table; with  rowids and timestamps of rows which changed in the master'
/

comment on column ALL_MVIEW_LOGS.LOG_TRIGGER is 'An after-row trigger on the master which inserts rows into the log'
/

comment on column ALL_MVIEW_LOGS.ROWIDS is 'If YES, the materialized view log records rowid information'
/

comment on column ALL_MVIEW_LOGS.PRIMARY_KEY is 'If YES, the materialized view log records primary key information'
/

comment on column ALL_MVIEW_LOGS.OBJECT_ID is 'If YES, the materialized view log records object id information'
/

comment on column ALL_MVIEW_LOGS.FILTER_COLUMNS is 'If YES, the materialized view log records filter column information'
/

comment on column ALL_MVIEW_LOGS.SEQUENCE is 'If YES, the materialized view log records sequence information'
/

comment on column ALL_MVIEW_LOGS.INCLUDE_NEW_VALUES is 'If YES, the materialized view log records old and new values (else only old values)'
/

comment on column ALL_MVIEW_LOGS.PURGE_ASYNCHRONOUS is 'If YES, the materialized view log is purged asynchronously'
/

comment on column ALL_MVIEW_LOGS.PURGE_DEFERRED is 'If YES, the materialized view log is purged in a deferred manner'
/

comment on column ALL_MVIEW_LOGS.PURGE_START is 'For deferred purge, the purge start date'
/

comment on column ALL_MVIEW_LOGS.PURGE_INTERVAL is 'For deferred purge, the purge interval'
/

comment on column ALL_MVIEW_LOGS.LAST_PURGE_DATE is 'Date of the last purge'
/

comment on column ALL_MVIEW_LOGS.LAST_PURGE_STATUS is 'Status of the last purge: error code or 0 for success'
/

comment on column ALL_MVIEW_LOGS.NUM_ROWS_PURGED is 'Number of rows purged in the last purge'
/

comment on column ALL_MVIEW_LOGS.COMMIT_SCN_BASED is 'If YES, the materialized view log is commit SCN-based'
/

comment on column ALL_MVIEW_LOGS.STAGING_LOG is 'If YES, the log is a staging log for synchronous refresh'
/

