create view ALL_ERROR_TRANSLATIONS
            (OWNER, PROFILE_NAME, ERROR_CODE, TRANSLATED_CODE, TRANSLATED_SQLSTATE, ENABLED, REGISTRATION_TIME,
             COMMENTS) as
select u.name, o.name, s.errcode#, s.txlcode#, s.txlsqlstate,
       decode(bitand(s.flags, 1), 1, 'TRUE', 0, 'FALSE'), s.rtime, s.comment$
  from sys.sqltxl_err$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
 where s.obj# = o.obj# and
       o.owner# = u.user# and
       (
         o.owner# = userenv('SCHEMAID')
         or
         exists (select null from sys.objauth$ oa
                  where oa.obj# = o.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# in (0 /* ALTER */, 29 /* USE */))
         or
         exists (select null from v$enabledprivs
                 where priv_number in (
                                -335 /* CREATE ANY SQL TRANSLATION PROFILE */,
                                -336 /* ALTER ANY SQL TRANSLATION PROFILE  */,
                                -337 /* USE ANY SQL TRANSLATION PROFILE    */,
                                -338 /* DROP ANY SQL TRANSLATION PROFILE   */
                                      )
                )
       )
/

comment on table ALL_ERROR_TRANSLATIONS is 'Describes all error translations accessible to the user'
/

comment on column ALL_ERROR_TRANSLATIONS.OWNER is 'Owner of the SQL translation profile'
/

comment on column ALL_ERROR_TRANSLATIONS.PROFILE_NAME is 'Name of the SQL translation profile'
/

comment on column ALL_ERROR_TRANSLATIONS.ERROR_CODE is 'The error code'
/

comment on column ALL_ERROR_TRANSLATIONS.TRANSLATED_CODE is 'The translated error code'
/

comment on column ALL_ERROR_TRANSLATIONS.TRANSLATED_SQLSTATE is 'The translated SQLSTATE'
/

comment on column ALL_ERROR_TRANSLATIONS.ENABLED is 'Is the translation enabled?'
/

comment on column ALL_ERROR_TRANSLATIONS.REGISTRATION_TIME is 'Time the translation was registered'
/

comment on column ALL_ERROR_TRANSLATIONS.COMMENTS is 'Comment on the translation'
/

