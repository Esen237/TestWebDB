create view INT$DBA_APP_STATEMENTS
            (STATEMENT_ID, CAPTURE_TIME, LONGSQLTXT, SQLSTMT, APP_NAME, APP_STATUS, PATCH_NUMBER, VERSION_NUMBER,
             SESSION_ID, OPCODE, OPTIMIZED, APP_ID, SHARING, ORIGIN_CON_ID)
as
select s.replay#, s.ctime,
          /* Bug 28689357 : Mask the DDL for password verifiers, if the OPCODE
           * in question is known to contain "IDENTIFIED BY" clause.
           *   51 (CREATE USER),   43 (ALTER USER), 52 (CREATE ROLE),
           *   79 (ALTER ROLE),    17 (GRANT DDL),  32 (CREATE DBLINK),
           *   225 (ALTER DBLINK), 55 (SET ROLE)
           * This list needs to be in sync with kpdbfdGetSqlWithVerifier.
           *
           * longsqltxt is used only when the statement length exceeds 4K.
           * The only statement type wherein it can contain password is when
           * grant .. identified by .. is executed with too many grantees.
           * (qcpl password masking code supports maximum of 148 password in
           * one single DDL statement).
           * We just extract the 4000 bytes, search for identified by values
           * clause and mask the rest of the statement text.
           */
          case when opcode in (51, 43, 52, 79, 17, 32, 225, 55) then
            to_clob(regexp_replace(
                      translate(dbms_lob.substr(s.longsqltxt, 4000, 1),
                                chr(9)||chr(10)||chr(11)||chr(13),
                                '    '),
                      'identified\s*by\s*values\s*.*',
                      'identified by values * ', 1, 0, 'i'))
          else s.longsqltxt end,
          case when opcode in (51, 43, 52, 79, 17, 32, 225, 55) then
            regexp_replace(translate(s.sqlstmt,
                                     chr(9)||chr(10)||chr(11)||chr(13),
                                     '    '),
                   'identified\s*by\s*values\s*(''([a-z0-9;: ]+)''\s*,?\s*)*',
                   'identified by values * ', 1, 0, 'i')
          else s.sqlstmt end,
          a.app_name,
          decode(s.app_status, 1, 'INSTALLING', 2, 'UPGRADING', 3, 'PATCHING',
                               4, 'UNINSTALLING', 5, 'UNINSTALLED',
                               6, 'SET VERSION', 7, 'SET PATCH',
                               0, 'NORMAL'),
          s.patch#, s.ver#, s.sessserial#, s.opcode,
          decode(bitand(s.flags,48), 16, 'NO OP', 32, 'NO REPLAY', null)
            optimized, s.appid#,
          1,
          to_number(sys_context('USERENV', 'CON_ID'))
from fed$apps a, pdb_sync$ s
where a.appid#=s.appid# and bitand(s.flags,8)=8 and a.spare1=0
and (SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' or
     bitand(a.flag,128)=0)
/

