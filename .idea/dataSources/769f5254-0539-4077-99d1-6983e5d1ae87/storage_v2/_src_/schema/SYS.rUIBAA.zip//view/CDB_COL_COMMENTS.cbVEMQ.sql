create view CDB_COL_COMMENTS (OWNER, TABLE_NAME, COLUMN_NAME, COMMENTS, ORIGIN_CON_ID, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."COMMENTS",k."ORIGIN_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_COL_COMMENTS") k
/

comment on table CDB_COL_COMMENTS is 'Comments on columns of all tables and views in all containers'
/

comment on column CDB_COL_COMMENTS.OWNER is 'Name of the owner of the object'
/

comment on column CDB_COL_COMMENTS.TABLE_NAME is 'Name of the object'
/

comment on column CDB_COL_COMMENTS.COLUMN_NAME is 'Name of the column'
/

comment on column CDB_COL_COMMENTS.COMMENTS is 'Comment on the object'
/

comment on column CDB_COL_COMMENTS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

comment on column CDB_COL_COMMENTS.CON_ID is 'container id'
/

