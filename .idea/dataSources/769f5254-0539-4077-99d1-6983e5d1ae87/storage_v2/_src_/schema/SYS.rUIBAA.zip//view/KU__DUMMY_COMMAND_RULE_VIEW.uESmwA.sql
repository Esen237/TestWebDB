create view KU$_DUMMY_COMMAND_RULE_VIEW (VERS_MAJOR, VERS_MINOR, RULE_SET_NAME) as
select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

