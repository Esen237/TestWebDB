create view V_$DIAG_DDE_USR_INC_ACT_MAP (TYPE_NAME, ACTION_NAME, CON_ID) as
select
   "TYPE_NAME",
   "ACTION_NAME",
   "CON_ID"
  from x$diag_DDE_USR_INC_ACT_MAP
/

