create view V_$SESSION_CURSOR_CACHE (MAXIMUM, COUNT, OPENS, HITS, HIT_RATIO, CON_ID) as
select "MAXIMUM","COUNT","OPENS","HITS","HIT_RATIO","CON_ID" from v$session_cursor_cache
/

