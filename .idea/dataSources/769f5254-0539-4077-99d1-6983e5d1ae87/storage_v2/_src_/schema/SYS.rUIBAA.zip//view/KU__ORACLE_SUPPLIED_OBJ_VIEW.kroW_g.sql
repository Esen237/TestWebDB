create view KU$_ORACLE_SUPPLIED_OBJ_VIEW (OBJECT_TYPE, OBJECT_SCHEMA, OBJECT_NAME) as
SELECT  type_name, owner_name, name
        FROM    sys.ku$_schemaobj_view
        WHERE   BITAND(flags, 4194304) = 4194304 AND
                owner_name NOT IN (SELECT UNIQUE n.name
                                   FROM   sys.ku_noexp_tab n
                                    WHERE n.obj_type = 'SCHEMA')
/

