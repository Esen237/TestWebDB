create view CDB_STREAMS_NEWLY_SUPPORTED (OWNER, TABLE_NAME, REASON, COMPATIBLE, CON_ID) as
SELECT k."OWNER",k."TABLE_NAME",k."REASON",k."COMPATIBLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_STREAMS_NEWLY_SUPPORTED") k
/

comment on table CDB_STREAMS_NEWLY_SUPPORTED is 'List of tables that are newly supported by Streams capture in all containers'
/

comment on column CDB_STREAMS_NEWLY_SUPPORTED.OWNER is 'Owner of the table'
/

comment on column CDB_STREAMS_NEWLY_SUPPORTED.TABLE_NAME is 'Name of the table'
/

comment on column CDB_STREAMS_NEWLY_SUPPORTED.REASON is 'Reason why the table was not supported in some previous release'
/

comment on column CDB_STREAMS_NEWLY_SUPPORTED.COMPATIBLE is 'The latest compatible setting when this table was unsupported'
/

comment on column CDB_STREAMS_NEWLY_SUPPORTED.CON_ID is 'container id'
/

