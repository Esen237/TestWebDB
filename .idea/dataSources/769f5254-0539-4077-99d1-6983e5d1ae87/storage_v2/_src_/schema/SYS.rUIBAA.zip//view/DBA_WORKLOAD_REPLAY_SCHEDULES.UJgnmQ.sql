create view DBA_WORKLOAD_REPLAY_SCHEDULES (SCHEDULE_NAME, DIRECTORY, STATUS) as
select schedule_name, directory, status
 from   WRR$_REPLAY_SCHEDULES
/

