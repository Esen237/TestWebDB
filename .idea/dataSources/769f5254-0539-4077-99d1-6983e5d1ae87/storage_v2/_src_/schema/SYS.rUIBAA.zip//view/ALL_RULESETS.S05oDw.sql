create view ALL_RULESETS (OWNER, RULESET_NAME, RULESET_STORAGE_TABLE, BASE_TABLE, RULESET_COMMENT) as
SELECT rule_set_owner, rule_set_name, NULL,
       decode(rule_set_eval_context_owner, NULL, NULL,
              rule_set_eval_context_owner||'.'||rule_set_eval_context_name),
       rule_set_comment
FROM   all_rule_sets
/

comment on table ALL_RULESETS is 'Rulesets seen by the user: maintained for backward compatibility'
/

comment on column ALL_RULESETS.OWNER is 'Owner of the ruleset'
/

comment on column ALL_RULESETS.RULESET_NAME is 'Name of the ruleset'
/

comment on column ALL_RULESETS.RULESET_STORAGE_TABLE is 'name of the table to store rules in the ruleset'
/

comment on column ALL_RULESETS.BASE_TABLE is 'name of the evaluation context for the rule set'
/

comment on column ALL_RULESETS.RULESET_COMMENT is 'user description of the ruleset'
/

