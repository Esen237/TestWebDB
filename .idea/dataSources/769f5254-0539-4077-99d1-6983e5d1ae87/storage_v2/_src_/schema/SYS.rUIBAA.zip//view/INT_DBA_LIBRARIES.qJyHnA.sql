create view INT$DBA_LIBRARIES
            (OWNER, LIBRARY_NAME, OBJECT_ID, FILE_SPEC, DYNAMIC, STATUS, AGENT, LEAF_FILENAME, SHARING,
             ORIGIN_CON_ID) as
select u.name,
       o.name,
       o.obj#,
       l.filespec,
       decode(bitand(l.property, 1), 0, 'Y', 1, 'N', NULL),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       l.agent,
       l.leaf_filename,
       case when bitand(o.flags, (65536+131072+4294967296))>0 then 1 else 0 end,
       to_number(sys_context('USERENV', 'CON_ID'))
from sys."_CURRENT_EDITION_OBJ" o, sys.library$ l, sys.user$ u
where o.owner# = u.user#
  and o.obj# = l.obj#
/

