create view CDB_STREAMS_TP_PATH_BOTTLENECK
            (PATH_ID, COMPONENT_ID, COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, TOP_SESSION_ID, TOP_SESSION_SERIAL#,
             ACTION_NAME, BOTTLENECK_IDENTIFIED, ADVISOR_RUN_ID, ADVISOR_RUN_TIME, ADVISOR_RUN_REASON, CON_ID)
as
SELECT k."PATH_ID",k."COMPONENT_ID",k."COMPONENT_NAME",k."COMPONENT_DB",k."COMPONENT_TYPE",k."TOP_SESSION_ID",k."TOP_SESSION_SERIAL#",k."ACTION_NAME",k."BOTTLENECK_IDENTIFIED",k."ADVISOR_RUN_ID",k."ADVISOR_RUN_TIME",k."ADVISOR_RUN_REASON",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_STREAMS_TP_PATH_BOTTLENECK") k
/

comment on table CDB_STREAMS_TP_PATH_BOTTLENECK is 'DBA Streams Path Bottleneck in all containers'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.PATH_ID is 'ID of the Streams Path'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_NAME is 'Name of the Bottleneck Component'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_DB is 'Database Where the Bottleneck Component resides'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_TYPE is 'Type of the Bottleneck Component'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.TOP_SESSION_ID is 'ID of the Top Session for the Bottleneck Component'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.TOP_SESSION_SERIAL# is 'Serial# of the Top Session for the Bottleneck Component'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.ACTION_NAME is 'Action Name for the Bottleneck Process'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.BOTTLENECK_IDENTIFIED is 'Whether Bottlecneck Was Identified'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_ID is '1-Based Logical Number of Advisor Run'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_TIME is 'Time That the Advisor Was Run'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_REASON is 'Reasons for Bottleneck Analysis Results'
/

comment on column CDB_STREAMS_TP_PATH_BOTTLENECK.CON_ID is 'container id'
/

