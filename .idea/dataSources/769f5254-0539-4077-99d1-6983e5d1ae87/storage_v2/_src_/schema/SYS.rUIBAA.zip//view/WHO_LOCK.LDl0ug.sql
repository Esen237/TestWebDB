create view WHO_LOCK
            (SID, SERIAL, CTIME, BLOCKER, STATUS, SQL_HASH, PREV_SQL_HASH, PROGRAM, MODULE, ACTION, CLIENT_INFO,
             LOGON_TIME, TYPE, OBJ_ROWID)
as
select /*+ ordered */
 bs.sid, bs.serial# Serial, hk.ctime,
 bs.username||'\'|| bs.osuser||'\'||bs.machine blocker,
 bs.status,
 bs.sql_hash_value sql_hash,
 bs.prev_hash_value Prev_Sql_hash,
 bs.program, bs.module, bs.action, bs.client_info,
 TO_CHAR(bs.logon_time,'hh:mi:ss dd.mm.yyyy') logon_time,
 hk.type,
 case hk.type
   when 'TM' then (select ob.owner || '.' || ob.object_name
                   from dba_objects ob where ob.object_id= hk.id1)
   when 'TX' then (select ob.owner || '.' || ob.object_name ||' / '||
                   dbms_rowid.rowid_create(1, ob.data_object_id,
                   ws.row_wait_file#, ws.row_wait_block#, ws.row_wait_row#)
                   from dba_objects ob where ob.object_id(+)=ws.row_wait_obj#)
 end obj_rowid
FROM
   v$lock hk, v$session bs, v$lock wk, v$session ws
WHERE
     hk.block   = 1
  AND  wk.request  != 0
  AND  wk.TYPE (+) = hk.TYPE
  AND  wk.id1  (+) = hk.id1
  AND  wk.id2  (+) = hk.id2
  AND  hk.sid    = bs.sid(+)
  AND  wk.sid    = ws.sid(+)
  and  bs.lockwait is null
ORDER BY hk.ctime desc
/

