create view USER_ASSOCIATIONS
            (OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, OBJECT_TYPE, STATSTYPE_SCHEMA, STATSTYPE_NAME, DEF_SELECTIVITY,
             DEF_CPU_COST, DEF_IO_COST, DEF_NET_COST, INTERFACE_VERSION, MAINTENANCE_TYPE)
as
select u.name, o.name, c.name,
         decode(a.property, 1, 'COLUMN', 2, 'TYPE', 3, 'PACKAGE', 4,
                'FUNCTION', 5, 'INDEX', 6, 'INDEXTYPE', 'INVALID'),
         u1.name, o1.name,a.default_selectivity,
         a.default_cpu_cost, a.default_io_cost, a.default_net_cost,
         a.interface_version#,
         decode (bitand(a.spare2, 1), 1, 'SYSTEM_MANAGED', 'USER_MANAGED')
   from  sys.association$ a, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u,
         sys."_CURRENT_EDITION_OBJ" o1, sys.user$ u1, sys.col$ c
   where a.obj#=o.obj# and o.owner#=u.user#
   AND   a.statstype#=o1.obj# (+) and o1.owner#=u1.user# (+)
   AND   a.obj# = c.obj#  (+)  and a.intcol# = c.intcol# (+)
   and o.owner#=userenv('SCHEMAID')
/

comment on table USER_ASSOCIATIONS is 'All assocations defined by the user'
/

comment on column USER_ASSOCIATIONS.OBJECT_OWNER is 'Owner of the object for which the association is being defined'
/

comment on column USER_ASSOCIATIONS.OBJECT_NAME is 'Object name for which the association is being defined'
/

comment on column USER_ASSOCIATIONS.COLUMN_NAME is 'Column name in the object for which the association is being defined'
/

comment on column USER_ASSOCIATIONS.OBJECT_TYPE is 'Schema type of the object - table, type, package or function'
/

comment on column USER_ASSOCIATIONS.STATSTYPE_SCHEMA is 'Owner of the statistics type'
/

comment on column USER_ASSOCIATIONS.STATSTYPE_NAME is 'Name of Statistics type which contains the cost, selectivity or stats funcs'
/

comment on column USER_ASSOCIATIONS.DEF_SELECTIVITY is 'Default Selectivity if any of the object'
/

comment on column USER_ASSOCIATIONS.DEF_CPU_COST is 'Default CPU cost if any of the object'
/

comment on column USER_ASSOCIATIONS.DEF_IO_COST is 'Default I/O cost if any of the object'
/

comment on column USER_ASSOCIATIONS.DEF_NET_COST is 'Default Networking cost if any of the object'
/

comment on column USER_ASSOCIATIONS.INTERFACE_VERSION is 'Interface number of Statistics type interface implemented'
/

comment on column USER_ASSOCIATIONS.MAINTENANCE_TYPE is 'Whether it is system managed or user managed'
/

