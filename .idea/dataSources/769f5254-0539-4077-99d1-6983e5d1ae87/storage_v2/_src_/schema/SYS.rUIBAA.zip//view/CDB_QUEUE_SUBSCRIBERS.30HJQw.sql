create view CDB_QUEUE_SUBSCRIBERS
            (OWNER, QUEUE_NAME, QUEUE_TABLE, CONSUMER_NAME, ADDRESS, PROTOCOL, TRANSFORMATION, RULE, DELIVERY_MODE,
             IF_NONDURABLE_SUBSCRIBER, QUEUE_TO_QUEUE, SUBSCRIBER_ID, POS_BITMAP, CON_ID)
as
SELECT k."OWNER",k."QUEUE_NAME",k."QUEUE_TABLE",k."CONSUMER_NAME",k."ADDRESS",k."PROTOCOL",k."TRANSFORMATION",k."RULE",k."DELIVERY_MODE",k."IF_NONDURABLE_SUBSCRIBER",k."QUEUE_TO_QUEUE",k."SUBSCRIBER_ID",k."POS_BITMAP",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_QUEUE_SUBSCRIBERS") k
/

comment on table CDB_QUEUE_SUBSCRIBERS is 'queue subscribers in the database in all containers'
/

comment on column CDB_QUEUE_SUBSCRIBERS.OWNER is 'owner of the queue'
/

comment on column CDB_QUEUE_SUBSCRIBERS.QUEUE_NAME is 'name of the queue'
/

comment on column CDB_QUEUE_SUBSCRIBERS.QUEUE_TABLE is 'name of the queue table'
/

comment on column CDB_QUEUE_SUBSCRIBERS.CONSUMER_NAME is 'name of the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.ADDRESS is 'address of the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.PROTOCOL is 'protocol of the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.TRANSFORMATION is 'transformation for the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.RULE is 'rule condition for the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.DELIVERY_MODE is 'message delivery mode for the subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.QUEUE_TO_QUEUE is 'whether the subscriber is a queue to queue subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.SUBSCRIBER_ID is 'id of subscriber'
/

comment on column CDB_QUEUE_SUBSCRIBERS.POS_BITMAP is 'position of subscriber in the bitmap'
/

comment on column CDB_QUEUE_SUBSCRIBERS.CON_ID is 'container id'
/

