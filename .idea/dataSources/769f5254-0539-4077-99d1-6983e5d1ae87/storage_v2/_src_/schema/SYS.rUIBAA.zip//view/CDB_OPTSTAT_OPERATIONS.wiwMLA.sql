create view CDB_OPTSTAT_OPERATIONS
            (ID, OPERATION, TARGET, START_TIME, END_TIME, STATUS, JOB_NAME, SESSION_ID, NOTES, CON_ID) as
SELECT k."ID",k."OPERATION",k."TARGET",k."START_TIME",k."END_TIME",k."STATUS",k."JOB_NAME",k."SESSION_ID",k."NOTES",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_OPTSTAT_OPERATIONS") k
/

comment on table CDB_OPTSTAT_OPERATIONS is 'History of statistics operations performed in all containers'
/

comment on column CDB_OPTSTAT_OPERATIONS.ID is 'Internal identifier for the operation'
/

comment on column CDB_OPTSTAT_OPERATIONS.OPERATION is 'Operation name'
/

comment on column CDB_OPTSTAT_OPERATIONS.TARGET is 'Target on which operation performed'
/

comment on column CDB_OPTSTAT_OPERATIONS.START_TIME is 'Start time of operation'
/

comment on column CDB_OPTSTAT_OPERATIONS.END_TIME is 'End time of operation'
/

comment on column CDB_OPTSTAT_OPERATIONS.STATUS is 'Operation completion status'
/

comment on column CDB_OPTSTAT_OPERATIONS.JOB_NAME is 'Name of the scheduler job in which the operation runs'
/

comment on column CDB_OPTSTAT_OPERATIONS.SESSION_ID is 'Id of the session in which the operation runs'
/

comment on column CDB_OPTSTAT_OPERATIONS.NOTES is 'Additional notes about the operation'
/

comment on column CDB_OPTSTAT_OPERATIONS.CON_ID is 'container id'
/

