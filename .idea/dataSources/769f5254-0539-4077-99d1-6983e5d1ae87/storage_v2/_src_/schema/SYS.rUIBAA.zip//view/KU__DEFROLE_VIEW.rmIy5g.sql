create view KU$_DEFROLE_VIEW (VERS_MAJOR, VERS_MINOR, USER_ID, USER_NAME, USER_TYPE, DEFROLE, ROLE_LIST) as
select '1','0',
          u.user#,
          u.name,
          u.type#,
          u.defrole,
          cast(multiset (select * from ku$_defrole_list_view df
                where df.user_id = u.user#) as ku$_defrole_list_t
                )
  from sys.user$ u
  where (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0
                OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

