create view KU$_PROCACT_SYS_VIEW
            (VERS_MAJOR, VERS_MINOR, TAG, CMNT, PACKAGE, SCHEMA, LEVEL_NUM, CLASS, PREPOST, PLSQL) as
select '1','0',
  p.tag, p.cmnt, p.package, p.schema,
  p.level#, p.class, pr.prepost,
  case
   when p.class=1 then sys.dbms_metadata.get_action_sys
        ( p.tag, p.package, p.schema, 'SYSTEM_INFO_EXP', pr.prepost)
   else null
  end
  FROM  sys.ku$_exppkgact_view p , ku$_prepost_view pr
  where p.class =1
  order by p.level#
/

