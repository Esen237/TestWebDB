create view DBA_SUBPART_KEY_COLUMNS_V$ (OWNER, NAME, OBJECT_TYPE, COLUMN_NAME, COLUMN_POSITION, COLLATED_COLUMN_ID) as
select u.name, o.name, 'TABLE',
  decode(bitand(c.property, 1), 1, a.name, c.name), spc.pos#,
  c.collintcol#
from   obj$ o, subpartcol$ spc, col$ c, user$ u, attrcol$ a
where  spc.obj# = o.obj# and spc.obj# = c.obj#
       and c.intcol# = spc.intcol#
       and u.user# = o.owner#
       and c.obj# = a.obj#(+) and c.intcol# = a.intcol#(+)
       and o.subname IS NULL
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union
select u.name, o.name, 'INDEX',
  decode(bitand(c.property, 1), 1, a.name, c.name), spc.pos#,
  c.collintcol#
from   obj$ o, subpartcol$ spc, col$ c, user$ u, ind$ i, attrcol$ a
where  spc.obj# = i.obj# and i.obj# = o.obj# and i.bo# = c.obj#
       and c.intcol# = spc.intcol#
       and u.user# = o.owner#
       and c.obj# = a.obj#(+) and c.intcol# = a.intcol#(+)
       and o.subname IS NULL
       and o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
/

