create view KU$_XSPRIV_VIEW
            (VERS_MAJOR, VERS_MINOR, PRIVID, SCID, CTIME, MTIME, DESCRIPTION, NAME, OWNER_NAME, AGGR_PRIV_LIST) as
select '1','0',
  p.priv#,
  p.sc#,
  p.ctime,
  p.mtime,
  p.description,
  (select name from xs$obj o where o.id = p.priv#),
  (select owner from xs$obj o where o.id = p.priv#),
  (cast(multiset(select * from ku$_xsaggpriv_view ap
                        where ap.scid = p.sc# and ap.aggr_privid = p.priv#
                      ) as ku$_xsaggpriv_list_t))
  from xs$priv p
/

