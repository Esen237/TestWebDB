create view "_DBA_STREAMS_RULES_H2"
            (STREAMS_TYPE, STREAMS_NAME, RULE_SET_OWNER, RULE_SET_NAME, RULE_OWNER, RULE_NAME, RULE_CONDITION,
             RULE_SET_TYPE, STREAMS_RULE_TYPE, SCHEMA_NAME, OBJECT_NAME, SUBSETTING_OPERATION, DML_CONDITION,
             INCLUDE_TAGGED_LCR, SOURCE_DATABASE, RULE_TYPE, ORIGINAL_RULE_CONDITION, SAME_RULE_CONDITION,
             SOURCE_ROOT_NAME)
as
select decode(r.streams_type, 1, 'CAPTURE',
                              2, 'PROPAGATION',
                              3, 'APPLY',
                              4, 'DEQUEUE',
                              5, 'SYNC_CAPTURE') streams_type,
       r.streams_name, r.rule_set_owner, r.rule_set_name,
       r.rule_owner, r.rule_name, r.rule_condition, r.rule_set_type,
       decode(sr.object_type, 1, 'TABLE',
                              2, 'SCHEMA',
                              3, 'GLOBAL',
                              4, 'PROCEDURE') streams_rule_type,
       sr.schema_name, sr.object_name,
       decode(sr.subsetting_operation, 1, 'INSERT',
                                       2, 'UPDATE',
                                       3, 'DELETE') subsetting_operation,
       sr.dml_condition,
       decode(sr.include_tagged_lcr, 0, 'NO',
                                     1, 'YES') include_tagged_lcr,
       sr.source_database,
       decode(sr.rule_type, 1, 'DML',
                            2, 'DDL',
                            3, 'PROCEDURE') rule_type,
       sr.rule_condition original_rule_condition,
       decode(sr.rule_condition,
              NULL, NULL,
              dbms_lob.substr(r.rule_condition), 'YES',
              decode(least(4001,dbms_lob.getlength(r.rule_condition)),
                     4001, NULL, 'NO')) same_rule_condition,
       sr.source_root_name
  from "_DBA_STREAMS_RULES_H" r, streams$_rules sr
  where r.rule_name = sr.rule_name(+)
    and r.rule_owner = sr.rule_owner(+)
/

