create view USER_ANALYTIC_VIEW_HIER_CLASS
            (ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, HIER_ALIAS, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM,
             ORIGIN_CON_ID) as
select ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, HIER_ALIAS, CLASSIFICATION,
       VALUE, language, ORDER_NUM, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_AVIEW_HIER_CLASS)
where owner = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_ANALYTIC_VIEW_HIER_CLASS is 'Analytic view hierarchy classifications in the database'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.ANALYTIC_VIEW_NAME is 'Name of analytic view'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.DIMENSION_ALIAS is 'Alias of the attribute dimension in the analytic view'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.HIER_ALIAS is 'Alias of the hierarchy within the attribute dimension in the analytic view'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.CLASSIFICATION is 'Name of analytic view hierarchy classification'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.VALUE is 'Value of hierarchy classification'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.LANGUAGE is 'Language of hierarchy classification'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.ORDER_NUM is 'Order number of hierarchy classification'
/

comment on column USER_ANALYTIC_VIEW_HIER_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

