create view DBA_CAPTURE_PREPARED_TABLES
            (TABLE_OWNER, TABLE_NAME, SCN, TIMESTAMP, SUPPLEMENTAL_LOG_DATA_PK, SUPPLEMENTAL_LOG_DATA_UI,
             SUPPLEMENTAL_LOG_DATA_FK, SUPPLEMENTAL_LOG_DATA_ALL)
as
select u.name, o.name, co.ignore_scn, co.timestamp,
       decode(bitand(cd.flags, 1), 1,
              decode(bitand(co.flags, 1), 1, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(cd.flags, 2), 2,
              decode(bitand(co.flags, 2), 2, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(cd.flags, 4), 4,
              decode(bitand(co.flags, 4), 4, 'IMPLICIT', 'EXPLICIT'), 'NO'),
       decode(bitand(cd.flags, 8), 8,
              decode(bitand(co.flags, 8), 8, 'IMPLICIT', 'EXPLICIT'), 'NO')
  from obj$ o, user$ u, streams$_prepare_object co,
       (select obj#, sum(DECODE(type#, 14, 1, 15, 2, 16, 4, 17, 8, 0)) flags
          from sys.cdef$ group by obj#) cd
  where o.obj# = co.obj# and o.owner# = u.user# and co.obj# = cd.obj#(+)
    and co.cap_type = 0 and bitand(o.flags,128) = 0 -- skip recyclebin obj
/

comment on table DBA_CAPTURE_PREPARED_TABLES is 'All tables prepared for instantiation'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.TABLE_OWNER is 'Owner of the table prepared for instantiation'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.TABLE_NAME is 'Name of the table prepared for instantiation'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.SCN is 'SCN from which changes can be captured'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.TIMESTAMP is 'Time at which the table was ready to be instantiated'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.SUPPLEMENTAL_LOG_DATA_PK is 'Status of table-level PRIMARY KEY COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.SUPPLEMENTAL_LOG_DATA_UI is 'Status of table-level UNIQUE INDEX COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.SUPPLEMENTAL_LOG_DATA_FK is 'Status of table-level FOREIGN KEY COLUMNS supplemental logging'
/

comment on column DBA_CAPTURE_PREPARED_TABLES.SUPPLEMENTAL_LOG_DATA_ALL is 'Status of table-level ALL COLUMNS supplemental logging'
/

