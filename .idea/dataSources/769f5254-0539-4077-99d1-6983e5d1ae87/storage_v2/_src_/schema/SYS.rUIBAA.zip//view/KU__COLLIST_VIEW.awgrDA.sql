create view KU$_COLLIST_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, PROPERTY, COL_LIST) as
select '1','1',
         t.obj#,
         value(o),
         t.property,
         cast( multiset(select * from ku$_column_view c
                where c.obj_num = t.obj#
                order by c.col_num, c.intcol_num
                ) as ku$_tab_column_list_t
              )
 from   ku$_schemaobj_view o, tab$ t
 where t.obj# = o.obj_num
        AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                         WHERE role = 'SELECT_CATALOG_ROLE'))
/

