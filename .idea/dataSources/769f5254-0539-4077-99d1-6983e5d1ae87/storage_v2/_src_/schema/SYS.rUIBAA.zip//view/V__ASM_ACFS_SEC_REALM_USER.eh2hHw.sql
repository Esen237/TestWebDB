create view V_$ASM_ACFS_SEC_REALM_USER (REALM_NAME, USER_NAME, FS_NAME, VOL_DEVICE, CON_ID) as
select "REALM_NAME","USER_NAME","FS_NAME","VOL_DEVICE","CON_ID" from v$asm_acfs_sec_realm_user
/

