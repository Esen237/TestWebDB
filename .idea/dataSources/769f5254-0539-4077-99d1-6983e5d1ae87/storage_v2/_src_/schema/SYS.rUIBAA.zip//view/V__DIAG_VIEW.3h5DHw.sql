create view V_$DIAG_VIEW (OBJ_ID, NAME, TEXT, CREATION_TIME, SCOPE, VERSION, CON_ID) as
select
   "OBJ_ID",
   "NAME",
   "TEXT",
   "CREATION_TIME",
   "SCOPE",
   "VERSION",
   "CON_ID"
  from x$diag_VIEW
/

