create view USER_STATEMENTS
            (SIGNATURE, TYPE, OBJECT_NAME, OBJECT_TYPE, USAGE_ID, LINE, COL, USAGE_CONTEXT_ID, SQL_ID, HAS_HINT,
             HAS_INTO_BULK, HAS_INTO_RETURNING, HAS_INTO_RECORD, HAS_CURRENT_OF, HAS_FOR_UPDATE, HAS_IN_BINDS, TEXT,
             FULL_TEXT, ORIGIN_CON_ID)
as
select SIGNATURE, TYPE, OBJECT_NAME, OBJECT_TYPE,
USAGE_ID, LINE, COL, USAGE_CONTEXT_ID, SQL_ID, HAS_HINT, HAS_INTO_BULK,
HAS_INTO_RETURNING, HAS_INTO_RECORD, HAS_CURRENT_OF, HAS_FOR_UPDATE, HAS_IN_BINDS,
TEXT, FULL_TEXT, ORIGIN_CON_ID
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_STATEMENTS)
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
/

comment on table USER_STATEMENTS is 'SQL statements in stored PL/SQL objects accessible to the user'
/

comment on column USER_STATEMENTS.SIGNATURE is 'Signature of the SQL statement'
/

comment on column USER_STATEMENTS.TYPE is 'Type of the statement'
/

comment on column USER_STATEMENTS.OBJECT_NAME is 'Name of the object where the SQL statement occurred'
/

comment on column USER_STATEMENTS.OBJECT_TYPE is 'Type of the object where the SQL statement occurred'
/

comment on column USER_STATEMENTS.USAGE_ID is 'Unique key for a SQL statement within the object'
/

comment on column USER_STATEMENTS.LINE is 'Line number of the SQL statement'
/

comment on column USER_STATEMENTS.COL is 'Column number of the SQL statement'
/

comment on column USER_STATEMENTS.USAGE_CONTEXT_ID is 'Context USAGE_ID of a the SQL statement'
/

comment on column USER_STATEMENTS.SQL_ID is 'SQLID of the SQL statement'
/

comment on column USER_STATEMENTS.HAS_HINT is 'TRUE if the SQL statement contains a hint'
/

comment on column USER_STATEMENTS.TEXT is 'Varchar2 text of the SQL statement'
/

comment on column USER_STATEMENTS.FULL_TEXT is 'Clob text of the SQL statement'
/

comment on column USER_STATEMENTS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

