create view USER_CERTIFICATES (CERTIFICATE_ID, USER_NAME, DISTINGUISHED_NAME, CERTIFICATE) as
select  c.user_cert_guid,
        u.name,
        c.distinguish_name,
        c.user_cert
from sys.user_certs$ c, sys.user$ u
where c.user_obj# = u.user# AND
      c.user_obj# = userenv('SCHEMAID')
/

