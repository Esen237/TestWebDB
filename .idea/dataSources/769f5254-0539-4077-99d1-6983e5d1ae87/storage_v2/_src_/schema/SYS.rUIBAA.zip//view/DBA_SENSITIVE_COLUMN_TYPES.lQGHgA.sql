create view DBA_SENSITIVE_COLUMN_TYPES (NAME, USER_COMMENT, SOURCE_NAME, SOURCE_TYPE) as
select
 t.name,
 t.user_comment,
 s.name,
 decode(s.type, 1, 'DB', 2, 'ADM')
from sys.tsdp_sensitive_type$ t, sys.tsdp_source$ s where t.source#=s.source#
/

comment on table DBA_SENSITIVE_COLUMN_TYPES is 'All Sensitive Column Types in the database'
/

comment on column DBA_SENSITIVE_COLUMN_TYPES.NAME is 'The name of the Sensitive Column Type'
/

comment on column DBA_SENSITIVE_COLUMN_TYPES.USER_COMMENT is 'User comment on the Sensitive Column Type'
/

comment on column DBA_SENSITIVE_COLUMN_TYPES.SOURCE_NAME is 'The source of the Sensitive Column Type'
/

comment on column DBA_SENSITIVE_COLUMN_TYPES.SOURCE_TYPE is 'The type of the source - DB or ADM'
/

