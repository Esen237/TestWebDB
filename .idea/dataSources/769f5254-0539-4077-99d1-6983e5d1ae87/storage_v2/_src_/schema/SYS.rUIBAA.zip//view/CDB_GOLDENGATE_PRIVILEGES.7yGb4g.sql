create view CDB_GOLDENGATE_PRIVILEGES (USERNAME, PRIVILEGE_TYPE, GRANT_SELECT_PRIVILEGES, CREATE_TIME, CON_ID) as
SELECT k."USERNAME",k."PRIVILEGE_TYPE",k."GRANT_SELECT_PRIVILEGES",k."CREATE_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_GOLDENGATE_PRIVILEGES") k
/

comment on table CDB_GOLDENGATE_PRIVILEGES is 'Details about goldengate privileges in all containers'
/

comment on column CDB_GOLDENGATE_PRIVILEGES.USERNAME is 'Name of the user that is granted the privilege'
/

comment on column CDB_GOLDENGATE_PRIVILEGES.PRIVILEGE_TYPE is 'Type of privilege granted'
/

comment on column CDB_GOLDENGATE_PRIVILEGES.GRANT_SELECT_PRIVILEGES is 'Whether to grant select privileges'
/

comment on column CDB_GOLDENGATE_PRIVILEGES.CREATE_TIME is 'Timestamp for the granted privilege'
/

comment on column CDB_GOLDENGATE_PRIVILEGES.CON_ID is 'container id'
/

