create view AWR_CDB_CELL_OPEN_ALERTS
            (SNAP_ID, DBID, CELL_HASH, BEGIN_TIME, SEQ_NO, MESSAGE, STATEFUL, SEVERITY, CELL_ALERT_SUMMARY, CON_DBID,
             CON_ID) as
select s.snap_id, s.dbid, s.cell_hash,
       s.begin_time, s.seq_no, s.message,
       decode(s.stateful,1,'Y','N') stateful,
       s.severity,
       s.cell_alert_summary,
       decode(s.con_dbid, 0, s.dbid, s.con_dbid),
       decode(s.per_pdb, 0, 0,
         con_dbid_to_id(decode(s.con_dbid, 0, s.dbid, s.con_dbid))) con_id
from WRH$_CELL_OPEN_ALERTS s,
    (select distinct snap_id, dbid
       from AWR_CDB_SNAPSHOT) sn
where  s.snap_id          = sn.snap_id
  and  s.dbid             = sn.dbid
/

comment on table AWR_CDB_CELL_OPEN_ALERTS is 'Cell Open Alerts Information'
/

