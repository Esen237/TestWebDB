create view USER_ATTRIBUTE_DIM_CLASS (DIMENSION_NAME, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM, ORIGIN_CON_ID) as
select dimension_name, classification, value, language, order_num,
       origin_con_id
from  NO_ROOT_SW_FOR_LOCAL(INT$DBA_ATTR_DIM_CLASS)
where owner = sys_context('USERENV','CURRENT_USER')
/

comment on table USER_ATTRIBUTE_DIM_CLASS is 'Attribute dimension classifications in the database'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.DIMENSION_NAME is 'Dimension name of owning attribute dimension classification'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.CLASSIFICATION is 'Name of attribute dimension classification'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.VALUE is 'Value of attribute dimension classification'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.LANGUAGE is 'Language of attribute dimension classification'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.ORDER_NUM is 'Order number of attribute dimension classification'
/

comment on column USER_ATTRIBUTE_DIM_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

