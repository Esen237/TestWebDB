create view GV_$NLS_PARAMETERS (INST_ID, PARAMETER, VALUE, CON_ID) as
select "INST_ID","PARAMETER","VALUE","CON_ID" from gv$nls_parameters
/

