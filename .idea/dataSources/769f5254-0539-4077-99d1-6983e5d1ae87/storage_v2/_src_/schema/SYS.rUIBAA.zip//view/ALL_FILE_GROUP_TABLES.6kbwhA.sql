create view ALL_FILE_GROUP_TABLES
            (FILE_GROUP_OWNER, FILE_GROUP_NAME, VERSION_NAME, VERSION, OWNER, TABLE_NAME, TABLESPACE_NAME, SCN) as
select file_group_owner, file_group_name, version_name, version_id,
       owner, table_name, tablespace_name, scn
from "_ALL_FILE_GROUP_TABLES"
/

comment on table ALL_FILE_GROUP_TABLES is 'Details about the tables in the file group repository'
/

comment on column ALL_FILE_GROUP_TABLES.FILE_GROUP_OWNER is 'Owner of the file group'
/

comment on column ALL_FILE_GROUP_TABLES.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column ALL_FILE_GROUP_TABLES.VERSION_NAME is 'Name of the version'
/

comment on column ALL_FILE_GROUP_TABLES.VERSION is 'Internal version number'
/

comment on column ALL_FILE_GROUP_TABLES.OWNER is 'Schema table belongs to'
/

comment on column ALL_FILE_GROUP_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column ALL_FILE_GROUP_TABLES.TABLESPACE_NAME is 'Name of the tablespace containing the table'
/

comment on column ALL_FILE_GROUP_TABLES.SCN is 'SCN table was exported at'
/

