create view ALL_EXTERNAL_LOCATIONS (OWNER, TABLE_NAME, LOCATION, DIRECTORY_OWNER, DIRECTORY_NAME) as
select u.name, o.name, xl.name, 'SYS', nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.user$ u, sys.obj$ o, sys.external_tab$ xt
where o.owner# = u.user#
  and o.subname IS NULL
  and o.obj#   = xl.obj#
  and o.obj#   = xt.obj#
  and ( o.owner# = userenv('SCHEMAID')
        or o.obj# in
        ( select oa.obj# from sys.objauth$ oa
          where grantee# in (select kzsrorol from x$kzsro)
        )
        or    /* user has system privileges */
          exists ( select null from v$enabledprivs
                   where priv_number in (-45 /* LOCK ANY TABLE */,
                                         -47 /* SELECT ANY TABLE */,
                                         -397/* READ ANY TABLE */)
                 )
      )
/

comment on table ALL_EXTERNAL_LOCATIONS is 'Description of the external tables locations accessible to the user'
/

comment on column ALL_EXTERNAL_LOCATIONS.OWNER is 'Owner of the external table location'
/

comment on column ALL_EXTERNAL_LOCATIONS.TABLE_NAME is 'Name of the corresponding external table'
/

comment on column ALL_EXTERNAL_LOCATIONS.LOCATION is 'External table location clause'
/

comment on column ALL_EXTERNAL_LOCATIONS.DIRECTORY_OWNER is 'Owner of the directory containing the external table location'
/

comment on column ALL_EXTERNAL_LOCATIONS.DIRECTORY_NAME is 'Name of the directory containing the location'
/

