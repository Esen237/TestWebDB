create view CDB_HIST_IOSTAT_FILETYPE_NAME (DBID, FILETYPE_ID, FILETYPE_NAME, CON_DBID, CON_ID) as
SELECT k."DBID",k."FILETYPE_ID",k."FILETYPE_NAME",k."CON_DBID",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_IOSTAT_FILETYPE_NAME") k
/

comment on table CDB_HIST_IOSTAT_FILETYPE_NAME is 'File type names for historical I/O statistics in all containers'
/

comment on column CDB_HIST_IOSTAT_FILETYPE_NAME.CON_ID is 'container id'
/

