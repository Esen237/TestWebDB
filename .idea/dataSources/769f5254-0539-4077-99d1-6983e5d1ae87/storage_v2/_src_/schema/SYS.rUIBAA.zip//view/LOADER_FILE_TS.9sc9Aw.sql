create view LOADER_FILE_TS (TABLESPACENO, FILENAME, FILENO) as
select file$.ts#, v$dbfile.name, file$.relfile#
   from file$, v$dbfile
   where file$.file# = v$dbfile.file#
/

