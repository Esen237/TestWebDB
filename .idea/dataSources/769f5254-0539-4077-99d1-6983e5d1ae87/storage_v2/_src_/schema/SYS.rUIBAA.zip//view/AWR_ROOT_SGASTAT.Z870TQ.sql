create view AWR_ROOT_SGASTAT (SNAP_ID, DBID, INSTANCE_NUMBER, NAME, POOL, BYTES, CON_DBID, CON_ID) as
select sga.snap_id, sga.dbid, sga.instance_number, name, pool,
       case when SYS_CONTEXT('USERENV','SYSTEM_DATA_VISIBLE')='YES' or sga.per_pdb<>0 then sga.bytes else null end bytes,
       decode(sga.con_dbid, 0, sga.dbid, sga.con_dbid),
       decode(sga.per_pdb, 0, 0,
         con_dbid_to_id(decode(sga.con_dbid, 0, sga.dbid, sga.con_dbid))) con_id
  from AWR_ROOT_SNAPSHOT sn, WRH$_SGASTAT sga
  where     sn.snap_id         = sga.snap_id
        and sn.dbid            = sga.dbid
        and sn.instance_number = sga.instance_number
/

comment on table AWR_ROOT_SGASTAT is 'SGA Pool Historical Statistics Information'
/

