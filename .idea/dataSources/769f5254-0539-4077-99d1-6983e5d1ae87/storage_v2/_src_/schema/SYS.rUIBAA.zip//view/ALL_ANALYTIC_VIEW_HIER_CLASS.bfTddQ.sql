create view ALL_ANALYTIC_VIEW_HIER_CLASS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, HIER_ALIAS, CLASSIFICATION, VALUE, LANGUAGE, ORDER_NUM,
             ORIGIN_CON_ID) as
select owner,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       HIER_ALIAS,
       CLASSIFICATION,
       VALUE,
       language,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_HIER_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

comment on table ALL_ANALYTIC_VIEW_HIER_CLASS is 'Analytic view hierarchy classifications in the database'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.OWNER is 'Owner of the analytic view hierarchy classification'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.ANALYTIC_VIEW_NAME is 'Name of analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.DIMENSION_ALIAS is 'Alias of the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.HIER_ALIAS is 'Alias of the hierarchy within the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.CLASSIFICATION is 'Name of analytic view hierarchy classification'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.VALUE is 'Value of hierarchy classification'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.LANGUAGE is 'Language of hierarchy classification'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.ORDER_NUM is 'Order number of hierarchy classification'
/

comment on column ALL_ANALYTIC_VIEW_HIER_CLASS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

