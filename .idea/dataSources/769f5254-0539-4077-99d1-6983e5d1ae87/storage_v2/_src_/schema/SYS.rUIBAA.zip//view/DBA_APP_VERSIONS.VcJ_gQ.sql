create view DBA_APP_VERSIONS (APP_NAME, APP_VERSION, APP_VERSION_COMMENT, APP_VERSION_CHECKSUM, APP_ROOT_CLONE_NAME) as
select a.app_name, v.tgtver, v.cmnt, v.spare1,
       con_id_to_con_name(con_uid_to_id(v.root_clone_con_uid#))
from fed$apps a, fed$versions v
where a.app_name <> '_CURRENT_STATE'
and a.appid#=v.appid#
and a.spare1=0
/

comment on table DBA_APP_VERSIONS is 'Describes all applications in the Application Container'
/

comment on column DBA_APP_VERSIONS.APP_NAME is 'Name of the application'
/

comment on column DBA_APP_VERSIONS.APP_VERSION is 'Version of the application'
/

comment on column DBA_APP_VERSIONS.APP_VERSION_COMMENT is 'Comment for the application version'
/

comment on column DBA_APP_VERSIONS.APP_VERSION_CHECKSUM is 'Checksum for the application version'
/

comment on column DBA_APP_VERSIONS.APP_ROOT_CLONE_NAME is 'Name of the application root clone'
/

