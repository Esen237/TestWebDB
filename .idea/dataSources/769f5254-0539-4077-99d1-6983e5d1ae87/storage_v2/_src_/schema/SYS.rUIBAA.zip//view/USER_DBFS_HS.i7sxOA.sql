create view USER_DBFS_HS (STORENAME) as
SELECT d.storeName FROM DBA_DBFS_HS d, sys.user$ u WHERE u.user#= userenv('SCHEMAID') and d.storeOwner = u.name
/

