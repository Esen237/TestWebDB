create view CDB_ACCHK_EVENTS_SUMMARY
            (INST_ID, CON_ID, SERVICE_NAME, FAILOVER_TYPE, FAILOVER_RESTORE, RESET_STATE, PROGRAM, MODULE, ACTION,
             SQL_ID, CALL_NAME, EVENT_TYPE, ERROR_CODE, FREQUENCY)
as
SELECT k."INST_ID",k."CON_ID",k."SERVICE_NAME",k."FAILOVER_TYPE",k."FAILOVER_RESTORE",k."RESET_STATE",k."PROGRAM",k."MODULE",k."ACTION",k."SQL_ID",k."CALL_NAME",k."EVENT_TYPE",k."ERROR_CODE",k."FREQUENCY", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_ACCHK_EVENTS_SUMMARY") k
/

comment on table CDB_ACCHK_EVENTS_SUMMARY is ' in all containers'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.INST_ID is 'Instance number the session was using'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.CON_ID is 'Container ID the session was using'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.SERVICE_NAME is 'Service name of the session'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.FAILOVER_TYPE is 'FAILOVER_TYPE service setting'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.FAILOVER_RESTORE is 'FAILOVER_RESTORE service setting'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.RESET_STATE is 'RESET_STATE service setting'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.PROGRAM is 'Operating system program name'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.MODULE is 'Name of the currently executing module'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.ACTION is 'Name of the currently executing action'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.SQL_ID is 'SQL identifier of the SQL statement that is currently being executed'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.CALL_NAME is 'User call that is currently being executed'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.EVENT_TYPE is 'Type of the event recorded'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.ERROR_CODE is 'Oracle error message number'
/

comment on column CDB_ACCHK_EVENTS_SUMMARY.FREQUENCY is 'Number of times that event occurred during the workload run'
/

