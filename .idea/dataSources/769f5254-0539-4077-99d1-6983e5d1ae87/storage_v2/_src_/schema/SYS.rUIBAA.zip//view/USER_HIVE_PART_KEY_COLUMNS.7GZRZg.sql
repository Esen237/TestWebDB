create view USER_HIVE_PART_KEY_COLUMNS
            (CLUSTER_ID, DATABASE_NAME, TABLE_NAME, OWNER, COLUMN_NAME, COLUMN_TYPE, COLUMN_POSITION,
             ORACLE_COLUMN_TYPE) as
SELECT M."CLUSTER_ID",M."DATABASE_NAME",M."TABLE_NAME",M."OWNER",M."COLUMN_NAME",M."COLUMN_TYPE",M."COLUMN_POSITION",M."ORACLE_COLUMN_TYPE" FROM DBA_HIVE_PART_KEY_COLUMNS M, SYS.USER$ U
WHERE U.user# = USERENV('SCHEMAID') AND
-- Current user has system privileges
      ((
        ora_check_sys_privilege(U.user#, 2) = 1
       )
       OR
-- If current user is neither SYS nor DBA, then do the following checks
-- User must have read privilege on ORACLE_BIGDATA_CONFIG directory
      (
        DBMS_HADOOP.USER_PRIVILEGED('BDSQL_USER', M.CLUSTER_ID) = 1
      )
     )
/

comment on table USER_HIVE_PART_KEY_COLUMNS is 'USER hive table partition columns'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.CLUSTER_ID is 'Hadoop cluster name'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.DATABASE_NAME is 'Database where hive table resides'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.TABLE_NAME is 'Hive table name'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.OWNER is 'Owner of hive table'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.COLUMN_NAME is 'Partition column name'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.COLUMN_TYPE is 'Partition column type'
/

comment on column USER_HIVE_PART_KEY_COLUMNS.COLUMN_POSITION is 'Partition column position'
/

