create view INDEX_HISTOGRAM (REPEAT_COUNT, KEYS_WITH_REPEAT_COUNT) as
select hist.indx * power(2, stats.kdxstscl-4)  repeat_count,
        hist.kdxhsval                           keys_with_repeat_count
        from  x$kdxst stats, x$kdxhs hist
/

comment on table INDEX_HISTOGRAM is 'statistics on keys with repeat count'
/

comment on column INDEX_HISTOGRAM.REPEAT_COUNT is 'number of times that a key is repeated'
/

comment on column INDEX_HISTOGRAM.KEYS_WITH_REPEAT_COUNT is 'number of keys that are repeated REPEAT_COUNT times'
/

