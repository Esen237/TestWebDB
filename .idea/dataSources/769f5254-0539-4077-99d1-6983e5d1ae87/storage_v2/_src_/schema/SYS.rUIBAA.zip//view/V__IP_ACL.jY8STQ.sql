create view V_$IP_ACL (SERVICE_NAME, HOST, CON_ID) as
select "SERVICE_NAME","HOST","CON_ID" from v$ip_acl
/

