create view AUDIT_UNIFIED_CONTEXTS (NAMESPACE, ATTRIBUTE, USER_NAME) as
select a.namespace,
       a.attribute,
       u.name
from sys.aud_context$ a, sys.user$ u
where a.user# = u.user#
UNION all
select a.namespace,
       a.attribute,
       'ALL USERS'
from sys.aud_context$ a
where a.user# = -1
/

comment on table AUDIT_UNIFIED_CONTEXTS is 'Describes the application context''s attributes, which are configured to be
 captured in the audit trail'
/

comment on column AUDIT_UNIFIED_CONTEXTS.NAMESPACE is 'Name of Application context''s Namespace'
/

comment on column AUDIT_UNIFIED_CONTEXTS.ATTRIBUTE is 'Name of Application context''s Attribute'
/

comment on column AUDIT_UNIFIED_CONTEXTS.USER_NAME is 'Database username for whom the Application context''s attribute is congfigured
 to be captured in the audit trail'
/

