create view CDB_HIST_COLORED_SQL (DBID, SQL_ID, CREATE_TIME, CON_ID) as
SELECT k."DBID",k."SQL_ID",k."CREATE_TIME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."AWR_PDB_COLORED_SQL") k
/

comment on table CDB_HIST_COLORED_SQL is 'Marked SQLs for snapshots in all containers'
/

comment on column CDB_HIST_COLORED_SQL.CON_ID is 'container id'
/

