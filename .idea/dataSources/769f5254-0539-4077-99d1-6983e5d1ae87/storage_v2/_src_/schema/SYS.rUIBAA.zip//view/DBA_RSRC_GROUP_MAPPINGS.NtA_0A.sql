create view DBA_RSRC_GROUP_MAPPINGS (ATTRIBUTE, VALUE, CONSUMER_GROUP, STATUS) as
select m.attribute, m.value, m.consumer_group,
       decode(m.status,'PENDING',m.status, NULL)
from sys.resource_group_mapping$ m
order by m.status,
         (select p.priority from sys.resource_mapping_priority$ p
          where m.status = p.status and m.attribute = p.attribute),
         m.consumer_group, m.value
/

comment on table DBA_RSRC_GROUP_MAPPINGS is 'all the consumer group mappings'
/

comment on column DBA_RSRC_GROUP_MAPPINGS.ATTRIBUTE is 'which session attribute to match'
/

comment on column DBA_RSRC_GROUP_MAPPINGS.VALUE is 'attribute value'
/

comment on column DBA_RSRC_GROUP_MAPPINGS.CONSUMER_GROUP is 'target consumer group name'
/

comment on column DBA_RSRC_GROUP_MAPPINGS.STATUS is 'PENDING if it is part of the pending area, NULL otherwise'
/

