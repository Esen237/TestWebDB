create view ALL_ANALYTIC_VIEW_HIERS
            (OWNER, ANALYTIC_VIEW_NAME, DIMENSION_ALIAS, HIER_OWNER, HIER_NAME, HIER_ALIAS, IS_DEFAULT, ORDER_NUM,
             ORIGIN_CON_ID) as
select OWNER,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       HIER_OWNER,
       HIER_NAME,
       HIER_ALIAS,
       IS_DEFAULT,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_HIERS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
/

comment on table ALL_ANALYTIC_VIEW_HIERS is 'Analytic view hierarchies in the database'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.OWNER is 'Owner of analytic view hierarchy'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.ANALYTIC_VIEW_NAME is 'Name of the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.DIMENSION_ALIAS is 'Alias of the attribute dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.HIER_OWNER is 'Owner of the hierarchy'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.HIER_NAME is 'Name of the hierarchy'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.HIER_ALIAS is 'Alias specified for the hierarchy'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.IS_DEFAULT is 'Y if this is the default hierarchy for the dimension in the analytic view, N otherwise'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.ORDER_NUM is 'Order of the hierarchy within the list of hierarchies for the
 dimension in the analytic view'
/

comment on column ALL_ANALYTIC_VIEW_HIERS.ORIGIN_CON_ID is 'ID of Container where row originates'
/

