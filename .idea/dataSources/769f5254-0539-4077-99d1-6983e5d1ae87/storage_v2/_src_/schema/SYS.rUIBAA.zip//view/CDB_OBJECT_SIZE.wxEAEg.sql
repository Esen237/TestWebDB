create view CDB_OBJECT_SIZE (OWNER, NAME, TYPE, SOURCE_SIZE, PARSED_SIZE, CODE_SIZE, ERROR_SIZE, CON_ID) as
SELECT k."OWNER",k."NAME",k."TYPE",k."SOURCE_SIZE",k."PARSED_SIZE",k."CODE_SIZE",k."ERROR_SIZE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_OBJECT_SIZE") k
/

comment on table CDB_OBJECT_SIZE is 'Sizes, in bytes, of various pl/sql objects in all containers'
/

comment on column CDB_OBJECT_SIZE.OWNER is 'Owner of the object'
/

comment on column CDB_OBJECT_SIZE.NAME is 'Name of the object'
/

comment on column CDB_OBJECT_SIZE.TYPE is 'Type of the object: "TYPE", "TYPE BODY", "TABLE", "VIEW", "SYNONYM",
"SEQUENCE", "PROCEDURE", "FUNCTION", "PACKAGE", "PACKAGE BODY", "TRIGGER",
"JAVA SOURCE", "JAVA CLASS", "JAVA RESOURCE", "JAVA DATA",
"CUBE DIMENSION", "CUBE", "MEASURE FOLDER", or "CUBE BUILD PROCESS"'
/

comment on column CDB_OBJECT_SIZE.SOURCE_SIZE is 'Size of the source, in bytes.  Must be in memory during compilation, or
dynamic recompilation'
/

comment on column CDB_OBJECT_SIZE.PARSED_SIZE is 'Size of the parsed form of the object, in bytes.  Must be in memory when
an object is being compiled that references this object'
/

comment on column CDB_OBJECT_SIZE.CODE_SIZE is 'Code size, in bytes.  Must be in memory when this object is executing'
/

comment on column CDB_OBJECT_SIZE.ERROR_SIZE is 'Size of error messages, in bytes.  In memory during the compilation of the object when there are compilation errors'
/

comment on column CDB_OBJECT_SIZE.CON_ID is 'container id'
/

