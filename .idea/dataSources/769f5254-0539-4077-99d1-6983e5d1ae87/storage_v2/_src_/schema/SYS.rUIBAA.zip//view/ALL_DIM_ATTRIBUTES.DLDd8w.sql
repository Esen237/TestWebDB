create view ALL_DIM_ATTRIBUTES (OWNER, DIMENSION_NAME, ATTRIBUTE_NAME, LEVEL_NAME, COLUMN_NAME, INFERRED) as
select u.name, o.name, da.attname, dl.levelname, c.name, 'N'
from sys.dimattr$ da, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl, sys.col$ c
where da.dimobj# = o.obj#
  and o.owner# = u.user#
  and da.dimobj# = dl.dimobj#
  and da.levelid# = dl.levelid#
  and da.detailobj# = c.obj#
  and da.col# = c.intcol#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         ora_check_sys_privilege(o.owner#, o.type#) = 1
      )
/

comment on table ALL_DIM_ATTRIBUTES is 'Representation of the relationship between a dimension level and
 a functionally dependent column'
/

comment on column ALL_DIM_ATTRIBUTES.OWNER is 'Owner of the dimentsion'
/

comment on column ALL_DIM_ATTRIBUTES.DIMENSION_NAME is 'Name of the dimension'
/

comment on column ALL_DIM_ATTRIBUTES.ATTRIBUTE_NAME is 'Name of the attribute'
/

comment on column ALL_DIM_ATTRIBUTES.LEVEL_NAME is 'Name of the hierarchy level'
/

comment on column ALL_DIM_ATTRIBUTES.COLUMN_NAME is 'Name of the dependent column'
/

comment on column ALL_DIM_ATTRIBUTES.INFERRED is 'Whether this attribute is inferred from a JOIN KEY specification'
/

