create view DBA_SUBSCR_DUR_REGISTRATIONS
            (REG_ID, SUBSCRIPTION_NAME, LOCATION_NAME, USER#, USER_CONTEXT, CONTEXT_SIZE, NAMESPACE, PRESENTATION,
             VERSION, STATUS, ANY_CONTEXT, CONTEXT_TYPE, QOSFLAGS, PAYLOAD_CALLBACK, TIMEOUT, REG_TIME,
             NTFN_GROUPING_CLASS, NTFN_GROUPING_VALUE, NTFN_GROUPING_TYPE, NTFN_GROUPING_START_TIME,
             NTFN_GROUPING_REPEAT_COUNT)
as
select reg_id, subscription_name, location_name, user#, user_context,
  context_size, decode(namespace, 0, 'ANONYMOUS', 1, 'AQ', 2, 'DBCHANGE')
  NAMESPACE, decode(presentation, 0, 'DEFAULT', 1, 'XML') PRESENTATION,
  decode(version, 1, '8.1.6', 2, '10.2', 3, '11.1', 4, '11.2', 5, '11.2.0.2',
         6, '12.1.0.0')
  VERSION, decode(status, 0, 'DB REG', 1, 'LDAP REG') STATUS,
  any_context, context_type,
  decode(bitand(qosflags, 1), 1,' RELIABLE') ||
  decode(bitand(qosflags, 2), 2, ' PAYLOAD') ||
  decode(bitand(qosflags, 8), 8, ' SECURE')  ||
  decode(bitand(qosflags, 16), 16, ' PURGE_ON_NTFN') ||
  decode(bitand(qosflags, 512), 512, ' ASYNC_DEQ')   ||
  decode(bitand(qosflags, 1024), 1024, ' AUTO_ACK') ||
  decode(bitand(qosflags, 2048), 2048, ' TX_ACK') QOSFLAGS,
  payload_callback, timeout, reg_time,
  decode(ntfn_grouping_class, 1, 'TIME')NTFN_GROUPING_CLASS,
  ntfn_grouping_value, decode(ntfn_grouping_type, 1, 'SUMMARY', 2, 'LAST')
  NTFN_GROUPING_TYPE, ntfn_grouping_start_time,
  decode(ntfn_grouping_repeat_count, -1, 'FOREVER', ntfn_grouping_repeat_count)   NTFN_GROUPING_REPEAT_COUNT
from reg$
/

comment on table DBA_SUBSCR_DUR_REGISTRATIONS is 'All Durable subscription registrations created in the database'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NAMESPACE is 'Subscription namespace'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.PRESENTATION is 'Presentation of notification'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.VERSION is 'Version'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.STATUS is 'Status of registration'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.QOSFLAGS is 'Quality of service of registration'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NTFN_GROUPING_CLASS is 'Grouping class'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NTFN_GROUPING_VALUE is 'Grouping value'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NTFN_GROUPING_TYPE is 'Grouping type'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NTFN_GROUPING_START_TIME is 'Grouping start time'
/

comment on column DBA_SUBSCR_DUR_REGISTRATIONS.NTFN_GROUPING_REPEAT_COUNT is 'Grouping repeat count'
/

