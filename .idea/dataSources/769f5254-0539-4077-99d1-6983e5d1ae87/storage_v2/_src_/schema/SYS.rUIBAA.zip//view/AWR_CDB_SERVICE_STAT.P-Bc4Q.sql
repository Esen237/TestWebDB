create view AWR_CDB_SERVICE_STAT
            (SNAP_ID, DBID, INSTANCE_NUMBER, SERVICE_NAME_HASH, SERVICE_NAME, STAT_ID, STAT_NAME, VALUE, CON_DBID,
             CON_ID) as
select st.snap_id, st.dbid, st.instance_number,
       st.service_name_hash, sv.service_name,
       nm.stat_id, nm.stat_name, value,
       decode(st.con_dbid, 0, st.dbid, st.con_dbid),
       decode(st.per_pdb, 0, 0,
         con_dbid_to_id(decode(st.con_dbid, 0, st.dbid, st.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_SERVICE_STAT st,
       WRH$_SERVICE_NAME sv, WRH$_STAT_NAME nm
  where    st.service_name_hash = sv.service_name_hash
      and  st.dbid              = sv.dbid
      and  st.stat_id           = nm.stat_id
      and  st.dbid              = nm.dbid
      and  st.snap_id           = sn.snap_id
      and  st.dbid              = sn.dbid
      and  st.instance_number   = sn.instance_number
      and  st.con_dbid          = sv.con_dbid
/

comment on table AWR_CDB_SERVICE_STAT is 'Historical Service Statistics'
/

