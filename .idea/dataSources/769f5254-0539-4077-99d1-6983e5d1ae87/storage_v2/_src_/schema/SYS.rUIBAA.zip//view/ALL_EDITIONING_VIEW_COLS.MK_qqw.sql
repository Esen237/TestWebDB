create view ALL_EDITIONING_VIEW_COLS
            (OWNER, VIEW_NAME, VIEW_COLUMN_ID, VIEW_COLUMN_NAME, TABLE_COLUMN_ID, TABLE_COLUMN_NAME) as
select ev_user.name,
       ev_obj.name,
       view_col.col#,
       view_col.name,
       tbl_col.col#,
       tbl_col.name
       
from   sys."_CURRENT_EDITION_OBJ" ev_obj, sys.obj$ base_tbl_obj,
       sys.ev$ ev, sys.evcol$ ev_col, sys.col$ view_col, sys.col$ tbl_col,
       sys.user$ ev_user
where  /* get all columns of a given EV */
       ev.ev_obj# = ev_col.ev_obj#
       /* join EVCOL$ to COL$ on EV id and column id to obtain EV column */
       /* name */
  and  ev_col.ev_obj# = view_col.obj#
  and  ev_col.ev_col_id = view_col.col#
       /* join EV$ to OBJ$ on base table owner id and base table name so we */
       /* can determine base table id */
  and  ev.base_tbl_owner# = base_tbl_obj.owner#
  and  ev.base_tbl_name   = base_tbl_obj.name
       /* exclude [sub]partitions by restricting base_tbl_obj.type# to */
       /* "table"; since COL$ will not contain rows for [sub]partitions, */
       /* this restriction is not, strictly speaking, necessary, but it */
       /* does ensure that the above join will return exactly one row */
  and base_tbl_obj.type# = 2
       /* join EVCOL$ row and OBJ$ row describing the EV's base table to */
       /* COL$ to obtain base table column id */
  and  base_tbl_obj.obj# = tbl_col.obj#
  and  ev_col.base_tbl_col_name = tbl_col.name
       /* join EV$ to _*_EDITION_OBJ on EV id so we can determine */
       /* name of the EV and id of its owner */
  and  ev_obj.obj# = ev.ev_obj#
       /* join _*_EDITION_OBJ row describing the EV to USER$ to get */
       /* owner name */
   and ev_obj.owner# = ev_user.user#
       /* make sure the EV is visible to the current user */
   and (ev_obj.owner# = userenv('SCHEMAID')
        or ev_obj.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
         ora_check_sys_privilege (ev_obj.owner#, ev_obj.type#) = 1
      )
/

comment on table ALL_EDITIONING_VIEW_COLS is 'Relationship between columns of Editioning Views accessible to the user and the table columns to which they map'
/

comment on column ALL_EDITIONING_VIEW_COLS.OWNER is 'Owner of an Editioning View'
/

comment on column ALL_EDITIONING_VIEW_COLS.VIEW_NAME is 'Name of an Editioning View'
/

comment on column ALL_EDITIONING_VIEW_COLS.VIEW_COLUMN_ID is 'Column number within the Editioning View'
/

comment on column ALL_EDITIONING_VIEW_COLS.VIEW_COLUMN_NAME is 'Name of the column in the Editioning View'
/

comment on column ALL_EDITIONING_VIEW_COLS.TABLE_COLUMN_ID is 'Column number of a table column to which this EV column maps'
/

comment on column ALL_EDITIONING_VIEW_COLS.TABLE_COLUMN_NAME is 'Name of a table column to which this EV column maps'
/

