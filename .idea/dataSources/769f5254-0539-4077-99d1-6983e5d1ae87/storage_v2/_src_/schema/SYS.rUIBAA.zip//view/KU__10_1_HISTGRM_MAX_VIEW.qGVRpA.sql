create view KU$_10_1_HISTGRM_MAX_VIEW
            (OBJ_NUM, INTCOL_NUM, BUCKET, ENDPOINT, EPVALUE, EPVALUE_RAW, EP_REPEAT_COUNT, SPARE1) as
select  hh.obj#, hh.intcol#, 1,
           case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
                then hh.maximum
                else null
           end,
           NULL, NULL, 0, NULL
   from    sys.obj$ o, sys."_HIST_HEAD_DEC" hh
   where   bucket_cnt = 1 AND o.obj# = hh.obj#
/

