create view DBA_REGISTRY_HISTORY (ACTION_TIME, ACTION, NAMESPACE, VERSION, ID, COMMENTS, BUNDLE_SERIES) as
SELECT action_time, action, namespace, version, id, comments, bundle_series
  FROM registry$history
/

