create view AWR_CDB_SESS_TIME_STATS
            (SNAP_ID, DBID, INSTANCE_NUMBER, SESSION_TYPE, MIN_LOGON_TIME, SUM_CPU_TIME, SUM_SYS_IO_WAIT,
             SUM_USER_IO_WAIT, CON_DBID, SESSION_MODULE, CON_ID)
as
select st.snap_id, st.dbid, st.instance_number, st.session_type,
       st.min_logon_time, st.sum_cpu_time, st.sum_sys_io_wait,
       st.sum_user_io_wait,
       decode(st.con_dbid, 0, st.dbid, st.con_dbid),
       st.session_module,
       decode(st.per_pdb, 0, 0,
         con_dbid_to_id(decode(st.con_dbid, 0, st.dbid, st.con_dbid))) con_id
  from AWR_CDB_SNAPSHOT sn, WRH$_SESS_TIME_STATS st
  where    st.snap_id           = sn.snap_id
      and  st.dbid              = sn.dbid
      and  st.instance_number   = sn.instance_number
/

comment on table AWR_CDB_SESS_TIME_STATS is 'CPU And I/O Time For High Utilization Streams/GoldenGate/XStream sessions'
/

