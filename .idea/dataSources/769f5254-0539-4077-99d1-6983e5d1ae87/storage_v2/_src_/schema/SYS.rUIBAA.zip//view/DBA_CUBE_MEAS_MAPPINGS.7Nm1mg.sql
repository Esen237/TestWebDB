create view DBA_CUBE_MEAS_MAPPINGS
            (OWNER, CUBE_NAME, CUBE_MAP_NAME, MAP_NAME, MAP_ID, MEASURE_NAME, MEASURE_EXPRESSION) as
SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  owner_map.map_name CUBE_MAP_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  meas.measure_name MEASURE_NAME,
  s1.syntax_clob MEASURE_EXPRESSION
FROM
  olap_mappings$ m,
  olap_mappings$ owner_map,
  user$ u,
  obj$ o,
  olap_measures$ meas,
  olap_syntax$ s1
WHERE
  m.map_type = 24
  AND m.mapped_object_id = meas.measure_id
  AND meas.cube_obj# = o.obj#
  AND o.owner# = u.user#
  AND m.mapping_owner_id = owner_map.map_id
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 1
/

comment on table DBA_CUBE_MEAS_MAPPINGS is 'OLAP Cube Measure Mappings in the database'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.OWNER is 'Owner of the OLAP Cube that contains the measure'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.CUBE_NAME is 'Name of the OLAP Cube that contains the measure'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.CUBE_MAP_NAME is 'Name of the map that contains the cube measure mapping'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.MAP_NAME is 'Name of the OLAP Cube Measure Mapping'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.MAP_ID is 'Dictionary Id of the OLAP Cube Measure Mapping'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.MEASURE_NAME is 'Name of the OLAP Cube Measure'
/

comment on column DBA_CUBE_MEAS_MAPPINGS.MEASURE_EXPRESSION is 'Expression of the OLAP Cube Measure Mapping'
/

