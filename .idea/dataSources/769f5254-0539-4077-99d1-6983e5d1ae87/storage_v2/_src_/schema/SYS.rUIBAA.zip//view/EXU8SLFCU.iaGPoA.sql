create view EXU8SLFCU (MOWNER, MOWNERID, MASTER, COLNAME, OLDEST, FLAG) as
SELECT  "MOWNER","MOWNERID","MASTER","COLNAME","OLDEST","FLAG"
        FROM    sys.exu8slfc
        WHERE   mownerid = userenv('SCHEMAID')
/

