create view AWR_PDB_BG_EVENT_SUMMARY
            (SNAP_ID, DBID, INSTANCE_NUMBER, EVENT_ID, EVENT_NAME, WAIT_CLASS_ID, WAIT_CLASS, TOTAL_WAITS,
             TOTAL_TIMEOUTS, TIME_WAITED_MICRO, CON_DBID, CON_ID)
as
select e.snap_id, e.dbid, e.instance_number,
       e.event_id, en.event_name, en.wait_class_id, en.wait_class,
       total_waits, total_timeouts, time_waited_micro,
       decode(e.con_dbid, 0, e.dbid, e.con_dbid),
       decode(e.per_pdb, 0, 0,
         con_dbid_to_id(decode(e.con_dbid, 0, e.dbid, e.con_dbid))) con_id
from AWR_PDB_SNAPSHOT sn, WRH$_BG_EVENT_SUMMARY e, WRH$_EVENT_NAME en
where     sn.snap_id         = e.snap_id
      and sn.dbid            = e.dbid
      and sn.instance_number = e.instance_number
      and e.event_id         = en.event_id
      and e.dbid             = en.dbid
/

comment on table AWR_PDB_BG_EVENT_SUMMARY is 'Summary of Background Event Historical Statistics Information'
/

