create view DBA_APPLY_TABLE_COLUMNS
            (OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, COMPARE_OLD_ON_DELETE, COMPARE_OLD_ON_UPDATE,
             APPLY_DATABASE_LINK) as
(select daoc.object_owner, daoc.object_name, daoc.column_name,
       decode(bitand(ac.property, 1), 1, 'NO', 0, 'YES'),
       decode(bitand(ac.property, 2), 2, 'NO', 0, 'YES'),
       daoc.apply_database_link
  from "_DBA_APPLY_TABLE_COLUMNS_H" daoc, "_DBA_APPLY_OBJECTS" ac
 where daoc.object_owner = ac.object_owner
   and daoc.object_name  = ac.object_name
union
select u.name, o.name, doc.column_name,
       decode(bitand(doc.flag, 1), 1, 'NO', 0, 'YES'),
       decode(bitand(doc.flag, 2), 2, 'NO', 0, 'YES'),
       null
  from sys.streams$_dest_obj_cols doc, sys.obj$ o, sys.user$ u
 where o.obj# = doc.object_number
   and o.owner# = u.user#
   and o.linkname is null
   and doc.dblink is null
   and o.remoteowner is null
union
select o.remoteowner, o.name, doc.column_name,
       decode(bitand(doc.flag, 1), 1, 'NO', 0, 'YES'),
       decode(bitand(doc.flag, 2), 2, 'NO', 0, 'YES'),
       doc.dblink
  from sys.streams$_dest_obj_cols doc, sys.obj$ o
 where o.obj# = doc.object_number
   and o.linkname = doc.dblink
   and o.remoteowner is not null)
/

comment on table DBA_APPLY_TABLE_COLUMNS is 'Details about the destination table columns'
/

comment on column DBA_APPLY_TABLE_COLUMNS.OBJECT_OWNER is 'Owner of the table'
/

comment on column DBA_APPLY_TABLE_COLUMNS.OBJECT_NAME is 'Name of the table'
/

comment on column DBA_APPLY_TABLE_COLUMNS.COLUMN_NAME is 'Name of column'
/

comment on column DBA_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_DELETE is 'Compare old value of column on deletes'
/

comment on column DBA_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_UPDATE is 'Compare old value of column on updates'
/

comment on column DBA_APPLY_TABLE_COLUMNS.APPLY_DATABASE_LINK is 'For remote table, name of database link pointing to remote database'
/

