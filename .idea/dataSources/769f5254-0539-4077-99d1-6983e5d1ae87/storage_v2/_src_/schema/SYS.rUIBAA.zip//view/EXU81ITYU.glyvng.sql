create view EXU81ITYU (NAME, OBJID, OWNER, OWNERID) as
SELECT  "NAME","OBJID","OWNER","OWNERID"
        FROM    sys.exu81ity
        WHERE   ownerid = userenv('SCHEMAID')
/

