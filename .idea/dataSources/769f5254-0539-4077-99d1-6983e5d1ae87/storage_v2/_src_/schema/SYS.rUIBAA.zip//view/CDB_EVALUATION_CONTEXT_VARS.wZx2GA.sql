create view CDB_EVALUATION_CONTEXT_VARS
            (EVALUATION_CONTEXT_OWNER, EVALUATION_CONTEXT_NAME, VARIABLE_NAME, VARIABLE_TYPE, VARIABLE_VALUE_FUNCTION,
             VARIABLE_METHOD_FUNCTION, CON_ID)
as
SELECT k."EVALUATION_CONTEXT_OWNER",k."EVALUATION_CONTEXT_NAME",k."VARIABLE_NAME",k."VARIABLE_TYPE",k."VARIABLE_VALUE_FUNCTION",k."VARIABLE_METHOD_FUNCTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_EVALUATION_CONTEXT_VARS") k
/

comment on table CDB_EVALUATION_CONTEXT_VARS is 'variables in all rule evaluation contexts in the database in all containers'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.EVALUATION_CONTEXT_OWNER is 'Owner of the evaluation context'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.VARIABLE_NAME is 'Name of the variable'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.VARIABLE_VALUE_FUNCTION is 'Function to provide variable value'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.VARIABLE_METHOD_FUNCTION is 'Function to provide variable method return value'
/

comment on column CDB_EVALUATION_CONTEXT_VARS.CON_ID is 'container id'
/

