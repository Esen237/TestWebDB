create view CDB_XS_PRIVILEGES (NAME, SECURITY_CLASS, SECURITY_CLASS_OWNER, DESCRIPTION, CON_ID) as
SELECT k."NAME",k."SECURITY_CLASS",k."SECURITY_CLASS_OWNER",k."DESCRIPTION",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("SYS"."DBA_XS_PRIVILEGES") k
/

comment on table CDB_XS_PRIVILEGES is 'All the Real Application Security privileges defined in the database in all containers'
/

comment on column CDB_XS_PRIVILEGES.NAME is 'Name of the privilege'
/

comment on column CDB_XS_PRIVILEGES.SECURITY_CLASS is 'Name of the security class that scopes the privilege'
/

comment on column CDB_XS_PRIVILEGES.SECURITY_CLASS_OWNER is 'Owner of the security class that scopes the privilege'
/

comment on column CDB_XS_PRIVILEGES.DESCRIPTION is 'Description of the privilege'
/

comment on column CDB_XS_PRIVILEGES.CON_ID is 'container id'
/

