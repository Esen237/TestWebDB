create trigger REFRESH_TOKEN_DELETE
    before delete
    on OAUTH_REFRESH_TOKEN
    for each row
begin
    insert into collector_core.oauth_refresh_token_log
    (old_token_id, new_token_id, dlm, status)
    values (
    :old.token_id,
    :new.token_id,
    sysdate,
    'deleted');
end;


/

