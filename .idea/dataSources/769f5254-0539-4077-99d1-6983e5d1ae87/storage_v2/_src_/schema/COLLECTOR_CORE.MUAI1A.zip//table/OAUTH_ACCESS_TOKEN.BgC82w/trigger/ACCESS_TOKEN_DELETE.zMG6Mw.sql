create trigger ACCESS_TOKEN_DELETE
    before delete
    on OAUTH_ACCESS_TOKEN
    for each row
begin
    insert into collector_core.oauth_access_token_log
    (old_token_id, new_token_id, authentication_id, dlm, status)
    values (
    :old.token_id,
    :new.token_id,
    :new.authentication_id,
    sysdate,
    'deleted');
end;


/

