create function            getElcardIPCBalance(ps_account_number in varchar2) return number is
ln_balance number := 0;
begin
ln_balance:=(select pkg_soa_transaction.getElcardIPCBalance(ps_account_number) from dual);
return ln_balance;
end;
/

