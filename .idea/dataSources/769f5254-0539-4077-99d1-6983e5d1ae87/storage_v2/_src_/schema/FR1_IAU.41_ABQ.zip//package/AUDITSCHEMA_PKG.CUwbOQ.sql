create package auditschema_pkg as

    type general_refcur_type is ref cursor;
    type string_table_type is table of varchar2(255);

    function componentTable (p_id integer, p_time varchar2) return general_refcur_type;
    function delimitStr (p_in_str clob, p_delimiter varchar2, p_separator varchar2, p_escape varchar2) return clob;
    function tableExist (p_component_type in out varchar2) return boolean;

end auditschema_pkg;
/

