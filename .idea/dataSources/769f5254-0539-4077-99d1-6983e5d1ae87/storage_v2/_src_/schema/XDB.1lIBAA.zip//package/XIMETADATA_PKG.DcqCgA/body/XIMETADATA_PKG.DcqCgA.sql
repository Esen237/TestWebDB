create PACKAGE BODY     ximetadata_pkg AS

iterate   NUMBER := 0;     -- counts the calls
data      CLOB := NULL;    -- buffer storage
offset NUMBER := 1;
done NUMBER := 0;

FUNCTION getIndexMetadata (idxinfo  IN  sys.ODCIIndexInfo,
                           expver   IN  VARCHAR2,
                           newblock OUT number,
                           idxenv   IN  sys.ODCIEnv) return VARCHAR2 IS
  current_plsql VARCHAR2(32000);
  pos    NUMBER := 0;
BEGIN
  newblock := 0;

  IF (done = 1) THEN
     iterate  := 0; -- reset
     done     := 0; -- reset
     offset   := 1;
     RETURN '';
  END IF;

  IF (sys.dbms_datapump.datapump_job) THEN
    IF (iterate = 0) THEN -- first call: get data from c callback once
      data := getIndexMetadataCallback (idxinfo, expver, newblock, idxenv);
      IF (length(data) <= 30000) THEN
        done := 1;          -- short metadata can be returned in one shot
        RETURN data;
      END IF;
    END IF;

    -- we have long metadata
    -- find the second occurence of 'insert into XDB.XDB'
    pos := dbms_lob.instr(data, 'insert into', offset, 2);

    IF (pos = 0) THEN -- not found
       current_plsql := DBMS_LOB.SUBSTR(data, 30000, offset); -- the rest
       done := 1;
    ELSE
       current_plsql:= DBMS_LOB.SUBSTR(data, pos - offset -1, offset);
       offset := pos;
    END IF;

    iterate := iterate + 1;
    return current_plsql;
  END IF;

  done := 1;
  return '';
END getIndexMetadata;


 function getIndexMetadataCallback (idxinfo  IN  sys.ODCIIndexInfo,
                                    expver   IN  VARCHAR2,
                                    newblock OUT number,
                                    idxenv   IN  sys.ODCIEnv)
         return CLOB
  is language C name "QMIX_XMETADATA" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo  INDICATOR struct,
       expver,  expver   INDICATOR,
       newblock,newblock INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       RETURN OCILobLocator);

 FUNCTION utlgettablenames(idxinfo  IN  sys.ODCIIndexInfo) return BOOLEAN
 is language C name "QMIX_TABLEUTILS" library  XDB.XMLINDEX_LIB
      with context
      parameters (
        context,
        idxinfo, idxinfo  INDICATOR struct,
        RETURN            INDICATOR sb4,
        return);

END ximetadata_pkg;
/

