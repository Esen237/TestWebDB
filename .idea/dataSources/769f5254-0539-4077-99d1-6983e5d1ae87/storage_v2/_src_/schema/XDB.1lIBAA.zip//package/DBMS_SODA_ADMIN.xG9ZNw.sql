create package     DBMS_SODA_ADMIN authid current_user as

  --
  -- Error messages which we can ignore
  --
  SQL_OBJECT_EXISTS         constant number := -955;
  SQL_OBJECT_NOT_EXISTS     constant number := -942;
  SQL_INDEX_OUT_OF_BOUNDS   constant number := -6513;

  -- ORA-00054: resource busy and acquire with
  -- NOWAIT specified or timeout expired exception
  SQL_RESOURCE_BUSY         constant number := -54;

  --
  type VCTAB is table of varchar2(32767) index by binary_integer;
  type NVCTAB is table of nvarchar2(32767) index by binary_integer;
  type LTAB is table of long index by binary_integer;

  type VCNTAB is table of varchar2(32767);
  type NVCNTAB is table of nvarchar2(32767);
  type NUMNTAB is table of number;
  type INTNTAB is table of PLS_INTEGER;

  --
  -- List collections by returning a cursor which delivers two
  -- columns: the URI name and a JSON descriptor. The results
  -- are returning in URI string order.
  -- An optional argument can be used to specify a starting URI string
  -- (possibly useful for paginated reading of large schemas).
  --
  procedure LIST_COLLECTIONS(P_START_NAME in  varchar2 default null,
                             P_RESULTS    out SYS_REFCURSOR);
  --
  -- Describe a single collection. The input collection name is
  -- case-sensitive. If a match is found, the case-sensitive actual
  -- URI name is returned along with the descriptor body.
  --
  procedure DESCRIBE_COLLECTION(P_URI_NAME   in out nvarchar2,
                                P_DESCRIPTOR    out varchar2);
  --
  -- Create a collection for a specified URI name, with a specified
  -- descriptor. The URI name is case-sensitive.
  -- Note that the descriptor stored in the table may differ from
  -- from the input descriptor if values are defaulted during validation.
  --
  procedure CREATE_COLLECTION(P_URI_NAME    in     nvarchar2,
                              P_CREATE_MODE in     varchar2 default 'MAP',
                              P_DESCRIPTOR  in out varchar2,
                              P_CREATE_TIME out    varchar2,
                              P_VERBOSE     in     boolean  default false);
  --
  -- Drop a collection given the name. This forcibly drops the
  -- the collection regardless of the drop policy, which must
  -- be enforced by the calling code layer.
  --
  procedure DROP_COLLECTION(P_URI_NAME          in nvarchar2,
                            P_PURGE             in varchar2 default 'FALSE',
                            P_DROP_MAPPED_TABLE in varchar2 default 'FALSE');

  --
  -- Drops all collections in the current user's schema.
  --
  -- P_COLLECTIONS and P_ERRORS out parameters contain
  -- an array of names of the collections that could not be
  -- dropped, and an array of errors encountered when dropping
  -- these collections (P_ERRORS), respectively.
  -- These two arrays are always of the same size and correlated
  -- by the index value. For example, if returned P_COLLECTIONS
  -- and P_ERRORS are both of size 2, then 2 collections could not
  -- be dropped. In this case, P_COLLECTIONS(0) and P_ERRORS(0) will
  -- contain the name of one of these two collections that could
  -- not be dropped, and the associated error, respectively.
  -- Similarly, P_COLLECTIONS(1) and P_ERRORS(1) will return
  -- the name of another collection that could not be dropped,
  -- and the associated error. If the arrays are of size 0, then
  -- all collections were dropped successfully.
  --
  -- P_FORCE parameter, if set to true, will
  -- result in collection metadata table being cleared of
  -- all collections in the user schema, even if collections
  -- could not to be dropped due to errors encountered
  -- when attempting to drop their underlying tables/views/packages.
  --
  procedure DROP_COLLECTIONS(P_COLLECTIONS       out NVCNTAB,
                             P_ERRORS            out VCNTAB,
                             P_FORCE             in varchar2,
                             P_PURGE             in varchar2 default 'FALSE',
                             P_DROP_MAPPED_TABLE in varchar2 default 'FALSE');

  --
  -- Returns RDBMS parameters as name/value pairs.
  -- Currently returns 3 values:
  --       PKEY             P_VALUE
  --   (1) "VARCHAR2_MAX"   4000 or 32767
  --   (2) "RAW_MAX"        2000 or 32767
  --   (3) "NVARCHAR2_MAX"  2000, 4000, 16383, or 32767
  --
  procedure GET_PARAMETERS (P_KEY   in out VCTAB,
                            P_VALUE in out VCTAB);
  --
  -- Returns the database SCN value
  --
  procedure GET_SCN(P_SCN out NUMBER);

  --
  -- Returns service name (cloud), and compatible param
  --
  procedure GET_SERVICE_AND_COMPATIBLE (P_SERVICE out VARCHAR2,
                                        P_COMPATIBLE out number);
  --
  -- Returns the default metadata as CLOB
  --
  procedure GET_DEFAULT_METADATA_C(P_METADATA out clob);

  --
  -- Returns the default metadata as VARCHAR2
  --
  procedure GET_DEFAULT_METADATA_V(P_METADATA out varchar2);

  --
  -- Deletes metadata for collections that no longer have tables
  -- or views backing them up belonging to the schema it
  -- was called from.
  --
  procedure DROP_DANGLING_COLLECTIONS;
  --
  -- Deletes all entries in XDB.JSON$COLLECTION_METADATA
  -- belonging to the schema it was called from.
  --
  procedure DELETE_COLLECTION_METADATA (P_KEY in VARCHAR2);

  procedure GET_SQL_TEXT(P_SQLTEXT out varchar2);

  --
  -- Create an index based on an index specification, for a
  -- collection with the supplied URI name.
  --
  procedure CREATE_INDEX(P_URI_NAME    in  nvarchar2,
                         P_INDEX_SPEC  in  varchar2,
                         P_VERBOSE     in  boolean  default false);

  --
  -- List all the indexes on a collection with the supplied URI name,
  -- accessible to the invoker (CURRENT_USER).
  -- Returns the reconstructed descriptor of the indexes.
  -- The URI name is case-sensitive.
  --
  procedure LIST_INDEXES(P_URI_NAME          in   nvarchar2,
                         P_INDEX_NAME        in   varchar2 default null,
                         P_INDEX_SPECS       out  VCNTAB);

  --
  -- Describes the index on a collection with the supplied URI name and index
  -- name. The index must be owned by the invoker (CURRENT_USER).
  -- Returns the reconstructed descriptor of the index.
  -- The URI name is case-sensitive.
  --
  procedure DESCRIBE_INDEX(P_URI_NAME          in   nvarchar2,
                           P_INDEX_NAME        in   varchar2,
                           P_INDEX_SPEC        out  varchar2,
                           P_VERBOSE           in   boolean default false);

  --
  -- Returns the statistics for a collection as a JSON text. Statistics
  -- contain information such as total size of the collection, the number
  -- of blocks allocated for the collection, number of blocks allocated for
  -- the out of line LOB segments (if any). Setting P_FORCE_ANALYZE to TRUE
  -- refreshes the statistics information, allowing more accurate estimation
  -- of the size.
  -- The usedSize only indicates an estimate of the number of bytes used by the
  -- database object and is not an exact value.
  -- The usedSize returned are always in bytes unit.
  -- The URI name is case-sensitive.
  --
  -- A sample value returned by this API:
  -- {
  --   "name" : "SODA_COLL"     --> Name of the collection
  --   "schema" : "SCOTT"       --> Owner of the collection
  --   "blockSize" : 8192,      --> Block size of the tablespace
  --   "numRows" : 5000,        --> Number of documents in the collection
  --   "avgRowLen" : 536,       --> Average length of a document in collection
  --   "sampleSize" : 5000      --> Sample size used in analyzing collection
  --   "lastAnalyzed" :         --> Date on which this collection was most
  --      "2018-07-18T11:09:00"     recently analyzed
  --   "usedSize" : 2298150,    --> Total size used by the collection
  --   "tableBlocks" :
  --   {
  --     "allocated" : 412,     --> Number of blocks allocated for the table
  --     "empty" : 95,          --> Number of empty blocks
  --     "usedSize" : 2281766   --> Average size used by the table
  --   },
  --   "lobBlocks" :
  --   {
  --     "allocated" : 3,       --> Number of blocks allocated in LOB segment
  --     "empty" : 1,           --> Number of empty blocks
  --     "usedSize" : 16384     --> Average size used by the LOB
  --   }
  -- }
  --
  procedure GET_COLLECTION_STATISTICS(P_URI_NAME      in  nvarchar2,
                                      P_FORCE_ANALYZE in  boolean default false,
                                      P_STATISTICS    out varchar2);

  --
  -- Returns the statistics for an index on a collection as a JSON text.
  -- Statistics contain information such as type, total size of the index, the
  -- number of blocks allocated for the index and the number of unused blocks.
  -- The usedSize only indicates an estimate of the number of bytes used by the
  -- database object and is not an exact value.
  -- The usedSize returned are always in bytes unit.
  -- The URI name is case-sensitive, so is the index name.
  -- 'numRows', 'sampleSize' and 'lastAnalyzed' are reported for functional
  -- index only, not for domain (search, spatial) index.
  --
  -- A sample value returned by this API:
  -- {
  --   "name" : "SODA_COLL"     --> Name of the index
  --   "schema" : "SCOTT"       --> Owner of the index
  --   "type" : "FUNCTIONAL"    --> Type of the index
  --   "blockSize" : 8192,      --> Block size of the tablespace
  --   "numRows" : 5000         --> Number of rows in the index
  --   "sampleSize" : 5000      --> Sample size used in analyzing the index
  --   "lastAnalyzed" :         --> Date on which this index was most
  --      "2018-07-18T11:09:00"     recently analyzed
  --   "indexBlocks" :
  --   {
  --     "allocated" : 20,      --> Number of blocks allocated for the index
  --     "empty" : 3,           --> Number of empty blocks
  --     "usedSize" : 139264    --> Average size used by the index
  --   }
  -- }
  --
  procedure GET_INDEX_STATISTICS(P_URI_NAME       in   nvarchar2,
                                 P_INDEX_NAME     in   varchar2,
                                 P_FORCE_ANALYZE  in   boolean   default false,
                                 P_STATISTICS     out  varchar2);

  --
  -- Returns the usage statistics for the current schema as a JSON text.
  -- Statistics contain collection names, number of times it was accessed
  -- and its rank. P_ACCESS_TYPE can be set to 'READ', 'WRITE' or 'ALL' to
  -- filter based on access type. If P_SORT value is greater than 0, the array
  -- is ranked in ascending order, if not it is descending.
  --
  -- A sample value returned by this API:
  -- {
  --   "collections": [
  --     {
  --       "name": "coll0",
  --       "frequency": 6882558,
  --       "rank": 1
  --     },
  --     {
  --       "name": "coll5",

  --       "frequency": 133634,
  --       "rank": 2
  --     },
  --     {
  --       "name": "coll2",
  --       "frequency": 23898,
  --       "rank": 3
  --     },
  --     {

  --       "name": "coll1",
  --       "frequency": 2633,
  --       "rank": 4
  --     },

  --     {
  --       "name": "coll4",
  --       "frequency": 568,
  --       "rank": 5

  --     },
  --     {
  --       "name": "coll3",
  --       "frequency": 120,
  --       "rank": 6
  --     }
  --   ]
  -- }
  --
  procedure LIST_USAGE_STATISTICS(P_ACCESS_TYPE   in   varchar2 default 'READ',
                                  P_SORT          in   number   default 1,
                                  P_LIMIT         in   number   default 100,
                                  P_STATISTICS    out  varchar2);

  -- Creates a view with relational columns, using scalar JSON fields
  -- as specified in the data guide. A data guide-enabled JSON search
  -- index is not required for this procedure; the data guide is passed
  -- to the procedure.
  -- The URI name is case-sensitive.
  procedure CREATE_VIEW_FROM_DG(P_URI_NAME    in    nvarchar2,
                                P_VIEW_NAME   in    varchar2,
                                P_DATA_GUIDE  in    CLOB,
                                P_MATERIALIZE in    BOOLEAN DEFAULT FALSE);
  -- Replaces the value of the schemaName field in the metadata descriptor
  function CHANGE_SCHEMA(P_DESCRIPTOR in varchar2,
                         P_SCHEMA in varchar2)
    return varchar2;

  function IS_DEFAULT_ADB_COLLECTION(P_COLLECTION_NAME in nvarchar2)
    return boolean;
end DBMS_SODA_ADMIN;
/

