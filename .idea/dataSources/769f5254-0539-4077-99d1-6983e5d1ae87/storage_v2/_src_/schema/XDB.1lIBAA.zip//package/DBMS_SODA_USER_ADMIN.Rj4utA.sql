create package     DBMS_SODA_USER_ADMIN
authid current_user
is
--
  -- Creates a user for the current schema owned by CURRENT_USER
  -- Returns the 16-byte UUID assigned to the user
  -- Returns NULL if the user already existed
  procedure CREATE_USER(P_USER_NAME in nvarchar2,
                        P_DESCRIPTION in varchar2,
                        P_UID out raw);
--
  -- Change the description for a user for the current schema.
  procedure UPDATE_USER(P_UID in raw,
                        P_DESCRIPTION in varchar2);
--
  -- Create or updates the credential for a user given the UUID.
  -- This will work only for users that are owned by CURRENT_USER.
  procedure SET_CREDENTIAL(P_UID in raw,
                           P_CREDENTIAL_TYPE in varchar2,
                           P_CREDENTIAL in varchar2);
--
  -- Add a role to the specified user given the UUID.
  -- Any valid UUID can be the target of this assignment.
  -- This will create an assignment for the schema owned by CURRENT_USER.
  procedure GRANT_ROLE(P_UID in raw,
                       P_ROLE_NAME in varchar2);
--
  -- Remove a role from the specified user given the UUID.
  -- Any valid UUID can be the target.
  -- This will work for the schema owned by CURRENT_USER.
  procedure REVOKE_ROLE(P_UID in raw,
                        P_ROLE_NAME in varchar2);
--
  -- Drop a user owned by the current schema CURRENT_USER
  -- Returns the UUID of the user, or null if not found
  procedure DROP_USER(P_USER_NAME in varchar2, P_UID out raw);
--
  -- Get information about a user given the ID.
  -- All users are discoverable, even by a non-owner.
  -- If the user is owned by the current schema,
  -- creation time and description are returned.
  procedure GET_USER(P_UID in raw,
                     P_OWNER out varchar2,
                     P_USER_NAME out nvarchar2,
                     P_CREATED_ON out timestamp,
                     P_DESCRIPTION out varchar2);
--
  -- Get information about a user given the name and owner.
  -- All users are discoverable, even by a non-owner.
  procedure FIND_USER(P_OWNER in varchar2,
                      P_USER_NAME in nvarchar2,
                      P_UID out raw);
--
  -- Get a credential and the UUID for a user.
  -- The credential may be NULL, but the UUID will be returned if found.
  -- The user must be one owned by the current schema CURRENT_USER
  procedure GET_CREDENTIAL(P_USER_NAME in nvarchar2,
                           P_CREDENTIAL_TYPE in varchar2,
                           P_CREDENTIAL out varchar2,
                           P_UID out raw);
--
  -- Get roles for a user given the UUID. The current schema must own the user.
  -- The roles are those available to the user across all databases.
  procedure GET_ROLES(P_UID in raw, P_RESULTS out SYS_REFCURSOR);
--
  -- Get all users owned by the current schema
  procedure GET_USERS(P_RESULTS out SYS_REFCURSOR);
--
  -- Drop all roles granted from the current schema.
  procedure DROP_ALL_ROLES;
--
  -- Drop all users owned by the current schema.
  procedure DROP_ALL_USERS;
--
end DBMS_SODA_USER_ADMIN;
/

