create type     xdb$annotation_t                                        as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  appinfo         xdb.xdb$appinfo_list_t,
  documentation   xdb.xdb$documentation_list_t
)
 alter type     xdb$annotation_t add attribute (id varchar2(128)) cascade
/

