create trigger "XDB$STATS$xd"
    after update or delete
    on XDB$STATS
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, '86B64B676886012EE053F706E80A06B7' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, '86B64B676886012EE053F706E80A06B7', user ); END IF; END;
/

