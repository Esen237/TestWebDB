create trigger "XDB$RESCONFIG$xd"
    after update or delete
    on XDB$RESCONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '86B64B6766A6012EE053F706E80A06B7' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '86B64B6766A6012EE053F706E80A06B7', user ); END IF; END;
/

