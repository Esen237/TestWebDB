create TYPE       "FolderListingTyp" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","name" VARCHAR2(4000 CHAR),"size" NUMBER(38),"ChildName" "ChildNameCollTyp")NOT FINAL INSTANTIABLE
/

