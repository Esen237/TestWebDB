create view XDB$RCLIST_V as
(select rclist from xdb.xdb$root_info)
/

