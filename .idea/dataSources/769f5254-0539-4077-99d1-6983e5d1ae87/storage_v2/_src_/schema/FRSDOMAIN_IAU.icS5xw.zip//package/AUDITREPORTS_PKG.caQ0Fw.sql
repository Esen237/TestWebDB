create package auditreports_pkg as

    type general_refcur_type is ref cursor;

    function datasetQuery (p_component_specific_columns varchar2, p_component_specific_table varchar2, p_locale varchar2, p_translate_on varchar2, p_start_time date, p_end_time date, p_time_range integer, p_shown_component_types list_of_components, p_shown_event_types list_of_events, p_shown_event_status integer, p_predicate_on attribute_value_pairs, p_search_by attribute_value_pairs, p_sort_by varchar2, p_order_by varchar2, p_row_limit integer) return general_refcur_type;

    procedure translateByLeftJoin (p_sql_statement in out varchar2, p_locale varchar2, p_translate_on varchar2);

    v_authentication_events varchar2(256) := 'iau_base.iau_eventcategory = ''UserSession'' or iau_base.iau_eventcategory = ''Authentication''';
    v_authorization_events varchar2(256) := 'iau_base.iau_eventcategory = ''Authorization''';

end auditreports_pkg;
/

