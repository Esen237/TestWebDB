create trigger ACCESS_TOKEN_INSERT
    after insert
    on OAUTH_ACCESS_TOKEN
    for each row
begin
    insert into oauth_access_token_log
    (old_token_id, new_token_id, authentication_id, dlm, status)
    values (
    :old.token_id,
    :new.token_id,
    :new.authentication_id,
    sysdate,
    'inserted');
end;

/

