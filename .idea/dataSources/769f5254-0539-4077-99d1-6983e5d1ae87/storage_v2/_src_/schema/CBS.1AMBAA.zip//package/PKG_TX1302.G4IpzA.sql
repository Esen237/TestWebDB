create PACKAGE     PKG_TX1302 IS
/******************************************************************************
   Name       : PKG_TX1302
   Created By : Seval Balci
   Date       : 21.10.03
   Purpose    : Kredi Teklif Onay/Red
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);             -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);           -- Islem dogrulandiktan sonra cagrilir
  Procedure    Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);                -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);            -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);               -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);               -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);               -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);               -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);          -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);      -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Musteri_Limit_Guncelle(pn_islem_no number);
  Procedure Teklif_limit_satir_guncelle(pn_islem_no number);
  Procedure sp_teklif_Satir_sifirlanmissa(pn_islem_no number);
  Function sf_teklif_hesap_mevcutmu(pn_teklif_Satir_no NUMBER) RETURN VARCHAR2;
  Function sf_teklif_risk_mevcutmu(pn_musteri_no number,pn_urun_grub_no number,pn_teklif_Satir_no NUMBER) RETURN VARCHAR2;
  Function sf_credit_accounts_close(pn_islem_no number, pn_eom_close boolean) RETURN BOOLEAN;
     /*   cbs-366 Transfer last approved limit from 1302 to 7157   GulkaiyrK*/
  PROCEDURE musteri_limit(pn_musteri         IN  NUMBER,
                           pn_limit           OUT NUMBER,
                           ps_limit_cy        OUT VARCHAR2,
                           pn_teklif_satir_no OUT VARCHAR2,
                           pn_urun_Grup_no    OUT VARCHAR2   ) ;
  PROCEDURE Installment_Notif(pn_islem_no number); --BahianaB CBS-677 Installment Notification 05092022                        
END;
/

