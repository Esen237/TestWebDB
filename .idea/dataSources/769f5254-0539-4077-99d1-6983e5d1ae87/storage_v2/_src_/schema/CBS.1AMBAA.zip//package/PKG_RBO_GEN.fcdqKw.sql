create package pkg_RBO_gen 
is 
    function generate_rbo_4_15 (pc_ref_in in sys_refcursor, pn_num number) return varchar2_ntt;
end;
/

