create PACKAGE     PKG_INT_QR_TRX IS
/******************************************************************************
    Name       : PKG_INT_QR_TRX
    Created By : Yadgar Babaev
    Date       : 15/11/2022
    Purpose    : CBS-793: QR STANDARDIZATION / IPC Integration
******************************************************************************/
    TYPE CursorReferenceType IS REF CURSOR;

    FUNCTION CreateQrPaymentRequest(ps_customer_id varchar2,
                                    ps_source_iban varchar2,
                                    ps_tran_type varchar2,
                                    pn_amount number,
                                    ps_recipient varchar2,
                                    ps_description varchar2,
                                    pc_ref OUT CursorReferenceType) RETURN varchar2;
    FUNCTION GetTransaction(ps_transaction_number number,
                            ps_ipc_transaction_id varchar2,
                            ps_acquirer_bic varchar2,
                            ps_merchant_provider varchar2,
                            pn_fee number,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType) RETURN varchar2;
    FUNCTION Blocking(ps_transaction_number number,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType) RETURN varchar2;
    FUNCTION SetFinalStatus(ps_transaction_number number, ps_status varchar2, ps_description varchar2 DEFAULT NULL) RETURN varchar2;
    FUNCTION CreateQrBeneficiaryTransaction(ps_transaction_type varchar2,
                                            ps_target_iban varchar2,
                                            pn_amount number,
                                            ps_provider varchar2,
                                            ps_description varchar2,
                                            ps_ipc_transaction_id varchar2,
                                            ps_aqr_transaction_id varchar2,
                                            ps_aqr_client_type varchar2,
                                            ps_aqr_check_number varchar2,
                                            ps_our_qr varchar2,
                                            pc_ref OUT CursorReferenceType) RETURN varchar2;
    FUNCTION ExecuteQrBeneficiaryTransaction(ps_ipc_transaction_id varchar2, pc_ref OUT CursorReferenceType) RETURN varchar2;
END;
/

