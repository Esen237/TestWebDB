create PACKAGE PKG_TX4002 IS

 /******************************************************************************
   Name       : PKG_TX4002
   Created By : Bilal GUL
   Purpose	  : Giden YP Havale Provizyon Iptal
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir


  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);


END;


/

