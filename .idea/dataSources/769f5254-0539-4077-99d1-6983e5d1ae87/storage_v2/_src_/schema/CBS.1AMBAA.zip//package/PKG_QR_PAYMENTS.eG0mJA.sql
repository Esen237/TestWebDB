create PACKAGE     "PKG_QR_PAYMENTS" IS

PROCEDURE Participant_Banks_Add (--ps_bank_id              NUMBER,
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2 DEFAULT '0',
                                 pd_registration_date    DATE DEFAULT SYSDATE,
                                 pd_closing_date         DATE DEFAULT NULL,
                                 pd_closed_user         VARCHAR2 DEFAULT NULL                       
                                 ) ;
PROCEDURE Participant_Banks_Update (ps_bank_id              NUMBER,
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2,
                                 pd_registration_date    DATE,
                                 pd_closing_date         DATE,
                                 pd_closed_user         VARCHAR2                              
                                 );                                
                               
PROCEDURE  Participant_Apps_Add (pn_bank_id              NUMBER,
                           --  pn_app_id               NUMBER , --add unique constraint 
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         VARCHAR2,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             pd_registration_date    DATE DEFAULT SYSDATE, 
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE DEFAULT NULL,
                             ps_closed_user          VARCHAR2 DEFAULT NULL ,
                             ps_port                 VARCHAR2, 
                             ps_path                 VARCHAR2                                        
                               ) ;
PROCEDURE  Participant_Apps_Update (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER,
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         VARCHAR2,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,                            
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE,
                             ps_closed_user          VARCHAR2,
                             ps_port                 VARCHAR2,
                             ps_path                 VARCHAR2                                         
                               );                                                                                
PROCEDURE  Bank_Limit_Setting(pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE,
                              ps_type                VARCHAR2
                              ); 
PROCEDURE  App_Limit_Setting (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              pn_app_limit           NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              );                              
PROCEDURE  App_Comission_Def (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              ps_comission_code      VARCHAR2,
                              ps_comission_rate      VARCHAR2,
                              ps_is_fix_comission    VARCHAR2,                         
                              ps_is_exemption        VARCHAR2
                              );                             
PROCEDURE  Add_App_Users (pn_bank_id             NUMBER,                        
                          ps_username            VARCHAR2,
                          ps_password            VARCHAR2,
                          pn_role                NUMBER,
                          ps_status              VARCHAR2,                         
                          ps_is_exemption        VARCHAR2,
                          ps_created_user        VARCHAR2,
                          pd_create_date         DATE DEFAULT SYSDATE,
                          ps_deactivate_user     VARCHAR2,
                          pd_deactivate_date     DATE,
                          pn_app_id              NUMBER 
                          ); 
PROCEDURE  Update_App_Users (pn_bank_id             NUMBER,                        
                             ps_username            VARCHAR2,
                             --ps_password            VARCHAR2,
                             pn_role                NUMBER,
                             ps_status              VARCHAR2,                                                   
                             ps_deactivate_user     VARCHAR2,
                             pd_deactivate_date     DATE,
                             ps_changed_user       VARCHAR2
                          --   ps_force_password       VARCHAR2 DEFAULT 'YES',
                            -- pn_app_id              NUMBER
                          );                                                                                     
PROCEDURE  Eod_Daily_Transactions;
FUNCTION Get_Bank_ID_By_App (pn_app_id NUMBER) RETURN NUMBER;
FUNCTION Get_App_Name_By_App (pn_app_id NUMBER) RETURN VARCHAR;   
FUNCTION Get_Bank_Account_By_App (pn_app_id NUMBER) RETURN NUMBER;  
PROCEDURE  QR_Transactions ( ps_operator_transaction_id    VARCHAR2,
                            pn_sender_bank_bic             NUMBER,
                            pn_sender_app_id               NUMBER,
                            pn_sender_customer_type        NUMBER,
                            ps_sender_transaction_no       VARCHAR2,--NUMBER,
                            ps_sender_receipt_no           VARCHAR2, --NUMBER,--VarCchar 2
                            pn_transaction_type            NUMBER,
                            ps_qr_type                     VARCHAR2,
                            ps_qr_merchant_provider        VARCHAR2,
                            ps_qr_merchant_id              VARCHAR2,
                            ps_qr_service_id               VARCHAR2,
                            ps_qr_service_name             VARCHAR2,
                            pn_qr_ben_account_number       VARCHAR2,
                            pn_qr_merchant_code            NUMBER,
                            pn_qr_currency_code            NUMBER,
                            ps_qr_transaction_id           VARCHAR2,
                            ps_qr_comment                  VARCHAR2,
                            pn_qr_amount                   NUMBER,
                            pn_comission                   NUMBER, 
                            ps_qr_link_hash                VARCHAR2, 
                            pd_create_request_time         DATE                 DEFAULT SYSDATE,
                            pn_beneficiary_bank_bic        NUMBER,
                            pn_beneficiary_app_id          NUMBER,
                            ps_beneficiary_name            VARCHAR2,
                            pn_ben_customer_type           NUMBER,
                            ps_ben_receipt_no              VARCHAR2,--NUMBER,
                            pd_create_response_time        DATE,
                            pn_create_status               NUMBER,
                            pd_execute_request_time        DATE,
                            pd_execute_process_time        DATE,
                            pd_error_time                  DATE,
                            pn_final_status                NUMBER,
                            ps_is_our_network              VARCHAR2, 
                            ps_other_operator_id           VARCHAR2           
                               );  
PROCEDURE  QR_Check_Transactions (pn_sender_app_id              NUMBER,
                                  pn_sender_customer_type       NUMBER,
                                  ps_qr_type                    VARCHAR2,
                                  ps_qr_merchant_provider       VARCHAR2,
                                  ps_qr_merchant_id             VARCHAR2,
                                  ps_qr_service_id              VARCHAR2,
                                  ps_qr_service_name            VARCHAR2,
                                  ps_qr_ben_account_number      VARCHAR2,
                                  pn_qr_merchant_code           NUMBER,
                                  pn_qr_currency_code           NUMBER,
                                  ps_qr_transaction_id          VARCHAR2,
                                  ps_qr_comment                 VARCHAR2,
                                  pn_qr_amount                  NUMBER,
                                  ps_qr_link_hash               VARCHAR2,
                                  pd_requested_date             DATE ,
                                  pn_beneficiary_app_id_number  NUMBER,
                                  ps_beneficiary_name           VARCHAR2,
                                  pn_ben_customer_type          NUMBER,
                                  pn_operator_tran_type         NUMBER,
                                  pn_check_status               NUMBER,
                                  pd_response_date              DATE            
                               ) ; 
FUNCTION Is_Internal (pn_sender_bic NUMBER, pn_beneficiary_bic NUMBER) RETURN VARCHAR;                              

PROCEDURE Get_App_By_App_Id (pn_app_id IN NUMBER, pc_ref OUT SYS_REFCURSOR);
FUNCTION Token_Update (pn_app_id NUMBER, ps_token VARCHAR2,pn_signing_version NUMBER) RETURN NUMBER;
FUNCTION Revoke_Token_Param_Update (pn_app_id NUMBER, ps_revoke_token VARCHAR2) RETURN NUMBER;
PROCEDURE Get_Transaction_By_Sender_Tx_Id (pn_sender_tx_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Bank_Balance_Info (ps_bank_id IN NUMBER, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Application_Balance_Info (ps_bank_id IN NUMBER,ps_app_id IN NUMBER, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Transaction_By_Bank_Id (ps_bank_id IN VARCHAR,ps_app_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR);
FUNCTION Get_Bank_BIC_By_Id (pn_bank_id NUMBER) RETURN NUMBER;
PROCEDURE  Get_QR_Transactions (pn_bank_id                 NUMBER,--qroperator_app.participant_banks 
                                pn_app_id           NUMBER DEFAULT NULL,
                                pd_start_date              VARCHAR2 DEFAULT NULL,
                                pd_end_date                VARCHAR2 DEFAULT NULL,
                                ps_status                  NUMBER DEFAULT NULL,
                                pn_page_index              NUMBER,
                                pn_page_size               NUMBER,
                                ps_operator_transaction_id    VARCHAR2 DEFAULT NULL,
                                pc_ref OUT SYS_REFCURSOR                     
                               );
PROCEDURE Get_App_By_Qr_Provider (pn_qr_provider IN VARCHAR, pc_ref OUT SYS_REFCURSOR);
PROCEDURE  Get_EOD_Operations(pn_bank_id           NUMBER,                                 
                              pd_date              DATE DEFAULT SYSDATE,
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                                 
                              pc_ref OUT SYS_REFCURSOR                     
                               );
PROCEDURE  Get_EOD_Net_Gross_Positions(                             
                              pd_date                    DATE DEFAULT SYSDATE,
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                               
                              pc_ref OUT SYS_REFCURSOR                     
                               ); 
PROCEDURE  Get_B2B_Positions(                             
                              pd_date                    DATE DEFAULT SYSDATE,
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                                
                              pc_ref OUT SYS_REFCURSOR                     
                               );                               
FUNCTION Get_Bank_Name_By_Id (pn_bank_id NUMBER) RETURN VARCHAR2;
FUNCTION Get_App_Name_By_Bank_Id (pn_bank_id NUMBER) RETURN VARCHAR2;                              
PROCEDURE Get_Bank_Limits (pn_bank_id NUMBER DEFAULT NULL, pc_ref OUT SYS_REFCURSOR );                              
PROCEDURE Get_App_Limits (pn_bank_id NUMBER DEFAULT NULL, pc_ref OUT SYS_REFCURSOR ); 
FUNCTION Get_Status_Name_By_Code (pn_code NUMBER) RETURN VARCHAR2;
PROCEDURE Get_Status_List (pc_ref OUT SYS_REFCURSOR); 
PROCEDURE Get_Participant_Banks_List (pn_bank_id NUMBER,pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Participant_Apps_List (pn_bank_id NUMBER, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Transaction_Details (ps_trx_no VARCHAR2,pc_ref OUT SYS_REFCURSOR);
FUNCTION Get_Transaction_Name_By_Type (ps_type VARCHAR2) RETURN VARCHAR2;  
FUNCTION Update_Trx_By_Transaction_ID (ps_transaction_id VARCHAR2,pd_execute_request_time DATE,pd_execute_process_time DATE,pn_final_status NUMBER) RETURN NUMBER; 
FUNCTION Update_Trx_By_Trans_ID_Err (ps_transaction_id VARCHAR2,pn_final_status NUMBER,pd_error_time DATE) RETURN NUMBER;  
PROCEDURE Get_User_By_Username (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_User_Roles (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR);     
PROCEDURE Auth_Connected_User (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR); 
FUNCTION Get_Role_By_Username (ps_username VARCHAR2) RETURN NUMBER; 
PROCEDURE Get_Participant_Banks_All_Info (pn_bank_id NUMBER,pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Participant_Apps_All_Info (pn_app_id NUMBER,pc_ref OUT SYS_REFCURSOR);
FUNCTION Get_Role_Name_By_ID (pn_role_id NUMBER) RETURN VARCHAR2;
PROCEDURE Get_Comission_List (pn_app_id NUMBER,pc_ref OUT SYS_REFCURSOR);  
FUNCTION Get_Comm_Descr_By_Comm_Code (ps_code VARCHAR2) RETURN VARCHAR2;  
PROCEDURE Get_Comission_Types_List (pc_ref OUT SYS_REFCURSOR); 
FUNCTION Update_Comission (pn_app_id NUMBER,ps_comission_code VARCHAR2,ps_comission_rate VARCHAR2,ps_is_fix_comission VARCHAR2,ps_is_exemption VARCHAR2) RETURN NUMBER;
 PROCEDURE  Holidays_Add ( pn_day              DATE,                         
                          ps_explanation      VARCHAR2,
                          ps_status           VARCHAR2,
                          pd_created_date     DATE,
                          ps_created_user     VARCHAR2                                                                            
                               );  
 FUNCTION Update_Holidays (pd_day DATE,                           
                           ps_explanation      VARCHAR2,
                           ps_status           VARCHAR2,
                           pd_created_date     DATE,
                           ps_created_user     VARCHAR2) RETURN NUMBER;
PROCEDURE Get_Transaction_By_Tx_Id (pn_tx_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Holidays_Info (pd_day DATE,pc_ref OUT SYS_REFCURSOR);
FUNCTION Modify_Holidays (pd_day DATE) RETURN NUMBER;
PROCEDURE Get_Application_Types_Info (pc_ref OUT SYS_REFCURSOR);
PROCEDURE  Eod_Net_Gross;
PROCEDURE Get_Reconciliation  (pn_bank_id IN NUMBER,pn_app_id IN NUMBER ,pd_bank_date DATE,
                               pn_page_index NUMBER, pn_page_size NUMBER, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Lps_Online (pn_page_index NUMBER,pn_page_size NUMBER,pd_date DATE, pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Summary_Data (pd_date DATE, pn_bank_id NUMBER,pn_app_id NUMBER, 
                               pn_page_index NUMBER,pn_page_size NUMBER,pc_ref OUT SYS_REFCURSOR);
FUNCTION Remote_User_Pass_Update (ps_username VARCHAR, ps_password VARCHAR2,ps_force_password VARCHAR,ps_connection_user VARCHAR) RETURN NUMBER;
PROCEDURE Get_External_Transactions_In_Process(pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Xsigning_Version(pc_ref OUT SYS_REFCURSOR);
PROCEDURE Get_Limit_Type(pc_ref OUT SYS_REFCURSOR);
PROCEDURE Bank_Lim_Updating_By_Status (ps_state VARCHAR2, ps_msg_type VARCHAR2, pn_docs_amount NUMBER, pn_batch_no NUMBER);
FUNCTION Get_App_Type_By_Code (ps_application_code VARCHAR2) RETURN VARCHAR2;
PROCEDURE Reserve_Update (pn_bic NUMBER, pn_reserve NUMBER);
PROCEDURE  Bank_Limit_Adding (pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE,
                              ps_type                VARCHAR2
                              );
END;
/

