create PACKAGE pkg_X_PRBO36 IS

/******************************************************************************
   Name       : pkg_X_PRBO36
   Created By : Artem
   Date    	  : 27.11.2008
   Purpose	  : Создание отчета PRBO36 для НБКР
******************************************************************************/

Out_File UTL_FILE.FILE_TYPE;
In_File	UTL_FILE.FILE_TYPE;

PROCEDURE control_Module_PRBO36(Prbo_Date DATE);
PROCEDURE generate_Table_PRBO36 (Prbo_Code VARCHAR2,P_Day NUMBER,P_Month NUMBER,P_Year NUMBER,Prbo_Date DATE);
PROCEDURE generate_CSV_PRBO36;
PROCEDURE generate_CSV_PRBO36_EOM;


END;


/

