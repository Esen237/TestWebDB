create PACKAGE BODY     "PKG_KREDI_RAPOR" is

/******************************************************************************
   NAME       : PKG_KREDI_RAPOR
   Created By : Seval Balci
   Date          : 19.01.04
   Purpose      :Kredi izleme ve rapor ile ilgili procedur ve fonksiyonlari icerir.
******************************************************************************/

 /*****************************************************************************************************************/
 /*   Function sf_birikmis_hesapla                                                             */
 /****************************************************************************************************************/
 Function sf_birikmis_hesapla(ps_hesaplama_secimi varchar2,pn_gun number ,pn_tutar number,pn_oran number , ps_doviz_kodu varchar2 ,pn_esas_gun number default 360 ) return number
 is
   ln_tutar number := 0;
 Begin
      if ps_hesaplama_secimi  != 'MEVCUT' then
            if pn_esas_gun <> 0 and  pn_gun <> 0 and pn_tutar <> 0 and pn_oran <>0 then
             ln_tutar := nvl(pkg_kur.yuvarla(ps_doviz_kodu ,  abs(nvl(pn_gun,0) * nvl(pn_tutar,0) * nvl(pn_oran,0) /  ( nvl(pn_esas_gun,360) *100 ))),0);
           end if;
      end if;

       return nvl(ln_tutar,0);

    exception when others then return 0;

 End;

 Function sf_vade_fark_sure(ps_songun_faizi varchar2,
                            pd_kredi_vade date ) return number
  is
   ln_sure number := 0;
 Begin

     if ps_songun_faizi = 'E' then
         ln_sure := pkg_tarih.ileri_is_gunu(trunc(pd_kredi_vade))  -  trunc(pkg_muhasebe.banka_tarihi_bul);
     else
         ln_sure := trunc(pd_kredi_vade) - trunc(pkg_muhasebe.banka_tarihi_bul);
     end if;

     return nvl(ln_sure,0);

    exception when others then return 0;

 End;

 Function sf_faiztahak_fark_sure(ps_songun_faizi varchar2,
                            pd_faiztahak_tarihi date ) return number

  is
   ln_sure number := 0;
 Begin
      if trunc(pd_faiztahak_tarihi) =    trunc(pkg_muhasebe.banka_tarihi_bul) then
            ln_sure :=0;
       else
          ln_sure := trunc(pd_faiztahak_tarihi)  - trunc(pkg_muhasebe.banka_tarihi_bul) + 1;
       end if;
     return nvl(ln_sure,0);

    exception when others then return 0;

 End;



 /*****************************************************************************************************************/
 /*  Function sf_bsmv_hesapla                                                             */
 /****************************************************************************************************************/
 Function sf_bsmv_hesapla(
                          ps_vade_faiz_tahak_secim varchar2,
                          ps_doviz_kodu varchar2,
                          ps_endeks_doviz_kodu varchar2,
                          pn_acilis_kuru number,
                          pn_hesap_no cbs_hesap_kredi.hesap_no%type,
                              pn_tutar number,
                          pn_endeks_doviz_tutar number,
                          ps_bsmv_alinsin varchar2 default 'E'  ) return number
 is
  ln_kur         number  := 0;
  ln_bsmv_tutar  number := 0;
  ln_tutar       number := abs(pn_tutar);
  ln_endeks_tutar number := 0;
 Begin
       ln_kur := nvl(pkg_kur.doviz_doviz_karsilik(    ps_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'O','A'),0);
      ln_bsmv_tutar := PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',ps_doviz_kodu, PN_HESAP_NO, ln_tutar,ln_kur , 'H', null,ps_BSMV_ALINSIN );

           if ps_endeks_doviz_kodu is not null then
              /* DEK ise */
             /* vadeye kadar seciminde */
             if  ps_vade_faiz_tahak_secim = 'KREDI_VADE' then
                     if ln_kur > nvl(pn_acilis_kuru,0) then
                         ln_kur := ln_kur - nvl(pn_acilis_kuru,0) ;
                          ln_endeks_tutar := PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',ps_doviz_kodu, PN_HESAP_NO,abs(pn_endeks_doviz_tutar),ln_kur , 'H', null,ps_BSMV_ALINSIN );
                     end if;
                   ln_bsmv_tutar := nvl(ln_bsmv_tutar,0) + nvl(ln_endeks_tutar,0) ;
             end if;
         end if;

    return nvl(ln_bsmv_tutar ,0);

 End ;

 /*****************************************************************************************************************/
 /*  Function sf_kkdf_hesapla                                                             */
 /****************************************************************************************************************/
 Function sf_kkdf_hesapla(
                          ps_vade_faiz_tahak_secim varchar2,
                          ps_doviz_kodu varchar2,
                          ps_endeks_doviz_kodu varchar2,
                          pn_sonislem_kuru number,
                          pn_hesap_no cbs_hesap_kredi.hesap_no%type,
                              pn_tutar number,
                          pn_endeks_doviz_tutar number,
                          ps_kkdf_alinsin varchar2 default 'E'  ) return number
 is
  ln_kur         number  := 0;
  ln_bsmv_tutar  number := 0;
  ln_tutar       number := abs(pn_tutar);
  ln_endeks_tutar number := 0;
 Begin
       ln_kur := nvl(pkg_kur.doviz_doviz_karsilik(    ps_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'O','A'),0);
      ln_bsmv_tutar := PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',ps_doviz_kodu, PN_HESAP_NO, ln_tutar,ln_kur , 'H', ps_kkdf_ALINSIN,null );

           if ps_endeks_doviz_kodu is not null then
              /* DEK ise */
             /* vadeye kadar seciminde */
             if  ps_vade_faiz_tahak_secim = 'FAIZ_TAHAK' then
                     if ln_kur > nvl(pn_sonislem_kuru,0) then
                         ln_kur := ln_kur - nvl(pn_sonislem_kuru,0) ;
                          ln_endeks_tutar := PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',ps_doviz_kodu, PN_HESAP_NO,abs(pn_endeks_doviz_tutar),ln_kur , 'H', ps_kkdf_ALINSIN ,null );
                     end if;
                   ln_bsmv_tutar := nvl(ln_bsmv_tutar,0) + nvl(ln_endeks_tutar,0) ;
             end if;
         end if;

    return nvl(ln_bsmv_tutar ,0);

 End ;


 procedure sp_birikmisfaiz_kkdfhesapla
  (
              pn_hesap_no                 number,
              ps_hesaplama_secimi      varchar2,
            pd_tarih2 date,
            pd_girilen_tarih date ,
            pn_birikmis_faiz out number,
            pn_birikmis_kom out number,
            pn_kkdf out number,
            pn_bsmv out number
         )
 is
 ln_gun number := 0;
 ls_vade_tahak_secim  varchar2(200);
  cursor cursor_hesap is
     select
            hesap_no,
            doviz_kodu,
            endeks_doviz_kodu,
           son_gun_faizi,
           kredi_vade,
           faiz_tahakkuk_tarihi,
            acilis_kuru,
           esas_gun_sayisi,
           birikmis_faiz_toplam,
           birikmis_komisyon_toplam,
           faiz_orani,
           komisyon_orani ,
           endeks_doviz_tutari,
           bsmv_alinsin,
           kkdf_alinsin,
          nvl( abs( pkg_kredi.sf_bakiye_al(hesap_no)),0) bakiye
     from  cbs_vw_kredi_hesap_izleme
     where hesap_no = pn_hesap_no ;


 Begin

     for cur_hesap in cursor_hesap loop
           /*vade tarihi girilen tarihden kucuk esit ise */
         if    ps_hesaplama_secimi != 'TARIH' then
                if cur_hesap.kredi_vade <= pd_tarih2 then
                  ls_vade_tahak_secim := 'KREDI_VADE';
                  ln_gun := sf_vade_fark_sure(cur_hesap.son_gun_faizi ,    cur_hesap.kredi_vade );
               else
                    ls_vade_tahak_secim  := 'FAIZ_TAHAK';
                     ln_gun := sf_faiztahak_fark_sure(cur_hesap.son_gun_faizi ,cur_hesap.faiz_tahakkuk_tarihi );
              end if;
           else
                   ln_gun :=  (pd_girilen_tarih - pkg_muhasebe.banka_tarihi_bul )  + 1;
         end if;


/*birikmis faiz ve komisyon toplami */
      pn_birikmis_faiz := abs( nvl(cur_hesap.BIRIKMIS_FAIZ_TOPLAM,0) ) + abs(nvl( pkg_kur.yuvarla(cur_hesap.doviz_kodu, sf_birikmis_hesapla(ps_hesaplama_secimi,ln_gun,cur_hesap.bakiye,cur_hesap.faiz_orani ,cur_hesap.doviz_kodu,cur_hesap.esas_gun_sayisi  )),0));
      pn_birikmis_kom :=  abs(nvl(cur_hesap.BIRIKMIS_KOMISYON_TOPLAM,0)) +abs(nvl(pkg_kur.yuvarla(cur_hesap.doviz_kodu, sf_birikmis_hesapla(ps_hesaplama_secimi,ln_gun,cur_hesap.bakiye,cur_hesap.komisyon_orani ,cur_hesap.doviz_kodu,cur_hesap.esas_gun_sayisi )),0));

    /* bsmv hesaplama */
    pn_bsmv :=  pkg_kur.yuvarla(cur_hesap.doviz_kodu, pkg_kredi_rapor.sf_bsmv_hesapla
    (
                              ls_vade_tahak_secim ,
                              cur_hesap.doviz_kodu,
                              cur_hesap.endeks_doviz_kodu,
                              cur_hesap.acilis_kuru,
                              cur_hesap.hesap_no,
                                  NVL(pn_birikmis_faiz ,0) + NVL(pn_birikmis_kom,0)  ,
                              cur_hesap.endeks_doviz_tutari,
                               cur_hesap.bsmv_alinsin) );
   /* kkdf hesaplama */
    pn_kkdf := pkg_kur.yuvarla(cur_hesap.doviz_kodu,  pkg_kredi_rapor.sf_kkdf_hesapla(
                              ls_vade_tahak_secim ,
                              cur_hesap.doviz_kodu,
                              cur_hesap.endeks_doviz_kodu,
                              cur_hesap.acilis_kuru,
                              cur_hesap.hesap_no,
                                  NVL(pn_birikmis_faiz ,0)  ,
                              cur_hesap.endeks_doviz_tutari,
                               cur_hesap.kkdf_alinsin)) ;

  end loop;
 End;



 /*****************************************************************************************************************/
 /*  procedure sp_insert_kredivade_faiz                                                                         */
 /****************************************************************************************************************/
 procedure sp_insert_kredivade_faiz (
                p_rapor_islem_no    cbs_rpt_kredivade_faiz.    rapor_islem_no%type,
                p_hesap_no    cbs_rpt_kredivade_faiz.    hesap_no%type,
                p_musteri_no    cbs_rpt_kredivade_faiz.    musteri_no%type,
                p_unvan    cbs_rpt_kredivade_faiz.    unvan%type,
                p_doviz_kodu    cbs_rpt_kredivade_faiz.    doviz_kodu%type,
                p_durum_kodu    cbs_rpt_kredivade_faiz.    durum_kodu%type,
                p_sube_kodu    cbs_rpt_kredivade_faiz.    sube_kodu%type,
                p_kredi_vade                            cbs_rpt_kredivade_faiz.kredi_vade%type,
                p_endeks_doviz_kodu                        cbs_rpt_kredivade_faiz.endeks_doviz_kodu%type,
                p_faiz_orani                            cbs_rpt_kredivade_faiz.faiz_orani%type,
                p_faiz_tahakkuk_tarihi                    cbs_rpt_kredivade_faiz.faiz_tahakkuk_tarihi%type,
                p_komisyon_orani                        cbs_rpt_kredivade_faiz.komisyon_orani%type,
                p_kredi_turu_nakit_gayri                cbs_rpt_kredivade_faiz.kredi_turu_nakit_gayri%type,
                p_bakiye                                cbs_rpt_kredivade_faiz.bakiye%type,
                p_birikmis_faiz_tutari                    cbs_rpt_kredivade_faiz.birikmis_faiz_tutari%type,
                p_birikmis_komisyon_tutari                cbs_rpt_kredivade_faiz.birikmis_komisyon_tutari%type,
                p_kkdf                                    number,
                p_bsmv                                    number,
                p_modul_tur_kod                            cbs_rpt_kredivade_faiz.modul_tur_kod%type,
                p_urun_tur_kod                            cbs_rpt_kredivade_faiz.urun_tur_kod%type,
                p_urun_sinif_kod                        cbs_rpt_kredivade_faiz.urun_sinif_kod%type
 )is pragma autonomous_transaction;
 Begin
       insert into cbs_rpt_kredivade_faiz
      (
          rapor_islem_no    ,
        hesap_no    ,
        musteri_no    ,
        unvan    ,
        doviz_kodu    ,
        durum_kodu    ,
        sube_kodu    ,
        kredi_vade    ,
        endeks_doviz_kodu    ,
        faiz_orani    ,
        faiz_tahakkuk_tarihi    ,
        komisyon_orani    ,
        kredi_turu_nakit_gayri    ,
        bakiye    ,
        birikmis_faiz_tutari    ,
        birikmis_komisyon_tutari,
        kkdf,
        bsmv,
        modul_tur_kod,
        urun_tur_kod,
        urun_sinif_kod    )
    values
     ( p_rapor_islem_no    ,
        p_hesap_no    ,
        p_musteri_no    ,
        p_unvan    ,
        p_doviz_kodu    ,
        p_durum_kodu    ,
        p_sube_kodu    ,
        p_kredi_vade    ,
        p_endeks_doviz_kodu    ,
        p_faiz_orani    ,
        p_faiz_tahakkuk_tarihi    ,
        p_komisyon_orani    ,
        p_kredi_turu_nakit_gayri    ,
        p_bakiye    ,
        p_birikmis_faiz_tutari    ,
        p_birikmis_komisyon_tutari,
        p_kkdf,
        p_bsmv,
        p_modul_tur_kod,
        p_urun_tur_kod,
        p_urun_sinif_kod
        );

    commit;

 End;

 /*****************************************************************************************************************/
 /*  Function  sf_vade_mevcutmu girilen max tarih icerisinde vade tarihi olan varsa E dondurulur                    */
 /****************************************************************************************************************/
Function sf_vade_mevcutmu(pd_tarih date,pd_vade_tarih date ) return varchar2
 is
 Begin
       if trunc(pd_vade_tarih)  <=  trunc(pd_tarih) then
         return 'E';
       else
         return 'H';
       end if;
 End;

 /*****************************************************************************************************************/
 /*  Function sf_doviz_endk_toplami                                                                                 */
 /****************************************************************************************************************/
/* konsolide risk izleme ile ilgili fonk.*/
 Function sf_doviz_endk_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
  is
   ln_tutar number := 0;
 Begin
       select sum(nvl(pkg_kredi.SF_BAKIYE_AL(hesap_no),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
            doviz_kodu = pkg_genel.lc_al and
            endeks_doviz_kodu is not null and
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E' ;

       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;
 /*****************************************************************************************************************/
 /*   Function sf_nakdi_tl_toplami                                                                             */
 /****************************************************************************************************************/
 Function sf_nakdi_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
 is
   ln_tutar number := 0;
 Begin
       select sum(nvl(pkg_kredi.SF_BAKIYE_AL(hesap_no),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
            doviz_kodu = pkg_genel.lc_al and
            endeks_doviz_kodu is null and
            urun_tur_kod not in ( 'NOSTRO-LC','NOSTRO-FC') and
            pkg_GENEL.URUN_SINIF_NAKDIMI(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E' AND
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E'
            and urun_tur_kod <>'LEASING';

       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;

  /*****************************************************************************************************************/
 /*   Function sf_nakdi_YP_toplami                                                                             */
 /****************************************************************************************************************/
 Function sf_nakdi_YP_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
 is
   ln_tutar number := 0;
 Begin
       select
          SUM( nvl(pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,pkg_kredi.SF_BAKIYE_AL(hesap_no),1,null,null,'N','A'),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
            doviz_kodu <> pkg_genel.lc_al and
            endeks_doviz_kodu is null and
            urun_tur_kod not in ( 'NOSTRO-LC','NOSTRO-FC') and
            pkg_GENEL.URUN_SINIF_NAKDIMI(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E' AND
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E'
            and urun_tur_kod <>'LEASING';

       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;

  /*****************************************************************************************************************/
 /*    Function sf_gayrinakdi_tl_toplami                                                                         */
 /****************************************************************************************************************/
 Function sf_gayrinakdi_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
 is
   ln_tutar number := 0;
 Begin
       select sum(nvl(pkg_kredi.SF_BAKIYE_AL(hesap_no),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
            doviz_kodu = pkg_genel.lc_al and
            endeks_doviz_kodu is null and
            pkg_GENEL.URUN_SINIF_NAKDIMI(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'H' AND
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E'
            and urun_tur_kod <>'LEASING';
       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;

  /*****************************************************************************************************************/
 /*     Function sf_gayrinakdi_yp_toplami                                                                         */
 /****************************************************************************************************************/
 Function sf_gayrinakdi_yp_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
 is
   ln_tutar number := 0;
 Begin
     select  SUM( nvl(pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,pkg_kredi.SF_BAKIYE_AL(hesap_no),1,null,null,'N','A'),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
            doviz_kodu <> pkg_genel.lc_al and
            endeks_doviz_kodu is null and
            pkg_GENEL.URUN_SINIF_NAKDIMI(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'H' AND
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E'
            and urun_tur_kod <>'LEASING';
       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;

 /*****************************************************************************************************************/
 /*   Function sf_leasing_tl_toplami                                                                     */
 /****************************************************************************************************************/
Function sf_leasing_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number
is
   ln_tutar number := 0;
 Begin
       select  SUM( nvl(pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,pkg_kredi.SF_BAKIYE_AL(hesap_no),1,null,null,'N','A'),0))
      into ln_tutar
       from cbs_hesap_kredi
      where musteri_no =  pn_musteri_no and
            durum_kodu = ps_durum_kodu and
         --   doviz_kodu = pkg_genel.lc_al and
            urun_tur_kod = 'LEASING' and
            pkg_limit.urun_sinif_risklimi(modul_tur_kod,urun_tur_kod,urun_sinif_kod ) = 'E' ;

       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;

 /*****************************************************************************************************************/
 /* Function sf_kullandirim_tutar asagidaki listesi verilen islemleri icerir.                                  */
/*  Kullandirim artt?r?m ise tutar dondurulmeli diger durumda 0 dondurulmelidir.
/*  --1303  Kredi hesap a??l???
     --1305  Kredi hesap ek kulland?r?m
    --4100  Teminat Mektubu/Harici garanti a??l??
    --4101  Teminat  Mektubu/ Harici granati g?ncelleme
    --3215  Ithalat Akreditif A??l??
    --3216  Ithalat Akreditif G?ncelleme
    --4115  Verilen Garanti -Kefalet Giri?i
    --4116  Verilen garanti - Kefalet g?ncelleme     */
 /****************************************************************************************************************/
 Function sf_kullandirim_tutar(pn_islem_kod number, pn_islem_no number) return number
 is
   ln_tutar number := 0;
   ls_az varchar2(2000);
   ln_yeni_tutar number := 0;
 Begin
       if pn_islem_kod in ('1303','1305','4100','3215','4115') then
           select tutar
          into ln_tutar
          from  cbs_islem
          where numara = pn_islem_no ;
/* TDL guncelleme islemleri eklenmelidir.*/
      elsif pn_islem_kod = '3216' then
/*3216  Ithalat Akreditif G?ncelleme*/
         select nvl(arttirim_azaltim,'T'), nvl(artirim_azaltim_tutar,0)
           into ls_az, ln_tutar
           from cbs_ith_akreditif_islem
          where tx_no = pn_islem_no;
          if ls_az <> 'A' then  --artt?r?m d???nda
            ln_tutar := 0;
          end if;
      elsif pn_islem_kod = '4101' then
/*4101  Teminat  Mektubu/ Harici granati g?ncelleme*/

         select tutar,yeni_tutar
          into ln_tutar,ln_yeni_tutar
          from CBS_TM_HG_ACILIS_ISLEM
          where tx_no = pn_islem_no;

          if ln_yeni_tutar>ln_tutar then
            ln_tutar :=ln_yeni_tutar-ln_tutar;
            else
            ln_tutar :=0;
          end if;

      elsif pn_islem_kod = '4116' then
/*4116  Verilen garanti - Kefalet g?ncelleme*/

         select ARTTIRIM_AZALTIM, ART_AZAL_TUTARI
         into ls_az, ln_tutar
         from CBS_TM_VERILEN_GARANTI_ISLEM
         where tx_no = pn_islem_no;

         if ls_az ='AZALTIM' then
            ln_tutar := 0;
         end if;

     end if;

  return ln_tutar;

  Exception when others then  return 0;
 End;

/* Teminat nakdi rapor */

 /*****************************************************************************************************************/
 /*    Function sf_tl_karsiligi_bul                                                                 */
 /****************************************************************************************************************/
 Function sf_tl_karsiligi_bul(ps_doviz_kodu varchar2 ,pn_tutar number, pd_date date default pkg_muhasebe.banka_tarihi_bul) return number
 is
  ln_tutar number := 0;
 Begin

   ln_tutar := nvl(pkg_kur.doviz_doviz_karsilik(    ps_doviz_kodu ,pkg_genel.lc_al,NVL(pd_date,pkg_muhasebe.banka_tarihi_bul),pn_tutar,1,null,null,'O','A'),0);

   return ln_tutar;

  Exception when others then return 0;
 End;

 PROCEDURE  sp_ins_rpt_teminat_ipotek_cuz( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul)
 is
 Begin

    delete from cbs_rpt_teminat_ipotek_cuzdani
    where banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);

    commit;

       insert into cbs_rpt_teminat_ipotek_cuzdani
      ( TEMINAT_KOD, ACIKLAMA, TEMINAT_SIRA_NO,
          MUSTERI_NO, UNVAN, TUTAR, DOVIZ_KODU,
        IPOTEK_DERECE, IPOTEK_YEVMIYE_NO, IPOTEK_EXPERTIZ_DEGERI,
        IPOTEK_EXPERTIZ_TARIHI, IPOTEK_SIGORTA_VADESI, GIRIS_TARIHI,
        DURUM_KODU, BANKA_TARIHI, GRUP_NO, LOG_NO,
        MALIKI,BOLUM_KODU, TEMINAT_TIPI )
       select
        ANA_TEMINAT_KODU ||' ' ||DETAY_TEMINAT_KODU  teminat_kod ,
        pkg_teminat.SF_TEMINAT_ALT_KOD_ACIKLAMASI (ANA_TEMINAT_KODU,DETAY_TEMINAT_KODU) aciklama,
        TEMINAT_SIRA_NO,
        MUSTERI_NO,
        pkg_musteri.sf_musteri_adi(musteri_no) unvan,
        TUTAR,
        DOVIZ_KODU,
        IPOTEK_DERECE,
        NULL,
        IPOTEK_EXPERTIZ_DEGERI,
        IPOTEK_EXPERTIZ_TARIHI,
        IPOTEK_SIGORTA_VADESI,
        giris_tarihi ,
        durum ,
        nvl(pd_date,pkg_muhasebe.banka_tarihi_bul),
        pn_grup_no,
        pn_log_no,
        IPOTEK_MALIKI,BOLUM_KODU,pkg_teminat.SF_TEMINAT_ALT_KOD_ACIKLAMASI (ANA_TEMINAT_KODU,DETAY_TEMINAT_KODU)
        from cbs_kredi_teminat_tanim
        where  ANA_TEMINAT_KODU = '02' and durum = 'ACIK' ;

    commit;
    exception when others then rollback;
 End ;

 /*****************************************************************************************************************/
 /*  PROCEDURE  sp_ins_rpt_teminat_nakit                                                             */
 /****************************************************************************************************************/
 PROCEDURE  sp_ins_rpt_teminat_nakit( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul)
 is
 Begin

    delete from  cbs_rpt_teminat_nakit
    where banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);
    commit;
      insert into cbs_rpt_teminat_nakit
               (MUSTERI_NO, UNVAN, HESAP_NO,
              MUSTERI_DK_NO, DOVIZ_KODU,
              KULLANILAN_TUTAR,tl_tutar,
              BANKA_TARIHI, GRUP_NO, LOG_NO)
         SELECT B.MUSTERI_NO ,
                 PKG_MUSTERI.SF_MUSTERI_ADI(B.MUSTERI_NO) UNVAN,
                 B.HESAP_NO,
                B.MUSTERI_DK_NO,
                B.DOVIZ_KODU ,
                a.kullanilan_TUTAR,
                pkg_kur.doviz_doviz_karsilik(doviz_kodu ,pkg_genel.lc_al,NVL(pd_date,pkg_muhasebe.banka_tarihi_bul),kullanilan_tutar,1,null,null,'N','A'),
                nvl(pd_date,pkg_muhasebe.banka_tarihi_bul),
                pn_grup_no,
                pn_log_no
         FROM CBS_TEMINAT A,  CBS_HESAP_KREDI B
         WHERE A.TEMINAT_HESAP_NO = B.HESAP_NO AND
    --          B.DURUM_KODU = 'A' AND
    --           TEMINAT_DURUMU = 'ACIK' AND
              TEMINAT_KODU = '12' and kullanilan_tutar<> 0;

   commit;

   exception when others then rollback;

 End ;

  /*****************************************************************************************************************/
 /*  PROCEDURE  sp_ins_rpt_teminat_ipotek                                                         */
 /****************************************************************************************************************/
 PROCEDURE  sp_ins_rpt_teminat_ipotek( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul)
 is
 Begin

    delete from  cbs_rpt_teminat_ipotek
    where banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);

    commit;
      insert into cbs_rpt_teminat_ipotek
               (MUSTERI_NO, UNVAN, HESAP_NO,
              MUSTERI_DK_NO, DOVIZ_KODU,
              KULLANILAN_TUTAR,tl_tutar,
              BANKA_TARIHI, GRUP_NO, LOG_NO)
         SELECT B.MUSTERI_NO ,
                 PKG_MUSTERI.SF_MUSTERI_ADI(B.MUSTERI_NO) UNVAN,
                 B.HESAP_NO,
                B.MUSTERI_DK_NO,
                B.DOVIZ_KODU ,
                a.kullanilan_TUTAR,
                pkg_kur.doviz_doviz_karsilik(doviz_kodu ,pkg_genel.lc_al,NVL(pd_date,pkg_muhasebe.banka_tarihi_bul),kullanilan_tutar,1,null,null,'N','A'),
                nvl(pd_date,pkg_muhasebe.banka_tarihi_bul),
                pn_grup_no,
                pn_log_no
         FROM CBS_TEMINAT A,  CBS_HESAP_KREDI B
         WHERE A.TEMINAT_HESAP_NO = B.HESAP_NO AND
              --B.DURUM_KODU = 'A' AND
--               TEMINAT_DURUMU = 'ACIK' AND
              TEMINAT_KODU = '02' and kullanilan_tutar<> 0;

  commit;
  exception when others then rollback;
 End ;


 /*****************************************************************************************************************/
 /*   Function   sf_komisyon_oran_tutar_al                                                     */
 /****************************************************************************************************************/
  Function   sf_komisyon_oran_tutar_al(pn_islem_no number ,ps_oran_mi varchar2) return number
  is
   ln_oran number := 0;
   ln_tutar number := 0;
  Begin
    pkg_masraf.islem_komisyon_oran_tutar_al(pn_islem_no,ln_oran,ln_tutar );
    if ps_oran_mi  = 'E' then
        return ln_oran;
    else
       return ln_tutar;
    end if;

    exception when others then return 0;
  End;

 /*****************************************************************************************************************/
 /*   Procedure kredi_ayyilsonu_faiz_raporu                                                     */
 /* ay yil sonu kredi faiz listesi*/
/* 1. Faiz kredi devre yilsonu hesaplamas?ndan sonra ?al??t?r?lmal?d?r.*/
 /****************************************************************************************************************/
 Procedure kredi_ayyilsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul)
   is
 Begin

    delete from  cbs_rpt_kredi_ayyilsonu_faiz
    where banka_tarihi =nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);

      insert into cbs_rpt_kredi_ayyilsonu_faiz
               (musteri_no, unvan, hesap_no,
              musteri_dk_no, urun_tur_kod, urun_sinif_kod, doviz_kodu,
              bakiye, durum_kodu, sube_kodu, kredi_vade,acilis_tarihi,
              endeks_doviz_kodu, endeks_doviz_tutari,
              faiz_orani, faiz_tahakkuk_tarihi,
              komisyon_orani, birikmis_faiz_tutari,
              birikmis_komisyon_tutari, banka_tarihi,
              gecenyil_faiz_tutari, gecenyil_komisyon_tutari,
              grup_no, log_no,YEARLY_INT_RATE,GECMIS_AYLARIN_FAIZI,
              accrued_interest_tax,accrued_commission_tax ,   --sevalb 04032011 accrued interest,commission eklendi
              accrual_gl_no, --sevalb 23032011  hesap dk fark izlemesi icin eklendi
              ap_gecikme_gun_sayisi,
              faiz_gecikme_gun_sayisi,
              non_accrual_status,
              non_accrual_status_upd_date,
              --b-o-m seval.colak 06092022
                tahsiledilen_faiz_tutari,
                pastdue_faiz_orani,
                yearly_effective_int_rate,
                penalty_amount,
                penalty_rate,
                birikmis_gecikme_faiz_tutari,
                tahsil_gecikme_faiz_tutari,
                paid_penalty_amount,
                llp_rate,
                llp_amount,
              --e-o-m seval.colak 06092022   
                 rst_agreement_date,rst_agreement_no ,--seval.colak 13092022     
                 accrual_status_upd_date -- seval.colak 02112022         
              )
     select   musteri_no ,
               pkg_musteri.sf_musteri_adi(musteri_no) unvan,
              hesap_no, musteri_dk_no, urun_tur_kod, urun_sinif_kod,
              doviz_kodu, pkg_kredi.sf_bakiye_al(hesap_no),
              durum_kodu, sube_kodu, kredi_vade, acilis_tarihi,
              endeks_doviz_kodu,
              decode(endeks_doviz_kodu ,null,0,endeks_doviz_tutari),
              nvl(faiz_orani,0),
              faiz_tahakkuk_tarihi,
              nvl(komisyon_orani,0),
              pkg_kur.yuvarla(doviz_kodu, nvl(birikmis_faiz_tutari,0)),
              pkg_kur.yuvarla(doviz_kodu, nvl(birikmis_komisyon_tutari,0)),
              nvl(pd_date,pkg_muhasebe.banka_tarihi_bul),
                gecenyil_faiz_tutari, gecenyil_komisyon_tutari,
              pn_grup_no,   pn_log_no,YEARLY_INT_RATE,GECMIS_AYLARIN_FAIZI,
              accrued_interest_tax,accrued_commission_tax ,   --sevalb 04032011 accrued interest,commission eklendi
              pkg_rapor_2.dk_bul_getir(musteri_no,'LOAN',urun_tur_kod,urun_sinif_kod,4)  ACCRUAL_GL_NO ,--sevalb 23032011  hesap dk fark izlemesi icin eklendi
              ap_gecikme_gun_sayisi,
              faiz_gecikme_gun_sayisi,
              non_accrual_status,
              non_accrual_status_upd_date ,
                --b-o-m seval.colak 06092022
                tahsiledilen_faiz_tutari,
                pastdue_faiz_orani,
                yearly_effective_int_rate,
                penalty_amount,
                penalty_rate,
                birikmis_gecikme_faiz_tutari,
                tahsil_gecikme_faiz_tutari,
                paid_penalty_amount,
                llp_rate,
                llp_amount,
              --e-o-m seval.colak 06092022  
                 rst_agreement_date,rst_agreement_no ,--seval.colak 13092022     
                 accrual_status_upd_date -- seval.colak 02112022   
         from  cbs_hesap_kredi
         where durum_kodu = 'A' ;
  commit;

 End ;


 /*****************************************************************************************************************/
 /*Procedure kredi_gunsonu_faiz_raporu                                                                               */
 /* GUN sonu kredi faiz listesi*/
/* 2. Faiz kredi hesaplamas?ndan sonra ?al??t?r?lmal?d?r.*/
 /****************************************************************************************************************/
 Procedure kredi_gunsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul)
   is
 Begin

    delete from  cbs_rpt_kredi_gunsonu_faiz
    where banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);

      insert into cbs_rpt_kredi_gunsonu_faiz
               (musteri_no, unvan, hesap_no,
              musteri_dk_no, urun_tur_kod, urun_sinif_kod, doviz_kodu,
              bakiye, durum_kodu, sube_kodu, kredi_vade,acilis_tarihi,
              endeks_doviz_kodu, endeks_doviz_tutari,
              faiz_orani, faiz_tahakkuk_tarihi,
              komisyon_orani, birikmis_faiz_tutari,
              birikmis_komisyon_tutari, banka_tarihi,
              gecenyil_faiz_tutari, gecenyil_komisyon_tutari,
              grup_no, log_no,YEARLY_INT_RATE,GECMIS_AYLARIN_FAIZI,
              accrued_interest_tax,accrued_commission_tax,    --sevalb 04032011 accrued interest,commission eklendi
              accrual_gl_no, --sevalb 23032011  hesap dk fark izlemesi icin eklendi      
              ap_gecikme_gun_sayisi,
              faiz_gecikme_gun_sayisi,
              non_accrual_status,
              non_accrual_status_upd_date ,
               --b-o-m seval.colak 06092022
                tahsiledilen_faiz_tutari,
                pastdue_faiz_orani,
                yearly_effective_int_rate,
                penalty_amount,
                penalty_rate,
                birikmis_gecikme_faiz_tutari,
                tahsil_gecikme_faiz_tutari,
                paid_penalty_amount,
                llp_rate,
                llp_amount,
              --e-o-m seval.colak 06092022   
               rst_agreement_date,rst_agreement_no, --seval.colak 13092022  
               accrual_status_upd_date -- seval.colak 02112022                
                )
     select   musteri_no ,
               pkg_musteri.sf_musteri_adi(musteri_no) unvan,
              hesap_no, musteri_dk_no, urun_tur_kod, urun_sinif_kod,
              doviz_kodu, pkg_kredi.sf_bakiye_al(hesap_no),
              durum_kodu, sube_kodu, kredi_vade, acilis_tarihi,
              endeks_doviz_kodu,
              decode(endeks_doviz_kodu ,null,0,endeks_doviz_tutari) endeks_doviz_tutari,
              nvl(faiz_orani,0),
              faiz_tahakkuk_tarihi,
              nvl(komisyon_orani,0),
              nvl( birikmis_faiz_tutari_round,0),
              nvl(birikmis_komisyon_tutari_round,0),
              nvl(pd_date,pkg_muhasebe.banka_tarihi_bul),
              gecenyil_faiz_tutari, gecenyil_komisyon_tutari,
              pn_grup_no,pn_log_no,YEARLY_INT_RATE,GECMIS_AYLARIN_FAIZI,
              accrued_interest_tax,accrued_commission_tax ,   --sevalb 04032011 accrued interest,commission eklendi
              pkg_rapor_2.dk_bul_getir(musteri_no,'LOAN',urun_tur_kod,urun_sinif_kod,4)  ACCRUAL_GL_NO ,--sevalb 23032011  hesap dk fark izlemesi icin eklendi
              ap_gecikme_gun_sayisi,            --seval.colak 07122021   
              faiz_gecikme_gun_sayisi,
              non_accrual_status,
              non_accrual_status_upd_date,
               --b-o-m seval.colak 06092022
                tahsiledilen_faiz_tutari,
                pastdue_faiz_orani,
                yearly_effective_int_rate,
                penalty_amount,
                penalty_rate,
                birikmis_gecikme_faiz_tutari,
                tahsil_gecikme_faiz_tutari,
                paid_penalty_amount,
                llp_rate,
                llp_amount,
              --e-o-m seval.colak 06092022     
               rst_agreement_date,rst_agreement_no ,--seval.colak 13092022    
               accrual_status_upd_date -- seval.colak 02112022  
         from  cbs_hesap_kredi
         where durum_kodu = 'A' ;

  commit;

 End ;

 /*****************************************************************************************************************/
 /*   Function sf_vade_araligindami                                                     */
 /****************************************************************************************************************/
/* Function sf_vade_araligindami(pn_hesap_no number,ps_taksitdurum varchar2,pd_vade1 date,pd_vade2 date) return varchar2
 is
  ls_mevcut cbs_hesap_kredi_taksit.durum_kodu%type := 'H';
 Begin
             select distinct 'E'
          into ls_mevcut
          from cbs_hesap_kredi_taksit
          where hesap_no =pn_hesap_no and
                  durum_kodu = nvl(ps_taksitdurum,durum_kodu) and
                vade_tarih between  nvl(pd_vade1,vade_tarih) and  nvl(pd_vade2,vade_tarih);
    return ls_mevcut;

 Exception when others then return 'H';
 End;
*/
  /*****************************************************************************************************************/
 /*   Function sf_vade_araligindami                                                     */
 /****************************************************************************************************************/
/* Function sf_vade_tarihial(pn_hesap_no number,ps_taksitdurum varchar2,pd_vade1 date,pd_vade2 date) return date
 is
  ld_vade date :=null;
 Begin
             select min(vade_tarih)
          into ld_vade
          from cbs_hesap_kredi_taksit
          where hesap_no =pn_hesap_no and
                  durum_kodu = nvl(ps_taksitdurum,durum_kodu) and
                vade_tarih between  nvl(pd_vade1,vade_tarih) and  nvl(pd_vade2,vade_tarih);

    return ld_vade;

 Exception when others then return null;
 End;
*/
 /*****************************************************************************************************************/
 /*   Procedure sp_ins_cbs_rpt_bireysel_kredi                                              */
 /****************************************************************************************************************/
  /*Procedure sp_ins_cbs_rpt_bireysel_kredi (
             p_rapor_islem_no    number,
             ps_sql varchar2,
            ps_taksitdurum varchar2,
            pd_vade1 date,pd_vade2 date)
 is

 Type empcurtyp is ref cursor; -- define weak ref cursor type
    emp_cv empcurtyp;
    m_rec cbs_rpt_bireysel_kredi_hesap%rowtype ;
    ln_sira_no number := 0;

  Begin

    delete from  cbs_rpt_bireysel_kredi_hesap;

    open emp_cv for 'select ' ||  p_rapor_islem_no ||' rapor_islem_no,'||
                               ln_sira_no||' sira_no,'||
                     ' pkg_kredi_rapor.sf_vade_tarihial(HESAP_NO ,null,NULL,NULL) taksit_tarihi,' ||
                     ' a.* from cbs_vw_bireysel_kredihesapizle a '
                     || ps_sql;

        loop fetch emp_cv into m_rec;
               insert into cbs_rpt_bireysel_kredi_hesap (
                    rapor_islem_no,
                    sira_no,
                    hesap_no    ,
                    musteri_no    ,
                    unvan    ,
                    doviz_kodu    ,
                    acilis_tutar    ,
                    durum_kodu    ,
                    sube_kodu    ,
                    musteri_dk_no    ,
                    urun_tur_kod    ,
                    urun_sinif_kod    ,
                    modul_tur_kod    ,
                    bakiye    ,
                    kredi_teklif_satir_numara    ,
                    kredi_vade    ,
                    kredi_kullandirim_kodu    ,
                    endeks_doviz_kodu    ,
                    kullandirim_doviz_kodu    ,
                    son_gun_faizi    ,
                    acilis_kuru    ,
                    faiz_orani    ,
                    faiz_siklik    ,
                    faiz_siklik_tipi    ,
                    faiz_tahakkuk_tarihi    ,
                    komisyon_orani    ,
                    komisyon_tutari    ,
                    komisyon_tahsilat_donemi    ,
                    fon_orani    ,
                    bsmv_orani    ,
                    alacak_hesap_no    ,
                    iliskili_hesap_no    ,
                    kur_farki    ,
                    extre_masrafi    ,
                    sinirlama_kodu    ,
                    kaynak_kodu    ,
                    istatistik_kodu    ,
                    urun_grup_no    ,
                    referans    ,
                    faiz_tahakkuk_hesap_no    ,
                    faiz_tahakkuk_hesap_bakiye    ,
                    vergi_tahakkuk_hesap_no    ,
                    vergi_tahakkuk_hesap_bakiye    ,
                    birikmis_faiz_tutari    ,
                    birikmis_komisyon_tutari    ,
                    esas_gun_sayisi    ,
                    acilis_tarihi    ,
                    kapanis_tarihi    ,
                    bsmv_alinsin    ,
                    kkdf_alinsin    ,
                    endeks_doviz_tutari    ,
                    gecenyil_faiz_tutari    ,
                    tahsiledilen_faiz_tutari    ,
                    tahsiledilen_komisyon_tutari    ,
                    gecenyil_komisyon_tutari    ,
                    birikmis_sch_faizi    ,
                    gecenyil_sch_faizi    ,
                    son_islem_kuru    ,
                    gecenyil_anaparakurfark_gelir    ,
                    gecenyil_anaparakurfark_zarar    ,
                    gecenyil_faizkurfark_gelir    ,
                    gecenyil_faizkurfark_zarar    ,
                    gecenyil_komiskurfark_gelir    ,
                    gecenyil_komiskurfark_zarar    ,
                    faiz_baslangic_tarihi    ,
                    sch_faiz_orani    ,
                    eski_hesap_no    ,
                    eski_hesap_ekno    ,
                    eski_faizhesap_ekno    ,
                    eski_komhesap_ekno    ,
                    kredi_turu_nakit_gayri    ,
                    musteri_tipi_kodu    ,
                    birikmis_faiz_toplam    ,
                    birikmis_komisyon_toplam)
               values
                   (p_rapor_islem_no,
                    ln_sira_no,
                       m_rec.hesap_no    ,
                    m_rec.musteri_no    ,
                    m_rec.unvan    ,
                    m_rec.doviz_kodu    ,
                    m_rec.acilis_tutar    ,
                    m_rec.durum_kodu    ,
                    m_rec.sube_kodu    ,
                    m_rec.musteri_dk_no    ,
                    m_rec.urun_tur_kod    ,
                    m_rec.urun_sinif_kod    ,
                    m_rec.modul_tur_kod    ,
                    m_rec.bakiye    ,
                    m_rec.kredi_teklif_satir_numara    ,
                    m_rec.kredi_vade    ,
                    m_rec.kredi_kullandirim_kodu    ,
                    m_rec.endeks_doviz_kodu    ,
                    m_rec.kullandirim_doviz_kodu    ,
                    m_rec.son_gun_faizi    ,
                    m_rec.acilis_kuru    ,
                    m_rec.faiz_orani    ,
                    m_rec.faiz_siklik    ,
                    m_rec.faiz_siklik_tipi    ,
                    m_rec.faiz_tahakkuk_tarihi    ,
                    m_rec.komisyon_orani    ,
                    m_rec.komisyon_tutari    ,
                    m_rec.komisyon_tahsilat_donemi    ,
                    m_rec.fon_orani    ,
                    m_rec.bsmv_orani    ,
                    m_rec.alacak_hesap_no    ,
                    m_rec.iliskili_hesap_no    ,
                    m_rec.kur_farki    ,
                    m_rec.extre_masrafi    ,
                    m_rec.sinirlama_kodu    ,
                    m_rec.kaynak_kodu    ,
                    m_rec.istatistik_kodu    ,
                    m_rec.urun_grup_no    ,
                    m_rec.referans    ,
                    m_rec.faiz_tahakkuk_hesap_no    ,
                    m_rec.faiz_tahakkuk_hesap_bakiye    ,
                    m_rec.vergi_tahakkuk_hesap_no    ,
                    m_rec.vergi_tahakkuk_hesap_bakiye    ,
                    m_rec.birikmis_faiz_tutari    ,
                    m_rec.birikmis_komisyon_tutari    ,
                    m_rec.esas_gun_sayisi    ,
                    m_rec.acilis_tarihi    ,
                    m_rec.kapanis_tarihi    ,
                    m_rec.bsmv_alinsin    ,
                    m_rec.kkdf_alinsin    ,
                    m_rec.endeks_doviz_tutari    ,
                    m_rec.gecenyil_faiz_tutari    ,
                    m_rec.tahsiledilen_faiz_tutari    ,
                    m_rec.tahsiledilen_komisyon_tutari    ,
                    m_rec.gecenyil_komisyon_tutari    ,
                    m_rec.birikmis_sch_faizi    ,
                    m_rec.gecenyil_sch_faizi    ,
                    m_rec.son_islem_kuru    ,
                    m_rec.gecenyil_anaparakurfark_gelir    ,
                    m_rec.gecenyil_anaparakurfark_zarar    ,
                    m_rec.gecenyil_faizkurfark_gelir    ,
                    m_rec.gecenyil_faizkurfark_zarar    ,
                    m_rec.gecenyil_komiskurfark_gelir    ,
                    m_rec.gecenyil_komiskurfark_zarar    ,
                    m_rec.faiz_baslangic_tarihi    ,
                    m_rec.sch_faiz_orani    ,
                    m_rec.eski_hesap_no    ,
                    m_rec.eski_hesap_ekno    ,
                    m_rec.eski_faizhesap_ekno    ,
                    m_rec.eski_komhesap_ekno    ,
                    m_rec.kredi_turu_nakit_gayri    ,
                    m_rec.musteri_tipi_kodu    ,
                    m_rec.birikmis_faiz_toplam    ,
                    m_rec.birikmis_komisyon_toplam);
              ln_sira_no := ln_sira_no + 1;
          exit when emp_cv%notfound;

    end loop ;
  Exception
      when others then
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '913' || pkg_hata.getDelimiter ||to_char(SQLCODE)||' '|| to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

END;
*/

 Function sf_valorlu_bakiye_al(pn_hesap_no number) return number
 is
  ln_bakiye number := 0;
 Begin
       select nvl(valorlu_bakiye,0)
      into ln_bakiye
      from cbs_hesap_bakiye
      where hesap_no = pn_hesap_no ;

     return ln_bakiye;
     
     Exception when others then return 0;
 End;

 /* kredi teklif karar layoutlari ile ilgili */
 procedure sp_kredi_teklif_personel_al(ps_komite_tipi varchar2 default 'Y?NET?M KURULU',

                                           ps_unvan_1 out varchar2 ,
                                       ps_ad_1       out varchar2 ,
                                       ps_unvan_2 out varchar2 ,
                                       ps_ad_2       out varchar2 ,
                                       ps_unvan_3 out varchar2 ,
                                       ps_ad_3       out varchar2 ,
                                       ps_unvan_4 out varchar2 ,
                                       ps_ad_4       out varchar2 ,
                                       ps_unvan_5 out varchar2 ,
                                       ps_ad_5       out varchar2 ,
                                       ps_unvan_6 out varchar2 ,
                                       ps_ad_6       out varchar2 ,
                                       ps_unvan_7 out varchar2 ,
                                       ps_ad_7       out varchar2 ) is


 Begin
      select unvan_1, ad_1,
               unvan_2, ad_2,
             unvan_3, ad_3,
             unvan_4, ad_4,
             unvan_5, ad_5,
             unvan_6, ad_6,
             unvan_7,ad_7
      into      ps_unvan_1, ps_ad_1,
               ps_unvan_2, ps_ad_2,
             ps_unvan_3, ps_ad_3,
             ps_unvan_4, ps_ad_4,
             ps_unvan_5, ps_ad_5,
             ps_unvan_6, ps_ad_6,
             ps_unvan_7, ps_ad_7
      from cbs_kredi_teklif_personel
      where KOMITE_TIPI = ps_komite_tipi;

 Exception when others then null;

 End;

Function sf_kredi_teminat_min_kosul_al(pn_teklif_no number,pn_teklif_satir_no number) return number
is
 ln_sira number := 0;
Begin
      if  nvl(pn_teklif_satir_no,0) <> 0 then
          select NVL(min( sira_no),0)
         into ln_sira
         from cbs_kredi_teklif_satir_teminat
         where teklif_no = pn_teklif_no and
                TEKLIF_SATIR_NO = pn_teklif_satir_no ;
     end if;

     return nvl(ln_sira,0);
End;

 Function sf_adres_al (pn_musteri_no number) return varchar2
 is
    ls_adres       cbs_musteri_adres.adres%type;
    ls_semt       cbs_musteri_adres.semt%type;
    ls_il_kod        cbs_musteri_adres.il_kod%type;
    ln_posta_kod  cbs_musteri_adres.posta_kod%type;
    ls_ulke_kod      cbs_musteri_adres.ulke_kod%type;
    ls_tumadres      varchar2(2000);
    ls_posta_kod  varchar2(2000);
  Begin

         pkg_musteri.Sp_Musteri_Adres( pn_musteri_no ,
                            ls_adres     ,
                         ls_semt ,
                         ls_il_kod,
                         ln_posta_kod,
                         ls_ulke_kod);

        if  nvl(ls_il_kod,0) = '0' then
            ls_il_kod := '';
        end if;

        if  nvl(ln_posta_kod,0) = 0 then
              ls_posta_kod := '' ;
        else
              ls_posta_kod :=  trim(to_char(ln_posta_kod));
        end if;

        ls_tumadres :=  trim( trim(ls_adres )) ||' '||
                        trim( ls_semt ) ||' '||
                        trim(to_char(ls_posta_kod)) ;
     return upper(ls_tumadres );
  End ;
/* fonksiyon baslangicta il amacliydi sonradan gelen talep uzerine il ve ulke kod aciklamas? dondurecek sekilde degistirildi.*/
 Function sf_adres_ilkod_al (pn_musteri_no number) return varchar2
 is
    ls_adres       cbs_musteri_adres.adres%type;
    ls_semt       cbs_musteri_adres.semt%type;
    ls_il_kod        cbs_musteri_adres.il_kod%type;
    ln_posta_kod  cbs_musteri_adres.posta_kod%type;
    ls_ulke_kod      cbs_musteri_adres.ulke_kod%type;
    ls_tumadres      varchar2(2000);
    ls_posta_kod  varchar2(2000);
    ls_il_aciklama varchar2(2000);
    ls_ulke_aciklama varchar2(2000);
  Begin

         pkg_musteri.Sp_Musteri_Adres( pn_musteri_no ,
                            ls_adres     ,
                         ls_semt ,
                         ls_il_kod,
                         ln_posta_kod,
                         ls_ulke_kod);

      if  nvl(ls_il_kod,0) = '0' then
            ls_il_aciklama := '';
      else
          begin
           select il_adi
           into ls_il_aciklama
           from cbs_il_kodlari
           where il_kodu = ls_il_kod;
           ls_il_aciklama   := ls_il_aciklama  ||' / ';

          exception when others then return null;
         end ;
      end if;

       if  nvl(ls_ulke_kod,0) = '0' then
            ls_ulke_aciklama := '';
      else
          begin
           select ULKE_ADI
           into ls_ulke_aciklama
           from cbs_ulke_kodlari
           where ulke_kodu = ls_ulke_kod;

          exception when others then return null;
         end ;
      end if;

  return upper( trim(ls_il_aciklama ||ls_ulke_aciklama ));
  End ;

 Function sf_bireysel_anapara_bul(pn_hesap_no number) return number
 is
  ln_tutar number ;
  begin
      select sum(abs(nvl(anapara,0)))
    into ln_tutar
    from cbs_hesap_kredi_taksit
    where hesap_no = pn_hesap_no;


   return ln_tutar;

   Exception when others then return 0;

  End;

function acilis_tarihi(pn_hesap_no number) return date
is
 ld_tarih date;
 begin
       select acilis_tarihi
      into ld_tarih
      from cbs_hesap_kredi
      where hesap_no = pn_hesap_no ;

      return ld_tarih;
    exception when others then null;
 end;
   Function sf_Bankamiz_adres_al return varchar2
   is
   Begin
        return  'BEYBI GIZ PLAZA KAT:7 MEYDAN SOK. NO:28  80670-MASLAK /ISTANBUL';
   End;

Function sf_hesapdkno_al (pn_hesap_no number)  return varchar2
is
 ls_dkno varchar2(200);
Begin
     select musteri_dk_no
     into ls_dkno
     from cbs_hesap_kredi
     where hesap_no = pn_hesap_no;

     return ls_dkno;
End;

Function komtiporanal (p_referans cbs_masraf_ith_ihr.referans%type, p_sira_no cbs_masraf_ith_ihr.sira_no%type)  return number
    is
      ln_oran number := 0;
    Begin
      select  DECODE(M.KOMISYON_TIPI,'D?NEMSEL YORAN',nvl(M.YILLIK_ORAN,0),
              'ORAN',NVL(M.ORAN,0),
              'D?NEMSEL ORAN',NVL(M.ORAN,0),
              0)
      into ln_oran
      from cbs_masraf_ith_ihr m
      where  REFERANS = p_referans and
             SIRA_NO =     p_sira_no ;
     return ln_oran;

    End;


PROCEDURE   teklif_kosullari_karsilandimi (
                pn_hesap_no                      number ,
             pn_musteri_no                     number,
                pn_kredi_teklif_satir_numara    number,
             pn_ref_no out number )
 is pragma autonomous_transaction;

      ln_teklif_no                cbs_kredi_teklif.teklif_no%TYPE;
      ln_teklif_satir_numara      cbs_hesap_kredi_islem.kredi_teklif_satir_numara%TYPE;
      ls_teminat_kodu             cbs_teminat_alt_kodlari.teminat_kodu%TYPE;
      ls_teminat_alt_kodu         cbs_teminat_alt_kodlari.teminat_alt_kodu%TYPE;
      ln_alinan_tutar             NUMBER;
      ln_alinan_toplam_tutar      NUMBER;
      ln_alinmasi_gereken_tutar   NUMBER;
      ln_mevcut                   NUMBER  := 0;
      ln_hesap_islem              NUMBER  := 0;
      ln_teklif_islem             NUMBER  := 0;
      ln_teminat_islem            NUMBER  := 0;
      ls_hesap_doviz_kodu          cbs_hesap_kredi.DOVIZ_KODU%type;
      ls_teklif_doviz_kodu          cbs_hesap_kredi.DOVIZ_KODU%type;
      ln_hesap_tutar              number;
      ln_teklif_doviz_tutar          number;
      ln_alinan_toplamtutar_tekdoviz number := 0;
      ls_teminat_kodacik           varchar(2000) := '' ;
      ls_teminat_altkodacik            varchar(2000) := '' ;
      ln_grup_no                    number:= 0;
      ln_grup_karsilanmis            number := 0;
         ls_aranilan_doviz_kodu      cbs_hesap_kredi.doviz_kodu%type;
      ls_teminat_doviz            cbs_hesap_kredi.doviz_kodu%type;
      Ps_karsilandimi              Varchar2(1) := 'E';
      ln_ref_no                      number :=0;
        ps_kredi_hesap_doviz_kodu cbs_hesap_kredi.doviz_kodu%type;
      ps_kredi_endeksdoviz cbs_hesap_kredi.doviz_kodu%type;
      pn_kredi_hesap_tutar number;
      ln_alma_gun_Sayisi   number := 0;
      ln_hesap_bakiye number := 0;
/* grup no 0 dan fakl? olanlar icin veya kosulu ile bak?lacakt?r */
          cursor cursor_grup1 is
         SELECT distinct GRUP_NO grup_no
         FROM cbs_vw_teklif_satir_teminat
         WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
            AND nvl(alma_gun_sayisi,0) <= nvl(ln_alma_gun_Sayisi,0)
            group by  GRUP_NO;


/* teklifdeki alma gun sayisi girilmemi? olan kay?tlar i?in teminat ko?ullar? a??l?? s?ras?nda kar??lanmal?d?r. */
/* teklif satirindaki girilen de?erlere g?re hesaplanan teminat tutar? hesab?n d?viz kodundad?r.*/
/* 1. a?amada tutar alan? dolu olanlar i?in teklif ko?ullar? ayn? doviz kodunda kar??lanmal?*/


      CURSOR cursor_teklif_satir_toplam_1
      IS
         SELECT GRUP_NO,
                 teklif_no,
                teklif_satir_no,
                 teminat_kodu,
                teminat_alt_kodu,
                doviz_kodu teklif_doviz_kodu,
                 nvl(doviz_kodu,ls_hesap_doviz_kodu) doviz_kodu,
                nvl(sum(pkg_teminat.sf_teklif_teminat_tutari( tutar,
                                                               nvl(doviz_kodu,ls_hesap_doviz_kodu),
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani)),0) tutar,
                nvl(sum(pkg_teminat.sf_teklif_teminat_tutari( tutar,
                                                             nvl(doviz_kodu,ls_hesap_doviz_kodu),
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani
                                                          ,'ORIGINKOD'
                                                          )),0)  teklif_doviz_tutar
           FROM cbs_vw_teklif_satir_teminat
          WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
            AND nvl(alma_gun_sayisi,0) <= nvl(ln_alma_gun_Sayisi,0)
            and grup_no = ln_grup_no
            group by  GRUP_NO,
                        teklif_no,
                      teklif_satir_no,
                        teminat_kodu,
                      teminat_alt_kodu,
                      doviz_kodu ,
                      nvl(doviz_kodu,ls_hesap_doviz_kodu);

      CURSOR cur_teminat_islem
      IS
         SELECT  teminat_kodu,
                  teminat_alt_kodu ,
                  teminat_doviz_kodu,
                  sum(NVL (kullanilan_tutar, 0)) kullanilan_tutar
         FROM cbs_teminat
          WHERE teminat_hesap_no = pn_hesap_no
            AND teminat_kodu = ls_teminat_kodu
            AND teminat_alt_kodu = nvl(ls_teminat_alt_kodu,teminat_alt_kodu)
            AND teminat_durumu = 'ACIK'
            AND PKG_TEMINAT.SF_TEMINAT_DURUMU_UYGUNMU( TEMINAT_KODU, REFERANS, REF_CEK_NO, BOLUM_KODU, SENET_NO, MUSTERI_NO, KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO ,SOZLESME_NO,EK_SOZLESME_NO)= 'E'
            AND teminat_doviz_kodu = nvl(ls_aranilan_doviz_kodu,teminat_doviz_kodu )
             group by     teminat_kodu,
                            teminat_alt_kodu ,
                        teminat_doviz_kodu;
 BEGIN
   Ps_karsilandimi := 'E';
   ln_teminat_islem := 0;
   ln_teklif_no := pkg_kredi.SF_SATIRNODAN_TEKLIFNOAL( pn_kredi_teklif_satir_numara);
   ln_teklif_satir_numara := pn_kredi_teklif_satir_numara;

   select SQ_CBS_TEMINATTEKLIFSATIR_IZLE.NEXTVAL
   into  ln_ref_no
   from dual;

   pn_ref_no :=ln_ref_no;

  if nvl(pn_hesap_no,0) <> 0  then

 --030604
      select doviz_kodu,endeks_doviz_kodu,
               decode(endeks_doviz_kodu,null,abs(nvl(pkg_kredi.sf_Bakiye_Al(hesap_no),0)), abs(nvl(pkg_kredi.sf_endeks_doviz_bakiye_al(hesap_no),0))),
             abs(pkg_muhasebe.banka_tarihi_bul - nvl(acilis_tarihi,pkg_muhasebe.banka_tarihi_bul)),
             nvl(pkg_kredi.sf_bakiye_al(pn_hesap_no),0)
      into   ps_kredi_hesap_doviz_kodu,
               ps_kredi_endeksdoviz,
             ln_hesap_tutar ,
             ln_alma_gun_Sayisi,
             ln_hesap_bakiye
      from   cbs_hesap_kredi
      where hesap_no = pn_hesap_no  ;
   else
      ln_hesap_tutar    := 0;
   end if;

   ls_hesap_doviz_kodu :=nvl( ps_kredi_endeksdoviz,ps_kredi_hesap_doviz_kodu);

 FOR cur_grup in cursor_grup1 Loop
      Ps_karsilandimi := 'E';
       ln_grup_no := cur_grup.grup_no;
      ln_grup_karsilanmis :=0 ;
        ls_aranilan_doviz_kodu :=null;
    /* 1. a?ama tutar alan? dolu ise */


         FOR cur_teklif_satir_toplam_1 IN cursor_teklif_satir_toplam_1
         LOOP
            Ps_karsilandimi := 'E';
            ls_teminat_kodu            := cur_teklif_satir_toplam_1.teminat_kodu;
            ls_teminat_alt_kodu        := cur_teklif_satir_toplam_1.teminat_alt_kodu;
            ln_alinmasi_gereken_tutar  := cur_teklif_satir_toplam_1.tutar;
            ln_teklif_doviz_tutar      := cur_teklif_satir_toplam_1.teklif_doviz_tutar;
            ls_teklif_doviz_kodu       := cur_teklif_satir_toplam_1.doviz_kodu;
            ln_alinan_toplam_tutar        := 0;
            ln_alinan_tutar            := 0;
            ln_mevcut := 1;
            ls_aranilan_doviz_kodu :=null;



    /* teklif doviz kodu dolu ise teklifin doviz kodunda aran?r, bos ise 15 sozlesme icin kredi hesap doviz kodunda digerlerinde kosul aranmaz */
            if cur_teklif_satir_toplam_1.teklif_doviz_kodu is null then
               if  ls_teminat_kodu = '15' then /*sozlesmeler de kredi hesab?n?n doviz kodu */
                      ls_aranilan_doviz_kodu := ls_hesap_doviz_kodu;
               else
                    ls_aranilan_doviz_kodu  := null;
                end if;
             else
                     ls_aranilan_doviz_kodu  := cur_teklif_satir_toplam_1.teklif_doviz_kodu;
             end if;


            FOR cur_teminat IN cur_teminat_islem
            LOOP
               ln_teminat_islem := ln_teminat_islem + 1;
               ln_alinan_tutar := cur_teminat.kullanilan_tutar;
               ls_teminat_doviz:= cur_teminat.teminat_doviz_kodu;
--               IF ps_kredi_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu   THEN
                  IF  ls_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu then
                      ln_alinan_tutar :=  pkg_teminat.sf_teminattutar_hesdovizcevir
                                             (ln_alinan_tutar,
                                              cur_teminat.teminat_doviz_kodu,
                                              ls_hesap_doviz_kodu--ps_kredi_hesap_doviz_kodu
                                             );
                END IF;
                ln_alinan_toplam_tutar := NVL (ln_alinan_toplam_tutar, 0)  + NVL (ln_alinan_tutar, 0);
            END LOOP;
/* grup numaras? 0 ise AND ile bagli kosullard?r , karsilanmama durumu raise edilir.*/
            IF NVL (ln_alinmasi_gereken_tutar, 0) >  NVL (ln_alinan_toplam_tutar, 0) and nvl(ln_grup_no,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
                     ps_karsilandimi := 'H';
                       ls_teminat_kodacik    := ls_teminat_kodu ||'-' || pkg_teminat.Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
                       ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || pkg_teminat.Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

                     if ls_teklif_doviz_kodu is null then
                         ln_alinmasi_gereken_tutar := nvl(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
                     END IF;
                     ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );
             END IF;

            IF NVL (ln_alinmasi_gereken_tutar, 0) <=  NVL (ln_alinan_toplam_tutar, 0) and nvl(ln_grup_no,0) <> 0  THEN
               /* grup olarak alinmasi gereken tutar kar??lanm??*/
               ln_grup_karsilanmis := ln_grup_karsilanmis + 1;
            END IF;

               insert into CBS_TEMINAT_TEKLIFSATIR_IZLEME
                   (                ref_no,
                                    musteri_no,
                                 teklif_satir_no,
                                    teminat_kodu,
                                 teminat_alt_kodu,
                                 teminat_turu,
                                 teklif_tutar,
                                 teklif_doviz_kodu,
                                 grup_no,
                                 teminat_hesap_no,
                                    teminat_doviz_kodu,
                                 teminat_kullanilan_tutar,
                                 teminat_kul_teklifdvzli_tutar,
                                 karsilanma
                                 )
                    values        (
                                 ln_ref_no,
                                    pn_musteri_no,
                                 pn_kredi_teklif_satir_numara,
                                    ls_teminat_kodu,
                                 ls_teminat_alt_kodu,
                                 NVL(ls_teminat_altkodacik,ls_teminat_kodacik  ),
                                 decode(ln_hesap_Bakiye,0,0,ln_alinmasi_gereken_tutar),--ln_teklif_doviz_tutar,
                                 nvl(ls_hesap_doviz_kodu,ls_teklif_doviz_kodu),
                                 ln_grup_no,
                                 pn_hesap_no,
                                    ls_teminat_doviz,
                                 ln_alinan_toplam_tutar ,
                                 ln_alinan_toplamtutar_tekdoviz,
                                  decode(ln_hesap_Bakiye,0,'E',ps_karsilandimi));

         END LOOP;
/*gruplar icin karsilanma durumu kontrol edilir.*/
         IF nvl(ln_grup_no,0) <> 0 then
             if  nvl(ln_grup_karsilanmis,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
                 ps_karsilandimi := 'H';
             else
                   ps_karsilandimi := 'E';
             end if;
             --  RAISE grup_teklif_karsilanmamis;
                  ls_teminat_kodacik    := ls_teminat_kodu ||'-' || pkg_teminat.Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
              ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || pkg_teminat.Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

             if ls_teklif_doviz_kodu is null then
                         ln_teklif_doviz_tutar := nvl(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
             end if;
              ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );


              update CBS_TEMINAT_TEKLIFSATIR_IZLEME
              set   karsilanma =   decode(ln_hesap_Bakiye,0,'E',ps_karsilandimi)
              where ref_no = ln_ref_no  and
                    teklif_satir_no = pn_kredi_teklif_satir_numara and
                    grup_no = ln_grup_no ;

       END IF;

  END LOOP;


    commit;
      EXCEPTION WHEN OTHERS
      THEN
              raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '502'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END;


  PROCEDURE sp_insert_cbs_rpt_teminateksik(
              pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2,
              pn_hata_kod             NUMBER,
            pn_kredi_hesap_no        CBS_RPT_TEMINAT_EKSIK.kredi_hesap_no%TYPE,
            pn_teklif_satir_no        CBS_RPT_TEMINAT_EKSIK.teklif_satir_no%TYPE  ,
            ps_teminat_kodu            CBS_RPT_TEMINAT_EKSIK.teminat_kodu%TYPE ,
            ps_teminat_alt_kodu        CBS_RPT_TEMINAT_EKSIK.teminat_alt_kodu%TYPE ,
            pn_teklif_doviz_tutar NUMBER,
            ps_teklif_doviz_kodu  VARCHAR2,
            pn_alinan_toplamtutar_tekdoviz NUMBER,
            pn_alinmasi_gereken_tutar NUMBER,
            pn_alinan_toplam_tutar  NUMBER ,
            pn_teklif_musteri_no number default 0 )
IS
  ls_hata_mesaj VARCHAR2(2000);
  ln_musteri_no number := 0;
  ls_teminat_alt_kodu varchar2(2000);
  ls_teminat_kodu varchar2(2000);
BEGIN

 ls_teminat_kodu := upper(ps_teminat_kodu ||'-' || pkg_teminat.Sf_Teminat_Kod_Aciklamasi( ps_teminat_kodu));
 ls_teminat_alt_kodu :=upper(ps_teminat_alt_kodu ||'-' || pkg_teminat.Sf_Teminat_Alt_Kod_Aciklamasi( ps_teminat_kodu,ps_teminat_alt_kodu));

     CASE  pn_hata_kod
           WHEN  1 THEN
                     ls_hata_mesaj := Pkg_Hata.GenerateMessage( Pkg_Hata.getucpointer
                                          || '493'
                                          || Pkg_Hata.getucpointer
                                         );
           WHEN 2 THEN
                   ls_hata_mesaj := Pkg_Hata.GenerateMessage(      Pkg_Hata.getucpointer
                                  || '492'
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_kodu
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_alt_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR (pn_teklif_doviz_tutar,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR ( pn_alinan_toplamtutar_tekdoviz,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer
                                 );
            WHEN 3 THEN
                        ls_hata_mesaj := Pkg_Hata.GenerateMessage(  Pkg_Hata.getucpointer
                                  || '562'
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_kodu
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_alt_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR (pn_alinmasi_gereken_tutar,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR ( pn_alinan_toplam_tutar,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer             );
           WHEN 4 THEN
                   ls_hata_mesaj := Pkg_Hata.GenerateMessage(      Pkg_Hata.getucpointer
                                  || '680'
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_kodu
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_alt_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR (pn_teklif_doviz_tutar,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR ( pn_alinan_toplamtutar_tekdoviz,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer
                                 );

           WHEN 5 THEN
                   ls_hata_mesaj := Pkg_Hata.GenerateMessage(      Pkg_Hata.getucpointer
                                  || '681'
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_kodu
                                  || Pkg_Hata.getdelimiter
                                  || ls_teminat_alt_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR (pn_teklif_doviz_tutar,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR ( pn_alinan_toplamtutar_tekdoviz,'FM999G999G999G999G999G999G999G999G999D00')
                                  || ps_teklif_doviz_kodu
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer
                                 );

            ELSE
                     ls_hata_mesaj := Pkg_Hata.GenerateMessage(
                                     Pkg_Hata.getucpointer
                                  || '502'
                                  || Pkg_Hata.getdelimiter
                                  || 'Hata Kod:' || TO_CHAR(pn_hata_kod )|| TO_CHAR(pn_kredi_hesap_no) ||'/'|| TO_CHAR( pn_teklif_satir_no) || ' '
                                  || TO_CHAR (SQLCODE) || '-'
                                  || SQLERRM
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer
                                 );

    END CASE;

    -- pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);

    ln_musteri_no := pn_teklif_musteri_no;
    if nvl(pn_kredi_hesap_no,0) <> 0 and nvl(ln_musteri_no,0) = 0 then
       select musteri_no
       into ln_musteri_no
       from cbs_hesap_kredi
       where hesap_no =pn_kredi_hesap_no;
     end if;

      insert into cbs_rpt_teminat_eksik (hata_mesaj,
                                                 kredi_hesap_no    ,                                                                                  teklif_satir_no  ,
                                         teminat_kodu ,
                                         teminat_alt_kodu ,
                                         banka_tarihi,
                                         grup_no,
                                         log_no ,
                                         teklif_musteri_no )
           values (ls_hata_mesaj,
                      nvl(pn_kredi_hesap_no,0),
                   nvl(pn_teklif_satir_no ,0),
                   ls_teminat_kodu ,
                   ls_teminat_alt_kodu ,
                   pkg_muhasebe.banka_tarihi_bul,
                   pn_grup_no,
                   pn_log_no ,
                   ln_musteri_no);



    EXCEPTION
      WHEN OTHERS THEN
        ls_hata_mesaj  := 'sp_insert_cbs_rpt_teminateksik de error occured. HesapNo:'||TO_CHAR(Pn_KREDI_HESAP_NO)||' TeklifSatNo:'||TO_CHAR(pn_TEKLIF_SATIR_NO) ||' Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);

END;


  PROCEDURE TeminatEksikRaporla(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
  IS
  Begin
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    pkg_kredi_Rapor.TeminatEksikRaporlahesap(pn_grup_no,pn_log_no,ps_program_kod);
    pkg_kredi_Rapor.TeminatEksikRaporlamusteri(pn_grup_no,pn_log_no,ps_program_kod);
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  End;

  PROCEDURE TeminatEksikRaporlahesap(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
  IS
      ln_teklif_no                CBS_KREDI_TEKLIF.teklif_no%TYPE;
      ln_teklif_satir_numara      NUMBER;
      ls_teminat_kodu             CBS_TEMINAT_ALT_KODLARI.teminat_kodu%TYPE;
      ls_teminat_alt_kodu         CBS_TEMINAT_ALT_KODLARI.teminat_alt_kodu%TYPE;
      ln_alinan_tutar             NUMBER;
      ln_alinan_toplam_tutar      NUMBER;
      ln_alinmasi_gereken_tutar   NUMBER;
      ln_mevcut                   NUMBER  := 0;
      ln_hesap_islem              NUMBER  := 0;
      ln_teklif_islem             NUMBER  := 0;
      ln_teminat_islem            NUMBER  := 0;
      ln_alma_gun_sayisi          NUMBER := 0;
      ls_hesap_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ls_teklif_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ln_hesap_tutar              NUMBER;
      ln_teklif_doviz_tutar          NUMBER;
      ln_alinan_toplamtutar_tekdoviz NUMBER := 0;
      teklif_karsilanmamis        EXCEPTION;
      hic_teminat_girilmemis      EXCEPTION;
      TOPLAM_teklif_karsilanmamis EXCEPTION;
      grup_teklif_karsilanmamis      EXCEPTION;
      toplam_teklif_karsilanmamis EXCEPTION;
      ln_adet                      NUMBER := 0;
      ln_grup_no              NUMBER:= 0;
      ln_grup_karsilanmis      NUMBER := 0;
      ls_hata VARCHAR2(2000);
      ln_kredi_hesap_no      NUMBER;
         ls_aranilan_doviz_kodu      CBS_HESAP_KREDI.doviz_kodu%TYPE;
      ln_teklifmusteri_no      number :=0 ;

CURSOR cur_hesap_kredi
      IS
         SELECT Pkg_Kredi.SF_SATIRNODAN_TEKLIFNOAL(kredi_teklif_satir_numara)  KREDI_TEKLIF_NO,
                 hesap_no,
                 kredi_teklif_satir_numara,
                NVL(Pkg_Muhasebe.banka_tarihi_bul -TRUNC(acilis_tarihi),0) alma_gun_sayisi,
                decode(endeks_doviz_kodu,null,abs(nvl(pkg_kredi.sf_Bakiye_Al(hesap_no),0)), abs(nvl(pkg_kredi.sf_endeks_doviz_bakiye_al(hesap_no),0))) tutar, --030604
                NVL(endeks_doviz_kodu,doviz_kodu) doviz_kodu
           FROM CBS_HESAP_KREDI
          WHERE NVL(kredi_teklif_satir_numara,0) <> 0
                  AND durum_kodu = 'A'
                and urun_tur_kod not in( 'TAHAKKUK','TAKIPKRED')
                and nvl(pkg_kredi.sf_bakiye_al(hesap_no),0) <> 0
         order by hesap_No;
/* grup no 0 dan fakl? olanlar icin veya kosulu ile bak?lacakt?r */
          CURSOR cursor_grup1 IS
         SELECT DISTINCT GRUP_NO grup_no
         FROM cbs_vw_teklif_satir_teminat
         WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
            AND nvl(alma_gun_sayisi,0) <= nvl(ln_alma_gun_Sayisi,0)
            GROUP BY  GRUP_NO;

/* teklifdeki alma gun sayisi girilmemi? olan kay?tlar i?in teminat ko?ullar? a??l?? s?ras?nda kar??lanmal?d?r. */
/* teklif satirindaki girilen de?erlere g?re hesaplanan teminat tutar? hesab?n d?zi kodundad?r.*/

/* 1. a?amada tutar alan? dolu olanlar i?in teklif ko?ullar? ayn? doviz kodunda kar??lanmal?*/
      CURSOR cursor_teklif_satir_toplam_1
      IS
         SELECT teklif_no,
                 musteri_no,
                 teklif_satir_no,
                 teminat_kodu,
                 teminat_alt_kodu,
                 doviz_kodu teklif_doviz_kodu,
                 NVL(doviz_kodu,ls_hesap_doviz_kodu) doviz_kodu,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                               NVL(doviz_kodu,ls_hesap_doviz_kodu),
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani)),0) tutar,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                             doviz_kodu,
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani
                                                          ,'ORIGINKOD'
                                                          )),0)  teklif_doviz_tutar
           FROM cbs_vw_teklif_satir_teminat
          WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
            AND nvl(alma_gun_sayisi,0) <= nvl(ln_alma_gun_Sayisi,0)
            AND grup_no = ln_grup_no
            GROUP BY  teklif_no,musteri_no, teklif_satir_no, teminat_kodu, teminat_alt_kodu,doviz_kodu
            ORDER BY     NVL(doviz_kodu,ls_hesap_doviz_kodu);

      CURSOR cur_teminat_islem
      IS
         SELECT  teminat_kodu,teminat_alt_kodu ,
                  teminat_doviz_kodu,
                  SUM(NVL (kullanilan_tutar, 0)) kullanilan_tutar
          FROM cbs_vw_teminat
          WHERE   teminat_hesap_no = ln_kredi_hesap_no AND
                     teminat_kodu = ls_teminat_kodu AND
                  teminat_alt_kodu = NVL(ls_teminat_alt_kodu,teminat_alt_kodu) and
                  teminat_durumu = 'ACIK' and
/*230704 sozlesme disinda kontrol edilsin*/
                  (    (  teminat_kodu != '15' and  NVL(BAKIYE,0) >= 0  AND Pkg_Teminat.SF_TEMINAT_DURUMU_UYGUNMU( TEMINAT_KODU, REFERANS, REF_CEK_NO, BOLUM_KODU, SENET_NO, MUSTERI_NO, KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO ,sozlesme_no,ek_sozlesme_no)= 'E')
                  or (  teminat_kodu  = '15' and 1=1 ) )
                  AND teminat_doviz_kodu = NVL(ls_aranilan_doviz_kodu,teminat_doviz_kodu )
             GROUP BY     teminat_kodu,
                            teminat_alt_kodu ,
                            teminat_doviz_kodu;

 BEGIN

 ln_teminat_islem := 0;

 BEGIN
  FOR cur_hesap IN cur_hesap_kredi
   LOOP
    BEGIN
             ln_alma_gun_sayisi    := cur_hesap.alma_gun_sayisi;
             ln_teklif_no := cur_hesap.kredi_teklif_no;
             ln_teklif_satir_numara := cur_hesap.kredi_teklif_satir_numara;
             ln_hesap_tutar    := cur_hesap.tutar;
              ls_hesap_doviz_kodu :=cur_hesap.doviz_kodu;
             ln_kredi_hesap_no :=cur_hesap.hesap_no;
             ln_alinan_toplam_tutar := 0;
             ln_alinmasi_gereken_tutar := 0;
             ln_teklif_doviz_tutar  := 0;
               ln_alinan_toplamtutar_tekdoviz := 0;
                ln_alinmasi_gereken_tutar  := 0 ;

     FOR cur_grup IN cursor_grup1 LOOP
        ln_grup_no := cur_grup.grup_no;
       ln_grup_karsilanmis :=0 ;
         ls_aranilan_doviz_kodu :=NULL;
       ln_alinan_toplam_tutar := 0;
       ln_alinmasi_gereken_tutar := 0;
       ln_teklif_doviz_tutar  := 0;
       ln_alinan_toplamtutar_tekdoviz := 0;
       ln_alinmasi_gereken_tutar  := 0 ;
        /* 1. a?ama tutar alan? dolu ise */
             FOR cur_teklif_satir_toplam_1 IN cursor_teklif_satir_toplam_1
             LOOP
              BEGIN
                ls_teminat_kodu            := cur_teklif_satir_toplam_1.teminat_kodu;
                ls_teminat_alt_kodu        := cur_teklif_satir_toplam_1.teminat_alt_kodu;
                ln_alinmasi_gereken_tutar  := cur_teklif_satir_toplam_1.tutar;
                ln_teklif_doviz_tutar      := cur_teklif_satir_toplam_1.teklif_doviz_tutar;
                ls_teklif_doviz_kodu       := cur_teklif_satir_toplam_1.doviz_kodu;
                ln_alinan_toplam_tutar        := 0;
                ln_alinan_tutar            := 0;
                ln_mevcut := 1;
                  ls_aranilan_doviz_kodu :=NULL;
                ln_teklifmusteri_no                := cur_teklif_satir_toplam_1.musteri_No;
    /* teklif doviz kodu dolu ise teklifin doviz kodunda aran?r, bos ise 15 sozlesme icin kredi hesap doviz kodunda digerlerinde kosul aranmaz */
                 IF cur_teklif_satir_toplam_1.teklif_doviz_kodu IS NULL THEN
                   IF  ls_teminat_kodu = '15' THEN /*sozlesmeler de kredi hesab?n?n doviz kodu */
                          ls_aranilan_doviz_kodu := ls_hesap_doviz_kodu;
                   ELSE
                        ls_aranilan_doviz_kodu  := NULL;
                    END IF;
                 ELSE
                         ls_aranilan_doviz_kodu  := cur_teklif_satir_toplam_1.teklif_doviz_kodu;
                 END IF;

                FOR cur_teminat IN cur_teminat_islem
                LOOP
                 BEGIN
                   ln_teminat_islem := ln_teminat_islem + 1;
                   ln_alinan_tutar := cur_teminat.kullanilan_tutar;

                   IF cur_hesap.doviz_kodu <> cur_teminat.teminat_doviz_kodu
                   THEN
                          ln_alinan_tutar :=  Pkg_Teminat.sf_teminattutar_hesdovizcevir
                                                 (ln_alinan_tutar,
                                                  cur_teminat.teminat_doviz_kodu,
                                                  cur_hesap.doviz_kodu
                                                 );
                    END IF;

                    ln_alinan_toplam_tutar := NVL (ln_alinan_toplam_tutar, 0)  + NVL (ln_alinan_tutar, 0);

                 EXCEPTION WHEN OTHERS THEN
                      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -4 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);

                 END;
                END LOOP;

                IF NVL (ln_alinmasi_gereken_tutar, 0) >  NVL (ln_alinan_toplam_tutar, 0)  AND NVL(ln_grup_no,0) = 0
                THEN
                   /* alinmasi gereken tutar kar??lanmam??    RAISE teklif_karsilanmamis;*/
                    IF ls_teklif_doviz_kodu IS NULL THEN
                         ln_teklif_doviz_tutar := NVL(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
                     END IF;
                      ln_alinan_toplamtutar_tekdoviz := Pkg_Kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );
                      sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                                   2,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                                  ls_TEMINAT_KODU,ls_TEMINAT_ALT_KODU, ln_teklif_doviz_tutar,
                                                  ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                                  ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
                      ln_adet := ln_adet + 1 ;

                END IF;

            IF NVL (ln_alinmasi_gereken_tutar, 0) <=  NVL (ln_alinan_toplam_tutar, 0) AND NVL(ln_grup_no,0) <> 0  THEN
               /* grup olarak alinmasi gereken tutar kar??lanm??*/
               ln_grup_karsilanmis := ln_grup_karsilanmis + 1;
            END IF;

           EXCEPTION WHEN OTHERS THEN
                  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -5 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);

           END;

           END LOOP;

           /*gruplar icin karsilanma durumu kontrol edilir.*/
        IF NVL(ln_grup_no,0) <> 0 AND  NVL(ln_grup_karsilanmis,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
                  sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                                  4,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                                  ls_TEMINAT_KODU,ls_TEMINAT_ALT_KODU, ln_teklif_doviz_tutar,
                                                  ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                                  ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
                  ln_adet := ln_adet + 1 ;
         END IF;

     END LOOP;

     COMMIT;

    EXCEPTION WHEN OTHERS THEN
             Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -8 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);
    END;

   END LOOP;

      IF ln_teminat_islem = 0 AND ln_mevcut <> 0
      THEN
         /* teminat islem giri?i yap?lmam??*/

            sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                      1,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                      ls_TEMINAT_KODU,ls_TEMINAT_ALT_KODU, ln_teklif_doviz_tutar,
                                      ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                      ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
              ln_adet := ln_adet + 1 ;
      END IF;

  EXCEPTION WHEN OTHERS THEN
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -10 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);


  END;

  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GenerateMessage(
                                  Pkg_Hata.getucpointer
                                  || '682'
                                  || Pkg_Hata.getdelimiter
                                  || TO_CHAR(ln_adet)
                                  || Pkg_Hata.getdelimiter
                                  || Pkg_Hata.getucpointer
                                 )) ;
  COMMIT;

  EXCEPTION WHEN OTHERS THEN
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -9 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);


   END;


  PROCEDURE TeminatEksikRaporlamusteri(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
  IS
      ln_teklif_no                CBS_KREDI_TEKLIF.teklif_no%TYPE;
      ln_teklif_satir_numara      NUMBER;
      ls_teminat_kodu             CBS_TEMINAT_ALT_KODLARI.teminat_kodu%TYPE;
      ls_teminat_alt_kodu         CBS_TEMINAT_ALT_KODLARI.teminat_alt_kodu%TYPE;
      ln_alinan_tutar             NUMBER;
      ln_alinan_toplam_tutar      NUMBER;
      ln_alinmasi_gereken_tutar   NUMBER;
      ln_mevcut                   NUMBER  := 0;
      ln_hesap_islem              NUMBER  := 0;
      ln_teklif_islem             NUMBER  := 0;
      ln_teminat_islem            NUMBER  := 0;
      ln_alma_gun_sayisi          NUMBER := 0;
      ls_hesap_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ls_teklif_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ln_hesap_tutar              NUMBER;
      ln_teklif_doviz_tutar          NUMBER;
      ln_alinan_toplamtutar_tekdoviz NUMBER := 0;
      teklif_karsilanmamis        EXCEPTION;
      hic_teminat_girilmemis      EXCEPTION;
      TOPLAM_teklif_karsilanmamis EXCEPTION;
      grup_teklif_karsilanmamis      EXCEPTION;
      toplam_teklif_karsilanmamis EXCEPTION;
      ln_adet                      NUMBER := 0;
      ln_grup_no              NUMBER:= 0;
      ln_grup_karsilanmis      NUMBER := 0;
      ls_hata VARCHAR2(2000);
      ln_kredi_hesap_no      NUMBER;
         ls_aranilan_doviz_kodu      CBS_HESAP_KREDI.doviz_kodu%TYPE;
      ln_teklifmusteri_no          number := 0;

/* grup no 0 dan fakl? olanlar icin veya kosulu ile bak?lacakt?r */
          CURSOR cursor_grup1 IS
         SELECT DISTINCT a.teklif_no,
                          a.musteri_no,
                         grup_no
         FROM CBS_KREDI_TEKLIF a,
                CBS_KREDI_TEKLIF_TEMINAT b
         WHERE a.TEKLIF_NO = b.TEKLIF_NO and
               a.DURUM_KODU = 'A'
                and alma_gun_sayisi <= NVL(Pkg_Muhasebe.banka_tarihi_bul -TRUNC(teklif_tarihi),0)
         GROUP BY   a.teklif_no,a.musteri_no,GRUP_NO;

/* teklifdeki alma gun sayisi girilmemi? olan kay?tlar i?in teminat ko?ullar? a??l?? s?ras?nda kar??lanmal?d?r. */
/* teklif satirindaki girilen de?erlere g?re hesaplanan teminat tutar? hesab?n d?zi kodundad?r.*/

/* 1. a?amada tutar alan? dolu olanlar i?in teklif ko?ullar? ayn? doviz kodunda kar??lanmal?*/
      CURSOR cursor_teklif_satir_toplam_1
      IS
         SELECT a.teklif_no,
                 a.musteri_no,
                 teminat_kodu,
                 teminat_alt_kodu,
                 doviz_kodu teklif_doviz_kodu,
                 NVL(doviz_kodu,ls_hesap_doviz_kodu) doviz_kodu,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                               NVL(doviz_kodu,ls_hesap_doviz_kodu),
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani)),0) tutar,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                             doviz_kodu,
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani
                                                          ,'ORIGINKOD'
                                                          )),0)  teklif_doviz_tutar
         FROM CBS_KREDI_TEKLIF a,
                CBS_KREDI_TEKLIF_TEMINAT b
         WHERE a.teklif_no = ln_teklif_no and
                a.TEKLIF_NO = b.TEKLIF_NO and
               a.DURUM_KODU = 'A' and
                 alma_gun_sayisi <= NVL(Pkg_Muhasebe.banka_tarihi_bul -TRUNC(teklif_tarihi),0) and
                   b.grup_no = ln_grup_no
            GROUP BY  a.teklif_no, a.musteri_no,teminat_kodu, teminat_alt_kodu,doviz_kodu
            ORDER BY     NVL(doviz_kodu,ls_hesap_doviz_kodu);

      CURSOR cur_teminat_islem
      IS
         SELECT  teminat_kodu,teminat_alt_kodu ,
                  teminat_doviz_kodu,
                  SUM(NVL (kullanilan_tutar, 0)) kullanilan_tutar
          FROM cbs_vw_teminat
          WHERE   teminat_hesap_no is null AND
                    teklif_musteri_no = ln_teklifmusteri_no and
                     teminat_kodu = ls_teminat_kodu AND
                  teminat_alt_kodu = NVL(ls_teminat_alt_kodu,teminat_alt_kodu)
                  AND teminat_durumu = 'ACIK'
                    AND NVL(BAKIYE,0) >= 0
                  AND Pkg_Teminat.SF_TEMINAT_DURUMU_UYGUNMU( TEMINAT_KODU, REFERANS, REF_CEK_NO, BOLUM_KODU, SENET_NO, MUSTERI_NO, KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO ,sozlesme_no,ek_sozlesme_no)= 'E'
                  AND teminat_doviz_kodu = NVL(ls_aranilan_doviz_kodu,teminat_doviz_kodu )
             GROUP BY     teminat_kodu,
                            teminat_alt_kodu ,
                            teminat_doviz_kodu;

 BEGIN

    ln_teminat_islem := 0;

     FOR cur_grup IN cursor_grup1 LOOP
          ln_teklif_no := cur_grup.teklif_no;
          ln_hesap_tutar    :=  0;--cur_hesap.tutar;
       ls_hesap_doviz_kodu :=pkg_genel.lc_al;--cur_hesap.doviz_kodu;
        ln_grup_no := cur_grup.grup_no;
       ln_grup_karsilanmis :=0 ;
         ls_aranilan_doviz_kodu :=NULL;
       ln_teminat_islem :=0;
       ln_adet := 0;
         ln_alinan_toplam_tutar := 0;
       ln_alinmasi_gereken_tutar := 0;
       ln_teklif_doviz_tutar  := 0;
       ln_alinan_toplamtutar_tekdoviz := 0;
       ln_alinmasi_gereken_tutar  := 0 ;


         -- ln_alma_gun_sayisi    := cur_grup.alma_gun_sayisi;
        /* 1. a?ama tutar alan? dolu ise */
             FOR cur_teklif_satir_toplam_1 IN cursor_teklif_satir_toplam_1
             LOOP
              BEGIN
                ls_teminat_kodu            := cur_teklif_satir_toplam_1.teminat_kodu;
                ls_teminat_alt_kodu        := cur_teklif_satir_toplam_1.teminat_alt_kodu;
                ln_alinmasi_gereken_tutar  := cur_teklif_satir_toplam_1.tutar;
                ln_teklif_doviz_tutar      := cur_teklif_satir_toplam_1.teklif_doviz_tutar;
                ls_teklif_doviz_kodu       := cur_teklif_satir_toplam_1.doviz_kodu;
                ln_alinan_toplam_tutar        := 0;
                ln_alinan_tutar            := 0;
                  ls_aranilan_doviz_kodu        :=NULL;
                ln_teklifmusteri_no              := cur_teklif_satir_toplam_1.musteri_No;
                ln_teminat_islem             := 0;
    /* teklif doviz kodu dolu ise teklifin doviz kodunda aran?r, bos ise 15 sozlesme icin kredi hesap doviz kodunda digerlerinde kosul aranmaz */
                 IF cur_teklif_satir_toplam_1.teklif_doviz_kodu IS NULL THEN
                   IF  ls_teminat_kodu = '15' THEN /*sozlesmeler de kredi hesab?n?n doviz kodu */
                          ls_aranilan_doviz_kodu := ls_hesap_doviz_kodu;
                   ELSE
                        ls_aranilan_doviz_kodu  := NULL;
                    END IF;
                 ELSE
                         ls_aranilan_doviz_kodu  := cur_teklif_satir_toplam_1.teklif_doviz_kodu;
                 END IF;

                FOR cur_teminat IN cur_teminat_islem
                LOOP
                 BEGIN
                   ln_teminat_islem := ln_teminat_islem + 1;
                   ln_alinan_tutar := cur_teminat.kullanilan_tutar;

                   IF ls_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu
                   THEN
                          ln_alinan_tutar :=  Pkg_Teminat.sf_teminattutar_hesdovizcevir
                                                 (ln_alinan_tutar,
                                                  cur_teminat.teminat_doviz_kodu,
                                                  ls_hesap_doviz_kodu
                                                 );
                    END IF;
                    ln_alinan_toplam_tutar := NVL (ln_alinan_toplam_tutar, 0)  + NVL (ln_alinan_tutar, 0);

                 EXCEPTION WHEN OTHERS THEN
                      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -4 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);

                 END;
                END LOOP;

                IF NVL (ln_alinmasi_gereken_tutar, 0) >  NVL (ln_alinan_toplam_tutar, 0)  AND NVL(ln_grup_no,0) = 0
                THEN
                   /* alinmasi gereken tutar kar??lanmam??    RAISE teklif_karsilanmamis;*/
                    IF ls_teklif_doviz_kodu IS NULL THEN
                         ln_teklif_doviz_tutar := NVL(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
                     END IF;
                      ln_alinan_toplamtutar_tekdoviz := Pkg_Kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );
                      sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                                   2,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                                  ls_teminat_kodu,ls_teminat_alt_kodu, ln_teklif_doviz_tutar,
                                                  ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                                  ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
                      ln_adet := ln_adet + 1 ;

                END IF;

            IF NVL (ln_alinmasi_gereken_tutar, 0) <=  NVL (ln_alinan_toplam_tutar, 0) AND NVL(ln_grup_no,0) <> 0  THEN
               /* grup olarak alinmasi gereken tutar kar??lanm??*/
               ln_grup_karsilanmis := ln_grup_karsilanmis + 1;
            END IF;

           EXCEPTION WHEN OTHERS THEN
                  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -5 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);

           END;

           END LOOP;

           /*gruplar icin karsilanma durumu kontrol edilir.*/
        IF NVL(ln_grup_no,0) <> 0 AND  NVL(ln_grup_karsilanmis,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
                  sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                                  4,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                                  ls_TEMINAT_KODU,ls_TEMINAT_ALT_KODU, ln_teklif_doviz_tutar,
                                                  ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                                  ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
                  ln_adet := ln_adet + 1 ;
         END IF;

      IF  ln_teminat_islem = 0  and ln_adet = 0 THEN
         /* teminat islem giri?i yap?lmam??*/

           sp_insert_cbs_rpt_teminateksik(pn_grup_no , pn_log_no ,ps_program_kod ,
                                                   2,ln_kredi_hesap_no,ln_teklif_satir_numara,
                                                  ls_teminat_kodu,ls_teminat_alt_kodu, ln_teklif_doviz_tutar,
                                                  ls_teklif_doviz_kodu ,ln_alinan_toplamtutar_tekdoviz,
                                                  ln_alinmasi_gereken_tutar,ln_alinan_toplam_tutar,ln_teklifmusteri_no) ;
              ln_adet := ln_adet + 1 ;
      END IF;
    END LOOP;
    COMMIT;

    EXCEPTION WHEN OTHERS THEN
              Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod, 'Collateral Lack Report -9 error occured. Error Code:' || TO_CHAR (SQLCODE) || '-'|| SQLERRM);
   END;


PROCEDURE   musteri_teklifkosulkarsilandi (
            pn_musteri_no                     number,
            pn_ref_no out number )
 is pragma autonomous_transaction;
      ln_teklif_no                CBS_KREDI_TEKLIF.teklif_no%TYPE;
      ln_teklif_satir_numara      NUMBER;
      ls_teminat_kodu             CBS_TEMINAT_ALT_KODLARI.teminat_kodu%TYPE;
      ls_teminat_alt_kodu         CBS_TEMINAT_ALT_KODLARI.teminat_alt_kodu%TYPE;
      ln_alinan_tutar             NUMBER;
      ln_alinan_toplam_tutar      NUMBER;
      ln_alinmasi_gereken_tutar   NUMBER;
      ln_mevcut                   NUMBER  := 0;
      ln_hesap_islem              NUMBER  := 0;
      ln_teklif_islem             NUMBER  := 0;
      ln_teminat_islem            NUMBER  := 0;
      ln_alma_gun_sayisi          NUMBER := 0;
      ls_hesap_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ls_teklif_doviz_kodu          CBS_HESAP_KREDI.DOVIZ_KODU%TYPE;
      ln_hesap_tutar              NUMBER;
      ln_teklif_doviz_tutar          NUMBER;
      ln_alinan_toplamtutar_tekdoviz NUMBER := 0;
      ls_teminat_doviz            cbs_hesap_kredi.doviz_kodu%type;
      ln_adet                      NUMBER := 0;
      ln_grup_no              NUMBER:= 0;
      ln_grup_karsilanmis      NUMBER := 0;
      ls_hata VARCHAR2(2000);
      ln_kredi_hesap_no      NUMBER;
         ls_aranilan_doviz_kodu      CBS_HESAP_KREDI.doviz_kodu%TYPE;
      ln_teklifmusteri_no          number := 0;
      ls_teminat_kodacik           varchar(2000) := '' ;
      ls_teminat_altkodacik            varchar(2000) := '' ;
      Ps_karsilandimi              Varchar2(1) := 'E';
      ln_ref_no                      number :=0;
        ps_kredi_hesap_doviz_kodu cbs_hesap_kredi.doviz_kodu%type;
      ps_kredi_endeksdoviz cbs_hesap_kredi.doviz_kodu%type;
      pn_kredi_hesap_tutar number;

/* grup no 0 dan fakl? olanlar icin veya kosulu ile bak?lacakt?r */
          CURSOR cursor_grup1 IS
         SELECT DISTINCT a.teklif_no, a.musteri_no,grup_no
         FROM CBS_KREDI_TEKLIF a,
                CBS_KREDI_TEKLIF_TEMINAT b
         WHERE a.TEKLIF_NO = b.TEKLIF_NO and
               a.DURUM_KODU = 'A' and
               a.musteri_no = pn_musteri_no
               and alma_gun_sayisi <= NVL(Pkg_Muhasebe.banka_tarihi_bul -TRUNC(teklif_tarihi),0)
         GROUP BY   a.teklif_no,a.musteri_no,GRUP_NO;

/* teklifdeki alma gun sayisi girilmemi? olan kay?tlar i?in teminat ko?ullar? a??l?? s?ras?nda kar??lanmal?d?r. */
/* teklif satirindaki girilen de?erlere g?re hesaplanan teminat tutar? hesab?n d?zi kodundad?r.*/

/* 1. a?amada tutar alan? dolu olanlar i?in teklif ko?ullar? ayn? doviz kodunda kar??lanmal?*/
      CURSOR cursor_teklif_satir_toplam_1
      IS
         SELECT a.teklif_no,
                 a.musteri_no,
                 teminat_kodu,
                 teminat_alt_kodu,
                 doviz_kodu teklif_doviz_kodu,
                 NVL(doviz_kodu,ls_hesap_doviz_kodu) doviz_kodu,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                               NVL(doviz_kodu,ls_hesap_doviz_kodu),
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani)),0) tutar,
                NVL(SUM(Pkg_Teminat.sf_teklif_teminat_tutari( tutar,
                                                             doviz_kodu,
                                                                ln_hesap_tutar    ,
                                                            ls_hesap_doviz_kodu,
                                                            marj,
                                                            katilim_orani
                                                          ,'ORIGINKOD'
                                                          )),0)  teklif_doviz_tutar
         FROM CBS_KREDI_TEKLIF a,
                CBS_KREDI_TEKLIF_TEMINAT b
         WHERE a.teklif_no = ln_teklif_no and
                a.TEKLIF_NO = b.TEKLIF_NO and
               a.DURUM_KODU = 'A' and
                   b.grup_no = ln_grup_no and
               alma_gun_sayisi <= NVL(Pkg_Muhasebe.banka_tarihi_bul -TRUNC(teklif_tarihi),0)
            GROUP BY  a.teklif_no, a.musteri_no,teminat_kodu, teminat_alt_kodu,doviz_kodu
            ORDER BY     NVL(doviz_kodu,ls_hesap_doviz_kodu);

      CURSOR cur_teminat_islem
      IS
         SELECT  teminat_kodu,teminat_alt_kodu ,
                  teminat_doviz_kodu,
                  SUM(NVL (kullanilan_tutar, 0)) kullanilan_tutar
          FROM cbs_vw_teminat
          WHERE   nvl(teminat_hesap_no,0) = 0 AND
                    teklif_musteri_no = ln_teklifmusteri_no and
                     teminat_kodu = ls_teminat_kodu AND
                  teminat_alt_kodu = NVL(ls_teminat_alt_kodu,teminat_alt_kodu)
                  AND teminat_durumu = 'ACIK'
                    AND NVL(BAKIYE,0) >= 0
                  AND Pkg_Teminat.SF_TEMINAT_DURUMU_UYGUNMU( TEMINAT_KODU, REFERANS, REF_CEK_NO, BOLUM_KODU, SENET_NO, MUSTERI_NO, KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO ,sozlesme_no,ek_sozlesme_no)= 'E'
                  AND teminat_doviz_kodu = NVL(ls_aranilan_doviz_kodu,teminat_doviz_kodu )
             GROUP BY     teminat_kodu,
                            teminat_alt_kodu ,
                            teminat_doviz_kodu;

 BEGIN

   Ps_karsilandimi := 'E';
   ln_teminat_islem := 0;

   select SQ_CBS_TEMINATTEKLIFSATIR_IZLE.NEXTVAL
   into  ln_ref_no
   from dual;

   pn_ref_no :=ln_ref_no;

     FOR cur_grup IN cursor_grup1 LOOP
       Ps_karsilandimi := 'E';
          ln_teklif_no := cur_grup.teklif_no;
          ln_hesap_tutar    :=  0;--cur_hesap.tutar;
       ls_hesap_doviz_kodu :=pkg_genel.lc_al;--cur_hesap.doviz_kodu;
        ln_grup_no := cur_grup.grup_no;
       ln_grup_karsilanmis :=0 ;
         ls_aranilan_doviz_kodu :=NULL;
       ln_teminat_islem :=0;
       ln_adet := 0;
--       ln_alma_gun_sayisi    := cur_grup.alma_gun_sayisi;

        /* 1. a?ama tutar alan? dolu ise */
             FOR cur_teklif_satir_toplam_1 IN cursor_teklif_satir_toplam_1
             LOOP
                Ps_karsilandimi := 'E';
                ls_teminat_kodu            := cur_teklif_satir_toplam_1.teminat_kodu;
                ls_teminat_alt_kodu        := cur_teklif_satir_toplam_1.teminat_alt_kodu;
                ln_alinmasi_gereken_tutar  := cur_teklif_satir_toplam_1.tutar;
                ln_teklif_doviz_tutar      := cur_teklif_satir_toplam_1.teklif_doviz_tutar;
                ls_teklif_doviz_kodu       := cur_teklif_satir_toplam_1.doviz_kodu;
                ln_alinan_toplam_tutar        := 0;
                ln_alinan_tutar            := 0;
                  ls_aranilan_doviz_kodu        :=NULL;
                ln_teklifmusteri_no              := cur_teklif_satir_toplam_1.musteri_No;
                ln_teminat_islem             := 0;
                ln_mevcut := 1;
    /* teklif doviz kodu dolu ise teklifin doviz kodunda aran?r, bos ise 15 sozlesme icin kredi hesap doviz kodunda digerlerinde kosul aranmaz */
                 IF cur_teklif_satir_toplam_1.teklif_doviz_kodu IS NULL THEN
                   IF  ls_teminat_kodu = '15' THEN /*sozlesmeler de kredi hesab?n?n doviz kodu */
                          ls_aranilan_doviz_kodu := ls_hesap_doviz_kodu;
                   ELSE
                        ls_aranilan_doviz_kodu  := NULL;
                    END IF;
                 ELSE
                         ls_aranilan_doviz_kodu  := cur_teklif_satir_toplam_1.teklif_doviz_kodu;
                 END IF;

                FOR cur_teminat IN cur_teminat_islem
                LOOP
                   ln_teminat_islem := ln_teminat_islem + 1;
                   ln_alinan_tutar := cur_teminat.kullanilan_tutar;

                   IF ls_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu
                   THEN
                          ln_alinan_tutar :=  Pkg_Teminat.sf_teminattutar_hesdovizcevir
                                                 (ln_alinan_tutar,
                                                  cur_teminat.teminat_doviz_kodu,
                                                  ls_hesap_doviz_kodu
                                                 );
                    END IF;
                    ln_alinan_toplam_tutar := NVL (ln_alinan_toplam_tutar, 0)  + NVL (ln_alinan_tutar, 0);
                END LOOP;



                IF NVL (ln_alinmasi_gereken_tutar, 0) >  NVL (ln_alinan_toplam_tutar, 0)  AND NVL(ln_grup_no,0) = 0
                THEN
                   /* alinmasi gereken tutar kar??lanmam??    RAISE teklif_karsilanmamis;*/
                       ps_karsilandimi := 'H';
                    IF ls_teklif_doviz_kodu IS NULL THEN
                         ln_teklif_doviz_tutar := NVL(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
                     END IF;
                      ln_alinan_toplamtutar_tekdoviz := Pkg_Kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );
                      ln_adet := ln_adet + 1 ;
                END IF;

            IF NVL (ln_alinmasi_gereken_tutar, 0) <=  NVL (ln_alinan_toplam_tutar, 0) AND NVL(ln_grup_no,0) <> 0  THEN
               /* grup olarak alinmasi gereken tutar kar??lanm??*/
               ln_grup_karsilanmis := ln_grup_karsilanmis + 1;
            END IF;

                ls_teminat_kodacik    := ls_teminat_kodu ||'-' || pkg_teminat.Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
                 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || pkg_teminat.Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;


                   insert into CBS_TEMINAT_TEKLIFSATIR_IZLEME
                   (                ref_no,
                                    musteri_no,
                                 teklif_satir_no,
                                    teminat_kodu,
                                 teminat_alt_kodu,
                                 teminat_turu,
                                 teklif_tutar,
                                 teklif_doviz_kodu,
                                 grup_no,
                                 teminat_hesap_no,
                                    teminat_doviz_kodu,
                                 teminat_kullanilan_tutar,
                                 teminat_kul_teklifdvzli_tutar,
                                 karsilanma
                                 )
                    values        (
                                 ln_ref_no,
                                    pn_musteri_no,
                                 0,
                                    ls_teminat_kodu,
                                 ls_teminat_alt_kodu,
                                 NVL(ls_teminat_altkodacik,ls_teminat_kodacik  ),
                                 ln_alinmasi_gereken_tutar,--ln_teklif_doviz_tutar,
                                 nvl(ls_hesap_doviz_kodu,ls_teklif_doviz_kodu),
                                 ln_grup_no,
                                 0,
                                    ls_teminat_doviz,
                                 ln_alinan_toplam_tutar ,
                                 ln_alinan_toplamtutar_tekdoviz,
                                 ps_karsilandimi);

           END LOOP;

    /*gruplar icin karsilanma durumu kontrol edilir.*/
         IF nvl(ln_grup_no,0) <> 0 then
             if  nvl(ln_grup_karsilanmis,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
                 ps_karsilandimi := 'H';
             else
                   ps_karsilandimi := 'E';
             end if;
             --  RAISE grup_teklif_karsilanmamis;
                  ls_teminat_kodacik    := ls_teminat_kodu ||'-' || pkg_teminat.Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
              ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || pkg_teminat.Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

             if ls_teklif_doviz_kodu is null then
                         ln_teklif_doviz_tutar := nvl(ln_alinmasi_gereken_tutar,0);
                        ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
             end if;
              ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );


              update CBS_TEMINAT_TEKLIFSATIR_IZLEME
              set   karsilanma =  ps_karsilandimi
              where ref_no = ln_ref_no  and
                    grup_no = ln_grup_no ;

       END IF;


    END LOOP;
    COMMIT;
 End;

Function islem_yillkomoran_al(pn_islem_no number) return number
is
  ln_oran number := 0;

    Begin

       select nvl(yillik_oran,0)
        into ln_oran
        from CBS_MASRAF_ITH_IHR
        where referans=(select referans
                        from cbs_tm_hg_acilis_islem
                        where tx_no=pn_islem_no);

    return      ln_oran;

    Exception when others then return 0;
    End;
function sf_devirbakiyebul (pn_hesap_no number ,pd_bakiye_tarih date) return number
 is
 ln_bakiye number  :=0 ;
 ln_adet   number  := 0;

 cursor cur_1 is
       select Bakiye
      from   cbs_hesap_bakiye
      where  hesap_no = pn_hesap_no;


 cursor cur_2 is
/*
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no and
                to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY') in(
              select max( to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY'))
                      from   cbs_hesap_gunluk_bakiye
                      where  hesap_no = pn_hesap_no and
                                 to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY') <= TRUNC(pd_bakiye_tarih) ) ;
*/
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no and
                BALANCE_DATE =(
              select max( BALANCE_DATE)
                      from   cbs_hesap_gunluk_bakiye
                      where  hesap_no = pn_hesap_no and
                                 BALANCE_DATE <= TRUNC(pd_bakiye_tarih) ) ;

  /* cursor cur_3 is
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no
                order by yil ,ay,gun     ;
    */
 Begin

   if  pd_bakiye_tarih is null then
     open  cur_1 ;
         fetch cur_1 into ln_bakiye;
   else
     for c_2 in cur_2 loop
       ln_bakiye := c_2.bakiye ;
       ln_adet := ln_adet + 1 ;
     end loop;
     /*if  nvl(ln_adet,0) = 0 then
      open  cur_3 ;
             fetch cur_3 into ln_bakiye;
     end if;
     */
   end if;

    return nvl(ln_bakiye,0);

  exception when others then return 0;

 End;

 /* Ekstre bas?lmas? istenmeyenler icin kontoldur. */
  Function Sf_KrediHesap_UrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2
  is
     ls_uygun  varchar2(1) := 'H';
  Begin
        if  ps_urun_tur_kod in ( 'TAHAKKUK','LEASING','TAKIPKRED','TAZMIN-LC','TAZMIN-FC')  then
             ls_uygun := 'H';
        else
            ls_uygun := 'E';
        end if;

/* bireysel kredilere ekstre cikmasin */
        if pkg_bireysel_kredi.Sf_BireyselUrunUygunmu(ps_urun_tur_kod ) = 'E' then
          ls_uygun := 'H';
         end if;

       return ls_uygun ;

    Exception
      When Others Then return 'H';
  End ;

Function sf_sektoradi_al(pn_musteri_no number) return varchar2
is
 ls_sektor_adi varchar2(2000);
Begin
     select sektor_adi
     into   ls_sektor_adi
     from   cbs_musteri  a, cbs_sektor_kodlari b
     where musteri_no = pn_musteri_no and
            a.sektor_kod = b.sektor_kodu ;

     return ls_sektor_adi;

 Exception when others then return null;
End;

Function sf_grupadi_al(pn_musteri_no number) return varchar2
is
 ls_aciklama varchar2(2000);
Begin
     select b.aciklama
     into   ls_aciklama
     from   cbs_musteri  a, cbs_grup_kodlari b
     where  musteri_no = pn_musteri_no and
             a.grup_kod = b.grup_kodu ;

     return ls_aciklama;

 Exception when others then return null;

End;

/* faiz orani guncellemesi yap?ld?ysa */
Function sf_faizorani_degistimi(pn_tx_no number ,pn_hesap_no number,pn_faiz_orani number) return varchar2
is
  ln_faiz_orani number := 0;
  Begin

      select faiz_orani
      into ln_faiz_orani
      from cbs_hesap_kredi_islem
      where hesap_no = pn_hesap_no and
              tx_no in(
                  select Max(tx_no)
                  from cbs_hesap_kredi_islem
                  where tx_no < pn_tx_no and
                          hesap_no = pn_hesap_no) ;

      if  nvl(pn_faiz_orani,0) <> nvl(ln_faiz_orani,0) then
       return 'E';
      else
        return 'H';
      end if;

     Exception when others then return 'H';
  End;
Function sf_musteri_uygunmu(pn_musteri_no number) return varchar2
is
 Begin
       if pn_musteri_No in (210,217,220,227,292,375,457,103) Then
           return 'H';
       else
             return 'E';
      end if;

     Exception when others then return 'H';
 End;


Function sf_valbakiye_al(pn_hesap_no number ,pd_bakiye_tarih date) return number
is
 ln_bakiye number  :=0 ;
 ln_adet   number  := 0;

 cursor cur_1 is
       select Bakiye
      from   cbs_hesap_bakiye
      where  hesap_no = pn_hesap_no;


 cursor cur_2 is
/*
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no and
                to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY') in(
              select max( to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY'))
                      from   cbs_hesap_gunluk_bakiye
                      where  hesap_no = pn_hesap_no and
                                 to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY') <= TRUNC(pd_bakiye_tarih) ) ;
*/
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no and
                BALANCE_DATE =(
              select /*+ index(a idx_balance_date)*/ max(BALANCE_DATE)
                      from   cbs_hesap_gunluk_bakiye a
                      where  hesap_no = pn_hesap_no and
                                 BALANCE_DATE <= TRUNC(pd_bakiye_tarih) ) ;

  /* cursor cur_3 is
       select Bakiye
      from   cbs_hesap_gunluk_bakiye
      where   hesap_no = pn_hesap_no
                order by yil ,ay,gun     ;
    */
 Begin

   if  pd_bakiye_tarih is null or pd_bakiye_tarih = pkg_muhasebe.banka_tarihi_bul then
     open  cur_1 ;
         fetch cur_1 into ln_bakiye;
   else
     for c_2 in cur_2 loop
       ln_bakiye := c_2.bakiye ;
       ln_adet := ln_adet + 1 ;
     end loop;
     /*if  nvl(ln_adet,0) = 0 then
      open  cur_3 ;
             fetch cur_3 into ln_bakiye;
     end if;
     */
   end if;

    return nvl(ln_bakiye,0);

  exception when others then return 0;

 End;

 Function sf_colletaraltype_al(pn_hesap_no number ) return varchar2
 is
   ls_kisa_kod varchar2(2000);
   ls_str       varchar2(2000) := null;

        cursor cur_hesap is
      select Distinct nvl(b.kisa_kod,b.TEMINAT_TURU) kisa_kod
      from cbs_teminat a,cbs_teminat_kodlari b
      where teminat_hesap_no =pn_hesap_no and
              a.teminat_kodu =b.teminat_kodu;


 Begin
       for c_hesap in cur_hesap loop
          ls_kisa_kod :=  ls_kisa_kod|| ls_str || c_hesap.kisa_kod;
         ls_str :=',';
      end loop;

      return trim(ls_kisa_kod);
 End ;
/* bilesik faiz hesaplamasi icindir */
Function sf_compoundintrate_al(pn_duration number ,pn_faiz_orani number ,ps_urun_sinif varchar2) return number
is
 ln_faiz number := 0;
Begin
     if ps_urun_sinif in( 'ROTATIF-LC','ROTATIF-FC') then
     /* ((1+faiz_orani*90/36000))-1 formuludur.*/
         ln_faiz := 100*( POWER((1+nvl(pn_faiz_orani,0)*90/36000),4) - 1 );
     else
       if nvl(pn_duration,0)  > 365 then
             ln_faiz:= pn_faiz_orani;
         else
         if nvl(pn_duration,0) = 0 then
              ln_faiz := 0;
         else
              ln_faiz := 100*( POWER((1+nvl(pn_faiz_orani,0)*nvl(pn_duration,0)/36000),360/nvl(pn_duration,0)) - 1 );
         end if;
         end if;
     end if;

     return round(nvl(ln_faiz,0),2);

End;
    Function EUR_AL return varchar2
    is
    Begin
      return 'EUR';
    End;

Function sf_birikmisfaiz_al(pn_hesap_no number ,pd_tarih date) return number
is
 ln_bakiye number  :=0 ;

 cursor cur_1 is
       select pkg_kur.yuvarla(doviz_kodu ,nvl(BIRIKMIS_FAIZ_TUTARI,0)  + nvl( GECENYIL_FAIZ_TUTARI,0)) birikmis_faiz
      from   CBS_RPT_KREDI_GUNSONU_FAIZ
      where  hesap_no = pn_hesap_no and
               banka_tarihi = pd_tarih ;
 Begin

   open  cur_1 ;
         fetch cur_1 into ln_bakiye;

    return nvl(ln_bakiye,0);

  exception when others then return 0;

 End;
Function Sf_TeminatUrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2
is
  ls_uygun  varchar2(1) := 'H';
  Begin
        if  ps_urun_tur_kod in ( 'TAHAKKUK')  then
             ls_uygun := 'H';
        else
            ls_uygun := 'E';
        end if;

        return ls_uygun;
    Exception
      When Others Then return 'H';
  End ;

Function sf_teminatgruptoplam (pn_ref_no number,
                                pn_musteri_no number,
                                pn_hesap_no number,
                                pn_teklif_no number,
                                pn_teklif_satir_no number,
                               pn_grup_no number ,
                               pn_teminat_kullanilan_tutar number,
                               pn_teklif_tutar number) return number
 is
 ln_tutar number :=  0;
 Begin
  if nvl(pn_grup_no ,0) <> 0 then
      select sum(decode( nvl(teklif_tutar,0),0,0,nvl(teminat_kullanilan_tutar,0) / nvl(teklif_tutar,0)))
      into ln_tutar
      from CBS_TEMINAT_TEKLIFSATIR_IZLEME
      where musteri_no = pn_musteri_no and
              nvl(teminat_hesap_no,0) = nvl(  pn_hesap_no ,0)and
            teklif_satir_no = pn_teklif_satir_no and
              grup_no = pn_grup_no and
            ref_no = pn_ref_no;
    else
        if  nvl(pn_teklif_tutar,0) = 0 then
            ln_tutar := 0;
        else
            ln_tutar := nvl(pn_teminat_kullanilan_tutar,0) / nvl(pn_teklif_tutar,0);
        end if;
    end if;
    return 100*abs(ln_tutar);

 End;
----------------------------------------------------------------------------------------
PROCEDURE  sp_ins_rpt_nakdi_alco
is
Begin


 delete from cbs_rap_nakdi_kredi_alco
 where banka_tarihi = pkg_muhasebe.banka_tarihi_bul;

 commit;

 insert into cbs_rap_nakdi_kredi_alco (banka_tarihi,
    musteri_no,
    hesap_no,
    customer_name,
    purpose_of_loan,
    modul_tur_kod,
    urun_tur_kod,
    urun_sinif_kod,
    doviz_kodu,
    balance,
    trl_equivalent,
    usd_equivalent,
    interest_rate,
    compound_int_rate,
    value_date,
    maturity_date,
    original_duration,
    remaining_duration,
    colleteral_type,
    groupname,
    sektorname,
    sube_kodu,
    durum_kodu )
 select
    pkg_muhasebe.banka_tarihi_bul,
    musteri_no,
    hesap_no,
    customer_name,
    purpose_of_loan,
    modul_tur_kod,
    urun_tur_kod,
    urun_sinif_kod,
    doviz_kodu,
    balance,
    trl_equivalent,
    usd_equivalent,
    interest_rate,
    compound_int_rate,
    value_date,
    maturity_date,
    original_duration,
    remaining_duration,
    colleteral_type,
    groupname,
    sektorname ,
    sube_kodu,
    durum_kodu
 from cbs_vw_rpt_kredikomite_loansum;

  commit;

End;

----------------------------------------------------------------------------------------
--sevalb 24032011  BLDIF dk ,hesap farklari izleme icin eklendi 

Function toplam_satir_dk_islem_kod (ps_bolum_kodu varchar2 ,ps_dk_no varchar2 ,ps_doviz_kodu varchar2 ,pd_date date default pkg_muhasebe.banka_tarihi_Bul,pn_islem_tanim_kod number DEFAULT NULL ) return number
is
  ln_toplam number ;
  Begin
      select sum (decode (tur, 'A', nvl (dv_tutar, 0), -1* nvl (dv_tutar, 0))) satir_bakiye
      into ln_toplam 
      from cbs_satir b
       where b.hesap_tur_kodu = 'DK'
         and b.hesap_numara =ps_dk_no
         and b.hesap_bolum_kodu = ps_bolum_kodu
         and b.doviz_kod = ps_doviz_kodu
         and b.fis_muhasebelestigi_tarih  <= pd_date
         and b.fis_tur = 'G' and b.fis_no is not null 
         and  b.fis_islem_numara in (select s.numara from cbs_islem s where s.kayit_tarih <= pd_date and  s.islem_kod = nvl(pn_islem_tanim_kod,s.islem_kod)); 

        return ln_toplam;
    Exception
      When Others Then return 0;
  End ;
-------------------------------------------------------------------------------------------------------------------------
-- B-O-M SEVALB 13122011 KRPFI Accrued Loan Interest  izlemede kullanailan fonksiyonlardirPast due principal
-------------------------------------------------------------------------------------------------------------------------
 Function sf_pastdue_principal_total(pn_ana_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
 Begin
     select  sum( pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(hesap_no)))
      into ln_tutar
       from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_ana_kredi_hesap_no and
             pastdue_faiz_anapara_sec = 'ANAPARA' and 
             durum_kodu = 'A' and
             ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
       return  nvl(ln_tutar,0);  -- bakiye negatif olmali
    Exception when others then return 0 ;
 End;
-------------------------------------------------------------------------------------------------------------------------
 Function sf_pastdue_interest_total(pn_ana_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
 Begin
      select  sum(pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(hesap_no)))
      into ln_tutar
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_ana_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'FAIZ' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;
 Function sf_pastdue_tax_total(pn_ana_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
 Begin
      select  sum(pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(hesap_no)))
      into ln_tutar
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_ana_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'TAX' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;
Function sf_pastdue_princip_accrued_int(pn_ana_kredi_hesap_no number) return number
is
   ln_tutar number := 0;
 Begin
     select sum( pkg_kur.yuvarla(doviz_kodu, (ABS (NVL (Birikmis_faiz_tutari, 0)) + ABS (NVL (GECENYIL_FAIZ_TUTARI, 0)) + ABS (NVL (GECMIS_AYLARIN_FAIZI, 0)))) )
      into ln_tutar
       from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_ana_kredi_hesap_no and
             pastdue_faiz_anapara_sec = 'ANAPARA' and 
             durum_kodu = 'A' and
             ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
       return  nvl(ln_tutar,0);  -- bakiye negatif olmali
    Exception when others then return 0 ;
 End;

Function sf_pastdue_int_penalty_days(pn_ana_kredi_hesap_no number,pd_bank_date date default pkg_muhasebe.banka_tarihi_bul) return number
is
   ld_date date ;
    ln_penalty_days number := 0; 
 Begin
      select min(acilis_tarihi)
      into ld_date
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_ana_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'FAIZ' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );

       if ld_date is not null then 
          ln_penalty_days :=  nvl(trunc(pd_bank_date), pkg_muhasebe.banka_tarihi_bul) - trunc(ld_date);
        else
           ln_penalty_days := 0;
        end if; 

       return  ln_penalty_days;
    Exception when others then return 0 ;
 End;
-------------------------------------------------------------------------------------------------------------------------
-- E-O-M SEVALB 13122011 KRPFI Accrued Loan Interest  izlemede kullanailan fonksiyonlardirPast due principal
-------------------------------------------------------------------------------------------------------------------------
--BOM CQ5782 ASKHATS
Function sf_date_of_last_payment(pn_ana_kredi_hesap_no number) return DATE IS
    ld_date date;
    
BEGIN
      SELECT TARIH INTO LD_DATE 
      FROM 
          (SELECT 
            HESAP_NO,
            TARIH,
            VAL_BAKIYE,
            TX_NO, 
            ROW_NUMBER() OVER (PARTITION BY hesap_no ORDER BY TX_No DESC) as rn
          FROM CBS_VW_KREDI_ADAT 
          WHERE 
                tx_no IS NOT NULL 
                AND hesap_no = pn_ana_kredi_hesap_no
                AND durum_kodu = 'A')
     WHERE RN = 1 ;
     RETURN LD_DATE;
     EXCEPTION WHEN OTHERS THEN RETURN NULL;      
END;
Function sf_val_balance_of_last_payment(pn_ana_kredi_hesap_no number) return number IS
    LN_VAL_BAKIYE NUMBER;
BEGIN
    SELECT VAL_BAKIYE INTO LN_VAL_BAKIYE 
    FROM 
        (SELECT 
            HESAP_NO,
            TARIH,
            VAL_BAKIYE,
            TX_NO, 
            ROW_NUMBER() OVER (PARTITION BY hesap_no ORDER BY TX_No DESC) as rn
          FROM CBS_VW_KREDI_ADAT 
          WHERE 
                tx_no IS NOT NULL 
                AND hesap_no = pn_ana_kredi_hesap_no
                AND durum_kodu = 'A')
     WHERE RN = 1 ;
     RETURN LN_VAL_BAKIYE;
     EXCEPTION WHEN OTHERS THEN RETURN 0;
END;
--EOM CQ5782 ASKHATS
-------------------------------------------------------------------------------------------------------------------------
Function sf_llp_amount(pn_kredi_hesap_no number) return number --seval.colak  02082022 loan accrual modifications
is
   ln_tutar number := 0;
 Begin
           
            select  nvl(llp_amount,0) 
            into ln_tutar
            from cbs_vw_llp_report
            where account_no=   pn_kredi_hesap_no;
            
       return  ABS(nvl(ln_tutar,0));
    Exception when others then return 0 ;
 End;
 
END ;
/

