create package body     "PKG_BLACK_LIST" as

/******************************************************************************
   NAME       : FUNCTION  Cor_Str
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    : Prepares a string for analysis
******************************************************************************/
function cor_str(str varchar2) return varchar2 is

v_result varchar2(2048);

begin

    v_result := trim(regexp_replace(str,'[^[[:alpha:][:space:]]]*'));

    return v_result;

end;
/******************************************************************************
   NAME       : FUNCTION  CheckBeforeInsBlackList
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    : Check is it string was inserted earlier
******************************************************************************/
function checkbeforeinsblacklist(customer_name varchar2) return number  is 
cursor c1 is
      select name from cbs_black_list t where t.name = customer_name; -- add condition for optimize  CQ004530 UrmatA 20150304
      
c_name varchar2(1024);
begin
      open c1;
          loop
              fetch c1 into c_name;
              exit when c1%notfound;
              
               if (customer_name = c_name)
                 then  return 1;
               end if;
                      
          end loop;
          
      close c1; 
            
     return 0;
end;
/******************************************************************************
   NAME       : FUNCTION  AddRowToBlackList
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    : Inserts a row into a temporary table
******************************************************************************/
function addrowtoblacklist(ls_buffer varchar2, islem_no number, ps_match varchar2, user_kod varchar2 default null ) return varchar2  is   -- optimized removed excess string convertation  CQ004530 UrmatA 20150304
c_name varchar2(512);
begin
     insert into cbs_black_list_tx
      (name, create_date, tx_no, match, create_user)
     values (ls_buffer, sysdate, islem_no, ps_match, user_kod);
     
     return 'ok';
end;

/******************************************************************************
   NAME       : FUNCTION  CheckCustomerInBlackList_No
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    : Verifies customer data on the blacklist by customer id
******************************************************************************/
function checkcustomerinblacklist_no(customer_no number) return varchar2  is 
cursor c1 is
      select trim(name) from cbs_black_list;
      
m_soyadi            varchar2(128);
m_isim              varchar2(128);
m_ikinci_isim       varchar2(128);
m_soyadi_eng        varchar2(128);
m_isim_eng          varchar2(128);
m_ikinci_isim_eng   varchar2(128);
m_uyruk_kod         varchar2(128);
m_arama_isim        varchar2(256);
m_lokal_unvan       varchar2(256);

sp_p number;
c_word varchar2(128);
c_name varchar2(512);
c_bl_name varchar2(32000):='';
c_temp_str varchar2(1024);

c_count number :=0;
p_coinc number;

v_name_arama varchar2(1024):='';
v_name_local varchar2(1024):='';
v_check boolean := false;

begin

  pkg_parametre.deger('BLACKLIST_IS_CHECK_CUST_NO', v_check);
  if v_check = true then
     pkg_parametre.deger('BLACKLIST_COINC_TRAN', p_coinc);
     select soyadi,isim,ikinci_isim,soyadi_eng,isim_eng,ikinci_isim_eng, uyruk_kod, arama_isim, lokal_unvan
     into m_soyadi, m_isim, m_ikinci_isim, m_soyadi_eng, m_isim_eng, m_ikinci_isim_eng, m_uyruk_kod, m_arama_isim, m_lokal_unvan
      from cbs_musteri
      where musteri_no = customer_no
      and durum_kodu = 'A';

     open c1;
          loop
              fetch c1 into c_name;
              exit when c1%notfound;
              c_temp_str := c_name;
              c_name := upper(c_name);
              v_name_arama := replace(trim(c_name),' ','');
              v_name_local := c_name;
              
              
                  loop
                    sp_p   := instr(trim(c_name),' ');
                    
                     if sp_p = 0  then 
                            c_word := substr(trim(c_name), 1);
                     else
                            c_word := substr(trim(c_name), 1, sp_p-1);    
                     end if;
                    
                     if (c_word = m_soyadi             or
                          c_word = m_isim               or
                          c_word = m_ikinci_isim        or
                          c_word = m_soyadi_eng         or
                          c_word = m_isim_eng           or
                          c_word = m_ikinci_isim_eng    or
                          instr(m_arama_isim, v_name_arama) !=0 or
                          instr(m_lokal_unvan, v_name_local) !=0)
                      then  c_count:=c_count+1;
                     elsif c_temp_str = m_uyruk_kod
                        then  return '2';
                     end if;
                    c_name := substr(trim(c_name), sp_p+1);
                    
                    exit when sp_p = 0;
                  end loop; 
              if p_coinc <= c_count then
                c_bl_name := c_bl_name||chr(10)||c_temp_str;
                c_count:=0;
              end if;
              c_count:=0;
          end loop;
          
      close c1;  
       if length(c_bl_name) > 0 then
         return c_bl_name;
       else 
         return '0';
       end if;
  else
    return '0';
  end if;
exception
    when no_data_found then 
            return 0;
end;
/******************************************************************************
   NAME       : FUNCTION  CheckCustomerInBlackList_Str
   Created By : Urmat Aymambetov & Nurmila Zhetimishova
   Date       : 01.12.14 & 24.07.21
   Purpose    : Verifies customer data on the blacklist by string
******************************************************************************/
function checkcustomerinblacklist_str(ps_customer_name varchar2) return varchar2  is 
    ls_query clob;
    ln_percent_c varchar2(5); 
    ln_percent number;
    ln_cnt number := 0;

    ln_len number;
    ls_name varchar2(200);
    ls_customer_name varchar2(200);
    ln_count number;

    l_words apex_application_global.vc_arr2;
    
begin
    log_at('blackListTilek','ps_customer_name',ps_customer_name);
  if trim(ps_customer_name) is not null then   
    ls_customer_name := upper(trim(chek_companies(ps_customer_name)));
    
    l_words := apex_util.string_to_table(ls_customer_name, ' ');
    
    pkg_parametre.deger('BLACKLIST_PERCENT_PARAMETRE',ln_percent_c);
    ln_percent := to_number(ln_percent_c, '9.99');

    ls_query := 'select count(*) from cbs.cbs_black_list where';

    for i in 1 .. l_words.count
    loop
        ls_name := sf_cleaning_name(l_words(i));
        if ls_name is not null then 
             ln_len := length(ls_name);
             ln_count := round(ln_len*ln_percent);
             ls_query := ls_query || ' (';

             for j in 1 .. ln_len - ln_count + 1
             loop
                  ls_query := ls_query || ' search_name like ''%' || substr(ls_name, j, ln_count) || '%'' or';
             end loop;

             ls_query := rtrim(ls_query, 'or') || ') and';
        end if;
    end loop;   
  end if;
  
  if ls_query is null then 
      return 0;
  else 
      ls_query := rtrim(ls_query, 'and');
  end if;
    
  execute immediate ls_query into ln_cnt;
    
  if ln_cnt = 0 then 
  log_at('blackListTilek','ln_cnt 0',ln_cnt);
      return 0;
  else 
  log_at('blackListTilek','ln_cnt 1',ln_cnt);
      return 1;
  end if;
exception when others then
      log_at('checkcustomerinblacklist_str', ln_cnt, sqlerrm, dbms_utility.format_error_backtrace);
      return 0;
end;
/******************************************************************************
   NAME       : FUNCTION  CheckCustomerInWhiteList_Str
   Created By : Nurmila Zhetimishova
   Date       : 24072021
   Purpose    : Verifies customer data on the whitelist by string
******************************************************************************/
function checkcustomerinwhitelist_str(ps_customer_name varchar2) return varchar2  is 
    ls_query clob;
    ln_cnt number := 0;

    ln_len number;
    ls_name varchar2(200);
    ls_customer_name varchar2(200);
    ln_count number;

    l_words apex_application_global.vc_arr2;
begin
  if trim(ps_customer_name) is not null then   
    ls_customer_name := upper(trim(ps_customer_name));

    l_words := apex_util.string_to_table(ls_customer_name, ' ');

    ls_query := 'select count(*) from cbs_white_list where';

    for i in 1 .. l_words.count
    loop
        ls_name := sf_cleaning_name(l_words(i));
        if ls_name is not null then 
            ls_query := ls_query || ' search_name like ''%' || ls_name || '%''  and';
        end if;
    end loop;
    
  end if;
  
  if ls_query is null then 
        return 0;
   else 
        ls_query := rtrim(ls_query, 'and');
  end if;
    
  execute immediate ls_query into ln_cnt;

  if ln_cnt = 0 then 
      return 0;
  else 
      return 1;
  end if;
exception when others then
      log_at('checkcustomerinwhitelist_str', ln_cnt, sqlerrm, dbms_utility.format_error_backtrace);
      return 0;    
end;

/******************************************************************************
   NAME       : FUNCTION  BLACK_LIST_REPORT
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    : Sends an email to the compliance department
******************************************************************************/
procedure black_list_report(customer_no number default null, 
                               islem_kod number default null, 
                               hesap_no number default null,
                               amount number default null, 
                               tran_kod number default null,
                               email_subject varchar2 default null) --chyngyzo CQ509 10/07/2015 custom email_subject was added
is
     v_recipient varchar2(240);
     v_copy      varchar2(240);
     v_bcopy    varchar2(240);
     v_from     varchar2(240);
    
    text   clob;
begin
   
     text:= 'customer_no:'||chr(9)||customer_no||chr(13)||chr(10)||
            'screen_kod:'||chr(9)||islem_kod||chr(13)||chr(10)||
            'transaction_kod:'||chr(9)||tran_kod||chr(13)||chr(10)||
            'account_no:'||chr(9)||hesap_no||chr(13)||chr(10)||
            'amount:'||chr(9)||amount||chr(13)||chr(10)||
            'user: '||chr(9)||user||chr(13)||chr(10);
                            
            pkg_parametre.deger('REPORT_BLACK_LIST_EMAIL', v_recipient);
            pkg_parametre.deger('REPORT_BLACK_LIST_ALERT_FROM', v_from);
                      
    pkg_email.addtoemailqueue('SUBSCRIPTION',
                                   50,
                                   v_from,
                                   v_recipient ,
                                   nvl(substr(email_subject, 1, 500), 'Black list alert '||to_char(sysdate, 'dd/mm/yyyy')), --chyngyzo CQ509 10/07/2015 custom email_subject was added
                                   text
                                   );

exception
    when others then
          log_at('PKG_BLACK_LIST.BLACK_LIST_REPORT',sqlerrm);   -- added handle of exception  CQ004530 UrmatA 20150304
end;


/******************************************************************************
   NAME       : FUNCTION  CheckCompanyName
   Created By : Urmat Aymambetov
   Date       : 01.12.14
   Purpose    :Verifies customer data on the blacklist by company name
******************************************************************************/
function checkcompanyname(customer_name varchar2) return number  is 

v_count number;
begin
      select count(*) into v_count from cbs_black_list t  where upper(trim(t.name)) = upper(trim(customer_name));     
      
      if v_count > 0
         then  return 1;
      end if;
              
     return 0;
end;

function fiomusteri(p_musteri_no number) return varchar2  is 
    
    v_result varchar2(1024);

begin 
     select t.isim||' '||t.ikinci_isim||' '||t.soyadi||' '||t.isim_eng||' '||t.ikinci_isim_eng||' '||t.soyadi_eng
        into v_result
     from cbs_musteri t where t.musteri_no = p_musteri_no;
    
    return v_result;
    
exception when no_data_found then
    log_at('PKG_BLACK_LIST.FioMusteri',sqlerrm);
end;

/******************************************************************************
   NAME       : PROCEDURE  CheckForImport
   Created By : Urmat Aymambetov
   Date       : 17.04.15
   Purpose    :Check blacklist coincidence with customers data (optimized CQ004642)
******************************************************************************/
procedure checkforimport(bl_name varchar2, v_result out varchar2, v_result_m out varchar2) is 

v_name varchar2(1024):= replace(trim(bl_name),' ','');
p_coinc number;
c_count number := 0;
 
cursor s1 is
            select t.musteri_no  from cbs_musteri t 
                        where  1=1
                        and
                         (
                         instr(bl_name, trim(t.isim)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.soyadi)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.ikinci_isim)) !=0
                         ) or
                         (
                          instr(bl_name, trim(t.soyadi_eng)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.ikinci_isim_eng)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.isim_eng)) !=0
                         ) or
                         (
                         instr(t.arama_isim, v_name) !=0
                         ) or
                         (
                         instr(t.lokal_unvan, bl_name) !=0
                         );   

cursor s2 is
            select t.musteri_no  from cbs_musteri t 
                        where  1=1
                        and
                        (
                         instr(bl_name, trim(t.soyadi)) !=0
                         and instr(bl_name, trim(t.isim)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.soyadi)) !=0
                         and instr(bl_name, trim(t.ikinci_isim)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.isim)) !=0
                         and instr(bl_name, trim(t.ikinci_isim)) !=0
                         ) or
                         (
                          instr(bl_name, trim(t.soyadi_eng)) !=0
                         and instr(bl_name, trim(t.isim_eng)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.soyadi_eng)) !=0
                         and instr(bl_name, trim(t.ikinci_isim_eng)) !=0
                         ) or
                         (
                         instr(bl_name, trim(t.isim_eng)) !=0
                         and instr(bl_name, trim(t.ikinci_isim_eng)) !=0
                         )or
                         (
                         instr(t.arama_isim, v_name) !=0
                         ) or
                         (
                         instr(t.lokal_unvan, bl_name) !=0
                         );  

cursor s3 is
            select t.musteri_no  from cbs_musteri t 
                        where  1=1
                        and
                         (
                         instr(bl_name, trim(t.soyadi)) !=0
                         and instr(bl_name, trim(t.isim)) !=0
                         and instr(bl_name, trim(t.ikinci_isim)) !=0
                         ) or
                         (
                          instr(bl_name, trim(t.soyadi_eng)) !=0
                         and instr(bl_name, trim(t.isim_eng)) !=0
                         and instr(bl_name, trim(t.ikinci_isim)) !=0
                         ) or
                         (
                         instr(t.arama_isim, v_name) !=0
                         ) or
                         (
                         instr(t.lokal_unvan, bl_name) !=0
                         );           
                 
m_musteri_no        number;

begin
        
    pkg_parametre.deger('BLACKLIST_COINC_IMP', p_coinc);
    if p_coinc = 1 then  
     open s1;
        loop
            fetch s1 into m_musteri_no;
            exit when s1%notfound;
            c_count:=c_count+1;
            --BOM BlackList CQ5622 MederT 22092016
            if nvl(length(v_result), 0) < 32600 then
                v_result:= substr(substr(v_result,1,32400)||bl_name||';'||fiomusteri(m_musteri_no)||';'||m_musteri_no, 1, 32400)||chr(10);  
            end if;
            if nvl(length(v_result_m), 0) < 32600 then
                v_result_m := v_result_m||' '||m_musteri_no;
            end if;
            --EOM BlackList CQ5622 MederT 22092016        
        end loop; 
        close s1;
         
    elsif p_coinc = 2 then
     open s2;
        loop
            fetch s2 into m_musteri_no;
            exit when s2%notfound;
            c_count:=c_count+1;
            --BOM BlackList CQ5622 MederT 22092016
            if nvl(length(v_result), 0) < 32600 then
                v_result:= substr(substr(v_result,1,32400)||bl_name||';'||fiomusteri(m_musteri_no)||';'||m_musteri_no, 1, 32400)||chr(10);  
            end if;
            if nvl(length(v_result_m), 0) < 32600 then
                v_result_m := v_result_m||' '||m_musteri_no;
            end if;
            --EOM BlackList CQ5622 MederT 22092016        
                    
        end loop; 
        
        close s2;
    
    elsif p_coinc = 3 then
     open s3;
        loop
            fetch s3 into m_musteri_no;
            exit when s3%notfound;
            c_count:=c_count+1;
            --BOM BlackList CQ5622 MederT 22092016
            if nvl(length(v_result), 0) < 32600 then
                v_result:= substr(substr(v_result,1,32400)||bl_name||';'||fiomusteri(m_musteri_no)||';'||m_musteri_no, 1, 32400)||chr(10);  
            end if;
            if nvl(length(v_result_m), 0) < 32600 then
                v_result_m := v_result_m||' '||m_musteri_no;
            end if;
            --EOM BlackList CQ5622 MederT 22092016        
        end loop; 
        close s3;    
    end if;

    log_at('Black_Nurmila', bl_name, v_result, v_result_m);
               
end;
procedure chek_in_black(pn_islem_no number, pn_cust_name varchar2 default 'No Name') is 
    
    ln_count number;
    ln_main_p number;
    ln_islem_no number;
    ln_white_contr number; 
    lv_user varchar2(200);
    ln_islem_kod number;
    ln_blacklist_name varchar2(4000 byte);
    begin 
        
      select count(*) into ln_count from cbs_approval where islem_numara=pn_islem_no 
                                                                and replace(black_name, ' ', '')=replace(pn_cust_name,  ' ', '');
      
      pkg_parametre.deger('BLACKLIST_MAIN_PARAMETRE',ln_main_p);
      
      ln_white_contr := checkcustomerinwhitelist_str(pn_cust_name);
      --Adilk begin block cbs-801
      begin
      select user into lv_user from dual;
      select nvl(islem_kod,0) into ln_islem_kod from CBS.CBS_ISLEM where NUMARA=pn_islem_no;
      end;
      log_at('cbs-801',lv_user,ln_islem_kod,pn_islem_no);
      if lv_user='CAMPUS_CALLER' and ln_islem_kod=1000 then
            ln_blacklist_name := get_blacklist_str(pn_cust_name);
            insert into cbs.CBS_CAMPUS_APPROVAL
                (islem_numara, black_name, black_list_name)
            values
                (pn_islem_no, pn_cust_name, ln_blacklist_name);
                
                update cbs_approval 
        set (islem_kod, kayit_tarih, musteri_numara, hesap_numara, 
                    tutar, doviz_kod, fis_numara, modul_tur_kod, urun_tur_kod, 
                    urun_sinif_kod, kayit_kullanici_kodu, kayit_sistem_tarihi, dogru_kullanici_kodu, dogrulama_sistem_tarihi, 
                    dogrula_aciklama, onay_kullanici_kodu, onay_sistem_tarihi, onay_aciklama, iptal_kullanici_kodu, 
                    iptal_sistem_tarihi, iptal_onay_kullanici_kodu, iptal_onay_sistem_tarihi, iptal_onay_aciklama, amir_bolum_kodu) 
                    = (select islem_kod, kayit_tarih, musteri_numara, hesap_numara, 
                    tutar, doviz_kod, fis_numara, modul_tur_kod, urun_tur_kod, 
                    urun_sinif_kod, kayit_kullanici_kodu, kayit_sistem_tarihi, dogru_kullanici_kodu, dogrulama_sistem_tarihi, 
                    dogrula_aciklama, onay_kullanici_kodu, onay_sistem_tarihi, onay_aciklama, iptal_kullanici_kodu, 
                    iptal_sistem_tarihi, iptal_onay_kullanici_kodu, iptal_onay_sistem_tarihi, iptal_onay_aciklama, amir_bolum_kodu
                    from cbs_islem where numara = pn_islem_no)
        where islem_numara = pn_islem_no;
          
               /* update cbs_approval 
        set (CUSTOMER_NAME , CUSTOMER_BIRTH_DATE) = (select DOGUM_YERI,LOKAL_UNVAN from CBS.CBS_MUSTERI where MUSTERI_NO=) where islem_numara = pn_islem_no;*/
 
      --end of cbs-801 block         
      elsif ln_white_contr<>0 and ln_count=0 and ln_main_p=1 then
            ln_islem_no := pkg_tx.islem_no_al; 
            insert into cbs.cbs_approval
                (numara, islem_numara, status, black_name)
            values
                (ln_islem_no, pn_islem_no, 'WHITE', pn_cust_name);
      elsif ln_count=0 and ln_main_p=1 then 
            ln_blacklist_name := get_blacklist_str(pn_cust_name);
            insert into cbs.cbs_approval
                (islem_numara, black_name, black_list_name)
            values
                (pn_islem_no, pn_cust_name, ln_blacklist_name);
      elsif ln_count=0 and ln_main_p=0 then
            ln_islem_no := pkg_tx.islem_no_al; 
            insert into cbs.cbs_approval
                (numara, islem_numara, status, black_name)
            values
                (ln_islem_no, pn_islem_no, 'NONE', pn_cust_name);
      end if;
    exception when others then
        log_at('PKG_BLACK_LIST.Check_in',sqlerrm,DBMS_UTILITY.format_error_stack);
        RAISE_APPLICATION_ERROR(-20100, CBS.Pkg_Hata.getUCPOINTER || '???' || CBS.Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' || SQLERRM || CBS.Pkg_Hata.getdelimiter || CBS.Pkg_Hata.getUCPOINTER);       
    end;
function chek_companies(llc_name varchar2)return varchar2  is
    cursor llc_word
    is 
    select * from companies;
    
    company varchar2(500);
    llc_name_out varchar2(500);
      
begin
    llc_name_out := llc_name;
        open llc_word;
        loop
            fetch llc_word into company;
            exit when llc_word%notfound;
            
            company:= trim(company)||' ';
            llc_name_out:= replace(upper(llc_name_out),upper(company));
            
            company:= ' '||trim(company)||' ';
            llc_name_out:= replace(upper(llc_name_out),upper(company));
            
            company:= ' '||trim(company);
            llc_name_out:= replace(upper(llc_name_out),upper(company));
                 
            
        end loop;
         return (llc_name_out);
        close llc_word;
       
end;
procedure chek_update(pn_islem_no number) is 
    ls_count number;
begin
    select count(*) into ls_count from cbs_approval where islem_numara = pn_islem_no;
   
    if ls_count <> 0 then
        update cbs_approval 
        set (islem_kod, kayit_tarih, musteri_numara, hesap_numara, 
                    tutar, doviz_kod, fis_numara, modul_tur_kod, urun_tur_kod, 
                    urun_sinif_kod, kayit_kullanici_kodu, kayit_sistem_tarihi, dogru_kullanici_kodu, dogrulama_sistem_tarihi, 
                    dogrula_aciklama, onay_kullanici_kodu, onay_sistem_tarihi, onay_aciklama, iptal_kullanici_kodu, 
                    iptal_sistem_tarihi, iptal_onay_kullanici_kodu, iptal_onay_sistem_tarihi, iptal_onay_aciklama, amir_bolum_kodu) 
                    = (select islem_kod, kayit_tarih, musteri_numara, hesap_numara, 
                    tutar, doviz_kod, fis_numara, modul_tur_kod, urun_tur_kod, 
                    urun_sinif_kod, kayit_kullanici_kodu, kayit_sistem_tarihi, dogru_kullanici_kodu, dogrulama_sistem_tarihi, 
                    dogrula_aciklama, onay_kullanici_kodu, onay_sistem_tarihi, onay_aciklama, iptal_kullanici_kodu, 
                    iptal_sistem_tarihi, iptal_onay_kullanici_kodu, iptal_onay_sistem_tarihi, iptal_onay_aciklama, amir_bolum_kodu
                    from cbs_islem where numara = pn_islem_no)
        where islem_numara = pn_islem_no;
        
             if pkg_tx.black_list(pn_islem_no) then  
                 update_islem(pn_islem_no);
                 send_email(pn_islem_no);
             end if;
     
    end if;
    
end;                
procedure update_islem(pn_islem_no number) is 
begin
          update cbs_islem
             set onaylanmali_mi  = 'E',
                iptal_onaylanmali_mi = 'E'
          where numara=pn_islem_no and islem_kod in (6200, 6201, 6202, 6203, 4300);
end; 
procedure blacklist_fmb_logic(pn_tx_no number, pn_customer_no number, pn_customer_name varchar2, pn_company_name varchar2) is
 v_parametre number;
 check_result number;
 v_check_result varchar2(32000);
 ln_pn_customer_name varchar2(32000);
begin
   pkg_parametre.deger('BLACKLIST_ALERT', v_parametre);
   if v_parametre <> '0' then
   
        if pn_customer_no is not null then
            v_check_result := cbs.pkg_black_list.checkbeforeinsblacklist(pn_customer_no); 
            if check_result <> 0 then 
                pkg_black_list.chek_in_black(pn_tx_no, pn_customer_no);
            end if;
        end if;
        
        if pn_customer_name is not null then
            v_check_result := cbs.pkg_black_list.checkcustomerinblacklist_str(pn_customer_name); 
            if v_check_result not in ('0') then 
                pkg_black_list.chek_in_black(pn_tx_no, pn_customer_name);
            end if;
        end if;
        
        if pn_company_name is not null then
            v_check_result := cbs.pkg_black_list.checkcustomerinblacklist_str(pn_company_name); 
            if v_check_result not in ('0') then 
                pkg_black_list.chek_in_black(pn_tx_no, pn_company_name);
            end if;
        end if;
        
   end if;
end; 
procedure send_email(pn_islem_no number) is

    cursor cur_email is
         select islem_kod, 
                amir_bolum_kodu,
                musteri_numara, 
                tutar, 
                doviz_kod, 
                black_name,
                black_list_name,
                kayit_kullanici_kodu from cbs_approval
          where islem_numara = pn_islem_no and status='Suspended';

    r_email    cur_email%rowtype;
      
    v_to      varchar2(51 byte);
    l_recipients corpint2.pkg_notification.recipientlist;
    ls_content varchar2 (32767);
    ls_json clob; 
    ls_ret varchar2(3); 
    
begin  
       l_recipients := corpint2.pkg_notification.recipientlist(1);
        pkg_parametre.deger('REPORT_BLACK_LIST_EMAIL', v_to);
        
        l_recipients(1) := v_to;
        
         open cur_email;
          loop
             fetch cur_email into r_email;
             exit when cur_email%notfound;
             if r_email.black_name is not null
             then
                ls_content:='<tr><td class=\"black\">Transaction: </td><td>' || pn_islem_no 
                || '</td></tr><tr><td class=\"black\">Brach: </td><td>' || r_email.amir_bolum_kodu 
                || '</td></tr><tr><td class=\"black\">Screen: </td><td>' || r_email.islem_kod 
                || '</td></tr><tr><td class=\"black\">Customer: </td><td>' || r_email.musteri_numara 
                || '</td></tr><tr><td class=\"black\">Amount: </td><td>' || r_email.tutar || ' ' || r_email.doviz_kod 
                || '</td></tr><tr><td class=\"black\">Black Name: </td><td>' || r_email.black_name 
                || '</td></tr><tr><td class=\"black\">Black List Name: </td><td>' || r_email.black_list_name 
                || '</td></tr><tr><td class=\"black\">Maker: </td><td>' || r_email.kayit_kullanici_kodu 
                || '</td></tr>';
                
                ls_json := '{';
                ls_json := ls_json || '"##BLACK##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := corpint2.pkg_notification.addemailtoqueuenew(to_char(ls_json), 'Black List', 'info@demirbank.kg',l_recipients, 'HTML', 'black_list', null, null);
                      
             end if;
          end loop;
          close cur_email;            
exception
    when others then
          log_at('SEND_EMAIL_BLACK_LIST',sqlerrm, dbms_utility.format_error_backtrace);
end;
function get_blacklist_str(ps_customer_name varchar2) return varchar2  is 
    ls_query clob;
    ln_percent_c varchar2(5); 
    ln_percent number;
    ln_cnt number := 0;

    ln_len number;
    ls_name varchar2(200);
    ls_customer_name varchar2(200);
    ln_count number;

    l_words apex_application_global.vc_arr2;
    type namelist is table of varchar2(200 byte);
    ln_name   namelist;
    get_name  varchar2(4000 byte);
begin

  if trim(ps_customer_name) is not null then   
    
    ls_customer_name := upper(trim(chek_companies(ps_customer_name)));
    l_words := apex_util.string_to_table(ls_customer_name, ' ');
    pkg_parametre.deger('BLACKLIST_PERCENT_PARAMETRE',ln_percent_c);
    ln_percent := to_number(ln_percent_c, '9.99');

    ls_query := 'select name from cbs.cbs_black_list where';

    for i in 1 .. l_words.count
    loop
        ls_name := sf_cleaning_name(l_words(i));
        if ls_name is not null then 

            ln_len := length(ls_name);
            ln_count := round(ln_len*ln_percent);
            ls_query := ls_query || ' (';

            for j in 1 .. ln_len - ln_count + 1
            loop
                ls_query := ls_query || ' search_name like ''%' || substr(ls_name, j, ln_count) || '%'' or';
            end loop;

            ls_query := rtrim(ls_query, 'or') || ') and';
        end if;
    end loop;   
  end if;
  
  if ls_query is null then 
      return 0;
  else 
      ls_query := ls_query || ' rownum<=5';
  end if;
    
  execute immediate ls_query bulk collect into ln_name;
    
  for i in reverse 1..ln_name.count
  loop
      get_name := get_name || ln_name(i) || ', ';
  end loop;
    
  return get_name;
  
exception when others then
      log_at('get_blacklist_str', get_name, sqlerrm, dbms_utility.format_error_backtrace);
      return get_name;
end;
function fast_payment_update(pn_islem_no number, ps_customer_name varchar2) return boolean
is 
    ls_count number;
    pragma autonomous_transaction;
begin

    chek_in_black(pn_islem_no, ps_customer_name);
    
    select count(*) into ls_count from cbs_approval where islem_numara = pn_islem_no and status='Suspended';
    
    if ls_count <> 0 then 
          update cbs_approval 
             set islem_kod= '3130',
                kayit_kullanici_kodu = user,
                kayit_sistem_tarihi = sysdate,
                amir_bolum_kodu = pkg_baglam.bolum_kodu
          where islem_numara = pn_islem_no;
          
          send_email(pn_islem_no); 
           
          commit; 
          
        return true;
    else 
        return false;
    end if; 
exception
    when others then
          return false;   
end; 
function  sf_cleaning_name(ps_string varchar2) return  varchar2
  is
    ls_string varchar2(2048 byte) := ps_string;
  begin
       if ls_string  is not null then
          ls_string := regexp_replace(upper(trim(ls_string)), '[^[:alpha:]]');
       end if;
     return ls_string;
   end;
end pkg_black_list;
/

