create PACKAGE     "PKG_LLP" 
--Yerzhan Tanatov
is
  procedure createLLPforAccount(p_account_no number,p_gl_code varchar2,p_bakiye number default 0);
  procedure createLLP(n_account number,n_llp_rate number, n_llp_amount number default null,n_mod_user varchar2 default null,n_mod_date date default null); --BahianaB CBS-735 10102022 llp_amount added
  function getTypeOfCollateral(n_hesap_no number,n_musteri_no number,p_bakiye number default 0) return varchar2;
  function getCreditCardGroupNumber(m_musteri_no number,n_teklif_no number,per_sicil_no number) return int;
  function getTypeOfOverdraft(n_hesap_no number,n_musteri_no number,p_bakiye number default 0) return int;
  function getRelatedLoans(p_account number) return number;
  function getInstallmentAndTaxForLoans(p_account number, p_principal number,p_installment_amount number, p_interest number,p_sira_no number)
  return number;
/******************************************************************************
   NAME       : PROCEDURE setPDcardRatesStr
   Created By : Urmat Aymambetov
   Date       : 13.04.2016
   Purpose    : CQ5257 urmata 13042016 New procedure for set rates to PD cards
******************************************************************************/
  procedure setPDcardRatesStr(p_str IN varchar);  
end;
/

