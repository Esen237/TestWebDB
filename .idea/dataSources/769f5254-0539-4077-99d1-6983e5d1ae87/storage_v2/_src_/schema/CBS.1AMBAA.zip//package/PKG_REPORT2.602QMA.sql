create package PKG_REPORT2 is

  -- Author  : MAXIMP
  -- Created : 10.04.2005 11:10:07
  -- Purpose :

  function GET_REZ_DATE_STRING(RPT_DATE DATE) return VARCHAR2;
  function GET_REZ_GROWING(DATE_BEGIN DATE, DATE_END DATE,  DATE_CUR DATE) return NUMBER;

  function GET_WORD_DATE_BY_NUM(DATE_BEGIN DATE, DATE_END DATE, ID NUMBER) return DATE;
  function GET_NUM_DATE_BY_DATE(DATE_NO_ DATE) return NUMBER;
  function FIRST_DAY(DATE_ DATE) return DATE;
  function GET_DAY_WORK_COUNT(RPT_DATE DATE) return NUMBER;

  function GET_GL_ACIKLAMA(DK_KODU_ CBS_DKHESAP.DK_KOD%TYPE, LANG_KODU_ CBS_DKHESAP_DEFINITION.LANG_KODU%TYPE) return VARCHAR2;

  function GET_AVERAGE_BAKIYE(DATE_ DATE, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER;
  function GET_BAKIYE(DATE_ DATE, BOLUM_KOD_ VARCHAR2, TUR_ VARCHAR2, NUMARA_ VARCHAR2, DOVIZ_KOD_ VARCHAR2, TYPE_ VARCHAR2/*FC, LC*/) RETURN NUMBER;

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ DATE) return number;
  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ DATE, bolum_kodu_ varchar2) return number;

  function val_pos(gl_ varchar2, date_ DATE) return number;

  function CBS_SN_BALANCE(DATE_ in DATE, BOLUM_ in varchar2) return SN_BALANCE_TABLE pipelined;
end PKG_REPORT2;

/

