create PACKAGE PKG_TX4101 IS

  /******************************************************************************
   Name       : PKG_TX4061
   Created By : Bilal GUL
   Date	   	  : 15/12/2003
   Purpose	  : TEMINAT MEKTUBU / HARICI GARANTI GUNCELLEME
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Procedure TM_HG_BilgiAktar(pn_txno number,ps_refno varchar2);
  Procedure Guncelleme_Kontrolu(pn_islem_no NUMBER,
  								ps_block	VARCHAR2,
								ps_rowid   VARCHAR2,
		  				   		ps_column  	VARCHAR2,
  		   				   		pd_column   VARCHAR2,
								ps_oldvalue IN OUT VARCHAR2); --G?ncellenen alanlar? bulmak i?in

  procedure geri_kopyala(pn_islem_no number, ps_ref varchar2);

  Function masraf_kontrol_yap(ps_odeyecek varchar2) return varchar2;

  Function enkucuk_kg_vade_bul(ps_ref varchar2) return date;

  procedure kullanilan_kg_aktar(pn_islem_no number, ps_ref varchar2);

  procedure kullanilan_kg_geri_kopyala(pn_islem_no number);

  PROCEDURE SP_KG_HESAP_VADE_GUNCELLE(PS_REFERANS VARCHAR2,PD_VADE_TARIHI DATE);

END;


/

