create PACKAGE BODY     PKG_INT_PAYMENT_INQUIRY
IS
    FUNCTION GetIntalLlc (ps_row_number         IN     VARCHAR2,
                          ps_container_number   IN     VARCHAR2,
                          pc_ref                   OUT CursorReferenceType)
        RETURN VARCHAR2
    IS
        ln_name_count   NUMBER;
        notFoundName    EXCEPTION;
    BEGIN
        SELECT COUNT (*)
          INTO ln_name_count
          FROM CBS.CBS_INTAL_LLC
         WHERE     ROWNUMBER = ps_row_number
               AND CONTAINERNUMBER = ps_container_number;

        IF ln_name_count != 1
        THEN
            RAISE notFoundName;
        END IF;

        OPEN pc_ref FOR
            SELECT NAME
              FROM CBS_INTAL_LLC
             WHERE     ROWNUMBER = ps_row_number
                   AND CONTAINERNUMBER = ps_container_number;

        RETURN '000';
    EXCEPTION
        WHEN notFoundName
        THEN
            log_at ('GetIntalLlc',
                    'notFoundName',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN '505';
        WHEN OTHERS
        THEN
            log_at ('GetIntalLlc',
                    'OTHERS',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RAISE;
    END;

    FUNCTION GetIntalLlcAccount (ps_name   IN     VARCHAR2,
                                 pc_ref       OUT CursorReferenceType)
        RETURN VARCHAR2
    IS
        ln_account                NUMBER;
        ln_account_count          NUMBER;
        ln_external_count         NUMBER;
        notFoundAccount           EXCEPTION;
        notFoundExternalAccount   EXCEPTION;
    BEGIN
        SELECT COUNT (*)
          INTO ln_account_count
          FROM CBS.CBS_TAHSILAT_KURUM_TANIM
         WHERE KURUM_KODU = ps_name;

        IF ln_account_count != 1
        THEN
            RAISE notFoundAccount;
        END IF;

        SELECT KURUM_HESAP_NO
          INTO ln_account
          FROM CBS.CBS_TAHSILAT_KURUM_TANIM
         WHERE KURUM_KODU = ps_name;

        SELECT COUNT (*)
          INTO ln_external_count
          FROM CBS.CBS_HESAP
         WHERE HESAP_NO = ln_account;

        IF ln_external_count != 1
        THEN
            RAISE notFoundExternalAccount;
        END IF;

        OPEN pc_ref FOR SELECT EXTERNAL_HESAP_NO
                          FROM CBS.CBS_HESAP
                         WHERE HESAP_NO = ln_account;

        RETURN '000';
    EXCEPTION
        WHEN notFoundAccount
        THEN
            log_at ('GetIntalLlcAccount',
                    'notFoundAccount',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN '505';
        WHEN notFoundExternalAccount
        THEN
            log_at ('GetIntalLlcAccount',
                    'notFoundExternalAccount',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN '506';
        WHEN OTHERS
        THEN
            log_at ('GetIntalLlcAccount',
                    'OTHERS',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RAISE;
    END;

    FUNCTION GetLoanDebt (ps_account_no   IN     VARCHAR2,
                          ps_cust_no      IN     VARCHAR2,
                          pc_ref             OUT CursorReferenceType)
        RETURN VARCHAR2
    IS
        ln_account_count   NUMBER;
        notFoundAccount    EXCEPTION;
    BEGIN
        SELECT COUNT (*)
          INTO ln_account_count
          FROM CBS.CBS_VW_KREDI_HESAP_IZLEME
         WHERE     MUSTERI_NO = ps_cust_no
               AND ANA_KREDI_HESAP_NO = ps_account_no
               AND URUN_SINIF_KOD NOT IN ('CREDIT CARD-LC', 'OVERLIMIT-LC')
               AND DURUM_KODU NOT IN 'K';

        IF ln_account_count = 0
        THEN
            RAISE notFoundAccount;
        END IF;

        OPEN pc_ref FOR
            SELECT URUN_TUR_KOD,
                   BAKIYE,
                   BIRIKMIS_FAIZ_TUTARI,
                   TO_CHAR (ACILIS_KREDI_VADE, 'YYYYMMDD')
                       ACILIS_KREDI_VADE,
                   FAIZ_ORANI
              FROM CBS.CBS_VW_KREDI_HESAP_IZLEME
             WHERE     MUSTERI_NO = ps_cust_no
                   AND ANA_KREDI_HESAP_NO = ps_account_no
                   AND URUN_SINIF_KOD NOT IN
                           ('CREDIT CARD-LC', 'OVERLIMIT-LC')
                   AND DURUM_KODU NOT IN 'K'
                   AND URUN_TUR_KOD IN ('PD-FIXRATE', 'PAST DUE');

        RETURN '000';
    EXCEPTION
        WHEN notFoundAccount
        THEN
            log_at ('GetLoans',
                    'notFoundAccount',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN '505';
        WHEN OTHERS
        THEN
            log_at ('GetLoanAccount',
                    'OTHERS',
                    SQLERRM,
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RAISE;
    END;
    FUNCTION GetAUCAStudentByID(ps_student_id in varchar2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2
    IS
        ln_name_count   NUMBER;
        notFoundName    EXCEPTION;
    BEGIN
        SELECT COUNT (*)
          INTO ln_name_count
          FROM CBS.CBS_TECH_SCH_AUCA
         WHERE ID = ps_student_id;

        IF ln_name_count != 1
        THEN
            RAISE notFoundName;
        END IF;

        OPEN pc_ref FOR
            SELECT FULLNAME
              FROM CBS.CBS_TECH_SCH_AUCA
             WHERE ID = ps_student_id;

        RETURN '000';
    EXCEPTION
        WHEN notFoundName THEN
            log_at ('GetAUCAStudentByID', 'notFoundName', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
            RETURN '505';
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
            log_at ('GetAUCAStudentByID', 'OTHERS', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RAISE;
    END;
END;
/

