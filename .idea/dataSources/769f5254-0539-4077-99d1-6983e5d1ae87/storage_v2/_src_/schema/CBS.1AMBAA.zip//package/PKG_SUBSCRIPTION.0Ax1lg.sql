create PACKAGE     "PKG_SUBSCRIPTION" IS
                                          
/******************************************************************************
   Name       : FUNCTION encodeBase64
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Encode given string to Base64 encoding scheme
******************************************************************************/   
FUNCTION encodeBase64(str VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION decodeBase64
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Decode given string from Base64 encoding scheme
******************************************************************************/   
FUNCTION decodeBase64(str VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION CheckSubscription
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Check given customer link for customer's subscription to the email notification
******************************************************************************/   
FUNCTION CheckSubscription (pn_musteri_no NUMBER, ps_email VARCHAR2, ps_hash VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION CheckUnsubscribeList
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Check if customer have already been added to unsubscribe list
******************************************************************************/   
FUNCTION CheckUnsubscribeList (ps_hash VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Name       : FUNCTION AddToUnsubscribeList
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Add customer to unsubscribe list
******************************************************************************/   
FUNCTION AddToUnsubscribeList (pn_musteri_no NUMBER, ps_email VARCHAR2, ps_hash VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   Name       : PROCEDURE UnsubscribeCustomers
   Created By : Adilet Kachkeev 20.02.2015
   Purpose      : Unsubscribe customers in an unsubscribe list from email notification
******************************************************************************/   
PROCEDURE UnsubscribeCustomers;

END;

/

