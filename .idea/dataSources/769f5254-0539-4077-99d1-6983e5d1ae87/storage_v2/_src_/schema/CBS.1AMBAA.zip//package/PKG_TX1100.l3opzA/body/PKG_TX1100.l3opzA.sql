create PACKAGE BODY PKG_TX1100 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;




  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
  	/* islem bilgisi guncellenir */
    update cbs_cek_karne_islem
	set durum_kodu = 'A',talep_tarihi = pkg_muhasebe.banka_tarihi_bul
	where tx_no = pn_islem_no ;


  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '139' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_karne_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   null;
  End;


END;
/

