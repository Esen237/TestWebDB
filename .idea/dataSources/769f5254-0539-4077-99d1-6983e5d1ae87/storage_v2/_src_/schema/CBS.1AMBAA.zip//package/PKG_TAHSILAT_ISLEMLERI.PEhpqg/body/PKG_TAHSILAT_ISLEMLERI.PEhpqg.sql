create PACKAGE BODY     "PKG_TAHSILAT_ISLEMLERI" IS
/******************************************************************************
   Name       : PKG_TAHSILAT_ISLEMLERI
   Created By : Seval colak 05082011   
   Purpose      : Kurum Tahsilatlari
******************************************************************************/

FUNCTION  Modul_Tur_Tahsilat RETURN VARCHAR2 IS
BEGIN
  RETURN 'COLLECTION' ;
END;

--***********************************

FUNCTION  Urun_Tur_Kod(pn_KOD NUMBER) RETURN VARCHAR2 IS
BEGIN

  IF pn_kod = 0 THEN
       RETURN 'GENERAL' ;
  ELSIF pn_kod = 1 THEN
       RETURN 'AUTOMATIC' ;
  ELSIF pn_kod = 2 THEN
       RETURN 'ONLINE' ;
  END IF;

END;
--***********************************

 PROCEDURE TAHSILAT_KURUM_KAYDI_AC(ps_kurum_kodu VARCHAR2,ps_kurum_adi VARCHAR2)
  IS

  BEGIN

    INSERT INTO CBS_TAHSILAT_KURUM_TANIM(KURUM_KODU,KURUM_ADI,DURUM_KODU) VALUES (ps_kurum_kodu,ps_kurum_adi,'AKTIF') ;

      EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5156' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;

--***********************************
 FUNCTION TAHSILAT_KURUM_KAYDI_VARMI(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
   ln_count  NUMBER;
  BEGIN

    SELECT COUNT(*)
    INTO   ln_count
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    IF ln_count = 0 THEN
       RETURN 'H';
    ELSE
       RETURN 'E';
    END IF;

   END ;

--***********************************
  FUNCTION Kurum_adi_al(ps_kurum_kodu VARCHAR2,ps_dil varchar2 default 'ENG') RETURN VARCHAR2
  IS
    ls_kurum_adi  VARCHAR2(2000);
  BEGIN

    SELECT DECODE( ps_dil,'RUS',KURUM_ADI_2,KURUM_ADI)
    INTO   ls_kurum_adi
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_kurum_adi;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_Hesabi_Urun_Tur_Uygun_mu(ps_urun VARCHAR2,ps_anlasma_sekli VARCHAR2 DEFAULT 'BANKAMIZ') RETURN VARCHAR2
  IS
  BEGIN

    IF ps_anlasma_sekli = 'BANKAMIZ' THEN

        IF ps_urun  IN ('CURRENT','DEMAND DEP') THEN
           RETURN 'E' ;
        ELSE
           RETURN 'H' ;
        END IF;
    ELSIF ps_anlasma_sekli = 'BASKA_BANKA' THEN
        IF ps_urun  IN ('NOSTRO-LC') THEN
           RETURN 'E' ;
        ELSE
           RETURN 'H' ;
        END IF;
    END IF;

   END ;

--***********************************
  FUNCTION DK_Hesabi_Uygun_mu(ps_dk VARCHAR2) RETURN VARCHAR2
  IS
  BEGIN

    IF (SUBSTR(ps_dk,1,3)  NOT IN ('010','011') ) AND  (SUBSTR(ps_dk,1,1)  NOT IN ('5','6','7','8','9') )THEN
       RETURN 'E' ;
    ELSE
       RETURN 'H' ;
    END IF;
   END ;

  --***********************************
  FUNCTION Sozlesme_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_zorunlu VARCHAR2(1);
  BEGIN

    SELECT TIZB_SOZLESME_NO
    INTO   ls_zorunlu
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN   ls_zorunlu;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Fatura_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_zorunlu VARCHAR2(1);
  BEGIN

    SELECT TIZB_FATURA_NO
    INTO   ls_zorunlu
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN   ls_zorunlu;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Telefon_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_zorunlu VARCHAR2(1);
  BEGIN

    SELECT TIZB_TELEFON_NO
    INTO   ls_zorunlu
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN   ls_zorunlu;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Tesisat_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_zorunlu VARCHAR2(1);
  BEGIN

    SELECT TIZB_TESISAT_NO
    INTO   ls_zorunlu
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN   ls_zorunlu;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_ozel_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_zorunlu VARCHAR2(1);
  BEGIN

    SELECT TIZB_KURUM_OZEL_NO
    INTO   ls_zorunlu
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN   ls_zorunlu;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_Hesabi_al(ps_kurum_kodu VARCHAR2, pn_kanal_no NUMBER DEFAULT 0) RETURN VARCHAR2
  IS
    ls_hesap_no  VARCHAR2(2000);
  BEGIN
    IF pn_kanal_no = 0 THEN
        SELECT NVL(KURUM_HESAP_NO,HESAP_NO)
        INTO   ls_hesap_no
        FROM   CBS_TAHSILAT_KURUM_TANIM
        WHERE  KURUM_KODU = ps_kurum_kodu ;
    ELSE
        SELECT NVL(HESAP_NO,0)
        INTO   ls_hesap_no
        FROM   CBS_TAHSILAT_KURUM_HESAP_TANIM
        WHERE  KURUM_KODU = ps_kurum_kodu
        AND    KANAL_NO   = pn_kanal_no;
    END IF;

    RETURN  ls_hesap_no;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_DK_Hesabi_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_dk_no  VARCHAR2(2000);
  BEGIN

    SELECT DK_NO
    INTO   ls_dk_no
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_dk_no;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_DK_Hesap_Subesi_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_dk_no_subesi  VARCHAR2(10);
  BEGIN

    SELECT DK_NO_SUBESI
    INTO   ls_dk_no_subesi
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_dk_no_subesi;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_Tahsilat_Hesap_DK(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_tahsilat  VARCHAR2(10);  -- DK veya KURUM doner
  BEGIN

    SELECT TAHSILAT_ALACAK_HESAP
    INTO   ls_tahsilat
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_tahsilat;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
PROCEDURE Tahsilat_Talimati_Log_Kaydet(pn_MUSTERI_NO        NUMBER ,
                                         pn_HESAP_NO             NUMBER ,
                                       ps_KURUM_KODU         VARCHAR2,
                                       ps_DURUM_KODU         VARCHAR2 DEFAULT NULL,
                                       pn_IPTAL_NEDENI         NUMBER   DEFAULT NULL,
                                       pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                       pn_FATURA_NO         VARCHAR2 DEFAULT NULL,
                                         ps_TELEFON_ALAN_KOD  VARCHAR2 DEFAULT NULL,
                                       ps_TELEFON_NO         VARCHAR2 DEFAULT NULL,
                                       pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                       pn_KURUM_OZEL_NO        VARCHAR2 DEFAULT NULL,
                                       pn_ISLEM_NO             NUMBER      DEFAULT NULL,
                                       pd_ISLEM_TARIHI         DATE      DEFAULT SYSDATE,
                                       pn_YARATAN_KULLANICI VARCHAR  DEFAULT USER,
                                       ps_TALIMAT_SEKLI        VARCHAR2 DEFAULT NULL,
                                       pn_TALIMAT_LIMITI    NUMBER   DEFAULT NULL)
IS
 PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

     INSERT INTO CBS_TAHSILAT_OTM_TALIMAT_LOG
     (MUSTERI_NO,HESAP_NO, KURUM_KODU, DURUM_KODU, IPTAL_NEDENI, SOZLESME_NO, FATURA_NO, TELEFON_ALAN_KOD, TELEFON_NO,
      TESISAT_NO, KURUM_OZEL_NO, ISLEM_NO, ISLEM_TARIHI, YARATAN_KULLANICI,TALIMAT_SEKLI, TALIMAT_LIMITI)
     VALUES
     (pn_MUSTERI_NO,pn_HESAP_NO, ps_KURUM_KODU, ps_DURUM_KODU, pn_IPTAL_NEDENI, pn_SOZLESME_NO, pn_FATURA_NO,
      ps_TELEFON_ALAN_KOD, ps_TELEFON_NO,pn_TESISAT_NO, pn_KURUM_OZEL_NO, pn_ISLEM_NO, pd_ISLEM_TARIHI,
      pn_YARATAN_KULLANICI,ps_TALIMAT_SEKLI, pn_TALIMAT_LIMITI) ;
   COMMIT;
END;
-----------------------------------------------------------------------------
PROCEDURE sp_Talimatli_Musteri_Kaydet(pn_MUSTERI_NO        NUMBER ,
                                         pn_HESAP_NO             NUMBER ,
                                       ps_KURUM_KODU         VARCHAR2,
                                       pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                       pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                         ps_TELEFON_ALAN_KOD  VARCHAR2      DEFAULT NULL,
                                       ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                       pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                       pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL,
                                       ps_TALIMAT_SEKLI        VARCHAR2 DEFAULT NULL,
                                       pn_TALIMAT_LIMITI    NUMBER   DEFAULT NULL,
                                          pd_TALIMAT_TARIHI    DATE     DEFAULT NULL,
                                       pn_ISLEM_NO            NUMBER   DEFAULT NULL,
                                       pn_IPTAL_ISLEM_NO    NUMBER   DEFAULT NULL,
                                       ps_ABONE_ADI            VARCHAR2 DEFAULT NULL)
IS
 PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

     INSERT INTO CBS_TAHSILAT_TALIMATLI_MUSTERI
     (MUSTERI_NO, HESAP_NO, KURUM_KODU, DURUM_KODU, SOZLESME_NO, FATURA_NO, TELEFON_ALAN_KOD, TELEFON_NO,
      TESISAT_NO, KURUM_OZEL_NO, AKTARIM,TALIMAT_SEKLI, TALIMAT_LIMITI,TALIMAT_TARIHI,YARATAN_ISLEM_NO,
      IPTAL_ISLEM_NO,AD_SOYAD)
     VALUES
     (pn_MUSTERI_NO,pn_HESAP_NO, ps_KURUM_KODU,'AKTIF',pn_SOZLESME_NO, pn_FATURA_NO,
      ps_TELEFON_ALAN_KOD, ps_TELEFON_NO,pn_TESISAT_NO, pn_KURUM_OZEL_NO,'E',ps_TALIMAT_SEKLI, pn_TALIMAT_LIMITI,
      pd_TALIMAT_TARIHI,pn_ISLEM_NO,pn_IPTAL_ISLEM_NO,ps_ABONE_ADI) ;
   COMMIT;

END;

--***********************************
  FUNCTION Hesap_Talimat_Sekli_al(pn_HESAP_NO             NUMBER ,
                                  ps_KURUM_KODU         VARCHAR2,
                                  pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                  pn_FATURA_NO             VARCHAR2      DEFAULT NULL,
                                    ps_TELEFON_ALAN_KOD   VARCHAR2      DEFAULT NULL,
                                  ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                  pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                  pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL) RETURN VARCHAR2
  IS
    ls_TALIMAT_SEKLI  VARCHAR2(2000);
  BEGIN

    SELECT TALIMAT_SEKLI
    INTO   ls_TALIMAT_SEKLI
    FROM   CBS_TAHSILAT_TALIMATLI_MUSTERI
    WHERE  (HESAP_NO = pn_HESAP_NO OR (HESAP_NO IS NULL AND pn_HESAP_NO IS NULL ) ) AND
           (KURUM_KODU = ps_KURUM_KODU OR ( KURUM_KODU IS NULL AND ps_KURUM_KODU IS NULL)) AND
           (SOZLESME_NO = pn_SOZLESME_NO OR (SOZLESME_NO IS NULL AND pn_SOZLESME_NO  IS NULL)) AND
           (TELEFON_ALAN_KOD = ps_TELEFON_ALAN_KOD OR (TELEFON_ALAN_KOD IS NULL AND ps_TELEFON_ALAN_KOD IS NULL)) AND
           (TELEFON_NO = ps_TELEFON_NO OR ( TELEFON_NO IS NULL AND ps_TELEFON_NO IS NULL)) AND
           (TESISAT_NO = pn_TESISAT_NO OR (TESISAT_NO IS NULL AND pn_TESISAT_NO IS NULL)) AND
           (KURUM_OZEL_NO = pn_KURUM_OZEL_NO OR (KURUM_OZEL_NO IS NULL AND pn_KURUM_OZEL_NO IS NULL)) AND
           DURUM_KODU              = 'AKTIF';



    RETURN  ls_TALIMAT_SEKLI;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Hesap_Talimat_Limiti_al(pn_HESAP_NO             NUMBER ,
                                  ps_KURUM_KODU         VARCHAR2,
                                  pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                  pn_FATURA_NO             VARCHAR2      DEFAULT NULL,
                                    ps_TELEFON_ALAN_KOD   VARCHAR2      DEFAULT NULL,
                                  ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                  pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                  pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL) RETURN NUMBER
  IS
    ls_TALIMAT_LIMITI  VARCHAR2(2000);
  BEGIN

    SELECT TALIMAT_LIMITI
    INTO   ls_TALIMAT_LIMITI
    FROM   CBS_TAHSILAT_TALIMATLI_MUSTERI
    WHERE  (HESAP_NO = pn_HESAP_NO OR (HESAP_NO IS NULL AND pn_HESAP_NO IS NULL ) ) AND
           (KURUM_KODU = ps_KURUM_KODU OR ( KURUM_KODU IS NULL AND ps_KURUM_KODU IS NULL)) AND
           (SOZLESME_NO = pn_SOZLESME_NO OR (SOZLESME_NO IS NULL AND pn_SOZLESME_NO  IS NULL)) AND
           (TELEFON_ALAN_KOD = ps_TELEFON_ALAN_KOD OR (TELEFON_ALAN_KOD IS NULL AND ps_TELEFON_ALAN_KOD IS NULL)) AND
           (TELEFON_NO = ps_TELEFON_NO OR ( TELEFON_NO IS NULL AND ps_TELEFON_NO IS NULL)) AND
           (TESISAT_NO = pn_TESISAT_NO OR (TESISAT_NO IS NULL AND pn_TESISAT_NO IS NULL)) AND
           (KURUM_OZEL_NO = pn_KURUM_OZEL_NO OR (KURUM_OZEL_NO IS NULL AND pn_KURUM_OZEL_NO IS NULL)) AND
           DURUM_KODU              = 'AKTIF';


    RETURN  ls_TALIMAT_LIMITI;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
PROCEDURE Tahsilat_OTMFatura_Log_Kaydet(pn_TX_NO            NUMBER ,
                                          pn_MUSTERI_NO       NUMBER ,
                                          pn_HESAP_NO         NUMBER ,
                                        ps_KURUM_KODU         VARCHAR2,
                                        pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                        pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                          ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                                        ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                        pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                        pn_KURUM_OZEL_NO    VARCHAR2      DEFAULT NULL,
                                        ps_DOVIZ_KODU         VARCHAR2 DEFAULT NULL,
                                        pn_TUTAR            NUMBER   DEFAULT NULL,
                                        pn_ODENEN_TUTAR        NUMBER   DEFAULT NULL,
                                        pd_SON_ODEME_TARIHI DATE      DEFAULT NULL,
                                        ps_KISMI_TAHSILAT    VARCHAR  DEFAULT NULL,
                                        ps_DURUM            VARCHAR2 DEFAULT NULL)
IS
 PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

     INSERT INTO CBS_TAHSILAT_OTMFATURA_LOG
     (TX_NO, MUSTERI_NO, HESAP_NO, KURUM_KODU, SOZLESME_NO, FATURA_NO, TELEFON_ALAN_KOD, TELEFON_NO, TESISAT_NO,
      KURUM_OZEL_NO, DOVIZ_KODU, TUTAR, ODENEN_TUTAR, SON_ODEME_TARIHI, KISMI_TAHSILAT,DURUM)
     VALUES
     (pn_TX_NO, pn_MUSTERI_NO,pn_HESAP_NO, ps_KURUM_KODU, pn_SOZLESME_NO, pn_FATURA_NO,
      ps_TELEFON_ALAN_KOD, ps_TELEFON_NO,pn_TESISAT_NO, pn_KURUM_OZEL_NO,ps_DOVIZ_KODU, pn_TUTAR,
      pn_ODENEN_TUTAR, pd_SON_ODEME_TARIHI, ps_KISMI_TAHSILAT,ps_DURUM) ;
   COMMIT;
END;
-----------------------------------------------------------------------------
PROCEDURE Tahsilat_Batch_Log_Kaydet(pd_TARIH              DATE,
                                    ps_PROGRAM_KODU       VARCHAR2 DEFAULT NULL,
                                       pn_YARATAN_TX_NO      NUMBER DEFAULT NULL,
                                       pn_HATA_KODU          NUMBER DEFAULT NULL,
                                       ps_HATA_ACIKLAMASI    VARCHAR2 DEFAULT NULL,
                                    pd_CALISMA_ZAMANI      DATE DEFAULT SYSDATE)
IS
 PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

     INSERT INTO CBS_TAHSILAT_BATCH_LOG
     (TARIH, PROGRAM_KODU, YARATAN_TX_NO, HATA_KODU, HATA_ACIKLAMASI, CALISMA_ZAMANI)
     VALUES
     (pd_TARIH, ps_PROGRAM_KODU, pn_YARATAN_TX_NO, pn_HATA_KODU, ps_HATA_ACIKLAMASI,pd_CALISMA_ZAMANI) ;

   COMMIT;
END;
-----------------------------------------------------------------------------
PROCEDURE sp_OTMFatura_Iptal_Log_Kaydet(ps_KURUM_KODU         VARCHAR2,
                                        pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                        pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                          ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                                        ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                        pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                        pn_KURUM_OZEL_NO    VARCHAR2      DEFAULT NULL,
                                        pn_TUTAR            NUMBER     DEFAULT NULL,
                                        pd_SON_ODEME_TARIHI DATE      DEFAULT NULL,
                                        ps_IPTAL_EDILEMEME_NEDENI    VARCHAR  DEFAULT NULL,
                                        pd_ISLEM_TARIHI        DATE DEFAULT NULL,
                                        ps_HATA_KODU        VARCHAR2 DEFAULT NULL,
                                        ps_HATA_ACIKLAMASI    VARCHAR2 DEFAULT NULL)
IS
 PRAGMA AUTONOMOUS_TRANSACTION ;
BEGIN

  INSERT INTO CBS_TAHSILAT_OTMFATURA_IPT_LOG
  (KURUM_KODU, SOZLESME_NO, FATURA_NO, TELEFON_ALAN_KOD, TELEFON_NO, TESISAT_NO, KURUM_OZEL_NO, TUTAR,
   SON_ODEME_TARIHI, IPTAL_EDILEMEME_NEDENI, ISLEM_TARIHI, HATA_KODU, HATA_ACIKLAMASI)
  VALUES
  (ps_KURUM_KODU, pn_SOZLESME_NO, pn_FATURA_NO, ps_TELEFON_ALAN_KOD, ps_TELEFON_NO,pn_TESISAT_NO,pn_KURUM_OZEL_NO,
   pn_TUTAR,pd_SON_ODEME_TARIHI,ps_IPTAL_EDILEMEME_NEDENI, pd_ISLEM_TARIHI, ps_HATA_KODU, ps_HATA_ACIKLAMASI) ;

  COMMIT;

END;
-----------------------------------------------------------------------------
  FUNCTION Kurum_tahsilat_Saati_Uygun_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ld_saat DATE;
  BEGIN
    
/* B-O-M sevalb 06092011 su asama da saat olayi soz konusu olmadaigindan kapatiliyor 

    ld_saat := Pkg_Tahsilat_Islemleri.Kurum_tahsilat_max_saat(ps_kurum_kodu) ;

    IF TO_NUMBER(REPLACE(TO_CHAR(ld_saat,'HH24:MI:SS'),':','')) <
       TO_NUMBER(REPLACE(TO_CHAR(SYSDATE,'HH24:MI:SS'),':','')) THEN

       RETURN  'H';
    ELSE
       RETURN  'E';
    END IF;

   E-O-M sevalb 06092011    */
 RETURN  'E';   --eklendi sevalb 06092011

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN  'H';
      WHEN OTHERS THEN
        RETURN  'H';

   END ;

--***********************************

  FUNCTION Iptal_Neden_Aciklamasi_Al(pn_kod NUMBER) RETURN VARCHAR2
  IS
    ls_aciklama VARCHAR2(2000);
  BEGIN

    SELECT ACIKLAMA
    INTO   ls_aciklama
    FROM   CBS_TAHSILAT_IPTAL_NEDEN_KOD
    WHERE  IPTAL_KODU = pn_kod ;

    RETURN ls_aciklama ;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN  NULL;
      WHEN OTHERS THEN
        RETURN  NULL ;

   END ;

--***********************************
  FUNCTION Talimat_Tarihi_al(pn_MUSTERI_NO          NUMBER ,
                             ps_KURUM_KODU          VARCHAR2,
                             pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                             pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                               ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                             ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                             pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                             pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN DATE
  IS
    ld_basvuru_tarihi  DATE;
  BEGIN
--     musteri numarasina bakmak istemezsen 0 gonder
    SELECT talimat_tarihi
    INTO   ld_basvuru_tarihi
    FROM   CBS_TAHSILAT_TALIMATLI_MUSTERI
    WHERE  durum_kodu = 'AKTIF'
    AND    MUSTERI_NO = DECODE(pn_MUSTERI_NO,0,MUSTERI_NO,pn_MUSTERI_NO) -- aslinda musterinoya gerek yok,spec bozulmasin diye boyle yaptim.
    AND    KURUM_KODU = ps_KURUM_KODU AND
           (SOZLESME_NO = pn_SOZLESME_NO OR (SOZLESME_NO IS NULL AND pn_SOZLESME_NO  IS NULL)) AND
           (TELEFON_ALAN_KOD = ps_TELEFON_ALAN_KOD OR (TELEFON_ALAN_KOD IS NULL AND ps_TELEFON_ALAN_KOD IS NULL)) AND
           (TELEFON_NO = ps_TELEFON_NO OR ( TELEFON_NO IS NULL AND ps_TELEFON_NO IS NULL)) AND
           (TESISAT_NO = pn_TESISAT_NO OR (TESISAT_NO IS NULL AND pn_TESISAT_NO IS NULL)) AND
           (KURUM_OZEL_NO = pn_KURUM_OZEL_NO OR (KURUM_OZEL_NO IS NULL AND pn_KURUM_OZEL_NO IS NULL))     ;


    RETURN  ld_basvuru_tarihi;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Talimat_Hesap_no_al(pn_MUSTERI_NO          NUMBER ,
                             ps_KURUM_KODU          VARCHAR2,
                             pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                             pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                               ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                             ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                             pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                             pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN NUMBER
  IS
    ln_hesap_no  NUMBER;
  BEGIN

    SELECT HESAP_NO
    INTO   ln_hesap_no
    FROM   CBS_TAHSILAT_TALIMATLI_MUSTERI
    WHERE  durum_kodu = 'AKTIF'
    AND    MUSTERI_NO = pn_MUSTERI_NO
    AND    KURUM_KODU = ps_KURUM_KODU AND
           (SOZLESME_NO = pn_SOZLESME_NO OR (SOZLESME_NO IS NULL AND pn_SOZLESME_NO  IS NULL)) AND
           (TELEFON_ALAN_KOD = ps_TELEFON_ALAN_KOD OR (TELEFON_ALAN_KOD IS NULL AND ps_TELEFON_ALAN_KOD IS NULL)) AND
           (TELEFON_NO = ps_TELEFON_NO OR ( TELEFON_NO IS NULL AND ps_TELEFON_NO IS NULL)) AND
           (TESISAT_NO = pn_TESISAT_NO OR (TESISAT_NO IS NULL AND pn_TESISAT_NO IS NULL)) AND
           (KURUM_OZEL_NO = pn_KURUM_OZEL_NO OR (KURUM_OZEL_NO IS NULL AND pn_KURUM_OZEL_NO IS NULL))     ;


    RETURN  ln_hesap_no;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
 
FUNCTION Abone_adi_al(ps_KURUM_KODU      VARCHAR2,
                     pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                     pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                      ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                     ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                     pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                     pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN VARCHAR2
  IS
   ls_isim  VARCHAR2(2000):= NULL;
  BEGIN
     SELECT AD_SOYAD  -- avea olmas?na bakma, zamaninda isimlendirme yanlis yapildi
        INTO   ls_isim
        FROM   CBS_TAHSILAT_TALIMATLI_MUSTERI
        WHERE  (KURUM_KODU = ps_KURUM_KODU OR ( KURUM_KODU IS NULL AND ps_KURUM_KODU IS NULL)) AND
               (SOZLESME_NO = pn_SOZLESME_NO OR (SOZLESME_NO IS NULL AND pn_SOZLESME_NO  IS NULL)) AND
               (TELEFON_ALAN_KOD = ps_TELEFON_ALAN_KOD OR (TELEFON_ALAN_KOD IS NULL AND ps_TELEFON_ALAN_KOD IS NULL)) AND
               (TELEFON_NO = ps_TELEFON_NO OR ( TELEFON_NO IS NULL AND ps_TELEFON_NO IS NULL)) AND
               (TESISAT_NO = pn_TESISAT_NO OR (TESISAT_NO IS NULL AND pn_TESISAT_NO IS NULL)) AND
               (KURUM_OZEL_NO = pn_KURUM_OZEL_NO OR (KURUM_OZEL_NO IS NULL AND pn_KURUM_OZEL_NO IS NULL)) AND
               DURUM_KODU              = 'AKTIF';

   
    RETURN ls_isim ;
      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

  END;
--***********************************
 
  FUNCTION Kurum_OtmTahsilat_Hesabi_al(ps_kurum_kodu VARCHAR2) RETURN NUMBER
  IS
    ln_hesap_no  NUMBER;
  BEGIN

    SELECT OTOMATIK_TAHSILAT_HESAP_NO
    INTO   ln_hesap_no
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ln_hesap_no;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************
  FUNCTION Kurum_Anlasma_Sekli_Al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_ANLASMA_SEKLI  VARCHAR(30);
  BEGIN

    SELECT ANLASMA_SEKLI
    INTO   ls_ANLASMA_SEKLI
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_ANLASMA_SEKLI;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--***********************************

FUNCTION Kurum_musteri_no_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 IS
 ln_musteri_no NUMBER;

BEGIN
      SELECT musteri_no
      INTO   ln_musteri_no
      FROM   CBS_TAHSILAT_KURUM_TANIM
      WHERE  kurum_kodu = ps_kurum_kodu  ;

  RETURN ln_musteri_no ;

    EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

END;
--***********************************
FUNCTION Kurum_anlasmali_musteri_no_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 IS
 ln_musteri_no NUMBER;

BEGIN
      SELECT ANLASMALI_BANKA_MUSTERI_NO
      INTO   ln_musteri_no
      FROM   CBS_TAHSILAT_KURUM_TANIM
      WHERE  kurum_kodu = ps_kurum_kodu  ;

  RETURN ln_musteri_no ;

   EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

END;

--***********************************
 FUNCTION Kurum_Otomatik_Tahsilat_var_mi(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_OTOMATIK_TAHSILAT  VARCHAR2(2000);
  BEGIN

    SELECT OTOMATIK_TAHSILAT
    INTO   ls_OTOMATIK_TAHSILAT
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_OTOMATIK_TAHSILAT;

      EXCEPTION
        WHEN OTHERS THEN
        RETURN NULL;

   END ;

--------------------------------------------------------------------------------------------------
 FUNCTION AktiflikTarihi_Aciklama_Al(ps_Kod VARCHAR2) RETURN VARCHAR2
  IS
    ls_ACIKLAMA  VARCHAR2(2000);
  BEGIN

    SELECT ACIKLAMA
    INTO   ls_ACIKLAMA
    FROM   CBS_TAHSILAT_OTMAKTIFLIK_TARIH
    WHERE  KOD = ps_Kod ;

    RETURN  ls_ACIKLAMA;

      EXCEPTION
       WHEN OTHERS THEN
        RETURN NULL;

   END ;

--------------------------------------------------------------------------------------------------
 FUNCTION Kurum_Grup_Aciklama_Al(ps_grup_kod varchar2,ps_dil varchar2 default 'ENG') RETURN VARCHAR2
  IS
    ls_ACIKLAMA  VARCHAR2(2000);
  BEGIN

    SELECT DECODE(ps_dil,'RUS',ACIKLAMA_2,ACIKLAMA)
    INTO   ls_ACIKLAMA
    FROM   CBS_TAHSILAT_KURUM_GRUP_TANIM
    WHERE  GRUP_KODU = ps_grup_kod ;

    RETURN  ls_ACIKLAMA;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;


-----------------------------------------------------------------------------
FUNCTION Kurum_alt_Grup_Aciklama_Al(ps_grup_kod varchar2 ,ps_alt_grup_kod varchar2,ps_dil varchar2 default 'ENG' ) RETURN VARCHAR2
  IS
    ls_ACIKLAMA  VARCHAR2(2000);
  BEGIN

     SELECT DECODE(ps_dil,'RUS',ACIKLAMA_2,ACIKLAMA)
    INTO   ls_ACIKLAMA
    FROM   CBS_TAHSILAT_KURUM_ALTGRUP_TAN
    WHERE  GRUP_KODU = ps_grup_kod AND
           ALT_GRUP_KODU =ps_alt_grup_kod;

    RETURN  ls_ACIKLAMA;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

-----------------------------------------------------------------------------
 FUNCTION Kurum_min_Digit_Al(ps_Kurum VARCHAR2) RETURN NUMBER
  IS
    ln_KURUM_DIGIT   NUMBER;
  BEGIN

    SELECT MIN_DIGIT_NUMBER
    INTO   ln_KURUM_DIGIT
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_Kurum ;

    RETURN  ln_KURUM_DIGIT;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
---------------------------------------------------------------------------------
 FUNCTION Kurum_max_Digit_Al(ps_Kurum VARCHAR2) RETURN NUMBER
  IS
    ln_KURUM_DIGIT   NUMBER;
  BEGIN

    SELECT MAX_DIGIT_NUMBER
    INTO   ln_KURUM_DIGIT
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_Kurum ;

    RETURN  ln_KURUM_DIGIT;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
---------------------------------------------------------------------------------

 FUNCTION Kurum_Digit_Mesaj_Al(ps_Kurum VARCHAR2) RETURN VARCHAR2
  IS
    ls_KURUM_DIGIT_MESAJ  VARCHAR2(2000);
  BEGIN

    SELECT KURUM_DIGIT_MESAJ
    INTO   ls_KURUM_DIGIT_MESAJ
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_Kurum ;

    RETURN  ls_KURUM_DIGIT_MESAJ;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

-----------------------------------------------------------------------------
   FUNCTION kanal_adi_al(pn_kanal_no NUMBER)  RETURN VARCHAR2 IS
   ls_aciklama VARCHAR2(200);
   BEGIN
     SELECT kanal_adi
       INTO ls_aciklama
       FROM CBS_KANAL_KODLARI
      WHERE kanal_no = pn_kanal_no;
     RETURN ls_aciklama;
 
    EXCEPTION                       
       WHEN OTHERS THEN                           
        RETURN NULL;
   END;
-----------------------------------------------------------------------------
FUNCTION Grup_koduna_bagli_kurum_Var(ps_grup_kod varchar2) RETURN VARCHAR2
is
ln_adet number := 0;
Begin
    SELECT count(*)
    INTO   ln_adet
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_GRUP_KOD = ps_grup_kod ;
    
    if ln_adet <> 0 then 
        return 'E';
    else    
        return 'H';
    end if;
     EXCEPTION
      WHEN OTHERS THEN
        RETURN 'H';
End;
-----------------------------------------------------------------------------
FUNCTION AltGrup_koduna_bagli_kurum_Var(ps_grup_kod varchar2,ps_alt_grup_kod varchar2) RETURN VARCHAR2
is
ln_adet number := 0;
Begin
    SELECT count(*)
    INTO   ln_adet
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_GRUP_KOD = ps_grup_kod and
           KURUM_ALT_GRUP_KOD =ps_alt_grup_kod  ;
    
    if ln_adet <> 0 then 
        return 'E';
    else    
        return 'H';
    end if;
     EXCEPTION
      WHEN OTHERS THEN
        RETURN 'H';
End;
-----------------------------------------------------------------------------
FUNCTION Kurum_grup_kodu_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_KURUM_GRUP_KOD  VARCHAR(200);
  BEGIN

    SELECT KURUM_GRUP_KOD
    INTO   ls_KURUM_GRUP_KOD
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_KURUM_GRUP_KOD;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
-----------------------------------------------------------------------------
FUNCTION Kurum_alt_grup_kodu_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_KURUM_GRUP_KOD  VARCHAR(200);
  BEGIN

    SELECT KURUM_ALT_GRUP_KOD
    INTO   ls_KURUM_GRUP_KOD
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_KURUM_GRUP_KOD;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
-----------------------------------------------------------------------------
FUNCTION Kurum_iptal_talebi_girilebilmi(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2
  IS
    ls_IPTAL_TALEBI_VAR  VARCHAR(1);
  BEGIN

    SELECT IPTAL_TALEBI_VAR
    INTO   ls_IPTAL_TALEBI_VAR
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ls_IPTAL_TALEBI_VAR;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
-----------------------------------------------------------------------------
FUNCTION Kurum_iptal_max_datetime(ps_kurum_kodu VARCHAR2,Pd_date date default sysdate ) RETURN DATE
  IS
    ld_date date;
  BEGIN
       
    select DECODE(IPTAL_TALEBI_VAR,'E', to_date(to_char( nvl(pd_date,sysdate) +nvl(iptal_kontrol_gun_sayisi,0) ,'DDMMYYYY') || nvl(to_char(iptal_kontrol_saat,'HH24:MI'),'00:00') ,'DDMMYYYY HH24:MI'),
        NULL) max_date
    into   ld_date    
    from   cbs_tahsilat_kurum_tanim
    where  kurum_kodu = ps_kurum_kodu ;

    RETURN  ld_date;

      EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;

   END ;

--B-O=M ernestk 12052014 cqdb00000524 function to get provider code of kurum
 /*
    Name:           kurum_provider_code_al
    Modify Date:    12052014
    Modified By:    Ernest Kuttubaev
    Description:    to get the provider of this tahsilat
 */
 FUNCTION Kurum_provider_code_al(ps_kurum_kodu varchar2) RETURN VARCHAR2
   is
     ls_provider_code cbs.cbs_tahsilat_kurum_tanim.provider_code%type;
   begin
     select t.provider_code
     into   ls_provider_code
     from   cbs.cbs_tahsilat_kurum_tanim t
     where  t.kurum_kodu = ps_kurum_kodu;
     
     return ls_provider_code;
     
     exception
       when NO_DATA_FOUND then
         return null;
       when OTHERS then
         return null;
     end;
-----------------------------------------------------------------------------
 /*FUNCTION Kurum_service_code_al(ps_kurum_kodu varchar2) RETURN VARCHAR2
   is
     ls_service_code cbs.cbs_tahsilat_kurum_tanim.service_code%type;
   begin
     select t.service_code
     into   ls_service_code
     from   cbs.cbs_tahsilat_kurum_tanim t
     where  t.kurum_kodu = ps_kurum_kodu;
     
     return ls_service_code;
     
     exception
       when NO_DATA_FOUND then
         return null;
       when OTHERS then
         return null;
     end;*/

-----------------------------------------------------------------------------
 Function Usip_Response_Code_Explanation(Pn_Response_Code Number) Return Varchar2
  is
    ls_explanation  cbs_usip_webserv_response_code.explanation%type;
  begin

    select explanation
    into   ls_explanation
    from   cbs_usip_webserv_response_code
    where  response_code = pn_response_code;

    return  ls_explanation;

      exception
      when no_data_found then
        return null;
      when others then
        return null;

   end ;
-----------------------------------------------------------------------------
 Function Usip_Response_Code_Short_Expl(Pn_Response_Code Number) Return Varchar2
  is
    ls_explanation  cbs_usip_webserv_response_code.short_explanation%type;
  begin

    select short_explanation
    into   ls_explanation
    from   cbs_usip_webserv_response_code
    where  response_code = pn_response_code;

    return  trim(ls_explanation);

      exception
      when no_data_found then
        return null;
      when others then
        return null;

   end ;
-----------------------------------------------------------------------------
 Function Usip_Response_Code_Long_Expl(Pn_Response_Code Number) Return Varchar2
  is
    ls_explanation  cbs_usip_webserv_response_code.long_explanation%type;
  begin

    select long_explanation
    into   ls_explanation
    from   cbs_usip_webserv_response_code
    where  response_code = pn_response_code;

    return  ls_explanation;

      exception
      when no_data_found then
        return null;
      when others then
        return null;

   end ;
-----------------------------------------------------------------------------
Function Usip_Response_Code_Eng_Expl(Pn_Response_Code Number) Return Varchar2
  is
    ls_explanation  cbs_usip_webserv_response_code.explanation_eng%type;
  begin

    select explanation_eng
    into   ls_explanation
    from   cbs_usip_webserv_response_code
    where  response_code = pn_response_code;

    return  ls_explanation;

      exception
      when no_data_found then
        return null;
      when others then
        return null;

   end ;
Function Usip_Statu_Code_Expl(Pn_statu_code Number) Return Varchar2
  is
    ls_explanation  cbs_usip_webserv_statu_code.explanation%type;
  begin
    if nvl(Pn_statu_code,0)<>0 then 
        select explanation
        into   ls_explanation
        from   cbs_usip_webserv_statu_code
        where  statu_code = Pn_statu_code;
    end if;

    return  ls_explanation;

      exception
      when no_data_found then
        return 'ERROR';
      when others then
        return null;

   end ;
-----------------------------------------------------------------------------
PROCEDURE ins_tahsilat_usip_webserv_log( 
                pn_islem_tanim_kod  number default 6330,    
                ps_transaction_type  varchar2 default null,     
                pn_tx_no    number,        
                pn_tahsilat_islem_no  number default 0,        
                pn_tahsilat_islem_sira_no number default 0,        
                pn_payment_id   number default 0,        
                pn_service_id number   default 0,
                ps_usip_status_code varchar2 default null, --asagidaki kisim usip webservice den donen degerleri kaydetmek icindir      
                ps_usip_result_code    varchar2 default null ,        
                ps_usip_transactionnumber varchar2 default null,        
                ps_usip_serviceid   varchar2 default null,        
                ps_usip_amount      varchar2 default null,        
                ps_usip_accountnumber   varchar2 default null,
                ps_error_message    varchar2 default null
            ) IS
pragma autonomous_transaction;
 begin
      insert into cbs_tahsilat_usip_webserv_log
         (      log_no  ,      
                transaction_type,  
                banka_tarihi ,
                islem_tanim_kod,             
                yaratan_islem_no  ,        
                tahsilat_islem_no ,        
                tahsilat_islem_sira_no ,        
                payment_id,      
                service_id,  
                usip_status_code,        
                usip_result_code,        
                usip_transactionnumber ,        
                usip_serviceid,        
                usip_amount,        
                usip_accountnumber,
                error_message)              --seval.colak 05.05.2021 Complaint_3610 
      values (
                pkg_genel.genel_kod_al('USIP_WEBSERV_LOG')  ,
                ps_transaction_type,        
                pkg_muhasebe.banka_tarihi_bul ,
                pn_islem_tanim_kod,       
                pn_tx_no  ,        
                pn_tahsilat_islem_no ,        
                pn_tahsilat_islem_sira_no ,        
                pn_payment_id,  
                pn_Service_id,      
                ps_usip_status_code,        
                ps_usip_result_code,        
                ps_usip_transactionnumber ,        
                ps_usip_serviceid,        
                ps_usip_amount,        
                ps_usip_accountnumber,
                substr(ps_error_message,1,2000) --seval.colak 05.05.2021 Complaint_3610 
         );
      commit;
  Exception when others then log_at('ins_tahsilat_usip_webserv_log error:',sqlcode,sqlerrm);

 End;
-----------------------------------------------------------------------------
 FUNCTION Usip_service_id(ps_kurum_kodu varchar2) Return number
  IS
    ln_service_id   NUMBER;
  BEGIN

    SELECT service_id
    INTO   ln_service_id
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_kurum_kodu ;

    RETURN  ln_service_id;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
-----------------------------------------------------------------------------
PROCEDURE upd_tahsilat_usip_statu_code( pn_tx_no   number,ps_usip_status_code varchar2) IS
pragma autonomous_transaction;
Begin
      update cbs_tahsilat 
      set usip_statu_code =ps_usip_status_code,
          usip_statu_code_updated_date =sysdate
      where islem_no = pn_tx_no;
    
    commit;
  EXCEPTION
  WHEN OTHERS THEN  
     log_at('upd_tahsilat_usip_statu_code error',pn_tx_no,'ps_usip_status_code:' ||ps_usip_status_code, sqlcode||''||sqlerrm);
     rollback;
                
End;

procedure Usip_payment_statu_code_al(pn_tx_no number ,ps_statu_code out varchar2,ps_result_code out varchar2) 
is
    pc_ref cbs.pkg_soa_transaction.cursorreferencetype;
    ls_returncode   varchar2(10);
    webservice_error exception ;
    ls_returncode_Explanation   VARCHAR2(2000);
    --ls_resultcode   varchar2(200);
    ls_usip_status_code varchar2(200);        
    ls_usip_result_code    varchar2(200);        
    ls_usip_transactionnumber varchar2(200);           
    ls_usip_serviceid   varchar2(200);        
    ls_usip_amount      varchar2(200);        
    ls_usip_accountnumber   varchar2(200);

    CURSOR c_islem IS
        select * from cbs_tahsilat
        where islem_no = pn_tx_no ; 

    r_islem c_islem%ROWTYPE;

Begin

   OPEN c_islem;
   FETCH c_islem INTO r_islem;
   CLOSE c_islem;
    
   ps_statu_code :=  60; --pkg_soa_transaction.getWSPaymentStatus(trim( to_char( r_islem.tutar,'9999999999999999999.99')),pn_tx_no,pc_ref);
   
    begin         
                
        loop
          fetch pc_ref into  ls_usip_status_code, ls_usip_result_code, ls_usip_transactionnumber, ls_usip_serviceid, ls_usip_amount, ls_usip_accountnumber ;
          exit when PC_REF%notfound;                      
      end loop;
        exception when others then log_at('PKG_TAHSILAT_ISLEMLERI-USIP_PAYMENT_STATUS_AL WEBSERVICE PARSING ERROR',pn_tx_no,sqlcode,sqlerrm);
     End;

    ps_result_code :=ls_usip_result_code;

        pkg_tahsilat_islemleri.ins_tahsilat_usip_webserv_log( 
                    0,       
                    'STATU',
                    r_islem.islem_no,        
                    r_islem.islem_no ,        
                    r_islem.sira_no,        
                    r_islem.payment_id  ,    
                    pkg_tahsilat_islemleri.Usip_service_id(r_islem.kurum_kodu),    
                   nvl( ls_usip_status_code,ps_statu_code) ,        
                    ls_usip_result_code ,        
                    ls_usip_transactionnumber,        
                    ls_usip_serviceid,        
                    ls_usip_amount,        
                    ls_usip_accountnumber
                   ) ;
     pkg_tahsilat_islemleri.upd_tahsilat_usip_statu_code( r_islem.islem_no,ls_usip_status_code);

    
    Exception when others then 
            log_at('USIP_PAYMENT_STATUS_AL_LOG_AT ERROR',pn_tx_no,sqlcode,sqlerrm);

 End; 
-----------------------------------------------------------------------------------------------------------
FUNCTION Kurum_min_payment_amount_Al(ps_Kurum VARCHAR2) RETURN NUMBER
  IS
    ln_MIN_PAYMENT_AMOUNT   NUMBER;
  BEGIN

    SELECT MIN_PAYMENT_AMOUNT
    INTO   ln_MIN_PAYMENT_AMOUNT
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_Kurum ;

    RETURN  ln_MIN_PAYMENT_AMOUNT;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
---------------------------------------------------------------------------------
FUNCTION Kurum_MAX_payment_amount_Al(ps_Kurum VARCHAR2) RETURN NUMBER
  IS
    ln_MAX_PAYMENT_AMOUNT   NUMBER;
  BEGIN

    SELECT MAX_PAYMENT_AMOUNT
    INTO   ln_MAX_PAYMENT_AMOUNT
    FROM   CBS_TAHSILAT_KURUM_TANIM
    WHERE  KURUM_KODU = ps_Kurum ;

    RETURN  ln_MAX_PAYMENT_AMOUNT;

      EXCEPTION
      WHEN OTHERS THEN
        RETURN NULL;

   END ;
-------------------------------------------------------------------------------------------------------------------------
PROCEDURE BLOKE_YARAT(pn_tx_no number, pn_hesap_no number,pn_bloke_tutari number , ps_bloke_referans out varchar2  )
is
 cursor cur_islem is
    select
        pkg_muhasebe.banka_tarihi_bul kayit_tarih,
        sysdate kayit_sistem_tarihi,
        nvl(nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu),kayit_kullanici_kodu)  kayit_kullanici_kodu,
        nvl(nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu),kayit_kullanici_bolum_kodu) kayit_kullanici_bolum_kodu,
        pkg_muhasebe.banka_tarihi_bul dogru_tarih    ,
        nvl(nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu),kayit_kullanici_kodu)  dogru_kullanici_kodu,
        nvl(nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu),kayit_kullanici_bolum_kodu) dogru_kullanici_bolum_kodu,
        pkg_muhasebe.banka_tarihi_bul onay_tarih,
        sysdate onay_sistem_tarihi,
        nvl(nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu),kayit_kullanici_bolum_kodu) onay_kullanici_bolum_kodu    ,
        nvl(nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu),kayit_kullanici_kodu) onay_kullanici_kodu
    from cbs_islem
    where numara = pn_tx_no ;

  r_islem        cur_islem%rowtype;
  ls_hesap_doviz      varchar2(3);
  ln_musteri_no       number;
  ln_hesap_no       number;   
  ls_aciklama                 varchar2 (2000) := 'Payment Transfer Blockage' ;
  ls_bloke_neden              cbs_bloke_neden_kodlari.bloke_neden_kodu%type := '6';
  ls_bloke_referans     varchar2(100);
  ls_hata_mesaj      varchar2(2000);
  ls_ucpointer      varchar2(3):=pkg_hata.getucpointer;
  ls_delimiter      varchar2(3):=pkg_hata.getdelimiter;
  ls_err         varchar2(100);
  ln_i          number := 0;
  ln_bloke_tutari       number;
Begin
   
   For c_islem in cur_islem  loop
    r_islem := c_islem ;
  end loop;
     ls_hesap_doviz     := pkg_hesap.HesaptanDovizKoduAl(pn_HESAP_NO);
     ln_musteri_no      := pkg_hesap.HesaptanMusteriNoAl(pn_HESAP_NO);
     ln_hesap_no        := pn_HESAP_NO;
     ls_bloke_referans   := null;
     ln_bloke_tutari     := pn_bloke_tutari;
    
     pkg_bloke.sp_bloke_yarat (
                                 ls_bloke_referans,
                                 ln_musteri_no,
                                 ln_hesap_no,
                                 ls_hesap_doviz,
                                 ln_bloke_tutari,
                                 ls_bloke_neden,
                                 ls_aciklama,
                                 pkg_muhasebe.banka_tarihi_bul,
                                 null,
                                 null,
                                 pn_tx_no,
                                 r_islem.kayit_tarih,
                                 r_islem.kayit_sistem_tarihi,
                                 r_islem.kayit_kullanici_kodu,
                                 r_islem.kayit_kullanici_bolum_kodu,
                                 r_islem.dogru_tarih    ,
                                 r_islem.dogru_kullanici_kodu,
                                 r_islem.dogru_kullanici_bolum_kodu,
                                 r_islem.onay_tarih,
                                 r_islem.onay_sistem_tarihi,
                                 r_islem.onay_kullanici_kodu,
                                 r_islem.onay_kullanici_bolum_kodu  ) ;
    ps_bloke_referans := ls_bloke_referans ;

  EXCEPTION
    WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3704' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;

-------------------------------------------------------------------------------------------------------------------------
PROCEDURE BLOKE_COZ(pn_tx_no number, ps_bloke_referans varchar2 default null )
is
cursor cur_bloke is
 select  *
 from cbs_bloke
 where bloke_referans = ps_bloke_referans and durum_kodu = 'A';    

 cursor cur_islem is
      select
        pkg_muhasebe.banka_tarihi_bul kayit_tarih,
        sysdate kayit_sistem_tarihi,
        nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) kayit_kullanici_kodu,
        nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) kayit_kullanici_bolum_kodu,
        pkg_muhasebe.banka_tarihi_bul dogru_tarih    ,
        nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) dogru_kullanici_kodu,
        nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) dogru_kullanici_bolum_kodu,
        pkg_muhasebe.banka_tarihi_bul onay_tarih,
        sysdate onay_sistem_tarihi,
        nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) onay_kullanici_bolum_kodu    ,
        nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) onay_kullanici_kodu
    from cbs_islem
    where numara = pn_tx_no ;
  r_islem        cur_islem%rowtype;
  r_bloke        cur_bloke%rowtype;
  ls_hesap_doviz      varchar2(3);
  ln_musteri_no       number;
  ls_bloke_referans     varchar2(100);
  ln_hesap_no      number;
  ls_hata_mesaj      varchar2(2000);
  ls_ucpointer      varchar2(3):=pkg_hata.getucpointer;
  ls_delimiter      varchar2(3):=pkg_hata.getdelimiter;
   ls_err         varchar2(100);
  ln_i          number := 0;
  ln_bloke_tutari       number;
Begin
   
   For c_islem in cur_islem  loop
    r_islem := c_islem ;
  end loop;

    For c_bloke in cur_bloke loop
       r_Bloke := c_bloke;
    end loop ;

    if  r_bloke.bloke_referans is not null then
        ln_i := ln_i + 1;
        ls_bloke_referans := r_bloke.bloke_referans;
      ln_bloke_tutari  := r_bloke.bloke_tutari;
        if  pkg_bloke.sf_bloke_durum_kodu_al(r_bloke.bloke_referans) != 'K' then
         ls_hesap_doviz     := pkg_hesap.HesaptanDovizKoduAl(r_bloke.HESAP_NO);
         ln_musteri_no      := pkg_hesap.HesaptanMusteriNoAl(r_bloke.HESAP_NO);
         ln_hesap_no      := r_bloke.hesap_no;
        --mevcut bloke kapama amacli cagrilir.
              begin
                 pkg_bloke.sp_bloke_yarat (
                 ps_bloke_referans => r_bloke.bloke_referans,
                 pn_musteri_no =>ln_musteri_no ,
                 pn_hesap_no=>r_bloke.hesap_no,
                 ps_doviz_kodu=> ls_hesap_doviz,
                 pn_bloke_tutari=>0,
                 ps_bloke_neden_kodu=>r_bloke.bloke_neden_kodu,
                 ps_aciklama=>r_bloke.aciklama,
                 pd_bloke_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                 pd_bloke_bitis_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                 pn_tx_no=> null,
                 p_coz_kayit_tarih =>r_islem.kayit_tarih,
                 p_coz_kayit_sistem_tarih=>r_islem.kayit_sistem_tarihi,
                 p_coz_kayit_kullanici_kodu=>r_islem.kayit_kullanici_kodu,
                 p_coz_kayit_kullanici_bolumkod=>r_islem.kayit_kullanici_bolum_kodu,
                 p_coz_dogru_tarih=>r_islem.dogru_tarih,
                 p_coz_dogru_kullanici_kodu=>r_islem.dogru_kullanici_kodu,
                 p_coz_dogru_kullanici_bolumkod=>r_islem.dogru_kullanici_bolum_kodu,
                 p_coz_onay_tarih=>r_islem.onay_tarih,
                 p_coz_onay_sistem_tarih=>r_islem.onay_sistem_tarihi,
                 p_coz_onay_kullanici_kodu=>r_islem.onay_kullanici_kodu,
                 p_coz_onay_kullanici_bolumkod=>r_islem.onay_kullanici_bolum_kodu,
                 ps_kapama=>'KAPAMA');

         end;
        end if;
   end if;
 
  EXCEPTION
    WHEN OTHERS THEN         
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3754' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;
-------------------------------------------------------------------------------------------------------------------------
--  booktobooktransfer is taken from copy of IB booktobooktransfer and changed to new tran code  6332 and can be used for other batch process bookto book transfer
Procedure booktobooktransfer(pn_grup_no Number default 0, pn_log_no Number default 0, ps_program_kod Varchar2 default 'PKG_BAT_3.KURUM_INTER_TO_MAIN_ACCT_TRANS',
                             ps_instution_code varchar2,
                             pn_fromaccountno number,
                             pn_toaccountno  number,
                             pn_amount        number,
                             pn_instution_balance number default null,
                             pn_instution_available_bal number default null,
                             pn_Remain_amount number default null,   
                             pn_islem_kod     number default 6332,
                             ps_description   IN VARCHAR2 default 'Payment transfer from Intermediate acount to Main Account',                           
                             pn_islem_no out number
                             )                                
  IS    PRAGMA autonomous_transaction;                                                    
      pc_modul_tur_kod     VARCHAR2 (20);
      pc_urun_tur_kod      VARCHAR2 (20);
      pc_urun_sinif_kod    VARCHAR2 (20);
      ps_bolum_kodu        VARCHAR2 (3):= Pkg_Hesap.hesapsubeal (pn_fromaccountno);
      pc_bolum_kodu        VARCHAR (10)  := ps_bolum_kodu;
      pc_amir_bolum_kodu   VARCHAR (10)  := ps_bolum_kodu;
      pn_musteri_numara    NUMBER:= Pkg_Hesap.hesaptanmusterinoal (TO_NUMBER (pn_fromaccountno));
      pc_hesap_numara      NUMBER        := TO_NUMBER (pn_fromaccountno);
      pc_kasa_kod          NUMBER;
      pn_kanal_numara      NUMBER        := 1;
      exacc_b               VARCHAR2(16);
      exacc_a               VARCHAR2(16);
      ls_ISTATISTIK_KODU    VARCHAR2(10);
      ls_PREFIX_STAT        VARCHAR2(4);
      ln_CHARGE_AMOUNT        NUMBER;
      ls_sube varchar2(20);
      ps_currencycode   VARCHAR2(3);
      pn_fis_no number := null;  
    ln_service_tax_rate NUMBER := 0;
    ln_SERVICE_TAX NUMBER := 0;
    ln_amount       number:= 0;
BEGIN
    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);
      pkg_baglam.batch;
      ls_sube := pkg_hesap.hesaptansubeal(pn_fromaccountno);
      ps_currencycode := pkg_hesap.hesaptandovizkodual(pn_fromaccountno);
      pn_islem_no:=pkg_batch.islem_yarat(pn_islem_kod,ls_sube);
       
      exacc_b := to_char(pkg_hesap.external_hesapno_al(pn_fromaccountno));--,'fm000000000');
      exacc_a := to_char(pkg_hesap.external_hesapno_al(pn_toaccountno));
      
      ls_prefix_stat := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno))) ||
                        pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_toaccountno))) ||
                        pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(pn_toaccountno))) ;

      ls_istatistik_kodu:= null; --pkg_message.split(ps_paymentcode,';',0);  --sorulacak 

      Pkg_Tx6332.sp_urun_tur_sinif_al(  pn_fromaccountno,
                                            pn_toaccountno  ,
                                           ps_currencycode ,
                                           'H',     --notinternet 
                                           pc_modul_tur_kod,
                                            pc_urun_tur_kod,
                                            pc_urun_sinif_kod);

      Pkg_Masraf.masraf_yarat(pn_islem_no,pn_islem_kod,
                                            pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod ,
                                            pn_amount,
                                            pc_bolum_kodu,
                                                ps_currencycode,
                                            pn_musteri_numara,
                                            pc_hesap_numara,null,ps_currencycode);
       Pkg_Masraf.validate_masraf(pn_islem_no);
                    
       ln_charge_amount := pkg_masraf.toplam_masraf(pn_islem_no);
       ln_service_tax:=  round( (nvl(ln_service_tax_rate,0)*nvl(ln_charge_amount,0) )/100,2);

       if pn_islem_kod = 6332 then 
            ln_amount:= ( ( nvl(pn_instution_available_bal,0) - ( nvl(ln_charge_amount,0) + nvl(ln_service_tax,0)) ) - nvl(pn_remain_amount,0) ) ;
         else
            ln_amount := pn_amount;
        end if;

       insert into cbs_usip_virman_islem
                  (tx_no, borc_hesap_no, doviz_kodu, tutar,alacak_hesap_no, aciklama, dekont_basim_f,
                  borc_external_hesap,alacak_external_hesap, borc_vergi_no,alacak_vergi_no,prefix_istatistik_kodu, istatistik_kodu,charge_amount
                 ,islem_kod, instution_available_balance , remain_amount,instution_balance ,kurum_kodu  )
        values (pn_islem_no, pn_fromaccountno, ps_currencycode, ln_amount,
                   pn_toaccountno, ps_description, 'X',exacc_b,exacc_a,pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(pn_fromaccountno)),
                   pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(pn_toaccountno)),  ls_prefix_stat ,ls_istatistik_kodu,ln_charge_amount,
                   pn_islem_kod,pn_instution_available_bal , pn_remain_amount ,pn_instution_balance ,ps_instution_code      
                   );

       Pkg_tx6332.Batch_Muhasebelesme(pn_islem_no,pn_fis_no);
       if pn_islem_kod =6332 then 
            Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'Transfer is done for Institut.Cd:'||ps_instution_code ||',Journal No:'||pn_fis_no,pn_islem_no);
        else
             Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'Transfer is done.Journal No:'||pn_fis_no,pn_islem_no);        
        end if;
    commit;

  Exception
        WHEN OTHERS THEN
            if pn_islem_kod =6332 then 
                    Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5029'||Pkg_Hata.GetDelimiter||'No transfer is done.'||to_char(sqlcode)||'-' || to_char(sqlerrm)||',Institut.Cd:'||ps_instution_code||',Acct.No:'||pn_fromaccountno||',Available Balance:'|| To_char(pn_instution_available_bal, 'FM9999999999999999.99')||',Remain amount:'||To_char(pn_remain_amount, 'FM9999999999999999.99')||',Charge:'||To_char(ln_charge_amount, 'FM9999999999999999.99')||',Sales:'||To_char(ln_service_tax, 'FM9999999999999999.99')||',Transfer Amount:'||To_char(ln_amount, 'FM9999999999999999.99')||Pkg_Hata.GetDelimiter ||Pkg_Hata.GetUCPOINTER);
               else
                    Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,Pkg_Hata.GetUCPOINTER||'5029'||Pkg_Hata.GetDelimiter||to_char(sqlcode)||'-' || to_char(sqlerrm)||Pkg_Hata.GetDelimiter ||Pkg_Hata.GetUCPOINTER,pn_islem_no);
             end if;
         rollback;
    
END;
-------------------------------------------------------------------------------------------------------------------------
FUNCTION USIP_main_account_no_al RETURN number is
    ln_ret NUMBER;
BEGIN
    ln_ret := 0;

    select MAIN_ACCOUNT_NO
    into ln_ret
    from CBS_USIP_PARAMETER;

    RETURN ln_ret;
    Exception when others then return null;
END;
-------------------------------------------------------------------------------------------------------------------------
function usip_remain_amount_al return number is
    ln_ret NUMBER;
BEGIN
    ln_ret := 0;

    select REMAIN_AMOUNT
    into ln_ret
    from CBS_USIP_PARAMETER;

    RETURN ln_ret;
    Exception when others then return null;
END;
-------------------------------------------------------------------------------------------------------------------------
FUNCTION  sf_usip_durum_kodu_al(ps_durum_kodu varchar2 ) RETURN  varchar2 
 IS
  ls_adi varchar2(500);
 BEGIN
        SELECT aciklama
        INTO ls_adi
        FROM cbs_usip_durum_kodlari
        WHERE durum_kodu = ps_durum_kodu;

    RETURN     ls_adi ;

 EXCEPTION WHEN OTHERS THEN RETURN NULL;
 END;
 
 --B-O-M chyngyzo 09062014 cqdb00000728 KT_CALL_WS
/*******************************************************************************
    Name: KT_CALL_WS
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Makes web service call to KyrgyzTelecom
********************************************************************************/    
   PROCEDURE KT_CALL_WS (PN_TX_NO               NUMBER,
                         PN_OP                  VARCHAR2,
                         PN_QID                 NUMBER,
                         PN_SERVICE_ID          NUMBER,
                         PN_SUBSCRIBER_NO       NUMBER,
                         PN_SUM                 NUMBER,
                         PN_WS_SUM          OUT NUMBER,
                         PS_WS_STATUS       OUT VARCHAR2,
                         PS_WS_MSG          OUT VARCHAR2,
                         PS_ERROR           OUT VARCHAR2)
   IS
      PC_REF                     CBS.PKG_SOA_TRANSACTION.CURSORREFERENCETYPE;

      LS_SUPPLIER_ID             VARCHAR2 (100) := '555';
      LS_QM                      VARCHAR2 (100) := '';
      LS_SID                     VARCHAR2 (100) := 'DB';
      --LS_OP                  VARCHAR2 (100) := 'QE11'; -- QE11 - request  ,QE10 - payment

      LS_WS_RETURN               NUMBER;

      LS_STATUS                  VARCHAR2 (2000);
      LS_SUM                     VARCHAR2 (2000);
      LS_MSG                     VARCHAR2 (2000);
      LS_AGENT_ID                VARCHAR2 (10) := '0';

      LN_QID                     NUMBER;

      LS_STATU_EXPLANATION       VARCHAR2 (2000);

      LS_UCPOINTER               VARCHAR2 (3) := PKG_HATA.GETUCPOINTER;
      LS_DELIMITER               VARCHAR2 (3) := PKG_HATA.GETDELIMITER;


   BEGIN
      IF PN_QID IS NULL
      THEN
         LN_QID := PKG_GENEL.GENEL_KOD_AL ('6200_WS_REQID');
      ELSE
         LN_QID := PN_QID;
      END IF;

      Pkg_Parametre.deger('6200_KT_WS',LS_QM);

      LS_WS_RETURN :=
         PKG_SOA_TRANSACTION.MAKEKTWSREQUEST (PN_SUBSCRIBER_NO,
                                              PN_SERVICE_ID,
                                              LS_SUPPLIER_ID,
                                              LN_QID,
                                              LS_QM,
                                              LS_SID,
                                              PN_OP,
                                              PN_SUM,
                                              LS_AGENT_ID,
                                              PC_REF);

      LOOP
         FETCH PC_REF
         INTO LS_STATUS, LS_SUM, LS_MSG;

         EXIT WHEN PC_REF%NOTFOUND;
      END LOOP;

      PN_WS_SUM :=
         ABS (
            TO_NUMBER (TRIM (REPLACE (NVL (LS_SUM, '0'), '-')),
                       '9999999999999999.99'));


      PS_WS_MSG := LS_MSG;
      LS_STATU_EXPLANATION :=
         PKG_DIRECT_DEBIT.KT_STATU_CODE_EXPLANATION (LS_STATUS);
      PS_WS_STATUS := LS_STATUS || ' - ' || LS_STATU_EXPLANATION;

      pkg_tahsilat_islemleri.LOG_WS_REQUEST (PN_TX_NO,
                                 PN_OP,
                                 SYSDATE,
                                 LN_QID,
                                 LS_QM,
                                 PN_SERVICE_ID,
                                 PN_SUM,
                                 PN_SUBSCRIBER_NO,
                                 LS_STATUS,
                                 LS_STATU_EXPLANATION,
                                 PN_WS_SUM,
                                 PS_WS_MSG);

      PS_ERROR := 'N';

      IF LS_STATUS IN ('997', '998', '999')
      THEN
         PS_WS_MSG := '*** SERVICE ERROR ***';
         PN_WS_SUM := NULL;
         PS_ERROR := 'Y';
      END IF;

      IF LS_STATUS <> '200' AND LS_STATUS <> '250'
      THEN
         PS_WS_MSG := '*** SERVICE ERROR ***';
         PN_WS_SUM := NULL;
         PS_ERROR := 'Y';
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         LS_STATU_EXPLANATION :=
               SQLCODE
            || ' '
            || SUBSTR (SQLERRM, 1, 1500)
            || 'ls_Status:'
            || LS_STATUS
            || ',ls_Sum:'
            || LS_SUM
            || ',ls_Msg:'
            || LS_MSG;
         pkg_tahsilat_islemleri.LOG_WS_REQUEST (PN_TX_NO,
                                    PN_OP,
                                    SYSDATE,
                                    LN_QID,
                                    LS_QM,
                                    PN_SERVICE_ID,
                                    PN_SUM,
                                    PN_SUBSCRIBER_NO,
                                    -1,
                                    LS_STATU_EXPLANATION,
                                    PN_WS_SUM,
                                    PS_WS_MSG);

         RAISE_APPLICATION_ERROR (
            -20100,
               PKG_HATA.GETUCPOINTER
            || '6171'
            || PKG_HATA.GETDELIMITER
            || LS_STATU_EXPLANATION
            || PKG_HATA.GETDELIMITER
            || PKG_HATA.GETUCPOINTER);
   END;
--E-O-M chyngyzo 09062014 cqdb00000728 KT_CALL_WS

--B-O-M chyngyzo 09062014 cqdb00000728 LOG_WS_REQUEST
/*******************************************************************************
    Name: LOG_WS_REQUEST
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Logs each web service call to table CBS_KT_WS_LOG
********************************************************************************/      
   PROCEDURE LOG_WS_REQUEST (pn_TX_NO                        NUMBER,
                             ps_KT_OP                        VARCHAR2,
                             pd_KT_DTS                       DATE,
                             ps_KT_QID                       VARCHAR2,
                             ps_KT_QM                        VARCHAR2,
                             pn_KT_SERVICE_ID                NUMBER,
                             pn_KT_SUM_PAYMENT_AMOUNT        NUMBER,
                             ps_KT_PARAM1_PERSONAL_NUMBER    VARCHAR2,
                             ps_KT_STATUS                    VARCHAR2,
                             ps_KT_STATUS_EXPLANATION        VARCHAR2,
                             pn_KT_SUM_AMOUNT_RETURNED       NUMBER,
                             ps_KT_MSG                       VARCHAR2)
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      INSERT INTO CBS_KT_WS_LOG (TX_NO,
                                 OP,
                                 DTS,
                                 QID,
                                 QM,
                                 SERVICE_ID,
                                 SUM_AMOUNT,
                                 PARAM1_ACCOUNT,
                                 STATUS,
                                 STATUS_EXPLANATION,
                                 SUM_AMOUNT_RETURNED,
                                 MSG,
                                 BANKA_TARIHI)
           VALUES (pn_TX_NO,
                   ps_KT_OP,
                   pd_KT_DTS,
                   ps_KT_QID,
                   ps_KT_QM,
                   pn_KT_SERVICE_ID,
                   pn_KT_SUM_PAYMENT_AMOUNT,
                   ps_KT_PARAM1_PERSONAL_NUMBER,
                   ps_KT_STATUS,
                   ps_KT_STATUS_EXPLANATION,
                   pn_KT_SUM_AMOUNT_RETURNED,
                   ps_KT_MSG,
                   pkg_muhasebe.banka_tarihi_bul);

      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         log_at ('LOG_WS_REQUEST error:', pn_TX_NO ,SQLCODE, SQLERRM);
   END;
--E-O-M chyngyzo 09062014 cqdb00000728 LOG_WS_REQUEST


--B-O-M chyngyzo 09062014 cqdb00000728 GET_SERVICE_ID
/*******************************************************************************
    Name: GET_SERVICE_ID
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns service id of the given institution code
********************************************************************************/  
   FUNCTION GET_SERVICE_ID (
      ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE)
      RETURN VARCHAR2
   IS
      ln_service_id   CBS_TAHSILAT_KURUM_TANIM.SERVICE_ID%TYPE;
   BEGIN
      SELECT T.SERVICE_ID
        INTO ln_service_id
        FROM CBS_TAHSILAT_KURUM_TANIM T
       WHERE T.KURUM_KODU = ps_kurum_kodu;

      RETURN ln_service_id;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;
   
--E-O-M chyngyzo 09062014 cqdb00000728 GET_SERVICE_ID

--B-O-M chyngyzo 09062014 cqdb00000728 GET_KURUM_GRUP_KOD
/*******************************************************************************
    Name: GET_KURUM_GRUP_KOD
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns group code of the given institution code
********************************************************************************/    
   FUNCTION GET_KURUM_GRUP_KOD (
      ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE)
      RETURN VARCHAR2
   IS
      ln_kurum_grup_kod   CBS_TAHSILAT_KURUM_TANIM.KURUM_ALT_GRUP_KOD%TYPE;
   BEGIN
      SELECT T.KURUM_ALT_GRUP_KOD
        INTO ln_kurum_grup_kod
        FROM CBS_TAHSILAT_KURUM_TANIM T
       WHERE T.KURUM_KODU = ps_kurum_kodu;

      RETURN ln_kurum_grup_kod;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_KURUM_GRUP_KOD


--B-O-M chyngyzo 09062014 cqdb00000728 GET_PROVIDER_CODE
/*******************************************************************************
    Name: GET_PROVIDER_CODE
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns provider code of the given institution code
********************************************************************************/
   FUNCTION GET_PROVIDER_CODE (
      ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE)
      RETURN VARCHAR2
   IS
      ln_provider_code   CBS_TAHSILAT_KURUM_TANIM.PROVIDER_CODE%TYPE;
   BEGIN
      SELECT T.PROVIDER_CODE
        INTO ln_provider_code
        FROM CBS_TAHSILAT_KURUM_TANIM T
       WHERE T.KURUM_KODU = ps_kurum_kodu;

      RETURN ln_provider_code;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_PROVIDER_CODE

--B-O-M chyngyzo 09062014 cqdb00000728 GET_LAST_WS_CALL
/*******************************************************************************
    Name: LOG_WS_REQUEST
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns last retrieved data from QE11 web service
********************************************************************************/  
PROCEDURE GET_LAST_WS_CALL(pn_txno NUMBER, pn_subscriber_no CBS_CARI_NAKIT_YATAN.SUBSCRIBER_NO%TYPE, pn_name OUT CBS_KT_WS_LOG.MSG%TYPE, pn_sum OUT CBS_KT_WS_LOG.SUM_AMOUNT_RETURNED%TYPE, pn_status OUT VARCHAR2) 
 IS
 BEGIN
 
  select  L.MSG, L.SUM_AMOUNT_RETURNED, L.STATUS || ' - ' || L.STATUS_EXPLANATION into pn_name, pn_sum, pn_status  
  from (select MSG, SUM_AMOUNT_RETURNED, STATUS, STATUS_EXPLANATION  
            from cbs_kt_ws_log T 
            where T.tx_no = pn_txno and to_char(pn_subscriber_no) = T.PARAM1_ACCOUNT and  T.OP = 'QE11'
            order by dts desc) L 
  where rownum = 1;
    
    exception
    when others then
        pn_name := null;
        pn_sum := null;
        pn_status := null;
 END;
 
 --E-O-M chyngyzo 09062014 cqdb00000728 GET_LAST_WS_CALL

--B-O-M AdiletK 30122014 CQ1236 Overdraft Interest Payment
/*******************************************************************************
    Name: Overdraft_Interest_Payment 
    Author: Adilet Kachkeev
    Modify Date: 30.12.2014
    
    Desc: Payment of Overdraft Interest when the account receives monetary inflows
********************************************************************************/                                                                   
PROCEDURE Overdraft_Interest_Payment (pn_islem_no NUMBER) IS
 varchar_list               pkg_muhasebe.varchar_array;
 number_list                   pkg_muhasebe.number_array;
 date_list                   pkg_muhasebe.date_array;
 boolean_list               pkg_muhasebe.boolean_array;

 CURSOR c_credited_cust IS
 SELECT s.hesap_numara,  -- list of accounts with balance inflow
        s.hesap_bolum_kodu, 
        h.urun_tur_kod, 
        h.urun_sinif_kod, 
        h.modul_tur_kod
 FROM cbs_satir s, cbs_hesap h
 WHERE s.fis_islem_numara = pn_islem_no and
             s.hesap_tur_kodu = 'VS' and
             s.tur = 'A' and
             s.hesap_numara = h.hesap_no and
             nvl(h.ovd_total_acc_interest,0) > 0 and 
             trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) > 0;
 r_credited_cust  c_credited_cust%ROWTYPE;

 CURSOR c_atm_tran IS 
 SELECT referance,
             terminal_id
 FROM cbs_atm_finansal_islem
 WHERE tx_no = pn_islem_no;
 r_atm_tran  c_atm_tran%ROWTYPE;

 p_5213_HESAP_SUBE NUMBER;
 p_5213_VADESIZ_HESAP NUMBER;
 p_5213_REFERANS NUMBER;
 p_5213_DOVIZ_KODU NUMBER;
 p_5213_VERGI_ACIKLAMA NUMBER;
 p_5213_FAIZ_ACIKLAMA NUMBER;
 p_5213_KUR    NUMBER;
 p_5213_IS_BALANCE_POSITIVE  NUMBER;
 p_5213_INTEREST_GL  NUMBER;
 p_5213_INTEREST_OVER_LIMIT_LC NUMBER;
 p_5213_INTEREST_OVER_LIMIT_FC NUMBER;
 p_5213_TAX_OVER_LIMIT_LC NUMBER;
 p_5213_TAX_OVER_LIMIT_FC NUMBER;
 ln_islem_no  NUMBER;
 ln_islem_kod NUMBER := 5213;
 pn_islem_kod NUMBER;
 ln_balance   NUMBER;
 ls_interest_dk varchar2(30);
 ln_rate_sales_tax NUMBER := 0;
 ln_total_interest NUMBER;
 ln_musteri_no NUMBER;
 ln_fis_no NUMBER; 
 ln_hesap_no NUMBER;
 ls_doviz_kod VARCHAR2(3);
 ln_dk_grup_kod CBS_MUSTERI.DK_GRUP_KOD%TYPE;
 ls_modul_tur_kod VARCHAR2(10);
 ls_urun_tur_kod VARCHAR2(10);
 ls_urun_sinif_kod VARCHAR2(20);
--B-O-M CQ4646 AdiletK Overdraft Tx_no creation for IB and ATM transactions
 ln_rol NUMBER:=7777;
 ln_tutar NUMBER;
 ln_kasa_kod NUMBER;
 ls_bolum_kodu VARCHAR2(3);
 ls_amir_bolum_kodu VARCHAR(3);
 ln_kanal_numara       NUMBER:=1; 
 ls_atm_not_process VARCHAR2(300);
BEGIN

  SELECT islem_kod
  INTO pn_islem_kod
  FROM cbs_islem
  WHERE numara = pn_islem_no;  
  
  pkg_parametre.deger('OVERDRAFT_NOT_PROC_ATM', ls_atm_not_process);   
  IF INSTR(to_char(ls_atm_not_process), to_char(pn_islem_kod)) = 0 THEN
    --E-O-M CQ4646 AdiletK Overdraft Tx_no creation for IB and ATM transactions
     p_5213_HESAP_SUBE := Pkg_Muhasebe.parametre_index_bul('5213_HESAP_SUBE');
     p_5213_VADESIZ_HESAP := Pkg_Muhasebe.parametre_index_bul('5213_VADESIZ_HESAP');
     p_5213_REFERANS := Pkg_Muhasebe.parametre_index_bul('5213_REFERANS');
     p_5213_DOVIZ_KODU := Pkg_Muhasebe.parametre_index_bul('5213_DOVIZ_KODU');
     p_5213_VERGI_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_VERGI_ACIKLAMA');
     p_5213_FAIZ_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_FAIZ_ACIKLAMA');
     p_5213_KUR  := Pkg_Muhasebe.parametre_index_bul('5213_KUR');
     p_5213_IS_BALANCE_POSITIVE  := Pkg_Muhasebe.parametre_index_bul('5213_IS_BALANCE_POSITIVE');
     p_5213_INTEREST_GL  := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_GL');
     p_5213_INTEREST_OVER_LIMIT_LC := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_OVER_LIMIT_LC');
     p_5213_INTEREST_OVER_LIMIT_FC := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_OVER_LIMIT_FC');
     p_5213_TAX_OVER_LIMIT_LC := Pkg_Muhasebe.parametre_index_bul('5213_TAX_OVER_LIMIT_LC');
     p_5213_TAX_OVER_LIMIT_FC := Pkg_Muhasebe.parametre_index_bul('5213_TAX_OVER_LIMIT_FC');
     
     varchar_list(p_5213_HESAP_SUBE) := '';
     varchar_list(p_5213_VADESIZ_HESAP) := '';
     varchar_list(p_5213_REFERANS) := '';
     varchar_list(p_5213_DOVIZ_KODU) := '';
     varchar_list(p_5213_VERGI_ACIKLAMA) := '';
     varchar_list(p_5213_FAIZ_ACIKLAMA) := '';
     number_list(p_5213_KUR) := 0;
     boolean_list(p_5213_IS_BALANCE_POSITIVE) := FALSE;
     varchar_list(p_5213_INTEREST_GL) := '';
     number_list(p_5213_INTEREST_OVER_LIMIT_LC) := 0;
     number_list(p_5213_INTEREST_OVER_LIMIT_FC) := 0;
     number_list(p_5213_TAX_OVER_LIMIT_LC) := 0;
     number_list(p_5213_TAX_OVER_LIMIT_FC) := 0;
     pkg_parametre.deger('G_SALES_TAX_RATE', ln_rate_sales_tax);
     
     -- goes through accounts with replishment and debt to accrual GL
     OPEN c_credited_cust;
     LOOP
      FETCH c_credited_cust INTO r_credited_cust;
      EXIT WHEN c_credited_cust%NOTFOUND; 
      ln_fis_no:=NULL;
      ln_islem_no:=NULL;

      SELECT musteri_no, doviz_kodu, nvl(ovd_total_acc_interest, 0)
      INTO ln_musteri_no, ls_doviz_kod, ln_total_interest
      FROM cbs_hesap
      WHERE hesap_no = to_number(r_credited_cust.hesap_numara); 

    --B-O-M- CQ4646 AdiletK Overdraft Tx_no creation for IB and ATM transactions
      IF pkg_baglam.kullanici_kodu is null and INSTR(to_char(pn_islem_kod), '88') = 0 THEN -- tx creation for IB transaction
        ln_islem_no:=Pkg_Tx.islem_no_al;
        ls_bolum_kodu := r_credited_cust.hesap_bolum_kodu;
        ls_amir_bolum_kodu := r_credited_cust.hesap_bolum_kodu;
        ls_modul_tur_kod := r_credited_cust.modul_tur_kod;
        ls_urun_tur_kod := r_credited_cust.urun_tur_kod;
        ls_urun_sinif_kod := r_credited_cust.urun_sinif_kod;
        Pkg_Int_Api.create_transaction (ln_islem_no, ln_islem_kod,
                                   ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod,
                                   ln_tutar,ls_amir_bolum_kodu, ls_bolum_kodu,ln_rol,
                                   ls_doviz_kod, ln_musteri_no,r_credited_cust.hesap_numara,
                                   ln_kasa_kod,ln_kanal_numara);    
      ELSIF INSTR(to_char(pn_islem_kod), '88') <> 0 THEN -- tx creation for ATM transaction
        ln_islem_no:=Pkg_Tx.islem_no_al;
        ln_rol := pkg_atm.kanal_rol;
        ln_kanal_numara := pkg_atm.kanal_numara;
        ls_bolum_kodu := r_credited_cust.hesap_bolum_kodu;
        ls_amir_bolum_kodu := r_credited_cust.hesap_bolum_kodu;
        ls_modul_tur_kod := r_credited_cust.modul_tur_kod;
        ls_urun_tur_kod := r_credited_cust.urun_tur_kod;
        ls_urun_sinif_kod := r_credited_cust.urun_sinif_kod;
        OPEN c_atm_tran;
        FETCH c_atm_tran INTO r_atm_tran;
        pkg_atm_api.create_transaction (ln_islem_no, ln_islem_kod, ls_modul_tur_kod,
                                     ls_urun_tur_kod, ls_urun_sinif_kod, ln_tutar, ls_amir_bolum_kodu,
                                     ls_bolum_kodu, ln_rol, ls_doviz_kod, ln_musteri_no, r_credited_cust.hesap_numara, 
                                     ln_kasa_kod, ln_kanal_numara, nvl(r_atm_tran.terminal_id, ''), nvl(r_atm_tran.referance, ''));    
        CLOSE c_atm_tran;
      ELSE -- tx creation for CBS transaction
        ln_islem_no:=Pkg_Batch.Islem_Yarat(ln_islem_kod,r_credited_cust.hesap_bolum_kodu);
      END IF;
    --E-O-M- CQ4646 AdiletK Overdraft Tx_no creation for IB and ATM transactions
    -- get interest debt to accrual GL
      IF ln_total_interest > 0 THEN -- if there is overdraft debt on the account
        ln_balance := trunc(pkg_hesap.kullanilabilir_bakiye_al(to_number(r_credited_cust.hesap_numara)),2);

        number_list(p_5213_INTEREST_OVER_LIMIT_FC) := ROUND(ln_total_interest, 2);
        number_list(p_5213_TAX_OVER_LIMIT_FC) := ROUND(((ln_total_interest*ln_rate_sales_tax)/100),2);
        IF ln_balance > 0 and ln_balance < (number_list(p_5213_INTEREST_OVER_LIMIT_FC)+number_list(p_5213_TAX_OVER_LIMIT_FC)) THEN
             -- can repay only partial amount of interest and tax
             boolean_list(p_5213_IS_BALANCE_POSITIVE) := TRUE;
             -- split the available balance between interest and tax amounts
             number_list(p_5213_INTEREST_OVER_LIMIT_FC) := ROUND(((ln_balance*100)/(100+ln_rate_sales_tax)),2);
             number_list(p_5213_INTEREST_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(ls_doviz_kod,pkg_genel.LC_AL,NULL,number_list(p_5213_INTEREST_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
             number_list(p_5213_TAX_OVER_LIMIT_FC) := ROUND((ln_balance - number_list(p_5213_INTEREST_OVER_LIMIT_FC)),2);
             number_list(p_5213_TAX_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(ls_doviz_kod,pkg_genel.LC_AL,NULL,number_list(p_5213_TAX_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
        ELSIF ln_balance > 0 THEN
            -- can repay full interest and tax amounts
            boolean_list(p_5213_IS_BALANCE_POSITIVE) := TRUE;
            number_list(p_5213_INTEREST_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(ls_doviz_kod,pkg_genel.LC_AL,NULL,number_list(p_5213_INTEREST_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
            number_list(p_5213_TAX_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(ls_doviz_kod,pkg_genel.LC_AL,NULL,number_list(p_5213_TAX_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
        END IF;
        varchar_list(p_5213_HESAP_SUBE) := r_credited_cust.hesap_bolum_kodu;
        varchar_list(p_5213_VADESIZ_HESAP) := r_credited_cust.hesap_numara;
        varchar_list(p_5213_REFERANS) := r_credited_cust.hesap_numara;
        varchar_list(p_5213_DOVIZ_KODU) := ls_doviz_kod;
        varchar_list(p_5213_VERGI_ACIKLAMA) := r_credited_cust.hesap_numara ||' '||'account sales tax of overdraft interest';
        varchar_list(p_5213_FAIZ_ACIKLAMA) := r_credited_cust.hesap_numara ||' '||'account Overdraft Interest Payment';
        number_list(p_5213_KUR) := pkg_kur.doviz_doviz_karsilik(ls_doviz_kod,pkg_genel.LC_AL,NULL,1,1,NULL,NULL,'N','A');
      END IF;

      SELECT dk_grup_kod
      INTO ln_dk_grup_kod
      FROM cbs_musteri
      WHERE musteri_no = ln_musteri_no;

      -- find the accrual GL
      Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_credited_cust.modul_tur_kod, r_credited_cust.urun_tur_kod, r_credited_cust.urun_sinif_kod, 8, NULL, NULL, NULL,ls_interest_dk);
      varchar_list(p_5213_INTEREST_GL) := ls_interest_dk;

       ln_fis_no:=Pkg_Muhasebe.fis_kes (ln_islem_kod,
                8,
                ln_islem_no,
                varchar_list,
                number_list,
                date_list,
                boolean_list,
                NULL,
                FALSE,
                NVL(ln_fis_no,0),
                'Overdraft Interest Payment');  

       IF boolean_list(p_5213_IS_BALANCE_POSITIVE) = TRUE THEN
          -- set updated interest debt to accrual GL
          UPDATE cbs_hesap
          SET ovd_total_acc_interest = ovd_total_acc_interest - number_list(p_5213_INTEREST_OVER_LIMIT_FC)
          WHERE hesap_no =  r_credited_cust.hesap_numara;
       END IF;
      pkg_muhasebe.muhasebelestir(ln_fis_no);
       update cbs_islem
       set durum = 'N',
            tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
       where numara=ln_islem_no;  
     END LOOP;
     CLOSE c_credited_cust;
  END IF;
 
 EXCEPTION
 WHEN OTHERS THEN
   log_at('overdraft_int', TO_CHAR(SQLCODE), SQLERRM);
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4666' ||  Pkg_Hata.getdelimiter|| r_credited_cust.hesap_numara || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
--E-O-M AdiletK 30122014 CQ1236 Overdraft Interest Payment


--BOM aisuluud CQ4883 TemirlanT cbs-119
PROCEDURE PASTDUE_CLOSING_PAYMENT (pn_islem_no NUMBER) IS

 ln_current_account number;
 ln_tx_amount number;
 ln_available_amount number;
 ln_remaining_avail_balance number;
 ln_amount number;
 
 ld_date DATE := to_date('04062013','DDMMYYYY');
 ls_past_due_currency cbs_hesap_kredi.doviz_kodu%type;
 ln_pd_account_no number;
 ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
 ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
 ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
 ln_gecenyil_faiz_tutari number; 
 ln_gecmis_aylarin_faizi number; 
 ln_birikmis_faiz_tutari number;
 ln_pd_balance number;
 ls_pd_branch_cd cbs_hesap_kredi_islem.sube_kodu%type;
 ls_son_gun_faizi cbs_hesap_kredi_islem.son_gun_faizi%type;
 ln_faiz_tutari number;
 ln_komisyon_tutari number;
 ln_toplam_faiz number;
 ld_value_date CBS_HESAP_KREDI_ISLEM.VALOR_TARIHI%TYPE;
 ls_collection_currency CBS_HESAP_KREDI_ISLEM.TAHSIL_HESAP_DOVIZ%TYPE;
 ln_rate number;
 ln_related_account number;
 ln_collection_account number;
 ln_anapara_tahsilat_tutar number;
 ls_choice cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
 ls_durum_kodu cbs_hesap_kredi_islem.durum_kodu%type;  
 ln_tahsedil_gecenyilfaiztutar cbs_hesap_kredi_islem.tahsedil_gecenyil_faiz_tutari%type;
 ln_tahsedil_gecmis_aylar_faiz cbs_hesap_kredi_islem.tahsedil_gecmis_aylar_faiz%type;
 ln_tahsedil_birikmisfaiztutar cbs_hesap_kredi_islem.tahsedil_birikmis_faiz_tutari%type;
 ls_aciklama cbs_hesap_kredi_islem.aciklama%type;
 ln_musteri_no number;
 ls_account_currency cbs_hesap.doviz_kodu%type;
 ln_pd_tax_balance number;
 ln_pd_interest_balance number;
 
 ln_tax_last_year number;
 ln_tax_last_month number;
 ln_tax_cumulated number;
 ln_tax_rate number;
 ln_tax_rate_last_year number;
 ln_toplam_tax number;
 
 ls_cash_account CBS_MASRAF_KOM_TAHSIL_ISL.CASH_ACCOUNT%type;
 ls_currency_code CBS_MASRAF_KOM_TAHSIL_ISL.DVZ%type;
 ln_customer_no CBS_MASRAF_KOM_TAHSIL_ISL.MUSTERI_NO%type;
 ls_residency_code CBS_MASRAF_KOM_TAHSIL_ISL.RESIDENCY_CODE%type;
 ls_citizen_code CBS_MASRAF_KOM_TAHSIL_ISL.CITIZEN_CODE%type;
 ls_customer_type CBS_MASRAF_KOM_TAHSIL_ISL.CUSTOMER_TYPE%type;
 ls_income_type CBS_MASRAF_KOM_TAHSIL_ISL.GELIR_ACIKLAMA%type;
 ln_related_account_penalty CBS_MASRAF_KOM_TAHSIL_ISL.ILISKILI_HESAP_NO%type;
 ln_amount_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_TUTARI%type;
 ls_vat CBS_MASRAF_KOM_TAHSIL_ISL.VAT%type;
 ls_service_tax CBS_MASRAF_KOM_TAHSIL_ISL.SERVICE_TAX%type;
 ln_service_tax_rate CBS_MASRAF_KOM_TAHSIL_ISL.SERVICE_TAX_RATE%type;
 ls_tax_coll_type CBS_MASRAF_KOM_TAHSIL_ISL.TAX_COLL_TYPE%type;
 ln_paid_tax_amount CBS_MASRAF_KOM_TAHSIL_ISL.PAID_TAX_AMOUNT%type;
 ln_total_collection_amount CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_TOPLAM_TUTAR%type;
 ls_collection_currency_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_DVZ_KOD%type;
 ln_rate_penalty CBS_MASRAF_KOM_TAHSIL_ISL.KUR%type;
 ln_collection_account_penalty CBS_MASRAF_KOM_TAHSIL_ISL.TAHSIL_HESAP_NO%type;
 ls_income_gl CBS_MASRAF_KOM_TAHSIL_ISL.INCOME_GL%type;
 ls_explanation CBS_MASRAF_KOM_TAHSIL_ISL.ACIKLAMA%type;
 ls_name_surname CBS_MUSTERI.ARAMA_ISIM%type;                   --TemirlanT
 ls_day  cbs_hesap_kredi_islem.aciklama%type;                   --TemirlanT
 ln_loan_account CBS_HESAP_KREDI.HESAP_NO%type;                 --TemirlanT
 ls_dk_explanation CBS_DKHESAP.ACIKLAMA%type;                   --TemirlanT
 ls_sector_explanation CBS_DKHESAP.ACIKLAMA%type;               --TemirlanT
 ls_month_explanation varchar2(20);                             --TemirlanT
 ln_count_related_account_pd number;                            --TemirlanT
 ln_general_balance number := 0;                                --TemirlanT
 ln_general_balance_1 number;                                   --TemirlanT
 ln_general_balance_2 number;                                   --TemirlanT
 ls_part varchar2(10);                                          --TemirlanT
 ln_count_a boolean := false;                                   --TemirlanT
 ln_count_b boolean := false;                                   --TemirlanT
 ln_overdraft_mi CBS_HESAP.OVERDRAFT%type;                      --TemirlanT
 ln_toplam_faiz_tim number;                                     --TemirlanT
 ln_delayed_days number;
 ls_account_branch cbs_hesap.sube_kodu%type;
 ln_alis_tutari number;
 ln_current_account_2 cbs_hesap.hesap_no%type;
 
 ln_alter_current_account CBS_HESAP.HESAP_NO%type;
 
 ln_related_account_pen_curr number;
 lb_buy_loan_currency boolean := false;
 ln_faizler number;
 ln_arbitraj_account_amount number;
 lb_bought_amount boolean;
 ln_converted_acc_amount number;
 ln_acc_amount_before number;
 
 ln_loan_related_account CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ln_gon_block_count number;
 ln_non_gon_block number;
 ln_any_block number;
 ln_related_account_pd CBS_HESAP_KREDI.ILISKILI_HESAP_NO%type;
 ----rahat
 lb_block boolean;
 ln_bloke_tutari_sum number;
 ln_bakiye CBS_HESAP_BAKIYE.bakiye%TYPE;
 ln_block_sum number;
 ln_difference_amount number;
 -------------------------------------------------------------
 
 CURSOR c_credited_cust IS
 SELECT s.hesap_numara,  -- list of accounts with balance inflow
        s.hesap_bolum_kodu, 
        s.dv_tutar,
        h.urun_tur_kod, 
        h.urun_sinif_kod, 
        h.modul_tur_kod,
        h.doviz_kodu,
        h.sube_kodu,
        h.musteri_no,
        trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) available_balance,
        pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','A', h.sube_kodu ) buying_amount,
        pkg_kur.doviz_doviz_karsilik(h.doviz_kodu,pkg_genel.lc_al,null,trunc(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),2),1,null,null,'O','S',  h.sube_kodu) selling_amount
 FROM cbs_satir s, cbs_hesap h
 WHERE s.fis_islem_numara = pn_islem_no 
            and s.hesap_tur_kodu = 'VS' 
            and s.tur = 'A' 
            and s.hesap_numara = to_char(h.hesap_no)
            and pkg_musteri.Report_Customer_Type(h.musteri_no) in (1, 2) --retail, sme
            --and S.DOVIZ_KOD in ('KGS','USD') 
            --and trunc(pkg_hesap.kullanilabilir_bakiye_al(h.hesap_no),2) > 0
            and (pkg_muhasebe.banka_tarihi_bul - (select min(k.acilis_tarihi) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') 
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null)) < 90
            and ((select count(*) from   cbs_hesap_kredi k
                where K.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)
                and K.durum_kodu='A'
                and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') 
                and k.urun_sinif_kod not in ('CRD.CARD-LC')
                and K.pastdue_faiz_anapara_sec is not null) > 0 
            or (select count(*)
                from cbs_hesap_kredi k 
                where  k.penalty_amount > 0
                and k.musteri_no= pkg_hesap.HesaptanMusteriNoAl(s.hesap_numara)) > 0);                         
 r_credited_cust  c_credited_cust%ROWTYPE;
 --BOM TemirlanT
 CURSOR c_credited_count IS
 select hesap_no,iliskili_hesap_no, doviz_kodu
                into ln_loan_account,ln_related_account, ls_past_due_currency
                from cbs_hesap_kredi k1
                where k1.ana_kredi_hesap_no is null
                and k1.musteri_no = ln_musteri_no
                --and k1.durum_kodu='A'
                and k1.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
                and pkg_hesap.HesaptanDurumAl(k1.iliskili_hesap_no) = 'A' 
                and (select count(*) from cbs_hesap_kredi where ana_kredi_hesap_no=k1.hesap_no and durum_kodu='A')>0;
 r_credited_count  c_credited_count%ROWTYPE;
 --EOM TemirlanT
 CURSOR cur_anapara_pd_before_2013 IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance , 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k 
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'  
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') 
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no 
        and abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_anapara_pd_before_2013  cur_anapara_pd_before_2013%ROWTYPE;  
 
 CURSOR cur_faiz_pd_before_2013 IS
        select * from (
            --only faiz     
            select K.MUSTERI_NO,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount ,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')    
            and KK.HESAP_NO is null   
            union all
            --only tax
            select k.musteri_no, K.ACILIS_TARIHI, kk.doviz_kodu, kk.hesap_no, kk.modul_tur_kod, Kk.URUN_TUR_KOD, Kk.URUN_SINIF_KOD, kk.GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu, Kk.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_faiz_amount ,
            k.doviz_kodu tax_doviz_kodu, k.hesap_no tax_hesap_no, k.modul_tur_kod tax_modul_tur_kod, k.URUN_TUR_KOD tax_URUN_TUR_KOD, k.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    k.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, k.sube_kodu tax_sube_kodu, k.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_tax_amount ,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')    
            and KK.HESAP_NO is null
            union all
            --both faiz and tax
            select k.musteri_no,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount ,
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC') ) k  
            where k.musteri_no=ln_musteri_no 
            and k.ana_hesap_acilis < ld_date
            --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
            and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
            order by K.ACILIS_TARIHI, k.ana_hesap_acilis;  
              
 r_faiz_pd_before_2013  cur_faiz_pd_before_2013%ROWTYPE;
 
 CURSOR cur_def_int_before_2013_pd IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance , 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k 
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'  
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') 
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no 
        and (abs(nvl(K.GECENYIL_FAIZ_TUTARI,0)) >0 or abs(nvl(K.GECMIS_AYLARIN_FAIZI,0)) > 0 or abs(nvl(K.BIRIKMIS_FAIZ_TUTARI,0)) > 0)
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_def_int_before_2013_pd  cur_def_int_before_2013_pd%ROWTYPE;
 
 CURSOR cur_penalty_pd_before_2013 IS
        select k.*, 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis 
        from cbs_hesap_kredi k 
        where K.MUSTERI_NO = ln_musteri_no
        and K.PENALTY_AMOUNT > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) < ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_penalty_pd_before_2013  cur_penalty_pd_before_2013%ROWTYPE;
 
 
 CURSOR cur_anapara_pd_after_2013 IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance , 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k 
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'  
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') 
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no 
        and abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_anapara_pd_after_2013  cur_anapara_pd_after_2013%ROWTYPE;  
 
 CURSOR cur_faiz_pd_after_2013 IS
        select * from (
            --only faiz     
            select K.MUSTERI_NO,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount ,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')    
            and KK.HESAP_NO is null   
            union all
            --only tax
            select k.musteri_no, K.ACILIS_TARIHI, kk.doviz_kodu, kk.hesap_no, kk.modul_tur_kod, Kk.URUN_TUR_KOD, Kk.URUN_SINIF_KOD, kk.GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu, Kk.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_faiz_amount ,
            k.doviz_kodu tax_doviz_kodu, k.hesap_no tax_hesap_no, k.modul_tur_kod tax_modul_tur_kod, k.URUN_TUR_KOD tax_URUN_TUR_KOD, k.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    k.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, k.sube_kodu tax_sube_kodu, k.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            left join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC')    
            and KK.HESAP_NO is null
            union all
            --both faiz and tax
            select k.musteri_no,  K.ACILIS_TARIHI,k.doviz_kodu, k.hesap_no, k.modul_tur_kod, K.URUN_TUR_KOD, K.URUN_SINIF_KOD, k.GECENYIL_FAIZ_TUTARI, k.GECMIS_AYLARIN_FAIZI, k.BIRIKMIS_FAIZ_TUTARI, k.sube_kodu, K.SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_faiz_amount,
                    kk.doviz_kodu tax_doviz_kodu, kk.hesap_no tax_hesap_no, kk.modul_tur_kod tax_modul_tur_kod, kk.URUN_TUR_KOD tax_URUN_TUR_KOD, kk.URUN_SINIF_KOD tax_URUN_SINIF_KOD, 
                    kk.GECENYIL_FAIZ_TUTARI tax_GECENYIL_FAIZ_TUTARI, kk.GECMIS_AYLARIN_FAIZI tax_GECMIS_AYLARIN_FAIZI, kk.BIRIKMIS_FAIZ_TUTARI tax_BIRIKMIS_FAIZ_TUTARI, kk.sube_kodu tax_sube_kodu, kk.SON_GUN_FAIZI tax_SON_GUN_FAIZI,
                    abs(pkg_hesap.Kullanilabilir_Bakiye_Al(kk.hesap_no)) pd_tax_amount, kk.ANA_KREDI_HESAP_NO,  -- TemirlanT cbs-119
                    (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
            from cbs_hesap_kredi k 
            join cbs_hesap_kredi kk on KK.ACILIS_TARIHI=K.ACILIS_TARIHI and KK.PASTDUE_FAIZ_ANAPARA_SEC='TAX' and KK.ANA_KREDI_HESAP_NO=K.ANA_KREDI_HESAP_NO and KK.DURUM_KODU='A'
            where K.PASTDUE_FAIZ_ANAPARA_SEC='FAIZ' and k.durum_kodu='A' and k.urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD') and k.urun_sinif_kod not in ('CRD.CARD-LC') ) k  
            where k.musteri_no=ln_musteri_no 
            and k.ana_hesap_acilis >= ld_date
            --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
            and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
            order by K.ACILIS_TARIHI, k.ana_hesap_acilis;  
              
 r_faiz_pd_after_2013  cur_faiz_pd_after_2013%ROWTYPE;
 
 CURSOR cur_def_int_after_2013_pd IS
        select k.*, abs(pkg_hesap.Kullanilabilir_Bakiye_Al(k.hesap_no)) pd_balance , 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis
        from CBS_HESAP_KREDI k 
        where K.PASTDUE_FAIZ_ANAPARA_SEC ='ANAPARA'
        and K.DURUM_KODU='A'  
        and urun_tur_kod not in ('PD-CARD', 'RT-CARD', 'CRD.CARD')
        and urun_sinif_kod not in ('CRD.CARD-LC')
        and musteri_no=ln_musteri_no 
        and (abs(nvl(K.GECENYIL_FAIZ_TUTARI,0)) >0 or abs(nvl(K.GECMIS_AYLARIN_FAIZI,0)) > 0 or abs(nvl(K.BIRIKMIS_FAIZ_TUTARI,0)) > 0)
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_def_int_after_2013_pd  cur_def_int_after_2013_pd%ROWTYPE;
 
 CURSOR cur_penalty_pd_after_2013 IS
        select k.*, 
        (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_hesap_acilis,
        (select K1.MUSTERI_DK_NO from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) ana_dk_no
        from cbs_hesap_kredi k 
        where K.MUSTERI_NO = ln_musteri_no
        and K.PENALTY_AMOUNT > 0
        and (select K1.ACILIS_TARIHI from cbs_hesap_kredi k1 where K1.HESAP_NO=K.ANA_KREDI_HESAP_NO) >= ld_date
        --and  trunc(sysdate) - K.ACILIS_TARIHI < 90
        and pkg_muhasebe.banka_tarihi_bul - K.ACILIS_TARIHI < 90
        order by K.ACILIS_TARIHI, ana_hesap_acilis;        
 r_penalty_pd_after_2013  cur_penalty_pd_after_2013%ROWTYPE;
 
 cursor c_block is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu in ('7','10') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
    and hesap_no = ln_current_account;
    
 r_block c_block%ROWTYPE;
 
 cursor rel_acc_block is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu in ('7','10') and b.durum_kodu = 'A' and B.BLOKE_TUTARI > 0
    and hesap_no = ln_related_account;
                    
    r_acc_block rel_acc_block%ROWTYPE;


BEGIN

    pkg_parametre.deger('BAT_1_NEW_LOGIC_PAST_DUE',ld_date);
    pkg_parametre.deger('G_PD_PART_EXPLANATION',ls_part);  -- cbs-119 TemirlanT
 
    OPEN c_credited_cust;
 LOOP
    FETCH c_credited_cust INTO r_credited_cust;
    EXIT WHEN c_credited_cust%NOTFOUND; 
  
    ln_current_account := r_credited_cust.hesap_numara;
    ls_account_currency := r_credited_cust.doviz_kodu;
    ls_account_branch := r_credited_cust.sube_kodu;
    ln_musteri_no := r_credited_cust.musteri_no;
    ln_tx_amount := r_credited_cust.dv_tutar;
    ls_name_surname := pkg_musteri.sf_musteri_adi(ln_musteri_no);         -- cbs-119 TemirlanT
    select overdraft into ln_overdraft_mi from cbs_hesap where hesap_no=ln_current_account;
    --if ln_overdraft_mi='H' then
        begin    
            begin    
                select count(*) 
                into ln_non_gon_block 
                from cbs_bloke b
                where b.bloke_neden_kodu not in('7','10') 
                and b.durum_kodu = 'A' 
                and B.BLOKE_TUTARI > 0
                and hesap_no = ln_current_account;
            exception when no_data_found then
                ln_non_gon_block := 0;
            end;
    
            begin
                select count(*) 
                into ln_gon_block_count 
                from cbs_bloke b
                where b.bloke_neden_kodu in('7','10')
                and b.durum_kodu = 'A' 
                and B.BLOKE_TUTARI > 0
                and hesap_no = ln_current_account;
            exception when no_data_found then
                ln_gon_block_count := 0;
            end;
            
            if ln_non_gon_block > 0 then
        
                ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2);
                begin         
                    select sum(bloke_tutari)
                    into ln_block_sum
                    from cbs_bloke b
                    where b.bloke_neden_kodu not in ('10', '7')
                    and b.durum_kodu = 'A' 
                    and B.BLOKE_TUTARI > 0
                    and hesap_no = ln_current_account;
                exception when no_data_found then
                    ln_block_sum := 0; 
                end;
                if ln_bakiye > ln_block_sum then      
                    if ln_gon_block_count > 0 then
                        OPEN c_block;
                        LOOP
                            FETCH c_block INTO r_block;
                            EXIT WHEN c_block%NOTFOUND;  
                            begin
                                if r_block.bloke_neden_kodu = '7' then
                                    Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'7',
                                                          ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                           
                                elsif r_block.bloke_neden_kodu = '10' then
                        
                                    Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'10',
                                                          ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                                end if;
                                                                              
                                commit;
                            exception
                                when others then
                                log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                            end;
                        END LOOP;
                        CLOSE c_block;
                    end if;
                end if;
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2) - ln_block_sum; --TemirlanT
        
            elsif ln_gon_block_count > 0 then
                OPEN c_block;
                LOOP
                    FETCH c_block INTO r_block;
                    EXIT WHEN c_block%NOTFOUND;
                    begin
                        if r_block.bloke_neden_kodu = '7' then
                            Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                      r_block.musteri_no,
                                                      r_block.hesap_no,
                                                      r_block.doviz_kodu,
                                                      pn_BLOKE_TUTARI=>0,
                                                      ps_BLOKE_NEDEN_KODU=>'7',
                                                      ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                      PS_KAPAMA   => 'KAPAMA');
                        elsif r_block.bloke_neden_kodu = '10' then
                            Pkg_Bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                      r_block.musteri_no,
                                                      r_block.hesap_no,
                                                      r_block.doviz_kodu,
                                                      pn_BLOKE_TUTARI=>0,
                                                      ps_BLOKE_NEDEN_KODU=>'10',
                                                      ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                      PS_KAPAMA   => 'KAPAMA');
                        end if;
                                                                          
                        commit;
                    exception
                        when others then
                        log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                    end;
                END LOOP;
                CLOSE c_block;  
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2); 
            else
                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_current_account),2);
        
            end if;

        end;
  
  
        log_at('cbs-timka_pd',1,1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
        --BOM TemirlanT timka
        begin
            log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
            if ln_available_amount>0 then    
                OPEN c_credited_count;
                LOOP
                    FETCH c_credited_count INTO r_credited_count;
                    EXIT WHEN c_credited_count%NOTFOUND;
                    --c_credited_count
                    --WHILE ln_count_a < ln_count_related_account_pd LOOP
                    ln_loan_account := r_credited_count.hesap_no;
                    ln_related_account := r_credited_count.iliskili_hesap_no;
                    ls_past_due_currency := r_credited_count.doviz_kodu;
                    if ln_current_account <> ln_related_account then
                        ln_count_a := true;
                    end if;
                    select sum(abs(pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)))
                    into ln_general_balance_1
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90;
                    log_at('cbs-timka_pd',1,5,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    select sum(nvl(abs(GECENYIL_FAIZ_TUTARI), 0)), sum(nvl(abs(GECMIS_AYLARIN_FAIZI), 0)), sum(nvl(abs(BIRIKMIS_FAIZ_TUTARI), 0))
                    into ln_gecenyil_faiz_tutari, ln_gecmis_aylarin_faizi, ln_birikmis_faiz_tutari
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'ANAPARA';
                    log_at('cbs-timka_pd',1,6,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);   
                    select sum(nvl(abs(penalty_amount), 0))
                    into ln_amount_penalty
                    from cbs_hesap_kredi
                    where durum_kodu = 'A'
                    and ana_kredi_hesap_no = ln_loan_account
                    and pkg_muhasebe.banka_tarihi_bul - acilis_tarihi < 90
                    and pastdue_faiz_anapara_sec = 'FAIZ';
                    log_at('cbs-timka_pd',1,7,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    Pkg_Parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);
                    log_at('cbs-timka_pd',1,8,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);              
                    ln_toplam_tax := round((((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                                         (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate)/100),2)
                                + round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                
                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                    
                    ln_general_balance_2 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax),2);
                    
                    ln_general_balance_1 := round((ln_general_balance_1 + ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari + ln_toplam_tax + ln_amount_penalty + ln_paid_tax_amount),2);
                    log_at('cbs-timka_pd',1,9,'ln_available_amount='||ln_available_amount||' ln_general_balance_1='||ln_general_balance_1);
            
                    ln_general_balance := ln_general_balance + ln_general_balance_1;
                    log_at('cbs-timka_pd',1,10,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
                    --ln_count_a := ln_count_a + 1;
                    ln_general_balance_1 := 0;
            
                    if ln_current_account = ln_related_account then
                        lb_block := false;
                    else
                        begin         
                            select sum(bloke_tutari)
                            into ln_block_sum
                            from cbs_bloke b
                            where b.bloke_neden_kodu not in ('7', '10')
                            and b.durum_kodu = 'A' 
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_block_sum := 0; 
                        end;
            
                        ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
            
                        ln_general_balance := ln_general_balance + ln_block_sum - ln_bakiye;
                        ln_general_balance_2 := ln_general_balance_2 + ln_block_sum - ln_bakiye;
                    end if;
            
                    if trunc(ln_available_amount,2) > 0 then
                        if ls_account_currency <> ls_past_due_currency then
                            if ls_past_due_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-LC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(ls_account_currency,pkg_genel.lc_al,null,ln_available_amount,1,null,null,'O','A', ls_account_branch );
                                log_at('cbs-timka_pd',1,3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);                
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then -- LC-FC
                                ln_available_amount := pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,ls_past_due_currency,null,ln_available_amount,1,null,null,'O','S', ls_account_branch ); 
                            elsif ls_past_due_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then -- FC-FC
                                ln_available_amount := pkg_kredi.arbitraj_kur(ls_account_currency, ls_past_due_currency, ln_available_amount, ls_account_branch, false, true); 
                            end if;
                        end if;
            
                        if ln_available_amount > ln_general_balance then    --TemirlanT cbs-119
                            ln_available_amount := ln_general_balance;
                        end if;
                        if ln_available_amount > ln_general_balance_2 then    --TemirlanT cbs-119
                            ln_count_b := true;
                        end if;
                
                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
            
                        ln_alter_current_account := ln_related_account;
                        if ln_current_account != ln_related_account then  
                            if ls_account_currency <> ls_past_due_currency then
                                pkg_kredi.sp_convert_for_pd_closing_arb(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account,ln_converted_acc_amount);
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT
                                log_at('cbs-timka_pd',1,6,'ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar||' ln_general_balance='||ln_general_balance);
                            else 
                                pkg_kredi.sp_transfer_for_pd_closing(ln_loan_account, ln_current_account, ln_anapara_tahsilat_tutar, ln_alter_current_account, ln_converted_acc_amount); --TemirlanT cbs-119
                                ls_account_currency := ls_past_due_currency;        --TemirlanT
                                ln_current_account := ln_related_account;        --TemirlanT 
                            end if;
                        end if;
                        ln_current_account_2 := ln_alter_current_account;      --TemirlanT
                    end if;
                
                    if ln_count_a = true then
                        log_at('cbs-timka_pd','block',1,'ln_current_account='||ln_current_account||' ln_related_account='||ln_related_account);
                        begin    
                            select count(*) 
                            into ln_non_gon_block 
                            from cbs_bloke b
                            where b.bloke_neden_kodu not in ('7','10')
                            and b.durum_kodu = 'A' 
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_non_gon_block := 0;
                        end; 
                
                        begin
                            select count(*) 
                            into ln_gon_block_count 
                            from cbs_bloke b
                            where b.bloke_neden_kodu in ('7','10') 
                            and b.durum_kodu = 'A' 
                            and B.BLOKE_TUTARI > 0
                            and hesap_no = ln_related_account;
                        exception when no_data_found then
                            ln_gon_block_count := 0;
                        end;
                        log_at('cbs-timka_pd','block',2,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                        if  ln_non_gon_block > 0 then
                    
                            ln_bakiye := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            begin         
                                select sum(bloke_tutari)
                                into ln_block_sum
                                from cbs_bloke b
                                where b.bloke_neden_kodu not in ('7', '10')
                                and b.durum_kodu = 'A' 
                                and B.BLOKE_TUTARI > 0
                                and hesap_no = ln_related_account;
                            exception when no_data_found then
                                ln_block_sum := 0; 
                            end;
                            if ln_bakiye > ln_block_sum then
                                log_at('cbs-timka_pd','block',3,'ln_bakiye='||ln_bakiye||' ln_block_sum='||ln_block_sum);
                                if ln_gon_block_count > 0 then
                                    log_at('cbs-timka_pd','block',4,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                                    OPEN rel_acc_block;
                                    LOOP
                                        FETCH rel_acc_block INTO r_acc_block;
                                        EXIT WHEN rel_acc_block%NOTFOUND;
                                        begin
                                            if r_acc_block.bloke_neden_kodu = '7' then
                                                log_at('cbs-timka_pd','block',5,'ln_non_gon_block='||ln_non_gon_block||' ln_gon_block_count='||ln_gon_block_count);
                                                Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                                      r_acc_block.musteri_no,
                                                                      r_acc_block.hesap_no,
                                                                      r_acc_block.doviz_kodu,
                                                                      pn_BLOKE_TUTARI=>0,
                                                                      ps_BLOKE_NEDEN_KODU=>'7',
                                                                      ps_ACIKLAMA=>'Releasing Blocking for past due closing',
                                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                                      PS_KAPAMA   => 'KAPAMA');
                                                                                              
                                            elsif r_acc_block.bloke_neden_kodu = '10' then
                                                Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                                      r_acc_block.musteri_no,
                                                                      r_acc_block.hesap_no,
                                                                      r_acc_block.doviz_kodu,
                                                                      pn_BLOKE_TUTARI=>0,
                                                                      ps_BLOKE_NEDEN_KODU=>'10',
                                                                      ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                                      pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                                      PS_KAPAMA   => 'KAPAMA');
                                            end if;
                                            commit;
                                        exception
                                            when others then
                                        log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_related_account: ' || ln_related_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                                        end;
                                    END LOOP;
                                    CLOSE rel_acc_block;
                                    ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                    lb_block := false; 
                                    log_at('cbs-timka_pd','block',6,'ln_available_amount='||ln_available_amount||' lb_block='||'false');
                                else
                                    ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                    lb_block := false;
                                    log_at('cbs-timka_pd','block',7,'ln_available_amount='||ln_available_amount||' lb_block='||'false');
                                end if;
                            else
                                ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2) - ln_block_sum;
                                lb_block := true;
                                log_at('cbs-timka_pd','block',8,'ln_available_amount='||ln_available_amount||' lb_block='||'true');
                            end if;
                    
                        elsif ln_gon_block_count > 0  then
                                          
                            OPEN rel_acc_block;
                            LOOP
                                FETCH rel_acc_block INTO r_acc_block;
                                EXIT WHEN rel_acc_block%NOTFOUND;
                                        
                                --if (rel_acc_block%FOUND) then
                                begin
                                    if r_acc_block.bloke_neden_kodu = '7' then                               
                                        Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                          r_acc_block.musteri_no,
                                                          r_acc_block.hesap_no,
                                                          r_acc_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'7',
                                                          ps_ACIKLAMA=>'Releasing GON file Blocking for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                                    elsif r_acc_block.bloke_neden_kodu = '10' then
                                        Pkg_Bloke.sp_bloke_yarat(r_acc_block.bloke_referans,
                                                          r_acc_block.musteri_no,
                                                          r_acc_block.hesap_no,
                                                          r_acc_block.doviz_kodu,
                                                          pn_BLOKE_TUTARI=>0,
                                                          ps_BLOKE_NEDEN_KODU=>'10',
                                                          ps_ACIKLAMA=>'Releasing Loans Block for past due closing',
                                                          pd_BLOKE_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          pd_BLOKE_BITIS_TARIHI=>Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                                          PS_KAPAMA   => 'KAPAMA');
                                  
                                    end if;                                                       
                                    commit;
                                exception
                                    when others then
                                    log_at('GONfileReleasBlock', 'referans: ' || r_block.bloke_referans || ', ln_current_account: ' || ln_current_account || ', ln_musteri_no: ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                                end;
                            END LOOP;
                            CLOSE rel_acc_block;
                            ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            lb_block := false;
                        else
                            ln_available_amount := trunc(pkg_hesap.HesapBakiyeAl(ln_related_account),2);
                            lb_block := false;
                        end if;
                    end if;
            
                    if ln_current_account = ln_related_account then
                        lb_block := false;
                    end if;
                END LOOP;
                CLOSE c_credited_count;
       
                log_at('cbs-timka_pd',1,11,'ln_general_balance='||ln_general_balance||' ln_general_balance_1='||ln_general_balance_1);
            end if;  
        exception when others then
            log_at('cbs-timka_pd',1,10,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
        --ln_related_account := null;
        end;
        
        /*if ln_available_amount > ln_general_balance then    --TemirlanT cbs-119
            ln_available_amount := ln_general_balance;
        end if;*/
        --EOM TemirlanT
    -----------------------before-----------------------------------------
    
        if trunc(ln_available_amount,2) > 0 then
            open cur_penalty_pd_before_2013;
            loop
            fetch cur_penalty_pd_before_2013 into r_penalty_pd_before_2013;
            exit when cur_penalty_pd_before_2013%notfound;
                ls_past_due_currency := r_penalty_pd_before_2013.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;
                
               

                if trunc(ln_available_amount,2) > 0 then
                
                    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);   
                    
                    ln_related_account_penalty := r_penalty_pd_before_2013.hesap_no;    
                    ln_amount_penalty := r_penalty_pd_before_2013.penalty_amount;
                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                    
                    if round(ln_available_amount,2) < nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);                  
                    elsif round(ln_available_amount,2) = nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);                   
                    elsif round(ln_available_amount,2) > nvl(r_penalty_pd_before_2013.penalty_amount,0) then
                        if round(ln_available_amount,2) >= nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := r_penalty_pd_before_2013.penalty_amount;
                            ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                        elsif round(ln_available_amount,2) < nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                            ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                        end if;         
                    end if;  

                    ln_total_collection_amount := nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0);   
                    
                    lb_bought_amount := false;
                    
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_related_account_penalty 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                    
                    -----------------------------------------------------------
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
                    
                    
                    if lb_block = false then
                            
                        ls_cash_account := 'ACCOUNT';
                        ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account_pd);
                        ln_customer_no := ln_musteri_no;
                        ls_residency_code := pkg_musteri.sf_get_residency_code (ln_customer_no);
                        ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_customer_no);
                        ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no);
                        ls_income_type := 'LOANCOMM';
                        
                        ls_vat := 'N';
                        ls_service_tax := 'Y';
                        ls_tax_coll_type := 'PS';--PAID SEPERATELY
                        ln_rate_penalty := pkg_kur.doviz_doviz_karsilik(ls_currency_code,pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        ln_collection_account_penalty := ln_related_account_pd;
                        ls_collection_currency_penalty := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_collection_account_penalty);
                        pkg_parametre.deger('G_PD_PENALTY',ls_income_gl);
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_penalty_pd_before_2013.acilis_tarihi;
                        ls_explanation := 'Penalty for ' || ln_delayed_days || ' days delay of int+sales tax of ' || PKG_MUSTERI.SF_MUSTERI_ADI(ln_customer_no);
                                              
                        ls_modul_tur_kod := 'CURR.OPS.';
                        ls_urun_tur_kod := 'CHARGE';
                        ls_urun_sinif_kod := 'GENERAL';
                        ls_pd_branch_cd := r_penalty_pd_before_2013.sube_kodu;
                        pkg_kredi.sp_penalty_Pastdue_Closing(
                                                            ls_cash_account ,
                                                            ls_currency_code ,
                                                            ln_customer_no ,
                                                            ls_residency_code,
                                                            ls_citizen_code,
                                                            ls_customer_type, 
                                                            ls_income_type, 
                                                            ln_related_account_penalty,
                                                            ln_amount_penalty,
                                                            ls_vat,
                                                            ls_service_tax,
                                                            ln_service_tax_rate,
                                                            ls_tax_coll_type,
                                                            ln_paid_tax_amount,
                                                            ln_total_collection_amount,
                                                            ls_collection_currency_penalty,
                                                            ln_rate_penalty,
                                                            ln_collection_account_penalty,
                                                            ls_income_gl,
                                                            ls_explanation,
                                                            ls_pd_branch_cd,
                                                            ls_modul_tur_kod,
                                                            ls_urun_tur_kod,
                                                            ls_urun_sinif_kod,
                                                            ln_current_account
                                                            );
                                                          
                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_total_collection_amount,0);
                    end if;                                       
                
                end if; 
            
            end loop;
            close cur_penalty_pd_before_2013;    
        end if;
    
        if trunc(ln_available_amount,2) > 0 then
            OPEN cur_def_int_before_2013_pd;
            loop
                fetch cur_def_int_before_2013_pd into r_def_int_before_2013_pd;
                exit when cur_def_int_before_2013_pd%notfound;
                ls_past_due_currency := r_def_int_before_2013_pd.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;      
            
                if trunc(ln_available_amount,2) > 0 then
            
                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);                    
                    ln_pd_account_no := r_def_int_before_2013_pd.hesap_no;
                    ln_gecenyil_faiz_tutari := abs(nvl(r_def_int_before_2013_pd.GECENYIL_FAIZ_TUTARI,0)); 
                    ln_gecmis_aylarin_faizi := abs(nvl(r_def_int_before_2013_pd.GECMIS_AYLARIN_FAIZI,0)); 
                    ln_birikmis_faiz_tutari := abs(nvl(r_def_int_before_2013_pd.BIRIKMIS_FAIZ_TUTARI,0));
                    ln_tahsedil_gecenyilfaiztutar := 0;
                    ln_tahsedil_gecmis_aylar_faiz := 0;
                    ln_tahsedil_birikmisfaiztutar := 0;
                    ln_tax_last_year := 0;
                    ln_tax_last_month := 0;
                    ln_tax_cumulated := 0;
                
                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                
                    ln_toplam_tax := round((((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                                         (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate )/100 ),2)+ 
                                         round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);

                    if round(nvl(ln_available_amount,0),2) > 0 then 
                        if ln_available_amount >= nvl(ln_toplam_faiz,0) + nvl(ln_toplam_tax,0) then
                            ls_choice := 'KAPAMA';
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                            ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                            ln_available_amount := nvl(ln_available_amount,0) - (abs(ln_toplam_faiz) + ln_toplam_tax);                                  
                        else
                            ls_choice := 'GERI ODEME';
                            if round(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecenyil_faiz_tutari,0),2) > 0 then
                                    if ln_available_amount >= ln_gecenyil_faiz_tutari + (round((((nvl(ln_gecenyil_faiz_tutari,0))*ln_tax_rate_last_year )/100),2)) then
                                        ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecenyilfaiztutar,0) + ln_tax_last_year);                                      
                                    else
                                        ln_tahsedil_gecenyilfaiztutar := round(ln_available_amount / (1 + ln_tax_rate_last_year / 100),2);
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecenyilfaiztutar,0)))*ln_tax_rate_last_year )/100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecenyilfaiztutar + ln_tax_last_year);                                                  
                                    end if;
                                end if;
                            end if;
                                
                            if trunc(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecmis_aylarin_faizi,0),2) > 0 then 
                                    if ln_available_amount >= ln_gecmis_aylarin_faizi + (round((((nvl(ln_gecmis_aylarin_faizi,0))*ln_tax_rate )/100),2)) then
                                        ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecmis_aylar_faiz,0) + ln_tax_last_month);                                         
                                    else
                                        ln_tahsedil_gecmis_aylar_faiz := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecmis_aylar_faiz,0))) * ln_tax_rate ) / 100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecmis_aylar_faiz + ln_tax_last_month);                                        
                                    end if;
                                end if;
                                        
                                if trunc(nvl(ln_available_amount,0),2) > 0 then 
                                    if round(nvl(ln_birikmis_faiz_tutari,0),2) > 0 then
                                        if ln_available_amount >= ln_birikmis_faiz_tutari + (round(((nvl(ln_birikmis_faiz_tutari,0)*ln_tax_rate)/100),2)) then
                                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                                            ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_birikmisfaiztutar,0) + ln_tax_cumulated);
                                        else
                                            ln_tahsedil_birikmisfaiztutar := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_birikmisfaiztutar,0))) * ln_tax_rate ) / 100),2);
                                            ln_available_amount := ln_available_amount - (ln_tahsedil_birikmisfaiztutar + ln_tax_cumulated);
                                        end if;
                                    end if;
                                end if; 
                                    
                            end if;
                        end if;
                        
                    end if;
                
                    ln_faizler := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar + ln_tax_last_year + ln_tax_last_month + ln_tax_cumulated;
                
                    lb_bought_amount := false;
                
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
                
                
                    if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                    
                        ls_modul_tur_kod := r_def_int_before_2013_pd.modul_tur_kod;
                        ls_urun_tur_kod := r_def_int_before_2013_pd.urun_tur_kod;
                        ls_urun_sinif_kod := r_def_int_before_2013_pd.urun_sinif_kod;
                        ln_pd_balance := r_def_int_before_2013_pd.pd_balance;
                        ls_pd_branch_cd := r_def_int_before_2013_pd.sube_kodu;
                        ls_son_gun_faizi := r_def_int_before_2013_pd.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if; 
                    
                        ld_value_date := null;              
                        ls_collection_currency := ls_account_currency;
                    
                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;
                    
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                    
                        if ln_pd_balance <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;
                    
                        ln_anapara_tahsilat_tutar := 0;
                        
                        if ls_choice = 'KAPAMA' then 
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;
                    
                        ls_aciklama := 'Close PDPA, c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;

                        pkg_kredi.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod, 
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );
                    end if;  
            
                end if;
                        
            end loop;
        close cur_def_int_before_2013_pd; 
        end if;
    
        if trunc(ln_available_amount,2) > 0 then
            open cur_faiz_pd_before_2013;
            loop
                fetch cur_faiz_pd_before_2013 into r_faiz_pd_before_2013;
                exit when cur_faiz_pd_before_2013%notfound;
                if trunc(nvl(ln_available_amount,0),2) > 0 then
                    if nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) > 0 then
                        ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                        ln_acc_amount_before := ln_available_amount;
                        if nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) + nvl(r_faiz_pd_before_2013.pd_tax_amount,0) <= trunc(ln_available_amount,2) then
                            
                            if trunc(ln_available_amount,2) > 0 then
                         
                            -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                                ln_acc_amount_before := ln_available_amount; 
                                ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.hesap_no;
                        
                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;

                                lb_bought_amount := false;
                        
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                        
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                            
                                if lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????? ?? faiz ? tax
                        
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;
                                  
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;
                                  
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                            
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                           
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                           
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                  
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;
                           
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;
                           
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod, 
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         ); 
                                                         
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0); 
                                end if;                              
                                --aisuluud
                                -------------------------FAIZ--------------------------------------------------------------
                        
                                -------------------------TAX----------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;--aisuluud
                                ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;
                                                          
                                if ln_available_amount >= ln_pd_balance then--aisuluud
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                    ls_choice := 'GERI ODEME';
                                end if;
                                                          
                                lb_bought_amount := false;
                     
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;                                                              
                                
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                    
                                if lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                                 
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;
                                  
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;
                                  
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                  
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                  
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                                          
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;
                                                          
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;
                                                          
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );                           
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);  
                                end if;        
                                -------------------------TAX----------------------------------------------------------------
                            end if;
                        else
                            ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            if trunc(ln_available_amount,2) > 0 then
                                ln_pd_tax_balance := round(ln_available_amount,2) * 2 / (100+2);
                                ln_pd_interest_balance := round(ln_available_amount,2) - ln_pd_tax_balance;
                                -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.hesap_no; 
                                if ln_pd_interest_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_interest_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;
                        
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end; 
                        
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                        
                                if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;
                                    
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if; 
                                    
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                                      
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                    
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                                                      
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                                                      
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;
                                    
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no; 
                                    
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                                         
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);    
                                end if;                      

                                -------------------------FAIZ--------------------------------------------------------------
                        
                                -------------------------TAX--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;
                                
                                if ln_pd_tax_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_tax_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;
                        
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                        
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                        
                                if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????
                                    ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0); 
                                    ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;
                                    
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if; 
                                    
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                                      
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                    
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                      
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                                                      
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                    else
                                        ls_durum_kodu := 'A';
                                    end if;
                                                                       
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no; 
                                    
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                                         
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                end if;
                                -------------------------TAX--------------------------------------------------------------
                            end if;
                
                        end if;
            
                    elsif nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) = 0 then
            
                        -------------------------FAIZ--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then 
                            ls_past_due_currency := r_faiz_pd_before_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_before_2013.pd_faiz_amount;
                            ln_pd_account_no := r_faiz_pd_before_2013.hesap_no;  
                    
                            if round(ln_available_amount,2) >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                            else
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                ls_choice := 'GERI ODEME';
                            end if;
                    
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no 
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                    
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;
                    
                            if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????a
                            
                                ls_modul_tur_kod := r_faiz_pd_before_2013.modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_before_2013.urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_before_2013.urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.GECENYIL_FAIZ_TUTARI,0); 
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.GECMIS_AYLARIN_FAIZI,0); 
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_before_2013.sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_before_2013.son_gun_faizi;
                            
                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;
                            
                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                ls_collection_currency := ls_account_currency;
                                                      
                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;
                            
                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                              
                                if ln_toplam_faiz <> 0 then 
                                    ls_choice := 'GERI ODEME';
                                end if;  
                                                      
                                if ls_choice = 'KAPAMA' then 
                                    ls_durum_kodu := 'K';
                                else
                                    ls_durum_kodu := 'A';
                                end if;
                                                      
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                ls_aciklama := 'Close past due interests of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;  
                            
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                                                         
                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);   
                            end if;    
                    
                        end if;
                
                        -------------------------FAIZ--------------------------------------------------------------
                    elsif nvl(r_faiz_pd_before_2013.pd_faiz_amount,0) = 0 and nvl(r_faiz_pd_before_2013.pd_tax_amount,0) > 0 then
            
                        -------------------------TAX--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_before_2013.tax_doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_before_2013.pd_tax_amount;
                            ln_pd_account_no := r_faiz_pd_before_2013.tax_hesap_no;
                    
                            if round(ln_available_amount,2) >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                            else
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                ls_choice := 'GERI ODEME';
                            end if;
                    
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no 
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                    
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;
                    
                            if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????  
                                ls_modul_tur_kod := r_faiz_pd_before_2013.tax_modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_before_2013.tax_urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_before_2013.tax_urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_before_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_before_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_before_2013.tax_sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_before_2013.tax_son_gun_faizi;
                            
                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;
                            
                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                ls_collection_currency := ls_account_currency;
                                                  
                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;
                            
                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                      
                                if ln_toplam_faiz <> 0 then 
                                    ls_choice := 'GERI ODEME';
                                end if;  
                                                  
                                if ls_choice = 'KAPAMA' then 
                                    ls_durum_kodu := 'K';
                                else
                                    ls_durum_kodu := 'A';
                                end if;
                                                   
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                ls_aciklama := 'Close past due tax of c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no; 
                            
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod, 
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );
                                                             
                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                            end if;  
                            
                        end if;
                        -------------------------TAX--------------------------------------------------------------            
                    end if;
        
                end if; 
        
            end loop;
            close cur_faiz_pd_before_2013;   
        end if; 
    
    
        if trunc(ln_available_amount,2) > 0 then
            open cur_anapara_pd_before_2013;
            loop
                fetch cur_anapara_pd_before_2013 into r_anapara_pd_before_2013;
                exit when cur_anapara_pd_before_2013%notfound;
                if trunc(ln_available_amount,2) > 0 then    
                    ls_past_due_currency := r_anapara_pd_before_2013.doviz_kodu; 
                    ln_acc_amount_before := ln_available_amount;        
                    ln_pd_account_no := r_anapara_pd_before_2013.hesap_no;
                    ln_pd_balance := r_anapara_pd_before_2013.pd_balance;   
            
                    if ln_available_amount >= ln_pd_balance then
                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                        ls_choice := 'KAPAMA';
                    else
                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                        ls_choice := 'GERI ODEME';
                    end if;
            
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                        
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
            
                    if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                        ls_modul_tur_kod := r_anapara_pd_before_2013.modul_tur_kod;
                        ls_urun_tur_kod := r_anapara_pd_before_2013.urun_tur_kod;
                        ls_urun_sinif_kod := r_anapara_pd_before_2013.urun_sinif_kod;
                        ln_gecenyil_faiz_tutari := nvl(r_anapara_pd_before_2013.GECENYIL_FAIZ_TUTARI,0); 
                        ln_gecmis_aylarin_faizi := nvl(r_anapara_pd_before_2013.GECMIS_AYLARIN_FAIZI,0); 
                        ln_birikmis_faiz_tutari := nvl(r_anapara_pd_before_2013.BIRIKMIS_FAIZ_TUTARI,0);
                        ls_pd_branch_cd := r_anapara_pd_before_2013.sube_kodu;
                        ls_son_gun_faizi := r_anapara_pd_before_2013.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;
                      
                        ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                        ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                        ls_collection_currency := ls_account_currency;
                      
                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        if ln_toplam_faiz <> 0 then 
                            ls_choice := 'GERI ODEME';
                        end if;  
                              
                        if ls_choice = 'KAPAMA' then 
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;
                              
                        ln_tahsedil_gecenyilfaiztutar := 0;
                        ln_tahsedil_gecmis_aylar_faiz := 0;
                        ln_tahsedil_birikmisfaiztutar := 0;
                        ls_aciklama := 'Close PDPA, c_no:' || ln_musteri_no || 'acc no:' || ln_pd_account_no;
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                    
                        pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                                                     
                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);     
                    end if;                             
            
                end if;
            end loop;
            close cur_anapara_pd_before_2013;
        end if;

        ------------------------------------------before-------------------------------------------------  
        log_at('cbs-timka_pd','anapara',222,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
    
        ------------------------------------------after-------------------------------------------------  
  
        if trunc(ln_available_amount,2) > 0 then
            open cur_anapara_pd_after_2013;
            loop
                fetch cur_anapara_pd_after_2013 into r_anapara_pd_after_2013;
                exit when cur_anapara_pd_after_2013%notfound;
                if trunc(ln_available_amount,2) > 0 then    
                    ls_past_due_currency := r_anapara_pd_after_2013.doviz_kodu;
                    ln_acc_amount_before := ln_available_amount; 
                    ln_pd_account_no := r_anapara_pd_after_2013.hesap_no;
                    ln_pd_balance := r_anapara_pd_after_2013.pd_balance;
                    ln_loan_related_account := r_anapara_pd_after_2013.iliskili_hesap_no;
                    ln_loan_account := r_anapara_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                    ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_anapara_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                    log_at('cbs-timka_pd',1,2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
                 
                    if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                        
                        log_at('cbs-timka_pd','anapara',2);
                     
                        ls_modul_tur_kod := r_anapara_pd_after_2013.modul_tur_kod;
                        ls_urun_tur_kod := r_anapara_pd_after_2013.urun_tur_kod;
                        ls_urun_sinif_kod := r_anapara_pd_after_2013.urun_sinif_kod;
                        ln_gecenyil_faiz_tutari := nvl(r_anapara_pd_after_2013.GECENYIL_FAIZ_TUTARI,0); 
                        ln_gecmis_aylarin_faizi := nvl(r_anapara_pd_after_2013.GECMIS_AYLARIN_FAIZI,0); 
                        ln_birikmis_faiz_tutari := nvl(r_anapara_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                        ls_pd_branch_cd := r_anapara_pd_after_2013.sube_kodu;
                        ls_son_gun_faizi := r_anapara_pd_after_2013.son_gun_faizi;

                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if;
                          
                        ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                        ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                        ls_collection_currency := ls_account_currency;
                          
                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;

                        if ln_toplam_faiz <> 0 then 
                            ls_choice := 'GERI ODEME';
                        end if;  
                                  
                        if ls_choice = 'KAPAMA' then 
                            ls_durum_kodu := 'K';
                        else
                            ls_durum_kodu := 'A';
                        end if;
                                
                        
                        if ln_count_b then
                            ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_anapara_pd_after_2013.acilis_tarihi;
                            --BOM TemirlanT
                            pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                            if ln_delayed_days=1 then
                                ls_day := SUBSTR (ls_day, 1, 4);
                            elsif ln_delayed_days in (2,3,4) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                                ls_day := SUBSTR (ls_day, 10, 4);
                            elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                                ls_day := SUBSTR (ls_day, 6, 3);
                            else
                                ls_day := SUBSTR (ls_day, 10, 4);
                            end if;
                            --EOM TemirlanT   
                            pkg_parametre.deger('G_PD_MAIN_ELEVATED_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            ls_aciklama := REPLACE (ls_aciklama, '$$$', ln_delayed_days);
                            ls_aciklama := REPLACE (ls_aciklama, '@@@', ls_day);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari; 
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ls_durum_kodu := 'K';
                        else
                            pkg_parametre.deger('G_PD_MAIN_EXPLANATION',ls_aciklama);
                            ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                            ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                            ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka
                            if ln_available_amount >= ln_pd_balance then
                                ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                ls_choice := 'KAPAMA';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%');
                            else
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                ls_choice := 'GERI ODEME';
                                ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                            end if;
                            ln_tahsedil_gecenyilfaiztutar := 0;
                            ln_tahsedil_gecmis_aylar_faiz := 0;
                            ln_tahsedil_birikmisfaiztutar := 0; 
                        
                        end if;
                        ln_toplam_faiz_tim := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar;
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                        log_at('cbs-timka_pd','anapara',1,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                               ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                               ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                               ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                               ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                               ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                               ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                               ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                               ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no); 
                        pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,--
                                                     ln_tahsedil_gecmis_aylar_faiz,--
                                                     ln_tahsedil_birikmisfaiztutar,--
                                                     ln_anapara_tahsilat_tutar,--
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                
                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0) - nvl(ln_toplam_faiz_tim,0);
                    end if;
                    log_at('cbs-timka_pd',1,7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                end if;   
            end loop;
            close cur_anapara_pd_after_2013;
        end if;
    
        -----------------------------------------------------------------------------------FAIZ<->TAX---------------------------------------------------------------------------------------------------------------------
        if trunc(ln_available_amount,2) > 0 then
            open cur_faiz_pd_after_2013;
            loop
                fetch cur_faiz_pd_after_2013 into r_faiz_pd_after_2013;
                exit when cur_faiz_pd_after_2013%notfound;
                ln_loan_account := r_faiz_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_faiz_pd_after_2013.ACILIS_TARIHI); --TemirlanT cbs-119
                if trunc(nvl(ln_available_amount,0),2) > 0 then --end if
                    log_at('cbs-timka_pd','faiz-1',1, 'ln_available_amount='||ln_available_amount);
                    if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then --end if 0->12
                        --aisuluud
                        ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                        ln_acc_amount_before := ln_available_amount;
                        log_at('cbs-timka_pd','faiz-1',2,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);
                
                        if nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) + nvl(r_faiz_pd_after_2013.pd_tax_amount,0) <= trunc(ln_available_amount,2) then
                            log_at('cbs-timka_pd','faiz-1',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                            if trunc(ln_available_amount,2) > 0 then 
                                -------------------------FAIZ--------------------------------------------------------------
                                           
                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;
                        
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                        
                                log_at('cbs-timka_pd','faiz-1',8,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                                          
                                if lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????? ?? faiz ? tax
                                    log_at('cbs-timka_pd','faiz-1',9,'ln_available_amount='||ln_available_amount||' ln_current_account='||ln_current_account);
                                    if round(ln_available_amount,2) >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                    log_at('cbs-timka_pd','faiz-1',10,'ln_available_amount='||ln_available_amount||' ls_choice='||ls_choice);                       
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;
                                                          
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;
                                                          
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                          
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                                          
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                                        
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka                 
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;                           
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                             
                                    log_at('cbs-timka_pd','faiz-1',11,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);                       
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('cbs-timka_pd','faiz-1',12,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                end if;
                                    log_at('cbs-timka_pd','faiz-1',13,'ln_available_amount='||ln_available_amount||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar);
                                ----------------------------FAIZ--------------------------------------------------------------
                            
                                -------------------------------TAX----------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','tax-1',1,'ln_available_amount='||ln_available_amount||' ls_past_due_currency='||ls_past_due_currency);  
                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;
                           
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                        
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                         
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                        
                                if lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????a
                        
                                    if ln_available_amount >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                                        ls_choice := 'GERI ODEME';
                                    end if;
                                                                                                                  
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;
                                      
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if;
                                                              
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                              
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                      
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                                            
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka                                
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                                              
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','tax-1',2,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);          
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                                                        
                                    ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_anapara_tahsilat_tutar,0);  
                            
                                end if;
                                log_at('cbs-timka_pd','tax-1',3,'ln_available_amount='||ln_available_amount||' ls_account_currency='||ls_account_currency); 
                            end if;                                 
                            -------------------------TAX---------------------------------------------------------------- 
                        else 
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                    
                            if trunc(ln_available_amount,2) > 0 then
                                ln_pd_tax_balance := round(ln_available_amount,2) * 2 / (100+2);
                                ln_pd_interest_balance := round(ln_available_amount,2) - ln_pd_tax_balance;
                                -------------------------FAIZ--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;  
                                ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;
                                log_at('cbs-timka_pd','faiz_tax_faiz',1,'ln_available_amount='||ln_available_amount||' ln_pd_tax_balance='||ln_pd_tax_balance
                                                            ||' ln_pd_interest_balance='||ln_pd_interest_balance||' ln_pd_balance='||ln_pd_balance);                                                                 
                                                       
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                ln_anapara_tahsilat_tutar := abs(ln_available_amount);
                        
                                log_at('cbs-timka_pd','faiz_tax_faiz',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account); 
                                -------------------------------------------
                        
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                        
                                if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ??????a
                                    if ln_pd_interest_balance >= ln_pd_balance then
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                        ls_choice := 'KAPAMA';
                                    else
                                        ln_anapara_tahsilat_tutar := abs(ln_pd_interest_balance);
                                        ls_choice := 'GERI ODEME';
                                    end if;
                            
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                    
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;
                                    
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if; 
                                    
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                                      
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                    
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                                                      
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if;  
                                    pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka                 
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);                                            
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0; 
                                    log_at('cbs-timka_pd','faiz_tax_faiz',4,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);  
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                                 
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);   
                            
                                end if; --bloke
                                log_at('cbs-timka_pd','faiz_tax_faiz',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);  
                                -------------------------FAIZ--------------------------------------------------------------
                        
                                -------------------------TAX--------------------------------------------------------------
                                ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                                ln_acc_amount_before := ln_available_amount;
                                log_at('cbs-timka_pd','faiz_tax_tax',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_past_due_currency='||ls_past_due_currency||' ln_acc_amount_before='||ln_acc_amount_before); 
                        
                                ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                                ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;
                        
                                if ln_pd_tax_balance >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_tax_balance);
                                    ls_choice := 'GERI ODEME';
                                end if;
                        
                                begin---------------------rahat
                                    select iliskili_hesap_no
                                    into ln_related_account_pd
                                    from cbs_hesap_kredi
                                    where hesap_no = ln_pd_account_no 
                                    and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                    and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                                exception when others then
                                    ln_related_account_pd := null;
                                end;
                                log_at('cbs-timka_pd','faiz_tax_tax',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                                if ln_current_account = ln_related_account_pd then
                                    lb_block := false;
                                end if;
                        
                                if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                                    ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                    ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                    ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                    ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                    ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                    ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0); 
                                    ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                    ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;
                                    
                                    if ls_son_gun_faizi = 'E' then
                                        pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                        ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                    end if; 
                                    
                                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                    ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                    ls_collection_currency := ls_account_currency;
                                                                      
                                    if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                    else
                                        ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                    end if;
                                    
                                    ln_related_account := ln_related_account_pd;
                                    ln_collection_account := null;
                                    ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                    
                                    if ln_toplam_faiz <> 0 then 
                                        ls_choice := 'GERI ODEME';
                                    end if; 
                                     
                                    pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                    ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                    ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                    ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka 
                                                                   
                                    if ls_choice = 'KAPAMA' then 
                                        ls_durum_kodu := 'K';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                    else
                                        ls_durum_kodu := 'A';
                                        ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                    end if;
                                    log_at('cbs-timka_pd','faiz_tax_tax',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);                                         
                                    ln_tahsedil_gecenyilfaiztutar := 0;
                                    ln_tahsedil_gecmis_aylar_faiz := 0;
                                    ln_tahsedil_birikmisfaiztutar := 0;
                                    log_at('cbs-timka_pd','faiz_tax_tax',8,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                    ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                    ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                    ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                    ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                    ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                    ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);          
                                    pkg_kredi.sp_Principal_Pastdue_Closing(
                                                 ln_pd_account_no,
                                                 ld_value_date,
                                                 ls_collection_currency,
                                                 ln_rate,
                                                 ln_related_account,
                                                 ln_collection_account,
                                                 ln_tahsedil_gecenyilfaiztutar,
                                                 ln_tahsedil_gecmis_aylar_faiz,
                                                 ln_tahsedil_birikmisfaiztutar,
                                                 ln_anapara_tahsilat_tutar,
                                                 ls_aciklama,
                                                 ls_choice,
                                                 ls_durum_kodu,
                                                 ls_pd_branch_cd,
                                                 ls_modul_tur_kod, 
                                                 ls_urun_tur_kod,
                                                 ls_urun_sinif_kod,
                                                 ls_past_due_currency,
                                                 ln_musteri_no
                                                 );
                                    log_at('tahsilat_4883project4',9,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar ); 
                                    ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);
                                    log_at('tahsilat_4883project4',10,'ln_pd_account_no: '||ln_pd_account_no||' ln_available_amount: '||ln_available_amount||' ln_anapara_tahsilat_tutar: '||ln_anapara_tahsilat_tutar ); 
                                end if; --bloke
                        
                                -------------------------TAX--------------------------------------------------------------
                                log_at('cbs-timka_pd','faiz_tax_tax',9,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                                ||' ls_choice='||ls_choice||' ls_durum_kodu='||ls_durum_kodu);
                            end if;
                
                        end if;
                        ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            
                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) > 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) = 0 then
                        log_at('cbs-timka_pd','faiz_1_tax_0',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                -------------------------FAIZ--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then 
                            ls_past_due_currency := r_faiz_pd_after_2013.doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_faiz_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.hesap_no;
                    
                            log_at('cbs-timka_pd','faiz_1_tax_0',2,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                    
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no 
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                            log_at('cbs-timka_pd','faiz_1_tax_0',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;
                    
                            if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                        
                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;
                                                                           
                                ls_modul_tur_kod := r_faiz_pd_after_2013.modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.GECENYIL_FAIZ_TUTARI,0); 
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.GECMIS_AYLARIN_FAIZI,0); 
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.son_gun_faizi;
                            
                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;
                            
                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                ls_collection_currency := ls_account_currency;
                                                      
                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;      
                            
                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                              
                                if ln_toplam_faiz <> 0 then 
                                    ls_choice := 'GERI ODEME';
                                end if;
                                  
                                pkg_parametre.deger('G_PD_PERCENT_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka                     
                                
                                if ls_choice = 'KAPAMA' then 
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_1_tax_0',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);                              
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_1_tax_0',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);    
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                                  
                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0); 
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_1_tax_0',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance); 
                        end if;
                
                        -------------------------FAIZ--------------------------------------------------------------
                    elsif nvl(r_faiz_pd_after_2013.pd_faiz_amount,0) = 0 and nvl(r_faiz_pd_after_2013.pd_tax_amount,0) > 0 then 
                        -------------------------TAX--------------------------------------------------------------
                        if trunc(ln_available_amount,2) > 0 then
                            ls_past_due_currency := r_faiz_pd_after_2013.tax_doviz_kodu;
                            ln_acc_amount_before := ln_available_amount;
                            ln_pd_balance := r_faiz_pd_after_2013.pd_tax_amount;
                            ln_pd_account_no := r_faiz_pd_after_2013.tax_hesap_no;
                            log_at('cbs-timka_pd','faiz_0_tax_1',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance); 
                      
                            ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                    
                            log_at('cbs-timka_pd','faiz_0_tax_1',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account); 
                            begin---------------------rahat
                                select iliskili_hesap_no
                                into ln_related_account_pd
                                from cbs_hesap_kredi
                                where hesap_no = ln_pd_account_no 
                                and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                                and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                            exception when others then
                                ln_related_account_pd := null;
                            end;
                     
                            if ln_current_account = ln_related_account_pd then
                                lb_block := false;
                            end if;
                    
                            if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                              
                                if round(ln_available_amount,2) >= ln_pd_balance then
                                    ln_anapara_tahsilat_tutar := abs(ln_pd_balance);
                                    ls_choice := 'KAPAMA';
                                else
                                    ln_anapara_tahsilat_tutar := abs(round(ln_available_amount,2));
                                    ls_choice := 'GERI ODEME';
                                end if;
                
                                ls_modul_tur_kod := r_faiz_pd_after_2013.tax_modul_tur_kod;
                                ls_urun_tur_kod := r_faiz_pd_after_2013.tax_urun_tur_kod;
                                ls_urun_sinif_kod := r_faiz_pd_after_2013.tax_urun_sinif_kod;
                                ln_gecenyil_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_GECENYIL_FAIZ_TUTARI,0); 
                                ln_gecmis_aylarin_faizi := nvl(r_faiz_pd_after_2013.tax_GECMIS_AYLARIN_FAIZI,0); 
                                ln_birikmis_faiz_tutari := nvl(r_faiz_pd_after_2013.tax_BIRIKMIS_FAIZ_TUTARI,0);
                                ls_pd_branch_cd := r_faiz_pd_after_2013.tax_sube_kodu;
                                ls_son_gun_faizi := r_faiz_pd_after_2013.tax_son_gun_faizi;
                        
                                if ls_son_gun_faizi = 'E' then
                                    pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                                    ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                                end if;
                        
                                ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;              
                                ld_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;              
                                ls_collection_currency := ls_account_currency;
                                              
                                if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                                else
                                    ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                                end if;                    
                        
                                ln_related_account := ln_related_account_pd;
                                ln_collection_account := null;
                                ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                                                                  
                                if ln_toplam_faiz <> 0 then 
                                    ls_choice := 'GERI ODEME';
                                end if;  
                                pkg_parametre.deger('G_PD_TAX_EXPLANATION',ls_aciklama);
                                ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                                ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                                ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka                                    
                                if ls_choice = 'KAPAMA' then 
                                    ls_durum_kodu := 'K';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%');
                                else
                                    ls_durum_kodu := 'A';
                                    ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);
                                end if;
                                log_at('cbs-timka_pd','faiz_0_tax_1',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                            ||' ls_durum_kodu='||ls_durum_kodu||' ls_choice='||ls_choice);                       
                                ln_tahsedil_gecenyilfaiztutar := 0;
                                ln_tahsedil_gecmis_aylar_faiz := 0;
                                ln_tahsedil_birikmisfaiztutar := 0;
                                log_at('cbs-timka_pd','faiz_0_tax_1',5,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                                ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                                ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                                ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                                ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                                ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                                ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);  
                                pkg_kredi.sp_Principal_Pastdue_Closing(
                                                         ln_pd_account_no,
                                                         ld_value_date,
                                                         ls_collection_currency,
                                                         ln_rate,
                                                         ln_related_account,
                                                         ln_collection_account,
                                                         ln_tahsedil_gecenyilfaiztutar,
                                                         ln_tahsedil_gecmis_aylar_faiz,
                                                         ln_tahsedil_birikmisfaiztutar,
                                                         ln_anapara_tahsilat_tutar,
                                                         ls_aciklama,
                                                         ls_choice,
                                                         ls_durum_kodu,
                                                         ls_pd_branch_cd,
                                                         ls_modul_tur_kod, 
                                                         ls_urun_tur_kod,
                                                         ls_urun_sinif_kod,
                                                         ls_past_due_currency,
                                                         ln_musteri_no
                                                         );
                         
                                ln_available_amount := nvl(round(ln_available_amount,2),0) - nvl(ln_anapara_tahsilat_tutar,0);  
                            end if;--bloke
                            log_at('cbs-timka_pd','faiz_0_tax_1',6,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);       
                        end if;
                        -------------------------TAX--------------------------------------------------------------
                    end if; --check balance of tax and faiz
                    
                end if;--main if after loop
            end loop;
            close cur_faiz_pd_after_2013;   
        end if; --close faiz and tax condition
    
        if trunc(ln_available_amount,2) > 0 then
            OPEN cur_def_int_after_2013_pd;
            loop
                fetch cur_def_int_after_2013_pd into r_def_int_after_2013_pd;
                exit when cur_def_int_after_2013_pd%notfound;
                ls_past_due_currency := r_def_int_after_2013_pd.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;
                ln_loan_account := r_def_int_after_2013_pd.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                ls_month_explanation := PKG_KREDI.WHAT_MONTH(r_def_int_after_2013_pd.ACILIS_TARIHI); --TemirlanT cbs-119
                log_at('cbs-timka_pd','after',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_loan_account='||ln_loan_account||' ls_month_explanation='||ls_month_explanation); 
                
                if trunc(ln_available_amount,2) > 0 then            
                
                    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_tax_rate);
                    Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_tax_rate_last_year);
                    ln_pd_account_no := r_def_int_after_2013_pd.hesap_no;
                    ln_gecenyil_faiz_tutari := abs(nvl(r_def_int_after_2013_pd.GECENYIL_FAIZ_TUTARI,0)); 
                    ln_gecmis_aylarin_faizi := abs(nvl(r_def_int_after_2013_pd.GECMIS_AYLARIN_FAIZI,0)); 
                    ln_birikmis_faiz_tutari := abs(nvl(r_def_int_after_2013_pd.BIRIKMIS_FAIZ_TUTARI,0));    
                    ln_tahsedil_gecenyilfaiztutar := 0;
                    ln_tahsedil_gecmis_aylar_faiz := 0;
                    ln_tahsedil_birikmisfaiztutar := 0;
                    ln_tax_last_year := 0;
                    ln_tax_last_month := 0;
                    ln_tax_cumulated := 0;
                    ln_toplam_faiz := ln_gecenyil_faiz_tutari + ln_gecmis_aylarin_faizi + ln_birikmis_faiz_tutari;
                                    
                    ln_toplam_tax :=      round(
                             (
                               (
                               (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))))*ln_tax_rate_last_year+
                               (Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))))*ln_tax_rate
                             )
                             /100
                            ),2
                            )
                            + round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                
                        log_at('cbs-timka_pd','after',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_gecenyil_faiz_tutari='||ln_gecenyil_faiz_tutari||' ln_birikmis_faiz_tutari='||ln_birikmis_faiz_tutari
                                                ||' ln_tax_rate='||ln_tax_rate||' ln_tax_rate_last_year='||ln_tax_rate_last_year
                                                ||' ln_gecmis_aylarin_faizi='||ln_gecmis_aylarin_faizi||' ls_past_due_currency='||ls_past_due_currency
                                                ||' ln_toplam_faiz='||ln_toplam_faiz||' ln_toplam_tax='||ln_toplam_tax);
                    if round(nvl(ln_available_amount,0),2) > 0 then  
                    
                        if ln_available_amount >= nvl(ln_toplam_faiz,0) + nvl(ln_toplam_tax,0) then
                            ls_choice := 'KAPAMA';
                            ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                            ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                            ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                            ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                            ln_available_amount := nvl(ln_available_amount,0) - (abs(ln_toplam_faiz) + ln_toplam_tax);        
                        else
                            ls_choice := 'GERI ODEME';
                            if round(nvl(ln_available_amount,0),2) > 0 then
                                if round(nvl(ln_gecenyil_faiz_tutari,0),2) > 0 then
                                    if ln_available_amount >= ln_gecenyil_faiz_tutari + (round((((nvl(ln_gecenyil_faiz_tutari,0))*ln_tax_rate_last_year )/100),2)) then
                                        ln_tahsedil_gecenyilfaiztutar := ln_gecenyil_faiz_tutari;
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecenyil_faiz_tutari, 0))) * ln_tax_rate_last_year) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecenyilfaiztutar,0) + ln_tax_last_year);
                                    
                                    else
                                        ln_tahsedil_gecenyilfaiztutar := round(ln_available_amount / (1 + ln_tax_rate_last_year / 100),2);
                                        ln_tax_last_year := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecenyilfaiztutar,0)))*ln_tax_rate_last_year )/100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecenyilfaiztutar + ln_tax_last_year);     
                                    end if;
                                end if;
                            end if;
                                
                            if trunc(nvl(ln_available_amount,0),2) > 0 then
                            
                                if round(nvl(ln_gecmis_aylarin_faizi,0),2) > 0 then 
                                    if ln_available_amount >= ln_gecmis_aylarin_faizi + (round((((nvl(ln_gecmis_aylarin_faizi,0))*ln_tax_rate )/100),2)) then
                                        ln_tahsedil_gecmis_aylar_faiz := ln_gecmis_aylarin_faizi;
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_gecmis_aylarin_faizi, 0))) * ln_tax_rate) / 100), 2);
                                        ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_gecmis_aylar_faiz,0) + ln_tax_last_month);
                                    else
                                        ln_tahsedil_gecmis_aylar_faiz := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                        ln_tax_last_month := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_gecmis_aylar_faiz,0))) * ln_tax_rate ) / 100),2);
                                        ln_available_amount := ln_available_amount - (ln_tahsedil_gecmis_aylar_faiz + ln_tax_last_month);  
                                    end if;
                                end if;
                                        
                                if trunc(nvl(ln_available_amount,0),2) > 0 then 
                                    if round(nvl(ln_birikmis_faiz_tutari,0),2) > 0 then
                                        if ln_available_amount >= ln_birikmis_faiz_tutari + (round(((nvl(ln_birikmis_faiz_tutari,0)*ln_tax_rate)/100),2)) then
                                            ln_tahsedil_birikmisfaiztutar := ln_birikmis_faiz_tutari;
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_birikmis_faiz_tutari, 0))) * ln_tax_rate) / 100), 2);
                                            ln_available_amount := nvl(ln_available_amount,0) - (nvl(ln_tahsedil_birikmisfaiztutar,0) + ln_tax_cumulated);
                                        else
                                            ln_tahsedil_birikmisfaiztutar := round(ln_available_amount / (1 + ln_tax_rate / 100),2);
                                            ln_tax_cumulated := round(((Pkg_Kur.yuvarla(ls_past_due_currency, ABS(nvl(ln_tahsedil_birikmisfaiztutar,0))) * ln_tax_rate ) / 100),2);
                                            ln_available_amount := ln_available_amount - (ln_tahsedil_birikmisfaiztutar + ln_tax_cumulated);
                                        end if;
                                    end if;
                                end if;
                                    
                            end if;
                        end if;
                        
                    end if;
                    -----------------------------------
                    ln_faizler := ln_tahsedil_gecenyilfaiztutar + ln_tahsedil_gecmis_aylar_faiz + ln_tahsedil_birikmisfaiztutar + ln_tax_last_year + ln_tax_last_month + ln_tax_cumulated;
                    log_at('cbs-timka_pd','after',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ln_gecenyil_faiz_tutari='||ln_gecenyil_faiz_tutari||' ln_birikmis_faiz_tutari='||ln_birikmis_faiz_tutari
                                                ||' ln_tax_rate='||ln_tax_rate||' ln_tax_rate_last_year='||ln_tax_rate_last_year
                                                ||' ln_gecmis_aylarin_faizi='||ln_gecmis_aylarin_faizi||' ls_past_due_currency='||ls_past_due_currency
                                                ||' ln_tax_cumulated='||ln_tax_cumulated||' ln_tax_last_month='||ln_tax_last_month);        
               
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_pd_account_no 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                
                    log_at('cbs-timka_pd','after',5,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
                
                    if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                                          
                        ls_modul_tur_kod := r_def_int_after_2013_pd.modul_tur_kod;
                        ls_urun_tur_kod := r_def_int_after_2013_pd.urun_tur_kod;
                        ls_urun_sinif_kod := r_def_int_after_2013_pd.urun_sinif_kod;                    
                        ln_pd_balance := r_def_int_after_2013_pd.pd_balance;
                        ls_pd_branch_cd := r_def_int_after_2013_pd.sube_kodu;
                        ls_son_gun_faizi := r_def_int_after_2013_pd.son_gun_faizi;
                                        
                        if ls_son_gun_faizi = 'E' then
                            pkg_kredi.Sp_Kredi_Kapama_FaizKomis_Bul(ln_pd_account_no,ln_faiz_tutari,ln_komisyon_tutari,pkg_tarih.TARIHTEN_SONRAKI_ISGUNU( pkg_muhasebe.banka_tarihi_bul)) ; 
                            ln_birikmis_faiz_tutari := abs(nvl(ln_birikmis_faiz_tutari,0)) + abs(nvl(ln_faiz_tutari,0));
                        end if; 

                        ld_value_date := null;              
                        ls_collection_currency := ls_account_currency;
                                      
                        if ls_past_due_currency <> PKG_GENEL.LC_AL and ls_collection_currency = PKG_GENEL.LC_AL then
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','S');
                        else
                            ln_rate := pkg_kur.doviz_doviz_karsilik(ls_past_due_currency, pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        end if;                    
                        
                        ln_related_account := ln_related_account_pd;
                        ln_collection_account := null;
                        ls_collection_currency := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_related_account);
                        
                        if ln_pd_balance <> 0 then
                            ls_choice := 'GERI ODEME';
                        end if;
                        log_at('cbs-timka_pd','after',5,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                ||' ls_choice='||ls_choice||' ls_collection_currency='||ls_collection_currency);    
                        ln_anapara_tahsilat_tutar := 0;
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_def_int_after_2013_pd.acilis_tarihi;
                        --BOM TemirlanT
                        pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                        if ln_delayed_days=1 then
                            ls_day := SUBSTR (ls_day, 1, 4);
                        elsif ln_delayed_days in (2,3,4) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                            ls_day := SUBSTR (ls_day, 10, 4);
                        elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        else
                            ls_day := SUBSTR (ls_day, 10, 4);
                        end if;
                        --EOM TemirlanT   
                        pkg_parametre.deger('G_PD_ELEVATED_EXPLANATION',ls_aciklama);
                        ls_aciklama := REPLACE (ls_aciklama, '$$$', ln_delayed_days);
                        ls_aciklama := REPLACE (ls_aciklama, '@@@', ls_day);
                        ls_aciklama := REPLACE (ls_aciklama, '###', ls_month_explanation);
                        ls_aciklama := REPLACE (ls_aciklama, '***', ln_loan_account);
                        ls_aciklama := REPLACE (ls_aciklama, '&&&', ls_name_surname); --TemirlanT timka 
                        if ls_choice = 'KAPAMA' then 
                            ls_durum_kodu := 'K';
                            ls_aciklama := REPLACE (ls_aciklama, '%%%');
                        else
                            ls_durum_kodu := 'A';
                            ls_aciklama := REPLACE (ls_aciklama, '%%%', ls_part);--TemirlanT
                        end if;
                        
                   
                        log_at('cbs-timka_pd','after',6,'ln_pd_account_no='||ln_pd_account_no||' ld_value_date='||ld_value_date
                               ||' ls_collection_currency='||ls_collection_currency||' ln_rate='||ln_rate
                               ||' ln_related_account='||ln_related_account||' ln_collection_account='||ln_collection_account
                               ||' ln_tahsedil_gecenyilfaiztutar='||ln_tahsedil_gecenyilfaiztutar||' ln_tahsedil_gecmis_aylar_faiz='||ln_tahsedil_gecmis_aylar_faiz
                               ||' ln_tahsedil_birikmisfaiztutar='||ln_tahsedil_birikmisfaiztutar||' ln_anapara_tahsilat_tutar='||ln_anapara_tahsilat_tutar
                               ||' ls_aciklama='||ls_aciklama||' ls_durum_kodu='||ls_durum_kodu
                               ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                               ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                               ||' ls_past_due_currency='||ls_past_due_currency||' ln_musteri_no='||ln_musteri_no);     
                        pkg_kredi.sp_Principal_Pastdue_Closing(
                                                     ln_pd_account_no,
                                                     ld_value_date,
                                                     ls_collection_currency,
                                                     ln_rate,
                                                     ln_related_account,
                                                     ln_collection_account,
                                                     ln_tahsedil_gecenyilfaiztutar,
                                                     ln_tahsedil_gecmis_aylar_faiz,
                                                     ln_tahsedil_birikmisfaiztutar,
                                                     ln_anapara_tahsilat_tutar,
                                                     ls_aciklama,
                                                     ls_choice,
                                                     ls_durum_kodu,
                                                     ls_pd_branch_cd,
                                                     ls_modul_tur_kod, 
                                                     ls_urun_tur_kod,
                                                     ls_urun_sinif_kod,
                                                     ls_past_due_currency,
                                                     ln_musteri_no
                                                     );
                     
                    end if; --bloke
                    log_at('cbs-timka_pd','after',7,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                end if;
            
            end loop;
            close cur_def_int_after_2013_pd; 
        end if;  
    
        if trunc(ln_available_amount,2) > 0 then
            open cur_penalty_pd_after_2013;
            loop
                fetch cur_penalty_pd_after_2013 into r_penalty_pd_after_2013;
                exit when cur_penalty_pd_after_2013%notfound;
                log_at('check_in','cur_penalty_pd_after_2013','ln_available_amount '||ln_available_amount);
                ls_past_due_currency := r_penalty_pd_after_2013.doviz_kodu;
                ln_acc_amount_before := ln_available_amount;
                ln_loan_account := r_penalty_pd_after_2013.ANA_KREDI_HESAP_NO;  --TemirlanT cbs-119
                log_at('cbs-timka_pd','penalty',1,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
                if trunc(ln_available_amount,2) > 0 then 
                
                    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);                    
                    
                    ln_related_account_penalty := r_penalty_pd_after_2013.hesap_no;
                    ln_amount_penalty := r_penalty_pd_after_2013.penalty_amount;
                    ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                    
                    if round(ln_available_amount,2) < nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);                  
                    elsif round(ln_available_amount,2) = nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                        ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);                  
                    elsif round(ln_available_amount,2) > nvl(r_penalty_pd_after_2013.penalty_amount,0) then
                        if round(ln_available_amount,2) >= nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := r_penalty_pd_after_2013.penalty_amount;
                            ln_paid_tax_amount := ln_amount_penalty * (ln_service_tax_rate / 100);
                        elsif round(ln_available_amount,2) < nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0) then
                            ln_amount_penalty := round((ln_available_amount/((ln_service_tax_rate/100) + 1)),2);
                            ln_paid_tax_amount := round(NVL(ln_amount_penalty,0)*NVL(ln_service_tax_rate,0)/100,2);
                        end if;         
                    end if;
                    
                    ln_total_collection_amount := nvl(ln_amount_penalty,0) + nvl(ln_paid_tax_amount,0);
                   log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ln_amount_penalty='||ln_amount_penalty||' ln_paid_tax_amount='||ln_paid_tax_amount); 
                    
                    begin---------------------rahat
                        select iliskili_hesap_no
                        into ln_related_account_pd
                        from cbs_hesap_kredi
                        where hesap_no = ln_related_account_penalty 
                        and pkg_hesap.HesaptanDurumAl(iliskili_hesap_no) = 'A' 
                        and pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) = ls_past_due_currency;
                    exception when others then
                        ln_related_account_pd := null;
                    end;
                    
                    if ln_current_account = ln_related_account_pd then
                        lb_block := false;
                    end if;
                    
                    if  lb_block = false then --???? ??? ????? ?? ????? ?????, ?? ???????????? ?????????? ????????? ???????
                        
                        log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ls_account_currency='||ls_account_currency||' ln_current_account='||ln_current_account);
                        ls_cash_account := 'ACCOUNT';
                        ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_current_account_2);
                        ln_customer_no := ln_musteri_no;
                        ls_residency_code := pkg_musteri.sf_get_residency_code (ln_customer_no);
                        ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_customer_no);
                        ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no );
                        ls_income_type := 'LOANCOMM';

                        ls_vat := 'N';
                        ls_service_tax := 'Y';
                        ls_tax_coll_type := 'PS';--PAID SEPERATELY                    
                        ln_rate_penalty := pkg_kur.doviz_doviz_karsilik(ls_currency_code,pkg_genel.lc_al,null,1,1,null,null,'N','A');
                        ln_collection_account_penalty := ln_related_account_pd;
                        ls_collection_currency_penalty := PKG_HESAP.HESAPTANDOVIZKODUAL(ln_collection_account_penalty);
                        pkg_parametre.deger('G_PD_PENALTY',ls_income_gl);
                        ln_delayed_days := PKG_MUHASEBE.BANKA_TARIHI_BUL - r_penalty_pd_after_2013.acilis_tarihi;
                        --BOM TemirlanT
                        select ACIKLAMA into ls_dk_explanation from CBS_DKHESAP 
                            where numara=r_penalty_pd_after_2013.ana_dk_no and bolum_kodu=r_penalty_pd_after_2013.sube_kodu and doviz_kod=r_penalty_pd_after_2013.doviz_kodu;
                        pkg_parametre.deger('G_PD_SECTOR_EXPLANATION',ls_sector_explanation);
                        if (instr(ls_dk_explanation,'Mortgage') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 1, 4);
                        elsif (instr(ls_dk_explanation,'Agriculture') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 6, 3);
                        elsif (instr(ls_dk_explanation,'Industry') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 10, 4);
                        elsif (instr(ls_dk_explanation,'construction') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 15, 6);
                        elsif (instr(ls_dk_explanation,'individual') > 0) or (instr(ls_dk_explanation,'Consumer') > 0) then
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 22, 4);
                        else 
                            ls_sector_explanation := SUBSTR (ls_sector_explanation, 27, 4);
                        end if;
                        
                        pkg_parametre.deger('G_PD_DAY_EXPLANATION',ls_day);
                        if ln_delayed_days=1 then
                            ls_day := SUBSTR (ls_day, 1, 4);
                        elsif ln_delayed_days in (2,3,4) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        elsif ln_delayed_days >= 5 and ln_delayed_days <= 21 then
                            ls_day := SUBSTR (ls_day, 10, 4);
                        elsif ln_delayed_days >= 22 and (mod(ln_delayed_days,10)  in (2,3,4)) then
                            ls_day := SUBSTR (ls_day, 6, 3);
                        else
                            ls_day := SUBSTR (ls_day, 10, 4);
                        end if;
                        pkg_parametre.deger('G_PD_PENALTY_EXPLANATION',ls_explanation);
                        ls_explanation := REPLACE (ls_explanation, '$$$', ln_delayed_days);
                        ls_explanation := REPLACE (ls_explanation, '@@@', ls_day);
                        ls_explanation := REPLACE (ls_explanation, '***', ln_loan_account);
                        ls_explanation := REPLACE (ls_explanation, '&&&', ls_name_surname);
                        ls_explanation := REPLACE (ls_explanation, '###', ls_sector_explanation); --TemirlanT timka
                        --ls_explanation := '???? ?? ' || ln_delayed_days || ' ' || ls_day || ' ?? ?????. ????????+??? (' || ln_loan_account || ') - ' || ls_name_surname || ls_sector_explanation;  --TemirlanT
                        --EOM TemirlanT                      
                        ls_modul_tur_kod := 'CURR.OPS.';
                        ls_urun_tur_kod := 'CHARGE';
                        ls_urun_sinif_kod := 'GENERAL';
                        ls_pd_branch_cd := r_penalty_pd_after_2013.sube_kodu;
                        log_at('cbs-timka_pd','penalty',3,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance
                                                    ||' ls_cash_account='||ls_cash_account||' ls_currency_code='||ls_currency_code
                                                    ||' ln_customer_no='||ln_customer_no||' ls_residency_code='||ls_residency_code
                                                    ||' ls_citizen_code='||ls_citizen_code||' ls_customer_type='||ls_customer_type
                                                    ||' ls_income_type='||ls_income_type||' ln_related_account_penalty='||ln_related_account_penalty
                                                    ||' ln_amount_penalty='||ln_amount_penalty||' ls_vat='||ls_vat
                                                    ||' ls_service_tax='||ls_service_tax||' ln_service_tax_rate='||ln_service_tax_rate
                                                    ||' ls_tax_coll_type='||ls_tax_coll_type||' ln_paid_tax_amount='||ln_paid_tax_amount
                                                    ||' ln_total_collection_amount='||ln_total_collection_amount||' ls_collection_currency_penalty='||ls_collection_currency_penalty
                                                    ||' ln_rate_penalty='||ln_rate_penalty||' ln_collection_account_penalty='||ln_collection_account_penalty
                                                    ||' ls_income_gl='||ls_income_gl||' ls_explanation='||ls_explanation
                                                    ||' ls_pd_branch_cd='||ls_pd_branch_cd||' ls_modul_tur_kod='||ls_modul_tur_kod
                                                    ||' ls_urun_tur_kod='||ls_urun_tur_kod||' ls_urun_sinif_kod='||ls_urun_sinif_kod
                                                    ||' ln_current_account='||ln_current_account);
                        pkg_kredi.sp_penalty_Pastdue_Closing(
                                                            ls_cash_account ,
                                                            ls_currency_code ,
                                                            ln_customer_no ,
                                                            ls_residency_code,
                                                            ls_citizen_code,
                                                            ls_customer_type, 
                                                            ls_income_type, 
                                                            ln_related_account_penalty,
                                                            ln_amount_penalty,
                                                            ls_vat,
                                                            ls_service_tax,
                                                            ln_service_tax_rate,
                                                            ls_tax_coll_type,
                                                            ln_paid_tax_amount,
                                                            ln_total_collection_amount,
                                                            ls_collection_currency_penalty,
                                                            ln_rate_penalty,
                                                            ln_collection_account_penalty,
                                                            ls_income_gl,
                                                            ls_explanation,
                                                            ls_pd_branch_cd,
                                                            ls_modul_tur_kod,
                                                            ls_urun_tur_kod,
                                                            ls_urun_sinif_kod,
                                                            ln_current_account
                                                            );
                                                           
                        ln_available_amount := nvl(ln_available_amount,0) - nvl(ln_total_collection_amount,0);
                    end if; -- bloke
 
                end if;
            log_at('cbs-timka_pd','penalty',4,'ln_available_amount='||ln_available_amount||' ln_general_balance='||ln_general_balance);
            end loop;
            close cur_penalty_pd_after_2013;    
        end if;        
    --end if;
 END LOOP;
 CLOSE c_credited_cust;
 
 exception
 when others then
 log_at('pkg_kredi_pd_closing','tahsilat', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); 
 rollback;
 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4668' ||  Pkg_Hata.getdelimiter|| ln_current_account || Pkg_Hata.getdelimiter || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


end;
--EOM aisuluud CQ4883 TemirlanT cbs-119

FUNCTION  get_priority(pn_priority number) RETURN boolean
 IS
    ln_count  number;  -- DK veya KURUM doner
BEGIN

    SELECT count(*)
    INTO   ln_count
    FROM   cbs_tahsilat_kurum_grup_tanim
    WHERE  PRIORITY = pn_priority 
    and gecerlimi = 'E';

    if ln_count > 0 then
       RETURN  true;
    end if;

   RETURN  false;
 EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN false;
      WHEN OTHERS THEN
        RETURN false;

END ;
   
END;
/

