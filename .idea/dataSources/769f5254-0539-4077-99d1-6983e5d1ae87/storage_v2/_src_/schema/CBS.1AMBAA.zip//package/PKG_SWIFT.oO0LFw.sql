create PACKAGE     "PKG_SWIFT" IS

----------------------------------------------------------------------------------------------------------
FUNCTION GetMubabirAccountNo(ps_currcode IN VARCHAR2) RETURN NUMBER;
----------------------------------------------------------------------------------------------------------
FUNCTION GetMubabirBICCode(pn_customer_no IN NUMBER) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------------------
FUNCTION sf_mesaj_tipi_donustur(ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2 ;
TYPE Generic_CurType IS REF CURSOR;
CURSOR cur_hata(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
SELECT  b.DATABLOCK_NAME DATABLOCK, b.ITEM_NAME ITEM
FROM    SWTARAPF_CBS a, CBS_SWIFT_MESAJ_DETAIL_MAP b
WHERE     b.islem_kod    = pn_islem_kod
AND     Pkg_Swift.sf_mesaj_tipi_donustur(b.FLDTYP)    = a.ARATYP
AND     b.FLDTYP    = ps_mesaj_tipi
AND     b.FLDIDX      = a.ARAIDX
AND     b.FLDNAM      = a.ARAKOD
AND     b.FLDSNO      = a.ARASNO
AND     ARAERR         IS NOT NULL
AND     a.ARASRN IN (SELECT SASRN FROM SWTTRNPF WHERE TX_NO = pn_islem_no AND ssts NOT IN ('CANCL'));

   row_hata cur_hata%ROWTYPE;

CURSOR cur_BLKLIST(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
SELECT  b.DATABLOCK_NAME DATABLOCK, b.ITEM_NAME ITEM
FROM    SWTFNDBLC a,  CBS_SWIFT_MESAJ_DETAIL_MAP b
WHERE     b.islem_kod    = pn_islem_kod
AND     Pkg_Swift.sf_mesaj_tipi_donustur(b.FLDTYP)     = a.MESSAGETYPE
AND     b.FLDTYP    = ps_mesaj_tipi
AND     b.FLDIDX      = a.FIELDIDX
AND     b.FLDNAM      = trim(a.FIELDNAME)
AND     b.FLDSNO      = a.FIELDSNO
AND     a.MESSAGENO IN (SELECT SASRN FROM SWTTRNPF WHERE TX_NO = pn_islem_no AND ssts NOT IN ('CANCL'));
row_BLKLIST cur_blklist%ROWTYPE;


CURSOR cur_hatasiz(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
SELECT  b.DATABLOCK_NAME DATABLOCK, b.ITEM_NAME ITEM
FROM    SWTARAPF_CBS a, CBS_SWIFT_MESAJ_DETAIL_MAP b
WHERE     b.islem_kod    = pn_islem_kod
AND     Pkg_Swift.sf_mesaj_tipi_donustur(b.FLDTYP)     = a.ARATYP
AND     b.FLDTYP    = ps_mesaj_tipi
AND     b.FLDIDX      = a.ARAIDX
AND     b.FLDNAM      = a.ARAKOD
AND     b.FLDSNO      = a.ARASNO
AND     ARAERR         IS NULL
AND     b.ITEM_NAME IS NOT NULL
AND     a.ARASRN IN (SELECT SASRN FROM SWTTRNPF WHERE TX_NO = pn_islem_no AND ssts NOT IN ('CANCL'));

   row_hatasiz cur_hatasiz%ROWTYPE;

PROCEDURE open_cur_hata(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) ;
PROCEDURE fetch_cur_hata(row_hata OUT cur_hata%ROWTYPE, ls_ok OUT VARCHAR2);
PROCEDURE close_cur_hata;

PROCEDURE open_cur_blklist(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) ;
PROCEDURE fetch_cur_blklist(row_blklist OUT cur_blklist%ROWTYPE, ls_ok OUT VARCHAR2);
PROCEDURE close_cur_blklist;

PROCEDURE open_cur_hatasiz(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) ;
PROCEDURE fetch_cur_hatasiz(row_hatasiz OUT cur_hatasiz%ROWTYPE, ls_ok OUT VARCHAR2);
PROCEDURE close_cur_hatasiz;

FUNCTION  SF_KAYIT_NUMARASI_AL RETURN NUMBER ;
FUNCTION  SF_KAYIT_NO(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER;
FUNCTION  SF_ISLEM_KAYDEDILDI_MI(pn_islem_kod NUMBER,pn_islemno NUMBER) RETURN VARCHAR2;
PROCEDURE MESAJ_OLUSTUR (pn_islem_kod NUMBER,
                             pn_islem_no NUMBER ,
                      ps_black_list_kontrol VARCHAR2,
                      ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                      ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                      ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                      ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                      ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL,
                      ps_cevap          OUT VARCHAR2
                      );
PROCEDURE SP_MESAJ_HEADER_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2,ps_black_list VARCHAR2);
PROCEDURE SP_MESAJ_DETAY_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2);
PROCEDURE SP_MESAJ_RPT_DETAY_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2);

 PROCEDURE SP_DETAY_KAYDI_INSERT_ET(  pn_islem_kod IN NUMBER,    -- islem kod
                                          pn_islem_no IN NUMBER,    -- islem numarasi
                                          ps_FLDMTP VARCHAR2,    -- 103,202 gibi mesaj tipleri
                                      ps_FLDNAM VARCHAR2,
                                          pn_FLDIDX NUMBER,
                                      pn_FLDSNO NUMBER,
                                      ps_FLDTXT  VARCHAR2,     -- alanin icerdigi bilgi
                                      pn_FLDRPT NUMBER DEFAULT 1 );--FLDRPT -- > 950 mesajdaki 60 sahasi gibi tekrarli sahalarda, kacinci tekrar oldugunu ifade eder.
FUNCTION  SF_MESAJ_GONDER(ps_text IN VARCHAR2) RETURN VARCHAR2 ;
FUNCTION  SF_DRAFT(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_SEND(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_PARSE_ET_SONUCU_AL(ps_text IN VARCHAR2) RETURN VARCHAR2 ;
PROCEDURE SF_MESAJA_KARSI_GELEN_ALAN( pn_islem_kod NUMBER,
                                          pn_islemno NUMBER ,ps_mesaj_tipi  VARCHAR2,
                                        ps_table_name OUT VARCHAR2,
                                  ps_field_name OUT VARCHAR2,
                                  ps_datablock_name OUT VARCHAR2,
                                  ps_item_name OUT VARCHAR2) ;
PROCEDURE SP_HATALI_ALANI_BUL(pn_islem_kod NUMBER,pn_islemno IN NUMBER,ps_mesaj_tipi  VARCHAR2 DEFAULT NULL,
                                  pRetCur  IN OUT Generic_CurType) ;
PROCEDURE SP_BLACK_LIST_ALANI_BUL(pn_islem_kod NUMBER,pn_islemno IN NUMBER,ps_mesaj_tipi  VARCHAR2 DEFAULT NULL,
                                  pRetCur  IN OUT Generic_CurType);
FUNCTION  SF_MESAJ_STATU_AL(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2 ;
FUNCTION  SF_HATA_ACIKLAMASI_al(ps_hatano IN VARCHAR2) RETURN VARCHAR2;
PROCEDURE SP_MESAJ_STATU_UPDATE(pn_islemno IN NUMBER,ps_statu  SWTTRNPF.SSTS%TYPE ,ps_mesaj_tipi VARCHAR2  DEFAULT NULL);
PROCEDURE SP_UPDATE_DRAFT(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL);
PROCEDURE SP_UPDATE_RED(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL);
PROCEDURE SP_UPDATE_READY(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL);
FUNCTION  SF_MESAJ_ACIKLAMASI_AL(ps_mesaj IN VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_BIC_KODU RETURN VARCHAR2;
FUNCTION  SF_SUBE RETURN VARCHAR2;
FUNCTION  SF_DEPARTMAN RETURN VARCHAR2 ;
FUNCTION  SF_DELIVERY RETURN VARCHAR2;
FUNCTION  SF_PRIORTY RETURN VARCHAR2;
FUNCTION  SF_KULLANICI RETURN VARCHAR2;
FUNCTION  SF_UZUN_MESAJ_FORMATLA(ps_text IN VARCHAR2,pn_len IN NUMBER) RETURN VARCHAR2;
FUNCTION  SF_TABLO_ISLEM_ALAN_ADI_AL(ps_table_name IN VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_TABLO_ORDERBY_ALAN_ADI_AL(ps_table_name IN VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_VALOR(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER    ;
FUNCTION  SF_DOVIZ(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_BIC(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2 ;
FUNCTION  SF_TUTAR(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER;
FUNCTION  SF_20(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2;
FUNCTION  SF_21(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2;
FUNCTION  Swift_kontrolu_yapilsin(pn_islem_kod NUMBER DEFAULT NULL) RETURN VARCHAR2;
PROCEDURE SP_MESAJ_SIL(pn_islemno IN NUMBER );
PROCEDURE Kontrol_Sonrasi (pn_islem_kod NUMBER,
                               pn_islem_no NUMBER ,
                         ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                         ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                         );
PROCEDURE Dogrulama_Sonrasi (pn_islem_kod NUMBER,
                               pn_islem_no NUMBER ,
                         ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                         ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                         ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                         );
PROCEDURE Onay_Sonrasi (pn_islem_kod NUMBER,
                            pn_islem_no NUMBER ,
                   ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                   ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                   ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                   ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                   ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                   ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                   );
PROCEDURE Muhasebelesme_Sonrasi (pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2);

FUNCTION sf_Musteri_BIC_Al(pn_musteri_no NUMBER) RETURN VARCHAR2;
FUNCTION sf_mesaj_txt_al(pn_islem_no NUMBER) RETURN VARCHAR2;
PROCEDURE SP_MESAJ_BLACKLISTFLAG_UPDATE(pn_islemno IN NUMBER,ps_flag  SWTTRNPF.BLFLAG %TYPE );
FUNCTION  sf_turkce_char_cevir(ps_string VARCHAR2) RETURN  VARCHAR2;
FUNCTION  sf_bic_gecerlimi(ps_bic VARCHAR2) RETURN  VARCHAR2;

FUNCTION swift_ip_al RETURN VARCHAR2;
FUNCTION swift_port_al RETURN NUMBER;
PROCEDURE Batch_Onay_Sonrasi (pn_islem_kod NUMBER,pn_islem_no NUMBER ,
                           ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                           ps_mesaj_tipi VARCHAR2 DEFAULT NULL );

FUNCTION Relse_Mesaj_Varmi(pn_islem_no NUMBER ,ps_mesaj_tipi VARCHAR2 ) RETURN VARCHAR2 ;
FUNCTION Muafiyet(ps_aratyp VARCHAR2, pn_araidx NUMBER, ps_arakod VARCHAR2, pn_arasno NUMBER) RETURN VARCHAR2 ;
PROCEDURE Sp_Islem_Turu_Map_Kaydet(pn_swift_no LONG, pn_islemno  NUMBER, ps_mesaj_tipi VARCHAR2);
FUNCTION bic_adi_yazan_text(ps_str IN VARCHAR2) RETURN VARCHAR2;
FUNCTION bic_adi(ps_bic_code IN VARCHAR2) RETURN VARCHAR2;
FUNCTION swift_hata_Aciklamasi(ps_hata_kodu IN VARCHAR2) RETURN VARCHAR2; --sevalb 27052011
PROCEDURE Sp_hata_Log_Kaydet(pn_islem_no NUMBER, pn_kayit_no NUMBER, ps_mesaj_tipi VARCHAR2, ps_hata_kodu VARCHAR2,ps_mesaj_durum_kodu VARCHAR2);--sevalb  23022012 sdlc23773_AplicationShow errors in screen 4003 from SKYJAVA
FUNCTION  SF_MESAJ_SSTS_AL(pn_SASRN NUMBER) RETURN VARCHAR2 ;
FUNCTION sf_yasakli_ulke_mi(ps_ulke_kodu IN VARCHAR2) RETURN VARCHAR2;
END;
/

