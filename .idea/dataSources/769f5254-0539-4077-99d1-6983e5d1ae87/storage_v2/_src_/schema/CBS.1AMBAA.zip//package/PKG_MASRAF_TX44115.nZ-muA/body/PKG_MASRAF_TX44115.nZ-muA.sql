create PACKAGE BODY     pkg_masraf_tx44115  IS

p_44115_HABR_TRL number;        	--HABERLE?ME TRL
p_44115_POSTA_TRL number;        	--POSTA MASRAFI TRL
p_44115_KOM_TOPLAMI number;        	--TOPLAM TRL MASRAF
p_44115_M_HESAP number;        		--MASRAF HESAP NO
p_44115_M_HESAP_DVZ number;         --MASRAF HESAP TRL DE??L
p_44115_MHESAP_SUBE number;         --MASRAF HESABININ ?UBES?
p_44115_ISLEM_SUBE number;        	--??LEM YAPILAN ?UBE
p_44115_TEYIT_MDV number;        	--TEYIT MASRAF HESAP D?V?Z? KARSILI?I
p_44115_IHBAR_MDV number;        	--?HBAR MASRAF HESAP D?V?Z? KAR?ILI?I
p_44115_HABR_MDV number;        	--HABERLE?ME MASRAF HESAP D?V?Z? KAR?ILI?I
p_44115_POSTA_MDV number;       	--POSTA MASRAF HESAP D?V?Z? KAR?ILI?I
p_44115_KOM_MDV_TOPLAM number;      --TOPLAM MASRAF, MASRAF HESAP D?V?Z? KAR?ILI?I
p_44115_MAS_ACIKLAMA number;        --ANA F?? A?IKLAMASI
p_44115_MAS_TEY_ACIKLAMA number;    --TEYIT BOLUM A?IKLAMASI
p_44115_MAS_HABR_ACIKLAMA number;   --HABR BOLUM A?IKLAMASI
p_44115_MAS_IHBAR_ACIKLAMA number;  --IHBAR BOLUM A?IKLAMASI
p_44115_MAS_POST_ACIKLAMA number;   --POSTA BOLUM A?IKLAMASI
p_44115_KUR_TUTAR number;        	--KUR B?LG?S?
p_44115_TEYIT_VAR number;        	--TEYIT MASRAFI VAR
p_44115_IHBAR_VAR number;        	--IHBAR MASRAFI VAR
p_44115_HABR_VAR number;        	--HABERLE?ME MASRAFI VAR
p_44115_POSTA_VAR number;        	--POSTA MASRAFI VAR
p_44115_M_HESAP_TRL number;        	--MASRAF HESAP TRL
p_44115_MHESAP_DVZ number;        	--MASRAF HESABININ D?V?Z?
p_44115_TEYIT_TRL number;        	--TEYIT TRL KARSILI?I
p_44115_IHBAR_TRL number;        	--IHBAR TRL KARSILIK
p_44115_MAS_TP_ANA number;			--ANA MASRAF HESABI
p_44115_MAS_YP_ANA number;			--ANA MASRAF HESABI
p_44115_KOMISYON_DK number;
p_44115_DVBSMV_EVET number;
p_44115_ODEYEN_LEHDAR number;
p_44115_BSMV_TRL number;
p_44115_BSMV_MDV number;
p_44115_MASKOMBSMV_TOPLAM number;

/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'VERGARKOM');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   Null;
  End;
/*------------------------------------------------------------------------------------------------------*/

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is	-- Islem iptal edilemez
  begin
    --status iptal konumuna getirilir ve tahsil edilen vs. oldu?u gibi b?rak?l?r...
    update cbs_masraf_ith_ihr
	   set durum = 'IPTAL'
	 where referans = ps_ref
	   and vs_no = 0
	   and sira_no in (select sira_no from cbs_masraf_ith_ihr_isl
	                   where islem_no = pn_islem_no);

    --masraf logu iptal edilir....
    update cbs_masraf_ith_ihr_ipt_log
	   set durum = 'IPTAL'
	 where islem_no = pn_islem_no;

    update cbs_masraf_ith_ihr_isl
	   set durum = 'IPTAL'
	 where islem_no = pn_islem_no;

  end;

 /*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_tahsil_tutar		  number;
   ln_bsmv_trl number;

   --ls_referans........

   cursor cur_masraf is
    select *
	 from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	 order by sira_no
	for update;
	row_masraf cur_masraf%rowtype;

   cursor cur_tmhg is
     select * from CBS_TM_VERILEN_GARANTI_ISLEM
	  where tx_no = pn_islem_no;
	  row_tmhg cur_tmhg%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
  --buraya geldiyse masraf ?demesi vard?r. Tarih kontrol? sadece taksitlerde yap?l?r.
  --E?er fi? kesilmesi istenmiyorsa, bu fonksiyon ?a?r?lmamal?d?r....
    ln_fis_no := pn_fis_no;
	open cur_tmhg;
	fetch cur_tmhg into row_tmhg;
	 ls_akr_doviz := row_tmhg.doviz_kodu;
	 varchar_list(p_44115_M_HESAP):=row_tmhg.masraf_hesap_no;

----------------
	 if row_tmhg.masraf_hesap_no is not null then
	    varchar_list(p_44115_MHESAP_DVZ):= pkg_hesap.HesaptanDovizKoduAl(row_tmhg.masraf_hesap_no);
	    varchar_list(p_44115_MHESAP_SUBE) := pkg_hesap.HesapSubeAl(row_tmhg.masraf_hesap_no);
 	    number_list(p_44115_KUR_TUTAR) := pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),1);
	  else
	      varchar_list(p_44115_MHESAP_DVZ):='';
	      varchar_list(p_44115_MHESAP_SUBE) :='';
	 end if;
----------------

	 varchar_list(p_44115_ISLEM_SUBE) := pkg_tx.Islem_BolumKodu_Al(pn_islem_no);
	 ls_referans := row_tmhg.referans;
	close cur_tmhg;
    if varchar_list(p_44115_MHESAP_DVZ) = pkg_genel.LC_AL then
	 boolean_list(p_44115_M_HESAP_TRL) := TRUE;
	 boolean_list(p_44115_M_HESAP_DVZ) := FALSE;
	else
	 boolean_list(p_44115_M_HESAP_TRL) := FALSE;
	 boolean_list(p_44115_M_HESAP_DVZ) := TRUE;
	end if;
	boolean_list(p_44115_MAS_TP_ANA) := FALSE;
	boolean_list(p_44115_MAS_YP_ANA) := FALSE;
	number_list(p_44115_HABR_TRL) := 0;
	number_list(p_44115_HABR_MDV) := 0;
	varchar_list(p_44115_MAS_HABR_ACIKLAMA) := '';
	boolean_list(p_44115_HABR_VAR) := FALSE;
	number_list(p_44115_POSTA_TRL) := 0;
	number_list(p_44115_POSTA_MDV) := 0;
	varchar_list(p_44115_MAS_POST_ACIKLAMA) := '';
	boolean_list(p_44115_POSTA_VAR) := FALSE;
	number_list(p_44115_TEYIT_TRL) := 0;
	number_list(p_44115_TEYIT_MDV) := 0;
	varchar_list(p_44115_MAS_TEY_ACIKLAMA) := '';
	boolean_list(p_44115_TEYIT_VAR) := FALSE;
	number_list(p_44115_IHBAR_TRL) := 0;
	number_list(p_44115_IHBAR_MDV) := 0;
	varchar_list(p_44115_MAS_IHBAR_ACIKLAMA) := '';
	boolean_list(p_44115_IHBAR_VAR) := FALSE;

	number_list(p_44115_KOM_TOPLAMI) := 0;
	number_list(p_44115_KOM_MDV_TOPLAM) := 0;
	varchar_list(p_44115_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' M??teri No:'||row_tmhg.LEHDAR_MUSTERI_NO
								   ||' -'||pkg_musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);

	/*
	if row_tmhg.doviz_kodu=pkg_genel.lc_al then
	  case row_tmhg.mektup_tipi
	   when 'GECICI' then  varchar_list(p_44115_KOMISYON_DK) :='74800000';
	   when 'KESIN' then  varchar_list(p_44115_KOMISYON_DK) :='74800100';
	   when 'AVANS' then  varchar_list(p_44115_KOMISYON_DK) :='74800200';
	   when 'SERBEST' then  varchar_list(p_44115_KOMISYON_DK) :='74800300';
	   end case;
	ELSE
    	  case row_tmhg.mektup_tipi
    	   when 'GECICI' then  varchar_list(p_44115_KOMISYON_DK) :='74900000';
    	   when 'KESIN' then  varchar_list(p_44115_KOMISYON_DK) :='74900100';
    	   when 'AVANS' then  varchar_list(p_44115_KOMISYON_DK) :='74900200';
    	   when 'SERBEST' then  varchar_list(p_44115_KOMISYON_DK) :='74900300';
    	   end case;
    end if;
     */
    boolean_list(p_44115_DVBSMV_EVET) :=TRUE;

    boolean_list(p_44115_ODEYEN_LEHDAR) :=FALSE;

	--
	--masraf al?nacak hesab?n bakiyesini al
	ln_son_bakiye := pkg_hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_44115_M_HESAP));

	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  boolean_list(p_44115_TEYIT_VAR) := FALSE;
	  boolean_list(p_44115_IHBAR_VAR) := FALSE;
	  boolean_list(p_44115_HABR_VAR) := FALSE;
	  boolean_list(p_44115_POSTA_VAR) := FALSE;

	  if nvl(row_masraf.tahsil_edilemeyen,0) > 0  then
		  if row_masraf.ODEYECEK = 'LEHDAR' then
		  	   boolean_list(p_44115_ODEYEN_LEHDAR) :=TRUE;
 		      ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
    		  lb_taksit_var := false;
		      if row_masraf.masraf_kodu = 'LCACIHBAR'  then     --ihbar masraf?
	--masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
			    if boolean_list(p_44115_M_HESAP_TRL) then
				   number_list(p_44115_IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
				   number_list(p_44115_IHBAR_MDV) := number_list(p_44115_IHBAR_TRL);
				else
				   number_list(p_44115_IHBAR_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_IHBAR_MDV)));
				end if;
    --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
    --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
				ln_borc_tutar := number_list(p_44115_IHBAR_MDV);
				ln_borc_trl := number_list(p_44115_IHBAR_TRL);
				varchar_list(p_44115_MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
				boolean_list(p_44115_IHBAR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'TMALGARHAB'  then   --haberle?me
			    if boolean_list(p_44115_M_HESAP_TRL) then
					number_list(p_44115_HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p_44115_HABR_MDV) := number_list(p_44115_HABR_TRL);
				else
				   number_list(p_44115_HABR_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_HABR_MDV)));
				end if;
				ln_borc_tutar := number_list(p_44115_HABR_MDV);
				ln_borc_trl := number_list(p_44115_HABR_TRL);
		    	varchar_list(p_44115_MAS_HABR_ACIKLAMA) := 'HABERLE?ME MASRAFLARI';
				boolean_list(p_44115_HABR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'TMALGARPOS' then   --posta
			    if boolean_list(p_44115_M_HESAP_TRL) then
					number_list(p_44115_POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p_44115_POSTA_MDV) := number_list(p_44115_POSTA_TRL);
				else
				   number_list(p_44115_POSTA_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_POSTA_MDV)));
				end if;
				ln_borc_tutar := number_list(p_44115_POSTA_MDV);
				ln_borc_trl := number_list(p_44115_POSTA_TRL);
				varchar_list(p_44115_MAS_POST_ACIKLAMA) := 'POSTA MASRAFLARI';
				boolean_list(p_44115_POSTA_VAR) := TRUE;

			  elsif row_masraf.masraf_kodu =  'VERGARKOM' then  --teyit TAKS?TL? OLUR
				if  row_masraf.komisyon_tipi not  like 'DONEMSEL%'  then
				    ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0); --row_masraf.hesaplanan - nvl(row_masraf.tahsil_toplam,0);
				    if boolean_list(p_44115_M_HESAP_TRL) then
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					  number_list(p_44115_TEYIT_MDV) := number_list(p_44115_TEYIT_TRL);
					else
					  number_list(p_44115_TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_TEYIT_MDV)));
					end if;
					ln_borc_tutar := number_list(p_44115_TEYIT_MDV);
					ln_borc_trl := number_list(p_44115_TEYIT_TRL);
					varchar_list(p_44115_MAS_TEY_ACIKLAMA) := 'Verilen Garanti Komisyonu';
					boolean_list(p_44115_TEYIT_VAR) := TRUE;

				else
				  lb_taksit_var := true;
				  open cur_taksitler;
				  loop
				    fetch cur_taksitler into row_taksit;
					exit when cur_taksitler%notfound;
					ln_tahsil_tutar := row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0);
				    if boolean_list(p_44115_M_HESAP_TRL) then
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					  number_list(p_44115_TEYIT_MDV) := number_list(p_44115_TEYIT_TRL);
					else
					  number_list(p_44115_TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_TEYIT_MDV)));
					end if;
					varchar_list(p_44115_MAS_TEY_ACIKLAMA) := row_taksit.taksit_no || '. GARANT? KOM?SYON TAKS?D?';
					ln_borc_tutar := number_list(p_44115_TEYIT_MDV);
					ln_borc_trl := number_list(p_44115_TEYIT_TRL);
					lb_taksit_var := true;


					if ln_son_bakiye >= ln_borc_tutar then
						boolean_list(p_44115_TEYIT_VAR) := TRUE;
					    ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
					    			 	              	  null,
						     						  	  pn_islem_no,
							    					  	  varchar_list ,
								    				  	  number_list  ,
									    			  	  date_list    ,
										    		  	  boolean_list ,
											    	  	  null,
												     	  false,
												  	      ln_fis_no,
												  	      null);

						--pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                        --                             row_masraf.masraf_kodu, (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)), row_masraf.vs_no);

					    update cbs_masraf_ith_ihr_isl
						   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
						       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
					     where current of cur_masraf;

 					  	pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

						update cbs_masraf_taksit_islem
						   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
						       odenen_tutar = taksit_tutari
						 where current of cur_taksitler;

						ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
						number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_KOM_TOPLAMI) + ln_borc_trl;
						number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_KOM_MDV_TOPLAM) + ln_borc_tutar;
					end if;

				  end loop;
				  close cur_taksitler;

				end if;
			  else
			    close cur_masraf;
		 	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  end if;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle

				 ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
        		    			 	               null,
        			     						   pn_islem_no,
        				    					   varchar_list ,
        					    				   number_list  ,
        						    			   date_list    ,
        							    		   boolean_list ,
        								    	   null,
        									       false,
        									  	   ln_fis_no,
        									  	   null);
			     pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                               row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

			      update cbs_masraf_ith_ihr_isl
				     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
					     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
			       where current of cur_masraf;
				  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
				  number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_KOM_TOPLAMI) + ln_borc_trl;
				  number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_KOM_MDV_TOPLAM) + ln_borc_tutar;
			   end if;
			  end if;
 	      end if; --ihracat?? ?demesi
	  end if;  --tahsil edilmeyen var....

	end loop;
	close cur_masraf;
	if number_list(p_44115_KOM_MDV_TOPLAM) > 0 then
	   boolean_list(p_44115_TEYIT_VAR) := FALSE;
	   boolean_list(p_44115_IHBAR_VAR) := FALSE;
	   boolean_list(p_44115_HABR_VAR)  := FALSE;
	   boolean_list(p_44115_POSTA_VAR) := FALSE;
       if boolean_list(p_44115_M_HESAP_TRL) then
	      boolean_list(p_44115_MAS_TP_ANA) := TRUE;
	   else
	      boolean_list(p_44115_MAS_YP_ANA) := TRUE;
	   end if;
/*
	  	number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_IHBAR_TRL) +
										   number_list(p_44115_HABR_TRL) +
		                                   number_list(p_44115_POSTA_TRL) +
										   number_list(p_44115_TEYIT_TRL);
    	number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_IHBAR_MDV)+
		                                      number_list(p_44115_HABR_MDV) +
											  number_list(p_44115_POSTA_MDV) +
											  number_list(p_44115_TEYIT_MDV);
*/

		number_list(p_44115_BSMV_TRL) :=pkg_kur.YUVARLA(PKG_GENEL.LC_AL,number_list(p_44115_KOM_TOPLAMI)*0.05);
		                               /*pkg_kur.YUVARLA(PKG_GENEL.LC_AL,
									   (number_list(p_44115_HABR_TRL)+
		                                number_list(p_44115_POSTA_TRL)+
										number_list(p_44115_TEYIT_TRL))*0.05);*/

		number_list(p_44115_BSMV_MDV) :=pkg_kur.YUVARLA(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_KOM_TOPLAMI)*0.05);
		                               /*pkg_kur.YUVARLA(varchar_list(p_44115_MHESAP_DVZ),
									   (number_list(p_44115_HABR_MDV) +
										number_list(p_44115_POSTA_MDV) +
										number_list(p_44115_TEYIT_MDV))*0.05);*/

 	    IF boolean_list(p_44115_DVBSMV_EVET)=TRUE THEN

    		number_list(p_44115_MASKOMBSMV_TOPLAM) :=pkg_kur.YUVARLA(PKG_GENEL.LC_AL,number_list(p_44115_KOM_TOPLAMI)*1.05);
			                                        /* pkg_kur.YUVARLA(PKG_GENEL.LC_AL,
												    (number_list(p_44115_HABR_TRL)+
    		                                         number_list(p_44115_POSTA_TRL)+
    										         number_list(p_44115_TEYIT_TRL))*1.05);*/
		ELSE
    		number_list(p_44115_MASKOMBSMV_TOPLAM) :=number_list(p_44115_KOM_TOPLAMI);
			                                        /*(number_list(p_44115_HABR_TRL)+
    		                                         number_list(p_44115_POSTA_TRL)+
    										         number_list(p_44115_TEYIT_TRL));*/
		END IF;



       ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
	    			 	              	 null,
		     						  	 pn_islem_no,
			    					  	 varchar_list ,
				    				  	 number_list  ,
					    			  	 date_list    ,
						    		  	 boolean_list ,
							    	  	 null,
								     	 false,
								  	     ln_fis_no,
								  	     null);
	end if;
	pn_fis_no := ln_fis_no;

  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebe_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, null);
  End;
/*------------------------------------------------------------------------------------------------------*/

   Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
     ln_temp number;
     begin
       select count(*)
         into ln_temp
    	 from cbs_masraf_ith_ihr_isl
    	where islem_no = pn_islem_no
    	  and odeyecek = 'LEHDAR';
       if ln_temp > 0 then
         return 'E';
       else
         return 'H';
       end if;
 end;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

  Procedure EOD_Muhasebelesme(pn_islem_no number, pn_fis_no in out number, ps_referans varchar2) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_tahsil_tutar		  number;
   ln_bsmv_trl number;

   --ls_referans........

   cursor cur_masraf is
    select *
	 from cbs_masraf_ith_ihr
	 where referans = ls_referans
	 order by sira_no
	for update;
	row_masraf cur_masraf%rowtype;

   cursor cur_tmhg is
     select * from CBS_TM_VERILEN_GARANTI
	  where referans = ps_referans;
	  row_tmhg cur_tmhg%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit a
	  where referans = ls_referans
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
  --buraya geldiyse masraf ?demesi vard?r. Tarih kontrol? sadece taksitlerde yap?l?r.
  --E?er fi? kesilmesi istenmiyorsa, bu fonksiyon ?a?r?lmamal?d?r....
    ln_fis_no := pn_fis_no;
	open cur_tmhg;
	fetch cur_tmhg into row_tmhg;
	 ls_akr_doviz := row_tmhg.doviz_kodu;
	 varchar_list(p_44115_M_HESAP):=row_tmhg.masraf_hesap_no;

----------------
	 if row_tmhg.masraf_hesap_no is not null then
	    varchar_list(p_44115_MHESAP_DVZ):= pkg_hesap.HesaptanDovizKoduAl(row_tmhg.masraf_hesap_no);
	    varchar_list(p_44115_MHESAP_SUBE) := pkg_hesap.HesapSubeAl(row_tmhg.masraf_hesap_no);
 	    number_list(p_44115_KUR_TUTAR) := pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),1);
	  else
	      varchar_list(p_44115_MHESAP_DVZ):='';
	      varchar_list(p_44115_MHESAP_SUBE) :='';
	 end if;
----------------

	 varchar_list(p_44115_ISLEM_SUBE) := pkg_tx.Islem_BolumKodu_Al(pn_islem_no);
	 ls_referans := row_tmhg.referans;
	close cur_tmhg;
    if varchar_list(p_44115_MHESAP_DVZ) = pkg_genel.LC_AL then
	 boolean_list(p_44115_M_HESAP_TRL) := TRUE;
	 boolean_list(p_44115_M_HESAP_DVZ) := FALSE;
	else
	 boolean_list(p_44115_M_HESAP_TRL) := FALSE;
	 boolean_list(p_44115_M_HESAP_DVZ) := TRUE;
	end if;
	boolean_list(p_44115_MAS_TP_ANA) := FALSE;
	boolean_list(p_44115_MAS_YP_ANA) := FALSE;
	number_list(p_44115_HABR_TRL) := 0;
	number_list(p_44115_HABR_MDV) := 0;
	varchar_list(p_44115_MAS_HABR_ACIKLAMA) := '';
	boolean_list(p_44115_HABR_VAR) := FALSE;
	number_list(p_44115_POSTA_TRL) := 0;
	number_list(p_44115_POSTA_MDV) := 0;
	varchar_list(p_44115_MAS_POST_ACIKLAMA) := '';
	boolean_list(p_44115_POSTA_VAR) := FALSE;
	number_list(p_44115_TEYIT_TRL) := 0;
	number_list(p_44115_TEYIT_MDV) := 0;
	varchar_list(p_44115_MAS_TEY_ACIKLAMA) := '';
	boolean_list(p_44115_TEYIT_VAR) := FALSE;
	number_list(p_44115_IHBAR_TRL) := 0;
	number_list(p_44115_IHBAR_MDV) := 0;
	varchar_list(p_44115_MAS_IHBAR_ACIKLAMA) := '';
	boolean_list(p_44115_IHBAR_VAR) := FALSE;

	number_list(p_44115_KOM_TOPLAMI) := 0;
	number_list(p_44115_KOM_MDV_TOPLAM) := 0;
	varchar_list(p_44115_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' M??teri No:'||row_tmhg.LEHDAR_MUSTERI_NO
								   ||' -'||pkg_musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);

	/*
	if row_tmhg.doviz_kodu=pkg_genel.lc_al then
	  case row_tmhg.mektup_tipi
	   when 'GECICI' then  varchar_list(p_44115_KOMISYON_DK) :='74800000';
	   when 'KESIN' then  varchar_list(p_44115_KOMISYON_DK) :='74800100';
	   when 'AVANS' then  varchar_list(p_44115_KOMISYON_DK) :='74800200';
	   when 'SERBEST' then  varchar_list(p_44115_KOMISYON_DK) :='74800300';
	   end case;
	ELSE
    	  case row_tmhg.mektup_tipi
    	   when 'GECICI' then  varchar_list(p_44115_KOMISYON_DK) :='74900000';
    	   when 'KESIN' then  varchar_list(p_44115_KOMISYON_DK) :='74900100';
    	   when 'AVANS' then  varchar_list(p_44115_KOMISYON_DK) :='74900200';
    	   when 'SERBEST' then  varchar_list(p_44115_KOMISYON_DK) :='74900300';
    	   end case;
    end if;
     */
    boolean_list(p_44115_DVBSMV_EVET) :=TRUE;

    boolean_list(p_44115_ODEYEN_LEHDAR) :=FALSE;

	--
	--masraf al?nacak hesab?n bakiyesini al
	ln_son_bakiye := pkg_hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_44115_M_HESAP));

	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  boolean_list(p_44115_TEYIT_VAR) := FALSE;
	  boolean_list(p_44115_IHBAR_VAR) := FALSE;
	  boolean_list(p_44115_HABR_VAR) := FALSE;
	  boolean_list(p_44115_POSTA_VAR) := FALSE;

	  if nvl(row_masraf.tahsil_edilemeyen,0) > 0  then
		  if row_masraf.ODEYECEK = 'LEHDAR' then
		  	   boolean_list(p_44115_ODEYEN_LEHDAR) :=TRUE;
 		      ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
    		  lb_taksit_var := false;
		      if row_masraf.masraf_kodu = 'LCACIHBAR'  then     --ihbar masraf?
	--masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
			    if boolean_list(p_44115_M_HESAP_TRL) then
				   number_list(p_44115_IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
				   number_list(p_44115_IHBAR_MDV) := number_list(p_44115_IHBAR_TRL);
				else
				   number_list(p_44115_IHBAR_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_IHBAR_MDV)));
				end if;
    --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
    --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
				ln_borc_tutar := number_list(p_44115_IHBAR_MDV);
				ln_borc_trl := number_list(p_44115_IHBAR_TRL);
				varchar_list(p_44115_MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
				boolean_list(p_44115_IHBAR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'TMALGARHAB'  then   --haberle?me
			    if boolean_list(p_44115_M_HESAP_TRL) then
					number_list(p_44115_HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p_44115_HABR_MDV) := number_list(p_44115_HABR_TRL);
				else
				   number_list(p_44115_HABR_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_HABR_MDV)));
				end if;
				ln_borc_tutar := number_list(p_44115_HABR_MDV);
				ln_borc_trl := number_list(p_44115_HABR_TRL);
		    	varchar_list(p_44115_MAS_HABR_ACIKLAMA) := 'HABERLE?ME MASRAFLARI';
				boolean_list(p_44115_HABR_VAR) := TRUE;
			  elsif row_masraf.masraf_kodu = 'TMALGARPOS' then   --posta
			    if boolean_list(p_44115_M_HESAP_TRL) then
					number_list(p_44115_POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					number_list(p_44115_POSTA_MDV) := number_list(p_44115_POSTA_TRL);
				else
				   number_list(p_44115_POSTA_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
				   number_list(p_44115_POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_POSTA_MDV)));
				end if;
				ln_borc_tutar := number_list(p_44115_POSTA_MDV);
				ln_borc_trl := number_list(p_44115_POSTA_TRL);
				varchar_list(p_44115_MAS_POST_ACIKLAMA) := 'POSTA MASRAFLARI';
				boolean_list(p_44115_POSTA_VAR) := TRUE;

			  elsif row_masraf.masraf_kodu =  'VERGARKOM' then  --teyit TAKS?TL? OLUR
				if  row_masraf.komisyon_tipi not  like 'DONEMSEL%'  then
				    ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0); --row_masraf.hesaplanan - nvl(row_masraf.tahsil_toplam,0);
				    if boolean_list(p_44115_M_HESAP_TRL) then
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					  number_list(p_44115_TEYIT_MDV) := number_list(p_44115_TEYIT_TRL);
					else
					  number_list(p_44115_TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_TEYIT_MDV)));
					end if;
					ln_borc_tutar := number_list(p_44115_TEYIT_MDV);
					ln_borc_trl := number_list(p_44115_TEYIT_TRL);
					varchar_list(p_44115_MAS_TEY_ACIKLAMA) := 'Verilen Garanti Komisyonu';
					boolean_list(p_44115_TEYIT_VAR) := TRUE;

				else
				  lb_taksit_var := true;
				  open cur_taksitler;
				  loop
				    fetch cur_taksitler into row_taksit;
					exit when cur_taksitler%notfound;
					ln_tahsil_tutar := row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0);
				    if boolean_list(p_44115_M_HESAP_TRL) then
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.dak_to_lc(ls_akr_doviz, ln_tahsil_tutar));
					  number_list(p_44115_TEYIT_MDV) := number_list(p_44115_TEYIT_TRL);
					else
					  number_list(p_44115_TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p_44115_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44115_MHESAP_DVZ), null,
				                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));
					  number_list(p_44115_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_TEYIT_MDV)));
					end if;
					varchar_list(p_44115_MAS_TEY_ACIKLAMA) := row_taksit.taksit_no || '. GARANT? KOM?SYON TAKS?D?';
					ln_borc_tutar := number_list(p_44115_TEYIT_MDV);
					ln_borc_trl := number_list(p_44115_TEYIT_TRL);
					lb_taksit_var := true;


					if ln_son_bakiye >= ln_borc_tutar then
						boolean_list(p_44115_TEYIT_VAR) := TRUE;
					    ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
					    			 	              	  null,
						     						  	  pn_islem_no,
							    					  	  varchar_list ,
								    				  	  number_list  ,
									    			  	  date_list    ,
										    		  	  boolean_list ,
											    	  	  null,
												     	  false,
												  	      ln_fis_no,
												  	      null);

						--pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                        --                             row_masraf.masraf_kodu, (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)), row_masraf.vs_no);

					    update cbs_masraf_ith_ihr_isl
						   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
						       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
					     where current of cur_masraf;

 					  	pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

						update cbs_masraf_taksit_islem
						   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
						       odenen_tutar = taksit_tutari
						 where current of cur_taksitler;

						ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
						number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_KOM_TOPLAMI) + ln_borc_trl;
						number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_KOM_MDV_TOPLAM) + ln_borc_tutar;
					end if;

				  end loop;
				  close cur_taksitler;

				end if;
			  else
			    close cur_masraf;
		 	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  end if;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle

				 ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
        		    			 	               null,
        			     						   pn_islem_no,
        				    					   varchar_list ,
        					    				   number_list  ,
        						    			   date_list    ,
        							    		   boolean_list ,
        								    	   null,
        									       false,
        									  	   ln_fis_no,
        									  	   null);
			     pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                               row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

			      update cbs_masraf_ith_ihr_isl
				     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
					     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
			       where current of cur_masraf;
				  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
				  number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_KOM_TOPLAMI) + ln_borc_trl;
				  number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_KOM_MDV_TOPLAM) + ln_borc_tutar;
			   end if;
			  end if;
 	      end if; --ihracat?? ?demesi
	  end if;  --tahsil edilmeyen var....

	end loop;
	close cur_masraf;
	if number_list(p_44115_KOM_MDV_TOPLAM) > 0 then
	   boolean_list(p_44115_TEYIT_VAR) := FALSE;
	   boolean_list(p_44115_IHBAR_VAR) := FALSE;
	   boolean_list(p_44115_HABR_VAR)  := FALSE;
	   boolean_list(p_44115_POSTA_VAR) := FALSE;
       if boolean_list(p_44115_M_HESAP_TRL) then
	      boolean_list(p_44115_MAS_TP_ANA) := TRUE;
	   else
	      boolean_list(p_44115_MAS_YP_ANA) := TRUE;
	   end if;
/*
	  	number_list(p_44115_KOM_TOPLAMI) := number_list(p_44115_IHBAR_TRL) +
										   number_list(p_44115_HABR_TRL) +
		                                   number_list(p_44115_POSTA_TRL) +
										   number_list(p_44115_TEYIT_TRL);
    	number_list(p_44115_KOM_MDV_TOPLAM) := number_list(p_44115_IHBAR_MDV)+
		                                      number_list(p_44115_HABR_MDV) +
											  number_list(p_44115_POSTA_MDV) +
											  number_list(p_44115_TEYIT_MDV);
*/

		number_list(p_44115_BSMV_TRL) :=pkg_kur.YUVARLA(PKG_GENEL.LC_AL,number_list(p_44115_KOM_TOPLAMI)*0.05);
		                               /*pkg_kur.YUVARLA(PKG_GENEL.LC_AL,
									   (number_list(p_44115_HABR_TRL)+
		                                number_list(p_44115_POSTA_TRL)+
										number_list(p_44115_TEYIT_TRL))*0.05);*/

		number_list(p_44115_BSMV_MDV) :=pkg_kur.YUVARLA(varchar_list(p_44115_MHESAP_DVZ),number_list(p_44115_KOM_TOPLAMI)*0.05);
		                               /*pkg_kur.YUVARLA(varchar_list(p_44115_MHESAP_DVZ),
									   (number_list(p_44115_HABR_MDV) +
										number_list(p_44115_POSTA_MDV) +
										number_list(p_44115_TEYIT_MDV))*0.05);*/

 	    IF boolean_list(p_44115_DVBSMV_EVET)=TRUE THEN

    		number_list(p_44115_MASKOMBSMV_TOPLAM) :=pkg_kur.YUVARLA(PKG_GENEL.LC_AL,number_list(p_44115_KOM_TOPLAMI)*1.05);
			                                        /* pkg_kur.YUVARLA(PKG_GENEL.LC_AL,
												    (number_list(p_44115_HABR_TRL)+
    		                                         number_list(p_44115_POSTA_TRL)+
    										         number_list(p_44115_TEYIT_TRL))*1.05);*/
		ELSE
    		number_list(p_44115_MASKOMBSMV_TOPLAM) :=number_list(p_44115_KOM_TOPLAMI);
			                                        /*(number_list(p_44115_HABR_TRL)+
    		                                         number_list(p_44115_POSTA_TRL)+
    										         number_list(p_44115_TEYIT_TRL));*/
		END IF;



       ln_fis_no:=pkg_muhasebe.fis_kes ( 44115,
	    			 	              	 null,
		     						  	 pn_islem_no,
			    					  	 varchar_list ,
				    				  	 number_list  ,
					    			  	 date_list    ,
						    		  	 boolean_list ,
							    	  	 null,
								     	 false,
								  	     ln_fis_no,
								  	     null);
	end if;
	pn_fis_no := ln_fis_no;

  End;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

 BEGIN
	p_44115_HABR_TRL   := pkg_muhasebe.parametre_index_bul('44115_HABR_TRL');
	p_44115_POSTA_TRL  := pkg_muhasebe.parametre_index_bul('44115_POSTA_TRL');
	p_44115_KOM_TOPLAMI:= pkg_muhasebe.parametre_index_bul('44115_KOM_TOPLAMI');
	p_44115_M_HESAP    := pkg_muhasebe.parametre_index_bul('44115_M_HESAP');
	p_44115_M_HESAP_DVZ:= pkg_muhasebe.parametre_index_bul('44115_M_HESAP_DVZ');
	p_44115_MHESAP_SUBE:= pkg_muhasebe.parametre_index_bul('44115_MHESAP_SUBE');
	p_44115_ISLEM_SUBE := pkg_muhasebe.parametre_index_bul('44115_ISLEM_SUBE');
	p_44115_TEYIT_MDV  := pkg_muhasebe.parametre_index_bul('44115_TEYIT_MDV');
	p_44115_IHBAR_MDV  := pkg_muhasebe.parametre_index_bul('44115_IHBAR_MDV');
	p_44115_HABR_MDV   := pkg_muhasebe.parametre_index_bul('44115_HABR_MDV');
	p_44115_POSTA_MDV  := pkg_muhasebe.parametre_index_bul('44115_POSTA_MDV');
	p_44115_KOM_MDV_TOPLAM := pkg_muhasebe.parametre_index_bul('44115_KOM_MDV_TOPLAM');
	p_44115_MAS_ACIKLAMA   := pkg_muhasebe.parametre_index_bul('44115_MAS_ACIKLAMA');
	p_44115_MAS_TEY_ACIKLAMA   := pkg_muhasebe.parametre_index_bul('44115_MAS_TEY_ACIKLAMA');
	p_44115_MAS_HABR_ACIKLAMA  := pkg_muhasebe.parametre_index_bul('44115_MAS_HABR_ACIKLAMA');
	p_44115_MAS_IHBAR_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44115_MAS_IHBAR_ACIKLAMA');
	p_44115_MAS_POST_ACIKLAMA  := pkg_muhasebe.parametre_index_bul('44115_MAS_POST_ACIKLAMA');
	p_44115_KUR_TUTAR  := pkg_muhasebe.parametre_index_bul('44115_KUR_TUTAR');
	p_44115_TEYIT_VAR  := pkg_muhasebe.parametre_index_bul('44115_TEYIT_VAR');
	p_44115_IHBAR_VAR  := pkg_muhasebe.parametre_index_bul('44115_IHBAR_VAR');
	p_44115_HABR_VAR   := pkg_muhasebe.parametre_index_bul('44115_HABR_VAR');
	p_44115_POSTA_VAR  := pkg_muhasebe.parametre_index_bul('44115_POSTA_VAR');
	p_44115_M_HESAP_TRL:= pkg_muhasebe.parametre_index_bul('44115_M_HESAP_TRL');
	p_44115_MHESAP_DVZ := pkg_muhasebe.parametre_index_bul('44115_MHESAP_DVZ');
	p_44115_TEYIT_TRL  := pkg_muhasebe.parametre_index_bul('44115_TEYIT_TRL');
	p_44115_IHBAR_TRL  := pkg_muhasebe.parametre_index_bul('44115_IHBAR_TRL');
	p_44115_MAS_TP_ANA := pkg_muhasebe.parametre_index_bul('44115_MAS_TP_ANA');
	p_44115_MAS_YP_ANA := pkg_muhasebe.parametre_index_bul('44115_MAS_YP_ANA');
	p_44115_KOMISYON_DK:= pkg_muhasebe.parametre_index_bul('44115_KOMISYON_DK');
	p_44115_DVBSMV_EVET:= pkg_muhasebe.parametre_index_bul('44115_DVBSMV_EVET');
	p_44115_ODEYEN_LEHDAR:= pkg_muhasebe.parametre_index_bul('44115_ODEYEN_LEHDAR');
	p_44115_BSMV_TRL := pkg_muhasebe.parametre_index_bul('44115_BSMV_TRL');
	p_44115_BSMV_MDV := pkg_muhasebe.parametre_index_bul('44115_BSMV_MDV');
	p_44115_MASKOMBSMV_TOPLAM:= pkg_muhasebe.parametre_index_bul('44115_MASKOMBSMV_TOPLAM');
 END;
/

