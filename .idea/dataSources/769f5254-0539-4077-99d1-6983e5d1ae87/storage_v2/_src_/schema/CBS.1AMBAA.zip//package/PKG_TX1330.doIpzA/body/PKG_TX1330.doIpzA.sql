create PACKAGE BODY     PKG_TX1330 IS
  
  FUNCTION GetLoanApplicationNo RETURN NUMBER
  IS
  ln_sira_no   NUMBER := 0;

  BEGIN

  ln_sira_no      := Pkg_Genel.genel_kod_al('LOAN_APPLICATION');

   RETURN ln_sira_no;

 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8000' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END ;
  
  /*FUNCTION GetLoanReferenceNo(cust_type VARCHAR2) RETURN VARCHAR2
  IS
    ls_key VARCHAR2(6);
    ln_seq_no   NUMBER := 0;
    ls_ref_no  VARCHAR2(13);
  
   BEGIN
    
    ls_key := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  || '.' || substr(cust_type, 1, 3);
    
    ln_seq_no      := Pkg_Genel.genel_kod_al(ls_key);
      
    ls_ref_no  := LPAD(ln_seq_no,6,0) || '/' || ls_key ;

   RETURN ls_ref_no;

 EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4532' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END ;*/
 
 
 PROCEDURE Check_INNs(pn_islem_no number) IS
 
     ls_cust_type CBS_CIB_LOAN_APPLICATION_TX.CUST_TYPE%TYPE;
     ls_company_country CBS_CIB_LOAN_APPLICATION_TX.COMPANY_COUNTRY%TYPE;
     ls_company_inn CBS_CIB_LOAN_APPLICATION_TX.COMPANY_INN%TYPE;
     ls_error_msg VARCHAR2(500);
    
    CURSOR cur_guarantor_inns IS
        SELECT INN, COUNTRY
        FROM CBS_CIB_GUARANTORS_UL_TX 
        WHERE tx_no  = pn_islem_no;
    
    CURSOR cur_guarantor_pers_inns IS
        SELECT p_inn, PKG_CIB_TRANSACTION.GETCOUNTRYCODEBYDOCTYPE(doc_type) p_country
        FROM CBS_CIB_GUARANTORS_TX 
        WHERE tx_no  = pn_islem_no;
           
        
 BEGIN
 
    --check debtor's INN
    select cust_type into ls_cust_type
    from cbs_cib_loan_application_tx
    where tx_no = pn_islem_no;
    
    select decode(ls_cust_type, '3', company_country, '4', company_country, PKG_CIB_TRANSACTION.GETCOUNTRYCODEBYDOCTYPE(p_document_type)), 
           decode(ls_cust_type, '3', company_inn, '4', company_inn, p_tax_no) 
    into ls_company_country, ls_company_inn
    from cbs_cib_loan_application_tx
    where tx_no = pn_islem_no;
    
    if(ls_cust_type IN ('1', '2')) then
        IF ls_company_country = 'kgz' then    
            if Pkg_Cib_Transaction.Check_Inn(ls_company_inn, ls_company_country, ls_error_msg) = TRUE THEN
                RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8017' || Pkg_Hata.getDelimiter ||ls_company_inn ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
            end if;
            null;
        end if;    
    else
        if Pkg_Cib_Transaction.Check_Inn(ls_company_inn, ls_company_country, ls_error_msg) = TRUE THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8017' || Pkg_Hata.getDelimiter ||ls_company_inn ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
        end if;
        if Pkg_Cib_Transaction.Check_INN_comp(ls_company_inn, ls_company_country, ls_error_msg) = TRUE THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8017' || Pkg_Hata.getDelimiter ||ls_company_inn ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER); 
        end if;
    end if;
    
    --check UL guarantors' INN
    FOR row_inn IN cur_guarantor_inns 
    LOOP
        IF Pkg_Cib_Transaction.Check_Inn(row_inn.INN, row_inn.COUNTRY, ls_error_msg) = TRUE THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8018' || Pkg_Hata.getDelimiter ||row_inn.INN ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
        END IF;
        IF Pkg_Cib_Transaction.Check_INN_comp(row_inn.INN, row_inn.COUNTRY, ls_error_msg) = TRUE THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8018' || Pkg_Hata.getDelimiter ||row_inn.INN ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
        END IF;
    END LOOP;
    
    --check person guarantors' INN
    FOR row_pers_inn IN cur_guarantor_pers_inns 
    LOOP
        if row_pers_inn.P_COUNTRY = 'kgz' then
            IF Pkg_Cib_Transaction.Check_Inn(row_pers_inn.P_INN, row_pers_inn.P_COUNTRY, ls_error_msg) = TRUE THEN
                RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8018' || Pkg_Hata.getDelimiter ||row_pers_inn.P_INN ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
            END IF;
        end if;       
    END LOOP;

    
 END;
 
Procedure Check_Document_No(pn_islem_no number) is
ls_cust_type VARCHAR2(1);
 lb_ret BOOLEAN;
 ln_doc_type NUMBER;
 ls_doc_no VARCHAR2(50);   
 ls_error_msg VARCHAR2(200);
 ln_min NUMBER;
 ln_max NUMBER;
 
 CURSOR c_false_docs IS
    select doc_no, min_len, max_len 
    from cbs_cib_guarantors_tx a 
        left join cbs_cib_dir_document b on A.DOC_TYPE = B.ID
    where (length(trim(A.DOC_NO)) > B.MAX_LEN or length(trim(A.DOC_NO)) < B.MIN_LEN) and a.tx_no = pn_islem_no;
    
  Begin
    
  select cust_type, p_document_type, p_document_no into ls_cust_type, ln_doc_type, ls_doc_no
  from cbs_cib_loan_application_tx
  where tx_no = pn_islem_no;
  
  if ls_cust_type in ('1', '2') then

   lb_ret := Pkg_Cib_Transaction.Check_Document_Length(ln_doc_type, ls_doc_no, ls_error_msg) OR 
              Pkg_Cib_Transaction.Check_Document_Pattern(ln_doc_type, ls_doc_no, ls_error_msg);  --CQ5988, ErkinZ, check pattern of document                                                   
   
   if lb_ret then
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8009' || Pkg_Hata.getDelimiter ||ls_error_msg ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   end if;
   
  end if;
  
  for guarant_rw in( 
  select doc_type, doc_no
  from cbs_cib_guarantors_tx
  where tx_no = pn_islem_no)
  loop 
  
      lb_ret := Pkg_Cib_Transaction.Check_Document_Length(guarant_rw.doc_type, guarant_rw.doc_no, ls_error_msg) OR 
                  Pkg_Cib_Transaction.Check_Document_Pattern(guarant_rw.doc_type, guarant_rw.doc_no, ls_error_msg); --CQ5988, ErkinZ, check pattern of document
      if lb_ret then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8010' || Pkg_Hata.getDelimiter ||ls_error_msg ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
      end if;    
  end loop;
    /*OPEN c_false_docs;
    
    FETCH c_false_docs into ls_doc_no, ln_min, ln_max;
  
  if c_false_docs%FOUND and ln_min is not null and ln_max is not null then
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8010' || Pkg_Hata.getDelimiter || ls_doc_no ||' => must be between ' || ln_min ||' and ' || ln_max ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  end if;*/         
               
  End;
 
Procedure Check_Dates(pn_islem_no number) is    
    ld_bank_date DATE;
    ln_count NUMBER;
    ls_cust_type VARCHAR2(1);
    ld_pbdate DATE;
    ld_cbdate DATE;
    ld_app_date DATE;
    ld_due_date DATE;
 Begin
 
    ld_bank_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
    
    --CHECK BIRTHDATE >= 18
        
    select cust_type, p_bdate, company_bdate, application_date, due_date into ls_cust_type, ld_pbdate, ld_cbdate, ld_app_date, ld_due_date  from CBS_CIB_LOAN_APPLICATION_TX where tx_no = pn_islem_no;
    
    if ls_cust_type in ('1', '2') and floor(months_between(ld_bank_date, ld_pbdate) /12) < 18 then 
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8011' || Pkg_Hata.getDelimiter || floor(months_between(ld_bank_date, ld_pbdate) /12) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    end if;
    
    select count(*) into ln_count from cbs_cib_guarantors_tx where tx_no = pn_islem_no and  floor(months_between(ld_bank_date, birthdate) /12) < 18;
    
    if ln_count > 0 then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8012' || Pkg_Hata.getDelimiter || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    end if;
    
    
    --CHECK Company Registration date < DateTime.Now
    
   if ls_cust_type in ('3', '4') and ld_cbdate >= ld_bank_date then
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8013' || Pkg_Hata.getDelimiter || ld_cbdate ||Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
   end if;
    
    select count(*) into ln_count from cbs_cib_guarantors_ul_tx where tx_no = pn_islem_no and registration_date >= ld_bank_date;
    
     if ln_count > 0 then
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8014' || Pkg_Hata.getDelimiter || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    end if;
    
    
    --CHECK Application date and Due date
    
    if ld_app_date > ld_bank_date then
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8016' || Pkg_Hata.getDelimiter || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    end if;
    
    
    if ld_due_date - ld_app_date < 28 then
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8015' || Pkg_Hata.getDelimiter || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    end if;
    
 End;
 
 Procedure Check_Guarants(pn_islem_no number) is
 
    ln_count NUMBER;
    ln_count_2 NUMBER;
    
    ls_cust_type VARCHAR2(1);
 Begin
 
  select cust_type into ls_cust_type from CBS_CIB_LOAN_APPLICATION_TX where tx_no = pn_islem_no;
   
   if ls_cust_type in ('3', '4') then
        select count(*) into ln_count from cbs_cib_guarantors_tx where tx_no = pn_islem_no;
        select count(*) into ln_count_2 from cbs_cib_guarantors_ul_tx where tx_no = pn_islem_no;
        
        if ln_count=0 and ln_count_2=0 then
             RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8019' || Pkg_Hata.getDelimiter || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
        end if;
        
   end if;
   
   
      
 End;
 
Procedure Kontrol_Sonrasi(pn_islem_no number) is
Begin
   
    Check_Dates(pn_islem_no);
    
    Check_Document_No(pn_islem_no);
    
    Check_INNs(pn_islem_no);
    
    Check_Guarants(pn_islem_no);
         


End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;

  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    null;
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
      
       LN_APP_NO CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE;
       
  BEGIN
                                 
        -- status 1-0 means application is under consideration
        -- Erkin Z, cq614, 17.08.2017, strange status -11 means that application has not yet passed screen 1331 which is mandatory step after last discussions
        INSERT INTO CBS_CIB_LOAN_APPLICATION(APP_NO,  CUST_NO, CUST_TYPE, STATUS,  LOAN_TYPE, DUE_DATE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, UPDATE_TX, UPDATE_DATE)
        SELECT APP_NO,  CUST_NO, CUST_TYPE, '-11',  LOAN_TYPE, DUE_DATE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, TX_NO, SYSDATE
        FROM CBS_CIB_LOAN_APPLICATION_TX
        WHERE TX_NO = pn_islem_no;    
        
        INSERT INTO CBS_CIB_GUARANTORS(APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO, P_INN)
        SELECT APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO, P_INN
        FROM CBS_CIB_GUARANTORS_TX
        WHERE TX_NO = pn_islem_no;
        
        INSERT INTO CBS_CIB_GUARANTORS_UL(APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN,  CUST_NO)
        SELECT APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO
        FROM CBS_CIB_GUARANTORS_UL_TX
        WHERE TX_NO = pn_islem_no;
        
        INSERT INTO CBS_CIB_GUARANTEE(APP_NO, GUARANTEE_TYPE)
        SELECT APP_NO, GUARANTEE_TYPE
        FROM CBS_CIB_GUARANTEE_TX
        WHERE TX_NO = pn_islem_no;
        
        
        SELECT APP_NO INTO LN_APP_NO
        FROM CBS_CIB_LOAN_APPLICATION_TX
        WHERE TX_NO = pn_islem_no;
        
       -- PKG_CIB_TRANSACTION.ADDTOSENDINGLIST(PN_ISLEM_NO, 1330, LN_APP_NO, NULL);
        
    EXCEPTION
        WHEN  OTHERS THEN
           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8001' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is    
  Begin
      null;
  End;
  
END;
/

