create PACKAGE BODY PKG_TX1604 IS
	pn_1604_banka_aciklama        		  number;
	pn_1604_doviz_kodu        	  		  number;
	pn_1604_istatistik_kodu        		  number;
	pn_1604_referans        			  number;
	pn_1604_dekont_aciklama        		  number;
	pn_1604_musteri_aciklama        	  number;
	pn_1604_islem_sube        			  number;
	pn_1604_nakit_kodu_lc        		  number;
	pn_1604_nakit_kodu_fc        		  number;
	pn_1604_kur        					  number;
	pn_1604_tutar_tl        			  number;
	pn_1604_tutar        				  number;
	pn_1604_to_main_cash        		  number;
	pn_1604_fc_islem        			  number;
	pn_1604_lc_islem        			  number;
	pn_1604_from_main_cash        		  number;
	ls_dk_no							  varchar2(2000);
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
		   doviz_kodu,
		   urun_sinif_kod,
		   bakiye
	from cbs_kasa_bakiye_islem
	where tx_no = pn_islem_no;

	 ls_retval varchar2(200);
	 ls_islem_tipi varchar2(1);
  Begin
  	Bakiye_Kontrol(pn_islem_no);
    pkg_tx1601.Ana_Kasa_Bakiye_Guncelle(pn_islem_no ,'KONTROL');

	for c_bakiye in cur_bakiye loop
		ls_retval := pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'ANAKASAAL');
		if c_bakiye.urun_sinif_kod =  ls_RetVal  then
				/* ANA KASA ALINAN ISE  kullan?c? kasasi yatandir. */
		    ls_islem_tipi  := 'Y';
		 else
	  		ls_islem_tipi := 'C';
		end if;
		pkg_tx1601.Kontrol_Sonrasi(pn_islem_no,
									   '1604',
										c_bakiye.bakiye,
										c_bakiye.doviz_kodu,
										ls_islem_tipi,
										null,null,null,null,'H' );
	end loop;

  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
		   doviz_kodu,
		   urun_sinif_kod,
		   bakiye
	from cbs_kasa_bakiye_islem
	where tx_no = pn_islem_no;

	 ls_retval varchar2(200);
	 ls_islem_tipi varchar2(1);
  Begin

	for c_bakiye in cur_bakiye loop
		ls_retval := pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'ANAKASAAL');
		if c_bakiye.urun_sinif_kod =  ls_RetVal  then
				/* ANA KASA ALINAN ISE  kullan?c? kasasi yatandir. */
		    ls_islem_tipi  := 'Y';
		 else
	  		ls_islem_tipi := 'C';
		end if;

		  pkg_tx1601.Dogrulama_Sonrasi(pn_islem_no,
								   '1604',
									c_bakiye.bakiye,
									c_bakiye.doviz_kodu,
									ls_islem_tipi );
	end loop;
  End;


  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
	-- Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
    null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin

    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
   PKG_Tx1601.Iptal_Onay_Sonrasi(pn_islem_no ,'1604' );
   pkg_tx1601.Ana_Kasa_Bakiye_Guncelle(pn_islem_no ,'IPTAL');
--    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    PKG_Tx1601.Iptal_Muhasebelestir_Sonrasi(pn_islem_no ,'1604');

   --Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
     cursor cur_bakiye is
    select distinct
		   doviz_kodu,
		   urun_sinif_kod,
		   bakiye
	from cbs_kasa_bakiye_islem
	where tx_no = pn_islem_no;

	 ls_retval varchar2(200);
	 ls_islem_tipi varchar2(1);
  Begin

	for c_bakiye in cur_bakiye loop
		ls_retval := pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'ANAKASAAL');
		if c_bakiye.urun_sinif_kod =  ls_RetVal  then
				/* ANA KASA ALINAN ISE  kullan?c? kasasi yatandir. */
		    ls_islem_tipi  := 'Y';
		 else
	  		ls_islem_tipi := 'C';
		end if;

		    PKG_Tx1601.Onay_Sonrasi(pn_islem_no,
								   '1604',
									c_bakiye.bakiye,
									c_bakiye.doviz_kodu,
									ls_islem_tipi );
	end loop;

	 pkg_tx1601.Ana_Kasa_Bakiye_Guncelle(pn_islem_no ,'ONAY');
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
    ln_fis_no				   cbs_fis.numara%type :=0;
	ls_islem_kod               cbs_islem.islem_kod%type :='1604';
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama            varchar2(2000);
	ls_aciklama				   varchar2(2000);
	ls_musteri_aciklama_2      varchar2(2000);
	ls_kasa_kodu 			   varchar2(2000);
	ls_doviz_kodu			   varchar2(2000);
	ln_plan_no				   number;

	ls_durum varchar2(200);
	kasa_kapali exception;

 cursor cur_islem_cursor is
    select a.sube_kodu,
		   b.doviz_kodu,
		   A.urun_sinif_kod,
		   BAKIYE tutar
	from CBS_KASA_ISLEM a,
		 CBS_KASA_BAKIYE_ISLEM b
	where a.tx_no = pn_islem_no and
		  a.tx_no = b.tx_no;

  Begin

  /******** 1604 Muhasebe islemleri****/
	varchar_list(pn_1604_banka_aciklama) := NULL;
	varchar_list(pn_1604_dekont_aciklama) := NULL;
	varchar_list(pn_1604_doviz_kodu) := NULL;
	varchar_list(pn_1604_islem_sube) := NULL;
	varchar_list(pn_1604_istatistik_kodu) := NULL;
	varchar_list(pn_1604_musteri_aciklama) := NULL;
	varchar_list(pn_1604_nakit_kodu_fc) := NULL;
	varchar_list(pn_1604_nakit_kodu_lc) := NULL;
	varchar_list(pn_1604_referans) := NULL;
	number_list(pn_1604_kur):= 0;
	number_list(pn_1604_tutar):= 0;
	number_list(pn_1604_tutar_tl):= 0;
	boolean_list(pn_1604_fc_islem):= FALSE;
	boolean_list(pn_1604_from_main_cash):= FALSE;
	boolean_list(pn_1604_lc_islem):= FALSE;
	boolean_list(pn_1604_to_main_cash):= FALSE;

/*** Liste Deger Atama K?sm? **/

  -- pkg_parametre.deger('1604_BANKA_ACIKLAMA',ls_banka_aciklama);
  -- pkg_parametre.deger('1604_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   ls_aciklama := 	varchar_list(pn_1604_banka_aciklama);
   ls_fis_aciklama :=    pkg_genel.ISLEM_ADI_AL(1604) ;

    for c_islem_cursor in cur_islem_cursor loop

			boolean_list(pn_1604_fc_islem):= FALSE;
			boolean_list(pn_1604_lc_islem):= FALSE;
			boolean_list(pn_1604_from_main_cash):= FALSE;
			boolean_list(pn_1604_to_main_cash):= FALSE;
			ls_doviz_kodu := c_islem_cursor.doviz_kodu;
			varchar_list(pn_1604_doviz_kodu) := c_islem_cursor.doviz_kodu;
			varchar_list(pn_1604_islem_sube) := c_islem_cursor.sube_kodu;
			varchar_list(pn_1604_referans) :=c_islem_cursor.sube_kodu;
			number_list(pn_1604_tutar):= c_islem_cursor.tutar;
			number_list(pn_1604_tutar_tl):=  pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.TUTAR,1,null,null,'N','A'));
			number_list(pn_1604_kur) :=pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'));

			if ls_doviz_kodu = pkg_genel.lc_al then
			   boolean_list(pn_1604_lc_islem) := true;
			 else
			     boolean_list(pn_1604_fc_islem) := true;
			end if;
			if c_islem_cursor.urun_sinif_kod = 'RECEIVED' then
			  ls_banka_aciklama := 'Cash received from Main cash to exchange office.';
			  boolean_list(pn_1604_from_main_cash):= true;
			 else
			  ls_banka_aciklama := 'Transfer to Main cash from exchange office.';
			  boolean_list(pn_1604_to_main_cash):= true;
			end if;

			varchar_list(pn_1604_banka_aciklama)   := ls_banka_aciklama ;
			varchar_list(pn_1604_musteri_aciklama) := ls_banka_aciklama  ;

/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							ln_plan_no,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							ln_fis_no,
							ls_fis_aciklama);

  end loop;
    if nvl(ln_fis_no,0) <> 0 then
     	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
	end if;

	  PKG_Tx1601.Muhasebelesme(pn_islem_no ,'1604');

  End;


  Function urun_sinif_uygunmu (ps_modul_tur_kod varchar2,ps_urun_tur_kod varchar2 ,ps_urun_sinif_kod varchar2 ) return varchar2
  is
  Begin
  	  if  ps_modul_tur_kod  = pkg_kasa.kasa_modul_tur_kod and
	  	  ps_urun_tur_kod   = pkg_kasa.kasa_urun_tur_kod and
		  ps_urun_sinif_kod in( 'RECEIVED','TRANSFER') then

		  return 'E';
	 else
  	     return 'H';
	end if;
  End;

  Procedure Bakiye_Kontrol(pn_islem_no number)
  is
   ls_urun_sinif varchar2(200) := null;
 	ls_retval varchar2(200);
	ls_pkod	 varchar2(200);
	ls_kasa_kodu varchar2(200);
	ls_sube_kodu varchar2(200);
	ls_doviz varchar2(200);
	ln_adet  number := 0;
	ln_max_adet number := 5;
   cursor cur_bakiye
   is
	   Select a.doviz_kodu
	   from cbs_kasa_bakiye a,
	   		cbs_kasa_bakiye_islem b
	   where  b.tx_no = pn_islem_no and
	   		 a.DOVIZ_KODU = b.doviz_kodu and
			 a.KASA_KODU = ls_kasa_kodu and
			 a.sube_kodu = ls_sube_kodu and
			 a.banka_tarihi = b.banka_tarihi and
			 b.bakiye > a.bakiye  ;

	cursor cur_doviz_adet is
	 select count(distinct doviz_kodu) adet
	 from  cbs_kasa_bakiye_islem b
	 where tx_no  = pn_islem_no and
	 	   bakiye <> 0	  ;

	cursor cur_doviz is
	 select distinct doviz_kodu
	 from  cbs_kasa_bakiye_islem b
	 where tx_no  = pn_islem_no and
	 	   bakiye <> 0 and
	 	   doviz_kodu not in ( select distinct doviz_kodu
		   			  	  	   from cbs_kasa_kupur_bakiye_islem
		   			  	  	   where tx_no =pn_islem_no);


	bakiye_buyuk 		   exception;
	karsilanmadi 		   exception;
	max_doviz_asildi 	   exception;
 Begin
      ls_retval := pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'ANAKASAAL');

  	   select distinct urun_sinif_kod ,kasa_kodu,sube_kodu
	   into ls_urun_sinif,ls_kasa_kodu ,ls_sube_kodu
	   from cbs_kasa_bakiye_islem
	   where tx_no = pn_islem_no AND bakiye <> 0;

	  if ls_urun_sinif =  ls_RetVal  then
	  /* ANA KASA ALINAN ISE ana kasa doviz kodu dolu olan bakiyeleri */
	    ls_kasa_kodu := pkg_kasa.ana_kasa_kodu ;
		ls_sube_kodu :=ls_sube_kodu;
	  end if;

	for c_doviz_adet in cur_doviz_adet
	loop
		ln_adet :=c_doviz_adet.adet;
	end loop;

	if  nvl(ln_adet,0)  > ln_max_adet then
	  raise max_doviz_asildi;
	end if;

	ls_doviz := null;
	for c_doviz in cur_doviz loop
		ls_doviz := c_doviz.doviz_kodu ;
	end loop;

	if ls_doviz is not null then
	  raise karsilanmadi;
	 end if;

	ls_doviz := null;
	open  cur_bakiye;
	fetch cur_bakiye into ls_doviz;
	if ls_doviz is not null then
	  raise bakiye_buyuk;
	 end if;
	close cur_bakiye;


 	Exception
	 when no_data_found then
	 	 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '757' || pkg_hata.getUCPOINTER);
	 when bakiye_buyuk then
	 	 		 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '758' ||  pkg_hata.getdelimiter|| to_char(ls_doviz) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
	 when karsilanmadi then
	 	 		 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '760' ||  pkg_hata.getdelimiter|| to_char(ls_doviz) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
	 when max_doviz_asildi then
	 	 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '761' || pkg_hata.getdelimiter|| to_char(ln_max_adet) || pkg_hata.getdelimiter ||pkg_hata.getUCPOINTER);

  End;
Begin
	pn_1604_to_main_cash :=pkg_muhasebe.parametre_index_bul('1604_TO_MAIN_CASH');
	pn_1604_from_main_cash :=pkg_muhasebe.parametre_index_bul('1604_FROM_MAIN_CASH');
	pn_1604_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1604_BANKA_ACIKLAMA');
	pn_1604_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1604_DOVIZ_KODU');
	pn_1604_fc_islem :=pkg_muhasebe.parametre_index_bul('1604_FC_ISLEM');
	pn_1604_islem_sube :=pkg_muhasebe.parametre_index_bul('1604_ISLEM_SUBE');
	pn_1604_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1604_ISTATISTIK_KODU');
	pn_1604_kur :=pkg_muhasebe.parametre_index_bul('1604_KUR');
	pn_1604_lc_islem :=pkg_muhasebe.parametre_index_bul('1604_LC_ISLEM');
	pn_1604_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1604_MUSTERI_ACIKLAMA');
	pn_1604_referans :=pkg_muhasebe.parametre_index_bul('1604_REFERANS');
	pn_1604_tutar :=pkg_muhasebe.parametre_index_bul('1604_TUTAR');
	pn_1604_tutar_tl :=pkg_muhasebe.parametre_index_bul('1604_TUTAR_TL');
	pn_1604_dekont_aciklama :=pkg_muhasebe.parametre_index_bul('1604_DEKONT_ACIKLAMA');
	pn_1604_nakit_kodu_lc :=pkg_muhasebe.parametre_index_bul('1604_NAKIT_KODU_LC');
	pn_1604_nakit_kodu_fc :=pkg_muhasebe.parametre_index_bul('1604_NAKIT_KODU_FC');

END;
/

