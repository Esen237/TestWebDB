create PACKAGE BODY PKG_REPORT5 IS

	 FUNCTION GetNBEquivalent(ps_DOVIZ_KODU varchar2,pd_date DATE,pn_AMOUNT  number) RETURN VARCHAR2 is
	 		  ln_rate					   number;
			  ln_lcamount				   number;
	 BEGIN
	 	  if ps_DOVIZ_KODU<>pkg_genel.LC_al then
		 	  ln_rate:=Pkg_Kur.doviz_doviz_karsilik(ps_DOVIZ_KODU,pkg_genel.LC_al,pd_date,1,1,NULL,NULL,'N','A');
			  ln_lcamount:=Pkg_Kur.doviz_doviz_karsilik(ps_DOVIZ_KODU,pkg_genel.LC_al,pd_date,pn_AMOUNT,1,NULL,NULL,'N','A');

			  return to_char(ln_rate) || '/ '|| to_char(round(ln_lcamount,2));
		  else
		  	  return null;
		  end if;
	 END;

END PKG_REPORT5;
/

