create PACKAGE PKG_VIRMAN IS

/******************************************************************************
   Name       : PKG_VIRMAN
   Created By : Seval Balci
   Date    	  : 22.09.03
   Purpose	  : Virman ??lemleri
******************************************************************************/
 Function Sf_Hesap_Tipi_Virmana_Uygunmu(pn_hesap_no cbs_hesap.hesap_no%type ) return varchar2;
 Function Sf_Musteri_Tipi_Virman_Uygunmu(pn_musteri_no cbs_musteri.musteri_no%type ) return varchar2;
END;


/

