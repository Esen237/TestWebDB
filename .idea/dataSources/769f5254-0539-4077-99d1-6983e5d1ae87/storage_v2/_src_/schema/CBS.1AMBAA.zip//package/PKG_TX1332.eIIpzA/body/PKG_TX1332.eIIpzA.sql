create PACKAGE BODY     PKG_TX1332 IS 

 Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    
   Pkg_Tx1331.ApplicationStatusCheck(pn_islem_no);
   
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;

  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    null;
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
      
      ln_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE;
      ls_status CBS_CIB_LOAN_APPLICATION.STATUS%TYPE;
  BEGIN
       
        Pkg_Tx1331.ApplicationStatusCheck(pn_islem_no);

        SELECT APP_NO, STATUS INTO ln_app_no, ls_status
        FROM CBS_CIB_LOAN_APPLICATION_TX
        WHERE TX_NO = pn_islem_no;
        
        UPDATE CBS_CIB_LOAN_APPLICATION SET STATUS = ls_status, UPDATE_TX = pn_islem_no, update_date=sysdate
        WHERE APP_NO = ln_app_no;                      
        
    EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8005' || Pkg_Hata.getDelimiter ||  TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is    
  Begin
      null;
  End;
  
END;
/

