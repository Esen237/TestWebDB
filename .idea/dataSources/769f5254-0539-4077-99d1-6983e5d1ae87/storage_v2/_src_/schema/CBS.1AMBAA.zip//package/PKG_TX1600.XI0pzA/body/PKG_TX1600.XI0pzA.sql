create PACKAGE BODY PKG_TX1600 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	   kasa_bagliysa_hata_ver(pn_islem_no);

  End;

  Procedure kasa_bagliysa_hata_ver(pn_islem_no number ) is
   ls_kasa_bagli varchar2(1) := 'H';
   ls_kullanici_bagli varchar2(1) := 'H';
   kasa_bagli exception;
   kasa_kullanici_bagli exception;
  Begin

    select pkg_kasa.kasa_baglimi(kasa_kodu),
		   pkg_kasa.kullanici_kasaya_baglimi(kasa_kodu)
	into ls_kasa_bagli,
		 ls_kullanici_bagli
	from cbs_kasa_kullanici_tanim_islem
	where tx_no = pn_islem_no ;
	 if ls_kasa_bagli ='E' then
	 	raise kasa_bagli;
	 end if;
	 if ls_kullanici_bagli ='E' then
	 	raise kasa_kullanici_bagli;
	 end if;

   Exception
      when kasa_bagli then
	 	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '958' || pkg_hata.getUCPOINTER);
      when kasa_kullanici_bagli then
	 	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '959' || pkg_hata.getUCPOINTER);
      when others then null;


  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
	 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);

  End;

  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin

    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin

	kasa_bagliysa_hata_ver(pn_islem_no);

	insert into CBS_KASA_KULLANICI_TANIM
		   (TANIM_NO,
		    KASA_KODU,
		    KULLANICI_KODU,
			YARATAN_TX_NO,
			SON_GUNCELLEYEN_TX_NO,
			YARATAN_KULLANICI_KODU,
			YARATILDIGI_TARIH,
			MODUL_TUR_KOD,
			URUN_TUR_KOD,
			URUN_SINIF_KOD,
			DURUM_KODU,
			SUBE_KODU,
			BANKA_TARIHI)
	select  TANIM_NO,
			KASA_KODU,
		    KULLANICI_KODU,
			pn_islem_no,
			SON_GUNCELLEYEN_TX_NO,
			YARATAN_KULLANICI_KODU,
			YARATILDIGI_TARIH,
			MODUL_TUR_KOD,
			URUN_TUR_KOD,
			URUN_SINIF_KOD,
			DURUM_KODU,
			SUBE_KODU,
			pkg_muhasebe.banka_tarihi_bul
	 from CBS_KASA_KULLANICI_TANIM_ISLEM
	 where tx_no = pn_islem_No;


   /*Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '139' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  */
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   null;
  End;


END;
/

