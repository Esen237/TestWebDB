create PACKAGE BODY     PKG_HATA IS

  -- Function and procedure implementations
  PROCEDURE  HataLogEkle(errorcode VARCHAR2,
                    errortype VARCHAR2,
                    errordesc VARCHAR2,
                    derrorcode VARCHAR2,
                    derrortype VARCHAR2,
                    derrordesc VARCHAR2,
                    connectuser VARCHAR2,
                    windowsuser VARCHAR2,
                    computername VARCHAR2,
                    callingform VARCHAR2,
                    currentform VARCHAR2,
                    usernlslang VARCHAR2,
                    bolumkodu VARCHAR2,
                    rolnumarasi NUMBER,
                    rolkisaaciklama VARCHAR2) IS
   PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
        INSERT INTO CBS_HATA_LOG
        (error_nbr,error_code,error_type,error_desc,d_error_code,d_error_type,d_error_desc,connect_user,windows_user,computer_name,calling_form, current_form, user_nls_lang, bolum_kodu, rol_numarasi,rol_kisa_aciklama)
        VALUES
        (sq_error_nbr.NEXTVAL,errorcode,errortype,errordesc,derrorcode,derrortype,derrordesc,connectuser,windowsuser,computername,callingform, currentform, usernlslang, bolumkodu, rolnumarasi,rolkisaaciklama);

        COMMIT;
   END;
   ------------------------------------------------------
   -- IN: HATA NUMARASI,
   -- OUT: HATA MESAJI
   FUNCTION HataMesajiGetir(hata_kodu NUMBER,dil_kodu VARCHAR2) RETURN VARCHAR2 IS
            msg_text CBS_HATA_MESAJLARI.mesaj_text%TYPE;
            CURSOR msg_cursor (p_hatakodu NUMBER,p_dilkodu VARCHAR2) IS
                   SELECT mesaj_text
                   FROM CBS_HATA_MESAJLARI
                   WHERE hata_no=p_hatakodu
                         AND dil=p_dilkodu;
   BEGIN
        OPEN msg_cursor(hata_kodu,dil_kodu);
        FETCH msg_cursor INTO msg_text;

        IF msg_cursor%NOTFOUND THEN
            msg_text:=hata_kodu || ' error code could not be found in the table : CBS_HATA_MESAJLARI !';
        END IF;

        CLOSE msg_cursor;

        RETURN msg_text;
   END;
   ---------------------------------------------------
   PROCEDURE BolmeYap(num1 NUMBER,num2 NUMBER,result OUT NUMBER) IS
             hata_desc VARCHAR2(250);
   BEGIN
        result:=num1 / num2;
        --insert into cbs_hata_log (error_nbr)values('test');

        EXCEPTION
                 WHEN OTHERS THEN
                      --hata_kodu + param1 + param2 + ...
                      hata_desc := G_UC_POINTER || '1001' || G_UC_POINTER;
                      RAISE_APPLICATION_ERROR(-20100,hata_desc);

   END;
   -------------------------------------------------------
   FUNCTION GetDELIMITER RETURN VARCHAR2 IS
   BEGIN
        RETURN G_DELIMITER;
   END;
   ------------------------------------------------
   FUNCTION GetUCPOINTER RETURN VARCHAR2 IS
   BEGIN
        RETURN G_UC_POINTER;
   END;
   -----------------------------------------------
   FUNCTION MessageBuilder (p_dbms_errtxt VARCHAR2) RETURN VARCHAR2 IS
      l_errcode CBS_HATA_MESAJLARI.HATA_NO%TYPE;

      l_errtxt VARCHAR2(4000);
      l_err_length NUMBER;
      l_paramtxt VARCHAR2(4000);
      l_templatetxt VARCHAR(4000);

      l_start_indx NUMBER;
      l_end_indx NUMBER;

      l_message VARCHAR2(4000);
      l_template_startIndx NUMBER;
      l_param_startIndx NUMBER;

      l_t_currentIndx NUMBER:=1;
      l_p_currentIndx NUMBER:=1;
      l_param_no NUMBER:=1;

      l_temp_template VARCHAR2(4000);
      l_temp_param VARCHAR2(4000);

   BEGIN
      l_start_indx:=INSTR(p_dbms_errtxt,G_UC_POINTER);
      IF l_start_indx>0 THEN --eer hata parametreleri uygun formatta balyor ise
          l_end_indx:=INSTR(p_dbms_errtxt,G_UC_POINTER,l_start_indx + LENGTH(G_UC_POINTER));
          l_err_length:=l_end_indx-l_start_indx-LENGTH(G_UC_POINTER);
          l_errtxt:=SUBSTR(p_dbms_errtxt,l_start_indx+LENGTH(G_UC_POINTER),l_err_length);

          --CBS_HATA_MESAJLARI.HATA_NO = l_errcode
          IF INSTR(l_errtxt,G_DELIMITER)=0 THEN
                  l_errcode:=TO_NUMBER(l_errtxt);
          ELSE
              l_errcode:=TO_NUMBER(SUBSTR(l_errtxt,1,INSTR(l_errtxt,G_DELIMITER)-1));
                l_start_indx:=INSTR(l_errtxt,G_DELIMITER);
                l_paramtxt:=SUBSTR(l_errtxt,l_start_indx+LENGTH(G_DELIMITER));
          END IF;

          l_templatetxt:=HataMesajiGetir(l_errcode,'ENGLISH');
           --SELECT MESAJ_TEXT INTO l_templatetxt FROM CBS_HATA_MESAJLARI
           --WHERE HATA_NO=l_errcode AND DIL='TURKISH';--pkg_baglam.dil;

          --Message Replacer l_templatetxt <--- l_paramtxt
          --l_user_message:=GenerateMessage(l_templatetxt,l_paramtxt);
          --initialize the user message to empty string
          l_message:='';
          l_temp_template:=l_templatetxt;
          l_temp_param:=l_paramtxt;

          l_message :=l_templatetxt;
          LOOP
              EXIT WHEN  INSTR(l_errtxt,G_DELIMITER)=0;
            l_param_startIndx:=INSTR(l_temp_param,G_DELIMITER,l_p_currentIndx);
            IF NVL(l_param_startIndx,0)=0 THEN
              l_message:=REPLACE(l_message,G_DELIMITER || TO_CHAR(l_param_no),SUBSTR(l_temp_param,l_p_currentIndx));
              l_p_currentIndx:=-1;
            ELSE
              l_message:=REPLACE(l_message,G_DELIMITER || TO_CHAR(l_param_no),SUBSTR(l_temp_param,l_p_currentIndx,l_param_startIndx-l_p_currentIndx));
              l_p_currentIndx:=l_param_startIndx+LENGTH(G_DELIMITER);
            END IF;

            EXIT WHEN l_p_currentIndx=-1;

            l_param_no:=l_param_no+1;
          END LOOP;
        ELSE--eer hata parametre stringi hatal formatta ise aynen geleni gster.
            l_message:=p_dbms_errtxt;
        END IF;

      RETURN ' CBS-'|| l_errcode || ':' || l_message;
 exception
           when others then
                       RETURN ' CBS-'|| l_errcode || ':' || p_dbms_errtxt;

   END;
--###########################################################################################
    FUNCTION GenerateMessage( p_dbms_errtxt VARCHAR2) RETURN VARCHAR2 IS
           lv_result VARCHAR2(4000);
        l_uc      VARCHAR2(3):=G_UC_POINTER;
        tempstr      VARCHAR2(4000);
        str1      VARCHAR2(4000);
        i          NUMBER:=1;
        ln_position          NUMBER:=1;
        ln_start_index          NUMBER:=0;
        ln_end_index          NUMBER:=0;
        result                  VARCHAR2(4000);
        l_uc_count              NUMBER:=1;
        l_last_ucpoint          NUMBER:=1;
   BEGIN
    IF INSTR(p_dbms_errtxt,l_uc,1) = 0 then 
--        -- b-o-m seval.colak 13112021
--        INSTR(p_dbms_errtxt,'***ORA-',1) <> 0 or   INSTR(p_dbms_errtxt,'###ORA-',1) <> 0 or   
--       ( INSTR(p_dbms_errtxt,'ORA-',1) <> 0 and instr(substr(p_dbms_errtxt,INSTR(p_dbms_errtxt,'ORA-') ),'***')  <> 0 ) or --seval.colak 13112021  to prevent exmp ORA-12899: value too large ***'
--       ( INSTR(p_dbms_errtxt,'ORA-',1) <> 0 and instr(substr(p_dbms_errtxt,INSTR(p_dbms_errtxt,'ORA-') ),'###')  <> 0 ) then
--          -- e-o-m seval.colak 13112021
      --uc hic gonderilmediyse........ mutlu
      RETURN p_dbms_errtxt;
    END IF;
    WHILE INSTR(p_dbms_errtxt,l_uc,1,l_uc_count)>0 LOOP
          l_last_ucpoint:=INSTR(p_dbms_errtxt,l_uc,1,l_uc_count);
          l_uc_count:=l_uc_count+1;
    END LOOP;
    IF l_last_ucpoint>1 THEN
       l_last_ucpoint:=l_last_ucpoint+2;
    END IF;
    tempstr:=SUBSTR(p_dbms_errtxt,1,l_last_ucpoint);
    str1:=tempstr;


    IF    INSTR(p_dbms_errtxt,l_uc)>0 THEN
        LOOP
            WHILE INSTR(tempstr,l_uc,ln_position,1)<>0 AND LENGTH(tempstr)>ln_position LOOP
              IF i=1 THEN
                  ln_start_index:=INSTR(tempstr,l_uc,ln_position,1);
              ELSE
                  ln_end_index:=INSTR(tempstr,l_uc,ln_position,1);
              END IF;
              ln_position:=INSTR(tempstr,l_uc,ln_position,1)+3;
              i:=i+1;
            END LOOP ;
            --ln_start_index:=instr(tempstr,l_uc,1,1);
            --ln_end_index:=instr(tempstr,l_uc,1,2);  ayn i gibi mutlu
            IF ln_start_index=0 AND ln_end_index=0 THEN
                result:=pkg_hata.MessageBuilder(l_uc || tempstr || l_uc);

                str1:=REPLACE(str1,l_uc || tempstr || l_uc,result);
                tempstr:=str1;
                EXIT WHEN INSTR(tempstr,l_uc)=0;
            ELSE
                tempstr:=SUBSTR(tempstr,ln_start_index+3,ln_end_index-ln_start_index-3);
            END IF;
            i:=1;
            ln_position:=1;
            ln_start_index:=0;
            ln_end_index:=0;
        END LOOP;
    ELSE--uygun formatta deilse aynen gster
        tempstr:=p_dbms_errtxt;
    END IF;
    --return  message
    lv_result:=REPLACE(tempstr,'ORA-20100:','');
    RETURN lv_result;
--        EXCEPTION  
--           WHEN others THEN
--              LOG_AT('pkg_hata',SQLERRM,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); --bahianab 11.11.21 cbs-541 ekstre error
--                       RETURN SUBSTR(SQLERRM,1,1500); --bahianab 11.11.21 cbs-541 ekstre error
   END;
--###########################################################################################\

Function GetPrintingOrder(pn_txno number) return varchar2 is
   CURSOR islem_cursor IS
            select *from cbs_collection_detail_tran
            where tx_no = pn_txno
            and INSTITUTION_CODE not in ('KCELL','KMOBILE')
            order by DETAIL_ID ;

    row_islem                              islem_cursor%ROWTYPE;
    ls_printorder                      varchar2(2000):='';
    ln_number                          number:=1;
Begin

      OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    while islem_cursor%FOUND
    LOOP
        ls_printorder:=ls_printorder || '(' || ln_number || ') Institution:' || row_islem.INSTITUTION_CODE ||' Amount:' || row_islem.COLLECTION_AMOUNT || ' Invoice:' ||row_islem.INVOICE_NO || chr(10);
        ln_number:=ln_number+1;
        FETCH islem_cursor INTO row_islem;
    END LOOP;
    CLOSE islem_cursor;

    return ls_printorder;
END;
----------------------------------------------------------------------------------------------------
END PKG_HATA;
/

