create PACKAGE pkg_masraf_tx33204 IS

  -- TX Event Listesi
  --?HRACAT ve ?THALAT ekranlar?nda kullan?lan MASRAF objeleri i?in paket

  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2);		-- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2);-- Islem iptal edildikten sonra cagrilir

  Procedure onay_sonrasi(pn_islem_no number, ps_ref varchar2, pn_no number);  --onaydan sonra ca?r?l?r.....
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2);		-- Islem reddedildikten sonra cagrilir

  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2);  		-- Isleme iliskin formlar basildiktan sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2);		-- Islem iptal edilirse

  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number);			-- Islemin muhasebelesmesi icin cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  Procedure muhasebe_sonrasi(pn_islem_no number, ps_ref varchar2, pn_no number);  --muhasebeden sonra ca?r?l?r.....

END;


/

