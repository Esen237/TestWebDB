create PACKAGE BODY     "PKG_LIMIT" IS

  g_uc_delimiter VARCHAR2(3):= Pkg_Hata.getUCPOINTER;
  g_ara_delimiter VARCHAR2(3):= Pkg_Hata.getDELIMITER;

  FUNCTION Musteri_Grubunun_Limiti_Var_Mi(ps_grupkod CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE) RETURN NUMBER
   IS
    ln_count      NUMBER;
  BEGIN
    --    ls_count=0 ise limit yok ls_count=1 limit var

      SELECT COUNT(*)
    INTO   ln_count
    FROM   CBS_MUSTERI_GRUP_LIMIT
    WHERE  grup_kodu = ps_grupkod  ;

    IF ln_count >0 THEN ln_count :=1 ; END IF;

    RETURN ln_count  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/
  FUNCTION Musteri_Limiti_Var_Mi(pn_musteri_no CBS_GRUP_KODLARI.grup_kodu%TYPE ) RETURN NUMBER
   IS
    ls_count      NUMBER;
  BEGIN
    --    ls_count=0 ise limit yok ls_count=1 limit var

      SELECT COUNT(*)
    INTO   ls_count
    FROM   CBS_MUSTERI_LIMIT
    WHERE  musteri_no = pn_musteri_no  ;

    IF ls_count >0 THEN ls_count :=1 ; END IF;

    RETURN ls_count  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION Musteri_Limiti_guncelle_ctrl(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER
   IS
    ln_sonuc      NUMBER;
    ln_txno      NUMBER;
    /* M??teri limiti g?ncelleme ekran? i?in kullan?l?r.*/
    /* E?er ayn? m??teri daha ?nce g?ncellenmi? ama yap?lan bu i?lem hala onay bekliyorsa (tamamlanmami?sa) */
    /* ayni musteri ile ilgili yeni bir guncelleme yap?lmas?na izin verilmemeli.*/
  BEGIN
    --    ln_sonuc=0 ise guncellenemez,ln_sonuc=1 guncellenebilir

    SELECT NVL(MAX(a.tx_no),0)
    INTO   ln_txno
    FROM   CBS_MUSTERI_LIMIT_GUNCELLE a, CBS_ISLEM b
    WHERE  b.numara      = a.tx_no
    AND    b.kayit_tarih = Pkg_Muhasebe.Banka_Tarihi_Bul
    AND    musteri_no    = pn_musteri_no    ;

    ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;

    RETURN ln_sonuc  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1903' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  FUNCTION MusteriGrupLimit_guncelle_ctrl(pn_grup_kodu CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE) RETURN NUMBER
   IS
    ln_sonuc      NUMBER;
    ln_txno      NUMBER;
    /* M??teri limiti g?ncelleme ekran? i?in kullan?l?r.*/
    /* E?er ayn? m??teri daha ?nce g?ncellenmi? ama yap?lan bu i?lem hala onay bekliyorsa (tamamlanmami?sa) */
    /* ayni musteri ile ilgili yeni bir guncelleme yap?lmas?na izin verilmemeli.*/
  BEGIN
    --    ln_sonuc=0 ise guncellenemez,ln_sonuc=1 guncellenebilir

    SELECT NVL(MAX(a.tx_no),0)
    INTO   ln_txno
    FROM   CBS_MUSTERI_GRUP_LIMIT_ISLEM a, CBS_ISLEM b
    WHERE  a.islem_kodu  = 6102
    AND    b.numara      = a.tx_no
    AND    b.kayit_tarih = Pkg_Muhasebe.Banka_Tarihi_Bul
    AND    grup_kodu     = pn_grup_kodu;

    ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;

    RETURN ln_sonuc  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1905' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/


  FUNCTION Urun_limit_grubu_adi_al(pn_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2
   IS
    ls_tanim      CBS_URUN_GRUBU.tanim%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT tanim
    INTO   ls_tanim
    FROM   CBS_URUN_GRUBU
    WHERE  numara = pn_numara ;

    RETURN ls_tanim  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1748' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  PROCEDURE MusteriGrubu_limit_BilgiAktar(ps_grup_kodu IN CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE,
                                          p_txno IN NUMBER) IS
  BEGIN
    -- Bu fonksiyon M??teri grubu limitlerini g?ncelleme program?nda kullan?lmaktad?r.

          INSERT INTO CBS_MUSTERI_GRUP_LIMIT_ISLEM
            (tx_no, grup_kodu , lc_limit , fc_doviz_kodu , fc_limit , lc_risk, fc_risk , nakdi_lc_limit ,
                   gnakdi_lc_limit , nakdi_fc_limit , gnakdi_fc_limit, nakdi_lc_risk , gnakdi_lc_risk ,
                   nakdi_fc_risk , gnakdi_fc_risk , yenileme_vadesi)
            SELECT p_txno,
                    grup_kodu , lc_limit , fc_doviz_kodu , fc_limit , lc_risk, fc_risk , nakdi_lc_limit ,
                   gnakdi_lc_limit , nakdi_fc_limit , gnakdi_fc_limit, nakdi_lc_risk , gnakdi_lc_risk ,
                   nakdi_fc_risk , gnakdi_fc_risk , yenileme_vadesi
            FROM   CBS_MUSTERI_GRUP_LIMIT
            WHERE  grup_kodu = ps_grup_kodu ;

        INSERT INTO CBS_MUSTERI_GRUB_URUN_LIMITISL
            (tx_no,grup_kodu ,urun_grub_no ,lc_limit ,fc_doviz_kodu ,fc_limit,lc_risk ,fc_risk)
            SELECT p_txno,
                   grup_kodu , urun_grub_no , lc_limit , fc_doviz_kodu , fc_limit, lc_risk , fc_risk
            FROM   CBS_MUSTERI_GRUB_URUN_LIMIT
            WHERE  grup_kodu = ps_grup_kodu;


    EXCEPTION
           WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1773' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /***********************************/

PROCEDURE Musteri_limit_BilgiAktar(pn_musteri_no IN CBS_MUSTERI_LIMIT.musteri_no%TYPE,
                                          p_txno IN NUMBER) IS
  BEGIN
    -- Bu fonksiyon M??teri limitlerini g?ncelleme program?nda kullan?lmaktad?r.

          INSERT INTO CBS_MUSTERI_LIMIT_GUNCELLE
            (tx_no, musteri_no, lc_limit , fc_doviz_kodu , fc_limit , lc_risk, fc_risk , nakdi_lc_limit ,
                   gnakdi_lc_limit , nakdi_fc_limit , gnakdi_fc_limit, nakdi_lc_risk , gnakdi_lc_risk ,
                   nakdi_fc_risk , gnakdi_fc_risk , yenileme_vadesi)
            SELECT p_txno,
                    musteri_no , lc_limit , fc_doviz_kodu , fc_limit , lc_risk, fc_risk , nakdi_lc_limit ,
                   gnakdi_lc_limit , nakdi_fc_limit , gnakdi_fc_limit, nakdi_lc_risk , gnakdi_lc_risk ,
                   nakdi_fc_risk , gnakdi_fc_risk , yenileme_vadesi
            FROM   CBS_MUSTERI_LIMIT
            WHERE  musteri_no = pn_musteri_no ;

        INSERT INTO CBS_MUSTERI_URUN_LIMIT_GUNCEL
            (tx_no,musteri_no ,urun_grub_no ,lc_limit ,fc_doviz_kodu ,fc_limit,lc_risk ,fc_risk)
            SELECT p_txno,
                   musteri_no , urun_grub_no , lc_limit , fc_doviz_kodu , fc_limit, lc_risk , fc_risk
            FROM   CBS_MUSTERI_URUN_LIMIT
            WHERE   musteri_no = pn_musteri_no;


    EXCEPTION
           WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1787' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 /***********************************/

  FUNCTION Musteri_Tipi_Al(pn_musteri CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2
   IS
    ls_musteri_tipi     CBS_MUSTERI_TIPI_KODLARI.musteri_tipi%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT musteri_tipi_kod
    INTO   ls_musteri_tipi
    FROM   CBS_MUSTERI
    WHERE  musteri_no = pn_musteri ;

    RETURN ls_musteri_tipi ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1786' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  PROCEDURE Baglantili_musterileri_getir(ps_grup_kodu CBS_GRUP_KODLARI.grup_kodu%TYPE,
                                           pRetCur       IN OUT Pkg_Rapor.Generic_CurType)
  IS
   TYPE Generic_CurType IS REF CURSOR;
  BEGIN

   OPEN pRetCur FOR
   SELECT musteri_no
   FROM CBS_MUSTERI
   WHERE grup_kod = ps_grup_kodu
   ORDER BY musteri_no        ;

   EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


  END;
 /*****************************    */
  PROCEDURE urun_grubuna_bagli_urunleri_al(pn_grup_kodu CBS_URUN_GRUBU.numara%TYPE,
                                           pRetCur       IN OUT Pkg_Rapor.Generic_CurType)
  IS
   TYPE Generic_CurType IS REF CURSOR;
  BEGIN

   OPEN pRetCur FOR
   SELECT urun_sinif_kod
   FROM CBS_URUN_GRUBU_URUN
   WHERE urun_grub_no =pn_grup_kodu ;

   EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1907' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


  END;
 /*****************************    */


  PROCEDURE urun_grubuna_bagli_uruntur_al(pn_grup_kodu CBS_URUN_GRUBU.numara%TYPE,
                                            pRetCur       IN OUT Pkg_Rapor.Generic_CurType)
  IS
   TYPE Generic_CurType IS REF CURSOR;
  BEGIN

   OPEN pRetCur FOR
   SELECT urun_tur_kod
   FROM CBS_URUN_GRUBU_URUN
   WHERE urun_grub_no =pn_grup_kodu ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4267' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
  /***************************************/

  PROCEDURE Grup_Limit_Kontrol( ps_grup_kodu         CBS_MUSTERI.grup_kod%TYPE,
                                  pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE,
                                pn_toplam_fc_tutar  CBS_SATIR.lc_tutar%TYPE,
                                pn_toplam_lc_tutar  CBS_SATIR.lc_tutar%TYPE,
                                ps_doviz_kod        CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                                ps_nakdi            CBS_URUN_SINIF.nakdi%TYPE,
                                ps_modul_tur_kod    CBS_URUN_SINIF.modul_tur_kod%TYPE,
                                ps_urun_tur_kod     CBS_URUN_SINIF.urun_tur_kod%TYPE,
                                ps_urun_sinif_kod   CBS_URUN_SINIF.kod%TYPE,
                                ps_musteri_tipi_kod CBS_MUSTERI.musteri_tipi_kod%TYPE,
                                pb_limit_kontrol    BOOLEAN DEFAULT TRUE,
                                pb_dovize_endeksli  BOOLEAN DEFAULT FALSE,
                                ps_satir_tur         CBS_SATIR.tur%TYPE,
                                p_EOD                 varchar2 default 'H'
) IS

  ls_limit_doviz_kodu            CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_lc_limit                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_fc_limit                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_lc_risk                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_fc_risk                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_lc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_fc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_lc_limit            CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_fc_limit            CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_grub_no                CBS_URUN_GRUBU.numara%TYPE;

  ls_urun_limit_doviz_kodu        CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_urun_lc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_fc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;

  ln_mevcut_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;

  ln_fc_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_lc_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_mevcut_bakiye            CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_lc_mevcut_bakiye            CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_urun_mevcut_bakiye        CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_urun_yeni_bakiye        CBS_HESAP_BAKIYE.bakiye%TYPE;

  lb_risk_azalmiyor                BOOLEAN:=TRUE;
  ps_endeks_kontrol_doviz_kodu    CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_eod_fc_tutar                number;

  BEGIN
    -- Grubun Mevcut Limit ve Risk Bilgileri sorgulan?r
    BEGIN
      SELECT fc_doviz_kodu,NVL(lc_limit,0),NVL(fc_limit,0),NVL(lc_risk,0),NVL(fc_risk,0),
             NVL(nakdi_lc_limit,0),NVL(nakdi_fc_limit,0),NVL(nakdi_lc_risk,0),NVL(nakdi_fc_risk,0),
             NVL(gnakdi_lc_limit,0),NVL(gnakdi_fc_limit,0),NVL(gnakdi_lc_risk,0),NVL(gnakdi_fc_risk,0)
        INTO ls_limit_doviz_kodu,ln_lc_limit,ln_fc_limit,ln_lc_risk,ln_fc_risk,
             ln_nakdi_lc_limit,ln_nakdi_fc_limit,ln_nakdi_lc_risk,ln_nakdi_fc_risk,
             ln_gnakdi_lc_limit,ln_gnakdi_fc_limit,ln_gnakdi_lc_risk,ln_gnakdi_fc_risk
        FROM CBS_MUSTERI_GRUP_LIMIT
       WHERE grup_kodu=ps_grup_kodu;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1815' ||g_ara_delimiter||TO_CHAR(ps_grup_kodu)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1816' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    -- Hesab?n hangi limit ?r?n grubuna ait buldu?u bulunur
    BEGIN
      SELECT urun_grub_no
        INTO ln_urun_grub_no
        FROM CBS_URUN_GRUBU_URUN,CBS_URUN_GRUBU
       WHERE modul_tur_kod=ps_modul_tur_kod
         AND urun_tur_kod=ps_urun_tur_kod
         AND urun_sinif_kod=ps_urun_sinif_kod
         AND CBS_URUN_GRUBU_URUN.urun_grub_no=CBS_URUN_GRUBU.numara
         AND CBS_URUN_GRUBU.musteri_tipi=ps_musteri_tipi_kod;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1817' ||g_ara_delimiter||ps_modul_tur_kod||'-'||ps_urun_tur_kod||'-'||ps_urun_sinif_kod||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1818' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    -- M??terinin ilgili ?r?n grubu limitleri sorgulan?r
    BEGIN
      SELECT fc_doviz_kodu,NVL(lc_limit,0),NVL(fc_limit,0),NVL(lc_risk,0),NVL(fc_risk,0)
        INTO ls_urun_limit_doviz_kodu,ln_urun_lc_limit,ln_urun_fc_limit,ln_urun_lc_risk,ln_urun_fc_risk
        FROM CBS_MUSTERI_GRUB_URUN_LIMIT
       WHERE grup_kodu  =ps_grup_kodu
         AND urun_grub_no=ln_urun_grub_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1819' ||g_ara_delimiter||TO_CHAR(ps_grup_kodu)||g_ara_delimiter||TO_CHAR(ln_urun_grub_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1820' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
   -- Hesab?n mevcut_bakiyesi bulunur
    BEGIN
      SELECT NVL(bakiye,0)
        INTO ln_mevcut_bakiye
        FROM CBS_HESAP_BAKIYE
       WHERE hesap_no=pn_hesap_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1821' ||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1822' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;

    if p_eod = 'E' then
        -- EOD sirasinda henuz muhasebelesmemis fisler var onlara dikkat
          select sum(decode(s.tur,'A', nvl(dv_tutar,0), -1*nvl(dv_tutar,0)))
            into ln_eod_fc_tutar
            from cbs_satir s
           where s.fis_numara in (select fis_numara from cbs_eod_fis_no ef
                                   where ef.durum = 'A')
             and s.hesap_numara = pn_hesap_no;

            ln_eod_fc_tutar := nvl(ln_eod_fc_tutar, 0);
            ln_mevcut_bakiye := ln_mevcut_bakiye + ln_eod_fc_tutar;
     end if;

    IF  pb_dovize_endeksli THEN

    -- D?vize endeksli bir hesap
      ln_mevcut_bakiye:=pn_toplam_fc_tutar;
      ln_yeni_bakiye:=pn_toplam_fc_tutar;

      ln_fc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
      ln_lc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
      ln_fc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_lc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_fc_urun_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_fc_urun_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');

      ln_fc_risk:=ln_fc_risk+ln_fc_mevcut_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk+ln_fc_urun_mevcut_bakiye;
      ln_lc_risk:=ln_lc_risk+ln_lc_mevcut_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk+ln_lc_mevcut_bakiye;

    ELSE
    -- Normal bir hesap

   -- Hesab?n yeni_bakiyesi hesaplan?r
    ln_yeni_bakiye:=ln_mevcut_bakiye+pn_toplam_fc_tutar;

    log_at('Genel Limit Kontrol ?ncesi','FC Mevcut Bakiye:'||to_char(ln_mevcut_bakiye),'FC Yeni Bakiye:'||to_char(ln_yeni_bakiye),'');

   -- Limit Kontrol? i?in fc_yeni_bakiye ve lc_yeni_bakiye elde edilir
    ln_fc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
    ln_lc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
    ln_fc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_lc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_fc_urun_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_fc_urun_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');

   -- Olu?an riskler hesaplan?r
    IF ln_mevcut_bakiye <= 0 AND ln_yeni_bakiye >= 0 THEN
     log_at('Genel Limit Kontrol S?ras?nda','1','','');
      ln_fc_risk:=ln_fc_risk+ln_fc_mevcut_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk+ln_fc_urun_mevcut_bakiye;
      ln_lc_risk:=ln_lc_risk+ln_lc_mevcut_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk+ln_lc_mevcut_bakiye;
    ELSIF ln_mevcut_bakiye >= 0 AND ln_yeni_bakiye < 0 THEN
    log_at('Genel Limit Kontrol S?ras?nda','2','','');
      ln_fc_risk:=ln_fc_risk-ln_fc_yeni_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk-ln_fc_yeni_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk-ln_fc_yeni_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk-ln_fc_urun_yeni_bakiye;
      ln_lc_risk:=ln_lc_risk-ln_lc_yeni_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk-ln_lc_yeni_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk-ln_lc_yeni_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk-ln_lc_yeni_bakiye;
    ELSIF ln_mevcut_bakiye <= 0 AND ln_yeni_bakiye < 0 THEN
      log_at('Genel Limit Kontrol S?ras?nda','3','','');
      IF ln_yeni_bakiye < ln_mevcut_bakiye THEN
     log_at('Genel Limit Kontrol S?ras?nda','4','','');
          ln_fc_risk:=ln_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_nakdi_fc_risk:=ln_nakdi_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_urun_fc_risk:=ln_urun_fc_risk-(ln_fc_urun_yeni_bakiye-ln_fc_urun_mevcut_bakiye);
        ln_lc_risk:=ln_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_nakdi_lc_risk:=ln_nakdi_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_urun_lc_risk:=ln_urun_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
      ELSE
    log_at('Genel Limit Kontrol S?ras?nda','5','','');
          ln_fc_risk:=ln_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_nakdi_fc_risk:=ln_nakdi_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_urun_fc_risk:=ln_urun_fc_risk+(ln_fc_urun_mevcut_bakiye-ln_fc_urun_yeni_bakiye);
        ln_lc_risk:=ln_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_nakdi_lc_risk:=ln_nakdi_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_urun_lc_risk:=ln_urun_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        lb_risk_azalmiyor:=FALSE;
      END IF;
    END IF;
    END IF;

    -- Genel limit (Grup baz?nda) kontrolleri yap?l?r
    log_at('Riskler','FC'||to_char(ln_fc_risk),'','');

    IF pb_limit_kontrol AND lb_risk_azalmiyor AND ps_satir_tur ='B' THEN  -- G?nsonunda limit kontrol? yap?lmadan riskler g?ncel kurdan g?nncellenir
                                                                                       -- Sadece Bor? (Risk) yaratan sat?rlar i?in kontrol yap?lmal?

       IF ln_fc_risk > ln_fc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1823' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;
--Yerzhant 15022010 removed the comment
 -- lc riskler kontrol edilmiyor 2007-04-24
      IF ln_lc_risk > ln_lc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1824' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;

      IF ps_nakdi='E' THEN
        IF ln_nakdi_fc_risk > ln_nakdi_fc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1825' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
--Yerzhant 15022010 removed the comment
-- lc riskler kontrol edilmiyor 2007-04-24
        IF ln_nakdi_lc_risk > ln_nakdi_lc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1826' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
      ELSE
        IF ln_gnakdi_fc_risk > ln_gnakdi_fc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1827' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
--Yerzhant 15022010 removed the comment
-- lc riskler kontrol edilmiyor 2007-04-24
        IF ln_gnakdi_lc_risk > ln_gnakdi_lc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1828' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
      END IF;

    -- ?r?n Grubu limit kontrolleri yap?l?r

      IF ln_urun_fc_risk > ln_urun_fc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1829' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;

--Yerzhant 15022010 removed the comment
-- lc riskler kontrol edilmiyor 2007-04-24
      IF ln_urun_lc_risk > ln_urun_lc_limit THEN
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1830' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;

    END IF;
--Yerzhant 15022010 removed the comment
    -- Risk(ler)in s?f?rdan k???k olmamas? gerekir
--    Sevil Han?m'?n talebi ?zerinde kurdan dolay? ge?ici olarak negatif de?ere d?n??mesine izin verildi : Erguna 05.12.2003
    if ln_lc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1831' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ln_fc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1832' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ps_nakdi='E' then
      if ln_nakdi_lc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1833' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;

      if ln_nakdi_fc_risk < 0 then
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1834' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;
    else
      if ln_gnakdi_lc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1835' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;

      if ln_gnakdi_fc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1836' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;
    end if;

    if ln_urun_lc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1837' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ln_urun_fc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1838' ||g_ara_delimiter||ps_grup_kodu||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if p_EOD = 'E' then
       --EOD s?ra?nda risk update yapm?yoruz........
       return;
    end if;
    -- E?er limit a??m? olmad?ysa risk bilgilerini g?ncelle

    BEGIN
      IF ps_nakdi='E' THEN
         UPDATE CBS_MUSTERI_GRUP_LIMIT
            SET lc_risk=ln_lc_risk,
                fc_risk=ln_fc_risk,
                nakdi_lc_risk=ln_nakdi_lc_risk,
                nakdi_fc_risk=ln_nakdi_fc_risk
          WHERE grup_kodu=ps_grup_kodu;
      ELSE
         UPDATE CBS_MUSTERI_GRUP_LIMIT
            SET lc_risk=ln_lc_risk,
                fc_risk=ln_fc_risk,
                gnakdi_lc_risk=ln_gnakdi_lc_risk,
                gnakdi_fc_risk=ln_gnakdi_fc_risk
          WHERE grup_kodu=ps_grup_kodu;
      END IF;
    EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1839' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;

    -- M??terinin ilgili ?r?n grubu riskleri g?ncellenir

    BEGIN
      UPDATE CBS_MUSTERI_GRUB_URUN_LIMIT
         SET lc_risk=ln_urun_lc_risk,
             fc_risk=ln_urun_fc_risk
          WHERE grup_kodu=ps_grup_kodu
            AND urun_grub_no=ln_urun_grub_no;
    EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1840' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
  END;

  PROCEDURE Genel_Limit_Kontrol(pn_musteri_no         CBS_MUSTERI.musteri_no%TYPE,
                                  pn_hesap_no         CBS_HESAP_KREDI.hesap_no%TYPE,
                                pn_toplam_fc_tutar  CBS_SATIR.lc_tutar%TYPE,
                                pn_toplam_lc_tutar  CBS_SATIR.lc_tutar%TYPE,
                                ps_doviz_kod        CBS_DOVIZ_KODLARI.doviz_kodu%TYPE,
                                ps_nakdi            CBS_URUN_SINIF.nakdi%TYPE,
                                ps_modul_tur_kod    CBS_URUN_SINIF.modul_tur_kod%TYPE,
                                ps_urun_tur_kod     CBS_URUN_SINIF.urun_tur_kod%TYPE,
                                ps_urun_sinif_kod   CBS_URUN_SINIF.kod%TYPE,
                                pn_kredi_teklif_satir_numara CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE,
                                ps_musteri_tipi_kod       CBS_MUSTERI.musteri_tipi_kod%TYPE,
                                pb_limit_kontrol    BOOLEAN DEFAULT TRUE,
                                pb_dovize_endeksli   BOOLEAN DEFAULT FALSE,
                                ps_satir_tur         CBS_SATIR.tur%TYPE,
                                p_EOD                 varchar2 DEFAULT 'H'
                                ) IS

  ls_limit_doviz_kodu            CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_lc_limit                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_fc_limit                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_lc_risk                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_fc_risk                    CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_lc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_fc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_nakdi_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_lc_limit            CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_fc_limit            CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_gnakdi_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_grub_no                CBS_URUN_GRUBU.numara%TYPE;

  ls_urun_limit_doviz_kodu        CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_urun_lc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_fc_limit                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_lc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;
  ln_urun_fc_risk                CBS_MUSTERI_LIMIT.lc_limit%TYPE;

  ln_mevcut_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;

  ln_fc_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_lc_yeni_bakiye                CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_mevcut_bakiye            CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_lc_mevcut_bakiye            CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_urun_mevcut_bakiye        CBS_HESAP_BAKIYE.bakiye%TYPE;
  ln_fc_urun_yeni_bakiye        CBS_HESAP_BAKIYE.bakiye%TYPE;

  lb_risk_azalmiyor                BOOLEAN:=TRUE;

  ps_endeks_kontrol_doviz_kodu    CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
  ln_eod_fc_tutar                number;
-- B-O-M AdiletK 10032016 CQ4712 increasing real limit when installment is paid  
  ln_limit_diff number; 
  ls_line varchar2(3);
  ld_matur_date DATE;
  ls_tranches varchar2(3);
  ln_count number;
  ln_real_limit number;
-- E-O-M AdiletK 10032016 CQ4712 increasing real limit when installment is paid    
  BEGIN
    -- M??terinin Mevcut Limit ve Risk Bilgileri sorgulan?r
    BEGIN
      SELECT fc_doviz_kodu,NVL(lc_limit,0),NVL(fc_limit,0),NVL(lc_risk,0),NVL(fc_risk,0),
             NVL(nakdi_lc_limit,0),NVL(nakdi_fc_limit,0),NVL(nakdi_lc_risk,0),NVL(nakdi_fc_risk,0),
             NVL(gnakdi_lc_limit,0),NVL(gnakdi_fc_limit,0),NVL(gnakdi_lc_risk,0),NVL(gnakdi_fc_risk,0)
        INTO ls_limit_doviz_kodu,ln_lc_limit,ln_fc_limit,ln_lc_risk,ln_fc_risk,
             ln_nakdi_lc_limit,ln_nakdi_fc_limit,ln_nakdi_lc_risk,ln_nakdi_fc_risk,
             ln_gnakdi_lc_limit,ln_gnakdi_fc_limit,ln_gnakdi_lc_risk,ln_gnakdi_fc_risk
        FROM CBS_MUSTERI_LIMIT
       WHERE musteri_no=pn_musteri_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1752' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1753' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    -- Hesab?n hangi limit ?r?n grubuna ait buldu?u bulunur
    BEGIN
      SELECT urun_grub_no
        INTO ln_urun_grub_no
        FROM CBS_URUN_GRUBU_URUN,CBS_URUN_GRUBU
       WHERE modul_tur_kod=ps_modul_tur_kod
         AND urun_tur_kod=ps_urun_tur_kod
         AND urun_sinif_kod=ps_urun_sinif_kod
          AND CBS_URUN_GRUBU_URUN.urun_grub_no=CBS_URUN_GRUBU.numara
         AND CBS_URUN_GRUBU.musteri_tipi=ps_musteri_tipi_kod;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        log_at('LIMIT ERROR: ', ps_modul_tur_kod||'+'||ps_urun_tur_kod||'+'||ps_urun_sinif_kod||'='||pn_musteri_no, ps_musteri_tipi_kod, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1754' ||g_ara_delimiter||ps_modul_tur_kod||'-'||ps_urun_tur_kod||'-'||ps_urun_sinif_kod||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1755' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    -- M??terinin ilgili ?r?n grubu limitleri sorgulan?r
    BEGIN
      SELECT fc_doviz_kodu,NVL(lc_limit,0),NVL(fc_limit,0),NVL(lc_risk,0),NVL(fc_risk,0)
        INTO ls_urun_limit_doviz_kodu,ln_urun_lc_limit,ln_urun_fc_limit,ln_urun_lc_risk,ln_urun_fc_risk
        FROM CBS_MUSTERI_URUN_LIMIT
       WHERE musteri_no  =pn_musteri_no
         AND urun_grub_no=ln_urun_grub_no
         AND ( kredi_teklif_satir_numara=0 OR kredi_teklif_satir_numara=pn_kredi_teklif_satir_numara); -- Banka tipi m??teriler i?in teklif ?art de?il.
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1756' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(ln_urun_grub_no)||g_ara_delimiter||TO_CHAR(pn_kredi_teklif_satir_numara)||g_uc_delimiter);

        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1757' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
   -- Hesab?n mevcut_bakiyesi bulunur
    BEGIN
      SELECT NVL(bakiye,0)
        INTO ln_mevcut_bakiye
        FROM CBS_HESAP_BAKIYE
       WHERE hesap_no=pn_hesap_no;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1758' ||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1775' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    -- B-O-M AdiletK 04.01.2017 CQ4712 real limit
    BEGIN
        SELECT nvl(real_limit, ln_urun_fc_limit)
        INTO ln_real_limit
        FROM cbs_kredi_teklif_satir s
        WHERE s.musteri_no=pn_musteri_no
            AND s.kredi_turu=ln_urun_grub_no
            AND s.teklif_satir_no=pn_kredi_teklif_satir_numara
            AND s.teklif_no = (select teklif_no
                                        from cbs_kredi_teklif t
                                        where t.musteri_no = s.musteri_no and
                                                  t.durum_kodu = 'A');
    EXCEPTION WHEN OTHERS THEN
        ln_real_limit := ln_urun_fc_limit;
    END;    
    -- E-O-M AdiletK 04.01.2017 CQ4712 real limit KalysbekA cbs-95
    if p_eod = 'E' then
        -- EOD sirasinda henuz muhasebelesmemis fisler var onlara dikkat
          select sum(decode(s.tur,'A', nvl(dv_tutar,0), -1*nvl(dv_tutar,0)))
            into ln_eod_fc_tutar
            from cbs_satir s
           where s.fis_numara in (select fis_numara from cbs_eod_fis_no ef
                                   where ef.durum = 'A')
             and s.hesap_numara = pn_hesap_no;

            ln_eod_fc_tutar := nvl(ln_eod_fc_tutar, 0);
            ln_mevcut_bakiye := ln_mevcut_bakiye + ln_eod_fc_tutar;
     end if;

    IF  pb_dovize_endeksli THEN

    -- D?vize endeksli bir hesap
      ln_mevcut_bakiye:=pn_toplam_fc_tutar;
      ln_yeni_bakiye:=pn_toplam_fc_tutar;

      ln_fc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
      ln_lc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
      ln_fc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_lc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_fc_urun_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
      ln_fc_urun_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');

      ln_fc_risk:=ln_fc_risk+ln_fc_mevcut_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk+ln_fc_urun_mevcut_bakiye;
      ln_lc_risk:=ln_lc_risk+ln_lc_mevcut_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk+ln_lc_mevcut_bakiye;
      ln_limit_diff := -ln_fc_urun_mevcut_bakiye; -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid  
    ELSE
    -- Normal bir hesap

   -- Hesab?n yeni_bakiyesi hesaplan?r
    ln_yeni_bakiye:=ln_mevcut_bakiye+pn_toplam_fc_tutar;

--   Log_At('Genel Limit Kontrol S?ras?nda','Mevcut Bakiye'||TO_CHAR(ln_mevcut_bakiye),'Yeni Bakiye'||TO_CHAR(ln_yeni_bakiye),'');

   -- Limit Kontrol? i?in fc_yeni_bakiye ve lc_yeni_bakiye elde edilir
    ln_fc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
    ln_lc_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');
    ln_fc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_lc_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,Pkg_Genel.lc_al,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_fc_urun_mevcut_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_mevcut_bakiye,1,NULL,NULL,'N','A');
    ln_fc_urun_yeni_bakiye:=Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kod,ls_urun_limit_doviz_kodu,NULL,ln_yeni_bakiye,1,NULL,NULL,'N','A');

   -- Olu?an riskler hesaplan?r
    IF ln_mevcut_bakiye <= 0 AND ln_yeni_bakiye >= 0 THEN
--Log_At('Genel Limit Kontrol S?ras?nda','1','','');
      ln_fc_risk:=ln_fc_risk+ln_fc_mevcut_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+ln_fc_mevcut_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk+ln_fc_urun_mevcut_bakiye;
      ln_lc_risk:=ln_lc_risk+ln_lc_mevcut_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+ln_lc_mevcut_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk+ln_lc_mevcut_bakiye;
      ln_limit_diff := -ln_fc_urun_mevcut_bakiye; -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid      
    ELSIF ln_mevcut_bakiye >= 0 AND ln_yeni_bakiye < 0 THEN
--Log_At('Genel Limit Kontrol S?ras?nda','2','','');
      ln_fc_risk:=ln_fc_risk-ln_fc_yeni_bakiye;
      ln_nakdi_fc_risk:=ln_nakdi_fc_risk-ln_fc_yeni_bakiye;
      ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk-ln_fc_yeni_bakiye;
      ln_urun_fc_risk:=ln_urun_fc_risk-ln_fc_urun_yeni_bakiye;
      ln_lc_risk:=ln_lc_risk-ln_lc_yeni_bakiye;
      ln_nakdi_lc_risk:=ln_nakdi_lc_risk-ln_lc_yeni_bakiye;
      ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk-ln_lc_yeni_bakiye;
      ln_urun_lc_risk:=ln_urun_lc_risk-ln_lc_yeni_bakiye;
      ln_limit_diff := ln_fc_urun_yeni_bakiye; -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid      
    ELSIF ln_mevcut_bakiye <= 0 AND ln_yeni_bakiye < 0 THEN
--Log_At('Genel Limit Kontrol S?ras?nda','3','','');
      IF ln_yeni_bakiye < ln_mevcut_bakiye THEN
--Log_At('Genel Limit Kontrol S?ras?nda','4','','');
          ln_fc_risk:=ln_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_nakdi_fc_risk:=ln_nakdi_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk-(ln_fc_yeni_bakiye-ln_fc_mevcut_bakiye);
        ln_urun_fc_risk:=ln_urun_fc_risk-(ln_fc_urun_yeni_bakiye-ln_fc_urun_mevcut_bakiye);
        ln_lc_risk:=ln_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_nakdi_lc_risk:=ln_nakdi_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_urun_lc_risk:=ln_urun_lc_risk-(ln_lc_yeni_bakiye-ln_lc_mevcut_bakiye);
        ln_limit_diff := ln_fc_urun_yeni_bakiye-ln_fc_urun_mevcut_bakiye; -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid        
      ELSE
--Log_At('Genel Limit Kontrol S?ras?nda','5','','');
          ln_fc_risk:=ln_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_nakdi_fc_risk:=ln_nakdi_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_gnakdi_fc_risk:=ln_gnakdi_fc_risk+(ln_fc_mevcut_bakiye-ln_fc_yeni_bakiye);
        ln_urun_fc_risk:=ln_urun_fc_risk+(ln_fc_urun_mevcut_bakiye-ln_fc_urun_yeni_bakiye);
        ln_lc_risk:=ln_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_nakdi_lc_risk:=ln_nakdi_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_gnakdi_lc_risk:=ln_gnakdi_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        ln_urun_lc_risk:=ln_urun_lc_risk+(ln_lc_mevcut_bakiye-ln_lc_yeni_bakiye);
        lb_risk_azalmiyor:=FALSE;
        ln_limit_diff := -(ln_fc_urun_mevcut_bakiye-ln_fc_urun_yeni_bakiye); -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid        
      END IF;
    END IF;

    END IF; --  d?vize endeksli

    -- Genel limit (M??teri baz?nda) kontrolleri yap?l?r

    IF pb_limit_kontrol AND lb_risk_azalmiyor AND ps_satir_tur ='B' THEN  -- G?nsonunda limit kontrol? yap?lmadan riskler g?ncel kurdan g?nncellenir
                                                                                         -- Sadece Borc (Risk) yaratan satirlar i?in kontrol yapilmali
        IF ln_fc_risk > ln_fc_limit THEN
--Log_At('IF ln_fc_risk > ln_fc_limit THEN ',TO_CHAR(ln_fc_risk),TO_CHAR(ln_fc_limit),'');
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1759' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;
/* lc riskler kontrol edilmiyor 2007-04-24
      IF ln_lc_risk > ln_lc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1760' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;
*/
      IF ps_nakdi='E' THEN
        IF ln_nakdi_fc_risk > ln_nakdi_fc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1761' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
          END IF;
/* lc riskler kontrol edilmiyor 2007-04-24
        IF ln_nakdi_lc_risk > ln_nakdi_lc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1762' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
*/      ELSE
        IF ln_gnakdi_fc_risk > ln_gnakdi_fc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1763' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
/* lc riskler kontrol edilmiyor 2007-04-24
        IF ln_gnakdi_lc_risk > ln_gnakdi_lc_limit THEN
           RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1765' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter|| TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;
*/      END IF;

    -- ?r?n Grubu limit kontrolleri yap?l?r

      IF ln_urun_fc_risk > ln_urun_fc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1769' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;
/* lc riskler kontrol edilmiyor 2007-04-24
      IF ln_urun_lc_risk > ln_urun_lc_limit THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1770' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
      END IF;
*/
        -- AdiletK 10032016 CQ4712 increasing real limit when installment is paid
        IF ln_urun_fc_risk > ln_real_limit THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1766' ||g_ara_delimiter||TO_CHAR(pn_musteri_no)||g_ara_delimiter||TO_CHAR(pn_hesap_no)||g_uc_delimiter);
        END IF;             
    END IF;


--Log_At('Genel Limit Kontrol S?ras?nda','FC risk'||TO_CHAR(ln_fc_risk),'LC Risk'||TO_CHAR(ln_lc_risk),'');

    -- Risk(ler)in s?f?rdan k???k olmamas? gerekir
/*    Sevil Han?m'?n talebi ?zerinde kurdan dolay? ge?ici olarak negatif de?ere d?n??mesine izin verildi : Erguna 05.12.2003
    if ln_lc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1802' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ln_fc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1803' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ps_nakdi='E' then
        if ln_nakdi_lc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1804' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;

      if ln_nakdi_fc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1805' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;
    else
      if ln_gnakdi_lc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1806' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;

      if ln_gnakdi_fc_risk < 0 then
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1807' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
      end if;
    end if;

    if ln_urun_lc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1808' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;

    if ln_urun_fc_risk < 0 then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1809' ||g_ara_delimiter||to_char(pn_musteri_no)||g_ara_delimiter||to_char(pn_hesap_no)||g_uc_delimiter);
    end if;
*/
    if p_EOD = 'E' then
       --EOD s?ra?nda risk update yapm?yoruz........
       return;
    end if;
    -- E?er limit a??m? olmad?ysa risk bilgilerini g?ncelle

    BEGIN
      IF ps_nakdi='E' THEN
         UPDATE CBS_MUSTERI_LIMIT
            SET lc_risk=ln_lc_risk,
                fc_risk=ln_fc_risk,
                nakdi_lc_risk=ln_nakdi_lc_risk,
                nakdi_fc_risk=ln_nakdi_fc_risk
          WHERE musteri_no=pn_musteri_no;
      ELSE
         UPDATE CBS_MUSTERI_LIMIT
            SET lc_risk=ln_lc_risk,
                fc_risk=ln_fc_risk,
                gnakdi_lc_risk=ln_gnakdi_lc_risk,
                gnakdi_fc_risk=ln_gnakdi_fc_risk
          WHERE musteri_no=pn_musteri_no;
      END IF;
    EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1771' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;

    -- M??terinin ilgili ?r?n grubu riskleri g?ncellenir

    BEGIN
      UPDATE CBS_MUSTERI_URUN_LIMIT
         SET lc_risk=ln_urun_lc_risk,
             fc_risk=ln_urun_fc_risk
          WHERE musteri_no=pn_musteri_no
            AND urun_grub_no=ln_urun_grub_no
            AND (kredi_teklif_satir_numara=0 OR kredi_teklif_satir_numara=pn_kredi_teklif_satir_numara);
    EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1772' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
    END;
    log_at('test_adilet_limit', ln_urun_lc_risk || ' - ' || ln_urun_fc_risk || ' l ' || ln_limit_diff, pn_musteri_no || ' u ' || ln_urun_grub_no || ' s ' || pn_kredi_teklif_satir_numara);
    
    -- B-O-M AdiletK 10032016 CQ4712 increasing real limit when installment is paid KalysbekA cbs-95
    BEGIN  
        BEGIN
            SELECT nvl(s.tranches, 'N'),
                      nvl(s.line, 'NO')
            INTO ls_tranches,
                  ls_line
            FROM CBS_KREDI_TEKLIF_SATIR s
            WHERE s.musteri_no=pn_musteri_no
                AND s.kredi_turu=ln_urun_grub_no
                AND s.teklif_satir_no=pn_kredi_teklif_satir_numara
                AND s.teklif_no = (select teklif_no
                                            from cbs_kredi_teklif t
                                            where t.musteri_no = s.musteri_no and
                                                      t.durum_kodu = 'A');    
        EXCEPTION WHEN OTHERS THEN
            ls_tranches := 'N';
            ls_line := 'NO';
        END;    
        
        SELECT count(*)
        INTO ln_count
        FROM CBS_MUSTERI_URUN_LIMIT l
        WHERE l.musteri_no=pn_musteri_no
               AND (kredi_teklif_satir_numara=0 OR kredi_teklif_satir_numara=pn_kredi_teklif_satir_numara)
               AND urun_grub_no = (SELECT numara
                                            FROM CBS_URUN_GRUBU g,
                                                     CBS_MUSTERI m
                                            WHERE m.musteri_no =  l.musteri_no
                                                AND g.tanim = '%OVERDRAFT%'
                                               AND g.musteri_tipi= m.musteri_tipi_kod
                                               AND g.numara = ln_urun_grub_no) ;
              
        IF ls_tranches = 'Y' THEN -- AdiletK 17022017 CQ5744 defect real limit
            IF ln_limit_diff > 0 THEN
                UPDATE CBS_KREDI_TEKLIF_SATIR
                SET real_limit = real_limit - ln_limit_diff
                WHERE musteri_no=pn_musteri_no
                    AND kredi_turu=ln_urun_grub_no
                    AND teklif_satir_no=pn_kredi_teklif_satir_numara
                    AND real_limit is not null;
            END IF;
        ELSIF ln_count = 0 and ls_line = 'NO' THEN
            UPDATE CBS_KREDI_TEKLIF_SATIR
            SET real_limit = abs(ln_urun_fc_risk)
            WHERE musteri_no=pn_musteri_no
                AND kredi_turu=ln_urun_grub_no
                AND teklif_satir_no=pn_kredi_teklif_satir_numara
                AND real_limit is not null;                                         
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '4664' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);  
    END;   
    -- E-O-M AdiletK 10032016 CQ4712 increasing real limit when installment is paid
  END;


  PROCEDURE Limit_Kontrol(pn_fis_numara CBS_FIS.numara%TYPE, pb_iptal_flag BOOLEAN DEFAULT FALSE, p_EOD varchar2 DEFAULT 'H') IS
  -- Risk yaratan islemlere iliskin limit kontrol?n? yapan prosedur
  ln_hesap_no                CBS_HESAP_KREDI.hesap_no%TYPE;
  ln_islem_no                CBS_ISLEM.numara%TYPE;
  ls_doviz_kod                CBS_HESAP_KREDI.doviz_kodu%TYPE;
  ln_musteri_no                CBS_HESAP_KREDI.musteri_no%TYPE;
  ln_toplam_lc_tutar        CBS_SATIR.lc_tutar%TYPE;
  ln_toplam_fc_tutar        CBS_SATIR.dv_tutar%TYPE;
  ls_hesap_tur_kodu            CBS_SATIR.hesap_tur_kodu%TYPE;
  ls_modul_tur_kod            CBS_HESAP_KREDI.modul_tur_kod%TYPE;
  ls_urun_tur_kod            CBS_HESAP_KREDI.urun_tur_kod%TYPE;
  ls_urun_sinif_kod            CBS_HESAP_KREDI.urun_sinif_kod%TYPE;
  ls_nakdi                    CBS_URUN_SINIF.nakdi%TYPE;
  ls_risk_yarat                CBS_URUN_SINIF.risk_yarat%TYPE;
  ls_musteri_tipi_kod       CBS_MUSTERI.musteri_tipi_kod%TYPE;
  ln_kredi_teklif_satir_numara CBS_HESAP_KREDI.kredi_teklif_satir_numara%TYPE;
  ls_grup_kod                CBS_MUSTERI.grup_kod%TYPE;
  ls_bakiye_karakteri        CBS_HESAP_BAKIYE.bakiye_karakteri%TYPE;
  ls_islem_urun_tur_kod        CBS_ISLEM.urun_tur_kod%TYPE;
  lb_kontrol                BOOLEAN;
  lb_limit_kontrol            BOOLEAN;
  lb_doviz_endeksli            BOOLEAN;
  ls_endeks_doviz_kodu        CBS_HESAP_KREDI.endeks_doviz_kodu%TYPE;
  ln_islem_kod                CBS_ISLEM_TANIM.KOD%TYPE;

  ls_satir_tur                CBS_SATIR.tur%TYPE;


  CURSOR c1 IS
     SELECT UNIQUE CBS_SATIR.hesap_numara,CBS_SATIR.doviz_kod,CBS_SATIR.hesap_tur_kodu,CBS_ISLEM.URUN_TUR_KOD,CBS_ISLEM.ISLEM_KOD,CBS_ISLEM.NUMARA,
                    CBS_SATIR.tur
       FROM CBS_SATIR,CBS_FIS,CBS_ISLEM
      WHERE CBS_SATIR.fis_numara=pn_fis_numara
        AND CBS_SATIR.fis_numara=CBS_FIS.numara
        AND CBS_FIS.islem_numara=CBS_ISLEM.numara
        AND hesap_tur_kodu IN ('KR','VS') ;
  BEGIN
  -- Fi?teki farkl? t?m kredi hesaplari i?in limit kontrol? yap?l?r
  -- SBO ekran? d???nda yarat?lan fi?lerde normalde bu d?ng?de sadece tek bir kredi hesab? olmas? beklenir
    OPEN c1;
    LOOP
      FETCH c1 INTO ln_hesap_no,ls_doviz_kod,ls_hesap_tur_kodu,ls_islem_urun_tur_kod,ln_islem_kod,ln_islem_no, ls_satir_tur;
      EXIT WHEN c1%NOTFOUND;
        lb_doviz_endeksli:=FALSE;
      ls_endeks_doviz_kodu:=NULL;
      -- Batch i?lemlerde limit kontrol? yap?lmaz ama risk g?ncellenir
      IF ls_islem_urun_tur_kod='BATCH' THEN
        lb_limit_kontrol:=FALSE;
      ELSE
        lb_limit_kontrol:=TRUE;
      END IF;

      lb_kontrol:=TRUE;
      -- Hesab?n m??teri numaras?,tipi ve urun s?n?f? bulunur
        IF ls_hesap_tur_kodu='KR' THEN
        BEGIN
          SELECT musteri_no,modul_tur_kod,urun_tur_kod,urun_sinif_kod,NVL(kredi_teklif_satir_numara,0),ENDEKS_DOVIZ_KODU
            INTO ln_musteri_no,ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,ln_kredi_teklif_satir_numara,ls_endeks_doviz_kodu
            FROM CBS_HESAP_KREDI
           WHERE hesap_no=ln_hesap_no;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1742' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1743' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
        END;
      ELSIF ls_hesap_tur_kodu='VS' THEN
        BEGIN
          SELECT musteri_no,modul_tur_kod,urun_tur_kod,urun_sinif_kod,0,bakiye_karakteri
            INTO ln_musteri_no,ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,ln_kredi_teklif_satir_numara,ls_bakiye_karakteri
            FROM CBS_HESAP,CBS_HESAP_BAKIYE
           WHERE CBS_HESAP.hesap_no=ln_hesap_no
             AND CBS_HESAP.hesap_no=CBS_HESAP_BAKIYE.hesap_no;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2614' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2615' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
        END;

      -- Hesab?n ait oldu?u urun_sinif'?n ?zellikleri al?n?r
      BEGIN
        SELECT nakdi,risk_yarat
          INTO ls_nakdi,ls_risk_yarat
          FROM CBS_URUN_SINIF
         WHERE modul_tur_kod=ls_modul_tur_kod
           AND urun_tur_kod=ls_urun_tur_kod
           AND kod=ls_urun_sinif_kod;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1776' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1743' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
      END;

        -- Pozitif bakiye karakterine sahip vadesiz hesaplar i?in limit kontrol? yap?lmaz
        IF ls_bakiye_karakteri='P' THEN
          lb_kontrol:=FALSE;
        ELSE
          IF ls_risk_yarat='H' THEN
            lb_kontrol:=FALSE;
          END IF;
        END IF;
      END IF;

      IF lb_kontrol THEN

      -- M??terinin tipi ve grubu bulunur
      BEGIN
        SELECT musteri_tipi_kod,grup_kod
          INTO ls_musteri_tipi_kod,ls_grup_kod
          FROM CBS_MUSTERI
         WHERE musteri_no=ln_musteri_no;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1746' ||g_ara_delimiter||TO_CHAR(ln_musteri_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1747' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
      END;

      -- M??terinin tipi Banka ise kredi_teklif_satir_numara null olabilir ama di?er durumlarda dolu olmal?d?r
       IF ls_musteri_tipi_kod != '4' AND ln_kredi_teklif_satir_numara=0 THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1813' ||g_ara_delimiter||TO_CHAR(ln_musteri_no)||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
      END IF;
      -- Fi?teki hesaba ili?kin toplam bor?-alacak tutarlar? LC ve FC olarak bulunur.
      BEGIN
        SELECT SUM(DECODE(tur,'A',dv_tutar,-dv_tutar)),
               SUM(DECODE(tur,'A',lc_tutar,-lc_tutar))
          INTO ln_toplam_fc_tutar,ln_toplam_lc_tutar
            FROM CBS_SATIR
          WHERE fis_numara=pn_fis_numara
           AND hesap_numara=ln_hesap_no
           AND doviz_kod=ls_doviz_kod;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1744' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1745' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
      END;
      -- Eger Endeks Doviz Kodu alan? doluysa, bu bir d?viz endeksli kredidir. ??lem tipine g?re fc_tutar al?nmal?d?r
      IF ls_endeks_doviz_kodu IS NOT NULL THEN
          lb_doviz_endeksli:=TRUE;
        BEGIN
          SELECT DECODE(ln_islem_kod,1303,endeks_doviz_tutari,
                                     3250,endeks_doviz_tutari,-anapara_tahsilat_tutar),ls_endeks_doviz_kodu
            INTO ln_toplam_fc_tutar,ls_doviz_kod
            FROM CBS_HESAP_KREDI_ISLEM
           WHERE tx_no=ln_islem_no;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1742' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1743' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
        END;
      END IF;
      -- Eger fi? iptal ediliyorsa tutarlar ters ?evrilir
      IF pb_iptal_flag THEN
          ln_toplam_fc_tutar:=-ln_toplam_fc_tutar;
        ln_toplam_lc_tutar:=-ln_toplam_lc_tutar;
      END IF;

      -- Hesab?n ait oldu?u urun_sinif'?n ?zellikleri al?n?r
      BEGIN
        SELECT nakdi,risk_yarat
          INTO ls_nakdi,ls_risk_yarat
          FROM CBS_URUN_SINIF
         WHERE modul_tur_kod=ls_modul_tur_kod
           AND urun_tur_kod=ls_urun_tur_kod
           AND kod=ls_urun_sinif_kod;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1776' ||g_ara_delimiter||TO_CHAR(ln_hesap_no)||g_uc_delimiter);
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1743' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
      END;

      -- E?er ?r?n risk yaratan bir ?r?n ise limit kontrolleri yap?l?r
      IF ls_risk_yarat='E' THEN
           -- M??terinin genel limit kontrol? yap?l?r
         Genel_limit_Kontrol(ln_musteri_no,ln_hesap_no,ln_toplam_fc_tutar,ln_toplam_lc_tutar,ls_doviz_kod,ls_nakdi,
                              ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,ln_kredi_teklif_satir_numara,
                             ls_musteri_tipi_kod,lb_limit_kontrol,lb_doviz_endeksli,ls_satir_tur, p_EOD);

            -- E?er m??teri bir gruba aitse grup kontrolleri yap?l?r
            IF ls_grup_kod IS NOT NULL THEN
             Grup_limit_Kontrol(ls_grup_kod,ln_hesap_no,ln_toplam_fc_tutar,ln_toplam_lc_tutar,ls_doviz_kod,ls_nakdi,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,'X',lb_limit_kontrol,
                                 lb_doviz_endeksli,ls_satir_tur, p_EOD);
            END IF;

      END IF;

      END IF; -- lb_kontrol

    END LOOP;
    CLOSE c1;
  END;

 PROCEDURE Risk_Iptal(pn_fis_numara CBS_FIS.numara%TYPE) IS
 BEGIN
   Limit_kontrol(pn_fis_numara,TRUE);
 END;


/******************************************************************************/
 --Limit Urun Grubu i?in sistemden numara al?r
  FUNCTION  Urun_grubu_no_al RETURN NUMBER
   IS
    ln_urun_grup_no      NUMBER;
  BEGIN

      ln_urun_grup_no := Pkg_Genel.genel_kod_al('URUN_LIMIT_GRUP_NO') ;

    RETURN ln_urun_grup_no  ;

  EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2244' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;

/***************************************************************************/
/* Kredi teklif giris de kullan?lmak uzere haz?rlanm?? proc & fonksiyonlar */
/***************************************************************************/

 /******************************************************************************************************************/
 /*   Procedure Sp_Musteri_Limit_Risk_Degeri_Al                                                                            */
 /*   Musteriye ait Mevcut limit ve risk degerleri alinir                                                           */
 /******************************************************************************************************************/
 PROCEDURE Sp_Musteri_Limit_Risk_Al (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                         ps_doviz_kodu  OUT CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                     pn_lc_limit OUT NUMBER,pn_fc_limit OUT NUMBER,
                                     pn_lc_risk OUT NUMBER,pn_fc_risk OUT NUMBER,
                                     pn_nakdi_lc_limit  OUT NUMBER,pn_nakdi_fc_limit  OUT NUMBER,
                                     pn_nakdi_lc_risk   OUT NUMBER, pn_nakdi_fc_risk   OUT NUMBER,
                                     pn_gnakdi_lc_limit OUT NUMBER,pn_gnakdi_fc_limit OUT NUMBER,
                                     pn_gnakdi_lc_risk  OUT NUMBER,pn_gnakdi_fc_risk  OUT NUMBER,
                                     pn_line_amount OUT NUMBER)
   IS
   BEGIN

     SELECT
           fc_doviz_kodu,lc_limit, fc_limit, lc_risk, fc_risk, nakdi_lc_limit,
           gnakdi_lc_limit, nakdi_fc_limit,gnakdi_fc_limit,
           nakdi_lc_risk,gnakdi_lc_risk,nakdi_fc_risk, gnakdi_fc_risk,line_amount
      INTO ps_doviz_kodu,pn_lc_limit, pn_fc_limit, pn_lc_risk,pn_fc_risk, pn_nakdi_lc_limit,
             pn_gnakdi_lc_limit, pn_nakdi_fc_limit,pn_gnakdi_fc_limit,
           pn_nakdi_lc_risk, pn_gnakdi_lc_risk,pn_nakdi_fc_risk,pn_gnakdi_fc_risk,pn_line_amount
      FROM CBS_MUSTERI_LIMIT
      WHERE musteri_no = pn_musteri_no ;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
            ps_doviz_kodu := NULL;
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '468' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;


  /******************************************************************************************************************/
  /*   Procedure Sp_Musteri_Urun_Limit_Risk_Al                                                                                */
  /*   Musteri no ve urun grubu gonderilerek Mevcut limit ve risk degerleri alinir                                            */
  /******************************************************************************************************************/
 PROCEDURE Sp_Musteri_Urun_Limit_Risk_Al (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                              pn_urun_grub_no   CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE,
                                            ps_doviz_kodu     CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                          pn_kredi_teklif_satir_numara CBS_MUSTERI_URUN_LIMIT.kredi_teklif_satir_numara%TYPE,
                                          pn_lc_limit OUT NUMBER,
                                          pn_fc_limit OUT NUMBER,
                                          pn_lc_risk OUT NUMBER,
                                          pn_fc_risk OUT NUMBER)
  IS
   BEGIN

     SELECT lc_limit,fc_limit , lc_risk ,  fc_risk
     INTO   pn_lc_limit, pn_fc_limit, pn_lc_risk, pn_fc_risk
     FROM CBS_MUSTERI_URUN_LIMIT
     WHERE musteri_no = pn_musteri_no AND
            urun_grub_no = pn_urun_grub_no AND
           KREDI_TEKLIF_SATIR_NUMARA =  pn_kredi_teklif_satir_numara;
            --fc_doviz_kodu = ps_doviz_kodu ;



    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '469' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;



  /******************************************************************************************************************/
  /*   Procedure  Sp_Musteri_Limit_Guncelle                                                                                 */
  /*   Onerilen limit ve risk degerleri ile musteri limit tablosu guncellenir                                           */
  /******************************************************************************************************************/
 PROCEDURE Sp_Musteri_Limit_Guncelle (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE, ps_genel_doviz_kodu  CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                      pn_lc_limit  NUMBER,pn_fc_limit NUMBER,pn_nakdi_lc_limit NUMBER,pn_nakdi_fc_limit NUMBER,pn_gnakdi_lc_limit  NUMBER,pn_gnakdi_fc_limit NUMBER)
  IS
      ls_doviz_kodu CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
    mevcut_doviz_kodu_farkli          EXCEPTION;
  BEGIN


    SELECT fc_doviz_kodu
    INTO   ls_doviz_kodu
    FROM CBS_MUSTERI_LIMIT
    WHERE musteri_no = pn_musteri_no ;

    IF ls_doviz_kodu  IS NOT NULL THEN
          UPDATE CBS_MUSTERI_LIMIT
          SET (lc_limit,
               fc_limit,
               nakdi_lc_limit,
                 gnakdi_lc_limit,
               nakdi_fc_limit,
               gnakdi_fc_limit
                ) = ( SELECT NVL(pn_lc_limit,0),
                               NVL(pn_fc_limit * (  NVL(Pkg_Kur.doviz_doviz_karsilik(ps_genel_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) /
                                                 NVL(Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) )    ,0),
                             NVL(pn_nakdi_lc_limit,0),
                                 NVL(pn_gnakdi_lc_limit,0),
                             NVL(pn_nakdi_fc_limit * (  NVL(Pkg_Kur.doviz_doviz_karsilik(ps_genel_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) /
                                                 NVL(Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) )    ,0),
                               NVL(pn_gnakdi_fc_limit * (  NVL(Pkg_Kur.doviz_doviz_karsilik(ps_genel_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) /
                                                 NVL(Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) ),0)

                             FROM dual)
         WHERE musteri_no = pn_musteri_no ;

    ELSE
    /* yoksa yeni limit kaydi yaratilir */
    INSERT INTO CBS_MUSTERI_LIMIT(musteri_no, lc_limit, fc_doviz_kodu,fc_limit,  nakdi_lc_limit,
                                  gnakdi_lc_limit, nakdi_fc_limit, gnakdi_fc_limit  )
                          VALUES (pn_musteri_no, NVL(pn_lc_limit,0),  ps_genel_doviz_kodu, NVL(pn_fc_limit,0),  NVL(pn_nakdi_lc_limit,0),
                                   NVL(pn_gnakdi_lc_limit,0),NVL(pn_nakdi_fc_limit,0), NVL(pn_gnakdi_fc_limit,0) );
    END IF;

  EXCEPTION
   WHEN NO_DATA_FOUND THEN
     INSERT INTO CBS_MUSTERI_LIMIT(musteri_no, lc_limit, fc_doviz_kodu,fc_limit,  nakdi_lc_limit,
                                  gnakdi_lc_limit, nakdi_fc_limit, gnakdi_fc_limit  )
                          VALUES (pn_musteri_no, NVL(pn_lc_limit,0), ps_genel_doviz_kodu, NVL(pn_fc_limit,0),  NVL(pn_nakdi_lc_limit,0),
                                   NVL(pn_gnakdi_lc_limit,0),NVL(pn_nakdi_fc_limit,0), NVL(pn_gnakdi_fc_limit,0) );

   WHEN mevcut_doviz_kodu_farkli THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '470' || Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
      WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '471' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;


  /******************************************************************************************************************/
  /*   Procedure  Sp_Musteri_Urun_Limit_Guncelle                                                                                 */
  /*   Onerilen limit ve risk degerleri ile musteri urun limit tablosu guncellenir                                           */
  /******************************************************************************************************************/
 PROCEDURE Sp_Musteri_Urun_Limit_Guncelle (pn_musteri_no        CBS_MUSTERI.musteri_no%TYPE,
                                               pn_urun_grub_no      CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE,
                                           pn_teklif_satir_no   CBS_MUSTERI_URUN_LIMIT.kredi_teklif_satir_numara%TYPE,
                                             ps_doviz_kodu         CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                           pn_lc_limit             CBS_MUSTERI_URUN_LIMIT.lc_limit%TYPE,
                                           pn_fc_limit          CBS_MUSTERI_URUN_LIMIT.fc_limit%TYPE)
 IS
      ls_doviz_kodu CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE;
    mevcut_doviz_kodu_farkli          EXCEPTION;
  BEGIN

    SELECT fc_doviz_kodu
    INTO ls_doviz_kodu
    FROM CBS_MUSTERI_URUN_LIMIT
    WHERE musteri_no = pn_musteri_no AND
          urun_grub_no =  pn_urun_grub_no AND
          kredi_teklif_satir_numara = pn_teklif_satir_no ;

    IF ls_doviz_kodu  IS NOT NULL THEN

          UPDATE CBS_MUSTERI_URUN_LIMIT
          SET  (lc_limit, fc_limit) = ( SELECT  NVL(pn_lc_limit,0),
                                                       NVL(pn_fc_limit * (  NVL(Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) /
                                                                        NVL(Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'N','A'),0) ),0)
                                                   FROM dual)
          WHERE musteri_no = pn_musteri_no AND
                 urun_grub_no =  pn_urun_grub_no AND
                kredi_teklif_satir_numara = pn_teklif_satir_no ;
      ELSE
    /* yoksa yeni limit kaydi yaratilir */
    INSERT INTO CBS_MUSTERI_URUN_LIMIT(musteri_no, urun_grub_no, fc_doviz_kodu,lc_limit, fc_limit,kredi_teklif_satir_numara)
             VALUES (pn_musteri_no, pn_urun_grub_no, ps_doviz_kodu,NVL(pn_lc_limit,0), NVL(pn_fc_limit,0),pn_teklif_satir_no);

    END IF;

  EXCEPTION
   WHEN NO_DATA_FOUND THEN
            /* yoksa yeni limit kaydi yaratilir */
    INSERT INTO CBS_MUSTERI_URUN_LIMIT(musteri_no, urun_grub_no, fc_doviz_kodu,lc_limit, fc_limit,kredi_teklif_satir_numara)
             VALUES (pn_musteri_no, pn_urun_grub_no, ps_doviz_kodu,NVL(pn_lc_limit,0), NVL(pn_fc_limit,0),pn_teklif_satir_no);
   WHEN mevcut_doviz_kodu_farkli THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '472' || Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
      WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '473' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;

  /******************************************************************************************************************/
  /*   Procedure sp_musteri_grup_urun_limiti_al(                                                                            */
  /*   musteri numaras? g?nderilir, grup kodu bulunur,limit bilgileri al?n?r                                         */
  /******************************************************************************************************************/
 PROCEDURE sp_musteri_grup_urun_limiti_al( pn_musteri_no     CBS_MUSTERI.musteri_no%TYPE,
                                             ps_fc_doviz_kodu OUT CBS_MUSTERI_GRUP_LIMIT.fc_doviz_kodu%TYPE,
                                           pn_lc_limit      OUT CBS_MUSTERI_GRUP_LIMIT.lc_limit%TYPE ,
                                              pn_fc_limit      OUT CBS_MUSTERI_GRUP_LIMIT.fc_limit%TYPE,
                                              pn_lc_risk       OUT CBS_MUSTERI_GRUP_LIMIT.lc_risk%TYPE,
                                              pn_fc_risk          OUT CBS_MUSTERI_GRUP_LIMIT.fc_risk%TYPE)
  IS
      ls_grup_kodu CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE;
  BEGIN
       SELECT grup_kod
     INTO  ls_grup_kodu
     FROM  CBS_MUSTERI
     WHERE musteri_no = pn_musteri_no;

    SELECT fc_doviz_kodu,
           lc_limit,
           fc_limit,
           lc_risk,
           fc_risk
    INTO   ps_fc_doviz_kodu,
           pn_lc_limit,
           pn_fc_limit,
           pn_lc_risk,
           pn_fc_risk
    FROM CBS_MUSTERI_GRUP_LIMIT
    WHERE grup_kodu = ls_grup_kodu ;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN NULL;
  WHEN OTHERS  THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '476' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END ;

  /******************************************************************************************************************/
  /*   Function  sf_musteri_urun_grub_limit_var                                                                           */
  /*   musterinin grilen kredi turune ait limiti olup olmad?gi kontrol edilir                                        */
  /******************************************************************************************************************/
  FUNCTION sf_musteri_urun_grub_limit_var(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,pn_urun_grub_no CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE) RETURN VARCHAR2
   IS
     ls_return  VARCHAR2(1) := 'H';
   BEGIN

        SELECT 'E'
        INTO  ls_return
        FROM  CBS_MUSTERI_URUN_LIMIT
        WHERE musteri_no = pn_musteri_no AND
              urun_grub_no = pn_urun_grub_no;

    RETURN ls_return;

    EXCEPTION
    WHEN  NO_DATA_FOUND THEN RETURN 'H';

   END;

  /******************************************************************************************************************/
  /*   Function  sf_musterinin_urun_limiti_var                                                                           */
  /*   musterinin herhangi bir kredi turune ait limiti olup olmad?gi kontrol edilir                                        */
  /******************************************************************************************************************/
  FUNCTION sf_musterinin_urun_limiti_var(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2
   IS
     ls_return  VARCHAR2(1) := 'H';
     ln_adet   NUMBER;
   BEGIN

        SELECT COUNT(*)
        INTO  ln_adet
        FROM  CBS_MUSTERI_URUN_LIMIT
        WHERE musteri_no = pn_musteri_no ;

     IF NVL(ln_adet,0) = 0 THEN
         ls_return := 'H' ;
     ELSE
         ls_return := 'E' ;
      END IF;

    RETURN ls_return;

    EXCEPTION
    WHEN  NO_DATA_FOUND THEN RETURN 'H';
   END;


FUNCTION  urun_sinif_risklimi(ps_modul_tur_kod IN CBS_URUN_SINIF.modul_tur_kod%TYPE,ps_urun_tur_kod IN CBS_URUN_SINIF.urun_tur_kod%TYPE,ps_kod IN CBS_URUN_SINIF.kod%TYPE) RETURN CBS_URUN_SINIF.RISK_YARAT%TYPE
   IS
    ls_urun_aciklama      CBS_URUN_SINIF.RISK_YARAT%TYPE := 'H';
  BEGIN
          SELECT  RISK_YARAT
           INTO   ls_urun_aciklama
           FROM   CBS_URUN_SINIF
           WHERE  modul_tur_kod = ps_modul_tur_kod
                  AND urun_tur_kod=ps_urun_tur_kod
                  AND kod=ps_kod;

    RETURN ls_urun_aciklama;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN 'H';
  END;
 /*****************************    */

  PROCEDURE Bagli_musterileri_getir(ps_grup_kodu CBS_BAGLI_MUSTERI_GRUPLARI.grup_kodu%TYPE,
                                      pRetCur       IN OUT Pkg_Rapor.Generic_CurType)
  IS
  -- Bagl? musteri grubundaki musterileri getirecek.
   TYPE Generic_CurType IS REF CURSOR;
  BEGIN

   OPEN pRetCur FOR
   SELECT musteri_no
   FROM   CBS_MUSTERI_GRUP_BAGLI_MUSTERI
   WHERE  grup_kodu = ps_grup_kodu
   ORDER BY musteri_no        ;

   EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);


  END;

 FUNCTION Baglama_Referansi_Al RETURN VARCHAR2
  IS
  ls_baglama_ref VARCHAR2(2000);
  ls_bolum_kodu VARCHAR2(2000);
  ln_sira_no  NUMBER;
  BEGIN

     ls_bolum_kodu       := Pkg_Baglam.bolum_kodu ;
     ls_baglama_ref := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu  ;
     ln_sira_no          := Pkg_Genel.genel_kod_al(ls_baglama_ref);
     ls_baglama_ref := ls_baglama_ref || LPAD(ln_sira_no,6,0);

      RETURN ls_baglama_ref;

    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2723' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END ;

  FUNCTION musteri_genel_limit_dvz_al(pn_numara NUMBER) RETURN VARCHAR2
   IS
    ls_dvz      CBS_MUSTERI_LIMIT.FC_DOVIZ_KODU%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT FC_DOVIZ_KODU
    INTO   ls_dvz
    FROM   CBS_MUSTERI_LIMIT
    WHERE  musteri_no = pn_numara ;

    RETURN ls_dvz  ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_dvz := ' ';
  END;
-----------------------------------------
  FUNCTION musteri_genel_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER
   IS
    ls_fc_limit  CBS_MUSTERI_LIMIT.FC_LIMIT%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT FC_LIMIT
    INTO   ls_fc_limit
    FROM   CBS_MUSTERI_LIMIT
    WHERE  musteri_no = pn_numara ;

    RETURN ls_fc_limit ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_fc_limit := 0;
  END;
-----------------------------------------
  FUNCTION musteri_nakdi_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER
   IS
    ls_NAKDI_FC_LIMIT  CBS_MUSTERI_LIMIT.NAKDI_FC_LIMIT%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT NAKDI_FC_LIMIT
    INTO   ls_NAKDI_FC_LIMIT
    FROM   CBS_MUSTERI_LIMIT
    WHERE  musteri_no = pn_numara ;

    RETURN ls_NAKDI_FC_LIMIT ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_NAKDI_FC_LIMIT := 0;
  END;
-----------------------------------------
  FUNCTION musteri_gnakdi_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER
   IS
    ls_gNAKDI_FC_LIMIT  CBS_MUSTERI_LIMIT.gNAKDI_FC_LIMIT%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT gNAKDI_FC_LIMIT
    INTO   ls_gNAKDI_FC_LIMIT
    FROM   CBS_MUSTERI_LIMIT
    WHERE  musteri_no = pn_numara ;

    RETURN ls_gNAKDI_FC_LIMIT ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_gNAKDI_FC_LIMIT := 0;
  END;
-----------------------------------------
  FUNCTION musteri_urun_limit_dvz_al(pn_numara NUMBER,pn_grup NUMBER) RETURN VARCHAR2
   IS
    ls_dvz      CBS_MUSTERI_URUN_LIMIT.FC_DOVIZ_KODU%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT FC_DOVIZ_KODU
    INTO   ls_dvz
    FROM   CBS_MUSTERI_URUN_LIMIT
    WHERE  musteri_no = pn_numara
    AND    urun_grub_no = pn_grup;

    RETURN ls_dvz  ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_dvz := ' ';
  END;
-----------------------------------------
  FUNCTION musteri_urun_fc_limiti_al(pn_numara NUMBER,pn_grup NUMBER) RETURN NUMBER
   IS
    ls_fc_limit  CBS_MUSTERI_URUN_LIMIT.FC_LIMIT%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT FC_LIMIT
    INTO   ls_fc_limit
    FROM   CBS_MUSTERI_URUN_LIMIT
    WHERE  musteri_no = pn_numara
    AND    urun_grub_no = pn_grup;

    RETURN ls_fc_limit ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_fc_limit := 0;
  END;
-----------------------------------------
  FUNCTION musteri_urun_lc_limiti_al(pn_numara NUMBER,pn_grup NUMBER) RETURN NUMBER
   IS
    ls_fc_limit  CBS_MUSTERI_URUN_LIMIT.FC_LIMIT%TYPE;
  BEGIN
    -- ?r?n limit grubunun ad?n? d?nd?r?r.

      SELECT FC_LIMIT
    INTO   ls_fc_limit
    FROM   CBS_MUSTERI_URUN_LIMIT
    WHERE  musteri_no = pn_numara
    AND    urun_grub_no = pn_grup;

    RETURN ls_fc_limit ;

  EXCEPTION
      WHEN OTHERS THEN
        ls_fc_limit := 0;
  END;
-----------------------------------------

END;
/

