create PACKAGE     PKG_TX1000 IS

/******************************************************************************
   Name       : PKG_TX1000
   Created By : Seval Balci
   Date    	  : 04.06.03
   Purpose	  : M??teri Ba?vuru Giris Islemleri
******************************************************************************/


  Procedure Kontrol_Sonrasi(pn_islem_no number); 		      -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);        -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);  -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			        -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		      -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			      -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		      -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			      -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			      -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);	      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);   -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Function dokuman_kontrol(ps_musteri_tipi_kod cbs_musteri.musteri_tipi_kod%type, pn_islem_no number) return number;
  Function sf_ortaklik_kontrol(pn_islem_no number) return number;

  Function sf_tax_zorunlumu(ps_working_basis varchar2, pn_dk_grup_kod number, ps_musteri_tipi_kod varchar2 default null) return varchar2;
  Function sf_registration_zorunlumu(ps_working_basis varchar2, pn_dk_grup_kod number, ps_musteri_tipi_kod varchar2 default null) return varchar2;
  Function sf_okpo_social_zorunlumu(ps_working_basis varchar2, pn_dk_grup_kod number, ps_musteri_tipi_kod varchar2 default null) return varchar2;
END;
/

