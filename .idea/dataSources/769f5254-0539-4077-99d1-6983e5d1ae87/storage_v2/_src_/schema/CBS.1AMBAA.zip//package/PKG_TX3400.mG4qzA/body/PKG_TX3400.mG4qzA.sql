create PACKAGE BODY     "PKG_TX3400" IS

/*---------------------------FAIZ-MASRAF-KOMISYON TAHSIL ----------------------------------------------*/
p_3400_BOLUM_KODU                                   number;
p_3400_B_ACIKLAMA                                  number;
p_3400_DOVIZ_KODU                                  number;
p_3400_ISTATISTIK_KODU                              number;
p_3400_KUR                                          number;
p_3400_M_ACIKLAMA                                  number;
p_3400_REFERANS_NO                                  number;
p_3400_003_SUBE                                      number;
p_3400_GELIR_SUBE                                  number;
p_3400_TAHSIL_HESAP_BOLUM                          number;
p_3400_TAHSIL_HESAP_NO                              number;
p_3400_TAHSIL_HESAP_DVZ                              number;
p_3400_ILISKILI_HESAP_DK                          number;
p_3400_TAHSIL_TUTARI                              number;
p_3400_TAHSIL_TUTARI_LC                              number;
p_3400_TOPLAM_TUTAR                                  number;
p_3400_TOPLAM_TUTAR_LC                              number;
p_3400_TAH_DVZ_TRY                                  number;
p_3400_ILISKILI_HESAP_VAR                          number;
p_3400_ILISKILI_HESAP_YOK                          number;
p_3400_MASRAF_DK                                  number;

p_3400_TAX_DK                                        number;

p_3400_TAH_DVZ_YP                                  number;
p_3400_MAS_DVZ_YP                                  number;
p_3400_MAS_DVZ_TRY                                  number;
p_3400_TAX_VAR                                      number;
p_3400_TAX_YOK                                      number;
p_3400_TAX_DEDUCTED                                  number;
p_3400_TAX_PAID                                      number;
p_3400_TAX_AMOUNT                                  number;
p_3400_TAX_AMOUNT_LC                              number;
p_3400_SERVICE_TAX_AMOUNT                           number;
p_3400_VAT_AMOUNT                                  number;
p_3400_SERVICE_TAX_AMOUNT_LC                       number;
p_3400_VAT_AMOUNT_LC                              number;
p_3400_NET_COMM                                      number;
p_3400_NET_COMM_LC                                  number;
p_3400_TUR                                          number;
p_3400_ACC_TYPE                                      number;
p_3400_CUS_ACC_NO                                  number;
p_3400_CASH_CODE                                  number;

p_3400_TAHSIL_TUTARI_R                              number;
p_3400_TAHSIL_TUTARI_A_R                          number;
p_3400_TAHSIL_TUTARI_B_R                          number;

p_3400_NET_COMM_LC_R                              number;
p_3400_NET_COMM_LC_A_R                              number;
p_3400_NET_COMM_LC_B_R                              number;

p_3400_TAX_AMOUNT_LC_R                              number;
p_3400_TAX_AMOUNT_LC_A_R                          number;
p_3400_TAX_AMOUNT_LC_B_R                          number;
/*------------------------------------------------------------------------------------------------------*/
 FUNCTION kur_al (ln_dvz_kod in CBS_MASRAF_KOM_TAHSIL_ISL.DVZ%TYPE) return number IS
 Begin
  return Pkg_Kur.yuvarla(ln_dvz_kod,Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,ln_dvz_kod,
                                                                      NULL,1,1,NULL,NULL,'N','A'));
 End;
/*------------------------------------------------------------------------------------------------------*/
 Procedure Kontrol_Sonrasi(pn_islem_no number) is
    ln_doviz_tutari number;
    ln_bakiye number;
    ln_tahsil_tutar number;
    CURSOR islem_cursor IS
                SELECT * from cbs_masraf_kom_tahsil_isl
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
   Begin


    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;


    --KUPUR KONTROLLERI
    IF row_islem.cash_account = 'CASH' THEN
        if     row_islem.dvz = pkg_genel.lc_al then  -- collection is done with local currency then both collection and charge are local curr.
              ln_tahsil_tutar := nvl(row_islem.tahsil_toplam_tutar,0);
        else
              if row_islem.dvz <> row_islem.TAHSIL_DVZ_KOD then
                       ln_tahsil_tutar := round((nvl(row_islem.tahsil_toplam_tutar,0) * row_islem.kur),1);
              else
                 ln_tahsil_tutar := nvl(row_islem.tahsil_toplam_tutar,0);
              end if;
        end if;
        Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no ,3400, ln_tahsil_tutar, row_islem.TAHSIL_DVZ_KOD, 'Y');
        Pkg_Cash_Slip.Cash_Slip( pn_TX_NO                  => pn_islem_no,
                                pn_ISLEM_TIPI               => 1, --deposit
                                pd_ISLEM_TARIHI           => pkg_muhasebe.banka_tarihi_bul,
                                ps_ISLEM_TIPI_DOVIZ_KODU  => row_islem.TAHSIL_DVZ_KOD,
                                pn_ISLEM_KOD              => 3400,
                                pn_ISLEM_TIPI_TUTARI      => ln_tahsil_tutar,
                                ps_ACIKLAMA               => row_islem.ACIKLAMA,
                                pn_MUSTERI_HESAP_NO       => null,
                                ps_GL_HESAP_NO               => row_islem.INCOME_GL,
                                ps_MUSTERI_ADI               => null,
                                ps_BAGLAM_BOLUM              => pkg_baglam.Bolum_kodu,
                                pn_PREFIX_ISTATISTIK_KODU => null,
                                ps_ISTATISTIK_DOVIZ_KODU  => null,
                                ps_ISTATISTIK_KODU           => null
                                       ) ;
    END IF;

    /*if row_islem.REZERVASYON_NO is not null then

       ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

       IF row_islem.tahsil_toplam_tutar > ln_bakiye THEN --Bakiye Yetersiz..
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
       else
          Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                           pn_islem_no,
                                                           row_islem.tahsil_toplam_tutar);
       END IF;

    end if;*/
        
  End;

/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
    CURSOR islem_cursor IS
                SELECT * from cbs_masraf_kom_tahsil_isl
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
    ln_tahsil_tutar number;

   Begin
    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;
    --KUPUR KONTROLLERI
    IF row_islem.cash_account = 'CASH' THEN
        if     row_islem.dvz = pkg_genel.lc_al then  -- collection is done with local currency then both collection and charge are local curr.
              ln_tahsil_tutar := nvl(row_islem.tahsil_toplam_tutar,0);
        else
              if row_islem.dvz <> row_islem.TAHSIL_DVZ_KOD then
                       ln_tahsil_tutar := nvl(row_islem.tahsil_toplam_tutar,0) * row_islem.kur;
              else
                 ln_tahsil_tutar := nvl(row_islem.tahsil_toplam_tutar,0);
              end if;
        end if;
        Pkg_Tx1601.Dogrulama_Sonrasi(pn_islem_no ,3400, ln_tahsil_tutar,row_islem.TAHSIL_DVZ_KOD,'Y');
    END IF;
    
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
   Reddetme_Sonrasi(pn_islem_no);
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number) is

    ln_temp number;
    ln_alacak_hesap number;
    ln_bakiye number;
    ln_mus_kur number;
    ln_mal_kur number;
    ln_sira_no number;
    ls_referans varchar2(16);
    ln_tahsil_tutar number;

    cursor cur_o is
     select *
       from cbs_masraf_kom_tahsil_isl
     where tx_no = pn_islem_no;
    row_o cur_o%rowtype;

  Begin
        open cur_o;
        fetch cur_o into row_o;
        close cur_o;

        update cbs_masraf_kom_tahsil_isl
        set durum_kodu = 'ACIK'
        where tx_no = pn_islem_no;

        IF row_o.cash_account = 'CASH' THEN
            if     row_o.dvz = pkg_genel.lc_al then  -- collection is done with local currency then both collection and charge are local curr.
                  ln_tahsil_tutar := nvl(row_o.tahsil_toplam_tutar,0);
            else
              if row_o.dvz <> row_o.TAHSIL_DVZ_KOD then
                       ln_tahsil_tutar := nvl(row_o.tahsil_toplam_tutar,0) * row_o.kur;
              else
                 ln_tahsil_tutar := nvl(row_o.tahsil_toplam_tutar,0);
              end if;
            end if;
            Pkg_Tx1601.Onay_Sonrasi(pn_islem_no ,3400, ln_tahsil_tutar, row_o.TAHSIL_DVZ_KOD, 'Y');
        END IF;

        /*
       if nvl(row_o.rezervasyon_no,0) > 0 then
          --rezervasyondan gidilmis...
          pkg_kur_rezervasyon.Rezervasyon_Alis_Bilgisi_Al(row_o.rezervasyon_no, ln_mus_kur, ln_mal_kur);
       else
          --yok kur tablosundan al
           ln_mus_kur := row_o.kur;
       end if;*/
              --yok kur tablosundan al
           ln_mus_kur := row_o.kur;
       insert into cbs_masraf_kom_tahsil( islem_no, sira_no, gelir_tipi, dvz, musteri_no, iliskili_hesap_no,
               iliskili_referans, tahsil_tutari, kkdf_var, kkdf_oran, kkdf_tutari,
               bsmv_var, bsmv_oran, bsmv_tutari, tesvikli_oran, tahsil_toplam_tutar,
               tahsil_dvz_kod, kur, tahsil_hesap_no, aciklama, durum_kodu,  rezervasyon_no,
               tarih, gelir_aciklama, service_tax, tax_coll_type, paid_tax_amount, service_tax_rate,
               prefix_istatistik_kodu, istatistik_kodu, vat, vat_rate,income_gl, cash_account,
               id_card_no, verildigi_yer, verildigi_tarih, nakit_kodu,residency_code,citizen_code,
               id_type,--maksatt 13.10.22 rbo-395
               id_no,
               validity_date,
               date_of_birth,
               gender,
               name,
               middle_name,
               surname,
               tin,--maksatt rbo-395 12.12.2022
                 Customer_type---- CQ5514 KonstantinJ  07.02.2017
               ) -- CQ4808 KonstantinJ 3400 Modification 29.06.2015 
       (select tx_no, sira_no, gelir_tipi, dvz, musteri_no, iliskili_hesap_no,
               iliskili_referans, tahsil_tutari, kkdf_var, kkdf_oran, kkdf_tutari,
               bsmv_var, bsmv_oran, bsmv_tutari, tesvikli_oran, tahsil_toplam_tutar,
               tahsil_dvz_kod, kur, tahsil_hesap_no, aciklama, durum_kodu, rezervasyon_no,
               tarih, gelir_aciklama, service_tax, tax_coll_type, paid_tax_amount, service_tax_rate,
               prefix_istatistik_kodu, istatistik_kodu, vat, vat_rate,income_gl, cash_account,
               id_card_no, verildigi_yer, verildigi_tarih, nakit_kodu,residency_code,citizen_code,-- CQ4808 KonstantinJ 3400 Modification 29.06.2015
               id_type,--maksatt 13.10.22 rbo-395
               id_no,
               validity_date,
               date_of_birth,
               gender,
               name,
               middle_name,
               surname,
               tin,--maksatt rbo-395 12.12.2022
                     Customer_type---- CQ5514 KonstantinJ  07.02.2017  
             from cbs_masraf_kom_tahsil_isl
            where tx_no = pn_islem_no); 

     if  row_o.gelir_tipi in ('LGISSUECOM','EXPCOMCAT','IMPCOMCAT','RECGUARCOM') then
         ls_referans := row_o.iliskili_referans ;
         ln_sira_no  := pkg_genel.genel_kod_al('SABIT_MASRAF') ;
         pkg_masraf.iptal_icin_log_at(pn_islem_no, ls_referans,ln_sira_no,
                                      row_o.gelir_tipi, row_o.tahsil_tutari,0 );
     elsif row_o.gelir_tipi = 'LOANINT'  then
         update cbs_hesap_kredi
         set tahsiledilen_faiz_tutari = NVL(tahsiledilen_faiz_tutari,0) + NVL(row_o.tahsil_tutari,0)
         where  hesap_no =  row_o.iliskili_hesap_no ;
     elsif row_o.gelir_tipi = 'LOANCOMM' then
            update cbs_hesap_kredi
         set tahsiledilen_komisyon_tutari = NVL(tahsiledilen_komisyon_tutari,0) + NVL(row_o.tahsil_tutari,0)
         where  hesap_no =  row_o.iliskili_hesap_no ;
     end if;


  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  ln_rezervasyon_no number;
  Begin
      select rezervasyon_no
      into ln_rezervasyon_no
      from cbs_masraf_kom_tahsil_isl
     where tx_no=pn_islem_no;

-- Kur rezervasyon kullanilmamis olabilir...
    if ln_rezervasyon_no is not null then
       Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Iptal(pn_islem_no);
    end if;

     update cbs_masraf_kom_tahsil_isl
        set durum_kodu = 'RED'
       where tx_no = pn_islem_no;



  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is        -- Islem iptal edilemez
  ls_ref                 varchar2(16);
  ln_rezervasyon_no        number;
   cursor cur_o is
     select *
       from cbs_masraf_kom_tahsil_isl
      where tx_no = pn_islem_no;
    row_o cur_o%rowtype;
  Begin

     open cur_o;
     fetch cur_o into row_o;
     close cur_o;

     update cbs_masraf_kom_tahsil_isl
        set durum_kodu = 'IPTAL'
       where tx_no = pn_islem_no;

     update cbs_masraf_kom_tahsil
        set durum_kodu = 'IPTAL'
       where islem_no = pn_islem_no;

     IF row_o.cash_account = 'CASH' THEN
        Pkg_Tx1601.Iptal_Onay_Sonrasi(pn_islem_no,3400);
     end if;
       if  row_o.gelir_tipi in ('LGISSUCOM','EXPCOMCAT','IMPCOMCAT','RECGUARCOM') then
           update cbs_masraf_ith_ihr_ipt_log
           set durum='IPTAL'
           where islem_no = pn_islem_no;
       elsif row_o.gelir_tipi = 'LOANINT'  then
           update cbs_hesap_kredi
           set tahsiledilen_faiz_tutari =tahsiledilen_faiz_tutari - row_o.tahsil_tutari
           where  hesap_no =  row_o.iliskili_hesap_no ;
       elsif row_o.gelir_tipi = 'LOANCOMM' then
              update cbs_hesap_kredi
              set tahsiledilen_komisyon_tutari =tahsiledilen_komisyon_tutari - row_o.tahsil_tutari
           where  hesap_no =  row_o.iliskili_hesap_no ;
       end if;



       /*
-- Islem iptal edilirse, kullandigi kur rezervasyonu da kullanim listesinden siliniyor.
-- Kur rezervasyon kullanilmamis olabilir...
    if ln_rezervasyon_no is not null then
       Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Iptal(pn_islem_no);
    end if;
*/
--DAB varsa iptal edilecek
  --  pkg_dab.DAB_Iptal(pn_islem_no);

  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number) is
   cursor cur_o is
     select *
       from cbs_masraf_kom_tahsil_isl
      where tx_no = pn_islem_no;
    row_o cur_o%rowtype;
  Begin
     open cur_o;
     fetch cur_o into row_o;
     close cur_o;

    IF row_o.cash_account = 'CASH' THEN
       Pkg_Tx1601.Iptal_Muhasebelestir_Sonrasi(pn_islem_no,3400);
    end if;
      
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number) is

   varchar_list              pkg_muhasebe.varchar_array;
   number_list              pkg_muhasebe.number_array;
   date_list              pkg_muhasebe.date_array;
   boolean_list              pkg_muhasebe.boolean_array;
   ln_fis_no              number;
   ls_aciklama            varchar2(2000);
   ls_ref                   varchar2(16);
   ln_temp                  number;
   ln_mus_kur               number;
   ln_mal_kur              number;
   ls_not_1                  varchar2(100);
   ls_not_2                  varchar2(100);
   ln_dk_kod              cbs_musteri.dk_grup_kod%type;
   ls_dk_grup_kod          cbs_musteri.DK_GRUP_KOD%type;
   ls_modul_tur_kod          cbs_hesap.modul_tur_kod%type;
   ls_urun_tur_kod          cbs_hesap.urun_tur_kod%type;
   ls_urun_sinif_kod      cbs_hesap.urun_sinif_kod%type;
   ls_cash_GL              varchar2(200);
--   iliskili_kom_dk_yok    exception;
   ls_kom_dk              varchar2(2000);
   ls_hesap_no              cbs_hesap_kredi.HESAP_NO%type;
   ls_service_tax_dk      varchar2(30);
   ln_dk_grup_no          number;
   cursor cur_o is
    select * from cbs_masraf_kom_tahsil_isl
     where tx_no = pn_islem_no;
   row_o cur_o%rowtype;

    ln_rounded           number;
 
Begin
     open cur_o;
     fetch cur_o into row_o;
     close cur_o;
     ln_fis_no := 0;

    number_list(p_3400_TAHSIL_TUTARI)       :=0;

    number_list(p_3400_TAX_AMOUNT_LC_R)       :=0;
    number_list(p_3400_TAX_AMOUNT_LC_A_R)       :=0;
    number_list(p_3400_TAX_AMOUNT_LC_B_R)       :=0;

    number_list(p_3400_TAHSIL_TUTARI_R)       :=0;
    number_list(p_3400_TAHSIL_TUTARI_A_R)       :=0;
    number_list(p_3400_TAHSIL_TUTARI_B_R)       :=0;

    number_list(p_3400_NET_COMM_LC_R)       :=0;
    number_list(p_3400_NET_COMM_LC_A_R)       :=0;
    number_list(p_3400_NET_COMM_LC_B_R)       :=0;

    number_list(p_3400_TAHSIL_TUTARI_LC)    :=0;
    number_list(p_3400_TAX_AMOUNT)            :=0;
    number_list(p_3400_TAX_AMOUNT_LC)        :=0;
    number_list(p_3400_TOPLAM_TUTAR    )        :=0;
    number_list(p_3400_TOPLAM_TUTAR_LC    )    :=0;
    number_list(p_3400_SERVICE_TAX_AMOUNT)  :=0;
    number_list(p_3400_VAT_AMOUNT)          :=0;
    number_list(p_3400_SERVICE_TAX_AMOUNT_LC) :=0;
    number_list(p_3400_VAT_AMOUNT_LC)        :=0;
    number_list(p_3400_NET_COMM)            :=0;
    number_list(p_3400_NET_COMM_LC)            :=0;

    varchar_list(p_3400_TAHSIL_HESAP_BOLUM) := '';
    varchar_list(p_3400_TAHSIL_HESAP_NO) := '';
    varchar_list(p_3400_TAHSIL_HESAP_DVZ) := '';
    varchar_list(p_3400_REFERANS_NO) := '';
    varchar_list(p_3400_M_ACIKLAMA) := '';
    varchar_list(p_3400_B_ACIKLAMA) := '';
    varchar_list(p_3400_BOLUM_KODU) := '';
    varchar_list(p_3400_DOVIZ_KODU) := '';
    varchar_list(p_3400_MASRAF_DK)    := '' ;
    varchar_list(p_3400_TAX_DK)    := '' ;

    boolean_list(p_3400_TAH_DVZ_TRY)                    := FALSE;
    boolean_list(p_3400_TAH_DVZ_YP)                    := FALSE;
    boolean_list(p_3400_ILISKILI_HESAP_VAR)         := FALSE;
    boolean_list(p_3400_ILISKILI_HESAP_YOK)         := FALSE;
    boolean_list(p_3400_MAS_DVZ_YP)              := FALSE;
    boolean_list(p_3400_MAS_DVZ_TRY)              := FALSE;

    varchar_list(p_3400_BOLUM_KODU)  := pkg_tx.amir_bolumkodu_al(pn_islem_no); --pkg_baglam.bolum_kodu;
    varchar_list(p_3400_DOVIZ_KODU)  := row_o.dvz;

    --cbs_masraf_kom_tahsil_isl
    if sf_istatistikkod_zorunlumu_1(row_o.CASH_ACCOUNT,row_o.MUSTERI_NO)='E' then
       varchar_list(p_3400_ISTATISTIK_KODU) := pkg_musteri.paymentkod_formatli_al( row_o.MUSTERI_NO ,row_o.istatistik_kodu) ;

    elsif sf_istatistikkod_zorunlumu_2(row_o.CASH_ACCOUNT,row_o.DVZ)='E' then

      if row_o.ILISKILI_HESAP_NO is not null then
         varchar_list(p_3400_ISTATISTIK_KODU) := pkg_musteri.paymentkod_formatli_al(pkg_hesap.HesaptanMusteriNoAl(row_o.ILISKILI_HESAP_NO) ,row_o.istatistik_kodu) ;
      else
         varchar_list(p_3400_ISTATISTIK_KODU) :=row_o.istatistik_kodu||'10';
      end if;

    end if;

    if     varchar_list(p_3400_DOVIZ_KODU) =pkg_genel.lc_al then
        boolean_list(p_3400_MAS_DVZ_YP) := FALSE;
        boolean_list(p_3400_MAS_DVZ_TRY) := TRUE;
    else
          boolean_list(p_3400_MAS_DVZ_YP) := TRUE;
        boolean_list(p_3400_MAS_DVZ_TRY) := FALSE;
    end if;
    if row_o.cash_account = 'ACCOUNT' then

        varchar_list(p_3400_TAHSIL_HESAP_NO)    := row_o.tahsil_hesap_no;
            log_at('CASH TEST',1,varchar_list(p_3400_TAHSIL_HESAP_NO));
        varchar_list(p_3400_TAHSIL_HESAP_BOLUM) := pkg_hesap.HesapSubeAl(varchar_list(p_3400_TAHSIL_HESAP_NO));
        varchar_list(p_3400_TAHSIL_HESAP_DVZ)   := pkg_hesap.HesaptanDovizKoduAl(varchar_list(p_3400_TAHSIL_HESAP_NO));
        varchar_list(p_3400_TUR) := 'VS';
        varchar_list(p_3400_ACC_TYPE) := 'VS';
        varchar_list(p_3400_CUS_ACC_NO) := row_o.tahsil_hesap_no;
    else
        if     varchar_list(p_3400_DOVIZ_KODU) = pkg_genel.lc_al then
          -- hs,20100118, for outlet
          if pkg_tx6200.sube_outlet_mi(varchar_list(p_3400_BOLUM_KODU)) = 'H' then
            pkg_parametre.deger('G_DK_LC_CASH_GL', ls_cash_GL);
          else
            pkg_parametre.deger('G_DK_OUTLET_CASH_GL', ls_cash_GL);
          end if;
          -- hs,20100118, for outlet

            varchar_list(p_3400_TAHSIL_HESAP_NO)    := ls_cash_GL;            
            log_at('CASH TEST',2,varchar_list(p_3400_TAHSIL_HESAP_NO),ls_cash_GL);
            log_at('CASH TEST',3,varchar_list(p_3400_TAHSIL_HESAP_NO),varchar_list(p_3400_TAHSIL_HESAP_BOLUM));
            varchar_list(p_3400_TAHSIL_HESAP_BOLUM) := varchar_list(p_3400_BOLUM_KODU);
            varchar_list(p_3400_TAHSIL_HESAP_DVZ)   := pkg_genel.lc_al;
            varchar_list(p_3400_TUR) := 'DK';
            varchar_list(p_3400_ACC_TYPE) := '';
            varchar_list(p_3400_CUS_ACC_NO) := '';
        else
          -- hs,20100118, for outlet
          if pkg_tx6200.sube_outlet_mi(varchar_list(p_3400_BOLUM_KODU)) = 'H' then
            pkg_parametre.deger('G_DK_FC_CASH_GL', ls_cash_GL);
          else
            pkg_parametre.deger('G_DK_OUTLET_CASH_GL', ls_cash_GL);
          end if;
          -- hs,20100118, for outlet

            varchar_list(p_3400_TAHSIL_HESAP_NO)    := ls_cash_GL;
            varchar_list(p_3400_TAHSIL_HESAP_BOLUM) := varchar_list(p_3400_BOLUM_KODU);
            varchar_list(p_3400_TAHSIL_HESAP_DVZ)   := row_o.TAHSIL_DVZ_KOD;--varchar_list(p_3400_DOVIZ_KODU);
            varchar_list(p_3400_TUR) := 'DK';
            varchar_list(p_3400_ACC_TYPE) := '';
            varchar_list(p_3400_CUS_ACC_NO) := '';            
            log_at('CASH TEST',4,varchar_list(p_3400_TAHSIL_HESAP_NO),ls_cash_GL);
            log_at('CASH TEST',5,varchar_list(p_3400_TAHSIL_HESAP_NO),varchar_list(p_3400_TAHSIL_HESAP_BOLUM));
        end if;
    end if;

    if varchar_list(p_3400_TAHSIL_HESAP_DVZ) = pkg_genel.lc_al then
       boolean_list(p_3400_TAH_DVZ_TRY) := TRUE;
       boolean_list(p_3400_TAH_DVZ_YP) := FALSE;
    else
       boolean_list(p_3400_TAH_DVZ_TRY) := FALSE;
       boolean_list(p_3400_TAH_DVZ_YP) := TRUE;
    end if;

    if  boolean_list(p_3400_MAS_DVZ_YP) =TRUE and boolean_list(p_3400_TAH_DVZ_YP)=TRUE then
        ln_mus_kur:=pkg_kur.doviz_doviz_karsilik(varchar_list(p_3400_DOVIZ_KODU),pkg_genel.lc_al,
                                                 null,1,1,null,null,'N','A');
    elsif boolean_list(p_3400_TAH_DVZ_TRY) = TRUE and boolean_list(p_3400_MAS_DVZ_TRY) = TRUE then
        ln_mus_kur := 1;
    elsif boolean_list(p_3400_TAH_DVZ_TRY) = TRUE and boolean_list(p_3400_MAS_DVZ_YP) = TRUE then
        ln_mus_kur := row_o.kur;  --komisyon kuru
    end if;
    varchar_list(p_3400_CASH_CODE) := row_o.nakit_kodu;
    number_list(p_3400_KUR) := ln_mus_kur;

    number_list(p_3400_TAHSIL_TUTARI)    :=    nvl(row_o.tahsil_tutari,0);
    number_list(p_3400_TAHSIL_TUTARI_LC) :=    number_list(p_3400_TAHSIL_TUTARI) * ln_mus_kur;

    if row_o.tax_coll_type ='DFI'
    then
        number_list(p_3400_NET_COMM_LC) := round((number_list(p_3400_TAHSIL_TUTARI_LC)/(((NVL(row_o.service_tax_rate,0)+NVL(row_o.vat_rate,0))/100) + 1)),2);
       
        number_list(p_3400_SERVICE_TAX_AMOUNT_LC) := ROUND(NVL(number_list(p_3400_NET_COMM_LC),0)*NVL(row_o.service_tax_rate,0)/100,2);
            number_list(p_3400_VAT_AMOUNT_LC) := number_list(p_3400_TAHSIL_TUTARI_LC) - number_list(p_3400_NET_COMM_LC) - number_list(p_3400_SERVICE_TAX_AMOUNT_LC);


        number_list(p_3400_SERVICE_TAX_AMOUNT) := ROUND(number_list(p_3400_SERVICE_TAX_AMOUNT_LC)/ln_mus_kur,2);
        number_list(p_3400_VAT_AMOUNT) := ROUND(number_list(p_3400_VAT_AMOUNT_LC)/ln_mus_kur,2);

        number_list(p_3400_NET_COMM):=number_list(p_3400_TAHSIL_TUTARI) - number_list(p_3400_SERVICE_TAX_AMOUNT) - number_list(p_3400_VAT_AMOUNT);
    else
        number_list(p_3400_SERVICE_TAX_AMOUNT_LC) := ROUND(((number_list(p_3400_TAHSIL_TUTARI_LC)*nvl(row_o.service_tax_rate,0))/100),2);
        number_list(p_3400_SERVICE_TAX_AMOUNT) := ROUND(number_list(p_3400_SERVICE_TAX_AMOUNT_LC)/ln_mus_kur,2);

        number_list(p_3400_VAT_AMOUNT_LC)     :=    ROUND(((number_list(p_3400_TAHSIL_TUTARI_LC)*nvl(row_o.vat_rate,0))/100),2);
        number_list(p_3400_VAT_AMOUNT)          := ROUND(number_list(p_3400_VAT_AMOUNT_LC)/ln_mus_kur,2);
   end if;


    number_list(p_3400_TAX_AMOUNT)  := number_list(p_3400_SERVICE_TAX_AMOUNT) + number_list(p_3400_VAT_AMOUNT);

    -- hs20090625
    if abs(number_list(p_3400_TAX_AMOUNT) - nvl(row_o.PAID_TAX_AMOUNT,0)) <= 0.01
    then
        number_list(p_3400_TAX_AMOUNT) := nvl(row_o.PAID_TAX_AMOUNT,0);
    end if;
    -- hs20090625
log_at('hakan001','number_list(p_3400_SERVICE_TAX_AMOUNT)',number_list(p_3400_SERVICE_TAX_AMOUNT));
log_at('hakan002','number_list(p_3400_VAT_AMOUNT)',number_list(p_3400_VAT_AMOUNT));
    number_list(p_3400_TAX_AMOUNT_LC)    := number_list(p_3400_SERVICE_TAX_AMOUNT_LC) + number_list(p_3400_VAT_AMOUNT_LC);
log_at('hakan003','number_list(p_3400_TAX_AMOUNT_LC)',number_list(p_3400_TAX_AMOUNT_LC));

----------------------- rounding -----------------------
    ln_rounded :=pkg_tutar.Rounding(number_list(p_3400_TAX_AMOUNT_LC)); --  CQ516 Roundings KonstantinJ 28052014

    number_list(p_3400_TAX_AMOUNT_LC_R):= number_list(p_3400_TAX_AMOUNT_LC);
    number_list(p_3400_TAX_AMOUNT_LC_A_R):= 0;
    number_list(p_3400_TAX_AMOUNT_LC_B_R):= 0;
    
   


    if row_o.cash_account = 'CASH' then
        if ln_rounded > number_list(p_3400_TAX_AMOUNT_LC)
        then
            number_list(p_3400_TAX_AMOUNT_LC_A_R):= ln_rounded - number_list(p_3400_TAX_AMOUNT_LC) ;
            number_list(p_3400_TAX_AMOUNT_LC_R):= ln_rounded;
        else
            number_list(p_3400_TAX_AMOUNT_LC_B_R):= number_list(p_3400_TAX_AMOUNT_LC)-ln_rounded ;
            number_list(p_3400_TAX_AMOUNT_LC_R):= ln_rounded;
        end if;
    end if;
----------------------- rounding -----------------------

----------------------- rounding -----------------------
--    ln_rounded := round(number_list(p_3400_NET_COMM_LC),1);

    number_list(p_3400_NET_COMM_LC_R):= number_list(p_3400_NET_COMM_LC);
    number_list(p_3400_NET_COMM_LC_A_R):= 0;
    number_list(p_3400_NET_COMM_LC_B_R):= 0;

/*
    if ln_rounded > number_list(p_3400_NET_COMM_LC)
    then
        number_list(p_3400_NET_COMM_LC_B_R):= ln_rounded - number_list(p_3400_NET_COMM_LC) ;
        number_list(p_3400_NET_COMM_LC_R):= ln_rounded;
    else
        number_list(p_3400_NET_COMM_LC_A_R):= number_list(p_3400_NET_COMM_LC)-ln_rounded ;
        number_list(p_3400_NET_COMM_LC_R):= ln_rounded;
    end if;
*/
----------------------- rounding -----------------------

    number_list(p_3400_TOPLAM_TUTAR)     :=    NVL(number_list(p_3400_TAHSIL_TUTARI),0) - NVL(number_list(p_3400_TAX_AMOUNT),0) ;
    number_list(p_3400_TOPLAM_TUTAR_LC)     :=    NVL(number_list(p_3400_TAHSIL_TUTARI_LC),0) - NVL(number_list(p_3400_TAX_AMOUNT_LC),0) ;

    varchar_list(p_3400_M_ACIKLAMA) := row_o.aciklama;
--    varchar_list(p_3400_B_ACIKLAMA) := pkg_masraf.Sf_Gelir_Adi(row_o.gelir_tipi);
     varchar_list(p_3400_B_ACIKLAMA) :=     varchar_list(p_3400_M_ACIKLAMA);

    varchar_list(p_3400_REFERANS_NO)        := nvl(row_o.tahsil_hesap_no,'0');

    if row_o.service_tax ='Y' or row_o.vat ='Y' then
       boolean_list(p_3400_TAX_VAR) := TRUE;
          boolean_list(p_3400_TAX_YOK) := FALSE;
       if row_o.tax_coll_type ='DFI' then
          boolean_list(p_3400_TAX_DEDUCTED):=TRUE;
          boolean_list(p_3400_TAX_PAID):=FALSE;
       else
            boolean_list(p_3400_TAX_DEDUCTED):=FALSE;
          boolean_list(p_3400_TAX_PAID):=TRUE;
       end if;
    else
         boolean_list(p_3400_TAX_VAR) := FALSE;
          boolean_list(p_3400_TAX_YOK) := TRUE;
    end if;

    if row_o.gelir_tipi in ('LOANINT','LOANCOMM') then
       boolean_list(p_3400_ILISKILI_HESAP_VAR)         := TRUE;
          boolean_list(p_3400_ILISKILI_HESAP_YOK)         := FALSE;
       ls_hesap_no  :=row_o.iliskili_hesap_no ;
     else
        boolean_list(p_3400_ILISKILI_HESAP_VAR)         := FALSE;
           boolean_list(p_3400_ILISKILI_HESAP_YOK)         := TRUE;
     end if;
    varchar_list(p_3400_ILISKILI_HESAP_DK)    := row_o.INCOME_GL;
    varchar_list(p_3400_MASRAF_DK)            := row_o.INCOME_GL;

    pkg_parametre.deger('G_DK_SERVICE_TAX', varchar_list(p_3400_TAX_DK));

   if row_o.gelir_tipi = 'LOANINT' and row_o.INCOME_GL like '605%' --11.03.2015 CQ4611 VictorK check by gelir_tipi code
    then
        varchar_list(p_3400_TAX_DK) := '21113710';
    end if;

    ln_fis_no:=pkg_muhasebe.fis_kes ( 3400,
                                         null,
                                         pn_islem_no,
                                        varchar_list ,
                                        number_list  ,
                                        date_list    ,
                                        boolean_list ,
                                        null,
                                       false,
                                        ln_fis_no,
                                        null);

/*    if varchar_list(p_3400_TAHSIL_HESAP_DVZ) <> pkg_genel.lc_al then   --DAB KESILECEK

       Pkg_Dab.DAB_DUZENLE(PN_TX_NO => pn_islem_no,
                          PN_MUSTERI_NO              => row_o.MUSTERI_NO,
                          PS_ISLEM_TIPI           => 'A',
                          PS_DOVIZ_EFEKTIF           => 'D',
                          PS_DOVIZI_SATAN           => pkg_musteri.Sf_Musteri_Adi(row_o.musteri_no),
                          PS_UYRUK                   => pkg_musteri.Sf_UyrukKod_Al(row_o.musteri_no),
                          PS_DOVIZ_KODU           => row_o.dvz,
                          PS_DOVIZ_ULKE_KODU      => null,
                          PS_ISTATISTIK_KODU       => 1240,
                          PN_TUTAR                   => NVL(row_o.tahsil_tutari,0),
                          PN_KUR                   => NVL(ln_mus_kur,0),
                          PS_ACIKLAMA               => row_o.ACIKLAMA) ;

    end if;
*/
    pkg_muhasebe.muhasebelestir(ln_fis_no);

    if row_o.cash_account = 'CASH' then
       Pkg_Tx1601.Muhasebelesme(pn_islem_no,3400);
    end if;
--    Exception
--      When iliskili_kom_dk_yok then
--      raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter || ls_hesap_no || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 
 End;


/* -------------------------------------------------------------------------------------- */

  Function sf_istatistikkod_zorunlumu_1(ps_islem_sekli varchar2, pn_musteri_no number ) return varchar2
  is
   ls_musteri_tipi_kod    varchar2(1);
   ln_dk_grup_kod        number;
  Begin
         select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_musteri_tipi_kod,
                ln_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_musteri_no ;

       if (ps_islem_sekli='ACCOUNT' ) and  ( ln_dk_grup_kod = 1023 ) Then
             return 'E';
       else
             return 'H';
       end if;

      Exception
        when others then return 'H';
  End;

/* -------------------------------------------------------------------------------------- */
  Function sf_istatistikkod_zorunlumu_2(ps_islem_sekli varchar2, ps_doviz_kodu varchar2 ) return varchar2
  is
  Begin

       if (ps_islem_sekli='CASH') and ( ps_doviz_kodu<>pkg_genel.LC_al ) Then
             return 'E';
       else
             return 'H';
       end if;

      Exception
        when others then return 'H';
  End;
 
--maksatt 13.10.22 rbo-395
PROCEDURE GET_CUSTOMER_INFORMATION(pc_tax_no varchar2,  ps_name out varchar2, 
        ps_middle_name out varchar2, ps_surname out varchar2, ps_id_type out varchar2,
        ps_id_no out varchar2,ps_validity_date out date, ps_date_of_birth out date,
        ps_issuing_authority out varchar2,ps_gender out varchar2, ps_customer_no out number,
        ps_issue_date out date) is
 ln_tin 	        number;
 ln_id_card         varchar2(50);
 ln_resident_permit varchar2(50);
 ln_driving_licence varchar2(50);
 ln_passport        varchar2(50);
 ls_military_card   varchar2(50);
begin
    select TC_KIMLIK_NO, NUFUS_CUZDANI_SERI_NO, EHLIYET_BELGE_NO, PASAPORT_NO,
    MILITARY_CARD
    into ln_id_card, ln_resident_permit, ln_driving_licence, ln_passport,
    ls_military_card
    from cbs_musteri where VERGI_NO = to_char(pc_tax_no) and ROWNUM = 1;
    
    case when ln_id_card is not null
            then ps_id_type := '1'; ps_id_no:= ln_id_card;
         when ln_resident_permit is not null
            then ps_id_type := '2'; ps_id_no:= ln_resident_permit;
         when ln_driving_licence is not null
            then ps_id_type := '3'; ps_id_no:= ln_driving_licence;
         when ln_passport is not null
            then ps_id_type := '4'; ps_id_no:= ln_passport;
         when ln_passport is not null
            then ps_id_type := '5'; ps_id_no:= ls_military_card;
    end case;

    select ISIM, IKINCI_ISIM,SOYADI,GECERLILIK_TARIHI,DOGUM_TARIHI,
       VERILDIGI_YER,CINSIYET_KOD, MUSTERI_NO, VERILDIGI_TARIH
    into
    	ps_name,ps_middle_name,ps_surname,ps_validity_date,ps_date_of_birth,
    	ps_issuing_authority,ps_gender,ps_customer_no, ps_issue_date
		from cbs_musteri
		where VERGI_NO = to_char(pc_tax_no) and ROWNUM = 1; --rownum for test bases, bcz there're users with non-unique TIN
		exception when no_data_found then
        null;
end; 

--maksatt 04.10.22 rbo-395
PROCEDURE GET_CUSTOMER_BY_PASSPORT(pc_id_no varchar2, pc_id_type varchar2,
        ps_name out varchar2,ps_middle_name out varchar2, ps_surname out varchar2,
        ps_validity_date out date, ps_date_of_birth out date,
        ps_gender out varchar2, ps_customer_no out number, ps_tin out varchar2, 
        ps_issue_place out varchar2, ps_issue_date out date) 
    is
begin
    select ISIM,IKINCI_ISIM,SOYADI,GECERLILIK_TARIHI,DOGUM_TARIHI,CINSIYET_KOD, 
        MUSTERI_NO, VERGI_NO, verildigi_yer, VERILDIGI_TARIH
    into
           ps_name,ps_middle_name,ps_surname,ps_validity_date,ps_date_of_birth,
           ps_gender,ps_customer_no, ps_tin, ps_issue_place, ps_issue_date
	from cbs_musteri A
		where  
            REPLACE(pc_id_no, ' ', '') = 
            case
                when pc_id_type = '3' then REPLACE(A.EHLIYET_BELGE_NO, ' ', '')
                when pc_id_type = '1' then REPLACE(A.NUFUS_CUZDANI_SERI_NO, ' ', '')
                when pc_id_type = '2' then REPLACE(A.RESIDENCE_PERMIT, ' ', '')
                when pc_id_type = '4' then REPLACE(A.PASAPORT_NO, ' ', '')
                when pc_id_type = '5' then REPLACE(A.MILITARY_CARD, ' ', '')
                else null
            end and ROWNUM = 1;--ROWNUM for test bases, bcz there're users with non-unique TIN
    exception when no_data_found then
        null;
end; --maksatt 04.10.22 rbo-395

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN

    p_3400_BOLUM_KODU               := pkg_muhasebe.parametre_index_bul('3400_BOLUM_KODU');
    p_3400_B_ACIKLAMA               := pkg_muhasebe.parametre_index_bul('3400_B_ACIKLAMA');
    p_3400_DOVIZ_KODU               := pkg_muhasebe.parametre_index_bul('3400_DOVIZ_KODU');
    p_3400_ISTATISTIK_KODU           := pkg_muhasebe.parametre_index_bul('3400_ISTATISTIK_KODU');
    p_3400_KUR                       := pkg_muhasebe.parametre_index_bul('3400_KUR');
    p_3400_M_ACIKLAMA               := pkg_muhasebe.parametre_index_bul('3400_M_ACIKLAMA');
    p_3400_REFERANS_NO               := pkg_muhasebe.parametre_index_bul('3400_REFERANS_NO');
    p_3400_003_SUBE                   := pkg_muhasebe.parametre_index_bul('3400_003_SUBE');
    p_3400_TAHSIL_HESAP_BOLUM       := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_HESAP_BOLUM');
    p_3400_GELIR_SUBE               := pkg_muhasebe.parametre_index_bul('3400_GELIR_SUBE');
    p_3400_TAHSIL_HESAP_NO           := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_HESAP_NO');
    p_3400_TAHSIL_HESAP_DVZ           := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_HESAP_DVZ');
    p_3400_ILISKILI_HESAP_DK       := pkg_muhasebe.parametre_index_bul('3400_ILISKILI_HESAP_DK');
    p_3400_TAHSIL_TUTARI           := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_TUTARI');
    p_3400_TAHSIL_TUTARI_LC           := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_TUTARI_LC');
    p_3400_TOPLAM_TUTAR               := pkg_muhasebe.parametre_index_bul('3400_TOPLAM_TUTAR');
    p_3400_TOPLAM_TUTAR_LC           := pkg_muhasebe.parametre_index_bul('3400_TOPLAM_TUTAR_LC');
    p_3400_TAH_DVZ_TRY               := pkg_muhasebe.parametre_index_bul('3400_TAH_DVZ_TRY');
    p_3400_TAH_DVZ_YP               := pkg_muhasebe.parametre_index_bul('3400_TAH_DVZ_YP');
    p_3400_ILISKILI_HESAP_VAR       := pkg_muhasebe.parametre_index_bul('3400_ILISKILI_HESAP_VAR');
    p_3400_MAS_DVZ_YP               := pkg_muhasebe.parametre_index_bul('3400_MAS_DVZ_YP');
    p_3400_MAS_DVZ_TRY               := pkg_muhasebe.parametre_index_bul('3400_MAS_DVZ_TRY');
    p_3400_ILISKILI_HESAP_YOK       := pkg_muhasebe.parametre_index_bul('3400_ILISKILI_HESAP_YOK');
    p_3400_MASRAF_DK                := pkg_muhasebe.parametre_index_bul('3400_MASRAF_DK');
    p_3400_TAX_DK                       := pkg_muhasebe.parametre_index_bul('3400_TAX_DK');
    p_3400_TAX_VAR                   := pkg_muhasebe.parametre_index_bul('3400_TAX_VAR');
    p_3400_TAX_YOK                   := pkg_muhasebe.parametre_index_bul('3400_TAX_YOK');
    p_3400_TAX_DEDUCTED               := pkg_muhasebe.parametre_index_bul('3400_TAX_DEDUCTED');
    p_3400_TAX_PAID                   := pkg_muhasebe.parametre_index_bul('3400_TAX_PAID');
    p_3400_TAX_AMOUNT               := pkg_muhasebe.parametre_index_bul('3400_TAX_AMOUNT');
    p_3400_TAX_AMOUNT_LC           := pkg_muhasebe.parametre_index_bul('3400_TAX_AMOUNT_LC');
    p_3400_SERVICE_TAX_AMOUNT       := pkg_muhasebe.parametre_index_bul('3400_SERVICE_TAX_AMOUNT');
    p_3400_VAT_AMOUNT               := pkg_muhasebe.parametre_index_bul('3400_VAT_AMOUNT');
    p_3400_SERVICE_TAX_AMOUNT_LC   := pkg_muhasebe.parametre_index_bul('3400_SERVICE_TAX_AMOUNT_LC');
    p_3400_VAT_AMOUNT_LC           := pkg_muhasebe.parametre_index_bul('3400_VAT_AMOUNT_LC');
    p_3400_NET_COMM                   := pkg_muhasebe.parametre_index_bul('3400_NET_COMM');
    p_3400_NET_COMM_LC               := pkg_muhasebe.parametre_index_bul('3400_NET_COMM_LC');
    p_3400_TUR                        := pkg_muhasebe.parametre_index_bul('3400_TUR');
    p_3400_ACC_TYPE                := pkg_muhasebe.parametre_index_bul('3400_ACC_TYPE');
    p_3400_CUS_ACC_NO                := pkg_muhasebe.parametre_index_bul('3400_CUS_ACC_NO');
    p_3400_CASH_CODE                := pkg_muhasebe.parametre_index_bul('3400_CASH_CODE');

    p_3400_TAHSIL_TUTARI_R                := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_TUTARI_R');
    p_3400_TAHSIL_TUTARI_A_R            := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_TUTARI_A_R');
    p_3400_TAHSIL_TUTARI_B_R            := pkg_muhasebe.parametre_index_bul('3400_TAHSIL_TUTARI_B_R');
    p_3400_NET_COMM_LC_R                := pkg_muhasebe.parametre_index_bul('3400_NET_COMM_LC_R');
    p_3400_NET_COMM_LC_A_R                := pkg_muhasebe.parametre_index_bul('3400_NET_COMM_LC_A_R');
    p_3400_NET_COMM_LC_B_R                := pkg_muhasebe.parametre_index_bul('3400_NET_COMM_LC_B_R');
    p_3400_TAX_AMOUNT_LC_R           := pkg_muhasebe.parametre_index_bul('3400_TAX_AMOUNT_LC_R');
    p_3400_TAX_AMOUNT_LC_A_R           := pkg_muhasebe.parametre_index_bul('3400_TAX_AMOUNT_LC_A_R');
    p_3400_TAX_AMOUNT_LC_B_R           := pkg_muhasebe.parametre_index_bul('3400_TAX_AMOUNT_LC_B_R');
END;
/

