create PACKAGE PKG_TX1801 IS

/******************************************************************************
   Name       : PKG_TX1801
   Created By : Seval Balci
   Date    	  : 01.10.04
   Purpose	  : Vadeli Faiz Oran Rezervasyon Toplu Onay?
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure	Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );

  Procedure sorgu_isleme_at(pn_islem_no 	   number,
  							ps_sube_kodu 	   varchar2,
  							pn_musteri_no 	   number,
							ps_doviz 	  	   varchar2,
							pn_tutar1    number,
							pn_tutar2    number);
procedure sp_temizle (pn_islem_no number);
Function sf_bitmemis_islem_varmi(pn_islem_no number ,pn_internal_no number default null)  return number;
Procedure rezervasyon_durum_uygunmu(pn_islem_no number);
END;


/

