create PACKAGE BODY     PKG_TX1111 IS
	pn_1111_alacak_hesap_sube_kodu  number;
	pn_1111_alacak_hesap_no         number;
	pn_1111_istatistik_kod          number;
	pn_1111_doviz_kodu        	    number;
	pn_1111_lc_tutar          	    number;
	pn_1111_fc_tutar        	    number;
	pn_1111_banka_aciklama          number;
	pn_1111_hesap_sube_kodu         number;
	pn_1111_hesap_no        	    number;
	pn_1111_bloke_hesap_sube_kodu   number;
	pn_1111_bloke_hesap_no          number;
	pn_1111_musteri_aciklama        number;
	pn_1111_cek_referans        	number;
	pn_1111_fis_aciklama        	number;
	pn_1111_kur_lc        			number;
	pn_1111_bloke_hesap_var			number;
	pn_1111_bloke_hesap_yok			number;
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_musteri_no 	 		    number := 0;
  ld_banka_tarihi    			date ;
  ld_teslim_tarihi   			date ;
  ld_keside_tarihi   			date ;
  ln_cek_no		 	 	   	    cbs_cek.cek_no%type;
  ln_cek_tutari	 				cbs_cek.cek_tutari%type;
  ls_durum_kodu	 				cbs_cek.durum_kodu%type;
  ls_cek_islemdurum				cbs_cek.durum_kodu%type;
  ls_istatistik_islem_tanim_kod	cbs_cek.istatistik_islem_tanim_kod%type;
  ln_alacak_musteri_no			cbs_cek.alacak_musteri_no%type;
  ln_alacak_hesap_no			cbs_cek.alacak_hesap_no%type;
  ls_ibraz_edilen_sube			cbs_cek.ibraz_edilen_sube%type;
  ls_aciklama					cbs_cek.aciklama%type;
  ls_dekont_basim_f    			cbs_cek.dekont_basim_f%type;
  onceden_odeme_yapilmis 		exception;
  durumu_aktif_degil     		exception;
  teslim_iptal_edilmis   		exception;

  ls_unvan						varchar2(2000);
  ls_adres						cbs_musteri_adres.ADRES%type;
  ls_semt						cbs_musteri_adres.semt%type;
  ls_il_kod						cbs_musteri_adres.il_kod%type;
  ln_posta_kod					cbs_musteri_adres.posta_kod%type;
  ls_ulke_kod					cbs_musteri_adres.ulke_kod%type;
  Begin

  ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;

 /* cek islemden cek tablosunun g?ncellenecek alanlar?n?n bilgileri getirilir.*/
    select cek_no,cek_tutari,keside_tarihi,istatistik_islem_tanim_kod,
		   alacak_musteri_no,alacak_hesap_no,aciklama,dekont_basim_f ,durum_kodu
	into   ln_cek_no, ln_cek_tutari,ld_keside_tarihi,ls_istatistik_islem_tanim_kod,
		   ln_alacak_musteri_no,ln_alacak_hesap_no,ls_aciklama,ls_dekont_basim_f ,ls_cek_islemdurum
	from   cbs_cek_islem
    where  tx_no = pn_islem_no;

 /* islemi yapan sube ibraz edilen subedir.*/
	select amir_bolum_kodu
	into   ls_ibraz_edilen_sube
	from   cbs_islem
    where  numara = pn_islem_no;

/*cekin durumu hala aktif olup olmad??? kontrol edileceginden o anki durumu alinir. */
	select  durum_kodu,teslim_tarihi
	into 	ls_durum_kodu ,ld_teslim_tarihi
	from 	cbs_cek
	where   cek_no   = ln_cek_no;

  if ls_durum_kodu in ('A','B','K')  and ld_teslim_tarihi is not null then
  /* alacak musterisinin unvan bilgisi al?n?r*/
   ls_unvan := Pkg_Musteri. Sf_Musteri_Adi(ln_alacak_musteri_no);

  /* alacak musterisinin adres bilgileri al?n?r ,cek hamili g?ncellenir*/
   Pkg_Musteri.Sp_Musteri_Adres(ln_alacak_musteri_no, ls_adres,ls_semt,ls_il_kod,ln_posta_kod ,ls_ulke_kod);
  /* cek'in bloke kodu ,bloke tarihi ve tutar? guncellenir. */
	   update  cbs_cek
	   set     cek_tutari = ln_cek_tutari,
	   		   keside_tarihi = ld_keside_tarihi ,
	   		   ibraz_tarihi =ld_banka_tarihi,
			   ibraz_edilen_sube = ls_ibraz_edilen_sube,
			   istatistik_islem_tanim_kod =ls_istatistik_islem_tanim_kod,
			   alacak_musteri_no=ln_alacak_musteri_no,
			   alacak_hesap_no=ln_alacak_hesap_no,
			   aciklama = ls_aciklama,
			   dekont_basim_f = ls_dekont_basim_f,
	   		   durum_kodu = ls_cek_islemdurum,
			   cek_hamili_unvan = ls_unvan,
 			   cek_hamili_adres = ls_adres,
			   cek_hamili_semt  = ls_semt,
			   cek_hamili_il_kod = ls_il_kod,
			   cek_hamili_posta_kod = ln_posta_kod,
   			   cek_hamili_ulke_kod = ls_ulke_kod
      where   cek_no = ln_cek_no;

  else
  	  if ld_teslim_tarihi is null then
	     raise teslim_iptal_edilmis ;
	  else
	   	  if ls_durum_kodu in('BO','KO','O') then
	  	  	 raise  onceden_odeme_yapilmis;
	   	 else
	   	 	 raise durumu_aktif_degil;
	  	 end if;
	  end if;
  end if;

  Exception
   	 When teslim_iptal_edilmis then
	 	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '416' ||pkg_hata.getUCPOINTER);
  	 When onceden_odeme_yapilmis then
	 	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '417' ||  pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter||pkg_hata.getUCPOINTER);
  	 When durumu_aktif_degil then
    	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '418' ||  pkg_hata.getDelimiter || ls_durum_kodu ||pkg_hata.getDelimiter||  pkg_hata.getUCPOINTER);
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '419' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
    ln_cek_no     cbs_cek.cek_no%type;
	ls_durum_kodu varchar2(2);

  Begin

   /* cek numarasi alinir */
   	   select cek_no,
	   		  decode(durum_kodu,'O','A','KO','K','BO','B','A')
	   into ln_cek_no ,
	   		ls_durum_kodu
	   from cbs_cek_islem
	   where tx_no = pn_islem_no;


   /* cek islem keside tarihi ve durum kodu onaylandi koduna A'ya  guncellenir. */
	   update  cbs_cek_islem
	   set     durum_kodu = 'I'
	   where   tx_no = pn_islem_no;
  /* cek'in bloke kodu ,bloke tarihi ve tutar? guncellenir. */
	   update  cbs_cek
	   set     cek_tutari =  decode(durum_kodu,'KO',cek_tutari,null),
	   		   keside_tarihi = decode(durum_kodu,'KO',keside_tarihi,null),
	   		   ibraz_tarihi = null,
			   ibraz_edilen_sube =null,
			   istatistik_islem_tanim_kod = null,
			   alacak_musteri_no= null,
			   alacak_hesap_no= null,
			   aciklama = null,
			   dekont_basim_f = null,
	   		   durum_kodu = ls_durum_kodu,
   			   cek_hamili_unvan = null,
 			   cek_hamili_adres = null,
			   cek_hamili_semt  = null,
			   cek_hamili_il_kod = null,
			   cek_hamili_posta_kod = null,
			   cek_hamili_ulke_kod = null
	   where   cek_no = ln_cek_no;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '419' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin

 	/* Red edildi */
    update cbs_cek_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;

	ln_fis_no				   cbs_fis.numara%type ;
	ls_islem_kod               cbs_islem.islem_kod%type :='1111';
	ls_musteri_aciklama         varchar2(2000);
	ls_banka_aciklama           varchar2(2000);
	ln_musteri_no			    cbs_musteri.musteri_no%TYPE;
	ln_hesap_no		   		    cbs_cek.hesap_no%TYPE;
    ls_hesap_sube_kodu          cbs_cek.hesap_sube_kodu%TYPE;
	ln_bloke_hesap_no		    cbs_cek.hesap_no%TYPE;
	ls_bloke_hesap_sube_kodu    cbs_cek.hesap_sube_kodu%TYPE;
    ln_alacak_hesap_no	    	cbs_cek.hesap_no%TYPE;
	ls_alacak_hesap_sube_kodu   cbs_cek.hesap_sube_kodu%TYPE;
	ln_tutar			   	    cbs_cek.cek_tutari%TYPE;
	ls_fis_aciklama			    cbs_fis.aciklama%type;
	ls_doviz_kodu			    cbs_cek.doviz_kodu%type;
	ln_istatistik_kod			 cbs_cek.istatistik_islem_tanim_kod%type;

	cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
	   	select musteri_no,
			   hesap_no,
			   nvl(hesap_sube_kodu,Pkg_Hesap.HesaptanSubeAl(hesap_no)),
   			   Decode( cek_bloke_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(cek_bloke_hesap_no) ),
			   cek_bloke_hesap_no,
   			   Decode( alacak_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(alacak_hesap_no) ),
			   alacak_hesap_no ,
			   doviz_kodu,
			   cek_tutari ,
			   aciklama ,
			   istatistik_islem_tanim_kod
			from cbs_cek_islem
			where   tx_no=pn_islemno;

  Begin

/* islem bilgisi detaylari alinir */
  	   open islem_cursor(pn_islem_no);
	    fetch islem_cursor into ln_musteri_no,ln_hesap_no,ls_hesap_sube_kodu,ls_bloke_hesap_sube_kodu,ln_bloke_hesap_no,
		   		 			  	ls_alacak_hesap_sube_kodu,ln_alacak_hesap_no,ls_doviz_kodu,ln_tutar ,ls_banka_aciklama ,ln_istatistik_kod;
		   if islem_cursor%notfound then
	          close islem_cursor;
	       end if;
		  close islem_cursor;

/*** Liste Deger Atama K?sm? **/
    boolean_list(pn_1111_bloke_hesap_var)       := false;
    boolean_list(pn_1111_bloke_hesap_yok)       := false;

/* bloke hesap durumuna g?re atam */
  if nvl(ln_bloke_hesap_no,0) = 0 then
	 boolean_list(pn_1111_bloke_hesap_yok) :=true;
   else
  	 boolean_list(pn_1111_bloke_hesap_var) :=true;
  end if;

/**** varchar list ****/

   pkg_parametre.deger('1111_FIS_ACIKLAMA',ls_fis_aciklama);
--   pkg_parametre.deger('1111_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   varchar_list(pn_1111_fis_aciklama) 	 := ls_fis_aciklama ;
   varchar_list(pn_1111_banka_aciklama)  := ls_banka_aciklama;
   varchar_list(pn_1111_musteri_aciklama):= ls_banka_aciklama; --ls_musteri_aciklama;
   varchar_list(pn_1111_cek_referans) 	 := to_char(ln_hesap_no);
   varchar_list(pn_1111_hesap_sube_kodu) := ls_hesap_sube_kodu;
   varchar_list(pn_1111_hesap_no) 		 := to_char(ln_hesap_no);
   varchar_list(pn_1111_doviz_kodu)		 	   := ls_doviz_kodu;
   varchar_list(pn_1111_bloke_hesap_sube_kodu) := ls_bloke_hesap_sube_kodu;
   varchar_list(pn_1111_bloke_hesap_no)        := to_char(ln_bloke_hesap_no);
   varchar_list(pn_1111_alacak_hesap_sube_kodu):= ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1111_alacak_hesap_no)       := to_char(ln_alacak_hesap_no);
   varchar_list(pn_1111_istatistik_kod)       := to_char(ln_istatistik_kod);


/**** number list ****/
  if ls_doviz_kodu = pkg_genel.lc_al then
     number_list(pn_1111_fc_tutar):=ln_tutar ;
	 number_list(pn_1111_lc_tutar):=ln_tutar ;
  else
     number_list(pn_1111_fc_tutar):=ln_tutar ;
     number_list(pn_1111_lc_tutar):= pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.lc_al,null,ln_tutar,1,null,null,'N','A');
  end if;

  number_list(pn_1111_kur_lc):= pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A');




/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							null,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							0,
							ls_fis_aciklama);


	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '420' || pkg_hata.getDelimiter || to_char(SQLCODE) || SQLERRM || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

Begin
/* parametre index numaralar? bulunur.*/
	pn_1111_alacak_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1111_ALACAK_HESAP_SUBE_KODU');
	pn_1111_alacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1111_ALACAK_HESAP_NO');
	pn_1111_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1111_ISTATISTIK_KOD');
	pn_1111_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1111_DOVIZ_KODU');
	pn_1111_lc_tutar :=pkg_muhasebe.parametre_index_bul('1111_LC_TUTAR');
	pn_1111_fc_tutar :=pkg_muhasebe.parametre_index_bul('1111_FC_TUTAR');
	pn_1111_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1111_BANKA_ACIKLAMA');
	pn_1111_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1111_HESAP_SUBE_KODU');
	pn_1111_hesap_no :=pkg_muhasebe.parametre_index_bul('1111_HESAP_NO');
	pn_1111_bloke_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1111_BLOKE_HESAP_SUBE_KODU');
	pn_1111_bloke_hesap_no :=pkg_muhasebe.parametre_index_bul('1111_BLOKE_HESAP_NO');
	pn_1111_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1111_MUSTERI_ACIKLAMA');
	pn_1111_cek_referans :=pkg_muhasebe.parametre_index_bul('1111_CEK_REFERANS');
	pn_1111_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1111_FIS_ACIKLAMA');
	pn_1111_kur_lc :=pkg_muhasebe.parametre_index_bul('1111_KUR_LC');
	pn_1111_bloke_hesap_var :=pkg_muhasebe.parametre_index_bul('1111_BLOKE_HESAP_VAR');
	pn_1111_bloke_hesap_yok :=pkg_muhasebe.parametre_index_bul('1111_BLOKE_HESAP_YOK');
END ;
/

