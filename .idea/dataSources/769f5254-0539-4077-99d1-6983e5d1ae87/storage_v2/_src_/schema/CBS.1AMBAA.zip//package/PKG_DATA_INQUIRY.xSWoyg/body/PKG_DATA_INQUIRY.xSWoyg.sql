create PACKAGE BODY     PKG_DATA_INQUIRY IS

/******************************************************************************
NAME        : FUNCTION GetUAEPaymentCodesByOption
Prepared By : Bakdoolot Keldibekova
Date        : 28.12.2021
Purpose     : get payment codes for UAE - IBC-52
******************************************************************************/
FUNCTION GetUAEPaymentCodesByOption(ps_option IN VARCHAR2,ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
    
      IF (ps_option='SWIFT') THEN
        OPEN pc_ref FOR
        SELECT STAT_CODE, decode(ps_langcd, 'ENG', SUBSTR(code_name,1,70),  SUBSTR(code_name_rus,1,70)) as code_name
        FROM cbs_swift_codes_uae_cib
        WHERE STAT_CODE IS NOT NULL
        ORDER BY code_id;
      ELSIF (ps_option='SWIFT_CORP') THEN
  	log_at('hgbjahb');
        OPEN pc_ref FOR
        SELECT code_id, '- '||UPPER(TRIM(decode(ps_langcd, 'ENG', code_name,  code_name_rus)))
        FROM cbs_swift_codes_uae_cib
        WHERE parent_id IS NULL
        ORDER BY code_id;
      END IF;
   RETURN ls_returncode;
END;

/*******************************************************************************
Name        : FUNCTION getUAEPaymentCodesCIB
Prepared By : Bakdoolot Keldibekova
Date        : 28.12.2021
Purpose     : get the UAE payment codes for Corp IB - IBC-52
*******************************************************************************/
FUNCTION getUAEPaymentCodesCIB(pn_group_code NUMBER, ps_lang VARCHAR2, pc_ref OUT CursorReferenceType)  RETURN VARCHAR2
    IS
    ls_returncode       VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT code_id || DECODE(stat_code, NULL, '', '#'||stat_code || '#' ||DECODE(UPPER(TRIM(ps_lang)), 'ENG', code_name, code_name_rus) ||'#' ||code_name), stat_code, DECODE(UPPER(TRIM(ps_lang)), 'ENG', code_name, code_name_rus)
        FROM cbs_swift_codes_uae_cib
        WHERE parent_id = pn_group_code;

    RETURN ls_returncode;

EXCEPTION
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT ' ', ' ', ' '  FROM DUAL;
            log_at('swiftcib pkg_data_inquiry.getUAEPaymentCodesCIB', 'Error pn_group_code='||pn_group_code||' ps_lang=' || ps_lang, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN  '999';
END;

/*******************************************************************************
    Name        : FUNCTION getAllCustomer
    Prepared By : Omurchiev Esen
    Date:       : 25.02.2022
    Base Project: Combined access to Internet (MB or IB)-Banking for retail
                                        customers and private entrepreneurs
    Purpose     : Get private and retail customers
*******************************************************************************/
FUNCTION  getAllCustomers(pn_customer_no in varchar2,
                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
    ls_returncode varchar2(3):='000';

    ls_is_resident VARCHAR2(1);
    ls_inn VARCHAR2(20);
    ls_date_of_birth DATE;
    ls_passport_no VARCHAR2(20);
    ls_gender_code VARCHAR2(2);

BEGIN

log_at('getAllCustomers testproba');
    OPEN pc_ref FOR SELECT '-' FROM dual;

    SELECT YERLESIM_KOD, VERGI_NO , DOGUM_TARIHI, PASAPORT_NO, CINSIYET_KOD into ls_is_resident , ls_inn, ls_date_of_birth, ls_passport_no, ls_gender_code FROM  CBS_MUSTERI   WHERE  musteri_no = to_number(pn_customer_no);

    if ls_is_resident = '1' then

       log_at('getAllCustomers 1',ls_is_resident || '|' || ls_inn  || '|' || ls_date_of_birth  || '|' || ls_passport_no  || '|' || ls_gender_code);

       OPEN pc_ref FOR

       SELECT musteri_no FROM  CBS_MUSTERI   WHERE VERGI_NO = ls_inn and DOGUM_TARIHI = ls_date_of_birth;

    else
       log_at('getAllCustomers 2',ls_is_resident || '|' || ls_inn  || '|' || ls_date_of_birth  || '|' || ls_passport_no  || '|' || ls_gender_code);

       OPEN pc_ref FOR

       SELECT musteri_no FROM  CBS_MUSTERI  WHERE  DOGUM_TARIHI = ls_date_of_birth and PASAPORT_NO = ls_passport_no and CINSIYET_KOD = ls_gender_code;

    end if;

    RETURN ls_returncode ;

EXCEPTION
  WHEN NO_DATA_FOUND THEN RETURN NULL;
    WHEN OTHERS THEN
     log_at('ibservice','getAllCustomers', sqlerrm, dbms_utility.format_error_backtrace);
     raise_application_error(-20100,sqlerrm);
     OPEN pc_ref FOR SELECT '-' FROM dual;
     return '999';
END;

/*******************************************************************************
Name        : FUNCTION getOrdoNameByAccNo
Prepared By : Bakdoolot Keldibekova
Date        : 16.03.2022
Purpose     : get the ORDO fullname by account number for MB and IB - IB-40
*******************************************************************************/
FUNCTION getOrdoNameByAccNo(pn_personal_acc VARCHAR2, pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 IS
    ln_name_count NUMBER;
    notFoundName   EXCEPTION;
BEGIN
    SELECT COUNT(*) INTO ln_name_count from CORPINT2.TBL_PAYMENT_ORDO p
    WHERE p.PERSONAL_ACC = pn_personal_acc;

    IF ln_name_count != 1 THEN
        RAISE notFoundName;
    end if;

    OPEN pc_ref FOR
        SELECT FULL_NAME FROM CORPINT2.TBL_PAYMENT_ORDO p
        WHERE p.PERSONAL_ACC = pn_personal_acc;

    RETURN '000';

EXCEPTION
    WHEN notFoundName THEN
        log_at('getOrdoNameByAccNo','notFoundName', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     return '505';
    WHEN OTHERS THEN
        log_at('getOrdoNameByAccNo','OTHERS', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     return '999';
END;
/*******************************************************************************
Name        : FUNCTION getBravoNameByAccNo
Prepared By : Bakdoolot Keldibekova
Date        : 16.03.2022
Purpose     : get the BRAVO fullname by account number for MB and IB - IB-40
*******************************************************************************/
FUNCTION getBravoNameByAccNo(pn_personal_acc VARCHAR2, pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 IS
    ln_name_count NUMBER;
    notFoundName   EXCEPTION;
BEGIN
    SELECT COUNT(*) INTO ln_name_count from CORPINT2.TBL_PAYMENT_BRAVO p
    WHERE p.PERSONAL_ACC = pn_personal_acc;

    IF ln_name_count != 1 THEN
        RAISE notFoundName;
    end if;

    OPEN pc_ref FOR
        SELECT FULL_NAME FROM CORPINT2.TBL_PAYMENT_BRAVO p
        WHERE p.PERSONAL_ACC = pn_personal_acc;

    RETURN '000';

EXCEPTION
    WHEN notFoundName THEN
        log_at('getBravoNameByAccNo','notFoundName', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     return '505';
    WHEN OTHERS THEN
        log_at('getBravoNameByAccNo','OTHERS', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     return '999';
END;

/******************************************************************************
NAME        : FUNCTION GetLoanAccount
Prepared By : Filipp Krupnov
Date        : 26.04.2022
Purpose     : Get Loan Account for MB-248
******************************************************************************/
FUNCTION GetLoanAccount(pn_CustomerId IN VARCHAR2,
                        pn_DurumKodu IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';
    ln_count       NUMBER;
    noLoanAccoutFound        EXCEPTION;
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

if (pn_DurumKodu = 'ALL') THEN

    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_VW_KREDI_HESAP_IZLEME
        WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu in ('A', 'K')
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL') --Added FilippK MB-27.09.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' 
          AND ANA_KREDI_HESAP_NO is null;

    IF (ln_count= 0) THEN
        RAISE noLoanAccoutFound;
    END IF;

    OPEN pc_ref FOR
        SELECT 'Cash Credits' modul_tur_kod, MUSTERI_NO, sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE, TO_CHAR(ACILIS_TARIHI ,'YYYYMMDD') ACILIS_TARIHI, TO_CHAR(ACILIS_KREDI_VADE ,'YYYYMMDD') "VADE_TARIHI", HESAP_NO, DURUM_KODU,
               DOVIZ_KODU, NVL(TAKSIT_ANAPARA_TOPLAMI,0) "AMOUNT_TOTAL", NVL(BAKIYE,0), YEARLY_INT_RATE --ACILIS_TUTAR
        FROM CBS_VW_KREDI_HESAP_IZLEME
        WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu in ('A', 'K')
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL') --Added FilippK MB-27.09.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E'
          AND ANA_KREDI_HESAP_NO is null;
    ELSE
        SELECT COUNT(*)
        INTO ln_count
        FROM CBS_vw_hesap_izleme
        WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu = 'A'
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD') --Added FilippK MB-417 29.08.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

        IF (ln_count= 0) THEN
            RAISE noLoanAccoutFound;
        END IF;

        OPEN pc_ref FOR
            SELECT 'Cash Credits' modul_tur_kod, MUSTERI_NO, ISIM_UNVAN, sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE, HESAP_NO,
                   DOVIZ_KODU, NVL(BAKIYE,0), NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye, 3 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, TO_CHAR(ACILIS_TARIHI ,'YYYYMMDD') ACILIS_TARIHI, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2)
            FROM CBS_vw_hesap_izleme
            WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                                connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
              AND durum_kodu = 'A'
              AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD') --Added FilippK MB-417 29.08.2022
              AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
              AND modul_tur_kod= 'LOAN'
              AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN noLoanAccoutFound THEN
        ls_returncode:= '058';
        RETURN ls_returncode;
    WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;
/******************************************************************************
NAME        : FUNCTION GetElcardAccount
Prepared By : Filipp Krupnov
Date        : 31.05.2022
Purpose     : Retrieve Elcard account data via MB/IB for MB-279
******************************************************************************/
FUNCTION GetElcardAccount(pn_customer_no VARCHAR2, pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 IS
    ln_account_no NUMBER;
    notFoundName   EXCEPTION;
BEGIN
    SELECT COUNT(*) INTO ln_account_no from cbs_hesap p
    WHERE p.musteri_no = pn_customer_no
      AND p.doviz_kodu = 'KGS'
      AND p.urun_sinif_kod ='ELCARD NON INT.BR-LC'
      AND p.durum_kodu='A';

    IF ln_account_no != 1 THEN
        RAISE notFoundName;
    end if;

    OPEN pc_ref FOR
        SELECT HESAP_NO, EXTERNAL_HESAP_NO FROM cbs_hesap p--added filippK 09.06.2022
        WHERE p.musteri_no = pn_customer_no
          AND p.doviz_kodu = 'KGS'
          AND p.urun_sinif_kod ='ELCARD NON INT.BR-LC'
          AND p.durum_kodu='A';

    RETURN '000';

EXCEPTION
    WHEN notFoundName THEN
        log_at('getBravoNameByAccNo','notFoundName', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '505';
    WHEN OTHERS THEN
        log_at('getBravoNameByAccNo','OTHERS', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
END;
/******************************************************************************
NAME        : FUNCTION SwiftBankInfoRu
Date        : 16.06.2022
Purpose     : Swift Bank Info for RU
******************************************************************************/
FUNCTION SwiftBankInfoRu(ps_bankcountry  IN VARCHAR2,
                       ps_bankcity     IN VARCHAR2,
                       ps_bankname     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS
ls_sqlstr        VARCHAR2(2000);
ln_count         NUMBER;
ls_returncode     VARCHAR2(3):='000';
NoBankFound      EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_BIC_KODLARI
    WHERE BIC_ULKE_KODU=ps_bankcountry
      AND LENGTH(ULKE_ADI)>0
      AND SUBSTR(BIC_KODU, 8,1) <> '1'
      AND BIC_SUBE_KODU='XXX';

        IF ln_count=0 THEN
           RAISE NoBankFound;
        END IF;

        OPEN pc_ref FOR
         SELECT BIC_KODU, BIC_SUBE_KODU, BANKA_ADI, NVL(SUBE_ADI,'(HEAD OFFICE)'), SEHIR_ADI,
                ALTTIP_ISARETI, DEGER_EKLI_SRV, EK_BILGI, LOKASYON, ULKE_ADI,
                POB_NUMARASI, POB_LOKASYON, POB_ULKE_ADI, BIC_BANKA_KODU,
                BIC_ULKE_KODU, BIC_SEHIR_KODU, COUNTRY_NAME, ADRES_1,
                ADRES_2, ADRES_3, ADRES_4, ADRES_5, ACIKLAMA2,rr.DESCRIPTION, rr.BANK_NAME
           FROM CBS_BIC_KODLARI
           INNER JOIN CBS.CBS_BIC_CODES_RU rr ON rr.BIC_CODE = BIC_KODU
          WHERE BIC_ULKE_KODU=ps_bankcountry
            AND LENGTH(ULKE_ADI)>0
            AND BIC_SUBE_KODU='XXX'
            AND SUBSTR(BIC_KODU, 8,1) <> '1'
            AND rr.ACTIVE = 1
            ORDER BY BIC_KODU;

    RETURN ls_returncode;
EXCEPTION
    WHEN NoBankFound THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetCurrencyTXCodes
   Date        : 17.06.2022
   Purpose     : Get Currency TX Codes
******************************************************************************/
FUNCTION GetCurrencyTXCodes(ps_option IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode          VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR
        SELECT CODE, NAME_RUS
       FROM CBS_CURRENCY_TX_CODES
      	ORDER BY CODE;

     RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION Swift_Character_Cannotstart
   Prepared By : Bakdoolot Keldibekova
   Date        :  27.06.2022, ibc-110/ib-177
   Purpose     : Line cannot start with a specific character
******************************************************************************/
FUNCTION Swift_Character_Cannotstart(ps_string VARCHAR2, ps_symbol VARCHAR2) RETURN VARCHAR2
IS
   ls_return VARCHAR2(2000);
   ls_symbol VARCHAR2(10);
   idx NUMBER := 1;
BEGIN
    ls_return := ps_string;
    ls_symbol := ps_symbol;

    WHILE COALESCE(LENGTH(ls_return), 0)>=idx and SUBSTR(ls_return, idx, 1)=ls_symbol LOOP
        idx := idx + 1;
    END LOOP;

    ls_return := SUBSTR(ls_return, idx, LENGTH(ls_return));

    RETURN ls_return;

    EXCEPTION
        WHEN OTHERS THEN
            Log_At('swiftcib CBS.pkg_data_inquiry.Swift_Character_Cannotstart',SQLCODE||':'||SQLERRM, ps_string);
            return ps_string;
END;

/******************************************************************************
NAME        : FUNCTION SwiftBankInfoKz
Date        : 15.07.2022
Purpose     : Swift Bank Info for KZ
******************************************************************************/
FUNCTION SwiftBankInfoKz(ps_bankcountry  IN VARCHAR2,
                       ps_bankcity     IN VARCHAR2,
                       ps_bankname     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS
ls_sqlstr        VARCHAR2(2000);
ln_count         NUMBER;
ls_returncode     VARCHAR2(3):='000';
NoBankFound      EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_BIC_KODLARI
    WHERE BIC_ULKE_KODU=ps_bankcountry
      AND LENGTH(ULKE_ADI)>0
      AND SUBSTR(BIC_KODU, 8,1) <> '1'
      AND BIC_SUBE_KODU='XXX';

        IF ln_count=0 THEN
           RAISE NoBankFound;
        END IF;

        OPEN pc_ref FOR
         SELECT BIC_KODU, BIC_SUBE_KODU, BANKA_ADI, NVL(SUBE_ADI,'(HEAD OFFICE)'), SEHIR_ADI,
                ALTTIP_ISARETI, DEGER_EKLI_SRV, EK_BILGI, LOKASYON, ULKE_ADI,
                POB_NUMARASI, POB_LOKASYON, POB_ULKE_ADI, BIC_BANKA_KODU,
                BIC_ULKE_KODU, BIC_SEHIR_KODU, COUNTRY_NAME, ADRES_1,
                ADRES_2, ADRES_3, ADRES_4, ADRES_5, ACIKLAMA2
           FROM CBS_BIC_KODLARI
           INNER JOIN CBS.CBS_BIC_CODES_KZ rr ON rr.BIC_CODE = BIC_KODU
          WHERE BIC_ULKE_KODU=ps_bankcountry
            AND LENGTH(ULKE_ADI)>0
            AND BIC_SUBE_KODU='XXX'
            AND SUBSTR(BIC_KODU, 8,1) <> '1'
            AND rr.ACTIVE = 1
            ORDER BY BIC_KODU;

    RETURN ls_returncode;
EXCEPTION
    WHEN NoBankFound THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;


/******************************************************************************
NAME        : FUNCTION GetLoanAccount2.0
Prepared By : Filipp Krupnov
Date        : 05.09.2022
Purpose     : Get Loan Account for MB-248
******************************************************************************/
FUNCTION GetLoanAccount1(pn_CustomerId IN VARCHAR2,
                        pn_DurumKodu IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode  VARCHAR2(3):='000';
    ln_count       NUMBER;
    noLoanAccoutFound        EXCEPTION;
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

if (pn_DurumKodu = 'ALL') THEN

    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_VW_KREDI_HESAP_IZLEME
    WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu in ('A', 'K')
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL') --Added FilippK MB-417 29.08.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

    IF (ln_count= 0) THEN
        RAISE noLoanAccoutFound;
    END IF;

    OPEN pc_ref FOR
        SELECT 'Cash Credits' modul_tur_kod, MUSTERI_NO, sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE, TO_CHAR(ACILIS_TARIHI ,'YYYYMMDD') ACILIS_TARIHI, TO_CHAR(ACILIS_KREDI_VADE ,'YYYYMMDD') "VADE_TARIHI", HESAP_NO, DURUM_KODU,
               DOVIZ_KODU, NVL(ACILIS_TUTAR,0) "AMOUNT_TOTAL", NVL(BAKIYE,0), YEARLY_INT_RATE 
        FROM CBS_VW_KREDI_HESAP_IZLEME
        WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu in ('A', 'K')
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL') --Added FilippK MB-417 29.08.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';
          
    ELSE
        SELECT COUNT(*)
        INTO ln_count
        FROM CBS_vw_hesap_izleme
        WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                            connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
          AND durum_kodu = 'A'
          AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD') --Added FilippK MB-417 29.08.2022
          AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
          AND modul_tur_kod= 'LOAN'
          AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

        IF (ln_count= 0) THEN
            RAISE noLoanAccoutFound;
        END IF;

        OPEN pc_ref FOR
            SELECT 'Cash Credits' modul_tur_kod, MUSTERI_NO, ISIM_UNVAN, sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE, HESAP_NO,
                   DOVIZ_KODU, NVL(BAKIYE,0), NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye, 3 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, TO_CHAR(ACILIS_TARIHI ,'YYYYMMDD') ACILIS_TARIHI, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2)
            FROM CBS_vw_hesap_izleme
            WHERE musteri_no in(select trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level ) )from dual
                                connect by trim(regexp_substr(pn_CustomerId, '[^,]+', 1, level )) is not null)
              AND durum_kodu = 'A'
              AND urun_tur_kod NOT IN ('LEASING', 'RT-CARD', 'PD-CARD') --Added FilippK MB-417 29.08.2022
              AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
              AND modul_tur_kod= 'LOAN'
              AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN noLoanAccoutFound THEN
        ls_returncode:= '058';
        RETURN ls_returncode;
    WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;

/******************************************************************************
NAME        : FUNCTION getQrInfoByCustomerNo
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : getQrInfoByCustomerNo
******************************************************************************/
FUNCTION getQrInfoByCustomerNo(ps_customer_no IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  ln_count       NUMBER;
  BEGIN
        select count(*) into ln_count 
        from CBS.CBS_QR_MERCHANTS 
        where CUSTOMER_NO=ps_customer_no;

        IF (ln_count = 0) THEN
            ls_returncode := 999;
        END IF;
        
        OPEN pc_ref FOR
        select MCC from CBS.CBS_QR_MERCHANTS 
        where CUSTOMER_NO=ps_customer_no;
        
   RETURN ls_returncode;
END;

/******************************************************************************
NAME        : FUNCTION getMerchantCategories
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : getMerchantCategories
******************************************************************************/
FUNCTION getMerchantCategories(ps_lang IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  BEGIN 
        OPEN pc_ref FOR
        SELECT * FROM CBS.CBS_MERCHANT_CATEGORIES_QR order by code;
   RETURN ls_returncode;
END;

/******************************************************************************
NAME        : FUNCTION getBusinessObjectTypes
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : getBusinessObjectTypes
******************************************************************************/
FUNCTION getBusinessObjectTypes(ps_lang IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  BEGIN 
        OPEN pc_ref FOR
        SELECT * FROM CBS.CBS_MERCHANT_BUSINESS_TYPES_QR order by code;
   RETURN ls_returncode;
END;

/******************************************************************************
NAME        : FUNCTION getActivityTypes
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : getActivityTypes
******************************************************************************/
FUNCTION getActivityTypes(ps_lang IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  BEGIN 
        OPEN pc_ref FOR
        SELECT * FROM CBS.CBS_MERCHANT_ACTIVITIES_QR order by code;
   RETURN ls_returncode;
END;            

/******************************************************************************
NAME        : FUNCTION newQrFormByCustomerNumber
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : newQrFormByCustomerNumber
******************************************************************************/
FUNCTION newQrFormByCustomerNumber(ps_customer_no IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  ln_count       NUMBER;
  BEGIN 
        SELECT COUNT(*) INTO ln_count from  cbs.cbs_musteri where musteri_no = ps_customer_no; 

        IF (ln_count = 0) THEN
            ls_returncode := 999;
        END IF;
        
        OPEN pc_ref FOR
        select nvl(ticari_unvan, isim || ' ' || ikinci_isim || ' ' || soyadi) full_name, 
               VERGI_NO 
        from  cbs.cbs_musteri where musteri_no = ps_customer_no;
        
   RETURN ls_returncode;
END;

/******************************************************************************
NAME        : FUNCTION saveQrOfMerchant
Prepared By : Bakdoolot Keldibekova
Date        : 30.11.2022
Purpose     : saveQrOfMerchant
******************************************************************************/
FUNCTION saveQrOfMerchant(ps_customer_no IN VARCHAR2, 
                            ps_tin IN VARCHAR2, 
                            ps_customer_name IN VARCHAR2, 
                            ps_mcc IN VARCHAR2, 
                            ps_activity_type IN VARCHAR2, 
                            ps_business_obj_type IN VARCHAR2, 
                            ps_point_type IN VARCHAR2, 
                            ps_point_format IN VARCHAR2, 
                            ps_postal_code IN VARCHAR2, 
                            ps_email IN VARCHAR2, 
                            ps_country IN VARCHAR2, 
                            ps_administrative_area IN VARCHAR2, 
                            ps_region IN VARCHAR2, 
                            ps_locality IN VARCHAR2, 
                            ps_street IN VARCHAR2, 
                            ps_street_no IN VARCHAR2, 
                            ps_location IN VARCHAR2, 
                            ps_eq_type IN VARCHAR2, 
                            ps_eq_id IN VARCHAR2, 
                           -- ps_point_id IN VARCHAR2, 
                            ps_created_by IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  BEGIN 
        insert into CBS.CBS_QR_MERCHANTS(CUSTOMER_NO, 
                                            TIN, 
                                            CUSTOMER_NAME, 
                                            MCC, 
                                            ACTIVITY_TYPE, 
                                            BUSINESS_OBJ_TYPE, 
                                            POINT_TYPE, 
                                            POINT_FORMAT, 
                                            POSTAL_CODE, 
                                            EMAIL, 
                                            COUNTRY, 
                                            ADMINISTRATIVE_AREA, 
                                            REGION, 
                                            LOCALITY, 
                                            STREET, 
                                            STREET_NO, 
                                            LOCATION, 
                                            EQ_TYPE, 
                                            EQ_ID, 
                                            CREATED_AT, 
                                            CREATED_BY)
        values(ps_customer_no, 
                ps_tin, 
                ps_customer_name, 
                ps_mcc,
                ps_activity_type,
                ps_business_obj_type,
                ps_point_type,
                ps_point_format,
                ps_postal_code,
                ps_email, 
                ps_country, 
                ps_administrative_area,
                ps_region, 
                ps_locality, 
                ps_street,
                ps_street_no, 
                ps_location, 
                ps_eq_type,
                ps_eq_id,
                sysdate, 
                ps_created_by);
        
        OPEN pc_ref FOR
        select MCC from CBS.CBS_QR_MERCHANTS where CUSTOMER_NO = ps_customer_no;
        
    RETURN ls_returncode;
    
    EXCEPTION
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT '-' FROM DUAL;
            log_at('CBS.PKG_DATA_INQUIRY.saveQrOfMerchant', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN  '999';  
END;

/******************************************************************************
NAME        : FUNCTION getSocialFundInfo
Prepared By : Bakdoolot Keldibekova
Date        : 06.12.2022
Purpose     : getSocialFundInfo
******************************************************************************/
FUNCTION getSocialFundInfo(ps_pin IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode  VARCHAR2(3):='000';
  ln_count       NUMBER;
 
  BEGIN
	  select count(*) INTO ln_count FROM cbs.cbs_social_fund_info where pin = ps_pin;
	 IF (ln_count = 0) then
	 	ls_returncode := '999';
	 end IF;
	 
        
	 OPEN pc_ref FOR
        SELECT * FROM cbs.cbs_social_fund_info where pin = ps_pin;
	  
   RETURN ls_returncode;
END;


/******************************************************************************
NAME        : FUNCTION saveSocialFundInfo
Prepared By : Nursultan K
Date        : 06.12.2022
Purpose     : saveSocialFundInfo
******************************************************************************/
FUNCTION saveSocialFundInfo(ps_pin IN VARCHAR2,
							ps_name IN VARCHAR2,
							ps_created_date IN VARCHAR2,
							ps_requested_by IN VARCHAR2,
							ps_customer_no IN VARCHAR2, ps_data clob) RETURN VARCHAR2 IS
	ls_returncode varchar2(3) := '000';
	ls_count NUMBER;
	BEGIN
		
	SELECT count(*) INTO ls_count FROM cbs.cbs_social_fund_info WHERE pin = ps_pin;
	IF (ls_count = 0) THEN
		INSERT INTO cbs.cbs_social_fund_info (
		CUSTOMER_NO,
		SF_PERSONAL_INFO,
		CREATED_DATE,
		REQUESTED_BY,
		NAME, PIN)
		VALUES (
				to_number(ps_customer_no),
				ps_data,
				ps_created_date,
				ps_requested_by,
				ps_name, 
				ps_pin);
		ELSE
		UPDATE cbs.cbs_social_fund_info SET SF_PERSONAL_INFO = TO_CHAR(ps_data), 
		REQUESTED_BY = ps_requested_by,
		CREATED_DATE = ps_created_date
		WHERE pin = ps_pin;
		end IF;
	
	
	RETURN '000';
	
	EXCEPTION
      WHEN OTHERS
      THEN
         log_at (
            'Pkg_date_inquiry.save_sf_info',
            UTL_HTTP.GET_DETAILED_SQLERRM,
               SQLCODE
            || ' '
            || SQLERRM
            || ' '
            || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN '999';
   END;
		

/******************************************************************************
NAME        : FUNCTION checkRequestCount for social fund
Prepared By : Nursultan K
Date        : 09.12.2022
Purpose     : checkRequestCount
******************************************************************************/
FUNCTION checkRequestCount(ps_pin IN varchar2) RETURN varchar2 IS
							
	ls_returncode varchar2(3) := '000';
	ls_count NUMBER := NULL;
	limitIsExceeded EXCEPTION;
	
	BEGIN
		SELECT count(*) INTO ls_count FROM CBS.cbs_social_fund_check_request WHERE pin = ps_pin AND trunc(REQUEST_DATE) = trunc(sysdate);
		IF (ls_count = 3) THEN
		ls_returncode := '003';
		raise limitIsExceeded;
		END IF;
	
	RETURN ls_returncode;

	EXCEPTION
    WHEN limitIsExceeded THEN 
     RETURN ls_returncode;
    WHEN OTHERS THEN 
    ls_returncode := '999';
    ROLLBACK;
   	RETURN ls_returncode;
   END;

  
 /******************************************************************************
NAME        : FUNCTION insertRequestCount
Prepared By : Nursultan K
Date        : 09.12.2022
Purpose     : insertRequestCount
******************************************************************************/
  FUNCTION insertRequestCount(ps_pin IN varchar2, 
							ps_requested_by IN varchar2,
							ps_customer_no IN varchar2,
							ps_tran_no IN varchar2) RETURN varchar2 IS
	ls_returncode varchar2(3) := '000';
	ln_branch varchar2(3);
	ln_firstname varchar(50);
	ln_lastname varchar(50);
	ln_fullname varchar(100);

	BEGIN
		
		BEGIN
		select distinct
			K.kodu USERNAME,
			K.ADI ||' '||K.SOYADI, --K.PERSONEL_NUMARA STAFF_NO ,
			K.CALISILAN_BOLUM INTO ln_firstname, ln_lastname, ln_branch
			from cbs_kullanici K  
			LEFT JOIN CBS_ERISIM E ON E.KULLANICI_KODU=K.KODU
			LEFT JOIN CBS_ERISIM_ROL ER ON K.KODU=ER.ERISIM_KULLANICI_KODU AND E.BOLUM_KODU=ER.BOLUM_KODU
			LEFT JOIN CBS_ROL R ON R.NUMARA=ER.ROL_NUMARA
			where ( E.BITIS_TARIHI IS NULL OR E.BITIS_TARIHI>=(SELECT BANKA_TARIHI FROM CBS_SYSTEM)) AND R.BITIS_TARIHI IS NULL AND
			--  ER.ROL_NUMARA =NVL(:P69_ROLE_NO, ER.ROL_NUMARA) --поиск по роли
			ER.ROL_NUMARA='1560' and K.kodu = upper(ps_requested_by);
			ln_fullname := ln_firstname|| ' ' ||ln_lastname;
		EXCEPTION WHEN
			NO_DATA_FOUND THEN
        	ln_firstname := NULL;
        	ln_lastname := NULL;
        	ln_fullname := NULL;
        	ln_branch := NULL;
    	END;
		
		INSERT INTO CBS.cbs_social_fund_check_request(
		PIN,
		REQUEST_DATE, 
		REQUESTED_BY, 
		CUSTOMER_NO, 
		TRAN_NO, BRANCH, FULLNAME)
		VALUES (ps_pin, sysdate, ps_requested_by, ps_customer_no, ps_tran_no, ln_branch, ln_fullname);

	RETURN ls_returncode;

	EXCEPTION
    WHEN OTHERS THEN 
    ls_returncode := '999';
    ROLLBACK;
   	RETURN ls_returncode;
   END;
 
 /******************************************************************************
NAME        : FUNCTION getCheckRequest
Prepared By : Nursultan K
Date        : 14.12.2022
Purpose     : getCheckRequest
******************************************************************************/
 FUNCTION getCheckRequest(ps_branch_code IN varchar2, ps_start_date IN varchar2, ps_end_date IN varchar2, pc_ref OUT CursorReferenceType) 
 RETURN varchar2 IS
 ls_returncode varchar2(3) := '000';
 ln_start_date DATE;
 ln_end_date DATE;

BEGIN
	ln_start_date := to_date(ps_start_date, 'YYYY-MM-DD');
	ln_end_date := to_date(ps_end_date, 'YYYY-MM-DD');
	
	OPEN pc_ref FOR
        SELECT * FROM CBS.cbs_social_fund_check_request 
       	where BRANCH  = ps_branch_code AND REQUEST_DATE BETWEEN ln_start_date AND ln_end_date;  
    RETURN ls_returncode;
       
    EXCEPTION
    WHEN OTHERS THEN
    log_at (
            'Pkg_date_inquiry.getCheckReq',
            UTL_HTTP.GET_DETAILED_SQLERRM,
               SQLCODE
            || ' '
            || SQLERRM
            || ' '
            || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         RETURN '999';
   	END;

   	
END;
/

