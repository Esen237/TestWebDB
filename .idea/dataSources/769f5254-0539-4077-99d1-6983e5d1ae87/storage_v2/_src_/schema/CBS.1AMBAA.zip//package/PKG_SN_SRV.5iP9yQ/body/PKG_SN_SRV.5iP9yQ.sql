create PACKAGE BODY PKG_SN_SRV
IS

   PROCEDURE FILL_SN_FIRST_LEVEL(P_DATE DATE)
   IS
     RPT_DATE DATE := P_DATE;--PKG_DATES.get_previous_work_date(P_DATE);
   BEGIN
        delete from CBS_RPT_SN_BALANCE where date_no = RPT_DATE;
		insert into CBS_RPT_SN_BALANCE values (rpt_date,'KZT','010','8365',147754000,0,147754000);
        insert into CBS_RPT_SN_BALANCE
             select date_no,
            	    doviz_kod curr_code,
            	    bolum_kodu branch_code,
            	    numara gl_no,
            	    sum(bakiye_a) bakiye_a,
            	    sum(bakiye_p) bakiye_p,
            	    sum(bakiye) bakiye
               from (select date_no,
        					 doviz_kod,
        					 bolum_kodu,
        					 dk_kod numara,
                             sum(case when substr(DK_KOD, 1, 1) in ('1', '5', '7') then bakiye when substr(DK_KOD, 1, 1) in ('6') then case when substr(DK_KOD, 2, 1) in ('0', '1', '3', '4') then bakiye else 0 end else 0 end) bakiye_a,
                             sum(case when substr(DK_KOD, 1, 1) in ('2', '3', '4') then bakiye when substr(DK_KOD, 1, 1) in ('6') then case when substr(DK_KOD, 2, 1) in ('5', '6', '7', '8', '9') then bakiye else 0 end else 0 end) bakiye_p,
                             sum(bakiye) bakiye
                        from (select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
         	   		               	 doviz_kod,
        		               		 bolum_kodu,
         	   		               	 substr(numara, 1, 4) dk_kod,
        		               		 case when ((substr(numara, 1, 4) like '1%' or substr(numara, 1, 4) like '5%') and sum(bakiye_lc) >0) or ((substr(numara, 1, 4) like '2%' or substr(numara, 1, 4) like '3%' or substr(numara, 1, 4) like '4%') and sum(bakiye_lc) < 0) then -abs(sum(nvl(BAKIYE_LC, 0))) else abs(sum(nvl(BAKIYE_LC, 0))) end bakiye
                                from cbs_dkhesap_gunluk_bakiye
        	                   where gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
               				   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), doviz_kod, bolum_kodu, substr(numara, 1, 4))
                       group by date_no, doviz_kod, bolum_kodu, dk_kod
                       union all
                   	  select b.date_no,
        					 b.doviz_kod,
        					 b.bolum_kodu,
        					 a.sn_dk_kode dk_kod,
                   			 abs(sum(nvl(b.BAKIYE_LC, 0))) a_bakiye,
        					 0 p_bakiye,
        					 abs(sum(nvl(b.BAKIYE_LC, 0))) bakiye
                   		from cbs_rapor_sn_par a,
                   		 	 (select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
        					   		 doviz_kod,
        							 bolum_kodu,
                   					 numara,
        						     sum(bakiye_lc) bakiye_lc
                   				from cbs_dkhesap_gunluk_bakiye
        					   where gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
                   			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), doviz_kod, bolum_kodu, numara) b
                       where substr(b.NUMARA, 1, length(a.DK_KODE)) = a.dk_kode
                   	   group by b.date_no, b.doviz_kod, b.bolum_kodu, a.sn_dk_kode
           			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '8001',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1004', '1005', '1007', '1008') and
                        	 a.DOVIZ_KOD = 'KZT' and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
        			  select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
                             '8002' dk_kod,
        			  		 abs(sum(nvl(a.BAKIYE_LC, 0))) a_bakiye,
        					 0 p_bakiye,
        					 abs(sum(nvl(a.BAKIYE_LC, 0))) bakiye
                        from cbs_dkhesap_gunluk_bakiye a,
               	 	  		 cbs_doviz_kodlari b
                       where substr(a.numara, 1, 6) in ('100123', '100223', '100323') and
               		   		 b.DOVIZ_KODU = a.DOVIZ_KOD and
               		  		 b.DOVIZ_TIPI = 'HARD' and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
        			  select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
                             '8016' dk_kod,
        			  		 abs(sum(nvl(a.BAKIYE_LC, 0))) a_bakiye,
        					 0 p_bakiye,
        					 abs(sum(nvl(a.BAKIYE_LC, 0))) bakiye
                        from cbs_dkhesap_gunluk_bakiye a,
               	 	  		 cbs_doviz_kodlari b
                       where substr(a.numara, 1, 6) = '100123' and
               		   		 b.DOVIZ_KODU = a.DOVIZ_KOD and
               		  		 b.DOVIZ_TIPI NOT IN ('HARD', 'LC') and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
         			  select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8025' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
        					 b.MUSTERI_NO in (106, 110, 116, 117, 130, 135, 144, 159, 7979) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
                       union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8043' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                      	   	 b.MUSTERI_NO IN (118, 133, 171, 183) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
                       union all
                      select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
        			  		 DOVIZ_KOD,
        					 BOLUM_KODU,
        			  		 '8054',
                      	   	 -sum(abs(BAKIYE_LC)),
                      	   	 0,
                      	   	 -sum(abs(BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye
                       where (substr(NUMARA, 1, 4) = '1329' or substr(NUMARA, 1, 6) = '142817') and
        			   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), DOVIZ_KOD, BOLUM_KODU
                       union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8054' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap_kredi b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 6) in ('130324', '130224') and
                      	   	 b.MUSTERI_NO IN (101, 103, 104, 107, 109, 111, 112, 114, 123, 134, 125, 147, 153, 161, 166, 188, 189, 190, 6079, 113, 115, 120, 121, 124, 125, 126, 127, 130, 131, 146, 165, 169, 175, 186, 195, 180, 6550, 6075, 6460, 6062) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
                       union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '8055',
                      	   	 -sum(abs(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 -sum(abs(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 6) in ('142819', '142829') and
        			   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, A.BOLUM_KODU
                       union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8058' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258','1264') and
                      	   	 b.MUSTERI_NO IN (101, 103, 104, 107, 109, 111, 112, 114, 123, 134, 147, 153, 161, 166, 188, 189, 190, 121, 124, 146, 6079, 175, 186, 195, 180) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
                       union all
                     select RPT_DATE date_no,
                     	    DOVIZ_KODU,
                     	    SUBE_KODU,
                            '8058' dk_kod,
                            nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(DOVIZ_KODU, pkg_genel.lc_al, BANKA_TARIHI, BAKIYE, 1, null, null, 'N', 'B'))), 0),
                            0 p_bakiye,
                            nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(DOVIZ_KODU, pkg_genel.lc_al, BANKA_TARIHI, BAKIYE, 1, null, null, 'N', 'B'))), 0)
                       from cbs_rpt_kredi_gunsonu_faiz
                      where substr(MUSTERI_DK_NO, 1, 4) in ('1264') and
                      	    musteri_no = 134 and
                       	    banka_tarihi = RPT_DATE
                      group by BANKA_TARIHI, DOVIZ_KODU, SUBE_KODU
					  union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8058' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap_kredi b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                      	   	 b.MUSTERI_NO IN (101, 103, 104, 107, 109, 111, 112, 114, 123, 134, 147, 153, 161, 166, 188, 189, 190, 121, 124, 146, 6079, 175, 186, 195, 180) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
                       union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8075' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap_kredi b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                      	   	 b.MUSTERI_NO IN (113, 115, 119, 120, 125, 126, 127, 131, 132, 136, 154, 165, 169, 182, 185, 193, 6550, 6075, 6466, 6460, 6062) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8075' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                      	   	 b.MUSTERI_NO IN (113, 115, 119, 120, 125, 126, 127, 131, 132, 136, 154, 165, 169, 182, 185, 193, 6550, 6075, 6466, 6460, 6062) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
         			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8166' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b,
                      	   	 cbs_musteri c
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 c.MUSTERI_NO = b.MUSTERI_NO and
        					 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                        	 c.MUSTERI_NO in (select MUSTERI_NO
                          	 				    from cbs_musteri_grup_bagli_musteri
                        					   where GRUP_KODU='DEMIR') and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8167' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b,
                      	   	 cbs_musteri c
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 c.MUSTERI_NO = b.MUSTERI_NO and
        					 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1256', '1257', '1258') and
                        	 c.MUSTERI_NO in (select MUSTERI_NO
                          	 				    from cbs_musteri_grup_bagli_musteri
                        					   where GRUP_KODU='DEMIR') and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8172' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 6) in ('105224', '125224', '105214', '125214') and
                      	   	 b.MUSTERI_NO IN (171, 183, 133, 109, 135, 144, 7979, 106, 110, 116, 117, 118, 130, 159, 180, 101, 104, 107, 109, 111, 112, 114, 123, 134, 147, 153, 161, 166, 188, 189, 190) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '8173' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                      	   	 substr(b.MUSTERI_DK_NO, 1, 6) in ('130124', '130114') and
                      	   	 b.MUSTERI_NO IN (171, 183, 133) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
        			  		 '8176',
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_rpt_kredi_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1411', '1256', '1264', '1417', '1252', '1253', '1302') and
							 b.KREDI_VADE-RPT_DATE < 93 and
							 b.BANKA_TARIHI = RPT_DATE and
							 gun = to_number(to_char(RPT_DATE, 'dd')) and
						     ay = to_number(to_char(RPT_DATE, 'mm')) and
						     yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
        			  		 '8177',
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
        					 cbs_rpt_vadeli_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) in ('2054', '2123', '2124', '2127', '2130', '2131', '2133', '2206', '2207', '2208', '2213', '2215', '2217', '2219', '2223', '2240') and
        					 b.BANKA_TARIHI = RPT_DATE and
							 b.vade_tarihi-RPT_DATE  < 93 and
							 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select b.BANKA_TARIHI date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
        			  		 '8176',
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, b.BANKA_TARIHI, b.BIRIKMIS_FAIZ_TUTARI, 1, null, null, 'N', 'B'))), 0),
        					 0,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, b.BANKA_TARIHI, b.BIRIKMIS_FAIZ_TUTARI, 1, null, null, 'N', 'B'))), 0)
                        from cbs_rpt_kredi_gunsonu_faiz b
                       where b.KREDI_VADE-RPT_DATE < 93 and
							 b.BANKA_TARIHI = RPT_DATE
        			   group by b.BANKA_TARIHI, b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select b.BANKA_TARIHI date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
        			  		 '8177',
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, b.BANKA_TARIHI, b.BIRIKMIS_FAIZ_TUTARI, 1, null, null, 'N', 'B'))), 0),
        					 0,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, b.BANKA_TARIHI, b.BIRIKMIS_FAIZ_TUTARI, 1, null, null, 'N', 'B'))), 0)
                        from cbs_rpt_vadeli_gunsonu_faiz b
                       where b.BANKA_TARIHI = RPT_DATE and
							 b.vade_tarihi-RPT_DATE  < 93
        			   group by b.BANKA_TARIHI, b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '8801',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1004', '1005', '1007', '1008') and
                        	 a.DOVIZ_KOD = 'KZT' and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '9001',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('1001', '1002', '1003', '1004', '1005', '1007', '1008') and
                        	 a.DOVIZ_KOD = 'KZT' and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '9003' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_rpt_vadeli_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) = '2301' and
                        	 substr(b.MUSTERI_DK_NO, 1, 6) not in ('230113', '230114') and
        					 b.BANKA_TARIHI = RPT_DATE and
                        	 (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), 'mmyyyy') or
                        	 to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'))+1, 'mmyyyy')) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '9004' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_rpt_vadeli_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) = '2303' and
                        	 substr(b.MUSTERI_DK_NO, 1, 6) not in ('230313', '230314') and
        					 b.BANKA_TARIHI = RPT_DATE and
                        	 (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), 'mmyyyy') or
                        	 to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'))+1, 'mmyyyy')) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '9005' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_rpt_vadeli_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
        			   		 b.BANKA_TARIHI = RPT_DATE and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) = '2401' and
                        	 substr(b.MUSTERI_DK_NO, 1, 6) not in ('240113', '240114') and
                        	 (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), 'mmyyyy') or
                        	 to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'))+1, 'mmyyyy')) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select date_no,
        			  		 doviz_kod,
        					 bolum_kodu,
        			  		 '9006',
        			  		 nvl(abs(sum(b1-b2)), 0),
        					 0,
        					 nvl(abs(sum(b1-b2)), 0)
        			    from (select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        					 		 a.DOVIZ_KOD,
        							 a.BOLUM_KODU,
                			  		 a.NUMARA,
                					 case when substr(a.NUMARA, 1, 6) in ('285514', '285524', '285525', '285526', '285527', '285528', '285529')
                					      then 0
                					      else pkg_kur.DOVIZ_DOVIZ_KARSILIK(a.DOVIZ_KOD, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B')
                					 end b1,
                					 case when substr(a.NUMARA, 1, 6) in ('285514', '285524', '285525', '285526', '285527', '285528', '285529')
                					      then pkg_kur.DOVIZ_DOVIZ_KARSILIK(a.DOVIZ_KOD, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B')
                						  else 0
                					 end b2
                                from cbs_dkhesap_gunluk_bakiye a
                               where substr(a.NUMARA, 1, 4) = '2855' and
        					   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy')))
                       group by date_no, doviz_kod, bolum_kodu
        			   union all
        			  select date_no,
        			  		 doviz_kod,
        					 bolum_kodu,
        			  		 '9007',
        					 nvl(sum(bakiye_lc), 0),
        					 0,
        					 nvl(sum(bakiye_lc), 0)
        			    from (select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        					 		 a.DOVIZ_KOD,
        							 a.BOLUM_KODU,
                			  		 a.NUMARA,
        							 a.BAKIYE_LC
                                from cbs_dkhesap_gunluk_bakiye a
                               where substr(a.NUMARA, 1, 4) = '2870' and
        					   		 substr(a.NUMARA, 1, 6) not in ('287011', '287013', '287024', '287025', '287026', '287027', '287028', '287029') and
        							 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        					   union
        				     select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        					 		 a.DOVIZ_KOD,
        							 a.BOLUM_KODU,
                			  		 a.NUMARA,
        							 a.BAKIYE_LC
                                from cbs_dkhesap_gunluk_bakiye a
                               where substr(a.NUMARA, 1, 6) in ('287014') and
        					   		 a.DOVIZ_KOD = 'KZT' and
        							 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy')))
                       group by date_no, doviz_kod, bolum_kodu
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
                             '9009' dk_kod,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0 p_bakiye,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_rpt_vadeli_gunsonu_faiz b
                       where b.HESAP_NO = a.HESAP_NO and
        			   		 b.BANKA_TARIHI = RPT_DATE and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) in ('2206', '2207', '2208', '2215', '2217', '2219', '2222', '2223') and
                        	 (to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), 'mmyyyy') or
                        	 to_char(b.VADE_TARIHI, 'mmyyyy') = to_char(LAST_DAY(to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'))+1, 'mmyyyy')) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '9010',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('2044', '2046') and
        			   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        					 '9011',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('2301') and
        			   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
        			  		 '9012',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('2401', '2402') and
        			   		 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
        			   union all
        			  select to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.DOVIZ_KOD,
        					 a.BOLUM_KODU,
                             '9013' dk_kod,
        			  		 abs(sum(nvl(a.BAKIYE_LC, 0))) a_bakiye,
        					 0 p_bakiye,
        					 abs(sum(nvl(a.BAKIYE_LC, 0))) bakiye
                        from cbs_dkhesap_gunluk_bakiye a,
               	 	  		 cbs_doviz_kodlari b
                       where substr(a.numara, 1, 6) in ('100123', '100223', '100323') and
               		   		 b.DOVIZ_KODU = a.DOVIZ_KOD and
               		  		 b.DOVIZ_TIPI NOT IN ('LC') and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU
           			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 b.DOVIZ_KODU,
        					 b.SUBE_KODU,
        			  		 '9015',
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0),
        					 0,
        					 nvl(sum(abs(pkg_kur.DOVIZ_DOVIZ_KARSILIK(b.DOVIZ_KODU, pkg_genel.lc_al, to_date(to_char(a.GUN, '99')||to_char(a.AY, '99')||to_char(a.YIL, '9999'), 'ddmmyyyy'), a.BAKIYE, 1, null, null, 'N', 'B'))), 0)
                        from cbs_hesap_gunluk_bakiye a,
                        	 cbs_hesap b
                       where b.HESAP_NO = a.HESAP_NO and
                         	 substr(b.MUSTERI_DK_NO, 1, 4) in ('1052', '1251', '1252', '1253', '1254', '1255', '1257', '1705', '1725', '1726') and
        					 b.MUSTERI_NO in (106, 110, 116, 117, 118, 130, 133, 135, 144, 159, 171, 183, 180, 7979) and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), b.DOVIZ_KODU, b.SUBE_KODU
        			   union all
                      select to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy') date_no,
        			  		 a.doviz_kod,
        					 a.bolum_kodu,
        			  		 '9018',
                      	   	 abs(sum(a.BAKIYE_LC)),
                      	   	 0,
                      	   	 abs(sum(a.BAKIYE_LC))
                        from cbs_dkhesap_gunluk_bakiye a
                       where substr(a.NUMARA, 1, 4) in ('2201', '2202', '2203', '2204', '2205', '2209', '2211', '2221', '2224', '2226', '2228', '2232', '2252') and
        			   		 substr(a.NUMARA, 5, 2) not in ('21', '22', '23', '24', '25', '26', '27', '28', '29', '14', '13') and
        					 gun = to_number(to_char(RPT_DATE, 'dd')) and ay = to_number(to_char(RPT_DATE, 'mm')) and yil = to_number(to_char(RPT_DATE, 'yyyy'))
        			   group by to_date(to_char(a.gun, '99')||to_char(a.ay, '99')||to_char(a.yil, '9999'), 'ddmmyyyy'), a.DOVIZ_KOD, a.BOLUM_KODU)
		   where substr(numara,1,1) <> '9'
           group by date_no, doviz_kod, bolum_kodu, numara;


      for recin in (select RPT_DATE date_no,
    					   doviz_kodu curr_code,
    					   '010' branch_code,
    					   '8368' gl_no,
    					   abs(dat1-dat2)*1000 bakiye_a,
    					   0 bakiye_b,
    					   abs(dat1-dat2)*1000 bakiye
    				  from (SELECT doviz_kodu,
    							   ROUND(PKG_REPORT6.CBS_RAPOR_VPD_DATA(t.R_NAME, dov.DOVIZ_KODU, t.TYPE_NO, 0, RPT_DATE)/1000, 0) dat1,
                                   ROUND(PKG_REPORT6.CBS_RAPOR_VPD_DATA(t.R_NAME, dov.DOVIZ_KODU, t.TYPE_NO, 1, RPT_DATE)/1000, 0) dat2,
    							   R_NAME,
    							   DOVIZ_NUMARA
                              FROM CBS_RAPOR_VPD_PAR T,
                                   CBS_DOVIZ_KODLARI DOV
                             WHERE DOV.NUMARA = T.DOVIZ_NUMARA)
    				 where R_NAME = 'R8' and
            			   NVL(DOVIZ_NUMARA, R_NAME) <> 'R8' and
    				 	   dat1-dat2<0) loop
        insert into CBS_RPT_SN_BALANCE (DATE_NO, CURR_CODE, BRANCH_CODE, GL_NO, BAKIYE_A, BAKIYE_B, BAKIYE)
    	values (recin.DATE_NO, recin.CURR_CODE, recin.BRANCH_CODE, recin.GL_NO, recin.BAKIYE_A, recin.BAKIYE_B, recin.BAKIYE);
      end loop;

   END;

   PROCEDURE FILL_SN_SECOND_LEVEL(P_DATE DATE)
   IS
     RPT_DATE DATE := P_DATE;--PKG_DATES.get_previous_work_date(P_DATE);
   BEGIN
        delete from CBS_RPT_SN_BALANCE_FULL where date_no = RPT_DATE;
        insert into CBS_RPT_SN_BALANCE_FULL
        select *
          from (select date_no,
                	   gl_no,
        			   round(decode(gl_no, '5703', PKG_SN_SRV.difference_5703_4703(gl_no, bakiye_a, date_no), bakiye_a)/1000) bakiye_a,
        			   round(decode(gl_no, '4703', PKG_SN_SRV.difference_5703_4703(gl_no, bakiye_b, date_no), bakiye_b)/1000) bakiye_b,
        			   round(PKG_SN_SRV.difference_5703_4703(gl_no, bakiye, date_no)/1000) bakiye
                  from (select date_no, gl_no, sum(bakiye_a) bakiye_a, sum(bakiye_b) bakiye_b, sum(bakiye) bakiye
        		          from cbs_rpt_sn_balance
        				 where date_no = RPT_DATE and
        				 	   PKG_SN_SRV.val_pos(gl_no, date_no) = 0
        				 group by date_no, gl_no)
                 union
                select date_no,
                	   '3599' gl_no,
                	   0 bakiye_a,
                	   sum(decode(substr(gl_no, 1, 1), '4', BAKIYE)) - sum(decode(substr(gl_no, 1, 1), '5', BAKIYE)) bakiye_p,
                	   sum(decode(substr(gl_no, 1, 1), '4', BAKIYE)) - sum(decode(substr(gl_no, 1, 1), '5', BAKIYE)) bakiye
                  from (select date_no,
                  	           gl_no,
                			   round(PKG_SN_SRV.difference_5703_4703(gl_no, sum(nvl(BAKIYE, 0)), date_no)/1000) BAKIYE
                	      from (select date_no, gl_no, sum(bakiye) bakiye
        				          from cbs_rpt_sn_balance
        						 where date_no = RPT_DATE
        						 group by gl_no, date_no)
                         where substr(gl_no, 1, 1) in ('4', '5')
                         group by date_no, gl_no)
                group by date_no)
         where bakiye <> 0 and gl_no <> '7990'
         order by 1,2;

        delete from CBS_RPT_SN_BALANCE_BRANCH where date_no = RPT_DATE;
        insert into CBS_RPT_SN_BALANCE_BRANCH
        select *
          from (select date_no,
                	   gl_no,
        			   branch_code,
        			   round(bakiye_a/1000) bakiye_a,
        			   round(bakiye_b/1000) bakiye_b,
        			   round(bakiye/1000) bakiye
                  from (select date_no, gl_no, branch_code, sum(bakiye_a) bakiye_a, sum(bakiye_b) bakiye_b, sum(bakiye) bakiye
        		          from cbs_rpt_sn_balance
        				 where date_no = RPT_DATE
        				 group by date_no, gl_no, branch_code)
                 union
                select date_no,
                	   '3599' gl_no,
        			   branch_code,
                	   0 bakiye_a,
                	   sum(decode(substr(gl_no, 1, 1), '4', BAKIYE)) - sum(decode(substr(gl_no, 1, 1), '5', BAKIYE)) bakiye_p,
                	   sum(decode(substr(gl_no, 1, 1), '4', BAKIYE)) - sum(decode(substr(gl_no, 1, 1), '5', BAKIYE)) bakiye
                  from (select date_no,
                  	           gl_no,
        					   branch_code,
                			   round(PKG_SN_SRV.difference_5703_4703(gl_no, round(sum(nvl(BAKIYE, 0))/1000), date_no, branch_code)/1000) BAKIYE
                	      from cbs_rpt_sn_balance
                         where substr(gl_no, 1, 1) in ('4', '5') and
        				 	   date_no = RPT_DATE
                         group by date_no, gl_no, branch_code)
                group by date_no, branch_code)
         where bakiye <> 0 and gl_no <> '7990'
         order by 1, 3, 2;

        delete from CBS_RPT_SN_BALANCE_CUR where date_no = RPT_DATE;
        insert into CBS_RPT_SN_BALANCE_CUR
        select date_no,
			   gl_no,
			   curr_code,
			   round(sum(bakiye_a)/1000) bakiye_a,
			   round(sum(bakiye_b)/1000) bakiye_b,
			   round(sum(bakiye)/1000) bakiye
          from cbs_rpt_sn_balance
         where date_no = RPT_DATE
         group by date_no, gl_no, curr_code
         order by 1, 2, 3;

   END;

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ date) return number
  as
	p4703  NUMBER;
	p5703  NUMBER;
  begin
    if gl_ <> '4703' and gl_ <> '5703' then
	    return bakiye_;
	else
    	if gl_ = '4703' then
    	  p4703 := abs(bakiye_);
            select sum(abs(nvl(BAKIYE, 0)))  bakiye
    		  into p5703
              from cbs_rpt_sn_balance
             where DATE_NO = DATE_ and
    		 	   gl_no = '5703';
    	  if p4703 > p5703 then
    	    return p4703-p5703;
    	  else
    	    return 0;
    	  end if;
    	elsif gl_ = '5703' then
    	  p5703 := abs(bakiye_);
            select sum(abs(nvl(BAKIYE, 0)))  bakiye
    		  into p4703
              from cbs_rpt_sn_balance
             where DATE_NO = DATE_ and
    		 	   gl_no = '4703';
    	  if p5703 > p4703 then
    	    return p5703-p4703;
    	  else
    	    return 0;
    	  end if;
    	end if;
	end if;
  end;

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ date, bolum_kodu_ varchar2) return number
  as
	p4703  NUMBER;
	p5703  NUMBER;
  begin
    if gl_ <> '4703' and gl_ <> '5703' then
	    return bakiye_;
	else
    	if gl_ = '4703' then
    	  p4703 := abs(bakiye_);
            select sum(abs(nvl(BAKIYE, 0)))  bakiye
    		  into p5703
              from cbs_rpt_sn_balance
             where DATE_NO = DATE_ and
			 	   branch_code = bolum_kodu_ and
    		 	   gl_no = '5703';
    	  if p4703 > p5703 then
    	    return p4703-p5703;
    	  else
    	    return 0;
    	  end if;
    	elsif gl_ = '5703' then
    	  p5703 := abs(bakiye_);
            select sum(abs(nvl(BAKIYE, 0)))  bakiye
    		  into p4703
              from cbs_rpt_sn_balance
             where DATE_NO = DATE_ and
			 	   branch_code = bolum_kodu_ and
    		 	   gl_no = '4703';
    	  if p5703 > p4703 then
    	    return p5703-p4703;
    	  else
    	    return 0;
    	  end if;
    	end if;
	end if;
  end;

  function val_pos(gl_ varchar2, date_ date) return number
  as
    result NUMBER;
    p1351  NUMBER;
    p1352  NUMBER;

    p2151  NUMBER;
    p2152  NUMBER;


	p1858  NUMBER;
	p1859  NUMBER;

	p2858  NUMBER;
	p2859  NUMBER;
  begin
    if gl_ not in ('1351', '1352', '1858', '1859', '2151', '2152', '2858', '2859') then
	    return 0;
	else
    	if gl_ in ('1351', '1352', '2151', '2152') then
                select count(*)
				  into result
			      from (select round(sum(f1351)/1000) f1351,
							   round(sum(f1352)/1000) f1352,
							   round(sum(f2151)/1000) f2151,
							   round(sum(f2152)/1000) f2152,
							   round(sum(f1351+f1352)/1000) f13,
							   round(sum(f2151+f2152)/1000) f21
						  from (select dk,
									   decode(dk, '1351', bakiye, 0) f1351,
									   decode(dk, '1352', bakiye, 0) f1352,
									   decode(dk, '2151', bakiye, 0) f2151,
									   decode(dk, '2152', bakiye, 0) f2152
							      from (select gl_no dk,
                				  	   		   abs(sum(nvl(BAKIYE, 0)))  bakiye
                                          from cbs_rpt_sn_balance
										 where DATE_NO = DATE_ and
										 	   gl_no in ('1351', '1352', '2151', '2152')
                						 group by gl_no)))
                  where f13 = f21;--f1351+f1352 = f2151+f2152;
		else
                select count(*)
				  into result
			      from (select round(sum(f1858)/1000) f1858,
							   round(sum(f1859)/1000) f1859,
							   round(sum(f2858)/1000) f2858,
							   round(sum(f2859)/1000) f2859,
							   round(sum(f1858+f1859)/1000) f18,
							   round(sum(f2858+f2859)/1000) f28
						  from (select dk,
									   decode(dk, '1858', bakiye, 0) f1858,
									   decode(dk, '1859', bakiye, 0) f1859,
									   decode(dk, '2858', bakiye, 0) f2858,
									   decode(dk, '2859', bakiye, 0) f2859
							      from (select gl_no dk,
                				  	   		   abs(round(sum(nvl(BAKIYE, 0))/1000))  bakiye
                                          from cbs_rpt_sn_balance
										 where DATE_NO = DATE_ and
										 	   gl_no in ('1858', '1859', '2858', '2859')
                						 group by gl_no)))
                  where f18=f28;--f1858+f1859 = f2858+f2859;
		 end if;
	  return result;
	end if;
  end;



  PROCEDURE FILL_SRV_FIRST_LEVEL(P_DATE DATE)
  IS
    RPT_DATE DATE := P_DATE;
  BEGIN
            delete from cbs_rpt_srv where date_no = RPT_DATE;
 			insert into cbs_rpt_srv
            select RPT_DATE,
            	   str_no,
            	   curr_code,
            	   sum(col1) col1,
            	   sum(col2) col2,
            	   sum(col4) col4
              from (select a.str_no,
                    	   b.CURR_CODE,
                    	   decode(a.col_no, 1, decode(a.abs_no, 1, abs(bakiye), bakiye)*sign_no, 0) col1,
                    	   decode(a.col_no, 2, decode(a.abs_no, 1, abs(bakiye), bakiye)*sign_no, 0) col2,
                    	   decode(a.col_no, 4, decode(a.abs_no, 1, abs(bakiye), bakiye)*sign_no, 0) col4
                      from cbs_rpt_srv_meta a,
                      	   cbs_rpt_sn_balance b
                     where table_name = 'SN balance' and
                     	   a.gl_no = b.gl_no and
                    	   b.date_no = RPT_DATE
					 union all
                    select a.str_no,
                    	   b.doviz_kod,
                    	   decode(a.col_no, 1, decode(a.abs_no, 1, abs(bakiye_lc), bakiye_lc)*sign_no, 0) col1,
                    	   decode(a.col_no, 2, decode(a.abs_no, 1, abs(bakiye_lc), bakiye_lc)*sign_no, 0) col2,
                    	   decode(a.col_no, 4, decode(a.abs_no, 1, abs(bakiye_lc), bakiye_lc)*sign_no, 0) col4
                      from cbs_rpt_srv_meta a,
                      	   cbs_dkhesap_gunluk_bakiye b
                     where table_name = 'cbs_dkhesap_gunluk_bakiye' and
                     	   a.gl_no = substr(b.numara,1, length(a.gl_no)) and
						   gun = to_number(to_char(RPT_DATE, 'dd')) and
						   ay = to_number(to_char(RPT_DATE, 'mm')) and
						   yil = to_number(to_char(RPT_DATE, 'yyyy'))
					 union all
	                select case when (b.vade_tarihi - RPT_DATE < 33) then 2
						   		when (b.vade_tarihi - RPT_DATE > 32 and b.vade_tarihi - RPT_DATE < 93) then 3
						   		when (b.vade_tarihi - RPT_DATE > 92 and b.vade_tarihi - RPT_DATE < 183) then 4
						   		when (b.vade_tarihi - RPT_DATE > 182 and b.vade_tarihi - RPT_DATE < 368) then 5
								when (b.vade_tarihi - RPT_DATE > 367) then 6
						   end str_no,
                    	   b.doviz_kodu,
                    	   decode(a.col_no, 1, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col1,
                    	   decode(a.col_no, 2, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col2,
                    	   decode(a.col_no, 4, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col4
                      from cbs_rpt_srv_meta a,
                      	   cbs_rpt_vadeli_gunsonu_faiz b
                     where table_name = 'cbs_hesap_gunluk_bakiye-cbs_rpt_vadeli_gunsonu_faiz' and
						   b.banka_tarihi = RPT_DATE and
                     	   a.gl_no = substr(b.musteri_dk_no,1, length(a.gl_no))
					 union all
	                select case when (b.kredi_vade - RPT_DATE < 33) then 2
						   		when (b.kredi_vade - RPT_DATE > 32 and b.kredi_vade - RPT_DATE < 93) then 3
						   		when (b.kredi_vade - RPT_DATE > 92 and b.kredi_vade - RPT_DATE < 183) then 4
						   		when ((b.kredi_vade - RPT_DATE > 182 and b.kredi_vade - RPT_DATE < 368) or (b.kredi_vade is null))then 5
								when (b.kredi_vade - RPT_DATE > 367) then 6
						   end str_no,
                    	   b.doviz_kodu,
                    	   decode(a.col_no, 1, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col1,
                    	   decode(a.col_no, 2, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col2,
                    	   decode(a.col_no, 4, decode(a.abs_no, 1, abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A')), Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BAKIYE, 0), 1,NULL,NULL,'N','A'))*sign_no, 0) col4
                      from cbs_rpt_srv_meta a,
                      	   cbs_rpt_kredi_gunsonu_faiz b
                     where table_name = 'cbs_hesap_gunluk_bakiye-cbs_rpt_kredi_gunsonu_faiz' and
						   b.banka_tarihi = RPT_DATE and
                     	   a.gl_no = substr(b.musteri_dk_no,1, length(a.gl_no))
					 union all
	                select case when (b.kredi_vade - RPT_DATE < 33) then 2
						   		when (b.kredi_vade - RPT_DATE > 32 and b.kredi_vade - RPT_DATE < 93) then 3
						   		when (b.kredi_vade - RPT_DATE > 92 and b.kredi_vade - RPT_DATE < 183) then 4
						   		when ((b.kredi_vade - RPT_DATE > 182 and b.kredi_vade - RPT_DATE < 368) or (b.kredi_vade is null))then 5
								when (b.kredi_vade - RPT_DATE > 367) then 6
						   end str_no,
                    	   b.doviz_kodu,
                    	   abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BIRIKMIS_FAIZ_TUTARI, 0), 1,NULL,NULL,'N','A')) col1,
                    	   0 col2,
                    	   0 col4
                      from cbs_rpt_kredi_gunsonu_faiz b
                     where b.banka_tarihi = RPT_DATE and
					 	   substr(b.musteri_dk_no,1, 1) = '1'
        			   union all
	                select case when (b.vade_tarihi - RPT_DATE < 33) then 2
						   		when (b.vade_tarihi - RPT_DATE > 32 and b.vade_tarihi - RPT_DATE < 93) then 3
						   		when (b.vade_tarihi - RPT_DATE > 92 and b.vade_tarihi - RPT_DATE < 183) then 4
						   		when (b.vade_tarihi - RPT_DATE > 182 and b.vade_tarihi - RPT_DATE < 368) then 5
								when (b.vade_tarihi - RPT_DATE > 367) then 6
						   end str_no,
                    	   b.doviz_kodu,
                    	   0 col1,
                    	   abs(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,'KZT',RPT_DATE, nvl(b.BIRIKMIS_FAIZ_TUTARI, 0), 1,NULL,NULL,'N','A')) col2,
                    	   0 col4
                      from cbs_rpt_vadeli_gunsonu_faiz b
                     where b.banka_tarihi = RPT_DATE and
                     	   substr(b.musteri_dk_no,1, 1) = '2'
        			   union all
                    select case when KEFALET_VADE_TARIHI - RPT_DATE < 33 then 2
            				   when (KEFALET_VADE_TARIHI - RPT_DATE > 32 and KEFALET_VADE_TARIHI - RPT_DATE < 93) then 3
            				   when (KEFALET_VADE_TARIHI - RPT_DATE > 92 and KEFALET_VADE_TARIHI - RPT_DATE < 183) then 4
            				   when ((KEFALET_VADE_TARIHI - RPT_DATE > 182 and KEFALET_VADE_TARIHI - RPT_DATE < 368) or (KEFALET_VADE_TARIHI IS NULL)) then 5
            				   when (KEFALET_VADE_TARIHI - RPT_DATE > 182 and KEFALET_VADE_TARIHI - RPT_DATE < 368) then 5
            			       when KEFALET_VADE_TARIHI - RPT_DATE > 367 then 6
						   end str_no,
				   		   DOVIZ_KODU,
						   0 col1,
						   0 col2,
						   abs(nvl(TOTAL, 0)) col4
                      from (select DOVIZ_KODU,
                           	   	  KEFALET_VADE_TARIHI,
                           	   	  GIRIS_TARIHI,
                           	   	  pkg_kur.doviz_doviz_karsilik(DOVIZ_KODU, 'KZT', RPT_DATE, pkg_teminat.SF_DIGER_GAYRINAKDI_TUTAR_AL(musteri_no,teminat_sira_no), 1, null, null, 'N', 'A') TOTAL
                             from cbs.CBS_KREDI_TEMINAT_TANIM_RAP
                            where ANA_TEMINAT_KODU='03' and tarih=RPT_DATE
                            union all
                           SELECT DOVIZ_KODU,
                           	   	  VADE_TARIHI,
                           	   	  DUZENLEME_TARIHI,
                           	   	  pkg_kur.doviz_doviz_karsilik(DOVIZ_KODU, 'KZT', RPT_DATE, TUTAR, 1, null, null, 'N', 'A')
                             FROM cbs.CBS_TM_ALINAN_GARANTI_RAP
                            where DURUM_KODU<>'IP' and tarih = RPT_DATE))
			WHERE STR_NO IS NOT NULL
            HAVING sum(col1) <> 0 or sum(col2) <> 0 or sum(col4) <> 0
             GROUP BY str_no, curr_code
             order by 1,2,3;
  END;

  PROCEDURE FILL_SRV_SECOND_LEVEL(P_DATE DATE)
  IS
    RPT_DATE DATE := P_DATE;--PKG_DATES.get_previous_work_date(P_DATE);
  BEGIN
            delete from cbs_rpt_srv_full where date_no = RPT_DATE;
            insert into CBS_RPT_SRV_FULL
            select date_no,
            	   str_no,
            	   curr,
            	   round(col1/1000) col1,
            	   round(col2/1000) col2,
            	   round(col4/1000) col4
              from cbs_rpt_srv
			 where date_no = RPT_DATE
              order by 1,2,3;
  END;

  PROCEDURE FILL_SN_SRV(P_DATE DATE)
  IS
  BEGIN
    PKG_SN_SRV.FILL_SN_FIRST_LEVEL(P_DATE);
    PKG_SN_SRV.FILL_SN_SECOND_LEVEL(P_DATE);
    PKG_SN_SRV.FILL_SRV_FIRST_LEVEL(P_DATE);
    PKG_SN_SRV.FILL_SRV_SECOND_LEVEL(P_DATE);
	--INSERT INTO CBS_RPT_SN_CHECK_LIST VALUES (P_DATE);
  --EXCEPTION
    --WHEN OTHERS THEN NULL;
  END;

  FUNCTION IS_RPT_SN_EXIST(P_DATE DATE) RETURN NUMBER
  IS
    RESULT NUMBER := 0;
  BEGIN
    SELECT COUNT(*)
	  INTO RESULT
	  FROM CBS_RPT_SN_BALANCE
	 WHERE DATE_NO = P_DATE;
	RETURN RESULT;
  END;

BEGIN
   NULL;
END PKG_SN_SRV;
/

