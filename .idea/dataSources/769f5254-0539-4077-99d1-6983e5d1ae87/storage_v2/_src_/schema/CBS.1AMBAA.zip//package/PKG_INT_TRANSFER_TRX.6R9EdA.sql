create PACKAGE     PKG_INT_TRANSFER_TRX IS 

TYPE CursorReferenceType IS REF CURSOR;
 
FUNCTION PostBookToBookTransfer(ps_lang varchar2,
                                ps_source_iban varchar2,
                                ps_target_iban varchar2,
                                ps_amount varchar2,
                                ps_description varchar2,
                                ps_transafer_type varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER',            
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType) RETURN varchar2;   

FUNCTION PostClearingTransfer(ps_lang varchar2,
                                ps_source_iban varchar2,
                                ps_target_full_name varchar2,
                                ps_target_iban varchar2,
                                ps_bic_code varchar2,
                                ps_payment_code varchar2,
                                ps_amount varchar2,
                                ps_description varchar2,
                                ps_transfer_type varchar2,
                                ps_tax_number varchar default null,
                                ps_source_name varchar default null,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER', 
                                pc_ref OUT CursorReferenceType, 
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType) RETURN varchar2;
  
FUNCTION PostCrossTransfer(ps_lang varchar2,
                                ps_source_iban varchar2,
                                ps_target_full_name varchar2,
                                ps_target_iban varchar2,
                                ps_bic_code varchar2,
                                ps_payment_code varchar2,
                                ps_amount varchar2,
                                ps_description varchar2,
                                ps_transfer_type varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER', 
                                pc_ref OUT CursorReferenceType, 
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType) RETURN varchar2;                    

function PostSwiftTransfer(ps_lang varchar2,
                                ps_source_iban varchar2,
                                ps_currency_code varchar2,
                                ps_country_code varchar2,
                                ps_swift_code varchar2,
                                ps_amount varchar2,       
                                ps_commission_type varchar2, 
                                ps_execution_type varchar2, 
                                ps_target_iban varchar2,
                                ps_target_bank_city_name varchar2,     
                                ps_target_full_name varchar2,  
                                ps_target_address varchar2, 
                                ps_target_phone_number varchar2,  
                                ps_target_passport varchar2,  
                                ps_payment_dest_code varchar2,                   
                                ps_purpose_code varchar2,
                                ps_payment_code varchar2,
                                ps_payment_details varchar2,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER', 
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType) RETURN varchar2;                            
END PKG_INT_TRANSFER_TRX;
/

