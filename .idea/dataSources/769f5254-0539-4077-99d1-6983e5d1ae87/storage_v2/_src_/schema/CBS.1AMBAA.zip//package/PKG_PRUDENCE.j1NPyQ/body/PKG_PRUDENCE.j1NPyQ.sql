create package body pkg_prudence
is

  function Capital(p_date DATE) return NUMBER
  is
    bak0 number;
  begin
    select sum(case when substr(numara,1,1) = '3' then abs(bakiye)
					when numara = '1659' then -abs(bakiye)
					when numara in ('1699', '8067') then abs(bakiye)
			    end) bakiye
	 into bak0
     from cbs_vw_sn_balance
    where DATE_NO=p_date and
		 (substr(numara,1,1) = '3' or
		  numara  in ('1659', '1699', '8067'));

      return bak0;
  end;

end pkg_prudence;
/

