create Package     PKG_KREDI_RAPOR is

/******************************************************************************
   NAME       : PKG_KREDI_RAPOR
   Created By : Seval Balci
   Date          : 19.01.04
   Purpose      :Kredi izleme ve rapor ile ilgili procedur ve fonksiyonlari icerir.
******************************************************************************/
/* Kredi vade faiz izleme ile ilgili */
 Function sf_birikmis_hesapla(ps_hesaplama_secimi varchar2,pn_gun number ,pn_tutar number,pn_oran number , ps_doviz_kodu varchar2 ,pn_esas_gun number default 360 ) return number;

 Function sf_vade_fark_sure(ps_songun_faizi varchar2,
                            pd_kredi_vade date ) return number;
 Function sf_faiztahak_fark_sure(ps_songun_faizi varchar2,
                            pd_faiztahak_tarihi date ) return number;

 Function sf_bsmv_hesapla(
                           ps_vade_faiz_tahak_secim varchar2,
                          ps_doviz_kodu varchar2,
                          ps_endeks_doviz_kodu varchar2,
                          pn_acilis_kuru number,
                          pn_hesap_no cbs_hesap_kredi.hesap_no%type,
                              pn_tutar number,
                          pn_endeks_doviz_tutar number,
                          ps_bsmv_alinsin varchar2 default 'E'  ) return number ;
 Function sf_kkdf_hesapla(
                          ps_vade_faiz_tahak_secim varchar2,
                          ps_doviz_kodu varchar2,
                          ps_endeks_doviz_kodu varchar2,
                          pn_sonislem_kuru number,
                          pn_hesap_no cbs_hesap_kredi.hesap_no%type,
                              pn_tutar number,
                          pn_endeks_doviz_tutar number,
                          ps_kkdf_alinsin varchar2 default 'E'  ) return number ;

procedure sp_birikmisfaiz_kkdfhesapla
  (
              pn_hesap_no                 number,
              ps_hesaplama_secimi      varchar2,
            pd_tarih2 date,
            pd_girilen_tarih date ,
            pn_birikmis_faiz out number,
            pn_birikmis_kom out number,
            pn_kkdf out number,
            pn_bsmv out number
         ) ;

 procedure sp_insert_kredivade_faiz (
                p_rapor_islem_no    cbs_rpt_kredivade_faiz.    rapor_islem_no%type,
                p_hesap_no    cbs_rpt_kredivade_faiz.    hesap_no%type,
                p_musteri_no    cbs_rpt_kredivade_faiz.    musteri_no%type,
                p_unvan    cbs_rpt_kredivade_faiz.    unvan%type,
                p_doviz_kodu    cbs_rpt_kredivade_faiz.    doviz_kodu%type,
                p_durum_kodu    cbs_rpt_kredivade_faiz.    durum_kodu%type,
                p_sube_kodu    cbs_rpt_kredivade_faiz.    sube_kodu%type,
                p_kredi_vade                            cbs_rpt_kredivade_faiz.kredi_vade%type,
                p_endeks_doviz_kodu                        cbs_rpt_kredivade_faiz.endeks_doviz_kodu%type,
                p_faiz_orani                            cbs_rpt_kredivade_faiz.faiz_orani%type,
                p_faiz_tahakkuk_tarihi                    cbs_rpt_kredivade_faiz.faiz_tahakkuk_tarihi%type,
                p_komisyon_orani                        cbs_rpt_kredivade_faiz.komisyon_orani%type,
                p_kredi_turu_nakit_gayri                cbs_rpt_kredivade_faiz.kredi_turu_nakit_gayri%type,
                p_bakiye                                cbs_rpt_kredivade_faiz.bakiye%type,
                p_birikmis_faiz_tutari                    cbs_rpt_kredivade_faiz.birikmis_faiz_tutari%type,
                p_birikmis_komisyon_tutari                cbs_rpt_kredivade_faiz.birikmis_komisyon_tutari%type,
                p_kkdf                                    number,
                p_bsmv                                    number,
                p_modul_tur_kod                            cbs_rpt_kredivade_faiz.modul_tur_kod%type,
                p_urun_tur_kod                            cbs_rpt_kredivade_faiz.urun_tur_kod%type,
                p_urun_sinif_kod                        cbs_rpt_kredivade_faiz.urun_sinif_kod%type
 );


 Function sf_vade_mevcutmu(pd_tarih date,pd_vade_tarih date ) return varchar2;
/* konsolide risk izleme ile ilgili fonk.*/
 Function sf_doviz_endk_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
 Function sf_nakdi_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
 Function sf_nakdi_yp_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
 Function sf_gayrinakdi_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
 Function sf_gayrinakdi_yp_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
 Function sf_leasing_tl_toplami(pn_musteri_no number, ps_durum_kodu varchar2 default 'A') return number;
/*kullandirilan kredi listesi ile ilgili */
 Function sf_kullandirim_tutar(pn_islem_kod number, pn_islem_no number) return number;
/* Teminat nakdi rapor */
 Function sf_tl_karsiligi_bul(ps_doviz_kodu varchar2 ,pn_tutar number, pd_date date default pkg_muhasebe.banka_tarihi_bul) return number;

 /* gun sonu rapor insert proc.*/
  PROCEDURE  sp_ins_rpt_teminat_ipotek_cuz( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
  PROCEDURE  sp_ins_rpt_teminat_nakit( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
  PROCEDURE  sp_ins_rpt_teminat_ipotek( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
  Function   sf_komisyon_oran_tutar_al(pn_islem_no number ,ps_oran_mi varchar2) return number;

/* ay yil sonu kredi faiz listesi*/
  PROCEDURE kredi_ayyilsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
/* gun sonu 2. faiz hesaplamas?ndan sonra ?al??t?r?lmal?d?r.*/
 Procedure kredi_gunsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);


 /****Bireysel kredi izleme****/
 /** gerek kalmadi ihtiyac durumunda kullanilmak ?zere commentlendi */
/* Function sf_vade_araligindami(pn_hesap_no number,ps_taksitdurum varchar2,pd_vade1 date,pd_vade2 date) return varchar2;
  Function sf_vade_tarihial(pn_hesap_no number,ps_taksitdurum varchar2,pd_vade1 date,pd_vade2 date) return date;
  Procedure sp_ins_cbs_rpt_bireysel_kredi (
             p_rapor_islem_no    number,
             ps_sql varchar2,
            ps_taksitdurum varchar2,
            pd_vade1 date,pd_vade2 date);
 */

 Function sf_valorlu_bakiye_al(pn_hesap_no number) return number;

 /* kredi teklif karar layoutlari ile ilgili */
 procedure sp_kredi_teklif_personel_al(ps_komite_tipi varchar2 default 'Y?NET?M KURULU',
                                           ps_unvan_1 out varchar2 ,
                                       ps_ad_1       out varchar2 ,
                                       ps_unvan_2 out varchar2 ,
                                       ps_ad_2       out varchar2 ,
                                       ps_unvan_3 out varchar2 ,
                                       ps_ad_3       out varchar2 ,
                                       ps_unvan_4 out varchar2 ,
                                       ps_ad_4       out varchar2 ,
                                       ps_unvan_5 out varchar2 ,
                                       ps_ad_5       out varchar2 ,
                                       ps_unvan_6 out varchar2 ,
                                       ps_ad_6       out varchar2 ,
                                       ps_unvan_7 out varchar2 ,
                                       ps_ad_7       out varchar2 );
Function sf_kredi_teminat_min_kosul_al(pn_teklif_no number,pn_teklif_satir_no number) return number;
Function sf_adres_al (pn_musteri_no number) return varchar2;
Function sf_adres_ilkod_al (pn_musteri_no number) return varchar2;
function sf_bireysel_anapara_bul(pn_hesap_no number) return number;
function acilis_tarihi(pn_hesap_no number) return date;
Function sf_Bankamiz_adres_al return varchar2;
Function sf_hesapdkno_al (pn_hesap_no number)  return varchar2;
/* Gayri nakdi krediler bilalg */
function komtiporanal (p_referans cbs_masraf_ith_ihr.referans%type, p_sira_no cbs_masraf_ith_ihr.sira_no%type)  return number;
PROCEDURE   teklif_kosullari_karsilandimi (
                pn_hesap_no                      number ,
             pn_musteri_no                     number,
                pn_kredi_teklif_satir_numara    number,
             pn_ref_no out number );
PROCEDURE TeminatEksikRaporla(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );
PROCEDURE TeminatEksikRaporlahesap(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );
PROCEDURE TeminatEksikRaporlamusteri(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );
  -- Tan?m : Teminat Eksigi olanlar?n CBS_RPT_TEMINAT_EKSIK Tablosuna insert edilmesini sa?lar.
  -- Yazar : Seval Balci
  -- Tarih : 09/01/2004
PROCEDURE   musteri_teklifkosulkarsilandi (
            pn_musteri_no                     number,
               pn_ref_no out number );

Function islem_yillkomoran_al(pn_islem_no number) return number;
/* ekstre ile ilgili */
Function sf_devirbakiyebul (pn_hesap_no number ,pd_bakiye_tarih date) return number ;
Function Sf_KrediHesap_UrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2;
/* kredi komitesi raporu */
Function sf_sektoradi_al(pn_musteri_no number) return varchar2 ;
Function sf_grupadi_al(pn_musteri_no number) return varchar2 ;
/* kredi adat raporu */
Function sf_faizorani_degistimi(pn_tx_no number ,pn_hesap_no number,pn_faiz_orani number) return varchar2 ;
Function sf_musteri_uygunmu(pn_musteri_no number) return varchar2;
Function sf_valbakiye_al(pn_hesap_no number ,pd_bakiye_tarih date) return number ;
/* kredi komitesi raporlari*/
Function sf_colletaraltype_al(pn_hesap_no number ) return varchar2;
Function sf_compoundintrate_al(pn_duration number ,pn_faiz_orani number ,ps_urun_sinif varchar2) return number;
Function EUR_AL return varchar2;
/*adat raporu */
Function sf_birikmisfaiz_al(pn_hesap_no number ,pd_tarih date) return number;
/* teminat eksik izleme lov*/
Function Sf_TeminatUrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2;
Function sf_teminatgruptoplam (pn_ref_no number,
                                pn_musteri_no number,
                                pn_hesap_no number,
                                pn_teklif_no number,
                                pn_teklif_satir_no number,
                               pn_grup_no number ,
                               pn_teminat_kullanilan_tutar number,
                               pn_teklif_tutar number) return number ;

PROCEDURE  sp_ins_rpt_nakdi_alco;
Function toplam_satir_dk_islem_kod (ps_bolum_kodu varchar2 ,ps_dk_no varchar2 ,ps_doviz_kodu varchar2 ,pd_date date default pkg_muhasebe.banka_tarihi_Bul,pn_islem_tanim_kod number default NULL ) return number;
-------------------------------------------------------------------------------------------------------------------------
Function sf_pastdue_principal_total(pn_ana_kredi_hesap_no number) return number;
Function sf_pastdue_interest_total(pn_ana_kredi_hesap_no number) return number;
Function sf_pastdue_tax_total(pn_ana_kredi_hesap_no number) return number;
Function sf_pastdue_princip_accrued_int(pn_ana_kredi_hesap_no number) return number;
Function sf_pastdue_int_penalty_days(pn_ana_kredi_hesap_no number,pd_bank_date date default pkg_muhasebe.banka_tarihi_bul) return number;
-------------------------------------------------------------------------------------------------------------------------
Function sf_date_of_last_payment(pn_ana_kredi_hesap_no number) return DATE; -- CQ5782 ASKHATS
Function sf_val_balance_of_last_payment(pn_ana_kredi_hesap_no number) return number;-- CQ5782 ASKHATS
-------------------------------------------------------------------------------------------------------------------------
Function sf_llp_amount(pn_kredi_hesap_no number) return number; --seval.colak  02082022 loan accrual modifications
End ;
/

