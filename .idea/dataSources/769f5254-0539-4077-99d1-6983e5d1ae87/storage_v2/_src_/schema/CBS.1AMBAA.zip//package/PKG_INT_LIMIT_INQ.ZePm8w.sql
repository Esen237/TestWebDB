create PACKAGE     PKG_INT_LIMIT_INQ IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION GetTopicLimit(ps_lang varchar2,
                            ps_limit_type varchar2 default null,
                            ps_code varchar2 default null,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType) RETURN varchar2;
                                                       
FUNCTION GetCustomerLimit(ps_lang varchar2,
                            ps_customer_id varchar2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType) RETURN varchar2;
                            
FUNCTION GetCustomerTopicLimit(ps_lang varchar2,
                            ps_customer_id varchar2,
                            ps_code varchar2,
                            ps_period varchar2 default null,
                            ps_currency_code varchar2 default null,
                            pc_ref OUT CursorReferenceType) RETURN varchar2;
                                  
FUNCTION CheckCustomerTopicLimit(ps_lang varchar2,
                            ps_customer_id varchar2,
                            ps_code varchar2,
                            ps_amount in varchar2,
                            ps_currency_code varchar2 default null,
                            pc_ref OUT CursorReferenceType) RETURN varchar2;
                            
FUNCTION GetTopicLimitName(ps_lang varchar2,
                            ps_code varchar2) RETURN varchar2;  
                                                                                                                                                                                                                                                                        
END;
/

