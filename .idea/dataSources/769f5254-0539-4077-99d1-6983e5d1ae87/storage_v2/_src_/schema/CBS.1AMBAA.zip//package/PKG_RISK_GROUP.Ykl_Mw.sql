create PACKAGE     PKG_RISK_GROUP IS

/******************************************************************************
   Name       : PKG_RISK_GROUP
   Created By : Aisuluu Dzhumalieva
   Date          : 06.06.2017
   Purpose      : procedures and functions for risk groups
******************************************************************************/

FUNCTION  Sf_risk_group_name( ps_grup_kodu CBS_RISK_GROUP_CODES.grup_kodu%TYPE) RETURN VARCHAR2;
FUNCTION SF_SECTOR_CODE_EXPLANATION(PN_SECTOR_CODE CBS_FINANS_KODLARI.FINANS_KODU%TYPE) RETURN CBS_FINANS_KODLARI.ACIKLAMA%TYPE;
FUNCTION  sf_GROUP_CODE_EXISTS(ps_group_code VARCHAR2) RETURN VARCHAR2 ;
Procedure Get_Related_Parties(pn_app_no number ,  pn_tx_no number);
Procedure Get_Related_Parties_cn(pn_cust_no number ,  pn_tx_no number);

end;
/

