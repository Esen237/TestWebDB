create PACKAGE BODY     Pkg_Personel IS
--------------------------------------------
PROCEDURE SP_LOG_PERSONEL_HESAP_ISLEM( pn_islem_no CBS_PERSONEL_HESAP_ISLEM.islem_no%type, pn_islem_kodu CBS_PERSONEL_HESAP_ISLEM.islem_kodu%type, pn_hesap_no CBS_PERSONEL_HESAP_ISLEM.hesap_no%type) is
  ls_maas_hesabi cbs_hesap.MAAS_HESAP_FLAG%type;
  ls_islem_durum cbs_islem.durum%type;
BEGIN

if pn_hesap_no is not null then
   begin
	select MAAS_HESAP_FLAG
	into ls_maas_hesabi
	from cbs_hesap
	where hesap_no=pn_hesap_no;

		Exception when no_data_found then ls_maas_hesabi := 'H';
	end;

  if ls_maas_hesabi='E'  then
     INSERT INTO CBS_PERSONEL_HESAP_ISLEM(ISLEM_NO, ISLEM_KODU, BOLUM_KODU, HESAP_NO)
     VALUES(pn_islem_no,pn_islem_kodu,pkg_baglam.bolum_kodu, pn_hesap_no);
  end if;

end if;
End;
----------
FUNCTION SF_FISTE_PERSONEL_HESABI_VARMI( pn_islem_no number) return varchar2 is
  ln_count number;
BEGIN

 select count(*)
 into ln_count
 from cbs_fis a, cbs_satir b
 where a.numara=b.fis_numara
 and a.islem_numara=pn_islem_no
 and pkg_hesap.Personel_Hesap_Mi(hesap_numara)=1
 and pkg_hesap.Personel_Bakiye_Gosterilsin(hesap_numara)=0;

 if nvl(ln_count,0)<>0 then
   return 'E';
 else
   return 'H';
 end if;

END;

FUNCTION KULLANICI_MAASHES_IZLEYEBILIR( pn_kullanici_kodu cbs_kullanici.KODU%type) return varchar2 is
  ln_count number;
  ln_personel_no number;
BEGIN
	select m.PERSONEL_NO
	into ln_personel_no
	from cbs_maas_hesap_izle m, cbs_kullanici k
	where m.personel_no = k.PERSONEL_NUMARA
	  and k.kodu=pn_kullanici_kodu;

	if nvl(ln_personel_no,0) > 0
	then
		return 'E';
	else
		return 'H';
	end if;

	Exception
		when others then
			return 'H';
/*
 select personel_numara
 into ln_personel_no
  from cbs_kullanici
  where kodu=pn_kullanici_kodu;

 select count(*)
  into ln_count
  from cbs_maas_hesap_izle
  where personel_no=ln_personel_no;

 if nvl(ln_count,0)<>0 then
   return 'E';
 else
   return 'H';
 end if;
*/
END;
---------------------------------------------------------------------------------------
FUNCTION TRAN_DISPLAY(pn_islem_no number) return varchar2 IS
  LN_ISLEM_KOD NUMBER;
BEGIN
    select distinct(i.islem_kod)
	  into LN_ISLEM_KOD
	  from cbs_fis f, cbs_islem i
	 where f.ISLEM_NUMARA = i.NUMARA and f.ISLEM_NUMARA = pn_islem_no;

	if LN_ISLEM_KOD='2150' then
	   return 'N';
	else
	   return 'Y';
	end if;
END;
--------------------------------------------------------------------------------------
Function Kullanici_Maas_Izleyebilir(pn_musteri number, ps_kullanici varchar2) return varchar2
is
	ln_cnt number;
	ln_cnt2 number;
	ln_personel_no number;
	ls_ret varchar2(1);
Begin
	 ls_ret := 'E';

	 select count(*)
	 into ln_cnt
	 from cbs_musteri
	 where musteri_no = pn_musteri
	   and PERSONEL_SICIL_NO is not null;

	 if ln_cnt = 1
	 then
	 	 ln_personel_no := pkg_kullanici.kullanici_personel_kodu_al(ps_kullanici);

		 select count(*)
		 into ln_cnt2
		 from cbs_maas_hesap_izle
		 where PERSONEL_NO = ln_personel_no;

		 if ln_cnt2 = 0
		 then
		 	 ls_ret := 'H';
		 end if;
	 end if;

	 return ls_ret;
END;
--------------------------------------------
FUNCTION Fis_PersonelHesapVarmi( pn_fis_no number ) RETURN varchar2
is
  ln_count number;
BEGIN

 select count(*)
 into ln_count
 from cbs_fis a, cbs_satir b
 where a.numara=b.fis_numara
 and a.numara=pn_fis_no
 and pkg_hesap.Personel_Hesap_Mi(hesap_numara)=1
 and pkg_hesap.Personel_Bakiye_Gosterilsin(hesap_numara)=0;

 if nvl(ln_count,0)<>0 then
   return 'E';
 else
   return 'H';
 end if;

 End;
--------------------------------------------
FUNCTION TRAN_DISPLAY_2(pn_islem_no number) return varchar2 IS
  LN_ISLEM_KOD NUMBER;
BEGIN
    select islem_kod
	  into LN_ISLEM_KOD
	  from cbs_islem
	 where NUMARA = pn_islem_no;

	if LN_ISLEM_KOD='2150' then
	   return 'N';
	else
	   return 'Y';
	end if;
END;
--------------------------------------------------------------------------------------
FUNCTION SF_FISTE_GOSTER(ps_hesap_tipi varchar2, ps_satir_hesap_no varchar2, pn_kullanici_sicil number, pn_fis_no number) return varchar2 is
	ln_cnt number;
	LN_ISLEM_KOD NUMBER;
BEGIN
	if ps_hesap_tipi <> 'DK'
	then
		select count(*)
		into ln_cnt
		from cbs_vw_hesap_izleme_2 h, cbs_musteri m
		where h.musteri_no = m.musteri_no
		  and h.hesap_no = ps_satir_hesap_no
		  and nvl(m.PERSONEL_SICIL_NO,pn_kullanici_sicil) <> pn_kullanici_sicil;

		 if nvl(ln_cnt,0) > 0 then
		   return 'H';
		 else
		   return 'E';
		 end if;
	 else
		select count(*)
		into ln_cnt
		from cbs_vw_hesap_izleme_2 h, cbs_musteri m
		where h.musteri_no = m.musteri_no
		  and nvl(m.PERSONEL_SICIL_NO,pn_kullanici_sicil) <> pn_kullanici_sicil
		  and to_char(h.hesap_no) in (select HESAP_NUMARA
		  	  			 	          from cbs_satir
							          where fis_numara = pn_fis_no
							          and hesap_tur_kodu <> 'DK');

		 if nvl(ln_cnt,0) > 0 then
		   return 'H';
		 else
		   return 'E';
		 end if;
	 end if;

	Exception
		when others then
			return 'H';
END;
--------------------------------------------------------------------------------------
FUNCTION Kullanicinin_Personel_No(ps_user varchar2) return varchar2 is
	ln_kul_per_sicil number;
BEGIN
	begin
		SELECT NVL(personel_numara,-2)
		INTO ln_kul_per_sicil
		FROM CBS_KULLANICI
		WHERE kodu = ps_user;

		exception
		when others then
			ln_kul_per_sicil := -2;
	end;
	return ln_kul_per_sicil;
END;
--------------------------------------------------------------------------------------
FUNCTION Personel_Hesap_Mi(pn_musteri_no number) RETURN NUMBER IS  --1 yes personel, else no
	ln_sicil_no 		  number;
BEGIN
	ln_sicil_no := pkg_musteri.Sf_PersonelSicilNoAl(pn_musteri_no);

	if nvl( ln_sicil_no ,0) <> 0 then
		return 1;
	else
		return 0;
	end if;
  
	EXCEPTION
		WHEN OTHERS THEN
			RETURN 0;
END;
-------------------------------------------------------------------------------------------------
/**********************************************************************************
     Name        :Permission to review loan accounts of DB staff in CBS   
    Created By   :Gulkaiyr Kalybek kyzy 15.09.2021 
    Purpose      :Loan_display_crd_card_rol
             
******************************************************************************/
Function Loan_display_crd_card_rol(ln_hesap_no number, pn_rol_numara number) return varchar2
is
    ps_rol_tanim cbs_rol.tanim%type;
    ln_count number;
    ln_loan_display cbs_rol.numara%type;
    pn_g_loan_spc varchar2(100);
    pn_g_loan_head varchar2(100);
          
 BEGIN 
  pkg_parametre.deger('CARD_DEPARTMENT_SCT',pn_g_loan_spc);
  pkg_parametre.deger('CARD_DEPUTY_HEAD',pn_g_loan_head);

 
  select tanim into ps_rol_tanim  from cbs_rol where numara= pn_rol_numara and numara in(pn_g_loan_spc,pn_g_loan_head);
   
 
    if ps_rol_tanim is not null  
        then
         select count(*) into ln_count  
           from cbs_vw_hesap_izleme  
             where hesap_no=ln_hesap_no and 
                   urun_tur_kod in ('RT-CARD','PD-CARD','CRD.CARD', 'PAST DUE','DEMAND DEP','CASH COLL.') and
                   urun_sinif_kod in ('OVERLIMIT-LC','CREDIT CARD-LC', 'LC','INSTALLMENT-LC', 'OVERBALANCE-LC');
      
           if ln_count > 0 then 
                RETURN 'E';
               ELSE
                  RETURN 'H';
               END IF;
    END IF;
    EXCEPTION
       WHEN NO_DATA_FOUND
       THEN
      RETURN 'H';
 End;
/****************************************************************************************/  

END;
/

