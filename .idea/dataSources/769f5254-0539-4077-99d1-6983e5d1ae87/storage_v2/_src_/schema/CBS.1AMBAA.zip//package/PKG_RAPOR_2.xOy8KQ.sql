create PACKAGE     Pkg_Rapor_2 IS
/******************************************************************************
   Name       : PKG_RAPOR_2
   Created By : G?lnihal Cengiz
   Date          : 03/12/2004
   Purpose      : Genel rapolar ve izlemelerde kullanilacak fonksiyonlar ve
                   procedure'lar yer alir.
******************************************************************************/
 FUNCTION  gunluk_dk_onceki_bakiye_al(ps_tarih VARCHAR2) RETURN NUMBER;
 FUNCTION  modul_adi_al(ps_modul_tur_kod IN CBS_MODUL_TUR.kod%TYPE) RETURN VARCHAR2;
 PROCEDURE Limit_Bilgi_Getir(pn_kod IN CBS_LIMIT.numara%TYPE,
                                pn_alt OUT NUMBER,pn_ust OUT NUMBER ,
                              ps_doviz_kod OUT VARCHAR2,ps_karsilik OUT VARCHAR2) ;
 PROCEDURE Zaman_Bilgi_Getir(pn_kod IN CBS_ZAMAN.numara%TYPE,
                                pn_bas OUT NUMBER,pn_bit OUT NUMBER ) ;
 FUNCTION program_adi_al(ps_program_kod IN CBS_PROGRAM.kod%TYPE) RETURN VARCHAR2 ;

 FUNCTION Neg_Bakiyeli_Urun_Tur_Uygun_mu(ps_urun_tur_kod CBS_URUN_TUR.KOD%TYPE) RETURN VARCHAR2;
 FUNCTION  dosya_bakiyesi_al(ps_referans VARCHAR2) RETURN NUMBER;
 FUNCTION  dk_adi_al(ps_numara VARCHAR2,ps_doviz varchar2) RETURN varchar2;
 Function DK_BUL_GETIR( pn_musteri_no in number 
                           ,ps_modul_tur_kod     IN VARCHAR2
                           ,ps_urun_tur_kod      IN VARCHAR2
                           ,ps_urun_sinif_kod    IN VARCHAR2
                           ,pn_gl_index          IN NUMBER) return varchar2;
 
 END;
/

