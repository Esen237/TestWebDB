create PACKAGE BODY     "PKG_DIRECT_DEBIT" is
 INPUT_PATH varchar2(200) :='CL_INBOX'; -- MaratM 01072021 D:\SHARED\CLEARING\INBOX\
 INPUT_PATH_DDS_XML varchar2(200) :='DDS';
 INPUT_PATH_DDS_XML_ARCH varchar2(200) :='DDS_ARCHIVE';

 l_uc VARCHAR2(3):=pkg_hata.getUCPOINTER;
 l_ara VARCHAR2(3):=pkg_hata.getDELIMITER;

--*************************************************************************************--
FUNCTION SplitStr(ps_str IN VARCHAR2,pn_valindx IN NUMBER ,ps_delimeter IN VARCHAR2 default ';;') RETURN VARCHAR2 IS
 ln_i NUMBER:=1;
 ln_itemindx NUMBER:=0;
 ls_strOut VARCHAR2(2000);
BEGIN
 LOOP
 EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
 IF ln_itemindx=pn_valindx THEN
 IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
 ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
 ELSE
 ls_strOut:=SUBSTR(ps_str,ln_i);
 END IF;

 RETURN ls_strOut;
 END IF;

 IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
 ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
 ELSE
 ln_i:=LENGTH(ps_str)+1;
 END IF;

 ln_itemindx:=ln_itemindx+1;
 END LOOP;
 RETURN '';
END;
--*************************************************************************************--
PROCEDURE MessageLoad(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'MESSAGELOAD' )
is
 f utl_file.file_type;
 ls_dirlist varchar2(2000);
 ln_filecount number;
 ln_fileindex number;
 ls_filename varchar2(20);
 ls_outstr varchar2(2000);
 ls_path varchar2(2000);
 ln_MSG_ID varchar2(2000);
 ls_MSG_TYPE varchar2(2000);
 ls_satir varchar2(2100);

 ls_par1 varchar2(200);
 ls_par2 varchar2(2000);
 ls_par3 varchar2(2000);
 ls_par4 varchar2(2000);
 ls_par5 varchar2(2000);
 ls_par6 varchar2(2000);
 ls_par7 varchar2(2000);
 ls_par8 varchar2(2000);
 ls_par9 varchar2(2000);
 ls_par10 varchar2(2000);
 ls_par11 varchar2(2000);
 ls_par12 varchar2(2000);
 ls_par13 varchar2(2000);
 ls_par14 varchar2(2000);
 ls_par15 varchar2(2000);
 ls_par16 varchar2(2000);
 ls_par17 varchar2(2000);
 ls_par18 varchar2(2000);
 ls_par19 varchar2(2000);
 ls_par20 varchar2(2000);
 ls_par21 varchar2(2000);
 ls_par22 varchar2(2000);
 ls_par23 varchar2(2000); --Yerzhan Tanatov, requested by NB --01122009
 ls_ad varchar2(2000);
 ln_sira_no number := 0;
 dosya_hata exception;
 v_ls_par4 varchar2(2000);
 v_ls_par4t varchar2(2000) := '0';
 v_ls_par4d varchar2(2000) := '0';
 n_ls_par4 NUMBER;
 ln_internal_no number;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6050'||Pkg_Hata.GetUCPOINTER);
 
 ln_internal_no :=pkg_genel.genel_kod_al('DIRECT_DEBIT');
 ls_path := INPUT_PATH;
 ls_filename:='DOCSMT104.IN';

 Begin
 f:=utl_file.fopen(ls_path, ls_filename, 'r',2100);
 Exception when others then
 raise dosya_hata ;
 End;

 ls_MSG_TYPE:='INCOMING';

 Begin
 LOOP
 utl_file.get_line(f, ls_outstr);

 IF ls_outstr IS NULL
 THEN
 RAISE NO_DATA_FOUND;
 END IF;

 ls_satir := ';;'|| ls_outstr ;

 ls_par1 := SplitStr(ls_satir,1); --Priority document
 ls_par2 := SplitStr(ls_satir,2); --Date of clearing session "YYYYMMDD" (example: 20020719)
 ls_par3 := SplitStr(ls_satir,3); --Number of clearing session
 ls_par4 := SplitStr(ls_satir,4); --Amount of document

 v_ls_par4 := REPLACE(REPLACE(ls_par4,',','#'),'.','#');

 v_ls_par4t := '0';
 v_ls_par4d := '0';

 IF instr(v_ls_par4,'#') >0 THEN
 v_ls_par4t := substr(v_ls_par4,1,instr(v_ls_par4,'#')-1);
 v_ls_par4d := substr(v_ls_par4,instr(v_ls_par4,'#')+1);
 ELSE
 v_ls_par4t := v_ls_par4;
 END IF;

 n_ls_par4 := to_number(v_ls_par4t) + to_number(v_ls_par4d)/100;

 ls_par5 := SplitStr(ls_satir,5); --Account of sender
 ls_par6 := SplitStr(ls_satir,6); --INN sender
 ls_par7 := SplitStr(ls_satir,7); --Code of OKPO sender
 ls_par8 := SplitStr(ls_satir,8); -- Registration number CFKR
 --5 fields description of sender
 ls_par9 := SplitStr(ls_satir,9) || ' ' ||
 SplitStr(ls_satir,10) || ' ' ||
 SplitStr(ls_satir,11) || ' ' ||
 SplitStr(ls_satir,12) || ' ' ||
 SplitStr(ls_satir,13);
 ls_par10 := SplitStr(ls_satir,14); --Code bic bank sender

 --5 fields description of bank sender
 ls_par11 := SplitStr(ls_satir,15) || ' ' ||
 SplitStr(ls_satir,16) || ' ' ||
 SplitStr(ls_satir,17) || ' ' ||
 SplitStr(ls_satir,18) || ' ' ||
 SplitStr(ls_satir,19);
 ls_par12 := SplitStr(ls_satir,20); --Code bic bank receiver
 --5 fields description of bank receiver
 ls_par13 := SplitStr(ls_satir,21) || ' ' ||
 SplitStr(ls_satir,22) || ' ' ||
 SplitStr(ls_satir,23) || ' ' ||
 SplitStr(ls_satir,24) || ' ' ||
 SplitStr(ls_satir,25);

 ls_par14 := SplitStr(ls_satir,26); --Account of receiver
 ls_par15 := SplitStr(ls_satir,27); --Sub-Account of receiver

 --Description of receiver
 ls_par16 := SplitStr(ls_satir,28) || ' ' ||
 SplitStr(ls_satir,29) || ' ' ||
 SplitStr(ls_satir,30) || ' ' ||
 SplitStr(ls_satir,31) || ' ' ||
 SplitStr(ls_satir,32);

 --10 fields of payment assignment
 ls_par17 := substr(SplitStr(ls_satir,33) || ' ' ||
 SplitStr(ls_satir,34) || ' ' ||
 SplitStr(ls_satir,35) || ' ' ||
 SplitStr(ls_satir,36) || ' ' ||
 SplitStr(ls_satir,37) || ' ' ||
 SplitStr(ls_satir,38) || ' ' ||
 SplitStr(ls_satir,39) || ' ' ||
 SplitStr(ls_satir,40) || ' ' ||
 SplitStr(ls_satir,41) || ' ' ||
 SplitStr(ls_satir,42),1,200);

 ls_par18 := SplitStr(ls_satir,43); --Number of document
 ls_par19 := SplitStr(ls_satir,44);--Type of message
 ls_par20 := SplitStr(ls_satir,45);--Code payment
 ls_par21 := SplitStr(ls_satir,46);--Date of document "YYYYMMDD" (example: 20020719)
 ls_par23 := SplitStr(ls_satir,47);--Message reference, unique NB message ID
 ln_sira_no := ln_sira_no + 1 ;

 INSERT INTO CBS_DIRECT_DEBIT_DATA (
 internal_no,
 sira_no,
 PRIORITY,
 MATURITY_DATE,
 REFERENCE,
 AMOUNT,
 FROM_ACCOUNT_EXTERNAL_NUMBER,
 FROM_RNN,
 FROM_OKPO,
 FROM_SOCIAL_FUND_NUMBER,
 FROM_DESCRIPTION,
 FROM_BANKBICCODE,
 FROM_BANKNAME,
 TO_BANKBICCODE,
 TO_BANKNAME,
 TO_ACCOUNT_EXTERNAL_NUMBER,
 TO_SUBACCOUNT,
 TO_NAME,
 PURPOSE,
 DOCUMENT_NO,
 MSG_TYPE,
 PAYMENT_TYPE,
 DOCUMENT_DATE,
 FILE_NAME,
 BANK_DATE,
  COMES_FROM_UC,
 MESSAGE_REFERENCE,
 file_id_no)
 VALUES (
 ln_internal_no,
 ln_sira_no,
 ls_par1,
 TO_DATE(ls_par2,'YYYYMMDD'),
 ls_par3,
 n_ls_par4,--AMOUNT
 ls_par5,
 ls_par6,
 ls_par7,
 ls_par8,
 ls_par9,
 ls_par10,
 ls_par11,
 ls_par12,
 ls_par13,
 ls_par14,
 ls_par15,
 ls_par16,
 ls_par17,
 ls_par18,
 ls_par19,
 ls_par20,
 ls_par21,
 ls_filename,
 pkg_muhasebe.Banka_Tarihi_Bul,
  'N',
 ls_par23,
 ln_internal_no);
 END LOOP;

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
 pkg_dosya.dosya_kapa('r');
 End;

 COMMIT;

 Begin
 pkg_dosya.kopyala( ls_path,ls_filename,ls_path||'\archive',ls_filename ||to_char(sysdate,'DDMMYYYHH24MI') );
 PKG_DOSYA.DOSYA_SIL (ls_path, ls_filename );

 Exception
 when others then
 Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6046'||Pkg_Hata.GetUCPOINTER);
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 End ;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 Exception
 WHEN dosya_hata then
 log_at('hakan_dd_error1',sqlcode,sqlerrm);
 if nvl(ln_sira_no,0) = 0 then
 Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6046'||Pkg_Hata.GetUCPOINTER);
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 end if;
 WHEN OTHERS THEN
      --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','Error in Message Load','Error is: dosya hata');
 log_at('hakan_dd_error2',sqlcode,sqlerrm);
 Log_At('hakan_CBS_DIRECT_DEBIT_DATA',sqlcode||' '|| substr(sqlerrm,1,200), ls_outstr,ls_par1||','||ls_par2||','||ls_par3||','||
 ls_par4||','||ls_par5||','||ls_par6||','||ls_par7||','||ls_par8||','||ls_par9||','||
 ls_par10||','||ls_par11||','||ls_par12||','||ls_par13||','||ls_par14||','||ls_par15||','||
 ls_par16||','||ls_par17||','||ls_par18||','||ls_par19||','||ls_par20||','||ls_par21||','||
 ls_par22);
 utl_file.fclose(f);
 --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','Error in Message Load','Error is: '||sqlerrm);
 Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6046'||Pkg_Hata.GetUCPOINTER);
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
--------------------------------------------------------------------------------------------------------------
PROCEDURE MakePayment(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'MAKEPAYMENT' )
is
 varchar_list Pkg_Muhasebe.varchar_array;
 number_list Pkg_Muhasebe.number_array;
 date_list Pkg_Muhasebe.date_array;
 boolean_list Pkg_Muhasebe.boolean_array;

 ln_counter number;
 ln_temp_numara number;
 ln_islem_no number;
 ln_fis_numara number;
 ln_fis_numara_gecici number;

 p_7062_SUBE number;
 p_7062_HESAP number;
 p_7062_MB_HESAP number;
 p_7062_MB_SUBE number;
 p_7062_TUTAR number;
 p_7062_ACIKLAMA number;
 p_7062_MASRAF_DK number;
 p_7062_COMM_TUTAR number;
 p_7062_COMM_ACIKLAMA number;
 p_7062_MATURITY_DATE number;
 p_7062_MASRAF number;
 p_7062_MASRAF_ACIKLAMA number;
 p_7062_TAX_ACIKLAMA number;
 p_7062_TAX_TUTAR number;

    p_7062_CONV_HESAP     NUMBER;
    p_7062_CONV_BR      NUMBER;
    p_7062_CONV_CY         NUMBER;
    p_7062_CONV_ACIKLAMA               NUMBER;
    p_7062_CONV_FC_AMNT             NUMBER;
    p_7062_CONV_LC_AMNT          NUMBER;
    p_7062_CONV_RATE          NUMBER;
 --Yerzhan Tanatov for rate difference
    p_7062_CONV_RET_LC_AMNT NUMBER;
 p_7062_CUSTOMER_RATE_LESS NUMBER;
 p_7062_CUSTOMER_RATE_MORE NUMBER;
 p_7062_RATE_DIFF_AMOUNT NUMBER;
 p_our_buy_rate number;

 ln_cnt number;
    
 CURSOR c1 IS
 SELECT *
 FROM CBS_DIRECT_DEBIT_DATA
 WHERE BANK_DATE = pkg_muhasebe.Banka_Tarihi_Bul
 AND STATUS = 'NEW'
     and nvl(comes_from_uc,'N') = 'N'   --Sevalb 03022012   phase-1 accounting kismina phase-2 kesinlikle girmemesi istendi.  
        ORDER BY MATURITY_DATE, INTERNAL_NO, SIRA_NO;
 r1 c1%ROWTYPE;

 CURSOR c_hesap(pn_customer_no number) IS
 SELECT account_no
        FROM cbs_direct_debit_hesap
 WHERE customer_no = pn_customer_no;
 r_hesap c_hesap%ROWTYPE;

    CURSOR c_fx(pn_musteri number, pn_account number) IS
 SELECT decode(h.doviz_kodu,pkg_genel.lc_al,'1','2') Sira,h.*
        FROM cbs_hesap h
        WHERE musteri_no = pn_musteri
         and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) > 0
         and durum_kodu = 'A'
         and hesap_no <> pn_account
         and hesap_no in (select account_no
                            from cbs_direct_debit_hesap
                         where customer_no = pn_musteri)
         order by sira,rownum;
    r_fx c_fx%ROWTYPE;

 ln_account NUMBER;
 ln_islem_no_gecici NUMBER;
 ln_rej_komisyon number;
 ls_DIRECT_DEBIT varchar2(1);

 ls_7062_NB_ACC varchar2(20);
 ls_7062_NB_ACC_BR varchar2(10);
 ls_masraf_dk varchar2(30);
 ln_masraf number;
 ln_masrafli_tutar number;
 ln_rate number;
 ln_tax number;
 ln_rej_tax number;
 ls_DIRECT_DEBIT_ANNUAL varchar2(1);
    ln_customer                    number;
    ln_toplam_bakiye            number;
    ln_total_balance            number;
    ln_hesaptan_al                number;
    ln_kalan_tahsilat             number;
    ln_plan                        number;
    ln_original_kur             number;
    ln_hesap_kur                 number;
    ln_hesaptan_tutar             number;
    ln_bakiye                     number;
    ln_bakiye_fx                     number;
    ln_bakiye_dvz                 number;
    No_Uc_Account                Exception;
    ln_cnt_2                    number;
  
begin
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 p_7062_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_SUBE');
 p_7062_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_HESAP');
 p_7062_MB_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_MB_HESAP');
 p_7062_MB_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_MB_SUBE');
 p_7062_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_ACIKLAMA');
 p_7062_MASRAF_DK :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF_DK');
 p_7062_COMM_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_ACIKLAMA');
 p_7062_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TUTAR');
 p_7062_COMM_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_TUTAR');
 p_7062_MATURITY_DATE :=Pkg_Muhasebe.parametre_index_bul('7062_MATURITY_DATE');
 p_7062_MASRAF :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF');
 p_7062_MASRAF_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF_ACIKLAMA');
 p_7062_TAX_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_ACIKLAMA');
 p_7062_TAX_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_TUTAR');

 p_7062_CONV_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_HESAP');
 p_7062_CONV_BR :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_BR');
 p_7062_CONV_CY :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_CY');
 p_7062_CONV_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_ACIKLAMA');
 p_7062_CONV_FC_AMNT :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_FC_AMNT');
 p_7062_CONV_LC_AMNT :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_LC_AMNT');
 p_7062_CONV_RATE :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RATE');

 --Yerzhan Tanatov for rate difference
 p_7062_CONV_RET_LC_AMNT :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RET_LC_AMNT'); --
 p_7062_CUSTOMER_RATE_LESS :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_LESS');
 p_7062_CUSTOMER_RATE_MORE :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_MORE');
 p_7062_RATE_DIFF_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7062_RATE_DIFF_AMOUNT');

 Pkg_Parametre.deger('3555_NB_ACC',ls_7062_NB_ACC);

 ls_7062_NB_ACC_BR := pkg_hesap.HesaptanSubeAl(ls_7062_NB_ACC);

 ln_rate := 2;

 OPEN c1 ;
 LOOP
 FETCH c1 INTO r1;
 EXIT WHEN c1%NOTFOUND;
 
 begin
 ln_account := pkg_hesap.GetHesapNoFromExternal(r1.TO_ACCOUNT_EXTERNAL_NUMBER,pkg_genel.LC_al);
 exception
 when others then
 ln_account := NULL;
 end;

 ln_customer := pkg_hesap.HesaptanMusteriNoAl(ln_account);
 
        select count(*)
        into ln_cnt
        from cbs_direct_debit_hesap
        where customer_no = ln_customer;

        if ln_cnt = 0
        then

     varchar_list(p_7062_SUBE) := NULL;
     varchar_list(p_7062_HESAP) := NULL;
     varchar_list(p_7062_MB_HESAP) := NULL;
     varchar_list(p_7062_MB_SUBE) := NULL;
     varchar_list(p_7062_ACIKLAMA) := NULL;
     varchar_list(p_7062_MASRAF_DK) := NULL;
     varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
     number_list(p_7062_MASRAF):= 0;
     number_list(p_7062_TAX_TUTAR):= 0;
     varchar_list(p_7062_MASRAF_ACIKLAMA) := NULL;
     varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
     number_list(p_7062_TUTAR):= 0;
     number_list(p_7062_COMM_TUTAR):= 0;
     date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

     ln_rej_komisyon := 0;
     ln_bakiye := 0;
     ln_masraf := 0;
     ln_masrafli_tutar := 0;
     ln_tax := 0;

     begin
     select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
     into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
     from cbs_hesap
     where hesap_no = nvl(ln_account,0);
     exception
     when others then
     ls_DIRECT_DEBIT := 'H';
     end;
    
     if ln_account is null or ls_DIRECT_DEBIT = 'H'
     then
     update CBS_DIRECT_DEBIT_DATA
     set COMM_AMOUNT = 0,
     STATUS = (case when ln_account is null then 'NO ACCOUNT' else 'NOT ACTIVE' end),
     PAYMENT_CHARGED = 'H',
     CHARGED_PAYMENT_AMOUNT = 0,
     COMMISSION_CHARGED = 'H',
     CHARGED_COMMISSION_AMOUNT = 0
     WHERE INTERNAL_NO = r1.INTERNAL_NO
     and SIRA_NO = r1.SIRA_NO;
        
     else 
     ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');

     varchar_list(p_7062_MASRAF_ACIKLAMA) := 'Commmission of Direct Debit for Account : '||ln_account;
     varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;

     ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);

     if nvl(ls_DIRECT_DEBIT_ANNUAL,'H') = 'E'
     then
     ln_masraf := 0;
     else
     ln_masraf := CBS.pkg_direct_debit.Clearing_Comm_Amount(r1.amount);
     end if;

     ln_tax := round(((nvl(ln_masraf,0)*nvl(ln_rate,0))/100),2);
     ln_masrafli_tutar := round((nvl(r1.AMOUNT,0)+nvl(ln_masraf,0)+nvl(ln_tax,0)),2);
     ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);
                    
     if r1.maturity_date > pkg_muhasebe.Banka_Tarihi_Bul
     then
     if ln_bakiye >= ln_masrafli_tutar
     then
     varchar_list(p_7062_HESAP) := ln_account;
     varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                        if r1.comes_from_uc = 'Y'
                        then
                            select count(*)
                            into ln_cnt_2
                            from cbs_hesap
                            where durum_kodu = 'A'
                             and hesap_no = nvl(r1.UC_ACCOUNT,0);

                            if ln_cnt_2 <> 1
                            then
                                raise No_Uc_Account;
                            else
             varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
             varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                            end if;
                        else
         varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                            varchar_list(p_7062_MB_SUBE) := ls_7062_NB_ACC_BR;
                        end if;

     varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
     number_list(p_7062_TUTAR):= r1.amount;
     date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

     number_list(p_7062_MASRAF):= ln_masraf;
     number_list(p_7062_TAX_TUTAR):= ln_tax;
     varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

     ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

     ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
     2,
     ln_islem_no,
     varchar_list,
     number_list,
     date_list,
     boolean_list ,
     NULL,
     FALSE,
     0,
     'Direct Debitting - On Value Date');

     ln_islem_no_gecici:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
     Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

     ln_fis_numara_gecici:=Pkg_Muhasebe.fis_kes(7062,
     3,
     ln_islem_no_gecici,
     varchar_list,
     number_list,
     date_list,
     boolean_list ,
     r1.maturity_date,
     FALSE,
     0,
     'Direct Debitting - On Maturity Date');

     update CBS_DIRECT_DEBIT_DATA
     set COMM_AMOUNT = 0,
     STATUS = 'DONE - FUTURE',
     PAYMENT_CHARGED = 'E',
     CHARGED_PAYMENT_AMOUNT = r1.amount,
     CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
     CHARGED_COMMISSION_AMOUNT = 0,
     COMMISSION_CHARGED = 'H',
     TEMPORARY_JOURNAL_NO = ln_fis_numara_gecici,
     TEMPORARY_TX_NO = ln_islem_no_gecici,
     JOURNAL_NO = ln_fis_numara,
     TX_NO = ln_islem_no,
     ACCOUNT_BALANCE = ln_bakiye
     WHERE INTERNAL_NO = r1.INTERNAL_NO
     and SIRA_NO = r1.SIRA_NO;
     else
     update CBS_DIRECT_DEBIT_DATA
     set STATUS = 'FUTURE',
     PAYMENT_CHARGED = 'H',
     CHARGED_PAYMENT_AMOUNT = 0,
     CHARGED_COMMISSION_AMOUNT = 0,
     COMMISSION_CHARGED = 'H'
     WHERE INTERNAL_NO = r1.INTERNAL_NO
     and SIRA_NO = r1.SIRA_NO;
     end if;
     end if;
                
     if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul
     then 
     if ln_bakiye >= ln_masrafli_tutar
     then
     varchar_list(p_7062_HESAP) := ln_account;
     varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                        if r1.comes_from_uc = 'Y'
                        then
                            select count(*)
                            into ln_cnt_2
                            from cbs_hesap
                            where durum_kodu = 'A'
                             and hesap_no = nvl(r1.UC_ACCOUNT,0);

                            if ln_cnt_2 <> 1
                            then
                                raise No_Uc_Account;
                            else
             varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
             varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                            end if;
                        else
         varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
         varchar_list(p_7062_MB_SUBE) := ls_7062_NB_ACC_BR;
                        end if;

     varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
     number_list(p_7062_TUTAR):= r1.amount;
     number_list(p_7062_MASRAF):= ln_masraf;

     number_list(p_7062_TAX_TUTAR):= ln_tax;
     varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                            1,
                                                            ln_islem_no,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            NULL,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Value Date - Value Date is banking date');
                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = 0,
                            STATUS  = 'DONE',
                            PAYMENT_CHARGED = 'E',
                            CHARGED_PAYMENT_AMOUNT = r1.amount,
                            CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            JOURNAL_NO = ln_fis_numara,
                            TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    else
                        ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);

                        if ln_bakiye >= round((ln_rej_komisyon + ln_rej_tax),2)
                        then
                            varchar_list(p_7062_HESAP) := ln_account;
                            varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                            varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;
                            number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                            number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                            varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                            ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                4,
                                                                ln_islem_no,
                                                                varchar_list,
                                                                number_list,
                                                                date_list,
                                                                boolean_list ,
                                                                NULL,
                                                                FALSE,
                                                                0,
                                                                'Direct Debitting - Reject Commission');

                            Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                            update CBS_DIRECT_DEBIT_DATA
                            set COMM_AMOUNT = ln_rej_komisyon,
                                STATUS  = 'REJECTED - COMM CHARGED',
                                PAYMENT_CHARGED = 'H',
                                CHARGED_PAYMENT_AMOUNT = 0,
                                COMMISSION_CHARGED = 'E',
                                CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                                COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                                COMM_JOURNAL_NO = ln_fis_numara,
                                COMM_TX_NO = ln_islem_no,
                                ACCOUNT_BALANCE = ln_bakiye        
                            WHERE INTERNAL_NO = r1.INTERNAL_NO
                              and SIRA_NO = r1.SIRA_NO;
                            
                        else
                            update CBS_DIRECT_DEBIT_DATA
                            set COMM_AMOUNT = ln_rej_komisyon,
                                STATUS  = 'REJECTED - COMM MISSING',
                                PAYMENT_CHARGED = 'H',
                                CHARGED_PAYMENT_AMOUNT = 0,
                                COMMISSION_CHARGED = 'H',
                                CHARGED_COMMISSION_AMOUNT = 0,
                                ACCOUNT_BALANCE = ln_bakiye
                            WHERE INTERNAL_NO = r1.INTERNAL_NO
                              and SIRA_NO = r1.SIRA_NO;
                            
                        end if;
                    end if;
                end if;
            end if;
            --
            --
        else  ------------ if primary account's balance is not enough, check the other accounts of customer

            varchar_list(p_7062_SUBE) := NULL;
            varchar_list(p_7062_HESAP) := NULL;
            varchar_list(p_7062_MB_HESAP) := NULL;
            varchar_list(p_7062_MB_SUBE) := NULL;
            varchar_list(p_7062_ACIKLAMA) := NULL;
            varchar_list(p_7062_MASRAF_DK) := NULL;
            varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
            number_list(p_7062_MASRAF):= 0;
            number_list(p_7062_TAX_TUTAR):= 0;
            varchar_list(p_7062_MASRAF_ACIKLAMA) := NULL;
            varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
            number_list(p_7062_TUTAR):= 0;
            number_list(p_7062_COMM_TUTAR):= 0;
            date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

            ln_rej_komisyon := 0;
            ln_bakiye := 0;
            ln_total_balance  := 0;
            ln_masraf := 0;
            ln_masrafli_tutar := 0;
            ln_tax := 0;
            ln_counter := 0;

            begin
                select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
                into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
                from cbs_hesap
                where hesap_no = nvl(ln_account,0);
            exception
            when others then
                ls_DIRECT_DEBIT := 'H';
            end;

            if ln_account is null or ls_DIRECT_DEBIT = 'H'
            then
                update CBS_DIRECT_DEBIT_DATA
                set COMM_AMOUNT = 0,
                    STATUS  = (case when ln_account is null then 'NO ACCOUNT' else 'NOT ACTIVE' end),
                    PAYMENT_CHARGED = 'H',
                    CHARGED_PAYMENT_AMOUNT = 0,
                    COMMISSION_CHARGED = 'H',
                    CHARGED_COMMISSION_AMOUNT = 0
                WHERE INTERNAL_NO = r1.INTERNAL_NO
                  and SIRA_NO = r1.SIRA_NO;
                
            else
                 ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');

                varchar_list(p_7062_MASRAF_ACIKLAMA) := 'Commmission of Direct Debit for Account : '||ln_account;
                varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;

                ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);
                ln_total_balance := pkg_direct_debit.Customer_Total_Balance(ln_customer, ln_account);

                if nvl(ls_DIRECT_DEBIT_ANNUAL,'H') = 'E'
                then
                    ln_masraf := 0;
                else
                    ln_masraf := pkg_direct_debit.Clearing_Comm_Amount(r1.amount);
                end if;

                ln_tax := round(((nvl(ln_masraf,0)*nvl(ln_rate,0))/100),2);
                ln_masrafli_tutar := round((nvl(r1.AMOUNT,0)+nvl(ln_masraf,0)+nvl(ln_tax,0)),2);
                ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);

                if r1.maturity_date > pkg_muhasebe.Banka_Tarihi_Bul
                then
                    if ln_total_balance >= ln_masrafli_tutar
                    then
                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                        if r1.comes_from_uc = 'Y'
                        then
                            select count(*)
                            into ln_cnt_2
                            from cbs_hesap
                            where durum_kodu = 'A'
                              and hesap_no = nvl(r1.UC_ACCOUNT,0);

                            if ln_cnt_2 <> 1
                            then
                                raise No_Uc_Account;
                            else
                                varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                                varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                            end if;
                        else
                            varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                            varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                        end if;

                        varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                        number_list(p_7062_TUTAR):= r1.amount;
                        date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

                        number_list(p_7062_MASRAF):= ln_masraf;
                        number_list(p_7062_TAX_TUTAR):= ln_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ----  FX CONV HERE
                        if ln_bakiye < ln_masrafli_tutar
                        then
                            ln_hesaptan_al := 1;
                            ln_kalan_tahsilat := round((nvl(ln_masrafli_tutar,0)-nvl(ln_bakiye,0)),2);

                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;
                    
                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                                                

                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;

                                    IF ln_counter = 0
                                    THEN
                                         ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                         ln_plan,
                                                                         ln_islem_no,
                                                                         varchar_list,
                                                                         number_list,
                                                                         date_list,
                                                                         boolean_list ,
                                                                         NULL,
                                                                         FALSE,
                                                                         0,
                                                                         'Direct Debitting - On Value Date');
                                    ELSE
                                        ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                                 ln_plan,
                                                                                 ln_fis_numara,
                                                                                 varchar_list,
                                                                                 number_list,
                                                                                 date_list,
                                                                                 boolean_list,
                                                                                 NULL,
                                                                                 FALSE);
                                    END IF;

                                    ln_counter:=ln_counter+1;

                                    if ln_kalan_tahsilat = 0
                                    then
                                        ln_hesaptan_al := 0;
                                    end if;
                                end if;
                            END LOOP;
                            CLOSE c_fx;

                        end if;
                    ----  FX CONV HERE

                        IF ln_counter = 0
                        THEN
                             ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                             2,
                                                             ln_islem_no,
                                                             varchar_list,
                                                             number_list,
                                                             date_list,
                                                             boolean_list ,
                                                             NULL,
                                                             FALSE,
                                                             0,
                                                             'Direct Debitting - On Value Date');
                        ELSE
                            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                     2,
                                                                     ln_fis_numara,
                                                                     varchar_list,
                                                                     number_list,
                                                                     date_list,
                                                                     boolean_list,
                                                                     NULL,
                                                                     FALSE);
                        END IF;

                        ln_counter:=ln_counter+1;

                        ln_islem_no_gecici:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        ln_fis_numara_gecici:=Pkg_Muhasebe.fis_kes(7062,
                                                            3,
                                                            ln_islem_no_gecici,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            r1.maturity_date,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Maturity Date');

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = 0,
                            STATUS  = 'DONE - FUTURE',
                            PAYMENT_CHARGED = 'E',
                            CHARGED_PAYMENT_AMOUNT = r1.amount,
                            CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                            CHARGED_COMMISSION_AMOUNT = 0,
                            COMMISSION_CHARGED = 'H',
                            TEMPORARY_JOURNAL_NO = ln_fis_numara_gecici,
                            TEMPORARY_TX_NO = ln_islem_no_gecici,
                            JOURNAL_NO = ln_fis_numara,
                            TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    else
                        update CBS_DIRECT_DEBIT_DATA
                        set STATUS  = 'FUTURE',
                            PAYMENT_CHARGED = 'H',
                            CHARGED_PAYMENT_AMOUNT = 0,
                            CHARGED_COMMISSION_AMOUNT = 0,
                            COMMISSION_CHARGED = 'H'
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    end if;
                end if;
                if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul
                then
                    if ln_total_balance >= ln_masrafli_tutar
                    then
                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                        if r1.comes_from_uc = 'Y'
                        then
                            select count(*)
                            into ln_cnt_2
                            from cbs_hesap
                            where durum_kodu = 'A'
                              and hesap_no = nvl(r1.UC_ACCOUNT,0);

                            if ln_cnt_2 <> 1
                            then
                                raise No_Uc_Account;
                            else
                                varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                                varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                            end if;
                        else
                            varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                            varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                        end if;

                        varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                        number_list(p_7062_TUTAR):= r1.amount;
                        number_list(p_7062_MASRAF):= ln_masraf;

                        number_list(p_7062_TAX_TUTAR):= ln_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ----  FX CONV HERE
                        if ln_bakiye < ln_masrafli_tutar
                        then
                            ln_hesaptan_al := 1;
                            ln_kalan_tahsilat := round((nvl(ln_masrafli_tutar,0)-nvl(ln_bakiye,0)),2);

                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;

                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                

                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;                                            
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;
                                     
                                    IF ln_counter = 0
                                    THEN
                                         ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                         ln_plan,
                                                                         ln_islem_no,
                                                                         varchar_list,
                                                                         number_list,
                                                                         date_list,
                                                                         boolean_list ,
                                                                         NULL,
                                                                         FALSE,
                                                                         0,
                                                                         'Direct Debitting - On Value Date');
                                    ELSE
                                        ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                                 ln_plan,
                                                                                 ln_fis_numara,
                                                                                 varchar_list,
                                                                                 number_list,
                                                                                 date_list,
                                                                                 boolean_list,
                                                                                 NULL,
                                                                                 FALSE);
                                    END IF;

                                    ln_counter:=ln_counter+1;

                                    if ln_kalan_tahsilat = 0
                                    then
                                        ln_hesaptan_al := 0;
                                    end if;
                                end if;
                            END LOOP;
                            CLOSE c_fx;
                        end if;
                    ----  FX CONV HERE

                        IF ln_counter = 0
                        THEN
                            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                1,
                                                                ln_islem_no,
                                                                varchar_list,
                                                                number_list,
                                                                date_list,
                                                                boolean_list ,
                                                                NULL,
                                                                FALSE,
                                                                0,
                                                                'Direct Debitting - On Value Date - Value Date is banking date');
                        ELSE
                            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                     1,
                                                                     ln_fis_numara,
                                                                     varchar_list,
                                                                     number_list,
                                                                     date_list,
                                                                     boolean_list,
                                                                     NULL,
                                                                     FALSE);
                        END IF;

                        ln_counter:=ln_counter+1;

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = 0,
                            STATUS  = 'DONE',
                            PAYMENT_CHARGED = 'E',
                            CHARGED_PAYMENT_AMOUNT = r1.amount,
                            CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            JOURNAL_NO = ln_fis_numara,
                            TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    else
                        ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);

                        if ln_total_balance >= round((ln_rej_komisyon + ln_rej_tax),2)
                        then
                            ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                            varchar_list(p_7062_HESAP) := ln_account;
                            varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                            varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;
                            number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                            number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                            varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                        ----  FX CONV HERE
                            if ln_bakiye < round((ln_rej_komisyon + ln_rej_tax),2)
                            then
                                ln_hesaptan_al := 1;
                                ln_kalan_tahsilat := round((nvl(ln_rej_komisyon,0) + nvl(ln_rej_tax,0) - nvl(ln_bakiye,0)),2);

                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;

                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                

                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;                                            
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;
                                     
                                        IF ln_counter = 0
                                        THEN
                                             ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                             ln_plan,
                                                                             ln_islem_no,
                                                                             varchar_list,
                                                                             number_list,
                                                                             date_list,
                                                                             boolean_list ,
                                                                             NULL,
                                                                             FALSE,
                                                                             0,
                                                                             'Direct Debitting - On Value Date');
                                        ELSE
                                            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                                     ln_plan,
                                                                                     ln_fis_numara,
                                                                                     varchar_list,
                                                                                     number_list,
                                                                                     date_list,
                                                                                     boolean_list,
                                                                                     NULL,
                                                                                     FALSE);
                                        END IF;

                                        ln_counter:=ln_counter+1;

                                        if ln_kalan_tahsilat = 0
                                        then
                                            ln_hesaptan_al := 0;
                                        end if;
                                    end if;
                                END LOOP;
                                CLOSE c_fx;
                            end if;
                        ----  FX CONV HERE

                            IF ln_counter = 0
                            THEN
                                ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                    4,
                                                                    ln_islem_no,
                                                                    varchar_list,
                                                                    number_list,
                                                                    date_list,
                                                                    boolean_list ,
                                                                    NULL,
                                                                    FALSE,
                                                                    0,
                                                                    'Direct Debitting - Reject Commission');
                            ELSE
                                ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                         4,
                                                                         ln_fis_numara,
                                                                         varchar_list,
                                                                         number_list,
                                                                         date_list,
                                                                         boolean_list,
                                                                         NULL,
                                                                         FALSE);
                            END IF;

                            ln_counter:=ln_counter+1;

                            Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                            update CBS_DIRECT_DEBIT_DATA
                            set COMM_AMOUNT = ln_rej_komisyon,
                                STATUS  = 'REJECTED - COMM CHARGED',
                                PAYMENT_CHARGED = 'H',
                                CHARGED_PAYMENT_AMOUNT = 0,
                                COMMISSION_CHARGED = 'E',
                                CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                                COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                                COMM_JOURNAL_NO = ln_fis_numara,
                                COMM_TX_NO = ln_islem_no,
                                ACCOUNT_BALANCE = ln_bakiye
                            WHERE INTERNAL_NO = r1.INTERNAL_NO
                              and SIRA_NO = r1.SIRA_NO;
                            
                        else
                            update CBS_DIRECT_DEBIT_DATA
                            set COMM_AMOUNT = ln_rej_komisyon,
                                STATUS  = 'REJECTED - COMM MISSING',
                                PAYMENT_CHARGED = 'H',
                                CHARGED_PAYMENT_AMOUNT = 0,
                                COMMISSION_CHARGED = 'H',
                                CHARGED_COMMISSION_AMOUNT = 0,
                                ACCOUNT_BALANCE = ln_bakiye
                            WHERE INTERNAL_NO = r1.INTERNAL_NO
                              and SIRA_NO = r1.SIRA_NO;
                            
                        end if;
                    end if;
                end if;
            end if;
        end if;  ------------ if primary account's balance is not enough, check the other accounts of customer
        
        commit;
    END LOOP;



    CLOSE c1;
      Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    Exception
    WHEN No_Uc_Account THEN
        rollback;        
        --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','MakePayment','Error is: No uc account, rollbacked');        
        log_at('hakan_dd_error3',sqlcode,sqlerrm);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6047'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
    WHEN OTHERS THEN
        rollback;
        --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','MakePayment','Error is: '||sqlerrm);               
        log_at('hakan_dd_error3',sqlcode,sqlerrm);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6047'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
end;
--------------------------------------------------------------------------------------------------------------
PROCEDURE Make_Future_Payment
is
    CURSOR c1 IS
        SELECT *
        FROM CBS_DIRECT_DEBIT_DATA
        WHERE 
        ( 
          (MATURITY_DATE <= PKG_MUHASEBE.BANKA_TARIHI_BUL
           AND 
           STATUS = 'DONE - FUTURE'
           )
           OR
           ( 
           STATUS = 'FUTURE'
           AND  
            MATURITY_DATE >= PKG_MUHASEBE.BANKA_TARIHI_BUL
           )
         )
         and nvl(comes_from_uc,'N') = 'N'   --Sevalb 03022012   phase-1 accounting kismina phase-2 kesinlikle girmemesi istendi.
         ORDER BY MATURITY_DATE, INTERNAL_NO, SIRA_NO;
         
    r1        c1%ROWTYPE;

    CURSOR c_fx(pn_musteri number, pn_account number) IS
        SELECT decode(h.doviz_kodu,pkg_genel.lc_al,'1','2') Sira,h.*
        FROM cbs_hesap h
        WHERE musteri_no = pn_musteri
          and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) > 0
          and durum_kodu = 'A'
          and hesap_no <> pn_account
          and hesap_no in (select account_no
                                  from cbs_direct_debit_hesap
                           where customer_no = pn_musteri)
          order by sira,rownum;
    r_fx c_fx%ROWTYPE;

    ln_account           NUMBER;
    ln_bakiye           number;
    ln_rej_komisyon           number;
    ls_DIRECT_DEBIT       varchar2(1);

    varchar_list               Pkg_Muhasebe.varchar_array;
    number_list                   Pkg_Muhasebe.number_array;
    date_list                   Pkg_Muhasebe.date_array;
    boolean_list               Pkg_Muhasebe.boolean_array;

    ln_counter                  number;
    ln_temp_numara              number;
    ln_islem_no                   number;
    ln_fis_numara               number;
    ln_fis_numara_gecici       number;

    p_7062_SUBE                   number;
    p_7062_HESAP               number;
    p_7062_MB_HESAP               number;
    p_7062_MB_SUBE               number;
    p_7062_TUTAR               number;
    p_7062_ACIKLAMA               number;
    p_7062_MASRAF_DK           number;
    p_7062_COMM_TUTAR           number;
    p_7062_COMM_ACIKLAMA       number;
    p_7062_MATURITY_DATE       number;

    p_7062_CONV_HESAP      NUMBER;
    p_7062_CONV_BR         NUMBER;
    p_7062_CONV_CY          NUMBER;
    p_7062_CONV_ACIKLAMA                  NUMBER;
    p_7062_CONV_FC_AMNT               NUMBER;
    p_7062_CONV_LC_AMNT             NUMBER;
    p_7062_CONV_RATE             NUMBER;

    p_7062_MASRAF                number;
    p_7062_MASRAF_ACIKLAMA        number;

    p_7062_TAX_ACIKLAMA           number;
    p_7062_TAX_TUTAR           number;

    ls_7062_NB_ACC       varchar2(20);
    ls_7062_NB_ACC_BR  varchar2(10);

    --Yerzhan Tanatov for rate difference
    p_7062_CONV_RET_LC_AMNT      NUMBER;
    p_7062_CUSTOMER_RATE_LESS    NUMBER;
    p_7062_CUSTOMER_RATE_MORE    NUMBER;
    p_7062_RATE_DIFF_AMOUNT NUMBER;
    p_our_buy_rate number;

    ls_masraf_dk       varchar2(30);
    ln_islem_no_gecici NUMBER;
    ln_masraf            number;
    ln_masrafli_tutar  number;
    ln_rate               number;
    ln_tax                number;
    ln_rej_tax           number;
    ln_cnt               number;
    ls_DIRECT_DEBIT_ANNUAL      varchar2(1);

    ln_customer                    number;
    ln_toplam_bakiye            number;
    ln_total_balance            number;
    ln_hesaptan_al                number;
    ln_kalan_tahsilat             number;
    ln_plan                        number;
    ln_original_kur             number;
    ln_hesap_kur                 number;
    ln_hesaptan_tutar             number;
    ln_bakiye_fx                 number;
    ln_bakiye_dvz                 number;
    ln_cnt_2                    number;
    No_Uc_Account                Exception;
begin
    Pkg_Batch.basla(0,0,'Make_Future_Payment');

    p_7062_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_SUBE');
    p_7062_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_HESAP');
    p_7062_MB_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_MB_HESAP');
    p_7062_MB_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_MB_SUBE');
    p_7062_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_ACIKLAMA');
    p_7062_MASRAF_DK :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF_DK');
    p_7062_COMM_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_ACIKLAMA');
    p_7062_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TUTAR');
    p_7062_COMM_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_TUTAR');
    p_7062_MATURITY_DATE :=Pkg_Muhasebe.parametre_index_bul('7062_MATURITY_DATE');
    p_7062_MASRAF :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF');
    p_7062_MASRAF_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF_ACIKLAMA');
    p_7062_TAX_ACIKLAMA                      :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_ACIKLAMA');
    p_7062_TAX_TUTAR                      :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_TUTAR');

    p_7062_CONV_HESAP           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_HESAP');
    p_7062_CONV_BR           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_BR');
    p_7062_CONV_CY           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_CY');
    p_7062_CONV_ACIKLAMA           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_ACIKLAMA');
    p_7062_CONV_FC_AMNT           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_FC_AMNT');
    p_7062_CONV_LC_AMNT           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_LC_AMNT');
    p_7062_CONV_RATE           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RATE');

    --Yerzhan Tanatov for rate difference
    p_7062_CONV_RET_LC_AMNT       :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RET_LC_AMNT'); --
    p_7062_CUSTOMER_RATE_LESS    :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_LESS');
    p_7062_CUSTOMER_RATE_MORE    :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_MORE');
    p_7062_RATE_DIFF_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7062_RATE_DIFF_AMOUNT');

    Pkg_Parametre.deger('3555_NB_ACC',ls_7062_NB_ACC);
    ls_7062_NB_ACC_BR := pkg_hesap.HesaptanSubeAl(ls_7062_NB_ACC);
--    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
    ln_rate := 2;

    OPEN c1 ;
    LOOP
        FETCH c1 INTO r1;
        EXIT WHEN c1%NOTFOUND;
         
        date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

        ln_rej_komisyon := 0;
        ln_bakiye := 0;

        begin
            ln_account := pkg_hesap.GetHesapNoFromExternal(r1.TO_ACCOUNT_EXTERNAL_NUMBER,pkg_genel.LC_al);
        exception
        when others then
            ln_account := NULL;
        end;

        ln_customer := pkg_hesap.HesaptanMusteriNoAl(ln_account);

        select count(*)
        into ln_cnt
        from cbs_direct_debit_hesap
        where customer_no = ln_customer;

        if ln_cnt = 0
        then
            varchar_list(p_7062_SUBE) := NULL;
            varchar_list(p_7062_HESAP) := NULL;
            varchar_list(p_7062_MB_HESAP) := NULL;
            varchar_list(p_7062_MB_SUBE) := NULL;
            varchar_list(p_7062_ACIKLAMA) := NULL;
            varchar_list(p_7062_MASRAF_DK) := NULL;
            varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
            number_list(p_7062_MASRAF):= 0;
            number_list(p_7062_TAX_TUTAR):= 0;
            varchar_list(p_7062_MASRAF_ACIKLAMA) := NULL;
            varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
            number_list(p_7062_TUTAR):= 0;
            number_list(p_7062_COMM_TUTAR):= 0;
            date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

            begin
                select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
                into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
                from cbs_hesap
                where hesap_no = nvl(ln_account,0);
            exception
            when others then
                ls_DIRECT_DEBIT := 'H';
            end;

            ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);
             ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');

            varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;
            varchar_list(p_7062_MASRAF_ACIKLAMA) := 'Commmission of Direct Debit for Account : '||ln_account;

            if nvl(ls_DIRECT_DEBIT_ANNUAL,'H') = 'E'
            then
                ln_masraf := 0;
            else
                ln_masraf := pkg_direct_debit.Clearing_Comm_Amount(r1.amount);
            end if;

            ln_tax := round(((ln_masraf*ln_rate)/100),2);
            ln_masrafli_tutar := round((r1.AMOUNT+ln_masraf+ln_tax),2);

            ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);

            if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'DONE - FUTURE'
            then
            
                Pkg_Muhasebe.GECICI_FIS_IPTAL(r1.TEMPORARY_JOURNAL_NO);

                varchar_list(p_7062_HESAP) := ln_account;
                varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                if r1.comes_from_uc = 'Y'
                then
                    select count(*)
                    into ln_cnt_2
                    from cbs_hesap
                    where durum_kodu = 'A'
                      and hesap_no = nvl(r1.UC_ACCOUNT,0);

                    if ln_cnt_2 <> 1
                    then
                        raise No_Uc_Account;
                    else
                        varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                        varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                    end if;
                else
                    varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                    varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                end if;

                varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                number_list(p_7062_TUTAR):= r1.amount;
                date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

                ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                    3,
                                                    ln_islem_no,
                                                    varchar_list,
                                                    number_list,
                                                    date_list,
                                                    boolean_list ,
                                                    null,
                                                    FALSE,
                                                    0,
                                                    'Direct Debitting - On Maturity Date');

                Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                update CBS_DIRECT_DEBIT_DATA
                set MATURITY_JOURNAL_NO = ln_fis_numara,
                    STATUS = 'DONE - 2',
                    MATURITY_TX_NO = ln_islem_no
                WHERE INTERNAL_NO = r1.INTERNAL_NO
                  and SIRA_NO = r1.SIRA_NO;
            end if;

            if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'FUTURE'
            then

                if ln_bakiye >= ln_masrafli_tutar
                then
                    varchar_list(p_7062_HESAP) := ln_account;
                    varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                    if r1.comes_from_uc = 'Y'
                    then
                    
                        select count(*)
                        into ln_cnt_2
                        from cbs_hesap
                        where durum_kodu = 'A'
                          and hesap_no = nvl(r1.UC_ACCOUNT,0);

                        if ln_cnt_2 <> 1
                        then
                            raise No_Uc_Account;
                        else
                            varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                            varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                        end if;
                    else
                        varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                        varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                    end if;

                    varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                    number_list(p_7062_TUTAR):= r1.amount;

                    number_list(p_7062_MASRAF):= ln_masraf;

                    number_list(p_7062_TAX_TUTAR):= ln_tax;
                    varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                    
                    ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                        1,
                                                        ln_islem_no,
                                                        varchar_list,
                                                        number_list,
                                                        date_list,
                                                        boolean_list ,
                                                        NULL,
                                                        FALSE,
                                                        0,
                                                        'Direct Debitting - On Maturity Date');

                    Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                    update CBS_DIRECT_DEBIT_DATA
                    set COMM_AMOUNT = 0,
                        STATUS  = 'DONE',
                        PAYMENT_CHARGED = 'E',
                        CHARGED_PAYMENT_AMOUNT = r1.amount,
                        CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                        COMMISSION_CHARGED = 'H',
                        CHARGED_COMMISSION_AMOUNT = 0,
                        JOURNAL_NO = ln_fis_numara,
                        TX_NO = ln_islem_no,
                        ACCOUNT_BALANCE = ln_bakiye
                    WHERE INTERNAL_NO = r1.INTERNAL_NO
                      and SIRA_NO = r1.SIRA_NO;
                else

                    ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);                    
                
                    if ln_bakiye >= round((ln_rej_komisyon + ln_rej_tax),2)
                    then
                    
                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                        varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;
                        number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                        number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        
                        ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                            4,
                                                            ln_islem_no,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            NULL,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - Reject Commission');

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = ln_rej_komisyon,
                            STATUS  = 'REJECTED - COMM CHARGED',
                            PAYMENT_CHARGED = 'H',
                            CHARGED_PAYMENT_AMOUNT = 0,
                            COMMISSION_CHARGED = 'E',
                            CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                            COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                            COMM_JOURNAL_NO = ln_fis_numara,
                            COMM_TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    else
                    
                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = ln_rej_komisyon,
                            STATUS  = 'REJECTED - COMM MISSING',
                            PAYMENT_CHARGED = 'H',
                            CHARGED_PAYMENT_AMOUNT = 0,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    end if;
                end if;
            end if;
            if r1.maturity_date > pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'FUTURE'
            then
                if ln_bakiye >= ln_masrafli_tutar
                then
                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                        if r1.comes_from_uc = 'Y'
                        then
                            select count(*)
                            into ln_cnt_2
                            from cbs_hesap
                            where durum_kodu = 'A'
                            and hesap_no = nvl(r1.UC_ACCOUNT,0);

                            if ln_cnt_2 <> 1
                            then
                                raise No_Uc_Account;
                            else
                                varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                                varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                            end if;
                        else
                            varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                            varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                        end if;

                        varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                        number_list(p_7062_TUTAR):= r1.amount;
                        date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

                        number_list(p_7062_MASRAF):= ln_masraf;

                        number_list(p_7062_TAX_TUTAR):= ln_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                            2,
                                                            ln_islem_no,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            NULL,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Value Date');

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        ln_islem_no_gecici:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        ln_fis_numara_gecici:=Pkg_Muhasebe.fis_kes(7062,
                                                            3,
                                                            ln_islem_no_gecici,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            r1.maturity_date,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Maturity Date');

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = 0,
                            STATUS  = 'DONE - FUTURE',
                            PAYMENT_CHARGED = 'E',
                            CHARGED_PAYMENT_AMOUNT = r1.amount,
                            CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            TEMPORARY_JOURNAL_NO = ln_fis_numara_gecici,
                            TEMPORARY_TX_NO = ln_islem_no_gecici,
                            JOURNAL_NO = ln_fis_numara,
                            TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                end if;
            end if;
        else  ------------ if primary account's balance is not enough, check the other accounts of customer
            varchar_list(p_7062_SUBE) := NULL;
            varchar_list(p_7062_HESAP) := NULL;
            varchar_list(p_7062_MB_HESAP) := NULL;
            varchar_list(p_7062_MB_SUBE) := NULL;
            varchar_list(p_7062_ACIKLAMA) := NULL;
            varchar_list(p_7062_MASRAF_DK) := NULL;
            varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
            number_list(p_7062_MASRAF):= 0;
            number_list(p_7062_TAX_TUTAR):= 0;
            varchar_list(p_7062_MASRAF_ACIKLAMA) := NULL;
            varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
            number_list(p_7062_TUTAR):= 0;
            number_list(p_7062_COMM_TUTAR):= 0;
            date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;
             
            ln_rej_komisyon := 0;
            ln_bakiye := 0;
            ln_total_balance  := 0;
            ln_masraf := 0;
            ln_masrafli_tutar := 0;
            ln_tax := 0;
            ln_counter := 0;
            
            begin
                select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
                into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
                from cbs_hesap
                where hesap_no = nvl(ln_account,0);
            exception
            when others then
                ls_DIRECT_DEBIT := 'H';
            end;

            ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);
            ln_total_balance := pkg_direct_debit.Customer_Total_Balance(ln_customer, ln_account);
            ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');

            varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;
            varchar_list(p_7062_MASRAF_ACIKLAMA) := 'Commmission of Direct Debit for Account : '||ln_account;

            if nvl(ls_DIRECT_DEBIT_ANNUAL,'H') = 'E'
            then
                ln_masraf := 0;
            else
                ln_masraf := pkg_direct_debit.Clearing_Comm_Amount(r1.amount);
            end if;

            ln_tax := round(((ln_masraf*ln_rate)/100),2);
            ln_masrafli_tutar := round((r1.AMOUNT+ln_masraf+ln_tax),2);
            ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);

            if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'DONE - FUTURE'
            then
                Pkg_Muhasebe.GECICI_FIS_IPTAL(r1.TEMPORARY_JOURNAL_NO);

                varchar_list(p_7062_HESAP) := ln_account;
                varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                if r1.comes_from_uc = 'Y'
                then
                    select count(*)
                    into ln_cnt_2
                    from cbs_hesap
                    where durum_kodu = 'A'
                      and hesap_no = nvl(r1.UC_ACCOUNT,0);

                    if ln_cnt_2 <> 1
                    then
                        raise No_Uc_Account;
                    else
                        varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                        varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                    end if;
                else
                    varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                    varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                end if;

                varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                number_list(p_7062_TUTAR):= r1.amount;
                date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

                ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                    3,
                                                    ln_islem_no,
                                                    varchar_list,
                                                    number_list,
                                                    date_list,
                                                    boolean_list ,
                                                    null,
                                                    FALSE,
                                                    0,
                                                    'Direct Debitting - On Maturity Date');

                Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                update CBS_DIRECT_DEBIT_DATA
                set MATURITY_JOURNAL_NO = ln_fis_numara,
                    status = 'DONE - 2',
                    MATURITY_TX_NO = ln_islem_no
                WHERE INTERNAL_NO = r1.INTERNAL_NO
                  and SIRA_NO = r1.SIRA_NO;
            end if;

            if r1.maturity_date = pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'FUTURE'
            then

                if ln_total_balance >= ln_masrafli_tutar
                then
                    varchar_list(p_7062_HESAP) := ln_account;
                    varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));

                    if r1.comes_from_uc = 'Y'
                    then
                        select count(*)
                        into ln_cnt_2
                        from cbs_hesap
                        where durum_kodu = 'A'
                          and hesap_no = nvl(r1.UC_ACCOUNT,0);

                        if ln_cnt_2 <> 1
                        then
                            raise No_Uc_Account;
                        else
                            varchar_list(p_7062_MB_HESAP) := r1.UC_ACCOUNT;
                            varchar_list(p_7062_MB_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_MB_HESAP));
                        end if;
                    else
                        varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                        varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                    end if;

                    varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                    number_list(p_7062_TUTAR):= r1.amount;

                    number_list(p_7062_MASRAF):= ln_masraf;

                    number_list(p_7062_TAX_TUTAR):= ln_tax;
                    varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                ----  FX CONV HERE
                
                    if ln_bakiye < ln_masrafli_tutar
                    then                       
                        ln_hesaptan_al := 1;
                        ln_kalan_tahsilat := round((nvl(ln_masrafli_tutar,0)-nvl(ln_bakiye,0)),2);
                  
                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;

                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                
                                
                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;                                            
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;
                                                                          
                                IF ln_counter = 0
                                THEN
                                     ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                     ln_plan,
                                                                     ln_islem_no,
                                                                     varchar_list,
                                                                     number_list,
                                                                     date_list,
                                                                     boolean_list ,
                                                                     NULL,
                                                                     FALSE,
                                                                     0,
                                                                     'Direct Debitting - On Value Date');
                                ELSE

                                    ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                             ln_plan,
                                                                             ln_fis_numara,
                                                                             varchar_list,
                                                                             number_list,
                                                                             date_list,
                                                                             boolean_list,
                                                                             NULL,
                                                                             FALSE);
                                END IF;

                                ln_counter:=ln_counter+1;

                                if ln_kalan_tahsilat = 0
                                then
                                    ln_hesaptan_al := 0;
                                end if;
                            end if;
                        END LOOP;
                        CLOSE c_fx;
                    end if;
                ----  FX CONV HERE


                    IF ln_counter = 0
                    THEN
                        ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                            1,
                                                            ln_islem_no,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            NULL,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Maturity Date');
                                                            
                    ELSE
                        ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                 1,
                                                                 ln_fis_numara,
                                                                 varchar_list,
                                                                 number_list,
                                                                 date_list,
                                                                 boolean_list,
                                                                 NULL,
                                                                 FALSE);
                    END IF;

                    ln_counter:=ln_counter+1;

                    Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                    update CBS_DIRECT_DEBIT_DATA
                    set COMM_AMOUNT = 0,
                        STATUS  = 'DONE',
                        PAYMENT_CHARGED = 'E',
                        CHARGED_PAYMENT_AMOUNT = r1.amount,
                        CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                        COMMISSION_CHARGED = 'H',
                        CHARGED_COMMISSION_AMOUNT = 0,
                        JOURNAL_NO = ln_fis_numara,
                        TX_NO = ln_islem_no,
                        ACCOUNT_BALANCE = ln_bakiye
                    WHERE INTERNAL_NO = r1.INTERNAL_NO
                      and SIRA_NO = r1.SIRA_NO;
                else
                    ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);
                    if ln_total_balance >= round((ln_rej_komisyon + ln_rej_tax),2)
                    then
                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                        varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;
                        number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                        number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ----  FX CONV HERE
                        if ln_bakiye < round((ln_rej_komisyon + ln_rej_tax),2)
                        then
                            ln_hesaptan_al := 1;
                            ln_kalan_tahsilat := round((nvl(ln_rej_komisyon,0) + nvl(ln_rej_tax,0) - nvl(ln_bakiye,0)),2);

                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;

                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                

                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;                                            
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;
                                                                          
                                    IF ln_counter = 0
                                    THEN
                                         ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                         ln_plan,
                                                                         ln_islem_no,
                                                                         varchar_list,
                                                                         number_list,
                                                                         date_list,
                                                                         boolean_list ,
                                                                         NULL,
                                                                         FALSE,
                                                                         0,
                                                                         'Direct Debitting - On Value Date');
                                    ELSE
                                        ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                                 ln_plan,
                                                                                 ln_fis_numara,
                                                                                 varchar_list,
                                                                                 number_list,
                                                                                 date_list,
                                                                                 boolean_list,
                                                                                 NULL,
                                                                                 FALSE);
                                    END IF;

                                    ln_counter:=ln_counter+1;

                                    if ln_kalan_tahsilat = 0
                                    then
                                        ln_hesaptan_al := 0;
                                    end if;
                                end if;
                            END LOOP;
                            CLOSE c_fx;
                        end if;
                    ----  FX CONV HERE

                        IF ln_counter = 0
                        THEN
                            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                4,
                                                                ln_islem_no,
                                                                varchar_list,
                                                                number_list,
                                                                date_list,
                                                                boolean_list ,
                                                                NULL,
                                                                FALSE,
                                                                0,
                                                                'Direct Debitting - Reject Commission');
                        ELSE
                            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                     4,
                                                                     ln_fis_numara,
                                                                     varchar_list,
                                                                     number_list,
                                                                     date_list,
                                                                     boolean_list,
                                                                     NULL,
                                                                     FALSE);
                        END IF;

                        ln_counter:=ln_counter+1;

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = ln_rej_komisyon,
                            STATUS  = 'REJECTED - COMM CHARGED',
                            PAYMENT_CHARGED = 'H',
                            CHARGED_PAYMENT_AMOUNT = 0,
                            COMMISSION_CHARGED = 'E',
                            CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                            COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                            COMM_JOURNAL_NO = ln_fis_numara,
                            COMM_TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    else
                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = ln_rej_komisyon,
                            STATUS  = 'REJECTED - COMM MISSING',
                            PAYMENT_CHARGED = 'H',
                            CHARGED_PAYMENT_AMOUNT = 0,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                    end if;
                end if;
            end if;
           
            if r1.maturity_date > pkg_muhasebe.Banka_Tarihi_Bul and r1.status = 'FUTURE'
            then
                if ln_bakiye >= ln_masrafli_tutar
                then
                        varchar_list(p_7062_HESAP) := ln_account;
                        varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                        varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
                        varchar_list(p_7062_MB_SUBE)  := ls_7062_NB_ACC_BR;
                        varchar_list(p_7062_ACIKLAMA) := 'Direct Debit for Account : '||ln_account;
                        number_list(p_7062_TUTAR):= r1.amount;
                        date_list(p_7062_MATURITY_DATE):= r1.maturity_date;

                        number_list(p_7062_MASRAF):= ln_masraf;

                        number_list(p_7062_TAX_TUTAR):= ln_tax;
                        varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                        ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                            2,
                                                            ln_islem_no,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            NULL,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Value Date');

                        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                        ln_islem_no_gecici:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                        ln_fis_numara_gecici:=Pkg_Muhasebe.fis_kes(7062,
                                                            3,
                                                            ln_islem_no_gecici,
                                                            varchar_list,
                                                            number_list,
                                                            date_list,
                                                            boolean_list ,
                                                            r1.maturity_date,
                                                            FALSE,
                                                            0,
                                                            'Direct Debitting - On Maturity Date');

                        update CBS_DIRECT_DEBIT_DATA
                        set COMM_AMOUNT = 0,
                            STATUS  = 'DONE - FUTURE',
                            PAYMENT_CHARGED = 'E',
                            CHARGED_PAYMENT_AMOUNT = r1.amount,
                            CHARGED_CLEARING_COMM_AMOUNT = ln_masraf,
                            COMMISSION_CHARGED = 'H',
                            CHARGED_COMMISSION_AMOUNT = 0,
                            TEMPORARY_JOURNAL_NO = ln_fis_numara_gecici,
                            TEMPORARY_TX_NO = ln_islem_no_gecici,
                            JOURNAL_NO = ln_fis_numara,
                            TX_NO = ln_islem_no,
                            ACCOUNT_BALANCE = ln_bakiye
                        WHERE INTERNAL_NO = r1.INTERNAL_NO
                          and SIRA_NO = r1.SIRA_NO;
                end if;
            end if;
         end if;  ------------ if primary account's balance is not enough, check the other accounts of customer
        commit;
    END LOOP;
    CLOSE c1;
      Pkg_Batch.bitir(0,0,'Make_Future_Payment');

    Exception
    WHEN OTHERS THEN
        --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','make_future_payment','Error is: '||sqlerrm);    
        log_at('hakan_dd_error4',sqlcode,sqlerrm);
        Pkg_Batch.logla(0,0,'Make_Future_Payment',Pkg_Hata.GetUCPOINTER||'6047'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
        Pkg_Batch.bitir(0,0,'Make_Future_Payment');
end;
--------------------------------------------------------------------------------------------------------------
PROCEDURE Missing_Comm_Payment
is
    CURSOR c1 IS
        SELECT     *
        FROM CBS_DIRECT_DEBIT_DATA
        WHERE STATUS = 'REJECTED - COMM MISSING';

    r1        c1%ROWTYPE;

    CURSOR c_fx(pn_musteri number, pn_account number) IS
        SELECT decode(h.doviz_kodu,pkg_genel.lc_al,'1','2') Sira,h.*
        FROM cbs_hesap h
        WHERE musteri_no = pn_musteri
          and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) > 0
          and durum_kodu = 'A'
          and hesap_no <> pn_account
          and hesap_no in (select account_no
                                  from cbs_direct_debit_hesap
                           where customer_no = pn_musteri)
          order by sira,rownum;
         
    r_fx c_fx%ROWTYPE;

    ln_account           NUMBER;
    ln_bakiye            number;
    ln_rej_komisyon      number;
    ls_DIRECT_DEBIT      varchar2(1);

    varchar_list               Pkg_Muhasebe.varchar_array;
    number_list                   Pkg_Muhasebe.number_array;
    date_list                   Pkg_Muhasebe.date_array;
    boolean_list               Pkg_Muhasebe.boolean_array;

    ln_counter                  number;
    ln_temp_numara              number;
    ln_islem_no                   number;
    ln_fis_numara               number;

    p_7062_SUBE                   number;
    p_7062_HESAP               number;
    p_7062_TUTAR               number;
    p_7062_ACIKLAMA               number;
    p_7062_MASRAF_DK           number;
    p_7062_COMM_TUTAR           number;
    p_7062_COMM_ACIKLAMA       number;
    p_7062_MATURITY_DATE       number;

    p_7062_CONV_HESAP      NUMBER;
    p_7062_CONV_BR         NUMBER;
    p_7062_CONV_CY          NUMBER;
    p_7062_CONV_ACIKLAMA                  NUMBER;
    p_7062_CONV_FC_AMNT               NUMBER;
    p_7062_CONV_LC_AMNT             NUMBER;
    p_7062_CONV_RATE             NUMBER;

    p_7062_TAX_ACIKLAMA           number;
    p_7062_TAX_TUTAR           number;
    --Yerzhan Tanatov for rate difference
    p_7062_CONV_RET_LC_AMNT      NUMBER;
    p_7062_CUSTOMER_RATE_LESS    NUMBER;
    p_7062_CUSTOMER_RATE_MORE    NUMBER;
    p_7062_RATE_DIFF_AMOUNT NUMBER;
    p_our_buy_rate number;

    ls_7062_NB_ACC       varchar2(20);
    ls_7062_NB_ACC_BR  varchar2(10);

    ls_masraf_dk       varchar2(30);
    ln_rate               number;
    ln_tax                number;
    ln_rej_tax           number;
    ln_CNT           number;
    ls_DIRECT_DEBIT_ANNUAL      varchar2(1);

    ln_customer                    number;
    ln_toplam_bakiye            number;
    ln_total_balance            number;
    ln_hesaptan_al                number;
    ln_kalan_tahsilat             number;
    ln_plan                        number;
    ln_original_kur             number;
    ln_hesap_kur                 number;
    ln_hesaptan_tutar             number;
    ln_bakiye_fx                     number;
    ln_bakiye_dvz                 number;
begin
    Pkg_Batch.basla(0,0,'Missing_Comm_Payment');

    p_7062_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_SUBE');
    p_7062_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_HESAP');
    p_7062_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_ACIKLAMA');
    p_7062_MASRAF_DK :=Pkg_Muhasebe.parametre_index_bul('7062_MASRAF_DK');
    p_7062_COMM_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_ACIKLAMA');
    p_7062_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TUTAR');
    p_7062_COMM_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_COMM_TUTAR');
    p_7062_MATURITY_DATE :=Pkg_Muhasebe.parametre_index_bul('7062_MATURITY_DATE');

    p_7062_TAX_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_ACIKLAMA');
    p_7062_TAX_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TAX_TUTAR');

    p_7062_CONV_HESAP           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_HESAP');
    p_7062_CONV_BR           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_BR');
    p_7062_CONV_CY           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_CY');
    p_7062_CONV_ACIKLAMA           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_ACIKLAMA');
    p_7062_CONV_FC_AMNT           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_FC_AMNT');
    p_7062_CONV_LC_AMNT           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_LC_AMNT');
    p_7062_CONV_RATE           :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RATE');

    --Yerzhan Tanatov for rate difference
    p_7062_CONV_RET_LC_AMNT       :=Pkg_Muhasebe.parametre_index_bul('7062_CONV_RET_LC_AMNT'); --
    p_7062_CUSTOMER_RATE_LESS    :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_LESS');
    p_7062_CUSTOMER_RATE_MORE    :=Pkg_Muhasebe.parametre_index_bul('7062_CUSTOMER_RATE_MORE');
    p_7062_RATE_DIFF_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7062_RATE_DIFF_AMOUNT');

--    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
    ln_rate := 2;
    OPEN c1 ;
    LOOP
        FETCH c1 INTO r1;
        EXIT WHEN c1%NOTFOUND;

        begin
            ln_account := pkg_hesap.GetHesapNoFromExternal(r1.TO_ACCOUNT_EXTERNAL_NUMBER,pkg_genel.LC_al);
        exception
        when others then
            ln_account := NULL;
        end;

        ln_customer := pkg_hesap.HesaptanMusteriNoAl(ln_account);

        select count(*)
        into ln_cnt
        from cbs_direct_debit_hesap
        where customer_no = ln_customer;

        if ln_cnt = 0
        then
            varchar_list(p_7062_SUBE) := NULL;
            varchar_list(p_7062_HESAP) := NULL;
            varchar_list(p_7062_ACIKLAMA) := NULL;
            varchar_list(p_7062_MASRAF_DK) := NULL;
            varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
            number_list(p_7062_TAX_TUTAR):= 0;
            varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
            number_list(p_7062_TUTAR):= 0;
            number_list(p_7062_COMM_TUTAR):= 0;
            date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

            ln_rej_komisyon := 0;
            ln_bakiye := 0;

             ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');
            varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;
            varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;


            begin
                select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
                into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
                from cbs_hesap
                where hesap_no = nvl(ln_account,0);
            exception
            when others then
                ls_DIRECT_DEBIT := 'H';
            end;

            if ln_account is null or ls_DIRECT_DEBIT = 'H'
            then
                update CBS_DIRECT_DEBIT_DATA
                set COMM_AMOUNT = 0,
                    STATUS  = 'REJECTED BUT NOW NOT ACTIVE',
                    PAYMENT_CHARGED = 'H',
                    CHARGED_PAYMENT_AMOUNT = 0,
                    COMMISSION_CHARGED = 'H',
                    CHARGED_COMMISSION_AMOUNT = 0
                WHERE INTERNAL_NO = r1.INTERNAL_NO
                  and SIRA_NO = r1.SIRA_NO;
            else
                ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);
                ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);
                ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);

                if ln_bakiye >= round((ln_rej_komisyon + ln_rej_tax),2)
                then
                    varchar_list(p_7062_HESAP) := ln_account;
                    varchar_list(p_7062_SUBE) := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                    number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                    number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                    varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                    ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));
                    ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                        4,
                                                        ln_islem_no,
                                                        varchar_list,
                                                        number_list,
                                                        date_list,
                                                        boolean_list ,
                                                        NULL,
                                                        FALSE,
                                                        0,
                                                        'Direct Debitting - Missing Reject Commission Colelction');

                    Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                    update CBS_DIRECT_DEBIT_DATA
                    set COMM_AMOUNT = ln_rej_komisyon,
                        STATUS  = 'REJECTED - COMM CHARGED',
                        PAYMENT_CHARGED = 'H',
                        CHARGED_PAYMENT_AMOUNT = 0,
                        COMMISSION_CHARGED = 'E',
                        CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                        COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                        COMM_JOURNAL_NO = ln_fis_numara,
                        COMM_TX_NO = ln_islem_no,
                        ACCOUNT_BALANCE = ln_bakiye
                    WHERE INTERNAL_NO = r1.INTERNAL_NO
                      and SIRA_NO = r1.SIRA_NO;
                end if;
            end if;
        else  ------------ if primary account's balance is not enough, check the other accounts of customer
            varchar_list(p_7062_SUBE) := NULL;
            varchar_list(p_7062_HESAP) := NULL;
            varchar_list(p_7062_ACIKLAMA) := NULL;
            varchar_list(p_7062_MASRAF_DK) := NULL;
            varchar_list(p_7062_COMM_ACIKLAMA) := NULL;
            number_list(p_7062_TAX_TUTAR):= 0;
            varchar_list(p_7062_TAX_ACIKLAMA) := NULL;
            number_list(p_7062_TUTAR):= 0;
            number_list(p_7062_COMM_TUTAR):= 0;
            date_list(p_7062_MATURITY_DATE):= pkg_muhasebe.Banka_Tarihi_Bul;

            ln_rej_komisyon := 0;
            ln_bakiye := 0;

             ls_masraf_dk := Pkg_Muhasebe.Komisyon_DK_Bul( Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_account)),'CLEARING');
            varchar_list(p_7062_MASRAF_DK) := ls_masraf_dk;
            varchar_list(p_7062_COMM_ACIKLAMA) := 'Reject Commission of Direct Debit for Account : '||ln_account;


            begin
                select DIRECT_DEBIT,DIRECT_DEBIT_ANNUAL
                into ls_DIRECT_DEBIT,ls_DIRECT_DEBIT_ANNUAL
                from cbs_hesap
                where hesap_no = nvl(ln_account,0);
            exception
            when others then
                ls_DIRECT_DEBIT := 'H';
            end;

            if ln_account is null or ls_DIRECT_DEBIT = 'H'
            then
                update CBS_DIRECT_DEBIT_DATA
                set COMM_AMOUNT = 0,
                    STATUS  = 'REJECTED BUT NOW NOT ACTIVE',
                    PAYMENT_CHARGED = 'H',
                    CHARGED_PAYMENT_AMOUNT = 0,
                    COMMISSION_CHARGED = 'H',
                    CHARGED_COMMISSION_AMOUNT = 0
                WHERE INTERNAL_NO = r1.INTERNAL_NO
                  and SIRA_NO = r1.SIRA_NO;
            else
                ln_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_account);
                ln_rej_komisyon := pkg_direct_debit.Reject_Comm_Amount(r1.amount);
                ln_rej_tax := round(((ln_rej_komisyon*ln_rate)/100),2);

                if ln_total_balance >= round((ln_rej_komisyon + ln_rej_tax),2)
                then
                    ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_SUBE));

                    varchar_list(p_7062_HESAP) := ln_account;
                    varchar_list(p_7062_SUBE)  := pkg_hesap.HesaptanSubeAl(varchar_list(p_7062_HESAP));
                    number_list(p_7062_COMM_TUTAR):= ln_rej_komisyon;

                    number_list(p_7062_TAX_TUTAR):= ln_rej_tax;
                    varchar_list(p_7062_TAX_ACIKLAMA) := 'Tax of Direct Debit Commission for Account : '||ln_account;

                ----  FX CONV HERE
                    if ln_bakiye < round((ln_rej_komisyon + ln_rej_tax),2)
                    then
                        ln_hesaptan_al := 1;
                        ln_kalan_tahsilat := round((nvl(ln_rej_komisyon,0) + nvl(ln_rej_tax,0) - nvl(ln_bakiye,0)),2);

                            OPEN c_fx(ln_customer,ln_account);
                            LOOP
                            FETCH c_fx INTO r_fx ;
                            EXIT WHEN c_fx%NOTFOUND;

                                varchar_list(p_7062_CONV_HESAP) := null;
                                varchar_list(p_7062_CONV_BR)  := null;
                                varchar_list(p_7062_CONV_CY) := null;
                                varchar_list(p_7062_CONV_ACIKLAMA) := 'FX Conversion For Direct Debit';

                                number_list(p_7062_CONV_RATE) := 0;
                                number_list(p_7062_CONV_FC_AMNT)     := 0;
                                number_list(p_7062_CONV_LC_AMNT)     := 0;                                

                                            --Yerzhan Tanatov for rate difference
                                number_list(p_7062_CONV_RET_LC_AMNT) := 0;                                            
                                number_list(p_7062_RATE_DIFF_AMOUNT):= 0;
                                boolean_list(p_7062_CUSTOMER_RATE_LESS):= FALSE;
                                boolean_list(p_7062_CUSTOMER_RATE_MORE):= FALSE;

                                ln_plan:= 0;
                                ln_hesaptan_tutar := 0;
                                ln_bakiye_fx := 0;
                                ln_bakiye_dvz := 0;

                                if ln_hesaptan_al = 1 and nvl(ln_kalan_tahsilat,0) > 0
                                then
                                    varchar_list(p_7062_CONV_HESAP) := r_fx.hesap_no;
                                    varchar_list(p_7062_CONV_BR)  := pkg_hesap.HesaptanSubeAl(r_fx.hesap_no);
                                    varchar_list(p_7062_CONV_CY) := pkg_hesap.HesaptanDovizKoduAl(r_fx.hesap_no);

                                    ln_original_kur := 1;
                                    ln_hesap_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'N','A'),0)),4);
                                    --Yerzhan Tanatov
                                    p_our_buy_rate := round(Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_7062_CONV_CY),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),2);
                                    number_list(p_7062_CONV_RATE) := ln_hesap_kur;

                                    ln_hesaptan_tutar := round(
                                                               ((nvl(ln_kalan_tahsilat,0)*nvl(ln_original_kur,0))) 
                                                                                                                                                         /p_our_buy_rate
                                                                                                                                                      ,2);
                                    ln_bakiye_fx :=  trunc(pkg_hesap.Kullanilabilir_Bakiye_Al(varchar_list(p_7062_CONV_HESAP)),2);
                                    ln_bakiye_dvz := trunc((nvl(ln_bakiye_fx,0)*nvl(number_list(p_7062_CONV_RATE),0)/nvl(ln_original_kur,0)),2);

                                    if ln_bakiye_fx < 0
                                    then
                                        ln_bakiye_fx   := 0;
                                        ln_bakiye_dvz  :=0;
                                    end if;

                                    if ln_hesaptan_tutar > ln_bakiye_fx
                                    then
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT)     := nvl(ln_bakiye_fx,0);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(ln_bakiye_fx,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_bakiye_fx,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(p_our_buy_rate,0)),2);                                            
                                            ln_kalan_tahsilat := nvl(ln_kalan_tahsilat,0) - nvl(number_list(p_7062_CONV_RET_LC_AMNT),0);
                                        end if;

                                        ln_hesaptan_al := 1;
                                    else
                                        if number_list(p_7062_CONV_RATE) = 1
                                        then
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := nvl(ln_kalan_tahsilat,0);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := nvl(ln_kalan_tahsilat,0);
                                        else
                                            number_list(p_7062_CONV_FC_AMNT)     := nvl(ln_hesaptan_tutar,0);
                                            number_list(p_7062_CONV_LC_AMNT)     := round((nvl(number_list(p_7062_CONV_FC_AMNT),0)*nvl(number_list(p_7062_CONV_RATE),0)),2);
                                            number_list(p_7062_CONV_RET_LC_AMNT) := round(ln_kalan_tahsilat,2);
                                        end if;

                                        ln_kalan_tahsilat := 0 ;
                                        ln_hesaptan_al := 0;
                                    end if;

                                    if r_fx.doviz_kodu = pkg_genel.LC_al
                                    then
                                        ln_plan:= 5;
                                    else
                                        ln_plan:= 6;

                                        --Yerzhan Tanatov for rate difference                                       
                                        number_list(p_7062_RATE_DIFF_AMOUNT) := round(ABS( NVL(number_list(p_7062_CONV_LC_AMNT),0) - NVL(number_list(p_7062_CONV_RET_LC_AMNT),0) ),2);

                                                 if ln_hesap_kur < p_our_buy_rate then
                                                        boolean_list(p_7062_CUSTOMER_RATE_MORE):=true;
                                                else
                                                        boolean_list(p_7062_CUSTOMER_RATE_LESS):=true;
                                                end if;
                                     end if;
                                                                          
                                IF ln_counter = 0
                                THEN
                                     ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                                     ln_plan,
                                                                     ln_islem_no,
                                                                     varchar_list,
                                                                     number_list,
                                                                     date_list,
                                                                     boolean_list ,
                                                                     NULL,
                                                                     FALSE,
                                                                     0,
                                                                     'Direct Debitting - On Value Date');
                                ELSE
                                    ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                             ln_plan,
                                                                             ln_fis_numara,
                                                                             varchar_list,
                                                                             number_list,
                                                                             date_list,
                                                                             boolean_list,
                                                                             NULL,
                                                                             FALSE);
                                END IF;

                                ln_counter:=ln_counter+1;

                                if ln_kalan_tahsilat = 0
                                then
                                    ln_hesaptan_al := 0;
                                end if;
                            end if;
                        END LOOP;
                        CLOSE c_fx;
                    end if;
                ----  FX CONV HERE

                    IF ln_counter = 0
                    THEN
                    ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                        4,
                                                        ln_islem_no,
                                                        varchar_list,
                                                        number_list,
                                                        date_list,
                                                        boolean_list ,
                                                        NULL,
                                                        FALSE,
                                                        0,
                                                        'Direct Debitting - Missing Reject Commission Colelction');
                    ELSE
                        ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7062,
                                                                 4,
                                                                 ln_fis_numara,
                                                                 varchar_list,
                                                                 number_list,
                                                                 date_list,
                                                                 boolean_list,
                                                                 NULL,
                                                                 FALSE);
                    END IF;

                    ln_counter:=ln_counter+1;

                    Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

                    update CBS_DIRECT_DEBIT_DATA
                    set COMM_AMOUNT = ln_rej_komisyon,
                        STATUS  = 'REJECTED - COMM CHARGED',
                        PAYMENT_CHARGED = 'H',
                        CHARGED_PAYMENT_AMOUNT = 0,
                        COMMISSION_CHARGED = 'E',
                        CHARGED_COMMISSION_AMOUNT = ln_rej_komisyon,
                        COMM_CHARGE_DATE = pkg_muhasebe.Banka_Tarihi_Bul,
                        COMM_JOURNAL_NO = ln_fis_numara,
                        COMM_TX_NO = ln_islem_no,
                        ACCOUNT_BALANCE = ln_bakiye
                    WHERE INTERNAL_NO = r1.INTERNAL_NO
                      and SIRA_NO = r1.SIRA_NO;
                end if;
            end if;
        end if; ------------ if primary account's balance is not enough, check the other accounts of customer
        commit;
    END LOOP;
    CLOSE c1;
      Pkg_Batch.bitir(0,0,'Missing_Comm_Payment');

    Exception
    WHEN OTHERS THEN
        --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','missing_comm_payment','Error is: '||sqlerrm);    
        log_at('hakan_dd_error4',sqlcode,sqlerrm);
        Pkg_Batch.logla(0,0,'Missing_Comm_Payment',Pkg_Hata.GetUCPOINTER||'6047'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
          Pkg_Batch.bitir(0,0,'Missing_Comm_Payment');
end;
--------------------------------------------------------------------------------------------------------------
FUNCTION Aralik_Kontrol RETURN NUMBER
IS
    ln_sonuc        NUMBER;
    ln_bas            NUMBER;
    ln_son            NUMBER;
    ln_bas2            NUMBER;
    ln_son2            NUMBER;

    CURSOR c1 IS
    SELECT AMOUNT_1, AMOUNT_2
    FROM   CBS_DIRECT_DEBIT_COMM
    ORDER BY AMOUNT_1, AMOUNT_2;

    CURSOR c2 IS
    SELECT AMOUNT_1, AMOUNT_2
    FROM   CBS_DIRECT_DEBIT_COMM
    ORDER BY AMOUNT_1, AMOUNT_2;
BEGIN
    ln_sonuc := 0 ;

    OPEN c1 ;
    LOOP
        FETCH  c1 INTO ln_bas,ln_son;
        EXIT WHEN c1%NOTFOUND;

        OPEN c2 ;
        LOOP
            FETCH  c2 INTO ln_bas2,ln_son2;
            EXIT WHEN c2%NOTFOUND;

            IF (ln_bas = ln_bas2 and ln_son <> ln_son2) or
               (ln_bas <> ln_bas2 and ln_son = ln_son2)
            then
                ln_sonuc := 1 ;
                EXIT ;
            end if;
            IF ln_bas <> ln_bas2 AND ln_son <> ln_son2
            THEN
                IF (ln_bas >= ln_bas2 AND ln_bas <= ln_son2)
                OR (ln_son >= ln_bas2 AND ln_son <= ln_son2)
                THEN
                    ln_sonuc := 1 ;
                    EXIT ;
                END IF ;
            END IF ;
        END LOOP;
        CLOSE c2;
    END LOOP;
    CLOSE c1;

    RETURN ln_sonuc ;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '3883' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------------------------------------------------------
FUNCTION Reject_Comm_Amount(pn_amount in number) RETURN NUMBER
IS
    ln_ret        NUMBER;
BEGIN
    select REJECT_COMM
    into ln_ret
    from cbs_direct_debit_comm
    where AMOUNT_1 <= nvl(pn_amount,0) and
          AMOUNT_2  >= nvl(pn_amount,0);

    RETURN ln_ret ;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6051' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------------------------------------------------------
FUNCTION Clearing_Comm_Amount(pn_amount in number) RETURN NUMBER
IS
    ln_ret       NUMBER;
BEGIN
    select CLEARING_COMM
    into ln_ret
    from cbs_direct_debit_comm
    where AMOUNT_1 <= nvl(pn_amount,0) and
          AMOUNT_2  >= nvl(pn_amount,0);

    RETURN ln_ret ;
    EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6051' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
--------------------------------------------------------------------------------------------------------------
PROCEDURE al_file  IS
    ls_dosya_tipi                  VARCHAR2(10) := 'OUTGOING';
    ls_text                       VARCHAR2(2000);
    ls_path                          VARCHAR2(200);
    ls_filename                    VARCHAR2(2000);
    ln_sira                          NUMBER := 0;
    gn_delimiter                   VARCHAR2(3) :=';;'; -- ''';;''';
    gs_rep_delim                  VARCHAR2(3) :='::';
    ls_data                      VARCHAR2(4000);
    ls_str VARCHAR2(300);
    ls_1 VARCHAR2(35);
    ls_2 VARCHAR2(35);
    ls_3 VARCHAR2(35);
    ls_4 VARCHAR2(35);
    ls_5 VARCHAR2(35);
    ls_6 VARCHAR2(35);
    ls_7 VARCHAR2(35);
    ls_8 VARCHAR2(35);
    ls_string_payers_string VARCHAR2(300);
    ls_string_explanation VARCHAR2(300);
    ls_string_descr_rec VARCHAR2(300);

    CURSOR dosyaya_cursor IS
        SELECT *
        FROM CBS_DIRECT_DEBIT_DATA
        where status in ('REJECTED - COMM CHARGED','REJECTED - COMM MISSING','NO ACCOUNT','NOT ACTIVE','REJECTED') --Yerzhan Tanatov
        and maturity_date = pkg_muhasebe.Banka_Tarihi_Bul
        and AL_FILE_WRITTEN = 'H'
        and nvl(comes_from_uc,'N') ='N'     
        for update of AL_FILE_WRITTEN;

    r1                              dosyaya_cursor%ROWTYPE;
    Dosyalik_Bulunamadi_Exception          EXCEPTION;
    lv_EFT_bolum VARCHAR2(3);
    OUTPUT_PATH VARCHAR2(200) :='CL_OUTBOX';
BEGIN
    ls_path :=OUTPUT_PATH;
    ls_filename :=  'docsmt104.out';

    OPEN dosyaya_cursor;
    FETCH dosyaya_cursor INTO r1;
    if dosyaya_cursor%rowcount > 0 then
        Pkg_Dosya.Dosya_Ac(ls_path,ls_filename,'w');
        LOOP
        EXIT WHEN dosyaya_cursor%NOTFOUND;

            if nvl(r1.comes_from_uc,'N') ='N' then --sevalb 24012012
                ls_str:= REPLACE(RPAD(RTRIM(NVL(r1.FROM_DESCRIPTION,'')),175,' '),gn_delimiter,gs_rep_delim);
                ls_1 := SUBSTR(ls_str,1,35);
                ls_2 := SUBSTR(ls_str,36,35);
                ls_3 := SUBSTR(ls_str,71,35);
                ls_4 := SUBSTR(ls_str,106,35);
                ls_5 := SUBSTR(ls_str,141,35);

                ls_string_payers_string := RTRIM(ls_1)||gn_delimiter||RTRIM(ls_2)||gn_delimiter||RTRIM(ls_3)||gn_delimiter||RTRIM(ls_4)||gn_delimiter||RTRIM(ls_5);

                ls_str:= REPLACE(RPAD(RTRIM(NVL(r1.PURPOSE,'')),250,' '),gn_delimiter,gs_rep_delim);
                ls_1 := SUBSTR(ls_str,1,35);
                ls_2 := SUBSTR(ls_str,36,35);
                ls_3 := SUBSTR(ls_str,71,35);
                ls_4 := SUBSTR(ls_str,106,35);
                ls_5 := SUBSTR(ls_str,141,35);
                ls_6 := SUBSTR(ls_str,176,35);
                ls_7 := SUBSTR(ls_str,211,35);
                ls_8 := SUBSTR(ls_str,246,5);

                ls_string_explanation :=   RTRIM(ls_1) || gn_delimiter || RTRIM(ls_2) || gn_delimiter || RTRIM(ls_3) || gn_delimiter || RTRIM(ls_4)|| gn_delimiter ||
                                                RTRIM(ls_5) || gn_delimiter || RTRIM(ls_6) || gn_delimiter || RTRIM(ls_7) || gn_delimiter || RTRIM(ls_8)|| gn_delimiter ||
                                           gn_delimiter;

                ls_str:= REPLACE(RPAD(RTRIM(NVL(r1.TO_NAME,'')),175,' '),gn_delimiter,gs_rep_delim);
                ls_1 := SUBSTR(ls_str,1,35);
                ls_2 := SUBSTR(ls_str,36,35);
                ls_3 := SUBSTR(ls_str,71,35);
                ls_4 := SUBSTR(ls_str,106,35);
                ls_5 := SUBSTR(ls_str,141,35);

                ls_string_descr_rec := RTRIM(ls_1)||gn_delimiter||RTRIM(ls_2)||gn_delimiter||RTRIM(ls_3)||gn_delimiter||RTRIM(ls_4)||gn_delimiter||RTRIM(ls_5);

                ls_data :=   r1.PRIORITY  ||gn_delimiter||                                                            --1.PRIORITY
                              TO_CHAR(r1.MATURITY_DATE,'YYYYMMDD' ) ||gn_delimiter||                    --2.Maturity
                              r1.REFERENCE   ||gn_delimiter||                                                      --3.Clearing Session Number
                              TO_CHAR(NVL(r1.AMOUNT,0),'FM099999999999999.00') ||gn_delimiter||            --4.Documents Amount
                              REPLACE(LPAD(NVL(r1.FROM_ACCOUNT_EXTERNAL_NUMBER,0),16,'0'),gn_delimiter,gs_rep_delim)   ||gn_delimiter||    --5.Payer Account
                              REPLACE(LPAD(NVL(r1.FROM_RNN,0),14,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                            --6.ID oftax payer
                              REPLACE(LPAD(NVL(r1.FROM_OKPO,'99999999'),8,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                            --7.Payer Code of Branch Classification of Payment Turnover
                              REPLACE(NVL(r1.FROM_SOCIAL_FUND_NUMBER,''),gn_delimiter,gs_rep_delim) ||gn_delimiter||                        --8.Payer Registration Number Of Social Fund
                              ls_string_payers_string ||gn_delimiter||                                     --9.5 fields for payers description
                              r1.FROM_BANKBICCODE ||gn_delimiter||                                                --10.FROM_BANKBICCODE
                              r1.FROM_BANKNAME ||gn_delimiter||                    --11.FROM_BANKNAME, 5 fields
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              REPLACE(LPAD(NVL(r1.TO_BANKBICCODE,0),9,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                        --12.To Bank
                              REPLACE(RTRIM(SUBSTR(RPAD(r1.TO_BANKNAME,35,' '),1,35)),gn_delimiter,gs_rep_delim) ||gn_delimiter|| --13.TO_BANKNAME
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              ''||gn_delimiter||
                              REPLACE(LPAD(NVL(r1.TO_ACCOUNT_EXTERNAL_NUMBER,0),16,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||        --14.Recipient's Account
                              REPLACE(r1.TO_SUBACCOUNT,gn_delimiter,gs_rep_delim) || gn_delimiter ||                                          --15.r1.TO_SUBACCOUNT
                              ls_string_descr_rec || gn_delimiter||                                     --16.decription of receiver
                              ls_string_explanation || gn_delimiter||                                       --17.10 fields of payment explanation
                              REPLACE(RPAD(NVL(r1.DOCUMENT_NO,''),9,' '),gn_delimiter,gs_rep_delim) ||gn_delimiter||                             --18.DOCUMENT_NO
                              r1.MSG_TYPE   ||gn_delimiter||                                                           --19.MSG_TYPE
                              REPLACE(LPAD(NVL(r1.PAYMENT_TYPE,0),8,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                    --20.CODE_OF_PAYMENT
                              r1.DOCUMENT_DATE  ||gn_delimiter|| --Modified by Yerzhan Tanatov  --TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD' )||gn_delimiter|| --21.DOCUMENT_DATE
                              r1.MESSAGE_REFERENCE||gn_delimiter|| --22.Message reference, unique NB message ID -- Yerzhan Tanatov -- 01122009
                              (CASE r1.status when 'REJECTED - COMM CHARGED' then 'BNFBANKRUPT'
                                              when 'REJECTED - COMM MISSING' then 'BNFBANKRUPT'
                                              when 'NO ACCOUNT' then 'ERRACCOUNT'
                                              when 'NOT ACTIVE' then 'ERRCONTRACT'
                                              ELSE   'BNFBANKRUPT'
                                              end); --Reject Message status

                            Pkg_Dosya.Kayit_ekle(ls_data);
                            Pkg_Dosya.SatirAc;
                    
                        update cbs_direct_debit_data
                        set  al_file_written='E',
                             al_file_sysdate =sysdate,
                             al_file_bankdate  =pkg_muhasebe.banka_tarihi_bul,
                             rejected = 'E',
                             reject_date_time = sysdate,
                             reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                             reject_explanation =(CASE r1.status when 'REJECTED - COMM CHARGED' then 'BNFBANKRUPT'
                                              when 'REJECTED - COMM MISSING' then 'BNFBANKRUPT'
                                              when 'NO ACCOUNT' then 'ERRACCOUNT'
                                              when 'NOT ACTIVE' then 'ERRCONTRACT'
                                              ELSE
                                                   'BNFBANKRUPT'   
                                              end )
                        where current of dosyaya_cursor;
                    
              else
                begin
                    update cbs_direct_debit_uc_data
                    set rejected = 'E',
                        reject_date_time = sysdate,
                        reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                        reject_explanation =(CASE r1.status when 'REJECTED - COMM CHARGED' then 'BNFBANKRUPT'
                                              when 'REJECTED - COMM MISSING' then 'BNFBANKRUPT'
                                              when 'NO ACCOUNT' then 'ERRACCOUNT'
                                              when 'NOT ACTIVE' then 'ERRCONTRACT'
                                                ELSE
                                                   'BNFBANKRUPT' 
                                              end )
                    where internal_no = r1.internal_no and
                          sira_no = r1.sira_no and 
                          message_reference =R1.message_reference ;
                   Exception when others then log_at('dds2-error-al_file',r1.internal_no|| '-'|| r1.sira_no || '-'|| r1.message_reference,sqlcode,sqlerrm);
                end; 
               end if;    

            FETCH dosyaya_cursor INTO r1;
           END LOOP;
        Pkg_Dosya.dosya_kapa('w');
        pkg_dosya.kopyala( ls_path,ls_filename,ls_path||'\archive',ls_filename ||to_char(sysdate,'DDMMYYYHH24MI') );

      ls_path :='CL';
      ls_filename :=  'docsmt104.log';
      out_file :=  utl_file.Fopen(ls_path,ls_filename,'a' );
      utl_file.put_line(out_file,to_char(sysdate,'mm/dd/yyyy hh24:mi:ss'));
      utl_file.FClose(out_file);
      utl_file.fclose_all;
      end if; -- If no transactions
    CLOSE dosyaya_cursor;
  COMMIT;

 EXCEPTION
    WHEN OTHERS THEN    
      --PKG_EMAIL.SENDHTMLEMAIL('direcdebit@demirbank.kg','yerzhan.tanatov@demirbank.kg;','al_file','Error is: '||sqlerrm);
      RAISE_APPLICATION_ERROR(-20100,'200' || SQLERRM);
  END;
--------------------------------------------------------------------------------------------------------------
Function Customer_Total_Balance(pn_customer_no number, pn_primary_account number) return number
is
    ln_musteri                    number;
    ln_ret                        number;

    CURSOR c1 IS
        SELECT hesap_no,doviz_kodu
        FROM cbs_hesap
        WHERE musteri_no = pn_customer_no
          and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) > 0
          and durum_kodu = 'A'
          and hesap_no <> pn_primary_account
          and hesap_no in (select account_no
                                  from cbs_direct_debit_hesap
                           where customer_no = pn_customer_no);
    r1 c1%ROWTYPE;

    ln_kur_kgs                    NUMBER;
    ln_kur_usd                    NUMBER;
    ln_kur_eur                    NUMBER;
    ln_kur                        NUMBER;
begin
    ln_ret := pkg_hesap.Kullanilabilir_Bakiye_Al(pn_primary_account);

    OPEN c1 ;
    LOOP
    FETCH c1 INTO r1 ;
    EXIT WHEN c1%NOTFOUND;
        ln_kur := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r1.DOVIZ_KODU,'KGS',NULL,1,3,NULL,NULL,'N','A'),0)),4);
        ln_ret := ln_ret + pkg_hesap.Kullanilabilir_Bakiye_Al(r1.hesap_no)*ln_kur;
    END LOOP;
    CLOSE c1;

    return trunc((nvl(ln_ret,0)),2);

    exception
    when others then
        return 0;
end;
----------------------------------    ---------------------------------------------------------------
--MessageLoad_UC to load txt file from other banks
PROCEDURE MessageLoad_UC(ps_input_file_name varchar2  default 'MT104.TXT',pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'MESSAGELOAD_UC' ) 
is
    f                utl_file.file_type;
    ls_dirlist        varchar2(2000);
    ln_filecount    number;
    ln_fileindex    number;
    ls_input_filename        varchar2(2000) := upper(ps_input_file_name);
    ls_Output_filename        varchar2(2000);
    ls_outstr        varchar2(2000);
    ls_path            varchar2(2000);
    ln_MSG_ID         varchar2(2000);
    ls_MSG_TYPE     varchar2(2000);
    ls_satir varchar2(2100);
    ls_par1 varchar2(200);
    ls_par2 varchar2(2000);
    ls_par3 varchar2(2000);
    ls_par4 varchar2(2000);
    ls_par5 varchar2(2000);
    ls_par6 varchar2(2000);
    ls_par7 varchar2(2000);
    ls_par8 varchar2(2000);
    ls_par9 varchar2(2000);
    ls_par10 varchar2(2000);
    ls_par11 varchar2(2000);
    ls_par12 varchar2(2000);
    ls_par13 varchar2(2000);
    ls_par14 varchar2(2000);
    ls_par15 varchar2(2000);
    ls_par16 varchar2(2000);
    ls_par17 varchar2(2000);
    ls_par18 varchar2(2000);
    ls_par19 varchar2(2000);
    ls_par20 varchar2(2000);
    ls_par21 varchar2(2000);
    ls_par22 varchar2(2000);
    ls_par23 varchar2(2000);
    ls_par24 varchar2(2000);
    ls_par25 varchar2(2000);
    ls_par26 varchar2(2000);
    ls_ad   varchar2(2000);
    ls_param_str varchar2(2000);
    ln_sira_no              number := 0;
    ls_our_customer            varchar2(1);
    dosya_hata  exception;
    v_ls_par13 varchar2(2000);
    v_ls_par13t varchar2(2000) := '0';
    v_ls_par13d varchar2(2000) := '0';
    n_ls_par13 NUMBER;
    ln_txt_file_internal_no     number;
    ln_account           number;
    ld_maturity_date   date;

--    OUTPUT_PATH VARCHAR2(200) :='D:\SHARED\CLEARING\OUTBOX\';

    ls_dosya_tipi                  VARCHAR2(10) := 'OUTGOING';
    ls_text                       VARCHAR2(2000);
    ln_sira                          NUMBER := 0;
    gn_delimiter                   VARCHAR2(3) :=';;'; -- ''';;''';
    gs_rep_delim                  VARCHAR2(3) :='::';


    ls_data                      VARCHAR2(4000);
    ls_str VARCHAR2(300);
    ls_1 VARCHAR2(35);
    ls_2 VARCHAR2(35);
    ls_3 VARCHAR2(35);
    ls_4 VARCHAR2(35);
    ls_5 VARCHAR2(35);
    ls_6 VARCHAR2(35);
    ls_7 VARCHAR2(35);
    ls_8 VARCHAR2(35);
    ls_string_payers_string VARCHAR2(300);
    ls_string_explanation VARCHAR2(300);
    ls_string_descr_rec VARCHAR2(300);
    ld_document_date        varchar2(8);
    ln_kayit_var   number := 0;
    ls_err                           VARCHAR2(2000);    
    ls_ucpointer                     VARCHAR2(3) := pkg_hata.getucpointer;
    ls_delimiter                     VARCHAR2(3) := pkg_hata.getdelimiter;
    ls_hata_mesaj       varchar2(2000);
    ls_priority char(2) :='01';    
  
    dosya_onceden_yuklendi exception ;
    dosya_bulunamadi                 EXCEPTION;    
    dosya_kopyalama_hatasi           EXCEPTION;
    dosya_silme_hatasi               EXCEPTION;    

BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
   -- Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6050'||Pkg_Hata.GetUCPOINTER);
    
   
            ln_txt_file_internal_no :=pkg_genel.genel_kod_al('DIRECT_DEBIT');
            ls_path := 'CL_INBOX';
                    
            Begin
                f:=utl_file.fopen(ls_path, ls_input_filename, 'r',2100);
                Exception when others then
                raise dosya_bulunamadi ;
            End;
            ls_MSG_TYPE:='INCOMING';

             utl_file.get_line(f, ls_outstr);
            Begin
                LOOP         
                    ls_outstr:= replace(ls_outstr,'null','');                      
                                      
                    IF ls_outstr IS NULL
                    THEN
                        RAISE NO_DATA_FOUND;
                    END IF;                    
                          
                    ls_satir := ';'|| ls_outstr ;
                    ls_par1 := SplitStr_UC(ls_satir,1); --Unused
                    ls_par2 := SplitStr_UC(ls_satir,2); --Unused
                    ls_par3 := SplitStr_UC(ls_satir,3); --TYPE_MSG
                    ls_par4 := SplitStr_UC(ls_satir,4); --TYPE_PLT
                    ls_par5 := SplitStr_UC(ls_satir,5); --DATE_VAL
                    ls_par6 := SplitStr_UC(ls_satir,6); --T52A
                    ls_par7 := SplitStr_UC(ls_satir,7); --T52A_NAME
                    ls_par8 := SplitStr_UC(ls_satir,8); --T26T
                    ls_par9 := SplitStr_UC(ls_satir,9); --T50
                    ls_par10 := SplitStr_UC(ls_satir,10); --T50_SCHET
                    ls_par11 := SplitStr_UC(ls_satir,11); --T50_SUB
                    ls_par12 := SplitStr_UC(ls_satir,12); --T50_NAME
                    ls_par13 := SplitStr_UC(ls_satir,13); --T32B

                    v_ls_par13 := REPLACE(REPLACE(ls_par13,',','#'),'.','#');

                    v_ls_par13t := '0';
                    v_ls_par13d := '0';

                    IF instr(v_ls_par13,'#') >0 THEN
                        v_ls_par13t := substr(v_ls_par13,1,instr(v_ls_par13,'#')-1);
                        v_ls_par13d := substr(v_ls_par13,instr(v_ls_par13,'#')+1);
                    ELSE
                        v_ls_par13t := v_ls_par13;
                    END IF;

                    n_ls_par13 := to_number(v_ls_par13t) + to_number(v_ls_par13d)/100;

                    ls_par14 := SplitStr_UC(ls_satir,14); --T57
                    ls_par15 := SplitStr_UC(ls_satir,15); --T57_NAME
                    ls_par16 := SplitStr_UC(ls_satir,16); --T59
                    ls_par17 := SplitStr_UC(ls_satir,17); --T59_INN
                    ls_par18 := SplitStr_UC(ls_satir,18); --T59_OKPO
                    ls_par19 := SplitStr_UC(ls_satir,19); --T59_SFOND
                    ls_par20 := SplitStr_UC(ls_satir,20); --T59_SUB
                    ls_par21 := SplitStr_UC(ls_satir,21); --T59_LS
                    ls_par22 := SplitStr_UC(ls_satir,22); --T59_NAME
                    ls_par23 := SplitStr_UC(ls_satir,23); --T70
                    ls_par24 := SplitStr_UC(ls_satir,24); --?0_1
                    ls_par25 := SplitStr_UC(ls_satir,25); --T77B_DNUM
                    ls_par26 := SplitStr_UC(ls_satir,26); --T77B_DDATE

                     begin
                         ln_account := pkg_hesap.GetHesapNoFromExternal(ls_par16,pkg_genel.LC_al);
                     exception
                     when others then
                         ln_account := NULL;
                     end;

                    ln_sira_no := ln_sira_no + 1 ;

                    if ln_account is not null
                    then
                        ls_our_customer := 'Y';
                    else
                        ls_our_customer := 'N';
                    end if;
               
             if ls_par5  is not null and ls_par6 is not null then 
                    insert into cbs_direct_debit_uc_data (
                    internal_no,
                    sira_no,
                    type_msg,
                    type_plt,
                    date_val,
                    t52a,
                    t52a_name,
                    t26t,
                    t50,
                    t50_schet,
                    t50_sub,
                    t50_name,
                    t32b,
                    t57,
                    t57_name,
                    t59,
                    t59_inn,
                    t59_okpo,
                    t59_sfond,
                    t59_sub,
                    t59_ls,
                    t59_name,
                    t70,
                    t70_1,
                    t77b_dnum,
                    t77b_ddate,
                    our_customer,
                    account_no,
                    message_reference,
                    file_name ,        
                    bank_date  ,        
                    number_column ,        
                    service_id_column ,        
                    param1_column ,        
                    file_id_no          
        )
                    values (
                        ln_txt_file_internal_no,
                        ln_sira_no,
                        ls_par3,
                        ls_par4,
                        ls_par5,
                        ls_par6,
                        ls_par7,
                        ls_par8,
                        ls_par9,
                        ls_par10,
                        ls_par11,
                        ls_par12,
                        ls_par13,--amount
                        ls_par14,
                        ls_par15,
                        ls_par16,
                        ls_par17,
                        ls_par18,
                        ls_par19,
                        ls_par20,
                        ls_par21,
                        ls_par22,
                        ls_par23,
                        ls_par24,
                        ls_par25,
                        ls_par26,
                        ls_our_customer,
                        ln_account,
                        pkg_genel.genel_kod_al('DIRECT_DEBIT_MSG_REF'),
                        ls_input_filename,
                        pkg_muhasebe.banka_tarihi_bul,        
                        null ,--number_column ,        
                        null,--service_id_column ,        
                        null, --param1_column ,        
                        ln_txt_file_internal_no --file_id_no        
                         );
                    end if;
                    
                  utl_file.get_line(f, ls_outstr);--Yerzhant moved here
            
                END LOOP;

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    pkg_dosya.dosya_kapa('r');
            End;

   COMMIT;  

-- File copy to acrhive and remove operation 
        Begin
            pkg_dosya.kopyala( 'CL_INBOX', ls_input_filename, 'INBOX_ARCHIVE', ls_input_filename ||to_char(sysdate,'DDMMYYYHH24MI') ); -- MaratM 01072021
         Exception
            when others then
                RAISE dosya_kopyalama_hatasi;
         END;

        Begin        
            PKG_DOSYA.DOSYA_SIL ('CL_INBOX', ls_input_filename );
        Exception
            when others then
                RAISE dosya_silme_hatasi;  
        end; 
 
   

    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    EXCEPTION
     WHEN dosya_bulunamadi
        THEN
         ROLLBACK;
         log_at('messageload_uc-error-dosya_bulunamadi',ls_path|| '\'|| ls_input_filename,sqlcode,sqlerrm);              
         utl_file.fclose_all;
         ls_err := '6150';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename
                                                  || ls_delimiter
                                                  || ls_path 
                                                  || ls_delimiter
                                                  || ls_ucpointer);           
          Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
          Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN dosya_kopyalama_hatasi
         THEN
         ROLLBACK;
         utl_file.fclose_all;
         ls_err := '841';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                  || ls_delimiter
                                                  || ls_ucpointer);
              Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
              Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN dosya_silme_hatasi
          THEN
             ROLLBACK;              
             utl_file.fclose_all;
             ls_err := '842';
             ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                      || ls_err
                                                      || ls_delimiter
                                                      || ls_input_filename || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                      || ls_delimiter
                                                      || ls_ucpointer);
               Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
               Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN OTHERS THEN
        ROLLBACK;              
                 utl_file.fclose_all;
                 ls_err := '6165';
                ls_param_str := substr( ls_par1||','||ls_par2||','||ls_par3||','||
                            ls_par4||','||ls_par5||','||ls_par6||','||ls_par7||','||ls_par8||','||ls_par9||','||
                            ls_par10||','||ls_par11||','||ls_par12||','||ls_par13||','||ls_par14||','||ls_par15||','||
                            ls_par16||','||ls_par17||','||ls_par18||','||ls_par19||','||ls_par20||','||ls_par21||','||
                            ls_par22  ,1,1700);  
                 ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                          || ls_err
                                                          || ls_delimiter
                                                          ||'File Name:'|| ls_input_filename || ',Error:' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 180)
                                                          || ls_delimiter
                                                          || ls_ucpointer);
                   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
                   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    END;
/*---------------------------------------------------------------------------------------*/
/*cbs_direct_debit_uc_data durum kodlari
A  : Created
V  : insert into sub tables and waiting for reject
R  :Rejected
K  :Closed processed 
*/
/*--------------------------------------------------------------------------------------*/
-- PROCEDURE ins_dds_cust_noncust_tbl:cbs_direct_debit_uc_data table is inserted from MessageLoad_UC,MessageLoad_xml (called by DDSFL screen) 
--and 7070 our customer file load is processed
-- pupose of this procedure to insert into sub tables which will be used in DIRIZ view 
-- (cbs_direct_debit_data ,cbs_direct_debit_data_other_bn) 
/*---------------------------------------------------------------------------------------*/   
PROCEDURE ins_dds_cust_noncust_tbl(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'INS_DDS_CUST_NONCUST_TBL' )
is
    cursor c_customer is
        select     *
        from cbs_direct_debit_uc_data
        where  durum_kodu = 'A'          
           and account_no is not null
           and our_customer = 'Y' 
       for update of durum_kodu,kapanis_tarihi,kapanis_system_tarihi; 

        r_customer        c_customer%ROWTYPE;

    cursor c_noncustomer is
        select     *
        from cbs_direct_debit_uc_data
        where  durum_kodu = 'A'     
           and account_no is null
            and our_customer = 'N'    
            and nvl(ucdocsmt104_out_file_written,'H') = 'H'       
            for update of ucdocsmt104_out_file_written,ucdocsmt104_out_file_sysdate,ucdocsmt104_out_file_bankdate,
                           durum_kodu,kapanis_tarihi,kapanis_system_tarihi;

    r_noncustomer        c_noncustomer%ROWTYPE;
    ls_our_customer            varchar2(1);

    ln_account           number;
    ld_maturity_date   date;
    ld_document_date        varchar2(8);
    ln_kayit_var   number := 0;
    ls_err                           VARCHAR2(2000);    
    ls_ucpointer                     VARCHAR2(3) := pkg_hata.getucpointer;
    ls_delimiter                     VARCHAR2(3) := pkg_hata.getdelimiter;
    ls_hata_mesaj       varchar2(2000);
    ls_priority char(2) :='01';    

BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  -- Our Customers
    OPEN c_customer;
    LOOP
    FETCH c_customer INTO r_customer ;
    EXIT WHEN c_customer%NOTFOUND;
        ld_maturity_date := null;
        begin
            ln_account := pkg_hesap.GetHesapNoFromExternal(r_customer.T50,pkg_genel.LC_al);
        exception
        when others then
            ln_account := NULL;
        end;
         
        ld_maturity_date := to_date('20'||to_char(r_customer.DATE_VAL,'FM000000'),'yyyymmdd');

        ld_document_date := '20'||to_char(r_customer.T77B_DDATE,'FM000000');--to_char(r_customer.T77B_DDATE,'FM000000');
                insert into cbs_direct_debit_data (
                internal_no,
                sira_no,
                priority,
                maturity_date,
                reference,
                amount,
                from_account_external_number,
                from_rnn,
                from_okpo,
                from_social_fund_number,
                from_description,
                from_bankbiccode,
                from_bankname,
                to_bankbiccode,
                to_bankname,
                to_account_external_number,
                to_subaccount,
                to_name,
                purpose,
                document_no,
                msg_type,
                payment_type,
                document_date,
                file_name,
                bank_date,
                comes_from_uc,
                uc_account,
                message_reference,
                number_column ,        
                service_id_column ,        
                param1_column ,       
                file_id_no   ,
                kt_personel_account_number     
                )
                values (
                r_customer.internal_no,
                r_customer.sira_no,
                ls_priority,
                ld_maturity_date,          -- maturity_date
                r_customer.message_reference,                       -- reference
                r_customer.t32b,           -- amount
                r_customer.t50,               -- from_account_external_number
                null,                      -- from rnn
                null,                      -- from okpo
                null,                      -- from social fund
                r_customer.t50_name,     -- from desc
                r_customer.t52a,         -- from bankbic
                r_customer.t52a_name,    -- from_bankname
                r_customer.t57,         -- to_bankbiccode
                r_customer.t57_name,    -- to_bankname
                r_customer.t59,            -- to_account_external_number
                null,                         -- to_subaccount
                r_customer.t59_name,      -- to_name
                r_customer.t70 || r_customer.t70_1,           -- purpose
                r_customer.t77b_dnum ,  -- document_no
                r_customer.type_msg,    -- msg_type
                r_customer.type_plt,      -- payment_type
                ld_document_date,     -- doc date,
                r_customer.file_name,              -- file_name
                pkg_muhasebe.banka_tarihi_bul,
                'Y',
                ln_account,
                r_customer.message_reference,
                r_customer.number_column ,        
                r_customer.service_id_column ,        
                r_customer.param1_column ,        
                r_customer.file_id_no ,
                r_customer.t59_ls      );
            
               update cbs_direct_debit_uc_data
               set  durum_kodu = 'V',
                    kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                    kapanis_system_tarihi = sysdate
                where current of c_customer;
    
    END LOOP;
    CLOSE c_customer;
         
  -- NOT Our Customers       
  ln_account:= null;
  OPEN c_noncustomer;
    LOOP
    FETCH c_noncustomer INTO r_noncustomer ;
    EXIT WHEN c_noncustomer%NOTFOUND;
            ld_maturity_date := null;   
            begin
            ld_maturity_date := to_date('20'||to_char(r_noncustomer.DATE_VAL,'FM000000'),'yyyymmdd');
            exception when others then log_at('error-ld_maturity_date',sqlcode,sqlerrm); end;
            
            if r_noncustomer.T77B_DDATE is not null then     
                ld_document_date := '20'||to_char(r_noncustomer.T77B_DDATE,'FM000000');
            end if;

                   INSERT INTO CBS_DIRECT_DEBIT_DATA_OTHER_BN (
                    internal_no,
                    sira_no,
                    priority,
                    maturity_date,
                    reference,
                    amount,
                    from_account_external_number,
                    from_rnn,
                    from_okpo,
                    from_social_fund_number,
                    from_description,
                    from_bankbiccode,
                    from_bankname,
                    to_bankbiccode,
                    to_bankname,
                    to_account_external_number,
                    to_subaccount,
                    to_name,
                    purpose,
                    document_no,
                    msg_type,
                    payment_type,
                    document_date,
                    file_name,
                    bank_date,
                    comes_from_uc,
                    uc_account,
                    message_reference,
                    number_column ,        
                    service_id_column ,        
                    param1_column ,       
                    file_id_no     ,
                    kt_personel_account_number                    
                   )
                    VALUES (
                    r_noncustomer.internal_no,
                    r_noncustomer.sira_no,
                    ls_priority,
                    ld_maturity_date,          -- MATURITY_DATE
                    r_noncustomer.MESSAGE_REFERENCE,             -- REFERENCE
                    r_noncustomer.T32B,           -- AMOUNT
                    r_noncustomer.T50,               -- FROM_ACCOUNT_EXTERNAL_NUMBER
                    null,                      -- from rnn
                    null,                      -- from okpo
                    null,                      -- from social fund
                    r_noncustomer.T50_NAME,     -- from desc
                    r_noncustomer.T52A,         -- from bankbic
                    r_noncustomer.T52A_NAME,    -- FROM_BANKNAME
                    r_noncustomer.T57,         -- TO_BANKBICCODE
                    r_noncustomer.T57_NAME,    -- TO_BANKNAME
                    r_noncustomer.T59,            -- TO_ACCOUNT_EXTERNAL_NUMBER
                    null,                         -- TO_SUBACCOUNT
                    r_noncustomer.T59_NAME,      -- TO_NAME
                    r_noncustomer.T70 || r_noncustomer.T70_1,           -- PURPOSE
                    r_noncustomer.T77B_DNUM ,  -- DOCUMENT_NO
                    r_noncustomer.TYPE_MSG,    -- MSG_TYPE
                    r_noncustomer.TYPE_PLT,      -- PAYMENT_TYPE
                    ld_document_date,     -- Doc Date,
                    r_noncustomer.file_name,              -- FILE_NAME
                    pkg_muhasebe.Banka_Tarihi_Bul,
                    'Y',
                    ln_account,
                    r_noncustomer.message_Reference,
                    r_noncustomer.number_column ,        
                    r_noncustomer.service_id_column ,        
                    r_noncustomer.param1_column ,       
                    r_noncustomer.file_id_no,
                    r_noncustomer.t59_ls   );
                
                 --E-O-M SEVALB 18012012
        
                    UPDATE CBS_DIRECT_DEBIT_UC_DATA
                     SET   durum_kodu = 'V',
                         kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                         kapanis_system_tarihi = sysdate
                    WHERE internal_no = r_noncustomer.internal_no and 
                          sira_no = r_noncustomer.sira_no ;
        END LOOP;

            
    CLOSE c_noncustomer;

    COMMIT;
      Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    EXCEPTION
     WHEN others
        THEN
         ROLLBACK;
         log_at('ins_dds_cust_noncust_tbl-error',sqlcode,sqlerrm);              
         ls_err := '6166';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 1800)
                                                  || ls_delimiter
                                                  || ls_ucpointer);           
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        
          
END;
/*---------------------------------------------------------------------------------------*/
----WRITE_INTO_UCDOCSMT104OUT_FILE procedure to  create  UCdocsmt104.out file for non customer   
PROCEDURE WRITE_INTO_UCDOCSMT104OUT_FILE(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'WRITE_INTO_UCDOCSMT104OUT_FILE' )
is
    f                         utl_file.file_type;
    ls_dirlist                varchar2(2000);
    ln_filecount              number;
    ln_fileindex              number;
    ls_Output_filename        varchar2(2000);
    ls_outstr                 varchar2(2000);
    ls_path                   varchar2(2000);
    ln_MSG_ID                 varchar2(2000);
    ls_MSG_TYPE               varchar2(2000);
    ls_satir                  varchar2(2100);

    cursor c_noncustomer is
        select     *
        from cbs_direct_debit_uc_data
        where  durum_kodu in( 'V')     
           and account_no is null
            and our_customer = 'N'    
            and nvl(ucdocsmt104_out_file_written,'H') = 'H'       
            for update of ucdocsmt104_out_file_written,ucdocsmt104_out_file_sysdate,ucdocsmt104_out_file_bankdate,
                  durum_kodu,kapanis_tarihi,kapanis_system_tarihi;

    r_noncustomer        c_noncustomer%ROWTYPE;
    ls_our_customer            varchar2(1);
    dosya_hata  exception;

    ln_account           number;
    ld_maturity_date   date;

--    OUTPUT_PATH VARCHAR2(200) :='D:\SHARED\CLEARING\OUTBOX\'; CL_OUTBOX D:\SHARED\CLEARING\OUTBOX\

    ls_dosya_tipi                  VARCHAR2(10) := 'OUTGOING';
    ls_text                       VARCHAR2(2000);
    ln_sira                          NUMBER := 0;
    gn_delimiter                   VARCHAR2(3) :=';;'; -- ''';;''';
    gs_rep_delim                  VARCHAR2(3) :='::';
    ls_data                      VARCHAR2(4000);
    ls_str VARCHAR2(300);
    ls_1 VARCHAR2(35);
    ls_2 VARCHAR2(35);
    ls_3 VARCHAR2(35);
    ls_4 VARCHAR2(35);
    ls_5 VARCHAR2(35);
    ls_6 VARCHAR2(35);
    ls_7 VARCHAR2(35);
    ls_8 VARCHAR2(35);
    ls_string_payers_string VARCHAR2(300);
    ls_string_explanation VARCHAR2(300);
    ls_string_descr_rec VARCHAR2(300);
    ld_document_date        varchar2(8);
    ln_kayit_var   number := 0;
    ls_err                           VARCHAR2(2000);    
    ls_ucpointer                     VARCHAR2(3) := pkg_hata.getucpointer;
    ls_delimiter                     VARCHAR2(3) := pkg_hata.getdelimiter;
    ls_hata_mesaj       varchar2(2000);
    ls_priority char(2) :='01';    
  
    dosya_onceden_yuklendi exception ;
    dosya_bulunamadi                 EXCEPTION;    
    dosya_kopyalama_hatasi           EXCEPTION;
    dosya_silme_hatasi               EXCEPTION;    

BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    
         
  -- Not Our Custoemrs
--    ls_path :=OUTPUT_PATH;
    ls_output_filename :=  'UCdocsmt104.out';
      
      select    count(*)
        into ln_kayit_var
        from cbs_direct_debit_uc_data
        where  durum_kodu = 'V'     
           and account_no is null
            and our_customer = 'N'    
            and nvl(ucdocsmt104_out_file_written,'H') = 'H' ;  

    if nvl( ln_kayit_var,0) <> 0 then
        Pkg_Dosya.Dosya_Ac('CL_OUTBOX',ls_output_filename,'w'); -- MaratM 01072021
    end if;
  
  OPEN c_noncustomer;
    LOOP
    FETCH c_noncustomer INTO r_noncustomer ;
    EXIT WHEN c_noncustomer%NOTFOUND;
          -- LOG_aT('r_noncustomer',r_noncustomer.T50_NAME);
            begin
            ld_maturity_date := to_date('20'||to_char(r_noncustomer.DATE_VAL,'FM000000'),'yyyymmdd');
            exception when others then log_at('error-ld_maturity_date',sqlcode,sqlerrm); end;
            
            if r_noncustomer.T77B_DDATE is not null then     
                ld_document_date := '20'||to_char(r_noncustomer.T77B_DDATE,'FM000000');
            end if;

            ls_str:= REPLACE(RPAD(RTRIM(NVL(r_noncustomer.T50_NAME,'')),175,' '),gn_delimiter,gs_rep_delim);
            ls_1 := SUBSTR(ls_str,1,35);
            ls_2 := SUBSTR(ls_str,36,35);
            ls_3 := SUBSTR(ls_str,71,35);
            ls_4 := SUBSTR(ls_str,106,35);
            ls_5 := SUBSTR(ls_str,141,35);

            ls_string_payers_string := RTRIM(ls_1)||gn_delimiter||RTRIM(ls_2)||gn_delimiter||RTRIM(ls_3)||gn_delimiter||RTRIM(ls_4)||gn_delimiter||RTRIM(ls_5);
         
            ls_str:= REPLACE(RPAD(RTRIM(NVL(r_noncustomer.T70 || r_noncustomer.T70_1,'')),250,' '),gn_delimiter,gs_rep_delim);
            ls_1 := SUBSTR(ls_str,1,35);
            ls_2 := SUBSTR(ls_str,36,35);
            ls_3 := SUBSTR(ls_str,71,35);
            ls_4 := SUBSTR(ls_str,106,35);
            ls_5 := SUBSTR(ls_str,141,35);
            ls_6 := SUBSTR(ls_str,176,35);
            ls_7 := SUBSTR(ls_str,211,35);
            ls_8 := SUBSTR(ls_str,246,5);

            ls_string_explanation :=   RTRIM(ls_1) || gn_delimiter || RTRIM(ls_2) || gn_delimiter || RTRIM(ls_3) || gn_delimiter || RTRIM(ls_4)|| gn_delimiter ||
                                       RTRIM(ls_5) || gn_delimiter || RTRIM(ls_6) || gn_delimiter || RTRIM(ls_7) || gn_delimiter || RTRIM(ls_8)|| gn_delimiter ||
                                       gn_delimiter;

            ls_str:= REPLACE(RPAD(RTRIM(NVL(r_noncustomer.T59_NAME,''))||' '|| RTRIM(NVL(null,'')),175,' '),gn_delimiter,gs_rep_delim);
            ls_1 := SUBSTR(ls_str,1,35);
            ls_2 := SUBSTR(ls_str,36,35);
            ls_3 := SUBSTR(ls_str,71,35);
            ls_4 := SUBSTR(ls_str,106,35);
            ls_5 := SUBSTR(ls_str,141,35);
            
            ls_string_descr_rec := RTRIM(ls_1)||gn_delimiter||RTRIM(ls_2)||gn_delimiter||RTRIM(ls_3)||gn_delimiter||RTRIM(ls_4)||gn_delimiter||RTRIM(ls_5);
 
            ls_data :=   
                            r_noncustomer.MESSAGE_REFERENCE ||gn_delimiter|| --sevalb 04102011      -- sevalb 0.MESSAGE REFERENCE UQ ID will be used for reject
                          '01'  ||gn_delimiter||                                                            --1.PRIORITY
                          TO_CHAR(ld_maturity_date,'YYYYMMDD' ) ||gn_delimiter||                    --2.Maturity
                          '1'   ||gn_delimiter||                                                      --3.Clearing Session Number
                          TO_CHAR(NVL(r_noncustomer.T32B,0),'FM099999999999999.00') ||gn_delimiter||            --4.Documents Amount
                          REPLACE(LPAD(NVL(r_noncustomer.T50,0),16,'0'),gn_delimiter,gs_rep_delim)   ||gn_delimiter||    --5.Payer Account
                          REPLACE(LPAD(NVL(null,0),14,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                            --6.ID oftax payer
                          REPLACE(LPAD(NVL(null,'99999999'),8,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                            --7.Payer Code of Branch Classification of Payment Turnover
                          REPLACE(NVL(null,''),gn_delimiter,gs_rep_delim) ||gn_delimiter||                        --8.Payer Registration Number Of Social Fund
                          ls_string_payers_string ||gn_delimiter||                                     --9.5 fields for payers description
                          lpad(r_noncustomer.T52A,9,'0')  ||gn_delimiter||                                                --10.FROM_BANKBICCODE
                          r_noncustomer.T52A_NAME ||gn_delimiter||                    --11.FROM_BANKNAME, 5 fields
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          REPLACE(LPAD(NVL(r_noncustomer.T57,0),9,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                        --12.To Bank
                          REPLACE(RTRIM(SUBSTR(RPAD(r_noncustomer.T57_NAME,35,' '),1,35)),gn_delimiter,gs_rep_delim) ||gn_delimiter|| --13.TO_BANKNAME
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          ''||gn_delimiter||
                          REPLACE(LPAD(NVL(r_noncustomer.T59,0),16,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||        --14.Recipient's Account
                          REPLACE(null,gn_delimiter,gs_rep_delim) || gn_delimiter ||                                          --15.TO_SUBACCOUNT
                          ls_string_descr_rec || gn_delimiter||                                     --16.decription of receiver
                          ls_string_explanation || gn_delimiter||                                       --17.10 fields of payment explanation
                          REPLACE(RPAD(NVL(r_noncustomer.T77B_DNUM,''),9,' '),gn_delimiter,gs_rep_delim) ||gn_delimiter||                             --18.DOCUMENT_NO
                          r_noncustomer.TYPE_MSG   ||gn_delimiter||                                                           --19.MSG_TYPE
                          r_noncustomer.T26T   ||gn_delimiter||  --Yerzhant --20.CODE_OF_PAYMENT REPLACE(LPAD(NVL(r_noncustomer.TYPE_PLT,0),8,'0'),gn_delimiter,gs_rep_delim)  ||gn_delimiter||                    --20.CODE_OF_PAYMENT
                          TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD' );                                                   --21.DOCUMENT_DATE
                    
                    UPDATE CBS_DIRECT_DEBIT_UC_DATA
                     SET UCdocsmt104_out_file_written = 'E' ,
                         UCdocsmt104_out_file_sysdate=sysdate,
                         UCdocsmt104_out_file_bankdate = pkg_muhasebe.banka_tarihi_bul
                     --    durum_kodu = 'V',
                     --    kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                      --   kapanis_system_tarihi = sysdate
                    WHERE internal_no = r_noncustomer.internal_no and 
                          sira_no = r_noncustomer.sira_no ;
                  
                     UPDATE CBS_DIRECT_DEBIT_DATA_OTHER_BN
                     SET UCdocsmt104_out_file_written = 'E' ,
                         UCdocsmt104_out_file_sysdate=sysdate,
                         UCdocsmt104_out_file_bankdate = pkg_muhasebe.banka_tarihi_bul
                    WHERE internal_no = r_noncustomer.internal_no and 
                          sira_no = r_noncustomer.sira_no and
                          message_reference = r_noncustomer.message_reference  ;
        
                Pkg_Dosya.Kayit_ekle(ls_data);
                Pkg_Dosya.SatirAc;
            END LOOP;

            Pkg_Dosya.dosya_kapa('w');
            pkg_dosya.kopyala( ls_path,ls_output_filename,ls_path||'\archive',ls_output_filename ||to_char(sysdate,'DDMMYYYHH24MI') ); 
             
--            ls_path :='D:\SHARED\CLEARING';
            ls_output_filename :=  'UCdocsmt104.log';
            out_file :=  utl_file.Fopen('CL',ls_output_filename,'a' ); -- MaratM 01072021
            utl_file.put_line(out_file,to_char(sysdate,'mm/dd/yyyy hh24:mi:ss'));
            utl_file.FClose(out_file);
            utl_file.fclose_all;

    CLOSE c_noncustomer;

  
    COMMIT;

      Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    EXCEPTION
     WHEN others
        THEN
         ROLLBACK;
         log_at('write_into_ucdocsmt104out_file-error',sqlcode,sqlerrm);              
         utl_file.fclose_all;
         ls_err := '6166';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 1800)
                                                  || ls_delimiter
                                                  || ls_ucpointer);           
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);        
          
END;
--------------------------------------------------------------------------------------------------------------
FUNCTION SplitStr_UC(ps_str IN VARCHAR2,pn_valindx IN NUMBER ,ps_delimeter IN VARCHAR2 default ';') RETURN VARCHAR2 IS
        ln_i                NUMBER:=1;
        ln_itemindx       NUMBER:=0;
        ls_strOut        VARCHAR2(2000);
BEGIN
    LOOP
    EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
        IF ln_itemindx=pn_valindx THEN
            IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
                ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
            ELSE
                ls_strOut:=SUBSTR(ps_str,ln_i);
            END IF;

            RETURN ls_strOut;
        END IF;

        IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
            ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
        ELSE
            ln_i:=LENGTH(ps_str)+1;
        END IF;

        ln_itemindx:=ln_itemindx+1;
    END LOOP;
    RETURN '';
END;
--------------------------------------------------------------------------------------------------------------
PROCEDURE  MessageLoad_Rejects(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'MESSAGELOAD_REJECTS')
is
    f                utl_file.file_type;
    ls_dirlist        varchar2(2000);
    ln_filecount    number;
    ln_fileindex    number;
    ls_filename        varchar2(20);
    ls_outstr        varchar2(2000);
    ls_path            varchar2(2000);
    ln_MSG_ID         varchar2(2000);
    ls_MSG_TYPE     varchar2(2000);
    ls_satir varchar2(2100);
    ls_par0  varchar2(200);  --sevalb 05102011
    ls_par1 varchar2(200);
    ls_par2 varchar2(2000);
    ls_par3 varchar2(2000);
    ls_par4 varchar2(2000);
    ls_par5 varchar2(2000);
    ls_par6 varchar2(2000);
    ls_par7 varchar2(2000);
    ls_par8 varchar2(2000);
    ls_par9 varchar2(2000);
    ls_par10 varchar2(2000);
    ls_par11 varchar2(2000);
    ls_par12 varchar2(2000);
    ls_par13 varchar2(2000);
    ls_par14 varchar2(2000);
    ls_par15 varchar2(2000);
    ls_par16 varchar2(2000);
    ls_par17 varchar2(2000);
    ls_par18 varchar2(2000);
    ls_par19 varchar2(2000);
    ls_par20 varchar2(2000);
    ls_par21 varchar2(2000);
    ls_par22 varchar2(2000);
    ls_par23 varchar2(2000); --Yerzhan Tanatov, requested by NB  --01122009
    ls_ad  varchar2(2000);
    ln_sira_no              number := 0;
    dosya_hata  exception;
    v_ls_par4 varchar2(2000);
    v_ls_par4t varchar2(2000) := '0';
    v_ls_par4d varchar2(2000) := '0';
    n_ls_par4 NUMBER;
    ln_internal_no     number;
    ls_param_str varchar2(2000);
    ls_hata_mesaj  varchar2(2000); 
    ls_err      varchar2(20);
    ls_ucpointer                     VARCHAR2(3) := pkg_hata.getucpointer;
    ls_delimiter                     VARCHAR2(3) := pkg_hata.getdelimiter;
    ln_message_adet number := 0;
    ls_last_status varchar2(200);
    dosya_onceden_yuklendi exception ;
    dosya_bulunamadi                 EXCEPTION;    
    dosya_kopyalama_hatasi           EXCEPTION;
    dosya_silme_hatasi               EXCEPTION;    
BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    --Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6050'||Pkg_Hata.GetUCPOINTER);
    ln_internal_no :=pkg_genel.genel_kod_al('DIRECT_DEBIT_REJ');
    ls_path := INPUT_PATH;
    ls_filename:='UCdocsmt104rejt.in';

    Begin
        f:=utl_file.fopen(ls_path, ls_filename, 'r',2100);
        Exception when others then
         raise dosya_bulunamadi ; 
    End;

    ls_MSG_TYPE:='INCOMING';

    Begin
        LOOP
            utl_file.get_line(f, ls_outstr);

            IF ls_outstr IS NULL
            THEN

                RAISE NO_DATA_FOUND;
            END IF;

            ls_satir := ls_outstr ; --sevalb 05102011  ';;'|| ls_outstr ;

            ls_par0 := SplitStr(ls_satir,0); --sevalb 05102011 message reference they said added 
            ls_par1 := SplitStr(ls_satir,1); --Priority document


            ls_par2 := SplitStr(ls_satir,2); --Date of clearing session "YYYYMMDD" (example: 20020719)

            ls_par3 := SplitStr(ls_satir,3); --Number of clearing session
            ls_par4 := SplitStr(ls_satir,4); --Amount of document

            v_ls_par4 := REPLACE(REPLACE(ls_par4,',','#'),'.','#');

            v_ls_par4t := '0';
            v_ls_par4d := '0';


            IF instr(v_ls_par4,'#') >0 THEN
                v_ls_par4t := substr(v_ls_par4,1,instr(v_ls_par4,'#')-1);
                v_ls_par4d := substr(v_ls_par4,instr(v_ls_par4,'#')+1);
            ELSE
                v_ls_par4t := v_ls_par4;
            END IF;

            n_ls_par4 := to_number(v_ls_par4t) + to_number(v_ls_par4d)/100;


            ls_par5 := SplitStr(ls_satir,5); --Account of  sender
            ls_par6 := SplitStr(ls_satir,6); --INN sender
            ls_par7 := SplitStr(ls_satir,7); --Code of OKPO sender
            ls_par8 := SplitStr(ls_satir,8); -- Registration number CFKR


            --5 fields description of sender
            ls_par9 := SplitStr(ls_satir,9)   || ' ' ||
            SplitStr(ls_satir,10)  || ' ' ||
            SplitStr(ls_satir,11)  || ' ' ||
            SplitStr(ls_satir,12)  || ' ' ||
            SplitStr(ls_satir,13);
            ls_par10 := SplitStr(ls_satir,14); --Code bic bank sender


            --5 fields description of bank sender
            ls_par11 := SplitStr(ls_satir,15)  || ' ' ||
                        SplitStr(ls_satir,16)  || ' ' ||
            SplitStr(ls_satir,17)  || ' ' ||
            SplitStr(ls_satir,18)  || ' ' ||
            SplitStr(ls_satir,19);
            ls_par12 := SplitStr(ls_satir,20); --Code bic bank receiver
            --5 fields description of bank receiver
            ls_par13 := SplitStr(ls_satir,21)  || ' ' ||
            SplitStr(ls_satir,22)  || ' ' ||
            SplitStr(ls_satir,23)  || ' ' ||
            SplitStr(ls_satir,24)  || ' ' ||
            SplitStr(ls_satir,25);

            ls_par14 := SplitStr(ls_satir,26); --Account of receiver
            ls_par15 := SplitStr(ls_satir,27); --Sub-Account of receiver

            --Description of receiver
            ls_par16 := SplitStr(ls_satir,28) || ' ' ||
            SplitStr(ls_satir,29)  || ' ' ||
            SplitStr(ls_satir,30)  || ' ' ||
            SplitStr(ls_satir,31)  || ' ' ||
            SplitStr(ls_satir,32);

            --10 fields of payment assignment
            ls_par17 := substr(SplitStr(ls_satir,33)  || ' ' ||
            SplitStr(ls_satir,34)  || ' ' ||
            SplitStr(ls_satir,35)  || ' ' ||
            SplitStr(ls_satir,36)  || ' ' ||
            SplitStr(ls_satir,37)  || ' ' ||
            SplitStr(ls_satir,38)  || ' ' ||
            SplitStr(ls_satir,39)  || ' ' ||
            SplitStr(ls_satir,40)  || ' ' ||
            SplitStr(ls_satir,41)  || ' ' ||
            SplitStr(ls_satir,42),1,200);

            ls_par18 := SplitStr(ls_satir,43); --Number of document
            ls_par19 := SplitStr(ls_satir,44);--Type of message
            ls_par20 := SplitStr(ls_satir,45);--Code payment
            ls_par21 := SplitStr(ls_satir,46);--Date of document "YYYYMMDD" (example: 20020719)
            ls_par23 := SplitStr(ls_satir,47);--Message reference, unique NB message ID
            ln_sira_no := ln_sira_no + 1 ;

            INSERT INTO CBS_DIRECT_DEBIT_DATA_REJ (
                  internal_no,
                  sira_no,
                  PRIORITY,
                  MATURITY_DATE,
                  REFERENCE,
                  AMOUNT,
                  FROM_ACCOUNT_EXTERNAL_NUMBER,
                  FROM_RNN,
                  FROM_OKPO,
                  FROM_SOCIAL_FUND_NUMBER,
                  FROM_DESCRIPTION,
                  FROM_BANKBICCODE,
                  FROM_BANKNAME,
                  TO_BANKBICCODE,
                  TO_BANKNAME,
                  TO_ACCOUNT_EXTERNAL_NUMBER,
                  TO_SUBACCOUNT,
                  TO_NAME,
                  PURPOSE,
                  DOCUMENT_NO,
                  MSG_TYPE,
                  PAYMENT_TYPE,
                  DOCUMENT_DATE,
                  FILE_NAME,
                  BANK_DATE,
                  MESSAGE_REFERENCE_47,--SEVALB 05102011 changed
                  MESSAGE_REFERENCE) --SEVALB 05102011 changed 

            VALUES (
                ln_internal_no,
                ln_sira_no,
                ls_par1,
                TO_DATE(ls_par2,'YYYYMMDD'),
                ls_par3,
                n_ls_par4,--AMOUNT
                ls_par5,
                ls_par6,
                ls_par7,
                ls_par8,
                ls_par9,
                ls_par10,
                ls_par11,
                ls_par12,
                ls_par13,
                ls_par14,
                ls_par15,
                ls_par16,
                ls_par17,
                ls_par18,
                ls_par19,
                ls_par20,
                ls_par21,
                ls_filename,
                pkg_muhasebe.Banka_Tarihi_Bul,
                ls_par23,
                ls_par0 --sevalb 05102011
                );
            
        if trim(ls_par0) is not null then            
            select count(*)
            into ln_message_adet      
            from  cbs_direct_debit_uc_data
            where  message_reference =ls_par0
                   and  nvl(our_customer,'N') = 'N' ;
            
           if nvl(ln_message_adet,0) = 0 then
              --logla bizde bu message reference kaydi yok                
             Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,pkg_hata.generatemessage(ls_ucpointer
                                                  || 6173
                                                  || ls_delimiter
                                                  || ls_par0
                                                  || ls_delimiter
                                                  || TO_CHAR(ln_internal_no) ||'/'||ln_sira_no 
                                                  || ls_delimiter
                                                  || ls_ucpointer)); 
           else
                -- durumu DONE ise  reject geldiyse hatali bir durum var .Reject explanationa not dusulecek.
                begin
                 select status
                 into ls_last_status      
                 from  cbs_direct_debit_data_other_bn
                 where  message_reference =ls_par0;
                exception when others then 
                     null;
                end; 
           end if;
            
            if nvl(ls_last_status,'NEW') = 'NEW' then 
                update cbs_direct_debit_uc_data
                set   durum_kodu = 'R',
                      kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                      kapanis_system_tarihi =sysdate,  
                      rejected = 'E',
                      reject_explanation ='Origin:Reject File, Explanation:' || ltrim(rtrim(ls_par17)) ||', Status was '||ls_last_status,
                      reject_date_time = sysdate,
                      reject_bank_date = pkg_muhasebe.banka_tarihi_bul                        
                where message_reference =ls_par0 and
                       date_val = ls_par2
                      and t50 = ls_par5
                      and t57 = ls_par12
                      and t59 = ls_par14
                      and t77b_dnum =ls_par18; 
                      --and  nvl(our_customer,'N') = 'N'; 
                      --and al_file_written = 'E';
                    
                    --b-o-m sevalb 20012012
                    begin
                      update cbs_direct_debit_data_other_bn
                      set  status = 'REJECTED',
                           rejected = 'E',
                           reject_explanation ='Origin:Reject File, Explanation:' || ltrim(rtrim(ls_par17)) ||', Status was '||ls_last_status,
                           reject_date_time = sysdate,
                           reject_bank_date = pkg_muhasebe.banka_tarihi_bul 
                      where message_reference = ls_par0 ;
                    exception when others then
                        log_At('MessageLoad_Rejects-error',ls_par0,sqlcode,sqlerrm);
                    end ;
             elsif nvl(ls_last_status,'NEW') = 'DONE' then 
           
                update cbs_direct_debit_uc_data
                set   durum_kodu = 'R',
                      kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                      kapanis_system_tarihi =sysdate,  
                      rejected = 'E',
                      reject_explanation ='EXCEPTIONAL CASE!.PLS CHECK IT AND ENTER MANUAL REVERSE JOURNAL IF NEEDED. ' || 'Origin:Reject File, Explanation:' || ltrim(rtrim(ls_par17)) ||', Status was '||ls_last_status,
                      reject_date_time = sysdate,
                      reject_bank_date = pkg_muhasebe.banka_tarihi_bul                        
                where message_reference =ls_par0 and
                       date_val = ls_par2
                      and t50 = ls_par5
                      and t57 = ls_par12
                      and t59 = ls_par14
                      and t77b_dnum =ls_par18; 
                      --and  nvl(our_customer,'N') = 'N'; 
                      --and al_file_written = 'E';
                    
                    --b-o-m sevalb 20012012
                    begin
                      update cbs_direct_debit_data_other_bn
                      set  status = 'REJECTED AFTER DONE',
                           rejected = 'E',
                           reject_explanation ='EXCEPTIONAL CASE!.PLS CHECK IT AND ENTER MANUAL REVERSE JOURNAL IF NEEDED. ' || 'Origin:Reject File, Explanation:' || ltrim(rtrim(ls_par17)) ||', Status was '||ls_last_status,
                           reject_date_time = sysdate,
                           reject_bank_date = pkg_muhasebe.banka_tarihi_bul 
                      where message_reference = ls_par0 ;
                    exception when others then
                        log_At('MessageLoad_Rejects-error after done',ls_par0,sqlcode,sqlerrm);
                    end ;
                
             end if;
         else
                Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,pkg_hata.generatemessage(ls_ucpointer
                                                  || 6174
                                                  || ls_delimiter
                                                  || ls_par0
                                                  || ls_delimiter
                                                  || TO_CHAR(ln_internal_no) ||'/'||ln_sira_no 
                                                  || ls_delimiter
                                                  || ls_ucpointer));
        end if;

        END LOOP;

        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            pkg_dosya.dosya_kapa('r');

    End;

    COMMIT;

-- File copy to acrhive and remove operation
    begin

        pkg_dosya.kopyala( ls_path,ls_filename,ls_path||'\archive',ls_filename ||to_char(sysdate,'DDMMYYYHH24MI') );
    exception
            when others then
                raise dosya_kopyalama_hatasi;
     end;

    begin
        pkg_dosya.dosya_sil (ls_path, ls_filename );
     exception
            when others then
                raise dosya_silme_hatasi;  
     end;

     
    
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
     WHEN dosya_bulunamadi
        THEN
         ROLLBACK;
         log_at('messageload_rejects-error-dosya_bulunamadi',ls_path|| '\'|| ls_filename,sqlcode,sqlerrm);              
         utl_file.fclose_all;
         ls_err := '6150';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_filename
                                                  || ls_delimiter
                                                  || ls_path 
                                                  || ls_delimiter
                                                  || ls_ucpointer);           
          Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
          Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN dosya_kopyalama_hatasi
         THEN
         ROLLBACK;
         utl_file.fclose_all;
         ls_err := '841';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_filename || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                  || ls_delimiter
                                                  || ls_ucpointer);
              Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
              Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN dosya_silme_hatasi
          THEN
             ROLLBACK;              
             utl_file.fclose_all;
             ls_err := '842';
             ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                      || ls_err
                                                      || ls_delimiter
                                                      || ls_filename || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                      || ls_delimiter
                                                      || ls_ucpointer);
               Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
               Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
        WHEN OTHERS THEN
        ROLLBACK;              
                 utl_file.fclose_all;
                 ls_err := '6165';
                ls_param_str := substr( ls_par1||','||ls_par2||','||ls_par3||','||
                            ls_par4||','||ls_par5||','||ls_par6||','||ls_par7||','||ls_par8||','||ls_par9||','||
                            ls_par10||','||ls_par11||','||ls_par12||','||ls_par13||','||ls_par14||','||ls_par15||','||
                            ls_par16||','||ls_par17||','||ls_par18||','||ls_par19||','||ls_par20||','||ls_par21||','||
                            ls_par22  ,1,1700);  
                 ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                          || ls_err
                                                          || ls_delimiter
                                                          --||'File Name:'|| ls_filename || ',Error:' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 180) ||', Param Str:'|| substr(ls_param_str,1,1600)
                                                          || ls_delimiter
                                                          || ls_ucpointer);
                   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
                   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

END;
--------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
--sevalb 9909_direct_debit_2nphase  04012012
FUNCTION  sf_direct_debit_durum_kodu_al(ps_durum_kodu varchar2 ) RETURN  varchar2 
 IS
  ls_adi varchar2(500);
 BEGIN
        SELECT aciklama
        INTO ls_adi
        FROM cbs_direct_debit_durum_kodlari
        WHERE durum_kodu = ps_durum_kodu;

    RETURN     ls_adi ;

 EXCEPTION WHEN OTHERS THEN RETURN NULL;
 END;
--------------------------------------------------------------------------------------------------------------
--sevalb  1912012  9909_direct_debit_2nphase_UAT__18122 Aplication CBS modification for DDS implementation with Kyrgyztelecom
procedure sp_error_log(   ps_file_id_no              number,
                          ps_file_type               varchar2,
                          ps_file_name               varchar2,
                          pn_error_code              number,
                          ps_error_text              varchar2,
                          ps_message_text            varchar2
)
is pragma autonomous_transaction;
Begin

      insert into  CBS_DDS_XML_ERROR(
                        ERR_INT_NO    ,
                        FILE_ID_NO    ,
                        FILE_TYPE    ,
                        FILE_NAME    ,
                        ERROR_CODE    ,
                        ERROR_TEXT    ,
                        MESSAGE_TEXT ,
                        bank_date   )
       values    (      pkg_genel.genel_kod_al('DDS_ERROR'),
                        ps_FILE_ID_NO    ,
                        ps_FILE_TYPE    ,
                        ps_FILE_NAME    ,
                        pn_ERROR_CODE    ,
                        ps_ERROR_TEXT    ,
                        ps_MESSAGE_TEXT ,
                        PKG_MUHASEBE.BANKA_TARIHI_BUL );
      commit;

End;

PROCEDURE MessageLoad_xml(pn_file_no in out number,ps_input_file_name varchar2  default 'dds_xml.xml',
                         pn_grup_no number default 0,
                         pn_log_no number  default 0,
                         ps_program_kod  varchar2 default 'PKG_DIRECT_DEBIT.MESSAGELOAD_XML'                         
                          )
is
    ls_file_type      utl_file.file_type;
    ls_text_message   varchar2 (32767 char);
    ls_message     clob;
    ln_id_no       number;
    ls_hata_mesaj       varchar2(2000);
    ls_path            varchar2(2000);
    ls_input_filename_xml varchar2(2000) := upper(ps_input_file_name);
    ln_msg_id         varchar2(2000);
    ls_msg_type     varchar2(2000);
    ls_satir varchar2(2100);
    ls_err                           varchar2(2000);    
    ls_ucpointer                     varchar2(3) := pkg_hata.getucpointer;
    ls_delimiter                     varchar2(3) := pkg_hata.getdelimiter;
    ls_type_of_file varchar2(20) := 'DDS';
    ln_adet number := 0;
    ls_our_customer            varchar2(1);
    ln_account  number;
    ln_kt_ext_Accnt_no  number;
    ln_sira_no  number := 0;
    ls_hata_aciklamasi  varchar2(2000);
    ln_banka_bic_kod    number;
    ld_date_Val date;
    ld_last_bank_date     date  :=pkg_tarih.ayin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) ;
    ld_bank_date    date :=pkg_muhasebe.banka_tarihi_bul;
    ln_ext_hesap_adet   number := 0;
    ls_hesap_durum_kodu varchar2(1);
    ln_min_loaded_internal_no   number := 0;
    ln_min_loaded_sira_no       number := 0;
    ls_min_loaded_filename varchar2(2000);

cursor cur_file is 
  select *
     from  cbs_dds_xml
     where file_name =  ls_input_filename_xml;
    r_file cur_file%rowtype;

cursor cur_detay is 
  select *
     from  cbs_dds_xml_parse
     where id_no =  ln_id_no;
    r_detay cur_detay%rowtype;

    dosya_onceden_yuklendi           EXCEPTION ;
    dosya_bulunamadi                 EXCEPTION;    
    dosya_kopyalama_hatasi           EXCEPTION;
    dosya_silme_hatasi               EXCEPTION; 
    dosya_formati_uygun_degil        EXCEPTION ;
    customer_bic_code_hatali         EXCEPTION ;
    firm_bic_code_hatali             EXCEPTION ;
    firm_bic_code_banka_bic_degil    EXCEPTION ;
    customer_ext_account_hatali      EXCEPTION ;
    firm_ext_acct_kt_accnt_degil     EXCEPTION ;
    date_Val_zorunlu_alan            EXCEPTION ;
    date_val_format_hatali           EXCEPTION ;
    banka_tarihinden_kucuk_olamaz    EXCEPTION ;
    date_Val_isgunu_degil            EXCEPTION ;   
    date_Val_son_gunden_buyuk        EXCEPTION ;
    hesap_doviz_hatali               EXCEPTION ;
    musteri_hesap_aktif_degil        EXCEPTION ;
    ayni_musteri_onceden_yuklendi    EXCEPTION ;
BEGIN
--1. check file is loaded before 
    if nvl(pn_file_no,0) <> 0  then 
        ln_id_no := pn_file_no;
    else
        ln_id_no := pkg_genel.genel_kod_al ('DIRECT_DEBIT');
        pn_file_no  :=ln_id_no;
    end if;

    ln_adet := 0;
    ls_path := INPUT_PATH_DDS_XML;
     select count(*)
     into ln_adet 
     from  cbs_dds_xml
     where file_name =  ls_input_filename_xml;
 
    if nvl(ln_adet,0) <> 0 then 
    open  cur_file ;
    fetch cur_file into r_file;
    close cur_file;
     
       raise dosya_onceden_yuklendi;
    end if;
  
--2. open file 
begin
   ls_file_type :=
   utl_file.fopen (ls_path,
                      ls_input_filename_xml,
                      'R',
                      32767);
exception when others then  raise dosya_bulunamadi ;--log_at('1.1111', sqlcode,sqlerrm);
    end;

   if utl_file.is_open (ls_file_type)
   then
      loop
         begin
            utl_file.get_line (ls_file_type, ls_text_message, 32767);

            if ls_message is null
            then
               ls_message := ls_text_message;
            elsif ls_message is not null
            then
               ls_message := ls_message || chr (10) || ls_text_message;
            end if;
         exception
            when no_data_found
            then
               exit;
         end;
      end loop;
   end if;

   dbms_output.put_line (ls_message);
--3. insert into dds xml tables
   insert into CBS_dds_xml (id_no, file_name, xml_file,bank_date)
     values   (ln_id_no, ls_input_filename_xml, ls_message,ld_bank_date);

   insert into cbs_dds_xml_parse (id_no,
                              file_name,
                              bank_date,
                              number_column,
                              service_id_column,
                              param1_column,
                              date_val_column,
                              t52a_column,
                              t52a_name_column,
                              t26t_column,
                              t50_column,
                              t50_shet_column,
                              t50_sub_column,
                              t50_name_column,
                              t57_column,
                              t57_name_column,
                              t59_column,
                              t59_inn_column,
                              t59_okpo_column,
                              t59_sfond_column,
                              t59_sub_column,
                              t59_ls_column,
                              t59_name_column,
                              t70_column,
                              t70_1_column,
                              t77b_dnum_column,
                              t77b_ddate_column)
      select   ln_id_no,
               ls_input_filename_xml,
               ld_bank_date,
               extract (value (subject), '//number/text()').getstringval () number_column,
               extract (value (subject), '//SERVICE_ID/text()').getstringval () service_id_column,
               extract (value (subject), '//PARAM1/text()').getstringval () param1_column,
               extract (value (subject), '//DATE_VAL/text()').getstringval () date_val_column,
               extract (value (subject), '//T52A/text()').getstringval () t52a_column,
               extract (value (subject), '//T52A_NAME/text()').getstringval () t52a_name_column,
               extract (value (subject), '//T26T/text()').getstringval () t26t_column,
               extract (value (subject), '//T50/text()').getstringval () t50_column,
               extract (value (subject), '//T50_SHET/text()').getstringval () t50_shet_column,
               extract (value (subject), '//T50_SUB/text()').getstringval () t50_sub_column,
               extract (value (subject), '//T50_NAME/text()').getstringval () t50_name_column,
               extract (value (subject), '//T57/text()').getstringval () t57_column,
               extract (value (subject), '//T57_NAME/text()').getstringval () t57_name_column,
               extract (value (subject), '//T59/text()').getstringval () t59_column,
               extract (value (subject), '//T59_INN/text()').getstringval () t59_inn_column,
               extract (value (subject), '//T59_OKPO/text()').getstringval () t59_okpo_column,
               extract (value (subject), '//T59_SFOND/text()').getstringval () t59_sfond_column,
               extract (value (subject), '//T59_SUB/text()').getstringval () t59_sub_column,
               extract (value (subject), '//T59_LS/text()').getstringval () t59_ls_column,
               extract (value (subject), '//T59_NAME/text()').getstringval () t59_name_column,
               extract (value (subject), '//T70/text()').getstringval () t70_column,
               extract (value (subject), '//T70_1/text()').getstringval () t70_1_column,
               extract (value (subject), '//T77B_DNUM/text()').getstringval () t77b_dnum_column,
               extract (value (subject), '//T77B_DDATE/text()').getstringval () t77b_ddate_column
        from   table (xmlsequence (xmltype (ls_message).extract ('/*/*'))) subject;

     commit;

    utl_file.fclose(ls_file_type);
    utl_file.fclose_all;

--4. file format checking controls 
ln_sira_no := 0;
ln_banka_bic_kod := pkg_tx7070.banka_bic_kodu_getir;
ln_kt_ext_Accnt_no := pkg_tx7070.kt_external_acount_no_al;

 for c_detay in cur_detay loop
        r_Detay := c_Detay;
        ln_ext_hesap_adet := 0;
        ln_account := null;
        ln_sira_no := ln_sira_no + 1 ;
        begin

            select count(*)
            into ln_ext_hesap_adet
            from cbs_hesap
            where external_hesap_no=r_detay.t59_column;  
            
            if nvl(ln_ext_hesap_adet,0) <>0 then 
                 begin
                     ln_account := pkg_hesap.gethesapnofromexternal(r_detay.t59_column,pkg_genel.lc_al);      
                 exception
                 when others then
                     ln_account := NULL;               
                 end;
            end if;

            if ln_account is  null and nvl(ln_ext_hesap_adet,0) <>0 then 
                raise hesap_doviz_hatali;
            end if;
        
            
            if ln_account is not null
            then
                ls_our_customer := 'Y'; 

                select durum_kodu
                into ls_hesap_durum_kodu
                from cbs_hesap
                where hesap_no = ln_account;
                if ls_hesap_durum_kodu <>'A' then 
                    raise   musteri_hesap_aktif_degil;
                end if;

            else
                ls_our_customer := 'N'; 
            end if;


        --sevalb 12032012
                select min(internal_no), min(sira_no) ,min(file_name) 
                into   ln_min_loaded_internal_no, ln_min_loaded_sira_no,ls_min_loaded_filename
                from   cbs_direct_debit_uc_prep_data
                where  date_val= decode(trim(r_detay.date_val_column),null,null,decode(length(r_detay.date_val_column),8, substr(r_detay.date_val_column,3),r_detay.date_val_column) ) and
                       t59_ls =trim(r_detay.t59_ls_column) and
                       trim(nvl(service_id_column,'9')) =  trim(nvl(r_detay.service_id_column,'9')); 

                  if nvl(ln_min_loaded_internal_no,0) <>0 then
                      raise ayni_musteri_onceden_yuklendi; 
                end if;
        --sevalb 12032012

    
          insert into cbs_direct_debit_uc_prep_data ( internal_no,        
                                                    sira_no,        
                                                    file_id_no,
                                                    file_name,
                                                    bank_date,
                                                    number_column,
                                                    service_id_column,
                                                    param1_column,
                                                    date_val,
                                                    t52a,
                                                    t52a_name,
                                                    t26t,
                                                    t50 ,
                                                    t50_sChet    ,
                                                    t50_sub  ,
                                                    t50_name    ,
                                                    t57  ,
                                                    t57_name,
                                                    t59,
                                                    t59_inn,
                                                    t59_okpo,
                                                    t59_sfond,
                                                    t59_sub ,
                                                    t59_ls,
                                                    t59_name,
                                                    t70,
                                                    t70_1,
                                                    t77b_dnum,
                                                    t77b_ddate,
                                                    our_customer,
                                                    account_no ,
                                                    message_reference )
        values  
                                    (r_detay.id_no,
                                    ln_sira_no    ,
                                    r_detay.id_no,
                                    r_detay.file_name    ,
                                    r_detay.bank_date    ,
                                    decode(trim(r_detay.number_column),null,null,to_number(r_detay.number_column ) )  ,
                                    decode(trim(r_detay.service_id_column),null,null,to_number(r_detay.service_id_column))   ,
                                    r_detay.param1_column    ,
                                    decode(trim(r_detay.date_val_column),null,null,decode(length(r_detay.date_val_column),8, substr(r_detay.date_val_column,3),r_detay.date_val_column) ),  --date_val_column ,
                                    decode(trim(r_detay.t52a_column),null,null,to_number(r_detay.t52a_column )),
                                     trim(r_detay.t52a_name_column) ,
                                    decode(trim(r_detay.t26t_column),null,null, to_number(r_detay.t26t_column )) ,
                                    trim(r_detay.t50_column)    ,
                                    trim(r_detay.t50_shet_column) ,
                                    decode(trim(r_detay.t50_sub_column),null,null, to_number(r_detay.t50_sub_column)),
                                    trim(r_detay.t50_name_column)    ,
                                    decode(trim(r_detay.t57_column ) ,null,null,to_number(r_detay.t57_column ))  ,
                                    trim(r_detay.t57_name_column)    ,
                                    trim(r_detay.t59_column)    ,
                                    trim(r_detay.t59_inn_column)    ,
                                    trim(r_detay.t59_okpo_column)    ,
                                    trim(r_detay.t59_sfond_column)    ,
                                    decode(trim(r_detay.t59_sub_column),null,null, to_number(r_detay.t59_sub_column)),
                                    trim(r_detay.t59_ls_column)   ,
                                    trim(r_detay.t59_name_column)    ,
                                    trim(r_detay.t70_column)    ,
                                    trim(r_detay.t70_1_column)    ,
                                    trim(r_detay.t77b_dnum_column)    ,
                                    decode(trim(r_detay.t77b_ddate_column),null,null, decode(length(r_detay.t77b_ddate_column),8, substr(r_detay.t77b_ddate_column,3),r_detay.t77b_ddate_column)),   -- t77b_ddate_column,
                                    ls_our_customer,
                                    ln_account,
                                    pkg_genel.genel_kod_al('DIRECT_DEBIT_MSG_REF')    
                                    );
        if ( pkg_genel.banka_adi_al_eft_hatasiz( to_number(r_detay.T52A_COLUMN )) ='Bank not found.' and to_number(r_detay.T52A_COLUMN ) <> ln_banka_bic_kod ) or  (trim(r_detay.T52A_COLUMN) is null ) then
            raise customer_bic_code_hatali;
        end if;
        if trim(r_detay.T52A_COLUMN) is not  null and ln_banka_bic_kod <>to_number(r_detay.T52A_COLUMN ) then
            raise firm_bic_code_banka_bic_degil;
        end if;

       if ( pkg_genel.banka_adi_al_eft_hatasiz( to_number(r_detay.T57_COLUMN )) ='Bank not found.' and to_number(r_detay.T57_COLUMN ) <> ln_banka_bic_kod ) or  (trim(r_detay.T57_COLUMN) is null ) then
            raise firm_bic_code_hatali;
        end if;

        if pkg_tx3555.External_hesap_dogrumu(r_detay.T59_COLUMN) ='H' then
            raise customer_ext_account_hatali;
        end if;
    
        if pkg_tx7070.kt_external_acount_no_al <> r_detay.T50_COLUMN  and r_detay.T50_COLUMN is not null then
            raise firm_ext_acct_kt_accnt_degil;
        end if;

        
        if r_detay.date_val_column is null then
            raise date_val_zorunlu_alan;
        end if;
        begin
            ld_date_val := to_date(r_detay.date_val_column,'YYYYMMDD');            
        exception when others then 
                raise date_val_format_hatali;
        end;
        
        if to_date( r_detay.date_val_column,'YYYYMMDD') < ld_bank_date then
            raise banka_tarihinden_kucuk_olamaz;
        end if;
         
        if pkg_tarih.gun_ozellik(to_date( r_detay.date_val_column,'YYYYMMDD')) <> 0 then
              raise date_val_isgunu_degil; 
        end if;
    
        if to_date( r_detay.date_val_column,'YYYYMMDD') > ld_last_bank_date then
              raise date_val_son_gunden_buyuk; 
        end if;
        Exception 
                when customer_bic_code_hatali then 
                     raise customer_bic_code_hatali;
                when firm_bic_code_hatali  then
                     raise firm_bic_code_hatali;
                when firm_bic_code_banka_bic_degil then
                     raise firm_bic_code_banka_bic_degil;   
                when customer_ext_account_hatali then
                     raise customer_ext_account_hatali;   
                when firm_ext_acct_kt_accnt_degil then
                     raise firm_ext_acct_kt_accnt_degil;
                when date_val_zorunlu_alan then
                     raise date_val_zorunlu_alan;
                when date_val_format_hatali then
                     raise date_val_format_hatali;
                when banka_tarihinden_kucuk_olamaz then
                     raise banka_tarihinden_kucuk_olamaz; 
                when date_val_isgunu_degil then
                     raise date_val_isgunu_degil; 
                when date_val_son_gunden_buyuk then
                     raise date_val_son_gunden_buyuk;
                when hesap_doviz_hatali then
                     raise hesap_doviz_hatali;
                when musteri_hesap_aktif_degil then
                     raise musteri_hesap_aktif_degil;
                when ayni_musteri_onceden_yuklendi then
                     raise ayni_musteri_onceden_yuklendi;
                when others then
                  ls_hata_aciklamasi :=  TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200);
                  raise dosya_formati_uygun_degil;
        end ;

 end loop;

commit;

--5. Copy file _ remove file
      BEGIN
          pkg_dosya.kopyala( INPUT_PATH_DDS_XML,ls_input_filename_xml,INPUT_PATH_DDS_XML_ARCH,ls_input_filename_xml||to_char(sysdate,'DDMMYYYHH24MI') );
      EXCEPTION
         WHEN OTHERS
         THEN
            RAISE dosya_kopyalama_hatasi;
      END;

      BEGIN
         pkg_dosya.dosya_sil (ls_path, ls_input_filename_xml);
      EXCEPTION
         WHEN OTHERS
         THEN
            RAISE dosya_silme_hatasi;
      END;


    EXCEPTION
     WHEN dosya_bulunamadi
        THEN
         ROLLBACK;
         log_at('messageload_xml-error-dosya_bulunamadi',ls_input_filename_xml,sqlcode,sqlerrm);
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6150';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename_xml
                                                  || ls_delimiter
                                                  || INPUT_PATH_DDS_XML 
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );

    WHEN dosya_onceden_yuklendi
      THEN
         ROLLBACK;
         log_at('messageload_xml-error-dosya_onceden_yuklendi',ls_input_filename_xml,sqlcode,sqlerrm);
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '1564';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename_xml
                                                  || ls_delimiter
                                                  || r_file.id_no  
                                                  || ls_delimiter
                                                  || to_char( r_file.bank_date,'DD/MM/YYYY')
                                                  || ls_delimiter
                                                  || to_char( r_file.SYSTEM_DATE,'DD/MM/YYYY HH24:MI:SS')
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
        WHEN dosya_kopyalama_hatasi
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '841';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename_xml || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
    WHEN dosya_silme_hatasi
      THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '842';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename_xml || ' ' || TO_CHAR (SQLCODE)|| ' ' || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );

       WHEN  dosya_formati_uygun_degil
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '991';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || 'File Name:'||ls_input_filename_xml || ',Row No:' ||ln_sira_no||',Error Cd:' ||ls_hata_aciklamasi
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
      WHEN  customer_bic_code_hatali
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6152';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err        
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter                                       
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
    WHEN  firm_bic_code_hatali
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6153';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
  
  WHEN  firm_bic_code_banka_bic_degil
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6154';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err      
                                                  || ls_delimiter
                                                  || ln_banka_bic_kod
                                                  || ls_delimiter      
                                                  || ln_sira_no
                                                  || ls_delimiter                                   
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
    WHEN  customer_ext_account_hatali
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6155';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err        
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter                                       
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );
    
   when  firm_ext_acct_kt_accnt_degil
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6157';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err      
                                                  || ls_delimiter
                                                  || ln_kt_ext_Accnt_no
                                                  || ls_delimiter      
                                                  || ln_sira_no
                                                  || ls_delimiter                                   
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );

    when date_val_zorunlu_alan 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6158';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
     when date_val_format_hatali 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6159';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
     when banka_tarihinden_kucuk_olamaz 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6160';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
    when date_Val_isgunu_degil 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6161';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
        when date_val_son_gunden_buyuk 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6162';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err      
                                                  || ls_delimiter
                                                  || to_char(ld_last_bank_date,'YYYYMMDD')
                                                  || ls_delimiter      
                                                  || ln_sira_no
                                                  || ls_delimiter                                   
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );

     when hesap_doviz_hatali 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6163';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );
     when musteri_hesap_aktif_degil 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6164';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err   
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter        
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );

     when ayni_musteri_onceden_yuklendi 
         THEN
         ROLLBACK;
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '6175';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err      
                                                  || ls_delimiter
                                                  || ln_sira_no
                                                  || ls_delimiter      
                                                  || ls_min_loaded_filename ||'/'|| to_char(ln_min_loaded_internal_no) ||'/'|| to_char(ln_min_loaded_sira_no)
                                                  || ls_delimiter                                   
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message );

                                                                                    
    WHEN OTHERS
      THEN
         ROLLBACK;
         log_at('messageload_xml-error-others',ls_input_filename_xml,sqlcode,sqlerrm);
         utl_file.fclose(ls_file_type);     
         utl_file.fclose_all;
         ls_err := '1700';
         ls_hata_mesaj := pkg_hata.generatemessage(ls_ucpointer
                                                  || ls_err
                                                  || ls_delimiter
                                                  || ls_input_filename_xml
                                                  || ' '
                                                  || TO_CHAR (SQLCODE)
                                                  || ' '
                                                  || SUBSTR (TO_CHAR (SQLERRM), 1, 200)
                                                  || ls_delimiter
                                                  || ls_ucpointer);
            pkg_direct_Debit.sp_error_log(    ln_id_no ,
                                              ls_type_of_file  ,
                                              ls_input_filename_xml  ,
                                              ls_err   ,
                                              ls_hata_mesaj ,
                                              ls_text_message 
                                        );

  end;
------------------------------------------------------------------------------------------------------------------------------
-- DDSFL ekraninda webservice process butonu aktif edilmesi icin hata kaydi olup olmadigi kontrol edilir.
Function DDSFL_service_button_enable(pn_file_id number ) return varchar2
is
ln_err_adet     number := 0;
ln_sira_adet    number := 0;
Begin
    select count(*)
    into ln_err_adet  
    from cbs_dds_xml_error  
    where file_id_no =pn_file_id and
          error_code not  in (841,842);  

    if nvl(ln_err_Adet,0) <> 0 then 
        return 'H';
    else
       select count(*)
       into ln_sira_adet  
       from cbs_direct_debit_uc_prep_data  
       where internal_no =pn_file_id ;
        
        if nvl(ln_sira_adet,0) <> 0 then 
            return 'E';
        else
            return 'H';
        end if;     
       
    end if;

    Exception when others then return 'H';

End;
------------------------------------------------------------------------------------------------------------------------------
--seval maturity date hafta sonuna gelenlerde problem olacak bu sebeple banka tarihi ve sonraki isgunune kadar olanlari icerecek sekilde process ediyor olacagim.
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE UC_Accounting_NotOur_Customer(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'UC_ACCOUNTING_NOTOUR_CUSTOMER' )
is
    cursor c1 is    
        select *
        from cbs_direct_debit_uc_data
        where date_val >= to_number(to_char(pkg_muhasebe.banka_tarihi_bul,'yymmdd')) and date_val < to_number(to_char(pkg_muhasebe.sonraki_banka_tarihi_bul,'yymmdd')) --  sevalb haftasonu ve tatil girilenlerin de isleme girmesi ,icin sonraki banka tarihi 
          and durum_kodu = 'V' 
           and journal_no is null       
          and nvl(rejected,'H') = 'H' --sevalb   04102011  
          and  nvl(our_customer,'N') = 'N'   --sevalb   04102011
          and nvl(ucdocsmt104_out_file_written,'H') = 'E'  
        for update of durum_kodu,kapanis_tarihi,kapanis_system_tarihi; 
        
    r1        c1%ROWTYPE;

    cursor c2 is    
        select *
        from cbs_direct_debit_uc_data
        where date_val < to_number(to_char(pkg_muhasebe.banka_tarihi_bul,'yymmdd'))  
          and durum_kodu = 'V' 
           and journal_no is null       
          and nvl(rejected,'H') = 'H'  
          and  nvl(our_customer,'N') = 'N'
        for update of durum_kodu,kapanis_tarihi,kapanis_system_tarihi; 

    r2        c2%ROWTYPE;

    varchar_list               Pkg_Muhasebe.varchar_array;
    number_list                Pkg_Muhasebe.number_array;
    date_list                  Pkg_Muhasebe.date_array;
    boolean_list               Pkg_Muhasebe.boolean_array;

    p_7062_MB_SUBE               number;
    p_7062_MB_HESAP               number;
    p_7062_FIRM_HESAP_SUBE                   number;
    p_7062_FIRM_HESAP_NO          number;
    P_7062_FIRM_HESAP_DOVIZ   number;
    p_7062_TUTAR                  number;
    p_7062_ACIKLAMA               number;

    ls_7062_NB_ACC       varchar2(20);
    ls_7062_NB_ACC_BR  varchar2(10);
    
    ln_account           number;
    ln_islem_no           number;
    ln_fis_numara       number;

begin

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    p_7062_MB_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_MB_SUBE');

    p_7062_MB_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_MB_HESAP');

    p_7062_FIRM_HESAP_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_SUBE');
    p_7062_FIRM_HESAP_NO :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_NO');
    p_7062_FIRM_HESAP_DOVIZ :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_DOVIZ');

    p_7062_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_ACIKLAMA');
    p_7062_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TUTAR');

    Pkg_Parametre.deger('3555_NB_ACC',ls_7062_NB_ACC);
    ls_7062_NB_ACC_BR := pkg_hesap.HesaptanSubeAl(ls_7062_NB_ACC);
    
    OPEN c1 ;
    LOOP
        FETCH c1 INTO r1;
        EXIT WHEN c1%NOTFOUND;
         
            ln_account :=pkg_hesap.GetHesapNoFromExternal(r1.T50,pkg_genel.LC_al);  
            
            varchar_list(p_7062_FIRM_HESAP_NO) := ln_account;
            varchar_list(p_7062_FIRM_HESAP_SUBE) :=  pkg_hesap.HesaptanSubeAl(ln_account);
            varchar_list(p_7062_FIRM_HESAP_DOVIZ) :=  pkg_hesap.HesaptanDovizKoduAl(ln_account);

            varchar_list(p_7062_MB_HESAP) := ls_7062_NB_ACC;
            varchar_list(p_7062_MB_SUBE) := ls_7062_NB_ACC_BR;

            varchar_list(p_7062_ACIKLAMA) := 'Accounting for UC Company Bic/Ext.Acct/Name :' || r1.t57||'/'|| r1.t57_name ||'/'||r1.t59; --sevalb 04102011 
            number_list(p_7062_TUTAR):= abs( nvl(to_number(r1.T32B),0)) ; --sevalb 17102012 ABS eklendi
 
            ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_FIRM_HESAP_SUBE));

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                9,
                                                ln_islem_no,
                                                varchar_list,
                                                number_list,
                                                date_list,
                                                boolean_list ,
                                                null,
                                                FALSE,
                                                0,
                                                'Direct Debit - Not Our Customer Payment');

            Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

            update cbs_direct_debit_uc_data
            set journal_no = ln_fis_numara,
                durum_kodu = 'K',
                kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                kapanis_system_tarihi = sysdate
            where internal_no = r1.internal_no and sira_no = r1.sira_no;

            update cbs_direct_debit_data_other_bn
            set journal_no = ln_fis_numara,
                 tx_no = ln_islem_no,
                 status = 'DONE'
            where internal_no = r1.internal_no and sira_no = r1.sira_no AND message_reference = r1.message_reference;

    END LOOP;
    CLOSE c1;

    --- REJECT 
OPEN C2 ;
    LOOP
        FETCH C2 INTO R2;
        EXIT WHEN C2%NOTFOUND;
         
    
        if R2.date_val < to_number(to_char(pkg_muhasebe.banka_tarihi_bul,'yymmdd'))   then  
        -- maturity eski ise Reject edelim.Fis kesilmeyecek
            update cbs_direct_debit_uc_data
            set durum_kodu = 'R',
                kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                kapanis_system_tarihi = sysdate,
                rejected = 'E',
                reject_date_time = sysdate,
                reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                reject_explanation =  'Maturity date is old'
            where internal_no = R2.internal_no and sira_no = R2.sira_no;

            update cbs_direct_debit_data_other_bn
            set status = 'REJECTED',
                rejected = 'E',
                reject_date_time = sysdate,
                reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                reject_explanation = 'Maturity date is old'
            where internal_no = R2.internal_no and sira_no = R2.sira_no and message_reference = R2.message_reference;
    
           Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6172' ||  Pkg_Hata.getdelimiter ||TO_CHAR(R2.internal_no) ||'/'|| TO_CHAR(R2.sira_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer)  );

    END IF;

   END LOOP;

  CLOSE C2;


    commit;

   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    Exception
    WHEN OTHERS THEN
        ROLLBACK;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);        
    End;
------------------------------------------------------------------------------------------------------------------------------
PROCEDURE UC_Accounting_Our_Customer(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'UC_ACCOUNTING_OUR_CUSTOMER' )
is
    cursor cur_hesap is    
        select *
        from cbs_direct_debit_uc_data
        where date_val < to_number(to_char(pkg_muhasebe.sonraki_banka_tarihi_bul,'yymmdd')) --  sevalb haftasonu ve tatil girilenlerin de isleme girmesi ,icin sonraki banka tarihi  
           and durum_kodu = 'V' 
           and journal_no is null       
          and nvl(rejected,'H') = 'H'   
          and  nvl(our_customer,'N') = 'Y' 
    order by internal_no ,sira_no ;
 begin

    pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    -- create accounting for each account
    for c_hesap in cur_hesap loop
         PKG_Direct_debit.uc_accounting_our_customer_hes(c_hesap.internal_no , c_hesap.sira_no  ,pn_grup_no , pn_log_no ,ps_program_kod );
    end loop;

    commit;   
    pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
   
  Exception
    when others then
        rollback;
    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 end;
------------------------------------------------------------------------------------------------------------------------------
-- autonomous olarak tasarlandi bir musteri icin  hata aldiginda diger hesaplar icin calismaya devam etmeli.
PROCEDURE UC_Accounting_Our_Customer_hes(pn_internal_no number, pn_sira_no number ,pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'UC_ACCOUNTING_OUR_CUSTOMER' )
IS
PRAGMA autonomous_transaction;
    cursor c1 is    
        select *
        from cbs_direct_debit_uc_data
        where internal_no = pn_internal_no and sira_no = pn_sira_no; 
        --for update of durum_kodu,kapanis_tarihi,kapanis_system_tarihi; 
        
    r1        c1%ROWTYPE;
    varchar_list               Pkg_Muhasebe.varchar_array;
    number_list                Pkg_Muhasebe.number_array;
    date_list                  Pkg_Muhasebe.date_array;
    boolean_list               Pkg_Muhasebe.boolean_array;
    
    p_7062_HESAP_DOVIZ          number;
    p_7062_SUBE               number;
    p_7062_HESAP               number;

    p_7062_FIRM_HESAP_SUBE                   number;
    p_7062_FIRM_HESAP_NO          number;
    P_7062_FIRM_HESAP_DOVIZ   number;

    p_7062_TUTAR                  number;
    p_7062_ACIKLAMA               number;

    ln_firm_account           number;
    ln_customer_account           number;
    ln_islem_no           number;
    ln_fis_numara       number;
    ls_hata_mesaj varchar2(2000);
begin

    p_7062_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_SUBE');
    p_7062_HESAP :=Pkg_Muhasebe.parametre_index_bul('7062_HESAP');
    p_7062_HESAP_DOVIZ :=Pkg_Muhasebe.parametre_index_bul('7062_HESAP_DOVIZ');
    p_7062_FIRM_HESAP_SUBE :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_SUBE');
    p_7062_FIRM_HESAP_NO :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_NO');
    p_7062_FIRM_HESAP_DOVIZ :=Pkg_Muhasebe.parametre_index_bul('7062_FIRM_HESAP_DOVIZ');

    p_7062_ACIKLAMA :=Pkg_Muhasebe.parametre_index_bul('7062_ACIKLAMA');
    p_7062_TUTAR :=Pkg_Muhasebe.parametre_index_bul('7062_TUTAR');
 
    OPEN c1 ;
        FETCH c1 INTO r1;
        if r1.date_val < to_number(to_char(pkg_muhasebe.banka_tarihi_bul,'yymmdd'))   then  
        -- maturity eski ise Reject edelim.Fis kesilmeyecek
            update cbs_direct_debit_uc_data
            set durum_kodu = 'R',
                kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                kapanis_system_tarihi = sysdate,
                rejected = 'E',
                reject_date_time = sysdate,
                reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                reject_explanation =  'Not available balance until maturity date'
            where internal_no = r1.internal_no and sira_no = r1.sira_no;

            update cbs_direct_debit_data
            set status = 'REJECTED',
                rejected = 'E',
                reject_date_time = sysdate,
                reject_bank_date = pkg_muhasebe.banka_tarihi_bul,
                reject_explanation = 'Not available balance until maturity date'
            where internal_no = r1.internal_no and sira_no = r1.sira_no and message_reference = r1.message_reference;
       Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6172' ||  Pkg_Hata.getdelimiter ||TO_CHAR(r1.internal_no) ||'/'|| TO_CHAR(r1.sira_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer)  );
        else
            ln_firm_account :=pkg_hesap.GetHesapNoFromExternal(r1.T50,pkg_genel.LC_al);  --firm account
            varchar_list(p_7062_FIRM_HESAP_NO) := ln_firm_account;
            varchar_list(p_7062_FIRM_HESAP_SUBE) :=  pkg_hesap.HesaptanSubeAl(ln_firm_account);
            varchar_list(p_7062_FIRM_HESAP_DOVIZ) :=  pkg_hesap.HesaptanDovizKoduAl(ln_firm_account);

            ln_customer_account :=pkg_hesap.GetHesapNoFromExternal(r1.T59,pkg_genel.LC_al);
            varchar_list(p_7062_HESAP) := ln_customer_account;
            varchar_list(p_7062_SUBE) :=pkg_hesap.HesaptanSubeAl(ln_customer_account)  ;
            varchar_list(p_7062_HESAP_DOVIZ) :=  pkg_hesap.HesaptanDovizKoduAl(ln_customer_account);
            
            varchar_list(p_7062_ACIKLAMA) := 'Accounting for UC Company Bic/Ext.Acct/Name :' || r1.t57||'/'|| r1.t57_name ||'/'||r1.t59; --sevalb 04102011 
            number_list(p_7062_TUTAR):=  ABS(nvl(to_number(r1.T32B),0)) ; --SEVALB 17102012 ABS eklendi.
 
            ln_islem_no:=Pkg_Batch.islem_yarat(7062, varchar_list(p_7062_FIRM_HESAP_SUBE));
        
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7062,
                                                10,
                                                ln_islem_no,
                                                varchar_list,
                                                number_list,
                                                date_list,
                                                boolean_list ,
                                                null,
                                                FALSE,
                                                0,
                                                'Direct Debit - Our Customer Payment');

            Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

            update cbs_direct_debit_uc_data
            set durum_kodu = 'K',
                kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                kapanis_system_tarihi = sysdate,
                journal_no = ln_fis_numara  --sevalb 01112012 dds problem SDLC00027906 
            where internal_no = r1.internal_no and sira_no = r1.sira_no;

            update cbs_direct_debit_data
            set journal_no = ln_fis_numara,
                 tx_no = ln_islem_no,
                 status = 'DONE'
            where message_reference = r1.message_reference;
      
       Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6167' || Pkg_Hata.getdelimiter || TO_CHAR(ln_customer_account) || Pkg_Hata.getdelimiter || TO_CHAR(ln_fis_numara) || Pkg_Hata.getdelimiter ||TO_CHAR(r1.internal_no) ||'/'|| TO_CHAR(r1.sira_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no );
    
    end if;

    CLOSE c1;

    COMMIT;

    Exception
    WHEN OTHERS THEN
        ROLLBACK;
           -- update reject status if it's old maturiyt date
        ls_hata_mesaj :=Pkg_Hata.generatemessage(SQLCODE||' '||SQLERRM) ;   --(Pkg_Hata.getucpointer || '6168' || Pkg_Hata.getdelimiter || TO_CHAR(ln_customer_account) || Pkg_Hata.getdelimiter || sqlcode ||' '||sqlerrm || Pkg_Hata.getdelimiter ||TO_CHAR(r1.internal_no) ||'/'|| TO_CHAR(r1.sira_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6168' || Pkg_Hata.getdelimiter || TO_CHAR(ln_customer_account) || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) ||' ' ||SUBSTR(SQLERRM,1,1800) || Pkg_Hata.getdelimiter ||TO_CHAR(r1.internal_no) ||'/'|| TO_CHAR(r1.sira_no)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no);
    End;
------------------------------------------------------------------------------------------------------------------------------
Function KT_statu_Code_Explanation(pn_statu_code Number) Return Varchar2
  is
    ls_explanation  varchar2(200);
  begin

    select explanation
    into   ls_explanation
    from   cbs_kt_webservice_statu_code
    where  statu_code = pn_statu_code;

    return  ls_explanation;

      exception
      when others then
        if nvl(pn_statu_code,0) >= 400 then  
            return  'ERROR';
        else
            return  NULL;
        end if;
   end ;
------------------------------------------------------------------------------------------------------------------------------
Function cbs_transaction_statu_Code_Exp(ps_statu_code varchar2) Return Varchar2
is
    ls_explanation  varchar2(200);
  begin

    select explanation
    into   ls_explanation
    from   cbs_dds_transaction_statu_code
    where  statu_code = ps_statu_code;

    return  ls_explanation;

      exception
      when others then
        return null;
   end ;
------------------------------------------------------------------------------------------------------------------------------
/*QE11 - request
QE10 - payment
TEST - test ortami
*/
procedure kt_payment_amount_al(pn_internal_no number ,pn_sira_no number, ps_OP varchar2 default 'QE11',pn_statu_code out number,pn_payment_amount out number) 
is
    pc_ref cbs.pkg_soa_transaction.cursorreferencetype;
      
      CURSOR c_islem IS
        select internal_no, sira_no,service_id_column,t59_ls ,0 t32b from cbs_direct_debit_uc_prep_data
        where internal_no = pn_internal_no and
              sira_no = pn_sira_no  and
              ps_op = 'QE11' -- requirement olarak sorgulanirsa  payment amount bos gonderilir    
       union         
           select  internal_no, sira_no,service_id_column,t59_ls ,abs(t32b) from cbs_direct_debit_uc_data --sevalb 30112012 abs eklendi
           where internal_no = pn_internal_no and
                  sira_no = pn_sira_no  and
                  ps_OP = 'QE10'  ;         --QE10 - payment

    r_islem c_islem%ROWTYPE;

    ps_statu_explanation   varchar2(2000);
    webservice_statu_error exception ; 
    --   ls_hata_mesaj varchar2(500);
    ls_ucpointer                     varchar2(3) := pkg_hata.getucpointer;
    ls_delimiter                     varchar2(3) := pkg_hata.getdelimiter;

    ps_PARAM1 varchar2(100);--:='1000';
    ps_SERVICE_ID varchar2(100):='0'; 
    ps_SUPPLIER_ID varchar2(100):='555';
    ps_QID varchar2(100):=  PKG_GENEL.GENEL_KOD_AL('DDS_WEBSERVICE_REQID');
    ps_QM varchar2(100) ;--:=   'TEST';
    ps_SID varchar2(100):='DB';
   -- ps_OP varchar2(100):='QE11';    -- QE11 - request  ,QE10 - payment
    ps_statu_code varchar2(2000);
    ls_Status varchar2(2000); 
    ls_Sum varchar2(2000);  
    ls_Msg  varchar2(2000); 
    ps_agent_id varchar2(10) := '0'; --sevalb 01112012 dds problem SDLC00027906 Natalia her durum icin 0 gonderilmeli dedi. --almas dimitry ile konustu henuz kullanilmayan bir alan  bizim 1 yollamamizi istedi.
/*
QE11 - request
QE10 - payment
*/
Begin
    Pkg_Parametre.deger('DDS_KT_WEBSERVICE_QM',ps_QM);

   OPEN c_islem;
   FETCH c_islem INTO r_islem;
   CLOSE c_islem;
    
    ps_param1 :=r_islem.t59_ls ;
    ps_service_id := r_islem.service_id_column;
    
    ps_statu_code := pkg_soa_transaction.makektwsrequest(ps_param1, ps_service_id, ps_supplier_id, ps_qid, ps_qm, ps_sid, ps_op,r_islem.t32b,ps_agent_id, pc_ref);

    begin
     pn_statu_code := to_number(ps_statu_code);
    exception when others then null;
    end ;
   
    
    begin         
        loop
          fetch pc_ref into  ls_Status, ls_Sum, ls_Msg ;
          exit when PC_REF%notfound;                      
      end loop;
          pn_payment_amount := abs( to_number( trim(replace(nvl(ls_Sum,'0'),'-')),'9999999999999999.99'));
          
        exception when others            
           then log_at('PKG_DIRECT_DEBIT-kt_payment_amount_al-error-1',pn_internal_no ,pn_sira_no, sqlcode ||'' ||sqlerrm ||'ls_Status:'||ls_status ||',ls_Sum:'||ls_sum||',ls_Msg:'||ls_msg);
           begin
                pn_payment_amount :=abs(to_number( trim ( replace(nvl(ls_Sum,'0'),'-')))) ; 
            exception when others then 
                log_at('PKG_DIRECT_DEBIT-kt_payment_amount_al-error-2',pn_internal_no ,pn_sira_no, sqlcode ||'' ||sqlerrm ||'ls_Status:'||ls_status ||',ls_Sum:'||ls_sum||',ls_Msg:'||ls_msg);
              begin                
                pn_payment_amount := abs(to_number(replace(replace(replace(trim(nvl(ls_sum,'0')),'-'),',',','),';',','))); --sevalb 03122012
                exception when others then 
                log_at('PKG_DIRECT_DEBIT-kt_payment_amount_al-error-3',pn_internal_no ,pn_sira_no, sqlcode ||'' ||sqlerrm ||'ls_Status:'||ls_status ||',ls_Sum:'||ls_sum||',ls_Msg:'||ls_msg);
                end; 
        end;
     End;
   
    if trim(ls_Sum) is null and  ps_OP = 'QE10' then
            pn_payment_amount := abs(r_islem.t32b); 
    end if;
    
    --B-O-M sevalb 01112012 dds problem SDLC00027906
    if  ps_OP = 'QE10' then
       ps_agent_id := '0';
    end if;
    --E-O-M sevalb 01112012 dds problem SDLC00027906

    ps_statu_explanation :=ls_Msg ||' '||pkg_direct_Debit.kt_statu_code_explanation( pn_statu_code) ;
        
    pkg_direct_debit.ins_dds_webserv_log(
                r_islem.internal_no   ,     -- pn_internal_no        
                r_islem.sira_no,            -- pn_sira_no       
                ps_op,                     -- ps_op    
                ps_SID,                       -- ps_sid
                sysdate,                   -- pd_dts     
                ps_QID ,-- ps_qid            
                ps_qm ,                     -- ps_qm         
                ps_SUPPLIER_ID ,                       -- ps_supplier_id
                ps_SERVICE_ID,  -- pn_service_id
                ps_param1,            -- ps_param1_KT_personal_number
                pn_statu_code ,             -- ps_status
                ps_statu_explanation ,       -- ps_status_explanation,
                pn_payment_amount       -- pn_sum_payment_amount
              ) ;
EXCEPTION
      when webservice_statu_error then
            pn_statu_code :=nvl(pn_statu_code,990);
            ps_statu_explanation := pkg_hata.generatemessage(ls_ucpointer
                                                  || 6170
                                                  || ls_delimiter
                                                  || '999 - ERROR' 
                                                  || ls_delimiter                                              
                                                  || ls_ucpointer);
              pkg_direct_debit.ins_dds_webserv_log(
                r_islem.internal_no   ,     -- pn_internal_no        
                r_islem.sira_no,            -- pn_sira_no       
                ps_op,                     -- ps_op    
                ps_SID,                       -- ps_sid
                 sysdate,                   -- pd_dts     
                ps_QID ,-- ps_qid            
                ps_qm ,                     -- ps_qm         
                ps_SUPPLIER_ID ,                       -- ps_supplier_id
                ps_SERVICE_ID,  -- pn_service_id
                ps_param1 ,            -- ps_param1_KT_personal_number
                pn_statu_code ,             -- ps_status
                ps_statu_explanation,        -- ps_status_explanation,
                pn_payment_amount       -- pn_sum_payment_amount
              ) ;

        --RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6170'  || Pkg_Hata.getDelimiter  || ps_statu_code  ||'-'||ps_statu_explanation || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
      when others then
         --raise_application_error(-20100,pkg_hata.getucpointer || '6171'  || pkg_hata.getdelimiter || to_char(sqlcode)||'-' || to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer);
            pn_statu_code := nvl(pn_statu_code,991);
            ps_statu_explanation := pkg_hata.generatemessage(ls_ucpointer
                                                  || 6171
                                                  || ls_delimiter
                                                  || to_char(sqlcode) ||'-' ||sqlerrm ||',ls_Status:'||ls_Status ||',ls_Sum:'||ls_Sum||',ls_Msg:'||ls_Msg 
                                                  || ls_delimiter                                              
                                                  || ls_ucpointer);
              pkg_direct_debit.ins_dds_webserv_log(
                r_islem.internal_no   ,     -- pn_internal_no        
                r_islem.sira_no,            -- pn_sira_no       
                ps_op,                     -- ps_op    
                ps_SID,                       -- ps_sid
                 sysdate,                   -- pd_dts     
                ps_QID ,-- ps_qid            
                ps_qm ,                     -- ps_qm         
                ps_SUPPLIER_ID ,               -- ps_supplier_id
                ps_SERVICE_ID,  -- pn_service_id
                ps_param1,            -- ps_param1_KT_personal_number
                pn_statu_code ,             -- ps_status
                ps_statu_explanation,        -- ps_status_explanation,
                pn_payment_amount       -- pn_sum_payment_amount
              ) ;
 End; 
PROCEDURE ins_dds_webserv_log(
                pn_internal_no    number,         
                pn_sira_no number,                    
                ps_op   varchar2 default 'QE10',
                ps_sid varchar2 default 'DB',       
                pd_dts    date default null ,   --="2011-05-20 01:01:01"     maturity date      
                ps_qid      varchar2 default null,      
                ps_qm       varchar2 default 'TEST',        --const    TEST(in Kabul) and Normal(in PROD)
                ps_supplier_id      varchar2 default '555',  
                pn_service_id       number default null,      
                ps_param1_KT_personal_number  varchar2 default null,
                ps_status   varchar2 default null,
                ps_status_explanation   varchar2 default null,
                pn_sum_payment_amount number default null        
                )
IS
pragma autonomous_transaction;
 begin
      insert into  cbs_dds_webserv_log
             (      log_no    ,
                    internal_no,
                    sira_no,
                    banka_tarihi    ,                    
                    kt_op    ,
                    kt_sid    ,
                    kt_dts    ,
                    kt_qid    ,
                    kt_qm    ,
                    kt_supplier_id    ,
                    kt_service_id,
                    KT_SUM_PAYMENT_AMOUNT    ,
                    KT_PARAM1_KT_PERSONAL_NUMBER    ,
                    kt_status    ,
                    kt_status_explanation    
           )       
      values (
                    pkg_genel.genel_kod_al('DDS_WEBSERV_LOG')  ,
                    pn_internal_no,
                    pn_sira_no,
                    pkg_muhasebe.banka_tarihi_bul    ,
                    ps_op    ,
                    ps_sid    ,
                    pd_dts    ,
                    ps_qid    ,
                    ps_qm    ,
                    ps_supplier_id    ,
                    pn_service_id,
                    pn_sum_payment_amount    ,
                    ps_param1_KT_personal_number    ,
                    ps_status    ,
                    ps_status_explanation);   
      commit;
  Exception when others then
    rollback ;
    log_at('ins_dds_webserv_log error:',sqlcode,sqlerrm);

 End;
--------------------------------------------------------------------------------------
-- call_webservice_ins_dds_uc is called by DDSFL and 7070 to inquiry ky payment amount
-------------------------------------------------------------------------------------- 
PROCEDURE call_webservice_ins_dds_uc(pn_file_id number ,pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'CALL_WEBSERVICE_INS_DDS_UC' ) 
is
cursor cur_direct is 
select * from cbs_direct_debit_uc_prep_data
where ( ( internal_no =pn_file_id and pn_file_id <>0  ) or( pn_file_id = 0)  )
        and durum_kodu = 'A'
        and ( webservice_statu_code is null or webservice_statu_code < 200 or  webservice_statu_code> 299 )
for update of webservice_statu_code ,
           webservice_statu_explanation,
           webservice_statu_last_upd_date,
           webserv_statu_last_upd_bank_dt,
           durum_kodu ,kapanis_tarihi,kapanis_system_tarihi;
 
    r_Direct cur_direct%rowtype;
    ln_statu_code   number := null;
    ln_payment_amount   number := null;
    ls_statu_explanation    varchar2(2000);
    ps_OP varchar2(100):='QE11';    -- QE11 - request  ,QE10 - payment
Begin

    For c_direct in cur_Direct loop

        r_Direct :=c_direct;
        -- update old date val records to I iptal status
         if r_direct.date_val < to_number(to_char(pkg_muhasebe.banka_tarihi_bul,'yymmdd'))  then   
            update cbs_direct_debit_uc_prep_data
            set durum_kodu = 'I',
                kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
                kapanis_system_tarihi = sysdate            
            where internal_no = r_Direct.internal_no and sira_no = r_Direct.sira_no;
        else
        -- call  webservice for active records and log into log table
               begin 
                ln_statu_code := null;
                ln_payment_amount :=null;
                
                pkg_direct_Debit.kt_payment_amount_al(r_direct.internal_no  ,r_direct.sira_no,ps_OP,ln_statu_code ,ln_payment_amount );
                ln_payment_amount := abs(ln_payment_amount); --sevalb 03122012
               exception when others then 
                    log_at('call_webservice_ins_dds_uc error',r_direct.internal_no,r_direct.sira_no,sqlcode||' ' ||sqlerrm ||' '||',ln_statu_code:' ||ln_statu_code ||',ln_payment_amount:'||ln_payment_amount );
               end;

                ls_statu_explanation  := pkg_direct_debit.kt_statu_code_explanation(ln_statu_code);

               update cbs_direct_debit_uc_prep_data
               set t32b =  ln_payment_amount,
                   webservice_statu_code = ln_statu_code,      
                   webservice_statu_explanation  =ls_statu_explanation,
                   webservice_statu_last_upd_date = sysdate, 
                   webserv_statu_last_upd_bank_dt = pkg_muhasebe.banka_tarihi_bul                               
               where internal_no =r_direct.internal_no and
                      sira_no = r_direct.sira_no ;
               
          end if;  
    End loop;

--2. insert into main uc table
    insert into cbs_direct_debit_uc_data(
            internal_no    ,
            sira_no    ,
            type_msg    ,
            type_plt    ,
            date_val    ,
            t52a    ,
            t52a_name    ,
            t26t    ,
            t50    ,
            t50_schet    ,
            t50_sub    ,
            t50_name    ,
            t32b    ,
            t57    ,
            t57_name    ,
            t59    ,
            t59_inn    ,
            t59_okpo    ,
            t59_sfond    ,
            t59_sub    ,
            t59_ls    ,
            t59_name    ,
            t70    ,
            t70_1    ,
            t77b_dnum    ,
            t77b_ddate    ,
            creation_date    ,
            crator_user    ,
            file_name    ,
            bank_date    ,
            number_column    ,
            service_id_column    ,
            param1_column    ,
            file_id_no    ,
            yaratan_tx_no    ,
            our_customer    ,
            account_no    ,
            message_reference)
            select 
            internal_no    ,
            sira_no    ,
            type_msg    ,
            type_plt    ,
            date_val    ,
            t52a    ,
            t52a_name    ,
            t26t    ,
            t50    ,
            t50_schet    ,
            t50_sub    ,
            t50_name    ,
            t32b    ,       
            t57    ,
            t57_name    ,
            t59    ,
            t59_inn    ,
            t59_okpo    ,
            t59_sfond    ,
            t59_sub    ,
            t59_ls    ,
            t59_name    ,
            t70    ,
            t70_1    ,
            t77b_dnum    ,
            t77b_ddate    ,
            creation_date    ,
            crator_user    ,
            file_name    ,
            bank_date    ,
            number_column    ,
            service_id_column    ,
            param1_column    ,
            file_id_no    ,
            yaratan_tx_no    ,
            our_customer    ,
            account_no    ,
            message_reference    
            from cbs_direct_debit_uc_prep_data 
            where ( ( internal_no =pn_file_id and pn_file_id <>0  ) or( pn_file_id = 0)  )
                   and durum_kodu = 'A' 
                   and webservice_statu_code between 200 and 299 ;
                   
--3 close active status to K 
        
    update   cbs_direct_debit_uc_prep_data
    set  durum_kodu = 'K',
         kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul,
          kapanis_system_tarihi = sysdate            
    where ( ( internal_no =pn_file_id and pn_file_id <>0  ) or( pn_file_id = 0)  )
               and durum_kodu = 'A' 
               and webservice_statu_code between 200 and 299 ;


    commit;
        
  Exception
   When Others Then
        rollback;
        log_At('call_webservice_ins_dds_uc-error',sqlcode,sqlerrm );
      -- if pn_File_id <> 0 and pn_File_id is not null then  --comes from screen not batch process  
            Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6169' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     
 End;
----------------------------------------------------------------------------------------------
PROCEDURE call_webservice_payment_upd(pn_file_id number ,pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'CALL_WEBSERVICE_PAYMENT_UPD' ) 
is

cursor cur_direct is 
select * from cbs_direct_debit_uc_data
where  durum_kodu = 'K' 
       and ( webservice_statu_code is null or webservice_statu_code < 200 or  webservice_statu_code> 299 )
       and journal_no is not null
       and PKG_MUHASEBE.BANKA_TARIHI_BUL <= pkg_tarih.ayin_son_is_gunu(to_date('20'||to_char(DATE_VAL,'FM000000'),'yyyymmdd'))        
for update of webservice_statu_code ,
           webservice_statu_explanation,
           webservice_statu_last_upd_date,
           webserv_statu_last_upd_bank_dt; 

    r_Direct cur_direct%rowtype;
    ln_statu_code   number := null;
    ln_payment_amount   number := null;
    ls_statu_explanation    varchar2(2000);
  ps_OP varchar2(100):='QE10';    -- QE11 - request  ,QE10 - payment
Begin

    For c_direct in cur_Direct loop
        begin 
                r_Direct :=c_direct; 
                ln_statu_code := null;
                ln_payment_amount :=null;                
                pkg_direct_Debit.kt_payment_amount_al(r_direct.internal_no  ,r_direct.sira_no,ps_op,ln_statu_code ,ln_payment_amount );
                ln_payment_amount := abs(ln_payment_amount); --sevalb 03122012
               exception when others then 
                    log_at('call_webservice_payment_upd-error-1',r_direct.internal_no,r_direct.sira_no,sqlcode||' ' ||sqlerrm ||' '||',ln_statu_code:' ||ln_statu_code ||',ln_payment_amount:'||ln_payment_amount );
               end;
                
                ls_statu_explanation  := pkg_direct_debit.kt_statu_code_explanation(ln_statu_code);

               update cbs_direct_debit_uc_data
               set webservice_statu_code = ln_statu_code,      
                   webservice_statu_explanation  =ls_statu_explanation,
                   webservice_statu_last_upd_date = sysdate, 
                   webserv_statu_last_upd_bank_dt = pkg_muhasebe.banka_tarihi_bul                               
               where internal_no =r_direct.internal_no and
                      sira_no = r_direct.sira_no ;
    End loop;

    commit;
        
  Exception
   When Others Then
        rollback;
        log_At('call_webservice_payment_upd-error general',sqlcode,sqlerrm );
            Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6169' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
 End;
----------------------------------------------------------------------------------------------
PROCEDURE BATCH_CALL_KT_WEBSERVICE(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'BATCH_CALL_KT_WEBSERVICE'  ) 
is
Begin
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  pkg_direct_debit.call_webservice_ins_dds_uc(0  ,pn_grup_no , pn_log_no ,'PKG_DIRECT_DEBIT.BATCH_CALL_KT_WEBSERVICE' );
   commit; 
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
Exception
   When Others Then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
End;
----------------------------------------------------------------------------------------------
PROCEDURE BATCH_CALL_KT_WEBSERV_PAYMENT(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'BATCH_CALL_KT_WEBSERV_PAYMENT'  ) 
is
Begin
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
   pkg_direct_debit.call_webservice_payment_upd(0  ,pn_grup_no , pn_log_no ,'PKG_DIRECT_DEBIT.BATCH_CALL_KT_WEBSERV_PAYMENT' );
   commit; 
   pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
Exception
   When Others Then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
End;
----------------------------------------------------------------------------------------------
PROCEDURE RUN_DDS_PROCESS_FLOW(pn_grup_no NUMBER default 0, pn_log_no NUMBER default 0,ps_program_kod VARCHAR2 default 'RUN_DDS_PROCESS_FLOW' )
is
ls_program_kod varchar2(100);
Begin
 
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  
    --1. phase-2 load reject file
    begin
      ls_program_kod :='PKG_DIRECT_DEBIT.MESSAGELOAD_REJECTS';
      pkg_direct_debit.MessageLoad_Rejects(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;    
     
   --2. run  phase-1 message load 
    begin
     ls_program_kod :='PKG_DIRECT_DEBIT.MESSAGELOAD';
      pkg_direct_debit.messageload(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;    

  --3. run phase-1 makepayment 
    begin
     ls_program_kod :='PKG_DIRECT_DEBIT.MAKEPAYMENT';
      pkg_direct_debit.makepayment(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;

  --4. run phase-2 MessageLoad_UC 
    begin
     ls_program_kod :='PKG_DIRECT_DEBIT.MESSAGELOAD_UC';
      pkg_direct_debit.messageload_uc('MT104.TXT',pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;
  
  --5. run phase-2 BATCH_CALL_KT_WEBSERVICE  call KT webservice and insert into the main table (cbs_direct_debit_uc_data)
    begin
     ls_program_kod :='PKG_DIRECT_DEBIT.BATCH_CALL_KT_WEBSERVICE';
      pkg_direct_debit.BATCH_CALL_KT_WEBSERVICE(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;

--6.run phase-2 ins_dds_cust_noncust_tbl : seperate from cbs_direct_debit_uc_data to sub tables of DIRIZ monitoring screen view
begin
     ls_program_kod :='PKG_DIRECT_DEBIT.INS_DDS_CUST_NONCUST_TBL';
      pkg_direct_debit.ins_dds_cust_noncust_tbl(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
    end ;


--7.run phase-2 write_into_ucdocsmt104out_file : to create  UCDOCSMT104.OUT file
begin
     ls_program_kod :='PKG_DIRECT_DEBIT.WRITE_INTO_UCDOCSMT104OUT_FILE';
      pkg_direct_debit.write_into_ucdocsmt104out_file(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
                      
    end ;

--8.run phase-2 UC_Accounting_Our_Customer : journal is created for our customers
begin
     ls_program_kod :='PKG_DIRECT_DEBIT.UC_ACCOUNTING_OUR_CUSTOMER';
      pkg_direct_debit.UC_Accounting_Our_Customer(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;

 --9.run phase-2 UC_Accounting_NotOur_Customer : journal is created for not our customers
begin
     ls_program_kod :='PKG_DIRECT_DEBIT.UC_ACCOUNTING_NOTOUR_CUSTOMER';
      pkg_direct_debit.UC_Accounting_NotOur_Customer(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;

--10.run phase-2 BATCH_CALL_KT_WEBSERV_PAYMENT to make update status paid
begin
     ls_program_kod :='PKG_DIRECT_DEBIT.BATCH_CALL_KT_WEBSERV_PAYMENT';
      pkg_direct_debit.BATCH_CALL_KT_WEBSERV_PAYMENT(pn_grup_no , pn_log_no ,ls_program_kod );
      commit;
      Exception
      when others then
        rollback;
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ls_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
        Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);
    end ;

 

    commit;

    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 Exception
   when others then
    rollback;
    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,to_char(sqlcode) ||' '|| SQLERRM);
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ls_program_kod);

End;

----------------------------------------------------------------------------------------------


END;
/

