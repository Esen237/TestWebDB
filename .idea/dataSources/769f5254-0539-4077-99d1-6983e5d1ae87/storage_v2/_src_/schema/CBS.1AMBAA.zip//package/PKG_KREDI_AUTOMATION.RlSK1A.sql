create PACKAGE     "PKG_KREDI_AUTOMATION" IS

/******************************************************************************
   Name       : PKG_KREDI_AUTOMATION
   Created By : Temirlan Talapkerov
   Date          : 27.08.2020
   Purpose      : procedures and functions for automatic repayment of loan delinquencies
******************************************************************************/

 PROCEDURE pastdue_closing_payment_main (pn_islem_numara number);
 PROCEDURE pastdue_blocking(pn_islem_numara number);
 PROCEDURE sp_Principal_Pastdue_Closing( pn_pd_account_no number,
                                        pd_value_date date,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_related_account number,
                                        pn_collection_account number,
                                        pn_tahsedil_gecenyilfaiztutar number,
                                        pn_tahsedil_gecmis_aylar_faiz number,
                                        pn_tahsedil_birikmisfaiztutar number,
                                        pn_anapara_tahsilat_tutar number,
                                        ps_aciklama varchar2,
                                        ps_choice varchar2,
                                        ps_durum_kodu varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2, 
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        ps_past_due_currency varchar2,
                                        pn_musteri_no number); 
 PROCEDURE sp_penalty_Pastdue_Closing( ps_cash_account varchar2,
                                        ps_currency_code varchar2,
                                        pn_customer_no number,
                                        ps_residency_code varchar2,
                                        ps_citizen_code varchar2,
                                        ps_customer_type varchar2, 
                                        ps_income_type varchar2, 
                                        pn_related_account number,
                                        pn_amount number,
                                        ps_vat varchar2,
                                        ps_service_tax varchar2,
                                        pn_service_tax_rate number,
                                        ps_tax_coll_type varchar2,
                                        pn_paid_tax_amount number,
                                        pn_total_collection_amount number,
                                        ps_collection_currency varchar2,
                                        pn_rate number,
                                        pn_collection_account number,
                                        ps_income_gl varchar2,
                                        ps_explanation varchar2,
                                        ps_pd_branch_cd varchar2,
                                        ps_modul_tur_kod varchar2,
                                        ps_urun_tur_kod varchar2,
                                        ps_urun_sinif_kod varchar2,
                                        pn_current_account number);                                         
 PROCEDURE sp_convert_for_pd_closing_arb(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number);
 PROCEDURE sp_transfer_for_pd_closing(pn_loan_account number, pn_current_account number, pn_amount number, pn_alter_current_account number, pn_alis_tutari out number);
 FUNCTION arbitraj_kur( ps_account_currency varchar2, 
                            ps_past_due_currency varchar2, 
                            pn_available_amount number, 
                            ps_account_branch varchar2, 
                            pb_buy_loan_currency boolean default false,
                            pb_bought_amount boolean default false) RETURN number; 
 PROCEDURE Giris_Kontrol(pn_islem_no number);
 FUNCTION what_month(pd_date date) RETURN varchar2; -- CBS-119 past due closing
 FUNCTION payment_anapara_pd_before_2013(pn_available_amount number) RETURN number; -- CBS-119 past due closing
 FUNCTION payment_faiz_pd_before_2013(pn_available_amount number) RETURN number;    -- CBS-119 past due closing
 FUNCTION payment_def_int_before_2013_pd(pn_available_amount number) RETURN number; -- CBS-119 past due closing
 FUNCTION payment_penalty_pd_before_2013(pn_available_amount number) RETURN number; -- CBS-119 past due closing
 PROCEDURE payment_anapara_pd_after_2013(pn_available_amount number, pn_musteri_no number, ps_name_surname varchar2, pn_available_amount_after out number);  -- CBS-119 past due closing
 PROCEDURE payment_faiz_pd_after_2013(pn_available_amount number, pn_musteri_no number, ps_name_surname varchar2, pn_available_amount_after out number);     -- CBS-119 past due closing
 FUNCTION payment_def_int_after_2013_pd(pn_available_amount number) RETURN number;  -- CBS-119 past due closing
 FUNCTION payment_penalty_pd_after_2013(pn_available_amount number) RETURN number;  -- CBS-119 past due closing
 PROCEDURE pastdue_closing_payment_after(pn_current_account number, ps_account_currency varchar2, pn_musteri_no number, pn_bloke_amount number);
 END;
/

