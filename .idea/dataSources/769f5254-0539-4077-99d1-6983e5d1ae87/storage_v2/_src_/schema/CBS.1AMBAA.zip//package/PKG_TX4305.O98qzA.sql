create PACKAGE PKG_TX4305 IS

/******************************************************************************
   Name       : PKG_TX4305
   Created By : Bilal GUL
   Purpose	  : ?ubeler Aras? Havale ?ptal Talebi
******************************************************************************/

  -- TX Event Listesi
  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

Procedure Havale_Bilgisi_Al(ps_REFERANS CBS_SUBELERARASI_HAV_GIR.REFERANS%type,
                               ps_URUN_TUR out CBS_SUBELERARASI_HAV_GIR.URUN_TUR%type,
							   ps_URUN_SINIF out CBS_SUBELERARASI_HAV_GIR.URUN_SINIF%type,
							   ps_ALICI_SUBE out CBS_SUBELERARASI_HAV_GIR.ALICI_SUBE%type,
							   ps_DOVIZ_KODU out CBS_SUBELERARASI_HAV_GIR.DOVIZ_KODU%type,
							   ps_TUTAR out CBS_SUBELERARASI_HAV_GIR.TUTAR%type,
							   ps_GONDEREN_MUSTERI_NO out CBS_SUBELERARASI_HAV_GIR.GONDEREN_MUSTERI_NO%type,
							   ps_GONDEREN_HESAP_NO out CBS_SUBELERARASI_HAV_GIR.GONDEREN_HESAP_NO%type,
							   ps_GONDEREN_ISIM_UNVAN out CBS_SUBELERARASI_HAV_GIR.GONDEREN_ISIM_UNVAN%type,
							   ps_GONDEREN_ADRES out CBS_SUBELERARASI_HAV_GIR.GONDEREN_ADRES%type,
							   ps_GONDEREN_TEL_NO out CBS_SUBELERARASI_HAV_GIR.GONDEREN_TEL_NO%type,
							   ps_ALICI_MUSTERI_NO out CBS_SUBELERARASI_HAV_GIR.ALICI_MUSTERI_NO%type,
							   ps_ALICI_HESAP_NO out CBS_SUBELERARASI_HAV_GIR.ALICI_HESAP_NO%type,
							   ps_ALICI_ISIM_UNVAN out CBS_SUBELERARASI_HAV_GIR.ALICI_ISIM_UNVAN%type,
							   ps_ALICI_ADRES out CBS_SUBELERARASI_HAV_GIR.ALICI_ADRES%type,
							   ps_ALICI_TEL_NO out CBS_SUBELERARASI_HAV_GIR.ALICI_TEL_NO%type,
							   ps_ACIKLAMA out CBS_SUBELERARASI_HAV_GIR.ACIKLAMA%type,
							   ps_GONDERIM_AMACI out CBS_SUBELERARASI_HAV_GIR.GONDERIM_AMACI%type,
							   ps_MASRAF_TAHSIL_DOVIZ out CBS_SUBELERARASI_HAV_GIR.MASRAF_TAHSIL_DOVIZ%type,
							   ps_MASRAF_TAHSIL_SEKLI out CBS_SUBELERARASI_HAV_GIR.MASRAF_TAHSIL_SEKLI%type,
							   ps_MASRAF_TUTARI out CBS_SUBELERARASI_HAV_GIR.MASRAF_TUTARI%type,
							   ps_HAVALE_TARIHI out CBS_SUBELERARASI_HAV_GIR.HAVALE_TARIHI%type,
							   ps_BOLUM_KODU out CBS_SUBELERARASI_HAV_GIR.BOLUM_KODU%type,
							   ps_DURUM_KODU out CBS_SUBELERARASI_HAV_GIR.DURUM_KODU%type,
							   ps_MASRAF_DOVIZ out CBS_SUBELERARASI_HAV_GIR.MASRAF_DOVIZ%type,
							   pn_MASRAF_TAHSILDVZLI_TUTAR out CBS_SUBELERARASI_HAV_GIR.MASRAF_TAHSILDVZLI_TUTAR%type
							   );

 Function  Sf_Bitmemis_Islem_Var_Mi( pn_islem_no   cbs_islem.numara%type ,
										   ps_referans   CBS_SUBELERARASI_HAV_GIR.referans%type) return number;

END;


/

