create Package Body     PKG_STATEMENT_MANUAL is
---------------------------------------------------------------------------------
PROCEDURE PREPARE_CUSTOMER_STATEMENT IS
	CURSOR c1(ld1 date) IS
		select distinct satir_hesap_numara
		from cbs_vw_hesap_ekstre
		 where nvl(PERSONEL_SICIL_NO,0)=0
		   AND FIS_TUR='G'
		   and FIS_MUHASEBELESTIGI_TARIH  between pkg_vadehesap_rapor.ekstre_bas_tarih(satir_hesap_numara, ld1) and ld1;
	r1	 					c1%ROWTYPE;

	CURSOR c2 IS
		select
		    musteri_no,
		    fis_numara,
		    fis_islem_numara,
		    trim(upper(isim_unvan)) isim_unvan,
		    hesap_turu,
		    vergi_no,
		    hesap_doviz_kodu,
		    adres,
		    fis_fis_no,
		    fis_tur,
		    satir_numara,
		    satir_tur,
		    satir_hesap_bolum_kodu,
		    fis_muhasebelestigi_tarih,
		    satir_valor_tarihi,
		    satir_dv_tutar,
		    satir_doviz_kod,
		    substr(satir_musteri_aciklama,1,500) satir_musteri_aciklama,
		    bolum_kodu,
		    fis_yaratildigi_banka_tarih,
/*		    bakiye,  */
		    pkg_genel.bolum_adi_al_hatasiz(satir_hesap_bolum_kodu) as bolum_adi,
		    pkg_report5.GetNBEquivalent(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEquivalent,
				case when satir_dv_tutar > 0 then satir_dv_tutar else 0 end credit,
				case when satir_dv_tutar < 0 then satir_dv_tutar else 0 end debit,
			personel_sicil_no
		from cbs_vw_hesap_ekstre
		 where nvl(PERSONEL_SICIL_NO,0)=0
		   AND FIS_TUR='G'
		   and satir_hesap_numara = r1.satir_hesap_numara;
	r2	 					c2%ROWTYPE;

	pd_last_eod date;


	ls_external_acc     varchar2(30);
	ls_vergi 		   varchar2(100);
	ls_donem		   varchar2(100);
	ln_extre_no 	   number;
	ln_credit  	       number;
	ln_debit 		   number;
	ln_devir_bakiye	   number;
BEGIN
--	pd_last_eod:=pkg_muhasebe.Onceki_Banka_Tarihi_Bul;
pd_last_eod:=to_date('31.03.2008','dd.mm.yyyy');

	begin
log_at('hakan_hizli_ekstre1');
		delete from cbs_hizli_ekstre where trunc(eod_tarih)=trunc(pd_last_eod);

log_at('hakan_hizli_ekstre2');
		OPEN c1(pd_last_eod);
		LOOP
			FETCH c1 INTO r1;
			EXIT WHEN c1%NOTFOUND;
				if pkg_vadehesap_rapor.ekstre_basilacak(r1.satir_hesap_numara,pd_last_eod) = 'E'
				then
				    ls_external_acc := pkg_hesap.External_HesapNo_Al(r1.satir_hesap_numara) ;
				    ls_vergi := pkg_vadehesap_rapor.musteri_vergino_al_dairesiz(r1.satir_hesap_numara);
				    ls_donem := pkg_vadehesap_rapor.ekstre_bas_donem(r1.satir_hesap_numara,pd_last_eod) || ' - '  ||to_char(pd_last_eod,'DD.MM.YYYY');
				    ln_extre_no := pkg_vadehesap_rapor.ekstre_no_bul(r1.satir_hesap_numara,pd_last_eod);
				    ln_devir_bakiye := pkg_vadehesap_rapor.sf_devirbakiyebul(r1.satir_hesap_numara,replace(substr(ls_donem,1,10),'.','/'));

/*					OPEN c2;
					LOOP
						FETCH c2 INTO r2;
						EXIT WHEN c2%NOTFOUND;

						if r2.FIS_MUHASEBELESTIGI_TARIH between pkg_vadehesap_rapor.ekstre_bas_tarih(r1.satir_hesap_numara,pd_last_eod)
						                                 and pd_last_eod
						then
							insert into cbs_hizli_ekstre
							(MUSTERI_NO,FIS_NUMARA,FIS_ISLEM_NUMARA,ISIM_UNVAN,EXTERNAL_ACC,HESAP_TURU,VERGI_NO,
							 HESAP_DOVIZ_KODU,ADRES,FIS_FIS_NO,FIS_TUR,SATIR_NUMARA,SATIR_TUR,SATIR_HESAP_BOLUM_KODU,
							 SATIR_HESAP_NUMARA,FIS_MUHASEBELESTIGI_TARIH,SATIR_VALOR_TARIHI,SATIR_DV_TUTAR,SATIR_DOVIZ_KOD,
							 SATIR_MUSTERI_ACIKLAMA,BOLUM_KODU,FIS_YARATILDIGI_BANKA_TARIH,BAKIYE,
							 BOLUM_ADI,
							 NBEQUIVALENT,
							 CREDIT,DEBIT,VERGI_NO_DAIRESIZ,DONEM,EKSTRE_NO,PERSONEL_SICIL_NO,EOD_TARIH,DEVIR_BAKIYE)
							values
							(r2.musteri_no,r2.fis_numara,r2.fis_islem_numara,trim(upper(r2.isim_unvan)),ls_external_acc,r2.hesap_turu,r2.vergi_no,
							 r2.hesap_doviz_kodu,r2.adres,r2.fis_fis_no,r2.fis_tur,r2.satir_numara,r2.satir_tur,r2.satir_hesap_bolum_kodu,
							 r1.satir_hesap_numara,r2.fis_muhasebelestigi_tarih,r2.satir_valor_tarihi,r2.satir_dv_tutar,r2.satir_doviz_kod,
							 substr(r2.satir_musteri_aciklama,1,500),r2.bolum_kodu,r2.fis_yaratildigi_banka_tarih,r2.bakiye,
							 pkg_genel.bolum_adi_al_hatasiz(r2.satir_hesap_bolum_kodu),
							 pkg_report5.GetNBEquivalent(r2.SATIR_DOVIZ_KOD,r2.FIS_MUHASEBELESTIGI_TARIH,r2.SATIR_DV_TUTAR),
							 r2.credit,r2.debit,ls_vergi,ls_donem,ln_extre_no,r2.personel_sicil_no,pd_last_eod,ln_devir_bakiye);
						end if;
					END LOOP;
					CLOSE c2;   */
				end if;
		END LOOP;
log_at('hakan_hizli_ekstre3');
		CLOSE c1;

		exception
		when others then
log_at('hakan_hizli_ekstre4',SQLERRM);
	end;

	COMMIT;

EXCEPTION
  WHEN OTHERS THEN
log_at('hakan_hizli_ekstre5',SQLERRM);
END;
---------------------------------------------------------------------------------
END;
/

