create PACKAGE PKG_TX1113 IS

/******************************************************************************
   Name       : PKG_TX1114
   Created By : Seval Balci
   Date    	  : 01.09.04
   Purpose	  : Iptal Cek yapraginin aktif hale getirilmesi
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  FUNCTION  Sf_Cek_Aralik_Uygun(pn_cek_no CBS_CEK.cek_no%TYPE ,pn_cek_no_2 CBS_CEK.cek_no%TYPE ) RETURN CBS_CEK.cek_no%TYPE;

END;

/

