create PACKAGE     PKG_TX7730 IS

 /******************************************************************************
   Name       : PKG_TX7730
   Created By : Adilet K.
   Date          : 23.06.2014
   Purpose      :  Package of the transactional screen 7730 - Card Debt and Loan Authorized Users Definition
******************************************************************************/

  TYPE GenCurType IS REF CURSOR;
  
  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir
  
  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  
    -- Helper procedure for adding users to CBS_DOCUMENT_RIGHTS table
   Procedure Add_User(ps_code CBS_DOCUMENT_RIGHTS.USER_CODE%TYPE, ps_form CBS_DOCUMENT_RIGHTS.FORM_NAME%TYPE, ps_date CBS_DOCUMENT_RIGHTS.CREATION_DATE%TYPE);
  
END;

/

