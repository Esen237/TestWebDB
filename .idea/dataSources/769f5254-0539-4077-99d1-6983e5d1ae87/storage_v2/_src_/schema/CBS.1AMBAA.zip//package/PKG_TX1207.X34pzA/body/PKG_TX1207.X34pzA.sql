create PACKAGE BODY     "PKG_TX1207" IS
        pn_1207_alacak_hesap_tipi        number;
        pn_1207_borc_hesap_tipi        number;
        pn_1207_mborclu_hesap_no        number;
        pn_1207_malacak_hesap_no        number;
        pn_1207_musteri_aciklama        number;
        pn_1207_referans        number;
        pn_1207_alacak_hesap_sube_kodu        number;
        pn_1207_alacak_istatistik_kodu        number;
        pn_1207_alis_doviz_kod        number;
        pn_1207_islem_sube_kodu        number;
        pn_1207_fis_aciklama        number;
        pn_1207_borc_istatistik_kodu        number;
        pn_1207_borclu_hesap_sube_kodu        number;
        pn_1207_B_OUTLET_CASH_GL        number;
        pn_1207_A_OUTLET_CASH_GL        number;
        pn_1207_borclu_hesap_no        number;
        pn_1207_banka_aciklama        number;
        pn_1207_alacak_hesap_no        number;
        pn_1207_satis_doviz_kod        number;
        pn_1207_satis_kur        number;
        pn_1207_satis_tl_tutari        number;
        pn_1207_alis_satis_fark_tutari        number;
        pn_1207_alis_tutar        number;
        pn_1207_alis_tl_tutari        number;
        pn_1207_alis_kur        number;
        pn_1207_satis_tutar        number;
        pn_1207_malacak_hesap_tipi    number;
        pn_1207_mborc_hesap_tipi    number;
        pn_1207_borc_hesap        number;
        pn_1207_alacak_hesap        number;
        pn_1207_borc_dk        number;

        pn_1207_alis_buyuk_satis_1        number;
        pn_1207_alis_kucuk_satis_1        number;
        pn_1207_alis_buyuk_satis_2        number;
        pn_1207_alis_kucuk_satis_2        number;
        pn_1207_lc_fc_1        number;
        pn_1207_lc_fc_2        number;
        pn_1207_fc_lc_1        number;
        pn_1207_fc_lc_2        number;
        pn_1207_fc_fc_1        number;
        pn_1207_fc_fc_2        number;
        pn_1207_alacak_dk_1        number;
        pn_1207_alacak_dk_2        number;
        pn_1207_alacak_dk_3        number;
        pn_1207_BORC_CASH_GL_FC_FC   number;
        pn_1207_BORC_CASH_GL_LC_FC   number;

        pn_1207_alis_tutar_R        number;
        pn_1207_alis_tutar_A_R        number;
        pn_1207_alis_tutar_B_R        number;
        pn_1207_ALIS_TL_TUTARI_R        number;
        pn_1207_ALIS_TL_TUTARI_A_R        number;
        pn_1207_ALIS_TL_TUTARI_B_R        number;

        pn_1207_satis_tutar_R        number;
        pn_1207_satis_tutar_A_R        number;
        pn_1207_satis_tutar_B_R        number;
        pn_1207_satis_TL_TUTARI_R        number;
        pn_1207_satis_TL_TUTARI_A_R        number;
        pn_1207_satis_TL_TUTARI_B_R        number;
--------------------------------------------------------------------------------
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
    ln_doviz_tutari number;
    ln_bakiye number;

    CURSOR islem_cursor IS
                SELECT * from CBS_ARBITRAJ_ISLEM
            where TX_NO=pn_islem_no;




    row_islem islem_cursor%ROWTYPE;
    ln_tutar  number := 0;
    ls_name   varchar2(150);
    ln_parite number;
    ln_alis      number;
    ln_satis  number;
    ls_bloke_referans   CBS_BLOKE.BLOKE_REFERANS%TYPE;      --CQ528 MederT 04012016
Begin
    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    if row_islem.REZERVASYON_NO is not null
    then
        if row_islem.REZ_TIP = 'NON-CASH'
        then
            ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

            if PKG_KUR_Rezervasyon.Rezervasyon_Tutar_Turu_Al(row_islem.REZERVASYON_NO) = 'ALIS'
            then
                ln_tutar :=row_islem.ALIS_TUTARI;
            else
                ln_tutar :=row_islem.SATIS_TUTARI;
            end if;

            IF ln_tutar  >ln_bakiye
            THEN --Bakiye Yetersiz..
                RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
            else
                Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                                pn_islem_no,
                                                                ln_tutar);
            end if;
        end if;
--
        if row_islem.REZ_TIP = 'CASH'
        then
            ln_bakiye:=PKG_EF_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

            if PKG_EF_KUR_Rezervasyon.Rezervasyon_Tutar_Turu_Al(row_islem.REZERVASYON_NO) = 'ALIS'
            then
                ln_tutar :=row_islem.ALIS_TUTARI;
            else
                ln_tutar :=row_islem.SATIS_TUTARI;
            end if;

            IF ln_tutar  >ln_bakiye
            THEN --Bakiye Yetersiz..
                RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
            else
                Pkg_ef_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                                pn_islem_no,
                                                                ln_tutar);
            end if;
        end if;
    end if;

    pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1207',row_islem.ALIS_HESAP_NO);

--sevalb 110407 asagidaki kasa kontrolleri  eklendi. 
  if row_islem.urun_tur_kod in ('ACC-CASH','CASH-ACC','CASH-CASH') then
    -- satis tutari cekilen
    if row_islem.urun_tur_kod  = 'ACC-CASH' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C') ;
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.satis_tutari),row_islem.satis_doviz_kodu,'C') ;--  CQ516 Roundings KonstantinJ 28052014
        else Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C') ;
        end if;
    elsif row_islem.urun_tur_kod = 'CASH-ACC' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.alis_tutari),row_islem.alis_doviz_kodu,'Y') ;--  CQ516 Roundings KonstantinJ 28052014
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y') ;
        else Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y') ;
        end if;
    elsif row_islem.urun_tur_kod  = 'CASH-CASH' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.alis_tutari),row_islem.alis_doviz_kodu,'Y',row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C');--  CQ516 Roundings KonstantinJ 28052014
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y',pkg_tutar.rounding(row_islem.satis_tutari),row_islem.satis_doviz_kodu,'C');--  CQ516 Roundings KonstantinJ 28052014
        else Pkg_Tx1601.Kontrol_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y',row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C');
        end if;
    end if;
  end if;

 if row_islem.URUN_TUR_KOD in ('ACC-CASH','CASH-ACC','CASH-CASH')
    then
      if row_islem.NAME_SURNAME is NULL
         then
             if row_islem.ALIS_HESAP_NO is not null
             then
                 ls_name := pkg_hesap.HesaptanMusteriNoAl(row_islem.ALIS_HESAP_NO);
             end if;
             if row_islem.SATIS_HESAP_NO is not null
             then
                 ls_name := pkg_hesap.HesaptanMusteriNoAl(row_islem.SATIS_HESAP_NO);
             end if;
         else
             ls_name := row_islem.NAME_SURNAME;
         end if;

         if row_islem.PARITE is not null
         then
             ln_parite := row_islem.PARITE;
         else
             if row_islem.ALIS_TUTARI > row_islem.SATIS_TUTARI
             then
                 ln_parite := round((row_islem.ALIS_TUTARI / row_islem.SATIS_TUTARI),4);
             else
                 ln_parite := round((row_islem.SATIS_TUTARI / row_islem.ALIS_TUTARI),4);
             end if;
         end if;

        ln_alis := row_islem.ALIS_TUTARI;
        ln_satis := row_islem.SATIS_TUTARI;

        if row_islem.urun_tur_kod in ('CASH-CASH','ACC-CASH')
        then
            if row_islem.urun_sinif_kod in ('FC-FC','LC-FC')
            then
                null;
            else
                 if row_islem.ALIS_DOVIZ_KODU = 'KGS'
                 then
                     ln_alis := pkg_tutar.rounding(row_islem.ALIS_TUTARI);--  CQ516 Roundings KonstantinJ 28052014
                 else
                     ln_alis := row_islem.ALIS_TUTARI;
                 end if;

                 if row_islem.SATIS_DOVIZ_KODU = 'KGS'
                 then
                     ln_satis := pkg_tutar.rounding(row_islem.SATIS_TUTARI);--  CQ516 Roundings KonstantinJ 28052014
                 else
                     ln_satis := row_islem.SATIS_TUTARI;
                 end if;
            end if;

        end if;

        if row_islem.urun_tur_kod in ('CASH-ACC','CASH-CASH')
        then
            if row_islem.urun_sinif_kod in ('LC-FC')
            then
                 if row_islem.ALIS_DOVIZ_KODU = 'KGS'
                 then
                     ln_alis := pkg_tutar.rounding(row_islem.ALIS_TUTARI);--  CQ516 Roundings KonstantinJ 28052014
                 else
                     ln_alis := row_islem.ALIS_TUTARI;
                 end if;

                 if row_islem.SATIS_DOVIZ_KODU = 'KGS'
                 then
                     ln_satis := pkg_tutar.rounding(row_islem.SATIS_TUTARI);
                 else
                     ln_satis := row_islem.SATIS_TUTARI;
                 end if;
            end if;
        end if;

/*
         if row_islem.ALIS_DOVIZ_KODU = 'KGS'
         then
             ln_alis := round(row_islem.ALIS_TUTARI,1);
         else
             ln_alis := row_islem.ALIS_TUTARI;
         end if;

         if row_islem.SATIS_DOVIZ_KODU = 'KGS'
         then
             ln_satis := round(row_islem.SATIS_TUTARI,1);
         else
             ln_satis := row_islem.SATIS_TUTARI;
         end if;
*/
 
         Pkg_Cash_Slip.Cash_Slip(pn_TX_NO                  => pn_islem_no,
                                 pn_ISLEM_TIPI               => 3,
                                 pd_ISLEM_TARIHI           => pkg_muhasebe.Banka_Tarihi_Bul,
                                 ps_ISLEM_TIPI_DOVIZ_KODU  => row_islem.ALIS_DOVIZ_KODU,
                                 pn_ISLEM_TIPI_TUTARI      => row_islem.ALIS_TUTARI,
                                 ps_ACIKLAMA               => row_islem.ACIKLAMA,
                                 pn_MUSTERI_HESAP_NO       => NVL(row_islem.ALIS_HESAP_NO,row_islem.SATIS_HESAP_NO),
                                 ps_MUSTERI_ADI               => ls_name,
                                 pn_KUR                      => ln_parite,
                                 pn_ISLEM_KOD              => 1207,
                                 ps_ARB_DVZ_1              => row_islem.ALIS_DOVIZ_KODU,
                                 ps_ARB_DVZ_2              => row_islem.SATIS_DOVIZ_KODU,
                                 pn_ARB_TUTAR_1              => ln_alis,
                                 pn_ARB_TUTAR_2              => ln_satis,
                                 pn_ISLEM_TIPI_LC_KARSILIK => round(row_islem.ALIS_TUTARI,1)










                                 ) ;
--        end if;

    end if;

    --BOM CQ528 MederT 04012016
        if row_islem.ALIS_HESAP_NO is not null then
            Pkg_Bloke.sp_bloke_yarat(  ls_bloke_referans  ,
                                              pkg_hesap.HesaptanMusteriNoAl(row_islem.ALIS_HESAP_NO),
                                              row_islem.ALIS_HESAP_NO,
                                              row_islem.ALIS_DOVIZ_KODU,
                                              row_islem.ALIS_TUTARI,
                                              12,
                                              'Temporary Blockage' ,
                                              Pkg_Muhasebe.banka_tarihi_bul,
                                              NULL,
                                              NULL,
                                              pn_islem_no);
        end if;
        --EOM CQ528 MederT 04012016
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Sonrasi(pn_islem_no number) is
Begin
    Null;
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
    ls_rez_tip   varchar2(10);
Begin
    select rez_tip
    into ls_rez_tip
    from cbs_arbitraj_islem
    where tx_no = pn_islem_no;

    if ls_rez_tip = 'NON-CASH'
    then
        pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;

    if ls_rez_tip = 'CASH'
    then
        pkg_ef_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;
End;
--------------------------------------------------------------------------------
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Onay_Sonrasi(pn_islem_no number) is

    CURSOR islem_cursor IS
                SELECT * from CBS_ARBITRAJ_ISLEM
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;

    ls_bloke_referans   CBS_BLOKE.BLOKE_REFERANS%TYPE;      --CQ528 MederT 04012016

  Begin
    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    --BOM CQ528 MederT 04012016
    BEGIN
        SELECT bloke_referans
        INTO  ls_bloke_referans
        FROM cbs_bloke_islem
        WHERE tx_no = pn_islem_no and durum_kodu = 'A';
    EXCEPTION
        WHEN OTHERS THEN
        ls_bloke_referans := null;
    END;
    
    if ls_bloke_referans is not null then
        Pkg_Bloke.sp_bloke_yarat( ls_bloke_referans,
                                          pkg_hesap.HesaptanMusteriNoAl(row_islem.ALIS_HESAP_NO),
                                          row_islem.ALIS_HESAP_NO,
                                          row_islem.ALIS_DOVIZ_KODU,
                                          0,
                                          12,
                                          NULL,
                                          Pkg_Muhasebe.banka_tarihi_bul,
                                          NULL,
                                          NULL,
                                          pn_islem_no,
                                          p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                          p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                          p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                          PS_KAPAMA   => 'KAPAMA');
    end if;
    --EOM CQ528 MederT 04012016


      update cbs_arbitraj_islem
      set MUSTERI_NO=pkg_hesap.HesaptanMusteriNoAl(ALIS_HESAP_NO),
            ISLEM_TARIHI=pkg_muhasebe.Banka_Tarihi_Bul
      where URUN_TUR_KOD in ('ACC-ACC','ACC-GL','ACC-CASH')
      and tx_no=pn_islem_no;

  --sevalb 110407 asagidaki kasa kontrolleri  eklendi.
  if row_islem.urun_tur_kod in ('ACC-CASH','CASH-ACC','CASH-CASH') then
    -- satis tutari cekilen
    if row_islem.urun_tur_kod  = 'ACC-CASH' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C') ;
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.satis_tutari),row_islem.satis_doviz_kodu,'C') ;--  CQ516 Roundings KonstantinJ 28052014
        else Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C') ;
        end if;
    elsif row_islem.urun_tur_kod = 'CASH-ACC' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.alis_tutari),row_islem.alis_doviz_kodu,'Y') ;--  CQ516 Roundings KonstantinJ 28052014
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y') ;
        else Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y') ;
        end if;
    elsif row_islem.urun_tur_kod  = 'CASH-CASH' then
        if row_islem.URUN_SINIF_KOD = 'LC-FC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,pkg_tutar.rounding(row_islem.alis_tutari),row_islem.alis_doviz_kodu,'Y',row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C');--  CQ516 Roundings KonstantinJ 28052014
        elsif row_islem.URUN_SINIF_KOD = 'FC-LC' then Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y',pkg_tutar.rounding(row_islem.satis_tutari),row_islem.satis_doviz_kodu,'C');--  CQ516 Roundings KonstantinJ 28052014
        else Pkg_Tx1601.onay_Sonrasi(pn_islem_no,1207,row_islem.alis_tutari,row_islem.alis_doviz_kodu,'Y',row_islem.satis_tutari,row_islem.satis_doviz_kodu,'C');
        end if;
    end if;
  end if;

  End;
--------------------------------------------------------------------------------
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
   CURSOR islem_cursor IS
                SELECT * from CBS_ARBITRAJ_ISLEM
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
  Begin
    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    if row_islem.rez_tip = 'NON-CASH'
    then
        pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;

    if row_islem.rez_tip = 'CASH'
    then
        pkg_ef_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;

    --sevalb 050607 asagidaki kasa kontrolleri  eklendi.
      if row_islem.urun_tur_kod in ('ACC-CASH','CASH-ACC','CASH-CASH') then
        Pkg_Tx1601.Iptal_onay_Sonrasi(pn_islem_no,1207);
      end if;
  End;
--------------------------------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
/*     pkg_dab.DAB_IPTAL(pn_islem_no);
     pkg_dsb.DSB_IPTAL(pn_islem_no);
     */
     null;
     Pkg_Tx1601.Iptal_Muhasebelestir_Sonrasi(pn_islem_no,1207);
 End;
--------------------------------------------------------------------------------
Procedure Reddetme_Sonrasi(pn_islem_no number) is
    ls_rez_tip   varchar2(10);

    --BOM CQ528 MederT 04012016
    ls_bloke_referans   CBS_BLOKE.BLOKE_REFERANS%TYPE;
    ln_hesap_no number;      
    ls_doviz CBS_CARI_NAKIT_CEKILEN_ISLEM.DOVIZ_KODU%TYPE;
    --EOM CQ528 MederT 04012016
Begin
    --BOM CQ528 MederT 04012016
    BEGIN
        SELECT bloke_referans, hesap_no, doviz_kodu
        INTO  ls_bloke_referans, ln_hesap_no, ls_doviz
        FROM cbs_bloke_islem
        WHERE tx_no = pn_islem_no and durum_kodu = 'A';
    EXCEPTION
        WHEN OTHERS THEN
        ls_bloke_referans := null;
    END;
        
    if ls_bloke_referans is not null then
    Pkg_Bloke.sp_bloke_yarat( ls_bloke_referans,
                                      pkg_hesap.HesaptanMusteriNoAl(ln_hesap_no),
                                      ln_hesap_no,
                                      ls_doviz,
                                      0,
                                      12,
                                      NULL,
                                      Pkg_Muhasebe.banka_tarihi_bul,
                                      NULL,
                                      NULL,
                                      pn_islem_no,
                                      p_COZ_KAYIT_TARIH => Pkg_Muhasebe.banka_tarihi_bul,
                                      p_COZ_KAYIT_SISTEM_TARIH     =>SYSDATE ,
                                      p_COZ_KAYIT_KULLANICI_KODU     => Pkg_Baglam.Kullanici_kodu,
                                      PS_KAPAMA   => 'KAPAMA');
    end if;
    --EOM CQ528 MederT 04012016

    select rez_tip
    into ls_rez_tip
    from cbs_arbitraj_islem
    where tx_no = pn_islem_no;

    if ls_rez_tip = 'NON-CASH'
    then
        pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;

    if ls_rez_tip = 'CASH'
    then
        pkg_ef_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
    end if;
End;
--------------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Function Sf_Urun_Tur_Uygunmu(pn_hesap_no cbs_bloke_islem.hesap_no%type ) return varchar2
   is
     ln_adet number;
    Begin
         select  1
       into    ln_adet
       from    cbs_hesap
       where   hesap_no =pn_hesap_no and
                 ( (urun_tur_kod ='CURRENT')
               or
               ( urun_tur_kod  ='DEMAND DEP' and urun_sinif_kod not in ('OVERBALANCE-LC','OVERBALANCE-FC'))
               );

        if nvl(ln_adet,0) <> 0 Then
           return 'E';
        else
           return 'H';
        end if;

    Exception
      When Others Then return 'H';

   End ;
--------------------------------------------------------------------------------
 Function debit_istatistikkod_zorunlumu(pn_borc_hesap_no number,
                                         ps_urun_tur varchar2,
                                         ps_ALIS_DOVIZ_KODU varchar2,
                                        ps_borc_dk_no varchar2
                                     ) return varchar2

  is
   ls_borc_musteri_tipi_kod             varchar2(1);
   ln_borc_dk_grup_kod                 number;
   pn_borc_musteri_no                  number;
  Begin

    if pn_borc_hesap_no is not null then
       pn_borc_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_borc_hesap_no);

         select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_borc_musteri_tipi_kod,
                ln_borc_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_borc_musteri_no  ;

       end if;

      if   (ln_borc_dk_grup_kod    = 1023 ) or
             (ls_borc_musteri_tipi_kod = '4' and ps_alis_doviz_kodu <> Pkg_genel.lc_al ) or
              ( ps_urun_tur like 'CASH-%' AND ps_alis_doviz_kodu <> Pkg_genel.lc_al) or
           ( (substr(ps_borc_dk_no,1,5) in ( '10170','10180')  or substr(ps_borc_dk_no,1,3) in ( '201'))  AND ps_alis_doviz_kodu <> Pkg_genel.lc_al )
             Then   return 'E';
       else
             return 'H';
      end if;

      Exception
        when others then return 'H';
  End;
--------------------------------------------------------------------------------
 Function credit_istatistikkod_zorunlumu(pn_alacak_hesap_no number,
                                          ps_urun_tur varchar2,
                                          ps_satis_DOVIZ_KODU varchar2,
                                         ps_alacak_dk_no varchar2
                                        ) return varchar2
  is
   ls_alacak_musteri_tipi_kod             varchar2(1);
   ln_alacak_dk_grup_kod                 number;
   pn_alacak_musteri_no                  number;
  Begin

      if pn_alacak_hesap_no is not null then
       pn_alacak_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_alacak_hesap_no);

         select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_alacak_musteri_tipi_kod,
                ln_alacak_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_alacak_musteri_no  ;

       end if;

      if   ( ln_alacak_dk_grup_kod    = 1023)  or (ls_alacak_musteri_tipi_kod = '4' and ps_satis_doviz_kodu <> Pkg_genel.lc_al )  or
                ( ls_alacak_musteri_tipi_kod = '4' and ps_satis_doviz_kodu <> Pkg_genel.lc_al ) or
           ( ps_urun_tur like '%-CASH' AND ps_satis_doviz_kodu <> Pkg_genel.lc_al) or
           ( ( substr(ps_alacak_dk_no,1,5) in ( '10170','10180')  or substr(ps_alacak_dk_no,1,3) in ( '201'))  AND ps_satis_doviz_kodu <> Pkg_genel.lc_al ) Then
           return 'E';
        else
          return 'H';
       end if;

      Exception
        when others then return 'H';
  End;
--------------------------------------------------------------------------------
Function debit_istatistikkod_al(pn_borc_hesap_no number,
                                 ps_urun_tur varchar2,
                                 ps_alis_doviz_kodu varchar2,
                                ps_borc_dk_no varchar2,
                                pn_alacak_hesap_no number,
                                ps_istatistik_kod varchar2) return varchar2

  is
    ls_borc_musteri_tipi_kod             varchar2(1);
    ln_borc_dk_grup_kod                 number;
    pn_borc_musteri_no                  number;
    pn_alacak_musteri_no             number;
    ls_kod                             varchar2(200);
  Begin


  if pkg_tx1207.debit_istatistikkod_zorunlumu(pn_borc_hesap_no ,
                                         ps_urun_tur ,
                                         ps_ALIS_DOVIZ_KODU ,
                                        ps_borc_dk_no
                                     ) = 'E' then

    if pn_borc_hesap_no is not null  then
       pn_borc_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_borc_hesap_no);
       select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_borc_musteri_tipi_kod,
                ln_borc_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_borc_musteri_no  ;
     end if;

     if ( ln_borc_dk_grup_kod    = 1023)  or (ls_borc_musteri_tipi_kod = '4' and ps_alis_doviz_kodu <> Pkg_genel.lc_al )  then
              ls_kod := pkg_musteri.paymentkod_formatli_al( pn_borc_musteri_no ,ps_istatistik_kod );
     elsif   ( ps_urun_tur like 'CASH-%' AND ps_alis_doviz_kodu <> Pkg_genel.lc_al) then
          if pn_alacak_hesap_no is not null then
                pn_alacak_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_alacak_hesap_no);
               ls_kod := pkg_musteri.paymentkod_formatli_al( pn_alacak_musteri_no ,ps_istatistik_kod );
           else
                ls_kod := ps_istatistik_kod || '10';
           end if;
     elsif   ( ( substr(ps_borc_dk_no,1,5) in ( '10170','10180')  or substr(ps_borc_dk_no,1,3) in ( '201'))  AND ps_alis_doviz_kodu <> Pkg_genel.lc_al ) Then
             ls_kod := ps_istatistik_kod || '04';
     else
             ls_kod := null;
     end if;
   end if;

     RETURN ls_kod;

   Exception
        when others then return 'H';
  End;
--------------------------------------------------------------------------------
Function credit_istatistikkod_al(pn_alacak_hesap_no number,
                                 ps_urun_tur varchar2,
                                 ps_satis_doviz_kodu varchar2,
                                ps_alacak_dk_no varchar2,
                                pn_borc_hesap_no number,
                                ps_istatistik_kod varchar2) return varchar2

  is
   ls_alacak_musteri_tipi_kod             varchar2(1);
    ln_alacak_dk_grup_kod                 number;
    pn_borc_musteri_no                  number;
    pn_alacak_musteri_no             number;
    ls_kod                             varchar2(200);
  Begin


  if pkg_tx1207.credit_istatistikkod_zorunlumu(pn_alacak_hesap_no ,
                                         ps_urun_tur ,
                                         ps_satis_doviz_kodu ,
                                        ps_alacak_dk_no
                                     ) = 'E' then

    if pn_alacak_hesap_no is not null then
       pn_alacak_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_alacak_hesap_no);

         select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_alacak_musteri_tipi_kod,
                ln_alacak_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_alacak_musteri_no  ;
      end if;

       if  ln_alacak_dk_grup_kod    = 1023  then
              ls_kod := pkg_musteri.paymentkod_formatli_al( pn_alacak_musteri_no ,ps_istatistik_kod );
       elsif   ( ps_urun_tur like '%-CASH' AND ps_satis_doviz_kodu <> Pkg_genel.lc_al) then
              if pn_alacak_hesap_no is not null then
                 pn_borc_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_borc_hesap_no);
                ls_kod := pkg_musteri.paymentkod_formatli_al( pn_borc_musteri_no ,ps_istatistik_kod );
             else
                 ls_kod := ps_istatistik_kod || '10';
            end if;
        elsif   ( ( substr(ps_alacak_dk_no,1,5) in ( '10170','10180')  or substr(ps_alacak_dk_no,1,3) in ( '201'))  AND ps_satis_doviz_kodu <> Pkg_genel.lc_al ) Then
                 ls_kod := ps_istatistik_kod || '04';
        else
                 ls_kod := null;
       end if;
   end if;

    RETURN LS_KOD;
 Exception
        when others then return 'H';
  End;
--------------------------------------------------------------------------------

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ls_islem_kod               cbs_islem.islem_kod%type := '1207';
    ln_fis_no                   cbs_fis.numara%type ;
    ls_alis_doviz_kodu           cbs_hesap.doviz_kodu%type;
    ls_satis_doviz_kodu           cbs_hesap.doviz_kodu%type;
    ls_masraf_doviz_kodu       cbs_hesap.doviz_kodu%type;
    ln_banka_alis_kuru              cbs_kur.dvzalis%TYPE;

    ls_musteri_aciklama        varchar2(2000);
    ls_banka_aciklama          varchar2(2000);
    ls_fis_aciklama            varchar2(2000);

    ls_islem_sube_kodu         cbs_hesap.sube_kodu%TYPE;
    ln_alacak_hesap_no           VARCHAR2(200);
    ls_alacak_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
    ln_borclu_hesap_no           VARCHAR2(200);
    ls_borclu_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
    ln_alis_musteri                  cbs_musteri.musteri_no%type;
    ln_satis_musteri           cbs_musteri.musteri_no%type;
    ln_alis_tl_tutari          cbs_arbitraj_islem.alis_tutari%TYPE;
    ln_alis_tutari              cbs_arbitraj_islem.alis_tutari%TYPE;

    ln_satis_tl_tutari              cbs_arbitraj_islem.alis_tutari%TYPE;
    ln_satis_tutari                  cbs_arbitraj_islem.alis_tutari%TYPE;
    ln_rezervasyon_no            number;
    ln_alis_kuru                number;
    ln_satis_kuru                 number;
    ls_urun_tur_kod                varchar2(200);
    ls_urun_sinif_kod            varchar2(200);
    ln_maliyet_alis_kuru        number := 0;
    ln_maliyet_satis_kuru        number := 0;
    ls_debit_gl_no                varchar2(200);
    ls_credit_gl_no                varchar2(200);
    ls_kur_tipi                 varchar2(20);
    ln_alis_kuru_rez number;
    ln_satis_kuru_rez number;
    ls_rez_tip          varchar2(10);

    ls_dvz          varchar2(3);
    ln_must_kur   number;
    is_b_cy          varchar2(3);
    ls_s_cy          varchar2(3);
    ls_islem_sekli      varchar2(10);
    ln_rounded            NUMBER;
    ls_islem_bolum_kodu varchar2(10) := pkg_tx.Amir_BolumKodu_Al(pn_islem_no); -- AdiletK CQ1153 12.06.2015 Currency rates for branches

    cursor islem_cursor is
       select
                 a.urun_tur_kod,
            a.urun_sinif_kod,
            decode(alis_hesap_no,null,'DK','VS') borc_hesap_tipi,
            decode(satis_hesap_no,null,'DK','VS') alacak_hesap_tipi,
            decode(alis_hesap_no,null,' ',alis_hesap_no),
            decode(satis_hesap_no,null,' ',satis_hesap_no),
           alis_doviz_kodu,
           satis_doviz_kodu,
           nvl(alis_tutari,0) ,
           nvl(satis_tutari,0)   ,
           decode(alis_hesap_no,null,debit_gl_no,alis_hesap_no) alis_hesap_no  ,
           decode(alis_hesap_no,null,pkg_tx.Amir_BolumKodu_Al(tx_no),Pkg_Hesap.HesaptanSubeAl(alis_hesap_no)),
           decode(satis_hesap_no,null,credit_gl_no,satis_hesap_no) satis_hesap_no ,
           decode(satis_hesap_no,null,pkg_tx.Amir_BolumKodu_Al(tx_no),Pkg_Hesap.HesaptanSubeAl(satis_hesap_no)),
           aciklama ,
            pkg_tx.Amir_BolumKodu_Al(tx_no) ,
           decode(alis_hesap_no,null, null,Pkg_Hesap.HESAPTANMUSTERINOAL(alis_hesap_no)) ,
           decode(satis_hesap_no,null,null,Pkg_Hesap.HESAPTANMUSTERINOAL(satis_hesap_no)),
           rezervasyon_no     ,
           alis_kuru,
           satis_kuru,
              --TO_CHAR(NVL(prefix_ISTATISTIK_KODU_ALIS,0)) || alis_doviz_kodu  || TO_CHAR(NVL(ISTATISTIK_KODU_ALIS,0))||ISTAT_ULKE_ALIS_1 || ISTAT_ULKE_ALIS_2 istatistik_kodu_alis  ,
           --TO_CHAR(NVL(prefix_ISTATISTIK_KODU_SATIS,0)) || satis_doviz_kodu|| TO_CHAR(NVL(ISTATISTIK_KODU_SATIS,0))||ISTAT_ULKE_SATIS_1 || ISTAT_ULKE_SATIS_2 istatistik_kodu_satis,
             PKG_TX1207.debit_istatistikkod_al(a.alis_hesap_no ,
                                 a.urun_tur_kod ,
                                 alis_doviz_kodu ,
                                debit_gl_no,
                                a.satis_hesap_no ,
                                istatistik_kodu_alis ) istatistik_kodu_alis,
             PKG_TX1207.credit_istatistikkod_al(a.satis_hesap_no ,
                                 a.urun_tur_kod ,
                                 satis_doviz_kodu ,
                                credit_gl_no,
                                a.alis_hesap_no ,
                                istatistik_kodu_satis ) istatistik_kodu_satis,
            decode(alis_hesap_no,null,' ','VS') borc_hesap_tipi,
            decode(satis_hesap_no,null,' ','VS') alacak_hesap_tipi,
            debit_gl_no,
            credit_gl_no,
            kur_tipi,
            rez_tip
      from cbs_arbitraj_islem a ,
           cbs_islem c
      where    a.tx_no = c.numara and
              a.tx_no = pn_islem_no ;
  Begin
    varchar_list(pn_1207_alacak_hesap_no) := NULL;
    varchar_list(pn_1207_alacak_hesap_sube_kodu) := NULL;
    varchar_list(pn_1207_alacak_hesap_tipi) := NULL;
    varchar_list(pn_1207_alacak_istatistik_kodu) := NULL;
    varchar_list(pn_1207_alis_doviz_kod) := NULL;
    varchar_list(pn_1207_banka_aciklama) := NULL;
    varchar_list(pn_1207_borclu_hesap_no) := NULL;
    varchar_list(pn_1207_borclu_hesap_sube_kodu) := NULL;

    varchar_list(pn_1207_B_OUTLET_CASH_GL) := NULL;
    varchar_list(pn_1207_A_OUTLET_CASH_GL) := NULL;

    varchar_list(pn_1207_borc_hesap_tipi) := NULL;
    varchar_list(pn_1207_borc_istatistik_kodu) := NULL;
    varchar_list(pn_1207_fis_aciklama) := NULL;
    varchar_list(pn_1207_islem_sube_kodu) := NULL;
    varchar_list(pn_1207_malacak_hesap_no) := NULL;
    varchar_list(pn_1207_mborclu_hesap_no) := NULL;
    varchar_list(pn_1207_musteri_aciklama) := NULL;
    varchar_list(pn_1207_referans) := NULL;
    varchar_list(pn_1207_satis_doviz_kod) := NULL;
    number_list(pn_1207_alis_kur):= 0;
    number_list(pn_1207_alis_satis_fark_tutari):= 0;
    number_list(pn_1207_alis_tl_tutari):= 0;
    number_list(pn_1207_alis_tutar):= 0;
    number_list(pn_1207_satis_kur):= 0;
    number_list(pn_1207_satis_tl_tutari):= 0;
    number_list(pn_1207_satis_tutar):= 0;

    number_list(pn_1207_alis_tutar_R):= 0;
    number_list(pn_1207_alis_tutar_A_R):= 0;
    number_list(pn_1207_alis_tutar_B_R):= 0;
    number_list(pn_1207_ALIS_TL_TUTARI_R):= 0;
    number_list(pn_1207_ALIS_TL_TUTARI_A_R):= 0;
    number_list(pn_1207_ALIS_TL_TUTARI_B_R):= 0;

    number_list(pn_1207_satis_tutar_R):= 0;
    number_list(pn_1207_satis_tutar_A_R):= 0;
    number_list(pn_1207_satis_tutar_B_R):= 0;
    number_list(pn_1207_satis_TL_TUTARI_R):= 0;
    number_list(pn_1207_satis_TL_TUTARI_A_R):= 0;
    number_list(pn_1207_satis_TL_TUTARI_B_R):= 0;

    varchar_list(pn_1207_mborc_hesap_tipi) := NULL;
    varchar_list(pn_1207_malacak_hesap_tipi) := NULL;
    boolean_list(pn_1207_borc_dk):= FALSE;
    boolean_list(pn_1207_borc_hesap):= FALSE;
    boolean_list(pn_1207_alacak_hesap):= FALSE;

    boolean_list(pn_1207_alis_buyuk_satis_1):= FALSE;
    boolean_list(pn_1207_alis_kucuk_satis_1):= FALSE;
    boolean_list(pn_1207_alis_buyuk_satis_2):= FALSE;
    boolean_list(pn_1207_alis_kucuk_satis_2):= FALSE;
    boolean_list(pn_1207_lc_fc_1):= FALSE;
    boolean_list(pn_1207_lc_fc_2):= FALSE;
    boolean_list(pn_1207_fc_lc_1):= FALSE;
    boolean_list(pn_1207_fc_lc_2):= FALSE;
    boolean_list(pn_1207_fc_fc_1):= FALSE;
    boolean_list(pn_1207_fc_fc_2):= FALSE;
    boolean_list(pn_1207_alacak_dk_1):= FALSE;
    boolean_list(pn_1207_alacak_dk_2):= FALSE;
    boolean_list(pn_1207_BORC_CASH_GL_FC_FC):= FALSE;
    boolean_list(pn_1207_BORC_CASH_GL_LC_FC):= FALSE;

/* islem bilgisi detaylari alinir */
     if islem_cursor%isopen then
       close islem_cursor;
     end if;

         open islem_cursor;
        fetch islem_cursor into
               ls_urun_tur_kod,
               ls_urun_sinif_kod,
               varchar_list(pn_1207_borc_hesap_tipi),
               varchar_list(pn_1207_alacak_hesap_tipi),
               varchar_list(pn_1207_mborclu_hesap_no),
               varchar_list(pn_1207_malacak_hesap_no),
               ls_alis_doviz_kodu,
               ls_satis_doviz_kodu,
               ln_alis_tutari    ,
               ln_satis_tutari   ,
               ln_borclu_hesap_no  ,
               ls_borclu_hesap_sube_kodu,
               ln_alacak_hesap_no  ,
               ls_alacak_hesap_sube_kodu,
               ls_banka_aciklama ,
               ls_islem_sube_kodu,
               ln_alis_musteri,
               ln_satis_musteri ,
               ln_rezervasyon_no,
               ln_alis_kuru,
               ln_satis_kuru,
               varchar_list(pn_1207_borc_istatistik_kodu),
               varchar_list(pn_1207_alacak_istatistik_kodu),
               varchar_list(pn_1207_mborc_hesap_tipi),
               varchar_list(pn_1207_malacak_hesap_tipi),
               ls_debit_gl_no,
               ls_credit_gl_no ,
               ls_kur_tipi,
               ls_rez_tip ;

       close islem_cursor;

        if nvl(ln_rezervasyon_no,0) = 0 then
        --sevalb 300407
              if ls_kur_tipi = 'COMMERCIAL' then
                   -- B-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches 
                   if  (ls_urun_tur_kod in ('ACC-CASH') and ls_urun_sinif_kod not in ('FC-LC'))   or
                          (ls_urun_tur_kod in ('CASH-ACC') and ls_urun_sinif_kod not in ('LC-FC'))   or
                          ls_urun_tur_kod in ('CASH-CASH')   then

                         ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,2,null,null,'O','A', ls_islem_bolum_kodu);
                        ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,2,null,null,'O','S', ls_islem_bolum_kodu);
                   elsif  (ls_urun_tur_kod in ('ACC-CASH') and ls_urun_sinif_kod in ('FC-LC'))   or  (ls_urun_tur_kod in ('CASH-ACC') and ls_urun_sinif_kod in ('LC-FC'))   then
                          ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_islem_bolum_kodu);
                          ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_islem_bolum_kodu);
                   else
                          ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'O','A', ls_islem_bolum_kodu);
                          ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S', ls_islem_bolum_kodu);
                    end if;

              else
                     if ls_urun_tur_kod in('ACC-CASH','CASH-ACC','CASH-CASH') then
                    ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,2,null,null,'N','A', ls_islem_bolum_kodu);
                    ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,2,null,null,'N','S', ls_islem_bolum_kodu);
                  else
                      ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                      ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','S', ls_islem_bolum_kodu);
                  end if;
                end if;
              -- E-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
            --sevalb 300407 asagidaki kisim kapatildi.
            /*if ls_urun_sinif_kod = 'FC-FC' then
            --NB Bid
                ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'N','A');
                ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','S');
            else
            -- maliyet kurlari
                ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,3,null,null,'N','A');
                ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,3,null,null,'N','S');
            end if;
            */
        else
            if ls_rez_tip = 'NON-CASH'
            then
                pkg_kur_rezervasyon.Rezervasyon_Bilgisi_Al(ln_rezervasyon_no,
                                                            ln_alis_kuru_rez,
                                                            ln_satis_kuru_rez ,
                                                            ln_maliyet_alis_kuru ,
                                                            ln_maliyet_satis_kuru ,
                                                            pkg_muhasebe.banka_tarihi_bul,
                                                            ls_islem_sube_kodu
                                                            );
            end if;
            if ls_rez_tip = 'CASH'
            then
                select DOVIZ_KODU, MUSTERI_KURU, BOUGHT_CY, SOLD_CY, ISLEM_SEKLI
                into ls_dvz,ln_must_kur,is_b_cy,ls_s_cy, ls_islem_sekli
                from cbs_ef_kur_rezervasyon
                 where TARIH=pkg_muhasebe.banka_tarihi_bul
                   and SUBE_KODU=pkg_baglam.bolum_kodu
                   and rezervasyon_no=ln_rezervasyon_no;


                ln_satis_kuru_rez:= ln_must_kur;
                ln_satis_kuru_rez:= ln_alis_kuru_rez;
                -- B-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
                if ls_islem_sekli = 'ALIS'
                then
                    ln_maliyet_alis_kuru:=
                          pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                    ln_maliyet_satis_kuru:=null;
                end if;
                if ls_islem_sekli = 'SATIS'
                then
                    ln_maliyet_alis_kuru:=null;
                    ln_maliyet_satis_kuru:=
                          pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                end if;
                if ls_islem_sekli = 'ARBITRAJ'
                then
                    ln_maliyet_alis_kuru:=
                          pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                    ln_maliyet_satis_kuru:=
                          pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                end if;
            end if;
        end if;

            if ls_urun_sinif_kod = 'FC-FC' then
                --sevalb 300407 asagidaki kisim kapatildi.
                 if ls_kur_tipi = 'COMMERCIAL' then
                        if ls_urun_tur_kod in('ACC-CASH','CASH-ACC','CASH-CASH') then
                         ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,2,null,null,'N','A', ls_islem_bolum_kodu);
                        ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,2,null,null,'N','S', ls_islem_bolum_kodu);
                    else
                         ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                        ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','S', ls_islem_bolum_kodu);
                    end if;
                 else
                         if ls_urun_tur_kod in('ACC-CASH','CASH-ACC','CASH-CASH') then
                        ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,2,null,null,'N','A', ls_islem_bolum_kodu);
                        ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,2,null,null,'N','S', ls_islem_bolum_kodu);
                     else
                         ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                        ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','S', ls_islem_bolum_kodu);
                     end if;
                   end if;
                --ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,3,null,null,'N','A');
                --ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,3,null,null,'N','S');
            ELSIF ls_urun_sinif_kod = 'FC-LC' THEN
            ln_maliyet_alis_kuru:= pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                    ln_maliyet_satis_kuru:= NULL;
          ln_alis_kuru :=  ln_maliyet_alis_kuru ;
      ELSE
            ln_maliyet_alis_kuru:= NULL;
          ln_maliyet_satis_kuru:= pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','A', ls_islem_bolum_kodu);
                    ln_satis_kuru := ln_maliyet_satis_kuru ;
            end if;
            -- E-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
/**** varchar list ****/
   pkg_parametre.deger('1207_FIS_ACIKLAMA',ls_fis_aciklama);

   varchar_list(pn_1207_fis_aciklama)             := ls_fis_aciklama ;
   varchar_list(pn_1207_banka_aciklama)         := ls_banka_aciklama;
   varchar_list(pn_1207_musteri_aciklama)       := ls_banka_aciklama; --ls_musteri_aciklama;
   varchar_list(pn_1207_referans)                     := NVL(to_char(ln_borclu_hesap_no),'.');

   varchar_list(pn_1207_satis_doviz_kod )         := ls_satis_doviz_kodu;
   varchar_list(pn_1207_alacak_hesap_sube_kodu) := ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1207_alacak_hesap_no)        := to_char(ln_alacak_hesap_no);

   varchar_list(pn_1207_alis_doviz_kod )         := ls_alis_doviz_kodu;
   varchar_list(pn_1207_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
   varchar_list(pn_1207_borclu_hesap_no)        := to_char(ln_borclu_hesap_no);
   varchar_list(pn_1207_islem_sube_kodu)           := ls_islem_sube_kodu;

  -- hs,20100118, for outlet
  if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1207_borclu_hesap_sube_kodu)) = 'H' then
      pkg_parametre.deger('G_DK_FC_CASH_GL',      varchar_list(pn_1207_B_OUTLET_CASH_GL));
  else
      pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1207_B_OUTLET_CASH_GL));
  end if;
  if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1207_alacak_hesap_sube_kodu)) = 'H' then
      pkg_parametre.deger('G_DK_FC_CASH_GL',      varchar_list(pn_1207_A_OUTLET_CASH_GL));
  else
      pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1207_A_OUTLET_CASH_GL));
  end if;
  -- hs,20100118, for outlet

/**** number list ****/
   number_list(pn_1207_alis_tutar)      := ln_alis_tutari ;
   number_list(pn_1207_alis_tl_tutari  ) := pkg_kur.yuvarla(pkg_genel.LC_AL , ln_alis_tutari*ln_alis_kuru);

----------------- ROUNDING CHANGES -----------------
    ln_rounded := pkg_tutar.rounding(number_list(pn_1207_alis_tutar));--  CQ516 Roundings KonstantinJ 28052014

    number_list(pn_1207_alis_tutar_r):= number_list(pn_1207_alis_tutar);
    number_list(pn_1207_alis_tutar_a_r):= 0;
    number_list(pn_1207_alis_tutar_b_r):= 0;

    if ln_rounded > number_list(pn_1207_alis_tutar)
    then
        number_list(pn_1207_alis_tutar_a_r):= ln_rounded - number_list(pn_1207_alis_tutar) ;
        number_list(pn_1207_alis_tutar_r):= ln_rounded;
    else
        number_list(pn_1207_alis_tutar_b_r):= number_list(pn_1207_alis_tutar)-ln_rounded ;
        number_list(pn_1207_alis_tutar_r):= ln_rounded;
    end if;

    ln_rounded := pkg_tutar.rounding(number_list(pn_1207_alis_tl_tutari));--  CQ516 Roundings KonstantinJ 28052014

    number_list(pn_1207_alis_tl_tutari_r):= number_list(pn_1207_alis_tl_tutari);
    number_list(pn_1207_alis_tl_tutari_a_r):= 0;
    number_list(pn_1207_alis_tl_tutari_b_r):= 0;

    if ln_rounded > number_list(pn_1207_alis_tl_tutari)
    then
        number_list(pn_1207_alis_tl_tutari_a_r):= ln_rounded - number_list(pn_1207_alis_tl_tutari) ;
        number_list(pn_1207_alis_tl_tutari_r):= ln_rounded;
    else
        number_list(pn_1207_alis_tl_tutari_b_r):= number_list(pn_1207_alis_tl_tutari)-ln_rounded ;
        number_list(pn_1207_alis_tl_tutari_r):= ln_rounded;
    end if;
----------------- ROUNDING CHANGES -----------------

   number_list(pn_1207_alis_kur)          := ln_alis_kuru;

   number_list(pn_1207_satis_tutar  )   := ln_satis_tutari ;
   number_list(pn_1207_satis_tl_tutari) := pkg_kur.yuvarla(pkg_genel.LC_AL ,ln_satis_tutari * ln_satis_kuru);

----------------- ROUNDING CHANGES -----------------
    ln_rounded := pkg_tutar.rounding(number_list(pn_1207_satis_tutar));--  CQ516 Roundings KonstantinJ 28052014

    number_list(pn_1207_satis_tutar_r):= number_list(pn_1207_satis_tutar);
    number_list(pn_1207_satis_tutar_b_r):= 0;
    number_list(pn_1207_satis_tutar_a_r):= 0;

    if ln_rounded > number_list(pn_1207_satis_tutar)
    then
        number_list(pn_1207_satis_tutar_b_r):= ln_rounded - number_list(pn_1207_satis_tutar) ;
        number_list(pn_1207_satis_tutar_r):= ln_rounded;
    else
        number_list(pn_1207_satis_tutar_a_r):= number_list(pn_1207_satis_tutar)-ln_rounded ;
        number_list(pn_1207_satis_tutar_r):= ln_rounded;
    end if;

    ln_rounded := pkg_tutar.rounding(number_list(pn_1207_satis_tl_tutari));--  CQ516 Roundings KonstantinJ 28052014

    number_list(pn_1207_satis_tl_tutari_r):= number_list(pn_1207_satis_tl_tutari);
    number_list(pn_1207_satis_tl_tutari_b_r):= 0;
    number_list(pn_1207_satis_tl_tutari_a_r):= 0;

    if ln_rounded > number_list(pn_1207_satis_tl_tutari)
    then
        number_list(pn_1207_satis_tl_tutari_b_r):= ln_rounded - number_list(pn_1207_satis_tl_tutari) ;
        number_list(pn_1207_satis_tl_tutari_r):= ln_rounded;
    else
        number_list(pn_1207_satis_tl_tutari_a_r):= number_list(pn_1207_satis_tl_tutari)-ln_rounded ;
        number_list(pn_1207_satis_tl_tutari_r):= ln_rounded;
    end if;
----------------- ROUNDING CHANGES -----------------

   number_list(pn_1207_satis_kur)         := ln_satis_kuru;
   number_list(pn_1207_alis_satis_fark_tutari ) := pkg_kur.yuvarla(pkg_genel.LC_AL ,abs( number_list(pn_1207_alis_tl_tutari  ) - number_list(pn_1207_satis_tl_tutari))) ;


/* kosul atamalari */
        if ls_urun_tur_kod in ('CASH-ACC','CASH-CASH','ACC-CASH')
        then
            varchar_list(pn_1207_referans):= '.';
            if ls_urun_sinif_kod = 'FC-FC'  then
                  boolean_list(pn_1207_fc_fc_2) :=true;
            elsif ls_urun_sinif_kod = 'FC-LC'  then
                  boolean_list(pn_1207_fc_lc_2) := true;
            elsif ls_urun_sinif_kod = 'LC-FC'  then
               boolean_list(pn_1207_lc_fc_2):=true;
            end if;

            if  number_list(pn_1207_alis_tl_tutari  ) >= number_list(pn_1207_satis_tl_tutari) then
                boolean_list(pn_1207_alis_buyuk_satis_2) := true;
            else
                boolean_list(pn_1207_alis_kucuk_satis_2) := true;
            end if;
/*
            if ls_urun_sinif_kod in ('FC-FC','LC-FC')
            then
                boolean_list(pn_1207_alacak_dk_2) := true;
            else
                boolean_list(pn_1207_alacak_dk_3) := true;
            end if;

            if ls_urun_sinif_kod in ('FC-FC','FC-LC')
            then
                boolean_list(pn_1207_BORC_CASH_GL_FC_FC) := true;
            end if;

            if ls_urun_sinif_kod in ('LC-FC')
            then
                boolean_list(pn_1207_BORC_CASH_GL_LC_FC) := true;
            end if;
*/
            if ls_urun_tur_kod in ('CASH-CASH','ACC-CASH')
            then
                if ls_urun_sinif_kod in ('FC-FC','LC-FC')
                then
                    boolean_list(pn_1207_alacak_dk_2) := true;
                else
                    boolean_list(pn_1207_alacak_dk_3) := true;
                end if;

            end if;

            if ls_urun_tur_kod in ('CASH-ACC','CASH-CASH')
            then
                if ls_urun_sinif_kod in ('FC-FC','FC-LC')
                then
                    boolean_list(pn_1207_BORC_CASH_GL_FC_FC) := true;
                end if;

                if ls_urun_sinif_kod in ('LC-FC')
                then
                    boolean_list(pn_1207_BORC_CASH_GL_LC_FC) := true;
                end if;
            end if;

            if ls_urun_tur_kod in ('ACC-CASH')
            then
                 boolean_list(pn_1207_borc_hesap) := true;
            end if;

            if ls_urun_tur_kod in ('CASH-ACC')
            then
                 boolean_list(pn_1207_alacak_hesap) := true;
            end if;
        else
            if ls_urun_sinif_kod = 'FC-FC'  then
                  boolean_list(pn_1207_fc_fc_1) :=true;
            elsif ls_urun_sinif_kod = 'FC-LC'  then
                  boolean_list(pn_1207_fc_lc_1) := true;
            elsif ls_urun_sinif_kod = 'LC-FC'  then
               boolean_list(pn_1207_lc_fc_1):=true;
            end if;

            if ls_debit_gl_no is not null then
                boolean_list(pn_1207_borc_dk) := true;
            else
             boolean_list(pn_1207_borc_hesap) := true;
            end if;

            if    ls_credit_gl_no is not null then
                boolean_list(pn_1207_alacak_dk_1) := true;
            else
             boolean_list(pn_1207_alacak_hesap) := true;
            end if;

            if  number_list(pn_1207_alis_tl_tutari  ) >= number_list(pn_1207_satis_tl_tutari) then
                boolean_list(pn_1207_alis_buyuk_satis_1) := true;
            else
                boolean_list(pn_1207_alis_kucuk_satis_1) := true;
            end if;
        end if;
   log_at('YERZHAN',varchar_list(pn_1207_A_OUTLET_CASH_GL),varchar_list(pn_1207_B_OUTLET_CASH_GL));
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            ls_fis_aciklama);

    pkg_muhasebe.muhasebelestir(ln_fis_no);

  --sevalb 110407 asagidaki kasa kontrolleri  eklendi.
  if ls_urun_tur_kod in ('ACC-CASH','CASH-ACC','CASH-CASH') then
         Pkg_Tx1601.Muhasebelesme(pn_islem_no,1207) ;
  end if;

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '448' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

 End;
----------------------------------------------------------------------------------------------------------------------------------------------------------------
-- B-O-M ErkinZu CQ5232 11.10.2016. Based on return value of this function, different titles will 
-- be printed on cash slip of CBS_RAP_CASHFX_SLIP_ARB
Function Sf_Define_Currency(pn_islem_no number) return number
is
 ls_ret   number;
 ls_alis_dvz    varchar2(3);
 ls_satis_dvz    varchar2(3);
Begin
 select ARB_DVZ_1,ARB_DVZ_2
 into ls_alis_dvz, ls_satis_dvz
 from CBS_VW_RAP_CASH_SLIP
 where tx_no = pn_islem_no;
 
 if nvl(ls_alis_dvz,'XXX') = pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') <> pkg_genel.LC_al
 then
  ls_ret := 1; 
 elsif nvl(ls_alis_dvz,'XXX') <> pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') = pkg_genel.LC_al
 then
  ls_ret := 2;
 else
  ls_ret := 3;
 end if;

 return ls_ret; 
End; 
-- E-O-M ErkinZu CQ5232 11.10.2016. Based on return value of this function, different titles will 
-- be printed on cash slip of CBS_RAP_CASHFX_SLIP_ARB
-----------------------------------------------------------------------------------------------------
Function Sf_Baslik_Aciklama(pn_islem_no number) return varchar2
is
 ls_ret   varchar2(200);
 ls_alis_dvz    varchar2(3);
 ls_satis_dvz    varchar2(3);
Begin
 select ARB_DVZ_1,ARB_DVZ_2
 into ls_alis_dvz, ls_satis_dvz
 from CBS_VW_RAP_CASH_SLIP
 where tx_no = pn_islem_no;

 -- B-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for slip main title to be printed in kg lang
 if nvl(ls_alis_dvz,'XXX') = pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') <> pkg_genel.LC_al
 then
  ls_ret := PKG_SOA_COMMON.text_translation('FX SOLD SLIP','KGZ')||'/';
 elsif nvl(ls_alis_dvz,'XXX') <> pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') = pkg_genel.LC_al
 then
  ls_ret := PKG_SOA_COMMON.text_translation('FX BOUGHT SLIP','KGZ')||'/';
 else
  ls_ret := PKG_SOA_COMMON.text_translation('FX ARBITRAGE SLIP','KGZ')||'/';
 end if;
 -- E-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for slip main title to be printed in kg lang
 return ls_ret;
End ;
--------------------------------------------------------------------------------
Function Sf_Baslik_Aciklama2(pn_islem_no number) return varchar2
is
 ls_ret   varchar2(200);
 ls_alis_dvz    varchar2(3);
 ls_satis_dvz    varchar2(3);
Begin
 select ARB_DVZ_1,ARB_DVZ_2
 into ls_alis_dvz, ls_satis_dvz
 from CBS_VW_RAP_CASH_SLIP
 where tx_no = pn_islem_no;
 
 -- B-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for slip main title to be printed in ru lang
 if nvl(ls_alis_dvz,'XXX') = pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') <> pkg_genel.LC_al
 then
  ls_ret := PKG_SOA_COMMON.text_translation('FX SOLD SLIP','RUS');
 elsif nvl(ls_alis_dvz,'XXX') <> pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') = pkg_genel.LC_al
 then
  ls_ret := PKG_SOA_COMMON.text_translation('FX BOUGHT SLIP','RUS');
 else
  ls_ret := PKG_SOA_COMMON.text_translation('FX ARBITRAGE SLIP','RUS');
  end if;
  -- E-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for slip main title to be printed in ru lang
 return ls_ret;
End ;
--------------------------------------------------------------------------------
Function Sf_Doviz_Aciklama_1(pn_islem_no number) return varchar2
is
 ls_ret   varchar2(200);
 ls_alis_dvz    varchar2(3);
 ls_satis_dvz    varchar2(3);
Begin
 select ARB_DVZ_1,ARB_DVZ_2
 into ls_alis_dvz, ls_satis_dvz
 from CBS_VW_RAP_CASH_SLIP
 where tx_no = pn_islem_no;

 -- B-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for title to be properly printed based on sold and bought currency
 if nvl(ls_alis_dvz,'XXX') = pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') <> pkg_genel.LC_al
 then
  ls_ret :=
PKG_SOA_COMMON.text_translation('Local Currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Local Currency','RUS');
 elsif nvl(ls_alis_dvz,'XXX') <> pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') = pkg_genel.LC_al
 then
  ls_ret :=
PKG_SOA_COMMON.text_translation('Foreign currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Foreign currency','RUS');
 else
  ls_ret :=
PKG_SOA_COMMON.text_translation('Foreign currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Foreign currency','RUS');
 end if;
 -- E-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for title to be properly printed based on sold and bought currency

 return ls_ret;
End ;
--------------------------------------------------------------------------------
Function Sf_Doviz_Aciklama_2(pn_islem_no number) return varchar2
is
 ls_ret   varchar2(200);
 ls_alis_dvz    varchar2(3);
 ls_satis_dvz    varchar2(3);
Begin
 select ARB_DVZ_1,ARB_DVZ_2
 into ls_alis_dvz, ls_satis_dvz
 from CBS_VW_RAP_CASH_SLIP
 where tx_no = pn_islem_no;

 -- B-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for title to be properly printed based on sold and bought currency
 if nvl(ls_alis_dvz,'XXX') = pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') <> pkg_genel.LC_al
 then
  ls_ret :=
PKG_SOA_COMMON.text_translation('Foreign currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Foreign currency','RUS');
 elsif nvl(ls_alis_dvz,'XXX') <> pkg_genel.LC_al and nvl(ls_satis_dvz,'XXX') = pkg_genel.LC_al
 then
  ls_ret :=
PKG_SOA_COMMON.text_translation('Local Currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Local Currency','RUS');
 else
  ls_ret :=
PKG_SOA_COMMON.text_translation('Foreign currency','KGZ')||' / '||PKG_SOA_COMMON.text_translation('Foreign currency','RUS');
 end if;
 -- E-O-M ErkinZu CQ5232 11.10.2016. Changed values for ls_ret variable for title to be properly printed based on sold and bought currency
 return ls_ret;
End ;
--------------------------------------------------------------------------------
BEGIN
    pn_1207_alacak_hesap_tipi :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_HESAP_TIPI');
    pn_1207_borc_hesap_tipi :=pkg_muhasebe.parametre_index_bul('1207_BORC_HESAP_TIPI');
    pn_1207_mborclu_hesap_no :=pkg_muhasebe.parametre_index_bul('1207_MBORCLU_HESAP_NO');
    pn_1207_malacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1207_MALACAK_HESAP_NO');
    pn_1207_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1207_MUSTERI_ACIKLAMA');
    pn_1207_referans :=pkg_muhasebe.parametre_index_bul('1207_REFERANS');
    pn_1207_satis_doviz_kod :=pkg_muhasebe.parametre_index_bul('1207_SATIS_DOVIZ_KOD');
    pn_1207_satis_kur :=pkg_muhasebe.parametre_index_bul('1207_SATIS_KUR');
    pn_1207_satis_tl_tutari :=pkg_muhasebe.parametre_index_bul('1207_SATIS_TL_TUTARI');
    pn_1207_satis_tutar :=pkg_muhasebe.parametre_index_bul('1207_SATIS_TUTAR');
    pn_1207_alacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_HESAP_NO');
    pn_1207_alacak_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_HESAP_SUBE_KODU');
    pn_1207_alacak_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_ISTATISTIK_KODU');
    pn_1207_alis_doviz_kod :=pkg_muhasebe.parametre_index_bul('1207_ALIS_DOVIZ_KOD');
    pn_1207_alis_kur :=pkg_muhasebe.parametre_index_bul('1207_ALIS_KUR');
    pn_1207_alis_satis_fark_tutari :=pkg_muhasebe.parametre_index_bul('1207_ALIS_SATIS_FARK_TUTARI');
    pn_1207_alis_tl_tutari :=pkg_muhasebe.parametre_index_bul('1207_ALIS_TL_TUTARI');
    pn_1207_alis_tutar :=pkg_muhasebe.parametre_index_bul('1207_ALIS_TUTAR');
    pn_1207_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1207_BANKA_ACIKLAMA');
    pn_1207_borclu_hesap_no :=pkg_muhasebe.parametre_index_bul('1207_BORCLU_HESAP_NO');
    pn_1207_borclu_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1207_BORCLU_HESAP_SUBE_KODU');
    pn_1207_A_OUTLET_CASH_GL :=pkg_muhasebe.parametre_index_bul('1207_A_OUTLET_CASH_GL');
    pn_1207_B_OUTLET_CASH_GL :=pkg_muhasebe.parametre_index_bul('1207_B_OUTLET_CASH_GL');
    pn_1207_borc_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1207_BORC_ISTATISTIK_KODU');
    pn_1207_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1207_FIS_ACIKLAMA');
    pn_1207_islem_sube_kodu :=pkg_muhasebe.parametre_index_bul('1207_ISLEM_SUBE_KODU');
    pn_1207_mborc_hesap_tipi :=pkg_muhasebe.parametre_index_bul('1207_MBORC_HESAP_TIPI');
    pn_1207_malacak_hesap_tipi :=pkg_muhasebe.parametre_index_bul('1207_MALACAK_HESAP_TIPI');
    pn_1207_alacak_hesap :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_HESAP');
    pn_1207_borc_dk :=pkg_muhasebe.parametre_index_bul('1207_BORC_DK');
    pn_1207_borc_hesap :=pkg_muhasebe.parametre_index_bul('1207_BORC_HESAP');

    pn_1207_alis_kucuk_satis_1 :=pkg_muhasebe.parametre_index_bul('1207_ALIS_KUCUK_SATIS_1');
    pn_1207_alis_kucuk_satis_2 :=pkg_muhasebe.parametre_index_bul('1207_ALIS_KUCUK_SATIS_2');

    pn_1207_alis_buyuk_satis_1 :=pkg_muhasebe.parametre_index_bul('1207_ALIS_BUYUK_SATIS_1');
    pn_1207_alis_buyuk_satis_2 :=pkg_muhasebe.parametre_index_bul('1207_ALIS_BUYUK_SATIS_2');

    pn_1207_fc_fc_1 :=pkg_muhasebe.parametre_index_bul('1207_FC_FC_1');
    pn_1207_fc_fc_2 :=pkg_muhasebe.parametre_index_bul('1207_FC_FC_2');

    pn_1207_lc_fc_1 :=pkg_muhasebe.parametre_index_bul('1207_LC_FC_1');
    pn_1207_lc_fc_2 :=pkg_muhasebe.parametre_index_bul('1207_LC_FC_2');

    pn_1207_fc_lc_1 :=pkg_muhasebe.parametre_index_bul('1207_FC_LC_1');
    pn_1207_fc_lc_2 :=pkg_muhasebe.parametre_index_bul('1207_FC_LC_2');

    pn_1207_alacak_dk_1 :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_DK_1');
    pn_1207_alacak_dk_2 :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_DK_2');
    pn_1207_alacak_dk_3 :=pkg_muhasebe.parametre_index_bul('1207_ALACAK_DK_3');

    pn_1207_BORC_CASH_GL_FC_FC :=pkg_muhasebe.parametre_index_bul('1207_BORC_CASH_GL_FC_FC');
    pn_1207_BORC_CASH_GL_LC_FC :=pkg_muhasebe.parametre_index_bul('1207_BORC_CASH_GL_LC_FC');

    pn_1207_alis_tutar_R :=pkg_muhasebe.parametre_index_bul('1207_alis_tutar_R');
    pn_1207_alis_tutar_A_R :=pkg_muhasebe.parametre_index_bul('1207_alis_tutar_A_R');
    pn_1207_alis_tutar_B_R :=pkg_muhasebe.parametre_index_bul('1207_alis_tutar_B_R');
    pn_1207_ALIS_TL_TUTARI_R :=pkg_muhasebe.parametre_index_bul('1207_ALIS_TL_TUTARI_R');
    pn_1207_ALIS_TL_TUTARI_A_R :=pkg_muhasebe.parametre_index_bul('1207_ALIS_TL_TUTARI_A_R');
    pn_1207_ALIS_TL_TUTARI_B_R :=pkg_muhasebe.parametre_index_bul('1207_ALIS_TL_TUTARI_B_R');

    pn_1207_satis_tutar_R :=pkg_muhasebe.parametre_index_bul('1207_satis_tutar_R');
    pn_1207_satis_tutar_A_R :=pkg_muhasebe.parametre_index_bul('1207_satis_tutar_A_R');
    pn_1207_satis_tutar_B_R :=pkg_muhasebe.parametre_index_bul('1207_satis_tutar_B_R');
    pn_1207_satis_TL_TUTARI_R :=pkg_muhasebe.parametre_index_bul('1207_satis_TL_TUTARI_R');
    pn_1207_satis_TL_TUTARI_A_R :=pkg_muhasebe.parametre_index_bul('1207_satis_TL_TUTARI_A_R');
    pn_1207_satis_TL_TUTARI_B_R :=pkg_muhasebe.parametre_index_bul('1207_satis_TL_TUTARI_B_R');
END ;
/

