create PACKAGE BODY PKG_TX1114 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  ln_adet 					number := 0;
  ln_cek_no 	 	        cbs_cek.cek_no%type;
  ln_cek_no_2 	 		    cbs_cek.cek_no%type;
  ln_cek_no_except          cbs_cek.cek_no%type;

  ln_cek_no_sub 	  				 cbs_cek.cek_no%type;
  ls_durum_kodu						 cbs_cek.durum_kodu%type;

   cursor cur_cek_islem is
     select Distinct cek_no ,decode(nvl(cek_no_2,0),0,cek_no,cek_no_2)
 	 from cbs_cek_islem
	 where tx_no = pn_islem_no;
  Begin
/* ilgili cek numarasinin durum kodu odeme yasakli kodu  = 'Y' olarak guncellenir. */
 if cur_cek_islem%isopen then
	   close cur_cek_islem;
 end if;

 open cur_cek_islem ;
  loop
  	  fetch cur_cek_islem into ln_cek_no , ln_cek_no_2  ;
    	exit when cur_cek_islem%notfound;
 		ln_cek_no_except := Sf_Cek_Aralik_Uygun(ln_cek_no ,ln_cek_no_2);
  end loop;

 End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_adet 					number := 0;
  ln_cek_no 	 	        cbs_cek.cek_no%type;
  ln_cek_no_2 	 		    cbs_cek.cek_no%type;
  ln_cek_no_except          cbs_cek.cek_no%type;

  ln_cek_no_sub 	  				 cbs_cek.cek_no%type;
  ls_durum_kodu						 cbs_cek.durum_kodu%type;


    cursor cur_cek_islem is
     select Distinct cek_no ,decode(nvl(cek_no_2,0),0,cek_no,cek_no_2)
 	 from cbs_cek_islem
	 where tx_no = pn_islem_no;

  	cursor cur_cek is
	 select cek_no,durum_kodu
	 from   cbs_cek
	 where cek_no between ln_cek_no and nvl(ln_cek_no_2,ln_cek_no)
	 for update of durum_kodu;

  Begin

/* ilgili cek numarasinin durum kodu odeme yasakli kodu  = 'Y' olarak guncellenir. */
 if cur_cek_islem%isopen then
	   close cur_cek_islem;
 end if;

 open cur_cek_islem ;
  loop
  	  fetch cur_cek_islem into ln_cek_no , ln_cek_no_2  ;
    	exit when cur_cek_islem%notfound;
 		ln_cek_no_except := Sf_Cek_Aralik_Uygun(ln_cek_no ,ln_cek_no_2);

		if cur_cek%isopen then
	   	  close cur_cek;
	    end if;

		open cur_cek ;
		  loop
		   fetch cur_cek into ln_cek_no_sub,ls_durum_kodu ;
		      exit when cur_cek%notfound;

		     update cbs_cek
			 set durum_kodu = 'A' ,
			 	 iptal_neden_kodu = null
			 where current of cur_cek;

		  end loop;
		  close cur_cek;
  end loop;
 close 	 cur_cek_islem ;

     update cbs_cek_islem
	 set durum_kodu = 'A'
	 where tx_no = pn_islem_no;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '145' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
 	    close cur_cek_islem;
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;
  End;
 FUNCTION  Sf_Cek_Aralik_Uygun(pn_cek_no CBS_CEK.cek_no%TYPE ,pn_cek_no_2 CBS_CEK.cek_no%TYPE ) RETURN CBS_CEK.cek_no%TYPE
   IS
	 ln_cek_no      CBS_CEK.cek_no%TYPE;
	 ls_durum_kodu	CBS_CEK.durum_kodu%TYPE;
	 uygun_durum_Degil	EXCEPTION;
	BEGIN

	   SELECT MIN(cek_no) ,MIN(durum_kodu)
	   INTO   ln_cek_no ,ls_durum_kodu
	   FROM   CBS_CEK
	   WHERE  cek_no BETWEEN  pn_cek_no AND DECODE(NVL(pn_cek_no_2,0),0,pn_cek_no,pn_cek_no_2) AND
	   		  durum_kodu  <>'I';

	  IF  NVL(ln_cek_no,0) <> 0 THEN
	    RAISE  uygun_durum_degil;
	  ELSE
	   RETURN 0;
	  END IF ;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN RETURN 0 ;
	  WHEN OTHERS THEN
   	  	RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '733' || Pkg_Hata.getDelimiter || ls_durum_kodu || Pkg_Hata.getDelimiter || TO_CHAR(ln_cek_no) ||Pkg_Hata.getDelimiter ||Pkg_Hata.getUCPOINTER);
    END   ;



Begin
 null;
END;
/

