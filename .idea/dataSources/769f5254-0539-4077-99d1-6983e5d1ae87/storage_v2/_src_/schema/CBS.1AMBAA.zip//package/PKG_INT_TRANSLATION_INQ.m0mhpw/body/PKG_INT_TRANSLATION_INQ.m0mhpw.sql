create PACKAGE BODY     PKG_INT_TRANSLATION_INQ IS

FUNCTION GetTranslate(ps_lang varchar2,  
                      ps_label_cd varchar2,
                      ps_label_type varchar2) RETURN varchar2
IS
ls_description varchar2(500 byte) := '000'; 
BEGIN
    
    select label_msg into ls_description 
              from corpint2.tbl_label 
                      where lang = upper(ps_lang) 
                            and label_cd = ps_label_cd
                            and label_type = ps_label_type;

    return ls_description;

EXCEPTION  
    when no_data_found then 
        return null;
    when others then 
         RAISE;
END;

FUNCTION GetErrorCode(ps_lang varchar2,  
                      ps_label_cd varchar2,
                      ps_label_type varchar2,
                      pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(500 byte) := '000'; 
BEGIN
    
   open pc_ref for
       select label_msg as name 
             from corpint2.tbl_label
                  where lang = upper(ps_lang) 
                        and label_cd = ps_label_cd
                        and label_type = ps_label_type;
                                           
    return ls_returncode;

EXCEPTION  
    when no_data_found then 
        return null;
    when others then  
         RAISE;
END;

END pkg_int_translation_inq;
/

