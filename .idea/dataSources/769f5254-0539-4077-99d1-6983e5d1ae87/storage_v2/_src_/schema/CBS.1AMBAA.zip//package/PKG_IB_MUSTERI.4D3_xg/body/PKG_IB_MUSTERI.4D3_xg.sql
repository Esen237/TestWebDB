create PACKAGE BODY     PKG_IB_MUSTERI IS
  --------------------------------------Fx Convert turn on/off---------------------------------------*/
  FUNCTION Switch_Fx_Convert(pn_musteri_no IN number, ps_durum IN varchar2) return varchar2 is
    ls_durum            varchar2(1);
    ls_branch           varchar2(3);
    ls_modul_tur_kod    varchar2(20);
    ls_urun_tur_kod     varchar2(20);
    ls_urun_sinif_kod   varchar2(20);
    ln_tx_no            number;
  begin
  
    log_at('CBS.PKG_IB_MUSTERI.SWITCH_FX_CONVERT()', pn_musteri_no, ps_durum);

    ls_durum := Pkg_Musteri.Sf_Musteri_Kodu_Al(pn_musteri_no);
    if ls_durum = 'A' then

        ln_tx_no := pkg_tx1001.Sf_Onay_Bekleyen_Varmi(0,pn_musteri_no,1001);
        if nvl(ln_tx_no,0) = 0 then
            begin
                ls_branch := Pkg_Musteri.Sf_Bolum_Kodu_Al(pn_musteri_no);
                ln_tx_no  := Pkg_Tx.islem_no_al;
                
                --pkg_baglam.yarat(ls_branch, '0');
                --Pkg_Musteri.Sp_Musteri_Guncel_Kaydi_Olus(pn_musteri_no, ln_tx_no);
                --update CBS_MUSTERI_GUNCELLENEN set fx_convert = ps_durum where tx_no = ln_tx_no; 
                 
                INSERT INTO CBS_MUSTERI_GUNCELLENEN(tx_no,
                                                    musteri_no,
                                                    musteri_tipi_kod,
                                                    dk_grup_kod,
                                                    isim,
                                                    ikinci_isim,
                                                    soyadi,
                                                    dogum_tarihi,
                                                    dogum_yeri,
                                                    dogum_il_kod,
                                                    cinsiyet_kod,
                                                    baba_adi,
                                                    anne_adi,
                                                    anne_kizlik_soyadi,
                                                    meslek_kod,
                                                    egitim_kod,
                                                    medeni_hal_kod,
                                                    ticari_unvan,
                                                    hesap_ucreti_f,
                                                    cek_karnesi_f,
                                                    personel_sicil_no,
                                                    yerlesim_kod,
                                                    ozel_kategori_kod,
                                                    vergi_muaf_kod,
                                                    vergi_dairesi_adi,
                                                    vergi_no,
                                                    tesvik_kod,
                                                    uyruk_kod,
                                                    kimlik_kod,
                                                    tc_kimlik_no,
                                                    nufus_cuzdani_seri_no,
                                                    pasaport_no,
                                                    ehliyet_belge_no,
                                                    il_kod,
                                                    ilce_kod,
                                                    mahalle_koy,
                                                    cilt_no,
                                                    aile_sira_no,
                                                    sira_no,
                                                    verildigi_yer,
                                                    verildigi_tarih,
                                                    sektor_kod,
                                                    finans_kod,
                                                    ticari_sicil_no,
                                                    extre_adres_kod,
                                                    serbest_bolge_izin_tarihi,
                                                    serbest_bolge_izin_no,
                                                    pazarlama_sorumlusu_sicil_no_1,
                                                    pazarlama_sorumlusu_sicil_no_2,
                                                    grup_kod,
                                                    bic_kod,
                                                    swift_mesaj_kod,
                                                    reuters_info_page,
                                                    reuters_dealing_kod,
                                                    yaratan_kullanici_kodu,
                                                    yaratildigi_tarih,
                                                    modul_tur_kod,
                                                    urun_tur_kod,
                                                    urun_sinif_kod,
                                                    eski_musteri_no,
                                                    sektor_alt1_kodu,
                                                    sektor_alt2_kodu,
                                                    rating_kodu,
                                                    bolum_kodu,
                                                    gecerlilik_tarihi,
                                                    vergi_daire_kodu,
                                                    durum_kodu,
                                                    vat_seri_no,
                                                    vat_sira_no,
                                                    okpo_code,
                                                    manager_name,
                                                    manager_surname,
                                                    manager_patronymic_name,
                                                    manager_country_code,
                                                    manager_resident_code,
                                                    second_manager_name,
                                                    vergi_zorunlumu,
                                                    sosyal_fon_no,
                                                    EKSTRE_UCRETI_ALINSIN,
                                                    working_basis,
                                                    patent_no,
                                                    patent_expiry_date,
                                                    legal_form_code,
                                                    external_acct_no,
                                                    lokal_unvan,
                                                    COMPANY_OF_THE_STAFF,
                                                    report_customer_type,
                                                    fx_convert,
                                                    risk_level_code,
                                                    risk_assesment_date,
                                                    isim_eng,
                                                    ikinci_isim_eng,
                                                    soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                                                    MANAGER_ID_TYPE,
                                                    MANAGER_PASSPORT_NUMBER,
                                                    MANAGER_PASS_ISSUE_DATE,
                                                    MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                                    MANAGER_PASS_ISSUE_PLACE,
                                                    MANAGER_PASSPORT_SERIES, -- end  CQ578 KonstantinJ  03.04.2014 addtitional fields
                                                    UNIVERSITY_CODE,
                                                    CAMPUS_ID_NO, --CQ5273 MederT 23122015
                                                    State_share,  --KonstantinJ 08042016 CQ5223 State_Share addition
                                                    DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                                                    COMPANY_OF_THE_STAFF_2,	--CQ4960 ChyngyzO 15082016
                                                    COMPANY_OF_THE_STAFF_3,	--CQ4960 ChyngyzO 15082016
                                                    OPN_BY_THIRD_PERSON, --CQ5516 aisuluud 29092016
                                                    NOTIF_PACK,	--CBS113 nurzalata
                                                    AFFILIATED_ENTITIES) --CBS256 bahianab
                    SELECT ln_tx_no,
                           musteri_no,
                           musteri_tipi_kod,
                           dk_grup_kod,
                           isim,
                           ikinci_isim,
                           soyadi,
                           dogum_tarihi,
                           dogum_yeri,
                           dogum_il_kod,
                           cinsiyet_kod,
                           baba_adi,
                           anne_adi,
                           anne_kizlik_soyadi,
                           meslek_kod,
                           egitim_kod,
                           medeni_hal_kod,
                           ticari_unvan,
                           hesap_ucreti_f,
                           cek_karnesi_f,
                           personel_sicil_no,
                           yerlesim_kod,
                           ozel_kategori_kod,
                           vergi_muaf_kod,
                           vergi_dairesi_adi,
                           vergi_no,
                           tesvik_kod,
                           uyruk_kod,
                           kimlik_kod,
                           tc_kimlik_no,
                           nufus_cuzdani_seri_no,
                           pasaport_no,
                           ehliyet_belge_no,
                           il_kod,
                           ilce_kod,
                           mahalle_koy,
                           cilt_no,
                           aile_sira_no,
                           sira_no,
                           verildigi_yer,
                           verildigi_tarih,
                           sektor_kod,
                           finans_kod,
                           ticari_sicil_no,
                           extre_adres_kod,
                           serbest_bolge_izin_tarihi,
                           serbest_bolge_izin_no,
                           pazarlama_sorumlusu_sicil_no_1,
                           pazarlama_sorumlusu_sicil_no_2,
                           grup_kod,
                           bic_kod,
                           swift_mesaj_kod,
                           reuters_info_page,
                           reuters_dealing_kod,
                           yaratan_kullanici_kodu,
                           yaratildigi_tarih,
                           modul_tur_kod,
                           urun_tur_kod,
                           urun_sinif_kod,
                           eski_musteri_no,
                           sektor_alt1_kodu,
                           sektor_alt2_kodu,
                           rating_kodu,
                           bolum_kodu,
                           GECERLILIK_TARIHI,
                           VERGI_DAIRE_KODU,
                           durum_kodu,
                           vat_seri_no,
                           vat_sira_no,
                           okpo_code,
                           manager_name,
                           manager_surname,
                           manager_patronymic_name,
                           manager_country_code,
                           manager_resident_code,
                           second_manager_name,
                           vergi_zorunlumu,
                           sosyal_fon_no,
                           EKSTRE_UCRETI_ALINSIN,
                           working_basis,
                           patent_no,
                           patent_expiry_date,
                           legal_form_code,
                           external_acct_no,
                           lokal_unvan,
                           company_of_the_staff,
                           report_customer_type,
                           ps_durum,
                           risk_level_code,
                           risk_assesment_date,
                           isim_eng,
                           ikinci_isim_eng,
                           soyadi_eng, --SEVALB 1112012 6270_Automatic loading of customer information from CBS to Card system
                           MANAGER_ID_TYPE,
                           MANAGER_PASSPORT_NUMBER,
                           MANAGER_PASS_ISSUE_DATE,
                           MANAGER_PASS_EXPIRING_DATE, -- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                           MANAGER_PASS_ISSUE_PLACE,
                           MANAGER_PASSPORT_SERIES, -- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                           UNIVERSITY_CODE,
                           CAMPUS_ID_NO,													--CQ5273 MederT 23122015
                           State_share, --KonstantinJ 08042016 CQ5223 State_Share addition
                           DEFAULT_MOBILE_PHONE, --CQ5510 MederT 27072016
                           COMPANY_OF_THE_STAFF_2, --CQ4960 ChyngyzO 15082016
                           COMPANY_OF_THE_STAFF_3, --CQ4960 ChyngyzO 15082016
                           OPN_BY_THIRD_PERSON,	--CQ5516 aisuluud 29092016
                           NOTIF_PACK, --CBS113 nurzalata
                           AFFILIATED_ENTITIES	--CBS256 bahianab
                      FROM CBS_MUSTERI
                     WHERE musteri_no = pn_musteri_no;

                /* Basvuru adres bilgilerinin musteri adres tablosuna aktarilmasi */
                INSERT INTO CBS_MUSTERI_GUNCEL_ADRES(tx_no,
                                                     adres_kod,
                                                     adres,
                                                     semt,
                                                     il_kod,
                                                     posta_kod,
                                                     ulke_kod,
                                                     email,
                                                     tel_alan_kod,
                                                     tel_no,
                                                     gsm_alan_kod,
                                                     gsm_no,
                                                     fax_alan_kod,
                                                     fax_no,
                                                     ilk_gecerlilik_tarihi,
                                                     son_gecerlilik_tarihi,
                                                     ilce_kod,
                                                     yaratan_kullanici_kodu,
                                                     yaratildigi_tarih,
                                                     extre_adres_kod_f,
                                                     ISYERI_UNVANI,
                                                     ulke_tel_kod,
                                                     ulke_gsm_kod,
                                                     ulke_tel_kod_2,
                                                     tel_alan_kod_2,
                                                     tel_no_2,
                                                     ulke_tel_kod_3,
                                                     tel_alan_kod_3,
                                                     tel_no_3, --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                                                     ulke_gsm_kod_2,
                                                     gsm_alan_kod_2,
                                                     gsm_no_2,
                                                     ulke_gsm_kod_3,
                                                     gsm_alan_kod_3,
                                                     gsm_no_3,
                                                     EMAIL_FOR_CCARD_SYSTEM,
                                                     PHONE_EXTENSION_NO_1,
                                                     PHONE_EXTENSION_NO_2,
                                                     PHONE_EXTENSION_NO_3,
                                                     FAX_COUNTRY_CODE,
                                                     FAX_EXTENSION_NO,
                                                     EMERGENCY_CALL_PERSON,
                                                     EMERGENCY_TEL_AREA_CODE, --b-o-m KonstantinJ 10112015 CQ4731 credit card
                                                     EMERGENCY_TEL_PHONE_NO,
                                                     EMERGENCY_TEL_EXTENSION_NO)
                    --e-o-m KonstantinJ 10112015 CQ4731 credit card
                    SELECT ln_tx_no,
                           adres_kod,
                           adres,
                           semt,
                           il_kod,
                           posta_kod,
                           ulke_kod,
                           email,
                           tel_alan_kod,
                           tel_no,
                           gsm_alan_kod,
                           gsm_no,
                           fax_alan_kod,
                           fax_no,
                           ilk_gecerlilik_tarihi,
                           son_gecerlilik_tarihi,
                           ilce_kod,
                           yaratan_kullanici_kodu,
                           yaratildigi_tarih,
                           extre_adres_kod_f,
                           ISYERI_UNVANI,
                           ulke_tel_kod,
                           ulke_gsm_kod,
                           ulke_tel_kod_2,
                           tel_alan_kod_2,
                           tel_no_2,
                           ulke_tel_kod_3,
                           tel_alan_kod_3,
                           tel_no_3,					   --b-o-m sevalb 31012011 SDLC14229 additional adres fields
                           ulke_gsm_kod_2,
                           gsm_alan_kod_2,
                           gsm_no_2,
                           ulke_gsm_kod_3,
                           gsm_alan_kod_3,
                           gsm_no_3,
                           EMAIL_FOR_CCARD_SYSTEM,
                           PHONE_EXTENSION_NO_1,
                           PHONE_EXTENSION_NO_2,
                           PHONE_EXTENSION_NO_3,
                           FAX_COUNTRY_CODE,
                           FAX_EXTENSION_NO,
                           EMERGENCY_CALL_PERSON,
                           EMERGENCY_TEL_AREA_CODE, 				 --b-o-m KonstantinJ 10112015 CQ4731 credit card
                           EMERGENCY_TEL_PHONE_NO,
                           EMERGENCY_TEL_EXTENSION_NO
                      --e-o-m KonstantinJ 10112015 CQ4731 credit card
                      FROM CBS_MUSTERI_ADRES
                     WHERE musteri_no = pn_musteri_no;

                /* Basvuru dokuman bilgilerinin musteri dokuman tablosuna aktarilmasi */
                INSERT INTO CBS_MUSTERI_GUNCEL_DOKUMAN(tx_no, sira_no, dokuman_adi, alindi_kutusu_f, duzenlenme_tarihi, gecerlilik_tarihi, yaratan_kullanici_kodu, yaratildigi_tarih)
                    SELECT ln_tx_no, sira_no, dokuman_adi, alindi_kutusu_f, duzenlenme_tarihi, gecerlilik_tarihi, yaratan_kullanici_kodu, yaratildigi_tarih 
                      FROM CBS_MUSTERI_DOKUMAN
                     WHERE musteri_no = pn_musteri_no;

                /* Basvuru not bilgilerinin musteri not tablosuna aktarilmasi */
                INSERT INTO CBS_MUSTERI_GUNCEL_NOTLAR(tx_no, sira_no, alinan_notlar, giris_tarihi, kullanici_kodu, gorusme_bilgileri, gorusme_notu, katilanlar,
                                                      gorusme_tarihi, baslangic_saati, bitis_saati, yaratan_kullanici_kodu, yaratildigi_tarih, not_tipi)
                    SELECT ln_tx_no, sira_no, alinan_notlar, giris_tarihi, kullanici_kodu, gorusme_bilgileri, gorusme_notu, katilanlar,
                           gorusme_tarihi, baslangic_saati, bitis_saati, yaratan_kullanici_kodu, yaratildigi_tarih, not_tipi 
                      FROM CBS_MUSTERI_NOTLAR
                     WHERE musteri_no = pn_musteri_no;

                /* Basvuru ortaklik bilgilerinin musteri ortak tablosuna aktarilmasi */
                INSERT INTO CBS_MUSTERI_GUNCEL_ORTAKLIK(tx_no, sira_no, isim, orani, tutari, doviz_kod, tarih, ulke_kod, yaratan_kullanici_kodu, yaratildigi_tarih)
                    SELECT ln_tx_no, sira_no, isim, orani, tutari, doviz_kod, tarih, ulke_kod, yaratan_kullanici_kodu, yaratildigi_tarih
                      FROM CBS_MUSTERI_ORTAKLIK
                     WHERE musteri_no = pn_musteri_no;

                /* Contact bilgileri Sevalb 06022007 */
                INSERT INTO cbs_musteri_guncel_kontak(TX_NO, SIRA_NO, AD, SOYAD, EMAIL, WEB_SITE, TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD, GSM_NO, FAX_ALAN_KOD, FAX_NO)
                    SELECT ln_tx_no, SIRA_NO, AD, SOYAD, EMAIL, WEB_SITE, TEL_ALAN_KOD, TEL_NO, GSM_ALAN_KOD, GSM_NO, FAX_ALAN_KOD, FAX_NO 
                      FROM cbs_musteri_kontak
                     WHERE musteri_no = pn_musteri_no;

                /* Copy data for additional tab in MUSIZ  UrmatA 20150907 */
                INSERT INTO CBS_MUSTERI_GUNCEL_UPD_INF(TX_NO, activity, owners, results, update_date, create_user)
                    SELECT ln_tx_no, activity, owners, results, update_date, create_user
                      FROM CBS_MUSTERI_UPD_INF
                     WHERE musteri_no = pn_musteri_no;

                -- BOM Documents by third persons aisuluud CQ5516 21112016
                INSERT INTO CBS_CUST_BY_THIRD_PERS_MODIF(TX_NO, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT, OPENING_DATE, EXPIRY, EXPIRY_DATE, CBS_NO_OF_DOC, ACTIVE, DESCRIPTION, OPN_MNG)
                    SELECT DISTINCT ln_tx_no, TYPE_OF_DOCUMENT, NO_OF_DOCUMENT, OPENING_DATE, EXPIRY, EXPIRY_DATE, CBS_NO_OF_DOC, ACTIVE, DESCRIPTION, OPN_MNG 
                      FROM CBS_CUSTOMER_BY_THIRD_PERSONS
                     WHERE customer_no = pn_musteri_no;

                INSERT INTO cbs_doc_third_persons_modif(TX_NO, CBS_NO_OF_DOC, FIRSTNAME, MIDDLE_NAME, SURNAME)
                    SELECT ln_tx_no, CBS_NO_OF_DOC, FIRSTNAME, MIDDLE_NAME, SURNAME 
                      FROM CBS_CUSTOMER_BY_THIRD_PERSONS
                     WHERE customer_no = pn_musteri_no;
                -- EOM Documents by third persons aisuluud CQ5516 21112016   
            EXCEPTION
                when OTHERS then
                    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '105' || Pkg_Hata.getDelimiter ||  TO_CHAR(SQLCODE) ||SQLERRM || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
                    return -1;
            end;
        end if;
    elsif ls_durum = '1' then
        ln_tx_no := pkg_tx1001.Sf_Onay_Bekleyen_Varmi(0,pn_musteri_no,1001);
        Raise_application_error(-20100, pkg_hata.getucpointer || '813' || pkg_hata.getdelimiter || ln_tx_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        return -1;
    else
        Raise_application_error(-20100, pkg_hata.getucpointer || '812' || pkg_hata.getdelimiter || ln_tx_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
        return -1;
    end if;

    Pkg_Musteri.Sp_Musteri_Urun_Sinif_Al(pn_musteri_no, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod);
    --Pkg_Tx.islem_yarat(ln_tx_no, 1001, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, 0, Pkg_Baglam.Bolum_Kodu, 'KGS',pn_musteri_no, null, null);
    
    Pkg_Int_Api.create_transaction (ln_tx_no, 1001, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, 0, ls_branch, ls_branch, 7777, 'KGS', pn_musteri_no,null, null, 1);
    Pkg_Int_Api.process_transaction(ln_tx_no);
    commit;
    
    return get_fxconvert_status(pn_musteri_no);
  end;


  --------------------------------------Check Fx Convert status---------------------------------------*/

  FUNCTION get_fxconvert_status(pn_musteri_no IN number) return varchar2 is
      ls_fx_convert varchar2(1);
  begin      
    select nvl(fx_convert,'H')
    into ls_fx_convert
    from cbs_musteri
    where musteri_no = pn_musteri_no;
    return ls_fx_convert;
  end;



  --------------------------------------Check Debit card internet payment status---------------------------------------*/
  FUNCTION get_payment_status(pn_musteri_no IN number) return varchar2 is
      ls_db_status clob := get_clob_content(pn_musteri_no);
      substr_pos numeric;
      substr_1 varchar2(1);
  begin
     SELECT INSTR(ls_db_status, 'debitInternetPayments', 1) into substr_pos FROM DUAL;
     select substr(ls_db_status, substr_pos + 24, 1) into substr_1 from DUAL;
     select decode(substr_1, 's', 'X', substr_1) into substr_1 from DUAL;
      return substr_1;
  end;

  --------------------------------------Set Debit card internet payment status---------------------------------------*/
  FUNCTION set_payment_status(pn_musteri_no IN number, pn_user_id IN number, ps_durum_new IN varchar2) return varchar2 is

        ls_db_status clob;
        cust_info clob := get_clob_content(pn_musteri_no);
        product_form_new_tx_no number;
        product_form_old_tx_no varchar2(15);
        ps_durum_old varchar2(1) := get_payment_status(pn_musteri_no);
        ps_internet_payment varchar2(50);
        PRAGMA AUTONOMOUS_TRANSACTION;

  begin
      if ps_durum_old <> ps_durum_new then
          select (CBS.PKG_WP_MUSTERI.GETNEWTXNO)
          INTO    product_form_new_tx_no
          from dual;
          select regexp_substr(cust_info, '[^"]+', 1, 4) into product_form_old_tx_no from dual;
          select replace(cust_info, product_form_old_tx_no, product_form_new_tx_no) into cust_info from DUAL;
          select substr((select cbs.PKG_IB_MUSTERI.GET_CLOB_CONTENT(pn_musteri_no) from dual),
                            (SELECT INSTR((select cbs.PKG_IB_MUSTERI.GET_CLOB_CONTENT(pn_musteri_no) from dual),
                                          'debitInternetPayments', 1) FROM DUAL)-1, 27) into ps_internet_payment from DUAL;
          select replace(cust_info, ps_internet_payment
                  , '"debitInternetPayments":"' || to_char(ps_durum_new) || '"') into cust_info from DUAL;
          INSERT INTO webportal.tbl_customer_info (TX_NO, CUSTOMER_NO, CUSTOMER_INFO, CLASS_NAME, CREATED_BY)
              VALUES (product_form_new_tx_no, pn_musteri_no, cust_info, 'PRODUCTSFORM', pn_user_id);

          commit;
      end if;
      return get_payment_status(pn_musteri_no);
  end;

  FUNCTION get_clob_content(pn_musteri_no IN number) return clob is
      clob_content clob;
  begin
      select tbl.customer_info
      into clob_content
      from webportal.tbl_customer_info tbl
      where   tbl.CLASS_NAME = 'PRODUCTSFORM' AND
              tbl.CUSTOMER_NO = pn_musteri_no and
              tbl.tx_no in (select max(tx_no) from WEBPORTAL.tbl_customer_info) order by tbl.tx_no desc;
      return clob_content;
  end;
END;
/

