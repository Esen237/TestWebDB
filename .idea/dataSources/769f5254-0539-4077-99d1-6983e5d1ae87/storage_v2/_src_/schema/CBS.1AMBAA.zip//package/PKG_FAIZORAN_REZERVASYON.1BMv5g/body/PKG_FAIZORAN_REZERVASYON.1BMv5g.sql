create PACKAGE BODY     "PKG_FAIZORAN_REZERVASYON" IS
------------------------------------------------------------------------------------------------
 Function modul_tur_kod return varchar2
 is
 Begin
    return PKG_hesap.modul_tur_vadeli;
 End;
------------------------------------------------------------------------------------------------
 Function urun_tur_kod return varchar2
 is
 Begin
    return 'INTEREST';
 End;
------------------------------------------------------------------------------------------------
 Function urun_sinif_kod return varchar2
  is
 Begin
    return 'RESERVATION';
 End;
------------------------------------------------------------------------------------------------
 Procedure sp_isleme_at(pn_tx_no number,pn_internal_no number,pn_islem_kod number)
 is
 Begin
   insert into cbs_faizoran_rezervasyon_islem(
     tx_no,internal_no, tarih, sube_kodu, rezervasyon_no, musteri_no, islem_kod,
     durum_kodu, islem_sekli, doviz_kodu, tutar, vade_tarihi, faiz_oran,
     aciklama, marj_orani, modul_tur_kod, urun_tur_kod, urun_sinif_kod)
 select pn_tx_no ,internal_no, tarih, sube_kodu, rezervasyon_no,
     musteri_no, pn_islem_kod,durum_kodu, islem_sekli, doviz_kodu, tutar,
     vade_tarihi, faiz_oran,aciklama, marj_orani, modul_tur_kod, urun_tur_kod,
     urun_sinif_kod
 from cbs_faizoran_rezervasyon
 where internal_no = pn_internal_no ;
 End;
------------------------------------------------------------------------------------------------
 Function sf_islemde_kulanilmismi(pn_internal_no number )return number
 is
  ln_tx_no number := 0;
 Begin
    select min(a.tx_no)
   into ln_tx_no
   from cbs_faizoran_rezervasyonkullan a , cbs_islem b
   where internal_no =pn_internal_no and
     DURUM_kodu = 'ACIK' and
      a.tx_no = b.numara and
    b.durum = 'P' ;

   return  nvl(ln_tx_no,0);
 Exception when others then return 0;
 End;
------------------------------------------------------------------------------------------------
 Function rezervasyon_tutari( pn_internal_no number) return number
 is
  ln_tutar number := 0;
 Begin
     select nvl(tutar,0)
  into ln_tutar
  from  cbs_faizoran_rezervasyon
  where internal_no = pn_internal_no;

  return nvl(ln_tutar,0);

  Exception when others then return 0;

 End;
------------------------------------------------------------------------------------------------
Function kullanilan_tutar( pn_internal_no number) return number
is
 ln_tutar number := 0;
Begin
  select sum(nvl(a.tutar,0))
  into ln_tutar
  from cbs_faizoran_rezervasyonkullan a
   where internal_no =pn_internal_no and
     a.durum_kodu= 'ACIK';

   return nvl(ln_tutar,0) ;
 Exception when others then return 0;
End;
------------------------------------------------------------------------------------------------
 Function bakiye(pn_internal_no number) return number
 is
  ln_tutar number :=0 ;
 Begin
   ln_tutar :=  rezervasyon_tutari(pn_internal_no ) - kullanilan_tutar(pn_internal_no );

 return ln_tutar;
 End ;
------------------------------------------------------------------------------------------------
  Function kullanim_orani(pn_internal_no number) return number
 is
  ln_tutar number :=0 ;
  ln_acilis_tutar  number := 0;
 Begin
      select nvl(tutar,0)
  into ln_acilis_tutar
  from  cbs_faizoran_rezervasyon
  where internal_no = pn_internal_no;

  if nvl( ln_acilis_tutar,0) = 0 then
     return 0;
    else
      ln_tutar :=   100* ( (  nvl( kullanilan_tutar(pn_internal_no),0) ) /  nvl(ln_acilis_tutar,0)  );
  end if;
 return ln_tutar;
 End ;
------------------------------------------------------------------------------------------------
 Procedure Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO in number,
                                       pn_islem_numara in number,
            pn_TUTAR in number,
            pn_hesap_no number,
            pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
            ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
          )
 is
 ln_count number;
 ln_internal_no number;
 ln_musteri_no   number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;
 begin

 if nvl(pn_REZERVASYON_NO,0)  <> 0 then
  select count(*)
  into ln_count
  from  CBS_FAIZORAN_REZERVASYONKULLAN
  where tarih = pd_TARIH
    and sube_kodu = ps_SUBE_KODU
    and tx_no=pn_islem_numara;

  --Bu i?lemin kulland??? rezervasyon varsa sil
  --( ??lem M?sveddeeye her kaydedildi?inde eski rez.kullanim kayd? siliniyor.)
  if ln_count>0 then

    delete from CBS_FAIZORAN_REZERVASYONKULLAN
  where tarih = pd_TARIH
      and sube_kodu = ps_SUBE_KODU
      and tx_no=pn_islem_numara;

  end if;

   ln_internal_no := rezervasyon_internal_no(pn_rezervasyon_no,pd_tarih,ps_sube_kodu);
   if nvl(pn_hesap_no ,0) <> 0 then
     ln_musteri_no  :=pkg_hesap.HesaptanMusteriNoAl(pn_hesap_no);
    end if;

   insert into cbs_faizoran_rezervasyonkullan(tarih,sube_kodu,rezervasyon_no,tx_no,tutar,internal_no ,hesap_no,musteri_no ,DURUM_KODU)
   values(pd_tarih, ps_sube_kodu, pn_rezervasyon_no, pn_islem_numara, pn_tutar,ln_internal_no, pn_hesap_no ,ln_musteri_no  ,'ACIK');

  end if;
 exception
    when others then
       --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);
    null;
 end;
--------------------------------------------------------------------------------------
 Procedure Rezervasyon_Kullanim_Iptal(pn_islem_numara in number) is
 begin

 UPDATE  CBS_FAIZORAN_REZERVASYONKULLAN
 SET DURUM_KODU = 'IPTAL'
 where tx_no=pn_islem_numara;

 exception
    when others then
       --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);
    null;
 end;
 -------------------------------------------------------------------------------------
 Function Kur_Marj_Al( ps_doviz_kodu varchar2,pn_hesap_no number ,pn_gun_sayisi number default null) return number
 is
 ln_marj_orani number := 0;
 ln_gun number := 0;
 begin
    if pn_gun_sayisi is not null then
     ln_gun :=pn_gun_sayisi ;

     elsif nvl(pn_hesap_no,0) <> 0 then
    select vade_tarihi - valor_tarihi
    into ln_gun
    from cbs_vw_hesap_izleme
    where hesap_no = pn_hesap_no ;

    if ln_gun <0  then
       ln_gun := 0;
    end if;
  end if;

   select nvl(marj,0)
   into ln_marj_orani
   from cbs_faizoran_rezervasyon_marj
   where doviz_kodu=ps_doviz_kodu and
     ln_gun  between vade_1 and vade_2;

   return nvl(ln_marj_orani,0);

 Exception when others then return 0;
 end;
------------------------------------------------------------------------------------------------
 Function rezervasyon_internal_no( pn_rezervasyon_NO in number,
         pd_tarih in date default pkg_muhasebe.banka_tarihi_bul,
         ps_sube_kodu in varchar2 default pkg_baglam.bolum_kodu) return number
 is
 ln_internal_no number := 0;

 begin

  select internal_no
  into ln_internal_no
  from cbs_faizoran_rezervasyon
  where sube_kodu=ps_sube_kodu and
    rezervasyon_no = pn_rezervasyon_no and
   tarih = pd_tarih;

  return ln_internal_no;

 Exception when others then return 0;
 end;
------------------------------------------------------------------------------------------------
 Function Rezervasyon_Bakiye( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
            pn_islem_numara cbs_islem.NUMARA%type,
         pn_hesap_no   number,
            pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
         ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu,
         pn_gun_sayisi number default null
        ) return number
 is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_marj number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
-- ls_Alis_Satis varchar2(10);
 ln_tutar number;
 ln_count number;
 ln_kullanim_count number;

 begin

 select nvl(tutar,0)
  into ln_rezerve_tutar
  from cbs_faizoran_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 --Rezerve edilen tutar?n nekadarl?k k?sm?n?n kullan?ld??? hesaplan?yor...
 select nvl(sum(tutar),0)
  into ln_kullanilan_tutar
  from cbs_faizoran_rezervasyonkullan
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no
  and durum_kodu = 'ACIK';

 select doviz_kodu,tutar
  into ls_doviz_kodu,ln_tutar
  from cbs_faizoran_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

/* rezervasyon bakiyesinde marj kullan?lmayacak */
 --D?viz i?in girilen MARJ al?n?yor.
 -- ln_marj := Kur_Marj_Al (ls_doviz_kodu ,pn_hesap_no, pn_gun_sayisi);

 --kullan?labilir tutar bulunuyor.(max-kullanilan)
 -- ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
  ln_max_tutar := ln_rezerve_tutar;
  ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;

 --Rezervasyon,m?svetteye gidip i?lem numaras?yla kaydedilmi? olabilir.
 --Bu durumda, tekrar m?svetteden ?a?r?lan i?lemin bakiye hatas? almamas?
 --i?in bakiye, kullanim tutar? kadar art?r?l?yor.
  ln_kullanim_count:=0;
  ln_kullanilan_tutar:=0;

  select count(*)
   into ln_kullanim_count
   from cbs_faizoran_rezervasyonkullan
   where TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no
     and tx_no=pn_islem_numara;


 if ln_kullanim_count>0 then
  select nvl(sum(tutar),0)
   into ln_kullanilan_tutar
   from cbs_faizoran_rezervasyonkullan
   where TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no
  and tx_no=pn_islem_numara;

  ln_kullanilabilir_tutar:=ln_kullanilabilir_tutar+ln_kullanilan_tutar;
 end if;


   return ln_kullanilabilir_tutar;

  exception
     when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '4542' || pkg_hata.getUCPOINTER);
end;
------------------------------------------------------------------------------------------------
 Procedure Bakiye_yeterlimi(pn_REZERVASYON_NO in number,
                           pn_islem_numara in number,
         pn_TUTAR in number,
         pn_hesap_no number,
         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
         ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu,
         pn_gun_sayisi number default null)
 is
  ln_bakiye number := 0;
  bakiye_yetersiz exception;
 Begin
   ln_bakiye:= Rezervasyon_Bakiye( pn_rezervasyon_no,
           pn_islem_numara,
        pn_hesap_no ,
           pd_TARIH ,
        ps_SUBE_KODU,
        pn_gun_sayisi
       );
    if nvl(pn_TUTAR,0) > nvl(ln_bakiye,0) then
     raise bakiye_yetersiz ;
   end if;
 Exception
  when   bakiye_yetersiz then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2038' || pkg_hata.getUCPOINTER);
 End;
------------------------------------------------------------------------------------------------
 Procedure Kontrol_sonrasi(pn_REZERVASYON_NO in number,
                           pn_islem_numara in number,
         pn_TUTAR in number,
         pn_hesap_no number,
         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
         ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu,
         pn_gun_sayisi number default null
          )
 is
 Begin
   if nvl(pn_REZERVASYON_NO,0) <> 0 then
     Bakiye_yeterlimi(pn_REZERVASYON_NO,
                           pn_islem_numara,
         pn_TUTAR,
         pn_hesap_no,
         pd_TARIH,
         ps_SUBE_KODU ,
         pn_gun_sayisi);

    Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO ,
                                       pn_islem_numara,
            pn_TUTAR,
            pn_hesap_no,
            pd_TARIH ,
            ps_SUBE_KODU
          );
  end if;
 End;
------------------------------------------------------------------------------------------------
  Procedure onay_sonrasi(pn_REZERVASYON_NO in number,
                           pn_islem_numara in number,
         pn_TUTAR in number,
         pn_hesap_no number,
         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
         ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu,
         pn_gun_sayisi number default null
          )
 is
 Begin
    if nvl(pn_REZERVASYON_NO,0) <> 0 then
     Bakiye_yeterlimi(pn_REZERVASYON_NO,
                           pn_islem_numara,
         pn_TUTAR,
         pn_hesap_no,
         pd_TARIH,
         ps_SUBE_KODU ,
         pn_gun_sayisi);

    Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO ,
                                       pn_islem_numara,
            pn_TUTAR,
            pn_hesap_no,
            pd_TARIH ,
            ps_SUBE_KODU
          );
  end if;
 End;
------------------------------------------------------------------------------------------------
 Procedure iptal_onay_sonrasi(pn_islem_numara in number)
 is
 Begin
    Rezervasyon_Kullanim_Iptal(pn_islem_numara);
 End;
------------------------------------------------------------------------------------------------
 Procedure reddetme_sonrasi(pn_islem_numara in number)
 is
 Begin
    Rezervasyon_Kullanim_Iptal(pn_islem_numara);
 End;
------------------------------------------------------------------------------------------------
Function vadeli_faizoran_al(ps_doviz varchar2,
                             pn_gun_sayisi number,
                            pd_tarih date default pkg_muhasebe.banka_tarihi_bul,
                            pn_musteri number) return number
is
    ln_tutar number :=0 ;
    ls_musteri_tip varchar2(1);
Begin
    ls_musteri_tip := pkg_musteri.sf_musteri_tipi_al(pn_musteri);

    if ls_musteri_tip = '1'
    then
        select  decode(ps_doviz,pkg_genel.lc_al,TRL, 'USD',USD,'EUR', EUR,'GBP', GBP,'RUB',RUB,'KZT',KZT,'CHF',CHF,'CNY',CNY,0) -- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
        into ln_tutar
        from CBS_CARI_VADELI_MEVDUAT_FO
        where tarih = nvl(pd_tarih,pkg_muhasebe.banka_tarihi_bul)
          and pn_gun_sayisi between vade_1 and vade_2
          and musteri_tipi = '1';
    else
        select  decode(ps_doviz,pkg_genel.lc_al,TRL, 'USD',USD,'EUR', EUR,'GBP', GBP,'RUB',RUB,'KZT',KZT,'CHF',CHF,'CNY',CNY,0)  -- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
        into ln_tutar
        from CBS_CARI_VADELI_MEVDUAT_FO
        where tarih = nvl(pd_tarih,pkg_muhasebe.banka_tarihi_bul)
          and pn_gun_sayisi between vade_1 and vade_2
          and musteri_tipi = '2';
    end if;

    return nvl(ln_tutar,0);

    Exception when others then return 0;
End;
------------------------------------------------------------------------------------------------
Function max_faizoran(ps_doviz varchar2,
                      pn_gun_sayisi number ,
                      pd_tarih date default pkg_muhasebe.banka_tarihi_bul,
                      pn_musteri number) return number
is
    ln_faizoran number := 0;
    ln_marj number := 0;
    Begin
    ln_marj:= Kur_Marj_Al(ps_doviz,NULL,pn_gun_sayisi);
    ln_faizoran:= vadeli_faizoran_al(ps_doviz,pn_gun_sayisi,pd_tarih,pn_musteri);
    ln_faizoran := nvl(ln_faizoran,0) + nvl( ((ln_marj * ln_faizoran  ) / 100),0);

    return nvl(ln_faizoran,0);
End;
------------------------------------------------------------------------------------------------
Procedure Rezervasyon_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                  ps_doviz_kodu out varchar2,
          pn_faiz_orani out number,
          pn_tutar out number,
          pd_vade_tarihi out date ,
          pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
          ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
          )
 is

 begin

  select DOVIZ_KODU, FAIZ_ORAN, TUTAR, VADE_TARIHI
  into ps_doviz_kodu, pn_faiz_orani,pn_tutar,pd_vade_tarihi
  from CBS_faizoran_REZERVASYON
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 end;
------------------------------------------------------------------------------------------------
END;
/

