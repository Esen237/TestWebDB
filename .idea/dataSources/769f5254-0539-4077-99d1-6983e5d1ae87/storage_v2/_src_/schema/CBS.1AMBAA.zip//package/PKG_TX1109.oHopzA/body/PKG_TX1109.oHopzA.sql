create PACKAGE BODY     PKG_TX1109 IS
    pn_1109_masraf_tutari              number;
    pn_1109_masraf_hesap_no            number;
    pn_1109_masraf_hesap_sube          number;
    pn_1109_cek_islem_sube             number;
    pn_1109_cek_tutar_1_tl             number;
    pn_1109_cek_yaprak_adet            number;
    pn_1109_banka_aciklama             number;
    pn_1109_musteri_aciklama           number;
    pn_1109_cek_referans               number;
    pn_1109_fis_aciklama               number;
    pn_1109_kur_lc                       number;
--    pn_1109_masraf_vergi_toplami        number;
    pn_1109_bsmv_tutari                   number;
    pn_1109_masraf_kasa                     number;
    pn_1109_masraf_hesap                 number;
    pn_1109_masraf_yok                     number;
    pn_1109_karne_continuous             number;
    pn_1109_karne_10                     number;
    pn_1109_karne_25                     number;
    pn_1109_doviz_tl                     number;
    pn_1109_doviz_yp                     number;
    pn_1109_alinan_masraf_tutari        number;
    pn_1109_deger_masraf_toplami        number;

    pn_1109_DOVIZ_KODU                        number;
    pn_1109_LC_CEK_TUTAR_1_TL              number;
    pn_1109_KUR                        number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
               Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

 Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_musteri_no number := 0;
  ld_banka_tarihi date ;
  ln_cek_no           cbs_cek.cek_no%type;
  ln_karne_tx_no   cbs_cek_karne_islem.ref_tx_no%type;
  ls_durum_kodu       cbs_cek.durum_kodu%type;
  ld_teslim_tarihi cbs_cek.teslim_tarihi%type;
  odeme_yasakli_cek_mevcut     exception;
  karsiliksiz_cek_mevcut       exception;
  onceden_teslim_edilmis          exception;
  cek_karne_durumu_aktif_degil exception;
  blokeli_cek_mevcut           exception;
  ln_baslangic_cek_no           number;
  ls_bolum                         varchar2(20);
  Begin

  ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;

 /* talep ve karne islem numaralari bulunur */
    select   pkg_cek.Sf_Islem_Gonder_karne_Islem_Al(pn_islem_no)
    into ln_karne_tx_no
    from dual ;

    ln_cek_no :=  Pkg_cek.Sf_Cek_Teslim_Girisi_Yapilirmi(ln_karne_tx_no ) ;

      select durum_kodu,teslim_tarihi ,baslangic_cek_no ,nvl(nvl(hesap_sube_kodu,pkg_tx.Amir_BolumKodu_Al(pn_islem_no)),pkg_baglam.bolum_kodu    )
     into   ls_durum_kodu,ld_teslim_tarihi,ln_baslangic_cek_no,ls_bolum
     from   cbs_cek_karne_islem
     where  tx_no =  ln_karne_tx_no ;

/* karne bilgileri durum kodu kontrol edilir */
 if  ls_durum_kodu = 'A'  and   ld_teslim_tarihi is not null then
   if ln_cek_no =0 then
      /* cek teslim tarihi ve durum kodu guncellenir. */
       update  cbs_cek_karne_islem
       set     teslim_tarihi =  null ,durum_kodu = 'A',
                   hesap_sube_kodu =ls_bolum
       where  tx_no = pn_islem_no;

    /* cek karnesinin teslim tarihi guncellenir. */
       update  cbs_cek_karne_islem
       set    teslim_tarihi =  null,
                  musteri_no = null,
               hesap_no = null
       where  tx_no = ln_karne_tx_no;

    /* cek yapraklar?n?n teslim tarihi guncellenir. */
       update  cbs_cek
       set     teslim_tarihi =  null,
                  musteri_no = null,
               hesap_no = null
       where   ref_tx_no = ln_karne_tx_no;
    else
            select Pkg_cek.Sf_Cek_Durumu_Al(ln_cek_no)
          into ls_durum_kodu
          from dual;
      /* odeme yasakli yada karsiliksiz cek durum kodunda olan cek kaydi mevcuttur. teslim iptali yapilamaz. */
            if ls_durum_kodu = 'Y' then
               raise odeme_yasakli_cek_mevcut;
           elsif ls_durum_kodu = 'K' then
                raise karsiliksiz_cek_mevcut ;
           elsif ls_durum_kodu = 'B' then
                raise blokeli_cek_mevcut ;
           else
             raise cek_karne_durumu_aktif_degil ;
           end if;

    end if;
  else
       if ld_teslim_tarihi is null then
            raise onceden_teslim_edilmis;
     else
           raise cek_karne_durumu_aktif_degil;
     end if;
  end if;

  Exception
       When odeme_yasakli_cek_mevcut then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '406' ||  pkg_hata.getDelimiter || ln_cek_no || pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
       When karsiliksiz_cek_mevcut then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '407' ||  pkg_hata.getDelimiter || ln_cek_no || pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter ||  pkg_hata.getUCPOINTER);
       When onceden_teslim_edilmis  then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '413' ||  pkg_hata.getDelimiter || ln_baslangic_cek_no || pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter ||  pkg_hata.getUCPOINTER);
       When   blokeli_cek_mevcut then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '440' ||  pkg_hata.getDelimiter || ln_cek_no ||  pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
     When cek_karne_durumu_aktif_degil then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '414' ||  pkg_hata.getDelimiter || ln_cek_no ||  pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
      When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '141' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin

     /* Red edildi */
    update cbs_cek_karne_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;

    ln_fis_no                   cbs_fis.numara%type ;
    ls_islem_kod               cbs_islem.islem_kod%type :='1109';
    ls_aciklama                varchar2(2000);
    ls_genel_aciklama          varchar2(2000);
    ln_musteri_no               cbs_musteri.musteri_no%TYPE;
    ln_hesap_no                      cbs_cek_karne_islem.hesap_no%TYPE;
    ls_hesap_sube_kodu              cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_tutar                      cbs_cek_karne_islem.masraf_TUTARi%TYPE;
    ls_karne_tipi_kodu           cbs_cek_karne_islem.karne_tipi_kodu%TYPE;
    ls_doviz_kodu               cbs_hesap_basvuru.DOVIZ_KODU%TYPE;
    ln_cek_yaprak_adedi           cbs_cek_karne_islem.cek_yaprak_adedi%TYPE;
    ln_baslangic_cek_no           cbs_cek_karne_islem.baslangic_cek_no%type;
    ln_bitis_cek_no               cbs_cek_karne_islem.bitis_cek_no%type;
    ln_masraf_tutari           cbs_cek_karne_islem.masraf_tutari%TYPE;
    ls_kasa_hesap_secimi       cbs_cek_karne_islem.kasa_hesap_secimi%type;
    ls_islem_sube_kodu           cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_bsmv_tutari               cbs_cek_karne_islem.bsmv_tutari%TYPE;
    ls_masraf_hesap_sube_kodu  cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_masraf_hesap_no           cbs_cek_karne_islem.hesap_no%TYPE;
    ln_ref_tx_no               cbs_cek_karne_islem.ref_tx_no%type;
    ls_modul_tur_kod                cbs_cek_karne_islem.modul_tur_kod%type;
    ls_urun_tur_kod                cbs_cek_karne_islem.urun_tur_kod%type;
    ln_alinan_masraf_tutari     NUMBER;

    ln_tax_rate                   number := 0;
    ln_tax_amount               number := 0;
    cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
               select musteri_no,
                   hesap_sube_kodu,
                   hesap_no,
                   karne_tipi_kodu,
                   cek_yaprak_adedi,
                   baslangic_cek_no,
                   bitis_cek_no,
                    nvl(masraf_tutari,0),
                   pkg_hesap.HesaptanDovizKoduAl(hesap_no) ,
                   Decode( masraf_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(masraf_hesap_no) ),
                   masraf_hesap_no,
                   ref_tx_no,
                   modul_tur_kod,urun_tur_kod,
                   pkg_tx.Amir_BolumKodu_Al(tx_no)
            from cbs_cek_karne_islem
            where tx_no=pn_islemno;

    cursor masraf_cursor is
        select odeyecek
        from   cbs_masraf
        where  islem_no =pn_islem_no;

  Begin

/* islem bilgisi detaylari alinir */
         open islem_cursor(pn_islem_no);
        fetch islem_cursor into ln_musteri_no,ls_hesap_sube_kodu,ln_hesap_no,ls_karne_tipi_kodu,
                                         ln_cek_yaprak_adedi ,ln_baslangic_Cek_no,ln_bitis_cek_no,
                                   ln_masraf_tutari,ls_doviz_kodu, ls_masraf_hesap_sube_kodu ,
                                   ln_masraf_hesap_no,ln_ref_tx_no,ls_modul_tur_kod,ls_urun_tur_kod    ,
                                     varchar_list(pn_1109_cek_islem_sube) ;
           if islem_cursor%notfound then
              close islem_cursor;
           end if;
          close islem_cursor;

/*  masraf bilgisi al?n?r */
    pkg_masraf.masraf_toplamlari(ln_ref_tx_no,ln_alinan_masraf_tutari,ln_bsmv_tutari);

     select max(odeyecek)
     into ls_kasa_hesap_secimi
     from cbs_masraf
     where islem_no =ln_ref_tx_no and
            durum = 'VALID'  ;


/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/
   ls_genel_aciklama :=  Pkg_Genel.Islem_Adi_Al(1109);
   ls_genel_aciklama := ls_genel_aciklama  || ' Start No:' || to_char(ln_baslangic_cek_no) || ' End No:' || to_char(ln_bitis_cek_no);

   pkg_parametre.deger('1109_FIS_ACIKLAMA',ls_aciklama);
    varchar_list(pn_1109_fis_aciklama)      := ls_aciklama ;
    varchar_list(pn_1109_banka_aciklama)  := ls_genel_aciklama;
    varchar_list(pn_1109_musteri_aciklama):= ls_genel_aciklama;
    varchar_list(pn_1109_cek_referans)      := '.';
    varchar_list(pn_1109_masraf_hesap_no) := to_char(ln_masraf_hesap_no);
    varchar_list(pn_1109_masraf_hesap_sube):=ls_masraf_hesap_sube_kodu;
    varchar_list(pn_1109_DOVIZ_KODU)         := ls_doviz_kodu ;

    number_list(pn_1109_KUR)                  := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');

     pkg_parametre.deger('1102_CEK_TUTAR_1_TL',number_list(pn_1109_CEK_TUTAR_1_TL));

    number_list(pn_1109_LC_CEK_TUTAR_1_TL):= number_list(pn_1109_CEK_TUTAR_1_TL) * number_list(pn_1109_KUR) ;

/**** boolean list ****/
    boolean_list(pn_1109_masraf_kasa):=false;
    boolean_list(pn_1109_masraf_hesap):=false;
    boolean_list(pn_1109_masraf_yok):=false;
    boolean_list(pn_1109_karne_10):=false;
    boolean_list(pn_1109_karne_25):=false;
    boolean_list(pn_1109_karne_continuous):=false;
    boolean_list(pn_1109_doviz_tl):=false;
    boolean_list(pn_1109_doviz_yp):=false;

    
 /* masraf deger atamalari*/
   boolean_list(pn_1109_masraf_yok):=true; --SEVALB 23022011
 /*
   if ls_kasa_hesap_secimi = pkg_parametre.varchar_al ( ls_modul_tur_kod, ls_urun_tur_kod, null,'KASA') then
      boolean_list(pn_1109_masraf_kasa):=true;
   elsif ls_kasa_hesap_secimi =  pkg_parametre.varchar_al ( ls_modul_tur_kod, ls_urun_tur_kod, null,'HESAP') then
      boolean_list(pn_1109_masraf_hesap):=true;
   else
      boolean_list(pn_1109_masraf_yok):=true;
   end if;
*/
/* karne tipi atamalari */
   if  PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = 'CONTINUOUS' then
      boolean_list(pn_1109_karne_continuous):=true;
   elsif PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = '10' then
      boolean_list(pn_1109_karne_10):=true;
   else
        boolean_list(pn_1109_karne_25):=true;
   end if;



    boolean_list(pn_1109_doviz_tl):=true;  --SEVALB 23022011
/* d?viz tipi atamalari */
/*   if ls_doviz_kodu = pkg_genel.lc_al  then
      boolean_list(pn_1109_doviz_tl):=true;
   else
        boolean_list(pn_1109_doviz_yp):=true;
   end if;
   */
/**** number list ****/
--     pkg_parametre.deger('1109_CEK_TUTAR_1_TL',number_list(pn_1109_cek_tutar_1_tl));
       pkg_parametre.deger('G_CEK_MASRAF_ORAN',ln_tax_rate);

     if nvl(ln_alinan_masraf_tutari,0) <> 0 then
         ln_tax_amount := ((ln_tax_rate * ln_alinan_masraf_tutari) / ( 100 +ln_tax_rate));
     else
          ln_tax_amount := 0;
     end if;

     number_list(pn_1109_cek_yaprak_adet) := ln_cek_yaprak_adedi;
     number_list(pn_1109_kur_lc) := pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     --SEVALB 23022011
    /* number_list(pn_1109_masraf_tutari)   := nvl(ln_masraf_tutari,0) ;
     number_list(pn_1109_bsmv_tutari)     := nvl(ln_bsmv_tutari,0);
     number_list(pn_1109_alinan_masraf_tutari) :=   ln_tax_amount ;--nvl( ln_alinan_masraf_tutari,0);
     number_list(pn_1109_deger_masraf_toplami) := number_list(pn_1109_alinan_masraf_tutari)+  number_list(pn_1109_bsmv_tutari);
    */

/**** date list ****/

/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            ls_aciklama);

    pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '185' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

  End;

Begin
/* parametre index numaralar? bulunur.*/
    pn_1109_masraf_tutari         := pkg_muhasebe.parametre_index_bul('1109_MASRAF_TUTARI');
    pn_1109_bsmv_tutari           := pkg_muhasebe.parametre_index_bul('1109_BSMV_TUTARI');
--    pn_1109_masraf_vergi_toplami  := pkg_muhasebe.parametre_index_bul('1109_MASRAF_VERGI_TOPLAMI');
    pn_1109_masraf_hesap_no         := pkg_muhasebe.parametre_index_bul('1109_MASRAF_HESAP_NO');
    pn_1109_masraf_hesap_sube       := pkg_muhasebe.parametre_index_bul('1109_MASRAF_HESAP_SUBE');
    pn_1109_cek_islem_sube             := pkg_muhasebe.parametre_index_bul('1109_CEK_ISLEM_SUBE');
    pn_1109_cek_tutar_1_tl             := pkg_muhasebe.parametre_index_bul('1109_CEK_TUTAR_1_TL');
    pn_1109_cek_yaprak_adet         := pkg_muhasebe.parametre_index_bul('1109_CEK_YAPRAK_ADET');
    pn_1109_banka_aciklama             := pkg_muhasebe.parametre_index_bul('1109_BANKA_ACIKLAMA');
    pn_1109_musteri_aciklama        := pkg_muhasebe.parametre_index_bul('1109_MUSTERI_ACIKLAMA');
    pn_1109_cek_referans             := pkg_muhasebe.parametre_index_bul('1109_CEK_REFERANS');
    pn_1109_fis_aciklama             := pkg_muhasebe.parametre_index_bul('1109_FIS_ACIKLAMA');
    pn_1109_kur_lc                     := pkg_muhasebe.parametre_index_bul('1109_KUR_LC');
    pn_1109_masraf_kasa           := pkg_muhasebe.parametre_index_bul('1109_MASRAF_KASA');
    pn_1109_masraf_hesap           := pkg_muhasebe.parametre_index_bul('1109_MASRAF_HESAP');
    pn_1109_masraf_yok               := pkg_muhasebe.parametre_index_bul('1109_MASRAF_YOK');
    pn_1109_karne_continuous       := pkg_muhasebe.parametre_index_bul('1109_KARNE_CONTINUOUS');
    pn_1109_karne_10               := pkg_muhasebe.parametre_index_bul('1109_KARNE_10');
    pn_1109_karne_25               := pkg_muhasebe.parametre_index_bul('1109_KARNE_25');
    pn_1109_doviz_tl               := pkg_muhasebe.parametre_index_bul('1109_DOVIZ_TL');
    pn_1109_doviz_yp               := pkg_muhasebe.parametre_index_bul('1109_DOVIZ_YP');
    pn_1109_alinan_masraf_tutari  :=pkg_muhasebe.parametre_index_bul('1109_ALINAN_MASRAF_TUTARI');
    pn_1109_deger_masraf_toplami  :=pkg_muhasebe.parametre_index_bul('1109_DEGER_MASRAF_TOPLAMI');
    pn_1109_doviz_kodu            :=pkg_muhasebe.parametre_index_bul('1109_doviz_kodu');
    pn_1109_kur                     := pkg_muhasebe.parametre_index_bul('1109_KUR');

    pn_1109_LC_CEK_TUTAR_1_TL       := pkg_muhasebe.parametre_index_bul('1109_LC_CEK_TUTAR_1_TL');
    pn_1109_kur                     := pkg_muhasebe.parametre_index_bul('1109_KUR');
END ;
/

