create PACKAGE BODY     "PKG_EOD_AUTOMATION"
IS
   ln_log_no   NUMBER;

   FUNCTION Start_EOD_Process (pn_grup_no NUMBER) return NUMBER
   IS
      ln_flag     NUMBER;
      not_match   EXCEPTION;
      ln_log_no   NUMBER;
   BEGIN
      pkg_batch.Is_Yarat(pn_grup_no, ln_log_no);
      return ln_log_no;
   END;

   function Stop_EOD_Process return number
   IS
      not_started   EXCEPTION;
      ln_count number;
      ln_log_no NUMBER;
      ln_grup_no NUMBER;
   BEGIN
   
      select count(*) into ln_count from cbs_batch_Tanim where son_job_no is not null;

      if (ln_count > 1) then
        return -1; -- more than one eod proccess remaining
      elsif (ln_count = 0) then
        return 0; -- nothing to cancel
      end if;

      select grup_no, son_job_no into ln_grup_no, ln_log_no from cbs_batch_Tanim where son_job_no is not null;

      pkg_batch.is_iptal(ln_grup_no, ln_log_no);
      
      return ln_log_no;
   END;

   FUNCTION Continue_Eod_Process return NUMBER
   IS pragma AUTONOMOUS_TRANSACTION;
      not_match         EXCEPTION;

      ln_count number;
      ln_log_no NUMBER;
      ln_grup_no NUMBER;
      ls_status varchar2(3);

      ls_durum          VARCHAR2 (1);
      pn_log_number     NUMBER;
      ln_PROGRAM_KODU   VARCHAR2 (50);
      ln_flag_no        NUMBER;
      ln_sira_no        NUMBER;
      ls_fix            VARCHAR2 (1);


      CURSOR c1
      IS
         SELECT PROGRAM_KODU, sira_no
           FROM CBS_BATCH_CALISAN_PROGRAM_SETI
          WHERE grup_no = ln_grup_no AND durum = 'E';
      CURSOR c2

      IS
           SELECT sira_no
             FROM CBS_BATCH_PROGRAM_LOG
            WHERE     SUBSTR (hata_mesaji, 1, 9) = 'ORA-00060'
                  AND grup_no = ln_grup_no
                  AND log_no = ln_log_no
                  AND baslama_zamani > SYSDATE - 1
         ORDER BY baslama_zamani DESC;
         
   BEGIN
      /*select count(*) into ln_count from cbs_batch_Tanim where son_job_no is not null;

      if (ln_count > 1) then
        return -1; -- more than one eod proccess remaining
      elsif (ln_count = 0) then
      
        select COUNT(*) INTO ln_count from cbs_batch_program_log
        where log_no = (select max(log_no) from cbs_batch_program_log)
        and durum='E';
      
        return 0; -- no running proccess
      end if;*/

      Begin
          select grup_no, son_job_no into ln_grup_no, ln_log_no from cbs_batch_Tanim where son_job_no is not null;

          SELECT durum INTO ls_status
            FROM CBS_BATCH_LOG
           WHERE grup_no = ln_grup_no
           and log_no = ln_log_no
           and rownum = 1;

          -- this part to continue when force stop pressed before
          IF (ls_status = 'C') THEN

            DELETE FROM CBS_BATCH_CALISAN_PROGRAM_SETI WHERE grup_no=70;

            DELETE FROM cbs_batch_program_tanim t WHERE t.grup_no=70;
             
            INSERT INTO cbs_batch_program_tanim (SELECT 70, t.program_kod, t.sira_no, t.gecerli
            FROM cbs_batch_program_tanim t
            WHERE t.grup_no = ln_grup_no
            AND t.sira_no >= (Select min(sira_no) from CBS_BATCH_CALISAN_PROGRAM_SETI
                                where grup_no = ln_grup_no and durum not in ('+'))
            and GECERLI= 'E');

            COMMIT;
            
            return pkg_eod_automation.Start_EOD_Process(70);
          END IF;
      Exception
        when others then
            log_at('There is nothing to continue');
      End;


      Begin
            SELECT count(*) into ln_count FROM cbs_batch_program_log
            where log_no=(SELECT max(log_no) FROM cbs_batch_program_log)
            and durum='E'
            and grup_no in (SELECT grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1)
            and lower(hata_mesaji) like '%ora-00060%';
            
            SELECT grup_no into ln_grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1;
        
          -- this part to continue when deadlock found
          IF (ln_count > 0) THEN

            DELETE FROM CBS_BATCH_CALISAN_PROGRAM_SETI WHERE grup_no=70;

            DELETE FROM cbs_batch_program_tanim t WHERE t.grup_no=70;
             
            INSERT INTO cbs_batch_program_tanim (SELECT 70, t.program_kod, t.sira_no, t.gecerli
            FROM cbs_batch_program_tanim t
            WHERE t.grup_no = ln_grup_no
            AND t.sira_no >= (Select min(sira_no) from CBS_BATCH_CALISAN_PROGRAM_SETI
                                where grup_no = ln_grup_no and durum not in ('+'))
            and GECERLI= 'E');

            COMMIT;
            
            return pkg_eod_automation.Start_EOD_Process(70);
          END IF;
        
      Exception
        When others then
            RAISE_APPLICATION_ERROR(-20100, 'Error on continue deadlock!' || sqlerrm);
      End;
   
      ln_flag_no := 0;

      SELECT MAX (log_no)
        INTO ln_log_no
        FROM CBS_BATCH_LOG
       WHERE grup_no = ln_grup_no; ------- --------поиск последнего номера лога

      SELECT durum
        INTO ls_durum
        FROM CBS_BATCH_LOG
       WHERE grup_no = ln_grup_no AND log_no = ln_log_no; -----определение состояния процесса


      SELECT deger
        INTO ls_fix
        FROM cbs_parametre
       WHERE kod = 'eod_sod_automation';     ------выбор значения в параметрах

      OPEN c1;

      FETCH c1 INTO ln_PROGRAM_KODU, ln_sira_no; --------определение состояния ошибки

      CLOSE c1;



      IF ln_PROGRAM_KODU IS NOT NULL
      THEN
         OPEN c2;

         FETCH c2 INTO ln_flag_no;       ------если есть ошибка то ищем дедлок

         CLOSE c2;
      END IF;

      log_at (
         'lev_batop1',
            '-durum-'
         || ' - '
         || ls_durum
         || '-log_no-'
         || ln_log_no
         || '-grup_no-'
         || ln_grup_no,
         2.1,
         ln_grup_no);


      -- ii eier durdurulmui bir iie kaldiii yerden devam ettir.

      IF ls_durum = 'P' OR (ln_flag_no IS NULL AND ls_fix = 'A')
      THEN
         pkg_batch.is_devam_ettir (ln_grup_no, ln_log_no);
         log_at ('lev_batop1',
                 '-devam finished-',
                 2.2,
                 ln_grup_no);
      ELSIF ls_durum <> 'P' AND ln_flag_no <> 0
      THEN
         DELETE FROM CBS_BATCH_CALISAN_PROGRAM_SETI
               WHERE grup_no = ln_grup_no;

         DELETE FROM CBS_BATCH_PROGRAM_TANIM
               WHERE grup_no = ln_grup_no AND sira_no < ln_sira_no;

         COMMIT;
         pkg_batch.is_devam_ettir (ln_grup_no, ln_log_no);
         log_at ('lev_batop1',
                 '-devam finished-',
                 2.21,
                 ln_grup_no);
      END IF;
   END;

   FUNCTION Continue_Eod_Process_Deadlock return NUMBER
   IS pragma AUTONOMOUS_TRANSACTION;
      ln_count number;
      ln_log_no NUMBER;
      ln_grup_no NUMBER;
      ls_status varchar2(3);
   BEGIN
        SELECT count(*) into ln_count FROM cbs_batch_program_log
        where log_no=(SELECT max(log_no) FROM cbs_batch_program_log)
        and durum='E'
        and grup_no in (SELECT grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1)
        and lower(hata_mesaji) like '%ora-00060%';
            
        SELECT grup_no into ln_grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1;
        
      -- this part to continue when deadlock found
      IF (ln_count > 0) THEN

        DELETE FROM cbs_batch_program_tanim t WHERE t.grup_no=70;
             
        INSERT INTO cbs_batch_program_tanim (SELECT 70, t.program_kod, t.sira_no, t.gecerli
        FROM cbs_batch_program_tanim t
        WHERE t.grup_no = (
            SELECT decode(program_kodu, 'PKG_BAT_1.EOD_BITIR', 1, 2) FROM CBS_BATCH_CALISAN_PROGRAM_SETI
            where sira_no = (SELECT max(sira_no) FROM CBS_BATCH_CALISAN_PROGRAM_SETI)
        )
        AND t.sira_no >= (Select min(sira_no) from CBS_BATCH_CALISAN_PROGRAM_SETI
                            where grup_no = ln_grup_no and durum not in ('+'))
        and GECERLI= 'E');

        DELETE FROM CBS_BATCH_CALISAN_PROGRAM_SETI WHERE grup_no=70;

        COMMIT;
            
        return pkg_eod_automation.Start_EOD_Process(70);
      END IF;
      
      return -1;
   END;

   FUNCTION Continue_Eod_Process_04061 return NUMBER
   IS pragma AUTONOMOUS_TRANSACTION;
      ln_count number;
      ln_log_no NUMBER;
      ln_grup_no NUMBER;
      ls_status varchar2(3);
   BEGIN
        SELECT count(*) into ln_count FROM cbs_batch_program_log
        where log_no=(SELECT max(log_no) FROM cbs_batch_program_log)
        and durum='E'
        and grup_no in (SELECT grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1)
        and lower(hata_mesaji) like '%ora-04061%';
            
        SELECT grup_no into ln_grup_no FROM CBS_BATCH_CALISAN_PROGRAM_SETI where durum = 'E' and rownum=1;
        
      -- this part to continue when deadlock found
      IF (ln_count > 0) THEN

        DELETE FROM cbs_batch_program_tanim t WHERE t.grup_no=70;
             
        INSERT INTO cbs_batch_program_tanim (SELECT 70, t.program_kod, t.sira_no, t.gecerli
        FROM cbs_batch_program_tanim t
        WHERE t.grup_no = (
            SELECT decode(program_kodu, 'PKG_BAT_1.EOD_BITIR', 1, 2) FROM CBS_BATCH_CALISAN_PROGRAM_SETI
            where sira_no = (SELECT max(sira_no) FROM CBS_BATCH_CALISAN_PROGRAM_SETI)
        )
        AND t.sira_no >= (Select min(sira_no) from CBS_BATCH_CALISAN_PROGRAM_SETI
                            where grup_no = ln_grup_no and durum not in ('+'))
        and GECERLI= 'E');

        DELETE FROM CBS_BATCH_CALISAN_PROGRAM_SETI WHERE grup_no=70;

        COMMIT;
            
        return pkg_eod_automation.Start_EOD_Process(70);
      END IF;
      
      return -1;
   END;

   PROCEDURE renew_eod_process (pn_grup_no NUMBER)
   IS
      ln_log_number   NUMBER;
      ls_durum        VARCHAR2 (1);
      ln_sira_no      NUMBER;
   BEGIN
      SELECT MAX (log_no)
        INTO ln_log_number
        FROM CBS_BATCH_LOG
       WHERE grup_no = pn_grup_no;

      SELECT durum
        INTO ls_durum
        FROM CBS_BATCH_LOG
       WHERE grup_no = pn_grup_no AND log_no = ln_log_number;

      SELECT NVL (MAX (sira_no), 0)
        INTO ln_sira_no
        FROM CBS_BATCH_CALISAN_PROGRAM_SETI
       WHERE durum = 'E' AND grup_no = pn_grup_no;

      IF ln_sira_no <> 0 AND pn_grup_no <> 70
      THEN
         DELETE FROM CBS_BATCH_PROGRAM_TANIM
               WHERE grup_no = 70 AND gecerli = 'E';

         INSERT INTO CBS_BATCH_PROGRAM_TANIM
            (SELECT 70,
                    t.program_kod,
                    t.sira_no,
                    t.gecerli
               FROM CBS_BATCH_PROGRAM_TANIM t
              WHERE     t.grup_no = pn_grup_no
                    AND t.sira_no >= ln_sira_no
                    AND GECERLI = 'E');


         COMMIT;
      ELSIF ln_sira_no <> 0 AND pn_grup_no = 70
      THEN
         DELETE FROM CBS_BATCH_PROGRAM_TANIM
               WHERE grup_no = pn_grup_no AND sira_no < ln_sira_no;

         COMMIT;
      END IF;
   END;

   PROCEDURE pause_eod_process (pn_grup_no NUMBER)
   IS
   BEGIN
      pkg_batch.is_durdur (pn_grup_no);
   END;
END;
/

