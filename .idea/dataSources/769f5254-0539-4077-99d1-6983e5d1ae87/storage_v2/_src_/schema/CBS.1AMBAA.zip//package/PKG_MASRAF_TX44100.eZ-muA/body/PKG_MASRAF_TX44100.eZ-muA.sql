create PACKAGE BODY     Pkg_Masraf_Tx44100  IS

p_44100_HABR_TRL NUMBER;                --HABERLE?ME TRL
p_44100_POSTA_TRL NUMBER;            --POSTA MASRAFI TRL
p_44100_KOM_TOPLAMI NUMBER;            --TOPLAM TRL MASRAF
p_44100_M_HESAP NUMBER;                --MASRAF HESAP NO
p_44100_M_HESAP_DVZ NUMBER;          --MASRAF HESAP TRL DE??L
p_44100_MHESAP_SUBE NUMBER;          --MASRAF HESABININ ?UBES?
p_44100_ISLEM_SUBE NUMBER;            --??LEM YAPILAN ?UBE
p_44100_TEYIT_MDV NUMBER;            --TEYIT MASRAF HESAP D?V?Z? KARSILI?I
p_44100_IHBAR_MDV NUMBER;            --?HBAR MASRAF HESAP D?V?Z? KAR?ILI?I
p_44100_HABR_MDV NUMBER;                --HABERLE?ME MASRAF HESAP D?V?Z? KAR?ILI?I
p_44100_POSTA_MDV NUMBER;               --POSTA MASRAF HESAP D?V?Z? KAR?ILI?I
p_44100_KOM_MDV_TOPLAM NUMBER;       --TOPLAM MASRAF, MASRAF HESAP D?V?Z? KAR?ILI?I
p_44100_MAS_ACIKLAMA NUMBER;         --ANA F?? A?IKLAMASI
p_44100_MAS_TEY_ACIKLAMA NUMBER;     --TEYIT BOLUM A?IKLAMASI
p_44100_MAS_HABR_ACIKLAMA NUMBER;    --HABR BOLUM A?IKLAMASI
p_44100_MAS_IHBAR_ACIKLAMA NUMBER;   --IHBAR BOLUM A?IKLAMASI
p_44100_MAS_POST_ACIKLAMA NUMBER;    --POSTA BOLUM A?IKLAMASI
p_44100_KUR_TUTAR NUMBER;            --KUR B?LG?S?
p_44100_TEYIT_VAR NUMBER;            --TEYIT MASRAFI VAR
p_44100_IHBAR_VAR NUMBER;            --IHBAR MASRAFI VAR
p_44100_HABR_VAR NUMBER;                --HABERLE?ME MASRAFI VAR
p_44100_POSTA_VAR NUMBER;            --POSTA MASRAFI VAR
p_44100_M_HESAP_TRL NUMBER;            --MASRAF HESAP TRL
p_44100_MHESAP_DVZ NUMBER;            --MASRAF HESABININ D?V?Z?
p_44100_TEYIT_TRL NUMBER;            --TEYIT TRL KARSILI?I
p_44100_IHBAR_TRL NUMBER;            --IHBAR TRL KARSILIK
p_44100_MAS_TP_ANA NUMBER;            --ANA MASRAF HESABI
p_44100_MAS_YP_ANA NUMBER;            --ANA MASRAF HESABI
p_44100_KOMISYON_DK NUMBER;
p_44100_DVBSMV_EVET NUMBER;
p_44100_ODEYEN_LEHDAR NUMBER;
p_44100_BSMV_TRL NUMBER;
p_44100_BSMV_MDV NUMBER;
p_44100_MASKOMBSMV_TOPLAM NUMBER;
p_44100_POSTA_DK NUMBER;
p_44100_HABERLESME_DK NUMBER;
p_44100_MASRAF_GECICI_YOK NUMBER;
p_44100_MASRAF_GECICI_VAR NUMBER;

p_44100_TOPLAM_VERGI_LC number;
p_44100_TOPLAM_VERGI_MDV number;
p_44100_SERVICE_TAX_ODENECEK number;


/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
      NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'LGISSUCOM');
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
      NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS        -- Islem iptal edilemez
  BEGIN
    pkg_masraf.iptal_onay_sonrasi_grs_guncel(pn_islem_no, ps_ref, 0);
  END;

 /*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER) IS

   varchar_list              Pkg_Muhasebe.varchar_array;
   number_list              Pkg_Muhasebe.number_array;
   date_list              Pkg_Muhasebe.date_array;
   boolean_list              Pkg_Muhasebe.boolean_array;
   ln_fis_no              NUMBER;
   ls_referans               VARCHAR2(16);
   ls_sube                  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var          BOOLEAN := FALSE;
   ln_son_bakiye          NUMBER := 0;
   ln_borc_tutar          NUMBER := 0;
   ln_borc_trl              NUMBER := 0;
   ln_tahsil_tutar          NUMBER;
   ln_bsmv_trl NUMBER;

   ln_tax_service_rate number;



   --ls_referans........

   CURSOR cur_masraf IS
    SELECT *
     FROM CBS_MASRAF_ITH_IHR_ISL
     WHERE islem_no = pn_islem_no
     ORDER BY sira_no
    FOR UPDATE;
    row_masraf cur_masraf%ROWTYPE;

   CURSOR cur_tmhg IS
     SELECT * FROM CBS_TM_HG_ACILIS_ISLEM
      WHERE tx_no = pn_islem_no;
      row_tmhg cur_tmhg%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT_ISLEM a
      WHERE islem_no = pn_islem_no
        AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
        AND NVL(odenen_tutar,0) < taksit_tutari
     FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;

  BEGIN
  --buraya geldiyse masraf ?demesi vard?r. Tarih kontrol? sadece taksitlerde yap?l?r.
  --E?er fi? kesilmesi istenmiyorsa, bu fonksiyon ?a?r?lmamal?d?r....
    ln_fis_no := pn_fis_no;


    OPEN cur_tmhg;
    FETCH cur_tmhg INTO row_tmhg;
     ls_akr_doviz := row_tmhg.doviz_kodu;
     varchar_list(p_44100_M_HESAP) := row_tmhg.masraf_hesap_no;
     varchar_list(p_44100_MHESAP_DVZ):='';
     varchar_list(p_44100_MHESAP_SUBE) :='';


----------------
     IF row_tmhg.masraf_hesap_no IS NOT NULL THEN
        varchar_list(p_44100_MHESAP_DVZ):= Pkg_Hesap.HesaptanDovizKoduAl(row_tmhg.masraf_hesap_no);
        varchar_list(p_44100_MHESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_tmhg.masraf_hesap_no);

        if varchar_list(p_44100_MHESAP_DVZ)=pkg_genel.LC_al then
           number_list(p_44100_KUR_TUTAR) := Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),1);
        else
           number_list(p_44100_KUR_TUTAR) :=Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),1);
        end if;
     END IF;
----------------

     varchar_list(p_44100_ISLEM_SUBE) := Pkg_Tx.Islem_BolumKodu_Al(pn_islem_no);
     ls_referans := row_tmhg.referans;
    CLOSE cur_tmhg;
    IF varchar_list(p_44100_MHESAP_DVZ) = Pkg_Genel.LC_AL THEN
     boolean_list(p_44100_M_HESAP_TRL) := TRUE;
     boolean_list(p_44100_M_HESAP_DVZ) := FALSE;
    ELSE
     boolean_list(p_44100_M_HESAP_TRL) := FALSE;
     boolean_list(p_44100_M_HESAP_DVZ) := TRUE;
    END IF;
    boolean_list(p_44100_MAS_TP_ANA) := FALSE;
    boolean_list(p_44100_MAS_YP_ANA) := FALSE;
    number_list(p_44100_HABR_TRL) := 0;
    number_list(p_44100_HABR_MDV) := 0;
    varchar_list(p_44100_MAS_HABR_ACIKLAMA) := '';
    boolean_list(p_44100_HABR_VAR) := FALSE;
    number_list(p_44100_POSTA_TRL) := 0;
    number_list(p_44100_POSTA_MDV) := 0;
    varchar_list(p_44100_MAS_POST_ACIKLAMA) := '';
    boolean_list(p_44100_POSTA_VAR) := FALSE;
    number_list(p_44100_TEYIT_TRL) := 0;
    number_list(p_44100_TEYIT_MDV) := 0;
    varchar_list(p_44100_MAS_TEY_ACIKLAMA) := '';
    boolean_list(p_44100_TEYIT_VAR) := FALSE;
    number_list(p_44100_IHBAR_TRL) := 0;
    number_list(p_44100_IHBAR_MDV) := 0;
    varchar_list(p_44100_MAS_IHBAR_ACIKLAMA) := '';
    boolean_list(p_44100_IHBAR_VAR) := FALSE;

    number_list(p_44100_KOM_TOPLAMI) := 0;
    number_list(p_44100_KOM_MDV_TOPLAM) := 0;

    boolean_list(p_44100_SERVICE_TAX_ODENECEK):=FALSE;
    number_list(p_44100_TOPLAM_VERGI_LC) := 0;
    number_list(p_44100_TOPLAM_VERGI_MDV) := 0;

--CQ1405 if lehdar_musteri_no is null VictorK
if row_tmhg.LEHDAR_MUSTERI_NO is null then
varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' Customer No:'||row_tmhg.PRINCIPAL_TITLE ;
else
    varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' Customer No:'||row_tmhg.LEHDAR_MUSTERI_NO
                                   ||' -'||Pkg_Musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);
end if;
/*
    varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
    ||' Customer No:'||row_tmhg.LEHDAR_MUSTERI_NO
    ||' -'||Pkg_Musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);

*/
    
--CQ1405 if musteri_no is null VictorK
if row_tmhg.LEHDAR_MUSTERI_NO is null then
--log_at('1',sqlerrm);
varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'LGISSUCOM');
varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'MAILCHARGE');
varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'COMMUNICAT');
else         
varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'LGISSUCOM');
varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'MAILCHARGE');
varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'COMMUNICAT');
end if;
--varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'LGISSUCOM');
-- varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'MAILCHARGE');
--varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'COMMUNICAT');

   
    boolean_list(p_44100_ODEYEN_LEHDAR) :=FALSE;

     pkg_parametre.Deger('G_SERVICE_TAX_RATE',ln_tax_service_rate);
     if pkg_musteri.musteri_vergiden_muafmi(pkg_hesap.HesaptanMusteriNoAl( varchar_list(p_44100_M_HESAP)) )='H' then
          boolean_list(p_44100_SERVICE_TAX_ODENECEK):=TRUE;
     else
          boolean_list(p_44100_SERVICE_TAX_ODENECEK):=FALSE;
     end if;


    --
    --masraf al?nacak hesab?n bakiyesini al
    ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_44100_M_HESAP));

    OPEN cur_masraf;
    LOOP
      FETCH cur_masraf INTO row_masraf;
      EXIT WHEN cur_masraf%NOTFOUND;
      boolean_list(p_44100_TEYIT_VAR) := FALSE;
      boolean_list(p_44100_IHBAR_VAR) := FALSE;
      boolean_list(p_44100_HABR_VAR) := FALSE;
      boolean_list(p_44100_POSTA_VAR) := FALSE;

      IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
          IF row_masraf.ODEYECEK = 'PRINCIPAL' THEN
                 boolean_list(p_44100_ODEYEN_LEHDAR) :=TRUE;
               ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
              lb_taksit_var := FALSE;
              IF row_masraf.masraf_kodu = 'LCACIHBAR'  THEN     --ihbar masraf?
    --masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                   number_list(p_44100_IHBAR_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                   number_list(p_44100_IHBAR_MDV) := number_list(p_44100_IHBAR_TRL);
                ELSE
                   number_list(p_44100_IHBAR_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_IHBAR_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_IHBAR_MDV)));
                END IF;
    --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
    --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
                ln_borc_tutar := number_list(p_44100_IHBAR_MDV);
                ln_borc_trl := number_list(p_44100_IHBAR_TRL);
                varchar_list(p_44100_MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
                boolean_list(p_44100_IHBAR_VAR) := TRUE;
              ELSIF row_masraf.masraf_kodu = 'COMMUNICAT'  THEN   --haberle?me
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                    number_list(p_44100_HABR_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                    number_list(p_44100_HABR_MDV) := number_list(p_44100_HABR_TRL);
                ELSE
                   number_list(p_44100_HABR_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_HABR_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_HABR_MDV)));
                END IF;
                varchar_list(p_44100_MAS_HABR_ACIKLAMA) := 'COMMUNICATION CHARGE';
                boolean_list(p_44100_HABR_VAR) := TRUE;

                if boolean_list(p_44100_SERVICE_TAX_ODENECEK)=TRUE then
                   number_list(p_44100_TOPLAM_VERGI_LC) := number_list(p_44100_HABR_TRL) * ln_tax_service_rate / 100;
                   number_list(p_44100_TOPLAM_VERGI_MDV) := number_list(p_44100_HABR_MDV) * ln_tax_service_rate / 100;

                   ln_borc_tutar := number_list(p_44100_HABR_MDV)+number_list(p_44100_TOPLAM_VERGI_MDV);
                   ln_borc_trl := number_list(p_44100_HABR_TRL)+number_list(p_44100_TOPLAM_VERGI_LC);
                else
                   ln_borc_tutar := number_list(p_44100_HABR_MDV);
                   ln_borc_trl := number_list(p_44100_HABR_TRL);
                end if;


              ELSIF row_masraf.masraf_kodu = 'MAILCHARGE' THEN   --posta
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                    number_list(p_44100_POSTA_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                    number_list(p_44100_POSTA_MDV) := number_list(p_44100_POSTA_TRL);
                ELSE
                   number_list(p_44100_POSTA_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_POSTA_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_POSTA_MDV)));
                END IF;
                varchar_list(p_44100_MAS_POST_ACIKLAMA) := 'MAIL CHARGE';
                boolean_list(p_44100_POSTA_VAR) := TRUE;

                if boolean_list(p_44100_SERVICE_TAX_ODENECEK)=TRUE then
                   number_list(p_44100_TOPLAM_VERGI_LC) := number_list(p_44100_POSTA_TRL) * ln_tax_service_rate / 100;
                   number_list(p_44100_TOPLAM_VERGI_MDV) := number_list(p_44100_POSTA_MDV) * ln_tax_service_rate / 100;

                   ln_borc_tutar := number_list(p_44100_POSTA_MDV)+number_list(p_44100_TOPLAM_VERGI_MDV);
                   ln_borc_trl := number_list(p_44100_POSTA_TRL)+number_list(p_44100_TOPLAM_VERGI_LC);
                else
                   ln_borc_tutar := number_list(p_44100_POSTA_MDV);
                   ln_borc_trl := number_list(p_44100_POSTA_TRL);
                end if;

              ELSIF row_masraf.masraf_kodu =  'LGISSUCOM' THEN  --with INSTALLMENTS
                  lb_taksit_var := TRUE;
                  OPEN cur_taksitler;
                  LOOP
                    FETCH cur_taksitler INTO row_taksit;
                    EXIT WHEN cur_taksitler%NOTFOUND;
                    ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
                    IF boolean_list(p_44100_M_HESAP_TRL) THEN
                      number_list(p_44100_TEYIT_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                      number_list(p_44100_TEYIT_MDV) := number_list(p_44100_TEYIT_TRL);
                    ELSE
                      number_list(p_44100_TEYIT_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                      number_list(p_44100_TEYIT_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_TEYIT_MDV)));
                    END IF;
                    varchar_list(p_44100_MAS_TEY_ACIKLAMA) := row_taksit.taksit_no || '. L/G CHARGE INSTALLMENT';
                    ln_borc_tutar := number_list(p_44100_TEYIT_MDV);
                    ln_borc_trl := number_list(p_44100_TEYIT_TRL);
                    lb_taksit_var := TRUE;

                    IF ln_son_bakiye >= ln_borc_tutar THEN
                        boolean_list(p_44100_TEYIT_VAR) := TRUE;
                        if nvl(row_tmhg.donem_bas_son,'B') = 'B' then
                          boolean_list(p_44100_MASRAF_GECICI_VAR) := TRUE;
                          boolean_list(p_44100_MASRAF_GECICI_YOK) := FALSE;
                        else
                          boolean_list(p_44100_MASRAF_GECICI_VAR) := FALSE;
                          boolean_list(p_44100_MASRAF_GECICI_YOK) := TRUE;
                        end if;
                        ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                                             NULL,
                                                             pn_islem_no,
                                                            varchar_list ,
                                                            number_list  ,
                                                            date_list    ,
                                                            boolean_list ,
                                                            NULL,
                                                           FALSE,
                                                            ln_fis_no,
                                                            NULL);
                        UPDATE CBS_MASRAF_ITH_IHR_ISL
                           SET tahsil_toplam = NVL(tahsil_toplam,0) + (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0)),
                               tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0))
                         WHERE CURRENT OF cur_masraf;

                           Pkg_Masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                            row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);
                        UPDATE CBS_MASRAF_TAKSIT_ISLEM
                           SET taksit_odeme_tarih = Pkg_Muhasebe.banka_tarihi_bul,
                               odenen_tutar = taksit_tutari
                         WHERE CURRENT OF cur_taksitler;

                        if nvl(row_tmhg.donem_bas_son,'B') = 'B' then
                          pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
                                                               row_masraf.masraf_kodu, row_masraf.vs_no,
                                                               row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
                                                                    number_list(p_44100_TEYIT_TRL), row_tmhg.masraf_hesap_no,
                                                               row_tmhg.vade_tarihi, nvl(row_tmhg.vadeli,'E'));
                        end if;
                        number_list(p_44100_KOM_TOPLAMI) := number_list(p_44100_KOM_TOPLAMI) + ln_borc_trl;
                        number_list(p_44100_KOM_MDV_TOPLAM) := number_list(p_44100_KOM_MDV_TOPLAM) + ln_borc_tutar;
                        ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                    END IF;

                  END LOOP;
                  CLOSE cur_taksitler;

              ELSE
                CLOSE cur_masraf;
                 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
              END IF;


              IF NOT lb_taksit_var THEN
               IF ln_son_bakiye >= ln_borc_tutar THEN --bakiye yeterliyse satiri ekle

                 ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                                    NULL,
                                                    pn_islem_no,
                                                   varchar_list ,
                                                   number_list  ,
                                                   date_list    ,
                                                   boolean_list ,
                                                   NULL,
                                                   FALSE,
                                                     ln_fis_no,
                                                     NULL);
                 Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                               row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

                  UPDATE CBS_MASRAF_ITH_IHR_ISL
                     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
                         tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
                   WHERE CURRENT OF cur_masraf;
                  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                  number_list(p_44100_KOM_TOPLAMI) := number_list(p_44100_KOM_TOPLAMI) + ln_borc_trl;
                  number_list(p_44100_KOM_MDV_TOPLAM) := number_list(p_44100_KOM_MDV_TOPLAM) + ln_borc_tutar;

                   number_list(p_44100_TOPLAM_VERGI_LC) := 0;
                   number_list(p_44100_TOPLAM_VERGI_MDV) := 0;
               END IF;
              END IF;
           END IF; --ihracat?? ?demesi
      END IF;  --tahsil edilmeyen var....

    END LOOP;
    CLOSE cur_masraf;
    IF number_list(p_44100_KOM_MDV_TOPLAM) > 0 THEN
       boolean_list(p_44100_TEYIT_VAR) := FALSE;
       boolean_list(p_44100_IHBAR_VAR) := FALSE;
       boolean_list(p_44100_HABR_VAR)  := FALSE;
       boolean_list(p_44100_POSTA_VAR) := FALSE;
       boolean_list(p_44100_MASRAF_GECICI_YOK) := FALSE;
       boolean_list(p_44100_MASRAF_GECICI_VAR) := FALSE;
       IF boolean_list(p_44100_M_HESAP_TRL) THEN
          boolean_list(p_44100_MAS_TP_ANA) := TRUE;
       ELSE
          boolean_list(p_44100_MAS_YP_ANA) := TRUE;
       END IF;

        number_list(p_44100_BSMV_TRL) :=Pkg_Kur.YUVARLA(Pkg_Genel.LC_AL,number_list(p_44100_KOM_TOPLAMI)*0.05);
        number_list(p_44100_BSMV_MDV) :=Pkg_Kur.YUVARLA(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_KOM_MDV_TOPLAM)*0.05);

         IF boolean_list(p_44100_DVBSMV_EVET)=TRUE THEN
            number_list(p_44100_MASKOMBSMV_TOPLAM) :=Pkg_Kur.YUVARLA(Pkg_Genel.LC_AL,number_list(p_44100_KOM_TOPLAMI)*1.05);
        ELSE
            number_list(p_44100_MASKOMBSMV_TOPLAM) :=number_list(p_44100_KOM_TOPLAMI);
        END IF;


       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                            NULL,
                                            pn_islem_no,
                                           varchar_list ,
                                           number_list  ,
                                           date_list    ,
                                           boolean_list ,
                                           NULL,
                                          FALSE,
                                           ln_fis_no,
                                           NULL);
    END IF;
    pn_fis_no := ln_fis_no;

  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
   BEGIN
    NULL;
   END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebe_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, NULL);
  END;
/*------------------------------------------------------------------------------------------------------*/

   FUNCTION masraf_odeyecek_kontrol(pn_islem_no NUMBER) RETURN VARCHAR2 IS
     ln_temp NUMBER;
     BEGIN
       SELECT COUNT(*)
         INTO ln_temp
         FROM CBS_MASRAF_ITH_IHR_ISL
        WHERE islem_no = pn_islem_no
          AND odeyecek = 'PRINCIPAL';
       IF ln_temp > 0 THEN
         RETURN 'E';
       ELSE
         RETURN 'H';
       END IF;
 END;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

  PROCEDURE EOD_Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER, ps_referans VARCHAR2) IS

   varchar_list              Pkg_Muhasebe.varchar_array;
   number_list              Pkg_Muhasebe.number_array;
   date_list              Pkg_Muhasebe.date_array;
   boolean_list              Pkg_Muhasebe.boolean_array;
   ln_fis_no              NUMBER;
   ls_referans               VARCHAR2(16);
   ls_sube                  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var          BOOLEAN := FALSE;
   ln_son_bakiye          NUMBER := 0;
   ln_borc_trl              NUMBER := 0;
   ln_borc_tutar          NUMBER := 0;
   ln_tahsil_tutar          NUMBER;
   ln_bsmv_trl               NUMBER;

   ln_tax_service_rate number;

   --ls_referans........

    CURSOR cur_masraf IS
     SELECT *
     FROM CBS_MASRAF_ITH_IHR
     WHERE referans = ls_referans
     ORDER BY sira_no
    FOR UPDATE;
    row_masraf cur_masraf%ROWTYPE;

    CURSOR cur_tmhg IS
     SELECT *
     FROM CBS_TM_HG_ACILIS
     WHERE referans= ps_referans;
    row_tmhg cur_tmhg%ROWTYPE;

      CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT a
      WHERE referans = ls_referans
        AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
        AND NVL(odenen_tutar,0) < taksit_tutari
     FOR UPDATE;
    row_taksit cur_taksitler%ROWTYPE;

  BEGIN
  --buraya geldiyse masraf ?demesi vard?r. Tarih kontrol? sadece taksitlerde yap?l?r.
  --E?er fi? kesilmesi istenmiyorsa, bu fonksiyon ?a?r?lmamal?d?r....
    ln_fis_no := pn_fis_no;

       OPEN cur_tmhg;
       FETCH cur_tmhg INTO row_tmhg;

    ls_akr_doviz:=row_tmhg.doviz_kodu;
    varchar_list(p_44100_M_HESAP):=row_tmhg.masraf_hesap_no;


----------------
     IF row_tmhg.masraf_hesap_no IS NOT NULL THEN
        varchar_list(p_44100_MHESAP_DVZ):= Pkg_Hesap.HesaptanDovizKoduAl(row_tmhg.masraf_hesap_no);
        varchar_list(p_44100_MHESAP_SUBE):= Pkg_Hesap.HesapSubeAl(row_tmhg.masraf_hesap_no);
         number_list(p_44100_KUR_TUTAR):= Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),1);
      ELSE
          varchar_list(p_44100_MHESAP_DVZ):='';
          varchar_list(p_44100_MHESAP_SUBE):='';
     END IF;
----------------
     varchar_list(p_44100_ISLEM_SUBE) :=row_tmhg.BOLUM_KODU;--PKG_GENEL.bolum_adi_al(row_tmhg.BOLUM_KODU);
     ls_referans := row_tmhg.referans;

    CLOSE cur_tmhg;

    IF varchar_list(p_44100_MHESAP_DVZ) = Pkg_Genel.LC_AL THEN
     boolean_list(p_44100_M_HESAP_TRL) := TRUE;
     boolean_list(p_44100_M_HESAP_DVZ) := FALSE;
    ELSE
     boolean_list(p_44100_M_HESAP_TRL) := FALSE;
     boolean_list(p_44100_M_HESAP_DVZ) := TRUE;
    END IF;
    boolean_list(p_44100_MAS_TP_ANA) := FALSE;
    boolean_list(p_44100_MAS_YP_ANA) := FALSE;
    number_list(p_44100_HABR_TRL) := 0;
    number_list(p_44100_HABR_MDV) := 0;
    varchar_list(p_44100_MAS_HABR_ACIKLAMA) := '';
    boolean_list(p_44100_HABR_VAR) := FALSE;
    number_list(p_44100_POSTA_TRL) := 0;
    number_list(p_44100_POSTA_MDV) := 0;
    varchar_list(p_44100_MAS_POST_ACIKLAMA) := '';
    boolean_list(p_44100_POSTA_VAR) := FALSE;
    number_list(p_44100_TEYIT_TRL) := 0;
    number_list(p_44100_TEYIT_MDV) := 0;
    varchar_list(p_44100_MAS_TEY_ACIKLAMA) := '';
    boolean_list(p_44100_TEYIT_VAR) := FALSE;
    number_list(p_44100_IHBAR_TRL) := 0;
    number_list(p_44100_IHBAR_MDV) := 0;
    varchar_list(p_44100_MAS_IHBAR_ACIKLAMA) := '';
    boolean_list(p_44100_IHBAR_VAR) := FALSE;

    number_list(p_44100_KOM_TOPLAMI) := 0;
    number_list(p_44100_KOM_MDV_TOPLAM) := 0;

    boolean_list(p_44100_SERVICE_TAX_ODENECEK):=FALSE;
    number_list(p_44100_TOPLAM_VERGI_LC) := 0;
    number_list(p_44100_TOPLAM_VERGI_MDV) := 0;
log_at('0a',sqlerrm);
/*
    varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' Customer No:'||row_tmhg.LEHDAR_MUSTERI_NO
                                   ||' -'||Pkg_Musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);
*/
--CQ1405 if lehdar_musteri_no is null VictorK
if row_tmhg.LEHDAR_MUSTERI_NO is null then
varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' Customer No:'||row_tmhg.PRINCIPAL_TITLE ;
else
    varchar_list(p_44100_MAS_ACIKLAMA) := row_tmhg.REFERANS
                                   ||' Customer No:'||row_tmhg.LEHDAR_MUSTERI_NO
                                   ||' -'||Pkg_Musteri.Sf_Musteri_Adi(row_tmhg.LEHDAR_MUSTERI_NO);
end if;
    --varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'LGISSUCOM');
    --varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'MAILCHARGE');
    --varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'COMMUNICAT');
--CQ1405 if musteri_no is null VictorK
if row_tmhg.LEHDAR_MUSTERI_NO is null then
log_at('1a',sqlerrm);
varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'LGISSUCOM');
log_at('2a',sqlerrm);
varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'MAILCHARGE');
log_at('3a',sqlerrm);
varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'COMMUNICAT');
else 
log_at('4a',sqlerrm);        
varchar_list(p_44100_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'LGISSUCOM');
log_at('5a',sqlerrm);
varchar_list(p_44100_POSTA_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'MAILCHARGE');
log_at('6a',sqlerrm);
varchar_list(p_44100_HABERLESME_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_tmhg.LEHDAR_MUSTERI_NO),'COMMUNICAT');
end if;
    boolean_list(p_44100_ODEYEN_LEHDAR) :=FALSE;

     pkg_parametre.Deger('G_SERVICE_TAX_RATE',ln_tax_service_rate);
     if pkg_musteri.musteri_vergiden_muafmi(pkg_hesap.HesaptanMusteriNoAl( varchar_list(p_44100_M_HESAP)) )='H' then
          boolean_list(p_44100_SERVICE_TAX_ODENECEK):=TRUE;
     else
          boolean_list(p_44100_SERVICE_TAX_ODENECEK):=FALSE;
     end if;

    --
    --masraf al?nacak hesab?n bakiyesini al
    ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_44100_M_HESAP));

    OPEN cur_masraf;
    LOOP
      FETCH cur_masraf INTO row_masraf;
      EXIT WHEN cur_masraf%NOTFOUND;

      boolean_list(p_44100_TEYIT_VAR) := FALSE;
      boolean_list(p_44100_IHBAR_VAR) := FALSE;
      boolean_list(p_44100_HABR_VAR) := FALSE;
      boolean_list(p_44100_POSTA_VAR) := FALSE;

      IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
          IF row_masraf.ODEYECEK = 'PRINCIPAL' THEN
                 boolean_list(p_44100_ODEYEN_LEHDAR) :=TRUE;
               ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
              lb_taksit_var := FALSE;
              IF row_masraf.masraf_kodu = 'LCACIHBAR'  THEN     --ihbar masraf?
    --masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                   number_list(p_44100_IHBAR_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                   number_list(p_44100_IHBAR_MDV) := number_list(p_44100_IHBAR_TRL);
                ELSE
                   number_list(p_44100_IHBAR_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_IHBAR_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_IHBAR_MDV)));
                END IF;
    --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
    --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
                ln_borc_tutar := number_list(p_44100_IHBAR_MDV);
                ln_borc_trl := number_list(p_44100_IHBAR_TRL);
                varchar_list(p_44100_MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
                boolean_list(p_44100_IHBAR_VAR) := TRUE;
              ELSIF row_masraf.masraf_kodu = 'COMMUNICAT'  THEN   --haberle?me
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                    number_list(p_44100_HABR_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                    number_list(p_44100_HABR_MDV) := number_list(p_44100_HABR_TRL);
                ELSE
                   number_list(p_44100_HABR_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_HABR_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_HABR_MDV)));
                END IF;
                varchar_list(p_44100_MAS_HABR_ACIKLAMA) := 'COMMUNICATION CHARGE';
                boolean_list(p_44100_HABR_VAR) := TRUE;

                if boolean_list(p_44100_SERVICE_TAX_ODENECEK)=TRUE then
                   number_list(p_44100_TOPLAM_VERGI_LC) := number_list(p_44100_HABR_TRL) * ln_tax_service_rate / 100;
                   number_list(p_44100_TOPLAM_VERGI_MDV) := number_list(p_44100_HABR_MDV) * ln_tax_service_rate / 100;

                   ln_borc_tutar := number_list(p_44100_HABR_MDV)+number_list(p_44100_TOPLAM_VERGI_MDV);
                   ln_borc_trl := number_list(p_44100_HABR_TRL)+number_list(p_44100_TOPLAM_VERGI_LC);
                else
                   ln_borc_tutar := number_list(p_44100_HABR_MDV);
                   ln_borc_trl := number_list(p_44100_HABR_TRL);
                end if;

              ELSIF row_masraf.masraf_kodu = 'MAILCHARGE' THEN   --posta
                IF boolean_list(p_44100_M_HESAP_TRL) THEN
                    number_list(p_44100_POSTA_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                    number_list(p_44100_POSTA_MDV) := number_list(p_44100_POSTA_TRL);
                ELSE
                   number_list(p_44100_POSTA_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                   number_list(p_44100_POSTA_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_POSTA_MDV)));
                END IF;
                varchar_list(p_44100_MAS_POST_ACIKLAMA) := 'MAIL CHARGE';
                boolean_list(p_44100_POSTA_VAR) := TRUE;

                if boolean_list(p_44100_SERVICE_TAX_ODENECEK)=TRUE then
                   number_list(p_44100_TOPLAM_VERGI_LC) := number_list(p_44100_POSTA_TRL) * ln_tax_service_rate / 100;
                   number_list(p_44100_TOPLAM_VERGI_MDV) := number_list(p_44100_POSTA_MDV) * ln_tax_service_rate / 100;

                   ln_borc_tutar := number_list(p_44100_POSTA_MDV)+number_list(p_44100_TOPLAM_VERGI_MDV);
                   ln_borc_trl := number_list(p_44100_POSTA_TRL)+number_list(p_44100_TOPLAM_VERGI_LC);
                else
                   ln_borc_tutar := number_list(p_44100_POSTA_MDV);
                   ln_borc_trl := number_list(p_44100_POSTA_TRL);
                end if;

              ELSIF row_masraf.masraf_kodu =  'LGISSUCOM' THEN  --teyit TAKS?TL? OLUR
                  lb_taksit_var := TRUE;
                  OPEN cur_taksitler;
                  LOOP
                    FETCH cur_taksitler INTO row_taksit;
                    EXIT WHEN cur_taksitler%NOTFOUND;
                    ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
                    IF boolean_list(p_44100_M_HESAP_TRL) THEN
                      number_list(p_44100_TEYIT_TRL) := Pkg_Kur.mb_dak_to_lc(ls_akr_doviz, ln_tahsil_tutar);
                      number_list(p_44100_TEYIT_MDV) := number_list(p_44100_TEYIT_TRL);
                    ELSE
                      number_list(p_44100_TEYIT_MDV) := Pkg_Kur.yuvarla(varchar_list(p_44100_MHESAP_DVZ),Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44100_MHESAP_DVZ), NULL,
                                                    ln_tahsil_tutar, 1, NULL, NULL, 'N', 'A'));
                      number_list(p_44100_TEYIT_TRL) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.mb_dak_to_lc(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_TEYIT_MDV)));
                    END IF;
                    varchar_list(p_44100_MAS_TEY_ACIKLAMA) := row_taksit.taksit_no || '. L/G Charge Installment';
                    ln_borc_tutar := number_list(p_44100_TEYIT_MDV);
                    ln_borc_trl := number_list(p_44100_TEYIT_TRL);
                    lb_taksit_var := TRUE;

                    if nvl(row_tmhg.donem_bas_son,'B') = 'B' then
                      boolean_list(p_44100_MASRAF_GECICI_VAR) := TRUE;
                      boolean_list(p_44100_MASRAF_GECICI_YOK) := FALSE;
                    else
                      boolean_list(p_44100_MASRAF_GECICI_VAR) := FALSE;
                      boolean_list(p_44100_MASRAF_GECICI_YOK) := TRUE;
                    end if;

                    IF ln_son_bakiye >= ln_borc_tutar THEN
                        boolean_list(p_44100_TEYIT_VAR) := TRUE;
                        ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                                             NULL,
                                                             pn_islem_no,
                                                            varchar_list ,
                                                            number_list  ,
                                                            date_list    ,
                                                            boolean_list ,
                                                            NULL,
                                                           FALSE,
                                                            ln_fis_no,
                                                            NULL);

                        UPDATE CBS_MASRAF_ITH_IHR
                           SET tahsil_toplam = NVL(tahsil_toplam,0) + (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0)),
                               tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0))
                         WHERE CURRENT OF cur_masraf;

                           Pkg_Masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

                        UPDATE CBS_MASRAF_TAKSIT
                           SET taksit_odeme_tarih = Pkg_Muhasebe.banka_tarihi_bul,
                               odenen_tutar = taksit_tutari
                         WHERE CURRENT OF cur_taksitler;

                        if nvl(row_tmhg.donem_bas_son,'B') = 'B' then
                          Pkg_Masraf.gecici_gercek_icin_kaydet_eod(pn_islem_no, row_masraf.sira_no, row_taksit.referans,
                                                                   row_masraf.masraf_kodu, row_masraf.vs_no,
                                                                   row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
                                                                        number_list(p_44100_TEYIT_TRL), row_tmhg.masraf_hesap_no,
                                                                   row_tmhg.vade_tarihi, nvl(row_tmhg.vadeli,'E'), row_tmhg.bolum_kodu);
                        end if;

                        ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                        number_list(p_44100_KOM_TOPLAMI) := number_list(p_44100_KOM_TOPLAMI) + ln_borc_trl;
                        number_list(p_44100_KOM_MDV_TOPLAM) := number_list(p_44100_KOM_MDV_TOPLAM) + ln_borc_tutar;
                    END IF;
                  END LOOP;
                  CLOSE cur_taksitler;
              ELSE
                CLOSE cur_masraf;
                 RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
              END IF;
              IF NOT lb_taksit_var THEN
               IF ln_son_bakiye >= ln_borc_tutar THEN --bakiye yeterliyse satiri ekle

                 ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                                    NULL,
                                                    pn_islem_no,
                                                   varchar_list ,
                                                   number_list  ,
                                                   date_list    ,
                                                   boolean_list ,
                                                   NULL,
                                                   FALSE,
                                                     ln_fis_no,
                                                     NULL);
                 Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                               row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

                  UPDATE CBS_MASRAF_ITH_IHR
                     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
                         tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
                   WHERE CURRENT OF cur_masraf;
                  if nvl(row_tmhg.donem_bas_son,'B') = 'B' then
                          pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
                                                               row_masraf.masraf_kodu, row_masraf.vs_no,
                                                               row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
                                                                    number_list(p_44100_TEYIT_TRL), row_tmhg.masraf_hesap_no,
                                                               row_tmhg.vade_tarihi, nvl(row_tmhg.vadeli,'E'));
                        --donem sonu odeme ise ya burada gercek muhasebe yaratilir veya
                        --gecici gibi gonderilirken vadeli Hay?r gonderilir. gunsonunda geciciden al?r
                        --Seville konu?up birini sec.......
                        --taksit tarihinden mi baslasin yoksa odendigi tarihten mi?
                  end if;
                  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                  number_list(p_44100_KOM_TOPLAMI) := number_list(p_44100_KOM_TOPLAMI) + ln_borc_trl;
                  number_list(p_44100_KOM_MDV_TOPLAM) := number_list(p_44100_KOM_MDV_TOPLAM) + ln_borc_tutar;

                  number_list(p_44100_TOPLAM_VERGI_LC) := 0;
                  number_list(p_44100_TOPLAM_VERGI_MDV) := 0;

               END IF;
              END IF;
           END IF; --ihracat?? ?demesi
      END IF;  --tahsil edilmeyen var....

    END LOOP;
    CLOSE cur_masraf;
    IF number_list(p_44100_KOM_MDV_TOPLAM) > 0 THEN
       boolean_list(p_44100_TEYIT_VAR) := FALSE;
       boolean_list(p_44100_IHBAR_VAR) := FALSE;
       boolean_list(p_44100_HABR_VAR)  := FALSE;
       boolean_list(p_44100_POSTA_VAR) := FALSE;
       IF boolean_list(p_44100_M_HESAP_TRL) THEN
          boolean_list(p_44100_MAS_TP_ANA) := TRUE;
       ELSE
          boolean_list(p_44100_MAS_YP_ANA) := TRUE;
       END IF;
        number_list(p_44100_BSMV_TRL) :=Pkg_Kur.YUVARLA(Pkg_Genel.LC_AL,number_list(p_44100_KOM_TOPLAMI)*0.05);
        number_list(p_44100_BSMV_MDV) :=Pkg_Kur.YUVARLA(varchar_list(p_44100_MHESAP_DVZ),number_list(p_44100_KOM_MDV_TOPLAM)*0.05);
         IF boolean_list(p_44100_DVBSMV_EVET)=TRUE THEN
            number_list(p_44100_MASKOMBSMV_TOPLAM) :=Pkg_Kur.YUVARLA(Pkg_Genel.LC_AL,number_list(p_44100_KOM_TOPLAMI)*1.05);
        ELSE
            number_list(p_44100_MASKOMBSMV_TOPLAM) :=number_list(p_44100_KOM_TOPLAMI);
        END IF;


       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 44100,
                                            NULL,
                                            pn_islem_no,
                                           varchar_list ,
                                           number_list  ,
                                           date_list    ,
                                           boolean_list ,
                                           NULL,
                                          FALSE,
                                           ln_fis_no,
                                           NULL);
    END IF;
    pn_fis_no := ln_fis_no;

  END;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

 BEGIN
    p_44100_HABR_TRL := Pkg_Muhasebe.parametre_index_bul('44100_HABR_TRL');
    p_44100_POSTA_TRL := Pkg_Muhasebe.parametre_index_bul('44100_POSTA_TRL');
    p_44100_KOM_TOPLAMI := Pkg_Muhasebe.parametre_index_bul('44100_KOM_TOPLAMI');
    p_44100_M_HESAP := Pkg_Muhasebe.parametre_index_bul('44100_M_HESAP');
    p_44100_M_HESAP_DVZ := Pkg_Muhasebe.parametre_index_bul('44100_M_HESAP_DVZ');
    p_44100_MHESAP_SUBE := Pkg_Muhasebe.parametre_index_bul('44100_MHESAP_SUBE');
    p_44100_ISLEM_SUBE := Pkg_Muhasebe.parametre_index_bul('44100_ISLEM_SUBE');
    p_44100_TEYIT_MDV := Pkg_Muhasebe.parametre_index_bul('44100_TEYIT_MDV');
    p_44100_IHBAR_MDV := Pkg_Muhasebe.parametre_index_bul('44100_IHBAR_MDV');
    p_44100_HABR_MDV := Pkg_Muhasebe.parametre_index_bul('44100_HABR_MDV');
    p_44100_POSTA_MDV := Pkg_Muhasebe.parametre_index_bul('44100_POSTA_MDV');
    p_44100_KOM_MDV_TOPLAM := Pkg_Muhasebe.parametre_index_bul('44100_KOM_MDV_TOPLAM');
    p_44100_MAS_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_ACIKLAMA');
    p_44100_MAS_TEY_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_TEY_ACIKLAMA');
    p_44100_MAS_HABR_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_HABR_ACIKLAMA');
    p_44100_MAS_IHBAR_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_IHBAR_ACIKLAMA');
    p_44100_MAS_POST_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_POST_ACIKLAMA');
    p_44100_KUR_TUTAR := Pkg_Muhasebe.parametre_index_bul('44100_KUR_TUTAR');
    p_44100_TEYIT_VAR := Pkg_Muhasebe.parametre_index_bul('44100_TEYIT_VAR');
    p_44100_IHBAR_VAR := Pkg_Muhasebe.parametre_index_bul('44100_IHBAR_VAR');
    p_44100_HABR_VAR := Pkg_Muhasebe.parametre_index_bul('44100_HABR_VAR');
    p_44100_POSTA_VAR := Pkg_Muhasebe.parametre_index_bul('44100_POSTA_VAR');
    p_44100_M_HESAP_TRL := Pkg_Muhasebe.parametre_index_bul('44100_M_HESAP_TRL');
    p_44100_MHESAP_DVZ := Pkg_Muhasebe.parametre_index_bul('44100_MHESAP_DVZ');
    p_44100_TEYIT_TRL := Pkg_Muhasebe.parametre_index_bul('44100_TEYIT_TRL');
    p_44100_IHBAR_TRL := Pkg_Muhasebe.parametre_index_bul('44100_IHBAR_TRL');
    p_44100_MAS_TP_ANA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_TP_ANA');
    p_44100_MAS_YP_ANA := Pkg_Muhasebe.parametre_index_bul('44100_MAS_YP_ANA');
    p_44100_KOMISYON_DK := Pkg_Muhasebe.parametre_index_bul('44100_KOMISYON_DK');
    p_44100_DVBSMV_EVET := Pkg_Muhasebe.parametre_index_bul('44100_DVBSMV_EVET');
    p_44100_ODEYEN_LEHDAR:= Pkg_Muhasebe.parametre_index_bul('44100_ODEYEN_LEHDAR');
    p_44100_BSMV_TRL:= Pkg_Muhasebe.parametre_index_bul('44100_BSMV_TRL');
    p_44100_BSMV_MDV:= Pkg_Muhasebe.parametre_index_bul('44100_BSMV_MDV');
    p_44100_MASKOMBSMV_TOPLAM:= Pkg_Muhasebe.parametre_index_bul('44100_MASKOMBSMV_TOPLAM');
    p_44100_POSTA_DK:= Pkg_Muhasebe.parametre_index_bul('44100_POSTA_DK');
    p_44100_HABERLESME_DK:= Pkg_Muhasebe.parametre_index_bul('44100_HABERLESME_DK');
    p_44100_MASRAF_GECICI_YOK := Pkg_Muhasebe.parametre_index_bul('44100_MASRAF_GECICI_YOK');
    p_44100_MASRAF_GECICI_VAR := Pkg_Muhasebe.parametre_index_bul('44100_MASRAF_GECICI_VAR');

    p_44100_SERVICE_TAX_ODENECEK := Pkg_Muhasebe.parametre_index_bul('44100_SERVICE_TAX_ODENECEK');
    p_44100_TOPLAM_VERGI_LC := Pkg_Muhasebe.parametre_index_bul('44100_TOPLAM_VERGI_LC');
    p_44100_TOPLAM_VERGI_MDV := Pkg_Muhasebe.parametre_index_bul('44100_TOPLAM_VERGI_MDV');


END;
/

