create PACKAGE Pkg_Tx7059 IS
/**************************************
Name       : PKG_TX7059
Created By : Hakan SAMSA
Purpose	  : Cash Collateral Modification
***************************************/
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
PROCEDURE BilgiAktar(pn_txno IN NUMBER,
		  			 pn_musteri IN NUMBER) ;
FUNCTION Min_Debit_Tutari  RETURN number;
FUNCTION Cash_Coll_Amount (pn_musteri_no number) RETURN number;
FUNCTION Cash_Coll_Account (pn_musteri_no number) RETURN number;
FUNCTION Number_To_Date (pn_gun number,pn_ay number,pn_yil number) RETURN date;
END;


/

