create PACKAGE BODY     PKG_TX1002 IS

  Procedure Yaratma_Oncesi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
    
  Begin
  
log_at('lev_test1','kontral');
   
   End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      log_at('lev_test1','dogrulama');

  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
  Procedure upload(ps_customer_type varchar2,ps_form varchar2) is
  

cursor cur is
select musteri_no
from CBS_MUSTERI
where musteri_tipi_kod='1' ;
curcustom cur%rowtype;
ls_text VARCHAR2(4000);
ln_count number;
ls_filename varchar2(50);
ln_kod_no number;

begin
ln_count:=1;
ls_filename:='upload.csv';
--ln_kod_no:=pkg_genel.genel_kod_al(substr(ls_filename,1,20)); 
LOG_AT('rbolev','dosya_ac','c:\cbs\DOSYA\'||ls_filename||'_'||ln_kod_no||'w');                                                   
  pkg_dosya.Dosya_Ac('c:\cbs\DOSYA\',ls_filename,'w');--открыть файл
  
open cur;
loop
fetch cur into curcustom;
exit when ln_count>10 ;
 ls_text:= to_char(curcustom.musteri_no);                       
pkg_dosya.Kayit_ekle(ls_text);--положить строку
pkg_dosya.SatirAc;--новая линия
ls_text:='';
ln_count:=ln_count+1;
 

end loop;
 pkg_dosya.dosya_kapa('w'); --закрыть файл
close cur;
end;

 PROCEDURE Parsing_address(pn_musteri_no number,ps_full_address out varchar2,ps_city out varchar2,ps_district out varchar2,ps_statement out varchar2,ps_street out varchar2,
 ps_region out varchar2,ps_appartment out varchar2) IS
cursor  cur is
select adres from cbs_musteri_adres
where musteri_no=pn_musteri_no;

cursor city is
select title_city,region 
from cbs_cities_ref_book;

cursor district is
select title_district
from cbs_districts_ref_book;

rec cur%rowtype;
curcity city%rowtype;
curdistr district%rowtype;

ls_address varchar2(200);
ls_city varchar2(20);
ls_district varchar2(30);
ln_count number;
ls_space varchar2(150);
ln_pos number;
ln_i number;
ln_length number;
ls_pos varchar2(20);
ls_len   varchar2(150);
ls_rep varchar2(150);
ls_region varchar2(20);




BEGIN
log_at('rbolev','1',pn_musteri_no);
  if cur%isopen then
     close cur;
 end if;
 if city%isopen then
     close city;
 end if;
 if district%isopen then
     close district;
 end if;
 
open cur;
fetch cur into rec;
if cur%notfound then 
      close cur;
end if; 

   
ps_full_address:=rec.adres;

log_at('rbolev','2',ps_full_address);
ls_address:=rec.adres;
--------------------------------------------dist--------------------- 
 ln_count:=0;
     ln_count:=instr(ls_address,'DIST',1);
     ln_pos:=ln_count+4;
     ls_space:=substr(ls_address,ln_pos,1);

     if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     
    
     ls_space:=substr(ls_address,1,ln_count);
     ps_district:=ls_space;
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
     ln_count:=0;
     ln_count:=instr(ls_address,'Р-Н.',1);
     ln_pos:=ln_count+4;
     ls_space:=substr(ls_address,ln_pos,1);

     if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     
    
     ls_space:=substr(ls_address,1,ln_count);
     ps_district:=ls_space;
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
     ln_count:=0;
     ln_count:=instr(ls_address,'РАЙ.',1);
     ln_pos:=ln_count+4;
     ls_space:=substr(ls_address,ln_pos,1);

     if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     
    
     ls_space:=substr(ls_address,1,ln_count);
     ps_district:=ls_space;
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
     ln_count:=0;
     ln_count:=instr(ls_address,'Р-ОН,',1);
     ln_pos:=ln_count+4;
     ls_space:=substr(ls_address,ln_pos,1);

     if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     
    
     ls_space:=substr(ls_address,1,ln_count);
     ps_district:=ls_space;
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
     ln_count:=0;
     ln_count:=instr(ls_address,'РН.',1);
     ln_pos:=ln_count+3;
     ls_space:=substr(ls_address,ln_pos,1);

     if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     
    
     ls_space:=substr(ls_address,1,ln_count);
     ps_district:=ls_space;
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
      log_at('rbolev','3',ls_address);
--------------------------------------------obl---------------------      
     ln_count:=0;
     ln_count:=instr(ls_address,'OBL',1);
     if ln_count<>0 then
     ln_count:=ln_count+3;
     ls_space:=substr(ls_address,1,ln_count);
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
     ln_count:=0;
     ln_count:=instr(ls_address,'ОБЛ',1);
     if ln_count<>0 then
     ln_count:=ln_count+3;
     ls_space:=substr(ls_address,1,ln_count);
     ls_address:=REPLACE(ls_address, ls_space);
     end if;
      log_at('rbolev','4',ls_address);
--------------------------------------------city---------------------         
open city;
loop
fetch city into curcity;
 EXIT when city%notfound ;
 ls_city:=curcity.title_city;
 ls_region:=curcity.region;
 ls_region:=RTRIM(LTRIM(ls_region,',.; -()'),',.; -()');
ln_count:=instr(ls_address,ls_city,1);
ln_pos:=ln_count+length(ls_city);
ls_space:=substr(ls_address,ln_pos,1);

if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',') or (ln_count<>0 and ls_space='.') or (ln_count<>0 and ls_space='(')  then
ps_city:=ls_city;

if ls_region='chui' then
ps_region:='41708 000 000 00 0 ';
elsif ls_region='talas' then
ps_region:='41707 000 000 00 0 ';
elsif ls_region='osh' then
ps_region:='41706 000 000 00 0 ';
elsif ls_region='batken' then
ps_region:='41705 000 000 00 0 ';
elsif ls_region='naryn' then
ps_region:='41704 000 000 00 0 ';
elsif ls_region='jalal' then
ps_region:='41703 000 000 00 0 ';
elsif ls_region='isik' then
ps_region:='41702 000 000 00 0 ';


end if;

ls_address:=REPLACE(ls_address, ls_city, ' ');
end if;
end loop;
close city;

   log_at('rbolev','5',ps_city||'--'||ls_address);
--------------------------------------------district---------------------      
open district;
 loop
 fetch district into curdistr;
 EXIT when district%notfound;
 
    ls_district:=curdistr.title_district;
    ln_count:=instr(ls_address,ls_district,1);
    ln_pos:=ln_count+length(ls_district);
    ls_space:=substr(ls_address,ln_pos,1);
if (ln_count<>0 and ls_space=' ')or(ln_count<>0 and ls_space=',')  then
     ps_district:=ls_district;
     ls_address:=REPLACE(ls_address, ls_district);
    end if;
    end loop;
    close district;
      log_at('rbolev','6',ps_district||'--'||ls_address);
--------------------------------------------statement---------------------     
     ps_statement:=ls_address;
    
    for i in 1..10 loop
    ps_statement:=RTRIM(LTRIM(ps_statement,',.; -()'),',.; -()'); 
     ps_statement:=LTRIM(RTRIM(ps_statement,',.; -()'),',.; -()');
     ps_statement:=RTRIM(LTRIM(ps_statement,'ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ абвгдеёжзийклмнопрстуфхцчшщъыьэюя'),'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ абвгдеёжзийклмнопрстуфхцчшщъыьэюя ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz');
       ps_statement:=LTRIM(RTRIM(ps_statement,',.; -()'),',.; -()');
        end loop;
         ps_street:=replace(ls_address,ps_statement,' ');
         log_at('rbolev','7',length(ps_statement));
         if length(ps_statement)<>0 then
      for j in 1..length(ps_statement) loop
      if (substr(ps_statement,j,1)='-') or (substr(ps_statement,j,1)=' ') or (substr(ps_statement,j,1)='/') or (substr(ps_statement,j,1)='HOUSE') THEN
      
      ps_appartment:=substr(ps_statement,j+1);
       ps_statement:=substr(ps_statement,1,j-1);
      END IF;
      end loop;
      end if;
    
     log_at('rbolev','8',ps_appartment||'--'||ls_address);
--------------------------------------------street---------------------        
    
    ln_count:=0;
     ln_count:=instr(ps_street,'DIST',1);
     if ln_count<>0 then
      ln_count:=ln_count+1;
     ls_space:=substr(ps_street,1,ln_count);
      ps_street:=REPLACE(ps_street, ls_space);
     end if;
    ln_count:=0;
     ln_count:=instr(ps_street,'VIL',1);
     if ln_count<>0 then
     ln_count:=ln_count+2;
     ls_space:=substr(ps_street,1,ln_count);
      ls_space:=RTRIM(LTRIM(ls_space,',.; -()'),',.; -()'); 
      if ps_city is null then
     ps_city:=ls_space;
     end if;
     ps_street:=REPLACE(ps_street, ls_space);
     ps_street:=RTRIM(LTRIM(ps_street,',.; -()'),',.; -()'); 
     end if;
     ln_count:=instr(ps_street,'MKR',1);
     if ln_count<>0 then
     ln_count:=ln_count+3;
     ls_space:=substr(ps_street,1,ln_count);
     ps_district:=substr(ps_street,1,ln_count);
     ps_street:=REPLACE(ps_street, ls_space);
     
     ps_street:=RTRIM(LTRIM(ps_street,',.; -()'),',.; -()'); 
     
     end if;
 
   
      log_at('rbolev','9',ps_street||'--'||ls_address);
      


        
   
    
    
   
END;
PROCEDURE select_musiz(pn_musteri_no number,ps_isim out varchar2,ps_ikinci_isim out varchar2,ps_soyadi out varchar2,ps_vergi_no out varchar2,ps_uyruk_kod out varchar2,ps_risk_level_code out varchar2,pd_dogum_tarihi out date,
pd_GECERLILIK_TARIHI out date ,ps_pasaport_no out varchar2) is
cursor cur is
select musteri_no,isim,ikinci_isim,soyadi,
vergi_no,uyruk_kod,risk_level_code,dogum_tarihi,
GECERLILIK_TARIHI,pasaport_no
from CBS_VW_MUSTERI_IZLEME
where musteri_no=pn_musteri_no;
curmus cur%rowtype;
begin
  log_at('testrbo8','pkg1002.begin');
if cur%isopen then
     close cur;
 end if;
 open cur;
 fetch cur into curmus;
 if cur%notfound then 
      close cur;
      end if;
          log_at('testrbo8','pkg1002.open');
   ps_isim:= curmus.isim;  
   ps_ikinci_isim:=curmus.ikinci_isim;
   ps_soyadi:=curmus.soyadi;
   ps_vergi_no:=curmus.vergi_no;
   ps_uyruk_kod :=curmus.uyruk_kod;
   ps_risk_level_code :=curmus.risk_level_code;
   pd_dogum_tarihi:=curmus.dogum_tarihi;
   pd_GECERLILIK_TARIHI:=curmus.GECERLILIK_TARIHI;
   ps_pasaport_no :=curmus.pasaport_no;
   log_at('testrbo8','pkg1002.fetch',ps_isim);
 
end;
procedure insert_data(pn_customer_no number,ps_branch varchar2,ps_full_address varchar2, ps_REGION varchar2,ps_CITY varchar2,ps_DISTRICT varchar2,ps_STREET varchar2,ps_STATEMENT_NO varchar2,ps_APPARTMENT varchar2) is
begin
insert into cbs_rbo_reg_tx (customer_no,BRANCH_CODE,full_address,REGION,CITY,DISTRICT,STREET,STATEMENT_NO, APPARTMENT )
  values (pn_customer_no,ps_branch,ps_full_address,ps_REGION,ps_CITY,ps_DISTRICT,ps_STREET,ps_STATEMENT_NO,ps_APPARTMENT); 
  commit;   
  log_at('testrbo8','insert');
  end;
PROCEDURE Parsing_title_opf(pn_customer_no number,ps_title_rus out varchar2,ps_title_eng out varchar2) IS

cursor title is
select ticari_unvan,lokal_unvan 
from cbs_musteri
where musteri_no=pn_customer_no;

cursor opf is
select OPF_TITLE
from cbs_opftitle_ref_book;

curtitle title%rowtype;
curopf opf%rowtype;
ln_count number;
ls_title_rus varchar2(200);
ls_title_eng varchar2(200);
ls_opf varchar2(30);

begin

if title%isopen then
     close title;
 end if;
 if opf%isopen then
     close opf;
 end if;
 open title;
fetch title into curtitle;
 if title%notfound then 
      close title;
end if; 
ls_title_rus:=curtitle.ticari_unvan;
ls_title_eng:=curtitle.lokal_unvan;
open opf;
loop
fetch opf into curopf;
exit when opf%notfound;
ls_opf:=curopf.OPF_TITLE;
--ls_opf:=RTRIM(LTRIM(ls_opf,',.; -()'),',.; -()'); 
log_at('rbo_lev',ls_opf);



ln_count:=instr(ls_title_rus,ls_opf);
if ln_count<>0 then
ps_title_rus:=ls_title_rus;
ps_title_rus:=replace(ps_title_rus,ls_opf);
end if;

ln_count:=instr(ls_title_eng,ls_opf);
if ln_count<>0 then
ps_title_eng:=ls_title_eng;
ps_title_eng:=replace(ls_title_eng,ls_opf);

end if;

end loop;
close opf;


log_at('rbo_lev',ps_title_rus||'  '||ps_title_eng);


end;
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  /*11.01
  ls_kimlik_no varchar2(2000);11.01*/
  ln_musteri_no number := 0;
 cursor customerappr is
 select 
 TX_NO,INN,ECONOMY_SECTOR,NATIONALITY_KOD,SURNAME,NAME,SECOND_NAME,
  TEL_NO,BANK_RELATION_KOD,TYPE_ECONOMY_ACTION,REG_DATE,PASSPORT_NO,
  REG_DEPART ,COUNTRY,REGION,CITY,DISTRICT,STREET,STATEMENT_NO,
  APPARTMENT,PSP ,REF_BOOK_OPF, SWIFT_CODE ,TITLE_RUS ,
  TITLE_ENG ,WEB_SITE, FIRST_REG_DATE  ,REG_COUNTRY,
  STATE_REG_NUMBER,REP_REG_DATE,AUTHORIZED_CAPITAL,CURRENCY,
  AMOUNT,STATE_SHARE ,TYPE_LICENSE_ACT,SERIAL_NO,
  GRANT_LICENSE_DATE,GRANT_DEP,TERM_ACT_LICENSE,CUSTOMER_TYPE,
  RISK_LEVEL,TERM_ACT_PASSPORT,CUSTOMER_NO,BRANCH_CODE,REGION_NO_RESIDENT 
  from cbs_rbo_reg_tx
  where tx_no=pn_islem_no;  
  
  appr customerappr%rowtype;
  
  cursor benefeciaryappr is
  select 
  TX_NO ,  INN,  SURNAME_BENEFECIARY ,  SECOND_NAME_BENEFECIARY ,NAME_BENEFECIARY,
  PASSPORT_NO,TERMS_ACT,REG_DEPART_NO,  REG_COUNTRY,REGION,  CITY,
  DISTRICT,  STREET,  STATEMENT_NO,  APPARTMENT ,
  PERCENT_CAPITAL,  RISK_LEVEL ,  PSP,  REF_BOOK_OPF ,  TITLE_RUS ,
  TITLE_ENG ,  REG_DATE,  REG_NO ,  REG_COUNTRY_BENEFECIARY,  ACTIVITY,region_no_resident  
  from CBS_MUSTERI_BASVURU_BENEF
  where tx_no=pn_islem_no;
  
  apprben benefeciaryappr%rowtype;
  
 

  Begin
  delete from cbs_rbo_reg_tx where INN is null  and NATIONALITY_KOD is null and SURNAME is null
 and NAME is null and SECOND_NAME is null and TITLE_RUS is null and TITLE_ENG is null and SWIFT_CODE is null and COUNTRY is null and REGION is null and
 CITY is null and DISTRICT is null and STREET is null and STATEMENT_NO is null;
  ---------------- cursor customerappr
 if customerappr%isopen then
 close customerappr;
 end if;
 open customerappr;
 fetch customerappr into appr;
 

 
 
 
 
  if customerappr%notfound then
  close customerappr;
  end if;
  ----------------- cursor benefeciaryappr
  if benefeciaryappr%isopen then
 close benefeciaryappr;
 end if;
 open benefeciaryappr;

 
  if benefeciaryappr%notfound then
  close benefeciaryappr;
  end if;
  log_at('rbo1','upmus',appr.TITLE_ENG);
     log_at('rbo1','upadr',appr.TITLE_RUS);
update cbs_musteri
set 
    vergi_no=appr.INN,
    ECONOMY_SECTOR=appr.ECONOMY_SECTOR,
    NATIONALITY_KOD=appr.NATIONALITY_KOD,
    soyadi=appr.SURNAME,
    isim=appr.NAME,
    ikinci_isim=appr.SECOND_NAME,
    BANK_RELATION_KOD=appr.BANK_RELATION_KOD,
    TYPE_ECONOMY_ACTION=appr.TYPE_ECONOMY_ACTION,
    dogum_tarihi=appr.REG_DATE,
    pasaport_no=appr.passport_no,
    verildigi_yer=appr.REG_DEPART,
    PSP_KOD=appr.psp,
    REF_BOOK_OPF=appr.REF_BOOK_OPF,
    bic_kod=appr.SWIFT_CODE,
    lokal_unvan =appr.TITLE_RUS,
    ticari_unvan=appr.TITLE_ENG,
    WEB_SITE=appr.WEB_SITE,
    FIRST_REG_DATE=appr.FIRST_REG_DATE,
    REG_COUNTRY=appr.REG_COUNTRY,
    STATE_REG_NUMBER=appr.STATE_REG_NUMBER,
    REP_REG_DATE=appr.REP_REG_DATE,
    AUTHORIZED_CAPITAL=appr.AUTHORIZED_CAPITAL,
    CURRENCY=appr.CURRENCY,
    AMOUNT=appr.AMOUNT,
    STATE_SHARE=appr.STATE_SHARE,
    TYPE_LICENSE_ACT=appr.TYPE_LICENSE_ACT,
    SERIAL_NO=appr.SERIAL_NO,
    GRANT_LICENSE_DATE=appr.GRANT_LICENSE_DATE,
    GRANT_DEP=appr.GRANT_DEP,
    TERM_ACT=appr.TERM_ACT_LICENSE,
    musteri_tipi_kod=appr.CUSTOMER_TYPE,
    RISK_LEVEL_code=appr.RISK_LEVEL,
    validity_date=appr.TERM_ACT_PASSPORT,
    bolum_kodu=appr.BRANCH_CODE
    /*INN_BENEFECIARY = apprben.INN,               
  SURNAME_BENEFECIARY = apprben.SURNAME_BENEFECIARY ,         
  SECOND_NAME_BENEFECIARY= apprben.SECOND_NAME_BENEFECIARY ,        
  NAME_BENEFECIARY= apprben.NAME_BENEFECIARY ,                
  PASSPORT_NO_BENEFECIARY= apprben.PASSPORT_NO ,         
  TERMS_ACT_BENEFECIARY= apprben.TERMS_ACT ,          
  REG_DEPART_NO_BENEFECIARY= apprben.REG_DEPART_NO ,      
  REG_COUNTRY_BENEFECIARY= apprben.REG_COUNTRY ,       
  REGION_BENEFECIARY= apprben.REGION ,             
  CITY_BENEFECIARY= apprben.CITY ,               
  DISTRICT_BENEFECIARY= apprben.DISTRICT ,           
  STREET_BENEFECIARY= apprben.STREET ,              
  STATEMENT_NO_BENEFECIARY= apprben.STATEMENT_NO ,      
  APPARTMENT_BENEFECIARY= apprben.APPARTMENT ,         
  PERCENT_CAPITAL_BENEFECIARY= apprben.PERCENT_CAPITAL ,    
  RISK_LEVEL_BENEFECIARY= apprben.RISK_LEVEL ,         
  PSP_BENEFECIARY = apprben.PSP ,                
  REF_BOOK_OPF_BENEFECIARY= apprben.REF_BOOK_OPF ,        
  TITLE_RUS_BENEFECIARY = apprben.TITLE_RUS ,          
  TITLE_ENG_BENEFECIARY= apprben.TITLE_ENG ,           
  REG_DATE_BENEFECIARY= apprben.REG_DATE ,            
  REG_NO_BENEFECIARY= apprben.REG_NO ,              
  REG_COUNTRY_CORP_BENEFECIARY= apprben.REG_COUNTRY_BENEFECIARY ,   
  ACTIVITY_BENEFECIARY= apprben.ACTIVITY ,   
  REGION_NO_RESIDENT_BENEFECIARY = apprben.REGION_NO_RESIDENT*/
     where musteri_no=appr.CUSTOMER_NO;
   
loop
fetch benefeciaryappr into apprben;
exit when benefeciaryappr%notfound;

insert into cbs_musteri_beneficiary   (TX_NO ,inn_customer,customer_no,  INN,  SURNAME_BENEFECIARY ,  SECOND_NAME_BENEFECIARY ,NAME_BENEFECIARY,
  PASSPORT_NO,TERMS_ACT,REG_DEPART_NO,  REG_COUNTRY,REGION,  CITY,
  DISTRICT,  STREET,  STATEMENT_NO,  APPARTMENT ,  PERCENT_CAPITAL,  RISK_LEVEL ,  PSP,  REF_BOOK_OPF ,  TITLE_RUS ,
  TITLE_ENG ,  REG_DATE,  REG_NO ,  REG_COUNTRY_BENEFECIARY,  ACTIVITY,region_no_resident) 
  values(apprben.TX_NO,appr.inn,appr.CUSTOMER_NO,apprben.INN, apprben.SURNAME_BENEFECIARY,apprben.SECOND_NAME_BENEFECIARY,apprben.NAME_BENEFECIARY,apprben.PASSPORT_NO,
   apprben.TERMS_ACT,apprben.REG_DEPART_NO,apprben.REG_COUNTRY,apprben.REGION,apprben.CITY,apprben.DISTRICT,apprben.STREET,apprben.STATEMENT_NO,
   apprben.APPARTMENT, apprben.PERCENT_CAPITAL,apprben.RISK_LEVEL,apprben.PSP,apprben.REF_BOOK_OPF,apprben.TITLE_RUS,apprben.TITLE_ENG,apprben.REG_DATE,
   apprben.REG_NO,apprben.REG_COUNTRY_BENEFECIARY,apprben.ACTIVITY,apprben.REGION_NO_RESIDENT );
end loop;
    
  update   cbs_musteri_adres
  set gsm_no=appr.TEL_NO,
     COUNTRY=appr.COUNTRY,
     REGION_kod=appr.REGION,
    CITY=appr.CITY,
    microdistrict=appr.DISTRICT,
    STREET=appr.STREET,
    STATE_NO=appr.STATEMENT_NO,
    APPARTMENT_no=appr.APPARTMENT
 where musteri_no=appr.CUSTOMER_NO;
 
     log_at('rbo1','final');

commit;
  
  
  
  
  
 
  
    
 End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;
  End;
  
 
  end;
/

