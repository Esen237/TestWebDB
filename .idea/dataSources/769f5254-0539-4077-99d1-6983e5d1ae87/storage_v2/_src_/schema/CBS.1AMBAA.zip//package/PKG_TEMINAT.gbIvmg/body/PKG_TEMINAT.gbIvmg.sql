create PACKAGE BODY     pkg_teminat
IS
/******************************************************************************************************************/
/*   Function sf_teminat_tutari_hesapla                                                             */
/*   teminat doviz kodu kredi doviz kodundan farkl? ise al?nan tutar hesaplan?r                          */
/******************************************************************************************************************/
  Function sf_teminattutar_hesdovizcevir( pn_kullanilan_teminat_tutari cbs_teminat.KULLANILAN_TUTAR%type,
    		   						 ps_teminat_doviz_kodu   cbs_teminat.TEMINAT_DOVIZ_KODU%type,
									 ps_kredi_doviz_kodu     cbs_teminat.TEMINAT_DOVIZ_KODU%type,
									 ps_hesabin_dovizine	 varchar2 default null)
									 return  cbs_teminat.KULLANILAN_TUTAR%type
   IS
      ln_kur                NUMBER;
      ln_kullanilan_tutar   cbs_teminat.kullanilan_tutar%TYPE;
      ln_teminat_kur        cbs_teminat.kullanilan_tutar%TYPE;
      ln_kredi_kur          cbs_teminat.kullanilan_tutar%TYPE;
   BEGIN
      /* Bankam?z DAK */
      ln_teminat_kur := pkg_kur.doviz_doviz_karsilik (ps_teminat_doviz_kodu,pkg_genel.lc_al,NULL, 1, 1, NULL,NULL,'O','A' );
      ln_kredi_kur :=   pkg_kur.doviz_doviz_karsilik (ps_kredi_doviz_kodu,pkg_genel.lc_al,NULL,1,1,NULL,NULL,'O', 'A' );

	  if ps_hesabin_dovizine is null then
	  /*kredi hesabin dovizine cevrilir */
--	        ln_kullanilan_tutar := PKG_KUR.YUVARLA(ps_kredi_doviz_kodu,  pn_kullanilan_teminat_tutari * (ln_teminat_kur / ln_kredi_kur));
			ln_kullanilan_tutar :=pn_kullanilan_teminat_tutari * (ln_teminat_kur / ln_kredi_kur);
	  ELSE
	 /* teminatin dovizine cevrilir */
--	       ln_kullanilan_tutar :=  PKG_KUR.YUVARLA(ps_teminat_doviz_kodu,  pn_kullanilan_teminat_tutari * ( ln_kredi_kur /ln_teminat_kur));
		    ln_kullanilan_tutar :=   pn_kullanilan_teminat_tutari * ( ln_kredi_kur /ln_teminat_kur);
	 end if;
      RETURN nvl(ln_kullanilan_tutar,0);
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '490' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   END;

/******************************************************************************************************************/
/*   Function  sf_teklif_teminat_tutari                                                                 */
/*  Kredi teklif teminat tutari																		    */
/******************************************************************************************************************/
 Function sf_teklif_teminat_tutari(  pn_teklif_tutar         cbs_kredi_teklif_satir_teminat.TUTAR%type,
      		   						  ps_teminat_doviz_kodu   cbs_teminat.TEMINAT_DOVIZ_KODU%type,
  		   							  pn_hesap_tutar	 	  cbs_hesap_kredi.TUTAR%type,
									  ps_hesap_doviz_kodu     cbs_hesap_kredi.doviz_kodu%type,
									  pn_marj				  cbs_kredi_teklif_satir_teminat.MARJ%type,
									  pn_katilim_orani    	  cbs_kredi_teklif_satir_teminat.KATILIM_ORANI%type,
									  ps_teklif_tutari_ise	 varchar2 default null)

									  return number
  is
       ln_teklif_tutar	 cbs_kredi_teklif_satir_teminat.TUTAR%type;
	   hatali_durum		 exception ;
  Begin

  /* kredi teklif ?artlar?nda teminat tutar? bo? ise marj veya kat?l?m oran?ndan hesaplanmal?d?r. */

	  if pn_teklif_tutar is not null then
	    if ps_teklif_tutari_ise is null then
	      ln_teklif_tutar := pkg_teminat.sf_teminattutar_hesdovizcevir( pn_teklif_tutar ,ps_teminat_doviz_kodu,ps_hesap_doviz_kodu);
		else
		   ln_teklif_tutar := pn_teklif_tutar;
		 end if;
      else
	  /* kredi hesap a??l?? tutar? marj oran? kadar eklenerek teminat tutari bulunur */
	  	    if pn_marj	is not null then
			      ln_teklif_tutar :=   pn_hesap_tutar +  (pn_hesap_tutar * pn_marj) /100;
			else
				if pn_katilim_orani is not null then
    			      ln_teklif_tutar := (  pn_hesap_tutar * pn_katilim_orani)  / 100;
				   else
				   	   raise hatali_durum;
				end if;
		    end if;
	  end if;

	  return nvl(ln_teklif_tutar,0);

    EXCEPTION
      when  hatali_durum   then
	        raise_application_error (-20100, pkg_hata.getucpointer || '520' ||  pkg_hata.getucpointer    );
      WHEN OTHERS      THEN
            raise_application_error (-20100, pkg_hata.getucpointer || '521' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

   End;


/******************************************************************************************************************/
/*   Procedure teklif_kosullari_karsilandimi                                                           */
/*   kredi teklifin kosullarinin karilanip karsilanmadigi kontrol edilir                               */
/******************************************************************************************************************/
   PROCEDURE teklif_kosullari_karsilandimi (
   			 pn_islem_no	 			     number ,
   			 pn_kredi_teklif_satir_numara    number,
			 pn_kredi_hesap_tutar number,
             ps_kredi_hesap_doviz_kodu varchar2 ,
			 ps_karsilandimi out varchar2,
 			 ps_mesaj		 out varchar2 ,
 			 ps_kredi_endeksdoviz varchar2 default null)
   IS
      ln_teklif_no                cbs_kredi_teklif.teklif_no%TYPE;
      ln_teklif_satir_numara      cbs_hesap_kredi_islem.kredi_teklif_satir_numara%TYPE;
      ls_teminat_kodu             cbs_teminat_alt_kodlari.teminat_kodu%TYPE;
      ls_teminat_alt_kodu         cbs_teminat_alt_kodlari.teminat_alt_kodu%TYPE;
      ln_alinan_tutar             NUMBER;
      ln_alinan_toplam_tutar      NUMBER;
      ln_alinmasi_gereken_tutar   NUMBER;
      ln_mevcut                   NUMBER  := 0;
      ln_hesap_islem              NUMBER  := 0;
      ln_teklif_islem             NUMBER  := 0;
      ln_teminat_islem            NUMBER  := 0;
	  ls_hesap_doviz_kodu		  cbs_hesap_kredi.DOVIZ_KODU%type;
	  ls_teklif_doviz_kodu		  cbs_hesap_kredi.DOVIZ_KODU%type;
	  ln_hesap_tutar			  number;
	  ln_teklif_doviz_tutar		  number;
	  ln_alinan_toplamtutar_tekdoviz number := 0;
      teklif_karsilanmamis        exception;
      hic_teminat_girilmemis      exception;
	  grup_teklif_karsilanmamis	  exception;
      toplam_teklif_karsilanmamis exception;
	  gruptoplam_teklif_karsilnmamis exception;
	  ls_teminat_kodacik 		  varchar(2000) := '' ;
	  ls_teminat_altkodacik	  	  varchar(2000) := '' ;
	  ln_grup_no			  	  number:= 0;
	  ln_grup_karsilanmis	  	  number := 0;
   	  ls_aranilan_doviz_kodu	  cbs_hesap_kredi.doviz_kodu%type;
	  ln_kredi_hesap_no number;
	  ld_acilis_tarihi date ;
	  ln_alma_gun_sayisi number := 0;
/* grup no 0 dan fakl? olanlar icin veya kosulu ile bak?lacakt?r */
	  	cursor cursor_grup1 is
         SELECT distinct GRUP_NO grup_no
         FROM cbs_vw_teklif_satir_teminat
         WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
			AND nvl(alma_gun_sayisi,0) <= ln_alma_gun_sayisi
			group by  GRUP_NO;


/* teklifdeki alma gun sayisi girilmemi? olan kay?tlar i?in teminat ko?ullar? a??l?? s?ras?nda kar??lanmal?d?r. */
/* teklif satirindaki girilen de?erlere g?re hesaplanan teminat tutar? hesab?n d?viz kodundad?r.*/
/* 1. a?amada tutar alan? dolu olanlar i?in teklif ko?ullar? ayn? doviz kodunda kar??lanmal?*/


      CURSOR cursor_teklif_satir_toplam_1
      IS
         SELECT GRUP_NO,
		 		teklif_no,
				teklif_satir_no,
		 		teminat_kodu,
				teminat_alt_kodu,
				doviz_kodu teklif_doviz_kodu,
		 		nvl(doviz_kodu,ls_hesap_doviz_kodu) doviz_kodu,
                nvl(sum(pkg_teminat.sf_teklif_teminat_tutari( tutar,
      		   						                      nvl(doviz_kodu,ls_hesap_doviz_kodu),
  		   							 				      ln_hesap_tutar	,
									  				      ls_hesap_doviz_kodu,
									  				      marj,
									  				      katilim_orani)),0) tutar,
                nvl(sum(pkg_teminat.sf_teklif_teminat_tutari( tutar,
    		   						                      nvl(doviz_kodu,ls_hesap_doviz_kodu),
  		   							 				      ln_hesap_tutar	,
									  				      ls_hesap_doviz_kodu,
									  				      marj,
									  				      katilim_orani
														  ,'ORIGINKOD'
														  )),0)  teklif_doviz_tutar
           FROM cbs_vw_teklif_satir_teminat
          WHERE teklif_no = ln_teklif_no
            AND teklif_satir_no = ln_teklif_satir_numara
			AND nvl(alma_gun_sayisi,0) <= ln_alma_gun_sayisi
	--		and  nvl(tutar,0)<> 0

			and grup_no = ln_grup_no
			group by  GRUP_NO,
				  	  teklif_no,
					  teklif_satir_no,
				  	  teminat_kodu,
					  teminat_alt_kodu,
					  doviz_kodu ,
					  nvl(doviz_kodu,ls_hesap_doviz_kodu);

      CURSOR cur_teminat_islem
      IS
         SELECT  teminat_kodu,
		 		 teminat_alt_kodu ,
		 		 teminat_doviz_kodu,
		 		 sum(NVL (kullanilan_tutar, 0)) kullanilan_tutar
		 FROM cbs_teminat_islem
          WHERE tx_no = pn_islem_no
            AND teminat_kodu = ls_teminat_kodu
            AND teminat_alt_kodu = nvl(ls_teminat_alt_kodu,teminat_alt_kodu)
            AND teminat_durumu = 'ACIK'
			AND PKG_TEMINAT.SF_TEMINAT_DURUMU_UYGUNMU( TEMINAT_KODU, REFERANS, REF_CEK_NO, BOLUM_KODU, SENET_NO, MUSTERI_NO, KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO ,SOZLESME_NO,EK_SOZLESME_NO)= 'E'
			AND teminat_doviz_kodu = nvl(ls_aranilan_doviz_kodu,teminat_doviz_kodu )
			 group by 	teminat_kodu,
			 	   		teminat_alt_kodu ,
						teminat_doviz_kodu;
 BEGIN
   ps_karsilandimi := 'E';
   ln_teminat_islem := 0;
   ln_teklif_no := pkg_kredi.SF_SATIRNODAN_TEKLIFNOAL( pn_kredi_teklif_satir_numara);
   ln_teklif_satir_numara := pn_kredi_teklif_satir_numara;
   ln_hesap_tutar	:= pn_kredi_hesap_tutar;
   ls_hesap_doviz_kodu :=nvl( ps_kredi_endeksdoviz,ps_kredi_hesap_doviz_kodu);
 /* 070604 sevalb*/
 begin

   select teminat_hesap_no
   into  ln_kredi_hesap_no
   from cbs_teminat_islem
   where tx_no = pn_islem_no;

   if nvl(ln_kredi_hesap_no,0) <> 0 then
   	  select acilis_tarihi
	  into ld_acilis_tarihi
	  from cbs_hesap_kredi
	  where hesap_no = ln_kredi_hesap_no;
  	  ln_alma_gun_sayisi := abs(pkg_muhasebe.banka_tarihi_bul - nvl(ld_acilis_tarihi,pkg_muhasebe.banka_tarihi_bul ) );
   end if;
 exception when others then null;
 end;


 FOR cur_grup in cursor_grup1 Loop
 	  ln_grup_no := cur_grup.grup_no;
	  ln_grup_karsilanmis :=0 ;
  	  ls_aranilan_doviz_kodu :=null;
	/* 1. a?ama tutar alan? dolu ise */


         FOR cur_teklif_satir_toplam_1 IN cursor_teklif_satir_toplam_1
         LOOP
            ls_teminat_kodu            := cur_teklif_satir_toplam_1.teminat_kodu;
            ls_teminat_alt_kodu 	   := cur_teklif_satir_toplam_1.teminat_alt_kodu;
            ln_alinmasi_gereken_tutar  := cur_teklif_satir_toplam_1.tutar;
			ln_teklif_doviz_tutar      := cur_teklif_satir_toplam_1.teklif_doviz_tutar;
			ls_teklif_doviz_kodu	   := cur_teklif_satir_toplam_1.doviz_kodu;
            ln_alinan_toplam_tutar 	   := 0;
            ln_alinan_tutar 		   := 0;
            ln_mevcut := 1;
			ls_aranilan_doviz_kodu :=null;
	/* teklif doviz kodu dolu ise teklifin doviz kodunda aran?r, bos ise 15 sozlesme icin kredi hesap doviz kodunda digerlerinde kosul aranmaz */
			if cur_teklif_satir_toplam_1.teklif_doviz_kodu is null then
			   if  ls_teminat_kodu = '15' then /*sozlesmeler de kredi hesab?n?n doviz kodu */
			   	   ls_aranilan_doviz_kodu := ls_hesap_doviz_kodu;
			   else
			        ls_aranilan_doviz_kodu  := null;
				end if;
			 else
			 		ls_aranilan_doviz_kodu  := cur_teklif_satir_toplam_1.teklif_doviz_kodu;
			 end if;


            FOR cur_teminat IN cur_teminat_islem
            LOOP
               ln_teminat_islem := ln_teminat_islem + 1;
               ln_alinan_tutar := cur_teminat.kullanilan_tutar;

--               IF ps_kredi_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu   THEN
				  IF    ls_hesap_doviz_kodu <> cur_teminat.teminat_doviz_kodu then
                      ln_alinan_tutar :=  pkg_teminat.sf_teminattutar_hesdovizcevir
                                             (ln_alinan_tutar,
                                              cur_teminat.teminat_doviz_kodu,
                                              ls_hesap_doviz_kodu--ps_kredi_hesap_doviz_kodu
                                             );
		        END IF;
			    ln_alinan_toplam_tutar := NVL (ln_alinan_toplam_tutar, 0)  + NVL (ln_alinan_tutar, 0);
            END LOOP;
/* grup numaras? 0 ise AND ile bagli kosullard?r , karsilanmama durumu raise edilir.*/
            IF NVL (ln_alinmasi_gereken_tutar, 0) >  NVL (ln_alinan_toplam_tutar, 0) and nvl(ln_grup_no,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
		       ps_karsilandimi := 'H';

            --   RAISE teklif_karsilanmamis;
				  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
				  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

				     if ls_teklif_doviz_kodu is null then
					 	ln_alinmasi_gereken_tutar := nvl(ln_alinmasi_gereken_tutar,0);
						ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
					 END IF;
					 ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );
			         ps_mesaj := pkg_hata.generatemessage(
			                                    pkg_hata.getucpointer
			                                  || '492'
			                                  || pkg_hata.getdelimiter
			                                  || ls_teminat_kodacik
			                                  || pkg_hata.getdelimiter
			                                  || ls_teminat_altkodacik
			                                  || pkg_hata.getdelimiter
			                                  || TO_CHAR (ln_teklif_doviz_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
											  || ls_teklif_doviz_kodu
			                                  || pkg_hata.getdelimiter
			                                  || TO_CHAR ( ln_alinan_toplamtutar_tekdoviz) --'FM999G999G999G999G999G999G999G999G999D00')
											  || ls_teklif_doviz_kodu
			                                  || pkg_hata.getdelimiter
			                                  || pkg_hata.getucpointer
			                                 );

            END IF;

			IF NVL (ln_alinmasi_gereken_tutar, 0) <=  NVL (ln_alinan_toplam_tutar, 0) and nvl(ln_grup_no,0) <> 0  THEN
               /* grup olarak alinmasi gereken tutar kar??lanm??*/
               ln_grup_karsilanmis := ln_grup_karsilanmis + 1;
            END IF;
         END LOOP;
/*gruplar icin karsilanma durumu kontrol edilir.*/
        IF nvl(ln_grup_no,0) <> 0 and  nvl(ln_grup_karsilanmis,0) = 0  THEN
               /* alinmasi gereken tutar kar??lanmam??*/
		       ps_karsilandimi := 'H';
             --  RAISE grup_teklif_karsilanmamis;
	   	 	  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
			  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

			     if ls_teklif_doviz_kodu is null then
					 	ln_teklif_doviz_tutar := nvl(ln_alinmasi_gereken_tutar,0);
						ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
				 END IF;
		 	 	 ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );


	             ps_mesaj := pkg_hata.generatemessage(
			                                     pkg_hata.getucpointer
			                                  || '680'
			                                  || pkg_hata.getdelimiter
			                                  || ls_teminat_kodacik
			                                  || pkg_hata.getdelimiter
			                                  || ls_teminat_altkodacik
			                                  || pkg_hata.getdelimiter
			                                  || TO_CHAR (ln_teklif_doviz_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
											  || ls_teklif_doviz_kodu
			                                  || pkg_hata.getdelimiter
			                                  || TO_CHAR ( ln_alinan_toplamtutar_tekdoviz) --'FM999G999G999G999G999G999G999G999G999D00')
											  || ls_teklif_doviz_kodu
			                                  || pkg_hata.getdelimiter
			                                  || pkg_hata.getucpointer
			                                 );

         END IF;
END LOOP;

      IF ln_teminat_islem = 0 AND ln_mevcut <> 0
      THEN
         /* teminat islem giri?i yap?lmam??*/
	     ps_karsilandimi := 'H';
        -- RAISE hic_teminat_girilmemis;
           ps_mesaj := pkg_hata.generatemessage(
                                     pkg_hata.getucpointer
                                  || '493'
                                  || pkg_hata.getucpointer
                                 );

      END IF;
   EXCEPTION
      WHEN hic_teminat_girilmemis
      THEN
         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '493'
                                  || pkg_hata.getucpointer
                                 );
      WHEN teklif_karsilanmamis
      THEN
	  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
	  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

	     if ls_teklif_doviz_kodu is null then
		 	ln_teklif_doviz_tutar := nvl(ln_alinmasi_gereken_tutar,0);
			ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
		 END IF;
		 	 	 ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );


         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '492'
                                  || pkg_hata.getdelimiter
                                  || ls_teminat_kodacik
                                  || pkg_hata.getdelimiter
                                  || ls_teminat_altkodacik
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (ln_teklif_doviz_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR ( ln_alinan_toplamtutar_tekdoviz) --'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
      WHEN grup_teklif_karsilanmamis
      THEN
	  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
	  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

	     if ls_teklif_doviz_kodu is null then
		 	ln_teklif_doviz_tutar := nvl(ln_alinmasi_gereken_tutar,0);
			ls_teklif_doviz_kodu  := ls_hesap_doviz_kodu;
		 END IF;
		 	 	 ln_alinan_toplamtutar_tekdoviz := pkg_kur.doviz_doviz_karsilik (ls_hesap_doviz_kodu,ls_teklif_doviz_kodu,NULL,  ln_alinan_toplam_tutar, 1, NULL,NULL,'O','A' );


         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '680'
                                  || pkg_hata.getdelimiter
                                  || ls_teminat_kodacik
                                  || pkg_hata.getdelimiter
                                  || ls_teminat_altkodacik
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (ln_teklif_doviz_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR ( ln_alinan_toplamtutar_tekdoviz) --'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
      WHEN TOPLAM_teklif_karsilanmamis
      THEN
  	  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
	  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '562'
                                  || pkg_hata.getdelimiter
                                  ||  ls_teminat_kodacik
                                  || pkg_hata.getdelimiter
                                  ||  ls_teminat_altkodacik
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (ln_alinmasi_gereken_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR ( ln_alinan_toplam_tutar) --'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );

      WHEN gruptoplam_teklif_karsilnmamis
      THEN
  	  	 ls_teminat_kodacik    := ls_teminat_kodu ||'-' || Sf_Teminat_Kod_Aciklamasi( ls_teminat_kodu) ;
	  	 ls_teminat_altkodacik := ls_teminat_alt_kodu ||'-' || Sf_Teminat_alt_Kod_Aciklamasi( ls_teminat_kodu,ls_teminat_alt_kodu) ;

         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '681'
                                  || pkg_hata.getdelimiter
                                  ||  ls_teminat_kodacik
                                  || pkg_hata.getdelimiter
                                  ||  ls_teminat_altkodacik
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (ln_alinmasi_gereken_tutar) --,'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR ( ln_alinan_toplam_tutar) --'FM999G999G999G999G999G999G999G999G999D00')
								  || ls_teklif_doviz_kodu
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );


      WHEN OTHERS
      THEN
              raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '502'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END;


/******************************************************************************************************************/
/*   Function sf_teminat_nakdi_hesap_urunmu                                                            */
/*   teminat nakdi hesap ?r?n lov seciminde olabilecek ?r?nler                                      */
/******************************************************************************************************************/
  Function sf_teminat_nakdi_hesap_urunmu(ps_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type,ps_urun_Tur varchar2,ps_urun_sinif varchar2) return varchar2
   IS
      ls_mevcut   VARCHAR2 (1) := 'H';
   BEGIN

   if ps_urun_Tur = 'COLLATERAL' then
	      IF ps_doviz_kodu = pkg_genel.lc_al
	      THEN
	         IF instr(ps_urun_sinif, 'LC') > 0   --sevalb 010507
	         THEN
	            ls_mevcut := 'E';
	         ELSE
	            ls_mevcut := 'H';
	         END IF;
	      ELSE
	         IF instr(ps_urun_sinif, 'FC') > 0   --sevalb 010507
	         THEN
	            ls_mevcut := 'E';
	         ELSE
	            ls_mevcut := 'H';
	         END IF;
	      END IF;
	else
		  ls_mevcut :=  'H';
	end if;

     RETURN ls_mevcut;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

/******************************************************************************************************************/
/* Function  sf_teminat_hesap_uygunmu                                                                */
/* Lov icerisinde kosullar? sa?lamak amac?yla yaz?lm??t?r.
/* teminat hesap vadesiz ise lov  E  vadeli ve vade tarihi islem tarihi ise E diger durumda H dondurulur        */
/******************************************************************************************************************/
   FUNCTION sf_teminat_hesap_uygunmu (pn_hesap_no cbs_hesap.hesap_no%TYPE)
      RETURN VARCHAR2 is
	   ls_modul_tur_kod  varchar2(2000);
	   ld_vade_tarihi	 date;
	    ls_uygun 		 varchar2(1) := 'H';
   BEGIN
      SELECT modul_tur_kod, vade_tarihi
        INTO ls_modul_tur_kod, ld_vade_tarihi
        FROM cbs_vw_hesap_izleme
       WHERE hesap_no = pn_hesap_no AND
	   		 pkg_hesap.personel_hesap_mi(hesap_no) = 0 and
	   		 (
			  ( modul_tur_kod =PKG_HESAP.MODUL_TUR_VADESIZ and urun_tur_kod  in ('CURRENT' , 'DEMAND DEP') )
			  or
			 ( modul_tur_kod = PKG_HESAP.MODUL_TUR_VADELI and  urun_tur_kod   in ('SHORT TERM' , 'OVERNIGHT' , 'LONG TERM' , 'MEDIUMTERM'))
			 );

      IF ls_modul_tur_kod is not null then
		 IF ls_modul_tur_kod = pkg_hesap.modul_tur_vadesiz
	      	THEN
	         ls_uygun := 'E';
	      	ELSE
	         IF ld_vade_tarihi = pkg_muhasebe.banka_tarihi_bul
	         THEN
	            ls_uygun := 'E';
	         ELSE
	            ls_uygun := 'H';
	         END IF;
	      END IF;
	    END IF;

	  RETURN ls_uygun;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

 /***************************************************************************************************************/
 /*   Procedure Sp_Teminat_Ana_Tabloya_Aktar                                                                    */
 /****************************************************************************************************************/
  Procedure Sp_Teminat_Ana_Tabloya_Aktar(pn_tx_no cbs_teminat_islem.tx_no%type)
   IS

   BEGIN


   /*030406 sozlesme doviz kodu sozlesme tablosundan alinir */
	   Begin
		  update cbs_teminat_islem a
		  set sozlesme_doviz_kodu  = (select doviz_kodu
		  	  					   	  from cbs_sozlesme
									  	   where musteri_no = a.musteri_no and
										   		 sozlesme_no = a.sozlesme_no and
												 ek_sozlesme_no = a.ek_sozlesme_no )
		  where a.tx_no = pn_tx_no and
		  		a.teminat_kodu = 15 and
		  		sozlesme_doviz_kodu is  null;
	   Exception when others then null;
	   End ;

      insert into cbs_teminat
                  (teminat_no, teminat_turu, teminat_kodu, musteri_no, teminat_hesap_no,
				 teminat_hesap_doviz, teminat_tutari, kullanilan_tutar, teminat_doviz_kodu,
				 teminat_durumu, cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no, bolum_kodu,
				 senet_no, teminat_alt_kodu, aciklama, hesap_urun_sinif, hesap_urun_tur_kod,
				 hesap_modul_tur_kod, bloke_hesap_secimi, nakdi_gayri_secimi,
				 teklif_musteri_no,
				 kredi_teminat_tanim_sira_no, borclu_teminat_hesap_no, borclu_teminat_hesap_doviz,
				 nakdi_teminat_hesap_no, nakdi_teminat_hesap_doviz_kodu, REFERANS,
				 KREDI_TEKLIF_SATIR_NO, TEMINAT_ALIS_TARIHI,
				 SOZLESME_NO,EK_SOZLESME_NO ,sozlesme_doviz_kodu)
         select  teminat_no, teminat_turu, teminat_kodu, musteri_no, teminat_hesap_no,
				 teminat_hesap_doviz, teminat_tutari, kullanilan_tutar, teminat_doviz_kodu,
				 teminat_durumu, cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no,
				 nvl(bolum_kodu,pkg_baglam.bolum_kodu),
				 senet_no, teminat_alt_kodu, aciklama, hesap_urun_sinif, hesap_urun_tur_kod,
				 hesap_modul_tur_kod, bloke_hesap_secimi, nakdi_gayri_secimi,
				 teklif_musteri_no,
				 kredi_teminat_tanim_sira_no, borclu_teminat_hesap_no, borclu_teminat_hesap_doviz,
				 nakdi_teminat_hesap_no, nakdi_teminat_hesap_doviz_kodu, REFERANS,
				 KREDI_TEKLIF_SATIR_NO,
				 nvl(TEMINAT_ALIS_TARIHI,pkg_muhasebe.banka_tarihi_bul),
				 SOZLESME_NO,EK_SOZLESME_NO,sozlesme_doviz_kodu
           from cbs_teminat_islem
          WHERE tx_no = pn_tx_no  and
		  		teminat_durumu = 'ACIK'
				and teminat_no not in( select teminat_no from cbs_teminat)
			    and nvl(KULLANILAN_TUTAR,0) > 0  ;
	Begin

 /* 27/05/2004 kullanilan tutari 0 olanlar kapatildi.*/

		    update cbs_teminat_islem
			 set TEMINAT_DURUMU = 'KAPALI'
			 where tx_no = pn_tx_no   and
			        nvl(KULLANILAN_TUTAR,0) = 0 ;

			 update cbs_teminat  a
			 set
			 	( teminat_no, teminat_turu, teminat_kodu, musteri_no, teminat_hesap_no,
				 teminat_hesap_doviz, teminat_tutari, kullanilan_tutar, teminat_doviz_kodu,
				 teminat_durumu, cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no, bolum_kodu,
				 senet_no, teminat_alt_kodu, aciklama, hesap_urun_sinif, hesap_urun_tur_kod,
				 hesap_modul_tur_kod, bloke_hesap_secimi, nakdi_gayri_secimi,
				 teklif_musteri_no,
				 kredi_teminat_tanim_sira_no, borclu_teminat_hesap_no, borclu_teminat_hesap_doviz,
				 nakdi_teminat_hesap_no, nakdi_teminat_hesap_doviz_kodu, REFERANS,
				 KREDI_TEKLIF_SATIR_NO, TEMINAT_ALIS_TARIHI,
 				 SOZLESME_NO,EK_SOZLESME_NO,SOZLESME_DOVIZ_KODU)
				 =
				( select teminat_no, teminat_turu, teminat_kodu, musteri_no, teminat_hesap_no,
					 teminat_hesap_doviz, teminat_tutari, kullanilan_tutar, teminat_doviz_kodu,
					 teminat_durumu, cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no, bolum_kodu,
					 senet_no, teminat_alt_kodu, aciklama, hesap_urun_sinif, hesap_urun_tur_kod,
					 hesap_modul_tur_kod, bloke_hesap_secimi, nakdi_gayri_secimi,
					 teklif_musteri_no,
					 kredi_teminat_tanim_sira_no, borclu_teminat_hesap_no, borclu_teminat_hesap_doviz,
					 nakdi_teminat_hesap_no, nakdi_teminat_hesap_doviz_kodu, REFERANS,
	 				 KREDI_TEKLIF_SATIR_NO,  nvl(TEMINAT_ALIS_TARIHI,pkg_muhasebe.banka_tarihi_bul),
					 SOZLESME_NO,EK_SOZLESME_NO,SOZLESME_DOVIZ_KODU
				   From cbs_teminat_islem
				   WHERE tx_no = pn_tx_no  and
				   		 teminat_no = a.teminat_no)
		         where a.teminat_no in( Select teminat_no
			                          From cbs_teminat_islem
			   		 			  	  WHERE tx_no = pn_tx_no );

		  exception
		  	 when others then null;
		End;


   EXCEPTION
   	  When no_data_found then null;
      WHEN OTHERS
      THEN
         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '499'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || ' '
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END sp_teminat_ana_tabloya_aktar;

/******************************************************************************************************************/
/*   Function  sf_teminat_kullanilan_tutar_al                                                          */
/*   teminat numaras? gonderilir kullan?lan tutar al?n?r                                            */
/******************************************************************************************************************/
   FUNCTION sf_teminat_kullanilan_tutar_al (
      pn_teminat_no   cbs_teminat.teminat_no%TYPE
   )
      RETURN NUMBER
   IS
      ln_kullanilan_tutar   NUMBER;
   BEGIN
      SELECT SUM (NVL (kullanilan_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE teminat_no = pn_teminat_no
         AND teminat_durumu = 'ACIK';


      RETURN NVL (ln_kullanilan_tutar, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;

/******************************************************************************************************************/
/*   Function  sf_cekin_kullanilabilir_tutari                                                       */
/*   cek numaras? gonderilir kullanilabilir tutar alinir
/******************************************************************************************************************/
   FUNCTION sf_teminat_islemde_varmi (
      pn_tx_no        cbs_teminat_islem.tx_no%TYPE,
      pn_teminat_no   cbs_teminat.teminat_no%TYPE
   )
      RETURN VARCHAR2
   IS
      ls_mevcut   VARCHAR2 (1) := 'H';
   BEGIN
      SELECT 'E'
        INTO ls_mevcut
        FROM cbs_teminat_islem
       WHERE tx_no = pn_tx_no AND teminat_no = pn_teminat_no;

      RETURN ls_mevcut;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

/******************************************************************************************************************/
/*   Procedure  sp_teminat_takas_cek_isleme_at                                                                   */
/*   takas cek islem tablosuna kay?t aktar?m? yap?l?r                                                  */
/******************************************************************************************************************/
  Procedure sp_teminat_isleme_at( pn_tx_no                    cbs_teminat_islem.tx_no%type,
  								 pn_teminat_no         		  cbs_teminat.teminat_no%type,
								 pn_musteri_no         		  cbs_teminat.musteri_no%type,
								 pn_cek_no	           		  cbs_teminat.cek_no%type,
 								 pn_senet_no	       		  cbs_teminat.senet_no%type ,
								 ps_teminat_turu       		  cbs_teminat.teminat_turu%type,
								 ps_teminat_kodu       		  cbs_teminat.teminat_kodu%type,
								 ps_teminat_alt_kodu   		  cbs_teminat.teminat_alt_kodu%type,
								 pn_teminat_tutari     		  cbs_teminat.teminat_tutari%type,
								 pn_kullanilan_tutar   		  cbs_teminat.kullanilan_tutar%type,
								 pn_banka_kodu		   		  cbs_takas_cek.banka_kodu%type,
								 ps_sube_kodu		   		  cbs_takas_cek.sube_kodu%type,
								 pn_ref_cek_no		   		  cbs_teminat.ref_cek_no%type,
								 ps_bolum_kodu		   		  cbs_teminat.bolum_kodu%type,
								 pn_teminat_hesap_no		  cbs_teminat.teminat_hesap_no%type,
								 ps_teminat_hesap_doviz		  cbs_teminat.teminat_hesap_doviz%type,
								 ps_aciklama			   	  cbs_teminat.aciklama%type,
								 ps_teminat_doviz_kodu        cbs_teminat.teminat_doviz_kodu%type,
								 ps_teminat_durumu            cbs_teminat.teminat_durumu%type,
 								 pn_teklif_musteri_no		  cbs_teminat.teklif_musteri_no%type,
								 pn_kredi_teminat_tanim_sira_no  cbs_teminat.kredi_teminat_tanim_sira_no%type,
								 ps_hesap_urun_sinif	   	  cbs_teminat.hesap_urun_sinif%type,
								 ps_hesap_urun_tur_kod	   	  cbs_teminat.hesap_urun_tur_kod%type,
								 ps_hesap_modul_tur_kod   	  cbs_teminat.hesap_modul_tur_kod%type,
								 ps_borclu_teminat_hesap_no		  cbs_teminat.borclu_teminat_hesap_no%type,
								 ps_borclu_teminat_hesap_doviz 	  cbs_teminat.borclu_teminat_hesap_doviz%type,
								 ps_bloke_hesap_secimi		  cbs_teminat.bloke_hesap_secimi%type,
								 ps_nakdi_gayri_secimi		  cbs_teminat.nakdi_gayri_secimi%type default 'GAYRI',
								 PS_Referans				  cbs_teminat.REFERANS%type,
								 pn_kredi_teklif_satir_no	  cbs_teminat.kredi_teklif_satir_no%type,
								 pd_teminat_alis_tarihi     date default pkg_muhasebe.banka_tarihi_bul )

   IS
      ln_kullanilan_tutar   cbs_teminat.kullanilan_tutar%TYPE;
      ln_teminat_no         cbs_teminat.teminat_no%TYPE;
   BEGIN
   if pn_tx_no is not null then
      IF pkg_teminat.sf_teminat_islemde_varmi (pn_tx_no, pn_teminat_no) = 'E'
      THEN

         UPDATE cbs_teminat_islem
            SET kullanilan_tutar = pn_kullanilan_tutar
          WHERE tx_no = pn_tx_no AND teminat_no = pn_teminat_no;
      ELSE

         INSERT INTO cbs_teminat_islem
                     (tx_no, teminat_no, musteri_no, cek_no,
                      senet_no, teminat_turu, teminat_kodu,
                      teminat_alt_kodu, teminat_tutari,
                      kullanilan_tutar, cek_banka_kodu, cek_sube_kodu,
                      ref_cek_no, bolum_kodu, teminat_hesap_no,
                      teminat_hesap_doviz, aciklama,
                      teminat_doviz_kodu, teminat_durumu,
                      teklif_musteri_no,
					  kredi_teminat_tanim_sira_no,
                      hesap_urun_sinif, hesap_urun_tur_kod,
                      hesap_modul_tur_kod, borclu_teminat_hesap_no,
                      borclu_teminat_hesap_doviz, bloke_hesap_secimi,
                      nakdi_gayri_secimi,REFERANS,
					  kredi_teklif_satir_no,teminat_alis_tarihi
                     )
              VALUES (pn_tx_no,
			  		  nvl(pn_teminat_no,pkg_genel.genel_kod_al('TEMINAT_NO')),
					  pn_musteri_no, pn_cek_no,
                      pn_senet_no, ps_teminat_turu, ps_teminat_kodu,
                      ps_teminat_alt_kodu, pn_teminat_tutari,
                      pn_kullanilan_tutar, pn_banka_kodu, ps_sube_kodu,
                      pn_ref_cek_no, ps_bolum_kodu, pn_teminat_hesap_no,
                      ps_teminat_hesap_doviz, ps_aciklama,
                      ps_teminat_doviz_kodu, ps_teminat_durumu,
                      pn_teklif_musteri_no	,
					  pn_kredi_teminat_tanim_sira_no,
                      ps_hesap_urun_sinif, ps_hesap_urun_tur_kod,
                      ps_hesap_modul_tur_kod, ps_borclu_teminat_hesap_no,
                      ps_borclu_teminat_hesap_doviz, ps_bloke_hesap_secimi,
                      NVL(ps_nakdi_gayri_secimi,'GAYRI'),
					  PS_Referans,pn_kredi_teklif_satir_no,pd_teminat_alis_tarihi
                     );
      END IF;
  end if;

   EXCEPTION
    when no_data_found then null;
      WHEN OTHERS
      THEN
         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '505'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || ' '
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END;

/***************************************************************************************************************/
/*   Procedure sp_kredi_teminat_bloke_yarat                                                         */
/*   Kredi teminat kullan?d?rlmas? a?amas?nda bloke konulurken ?a?r?l?r                                   */
/***************************************************************************************************************/
   PROCEDURE sp_kredi_teminat_bloke_yarat (
      pn_tx_no        cbs_teminat_islem.tx_no%TYPE,
      pn_teminat_no   cbs_teminat_islem.teminat_no%TYPE
   )
   IS
      ls_aciklama          varchar2 (2000);
      ls_bloke_neden       varchar2 (2000);
      ls_islem_tanim_kod   varchar2 (2000)           := '1200';
  	  ln_kullanilan_tutar  number := 0;
      ls_bloke_referans    cbs_bloke.bloke_referans%type;

	  cursor cursor_bloke is
       SELECT   teminat_hesap_no,musteri_no,
	   			BORCLU_TEMINAT_hesap_no,
				BORCLU_teminat_hesap_doviz, 'A',
                kullanilan_tutar, ls_bloke_referans, ls_bloke_neden,
                ls_aciklama, ls_islem_tanim_kod,
                pkg_muhasebe.banka_tarihi_bul,
				referans,
				nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(borclu_teminat_hesap_no),0) bakiye,
				TEKLIF_MUSTERI_NO
           FROM cbs_teminat_islem
          WHERE tx_no = pn_tx_no AND
		  		teminat_no = pn_teminat_no and
			    bloke_hesap_secimi = 'BLOKE' and
			    teminat_kodu = '12';

   cursor cur_islem is
    select
		pkg_muhasebe.banka_tarihi_bul kayit_tarih,
		sysdate kayit_sistem_tarihi,
		nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) kayit_kullanici_kodu,
		nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) kayit_kullanici_bolum_kodu,
		pkg_muhasebe.banka_tarihi_bul dogru_tarih	,
		nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) dogru_kullanici_kodu,
		nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) dogru_kullanici_bolum_kodu,
		pkg_muhasebe.banka_tarihi_bul onay_tarih,
		sysdate onay_sistem_tarihi,
		nvl(pkg_baglam.bolum_kodu,onay_kullanici_bolum_kodu) onay_kullanici_bolum_kodu	,
		nvl(pkg_baglam.Kullanici_kodu,onay_kullanici_kodu) onay_kullanici_kodu
	from cbs_islem
	where numara = pn_tx_no ;

	r_islem cur_islem%rowtype;
   BEGIN

    for c_islem in cur_islem
	 loop
	  r_islem := c_islem ;
	 end loop;

      ls_bloke_neden :=
         pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_NEDEN_KODU'
                                  );

	  for cur_bloke in cursor_bloke loop
	   if cur_bloke.bakiye > 0 then
		  	 if cur_bloke.bakiye > cur_bloke.kullanilan_tutar then
			  	  ln_kullanilan_tutar := cur_bloke.kullanilan_tutar;
			 else
			 	  ln_kullanilan_tutar :=cur_bloke.bakiye;
			end if;
		else
   	 	  ln_kullanilan_tutar :=0;
		end if;
        if cur_bloke.teminat_hesap_no is not null then
         ls_aciklama :=      pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_ACIKLAMA'
                                  ) ||' ' || to_char(cur_bloke.teminat_hesap_no) ;
		 else
		 ls_aciklama :=      pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_ACIKLAMA_MUSTERI'
                                  ) ||' ' || to_char(cur_bloke.TEKLIF_MUSTERI_NO) ;

		end if;

    if  cur_bloke.referans is not null then
  /* mevcut olan kapatilir.*/
     if pkg_bloke.Sf_bloke_durum_Kodu_Al(cur_bloke.referans) <>'K' then
        pkg_bloke.sp_bloke_yarat (
								   ps_bloke_referans => cur_bloke.referans,
								   pn_musteri_no =>cur_bloke.musteri_no,
								   pn_HESAP_NO=>cur_bloke.borclu_teminat_hesap_no,
								   ps_DOVIZ_KODU=> cur_bloke.borclu_teminat_hesap_doviz,
								   pn_BLOKE_TUTARI=>0,
								   ps_BLOKE_NEDEN_KODU=>ls_bloke_neden,
								   ps_ACIKLAMA=>ls_aciklama,
								   pd_BLOKE_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pd_BLOKE_BITIS_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pn_tx_no=> pn_tx_no,
								   p_COZ_KAYIT_TARIH =>r_islem.kayit_tarih,
								   p_COZ_KAYIT_SISTEM_TARIH=>r_islem.kayit_sistem_tarihi,
								   p_COZ_KAYIT_KULLANICI_KODU=>r_islem.kayit_kullanici_kodu,
								   p_COZ_KAYIT_KULLANICI_BOLUMKOD=>r_islem.kayit_kullanici_bolum_kodu,
								   p_COZ_DOGRU_TARIH=>r_islem.dogru_tarih,
								   p_COZ_DOGRU_KULLANICI_KODU=>r_islem.dogru_kullanici_kodu,
								   p_COZ_DOGRU_KULLANICI_BOLUMKOD=>r_islem.dogru_kullanici_bolum_kodu,
								   p_COZ_ONAY_TARIH=>r_islem.onay_tarih,
								   p_COZ_ONAY_SISTEM_TARIH=>r_islem.onay_sistem_tarihi,
								   p_COZ_ONAY_KULLANICI_KODU=>r_islem.onay_kullanici_kodu,
								   p_COZ_ONAY_KULLANICI_BOLUMKOD=>r_islem.onay_kullanici_bolum_kodu,
								   ps_kapama=>'KAPAMA');



    	end if;
	end if;
	/* Yeni bloke kaydi yaratilir */
	if nvl(ln_kullanilan_tutar,0) <> 0 then
        pkg_bloke.sp_bloke_yarat (
							      ls_bloke_referans,
								   cur_bloke.musteri_no,
	   							   cur_bloke.borclu_teminat_hesap_no,
	   							   cur_bloke.borclu_teminat_hesap_doviz,
								   ln_kullanilan_tutar,
			 					   ls_bloke_neden,
								   ls_aciklama,
			 					   pkg_muhasebe.banka_tarihi_bul,
								   null,
								   null,
								   pn_tx_no,
								   r_islem.kayit_tarih,
									r_islem.kayit_sistem_tarihi,
									r_islem.kayit_kullanici_kodu,
									r_islem.kayit_kullanici_bolum_kodu,
									r_islem.dogru_tarih	,
									r_islem.dogru_kullanici_kodu,
									r_islem.dogru_kullanici_bolum_kodu,
									r_islem.onay_tarih,
									r_islem.onay_sistem_tarihi,
									r_islem.onay_kullanici_kodu,
									r_islem.onay_kullanici_bolum_kodu
								  	) ;
 	  end if;
     end loop;
	 if ls_bloke_referans is not null then
		     UPDATE cbs_teminat_islem
		     SET   REFERANS = ls_bloke_referans,
			 	   kullanilan_tutar = ln_kullanilan_tutar
		     WHERE tx_no = pn_tx_no AND teminat_no = pn_teminat_no;
	 end if;

   EXCEPTION
      WHEN OTHERS
      THEN
      log_at('4100_defect', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);--aisuluud defect 01112016
         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '531'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || ' '
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END;

/***************************************************************************************************************/
/*   Procedure Sp_Kredi_Teminat_Vadesiz_Ac                                                              */
/*   Kredi teminat vaddesiz hesap acilmasi                                                      */
/***************************************************************************************************************/
 Function Sp_Kredi_Teminat_Vadesiz_Ac(pn_tx_no 	   cbs_teminat_islem.tx_no%type ,
		   								pn_teminat_no cbs_teminat_islem.teminat_no%type ) return cbs_hesap.hesap_no%type

   IS
      ln_musteri_no            cbs_musteri.musteri_no%TYPE;
      ls_modul_tur_kod         cbs_teminat_islem.hesap_modul_tur_kod%TYPE;
      ls_urun_tur_kod          cbs_teminat_islem.hesap_urun_tur_kod%TYPE;
      ls_urun_sinif            cbs_teminat_islem.hesap_urun_sinif%TYPE;
      ln_kullanilan_tutar      cbs_teminat_islem.kullanilan_tutar%TYPE;
      ls_teminat_hesap_doviz   cbs_teminat_islem.teminat_hesap_doviz%TYPE;
      ls_bolum_kodu            cbs_teminat_islem.bolum_kodu%TYPE;
      ls_kisa_adi              VARCHAR2 (20);
      ln_hesap_no             cbs_hesap.hesap_no%TYPE;
      ln_dk_grup_kod           cbs_musteri.dk_grup_kod%TYPE;
      ls_gl_code               cbs_hesap.musteri_dk_no%TYPE;
	  ls_doviz_kodu			   cbs_hesap_kredi.doviz_kodu%type;
	  ls_kisa_isim			   varchar2(200);

   BEGIN
      SELECT musteri_no,
             hesap_modul_tur_kod,
			 hesap_urun_tur_kod,
			 hesap_urun_sinif ,
			 teminat_doviz_kodu,
			 bolum_kodu,
			 SUBSTR (pkg_musteri.sf_musteri_adi (musteri_no), 1, 20),
			 NAKDI_TEMINAT_HESAP_NO
        INTO ln_musteri_no,
             ls_modul_tur_kod,
			 ls_urun_tur_kod,
			 ls_urun_sinif ,
			 ls_doviz_kodu,
			 ls_bolum_kodu,
			 ls_kisa_isim,
			 ln_hesap_no
       FROM cbs_teminat_islem
       WHERE tx_no = pn_tx_no AND
	   		 teminat_no = pn_teminat_no and
			 bloke_hesap_secimi = 'HESAP' and
			 teminat_kodu = '12' and
			 NAKDI_TEMINAT_HESAP_NO is null ;

  if  nvl(ln_hesap_no,0) = 0 then
   begin
	select min(hesap_no)
	into  ln_hesap_no
	from cbs_hesap
	where musteri_no     = ln_musteri_no and
		  modul_tur_kod  = ls_modul_tur_kod and
	  	  urun_tur_kod 	 = ls_urun_tur_kod and
		  urun_sinif_kod = ls_urun_sinif and
		  doviz_kodu	 = ls_doviz_kodu and
		  sube_kodu	=  ls_bolum_kodu and
		  durum_kodu = 'A' 	;
   exception when others then null;
   end;
  end if;
   if nvl(ln_hesap_no,0) = 0 then
	    ln_hesap_no :=pkg_hesap.VadesizHesapAcilis
							 (ln_musteri_no ,
		 				  	  ls_modul_tur_kod ,
	  		   				  ls_urun_tur_kod ,
							  ls_urun_sinif,
							  ls_doviz_kodu,
							  ls_bolum_kodu,
							  ls_kisa_isim,
							  'H',--ps_cek_karnesi,
							  1,--pn_hesap_hareket_kodu,
							  'X',--ps_dekont	,
							  'X', --ps_ekstre_kodu
							  '365',
							  pkg_muhasebe.Banka_Tarihi_Bul
							  );


   end if;
	/* teminat hesap numarasi alani yeni yaratilan hesap ile g?ncellenir. */

	      UPDATE cbs_teminat_islem
          SET nakdi_teminat_hesap_no = ln_hesap_no ,
		 	  nakdi_teminat_hesap_doviz_kodu = ls_doviz_kodu
		  WHERE tx_no = pn_tx_no AND teminat_no = pn_teminat_no;




 return ln_hesap_no;

   EXCEPTION
     when no_data_found then return null ;
     WHEN OTHERS
      THEN
         raise_application_error (-20100,
                                     pkg_hata.getucpointer
                                  || '506'
                                  || pkg_hata.getdelimiter
                                  || TO_CHAR (SQLCODE)
                                  || ' '
                                  || SQLERRM
                                  || pkg_hata.getdelimiter
                                  || pkg_hata.getucpointer
                                 );
   END;

 /***************************************************************************************************************/
/*    Function Sf_cek_tahsil_teminat_al                                                                */
/*   Takas cek'in tahsil teminat bilgisi al?n?r                                                   */
/***************************************************************************************************************/
   FUNCTION sf_cek_tahsil_teminat_al (
      pn_ref_cek_no   cbs_takas_cek.ref_cek_no%TYPE
   )
      RETURN cbs_takas_cek.tahsil_teminat%TYPE
   IS
      ls_tahsil_teminat   cbs_takas_cek.tahsil_teminat%TYPE;
   BEGIN
      SELECT tahsil_teminat
        INTO ls_tahsil_teminat
        FROM cbs_takas_cek
       WHERE ref_cek_no = pn_ref_cek_no;

      RETURN ls_tahsil_teminat;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;


 /***************************************************************************************************************/
/*    Function sf_senet_tahsil_teminat_al                                                               */
/*   senetin tahsil teminat bilgisi al?n?r                                                   */
/***************************************************************************************************************/
   FUNCTION sf_senet_tahsil_teminat_al (
			ps_bolum_kodu   cbs_teminat_islem.bolum_kodu%TYPE  default null,
			pn_senet_no     cbs_teminat_islem.senet_no%TYPE  default null  ) RETURN cbs_senet.urun_tur_kod%TYPE
   IS
      ls_tahsil_teminat   cbs_senet.urun_tur_kod%TYPE;
   BEGIN
      SELECT urun_tur_kod
        INTO ls_tahsil_teminat
        FROM cbs_senet
       WHERE bolum_kodu =ps_bolum_kodu and
	   		 senet_no =pn_senet_no;

      RETURN ls_tahsil_teminat;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;


 /***************************************************************************************************************/
/*   Function  sf_diger_gayri_nakdi_mi                                                              */
/*   diger gayri nakdiler(cek,senet vb haric)                                               */
/***************************************************************************************************************/
   FUNCTION sf_diger_gayri_nakdi_mi (
      ps_teminat_kodu   cbs_teminat_kodlari.teminat_kodu%TYPE
   )
      RETURN VARCHAR2
   IS
      ls_uygun   VARCHAR2 (1) := 'E';
   BEGIN
      IF ps_teminat_kodu IN ('01', '11', '09','14','13','15','12')
      THEN                                                --cek ,senet,vesaik
         ls_uygun := 'H';
      ELSE
         SELECT DECODE (nakdi_gayrinakdi_secimi, 'NAKDI', 'H', 'E')
           INTO ls_uygun
           FROM cbs_teminat_kodlari
          WHERE teminat_kodu = ps_teminat_kodu;
      END IF;

      RETURN ls_uygun;
   EXCEPTION
       when no_data_found then null;
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;

 /***************************************************************************************************************/
/*   Function sf_diger_gayrinakdi_doviz_al                                                             */
/*   diger gayri nakdilerin doviz kodu alinir                                         */
/***************************************************************************************************************/
   FUNCTION sf_diger_gayrinakdi_doviz_al (
      pn_musteri_no        cbs_kredi_teminat_tanim.musteri_no%TYPE,
      pn_teminat_sira_no   cbs_kredi_teminat_tanim.teminat_sira_no%TYPE
   )
      RETURN cbs_doviz_kodlari.doviz_kodu%TYPE
   IS
      ls_doviz_kodu   cbs_doviz_kodlari.doviz_kodu%TYPE;
   BEGIN
      SELECT Doviz_kodu
        INTO ls_doviz_kodu
        FROM cbs_kredi_teminat_tanim
       WHERE musteri_no = pn_musteri_no
         AND teminat_sira_no = pn_teminat_sira_no;

      RETURN ls_doviz_kodu;
   EXCEPTION
      when no_data_found then null;
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

/***************************************************************************************************************/
/*   Function sf_diger_gayrinakdi_tutar_al                                                             */
/*   diger gayri nakdilerin TUTARI kodu alinir                                         */
/***************************************************************************************************************/
   FUNCTION sf_diger_gayrinakdi_tutar_al (
      pn_musteri_no        cbs_kredi_teminat_tanim.musteri_no%TYPE,
      pn_teminat_sira_no   cbs_kredi_teminat_tanim.teminat_sira_no%TYPE
   )
      RETURN NUMBER
   IS
      ln_tutar   NUMBER;
   BEGIN
      SELECT tutar
        INTO ln_tutar
        FROM cbs_kredi_teminat_tanim
       WHERE musteri_no = pn_musteri_no
         AND teminat_sira_no = pn_teminat_sira_no;

      RETURN ln_tutar;
   EXCEPTION
      when no_data_found then null;
      WHEN OTHERS
      THEN
         RETURN 0;
   END;

/***************************************************************************************************************/
/*    FUNCTION sf_teminat_turu_al                                                            */
/***************************************************************************************************************/

   FUNCTION sf_teminat_turu_al (
      ps_teminat_kodu   cbs_teminat_kodlari.teminat_kodu%TYPE
   )
      RETURN cbs_teminat_kodlari.teminat_turu%TYPE
   IS
      ls_teminat_turu   cbs_teminat_kodlari.teminat_turu%TYPE;

   BEGIN
      SELECT upper(teminat_turu)
        INTO ls_teminat_turu
        FROM cbs_teminat_kodlari
       WHERE teminat_kodu = ps_teminat_kodu;

      RETURN ls_teminat_turu;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

/***************************************************************************************************************/
/*    Procedure sp_krediteminatlari_isleme_at                                                           	  */
/*  teminat modulu icerisinden mevcut teminatlar ve sozlesme bilgileri atmak icin kullanilir				  */
/***************************************************************************************************************/

 Procedure sp_krediteminatlari_isleme_at(pn_tx_no cbs_teminat_islem.tx_no%type ,pn_hesap_no cbs_teminat.teminat_hesap_no%type,
 		   								 pn_musteri_no cbs_teminat.teklif_musteri_no%type default null)
 is
 	 ln_mevcut number := 0 ;
 Begin
 	  select count(*) into ln_mevcut
	  from cbs_teminat_islem
	  where tx_no = pn_tx_no;

	  if nvl(ln_mevcut,0) = 0 then

		 	  insert into cbs_teminat_islem (
			  		 	  					   tx_no, TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO, TEMINAT_HESAP_NO,
											   TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI, KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU,
											   TEMINAT_DURUMU, CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU, SENET_NO,
											   REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA, BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF,
											   HESAP_URUN_TUR_KOD, HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI,
											   TEKLIF_MUSTERI_NO,
											   KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO, BORCLU_TEMINAT_HESAP_DOVIZ,
											   NAKDI_TEMINAT_HESAP_NO, NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS,
											   KREDI_TEKLIF_SATIR_NO, TEMINAT_ALIS_TARIHI,satir_durum,
											    SOZLESME_NO,EK_SOZLESME_NO,SOZLESME_DOVIZ_KODU)
			select
					 	  					   pn_tx_no,  TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO, TEMINAT_HESAP_NO,
											   TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI, KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU,
											   TEMINAT_DURUMU, CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, nvl(BOLUM_KODU,pkg_baglam.bolum_kodu), SENET_NO,
											   REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA, BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF,
											   HESAP_URUN_TUR_KOD, HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI,
											   TEKLIF_MUSTERI_NO,
											   KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO, BORCLU_TEMINAT_HESAP_DOVIZ,
											   NAKDI_TEMINAT_HESAP_NO, NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS,
											   KREDI_TEKLIF_SATIR_NO, TEMINAT_ALIS_TARIHI,'ESKI',
											   SOZLESME_NO,EK_SOZLESME_NO,SOZLESME_DOVIZ_KODU
			from cbs_teminat
			where  (( pn_hesap_no is not null and teminat_hesap_no = pn_hesap_no)
				     or
					 ( pn_hesap_no is null and teklif_musteri_no = pn_musteri_no  and teminat_hesap_no is null));
				 -- and teminat_durumu = 'ACIK';

	  end if;

   EXCEPTION
     When no_data_found then null;
      WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '530' || pkg_hata.getdelimiter || TO_CHAR (SQLCODE)  || ' '  || SQLERRM || pkg_hata.getdelimiter || pkg_hata.getucpointer );

 End;

 /***************************************************************************************************************/
 /*     Function  sf_ihracat_dosya_tutari_al                                                          */
 /***************************************************************************************************************/

   Function  sf_ihracat_dosya_tutari_al(ps_referans cbs_teminat_islem.REFERANS%type) return number
   IS
      ln_tutar   number;
   BEGIN

      select akreditif_tutar
      into   ln_tutar
      from   cbs_akreditif
      where referans = ps_referans
	  union
	  select  tutar
      from   cbs_ihracat
      where referans_no = ps_referans  ;

      RETURN ln_tutar;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

 /***************************************************************************************************************/
 /*     Function sf_alingaran_dosya_tutari_al                                                         */
 /***************************************************************************************************************/
  Function  sf_alingaran_dosya_tutari_al(ps_referans cbs_teminat_islem.REFERANS%type) return number
  is
      ln_tutar   number;
   begin

   /* ihracat tablosuda eklenecek */
      select tutar
      into   ln_tutar
      from   cbs_tm_alinan_garanti
      where  referans = ps_referans;

      return ln_tutar;
   exception
      when others
      then
         return null;
   end;

 /***************************************************************************************************************/
 /*    sp_teminatislem_hesapno_guncel                                                         */
 /***************************************************************************************************************/
 Procedure sp_teminatislem_hesapno_guncel(pn_islem_no number ,pn_hesap_no number ,ps_doviz_kodu varchar2)
 is
 	Begin
		 if pn_hesap_no is not null then
			 update cbs_teminat_islem
			 set    teminat_hesap_no = pn_hesap_no ,
			 		teminat_hesap_doviz =ps_doviz_kodu
			 where  tx_no = pn_islem_no;
		end if;
    	 Exception
		  When others then null;
  End;


/***********************************************/
/****************KULLANILAN TUTARLAR************/
/***********************************************/

/******************************************************************************************************************/
/*   Function  sf_teminat_kullanilan_tutar_al                                                          */
/*   teminat numaras? gonderilir kullan?lan tutar al?n?r                                            */
/******************************************************************************************************************/
   FUNCTION sf_cekin_kullanilan_tutari (
									      pn_ref_cek_no   cbs_takas_cek.ref_cek_no%TYPE,
									      pn_islem_no     cbs_teminat_islem.tx_no%TYPE DEFAULT NULL,
										  ps_onaylimi varchar2 default 'H'  )  return number
   IS
      ln_kullanilan_tutar           NUMBER;
      ln_rezerve_kullanilan_tutar   NUMBER := 0;
   BEGIN

      SELECT SUM (NVL (kullanilan_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE ref_cek_no = pn_ref_cek_no
         AND teminat_durumu = 'ACIK';

/*	 if ps_onaylimi != 'E' then
      -- islemde olup teminatda olmayan ama rezerve edilen durumu acik cek teminat islemlerin toplami
	  Begin
	      IF pn_islem_no IS NULL
	      THEN

	         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	          WHERE ref_cek_no = pn_ref_cek_no
	            AND teminat_durumu = 'ACIK'
	            AND teminat_no NOT IN (SELECT teminat_no
	                                     FROM cbs_teminat
	                                    WHERE ref_cek_no = pn_ref_cek_no and
											  teminat_durumu = 'ACIK'  );
	      ELSE

	         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	          WHERE ref_cek_no = pn_ref_cek_no
	            AND teminat_durumu = 'ACIK'
	            AND teminat_no NOT IN (SELECT teminat_no
	                                     FROM cbs_teminat
	                                    WHERE ref_cek_no = pn_ref_cek_no and
											  teminat_durumu = 'ACIK')
	            AND tx_no <> pn_islem_no;

	      END IF;

	   exception
	   when no_data_found then null;
	   end ;

      ln_kullanilan_tutar :=
            NVL (ln_kullanilan_tutar, 0)
            + NVL (ln_rezerve_kullanilan_tutar, 0);
	end if;
 	*/
      RETURN NVL (ln_kullanilan_tutar, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   /***************************************************************************************************************/
/*   Function sf_senet_kullanilan_tutari                                                               */
/*   senetin teminatda kullanilan tutari alinir                                                   */
/***************************************************************************************************************/
   FUNCTION sf_senet_kullanilan_tutari (
										      ps_bolum_kodu   cbs_teminat_islem.bolum_kodu%TYPE,
										      pn_senet_no     cbs_teminat_islem.senet_no%TYPE,
										      pn_islem_no     cbs_teminat_islem.tx_no%TYPE DEFAULT NULL,
											  ps_onaylimi varchar2 default 'H'  )  return number
   IS
      ln_kullanilan_tutar           NUMBER;
      ln_rezerve_kullanilan_tutar   NUMBER;
   BEGIN

      SELECT SUM (NVL (kullanilan_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE bolum_kodu = ps_bolum_kodu
         AND senet_no = pn_senet_no
         AND teminat_durumu = 'ACIK' ;

/*	 if ps_onaylimi != 'E' then
      -- islemde olup teminatda olmayan ama rezerve edilen durumu acik senet teminat islemlerin toplami
	  Begin
	      IF pn_islem_no IS NULL
	      THEN
		         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	          WHERE bolum_kodu = ps_bolum_kodu
	            AND senet_no = pn_senet_no
	            AND teminat_durumu = 'ACIK'
	            AND teminat_no NOT IN (
	                   SELECT teminat_no
	                     FROM cbs_teminat
	                    WHERE bolum_kodu = ps_bolum_kodu
	                          AND senet_no = pn_senet_no
							  and teminat_durumu = 'ACIK');
	      ELSE
	         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	          WHERE bolum_kodu = ps_bolum_kodu
	            AND senet_no = pn_senet_no
	            AND teminat_durumu = 'ACIK'
				AND teminat_no NOT IN (
	                   SELECT teminat_no
	                     FROM cbs_teminat
	                    WHERE bolum_kodu = ps_bolum_kodu
	                          AND senet_no = pn_senet_no and
								  teminat_durumu = 'ACIK')
	            AND tx_no <> pn_islem_no;
	      END IF;
	   exception
	   when no_data_found then null;
	   end ;

      ln_kullanilan_tutar :=
            NVL (ln_kullanilan_tutar, 0)
            + NVL (ln_rezerve_kullanilan_tutar, 0);
     end if;
	*/

      RETURN NVL (ln_kullanilan_tutar, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;


 /***************************************************************************************************************/
/*    FUNCTION sf_diger_gayrin_kullan_tutari                                                           */
/***************************************************************************************************************/

   FUNCTION sf_diger_gayrin_kullan_tutari (
							        pn_musteri_no        cbs_kredi_teminat_tanim.musteri_no%TYPE,
							        pn_teminat_sira_no   cbs_kredi_teminat_tanim.teminat_sira_no%TYPE,
								    pn_islem_no  cbs_teminat_islem.tx_no%type default null,
								    ps_onaylimi varchar2 default 'H'  )  return number
   IS

	  ln_kullanilan_tutar  number;
	  ln_rezerve_kullanilan_tutar number;
   BEGIN

      SELECT SUM (NVL (KULLANILAN_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE musteri_no = pn_musteri_no
         AND kredi_teminat_tanim_sira_no = pn_teminat_sira_no
         AND teminat_durumu = 'ACIK';

/* if ps_onaylimi != 'E' then
    -- islemde olup teminatda olmayan ama rezerve edilen durumu acik senet teminat islemlerin toplami
   Begin
	      IF pn_islem_no IS NULL
	      THEN
		         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	          WHERE musteri_no = pn_musteri_no
         	  		AND kredi_teminat_tanim_sira_no = pn_teminat_sira_no
		            AND teminat_durumu = 'ACIK'
	                AND teminat_no NOT IN (
	                   SELECT teminat_no
	                     FROM cbs_teminat
	                    WHERE musteri_no = pn_musteri_no
						   	  and kredi_teminat_tanim_sira_no = pn_teminat_sira_no
					   	      and teminat_durumu = 'ACIK'    	   );
	      ELSE
	         SELECT SUM (NVL (kullanilan_tutar, 0))
	           INTO ln_rezerve_kullanilan_tutar
	           FROM cbs_teminat_islem
	            WHERE musteri_no = pn_musteri_no
         	   		   AND kredi_teminat_tanim_sira_no = pn_teminat_sira_no
		          	   AND teminat_durumu = 'ACIK'
				       AND teminat_no NOT IN (
	                   SELECT teminat_no
	                   FROM cbs_teminat
					   WHERE musteri_no = pn_musteri_no
         	   		   AND kredi_teminat_tanim_sira_no = pn_teminat_sira_no
					   	   and  teminat_durumu = 'ACIK'        	   )
	            AND tx_no <> pn_islem_no;
	      END IF;
	   exception
	   when no_data_found then null;
	   end ;
      ln_kullanilan_tutar :=
            NVL (ln_kullanilan_tutar, 0)
            + NVL (ln_rezerve_kullanilan_tutar, 0);
   end if;
	*/
      RETURN NVL (ln_kullanilan_tutar, 0);
	  EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;
/***************************************************************************************************************/
/*    Function sf_ihracat_kullanilan_tutari                                                           */
/***************************************************************************************************************/
 Function sf_ihracat_kullanilan_tutari(ps_referans cbs_teminat_islem.REFERANS%type ,
 		  							   pn_islem_no  cbs_teminat_islem.tx_no%type default null,
									   ps_onaylimi varchar2 default 'H'  )  return number
   IS
      ln_kullanilan_tutar           NUMBER;
      ln_rezerve_kullanilan_tutar   NUMBER;
   BEGIN
      SELECT SUM (NVL (kullanilan_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE  REFERANS = ps_referans
         AND teminat_durumu = 'ACIK';

/* if ps_onaylimi != 'E' then
      -- islemde olup teminatda olmayan ama rezerve edilen durumu acik senet teminat islemlerin toplami
	  Begin
	      IF pn_islem_no IS NULL
	      THEN

		         SELECT SUM (NVL (kullanilan_tutar, 0))
		           INTO ln_rezerve_kullanilan_tutar
		           FROM cbs_teminat_islem
		          WHERE  REFERANS = ps_referans
		            AND teminat_durumu = 'ACIK'
		            AND teminat_no NOT IN (
		                   SELECT teminat_no
		                     FROM cbs_teminat
		                    WHERE  REFERANS = ps_referans
								   and teminat_durumu = 'ACIK');
		      ELSE
		         SELECT SUM (NVL (kullanilan_tutar, 0))
		           INTO ln_rezerve_kullanilan_tutar
		           FROM cbs_teminat_islem
		          WHERE REFERANS = ps_referans
		            AND teminat_durumu = 'ACIK'
					AND teminat_no NOT IN (
		                   SELECT teminat_no
		                     FROM cbs_teminat
		                    WHERE  REFERANS = ps_referans
								   and  teminat_durumu = 'ACIK')
		            AND tx_no <> pn_islem_no;
		      END IF;
		   exception
		   when no_data_found then null;
	   end ;
      ln_kullanilan_tutar :=
            NVL (ln_kullanilan_tutar, 0)
            + NVL (ln_rezerve_kullanilan_tutar, 0);
    end if;
	*/
      RETURN NVL (ln_kullanilan_tutar, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
  END;

 /***************************************************************************************************************/
 /*      Function sf_alingaran_kullanilan_tutari                                                       */
 /***************************************************************************************************************/
 Function sf_alingaran_kullanilan_tutari(ps_referans cbs_teminat_islem.REFERANS%type ,
 		  								 pn_islem_no  cbs_teminat_islem.tx_no%type default null,
										  ps_onaylimi varchar2 default 'H'  )  return number
   IS
      ln_kullanilan_tutar           NUMBER;
      ln_rezerve_kullanilan_tutar   NUMBER;
   BEGIN
      SELECT SUM (NVL (kullanilan_tutar, 0))
        INTO ln_kullanilan_tutar
        FROM cbs_teminat
       WHERE  REFERANS = ps_referans
         AND teminat_durumu = 'ACIK';

/* if ps_onaylimi != 'E' then
  --     islemde olup teminatda olmayan ama rezerve edilen durumu acik senet teminat islemlerin toplami
	  Begin
	      IF pn_islem_no IS NULL
	      THEN

		         SELECT SUM (NVL (kullanilan_tutar, 0))
		           INTO ln_rezerve_kullanilan_tutar
		           FROM cbs_teminat_islem
		          WHERE  REFERANS = ps_referans
		            AND teminat_durumu = 'ACIK'
		            AND teminat_no NOT IN (
		                   SELECT teminat_no
		                     FROM cbs_teminat
		                    WHERE  REFERANS = ps_referans
								   and teminat_durumu = 'ACIK');
		      ELSE
		         SELECT SUM (NVL (kullanilan_tutar, 0))
		           INTO ln_rezerve_kullanilan_tutar
		           FROM cbs_teminat_islem
		          WHERE REFERANS = ps_referans
		            AND teminat_durumu = 'ACIK'
					AND teminat_no NOT IN (
		                   SELECT teminat_no
		                     FROM cbs_teminat
		                    WHERE  REFERANS = ps_referans
								   and  teminat_durumu = 'ACIK')
		            AND tx_no <> pn_islem_no;
		      END IF;
		   exception
		   when no_data_found then null;
	   end ;
      ln_kullanilan_tutar :=
            NVL (ln_kullanilan_tutar, 0)
            + NVL (ln_rezerve_kullanilan_tutar, 0);

   end if;
   */
      RETURN NVL (ln_kullanilan_tutar, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
  END;


 /***************************************************************************************************************/
 /* Function  sf_ihracat_dosya_tutari_al
 /* akreditif ve ihraacatdan ilgili referans?n durumu al?n?r
 /* teminat da kullan?lmak ?zere haz?rland?.               														 */
 /***************************************************************************************************************/

   Function   sf_ihracat_durumu_al(ps_referans cbs_teminat_islem.REFERANS%type) return VARCHAR2
   IS
      ls_durum_kodu varchar2(20);
   BEGIN
      select decode( durum_kodu,'GUNCEL','ACIK','A','ACIK',durum_kodu)
      into   ls_durum_kodu
      from   cbs_akreditif
      where referans = ps_referans
	  union
	  select decode( durum_kodu,'GUNCEL','ACIK','A','ACIK',durum_kodu)
      from   cbs_ihracat
      where  referans_no = ps_referans  ;

      RETURN  ls_durum_kodu;

   EXCEPTION
        when no_data_found then return null;
      WHEN OTHERS  THEN
	        raise_application_error (-20100, pkg_hata.getucpointer || '542' || pkg_hata.getucpointer || ps_referans|| pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   END;


 /***************************************************************************************************************/
 /*     Function  sf_alinangaranti_durumu_al                                                          */
 /***************************************************************************************************************/

  Function  sf_alinangaranti_durumu_al(ps_referans cbs_teminat_islem.REFERANS%type) return VARCHAR2
   IS
      ls_durum_kodu varchar2(20);
   BEGIN
      select decode(durum_kodu,'ON','ACIK',durum_kodu)
      into   ls_durum_kodu
      from   cbs_tm_alinan_garanti
      where  referans = ps_referans ;


      RETURN  ls_durum_kodu;

   EXCEPTION
        when no_data_found then return null;
      WHEN OTHERS  THEN
	        raise_application_error (-20100, pkg_hata.getucpointer || '543' || pkg_hata.getucpointer || ps_referans|| pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   END;


 Function sf_Hesap_Durum_Al(pn_hesap_no	IN cbs_vw_hesap_izleme.HESAP_NO%TYPE) return varchar2
 is
    	ls_durum_kodu		VARCHAR2(10);
   BEGIN
   		select durum_kodu
	    into   ls_durum_kodu
		from   cbs_vw_hesap_izleme
	    where  hesap_no = pn_hesap_no;

	   return ls_durum_kodu;
   exception
        when no_data_found then return null;
		  when others then
          raise_application_error (-20100, pkg_hata.getucpointer || '560' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
  end;

 /***************************************************************************************************************/
/*    Function sf_diger_gayrinakdi_durum_al                                                           */
/***************************************************************************************************************/
   Function sf_diger_gayrinakdi_durum_al ( pn_musteri_no        cbs_kredi_teminat_tanim.musteri_no%type,
     	  							      pn_teminat_sira_no   cbs_kredi_teminat_tanim.teminat_sira_no%type) return varchar2

   IS
      ls_durum_kodu varchar2(20) := null;
   BEGIN

	if  pn_musteri_no is not null and pn_teminat_sira_no is not null then
	      SELECT decode( durum ,'AKTIF','ACIK','A?IK','ACIK',durum)
	        INTO ls_durum_kodu
	        FROM cbs_kredi_teminat_tanim
	       WHERE  musteri_no = pn_musteri_no
	         AND  teminat_sira_no = pn_teminat_sira_no;
     end if;
      RETURN ls_durum_kodu;

   EXCEPTION
     WHEN no_data_found then return null;
      WHEN OTHERS then
          raise_application_error (-20100, pkg_hata.getucpointer || '561' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   END;

 /***************************************************************************************************************/
 /*     Procedure sp_teminat_onaya_uygunmu                                                         */
 /***************************************************************************************************************/
 Procedure sp_teminat_onaya_uygunmu(pn_islem_no number)
 is
  ls_durum				  varchar2(200);
  ls_numara				  varchar2(200);

  cek_durumu_uygun_degil              exception;
  cek_bakiyesi_uygun_degil 		      exception;
  senet_durumu_uygun_degil            exception;
  senet_bakiyesi_uygun_degil 		  exception;
  ihracat_durumu_uygun_degil          exception;
  ihracat_bakiyesi_uygun_degil 		  exception;
  algaran_durumu_uygun_degil          exception;
  algaran_bakiyesi_uygun_degil 		  exception;
  hesap_durumu_uygun_degil            exception;
  hesap_bakiyesi_uygun_degil 		  exception;
  diggayri_durumu_uygun_degil 		  exception;
  diggayri_bakiyesi_uygun_degil 	  exception;
  sozlesme_bakiyesi_uygun_degil		  exception;
  sozlesme_durumu_uygun_degil		  exception;
  ln_kullanilabilirtutar			  number;
  ln_tutar							  number;
  ln_temtutar						  number;
  ln_sozlesmedovizlibakiye			  number;
 cursor cursor_teminat is
 		select a.* ,
			   b.kullanilan_tutar eski_kullanilan_tutar
		from cbs_teminat_islem a, CBS_TEMINAT_ONAYONCE_ISLEM b
		where a.tx_no = pn_islem_no and
		 	  a.tx_no =b.tx_no and
			  a.teminat_no = b.teminat_no and
			  a.teminat_durumu = 'ACIK' and
			  a.kullanilan_tutar <>  b.kullanilan_tutar
		union
 		select a.*,
			  0 eski_kullanilan_tutar
		from cbs_teminat_islem a
		where a.tx_no=pn_islem_no and
				  a.teminat_durumu = 'ACIK' and
				  a.bloke_hesap_secimi = 'HESAP'
				  and a.teminat_no not in (select teminat_no
						                 from   CBS_TEMINAT_ONAYONCE_ISLEM
								   		 where tx_no  =pn_islem_no) ;
  Begin
   for cur_teminat in cursor_teminat
   loop
		 if  cur_teminat.teminat_kodu =  '01' then /*takas cek*/
	   			     ls_durum :=  pkg_takas.sf_takascek_durumu_al(cur_teminat.ref_cek_no);
					 ls_numara := to_char(cur_teminat.CEK_SUBE_KODU) ||'/' ||  to_char(cur_teminat.CEK_no);

					 if  PKG_TEMINAT.SF_TEMINAT_DURUMU_UYGUNMU('01', null, cur_teminat.REF_CEK_NO )= 'E' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_kullanilabilirtutar:=  nvl(cur_teminat.eski_kullanilan_tutar,0) + ln_temtutar - nvl(pkg_teminat.sf_cekin_kullanilan_tutari(cur_teminat.ref_cek_no,null,'E'),0);

						   if ln_tutar > ln_kullanilabilirtutar then
								 raise cek_bakiyesi_uygun_degil;
						    end if;
					 else
					 	 raise cek_durumu_uygun_degil;
					 end if;

	   		 /* senet*/
		elsif cur_teminat.teminat_kodu =  '11' then

	   			     ls_durum :=  pkg_senet.sf_senet_durumu_al(cur_teminat.bolum_kodu,cur_teminat.senet_no);
					 ls_numara := to_char(cur_teminat.bolum_kodu) ||'/' ||  to_char(cur_teminat.senet_no);

					 if  PKG_TEMINAT.SF_TEMINAT_DURUMU_UYGUNMU( '11', null, null, cur_teminat.BOLUM_KODU, cur_teminat.SENET_NO )= 'E' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_kullanilabilirtutar:= nvl(cur_teminat.eski_kullanilan_tutar,0) + ln_temtutar - nvl(pkg_teminat.sf_senet_kullanilan_tutari(cur_teminat.bolum_kodu,cur_teminat.senet_no,null,'E'),0);

						   if ln_tutar > ln_kullanilabilirtutar then
								 raise senet_bakiyesi_uygun_degil;
						    end if;
					 else
					 	 raise senet_durumu_uygun_degil;
					 end if;

	   		 /* ihracat & akreditif*/
		 elsif cur_teminat.teminat_kodu  in (   '09' ,'14') then
	   			     ls_durum :=  pkg_teminat.sf_ihracat_durumu_al(cur_teminat.REFERANS);
					 ls_numara := to_char(cur_teminat.REFERANS) ;
					 if  pkg_teminat.sf_teminat_durumu_uygunmu( cur_teminat.teminat_kodu, cur_teminat.referans)= 'E' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_kullanilabilirtutar:= nvl(cur_teminat.eski_kullanilan_tutar,0) + ln_temtutar - nvl(pkg_teminat.sf_ihracat_kullanilan_tutari(cur_teminat.REFERANS,null,'E'),0);

						   if ln_tutar > ln_kullanilabilirtutar then
								 raise ihracat_bakiyesi_uygun_degil;
						    end if;
					 else
						 	 raise ihracat_durumu_uygun_degil;
					 end if;

	   		 /* alinan garanti*/
		 elsif cur_teminat.teminat_kodu = '13' then
	   			     ls_durum :=  pkg_teminat.sf_alinangaranti_durumu_al(cur_teminat.REFERANS);
					 ls_numara := to_char(cur_teminat.REFERANS) ;

					 if    pkg_teminat.sf_teminat_durumu_uygunmu( cur_teminat.teminat_kodu, cur_teminat.referans)= 'E' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_kullanilabilirtutar:= nvl(cur_teminat.eski_kullanilan_tutar,0)  + ln_temtutar - nvl(pkg_teminat.sf_alingaran_kullanilan_tutari(cur_teminat.REFERANS,null,'E'),0);

						 if ln_tutar > ln_kullanilabilirtutar then
								 raise algaran_bakiyesi_uygun_degil;
						    end if;

					 else
					 	 raise algaran_durumu_uygun_degil;
					 end if;

				 /* Nakdi hesap*/
  	  elsif cur_teminat.teminat_kodu =   '12' then
	   			     ls_durum :=  pkg_teminat.sf_hesap_durum_al(cur_teminat.borclu_teminat_hesap_no);
					 ls_numara := to_char(cur_teminat.borclu_teminat_hesap_no) ;
					 if   ls_durum in ( 'A','ACIK') then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_kullanilabilirtutar:= pkg_hesap.Kullanilabilir_Bakiye_Al(cur_teminat.borclu_teminat_hesap_no);
						   if ln_tutar > ln_kullanilabilirtutar then
								 raise hesap_bakiyesi_uygun_degil;
						    end if;
					 else
					 	 raise hesap_durumu_uygun_degil;
					 end if;


			/*  15 sozlesmeler  */
  	  elsif cur_teminat.teminat_kodu =   '15' then
		 	     ls_durum := pkg_sozlesme.sf_sozlesme_Durum_Al(CUR_teminat.musteri_no,CUR_teminat.sozlesme_no,CUR_TEMINAT.ek_sozlesme_no);
				 ls_numara := to_char(cur_teminat.sozlesme_no ) ||',' || to_char(cur_teminat.ek_sozlesme_no) ;

				 if   ls_durum = 'ACIK' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_sozlesmedovizlibakiye := pkg_sozlesme.SF_SOZLESME_BAKIYE_AL(CUR_teminat.musteri_no,CUR_teminat.sozlesme_no,CUR_TEMINAT.ek_sozlesme_no);
						  ln_kullanilabilirtutar:= nvl(cur_teminat.eski_kullanilan_tutar,0) +  pkg_kur.yuvarla(cur_teminat.teminat_doviz_kodu,  pkg_kur.doviz_doviz_karsilik(cur_teminat.sozlesme_doviz_kodu,cur_teminat.teminat_doviz_kodu,null,ln_sozlesmedovizlibakiye,1,null,null,'O','A'));
						   if ln_tutar > ln_kullanilabilirtutar then
								 raise sozlesme_bakiyesi_uygun_degil;
						    end if;
				 else
					 	 raise sozlesme_durumu_uygun_degil;
				 end if;


			/* diger gayri nakdiler */
		 else
		 	   if cur_teminat.musteri_no is not null and cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO is not null then
		 	     ls_durum :=  pkg_teminat.sf_diger_gayrinakdi_durum_al(cur_teminat.musteri_no,cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO);
				 ls_numara := to_char(cur_teminat.musteri_no ) ||'/' || to_char(cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO) ;

				 if   PKG_TEMINAT.SF_TEMINAT_DURUMU_UYGUNMU( cur_teminat.TEMINAT_KODU, null, null,null,null, cur_teminat.MUSTERI_NO, cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO,null)= 'E' then
					 	  ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
						  ln_temtutar :=nvl(cur_teminat.teminat_tutari,0) ;
						  ln_kullanilabilirtutar:= nvl(cur_teminat.eski_kullanilan_tutar,0) + ln_temtutar - nvl(pkg_teminat.sf_diger_gayrin_kullan_tutari(cur_teminat.musteri_no,cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO,null,'E'),0);

						   if ln_tutar > ln_kullanilabilirtutar then
								 raise diggayri_bakiyesi_uygun_degil;
						    end if;
				 else
					 	 raise diggayri_durumu_uygun_degil;
				 end if;
				end if;

 	end if;
  end loop;

   EXCEPTION
     when no_data_found then null;
   	  when cek_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '544' || pkg_hata.getdelimiter|| ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when cek_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '545' || pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when senet_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '546' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when senet_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '547' || pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when ihracat_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '548' ||   pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when ihracat_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '549' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when algaran_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '550' ||   pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when algaran_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '551' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when diggayri_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '552' ||   pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when diggayri_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '553' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when hesap_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '554' ||   pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when hesap_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '555' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when sozlesme_durumu_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '596' ||   pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| ls_durum || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	  when sozlesme_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '597' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

	 when others then
	 	  raise_application_error (-20100, pkg_hata.getucpointer || '556' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 End;
/***************************************************************************************************************/
/*    PROCEDURE sp_teminat_ceksenetteminat_yap                                                       */
/***************************************************************************************************************/

  Procedure sp_teminat_ceksenetteminat_yap(pn_islem_no number)
   is
   cursor cursor_teminat_cek is
	  select a.tx_no,
	  		 a.teminat_no,
			 a.musteri_no,
 			 a.teminat_hesap_no,
			 a.teminat_doviz_kodu,
			 a.REF_CEK_NO,
			 a.teminat_kodu
	  from  cbs_teminat_islem  a,cbs_takas_cek b
	  where tx_no = pn_islem_no and
			teminat_kodu = '01'
			and a.ref_cek_no =b.ref_cek_no
			and b.tahsil_teminat = 'TAHSIL'
			and ( a.teminat_no not in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no)
			 or
			  a.teminat_no in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no and
								   		 kullanilan_tutar <> a.kullanilan_tutar)
			 ) ;



   cursor cursor_teminat_senet is
	  select a.tx_no,
	  		 a.teminat_no,
			 a.musteri_no,
 			 a.teminat_hesap_no,
			 a.teminat_doviz_kodu,
	  		 a.bolum_kodu,
	  		 a.senet_no,
			 a.teminat_kodu
	  from  cbs_teminat_islem a ,cbs_senet b
	  where a.tx_no = pn_islem_no and
			a.teminat_kodu = '11'
			and a.bolum_kodu = b.bolum_kodu
			and a.senet_no =b.senet_no
			and b.urun_tur_kod = 'TAHSIL'
			and ( a.teminat_no not in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no)
			 or
			  a.teminat_no in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no and
								   		 kullanilan_tutar <> a.kullanilan_tutar)
			 ) ;


  Begin

     For   cur_teminat_cek in   cursor_teminat_cek
	 Loop
	 	   insert into cbs_teminat_islem_tahsil_log(TX_NO, TEMINAT_NO, MUSTERI_NO, TEMINAT_HESAP_NO, TEMINAT_DOVIZ_KODU, REF_CEK_NO,teminat_kodu)
		   values (cur_teminat_cek.tx_no , cur_teminat_cek.teminat_no,cur_teminat_cek.musteri_no,cur_teminat_cek.teminat_hesap_no,
		   		  cur_teminat_cek.teminat_doviz_kodu,cur_teminat_cek.ref_cek_no,cur_teminat_cek.teminat_kodu);

	 	   pkg_takas.sp_takascek_tahstemin_guncelle(cur_teminat_cek.ref_cek_no ,'TEMINAT');
	 End loop;

	 For   cur_teminat_senet in   cursor_teminat_senet
	 Loop
 	 	   insert into cbs_teminat_islem_tahsil_log(TX_NO, TEMINAT_NO, MUSTERI_NO, TEMINAT_HESAP_NO, TEMINAT_DOVIZ_KODU, BOLUM_KODU, SENET_NO,teminat_kodu)
		   values ( cur_teminat_senet.tx_no , cur_teminat_senet.teminat_no,cur_teminat_senet.musteri_no,cur_teminat_senet.teminat_hesap_no,cur_teminat_senet.teminat_doviz_kodu,
		   		  	cur_teminat_senet.bolum_kodu,cur_teminat_senet.senet_no,cur_teminat_senet.teminat_kodu);

	 	   pkg_senet.sp_senet_tahsiltemin_guncelle(cur_teminat_senet.bolum_kodu,
		   										   cur_teminat_senet.senet_no,
												   'TEMINAT');
	 End loop;

  End;

/***************************************************************************************************************/
/*     Procedure sp_teminat_blokekoy_hesap_ac                                                   */
/***************************************************************************************************************/

  Procedure sp_teminat_blokekoy_hesap_ac(pn_islem_no number )
  is
    ls_bloke   varchar2(200);
	ln_nakdi_teminat_hesap_no  number;
    cursor cursor_teminat_islem is
	  select teminat_no,
	 		 bloke_hesap_secimi
	  from  cbs_teminat_islem
	  where tx_no = pn_islem_no and
	 	    bloke_hesap_secimi in ( 'BLOKE','HESAP')
			and teminat_kodu = '12'
 			and teminat_durumu = 'ACIK'
			and
			( teminat_no not in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no)
			 or
			  teminat_no in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no and
								   		 kullanilan_tutar <> cbs_teminat_islem.kullanilan_tutar)
			 ) ;

  Begin

     For  cur_teminat_islem in  cursor_teminat_islem Loop
	 /* bloke ise bloke koyma programi cagrilir*/
	   if cur_teminat_islem.bloke_hesap_secimi = 'BLOKE' then
	      pkg_Teminat.Sp_Kredi_Teminat_Bloke_Yarat( pn_islem_no,cur_teminat_islem.teminat_no);
	   else
	 /* hesap ise  */
	 		ln_nakdi_teminat_hesap_no := pkg_Teminat.Sp_Kredi_Teminat_Vadesiz_Ac( pn_islem_no,cur_teminat_islem.teminat_no);
	   end if;

	 End loop;

  End;

  Procedure sp_teminat_bloke_iptal(pn_islem_no number ,ps_islem_tipi varchar2 default 'ACILIS')
  is
      ls_aciklama          varchar2 (2000);
      ls_bloke_neden       varchar2 (2000);
      ls_islem_tanim_kod   varchar2 (2000)           := '1200';
  	  ln_kullanilan_tutar  number := 0;
      ls_bloke_referans    cbs_bloke.bloke_referans%type := null;

	  cursor cursor_bloke is
       SELECT   teminat_hesap_no,musteri_no,
	   			BORCLU_TEMINAT_hesap_no,
				BORCLU_teminat_hesap_doviz, 'A',
                kullanilan_tutar,
                pkg_muhasebe.banka_tarihi_bul,
				referans,
				nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(borclu_teminat_hesap_no),0) bakiye,
				teminat_no,
				'ACILIS' islem_tipi,
				 kullanilan_tutar onceki_tutar,
				 TEKLIF_MUSTERI_NO
           FROM cbs_teminat_islem
          WHERE tx_no = pn_islem_no AND
		    	teminat_kodu = '12' and
				teminat_durumu = 'ACIK' and
			    bloke_hesap_secimi = 'BLOKE' and
				teminat_no not in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no)
		 union
/* guncelleme ayni uygulamadir */
		 SELECT
		  		a.teminat_hesap_no,a.musteri_no,
	   			a.BORCLU_TEMINAT_hesap_no,
				a.BORCLU_teminat_hesap_doviz, 'A',
                b.kullanilan_tutar,
                pkg_muhasebe.banka_tarihi_bul,
				a.referans,
				nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(a.borclu_teminat_hesap_no),0) bakiye,
				a.teminat_no,
				'GUNCELLE' islem_tipi,
				b.kullanilan_tutar onceki_tutar,
				a.TEKLIF_MUSTERI_NO
           FROM cbs_teminat_islem a, CBS_TEMINAT_ONAYONCE_ISLEM b
          WHERE a.tx_no = pn_islem_no AND
		  		b.tx_no = pn_islem_no AND
				a.teminat_no =b.teminat_no and
			    a.bloke_hesap_secimi = 'BLOKE' and
				a.teminat_kodu = '12' and
				b.teminat_durumu = 'ACIK' and
				a.kullanilan_tutar <> b.kullanilan_tutar and
				ps_islem_tipi != 'KAPAMA'
	union
/* kapama ayni uygulamadir */
		 SELECT
		  		a.teminat_hesap_no,a.musteri_no,
	   			a.BORCLU_TEMINAT_hesap_no,
				a.BORCLU_teminat_hesap_doviz, 'A',
                b.kullanilan_tutar,
                pkg_muhasebe.banka_tarihi_bul,
				a.referans,
				nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(a.borclu_teminat_hesap_no),0) bakiye,
				a.teminat_no,
				'KAPAMA' islem_tipi,
				b.kullanilan_tutar onceki_tutar,
				a.TEKLIF_MUSTERI_NO
           FROM cbs_teminat_islem a, CBS_TEMINAT_ONAYONCE_ISLEM b
          WHERE a.tx_no = pn_islem_no AND
		  		b.tx_no = pn_islem_no AND
				a.teminat_no =b.teminat_no and
			    a.bloke_hesap_secimi = 'BLOKE' and
				a.teminat_kodu = '12' and
				b.teminat_durumu = 'ACIK' and
				ps_islem_tipi = 'KAPAMA';

   cursor cur_islem is
    select
		pkg_muhasebe.banka_tarihi_bul kayit_tarih,
		sysdate kayit_sistem_tarihi,
		nvl(pkg_baglam.Kullanici_kodu,iptal_kullanici_kodu) kayit_kullanici_kodu,
		nvl(pkg_baglam.bolum_kodu,iptal_kullanici_bolum_kodu) kayit_kullanici_bolum_kodu,
		pkg_muhasebe.banka_tarihi_bul dogru_tarih	,
		nvl(pkg_baglam.Kullanici_kodu,iptal_kullanici_kodu)  dogru_kullanici_kodu,
		nvl(pkg_baglam.bolum_kodu,iptal_kullanici_bolum_kodu)	 dogru_kullanici_bolum_kodu,
		pkg_muhasebe.banka_tarihi_bul onay_tarih,
		sysdate onay_sistem_tarihi,
		nvl(pkg_baglam.Kullanici_kodu,iptal_kullanici_kodu) onay_kullanici_kodu,
		nvl(pkg_baglam.bolum_kodu,iptal_kullanici_bolum_kodu)	 onay_kullanici_bolum_kodu
	from cbs_islem
	where numara = pn_islem_no ;

	r_islem cur_islem%rowtype;
   BEGIN

    for c_islem in cur_islem
	 loop
	  r_islem := c_islem ;
	 end loop;

      ls_bloke_neden :=
         pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_NEDEN_KODU'
                                  );

	  for cur_bloke in cursor_bloke loop

	   ls_bloke_referans := null;

	   if cur_bloke.bakiye > 0 then
		  	 if cur_bloke.bakiye > cur_bloke.kullanilan_tutar then
			  	  ln_kullanilan_tutar := cur_bloke.kullanilan_tutar;
			 else
			 	  ln_kullanilan_tutar :=cur_bloke.bakiye;
			end if;
		else
   	 	  ln_kullanilan_tutar :=0;
		end if;
		if cur_bloke.teminat_hesap_no is not null then
         ls_aciklama :=      pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_ACIKLAMA'
                                  ) ||' ' || to_char(cur_bloke.teminat_hesap_no) ;
		 else
		 ls_aciklama :=      pkg_parametre.varchar_al (pkg_kredi.modul_tur_kod,
                                   NULL,
                                   NULL,
                                   'BLOKE_ACIKLAMA_MUSTERI'
                                  ) ||' ' || to_char(cur_bloke.TEKLIF_MUSTERI_NO) ;

		end if;
  if  cur_bloke.referans is not null then
  /* mevcut olan kapatilir.acilis ve guncelleme iptalinde calisir*/
 	if  cur_bloke.islem_tipi != 'KAPAMA' then

	  if  pkg_bloke.sf_bloke_durum_kodu_al(cur_bloke.referans) != 'K' then
          pkg_bloke.sp_bloke_yarat (
								   ps_bloke_referans => cur_bloke.referans,
								   pn_musteri_no =>cur_bloke.musteri_no,
								   pn_HESAP_NO=>cur_bloke.borclu_teminat_hesap_no,
								   ps_DOVIZ_KODU=> cur_bloke.borclu_teminat_hesap_doviz,
								   pn_BLOKE_TUTARI=>0,
								   ps_BLOKE_NEDEN_KODU=>ls_bloke_neden,
								   ps_ACIKLAMA=>ls_aciklama,
								   pd_BLOKE_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pd_BLOKE_BITIS_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pn_tx_no=> pn_islem_no,
								   p_COZ_KAYIT_TARIH =>r_islem.kayit_tarih,
								   p_COZ_KAYIT_SISTEM_TARIH=>r_islem.kayit_sistem_tarihi,
								   p_COZ_KAYIT_KULLANICI_KODU=>r_islem.kayit_kullanici_kodu,
								   p_COZ_KAYIT_KULLANICI_BOLUMKOD=>r_islem.kayit_kullanici_bolum_kodu,
								   p_COZ_DOGRU_TARIH=>r_islem.dogru_tarih,
								   p_COZ_DOGRU_KULLANICI_KODU=>r_islem.dogru_kullanici_kodu,
								   p_COZ_DOGRU_KULLANICI_BOLUMKOD=>r_islem.dogru_kullanici_bolum_kodu,
								   p_COZ_ONAY_TARIH=>r_islem.onay_tarih,
								   p_COZ_ONAY_SISTEM_TARIH=>r_islem.onay_sistem_tarihi,
								   p_COZ_ONAY_KULLANICI_KODU=>r_islem.onay_kullanici_kodu,
								   p_COZ_ONAY_KULLANICI_BOLUMKOD=>r_islem.onay_kullanici_bolum_kodu,
								   ps_kapama=>'KAPAMA');
		end if;
	end if;

/* yeni tutar acilis yap?l?r , kapama ve guncelleme iptallerinde calisir */
 	if  cur_bloke.islem_tipi != 'ACILIS' then

/* Acilis iptali disindakiler yeninden yaratilir */
	/* Yeni bloke kaydi yaratilir */
	  if nvl(ln_kullanilan_tutar,0)  <> 0 then
        pkg_bloke.sp_bloke_yarat (
							      ls_bloke_referans,
								   cur_bloke.musteri_no,
	   							   cur_bloke.borclu_teminat_hesap_no,
	   							   cur_bloke.borclu_teminat_hesap_doviz,
								   ln_kullanilan_tutar,
			 					   ls_bloke_neden,
								   ls_aciklama,
			 					   pkg_muhasebe.banka_tarihi_bul,
								   null,
								   null,
								   pn_islem_no,
								   r_islem.kayit_tarih,
									r_islem.kayit_sistem_tarihi,
									r_islem.kayit_kullanici_kodu,
									r_islem.kayit_kullanici_bolum_kodu,
									r_islem.dogru_tarih	,
									r_islem.dogru_kullanici_kodu,
									r_islem.dogru_kullanici_bolum_kodu,
									r_islem.onay_tarih,
									r_islem.onay_sistem_tarihi,
									r_islem.onay_kullanici_kodu,
									r_islem.onay_kullanici_bolum_kodu
								  	) ;

  	     UPDATE cbs_teminat_islem
	     SET   REFERANS = ls_bloke_referans,
		 	   kullanilan_tutar = ln_kullanilan_tutar
	     WHERE tx_no = pn_islem_no AND teminat_no = cur_bloke.teminat_no;
		 begin
		     UPDATE cbs_teminat_onayonce_islem
		     SET   REFERANS = ls_bloke_referans,
			 	   kullanilan_tutar = ln_kullanilan_tutar
		     WHERE tx_no = pn_islem_no AND teminat_no = cur_bloke.teminat_no;
			 exception when others then null;

		 end;
	 end if;
    end if;
 end if;
   End loop;

  End;


/***************************************************************************************************************/
/*  Procedure sp_teminat_gayrinakdikayitkont
/* ayn? kay?t girisi yap?ld???nda bakiye kontrolu yap?l?r.                                              */
/***************************************************************************************************************/

  procedure sp_teminat_gayrinakdikayitkont(pn_islem_no number)
  is

  ls_durum				  varchar2(200);
  ls_numara				  varchar2(200);
  ln_bakiye   			  number := 0;
  ln_kullanilabilirtutar  number := 0;
  ln_temtutar  			  number := 0 ;
  ln_tutar 				  number := 0;
    cursor cursor_gayrinakdi is
   	select musteri_no,
		   kredi_teminat_tanim_sira_no,
		   nvl(teminat_tutari,0) teminat_tutari,
		   sum(nvl(kullanilan_tutar,0)) kullanilan_tutar
	from cbs_teminat_islem
	where tx_no = pn_islem_no and
		  teminat_durumu = 'ACIK' and
		  Kredi_Teminat_Tanim_Sira_No Is Not Null
		  Group By  musteri_no,
		  		    kredi_teminat_tanim_sira_no,
		  		    nvl(teminat_tutari,0)
		  Having Count(*) > 1;

  cursor cursor_nakdi is
   	select borclu_teminat_hesap_no,
		   sum(nvl(kullanilan_tutar,0)) kullanilan_tutar
	from cbs_teminat_islem
	where tx_no = pn_islem_no and
		  teminat_durumu = 'ACIK' and
		  NAKDI_GAYRI_SECIMI = 'NAKDI'
		  Group By borclu_teminat_hesap_no
		  Having Count(*) > 1;

    gayrinakdi_bakiye_asimi       exception;
	hesap_bakiyesi_uygun_degil    exception;
  Begin

  	   for cur_teminat in cursor_gayrinakdi
	     loop
		         ls_numara :=   to_char(cur_teminat.musteri_no ) ||'/' || to_char(cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO) ;
				 ln_temtutar := cur_teminat.teminat_tutari ;
				 ln_kullanilabilirtutar:= ln_temtutar - nvl(pkg_teminat.sf_diger_gayrin_kullan_tutari(cur_teminat.musteri_no,cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO,null,'E'),0);

		      if ln_kullanilabilirtutar <  cur_teminat.kullanilan_tutar    Then
			      raise gayrinakdi_bakiye_asimi;
			   end if;
		 end loop;

	 for cur_teminat in cursor_nakdi
     loop
		 ls_numara := to_char(cur_teminat.borclu_teminat_hesap_no) ;
		 ln_tutar := nvl(cur_teminat.kullanilan_tutar,0) ;
		 ln_kullanilabilirtutar:= pkg_hesap.Kullanilabilir_Bakiye_Al(cur_teminat.borclu_teminat_hesap_no);
	      if ln_kullanilabilirtutar <  cur_teminat.kullanilan_tutar  Then
				  raise hesap_bakiyesi_uygun_degil;
		   end if;
	 end loop;


	 EXCEPTION
     when no_data_found then null;
   	 when gayrinakdi_bakiye_asimi then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '564' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_temtutar) || pkg_hata.getdelimiter||  to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	 when hesap_bakiyesi_uygun_degil then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '565' ||  pkg_hata.getdelimiter||ls_numara||  pkg_hata.getdelimiter|| to_char(ln_kullanilabilirtutar) || pkg_hata.getdelimiter||to_char(ln_tutar) || pkg_hata.getdelimiter|| pkg_hata.getucpointer    );


  End;

/***************************************************************************************************************/
/*    Function  sf_teminat_durumu_uygumu                                              */
/***************************************************************************************************************/
 Function  sf_teminat_durumu_uygunmu(ps_teminat_kodu cbs_teminat.teminat_kodu%type,
 		   							ps_referans      cbs_teminat_islem.REFERANS%type default null,
									pn_ref_cek_no    cbs_teminat.ref_cek_no%type  default null,
									ps_bolum_kodu    cbs_teminat_islem.bolum_kodu%TYPE  default null,
									pn_senet_no      cbs_teminat_islem.senet_no%TYPE  default null,
									pn_musteri_no 	 cbs_kredi_teminat_tanim.musteri_no%type  default null,
  								    pn_teminat_sira_no cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type  default null,
									pn_hesap_no       cbs_hesap.hesap_no%type  default null,
									pn_sozlesme_no	  cbs_sozlesme.sozlesme_no%type default null,
									pn_ek_sozlesme_no cbs_sozlesme.ek_sozlesme_no%type default null) return VARCHAR2

 is
  ls_durum varchar2(2000);
   ls_sonuc varchar2(1) := 'H';

 Begin
 	  case
 		when ps_teminat_kodu is null then return 'H';
	  	when  ps_teminat_kodu ='01' then --takas cek
	         ls_durum :=  pkg_takas.sf_takascek_durumu_al(pn_ref_cek_no);
			 if ls_durum  in ('A','A?IK','ACIK','TAHSIL','TAKASTA','TAKAS') then
			   ls_sonuc := 'E';
			 else
			   ls_sonuc := 'H';
	  	   	 end if;
		      return ls_sonuc ;
	  	 when  ps_teminat_kodu= '11' then --senet
			    ls_durum :=  pkg_senet.sf_senet_durumu_al(ps_bolum_kodu,pn_senet_no);
				if  ls_durum in ('A','KS','K','P','ACIK')  then
				   ls_sonuc := 'E';
				else
				   ls_sonuc := 'H';
		  	   	end if;
		        return ls_sonuc ;
	   		 /* ihracat & akreditif &al?nan garanti*/
		 when ps_teminat_kodu in( '09', '14') then
	   		     ls_durum :=  pkg_teminat.sf_ihracat_durumu_al(ps_referans);
				if  ls_durum in  ('A','ACIK','A?IK','GUNCEL')  then
				   ls_sonuc := 'E';
				else
				   ls_sonuc := 'H';
		  	   	end if;
				 return ls_sonuc ;
		 		 /* al?nan garanti*/
		 when ps_teminat_kodu = '13' then
	   		     ls_durum :=  pkg_teminat.sf_alinangaranti_durumu_al(ps_referans);
				if  ls_durum in  ('A','ACIK','A?IK','GUNCEL')  then
				   ls_sonuc := 'E';
				else
				   ls_sonuc := 'H';
		  	   	end if;
				 return ls_sonuc ;
	   		 /* nakdi hesap*/
		  when ps_teminat_kodu ='12' then
   			     ls_durum :=  pkg_teminat.sf_hesap_durum_al(pn_hesap_no);
			  if   ls_durum in ( 'A','ACIK') then
				   ls_sonuc := 'E';
				 else
				   ls_sonuc := 'H';
		  	  end if;
			   return ls_sonuc ;
	  	  when ps_teminat_kodu ='15' then
		 	   ls_durum := pkg_sozlesme.sf_sozlesme_Durum_Al(pn_musteri_no,pn_sozlesme_no,pn_ek_sozlesme_no);
			if   ls_durum in ( 'ACIK','A') then
				   ls_sonuc := 'E';
				 else
				   ls_sonuc := 'H';
		  	 end if;
			  return ls_sonuc ;
		 else /* diger gayri nakdiler */
		 	   ls_durum :=  pkg_teminat.sf_diger_gayrinakdi_durum_al(pn_musteri_no,pn_TEMINAT_SIRA_NO);
 			  if   ls_durum in ( 'A','ACIK') then
				   ls_sonuc := 'E';
				 else
				   ls_sonuc := 'H';
		  	  end if;
			   return ls_sonuc ;
		 end case;
   RETURN ls_sonuc;

 Exception

  WHEN no_data_found then null;
  When others then
  	   raise_application_error (-20100, pkg_hata.getucpointer || '557' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 End;

/***************************************************************************************************************/
/*    Procedure sp_teminat_hepsi_referans_al                                       */
/*  cbs_vw_teminat_hepsi view 's? icin haz?rland?
/***************************************************************************************************************/
 Procedure sp_teminat_hepsi_referans_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type,
									  ps_durum out varchar2 ,
									  ps_referans  out varchar2,
  									  pn_teminat_tutari out number,
									  pn_bakiye out number)
 is

   ls_referans        cbs_teminat_islem.REFERANS%type;
   ln_ref_cek_no      cbs_teminat.ref_cek_no%type;
   ls_bolum_kodu      cbs_teminat_islem.bolum_kodu%TYPE;
   ln_senet_no        cbs_teminat_islem.senet_no%TYPE;
   ln_musteri_no 	  cbs_kredi_teminat_tanim.musteri_no%type;
   ln_teminat_sira_no cbs_teminat_islem.kredi_teminat_tanim_sira_no%type;
   ln_hesap_no        cbs_hesap.hesap_no%type ;
   ln_sozlesme_no	  cbs_teminat.sozlesme_no%type;
   ln_ek_sozlesme_no  cbs_teminat.ek_sozlesme_no%type;
   ln_sozlesmedovizlibakiye		number := 0;
   ln_nakdihesap				number := 0;
   ls_sozlesme_doviz_kodu		cbs_hesap_kredi.doviz_kodu%type;
   ls_teminat_doviz_kodu		cbs_hesap_kredi.doviz_kodu%type;
   ls_takascek  varchar2(2000);
   ls_bloke_hesap_secimi	   varchar2(20);
    cursor cur_temin_islem is
   	 	  select ref_cek_no,
		  		 bolum_kodu,
				 senet_no,
				 REFERANS,
				 musteri_no,
				 kredi_teminat_tanim_sira_no,
				 borclu_teminat_hesap_no,
				 sozlesme_no,
				 ek_sozlesme_no ,
				 sozlesme_doviz_kodu,
				 teminat_doviz_kodu,
				 cek_no,
 				 nakdi_teminat_hesap_no,
				 bloke_hesap_secimi
		  from cbs_teminat_islem
		  where tx_no = pn_tx_no and
		  		teminat_no = pn_teminat_no and
				teminat_kodu = ps_teminat_kodu
		  order by teminat_no		;

    cursor cur_temin is
   	 	  select ref_cek_no,
		  		 bolum_kodu,
				 senet_no,
				 REFERANS,
				 musteri_no,
				 kredi_teminat_tanim_sira_no,
				 borclu_teminat_hesap_no,
				 sozlesme_no,
				 ek_sozlesme_no,
				 sozlesme_doviz_kodu,
				 teminat_doviz_kodu,
				 cek_no,
				 nakdi_teminat_hesap_no,
				 bloke_hesap_secimi
		  from cbs_teminat
		  where teminat_no = pn_teminat_no and
				teminat_kodu = ps_teminat_kodu
		  order by teminat_no			;

 Begin
 	  if nvl(pn_tx_no,0) <> 0 then
	   	  if cur_temin_islem%isopen then
			   close cur_temin_islem;
 		   end if;

		   Open cur_temin_islem ;

		      fetch cur_temin_islem into
					    ln_ref_cek_no ,
				 		 ls_bolum_kodu ,
						 ln_senet_no,
						 ls_referans,
						 ln_musteri_no,
						 ln_teminat_sira_no,
						 ln_hesap_no,
						 ln_sozlesme_no,
						 ln_ek_sozlesme_no,
		 				 ls_sozlesme_doviz_kodu,
				 		 ls_teminat_doviz_kodu,
						 ls_takascek,
						 ln_nakdihesap,
						 ls_bloke_hesap_secimi;

		  if cur_temin_islem%isopen then
			   close cur_temin_islem;
		  end if;

	  else
		if cur_temin%isopen then
			   close cur_temin;
		  end if;

		   Open cur_temin ;

		      fetch cur_temin into
					    ln_ref_cek_no ,
				 		 ls_bolum_kodu ,
						 ln_senet_no,
						 ls_referans,
						 ln_musteri_no,
						 ln_teminat_sira_no,
						 ln_hesap_no,
						 ln_sozlesme_no,
						 ln_ek_sozlesme_no,
						 ls_sozlesme_doviz_kodu,
				 		 ls_teminat_doviz_kodu,
						 ls_takascek	,
						 ln_nakdihesap ,
						 ls_bloke_hesap_secimi;

		  if cur_temin%isopen then
			   close cur_temin;
		  end if;

    end if;
 	  case
	  	when  ps_teminat_kodu ='01' then --takas cek
	          ps_durum :=  pkg_takas.sf_takascek_durumu_al(ln_ref_cek_no);
			  pn_teminat_tutari := nvl( pkg_takas.sf_takascek_tutari_al(ln_ref_cek_no),0);
			  pn_bakiye :=  pn_teminat_tutari - nvl(pkg_teminat.sf_cekin_kullanilan_tutari(ln_ref_cek_no,pn_tx_no,'E'),0);
			  ps_referans := to_char(ls_takascek);
	  	when  ps_teminat_kodu= '11' then --senet
			  ps_durum :=  pkg_senet.sf_senet_durumu_al(ls_bolum_kodu,ln_senet_no);
			  pn_teminat_tutari :=  nvl( pkg_senet.sf_senet_tutari_al(ls_bolum_kodu,ln_senet_no),0);
			  pn_bakiye :=  pn_teminat_tutari - nvl(pkg_teminat.sf_senet_kullanilan_tutari(ls_bolum_kodu,ln_senet_no,null,'E'),0);
			  ps_referans := ls_bolum_kodu ||'/'|| to_char(ln_senet_no);
	   		 /* ihracat & akreditif &al?nan garanti*/
		 when ps_teminat_kodu in( '09', '14') then
	   		  ps_durum :=  pkg_teminat.sf_ihracat_durumu_al(ls_referans);
			  pn_teminat_tutari := nvl(pkg_teminat.SF_IHRACAT_DOSYA_TUTARI_AL(ls_referans),0);
  			  pn_bakiye :=  pn_teminat_tutari - nvl(pkg_teminat.sf_ihracat_kullanilan_tutari(ls_REFERANS,null,'E'),0);
			  ps_referans := ls_referans;
		 		 /* al?nan garanti*/
		 when ps_teminat_kodu = '13' then
	   		  ps_durum :=  pkg_teminat.sf_alinangaranti_durumu_al(ls_referans);
			  pn_teminat_tutari :=pkg_teminat.sf_alingaran_dosya_tutari_al(ls_referans);
			  pn_bakiye := pn_teminat_tutari - nvl(pkg_teminat.sf_alingaran_kullanilan_tutari(ls_REFERANS,null,'E'),0);
			  ps_referans := ls_referans;
	   		 /* nakdi hesap*/
		  when ps_teminat_kodu ='12' then
   			   ps_durum :=  pkg_teminat.sf_hesap_durum_al(ln_hesap_no);
			   pn_teminat_tutari :=pkg_hesap.kullanilabilir_bakiye_al(ln_hesap_no);
 			   pn_bakiye := pn_teminat_tutari;
			   if ls_bloke_hesap_secimi = 'HESAP' then
			   	   ps_referans := to_char(ln_nakdihesap);
				else
			 	   ps_referans := to_char(ls_referans);
			   end if;
			   /*sozlesmeler*/
		  when ps_teminat_kodu ='15' then
   			   ps_durum :=  pkg_sozlesme.sf_sozlesme_Durum_Al(ln_musteri_no,ln_sozlesme_no,ln_ek_sozlesme_no);
   			   pn_teminat_tutari :=pkg_sozlesme.sf_sozlesme_tutari_Al(ln_musteri_no,ln_sozlesme_no,ln_ek_sozlesme_no);
			   ln_sozlesmedovizlibakiye := pkg_sozlesme.sf_sozlesme_bakiye_al(ln_musteri_no,ln_sozlesme_no,ln_ek_sozlesme_no);
			   pn_bakiye:=  pkg_kur.yuvarla(ls_teminat_doviz_kodu,pkg_kur.doviz_doviz_karsilik(ls_sozlesme_doviz_kodu,ls_teminat_doviz_kodu,null,ln_sozlesmedovizlibakiye,1,null,null,'O','A'));
			   ps_referans := to_char(ln_sozlesme_no)|| '/'|| to_char(ln_ek_sozlesme_no);
		 else /* diger gayri nakdiler */
		 	   ps_durum :=  pkg_teminat.sf_diger_gayrinakdi_durum_al(ln_musteri_no,ln_TEMINAT_SIRA_NO);
			   pn_teminat_tutari := pkg_teminat.sf_diger_gayrinakdi_tutar_al(ln_musteri_no,ln_teminat_sira_no);
			   pn_bakiye := pn_teminat_tutari - nvl(pkg_teminat.sf_diger_gayrin_kullan_tutari(ln_musteri_no,ln_teminat_sira_no,null,'E'),0);
			   ps_referans := to_char(ln_musteri_no) || '/' ||to_char(ln_TEMINAT_SIRA_NO);
		 end case;

 Exception
--  when no_data_found then null;
  When others then
  	   raise_application_error (-20100, pkg_hata.getucpointer || '557' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
 End;

  /***************************************************************************************************************/
/*   Function sf_teminat_hepsi_referdurum_al                                            */
/***************************************************************************************************************/
 Function sf_teminat_hepsi_referdurum_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return varchar2
 is
   ls_durum varchar2(20);
   ls_referans varchar2(100);
   ln_tutar number := 0;
   ln_bakiye number := 0;
 Begin
 	   pkg_teminat.sp_teminat_hepsi_referans_al(pn_tx_no,pn_teminat_no,ps_teminat_kodu,ls_durum,ls_referans ,ln_tutar,ln_bakiye);

	   return ls_durum;
	exception
     when others then return null;
 End;

 /***************************************************************************************************************/
/*   Function sf_teminat_gunceltutari_al                                            */
/***************************************************************************************************************/
 Function sf_teminat_gunceltutari_al (pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return number
 is
   ls_durum varchar2(20);
   ls_referans varchar2(100);
   ln_tutar number := 0;
   ln_bakiye number := 0;
 Begin
 	   pkg_teminat.sp_teminat_hepsi_referans_al(pn_tx_no,pn_teminat_no,ps_teminat_kodu,ls_durum,ls_referans ,ln_tutar ,ln_bakiye);

	   return ln_tutar;
	exception
     when others then return 0;
 End;

 Function sf_teminat_bakiye_al (pn_tx_no number, pn_teminat_no  number,
		 							   ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return number
 is
   ls_durum varchar2(20);
   ls_referans varchar2(100);
   ln_tutar number := 0;
   ln_bakiye number := 0;

 Begin
 	   pkg_teminat.sp_teminat_hepsi_referans_al(pn_tx_no,pn_teminat_no,ps_teminat_kodu,ls_durum,ls_referans ,ln_tutar,ln_bakiye);

	   return ln_bakiye;
	exception
     when others then return 0;
 End;



 /***************************************************************************************************************/
/*   Function sf_teminat_hepsi_referans_al                                             */
/***************************************************************************************************************/
 Function sf_teminat_hepsi_referans_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return varchar2
 is
   ls_durum varchar2(20);
   ls_referans varchar2(100);
   ln_tutar number := 0;
   ln_bakiye number := 0;

 Begin
 	   pkg_teminat.sp_teminat_hepsi_referans_al(pn_tx_no,pn_teminat_no,ps_teminat_kodu,ls_durum,ls_referans,ln_tutar,ln_bakiye);
	   return ls_referans;
	  Exception
     when others then return null;
 End;

 /***************************************************************************************************************/
/*    Function  Sf_Teminat_Alt_Kod_Aciklamasi                                            */
/***************************************************************************************************************/

   Function  Sf_Teminat_Alt_Kod_Aciklamasi(ps_teminat_kodu cbs_teminat_alt_kodlari.teminat_kodu%type, ps_teminat_alt_kodu cbs_teminat_alt_kodlari.teminat_alt_kodu%type) return cbs_teminat_alt_kodlari.aciklama%type
   is
    ls_aciklama cbs_teminat_alt_kodlari.aciklama%type := null;
   Begin
		    select aciklama
		    into  ls_aciklama
			from  cbs_teminat_alt_kodlari
			where teminat_kodu = ps_teminat_kodu and
				  teminat_alt_kodu = ps_teminat_alt_kodu;

   if ls_aciklama is null then
       select aciklama
	   into  ls_aciklama
	   from  cbs_teminat_kodlari
	   where teminat_kodu = ps_teminat_kodu ;
    end if;

    return ls_aciklama;

	Exception
	 when no_data_found then
	 		 select aciklama
		    into  ls_aciklama
			from  cbs_teminat_kodlari
			where teminat_kodu = ps_teminat_kodu ;

	      return ls_aciklama ;
	 when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '466' || pkg_hata.getDelimiter ||to_char(SQLCODE) || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
    End;

 /***************************************************************************************************************/
/*    Function   Sf_Teminat_Kod_Aciklamasi                                           */
/***************************************************************************************************************/

Function  Sf_Teminat_Kod_Aciklamasi(ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return cbs_teminat_kodlari.aciklama%type
   is
    ls_aciklama cbs_teminat_kodlari.aciklama%type;
   Begin

	    select aciklama
	    into  ls_aciklama
		from  cbs_teminat_kodlari
		where teminat_kodu = ps_teminat_kodu ;

    return ls_aciklama;

	Exception
	 when no_data_found then return null;
	 when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '466' || pkg_hata.getDelimiter ||to_char(SQLCODE) || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
    End;

 /***************************************************************************************************************/
/*    Procedure sp_onayoncesi_teminat_at                                       */
/***************************************************************************************************************/
 Procedure sp_onayoncesi_teminat_at(pn_islem_no number )
 is
 Begin
 	  insert into CBS_TEMINAT_ONAYONCE_ISLEM
	  (TX_NO, TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO,
		  TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI,
		  KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU,
		  CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU,
		  SENET_NO, REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA,
		  BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF, HESAP_URUN_TUR_KOD,
		  HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI, teklif_musteri_no,
		  KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO,
		  BORCLU_TEMINAT_HESAP_DOVIZ, NAKDI_TEMINAT_HESAP_NO,
		  NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS, KREDI_TEKLIF_SATIR_NO,
		  TEMINAT_ALIS_TARIHI,
		 SOZLESME_NO,EK_SOZLESME_NO	,SOZLESME_DOVIZ_KODU  )
	  select
		  pn_islem_no, TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO,
		  TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI,
		  KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU,
		  CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU,
		  SENET_NO, REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA,
		  BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF, HESAP_URUN_TUR_KOD,
		  HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI,
		  teklif_musteri_no,
		  KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO,
		  BORCLU_TEMINAT_HESAP_DOVIZ, NAKDI_TEMINAT_HESAP_NO,
		  NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS, KREDI_TEKLIF_SATIR_NO,
		  nvl(TEMINAT_ALIS_TARIHI,pkg_muhasebe.banka_tarihi_bul),
		 SOZLESME_NO,EK_SOZLESME_NO ,SOZLESME_DOVIZ_KODU
	  from cbs_teminat
 	  where teminat_no in ( select teminat_no
								  from cbs_teminat_islem
								  where tx_no = pn_islem_no);

 End;

 /***************************************************************************************************************/
/*     Procedure sp_nakdihesapblokekoyac                                       */
/***************************************************************************************************************/
 Procedure sp_nakdihesapblokekoyac(pn_islem_no number ,pn_islem number)
  is
  /* kontrol sonras?nda 1 gonderilirse bloke bonulur ,
   fis kes oncesi -1 ile a?ilir */
  	cursor cursor_islem is
			select
			       a.BORCLU_TEMINAT_HESAP_NO,
				   pn_islem * nvl(a.Kullanilan_tutar,0) kullanilan_tutar
			from  cbs_teminat_islem a
			where a.tx_no=pn_islem_no and
				  a.teminat_durumu = 'ACIK' and
				  a.bloke_hesap_secimi = 'HESAP';

  Begin
   for cur_islem in cursor_islem loop
   	 Pkg_Hesap.BlokeTutariGuncelle(cur_islem.BORCLU_TEMINAT_HESAP_NO,cur_islem.kullanilan_tutar);
	end loop ;
  End;

 /***************************************************************************************************************/
/*    Procedure sp_ciftkayitkontrolu                                       */
/***************************************************************************************************************/
 Procedure sp_ciftkayitkontrolu(pn_islem_no number)
  is
  ls_referans				  varchar2(200);
  ls_kod					  varchar2(200);
    cursor cursor_teminat is
   	select teminat_kodu,
		   teminat_alt_kodu,
		   musteri_no,
		   sozlesme_no,
		   ek_sozlesme_no,
		   ref_cek_no,
		   KREDI_TEMINAT_TANIM_SIRA_NO,
		   borclu_teminat_hesap_no,
		   bolum_kodu,senet_no,
		   referans
	from cbs_teminat_islem
	where tx_no = pn_islem_no and
		  teminat_durumu = 'ACIK' and
		  kullanilan_tutar > 0
		  AND teminat_kodu not in ('12')
    Group By  teminat_kodu,
		   teminat_alt_kodu,
		   musteri_no,
		   sozlesme_no,
		   ek_sozlesme_no,
		   ref_cek_no,
		   KREDI_TEMINAT_TANIM_SIRA_NO,
		   borclu_teminat_hesap_no,
		   bolum_kodu,senet_no,
		   referans
	  Having Count(*) > 1;

   	   doublekayitmevcut      exception;

  Begin

   for cur_teminat in cursor_teminat
     loop
	 	ls_kod := cur_teminat.teminat_kodu ;
	  case

	  	when  cur_teminat.teminat_kodu ='01' then --takas cek
			  ls_referans := to_char(cur_teminat.ref_cek_no);
	  	when  cur_teminat.teminat_kodu= '11' then --senet
			  ls_referans := cur_teminat.bolum_kodu ||'/'|| to_char(cur_teminat.senet_no);
	   		 /* ihracat & akreditif &al?nan garanti*/
		 when cur_teminat.teminat_kodu in( '09', '14') then
			  ls_referans := ls_referans;
		 		 /* al?nan garanti*/
		 when cur_teminat.teminat_kodu = '13' then
			  ls_referans := ls_referans;
	   		 /* nakdi hesap*/
		  when cur_teminat.teminat_kodu ='12' then
			   ls_referans := to_char(cur_teminat.borclu_teminat_hesap_no);
		  when cur_teminat.teminat_kodu ='15' then
			   ls_referans := to_char(cur_teminat.sozlesme_no)|| '/'|| to_char(cur_teminat.ek_sozlesme_no);
		 else /* diger gayri nakdiler */
			   ls_referans := to_char(cur_teminat.musteri_no) || '/' ||to_char(cur_teminat.KREDI_TEMINAT_tanim_SIRA_NO);
		 end case;
		 raise doublekayitmevcut;

   End loop;

	 EXCEPTION
	 when    doublekayitmevcut then
	  	    raise_application_error (-20100, pkg_hata.getucpointer || '807' ||  pkg_hata.getdelimiter||ls_kod ||pkg_hata.getdelimiter ||ls_referans||  pkg_hata.getdelimiter || pkg_hata.getucpointer    );
      when others then null;
  End;


 /***************************************************************************************************************/
/*    Procedure sp_teminattutarguncelle																	                 */
/***************************************************************************************************************/
 Procedure sp_teminattutarguncelle(pn_tx_no number)
 is
  ls_teminat_kodu cbs_teminat_islem.teminat_kodu%type;
  ln_teminat_no	  cbs_teminat_islem.teminat_no%type;
  ln_teminat_tutari  number := 0;
  LN_yeni_teminat_tutari number := 0;
  cursor  cur_teminat is
	 select teminat_kodu,
	 		teminat_no,
	 		teminat_tutari
	 from cbs_teminat_islem
	 where tx_no = pn_tx_no and
	 	   teminat_durumu = 'ACIK'
	     for update of teminat_tutari ;

 Begin

 if cur_teminat%isopen then
	   close cur_teminat;
  end if;

   Open cur_teminat ;
   	 Loop
      fetch cur_teminat into  ls_teminat_kodu,ln_teminat_no,ln_teminat_tutari;
         exit when cur_Teminat%notfound;

		  ln_yeni_teminat_tutari :=	nvl( pkg_teminat.sf_teminat_gunceltutari_al(pn_tx_no,ln_teminat_no,ls_teminat_kodu),0) ;

		  UPDATE cbs_teminat_islem
		  set teminat_tutari = ln_yeni_Teminat_tutari
		  where CURRENT OF Cur_teminat;

	end loop;

  if cur_teminat%isopen then
	   close cur_teminat;
  end if;

  Exception
    When no_data_found then  null;
	 when others then
	 	  raise_application_error (-20100, pkg_hata.getucpointer || '809' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );


 End;

 /***************************************************************************************************************/
/*     procedure sp_iptalonaysonrasi_teminat_at                                     */
/***************************************************************************************************************/
  procedure sp_iptalonaysonrasi_teminat_at(pn_islem_no number,ps_islem_tipi varchar2 default 'ACILIS')
  is
    ls_durum cbs_teminat.teminat_durumu%type;
	ls_referans varchar2(2000);
    ln_teminat_tutari number :=0;
    ln_bakiye number :=0;
	ln_kullanilan_tutar number := 0;
     cursor cursor_teminat is
	   select *
	   from cbs_teminat_onayonce_islem
	   where tx_no =pn_islem_no and teminat_durumu = 'ACIK' ;
  Begin


  	   delete from cbs_teminat
	   where teminat_no in ( select teminat_no
								  from cbs_teminat_islem
								  where tx_no = pn_islem_no);


   For cur_teminat in cursor_teminat
    loop
		ln_teminat_tutari := 0;
		ls_durum  := '';
		ln_bakiye := 0;
		ln_kullanilan_tutar := 0;

	    sp_teminat_hepsi_referans_al( cur_teminat.tx_no,
	  							    cur_teminat.teminat_no,
		 						    cur_teminat.teminat_kodu,
								    ls_durum ,
									ls_referans,
  									ln_teminat_tutari,
									ln_bakiye );
	if  pkg_teminat.sf_teminat_durumu_uygunmu( cur_teminat.teminat_kodu,
										   cur_teminat.referans,
										   cur_teminat.ref_cek_no,
										   cur_teminat.bolum_kodu,
										   cur_teminat.senet_no,
										   cur_teminat.musteri_no,
										   cur_teminat.kredi_teminat_tanim_sira_no,
										   cur_teminat.borclu_teminat_hesap_no ,
										   cur_teminat.sozlesme_no,
										   cur_teminat.ek_sozlesme_no)= 'E' then
   		   ls_durum := 'ACIK';
		else
		   ls_durum := 'KAPALI';
	 end if;

	 if cur_teminat.bloke_hesap_secimi = 'BLOKE' and  cur_teminat.teminat_kodu = '12' then
	 	 ln_kullanilan_tutar :=nvl(cur_teminat.kullanilan_tutar,0) ;
	 else
	     if nvl(ln_bakiye ,0)  >=  nvl(cur_teminat.kullanilan_tutar,0)
		   then
		  	    ln_kullanilan_tutar :=	nvl(cur_teminat.kullanilan_tutar,0) ;
		   elsif nvl(ln_bakiye ,0) < 0  then
		   	    ln_kullanilan_tutar := 0 ;
		  else
		      ln_kullanilan_tutar := nvl(ln_bakiye ,0);
		  end if;
     end if;

	  UPDATE cbs_teminat_islem
	  set (TX_NO,TEMINAT_NO, TEMINAT_TURU,
	      TEMINAT_KODU, MUSTERI_NO,
		  TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI,
		  KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU,
		  CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU,
		  SENET_NO, REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA,
		  BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF, HESAP_URUN_TUR_KOD,
		  HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI, teklif_musteri_no,
		  KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO,
		  BORCLU_TEMINAT_HESAP_DOVIZ, NAKDI_TEMINAT_HESAP_NO,
		  NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS, KREDI_TEKLIF_SATIR_NO,
		  TEMINAT_ALIS_TARIHI ,
		 SOZLESME_NO,EK_SOZLESME_NO ,SOZLESME_DOVIZ_KODU)
	  =(
	    select
		  pn_islem_no,cur_teminat.TEMINAT_NO, cur_teminat.TEMINAT_TURU,
	      cur_teminat.TEMINAT_KODU, cur_teminat.MUSTERI_NO,
		  cur_teminat.TEMINAT_HESAP_NO, cur_teminat.TEMINAT_HESAP_DOVIZ,
		  ln_teminat_tutari,ln_kullanilan_tutar,
		  cur_teminat.TEMINAT_DOVIZ_KODU, ls_durum,
		  cur_teminat.CEK_BANKA_KODU, cur_teminat.CEK_SUBE_KODU, cur_teminat.CEK_NO,
		  cur_teminat.BOLUM_KODU,cur_teminat.SENET_NO, cur_teminat.REF_CEK_NO,
		  cur_teminat.TEMINAT_ALT_KODU, cur_teminat.ACIKLAMA,
		  cur_teminat.BLOKE_HESAP_SECIMI, cur_teminat.HESAP_URUN_SINIF,
		  cur_teminat.HESAP_URUN_TUR_KOD, cur_teminat.HESAP_MODUL_TUR_KOD,
		  cur_teminat.NAKDI_GAYRI_SECIMI, cur_teminat.teklif_musteri_no,
		  cur_teminat.KREDI_TEMINAT_TANIM_SIRA_NO, cur_teminat.BORCLU_TEMINAT_HESAP_NO,
		  cur_teminat.BORCLU_TEMINAT_HESAP_DOVIZ, cur_teminat.NAKDI_TEMINAT_HESAP_NO,
		  cur_teminat.NAKDI_TEMINAT_HESAP_DOVIZ_KODU, cur_teminat.REFERANS, cur_teminat.KREDI_TEKLIF_SATIR_NO,
		  cur_teminat.TEMINAT_ALIS_TARIHI ,cur_teminat.SOZLESME_NO,
		  cur_teminat.EK_SOZLESME_NO ,cur_teminat.SOZLESME_DOVIZ_KODU from dual)
		 where tx_no = pn_islem_no and
		 	   teminat_no =  cur_teminat.TEMINAT_NO;

  end loop;

	 Begin
	   update cbs_teminat_islem
	   set teminat_durumu = 'KAPALI'
	   where tx_no = pn_islem_no and
	   		 teminat_no not in ( select teminat_no
						    from cbs_teminat_onayonce_islem
						    where tx_no = pn_islem_no);

	 Exception when others then null;
     End;

/*  	   delete from cbs_teminat
	   where teminat_no in ( select teminat_no
								  from cbs_teminat_islem
								  where tx_no = pn_islem_no);
*/
   	  insert into CBS_TEMINAT
	     ( TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO,
		  TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI,
		  KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU, TEMINAT_DURUMU,
		  CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU,
		  SENET_NO, REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA,
		  BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF, HESAP_URUN_TUR_KOD,
		  HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI, teklif_musteri_no,
		  KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO,
		  BORCLU_TEMINAT_HESAP_DOVIZ, NAKDI_TEMINAT_HESAP_NO,
		  NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS, KREDI_TEKLIF_SATIR_NO,
		  TEMINAT_ALIS_TARIHI ,
		 SOZLESME_NO,EK_SOZLESME_NO ,SOZLESME_DOVIZ_KODU)
	  select
		  TEMINAT_NO, TEMINAT_TURU, TEMINAT_KODU, MUSTERI_NO,
		  TEMINAT_HESAP_NO, TEMINAT_HESAP_DOVIZ, TEMINAT_TUTARI,
		  KULLANILAN_TUTAR, TEMINAT_DOVIZ_KODU,
		  teminat_durumu,
		  CEK_BANKA_KODU, CEK_SUBE_KODU, CEK_NO, BOLUM_KODU,
		  SENET_NO, REF_CEK_NO, TEMINAT_ALT_KODU, ACIKLAMA,
		  BLOKE_HESAP_SECIMI, HESAP_URUN_SINIF, HESAP_URUN_TUR_KOD,
		  HESAP_MODUL_TUR_KOD, NAKDI_GAYRI_SECIMI, teklif_musteri_no,
		  KREDI_TEMINAT_TANIM_SIRA_NO, BORCLU_TEMINAT_HESAP_NO,
		  BORCLU_TEMINAT_HESAP_DOVIZ, NAKDI_TEMINAT_HESAP_NO,
		  NAKDI_TEMINAT_HESAP_DOVIZ_KODU, REFERANS, KREDI_TEKLIF_SATIR_NO,
		  TEMINAT_ALIS_TARIHI ,
		 SOZLESME_NO,EK_SOZLESME_NO ,SOZLESME_DOVIZ_KODU
	  from  CBS_TEMINAT_ISLEM
	  where tx_no = pn_islem_no ;

  End;


/***************************************************************************************************************/
/*   procedure sp_teminat_islem_onay_sonrasi                                               */
/***************************************************************************************************************/
 Procedure sp_teminat_onay_sonrasi(pn_islem_no number ,pn_hesap_no cbs_hesap_kredi.hesap_no%type  ,ps_doviz_kodu cbs_hesap_kredi.doviz_kodu%type,ps_islem_tipi varchar2 default 'ACILIS' )
 is
  ls_teminatvar varchar2(1) :='H';
  ls_durum		cbs_hesap_kredi.durum_kodu%type := 'A';
 Begin
 ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

  if ls_teminatvar   = 'E' then
 /* onay oncesi eski durumlari onay oncesi tablolara aktar?l?r*/
 	 sp_Teminat_iptalsonrasi(pn_islem_no); -- 060804 islemden sonra bir islem yapildiysa izin verilmez.*/
 	 sp_teminat_uygundegilse_kapat(pn_islem_no);
	 pkg_teminat.sp_onayoncesi_teminat_at(pn_islem_no );
  	 pkg_teminat.sp_teminattutarguncelle(pn_islem_no);

  	 update cbs_teminat_islem
	 set 	teminat_alis_tarihi = pkg_muhasebe.banka_tarihi_bul
	 where tx_no= pn_islem_no  and
	 	   teminat_alis_tarihi is null;

    if pn_hesap_no is not null then
		select durum_kodu
		into ls_durum
		from cbs_hesap_kredi
		where hesap_no = pn_hesap_no ;
	end if;

/*020604*/
	if ls_durum = 'A' and ps_islem_tipi != 'KAPAMA' then
  /* nakdi hesap i?in konulan ge?ici bloke kald?r?l?r */
	  pkg_teminat.sp_teminat_onaya_uygunmu(pn_islem_no);
	  pkg_teminat.sp_teminat_gayrinakdikayitkont(pn_islem_no);
    end if;
	 /* teminat islemin kredi hesap alan? guncellenir.*/
	  pkg_teminat.sp_teminatislem_hesapno_guncel(pn_islem_no,pn_hesap_no,ps_doviz_kodu);
      pkg_teminat.sp_teminat_blokekoy_hesap_ac(pn_islem_no);

 end if;
  Exception
    when no_data_found then null;
 End;

 /***************************************************************************************************************/
/*   procedure sp_teminat_fiskessonrasi                                              */
/***************************************************************************************************************/

  procedure sp_teminat_fiskessonrasi(pn_islem_no number,pn_fis_no in  number,ps_islem_tipi varchar2 default 'ACILIS')
  is
  ls_teminatvar varchar2(1) :='H';

 Begin

   ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

   if ls_teminatvar   = 'E' then
      pkg_teminat.sp_teminat_nakdihesap_muhasebe(pn_islem_no ,pn_fis_no,ps_islem_tipi );

	  if ps_islem_tipi = 'KAPAMA' then
		  sp_teminat_kapama_onaysonrasi(pn_islem_no);

		  update cbs_teminat_islem
		  set teminat_durumu = 'KAPALI'
		  where  tx_no = pn_islem_no;

	end if;
	  --pkg_teminat.sp_teminat_senet_muhasebe(pn_islem_no ,pn_fis_no );
 	  --pkg_teminat.sp_teminat_ceksenetteminat_yap(pn_islem_no);

 	  pkg_teminat.Sp_Teminat_Ana_Tabloya_Aktar(pn_islem_no);
	 end if;
 End;

/***************************************************************************************************************/
/*   procedure sp_teminat_islem_kontrolsonra                                              */
/***************************************************************************************************************/
 Procedure  sp_teminat_kontrolsonra(pn_islem_no number ,
		  	pn_kredi_teklif_satir_numara      number default 0,
		    pn_kredi_hesap_tutar 			  number default 0,
		    ps_kredi_hesap_doviz_kodu 		  varchar2  default null ,
			ps_kredi_hesap_endeksdoviz 		  varchar2  default null  )
  is
   ls_teminat_turu            cbs_teminat_kodlari.teminat_turu%type;
   ls_teminat_kodu       	  cbs_teminat_kodlari.teminat_kodu%type;
   ls_teminat_alt_kodu    	  cbs_teminat_alt_kodlari.teminat_alt_kodu%type;
   ln_sonuc 			      number;
   ln_alinan_tutar 	      	  number ;
   ln_alinmasi_gereken_tutar  number;
   ls_nakdi_gayri_secimi  	  cbs_teminat.nakdi_gayri_secimi%type;
   ln_kredi_teklif_no		  cbs_kredi_teklif.teklif_no%type;
   ls_teminatvar varchar2(1) :='H';
   ls_karsilandimi	varchar2(1) := null;
   ls_mesaj			varchar2(2000) := null;
  BEGIN

    /* kredi teklif kosullarinin karsilanip karsilanmadigi kontrol edilir */
    ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

	ls_teminat_kodu :=null;
	ls_teminat_alt_kodu := null;


     if ls_teminatvar   = 'E' then
  	 sp_Teminat_iptalsonrasi(pn_islem_no); -- 060804 islemden sonra bir islem yapildiysa izin verilmez.*/
    /* ayn? kay?t girisi yap?ld?ysa kontrol edilir.*/
		pkg_teminat.sp_ciftkayitkontrolu(pn_islem_no);

   /*030404 sozlesme doviz kodu sozlesme tablosundan alinir */
	   Begin
		  update cbs_teminat_islem a
		  set sozlesme_doviz_kodu  = (select doviz_kodu
		  	  					   	  from cbs_sozlesme
									  	   where musteri_no = a.musteri_no and
										   		 sozlesme_no = a.sozlesme_no and
												 ek_sozlesme_no = a.ek_sozlesme_no )
		  where a.tx_no = pn_islem_no and
		  		a.teminat_kodu = 15 and
		  		sozlesme_doviz_kodu is  null;
	   Exception when others then null;
	   End ;

	   sp_teminat_uygundegilse_kapat(pn_islem_no);
	end if;
/* on yuzden cagrilacak sekilde degisiklik yap?ld?. 170204*/
/*	 if nvl(pn_kredi_teklif_satir_numara,0)<> 0 then
			 pkg_teminat.teklif_kosullari_karsilandimi (
			      			 pn_islem_no,
	   						 pn_kredi_teklif_satir_numara,
				 			 pn_kredi_hesap_tutar,
	             			 ps_kredi_hesap_doviz_kodu,
							 ls_karsilandimi,
							 ls_mesaj,
							 ps_kredi_hesap_endeksdoviz) ;
	end if;
	*/
	ls_karsilandimi := pkg_teminat.sf_teminat_karsilandimi(pn_islem_no,pn_kredi_teklif_satir_numara);
	--sevalb 290507 dinamik onayin kapatilmasi istendi.
   /* if ls_karsilandimi = 'H' then
		  pkg_tx.Dinamik_Onay_Belirle( pn_islem_no ,'E',null,null,'E',null);
	end if;
	*/

 Exception
 when no_data_found then null;
  When others then
  	   raise_application_error (-20100, pkg_hata.getucpointer || '568' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

  End;

/***************************************************************************************************************/
/*   procedure sp_teminat_islem_durumguncelle                                           */
/***************************************************************************************************************/
 procedure sp_teminat_islem_durumguncelle(pn_islem_no number ,ps_durum cbs_teminat_islem.teminat_durumu%type default 'ACIK')
   is
   ln_mevcut number := 0;

    Begin

	     select count(*) into ln_mevcut
		 from cbs_teminat_islem
		 where tx_no = pn_islem_no ;

		  if nvl(ln_mevcut,0) <> 0 then
			 	 update cbs_teminat_islem
				 set teminat_durumu = ps_durum
				 where tx_no = pn_islem_no;
		  end if;

   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '566' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	End;

/***************************************************************************************************************/
/*   procedure sp_teminat_durumguncelle                                           */
/***************************************************************************************************************/
 procedure sp_teminat_durumguncelle(pn_islem_no number ,ps_durum cbs_teminat_islem.teminat_durumu%type default 'ACIK')
   is
   ln_mevcut number := 0;

    Begin

	     select count(*) into ln_mevcut
		 from cbs_teminat
		 where teminat_no in (select teminat_no from cbs_teminat_islem
							  where tx_no = pn_islem_no) ;

		  if nvl(ln_mevcut,0) <> 0 then
			 	 update cbs_teminat
				 set teminat_durumu = ps_durum
				 where teminat_no in (select teminat_no from cbs_teminat_islem
							          where tx_no = pn_islem_no) ;

		  end if;

   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '566' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );
   	End;



 /*****************************************************************************************************************/
 /*      Function Sf_BitmemisteminatIslemVarMi             			   		   */
 /*****************************************************************************************************************/
 Function Sf_BitmemisteminatIslemVarMi( pn_musteri_no cbs_musteri.musteri_no%type,
 		  								pn_islem_no cbs_islem.numara%type,
										pn_hesap_no  cbs_hesap_kredi.hesap_no%type) return number
 is

    ln_tx_no   cbs_islem.numara%type  := 0;
	onayda_bekleyen_islem_var 		 exception;
cursor cur_islem is
	   select  max(tx_no) tx_no
	   from    CBS_TEMINAT_TOPLU_ISLEM a , cbs_islem b
	   where  a.musteri_no = pn_musteri_no and
	   		  a.tx_no = b.numara and
			  a.tx_no <> pn_islem_no and
			  nvl(hesap_no,0) = nvl(pn_hesap_No,0) and
			  pkg_tx.ISLEM_BITMIS_MI(b.numara)= 0;
  Begin
	  for c_islem in cur_islem loop
		  	  ln_tx_no :=   c_islem.tx_no ;
	  end loop;

	   if  nvl(ln_tx_no,0) <> 0 then
	   	   raise 	onayda_bekleyen_islem_var;
	   end if;
	   return ln_tx_no ;

    Exception
	 when no_data_found then null;
	  When Others Then
  	   	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '456' ||pkg_hata.getdelimiter|| ln_tx_no  || pkg_hata.getdelimiter ||  pkg_hata.getUCPOINTER);
	End;



/***************************************************************************************************************/
/*   procedure sp_teklifno_teminatguncelle(                                          */
/***************************************************************************************************************/
/* Procedure  sp_teklifno_teminatguncelle(  pn_eski_teklif_no cbs_teminat.teminat_hesap_no%type,
 										  pn_yeni_teklif_no cbs_teminat.kredi_teklif_no%type)
 is
 begin

		 update cbs_teminat
		 set  kredi_teklif_no   = pn_yeni_teklif_no
		 where  kredi_teklif_no = pn_eski_teklif_no;

         update cbs_teminat_islem
		  set  kredi_teklif_no   = pn_yeni_teklif_no
		 where  kredi_teklif_no = pn_eski_teklif_no;

Exception
  when no_data_found then null;
  WHEN OTHERS
      THEN
         raise_application_error (-20100, pkg_hata.getucpointer || '570' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM|| pkg_hata.getdelimiter|| pkg_hata.getucpointer    );

 end;

 */
/***************************************************************************************************************/
/*  Function sf_ihracatta_teminatmi                                         */
/***************************************************************************************************************/
 Function sf_ihracatta_teminatmi(ps_ref varchar2) return varchar2 is
  ln_temp number;
 begin
 	select count(*)
	  into ln_temp
	  from cbs_teminat a
	 where a.REFERANS = ps_ref
	   and a.teminat_durumu = 'ACIK'
	   and a.kullanilan_tutar > 0;
	 if nvl(ln_temp,0) > 0 then
        return 'E';
	 else
	   return 'H';
	 end if;
 Exception
  when no_data_found then
    return 'H';
  WHEN OTHERS THEN
    raise_application_error (-20100, pkg_hata.getucpointer || '612' || pkg_hata.getdelimiter|| TO_CHAR (SQLCODE)|| SQLERRM || pkg_hata.getucpointer    );
 end;

 /***************************************************************************************************************/
/*    PROCEDURE sp_teminat_ceksenetteminat_yap                                                       */
/*  iptal sonras? tahsile donusturulur
/***************************************************************************************************************/

  Procedure sp_teminat_ceksenettahsil_yap(pn_islem_no number)
   is
   cursor cursor_teminat_cek is
	  select a.REF_CEK_NO
	  from  cbs_teminat_islem_tahsil_log  a,cbs_takas_cek b
	  where tx_no = pn_islem_no and
			a.teminat_kodu = '01' and
			a.ref_cek_no =b.ref_cek_no
			and b.tahsil_teminat = 'TEMINAT';

   cursor cursor_teminat_senet is
	  select a.bolum_kodu,
	  		 a.senet_no
	  from  cbs_teminat_islem_tahsil_log a ,cbs_senet b
	  where a.tx_no = pn_islem_no and
			a.teminat_kodu = '11' and
			a.bolum_kodu = b.bolum_kodu and
			a.senet_no =b.senet_no and
			b.urun_tur_kod = 'TEMINAT';

  Begin

     For   cur_teminat_cek in   cursor_teminat_cek
	 Loop
	 	   pkg_takas.sp_takascek_tahstemin_guncelle(cur_teminat_cek.ref_cek_no ,'TAHSIL');
	 End loop;

	 For   cur_teminat_senet in   cursor_teminat_senet
	 Loop
	 	   pkg_senet.sp_senet_tahsiltemin_guncelle(cur_teminat_senet.bolum_kodu,
		   										   cur_teminat_senet.senet_no,
												   'TAHSIL');
	 End loop;
	 Exception   when no_data_found then null;
  End;

/***************************************************************************************************************/
/*  procedure sp_teminat_nakdihesap_muhasebe                                        */
/***************************************************************************************************************/
  procedure sp_teminat_nakdihesap_muhasebe(pn_islem_no number,pn_fis_no in number,ps_islem_tipi varchar2 default 'ACILIS')
   is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
	ln_fis_no				   cbs_fis.numara%type  := 0;
	ls_islem_kod               cbs_islem.islem_kod%type :='1310';
	ls_aciklama                varchar2(2000);
	ls_fis_mesaj			   varchar2(2000);
	ln_sonuc 				   number;
	ls_fis_aciklama                varchar2(2000);
	ls_banka_aciklama              varchar2(2000);
	ls_musteri_aciklama            varchar2(2000);

	ln_1310_banka_aciklama          number;
	ln_1310_musteri_aciklama        number;
	ln_1310_referans        		number;
	ln_1310_fis_aciklama        	number;
	ln_1310_istatistik_kod          number;
	ln_1310_islem_sube        		number;
	ln_1310_bdak_kur          		number;
	ln_1310_borclu_teminat_hesap    number;
	ln_1310_alacak_teminat_hesap    number;
	ln_1310_teminat_doviz        	number;
	ln_1310_kullan_teminattutar     number;
	ln_1310_kullan_tl_teminattutar  number;
	ln_1310_borclu_teminhesapsube   number;
	ln_1310_nakdi_teminat_ise		number;
	ln_1310_teminat_ise 			number;
	ln_1310_fark_negatif        	number;
	ln_1310_fark_pozitif        	number;
	ln_1310_alacakteminathesapsube  number;
	ln_1310_acilis					number;
	ln_1310_kapanis					number;
	ps_fis_mesaj					varchar2(2000);
	ls_iptal_edilebilir				varchar2(1) := 'E';
	cursor cursor_islem is
		   	select
				   pkg_hesap.HESAPTANSUBEAL(a.BORCLU_TEMINAT_HESAP_NO) borclu_teminat_hesap_sube,
				   a.BORCLU_TEMINAT_HESAP_NO,
				   a.BORCLU_TEMINAT_HESAP_DOVIZ,
				   a.NAKDI_TEMINAT_HESAP_NO,
				   decode(nvl(a.Kullanilan_tutar,0),0,-1 * b.kullanilan_tutar, nvl(a.kullanilan_tutar,0) - nvl(b.kullanilan_tutar,0)) kullanilan_tutar,
--				   a.kullanilan_tutar,
				   a.aciklama,
				   pkg_hesap.HESAPTANSUBEAL(a.NAKDI_TEMINAT_HESAP_NO)  alacak_teminat_hesap_sube,
				   a.teminat_hesap_no
			from  cbs_teminat_islem a,CBS_TEMINAT_ONAYONCE_ISLEM b
			where a.tx_no=pn_islem_no and
				  a.tx_no =b.tx_no and
				  a.teminat_no = b.teminat_no and
				  a.teminat_durumu = 'ACIK' and
				  a.bloke_hesap_secimi = 'HESAP' and
				  a.kullanilan_tutar <> b.kullanilan_tutar
				  and  ( ps_islem_tipi != 'KAPAMA' or ps_islem_tipi is null)
			union
			select
			   pkg_hesap.HESAPTANSUBEAL(a.BORCLU_TEMINAT_HESAP_NO) borclu_teminat_hesap_sube,
				   a.BORCLU_TEMINAT_HESAP_NO,
				   a.BORCLU_TEMINAT_HESAP_DOVIZ,
				   a.NAKDI_TEMINAT_HESAP_NO,
				   nvl(a.Kullanilan_tutar,0) kullanilan_tutar,
				   a.aciklama,
				   pkg_hesap.HESAPTANSUBEAL(a.NAKDI_TEMINAT_HESAP_NO)  alacak_teminat_hesap_sube,
				   a.teminat_hesap_no
			from  cbs_teminat_islem a
			where a.tx_no=pn_islem_no and
				  a.teminat_durumu = 'ACIK' and
				  a.bloke_hesap_secimi = 'HESAP'
				  and a.teminat_no not in (select teminat_no
						                 from   CBS_TEMINAT_ONAYONCE_ISLEM
								   		 where tx_no  =pn_islem_no)
				  and  ( ps_islem_tipi != 'KAPAMA' or ps_islem_tipi is null)
			union
			/* kapama */
		   	select
				   pkg_hesap.HESAPTANSUBEAL(a.BORCLU_TEMINAT_HESAP_NO) borclu_teminat_hesap_sube,
				   a.BORCLU_TEMINAT_HESAP_NO,
				   a.BORCLU_TEMINAT_HESAP_DOVIZ,
				   a.NAKDI_TEMINAT_HESAP_NO,
				   nvl(a.Kullanilan_tutar,0) kullanilan_tutar,
				   a.aciklama,
				   pkg_hesap.HESAPTANSUBEAL(a.NAKDI_TEMINAT_HESAP_NO)  alacak_teminat_hesap_sube,
				   a.teminat_hesap_no
			from  cbs_teminat_islem a
			where a.tx_no=pn_islem_no and
				  a.teminat_durumu = 'ACIK' and
				  a.bloke_hesap_secimi = 'HESAP'
				  and   ps_islem_tipi = 'KAPAMA';



  Begin
/*ayr? fis kesilmesi istendiginden pn_fis no kullanilmamaktadir */
	/*parametre index atamas? */
		ln_1310_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1310_NAKDI_TEMINAT_ACIKLAMA');
		ln_1310_referans :=pkg_muhasebe.parametre_index_bul('1310_REFERANS');
		ln_1310_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1310_FIS_ACIKLAMA');
		ln_1310_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1310_ISTATISTIK_KOD');
		ln_1310_islem_sube :=pkg_muhasebe.parametre_index_bul('1310_ISLEM_SUBE');
		ln_1310_bdak_kur :=pkg_muhasebe.parametre_index_bul('1310_BDAK_KUR');
		ln_1310_borclu_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1310_BORCLU_TEMINAT_HESAP');
		ln_1310_alacak_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1310_ALACAK_TEMINAT_HESAP');
		ln_1310_teminat_doviz :=pkg_muhasebe.parametre_index_bul('1310_TEMINAT_DOVIZ');
		ln_1310_kullan_teminattutar :=pkg_muhasebe.parametre_index_bul('1310_KULLANILAN_TEMINAT_TUTARI');
		ln_1310_kullan_tl_teminattutar :=pkg_muhasebe.parametre_index_bul('1310_KULLANILAN_TL_TEMINAT_TUT');
		ln_1310_borclu_teminhesapsube :=pkg_muhasebe.parametre_index_bul('1310_BORCLU_TEMINAT_HESAP_SUBE');
		ln_1310_nakdi_teminat_ise :=pkg_muhasebe.parametre_index_bul('1310_NAKDI_TEMINAT_ISE');
		ln_1310_teminat_ise :=pkg_muhasebe.parametre_index_bul('1310_TEMINAT_ISE');
		ln_1310_fark_pozitif :=pkg_muhasebe.parametre_index_bul('1310_FARK_POZITIF');
		ln_1310_fark_negatif :=pkg_muhasebe.parametre_index_bul('1310_FARK_NEGATIF');
		ln_1310_alacakteminathesapsube :=pkg_muhasebe.parametre_index_bul('1310_ALACAK_TEMINAT_HESAP_SUBE');
		ln_1310_acilis :=pkg_muhasebe.parametre_index_bul('1310_ACILIS');
		ln_1310_kapanis :=pkg_muhasebe.parametre_index_bul('1310_KAPANIS');

      pkg_parametre.deger('1310_FIS_ACIKLAMA',ls_fis_aciklama);
      pkg_parametre.deger('1310_BANKA_ACIKLAMA',ls_banka_aciklama);
	  pkg_parametre.deger('1310_TEMINAT_ACIKLAMA',ls_aciklama);
      pkg_parametre.deger('1310_NAKDI_TEMINAT_ACIKLAMA',ls_musteri_aciklama);

      boolean_list(ln_1310_acilis):=false;
	  boolean_list(ln_1310_kapanis):=false;
	  boolean_list(ln_1310_nakdi_teminat_ise):=true;
   	  boolean_list(ln_1310_teminat_ise):=true;

	  if ps_islem_tipi = 'KAPAMA'  then
 		 boolean_list(ln_1310_kapanis):=true;
	  else
		  boolean_list(ln_1310_acilis):=true;
	  end if;


/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    if ps_islem_tipi = 'KAPAMA'  then
	   ls_iptal_edilebilir := 'H';
	else
	   ls_iptal_edilebilir := 'E';
	end if;

/* islem bilgisi detaylari alinir */
 for cur_islem in cursor_islem
   loop
		   boolean_list(ln_1310_fark_negatif):=false;
		   boolean_list(ln_1310_fark_pozitif):=false;

  		  if  nvl(cur_islem.kullanilan_tutar,0)  < 0 then
		     boolean_list(ln_1310_fark_negatif) := true ;
		   else
		   	  boolean_list(ln_1310_fark_pozitif) := true ;
		  end if;


		   varchar_list(ln_1310_fis_aciklama) 	 :=nvl(nvl(cur_islem.teminat_hesap_no ||' '||ls_fis_aciklama,cur_islem.aciklama),ls_aciklama);
		   varchar_list(ln_1310_islem_sube)  	 := pkg_tx.amir_bolumkodu_al( pn_islem_no);--pkg_baglam.bolum_kodu;
		   varchar_list(ln_1310_banka_aciklama)  := nvl(nvl(ls_musteri_aciklama,' ') || nvl( to_char(cur_islem.borclu_teminat_hesap_no), ' '),'  ');
		   varchar_list(ln_1310_referans) 	     := nvl(to_char(cur_islem.borclu_teminat_hesap_no),' ');
		   varchar_list(ln_1310_istatistik_kod)  := null;


		   varchar_list(ln_1310_borclu_teminat_hesap) := to_char(cur_islem.borclu_teminat_hesap_no);
		   varchar_list(ln_1310_borclu_teminhesapsube):= cur_islem.borclu_teminat_hesap_sube;
		   varchar_list(ln_1310_teminat_doviz)		  :=cur_islem.borclu_teminat_hesap_doviz;
		   varchar_list(ln_1310_alacak_teminat_hesap) := to_char(cur_islem.NAKDI_TEMINAT_HESAP_NO);
		   varchar_list(ln_1310_alacakteminathesapsube):= to_char(cur_islem.alacak_teminat_hesap_sube);

		   number_list(ln_1310_kullan_teminattutar) := abs(cur_islem.kullanilan_tutar) ;

		   number_list(ln_1310_kullan_tl_teminattutar) := pkg_kur.doviz_doviz_karsilik(cur_islem.borclu_teminat_hesap_doviz,pkg_genel.LC_AL,null,number_list(ln_1310_kullan_teminattutar),1,null,null,'O','A');
	  	   number_list(ln_1310_bdak_kur)	   		   :=  pkg_kur.doviz_doviz_karsilik(cur_islem.borclu_teminat_hesap_doviz,pkg_genel.LC_AL,null,1,1,null,null,'O','A');

	      ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
								null,
								pn_islem_no,
								varchar_list ,
								number_list  ,
								date_list    ,
								boolean_list ,
								null,
								false,
								ln_fis_no,
								null,--ls_aciklama,
								ls_iptal_edilebilir
								);
	 end loop;

	 if nvl(ln_fis_no,0) <> 0 then
	 	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
	 end if;
  Exception
   When no_data_found then null;
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '532' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

/***************************************************************************************************************/
/*  Procedure sp_teminat_senet_muhasebe																           */
/***************************************************************************************************************/
 Procedure sp_teminat_senet_muhasebe(pn_islem_no number,pn_fis_no in  number)
   is
    varchar_list	               pkg_muhasebe.varchar_array;
    number_list				   	   pkg_muhasebe.number_array;
    date_list				   	   pkg_muhasebe.date_array;
    boolean_list			       pkg_muhasebe.boolean_array;
	ln_fis_no				       cbs_fis.numara%type  := 0;
	ls_fis_aciklama                varchar2(2000);
	ls_banka_aciklama              varchar2(2000);
	ls_musteri_aciklama            varchar2(2000);
	ls_aciklama					   varchar2(2000);
	ls_fis_mesaj			   	   varchar2(2000);
	ln_sonuc 				   	   number;
	ln_1310_banka_aciklama         number;
	ln_1310_musteri_aciklama       number;
	ln_1310_referans        	   number;
	ln_1310_fis_aciklama           number;
	ln_1310_istatistik_kod         number;
	ln_1310_senet_sube_kodu        number;
	ln_1310_senet_tl_tutar         number;
	ln_1310_senet_fc_tutar         number;
	ln_1310_senet_doviz_kodu       number;
	ln_1310_senet_cuzdan_tp        number;
	ln_1310_senet_cuzdan_yp        number;
	ln_1310_senet_cuzdan_muh_tp    number;
	ln_1310_senet_cuzdan_muh_yp    number;
	ln_1310_senet_durum_acik       number;
	ln_1310_senet_durum_protesto   number;
	ln_1310_senet_durum_kabul      number;
	ln_1310_kur					   number;
	ln_1310_teminat_ise			   number;
	ls_islem_kod                   cbs_islem.islem_kod%type :='1310';
  	ls_bolum_kodu       		   cbs_senet.bolum_kodu%type;
	ls_senet_no         		   varchar2(2000);
	ls_durum_kodu   			   cbs_senet.durum_kodu%type;
	ls_urun_sinif_kod     		   cbs_senet.urun_sinif_kod%type;
	durum_uygun_degil			   exception;
	urun_sinif_uygun_degil		   exception;
	cursor cursor_islem is
     select
	 	    b.BOLUM_KODU,
			b.senet_no,
			b.urun_sinif_kod,
	 	    b.durum_kodu,
	 	    b.DOVIZ_KODU,
	 	    b.SENET_TUTARI
	  from  cbs_teminat_islem a ,
	  		cbs_senet b
	  where a.tx_no = pn_islem_no and
			a.teminat_kodu = '11'
			and A.teminat_durumu = 'ACIK'
			and a.bolum_kodu = b.bolum_kodu
			and a.senet_no =b.senet_no
			and b.urun_tur_kod = 'TAHSIL'
			and( a.teminat_no not in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no)
			 or
			  a.teminat_no in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no and
								   		 kullanilan_tutar <> a.kullanilan_tutar)
			 ) ;


  Begin

	/*parametre index atamas? */
		ln_1310_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1310_SENET_ACIKLAMA');
		ln_1310_referans :=pkg_muhasebe.parametre_index_bul('1310_REFERANS');
		ln_1310_kur :=pkg_muhasebe.parametre_index_bul('1310_KUR');
		ln_1310_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1310_FIS_ACIKLAMA');
		ln_1310_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1310_ISTATISTIK_KOD');
		ln_1310_senet_sube_kodu :=pkg_muhasebe.parametre_index_bul('1310_SENET_SUBE_KODU');
		ln_1310_senet_tl_tutar :=pkg_muhasebe.parametre_index_bul('1310_SENET_TL_TUTAR');
		ln_1310_senet_fc_tutar :=pkg_muhasebe.parametre_index_bul('1310_SENET_FC_TUTAR');
		ln_1310_senet_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1310_SENET_DOVIZ_KODU');
		ln_1310_senet_cuzdan_tp :=pkg_muhasebe.parametre_index_bul('1310_SENET_CUZDAN_TP');
		ln_1310_senet_cuzdan_yp :=pkg_muhasebe.parametre_index_bul('1310_SENET_CUZDAN_YP');
		ln_1310_senet_cuzdan_muh_tp :=pkg_muhasebe.parametre_index_bul('1310_SENET_CUZDAN_MUHABIR_TP');
		ln_1310_senet_cuzdan_muh_yp :=pkg_muhasebe.parametre_index_bul('1310_SENET_CUZDAN_MUHABIR_YP');
		ln_1310_senet_durum_acik :=pkg_muhasebe.parametre_index_bul('1310_SENET_DURUM_ACIK');
		ln_1310_senet_durum_protesto :=pkg_muhasebe.parametre_index_bul('1310_SENET_DURUM_PROTESTO');
		ln_1310_senet_durum_kabul :=pkg_muhasebe.parametre_index_bul('1310_SENET_DURUM_KABUL');
   		ln_1310_teminat_ise :=pkg_muhasebe.parametre_index_bul('1310_TEMINAT_ISE');

		pkg_parametre.deger('1310_FIS_ACIKLAMA',ls_fis_aciklama);
        pkg_parametre.deger('1310_SENET_ACIKLAMA',ls_banka_aciklama);
	    pkg_parametre.deger('1310_TEMINAT_ACIKLAMA',ls_aciklama);

/* islem bilgisi detaylari alinir */
 for cur_islem in cursor_islem
   loop
   	   	  ls_bolum_kodu   := cur_islem.bolum_kodu;
		  ls_senet_no     := to_char(cur_islem.senet_no);
		  ls_durum_kodu   := cur_islem.durum_kodu;
		  ls_urun_sinif_kod := cur_islem.urun_sinif_kod;

   		   varchar_list(ln_1310_fis_aciklama) 	 :=nvl(ls_fis_aciklama,ls_aciklama);
		   varchar_list(ln_1310_senet_sube_kodu) := cur_islem.bolum_kodu;
		   varchar_list(ln_1310_banka_aciklama)  := nvl(ls_banka_aciklama || cur_islem.bolum_kodu ||'-' || to_char(cur_islem.senet_no) ,' ');
		   varchar_list(ln_1310_referans) 	     := nvl(cur_islem.bolum_kodu ||'-' || to_char(cur_islem.senet_no),'  ');
		   varchar_list(ln_1310_istatistik_kod)  := null;
		   varchar_list(ln_1310_senet_doviz_kodu)  :=cur_islem.doviz_kodu;
/* number list */
		   number_list(ln_1310_senet_fc_tutar) := cur_islem.senet_tutari;
		   number_list(ln_1310_senet_tl_tutar) := pkg_kur.doviz_doviz_karsilik(cur_islem.doviz_kodu,pkg_genel.LC_AL,null,cur_islem.senet_tutari,1,null,null,'O','A');
	  	   number_list(ln_1310_kur)	   :=  pkg_kur.doviz_doviz_karsilik(cur_islem.doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'O','A');
/**** boolean list ****/
		    boolean_list(ln_1310_senet_cuzdan_tp):=false;
		    boolean_list(ln_1310_senet_cuzdan_yp):=false;
			boolean_list(ln_1310_senet_cuzdan_muh_tp):=false;
			boolean_list(ln_1310_senet_cuzdan_muh_yp):=false;
			boolean_list(ln_1310_senet_durum_acik):= false;
			boolean_list(ln_1310_senet_durum_protesto):=false;
			boolean_list(ln_1310_senet_durum_kabul):=false;
   	        boolean_list(ln_1310_teminat_ise):=true;

		   case
		   	  when cur_islem.urun_sinif_kod in('CUZDAN-LC','MUNZAM-LC') then
	  	   		    boolean_list(ln_1310_senet_cuzdan_tp):=true;
		   	  when cur_islem.urun_sinif_kod in ('CUZDAN-FC','MUNZAM-FC') then
	  	   		    boolean_list(ln_1310_senet_cuzdan_yp):=true;
		   	  when cur_islem.urun_sinif_kod = 'MUHABIR-LC' then
	  	   		    boolean_list(ln_1310_senet_cuzdan_muh_tp):=true;
 	   	      when cur_islem.urun_sinif_kod ='MUHABIR-FC' then
	  	   		    boolean_list(ln_1310_senet_cuzdan_muh_yp):=true;
 			  else
			  	   raise urun_sinif_uygun_degil;
			end case;
/* durum sorulacak */
		  if cur_islem.durum_kodu in ( 'A','KS') then
			   boolean_list(ln_1310_senet_durum_acik):= true;
			elsif cur_islem.durum_kodu in ( 'K') then
			   boolean_list(ln_1310_senet_durum_kabul):= true;
			elsif cur_islem.durum_kodu in ( 'P') then
			   boolean_list(ln_1310_senet_durum_protesto):= true;
			else

			    raise durum_uygun_degil;
		  end if;

/* eger fis numaras? mevcut de?ilse once fi? kesilir .*/

      ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							null,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							ln_fis_no,
						    null	--ls_aciklama
							);

 	end loop;

	 if nvl(ln_fis_no,0) <> 0 then
		pkg_muhasebe.MUHASEBELESTIR(pn_fis_no);
    end if;

  Exception
   When durum_uygun_degil then
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '591' || pkg_hata.getDelimiter || ls_bolum_kodu || pkg_hata.getDelimiter || ls_senet_no || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When urun_sinif_uygun_degil then
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '592' || pkg_hata.getDelimiter || ls_bolum_kodu || pkg_hata.getDelimiter || ls_senet_no || pkg_hata.getDelimiter || ls_urun_sinif_kod|| pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   When Others Then
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '590' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

/***************************************************************************************************************/
/*   procedure sp_teminat_IptalOnaySonrasi															           */
/***************************************************************************************************************/
 Procedure sp_TeminatGuncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2,
							   ps_blokharic varchar2 default null)
 is
   guncellenmis_exception			   exception;
   ln_retval			  number:=0;
   ls_sqlstr			  varchar2(2000);
   ls_sql_template		  varchar2(2000);
   ls_source_table		  varchar2(2000);
   ls_dest_table		  varchar2(2000);
   ls_teminatvar varchar2(1) :='H';
  Begin

  ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);


  if   ls_teminatvar  = 'E'  then
   if ps_block NOT IN( 'CBS_KREDI_TEKLIF_SATIR_TEMINAT','CBS_TEMINAT_TOPLU_ISLEM','CBS_VW_TEMINAT_HEPSI' ,'CBS_TEMINAT_KONTROL' ,ps_blokharic  ) then
   	 --TODO 1: Set the source and destination table names
   	   ls_source_table:='CBS_TEMINAT_ISLEM';
--	   ls_source_table := PS_BLOCK;
	   ls_dest_table:='CBS_TEMINAT';
	     if ps_column = 'KULLANILAN_TUTAR' Then --and ps_column<>'TX_NO'
/*	   if ps_column<>'TEMINAT_NO' and ps_column<>'TX_NO'
		 AND  ps_column <> 'BANKA_KODU' and  ps_column <> 'BOLUM_KODU' and ps_column <> 'HESAP_MODUL_TUR_KOD and ps_column <> HESAP_URUN_SINIF' and ps_column <> 'HESAP_URUN_TUR_KOD' and ps_column <> 'KREDI_TEKLIF_SATIR_NO'
		 and ps_column <> 'KREDI_TEMINAT_TANIM_SIRA_NO' and ps_column <> 'MUSTERI_NO' and ps_column <> 'NAKDI_TEMINAT_HESAP_DOVIZ_KODU' and
		 ps_column <> 'NAKDI_TEMINAT_HESAP_NO' and ps_column <> 'REFERANS' and ps_column <> 'REFERANS_DURUMU' and
		 ps_column <> 'REF_CEK_NO' and ps_column <> 'SATIR_DURUM' and ps_column <> 'SECIM' and
		 ps_column <> 'SENET_NO' and ps_column <> 'SUBE_KODU' and ps_column <> 'TAHSIL_TEMINAT' and
		 ps_column <> 'TEKLIF_MUSTERI_NO' and
		 ps_column <> 'TEMINAT_DURUMU' and ps_column <> 'TEMINAT_HESAP_DOVIZ' and
		 ps_column <> 'TEMINAT_HESAP_NO'  THEN
*/
		 --TODO 2: Set the Primary Key Count (Default 1)
		   ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(1);
		 --TODO 3: Do not alter until next TODO :)
		    ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
	   		ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
			ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
	   		ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
			ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
		 --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
	        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEMINAT_NO');
	   	    ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','TEMINAT_NO');

		   execute immediate ls_sql_template into ln_retval,ps_oldvalue;

		end if;

   end if;


	if ln_retval<>1 then
	   raise  guncellenmis_exception;
	 end if;
  end if;

  Exception
   When  guncellenmis_exception then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   End;


 /***************************************************************************************************************/
/*   procedure sp_teminat_DogrulamaIptalSonra															           */
/***************************************************************************************************************/
 procedure sp_teminat_DogrulamaIptalSonra(pn_islem_no number)
 is
   ls_teminatvar varchar2(1) :='H';

 Begin
  ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

    if ls_teminatvar   = 'E' then
   	/* teminat islem Durum guncellenir */
		pkg_teminat.sp_teminat_islem_durumguncelle(pn_islem_no,'RED');
		--pkg_teminat.sp_nakdihesapblokekoyac(pn_islem_no ,-1);
	 end if;
 End;

/***************************************************************************************************************/
/*   procedure sp_teminat_IptalOnaySonrasi															           */
/***************************************************************************************************************/
 Procedure sp_teminat_iptalonaysonrasi(pn_islem_no number ,ps_islem_tipi varchar2 default 'ACILIS')
  is
    ls_teminatvar varchar2(1) :='H';
  Begin
  ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

  if ls_teminatvar   = 'E' then
    pkg_teminat.sp_Teminat_iptalsonrasi(pn_islem_no);
 	/* teminat islem ve teminat Durum guncellenir */
   --pkg_teminat.sp_teminat_islem_durumguncelle(pn_islem_no,'IPTAL');
   -- pkg_teminat.sp_nakdihesapblokekoyac(pn_islem_no ,-1);
	/* cek ve senet tahsile geri cevrilir.*/
	--pkg_teminat.sp_teminat_ceksenettahsil_yap(pn_islem_no);

  /* teminat i?lem ?ncesi hali ana tabloya aktar?l?r.*/
	pkg_teminat.sp_teminat_bloke_iptal(pn_islem_no,ps_islem_tipi);
	pkg_teminat.sp_iptalonaysonrasi_teminat_at(pn_islem_no,ps_islem_tipi);
	if ps_islem_tipi ='KAPAMA' then
		pkg_teminat.sp_teminat_iptal_nakdihesap(pn_islem_no);
	end if;
   end if;

  End;

 /***************************************************************************************************************/
/*   procedure sp_teminat_IptalOnaySonrasi															           */
/***************************************************************************************************************/
 Procedure sp_teminat_reddetmesonrasi(pn_islem_no number)
 is
   ls_teminatvar varchar2(1) :='H';
  Begin
   ls_teminatvar :=  pkg_teminat.sf_teminatislemvarmi(pn_islem_no);

  if ls_teminatvar   = 'E' then
 	/* teminat islem ve teminat Durum guncellenir */
	pkg_teminat.sp_teminat_islem_durumguncelle(pn_islem_no,'RED');
    --pkg_teminat.sp_nakdihesapblokekoyac(pn_islem_no ,-1);
  end if;
  End;

 /***************************************************************************************************************/
/*   Function sf_teminatislemvarmi														           */
/***************************************************************************************************************/

 Function sf_teminatislemvarmi(pn_tx_no  number) return varchar2
 is
 ls_mevcut varchar2(1):= 'H';
 Begin
 	  select distinct 'E'
	  into ls_mevcut
	  from cbs_teminat_islem
	  where tx_no = pn_tx_no;

	return ls_mevcut;
	exception
	when no_data_found then return'H';
 End;

 /***************************************************************************************************************/
/*    Procedure sp_Teminat_iptalsonrasi													           */
/***************************************************************************************************************/
 Procedure sp_Teminat_iptalsonrasi(pn_islem_no number)
 is
 cursor cursor_islem is
 	  select max(distinct a.tx_no)   tx_no
	   from  cbs_teminat_islem a,cbs_islem b
	  where a.tx_no = b.numara and
	  		b.durum not in ( 'D','2','R') and
			a.tx_no > pn_islem_no
			and teminat_no in ( select teminat_no from cbs_teminat_islem
						   	    where tx_no = pn_islem_no) ;

  ln_tx_no 			 number;
  islemvar 		     exception;
  ln_teminat_no		 number;
 Begin

 /* islemden sonra bitmis ve de?i?iklik yap?lm?? islem varsa iptale izin verilemez. */
  for cur_teminat in cursor_islem
    loop
		ln_tx_no := cur_teminat.tx_no;
	end loop;

	if nvl(ln_tx_no,0) <> 0 then
	   raise islemvar ;
	end if;


  Exception
   When  islemvar then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '808' || pkg_hata.getDelimiter ||to_char(ln_tx_no)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then null;

 End;

 /***************************************************************************************************************/
/*    Function sf_hesap_durum_al												           */
/***************************************************************************************************************/
 Function sf_hesap_durum_al(pn_hesap_no cbs_hesap.hesap_no%type) return cbs_hesap.DURUM_KODU%type
 is
  ls_durum  cbs_hesap.DURUM_KODU%type;
 Begin
 	  select durum_kodu
	  into ls_durum
	  from CBS_VW_HESAP_IZLEME
	  where hesap_no = pn_hesap_no ;

 return ls_durum ;
 exception when others then return  '';
 End;

 /***************************************************************************************************************/
/*    Function sf_altkod_zorunlumu											           */
/***************************************************************************************************************/
 Function sf_altkod_zorunlumu(ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return varchar2
 is
  ls_zorunlu varchar2(1) := 'E' ;
 Begin
 	  select alt_kod_zorunlu
	  into ls_zorunlu
	  from cbs_teminat_kodlari
	  where teminat_kodu = ps_teminat_kodu;

  return ls_zorunlu ;
  exception when others then return  'E';
 End;


  /* teminat kontrol sonrasi kosul islemleri */
 /***************************************************************************************************************/
/*    procedure sp_insert_teminat_kosul_islem									           */
/***************************************************************************************************************/
 procedure sp_insert_teminat_kosul_islem(pn_tx_no number ,ps_teklif_kosul_karsilandi varchar2, ps_islem_dorgulama_gonderildi varchar2)
 is
  ln_mevcut number := 0;
 begin
    select count(*)
	into ln_mevcut
	from    cbs_teminat_kosul_islem
	where tx_no = pn_tx_no ;

  	 if nvl(ln_mevcut,0) <> 0 then

		    update cbs_teminat_kosul_islem
			set    TEKLIF_KOSUL_KARSILANDI =ps_teklif_kosul_karsilandi ,
					ISLEM_DORGULAMAYA_GONDERILDI =ps_islem_dorgulama_gonderildi
			where tx_no = pn_tx_no;

		 else

		    insert into cbs_teminat_kosul_islem(TX_NO,
				   							    TEKLIF_KOSUL_KARSILANDI,
												ISLEM_DORGULAMAYA_GONDERILDI)
		     							values
			 								   ( pn_tx_no,
											     ps_teklif_kosul_karsilandi,
												 ps_islem_dorgulama_gonderildi);
	 end if;
  Exception
   When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1852' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

 end;

 /***************************************************************************************************************/
/*     Function sf_teminat_karsilandimi(								           */
/***************************************************************************************************************/
 Function sf_teminat_karsilandimi( pn_tx_no number ,pn_kredi_teklif_satir_numara number) return varchar2
 is
  ls_karsilandimi varchar2(1) := 'H' ;
  ln_adet number := 0 ;
 Begin
      if nvl(pn_kredi_teklif_satir_numara,0) <> 0 then
	 	  select count(*)
		  into ln_adet
		  from cbs_kredi_teklif_satir
		  where teklif_no = pkg_kredi.SF_SATIRNODAN_TEKLIFNOAL(pn_kredi_teklif_satir_numara) and
		  		teklif_satir_no = pn_kredi_teklif_satir_numara ;
	 end if;
	  if nvl(ln_adet,0) <> 0 then
	 	  select NVL(TEKLIF_KOSUL_KARSILANDI,'E')
		  into  ls_karsilandimi
		  from  cbs_teminat_kosul_islem
		  where tx_no = pn_tx_no ;
	 else
	 	ls_karsilandimi := 'E';
 	 end if;
  return ls_karsilandimi ;
  exception when others then return  'H';
 End;

 Procedure sp_teminat_islem_guncelle( pn_tx_no                  cbs_teminat_islem.tx_no%type,
  								      pn_teminat_no         	cbs_teminat.teminat_no%type,
									  pn_kullanilan_tutar		number	  )
  is
 Begin
          update cbs_teminat_islem
          set kullanilan_tutar = pn_kullanilan_tutar
          where tx_no = pn_tx_no and
		  		teminat_no = pn_teminat_no;

  Exception
		 when others then null;

 End;

 Function sf_teminatno_varmi( pn_teminat_no         	    cbs_teminat.teminat_no%type) return varchar2
 is
  ls_var varchar2(1) := 'H';
 Begin
 	  	  select 'E'
		  into ls_var
		  from cbs_teminat
		  where teminat_no = pn_teminat_no;
   return ls_var;

  Exception when others then return 'H';
 End;
/***************************************************************************************************************/
/*  procedure sp_teminat_iptalnakdihesap_muhasebe                                        */
/***************************************************************************************************************/
  procedure sp_teminat_iptal_nakdihesap(pn_islem_no number)
  /* kapama iptali acilis islemidir*/
   is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
	ln_fis_no				   cbs_fis.numara%type  := 0;
	ls_islem_kod               cbs_islem.islem_kod%type :='1310';
	ls_aciklama                varchar2(2000);
	ls_fis_mesaj			   varchar2(2000);
	ln_sonuc 				   number;
	ls_fis_aciklama                varchar2(2000);
	ls_banka_aciklama              varchar2(2000);
	ls_musteri_aciklama            varchar2(2000);

	ln_1310_banka_aciklama          number;
	ln_1310_musteri_aciklama        number;
	ln_1310_referans        		number;
	ln_1310_fis_aciklama        	number;
	ln_1310_istatistik_kod          number;
	ln_1310_islem_sube        		number;
	ln_1310_bdak_kur          		number;
	ln_1310_borclu_teminat_hesap    number;
	ln_1310_alacak_teminat_hesap    number;
	ln_1310_teminat_doviz        	number;
	ln_1310_kullan_teminattutar     number;
	ln_1310_kullan_tl_teminattutar  number;
	ln_1310_borclu_teminhesapsube   number;
	ln_1310_nakdi_teminat_ise		number;
	ln_1310_teminat_ise 			number;
	ln_1310_fark_negatif        	number;
	ln_1310_fark_pozitif        	number;
	ln_1310_alacakteminathesapsube  number;
	ln_borcbakiye 					number := 0;
	ln_1310_acilis					number;
	ps_fis_mesaj					varchar2(2000);

	cursor cursor_islem is
			/* kapama */
		   	select
				   a.teminat_no,
				   pkg_hesap.HESAPTANSUBEAL(a.BORCLU_TEMINAT_HESAP_NO) borclu_teminat_hesap_sube,
				   a.BORCLU_TEMINAT_HESAP_NO,
				   a.BORCLU_TEMINAT_HESAP_DOVIZ,
				   a.NAKDI_TEMINAT_HESAP_NO,
				   nvl(a.Kullanilan_tutar,0) kullanilan_tutar,
				   a.aciklama,
				   pkg_hesap.HESAPTANSUBEAL(a.NAKDI_TEMINAT_HESAP_NO)  alacak_teminat_hesap_sube
			from  cbs_teminat_islem a
			where a.tx_no=pn_islem_no and
				   teminat_durumu in ('ACIK')  and
				   a.bloke_hesap_secimi = 'HESAP'
				   and( teminat_no in (select teminat_no
								   from   CBS_TEMINAT_ONAYONCE_ISLEM
								   where tx_no  =pn_islem_no   ));

  Begin
/*ayr? fis kesilmesi istendiginden pn_fis no kullanilmamaktadir */
	/*parametre index atamas? */
		ln_1310_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1310_NAKDI_TEMINAT_ACIKLAMA');
		ln_1310_referans :=pkg_muhasebe.parametre_index_bul('1310_REFERANS');
		ln_1310_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1310_FIS_ACIKLAMA');
		ln_1310_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1310_ISTATISTIK_KOD');
		ln_1310_islem_sube :=pkg_muhasebe.parametre_index_bul('1310_ISLEM_SUBE');
		ln_1310_bdak_kur :=pkg_muhasebe.parametre_index_bul('1310_BDAK_KUR');
		ln_1310_borclu_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1310_BORCLU_TEMINAT_HESAP');
		ln_1310_alacak_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1310_ALACAK_TEMINAT_HESAP');
		ln_1310_teminat_doviz :=pkg_muhasebe.parametre_index_bul('1310_TEMINAT_DOVIZ');
		ln_1310_kullan_teminattutar :=pkg_muhasebe.parametre_index_bul('1310_KULLANILAN_TEMINAT_TUTARI');
		ln_1310_kullan_tl_teminattutar :=pkg_muhasebe.parametre_index_bul('1310_KULLANILAN_TL_TEMINAT_TUT');
		ln_1310_borclu_teminhesapsube :=pkg_muhasebe.parametre_index_bul('1310_BORCLU_TEMINAT_HESAP_SUBE');
		ln_1310_nakdi_teminat_ise :=pkg_muhasebe.parametre_index_bul('1310_NAKDI_TEMINAT_ISE');
		ln_1310_teminat_ise :=pkg_muhasebe.parametre_index_bul('1310_TEMINAT_ISE');
		ln_1310_fark_pozitif :=pkg_muhasebe.parametre_index_bul('1310_FARK_POZITIF');
		ln_1310_fark_negatif :=pkg_muhasebe.parametre_index_bul('1310_FARK_NEGATIF');
		ln_1310_fark_negatif :=pkg_muhasebe.parametre_index_bul('1310_FARK_NEGATIF');
		ln_1310_alacakteminathesapsube :=pkg_muhasebe.parametre_index_bul('1310_ALACAK_TEMINAT_HESAP_SUBE');
		ln_1310_acilis :=pkg_muhasebe.parametre_index_bul('1310_ACILIS');

        pkg_parametre.deger('1310_FIS_ACIKLAMA',ls_fis_aciklama);
        pkg_parametre.deger('1310_BANKA_ACIKLAMA',ls_banka_aciklama);
	    pkg_parametre.deger('1310_TEMINAT_ACIKLAMA',ls_aciklama);
        pkg_parametre.deger('1310_NAKDI_TEMINAT_ACIKLAMA',ls_musteri_aciklama);


    boolean_list(ln_1310_nakdi_teminat_ise):=true;
    boolean_list(ln_1310_teminat_ise)	   :=true;
	boolean_list(ln_1310_acilis)	   :=true;
	boolean_list(ln_1310_fark_pozitif)	   :=true;

/* islem bilgisi detaylari alinir */
 for cur_islem in cursor_islem
   loop
 	  ln_borcbakiye :=nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(cur_islem.borclu_teminat_hesap_no),0) ;
		if ln_borcbakiye  > 0  then
  		  if  nvl(cur_islem.kullanilan_tutar,0)  > ln_borcbakiye then
		  	  cur_islem.kullanilan_tutar :=ln_borcbakiye ;
		  end if;
  	    else
	 	      cur_islem.kullanilan_tutar := 0 ;
 	    end if;

	    begin
			update cbs_teminat_islem
			set    kullanilan_tutar =  cur_islem.kullanilan_tutar
			where  tx_no = pn_islem_no and
				   teminat_no = cur_islem.teminat_no;
		exception when others then null;
		end;
		begin
			update cbs_teminat
			set    kullanilan_tutar =  cur_islem.kullanilan_tutar
			where   teminat_no = cur_islem.teminat_no;
		exception when others then null;
		end;

		varchar_list(ln_1310_fis_aciklama) 	 :=nvl(nvl(cur_islem.aciklama,ls_fis_aciklama),ls_aciklama);
		varchar_list(ln_1310_islem_sube)  	 :=pkg_tx.amir_bolumkodu_al( pn_islem_no);-- pkg_baglam.bolum_kodu;
		varchar_list(ln_1310_banka_aciklama)  := nvl(nvl(ls_musteri_aciklama,' ') || nvl( to_char(cur_islem.borclu_teminat_hesap_no), ' '),'  ');
		varchar_list(ln_1310_referans) 	     := nvl(to_char(cur_islem.borclu_teminat_hesap_no),' ');
		varchar_list(ln_1310_istatistik_kod)  := null;

	   varchar_list(ln_1310_borclu_teminat_hesap) := to_char(cur_islem.borclu_teminat_hesap_no);
	   varchar_list(ln_1310_borclu_teminhesapsube):= cur_islem.borclu_teminat_hesap_sube;
	   varchar_list(ln_1310_teminat_doviz)			 :=cur_islem.borclu_teminat_hesap_doviz;
	   varchar_list(ln_1310_alacak_teminat_hesap) := to_char(cur_islem.NAKDI_TEMINAT_HESAP_NO);
	   varchar_list(ln_1310_alacakteminathesapsube) := to_char(cur_islem.alacak_teminat_hesap_sube);

	   number_list(ln_1310_kullan_teminattutar) := abs(cur_islem.kullanilan_tutar) ;
	   number_list(ln_1310_kullan_tl_teminattutar) := pkg_kur.doviz_doviz_karsilik(cur_islem.borclu_teminat_hesap_doviz,pkg_genel.LC_AL,null,number_list(ln_1310_kullan_teminattutar),1,null,null,'O','A');
  	   number_list(ln_1310_bdak_kur)	   		   :=  pkg_kur.doviz_doviz_karsilik(cur_islem.borclu_teminat_hesap_doviz,pkg_genel.LC_AL,null,1,1,null,null,'O','A');
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */

      ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
								null,
								pn_islem_no,
								varchar_list ,
								number_list  ,
								date_list    ,
								boolean_list ,
								null,
								false,
								 ln_fis_no,
								null,--ls_aciklama,
								'H'
								);
	 end loop;

	 if nvl(ln_fis_no,0) <> 0 then
	 	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
	 end if;

  Exception
   When no_data_found then null;
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '532' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

 procedure sp_teminat_kapama_onaysonrasi(pn_islem_no number )
  is
    cursor cursor_teminat_islem is
	  select teminat_no,
	 		 bloke_hesap_secimi,
			 referans,
			 kullanilan_tutar,
			 musteri_no
			 teminat_hesap_no,musteri_no,
	   		 BORCLU_TEMINAT_hesap_no,
			 BORCLU_teminat_hesap_doviz
	  from  cbs_teminat_islem
	  where tx_no = pn_islem_no and
	 	    bloke_hesap_secimi in ( 'BLOKE') and
			teminat_durumu = 'ACIK' and
			teminat_kodu = '12'	and
			referans is not null ;

 cursor cur_islem is
    select
		   nvl(kayit_kullanici_kodu, pkg_baglam.KULLANICI_KODU) kayit_kullanici_kodu ,
		   nvl(kayit_kullanici_rol_numara,pkg_baglam.Rol_numara) kayit_kullanici_rol_numara,
		   nvl(kayit_kullanici_bolum_kodu, pkg_baglam.bolum_kodu)kayit_kullanici_bolum_kodu,
		   nvl(kayit_tarih,pkg_muhasebe.banka_tarihi_bul) kayit_tarih,
		   nvl(dogru_tarih,pkg_muhasebe.banka_tarihi_bul) dogru_tarih,
		   nvl(dogru_kullanici_kodu,pkg_baglam.KULLANICI_KODU) dogru_kullanici_kodu,
		   nvl(dogru_kullanici_bolum_kodu, pkg_baglam.bolum_kodu) dogru_kullanici_bolum_kodu,
		   nvl(kayit_sistem_tarihi, sysdate) kayit_sistem_tarihi,
		   nvl(onay_sistem_tarihi,sysdate)onay_sistem_tarihi,
		   nvl(onay_kullanici_kodu, pkg_baglam.KULLANICI_KODU)  onay_kullanici_kodu,
		   nvl(onay_kullanici_rol_numara, pkg_baglam.Rol_numara) onay_kullanici_rol_numara,
		   nvl(onay_kullanici_bolum_kodu, pkg_baglam.bolum_kodu) onay_kullanici_bolum_kodu,
		   nvl(onay_tarih , pkg_muhasebe.banka_tarihi_bul) onay_tarih
	from cbs_islem
	where numara = pn_islem_no ;

	r_islem cur_islem%rowtype;
   BEGIN

    for c_islem in cur_islem
	 loop
	  r_islem := c_islem ;
	 end loop;

	  For  cur_teminat_islem in  cursor_teminat_islem Loop
       pkg_bloke.sp_bloke_yarat (
								   ps_bloke_referans => cur_teminat_islem.referans,
								   pn_musteri_no =>cur_teminat_islem.musteri_no,
								   pn_HESAP_NO=>cur_teminat_islem.borclu_teminat_hesap_no,
								   ps_DOVIZ_KODU=> cur_teminat_islem.borclu_teminat_hesap_doviz,
								   pn_BLOKE_TUTARI=>0,
								   ps_BLOKE_NEDEN_KODU=>NULL,
								   ps_ACIKLAMA=>NULL,
								   pd_BLOKE_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pd_BLOKE_BITIS_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
								   pn_tx_no=> pn_islem_no,
								   p_COZ_KAYIT_TARIH =>r_islem.kayit_tarih,
								   p_COZ_KAYIT_SISTEM_TARIH=>r_islem.kayit_sistem_tarihi,
								   p_COZ_KAYIT_KULLANICI_KODU=>r_islem.kayit_kullanici_kodu,
								   p_COZ_KAYIT_KULLANICI_BOLUMKOD=>r_islem.kayit_kullanici_bolum_kodu,
								   p_COZ_DOGRU_TARIH=>r_islem.dogru_tarih,
								   p_COZ_DOGRU_KULLANICI_KODU=>r_islem.dogru_kullanici_kodu,
								   p_COZ_DOGRU_KULLANICI_BOLUMKOD=>r_islem.dogru_kullanici_bolum_kodu,
								   p_COZ_ONAY_TARIH=>r_islem.onay_tarih,
								   p_COZ_ONAY_SISTEM_TARIH=>r_islem.onay_sistem_tarihi,
								   p_COZ_ONAY_KULLANICI_KODU=>r_islem.onay_kullanici_kodu,
								   p_COZ_ONAY_KULLANICI_BOLUMKOD=>r_islem.onay_kullanici_bolum_kodu,
								   ps_kapama=>'KAPAMA');
	 End loop;
  End;
 procedure sp_teminat_uygundegilse_kapat(pn_islem_no number)
 is
 Begin
   /*170604 teminat durumu uygun de?ilse guncellenir.*/
		  update cbs_teminat_islem a
		  set  teminat_durumu= 'KAPALI'
		  where a.tx_no = pn_islem_no and
		  		teminat_durumu = 'ACIK' and
		  		pkg_teminat.sf_teminat_durumu_uygunmu( teminat_kodu,
										   referans,
										   ref_cek_no,
										   bolum_kodu,
										   senet_no,
										   musteri_no,
										   kredi_teminat_tanim_sira_no,
										   borclu_teminat_hesap_no ,
										   sozlesme_no,
										   ek_sozlesme_no)= 'H' ;

  Exception when others then null;
 End;
    FUNCTION sf_teminat_hesap_blokeuygunmu (pn_hesap_no cbs_hesap.hesap_no%TYPE)
      RETURN VARCHAR2
   IS
      ls_uygun           VARCHAR2 (1)                        := 'H';
      ls_modul_tur_kod   cbs_urun_sinif.modul_tur_kod%TYPE;
      ld_vade_tarihi     DATE;
   BEGIN
      SELECT modul_tur_kod, vade_tarihi
        INTO ls_modul_tur_kod, ld_vade_tarihi
        FROM cbs_vw_hesap_izleme
       WHERE hesap_no = pn_hesap_no AND
	   		 pkg_hesap.personel_hesap_mi(hesap_no) = 0 and
	   		 (
			  ( modul_tur_kod =PKG_HESAP.MODUL_TUR_VADESIZ and urun_tur_kod  in ('CURRENT' , 'DEMAND DEP') )
			  or
			 ( modul_tur_kod = PKG_HESAP.MODUL_TUR_VADELI and  urun_tur_kod  in ('SHORT TERM' , 'OVERNIGHT' , 'LONG TERM' , 'MEDIUMTERM'))
			 );

      IF ls_modul_tur_kod is not null then
	        ls_uygun := 'E';
      END IF;

	  RETURN ls_uygun;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 'H';
   END;
END pkg_teminat;
/

