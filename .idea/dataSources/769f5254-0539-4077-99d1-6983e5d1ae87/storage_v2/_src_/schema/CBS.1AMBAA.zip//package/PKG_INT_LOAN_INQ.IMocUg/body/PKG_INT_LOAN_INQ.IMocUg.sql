create PACKAGE BODY     PKG_INT_LOAN_INQ IS  

FUNCTION GetLoans(ps_lang varchar2,
                  ps_customer_id varchar2,
                  ps_currency_code varchar2 default null,
                  ps_status varchar2 default null,
                  pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ln_customer_number_second number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN
  
    ln_customer_no := pkg_int_customer_inq.GetCustomerNo(ps_customer_id);
    
    if ln_customer_no is null then
        raise le_customer_not_found;
    end if;
    
    ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);

    open pc_ref for 
          select
                 pkg_musteri.sf_musteri_adi(h.musteri_no) as name,
                     case
                         when ap_gecikme_gun_sayisi > 0 or faiz_gecikme_gun_sayisi > 0
                               then 'pastdue'
                         when non_accrual_status = 'Y'
                               then 'nonaccrual'
                         when durum_kodu = 'A'
                               then 'active'
                         else 'close' 
                     end as status,
                     'individual' as owner_type,
                     hesap_no as account_number,
                     iliskili_hesap_no as main_account_number,
                     pkg_hesap.external_hesapno_al(iliskili_hesap_no) as main_iban,
                     h.doviz_kodu as currency_code,
                     tutar as amount,
                     vade_suresi as term,
                     decode(vade_tipi, 'AY', 'months', 'GUN', 'days', 'months') as term_type, --translate
                     aciklama as credit_usage_reason,
                     (select vade_tarih from cbs_vw_kredi_hesap_taksit l where l.hesap_no = h.hesap_no 
                              and durum_kodu = 'A' 
                              order by sira_no  
                              offset 0 rows fetch next 1 rows only) as payment_day,
                     acilis_tarihi as opening_date,
                     kredi_vade as maturity_date,
                     --Product
                     modul_tur_kod as module_type_code, 
                     urun_tur_kod as product_type_code, 
                     urun_sinif_kod as product_class_code, 
                     --Branch
                     sube_kodu as branch_code,
                     Pkg_Genel.bolum_adi_al(sube_kodu) as branch_name,
                     --interestRate
                     faiz_hesaplama_tipi as rate_type,
                     esas_gun_sayisi as interest_calculation_base,
                     round(esas_gun_sayisi /  12) as day_interest_calculation_base,
                     nvl(faiz_orani, 0) as interest_rate, 
                     nvl(yearly_int_rate, 0) as yearly_interest_rate,
                     nvl(penalty_rate, 0) as penalty_rate,
                     nvl(pastdue_faiz_orani, 0) as pastdue_rate,
                     nvl(fon_orani, 0) as kkdf_rate,
                     nvl(bsmv_orani / 100, 0) as bsmv_rate,
                     nvl(yearly_effective_int_rate, 0) as yearly_cost_rate
           from cbs_hesap_kredi h
              inner join cbs_kredi_teklif_satir k
               on kredi_teklif_satir_numara = teklif_satir_no 
                            where h.musteri_no = ln_customer_no
                            and h.doviz_kodu = nvl(ps_currency_code, h.doviz_kodu)
                            and durum_kodu = nvl(decode(ps_status, 'active', 'A', 'close', 'K', null), durum_kodu)
                            and urun_tur_kod not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL', 'PAST DUE', 'PD-FIXRATE') 
                            and urun_sinif_kod not in ('CREDIT CARD-LC', 'CREDIT CARD-FC', 'OVERLIMIT-LC', 'OVERLIMIT-FC')
                            and teklif_no in (select max(teklif_no) from cbs_kredi_teklif_satir where kredi_teklif_satir_numara = teklif_satir_no)
                            and kredi_vade >= add_months(trunc(sysdate), -3) 
            union
            select
                 pkg_musteri.sf_musteri_adi(h.musteri_no) as name,
                     case
                         when ap_gecikme_gun_sayisi > 0 or faiz_gecikme_gun_sayisi > 0
                               then 'pastdue'
                         when non_accrual_status = 'Y'
                               then 'nonaccrual'
                         when durum_kodu = 'A'
                               then 'active'
                         else 'close' 
                     end as status,
                     'company' as owner_type,
                     hesap_no as account_number,
                     iliskili_hesap_no as main_account_number,
                     pkg_hesap.external_hesapno_al(iliskili_hesap_no) as main_iban,
                     h.doviz_kodu as currency_code,
                     tutar as amount,
                     vade_suresi as term,
                     decode(vade_tipi, 'AY', 'months', 'GUN', 'days', 'months') as term_type, --translate
                     aciklama as credit_usage_reason,
                     (select vade_tarih from cbs_vw_kredi_hesap_taksit l where l.hesap_no = h.hesap_no 
                              and durum_kodu = 'A' 
                              order by sira_no  
                              offset 0 rows fetch next 1 rows only) as payment_day,
                     acilis_tarihi as opening_date,
                     kredi_vade as maturity_date,
                     --Product
                     modul_tur_kod as module_type_code, 
                     urun_tur_kod as product_type_code, 
                     urun_sinif_kod as product_class_code, 
                     --Branch
                     sube_kodu as branch_code,
                     Pkg_Genel.bolum_adi_al(sube_kodu) as branch_name,
                     --interestRate
                     faiz_hesaplama_tipi as rate_type,
                     esas_gun_sayisi as interest_calculation_base,
                     round(esas_gun_sayisi /  12) as day_interest_calculation_base,
                     nvl(faiz_orani, 0) as interest_rate, 
                     nvl(yearly_int_rate, 0) as yearly_interest_rate,
                     nvl(penalty_rate, 0) as penalty_rate,
                     nvl(pastdue_faiz_orani, 0) as pastdue_rate,
                     nvl(fon_orani, 0) as kkdf_rate,
                     nvl(bsmv_orani / 100, 0) as bsmv_rate,
                     nvl(yearly_effective_int_rate, 0) as yearly_cost_rate
           from cbs_hesap_kredi h
              inner join cbs_kredi_teklif_satir k
               on kredi_teklif_satir_numara = teklif_satir_no 
                            where ln_customer_number_second is not null
                            and h.musteri_no = ln_customer_number_second
                            and h.doviz_kodu = nvl(ps_currency_code, h.doviz_kodu)
                            and durum_kodu = nvl(decode(ps_status, 'active', 'A', 'close', 'K', null), durum_kodu)
                            and urun_tur_kod not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL', 'PAST DUE', 'PD-FIXRATE') 
                            and urun_sinif_kod not in ('CREDIT CARD-LC', 'CREDIT CARD-FC', 'OVERLIMIT-LC', 'OVERLIMIT-FC')
                            and teklif_no in (select max(teklif_no) from cbs_kredi_teklif_satir where kredi_teklif_satir_numara = teklif_satir_no)
                            and kredi_vade >= add_months(trunc(sysdate), -3);
          
  return ls_returncode;
  
EXCEPTION
    when le_customer_not_found then
        log_at('GetLoans', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          return '454'; 
    when others then
        log_at('GetLoans', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         raise;
END; 
FUNCTION  GetLoan(ps_lang varchar2,
                  ps_account_number varchar2,
                  pc_ref OUT CursorReferenceType) RETURN varchar2   
IS
ls_owner_type varchar(100 byte);
ls_customer_type varchar(1 byte);
ls_returncode varchar2(3) := '000';
BEGIN

    ls_customer_type := pkg_int_customer_inq.GetCustomerTypeByAccount(ps_account_number);
             
    if pkg_int_account_inq.CheckJoinAccountByAccount(ps_account_number) then
         ls_owner_type := 'partner';
    elsif ls_customer_type is not null and ls_customer_type = '2' then
         ls_owner_type := 'company';
    else
         ls_owner_type := 'individual';
    end if;
    
     open pc_ref for 
        select
            pkg_musteri.sf_musteri_adi(h.musteri_no) as name,
                     case
                         when ap_gecikme_gun_sayisi > 0 or faiz_gecikme_gun_sayisi > 0
                               then 'pastdue'
                         when non_accrual_status = 'Y'
                               then 'nonaccrual'
                         when durum_kodu = 'A'
                               then 'active'
                         else 'close' 
                     end as status,
                     ls_owner_type as owner_type,
                     hesap_no as account_number,
                     iliskili_hesap_no as main_account_number,
                     pkg_hesap.external_hesapno_al(iliskili_hesap_no) as main_iban,
                     h.doviz_kodu as currency_code,
                     tutar as amount,
                     vade_suresi as term,
                     decode(vade_tipi, 'AY', 'months', 'GUN', 'days', 'months') as term_type, --translate
                     aciklama as credit_usage_reason,
                     (select vade_tarih from cbs_vw_kredi_hesap_taksit l where l.hesap_no = h.hesap_no 
                              and durum_kodu = 'A' 
                              order by sira_no  
                              offset 0 rows fetch next 1 rows only) as payment_day,
                     acilis_tarihi as opening_date,
                     kredi_vade as maturity_date,
                     --Product
                     modul_tur_kod as module_type_code, 
                     urun_tur_kod as product_type_code, 
                     urun_sinif_kod as product_class_code, 
                     --Branch
                     sube_kodu as branch_code,
                     Pkg_Genel.bolum_adi_al(sube_kodu) as branch_name,
                     --interestRate
                     faiz_hesaplama_tipi as rate_type,
                     esas_gun_sayisi as interest_calculation_base,
                     round(esas_gun_sayisi /  12) as day_interest_calculation_base,
                     nvl(faiz_orani, 0) as interest_rate, 
                     nvl(yearly_int_rate, 0) as yearly_interest_rate,
                     nvl(penalty_rate, 0) as penalty_rate,
                     nvl(pastdue_faiz_orani, 0) as pastdue_rate,
                     nvl(fon_orani, 0) as kkdf_rate,
                     nvl(bsmv_orani / 100, 0) as bsmv_rate,
                     nvl(yearly_effective_int_rate, 0) as yearly_cost_rate
           from cbs_hesap_kredi h
              inner join cbs_kredi_teklif_satir k
               on kredi_teklif_satir_numara = teklif_satir_no 
                    where hesap_no = to_number(ps_account_number)
                    and urun_tur_kod not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL') 
                    and urun_tur_kod not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL', 'PAST DUE', 'PD-FIXRATE')
                    and teklif_no in (select max(teklif_no) from cbs_kredi_teklif_satir where kredi_teklif_satir_numara = teklif_satir_no)
                    and kredi_vade >= add_months(trunc(sysdate), -3) ; 
                                          
       return ls_returncode;

EXCEPTION
    when others then
         log_at('GetLoans', ps_account_number, sqlerrm, dbms_utility.format_error_backtrace);
         raise;
END;  
FUNCTION  GetPaymentPlan(ps_lang varchar2,
                         ps_account_number varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2   
IS
ls_returncode varchar2(3) := '000';
BEGIN
    
    open pc_ref for
          select 
               count(sira_no) as installment_count,
               nvl(yaratildigi_tarih,'') as creation_date,
               sum(nvl(taksit, 0)) as total_installment_amount,
               sum(nvl(anapara, 0)) as total_principal_amount,
               sum(nvl(faiz, 0)) as total_interest_amount,
               sum(nvl(kkdf, 0)) as total_kkdf_amount,
               sum(nvl(bsmv, 0)) as total_bsmv_amount,
               sum(nvl(taksit - tahsil_taksit, 0)) as total_unpaid_installment_amount,
               sum(nvl(anapara - tahsil_anapara, 0)) as total_unpaid_principal_amount,
               sum(nvl(faiz - tahsil_faiz, 0)) as total_unpaid_interest_amount,
               sum(nvl(kkdf - tahsil_kkdf, 0)) as total_unpaid_kkdf_amount,
               sum(nvl(bsmv - tahsil_bsmv, 0)) as total_unpaid_bsmv_amount,
               sum(nvl(penalty_amount, 0)) as total_penalty_amount,
               sum(nvl(paid_penalty_amount, 0)) as total_paid_penalty_amount
            from cbs_hesap_kredi_taksit
                  where hesap_no = to_number(ps_account_number) group by yaratildigi_tarih; 
                
    return ls_returncode;

EXCEPTION
    when others then
          raise;
END;     
FUNCTION GetInstallments(ps_lang varchar2,
                         ps_account_number varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2  
IS
ls_returncode varchar2(3) := '000';
BEGIN
  
    open pc_ref for
     select cr.sira_no as payment_order, 
           cr.vade_tarih as payment_date,
           case 
             when (cr.vade_tarih - trunc(sysdate)) > 0 then
              (cr.vade_tarih - trunc(sysdate))
             else
              0
           end remaining_days_to_maturity,
           nvl(cr.taksit, 0) as amount,
           nvl(cr.anapara, 0) as principal_amount,
           nvl(cr.faiz, 0) as interest_amount,
           nvl(cr.kkdf, 0) as kkdf_amount,
           nvl(cr.bsmv, 0) as bsmv_amount,
           nvl(cr.taksit - cr.tahsil_taksit, 0) as unpaid_amount,
           nvl(cr.anapara - cr.tahsil_anapara, 0) as unpaid_principal_amount,
           nvl(cr.faiz - cr.tahsil_faiz, 0) as unpaid_interest_amount,
           nvl(cr.kkdf - cr.tahsil_kkdf, 0) as unpaid_kkdf_amount,
           nvl(cr.bsmv - cr.tahsil_bsmv, 0) as unpaid_bsmv_amount,
           nvl(cr.penalty_amount, 0) as penalty_amount,
           nvl(cr.paid_penalty_amount, 0) as paid_penalty_amount,
           (select nvl(sum(a.taksit), 0) 
             from cbs_hesap_kredi_taksit a 
              where  a.hesap_no = cr.hesap_no 
                 and a.sira_no > cr.sira_no) as remaining_balance,
           nvl(cr.kal_anapara, 0) as remaining_principal_balance,
           case
              when durum_kodu = 'A' and tahsil_taksit > 0 and cr.vade_tarih < trunc(sysdate)
                   then 'paidPartially'
--              when durum_kodu = 'A' and cr.vade_tarih < trunc(sysdate)
--                   then 'payableLate'
--              when durum_kodu = 'A' and cr.vade_tarih = trunc(sysdate)
--                   then 'payableOnTime'
              when durum_kodu = 'O'
                   then 'paidOnTime'
              when durum_kodu = 'A'
                   then 'unpaid'
              else
                   'paidLate'
           end as status
        from cbs_hesap_kredi_taksit cr
              where cr.hesap_no = to_number(ps_account_number) 
                order by payment_order;
          
  return ls_returncode;
    
EXCEPTION
    when others then
          raise;
END; 
FUNCTION GetPayInstallment(ps_lang varchar2,
                        ps_account_number varchar2,
                        ps_payment_order varchar2,
                        ps_payment_date varchar2,
                        pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

   open pc_ref for
     select cr.sira_no as payment_order, 
           cr.vade_tarih as payment_date,
           case 
             when (cr.vade_tarih - trunc(sysdate)) > 0 then
              (cr.vade_tarih - trunc(sysdate))
             else
              0
           end remaining_days_to_maturity,
           nvl(cr.taksit, 0) as amount,
           nvl(cr.anapara, 0) as principal_amount,
           nvl(cr.faiz, 0) as interest_amount,
           nvl(cr.kkdf, 0) as kkdf_amount,
           nvl(cr.bsmv, 0) as bsmv_amount,
           nvl(cr.taksit - cr.tahsil_taksit, 0) as unpaid_amount,
           nvl(cr.anapara - cr.tahsil_anapara, 0) as unpaid_principal_amount,
           nvl(cr.faiz - cr.tahsil_faiz, 0) as unpaid_interest_amount,
           nvl(cr.kkdf - cr.tahsil_kkdf, 0) as unpaid_kkdf_amount,
           nvl(cr.bsmv - cr.tahsil_bsmv, 0) as unpaid_bsmv_amount,
           nvl(cr.penalty_amount, 0) as penalty_amount,
           nvl(cr.paid_penalty_amount, 0) as paid_penalty_amount,
           (select nvl(sum(a.taksit), 0) 
             from cbs_hesap_kredi_taksit a 
              where  a.hesap_no = cr.hesap_no 
                 and a.sira_no > cr.sira_no) as remaining_balance,
           nvl(cr.kal_anapara, 0) as remaining_principal_balance,
           case
              when durum_kodu = 'A' and tahsil_taksit > 0 and cr.vade_tarih < trunc(sysdate)
                   then 'paidPartially'
--              when durum_kodu = 'A' and cr.vade_tarih < trunc(sysdate)
--                   then 'payableLate'
--              when durum_kodu = 'A' and cr.vade_tarih = trunc(sysdate)
--                   then 'payableOnTime'
              when durum_kodu = 'O' and faiz_gecikme_gun_sayisi > 0
                   then 'paidLate'
              when durum_kodu = 'O'
                   then 'paidOnTime'
              else
                   'unpaid'
           end as status
        from cbs_hesap_kredi_taksit cr
              where hesap_no = to_number(ps_account_number) 
                and sira_no = to_number(ps_payment_order)
                and vade_tarih = nvl(to_date(ps_payment_date, 'dd/mm/yyyy'), vade_tarih);
                
  return ls_returncode;
    
EXCEPTION 
    when others then
          raise;
END;                                                                                                                       
END;
/

