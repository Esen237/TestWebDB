create PACKAGE BODY Pkg_Memzuc IS
--------------------------------------------------------------------------------------
 PROCEDURE memzuc_gonderilen_ekle(pn_yil NUMBER, pn_ay NUMBER) IS
 BEGIN
   INSERT INTO CBS_MEMZUC_GONDERILEN(YIL, AY, GONDERILDIGI_TARIH)
   VALUES (pn_yil, pn_ay, Pkg_Muhasebe.banka_tarihi_bul);
 END;
--------------------------------------------------------------------------------------
 FUNCTION memzuc_olusturulmus_ay(pn_yil NUMBER, pn_ay NUMBER) RETURN NUMBER IS
 CURSOR c_0 IS
  SELECT 1
    FROM CBS_MEMZUC_GONDERILEN
   WHERE yil = pn_yil
     AND ay = pn_ay;
  ln_temp NUMBER;
  BEGIN
    OPEN c_0;
	  FETCH c_0 INTO ln_temp;
	  IF c_0%NOTFOUND THEN
	    ln_temp := 0;
	  END IF;
	CLOSE c_0;
	RETURN ln_temp;
  END;
--------------------------------------------------------------------------------------
 FUNCTION memzuc_urun_limit_toplami_al(pn_musteri_no NUMBER, pn_kredi_teklif_satir_no NUMBER) RETURN NUMBER IS
 CURSOR c_1 IS
 SELECT SUM(Pkg_Kur.mb_dak_to_lc (d.fc_doviz_kodu, NVL (d.fc_limit, 0))) lim
   FROM CBS_MUSTERI_URUN_LIMIT c, CBS_MUSTERI_URUN_LIMIT d
  WHERE c.musteri_no = pn_musteri_no
    AND c.kredi_teklif_satir_numara = pn_kredi_teklif_satir_no
	AND d.musteri_no = c.musteri_no
	AND d.urun_grub_no = c.urun_grub_no;
 ln_temp NUMBER;
 BEGIN
  OPEN c_1;
   FETCH c_1 INTO ln_temp;
  CLOSE c_1;
  RETURN ln_temp;
 END;
--------------------------------------------------------------------------------------
PROCEDURE memzuc_gelen_kayit_kaydet(ps_satir VARCHAR2,pn_ay NUMBER,pn_yil NUMBER) IS
 ln_BANKA_KODU 				    NUMBER ;
 ls_BANKA_ADI	   	 		    VARCHAR2(30);
 ls_BANKA_SUBE_ADI			    VARCHAR2(25);
 ls_VERGI_NO				    VARCHAR2(10);
 ls_MUS_ADI					    VARCHAR2(54);
 ls_RISK_KODU				    VARCHAR2(3);
 ln_LIMIT					    NUMBER ;
 ln_BIR_12_AY_VADELI		    NUMBER;
 ln_ONIKI_24_AY_VADELI		    NUMBER;
 ln_YIRMIDORT_AY_USTU_VADELI    NUMBER ;
 ln_FAIZ_REESKONT			    NUMBER;
 ln_FAIZ_TAHAKUK			    NUMBER ;
 ln_CALISTIGI_BANKA_SAYISI	    NUMBER ;
 ln_CALISTIGI_DIGER_KURUM_SAYI  NUMBER ;
BEGIN
	 ln_BANKA_KODU 				    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,1,10)))) ;
	 ls_BANKA_ADI	   	 		    := LTRIM(RTRIM(SUBSTR(ps_satir,11,30)));
	 ls_BANKA_SUBE_ADI			    := LTRIM(RTRIM(SUBSTR(ps_satir,41,25)));
	 ls_VERGI_NO				    := LTRIM(RTRIM(SUBSTR(ps_satir,66,10)));
	 ls_MUS_ADI					    := LTRIM(RTRIM(SUBSTR(ps_satir,76,54)));
	 ls_RISK_KODU				    := LTRIM(RTRIM(SUBSTR(ps_satir,130,3)));
	 ln_LIMIT					    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,133,10)))) ;
	 ln_BIR_12_AY_VADELI		    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,143,10)))) ;
	 ln_ONIKI_24_AY_VADELI		    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,153,10)))) ;
	 ln_YIRMIDORT_AY_USTU_VADELI    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,163,10)))) ;
	 ln_FAIZ_REESKONT			    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,173,10)))) ;
	 ln_FAIZ_TAHAKUK			    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,183,10)))) ;
	 ln_CALISTIGI_BANKA_SAYISI	    := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,193,2)))) ;
	 ln_CALISTIGI_DIGER_KURUM_SAYI  := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,195,2)))) ;


	 INSERT INTO CBS_MEMZUC_GELEN
	 (BANKA_KODU, BANKA_ADI, BANKA_SUBE_ADI, VERGI_NO, MUS_ADI, RISK_KODU, LIMIT, BIR_12_AY_VADELI,
	  ONIKI_24_AY_VADELI, YIRMIDORT_AY_USTU_VADELI, FAIZ_REESKONT, FAIZ_TAHAKUK, CALISTIGI_BANKA_SAYISI,
	  CALISTIGI_DIGER_KURUM_SAYI, YIL, AY)
	 VALUES(ln_BANKA_KODU, ls_BANKA_ADI, ls_BANKA_SUBE_ADI, ls_VERGI_NO, ls_MUS_ADI, ls_RISK_KODU, ln_LIMIT, ln_BIR_12_AY_VADELI,
	  ln_ONIKI_24_AY_VADELI, ln_YIRMIDORT_AY_USTU_VADELI, ln_FAIZ_REESKONT, ln_FAIZ_TAHAKUK, ln_CALISTIGI_BANKA_SAYISI,
	  ln_CALISTIGI_DIGER_KURUM_SAYI, pn_YIL, pn_AY);

	 COMMIT ;

END ;
--------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------

END;
/

