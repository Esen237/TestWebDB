create PACKAGE BODY     PKG_INT_QR_INQ IS
    FUNCTION CheckQrAccount(ps_customer_id varchar2, ps_source_iban varchar2, ps_currency varchar2, pn_amount number) RETURN varchar2 IS
--         ln_customer_from_customer_id number;
--         ln_pe_customer_from_customer_id number;
--         ln_customer_from_external_acc number;
        ln_account number;
        ln_bakiye number;
        ln_hesap_varmi number;
        ln_cnt_bad number;
        ls_response varchar2(3) := '000';
    BEGIN
        ------- Customer Control -------
        --ln_customer_from_customer_id := CBS.PKG_INT_CUSTOMER_INQ.GetCustomerNo(ps_customer_id);
        --ln_pe_customer_from_customer_id := CBS.PKG_INT_CUSTOMER_INQ.GetCustomerNoForTheSecondType(ps_customer_id);
        --ln_customer_from_external_acc := CBS.PKG_HESAP.GetMusteriNoFromExternal(ps_source_iban);
        if nvl(CBS.PKG_INT_ACCOUNT_INQ.GetCustomerMatchByIban(ps_customer_id, ps_source_iban), 0) = 0 then
            RETURN '453'; --Customer does not match by account
        end if;
        ------- Customer Control -------

        ------- Currency Control -------
        if ps_currency <> CBS.PKG_GENEL.LC_AL then
           RETURN '453'; --The currency of clearing and gross transfer must be in KGS
        end if;
        ------- Currency Control -------

        ln_account := CBS.PKG_HESAP.GetHesapNoFromExternal(ps_source_iban, ps_currency);
        ------- Account Control -------
        SELECT count(*)
          INTO ln_hesap_varmi
          FROM CBS.CBS_HESAP
         WHERE HESAP_NO = ln_account
           AND DURUM_KODU = 'A' ;

        IF nvl(ln_hesap_varmi,0) = 0 THEN
            RETURN '454'; --Account not found
        END IF;
        ------- Account Control -------

        ------- Badlist Control -------
        SELECT count(*)
          INTO ln_cnt_bad
          FROM CBS.CBS_HESAP
         WHERE HESAP_NO = ln_account
           AND nvl(BADLIST_FLAG, 'H') = 'E';

        IF nvl(ln_cnt_bad, 0) > 0 THEN
            RETURN '457'; --Customer on the bad list
        END IF;
        ------- Badlist Control -------

        ------- Balance Control -------
        ln_bakiye := CBS.PKG_HESAP.Kullanilabilir_Bakiye_Al(ln_account);
        IF nvl(pn_amount, 0) > 0 AND nvl(pn_amount, 0) > ln_bakiye THEN
            RETURN '456'; --Insufficient balance
        END IF;
        ------- Balance Control -------

        RETURN ls_response;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.CheckQrAccount', 'customer_id: ' || ps_customer_id || ' iban: ' || ps_source_iban, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END CheckQrAccount;

    FUNCTION GetQrCustomerType(ps_customer_id varchar2, ps_source_iban varchar2) RETURN varchar2 IS
        ln_customer_no number;
        ls_customer_type varchar2(1);
        ls_check_result varchar2(3);
        account_check_failed exception;
    BEGIN
        ls_check_result := CheckQrAccount(ps_customer_id, ps_source_iban, CBS.PKG_GENEL.LC_AL,0);
        IF ls_check_result != '000' THEN
            RAISE account_check_failed;
        END IF;

        ln_customer_no := CBS.PKG_INT_CUSTOMER_INQ.GetCustomerNo(ps_customer_id);
        ls_customer_type := CBS.PKG_MUSTERI.SF_MUSTERI_TIPI_AL(ln_customer_no);

        RETURN CASE WHEN ls_customer_type IN (1, 2) THEN ls_customer_type
                    WHEN ls_customer_type = 3 THEN 2
               END;
    EXCEPTION
        WHEN account_check_failed THEN
            RETURN ls_check_result;
            --RAISE_APPLICATION_ERROR(-20100, ls_check_result);
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.GetQrCustomerType', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END GetQrCustomerType;

    FUNCTION CheckQRBeneficiary(ps_target_iban varchar2, ps_our_qr varchar2) RETURN varchar2 IS
        ln_customer CBS.CBS_MUSTERI.MUSTERI_NO%type;
        ls_merchant_name varchar2(200);
        ls_currency CBS.CBS_DOVIZ_KODLARI.DOVIZ_KODU%type;
        ls_check_result varchar2(3);
        ln_our_qr_count number;
        account_check_failed exception;
        our_qr_transaction_error exception;
    BEGIN
        SELECT count(*) INTO ln_our_qr_count FROM CBS.CBS_IPC_QR_PAYMENTS WHERE OUR_QR_TRANSACTION_ID = ps_our_qr AND STATUS = 'PROCESSED';
        IF nvl(ln_our_qr_count, 0) > 0 THEN
            RAISE our_qr_transaction_error;
        END IF;

        SELECT h.MUSTERI_NO, h.DOVIZ_KODU
        INTO ln_customer, ls_currency
        FROM CBS.CBS_VW_HESAP_IZLEME h
        JOIN CBS.CBS_VW_MUSTERI_IZLEME m
            ON m.MUSTERI_NO = h.MUSTERI_NO
        WHERE h.EXTERNAL_HESAP_NO = ps_target_iban;

        ls_check_result := CheckQrAccount(PKG_INT_CUSTOMER_INQ.GetCustomerIdByCustomer(ln_customer), ps_target_iban, ls_currency, 0);
        IF ls_check_result != '000' THEN
            RAISE account_check_failed;
        END IF;

        ls_merchant_name := CBS.PKG_MUSTERI.SF_MUSTERI_ADI(ln_customer);

        RETURN MaskQRName(ls_merchant_name);
    EXCEPTION
        WHEN account_check_failed THEN
            RETURN ls_check_result;
            --RAISE_APPLICATION_ERROR(-20100, ls_check_result);
        WHEN our_qr_transaction_error THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.CheckQRBeneficiary', ps_our_qr, 'Duplicated our QR');
            RETURN '460';
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.CheckQRBeneficiary', ps_target_iban, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END CheckQRBeneficiary;

 FUNCTION GetQRBeneficiary(ps_target_iban varchar2, ps_our_qr varchar2, pc_ref OUT CursorReferenceType) RETURN varchar2 IS
        ln_customer CBS.CBS_MUSTERI.MUSTERI_NO%type;
        ls_merchant_name varchar2(200);
        ls_currency CBS.CBS_DOVIZ_KODLARI.DOVIZ_KODU%type;
        ls_check_result varchar2(3);
        ln_our_qr_count number;
        account_check_failed exception;
        our_qr_transaction_error exception;
    BEGIN
    
        SELECT count(*) INTO ln_our_qr_count FROM CBS.CBS_IPC_QR_PAYMENTS WHERE OUR_QR_TRANSACTION_ID = ps_our_qr AND STATUS = 'PROCESSED';
        
        IF nvl(ln_our_qr_count, 0) > 0 THEN
            RAISE our_qr_transaction_error;
        END IF;

        SELECT h.MUSTERI_NO, h.DOVIZ_KODU
        INTO ln_customer, ls_currency
        FROM CBS.CBS_VW_HESAP_IZLEME h
        JOIN CBS.CBS_VW_MUSTERI_IZLEME m
            ON m.MUSTERI_NO = h.MUSTERI_NO
        WHERE h.EXTERNAL_HESAP_NO = ps_target_iban;

        ls_check_result := CheckQrAccount(PKG_INT_CUSTOMER_INQ.GetCustomerIdByCustomer(ln_customer), ps_target_iban, ls_currency, 0);
        IF ls_check_result != '000' THEN
            RAISE account_check_failed;
        END IF;

        ls_merchant_name := CBS.PKG_MUSTERI.SF_MUSTERI_ADI(ln_customer);
        
        open 
           pc_ref for
             select MaskQRName(ls_merchant_name) as beneficiary_name, CBS.PKG_MUSTERI.SF_MUSTERI_TIPI_AL(ln_customer) as beneficiary_type from dual;

        RETURN ls_check_result;
    EXCEPTION
        WHEN account_check_failed THEN
            RETURN ls_check_result;
            --RAISE_APPLICATION_ERROR(-20100, ls_check_result);
        WHEN our_qr_transaction_error THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.GetQRBeneficiary', ps_our_qr, 'Duplicated our QR');
            RETURN '460';
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.GetQRBeneficiary', ps_target_iban, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END;

    FUNCTION GetQrStatus(ps_ipc_transaction_id varchar2 DEFAULT NULL,
                         ps_status varchar2 DEFAULT NULL,
                         ps_direction varchar2 DEFAULT NULL,
                         ps_from_date varchar2 DEFAULT NULL,
                         ps_to_date varchar2 DEFAULT NULL,
                         pc_ref OUT CursorReferenceType)
    RETURN varchar2 IS
        ls_response varchar2(3) := '000';
    BEGIN
        OPEN pc_ref
        FOR
            SELECT TX_NO as transaction_number,
                   TRANSACTION_REFERENCE as ipc_transaction_id,
                   CHECK_NUMBER,
                   STATUS,
                   AMOUNT,
                   CBS.PKG_INT_QR_INQ.MaskQRName(RECIPIENT) as recipient,
                   CBS.PKG_MUSTERI.SF_MUSTERI_TIPI_AL(CUSTOMER_NO) as client_type,
                   PROCESSED_DATE as executed_time,
                   CREATED_DATE as created,
                   CUSTOMER_ID
            FROM CBS.CBS_IPC_QR_PAYMENTS qr
            WHERE (ps_ipc_transaction_id IS NULL OR qr.TRANSACTION_REFERENCE = ps_ipc_transaction_id)
              AND (ps_status IS NULL OR qr.STATUS = upper(ps_status))
              AND (ps_direction IS NULL OR qr.DIRECTION = decode(upper(ps_direction), 'OUTGOING', 'OUT', 'INCOMING', 'IN', upper(ps_direction)))
              AND qr.CREATED_DATE between nvl(to_date(ps_from_date, 'YYYY-MM-DD'), qr.CREATED_DATE) and nvl(to_date(ps_to_date, 'YYYY-MM-DD'), SYSDATE);

        RETURN ls_response;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.GetQrStatus', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END GetQrStatus;

    FUNCTION MaskQRName(ps_name varchar2) RETURN varchar2 IS
        ls_result varchar2(200);
    BEGIN
        --SELECT LISTAGG(substr(t.parts, 1, 1) || case when length(t.parts) >= 5 then '***' else rpad('*', length(t.parts)-2, '*') end || substr(t.parts, -1, 1), ' ')
        SELECT LISTAGG(substr(t.parts, 1, 1) || '***' || substr(t.parts, -1, 1), ' ')
        INTO ls_result
        FROM (
                 SELECT REGEXP_SUBSTR(ps_name, '[^ ]+', 1, level) AS parts
                 FROM dual
                 CONNECT BY REGEXP_SUBSTR(ps_name, '[^ ]+', 1, level) IS NOT NULL
             ) t;

        RETURN ls_result;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_QR_ERROR('CBS.PKG_INT_QR_INQ.MaskQRName', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RAISE;
    END MaskQRName;
END;
/

