create PACKAGE BODY     PKG_INT_CUSTOMER_TRX IS  

FUNCTION TranCustModification(ps_lang varchar2,
                              ps_customer_id varchar2,
                              ps_profession_code varchar2 default null,
                              ps_address_type varchar2 default null,
                              ps_country_code varchar2 default null,
                              ps_city_code varchar2 default null,
                              ps_zip_code varchar2 default null,
                              ps_full_address_info varchar2 default null,
                              ps_company_address_info varchar2 default null,
                              ps_email varchar2 default null,
                              ps_phone_sorting varchar2 default null,
                              ps_phone_country_code varchar2 default null,
                              ps_prefix varchar2 default null,
                              ps_phone_number varchar2 default null,
                              ps_passport_number varchar2 default null,
                              ps_issue_place varchar2 default null,
                              ps_issue_date date default null,
                              ps_validity_date date default null,
                              ps_notif_package_id varchar2 default null,
                              ps_channel_code varchar2 default '1',
                              ps_user_code varchar2 default 'CINT_CALLER',       
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_tran_no number;
ln_tran_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ls_cash_code varchar2(10 byte);
ln_currency_code varchar2(3) := pkg_genel.lc_al;
ls_tran_branch_code varchar2(3);
ls_branch_code varchar(10);
ls_account_number varchar(20 byte);

ls_gsm_phone_country_code varchar2(10 byte);
ls_gsm_prefix varchar2(10 byte);
ls_gsm_phone_number varchar2(50 byte);
ls_gsm_phone_country_code_2 varchar2(10 byte);
ls_gsm_prefix_2 varchar2(10 byte);
ls_gsm_phone_number_2 varchar2(50 byte);
ls_gsm_phone_country_code_3 varchar2(10 byte);
ls_gsm_prefix_3 varchar2(10 byte);
ls_gsm_phone_number_3 varchar2(50 byte);

ls_phone_country_code varchar2(10 byte);
ls_prefix varchar2(10 byte);
ls_phone_number varchar2(50 byte);
ls_phone_country_code_2 varchar2(10 byte);
ls_prefix_2 varchar2(10 byte);
ls_phone_number_2 varchar2(50 byte);
ls_phone_country_code_3 varchar2(10 byte);
ls_prefix_3 varchar2(10 byte);
ls_phone_number_3 varchar2(50 byte);

ls_customer_type varchar2(1 byte);
ln_customer_no number;

ls_status varchar2(3 byte);
ln_tx_no number;
ls_returncode varchar2(3) := '000';

le_customer_not_found exception;
le_pending_trx exception;
begin

    ln_tran_code:=1001;

    ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
    
    if ln_customer_no is null then
        raise le_customer_not_found;
    end if;

    ls_module_type_code := 'CUSTOMER';
    ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no);
    ls_product_type_code := pkg_musteri.sf_musteri_urun_tur_al (ls_customer_type);
    ls_product_class_code := pkg_musteri.sf_musteri_urun_sinif_al (ls_module_type_code,
                                               ls_product_type_code);
     
    ls_branch_code := pkg_musteri.sf_bolum_kodu_al(ln_customer_no);
    ls_tran_branch_code := pkg_musteri.sf_bolum_kodu_al(ln_customer_no);
    
    if ps_phone_sorting = '1' then
        ls_gsm_phone_country_code := ps_phone_country_code;
        ls_gsm_prefix := ps_prefix;
        ls_gsm_phone_number := ps_phone_number;
    elsif ps_phone_sorting = '2' then
        ls_gsm_phone_country_code_2 := ps_phone_country_code;
        ls_gsm_prefix_2 := ps_prefix;
        ls_gsm_phone_number_2 := ps_phone_number;
    elsif ps_phone_sorting = '3' then
        ls_gsm_phone_country_code_3 := ps_phone_country_code;
        ls_gsm_prefix_3 := ps_prefix;
        ls_gsm_phone_number_3 := ps_phone_number;
    elsif ps_phone_sorting = '4' then
        ls_phone_country_code := ps_phone_country_code;
        ls_prefix := ps_prefix;
        ls_phone_number := ps_phone_number;
    elsif ps_phone_sorting = '5' then
        ls_phone_country_code_2 := ps_phone_country_code;
        ls_prefix_2 := ps_prefix;
        ls_phone_number_2 := ps_phone_number;
    elsif ps_phone_sorting = '6' then
        ls_phone_country_code_3 := ps_phone_country_code;
        ls_prefix_3 := ps_prefix;
        ls_phone_number_3 := ps_phone_number;
    end if;
    
    
    pkg_baglam.yarat(ls_branch_code, ln_role);
    
    if nvl (ln_customer_no, 0) <> 0 then
    
         ls_status := pkg_musteri.sf_musteri_kodu_al(ln_customer_no);

         if ls_status = 'A' then
            ln_tx_no := pkg_tx1001.sf_onay_bekleyen_varmi(0, ln_customer_no, 1001);

            if nvl (ln_tx_no, 0) = 0 then

               pkg_musteri.sp_musteri_guncel_kaydi_olus (ln_customer_no,
                                                         ln_tran_no,
                                                         ls_status);
            else
                raise le_pending_trx;                                        
            end if;  
         else
            raise le_customer_not_found;
         end if;
    end if;
                                             
    update cbs_musteri_guncellenen set meslek_kod = nvl(to_number(ps_profession_code), meslek_kod),
                                       extre_adres_kod = nvl(ps_address_type, extre_adres_kod),
                                       pasaport_no = nvl(ps_passport_number, pasaport_no),
                                       verildigi_yer = nvl(ps_issue_place, verildigi_yer),
                                       verildigi_tarih = nvl(ps_issue_date, verildigi_tarih),
                                       gecerlilik_tarihi = nvl(ps_validity_date, gecerlilik_tarihi), 
                                       notif_pack = nvl(to_number(ps_notif_package_id), notif_pack) where tx_no = ln_tran_no;
                                       
    update cbs_musteri_guncel_adres set adres_kod = nvl(ps_address_type, adres_kod), --/customer/profile/address
                               adres = nvl(ps_full_address_info, adres), --/customer/profile/address/{customerId}/{addressType}
                               il_kod = nvl(ps_city_code, il_kod), --/customer/profile/address/{customerId}/{addressType}
                               posta_kod = nvl(ps_zip_code, posta_kod), --/customer/profile/address/{customerId}/{addressType}
                               ulke_kod = nvl(ps_country_code, ulke_kod), --/customer/profile/address/{customerId}/{addressType}
                               email = nvl(ps_email, email), --/customer/profile/email/{customerId}/{eMailType}
                               tel_alan_kod = nvl(ls_prefix, tel_alan_kod), --/customer/profile/phone/{customerId}/{phoneType}
                               tel_no = nvl(ls_phone_number, tel_no), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_alan_kod = nvl(ls_gsm_prefix, gsm_alan_kod), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_no = nvl(ls_gsm_phone_number, gsm_no), --/customer/profile/phone/{customerId}/{phoneType} 
                               isyeri_unvani = nvl(ps_company_address_info,isyeri_unvani), --/customer/profile/address
                               ulke_tel_kod = nvl(ls_phone_country_code, ulke_tel_kod), --/customer/profile/phone/{customerId}/{phoneType},
                               ulke_gsm_kod = nvl(ls_gsm_phone_country_code, ulke_gsm_kod), --/customer/profile/phone/{customerId}/{phoneType}
                               ulke_tel_kod_2 = nvl(ls_phone_country_code_2, ulke_tel_kod_2), --/customer/profile/phone/{customerId}/{phoneType}
                               tel_alan_kod_2 = nvl(ls_prefix_2, tel_alan_kod_2), --/customer/profile/phone/{customerId}/{phoneType}
                               tel_no_2 = nvl(ls_phone_number_2, tel_no_2), --/customer/profile/phone/{customerId}/{phoneType}
                               ulke_tel_kod_3 = nvl(ls_phone_country_code_3, ulke_tel_kod_3), --/customer/profile/phone/{customerId}/{phoneType}
                               tel_alan_kod_3 = nvl(ls_prefix_3, tel_alan_kod_3), --/customer/profile/phone/{customerId}/{phoneType}
                               tel_no_3 = nvl(ls_phone_number_3, tel_no_3), --/customer/profile/phone/{customerId}/{phoneType}             
                               ulke_gsm_kod_2 = nvl(ls_phone_country_code_2, ulke_gsm_kod_2), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_alan_kod_2 = nvl(ls_prefix_2, gsm_alan_kod_2), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_no_2 = nvl(ls_phone_number_2, gsm_no_2), --/customer/profile/phone/{customerId}/{phoneType}
                               ulke_gsm_kod_3 = nvl(ls_phone_country_code_3, ulke_gsm_kod_3), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_alan_kod_3 = nvl(ls_prefix_3, gsm_alan_kod_3), --/customer/profile/phone/{customerId}/{phoneType}
                               gsm_no_3 = nvl(ls_phone_number_3, gsm_no_3) --/customer/profile/phone/{customerId}/{phoneType}
                           where tx_no = ln_tran_no;
                                         
        
      pkg_int_api.create_transaction (ln_tran_no, ln_tran_code,
                                   ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   0, ls_tran_branch_code, ls_branch_code, ln_role,
                                   ln_currency_code, ln_customer_no, ls_account_number,
                                   ls_cash_code, to_number(ps_channel_code), ps_user_code);

      pkg_int_api.process_transaction (ln_tran_no);
      
      commit;
 
      open pc_ref for select ln_tran_no from dual;
      
  return ls_returncode;
  
EXCEPTION
    when le_customer_not_found then
         log_at('TranCustomerModification', ln_customer_no, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         open pc_ref for select sysdate from dual;
         return '454';
    when le_pending_trx then
         log_at('TranCustomerModification', ln_customer_no, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         open pc_ref for select sysdate from dual;
         return '258';
    when others then
         ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
         log_at('TranCustomerModification', ln_customer_no, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
         rollback;
         open pc_ref for select sysdate from dual;
         if ls_returncode = '999' or ls_returncode is null then
           raise;
         end if;
         return ls_returncode;
END;  

FUNCTION PutProfession(ps_lang varchar2,
                       ps_customer_id varchar2,
                       ps_profession_code varchar2 default null,
                       ps_channel_code varchar2 default '1',
                       ps_user_code varchar2 default 'CINT_CALLER',       
                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count number;
ls_returncode varchar2(3) := '000';
le_profession_code_invalid exception;
le_passport_expired exception;
BEGIN 

   select count(*) into ln_count from cbs_meslek_kodlari
                        where meslek_kodu = to_number(ps_profession_code);
                        
    if ln_count = 0  then
        raise le_profession_code_invalid;
    end if;
    
    ln_count := pkg_int_customer_inq.CheckForPassportExpiredDate(ps_customer_id); --Bakdoolot ib-192
    
    if ln_count != 1 then
        raise le_passport_expired;
    end if; 
   
   ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_profession_code => ps_profession_code,
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_user_code,       
                    pc_ref => pc_ref);
                    
   return ls_returncode;
  
EXCEPTION
    when le_profession_code_invalid then
        rollback;
        return '453';
    when le_passport_expired then
        rollback;
        return '463';
    when others then
        log_at('PutProfession', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        raise;  
END;   
                   
FUNCTION PutAddress(ps_lang varchar2,
                    ps_customer_id varchar2,
                    ps_address_type varchar2 default null,
                    ps_country_code varchar2 default null,
                    ps_city_code varchar2 default null,
                    ps_zip_code varchar2 default null,
                    ps_full_address_info varchar2 default null,
                    ps_company_address_info varchar2 default null,
                    ps_channel_code varchar2 default '1',
                    ps_user_code varchar2 default 'CINT_CALLER',       
                    pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count number;
ls_returncode varchar2(3) := '000';
le_passport_expired exception;
BEGIN 

     ln_count := pkg_int_customer_inq.CheckForPassportExpiredDate(ps_customer_id); --Bakdoolot ib-192
    
     if ln_count != 1 then
        raise le_passport_expired;
     end if; 
   

     ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_address_type => ps_address_type,
                    ps_country_code => ps_country_code,
                    ps_city_code => ps_city_code,
                    ps_zip_code => ps_zip_code,
                    ps_full_address_info => ps_full_address_info,
                    ps_company_address_info => ps_company_address_info,
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_channel_code,       
                    pc_ref => pc_ref);
                    
     return ls_returncode;
  
EXCEPTION
    when le_passport_expired then
         log_at('PutAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         return '463';  
    when others then
         log_at('PutAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         raise;  
END;                     
                                        
FUNCTION PutEmail(ps_lang varchar2,
                  ps_customer_id varchar2,
                  ps_email varchar2 default null,
                  ps_channel_code varchar2 default '1',
                  ps_user_code varchar2 default 'CINT_CALLER',       
                  pc_ref OUT CursorReferenceType) RETURN varchar2     
IS
ln_count number;
ls_cust_data_modif_attempt varchar2(3);
ls_returncode varchar2(3) := '000';
le_limit_of_attempts_exceeded exception;
le_passport_expired exception;
BEGIN 

    ls_cust_data_modif_attempt := pkg_int_customer_inq.GetCustDataModifAttempt(ps_customer_id); --Bakdoolot ib-192   
    
    if ls_cust_data_modif_attempt <> '000' then
       raise le_limit_of_attempts_exceeded;
    end if;
    
    ln_count := pkg_int_customer_inq.CheckForPassportExpiredDate(ps_customer_id); --Bakdoolot ib-192
    
    if ln_count != 1 then
        raise le_passport_expired;
    end if; 

     ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_email => ps_email,
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_user_code,       
                    pc_ref => pc_ref);
                    
     return ls_returncode;
  
EXCEPTION
    when le_limit_of_attempts_exceeded then
         log_at('PutEmail', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         return '456';
    when le_passport_expired then
         log_at('PutEmail', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         return '463';  
    when others then
         log_at('PutEmail', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         raise;  
END;                   
FUNCTION PutPhone(ps_lang varchar2,
                  ps_customer_id varchar2,
                  ps_phone_sorting varchar2 default null,
                  ps_phone_country_code varchar2 default null,
                  ps_prefix varchar2 default null,
                  ps_phone_number varchar2 default null,
                  ps_channel_code varchar2 default '1',
                  ps_user_code varchar2 default 'CINT_CALLER',       
                  pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN 

     ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_phone_sorting => ps_phone_sorting,
                    ps_phone_country_code => ps_phone_country_code,
                    ps_prefix => ps_prefix,
                    ps_phone_number => ps_phone_number,
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_user_code,       
                    pc_ref => pc_ref);
                    
     return ls_returncode;
  
EXCEPTION
    when others then
         log_at('PutPhone', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         raise;  
END;

FUNCTION PutPassport(ps_lang varchar2,
                     ps_customer_id varchar2,
                     ps_passport_number varchar2 default null,
                     ps_issue_place varchar2 default null,
                     ps_issue_date varchar2 default null,
                     ps_validity_date varchar2 default null,
                     ps_channel_code varchar2 default '1',
                     ps_user_code varchar2 default 'CINT_CALLER',       
                     pc_ref OUT CursorReferenceType) RETURN varchar2
                    
IS
ls_returncode varchar2(3) := '000';
ls_resident_status varchar2(1);
ls_cust_data_modif_attempt varchar2(3);
le_customer_is_not_resident exception;
le_limit_of_attempts_exceeded exception;
BEGIN 
    
    ls_resident_status := pkg_int_customer_inq.GetCustResidentStatus(ps_customer_id);
    if ls_resident_status <> 1 then
        raise le_customer_is_not_resident;
    end if;    
    
    ls_cust_data_modif_attempt := pkg_int_customer_inq.GetCustDataModifAttempt(ps_customer_id);    
    if ls_cust_data_modif_attempt <> '000' then
       raise le_limit_of_attempts_exceeded;
    end if;
    
     ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_passport_number => ps_passport_number,
                    ps_issue_place => ps_issue_place,
                    ps_issue_date => TO_DATE(ps_issue_date, 'dd.mm.yyyy'),
                    ps_validity_date => TO_DATE(ps_validity_date, 'dd.mm.yyyy'),
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_user_code,       
                    pc_ref => pc_ref);
                    
     return ls_returncode;
  
EXCEPTION
    when le_customer_is_not_resident then
        log_at('PutPassport', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '453';
    when le_limit_of_attempts_exceeded then
        log_at('PutPassport', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '456';  
    when others then
        log_at('PutPassport', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        raise;  
END;
FUNCTION PutActualAddress(ps_lang varchar2,
                          ps_customer_id varchar2,
                          ps_actual_address varchar2 default null,
                          ps_channel_code varchar2 default '1',
                          ps_user_code varchar2 default 'CINT_CALLER',       
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
ls_resident_status varchar2(1);
ls_cust_data_modif_attempt varchar2(3);
ls_full_address_info varchar2(150);
le_customer_is_not_resident exception;
le_limit_of_attempts_exceeded exception;
BEGIN 
    
    ls_resident_status := pkg_int_customer_inq.GetCustResidentStatus(ps_customer_id);
    if ls_resident_status <> 1 then
        raise le_customer_is_not_resident;
    end if;    
    
    ls_cust_data_modif_attempt := pkg_int_customer_inq.GetCustDataModifAttempt(ps_customer_id);    
    if ls_cust_data_modif_attempt <> '000' then
       raise le_limit_of_attempts_exceeded;
    end if;
    
    
    ls_full_address_info := pkg_int_customer_inq.GetCustFullAddress(ps_customer_id) || '/' || ps_actual_address;
    
     ls_returncode := TranCustModification(ps_lang => ps_lang,
                    ps_customer_id => ps_customer_id,
                    ps_full_address_info => ls_full_address_info,
                    ps_channel_code => ps_channel_code,
                    ps_user_code => ps_user_code,       
                    pc_ref => pc_ref);
                    
     return ls_returncode;
  
EXCEPTION
    when le_customer_is_not_resident then
        log_at('PutActualAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '453';
    when le_limit_of_attempts_exceeded then
        log_at('PutActualAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '456';  
    when others then
        rollback;
        log_at('PutActualAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;


FUNCTION NotificationPushEnabled(ps_lang varchar2, 
                                ps_customer_id varchar2, 
                                ps_notif_package_id varchar2 default null,                  
                                ps_enabled varchar2 default null,
                                ps_customer_lang varchar2 DEFAULT NULL,
                                ps_channel_code varchar2 default '1', 
                                ps_user_code varchar2 default 'CINT_CALLER',
                                pc_ref OUT CursorReferenceType) RETURN varchar2 
IS	
ls_count_customer number;
ls_count_settings number;
ln_customer_number number;
ln_customer_lang varchar2(2);
ls_enabled varchar2(2);
ls_returncode varchar2(3) := '000';
customerNotFoundexception exception;
BEGIN
	   ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
	   ls_enabled :=ps_enabled;
       ln_customer_lang := ps_customer_lang;
       select count(*) into ls_count_customer from cbs.cbs_musteri where musteri_no = ln_customer_number and durum_kodu = 'A';
       
        if ls_count_customer = 0 then
            raise customernotfoundexception;
        end if;
       
        
        if ps_customer_lang is not null and ps_enabled is null then
           ls_enabled := 'Y';
        end if;
        if ls_enabled is not null then
            select count(*) into ls_count_settings from cbs_customer_notif_settings where customer_no = ln_customer_number;
            if ls_count_settings = 0 then
                if ln_customer_lang is null then
                   ln_customer_lang :='KY';
                end if;
                insert into cbs_customer_notif_settings (customer_no, enabled, lang) values (ln_customer_number, ls_enabled, ln_customer_lang);
            else
                if ln_customer_lang is not null then
                   update cbs_customer_notif_settings set enabled = ls_enabled, lang = ln_customer_lang where customer_no = ln_customer_number;
                else
                    update cbs_customer_notif_settings set enabled = ls_enabled where customer_no = ln_customer_number; 
                end if;
            end if;
        end if;

        if ps_notif_package_id is not null then
            ls_returncode := trancustmodification(ps_lang => ps_lang,
                                                    ps_customer_id => ps_customer_id,
                                                    ps_notif_package_id => ps_notif_package_id,
                                                    ps_channel_code => ps_channel_code,
                                                    ps_user_code => ps_user_code,       
                                                    pc_ref => pc_ref); 
        end if;

        return ls_returncode;

EXCEPTION 
	when customernotfoundexception then
        rollback;
        return '454';
    when others then
        rollback;
        log_at('NotificationPushEnabled', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
	    raise;	
END;

END;
/

