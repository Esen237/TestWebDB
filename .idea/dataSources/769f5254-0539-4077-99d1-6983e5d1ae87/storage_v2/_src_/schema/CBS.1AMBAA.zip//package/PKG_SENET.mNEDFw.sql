create package PKG_SENET is

 Function Sf_Senet_Tahsil_Tarihi_Al( ps_bolum_kodu cbs_senet_tahsil.bolum_kodu%type,pn_senet_no cbs_senet_tahsil.senet_no%type) return cbs_senet_tahsil.tahsil_tarihi%type;
 Function Sf_Senet_Tahsil_TxNo_Al( ps_bolum_kodu cbs_senet_tahsil.bolum_kodu%type,pn_senet_no cbs_senet_tahsil.senet_no%type) return cbs_senet_tahsil.tx_no%type;
 Function Sf_Senet_Kabul_Tarihi_Al( ps_bolum_kodu cbs_senet_kabul.bolum_kodu%type,pn_senet_no cbs_senet_kabul.senet_no%type) return cbs_senet_kabul.kabul_tarihi%type;
 Function Sf_Senet_Cikis_Tarihi_Al( ps_bolum_kodu cbs_senet_cikis.bolum_kodu%type,pn_senet_no cbs_senet_cikis.senet_no%type) return cbs_senet_cikis.cikis_tarihi%type;
 Function Sf_Senet_Cikis_TxNo_Al( ps_bolum_kodu cbs_senet_cikis.bolum_kodu%type,pn_senet_no cbs_senet_cikis.senet_no%type) return cbs_senet_cikis.tx_no%type;
 Procedure SenetBilgiAktar(ps_bolum_kodu IN cbs_senet.bolum_kodu%TYPE,pn_senet_no IN NUMBER,pn_txno IN NUMBER);
 Function  TeminatGirilmis (pn_txno NUMBER) return boolean;
 procedure sp_senet_tahsiltemin_guncelle ( ps_bolum_kodu cbs_senet.bolum_kodu%type, pn_senet_no cbs_senet.senet_no%type ,ps_tahsil_teminat cbs_senet.urun_tur_kod%type);
 Function sf_senet_durumu_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  pn_senet_no     cbs_senet.senet_no%TYPE) return cbs_senet.DURUM_KODU%type;
 Function sf_senet_tutari_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  pn_senet_no     cbs_senet.senet_no%TYPE) return cbs_senet.DURUM_KODU%type;

 Function sf_senet_vadetarihi_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  	  pn_senet_no     cbs_senet.senet_no%TYPE) return date;

 Function sf_senet_teminat_turu_al( ps_bolum_kodu   cbs_senet.bolum_kodu%TYPE,
							  	    pn_senet_no     cbs_senet.senet_no%TYPE) return varchar2;


End PKG_SENET;

/

