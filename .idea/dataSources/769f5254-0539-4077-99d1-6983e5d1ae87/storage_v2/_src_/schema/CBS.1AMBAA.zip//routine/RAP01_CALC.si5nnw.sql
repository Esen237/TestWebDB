create FUNCTION     RAP01_CALC(p_tarih date, p_tur varchar2, p_sube varchar2 default null) RETURN VARCHAR2 IS
    ln_lc number;
    ln_fc number;
    ls_cur varchar2(3);
    ld_date date;
    
    cursor rf_cur is
        select * from cbs_weekend_rpt_mizan 
        where dk_numara in (11519000,11519100, 11520000, 11520100);
    cur_row rf_cur%rowtype;
BEGIN
    ld_date := pkg_tarih.previous_working_day(p_tarih);
    
    if ld_date = p_tarih then
        RETURN 'OK';
    end if;
    
    delete from cbs_weekend_rpt_mizan;
    
    insert into cbs_weekend_rpt_mizan(tarih, bolum_kodu, tur, dk_numara, doviz_kod, aciklama, borc_lc, borc_fc, alacak_lc, alacak_fc, bakiye_lc, bakiye_fc)
        select p_tarih, bolum_kodu, tur, dk_numara, doviz_kod, aciklama,  
        borc_lc,
        borc_fc,
        alacak_lc,
        alacak_fc,
        (bakiye_fc * pkg_tx4050.get_day_currency(p_tarih, CASE WHEN dk_numara in (11519001,11519101, 11520001, 11520101) THEN pkg_genel.lc_al ELSE doviz_kod END)) bakiye_lc, 
        bakiye_fc
        from cbs_rpt_mizan
        where tarih=ld_date;
    
    for cur_row in rf_cur loop
        ln_lc := cur_row.BAKIYE_FC * (pkg_tx4050.get_day_currency(p_tarih, cur_row.doviz_kod) - pkg_tx4050.get_day_currency(ld_date, cur_row.doviz_kod));
        
        update cbs_weekend_rpt_mizan 
        set BAKIYE_FC = decode(dk_numara, 60303000, round(BAKIYE_FC + ln_lc, 2), round(BAKIYE_FC - ln_lc, 2)), 
            BAKIYE_LC = decode(dk_numara, 60303000, round(BAKIYE_LC + ln_lc, 2), round(BAKIYE_LC - ln_lc, 2))
        where bolum_kodu = cur_row.bolum_kodu 
          and tur = cur_row.tur
          and (  (dk_numara = substr(cur_row.dk_numara, 1, 7) || 1 and doviz_kod = cur_row.doviz_kod) 
               or dk_numara = 60303000);
    end loop;

    COMMIT;
    RETURN 'OK';
EXCEPTION 
    WHEN OTHERS THEN
        log_at('RAP01_CALC_ERRROR', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN substr(sqlerrm || ' -- ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 200);
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20100, TO_CHAR(SQLCODE)||' '||TO_CHAR(SQLERRM) || ' ' || substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 2000));
END rap01_calc;

/

