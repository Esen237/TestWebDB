create PACKAGE     PKG_TX8802 IS
/******************************************************************************
   Name       : PKG_Tx8802
   Created By : Hakan SAMSA
   Date          : 25/04/2007
   Purpose      : WORK.BLK
******************************************************************************/
-- TX Event Listesi
  Procedure Kontrol_Sonrasi(pn_islem_no number);        -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);      -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);          -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );    -- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);           -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);       -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);          -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);          -- Isleme iliskin formlar basildiktan sonra cagrilir

  --Procedure Muhasebelesme(pn_islem_no number ,pn_dosya_no number ,ps_file_type varchar2,ps_err out number,ps_error_mesaj out varchar2); --sevalb 26092014 deadlock problemi
  Procedure Muhasebelesme(pn_islem_no number, pn_dosya_no number, ps_file_type varchar2, pn_sira_no number);                     --sevalb 26092014 deadlock problemi

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
END;

/

