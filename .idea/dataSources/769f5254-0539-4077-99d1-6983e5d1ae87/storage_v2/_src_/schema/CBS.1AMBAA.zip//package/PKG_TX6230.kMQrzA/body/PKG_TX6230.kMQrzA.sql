create PACKAGE BODY     "PKG_TX6230" IS
    p_6230_YENI_HESAP_SUBE         NUMBER;
    p_6230_YENI_DK_NO             NUMBER;
    p_6230_ESKI_DK_NO             NUMBER;
    p_6230_BANKA_ACIKLAMA         NUMBER;
    p_6230_ARTI_BAKIYE             NUMBER;
    p_6230_DOVIZ_KODU             NUMBER;
    p_6230_FC_HESAP              NUMBER;
    p_6230_FC_TUTAR                 NUMBER;
    p_6230_ESKI_HESAP_SUBE         NUMBER;
    p_6230_ISTATISTIK_KODU         NUMBER;
    p_6230_KUR                     NUMBER;
    p_6230_LC_HESAP                 NUMBER;
    p_6230_LC_TUTAR                 NUMBER;
    p_6230_EKSI_BAKIYE             NUMBER;
    p_6230_MUSTERI_ACIKLAMA         NUMBER;
    p_6230_MUSTERI_HESAP_NO         NUMBER;
    p_6230_REFERANS                 NUMBER;
    p_6230_SUBE_DEGISTI                NUMBER;

  FUNCTION Modul_Tur_Uygun_mu(ps_modul  VARCHAR2) RETURN VARCHAR2 IS
    ls_sonuc  VARCHAR2(1) ;
  BEGIN

  IF ps_modul IN (Pkg_Hesap.Modul_tur_Vadesiz,Pkg_Hesap.Modul_tur_Vadeli,Pkg_Kredi.modul_tur_kod) THEN
    ls_sonuc := 'E' ;
  ELSE
    ls_sonuc := 'H' ;
  END IF ;

  RETURN  ls_sonuc ;
END;
 --*****************************************************************
  FUNCTION Urun_Tur_Uygun_mu(ps_modul  VARCHAR2,ps_urun  VARCHAR2) RETURN VARCHAR2 IS
    ls_sonuc  VARCHAR2(1) ;
    ln_count NUMBER;        --CQ5261 MederT 18122015
  BEGIN
--BOM CQ5523 MederT 02082016
  /*
  IF ps_modul = Pkg_Hesap.Modul_tur_Vadeli THEN
  
       IF ps_urun IN ('LONG TERM','MEDIUMTERM','OVERNIGHT','SHORT TERM','CRED.CARD+','COLLATERAL') THEN
         ls_sonuc := 'E' ;
     ELSE
         ls_sonuc := 'H' ;
     END IF;

  ELSIF ps_modul = Pkg_Hesap.Modul_tur_Vadesiz THEN
    IF ps_urun IN ('CURRENT','DEMAND DEP','CASH COLL.','COLLATERAL','NOSTRO-FC','NOSTRO-LC') THEN
           ls_sonuc := 'E' ;
    ELSE
        ls_sonuc := 'H' ;
    END IF;

  ELSIF ps_modul = Pkg_Kredi.modul_tur_kod THEN
  --BOM CQ5261 MederT 18122015
  /*
    IF ps_urun IN ('COMMERCIAL','FACTORING','FORFEITING','LEASING','MORTGAGE','PAST DUE','R.EST.CON.',
                   'RT-CARD','RT-FIXRATE','RT-VRRATE','PD-CARD','PD-FIXRATE','PD-VRRATE',
                   'DEPO','PLACEMENT','LOAN GIVEN','LNGV')
    THEN
           ls_sonuc := 'E' ;
    ELSE
        ls_sonuc := 'H' ;
    END IF;
  *-/
  
    SELECT COUNT(*) INTO ln_count FROM cbs_urun_sinif
    WHERE modul_tur_kod = ps_modul AND urun_tur_kod = ps_urun;
    
    IF ln_count > 0 THEN
        ls_sonuc := 'E' ;
    ELSE
        ls_sonuc := 'H' ;
    END IF;
  
  --EOMCQ5261 MederT 18122015
  
  END IF ;
  */
  
  SELECT COUNT(*) INTO ln_count FROM cbs_urun_sinif
    WHERE modul_tur_kod = ps_modul AND urun_tur_kod = ps_urun;
    
    IF ln_count > 0 THEN
        ls_sonuc := 'E' ;
    ELSE
        ls_sonuc := 'H' ;
    END IF;
    
  --EOM CQ5523 MederT 02082016

  RETURN  ls_sonuc ;

END;
 --*****************************************************************
  FUNCTION Urun_Sinif_Uygun_mu(ps_modul  VARCHAR2,ps_urun  VARCHAR2, ps_sinif VARCHAR2) RETURN VARCHAR2 IS
    ls_sonuc  VARCHAR2(1) ;
    ln_count  NUMBER ;
  BEGIN
--BOM CQ5523 MederT 02082016
  /*
  IF ps_modul = Pkg_Hesap.Modul_tur_Vadeli THEN
       IF ps_urun IN ('LONG TERM','MEDIUMTERM','OVERNIGHT','SHORT TERM','CRED.CARD+','COLLATERAL') THEN
         SELECT COUNT(*)
        INTO   ln_count
        FROM   CBS_URUN_SINIF
        WHERE  modul_tur_kod = Pkg_Hesap.Modul_tur_Vadeli
        AND    urun_tur_kod IN ('LONG TERM','MEDIUMTERM','OVERNIGHT','SHORT TERM','CRED.CARD+','COLLATERAL')
        AND    kod = ps_sinif ;

        IF ln_count <> 0 THEN
            ls_sonuc := 'E' ;
        ELSE
           ls_sonuc := 'H' ;
        END IF;

     ELSE
         ls_sonuc := 'H' ;
     END IF;

  ELSIF ps_modul = Pkg_Hesap.Modul_tur_Vadesiz THEN
    IF ps_urun IN ('CURRENT','DEMAND DEP','CASH COLL.','COLLATERAL','NOSTRO-FC','NOSTRO-LC') THEN
         SELECT COUNT(*)
        INTO   ln_count
        FROM   CBS_URUN_SINIF
        WHERE  modul_tur_kod = Pkg_Hesap.Modul_tur_Vadesiz
        AND    urun_tur_kod IN ('CURRENT','DEMAND DEP','CASH COLL.','COLLATERAL','NOSTRO-FC','NOSTRO-LC')
        AND    kod = ps_sinif ;

        IF ln_count <> 0 THEN
            ls_sonuc := 'E' ;
        ELSE
           ls_sonuc := 'H' ;
        END IF;
/*
    ELSIF ps_urun IN ('NAKDITM-TP','NAKDITM-YP') THEN
        IF ps_sinif IN ('KIRALIK KASALAR') THEN
           ls_sonuc := 'E' ;
        ELSE
           ls_sonuc := 'H' ;
        END IF;

    ELSIF ps_urun IN ('NOSTRO-TP','NOSTRO-YP') THEN
        IF ps_sinif IN ('S.OLMAYAN-V.SIZ','SERBEST-V.SIZ') THEN
           ls_sonuc := 'E' ;
        ELSE
           ls_sonuc := 'H' ;
        END IF;
*-/

    ELSE
        ls_sonuc := 'H' ;
    END IF;

  ELSIF ps_modul = Pkg_Kredi.modul_tur_kod THEN
    IF ps_urun IN ('COMMERCIAL','FACTORING','FORFEITING','LEASING','MORTGAGE','PAST DUE','R.EST.CON.',
                   'RT-CARD','RT-FIXRATE','RT-VRRATE','PD-CARD','PD-FIXRATE','PD-VRRATE',
                   'DEPO','PLACEMENT','LOAN GIVEN','LNGV')
    THEN
         SELECT COUNT(*)
        INTO   ln_count
        FROM   CBS_URUN_SINIF
        WHERE  modul_tur_kod = Pkg_Kredi.modul_tur_kod
        AND    urun_tur_kod IN ('COMMERCIAL','FACTORING','FORFEITING','LEASING','MORTGAGE','PAST DUE','R.EST.CON.',
                                'RT-CARD','RT-FIXRATE','RT-VRRATE','PD-CARD','PD-FIXRATE','PD-VRRATE',
                                'DEPO','PLACEMENT','LOAN GIVEN','LNGV')
        AND    kod = ps_sinif ;

        IF ln_count <> 0 THEN
            ls_sonuc := 'E' ;
        ELSE
           ls_sonuc := 'H' ;
        END IF;

    ELSE
        ls_sonuc := 'H' ;
    END IF;

  END IF ;
  */
  
  SELECT COUNT(*)
    INTO   ln_count
    FROM   CBS_URUN_SINIF
    WHERE  modul_tur_kod = ps_modul
    AND    urun_tur_kod = ps_urun
    AND    kod = ps_sinif ;

    IF ln_count <> 0 THEN
        ls_sonuc := 'E' ;
    ELSE
       ls_sonuc := 'H' ;
    END IF;
    --EOM CQ5523 MederT 02082016

  RETURN  ls_sonuc ;

END;
 --*****************************************************************
  FUNCTION Hesap_Ana_DK_al(pn_hesap_no  NUMBER) RETURN VARCHAR2 IS
    ls_sonuc  VARCHAR2(30) ;
  BEGIN

         SELECT musteri_dk_no
        INTO   ls_sonuc
        FROM   CBS_VW_HESAP_IZLEME
        WHERE  hesap_no = pn_hesap_no ;

  RETURN  ls_sonuc ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN  NULL;
  END;
------------------------------------------------------------------------------------------
--BOM aisuluud cq5721
  FUNCTION get_interest_gl(pn_hesap_no  NUMBER) RETURN VARCHAR2 IS
    ls_modul_tur_kod  VARCHAR2(30) ;
    ls_urun_tur_kod  VARCHAR2(30) ;
    ls_urun_sinif_kod  VARCHAR2(30) ;
    ln_dk_grup_kod  number ;
    ls_gl_interest VARCHAR2(30) ;
    ls_PASTDUE_FAIZ_ANAPARA_SEC VARCHAR2 (20);
    
     --b-o-m seval.colak 16022023
ls_ana_modul_tur_kod    varchar2(100) ;
ls_ana_urun_tur_kod varchar2(100) ; 
ls_ana_urun_sinif_kod varchar2(100) ;
ls_musteri_accrual_tax_dk_no    varchar2(100) ;
ls_nonaccrual_int_dk_no          varchar2(100) ;
ln_accrual_ana_hesap_no     number ;
 --e-o-m seval.colak 16022023
  BEGIN

        SELECT i.modul_tur_kod, i.urun_tur_kod, i.urun_sinif_kod, i.dk_grup_kod, (select k.pastdue_faiz_anapara_sec 
                                                                                  from cbs_hesap_kredi k
                                                                                 where k.hesap_no=i.hesap_no  ) pastdue_faiz_anapara_sec, -- seval.colak 16022023  aisuluud cq5721   left outer yerine subquery
                                                                                 accrual_ana_hesap_no        
        INTO   ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_dk_grup_kod, ls_pastdue_faiz_anapara_sec ,ln_accrual_ana_hesap_no
        FROM   CBS_VW_HESAP_IZLEME i
        WHERE  i.hesap_no = pn_hesap_no;
        
        --b-o-m seval.colak 16022023
          if ls_urun_tur_kod in ('ACCRUAL','NONACCRUAL') and nvl(ln_accrual_ana_hesap_no,0) <> 0  then  --
          
                pkg_parametre.deger('G_DK_NONACCRUAL_INT_DEBIT', ls_nonaccrual_int_dk_no);
                pkg_parametre.deger('G_DK_ACCRUAL_TAX_RECEIVAL', ls_musteri_accrual_tax_dk_no); --seval.colak 16022023
                
                select modul_tur_kod,urun_tur_kod,urun_sinif_kod
                into  ls_ana_modul_tur_kod,ls_ana_urun_tur_kod,ls_ana_urun_sinif_kod
                from cbs_vw_hesap_izleme i
                where hesap_no=ln_accrual_ana_hesap_no ;      
                 
                begin
                 select  case when ls_pastdue_faiz_anapara_sec  = 'ACCRUAL-DELAYED-INTEREST' then dk_hesabi_11
                              when  ls_pastdue_faiz_anapara_sec = 'ACCRUAL-TAX'              then ls_musteri_accrual_tax_dk_no
                              when  ls_pastdue_faiz_anapara_sec  in ('NONACCRUAL-INTEREST','NONACCRUAL-DELAYED-INTEREST') then  ls_nonaccrual_int_dk_no 
                              else  dk_hesabi_4 end
                 into ls_gl_interest    
                 from cbs_grup_urun_sinif 
                 where grup_kod = ln_dk_grup_kod
                        and modul_tur_kod = ls_ana_modul_tur_kod
                        and urun_tur_kod  =  ls_ana_urun_tur_kod
                        and urun_sinif_kod = ls_ana_urun_sinif_kod;
                   exception when others then null;
                 end;       
        -- e-o-m seval.colak seval.colak 16022023        
        
        else
            if ls_PASTDUE_FAIZ_ANAPARA_SEC is null or ls_PASTDUE_FAIZ_ANAPARA_SEC='ANAPARA' then
        
                select 
                case when modul_tur_kod = 'CURRENT' then dk_hesabi_8
                else case when modul_tur_kod = 'TIME DEP.' then dk_hesabi_4
                else case when modul_tur_kod = 'LOAN' then dk_hesabi_4
                end end end gl_interest
                into ls_gl_interest
                from CBS_GRUP_URUN_SINIF 
                where modul_tur_kod = ls_modul_tur_kod and
                urun_tur_kod = ls_urun_tur_kod and
                urun_sinif_kod = ls_urun_sinif_kod and 
                grup_kod = ln_dk_grup_kod;
              end if;
      END IF;

  RETURN  ls_gl_interest ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN  NULL;
  END;
  --EOM aisuluud cq5721

  --BOM aisuluud cq5721
  FUNCTION get_loan_pastdue_type(pn_hesap_no  NUMBER) RETURN VARCHAR2 IS
    ls_PASTDUE_FAIZ_ANAPARA_SEC VARCHAR2 (20);
  BEGIN
        
        SELECT HK.PASTDUE_FAIZ_ANAPARA_SEC 
        INTO   ls_PASTDUE_FAIZ_ANAPARA_SEC
        FROM cbs_hesap_kredi hk
        WHERE  hk.hesap_no = pn_hesap_no;


  RETURN  ls_PASTDUE_FAIZ_ANAPARA_SEC ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN  NULL;
  END;
  --EOM aisuluud cq5721
PROCEDURE Hata_Kontrolleri(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MUSTERI_NO, HESAP_NO,
           SUBE_KODU, MUSTERI_DK_NO, YENI_URUN_TUR_KOD, YENI_URUN_SINIF_KOD, YENI_SUBE_KODU,
           YENI_MUSTERI_DK_NO, DURUM_KODU, ISLEM_TARIHI, YARATAN_KULLANICI
    FROM   CBS_HESAP_URUN_SUBE_DEGISIKLIK
    WHERE  tx_no       = pn_islem_no 
     and urun_Tur_kod not in('ACCRUAL','NONACCRUAL'); -- seval.colak 16022023  accrual,nonaccrual kontrollere girmesin.

    r_islem  c_islem%ROWTYPE;
    ln_mus_count               NUMBER;
    ls_hata                    VARCHAR2(2000);
    ls_ana_dk_no               VARCHAR2(2000);
    ls_2_dk_no                 VARCHAR2(2000);
    ls_3_dk_no                 VARCHAR2(2000);
    ls_4_dk_no                 VARCHAR2(2000);
    ls_5_dk_no                 VARCHAR2(2000);
    ls_6_dk_no                 VARCHAR2(2000);
    ls_8_dk_no                 VARCHAR2(2000);--aisuluud cq5721
    ln_sube_count              NUMBER;
    ln_2_dk_count             NUMBER;
    ln_3_dk_count             NUMBER;
    ln_4_dk_count             NUMBER;
    ln_5_dk_count             NUMBER;
    ln_6_dk_count             NUMBER;
    ln_8_dk_count             NUMBER; --aisuluud cq5721
    ln_FAIZ_ORANI               NUMBER;
    ln_BIRIKMIS_FAIZ_POZ       NUMBER;
    ln_KOMISYON_ORANI           NUMBER;
    ln_BIRIKMIS_KOMISYON       NUMBER;
    LN_OVD_TOTAL_ACC_INTEREST  NUMBER; --AISULUUD CQ5721
    ln_GECMIS_AYLARIN_FAIZI number; --AISULUUD CQ5721
    ln_GECEN_YIL_FAIZ_TOPLAMI number; --AISULUUD CQ5721
    ln_GECENYIL_FAIZ_TUTARI number; --AISULUUD CQ5721

BEGIN
    DELETE FROM  CBS_HESAP_URUN_SUBE_DEG_HATA
    WHERE tx_no = pn_islem_no ;

    OPEN c_islem;
    FETCH c_islem INTO r_islem;
    CLOSE c_islem ;

--1.hata kontrolu
    SELECT COUNT(*)
    INTO   ln_mus_count
    FROM   CBS_GRUP_URUN_SINIF
    WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
    AND    modul_tur_kod  = r_islem.modul_tur_kod
    AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
    AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

    IF ln_mus_count  = 0 THEN
        ls_hata := 'Module : ' || r_islem.modul_tur_kod ||  ', Product Type : ' ||
                   r_islem.yeni_urun_tur_kod || ', Product Class : ' ||
                   r_islem.yeni_urun_sinif_kod     ||  ', ' ||
                   ' not defined under GL Group Code : ' ||
                   Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no));

        INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
        (pn_islem_no , ls_hata) ;
    END IF;

--2.hata kontrolu
    SELECT NVL(DK_HESABI_1,0)
    INTO   ls_ana_dk_no
    FROM   CBS_GRUP_URUN_SINIF
    WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
    AND    modul_tur_kod  = r_islem.modul_tur_kod
    AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
    AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

    IF ls_ana_dk_no  = 0 THEN
        ls_hata := ' Main GL No not defined under : ' ||
                   'Module : ' || r_islem.modul_tur_kod ||
                   ', Prouct Type : ' || r_islem.yeni_urun_tur_kod ||
                   ', Product Class : ' || r_islem.yeni_urun_sinif_kod     ||  ', ' ||
                   ', GL Group Code : ' || Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no));

        INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
        (pn_islem_no , ls_hata) ;
    END IF;

--3.hata kontrolu
    -- sube degismis ise...
    IF r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0 THEN
           IF r_islem.musteri_dk_no <> r_islem.yeni_musteri_dk_no THEN

            SELECT COUNT(*)
            INTO   ln_sube_count
            FROM   CBS_DKHESAP
            WHERE  numara     = r_islem.yeni_musteri_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = NVL(r_islem.yeni_sube_kodu,r_islem.sube_kodu) ;

            IF ln_sube_count  = 0 THEN
                ls_hata :=  'GL No: '||r_islem.yeni_musteri_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;
        END IF;

    END IF;
--4.hata kontrolu
    -- vadesiz ise...
    IF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz THEN
      SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_POZ,0), NVL(OVD_TOTAL_ACC_INTEREST,0) --AISULUUD CQ5721 ADDED NVL(OVD_TOTAL_ACC_INTEREST,0)
      INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ, LN_OVD_TOTAL_ACC_INTEREST --AISULUUD CQ5721 ADDED LN_OVD_TOTAL_ACC_INTEREST
      FROM   CBS_HESAP
      WHERE  hesap_no = r_islem.hesap_no ;

      IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN
            SELECT NVL(DK_HESABI_3,0)
            INTO   ls_3_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

/*
            SELECT COUNT(*)
            INTO   ln_3_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_3_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_3_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_3_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;


                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

*/
            SELECT COUNT(*)
            INTO   ln_3_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_3_dk_no
            AND    doviz_kod  = Pkg_Genel.lc_al
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_3_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_3_dk_no || ' not defined with Currency Code : '||
                            Pkg_Genel.lc_al||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;


                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

            SELECT NVL(DK_HESABI_4,0)
            INTO   ls_4_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

            SELECT COUNT(*)
            INTO   ln_4_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_4_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_4_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_4_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;


                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

      END IF;
      
      --BOM AISULUUD CQ5721
          IF
          LN_OVD_TOTAL_ACC_INTEREST <>0 THEN
          SELECT NVL(DK_HESABI_8,0)
                INTO   ls_8_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_8_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_8_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_8_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_8_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;


                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
                END IF;
          
          END IF;
          --EOM AISULUUD CQ5721
    END IF; -- hesap vadesi ise

--5.hata kontrolu
    -- vadeli ise...
    IF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli THEN
      SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_POZ,0), nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECEN_YIL_FAIZ_TOPLAMI,0) --aisuluud cq5721 added nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECEN_YIL_FAIZ_TOPLAMI,0)
      INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ, ln_GECMIS_AYLARIN_FAIZI, ln_GECEN_YIL_FAIZ_TOPLAMI --aisuluud  cq5721 added ln_GECMIS_AYLARIN_FAIZI, ln_GECEN_YIL_FAIZ_TOPLAMI
      FROM   CBS_HESAP_VADELI
      WHERE  hesap_no = r_islem.hesap_no ;

      IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN

            SELECT NVL(DK_HESABI_3,0)
            INTO   ls_3_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

/*
            SELECT COUNT(*)
            INTO   ln_3_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_3_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_3_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_3_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;
*/

            SELECT COUNT(*)
            INTO   ln_3_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_3_dk_no
            AND    doviz_kod  = Pkg_Genel.lc_al
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_3_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_3_dk_no || ' not defined with Currency Code : '||
                            Pkg_Genel.lc_al||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

            SELECT NVL(DK_HESABI_4,0)
            INTO   ls_4_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

            SELECT COUNT(*)
            INTO   ln_4_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_4_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_4_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_4_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

      END IF;
      
      --bom aisuluud cq5721
          if nvl(ln_GECMIS_AYLARIN_FAIZI,0) <>0 or nvl(ln_GECEN_YIL_FAIZ_TOPLAMI,0)<>0 then
          
          SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_4_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
                END IF;
          
          end if;
          --eom aisuluud cq5721
    END IF; -- hesap vadeli ise

--6.hata kontrolu
    -- kredi ise...
    IF r_islem.modul_tur_kod = Pkg_Kredi.modul_tur_kod THEN
      SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_TUTARI,0),NVL(KOMISYON_ORANI,0), NVL(BIRIKMIS_KOMISYON_TUTARI,0), nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECENYIL_FAIZ_TUTARI,0)  --aisuluud cq5721 added nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECENYIL_FAIZ_TUTARI,0)
      INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ,ln_KOMISYON_ORANI , ln_BIRIKMIS_KOMISYON, ln_GECMIS_AYLARIN_FAIZI, ln_GECENYIL_FAIZ_TUTARI  --aisuluud cq5721 added ln_GECMIS_AYLARIN_FAIZI, ln_GECENYIL_FAIZ_TUTARI
      FROM   CBS_HESAP_KREDI
      WHERE  hesap_no = r_islem.hesap_no ;

      IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN

            SELECT NVL(DK_HESABI_2,0)
            INTO   ls_2_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

/*
            SELECT COUNT(*)
            INTO   ln_2_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_2_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_2_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_2_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;
*/
            SELECT COUNT(*)
            INTO   ln_2_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_2_dk_no
            AND    doviz_kod  = Pkg_Genel.lc_al
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_2_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_2_dk_no || ' not defined with Currency Code : '||
                            Pkg_Genel.lc_al||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

            SELECT NVL(DK_HESABI_4,0)
            INTO   ls_4_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

            SELECT COUNT(*)
            INTO   ln_4_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_4_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_4_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_4_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

      END IF;

      IF ln_KOMISYON_ORANI <> 0 OR ln_BIRIKMIS_KOMISYON <> 0 THEN

            SELECT NVL(DK_HESABI_5,0)
            INTO   ls_5_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

/*
            SELECT COUNT(*)
            INTO   ln_5_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_5_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_5_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_5_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;
*/
            SELECT COUNT(*)
            INTO   ln_5_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_5_dk_no
            AND    doviz_kod  = Pkg_Genel.lc_al
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_5_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_5_dk_no || ' not defined with Currency Code : '||
                            Pkg_Genel.lc_al||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

            SELECT NVL(DK_HESABI_6,0)
            INTO   ls_6_dk_no
            FROM   CBS_GRUP_URUN_SINIF
            WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
            AND    modul_tur_kod  = r_islem.modul_tur_kod
            AND    urun_tur_kod   = r_islem.yeni_urun_tur_kod
            AND    urun_sinif_kod = r_islem.yeni_urun_sinif_kod     ;

            SELECT COUNT(*)
            INTO   ln_6_dk_count
            FROM   CBS_DKHESAP
            WHERE  numara     = ls_6_dk_no
            AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
            AND    bolum_kodu = r_islem.yeni_sube_kodu ;

            IF ln_6_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_6_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;
      END IF;
      
      --bom aisuluud cq5721
          if  (nvl(ln_GECMIS_AYLARIN_FAIZI,0)<>0 or nvl(ln_GECENYIL_FAIZ_TUTARI,0)<>0) then
          SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(r_islem.hesap_no))
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                ls_hata :=  'GL No: '||ls_4_dk_no || ' not defined with Currency Code : '||
                            Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)||
                            ' in the branch : ' ||r_islem.yeni_sube_kodu ;

                INSERT INTO CBS_HESAP_URUN_SUBE_DEG_HATA (TX_NO,HATA) VALUES
                (pn_islem_no , ls_hata) ;
            END IF;

         end if;
          --eom aisuluud cq5721
    END IF; -- hesap kredi ise
  END;
------------------------------------------------------------------------------------------
 --*****************************************************************
  FUNCTION Hesap_Kredi_Teklif_Satirno_al(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_sonuc  NUMBER ;
  BEGIN

         SELECT KREDI_TEKLIF_SATIR_NO
        INTO   ln_sonuc
        FROM   CBS_VW_HESAP_IZLEME
        WHERE  hesap_no = pn_hesap_no ;

  RETURN  ln_sonuc ;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN  NULL;

  END;

 --*****************************************************************
  FUNCTION Hesap_urun_grup_no_al(pn_teklif_satir_no  NUMBER) RETURN NUMBER IS
    ln_sonuc  NUMBER ;
  BEGIN

        SELECT kredi_turu
        INTO   ln_sonuc
        FROM   cbs_vw_aktif_kredi_teklif
        WHERE  teklif_satir_no = pn_teklif_satir_no ;


  RETURN  ln_sonuc ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN NULL;
  END;

 --*****************************************************************
  FUNCTION Faiz_Tahakkuk_Hesap_No_al(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_FAIZ_TAHAKKUK_HESAP_NO NUMBER ;
  BEGIN

        SELECT FAIZ_TAHAKKUK_HESAP_NO
        INTO   ln_FAIZ_TAHAKKUK_HESAP_NO
        FROM   CBS_HESAP_KREDI
        WHERE  hesap_no = pn_hesap_no ;


        RETURN  ln_FAIZ_TAHAKKUK_HESAP_NO ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN NULL;
  END;

 --*****************************************************************
  FUNCTION Vergi_Tahakkuk_Hesap_No_al(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_VERGI_TAHAKKUK_HESAP_NO NUMBER ;
  BEGIN

        SELECT VERGI_TAHAKKUK_HESAP_NO
        INTO   ln_VERGI_TAHAKKUK_HESAP_NO
        FROM   CBS_HESAP_KREDI
        WHERE  hesap_no = pn_hesap_no ;


        RETURN  ln_VERGI_TAHAKKUK_HESAP_NO ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN NULL;
  END;

 --*****************************************************************

PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER) IS
  BEGIN
    NULL;
  END;
--*************************************************************************************--
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MUSTERI_NO, HESAP_NO,
           SUBE_KODU, MUSTERI_DK_NO, YENI_URUN_TUR_KOD, YENI_URUN_SINIF_KOD, YENI_SUBE_KODU,
           YENI_MUSTERI_DK_NO, DURUM_KODU, ISLEM_TARIHI, YARATAN_KULLANICI
    FROM   CBS_HESAP_URUN_SUBE_DEGISIKLIK
    WHERE  tx_no       = pn_islem_no ;

    r_islem  c_islem%ROWTYPE;
    ln_hata_sayi NUMBER;
    ln_sonuc       NUMBER;

  BEGIN
   OPEN c_islem;
   LOOP
        FETCH c_islem INTO r_islem;
        EXIT WHEN c_islem%NOTFOUND;

        IF r_islem.hesap_no IS NOT NULL THEN
              ln_sonuc := Pkg_Tx6230.Bitmemis_islem_var_mi(r_islem.hesap_no);
            IF ln_sonuc =  pn_islem_no  THEN
              ln_sonuc := 0; -- kendi islemini saymasin
            END IF;

            IF ln_sonuc > 0 THEN
                RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '429' || Pkg_Hata.getDelimiter || ln_sonuc ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
            END IF;
        END IF;

        -- 3 bilgiden biri mutlaka degistirilmis olmali
        IF r_islem.YENI_URUN_TUR_KOD = r_islem.URUN_TUR_KOD AND  r_islem.YENI_URUN_SINIF_KOD = r_islem.URUN_SINIF_KOD
           AND  NVL(r_islem.YENI_SUBE_KODU,0) = 0 THEN

           RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5154' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

        END IF;

   END LOOP ;

   CLOSE c_islem;

   SELECT COUNT(*)
   INTO   ln_hata_sayi
   FROM   CBS_HESAP_URUN_SUBE_DEG_HATA
   WHERE  tx_no = pn_islem_no ;

   IF ln_hata_sayi > 0 THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5155' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END IF;

  END;
--*************************************************************************************--
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
         NULL;
  END;
--*************************************************************************************--
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MUSTERI_NO, HESAP_NO,
           SUBE_KODU, MUSTERI_DK_NO, YENI_URUN_TUR_KOD, YENI_URUN_SINIF_KOD, YENI_SUBE_KODU,
           YENI_MUSTERI_DK_NO, DURUM_KODU, ISLEM_TARIHI, YARATAN_KULLANICI,TEKLIF_SATIR_NO, URUN_GRUP_NO,
           YENI_TEKLIF_SATIR_NO, YENI_URUN_GRUP_NO,DOVIZ_KODU, MUSTERI_BOLUM_KODU_DEG
    FROM   CBS_HESAP_URUN_SUBE_DEGISIKLIK
    WHERE  tx_no       = pn_islem_no ;

    r_islem  c_islem%ROWTYPE;

    ls_sube            VARCHAR2(10);
    ln_Hesap_BDAK        NUMBER;
    ln_EskiSatir_BDAK  NUMBER;
    ln_YeniSatir_BDAK  NUMBER;
    ln_azalan_FC_Risk  NUMBER;
    ln_azalan_LC_Risk  NUMBER;
    ln_artan_FC_Risk   NUMBER;
    ln_artan_LC_Risk   NUMBER;
    ls_TeklifSatir_Doviz VARCHAR2(3);
    ls_hesap_doviz         VARCHAR2(3);
    ln_hesap_bakiye      NUMBER;
    ln_fc_limit            NUMBER;
    ln_cnt                 number;
  BEGIN
   OPEN c_islem;
   LOOP
        FETCH c_islem INTO r_islem;
        EXIT WHEN c_islem%NOTFOUND;

        IF r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0 THEN
            ls_sube := r_islem.yeni_sube_kodu ;
        ELSE
            ls_sube := r_islem.sube_kodu ;
        END IF;
        IF NVL(r_islem.musteri_bolum_kodu_deg ,'H')='E' THEN
           UPDATE CBS_MUSTERI
           SET bolum_kodu = r_islem.yeni_sube_kodu
           WHERE musteri_no=r_islem.musteri_no;
        END IF;
        IF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz THEN
           UPDATE CBS_HESAP
           SET    sube_kodu       = ls_sube ,
                     urun_tur_kod    = r_islem.yeni_urun_tur_kod,
                  urun_sinif_kod  = r_islem.yeni_urun_sinif_kod,
                  musteri_dk_no   = r_islem.yeni_musteri_dk_no
           WHERE  hesap_no          = r_islem.HESAP_NO;

        ELSIF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli THEN
           UPDATE CBS_HESAP_VADELI
           SET    sube_kodu       = ls_sube ,
                     urun_tur_kod    = r_islem.yeni_urun_tur_kod,
                  urun_sinif_kod  = r_islem.yeni_urun_sinif_kod,
                  musteri_dk_no   = r_islem.yeni_musteri_dk_no
           WHERE  hesap_no          = r_islem.HESAP_NO;

        ELSIF r_islem.modul_tur_kod = Pkg_Kredi.modul_tur_kod THEN

           UPDATE CBS_HESAP_KREDI
           SET    sube_kodu                 = ls_sube ,
                     urun_tur_kod            = r_islem.yeni_urun_tur_kod,
                  urun_sinif_kod          = r_islem.yeni_urun_sinif_kod,
                  musteri_dk_no           = r_islem.yeni_musteri_dk_no,
                  kredi_teklif_satir_numara = r_islem.yeni_teklif_satir_no,
                  urun_grup_no            = r_islem.yeni_urun_grup_no
           WHERE  hesap_no                = r_islem.HESAP_NO;

           select count(*)
           into ln_cnt
           from cbs_hazine_verilendepo
           where BANKA_HESAP_NO = r_islem.HESAP_NO;

           if ln_cnt > 0
           then
                  update cbs_hazine_verilendepo
               SET BOLUM_KODU = ls_sube
               where BANKA_HESAP_NO = r_islem.HESAP_NO;
           end if;

           -- Eger kredi teklif satir no degismis ise limitleri duzenlemek lazim.
           IF  r_islem.teklif_satir_no <> r_islem.yeni_teklif_satir_no THEN

                 UPDATE CBS_TEMINAT
                SET    KREDI_TEKLIF_SATIR_NO = r_islem.yeni_teklif_satir_no
                WHERE  TEMINAT_HESAP_NO      = r_islem.HESAP_NO;

               ls_hesap_doviz  := r_islem.doviz_kodu;
               ln_hesap_bakiye := Pkg_Hesap.HesapBakiyeAl(r_islem.hesap_no);

               ln_hesap_bakiye := (-1) * ln_hesap_bakiye;

                -- once eski teklif satira ait riskleri azalt
                SELECT doviz_kodu
                INTO   ls_TeklifSatir_Doviz
                FROM   CBS_KREDI_TEKLIF a,
                       CBS_KREDI_TEKLIF_SATIR b,
                       CBS_MUSTERI_URUN_LIMIT c
                WHERE  a.teklif_no = b.teklif_no AND
                       a.durum_kodu = 'A' AND
                       B.teklif_Satir_no = c.kredi_teklif_satir_numara AND
                       b.kredi_turu = C.urun_grub_no AND
                       a.musteri_no = c.musteri_no AND
                       b.TEKLIF_SATIR_NO    = r_islem.teklif_satir_no  AND
                       a.musteri_no = r_islem.musteri_no ;

                ln_Hesap_BDAK       := Pkg_Kur.doviz_doviz_karsilik(ls_hesap_doviz ,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A') ;
                   ln_EskiSatir_BDAK := Pkg_Kur.doviz_doviz_karsilik(ls_TeklifSatir_Doviz ,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A') ;

                ln_azalan_FC_Risk := (ln_hesap_bakiye * ln_Hesap_BDAK) / ln_EskiSatir_BDAK ;
                ln_azalan_FC_Risk := Pkg_Kredi.sf_teklifsatir_riskyp(r_islem.teklif_satir_no) - ln_azalan_FC_Risk ;

                ln_azalan_LC_Risk := (ln_hesap_bakiye * ln_Hesap_BDAK) ;
                ln_azalan_LC_Risk := Pkg_Kredi.sf_teklifsatir_risktl(r_islem.teklif_satir_no) - ln_azalan_LC_Risk ;


                UPDATE CBS_MUSTERI_URUN_LIMIT
                SET    fc_risk = ln_azalan_FC_Risk ,
                       lc_risk = ln_azalan_LC_Risk
                WHERE  musteri_no = r_islem.musteri_no
                AND    kredi_teklif_satir_numara =   r_islem.teklif_satir_no ;


                -- sonra yeni teklif satira ait riskleri arttir
                SELECT b.doviz_kodu, c.fc_limit
                INTO   ls_TeklifSatir_Doviz, ln_fc_limit
                FROM   CBS_KREDI_TEKLIF a,
                       CBS_KREDI_TEKLIF_SATIR b,
                       CBS_MUSTERI_URUN_LIMIT c
                WHERE  a.teklif_no = b.teklif_no AND
                       a.durum_kodu = 'A' AND
                       B.teklif_Satir_no = c.kredi_teklif_satir_numara AND
                       b.kredi_turu = C.urun_grub_no AND
                       a.musteri_no = c.musteri_no AND
                       b.TEKLIF_SATIR_NO    = r_islem.yeni_teklif_satir_no  AND
                       a.musteri_no = r_islem.musteri_no ;

                ln_Hesap_BDAK       := Pkg_Kur.doviz_doviz_karsilik(ls_hesap_doviz ,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A') ;
                   ln_yeniSatir_BDAK := Pkg_Kur.doviz_doviz_karsilik(ls_TeklifSatir_Doviz ,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A') ;

                ln_artan_FC_Risk := (ln_hesap_bakiye * ln_Hesap_BDAK) / ln_yeniSatir_BDAK ;
                ln_artan_FC_Risk := Pkg_Kredi.sf_teklifsatir_riskyp(r_islem.yeni_teklif_satir_no) + ln_artan_FC_Risk ;

                ln_artan_LC_Risk := (ln_hesap_bakiye * ln_Hesap_BDAK) ;
                ln_artan_LC_Risk := Pkg_Kredi.sf_teklifsatir_risktl(r_islem.yeni_teklif_satir_no) + ln_artan_LC_Risk ;

                -- Eger arttirim sonu?cu yeni teklif satirin Fc risk tutari , satirin FC limit Tutarini asiyorsa uyari ver
                IF  ln_artan_FC_Risk  > ln_fc_limit THEN
                    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5171' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
                ELSE

                    UPDATE CBS_MUSTERI_URUN_LIMIT
                    SET    fc_risk = ln_artan_FC_Risk ,
                           lc_risk = ln_artan_LC_Risk
                    WHERE  musteri_no = r_islem.musteri_no
                    AND    kredi_teklif_satir_numara =   r_islem.yeni_teklif_satir_no ;
                END IF;

            END IF; -- teklif satir no

        END IF; -- modul tur

   END LOOP ;

   CLOSE c_islem;

   EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4534' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

--*************************************************************************************
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
     NULL;
  END;
--*************************************************************************************--
  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MUSTERI_NO, HESAP_NO,
           SUBE_KODU, MUSTERI_DK_NO, YENI_URUN_TUR_KOD, YENI_URUN_SINIF_KOD, YENI_SUBE_KODU,
           YENI_MUSTERI_DK_NO, DURUM_KODU, ISLEM_TARIHI, YARATAN_KULLANICI,
           DOVIZ_KODU, TEKLIF_SATIR_NO, URUN_GRUP_NO, YENI_TEKLIF_SATIR_NO, YENI_URUN_GRUP_NO,
           NEW_DK_NO_INTEREST, DK_NO_INTEREST --aisuluud CQ5721 added NEW_DK_NO_INTEREST, DK_NO_INTEREST
    FROM   CBS_HESAP_URUN_SUBE_DEGISIKLIK
    WHERE  tx_no       = pn_islem_no ;

    r_islem  c_islem%ROWTYPE;

    ls_sube         VARCHAR2(10);

   varchar_list              Pkg_Muhasebe.varchar_array;
   number_list              Pkg_Muhasebe.number_array;
   date_list              Pkg_Muhasebe.date_array;
   boolean_list              Pkg_Muhasebe.boolean_array;
   ln_fis_no              NUMBER;
   ls_aciklama            VARCHAR2(2000);
   ln_temp                  NUMBER;
   ls_doviz_kodu          VARCHAR2(3);
   ln_gecmis_aylarin_faizi NUMBER; --aisuluud cq5721
   ln_GecenYilFaizToplami number; --aisuluud cq5721
   ln_ovd_total_acc_interest number; --aisuluud cq5721
   ln_interest number; --aisuluud cq5721

  BEGIN

    ln_fis_no := 0;

    varchar_list(p_6230_YENI_HESAP_SUBE)      := '';
    varchar_list(p_6230_ESKI_HESAP_SUBE)      := '';
    varchar_list(p_6230_YENI_DK_NO)             := '';
    varchar_list(p_6230_ESKI_DK_NO)             := '';
    varchar_list(p_6230_BANKA_ACIKLAMA)         := '';
    varchar_list(p_6230_MUSTERI_ACIKLAMA)      := '';
    varchar_list(p_6230_DOVIZ_KODU)             := '';
    varchar_list(p_6230_ISTATISTIK_KODU)      := '';
    varchar_list(p_6230_MUSTERI_HESAP_NO)      := '';
    varchar_list(p_6230_REFERANS)              := '';
    boolean_list(p_6230_ARTI_BAKIYE)         := FALSE;
    boolean_list(p_6230_EKSI_BAKIYE)         := FALSE;
    boolean_list(p_6230_FC_HESAP)              := FALSE;
    boolean_list(p_6230_LC_HESAP)              := FALSE;
    number_list(p_6230_KUR)                   := 1;
    number_list(p_6230_LC_TUTAR)               := 0;
    number_list(p_6230_FC_TUTAR)               := 0;

    boolean_list(p_6230_SUBE_DEGISTI)             := FALSE;


   OPEN c_islem;
   FETCH c_islem INTO r_islem;
   CLOSE c_islem;
   
   --bom aisuluud cq5721
            
            if r_islem.modul_tur_kod in ('TIME DEP.','LOAN') then
                ln_gecmis_aylarin_faizi := Pkg_Hesap.Gecmis_Aylarin_Faizi(r_islem.hesap_no);            
                ln_gecenyilfaiztoplami := pkg_hesap.GecenYilFaizToplami(r_islem.hesap_no); 
            end if;
            
            if r_islem.modul_tur_kod = 'CURRENT' then
                select OVD_TOTAL_ACC_INTEREST
                into ln_ovd_total_acc_interest
                from cbs_hesap 
                where hesap_no=r_islem.hesap_no;
            end if;
            
            select 
                CASE WHEN r_islem.modul_tur_kod = 'CURRENT' THEN
                ln_ovd_total_acc_interest
                ELSE CASE WHEN r_islem.modul_tur_kod = 'TIME DEP.' THEN
                nvl(ln_gecmis_aylarin_faizi,0)+nvl(ln_gecenyilfaiztoplami,0)
                ELSE CASE WHEN r_islem.modul_tur_kod = 'LOAN' THEN
                nvl(ln_gecmis_aylarin_faizi,0)+nvl(ln_gecenyilfaiztoplami,0)
                END END END 
            into ln_interest
            from dual;
            
            --eom aisuluud cq5721

   IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)
       OR r_islem.musteri_dk_no <> r_islem.yeni_musteri_dk_no THEN

       ls_doviz_kodu := Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ;

          IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)  THEN
            varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.yeni_sube_kodu ;
            varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
            boolean_list(p_6230_SUBE_DEGISTI)          := TRUE;
       ELSE
            varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.sube_kodu ;
            varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
            boolean_list(p_6230_SUBE_DEGISTI)          := FALSE;
       END IF;

       IF r_islem.musteri_dk_no <> r_islem.yeni_musteri_dk_no THEN
        varchar_list(p_6230_YENI_DK_NO)             := r_islem.yeni_musteri_dk_no  ;
        varchar_list(p_6230_ESKI_DK_NO)             := r_islem.musteri_dk_no;
       ELSE
        varchar_list(p_6230_YENI_DK_NO)             := r_islem.musteri_dk_no;
        varchar_list(p_6230_ESKI_DK_NO)             := r_islem.musteri_dk_no;
       END IF;

        varchar_list(p_6230_BANKA_ACIKLAMA)         := r_islem.hesap_no || ' Product / Branch Modification';
        varchar_list(p_6230_MUSTERI_ACIKLAMA)      := r_islem.hesap_no || ' Product / Branch Modification';
        varchar_list(p_6230_DOVIZ_KODU)             := ls_doviz_kodu;
        varchar_list(p_6230_ISTATISTIK_KODU)      := '';
        varchar_list(p_6230_MUSTERI_HESAP_NO)      := '';
        varchar_list(p_6230_REFERANS)              := r_islem.hesap_no;--r_islem.tx_no;


        number_list(p_6230_KUR)                   := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A')  ;
        number_list(p_6230_LC_TUTAR)               := ABS(Pkg_Kur.yuvarla(ls_doviz_kodu, Pkg_Hesap.HesapBakiyeAl(r_islem.hesap_no) * number_list(p_6230_KUR))) ;
        number_list(p_6230_FC_TUTAR)               := ABS(Pkg_Hesap.HesapBakiyeAl(r_islem.hesap_no));

        IF ls_doviz_kodu = Pkg_Genel.lc_al THEN
            boolean_list(p_6230_LC_HESAP)     := TRUE;
            boolean_list(p_6230_FC_HESAP)     := FALSE;
        ELSE
            boolean_list(p_6230_LC_HESAP)     := FALSE;
            boolean_list(p_6230_FC_HESAP)     := TRUE;
        END IF;

        IF Pkg_Hesap.HesapBakiyeAl(r_islem.hesap_no) < 0 THEN
            boolean_list(p_6230_ARTI_BAKIYE)         := FALSE;
            boolean_list(p_6230_EKSI_BAKIYE)         := TRUE;
        ELSE
            boolean_list(p_6230_ARTI_BAKIYE)         := TRUE;
            boolean_list(p_6230_EKSI_BAKIYE)         := FALSE;
        END IF;

        --Bakiye yoksa hic fis kesme
        IF number_list(p_6230_FC_TUTAR) <> 0 THEN
            ln_fis_no:=Pkg_Muhasebe.fis_kes ( 6230,
                                                     NULL,
                                                     pn_islem_no,
                                                    varchar_list ,
                                                    number_list  ,
                                                    date_list    ,
                                                    boolean_list ,
                                                    NULL,
                                                   FALSE,
                                                    ln_fis_no,
                                                    NULL);

             Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
        END IF;

   END IF;
   
   --BOM aisuluud cq5721
   if nvl(ln_interest,0)>0 and r_islem.modul_tur_kod in ('LOAN','CURRENT') then
   
    
   
       IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)
           OR r_islem.dk_no_interest <> r_islem.new_dk_no_interest THEN 

           ls_doviz_kodu := Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ;

              IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)  THEN
                varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.yeni_sube_kodu ;
                varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
                boolean_list(p_6230_SUBE_DEGISTI)          := TRUE;
           ELSE
                varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.sube_kodu ;
                varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
                boolean_list(p_6230_SUBE_DEGISTI)          := FALSE;
           END IF;

           IF r_islem.dk_no_interest <> r_islem.new_dk_no_interest THEN
            varchar_list(p_6230_YENI_DK_NO)             := r_islem.new_dk_no_interest  ;
            varchar_list(p_6230_ESKI_DK_NO)             := r_islem.dk_no_interest;
           ELSE
            varchar_list(p_6230_YENI_DK_NO)             := r_islem.dk_no_interest;
            varchar_list(p_6230_ESKI_DK_NO)             := r_islem.dk_no_interest;
           END IF;

            varchar_list(p_6230_BANKA_ACIKLAMA)         := r_islem.hesap_no || ' Product / Branch Modification';
            varchar_list(p_6230_MUSTERI_ACIKLAMA)      := r_islem.hesap_no || ' Product / Branch Modification';
            varchar_list(p_6230_DOVIZ_KODU)             := ls_doviz_kodu;
            varchar_list(p_6230_ISTATISTIK_KODU)      := '';
            varchar_list(p_6230_MUSTERI_HESAP_NO)      := '';
            varchar_list(p_6230_REFERANS)              := r_islem.hesap_no;--r_islem.tx_no;


            number_list(p_6230_KUR)                   := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A')  ;
            number_list(p_6230_LC_TUTAR)               := ABS(Pkg_Kur.yuvarla(ls_doviz_kodu, ln_interest * number_list(p_6230_KUR))) ;
            number_list(p_6230_FC_TUTAR)               := ABS(ln_interest);

            IF ls_doviz_kodu = Pkg_Genel.lc_al THEN
                boolean_list(p_6230_LC_HESAP)     := TRUE;
                boolean_list(p_6230_FC_HESAP)     := FALSE;
            ELSE
                boolean_list(p_6230_LC_HESAP)     := FALSE;
                boolean_list(p_6230_FC_HESAP)     := TRUE;
            END IF;

                boolean_list(p_6230_ARTI_BAKIYE)         := FALSE;
                boolean_list(p_6230_EKSI_BAKIYE)         := TRUE;


            --Bakiye yoksa hic fis kesme
            IF number_list(p_6230_FC_TUTAR) <> 0 THEN --nvl(ln_interest,0)<>0 then
                ln_fis_no:=Pkg_Muhasebe.fis_kes ( 6230,
                                                         NULL,
                                                         pn_islem_no,
                                                        varchar_list ,
                                                        number_list  ,
                                                        date_list    ,
                                                        boolean_list ,
                                                        NULL,
                                                       FALSE,
                                                        0,
                                                        NULL);

                 Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
            END IF;

       END IF;
       
       end if;
       
       
    if nvl(ln_interest,0)>0 and r_islem.modul_tur_kod in ('TIME DEP.') then 
   
       IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)
           OR r_islem.dk_no_interest <> r_islem.new_dk_no_interest THEN 

           ls_doviz_kodu := Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ;

              IF  (r_islem.sube_kodu <> r_islem.yeni_sube_kodu AND NVL(r_islem.yeni_sube_kodu,0) <> 0)  THEN
                varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.yeni_sube_kodu ;
                varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
                boolean_list(p_6230_SUBE_DEGISTI)          := TRUE;
           ELSE
                varchar_list(p_6230_YENI_HESAP_SUBE)      := r_islem.sube_kodu ;
                varchar_list(p_6230_ESKI_HESAP_SUBE)      := r_islem.sube_kodu;
                boolean_list(p_6230_SUBE_DEGISTI)          := FALSE;
           END IF;

           IF r_islem.dk_no_interest <> r_islem.new_dk_no_interest THEN
            varchar_list(p_6230_YENI_DK_NO)             := r_islem.new_dk_no_interest  ;
            varchar_list(p_6230_ESKI_DK_NO)             := r_islem.dk_no_interest;
           ELSE
            varchar_list(p_6230_YENI_DK_NO)             := r_islem.dk_no_interest;
            varchar_list(p_6230_ESKI_DK_NO)             := r_islem.dk_no_interest;
           END IF;

            varchar_list(p_6230_BANKA_ACIKLAMA)         := r_islem.hesap_no || ' Product / Branch Modification';
            varchar_list(p_6230_MUSTERI_ACIKLAMA)      := r_islem.hesap_no || ' Product / Branch Modification';
            varchar_list(p_6230_DOVIZ_KODU)             := ls_doviz_kodu;
            varchar_list(p_6230_ISTATISTIK_KODU)      := '';
            varchar_list(p_6230_MUSTERI_HESAP_NO)      := '';
            varchar_list(p_6230_REFERANS)              := r_islem.hesap_no;--r_islem.tx_no;


            number_list(p_6230_KUR)                   := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A')  ;
            number_list(p_6230_LC_TUTAR)               := ABS(Pkg_Kur.yuvarla(ls_doviz_kodu, ln_interest * number_list(p_6230_KUR))) ;
            number_list(p_6230_FC_TUTAR)               := ABS(ln_interest);

            IF ls_doviz_kodu = Pkg_Genel.lc_al THEN
                boolean_list(p_6230_LC_HESAP)     := TRUE;
                boolean_list(p_6230_FC_HESAP)     := FALSE;
            ELSE
                boolean_list(p_6230_LC_HESAP)     := FALSE;
                boolean_list(p_6230_FC_HESAP)     := TRUE;
            END IF;

                boolean_list(p_6230_ARTI_BAKIYE)         := TRUE;
                boolean_list(p_6230_EKSI_BAKIYE)         := FALSE;


            --Bakiye yoksa hic fis kesme
            IF number_list(p_6230_FC_TUTAR) <> 0 THEN --nvl(ln_interest,0)<>0 then
                ln_fis_no:=Pkg_Muhasebe.fis_kes ( 6230,
                                                         NULL,
                                                         pn_islem_no,
                                                        varchar_list ,
                                                        number_list  ,
                                                        date_list    ,
                                                        boolean_list ,
                                                        NULL,
                                                       FALSE,
                                                        0,
                                                        NULL);

                 Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
            END IF;

       END IF;
       
       end if;   
   --EOM aisuluud cq5721

     EXCEPTION
       WHEN OTHERS THEN
       log_at('6230_muhasebelesme', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE); --aisuluud cq5721
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5029'  || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);


  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER) IS
   BEGIN
    NULL;
  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '699' || Pkg_Hata.getucpointer);
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--------------------------------------------------------------------------------------------------------------
  FUNCTION Bitmemis_islem_var_mi(pn_hesap_no  NUMBER) RETURN NUMBER IS
    ln_sonuc  NUMBER ;
  BEGIN
    BEGIN
         SELECT tx_no
        INTO   ln_sonuc
        FROM   CBS_HESAP_URUN_SUBE_DEGISIKLIK
        WHERE  hesap_no = pn_hesap_no
        AND    Pkg_Tx.Islem_bitmis_mi(tx_no) = 0  ;

       EXCEPTION
       WHEN NO_DATA_FOUND THEN
         ln_sonuc := 0 ;
    END ;

    RETURN  ln_sonuc ;

  END;
  /******************************************************************************/
BEGIN
    p_6230_YENI_HESAP_SUBE    := Pkg_Muhasebe.parametre_index_bul('6230_YENI_HESAP_SUBE');
    p_6230_YENI_DK_NO        := Pkg_Muhasebe.parametre_index_bul('6230_YENI_DK_NO');
    p_6230_ESKI_DK_NO        := Pkg_Muhasebe.parametre_index_bul('6230_ESKI_DK_NO');
    p_6230_BANKA_ACIKLAMA    := Pkg_Muhasebe.parametre_index_bul('6230_BANKA_ACIKLAMA');
    p_6230_ARTI_BAKIYE        := Pkg_Muhasebe.parametre_index_bul('6230_ARTI_BAKIYE');
    p_6230_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('6230_DOVIZ_KODU');
    p_6230_FC_HESAP            := Pkg_Muhasebe.parametre_index_bul('6230_FC_HESAP');
    p_6230_FC_TUTAR            := Pkg_Muhasebe.parametre_index_bul('6230_FC_TUTAR');
    p_6230_ESKI_HESAP_SUBE    := Pkg_Muhasebe.parametre_index_bul('6230_ESKI_HESAP_SUBE');
    p_6230_ISTATISTIK_KODU    := Pkg_Muhasebe.parametre_index_bul('6230_ISTATISTIK_KODU');
    p_6230_KUR                := Pkg_Muhasebe.parametre_index_bul('6230_KUR');
    p_6230_LC_HESAP            := Pkg_Muhasebe.parametre_index_bul('6230_LC_HESAP');
    p_6230_LC_TUTAR            := Pkg_Muhasebe.parametre_index_bul('6230_LC_TUTAR');
    p_6230_EKSI_BAKIYE        := Pkg_Muhasebe.parametre_index_bul('6230_EKSI_BAKIYE');
    p_6230_MUSTERI_ACIKLAMA    := Pkg_Muhasebe.parametre_index_bul('6230_MUSTERI_ACIKLAMA');
    p_6230_MUSTERI_HESAP_NO    := Pkg_Muhasebe.parametre_index_bul('6230_MUSTERI_HESAP_NO');
    p_6230_REFERANS            := Pkg_Muhasebe.parametre_index_bul('6230_REFERANS');
    p_6230_SUBE_DEGISTI                := Pkg_Muhasebe.parametre_index_bul('6230_SUBE_DEGISTI');
END;
/

