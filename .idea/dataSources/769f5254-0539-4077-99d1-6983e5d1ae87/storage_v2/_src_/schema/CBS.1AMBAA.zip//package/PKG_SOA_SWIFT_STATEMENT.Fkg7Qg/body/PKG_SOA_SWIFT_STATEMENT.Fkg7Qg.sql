create PACKAGE BODY     "PKG_SOA_SWIFT_STATEMENT" IS
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 FUNCTION sf_Musteri_BIC_Kodu_Bul(pn_musteri_no number) RETURN VARCHAR2 IS
    ls_bic   VARCHAR2(12);
 BEGIN

    SELECT bic_kod
    INTO   ls_bic
    FROM   CBS_MUSTERI
    WHERE  musteri_no = pn_musteri_no ;

    RETURN ls_bic ;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN
       RETURN ls_bic ;

 END;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 FUNCTION sf_islem_aciklama_al(pn_fis_islem_numara NUMBER) RETURN VARCHAR2 IS
    ln_islem_kod  number := 0;
    ls_aciklama varchar2(200);
 BEGIN

    select islem_kod
    into ln_islem_kod
    from cbs_islem
    where numara = pn_fis_islem_numara;

    if nvl(ln_islem_kod,0) <>0 then
        begin
        select aciklama
        into ls_aciklama
        from cbs_islem_swift_tanim
        where cbs_islem_kod = ln_islem_kod ;
        exception when  others then
            ls_aciklama := PKG_GENEL.ISLEM_ADI_AL( ln_islem_kod);
         end;
   end if;


    RETURN  ls_aciklama ;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN
       RETURN null;

 END;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--- B-O-M  sevalb 28062012 25691-Special statements for Coca-Cola Bishkek Bottlers via Internet Banking
-- to_external_hesap_no function for getting transaction detials of to external account number ,will be used in IB mt940 statement 
Function to_external_hesap_no(pn_tx_no number ,pn_islem_kod number ) return varchar2 is
 ls_external_hesap_no varchar2(200);
  BEGIN
     
     if  pn_islem_kod = 6200 then 
           select  pkg_hesap.external_hesapno_al(hesap_no) external_hesap_no
           into  ls_external_hesap_no
           from cbs_cari_nakit_yatan_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 3555 then
           select  to_account_external_number
           into  ls_external_hesap_no
           from cbs_clearing_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 1203 then
           select alacak_external_hesap
           into  ls_external_hesap_no
           from cbs_virman_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 4003 then
           select BC_HESAP_NO_N
           into  ls_external_hesap_no
           from cbs_yphavale_giden_acilis
           where tx_no = pn_tx_no;
     end if;
     
          
     return ls_external_hesap_no;

     exception
               when others then
                   return null;
  END;

PROCEDURE sp_ins_ib_swift_file_msg( pn_hesap_no number,pn_log_no number,pn_log_sira_no  number,ps_mesaj varchar2) 
 is pragma autonomous_transaction;

Begin

    insert into cbs_ib_swift_ektsre_file_msg(log_no,log_sira_no ,hesap_no,dosya_satir_no,dosya_swift_mesaj)
    values (pn_log_no,pn_log_sira_no ,pn_hesap_no,pkg_genel.genel_kod_al('IB_SWIFT_FILE_SIRANO' ),ps_mesaj);        

    commit;

 Exception when others then
      rollback;
      log_At('sp_ins_ib_swift_file_msg Hata',sqlcode||' '||sqlerrm,pn_log_no||'\'||pn_log_sira_no ||' '||pn_hesap_no );
End;
/*
{1:F01DEMIKG22AXXX0000000000}{2:I940DEMIKG22XXXXN}{3:{108:0003000012980}}{4:
:20:25649560
:25:TR340014200000000000006478
:28C:39/1
:60F:C120626EUR50090000,00
:61:1206260627CR6500,00NMSC940 TEST 26.06.2//012
120626
:86:940 TEST 26.06.2012
:61::61:0626DR2500,00NMSC940 TEST 26.06.2//012-2
:86:940 TEST 26.06.2012-2
:62F:C120626EUR50094000,00
:64:C120626EUR50094000,00
-}
*/

PROCEDURE IB_MT940_Data_Hazirla(pn_hesap_no number,pd_baslangid_Tarih date ,pd_bitis_tarih date ,pn_log_no out number ) 
 is pragma autonomous_transaction;

    CURSOR c_hesap is
    SELECT HESAP_NO, MUSTERI_NO ,DOVIZ_KODU ,
          PKG_KUR.YUVARLA(doviz_kodu, NVL(pkg_vadehesap_rapor.sf_devirbakiyebul(hesap_no,to_char(pd_baslangid_Tarih,'DD/MM/YYYY')),0))  acilis_bakiyesi,
          PKG_KUR.YUVARLA(doviz_kodu, pkg_hesap.HesapBakiyeAl(hesap_no)) kapanis_bakiyesi,
          PKG_KUR.YUVARLA(doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no)) kullanilabilir_bakiye,
           decode(sign(NVL(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),0)),-1,'D','C')  kullbak_ba_kod  ,
           PKG_SOA_SWIFT_STATEMENT.sf_musteri_bic_kodu_bul(musteri_no) bic_kodu,
            decode(sign(NVL(pkg_vadehesap_rapor.sf_devirbakiyebul(hesap_no,to_char(pd_baslangid_Tarih,'DD/MM/YYYY')),0)),-1,'D','C')  acilis_ba_kod  ,
           decode(sign(NVL(pkg_hesap.HesapBakiyeAl(hesap_no),0)),-1,'D','C')  kapanis_ba_kod  ,
            ekstre_sikligi
    FROM   cbs_hesap
    WHERE hesap_no=pn_hesap_no;


    r_hesap    c_hesap%ROWTYPE;

    cursor  c_hrkt(c_hesap_no number) is
    select  satir_hesap_numara hesap_no,satir_valor_tarihi,decode(satir_tur,'B','D','C') satir_tur,satir_doviz_kod,abs(nvl(satir_dv_tutar,0)) satir_dv_tutar ,
       pkg_swift.sf_turkce_char_cevir( upper(trim(pkg_report4.cyr2lat(replace(replace(replace(satir_musteri_aciklama,'/'),'//'),chr(10),' '))))) aciklama , --sevalb 23082011 swift char replacement
        fis_numara, fis_islem_numara,satir_numara,
           decode(pkg_tx.islem_kod(fis_islem_numara),4003, nvl((select referans from cbs_yphavale_giden_acilis where tx_no = fis_islem_numara ), 'NONREF'),'NONREF') referans,
           pkg_tx.islem_kod(fis_islem_numara) cbs_islem_kodu
    from    cbs_vw_fis_satir
    where   satir_hesap_numara = to_char(c_hesap_no)
    and     fis_muhasebelestigi_tarih between  pd_baslangid_tarih and pd_bitis_tarih
    and     satir_hesap_tur_kodu = 'VS'
    and     fis_tur = 'G'
    and     fis_iptal_edildigi_tarih is null  --sevalb 12052011
    order by fis_numara,satir_tur;    

    r_hrkt    c_hrkt%ROWTYPE;
 
    ln_ekste_no      number;
    ls_sube           varchar2(3);
    ls_fis_aciklama   varchar2(200);
    ln_log_no  number;
    ln_sira_no        number := 0;  
    ls_result_message clob;
    ls_block2        varchar2(2000);
    ls_block4       clob;
    ls_to_external_hesap_no cbs_hesap.external_hesap_no%type;
    ln_dosya_satir_no   number := 0;
    ls_satir      varchar2(2000);
 BEGIN
 
    OPEN c_hesap;
    LOOP
      FETCH  c_hesap  INTO r_hesap ;
      EXIT WHEN c_hesap%NOTFOUND;

       ln_log_no := pkg_genel.genel_kod_al('IB_MT940_LOGNO');
       ln_ekste_no :=ln_log_no;
       ln_sira_no := 0 ; 
       ls_block2 := null; 
       ls_satir := null;
     insert into cbs_ib_swift_ektsre_analog
             (log_no, ekstre_numarasi, ekstre_sayfa_sayisi, hesap_no, doviz_kodu,doviz_kodu_f,doviz_kodu_m,  acilis_bakiyesi_f, acilis_bakiyesi_m,kullanilabilir_bakiye,
              kapanis_bakiyesi_f,kapanis_bakiyesi_m,  acilis_ba_kod_f,acilis_ba_kod_m, ekstre_tarihi,ekstre_tarihi_f,ekstre_tarihi_m, musteri_no,bic_kodu,
              kapanis_ba_kod_f, kapanis_ba_kod_m, kullbak_ba_kod,ekstre_sikligi)
      values(ln_log_no, ln_ekste_no, 1, r_hesap.hesap_no, r_hesap.doviz_kodu,r_hesap.doviz_kodu,null, abs(r_hesap.acilis_bakiyesi),null,abs( r_hesap.kullanilabilir_bakiye), --sevalb bakiye alanlari abs ile atildi
               abs(r_hesap.kapanis_bakiyesi), null, r_hesap.acilis_ba_kod,null, pd_bitis_tarih, pd_bitis_tarih,null, r_hesap.musteri_no,r_hesap.bic_kodu,
             r_hesap.kapanis_ba_kod, null, r_hesap.kullbak_ba_kod,r_hesap.ekstre_sikligi);

    if nvl(r_hesap.bic_kodu,0) is not null then
     begin
         select '{2:I940'||substr(sbickd,1,8)||'X'||  substr(sbickd,9,3) ||'N'|| '}'
         into ls_block2 
         from swiftgw.swtbicpf
         where sbickd =r_hesap.bic_kodu;
      exception when others then  ls_block2 := '{2:I940}';
     end;
    end if;  
      
     ls_satir :='{1:F01DEMIKG22AXXX0000000000}';    
     ls_result_message :=ls_satir || ls_block2||'{3:{108:0000000000000}}{4:' ;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.1,ls_result_message); 
     
     ls_satir := ':20:'||ln_log_no;
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.2,ls_satir);
     
     ls_satir := ':25:'||pkg_hesap.external_hesapno_al(r_hesap.hesap_no);
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.3,ls_satir);
     
     ls_satir  :=':28C:'||to_char(ln_ekste_no) || '/'  || '1';    
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.4,ls_satir);
        
     ls_satir :=':60F:'|| r_hesap.acilis_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu||
                         replace(trim(to_char(abs(r_hesap.acilis_bakiyesi),'999999999999999.99')),'.',',');
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.5,ls_satir);
    
      OPEN c_hrkt(r_hesap.hesap_no);
      LOOP
        fetch  c_hrkt  into r_hrkt ;
        exit when c_hrkt%notfound;
        ln_sira_no := ln_sira_no +1 ;
        ls_fis_aciklama := upper(PKG_SOA_SWIFT_STATEMENT.sf_islem_aciklama_al(r_hrkt.fis_islem_numara));
        ls_block4 := null;
        ls_to_external_hesap_no :=PKG_SOA_SWIFT_STATEMENT.to_external_hesap_no(r_hrkt.fis_islem_numara,r_hrkt.cbs_islem_kodu);

         insert into cbs_ib_swift_ektsre_dtylog
            (log_no, sira_no,ekstre_numarasi, ekstre_sayfa_sayisi, hesap_no, fis_islem_numara, fis_numara, satir_numara, valor_tarihi, tur, doviz_kodu, islem_tipi,
             islem_kodu, dv_tutar, musteri_aciklama,ekstre_tarihi,fis_aciklama,order_no,referans,cbs_islem_kodu,receiver_account_no)
         values
            (ln_log_no,ln_sira_no, ln_ekste_no,1,r_hrkt.hesap_no, r_hrkt.fis_islem_numara ,r_hrkt.fis_numara,r_hrkt.satir_numara,r_hrkt.satir_valor_tarihi,
             r_hrkt.satir_tur,r_hrkt.satir_doviz_kod, 'N', 'MSC' ,r_hrkt.satir_dv_tutar ,r_hrkt.aciklama ,pd_bitis_tarih,ls_fis_aciklama,pkg_genel.genel_kod_al('IB_SWIFT_EKST_ORDER' ),r_hrkt.referans,r_hrkt.cbs_islem_kodu,ls_to_external_hesap_no) ;
       
            ls_block4 := ':61:' ||ls_to_external_hesap_no||to_char(pd_bitis_tarih,'YYMMDD')  ||to_char(r_hrkt.satir_valor_tarihi,'MMDD') || r_hrkt.satir_tur ||substr(r_hrkt.satir_doviz_kod,3,1)||
                                replace(trim(to_char(abs(r_hrkt.satir_dv_tutar),'999999999999999.99')),'.',',')||'N'||'MSC'||substr(r_hrkt.referans,1,16)||'//'||substr(ls_fis_aciklama,1,14);
            sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_block4);

            if trim(substr(ls_fis_aciklama,15,34)) is not null then 
                ls_satir := trim(substr(ls_fis_aciklama,15,34));
                ls_block4 :=ls_block4 ||chr(10) || ls_satir ;
                sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);  
            end if;

           ls_result_message :=ls_result_message ||chr(10) || ls_block4;
      
           ls_block4 := null;
           ls_block4 := ':86:' ||trim(SUBSTR(r_hrkt.aciklama,1,65)) ;
           sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_block4);
           
            if trim(SUBSTR(r_hrkt.aciklama,66,65)) is not null then
                 ls_satir :=  trim(SUBSTR(r_hrkt.aciklama,66,65)) ;
                 ls_block4 :=ls_block4 ||chr(10) || ls_satir;
                 sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
            end if;
            if trim(SUBSTR(r_hrkt.aciklama,131,65)) is not null then
                 ls_satir :=  trim(SUBSTR(r_hrkt.aciklama,131,65)) ;
                 ls_block4 :=ls_block4 ||chr(10) || ls_satir;
                sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
            end if;
             if trim(SUBSTR(r_hrkt.aciklama,196,65)) is not null then
                 ls_satir :=  trim(SUBSTR(r_hrkt.aciklama,196,65)) ;
                 ls_block4 :=ls_block4 ||chr(10) ||  ls_satir;
                 sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
            end if;
            if trim(SUBSTR(r_hrkt.aciklama,261,65)) is not null then
                 ls_satir :=  trim(SUBSTR(r_hrkt.aciklama,261,65)) ;
                 ls_block4 :=ls_block4 ||chr(10) || ls_satir;
                 sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
            end if;

            if trim(SUBSTR(r_hrkt.aciklama,326,65)) is not null then
                ls_satir :=  trim(SUBSTR(r_hrkt.aciklama,326,65)) ;
                ls_block4 :=ls_block4 ||chr(10) ||  ls_satir;
                sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
            end if;

          ls_result_message :=ls_result_message ||chr(10) || ls_block4;
             
      End loop;

         ls_satir :=':62F:'|| r_hesap.kapanis_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu|| replace(trim(to_char( abs(r_hesap.kapanis_bakiyesi),'999999999999999.99')),'.',',');
         ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
         sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
         
         ls_satir :=':64:'|| r_hesap.kullbak_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu|| replace(trim(to_char(abs(r_hesap.kullanilabilir_bakiye),'999999999999999.99')),'.',',');
         ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
         sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);

       commit; --sevalb 12052011
      CLOSE c_hrkt;

    END LOOP;
    CLOSE c_hesap;
        
    ls_satir := '-}';  
    ls_result_message :=ls_result_message ||CHR(10) ||ls_satir;  
    sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no+1,ls_satir);

    update cbs_ib_swift_ektsre_analog 
    set swift_mesaj = ls_result_message
    where log_no = ln_log_no ; 
    
    pn_log_no := ln_log_no;

    commit;
          Exception when others then
            rollback;
            log_At('IB_MT940_Data_Hazirla Hata',sqlcode||' '||sqlerrm,ln_log_no ||' '||r_hesap.hesap_no );
 END;
--------------------------------------------------------------------------------------
--GetAccount_MT940_Statement bu kisim pkg_int_account eklenebilir.IB formatina uygun olarak parametreler varchar2 olarak hazirlandi.
--------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetAccount_MT940_Statement
   Prepared By : Seval Colak
   Date        : 29.06.2012
   Purpose     : Make IB MT940 statement data 
******************************************************************************/
FUNCTION GetAccount_MT940_Statement(ps_acct_no          VARCHAR2,
                 pd_start_date       VARCHAR2,
                 pd_end_date         VARCHAR2,               
                 pc_ref               OUT   Cursorreferencetype) RETURN VARCHAR2 IS

      ld_start_date             DATE;
      ld_end_date               DATE;
      ls_returncode             VARCHAR2(3):= '000';      
      lc_hesap_no               NUMBER:= TO_NUMBER (ps_acct_no);      
      ln_log_no                 number := 0;
      ls_retval                 varchar2(3):='000';
BEGIN
    ld_start_date := to_date(pd_start_date,'YYYYMMDD');
    ld_end_date := to_date(pd_end_date,'YYYYMMDD');    

    PKG_SOA_SWIFT_STATEMENT.ib_mt940_data_hazirla(lc_hesap_no ,ld_start_date  ,ld_end_date  ,ln_log_no  ) ;
   
   open pc_ref for
    select dosya_swift_mesaj 
    from cbs_ib_swift_ektsre_file_msg
    where log_no = ln_log_no
    order by  dosya_satir_no;

    return ls_returncode;

exception
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at('GetAccount_MT940_Statement',ps_acct_no,sqlerrm);
        raise_application_error(-20100,sqlerrm);
        open pc_ref for    select to_char(ln_log_no) ln_log_no from dual;
        return ls_returncode;
end;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function sf_musteri_swift_msg_uygun(ps_musteri_no varchar2 ,
                                     pc_ref  OUT CursorReferenceType) return varchar2 is
--customer_no=15685 coco cola will be inserted into cbs_ib_swift_ektsre_musteri table 
    ln_adet number :=0 ;
    ls_returncode   VARCHAR2 (3) := '000';
 begin
        

    select count(*)
    into ln_adet
    from cbs_ib_swift_ektsre_musteri
    where musteri_no = to_number(nvl(ps_musteri_no,'0') );

    
    if nvl(ln_adet,0) = 0 then
      open pc_ref for select 'N'  from dual;
    else
      open pc_ref for select 'Y'  from dual;            
    end if;

    return ls_returncode;

    exception
    when others then 
        ls_returncode := '999'; 
        return ls_returncode;

 end;
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--- E-O-M  sevalb 28062012 25691-Special statements for Coca-Cola Bishkek Bottlers via Internet Banking
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------
--GetAccount_MT942_Statement
--------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetAccount_MT942_Statement
   Prepared By : Esen Omurchiev
   Date        : 20.12.2021
   Purpose     : Make IB MT942 statement data 
******************************************************************************/
FUNCTION GetAccount_MT942_Statement(ps_acct_no          VARCHAR2,
                 pd_start_date       VARCHAR2,
                 pd_end_date         VARCHAR2, 
                 option_type         VARCHAR2,               
                 pc_ref               OUT   Cursorreferencetype) RETURN VARCHAR2 IS

      ld_start_date             DATE;
      ld_end_date               DATE;
      ls_returncode             VARCHAR2(3):= '000';      
      lc_hesap_no               NUMBER:= TO_NUMBER (ps_acct_no);      
      ln_log_no                 number := 0;
      ls_retval                 varchar2(3):='000';
BEGIN
    ld_start_date := to_date(pd_start_date,'YYYYMMDD');
    ld_end_date := to_date(pd_end_date,'YYYYMMDD');    

    PKG_SOA_SWIFT_STATEMENT.ib_mt942_data_hazirla(lc_hesap_no ,ld_start_date  ,ld_end_date,option_type  ,ln_log_no  ) ;
   
   open pc_ref for
    select dosya_swift_mesaj 
    from cbs_ib_swift_ektsre_file_msg
    where log_no = ln_log_no
    order by  dosya_satir_no;

    return ls_returncode;

exception
    when others then
        ls_returncode:=pkg_int_api.geterrorcode(sqlerrm);
        log_at('GetAccount_MT942_Statement',ps_acct_no,sqlerrm);
        raise_application_error(-20100,sqlerrm);
        open pc_ref for    select to_char(ln_log_no) ln_log_no from dual;
        return ls_returncode;
END;

PROCEDURE IB_MT942_Data_Hazirla(pn_hesap_no number,pd_baslangid_Tarih date ,pd_bitis_tarih date , option_type varchar2, pn_log_no out number ) 
 is pragma autonomous_transaction;

    CURSOR c_hesap is
    SELECT HESAP_NO, MUSTERI_NO ,DOVIZ_KODU ,
          PKG_KUR.YUVARLA(doviz_kodu, NVL(pkg_vadehesap_rapor.sf_devirbakiyebul(hesap_no,to_char(pd_baslangid_Tarih,'DD/MM/YYYY')),0))  acilis_bakiyesi,
          PKG_KUR.YUVARLA(doviz_kodu, pkg_hesap.HesapBakiyeAl(hesap_no)) kapanis_bakiyesi,
          PKG_KUR.YUVARLA(doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no)) kullanilabilir_bakiye,
           decode(sign(NVL(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),0)),-1,'D','C')  kullbak_ba_kod  ,
           PKG_SOA_SWIFT_STATEMENT.sf_musteri_bic_kodu_bul(musteri_no) bic_kodu,
            decode(sign(NVL(pkg_vadehesap_rapor.sf_devirbakiyebul(hesap_no,to_char(pd_baslangid_Tarih,'DD/MM/YYYY')),0)),-1,'D','C')  acilis_ba_kod  ,
           decode(sign(NVL(pkg_hesap.HesapBakiyeAl(hesap_no),0)),-1,'D','C')  kapanis_ba_kod  ,
            ekstre_sikligi
    FROM   cbs_hesap
    WHERE hesap_no=pn_hesap_no;


    r_hesap    c_hesap%ROWTYPE;

    cursor  c_hrkt(c_hesap_no number) is
   SELECT 
        A.fis_numara,
        A.satir_valor_tarihi,
        decode(A.satir_tur,'B','D','C') satir_tur,
        abs(nvl(A.satir_dv_tutar,0)) satir_dv_tutar,
        nvl((select REF_NO from cbs_yphavale_gelen_basvuru where tx_no = A.fis_islem_numara ), 'NONREF') referans,
        upper(trim(A.SATIR_MUSTERI_ACIKLAMA)) SATIR_MUSTERI_ACIKLAMA, 
        decode(I.KOD, 2010, 'SWIFT Incoming', I.ACIKLAMA) ACIKLAMA, 
        I.ACIKLAMA ACIKLAMA_2, 
        Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
        PKG_MUSTERI.SF_VERGINO_AL(A.MUSTERI_NO)  reciver_inn,
        satir_hesap_numara hesap_no,
        A.fis_islem_numara,
        pkg_tx.islem_kod(A.fis_islem_numara) cbs_islem_kodu,
        decode(I.KOD,2010,(select GONDEREN_ADI from cbs.cbs_yphavale_gelen_basvuru where tx_no =K.NUMARA),' ') Gonderen_Adi,
        decode(I.KOD,2010,(select ALICI_ADI from cbs.cbs_yphavale_gelen_basvuru where tx_no =K.NUMARA),' ') Alici_Adi,
        A.FIS_MUHASEBELESTIGI_TARIH 
  
    FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I 
    WHERE  SATIR_HESAP_NUMARA = to_char(c_hesap_no)
                AND FIS_MUHASEBELESTIGI_TARIH BETWEEN pd_baslangid_tarih and pd_bitis_tarih   
                AND FIS_TUR = 'G'
                AND A.SATIR_TUR LIKE DECODE('%', 'ALL', A.SATIR_TUR, '%') 
                AND K.NUMARA=A.FIS_ISLEM_NUMARA
                AND I.KOD=K.ISLEM_KOD
                AND K.ISLEM_KOD NOT IN (1203,3555,3556,4003)
    UNION ALL 
    
    SELECT 
        A.fis_numara,
        A.satir_valor_tarihi,
        decode(A.satir_tur,'B','D','C') satir_tur,
        abs(nvl(A.satir_dv_tutar,0)) satir_dv_tutar,
        nvl((select referans from cbs_yphavale_giden_acilis where tx_no = A.fis_islem_numara ), 'NONREF') referans,
        upper(trim(A.SATIR_MUSTERI_ACIKLAMA)) SATIR_MUSTERI_ACIKLAMA, 
        decode(I.KOD, 4003, 'SWIFT Outgoing', I.ACIKLAMA) ACIKLAMA, 
        I.ACIKLAMA ACIKLAMA_2, 
        Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
        PKG_MUSTERI.SF_VERGINO_AL(A.MUSTERI_NO)  reciver_inn,
        satir_hesap_numara hesap_no,
        A.fis_islem_numara,
        pkg_tx.islem_kod(A.fis_islem_numara) cbs_islem_kodu,
        decode(I.KOD,4003,(select OC_ISIM_ADRES_1 from cbs.cbs_yphavale_giden_acilis where tx_no =K.NUMARA),' ') Gonderen_Adi,
        decode(I.KOD,4003,(select BC_ISIM_ADRES_1 from cbs.cbs_yphavale_giden_acilis where tx_no =K.NUMARA),' ') Alici_Adi,
        A.FIS_MUHASEBELESTIGI_TARIH 
  
    FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I 
    WHERE  SATIR_HESAP_NUMARA = to_char(c_hesap_no)
                AND FIS_MUHASEBELESTIGI_TARIH BETWEEN pd_baslangid_tarih and pd_bitis_tarih  
                AND FIS_TUR = 'G'
                AND A.SATIR_TUR LIKE DECODE('%', 'ALL', A.SATIR_TUR, '%') 
                AND K.NUMARA=A.FIS_ISLEM_NUMARA
                AND I.KOD=K.ISLEM_KOD
                AND K.ISLEM_KOD = 2010 
    UNION ALL 
    
    SELECT 
        A.fis_numara,
        A.satir_valor_tarihi,
        decode(A.satir_tur,'B','D','C') satir_tur,
        abs(nvl(A.satir_dv_tutar,0)) satir_dv_tutar,
        'NONREF' referans,
        upper(trim(A.SATIR_MUSTERI_ACIKLAMA)) SATIR_MUSTERI_ACIKLAMA, 
  
        decode(K.URUN_SINIF_KOD, 'INTERNET OWN LC', 'Transfer between Accounts', 'INTERNET OTHER LC', 'Transfer to Other Accounts',I.ACIKLAMA) ACIKLAMA, 
        I.ACIKLAMA ACIKLAMA_2, 
  
        Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
        PKG_MUSTERI.SF_VERGINO_AL(decode(Pkg_Hesap.HesaptanMusteriNoAl(V.borc_hesap_no), MUSTERI_NO, Pkg_Hesap.HesaptanMusteriNoAl(V.alacak_hesap_no), Pkg_Hesap.HesaptanMusteriNoAl(V.borc_hesap_no))) reciver_inn,
        satir_hesap_numara hesap_no,
        A.fis_islem_numara,
        pkg_tx.islem_kod(A.fis_islem_numara) cbs_islem_kodu,
        Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.borc_hesap_no)) Gonderen_Adi,
        Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.alacak_hesap_no)) Alici_Adi,
        A.FIS_MUHASEBELESTIGI_TARIH 
  
    FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_VIRMAN_ISLEM V        
    WHERE  SATIR_HESAP_NUMARA = to_char(c_hesap_no) 
    AND FIS_MUHASEBELESTIGI_TARIH BETWEEN pd_baslangid_tarih and pd_bitis_tarih               
    AND FIS_TUR = 'G'               
    AND A.SATIR_TUR LIKE DECODE('%', 'ALL', A.SATIR_TUR, '%')               
    AND K.NUMARA=A.FIS_ISLEM_NUMARA               
    AND K.NUMARA=V.TX_NO               
    AND I.KOD=K.ISLEM_KOD               
    AND K.ISLEM_KOD = 1203
  
    UNION ALL 
    SELECT 
        A.fis_numara,
        A.satir_valor_tarihi,
        decode(A.satir_tur,'B','D','C') satir_tur,
        abs(nvl(A.satir_dv_tutar,0)) satir_dv_tutar,
        --decode(pkg_tx.islem_kod(A.fis_islem_numara),3555, nvl((select REF_NO from cbs_clearing_islem where tx_no = A.fis_islem_numara ), 'NONREF'),'NONREF') referans,
        'NONREF' referans,
        upper(trim(A.SATIR_MUSTERI_ACIKLAMA)) SATIR_MUSTERI_ACIKLAMA, 
        decode(k.URUN_SINIF_KOD,'CIBGROSS', (select ff.aciklama from cbs_urun_sinif ff where ff.modul_tur_kod=k.MODUL_TUR_KOD and ff.urun_tur_kod=k.URUN_TUR_KOD and kod=k.URUN_SINIF_KOD),I.ACIKLAMA) ACIKLAMA, 
        I.ACIKLAMA ACIKLAMA_2, 
        Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
        ci.from_RNN  reciver_inn,
        satir_hesap_numara hesap_no,
        A.fis_islem_numara,
        pkg_tx.islem_kod(A.fis_islem_numara) cbs_islem_kodu,
        pkg_musteri.Sf_Musteri_Adi(pkg_hesap.HesaptanMusteriNoAl(SATIR_HESAP_NUMARA)) Gonderen_Adi,
        ci.TO_NAME Alici_Adi,
        A.FIS_MUHASEBELESTIGI_TARIH
  
    FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci 
    WHERE SATIR_HESAP_NUMARA = to_char(c_hesap_no)
    AND ci.TX_NO = k.NUMARA 
    AND FIS_MUHASEBELESTIGI_TARIH BETWEEN pd_baslangid_tarih and pd_bitis_tarih
    AND FIS_TUR = 'G' 
    AND A.SATIR_TUR LIKE DECODE('%', 'ALL', A.SATIR_TUR, '%') 
    AND K.NUMARA = A.FIS_ISLEM_NUMARA 
    AND I.KOD = K.ISLEM_KOD 
    AND K.ISLEM_KOD = 3555 
  
    UNION ALL 
    SELECT 
        A.fis_numara,
        A.satir_valor_tarihi,
        decode(A.satir_tur,'B','D','C') satir_tur,
        abs(nvl(A.satir_dv_tutar,0)) satir_dv_tutar,
        --decode(pkg_tx.islem_kod(A.fis_islem_numara),3556, nvl((select REF_NO from cbs_clearing_islem where tx_no = A.fis_islem_numara ), 'NONREF'),'NONREF') referans,
        'NONREF' referans,
        upper(trim(A.SATIR_MUSTERI_ACIKLAMA)) SATIR_MUSTERI_ACIKLAMA, 
        I.ACIKLAMA, 
        I.ACIKLAMA ACIKLAMA_2, 
        Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
        ci.from_RNN reciver_inn,
        satir_hesap_numara hesap_no,
        A.fis_islem_numara,
        pkg_tx.islem_kod(A.fis_islem_numara) cbs_islem_kodu,
        ci.FROM_DESCRIPTION Gonderen_Adi,
        ci.TO_NAME Alici_Adi,
        A.FIS_MUHASEBELESTIGI_TARIH 

    FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci 
    WHERE SATIR_HESAP_NUMARA = to_char(c_hesap_no)
    AND ci.TX_NO = k.NUMARA 
    AND FIS_MUHASEBELESTIGI_TARIH BETWEEN pd_baslangid_tarih and pd_bitis_tarih 
    AND FIS_TUR = 'G' 
    AND A.SATIR_TUR LIKE DECODE('%', 'ALL', A.SATIR_TUR, '%') 
    AND K.NUMARA = A.FIS_ISLEM_NUMARA 
    AND I.KOD = K.ISLEM_KOD 
    AND K.ISLEM_KOD = 3556 ORDER BY 1, 3;   
    
    r_hrkt    c_hrkt%ROWTYPE;
 
    ln_ekste_no      number;
    ls_sube           varchar2(3);
    ls_fis_aciklama   varchar2(200);
    ln_log_no  number;
    ln_sira_no        number := 0;  
    ls_result_message clob;
    ls_block2        varchar2(2000);
    ls_block4       clob;
    ls_to_external_hesap_no varchar(200);
    ls_from_external_hesap_no varchar(200);
    ln_dosya_satir_no   number := 0;
    ls_satir      varchar2(2000);
 BEGIN
 
    OPEN c_hesap;
    LOOP
      FETCH  c_hesap  INTO r_hesap ;
      EXIT WHEN c_hesap%NOTFOUND;

       ln_log_no := pkg_genel.genel_kod_al('IB_MT940_LOGNO');
       ln_ekste_no :=ln_log_no;
       ln_sira_no := 0 ; 
       ls_block2 := null; 
       ls_satir := null;
       ls_to_external_hesap_no := null;
       ls_from_external_hesap_no := null;
       
     insert into cbs_ib_swift_ektsre_analog 
             (log_no, ekstre_numarasi, ekstre_sayfa_sayisi, hesap_no, doviz_kodu,doviz_kodu_f,doviz_kodu_m,  acilis_bakiyesi_f, acilis_bakiyesi_m,kullanilabilir_bakiye,
              kapanis_bakiyesi_f,kapanis_bakiyesi_m,  acilis_ba_kod_f,acilis_ba_kod_m, ekstre_tarihi,ekstre_tarihi_f,ekstre_tarihi_m, musteri_no,bic_kodu,
              kapanis_ba_kod_f, kapanis_ba_kod_m, kullbak_ba_kod,ekstre_sikligi)
      values(ln_log_no, ln_ekste_no, 1, r_hesap.hesap_no, r_hesap.doviz_kodu,r_hesap.doviz_kodu,null, abs(r_hesap.acilis_bakiyesi),null,abs( r_hesap.kullanilabilir_bakiye), --sevalb bakiye alanlari abs ile atildi
               abs(r_hesap.kapanis_bakiyesi), null, r_hesap.acilis_ba_kod,null, pd_bitis_tarih, pd_bitis_tarih,null, r_hesap.musteri_no,r_hesap.bic_kodu,
             r_hesap.kapanis_ba_kod, null, r_hesap.kullbak_ba_kod,r_hesap.ekstre_sikligi);
     
     ls_satir := ':20:'||ln_log_no;
     ls_result_message := ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.2,ls_satir);
     
     ls_satir := ':25:'||pkg_hesap.external_hesapno_al(r_hesap.hesap_no);
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.3,ls_satir);
     
     ls_satir  :=':28:'||to_char(ln_ekste_no);    
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.4,ls_satir);
        
     ls_satir :=':60F:'|| r_hesap.acilis_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu||
                         replace(trim(to_char(abs(r_hesap.acilis_bakiyesi),'999999999999999.99')),'.',',');
     ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
     sp_ins_ib_swift_file_msg( pn_hesap_no,ln_log_no,0.5,ls_satir);
    
      OPEN c_hrkt(r_hesap.hesap_no);
      LOOP
        fetch  c_hrkt  into r_hrkt ;
        exit when c_hrkt%notfound;
        ln_sira_no := ln_sira_no +1;
        ls_block4 := null;
        
         
           if (trim(r_hrkt.SATIR_TUR) = 'D') then
               ls_to_external_hesap_no := PKG_SOA_SWIFT_STATEMENT.to_external_hesap_no(r_hrkt.fis_islem_numara,r_hrkt.cbs_islem_kodu);
           else 
               ls_from_external_hesap_no := PKG_SOA_SWIFT_STATEMENT.from_external_hesap_no(r_hrkt.fis_islem_numara,r_hrkt.cbs_islem_kodu); 
           end if;
         
  
         insert into cbs_ib_swift_ektsre_dtylog
            (log_no, sira_no,ekstre_numarasi, ekstre_sayfa_sayisi, hesap_no, fis_islem_numara, fis_numara, satir_numara, valor_tarihi, tur, doviz_kodu, islem_tipi,
             islem_kodu, dv_tutar, musteri_aciklama,ekstre_tarihi,fis_aciklama,order_no,referans,cbs_islem_kodu,receiver_account_no)
         values
            (ln_log_no,ln_sira_no, ln_ekste_no,1,r_hrkt.hesap_no, '' ,r_hrkt.fis_numara,'',r_hrkt.satir_valor_tarihi,
             r_hrkt.satir_tur, '', 'N', 'MSC' ,r_hrkt.satir_dv_tutar ,r_hrkt.aciklama ,pd_bitis_tarih,'',pkg_genel.genel_kod_al('IB_SWIFT_EKST_ORDER' ), r_hrkt.referans,'','') ;
       
      
            if(trim(r_hrkt.cbs_islem_kodu) = '6200' ) then 
            
                ls_block4 := ':61:' || to_char(r_hrkt.FIS_MUHASEBELESTIGI_TARIH,'YYMMDD')  || to_char(r_hrkt.FIS_MUHASEBELESTIGI_TARIH,'MMDD') || r_hrkt.satir_tur || 'D' ||
                                trim(to_char(abs(r_hrkt.satir_dv_tutar),'999999999999999.99')) ||'N' || 'MSC'; --|| substr(r_hrkt.referans,1,16);
                                
            else 
                ls_block4 := ':61:' || to_char(r_hrkt.satir_valor_tarihi,'YYMMDD')  || to_char(r_hrkt.satir_valor_tarihi,'MMDD') || r_hrkt.satir_tur || 'D' ||
                              trim(to_char(abs(r_hrkt.satir_dv_tutar),'999999999999999.99')) ||'N' || 'MSC'; -- || substr(r_hrkt.referans,1,16);                  
             end if;         
            if (trim(r_hrkt.SATIR_TUR) = 'D') then
                 ls_block4 := ls_block4 || trim(r_hrkt.Alici_Adi);
            else 
                 ls_block4 := ls_block4 || trim(r_hrkt.Gonderen_Adi); 
            end if;
            
            sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_block4);

            ls_result_message :=ls_result_message ||chr(10) || ls_block4;
      
            ls_block4 := null; --2-   
            
            ls_block4 := ':86:' || '?00' || trim(r_hrkt.ACIKLAMA)  || '?20';
           
            ls_block4 := ls_block4 || '/PY/' || trim(r_hrkt.SATIR_MUSTERI_ACIKLAMA) || '?';
            /*if(trim(r_hrkt.referans) = 'NONREF') then
               ls_block4 := ls_block4 || '/PY/' || trim(r_hrkt.SATIR_MUSTERI_ACIKLAMA) || '?';
            else
               ls_block4 := ls_block4 || '/PY/' || trim(substr(trim(r_hrkt.SATIR_MUSTERI_ACIKLAMA),16,140)) || '?';
            end if;*/
            
            if (trim(r_hrkt.reciver_inn) is not Null) then
                ls_block4 := ls_block4 || '/'|| trim(r_hrkt.MUSTERI_VERGINO) || '?';
            else 
                ls_block4 := ls_block4 || '/'|| trim(r_hrkt.reciver_inn) || '?';
            end if;
            
             
            if (trim(r_hrkt.SATIR_TUR) = 'D') then
                 
                 if(ls_to_external_hesap_no is not Null) then
                     ls_block4 := ls_block4 || '/BI/'|| trim(ls_to_external_hesap_no) || '?';
                 end if;
            else 
               
                 if(ls_from_external_hesap_no is not Null) then
                     ls_block4 := ls_block4 || '/BI/'|| trim(ls_from_external_hesap_no) || '?';
                 end if;
            end if;
           
          
          
           sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_block4);
          
           ls_result_message :=ls_result_message ||chr(10) || ls_block4;
             
      End loop;

         ls_satir :=':62F:'|| r_hesap.kapanis_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu|| replace(trim(to_char( abs(r_hesap.kapanis_bakiyesi),'999999999999999.99')),'.',',');
         ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
         sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);
         
         ls_satir :=':64:'|| r_hesap.kullbak_ba_kod|| to_char(pd_bitis_tarih,'YYMMDD') ||r_hesap.doviz_kodu|| replace(trim(to_char(abs(r_hesap.kullanilabilir_bakiye),'999999999999999.99')),'.',',');
         ls_result_message :=ls_result_message ||chr(10) ||ls_satir;
         sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no,ls_satir);

       commit; --sevalb 12052011
      CLOSE c_hrkt;

    END LOOP;
    CLOSE c_hesap;
        
    ls_satir := '-';  
    ls_result_message :=ls_result_message ||CHR(10) ||ls_satir;  
    sp_ins_ib_swift_file_msg( r_hesap.hesap_no,ln_log_no,ln_sira_no+1,ls_satir);

    update cbs_ib_swift_ektsre_analog 
    set swift_mesaj = ls_result_message
    where log_no = ln_log_no ; 
    
    pn_log_no := ln_log_no;

    commit;
          Exception when others then
            rollback;
            log_At('IB_MT942_Data_Hazirla Hata',sqlcode||' '||sqlerrm,ln_log_no ||' '||r_hesap.hesap_no );
 END;
 
 Function from_external_hesap_no(pn_tx_no number ,pn_islem_kod number ) return varchar2 is
 
 ls_external_hesap_no varchar2(200);
  BEGIN
     
     if  pn_islem_kod = 6200 then 
           select  pkg_hesap.external_hesapno_al(hesap_no) external_hesap_no
           into  ls_external_hesap_no
           from cbs_cari_nakit_yatan_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 3556 then
           select  FROM_ACCOUNT_EXTERNAL_NUMBER
           into  ls_external_hesap_no
           from cbs_clearing_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 1203 then
           select BORC_EXTERNAL_HESAP
           into  ls_external_hesap_no
           from cbs_virman_islem
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 2012 then
            select GONDEREN_ADRES
           into  ls_external_hesap_no
           from cbs_yphavale_gelen_basvuru
           where tx_no = pn_tx_no;
     elsif  pn_islem_kod = 2010 then
           select GONDEREN_ADRES
           into  ls_external_hesap_no
           from cbs_yphavale_gelen_basvuru
           where tx_no = pn_tx_no;
    end if;
          
     return ls_external_hesap_no;

     exception
               when others then
                   return null;
  END;

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
END PKG_SOA_SWIFT_STATEMENT;
/

