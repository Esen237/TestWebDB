create PACKAGE BODY     PKG_TX1234 IS

 /******************************************************************************
   Name       : PKG_1234
   Created By : Urmat A.
   Date          : 22.12.2014
   Purpose      :  Package of the transactional screen 1234 - Import Blacklist
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;
  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    null;
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
    ln_customer_no number;
    ln_count number;
    
    CURSOR c_black_list_tx IS
    SELECT *
    FROM CBS_BLACK_LIST_TX
    where TX_NO = pn_islem_no;
     
        
    b_list cbs_black_list_tx%ROWTYPE;
    
     
  Begin
     OPEN c_black_list_tx;
     LOOP
         FETCH c_black_list_tx
         INTO b_list; 
         EXIT WHEN c_black_list_tx%NOTFOUND;
                   
         INSERT INTO CBS_BLACK_LIST(NAME, MATCH, CREATE_DATE, CREATE_USER)
                    VALUES(b_list.name, b_list.MATCH, b_list.create_date, b_list.create_user);
                 
         
     END LOOP;
      
      CLOSE c_black_list_tx;
      EXCEPTION WHEN OTHERS THEN
          Log_At('tx1234', pn_islem_no, SQLERRM);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is

    varchar_list                      Pkg_Muhasebe.varchar_array;
    number_list                      Pkg_Muhasebe.number_array;
    date_list                           Pkg_Muhasebe.date_array;
    boolean_list                      Pkg_Muhasebe.boolean_array;
    ln_plan_no                       NUMBER;
    ln_fis_no                          NUMBER;
    ln_tran_code                    NUMBER := 1234;
    ln_account_no                  NUMBER;
     ln_amount                       NUMBER;
     ls_explanation                  varchar2(2000);
    
BEGIN
null;
  End;
begin

null;
END;
/

