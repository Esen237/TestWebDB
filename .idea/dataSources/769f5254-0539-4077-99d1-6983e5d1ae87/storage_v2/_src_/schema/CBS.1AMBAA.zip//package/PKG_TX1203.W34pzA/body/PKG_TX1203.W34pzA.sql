create PACKAGE BODY     pkg_tx1203 IS
  pn_1203_doviz_kod               number;
  pn_1203_lc_tutar            number;
  pn_1203_fc_tutar              number;
  pn_1203_banka_aciklama          number;
  pn_1203_borclu_hesap_sube_kodu  number;
  pn_1203_borclu_hesap_no         number;
  pn_1203_alacak_hesap_sube_kodu  number;
  pn_1203_alacak_hesap_no         number;
  pn_1203_musteri_aciklama        number;
  pn_1203_referans            number;
  pn_1203_fis_aciklama            number;
  pn_1203_kur_lc              number;
  pn_1203_istatistik_kod_BORC     number;
  pn_1203_istatistik_kod_ALACAK   number;
  pn_1203_LC_CHARGE       number;
  pn_1203_FC_CHARGE             number;
  pn_1203_GL_CHARGE             number;
  pn_1203_FC_TRAN           number;
  pn_1203_LC_TRAN             number;
  pn_1203_SERVICE_TAX_LC        number;
  pn_1203_SERVICE_TAX_FC        number;
  pn_1203_AMIR_SUBE       number;
  pn_1203_TAX_ACIKLAMA      number;

    --B-O-M ernestk cqdb00000864
    pn_1203_SF_WTH_CUSTS_NO      number;
    pn_1203_SF_WTH_TRAN          number;
    pn_1203_SF_WTH_FC_CHARGE        number;
    pn_1203_SF_WTH_LC_CHARGE        number;
    pn_1203_SF_WTH_COMM_GL      number;
    pn_1203_SF_WTH_COMM_DSC     number;
    pn_1203_SF_WTH_TAX_LC_AMOUNT  number;
    pn_1203_SF_WTH_TAX_FC_AMOUNT  number;
    pn_1203_SF_WTH_TAX_DSC        number;
    pn_1203_SF_WTH_BISHRG_RATE    number;
    pn_1203_SF_WTH_OTHRRG_RATE   number;
    --E-O-M ernestk cqdb00000864

  --BOM YadgarB CBS-838
  pn_1203_BENEFICIARY_QR_COMMISSION number;
  pn_1203_QR_COMM_TAX_AMOUNT number;
  pn_1203_QR_COMM_AMOUNT number;
  pn_1203_QR_TAX_AMOUNT number;
  pn_1203_QR_COMM_TAX_DESCR number;
  pn_1203_QR_COMM_DESCR number;
  pn_1203_QR_TAX_DESCR number;
  --EOM YadgarB CBS-838

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_hesap_no number;
  Begin
   select borc_hesap_no
   into ln_hesap_no
   from cbs_virman_islem
   where tx_no=pn_islem_no;

   pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1203',ln_hesap_no);

  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

---------------------------------------------------------------------------
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
---------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
---------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
---------------------------------------------------------------------------
 Procedure sp_urun_tur_sinif_al( pn_fromaccountno   IN       VARCHAR2,
                         pn_toaccountno     IN       VARCHAR2,
                   ps_currencycode    IN       VARCHAR2,
                 ps_from_internet   in       varchar2 default null,
                 ps_modul_tur   out    varchar2,
                 ps_urun_tur    out       varchar2,
                 ps_urun_sinif    out varchar2 )
 is
  ls_musteri_tip_kod varchar2(10);
  ls_urun_sinif varchar2(20);
  ls_urun_tur varchar2(20);
  ln_from_custno number;
  ln_to_custno number;
 Begin
    ps_modul_tur := 'CURR.OPS.';
    ln_from_custno := pkg_hesap.HesaptanMusteriNoAl(pn_fromaccountno);
    ln_to_custno := pkg_hesap.HesaptanMusteriNoAl(pn_toaccountno);
    ls_musteri_tip_kod := pkg_musteri.sf_musteri_tipi_al(ln_from_custno);

    select decode(ls_musteri_tip_kod, '1','INDIVIDUAL','2','PRIV.ENTR.','3','CORPORATE','4','BANK')
      into ls_urun_tur
      from dual;

    if ps_from_internet = 'E' then
      ls_urun_sinif := 'INTERNET';
    end if;

    if ln_from_custno = ln_to_custno then
      if ls_urun_sinif is not null then
        ls_urun_sinif := ls_urun_sinif ||' '|| 'OWN';
      else
        ls_urun_sinif := 'OWN';
      end if;
    else
      if ls_urun_sinif is not null then
        ls_urun_sinif := ls_urun_sinif ||' '|| 'OTHER';
      else
        ls_urun_sinif := 'OTHER';
      end if;
    end if;

    if ps_currencycode <> pkg_genel.lc_al then
      ls_urun_sinif := ls_urun_sinif ||' '|| 'FC';
    else
      ls_urun_sinif := ls_urun_sinif ||' '|| 'LC';
    end if;

    ps_urun_tur  := ls_urun_tur;
    ps_urun_sinif := ls_urun_sinif;
 End;

---------------------------------------------------------------------------
  Function sf_istatistikkod_zorunlumu(pn_musteri_no number,ps_doviz_kodu varchar2 ) return varchar2
  is
   ls_musteri_tipi_kod  varchar2(1);
   ln_dk_grup_kod   number;
  Begin
    select musteri_tipi_kod,
           dk_grup_kod
      into ls_musteri_tipi_kod,
           ln_dk_grup_kod
      from cbs_musteri
     where musteri_no = pn_musteri_no;

    if (ps_doviz_kodu <> PKG_GENEL.lc_al and ls_musteri_tipi_kod = '4' ) or ( ln_dk_grup_kod = 1023 ) Then
      return 'E';
    else
      return 'H';
    end if;

    Exception
      when others then return 'H';
  End;


---------------------------------------------------------------------------
  Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list                  pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                     pkg_muhasebe.date_array;
    boolean_list                  pkg_muhasebe.boolean_array;

    ln_fis_no                     cbs_fis.numara%type ;
    ls_islem_kod                  cbs_islem.islem_kod%type := '1203';
    ls_musteri_aciklama           varchar2(2000);
    ls_banka_aciklama             varchar2(2000);
    ls_fis_aciklama               varchar2(2000);
    ln_musteri_no                 cbs_musteri.musteri_no%TYPE;
    ln_hesap_no                   cbs_hesap.hesap_no%TYPE;
    ln_alacak_hesap_no            cbs_hesap.hesap_no%TYPE;
    ls_alacak_hesap_sube_kodu     cbs_hesap.sube_kodu%TYPE;
    ln_borclu_hesap_no            cbs_hesap.hesap_no%TYPE;
    ls_borclu_hesap_sube_kodu     cbs_hesap.sube_kodu%TYPE;
    ln_tutar                      number;
    ln_kur                        number;
    ls_istatistik_kodu            CBS_ISTATISTIK_ESLEME.ISTATISTIK_KODU_1%TYPE;
    ls_doviz_kodu                 cbs_hesap.doviz_kodu%type;
    ln_plan_no                    number := 1;
    ln_borc_musteri_no            number;
    ln_alacak_musteri_no          number;
    ln_service_tax_rate           number;
    --ls_musteri_tipi_kod           varchar2(1); --YadgarB CBS-838: renamed to ls_borc_musteri_tipi_kod
    ls_transfered_to_staff        char := 'H'; --ernestk 16062014 cqdb864 money transfered to staff;
    ls_bishrg_rate                varchar2(10) := '0'; --ernestk 16042014 cqdb864 wth comm rate for bishkek region
    ls_othrrg_rate                varchar2(10) := '0'; --ernestk 16042014 cqdb864 wth comm rate for other regions
    ln_wth_rate                   number := 0; --ernestk 16042014 cqdb864 withdrawal commission rate;
    ls_alacak_il_kodu             cbs.cbs_bolum.il_kodu%type; --ernestk 16042014 cqdb864 reciever region no
    ls_customers_that_pay_wthcomm varchar2(1000) := ''; --ernestk 16042014 cqdb864 customers that pay wth comm for staff
    ln_charge_amount              number;

    --BOM YadgarB CBS-838
    ls_borc_musteri_tipi_kod      varchar2(1);
    ls_alacak_musteri_tipi_kod    varchar2(1);
    ls_alacak_hesap_no_doviz      cbs_hesap.doviz_kodu%type;
    ls_modul_tur_kod              cbs_islem.modul_tur_kod%type;
    ls_urun_tur_kod               cbs_islem.urun_tur_kod%type;
    ls_urun_sinif_kod             cbs_islem.urun_sinif_kod%type;
    ls_qr_flag                    varchar2(1);

    ln_commission_rate            number;
    ln_commission                 number;
    ln_tax                        number;
    ls_comm_tax_expl              varchar2(2000);
    ls_comm_expl                  varchar2(2000);
    ls_tax_expl                   varchar2(2000);
    --EOM YadgarB CBS-838

    cursor islem_cursor is
        select v.borc_hesap_no,
               Pkg_Hesap.HesaptanSubeAl(v.borc_hesap_no),
               v.doviz_kodu,
               v.tutar,
               v.alacak_hesap_no,
               Pkg_Hesap.HesaptanSubeAl(v.alacak_hesap_no),
               v.aciklama,
               v.istatistik_kodu,
               v.charge_amount,
               pkg_musteri.sf_musteri_tipi_al(Pkg_Hesap.HesaptanMusteriNoAl(v.borc_hesap_no)) borc_musteri_tipi_kod,
               --BOM CBS-838
               pkg_musteri.sf_musteri_tipi_al(Pkg_Hesap.HesaptanMusteriNoAl(v.alacak_hesap_no)) alacak_musteri_tipi_kod,
               PKG_HESAP.HesaptanDovizKoduAl(v.alacak_hesap_no) alacak_hesap_no_doviz,
               i.modul_tur_kod,
               i.urun_tur_kod,
               i.urun_sinif_kod,
               l.is_demirpay
               --EOM CBS-838
        from cbs_virman_islem v
        join cbs_islem i on v.tx_no = i.numara
        left join corpint2.tbl_demirpay_log l on l.tx_no = v.tx_no
        where v.tx_no = pn_islem_no;
  Begin
      /* islem bilgisi detaylari alinir */
      if islem_cursor%isopen then
          close islem_cursor;
      end if;

      open islem_cursor;
      fetch islem_cursor into
          ln_borclu_hesap_no,
          ls_borclu_hesap_sube_kodu,
          ls_doviz_kodu,
          ln_tutar,
          ln_alacak_hesap_no,
          ls_alacak_hesap_sube_kodu,
          ls_banka_aciklama,
          ls_istatistik_kodu,
          ln_charge_amount,
          ls_borc_musteri_tipi_kod,
          --BOM CBS-838
          ls_alacak_musteri_tipi_kod,
          ls_alacak_hesap_no_doviz,
          ls_modul_tur_kod,
          ls_urun_tur_kod,
          ls_urun_sinif_kod,
          ls_qr_flag;
          --EOM CBS-838

      if islem_cursor%notfound then
          close islem_cursor;
      end if;
      close islem_cursor;

      /*** Liste Deger Atama K?sm? **/

      /**** varchar list ****/
      pkg_parametre.deger('1203_FIS_ACIKLAMA', ls_fis_aciklama);
      pkg_parametre.deger('1203_SF_WTH_CUSTS_NO', ls_customers_that_pay_wthcomm);--ernestk 16062014 cqdb864 customer's who pay wth comm for their staff
      pkg_parametre.deger('1203_SF_WTH_OTHRRG_RATE', ls_othrrg_rate);--ernestk 16062014 cqdb864 withdrawal commission for other regions
      pkg_parametre.deger('1203_SF_WTH_BISHRG_RATE', ls_bishrg_rate);--ernestk 16062014 cqdb864 withdrawal commission for bishkek region
      pkg_parametre.deger('G_SERVICE_TAX_RATE', ln_service_tax_rate);
      varchar_list(pn_1203_fis_aciklama) := ls_fis_aciklama;
      varchar_list(pn_1203_banka_aciklama) := ls_banka_aciklama;
      --AzatD 27/05/2020
      varchar_list(pn_1203_musteri_aciklama) := ls_banka_aciklama;
      --'Комиссия за проведение платежного поручения.НДС не облагается'; --ls_musteri_aciklama;
      --AzatDAza

      varchar_list(pn_1203_tax_aciklama) := ln_service_tax_rate || '% Sales Tax';

      varchar_list(pn_1203_referans) := to_char(ln_borclu_hesap_no);

      varchar_list(pn_1203_doviz_kod) := ls_doviz_kodu;
      varchar_list(pn_1203_alacak_hesap_sube_kodu) := ls_alacak_hesap_sube_kodu;
      varchar_list(pn_1203_alacak_hesap_no) := to_char(ln_alacak_hesap_no);
      varchar_list(pn_1203_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
      varchar_list(pn_1203_borclu_hesap_no) := to_char(ln_borclu_hesap_no);

      varchar_list(pn_1203_amir_sube) := pkg_baglam.Bolum_kodu;
      --   varchar_list(pn_1203_istatistik_kod)         := ls_istatistik_kodu; --sevalb 260507
      ln_borc_musteri_no := Pkg_Hesap.HesaptanMusteriNoAl(ln_borclu_hesap_no);
      if PKG_TX1203.sf_istatistikkod_zorunlumu(ln_borc_musteri_no, ls_doviz_kodu) = 'E' then
          varchar_list(pn_1203_istatistik_kod_borc) := pkg_musteri.paymentkod_formatli_al(ln_borc_musteri_no, ls_istatistik_kodu);
      else
          varchar_list(pn_1203_istatistik_kod_borc) := null;
      end if;

      ln_alacak_musteri_no := Pkg_Hesap.HesaptanMusteriNoAl(ln_alacak_hesap_no);
      if PKG_TX1203.sf_istatistikkod_zorunlumu(ln_alacak_musteri_no, ls_doviz_kodu) = 'E' then
          varchar_list(pn_1203_istatistik_kod_alacak) := pkg_musteri.paymentkod_formatli_al(ln_alacak_musteri_no, ls_istatistik_kodu);
      else
          varchar_list(pn_1203_istatistik_kod_alacak) := null;
      end if;
      --B-O-M ernestk 16042014 cqdb864 does the money transferred to their staff
      select decode(company_of_the_staff, ln_borc_musteri_no, 'E', 'H')
      into ls_transfered_to_staff
      from cbs.cbs_musteri
      where musteri_no = ln_alacak_musteri_no;--ernestk cqdb00000864

      boolean_list(pn_1203_SF_WTH_TRAN) := FALSE;
      --E-O-M ernestk 16042014 cqdb864 does the money transferred to their staff
      if ls_doviz_kodu = pkg_genel.LC_al then
          boolean_list(pn_1203_FC_TRAN) := FALSE;
          boolean_list(pn_1203_LC_TRAN) := TRUE;
      else
          boolean_list(pn_1203_FC_TRAN) := TRUE;
          boolean_list(pn_1203_LC_TRAN) := FALSE;
          --B-O-M ernestk 16062014 cqdb864 charging the commission when company makes fc tran to staff
          IF (ls_transfered_to_staff = 'E' and instr(ls_customers_that_pay_wthcomm, ln_borc_musteri_no || ';') > 0) THEN
              boolean_list(pn_1203_SF_WTH_TRAN) := TRUE;

              select il_kodu into ls_alacak_il_kodu from cbs.cbs_bolum where kodu = ls_alacak_hesap_sube_kodu;

              IF ls_alacak_il_kodu = '003' THEN -- BISHKEK region
                  ln_wth_rate := to_number(ls_bishrg_rate, '9999999999.99');
              ELSE
                  ln_wth_rate := to_number(ls_othrrg_rate, '9999999999.99');
              END IF;

              varchar_list(pn_1203_SF_WTH_COMM_DSC) := 'Коммиссия за обналичивание с ATM';
              number_list(pn_1203_SF_WTH_FC_CHARGE) := round(((nvl(ln_tutar, 0) * nvl(ln_wth_rate, 0)) / 100), 2);
              number_list(pn_1203_SF_WTH_LC_CHARGE) := round(nvl(pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu, pkg_genel.LC_AL, null, number_list(pn_1203_SF_WTH_FC_CHARGE), 1, null, null, 'N', 'A'), 0), 2);

              varchar_list(pn_1203_SF_WTH_TAX_DSC) := 'НСП за коммиссия за обналичивание - ' || ln_service_tax_rate || '% Sales Tax';
              number_list(pn_1203_SF_WTH_TAX_LC_AMOUNT) := round(((nvl(ln_service_tax_rate, 0) * nvl(number_list(pn_1203_SF_WTH_LC_CHARGE), 0)) / 100), 2);
              number_list(pn_1203_SF_WTH_TAX_FC_AMOUNT) := round(pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL, ls_doviz_kodu, null, number_list(pn_1203_SF_WTH_TAX_LC_AMOUNT), 1, null, null, 'N', 'A'), 2);
              END IF;
          --E-O-M ernestk 16062014 cqdb864 charging the commission when company makes fc tran to staff
          end if;
      varchar_list(pn_1203_GL_CHARGE) := Pkg_Muhasebe.Komisyon_DK_Bul(Pkg_Musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.HesaptanMusteriNoAl(ln_borclu_hesap_no)), 'INTRABTRAN');
      number_list(pn_1203_FC_CHARGE) := ln_charge_amount;
      number_list(pn_1203_LC_CHARGE) := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu, pkg_genel.LC_AL, null, ln_charge_amount, 1, null, null, 'N', 'A');

      /**** number list ****/
      number_list(pn_1203_fc_tutar) := ln_tutar;
      number_list(pn_1203_lc_tutar) := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu, pkg_genel.LC_AL, null, ln_tutar, 1, null, null, 'N', 'A');
      number_list(pn_1203_kur_lc) := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu, pkg_genel.LC_AL, null, 1, 1, null, null, 'N', 'A');
      number_list(pn_1203_SERVICE_TAX_FC) := 0;
      number_list(pn_1203_SERVICE_TAX_LC) := 0;

      --    if ls_musteri_tipi_kod = '1' then
--    number_list(pn_1203_SERVICE_TAX_FC) := pkg_kur.yuvarla(ls_doviz_kodu,(  nvl(ln_service_tax_rate,0)*  nvl(  number_list(pn_1203_FC_CHARGE),0) )  /100 );
--    number_list(pn_1203_SERVICE_TAX_LC) :=pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,  number_list(pn_1203_SERVICE_TAX_FC),1,null,null,'N','A'));

      number_list(pn_1203_SERVICE_TAX_LC) := round(((nvl(ln_service_tax_rate, 0) * nvl(number_list(pn_1203_LC_CHARGE), 0)) / 100), 2);
      number_list(pn_1203_SERVICE_TAX_FC) := round((number_list(pn_1203_SERVICE_TAX_LC) / number_list(pn_1203_kur_lc)), 2);
      --  end if;

      --BOM YadgarB CBS-838
      IF ls_alacak_musteri_tipi_kod in ('2', '3') AND
         ls_alacak_hesap_no_doviz = pkg_genel.lc_al AND
         ls_urun_sinif_kod = 'INTERNET OTHER LC' AND
         nvl(ls_qr_flag, '0') = '1' THEN
        boolean_list(pn_1203_BENEFICIARY_QR_COMMISSION) := TRUE;
        CBS.PKG_PARAMETRE.deger('1203_BENEFICIARY_COMM_RATE', ln_commission_rate);

        ln_commission := round(((nvl(ln_commission_rate, 0) * nvl(ln_tutar, 0)) / 100), 2);
        ln_tax := round(((nvl(ln_service_tax_rate, 0) * nvl(ln_commission, 0)) / 100), 2);

        number_list(pn_1203_QR_COMM_TAX_AMOUNT) := ln_commission + ln_tax;
        number_list(pn_1203_QR_COMM_AMOUNT) := ln_commission;
        number_list(pn_1203_QR_TAX_AMOUNT) := ln_tax;

        CBS.PKG_PARAMETRE.deger('QR_BENEFICIARY_COMM_TAX_EXPL',ls_comm_tax_expl);
        varchar_list(pn_1203_QR_COMM_TAX_DESCR) := substr(utl_lms.format_message(ls_comm_tax_expl, to_char(nvl(ln_service_tax_rate, 0)), to_char(ln_alacak_musteri_no), PKG_MUSTERI.sf_musteri_adi(ln_alacak_musteri_no), to_char(SYSDATE, 'dd/mm/yyyy')), 1, 2000);
        CBS.PKG_PARAMETRE.deger('QR_BENEFICIARY_COMM_EXPL',ls_comm_expl);
        varchar_list(pn_1203_QR_COMM_DESCR) := substr(utl_lms.format_message(ls_comm_expl, to_char(ln_alacak_musteri_no), PKG_MUSTERI.sf_musteri_adi(ln_alacak_musteri_no), to_char(SYSDATE, 'dd/mm/yyyy')), 1, 2000);
        CBS.PKG_PARAMETRE.deger('QR_BENEFICIARY_TAX_EXPL',ls_tax_expl);
        varchar_list(pn_1203_QR_TAX_DESCR) := substr(utl_lms.format_message(ls_tax_expl, to_char(nvl(ln_service_tax_rate, 0)), to_char(ln_alacak_musteri_no), PKG_MUSTERI.sf_musteri_adi(ln_alacak_musteri_no), to_char(SYSDATE, 'dd/mm/yyyy')), 1, 2000);
      END IF;
      --EOM YadgarB CBS-838

/*
Since all incomes are calculated in KGS, tax also should be accrued in KGS,
For example:
Commission charged from customer 1.50 USD
Income will be calculated as follows: 1.50 * 39.41 = 59.12 KGS
Tax will be: 59.12 * 2.5% = 1.48 KGS
Formula, which you apply, 1.50*2.5/100*39.41=1.58 kgs
Can not be applicable for tax calculation
*/

      /**** date list ****/

      /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
      ln_fis_no := pkg_muhasebe.fis_kes(ls_islem_kod,
                                        ln_plan_no,
                                        pn_islem_no,
                                        varchar_list,
                                        number_list,
                                        date_list,
                                        boolean_list,
                                        null,
                                        false,
                                        0,
                                        ls_fis_aciklama);

      pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

      --bom bahianab cbs-113 18032021
      pkg_notif_sub.sf_generate_notif(pn_islem_no, ls_islem_kod);
      --eom bahianab cbs-113 18032021

  Exception
      When Others Then
          Raise_application_error(-20100, pkg_hata.getUCPOINTER || '441' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

BEGIN
  pn_1203_doviz_kod :=pkg_muhasebe.parametre_index_bul('1203_DOVIZ_KOD');
  pn_1203_lc_tutar :=pkg_muhasebe.parametre_index_bul('1203_LC_TUTAR');
  pn_1203_fc_tutar :=pkg_muhasebe.parametre_index_bul('1203_FC_TUTAR');
  pn_1203_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1203_BANKA_ACIKLAMA');
  pn_1203_borclu_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1203_BORCLU_HESAP_SUBE_KODU');
  pn_1203_borclu_hesap_no :=pkg_muhasebe.parametre_index_bul('1203_BORCLU_HESAP_NO');
  pn_1203_alacak_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1203_ALACAK_HESAP_SUBE_KODU');
  pn_1203_alacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1203_ALACAK_HESAP_NO');
  pn_1203_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1203_MUSTERI_ACIKLAMA');
  pn_1203_referans :=pkg_muhasebe.parametre_index_bul('1203_REFERANS');
  pn_1203_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1203_FIS_ACIKLAMA');
  pn_1203_kur_lc :=pkg_muhasebe.parametre_index_bul('1203_KUR_LC');
  pn_1203_istatistik_kod_BORC :=pkg_muhasebe.parametre_index_bul('1203_ISTATISTIK_KOD_BORC');
  pn_1203_istatistik_kod_ALACAK :=pkg_muhasebe.parametre_index_bul('1203_ISTATISTIK_KOD_ALACAK');
  pn_1203_LC_CHARGE:=pkg_muhasebe.parametre_index_bul('1203_LC_CHARGE');
  pn_1203_FC_CHARGE:=pkg_muhasebe.parametre_index_bul('1203_FC_CHARGE');
  pn_1203_GL_CHARGE:=pkg_muhasebe.parametre_index_bul('1203_GL_CHARGE');
  pn_1203_FC_TRAN:=pkg_muhasebe.parametre_index_bul('1203_FC_TRAN');
  pn_1203_LC_TRAN:=pkg_muhasebe.parametre_index_bul('1203_LC_TRAN');
  pn_1203_SERVICE_TAX_LC:=pkg_muhasebe.parametre_index_bul('1203_SERVICE_TAX_LC');
  pn_1203_SERVICE_TAX_FC:=pkg_muhasebe.parametre_index_bul('1203_SERVICE_TAX_FC');
  pn_1203_AMIR_SUBE:=pkg_muhasebe.parametre_index_bul('1203_AMIR_SUBE');
  pn_1203_TAX_ACIKLAMA:=pkg_muhasebe.parametre_index_bul('1203_TAX_ACIKLAMA');
    --B-O-M ernestk cqdb00000864
    pn_1203_SF_WTH_CUSTS_NO      :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_CUSTS_NO');
    pn_1203_SF_WTH_TRAN          :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_TRAN');
    pn_1203_SF_WTH_FC_CHARGE     :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_FC_CHARGE');
    pn_1203_SF_WTH_LC_CHARGE     :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_LC_CHARGE');
    pn_1203_SF_WTH_COMM_GL       :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_COMM_GL');
    pn_1203_SF_WTH_COMM_DSC      :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_COMM_DSC');
    pn_1203_SF_WTH_TAX_LC_AMOUNT  :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_TAX_LC_AMOUNT');
    pn_1203_SF_WTH_TAX_FC_AMOUNT  :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_TAX_FC_AMOUNT');
    pn_1203_SF_WTH_TAX_DSC        :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_TAX_DSC');
    pn_1203_SF_WTH_BISHRG_RATE    :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_BISHRG_RATE');
    pn_1203_SF_WTH_OTHRRG_RATE    :=pkg_muhasebe.parametre_index_bul('1203_SF_WTH_OTHRRG_RATE');
    --E-O-M ernestk cqdb00000864

  --BOM YadgarB CBS-838
  pn_1203_BENEFICIARY_QR_COMMISSION := pkg_muhasebe.parametre_index_bul('1203_BENEFICIARY_QR_COMMISSION');
  pn_1203_QR_COMM_TAX_AMOUNT := pkg_muhasebe.parametre_index_bul('1203_QR_COMM_TAX_AMOUNT');
  pn_1203_QR_COMM_AMOUNT := pkg_muhasebe.parametre_index_bul('1203_QR_COMM_AMOUNT');
  pn_1203_QR_TAX_AMOUNT := pkg_muhasebe.parametre_index_bul('1203_QR_TAX_AMOUNT');
  pn_1203_QR_COMM_TAX_DESCR := pkg_muhasebe.parametre_index_bul('1203_QR_COMM_TAX_DESCR');
  pn_1203_QR_COMM_DESCR := pkg_muhasebe.parametre_index_bul('1203_QR_COMM_DESCR');
  pn_1203_QR_TAX_DESCR := pkg_muhasebe.parametre_index_bul('1203_QR_TAX_DESCR');
  --EOM YadgarB CBS-838
END;
/

