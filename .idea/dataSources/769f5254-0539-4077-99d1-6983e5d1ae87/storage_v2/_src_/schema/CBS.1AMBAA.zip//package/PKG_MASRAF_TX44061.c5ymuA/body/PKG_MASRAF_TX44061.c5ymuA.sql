create PACKAGE BODY     pkg_masraf_tx44061  IS
p_44060_HABR_TRL number;                --HABERLE?ME TRL
p_44060_POSTA_TRL number;            --POSTA MASRAFI TRL
p_44060_KOM_TOPLAMI number;            --TOPLAM TRL MASRAF
p_44060_M_HESAP number;                --MASRAF HESAP NO
p_44060_M_HESAP_DVZ number;          --MASRAF HESAP TRL DE??L
p_44060_MHESAP_SUBE number;          --MASRAF HESABININ ?UBES?
p_44060_ISLEM_SUBE number;            --??LEM YAPILAN ?UBE
p_44060_TEYIT_MDV number;            --TEYIT MASRAF HESAP D?V?Z? KARSILI?I
p_44060_IHBAR_MDV number;            --?HBAR MASRAF HESAP D?V?Z? KAR?ILI?I
p_44060_HABR_MDV number;                --HABERLE?ME MASRAF HESAP D?V?Z? KAR?ILI?I
p_44060_POSTA_MDV number;               --POSTA MASRAF HESAP D?V?Z? KAR?ILI?I
p_44060_KOM_MDV_TOPLAM number;       --TOPLAM MASRAF, MASRAF HESAP D?V?Z? KAR?ILI?I
p_44060_MAS_ACIKLAMA number;         --ANA F?? A?IKLAMASI
p_44060_MAS_TEY_ACIKLAMA number;     --TEYIT BOLUM A?IKLAMASI
p_44060_MAS_HABR_ACIKLAMA number;    --HABR BOLUM A?IKLAMASI
p_44060_MAS_IHBAR_ACIKLAMA number;   --IHBAR BOLUM A?IKLAMASI
p_44060_MAS_POST_ACIKLAMA number;    --POSTA BOLUM A?IKLAMASI
p_44060_KUR_TUTAR number;            --KUR B?LG?S?
p_44060_TEYIT_VAR number;            --TEYIT MASRAFI VAR
p_44060_IHBAR_VAR number;            --IHBAR MASRAFI VAR
p_44060_HABR_VAR number;                --HABERLE?ME MASRAFI VAR
p_44060_POSTA_VAR number;            --POSTA MASRAFI VAR
p_44060_M_HESAP_TRL number;            --MASRAF HESAP TRL
p_44060_MHESAP_DVZ number;            --MASRAF HESABININ D?V?Z?
p_44060_TEYIT_TRL number;            --TEYIT TRL KARSILI?I
p_44060_IHBAR_TRL number;            --IHBAR TRL KARSILIK
p_44060_MAS_TP_ANA number;            --ANA MASRAF HESABI
p_44060_MAS_YP_ANA number;            --ANA MASRAF HESABI
p_44060_KOMISYON_DK number;

p_44060_VERGIDEN_MUAF_DEGIL          NUMBER;
p_44060_LC_SERVICE_TAX   NUMBER;
p_44060_FC_SERVICE_TAX   NUMBER;
/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
      null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
   pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'RECGUARCOM');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
      Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is        -- Islem iptal edilemez
  begin
    null;
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list              pkg_muhasebe.varchar_array;
   number_list              pkg_muhasebe.number_array;
   date_list              pkg_muhasebe.date_array;
   boolean_list              pkg_muhasebe.boolean_array;
   ln_fis_no              number;
   ls_referans               varchar2(16);
   ls_sube                  varchar2(10);
   ls_akr_doviz           varchar2(3);
   lb_taksit_var          boolean := false;
   ln_son_bakiye          number := 0;
   ln_borc_tutar          number := 0;
   ln_borc_trl              number := 0;
   ln_eski_tahsil_tutar      number;
   ln_tahsil_tutar          number;

    ln_ser_tax   number:=0;
   cursor cur_masraf is
    select *
      from cbs_masraf_ith_ihr_isl
     where islem_no = pn_islem_no
     order by sira_no
    for update;
    row_masraf cur_masraf%rowtype;

   cursor cur_akr is
     select * from cbs_tm_alinan_garanti_islem
      where tx_no = pn_islem_no;
     row_akr cur_akr%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
      where islem_no = pn_islem_no --referans = ls_referans
        and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
        and nvl(odenen_tutar,0) < taksit_tutari
     for update;
   row_taksit cur_taksitler%rowtype;

  Begin
    ln_fis_no := pn_fis_no;
    open cur_akr;
    fetch cur_akr into row_akr;
     ls_akr_doviz := row_akr.doviz_kodu;
     varchar_list(p_44060_M_HESAP) := row_akr.masraf_hesap_no;
----------
      if row_akr.masraf_hesap_no is not null then
        varchar_list(p_44060_MHESAP_DVZ):= pkg_hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
        varchar_list(p_44060_MHESAP_SUBE) := pkg_hesap.HesapSubeAl(row_akr.masraf_hesap_no);
         if pkg_musteri.musteri_vergiden_muafmi(pkg_hesap.HesaptanMusteriNoAl(varchar_list(p_44060_M_HESAP))) = 'E'
         then
            boolean_list(p_44060_VERGIDEN_MUAF_DEGIL) := FALSE ;
         else
            boolean_list(p_44060_VERGIDEN_MUAF_DEGIL) := TRUE ;
         end if;
       number_list(p_44060_KUR_TUTAR) :=Pkg_Kur.mb_dak_to_lc(varchar_list(p_44060_MHESAP_DVZ),1);
      else
          varchar_list(p_44060_MHESAP_DVZ):='';
          varchar_list(p_44060_MHESAP_SUBE) :='';
     end if;
-----------
     varchar_list(p_44060_ISLEM_SUBE) := pkg_tx.Islem_BolumKodu_Al(pn_islem_no);
     ls_referans := row_akr.referans;
    close cur_akr;
    if varchar_list(p_44060_MHESAP_DVZ) = pkg_genel.LC_AL then
     boolean_list(p_44060_M_HESAP_TRL) := TRUE;
     boolean_list(p_44060_M_HESAP_DVZ) := FALSE;
    else
     boolean_list(p_44060_M_HESAP_TRL) := FALSE;
     boolean_list(p_44060_M_HESAP_DVZ) := TRUE;
    end if;
    boolean_list(p_44060_MAS_TP_ANA) := FALSE;
    boolean_list(p_44060_MAS_YP_ANA) := FALSE;
    number_list(p_44060_HABR_TRL) := 0;
    number_list(p_44060_HABR_MDV) := 0;
    varchar_list(p_44060_MAS_HABR_ACIKLAMA) := '';
    boolean_list(p_44060_HABR_VAR) := FALSE;
    number_list(p_44060_POSTA_TRL) := 0;
    number_list(p_44060_POSTA_MDV) := 0;
    varchar_list(p_44060_MAS_POST_ACIKLAMA) := '';
    boolean_list(p_44060_POSTA_VAR) := FALSE;
    number_list(p_44060_TEYIT_TRL) := 0;
    number_list(p_44060_TEYIT_MDV) := 0;
    varchar_list(p_44060_MAS_TEY_ACIKLAMA) := '';
    boolean_list(p_44060_TEYIT_VAR) := FALSE;
    number_list(p_44060_IHBAR_TRL) := 0;
    number_list(p_44060_IHBAR_MDV) := 0;
    varchar_list(p_44060_MAS_IHBAR_ACIKLAMA) := '';
    boolean_list(p_44060_IHBAR_VAR) := FALSE;

    number_list(p_44060_LC_SERVICE_TAX) := 0;
    number_list(p_44060_FC_SERVICE_TAX) := 0;

    number_list(p_44060_KOM_TOPLAMI) := 0;
    number_list(p_44060_KOM_MDV_TOPLAM) := 0;   
--CQ1405 if lehdar_musteri_no is null VictorK
if row_akr.LEHDAR_MUSTERI_NO is null then
varchar_list(p_44060_MAS_ACIKLAMA) := row_akr.REFERANS
                                   ||' Customer No:'||row_akr.PRINCIPAL_TITLE ;
else
    varchar_list(p_44060_MAS_ACIKLAMA) := row_akr.REFERANS
                                   ||' Customer No:'||row_akr.LEHDAR_MUSTERI_NO
                                   ||' -'||Pkg_Musteri.Sf_Musteri_Adi(row_akr.LEHDAR_MUSTERI_NO);
end if;
    --varchar_list(p_44060_MAS_ACIKLAMA) := row_akr.REFERANS
    --||' Customer No:'||row_akr.LEHDAR_MUSTERI_NO
    --||' -'||pkg_musteri.Sf_Musteri_Adi(row_akr.LEHDAR_MUSTERI_NO);
--masraf al?nacak hesab?n bakiyesini al
ln_son_bakiye := pkg_hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_44060_M_HESAP));  
 --CQ1405 if musteri_no is null VictorK   
if row_akr.LEHDAR_MUSTERI_NO is null then
varchar_list(p_44060_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(null,'RECGUARCOM');
else
varchar_list(p_44060_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_akr.LEHDAR_MUSTERI_NO),'RECGUARCOM');
end if;
--varchar_list(p_44060_KOMISYON_DK) :=pkg_muhasebe.Komisyon_DK_Bul(pkg_musteri.sf_musteri_dk_grup_kod_al(row_akr.LEHDAR_MUSTERI_NO),'RECGUARCOM');




    open cur_masraf;
    loop
      fetch cur_masraf into row_masraf;
      exit when cur_masraf%notfound;
      boolean_list(p_44060_TEYIT_VAR) := FALSE;
      boolean_list(p_44060_IHBAR_VAR) := FALSE;
      boolean_list(p_44060_HABR_VAR) := FALSE;
      boolean_list(p_44060_POSTA_VAR) := FALSE;
      if nvl(row_masraf.tahsil_edilemeyen,0) > 0  then
          if row_masraf.ODEYECEK = 'BENEF.'
             AND boolean_list(p_44060_VERGIDEN_MUAF_DEGIL)
          then
              ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
/*              if row_masraf.masraf_kodu = 'LCACIHBAR'  then     --ihbar masraf?
    --masraflar akreditif kurunda, onlar? masraf hesab?n?n kuruna ?evirmek gerekli......
                if boolean_list(p_44060_M_HESAP_TRL) then
                   number_list(p_44060_IHBAR_TRL) := pkg_komisyon_kur.KUR_to_LC(ls_akr_doviz, ln_tahsil_tutar);
                   number_list(p_44060_IHBAR_MDV) := number_list(p_44060_IHBAR_TRL);
                else
                   number_list(p_44060_IHBAR_MDV) := pkg_kur.yuvarla(varchar_list(p_44060_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44060_MHESAP_DVZ), null,
                                                    ln_tahsil_tutar, 1, null, null, 'O', 'A'));

                   number_list(p_44060_IHBAR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.dak_to_lc(varchar_list(p_44060_MHESAP_DVZ),number_list(p_44060_IHBAR_MDV)));
                end if;
  --bu iki de?i?ken ile hesab?n ?demeyi alabilmek i?in yeterli olup olmad??? ara?t?r?lacak
  --e?er yeterli miktar varsa, toplam sat?r i?in toplanacak
                ln_borc_tutar := number_list(p_44060_IHBAR_MDV);
                ln_borc_trl := number_list(p_44060_IHBAR_TRL);
                varchar_list(p_44060_MAS_IHBAR_ACIKLAMA) := '?HBAR MASRAFLARI';
                boolean_list(p_44060_IHBAR_VAR) := TRUE;
*/
              if row_masraf.masraf_kodu = 'TMALGARHAB'  then   --haberle?me
                   number_list(p_44060_HABR_MDV) := pkg_kur.yuvarla(varchar_list(p_44060_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44060_MHESAP_DVZ), null,ln_tahsil_tutar, 1, null, null, 'O', 'A'));
                   number_list(p_44060_HABR_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.mb_dak_to_lc(varchar_list(p_44060_MHESAP_DVZ),number_list(p_44060_HABR_MDV)));

                ln_borc_tutar := number_list(p_44060_HABR_MDV);
                ln_borc_trl := number_list(p_44060_HABR_TRL);

                varchar_list(p_44060_MAS_HABR_ACIKLAMA) := 'HABERLE?ME MASRAFLARI';
                boolean_list(p_44060_HABR_VAR) := TRUE;

                number_list(p_44060_LC_SERVICE_TAX):=number_list(p_44060_LC_SERVICE_TAX)+ln_borc_trl;
              elsif row_masraf.masraf_kodu = 'TMALGARPOS' then   --posta
               number_list(p_44060_POSTA_MDV) := pkg_kur.yuvarla(varchar_list(p_44060_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44060_MHESAP_DVZ), null,ln_tahsil_tutar, 1, null, null, 'O', 'A'));
               number_list(p_44060_POSTA_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.mb_dak_to_lc(varchar_list(p_44060_MHESAP_DVZ),number_list(p_44060_POSTA_MDV)));

                ln_borc_tutar := number_list(p_44060_POSTA_MDV);
                ln_borc_trl := number_list(p_44060_POSTA_TRL);

                varchar_list(p_44060_MAS_POST_ACIKLAMA) := 'POSTA MASRAFLARI';
                boolean_list(p_44060_POSTA_VAR) := TRUE;

                number_list(p_44060_LC_SERVICE_TAX):=number_list(p_44060_LC_SERVICE_TAX)+ln_borc_trl;
              elsif row_masraf.masraf_kodu =  'RECGUARCOM' then  --teyit TAKS?TL? OLUR
                ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
                if row_masraf.hesaplanan <= ln_eski_tahsil_tutar  then
                   ln_tahsil_tutar := 0;
                else
                      boolean_list(p_44060_TEYIT_VAR) := TRUE;
                      lb_taksit_var := true;
                      open cur_taksitler;
                      loop
                        fetch cur_taksitler into row_taksit;
                        exit when cur_taksitler%notfound;
                          number_list(p_44060_TEYIT_MDV) := pkg_kur.yuvarla(varchar_list(p_44060_MHESAP_DVZ),pkg_kur.DOVIZ_DOVIZ_KARSILIK(ls_akr_doviz, varchar_list(p_44060_MHESAP_DVZ), null,row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0), 1, null, null, 'O', 'A'));
                          number_list(p_44060_TEYIT_TRL) := pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.mb_dak_to_lc(varchar_list(p_44060_MHESAP_DVZ),number_list(p_44060_TEYIT_MDV)));

                        varchar_list(p_44060_MAS_TEY_ACIKLAMA) := row_akr.referans||' '||row_taksit.taksit_no || '. Installment';
                        ln_borc_tutar := number_list(p_44060_TEYIT_MDV);
                        ln_borc_trl := number_list(p_44060_TEYIT_TRL);
                        if ln_son_bakiye >= ln_borc_tutar then
                            boolean_list(p_44060_TEYIT_VAR) := TRUE;
                            ln_fis_no:=pkg_muhasebe.fis_kes ( 44060, null, pn_islem_no, varchar_list, number_list,
                                                                date_list, boolean_list, null, false, ln_fis_no, null);

                            update cbs_masraf_ith_ihr_isl
                               set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
                                   tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
                             where current of cur_masraf;

                                pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

                            update cbs_masraf_taksit_islem
                               set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
                                   odenen_tutar = taksit_tutari
                             where current of cur_taksitler;

                           pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
                                                               row_masraf.masraf_kodu, row_masraf.vs_no,
                                                               row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
                                                                    number_list(p_44060_TEYIT_TRL), row_akr.masraf_hesap_no,
                                                               row_akr.vade_tarihi, nvl(row_akr.vadeli,'E'));

                            ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                            number_list(p_44060_KOM_TOPLAMI) := number_list(p_44060_KOM_TOPLAMI) + ln_borc_trl;
                            number_list(p_44060_KOM_MDV_TOPLAM) := number_list(p_44060_KOM_MDV_TOPLAM) + ln_borc_tutar;
                        end if;
                      end loop;
                      close cur_taksitler;
                    end if; --komisyon tipi
                 else
                    close cur_masraf;
                  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
                end if; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
                  end if;
              if not lb_taksit_var then
               if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle       
                 if ln_tahsil_tutar <> 0 then
                     ln_fis_no:=pkg_muhasebe.fis_kes ( 44060, null, pn_islem_no, varchar_list,
                                                    number_list, date_list, boolean_list,
                                                    null, false, ln_fis_no, null);
                      pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);
                      update cbs_masraf_ith_ihr_isl
                         set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
                             tahsil_edilemeyen = row_masraf.hesaplanan - ln_tahsil_tutar
                       where current of cur_masraf;
                      ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
                      number_list(p_44060_KOM_TOPLAMI) := number_list(p_44060_KOM_TOPLAMI) + ln_borc_trl;
                      number_list(p_44060_KOM_MDV_TOPLAM) := number_list(p_44060_KOM_MDV_TOPLAM) + ln_borc_tutar;

               end if;
              end if;
           end if; --ihracat?? ?demesi
      end if;  --tahsil edilmeyen var....

    end loop;
    close cur_masraf;
    if number_list(p_44060_KOM_MDV_TOPLAM) > 0 then
       boolean_list(p_44060_TEYIT_VAR) := FALSE;
       boolean_list(p_44060_IHBAR_VAR) := FALSE;
       boolean_list(p_44060_HABR_VAR) := FALSE;
       boolean_list(p_44060_POSTA_VAR) := FALSE;
       if boolean_list(p_44060_M_HESAP_TRL) then
          boolean_list(p_44060_MAS_TP_ANA) := TRUE;
       else
          boolean_list(p_44060_MAS_YP_ANA) := TRUE;
       end if;

        pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_ser_tax);

        number_list(p_44060_FC_SERVICE_TAX):=Pkg_Kur.yuvarla(varchar_list(p_44060_MHESAP_DVZ),(number_list(p_44060_LC_SERVICE_TAX)/number_list(p_44060_KUR_TUTAR)));
        number_list(p_44060_LC_SERVICE_TAX):=(number_list(p_44060_LC_SERVICE_TAX)* ln_ser_tax)/100;
        number_list(p_44060_FC_SERVICE_TAX):=(number_list(p_44060_FC_SERVICE_TAX)* ln_ser_tax)/100;

       ln_fis_no:=pkg_muhasebe.fis_kes ( 44060,
                                             null,
                                             pn_islem_no,
                                            varchar_list ,
                                            number_list  ,
                                            date_list    ,
                                            boolean_list ,
                                            null,
                                           false,
                                            ln_fis_no,
                                            null);
    end if;
    pn_fis_no := ln_fis_no;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
       pkg_masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, null);
   end;



 Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
     ln_temp number;
     begin
       select count(*)
         into ln_temp
         from cbs_masraf_ith_ihr_isl
        where islem_no = pn_islem_no
          and odeyecek = 'LEHDAR';
       if ln_temp > 0 then
         return 'E';
       else
         return 'H';
       end if;
 end;



/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
    p_44060_HABR_TRL := pkg_muhasebe.parametre_index_bul('44060_HABR_TRL');
    p_44060_POSTA_TRL := pkg_muhasebe.parametre_index_bul('44060_POSTA_TRL');
    p_44060_KOM_TOPLAMI := pkg_muhasebe.parametre_index_bul('44060_KOM_TOPLAMI');
    p_44060_M_HESAP := pkg_muhasebe.parametre_index_bul('44060_M_HESAP');
    p_44060_M_HESAP_DVZ := pkg_muhasebe.parametre_index_bul('44060_M_HESAP_DVZ');
    p_44060_MHESAP_SUBE := pkg_muhasebe.parametre_index_bul('44060_MHESAP_SUBE');
    p_44060_ISLEM_SUBE := pkg_muhasebe.parametre_index_bul('44060_ISLEM_SUBE');
    p_44060_TEYIT_MDV := pkg_muhasebe.parametre_index_bul('44060_TEYIT_MDV');
    p_44060_IHBAR_MDV := pkg_muhasebe.parametre_index_bul('44060_IHBAR_MDV');
    p_44060_HABR_MDV := pkg_muhasebe.parametre_index_bul('44060_HABR_MDV');
    p_44060_POSTA_MDV := pkg_muhasebe.parametre_index_bul('44060_POSTA_MDV');
    p_44060_KOM_MDV_TOPLAM := pkg_muhasebe.parametre_index_bul('44060_KOM_MDV_TOPLAM');
    p_44060_MAS_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44060_MAS_ACIKLAMA');
    p_44060_MAS_TEY_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44060_MAS_TEY_ACIKLAMA');
    p_44060_MAS_HABR_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44060_MAS_HABR_ACIKLAMA');
    p_44060_MAS_IHBAR_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44060_MAS_IHBAR_ACIKLAMA');
    p_44060_MAS_POST_ACIKLAMA := pkg_muhasebe.parametre_index_bul('44060_MAS_POST_ACIKLAMA');
    p_44060_KUR_TUTAR := pkg_muhasebe.parametre_index_bul('44060_KUR_TUTAR');
    p_44060_TEYIT_VAR := pkg_muhasebe.parametre_index_bul('44060_TEYIT_VAR');
    p_44060_IHBAR_VAR := pkg_muhasebe.parametre_index_bul('44060_IHBAR_VAR');
    p_44060_HABR_VAR := pkg_muhasebe.parametre_index_bul('44060_HABR_VAR');
    p_44060_POSTA_VAR := pkg_muhasebe.parametre_index_bul('44060_POSTA_VAR');
    p_44060_M_HESAP_TRL := pkg_muhasebe.parametre_index_bul('44060_M_HESAP_TRL');
    p_44060_MHESAP_DVZ := pkg_muhasebe.parametre_index_bul('44060_MHESAP_DVZ');
    p_44060_TEYIT_TRL := pkg_muhasebe.parametre_index_bul('44060_TEYIT_TRL');
    p_44060_IHBAR_TRL := pkg_muhasebe.parametre_index_bul('44060_IHBAR_TRL');
    p_44060_MAS_TP_ANA := pkg_muhasebe.parametre_index_bul('44060_MAS_TP_ANA');
    p_44060_MAS_YP_ANA := pkg_muhasebe.parametre_index_bul('44060_MAS_YP_ANA');
    p_44060_KOMISYON_DK:= pkg_muhasebe.parametre_index_bul('44060_KOMISYON_DK');

    p_44060_LC_SERVICE_TAX              := Pkg_Muhasebe.parametre_index_bul('44060_LC_SERVICE_TAX');
    p_44060_FC_SERVICE_TAX              := Pkg_Muhasebe.parametre_index_bul('44060_FC_SERVICE_TAX');
    p_44060_VERGIDEN_MUAF_DEGIL              := Pkg_Muhasebe.parametre_index_bul('44060_VERGIDEN_MUAF_DEGIL');
 END;
/

