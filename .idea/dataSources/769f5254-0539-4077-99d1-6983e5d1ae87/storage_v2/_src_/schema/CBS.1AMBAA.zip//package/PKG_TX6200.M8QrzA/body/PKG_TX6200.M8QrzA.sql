create PACKAGE BODY     pkg_tx6200 is
 pn_6200_islem_sube    number;
 pn_6200_hesap_sube    number;
 pn_6200_dk_hesap    number;
 pn_6200_musteri_hesap   number;
 pn_6200_banka_aciklama   number;
 pn_6200_referans    number;
 pn_6200_doviz_kodu    number;
 pn_6200_fc_tutar    number;
 pn_6200_lc_tutar    number;
 pn_6200_musteri_aciklama  number;
 pn_6200_hesap_turu    number;
 pn_6200_kur      number;
 pn_6200_islem_sekli_mh   number;
 pn_6200_islem_sekli_dk   number;
 pn_6200_tl      number;
 pn_6200_yp       number;
 pn_6200_valor      number;
 pn_6200_istatistik_kodu   number;
 pn_6200_nakit_kodu    number;
 pn_6200_cash_coll_amt_tax_lc number ;
 pn_6200_cash_coll_amount_fc  number ;
 pn_6200_cash_coll_amount_lc  number ;
 pn_6200_deposit_amount_fc  number ;
 pn_6200_deposit_amount_lc  number ;

 -- BOM NursultanT CBS-29
 pn_6200_deposit_amount_fc_r number;
 pn_6200_deposit_amount_lc_r number;
 -- EOM NursultanT CBS-29

 pn_6200_paid     number ;
 pn_6200_deducted    number ;
 pn_6200_cash_collection   number ;
 pn_6200_deposit     number ;
 pn_6200_lc_vergi    number ;
 pn_6200_fc_vergi    number ;
  -- BOM NursultanT CBS-29
 pn_6200_lc_tax    number ;
 pn_6200_fc_tax    number ;

 pn_6200_lc_tax_r  number;
 pn_6200_fc_tax_r  number;

 pn_6200_lc_round_d    number ;
 pn_6200_lc_round_c   number ;
 pn_6200_round    number ;
 -- EOM NursultanT CBS-29
 pn_6200_istatistik_kodu_kom  number ;
 pn_6200_dk_hesap_deposit  number ;
 pn_6200_dk_hesap_cash   number ;
 pn_6200_komisyon_referans  number ;
 pn_6200_dk_hesap_counting   number;
 pn_6200_cash_count_amount_lc  number;
 pn_6200_cash_count_amount_fc  number;
 pn_6200_cash_counting    number;
 pn_6200_commission_desc   number;
 pn_6200_desc_cashcoll   number;
 pn_6200_desc_counting   number;
 pn_6200_desc_vat    number;
  --Yerzhan Tanatov Outlet GL Modification 19.12.2009 
 pn_6200_g_dk_lc_cash_gl number;
 pn_6200_g_dk_fc_cash_gl number;
 -- BOM NursultanT CBS-29
 g_uc_delimiter        constant varchar2 (3) := pkg_hata.getucpointer;
 g_ara_delimiter       constant varchar2 (3) := pkg_hata.getdelimiter;
 -- EOM NursultanT CBS-29

 type cursorreferencetype is ref cursor;
 --*******************************************************************************************
 --*******************************************************************************************
 -- nursultanT CBS-29 
  function is_same_region (ps_hesap_no      cbs_hesap.hesap_no%type,
                            ps_bolum_kodu    cbs_bolum.kodu%type)
      return boolean
   is
      ls_sube_kodu    cbs_hesap.sube_kodu%type;
      ls_region_no1   cbs_bolum.region_no%type;
      ls_region_no2   cbs_bolum.region_no%type;
   begin
         -- Getting branch code from account table
      select sube_kodu
        into ls_sube_kodu
        from cbs_hesap
       where hesap_no = ps_hesap_no;

      -- getting region_no of the account
      select region_no
        into ls_region_no1
        from cbs_bolum
       where kodu = ls_sube_kodu;

      -- getting region_no of the brach
      select region_no
        into ls_region_no2
        from cbs_bolum
       where kodu = ps_bolum_kodu;

      if ls_region_no1 in (1, 2) and ls_region_no2 in (1, 2)
      then
         return true;
      elsif ls_region_no1 = ls_region_no2
      then
         return true;
      else
         return false;
      end if;
   exception
      when no_data_found
      then
         raise_application_error (
            -20100,
               g_uc_delimiter
            || '1131'
            || g_ara_delimiter
            || to_char (ps_hesap_no)
            || '-'
            || ps_bolum_kodu
            || g_uc_delimiter);
      when others
      then
         raise_application_error (
            -20100,
               g_uc_delimiter
            || '1132'
            || g_ara_delimiter
            || sqlerrm
            || g_uc_delimiter);
   end;
  --*******************************************************************************************
 function sf_hesap_urun_tipi_uygunmu(ps_urun_tur_kod cbs_hesap.urun_tur_kod%type ) return varchar2
   is
  ls_sonuc  varchar2(1) := 'E';
 begin
       if ps_urun_tur_kod in  ('NOSTRO-LC','NOSTRO-FC','SWAP','SWAP-FW','FORWARD','SPOT') then
      ls_sonuc := 'H' ;
  else
   ls_sonuc := 'E' ;
  end if;

  return ls_sonuc;
    exception
   when others then return 'E';
    end  sf_hesap_urun_tipi_uygunmu;
 --*******************************************************************************************
 function nakit_yatan_referansi_al return varchar2
  is
     ls_bolum_kodu       cbs_islem.kayit_kullanici_bolum_kodu%type;
     ls_nakit_yatan    cbs_cari_nakit_yatan.referans_no%type;
  ln_sira_no   number := 0;

  begin

  ls_bolum_kodu    := pkg_baglam.bolum_kodu ;
  ls_nakit_yatan  := to_char(pkg_muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || 'CNY' ;
  ln_sira_no      := pkg_genel.genel_kod_al(ls_nakit_yatan);
  ls_nakit_yatan  := ls_nakit_yatan || lpad(ln_sira_no,7,0);

   return ls_nakit_yatan;

 exception
   when others then
     raise_application_error(-20100,pkg_hata.getucpointer || '4532' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   end ;
  --*******************************************************************************************
  function sf_vergi_orani return number
   is
 begin

  return 2 ; --nursultanT CBS-29

  end  sf_vergi_orani;
 --*******************************************************************************************
 procedure kontrol_sonrasi(pn_islem_no number) is
 cursor c_nakit_yatan (pn_islemno cbs_islem.numara%type) is
 select tx_no, referans_no, durum_kodu, islem_sekli, musteri_no, hesap_no, doviz_kodu, dk_no, nvl(tutar,0) tutar,
     valor_tarihi, aciklama, islem_tarihi, nakit_kodu, prefix_istatistik_kodu, istatistik_kodu,
     nvl(nakit_yatan_komisyonu,0) nakit_yatan_komisyonu, nvl(nakit_yatan_tahsilat_komisyonu,0) nakit_yatan_tahsilat_komisyonu,
     prefix_istatistik_kodu_kom, istatistik_kodu_komisyon, komisyon_tahsil_sekli,
     nvl(toplam_tahsil_tutari,0) toplam_tahsil_tutari, nvl(cash_counting_comm,0) cash_counting_comm
 from   cbs_cari_nakit_yatan_islem
 where  tx_no    = pn_islemno;
 r_nakit  c_nakit_yatan%rowtype;
 ls_musteri_adi  varchar(2000);
 ls_komisyon_gl   varchar2(2000);
 ln_tutar            number;
 
 -- BOM nursultanT 10.10.2018 CBS-29
 ln_deposit_comm number := 0; 
 ln_sales_comm_rate number := 0;
 ln_tax number := 0;
 ln_total_amount number := 0;
 ln_round number := 0;
 -- EOM nursultanT 10.10.2018 CBS-29
 
begin
    open c_nakit_yatan(pn_islem_no);
 loop
     fetch c_nakit_yatan into r_nakit;
    exit when c_nakit_yatan%notfound;
   --KUPUR KONTROLLERI
   if r_nakit.komisyon_tahsil_sekli = 'PAID' then
   
    -- BOM nursultanT 10.10.2018 CBS-29
        ln_deposit_comm := r_nakit.nakit_yatan_komisyonu;
        pkg_parametre.deger ('G_SALES_TAX_RATE', ln_sales_comm_rate);
        ln_tax := ln_deposit_comm / 100 * ln_sales_comm_rate;
        if r_nakit.doviz_kodu = 'KGS' then
            ln_round := pkg_tx6201.commission_round_error(ln_deposit_comm) + pkg_tx6201.commission_round_error(ln_tax);

          -- if PKG_TX6201.Commission_Round_Error(ln_tax + ln_deposit_comm) = 0 THEN
          --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm) + PKG_TX6201.Commission_Round_Error(ln_tax);
          -- else
          --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm + ln_tax);
          -- end if;
          ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax + ln_round;
        else
          ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax;
        end if;
        -- EOM nursultanT 10.10.2018 CBS-29


    pkg_tx1601.kontrol_sonrasi(
      pn_islem_no,
      6200,
      ln_total_amount, -- nursultanT CBS-29
      r_nakit.doviz_kodu, 
      'Y'
      );
    
    else

    pkg_tx1601.kontrol_sonrasi(pn_islem_no ,6200,r_nakit.tutar,r_nakit.doviz_kodu,'Y');
    
    end if;
  begin
   --CASH SLIP HAZIRLAMACA
   if r_nakit.komisyon_tahsil_sekli is null or  r_nakit.komisyon_tahsil_sekli= 'DEDUCTED'  then
      --Komisyon alinmamis veya DEDUCTED secilmis demektir.
      if r_nakit.islem_sekli <> 'DK' then
         ls_musteri_adi  :=  pkg_musteri.sf_musteri_adi(r_nakit.musteri_no) ;
      else
         ls_musteri_adi := null;
      end if;

      pkg_cash_slip.cash_slip( pn_tx_no      => pn_islem_no,
          pn_islem_tipi      => 1, --deposit
          pd_islem_tarihi     => r_nakit.islem_tarihi,
          ps_islem_tipi_doviz_kodu  => r_nakit.doviz_kodu,
          pn_islem_kod     => 6200,
          pn_islem_tipi_tutari   => r_nakit.tutar,
          ps_aciklama      => r_nakit.aciklama,
          pn_musteri_hesap_no    => r_nakit.hesap_no,
          ps_gl_hesap_no      => r_nakit.dk_no,
          ps_musteri_adi      => ls_musteri_adi,
          ps_baglam_bolum     => pkg_baglam.bolum_kodu,
          pn_prefix_istatistik_kodu => r_nakit.prefix_istatistik_kodu,
          ps_istatistik_doviz_kodu  => r_nakit.doviz_kodu,
          ps_istatistik_kodu     => r_nakit.istatistik_kodu


            ) ;
    elsif r_nakit.komisyon_tahsil_sekli= 'PAID' then
      -- Bu durumda iki tane slip basacak
      if r_nakit.islem_sekli <> 'DK' then
         ls_musteri_adi  :=  pkg_musteri.sf_musteri_adi(r_nakit.musteri_no) ;
      else
         ls_musteri_adi := null;
      end if;
      --1.slip...ana tutar bilgileri ile olusturulacak
      pkg_cash_slip.cash_slip( pn_tx_no      => pn_islem_no,
          pn_islem_tipi      => 1, --deposit
          pd_islem_tarihi     => r_nakit.islem_tarihi,
          ps_islem_tipi_doviz_kodu  => r_nakit.doviz_kodu,
          pn_islem_tipi_tutari   => r_nakit.tutar,
          ps_aciklama      => r_nakit.aciklama,
          pn_islem_kod     => 6200,
          pn_musteri_hesap_no    => r_nakit.hesap_no,
          ps_gl_hesap_no      => r_nakit.dk_no,
          ps_musteri_adi      => ls_musteri_adi,
          ps_baglam_bolum     => pkg_baglam.bolum_kodu,
          pn_prefix_istatistik_kodu => r_nakit.prefix_istatistik_kodu,
          ps_istatistik_doviz_kodu  => r_nakit.doviz_kodu,
          ps_istatistik_kodu     => r_nakit.istatistik_kodu

            ) ;

      --2.slip...komisyon bilgileri ile olusturulacak.
      ls_komisyon_gl := pkg_muhasebe.komisyon_dk_bul( pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(r_nakit.hesap_no) ),'CASHDEPST');
      ln_tutar := r_nakit.toplam_tahsil_tutari - r_nakit.tutar; --r_nakit.NAKIT_YATAN_KOMISYONU + r_nakit.NAKIT_YATAN_TAHSILAT_KOMISYONU + r_nakit.CASH_COUNTING_COMM;
      
      -- BOM nursultanT  CBS-29
      pkg_parametre.deger ('G_SALES_TAX_RATE', ln_sales_comm_rate);
      ln_tax := ln_tutar / 100 * ln_sales_comm_rate;
      ln_total_amount := ln_tutar + ln_tax;
    
      if r_nakit.doviz_kodu = 'KGS' then 
          ln_total_amount := ln_tax + pkg_tx6201.commission_round_error(ln_tax) + ln_tutar  + pkg_tx6201.commission_round_error(ln_tutar);
        -- if PKG_TX6201.Commission_Round_Error(ln_total_amount) = 0 THEN
        --   ln_total_amount := ln_tax + PKG_TX6201.Commission_Round_Error(ln_tax) + ln_tutar  + PKG_TX6201.Commission_Round_Error(ln_tutar);
        -- else
        --   ln_total_amount := ln_total_amount + PKG_TX6201.Commission_Round_Error(ln_total_amount);
        -- end if;
      end if;

      -- EOM nursultanT  CBS-29


      pkg_cash_slip.cash_slip( pn_tx_no      => pn_islem_no,
          pn_islem_tipi      => 1, --withdrawal
          pd_islem_tarihi     => r_nakit.islem_tarihi,
          ps_islem_tipi_doviz_kodu  => r_nakit.doviz_kodu,
          pn_islem_tipi_tutari   => ln_total_amount,
          ps_aciklama      => 'comm + tax ' || ls_musteri_adi,--AndreiD CBS-385
          pn_islem_kod     => 6200,
          pn_musteri_hesap_no    => null,
          ps_gl_hesap_no      => ls_komisyon_gl ,
          ps_musteri_adi      => null,
          ps_baglam_bolum     => pkg_baglam.bolum_kodu,
          pn_prefix_istatistik_kodu => r_nakit.prefix_istatistik_kodu_kom,
          ps_istatistik_doviz_kodu  => r_nakit.doviz_kodu,
          ps_istatistik_kodu     => r_nakit.istatistik_kodu_komisyon

            ) ;


   end if;
      exception
      when others then
      pkg_cash_slip.delete_cash_slip( pn_tx_no   => pn_islem_no);
    end;
 end loop ;

    close c_nakit_yatan;
    pkg_black_list.chek_update(pn_islem_no);
end;
-------------------------------------------------------------------------
  procedure dogrulama_sonrasi(pn_islem_no number) is
 cursor c_nakit_yatan (pn_islemno cbs_islem.numara%type) is
 select doviz_kodu, tutar,komisyon_tahsil_sekli,toplam_tahsil_tutari,nvl(nakit_yatan_komisyonu,0) nakit_yatan_komisyonu
 from   cbs_cari_nakit_yatan_islem
 where  tx_no    = pn_islemno;

 r_nakit  c_nakit_yatan%rowtype;

  -- BOM nursultanT 10.10.2018 CBS-29
 ln_deposit_comm number := 0; 
 ln_sales_comm_rate number := 0;
 ln_tax number := 0;
 ln_total_amount number := 0;
 ln_round number := 0;
 -- EOM nursultanT 10.10.2018 CBS-29
  begin
    open c_nakit_yatan(pn_islem_no);
    loop
   fetch c_nakit_yatan into r_nakit;
   exit when c_nakit_yatan%notfound;

   if r_nakit.komisyon_tahsil_sekli = 'PAID' then

        -- BOM nursultanT 10.10.2018 CBS-29
        ln_deposit_comm := r_nakit.nakit_yatan_komisyonu;
        pkg_parametre.deger ('G_SALES_TAX_RATE', ln_sales_comm_rate);
        ln_tax := ln_deposit_comm / 100 * ln_sales_comm_rate;
        if r_nakit.doviz_kodu = 'KGS' then
            ln_round := pkg_tx6201.commission_round_error(ln_deposit_comm) + pkg_tx6201.commission_round_error(ln_tax);

          -- if PKG_TX6201.Commission_Round_Error(ln_tax + ln_deposit_comm) = 0 THEN
          --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm) + PKG_TX6201.Commission_Round_Error(ln_tax);
          -- else
          --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm + ln_tax);
          -- end if;
          ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax + ln_round;
        else
          ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax;
        end if;
        -- EOM nursultanT 10.10.2018 CBS-29

    pkg_tx1601.dogrulama_sonrasi(pn_islem_no ,6200,ln_total_amount,r_nakit.doviz_kodu,'Y');
   else
    pkg_tx1601.dogrulama_sonrasi(pn_islem_no ,6200,r_nakit.tutar,r_nakit.doviz_kodu,'Y');
   end if;


    end loop ;

    close c_nakit_yatan;
  end;
-------------------------------------------------------------------------
  procedure dogrulama_iptal_sonrasi(pn_islem_no number) is
  begin
   null;
  end;
-------------------------------------------------------------------------
  procedure iptal_reddetme_sonrasi(pn_islem_no number) is
  begin
   null;
  end;
-------------------------------------------------------------------------
  procedure iptal_sonrasi(pn_islem_no number) is
  begin
   null;
  end;
-------------------------------------------------------------------------
  procedure iptal_muhasebelestir_sonrasi(pn_islem_no number) is
  begin
    pkg_tx1601.iptal_muhasebelestir_sonrasi(pn_islem_no,6200);
  end;
-------------------------------------------------------------------------
 procedure onay_sonrasi(pn_islem_no number) is
 cursor c_nakit_yatan (pn_islemno cbs_islem.numara%type) is
     select doviz_kodu, tutar,komisyon_tahsil_sekli,toplam_tahsil_tutari, nvl(nakit_yatan_komisyonu,0) nakit_yatan_komisyonu


     from   cbs_cari_nakit_yatan_islem
     where  tx_no    = pn_islemno;

 r_nakit  c_nakit_yatan%rowtype;
 
   -- BOM nursultanT 10.10.2018 CBS-29
 ln_deposit_comm number := 0; 
 ln_sales_comm_rate number := 0;
 ln_tax number := 0;
 ln_total_amount number := 0;
 ln_round number := 0;
 -- EOM nursultanT 10.10.2018 CBS-29

  begin

   open c_nakit_yatan(pn_islem_no);
   loop
  fetch c_nakit_yatan into r_nakit;
  exit when c_nakit_yatan%notfound;

   if r_nakit.komisyon_tahsil_sekli = 'PAID' then

      -- BOM nursultanT 10.10.2018 CBS-29
      ln_deposit_comm := r_nakit.nakit_yatan_komisyonu;
      pkg_parametre.deger ('G_SALES_TAX_RATE', ln_sales_comm_rate);
      ln_tax := ln_deposit_comm / 100 * ln_sales_comm_rate;
      if r_nakit.doviz_kodu = 'KGS' then
          ln_round := pkg_tx6201.commission_round_error(ln_deposit_comm) + pkg_tx6201.commission_round_error(ln_tax);

        -- if PKG_TX6201.Commission_Round_Error(ln_tax + ln_deposit_comm) = 0 THEN
        --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm) + PKG_TX6201.Commission_Round_Error(ln_tax);
        -- else
        --   ln_round := PKG_TX6201.Commission_Round_Error(ln_deposit_comm + ln_tax);
        -- end if;
        ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax + ln_round;
      else
        ln_total_amount := r_nakit.toplam_tahsil_tutari + ln_tax;
      end if;
      -- EOM nursultanT 10.10.2018 CBS-29

    pkg_tx1601.onay_sonrasi(pn_islem_no ,6200,r_nakit.toplam_tahsil_tutari,r_nakit.doviz_kodu,'Y');
   else
    pkg_tx1601.onay_sonrasi(pn_islem_no ,6200,r_nakit.tutar,r_nakit.doviz_kodu,'Y');
   end if;
    

   end loop ;

   close c_nakit_yatan;

   insert into cbs_cari_nakit_yatan(referans_no, durum_kodu, islem_sekli, musteri_no, hesap_no, doviz_kodu, dk_no, tutar, valor_tarihi, aciklama, tx_no,
                                    islem_tarihi,nakit_kodu,prefix_istatistik_kodu,istatistik_kodu,cash_counting_comm,agent_id,payment_status,agent_name,
                                    kurum_kodu, --cq728 chyngyzo 090614
                                    subscriber_no, --cq728 chyngyzo 090614
                                      residency_code,-- BOM CQ5514 KonstantinJ  07.02.2017
                                        citizen_code,
                                        id_no,-- rbo-395 Maksatt 09/12/22
                                        id_type,
                                        issue_place,
                                        validity_date,
                                        gender,
                                        name,
                                        middle_name,
                                        surname,--maksatt 13.10.22 rbo-395
                                        third_person_surname,
                                        third_person_middle_name,
                                        third_person_date_of_birth,
                                        third_person_id_type,
                                        third_person_id_no,
                                        third_person_gender,
                                        third_person_validity_date,-- rbo-395 Maksatt 09/12/22
                                        third_person_issue_place,
                                        third_person_name,
                                        third_person_cbs_number,
                                        third_person_residency_code,
                                        third_person_citizen_code,
                                        third_person_tax_number,-- EOM CQ5514 KonstantinJ  07.02.2017
                                        DATE_OF_BIRTH,   --BOM CBS-349 AntonPa 16.06.2021
                                        ADDRESS,
                                        TIN,
                                        AMOUNT_IN_WORDS,
                                        TRANSFER_PURPOSE --EOM CBS-349 AntonPa 16.06.2021
                                        )
    (select referans_no, durum_kodu, islem_sekli, musteri_no, hesap_no, doviz_kodu, dk_no, tutar, valor_tarihi, aciklama, tx_no,islem_tarihi,nakit_kodu,
            prefix_istatistik_kodu,istatistik_kodu,cash_counting_comm,agent_id,payment_status,agent_name,
            kurum_kodu, --cq728 chyngyzo 090614
            subscriber_no, --cq728 chyngyzo 090614
     residency_code,-- CQ5514 KonstantinJ  07.02.2017
                                        citizen_code,
                                        id_no,-- rbo-395 Maksatt 09/12/22
                                        id_type,
                                        issue_place,
                                        validity_date,
                                        gender,
                                        name,
                                        middle_name,
                                        surname,--maksatt 13.10.22 rbo-395
                                        third_person_surname,
                                        third_person_middle_name,
                                        third_person_date_of_birth,
                                        third_person_id_type,
                                        third_person_id_no,
                                        third_person_gender,
                                        third_person_validity_date,
                                        third_person_issue_place,-- rbo-395 Maksatt 09/12/22
                                        third_person_name,
                                        third_person_cbs_number,
                                        third_person_residency_code,
                                        third_person_citizen_code,
                                        third_person_tax_number,-- EOM CQ5514 KonstantinJ  07.02.2017
                                        DATE_OF_BIRTH,   --BOM CBS-349 AntonPa 16.06.2021
                                        ADDRESS,
                                        TIN,
                                        AMOUNT_IN_WORDS,
                                        TRANSFER_PURPOSE --EOM CBS-349 AntonPa 16.06.2021

     from cbs_cari_nakit_yatan_islem where tx_no = pn_islem_no);

  exception 


   when others then
     raise_application_error(-20100,pkg_hata.getucpointer || '4534' || pkg_hata.getdelimiter ||to_char('SQLCODE') || sqlerrm ||pkg_hata.getdelimiter|| pkg_hata.getucpointer);

  end;
-------------------------------------------------------------------------
  procedure iptal_onay_sonrasi(pn_islem_no number) is
  ls_referans_no       cbs_menkul_repo_giris.referans_no%type;
  ls_status varchar2(2000);
  ls_payment_id varchar2(100);

 cursor cur_islem is
  select * from cbs_cari_nakit_yatan_islem where tx_no = pn_islem_no and agent_id is not null;
   rec  cur_islem%rowtype;


  ls_hata varchar2(2000); 
  webservice_error exception; 

    --BOM chyngyzo cq5220 Dealer Payments 09.12.2015
    cursor cur_payment (ps_referans_no cbs_cari_nakit_yatan.referans_no%type) is
        select * from cbs_cari_nakit_yatan where referans_no = ps_referans_no; 
    rw_payment cur_payment%rowtype;

    dealer_payment_error exception;
    ls_error_code varchar2(100);
    ls_error_desc varchar2(100);
    --EOM chyngyzo cq5220 Dealer Payments 09.12.2015
    
  begin
   -- Ancak Ayni gun icinde iptal yapilabilir

  --  CBS_CARI_NAKIT_YATAN_islem referans_no bilgisi alinir
   select referans_no
   into   ls_referans_no
   from   cbs_cari_nakit_yatan_islem
   where  tx_no = pn_islem_no;

   update cbs_cari_nakit_yatan
   set    durum_kodu   = 'K' -- Aciktan Kapali ya geciyor
   where  referans_no  = ls_referans_no ;

   --Iptal sonrasinda fis iptal fonkiyonu zaten calistiriliyor
   pkg_tx1601.iptal_onay_sonrasi(pn_islem_no,6200);
   
  -- islem bilgisi detaylari alinir
   open cur_islem;
   fetch cur_islem into rec;
   close cur_islem;
  if rec.tx_no is not null and rec.agent_id is not null then 
    begin
      pkg_qiwi_ws.cancelpayment(6200,rec.tx_no, nvl(rec.islem_tarihi,pkg_muhasebe.banka_tarihi_bul),ls_status); --sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services
    exception
       when others then
            ls_hata :=  ' Webservice Connection Error-Contact IT department.Error: ('|| substr( replace(sqlerrm,'&'),1,500)||')' ;
            log_at('pkg_tx3556.Iptal_Onay_Sonrasi',pn_islem_no, substr(sqlerrm,1,2000));
            raise   webservice_error;
    end;      
    update cbs_cari_nakit_yatan_islem
    set payment_status =  ls_status
    where  tx_no = rec.tx_no ;
   end if;
    
    --BOM chyngyzo cq5220 Dealer Payments 09.12.2015
    open cur_payment(ls_referans_no);
    fetch cur_payment into rw_payment;
    close cur_payment;
        
    if rw_payment.kurum_kodu is not null 
        and pkg_soa_inquiry.isdealerpayment(rw_payment.kurum_kodu) = 1 then -- Dealer Payments




        
        declare
            ls_returncode varchar2(3);
            pc_result cursorreferencetype;
            ls_result varchar2(100);
            ls_dealer_name varchar2(100);
            ls_amount varchar2(100);
            ls_currency varchar2(100);
            ls_date varchar2(100);
            ls_cbs_txno varchar2(100);
            ls_company_txno varchar2(100);
            ls_receipt_no varchar2(100);
        begin
             ls_returncode := pkg_soa_transaction.cancelwsdealerpayment ( ps_company_id => rw_payment.kurum_kodu,
                                                                          ps_dealer_id => rw_payment.subscriber_no,
                                                                          ps_amount => rw_payment.tutar,
                                                                          ps_currency => rw_payment.doviz_kodu,
                                                                          ps_current_date => to_char(sysdate, 'dd.mm.yyyy hh24:mi:ss'),
                                                                          ps_bank_date => to_char(pkg_muhasebe.banka_tarihi_bul, 'dd.mm.yyyy hh24:mi:ss'),
                                                                          ps_cbs_txno => pn_islem_no,
                                                                          ps_company_txno => rw_payment.subscriber_payment_info_1,
                                                                          pc_ref => pc_result);
                    
            fetch pc_result 
            into ls_result, ls_error_code, ls_error_desc, ls_dealer_name, ls_amount, 
                      ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no;                     
            close pc_result;  
                    
           if  nvl(ls_result, 'ERROR') <> 'OK' then
                raise dealer_payment_error;
           end if;
       end;
    end if;    
    --EOM chyngyzo cq5220 Dealer Payments 09.12.2015

  exception
   when webservice_error then
        raise_application_error(-20100,'5714' || ls_hata); --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi         
   
    when dealer_payment_error then  --chyngyzo cq5220 Dealer Payments 09.12.2015
        raise_application_error (-20100, pkg_hata.getucpointer || ls_error_code || pkg_hata.getdelimiter || ls_error_desc || pkg_hata.getdelimiter || pkg_hata.getucpointer); 

          
   when others then
     raise_application_error(-20100,pkg_hata.getucpointer || '4535' || pkg_hata.getdelimiter ||to_char('SQLCODE') || sqlerrm ||pkg_hata.getdelimiter|| pkg_hata.getucpointer);
  end;
-------------------------------------------------------------------------
  procedure reddetme_sonrasi(pn_islem_no number) is

  begin
  -- Durum kodu Update edilir.
      update cbs_cari_nakit_yatan_islem
   set   durum_kodu = 'R'
   where tx_no      = pn_islem_no;



  exception
   when others then
     raise_application_error(-20100,pkg_hata.getucpointer || '4533' || pkg_hata.getdelimiter ||to_char('SQLCODE') || sqlerrm ||pkg_hata.getdelimiter|| pkg_hata.getucpointer);

  end;
-------------------------------------------------------------------------
  procedure tamam_sonrasi(pn_islem_no number) is
  begin
   null;
  end;
-------------------------------------------------------------------------
  procedure basim_sonrasi(pn_islem_no number) is
  begin
   null;
  end;
  
  --BOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
 procedure insert_into_cancel_queue (  p_tx_no        number,
              p_status       varchar2,
              p_company      varchar2,
              p_amount       number,
              p_currency     varchar2,
              p_dealer_id    varchar2,
              p_bank_date    date,
              p_create_date  date,
              p_update_date  date,
              p_tx_code      number,
              p_company_tx_no varchar2) is
  
     pragma autonomous_transaction;

   begin
      insert into cbs_dealer_payments_cancel( tx_no, status, company,  amount,
                                              currency, dealer_id, bank_date,
                                              create_date, update_date, tx_code, company_tx_no  )   
                            values (  p_tx_no, p_status, p_company,  p_amount,
                                      p_currency, p_dealer_id, p_bank_date,
                                      p_create_date, p_update_date, p_tx_code, p_company_tx_no  );                                                
     commit;     
   end insert_into_cancel_queue;   
  --EOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
  
-------------------------------------------------------------------------
 procedure muhasebelesme(pn_islem_no number) is
    varchar_list              pkg_muhasebe.varchar_array;
    number_list         pkg_muhasebe.number_array;
    date_list         pkg_muhasebe.date_array;
    boolean_list        pkg_muhasebe.boolean_array;

 ln_fis_no         cbs_fis.numara%type ;
 ls_islem_sube_kodu    cbs_islem.kayit_kullanici_bolum_kodu%type ;
 ln_kur       number;

 ln_musteri_no              cbs_cari_nakit_yatan.musteri_no%type  ;
 ln_hesap_no      cbs_cari_nakit_yatan.hesap_no%type  ;
 ls_dk_no      cbs_cari_nakit_yatan.dk_no%type  ;
 ls_referans_no         cbs_cari_nakit_yatan.referans_no%type ;
 ls_islem_sekli         cbs_cari_nakit_yatan.islem_sekli%type ;
 ls_doviz_kodu        cbs_cari_nakit_yatan.doviz_kodu%type;
 ls_aciklama      cbs_cari_nakit_yatan.aciklama%type ;
 ln_lc_tutar      cbs_cari_nakit_yatan.tutar%type ;
 ln_fc_tutar      cbs_cari_nakit_yatan.tutar%type ;
 ls_modul_tur_kod     cbs_hesap.modul_tur_kod%type ;
 ls_hesap_tur     varchar2(2000);

 -- BOM NursultanT CBS-29
 ln_total_round  number := 0;
 ln_round  number := 0;
 ln_sales_tax_rate  number := 0;
 -- EOM NursultanT CBS-29

 cursor c_islem_cursor (pn_islemno cbs_islem.numara%type) is
 select a.referans_no,
     decode(a.islem_sekli,'DK','DK','MH')  islem_sekli,
     a.musteri_no, a.hesap_no, a.doviz_kodu, a.dk_no, a.tutar,
     a.aciklama,a.valor_tarihi,
     a.istatistik_kodu istatistik_kodu,
     nvl(to_char(a.nakit_kodu),' ') nakit_kodu,
     nvl(a.nakit_yatan_komisyonu,0) nakit_yatan_komisyonu, nvl(a.nakit_yatan_tahsilat_komisyonu,0) nakit_yatan_tahsilat_komisyonu,
        (to_char(nvl(a.prefix_istatistik_kodu_kom,0)) || nvl(a.doviz_kodu,' ') || to_char(nvl(a.istatistik_kodu_komisyon,0))) istatistik_kodu_kom,
     a.toplam_tahsil_tutari,a.komisyon_tahsil_sekli,nvl(a.cash_counting_comm,0) cash_counting_comm,
     a.payment_status,
     a.agent_id,
     a.kurum_kodu, a.subscriber_no --chyngyzo cq5220 Dealer Payments 09.12.2015
 from   cbs_cari_nakit_yatan_islem a,cbs_cari_nakit_yatan  b
 where  a.tx_no    = pn_islemno
 and    a.referans_no = b.referans_no
 and    b.durum_kodu  = 'A' ;

    r_islem  c_islem_cursor%rowtype;
    ls_status  varchar2(2000) ;
    ls_hata     varchar2(2000):= null;
    webservice_error               exception;

    --BOM chyngyzo cq5220 Dealer Payments 09.12.2015
    kt_payment_not_confirmed   exception;
    ln_status               varchar2 (2000);  
    dealer_payment_error exception;
    ls_error_code varchar2(100);
    ls_error_desc varchar2(100);
   --EOM chyngyzo cq5220 Dealer Payments 09.12.2015
 begin
   -- islem kaydi bilgisi alinir
   ls_islem_sube_kodu := pkg_tx.islem_bolumkodu_al(pn_islem_no) ;

   -- islem bilgisi detaylari alinir
   open c_islem_cursor(pn_islem_no);
   fetch c_islem_cursor into r_islem;
   close c_islem_cursor;

  ln_kur   :=  pkg_kur.doviz_doviz_karsilik(r_islem.doviz_kodu,pkg_genel.lc_al,null, 1,1,null,null,'N','A')  ;

  boolean_list(pn_6200_islem_sekli_mh) :=false;
  boolean_list(pn_6200_islem_sekli_dk) :=false;
  boolean_list(pn_6200_tl)    :=false;
  boolean_list(pn_6200_yp)    :=false;
  boolean_list(pn_6200_paid)    :=false;
  boolean_list(pn_6200_deducted)   :=false;
  boolean_list(pn_6200_cash_collection):=false;
  boolean_list(pn_6200_deposit)   :=false;
  boolean_list(pn_6200_cash_counting)  :=false;

  -- BOM nursultanT 10.10.2018 CBS-29
  boolean_list(pn_6200_round) := false; -- NursultanT
  number_list(pn_6200_lc_tax) := 0;
  number_list(pn_6200_fc_tax) := 0;

  number_list(pn_6200_lc_tax_r) := 0;
  number_list(pn_6200_fc_tax_r) := 0;

  number_list(pn_6200_lc_round_d) := 0;
  number_list(pn_6200_lc_round_c) := 0;
  pkg_parametre.deger ('G_SALES_TAX_RATE', ln_sales_tax_rate);
  -- BOM nursultanT 10.10.2018 CBS-29
  
   --Yerzhan Tanatov Outlet GL Modification 19.12.2009  
  if pkg_tx6200.sube_outlet_mi(ls_islem_sube_kodu) = 'H' then
      pkg_parametre.deger('G_DK_LC_CASH_GL', varchar_list(pn_6200_g_dk_lc_cash_gl));
      pkg_parametre.deger('G_DK_FC_CASH_GL', varchar_list(pn_6200_g_dk_fc_cash_gl));
  else
      varchar_list(pn_6200_g_dk_lc_cash_gl) := '10002000';
      varchar_list(pn_6200_g_dk_fc_cash_gl) := '10002000';
  end if;     

  if  r_islem.islem_sekli  = 'MH'  then   -- Musteri Hesabi ise
   boolean_list(pn_6200_islem_sekli_mh) :=true;
   boolean_list(pn_6200_islem_sekli_dk) :=false;
  else
   boolean_list(pn_6200_islem_sekli_mh) :=false;
   boolean_list(pn_6200_islem_sekli_dk) :=true;
  end if;

  if nvl(r_islem.cash_counting_comm,0) <>0 then
     boolean_list(pn_6200_cash_counting):=true;
  else
     boolean_list(pn_6200_cash_counting):=false;
  end if;

  if nvl(r_islem.nakit_yatan_tahsilat_komisyonu,0) <>0 then
     boolean_list(pn_6200_cash_collection):=true;
  else
     boolean_list(pn_6200_cash_collection):=false;
  end if;

  if nvl(r_islem.nakit_yatan_komisyonu,0) <>0 then
     boolean_list(pn_6200_deposit)  :=true;
  else
   boolean_list(pn_6200_deposit) := false;
  end if;

  if r_islem.doviz_kodu = pkg_genel.lc_al  then
   boolean_list(pn_6200_tl)    :=true;
   boolean_list(pn_6200_yp)    :=false;
  else
   boolean_list(pn_6200_tl)    :=false;
   boolean_list(pn_6200_yp)    :=true;
  end if;

  if boolean_list(pn_6200_tl) then 
      if r_islem.komisyon_tahsil_sekli  = 'DEDUCTED' then
         boolean_list(pn_6200_deducted) := true;
         boolean_list(pn_6200_paid)    := false;
      elsif r_islem.komisyon_tahsil_sekli  = 'PAID' then
         boolean_list(pn_6200_deducted) := false;
         boolean_list(pn_6200_paid)    := true;
      end if;
  elsif boolean_list(pn_6200_yp) then
      -- BOM NursultanT CBS-29
      if r_islem.komisyon_tahsil_sekli  = 'DEDUCTED' then
         boolean_list(pn_6200_deducted) := true;
         boolean_list(pn_6200_paid)    := false;
      elsif r_islem.komisyon_tahsil_sekli  = 'PAID' then
         boolean_list(pn_6200_deducted) := false;
         boolean_list(pn_6200_paid)    := true;
      end if;
      -- EOM NursultanT CBS-29
  end if;

  -- varchar list
  if  r_islem.islem_sekli = 'MH' then
   begin
     select modul_tur_kod
     into   ls_modul_tur_kod
     from   cbs_vw_hesap_izleme
     where  hesap_no = r_islem.hesap_no;

     exception
     when no_data_found then
        ls_modul_tur_kod := '';
     when others then
        ls_modul_tur_kod := '';
   end;

   if ls_modul_tur_kod = pkg_hesap.modul_tur_vadeli then
    pkg_parametre.deger('G_VADELI', ls_hesap_tur);
    varchar_list(pn_6200_hesap_turu)      := ls_hesap_tur;
   elsif ls_modul_tur_kod = pkg_hesap.modul_tur_vadesiz then
    pkg_parametre.deger('G_VADESIZ', ls_hesap_tur);
    varchar_list(pn_6200_hesap_turu)      := ls_hesap_tur;
   else
    varchar_list(pn_6200_hesap_turu)      := '';
   end if;
   varchar_list(pn_6200_hesap_sube)   := pkg_hesap.hesapsubeal(r_islem.hesap_no);

  else
   varchar_list(pn_6200_hesap_turu)      := '';
   varchar_list(pn_6200_hesap_sube)   := '';
  end if;

  varchar_list(pn_6200_islem_sube)      := ls_islem_sube_kodu;
  varchar_list(pn_6200_banka_aciklama)  := r_islem.aciklama ;
  varchar_list(pn_6200_musteri_aciklama):= r_islem.aciklama ;
  varchar_list(pn_6200_referans)      := r_islem.referans_no;
  varchar_list(pn_6200_doviz_kodu)    := r_islem.doviz_kodu;
  varchar_list(pn_6200_dk_hesap)    := r_islem.dk_no;
  varchar_list(pn_6200_musteri_hesap)   := r_islem.hesap_no;

  if sf_istatistikkod_zorunlumu(pkg_hesap.hesaptanmusterinoal(r_islem.hesap_no), r_islem.doviz_kodu)='E' then
     varchar_list(pn_6200_istatistik_kodu):=pkg_musteri.paymentkod_formatli_al( pkg_hesap.hesaptanmusterinoal(r_islem.hesap_no) ,r_islem.istatistik_kodu) ;
  end if;

  varchar_list(pn_6200_nakit_kodu)    := r_islem.nakit_kodu;
  varchar_list(pn_6200_istatistik_kodu_kom) :=  r_islem.istatistik_kodu_kom;
  varchar_list(pn_6200_commission_desc) := 'Комиссия за пересчет.НДС не облагается';
  varchar_list(pn_6200_desc_cashcoll) := 'Commission for collection(комиссия за инкассацию)';
  varchar_list(pn_6200_desc_counting) := 'Comission for re-counting(комиссия за пересчёт)';
  varchar_list(pn_6200_desc_vat)         := 'VAT for collection(НДС за инкассацию)';




  if varchar_list(pn_6200_musteri_hesap) is not null then
   varchar_list(pn_6200_komisyon_referans) := varchar_list(pn_6200_musteri_hesap) ;
  else
   varchar_list(pn_6200_komisyon_referans) := r_islem.referans_no;
  end if;

  if r_islem.hesap_no is not null then
   varchar_list(pn_6200_dk_hesap_deposit)    :=pkg_muhasebe.komisyon_dk_bul( pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(r_islem.hesap_no) ),'CASHDEPST');
  else
        varchar_list(pn_6200_dk_hesap_deposit)    := '' ;
  end if;
  if r_islem.hesap_no is not null then
   varchar_list(pn_6200_dk_hesap_cash)    :=pkg_muhasebe.komisyon_dk_bul( pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(r_islem.hesap_no) ),'CASHCOLL');
  else
        varchar_list(pn_6200_dk_hesap_cash)    := '';
  end if;

  if r_islem.hesap_no is not null then
   varchar_list(pn_6200_dk_hesap_counting)   :=pkg_muhasebe.komisyon_dk_bul( pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(r_islem.hesap_no) ),'CASHCOUNT');
  else
        varchar_list(pn_6200_dk_hesap_counting)   := '' ;
  end if;

  --number list

  number_list(pn_6200_fc_tutar)     := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.tutar) ;
  number_list(pn_6200_lc_tutar)     := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.tutar * ln_kur) ;
  number_list(pn_6200_kur)     := ln_kur ;

  number_list(pn_6200_cash_count_amount_fc) := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.cash_counting_comm);
  number_list(pn_6200_cash_count_amount_lc) := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.cash_counting_comm * ln_kur);

  number_list(pn_6200_cash_coll_amount_fc) := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.nakit_yatan_tahsilat_komisyonu);
  number_list(pn_6200_cash_coll_amount_lc) := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.nakit_yatan_tahsilat_komisyonu  * ln_kur);
  number_list(pn_6200_deposit_amount_fc)  := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.nakit_yatan_komisyonu);
  number_list(pn_6200_deposit_amount_lc)  := pkg_kur.yuvarla(r_islem.doviz_kodu,r_islem.nakit_yatan_komisyonu * ln_kur);
  
  -- BOM nursultanT CBS-29 
  number_list(pn_6200_deposit_amount_fc_r)  := number_list(pn_6200_deposit_amount_fc);
  number_list(pn_6200_deposit_amount_lc_r)  := number_list(pn_6200_deposit_amount_lc);
  -- EOM nursultanT CBS-29

  -- BOM nursultanT CBS-29 replace function to variable
  number_list(pn_6200_lc_vergi)     := ((r_islem.nakit_yatan_tahsilat_komisyonu * ln_sales_tax_rate)/100 ) * ln_kur;
  number_list(pn_6200_fc_vergi)    := ((r_islem.nakit_yatan_tahsilat_komisyonu * ln_sales_tax_rate)/100 );
  number_list(pn_6200_lc_tax)     := ((r_islem.nakit_yatan_komisyonu * ln_sales_tax_rate)/100 ) * ln_kur;
  number_list(pn_6200_fc_tax)    := ((r_islem.nakit_yatan_komisyonu * ln_sales_tax_rate)/100 );

  number_list(pn_6200_lc_tax_r) :=   number_list(pn_6200_lc_tax);
  number_list(pn_6200_fc_tax_r) :=   number_list(pn_6200_fc_tax);
  -- EOM nursultanT CBS-29
  number_list(pn_6200_cash_coll_amt_tax_lc):= number_list(pn_6200_cash_coll_amount_lc) + number_list(pn_6200_lc_vergi);


  
  -- BOM NursultanT CBS-29 considering round error


 -- EOM NursultanT CBS-29

    if boolean_list(pn_6200_tl) and boolean_list(pn_6200_paid) then 
      ln_total_round := number_list(pn_6200_deposit_amount_lc_r) + number_list(pn_6200_lc_tax_r);

      -- if PKG_TX6201.Commission_Round_Error(ln_total_round) = 0 THEN
      --   -- 1 COMMISSION ROUND ERROR
      --   number_list(pn_6200_LC_ROUND_D) := number_list(pn_6200_LC_ROUND_D) + PKG_TX6201.Commission_Round_Error(number_list(pn_6200_DEPOSIT_AMOUNT_FC));
        
      --   number_list(pn_6200_DEPOSIT_AMOUNT_FC_R) := number_list(pn_6200_DEPOSIT_AMOUNT_FC_R) + PKG_TX6201.Commission_Round_Error(number_list(pn_6200_DEPOSIT_AMOUNT_FC_R));
      --   number_list(pn_6200_DEPOSIT_AMOUNT_LC_R) := number_list(pn_6200_DEPOSIT_AMOUNT_FC_R);
      --   -->

      --   -- 1 TAX ROUND ERROR
      --   number_list(pn_6200_LC_ROUND_D) := number_list(pn_6200_LC_ROUND_D) + PKG_TX6201.Commission_Round_Error(number_list(pn_6200_FC_TAX_R));
        
      --   number_list(pn_6200_FC_TAX_R) := number_list(pn_6200_FC_TAX_R) + PKG_TX6201.Commission_Round_Error(number_list(pn_6200_FC_TAX_R));
      --   number_list(pn_6200_LC_TAX_R) := number_list(pn_6200_FC_TAX_R);
      --   -->
      -- else
      --   number_list(pn_6200_LC_ROUND_D) := PKG_TX6201.Commission_Round_Error(ln_total_round);
      --   ln_total_round := ln_total_round + number_list(pn_6200_LC_ROUND_D);

      --   -- 1 TAX ROUND ERROR
      --   number_list(pn_6200_FC_TAX_R) := number_list(pn_6200_FC_TAX_R) + PKG_TX6201.Commission_Round_Error(number_list(pn_6200_FC_TAX_R));
      --   number_list(pn_6200_LC_TAX_R) := number_list(pn_6200_FC_TAX_R);
      --   -->

      --   -- 1 COMMISSION ROUND ERROR
      --   number_list(pn_6200_DEPOSIT_AMOUNT_FC_R) := ln_total_round - number_list(pn_6200_FC_TAX_R);
      --   number_list(pn_6200_DEPOSIT_AMOUNT_LC_R) := number_list(pn_6200_DEPOSIT_AMOUNT_FC_R);
      --   -->
      -- end if;

      -- 1 TAX ROUND ERROR
      number_list(pn_6200_fc_tax_r) := number_list(pn_6200_fc_tax_r) + pkg_tx6201.commission_round_error(number_list(pn_6200_fc_tax_r));
      number_list(pn_6200_lc_tax_r) := number_list(pn_6200_fc_tax_r);
      -->

      -- 1 COMMISSION ROUND ERROR
      number_list(pn_6200_deposit_amount_fc_r) := number_list(pn_6200_deposit_amount_fc_r) + pkg_tx6201.commission_round_error(number_list(pn_6200_deposit_amount_fc_r));
      number_list(pn_6200_deposit_amount_lc_r) := number_list(pn_6200_deposit_amount_fc_r);
      -->

      number_list(pn_6200_lc_round_d) := ln_total_round - number_list(pn_6200_lc_tax_r) - number_list(pn_6200_deposit_amount_lc_r);

      if number_list(pn_6200_lc_round_d) < 0 then
        number_list(pn_6200_lc_round_c) := abs(number_list(pn_6200_lc_round_d));
        number_list(pn_6200_lc_round_d) := 0;
      elsif number_list(pn_6200_lc_round_d) > 0 then
        number_list(pn_6200_lc_round_c) := 0;
        number_list(pn_6200_lc_round_d) := abs(number_list(pn_6200_lc_round_d));
      end if;
      if number_list(pn_6200_lc_round_c) > 0 or number_list(pn_6200_lc_round_d) > 0 then 
        boolean_list(pn_6200_round) := true;
      else
        boolean_list(pn_6200_round) := false;
      end if;
    else
      boolean_list(pn_6200_round) := false;
    end if; -- boolean_list(pn_6200_TL) and boolean_list(pn_6200_PAID)
--  -- EOM NursultanT CBS-29

    
  --date_list
  if r_islem.valor_tarihi is not null then
   date_list(pn_6200_valor)     := r_islem.valor_tarihi ;
  else
   date_list(pn_6200_valor)     := pkg_muhasebe.banka_tarihi_bul ;
  end if;
  
  --send payment
  if r_islem.agent_id is not null then
        begin 
        pkg_qiwi_ws.addpayment(6200,pn_islem_no, r_islem.agent_id, r_islem.tutar, r_islem.referans_no,ls_status);--sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services
         exception
            when others then
                ls_hata :=  ' Webservice Connection Error-Contact IT department.Error: ('|| substr( replace(sqlerrm,'&'),1,500)||')' ;
                log_at('pkg_tx6200.muhasebelesme',pn_islem_no, substr(sqlerrm,1,2000));
              raise   webservice_error;
        end;
 
        update cbs_cari_nakit_yatan_islem
        set payment_status =  ls_status
        where tx_no = pn_islem_no;

  end if;
  

  --pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir.
  ln_fis_no:=pkg_muhasebe.fis_kes(6200,
         null,
         pn_islem_no,
         varchar_list ,
         number_list  ,
         date_list    ,
         boolean_list ,
         null,
         true,   -- balance kontrol yapsin
         0,
         r_islem.aciklama );

    pkg_muhasebe.muhasebelestir(ln_fis_no);
    
    --bom bahianab cbs-113 18032021
    pkg_notif_sub.sf_generate_notif(pn_islem_no, 6200);
    --eom bahianab cbs-113 18032021

   pkg_tx1601.muhasebelesme(pn_islem_no,6200);
   
   --BOM chyngyzo cq5220 Dealer Payments 09.12.2015 --
   declare
        ln_provider_code        cbs_tahsilat_kurum_tanim.provider_code%type;
        ln_service_id           cbs_tahsilat_kurum_tanim.service_id%type;
        ln_payment_sum          number;
        ln_msg                  varchar2 (2000);
        ln_error                varchar2 (2);
              
        cursor c_confirmation_request(pn_islemno cbs_islem.numara%type) is
        select qid from cbs_kt_ws_log where tx_no = pn_islemno and op = 'QE10'; 
              
        r_confirmation c_confirmation_request%rowtype;
        ln_qid cbs_kt_ws_log.qid%type;
        
        --dealer payment variables
        ls_returncode varchar2(3);
        pc_result cursorreferencetype;
        ls_result varchar2(100);
        ls_dealer_name varchar2(100);
        ls_amount varchar2(100);
        ls_currency varchar2(100);
        ls_date varchar2(100);
        ls_cbs_txno varchar2(100);
        ls_company_txno varchar2(100);
        ls_receipt_no varchar2(100);
        ln_count number; --chyngyzo cq5306 Dealer Payments Defect 13.01.2016
   begin

         if r_islem.kurum_kodu is not null
         then
            ln_provider_code := pkg_tahsilat_islemleri.get_provider_code (r_islem.kurum_kodu);

            if ln_provider_code = 'KYRGYZTELECOM' then --KyrgyzTelecom Payments
               ln_qid := null;
          
              open c_confirmation_request(pn_islem_no);
              fetch c_confirmation_request into r_confirmation;
               if c_confirmation_request%found then
                     ln_qid := r_confirmation.qid; --since payment confirmation was already sent before, the same QID must be used to avoid duplicated payments
               end if;
              close c_confirmation_request;
              
              ln_service_id := pkg_tahsilat_islemleri.get_service_id (r_islem.kurum_kodu);
              
               pkg_tahsilat_islemleri.kt_call_ws (pn_islem_no,
                                      'QE10',
                                      ln_qid,
                                      ln_service_id,
                                      r_islem.subscriber_no,
                                      r_islem.tutar,
                                      ln_payment_sum,
                                      ln_status,
                                      ln_msg,
                                      ln_error);

               if ln_error = 'Y' then
                  raise kt_payment_not_confirmed;
               end if;
               
            elsif pkg_soa_inquiry.isdealerpayment(r_islem.kurum_kodu) = 1 then -- Dealer Payments
                            
               --BOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
               --check if payment is in cancel queue (table cbs_dealer_payments_cancel)
               select count(*) into ln_count
               from cbs_dealer_payments_cancel
               where tx_no=pn_islem_no;
               
               if nvl(ln_count, 0) > 0 then --payment is already enqueued to be cancelled, so raise error
                    ls_error_code := '369'; --Error occured while sending payment to Company''s billing system. New transaction should be created!
                    raise dealer_payment_error;
               end if;               
               --EOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
                
                ls_returncode := pkg_soa_transaction.makewsdealerpayment (ps_company_id => r_islem.kurum_kodu,
                                                                          ps_dealer_id => r_islem.subscriber_no,
                                                                          ps_amount => r_islem.tutar,
                                                                          ps_currency => r_islem.doviz_kodu,
                                                                          ps_current_date => to_char(sysdate, 'dd.mm.yyyy hh24:mi:ss'),
                                                                          ps_bank_date => to_char(pkg_muhasebe.banka_tarihi_bul, 'dd.mm.yyyy hh24:mi:ss'),
                                                                          ps_cbs_txno => pn_islem_no,
                                                                          pc_ref => pc_result);
                
                fetch pc_result 
                into ls_result, ls_error_code, ls_error_desc, ls_dealer_name, ls_amount, 
                          ls_currency, ls_date, ls_cbs_txno, ls_company_txno, ls_receipt_no;
                 
                close pc_result;  
                
                --BOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
                --check if payment was not processed on company's side
                if ls_result = 'PENDING' then --payment is still not processed, so insert into cancel queue
                  insert_into_cancel_queue (pn_islem_no, 'PENDING',  r_islem.kurum_kodu, r_islem.tutar, 
                                                                 r_islem.doviz_kodu,  r_islem.subscriber_no,  pkg_muhasebe.banka_tarihi_bul,
                                                                 sysdate, sysdate, 6200, ls_company_txno);                                                                                                        
                    raise dealer_payment_error;
               end if;
               --EOM chyngyzo cq5306 13.01.2016 Dealer Payments Defect
               if  nvl(ls_result, 'ERROR') <> 'OK' then
                    raise dealer_payment_error;
               end if;
               
               update cbs_cari_nakit_yatan
               set subscriber_payment_info_1 = ls_company_txno,
                   subscriber_payment_info_2 = ls_receipt_no
               where referans_no = r_islem.referans_no;
               
            end if;
         end if;
   end;
   --EOM chyngyzo cq5220 Dealer Payments 09.12.2015--

  exception
   when kt_payment_not_confirmed  then --chyngyzo cq728 KyrgyzTelecom Payments 09.06.14
        raise_application_error (-20100, pkg_hata.getucpointer || '9401' || pkg_hata.getdelimiter || ln_status || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   when dealer_payment_error then  --chyngyzo cq5220 Dealer Payments 09.12.2015
        raise_application_error (-20100, pkg_hata.getucpointer || ls_error_code || pkg_hata.getdelimiter || ls_error_desc || pkg_hata.getdelimiter || pkg_hata.getucpointer);      
   when webservice_error then
        raise_application_error(-20100,'5713' || ls_hata); --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi          
   when others then
        raise_application_error(-20100,pkg_hata.getucpointer || '4536'  || pkg_hata.getdelimiter ||substr(to_char(sqlcode)||' '||sqlerrm,1,2000) || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 end;

--***************************
  function sf_istatistikkod_zorunlumu(pn_musteri_no number,ps_doviz_kodu varchar2 ) return varchar2
  is
   ls_musteri_tipi_kod varchar2(1);
   ln_dk_grup_kod  number;
  begin
      select musteri_tipi_kod,
        dk_grup_kod
    into  ls_musteri_tipi_kod,
       ln_dk_grup_kod
    from  cbs_musteri
    where musteri_no = pn_musteri_no ;

    if (ps_doviz_kodu <> pkg_genel.lc_al ) or  ( ln_dk_grup_kod = 1023 ) then
       return 'E';
    else
       return 'H';
    end if;

   exception
     when others then return 'H';
  end;

function sube_outlet_mi(p_sube_kodu varchar2) return varchar2
is
l_return varchar2(1) default 'E';
begin
        select decode(count(1),0,'H','E')
        into  l_return
        from cbs_bolum
        where kodu <> resmi_defter_bolum_kodu
        and kodu = p_sube_kodu;
        
--BahianaB CQ 4588 New exchange Office added 17.03.2015 --Tynar 011 sube, Main Cash GL olarak 10001000 kullanmasi icin, outlet degilmis gibi gostermeliyiz.
        if (p_sube_kodu in ('011','062','043','063','064')) then --BahianaB 07122016 new exch office 064 added--AisuluuD 21072016 new exch office 063 added --AisuluuD 31.03.2016 new exchange office "Frunze" - 043 is added
            l_return := 'H';
        end if;

        return l_return;
end;
--maksatt 13.10.22 rbo-395
PROCEDURE GET_CUSTOMER_INFORMATION(pc_tax_no varchar2,  ps_name out varchar2, 
        ps_middle_name out varchar2, ps_surname out varchar2, ps_id_type out varchar2,
        ps_id_no out varchar2,ps_validity_date out date, ps_date_of_birth out date,
        ps_issuing_authority out varchar2,ps_gender out varchar2, ps_customer_no out number) is
 ln_tin 	        number;
 ls_id_card         varchar2(50);
 ls_resident_permit varchar2(50);
 ls_driving_licence varchar2(50);
 ls_passport        varchar2(50);
 ls_military_card   varchar2(50);
begin
    select NUFUS_CUZDANI_SERI_NO, RESIDENCE_PERMIT, EHLIYET_BELGE_NO, PASAPORT_NO,
    MILITARY_CARD
    into ls_id_card, ls_resident_permit, ls_driving_licence, ls_passport,
    ls_military_card
    from cbs_musteri where VERGI_NO = to_char(pc_tax_no) and ROWNUM <= 1;
    
    case when ls_id_card is not null
            then ps_id_type := '1'; ps_id_no:= ls_id_card;
         when ls_resident_permit is not null
            then ps_id_type := '2'; ps_id_no:= ls_resident_permit;
         when ls_driving_licence is not null
            then ps_id_type := '3'; ps_id_no:= ls_driving_licence;
         when ls_passport is not null
            then ps_id_type := '4'; ps_id_no:= ls_passport;
         when ls_military_card is not null
            then ps_id_type := '5'; ps_id_no:= ls_military_card;
         else null;
    end case;

    select ISIM, IKINCI_ISIM,SOYADI,GECERLILIK_TARIHI,DOGUM_TARIHI,
       VERILDIGI_YER,CINSIYET_KOD, MUSTERI_NO
    into
    	ps_name,ps_middle_name,ps_surname,ps_validity_date,ps_date_of_birth,
    	ps_issuing_authority,ps_gender,ps_customer_no
		from cbs_musteri
		where VERGI_NO = to_char(pc_tax_no) and ROWNUM <= 1; --rownum for test bases, bcz there're users with non-unique TIN
		exception when no_data_found then
        null;
end; 

--maksatt 04.10.22 rbo-395
PROCEDURE GET_CUSTOMER_BY_PASSPORT(pc_id_no varchar2, pc_id_type varchar2,
        ps_name out varchar2,ps_middle_name out varchar2, ps_surname out varchar2,
        ps_validity_date out date, ps_date_of_birth out date,
        ps_gender out varchar2, ps_customer_no out number, ps_tin out varchar2, 
        ps_issue_place out varchar2) 
    is
begin
    select ISIM,IKINCI_ISIM,SOYADI,GECERLILIK_TARIHI,DOGUM_TARIHI,CINSIYET_KOD, 
        MUSTERI_NO, VERGI_NO, verildigi_yer
    into
           ps_name,ps_middle_name,ps_surname,ps_validity_date,ps_date_of_birth,
           ps_gender,ps_customer_no, ps_tin, ps_issue_place
	from cbs_musteri A
		where  
            REPLACE(pc_id_no, ' ', '') = 
            case
                when pc_id_type = '3' then REPLACE(A.EHLIYET_BELGE_NO, ' ', '')
                when pc_id_type = '1' then REPLACE(A.NUFUS_CUZDANI_SERI_NO, ' ', '')
                when pc_id_type = '2' then REPLACE(A.RESIDENCE_PERMIT, ' ', '')
                when pc_id_type = '4' then REPLACE(A.PASAPORT_NO, ' ', '')
                when pc_id_type = '5' then REPLACE(A.MILITARY_CARD, ' ', '')
                else null
            end and ROWNUM = 1;--ROWNUM for test bases, bcz there're users with non-unique TIN
    exception when no_data_found then
        null;
end; --maksatt 04.10.22 rbo-395

begin

/* parametre index numaralari bulunur.*/
 --Yerzhan Tanatov Outlet GL Modification 19.12.2009
 pn_6200_g_dk_lc_cash_gl    :=pkg_muhasebe.parametre_index_bul('6200_G_DK_LC_CASH_GL'); 
 pn_6200_g_dk_fc_cash_gl    :=pkg_muhasebe.parametre_index_bul('6200_G_DK_FC_CASH_GL');
  
 pn_6200_islem_sube    :=pkg_muhasebe.parametre_index_bul('6200_ISLEM_SUBE');
 pn_6200_hesap_sube    :=pkg_muhasebe.parametre_index_bul('6200_HESAP_SUBE');
 pn_6200_dk_hesap    :=pkg_muhasebe.parametre_index_bul('6200_DK_HESAP');
 pn_6200_musteri_hesap   :=pkg_muhasebe.parametre_index_bul('6200_MUSTERI_HESAP');
 pn_6200_banka_aciklama   :=pkg_muhasebe.parametre_index_bul('6200_BANKA_ACIKLAMA');
 pn_6200_referans    :=pkg_muhasebe.parametre_index_bul('6200_REFERANS');
 pn_6200_doviz_kodu    :=pkg_muhasebe.parametre_index_bul('6200_DOVIZ_KODU');
 pn_6200_fc_tutar    :=pkg_muhasebe.parametre_index_bul('6200_FC_TUTAR');
 pn_6200_lc_tutar    :=pkg_muhasebe.parametre_index_bul('6200_LC_TUTAR');
 pn_6200_musteri_aciklama  :=pkg_muhasebe.parametre_index_bul('6200_MUSTERI_ACIKLAMA');
 pn_6200_hesap_turu    :=pkg_muhasebe.parametre_index_bul('6200_HESAP_TURU');
 pn_6200_kur      :=pkg_muhasebe.parametre_index_bul('6200_KUR');
 pn_6200_islem_sekli_mh   :=pkg_muhasebe.parametre_index_bul('6200_ISLEM_SEKLI_MH');
 pn_6200_islem_sekli_dk   :=pkg_muhasebe.parametre_index_bul('6200_ISLEM_SEKLI_DK');
 pn_6200_tl      :=pkg_muhasebe.parametre_index_bul('6200_TL');
 pn_6200_yp       :=pkg_muhasebe.parametre_index_bul('6200_YP');
 pn_6200_valor     :=pkg_muhasebe.parametre_index_bul('6200_VALOR');
 pn_6200_istatistik_kodu   :=pkg_muhasebe.parametre_index_bul('6200_ISTATISTIK_KODU');
 pn_6200_nakit_kodu     :=pkg_muhasebe.parametre_index_bul('6200_NAKIT_KODU');

 pn_6200_cash_coll_amt_tax_lc :=pkg_muhasebe.parametre_index_bul('6200_CASH_COLL_AMOUNT_TAX_LC');
 pn_6200_cash_coll_amount_fc  :=pkg_muhasebe.parametre_index_bul('6200_CASH_COLL_AMOUNT_FC');
 pn_6200_cash_coll_amount_lc  :=pkg_muhasebe.parametre_index_bul('6200_CASH_COLL_AMOUNT_LC');
 pn_6200_deposit_amount_fc  :=pkg_muhasebe.parametre_index_bul('6200_DEPOSIT_AMOUNT_FC');
 pn_6200_deposit_amount_lc  :=pkg_muhasebe.parametre_index_bul('6200_DEPOSIT_AMOUNT_LC');

 -- BOM NursultanT CBS-29
 pn_6200_deposit_amount_fc_r  :=pkg_muhasebe.parametre_index_bul('6200_DEPOSIT_AMOUNT_FC_R');
 pn_6200_deposit_amount_lc_r  :=pkg_muhasebe.parametre_index_bul('6200_DEPOSIT_AMOUNT_LC_R');
 -- EOM NursultanT CBS-29

 pn_6200_paid     :=pkg_muhasebe.parametre_index_bul('6200_PAID');
 pn_6200_deducted    :=pkg_muhasebe.parametre_index_bul('6200_DEDUCTED');
 pn_6200_cash_collection   :=pkg_muhasebe.parametre_index_bul('6200_CASH_COLLECTION');
 pn_6200_deposit     :=pkg_muhasebe.parametre_index_bul('6200_DEPOSIT');
 pn_6200_lc_vergi    :=pkg_muhasebe.parametre_index_bul('6200_LC_VERGI');
 pn_6200_fc_vergi    :=pkg_muhasebe.parametre_index_bul('6200_FC VERGI');
  -- BOM NursultanT CBS-29
 pn_6200_lc_tax    :=pkg_muhasebe.parametre_index_bul('6200_LC_TAX');
 pn_6200_fc_tax    :=pkg_muhasebe.parametre_index_bul('6200_FC_TAX');

 pn_6200_lc_tax_r :=pkg_muhasebe.parametre_index_bul('6200_LC_TAX_R');
 pn_6200_fc_tax_r :=pkg_muhasebe.parametre_index_bul('6200_FC_TAX_R');

 pn_6200_lc_round_d    :=pkg_muhasebe.parametre_index_bul('6200_LC_ROUND_D');
 pn_6200_lc_round_c    :=pkg_muhasebe.parametre_index_bul('6200_LC_ROUND_C');
 pn_6200_round    :=pkg_muhasebe.parametre_index_bul('6200_ROUND');
 -- EOM NursultanT CBS-29
 pn_6200_istatistik_kodu_kom  :=pkg_muhasebe.parametre_index_bul('6200_ISTATISTIK_KODU_KOM');
 pn_6200_dk_hesap_deposit  :=pkg_muhasebe.parametre_index_bul('6200_DK_HESAP_DEPOSIT');
 pn_6200_dk_hesap_cash   :=pkg_muhasebe.parametre_index_bul('6200_DK_HESAP_CASH');
 pn_6200_komisyon_referans  :=pkg_muhasebe.parametre_index_bul('6200_KOMISYON_REFERANS');

 pn_6200_dk_hesap_counting   :=pkg_muhasebe.parametre_index_bul('6200_DK_HESAP_COUNTING');
 pn_6200_cash_count_amount_lc  :=pkg_muhasebe.parametre_index_bul('6200_CASH_COUNT_AMOUNT_LC');
 pn_6200_cash_count_amount_fc  :=pkg_muhasebe.parametre_index_bul('6200_CASH_COUNT_AMOUNT_FC');
 pn_6200_cash_counting    :=pkg_muhasebe.parametre_index_bul('6200_CASH_COUNTING');
 pn_6200_commission_desc   :=pkg_muhasebe.parametre_index_bul('6200_COMMISSION_DESC');
 pn_6200_desc_cashcoll   :=pkg_muhasebe.parametre_index_bul('6200_DESC_CASHCOLL');
 pn_6200_desc_counting   :=pkg_muhasebe.parametre_index_bul('6200_DESC_COUNTING');
 pn_6200_desc_vat    :=pkg_muhasebe.parametre_index_bul('6200_DESC_VAT');
end;
/

