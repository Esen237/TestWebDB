create PACKAGE BODY     "PKG_TX1301" IS
 PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
    ls_nakdi_var                                   varchar2(1);
    ls_gayrinakdi_var                            varchar2(1);
    ln_bekleyen_txno                             number;
    ln_musteri_no                              number;
    ls_durum_kodu                               varchar2(200);
    ln_kredi_kart_urun_adet                       number;
    ln_overdraft_urun_adet                       number;
-- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
    ln_ovd_cnt                              number; 
    ln_hesap_no                               number;
    account_not_conn            exception;
 --   overdraft_urun_mukerrer                        exception;
-- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
    kredi_kart_urun_mukerrer                   exception;
    ln_total_sum    number;   --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
    total_sum_error exception;   --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
    ln_count_curr number;--aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
    ln_count_record number;--aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
    duplicated_currency exception; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
    no_curr_structure_entry exception; --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017

  BEGIN
          select musteri_no,durum_kodu
       into ln_musteri_no ,ls_durum_kodu
       from cbs_kredi_teklif_islem
       where tx_no = pn_islem_no ;

       ln_bekleyen_txno := Pkg_Kredi.Sf_Bitmemis_TeklifIslem_Var_Mi(ln_musteri_no,pn_islem_no );

       select count(*)
          into ln_overdraft_urun_adet
          from cbs_kredi_teklif_satir_islem
          WHERE tx_no = pn_islem_no and
                 pkg_tx1300.sf_teklif_overdraft_urun_mu(kredi_turu) = 'E';

-- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
     /*    if nvl(ln_overdraft_urun_adet,0) > 1 then
              raise overdraft_urun_mukerrer;
      end if;
    */
   IF ln_overdraft_urun_adet > 1 THEN
       select count(*)
       into ln_ovd_cnt --number of accounts with old overdraft logic
       from cbs_hesap
       where musteri_no = ln_musteri_no and
                 overdraft = 'E' and
                 durum_kodu = 'A' and
                 ovd_proposal_line_no is null;
       
       IF ln_ovd_cnt > 0 THEN
            select max(hesap_no) -- get account with old logic and ask user to change its overdraft logic to new one
            into ln_hesap_no
            from cbs_hesap
            where musteri_no = ln_musteri_no and
                      overdraft = 'E' and
                      durum_kodu = 'A' and
                      ovd_proposal_line_no is null;
            raise account_not_conn;
       END IF;
   END IF;    
-- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction

       if ls_durum_kodu in ( 'A','Y') then
        Pkg_Kredi.sp_teklif_gayrinakdilimit_var(pn_islem_no,ls_nakdi_var ,ls_gayrinakdi_var);
      end if;

       select count(*)
       into  ln_kredi_kart_urun_adet
       from cbs_kredi_teklif_satir_islem
       where tx_no = pn_islem_no and
                pkg_tx1300.sf_kredi_kart_urun_mu(kredi_turu) = 'E';

       if nvl(ln_kredi_kart_urun_adet,0) > 1 then
             raise kredi_kart_urun_mukerrer;
       end if;
       
       --BOM aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
   
    select sum(share_percent) 
    into ln_total_sum
    from CBS_CURR_STRUCT_OF_INCOME_TX
    where tx_no=pn_islem_no;
    
    if ln_total_sum <> 100 then
        raise  total_sum_error;
    end if;
   ---------------------
        begin
        select count(1) into ln_count_curr from
            (
            select count(*) ln_count 
            from CBS_CURR_STRUCT_OF_INCOME_TX  where tx_no = pn_islem_no
            group by currency
            ) a where a.ln_count > 1;

            exception when no_data_found then
            ln_count_curr := 0;
        end;   
    ------------------------------
            if ln_count_curr >= 1 then
                raise  duplicated_currency;
            end if;
            
            select count(*) 
            into ln_count_record
            from CBS_CURR_STRUCT_OF_INCOME_TX
            where tx_no = pn_islem_no;
            
            if ln_count_record = 0 then
            raise no_curr_structure_entry;
            end if;
   --EOM aisuluud cqdb 5568 "incoming currency structure" 10.01.2017

 Exception
-- B-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
    --when  overdraft_urun_mukerrer then
    --         raise_application_error(-20100,pkg_hata.getucpointer || '1847' ||  pkg_hata.getucpointer);
      when  account_not_conn then
             raise_application_error(-20100,pkg_hata.getucpointer || '4633' || pkg_hata.getdelimiter || ln_hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
-- E-O-M 30122014 AdiletK CQ1236 Removing overdraft restriction
      when  kredi_kart_urun_mukerrer then
             raise_application_error(-20100,pkg_hata.getucpointer || '1955' ||  pkg_hata.getucpointer);
      when  total_sum_error then
             raise_application_error(-20100,pkg_hata.getucpointer || '6903' ||  pkg_hata.getucpointer);   --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017              
      when duplicated_currency then    
             raise_application_error(-20100,pkg_hata.getucpointer || '6908' ||  pkg_hata.getucpointer);   --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      when no_curr_structure_entry then    
             raise_application_error(-20100,pkg_hata.getucpointer || '6909' ||  pkg_hata.getucpointer);   --aisuluud cqdb 5568 "incoming currency structure" 10.01.2017
      when others then
             log_at('pkg_tx1301.Kontrol_Sonrasi', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
             raise_application_error(-20100,pkg_hata.getucpointer || '62' || pkg_hata.getdelimiter || to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  END;
-----------------------------------------------------------
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
-----------------------------------------------------------
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
-----------------------------------------------------------
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
       null;
  End;
-----------------------------------------------------------
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      -- null;
              RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
  End;
-----------------------------------------------------------
  Procedure Onay_Sonrasi(pn_islem_no number)
  is
  Begin
    pkg_kredi.sp_kredi_teklif_guncelle(pn_islem_no );
  End;
-----------------------------------------------------------
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '699' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
    --pkg_tx1300.sp_teklifislem_durum_guncelle(pn_islem_no,'I');
  End;
-----------------------------------------------------------
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      pkg_tx1300.sp_teklifislem_durum_guncelle(pn_islem_no,'R');

  End;
-----------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
-----------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
-----------------------------------------------------------
 Procedure Muhasebelesme(pn_islem_no number) is
 Begin
  null;
 End;
-----------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;
-----------------------------------------------------------
 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block    varchar2,ps_rowid   varchar2,
                                 ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
   guncellenmis_exception               exception;
   ln_retval              number:=0;
   ls_sqlstr              varchar2(2000);
   ls_sql_template          varchar2(2000);
   ls_source_table          varchar2(2000);
   ls_dest_table          varchar2(2000);
  Begin

   if ps_block='CBS_KREDI_TEKLIF_ISLEM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_KREDI_TEKLIF_ISLEM';
       ls_dest_table:='CBS_KREDI_TEKLIF';
   if ps_column<>'TEKLIF_NO' and ps_column<>'TX_NO' and ps_column<>'REF_TEKLIF_NO' and ps_column <> 'TEKLIF_REFERANS' then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(1);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEKLIF_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TEKLIF_NO');
      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
--    end if;
   elsif ps_block='CBS_KREDI_TEKLIF_SATIR_ISLEM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_KREDI_TEKLIF_SATIR_ISLEM';
       ls_dest_table:='CBS_KREDI_TEKLIF_SATIR';
   if ps_column<>'TEKLIF_NO' and ps_column<>'TX_NO' and  ps_column<>'REF_TEKLIF_NO' and ps_column<> 'TEKLIF_SATIR_NO' and ps_column <> 'REF_TEKLIF_SATIR_NO' then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(2);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEKLIF_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TEKLIF_NO');
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK2','TEKLIF_SATIR_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK2','REF_TEKLIF_SATIR_NO');

      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
   elsif ps_block='CBS_KREDI_TEKLIF_LIMIT_ISLEM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_KREDI_TEKLIF_LIMIT_ISLEM';
       ls_dest_table:='CBS_KREDI_TEKLIF_LIMIT';
   if ps_column<>'TEKLIF_NO' and ps_column<>'TX_NO' and ps_column<>'REF_TEKLIF_NO' and ps_column<> 'SIRA_NO' then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(1);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEKLIF_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TEKLIF_NO');
      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
   elsif ps_block='CBS_KREDI_TEKLIF_TEMINAT_ISLEM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_KREDI_TEKLIF_TEMINAT_ISLEM';
       ls_dest_table:='CBS_KREDI_TEKLIF_TEMINAT';
   if ps_column<>'TEKLIF_NO' and ps_column<>'TX_NO' and ps_column<>'REF_TEKLIF_NO' and ps_column<> 'SIRA_NO' and ps_column<> 'REF_SIRA_NO' then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(2);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEKLIF_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TEKLIF_NO');
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK2','SIRA_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK2','REF_SIRA_NO');

      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
   elsif ps_block='CBS_KREDI_TKLF_SATIR_TMN_ISLM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_KREDI_TKLF_SATIR_TMN_ISLM';
       ls_dest_table:='CBS_KREDI_TEKLIF_SATIR_TEMINAT';
   if ps_column<>'TEKLIF_NO' and ps_column<>'TX_NO' and  ps_column<>'REF_TEKLIF_NO' and ps_column<> 'TEKLIF_SATIR_NO' AND ps_column<> 'REF_TEKLIF_SATIR_NO' and ps_column<> 'SIRA_NO' and ps_column<> 'REF_SIRA_NO'then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(3);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEKLIF_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TEKLIF_NO');
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK2','TEKLIF_SATIR_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK2','REF_TEKLIF_SATIR_NO');
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK3','SIRA_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK3','REF_SIRA_NO');

      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
    end if;

   if ln_retval<>1 then
       raise  guncellenmis_exception;
   end if;
  Exception
   When  guncellenmis_exception then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   End;
-----------------------------------------------------------
END ;
/

