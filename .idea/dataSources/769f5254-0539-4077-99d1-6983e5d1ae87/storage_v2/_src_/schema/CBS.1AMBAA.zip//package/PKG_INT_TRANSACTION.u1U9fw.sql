create PACKAGE     PKG_INT_TRANSACTION IS


PROCEDURE CreateTransaction (pn_tran_no NUMBER
                            ,pn_tran_code NUMBER
                            ,pc_module_type_code VARCHAR2
                            ,pc_product_type_code VARCHAR2
                            ,pc_product_class_code VARCHAR2
                            ,pn_amount NUMBER
                            ,pc_tran_branch_code VARCHAR2 DEFAULT NULL
                            ,pc_branch_code VARCHAR2 DEFAULT 'INT'
                            ,pc_role VARCHAR2 DEFAULT 7777
                            ,pc_currency_code VARCHAR2 DEFAULT NULL
                            ,pn_customer_no NUMBER DEFAULT NULL
                            ,pc_account_no VARCHAR2 DEFAULT NULL
                            ,pc_cash_code VARCHAR2 DEFAULT NULL
                            ,pn_channel_no NUMBER DEFAULT 0
                            ,pc_register_user_code VARCHAR2 DEFAULT 'CINT_CALLER'
                            );

 PROCEDURE ProcessTransaction(pn_tran_no IN NUMBER);

 PROCEDURE EntryControl(pn_tran_no NUMBER);

 FUNCTION GetErrorCode(pc_error_text IN VARCHAR2) RETURN VARCHAR2;

 PROCEDURE create_draft_transaction (pn_islem_numara              NUMBER
                            ,pn_islem_kod                 NUMBER
                            ,pc_modul_tur_kod             VARCHAR2
                            ,pc_urun_tur_kod              VARCHAR2
                            ,pc_urun_sinif_kod            VARCHAR2
                            ,pn_tutar                     NUMBER
                            ,pc_amir_bolum_kodu           VARCHAR2   DEFAULT NULL
                            ,pc_bolum_kodu                VARCHAR2   DEFAULT 'INT'
                            ,pc_rol                          VARCHAR2   DEFAULT 2
                            ,pc_doviz_kod                 VARCHAR2   DEFAULT NULL
                            ,pn_musteri_numara            NUMBER     DEFAULT NULL
                            ,pc_hesap_numara              VARCHAR2   DEFAULT NULL
                            ,pc_kasa_kod                  VARCHAR2   DEFAULT NULL
                            ,pn_KANAL_NUMARA              NUMBER DEFAULT 0
                            );
 PROCEDURE EODControl(dummy IN VARCHAR2);

END;
/

