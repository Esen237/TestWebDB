create PACKAGE     "PKG_SWIFT_AUTOMATION" IS
  PROCEDURE SWIFT_Messages_Parse(ps_type VARCHAR2,pd_start_date VARCHAR2,pd_end_date VARCHAR2,pd_svadat VARCHAR);
  FUNCTION  Contry_Code_By_BIC(ps_bic_kodu IN CBS_BIC_KODLARI.BIC_KODU%TYPE) RETURN VARCHAR2;
  FUNCTION  Customer_No_By_BIC(ps_bic_kodu IN CBS_BIC_KODLARI.BIC_KODU%TYPE) RETURN VARCHAR2;
  FUNCTION  Get_Bank_Account (ps_currency IN VARCHAR2, pn_customer_no IN CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2;
  FUNCTION  Get_Istatistical_Code (ps_explanation  CBS_SWIFT_MESSAGES.EXPLANATION%TYPE) RETURN VARCHAR2;
  FUNCTION  Check_Customer_Name (ps_cust_name  cbs_swift_messages.beneficiary_name%TYPE, pn_account cbs_swift_messages.to_account%TYPE ) RETURN NUMBER;
  END;
/

