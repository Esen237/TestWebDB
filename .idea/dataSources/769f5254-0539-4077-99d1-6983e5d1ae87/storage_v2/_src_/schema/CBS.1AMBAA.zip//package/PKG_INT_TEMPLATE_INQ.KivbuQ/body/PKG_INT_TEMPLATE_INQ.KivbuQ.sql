create PACKAGE BODY     PKG_INT_TEMPLATE_INQ IS


FUNCTION GetTemplatesByOperationType(pn_customer_number number, 
                                     ps_operation_type varchar2, 
                                     pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

   if ps_operation_type = 'all' then
    open pc_ref for
        select * from cbs.cbs_int_customer_template
        where customer_number = pn_customer_number 
              order by template_id;
   elsif ps_operation_type = 'allMoneyTransfers' then
    open pc_ref for
        select * from cbs.cbs_int_customer_template
        where customer_number = pn_customer_number 
              and operation_type not in ('instantPayment', 'taxPayment')
              order by template_id;
   else
     open pc_ref for
        select * from cbs.cbs_int_customer_template
        where customer_number = pn_customer_number 
              and operation_type = ps_operation_type 
              order by template_id;
   end if;
    
    return ls_returncode;
    
EXCEPTION
    when others then
         raise;
END;

FUNCTION GetTemplateById(pn_id number, 
                         pn_customer_number number, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode VARCHAR2(3) := '000';
BEGIN

    open pc_ref for
        select * from cbs.cbs_int_customer_template
            where customer_number = pn_customer_number 
                and template_id = pn_id 
                and rownum = 1;
            
    return ls_returncode;
    
EXCEPTION
    when others then
         raise;
END;
END;
/

