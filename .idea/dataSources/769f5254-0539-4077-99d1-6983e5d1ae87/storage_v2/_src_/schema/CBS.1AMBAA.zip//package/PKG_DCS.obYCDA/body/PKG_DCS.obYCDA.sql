create PACKAGE BODY     "PKG_DCS" 
AS
   /******************************************************************************
      NAME:       PKG_DCS
      PURPOSE: Direct Crediting System. At this time only for CocaCola

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      MederT       1. Created this package.
      2.0       05.03.2014      ChyngyzO     2. Modifications according to analysis and technical documents
   ******************************************************************************/

   FUNCTION InsertPayment (ps_invoice_no               VARCHAR2,
                           pn_customer_no              NUMBER,
                           ps_subscriber_name          VARCHAR2,
                           ps_subscriber_ext_acc_no    VARCHAR2,
                           pn_payment_sum              NUMBER,
                           ps_payment_curr             VARCHAR2,
                           pd_value_date               DATE,
                           pd_file_date                DATE,
                           pd_shipment_date            DATE)   --prepared date
      RETURN VARCHAR2
   IS
      ln_customer_no             NUMBER;
      ln_customer_acc_no         NUMBER;
      ln_subscriber_no           NUMBER;
      ln_int_subscriber_acc_no   NUMBER;
      ln_curr_check              NUMBER;
      ln_dupl_check              NUMBER;
      ls_status                  VARCHAR2 (500);
      ls_comment                 VARCHAR2 (500) := '';
      ls_message                 VARCHAR2 (500) := '';
      ln_invoice_id              NUMBER;
      ls_log_result              VARCHAR2 (500) := '';

      ln_begin_h                 NUMBER;
      ln_begin_m                 NUMBER;
      ln_end_h                   NUMBER;
      ln_end_m                   NUMBER;
      ld_begin_time              DATE;
      ld_end_time                DATE;

      --AzatD
      ls_invoice_id                NUMBER;
      ls_invoice_no                VARCHAR2(50);
      
      --AzatD
      CURSOR dcs_customer
      IS
         SELECT ACC_NO
           FROM CBS_DCS_CUSTOMER_ACCOUNTS
          WHERE CUST_NO = pn_customer_no AND STATUS = 1;

      CURSOR acc_check
      IS
         SELECT MAX (customer.acc_no) AS cust_acc_no,
                MAX (subscriber.SUBS_CUST_NO) AS subs_cust_no,
                MAX (hsp.external_hesap_no) AS cust_ext_acc_no
           FROM CBS_DCS_SUBSCRIBER_ACCOUNTS subscriber
                JOIN CBS_DCS_CUSTOMER_ACCOUNTS customer
                   ON subscriber.DCS_CUSTOMER_ID = customer.ID
                JOIN cbs_hesap hsp
                   ON hsp.hesap_no = customer.acc_no
          WHERE     customer.CUST_NO = pn_customer_no
                AND subscriber.SUBS_ACC_NO = ln_int_subscriber_acc_no
                AND subscriber.STATUS = 'ACTIVE'
                AND customer.STATUS = 1;

      r_acc_check                acc_check%ROWTYPE;

      CURSOR currency_check
      IS
         SELECT subscriber.ID
           FROM CBS_DCS_SUBSCRIBER_ACCOUNTS subscriber
                JOIN CBS_DCS_CUSTOMER_ACCOUNTS customer
                   ON subscriber.DCS_CUSTOMER_ID = customer.ID
                JOIN cbs_hesap cust_hsp
                   ON customer.ACC_NO = cust_hsp.HESAP_NO
                JOIN cbs_hesap subs_hsp
                   ON subscriber.SUBS_ACC_NO = subs_hsp.HESAP_NO
          WHERE cust_hsp.DOVIZ_KODU = subs_hsp.DOVIZ_KODU
                AND cust_hsp.DOVIZ_KODU = ps_payment_curr;

      CURSOR duplicated
      IS
         SELECT ID
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE     INVOICE_NO = ps_invoice_no
               --AND CUST_NO = pn_customer_no
                --AND SUBS_ACC_NO = ln_int_subscriber_acc_no
               -- AND PAYMENT_SUM = pn_payment_sum  -- AsylbekP ,AzatD ,MiraidaT 01.10.2019
                AND PAYMENT_CURR = ps_payment_curr;
                /*AND VALUE_DATE = pd_value_date
                AND STATUS = PSTATUS_ACCEPTED;*/

        -- CQ4480 AlmasN 12032015
        ln_exipre_days number;
        
        ls_message_body_header CBS_PARAMETRE.DEGER%TYPE;
        ls_message_body_footer CBS_PARAMETRE.DEGER%TYPE;
        lc_message_body CBS_EMAIL_MESSAGES.BODY_CONTENT%TYPE;
        ls_message_subject CBS_EMAIL_MESSAGES.SUBJECT%TYPE;
        
        ls_notify_email_address CBS_EMAIL_MESSAGES.RECIPIENT%TYPE;

   BEGIN
      ln_int_subscriber_acc_no := Pkg_Hesap.GetHesapNoFromExternal (ps_subscriber_ext_acc_no, ps_payment_curr);

      OPEN acc_check;
      FETCH acc_check INTO r_acc_check;
      CLOSE acc_check;
      
      OPEN duplicated;
      FETCH duplicated INTO ln_dupl_check;
      CLOSE duplicated;                           
             
      IF (ln_dupl_check IS NOT NULL) THEN
            ls_status := PSTATUS_DUPLICATED_INVOICE;
            ls_comment := 'Duplicated Invoice';
            ls_message := PSTATUS_DUPLICATED_INVOICE;
            ls_log_result := 'Duplicated Invoice. ' || ls_log_result;

      ELSIF (r_acc_check.cust_acc_no IS NOT NULL) AND (r_acc_check.subs_cust_no IS NOT NULL) THEN
         OPEN currency_check;
         FETCH currency_check INTO ln_curr_check;
         CLOSE currency_check;

         IF (ln_curr_check IS NOT NULL) THEN
            ls_status := PSTATUS_ACCEPTED;
            ls_comment := PSTATUS_ACCEPTED;
            ls_message := PSTATUS_ACCEPTED;                               --OK
         ELSE
            ls_status := PSTATUS_CURRENCY_WRONG;
            ls_comment := 'Currency Code is wrong';
            ls_message := PSTATUS_CURRENCY_WRONG;
            ls_log_result := 'Currency Code is wrong. ' || ls_log_result;
         END IF;

         IF (pd_shipment_date > pd_value_date) THEN
            ls_status := PSTATUS_INVOICE_DT_GR_VALUE_DT;
            ls_comment := 'Invoice date greater than Value date';
            ls_message := PSTATUS_INVOICE_DT_GR_VALUE_DT;
            ls_log_result := 'Invoice date greater than Value date. ' || ls_log_result;
         END IF;

         OPEN duplicated;
         FETCH duplicated INTO ln_dupl_check;
         CLOSE duplicated;

         IF (ln_dupl_check IS NOT NULL) THEN
            ls_status := PSTATUS_DUPLICATED_INVOICE;
            ls_comment := 'Duplicated Invoice';
            ls_message := PSTATUS_DUPLICATED_INVOICE;
            ls_log_result := 'Duplicated Invoice. ' || ls_log_result;
         END IF;

         IF (TRUNC(pd_value_date) < TRUNC(SYSDATE)) THEN
            ls_status := PSTATUS_ACCEPT_TIME_EXPIRED;
            ls_comment := 'Accept time expired';
            ls_message := PSTATUS_ACCEPT_TIME_EXPIRED;
            ls_log_result := 'Accept time expired';
         END IF; 
         
         IF (TRUNC (pd_value_date) = TRUNC (SYSDATE)) THEN
            SELECT MAX (CIT.START_HH24),
                   MAX (CIT.START_MM),
                   MAX (CIT.END_HH24),
                   MAX (CIT.END_MM)
              INTO ln_begin_h,
                   ln_begin_m,
                   ln_end_h,
                   ln_end_m
              FROM CBS_INT_TIME CIT
             WHERE CIT.TRAN_CD = 'DCS_ACCEPT';

            ld_begin_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_begin_h
                  || ': '
                  || ln_begin_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');
            ld_end_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_end_h
                  || ': '
                  || ln_end_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');

            IF SYSDATE NOT BETWEEN ld_begin_time AND ld_end_time
            THEN
               ls_status := PSTATUS_ACCEPT_TIME_EXPIRED;
               ls_comment :=
                     'Invoices are accepted between '
                  || TO_CHAR (ld_begin_time, 'HH24:MI')
                  || ' and '
                  || TO_CHAR (ld_end_time, 'HH24:MI');
               ls_message := PSTATUS_ACCEPT_TIME_EXPIRED;
               ls_log_result :=
                     'Invoices are accepted between '
                  || TO_CHAR (ld_begin_time, 'HH24:MI')
                  || ' and '
                  || TO_CHAR (ld_end_time, 'HH24:MI')
                  || '  '
                  || ls_log_result;
            END IF;
         END IF;
      ELSE

         OPEN dcs_customer;
         FETCH dcs_customer INTO ln_customer_no;
         CLOSE dcs_customer;

         IF (ln_customer_no IS NULL)
         THEN
            ls_status := PSTATUS_INVALID_CUSTOMER;                    --'905';
            ls_comment := PSTATUS_INVALID_CUSTOMER;
            ls_message := PSTATUS_INVALID_CUSTOMER; --Client is not corporate or account is not collecting-account
            ls_log_result := 'INVALID CUSTOMER. ' || ls_log_result;
         ELSE
            ls_status := PSTATUS_INVALID_SUBSCRIBER;                 -- '906';
            ls_comment := PSTATUS_INVALID_SUBSCRIBER;
            ls_message := PSTATUS_INVALID_SUBSCRIBER; --Customer is not distributor or account is not defined
            ls_log_result := 'INVALID SUBSCRIBER ' || ls_log_result;
         END IF;
      END IF;

      --BOM CQ4480 AlmasN 12032015 check for expiration
     Begin
          pkg_parametre.deger('DSC_EXIPRE_DAYS', ln_exipre_days);
           --first check for duplicate asylbekp
          IF (ln_dupl_check IS NOT NULL) THEN
            ls_status := PSTATUS_DUPLICATED_INVOICE;
            ls_comment := 'Duplicated Invoice';
            ls_message := PSTATUS_DUPLICATED_INVOICE;
            ls_log_result := 'Duplicated Invoice. ' || ls_log_result;
          elsif 
          (abs(pd_value_date - pd_file_date) >= ln_exipre_days) THEN
            pkg_parametre.deger('DSC_EXIPRE_NOTIFY_MSG_HEADER', ls_message_body_header);
            pkg_parametre.deger('DSC_EXIPRE_NOTIFY_MSG_FOOTER', ls_message_body_footer);
            pkg_parametre.deger('DSC_EXIPRE_NOTIFY_MSG_SUBJECT', ls_message_subject);

            lc_message_body := '';
            lc_message_body := lc_message_body || '<tr>';
            lc_message_body := lc_message_body || '<td>' || ps_subscriber_name || '</td>';
            lc_message_body := lc_message_body || '<td>' || PKG_HESAP.GetMusteriNoFromExternal(ps_subscriber_ext_acc_no) || '</td>';
            lc_message_body := lc_message_body || '<td>' || ps_invoice_no || '</td>';
            lc_message_body := lc_message_body || '<td>' || to_char(pd_shipment_date, 'dd.mm.yyyy') || '</td>';
            lc_message_body := lc_message_body || '<td>' || to_char(pd_value_date, 'dd.mm.yyyy') || '</td>';
            lc_message_body := lc_message_body || '<td>' || pn_payment_sum || ' ' || ps_payment_curr || '</td>';
            lc_message_body := lc_message_body || '<td>' || PSTATUS_CANCELLED || '</td>';
            lc_message_body := lc_message_body || '</tr>';

            -- get related marketing officer email addresses
           --/*replaced by GulkaiyrK DEN-17 wm_concat(email) into ls_notify_email_address   
            select LISTAGG(aa.email, ',') WITHIN GROUP (ORDER BY aa.email)   into ls_notify_email_address
            from cbs_kullanici aa, cbs_musteri bb
            where bb.musteri_no=r_acc_check.subs_cust_no
            and (AA.PERSONEL_NUMARA = BB.PAZARLAMA_SORUMLUSU_SICIL_NO_1
              or AA.PERSONEL_NUMARA = BB.PAZARLAMA_SORUMLUSU_SICIL_NO_2)
            and email is not null;

            Pkg_Email.AddToEmailQueue('DCS_NOTIFY', 50, 'info@demirbank.kg', ls_notify_email_address, ls_message_subject, ls_message_body_header || lc_message_body || ls_message_body_footer,'HTML');

            ls_status := PSTATUS_ACCEPT_TIME_EXPIRED;
            ls_comment := 'Shipment date and Payment date difference is more or equal than ' || ln_exipre_days || ' days'; 
            ls_message := PSTATUS_ACCEPT_TIME_EXPIRED;

          END IF;
      Exception
        When Others Then
            LOG_AT('DCS', 'NotifyExpire', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
      End;
      --EOM CQ4480 AlmasN 12032015 check for expiration

      INSERT INTO CBS_DCS_PLANNED_PAYMENTS (ID,
                                            INVOICE_NO,
                                            CUST_NO,
                                            ACC_NO,
                                            CUST_EXT_ACC_NO,
                                            SUBS_CUST_NO,
                                            SUBS_NAME,
                                            SUBS_EXT_ACC_NO,
                                            SUBS_ACC_NO,
                                            PAYMENT_SUM,
                                            PAYMENT_CURR,
                                            VALUE_DATE,
                                            file_date,
                                            shipment_date,
                                            STATUS,
                                            CREATE_DATE,
                                            COMMENTS,
                                            REMAIN_SUM)
           VALUES (dcs_payments_seq.NEXTVAL,
                   ps_invoice_no,
                   pn_customer_no,
                   r_acc_check.cust_acc_no,
                   r_acc_check.cust_ext_acc_no,
                   r_acc_check.subs_cust_no,
                   ps_subscriber_name,
                   ps_subscriber_ext_acc_no,
                   ln_int_subscriber_acc_no,
                   pn_payment_sum,
                   ps_payment_curr,
                   pd_value_date,
                   pd_file_date,
                   pd_shipment_date,
                   ls_status,
                   SYSDATE,
                   ls_comment,
                   pn_payment_sum);
     --AzatD
       
     
     select id into ls_invoice_id  from
              (select id from CBS_DCS_PLANNED_PAYMENTS where invoice_no = ps_invoice_no)
              WHERE ROWNUM = 1 ;
              
              
     insert into cbs_invoice_history (initial_sum_hist,payment_sum_hist,remain_sum_hist,created_at,status_hist,invoice_id,invoice_no_hist) 
     values (pn_payment_sum,0,pn_payment_sum, SYSDATE,ls_status,ls_invoice_id,ps_invoice_no);
     --AzatD

      INSERT INTO CBS_DCS_LOG (ID,
                               invoice_id,
                               data_row,
                               result,
                               CREATE_DATE)
           VALUES (
                     dcs_log_seq.NEXTVAL,
                     dcs_payments_seq.CURRVAL,
                        '100 '
                     || ps_invoice_no
                     || ' '
                     || TO_CHAR (pn_customer_no)
                     || ' '
                     || TO_CHAR (ps_subscriber_ext_acc_no)
                     || ' '
                     || TO_CHAR (pn_payment_sum)
                     || ' '
                     || ps_payment_curr
                     || ' '
                     || TO_CHAR (pd_value_date, 'dd.MM.yyyy'),
                     COALESCE (ls_log_result, PSTATUS_ACCEPTED),
                     SYSDATE);

      --COMMIT;

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS THEN
         ls_message := 'OTHER ERROR ' || substr(SQLERRM, 1, 400);
         RETURN ls_message;
   END;

   PROCEDURE JustLog (ps_data_row VARCHAR2)
   IS
   BEGIN
      INSERT INTO CBS_DCS_LOG (ID,
                               data_row,
                               result,
                               CREATE_DATE)
           VALUES (dcs_log_seq.NEXTVAL,
                   '200 ' || ps_data_row,
                   PSTATUS_FORMAT_WRONG,
                   SYSDATE);
   END;

   FUNCTION CancelPayment (ps_invoice_no               VARCHAR2,
                           pn_customer_no              NUMBER,
                           ps_ext_subscriber_acc_no    VARCHAR2,
                           pn_payment_sum              NUMBER,
                           ps_payment_curr             VARCHAR2,
                           pd_value_date               DATE)
      RETURN VARCHAR2
   IS
      ln_payment_id       NUMBER;
      ls_payment_status   VARCHAR2 (10);
      ls_message          VARCHAR2 (50) := '';
      ln_inv              NUMBER;
      ls_log_result       VARCHAR2 (100) := '';

      ln_begin_h          NUMBER;
      ln_begin_m          NUMBER;
      ln_end_h            NUMBER;
      ln_end_m            NUMBER;
      ld_begin_time       DATE;
      ld_end_time         DATE;

      CURSOR get_client_acc_no
      IS
         SELECT MAX (acc_no)
           FROM CBS_DCS_CUSTOMER_ACCOUNTS
          WHERE CUST_NO = pn_customer_no;

      CURSOR payment
      IS
             SELECT ID, STATUS
               FROM CBS_DCS_PLANNED_PAYMENTS
              WHERE     INVOICE_NO = ps_invoice_no
                    AND CUST_NO = pn_customer_no
                    AND SUBS_EXT_ACC_NO = ps_ext_subscriber_acc_no
                    AND PAYMENT_SUM = pn_payment_sum
                    AND PAYMENT_CURR = ps_payment_curr
                    AND VALUE_DATE = pd_value_date
                    AND STATUS = PSTATUS_ACCEPTED
         FOR UPDATE OF STATUS;

      r_payment           payment%ROWTYPE;

      CURSOR cancelled_payment
      IS
         SELECT ID
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE     INVOICE_NO = ps_invoice_no
                AND CUST_NO = pn_customer_no
                AND SUBS_EXT_ACC_NO = ps_ext_subscriber_acc_no
                AND PAYMENT_SUM = pn_payment_sum
                AND PAYMENT_CURR = ps_payment_curr
                AND VALUE_DATE = pd_value_date
                AND STATUS = PSTATUS_CANCELLED;
   BEGIN
      OPEN payment;

      FETCH payment INTO r_payment;

      IF (r_payment.ID IS NOT NULL)
      THEN
         ln_inv := r_payment.ID;
    
       IF (TRUNC(pd_value_date) < TRUNC(SYSDATE))
         THEN
            --ls_status := PSTATUS_CANCEL_TIME_EXPIRED ;
            --ls_comment := 'Cancel time expired';
            ls_message := PSTATUS_CANCEL_TIME_EXPIRED;
            ls_log_result := 'Cancel time expired';
         END IF; 
         
         IF (TRUNC (pd_value_date) = TRUNC (SYSDATE))
         THEN
            SELECT MAX (CIT.START_HH24),
                   MAX (CIT.START_MM),
                   MAX (CIT.END_HH24),
                   MAX (CIT.END_MM)
              INTO ln_begin_h,
                   ln_begin_m,
                   ln_end_h,
                   ln_end_m
              FROM CBS_INT_TIME CIT
             WHERE CIT.TRAN_CD = 'DCS_CANCEL';

            ld_begin_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_begin_h
                  || ': '
                  || ln_begin_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');
            ld_end_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_end_h
                  || ': '
                  || ln_end_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');

            IF SYSDATE NOT BETWEEN ld_begin_time AND ld_end_time
            THEN
               ls_message := PSTATUS_CANCEL_TIME_EXPIRED;
               ls_log_result :=
                     'Cancellations are accepted between '
                  || TO_CHAR (ld_begin_time, 'HH24:MI')
                  || ' and '
                  || TO_CHAR (ld_end_time, 'HH24:MI')
                  || '  '
                  || ls_log_result;
            END IF;
         END IF;

         IF (ls_message = '') OR (ls_message IS NULL)
         THEN
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_CANCELLED,
                   CANCEL_DATE = SYSDATE,
                   COMMENTS = PSTATUS_CANCELLED
             WHERE CURRENT OF payment;

            ls_message := PSTATUS_CANCELLED;                              --OK
            ls_log_result := PSTATUS_CANCELLED;
         END IF;
      ELSE
         OPEN cancelled_payment;

         FETCH cancelled_payment INTO ln_payment_id;

         CLOSE cancelled_payment;

         IF (ln_payment_id IS NULL)
         THEN
            ls_message := PSTATUS_INVOICE_NOT_FOUND;  --Payment does not exist
            ls_log_result := 'Payment does not exist';
         ELSE
            ln_inv := ln_payment_id;
            ls_message := PSTATUS_ALREADY_CANCELLED; --Payment was already cancelled
            ls_log_result := 'Payment was already cancelled';
         END IF;
      END IF;

      CLOSE payment;

      INSERT INTO CBS_DCS_LOG (ID,
                               invoice_id,
                               data_row,
                               result,
                               CREATE_DATE)
           VALUES (
                     dcs_log_seq.NEXTVAL,
                     ln_inv,
                        '300 '
                     || ps_invoice_no
                     || ' '
                     || TO_CHAR (pn_customer_no)
                     || ' '
                     || TO_CHAR (ps_ext_subscriber_acc_no)
                     || ' '
                     || TO_CHAR (pn_payment_sum)
                     || ' '
                     || ps_payment_curr
                     || ' '
                     || TO_CHAR (pd_value_date, 'dd.MM.yyyy'),
                     ls_log_result,
                     SYSDATE);

      --COMMIT;

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_message := 'OTHER ERROR ' || substr(SQLERRM, 1, 400);

         RETURN ls_message;
   END;
   
   FUNCTION CancelPaymentById (ps_id VARCHAR2)
      RETURN VARCHAR2
   IS
      ln_payment_id       NUMBER;
      ls_payment_status   VARCHAR2 (10);
      ls_message          VARCHAR2 (50) := '';
      ln_inv              NUMBER;
      ls_log_result       VARCHAR2 (100) := '';

      ln_begin_h          NUMBER;
      ln_begin_m          NUMBER;
      ln_end_h            NUMBER;
      ln_end_m            NUMBER;
      ld_begin_time       DATE;
      ld_end_time         DATE;
      
      ln_initial_sum      NUMBER;
      
      CURSOR get_client_acc_no
      IS
      
         SELECT MAX (acc_no)
           FROM CBS_DCS_CUSTOMER_ACCOUNTS
          WHERE ID=ps_id;                                                          
      CURSOR payment
      IS      
             SELECT ID, ACC_NO, CUST_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                PAYMENT_CURR, INVOICE_NO, SUBS_CUST_NO, VALUE_DATE, STATUS,
                CANCEL_DATE, CREATE_DATE, COMMENTS, FILE_DATE, SHIPMENT_DATE,
                CUST_NO, SUBS_EXT_ACC_NO, SUBS_NAME, PAYMENT_DATE
               FROM CBS_DCS_PLANNED_PAYMENTS
              WHERE STATUS = PSTATUS_ACCEPTED
                    AND INSTR(',' || ps_id || ',', ',' || TO_CHAR(ID) || ',')>0 
         FOR UPDATE OF STATUS;

      r_payment           payment%ROWTYPE;

      CURSOR cancelled_payment
      IS
         SELECT ID
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE  STATUS = PSTATUS_CANCELLED
                AND INSTR(',' || ps_id || ',', ',' || TO_CHAR(ID) || ',')>0;
   BEGIN                
      OPEN payment;

      FETCH payment INTO r_payment;

      IF (r_payment.ID IS NOT NULL)
      THEN
         ln_inv := r_payment.ID;
    
       IF (TRUNC(r_payment.VALUE_DATE) < TRUNC(SYSDATE))
         THEN
            --ls_status := PSTATUS_CANCEL_TIME_EXPIRED ;
            --ls_comment := 'Cancel time expired';
            ls_message := PSTATUS_CANCEL_TIME_EXPIRED;
            ls_log_result := 'Cancel time expired';
         END IF; 
         
         IF (TRUNC (r_payment.VALUE_DATE) = TRUNC (SYSDATE))
         THEN
            SELECT MAX (CIT.START_HH24),
                   MAX (CIT.START_MM),
                   MAX (CIT.END_HH24),
                   MAX (CIT.END_MM)
              INTO ln_begin_h,
                   ln_begin_m,
                   ln_end_h,
                   ln_end_m
              FROM CBS_INT_TIME CIT
             WHERE CIT.TRAN_CD = 'DCS_CANCEL';

            ld_begin_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_begin_h
                  || ': '
                  || ln_begin_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');
            ld_end_time :=
               TO_DATE (
                     TO_CHAR (SYSDATE, 'dd.MM.yyyy ')
                  || ln_end_h
                  || ': '
                  || ln_end_m
                  || ':00',
                  'dd.MM.yyyy HH24:MI:SS');
            
            IF SYSDATE NOT BETWEEN ld_begin_time AND ld_end_time
            THEN
               ls_message := PSTATUS_CANCEL_TIME_EXPIRED;
               ls_log_result :=
                     'Cancellations are accepted between '
                  || TO_CHAR (ld_begin_time, 'HH24:MI')
                  || ' and '
                  || TO_CHAR (ld_end_time, 'HH24:MI')
                  || '  '
                  || ls_log_result;
            END IF;
         END IF;         
         IF (ls_message = '') OR (ls_message IS NULL)
         THEN           
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_CANCELLED,
                   CANCEL_DATE = SYSDATE,
                   COMMENTS = PSTATUS_CANCELLED
             WHERE CURRENT OF payment;
             
             --AzatD
              ----- insert into helper table
              select INITIAL_SUM_hist into ln_initial_sum from
              (select INITIAL_SUM_hist from cbs_invoice_history where invoice_no_hist =  r_payment.INVOICE_NO )
              WHERE ROWNUM = 1 ;
             insert into cbs_invoice_history (initial_sum_hist,payment_sum_hist,remain_sum_hist,
                created_at,status_hist,invoice_id,invoice_no_hist) 
                values ( ln_initial_sum,0,ln_initial_sum, 
                SYSDATE,PSTATUS_CANCELLED,r_payment.id,r_payment.INVOICE_NO);             
             --AzatD        

            ls_message := PSTATUS_CANCELLED;                              --OK
            ls_log_result := PSTATUS_CANCELLED;
         END IF;
      ELSE
         OPEN cancelled_payment;

         FETCH cancelled_payment INTO ln_payment_id;

         CLOSE cancelled_payment;

         IF (ln_payment_id IS NULL)
         THEN
            ls_message := PSTATUS_INVOICE_NOT_FOUND;  --Payment does not exist
            ls_log_result := 'Payment does not exist';
         ELSE
            ln_inv := ln_payment_id;
            ls_message := PSTATUS_ALREADY_CANCELLED; --Payment was already cancelled
            ls_log_result := 'Payment was already cancelled';
         END IF;
      END IF;

      CLOSE payment;

      INSERT INTO CBS_DCS_LOG (ID,
                               invoice_id,
                               data_row,
                               result,
                               CREATE_DATE)
           VALUES (
                     dcs_log_seq.NEXTVAL,
                     ln_inv,
                        '300 '
                     || r_payment.INVOICE_NO
                     || ' '
                     || TO_CHAR (r_payment.CUST_NO)
                     || ' '
                     || TO_CHAR (r_payment.SUBS_EXT_ACC_NO)
                     || ' '
                     || TO_CHAR (r_payment.PAYMENT_SUM)
                     || ' '
                     || r_payment.PAYMENT_CURR
                     || ' '
                     || TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'),
                     ls_log_result,
                     SYSDATE);

      --COMMIT;

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_message := 'OTHER ERROR ' || substr(SQLERRM, 1, 400);
         
         RETURN ls_message;
   END;

   FUNCTION ActionBySystemCode (ps_system_code              VARCHAR2,
                                ps_invoice_no               VARCHAR2,
                                pn_customer_no              NUMBER,
                                ps_subscriber_name          VARCHAR2,
                                ps_ext_subscriber_acc_no    VARCHAR2,
                                pn_payment_sum              NUMBER,
                                ps_payment_curr             VARCHAR2,
                                pd_value_date               DATE,
                                pd_file_date                DATE,
                                pd_shipment_date            DATE)
      RETURN VARCHAR2
   IS
      ls_mess   VARCHAR2 (500) := '';
   BEGIN
      IF (ps_system_code = 'FOR PROCESSING')                             --Insert Payment
      THEN
         ls_mess :=
            InsertPayment (ps_invoice_no,
                           pn_customer_no,
                           ps_subscriber_name,
                           ps_ext_subscriber_acc_no,
                           pn_payment_sum,
                           ps_payment_curr,
                           pd_value_date,
                           pd_file_date,
                           pd_shipment_date);
      ELSE
         IF (ps_system_code = 'FOR CANCELLATION')                          --Cancel Payment
         THEN
            ls_mess :=
               CancelPayment (ps_invoice_no,
                              pn_customer_no,
                              ps_ext_subscriber_acc_no,
                              pn_payment_sum,
                              ps_payment_curr,
                              pd_value_date);
         ELSE
            IF (ps_system_code = '200')                            -- Just Log
            THEN
               JustLog (
                     ps_invoice_no
                  || ' '
                  || TO_CHAR (pn_customer_no)
                  || ' '
                  || TO_CHAR (ps_ext_subscriber_acc_no)
                  || ' '
                  || TO_CHAR (pn_payment_sum)
                  || ' '
                  || ps_payment_curr
                  || ' '
                  || TO_CHAR (pd_value_date, 'dd.MM.yyyy'));
            END IF;

            ls_mess := 'WRONG SYSTEM CODE';
         END IF;
      END IF;

      RETURN ls_mess;
      
      EXCEPTION
      WHEN OTHERS THEN
           ls_mess := 'OTHER ERROR ' || substr(SQLERRM, 1, 400);

         RETURN ls_mess;
   END;

   FUNCTION PerformPayments (pd_value_date DATE) RETURN VARCHAR2
   IS
      pragma AUTONOMOUS_TRANSACTION;
      TYPE CursorReferenceType IS REF CURSOR;

      ls_message          VARCHAR2 (350) := '000';
      ls_return_code      VARCHAR2 (300);
      ls_log              VARCHAR2 (300);
      lc_ref              CursorReferenceType;
      ln_i                NUMBER := 0;
      ln_failed           NUMBER := 0;
      ln_processed        NUMBER := 0;
      ln_total_payments   NUMBER := 0;
      ln_acc_no           NUMBER;
      ls_ext_acc_no       VARCHAR2 (20);

      CURSOR get_ext_acc_no
      IS
         SELECT EXTERNAL_HESAP_NO
           FROM CBS_HESAP
          WHERE HESAP_NO = ln_acc_no;

      CURSOR today_payments IS
         SELECT ID, ACC_NO, CUST_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                PAYMENT_CURR, INVOICE_NO, SUBS_CUST_NO, VALUE_DATE, STATUS,
                CANCEL_DATE, CREATE_DATE, COMMENTS, FILE_DATE, SHIPMENT_DATE,
                CUST_NO, SUBS_EXT_ACC_NO, SUBS_NAME, PAYMENT_DATE
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE STATUS = PSTATUS_ACCEPTED
          order by VALUE_DATE, id;

      r_payment today_payments%ROWTYPE;
      
      --CQ4480 AlmasN 13032015 variables
      ln_islem_no cbs_islem.numara%TYPE;
      ln_islem_kod cbs_islem.islem_kod%TYPE;
      ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
      ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
      ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
      ln_charge_amount number;
      ln_new_amount number;
      ln_partial_paid_amount number := 0;
      lb_is_partial_payment boolean := false;
      ln_count number;
      
      ln_available_balance number; --09042015 AlmasN CQ4680 CocaCola Defect
      ls_explanation       cbs.CBS_VIRMAN_ISLEM.aciklama%type;
   BEGIN
      OPEN today_payments;

      LOOP
         FETCH today_payments INTO r_payment;
         EXIT WHEN today_payments%NOTFOUND;

         ln_total_payments := today_payments%ROWCOUNT;

         ls_return_code := '';

         IF (r_payment.CUST_EXT_ACC_NO IS NULL) THEN
            ln_acc_no := r_payment.ACC_NO;

            OPEN get_ext_acc_no;
            FETCH get_ext_acc_no INTO ls_ext_acc_no;
            CLOSE get_ext_acc_no;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL) OR (ls_ext_acc_no IS NOT NULL) THEN
            ln_i := ln_i + 1;

            --BOM CQ4480 AlmasN 13032015 get commission
            select nvl(sum(PAYMENT_SUM), 0) into ln_partial_paid_amount
            from CBS_DCS_PLANNED_PAYMENTS
            where status = PSTATUS_PARTIAL
            and INVOICE_NO = r_payment.INVOICE_NO;

            ln_new_amount := r_payment.PAYMENT_SUM - ln_partial_paid_amount; -- new amount is not paid amout

            Begin
                ln_islem_no := Pkg_Tx.islem_no_al;
                ln_islem_kod := 1203;
                Pkg_Tx1203.sp_urun_tur_sinif_al(TO_CHAR (r_payment.SUBS_ACC_NO), COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no), r_payment.PAYMENT_CURR, 'E',
                                                ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod);

                ln_charge_amount:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_new_amount, 
                                                              Pkg_Hesap.hesapsubeal(TO_CHAR(r_payment.SUBS_ACC_NO)), r_payment.PAYMENT_CURR, Pkg_Hesap.hesaptanmusterinoal(r_payment.SUBS_ACC_NO), r_payment.SUBS_ACC_NO, null);
            Exception
                When Others Then
                    ln_CHARGE_AMOUNT:=0;
            End;
            
            select count(1) into ln_count
            from CBS_DCS_SUBSCRIBER_ACCOUNTS
            where SUBS_ACC_NO = r_payment.SUBS_ACC_NO
            and STATUS='ACTIVE'
            and PARTIAL_PAYMENT = 'Y';

            if (ln_count=0) then
                lb_is_partial_payment := false;
            else
                lb_is_partial_payment := true;
            end if;

            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (r_payment.VALUE_DATE <= TRUNC(SYSDATE)) then
                ln_available_balance := PKG_HESAP.KULLANILABILIR_BAKIYE_AL(r_payment.SUBS_ACC_NO);
            else
                PKG_HESAP.BAKIYEBILGIAL(r_payment.SUBS_ACC_NO, ln_available_balance, ln_count, ln_count);
            end if;

            if (ln_available_balance < ln_new_amount + ln_charge_amount and 
                ln_available_balance > ln_charge_amount and lb_is_partial_payment) then
                ln_new_amount := ln_available_balance - ln_charge_amount;
            end if;
            --EOM CQ4480 AlmasN 13032015 get commission
            log_at('dcs_payment',r_payment.INVOICE_NO,r_payment.PAYMENT_SUM,ln_partial_paid_amount);
            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (ln_available_balance <= ln_charge_amount) then
                ls_return_code := '998';
            else
--                pkg_parametre.deger('DSC_DEFAULT_EXPLANATION', ls_explanation);

                ls_return_code :=
                   PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER (
                      TO_CHAR (r_payment.SUBS_ACC_NO),
                      COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no),
                      TO_CHAR (ln_new_amount,'999999999999999.9999'),
                      'DCS/Оплата за товары/'||r_payment.SUBS_NAME||'/'||r_payment.INVOICE_NO||'/'||r_payment.PAYMENT_SUM,                     --ps_description
                      r_payment.PAYMENT_CURR,
                      '',                        --ps_isdekont
                      '',                        --ps_paymentcode
                      ' ',                       --chyngyzo cq1264 add payment order number parameter
                      lc_ref);                   --pc_ref OUT cursorreferencetype
            end if;

         END IF;

         IF (ls_return_code = '000') THEN

            --CQ4480 AlmasN 13032015 make partial payment log
            
            if (ln_new_amount <> (r_payment.PAYMENT_SUM - ln_partial_paid_amount)) then
                INSERT INTO CBS_DCS_PLANNED_PAYMENTS (ID, INVOICE_NO, CUST_NO, ACC_NO, CUST_EXT_ACC_NO,
                                                      SUBS_CUST_NO, SUBS_NAME, SUBS_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                                                      PAYMENT_CURR, VALUE_DATE, FILE_DATE, SHIPMENT_DATE, STATUS,
                                                      CREATE_DATE, COMMENTS, PAYMENT_DATE)
                VALUES (dcs_payments_seq.NEXTVAL, r_payment.INVOICE_NO, r_payment.CUST_NO, r_payment.ACC_NO, r_payment.CUST_EXT_ACC_NO,
                        r_payment.SUBS_CUST_NO, r_payment.SUBS_NAME, r_payment.SUBS_EXT_ACC_NO, r_payment.SUBS_ACC_NO, ln_new_amount,
                        r_payment.PAYMENT_CURR, r_payment.VALUE_DATE, r_payment.FILE_DATE, r_payment.SHIPMENT_DATE, PSTATUS_PARTIAL,
                        SYSDATE, r_payment.COMMENTS, pkg_muhasebe.banka_tarihi_bul);

                INSERT INTO CBS_DCS_LOG (ID, invoice_id, data_row, result, CREATE_DATE)
                VALUES (dcs_log_seq.NEXTVAL, dcs_payments_seq.CURRVAL, '100 ' || r_payment.INVOICE_NO || ' ' || TO_CHAR (r_payment.CUST_NO) || ' ' || 
                                                                       TO_CHAR (r_payment.ACC_NO) || ' ' || TO_CHAR (ln_new_amount) || ' ' || r_payment.PAYMENT_CURR || ' ' || 
                                                                       TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'), 
                        PSTATUS_PARTIAL, SYSDATE);

                -- CQ4480 Almas Notify customer about performed payment            
                select dcs_payments_seq.CURRVAL into ln_count from dual;

                PKG_DCS.NotifyPerformedStatus(ln_count);
            else
                UPDATE CBS_DCS_PLANNED_PAYMENTS
                   SET STATUS = PSTATUS_PROCESSED,
                       COMMENTS = PSTATUS_PROCESSED,
                       PAYMENT_DATE = pkg_muhasebe.banka_tarihi_bul,
                       PAYMENT_SUM = ln_new_amount
                 WHERE ID = r_payment.ID;

                -- CQ4480 Almas Notify customer about performed payment            
                PKG_DCS.NotifyPerformedStatus(r_payment.ID);
            end if;

            ln_processed := ln_processed + 1;

            ls_log := 'Payment Done';

         ELSE
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_FAILED,
                   COMMENTS =
                      'FAILED ' || ls_return_code
                      || DECODE (ls_return_code,
                                 '502', ' - ' || PSTATUS_NOT_ENOUGH_BALANCE,
                                 '')
             WHERE ID = r_payment.ID
             AND   VALUE_DATE <= trunc(sysdate - 45);

            ln_failed := ln_failed + 1;

            ls_message := PSTATUS_FAILED;                             --Failed

            ls_log := 'Payment Failed ' || ls_return_code;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL)
            OR (ls_ext_acc_no IS NOT NULL)
         THEN
            INSERT INTO CBS_DCS_LOG (ID,
                                     invoice_id,
                                     data_row,
                                     result,
                                     CREATE_DATE)
                 VALUES (
                           dcs_log_seq.NEXTVAL,
                           r_payment.ID,
                              'Payment '
                           || TO_CHAR (r_payment.ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.SUBS_ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.PAYMENT_SUM)
                           || ' '
                           || r_payment.PAYMENT_CURR,
                           ls_log,
                           SYSDATE);
         END IF;
         
         -- commit added information
         commit;
      END LOOP;

      CLOSE today_payments;

      IF (ln_i = 0) AND (ls_message = '000')
      THEN
         ls_message := PSTATUS_NO_PAYMENTS;            --No payments for today
         RETURN ls_message;
      END IF;

      ls_message :=
            'Total number of payments: '
         || ln_total_payments
         || '. Payments processed successfully: '
         || ln_processed
         || '. Payments failed to process: '
         || ln_failed
         || '.';

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS THEN
         LOG_AT('DCS', 'PerformPayments', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
      
         IF today_payments%ISOPEN
         THEN
            CLOSE today_payments;
         END IF;

         IF lc_ref%ISOPEN
         THEN
            CLOSE lc_ref;
         END IF;

         ls_message := 'ERROR ' || SUBSTR (SQLERRM, 1, 300);

         RETURN ls_message;
   END;
   
   FUNCTION PerformPaymentsNew (pd_value_date DATE) RETURN VARCHAR2
   IS
      pragma AUTONOMOUS_TRANSACTION;
      TYPE CursorReferenceType IS REF CURSOR;

      ls_message          VARCHAR2 (350) := '000';
      ls_return_code      VARCHAR2 (300);
      ls_log              VARCHAR2 (300);
      lc_ref              CursorReferenceType;
      ln_i                NUMBER := 0;
      ln_failed           NUMBER := 0;
      ln_processed        NUMBER := 0;
      ln_total_payments   NUMBER := 0;
      ln_acc_no           NUMBER;
      ls_ext_acc_no       VARCHAR2 (20);
      
      

      CURSOR get_ext_acc_no
      IS
         SELECT EXTERNAL_HESAP_NO
           FROM CBS_HESAP
          WHERE HESAP_NO = ln_acc_no;

      CURSOR today_payments IS
         SELECT ID, ACC_NO, CUST_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                PAYMENT_CURR, INVOICE_NO, SUBS_CUST_NO, VALUE_DATE, STATUS,
                CANCEL_DATE, CREATE_DATE, COMMENTS, FILE_DATE, SHIPMENT_DATE,
                CUST_NO, SUBS_EXT_ACC_NO, SUBS_NAME, PAYMENT_DATE
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE STATUS = PSTATUS_ACCEPTED
          order by VALUE_DATE, id;

      r_payment today_payments%ROWTYPE;
      
      --CQ4480 AlmasN 13032015 variables
      ln_islem_no cbs_islem.numara%TYPE;
      ln_islem_kod cbs_islem.islem_kod%TYPE;
      ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
      ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
      ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
      ln_charge_amount number;
      ln_new_amount number;
      ln_partial_paid_amount number := 0;
      lb_is_partial_payment boolean := false;
      ln_count number;
      
      ln_invoice_id number;
      ln_initial_sum number;--AzatD
      
      ln_available_balance number; --09042015 AlmasN CQ4680 CocaCola Defect
      ls_explanation       cbs.CBS_VIRMAN_ISLEM.aciklama%type;
   BEGIN
      OPEN today_payments;

      LOOP
         FETCH today_payments INTO r_payment;
         EXIT WHEN today_payments%NOTFOUND;

         ln_total_payments := today_payments%ROWCOUNT;

         ls_return_code := '';

         IF (r_payment.CUST_EXT_ACC_NO IS NULL) THEN
            ln_acc_no := r_payment.ACC_NO;

            OPEN get_ext_acc_no;
            FETCH get_ext_acc_no INTO ls_ext_acc_no;
            CLOSE get_ext_acc_no;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL) OR (ls_ext_acc_no IS NOT NULL) THEN
            ln_i := ln_i + 1;

            --BOM CQ4480 AlmasN 13032015 get commission
            select nvl(sum(PAYMENT_SUM), 0) into ln_partial_paid_amount
            from CBS_DCS_PLANNED_PAYMENTS
            where status = PSTATUS_PARTIAL
            and INVOICE_NO = r_payment.INVOICE_NO;

            ln_new_amount := r_payment.PAYMENT_SUM - ln_partial_paid_amount; -- new amount is not paid amout

            Begin
                ln_islem_no := Pkg_Tx.islem_no_al;
                ln_islem_kod := 1203;
                Pkg_Tx1203.sp_urun_tur_sinif_al(TO_CHAR (r_payment.SUBS_ACC_NO), COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no), r_payment.PAYMENT_CURR, 'E',
                                                ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod);

                ln_charge_amount:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_new_amount, 
                                                              Pkg_Hesap.hesapsubeal(TO_CHAR(r_payment.SUBS_ACC_NO)), r_payment.PAYMENT_CURR, Pkg_Hesap.hesaptanmusterinoal(r_payment.SUBS_ACC_NO), r_payment.SUBS_ACC_NO, null);
            Exception
                When Others Then
                    ln_CHARGE_AMOUNT:=0;
            End;
            
            select count(1) into ln_count
            from CBS_DCS_SUBSCRIBER_ACCOUNTS
            where SUBS_ACC_NO = r_payment.SUBS_ACC_NO
            and STATUS='ACTIVE'
            and PARTIAL_PAYMENT = 'Y';

            if (ln_count=0) then
                lb_is_partial_payment := false;
            else
                lb_is_partial_payment := true;
            end if;

            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (r_payment.VALUE_DATE <= TRUNC(SYSDATE)) then
                ln_available_balance := PKG_HESAP.KULLANILABILIR_BAKIYE_AL(r_payment.SUBS_ACC_NO);
            else
                PKG_HESAP.BAKIYEBILGIAL(r_payment.SUBS_ACC_NO, ln_available_balance, ln_count, ln_count);
            end if;

            if (ln_available_balance < ln_new_amount + ln_charge_amount and 
                ln_available_balance > ln_charge_amount and lb_is_partial_payment) then
                ln_new_amount := ln_available_balance - ln_charge_amount;
            end if;
            --EOM CQ4480 AlmasN 13032015 get commission
            log_at('dcs_payment',r_payment.INVOICE_NO,r_payment.PAYMENT_SUM,ln_partial_paid_amount);
            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (ln_available_balance <= ln_charge_amount) then
                ls_return_code := '998';
            else
--                pkg_parametre.deger('DSC_DEFAULT_EXPLANATION', ls_explanation);

                ls_return_code :=
                   PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER (
                      TO_CHAR (r_payment.SUBS_ACC_NO),
                      COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no),
                      TO_CHAR (ln_new_amount,'999999999999999.9999'),
                      'DCS/Оплата за товары/'||r_payment.SUBS_NAME||'/'||r_payment.INVOICE_NO||'/'||r_payment.PAYMENT_SUM,                     --ps_description
                      r_payment.PAYMENT_CURR,
                      '',                        --ps_isdekont
                      '',                        --ps_paymentcode
                      ' ',                       --chyngyzo cq1264 add payment order number parameter
                      lc_ref);                   --pc_ref OUT cursorreferencetype
            end if;

         END IF;

         IF (ls_return_code = '000') THEN

            --CQ4480 AlmasN 13032015 make partial payment log
            
            if (ln_new_amount <> (r_payment.PAYMENT_SUM - ln_partial_paid_amount)) then
                INSERT INTO CBS_DCS_PLANNED_PAYMENTS (ID, INVOICE_NO, CUST_NO, ACC_NO, CUST_EXT_ACC_NO,
                                                      SUBS_CUST_NO, SUBS_NAME, SUBS_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                                                      PAYMENT_CURR, VALUE_DATE, FILE_DATE, SHIPMENT_DATE, STATUS,
                                                      CREATE_DATE, COMMENTS, PAYMENT_DATE)
                VALUES (dcs_payments_seq.NEXTVAL, r_payment.INVOICE_NO, r_payment.CUST_NO, r_payment.ACC_NO, r_payment.CUST_EXT_ACC_NO,
                        r_payment.SUBS_CUST_NO, r_payment.SUBS_NAME, r_payment.SUBS_EXT_ACC_NO, r_payment.SUBS_ACC_NO, ln_new_amount,
                        r_payment.PAYMENT_CURR, r_payment.VALUE_DATE, r_payment.FILE_DATE, r_payment.SHIPMENT_DATE, PSTATUS_PARTIAL,
                        SYSDATE, r_payment.COMMENTS, pkg_muhasebe.banka_tarihi_bul);
                        
                
                --AzatD                
                 ----- insert into helper table
                 select INITIAL_SUM_hist into ln_initial_sum from
                  (select INITIAL_SUM_hist from cbs_invoice_history where invoice_no_hist =  r_payment.INVOICE_NO )
                  WHERE ROWNUM = 1;
                 insert into cbs_invoice_history (payment_sum_hist,initial_sum_hist,remain_sum_hist,created_at,status_hist,invoice_id,invoice_no_hist) 
                    values (ln_new_amount,ln_initial_sum,ln_initial_sum-(ln_partial_paid_amount+ln_new_amount), SYSDATE,PSTATUS_PARTIAL,dcs_payments_seq.CURRVAL,r_payment.INVOICE_NO);                                           
                --AzatD
                                            

                INSERT INTO CBS_DCS_LOG (ID, invoice_id, data_row, result, CREATE_DATE)
                VALUES (dcs_log_seq.NEXTVAL, dcs_payments_seq.CURRVAL, '100 ' || r_payment.INVOICE_NO || ' ' || TO_CHAR (r_payment.CUST_NO) || ' ' || 
                                                                       TO_CHAR (r_payment.ACC_NO) || ' ' || TO_CHAR (ln_new_amount) || ' ' || r_payment.PAYMENT_CURR || ' ' || 
                                                                       TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'), 
                        PSTATUS_PARTIAL, SYSDATE);

                -- CQ4480 Almas Notify customer about performed payment            
                select dcs_payments_seq.CURRVAL into ln_count from dual;

                PKG_DCS.NotifyPerformedStatus(ln_count);
            else
                UPDATE CBS_DCS_PLANNED_PAYMENTS
                   SET STATUS = PSTATUS_PROCESSED,
                       COMMENTS = PSTATUS_PROCESSED,
                       PAYMENT_DATE = pkg_muhasebe.banka_tarihi_bul,
                       PAYMENT_SUM = ln_new_amount,
                       REMAIN_SUM=0
                 WHERE ID = r_payment.ID;

                -- CQ4480 Almas Notify customer about performed payment   
                
                  --AzatD
                  select INITIAL_SUM_hist into ln_initial_sum from
                  (select INITIAL_SUM_hist from cbs_invoice_history where invoice_no_hist =  r_payment.INVOICE_NO)
                  WHERE ROWNUM = 1;
                  
                  select id into ln_invoice_id   from CBS_DCS_PLANNED_PAYMENTS where status = PSTATUS_PROCESSED  and invoice_no = r_payment.invoice_no;
                    insert into cbs_invoice_history (payment_sum_hist,INITIAL_SUM_hist,remain_sum_hist,created_at,status_hist,invoice_id,invoice_no_hist) 
                    values (ln_new_amount,ln_initial_sum,0,SYSDATE,PSTATUS_PROCESSED,ln_invoice_id,r_payment.INVOICE_NO);
                    --AzatD
                    
                             
                PKG_DCS.NotifyPerformedStatus(r_payment.ID);
            end if;

            ln_processed := ln_processed + 1;

            ls_log := 'Payment Done';

         ELSE
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_FAILED,
                   COMMENTS =
                      'FAILED ' || ls_return_code
                      || DECODE (ls_return_code,
                                 '502', ' - ' || PSTATUS_NOT_ENOUGH_BALANCE,
                                 '')
             WHERE ID = r_payment.ID
             AND   VALUE_DATE <= trunc(sysdate - 45);

            ln_failed := ln_failed + 1;

            ls_message := PSTATUS_FAILED;                             --Failed

            ls_log := 'Payment Failed ' || ls_return_code;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL)
            OR (ls_ext_acc_no IS NOT NULL)
         THEN
            INSERT INTO CBS_DCS_LOG (ID,
                                     invoice_id,
                                     data_row,
                                     result,
                                     CREATE_DATE)
                 VALUES (
                           dcs_log_seq.NEXTVAL,
                           r_payment.ID,
                              'Payment '
                           || TO_CHAR (r_payment.ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.SUBS_ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.PAYMENT_SUM)
                           || ' '
                           || r_payment.PAYMENT_CURR,
                           ls_log,
                           SYSDATE);
         END IF;
         
         -- commit added information
         commit;
      END LOOP;

      CLOSE today_payments;

      IF (ln_i = 0) AND (ls_message = '000')
      THEN
         ls_message := PSTATUS_NO_PAYMENTS;            --No payments for today
         RETURN ls_message;
      END IF;

      ls_message :=
            'Total number of payments: '
         || ln_total_payments
         || '. Payments processed successfully: '
         || ln_processed
         || '. Payments failed to process: '
         || ln_failed
         || '.';

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS THEN
         LOG_AT('DCS', 'PerformPayments', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
      
         IF today_payments%ISOPEN
         THEN
            CLOSE today_payments;
         END IF;

         IF lc_ref%ISOPEN
         THEN
            CLOSE lc_ref;
         END IF;

         ls_message := 'ERROR ' || SUBSTR (SQLERRM, 1, 300);

         RETURN ls_message;
   END;
   
   
   --BOF 05/02/2019 RTalantbekova
    FUNCTION PerformPaymentsById (ps_id VARCHAR2, ps_payment_sum NUMBER) RETURN VARCHAR2
   IS
      --pragma AUTONOMOUS_TRANSACTION;
      TYPE CursorReferenceType IS REF CURSOR;

      ls_message          VARCHAR2 (350) := '000';
      ls_return_code      VARCHAR2 (300);
      ls_log              VARCHAR2 (300);
      lc_ref              CursorReferenceType;
      ln_i                NUMBER := 0;
      ln_failed           NUMBER := 0;
      ln_processed        NUMBER := 0;
      ln_total_payments   NUMBER := 0;
      ln_acc_no           NUMBER;
      ls_ext_acc_no       VARCHAR2 (20);
      ls_invoice_no       VARCHAR2 (100);

      CURSOR get_ext_acc_no
      IS
         SELECT EXTERNAL_HESAP_NO
           FROM CBS_HESAP
          WHERE HESAP_NO = ln_acc_no;

      CURSOR today_payments IS
         SELECT ID, ACC_NO, CUST_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                PAYMENT_CURR, INVOICE_NO, SUBS_CUST_NO, VALUE_DATE, STATUS,
                CANCEL_DATE, CREATE_DATE, COMMENTS, FILE_DATE, SHIPMENT_DATE,
                CUST_NO, SUBS_EXT_ACC_NO, SUBS_NAME, PAYMENT_DATE, REMAIN_SUM
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE (STATUS = PSTATUS_ACCEPTED or STATUS = PSTATUS_PARTIAL)
          AND INSTR(',' || ps_id || ',', ',' || TO_CHAR(ID) || ',')>0
          order by VALUE_DATE, id;

      r_payment today_payments%ROWTYPE;
      
      --CQ4480 AlmasN 13032015 variables
      ln_islem_no cbs_islem.numara%TYPE;
      ln_islem_kod cbs_islem.islem_kod%TYPE;
      ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
      ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
      ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
      ln_charge_amount number;
      ln_new_amount number;
      ln_partial_paid_amount number := 0;
      lb_is_partial_payment boolean := false;
      ln_count number;
      
      ln_available_balance number; --09042015 AlmasN CQ4680 CocaCola Defect
   BEGIN    
      OPEN today_payments;      
      LOOP
         FETCH today_payments INTO r_payment;
         EXIT WHEN today_payments%NOTFOUND;

         ln_total_payments := today_payments%ROWCOUNT;

         ls_return_code := '';

         IF (r_payment.CUST_EXT_ACC_NO IS NULL) THEN
            ln_acc_no := r_payment.ACC_NO;

            OPEN get_ext_acc_no;
            FETCH get_ext_acc_no INTO ls_ext_acc_no;
            CLOSE get_ext_acc_no;
         END IF;                                   
         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL) OR (ls_ext_acc_no IS NOT NULL) THEN
             ln_i := ln_i + 1;
             ln_partial_paid_amount := ps_payment_sum;
             if (r_payment.PAYMENT_SUM > 0) or (r_payment.REMAIN_SUM > 0) then
                if ln_partial_paid_amount < r_payment.REMAIN_SUM then
                    ln_new_amount := r_payment.REMAIN_SUM - ln_partial_paid_amount; --new amount is not paid amout
                elsif ln_partial_paid_amount = r_payment.REMAIN_SUM then
                    ln_new_amount := r_payment.REMAIN_SUM;
                end if;
             else
                if ln_partial_paid_amount < r_payment.PAYMENT_SUM then
                    ln_new_amount := r_payment.PAYMENT_SUM - ln_partial_paid_amount; --new amount is not paid amout
                elsif ln_partial_paid_amount = r_payment.PAYMENT_SUM then
                    ln_new_amount := r_payment.PAYMENT_SUM;
                end if;
             end if;
             
            Begin
                ln_islem_no := Pkg_Tx.islem_no_al;
                ln_islem_kod := 1203;
                Pkg_Tx1203.sp_urun_tur_sinif_al(TO_CHAR (r_payment.SUBS_ACC_NO), COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no), r_payment.PAYMENT_CURR, 'E',
                                                ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod);

                ln_charge_amount:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_partial_paid_amount, 
                                                              Pkg_Hesap.hesapsubeal(TO_CHAR(r_payment.SUBS_ACC_NO)), r_payment.PAYMENT_CURR, Pkg_Hesap.hesaptanmusterinoal(r_payment.SUBS_ACC_NO), r_payment.SUBS_ACC_NO, null);
            Exception
                When Others Then
                    ln_CHARGE_AMOUNT:=0;
            End;
            
            select count(1) into ln_count
            from CBS_DCS_SUBSCRIBER_ACCOUNTS
            where SUBS_ACC_NO = r_payment.SUBS_ACC_NO
            and STATUS='ACTIVE'
            and PARTIAL_PAYMENT = 'Y';

            if (ln_count=0) then
                lb_is_partial_payment := false;
            else
                lb_is_partial_payment := true;
            end if;

            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (r_payment.VALUE_DATE <= TRUNC(SYSDATE)) then
                ln_available_balance := PKG_HESAP.KULLANILABILIR_BAKIYE_AL(r_payment.SUBS_ACC_NO);
            else
                PKG_HESAP.BAKIYEBILGIAL(r_payment.SUBS_ACC_NO, ln_available_balance, ln_count, ln_count);
            end if;
            if (ln_available_balance < ln_partial_paid_amount + ln_charge_amount and 
                ln_available_balance > ln_charge_amount and lb_is_partial_payment) then
                ln_partial_paid_amount := ln_available_balance - ln_charge_amount;
            end if;
            --EOM CQ4480 AlmasN 13032015 get commission
            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance
            if (ln_available_balance <= ln_charge_amount) then
                ls_return_code := '998';
            else                
                ls_return_code :=
                   PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER (
                      TO_CHAR (r_payment.SUBS_ACC_NO),
                      COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no),
                      TO_CHAR (ln_partial_paid_amount),
                      'DCS/ќплата за товары/'||r_payment.SUBS_NAME||'/'||r_payment.INVOICE_NO||'/'||ln_partial_paid_amount,                     --ps_description
                      r_payment.PAYMENT_CURR,
                      '',                        --ps_isdekont
                      '',                        --ps_paymentcode
                      ' ',                       --chyngyzo cq1264 add payment order number parameter
                      lc_ref);                   --pc_ref OUT cursorreferencetype
            end if;

         END IF;
        log_at('azatpreif',ls_return_code,ln_partial_paid_amount,r_payment.PAYMENT_SUM);
         IF (ls_return_code = '000') THEN
            --CQ4480 AlmasN 13032015 make partial payment log            
            if (ln_partial_paid_amount <> r_payment.PAYMENT_SUM) then
            log_at('azatbegin',ln_partial_paid_amount,r_payment.PAYMENT_SUM);
                 INSERT INTO CBS_DCS_PLANNED_PAYMENTS (ID, INVOICE_NO, CUST_NO, ACC_NO, CUST_EXT_ACC_NO,
                                                      SUBS_CUST_NO, SUBS_NAME, SUBS_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                                                      PAYMENT_CURR, VALUE_DATE, FILE_DATE, SHIPMENT_DATE, STATUS,
                                                      CREATE_DATE, COMMENTS, PAYMENT_DATE)
                VALUES (dcs_payments_seq.NEXTVAL, r_payment.INVOICE_NO, r_payment.CUST_NO, r_payment.ACC_NO, r_payment.CUST_EXT_ACC_NO,
                        r_payment.SUBS_CUST_NO, r_payment.SUBS_NAME, r_payment.SUBS_EXT_ACC_NO, r_payment.SUBS_ACC_NO, ln_new_amount,
                        r_payment.PAYMENT_CURR, r_payment.VALUE_DATE, r_payment.FILE_DATE, r_payment.SHIPMENT_DATE, PSTATUS_PARTIAL,
                        SYSDATE, r_payment.COMMENTS, pkg_muhasebe.banka_tarihi_bul);

                INSERT INTO CBS_DCS_LOG (ID, invoice_id, data_row, result, CREATE_DATE)
                VALUES (dcs_log_seq.NEXTVAL, dcs_payments_seq.CURRVAL, '100 ' || r_payment.INVOICE_NO || ' ' || TO_CHAR (r_payment.CUST_NO) || ' ' || 
                                                                       TO_CHAR (r_payment.ACC_NO) || ' ' || TO_CHAR (ln_partial_paid_amount) || ' ' || r_payment.PAYMENT_CURR || ' ' || 
                                                                       TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'), 
                        PSTATUS_PARTIAL, SYSDATE);

                -- CQ4480 Almas Notify customer about performed payment            
                select dcs_payments_seq.CURRVAL into ln_count from dual;

                PKG_DCS.NotifyPerformedStatus(ln_count);
            else
                log_at('azatbegin4',ln_partial_paid_amount,r_payment.PAYMENT_SUM);
                UPDATE CBS_DCS_PLANNED_PAYMENTS
                   SET STATUS = PSTATUS_PROCESSED,
                       COMMENTS = PSTATUS_PROCESSED,
                       PAYMENT_DATE = pkg_muhasebe.banka_tarihi_bul,
                       PAYMENT_SUM = ln_partial_paid_amount,
                       REMAIN_SUM = 0
                 WHERE ID = r_payment.ID;

                -- CQ4480 Almas Notify customer about performed payment            
                PKG_DCS.NotifyPerformedStatus(r_payment.ID);
            end if;

            ln_processed := ln_processed + 1;
            ls_message := r_payment.INVOICE_NO||'->'||PSTATUS_PROCESSED;
            ls_log := 'Payment Done';

         ELSE
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_FAILED,
                   COMMENTS =
                      'FAILED ' || ls_return_code
                      || DECODE (ls_return_code,
                                 '502', ' - ' || PSTATUS_NOT_ENOUGH_BALANCE,
                                 '')
             WHERE ID = r_payment.ID
             AND   VALUE_DATE <= trunc(sysdate - 45);

            ln_failed := ln_failed + 1;

            ls_message := r_payment.INVOICE_NO||'->'||PSTATUS_FAILED;                             --Failed

            ls_log := 'Payment Failed ' || ls_return_code;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL)
            OR (ls_ext_acc_no IS NOT NULL)
         THEN
            INSERT INTO CBS_DCS_LOG (ID,
                                     invoice_id,
                                     data_row,
                                     result,
                                     CREATE_DATE)
                 VALUES (
                           dcs_log_seq.NEXTVAL,
                           r_payment.ID,
                              'Payment '
                           || TO_CHAR (r_payment.ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.SUBS_ACC_NO)
                           || ' '
                           || TO_CHAR (r_payment.PAYMENT_SUM)
                           || ' '
                           || r_payment.PAYMENT_CURR,
                           ls_log,
                           SYSDATE);
         END IF;                  
         -- commit added information
         commit;
      END LOOP;

      CLOSE today_payments;

      IF (ln_i = 0) AND (ls_message = '000')
      THEN
        select P.INVOICE_NO into ls_invoice_no from CBS_DCS_PLANNED_PAYMENTS p where P.ID=ps_id;
        ls_message := ls_invoice_no||'->'||PSTATUS_NO_PAYMENTS;            --No payments for today
         RETURN ls_message;
      END IF;

      ls_message :=
            'Total number of payments: '
         || ln_total_payments
         || '. Payments processed successfully: '
         || ln_processed
         || '. Payments failed to process: '
         || ln_failed
         || '.';

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS THEN
         LOG_AT('DCS', 'PerformPayments', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
      
         IF today_payments%ISOPEN
         THEN
            CLOSE today_payments;
         END IF;

         IF lc_ref%ISOPEN
         THEN
            CLOSE lc_ref;
         END IF;

         ls_message := 'ERROR ' || SUBSTR (SQLERRM, 1, 300);

         RETURN ls_message;
   END;
  --EOF
  
  
   FUNCTION PerformPaymentsById2 (ps_id VARCHAR2, ps_payment_sum NUMBER) RETURN VARCHAR2
   IS
--      pragma AUTONOMOUS_TRAnSACTION;
      TYPE CursorReferenceType IS REF CURSOR;

      ls_message          VARCHAR2 (350) := '000';
      ls_return_code      VARCHAR2 (300);
      ls_log              VARCHAR2 (300);
      lc_ref              CursorReferenceType;
      ln_i                NUMBER := 0;
      ln_failed           NUMBER := 0;
      ln_processed        NUMBER := 0;
      ln_total_payments   NUMBER := 0;
      ln_acc_no           NUMBER;
      ls_ext_acc_no       VARCHAR2 (20);
      pd_value_date DATE;
      remain_sum   NUMBER := 0;
      invoice_id   NUMBER := 0;  --AzatD    

      CURSOR get_ext_acc_no
      IS
         SELECT EXTERNAL_HESAP_NO
           FROM CBS_HESAP
          WHERE HESAP_NO = ln_acc_no;

     CURSOR today_payments IS
         SELECT ID, ACC_NO, CUST_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                PAYMENT_CURR, INVOICE_NO, SUBS_CUST_NO, VALUE_DATE, STATUS,
                CANCEL_DATE, CREATE_DATE, COMMENTS, FILE_DATE, SHIPMENT_DATE,
                CUST_NO, SUBS_EXT_ACC_NO, SUBS_NAME, PAYMENT_DATE, REMAIN_SUM
           FROM CBS_DCS_PLANNED_PAYMENTS
          WHERE (STATUS = PSTATUS_ACCEPTED or STATUS = PSTATUS_PARTIAL)
          AND INSTR(',' || ps_id || ',', ',' || TO_CHAR(ID) || ',')>0
          order by VALUE_DATE, id;

      r_payment today_payments%ROWTYPE;
      
      --CQ4480 AlmasN 13032015 variables
      ln_islem_no cbs_islem.numara%TYPE;
      ln_islem_kod cbs_islem.islem_kod%TYPE;
      ls_modul_tur_kod cbs_islem.modul_tur_kod%TYPE;
      ls_urun_tur_kod cbs_islem.urun_tur_kod%TYPE;
      ls_urun_sinif_kod cbs_islem.urun_sinif_kod%TYPE;
      ln_charge_amount number;
      ln_new_amount number;
      ln_partial_paid_amount number := 0;
      lb_is_partial_payment boolean := false;
      ln_count number;
      ln_initial_sum number;--AzatD
      
      ln_available_balance number; --09042015 AlmasN CQ4680 CocaCola Defect     
   BEGIN      
      
      OPEN today_payments;

      LOOP
         FETCH today_payments INTO r_payment;
         EXIT WHEN today_payments%NOTFOUND;
        
         ln_total_payments := today_payments%ROWCOUNT;

         ls_return_code := '';

         IF (r_payment.CUST_EXT_ACC_NO IS NULL) THEN
            ln_acc_no := r_payment.ACC_NO;

            OPEN get_ext_acc_no;
            FETCH get_ext_acc_no INTO ls_ext_acc_no;
            CLOSE get_ext_acc_no;
         END IF;

         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL) OR (ls_ext_acc_no IS NOT NULL) THEN
            ln_i := ln_i + 1;

            --BOM CQ4480 AlmasN 13032015 get commission
            --amount already paid
            select nvl(sum(PAYMENT_SUM), 0) into ln_partial_paid_amount
            from CBS_DCS_PLANNED_PAYMENTS
            where status = PSTATUS_PARTIAL
            and INVOICE_NO = r_payment.INVOICE_NO;

            
            
            --AzatD
--             select INITIAL_SUM_hist into ln_initial_sum from
--              (select INITIAL_SUM_hist from cbs_invoice_history where invoice_no_hist = r_payment.INVOICE_NO  )
--              WHERE ROWNUM = 1;
            
                select payment_sum                 
                into ln_initial_sum from CBS_DCS_PLANNED_PAYMENTS where invoice_no = r_payment.INVOICE_NO and STATUS=PSTATUS_ACCEPTED;
                
                select ln_initial_sum-ln_partial_paid_amount                 
                into remain_sum from CBS_DCS_PLANNED_PAYMENTS where invoice_no = r_payment.INVOICE_NO and STATUS=PSTATUS_ACCEPTED;                            
            
            if(ps_payment_sum>=remain_sum) then 
                ln_new_amount := remain_sum;
            else 
                ln_new_amount := ps_payment_sum; -- new amount is not paid amout                
            end if;
            log_at('azatbegin10', ps_payment_sum,ln_new_amount, TO_CHAR (ln_new_amount) || ','||TO_NUMBER(TO_CHAR (ln_new_amount),'999999999999999.9999')||
            ','||TO_CHAR (ln_new_amount,'999999999999999.9999'));
            --AzatD
            
            Begin
                ln_islem_no := Pkg_Tx.islem_no_al;
                ln_islem_kod := 1203;
                Pkg_Tx1203.sp_urun_tur_sinif_al(TO_CHAR (r_payment.SUBS_ACC_NO), COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no), r_payment.PAYMENT_CURR, 'E',
                                                ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod);

                ln_charge_amount:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_new_amount, 
                                                              Pkg_Hesap.hesapsubeal(TO_CHAR(r_payment.SUBS_ACC_NO)), r_payment.PAYMENT_CURR, Pkg_Hesap.hesaptanmusterinoal(r_payment.SUBS_ACC_NO), r_payment.SUBS_ACC_NO, null);
            Exception
                When Others Then
                    ln_CHARGE_AMOUNT:=0;
            End;  
                
            select count(1) into ln_count
            from CBS_DCS_SUBSCRIBER_ACCOUNTS
            where SUBS_ACC_NO = r_payment.SUBS_ACC_NO
            and STATUS='ACTIVE'
            and PARTIAL_PAYMENT = 'Y';

            if (ln_count=0) then
                lb_is_partial_payment := false;
            else
                lb_is_partial_payment := true;
            end if;

            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance                        
--            if (r_payment.VALUE_DATE <= TRUNC(SYSDATE)) then
                ln_available_balance := PKG_HESAP.KULLANILABILIR_BAKIYE_AL(r_payment.SUBS_ACC_NO);                 
--            else
            
--                PKG_HESAP.BAKIYEBILGIAL(r_payment.SUBS_ACC_NO, ln_available_balance, ln_count, ln_count);                 
--            end if;
            log_at('azatbegin9',ln_available_balance,r_payment.SUBS_ACC_NO); 
            if (ln_available_balance < ln_new_amount + ln_charge_amount and 
                ln_available_balance > ln_charge_amount and lb_is_partial_payment) then
                ln_new_amount := ln_available_balance - ln_charge_amount;
            end if;
            --EOM CQ4480 AlmasN 13032015 get commission

            --09042015 AlmasN CQ4680 if value date is today, then use overdraft otherwise only cash balance          
            if (ln_available_balance <= ln_charge_amount) then
                ls_return_code := '998';
            else
                ls_return_code :=
                   PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER (
                      TO_CHAR (r_payment.SUBS_ACC_NO),
                      COALESCE (r_payment.CUST_EXT_ACC_NO, ls_ext_acc_no),
                      TO_CHAR (ln_new_amount,'999999999999999.9999'),
                      'DCS/Оплата за товары/'||r_payment.SUBS_NAME||'/'||r_payment.INVOICE_NO||'/'||ln_initial_sum,                     --ps_description
                      r_payment.PAYMENT_CURR,
                      '',                        --ps_isdekont
                      '',                        --ps_paymentcode
                      ' ',                       --chyngyzo cq1264 add payment order number parameter
                      lc_ref);                   --pc_ref OUT cursorreferencetype
            end if;
                 
         END IF;
        
         IF (ls_return_code = '000') THEN
            --CQ4480 AlmasN 13032015 make partial payment log    
                   
            if (ln_new_amount <> (ln_initial_sum - ln_partial_paid_amount)) then
            log_at('azatbegin2',ln_new_amount,ln_initial_sum,ln_partial_paid_amount); 
                INSERT INTO CBS_DCS_PLANNED_PAYMENTS (ID, INVOICE_NO, CUST_NO, ACC_NO, CUST_EXT_ACC_NO,
                                                      SUBS_CUST_NO, SUBS_NAME, SUBS_EXT_ACC_NO, SUBS_ACC_NO, PAYMENT_SUM,
                                                      PAYMENT_CURR, VALUE_DATE, FILE_DATE, SHIPMENT_DATE, STATUS,
                                                      CREATE_DATE, COMMENTS, PAYMENT_DATE, REMAIN_SUM )
                VALUES (dcs_payments_seq.NEXTVAL, r_payment.INVOICE_NO, r_payment.CUST_NO, r_payment.ACC_NO, r_payment.CUST_EXT_ACC_NO,
                        r_payment.SUBS_CUST_NO, r_payment.SUBS_NAME, r_payment.SUBS_EXT_ACC_NO, r_payment.SUBS_ACC_NO, ln_new_amount,
                        r_payment.PAYMENT_CURR, r_payment.VALUE_DATE, r_payment.FILE_DATE, r_payment.SHIPMENT_DATE, PSTATUS_PARTIAL,
                        SYSDATE, PSTATUS_PARTIAL, pkg_muhasebe.banka_tarihi_bul, remain_sum-ln_new_amount);

                INSERT INTO CBS_DCS_LOG (ID, invoice_id, data_row, result, CREATE_DATE)
                VALUES (dcs_log_seq.NEXTVAL, dcs_payments_seq.CURRVAL, '100 ' || r_payment.INVOICE_NO || ' ' || TO_CHAR (r_payment.CUST_NO) || ' ' || 
                                                                       TO_CHAR (r_payment.ACC_NO) || ' ' || TO_CHAR (ln_new_amount) || ' ' || r_payment.PAYMENT_CURR || ' ' || 
                                                                       TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'), 
                        PSTATUS_PARTIAL, SYSDATE);
                        
                --AzatD                
                 ----- insert into helper table
                 insert into cbs_invoice_history (payment_sum_hist,initial_sum_hist,remain_sum_hist,created_at,status_hist,invoice_id,invoice_no_hist) 
                    values (ln_new_amount,ln_initial_sum,remain_sum-ln_new_amount, SYSDATE,PSTATUS_PARTIAL,dcs_payments_seq.CURRVAL,r_payment.INVOICE_NO);                                           
                --AzatD

                -- CQ4480 Almas Notify customer about performed payment            
                select dcs_payments_seq.CURRVAL into ln_count from dual;

                PKG_DCS.NotifyPerformedStatus(ln_count);
                
             
                
            else
            log_at('azatbegin3',ln_new_amount,r_payment.PAYMENT_SUM,ln_partial_paid_amount); 
                UPDATE CBS_DCS_PLANNED_PAYMENTS
                   SET STATUS = PSTATUS_PROCESSED,
                       COMMENTS = PSTATUS_PROCESSED,
                       PAYMENT_DATE = pkg_muhasebe.banka_tarihi_bul,
                       PAYMENT_SUM = ln_new_amount,
                       REMAIN_SUM = 0
                 WHERE status = PSTATUS_ACCEPTED  and invoice_no = r_payment.invoice_no;
                 

                    --AzatD
                    select id into invoice_id   from CBS_DCS_PLANNED_PAYMENTS where status = PSTATUS_PROCESSED  and invoice_no = r_payment.invoice_no;
                    
                    insert into cbs_invoice_history (payment_sum_hist,INITIAL_SUM_hist,remain_sum_hist,created_at,status_hist,invoice_id,invoice_no_hist) 
                    values (ln_new_amount,ln_initial_sum,0,SYSDATE,PSTATUS_PROCESSED,invoice_id,r_payment.INVOICE_NO);
                    --AzatD
                        
                        

                    INSERT INTO CBS_DCS_LOG (ID, invoice_id, data_row, result, CREATE_DATE)
                VALUES (dcs_log_seq.NEXTVAL, r_payment.ID, '100 ' || r_payment.INVOICE_NO || ' ' || TO_CHAR (r_payment.CUST_NO) || ' ' || 
                                                                       TO_CHAR (r_payment.ACC_NO) || ' ' || TO_CHAR (ln_new_amount) || ' ' || r_payment.PAYMENT_CURR || ' ' || 
                                                                       TO_CHAR (r_payment.VALUE_DATE, 'dd.MM.yyyy'), 
                        PSTATUS_PARTIAL, SYSDATE);

                -- CQ4480 Almas Notify customer about performed payment            
                PKG_DCS.NotifyPerformedStatus(r_payment.ID);
            end if;

            ln_processed := ln_processed + 1;

            ls_log := 'Payment Done';

         ELSE
            UPDATE CBS_DCS_PLANNED_PAYMENTS
               SET STATUS = PSTATUS_FAILED,
                   COMMENTS =
                      'FAILED ' || ls_return_code
                      || DECODE (ls_return_code,
                                 '502', ' - ' || PSTATUS_NOT_ENOUGH_BALANCE,
                                 '')
             WHERE ID = r_payment.ID
             AND   VALUE_DATE <= trunc(sysdate - 45);

            ln_failed := ln_failed + 1;

            ls_message := PSTATUS_FAILED;                             --Failed

            ls_log := 'Payment Failed ' || ls_return_code;
         END IF;

--         IF (r_payment.CUST_EXT_ACC_NO IS NOT NULL)
--            OR (ls_ext_acc_no IS NOT NULL)
--         THEN
--            INSERT INTO CBS_DCS_LOG (ID,
--                                     invoice_id,
--                                     data_row,
--                                     result,
--                                     CREATE_DATE)
--                 VALUES (
--                           dcs_log_seq.NEXTVAL,
--                           r_payment.ID,
--                              'Payment '
--                           || TO_CHAR (r_payment.ACC_NO)
--                           || ' '
--                           || TO_CHAR (r_payment.SUBS_ACC_NO)
--                           || ' '
--                           || TO_CHAR (r_payment.PAYMENT_SUM)
--                           || ' '
--                           || r_payment.PAYMENT_CURR,
--                           ls_log,
--                           SYSDATE);
--         END IF;
         
         -- commit added information
         commit;
      END LOOP;

      CLOSE today_payments;

      IF (ln_i = 0) AND (ls_message = '000')
      THEN
         ls_message := PSTATUS_NO_PAYMENTS;            --No payments for today
         RETURN ls_message;
      END IF;

      ls_message :=
            'Total number of payments: '
         || ln_total_payments
         || '. Payments processed successfully: '
         || ln_processed
         || '. Payments failed to process: '
         || ln_failed
         || '.';

      RETURN ls_message;
   EXCEPTION
      WHEN OTHERS THEN
         LOG_AT('DCS', 'PerformPayments', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
      
         IF today_payments%ISOPEN
         THEN
            CLOSE today_payments;
         END IF;

         IF lc_ref%ISOPEN
         THEN
            CLOSE lc_ref;
         END IF;

         ls_message := 'ERROR ' || SUBSTR (SQLERRM, 1, 300);

         RETURN ls_message;
   END;
    
   PROCEDURE PerformPaymentsFromJob IS
        ls_result varchar2(350) := '';
   BEGIN
        ls_result := PKG_DCS.PERFORMPAYMENTSNEW(trunc(SYSDATE)); --CQ1245 almasn 20141014 Direct Crediting System scheduled job wrong date format
   END;
   

   PROCEDURE PaymentInfo (pn_customer_no              NUMBER,
                          pd_value_date_from          DATE,       --value date
                          pd_value_date_till          DATE,
                          pd_file_date_from           DATE,    --document date
                          pd_file_date_till           DATE,
                          pd_shipment_date_from       DATE,    --prepared date
                          pd_shipment_date_till       DATE,
                          pn_debited_acc_no           varchar2,
                          pn_amount_from              NUMBER,
                          pn_amount_till              NUMBER,
                          ps_currency                 VARCHAR2,
                          ps_invoiceNo                VARCHAR2,
                          ps_status                   VARCHAR2,
                          pd_actual_payment_date_from DATE,
                          pd_actual_payment_date_till DATE,
                          pc_ref                  OUT cursorreferencetype)
   IS
      ls_condition   VARCHAR2 (1000) := '';
   BEGIN
   
      IF (pd_value_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE >= TO_DATE('''
            || TO_CHAR (pd_value_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_value_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE <= TO_DATE('''
            || TO_CHAR (pd_value_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;


      IF (pd_file_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE >= TO_DATE('''
            || TO_CHAR (pd_file_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_file_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE <= TO_DATE('''
            || TO_CHAR (pd_file_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE >= TO_DATE('''
            || TO_CHAR (pd_shipment_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE <= TO_DATE('''
            || TO_CHAR (pd_shipment_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_actual_payment_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND PAYMENT_DATE >= TO_DATE('''
            || TO_CHAR (pd_actual_payment_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_actual_payment_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND PAYMENT_DATE <= TO_DATE('''
            || TO_CHAR (pd_actual_payment_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pn_debited_acc_no IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SUBS_EXT_ACC_NO IS NOT NULL AND SUBS_EXT_ACC_NO = '''
            || pn_debited_acc_no || '''';
      END IF;


      IF (pn_amount_from IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND PAYMENT_SUM >= ' || TO_CHAR(pn_amount_from, '999999999.9999');
      END IF;

      IF (pn_amount_till IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND PAYMENT_SUM <= ' || TO_CHAR(pn_amount_till, '999999999.9999');
      END IF;

      IF (ps_currency IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND PAYMENT_CURR = ''' || ps_currency || '''';
      END IF;

      IF (ps_invoiceNo IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND INVOICE_NO = ''' || ps_invoiceNo || '''';
      END IF;

      IF (ps_status IS NOT NULL)
      THEN
            if (ps_status='FAILED') then 
                ls_condition := ls_condition || ' AND STATUS not in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PROCESSED||''','''||PSTATUS_PARTIAL||''')'; 
            elsif (ps_status='FINISHED') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_PROCESSED||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PROCESSED || ''')';
            elsif (ps_status='NOT_PAID') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_ACCEPTED||''''; 
                ls_condition := ls_condition || ' AND invoice_no not in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PARTIAL || ''')'; 
            elsif (ps_status='PARTIAL') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_PARTIAL||''''; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED || ''', '''|| PSTATUS_PROCESSED || '''))';
            elsif (ps_status='LEFT_AND_PARTIAL_PAYMENTS') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PARTIAL||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED || ''')'; 
            else 
                ls_condition := ls_condition || ' AND STATUS = ''' || ps_status || '''';
            end if;
      END IF;

      OPEN pc_ref FOR
            'SELECT dcs_payment.id,
                dcs_payment.invoice_no,
                dcs_payment.CUST_NO,
                dcs_payment.SUBS_NAME,
                dcs_payment.SUBS_ext_acc_no,
                decode(dcs_payment.status, 
                    ''PARTIAL'', nvl((select payment_sum from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status=''ACCEPTED''), 
                                (select nvl(sum(payment_sum), 0) from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status in (''PARTIAL'',''PROCESSED''))), 
                    dcs_payment.payment_sum
                    ) payment_sum,
                dcs_payment.payment_curr,
                dcs_payment.VALUE_date,
                dcs_payment.status,
                dcs_payment.cancel_date,
                dcs_payment.comments,
                dcs_payment.file_date,
                dcs_payment.shipment_date,
                dcs_payment.payment_date,
                Pkg_Hesap.Kullanilabilir_Bakiye_Al(dcs_payment.SUBS_ACC_NO),
                (select sum(lim.FC_LIMIT) from cbs_musteri_urun_limit lim where musteri_no = dcs_payment.SUBS_CUST_NO and fc_doviz_kodu = dcs_payment.payment_curr and urun_grub_no in (18,19,20)) as limit,
                dcs_payment.payment_sum actual_payment_sum
           FROM CBS_DCS_PLANNED_PAYMENTS dcs_payment
          WHERE CUST_NO =  '
         || TO_CHAR (pn_customer_no)
         || ls_condition
         || ' ORDER BY invoice_no desc, dcs_payment.payment_date desc, dcs_payment.id desc';
log_at('ls_cond',ls_condition);

   END;

   PROCEDURE CustomersBalanceInfo (pn_client_no       NUMBER,
                                   pc_ref OUT cursorreferencetype) IS
   BEGIN
   
   
   OPEN pc_ref FOR
             SELECT distinct hsp.musteri_no AS customer_no,
                  hsp.external_hesap_no AS ext_acc_no,
                  bakiye.bakiye AS balance,
                  hsp.doviz_kodu AS currency,
                  COALESCE (overdrft.fc_limit, 0) AS overdraft_limit,
                  COALESCE (overdrft.fc_limit, 0) + bakiye.bakiye  
                  AS remaining_limit,
                  COALESCE (SUM (payments.payment_sum), 0) AS invoices_sum,
                  PKG_HESAP.KULLANILABILIR_BAKIYE_AL(hsp.hesap_no) available_balance,
                  PKG_MUSTERI.SF_MUSTERI_ADI(hsp.musteri_no) customer_name,
                  to_char(sysdate, 'ddmmyyyyhh24miss') datetime
              FROM CBS_DCS_SUBSCRIBER_ACCOUNTS subscriber
              left join cbs_hesap hsp on (SUBSCRIBER.SUBS_ACC_NO =  hsp.hesap_no)
              left join cbs_vw_hesap_izleme  bakiye on (HSP.HESAP_NO = BAKIYE.HESAP_NO)
              left join cbs_musteri_urun_limit overdrft on (overdrft.musteri_no = HSP.MUSTERI_NO and OVERDRFT.FC_DOVIZ_KODU = hsp.doviz_kodu)
              LEFT JOIN CBS_DCS_PLANNED_PAYMENTS payments
                     ON PAYMENTS.SUBS_ACC_NO = HSP.HESAP_NO
                        AND payments.status ='ACCEPTED'
             where
                    SUBSCRIBER.DCS_CUSTOMER_ID=1
                    AND SUBSCRIBER.STATUS = 'ACTIVE'
         --new added conditions AzatD, Miraida,AsylbekP
                 -- and (COALESCE(overdrft.fc_limit, 0) + bakiye.bakiye)>=0 --new added
                  and OVERDRFT.URUN_GRUB_NO in ('19','20') 
                  and OVERDRFT.FC_LIMIT!=0
          -------------------------------
                   GROUP BY hsp.musteri_no,
                  hsp.external_hesap_no,
                  bakiye.bakiye,
                  hsp.doviz_kodu,
                  overdrft.fc_limit,
                  hsp.hesap_no
              ORDER BY hsp.musteri_no desc;

   END;


   FUNCTION GetSubscriberList (pn_customer_no       NUMBER,
                                                
       pc_ref           OUT cursorreferencetype) RETURN VARCHAR2
   IS
    ls_return_code VARCHAR2(3) := '000';
    ls_count NUMBER := 0;
   BEGIN

      SELECT COUNT(*) INTO ls_count FROM CBS_DCS_CUSTOMER_ACCOUNTS CA WHERE CA.CUST_NO = pn_customer_no AND CA.STATUS = 1;
      
      if (ls_count = 0) then
        return '072';
      end if;
        
      OPEN pc_ref FOR 
      SELECT SA.ID,
                  SA.SUBS_CUST_NO as cust_no, 
                  SA.SUBS_ACC_NO as acc_no ,
                  PKG_HESAP.HESAPTANDOVIZKODUAL(SA.SUBS_ACC_NO) AS CURRENCY, 
                  PKG_HESAP.EXTERNAL_HESAPNO_AL(SA.SUBS_ACC_NO) AS EXT_ACC_NO, 
                  PKG_MUSTERI.SF_MUSTERI_ADI(SA.SUBS_CUST_NO) as name, 
                  PKG_HESAP.HESAPSUBEAL(SA.SUBS_ACC_NO) as branch
        FROM CBS_DCS_SUBSCRIBER_ACCOUNTS SA
        LEFT JOIN CBS_DCS_CUSTOMER_ACCOUNTS CA ON (SA.DCS_CUSTOMER_ID = CA.ID)
        WHERE CA.CUST_NO = pn_customer_no AND CA.STATUS = 1 AND SA.STATUS = 'ACTIVE';
        
        
        return ls_return_code;
        
        exception
        when others
        then
        return '999';
        
   END;
   
   
    FUNCTION IsAccountUsedInDCS(pn_account_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2
     IS
       ln_count NUMBER := 0;
     BEGIN
        
         SELECT COUNT(*) INTO ln_count 
         FROM CBS_DCS_PLANNED_PAYMENTS P WHERE (P.ACC_NO = pn_account_no OR P.SUBS_ACC_NO = pn_account_no) AND P.STATUS = 'ACCEPTED';
         
         if ln_count > 0 then
            RETURN 'TRUE';
         end if;
        
          RETURN 'FALSE';
     END;
     
     PROCEDURE UnsubscribeCustomer(pn_account_no CBS_HESAP.HESAP_NO%TYPE)
      IS
      ln_count NUMBER;
      BEGIN

        SELECT COUNT(*) INTO ln_count from CBS_DCS_SUBSCRIBER_ACCOUNTS sa where SA.SUBS_ACC_NO = pn_account_no;

        IF ln_count <> 0 then
            
            update CBS_DCS_SUBSCRIBER_ACCOUNTS sa set SA.STATUS = 'PASSIVE' WHERE SA.SUBS_ACC_NO = pn_account_no;
    
          
        end if;

      EXCEPTION
      WHEN OTHERS THEN
        LOG_AT('DCS', 'UnsubscribeCustomer', substr(SQLERRM, 1, 1500));
      END;

    PROCEDURE NotifyPerformedStatus(ps_invoice_id CBS_DCS_PLANNED_PAYMENTS.ID%TYPE) IS

        CURSOR cursor_dcs_payment is
            select *
            from CBS_DCS_PLANNED_PAYMENTS
            where id = ps_invoice_id;

        CURSOR cursor_dcs_payment_history is
            select *
            from CBS_DCS_PLANNED_PAYMENTS
            where invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where id = ps_invoice_id)
            and payment_date is not null
            order by payment_date desc;

        lc_message_body CBS_EMAIL_MESSAGES.BODY_CONTENT%TYPE;
        ls_message_subject CBS_EMAIL_MESSAGES.SUBJECT%TYPE;

        ls_notify_email_address CBS_EMAIL_MESSAGES.RECIPIENT%TYPE;
        ls_subscriber_email_address CBS_EMAIL_MESSAGES.RECIPIENT%TYPE;
        ls_officer_email_address CBS_EMAIL_MESSAGES.RECIPIENT%TYPE;
        ln_amount number;
        ls_json CLOB;
        ls_ret VARCHAR2(3);
        recip corpint2.pkg_notification.RecipientList;
        
        pc_ref cursorreferencetype;
    BEGIN

        pkg_parametre.deger('DSC_PERFORM_NOTIFY_MSG_SUBJECT', ls_message_subject);

        FOR r_dcs_payment IN cursor_dcs_payment LOOP

            ls_json := '{';
            ls_json := ls_json || '"#DIST_NAME#":"'|| replace(r_dcs_payment.SUBS_NAME, '"', '') ||'",';           
            ls_json := ls_json || '"#INVOICE_NO#":"'|| r_dcs_payment.INVOICE_NO ||'",';
            ls_json := ls_json || '"#PAYMENT_DATE#":"'|| trim(to_char(r_dcs_payment.VALUE_DATE,'dd/mm/yyyy')) ||'",';  
            
            -- get invoice amount
            select max(payment_sum) into ln_amount
            from CBS_DCS_PLANNED_PAYMENTS
            where invoice_no = r_dcs_payment.INVOICE_NO
            and status in (PSTATUS_ACCEPTED, PSTATUS_PROCESSED);
            
            ls_json := ls_json || '"#INVOICE_AMOUNT#":"'|| trim(to_char(ln_amount,'999,999,999,999.99')) || ' ' || r_dcs_payment.PAYMENT_CURR ||'",';           
            ls_json := ls_json || '"#ACTUAL_PAYMENT_DATE#":"'|| trim(to_char(r_dcs_payment.PAYMENT_DATE,'dd/mm/yyyy')) ||'",';
            ls_json := ls_json || '"#ACTUAL_PAID_AMOUNT#":"'|| trim(to_char(r_dcs_payment.PAYMENT_SUM,'999,999,999,999.99')) || ' ' || r_dcs_payment.PAYMENT_CURR ||'",';

            select ln_amount - sum(payment_sum) into ln_amount
            from CBS_DCS_PLANNED_PAYMENTS
            where invoice_no = r_dcs_payment.INVOICE_NO
            and status = PSTATUS_PARTIAL;
            
            ls_json := ls_json || '"#RESIDUAL_AMOUNT#":"'|| trim(to_char(ln_amount,'999,999,999,999.99')) || ' ' || r_dcs_payment.PAYMENT_CURR ||'",';           
            ls_json := ls_json || '"#STATUS#":"'|| r_dcs_payment.STATUS ||'",';

            lc_message_body := '';
            FOR r_dcs_payment_hist IN cursor_dcs_payment_history LOOP
                lc_message_body := lc_message_body || '<tr>';
                lc_message_body := lc_message_body || '<td>' || trim(to_char(r_dcs_payment_hist.PAYMENT_DATE, 'dd/mm/yyyy')) || '</td>';
                lc_message_body := lc_message_body || '<td>' || trim(to_char(r_dcs_payment_hist.PAYMENT_SUM,'999,999,999,999.99')) || ' ' || r_dcs_payment_hist.PAYMENT_CURR || '</td>';
                lc_message_body := lc_message_body || '</tr>';
            end loop;
            
            ls_json := ls_json || '"#BODY#":"'|| lc_message_body ||'"';
            ls_json := ls_json ||  '}';

            -- get customer email addresses
            ls_notify_email_address := GetDelimetedEmails(r_dcs_payment.CUST_NO, ',');

            -- get subscriber customer email addresses
            ls_subscriber_email_address := GetDelimetedEmails(r_dcs_payment.SUBS_CUST_NO, ',');

            -- get related marketing officer email addresses
             --/*replaced by GulkaiyrK DEN-17 select wm_concat(email) into ls_officer_email_address
             select LISTAGG(aa.email, ',') WITHIN GROUP (ORDER BY aa.email)  into ls_officer_email_address         
            from cbs_kullanici aa, cbs_musteri bb
            where bb.musteri_no=r_dcs_payment.CUST_NO
            and (AA.PERSONEL_NUMARA = BB.PAZARLAMA_SORUMLUSU_SICIL_NO_1
              or AA.PERSONEL_NUMARA = BB.PAZARLAMA_SORUMLUSU_SICIL_NO_2)
            and email is not null;   
            
            IF ls_officer_email_address = '' THEN
                ls_officer_email_address := 'test@email.com';
            END IF;
            IF ls_subscriber_email_address = '' THEN
                ls_subscriber_email_address := 'test@email.com';
            END IF;
            IF ls_notify_email_address = '' THEN
                ls_notify_email_address := 'test@email.com';
            END IF;
            
            ls_ret := CORPINT2.PKG_NOTIFICATION.sendHtmlEmail(ls_notify_email_address || ',' || ls_subscriber_email_address || ',' || ls_officer_email_address, ls_message_subject, to_char(ls_json), 'dcs_email_template', pc_ref);

        END LOOP;    

    EXCEPTION
        WHEN OTHERS THEN
            LOG_AT('DCS', 'NotifyPerformedStatus', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
    END;

    FUNCTION GetDelimetedEmails(pn_customer_no NUMBER, ps_delimeter VARCHAR2 DEFAULT ',') RETURN VARCHAR2 is

        cursor email_cursor(p_customerno number) is
            select email
            from cbs_musteri_adres
            where musteri_no = p_customerno;

        ls_email cbs_musteri_adres.email%type;
        ls_result varchar2(1000);
    BEGIN

        open email_cursor(pn_customer_no);
        fetch email_cursor into ls_email;
        WHILE  email_cursor%FOUND LOOP
            ls_result := ls_result || ls_email || ps_delimeter;
        fetch email_cursor into ls_email;
        END LOOP;
        close email_cursor;

        if (length(ls_result) > 0) then
            ls_result := substr(ls_result, 1, length(ls_result)-1);
        end if;
        
        return ls_result;
    Exception
        when others then
            LOG_AT('DCS', 'GetDelimetedEmails', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
            return '';
    END;
    
 PROCEDURE PaymentInfo2 (pn_customer_no              NUMBER,
                          pd_value_date_from          DATE,    --value date
                          pd_value_date_till          DATE,
                          pd_file_date_from           DATE,    --document date
                          pd_file_date_till           DATE,
                          pd_shipment_date_from       DATE,    --prepared date
                          pd_shipment_date_till       DATE,
                          pn_debited_acc_no           varchar2,
                          pn_amount_from              NUMBER,
                          pn_amount_till              NUMBER,
                          ps_currency                 VARCHAR2,
                          ps_invoiceNo                VARCHAR2,
                          ps_status                   VARCHAR2,
                          pd_actual_payment_time_from varchar2,
                          pd_actual_payment_time_till varchar2,
                          pc_ref                  OUT cursorreferencetype)
   IS
      ls_condition   VARCHAR2 (1000) := '';
      pd_actual_payment_date_from DATE;
      pd_actual_payment_date_till DATE;
   BEGIN
   
--   select CAST(pd_actual_payment_timestamp_from AS DATE) into pd_actual_payment_date_from from dual;  
   
--   pd_actual_payment_date_from := ;
   
--   select to_date(pd_actual_payment_time_from,'yyyyMMdd HH:MI') from dual;
--   pd_actual_payment_date_till := to_date(pd_actual_payment_time_till,'yyyyMMdd HH:MI');
          
    
   
      IF (pd_value_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE >= TO_DATE('''
            || TO_CHAR (pd_value_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_value_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE <= TO_DATE('''
            || TO_CHAR (pd_value_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;


      IF (pd_file_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE >= TO_DATE('''
            || TO_CHAR (pd_file_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_file_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE <= TO_DATE('''
            || TO_CHAR (pd_file_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE >= TO_DATE('''
            || TO_CHAR (pd_shipment_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE <= TO_DATE('''
            || TO_CHAR (pd_shipment_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_actual_payment_time_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || ' AND ih.status_hist in (''' || PSTATUS_PROCESSED|| ''', ''' || PSTATUS_PARTIAL|| ''') AND ih.created_at >= TO_DATE('''
            ||pd_actual_payment_time_from            
            || ''', ''yyyyMMdd HH24:MI'')';
      END IF;

      IF (pd_actual_payment_time_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || ' AND ih.status_hist in (''' || PSTATUS_PROCESSED|| ''', ''' || PSTATUS_PARTIAL|| ''') AND ih.created_at <= TO_DATE('''
            || pd_actual_payment_time_till
            || ''', ''yyyyMMdd HH24:MI'')';
      END IF;

      IF (pn_debited_acc_no IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SUBS_EXT_ACC_NO IS NOT NULL AND SUBS_EXT_ACC_NO = '''
            || pn_debited_acc_no || '''';
      END IF;


      IF (pn_amount_from IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND ih.PAYMENT_SUM_HIST >= ' || TO_CHAR(pn_amount_from, '999999999.9999');
      END IF;

      IF (pn_amount_till IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND ih.PAYMENT_SUM_HIST <= ' || TO_CHAR(pn_amount_till, '999999999.9999');
      END IF;

      IF (ps_currency IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND PAYMENT_CURR = ''' || ps_currency || '''';
      END IF;

      IF (ps_invoiceNo IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND INVOICE_NO = ''' || ps_invoiceNo || '''';
      END IF;

      IF (ps_status IS NOT NULL)
      THEN
            if (ps_status='FAILED') then 
                ls_condition := ls_condition || ' AND STATUS not in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PROCESSED||''','''||PSTATUS_PARTIAL||''')'; 
            elsif (ps_status='FINISHED') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_PROCESSED||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PROCESSED || ''')';
            elsif (ps_status='NOT_PAID') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_ACCEPTED||''''; 
                ls_condition := ls_condition || ' AND invoice_no not in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PARTIAL || ''')'; 
            elsif (ps_status='PARTIAL') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_PARTIAL||''''; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED || ''', '''|| PSTATUS_PROCESSED || '''))';
            elsif (ps_status='LEFT_AND_PARTIAL_PAYMENTS') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PARTIAL||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED || ''')'; 
            else 
                ls_condition := ls_condition || ' AND STATUS = ''' || ps_status || '''';
            end if;
      END IF;
      
      log_at('debugAzat',
      pn_customer_no ||',' ||pd_value_date_from ||',' || pd_value_date_till||',' || 
    pd_file_date_from ||',' || pd_file_date_till || ',' || pd_shipment_date_from
    || ',' || pd_shipment_date_till
    || ',' || pn_debited_acc_no
    || ',' || pn_amount_from
    || ',' || pn_amount_till
    || ',' || ps_currency
    || ',' || ps_invoiceNo
    || ',' ||ps_status
    || ',' ||pd_actual_payment_time_from
    || ',' ||pd_actual_payment_time_till,        
     TO_CHAR (pn_customer_no)|| ','||ls_condition                
      );
      
      

      OPEN pc_ref FOR
            'SELECT dcs_payment.id,
                dcs_payment.invoice_no,
                dcs_payment.CUST_NO,
                dcs_payment.SUBS_NAME,
                dcs_payment.SUBS_ext_acc_no,
                decode(dcs_payment.status, 
                    ''PARTIAL'', nvl((select payment_sum from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status=''ACCEPTED''), 
                                (select nvl(sum(payment_sum), 0) from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status in (''PARTIAL'',''PROCESSED''))), 
                    dcs_payment.payment_sum
                    ) payment_sum2,
                dcs_payment.payment_curr,
                dcs_payment.VALUE_date,
                ih.status_hist status,
                dcs_payment.cancel_date,
                dcs_payment.comments,
                dcs_payment.file_date,
                dcs_payment.shipment_date,
                dcs_payment.payment_date,
                Pkg_Hesap.Kullanilabilir_Bakiye_Al(dcs_payment.SUBS_ACC_NO),
                (select sum(lim.FC_LIMIT) from cbs_musteri_urun_limit lim where musteri_no = dcs_payment.SUBS_CUST_NO and fc_doviz_kodu = dcs_payment.payment_curr and urun_grub_no in (18,19,20)) as limit,
                decode(dcs_payment.status
                    ,''PROCESSED'', (select nvl(sum(payment_sum),0)+dcs_payment.payment_sum from CBS_DCS_PLANNED_PAYMENTS where STATUS = ''PARTIAL'' and invoice_no=dcs_payment.invoice_no)
                    ,''PARTIAL'', dcs_payment.payment_sum, (select nvl(sum(payment_sum),0) from CBS_DCS_PLANNED_PAYMENTS where STATUS = ''PARTIAL'' and invoice_no=dcs_payment.invoice_no)
                ) actual_payment_sum,
                ih.initial_sum_hist payment_sum,
                ih.remain_sum_hist remain_sum,
                ih.payment_sum_hist paid_sum,                
                CASE  
                  WHEN (''PARTIAL'' = ih.status_hist or ''ACCEPTED'' = ih.status_hist) and 
                  ih.created_at = (select max(ih.created_at)from CBS_INVOICE_HISTORY ih join CBS_DCS_PLANNED_PAYMENTS pp on ih.invoice_id = pp.id where ih.invoice_no_hist = dcs_payment.invoice_no)
                  THEN 1 
                  ELSE 0
                END "active",
                ih.created_at created_at 
           FROM CBS_DCS_PLANNED_PAYMENTS dcs_payment join cbs_invoice_history ih on ih.invoice_id = dcs_payment.id
          WHERE dcs_payment.CUST_NO =  '
         || TO_CHAR (pn_customer_no)
         || ls_condition
         || ' AND dcs_payment.status in (''PARTIAL'',''ACCEPTED'',''PROCESSED'',''CANCELLED'')'
         || ' ORDER BY dcs_payment.invoice_no desc, ih.created_at asc';

exception
 When Others Then
            LOG_AT('DCS', 'PaymentInfo2', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));

   END;
    
    PROCEDURE PaymentInfoDistributor (pn_customer_no              NUMBER,
                          pd_value_date_from          DATE,    --value date
                          pd_value_date_till          DATE,
                          pd_file_date_from           DATE,    --document date
                          pd_file_date_till           DATE,
                          pd_shipment_date_from       DATE,    --prepared date
                          pd_shipment_date_till       DATE,
                          pn_debited_acc_no           varchar2,
                          pn_amount_from              NUMBER,
                          pn_amount_till              NUMBER,
                          ps_currency                 VARCHAR2,
                          ps_invoiceNo                VARCHAR2,
                          ps_status                   VARCHAR2,
                          pd_actual_payment_time_from varchar2,
                          pd_actual_payment_time_till varchar2,
                          pc_ref                  OUT cursorreferencetype)
   IS
      ls_condition   VARCHAR2 (1000) := '';
      ls_subscriber_external_account VARCHAR2 (16):= '';
      pd_actual_payment_date_from DATE;
      pd_actual_payment_date_till DATE;
   BEGIN
   
--   select CAST(pd_actual_payment_timestamp_from AS DATE) into pd_actual_payment_date_from from dual;  
   
--   pd_actual_payment_date_from := ;
   
--   select to_date(pd_actual_payment_time_from,'yyyyMMdd HH:MI') from dual;
--   pd_actual_payment_date_till := to_date(pd_actual_payment_time_till,'yyyyMMdd HH:MI');
   log_at('distributor',pn_customer_no);       
    --select EXTERNAL_HESAP_NO into ls_subscriber_external_account from cbs_hesap where musteri_no = pn_customer_no and doviz_kodu = 'KGS';
    
    select PKG_HESAP.EXTERNAL_HESAPNO_AL(SUBS_ACC_NO)  into ls_subscriber_external_account from CBS_DCS_SUBSCRIBER_ACCOUNTS where subs_cust_no = pn_customer_no and status = 'ACTIVE';
    
   log_at('distributor',ls_subscriber_external_account );
      IF (pd_value_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE >= TO_DATE('''
            || TO_CHAR (pd_value_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_value_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND VALUE_DATE <= TO_DATE('''
            || TO_CHAR (pd_value_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;


      IF (pd_file_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE >= TO_DATE('''
            || TO_CHAR (pd_file_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_file_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND FILE_DATE <= TO_DATE('''
            || TO_CHAR (pd_file_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE >= TO_DATE('''
            || TO_CHAR (pd_shipment_date_from, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_shipment_date_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SHIPMENT_DATE <= TO_DATE('''
            || TO_CHAR (pd_shipment_date_till, 'dd.mm.yyyy')
            || ''', ''dd.mm.yyyy'')';
      END IF;

      IF (pd_actual_payment_time_from IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || ' AND ih.status_hist in (''' || PSTATUS_PROCESSED|| ''', ''' || PSTATUS_PARTIAL|| ''') AND ih.created_at >= TO_DATE('''
            ||pd_actual_payment_time_from            
            || ''', ''yyyyMMdd HH24:MI'')';
      END IF;

      IF (pd_actual_payment_time_till IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || ' AND ih.status_hist in (''' || PSTATUS_PROCESSED|| ''', ''' || PSTATUS_PARTIAL|| ''') AND ih.created_at <= TO_DATE('''
            || pd_actual_payment_time_till
            || ''', ''yyyyMMdd HH24:MI'')';
      END IF;

      IF (pn_debited_acc_no IS NOT NULL)
      THEN
         ls_condition :=
               ls_condition
            || '  AND SUBS_EXT_ACC_NO IS NOT NULL AND SUBS_EXT_ACC_NO = '''
            || pn_debited_acc_no || '''';
      END IF;


      IF (pn_amount_from IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND PAYMENT_SUM >= ' || TO_CHAR(pn_amount_from, '999999999.9999');
      END IF;

       IF (pn_amount_from IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND ih.PAYMENT_SUM_HIST >= ' || TO_CHAR(pn_amount_from, '999999999.9999');
      END IF;

      IF (pn_amount_till IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND ih.PAYMENT_SUM_HIST <= ' || TO_CHAR(pn_amount_till, '999999999.9999');
      END IF;

      IF (ps_invoiceNo IS NOT NULL)
      THEN
         ls_condition :=
            ls_condition || '  AND INVOICE_NO = ''' || ps_invoiceNo || '''';
      END IF;

      IF (ps_status IS NOT NULL)
      THEN
            if (ps_status='FAILED') then 
                ls_condition := ls_condition || ' AND STATUS not in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PROCESSED||''','''||PSTATUS_PARTIAL||''')'; 
            elsif (ps_status='FINISHED') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_PROCESSED||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PROCESSED || ''')';
            elsif (ps_status='NOT_PAID') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_ACCEPTED||''''; 
                ls_condition := ls_condition || ' AND invoice_no not in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_PARTIAL || ''')'; 
            elsif (ps_status='PARTIAL') then 
                ls_condition := ls_condition || ' AND STATUS = '''||PSTATUS_PARTIAL||''''; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED  || ''')';
            elsif (ps_status='LEFT_AND_PARTIAL_PAYMENTS') then 
                ls_condition := ls_condition || ' AND STATUS in ('''||PSTATUS_ACCEPTED||''','''||PSTATUS_PARTIAL||''')'; 
                ls_condition := ls_condition || ' AND invoice_no in (select invoice_no from CBS_DCS_PLANNED_PAYMENTS where STATUS = '''|| PSTATUS_ACCEPTED || ''')'; 
            else 
                ls_condition := ls_condition || ' AND STATUS = ''' || ps_status || '''';
            end if;
      END IF;
      
      log_at('debugDistributor',
      pn_customer_no ||',' ||pd_value_date_from ||',' || pd_value_date_till||',' || 
    pd_file_date_from ||',' || pd_file_date_till || ',' || pd_shipment_date_from
    || ',' || pd_shipment_date_till
    || ',' || pn_debited_acc_no
    || ',' || pn_amount_from
    || ',' || pn_amount_till
    || ',' || ps_currency
    || ',' || ps_invoiceNo
    || ',' ||ps_status
    || ',' ||pd_actual_payment_time_from
    || ',' ||pd_actual_payment_time_till,        
     TO_CHAR (pn_customer_no)|| ',','ls_condition : '||ls_condition                
      );
      
      
      log_at('distributor select',  'FROM CBS_DCS_PLANNED_PAYMENTS dcs_payment join cbs_invoice_history ih on ih.invoice_id = dcs_payment.id
          WHERE dcs_payment.SUBS_ext_acc_no =  '               
         || ' AND ih.status_hist in (''PARTIAL'',''ACCEPTED'',''PROCESSED'',''CANCELLED'')'
         || ' ORDER BY dcs_payment.invoice_no desc, ih.created_at asc',TO_CHAR (ls_subscriber_external_account));
      

      OPEN pc_ref FOR
            'SELECT dcs_payment.id,
                dcs_payment.invoice_no,
                dcs_payment.CUST_NO,
                dcs_payment.SUBS_NAME,
                dcs_payment.SUBS_ext_acc_no,
                decode(dcs_payment.status, 
                    ''PARTIAL'', nvl((select payment_sum from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status=''ACCEPTED''), 
                                (select nvl(sum(payment_sum), 0) from CBS_DCS_PLANNED_PAYMENTS where invoice_no=dcs_payment.invoice_no and status in (''PARTIAL'',''PROCESSED''))), 
                    dcs_payment.payment_sum
                    ) payment_sum2,
                dcs_payment.payment_curr,
                dcs_payment.VALUE_date,
                ih.status_hist status,
                dcs_payment.cancel_date,
                dcs_payment.comments,
                dcs_payment.file_date,
                dcs_payment.shipment_date,
                dcs_payment.payment_date,
                Pkg_Hesap.Kullanilabilir_Bakiye_Al(dcs_payment.SUBS_ACC_NO),
                (select sum(lim.FC_LIMIT) from cbs_musteri_urun_limit lim where musteri_no = dcs_payment.SUBS_CUST_NO and fc_doviz_kodu = dcs_payment.payment_curr and urun_grub_no in (18,19,20)) as limit,
                decode(dcs_payment.status
                    ,''PROCESSED'', (select nvl(sum(payment_sum),0)+dcs_payment.payment_sum from CBS_DCS_PLANNED_PAYMENTS where STATUS = ''PARTIAL'' and invoice_no=dcs_payment.invoice_no)
                    ,''PARTIAL'', dcs_payment.payment_sum, (select nvl(sum(payment_sum),0) from CBS_DCS_PLANNED_PAYMENTS where STATUS = ''PARTIAL'' and invoice_no=dcs_payment.invoice_no)
                ) actual_payment_sum,
                ih.initial_sum_hist payment_sum,
                ih.remain_sum_hist remain_sum,
                ih.payment_sum_hist paid_sum,                
                CASE  
                  WHEN (''PARTIAL'' = ih.status_hist or ''ACCEPTED'' = ih.status_hist) and 
                  ih.created_at = (select max(ih.created_at)from CBS_INVOICE_HISTORY ih join CBS_DCS_PLANNED_PAYMENTS pp on ih.invoice_id = pp.id where ih.invoice_no_hist = dcs_payment.invoice_no)
                  THEN 1 
                  ELSE 0
                END "active",
                ih.created_at created_at 
           FROM CBS_DCS_PLANNED_PAYMENTS dcs_payment join cbs_invoice_history ih on ih.invoice_id = dcs_payment.id
          WHERE dcs_payment.SUBS_ext_acc_no =  '
         || TO_CHAR (ls_subscriber_external_account)   
         || ls_condition      
         || ' AND dcs_payment.status in (''PARTIAL'',''ACCEPTED'',''PROCESSED'')'
         || ' AND ih.status_hist in (''PARTIAL'',''ACCEPTED'',''PROCESSED'')'
         || ' ORDER BY dcs_payment.invoice_no desc, ih.created_at asc';

exception
 When Others Then
            LOG_AT('DCS', 'PaymentInfoDistributor', substr(SQLERRM, 1, 1500), substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));

   END;
END PKG_DCS;
/

