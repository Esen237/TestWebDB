create PACKAGE BODY     "PKG_INT" IS
FUNCTION GetCustomerInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;
    ln_count NUMBER := 0;
    no_data        EXCEPTION;
BEGIN

  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;

  SELECT COUNT(*)
  INTO ln_count
  FROM
(
  SELECT Pkg_Musteri.Sf_Musteri_Adi(pn_musteri_no),
         NVL(TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'),' '),
         NVL(m.DOGUM_YERI,' '),
         NVL(c.ACIKLAMA,' '),
         NVL(h.ACIKLAMA,' '),
         m.VERGI_NO,
         NVL(m.VERGI_DAIRESI_ADI,' '),
         NVL(m.UYRUK_KOD,' '),
         NVL(u.ACIKLAMA,' '),
         m.TC_KIMLIK_NO,
         NVL(a.ADRES,' '),
         NVL(a.SEMT,' '),
         NVL(a.IL_KOD,' '),
         NVL(i.IL_ADI,' '),
         a.POSTA_KOD,
         a.ULKE_KOD,
         NVL(b.ULKE_ADI,''),
         NVL(a.EMAIL,' '),
         a.TEL_ALAN_KOD,
         a.TEL_NO,
         a.GSM_ALAN_KOD,
         a.GSM_NO,
         NVL(k.ACIKLAMA,' '),
         m.MUSTERI_TIPI_KOD,
         NVL(TO_CHAR(m.DOGUM_TARIHI,'MMDD'),' '),
         NVL(TO_CHAR(SYSDATE,'MMDD'),' '),
         NVL(l.ACIKLAMA,' '),
         NVL(g.ACIKLAMA,' '),
         m.PERSONEL_SICIL_NO,
         m.MEDENI_HAL_KOD,
         m.CINSIYET_KOD,
         m.EXTRE_ADRES_KOD,
         m.PASAPORT_NO,
         m.VERILDIGI_YER,
         m.VERILDIGI_TARIH
   FROM CBS_MUSTERI m,
        CBS_MUSTERI_ADRES a ,
        CBS_IL_KODLARI i,
        CBS_UYRUK_KODLARI u,
        CBS_ULKE_KODLARI b,
        CBS_ADRES_KODLARI k,
        CBS_MESLEK_KODLARI l,
        CBS_EGITIM_KODLARI g,
        CBS_CINSIYET_KODLARI c,
        CBS_MEDENI_HAL_KODLARI h
   WHERE m.musteri_no = TO_NUMBER(pn_musteri_no) AND
         m.musteri_no = a.musteri_no AND
         m.EXTRE_ADRES_KOD = a.ADRES_KOD(+) AND
         m.UYRUK_KOD  = u.UYRUK_KODU(+) AND
         a.ULKE_KOD   = b.ULKE_KODU(+)   AND
         a.il_kod     = i.il_kodu(+)  AND
         k.ADRES_TIPI = a.ADRES_KOD AND
         h.MEDENI_HAL_KODU(+) = m.MEDENI_HAL_KOD AND
         c.CINSIYET_KODU(+) = m.CINSIYET_KOD AND
         l.MESLEK_KODU(+) = m.MESLEK_KOD AND
         g.EGITIM_KODU(+) = m.EGITIM_KOD);

  IF (ln_count= 0) THEN
    RAISE no_data;
  END IF;


  OPEN pc_ref FOR
  SELECT Pkg_Musteri.Sf_Musteri_Adi(pn_musteri_no),
         NVL(TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'),' '),
         NVL(m.DOGUM_YERI,' '),
         NVL(c.ACIKLAMA,' '),
         NVL(h.ACIKLAMA,' '),
         m.VERGI_NO,
         NVL(m.VERGI_DAIRESI_ADI,' '),
         NVL(m.UYRUK_KOD,' '),
         NVL(u.ACIKLAMA,' '),
         m.TC_KIMLIK_NO,
         NVL(a.ADRES,' '),
         NVL(a.SEMT,' '),
         NVL(a.IL_KOD,' '),
         NVL(i.IL_ADI,' '),
         a.POSTA_KOD,
         a.ULKE_KOD,
         NVL(b.ULKE_ADI,''),
         NVL(a.EMAIL,' '),
         a.TEL_ALAN_KOD,
         a.TEL_NO,
         a.GSM_ALAN_KOD,
         a.GSM_NO,
         NVL(k.ACIKLAMA,' '),
         m.MUSTERI_TIPI_KOD,
         NVL(TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'),' '),
         NVL(TO_CHAR(SYSDATE,'YYYYMMDD'),' '),
         NVL(l.ACIKLAMA,' '),
         NVL(g.ACIKLAMA,' '),
         m.PERSONEL_SICIL_NO,
         m.MEDENI_HAL_KOD,
         m.CINSIYET_KOD,
         m.EXTRE_ADRES_KOD,
         m.PASAPORT_NO,
         m.VERILDIGI_YER,
         NVL(TO_CHAR(m.VERILDIGI_TARIH,'YYYYMMDD'),' ')
   FROM CBS_MUSTERI m,
        CBS_MUSTERI_ADRES a ,
        CBS_IL_KODLARI i,
        CBS_UYRUK_KODLARI u,
        CBS_ULKE_KODLARI b,
        CBS_ADRES_KODLARI k,
        CBS_MESLEK_KODLARI l,
        CBS_EGITIM_KODLARI g,
        CBS_CINSIYET_KODLARI c,
        CBS_MEDENI_HAL_KODLARI h
   WHERE m.musteri_no = TO_NUMBER(pn_musteri_no) AND
         m.musteri_no = a.musteri_no AND
         m.EXTRE_ADRES_KOD = a.ADRES_KOD(+) AND
         m.UYRUK_KOD  = u.UYRUK_KODU(+) AND
         a.ULKE_KOD   = b.ULKE_KODU(+)   AND
         a.il_kod     = i.il_kodu(+)  AND
         k.ADRES_TIPI = a.ADRES_KOD AND
         h.MEDENI_HAL_KODU(+) = m.MEDENI_HAL_KOD AND
         c.CINSIYET_KODU(+) = m.CINSIYET_KOD AND
         l.MESLEK_KODU(+) = m.MESLEK_KOD AND
         g.EGITIM_KODU(+) = m.EGITIM_KOD;

    SELECT pn_musteri_no
    INTO ln_musterino
    FROM dual;
  RETURN ls_returncode;
EXCEPTION
WHEN NO_DATA_FOUND THEN
RETURN '025';
WHEN no_data THEN
RETURN '025';
END;
----------------------------------------------
FUNCTION UpdateCustomerInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;
BEGIN
  OPEN pc_ref FOR
  SELECT Pkg_Musteri.Sf_Musteri_Adi(pn_musteri_no),
         NVL(TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'),' '),
         NVL(m.DOGUM_YERI,' '),
         NVL(c.ACIKLAMA,' '),
         NVL(h.ACIKLAMA,' '),
         m.VERGI_NO,
         NVL(m.VERGI_DAIRESI_ADI,' '),
         NVL(m.UYRUK_KOD,' '),
         NVL(u.ACIKLAMA,' '),
         m.TC_KIMLIK_NO,
         NVL(a.ADRES,' '),
         NVL(a.SEMT,' '),
         NVL(a.IL_KOD,' '),
         NVL(i.IL_ADI,' '),
         a.POSTA_KOD,
         a.ULKE_KOD,
         NVL(b.ULKE_ADI,''),
         NVL(a.EMAIL,' '),
         a.TEL_ALAN_KOD,
         a.TEL_NO,
         a.GSM_ALAN_KOD,
         a.GSM_NO,
         NVL(k.ACIKLAMA,' '),
         m.MUSTERI_TIPI_KOD,
         NVL(TO_CHAR(m.DOGUM_TARIHI,'MMDD'),' '),
         NVL(TO_CHAR(SYSDATE,'MMDD'),' '),
         NVL(l.ACIKLAMA,' '),
         NVL(g.ACIKLAMA,' '),
         m.PERSONEL_SICIL_NO,
         m.MEDENI_HAL_KOD,
         m.CINSIYET_KOD,
         m.EXTRE_ADRES_KOD
   FROM CBS_MUSTERI m,
        CBS_MUSTERI_ADRES a ,
        CBS_IL_KODLARI i,
        CBS_UYRUK_KODLARI u,
        CBS_ULKE_KODLARI b,
        CBS_ADRES_KODLARI k,
        CBS_MESLEK_KODLARI l,
        CBS_EGITIM_KODLARI g,
        CBS_CINSIYET_KODLARI c,
        CBS_MEDENI_HAL_KODLARI h
   WHERE m.musteri_no = TO_NUMBER(pn_musteri_no) AND
         m.musteri_no = a.musteri_no AND
         m.EXTRE_ADRES_KOD = a.ADRES_KOD(+) AND
         m.UYRUK_KOD  = u.UYRUK_KODU(+) AND
         a.ULKE_KOD   = b.ULKE_KODU(+)   AND
         a.il_kod     = i.il_kodu(+)  AND
         k.ADRES_TIPI = a.ADRES_KOD AND
         h.MEDENI_HAL_KODU(+) = m.MEDENI_HAL_KOD AND
         c.CINSIYET_KODU(+) = m.CINSIYET_KOD AND
         l.MESLEK_KODU(+) = m.MESLEK_KOD AND
         g.EGITIM_KODU(+) = m.EGITIM_KOD;

    SELECT pn_musteri_no
    INTO ln_musterino
    FROM dual;
  RETURN ls_returncode;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN '025';
END;
----------------------------------------------
FUNCTION check_doviz(ps_cek_dvz VARCHAR2, ps_curr VARCHAR2) RETURN VARCHAR2 IS
BEGIN
  IF NVL(ps_curr,'333')='333' THEN
    RETURN 'E';
  ELSIF ps_curr=ps_cek_dvz THEN
    RETURN 'E';
  ELSIF ps_curr IN ('TRL','TRY') THEN
    IF ps_cek_dvz IN ('TRL','TRY') THEN
      RETURN 'E';
    END IF;
  END IF;
  RETURN 'H';
END;

FUNCTION GetCheckPNInfo(pn_custno             IN VARCHAR2,
                         ps_type                IN VARCHAR2,
                         ps_state              IN VARCHAR2,
                        pn_accountno           IN VARCHAR2,
                        pd_start_date         IN VARCHAR2,
                        pd_end_date         IN VARCHAR2,
                        ps_tahtem            IN VARCHAR2,
                        ps_sort                IN VARCHAR2,
                        ps_curr                IN VARCHAR2,
                        ps_tarih            IN VARCHAR2,
                        ps_aslimunzam       IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ls_durum VARCHAR2(2000);

    ld_startdate  DATE;
    ld_enddate      DATE;

    not_valid_date EXCEPTION;

    PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- yanl?? zaman girilmesi durumunda

BEGIN
  -- ps_type : CHECK    => check
  -- ps_type : PN        => promissory note

  --?ekler i?in

    -- burada e?er hatal? tarih girilmi? ise kullan?c?y? uyarmal?y?m o y?zden
    -- verecek ise burada hata versin diyorum

    ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
    ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');



  IF  ps_type = 'CHECK' THEN

      IF ps_Tarih ='VADE' OR ps_Tarih IS NULL THEN
           IF ps_state = 'ACIK' THEN
              OPEN pc_ref FOR
              SELECT TO_CHAR(a.keside_tarih ,'YYYYMMDD') vade,
                     (SELECT banka_adi FROM CBS_TAKAS_BANKA_KODLARI WHERE takas_banka_kodu = a.banka_kodu) banka_adi,
                     Pkg_Genel.sube_adi_al_takas (a.banka_kodu, a.sube_kodu) banka_sube_adi,
                     a.kesideci_adi borclu_adi,
                     a.cek_no,'ACIK',a.cek_tutari,a.tahsil_hesap_no,a.musteri_no,TO_CHAR(a.odeme_tarihi ,'YYYYMMDD') odeme_tarihi,
                     a.cek_doviz
              FROM   CBS_TAKAS_CEK a
              WHERE  a.bankamiz_cek    = 'H'
              AND    a.musteri_no      =  NVL(TO_NUMBER(pn_custno),a.musteri_no )
        --      AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.cek_durum IN ('ACIK','TAKAS','ELDEN','TAKASTA','TAHSIL')
              AND     a.cek_doviz       =  DECODE(ps_curr,NULL,Pkg_Genel.lc_al,ps_curr)
              AND     a.keside_tarih    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                          AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
              AND    a.tahsil_teminat  = DECODE(ps_tahtem,'TAMAMI',a.tahsil_teminat,NULL,a.tahsil_teminat,ps_tahtem)
              ORDER BY DECODE(ps_sort,'VADE',vade,'BANKA',banka_adi,'SUBE',banka_sube_adi,'BORCLU',borclu_adi,'CEK',a.cek_no,'TUTAR',a.cek_tutari,vade);
          ELSE
              OPEN pc_ref FOR
              SELECT TO_CHAR(a.keside_tarih ,'YYYYMMDD') vade,
                     (SELECT banka_adi FROM CBS_TAKAS_BANKA_KODLARI WHERE takas_banka_kodu = a.banka_kodu) banka_adi,
                     Pkg_Genel.sube_adi_al_takas (a.banka_kodu, a.sube_kodu) banka_sube_adi,
                     a.kesideci_adi borclu_adi,
                     a.cek_no, DECODE(a.cek_durum,'TAKAS','ACIK','ELDEN','ACIK','TAKASTA','ACIK','TAHSIL','ACIK',a.cek_durum),
                     a.cek_tutari,a.tahsil_hesap_no,a.musteri_no,TO_CHAR(a.odeme_tarihi ,'YYYYMMDD') odeme_tarihi,a.cek_doviz
              FROM   CBS_TAKAS_CEK a
              WHERE  a.bankamiz_cek    = 'H'
              AND    a.musteri_no      =  NVL(TO_NUMBER(pn_custno),a.musteri_no )
        --      AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.cek_durum       =  DECODE(ps_state,'TAMAMI',a.cek_durum,NULL,a.cek_durum,ps_state)
              AND     check_doviz(a.cek_doviz, ps_curr) = 'E'
              AND     a.keside_tarih    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                          AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
              AND    a.tahsil_teminat  = DECODE(ps_tahtem,'TAMAMI',a.tahsil_teminat,NULL,a.tahsil_teminat,ps_tahtem)
              ORDER BY DECODE(ps_sort,'VADE',vade,'BANKA',banka_adi,'SUBE',banka_sube_adi,'BORCLU',borclu_adi,'CEK',a.cek_no,'TUTAR',a.cek_tutari,vade);

          END IF;

      ELSIF ps_Tarih ='ODEME' THEN

            IF ps_state = 'ACIK' THEN
              OPEN pc_ref FOR
              SELECT TO_CHAR(a.keside_tarih ,'YYYYMMDD') vade,
                     (SELECT banka_adi FROM CBS_TAKAS_BANKA_KODLARI WHERE takas_banka_kodu = a.banka_kodu) banka_adi,
                     Pkg_Genel.sube_adi_al_takas (a.banka_kodu, a.sube_kodu) banka_sube_adi,
                     a.kesideci_adi borclu_adi,
                     a.cek_no,'ACIK',a.cek_tutari,a.tahsil_hesap_no,a.musteri_no,TO_CHAR(a.odeme_tarihi ,'YYYYMMDD') odeme_tarihi,a.cek_doviz
              FROM   CBS_TAKAS_CEK a
              WHERE  a.bankamiz_cek    = 'H'
              AND    a.musteri_no      =  NVL(TO_NUMBER(pn_custno),a.musteri_no )
        --      AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.cek_durum IN ('ACIK','TAKAS','ELDEN','TAKASTA','TAHSIL')
              AND     a.cek_doviz       =  DECODE(ps_curr,NULL,Pkg_Genel.lc_al,ps_curr)
              AND     a.odeme_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                          AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
              AND    a.tahsil_teminat  = DECODE(ps_tahtem,'TAMAMI',a.tahsil_teminat,NULL,a.tahsil_teminat,ps_tahtem)
              ORDER BY DECODE(ps_sort,'VADE',vade,'BANKA',banka_adi,'SUBE',banka_sube_adi,'BORCLU',borclu_adi,'CEK',a.cek_no,'TUTAR',a.cek_tutari,vade);

          ELSE
              OPEN pc_ref FOR
              SELECT TO_CHAR(a.keside_tarih ,'YYYYMMDD') vade,
                     (SELECT banka_adi FROM CBS_TAKAS_BANKA_KODLARI WHERE takas_banka_kodu = a.banka_kodu) banka_adi,
                     Pkg_Genel.sube_adi_al_takas (a.banka_kodu, a.sube_kodu) banka_sube_adi,
                     a.kesideci_adi borclu_adi,
                     a.cek_no,DECODE(a.cek_durum,'TAKAS','ACIK','ELDEN','ACIK','TAKASTA','ACIK','TAHSIL','ACIK',a.cek_durum),
                     a.cek_tutari,a.tahsil_hesap_no,a.musteri_no,TO_CHAR(a.odeme_tarihi ,'YYYYMMDD') odeme_tarihi,a.cek_doviz
              FROM   CBS_TAKAS_CEK a
              WHERE  a.bankamiz_cek    = 'H'
              AND    a.musteri_no      =  NVL(TO_NUMBER(pn_custno),a.musteri_no )
        --      AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.cek_durum       =  DECODE(ps_state,'TAMAMI',a.cek_durum,NULL,a.cek_durum,ps_state)
              AND     check_doviz(a.cek_doviz, ps_curr) = 'E'
              AND     a.odeme_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                          AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
              AND    a.tahsil_teminat  = DECODE(ps_tahtem,'TAMAMI',a.tahsil_teminat,NULL,a.tahsil_teminat,ps_tahtem)
              ORDER BY DECODE(ps_sort,'VADE',vade,'BANKA',banka_adi,'SUBE',banka_sube_adi,'BORCLU',borclu_adi,'CEK',a.cek_no,'TUTAR',a.cek_tutari,vade);

          END IF;
      END IF;

  -- Senetler i?in
  ELSIF  ps_type = 'PN' THEN
        IF  ps_Tarih ='VADE' OR ps_Tarih IS NULL THEN

        IF ps_state = 'A'  THEN
                OPEN pc_ref FOR
              SELECT TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                     Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                     a.borclu_adi borclu_adi,
                     a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                     'ACIK' durum,
                     TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                     a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
              FROM   CBS_SENET a
              WHERE  a.tahsil_musteri_no      =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
              --AND     a.tahsil_hesap_no           =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.durum_kodu                IN ('A','K','KS')
              AND     a.doviz_kodu               =  DECODE(ps_curr,NULL,Pkg_Genel.lc_al,ps_curr)
              AND    a.urun_tur_kod              = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
              AND      a.senet_teminat_turu       = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
              AND     a.vade_tarihi              BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                                    AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        ELSIF ps_state = 'O'  THEN
                OPEN pc_ref FOR
              SELECT TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                     Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                     a.borclu_adi borclu_adi,
                     a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                     'ODENDI' durum,
                     TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                     a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
              FROM   CBS_SENET a
              WHERE  a.tahsil_musteri_no      =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
              --AND     a.tahsil_hesap_no           =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.durum_kodu                IN ('O','PO')
              AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
              AND    a.urun_tur_kod              = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
              AND      a.senet_teminat_turu       = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
              AND     a.vade_tarihi              BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                                    AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        ELSIF ps_state = 'I'  THEN
                OPEN pc_ref FOR
              SELECT TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                     Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                     a.borclu_adi borclu_adi,
                     a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                     'IADE' durum,
                     TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                     a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
              FROM   CBS_SENET a
              WHERE  a.tahsil_musteri_no      =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
              --AND     a.tahsil_hesap_no           =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.durum_kodu                IN ('I','PI')
              AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
              AND    a.urun_tur_kod              = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
              AND      a.senet_teminat_turu       = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
              AND     a.vade_tarihi              BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                                    AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));

        ELSIF ps_state = 'P'  OR ps_state = 'T'  OR ps_state IS NULL THEN
                OPEN pc_ref FOR
              SELECT TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                     Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                     a.borclu_adi borclu_adi,
                     a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                     DECODE(a.durum_kodu,'A','ACIK','K','ACIK','P','PROTESTO','O','ODENDI','PO','ODENDI',
                     'I','IADE','PI','IADE','KS','ACIK') durum,
                     TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                     a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
              FROM   CBS_SENET a
              WHERE  a.tahsil_musteri_no      =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
              --AND     a.tahsil_hesap_no           =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
              AND     a.durum_kodu                  =  DECODE(ps_state,'T',a.durum_kodu,NULL,a.durum_kodu,ps_state)
              AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
              AND    a.urun_tur_kod              = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
              AND      a.senet_teminat_turu       = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
              AND     a.vade_tarihi              BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                                    AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        END IF;


      ELSIF ps_Tarih ='ODEME' THEN
        IF ps_state = 'A'  THEN
            OPEN pc_ref FOR
            SELECT  TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                    Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                    a.borclu_adi borclu_adi,
                    a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                    'ACIK' durum,
                    TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                    a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
            FROM   CBS_SENET a
            WHERE  a.tahsil_musteri_no  =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
            --AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
            AND     a.durum_kodu           IN ('A','K','KS')
            AND     a.doviz_kodu            = DECODE(ps_curr,NULL,Pkg_Genel.lc_al,ps_curr)
            AND  a.urun_tur_kod          = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
            AND  a.senet_teminat_turu = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
            AND     a.senet_tahsil_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                            AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        ELSIF ps_state = 'O'  THEN
            OPEN pc_ref FOR
            SELECT  TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                    Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                    a.borclu_adi borclu_adi,
                    a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                    'ODENDI' durum,
                    TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                    a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
            FROM   CBS_SENET a
            WHERE  a.tahsil_musteri_no  =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
            --AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
            AND     a.durum_kodu            IN ('O','PO')
            AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
            AND  a.urun_tur_kod          = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
            AND  a.senet_teminat_turu = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
            AND     a.senet_tahsil_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                            AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        ELSIF ps_state = 'I'  THEN
            OPEN pc_ref FOR
            SELECT  TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                    Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                    a.borclu_adi borclu_adi,
                    a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                    'IADE' durum,
                    TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                    a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
            FROM   CBS_SENET a
            WHERE  a.tahsil_musteri_no  =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
            --AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
             AND     a.durum_kodu            IN ('I','PI')
            AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
            AND  a.urun_tur_kod          = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
            AND  a.senet_teminat_turu = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
            AND     a.senet_tahsil_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                            AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));

        ELSIF ps_state = 'P'  OR ps_state = 'T'  OR ps_state IS NULL THEN
            OPEN pc_ref FOR
            SELECT  TO_CHAR(a.vade_tarihi ,'YYYYMMDD') vade,
                    Pkg_Genel.bolum_adi_al(a.bolum_kodu) sube_adi,
                    a.borclu_adi borclu_adi,
                    a.senet_no,a.durum_kodu,a.senet_tutari,a.tahsil_hesap_no,a.tahsil_musteri_no,
                     DECODE(a.durum_kodu,'A','ACIK','K','ACIK','P','PROTESTO','O','ODENDI','PO','ODENDI',
                     'I','IADE','PI','IADE','KS','ACIK') durum,
                    TO_CHAR(a.senet_tahsil_tarihi ,'YYYYMMDD') odeme_tarihi,
                    a.urun_tur_kod,a.senet_teminat_turu,a.doviz_kodu
            FROM   CBS_SENET a
            WHERE  a.tahsil_musteri_no  =  NVL(TO_NUMBER(pn_custno),a.tahsil_musteri_no )
            --AND     a.tahsil_hesap_no =  NVL(TO_NUMBER(pn_accountno),a.tahsil_hesap_no)
            AND     a.durum_kodu            = DECODE(ps_state,'T',a.durum_kodu,NULL,a.durum_kodu,ps_state)
            AND     check_doviz(a.doviz_kodu, ps_curr) = 'E'
            AND  a.urun_tur_kod          = DECODE(ps_tahtem,'TAMAMI',a.urun_tur_kod,NULL,a.urun_tur_kod,ps_tahtem)
            AND  a.senet_teminat_turu = DECODE(ps_aslimunzam,'TAMAMI',a.senet_teminat_turu,NULL,a.senet_teminat_turu,ps_aslimunzam )
            AND     a.senet_tahsil_tarihi    BETWEEN   NVL(TO_DATE(pd_start_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'))
                                            AND       NVL(TO_DATE(pd_end_date,'YYYYMMDD'),TO_DATE(TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),'YYYYMMDD'));
        END IF;

      END IF;
  END IF;
  RETURN ls_returncode;

  EXCEPTION
    WHEN not_valid_date THEN
    ls_returncode:='414';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;

    WHEN OTHERS THEN
    ls_returncode:='999';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;

END;


/******************************************************************************
   NAME       : FUNCTION GetCustomerAccounts
   Created By : Seval Balci
   Date          : 17.06.04
   Purpose      :Customer Accounts Informations are returned
******************************************************************************/
FUNCTION GetCustomerAccounts(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS    ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;

BEGIN

  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;

  -- hesap var m? yok mu?
  SELECT COUNT(*)
  INTO ls_account_count
  FROM
  CBS_vw_hesap_izleme a
  WHERE a.MUSTERI_NO=pn_musteri_no;

  IF (ls_account_count= 0) THEN
  RAISE noAccoutFound;
  END IF;


  OPEN pc_ref FOR
  SELECT *
  FROM
 (
  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         modul_tur_kod= 'VADESIZ' AND
         urun_tur_kod IN ('MUSTAK-TP','MUSTAK-YP','TEMINAT-TP','TEMINAT-YP','BLOKE-TP','BLOKE-YP')
   UNION
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           2 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         modul_tur_kod= 'VADELI'
   UNION
   SELECT
             'Nakit Krediler' modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           3 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim
    FROM CBS_vw_hesap_izleme a
    WHERE
         musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         urun_tur_kod != 'LEASING' AND
         modul_tur_kod= 'KREDI'     AND
         Pkg_Genel.urun_sinif_nakdimi('KREDI',urun_tur_kod,urun_sinif_kod) ='E' AND
            Pkg_Kredi.sf_dovize_endeksli_kredimi('KREDI',urun_tur_kod,urun_sinif_kod) = 'H'
   UNION
   SELECT
             'D?vize Endeksli Krediler' modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           Pkg_Kredi.sf_endeks_doviz_kodu_al(hesap_no) DOVIZ_KODU,
          (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') BAKIYE,
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           4 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi ,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE
         musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         modul_tur_kod= 'KREDI'     AND
            Pkg_Kredi.sf_dovize_endeksli_kredimi('KREDI',urun_tur_kod,urun_sinif_kod) = 'E'
   UNION
   SELECT
             'Teminat Mektubu' modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           5 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi ,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE
         musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         urun_tur_kod = 'TEM.MEKTUP' AND
         modul_tur_kod= 'KREDI'
   UNION
   SELECT
             'Akreditif' modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           6 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi     ,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE
         musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         urun_tur_kod IN ( 'ITH.AKR','KABULKRED') AND
         modul_tur_kod= 'KREDI'
   UNION
   SELECT
             'Leasing' modul_tur_kod,
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           7 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi ,kisa_isim
   FROM CBS_vw_hesap_izleme a
   WHERE
         musteri_no = pn_musteri_No AND
            durum_kodu = 'A' AND
         urun_tur_kod = 'LEASING' AND
         modul_tur_kod= 'KREDI'

   )
   ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu ;



/*  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod),
             MUSTERI_NO,
           ISIM_UNVAN,
           sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
           HESAP_NO,
           DOVIZ_KODU,
           NVL(BAKIYE,0),
           NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
           DECODE(modul_tur_kod,'VADESIZ',1,'VADELI',2,'KREDI',3) siralama
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
            durum_kodu = 'A'
    ORDER BY DECODE(modul_tur_kod,'VADESIZ',1,'VADELI',2,'KREDI',3) , SUBE_KODU, HESAP_NO,doviz_kodu ;
   */
  RETURN ls_returncode;
    EXCEPTION
    WHEN noAccoutFound THEN
      ls_returncode:= '503';
    RETURN ls_returncode;

END;

/******************************************************************************
   NAME       : FUNCTION GetNBExchangeRate
   Created By : Bilal GUL
   Date          : 18.06.04
   Purpose      : National Bank Exchange Rates are returned
******************************************************************************/

 FUNCTION GetNBExchangeRate(pd_tarih IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

  OPEN pc_ref FOR
  SELECT DVZ,
           DVZALIS,
         DVZSATIS,
         EFALIS,
         EFSATIS,
         ACIKLAMA
   FROM CBS_MBKURLOG,CBS_DOVIZ_KODLARI
   WHERE dvz=doviz_kodu
   AND TO_CHAR(tarih,'YYYYMMDD')=pd_TARIH
   AND gecerli_kur='E'
   AND ( (DVZ<>Pkg_Genel.lc_al) AND (DVZ <> 'TRL'))
   ORDER BY SIRA_NO;

   RETURN ls_returncode;

 END;
-----------------------------------------------------------------------------------
FUNCTION GetAccountTypeName(ps_modul_tur_kod VARCHAR2) RETURN VARCHAR2
IS
ls_modul VARCHAR2(50);
BEGIN
    SELECT DECODE( ps_modul_tur_kod,'LOAN','Loan Accounts',
                                          'TIME DEP.','Time Deposit Accounts',
                                    'CURRENT','Current Accounts')
    INTO ls_modul
    FROM dual;

  RETURN ls_modul;
END;

/******************************************************************************
   NAME       : GetCustomerAccountDetails
   Created By : Seval Balci
   Date          : 17.06.04
   Purpose      :Customer Account Detail Informations are returned
******************************************************************************/
FUNCTION GetCustomerAccountDetails(pn_account_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS    ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
  SELECT    hesap_no,
              sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
            trim(doviz_kodu),
            kisa_isim,
            modul_tur_kod,
              urun_tur_kod,
            urun_sinif_kod,
             TO_CHAR(acilis_tarihi,'YYYYMMDD') acilis_tarihi,
            TO_CHAR(vade_tarihi,'YYYYMMDD') vade_tarihi,
            NVL(faiz_orani,0),

              NVL(bakiye,0),
              NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
            NVL(bloke_tutari,0) bloke_tutari,
            DECODE(cek_karnesi,'E','Evet','Hay?r') cek_karnesi,
             DECODE(ekstre_basim_kodu,'E','Evet','Hay?r') ekstre_basim_kodu,
             NVL(birikmis_faiz_poz,0) birikmis_faiz_poz,
            NVL(birikmis_faiz_neg,0) birikmis_faiz_neg,
            NVL(gecen_yil_faiz_toplami,0) gecen_yil_faiz_toplami,
            NVL(odenmis_faiz_toplami,0)   odenmis_faiz_toplami        ,
            Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod) siralama,

            DECODE(vade_islem_bilgisi,1,'Kapama',2,'Ana Para Temdit',3,'Faizli Bakiye Temdit') vade_islem_bilgisi,
            otomatik_temdit,
--            NVL(TO_CHAR(period_sure),' ') || DECODE(NVL(period_cins,' '),'G','G?n','A','AY','Y','Y?l','AS','AySonu','YS','Y?lSonu') temdit_periodu,
            NVL(TO_CHAR(period_sure),' ') || NVL(period_cins,' ') temdit_periodu,
            (SELECT TO_CHAR(faiz_tahakkuk_tarihi,'YYYYMMDD') FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') faiz_tahakkuk_tarihi,
            (SELECT NVL(komisyon_orani,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') komisyon_orani,
            (SELECT NVL(birikmis_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') birikmis_komisyon_tutari,
            (SELECT NVL(tahsiledilen_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') tahsiledilen_komisyon_tutari,
            (SELECT NVL(gecenyil_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') gecenyil_komisyon_tutari,
            Pkg_Kredi.sf_endeks_doviz_kodu_al(hesap_no) end_dovz_kodu,
            (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_doviz_tutari,

            (SELECT referans FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_referans,
            (SELECT NVL(tutar,0) FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) tm_tutar,
            (SELECT TO_CHAR(verilis_tarihi,'YYYYMMDD') FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_verilis_tarihi,
            (SELECT muhatap FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_muhatap    ,
            (SELECT referans FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) AKR_Referans,
            (SELECT NVL(dosya_tutari,0) FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) dosya_tutari,
            (SELECT urun_sinif FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) akreditifin_cinsi,
--            Pkg_Int.GetAccountType(Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod),urun_tur_kod,urun_sinif_kod) hesap_turu,
            (SELECT NVL(acilis_kuru    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_acilis_kuru

   FROM     CBS_vw_hesap_izleme a
   WHERE    hesap_no = TO_NUMBER(pn_account_No) ;

  RETURN ls_returncode;
 EXCEPTION WHEN OTHERS THEN Log_At(SQLERRM);
 END;

FUNCTION GetAccountHistory(pn_account_no IN VARCHAR2,
                           pd_start_date IN VARCHAR2,
                           pd_end_date      IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
    ls_returncode VARCHAR2(3):='000';
    ld_startdate  DATE;
    ld_enddate      DATE;

    not_valid_date EXCEPTION;

    PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- yanl?? zaman girilmesi durumunda

BEGIN

  ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
  ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');

  OPEN pc_ref FOR
    SELECT  TO_CHAR(fis_muhasebelestigi_tarih,'YYYYMMDD'),
            TO_CHAR(satir_valor_tarihi,'YYYYMMDD'),
            UPPER(satir_musteri_aciklama),
            satir_dv_tutar,
            NVL(Pkg_Passbook.HareketliBakiyeHesapla(satir_hesap_numara,fis_numara,satir_numara),0) son_bakiye,
            SATIR_DOVIZ_KOD
    FROM cbs_vw_fis_satir_vsziz a
    WHERE  satir_hesap_numara = pn_account_no AND
           fis_muhasebelestigi_tarih BETWEEN TO_DATE(pd_start_date,'YYYYMMDD') AND TO_DATE(pd_end_date,'YYYYMMDD') AND
           fis_tur = 'G'
   ORDER BY fis_numara,fis_fis_no ;

  RETURN ls_returncode;

  EXCEPTION
    WHEN not_valid_date THEN
     ls_returncode:='414';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;

    WHEN OTHERS THEN
     ls_returncode:='999';
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
    RETURN ls_returncode;
END;

FUNCTION GetAccountSort(ps_modul IN VARCHAR2,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN NUMBER IS
    ln_returncode NUMBER ;
BEGIN

  IF ps_modul = 'CURRENT' THEN
       ln_returncode := 1;
  ELSIF ps_modul = 'TIME DEP.' THEN
     ln_returncode := 2;
  ELSIF ps_modul = 'LOAN' THEN
--       IF  ps_urun = 'L/G'  OR ps_urun = 'VER.GARAN' THEN
--        ln_returncode := 5;
--       ELSIF  ps_urun = 'ITH.AKR' OR  ps_urun = 'KABULKRED' OR ps_urun = 'AKREDITIF' THEN
        ln_returncode := 3 ;
--       ELSIF  ps_urun = 'LEASING' THEN
--        ln_returncode := 7;
--     ELSIF ps_urun != 'LEASING' AND Pkg_Genel.urun_sinif_nakdimi(ps_modul,ps_urun,ps_sinif) ='E' AND
--            Pkg_Kredi.sf_dovize_endeksli_kredimi(ps_modul,ps_urun,ps_sinif) = 'H'        THEN
--              ln_returncode := 3;
--       ELSIF Pkg_Kredi.sf_dovize_endeksli_kredimi(ps_modul,ps_urun,ps_sinif) = 'E'    THEN
--              ln_returncode := 4;
--     END IF;
  END IF;

  RETURN ln_returncode;
END;


FUNCTION GetAccountPaymentPolicyInfo(pn_account_no IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
  ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
  SELECT b.sira_no, TO_CHAR(b.vade_valor,'YYYYMMDD'), NVL(b.tutar,0), NVL(b.faiz_tutari,0), NVL(b.muhabir_masrafi,0) ,b.referans
  FROM   CBS_HESAP_KREDI a ,CBS_ITH_VESAIK_ODEME b
  WHERE  b.referans = a.referans AND
         a.hesap_no = TO_NUMBER(pn_account_No) AND
         b.durum_kodu = 'A' AND
         a.durum_kodu = 'A';
  RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN Log_At(SQLERRM);
END;


FUNCTION GetAccountType(ps_tur IN NUMBER,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN VARCHAR2 IS
    ln_returncode VARCHAR2(100) ;
BEGIN

  SELECT HESAP_TURU
  INTO   ln_returncode
  FROM   CBS_INT_HESAP_TURU
  WHERE  HESAP_TIPI        = ps_tur AND
           URUN_TUR_KOD        = ps_urun AND
           URUN_SINIF_KOD    = ps_sinif ;

  RETURN ln_returncode;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
   ln_returncode := ' ' ;
  WHEN OTHERS THEN
   ln_returncode :=' ';

END;
-----------------------------------------------------------------------------------
FUNCTION GetStaffInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
         ls_returncode VARCHAR2(3):='000';
         ln_pnumara       NUMBER;
         ln_sicil       NUMBER;
    no_data        EXCEPTION;
BEGIN
OPEN pc_ref FOR
SELECT SYSDATE
FROM dual;

SELECT Pkg_Musteri.Sf_PersonelSicilNoAl(TO_NUMBER(pn_musteri_no))
INTO ln_sicil
FROM dual;

IF ln_sicil = 0
THEN
  RAISE NO_DATA ;
END IF;
  OPEN pc_ref FOR
        SELECT ADI ||' '|| SOYADI,KODU,TO_CHAR(SYSDATE,'YYYYMMDD'),'', SIFRE, PERSONEL_NUMARA, TUR,
               DEKONT_YAZICI, RAPOR_YAZICI, PROFIL_KOD, YARATILDIGI_TARIH,
               YARATAN_KULLANICI_KODU, VERSIYON, AGENT, EMAIL, CALISILAN_BOLUM,
               GOREV_KODU, RAPOR_SUNUCUSU
        FROM CBS_KULLANICI
        WHERE PERSONEL_NUMARA = Pkg_Musteri.Sf_PersonelSicilNoAl(TO_NUMBER(pn_musteri_no))
        AND ROWNUM=1;

    SELECT PERSONEL_NUMARA
    INTO ln_pnumara
    FROM CBS_KULLANICI
        WHERE PERSONEL_NUMARA = Pkg_Musteri.Sf_PersonelSicilNoAl(TO_NUMBER(pn_musteri_no))
        AND ROWNUM=1;

  RETURN ls_returncode;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
         RETURN '024';
    WHEN no_data THEN
    RETURN '024';
END;
------------------------------------------------------------------------------------
FUNCTION GetTranAccounts(pn_musteri_no IN VARCHAR2,ps_currcode IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
      SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi
       FROM CBS_vw_hesap_izleme a
       WHERE musteri_no = pn_musteri_No
                AND durum_kodu = 'A'
             AND modul_tur_kod= 'VADESIZ'
             AND urun_tur_kod IN ('MUSTAK-TP','MUSTAK-YP','TEMINAT-TP','TEMINAT-YP','BLOKE-TP','BLOKE-YP')
             AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
             AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
       ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------
FUNCTION GetBankCodes(ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
  OPEN pc_ref FOR
    SELECT BANKA_KODU,SUBSTR(BANKA_ADI,1,40)
    FROM CBS_BANKA_KODLARI
    ORDER BY BANKA_KODU;
   RETURN ls_returncode;
 END;
--------------------------------------------------------------------------------------
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
  OPEN pc_ref FOR
    SELECT ISTATISTIK_KODU,SUBSTR(ACIKLAMA,1,50)
    FROM CBS_ISTATISTIK_KODLARI
    ORDER BY ISTATISTIK_KODU;

   RETURN ls_returncode;
 END;
--------------------------------------------------------------------------------------
FUNCTION GetCustomerFullName(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
   OPEN pc_ref FOR
   SELECT m.ISIM,m.IKINCI_ISIM,m.SOYADI
    FROM CBS_MUSTERI m
   WHERE m.musteri_no = TO_NUMBER(pn_musteri_no);

  RETURN ls_returncode;
 END;
--------------------------------------------------------------------------------------
FUNCTION CheckVergiKimlikNo(ps_vergi_kimlik_no VARCHAR2, ps_customerid VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ls_record_count NUMBER:= 0;

  BEGIN
  OPEN pc_ref FOR
  SELECT SYSDATE FROM DUAL;

  SELECT COUNT(*)
  INTO ls_record_count
  FROM CBS_MUSTERI m
  WHERE m.VERGI_NO=ps_vergi_kimlik_no
  AND m.MUSTERI_NO=TO_NUMBER(ps_customerid);

  IF (ls_record_count > 0) THEN
  ls_returncode := '000';
  ELSE
  ls_returncode := '285';
  END IF;

  RETURN ls_returncode;
 EXCEPTION
    WHEN NO_DATA_FOUND THEN
    OPEN pc_ref FOR
    SELECT SYSDATE FROM DUAL;
    RETURN '285';
 END;
------------------------------------------------------------
FUNCTION SetNewPassword(ps_password IN VARCHAR2,
                         pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 ps_username        VARCHAR2(13):='cint_caller';
 BEGIN
     OPEN pc_ref FOR
     SELECT 'lala' FROM dual;

    EXECUTE IMMEDIATE 'ALTER USER  ' || ps_username || '  IDENTIFIED BY  ' ||  ps_password ;
     RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
END;

--------------------------------------------------------------------
FUNCTION GetMeslekKodlari(ps_dummy IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 BEGIN

    OPEN pc_ref FOR
    SELECT m.MESLEK_KODU,m.ACIKLAMA
    FROM CBS_MESLEK_KODLARI m
    ORDER BY m.MESLEK_KODU;

    RETURN ls_returncode;

 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
END;

--------------------------------------------------------------------
FUNCTION GetEgitimDurumlari(ps_dummy IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 BEGIN

    OPEN pc_ref FOR
    SELECT m.EGITIM_KODU,m.ACIKLAMA
    FROM CBS_EGITIM_KODLARI m
    ORDER BY m.EGITIM_KODU;

    RETURN ls_returncode;


 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
END;
--------------------------------------------------------------------
FUNCTION GetMedeniHalDurumlari(ps_dummy IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
 ls_returncode         VARCHAR2(3):='000';
 BEGIN

    OPEN pc_ref FOR
    SELECT m.MEDENI_HAL_KODU,m.ACIKLAMA
    FROM CBS_MEDENI_HAL_KODLARI m
    ORDER BY m.MEDENI_HAL_KODU;

    RETURN ls_returncode;


 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
END;

-------------------------------------------------------------------------
FUNCTION GetCinsiyetKodlari(ps_dummy IN VARCHAR2,
                                pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
                               ls_returncode         VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
    SELECT C.CINSIYET_KODU,C.ACIKLAMA
    FROM CBS_CINSIYET_KODLARI C
    ORDER BY C.CINSIYET_KODU;

    RETURN ls_returncode;


 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION GetCustomerAddress(ps_custid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
                          ls_returncode         VARCHAR2(3):='000';
 BEGIN
    OPEN pc_ref FOR
    SELECT a.ADRES_KOD,k.ACIKLAMA, a.ADRES,Pkg_Genel.sehir_adi_al_hatasiz(a.IL_KOD),a.IL_KOD,
    Pkg_Genel.ilce_adi_al_hatasiz(a.IL_KOD,a.ILCE_KOD),a.ILCE_KOD,
           a.POSTA_KOD,a.SEMT,a.TEL_ALAN_KOD,a.TEL_NO,a.GSM_ALAN_KOD,
           a.GSM_NO,a.EMAIL,Pkg_Genel.ulke_adi_al_hatasiz(a.ULKE_KOD),a.ULKE_KOD,
           a.ADRES ||' '||NVL(a.POSTA_KOD,'')||' '||a.SEMT||' '||
           Pkg_Genel.sehir_adi_al_hatasiz(a.IL_KOD)||' '||Pkg_Genel.ulke_adi_al_hatasiz(a.ULKE_KOD),'('||a.TEL_ALAN_KOD||') '||a.TEL_NO,'('||a.GSM_ALAN_KOD||') '||a.GSM_NO
    FROM   CBS_MUSTERI_ADRES a,
           CBS_ADRES_KODLARI k
    WHERE  a.MUSTERI_NO = ps_custid AND
           k.ADRES_TIPI = a.ADRES_KOD
           ORDER BY k.ADRES_TIPI DESC;
    RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;
         ls_returncode:='999';
        RETURN ls_returncode;
END;
--------------------------------------------------------------------
FUNCTION GetAddressDetay(ps_custid IN VARCHAR2,
                         ps_adrestur IN VARCHAR2,
                           pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS
                          ls_returncode         VARCHAR2(3):='000';
 BEGIN
    OPEN pc_ref FOR
    SELECT a.ADRES_KOD,k.ACIKLAMA, a.ADRES,l.IL_ADI,a.IL_KOD,s.ILCE_ADI,a.ILCE_KOD,
           a.POSTA_KOD,a.SEMT,a.TEL_ALAN_KOD,a.TEL_NO,a.GSM_ALAN_KOD,
           a.GSM_NO,a.EMAIL,u.ULKE_ADI,a.ULKE_KOD,
           a.ADRES ||' '||NVL(a.POSTA_KOD,'')||' '||a.SEMT||' '||s.ILCE_ADI||' '
           ||l.IL_ADI||' '||u.ULKE_ADI,'('||a.TEL_ALAN_KOD||') '||a.TEL_NO,'('||a.GSM_ALAN_KOD||') '||a.GSM_NO,
           a.FAX_ALAN_KOD,a.FAX_NO
    FROM   CBS_MUSTERI_ADRES a,
           CBS_ADRES_KODLARI k,
           CBS_IL_KODLARI l,
           CBS_ILCE_KODLARI s,
           CBS_ULKE_KODLARI u
    WHERE  a.MUSTERI_NO = ps_custid AND
           a.ADRES_KOD = ps_adrestur AND
           k.ADRES_TIPI = a.ADRES_KOD AND
           l.IL_KODU = a.IL_KOD AND
           s.IL_KODU = a.IL_KOD AND
           s.ILCE_KODU = a.ILCE_KOD AND
           u.ULKE_KODU= a.ULKE_KOD
           ORDER BY k.ADRES_TIPI DESC;
    RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;
         ls_returncode:='999';
        RETURN ls_returncode;
END;
---------------------------------------------------------------------------------------
FUNCTION UpdateMusteriBilgi(pn_musteri_no VARCHAR2 ,
                                      pn_cinsiyet_kod VARCHAR2,
                                      pn_medeni_hal_kod VARCHAR2,
                                      pn_meslek_kod VARCHAR2,
                                      pn_egitim_durumu_kod VARCHAR2,
                                       pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

     pn_islem_kod NUMBER;
     pc_modul_tur_kod VARCHAR2(10);
     pc_urun_tur_kod VARCHAR2(10);
     pc_urun_sinif_kod VARCHAR2(10);
     ps_BOLUM_KODU VARCHAR2(3):=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(pn_musteri_no));
     pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_rol NUMBER:=5000;
     pc_kasa_kod NUMBER;
     pc_doviz_kod VARCHAR(10);
     pc_hesap_numara NUMBER;
     pn_tx_no CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE;
     ls_returncode VARCHAR2(3):='000';

BEGIN

     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;
     Pkg_Baglam.Yarat(ps_BOLUM_KODU,pc_rol);

     pn_islem_kod:=1001;

     Pkg_Musteri.sp_musteri_urun_sinif_al(TO_NUMBER(pn_musteri_no),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);
     Pkg_Musteri.Sp_Musteri_Guncel_Kaydi_Olus(TO_NUMBER(pn_musteri_no),pn_tx_no);

     UPDATE CBS_MUSTERI_GUNCELLENEN g
     SET
     g.CINSIYET_KOD=pn_cinsiyet_kod,
     g.MEDENI_HAL_KOD=pn_medeni_hal_kod,
     g.MESLEK_KOD=pn_meslek_kod,
     g.EGITIM_KOD=pn_egitim_durumu_kod
     WHERE g.TX_NO = pn_tx_no AND
            g.MUSTERI_NO = pn_musteri_no;

     UPDATE CBS_MUSTERI m
     SET
     m.CINSIYET_KOD=pn_cinsiyet_kod,
     m.MEDENI_HAL_KOD=pn_medeni_hal_kod,
     m.MESLEK_KOD=pn_meslek_kod,
     m.EGITIM_KOD=pn_egitim_durumu_kod
     WHERE  m.musteri_no = pn_musteri_no;

     Pkg_Int_Api.create_transaction (pn_tx_no, pn_islem_kod,
                                      pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                     0, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                     pc_doviz_kod, pn_musteri_no,pc_hesap_numara,
                                     pc_kasa_kod,1);

    Pkg_Int_Api.process_transaction (pn_tx_no);

    RETURN ls_returncode;

    EXCEPTION
         WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At(SQLERRM,ls_returncode);
            ROLLBACK;
            OPEN pc_ref FOR
              SELECT SYSDATE FROM dual;
            RETURN ls_returncode;
END;
-----------------------------------------------------------------------
FUNCTION UpdateMusteriAdresBilgi(pn_musteri_no VARCHAR2 ,
                                 pn_adres_kod VARCHAR2,
                                 pn_alan_kod VARCHAR2,
                                 pn_tel_no VARCHAR2,
                                 pn_gsmalan_kod VARCHAR2,
                                 pn_gsmtel_no VARCHAR2,
                                 pn_fax_alan_kod VARCHAR2,
                                 pn_fax_no VARCHAR2,
                                 pn_p_email_no VARCHAR2,
                                 ps_adres VARCHAR2,
                                  pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

     pn_islem_kod NUMBER;
     pc_modul_tur_kod VARCHAR2(10);
     pc_urun_tur_kod VARCHAR2(10);
     pc_urun_sinif_kod VARCHAR2(10);
     ps_BOLUM_KODU VARCHAR2(3):=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(pn_musteri_no));
     pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_rol NUMBER:=5000;
     pc_kasa_kod NUMBER;
     pc_doviz_kod VARCHAR(10);
     pc_hesap_numara NUMBER;
     pn_tx_no CBS_MUSTERI_GUNCEL_ADRES.tx_no%TYPE;
     ls_returncode VARCHAR2(3):='000';

     BEGIN

     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;
     Pkg_Baglam.Yarat(ps_BOLUM_KODU,pc_rol);

     pn_islem_kod:=1001;

     Pkg_Musteri.sp_musteri_urun_sinif_al(TO_NUMBER(pn_musteri_no),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);
     Pkg_Musteri.Sp_Musteri_Guncel_Kaydi_Olus(TO_NUMBER(pn_musteri_no),pn_tx_no);


     UPDATE CBS_MUSTERI_GUNCEL_ADRES g
     SET
     g.TEL_ALAN_KOD = pn_alan_kod,
     g.TEL_NO = pn_tel_no,
     g.GSM_ALAN_KOD = pn_gsmalan_kod,
     g.GSM_NO = pn_gsmtel_no,
     g.FAX_ALAN_KOD = pn_fax_alan_kod,
     g.FAX_NO = pn_fax_no,
     g.EMAIL = pn_p_email_no,
     g.ADRES = ps_adres
     WHERE g.TX_NO = pn_tx_no AND
            g.ADRES_KOD = pn_adres_kod;

     UPDATE CBS_MUSTERI_ADRES m
     SET
     m.TEL_ALAN_KOD = pn_alan_kod,
     m.TEL_NO = pn_tel_no,
     m.GSM_ALAN_KOD = pn_gsmalan_kod,
     m.GSM_NO = pn_gsmtel_no,
     m.FAX_ALAN_KOD = pn_fax_alan_kod,
     m.FAX_NO = pn_fax_no,
     m.EMAIL = pn_p_email_no,
     m.ADRES = ps_adres
     WHERE  m.musteri_no = pn_musteri_no
            AND m.ADRES_KOD = pn_adres_kod;

     Pkg_Int_Api.create_transaction (pn_tx_no, pn_islem_kod,
                                      pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                     0, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                     pc_doviz_kod, pn_musteri_no,pc_hesap_numara,
                                     pc_kasa_kod,1);

    Pkg_Int_Api.process_transaction (pn_tx_no);

    RETURN ls_returncode;

    EXCEPTION
         WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At(SQLERRM,ls_returncode);
            ROLLBACK;
            OPEN pc_ref FOR
              SELECT SYSDATE FROM dual;
            RETURN ls_returncode;
END;
------------------------------------------------------------------
FUNCTION UpdateMusteriEkstreAdres(pn_musteri_no VARCHAR2 ,
                                 pn_adres_kod VARCHAR2,
                                  pc_ref OUT CursorReferenceType)RETURN VARCHAR2 IS

     pn_islem_kod NUMBER;
     pc_modul_tur_kod VARCHAR2(10);
     pc_urun_tur_kod VARCHAR2(10);
     pc_urun_sinif_kod VARCHAR2(10);
     ps_BOLUM_KODU VARCHAR2(3):=Pkg_Musteri.sf_bolum_kodu_al(TO_NUMBER(pn_musteri_no));
     pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
     pc_rol NUMBER:=5000;
     pc_kasa_kod NUMBER;
     pc_doviz_kod VARCHAR(10);
     pc_hesap_numara NUMBER;
     pn_tx_no CBS_MUSTERI_GUNCELLENEN.tx_no%TYPE;
     ls_returncode VARCHAR2(3):='000';

BEGIN

     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual;
     Pkg_Baglam.Yarat(ps_BOLUM_KODU,pc_rol);

     pn_islem_kod:=1001;

     Pkg_Musteri.sp_musteri_urun_sinif_al(TO_NUMBER(pn_musteri_no),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);
     Pkg_Musteri.Sp_Musteri_Guncel_Kaydi_Olus(TO_NUMBER(pn_musteri_no),pn_tx_no);

     UPDATE CBS_MUSTERI_GUNCELLENEN g
     SET
     g.EXTRE_ADRES_KOD=pn_adres_kod
     WHERE g.TX_NO = pn_tx_no AND
            g.MUSTERI_NO = pn_musteri_no;

     UPDATE CBS_MUSTERI m
     SET
     m.EXTRE_ADRES_KOD=pn_adres_kod
     WHERE  m.musteri_no = pn_musteri_no;

     Pkg_Int_Api.create_transaction (pn_tx_no, pn_islem_kod,
                                      pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                     0, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                     pc_doviz_kod, pn_musteri_no,pc_hesap_numara,
                                     pc_kasa_kod,1);

    Pkg_Int_Api.process_transaction (pn_tx_no);

    RETURN ls_returncode;

    EXCEPTION
         WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At(SQLERRM,ls_returncode);
            ROLLBACK;
            OPEN pc_ref FOR
              SELECT SYSDATE FROM dual;
            RETURN ls_returncode;
END;
---------------------------------------------------------------------------
FUNCTION SetGenelGuvenlikAyarlari(
                                  ps_secim1 IN VARCHAR2,
                                  ps_secim2 IN VARCHAR2,
                                  ps_start1 IN VARCHAR2,
                                  ps_start2 IN VARCHAR2,
                                  ps_personid IN VARCHAR2,
                                  ps_chanelcd IN VARCHAR2,
                                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                      ls_returncode         VARCHAR2(3):='000';
                      ls_count NUMBER:=0;
 BEGIN
      OPEN pc_ref FOR
      SELECT 'lala' FROM dual;

      SELECT COUNT(*)
      INTO ls_count
      FROM CBS_INT_GENELGUV G
      WHERE G.PERSONID=ps_personid AND
      G.CHANNELCD=ps_chanelcd;

      IF (ls_count > 0) THEN
          DELETE FROM CBS_INT_GENELGUV G
          WHERE G.PERSONID=ps_personid AND
          G.CHANNELCD=ps_chanelcd;
      END IF;

      IF (ps_secim1 <> '1') THEN
        INSERT INTO CBS_INT_GENELGUV(PERSONID, SECIM1, SECIM2, BASLANGICSAAT, BITISSAAT,CHANNELCD)
        VALUES(ps_personid,ps_secim1,ps_secim2,DECODE(ps_secim2,'1','00.00',ps_start1),DECODE(ps_secim2,'1','23.00',ps_start2),ps_chanelcd);
      END IF;

      RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
 END;
------------------------------------------------------------------------------------
FUNCTION ChechSMSInfoMessage( ps_personid IN VARCHAR2,
                     ps_channelcd IN VARCHAR2,
                     ps_customerid IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

                     tmp CursorReferenceType;
                     ls_returncode         VARCHAR2(3):='000';
                     ps_start1 VARCHAR2(5);
                     ps_start2 VARCHAR2(5);
                     ls_count NUMBER:=0;
 BEGIN
      OPEN pc_ref FOR
      SELECT 'lala' FROM dual;

      SELECT COUNT(*)
      INTO ls_count
      FROM CBS_INT_GENELGUV G
      WHERE
      G.PERSONID=ps_personid AND
      G.CHANNELCD=ps_channelcd AND
      G.SECIM1='3'; -- e?er logon olduktan sonra bana sms g?nder ise


      IF (ls_count > 0) THEN

      SELECT TO_NUMBER(SUBSTR(G.BASLANGICSAAT,0,2)),TO_NUMBER(SUBSTR(G.BITISSAAT,0,2))
      INTO ps_start1,ps_start2
      FROM CBS_INT_GENELGUV G
      WHERE
      G.PERSONID=ps_personid AND
      G.CHANNELCD=ps_channelcd AND
      G.SECIM1='3'; -- e?er logon olduktan sonra bana sms g?nder ise

        IF (TO_NUMBER(ps_start1) > TO_NUMBER(ps_start2)) THEN
          ps_start2:=ps_start2+24;
        END IF;

        IF (((TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))) >= TO_NUMBER(ps_start1)) AND ((TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))) < TO_NUMBER(ps_start2))) THEN
         ls_returncode:=Pkg_Int_Limit.SendHatasizSmsMessage(ps_customerid,TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI') ||' tarihinde internet bankaciligi hesabiniza giris yapilmistir. Bilginize.'  ,tmp);
        END IF;

      END IF;
      RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
 END;
-----------------------------------------------------------------------
FUNCTION GetMusteriGenelGuvenlikInfo( ps_personid IN VARCHAR2,
                     ps_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
             ls_returncode         VARCHAR2(3):='000';
             ls_count NUMBER:=0;
 BEGIN

    OPEN PC_REF FOR
    SELECT G.SECIM1,G.SECIM2,G.BASLANGICSAAT,G.BITISSAAT
    FROM CBS_INT_GENELGUV G
    WHERE G.PERSONID = ps_personid AND
    G.CHANNELCD = ps_channelcd;

    RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
 END;
---------------------------------------------------------------------
FUNCTION CheckSmsSifreGereklimi( ps_personid IN VARCHAR2,
                     ps_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

            ls_returncode         VARCHAR2(3):='000';
            ls_count NUMBER:=0;
            ps_start1 VARCHAR2(5);
            ps_start2 VARCHAR2(5);

 BEGIN

    OPEN PC_REF FOR
    SELECT SYSDATE FROM DUAL;

      SELECT COUNT(*)
      INTO ls_count
      FROM CBS_INT_GENELGUV G
      WHERE
      G.PERSONID=ps_personid AND
      G.CHANNELCD=ps_channelcd AND
      G.SECIM1='2'; -- e?er logon olmadan ?nce bana sms ile mesaj g?nder ise


      IF (ls_count > 0) THEN

      SELECT TO_NUMBER(SUBSTR(G.BASLANGICSAAT,0,2)),TO_NUMBER(SUBSTR(G.BITISSAAT,0,2))
      INTO ps_start1,ps_start2
      FROM CBS_INT_GENELGUV G
      WHERE
      G.PERSONID=ps_personid AND
      G.CHANNELCD=ps_channelcd AND
      G.SECIM1='2'; --

        IF (TO_NUMBER(ps_start1) > TO_NUMBER(ps_start2)) THEN
          ps_start2:=ps_start2+24;
        END IF;

        IF (((TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))) >= TO_NUMBER(ps_start1)) AND ((TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))) < TO_NUMBER(ps_start2))) THEN
         ls_returncode:='111';
        END IF;

      END IF;

    RETURN ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
        ls_returncode:='999';
        RETURN ls_returncode;
 END;
----------------------
FUNCTION GetBranchCodes(ps_langcd IN VARCHAR2,ps_bankcd IN VARCHAR2,ps_citycd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

  OPEN pc_ref FOR
    --select lpad(s.sube_kodu,3,'0'), s.sube_adi, i.il_kodu, i.il_adi
    SELECT s.sube_kodu, s.sube_adi, i.il_kodu, i.il_adi
    FROM CBS_BANKA_SUBE_KODLARI s,
         CBS_IL_KODLARI i,
         CBS_BANKA_KODLARI b
    WHERE b.banka_tcmb_kodu = LPAD(ps_bankcd,3,'0')
    AND s.banka_kodu = b.banka_kodu
    AND s.il_kodu = NVL(LPAD(ps_citycd,3,'0'), s.il_kodu)
    AND s.il_kodu = i.il_kodu
    AND s.kapanma_tarihi IS NULL
    ORDER BY s.sube_adi;

   RETURN ls_returncode;
 END;
------------------------------
FUNCTION UpdateCustomer(ps_custno  IN VARCHAR2,
                         ps_adres   IN VARCHAR2,
                         ps_zip     IN VARCHAR2,
                         ps_mphone1 IN VARCHAR2,
                         ps_mphone2 IN VARCHAR2,
                         ps_hphone1 IN VARCHAR2,
                         ps_hphone2 IN VARCHAR2,
                         ps_email   IN VARCHAR2,
                         ps_country IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;
BEGIN
  UPDATE CBS_MUSTERI_ADRES
  SET  gsm_alan_kod = ps_mphone1,
         gsm_no = ps_mphone2,
         tel_alan_kod = ps_hphone1,
         tel_no  = ps_hphone2,
         email = ps_email
WHERE musteri_no = ps_custno ;

  OPEN pc_ref FOR
  SELECT 'OK'
  FROM dual;
  RETURN ls_returncode;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN '025';
END;
---------------------------------------------------------------------------------------------
FUNCTION SendEmailMessage(ps_SENDER  IN VARCHAR2,
                        ps_RECIPIENT  IN VARCHAR2,
                        ps_SUBJECT  IN VARCHAR2,
                        ps_BODY_CONTENT IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;

BEGIN
     Pkg_Int_Email.SENDHTMLEMAIL (ps_SENDER,ps_RECIPIENT,ps_SUBJECT,ps_BODY_CONTENT);

     OPEN pc_ref FOR SELECT 'OK' FROM dual;

       RETURN ls_returncode;
END;

------------------------------------------------------------------------
FUNCTION SendEmailMessageToQueue(ps_MESSAGE_CODE  IN VARCHAR2,
                        ps_SENDER  IN VARCHAR2,
                        ps_RECIPIENT  IN VARCHAR2,
                        ps_SUBJECT  IN VARCHAR2,
                        ps_BODY_CONTENT IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000'; 
BEGIN
     Pkg_Int_Email.SendHTMLEmailToQueue (ps_MESSAGE_CODE,ps_SENDER,ps_RECIPIENT,ps_SUBJECT,ps_BODY_CONTENT);

     OPEN pc_ref FOR SELECT 'OK' FROM dual;

      
     RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------------------
FUNCTION GetNonResidentDetail(pn_customerno IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2

        IS
        ls_returncode VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR

    SELECT TO_CHAR(MATURITY_DATE,'YYYYMMDD'), AMOUNT, '', FROM_ACCOUNT, Pkg_Hesap.HesapKisaIsimAl(FROM_ACCOUNT), TO_ACCOUNT_NUMBER, TO_NAME, YARATAN_TX_NO
    FROM CBS_VW_CLEARING
    WHERE pn_customerno=Pkg_Hesap.GetMusteriNoFromExternal(TO_ACCOUNT_NUMBER)
-- the following two lines comes from KZ version, hence commented out
--    and DEFINITE_TYPE='N2R'
--    and NR2R_STATUS='sTR'
    ORDER BY MATURITY_DATE;


    RETURN ls_returncode;

END;
---------------------------------------------------------------------------------------------------
FUNCTION IntCalculateParity(ps_fromaccount IN VARCHAR2,
                               ps_toaccount IN VARCHAR2) RETURN NUMBER IS

 BEGIN

  IF ( Pkg_Kur_Rezervasyon.sf_base_doviz_hangisi(ps_fromaccount,ps_toaccount) = ps_fromaccount) THEN
  RETURN ROUND(Pkg_Kur_Rezervasyon.CalculateParity(ps_fromaccount,ps_toaccount,'A'),5);
  ELSE
  RETURN ROUND(Pkg_Kur_Rezervasyon.CalculateParity(ps_fromaccount,ps_toaccount,'S'),5);
  END IF;
 END;
------------------------------------------------------------------------------------------------------
FUNCTION GetCommission(ps_TranCd     IN VARCHAR2,
                       pn_FromAccNo  IN VARCHAR2,
                       pn_ToAccNo    IN VARCHAR2,
                       pn_Amount     IN VARCHAR2,
                       ps_CurrCd     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;
    ln_islem_no NUMBER;
    ln_islem_kod NUMBER;
    ls_modul_tur_kod VARCHAR2(20);
    ls_urun_tur_kod VARCHAR2(20);
    ls_urun_sinif_kod VARCHAR2(20);
    ln_fromaccno NUMBER:=TO_NUMBER(pn_FromAccNo);
    ln_toaccno NUMBER:=Pkg_Hesap.GetHesapNoFromExternal(pn_ToAccNo,ps_CurrCd);
    ln_tutar NUMBER:=TO_NUMBER(LTRIM(pn_Amount,'0'),'999999999999999.9999');
    ls_bolum_kodu VARCHAR2(3):=Pkg_Hesap.hesapsubeal(ln_fromaccno);
    ln_musteri_no NUMBER:=Pkg_Hesap.hesaptanmusterinoal(ln_fromaccno);
    ls_kasa_kod NUMBER;
    ln_commission NUMBER;
    ln_tax_rate NUMBER;

BEGIN
    ln_islem_no:=Pkg_Tx.islem_no_al;

    IF ps_TranCd='CLEARING' THEN
       ln_islem_kod:=3555;
       ls_modul_tur_kod:='CLEARING';
       ls_urun_tur_kod:='OUTGOING';
       ls_urun_sinif_kod:='CIBCLEARING';
    --B-O-M ernestk 14022014 cqdb00000504-clearing gross payments
    ELSIF ps_TranCd='GROSS' THEN
       ln_islem_kod     :=3555;
       ls_modul_tur_kod :='CLEARING';
       ls_urun_tur_kod  :='OUTGOING';
       ls_urun_sinif_kod:='CIBGROSS';
    --E-O-M ernestk 14022014 cqdb00000504-clearing gross payments
    ELSIF ps_TranCd='B2OBHVL' THEN
       Pkg_Tx1203.sp_urun_tur_sinif_al(ln_fromaccno,
                                         ln_toaccno,
                                        ps_CurrCd,
                                        'E',
                                       ls_modul_tur_kod,
                                        ls_urun_tur_kod,
                                        ls_urun_sinif_kod);
       ln_islem_kod:='1203';
    END IF;

       ln_commission:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no,
                                                     ln_islem_kod,
                                                  ls_modul_tur_kod,
                                                  ls_urun_tur_kod,
                                                  ls_urun_sinif_kod,
                                                     ln_tutar,
                                                  ls_bolum_kodu,
                                                  ps_CurrCd,
                                                  ln_musteri_no,
                                                  ln_fromaccno,
                                                  ls_kasa_kod);
       BEGIN
           SELECT TO_NUMBER(REPLACE(DEGER,'.',',')) INTO ln_tax_rate
           FROM cbs_parametre
           WHERE kod='G_SALES_TAX_RATE'
           AND ROWNUM=1;
       EXCEPTION
           WHEN OTHERS THEN
               BEGIN
                   SELECT TO_NUMBER(REPLACE(DEGER,',','.')) INTO ln_tax_rate
                   FROM cbs_parametre
                   WHERE kod='G_SALES_TAX_RATE'
                   AND ROWNUM=1;
               EXCEPTION
                   WHEN OTHERS THEN
                       ln_tax_rate:=0;
               END;
       END;

       OPEN pc_ref FOR SELECT ln_commission, ln_tax_rate, TO_NUMBER(ln_commission)*ln_tax_rate/100 FROM dual;

       RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        Log_At('GetCommission',SQLERRM,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
------------------------------------------------------------------------------------------------------
FUNCTION GetBankName(pn_bankbic IN VARCHAR2) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(2000);
  BEGIN

    SELECT BANKA_KODU||' - '||BANKA_ADI
    INTO ls_returncode
    FROM CBS_BANKA_KODLARI
    WHERE BANKA_KODU=TO_NUMBER(pn_bankbic)
    ORDER BY BANKA_KODU;
   RETURN ls_returncode;
 END;
 -------------------------------------------------------------------------------------------------------
 /******************************************************************************
   NAME       : JoinAccountType
   Created By : Esen Omurchiev
   Date          : 25.11.2021
   Purpose      :Join Account Type Informations are returned
******************************************************************************/
FUNCTION GetJoinAccount(ps_heasap_no VARCHAR2) RETURN VARCHAR2
IS
ls_ortaklik_tipi VARCHAR2(50);
BEGIN

    SELECT ORTAKLIK_TIPI into ls_ortaklik_tipi from CBS_HESAP_ORTAK_BILGI 
    
    WHERE  ANA_HESAP_NO = ps_heasap_no AND STATUS = 'ACTIVE';

  RETURN ls_ortaklik_tipi;
EXCEPTION
    WHEN TOO_MANY_ROWS  then
        --Log_At('Pkg_INT.GetJoinAccountType', 'TOO_MANY_ROWS', SQLERRM);
        RETURN 'OY';
    WHEN NO_DATA_FOUND THEN
        Log_At('Pkg_INT.GetJoinAccountType', 'NO_DATA_FOUND', SQLERRM);
        RETURN 'NOT';
   
    WHEN OTHERS THEN
        Log_At('Pkg_INT.GetJoinAccountType', 'OTHERS', SQLERRM);
        RETURN 'NOT';
END;


FUNCTION GetJoinAccountType(ps_heasap_no VARCHAR2, ps_musteri_tipi_kod VARCHAR2) RETURN VARCHAR2
IS
ls_ortaklik_tipi VARCHAR2(4);
ls_return VARCHAR(6);
BEGIN


    ls_ortaklik_tipi := GetJoinAccount(ps_heasap_no);

    
    IF ls_ortaklik_tipi = 'OY' OR ls_ortaklik_tipi = 'OX' THEN
        
       ls_return := 'JOINT';
    
    ELSE 
   
       ls_return := 'SINGLE';
      
       IF ps_musteri_tipi_kod = '2' THEN 
        
          ls_return := 'PE';
         
       END IF;
      
    END IF; 

  RETURN ls_return;
  
EXCEPTION
    WHEN OTHERS THEN
        Log_At('Pkg_INT.GetJoinAccountType', 'OTHERS', SQLERRM);
        RETURN null;
END;

END;
/

