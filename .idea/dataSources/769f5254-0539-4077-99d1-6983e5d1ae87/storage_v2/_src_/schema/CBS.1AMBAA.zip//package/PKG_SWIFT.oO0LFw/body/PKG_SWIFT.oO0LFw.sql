create PACKAGE BODY     "PKG_SWIFT" IS

----------------------------------------------------------------------------------------------
FUNCTION GetMubabirAccountNo(ps_currcode IN VARCHAR2) RETURN NUMBER IS
           ln_account                          NUMBER;
BEGIN
     SELECT ACCOUNT_NO
     INTO ln_account
     FROM CBS_INT_MUHABIR_ACCOUNT
     WHERE CURRENCY_CODE=ps_currcode;

     RETURN ln_account;
END;
----------------------------------------------------------------------------------------------
FUNCTION GetMubabirBICCode(pn_customer_no IN NUMBER) RETURN VARCHAR2 IS
      ls_biccode                          VARCHAR2(11);
BEGIN
log_at('bug011', ls_biccode);
     SELECT BIC_KOD
     INTO ls_biccode
     FROM CBS_MUSTERI
     WHERE MUSTERI_NO=pn_customer_no;
log_at('bug012', ls_biccode);
     RETURN  ls_biccode;
END;
----------------------------------------------------------------------------------------------



  PROCEDURE open_cur_hata(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
  BEGIN
    OPEN cur_hata(pn_islem_no ,ps_mesaj_tipi ,pn_kayit_no , pn_islem_kod );
  END;

/* --------------------------------------------------------------------------------------------------- */


  PROCEDURE fetch_cur_hata(row_hata OUT cur_hata%ROWTYPE, ls_ok OUT VARCHAR2) IS
  BEGIN
    FETCH cur_hata INTO row_hata;
    IF cur_hata%NOTFOUND THEN
       ls_ok := 'H';
    ELSE
       ls_ok := 'E';
    END IF;
  END;
/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE close_cur_hata IS
  BEGIN
    CLOSE cur_hata;
  END;
/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE open_cur_blklist(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
  BEGIN
    OPEN cur_blklist(pn_islem_no ,ps_mesaj_tipi ,pn_kayit_no , pn_islem_kod );
  END;

/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE fetch_cur_blklist(row_blklist OUT cur_blklist%ROWTYPE, ls_ok OUT VARCHAR2) IS
  BEGIN
    FETCH cur_blklist INTO row_blklist;
    IF cur_blklist%NOTFOUND THEN
       ls_ok := 'H';
    ELSE
       ls_ok := 'E';
    END IF;
  END;
/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE close_cur_blklist IS
  BEGIN
    CLOSE cur_blklist;
  END;
/* --------------------------------------------------------------------------------------------------- */

  PROCEDURE open_cur_hatasiz(pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2,pn_kayit_no NUMBER, pn_islem_kod NUMBER) IS
  BEGIN
    OPEN cur_hatasiz(pn_islem_no ,ps_mesaj_tipi ,pn_kayit_no , pn_islem_kod );
  END;

/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE fetch_cur_hatasiz(row_hatasiz OUT cur_hatasiz%ROWTYPE, ls_ok OUT VARCHAR2) IS
  BEGIN
    FETCH cur_hatasiz INTO row_hatasiz;
    IF cur_hatasiz%NOTFOUND THEN
       ls_ok := 'H';
    ELSE
       ls_ok := 'E';
    END IF;
  END;
/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE close_cur_hatasiz IS
  BEGIN
    CLOSE cur_hatasiz;
  END;
/* --------------------------------------------------------------------------------------------------- */
  FUNCTION  sf_kayit_numarasi_al  RETURN NUMBER IS
  PRAGMA autonomous_transaction;
  ln_ret_val NUMBER;
  CURSOR cur_genel_kod IS
    SELECT * FROM swtrecno_cbs
    FOR UPDATE;
  row_genel_kod cur_genel_kod%ROWTYPE;

  BEGIN
      OPEN cur_genel_kod;
    FETCH cur_genel_kod INTO row_genel_kod;
    IF  cur_genel_kod%NOTFOUND THEN
      CLOSE cur_genel_kod;
      ln_ret_val := 3000000001;
      INSERT INTO swtrecno_cbs
                  (recno, son_kod_alan, son_tarih)
           VALUES (ln_ret_val, USER, SYSDATE);
     ELSE
       ln_ret_val := row_genel_kod.recno + 1;
       UPDATE swtrecno_cbs
         SET recno = ln_ret_val,
             son_kod_alan = USER,
             son_tarih = SYSDATE
        WHERE CURRENT OF cur_genel_kod;
       CLOSE cur_genel_kod;
     END IF;
 COMMIT;
     RETURN(ln_ret_val );
  END SF_KAYIT_NUMARASI_AL ;
--**********************************************
 FUNCTION SF_KAYIT_NO(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER
 IS
  ln_numara NUMBER;
 BEGIN

/*       SELECT  SASRN
      INTO      ln_numara
      FROM    SWTTRNPF
      WHERE   tx_no = pn_islemno
      AND       STYPE = ps_mesaj_tipi
      AND     ssts NOT IN ('CANCL');
*/ -- Yeni duzenlemeden dolayi kaldirdim. GC - 29.02.2008

      SELECT SWIFT_NO
        INTO     ln_numara
      FROM   CBS_SWIFT_ISLEM_TURU_MAP
      WHERE  tx_no         = pn_islemno
      AND    mesaj_tipi = ps_mesaj_tipi
      AND    SWIFT_NO IN (  SELECT  SASRN
                            FROM    SWTTRNPF
                            WHERE   tx_no = pn_islemno
                            AND     ssts NOT IN ('CANCL'));


  RETURN ln_numara;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ln_numara  := 0 ;
       RETURN ln_numara;
   WHEN OTHERS THEN

   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_KAYIT_NO;

--**********************************************

 FUNCTION SF_ISLEM_KAYDEDILDI_MI(pn_islem_kod NUMBER,pn_islemno NUMBER) RETURN VARCHAR2
 IS
  ln_ret NUMBER;
  ls_sql VARCHAR2(2000);
  ls_tablo_adi VARCHAR2(2000);
 BEGIN
     SELECT DISTINCT VALOR_TABLE_NAME
     INTO   ls_tablo_adi
     FROM   CBS_SWIFT_MESAJ_HEADER_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod;

     ls_sql := ' Select count(*) From ' || ls_tablo_adi ||
                    ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(ls_tablo_adi) || ' = ' || pn_islemno ;


    BEGIN
        EXECUTE IMMEDIATE  ls_sql INTO  ln_ret ;

        EXCEPTION
        WHEN NO_DATA_FOUND THEN
        ln_ret := 0;
        WHEN OTHERS THEN
        ln_ret := 0;

    END ;

    IF ln_ret = 0 THEN
      RETURN 'H';
    ELSE
      RETURN 'E';
    END IF;

 END SF_ISLEM_KAYDEDILDI_MI;

--**********************************************
  PROCEDURE MESAJ_OLUSTUR (     pn_islem_kod NUMBER,
                                 pn_islem_no NUMBER ,
                             ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                             ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL,
                              ps_cevap          OUT VARCHAR2
                             )IS

    ln_i         NUMBER := 1;
    ln_t         NUMBER := 1;
    ls_mesaj    VARCHAR(2000);
    ls_cevap    VARCHAR(2000) := 'SKYACK';
    ls_old_value VARCHAR(40);
    ls_nls_log VARCHAR(40);
    ls_sql VARCHAR2(2000);

    TYPE lrec_cevap IS RECORD  ( sirano   NUMBER :=1,deger    VARCHAR2(2000) := NULL);
    TYPE Cevaptype IS TABLE OF lrec_cevap
    INDEX BY     BINARY_INTEGER;
    Cevap_tab Cevaptype;

  BEGIN
log_at('bug181010', ps_cevap);
  SELECT VALUE
  INTO ls_old_value
  FROM NLS_SESSION_PARAMETERS
  WHERE parameter='NLS_NUMERIC_CHARACTERS';
log_at('bug181011', ps_cevap);
  dbms_session.set_nls('nls_date_format','''DD/MM/YYYY''');
  dbms_session.set_nls('nls_numeric_characters',''',.''');
        WHILE ln_i <=5 LOOP
        IF    ln_i = 1 THEN
            ls_mesaj := ps_mesaj_tipi_1 ;
        ELSIF ln_i = 2 THEN
            ls_mesaj := ps_mesaj_tipi_2 ;
        ELSIF ln_i = 3 THEN
            ls_mesaj := ps_mesaj_tipi_3 ;
        ELSIF ln_i = 4 THEN
            ls_mesaj := ps_mesaj_tipi_4 ;
        ELSIF ln_i = 5 THEN
            ls_mesaj := ps_mesaj_tipi_5 ;
        END IF;

        IF ls_mesaj IS NULL THEN
           ln_t := ln_i-1 ;
           ln_i := 6 ;
        END IF;
log_at('bug181012', ps_cevap);
        IF ln_i <=5 THEN
        log_at('bugCheck', pn_islem_kod || ' ' || pn_islem_no || ' ' || ls_mesaj || ' ' || ps_black_list_kontrol);
            Pkg_Swift.SP_MESAJ_HEADER_KAYDI_YARAT(pn_islem_kod,pn_islem_no,ls_mesaj,ps_black_list_kontrol);
            Pkg_Swift.SP_MESAJ_DETAY_KAYDI_YARAT(pn_islem_kod,pn_islem_no,ls_mesaj);
            --NurmilaZ 20062022 for test
--           ls_cevap := Pkg_Swift.SF_DRAFT(pn_islem_no,ls_mesaj);

              Cevap_tab(ln_i).deger := ls_cevap;
        END IF;
        ln_i :=ln_i+1;
        END LOOP;
log_at('bug181013', ps_cevap);
      dbms_session.set_nls('nls_numeric_characters',''''||ls_old_value||'''');
      ln_i := 1;
        WHILE ln_i <=ln_t LOOP
          IF Cevap_tab(ln_i).deger <> 'SKYACK' THEN
           ps_cevap    := Cevap_tab(ln_i).deger ; --Bir tane bile skynack varsa cik.

           ln_i := 6 ;
        ELSE
           ps_cevap    := 'SKYACK' ;
        END IF;

        ln_i :=ln_i+1;
        END LOOP;
        log_at('bug181014', ps_cevap);
  EXCEPTION
       WHEN OTHERS THEN
           log_at('bug181015', ps_cevap, dbms_utility.format_error_backtrace);
           dbms_session.set_nls('nls_numeric_characters',''''||ls_old_value||'''');
           ls_sql := SQLERRM;
           RAISE_APPLICATION_ERROR(-20000,SQLERRM);
  END MESAJ_OLUSTUR;
--**********************************************
 PROCEDURE SP_MESAJ_HEADER_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2,ps_black_list VARCHAR2)

 IS
 ls_sql VARCHAR2(2000);
    ls_table_name  VARCHAR2(2000);
    ls_valor       VARCHAR2(2000);
    ls_doviz       VARCHAR2(2000);
    ls_tutar       VARCHAR2(2000);
    ls_bic         VARCHAR2(2000);
    ls_20          VARCHAR2(2000);
    ls_21             VARCHAR2(2000);
    ln_kayit_no    LONG;
    ls_mesaj_tipi  VARCHAR2(2000);
    ls_dvz           VARCHAR2(3);

     PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
     ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_mesaj_tipi) ;

    ln_kayit_no := Pkg_Swift.SF_KAYIT_NUMARASI_AL;

    ls_dvz := Pkg_Swift.sf_doviz(pn_islem_kod,pn_islemno,ps_mesaj_tipi);

    IF ls_dvz = 'RUB'
    THEN
          -- SWTTRNPF Tablosuna mesajin header kaydi yazilir
         INSERT INTO SWTTRNPF
                     (SADAT     , SASRN     , SIO       , STYPE      , SNAME     , SCUR     , SAMNT     , SVADAT     ,
                     SSNDR     , SRCVR     , SSUBE   , SDEPT       , SSTS     , SDEL     , SPRIO     , SCRPRF     ,
                     SCRDAT     , SCRTIM     , SRELREF , STRANSREF , TX_NO   , BLFLAG)
         VALUES (    TO_NUMBER( TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul ,'YYYYMMDD')),  --SADAT
                     ln_kayit_no,  --SASRN
                     1    ,  --SIO
                     ls_mesaj_tipi , --STYPE
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.SF_MESAJ_ACIKLAMASI_AL(ls_mesaj_tipi)),1,35) , --SNAME
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.sf_doviz(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35), --SCUR
                     Pkg_Swift.sf_tutar(pn_islem_kod,pn_islemno,ps_mesaj_tipi) , --SAMNT
                     Pkg_Swift.sf_valor(pn_islem_kod,pn_islemno,ps_mesaj_tipi)     , --SVADAT
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.SF_BIC_KODU),1,35)     , --SSNDR
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.sf_BIC(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35) , --SRCVR
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.SF_SUBE),1,35)     , --SSUBE
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.SF_DEPARTMAN),1,35)     , --SDEPT
                     'DRAFT' , --SSTS
                     Pkg_Swift.SF_DELIVERY , --SDEL
                     Pkg_Swift.SF_PRIORTY  , --SPRIO
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.SF_KULLANICI),1,35) , --SCRPRF
                     TO_NUMBER(TO_CHAR(SYSDATE ,'YYYYMMDD') )     , --SCRDAT
                     TO_NUMBER(REPLACE(TO_CHAR(SYSDATE,'hh24:mi:ss'),':'))     , --SCRTIM
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.sf_21(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35) , --SRELREF
                     SUBSTR(pkg_report4.CYR2LAT_RUB(Pkg_Swift.sf_20(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35), --STRANSREF
                     pn_islemno, --TX_NO
                     ps_black_list); --BLFLAG
    ELSE  -- NOT RUB
          -- SWTTRNPF Tablosuna mesajin header kaydi yazilir
         INSERT INTO SWTTRNPF
                     (SADAT     , SASRN     , SIO       , STYPE      , SNAME     , SCUR     , SAMNT     , SVADAT     ,
                     SSNDR     , SRCVR     , SSUBE   , SDEPT       , SSTS     , SDEL     , SPRIO     , SCRPRF     ,
                     SCRDAT     , SCRTIM     , SRELREF , STRANSREF , TX_NO   , BLFLAG)
         VALUES (    TO_NUMBER( TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul ,'YYYYMMDD')),  --SADAT
                     ln_kayit_no,  --SASRN
                     1    ,  --SIO
                     ls_mesaj_tipi , --STYPE
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.SF_MESAJ_ACIKLAMASI_AL(ls_mesaj_tipi)),1,35) , --SNAME
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.sf_doviz(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35), --SCUR
                     Pkg_Swift.sf_tutar(pn_islem_kod,pn_islemno,ps_mesaj_tipi) , --SAMNT
                     Pkg_Swift.sf_valor(pn_islem_kod,pn_islemno,ps_mesaj_tipi)     , --SVADAT
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.SF_BIC_KODU),1,35)     , --SSNDR
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.sf_BIC(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35) , --SRCVR
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.SF_SUBE),1,35)     , --SSUBE
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.SF_DEPARTMAN),1,35)     , --SDEPT
                     'DRAFT' , --SSTS
                     Pkg_Swift.SF_DELIVERY , --SDEL
                     Pkg_Swift.SF_PRIORTY  , --SPRIO
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.SF_KULLANICI),1,35) , --SCRPRF
                     TO_NUMBER(TO_CHAR(SYSDATE ,'YYYYMMDD') )     , --SCRDAT
                     TO_NUMBER(REPLACE(TO_CHAR(SYSDATE,'hh24:mi:ss'),':'))     , --SCRTIM
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.sf_21(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35) , --SRELREF
                     SUBSTR(pkg_report4.CYR2LAT(Pkg_Swift.sf_20(pn_islem_kod,pn_islemno,ps_mesaj_tipi)),1,35), --STRANSREF
                     pn_islemno, --TX_NO
                     ps_black_list); --BLFLAG
    END IF;


     -- Mesaj tipini (ps_mesaj_tipi) donusturulmemis hali ile bu fonksiyona yolluyoruz.
     Pkg_Swift.Sp_Islem_Turu_Map_Kaydet(ln_kayit_no ,pn_islemno , ps_mesaj_tipi);

COMMIT;
 EXCEPTION
   WHEN OTHERS THEN

   ls_sql := SQLERRM;
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_MESAJ_HEADER_KAYDI_YARAT;


--**********************************************
 PROCEDURE SP_MESAJ_DETAY_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2)
 IS
  ls_sql  VARCHAR2(2000);
  ls_ret  VARCHAR2(2000);


     CURSOR c_cursor IS
     SELECT ISLEM_KOD, FLDTYP, FLDNAM, FLDIDX, FLDSNO, TABLE_NAME, FIELD
     FROM   CBS_SWIFT_MESAJ_DETAIL_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     FLDTYP     =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;
 PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
       -- islem koduna ait ilgili mesajdaki tum tablo ve field bilgilerini alir.
      -- Bu bilgilerden field'larin degerine ulasilir.
      -- SWTARAPF_CBS'e yazilir.

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;

            ls_sql := ' Select to_char(' || r_cursor.FIELD || ') From ' || r_cursor.TABLE_NAME ||
                              ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.TABLE_NAME) || ' = ' || pn_islemno ;


            BEGIN
                EXECUTE IMMEDIATE  ls_sql INTO  ls_ret ;

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                ls_ret := NULL;
                WHEN OTHERS THEN
                ls_ret := NULL;

            END ;
            Pkg_Swift.SP_DETAY_KAYDI_INSERT_ET(pn_islem_kod,
                                               pn_islemno,
                                                  ps_mesaj_tipi,
                                               r_cursor.FLDNAM,
                                                   r_cursor.FLDIDX ,
                                               r_cursor.FLDSNO,
                                               ls_ret ) ;
       END LOOP ;
       CLOSE c_cursor;

 COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_MESAJ_DETAY_KAYDI_YARAT;

--**********************************************
 PROCEDURE SP_MESAJ_RPT_DETAY_KAYDI_YARAT(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2)
 IS
     --repeat eden kayitli mesajlar icin kullanilir. 950 mesaji gibi

     CURSOR c_cursor IS
     SELECT ISLEM_KOD, FLDTYP, FLDNAM, FLDIDX, FLDSNO, TABLE_NAME, FIELD
     FROM   CBS_SWIFT_MESAJ_DETAIL_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     FLDTYP     =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;

     TYPE T_REFCUR IS REF CURSOR;
     pc_return_cursor  T_REFCUR ;
     ls_doviz_kodu VARCHAR2(3);

     ls_sql    VARCHAR2(2000);
     ls_ret    VARCHAR2(2000);
     ls_field  VARCHAR2(2000);
     ls_repeat VARCHAR2(1) := 'H';
     ln_count  NUMBER;
     ln_repeat NUMBER;
     ls_mesaj_tipi VARCHAR2(2000);

--B-O-M sevalb 01062011 Tekrarli mesajlarda ARARPTIDX
    ln_ARARPTIDX      NUMBER := 0;
    ln_max_rpt_id       NUMBER := 0;
    CURSOR cur_SWTARAPF_CBS  IS
    SELECT * FROM SWTARAPF_CBS
    WHERE arasrn =Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi) AND aratyp = ps_mesaj_tipi
        AND ARARPT = 1
    ORDER BY ARASRN,
        ARATYP    ,
        ARAIDX    ,
        ARAKOD    ,
        ARASNO
        FOR UPDATE OF ARARPTIDX;

    CURSOR cur2_SWTARAPF_CBS  IS
    SELECT * FROM SWTARAPF_CBS
    WHERE arasrn =Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi) AND aratyp = ps_mesaj_tipi
        AND  ARARPT >1
    ORDER BY ARASRN,
        ARATYP    ,
        ARARPT,
        ARAIDX    ,
        ARAKOD    ,
        ARASNO
        FOR UPDATE OF ARARPTIDX;

   CURSOR cur3_SWTARAPF_CBS  IS
    SELECT * FROM SWTARAPF_CBS
    WHERE arasrn =Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi) AND aratyp = ps_mesaj_tipi
        AND   araidx> ln_max_rpt_id AND  ARARPT =1
    ORDER BY ARASRN,
        ARATYP    ,
        ARAIDX    ,
        ARAKOD    ,
        ARASNO
        FOR UPDATE OF ARARPTIDX;
--E-O-M sevalb 01062011 Tekrarli mesajlarda ARARPTIDX


    PRAGMA AUTONOMOUS_TRANSACTION;

 BEGIN
       -- islem koduna ait ilgili mesajdaki tum tablo ve field bilgilerini alir.
      -- Bu bilgilerden field'larin degerine ulasilir.
      -- SWTARAPF_CBS'e yazilir.

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;

            SELECT COUNT(*)
            INTO   ln_count
            FROM   SWTFLDPF
            WHERE  FLDMTP = ps_mesaj_tipi
            AND    FLDNAM = r_cursor.FLDNAM
            AND    FLDIDX = r_cursor.FLDIDX
            AND    FLDSQBSNO IS NOT NULL;

            IF  ln_count = 0 THEN
                  ls_repeat := 'H';
            ELSE
                  ls_repeat := 'E';
            END IF;

            ls_sql := ' Select to_char(' || r_cursor.FIELD || ') From ' || r_cursor.TABLE_NAME ||
                              ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.TABLE_NAME) || ' = ' || pn_islemno ||
                      ' order by ' || Pkg_Swift.SF_TABLO_ORDERBY_ALAN_ADI_AL(r_cursor.TABLE_NAME) ;



            BEGIN


                 Pkg_Genel.Sp_Sql_Gonder_Ref_Cursor_Al(ls_sql, pc_return_cursor);

                 ln_repeat := 1;

                 LOOP
                   FETCH  pc_return_cursor INTO  ls_field;
                   EXIT WHEN  pc_return_cursor%NOTFOUND;

                  /* Pkg_Swift.SP_DETAY_KAYDI_INSERT_ET(pn_islemno,
                                                          ps_mesaj_tipi,
                                                       r_cursor.FLDNAM,
                                                           r_cursor.FLDIDX ,
                                                       r_cursor.FLDSNO,
                                                       ls_field,ln_repeat) ;*/
                    ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_mesaj_tipi) ;


                     -- SWTARAPF_CBS Tablosuna mesajin detay kaydi yazilir
                     INSERT INTO SWTARAPF_CBS(ARADAT, ARASRN, ARATYP, ARAIDX, ARAKOD, ARASNO, ARALEN,  ARATIP,ARAMO,
                                             ARAYAP, ARASOR, ARAACK, ARATXT,ARARPT)
                     SELECT  TO_NUMBER( TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul ,'YYYYMMDD') ),    Pkg_Swift.SF_KAYIT_NO(pn_islemno,ls_mesaj_tipi)  ,
                              FLDMTP, FLDIDX, FLDNAM, FLDSNO, FLDLEN, FLDTIP, FLDMO, FLDYAP,  FLDSOR, FLDTXT,
                            -- DECODE(FLDTXT,'YYMMDD',ls_field,ls_field ) --sevalb 23052011 kapatildi
                            SUBSTR(pkg_report4.CYR2LAT(ls_field),1,2000)--sevalb 23052011 eklendi
                             , ln_repeat
                     FROM    SWTFLDPF_CBS
                     WHERE   FLDMTP = ls_mesaj_tipi AND
                              FLDIDX = r_cursor.FLDIDX AND
                             FLDNAM = r_cursor.FLDNAM AND
                             FLDSNO = r_cursor.FLDSNO AND
                             FLDADT <>0 ;

                    IF ls_repeat ='E' THEN
                       ln_repeat := ln_repeat + 1 ;
                    END IF;
                 END LOOP;
                 CLOSE  pc_return_cursor;

             EXCEPTION
                WHEN NO_DATA_FOUND THEN
                log_At('SP_MESAJ_RPT_DETAY_KAYDI_YARAT HATA-NO_DATA_FOUND','pn_islem_kod:'||pn_islem_kod  ||',tx_no:'|| pn_islemno ||',ps_mesaj_tipi:' ||ps_mesaj_tipi ||' sql:'||ls_sql,SQLCODE,SQLERRM );
                ls_field := NULL;
                WHEN OTHERS THEN
                log_At('SP_MESAJ_RPT_DETAY_KAYDI_YARAT HATA-1','pn_islem_kod:'||pn_islem_kod  ||',tx_no:'|| pn_islemno ||',ps_mesaj_tipi:' ||ps_mesaj_tipi||' sql:'||ls_sql,SQLCODE,SQLERRM );
                ls_field := NULL;

            END ;
       END LOOP ;
       CLOSE c_cursor;

--B-O-M sevalb 01062011 Tekrarli mesajlarda ARARPTIDX  alani numaralandirilacak 61,86 alanlari bittikten sonra 2. 61,86 alanlari gelmeli.
    ln_ARARPTIDX    := 0;

        SELECT MAX(araidx)
        INTO ln_max_rpt_id
        FROM SWTARAPF_CBS
        WHERE arasrn =Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi)
               AND ARARPT > 1;

            FOR c_1 IN cur_SWTARAPF_CBS
            LOOP
                ln_ARARPTIDX := ln_ARARPTIDX +1 ;

                UPDATE SWTARAPF_CBS
                SET ARARPTIDX = ln_ARARPTIDX
                WHERE CURRENT OF cur_SWTARAPF_CBS;

            END LOOP;
           IF NVL(ln_max_rpt_id,0) <> 0 THEN
            FOR c_2 IN cur2_SWTARAPF_CBS
            LOOP

                ln_ARARPTIDX := ln_ARARPTIDX +1 ;


                UPDATE SWTARAPF_CBS
                SET ARARPTIDX = ln_ARARPTIDX
                WHERE CURRENT OF cur2_SWTARAPF_CBS;


            END LOOP;

            FOR c_3 IN cur3_SWTARAPF_CBS
            LOOP


                ln_ARARPTIDX := ln_ARARPTIDX +1 ;
                UPDATE SWTARAPF_CBS
                SET ARARPTIDX = ln_ARARPTIDX
                WHERE CURRENT OF cur3_SWTARAPF_CBS;


            END LOOP;
            END IF;

--E-O-M sevalb 01062011 Tekrarli mesajlarda
 COMMIT;
 EXCEPTION
   WHEN OTHERS THEN

    log_At('SP_MESAJ_RPT_DETAY_KAYDI_YARAT HATA-GENEL','pn_islem_kod:'||pn_islem_kod  ||',tx_no:'|| pn_islemno ||',ps_mesaj_tipi:' ||ps_mesaj_tipi,SQLCODE,SQLERRM );
    RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_MESAJ_RPT_DETAY_KAYDI_YARAT;

--**********************************************
 PROCEDURE SP_DETAY_KAYDI_INSERT_ET(  pn_islem_kod IN NUMBER,    -- islem kod
                                          pn_islem_no IN NUMBER,    -- islem numarasi
                                          ps_FLDMTP VARCHAR2,    -- 103,202 gibi mesaj tipleri
                                      ps_FLDNAM VARCHAR2,
                                          pn_FLDIDX NUMBER,
                                      pn_FLDSNO NUMBER,
                                      ps_FLDTXT  VARCHAR2,     -- alanin icerdigi bilgi
                                      pn_FLDRPT NUMBER DEFAULT 1 )--FLDRPT -- > 940,950 mesajdaki 60 sahasi gibi tekrarli sahalarda, kacinci tekrar oldugunu ifade eder.
 IS
   ls_count NUMBER;
   ls_mesaj_tipi  VARCHAR2(2000);
   ln_kayit_no       NUMBER;
    ls_dvz           VARCHAR2(3);

   PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN

    ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_FLDMTP) ;

    ln_kayit_no   := Pkg_Swift.SF_KAYIT_NO(pn_islem_no,ps_FLDMTP);

    ls_dvz := Pkg_Swift.sf_doviz(pn_islem_kod,pn_islem_no,ps_FLDMTP);


     -- SWTARAPF_CBS Tablosuna mesajin detay kaydi yazilir
    IF ls_dvz = 'RUB'
    THEN
     INSERT INTO SWTARAPF_CBS(ARADAT,
                                ARASRN,
                              ARATYP,
                              ARAIDX,
                              ARAKOD,
                              ARASNO,
                              ARALEN,
                              ARATIP,
                              ARAMO,
                                ARAYAP,
                              ARASOR,
                              ARAACK,
                              ARATXT,
                              ARARPT)
     SELECT  TO_NUMBER( TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul ,'YYYYMMDD') ),
             ln_kayit_no  , --Pkg_Swift.SF_KAYIT_NO(pn_islem_kod,ls_mesaj_tipi)  ,
              FLDMTP,
             FLDIDX,
             FLDNAM,
             FLDSNO,
             FLDLEN,
             FLDTIP,
             FLDMO,
             FLDYAP,
             FLDSOR,
             FLDTXT,
             DECODE(Pkg_Swift.Muafiyet(FLDMTP, FLDIDX, FLDNAM, FLDSNO),'E',ps_FLDTXT,'H',
             DECODE(FLDTXT,'YYMMDD',ps_FLDTXT,SUBSTR(pkg_report4.CYR2LAT_RUB(ps_FLDTXT),1,35))),
             pn_FLDRPT
     FROM    SWTFLDPF_CBS
     WHERE   FLDMTP = ls_mesaj_tipi AND
              FLDIDX = pn_FLDIDX AND
             FLDNAM = ps_FLDNAM AND
             FLDSNO = pn_FLDSNO AND
             ((FLDMTP = 320 AND  FLDADT >=0 ) OR  (FLDMTP <> 320 AND  FLDADT > 0 )  );
    ELSE
     INSERT INTO SWTARAPF_CBS(ARADAT, ARASRN, ARATYP, ARAIDX, ARAKOD, ARASNO, ARALEN,  ARATIP,ARAMO,
                             ARAYAP, ARASOR, ARAACK, ARATXT,ARARPT)
     SELECT  TO_NUMBER( TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul ,'YYYYMMDD') ),    ln_kayit_no  , --Pkg_Swift.SF_KAYIT_NO(pn_islem_kod,ls_mesaj_tipi)  ,
              FLDMTP, FLDIDX, FLDNAM, FLDSNO, FLDLEN, FLDTIP, FLDMO, FLDYAP,  FLDSOR, FLDTXT,
             DECODE(Pkg_Swift.Muafiyet(FLDMTP, FLDIDX, FLDNAM, FLDSNO),
                      'E',
                    ps_FLDTXT,
                    'H',
                    DECODE(FLDTXT,'YYMMDD',ps_FLDTXT,SUBSTR(pkg_report4.CYR2LAT(ps_FLDTXT),1,35))
                    )
             , pn_FLDRPT
     FROM    SWTFLDPF_CBS
     WHERE   FLDMTP = ls_mesaj_tipi AND
              FLDIDX = pn_FLDIDX AND
             FLDNAM = ps_FLDNAM AND
             FLDSNO = pn_FLDSNO AND
             ((FLDMTP = 320 AND  FLDADT >=0 ) OR  (FLDMTP <> 320 AND  FLDADT > 0 )  );
    END IF;
 COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_DETAY_KAYDI_INSERT_ET;


--**********************************************


 FUNCTION SF_MESAJ_GONDER(ps_text IN VARCHAR2) RETURN VARCHAR2
 IS
  conn utl_tcp.connection;
  ln_write     INTEGER;
  ls_data   VARCHAR2(2000);
 BEGIN
       log_at('bug181016n', ps_text, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      conn := utl_tcp.open_connection(swift_ip_al, swift_port_al);  -- open connection(cbilisimsvr)
       log_at('bug181018n', ps_text, swift_ip_al, swift_port_al);
      ln_write :=utl_tcp.write_line(conn,ps_text);
      BEGIN
        LOOP
          --sys.dbms_lock.sleep(1);
          ls_data := utl_tcp.get_line(conn, TRUE) ;
        END LOOP;
      EXCEPTION
        WHEN utl_tcp.end_of_input THEN
          NULL;
      END;
      utl_tcp.close_connection(conn);
      log_at('bug181019n', ps_text, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

  RETURN trim(ls_data);

 EXCEPTION
   WHEN OTHERS THEN
   log_at('bug181017n', ps_text, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_MESAJ_GONDER;
--**********************************************

 FUNCTION SF_DRAFT(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS

  ln_write      INTEGER;
  ls_msg     VARCHAR2(2000);
  ls_receive VARCHAR2(2000);
  ls_return  VARCHAR2(2000);
  ls_result  VARCHAR2(2000);
  ls_mesaj_tipi VARCHAR2(2000);
  ln_kayit_no NUMBER;
 BEGIN
     log_at('bug181020', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_mesaj_tipi) ;
      ln_kayit_no   := Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi);
      log_at('bug181020', 1);

      ls_msg := '<SWT value="' || ln_kayit_no || '" cmd="DRAFT"/>' ;

    --ls_msg := '<SWT value="' || Pkg_Swift.SF_KAYIT_NO(pn_islemno,ls_mesaj_tipi) || '" cmd="DRAFT"/>' ; -- yeni duzenlemeden dolayi kaldirdim. GC . 29.02.2008
     --  ls_msg := '<SWT value="' || pn_islemno || '" cmd="DRAFT"/>' ;
      ls_msg := LPAD(LENGTH(ls_msg),6,'0')||ls_msg ;
      log_at('bug181020', 2);
      ls_receive := Pkg_Swift.sf_mesaj_gonder(ls_msg) ;
      log_at('bug181020', 2);
      ls_result := Pkg_Swift.sf_parse_et_sonucu_al(ls_receive);
      log_at('bug181020', 2);
      ls_return := ls_result;

log_at('bug181020', 3);
      Sp_Hata_Log_Kaydet(pn_islemno,ln_kayit_no,ps_mesaj_tipi,ls_result,'DRAFT')  ; --sevalb  23022012 sdlc23773_AplicationShow errors in screen 4003 from SKYJAVA
log_at('bug181020', 4);
  RETURN ls_return;

 EXCEPTION
   WHEN OTHERS THEN
    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islemno,ln_kayit_no,ps_mesaj_tipi,ls_result,'DRAFT-ERROR'|| ' '||SQLCODE||SQLERRM)    ;
    RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_DRAFT;

--**********************************************
     FUNCTION SF_SEND(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS

  ln_write      INTEGER;
  ls_msg     VARCHAR2(2000);
  ls_receive VARCHAR2(2000);
  ls_return  VARCHAR2(2000);
  ls_result  VARCHAR2(2000);
  ls_statu   VARCHAR2(2000);
  ls_mesaj_tipi VARCHAR2(2000);
  ln_kayit_no    NUMBER;

 BEGIN
      ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_mesaj_tipi) ;
       ls_statu := Pkg_Swift.sf_mesaj_statu_al(pn_islemno,ps_mesaj_tipi) ;
--       ls_statu := Pkg_Swift.sf_mesaj_statu_al(pn_islemno,ls_mesaj_tipi) ;

      ln_kayit_no   := Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi);


      Pkg_Swift.SP_MESAJ_BLACKLISTFLAG_UPDATE(pn_islemno ,'1' ) ; -- Black list bulsa bile mesaji gondersin diye flagi 1 yap
      IF ls_statu = 'READY' THEN
           ls_msg := '<SWT value="' || ln_kayit_no || '" cmd="SEND"/>' ;
--           ls_msg := '<SWT value="' || Pkg_Swift.SF_KAYIT_NO(pn_islemno,ls_mesaj_tipi) || '" cmd="SEND"/>' ; -- Yeni duzenlemeden dolayi kaldirdim GC
          ls_msg := LPAD(LENGTH(ls_msg),6,'0')||ls_msg ;
           ls_receive := Pkg_Swift.sf_mesaj_gonder(ls_msg) ;
          ls_result := Pkg_Swift.sf_parse_et_sonucu_al(ls_receive);
          ls_return := ls_result;
      ELSE
            ls_return :=  'NOK';
      END IF;

    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islemno,ln_kayit_no,ps_mesaj_tipi,ls_result,'SEND'||'statu:'||ls_statu)  ;

  RETURN ls_return;

 EXCEPTION
   WHEN OTHERS THEN
   Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islemno,ln_kayit_no,ps_mesaj_tipi,ls_result,'SEND-ERROR'|| ' '||SQLCODE||SQLERRM)    ;
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_SEND;

--**********************************************

 FUNCTION SF_PARSE_ET_SONUCU_AL(ps_text IN VARCHAR2) RETURN VARCHAR2
 IS

  ls_msg     VARCHAR2(2000);
  ls_result  VARCHAR2(2000);
 BEGIN

      ls_msg := trim(ps_text);
      ls_result := Pkg_Dab.f_get_token (ls_msg , 'c');
      ls_msg := SUBSTR(ls_msg ,5,LENGTH(ls_msg)-7);

  RETURN ls_msg;

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_PARSE_ET_SONUCU_AL;

--**********************************************
 PROCEDURE SF_MESAJA_KARSI_GELEN_ALAN( pn_islem_kod NUMBER,
                                           pn_islemno NUMBER ,ps_mesaj_tipi  VARCHAR2,
                                         ps_table_name OUT VARCHAR2,
                                      ps_field_name OUT VARCHAR2,
                                      ps_datablock_name OUT VARCHAR2,
                                      ps_item_name OUT VARCHAR2)
 IS

 BEGIN

     SELECT TABLE_NAME, FIELD, DATABLOCK_NAME, ITEM_NAME
     INTO    ps_table_name,ps_field_name, ps_datablock_name,ps_item_name
     FROM   CBS_SWIFT_MESAJ_DETAIL_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     FLDTYP     =  ps_mesaj_tipi;


 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_MESAJA_KARSI_GELEN_ALAN;

--**********************************************
 PROCEDURE SP_HATALI_ALANI_BUL(pn_islem_kod NUMBER,
                                   pn_islemno IN NUMBER,ps_mesaj_tipi  VARCHAR2 DEFAULT NULL,
                                   pRetCur  IN OUT Generic_CurType)
 IS

 BEGIN
 -- Islemde hangi alanda hata alindigini, hatanin ne oldugunu ve aciklamasini doner
    OPEN    pRetCur FOR
    SELECT  b.FLDTYP mesaj_tipi,b.FLDIDX idx,b.FLDNAM NAME, b.FLDSNO  srno    ,
            b.DATABLOCK_NAME DATABLOCK, b.ITEM_NAME ITEM,a.ARAERR hata,
            Pkg_Swift.SF_HATA_ACIKLAMASI_AL(a.ARAERR) hata_aciklama
    FROM    SWTARAPF_CBS a, CBS_SWIFT_MESAJ_DETAIL_MAP b
    WHERE     b.islem_kod    = pn_islem_kod
    AND     Pkg_Swift.sf_mesaj_tipi_donustur(b.FLDTYP)= a.ARATYP
--    AND     b.FLDTYP    = ps_mesaj_tipi
    AND     b.FLDIDX      = a.ARAIDX
    AND     b.FLDNAM      = a.ARAKOD
    AND     b.FLDSNO      = a.ARASNO
    AND     ARAERR         IS NOT NULL
    AND     a.ARASRN IN (SELECT SASRN FROM SWTTRNPF WHERE TX_NO = pn_islemno AND  ssts NOT IN ('CANCL') );
    --AND     a.ARAERR     IN (SELECT MSGCODE FROM SWTERRCODE);


 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_HATALI_ALANI_BUL;

--**********************************************
 PROCEDURE SP_BLACK_LIST_ALANI_BUL(pn_islem_kod NUMBER,
                                       pn_islemno IN NUMBER,ps_mesaj_tipi  VARCHAR2 DEFAULT NULL,
                                       pRetCur  IN OUT Generic_CurType)
 IS

 BEGIN
 -- Islemde hangi alanda hata alindigini, hatanin ne oldugunu ve aciklamasini doner
    OPEN    pRetCur FOR
    SELECT  b.FLDTYP mesaj_tipi,b.FLDIDX idx,b.FLDNAM NAME,    b.FLDSNO  srno    ,
            b.DATABLOCK_NAME DATABLOCK, b.ITEM_NAME ITEM,ENT_NUM hata , SDN_NAME hata_aciklama
    FROM    SWTFNDBLC a, CBS_SWIFT_MESAJ_DETAIL_MAP b
    WHERE     b.islem_kod    = pn_islem_kod
    AND     Pkg_Swift.sf_mesaj_tipi_donustur(b.FLDTYP)      = a.MESSAGETYPE
--    AND     b.FLDTYP    = ps_mesaj_tipi
    AND     b.FLDIDX      = a.FIELDIDX
    AND     b.FLDNAM      = trim(a.FIELDNAME)
    AND     b.FLDSNO      = a.FIELDSNO
    AND     a.MESSAGENO IN (SELECT SASRN FROM SWTTRNPF WHERE TX_NO = pn_islemno AND  ssts NOT IN ('CANCL'));

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_BLACK_LIST_ALANI_BUL;

--**********************************************
 FUNCTION SF_MESAJ_STATU_AL(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS
  ls_statu   SWTTRNPF.SSTS%TYPE;
 BEGIN

       SELECT  SSTS
      INTO      ls_statu
      FROM    SWTTRNPF
      WHERE   SASRN   = Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi) ;

  RETURN ls_statu;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ls_statu := ' ' ;
       RETURN ls_statu;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_MESAJ_STATU_AL;

--**********************************************
 FUNCTION SF_HATA_ACIKLAMASI_AL(ps_hatano IN VARCHAR2) RETURN VARCHAR2
 IS
  ls_aciklama   SWTERRCODE.MSGEXP%TYPE;
 BEGIN

       SELECT  DISTINCT MSGEXP
      INTO      ls_aciklama
      FROM    SWTERRCODE
      WHERE   MSGCODE   = ps_hatano ;

  RETURN ls_aciklama;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          RETURN NULL ;
   WHEN OTHERS THEN
          RETURN NULL ;

 END sf_hata_aciklamasi_al;

--**********************************************

 PROCEDURE SP_MESAJ_STATU_UPDATE(pn_islemno IN NUMBER,ps_statu  SWTTRNPF.SSTS%TYPE ,ps_mesaj_tipi VARCHAR2 DEFAULT NULL )
 IS
 PRAGMA AUTONOMOUS_TRANSACTION;
 ln_kayit_no   NUMBER;
 BEGIN
    -- SADECE MESAJ_SIL FONKSIYONUNDAN ps_mesaj_tipi  NULL GELECEK

     IF ps_mesaj_tipi IS NOT NULL THEN
         ln_kayit_no   := Pkg_Swift.SF_KAYIT_NO(pn_islemno,ps_mesaj_tipi); -- Yeni ekledim. GC 03.03.2008
      ELSE
        ln_kayit_no   := NULL ;
     END IF;

      UPDATE  SWTTRNPF
     SET       SSTS   = ps_statu
     WHERE   tx_no  = pn_islemno
     AND     sasrn  = NVL(ln_kayit_no,sasrn)  -- Yeni ekledim. GC 03.03.2008
     AND     ssts NOT IN ('CANCL') ;

COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
    ROLLBACK;
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_MESAJ_STATU_UPDATE;

--**********************************************

 PROCEDURE SP_UPDATE_DRAFT(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL)
 IS
 BEGIN

     Pkg_Swift.sp_mesaj_statu_update(pn_islemno,'DRAFT',ps_mesaj_tipi) ;

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_UPDATE_DRAFT;

--**********************************************

 PROCEDURE SP_UPDATE_RED(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL)
 IS
 BEGIN
     --KULLANILMIYOR
     Pkg_Swift.sp_mesaj_statu_update(pn_islemno,'RED',ps_mesaj_tipi) ;

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_UPDATE_RED;

--**********************************************
 PROCEDURE SP_UPDATE_READY(pn_islemno IN NUMBER,ps_mesaj_tipi VARCHAR2  DEFAULT NULL)
 IS
 BEGIN
    --KULLANILMIYOR
     Pkg_Swift.sp_mesaj_statu_update(pn_islemno,'READY',ps_mesaj_tipi) ;

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_UPDATE_READY;

--**********************************************
 FUNCTION SF_MESAJ_ACIKLAMASI_AL(ps_mesaj IN VARCHAR2) RETURN VARCHAR2
 IS
  ls_aciklama   SWTMSGPF.MSGTNM%TYPE;
 BEGIN

       SELECT  SUBSTR(MSGTNM,1,2000)
      INTO      ls_aciklama
      FROM    SWTMSGPF
      WHERE   MSGKOD   = ps_mesaj ;

  RETURN ls_aciklama;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          RETURN NULL ;
   WHEN OTHERS THEN
   RETURN NULL;

 END SF_MESAJ_ACIKLAMASI_AL;

--**********************************************

 FUNCTION SF_BIC_KODU RETURN VARCHAR2
 IS

 BEGIN

  RETURN 'DEMIKG22XXX';

 END SF_BIC_KODU ;

--**********************************************

 FUNCTION SF_SUBE RETURN VARCHAR2
 IS
 BEGIN

  RETURN '010';

 END SF_SUBE ;

--**********************************************
 FUNCTION SF_DEPARTMAN RETURN VARCHAR2
 IS
 BEGIN

  RETURN 'OPS';

 END SF_DEPARTMAN ;

--**********************************************
 FUNCTION SF_DELIVERY RETURN VARCHAR2
 IS
 BEGIN

  RETURN 'N';

 END SF_DELIVERY ;

--**********************************************
 FUNCTION SF_PRIORTY RETURN VARCHAR2
 IS
 BEGIN

  RETURN NULL;

 END SF_PRIORTY ;

--**********************************************
 FUNCTION SF_KULLANICI RETURN VARCHAR2
 IS
 BEGIN

  RETURN 'ADMIN';

 END SF_KULLANICI ;

--**********************************************
 FUNCTION SF_UZUN_MESAJ_FORMATLA(ps_text IN VARCHAR2,pn_len IN NUMBER) RETURN VARCHAR2
 IS

  ls_msg   VARCHAR2(2000);
  ls_text  VARCHAR2(2000);
  ln_adet  NUMBER;
  ln_i     NUMBER;
  ln_t     NUMBER;
 BEGIN


       ln_adet := ROUND(LENGTH(ps_text) / pn_len) ;

      IF MOD(ln_adet,pn_len) = 0 THEN
           ln_adet := ln_adet-1 ;
      END IF;
    IF ln_adet <= 0 THEN
          ls_msg := '|' || ps_text || '|' ;
      RETURN trim(ls_msg);
    --  RETURN trim(ps_text);
    ELSE
          ln_t:=0;
          ls_msg := ' ';
        FOR ln_i IN 0..ln_adet LOOP
            IF ln_i <> 0 AND   SUBSTR(ps_text,ln_t+1,pn_len) IS NOT NULL THEN
                ls_text := '|' || SUBSTR(ps_text,ln_t+1,pn_len) ;
            ELSE
                ls_text     :=    SUBSTR(ps_text,ln_t+1,pn_len) ;
            END IF;
            ls_msg := ls_msg || ls_text ;
            ln_t :=  pn_len +ln_t ;

        END LOOP;
    END IF;

    ls_msg := '|' || ls_msg || '|' ;

  RETURN trim(ls_msg);

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_UZUN_MESAJ_FORMATLA;
--**********************************************

 FUNCTION SF_TABLO_ISLEM_ALAN_ADI_AL(ps_table_name IN VARCHAR2) RETURN VARCHAR2
 IS
  ls_name  CBS_SWIFT_TABLE_ISLEM_FIELD.ISLEM_FLD_NAME%TYPE;
 BEGIN

       SELECT  ISLEM_FLD_NAME
      INTO      ls_name
      FROM    CBS_SWIFT_TABLE_ISLEM_FIELD
      WHERE   TABLE_NAME   = ps_table_name ;

  RETURN ls_name;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          RETURN NULL ;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_TABLO_ISLEM_ALAN_ADI_AL;

--**********************************************
 FUNCTION  SF_TABLO_ORDERBY_ALAN_ADI_AL(ps_table_name IN VARCHAR2) RETURN VARCHAR2
 IS
  ls_name  CBS_SWIFT_TABLE_ISLEM_FIELD.ORDER_BY_FIELD%TYPE;
 BEGIN

       SELECT  ORDER_BY_FIELD
      INTO      ls_name
      FROM    CBS_SWIFT_TABLE_ISLEM_FIELD
      WHERE   TABLE_NAME   = ps_table_name ;

  RETURN ls_name;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          RETURN NULL ;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_TABLO_ORDERBY_ALAN_ADI_AL;

--**********************************************
 FUNCTION SF_VALOR(pn_islem_kod NUMBER,
                       pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER
 IS
  ls_sql  VARCHAR2(2000);
  ln_ret  NUMBER;
  ls_ret  VARCHAR2(2000);
     CURSOR c_cursor IS
     SELECT FLD_VALOR,VALOR_TABLE_NAME
     FROM   CBS_SWIFT_MESAJ_HEADER_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     MESAJ_TIPI =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;

 BEGIN

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;
             ls_sql := ' Select TO_NUMBER(TO_CHAR(' || r_cursor.FLD_VALOR || ',''YYYYMMDD'')) From ' || r_cursor.VALOR_TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.VALOR_TABLE_NAME) || ' = ' || pn_islemno ;

       END LOOP ;
       CLOSE c_cursor;

        BEGIN
            EXECUTE IMMEDIATE  ls_sql INTO  ln_ret ;

            EXCEPTION
            WHEN NO_DATA_FOUND THEN

            ln_ret := NULL;
            WHEN OTHERS THEN
            ln_ret := NULL;

        END ;
     RETURN ln_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ln_ret  := NULL ;
       RETURN ln_ret;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_VALOR;

--**********************************************
 FUNCTION SF_DOVIZ(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS
  ls_sql  VARCHAR2(2000);
  ls_ret  VARCHAR2(3);

     CURSOR c_cursor IS
     SELECT FLD_DOVIZ, DOVIZ_TABLE_NAME
     FROM   CBS_SWIFT_MESAJ_HEADER_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     MESAJ_TIPI =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;

 BEGIN

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;
             ls_sql := ' Select ' || r_cursor.FLD_DOVIZ || ' From ' || r_cursor.DOVIZ_TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.DOVIZ_TABLE_NAME) || ' = ' || pn_islemno ;

       END LOOP ;
       CLOSE c_cursor;

        BEGIN
            EXECUTE IMMEDIATE  ls_sql INTO  ls_ret ;

            EXCEPTION
            WHEN NO_DATA_FOUND THEN
            ls_ret := NULL;
            WHEN OTHERS THEN
            ls_ret := NULL;

        END ;
     RETURN ls_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ls_ret  := NULL ;
       RETURN ls_ret;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_DOVIZ;

--**********************************************
 FUNCTION SF_BIC(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS
  ls_sql  VARCHAR2(2000);
  ls_ret  VARCHAR2(12);

     CURSOR c_cursor IS
     SELECT FLD_BIC, BIC_TABLE_NAME
     FROM   CBS_SWIFT_MESAJ_HEADER_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     MESAJ_TIPI =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;

 BEGIN

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;

             ls_sql := ' Select ' || r_cursor.FLD_BIC || ' From ' || r_cursor.BIC_TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.BIC_TABLE_NAME) || ' = ' || pn_islemno ;

       END LOOP ;
       CLOSE c_cursor;

        BEGIN
            EXECUTE IMMEDIATE  ls_sql INTO  ls_ret ;
            EXCEPTION
            WHEN NO_DATA_FOUND THEN
                ls_ret := NULL;
            WHEN OTHERS THEN
            ls_ret := NULL;

        END ;
     RETURN ls_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ls_ret  := NULL;
       RETURN ls_ret;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_BIC;

--**********************************************
 FUNCTION SF_TUTAR(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN NUMBER
 IS
  ls_sql  VARCHAR2(2000);
  ln_ret  NUMBER;

     CURSOR c_cursor IS
     SELECT FLD_TUTAR,TUTAR_TABLE_NAME
     FROM   CBS_SWIFT_MESAJ_HEADER_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     MESAJ_TIPI =  ps_mesaj_tipi;

     r_cursor c_cursor%ROWTYPE;

 BEGIN

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;
             ls_sql := ' Select  ' || r_cursor.FLD_TUTAR || '  From ' || r_cursor.TUTAR_TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.TUTAR_TABLE_NAME) || ' = ' || pn_islemno ;

       END LOOP ;
       CLOSE c_cursor;

        BEGIN
            EXECUTE IMMEDIATE  ls_sql INTO  ln_ret ;

            EXCEPTION
            WHEN NO_DATA_FOUND THEN
            ln_ret :=0;
            WHEN OTHERS THEN
            ln_ret := 0;

        END ;
     RETURN ln_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ln_ret  := 0 ;
       RETURN ln_ret;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_TUTAR;

--**********************************************
 FUNCTION SF_20(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS
  ls_sql  VARCHAR2(2000);
  ls_ret  VARCHAR2(16);

     CURSOR c_cursor IS
     SELECT ISLEM_KOD, FLDTYP, FLDNAM,  TABLE_NAME, FIELD
     FROM   CBS_SWIFT_MESAJ_DETAIL_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     FLDTYP     =  ps_mesaj_tipi
     AND    FLDNAM       =  '20'
     AND    fldsno       <> 0 ;

     r_cursor c_cursor%ROWTYPE;

 BEGIN

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;
             ls_sql :=  'Select nvl(' || r_cursor.FIELD || ','' '') From ' || r_cursor.TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.TABLE_NAME) || ' = ' || pn_islemno ;

            BEGIN
                EXECUTE IMMEDIATE  ls_sql INTO  ls_ret ;

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                ls_ret := NULL;
                WHEN OTHERS THEN
                ls_ret := NULL;

            END ;

       END LOOP ;

       CLOSE c_cursor;

     RETURN ls_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ls_ret  := NULL ;
       RETURN ls_ret;
   WHEN OTHERS THEN

   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_20;

--**********************************************
 FUNCTION SF_21(pn_islem_kod NUMBER,pn_islemno NUMBER,ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
 IS
  ls_sql  VARCHAR2(2000);
  ls_ret  VARCHAR2(16);

     CURSOR c_cursor IS
     SELECT ISLEM_KOD, FLDTYP, FLDNAM,  TABLE_NAME, FIELD
     FROM   CBS_SWIFT_MESAJ_DETAIL_MAP
     WHERE  ISLEM_KOD  =  pn_islem_kod
     AND     FLDTYP     =  ps_mesaj_tipi
     AND    FLDNAM       =  '21'
     AND    fldsno       <> 0 ;

     r_cursor c_cursor%ROWTYPE;

 BEGIN
        ls_ret := ' ';

       OPEN c_cursor;
       LOOP
            FETCH c_cursor INTO r_cursor;
            EXIT WHEN c_cursor%NOTFOUND;
             ls_sql := ' Select nvl(' || r_cursor.FIELD || ','' '') From ' || r_cursor.TABLE_NAME ||
                 ' where '  || Pkg_Swift.SF_TABLO_ISLEM_ALAN_ADI_AL(r_cursor.TABLE_NAME) || ' = ' || pn_islemno ;

            BEGIN
                EXECUTE IMMEDIATE  ls_sql INTO  ls_ret ;

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                ls_ret := NULL;
                WHEN OTHERS THEN
                ls_ret := NULL;

            END ;

       END LOOP ;
       CLOSE c_cursor;


     RETURN ls_ret;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
          ls_ret  := NULL ;
       RETURN ls_ret;
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SF_21;


 FUNCTION Swift_kontrolu_yapilsin(pn_islem_kod NUMBER DEFAULT NULL) RETURN VARCHAR2
 IS
  ls_swift_kontrolu VARCHAR2(1) := 'H';

 BEGIN
      IF pn_islem_kod IS NOT NULL THEN
           SELECT SWIFT_MESAJI_GONDERILSIN_MI
         INTO     ls_swift_kontrolu
         FROM     CBS_ISLEM_TANIM
         WHERE  kod = pn_islem_kod ;
      END IF;

      RETURN ls_swift_kontrolu;
 END;
--**********************************************
 PROCEDURE SP_MESAJ_SIL(pn_islemno IN NUMBER )
 IS
  ln_kayit_no NUMBER;
    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
   relse_mesaj_var EXCEPTION;
   PRAGMA AUTONOMOUS_TRANSACTION;

   -- HANGI TIP MESAJ OLURSA OLSUN, BiR TANE BiLE RELSE MESAJ VARSA SILINEMEZ. BU FONK SADECE CBS_STD'den DOLAYI EKRANLARDAN CAGIRILIYOR

 BEGIN

      --- Burada mesaj tipinin ne oldugu ile iliglenmiyorum. BIr tane bile olmasi benim icin yeterli
      SELECT COUNT(*)
      INTO   ln_count
      FROM   (
                SELECT tx_no,stype,svadat,samnt,scur ,COUNT(*)
                FROM   swttrnpf
                WHERE  tx_no = pn_islemno
                AND    ssts = 'RELSE'
                GROUP BY tx_no,stype, svadat,samnt,scur
                HAVING COUNT(*) > 0
              )    ;
     IF ln_count > 0 THEN
         RAISE relse_mesaj_var;
     ELSE
          Pkg_Swift.sp_mesaj_statu_update(pn_islemno,'CANCL',NULL) ; -- Sadece buna ozel null gonderiyorum. O da  SP_MESAJ_SIL sadece ekrandan cagirildigi icin GC. 03.03.208
     END IF;
                --    DELETE FROM SWTARAPF_CBS
                --    WHERE ARASRN IN (SELECT SASRN FROM swttrnpf
                --                        WHERE tx_no = pn_islemno and ssts not in ('CANCL'));
                --    DELETE FROM swttrnpf
                --    WHERE tx_no = pn_islemno and  ssts not in ('CANCL');


                 --eski
                /*      IF  ln_kayit_no  <> 0 THEN
                          DELETE  FROM SWTARAPF_CBS
                         WHERE   ARASRN  = ln_kayit_no ;

                          DELETE  FROM SWTTRNPF
                         WHERE   SASRN   = ln_kayit_no ;

                     END IF;    */
COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
--   RAISE_APPLICATION_ERROR(-20000,SQLERRM);
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);
 END SP_MESAJ_SIL;
/********************Islem Sonrasi Koltroller***********************/
-----------------------------------------------------
  PROCEDURE Kontrol_Sonrasi (pn_islem_kod NUMBER,
                               pn_islem_no NUMBER ,
                             ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                             ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                             )IS

    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
    ln_i     NUMBER := 1 ;
    ls_mesaj VARCHAR2(2000);
    ln_sasrn NUMBER ; --sevalb 23022012
    ls_ssts   VARCHAR2(2000); --sevalb 23022012
    ls_kayit_status  VARCHAR2(2000); --sevalb 23022012
    ln_mesaj_tip_i  NUMBER;
  BEGIN
      ln_count := 0 ; ln_i := 1 ;
      ----------------------------------------------
      WHILE ln_i <=5 LOOP   -- Gonderilen mesaj tiplerinden daha once relse olmus olan var mi kontrolu
        IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
        ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
        ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
        ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
        ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
        END IF;

        IF ls_mesaj IS NOT NULL THEN
           IF Pkg_Swift.Relse_Mesaj_Varmi(pn_islem_no,ls_mesaj) = 'E' THEN -- Bir tane  bile bulursan izin verme
                 ls_kayit_status := Pkg_Swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
                 ln_sasrn   := Pkg_Swift.SF_KAYIT_NO(pn_islem_no,ls_mesaj); --sevalb 23022012
                 ls_ssts := Pkg_Swift.SF_MESAJ_SSTS_AL(ln_sasrn) ;   --sevalb 23022012
                 ln_mesaj_tip_i := ln_i;
                 ln_count := ln_count + 1 ;

           END IF;
        END IF;
       ln_i :=ln_i+1;
        END LOOP;
      ----------------------------------------------

     IF ln_count > 0 THEN
             Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'ERROR','Kontrol_Sonrasi-ERROR-5335' ||',ln_SASRN' ||ln_SASRN|| ',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count ||',ln_mesaj_tip_i:'||ln_mesaj_tip_i);
             RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);
     ELSE
           ln_i := 1;
          WHILE ln_i <=5 LOOP -- Daha once gonderilen mesajlar silinecek .Yenileri olusturulacak.
            IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
            ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
            ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
            ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
            ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
            END IF;

             ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
             ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ls_mesaj); --sevalb 23022012
             ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

            IF ls_mesaj IS NOT NULL THEN
               Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'CANCL','Kontrol_Sonrasi-UPDATE'|| ' ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count||',ln_i:'||ln_i  );
               Pkg_Swift.sp_mesaj_statu_update(pn_islem_no,'CANCL',ls_mesaj) ;
            END IF;
            ln_i :=ln_i+1;
            END LOOP;

          --Mesaji tekrar olustur
            Pkg_Swift.MESAJ_OLUSTUR(pn_islem_kod,pn_islem_no ,ps_black_list_kontrol,
                                    ps_mesaj_tipi_1 ,
                                  ps_mesaj_tipi_2 ,
                                  ps_mesaj_tipi_3 ,
                                  ps_mesaj_tipi_4 ,
                                  ps_mesaj_tipi_5 ,
                                  ls_cevap);
            ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ps_mesaj_tipi_1) ;   --sevalb 23022012
            ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ps_mesaj_tipi_1); --sevalb 23022012
            ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

          IF ls_cevap NOT IN  ('SKYACK','SKYBLCK') THEN --bilalg: SKYBLCK hatasInda mesaj tekrar olusturulsun
            Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'ERROR','Kontrol_Sonrasi-ERROR-4473'||' ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_cevap:' ||ls_cevap)  ;
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4473' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
          END IF;

      END IF;

    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'TAMAMLANDI','Kontrol_Sonrasi'||',ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_cevap:' ||ls_cevap)  ;
  END Kontrol_Sonrasi;
-----------------------------------------------------
  PROCEDURE Dogrulama_Sonrasi (pn_islem_kod NUMBER,
                                pn_islem_no NUMBER ,
                             ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                             ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                             ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                             )IS


    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
    ln_i     NUMBER :=1;
    ls_mesaj VARCHAR2(2000);

    ln_sasrn NUMBER ; --sevalb 23022012
    ls_ssts   VARCHAR2(2000); --sevalb 23022012
    ls_kayit_status  VARCHAR2(2000); --sevalb 23022012
    ln_mesaj_tip_i  NUMBER;
  BEGIN
      ln_count := 0 ;  ln_i := 1 ;
      ----------------------------------------------
      WHILE ln_i <=5 LOOP   -- Gonderilen mesaj tiplerinden daha once relse olmus olan var mi kontrolu
        IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
        ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
        ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
        ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
        ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
        END IF;

        IF ls_mesaj IS NOT NULL THEN
           IF Pkg_Swift.Relse_Mesaj_Varmi(pn_islem_no,ls_mesaj) = 'E' THEN -- Bir tane  bile bulursan izin verme
                 ls_kayit_status := Pkg_Swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
                 ln_sasrn   := Pkg_Swift.SF_KAYIT_NO(pn_islem_no,ls_mesaj); --sevalb 23022012
                 ls_ssts := Pkg_Swift.SF_MESAJ_SSTS_AL(ln_sasrn) ;   --sevalb 23022012
                 ln_mesaj_tip_i := ln_i;
                 ln_count := ln_count + 1 ;
           END IF;
        END IF;
         ln_i :=ln_i+1;
        END LOOP;
      ----------------------------------------------

     IF ln_count > 0 THEN
             Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'ERROR','Dogrulama_Sonrasi-ERROR-5335' ||',ln_SASRN' ||ln_SASRN|| ',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count ||',ln_mesaj_tip_i:'||ln_mesaj_tip_i);
             RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);

     ELSE
          ln_i := 1;
          WHILE ln_i <=5 LOOP -- Daha once gonderilen mesajlar silinecek .Yenileri olusturulacak.
            IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
            ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
            ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
            ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
            ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
            END IF;

             ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
             ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ls_mesaj); --sevalb 23022012
             ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

            IF ls_mesaj IS NOT NULL THEN
               Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'CANCL','Dogrulama_Sonrasi-UPDATE' ||',ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count||',ln_i:'||ln_i  );
               Pkg_Swift.sp_mesaj_statu_update(pn_islem_no,'CANCL',ls_mesaj) ;
            END IF;
            ln_i :=ln_i+1;
            END LOOP;

          --Mesaji tekrar olustur
            Pkg_Swift.MESAJ_OLUSTUR(pn_islem_kod,pn_islem_no ,ps_black_list_kontrol,
                                    ps_mesaj_tipi_1 ,
                                  ps_mesaj_tipi_2 ,
                                  ps_mesaj_tipi_3 ,
                                  ps_mesaj_tipi_4 ,
                                  ps_mesaj_tipi_5 ,
                                  ls_cevap);
            ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ps_mesaj_tipi_1) ;   --sevalb 23022012
            ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ps_mesaj_tipi_1); --sevalb 23022012
            ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

          IF ls_cevap NOT IN  ('SKYACK','SKYBLCK') THEN --bilalg: SKYBLCK hatasinda mesaj tekrar olusturulsun
            Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'ERROR','Dogrulama_Sonrasi-ERROR-4474'||',ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_cevap:' ||ls_cevap)  ;
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4474' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
          END IF;

      END IF;
    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'TAMAMLANDI','Dogrulama_Sonrasi'||',ln_SASRN:' ||ln_SASRN||' LS_SSTS:' ||LS_SSTS ||',ls_cevap:' ||ls_cevap)  ;
    --  END IF;
  END Dogrulama_Sonrasi;
-----------------------------------------------------
  PROCEDURE Onay_Sonrasi (pn_islem_kod NUMBER,pn_islem_no NUMBER ,
                                   ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                                   ps_mesaj_tipi_1 VARCHAR2 DEFAULT NULL,
                                   ps_mesaj_tipi_2 VARCHAR2 DEFAULT NULL,
                                   ps_mesaj_tipi_3 VARCHAR2 DEFAULT NULL,
                                   ps_mesaj_tipi_4 VARCHAR2 DEFAULT NULL,
                                   ps_mesaj_tipi_5 VARCHAR2 DEFAULT NULL
                                   )IS

    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
    ln_i     NUMBER;
    ls_mesaj VARCHAR2(2000);
    ln_sasrn NUMBER ; --sevalb 23022012
    ls_ssts   VARCHAR2(2000); --sevalb 23022012
    ls_kayit_status  VARCHAR2(2000); --sevalb 23022012
    ln_mesaj_tip_i  NUMBER;
  BEGIN
      ln_count := 0 ; ln_i := 1 ;
      ----------------------------------------------
      WHILE ln_i <=5 LOOP   -- Gonderilen mesaj tiplerinden daha once relse olmus olan var mi kontrolu
        IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
        ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
        ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
        ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
        ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
        END IF;

        IF ls_mesaj IS NOT NULL THEN
           IF Pkg_Swift.Relse_Mesaj_Varmi(pn_islem_no,ls_mesaj) = 'E' THEN -- Bir tane  bile bulursan izin verme
                 ls_kayit_status := Pkg_Swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
                 ln_sasrn   := Pkg_Swift.SF_KAYIT_NO(pn_islem_no,ls_mesaj); --sevalb 23022012
                 ls_ssts := Pkg_Swift.SF_MESAJ_SSTS_AL(ln_sasrn) ;   --sevalb 23022012
                 ln_mesaj_tip_i := ln_i;
                 ln_count := ln_count + 1 ;
           END IF;
        END IF;
        ln_i :=ln_i+1;
        END LOOP;
      ----------------------------------------------

     IF ln_count > 0 THEN
             Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'ERROR','Onay_Sonrasi-ERROR-5335' ||',ln_SASRN' ||ln_SASRN|| ',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count ||',ln_mesaj_tip_i:'||ln_mesaj_tip_i);
             RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);
     ELSE
            ln_i := 1;
          WHILE ln_i <=5 LOOP -- Daha once gonderilen mesajlar silinecek .Yenileri olusturulacak.
            IF    ln_i = 1 THEN ls_mesaj := ps_mesaj_tipi_1 ;
            ELSIF ln_i = 2 THEN ls_mesaj := ps_mesaj_tipi_2 ;
            ELSIF ln_i = 3 THEN ls_mesaj := ps_mesaj_tipi_3 ;
            ELSIF ln_i = 4 THEN ls_mesaj := ps_mesaj_tipi_4 ;
            ELSIF ln_i = 5 THEN    ls_mesaj := ps_mesaj_tipi_5 ;
            END IF;

             ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ls_mesaj) ;   --sevalb 23022012
             ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ls_mesaj); --sevalb 23022012
             ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

            IF ls_mesaj IS NOT NULL THEN
               Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ls_mesaj,'CANCL','Onay_Sonrasi-UPDATE,' ||'ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count||',ln_i:'||ln_i  );
               Pkg_Swift.sp_mesaj_statu_update(pn_islem_no,'CANCL',ls_mesaj) ;
            END IF;
            ln_i :=ln_i+1;
            END LOOP;

          --Mesaji tekrar olustur
            Pkg_Swift.MESAJ_OLUSTUR(pn_islem_kod ,pn_islem_no ,ps_black_list_kontrol,
                                    ps_mesaj_tipi_1 ,
                                  ps_mesaj_tipi_2 ,
                                  ps_mesaj_tipi_3 ,
                                  ps_mesaj_tipi_4 ,
                                  ps_mesaj_tipi_5 ,
                                  ls_cevap);
            ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ps_mesaj_tipi_1) ;   --sevalb 23022012
            ln_sasrn   := pkg_swift.sf_kayit_no(pn_islem_no,ps_mesaj_tipi_1); --sevalb 23022012
            ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

          IF ls_cevap NOT IN  ('SKYACK','SKYBLCK') THEN --bilalg: SKYBLCK hatasinda mesaj tekrar olusturulsun
           Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'ERROR','Onay_Sonrasi-ERROR-4475,'||'ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_cevap:' ||ls_cevap)  ;
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4475' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
          END IF;
     END IF;

    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi_1,'TAMAMLANDI','Onay_Sonrasi,'||'ln_SASRN:' ||ln_SASRN||' LS_SSTS:' ||LS_SSTS ||'ls_cevap:' ||ls_cevap)  ;
  END Onay_Sonrasi;
------------------------------
  PROCEDURE Muhasebelesme_Sonrasi (pn_islem_no NUMBER,ps_mesaj_tipi VARCHAR2)IS

    ls_send_cevap VARCHAR(2000);
    ln_count      NUMBER;
    ln_sasrn NUMBER ; --sevalb 23022012
    ls_ssts   VARCHAR2(2000); --sevalb 23022012
    ls_kayit_status  VARCHAR2(2000); --sevalb 23022012
    --ln_mesaj_tip_i  number;
  BEGIN

    ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ps_mesaj_tipi) ;   --sevalb 23022012
    ln_sasrn := pkg_swift.sf_kayit_no(pn_islem_no,ps_mesaj_tipi); --sevalb 23022012
    ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012

    Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi,'BASLADI','Muhasebelesme_Sonrasi' ||' ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS);--SEVALB 23022012


     IF Pkg_Swift.Relse_Mesaj_Varmi(pn_islem_no,ps_mesaj_tipi) = 'E' THEN
         ln_count := 1;
     ELSE
         ln_count := 0;
     END IF;


     IF ln_count > 0 THEN
          Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi,'DRAFT','Muhasebelesme_Sonrasi-UPDATE-Error-5335' ||' ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ln_count:'||ln_count);
          Pkg_Swift.SP_UPDATE_DRAFT (pn_islem_no,ps_mesaj_tipi) ;
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);
     ELSE
          ls_send_cevap := Pkg_Swift.SF_SEND(pn_islem_no,ps_mesaj_tipi);

          ls_kayit_status := pkg_swift.sf_mesaj_statu_al(pn_islem_no,ps_mesaj_tipi) ;   --sevalb 23022012
          ln_sasrn := pkg_swift.sf_kayit_no(pn_islem_no,ps_mesaj_tipi); --sevalb 23022012
          ls_ssts := pkg_swift.sf_mesaj_ssts_al(ln_sasrn) ;   --sevalb 23022012
          log_at(ls_send_cevap, pn_islem_no);
          --Nurmila for Test KABULN
          IF ls_send_cevap NOT IN ('SKYOK' ,'RELSE' ) THEN    --SEVALB 23022012 buraya relse de ekledim.Ya cok hizli relse oluyorsa  --not in ('SKYOK', 'SKYAC','RELSE') THEN
              Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi,'DRAFT','Muhasebelesme_Sonrasi-UPDATE-Error-4482' ||' ln_SASRN:' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_send_cevap:'||ls_send_cevap);
              Pkg_Swift.SP_UPDATE_DRAFT (pn_islem_no,ps_mesaj_tipi) ;
              RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4482' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||ls_send_cevap||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
          END IF;

     END IF;

     Pkg_Swift.Sp_Hata_Log_Kaydet(pn_islem_no,ln_SASRN,ps_mesaj_tipi,'TAMAMLANDI','Muhasebelesme_Sonrasi' ||',ln_SASRN' ||ln_SASRN||',ls_kayit_status:'||ls_kayit_status||',LS_SSTS:' ||LS_SSTS ||',ls_send_cevap:'||ls_send_cevap);
--    END IF;
  END Muhasebelesme_Sonrasi;
-----------------------------------------------------

FUNCTION sf_Musteri_BIC_Al(pn_musteri_no NUMBER) RETURN VARCHAR2
IS
ln_BIC VARCHAR2(11);
BEGIN
 IF pn_musteri_no IS NOT NULL THEN
  SELECT BIC_KOD
   INTO ln_BIC
   FROM CBS_MUSTERI
   WHERE musteri_no=pn_musteri_no;

  RETURN ln_BIC;
 ELSE
  RETURN NULL;
 END IF;

END;
--------------------------------------------------------
FUNCTION sf_mesaj_txt_al(pn_islem_no NUMBER) RETURN VARCHAR2 IS

 CURSOR cur1 IS
  SELECT SBLOCK1 ||CHR(10)|| SBLOCK2 ||CHR(10)||
   '--------------------------------'||CHR(10)||
   SBLOCK4_1 ||CHR(10)|| SBLOCK4_2 ||CHR(10)|| SBLOCK4_3 mesaj
  FROM SWTTRNPF
  WHERE TX_NO = pn_islem_no
  AND     ssts NOT IN ('CANCL');

  row1 cur1%ROWTYPE;

  ls_mesaj_txt VARCHAR2(30000);

BEGIN

    OPEN cur1;
    LOOP
      FETCH cur1 INTO  row1;
      EXIT WHEN cur1%NOTFOUND;
        BEGIN
         ls_mesaj_txt:=ls_mesaj_txt||CHR(10)||
         '*******************************************************'||CHR(10)||
         row1.mesaj;
        END;
    END LOOP;
    CLOSE cur1;

     RETURN pkg_swift.bic_adi_yazan_text(ls_mesaj_txt);
END;

-----------------------------------
FUNCTION sf_mesaj_tipi_donustur(ps_mesaj_tipi VARCHAR2) RETURN VARCHAR2
IS
ls_mesaj_tipi VARCHAR2(10);
BEGIN

 IF ps_mesaj_tipi = '202_103' THEN
    ls_mesaj_tipi := '202' ;
 ELSIF ps_mesaj_tipi = '202_SPT' THEN
    ls_mesaj_tipi := '202' ;
 ELSIF ps_mesaj_tipi = '202_FWD' THEN
    ls_mesaj_tipi := '202' ;
 ELSIF ps_mesaj_tipi = '300_SPT' THEN
    ls_mesaj_tipi := '300' ;
 ELSIF ps_mesaj_tipi = '300_FWD' THEN
    ls_mesaj_tipi := '300' ;
 ELSE
    ls_mesaj_tipi := ps_mesaj_tipi ;
 END IF;


 RETURN ls_mesaj_tipi;

END;
--------------------------------------------------------
 PROCEDURE SP_MESAJ_BLACKLISTFLAG_UPDATE(pn_islemno IN NUMBER,ps_flag  SWTTRNPF.BLFLAG %TYPE )
 IS
 PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN

      UPDATE  SWTTRNPF
     SET       BLFLAG   = ps_flag
     WHERE   tx_no  = pn_islemno;
 COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END SP_MESAJ_BLACKLISTFLAG_UPDATE;
--------------------------------------------------------
FUNCTION  sf_turkce_char_cevir(ps_string VARCHAR2) RETURN  VARCHAR2
  IS
    ls_string VARCHAR2(2000) := ps_string; --sevalb 02092011  length 2000 yapildi
  BEGIN
       IF ls_string  IS NOT NULL THEN
         -- ls_string := TRANSLATE( TRANSLATE( TRANSLATE( TRANSLATE( TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(TRANSLATE(ls_string,'?','S'),'?','G'),'?','I'),'?','I'),'?','U'),'?','I'),'?','O'),'?','C'),'?','c'),'?','o'),'?','g'),'?','u'),'?','s'); --sevalb 23082011 swift statement hatasi sonrasi su asamada sadece 940 icin bu fonksiyonun kullanilmaya karar verildi.

          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),'!',' '),'%',' '),'^',' ');
          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),'&',' '),'(',' '),')',' ');
          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),'=',' '),'?',' '),'_',' ');
          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),';',' '),':',' '),'>',' ');
          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),'<',' '),'/',' '),'#',' ');
          ls_string := REPLACE(REPLACE(REPLACE(UPPER(trim(ls_string)),'$',' '),'?',' '),'#',' ');
          ls_string := REPLACE(REPLACE(UPPER(trim(ls_string)),'[',' '),']',' ');
          ls_string := REPLACE(REPLACE(UPPER(trim(ls_string)),'*',' '),'''',' ');

        END IF;
     RETURN ls_string;
   END;
--------------------------------------------------------
FUNCTION  sf_bic_gecerlimi(ps_bic VARCHAR2) RETURN  VARCHAR2  IS
  ln_count1 NUMBER;
  ln_count2 NUMBER;
  BEGIN
   ln_count1:=0;
   SELECT COUNT(*)
   INTO ln_count1
   FROM SWTBICPF
   WHERE SBICKD=ps_bic;

   IF NVL(ln_count1,0)=0 THEN RETURN 'H'; END IF;

   ln_count1:=0;
   SELECT COUNT(*)
   INTO ln_count1
   FROM SWTBKEPF
   WHERE SBKEKD=ps_bic;

   IF NVL(ln_count1,0)>0 THEN RETURN 'E'; END IF;

----------------------
    ln_count1:=0;
    ln_count2:=0;

    SELECT COUNT(*)
    INTO ln_count1
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)=8
    AND SUBSTR(SBKEKD,1,8)=SUBSTR(ps_bic,1,8);

    SELECT COUNT(*)
    INTO ln_count2
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)>8
    AND SUBSTR(SBKEKD,1,8)=SUBSTR(ps_bic,1,8)
    AND  SUBSTR(SBKEKD,9,3)='XXX';

    IF NVL(ln_count1,0)>0 AND NVL(ln_count2,0)=0 THEN RETURN 'E'; END IF ;
---------------------------
    ln_count1:=0;
    ln_count2:=0;

    SELECT COUNT(*)
    INTO ln_count1
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)=6
    AND SUBSTR(SBKEKD,1,6)=SUBSTR(ps_bic,1,6);

    SELECT COUNT(*)
    INTO ln_count2
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)>6
    AND SUBSTR(SBKEKD,1,6)=SUBSTR(ps_bic,1,6)
    AND  SUBSTR(SBKEKD,7,2)='XX';

    IF NVL(ln_count1,0)>0 AND NVL(ln_count2,0)=0 THEN RETURN 'E'; END IF;

---------------------------
    ln_count1:=0;
    ln_count2:=0;

    SELECT COUNT(*)
    INTO ln_count1
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)=4
    AND SUBSTR(SBKEKD,1,4)=SUBSTR(ps_bic,1,4);

    SELECT COUNT(*)
    INTO ln_count2
    FROM SWTBKEPF
    WHERE LENGTH(SBKEKD)>4
    AND SUBSTR(SBKEKD,1,4)=SUBSTR(ps_bic,1,4)
    AND  SUBSTR(SBKEKD,5,2)='XX';

   IF NVL(ln_count1,0)>0 AND NVL(ln_count2,0)=0 THEN RETURN 'E'; END IF;
---------------------------

   RETURN 'H';

  END;


--------------------------------------------------------
  FUNCTION swift_ip_al RETURN VARCHAR2 IS
  ls_swift_ip CBS_SYSTEM.SWIFT_IP%TYPE;
  BEGIN
   SELECT trim(SWIFT_IP)
    INTO ls_swift_ip
    FROM CBS_SYSTEM;

   RETURN ls_swift_ip;
  END;
/* --------------------------------------------------------------------------------------------------- */

  FUNCTION swift_port_al RETURN NUMBER IS
  ln_swift_port CBS_SYSTEM.SWIFT_PORT%TYPE;
  BEGIN
   SELECT SWIFT_PORT
    INTO ln_swift_port
    FROM CBS_SYSTEM;

   RETURN ln_swift_port;
  END;

/* --------------------------------------------------------------------------------------------------- */
  PROCEDURE Batch_Onay_Sonrasi (pn_islem_kod NUMBER,pn_islem_no NUMBER ,
                                   ps_black_list_kontrol VARCHAR2, -- black list kontrolu yapilmak istenirse 0 istenmez ise 1 olmali
                                   ps_mesaj_tipi VARCHAR2 DEFAULT NULL )IS

    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
  BEGIN

     ln_count := 0 ;

     IF Pkg_Swift.Relse_Mesaj_Varmi(pn_islem_no,ps_mesaj_tipi) = 'E' THEN
              ln_count := ln_count + 1 ;
     END IF;

     IF ln_count > 0 THEN
             RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5335' ||  Pkg_Hata.getUCPOINTER);
     ELSE
          Pkg_Swift.sp_mesaj_statu_update(pn_islem_no,'CANCL',ps_mesaj_tipi ) ;

          --Mesaji tekrar olustur
            Pkg_Swift.MESAJ_OLUSTUR(pn_islem_kod ,pn_islem_no ,ps_black_list_kontrol,ps_mesaj_tipi, NULL,NULL,NULL,NULL,ls_cevap);

          IF ls_cevap NOT IN  ('SKYACK','SKYBLCK') THEN --bilalg: SKYBLCK hatasinda mesaj tekrar olusturulsun
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4475' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
          END IF;
     END IF;
    -- END IF;
  END Batch_Onay_Sonrasi;
/* --------------------------------------------------------------------------------------------------- */
FUNCTION Relse_Mesaj_Varmi(pn_islem_no NUMBER ,ps_mesaj_tipi VARCHAR2 ) RETURN VARCHAR2 IS

    ls_cevap VARCHAR(2000);
    ln_count NUMBER;
  BEGIN

      SELECT COUNT(*)
      INTO   ln_count
      FROM   swttrnpf
      WHERE  tx_no = pn_islem_no
--      AND    ssts  = 'RELSE'
      AND    ssts  IN ('RELSE','ACK')
      AND    SASRN   = Pkg_Swift.SF_KAYIT_NO(pn_islem_no,ps_mesaj_tipi);  -- YENI ekledim . GC 03.03.2008
--      AND    STYPE = ps_mesaj_tipi ;


      IF ln_count = 0 THEN
            ls_cevap := 'H';
      ELSE
            ls_cevap := 'E';
      END IF;

      RETURN ls_cevap ;

  END Relse_Mesaj_Varmi;

/* --------------------------------------------------------------------------------------------------- */

FUNCTION Muafiyet(ps_aratyp VARCHAR2, pn_araidx NUMBER, ps_arakod VARCHAR2, pn_arasno NUMBER) RETURN VARCHAR2 IS
 --muaf is E, degil ise H doner
BEGIN
--Kosul geldikce ekleme yap

   IF ps_aratyp = 320 AND  pn_araidx = 23 AND ps_arakod = '14D' AND  pn_arasno = 1 THEN
         RETURN 'E' ;
   ELSE
         RETURN 'H' ;
   END IF;

END Muafiyet;

/* --------------------------------------------------------------------------------------------------- */

 PROCEDURE Sp_Islem_Turu_Map_Kaydet(pn_swift_no LONG, pn_islemno  NUMBER, ps_mesaj_tipi VARCHAR2)
 IS
 ls_islem_turu   VARCHAR2(20);
 ls_mesaj_tipi   VARCHAR2(2000);
 BEGIN

     -- ls_islem_turu := NVL(SUBSTR(ps_mesaj_tipi,5,3),'STANDART');
    -- ls_mesaj_tipi := Pkg_Swift.sf_mesaj_tipi_donustur(ps_mesaj_tipi);

     INSERT INTO CBS_SWIFT_ISLEM_TURU_MAP
     (SWIFT_NO, TX_NO, MESAJ_TIPI)
     VALUES
     (pn_swift_no,pn_islemno,ps_mesaj_tipi);

 EXCEPTION
   WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20000,SQLERRM);

 END Sp_Islem_Turu_Map_Kaydet;

------------------------------------------------------------------------
FUNCTION bic_adi_yazan_text(ps_str IN VARCHAR2) RETURN VARCHAR2
IS
    str                     CLOB;
    str1                     VARCHAR2(5000);
    str2                     VARCHAR2(5000);
    indx_son              NUMBER;
    ls_bic_name           VARCHAR2(1000);
    ln_cnt                  NUMBER;
BEGIN
    str := ps_str;

    indx_son := INSTR(str,CHR(10))-1;
    str2 := NULL;
    LOOP
        EXIT WHEN indx_son = -1;

        IF indx_son <> -1
        THEN
            str1 := NULL;
            str1 := SUBSTR(str,1,indx_son);

            ls_bic_name := NULL ;
            ln_cnt        := 0 ;

            SELECT COUNT(*)
            INTO ln_cnt
            FROM SWIFTGW.swtbicpf
            WHERE INSTR(str1,SBICKD)>0 ;

            IF ln_cnt = 1
            THEN
                SELECT SUBSTR(RTRIM(LTRIM(SBICTX||','||SBRNTX)),1,110)
                INTO ls_bic_name
                FROM SWIFTGW.swtbicpf
                WHERE INSTR(str1,SBICKD)>0 ;

                str1 := str1||' ('||ls_bic_name||')';
            END IF;

            str2 := str2||str1||CHR(10);

            str := SUBSTR(str,indx_son+2);
            indx_son := INSTR(str,CHR(10))-1;
        END IF;
    END LOOP;

    str1 := str;

    RETURN str2;
END;
------------------------------------------------------------------------
FUNCTION bic_adi(ps_bic_code IN VARCHAR2) RETURN VARCHAR2
IS
    ln_cnt                  NUMBER;
    ls_ret                  VARCHAR(300);
BEGIN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM SWTBICPF
    WHERE SBICKD = ps_bic_code;

    IF ln_cnt = 1
    THEN
        SELECT SBICTX
        INTO ls_ret
        FROM SWTBICPF
        WHERE SBICKD = ps_bic_code;
    END IF;

    RETURN ls_ret;
END;
----------------------------------------------------------------------------------------------
--sevalb 27052011
FUNCTION swift_hata_Aciklamasi(ps_hata_kodu IN VARCHAR2) RETURN VARCHAR2
IS
 ls_aciklama   CBS_SWIFT_HATA_KODLARI.aciklama%TYPE;
BEGIN
     SELECT aciklama
     INTO ls_aciklama
     FROM CBS_SWIFT_HATA_KODLARI
     WHERE hata_kodu = UPPER( trim(ps_hata_kodu));

     RETURN ls_aciklama;
EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;


------------------------------------------------------------------------
-- B-O-M sevalb  23022012 sdlc23773_AplicationShow errors in screen 4003 from SKYJAVA
 PROCEDURE Sp_hata_Log_Kaydet(pn_islem_no NUMBER, pn_kayit_no NUMBER, ps_mesaj_tipi VARCHAR2, ps_hata_kodu VARCHAR2,ps_mesaj_durum_kodu VARCHAR2)
 IS
 ls_islem_turu   VARCHAR2(20);
 ls_mesaj_tipi   VARCHAR2(2000);
 ln_count_islem NUMBER;
 ln_count_islem_gecici   NUMBER;
 ln_islem_kod   NUMBER;
 ls_hata_aciklama VARCHAR2(2000);
   PRAGMA autonomous_transaction;

 BEGIN
        ls_hata_aciklama :=  swift_hata_Aciklamasi(trim(SUBSTR(ps_hata_kodu,1,7)) );

     INSERT INTO CBS_SWIFT_HATA_LOG
     (log_no,ISLEM_KODU, ISLEM_NO, KAYIT_NO, MESAJ_TIPI, HATA_KODU, HATA_ACIKLAMASI,mesaj_durum_kodu)
     VALUES
     (PKG_GENEL.GENEL_KOD_AL('SWFT_LOG_NO'), ln_islem_kod  ,pn_islem_no, pn_kayit_no, ps_mesaj_tipi, ps_hata_kodu, ls_hata_aciklama,ps_mesaj_durum_kodu);
     COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
           NULL;

 END ;
------------------------------------------------------------------------
 FUNCTION SF_MESAJ_SSTS_AL(pn_SASRN NUMBER) RETURN VARCHAR2
 IS
  ls_statu   SWTTRNPF.SSTS%TYPE := NULL;
 BEGIN

       SELECT  SSTS
      INTO      ls_statu
      FROM    SWTTRNPF
      WHERE   SASRN   = pn_SASRN ;

  RETURN ls_statu;

 EXCEPTION
   WHEN OTHERS THEN
       RETURN ls_statu;
 END ;

FUNCTION sf_yasakli_ulke_mi(ps_ulke_kodu IN VARCHAR2) RETURN VARCHAR2 IS
    ln_adet   NUMBER := 0;
BEGIN
     SELECT COUNT(*)
     INTO   ln_adet
     FROM SWTRESTCNT
     WHERE RCNTCODE =ps_ulke_kodu;

    IF NVL(ln_Adet,0) <> 0 THEN
        RETURN 'E';
    ELSE
         RETURN 'H';
    END IF;

 EXCEPTION
   WHEN OTHERS THEN
       RETURN  'H';
END;

------------------------------------------------------------------------
-- E-O-M sevalb  23022012 sdlc23773_AplicationShow errors in screen 4003 from SKYJAVA
------------------------------------------------------------------------
END;
/

