create PACKAGE     pkg_kullanici_log IS
----------------------------------------------------------------------------------------------------------------------------------
        Procedure Ekle (ps_program_adi varchar2 );
----------------------------------------------------------------------------------------------------------------------------------   
-- cbs_main to log clientinfo log    seval.colak 0507202
----------------------------------------------------------------------------------------------------------------------------------        
        Procedure clientinfo (ps_program_adi varchar2 ,  
                    p_clientinfo_user_name           cbs_kullanici_log.clientinfo_user_name%type  default null ,
                    p_clientinfo_ip_address          cbs_kullanici_log.clientinfo_ip_address%type  default null ,
                    p_clientinfo_host_name           cbs_kullanici_log.clientinfo_host_name%type  default null ,
                    p_clientinfo_operating_system    cbs_kullanici_log.clientinfo_operating_system%type  default null ,
                    p_clientinfo_java_version        cbs_kullanici_log.clientinfo_java_version%type  default null ,
                    --p_clientinfo_path_seperator      cbs_kullanici_log.clientinfo_path_seperator%type  default null ,
                    --p_clientinfo_file_seperator      cbs_kullanici_log.clientinfo_file_seperator%type  default null ,
                    p_clientinfo_language            cbs_kullanici_log.clientinfo_language%type  default null ,
                    p_clientinfo_time_zone           cbs_kullanici_log.clientinfo_time_zone%type  default null ,
                    p_clientinfo_date_time           cbs_kullanici_log.clientinfo_date_time%type  default null,
                    p_client_action_message          varchar2 default null 
                    );
                    
      Procedure Rollb_Tx;              
                    
----------------------------------------------------------------------------------------------------------------------------------
                       
END;
/

