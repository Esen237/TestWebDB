create PACKAGE Pkg_Memzuc IS

  PROCEDURE memzuc_gonderilen_ekle(pn_yil NUMBER, pn_ay NUMBER);
  ---------------
  FUNCTION memzuc_olusturulmus_ay(pn_yil NUMBER, pn_ay NUMBER) RETURN NUMBER;
  ---------------
  FUNCTION memzuc_urun_limit_toplami_al(pn_musteri_no NUMBER, pn_kredi_teklif_satir_no NUMBER) RETURN NUMBER;
  ---------------
  PROCEDURE memzuc_gelen_kayit_kaydet(ps_satir VARCHAR2,pn_ay NUMBER,pn_yil NUMBER);
END;

/

