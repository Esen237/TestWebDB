create PACKAGE BODY     pkg_clearing IS

  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;

	INPUT_PATH  varchar2(100) :='C:\CBSDATA\MESSAGES\IN';
	OUTPUT_PATH varchar2(100) :='C:\CBSDATA\MESSAGES\OUT';
	DEPO_PATH varchar2(100)   :='C:\CBSDATA\MESSAGES\DEPO';
	ARCHIVE_PATH varchar2(100):='C:\CBSDATA\MESSAGES\ARCHIVE';
    PREPARE_PATH varchar2(100):='C:\CBSDATA\MESSAGES\PREP';
	INST_PATH varchar2(100):='C:\CBSDATA\MESSAGES\INST';
	TEMP_PATH  varchar2(100) :='C:\CBSDATA\MESSAGES\TMP';
    SCAN_PATH varchar2(100):='C:\CBSDATA\MESSAGES\SCAN';

	MAIL_GROUP varchar2(2000):='dinaraz@demirbank.kz;saya@demirbank.kz;KarlygashR@demirbank.kz;GulmiraB@demirbank.kz;SairashZh@demirbank.kz;Shaida@demirbank.kz;annag@demirbank.kz;ITgroup@demirbank.kz';

/*********************************************************************************/
Function SendClearingMessages(ps_option in varchar2 default null)  return varchar2 is
	f utl_file.file_type;
    ls_returncode varchar2(3):='000';

	cursor cursor_clear is
		select *
		   from cbs_clearing_messages
		   where MSG_TYPE in ('OUTGOING','OUTGOING-T','OUTGOING-O')
		   and MSG_STATUS = 'sNEW'
		   --and TOTAL_TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD')
		   and MSG_KIND in ('100','102','998','920');

    row_clear	 cursor_clear%rowtype;


	ls_content			CLOB;
	ln_messageid		number;
	ls_archievefolder		   varchar2(1000);
Begin

	open cursor_clear;
	fetch cursor_clear into row_clear;

	while cursor_clear%found
	LOOP
		Begin
			if row_clear.MSG_KIND = '100' then
				ls_returncode:=pkg_message.SendMT100Message(row_clear.MSG_ID);
			elsif row_clear.MSG_KIND = '102' then
				if row_clear.MSG_TYPE='OUTGOING' then
				   ls_returncode:=pkg_message.SendMT102Message(row_clear.MSG_ID);
				elsif row_clear.MSG_TYPE='OUTGOING-T' then
				   ls_returncode:=pkg_message.SendMT102TaxMessage(row_clear.MSG_ID);
				elsif row_clear.MSG_TYPE='OUTGOING-O' then
				   ls_returncode:=pkg_message.SendMT102OrdMessage(row_clear.MSG_ID);
				end if;
			elsif row_clear.MSG_KIND = '998' then
				ls_returncode:=pkg_message.SendMT998Message(row_clear.MSG_ID);
			elsif row_clear.MSG_KIND = '920' then
				ls_returncode:=pkg_message.SendMT920Message(row_clear.MSG_ID);
			end if;

			UPDATE cbs_clearing_messages
			SET MSG_STATUS = 'sSEND'
			where MSG_ID= row_clear.MSG_ID;

			pkg_clearing.UpdateClearingPosition('OUT',to_number(row_clear.TOTAL_TRAN_AMOUNT),row_clear.TOTAL_TRAN_DATE);

			if ls_returncode='000' then
		   	   ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD') || '\_IN';
			   utl_file.fcopy(TEMP_PATH, row_clear.FILE_NAME,ls_archievefolder, row_clear.FILE_NAME);
			   utl_file.frename(TEMP_PATH, row_clear.FILE_NAME,INPUT_PATH, row_clear.FILE_NAME);
			end if;
			/*
			update cbs_clearing_position
			set OUTGOING_AMOUNT=OUTGOING_AMOUNT + to_number(row_clear.TOTAL_TRAN_AMOUNT)
			where to_char(VALUE_DATE,'YYMMDD')=row_clear.TOTAL_TRAN_DATE;
			*/
			COMMIT;

		exception
			 when others then
			 	utl_file.fclose(f);
	 	  		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

				ls_content:=sqlerrm;

				insert into CBS_EMAIL_MESSAGES
				(MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
				values
				(ln_messageid, 'SENDCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-SENDCLEARING MESSAGE JOB',TO_WIN(ls_content));
				ROLLBACK;
		End;

	fetch cursor_clear into row_clear;
	END LOOP;

	close cursor_clear;

	COMMIT;
	return ls_returncode;

exception
		 when others then
		 	utl_file.fclose(f);
 	  		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

			ls_content:=sqlerrm;

			insert into CBS_EMAIL_MESSAGES
			(MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
			values
			(ln_messageid, 'SENDCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-SENDCLEARING MESSAGE JOB',TO_WIN(ls_content));
			ROLLBACK;

	 	    RETURN '998';
End;

/*********************************************************************************/
FUNCTION GetPrepClearingMessages( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(4000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(30);

	 ls_outstr		varchar2(4000);
	 ls_returncode  varchar2(3):='000';

	 ls_MSG_KIND        VARCHAR2(3);
	 ls_FIRST_HEADER    VARCHAR2(200);
	 ls_SECOND_HEADER   VARCHAR2(200);
	 ls_PAYMENT_TYPE    VARCHAR2(200);
	 ls_archievefolder varchar2(200);

	 ls_content			CLOB;
     ln_messageid			number;
     
     /*BOM SURMALII 05.06.2018*/
     ls_json CLOB;
     ls_ret varchar2(3);
     pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
     /*EOM*/
BEGIN
	 ls_dirlist:=get_dir_list(PREPARE_PATH);
	 ln_filecount:=pkg_message.Split(ls_dirlist,';',0);

	FOR ln_fileindex IN 1..ln_filecount LOOP

		begin
			ls_filename:=pkg_message.Split(ls_dirlist,';',ln_fileindex);
		 	f:=utl_file.fopen(PREPARE_PATH, ls_filename, 'r',2100);

			utl_file.get_line(f, ls_outstr);--{1:
	  		ls_FIRST_HEADER:=ls_outstr;
			utl_file.get_line(f, ls_outstr);--{2:
	  		ls_SECOND_HEADER:=ls_outstr;
			ls_MSG_KIND:=substr(ls_outstr,5,3);
	  		ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);

			utl_file.fclose(f);

			if ls_MSG_KIND='102' then
			   ls_returncode:=pkg_message.GetPansionMT102Messages(ls_filename);
			end if;


			--move message to backup folder
			if ls_returncode='000' then
				ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD') || '\PREP';
				utl_file.frename(PREPARE_PATH, ls_filename,ls_archievefolder, ls_filename);
			end if;

			COMMIT;

		exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);
			ls_content:=sqlerrm || '--RETURNCODE:' ||ls_returncode;
            ls_content:=ls_content || 'FILE:' || ls_filename;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('PREPCLEARING', 50, 'info@demirbank.kz', MAIL_GROUP, 'ERROR-PREPCLEARING MESSAGE JOB',ls_content || 'FILE:' ||ls_filename);
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(MAIL_GROUP, 'ERROR-PREPCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
		end;

	END LOOP;--Files

	RETURN '000';

exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);

			ls_content:=sqlerrm || '--RETURNCODE:' ||ls_returncode;
            ls_content:=ls_content || 'FILE:' || ls_filename;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------

			--pkg_email.AddToEmailQueue('PREPCLEARING', 50, 'info@demirbank.kz', MAIL_GROUP, 'ERROR-PREPCLEARING MESSAGE JOB',ls_content || 'FILE:' ||ls_filename);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(MAIL_GROUP, 'ERROR-PREPCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
	 	    RETURN '998';
END;

/*********************************************************************************/
FUNCTION GetClearingMessages( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(4000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(20);

	 ls_outstr		varchar2(4000);
	 ls_returncode  varchar2(3):='000';

	 ls_MSG_KIND        VARCHAR2(3);
	 ls_FIRST_HEADER    VARCHAR2(200);
	 ls_SECOND_HEADER   VARCHAR2(200);
	 ls_PAYMENT_TYPE    VARCHAR2(200);
	 ls_archievefolder varchar2(200);

	 ls_content			CLOB;
     ln_messageid			number;
     
     /*BOM SURMALII 05.06.2018*/
     ls_json CLOB;
     ls_ret varchar2(3);
     pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
     /*EOM*/
BEGIN
	 ls_dirlist:=get_dir_list(OUTPUT_PATH);
	 ln_filecount:=pkg_message.Split(ls_dirlist,';',0);

	FOR ln_fileindex IN 1..ln_filecount LOOP

	Begin

		ls_filename:=pkg_message.Split(ls_dirlist,';',ln_fileindex);

	 	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

		utl_file.get_line(f, ls_outstr);--{1:
  		ls_FIRST_HEADER:=ls_outstr;
		utl_file.get_line(f, ls_outstr);--{2:
  		ls_SECOND_HEADER:=ls_outstr;
		ls_MSG_KIND:=substr(ls_outstr,5,3);
  		ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);

		utl_file.fclose(f);

		if ls_MSG_KIND='100' then
		   ls_returncode:=pkg_message.GetMT100Messages(ls_filename);
		elsif ls_MSG_KIND='102' then
		   ls_returncode:=pkg_message.GetMT102Messages(ls_filename);
		elsif ls_MSG_KIND='900' then
		   ls_returncode:=pkg_message.GetMT900Messages(ls_filename);
        elsif ls_MSG_KIND='940' then
		   ls_returncode:=pkg_message.GetMT940Messages(ls_filename);
		elsif ls_MSG_KIND='950' then
		   ls_returncode:=pkg_message.GetMT950Messages(ls_filename);
		elsif ls_MSG_KIND='954' then

			ls_content:='File Name:' || ls_filename ;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('ENDOFCLEARING', 50, 'info@demirbank.kz', 'ITGroup@demirbank.kz', 'MT954 ARRIVED',ls_content);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITGroup@demirbank.kz', 'MT954 ARRIVED', to_char(ls_json), pc_ref);
            /*EOM*/
		end if;



		--move message to backup folder
		if ls_returncode='000' then
		   if ls_MSG_KIND in ('100','102') then
		   	  ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD') || '\_MT' || ls_MSG_KIND;
		   else
		   	  if instr(ls_PAYMENT_TYPE,'SDEPO')>0 then
			  	 ls_archievefolder:=DEPO_PATH;
			  else
		   	  	  ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
			  end if;
		   end if;

		   utl_file.frename(OUTPUT_PATH, ls_filename,ls_archievefolder, ls_filename);

		end if;

	COMMIT;

	exception
	 	when others then
			ROLLBACK;
		    utl_file.fclose(f);
			ls_content:=sqlerrm || ' #File Name:' || ls_filename || ' #Folder:'|| ls_archievefolder;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------

			--pkg_email.AddToEmailQueue('GETCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-GETCLEARING MESSAGE JOB',TO_WIN(ls_content),'HTML');
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || TO_WIN(ls_content) || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITgroup@demirbank.kz', 'ERROR-GETCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
	End;
	END LOOP;--Files

	COMMIT;
	RETURN '000';

exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);
			ls_content:=sqlerrm || ' #File Name:' || ls_filename || ' #Folder:'|| ls_archievefolder;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------

			--pkg_email.AddToEmailQueue('GETCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-GETCLEARING MESSAGE JOB',TO_WIN(ls_content),'HTML');
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || TO_WIN(ls_content) || '"}';  
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITgroup@demirbank.kz', 'ERROR-GETCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
	 	    RETURN '998';
END;

------------------------------------------------------------------------------------
FUNCTION ProcessIncomingClearings( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 is

	cursor cursor_incoming is
		select  *
		from cbs_clearing_messages m
		where m.MSG_TYPE = 'INCOMING'
		and m.MSG_STATUS = 'sNEW'
		and m.MSG_KIND in ('100','102');
		--and TOTAL_TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
		--for update;

	row_incoming	 cursor_incoming%rowtype;

	cursor cursor_incomingdetail(ps_msgid varchar2) is
		select  *
		from cbs_clearing_messages_detail md
		where md.MSG_ID=ps_msgid;

	row_incomingdetail	 cursor_incomingdetail%rowtype;

    ls_returncode varchar2(3):='000';

	ln_islem_no	  	  number;
	ln_islem_kod  	  number;
	lc_modul_tur_kod  varchar2(10);
	lc_urun_tur_kod   varchar2(10);
	lc_urun_sinif_kod varchar2(20);
	ln_tutar          number;
	lc_bolum_kodu     varchar2(10):='010';
	lc_doviz_kod      varchar2(3);
	ln_musteri_numara number;
	lc_hesap_numara	  number;
	lc_kasa_kod		  varchar2(10);

	ls_content			CLOB;
    ln_messageid			number;
	ln_msgid				number;
    
    /*BOM SURMALII 05.06.2018*/
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/

BEGIN
    Pkg_Baglam.yarat('010',2);

	open cursor_incoming;
	fetch cursor_incoming into row_incoming;

	while cursor_incoming%found
	LOOP

		BEGIN

		ln_msgid:=row_incoming.MSG_ID;
		open cursor_incomingdetail(row_incoming.MSG_ID);
		fetch cursor_incomingdetail into row_incomingdetail;
		if cursor_incomingdetail%found then

			if row_incoming.MSG_KIND = '100' then

				   --1-insert into cbs_clearing_islem as incoming
				    ln_islem_no	   	  :=Pkg_Tx.islem_no_al;
					ln_islem_kod	  :=2102;
					lc_modul_tur_kod  :='CLEARING';
					lc_urun_tur_kod   :='INCOMING';
					lc_urun_sinif_kod :='ACCOUNT';
					ln_tutar          :=row_incoming.TOTAL_TRAN_AMOUNT;
					lc_doviz_kod      :=Pkg_Genel.lc_al;

					begin
						ln_musteri_numara :=pkg_hesap.GetMusteriNoFromExternal(row_incomingdetail.TO_ACCOUNT);
						lc_hesap_numara   :=pkg_hesap.GetHesapNoFromExternal(row_incomingdetail.TO_ACCOUNT,pkg_genel.LC_al);
						lc_bolum_kodu	  :=pkg_hesap.HesapSubeAl(lc_hesap_numara);
					exception
						when others then
						  ln_musteri_numara:=null;
						  lc_hesap_numara:=null;
						  lc_bolum_kodu:='010';
					end;

					Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
									   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

					--INSERT MASTER MSG
					insert into CBS_CLEARING_MT102_TRAN
					(TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, PAYMENT_TYPE, REF_NO, VALUE_DATE,
					MSG_KIND, MSG_STATUS, TOTAL_TRAN_AMOUNT, TOTAL_TRAN_CURR, BRANCH_CODE)
					(select ln_islem_no, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,row_incoming.PAYMENT_TYPE,row_incoming.MSG_REFERENCE,to_date(row_incoming.TOTAL_TRAN_DATE,'YYMMDD'),
					row_incoming.MSG_KIND, 'sNEW', row_incoming.TOTAL_TRAN_AMOUNT, row_incoming.TOTAL_TRAN_CURR, lc_bolum_kodu
					from CBS_CLEARING_MESSAGES
					where MSG_ID = row_incoming.MSG_ID);

					--INSERT THE DETAIL	MSG
					insert into CBS_CLEARING_MT102_DETAIL_TRAN
					(TX_NO, MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
					FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
					FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
					TO_IRS, TO_SECO, DOC_NUM, DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
					DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
					DOC_RNN2, DOC_BCLASS, REF_NO,
					CHK_TRAN_AMOUNT,CHK_FROM_ACCOUNT,CHK_TO_BRANCH,CHK_TO_ACCOUNT,CHK_TO_RNN, CHK_DOC_BCLASS)
					(select ln_islem_no,MSG_ID, DETAIL_ID, to_date(TRAN_DATE,'YYMMDD'), TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
					FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
					FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
					TO_IRS, TO_SECO, DOC_NUM, to_date(DOC_DATE,'YYMMDD'), DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
					DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
					DOC_RNN2, DOC_BCLASS, row_incoming.MSG_REFERENCE,
					TRAN_AMOUNT,FROM_ACCOUNT,TO_BRANCH,TO_ACCOUNT,TO_RNN, DOC_BCLASS
					from cbs_clearing_messages_detail
					where MSG_ID = row_incoming.MSG_ID);

					--If From Non -Residents(2) thendocuments should be completed
					if row_incomingdetail.FROM_IRS='1' then
					   if row_incomingdetail.FROM_SECO in ('1','2') and row_incoming.TOTAL_TRAN_AMOUNT>3000000 then
					   	  null;
					   else--SECO<>1,2
					   	  pkg_clearing.Process_Transaction(ln_islem_no);
					   end if;
					else--IRS=2
						pkg_clearing.Process_Transaction(ln_islem_no);
					end if;

					update CBS_CLEARING_MESSAGES
					set MSG_STATUS='sDONE'
					where  MSG_ID=row_incoming.MSG_ID;

					pkg_clearing.UpdateClearingPosition('IN',to_number(row_incoming.TOTAL_TRAN_AMOUNT),row_incoming.TOTAL_TRAN_DATE);

			elsif row_incoming.MSG_KIND = '102' then

					ln_islem_no	   	  :=Pkg_Tx.islem_no_al;
					ln_islem_kod	  :=2102;
					lc_modul_tur_kod  :='CLEARING';
					lc_urun_tur_kod   :='INCOMING';
					lc_urun_sinif_kod :='ACCOUNT';
					ln_tutar          :=row_incoming.TOTAL_TRAN_AMOUNT;
					lc_doviz_kod      :=Pkg_Genel.lc_al;

					begin
						ln_musteri_numara :=pkg_hesap.GetMusteriNoFromExternal(row_incomingdetail.TO_ACCOUNT);
						lc_hesap_numara   :=pkg_hesap.GetHesapNoFromExternal(row_incomingdetail.TO_ACCOUNT,pkg_genel.LC_al);
						lc_bolum_kodu	  :=pkg_hesap.HesapSubeAl(lc_hesap_numara);
					exception
						when others then
						  ln_musteri_numara:=null;
						  lc_hesap_numara:=null;
						  lc_bolum_kodu:='010';
					end;

					Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
				   						ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

					--INSERT MASTER MSG
					insert into CBS_CLEARING_MT102_TRAN
					(TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, PAYMENT_TYPE, REF_NO, VALUE_DATE,
					MSG_KIND, MSG_STATUS, TOTAL_TRAN_AMOUNT, TOTAL_TRAN_CURR, BRANCH_CODE)
					(select ln_islem_no, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,row_incoming.PAYMENT_TYPE,row_incoming.MSG_REFERENCE,to_date(row_incoming.TOTAL_TRAN_DATE,'YYMMDD'),
					row_incoming.MSG_KIND, 'sNEW', row_incoming.TOTAL_TRAN_AMOUNT, row_incoming.TOTAL_TRAN_CURR, lc_bolum_kodu
					from CBS_CLEARING_MESSAGES
					where MSG_ID = row_incoming.MSG_ID);

					--INSERT THE DETAIL	MSG
					insert into CBS_CLEARING_MT102_DETAIL_TRAN
					(TX_NO, MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
					FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
					FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
					TO_IRS, TO_SECO, DOC_NUM, DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
					DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
					DOC_RNN2, DOC_BCLASS, REF_NO,
					CHK_TRAN_AMOUNT,CHK_FROM_ACCOUNT,CHK_TO_BRANCH,CHK_TO_ACCOUNT,CHK_TO_RNN, CHK_DOC_BCLASS)
					(select ln_islem_no,MSG_ID, DETAIL_ID, to_date(TRAN_DATE,'YYMMDD'), TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
					FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
					FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
					TO_IRS, TO_SECO, DOC_NUM, to_date(DOC_DATE,'YYMMDD'), DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
					DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
					DOC_RNN2, DOC_BCLASS, row_incoming.MSG_REFERENCE,
					TRAN_AMOUNT,FROM_ACCOUNT,TO_BRANCH,TO_ACCOUNT,TO_RNN, DOC_BCLASS
					from cbs_clearing_messages_detail
					where MSG_ID = row_incoming.MSG_ID);

					--If From Non -Residents(2) thendocuments should be completed
					if row_incomingdetail.FROM_IRS='1' then
					   if row_incomingdetail.FROM_SECO in ('1','2') and row_incoming.TOTAL_TRAN_AMOUNT>3000000 then
					   	  null;
					   else--SECO<>1,2
					   	  pkg_clearing.Process_Transaction(ln_islem_no);
					   end if;
					else--IRS=2
						pkg_clearing.Process_Transaction(ln_islem_no);
					end if;

					update CBS_CLEARING_MESSAGES
					set MSG_STATUS='sDONE'
					where  MSG_ID=row_incoming.MSG_ID;

					pkg_clearing.UpdateClearingPosition('IN',to_number(row_incoming.TOTAL_TRAN_AMOUNT),row_incoming.TOTAL_TRAN_DATE);

			end if; --msg_kind

		end if;--if found coursorindcoming detail
		close cursor_incomingdetail;

		exception
			WHEN OTHERS THEN
			log_at('1-PROCESS MESSAGES',sqlerrm);
			close cursor_incomingdetail;
			ROLLBACK;
			ls_content:=sqlerrm || '#MSG ID:' || row_incoming.MSG_ID;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('PROCESSINCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-PROCESSINCLEARING MESSAGE JOB',ls_content);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITgroup@demirbank.kz', 'ERROR-PROCESSINCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
		END;

	--SUCCESSFUL MSG COMMITED
	COMMIT;

	FETCH cursor_incoming INTO row_incoming;
	END LOOP;

	close cursor_incoming;

	return ls_returncode;

exception
		 when others then
 	  		ROLLBACK;
			ls_content:=sqlerrm || '#MSG ID:' || row_incoming.MSG_ID;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------

			--pkg_email.AddToEmailQueue('PROCESSINCLEARING', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-PROCESSINCLEARING MESSAGE JOB',ls_content);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITgroup@demirbank.kz', 'ERROR-PROCESSINCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
	 	    RETURN '998';

END;
------------------------------------------------------------------------------------
Procedure GetDKBINFOCode( ps_hqbiccode IN VARCHAR2,
		  				  ps_BIC_CODE OUT VARCHAR2,
						  ps_NB_BIC_CODE OUT VARCHAR2,
						  ps_BANK_NAME OUT VARCHAR2,
						  ps_NB_CORR_ACCOUNT OUT VARCHAR2,
						  ps_RNN OUT VARCHAR2,
	 					  ps_HEAD_NAME OUT VARCHAR2,
						  ps_CHIEF_NAME OUT VARCHAR2,
						  ps_SECTOR_OF_ECONOMY OUT VARCHAR2,
						  ps_SIGN_OF_RESIDENCE OUT VARCHAR2) is
BEGIN
	 select BIC_CODE, NB_BIC_CODE,BANK_NAME, NB_CORR_ACCOUNT,RNN,
	 		HEAD_NAME, CHIEF_NAME,SECTOR_OF_ECONOMY, SIGN_OF_RESIDENCE
	 into ps_BIC_CODE, ps_NB_BIC_CODE,ps_BANK_NAME, ps_NB_CORR_ACCOUNT,ps_RNN,
	 		ps_HEAD_NAME, ps_CHIEF_NAME,ps_SECTOR_OF_ECONOMY, ps_SIGN_OF_RESIDENCE
	 from CBS_DKB_INFO
	 where BIC_CODE=ps_hqbiccode;

END;
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
FUNCTION IsInstitutionPayment( ps_externalno IN VARCHAR2) RETURN VARCHAR2 is
		 ls_code			   varchar2(20);
BEGIN

	 select CODE
	 into ls_code
	 from CBS_INST_DEFINITION
	 where EXTERNAL_ACC_NO=ps_externalno;

	 return ls_code;

exception
		 when no_data_found then
		 	  return null;
END;
--------------------------------------------------------------------------------------
 PROCEDURE Process_Transaction(pn_islem_no NUMBER) IS
 ln_islem_no NUMBER;
 BEGIN
   ln_islem_no := pn_islem_no;
   IF Pkg_Tx.Dogrula_Kontrol(ln_islem_no) THEN		 -- dogrulama gerekiyor
    BEGIN
     Pkg_Tx.dogrula(ln_islem_no,TRUE); 			 	 -- dogrula
	 --COMMIT;		   			   					 --dogrulama sonrasini DB yaz.
	 IF Pkg_Tx.Onay_Kontrol(ln_islem_no) THEN
	   Pkg_Tx.onay(ln_islem_no, TRUE );		 		 --onay gerekiyor o zaman onaylamaya ?al??.
	 END IF;
	 --COMMIT;		   			   	 	  			 --onaylad?, onay sonrasini DB yaz.
	 Pkg_Tx.muhasebelestir(ln_islem_no);
--	 EXCEPTION   --do?rulayam?yor veya onaylayam?yor veya hata olu?tu burada b?rak
--	  WHEN OTHERS THEN
--	     null;
	END;
   ELSIF Pkg_Tx.Onay_Kontrol(ln_islem_no) THEN     --dogrulama gerekmiyor ama onay gerekiyor
    BEGIN
	 --COMMIT;							  			 --do?rulama sonras? yap?lanlar db yaz?ld?
	 Pkg_Tx.onay(ln_islem_no, TRUE );				 --onaylamaya calis
	 --COMMIT;		  			  					 --onay sonrasini DB yaz.
  	 Pkg_Tx.muhasebelestir(ln_islem_no);
--	 EXCEPTION   	--onaylayam?yor veya hata olu?tu burada b?rak
--		WHEN OTHERS THEN
--	     null;
    END;
   ELSE						   			 	 	 --ne dogrulama ne onay gerekiyor. sadece muhasebele?tir..
    BEGIN
     --COMMIT;										 --dogrulama ve onay sonrasini DB yaz.
     Pkg_Tx.muhasebelestir(ln_islem_no);
--     EXCEPTION   --muhasebele?tiremiyor veya hata olu?tu burada b?rak
--	  WHEN OTHERS THEN
--	    NULL;
	END;
   END IF;
 END;
--------------------------------------------------------------------------------------
FUNCTION ProcessOutgoing102Clearings( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 is

	cursor cursor_incoming is
		select  *
		from cbs_clearing_messages m
		where m.MSG_TYPE in ('PREPARE','PREPARE-GL','INST-ORD','INST-TAX','INST-100','SCAN')
		and m.MSG_STATUS = 'sNEW';
		--and TOTAL_TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
		--for update;

	row_incoming	 cursor_incoming%rowtype;

	cursor cursor_incomingdetail(ps_msgid varchar2) is
		select  *
		from cbs_clearing_messages_detail md
		where md.MSG_ID=ps_msgid;

	row_incomingdetail	 cursor_incomingdetail%rowtype;

    ls_returncode varchar2(3):='000';

	ln_islem_no	  	  number;
	ln_islem_kod  	  number;
	lc_modul_tur_kod  varchar2(10);
	lc_urun_tur_kod   varchar2(10);
	lc_urun_sinif_kod varchar2(20);
	ln_tutar          number;
	lc_bolum_kodu     varchar2(10);
	lc_doviz_kod      varchar2(3);
	ln_musteri_numara number;
	lc_hesap_numara	  number;
	lc_kasa_kod		  varchar2(10);

	lc_rol               NUMBER:= 7777 ;
	ln_kanal_numara      NUMBER:= 1;


	ls_content			CLOB;
    ln_messageid			number;
	DifferentRNNException		   exception;
	DifferentAmountException	   exception;
	ln_sum_detail				   number;
	ln_total_amount				   number;
	ls_CHARGE_USER_STAT			   varchar2(4);
	ls_CHARGE_PAYMENTCODE		   varchar2(3);
	ls_FROM_GL					   varchar2(8);
	ln_customerno				   number;
	ln_currenthour				   number;
	ln_CHARGE_AMOUNT			   number;
    
    /*BOM SURMALII 05.06.2018*/
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/

BEGIN

	open cursor_incoming;
	fetch cursor_incoming into row_incoming;

	while cursor_incoming%found
	LOOP

		BEGIN
			ln_sum_detail:=0;
			open cursor_incomingdetail(row_incoming.MSG_ID);
			fetch cursor_incomingdetail into row_incomingdetail;
			close cursor_incomingdetail;

			ln_islem_no	   	  :=Pkg_Tx.islem_no_al;
			ln_islem_kod	  :=2102;
			lc_modul_tur_kod  :='CLEARING';
			lc_urun_tur_kod   :='OUTGOING';

			if row_incoming.MSG_TYPE in ('INST-ORD','INST-TAX','INST-100','PREPARE-GL') then
			   lc_urun_sinif_kod :='GL';
  			   ls_FROM_GL:=pkg_genelkz.GetGLExternal(row_incomingdetail.FROM_ACCOUNT);
			   ls_CHARGE_PAYMENTCODE:=null;
			   begin
			   		select BRANCH_CODE
					into lc_bolum_kodu
					from cbs_dkb_info
					where BIC_CODE=row_incomingdetail.FROM_BRANCH;
			   exception
	   			when no_data_found then
					  lc_bolum_kodu:='010';
			   end;

			elsif row_incoming.MSG_TYPE in ('PREPARE') then --PREPARE
			   begin
					ln_currenthour:=to_number(to_char(sysdate,'HH24'));
						if ln_currenthour<11 then
						   lc_urun_sinif_kod :='ACCOUNT-PENL-1';
						elsif ln_currenthour>=11 and ln_currenthour<15 then
						   lc_urun_sinif_kod :='ACCOUNT-PENL-2';
						elsif ln_currenthour>=15 then
						   lc_urun_sinif_kod :='ACCOUNT-PENL-3';
						end if;
			   exception
			   	when others then
				  lc_urun_sinif_kod :='ACCOUNT-PENL-1';--'ACCOUNT-IND-1';
			   end;

	   		   ls_CHARGE_USER_STAT:=row_incomingdetail.FROM_IRS || row_incomingdetail.FROM_SECO || '14';
			   ls_CHARGE_PAYMENTCODE:='840';
	   			begin
					 lc_bolum_kodu     :=pkg_hesap.HesaptanSubeAl(pkg_hesap.GetHesapNoFromExternal(row_incomingdetail.FROM_ACCOUNT,pkg_genel.LC_al));
				exception
					when others then
						lc_bolum_kodu:='010';
				end;

			elsif row_incoming.MSG_TYPE in ('SCAN') then --SCANNER
			   begin
					ln_currenthour:=to_number(to_char(sysdate,'HH24'));
					if ln_currenthour<11 then
					   lc_urun_sinif_kod :='ACCOUNT-IND-1';
					elsif ln_currenthour>=11 and ln_currenthour<15 then
					   lc_urun_sinif_kod :='ACCOUNT-IND-2';
					elsif ln_currenthour>=15 then
					   lc_urun_sinif_kod :='ACCOUNT-IND-3';
					end if;
			   exception
			   	when others then
				  lc_urun_sinif_kod :='ACCOUNT-IND-1';--'ACCOUNT-IND-1';
			   end;

	   		   ls_CHARGE_USER_STAT:=row_incomingdetail.FROM_IRS || row_incomingdetail.FROM_SECO || '14';
			   ls_CHARGE_PAYMENTCODE:='840';

	   			begin
					 lc_bolum_kodu     :=pkg_hesap.HesaptanSubeAl(pkg_hesap.GetHesapNoFromExternal(row_incomingdetail.FROM_ACCOUNT,pkg_genel.LC_al));
				exception
					when others then
						lc_bolum_kodu:='010';
				end;

			end if;--row_incoming.MSG_TYPE

			ln_tutar          :=row_incoming.TOTAL_TRAN_AMOUNT;
			lc_doviz_kod      :=Pkg_Genel.lc_al;

  		    /*ln_CHARGE_AMOUNT  :=pkg_aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
								   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);*/

			--FOR CINT_CALLER
			if substr(row_incoming.FILE_NAME,1,5)='PINT_' then
			     	Pkg_Int_Api.create_transaction (ln_islem_no,ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                 ln_tutar, lc_bolum_kodu,lc_bolum_kodu, lc_rol,lc_doviz_kod, ln_musteri_numara, lc_hesap_numara,
                                 lc_kasa_kod, ln_kanal_numara);
		    else--FOR CBS
					Pkg_Baglam.yarat(lc_bolum_kodu,2);

					Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
		   						ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);
			end if;

			--INSERT MASTER MSG
			insert into CBS_CLEARING_MT102_TRAN
			(TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, PAYMENT_TYPE, REF_NO, VALUE_DATE,
			MSG_KIND, MSG_STATUS, TOTAL_TRAN_AMOUNT, TOTAL_TRAN_CURR, BRANCH_CODE,
			CHARGE_USER_STAT, CHARGE_PAYMENTCODE,MSG_TYPE,FILE_NAME)
			(select ln_islem_no, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,decode(row_incoming.PAYMENT_TYPE,'000000','SCLEAR',row_incoming.PAYMENT_TYPE),row_incoming.MSG_REFERENCE,to_date(row_incoming.TOTAL_TRAN_DATE,'YYMMDD'),
			row_incoming.MSG_KIND, 'sNEW', row_incoming.TOTAL_TRAN_AMOUNT, row_incoming.TOTAL_TRAN_CURR, lc_bolum_kodu,
			ls_CHARGE_USER_STAT, ls_CHARGE_PAYMENTCODE,MSG_TYPE,FILE_NAME
			from CBS_CLEARING_MESSAGES
			where MSG_ID = row_incoming.MSG_ID);

			if row_incoming.MSG_TYPE in ('INST-ORD','INST-TAX','INST-100','PREPARE-GL') then

				insert into CBS_CLEARING_MT102_DETAIL_TRAN
				(TX_NO, MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_GL_EXTERNAL, FROM_GL,
				FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
				FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
				TO_IRS, TO_SECO, DOC_NUM, DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
				DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
				DOC_RNN2, DOC_BCLASS, REF_NO,
				CHK_TRAN_AMOUNT,CHK_FROM_ACCOUNT,CHK_TO_BRANCH,CHK_TO_ACCOUNT,CHK_TO_RNN, CHK_DOC_BCLASS,DOC_PERIOD)
				(select ln_islem_no,MSG_ID, DETAIL_ID, to_date(TRAN_DATE,'YYMMDD'), TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,ls_FROM_GL,
				FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
				FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
				TO_IRS, TO_SECO, DOC_NUM, to_date(DOC_DATE,'YYMMDD'), DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
				DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
				DOC_RNN2, DOC_BCLASS, row_incoming.MSG_REFERENCE,
				TRAN_AMOUNT,FROM_ACCOUNT,TO_BRANCH,TO_ACCOUNT,TO_RNN, DOC_BCLASS,DOC_PERIOD
				from cbs_clearing_messages_detail
				where MSG_ID = row_incoming.MSG_ID);

			else

				insert into CBS_CLEARING_MT102_DETAIL_TRAN
				(TX_NO, MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
				FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
				FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
				TO_IRS, TO_SECO, DOC_NUM, DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
				DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
				DOC_RNN2, DOC_BCLASS, REF_NO,
				CHK_TRAN_AMOUNT,CHK_FROM_ACCOUNT,CHK_TO_BRANCH,CHK_TO_ACCOUNT,CHK_TO_RNN, CHK_DOC_BCLASS,DOC_PERIOD)
				(select ln_islem_no,MSG_ID, DETAIL_ID, to_date(TRAN_DATE,'YYMMDD'), TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT,
				FROM_NAME, FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ,
				FROM_NBACCOUNT, TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN,
				TO_IRS, TO_SECO, DOC_NUM, to_date(DOC_DATE,'YYMMDD'), DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
				DOC_OPV, DOC_FM, DOC_NM, DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2,
				DOC_RNN2, DOC_BCLASS, row_incoming.MSG_REFERENCE,
				TRAN_AMOUNT,FROM_ACCOUNT,TO_BRANCH,TO_ACCOUNT,TO_RNN, DOC_BCLASS,DOC_PERIOD
				from cbs_clearing_messages_detail
				where MSG_ID = row_incoming.MSG_ID);

			end if;
			/*pkg_clearing.Process_Transaction(ln_islem_no);*/

			update CBS_CLEARING_MESSAGES
			set MSG_STATUS='sDONE'
			where  MSG_ID=row_incoming.MSG_ID;

			begin
				update cbs_islem
				set MUSTERI_NUMARA=pkg_hesap.GetMusteriNoFromExternal(row_incomingdetail.FROM_ACCOUNT),
					HESAP_NUMARA=pkg_hesap.GetHesapNoFromExternal(row_incomingdetail.FROM_ACCOUNT,pkg_genel.LC_al)
				where NUMARA = ln_islem_no;
			exception
				when others then
					 null;
			end;

		exception
			WHEN OTHERS THEN
			log_at('1-PROCESS PREP MESSAGES',sqlerrm);
			close cursor_incomingdetail;
			ROLLBACK;
		END;

	FETCH cursor_incoming INTO row_incoming;
	END LOOP;

	close cursor_incoming;

	COMMIT;
	return ls_returncode;

exception
		 when DifferentRNNException then
		 	  null;
			  log_at('RNN Different');
		 when DifferentAmountException then
		 	  null;
			  log_at('Total Amount Different');
		 when others then
 	  		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

			ls_content:=sqlerrm;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------

			--pkg_email.AddToEmailQueue('PROCESSPREPOUTCLEAR', 50, 'info@demirbank.kz', 'ITgroup@demirbank.kz', 'ERROR-PROCESSPREPOUTCLEAR MESSAGE JOB',ls_content);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL('ITGroup@demirbank.kz', 'ERROR-PROCESSPREPOUTCLEAR MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
	 	    RETURN '998';

END;
-----------------------------------------------------------------------------------------
PROCEDURE UpdateClearingPosition(ps_option VARCHAR2,pn_TRAN_AMOUNT NUMBER, ps_TRAN_DATE VARCHAR2) is
	ln_count			number:=0;
BEGIN
	select count(*)
	into ln_count
	from cbs_clearing_position
	where to_char(VALUE_DATE,'YYMMDD')=ps_TRAN_DATE;

	if ln_count=0 then
	   insert into cbs_clearing_position
	   (VALUE_DATE, OUTGOING_AMOUNT, INCOMING_AMOUNT, INITIAL_AMOUNT)
	   values
	   (to_date(ps_TRAN_DATE,'YYMMDD'), 0,0,0);
	end if;

	if ps_option='IN' then
		update cbs_clearing_position
		set INCOMING_AMOUNT=INCOMING_AMOUNT + to_number(pn_TRAN_AMOUNT)
		where to_char(VALUE_DATE,'YYMMDD')=ps_TRAN_DATE;
    elsif ps_option='OUT' then
		update cbs_clearing_position
		set OUTGOING_AMOUNT=OUTGOING_AMOUNT + to_number(pn_TRAN_AMOUNT)
		where to_char(VALUE_DATE,'YYMMDD')=ps_TRAN_DATE;
    elsif ps_option='START' then
		update cbs_clearing_position
		set INITIAL_AMOUNT=INITIAL_AMOUNT + to_number(pn_TRAN_AMOUNT)
		where to_char(VALUE_DATE,'YYMMDD')=ps_TRAN_DATE;
	end if;

END;
------------------------------------------------------------------------------------------
FUNCTION GetInstClearingMessages( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 is
     f	  utl_file.file_type;

	 ls_dirlist		varchar2(4000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(20);

	 ls_outstr		varchar2(4000);
	 ls_returncode  varchar2(3):='000';
	 ls_archievefolder varchar2(200);

	 ls_content			CLOB;
     ln_messageid			number;
     
     /*BOM SURMALII 05.06.2018*/
     ls_json CLOB;
     ls_ret varchar2(3);
     pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
     /*EOM*/

BEGIN
	 ls_dirlist:=get_dir_list(INST_PATH);
	 ln_filecount:=pkg_message.Split(ls_dirlist,';',0);

	FOR ln_fileindex IN 1..ln_filecount LOOP

		ls_filename:=pkg_message.Split(ls_dirlist,';',ln_fileindex);
	 	f:=utl_file.fopen(INST_PATH, ls_filename, 'r',2100);
		utl_file.fclose(f);

		ls_returncode:=pkg_message.UploadInstClearingFile(ls_filename);

		--move message to backup folder
		if ls_returncode='000' then
			ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD') || '\INST';
			utl_file.frename(INST_PATH, ls_filename,ls_archievefolder, ls_filename);
		end if;

		COMMIT;


	END LOOP;--Files



	 RETURN '000';

exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);
 	  		ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');

			ls_content:=sqlerrm;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('INSTCLEARING', 50, 'info@demirbank.kz', MAIL_GROUP, 'ERROR-INSTCLEARING MESSAGE JOB',ls_content,'HTML');\
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(MAIL_GROUP, 'ERROR-INSTCLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/

	 	    RETURN '998';

END;
------------------------------------------------------------------------------------------
FUNCTION GetScanClearingMessages( ps_option IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(4000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(30);

	 ls_outstr		varchar2(4000);
	 ls_returncode  varchar2(3):='000';

	 ls_MSG_KIND        VARCHAR2(3);
	 ls_FIRST_HEADER    VARCHAR2(200);
	 ls_SECOND_HEADER   VARCHAR2(200);
	 ls_PAYMENT_TYPE    VARCHAR2(200);
	 ls_archievefolder 	varchar2(200);

	 ls_content			CLOB;
     ln_messageid		number;
     
     /*BOM SURMALII 05.06.2018*/
     ls_json CLOB;
     ls_ret varchar2(3);
     pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
     /*EOM*/
BEGIN
	 ls_dirlist:=get_dir_list(SCAN_PATH);
	 ln_filecount:=pkg_message.Split(ls_dirlist,';',0);

	FOR ln_fileindex IN 1..ln_filecount LOOP

		begin
			ls_filename:=pkg_message.Split(ls_dirlist,';',ln_fileindex);
		 	f:=utl_file.fopen(SCAN_PATH, ls_filename, 'r',2100);

			utl_file.get_line(f, ls_outstr);--{1:
	  		ls_FIRST_HEADER:=ls_outstr;
			utl_file.get_line(f, ls_outstr);--{2:
	  		ls_SECOND_HEADER:=ls_outstr;
			ls_MSG_KIND:=substr(ls_outstr,5,3);
	  		ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);

			utl_file.fclose(f);

			if ls_MSG_KIND='100' then
			   ls_returncode:=pkg_message.GetScanMT100Messages(ls_filename);
			elsif ls_MSG_KIND='102' then
			   ls_returncode:=pkg_message.GetScanMT102Messages(ls_filename);
			end if;


			--move message to backup folder
			if ls_returncode='000' then
				ls_archievefolder:=ARCHIVE_PATH || '\CRYST.' || to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD') || '\SCAN';
				utl_file.frename(SCAN_PATH, ls_filename,ls_archievefolder, ls_filename);
			end if;

			COMMIT;

		exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);
			ls_content:=sqlerrm || '--RETURNCODE:' ||ls_returncode;
            ls_content:=ls_content || 'FILE:' || ls_filename;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('SCANCLEARING', 50, 'info@demirbank.kz', MAIL_GROUP, 'ERROR-SCAN CLEARING MESSAGE JOB',ls_content || 'FILE:' ||ls_filename);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(MAIL_GROUP, 'ERROR-SCAN CLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/
		end;

	END LOOP;--Files

	 RETURN '000';

exception
		 when others then
		 	ROLLBACK;
		 	utl_file.fclose(f);

			ls_content:=sqlerrm || '--RETURNCODE:' ||ls_returncode;
            ls_content:= ls_content || 'FILE:' || ls_filename;
            ------------------------------------------------------------ HTML email not accepting the chr()10 and chr(13) which are exists in sqlerrm
            ls_content:=replace(ls_content, chr(13)||chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(10), '<BR/>');
            ls_content:=replace(ls_content, chr(13), '<BR/>');
            ls_content:=replace(ls_content, '"', '''''');
            ------------------------------------------------------------
			--pkg_email.AddToEmailQueue('SCANCLEARING', 50, 'info@demirbank.kz', MAIL_GROUP, 'ERROR-SCAN CLEARING MESSAGE JOB',ls_content || 'FILE:' ||ls_filename);
            
            /*BOM SURMALII 05.06.2018*/
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(MAIL_GROUP, 'ERROR-SCAN CLEARING MESSAGE JOB', to_char(ls_json), pc_ref);
            /*EOM*/

	 	    RETURN '998';
END;
------------------------------------------------------------------------------------------
procedure RequestClearingStatement(ps_option IN VARCHAR2 default null) is
	pragma AUTONOMOUS_TRANSACTION;
 	ln_MSG_ID number;
	ls_refno  varchar2(16);
begin

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_refno:=lpad(to_char(pkg_genel.genel_kod_al('CLEARING')),16,'0');

	insert into cbs_clearing_messages
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER,TOTAL_TRAN_DATE)
	values
	(ln_MSG_ID,'OUTGOING','920',ls_refno ||'.imp','SGROSS',ls_refno,'{1:F01K57880000000010406986}','{2:I920SGROSS000000U3003}',to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD'));

	commit;

end;
--------------------------------------------------------------------------------------------
  Function  eft_merkezi(ps_bolum_kodu varchar2) return number is
  begin
    if ps_bolum_kodu = '001' then
	  return 1;
	else
	  return 0;
    end if;
  end;
--------------------------------------------------------------------------------------------
Function  get_clearing_cut_off_time return date is
  cursor c_1 is
     select to_date(to_char(clearing_cut_off_time,'hh24:mi'),'hh24:mi') clearing_cut_off_time
       from cbs_clearing_parameters;
  r_1  c_1%rowtype;
begin
  open c_1;
  fetch c_1 into r_1;
  if c_1%notfound then
       close c_1;
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2043' ||g_uc_delimiter);
  elsif r_1.clearing_cut_off_time is null then
       close c_1;
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2044' ||g_uc_delimiter);
  end if;
  close c_1;
  return r_1.clearing_cut_off_time;
end;
--------------------------------------------------------------------------------------------
Function  get_clearing_max_tutar return number is
  cursor c_1 is
     select clearing_max_tutar
       from cbs_clearing_parameters;
  r_1  c_1%rowtype;
begin
  open c_1;
  fetch c_1 into r_1;
  if c_1%notfound then
       close c_1;
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2045' ||g_uc_delimiter);
  elsif r_1.clearing_max_tutar is null then
       close c_1;
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2046' ||g_uc_delimiter);
  end if;
  close c_1;
  return r_1.clearing_max_tutar;
end;
--------------------------------------------------------------------------------------------
Function  get_clearing_approval_date(pn_islem_no number) return date is
  cursor c_1 is
     select onay_sistem_tarihi
	   from cbs_islem
	  where numara = pn_islem_no;
  ld_ret date;
begin
  open c_1;
  fetch c_1 into ld_ret;
  if c_1%notfound then
       ld_ret := null;
  end if;
  close c_1;
  return ld_ret;
end;
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------



END;
/

