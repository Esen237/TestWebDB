create PACKAGE BODY     "PKG_HESAP" IS



      l_uc          VARCHAR2(3):=Pkg_Hata.getUCPOINTER;

        l_ara          VARCHAR2(3):=Pkg_Hata.getDELIMITER;

/*-------------------------------HesaptanMusteriNoAl----------------------------------------*/

  FUNCTION HesaptanMusteriNoAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS

       l_musteri_no CBS_HESAP.musteri_no%TYPE;

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

              SELECT musteri_no

              FROM CBS_HESAP

              WHERE CBS_HESAP.hesap_no=p_hesapno

              UNION

              SELECT musteri_no

              FROM CBS_HESAP_VADELI

              WHERE CBS_HESAP_VADELI.hesap_no=p_hesapno

              UNION

              SELECT musteri_no

              FROM CBS_HESAP_KREDI

              WHERE CBS_HESAP_KREDI.hesap_no=p_hesapno ;

  BEGIN

     IF pn_hesap_no  IS NOT NULL THEN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO l_musteri_no;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;

         END IF;

       RETURN l_musteri_no;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN
LOG_AT('p_hesapno',pn_hesap_no);
                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;

/*------------------------------GeriDonusHesapNo----------------------------------------------------------*/

    FUNCTION GeriDonusHesapNo(pn_hesap_no CBS_HESAP_VADELI.HESAP_NO%TYPE) RETURN NUMBER IS

             ln_geridonus_hesapno          NUMBER;

    BEGIN

         SELECT geri_donus_hesapno INTO ln_geridonus_hesapno

         FROM CBS_HESAP_VADELI

         WHERE CBS_HESAP_VADELI.HESAP_NO=pn_hesap_no;



         RETURN ln_geridonus_hesapno;

    EXCEPTION

            WHEN OTHERS THEN

                 RETURN NULL;

    END;

/*------------------------------HesapUzerindeBlokeKayitli----------------------------------*/

    FUNCTION HesapUzerindeBlokeKayitli(pn_hesap_no cbs_vw_hesap_izleme.HESAP_NO%TYPE) RETURN BOOLEAN IS

             ln_bloke_tutar          NUMBER;

             Hesap_Bulunamadi_Exception EXCEPTION;

    BEGIN



     SELECT NVL(bloke_tutari,0) INTO ln_bloke_tutar

     FROM cbs_vw_hesap_izleme

     WHERE HESAP_NO=pn_hesap_no;



     IF ln_bloke_tutar>0 THEN

         RETURN TRUE;

     ELSE

        RETURN FALSE;

     END IF;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN



                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

    END;



/*-------------------------MusteriBilgiAl-------------------------------------------*/

  PROCEDURE MusteriBilgiAl(pn_hesap_no cbs_vw_hesap_izleme.HESAP_NO%TYPE,

                               pn_musteri_no OUT cbs_vw_hesap_izleme.MUSTERI_NO%TYPE,

                            pv_musteri_adi OUT cbs_vw_hesap_izleme.ISIM_UNVAN%TYPE) IS

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno cbs_vw_hesap_izleme.HESAP_NO%TYPE) IS

              SELECT musteri_no,isim_unvan

              FROM cbs_vw_hesap_izleme

              WHERE cbs_vw_hesap_izleme.hesap_no=p_hesapno;

  BEGIN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO pn_musteri_no,pv_musteri_adi;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN



                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;



-----------------------------------------------------------------------

PROCEDURE BakiyeBilgiAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE,

                        pn_bakiye OUT CBS_HESAP_BAKIYE.bakiye%TYPE,

                       pn_birikmis_faiz_neg OUT CBS_HESAP.BIRIKMIS_FAIZ_NEG%TYPE,

                       pn_birikmis_faiz_poz OUT CBS_HESAP.BIRIKMIS_FAIZ_POZ%TYPE) IS

       --ln_bakiye cbs_hes_bak.bakiye%TYPE;

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

           SELECT bakiye,BIRIKMIS_FAIZ_NEG,BIRIKMIS_FAIZ_POZ

                FROM cbs_vw_hesap_izleme

                WHERE hesap_no=p_hesapno;

               /*

            SELECT cbs_hesap_bakiye.bakiye,cbs_hesap.BIRIKMIS_FAIZ_NEG,cbs_hesap.BIRIKMIS_FAIZ_POZ

            FROM cbs_hesap_bakiye,cbs_hesap

            WHERE cbs_hesap.hesap_no=cbs_hesap_bakiye.hesap_no

                  AND cbs_hesap.hesap_no=p_hesapno

            UNION

            SELECT cbs_hesap_bakiye.bakiye,cbs_hesap_vadeli.BIRIKMIS_FAIZ_NEG,cbs_hesap_vadeli.BIRIKMIS_FAIZ_POZ

            FROM cbs_hesap_bakiye,cbs_hesap_vadeli

            WHERE cbs_hesap_vadeli.hesap_no=cbs_hesap_bakiye.hesap_no

                  AND cbs_hesap_vadeli.hesap_no=p_hesapno

            UNION

             SELECT cbs_hesap_bakiye.bakiye,cbs_hesap_kredi.BIRIKMIS_FAIZ_TUTARI ,0

            FROM cbs_hesap_bakiye,cbs_hesap_kredi

            WHERE cbs_hesap_kredi.hesap_no=cbs_hesap_bakiye.hesap_no

                  AND cbs_hesap_kredi.hesap_no=p_hesapno;      */

  BEGIN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO pn_bakiye,pn_birikmis_faiz_neg, pn_birikmis_faiz_poz;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN



                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;



-------------------------------------------------------------------------

  PROCEDURE UrunBilgiAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE,

                              pn_modul_tur_kod OUT CBS_HESAP.modul_tur_kod%TYPE,

                            pn_urun_tur_kod OUT CBS_HESAP.urun_tur_kod%TYPE,

                            pn_urun_sinif_kod OUT CBS_HESAP.urun_sinif_kod%TYPE) IS

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

              SELECT CBS_HESAP.MODUL_TUR_KOD,CBS_HESAP.URUN_TUR_KOD, CBS_HESAP.URUN_SINIF_KOD

              FROM CBS_HESAP

              WHERE CBS_HESAP.hesap_no=p_hesapno

              UNION

              SELECT CBS_HESAP_VADELI.MODUL_TUR_KOD,CBS_HESAP_VADELI.URUN_TUR_KOD, CBS_HESAP_VADELI.URUN_SINIF_KOD

              FROM CBS_HESAP_VADELI

              WHERE CBS_HESAP_VADELI.hesap_no=p_hesapno

              UNION

              SELECT CBS_HESAP_KREDI.MODUL_TUR_KOD,CBS_HESAP_KREDI.URUN_TUR_KOD, CBS_HESAP_KREDI.URUN_SINIF_KOD

              FROM CBS_HESAP_KREDI

              WHERE CBS_HESAP_KREDI.hesap_no=p_hesapno;





  BEGIN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO pn_modul_tur_kod, pn_urun_tur_kod,pn_urun_sinif_kod;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN



                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;

-------------------------------------------------------------------------------------------------

  PROCEDURE Bakiye_Guncelle(pv_hesap_turu IN VARCHAR2,

                              pv_hesap_no IN CBS_SATIR.HESAP_NUMARA%TYPE,

                            pv_doviz_kod IN CBS_SATIR.DOVIZ_KOD%TYPE,

                            pv_tur IN CBS_SATIR.TUR%TYPE,

                            pv_fc_tutar IN CBS_SATIR.DV_TUTAR%TYPE,

                            pv_lc_tutar IN CBS_SATIR.LC_TUTAR%TYPE,

                            pn_fis_numara in CBS_SATIR.fis_numara%TYPE,

                            ps_force_debit in cbs_fis.force_debit%TYPE) IS



            l_initial_bakiye                      NUMBER;

            ln_bloke_tutari                       NUMBER;

            l_last_bakiye                       NUMBER;

            ls_modul_tur_kod                   VARCHAR2(10);

            ls_bakiye_karakteri                   VARCHAR(1);

            ls_urun_tur_kod                          VARCHAR2(10);

            ls_urun_sinif_kod                   VARCHAR2(20);

            ls_durum_kodu                       VARCHAR2(1);

            ln_RetVal                            NUMBER;

            Hesap_Bulunamadi_Exception            EXCEPTION;

            Bakiye_Yetersiz_Exception           EXCEPTION;

            Bakiye_Negatif_Olamaz                  EXCEPTION;

            Bakiye_Pozitif_Olamaz                  EXCEPTION;

            Kapali_Hesap_Hareket_Yaratma       EXCEPTION;



            ln_eod_tutar                        NUMBER;

            ln_update_tutar                       NUMBER;

            ln_fon_tutar                       NUMBER;

            ls_fon                               VARCHAR2(1);

            ls_fon_kodu                           VARCHAR2(50);

            ln_destek                           NUMBER;

            ln_eod_fisi                           NUMBER;

            ls_overdraft_mi                       varchar2(1);

            ln_musteri_no                        number;

            ls_musteri_tipi_kod                   varchar2(1);

            ln_urun_grup_no                       number;

            ln_musteri_urun_fc_limit           number;

            ln_musteri_urun_fc_risk               number;

            ls_musteri_urun_fc_doviz_kodu       varchar2(3);

            ln_musteri_urun_limit_bosluk       number;

            lb_musteri_urun_limit_var            boolean := false;

            ln_musteri_fc_limit                   number;

            ln_musteri_fc_risk                   number;

            ls_musteri_fc_doviz_kodu           varchar2(3);

            ln_musteri_limit_bosluk                  number;

            lb_musteri_limit_var                   boolean := false;

            ln_musteri_grup_fc_limit           number;

            ln_musteri_grup_fc_risk               number;

            ls_musteri_grup_fc_doviz_kodu       varchar2(3);

            ln_musteri_grup_limit_bosluk       number;

            lb_musteri_grup_limit_var            boolean := false;

            ls_grup_kod                           varchar2(10);

            ln_before_tx_balans                   number;

            ln_risk_update_value               number;

            ln_risk_update_value_urun           number;

            ln_risk_update_value_musteri        number;

            ln_risk_update_value_grup           number;

            ln_risk_update_value_urun_grup       number;

            ln_mus_grup_urun_fc_limit              number;

            ln_mus_grup_urun_fc_risk              number;

            ls_mus_grup_urun_fc_doviz               varchar2(3);

            ln_mus_grup_urun_limit_bosluk         number;

            lb_mus_grup_urun_limit_var               boolean;

            CURSOR hesap_cursor (p_hesapno NUMBER) IS

                  SELECT NVL(b.BAKIYE,0),NVL(b.BLOKE_TUTARI,0),BAKIYE_KARAKTERI

                  FROM CBS_HESAP_BAKIYE b

                  WHERE b.hesap_no=p_hesapno FOR UPDATE;



p_cont_flag number;

ln_grup_urun_grup_no    number := 0;

ln_ovd_cnt number := 0; -- AdiletK 30122014 CQ1236 Real overdraft

ln_proposal_line_no number := 0; -- AdiletK 30122014 CQ1236 Real overdraft

  BEGIN



        SELECT NVL(b.bakiye,0),NVL(b.bloke_tutari,0),bakiye_karakteri

          INTO l_initial_bakiye,ln_bloke_tutari,ls_bakiye_karakteri

          FROM CBS_HESAP_BAKIYE b

         WHERE b.hesap_no=TO_NUMBER(pv_hesap_no)

        FOR UPDATE;



       SELECT h.durum_kodu,h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod, null otomatik_fon, null of_kodu, h.musteri_no, nvl(overdraft,'H')

         INTO ls_durum_kodu,ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod, ls_fon, ls_fon_kodu, ln_musteri_no, ls_overdraft_mi

         FROM cbs_vw_hesap_izleme h

        WHERE h.hesap_no=TO_NUMBER(pv_hesap_no);



       IF ls_durum_kodu='K' THEN

             RAISE Kapali_Hesap_Hareket_Yaratma;

       END IF;



--EOD sirasinda kesilen fislere dikkat et....

--       select count(*)

--         into ln_eod_fisi

--         from cbs_eod_fis_no efn

--        where efn.fis_numara = pn_fis_numara

--          and efn.durum='A';

--

--       if ln_eod_fisi=0 then

      --EOD sirasinda kesilen fis degil. Kontrol edilecek

          SELECT SUM(DECODE(s.tur,'A', NVL(dv_tutar,0), -1*NVL(dv_tutar,0)))

            INTO ln_eod_tutar

            FROM CBS_SATIR s, CBS_EOD_FIS_NO ef

           WHERE s.fis_numara = ef.fis_numara

             AND ef.durum = 'A'

             AND s.hesap_numara = pv_hesap_no

             AND s.hesap_tur_kodu = pv_hesap_turu

             and ef.fis_numara != pn_fis_numara;

--       else  -- bu fis zaten muhasebede kontrol edilmis. Sadece muhasebelesecek...

--          ln_eod_tutar := 0;

--       end if;

------Otomatik fon tutarini ekle

--       IF NVL(ls_fon, 'H') = 'E' THEN

--          ln_fon_tutar := Hesaptaki_OtmFon_Tutarini_al(TO_NUMBER(pv_hesap_no), ls_fon_kodu);

--       ELSE

          ln_fon_tutar := 0;

--       END IF;

--------

       ln_before_tx_balans := l_initial_bakiye;

       ln_update_tutar := l_initial_bakiye;



p_cont_flag := 0;

      if ls_overdraft_mi = 'E' and pv_hesap_turu='VS' then

p_cont_flag := 1;

        destek_hesap_limitleri (pv_hesap_no, pv_doviz_kod, ls_overdraft_mi, ln_musteri_no,

                                  ls_grup_kod, ls_musteri_tipi_kod, ln_urun_grup_no,

                               ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu,

                               ln_musteri_urun_limit_bosluk, lb_musteri_urun_limit_var,

                               ln_musteri_fc_limit, ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,

                               ln_musteri_limit_bosluk, lb_musteri_limit_var,

                               ln_musteri_grup_fc_limit, ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu,

                               ln_musteri_grup_limit_bosluk, lb_musteri_grup_limit_var,

                               ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk, ls_mus_grup_urun_fc_doviz,

                               ln_mus_grup_urun_limit_bosluk, lb_mus_grup_urun_limit_var, ln_destek);

            -- b-o-m  sevalb 040208

            if nvl(ln_destek,0) > 0 and  l_initial_bakiye < 0 and  ls_bakiye_karakteri='P' AND  (pv_tur='B' OR (pv_doviz_kod=Pkg_Genel.LC_AL and pv_lc_tutar<0 ) or (pv_doviz_kod <> Pkg_Genel.LC_AL and pv_fc_tutar<0) )  then

                 l_initial_bakiye :=  0 ;

            end if;

            -- e-o-m  sevalb 040208



      else -- is not an overdraft account

         ln_destek := 0;

      end if;



if p_cont_flag = 1

then

    log_at('qwerty_10a',l_initial_bakiye,ln_eod_tutar,ln_fon_tutar);

    log_at('qwerty_10b',l_last_bakiye,ln_bloke_tutari,pv_tur);

    log_at('qwerty_10c',pv_lc_tutar);

    log_at('qwerty_10d',ln_destek);



end if;

       l_initial_bakiye := l_initial_bakiye + NVL(ln_eod_tutar,0) + ln_fon_tutar + ln_destek;

       IF pv_doviz_kod=Pkg_Genel.LC_AL THEN

             IF pv_tur='A' THEN

               l_last_bakiye:=l_initial_bakiye + pv_lc_tutar;

             ln_update_tutar := ln_update_tutar + pv_lc_tutar;

          ELSE

             l_last_bakiye:=l_initial_bakiye-pv_lc_tutar;

             ln_update_tutar := ln_update_tutar - pv_lc_tutar;

          END IF;



          IF ls_bakiye_karakteri='P' AND (l_last_bakiye-ln_bloke_tutari)<0 AND (pv_tur='B' OR pv_lc_tutar<0) THEN

             log_at('qwerty_10e',l_last_bakiye,ln_bloke_tutari,(l_last_bakiye-ln_bloke_tutari));

             log_at('qwerty_10f',pv_tur,pv_lc_tutar,ls_bakiye_karakteri);

             if ps_force_debit= 'H' then

             log_at('qwerty_10g');

                 RAISE Bakiye_Negatif_Olamaz;

             end if;

          END IF;



            IF ls_bakiye_karakteri='N' AND (nvl(l_last_bakiye,0)-ln_bloke_tutari)>0 AND (pv_tur='A' OR pv_lc_tutar<0) THEN

               RAISE Bakiye_Pozitif_Olamaz;

          END IF;



             UPDATE CBS_HESAP_BAKIYE

           SET bakiye = ln_update_tutar

           WHERE hesap_no=TO_NUMBER(pv_hesap_no);

if p_cont_flag = 1

then

    log_at('qwerty_11',pv_hesap_no,ls_bakiye_karakteri);

    log_at('qwerty_12',l_initial_bakiye,ln_bloke_tutari,ln_destek);

    log_at('qwerty_13',ls_overdraft_mi,ls_grup_kod,ln_urun_grup_no);

    log_at('qwerty_14',ln_musteri_urun_fc_limit,ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk);

    log_at('qwerty_15',ls_musteri_urun_fc_doviz_kodu,ln_musteri_urun_limit_bosluk,ln_musteri_fc_limit);

    log_at('qwerty_16',ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,ln_musteri_limit_bosluk);

    log_at('qwerty_17',ln_musteri_grup_fc_limit,ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu);

    log_at('qwerty_18',ln_musteri_grup_limit_bosluk,ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk);

    log_at('qwerty_19',ls_mus_grup_urun_fc_doviz,ln_mus_grup_urun_limit_bosluk);

end if;

        ELSE --FC

          IF pv_tur='A' THEN

               l_last_bakiye:=l_initial_bakiye+pv_fc_tutar;

             ln_update_tutar := ln_update_tutar + pv_fc_tutar;

          ELSE

               l_last_bakiye:=l_initial_bakiye-pv_fc_tutar;

             ln_update_tutar := ln_update_tutar - pv_fc_tutar;

          END IF;

          IF ls_bakiye_karakteri='P' AND (l_last_bakiye-ln_bloke_tutari)<0 AND (pv_tur='B' OR pv_fc_tutar<0) THEN

             if ps_force_debit= 'H' then

                  RAISE Bakiye_Negatif_Olamaz;

             end if;

          END IF;

            IF ls_bakiye_karakteri='N' AND (l_last_bakiye-ln_bloke_tutari)>0 AND (pv_tur='A' OR pv_fc_tutar<0) THEN

               RAISE Bakiye_Pozitif_Olamaz;

          END IF;



           UPDATE CBS_HESAP_BAKIYE

           SET bakiye = ln_update_tutar

           WHERE hesap_no=TO_NUMBER(pv_hesap_no);

        END IF;

        if ls_overdraft_mi = 'E' then

        --now update risc values

          if ln_before_tx_balans < 0 and ln_update_tutar >= 0 then

             ln_risk_update_value := ln_before_tx_balans;

          elsif ln_before_tx_balans >= 0 and ln_update_tutar < 0 then

             ln_risk_update_value := abs(ln_update_tutar);

          elsif ln_before_tx_balans <= 0 and ln_update_tutar < 0 and (ln_before_tx_balans != ln_update_tutar) then

             ln_risk_update_value := abs(ln_update_tutar-ln_before_tx_balans);

             if ln_before_tx_balans < ln_update_tutar then

                ln_risk_update_value := -1 * ln_risk_update_value;

             end if;

          end if;

          if lb_musteri_grup_limit_var then

            if ls_musteri_grup_fc_doviz_kodu <> pv_doviz_kod then

              --different currencies change to account currency

              ln_risk_update_value_grup := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_musteri_grup_fc_doviz_kodu, NULL,

                                                                             ln_risk_update_value, 1, NULL, NULL, 'N', 'A');

            else

              ln_risk_update_value_grup := ln_risk_update_value;

            end if;



            update cbs_musteri_grup_limit

               set fc_risk = nvl(fc_risk,0) + nvl(ln_risk_update_value_grup,0),

                   nakdi_fc_risk = nvl(nakdi_fc_risk,0) +  nvl(ln_risk_update_value_grup,0)

             where grup_kodu =  ls_grup_kod;

          end if;

          if lb_mus_grup_urun_limit_var then

            if ls_mus_grup_urun_fc_doviz <> pv_doviz_kod then

              --different currencies change to account currency

              ln_risk_update_value_urun_grup := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_mus_grup_urun_fc_doviz, NULL,

                                                                                  ln_risk_update_value, 1, NULL, NULL, 'N', 'A');

            else

              ln_risk_update_value_urun_grup := ln_risk_update_value;

            end if;

        

         --B-O-M sevalb 07092011 destek hesap grup problemi ,grup limitlerine bakilirken musteri tipi X olmali

               if ls_grup_kod is not null then  

                begin

                    select numara

                      into ln_grup_urun_grup_no

                      from CBS_URUN_GRUBU

                     where tanim = 'OVERDRAFT'

                       and musteri_tipi='X';

                     exception

                       when others then

                         RAISE_APPLICATION_ERROR(-20100,l_uc || '1195' || l_ara || pv_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

                  end;

               end if;

           --E-O-M sevalb 07092011 destek hesap grup problemi ,grup limitlerine bakilirken musteri tipi X olmali 

            update cbs_musteri_grub_urun_limit

               set fc_risk = nvl(fc_risk,0) + nvl(ln_risk_update_value_urun_grup,0)

             where grup_kodu =  ls_grup_kod

               and urun_grub_no = ln_grup_urun_grup_no; --sevalb 07092011 bu kisimdaki hata duzeltildi.

          end if;



          if lb_musteri_limit_var then

            if ls_musteri_fc_doviz_kodu <> pv_doviz_kod then

               if ls_musteri_fc_doviz_kodu = ls_musteri_grup_fc_doviz_kodu then

                   ln_risk_update_value_musteri := ln_risk_update_value_grup;

               else

                  ln_risk_update_value_musteri := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_musteri_fc_doviz_kodu, NULL,

                                                                                    ln_risk_update_value, 1, NULL, NULL, 'N', 'A');

               end if;

            else

               ln_risk_update_value_musteri := ln_risk_update_value;

            end if;

            update cbs_musteri_limit

               set fc_risk = nvl(fc_risk,0) + nvl(ln_risk_update_value_musteri,0),

                      nakdi_fc_risk = nvl(nakdi_fc_risk,0) + nvl(ln_risk_update_value_musteri,0)

             where musteri_no = ln_musteri_no;

          end if;

          if lb_musteri_urun_limit_var then

            if ls_musteri_urun_fc_doviz_kodu <> pv_doviz_kod then

               if ls_musteri_urun_fc_doviz_kodu = ls_musteri_grup_fc_doviz_kodu then

                   ln_risk_update_value_urun := ln_risk_update_value_grup;

               else

                   if ls_musteri_urun_fc_doviz_kodu = ls_musteri_fc_doviz_kodu then

                      ln_risk_update_value_urun := ln_risk_update_value_musteri;

                   else

                        ln_risk_update_value_urun := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_musteri_urun_fc_doviz_kodu, NULL,

                                                                                        ln_risk_update_value, 1, NULL, NULL, 'N', 'A');

                   end if;

               end if;

            else

               ln_risk_update_value_urun := ln_risk_update_value;

            end if;

  --B-O-M AdiletK 30122014 CQ1236 Overdraft Risk Update      

            select count(*)

            into ln_ovd_cnt

            from cbs_musteri_urun_limit u, cbs_hesap h

            where u.musteri_no = h.musteri_no and

                      u.musteri_no = ln_musteri_no and

                      u.kredi_teklif_satir_numara = h.ovd_proposal_line_no and

                      u.urun_grub_no = ln_urun_grup_no and

                      h.hesap_no = pv_hesap_no;



            IF ln_ovd_cnt > 0 THEN -- account is directly connected to overdraft

                select nvl(h.ovd_proposal_line_no, 0)

                into ln_proposal_line_no

                from cbs_musteri_urun_limit u, cbs_hesap h

                where u.musteri_no = h.musteri_no and

                          u.musteri_no = ln_musteri_no and

                          u.kredi_teklif_satir_numara = h.ovd_proposal_line_no and

                          u.urun_grub_no = ln_urun_grup_no and

                          h.hesap_no = pv_hesap_no;            

            

                update cbs_musteri_urun_limit

                   set fc_risk = nvl(fc_risk,0) + nvl(ln_risk_update_value_urun,0)

                 where musteri_no = ln_musteri_no

                   and urun_grub_no = ln_urun_grup_no

                   and kredi_teklif_satir_numara = ln_proposal_line_no;

            ELSE -- there is only one overdraft, old logic is used 

                update cbs_musteri_urun_limit

                   set fc_risk = nvl(fc_risk,0) + nvl(ln_risk_update_value_urun,0)

                 where musteri_no = ln_musteri_no

                   and urun_grub_no = ln_urun_grup_no;        

            END IF;

  --E-O-M AdiletK 30122014 CQ1236 Overdraft Risk Update  

          end if;

        end if;

     EXCEPTION

         WHEN Hesap_Bulunamadi_Exception THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pv_hesap_no || l_uc);

         WHEN Bakiye_Yetersiz_Exception THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1403' || l_ara || pv_hesap_no || l_uc);

        WHEN Bakiye_Negatif_Olamaz THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1487' || l_ara || pv_hesap_no || l_uc);

        WHEN Bakiye_Pozitif_Olamaz THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1486' || l_ara || pv_hesap_no || l_uc);

        WHEN Kapali_Hesap_Hareket_Yaratma THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1604' || l_ara || pv_hesap_no || l_uc);

        WHEN OTHERS THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '2462' || l_ara || SQLERRM || l_uc);

  END;



------------------------------------------------------------------------------------------------

PROCEDURE FaizBilgiAl( pn_hesap_no CBS_HESAP_VADELI.HESAP_NO%TYPE,

                        pn_bakiye OUT CBS_HESAP_BAKIYE.bakiye%TYPE,

                        pn_gecen_yil_faizi OUT CBS_HESAP_VADELI.GECEN_YIL_FAIZ_TOPLAMI%TYPE,

                        pn_birikmis_faiz OUT CBS_HESAP.BIRIKMIS_FAIZ_POZ%TYPE) IS

       --ln_bakiye cbs_hes_bak.bakiye%TYPE;

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

            SELECT CBS_HESAP_BAKIYE.bakiye,CBS_HESAP_VADELI.GECEN_YIL_FAIZ_TOPLAMI,CBS_HESAP_VADELI.BIRIKMIS_FAIZ_POZ

            FROM CBS_HESAP_BAKIYE,CBS_HESAP_VADELI

            WHERE CBS_HESAP_VADELI.hesap_no=CBS_HESAP_BAKIYE.hesap_no

            AND CBS_HESAP_VADELI.hesap_no=p_hesapno;



  BEGIN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO pn_bakiye,pn_gecen_yil_faizi,pn_birikmis_faiz;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;



---Hesap Numarasindan sube kodu getirir--------------------------------------------------------------------

  FUNCTION HesaptanSubeAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2 IS

       ls_sube CBS_HESAP.sube_kodu%TYPE;

  BEGIN

        IF  pn_hesap_no IS NOT NULL THEN

          SELECT sube_kodu

            INTO ls_sube

            FROM cbs_vw_hesap_izleme

           WHERE hesap_no = pn_hesap_no;

     END IF;

           RETURN ls_sube;



     EXCEPTION

               WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1170' || l_ara || pn_hesap_no || l_uc);

  END;

----------------------------------------------------------------------------------------

  FUNCTION VadesizHesapVar(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE, ls_doviz CBS_HESAP.DOVIZ_KODU%TYPE) RETURN BOOLEAN IS

       ln_temp NUMBER;

  BEGIN

      SELECT 1

        INTO ln_temp

        FROM cbs_vw_hesap_izleme

       WHERE hesap_no = pn_hesap_no

         AND doviz_kodu = ls_doviz;

       RETURN TRUE;   --problemsiz, buldu..

     EXCEPTION

               WHEN OTHERS THEN

                   RETURN FALSE;   --bulamadi yada problem var....

  END;



----------------------------------------------------------------------------------------

  FUNCTION HesapKisaIsimAl(pn_hesap_no cbs_vw_hesap_izleme.HESAP_NO%TYPE) RETURN VARCHAR2 IS

      ls_kisa_isim                        VARCHAR2(30);

  BEGIN

         SELECT kisa_isim

       INTO ls_kisa_isim

       FROM cbs_vw_hesap_izleme

       WHERE hesap_no = pn_hesap_no;



       RETURN ls_kisa_isim;

EXCEPTION

         WHEN NO_DATA_FOUND THEN

               RETURN NULL;

  END;

--------------------

  PROCEDURE VadesizBilgiAktar(pn_hesap_no IN cbs_vw_hesap_izleme.HESAP_NO%TYPE,p_txno IN NUMBER) IS

  BEGIN

          insert into cbs_hesap_g_basvuru

         (tx_no, musteri_no, hesap_numarasi, modul_tur_kod, urun_tur_kod, urun_sinif_kod, kisa_isim, doviz_kodu, 

         cek_karnesi, hesap_hareket_kodu, min_para_tutari, aciklama, esas_gun_sayisi, faiz_orani, faiz_indikatoru, 

         bakiye_turu, min_faiz_tutari, ekstre_basim_kodu, ekstre_sikligi, dekont, sube_kodu, min_imza_adedi, 

         durum_kodu, birikmis_faiz_poz,external_hesap_no,next_interest_calc_date,sirket_hesabimi,

         interest_payment_period, overdraft, ovd_esas_gun_sayisi, ovd_faiz_orani, ovd_faiz_indikatoru, 

         ovd_interest_payment_period, ovd_dk_no,gecmis_aylarin_faizi,faiz_odeme_hesap_no,

         direct_debit,direct_debit_annual,direct_debit_annual_amount, ovd_proposal_line_no )-- 30122014 AdiletK CQ1236 ovd_proposal_line_no is added for real overdrafts

            select p_txno,musteri_no, hesap_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod, kisa_isim, doviz_kodu, 

                   cek_karnesi, hesap_hareket_kodu, min_para_tutari, aciklama, esas_gun_sayisi, faiz_orani, faiz_indikatoru, 

                   bakiye_turu, min_faiz_tutari, ekstre_basim_kodu, ekstre_sikligi, dekont, sube_kodu, min_imza_adedi, 

                   durum_kodu, birikmis_faiz_poz,external_hesap_no,next_interest_calc_date,sirket_hesabimi,

                   interest_payment_period, overdraft, ovd_esas_gun_sayisi, ovd_faiz_orani, ovd_faiz_indikatoru, 

                   ovd_interest_payment_period, ovd_dk_no,gecmis_aylarin_faizi,faiz_odeme_hesap_no,

                   direct_debit,direct_debit_annual,direct_debit_annual_amount, ovd_proposal_line_no -- 30122014 AdiletK CQ1236 ovd_proposal_line_no is added for real overdrafts                      

            from cbs_hesap

            where hesap_no=pn_hesap_no;



        insert into cbs_hesap_ortak_bilgi_basvuru

            (tx_no,ana_hesap_no, ortak_musteri_no, ortak_adi_soyadi, ortaklik_tipi, min_imza_adet, authorization_date, validity_date, authorization_type, status)

            select p_txno,ana_hesap_no, ortak_musteri_no, ortak_adi_soyadi, ortaklik_tipi, min_imza_adet, authorization_date, validity_date, authorization_type, status

            from cbs_hesap_ortak_bilgi

            where ana_hesap_no=pn_hesap_no;

    EXCEPTION

             WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1283' || l_ara || SQLERRM || l_uc);

  END;

----

--------------------

  PROCEDURE VadeliBilgiAktar(pn_hesap_no IN cbs_vw_hesap_izleme.HESAP_NO%TYPE,

                               p_txno IN NUMBER,

                               p_tran_type IN VARCHAR2) IS

  BEGIN

          INSERT INTO CBS_HESAP_VADELI_G_BASVURU

        (TX_NO,ACIKLAMA, ACILIS_TARIHI, ARA_ODEME_BILGISI, ARA_ODEME_ISLEM_BILGISI, BIRIKMIS_FAIZ_NEG,

         BIRIKMIS_FAIZ_POZ, BORC_KAYDI, BORCLU_HESAP_NO, DEKONT, DK_NO, DOVIZ_KODU, DURUM_KODU, EKSTRE_BASIM_KODU,

         EKSTRE_SIKLIGI, ESAS_GUN_SAYISI, FAIZ_ORANI, GECEN_YIL_FAIZ_TOPLAMI, GERI_DONUS_HESAPNO,

         HESAP_NO, KAPAMA_TARIHI, KISA_ISIM, MIN_IMZA_ADEDI, MODUL_TUR_KOD, MUHABIR_HESAP_NO, MUHASEBE_TARIHI,

         MUSTERI_DK_NO, MUSTERI_NO, ODENMIS_FAIZ_TOPLAMI, OTOMATIK_TEMDIT, PERIOD_CINS, PERIOD_SURE, REFERANS,

         SONRAKI_BASLANGIC_TARIHI, SUBE_KODU, TUTAR, URUN_SINIF_KOD, URUN_TUR_KOD, VADE_ISLEM_BILGISI,

         VADE_TARIHI, VALOR_TARIHI,ISTATISTIK_KODU_ALIS, PREFIX_ISTATISTIK_KODU_ALIS, NAKIT_KODU_ALIS,

         ISTATISTIK_KODU_KAPAMA, PREFIX_ISTATISTIK_KODU_KAPAMA, ISTATISTIK_KODU_FAIZ, PREFIX_ISTATISTIK_KODU_FAIZ,

         SIRKET_HESABIMI,VERGI_ORANI, NET_FAIZ,GECMIS_AYLARIN_FAIZI,TRAN_TYPE, VADE_PERIOD_SURE, VADE_PERIOD_CINS --chyngyzo cq808 added 2 columns (VADE_PERIOD_SURE, VADE_PERIOD_CINS)
        
         ,ACCRUAL_INT_ACCOUNT_NO , ACCRUAL_INT_ACCOUNT_NO_BAKIYE        -- seval.colak 04112021 accrual modification
         ) 

            SELECT p_txno,ACIKLAMA, ACILIS_TARIHI, ARA_ODEME_BILGISI, ARA_ODEME_ISLEM_BILGISI,BIRIKMIS_FAIZ_NEG,

                   BIRIKMIS_FAIZ_POZ,BORC_KAYDI,BORCLU_HESAP_NO,DEKONT,DK_NO,DOVIZ_KODU,DURUM_KODU, EKSTRE_BASIM_KODU,

                   EKSTRE_SIKLIGI, ESAS_GUN_SAYISI, FAIZ_ORANI, GECEN_YIL_FAIZ_TOPLAMI,GERI_DONUS_HESAPNO,

                   HESAP_NO, KAPAMA_TARIHI, KISA_ISIM, MIN_IMZA_ADEDI, MODUL_TUR_KOD, MUHABIR_HESAP_NO, MUHASEBE_TARIHI,

                   MUSTERI_DK_NO, MUSTERI_NO, ODENMIS_FAIZ_TOPLAMI, OTOMATIK_TEMDIT, PERIOD_CINS, PERIOD_SURE, REFERANS,

                   SONRAKI_BASLANGIC_TARIHI, SUBE_KODU, TUTAR, URUN_SINIF_KOD, URUN_TUR_KOD, VADE_ISLEM_BILGISI,

                   VADE_TARIHI, VALOR_TARIHI,ISTATISTIK_KODU_ALIS, PREFIX_ISTATISTIK_KODU_ALIS, NAKIT_KODU_ALIS,

                   ISTATISTIK_KODU_KAPAMA, PREFIX_ISTATISTIK_KODU_KAPAMA, ISTATISTIK_KODU_FAIZ, PREFIX_ISTATISTIK_KODU_FAIZ,

                   SIRKET_HESABIMI,VERGI_ORANI, NET_FAIZ,GECMIS_AYLARIN_FAIZI,p_tran_type, VADE_PERIOD_SURE, VADE_PERIOD_CINS --chyngyzo cq808 added 2 columns (VADE_PERIOD_SURE, VADE_PERIOD_CINS)
                
                    ,ACCRUAL_INT_ACCOUNT_NO , CASE WHEN NVL(ACCRUAL_INT_ACCOUNT_NO,0)<>0 THEN PKG_HESAP.HESAPBAKIYEAL(ACCRUAL_INT_ACCOUNT_NO) ELSE 0 END  ACCRUAL_INT_ACCOUNT_NO_BAKIYE        -- seval.colak 04112021 accrual modification 
            FROM CBS_HESAP_VADELI

            WHERE HESAP_NO=pn_hesap_no;



        INSERT INTO CBS_HESAP_ORTAK_BILGI_BASVURU

            (tx_no,ANA_HESAP_NO, ORTAK_MUSTERI_NO, ORTAK_ADI_SOYADI, ORTAKLIK_TIPI, MIN_IMZA_ADET, AUTHORIZATION_DATE, VALIDITY_DATE, AUTHORIZATION_TYPE, STATUS)

            SELECT p_txno,ANA_HESAP_NO, ORTAK_MUSTERI_NO, ORTAK_ADI_SOYADI, ORTAKLIK_TIPI, MIN_IMZA_ADET, AUTHORIZATION_DATE, VALIDITY_DATE, AUTHORIZATION_TYPE, STATUS

            FROM CBS_HESAP_ORTAK_BILGI

            WHERE ana_hesap_no=pn_hesap_no;



    EXCEPTION

             WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1283' || l_ara || SQLERRM || l_uc);

  END;

----

FUNCTION HesaptanDovizKoduAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2 IS

       ls_doviz CBS_HESAP.doviz_kodu%TYPE;

  BEGIN

     IF  pn_hesap_no IS NOT NULL THEN

       SELECT   doviz_kodu

        INTO ls_doviz

        FROM cbs_vw_hesap_izleme

       WHERE hesap_no = pn_hesap_no;

     END IF;

       RETURN ls_doviz;

     EXCEPTION

               WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1171' || l_ara || pn_hesap_no || l_uc);

  END;



--------------

   FUNCTION HesapSubeAl(pn_hesap_no    IN cbs_vw_hesap_izleme.HESAP_NO%TYPE) RETURN VARCHAR2 IS

        ls_sube_kodu                    VARCHAR2(10);

   BEGIN

           SELECT   sube_kodu

        INTO ls_sube_kodu

        FROM cbs_vw_hesap_izleme

        WHERE hesap_no = pn_hesap_no;



       RETURN ls_sube_kodu;

   EXCEPTION

                   WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);



   END;

----------------------

   FUNCTION IndikatorOranBul(pn_indikator_no     NUMBER) RETURN NUMBER IS

      ln_faiz_orani    NUMBER;

   BEGIN

           SELECT CBS_FAIZ_INDIKATORU.FAIZ_ORANI

        INTO ln_faiz_orani

        FROM CBS_FAIZ_INDIKATORU

        WHERE CBS_FAIZ_INDIKATORU.INDIKATOR_NO=pn_indikator_no;



        RETURN ln_faiz_orani;

   EXCEPTION

           WHEN NO_DATA_FOUND THEN

             RETURN NULL;

   END;



  /*****************************************************************************************************************/

  /*   Function     Kullanilabilir_Bakiye_Al                                                                                 */

  /*   Hesabin kullanilabilir bakiyesini getirir                                                                   */

  /*****************************************************************************************************************/

  FUNCTION Kullanilabilir_Bakiye_Al(pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE ) RETURN CBS_HESAP_BAKIYE.bakiye%TYPE

   IS

     ln_bakiye CBS_HESAP_BAKIYE.bakiye%TYPE;

     ln_eod_tutar   NUMBER;

     ln_fon_tutar    NUMBER;

     ls_fon            VARCHAR2(1);

     ls_fon_kodu    VARCHAR2(50);

     ln_destek        NUMBER;

     pv_doviz_kod   varchar2(3);

            ls_overdraft_mi                       varchar2(1);

            ln_musteri_no                        number;

            ls_musteri_tipi_kod                   varchar2(1);

            ln_urun_grup_no                       number;

            ln_musteri_urun_fc_limit           number;

            ln_musteri_urun_fc_risk               number;

            ls_musteri_urun_fc_doviz_kodu       varchar2(3);

            ln_musteri_urun_limit_bosluk       number;

            lb_musteri_urun_limit_var            boolean;

            ln_musteri_fc_limit                   number;

            ln_musteri_fc_risk                   number;

            ls_musteri_fc_doviz_kodu           varchar2(3);

            ln_musteri_limit_bosluk                  number;

            lb_musteri_limit_var                   boolean;

            ln_musteri_grup_fc_limit           number;

            ln_musteri_grup_fc_risk               number;

            ls_musteri_grup_fc_doviz_kodu       varchar2(3);

            ln_musteri_grup_limit_bosluk       number;

            lb_musteri_grup_limit_var            boolean;

            ls_grup_kod                           varchar2(10);

            ln_mus_grup_urun_fc_limit           number;

            ln_mus_grup_urun_fc_risk           number;

            ls_mus_grup_urun_fc_doviz           varchar2(3);

            ln_mus_grup_urun_limit_bosluk       number;

            lb_mus_grup_urun_limit_var           boolean;

            LN_BLOKE                           NUMBER;

   BEGIN



      SELECT NVL(bakiye,0) ,NVL(bloke_tutari,0)

      INTO  ln_bakiye, LN_BLOKE

      FROM  CBS_HESAP_BAKIYE

      WHERE hesap_no = pn_hesap_no;



      SELECT SUM(DECODE(s.tur,'A', NVL(dv_tutar,0), -1*NVL(dv_tutar,0)))

        INTO ln_eod_tutar

        FROM CBS_SATIR s, CBS_EOD_FIS_NO ef

       WHERE s.fis_numara = ef.fis_numara

         AND ef.durum = 'A'

         AND s.hesap_numara = pn_hesap_no

         AND s.hesap_tur_kodu <> 'DK';



       SELECT h.musteri_no, nvl(overdraft,'H'), doviz_kodu

         INTO ln_musteri_no, ls_overdraft_mi, pv_doviz_kod

         FROM cbs_vw_hesap_izleme h

        WHERE h.hesap_no=pn_hesap_no;



--------Otomatik fon tutarini ekle

--       SELECT otomatik_fon, of_kodu

--         INTO ls_fon, ls_fon_kodu

--         FROM cbs_vw_hesap_izleme h

--        WHERE h.hesap_no=pn_hesap_no;



--oto fon       IF NVL(ls_fon, 'H') = 'E' THEN

--          ln_fon_tutar := Hesaptaki_OtmFon_Tutarini_al(pn_hesap_no, ls_fon_kodu);

--       ELSE

          ln_fon_tutar := 0;

--       END IF;

--------

      if ls_overdraft_mi = 'E' then

        destek_hesap_limitleri (pn_hesap_no, pv_doviz_kod, ls_overdraft_mi, ln_musteri_no,

                                  ls_grup_kod, ls_musteri_tipi_kod, ln_urun_grup_no,

                               ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu,

                               ln_musteri_urun_limit_bosluk, lb_musteri_urun_limit_var,

                               ln_musteri_fc_limit, ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,

                               ln_musteri_limit_bosluk, lb_musteri_limit_var,

                               ln_musteri_grup_fc_limit, ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu,

                               ln_musteri_grup_limit_bosluk, lb_musteri_grup_limit_var,

                               ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk, ls_mus_grup_urun_fc_doviz,

                               ln_mus_grup_urun_limit_bosluk, lb_mus_grup_urun_limit_var, ln_destek);



      else -- is not an overdraft account

         ln_destek := 0;

      end if;



      if ln_bakiye < 0 AND NVL(ln_destek,0) <> 0

      then

          ln_bakiye :=  0 + NVL(ln_eod_tutar,0) + ln_fon_tutar + ln_destek - NVL(LN_BLOKE,0);

      else

          ln_bakiye :=  ln_bakiye + NVL(ln_eod_tutar,0) + ln_fon_tutar + ln_destek  - NVL(LN_BLOKE,0);

      end if;



     RETURN NVL(ln_bakiye,0);



    EXCEPTION

     WHEN NO_DATA_FOUND THEN RETURN 0 ;

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '248' ||Pkg_Hata.getdelimiter || TO_CHAR(pn_hesap_no) || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' ||SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);



   END Kullanilabilir_Bakiye_Al;



  /*****************************************************************************************************************/

  /*   Function     Bloke_Tutari_Al                                                                                 */

  /*   Hesabin bloke tutari getirir                                                                   */

  /*****************************************************************************************************************/

  FUNCTION Bloke_Tutari_Al(pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE ) RETURN CBS_HESAP_BAKIYE.bloke_tutari%TYPE

   IS

     ln_bloke_tutari CBS_HESAP_BAKIYE.bloke_tutari%TYPE;

   BEGIN



      SELECT NVL(bloke_tutari,0)

      INTO  ln_bloke_tutari

      FROM  CBS_HESAP_BAKIYE

      WHERE hesap_no = pn_hesap_no;



    RETURN NVL(ln_bloke_tutari,0);



    EXCEPTION

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '250' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' ||SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);



   END Bloke_Tutari_Al;

  /*****************************************************************************************************************/

   PROCEDURE BlokeTutariGuncelle(pn_hesap_no CBS_HESAP_BAKIYE.HESAP_NO%TYPE,pn_bloke_tutari    CBS_HESAP_BAKIYE.BLOKE_TUTARI%TYPE) IS

       blokenegatifdeger EXCEPTION;

       ln_tutar  NUMBER :=0 ;

   BEGIN



           SELECT NVL(bloke_tutari,0)+ pn_bloke_tutari

        INTO ln_tutar

        FROM CBS_HESAP_BAKIYE

        WHERE hesap_no=pn_hesap_no;



        IF  ln_tutar < 0  THEN

          RAISE  blokenegatifdeger;

        ELSE

               UPDATE CBS_HESAP_BAKIYE

            SET bloke_tutari=ln_tutar

            WHERE hesap_no=pn_hesap_no;

        END IF;



     EXCEPTION

       WHEN blokenegatifdeger THEN

                RAISE_APPLICATION_ERROR(-20100,l_uc || '1501' || l_ara || pn_hesap_no || l_uc);

           WHEN OTHERS THEN

             RAISE_APPLICATION_ERROR(-20100,l_uc || '1489' || l_ara || pn_hesap_no || l_uc);

   END;

 /*****************************************************************************************************************/

    FUNCTION BasvuruOrtakSayisiAl(pn_tx_no NUMBER) RETURN NUMBER IS

        ln_ortak_sayi NUMBER;

    BEGIN

         SELECT COUNT(*)

         INTO ln_ortak_sayi

         FROM CBS_HESAP_ORTAK_BILGI_BASVURU

         WHERE tx_no=pn_tx_no;



         RETURN ln_ortak_sayi;

    END;

  /*****************************************************************************************************************/

  FUNCTION HesapCekBilgisiAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2 IS

      ls_cek_karnesi    CBS_HESAP.CEK_KARNESI%TYPE;

  BEGIN

         SELECT cek_karnesi

       INTO ls_cek_karnesi

       FROM CBS_HESAP

       WHERE CBS_HESAP.hesap_no=pn_hesap_no;



       RETURN ls_cek_karnesi;

  END;

 /*****************************************************************************************************************/

  FUNCTION HesapCekBilgisiSil(pn_musteri_no CBS_HESAP.HESAP_NO%TYPE) RETURN BOOLEAN IS

  BEGIN

         UPDATE CBS_HESAP

       SET cek_karnesi='H'

       WHERE CBS_HESAP.musteri_no=pn_musteri_no

       AND cek_karnesi='E';



       RETURN TRUE;

 EXCEPTION

          WHEN OTHERS THEN

               RETURN FALSE;

  END;

 /*****************************************************************************************************************/

 FUNCTION GecerliDKHesap(ps_dkhesap VARCHAR2,ps_bolum_kodu VARCHAR2, ps_doviz_kodu VARCHAR2) RETURN BOOLEAN IS

     CURSOR dk_cursor IS

        SELECT * FROM CBS_DKHESAP

     WHERE doviz_kod=ps_doviz_kodu

     AND numara=ps_dkhesap

     AND bolum_kodu=ps_bolum_kodu;



    dk_row     dk_cursor%ROWTYPE;

 BEGIN

          OPEN dk_cursor;

       FETCH dk_cursor INTO dk_row;

       IF dk_cursor%NOTFOUND THEN

                RETURN FALSE;

       ELSE

              RETURN TRUE;

       END IF;

       CLOSE dk_cursor;

 END;

 /*****************************************************************************************************************/

/* FUNCTION HareketliBakiyeHesapla(pn_hesap_no NUMBER,pn_fis_numara NUMBER,pn_satir_no NUMBER) RETURN NUMBER IS

     ln_bakiye                                 NUMBER;

     ln_sum_hareket                                 NUMBER;



    CURSOR cursor_hareket IS

        SELECT SUM(DECODE(satir.tur, 'A', satir.dv_tutar, -1*satir.dv_tutar))

        FROM cbs_fis fis, cbs_satir satir

        WHERE fis.numara = satir.fis_numara and FIS.TUR='G'

        AND    SATIR.HESAP_NUMARA=TO_CHAR(pn_hesap_no)

        AND FIS.NUMARA>=pn_fis_numara

        AND SATIR.NUMARA>DECODE(FIS.NUMARA,pn_fis_numara,pn_satir_no,-1);

 BEGIN

     SELECT bakiye

    INTO ln_bakiye

    FROM CBS_HESAP_BAKIYE

    WHERE hesap_no=pn_hesap_no;



    OPEN cursor_hareket;

    FETCH cursor_hareket INTO ln_sum_hareket;

    IF cursor_hareket%NOTFOUND THEN

       ln_sum_hareket:=0;

    END IF;

    CLOSE cursor_hareket;



    select SUM(SATIR_DV_TUTAR)

    into ln_sum_hareket

    from CBS_VW_FIS_SATIR h

    where SATIR_HESAP_NUMARA=pn_hesap_no AND FIS_TUR='G'

    and FIS_NUMARA>=pn_fis_numara

    and SATIR_NUMARA>Decode(FIS_NUMARA,pn_fis_numara,pn_satir_no,-1);



    RETURN (ln_bakiye-NVL(ln_sum_hareket,0));

 END;*/



FUNCTION HareketliBakiyeHesapla(pn_hesap_no NUMBER,pn_fis_numara NUMBER,pn_satir_no NUMBER) RETURN NUMBER IS

   PRAGMA AUTONOMOUS_TRANSACTION;

     ln_bakiye NUMBER;

     ln_sum_hareket NUMBER;

    ls_count       VARCHAR2(1);

    ln_balance_after      NUMBER;



    CURSOR cursor_hareket IS

        SELECT SUM(satir_dv_tutar)--SUM(DECODE(tur, 'A', dv_tutar, -1*dv_tutar))

          FROM cbs_vw_fis_satir

         WHERE fis_tur = 'G' AND

               satir_HESAP_NUMARA = TO_CHAR(pn_hesap_no) AND

               FIS_NUMARA >= pn_fis_numara AND

               FIS_MUHASEBELESTIGI_TARIH IS NOT NULL AND

               satir_NUMARA > DECODE(FIS_NUMARA, pn_fis_numara, pn_satir_no,-1);

 BEGIN



     SELECT balance_flag,balance_after

    INTO ls_count,ln_balance_after

     FROM CBS_SATIR

    WHERE fis_numara = pn_fis_numara

    AND numara=pn_satir_no;



    IF ls_count='0' THEN

        SELECT bakiye

        INTO ln_bakiye

        FROM CBS_HESAP_BAKIYE

        WHERE hesap_no=pn_hesap_no;



        OPEN cursor_hareket;

        FETCH cursor_hareket INTO ln_sum_hareket;

        IF cursor_hareket%NOTFOUND THEN

           ln_sum_hareket:=0;

        END IF;

        CLOSE cursor_hareket;



        UPDATE CBS_SATIR

          SET balance_flag = '1',

                balance_after = ln_bakiye-NVL(ln_sum_hareket,0)

        WHERE fis_numara = pn_fis_numara

              AND numara=pn_satir_no;



        /*update cbs_satir

          set balance_flag= '0'

         where fis_numara > pn_fis_numara

         and hesap_numara in (select hesap_numara from cbs_satir

         where pn_fis_numara=fis_numara

         and hesap_tur_kodu in ('VS','VD','KR'));*/



          COMMIT;



         RETURN (ln_bakiye-NVL(ln_sum_hareket,0));

    END IF;

         RETURN ln_balance_after;

 END;



  /*****************************************************************************************************************/

  /*  Procedure hesap_bakiye_olustur                                                                                        */

  /*  hesap bakiye tablosuna giris yapar                                                                           */

  /*****************************************************************************************************************/

 PROCEDURE hesap_bakiye_olustur( pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE,

                                     pn_bakiye CBS_HESAP_BAKIYE.hesap_no%TYPE,

                                 pn_bloke_tutari CBS_HESAP_BAKIYE.bloke_tutari%TYPE,

                                 pn_valorlu_bakiye CBS_HESAP_BAKIYE.bloke_tutari%TYPE,

                                 pn_bakiye_karakteri  CBS_HESAP_BAKIYE.bakiye_karakteri%TYPE DEFAULT NULL) IS

        ls_bakiye_karakteri                              CBS_HESAP_BAKIYE.bakiye_karakteri%TYPE;

  BEGIN



/*       if pn_bakiye_karakteri is null then

             select PKG_PARAMETRE.DEGER(h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod,'BAKIYE_KARAKTERI')

          into ls_bakiye_karakteri

          from CBS_VW_HESAP_IZLEME h

          where h.hesap_no=pn_hesap_no;

       else

              ls_bakiye_karakteri:=pn_bakiye_karakteri;

       end if;

*/

            INSERT INTO CBS_HESAP_BAKIYE (hesap_no,

                                             bakiye,

                                        bloke_tutari,

                                        valorlu_bakiye,

                                        bakiye_karakteri)

                       VALUES           (pn_hesap_no,

                                           pn_bakiye,

                                        pn_bloke_tutari,

                                        pn_valorlu_bakiye,

                                        pn_bakiye_karakteri

                                        );



   EXCEPTION

      WHEN OTHERS THEN

         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '508' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

  END;

---------------------------------------------------------------------------------

--B-O-M sevalb  11102012 6270_Automatic loading of customer information from CBS to Card system 2000 body den External hesap no bulmasi alindi.pkg_hesap bodye eklendi

function generate_external_hesapno (pn_hesap_no number) 

return varchar2 is

ls_external_hesap_no     cbs_hesap.external_hesap_no%type;

ln_controlcode  number;

begin



   ln_controlcode:= mod(to_number(

                               pkg_genel.bankamiz_kodu_al || lpad (pn_hesap_no,11,'0')

                               ),97

                       );

    if ln_controlcode=0 then

      ln_controlcode:=97;

    end if;



    ls_external_hesap_no := pkg_genel.bankamiz_kodu_al || lpad (pn_hesap_no,11,'0') || lpad (to_char(ln_controlcode), 2,'0');



    return ls_external_hesap_no;



    exception when others then return null;

end;

--E-O-M sevalb  11102012 

---------------------------

  FUNCTION VadesizHesapAcilis(pn_musteri_no NUMBER,

                               ps_modul_tur_kod VARCHAR2,

                               ps_urun_tur_kod VARCHAR2,

                          ps_urun_sinif_kod VARCHAR2,

                          ps_doviz_kodu        VARCHAR2,

                          ps_bolum_kodu        VARCHAR2,

                          ps_kisaisim        VARCHAR2 DEFAULT 'GN Hesap',

                          ps_cek_karnesi    VARCHAR2 DEFAULT 'H',

                          pn_hesap_hareket_kodu    NUMBER DEFAULT 1,

                          ps_dekont                VARCHAR2 DEFAULT 'X',

                          ps_ekstre_kodu        VARCHAR2 DEFAULT 'X',

                            pn_esas_gun_sayisi    NUMBER DEFAULT 365,

                          pd_acilis_tarihi     DATE DEFAULT Pkg_Muhasebe.Banka_Tarihi_Bul

                          ) RETURN NUMBER IS



    ls_dkgrup_kodu          CBS_MUSTERI.DK_GRUP_KOD%TYPE;

    lv_musteri_dkno          CBS_HESAP.MUSTERI_DK_NO%TYPE;

    ln_hesap_no              NUMBER;

    ls_EXTERNAL_HESAP_NO    cbs_hesap.external_hesap_no%type;--sevalb 11102012

BEGIN



    SELECT CBS_MUSTERI.DK_GRUP_KOD

    INTO ls_dkgrup_kodu

    FROM CBS_MUSTERI

    WHERE CBS_MUSTERI.musteri_no=pn_musteri_no;



    Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, ps_modul_tur_kod, ps_urun_tur_kod,ps_urun_sinif_kod, 1, NULL, NULL, NULL, lv_musteri_dkno);



    ln_hesap_no:=Pkg_Genel.genel_kod_al('HESAP.VDSZ');

    --B-O-M sevalb 11102012 6270_Automatic loading of customer information from CBS to Card system  EXTERNAL_HESAP_NO eklendi

    if ps_modul_tur_kod ='CURRENT' and  ps_urun_tur_kod = 'DEMAND DEP' and  ps_urun_sinif_kod in ('NON INT.BEARING-LC','NON INT.BEARING-FC' ) then  --sevalb 18042013 

        begin

        ls_external_hesap_no := generate_external_hesapno(ln_hesap_no);

        exception when others then null;

        end;

    end if;

    --E-O-M sevalb 11102012  6270_Automatic loading of customer information from CBS to Card system EXTERNAL_HESAP_NO eklendi



    INSERT INTO CBS_HESAP

    (MUSTERI_NO, HESAP_NO, MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,KISA_ISIM, DOVIZ_KODU, CEK_KARNESI, HESAP_HAREKET_KODU, EKSTRE_BASIM_KODU, DEKONT,DURUM_KODU, SUBE_KODU, MUSTERI_DK_NO,ESAS_GUN_SAYISI, ACILIS_TARIHI,EXTERNAL_HESAP_NO)   --sevalb 11102012   EXTERNAL_HESAP_NO eklendi

    VALUES

    (pn_musteri_no, ln_hesap_no, 'CURRENT',ps_urun_tur_kod,ps_urun_sinif_kod,ps_kisaisim, ps_doviz_kodu, ps_cek_karnesi, pn_hesap_hareket_kodu,ps_ekstre_kodu, ps_dekont, 'A', ps_bolum_kodu, lv_musteri_dkno,pn_esas_gun_sayisi,pd_acilis_tarihi,ls_EXTERNAL_HESAP_NO);



    Pkg_Hesap.HESAP_BAKIYE_OLUSTUR(ln_hesap_no,0, 0, 0,Pkg_Parametre.DEGER('CURRENT', ps_urun_tur_kod,ps_urun_sinif_kod,'BAKIYE_KARAKTERI'));



    RETURN ln_hesap_no;

END;

---------------------------------------------------------------------------------

  FUNCTION VadeliHesapAcilis(pn_MUSTERI_NO       NUMBER,

                            ps_MODUL_TUR_KOD VARCHAR2,

                            ps_URUN_TUR_KOD VARCHAR2,

                            ps_URUN_SINIF_KOD VARCHAR2,

                            ps_KISA_ISIM VARCHAR2,

                            ps_DOVIZ_KODU VARCHAR2,

                            ps_SUBE_KODU VARCHAR2,

                            pn_TUTAR NUMBER,

                            pd_VALOR_TARIHI DATE,

                            pn_VADE_ISLEM_BILGISI NUMBER,

                            pn_ARA_ODEME_BILGISI NUMBER,

                            ps_OTOMATIK_TEMDIT VARCHAR2,

                            pn_PERIOD_SURE NUMBER,

                            ps_PERIOD_CINS VARCHAR2,

                            pd_SONRAKI_BASLANGIC_TARIHI DATE,

                            pn_ARA_ODEME_ISLEM_BILGISI NUMBER,

                            pd_VADE_TARIHI DATE,

                            pn_GERI_DONUS_HESAPNO NUMBER,

                            pn_ESAS_GUN_SAYISI NUMBER,

                            pn_FAIZ_ORANI NUMBER,

                            ps_ACIKLAMA VARCHAR2,

                            ps_REFERANS    VARCHAR2,

                            ps_EKSTRE_BASIM_KODU VARCHAR2 DEFAULT 'X',

                            ps_EKSTRE_SIKLIGI VARCHAR2 DEFAULT NULL,

                            ps_DEKONT VARCHAR2 DEFAULT 'X',

                            pd_acilis_tarihi DATE DEFAULT Pkg_Muhasebe.Banka_Tarihi_Bul,

                            ps_islemturu        VARCHAR2 DEFAULT NULL) RETURN NUMBER IS



    ls_dkgrup_kodu          CBS_MUSTERI.DK_GRUP_KOD%TYPE;

    lv_musteri_dkno          CBS_HESAP.MUSTERI_DK_NO%TYPE;

    ln_hesap_no              NUMBER;
    -- b-o-m seval.colak 04112021  accrual modification
        ln_accrual_int_accountno        number; 
        ls_accrual_int_account_glno     cbs_hesap.musteri_dk_no%type;
        ls_bakiye_karakteri             varchar2(1) ;
        ls_accrual_int_urun_sinif       cbs_hesap_vadeli.urun_sinif_kod%type;  
     -- e-o-m seval.colak 04112021

    GecerliDKHesap_Bulunamadi            EXCEPTION;
    
    GecerliTRLDKHesap_Bulunamadi        EXCEPTION;


BEGIN



    SELECT CBS_MUSTERI.DK_GRUP_KOD

    INTO ls_dkgrup_kodu

    FROM CBS_MUSTERI

    WHERE CBS_MUSTERI.musteri_no=pn_musteri_no;



    --3-faiz Gider DK

    Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, Pkg_Hesap.modul_tur_vadeli, ps_urun_tur_kod,ps_urun_sinif_kod, 3, NULL, NULL, NULL, lv_musteri_dkno);

    /*IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_KODU,ps_doviz_kodu ) THEN

       RAISE GecerliDKHesap_Bulunamadi;

    END IF;

    */

    IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_kodu,Pkg_Genel.LC_AL) THEN

       RAISE GecerliTRLDKHesap_Bulunamadi;

    END IF;


    --4-reeskont DK

    Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, Pkg_Hesap.modul_tur_vadeli, ps_urun_tur_kod,ps_urun_sinif_kod, 4, NULL, NULL, NULL, lv_musteri_dkno);
    ls_accrual_int_account_glno :=lv_musteri_dkno;
    
    IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_kodu,ps_doviz_kodu ) THEN

       RAISE GecerliDKHesap_Bulunamadi;

    END IF;

    --ANA DK

    Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, Pkg_Hesap.modul_tur_vadeli, ps_urun_tur_kod,ps_urun_sinif_kod, 1, NULL, NULL, NULL, lv_musteri_dkno);

    ln_hesap_no:=Pkg_Genel.genel_kod_al('HESAP.VDSZ');

    INSERT INTO CBS_HESAP_VADELI

    (MUSTERI_NO,HESAP_NO,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,KISA_ISIM,DOVIZ_KODU,SUBE_KODU,TUTAR,VALOR_TARIHI,VADE_ISLEM_BILGISI,ARA_ODEME_BILGISI,OTOMATIK_TEMDIT,PERIOD_SURE,PERIOD_CINS,SONRAKI_BASLANGIC_TARIHI,ARA_ODEME_ISLEM_BILGISI,VADE_TARIHI,GERI_DONUS_HESAPNO,ESAS_GUN_SAYISI,FAIZ_ORANI,ACIKLAMA,REFERANS,EKSTRE_BASIM_KODU,EKSTRE_SIKLIGI,DEKONT, ACILIS_TARIHI,DURUM_KODU,MUSTERI_DK_NO,ISLEM_TURU)

    VALUES

    (pn_MUSTERI_NO,ln_hesap_no,Pkg_Hesap.modul_tur_vadeli,ps_URUN_TUR_KOD,ps_URUN_SINIF_KOD,ps_KISA_ISIM,ps_DOVIZ_KODU,ps_SUBE_KODU,pn_TUTAR,pd_VALOR_TARIHI,pn_VADE_ISLEM_BILGISI,pn_ARA_ODEME_BILGISI,ps_OTOMATIK_TEMDIT,pn_PERIOD_SURE,ps_PERIOD_CINS,pd_SONRAKI_BASLANGIC_TARIHI,pn_ARA_ODEME_ISLEM_BILGISI,pd_VADE_TARIHI,pn_GERI_DONUS_HESAPNO,pn_ESAS_GUN_SAYISI,pn_FAIZ_ORANI,ps_ACIKLAMA,ps_REFERANS,ps_EKSTRE_BASIM_KODU,ps_EKSTRE_SIKLIGI,ps_DEKONT,pd_acilis_tarihi,'A',lv_musteri_dkno,ps_islemturu);

    ls_bakiye_karakteri:= Pkg_Parametre.DEGER(Pkg_Hesap.modul_tur_vadeli, ps_urun_tur_kod,ps_urun_sinif_kod,'BAKIYE_KARAKTERI');    --seval.colak 04112021
    Pkg_Hesap.HESAP_BAKIYE_OLUSTUR(ln_hesap_no,0, 0, 0,ls_bakiye_karakteri);    --seval.colak 04112021 ls_bakiye_karakteri ile degistirildi.
    
    if ps_urun_tur_kod <> 'ACCRUAL' then 
     ln_accrual_int_accountno:= pkg_hesap.AccrualVadeliHesapAcilis( pn_musteri_no ,       --seval.colak 04112021 accrual modification  
                                                                    ln_hesap_no ) ;
     end if;                                                               
     
    RETURN ln_hesap_no;

EXCEPTION

       WHEN GecerliDKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '2040' || l_ara || 'DK Grup Kodu'||ls_dkgrup_kodu||' '|| 'Product :'||ps_urun_tur_kod||' '||ps_urun_sinif_kod||' '||lv_musteri_dkno || l_ara || ps_doviz_kodu || l_uc);

          WHEN GecerliTRLDKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '2040' || l_ara || 'DK Grup Kodu'||ls_dkgrup_kodu||' '||'Product :'||ps_urun_tur_kod||' '||ps_urun_sinif_kod||' '||lv_musteri_dkno || l_ara || Pkg_Genel.lc_al || l_uc);



END;

---------------------------------------------------------------------------------

---------------------------------------------------------------------------------

  FUNCTION KrediHesapAcilis(pn_MUSTERI_NO       NUMBER,

                            ps_MODUL_TUR_KOD VARCHAR2,

                            ps_URUN_TUR_KOD VARCHAR2,

                            ps_URUN_SINIF_KOD VARCHAR2,

                            ps_KISA_ISIM VARCHAR2,

                            ps_DOVIZ_KODU VARCHAR2,

                            ps_SUBE_KODU VARCHAR2,

                            pn_TUTAR NUMBER,

                            pd_VALOR_TARIHI DATE,

                            pn_VADE_ISLEM_BILGISI NUMBER,

                            pn_ARA_ODEME_BILGISI NUMBER,

                            ps_OTOMATIK_TEMDIT VARCHAR2,

                            pn_PERIOD_SURE NUMBER,

                            ps_PERIOD_CINS VARCHAR2,

                            pd_SONRAKI_BASLANGIC_TARIHI DATE,

                            pn_ARA_ODEME_ISLEM_BILGISI NUMBER,

                            pd_VADE_TARIHI DATE,

                            pn_ILISKILI_HESAP_NO NUMBER,

                            pn_ESAS_GUN_SAYISI NUMBER,

                            pn_FAIZ_ORANI NUMBER,

                            ps_ACIKLAMA VARCHAR2,

                            ps_REFERANS    VARCHAR2,

                            ps_EKSTRE_BASIM_KODU VARCHAR2 DEFAULT 'X',

                            ps_EKSTRE_SIKLIGI VARCHAR2 DEFAULT NULL,

                            ps_DEKONT VARCHAR2 DEFAULT 'X',

                            pd_acilis_tarihi DATE DEFAULT Pkg_Muhasebe.Banka_Tarihi_Bul,

                            pn_KREDI_TEKLIF_SATIR NUMBER DEFAULT NULL) RETURN NUMBER IS



    ls_dkgrup_kodu          CBS_MUSTERI.DK_GRUP_KOD%TYPE;

    lv_musteri_dkno          CBS_HESAP.MUSTERI_DK_NO%TYPE;

    ln_hesap_no              NUMBER;

    ln_KUR                  NUMBER;

    GecerliDKHesap_Bulunamadi            EXCEPTION;

    GecerliTRLDKHesap_Bulunamadi        EXCEPTION;

    GecerliR_DKHesap_Bulunamadi            EXCEPTION;

    GecerliR_TRLDKHesap_Bulunamadi        EXCEPTION;

BEGIN



    SELECT CBS_MUSTERI.DK_GRUP_KOD

    INTO ls_dkgrup_kodu

    FROM CBS_MUSTERI

    WHERE CBS_MUSTERI.musteri_no=pn_musteri_no;



    IF ps_urun_tur_kod<>'KABULKRED' THEN

       --2-faiz Gelir DK

        Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, Pkg_Kredi.modul_tur_kod, ps_urun_tur_kod,ps_urun_sinif_kod, 2, NULL, NULL, NULL, lv_musteri_dkno);

/*        IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_KODU,ps_doviz_kodu ) THEN

           RAISE GecerliDKHesap_Bulunamadi;

        END IF;

        */

        IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_kodu,Pkg_Genel.LC_AL) THEN

           RAISE GecerliTRLDKHesap_Bulunamadi;

        END IF;



        --4-reeskont DK

        Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, Pkg_Kredi.modul_tur_kod, ps_urun_tur_kod,ps_urun_sinif_kod, 4, NULL, NULL, NULL, lv_musteri_dkno);

        IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ps_SUBE_kodu,ps_doviz_kodu ) THEN

           RAISE GecerliR_DKHesap_Bulunamadi;

        END IF;

    END IF;



    --ln_KUR:=pkg_kur.doviz_doviz_karsilik(ps_DOVIZ_KODU,pkg_genel.lc_al,null,1,1,null,null,'O','A');



    --Kredili hesap Ac

/*    pkg_kredi.kredi_hesap_ac(pkg_kredi.modul_tur_kod, ps_URUN_TUR_KOD, ps_URUN_SINIF_KOD,

                            pn_MUSTERI_NO, ps_DOVIZ_KODU, ps_SUBE_KODU, pd_VADE_TARIHI,

                            ps_REFERANS, ln_hesap_no,null, NULL,null,

                            pn_ILISKILI_HESAP_NO,pn_KREDI_TEKLIF_SATIR,null,null,null,null,

                            null,pn_FAIZ_ORANI,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,

                            0,0,pn_ESAS_GUN_SAYISI,    NULL,NULL);

    */

    -- sbalci 110204

    Pkg_Kredi.kredi_hesap_ac( ps_modul_tur=>Pkg_Kredi.modul_tur_kod , ps_urun_tur=>ps_URUN_TUR_KOD, ps_urun_sinif=>ps_URUN_SINIF_KOD,

                           pn_musteri_no=> pn_MUSTERI_NO, ps_doviz=>ps_DOVIZ_KODU, ps_sube=>ps_SUBE_KODU, pd_vade=>pd_VADE_TARIHI,

                            ps_referans=>ps_REFERANS, pn_hesap_no=>ln_hesap_no,

                            p_iliskili_hesap_no=>pn_ILISKILI_HESAP_NO,

                            p_kredi_teklif_satir_numara=>pn_KREDI_TEKLIF_SATIR,

                            p_faiz_orani=>pn_FAIZ_ORANI,

                            p_esas_gun_sayisi=>pn_ESAS_GUN_SAYISI);
    --b-o-m seval.colak 09112021
     if ps_urun_tur_kod <> 'ACCRUAL' then 
        pkg_kredi_tahsilat.sf_accrual_int_tax_account_open(ln_hesap_no,0 );  
     end if;
    --e-o-m seval.colak 09112021
    
    RETURN ln_hesap_no;



EXCEPTION

       WHEN GecerliDKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '3523' || l_ara || lv_musteri_dkno || l_ara || ps_doviz_kodu || l_uc);

          WHEN GecerliTRLDKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '3523' || l_ara || lv_musteri_dkno || l_ara || Pkg_Genel.lc_al || l_uc);

       WHEN GecerliR_DKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '3525' || l_ara || lv_musteri_dkno || l_ara || ps_doviz_kodu || l_uc);

          WHEN GecerliR_TRLDKHesap_Bulunamadi THEN

              RAISE_APPLICATION_ERROR(-20100,l_uc || '3525' || l_ara || lv_musteri_dkno || l_ara || Pkg_Genel.lc_al || l_uc);



END;

---------------------------------------------------------------------------

  /*****************************************************************************************************************/

  /*  Procedure RepoBlokeTutariGuncelle                                                                                    */

  /*  cbs_hesap tablosunda repo tutarini gunceller.(Gulnihal 15/12/2003)                                          */

  /*****************************************************************************************************************/



   PROCEDURE RepoBlokeTutariGuncelle(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE,pn_bloke_tutari  CBS_HESAP.REPO_BLOKE_TUTARI %TYPE) IS

   BEGIN

           UPDATE CBS_HESAP

        SET    repo_bloke_tutari = NVL(repo_bloke_tutari ,0)+ pn_bloke_tutari

        WHERE  hesap_no             = pn_hesap_no;



   EXCEPTION

           WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2923' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);



   END;

 /*****************************************************************************************************************/



PROCEDURE HesapDurumGuncelle(ps_tur VARCHAR2,pn_hesap_no NUMBER,ps_durum_kodu VARCHAR2) IS
    ln_accrual_int_accountno    number := 0; --seval.colak 09112021
    ln_accrual_tax_accountno    number := 0; --seval.colak 09112021
    ln_accrual_int_acct_bakiye   number := 0; --seval.colak 16112022
    ln_accrual_tax_acct_bakiye   number := 0; --seval.colak 16112022
BEGIN

 IF ps_tur=Pkg_Hesap.modul_tur_vadeli THEN

     UPDATE CBS_HESAP_VADELI

     SET DURUM_KODU=ps_durum_kodu

     WHERE hesap_no=pn_hesap_no ;

     IF ps_durum_kodu='K' THEN

          UPDATE CBS_HESAP_VADELI

         SET KAPAMA_TARIHI=Pkg_Muhasebe.Banka_Tarihi_Bul

         WHERE hesap_no=pn_hesap_no ;

     END IF;

  ELSIF ps_tur='CURRENT' THEN

     UPDATE CBS_HESAP

     SET DURUM_KODU=ps_durum_kodu

     WHERE hesap_no=pn_hesap_no ;

     IF ps_durum_kodu='K' THEN

          UPDATE CBS_HESAP

         SET KAPAMA_TARIHI=Pkg_Muhasebe.Banka_Tarihi_Bul

         WHERE hesap_no=pn_hesap_no ;

     END IF;

  ELSIF ps_tur=Pkg_Kredi.modul_tur_kod THEN

     UPDATE CBS_HESAP_KREDI

     SET DURUM_KODU=ps_durum_kodu

     WHERE hesap_no=pn_hesap_no ;

     IF ps_durum_kodu='K' THEN

          UPDATE CBS_HESAP_KREDI

         SET KAPANIS_TARIHI=Pkg_Muhasebe.Banka_Tarihi_Bul

         WHERE hesap_no=pn_hesap_no ;

     END IF;

  END IF;
  
  -- b-o-m seval.colak 16112022 accrual modification
  -- int accrual durum guncelle
	ln_accrual_int_accountno     := pkg_hesap.hesaptanaccrualintaccountnoal(pn_hesap_no); 
	begin
	 ln_accrual_int_acct_bakiye := PKG_HESAP.HESAPBAKIYEAL(ln_accrual_int_accountno); 
	 exception when others then null;
	end;
	if nvl(ln_accrual_int_accountno,0) <> 0 and nvl(ln_accrual_int_acct_bakiye,0) = 0 and ps_durum_kodu in( 'K','R','I') then 
        
        if ps_tur=pkg_hesap.modul_tur_vadeli then
         update cbs_hesap_vadeli
         set  durum_kodu=ps_durum_kodu ,
              kapama_tarihi=pkg_muhasebe.banka_tarihi_bul
         where hesap_no=ln_accrual_int_accountno ;
        end if;
           
        if ps_tur=Pkg_Kredi.modul_tur_kod  then
         update CBS_HESAP_KREDI
         set  durum_kodu=ps_durum_kodu ,
              kapanis_tarihi=pkg_muhasebe.banka_tarihi_bul
         where hesap_no=ln_accrual_int_accountno  ;
        end if;      
	end if;
	
 -- tax accrual durum guncelle
	ln_accrual_tax_accountno     := pkg_hesap.hesaptanaccrualtaxaccountnoal(pn_hesap_no); 
	begin
	 ln_accrual_tax_acct_bakiye := PKG_HESAP.HESAPBAKIYEAL(ln_accrual_tax_accountno); --seval.colak 16112022
	 exception when others then null;
	end;
	if nvl(ln_accrual_tax_accountno,0) <> 0 and  nvl(ln_accrual_tax_acct_bakiye,0) = 0 and ps_durum_kodu in( 'K','R','I') then         
        if ps_tur=pkg_hesap.modul_tur_vadeli then
         update cbs_hesap_vadeli
         set  durum_kodu=ps_durum_kodu ,
              kapama_tarihi=pkg_muhasebe.banka_tarihi_bul
         where hesap_no=ln_accrual_tax_accountno ;
        end if;
            
        if ps_tur=Pkg_Kredi.modul_tur_kod  then
         update CBS_HESAP_KREDI
         set  durum_kodu=ps_durum_kodu ,
              kapanis_tarihi=pkg_muhasebe.banka_tarihi_bul
         where hesap_no=ln_accrual_tax_accountno ;
        end if;      
	end if;
    -- e-o-m seval.colak 16112022 accrual modification    
END;

---------------------------------------------------------------------------------

FUNCTION GecenYilFaizToplami(pn_hesap_no NUMBER) RETURN NUMBER IS

    ln_gecenyilfaizi                     NUMBER;

BEGIN

     SELECT GECEN_YIL_FAIZ_TOPLAMI

     INTO ln_gecenyilfaizi

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_gecenyilfaizi;

END;

---------------------------------------------------------------------------------

FUNCTION BirikmisFaizPoz(pn_hesap_no NUMBER) RETURN NUMBER IS

    ln_birikmis                     NUMBER;

BEGIN

     SELECT BIRIKMIS_FAIZ_POZ

     INTO ln_birikmis

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_birikmis;

END;

---------------------------------------------------------------------------------

FUNCTION BirikmisFaizNeg(pn_hesap_no NUMBER) RETURN NUMBER IS

    ln_birikmis                     NUMBER;

BEGIN

     SELECT BIRIKMIS_FAIZ_NEG

     INTO ln_birikmis

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_birikmis;

END;

---------------------------------------------------------------------------------

PROCEDURE FaizBakiyeGuncelle(pn_islem_no NUMBER,ps_tur VARCHAR2,ps_islem_tur VARCHAR2,pn_hesap_no NUMBER,pn_tutar NUMBER) IS

          ln_last_tutar                 NUMBER;

BEGIN

     IF ps_tur='A' THEN

         ln_last_tutar:=NVL(pn_tutar,0);

     ELSE--'B'

         ln_last_tutar:= -1*NVL(pn_tutar,0);

     END IF;



     IF ps_islem_tur = 'BIRIKMISFAIZPOZ' THEN

         UPDATE CBS_HESAP_VADELI a

           SET BIRIKMIS_FAIZ_POZ = NVL(BIRIKMIS_FAIZ_POZ,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;

     ELSIF ps_islem_tur = 'GECENYILFAIZI' THEN

         UPDATE CBS_HESAP_VADELI a

           SET GECEN_YIL_FAIZ_TOPLAMI = NVL(GECEN_YIL_FAIZ_TOPLAMI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;

     ELSIF ps_islem_tur = 'ODENMISFAIZTOPLAMI' THEN

         UPDATE CBS_HESAP_VADELI a

           SET ODENMIS_FAIZ_TOPLAMI = NVL(ODENMIS_FAIZ_TOPLAMI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;

     ELSIF ps_islem_tur = 'KREDI-BIRIKMISFAIZNEG' THEN

         UPDATE CBS_HESAP_KREDI a

           SET BIRIKMIS_FAIZ_TUTARI= NVL(BIRIKMIS_FAIZ_TUTARI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;

     ELSIF ps_islem_tur = 'KREDI-GECENYILFAIZI' THEN

         UPDATE CBS_HESAP_KREDI a

           SET GECENYIL_FAIZ_TUTARI = NVL(GECENYIL_FAIZ_TUTARI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;
    
     ELSIF ps_islem_tur = 'GECENAYFAIZI' THEN  --b-o-m seval.colak 26102022 accrual modifications sirasinda kontrollerde sorun oldugu goruldu,duzeltildi.

         UPDATE CBS_HESAP_VADELI a

           SET GECMIS_AYLARIN_FAIZI = NVL(GECMIS_AYLARIN_FAIZI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;           
         
     ELSIF ps_islem_tur = 'KREDI-GECENAYFAIZI' THEN  

         UPDATE CBS_HESAP_KREDI a

           SET GECMIS_AYLARIN_FAIZI = NVL(GECMIS_AYLARIN_FAIZI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;            --e-o-m seval.colak 26102022 accrual modifications sirasinda kontrollerde sorun oldugu goruldu,duzeltildi.

     ELSIF ps_islem_tur = 'KREDI-ODENMISFAIZTOPLAMI' THEN

         UPDATE CBS_HESAP_KREDI a

           SET TAHSILEDILEN_FAIZ_TUTARI = NVL(TAHSILEDILEN_FAIZ_TUTARI,0)+NVL(ln_last_tutar,0)

         WHERE a.HESAP_NO = pn_hesap_no;

     END IF;



     INSERT INTO CBS_HESAP_FAIZ_LOG

     (ISLEM_NO, TUR, ISLEM_TIPI, HESAP_NO, TUTAR)

     VALUES

     (pn_islem_no,ps_tur ,ps_islem_tur ,pn_hesap_no ,pn_tutar);

END;

--------------------------------------------------------------------------------------

FUNCTION HesapBakiyeAl(pn_hesap_no CBS_VW_HESAP_IZLEME.HESAP_NO%TYPE) RETURN NUMBER IS

         ln_bakiye                   NUMBER;

BEGIN

     SELECT BAKIYE

     INTO ln_bakiye

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_bakiye;

END;



--------------------------------------------------------------------------------------

FUNCTION SchBirikmisFaizi(pn_hesap_no NUMBER) RETURN NUMBER IS

         ln_birikmis                   NUMBER;

BEGIN

     SELECT SCH_BIRIKMIS_FAIZI

     INTO ln_birikmis

     FROM CBS_HESAP_VADELI

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_birikmis;

END;



--------------------------------------------------------------------------------------

FUNCTION SchGecenYilFaizi(pn_hesap_no NUMBER) RETURN NUMBER IS

     ln_gecenyil                   NUMBER;

BEGIN

     SELECT SCH_GECENYIL_FAIZI

     INTO ln_gecenyil

     FROM CBS_HESAP_VADELI

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_gecenyil;

END;

--------------------------------------------------------------------------------------

FUNCTION MuhasebeTarihiAl(pn_hesap_no NUMBER) RETURN DATE IS

     ld_muhasebetarihi                   DATE;

BEGIN

     SELECT MUHASEBE_TARIHI

     INTO ld_muhasebetarihi

     FROM CBS_HESAP_VADELI

     WHERE hesap_no=pn_hesap_no;



     RETURN ld_muhasebetarihi;

END;

--------------------------------------------------------------------------------------

FUNCTION TCMBFaizHesapAl RETURN NUMBER IS

     ls_tcmbhesap                   NUMBER;

BEGIN

     SELECT HESAP_NO

     INTO ls_tcmbhesap

     FROM CBS_HESAP

     WHERE modul_tur_kod='CURRENT'

     AND urun_tur_kod='TCMB-TP'

     AND urun_sinif_kod='ANKARA';



     RETURN ls_tcmbhesap;

END;

--------------------------------------------------------------------------------------

FUNCTION TCMBFaizHesapSubeAl RETURN VARCHAR2 IS

     ls_tcmbhesapsube                 VARCHAR2(10);

BEGIN

     SELECT SUBE_KODU

     INTO ls_tcmbhesapsube

     FROM CBS_HESAP

     WHERE modul_tur_kod='CURRENT'

     AND urun_tur_kod='TCMB-TP'

     AND urun_sinif_kod='ANKARA';



     RETURN ls_tcmbhesapsube;

END;

--------------------------------------------------------------------------------------
FUNCTION OncekiGunBakiyeAl(pn_hesapno NUMBER,pn_yil NUMBER,pn_ay NUMBER, pn_gun NUMBER) RETURN NUMBER IS
         ln_bakiye                      NUMBER;

         ld_date                      DATE;

BEGIN



     ld_date:=TO_DATE(TO_CHAR(pn_yil) || '/'|| TO_CHAR(pn_ay) ||'/' || TO_CHAR(pn_gun),'YYYY/MM/DD')-1;--CBS-475
     --ld_date:= pn_balance_date-1;--CBS-475


     SELECT b.BAKIYE

     INTO ln_bakiye

     FROM CBS_HESAP_GUNLUK_BAKIYE b

     WHERE b.hesap_no=pn_hesapno

     AND yil=TO_NUMBER(TO_CHAR(ld_date,'YYYY'))--CBS-475

     AND ay=TO_NUMBER(TO_CHAR(ld_date,'MM'))--CBS-475

     AND gun=TO_NUMBER(TO_CHAR(ld_date,'DD'));--CBS-475

     -- AND balance_date=ld_date;--CBS-475


     RETURN ln_bakiye;



EXCEPTION

     WHEN OTHERS THEN

           RETURN NULL;



END;

--------------------------------------------------------------------------------------

FUNCTION HesapHareketKoduAl(pn_hesap_no CBS_VW_HESAP_IZLEME.HESAP_NO%TYPE) RETURN NUMBER IS

         ln_HareketKodu                   NUMBER;

BEGIN

     SELECT HESAP_HAREKET_KODU

     INTO ln_HareketKodu

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_HareketKodu;



EXCEPTION

     WHEN NO_DATA_FOUND THEN

           RETURN NULL;

     WHEN OTHERS THEN

           RETURN NULL;

END;



--------------------------------------------------------------------------------------



    FUNCTION Modul_tur_Vadesiz RETURN VARCHAR2

    IS

    BEGIN

         RETURN 'CURRENT' ;

    END;

    FUNCTION Modul_tur_Vadeli RETURN VARCHAR2

    IS

    BEGIN

         RETURN 'TIME DEP.';

    END;

--------------------------------------------------------------------------------------

FUNCTION External_HesapNo_Al(pn_hesap_no NUMBER) RETURN NUMBER IS

         ln_external                   NUMBER;

BEGIN

     SELECT EXTERNAL_HESAP_NO

     INTO ln_external

     FROM CBS_HESAP

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_external;



     EXCEPTION



     WHEN NO_DATA_FOUND THEN

     RETURN NULL;

END;

--------------------------------------------------------------------------------------

  FUNCTION  sf_borcvadesizhesap_urunuygun(ps_urun_tur_kod VARCHAR2 ) RETURN VARCHAR2

  IS

     ls_uygun  VARCHAR2(1) := 'H';

  BEGIN

         IF  (ps_urun_tur_kod IN ('SPOT','FORWARD','SWAP-FW','NOSTRO-FC','NOSTRO-LC','LOAN','PLACEMENT','ACCRUAL') ) THEN

             ls_uygun := 'H';

        ELSE

            ls_uygun := 'E';

        END IF;



       RETURN ls_uygun ;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END ;

  --------------------------------------------------------------------------------------

  FUNCTION  sf_ilisvadesizhesap_urunuygun(ps_urun_tur_kod VARCHAR2 ) RETURN VARCHAR2

    IS

     ls_uygun  VARCHAR2(1) := 'H';

  BEGIN

         IF  (ps_urun_tur_kod IN ('SPOT','FORWARD','SWAP-FW','NOSTRO-FC','NOSTRO-LC','LOAN','PLACEMENT','ACCRUAL') ) THEN

             ls_uygun := 'H';

        ELSE

            ls_uygun := 'E';

        END IF;

       RETURN ls_uygun ;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END ;

--------------------------------------------------------------------------------------

/*Asagidaki kisim Vadeli hesap urunleri netlestikten sonra tekrar degisitirilecektir. sevalb 11/10/2004*/

 FUNCTION  sf_vadeliurunuygunmu(ps_urun_tur_kod VARCHAR2) RETURN VARCHAR2

 IS

     ls_uygun  VARCHAR2(1) := 'E';

  BEGIN

         IF  (ps_urun_tur_kod  IN ('LOAN','PLACEMENT','ACCRUAL')) THEN -- seval.colak 04112021 accrual modification

             ls_uygun := 'H';

        ELSE

            ls_uygun := 'E';

        END IF;



       RETURN ls_uygun ;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END ;

--------------------------------------------------------------------------------------

  FUNCTION  sf_dk_uygunmu(ps_dkno VARCHAR2) RETURN VARCHAR2

  IS

    l_dk_firstdigit VARCHAR2(1);

  BEGIN

         l_dk_firstdigit:=SUBSTR(ps_dkno,1,1);



       IF l_dk_firstdigit IN('4','6','7','8','9') OR ps_dkno IN('11519000','11519001','11519100','11519101') THEN

         RETURN 'H';

        ELSE

          RETURN  'E';

       END IF;

  END;

--------------------------------------------------------------------------------------

  FUNCTION  sf_tax_orani_al(pn_dk_grup_kod NUMBER ,ps_modul_tur_kod VARCHAR2,ps_urun_tur_kod VARCHAR2 ,ps_urun_sinif_kod VARCHAR2 ) RETURN NUMBER

  IS

     ln_tax_oran NUMBER :=0 ;

  BEGIN

          SELECT TAX_ORAN

        INTO ln_tax_oran

        FROM CBS_TAX_DKGRUP_URUNSINIF_KOD

        WHERE DK_GRUP_KOD = pn_dk_grup_kod AND

              modul_tur_kod = ps_modul_tur_kod  AND

              urun_tur_kod = ps_urun_tur_kod AND

              urun_sinif_kod = ps_urun_sinif_kod ;



       RETURN NVL(ln_tax_oran,0);



    EXCEPTION

      WHEN OTHERS THEN RETURN 0;

  END ;

  --------------------------------------------------------------------------------------

  PROCEDURE sp_vadeli_istatistik_al(pn_hesap_no NUMBER, ps_istatis_tip VARCHAR2 DEFAULT 'A' ,pn_prefix OUT NUMBER,ps_doviz OUT VARCHAR2,ps_istatis_kod OUT VARCHAR2)

  IS

  BEGIN



         SELECT DECODE ( NVL(ps_istatis_tip,'A'),'A',ISTATISTIK_KODU_ALIS,'K',ISTATISTIK_KODU_KAPAMA,'F',ISTATISTIK_KODU_FAIZ) istatistik_kod,

                 DECODE ( NVL(ps_istatis_tip,'A'),'A',PREFIX_ISTATISTIK_KODU_ALIS,'K',PREFIX_ISTATISTIK_KODU_KAPAMA,'F',PREFIX_ISTATISTIK_KODU_FAIZ) Prefix_kod,

              doviz_kodu

       INTO ps_istatis_kod ,pn_prefix ,ps_doviz

       FROM CBS_HESAP_VADELI

       WHERE hesap_no = pn_hesap_no;

  END;



 --------------------------------------------------------------------------------------

  FUNCTION HesaptanMusteriDKNoAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2

  IS

       ls_musteri_dkno VARCHAR2(2000);

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

              SELECT musteri_dk_no

              FROM cbs_vw_hesap_izleme

              WHERE hesap_no=p_hesapno;

  BEGIN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO ls_musteri_dkno;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;



       CLOSE hesap_cursor;

       RETURN ls_musteri_dkno;



     EXCEPTION

               WHEN Hesap_Bulunamadi_Exception THEN



                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;

-----------------------------------------------------------------------------------------------------

FUNCTION GetBankCode(ps_bolum_kodu VARCHAR2) RETURN VARCHAR2 IS

        ls_bank_code               VARCHAR2(9);

BEGIN



    SELECT BIC_CODE

    INTO  ls_bank_code

    FROM CBS_DKB_INFO

    WHERE branch_code=ps_bolum_kodu;

/*

     IF ps_bolum_kodu='010' THEN

         ls_bank_code:='190501788';

     ELSif ps_bolum_kodu='030' then

         ls_bank_code:='191201772';

     END IF;

*/

     RETURN ls_bank_code;



END;

---------------------------------------------------------------------------------------

FUNCTION Check_External_HesapNo(ps_bankcode VARCHAR2,ps_hesap_no VARCHAR2) RETURN NUMBER IS

   ln_valid    NUMBER:=0;

   ls_bankcode VARCHAR2(9);

   ls_external VARCHAR2(9);

   ln_sum1       NUMBER:=0;

   ln_sum2       NUMBER:=0;

   ln_sum3       NUMBER:=0;

BEGIN

    ls_bankcode:=ps_bankcode;

    ls_external:=ps_hesap_no;



    ln_sum1:=MOD(7*SUBSTR(ls_bankcode,7,1),10) + MOD(1*SUBSTR(ls_bankcode,8,1),10)+MOD(3*SUBSTR(ls_bankcode,9,1),10);



    ln_sum2:=MOD(3*SUBSTR(ls_external,1,1),10) + MOD(7*SUBSTR(ls_external,2,1),10)+MOD(1*SUBSTR(ls_external,3,1),10)+

         MOD(3*SUBSTR(ls_external,4,1),10) + MOD(7*SUBSTR(ls_external,5,1),10)+MOD(1*SUBSTR(ls_external,6,1),10)+

         MOD(0*SUBSTR(ls_external,7,1),10) + MOD(7*SUBSTR(ls_external,8,1),10)+MOD(1*SUBSTR(ls_external,9,1),10);



    ln_sum3:=MOD(ln_sum1+ln_sum2,10)*3;



    IF SUBSTR(ls_external,7,1)=MOD(ln_sum3,10) THEN

        ln_valid:=1;

    ELSE

         ln_valid:=0;

    END IF;



    RETURN ln_valid;



EXCEPTION

     WHEN OTHERS THEN

           RETURN 0;



END;

---------------------------------------------------------------------------------------

FUNCTION GetSECOCode(ps_gl_group_code VARCHAR2) RETURN VARCHAR2 IS

     ls_YERLESIM_TIPI VARCHAR2(1);

     ls_SECTOR_OF_ECONOMY VARCHAR2(1);

BEGIN

     SELECT YERLESIM_TIPI, SECTOR_OF_ECONOMY

     INTO ls_YERLESIM_TIPI, ls_SECTOR_OF_ECONOMY

     FROM CBS_DK_GRUP_KODLARI

     WHERE DK_GRUP_KODU=ps_gl_group_code;



     RETURN ls_SECTOR_OF_ECONOMY;

END;

---------------------------------------------------------------------------------------

FUNCTION GetIRSCode(ps_gl_group_code VARCHAR2) RETURN VARCHAR2 IS

     ls_YERLESIM_TIPI VARCHAR2(1);

     ls_SECTOR_OF_ECONOMY VARCHAR2(1);

BEGIN

     SELECT YERLESIM_TIPI

     INTO ls_YERLESIM_TIPI

     FROM CBS_DK_GRUP_KODLARI

     WHERE DK_GRUP_KODU=ps_gl_group_code;



     RETURN ls_YERLESIM_TIPI;

END;

-----------------------------------------------------------------------------------------

FUNCTION GetTCMBHesap RETURN NUMBER IS

     ls_tcmbhesap    NUMBER:=9244;

BEGIN

     /*

     SELECT HESAP_NO

     INTO ls_tcmbhesap

     FROM CBS_HESAP

     WHERE modul_tur_kod='CURRENT'

     AND urun_tur_kod='TCMB'

     AND urun_sinif_kod='TCMB';*/





     RETURN ls_tcmbhesap;

END;

------------------------------------------------------------------------------------

FUNCTION BadListFlag(pn_hesap_no VARCHAR2) RETURN VARCHAR2 IS

         ls_badlistflag        VARCHAR2(1);

BEGIN

     SELECT BADLIST_FLAG

     INTO ls_badlistflag

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN NVL(ls_badlistflag,'H');

EXCEPTION

         WHEN NO_DATA_FOUND THEN

               RETURN  ls_badlistflag;

END;

--------------------------------------------------------------------------------------

FUNCTION GetBankHQ(ps_bankcode VARCHAR2) RETURN VARCHAR2 IS

         ls_hqcode               VARCHAR2(9);

BEGIN

     SELECT HQ_BIC_CODE

     INTO ls_hqcode

     FROM CBS_BANKCODES

     WHERE BANK_BIC_CODE=ps_bankcode;



     RETURN ls_hqcode;

END;

---------------------------------------------------------------------------------

FUNCTION GetExternalAccountNo(ps_dkgrup_kod VARCHAR2,

                             ps_modul_tur_kod VARCHAR2,

                            ps_urun_tur_kod VARCHAR2,

                            ps_urun_sinif_kod VARCHAR2) RETURN VARCHAR2 IS



    ls_old_gl_account     VARCHAR2(8);

    ls_firstcount        VARCHAR2(5);

    ln_lastindex        NUMBER;

    ls_externalaccountno       VARCHAR2(9);

    ls_bankcode VARCHAR2(9):='190501788';

    ls_external VARCHAR2(9);

    ln_sum1       NUMBER:=0;

    ln_sum2       NUMBER:=0;

    ln_sum3       NUMBER:=0;



BEGIN



     Pkg_Muhasebe.DK_BUL( ps_dkgrup_kod,

                           ps_modul_tur_kod,

                          ps_urun_tur_kod,

                          ps_urun_sinif_kod, 15, NULL, NULL, NULL, ls_old_gl_account);



     ls_firstcount := LPAD(TO_CHAR(Pkg_Genel.genel_kod_al('HESAP.EXTRNFRST')),5,'0');

     --ln_lastindex  := pkg_genel.genel_kod_al('HESAP.EXTRNLAST');



    ls_external:=SUBSTR(ls_firstcount,1,3) || ls_old_gl_account || 'X' || SUBSTR(ls_firstcount,4,2);



    ln_sum1:=MOD(7*SUBSTR(ls_bankcode,7,1),10) + MOD(7*SUBSTR(ls_bankcode,8,1),10)+MOD(7*SUBSTR(ls_bankcode,9,1),10);



    ln_sum2:=MOD(3*SUBSTR(ls_external,1,1),10) + MOD(7*SUBSTR(ls_external,2,1),10)+MOD(1*SUBSTR(ls_external,3,1),10)+

         MOD(3*SUBSTR(ls_external,4,1),10) + MOD(7*SUBSTR(ls_external,5,1),10)+MOD(1*SUBSTR(ls_external,6,1),10)+

         MOD(7*SUBSTR(ls_external,8,1),10)+MOD(1*SUBSTR(ls_external,9,1),10);



    ln_sum3:=MOD(ln_sum1+ln_sum2,10)*3;



    ls_external:=REPLACE(ls_external,'X',MOD(ln_sum3,10));



    RETURN ls_external;



END;

---------------------------------------------------------------------------------------

    FUNCTION GetMusteriNoFromExternal(ps_externalno VARCHAR2) RETURN NUMBER IS

             ln_musterino                            NUMBER;

    BEGIN

         SELECT max(MUSTERI_NO)

         INTO ln_musterino

         FROM CBS_HESAP

         WHERE EXTERNAL_HESAP_NO=ps_externalno;



         RETURN ln_musterino;

         Exception when others then return null;

    END;

----------------------------------------------------------------------------------------

    FUNCTION GetHesapNoFromExternal(ps_externalno VARCHAR2, ps_dvz varchar2) RETURN NUMBER IS

         ln_hesapno                            NUMBER;

    BEGIN

         SELECT HESAP_NO

         INTO ln_hesapno

         FROM CBS_HESAP

         WHERE EXTERNAL_HESAP_NO=ps_externalno

           and doviz_kodu = ps_dvz;



         RETURN ln_hesapno;

          Exception when others then return NULL;

    END;

---------------------------------------------------------------------------------------

FUNCTION GetBankHQName(ps_bankcode VARCHAR2) RETURN VARCHAR2 IS

         ls_BANKNAME               VARCHAR2(250);

BEGIN

     SELECT BANKNAME

     INTO ls_BANKNAME

     FROM CBS_BANKCODES

     WHERE BANK_BIC_CODE=ps_bankcode;



     RETURN ls_BANKNAME;

     Exception when others then return null;

END;

----------------------------------------------------------------------------------------

FUNCTION  sf_DCurunuygunmu(ps_urun_tur_kod VARCHAR2) RETURN VARCHAR2

 IS

     ls_uygun  VARCHAR2(1) := 'E';

  BEGIN

         IF  (ps_urun_tur_kod  IN ('SPOT','SWAP','FORWARD','SWAP-FW')) THEN

             ls_uygun := 'H';

        ELSE

            ls_uygun := 'E';

        END IF;



       RETURN ls_uygun ;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END ;

----------------------------------------------------------------------------------------

 FUNCTION  sf_GLuygunmu(ps_hesap CBS_DKHESAP.NUMARA%TYPE) RETURN VARCHAR2

 IS

     ls_uygun  VARCHAR2(1) := 'E';

  BEGIN

         IF  (ps_hesap  IN (10011300,10012300)) THEN

              ls_uygun := 'H';

        ELSE

           ls_uygun := 'E';

        END IF;



       RETURN ls_uygun ;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END ;

----------------------------------------------------------------------------------------

  FUNCTION HesaptanDurumAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2 IS

       ls_durum VARCHAR2(200);

  BEGIN

        IF  pn_hesap_no IS NOT NULL THEN

          SELECT durum_kodu

            INTO ls_durum

            FROM cbs_vw_hesap_izleme

           WHERE hesap_no = pn_hesap_no;

     END IF;

           RETURN ls_durum;



     EXCEPTION

               WHEN OTHERS THEN

                   RAISE_APPLICATION_ERROR(-20100,l_uc || '1156' || l_ara || pn_hesap_no || l_uc);

  END;

-------------------------------------------------------------------------------------------------

  FUNCTION BadListBalance(ps_reference VARCHAR2) RETURN NUMBER IS

    ln_AMOUNT NUMBER;

    ln_ODENEN_TUTAR     NUMBER;

  BEGIN

         SELECT NVL(AMOUNT,0),NVL(ODENEN_TUTAR,0)

       INTO ln_AMOUNT,ln_ODENEN_TUTAR

       FROM CBS_BAD_LIST

       WHERE reference=ps_reference;



       RETURN ln_AMOUNT-ln_ODENEN_TUTAR;

  END;

-------------------------------------------------------------------------------------------------

--sevalb 300407 kapatildi. yenisi eklendi

 /* FUNCTION Personel_Hesap_Mi(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS  --1 yes personel, else no

  ln_temp NUMBER;

  CURSOR c_0 IS

    SELECT 1 FROM CBS_MAAS_ODEMELERI

     WHERE hesap_no = pn_hesap_no;

  BEGIN

    OPEN c_0;

    FETCH c_0 INTO ln_temp;

    IF c_0%NOTFOUND THEN

       CLOSE c_0;

       RETURN 0;

    ELSE

     CLOSE c_0;

     RETURN 1;

    END IF;

    EXCEPTION

      WHEN OTHERS THEN

         RETURN 0;

  END;

  */

-------------------------------------------------------------------------------------------------

 FUNCTION Personel_Hesap_Mi(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS  --1 yes personel, else no

   ln_sicil_no           number;

   ln_musteri_no       number;

  BEGIN

       ln_musteri_no := pkg_hesap.HesaptanMusteriNoAl(pn_hesap_no );

          ln_sicil_no := pkg_musteri.Sf_PersonelSicilNoAl( ln_musteri_no  );

       if nvl( ln_sicil_no ,0) <> 0 then

             return 1;

        else

           return 0;

        end if;



    EXCEPTION

      WHEN OTHERS THEN

         RETURN 0;

  END;



-------------------------------------------------------------------------------------------------

  FUNCTION Personel_Bakiye_Gosterilsin(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS  --1 yes show, else no

  ln_temp NUMBER;

  ln_mus_per_sicil NUMBER;

  ln_kul_per_sicil NUMBER;

  CURSOR c_1 IS

    SELECT 1

      FROM CBS_MAAS_HESAP_IZLE

     WHERE personel_no = ln_kul_per_sicil;

  BEGIN

   IF Pkg_Hesap.personel_hesap_mi(pn_hesap_no) = 1 THEN

      SELECT NVL(personel_sicil_no, -1)

        INTO ln_mus_per_sicil

        FROM CBS_MUSTERI

       WHERE musteri_no = Pkg_Hesap.hesaptanmusterinoal(pn_hesap_no);

      SELECT NVL(personel_numara,-2)

        INTO ln_kul_per_sicil

        FROM CBS_KULLANICI

       WHERE kodu = Pkg_Baglam.kullanici_kodu;



     IF ln_mus_per_sicil = ln_kul_per_sicil THEN

        RETURN 1;   -- his own account show it

     ELSE

       OPEN c_1;

       FETCH c_1 INTO ln_temp;

       IF c_1%NOTFOUND THEN

         CLOSE c_1;

         RETURN 0;  -- does not have right to see

       ELSE

         CLOSE c_1;

         RETURN 1;  -- has right to see show it

       END IF;

     END IF;

   ELSE

      RETURN 1;     -- is not salary account  show it

   END IF;

    EXCEPTION

      WHEN OTHERS THEN

         RETURN 0;  -- any error occured in case don't show

  END;

-------------------------------------------------------------------------------------------------

   FUNCTION Sf_Hesap_maas_hesap_mi(pn_hesap_no CBS_HESAP.hesap_no%TYPE ) RETURN VARCHAR2

   IS

     ls_sonuc  VARCHAR2(1) := 'H';

    BEGIN

    -- sevalb 210507 sadece personel olmasi yeterlidir. Maas heasp flag kullanilmayacaktir

          if  pkg_hesap.Personel_Hesap_Mi(pn_hesap_no) = 1 then

            ls_sonuc  :=  'E';

        else

             ls_sonuc  := 'H';

      end if;



     /*SELECT NVL(maas_hesap_flag,'H')

       INTO   ls_sonuc

       FROM   cbs_vw_hesap_izleme

       WHERE  hesap_no = pn_hesap_no ;

      */

     RETURN ls_sonuc;



    EXCEPTION

      WHEN OTHERS THEN RETURN 'H';

  END  Sf_Hesap_maas_hesap_mi;

------------------------------------------------------------------------------------------------------------------------------------------------------------

  FUNCTION personel_kendi_hesabi_mi(pn_hesap_no CBS_HESAP.hesap_no%TYPE, ps_user VARCHAR2 DEFAULT Pkg_Baglam.kullanici_kodu) RETURN VARCHAR2 IS

  ln_mus_per_sicil NUMBER;

  ln_kul_per_sicil NUMBER;

  -- '0'  : A salary account but the user is different then the account owner

  -- '1'  : A salary account and the user is the account owner.

  -- '2'  : Not a salary account

  BEGIN

     IF Pkg_Hesap.personel_hesap_mi(pn_hesap_no) = 1 THEN

      SELECT NVL(personel_sicil_no, -1)

        INTO ln_mus_per_sicil

        FROM CBS_MUSTERI

       WHERE musteri_no = Pkg_Hesap.hesaptanmusterinoal(pn_hesap_no);



      SELECT NVL(personel_numara,-2)

        INTO ln_kul_per_sicil

        FROM CBS_KULLANICI

       WHERE kodu = ps_user;



          IF ln_mus_per_sicil = ln_kul_per_sicil THEN

          RETURN '1';   -- User is trying to reach his own account

        ELSE

          RETURN '0';

        END IF;

     ELSE

      RETURN '2';

    END IF;

  END;

------------------------------------------------------------------------------------------------------------------------------------------------------------



FUNCTION Gecmis_Aylarin_Faizi(pn_hesap_no NUMBER) RETURN NUMBER IS

    ln_Gecmis_Aylarin_Faizi                     NUMBER;

BEGIN

     SELECT GECMIS_AYLARIN_FAIZI

     INTO ln_Gecmis_Aylarin_Faizi

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_Gecmis_Aylarin_Faizi;

    Exception when others then return 0;

END;

---------------------------------------------------------------------------------

FUNCTION Gecmis_Aylarin_Komisyonu(pn_hesap_no NUMBER) RETURN NUMBER IS

    ln_Gecmis_Aylarin_Komisyonu                     NUMBER;

BEGIN

     SELECT GECMIS_AYLARIN_KOMISYONU

     INTO ln_Gecmis_Aylarin_Komisyonu

     FROM cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ln_Gecmis_Aylarin_Komisyonu;

    Exception when others then return 0;

END;

---------------------------------------------------------------------------------

FUNCTION EOD_Bekleyen_Bakiye(pn_hesap_no NUMBER) RETURN NUMBER

is

    ln_bakiye                     NUMBER;

BEGIN

        SELECT SUM(DECODE(s.tur,'A', NVL(dv_tutar,0), -1*NVL(dv_tutar,0)))

        into ln_bakiye

        FROM CBS_SATIR s, CBS_EOD_FIS_NO ef

        WHERE s.fis_numara = ef.fis_numara

               AND ef.durum = 'A'

                AND s.hesap_numara = pn_hesap_no

                AND s.hesap_tur_kodu <> 'DK';



     RETURN  nvl(ln_bakiye,0);

 Exception When Others then return 0;

End;

---------------------------------------------------------------------------------

procedure destek_hesap_limitleri (pn_hesap_no in number,

                                    pv_doviz_kod in varchar2,

                                  ps_overdraft in varchar2,

                                  pn_musteri_no in number,

            ls_grup_kod                        in out   varchar2,

            ls_musteri_tipi_kod              in out   varchar2,

            ln_urun_grup_no                  in out     number,

            ln_musteri_urun_fc_limit      in out     number,

            ln_musteri_urun_fc_risk          in out     number,

            ls_musteri_urun_fc_doviz_kodu in out     varchar2,

            ln_musteri_urun_limit_bosluk  in out     number,

            lb_musteri_urun_limit_var       in out     boolean,

            ln_musteri_fc_limit              in out     number,

            ln_musteri_fc_risk              in out     number,

            ls_musteri_fc_doviz_kodu      in out     varchar2,

            ln_musteri_limit_bosluk             in out     number,

            lb_musteri_limit_var           in out     boolean,

            ln_musteri_grup_fc_limit      in out     number,

            ln_musteri_grup_fc_risk          in out     number,

            ls_musteri_grup_fc_doviz_kodu in out   varchar2,

            ln_musteri_grup_limit_bosluk  in out   number,

            lb_musteri_grup_limit_var       in out   boolean,

            ln_mus_grup_urun_fc_limit      in out     number,

            ln_mus_grup_urun_fc_risk      in out     number,

            ls_mus_grup_urun_fc_doviz       in out     varchar2,

            ln_mus_grup_urun_limit_bosluk in out     number,

            lb_mus_grup_urun_limit_var       in out     boolean,

            ln_destek                      in out     number) is

 ln_nakdi_fc_limit number;

 ln_nakdi_fc_risk    number;

 type  t_arr_sira is VARRAY(4) of number;

 v_sirala t_arr_sira;

 i number;

ln_grup_urun_grup_no number := 0 ; --sevalb 07092011

--B-O-M -- AdiletK CQ1236 30122014

ln_ovd_cnt number := 0; 

ln_total_ovd_cnt number := 0;

ln_ovd_lim number;

ln_tot_cust_risk number;

ln_cash_cust_risk number;

ls_noncash_group varchar2(1000);

ls_cust_lim_curr varchar2(3);

--E-O-M -- AdiletK CQ1236 30122014

ln_aval_lim_product number; -- 05.03.2015 AdiletK CQ4591 variable to hold available limit without coefficient

Begin

      if ps_overdraft = 'E' then

          begin

              select musteri_tipi_kod, grup_kod

                into ls_musteri_tipi_kod, ls_grup_kod

                from cbs_musteri

                where musteri_no = pn_musteri_no;

             exception

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1194' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

          begin

            select numara

              into ln_urun_grup_no

              from CBS_URUN_GRUBU

             where tanim = 'OVERDRAFT'

               and musteri_tipi=ls_musteri_tipi_kod;

             exception

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1195' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

          begin

           -- B-O-M  30122014 AdiletK CQ1236  Select connected overdrafts to this account

            pkg_parametre.deger('OVD_LIMIT_PERCENTAGE', ln_ovd_lim);

            select count(*)

              into ln_ovd_cnt

              from cbs_musteri_urun_limit

             where musteri_no = pn_musteri_no

               and urun_grub_no=ln_urun_grup_no 

               and kredi_teklif_satir_numara = (select nvl(ovd_proposal_line_no, 0)

                                                                 from cbs_hesap

                                                                 where hesap_no = pn_hesap_no

                                                                    and durum_kodu = 'A');

                                                                 

            select count(*)

              into ln_total_ovd_cnt

              from cbs_musteri_urun_limit

             where musteri_no = pn_musteri_no

               and urun_grub_no=ln_urun_grup_no 

               and kredi_teklif_satir_numara in (select nvl(ovd_proposal_line_no,0)

                                                                 from cbs_hesap

                                                                 where musteri_no = pn_musteri_no

                                                                    and durum_kodu = 'A');                                               

               

            IF ln_ovd_cnt > 0 THEN   -- if overdraft is connected by kredi_teklif_satir_numara

                 select nvl(fc_limit,0), nvl(fc_risk,0), fc_doviz_kodu

                  into ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu

                  from cbs_musteri_urun_limit

                 where musteri_no = pn_musteri_no

                   and urun_grub_no=ln_urun_grup_no 

                   and kredi_teklif_satir_numara = (select nvl(ovd_proposal_line_no,0)

                                                                    from cbs_hesap

                                                                    where hesap_no = pn_hesap_no

                                                                       and durum_kodu = 'A');

            ELSIF ln_total_ovd_cnt = 0 THEN  -- if overdraft is not connected to the account directly

                 select nvl(fc_limit,0), nvl(fc_risk,0), fc_doviz_kodu

                  into ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu

                  from cbs_musteri_urun_limit

                 where musteri_no = pn_musteri_no

                   and urun_grub_no=ln_urun_grup_no;                

            END IF;

           

            select fc_doviz_kodu

              into ls_cust_lim_curr

              from cbs_musteri_limit

            where musteri_no = pn_musteri_no;  

            ln_aval_lim_product := ln_musteri_urun_fc_limit; -- 05.03.2015 AdiletK CQ4591 variable to hold available limit without coefficient            

            IF ls_cust_lim_curr <> ls_musteri_urun_fc_doviz_kodu THEN

                ln_musteri_urun_fc_limit := ln_musteri_urun_fc_limit*ln_ovd_lim/100; -- is applied when the customer limit currency differs overdraft currency

            END IF;    

             -- E-O-M  30122014 AdiletK CQ1236 Select connected overdrafts to this account

            ln_musteri_urun_limit_bosluk  := ln_musteri_urun_fc_limit - ln_musteri_urun_fc_risk;

            ln_aval_lim_product := ln_aval_lim_product - ln_musteri_urun_fc_risk; -- 05.03.2015 AdiletK CQ4591 variable to hold available limit without coefficient

            lb_musteri_urun_limit_var := true;

            if ls_musteri_urun_fc_doviz_kodu <> pv_doviz_kod then

              --different currencies change to account currency

              ln_musteri_urun_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(ls_musteri_urun_fc_doviz_kodu, pv_doviz_kod, NULL,

                                                                                ln_musteri_urun_limit_bosluk, 1, NULL, NULL, 'N', 'A');

              ln_aval_lim_product := Pkg_Kur.doviz_doviz_karsilik(ls_musteri_urun_fc_doviz_kodu, pv_doviz_kod, NULL,

                                                                                ln_aval_lim_product, 1, NULL, NULL, 'N', 'A');             -- 05.03.2015 AdiletK CQ4591 variable to hold available limit without coefficient

            end if;

             exception

               when no_data_found then

                  ln_musteri_urun_fc_limit := 0;

                  ln_musteri_urun_fc_risk := 0;

                  ln_musteri_urun_limit_bosluk := 0;

                  lb_musteri_urun_limit_var := false;

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1196' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

    --B-O-M sevalb 07092011 destek hesap grup problemi ,grup limitlerine bakilirken musteri tipi X olmali

       if ls_grup_kod is not null then  

        begin

            select numara

              into ln_grup_urun_grup_no

              from CBS_URUN_GRUBU

             where tanim = 'OVERDRAFT'

               and musteri_tipi='X';

             exception

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1195' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

       end if;

 

      --E-O-M sevalb 07092011 destek hesap grup problemi  

          begin

            select nvl(fc_limit,0), nvl(fc_risk,0), fc_doviz_kodu

              into ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk, ls_mus_grup_urun_fc_doviz

              from cbs_musteri_grub_urun_limit

             where grup_kodu = ls_grup_kod

               and urun_grub_no=ln_grup_urun_grup_no;

            ln_mus_grup_urun_limit_bosluk  := ln_mus_grup_urun_fc_limit - ln_mus_grup_urun_fc_risk;

            lb_mus_grup_urun_limit_var := true;

            if ls_mus_grup_urun_fc_doviz <> pv_doviz_kod then

              --different currencies change to account currency

              ln_mus_grup_urun_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(ls_mus_grup_urun_fc_doviz, pv_doviz_kod, NULL,

                                                                                 ln_mus_grup_urun_limit_bosluk, 1, NULL, NULL, 'N', 'A');

            end if;

             exception

               when no_data_found then

                  ln_mus_grup_urun_fc_limit := 0;

                  ln_mus_grup_urun_fc_risk := 0;

                  ln_mus_grup_urun_limit_bosluk := 0;

                  lb_mus_grup_urun_limit_var := false;

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1189' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

          begin

            select nvl(fc_limit,0), nvl(fc_risk,0), fc_doviz_kodu, nvl(nakdi_fc_limit,0), nvl(nakdi_fc_risk,0)

              into ln_musteri_fc_limit, ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu, ln_nakdi_fc_limit, ln_nakdi_fc_risk

              from cbs_musteri_limit

             where musteri_no = pn_musteri_no;

           -- B-O-M  30122014 AdiletK CQ1236 Change in logic of available total credit limit

            BEGIN

                SELECT SUM(DECODE(fc_doviz_kodu, ls_musteri_fc_doviz_kodu, nvl(fc_risk,0), Pkg_Kur.doviz_doviz_karsilik(fc_doviz_kodu, ls_musteri_fc_doviz_kodu, NULL,

                                                                                                                                      nvl(fc_risk,0), 1, NULL, NULL, 'N', 'A')))

                INTO ln_tot_cust_risk -- get total risk of all credit products in currency of total limit

                FROM cbs_musteri_urun_limit

                WHERE musteri_no = pn_musteri_no;

                EXCEPTION WHEN NO_DATA_FOUND THEN

                    ln_tot_cust_risk := ln_musteri_fc_risk;

            END; 

            BEGIN

                pkg_parametre.deger('NON_CASH_PROD_LIST', ls_noncash_group );

                SELECT SUM(DECODE(fc_doviz_kodu, ls_musteri_fc_doviz_kodu, nvl(fc_risk,0), Pkg_Kur.doviz_doviz_karsilik(fc_doviz_kodu, ls_musteri_fc_doviz_kodu, NULL,

                                                                                                                                      nvl(fc_risk,0), 1, NULL, NULL, 'N', 'A')))

                INTO ln_cash_cust_risk -- get total cash risk of all credit products in currency of total limit

                FROM cbs_musteri_urun_limit u, 

                         cbs_urun_grubu g

                WHERE musteri_no = pn_musteri_no and

                            g.numara = u.urun_grub_no and 

                            instr(ls_noncash_group, rtrim(ltrim(g.tanim))) = 0;

                EXCEPTION WHEN NO_DATA_FOUND THEN

                    ln_cash_cust_risk := ln_musteri_fc_risk;

            END;             

            ln_musteri_limit_bosluk  := ln_musteri_fc_limit - ln_tot_cust_risk; -- calculate total available limit using risks and cash risks of credit products

            if ln_musteri_limit_bosluk > (ln_nakdi_fc_limit - ln_cash_cust_risk) then

               ln_musteri_limit_bosluk := (ln_nakdi_fc_limit - ln_cash_cust_risk);

            end if;

            -- E-O-M  30122014 AdiletK CQ1236 Change in logic of available total credit limit

            lb_musteri_limit_var := true;

            if ls_musteri_fc_doviz_kodu <> pv_doviz_kod then

              --different currencies change to account currency

              ln_musteri_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(ls_musteri_fc_doviz_kodu, pv_doviz_kod, NULL,

                                                                           ln_musteri_limit_bosluk, 1, NULL, NULL, 'N', 'A');

            end if;

             exception

               when no_data_found then

                  ln_musteri_fc_limit := 0;

                  ln_musteri_fc_risk := 0;

                  ln_musteri_limit_bosluk := 0;

                  lb_musteri_limit_var := false;

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1197' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

          begin

            select nvl(fc_limit,0), nvl(fc_risk,0), fc_doviz_kodu, nvl(nakdi_fc_limit,0), nvl(nakdi_fc_risk,0)

              into ln_musteri_grup_fc_limit, ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu, ln_nakdi_fc_limit, ln_nakdi_fc_risk

              from cbs_musteri_grup_limit

             where grup_kodu =  ls_grup_kod;

            ln_musteri_grup_limit_bosluk  :=  ln_musteri_grup_fc_limit - ln_musteri_grup_fc_risk ;--sevalb 07092011 hatali kisim yan tarafda limit den risk dusulmeli ln_musteri_grup_fc_limit - ln_musteri_grup_fc_limit;

            if ln_musteri_grup_limit_bosluk > (ln_nakdi_fc_limit - ln_nakdi_fc_risk) then

               ln_musteri_grup_limit_bosluk := (ln_nakdi_fc_limit - ln_nakdi_fc_risk);

            end if;

            lb_musteri_grup_limit_var := true;

            if ls_musteri_grup_fc_doviz_kodu <> pv_doviz_kod then

              --different currencies change to account currency

              ln_musteri_grup_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(ls_musteri_grup_fc_doviz_kodu, pv_doviz_kod, NULL,

                                                                                  ln_musteri_grup_limit_bosluk, 1, NULL, NULL, 'N', 'A');

            end if;

             exception

               when no_data_found then

                  ln_musteri_grup_fc_limit := 0;

                  ln_musteri_grup_fc_risk := 0;

                  ln_musteri_grup_limit_bosluk := 0;

                  lb_musteri_grup_limit_var := false;

               when others then

                 RAISE_APPLICATION_ERROR(-20100,l_uc || '1198' || l_ara || pn_hesap_no || l_ara||sqlcode||'-'||sqlerrm ||l_uc);

          end;

          

          -- B-O-M AdiletK 30122014 CQ1236 Credit Limit Control

          IF lb_musteri_urun_limit_var AND lb_musteri_limit_var THEN 

             /* IF ls_musteri_fc_doviz_kodu <> pv_doviz_kod THEN

                  ln_musteri_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_musteri_fc_doviz_kodu, NULL,

                                                           ln_musteri_limit_bosluk, 1, NULL, NULL, 'N', 'A');

              END IF;

              

              IF ls_musteri_urun_fc_doviz_kodu <> pv_doviz_kod THEN

                  ln_musteri_urun_limit_bosluk := Pkg_Kur.doviz_doviz_karsilik(pv_doviz_kod, ls_musteri_urun_fc_doviz_kodu, NULL,

                                                                    ln_musteri_urun_limit_bosluk, 1, NULL, NULL, 'N', 'A');

              END IF;*/

              -- when one of the limits is fully used            

              IF ln_musteri_limit_bosluk <= 0 OR ln_aval_lim_product <= 0 THEN -- 17.04.2015 AdiletK CQ4646 Overdraft Risk Surpassing 95%

                  ln_musteri_limit_bosluk := 0;

                  ln_musteri_urun_limit_bosluk := 0;

              END IF;

              

              -- make both available limit equal to the smallest one                  

              IF ln_aval_lim_product > ln_musteri_limit_bosluk THEN -- 05.03.2015 AdiletK CQ4591 return aval limit as total aval limit

                  ln_musteri_urun_limit_bosluk := ln_musteri_limit_bosluk;

              ELSE

                  ln_musteri_limit_bosluk := ln_aval_lim_product; -- 05.03.2015 AdiletK CQ4591 return aval limit as customer's aval limit without coefficient

                  ln_musteri_urun_limit_bosluk := ln_aval_lim_product; -- 05.03.2015 AdiletK CQ4591 return aval limit as customer's aval limit without coefficient

              END IF;

          END IF;

          -- E-O-M AdiletK 30122014 CQ1236 Credit Limit Control     

          

          v_sirala := t_arr_sira();

            i:= 0;

          if lb_musteri_grup_limit_var then

              i:= i + 1;

              v_sirala.extend;

              v_sirala(i) := ln_musteri_grup_limit_bosluk;

            

          end if;

         

          if lb_musteri_limit_var then

              i:= i + 1;

              v_sirala.extend;

              v_sirala(i) := ln_musteri_limit_bosluk;

        

          end if;

        

          if lb_musteri_urun_limit_var then

              i:= i + 1;

              v_sirala.extend;

              v_sirala(i) := ln_musteri_urun_limit_bosluk;

    

          end if;

        

          if lb_mus_grup_urun_limit_var then

              i:= i + 1;

              v_sirala.extend;

              v_sirala(i) := ln_mus_grup_urun_limit_bosluk;

    

          end if;

          if lb_musteri_grup_limit_var or lb_musteri_limit_var or lb_musteri_urun_limit_var or lb_mus_grup_urun_limit_var then

               -- at least one limit exists

               for j in v_sirala.first..v_sirala.last loop

                 for k in v_sirala.first+1..v_sirala.last loop

        

                    if v_sirala(j) > v_sirala(k) then

                       i :=  v_sirala(j);

                       v_sirala(j) :=  v_sirala(k);

                       v_sirala(k) := i;

        

                    end if;

                 end loop;

               end loop;

               ln_destek := v_sirala(v_sirala.first);

   

          else

            ln_destek := 0; --no limit exists



          end if;

          if lb_musteri_urun_limit_var then

             if ls_grup_kod is not null then

                if lb_mus_grup_urun_limit_var then

                  null;



                else

                  ln_destek := 0; --no group limit exists



                end if;

             end if;

          else

            ln_destek := 0; --no product limit exists

          end if;

      else -- is not an overdraft account

         ln_destek := 0;

      end if;



 end;



 ---------------------------------------------------------------------------------

  FUNCTION BakiyeKarakteriAl(pn_hesap_no NUMBER) RETURN varchar2

  is

      ls_bakiye_karakteri varchar2(1);

BEGIN

     SELECT BAKIYE_KARAKTERI

     INTO  ls_bakiye_karakteri

     FROM  cbs_vw_hesap_izleme

     WHERE hesap_no=pn_hesap_no;



     RETURN ls_bakiye_karakteri;

    Exception when others then return null;

END;

 ---------------------------------------------------------------------------------

FUNCTION DestekHesapLimitBosluk(pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE ) RETURN number is

     ln_destek        NUMBER;

     pv_doviz_kod   varchar2(3);

            ls_overdraft_mi                       varchar2(1);

            ln_musteri_no                        number;

            ls_musteri_tipi_kod                   varchar2(1);

            ln_urun_grup_no                       number;

            ln_musteri_urun_fc_limit           number;

            ln_musteri_urun_fc_risk               number;

            ls_musteri_urun_fc_doviz_kodu       varchar2(3);

            ln_musteri_urun_limit_bosluk       number;

            lb_musteri_urun_limit_var            boolean;

            ln_musteri_fc_limit                   number;

            ln_musteri_fc_risk                   number;

            ls_musteri_fc_doviz_kodu           varchar2(3);

            ln_musteri_limit_bosluk                  number;

            lb_musteri_limit_var                   boolean;

            ln_musteri_grup_fc_limit           number;

            ln_musteri_grup_fc_risk               number;

            ls_musteri_grup_fc_doviz_kodu       varchar2(3);

            ln_musteri_grup_limit_bosluk       number;

            lb_musteri_grup_limit_var            boolean;

            ls_grup_kod                           varchar2(10);

            ln_mus_grup_urun_fc_limit           number;

            ln_mus_grup_urun_fc_risk           number;

            ls_mus_grup_urun_fc_doviz           varchar2(3);

            ln_mus_grup_urun_limit_bosluk       number;

            lb_mus_grup_urun_limit_var           boolean;

   BEGIN



       SELECT h.musteri_no, nvl(overdraft,'H'), doviz_kodu

         INTO ln_musteri_no, ls_overdraft_mi, pv_doviz_kod

         FROM cbs_vw_hesap_izleme h

        WHERE h.hesap_no=pn_hesap_no;



      if ls_overdraft_mi = 'E' then

        destek_hesap_limitleri (pn_hesap_no, pv_doviz_kod, ls_overdraft_mi, ln_musteri_no,

                                  ls_grup_kod, ls_musteri_tipi_kod, ln_urun_grup_no,

                               ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu,

                               ln_musteri_urun_limit_bosluk, lb_musteri_urun_limit_var,

                               ln_musteri_fc_limit, ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,

                               ln_musteri_limit_bosluk, lb_musteri_limit_var,

                               ln_musteri_grup_fc_limit, ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu,

                               ln_musteri_grup_limit_bosluk, lb_musteri_grup_limit_var,

                               ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk, ls_mus_grup_urun_fc_doviz,

                               ln_mus_grup_urun_limit_bosluk, lb_mus_grup_urun_limit_var, ln_destek);

      else -- is not an overdraft account

         ln_destek := 0;

      end if;



     RETURN NVL(ln_destek,0);



    EXCEPTION

     WHEN NO_DATA_FOUND THEN RETURN 0 ;

      WHEN OTHERS THEN

        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '344' ||Pkg_Hata.getdelimiter || TO_CHAR(pn_hesap_no) || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) || ' ' ||SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);



   END DestekHesapLimitBosluk;

 ---------------------------------------------------------------------------------

FUNCTION GetBankName(ps_bankcode VARCHAR2) RETURN VARCHAR2 IS



         ls_BANKNAME VARCHAR2(250);

BEGIN

             SELECT BANKA_ADI

             INTO ls_BANKNAME

             FROM  CBS_BANKA_KODLARI

             WHERE BANKA_KODU=ps_bankcode;



             RETURN ls_BANKNAME;



             EXCEPTION WHEN OTHERS THEN RETURN NULL;



END;

 --BOM     BaiamanG 01.02.2019
FUNCTION GetLegalBlockingCount(pn_hesap_no NUMBER) RETURN NUMBER 
IS
    ln_count    NUMBER;
BEGIN
    SELECT COUNT(*) INTO ln_count FROM cbs_bloke
    WHERE hesap_no = pn_hesap_no AND durum_kodu = 'A' AND bloke_neden_kodu = 70;
    
    return ln_count;
END;
--EOM   BaiamanG 01.02.2019

 ---------------------------------------------------------------------------------
FUNCTION HesaptanAccrualIntAccountNoAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS -- seval.colak 04112021 accrual modification

       l_ACCRUAL_INT_ACCOUNT_NO CBS_HESAP.ACCRUAL_INT_ACCOUNT_NO%TYPE;

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS

              SELECT ACCRUAL_INT_ACCOUNT_NO

              FROM CBS_HESAP

              WHERE CBS_HESAP.hesap_no=p_hesapno

              UNION

              SELECT ACCRUAL_INT_ACCOUNT_NO

              FROM CBS_HESAP_VADELI

              WHERE CBS_HESAP_VADELI.hesap_no=p_hesapno

              UNION

              SELECT ACCRUAL_INT_ACCOUNT_NO

              FROM CBS_HESAP_KREDI

              WHERE CBS_HESAP_KREDI.hesap_no=p_hesapno ;

  BEGIN

     IF pn_hesap_no  IS NOT NULL THEN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO l_ACCRUAL_INT_ACCOUNT_NO;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;

       CLOSE hesap_cursor;

         END IF;

       RETURN l_ACCRUAL_INT_ACCOUNT_NO;

     EXCEPTION

               WHEN OTHERS  THEN

                   RETURN NULL;

  END;

---------------------------------------------------------------------------------
FUNCTION HesaptanAccrualTaxAccountNoAl(pn_hesap_no CBS_HESAP.HESAP_NO%TYPE) RETURN NUMBER IS -- seval.colak 04112021 accrual modification
--  sadece kredi hesaplarinda  ACCRUAL_TAX_ACCOUNT_NO acildi ileri de vadeli,vadesiz icinde acilirsa kapatilan kisimlarda degisiklik yapmak gerekir
       l_accrual_tax_account_no CBS_HESAP_KREDI.ACCRUAL_TAX_ACCOUNT_NO%TYPE;

       Hesap_Bulunamadi_Exception EXCEPTION;

       CURSOR hesap_cursor (p_hesapno CBS_HESAP.HESAP_NO%TYPE) IS
            /*
              SELECT ACCRUAL_TAX_ACCOUNT_NO

              FROM CBS_HESAP

              WHERE CBS_HESAP.hesap_no=p_hesapno

              UNION

              SELECT ACCRUAL_TAX_ACCOUNT_NO

              FROM CBS_HESAP_VADELI

              WHERE CBS_HESAP_VADELI.hesap_no=p_hesapno

              UNION
               */
              SELECT ACCRUAL_TAX_ACCOUNT_NO

              FROM CBS_HESAP_KREDI

              WHERE CBS_HESAP_KREDI.hesap_no=p_hesapno ;

  BEGIN

     IF pn_hesap_no  IS NOT NULL THEN

       OPEN hesap_cursor(pn_hesap_no);

       FETCH hesap_cursor INTO l_accrual_tax_account_no;

       IF hesap_cursor%NOTFOUND THEN

          CLOSE hesap_cursor;

          RAISE Hesap_Bulunamadi_Exception;

       END IF;

       CLOSE hesap_cursor;

         END IF;

       RETURN l_accrual_tax_account_no;

     EXCEPTION

               WHEN OTHERS  THEN

                   RETURN NULL;

  END;
----------------------------------------------------------------------------------
-- FUNCTION AccrualVadeliHesapAcilis  seval.colak 04112021 accrual modification
----------------------------------------------------------------------------------
FUNCTION AccrualVadeliHesapAcilis(pn_musteri_no number ,      
                                  pn_ana_hesap_no   number,                                  
                                  pd_acilis_tarihi     date default pkg_muhasebe.banka_tarihi_bul 
                                  ) return number is
    ln_accrual_int_accountno        number; 
    lv_musteri_dkno                 cbs_hesap.musteri_dk_no%type;
    ls_bakiye_karakteri             varchar2(1) ;
    ls_accrual_int_urun_sinif       cbs_hesap_vadeli.urun_sinif_kod%type;  
    ls_dkgrup_kodu                  CBS_MUSTERI.DK_GRUP_KOD%type;  
    ls_urun_tur_kod                 cbs_hesap_vadeli.urun_tur_kod%type; 
    ls_urun_sinif_kod               cbs_hesap_vadeli.urun_sinif_kod%type; 
    ls_sube_kodu                    cbs_hesap_vadeli.sube_kodu%type; 
    ls_doviz_kodu                   cbs_hesap_vadeli.doviz_kodu%type;  
    ld_valor_tarihi                 cbs_hesap_vadeli.valor_tarihi%type;   
    ls_kisa_isim                    cbs_hesap_vadeli.kisa_isim%type;   
    ls_accrual_durum                cbs_hesap_vadeli.durum_kodu%type;
    GecerliDKHesap_Bulunamadi       EXCEPTION;
    GecerliTRLDKHesap_Bulunamadi    EXCEPTION;    
 Begin                         
            
    select cbs_musteri.dk_grup_kod
    into ls_dkgrup_kodu
    from cbs_musteri
    where cbs_musteri.musteri_no=pn_musteri_no;
    
    select accrual_int_account_no,urun_tur_kod,urun_sinif_kod,sube_kodu, doviz_kodu,valor_tarihi,kisa_isim
    into   ln_accrual_int_accountno,ls_urun_tur_kod,ls_urun_sinif_kod,ls_sube_kodu ,ls_doviz_kodu,ld_valor_tarihi,ls_kisa_isim
    from   cbs_hesap_vadeli
    where  hesap_no = pn_ana_hesap_no ;
    
    if nvl(ln_accrual_int_accountno,0) <> 0  then  
         select  durum_kodu
         into   ls_accrual_durum
         from   cbs_hesap_vadeli
         where  hesap_no = ln_accrual_int_accountno ;
       if ls_accrual_durum <> 'A' then 
        ln_accrual_int_accountno := null;
       end if; 
    end if;
     
     if nvl(ln_accrual_int_accountno,0) = 0 then   
       ls_bakiye_karakteri := 'H'; --seval.colak 17052022 vadeli accrual hesaplar icinde bakiye karakteri H olmasi istendi  ,yandaki eklendi, asagidaki kisim kapatildi.     
        /*select bakiye_karakteri
        into   ls_bakiye_karakteri
        from   cbs_hesap_Bakiye
        where hesap_No = pn_ana_hesap_no;
        */
        select   'INTEREST' ||'-' || DECODE(ls_doviz_kodu,pkg_genel.lc_al,'LC','FC')
        into  ls_accrual_int_urun_sinif
        from dual ;
      
  --4-reeskont DK
        pkg_muhasebe.dk_bul( ls_dkgrup_kodu, pkg_hesap.modul_tur_vadeli, ls_urun_tur_kod,ls_urun_sinif_kod, 4, null, null, null, lv_musteri_dkno);
         if not pkg_hesap.gecerlidkhesap(lv_musteri_dkno,ls_sube_kodu,ls_doviz_kodu ) then
           raise gecerlidkhesap_bulunamadi;
        end if;
   
        ln_accrual_int_accountno:=Pkg_Genel.genel_kod_al('HESAP.VDSZ');
   
        insert into cbs_hesap_vadeli(musteri_no,hesap_no,modul_tur_kod,urun_tur_kod,urun_sinif_kod,kisa_isim,doviz_kodu,sube_kodu,tutar,valor_tarihi, acilis_tarihi,durum_kodu,musteri_dk_no,ekstre_basim_kodu,dekont,ana_vadeli_hesap_no) --seval.colak 24062022 ana_vadeli_hesap_no eklendi
        values ( pn_musteri_no,ln_accrual_int_accountno,pkg_hesap.modul_tur_vadeli,'ACCRUAL',ls_accrual_int_urun_sinif,ls_kisa_isim,ls_doviz_kodu,ls_sube_kodu,0,ld_valor_tarihi,pd_acilis_tarihi,'A',lv_musteri_dkno,'X','X',pn_ana_hesap_no); --seval.colak 24062022 ana_vadeli_hesap_no eklendi
         
        pkg_hesap.hesap_bakiye_olustur(ln_accrual_int_accountno,0, 0, 0,ls_bakiye_karakteri); 
    
        update cbs_hesap_vadeli
        set accrual_int_account_no =ln_accrual_int_accountno
        where hesap_No=pn_ana_hesap_no;    
     end if;
                 
    RETURN ln_accrual_int_accountno;
    
EXCEPTION
       WHEN GecerliDKHesap_Bulunamadi THEN
              RAISE_APPLICATION_ERROR(-20100,l_uc || '2040' || l_ara || 'DK Grup Kodu'||ls_dkgrup_kodu||' '|| 'Tur-Sinif'||ls_urun_tur_kod||ls_urun_sinif_kod||lv_musteri_dkno || l_ara || ls_doviz_kodu || l_uc);
       WHEN GecerliTRLDKHesap_Bulunamadi THEN
              RAISE_APPLICATION_ERROR(-20100,l_uc || '2040' || l_ara || 'DK Grup Kodu'||ls_dkgrup_kodu||' '||'Tur-Sinif'||ls_urun_tur_kod||ls_urun_sinif_kod||lv_musteri_dkno || l_ara || Pkg_Genel.lc_al || l_uc);
     END;
------------------------------------------------------------------------------------------------------------
--AccrualVadeliHesapAcilis_Full tek sefer calistirilacatir. Conversion sirasinda mevcut olan tum acik vadeli hesaplar icin accrual int hesaplarin acilmasi icin hazirlandi.
PROCEDURE AccrualVadeliHesapAcilis_Full(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is 
    ln_hesap_no number ;
    ln_accrual_int_accountno number;
    ln_musteri_no   number;
    ls_accrual_int_hesap_durum varchar2(1);

    CURSOR cur_hesap IS
        select  musteri_no,
                hesap_no,
                accrual_int_account_no
         from cbs_hesap_vadeli  a
         where a.durum_kodu = 'A' and
               a.urun_tur_kod not in ('ACCRUAL') and
              ( ( nvl(accrual_int_account_no,0) = 0  ) or ( nvl(accrual_int_account_no,0)<> 0 and  PKG_HESAP.HESAPTANDURUMAL(accrual_int_account_no) <>'A'))--seval.colak 24062022 accrual_int_account_no durumu active olmayan hesaplar icin acilmasi saglandi.  
         order by hesap_no;   
   BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   for c_hesap in cur_hesap loop
        ln_musteri_no := c_hesap.musteri_No;
        ln_hesap_no   := c_hesap.hesap_no;
        ln_accrual_int_accountno := c_hesap.accrual_int_account_no;     
   --accrual hesap acilis       
        if nvl(ln_accrual_int_accountno,0) <> 0 then  
            select durum_kodu
            into   ls_accrual_int_hesap_durum 
            from cbs_hesap_vadeli
            where hesap_no = ln_accrual_int_accountno  ;
             if ls_accrual_int_hesap_durum <> 'A' then 
                ln_accrual_int_accountno := null;
             end if; 
        end if;    
     
          IF  nvl(ln_accrual_int_accountno,0) = 0 THEN     
               ln_accrual_int_accountno:= pkg_hesap.AccrualVadeliHesapAcilis(  ln_musteri_no ,       
                                                                               ln_hesap_no ) ;
              Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6820'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_accrual_int_accountno)||Pkg_Hata.GetDelimiter||TO_CHAR(ln_hesap_no)||Pkg_Hata.GetUCPOINTER);
                    
          END IF;

    end loop;
 commit;
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
        rollback;
    LOG_AT('AccrualVadeliHesapAcilis_Full',ln_hesap_no,ln_accrual_int_accountno,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||ln_hesap_no ||' '||TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
------------------------------------------------------------------------------------------------------------
FUNCTION OncekiGunBakiyeAlTarihli(pn_hesapno NUMBER,pd_tarih DATE DEFAULT Pkg_Muhasebe.banka_tarihi_bul) RETURN NUMBER IS
		 ln_bakiye					  NUMBER;
		 ld_date					  DATE;
 BEGIN
	 ld_date:= Pkg_Tarih.geri_is_gunu(NVL(pd_tarih,Pkg_Muhasebe.banka_tarihi_bul));

	 SELECT b.BAKIYE
	 INTO ln_bakiye
	 FROM CBS_HESAP_GUNLUK_BAKIYE b
	 WHERE b.hesap_no=pn_hesapno
	 AND balance_date = ld_date;

	 RETURN ln_bakiye;
 EXCEPTION
	 WHEN OTHERS THEN 	  RETURN 0;
 END;
------------------------------------------------------------------------------------------
     
END Pkg_Hesap;
/

