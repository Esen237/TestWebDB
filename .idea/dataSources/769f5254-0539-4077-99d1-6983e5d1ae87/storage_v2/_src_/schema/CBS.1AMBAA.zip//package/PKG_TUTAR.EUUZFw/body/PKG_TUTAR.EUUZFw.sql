create PACKAGE BODY     Pkg_Tutar IS
  -- General package to turn a number into a string
  -- ..ie..71 - Seventy One
  -- Savas Sasmaz
  -- 23-08-2000
  -- Table structure to hold names of numeric components.
    TYPE numwords_tabtype IS TABLE OF VARCHAR2(2000)
        INDEX BY BINARY_INTEGER;

  TYPE numwords_btabtype IS TABLE OF BOOLEAN
    INDEX BY BINARY_INTEGER;

    words_table        numwords_tabtype;
    words_table_rol1a  numwords_tabtype;
    words_table_rol1b  numwords_tabtype;
    words_table_rol2   numwords_tabtype;
    words_table_rol3   numwords_tabtype;
    words_table_rol1c  numwords_btabtype;

  FUNCTION CC_al RETURN VARCHAR2 IS
  BEGIN
    RETURN 'KG';
  END;

  FUNCTION TUTAR_YUZ(p_tutar NUMBER,p_doviz_kod VARCHAR2) RETURN VARCHAR2 IS

  TYPE array_3 IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  TYPE array_2 IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  s_array_3            array_3;
  s_array_2            array_2;
  s_max_dt            VARCHAR2(40);
  s_token_1            VARCHAR2(10);
  s_token_2            VARCHAR2(10);
  s_token_3            VARCHAR2(10);
  s_yuz                VARCHAR2(10):='yuz';
  s_tutar            VARCHAR2(200);
  n_token_1            NUMBER;
  n_token_2            NUMBER;
  n_token_3            NUMBER;
  n_length            NUMBER;

  BEGIN

    -- init variables
    s_array_3(0) := '';
    s_array_3(1) := 'bir';
    s_array_3(2) := 'iki';
    s_array_3(3) := 'uc';
    s_array_3(4) := 'dort';
    s_array_3(5) := 'bes';
    s_array_3(6) := 'alti';
    s_array_3(7) := 'yedi';
    s_array_3(8) := 'sekiz';
    s_array_3(9) := 'dokuz';

    s_array_2(0) := '';
    s_array_2(1) := 'on';
    s_array_2(2) := 'yirmi';
    s_array_2(3) := 'otuz';
    s_array_2(4) := 'kirk';
    s_array_2(5) := 'elli';
    s_array_2(6) := 'altmis';
    s_array_2(7) := 'yetmis';
    s_array_2(8) := 'seksen';
    s_array_2(9) := 'doksan';

    SELECT    MOD(p_tutar,10)
    INTO        n_token_3
    FROM        DUAL;

    IF (p_tutar >= 200) AND (p_tutar < 1000) THEN
        -- handle 200-1000
        SELECT    TRUNC((p_tutar/100),0)
        INTO        n_token_1
        FROM         DUAL;

        SELECT    TRUNC((MOD(p_tutar,100)/10),0)
        INTO        n_token_2
        FROM         DUAL;

        IF n_token_2 = 0 THEN
                RETURN INITCAP(REPLACE((s_array_3(n_token_1) || ' ' || s_yuz || ' ' || s_array_3(n_token_3)),' ',''));
        ELSE
                RETURN INITCAP(REPLACE((s_array_3(n_token_1) || ' ' || s_yuz || ' ' || s_array_2(n_token_2) || ' ' || s_array_3(n_token_3)),' ',''));
        END IF;

    ELSIF (p_tutar >= 100) AND (p_tutar < 200) THEN
        -- handle 100-200
        SELECT    TRUNC((p_tutar/100),0)
        INTO        n_token_1
        FROM        DUAL;

        SELECT    TRUNC((MOD(p_tutar,100)/10),0)
        INTO        n_token_2
        FROM        DUAL;

        IF n_token_2 = 0 THEN
                RETURN INITCAP(REPLACE((s_yuz || ' ' || s_array_3(n_token_3)),' ',''));
        ELSE
                RETURN INITCAP(REPLACE((s_yuz || ' ' || s_array_2(n_token_2) || ' ' || s_array_3(n_token_3)),' ',''));
        END IF;

    ELSIF (p_tutar >= 10) AND (p_tutar < 100) THEN
        -- handle 10-100
        n_token_1 := 0;

        SELECT    TRUNC((p_tutar/10),0)
        INTO        n_token_2
        FROM         DUAL;

        RETURN INITCAP(REPLACE((s_array_2(n_token_2) || ' ' || s_array_3(n_token_3)),' ',''));

    ELSIF (p_tutar < 10) AND (p_tutar >= 0) THEN
        -- handle 0-10
        SELECT    MOD(p_tutar,10)
        INTO        n_token_3
        FROM         DUAL;

        s_array_3(0) := 'sifir';

        RETURN INITCAP(REPLACE((s_array_3(n_token_3)),' ',''));

    END IF;

    EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RETURN -2000149;

  END;

  FUNCTION YAZI_TUTAR(p_tutar NUMBER,p_doviz_kod VARCHAR2) RETURN VARCHAR2 IS

  TYPE array_1 IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  n_temp            NUMBER;
  n_length        NUMBER; -- sayinin uzunlugu
  n_count            NUMBER; -- for loop variablei
  n_limit            NUMBER; -- loopun icine n_limit kadar girecek
  n_total            NUMBER;
  n_decimal        NUMBER;
  n_tutar_dc    NUMBER; -- decimal tutar

  s_array_1            array_1;
  s_tutar                VARCHAR2(200);
  s_tutar_dc        VARCHAR2(30); -- decimal tutar
  s_aciklama        VARCHAR2(50); -- Turk Lirasi
  s_temp                VARCHAR2(3);
  s_local                VARCHAR2(3);
  s_decimal            VARCHAR2(2);
  s_kurus                VARCHAR2(20); -- Kurus

  s_yazi                VARCHAR2(2000);      -- yazi seklinde dondurulen stringin TL bolumu
  s_yazi_kurus    VARCHAR2(40);  -- yazi seklinde dondurulen stringin kurus bolumu

  BEGIN

  s_local := Pkg_Genel.lc_al;

  IF s_local = Pkg_Genel.lc_al THEN

            -- init variables
            s_yazi := '';
            s_decimal := '';
            s_array_1(0) := '';
            s_array_1(1) := 'bin';
            s_array_1(2) := 'milyon';
            s_array_1(3) := 'milyar';
            s_array_1(4) := 'trilyon';
            s_array_1(5) := 'katrilyon';

            -- decimal or not ?!
            SELECT    INSTR(TO_CHAR(p_tutar),',')        INTO        n_decimal        FROM         DUAL;

            -- total length of number
            SELECT    LENGTH(TO_CHAR(p_tutar))            INTO        n_total            FROM        DUAL;

    IF n_decimal = 0 THEN
        SELECT    TO_CHAR(p_tutar)    INTO        s_tutar        FROM         DUAL;
        SELECT    LENGTH(s_tutar)        INTO        n_length    FROM         DUAL;
    ELSE
        SELECT    SUBSTR(TO_CHAR(p_tutar),1,n_decimal-1)        INTO        s_tutar        FROM         DUAL;
        SELECT    LENGTH(s_tutar)                                INTO        n_length    FROM         DUAL;

        -- handle difference between 3.2 and 3.26
        IF n_total-n_length = 3 THEN
            SELECT    SUBSTR(TO_CHAR(p_tutar),n_decimal+1,2)          INTO         s_tutar_dc    FROM         DUAL;
        ELSE
            SELECT     SUBSTR(TO_CHAR(p_tutar),n_decimal+1,1) || '0'    INTO        s_tutar_dc    FROM         DUAL;
        END IF;
        SELECT    TO_NUMBER(s_tutar_dc)        INTO         n_tutar_dc        FROM         DUAL;

    END IF;

    SELECT    TRUNC(((n_length-1)/3),0) + 1    INTO         n_limit    FROM         DUAL;

    SELECT    aciklama, kurus_adi
  INTO         s_aciklama, s_kurus
  FROM         CBS_DOVIZ_KODLARI
  WHERE     doviz_kodu = p_doviz_kod;

    -- loop to handle number by groups of 3 digits.....
    FOR n_count IN 1..n_limit LOOP

        IF LENGTH(s_tutar) > 3 THEN
                s_temp := SUBSTR(s_tutar,(-3),3);
        ELSE
                s_temp := s_tutar;
        END IF;

        SELECT    NVL(TO_NUMBER(s_temp),0)        INTO        n_temp        FROM         DUAL;
        s_yazi := ' ' ||  TUTAR_YUZ(n_temp,p_doviz_kod) || ' ' || s_array_1(n_count-1) || s_yazi ;
        s_tutar := SUBSTR(s_tutar,1,LENGTH(s_tutar)-3);

    END LOOP;

    IF n_limit != 1 THEN
            SELECT REPLACE(s_yazi,'Sifir', '') INTO s_yazi FROM dual;
    END IF;

        SELECT LTRIM(REPLACE(s_yazi,' ', '')) INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'Birbin', 'Bin') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'milyonbin', 'milyon') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'SifirbinSifir', '') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'Sifir', '') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'milyarmilyon', 'milyar') INTO s_yazi FROM dual;--Gulnihal 23/09/2003
        SELECT REPLACE(s_yazi,'trilyonmilyar', 'trilyon') INTO s_yazi FROM dual;--Gulnihal 23/09/2003
        SELECT REPLACE(s_yazi,'katrilyontrilyon', 'katrilyon') INTO s_yazi FROM dual;--Gulnihal 23/09/2003

    IF n_decimal = 0 THEN

        SELECT    s_yazi || ',%00, ' || p_doviz_kod        INTO        s_yazi        FROM         DUAL;
--        s_yazi := s_yazi || ' ' || s_aciklama;

        RETURN s_yazi;
    ELSE
        s_yazi_kurus := TUTAR_YUZ(n_tutar_dc,p_doviz_kod);

        SELECT    s_yazi || ',%' || s_tutar_dc || ', ' || p_doviz_kod
        INTO        s_yazi
        FROM         DUAL;
--        s_yazi := s_yazi || s_aciklama || ' ' || s_yazi_kurus || ' ' || s_kurus;

        RETURN s_yazi;
    END IF;

 ELSIF s_local = 'ROL' THEN

  RETURN num2words_rol(p_tutar) || ', ' || p_doviz_kod;

 ELSE

    SELECT    aciklama  INTO         s_aciklama  FROM         CBS_DOVIZ_KODLARI      WHERE     doviz_kodu = p_doviz_kod;
    RETURN num2words(p_tutar) || s_aciklama;

 END IF;

    EXCEPTION
              WHEN NO_DATA_FOUND THEN
            RETURN -2000149;

 END;


 FUNCTION num2words (number_in IN NUMBER) RETURN VARCHAR2
          -- USD degerler icin cagriliyor... ingilizce...
    IS
        my_number NUMBER;
 BEGIN
        -- Sorry, I don't do cents in this program!
        my_number := FLOOR (number_in);

        -- $1000000 +
        IF my_number >= 1000000    THEN
            -- Break up into two recursive calls to num2words.
            RETURN num2words (my_number/1000000) || ' Million ' || num2words (MOD (my_number, 1000000));
        END IF;

        -- $1000 +
        IF my_number >= 1000 THEN
            -- Break up into two recursive calls to num2words.
            RETURN num2words (my_number/1000) || ' Thousand ' || num2words (MOD (my_number, 1000));
        END IF;

        -- $100 - $999
        IF my_number >= 100 THEN
            -- Break up into two recursive calls to num2words.
            RETURN num2words (my_number/100) || ' Hundred ' || num2words (MOD (my_number, 100));
        END IF;

        -- $20 - $99
        IF my_number >= 20 THEN
            -- Break up into tens word and then final dollar amount.
            RETURN words_table (FLOOR (my_number/10)) || ' ' || num2words (MOD (my_number, 10));
        END IF;

        -- Down to 19 or less. Get word from "upper register" of table.
        RETURN words_table (my_number + 10);

    END num2words;
    
    /*Cash amounts Rounding function*/
 Function Rounding(amount number) return number is
 
   ln_rounded_temp           number:=0; 
   ln_rounded_temp_r        number:=0; 
   ln_rounded number:=0;
   
     begin
          ln_rounded_temp := mod(amount,1);--Start CQ516 Roundings KonstantinJ 28052014
   

    If ln_rounded_temp>=0.01 and ln_rounded_temp<=0.24 then
       ln_rounded_temp_r:=0;
    end if;
    
    If ln_rounded_temp>=0.25 and ln_rounded_temp <=0.49 then
       ln_rounded_temp_r:=0.50;
    end if;

   If ln_rounded_temp>=0.50 and ln_rounded_temp<=0.74 then
       ln_rounded_temp_r:=0.50;
    end if;

   If ln_rounded_temp>=0.75 and ln_rounded_temp<=0.99 then
       ln_rounded_temp_r:=1;
    end if;

     ln_rounded:= (amount- ln_rounded_temp) + ln_rounded_temp_r;--end CQ516 Roundings KonstantinJ 28052014
     return ln_rounded;
     end;

/*________________________________________________________________________________________*/

  FUNCTION fill_text(p_tutar3 IN NUMBER,p_una IN BOOLEAN) RETURN VARCHAR2 IS

    n_token_1            NUMBER;
    n_token_2            NUMBER;
    n_token_3            NUMBER;
    p_text        VARCHAR2(2000);

  BEGIN

      SELECT    MOD(p_tutar3,10)                  INTO        n_token_1      FROM        DUAL;
      SELECT    TRUNC((MOD(p_tutar3,100)/10),0)    INTO        n_token_2        FROM         DUAL;
      SELECT    TRUNC((p_tutar3/100),0)              INTO        n_token_3        FROM         DUAL;
    IF n_token_3 <> 0 THEN
       IF n_token_3 = 1 THEN
          p_text := 'osuta';
       ELSE
          p_text := words_table_rol2(n_token_3) || 'sute';
       END IF;
    END IF;
    IF n_token_2 <> 0 THEN
       IF n_token_2 = 1 THEN
          p_text := p_text || words_table_rol3(n_token_1+1);
       ELSE
          p_text := p_text || words_table_rol2(n_token_2) || 'zeci';
       END IF;
    END IF;
    IF n_token_1 <> 0 AND n_token_2 <> 1 THEN
       IF n_token_2 <> 0 THEN
          p_text := p_text || 'si' ;
       END IF;
       IF n_token_1 = 1 THEN
          IF p_una THEN
             IF n_token_3 = 0  AND n_token_2 = 0 THEN
                p_text := p_text || 'un';
             ELSE
                p_text := p_text || 'unu';
             END IF;
          ELSE
             p_text := p_text || 'una';
          END IF;
       ELSE
          p_text := p_text || words_table_rol2(n_token_1);
       END IF;
    END IF;
    RETURN p_text;
  END;
/*________________________________________________________________________________________*/

  FUNCTION num2words_rol(p_tutar NUMBER) RETURN VARCHAR2 IS

  s_text              VARCHAR2(2000);
  s_tutar                      VARCHAR2(200);
  s_temp                      VARCHAR2(3);
  s_tutar_dc              VARCHAR2(30); -- decimal tutar

  n_temp              NUMBER;
  n_length                  NUMBER;
  n_limit             NUMBER;
  n_count             NUMBER;
  n_tutar_dc            NUMBER; -- decimal tutar
  n_last3                    NUMBER;

  e_too_many_digit    EXCEPTION;

  BEGIN

    SELECT    TO_CHAR(TRUNC(p_tutar,0))            INTO        s_tutar          FROM         DUAL;
    SELECT    LENGTH(s_tutar)                      INTO        n_length      FROM         DUAL;

  n_tutar_dc := (p_tutar - TRUNC(p_tutar,0)) * 100;
    SELECT    TO_CHAR(n_tutar_dc,'00')            INTO      s_tutar_dc    FROM         DUAL;

  IF n_length > 15 THEN
     RAISE e_too_many_digit;
  END IF;

    SELECT    TRUNC(((n_length-1)/3),0) + 1      INTO         n_limit        FROM         DUAL;

    -- loop to handle number by groups of 3 digits.....
    FOR n_count IN 0..n_limit-1 LOOP

        IF LENGTH(s_tutar) > 3 THEN
                s_temp := SUBSTR(s_tutar,(-3),3);
        ELSE
                s_temp := s_tutar;
        END IF;

        SELECT    NVL(TO_NUMBER(s_temp),0)        INTO        n_temp        FROM         DUAL;

    IF n_count <> 0 THEN
      IF n_temp = 1 THEN
         s_text := fill_text(n_temp,words_table_rol1c(n_count)) ||  words_table_rol1a(n_count) || s_text;
      ELSE
         s_text := fill_text(n_temp,words_table_rol1c(n_count)) ||  words_table_rol1b(n_count) || s_text;
      END IF;
    ELSE
          s_text := fill_text(n_temp,words_table_rol1c(n_count)) || s_text;
      n_last3 := n_temp;
    END IF;

        s_tutar := SUBSTR(s_tutar,1,LENGTH(s_tutar)-3);

    END LOOP;

/*  if mod(n_last3,100)    = 0 and    trunc((mod(n_last3,100)/10),0)    = 0 then
     s_text := s_text || 'leu';
  else
     s_text := s_text || 'lei';
  end if;
*/
  s_text :=    s_text || ',%' || s_tutar_dc ;
    SELECT LTRIM(REPLACE(s_text,' ', '')) INTO s_text FROM dual;

/*    IF n_tutar_dc <> 0 THEN
    if n_tutar_dc = 1 then
       s_text := s_text || 'si' || fill_text(n_tutar_dc,false) || 'ban';
    else
       s_text := s_text || 'si' || fill_text(n_tutar_dc,false) || 'bani';
    end if;
    END IF;
*/
  RETURN s_text;

  EXCEPTION
    WHEN e_too_many_digit THEN
        RETURN -2000148;
      WHEN NO_DATA_FOUND THEN
            RETURN -2000149;
      WHEN OTHERS THEN
            RETURN -2000149;
  END;
/***************************************************************************/
  FUNCTION Number2Words(p_tutar NUMBER,p_doviz_kod VARCHAR2,p_dil_kodu VARCHAR2) RETURN VARCHAR2 IS

  TYPE array_1 IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
  n_temp            NUMBER;
  n_length        NUMBER; -- sayinin uzunlugu
  n_count            NUMBER; -- for loop variablei
  n_limit            NUMBER; -- loopun icine n_limit kadar girecek
  n_total            NUMBER;
  n_decimal        NUMBER;
  n_tutar_dc    NUMBER; -- decimal tutar

  s_array_1            array_1;
  s_tutar                VARCHAR2(200);
  s_tutar_dc        VARCHAR2(30); -- decimal tutar
  s_aciklama        VARCHAR2(50); -- Turk Lirasi
  s_temp                VARCHAR2(3);
  s_local                VARCHAR2(3);
  s_decimal            VARCHAR2(2);
  s_kurus                VARCHAR2(20); -- Kurus

  s_yazi                VARCHAR2(2000);      -- yazi seklinde dondurulen stringin TL bolumu
  s_yazi_kurus    VARCHAR2(40);  -- yazi seklinde dondurulen stringin kurus bolumu

  BEGIN

  s_local := p_dil_kodu;

  IF s_local = Pkg_Tutar.CC_al THEN

            -- init variables
            s_yazi := '';
            s_decimal := '';
            s_array_1(0) := '';
            s_array_1(1) := 'bin';
            s_array_1(2) := 'milyon';
            s_array_1(3) := 'milyar';
            s_array_1(4) := 'trilyon';
            s_array_1(5) := 'katrilyon';

            -- decimal or not ?!
            SELECT    INSTR(TO_CHAR(p_tutar),',')        INTO        n_decimal        FROM         DUAL;

            -- total length of number
            SELECT    LENGTH(TO_CHAR(p_tutar))            INTO        n_total            FROM        DUAL;

    IF n_decimal = 0 THEN
        SELECT    TO_CHAR(p_tutar)    INTO        s_tutar        FROM         DUAL;
        SELECT    LENGTH(s_tutar)        INTO        n_length    FROM         DUAL;
    ELSE
        SELECT    SUBSTR(TO_CHAR(p_tutar),1,n_decimal-1)        INTO        s_tutar        FROM         DUAL;
        SELECT    LENGTH(s_tutar)                                INTO        n_length    FROM         DUAL;

        -- handle difference between 3.2 and 3.26
        IF n_total-n_length = 3 THEN
            SELECT    SUBSTR(TO_CHAR(p_tutar),n_decimal+1,2)          INTO         s_tutar_dc    FROM         DUAL;
        ELSE
            SELECT     SUBSTR(TO_CHAR(p_tutar),n_decimal+1,1) || '0'    INTO        s_tutar_dc    FROM         DUAL;
        END IF;
        SELECT    TO_NUMBER(s_tutar_dc)        INTO         n_tutar_dc        FROM         DUAL;

    END IF;

    SELECT    TRUNC(((n_length-1)/3),0) + 1    INTO         n_limit    FROM         DUAL;

    SELECT    aciklama, kurus_adi
  INTO         s_aciklama, s_kurus
  FROM         CBS_DOVIZ_KODLARI
  WHERE     doviz_kodu = p_doviz_kod;

    -- loop to handle number by groups of 3 digits.....
    FOR n_count IN 1..n_limit LOOP

        IF LENGTH(s_tutar) > 3 THEN
                s_temp := SUBSTR(s_tutar,(-3),3);
        ELSE
                s_temp := s_tutar;
        END IF;

        SELECT    NVL(TO_NUMBER(s_temp),0)        INTO        n_temp        FROM         DUAL;
        s_yazi := ' ' ||  TUTAR_YUZ(n_temp,p_doviz_kod) || ' ' || s_array_1(n_count-1) || s_yazi ;
        s_tutar := SUBSTR(s_tutar,1,LENGTH(s_tutar)-3);

    END LOOP;

    IF n_limit != 1 THEN
            SELECT REPLACE(s_yazi,'Sifir', '') INTO s_yazi FROM dual;
    END IF;

        SELECT LTRIM(REPLACE(s_yazi,' ', '')) INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'Birbin', 'Bin') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'milyonbin', 'milyon') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'SifirbinSifir', '') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'Sifir', '') INTO s_yazi FROM dual;
        SELECT REPLACE(s_yazi,'milyarmilyon', 'milyar') INTO s_yazi FROM dual;--Gulnihal 23/09/2003
        SELECT REPLACE(s_yazi,'trilyonmilyar', 'trilyon') INTO s_yazi FROM dual;--Gulnihal 23/09/2003
        SELECT REPLACE(s_yazi,'katrilyontrilyon', 'katrilyon') INTO s_yazi FROM dual;--Gulnihal 23/09/2003

    IF n_decimal = 0 THEN

        SELECT    s_yazi || ',%00, ' || p_doviz_kod        INTO        s_yazi        FROM         DUAL;
--        s_yazi := s_yazi || ' ' || s_aciklama;
        s_yazi := Pkg_Tutar.f_get_token(s_yazi, ',') || ' ' || Pkg_Genel.doviz_adi_al(p_doviz_kod) ;
        RETURN s_yazi;
    ELSE
        s_yazi_kurus := TUTAR_YUZ(n_tutar_dc,p_doviz_kod);

        SELECT    s_yazi || ',%' || s_tutar_dc || ', ' || p_doviz_kod
        INTO        s_yazi
        FROM         DUAL;
--        s_yazi := s_yazi || s_aciklama || ' ' || s_yazi_kurus || ' ' || s_kurus;

        RETURN s_yazi;
    END IF;

 ELSIF s_local = 'ROL' THEN

  RETURN num2words_rol(p_tutar) || ', ' || p_doviz_kod;

 ELSE

    SELECT    aciklama  INTO         s_aciklama  FROM         CBS_DOVIZ_KODLARI      WHERE     doviz_kodu = p_doviz_kod;
    RETURN num2words(p_tutar) || s_aciklama;

 END IF;

    EXCEPTION
              WHEN NO_DATA_FOUND THEN
            RETURN -2000149;

 END;
/**************************************************************/
  FUNCTION f_get_token(ps_sourcetext IN OUT VARCHAR2, ps_separator VARCHAR2) RETURN VARCHAR2
  IS
    ln_adet           NUMBER;
    ls_sourcetext  VARCHAR2(1000);
    ls_RET         VARCHAR2(1000);

  BEGIN
        /*Verilen sourcetext i?inde , verilen ayrac? ilk g?rd??? yere kadar olan text'i ve geri kalan k?sm?n? dondurur. */
        ls_sourcetext :=ps_sourcetext;
        ln_adet       := INSTR(ls_sourcetext, ps_separator);
        IF ln_adet = 0 THEN
            ls_RET              := ls_sourcetext        ;
            ps_sourcetext := NULL        ;
--            ls_sourcetext := null        ;  Muhasebe plan?n? i?eri atarken kullandu??m?zdan de?i?ti
        ELSE
            ls_RET           := SUBSTR(ls_sourcetext, 1, ln_adet - 1)    ;
            ps_sourcetext := SUBSTR(ls_sourcetext, LENGTH(ls_RET)+2,LENGTH(ls_sourcetext) - ln_adet);
        END IF;

        RETURN ls_RET;

  END f_get_token;

BEGIN
    words_table (0) := 'Zero';
    words_table (1) := 'Ten';
    words_table (2) := 'Twenty';
    words_table (3) := 'Thirty';
    words_table (4) := 'Forty';
    words_table (5) := 'Fifty';
    words_table (6) := 'Sixty';
    words_table (7) := 'Seventy';
    words_table (8) := 'Eighty';
    words_table (9) := 'Ninety';
    words_table (10) := '';

    words_table (11) := 'One';
    words_table (12) := 'Two';
    words_table (13) := 'Three';
    words_table (14) := 'Four';
    words_table (15) := 'Five';
    words_table (16) := 'Six';
    words_table (17) := 'Seven';
    words_table (18) := 'Eight';
    words_table (19) := 'Nine';
    words_table (20) := 'Ten';
    words_table (21) := 'Eleven';
    words_table (22) := 'Twelve';
    words_table (23) := 'Thirteen';
    words_table (24) := 'Fourteen';
    words_table (25) := 'Fifteen';
    words_table (26) := 'Sixteen';
    words_table (27) := 'Seventeen';
    words_table (28) := 'Eightteen';
    words_table (29) := 'Nineteen';

    -- init variables
    words_table_rol1a(0) := '';
    words_table_rol1a(1) := 'mie';
    words_table_rol1a(2) := 'milion';
    words_table_rol1a(3) := 'miliard';
  words_table_rol1a(4) := 'miemiliarde';

    words_table_rol1b(0) := '';
    words_table_rol1b(1) := 'mii';
    words_table_rol1b(2) := 'milioane';
    words_table_rol1b(3) := 'miliarde';
  words_table_rol1b(4) := 'miimiliarde';

    words_table_rol1c(0) := TRUE;
    words_table_rol1c(1) := FALSE;
    words_table_rol1c(2) := TRUE;
    words_table_rol1c(3) := TRUE;
  words_table_rol1c(4) := FALSE;

    words_table_rol2(0) := '';
    words_table_rol2(1) := 'una';
    words_table_rol2(2) := 'doua';
    words_table_rol2(3) := 'trei';
    words_table_rol2(4) := 'patru';
    words_table_rol2(5) := 'cinci';
    words_table_rol2(6) := 'sase';
    words_table_rol2(7) := 'sapte';
    words_table_rol2(8) := 'opt';
    words_table_rol2(9) := 'noua';

    words_table_rol3(0) := '';
    words_table_rol3(1) := 'zece';
    words_table_rol3(2) := 'unsprezece';
    words_table_rol3(3) := 'doisprezece';
    words_table_rol3(4) := 'treisprezece';
    words_table_rol3(5) := 'patrusprezece';
    words_table_rol3(6) := 'cincisprezece';
    words_table_rol3(7) := 'sasesprezece';
    words_table_rol3(8) := 'saptesprezece';
    words_table_rol3(9) := 'optsprezece';
    words_table_rol3(10) := 'nouasprezece';

END;
/

