create PACKAGE BODY     PKG_TX1323 IS
--
    pn_1323_musteri_aciklama    NUMBER;
    pn_1323_referans    NUMBER;
    pn_1323_fis_aciklama    NUMBER;
    pn_1323_kur    NUMBER;
    pn_1323_banka_aciklama    NUMBER;
    pn_1323_kredi_doviz    NUMBER;
    pn_1323_islem_sube    NUMBER;
    pn_1323_kredi_tl    NUMBER;
    pn_1323_kredi_yp    NUMBER;
    pn_1323_iliskili_faiz_dk    NUMBER;
    pn_1323_kredi_hesap_no    NUMBER;
    pn_1323_kredi_hesap_sube    NUMBER;
    pn_1323_tax_aciklama    NUMBER;
    pn_1323_deferred_interest    NUMBER;
    pn_1323_deferred_interest_lc    NUMBER;
    pn_1323_deferred_tax    NUMBER;
    pn_1323_deferred_tax_lc    NUMBER;
    pn_1323_accrual_gecikme_faiz    NUMBER;
    pn_1323_accrual_gecikme_faiz_lc    NUMBER;
    pn_1323_gecikme_faiz_gl    NUMBER;
    pn_1323_accrual_gecikme_tax    NUMBER;
    pn_1323_accrual_gecikme_tax_lc    NUMBER;
    pn_1323_penalty_amount    NUMBER;
    pn_1323_penalty_amount_lc    NUMBER;
    pn_1323_penalty_tax    NUMBER;
    pn_1323_penalty_tax_lc    NUMBER;
    pn_1323_anapara    NUMBER;
    pn_1323_anapara_lc    NUMBER;
    pn_1323_iliskili_hesap_sube    NUMBER;
    pn_1323_iliskili_hesap_no    NUMBER;
    pn_1323_iliskili_hesap_doviz    NUMBER;
    pn_1323_toplam_faiz    NUMBER;
    pn_1323_toplam_faiz_lc    NUMBER;
    pn_1323_toplam_vergi    NUMBER;
    pn_1323_toplam_vergi_lc    NUMBER;
    pn_1323_penalty_toplam    NUMBER;
    pn_1323_penalty_toplam_lc    NUMBER;
    pn_1323_deferred_toplam    NUMBER;
    pn_1323_deferred_toplam_lc    NUMBER;
    pn_1323_gecikme_faiz_toplam    NUMBER;
    pn_1323_gecikme_faiz_toplam_lc    NUMBER;
    pn_1323_accrual_int_acct_no    NUMBER;
    pn_1323_accrual_tax_acct_no    NUMBER;
    pn_1323_accrual_delay_int_acct_no    NUMBER;
    pn_1323_nonaccrual_int_acct_no    NUMBER;
    pn_1323_nonaccrual_delay_int_acct    NUMBER;
    pn_1323_accrual_tahsil_faiz    NUMBER;
    pn_1323_nonaccrual_tahsil_faiz    NUMBER;
    pn_1323_accrual_tahsil_vergi    NUMBER;
    pn_1323_nonaccrual_tahsil_vergi    NUMBER;
    pn_1323_accrual_tahsil_faiz_lc    NUMBER;
    pn_1323_nonaccrual_tahsil_faiz_lc    NUMBER;
    pn_1323_accrual_tahsil_vergi_lc    NUMBER;
    pn_1323_nonaccrual_tahsil_vergi_l    NUMBER;
    pn_1323_defer_pen_toplam    NUMBER;
    pn_1323_defer_pen_toplam_lc    NUMBER;
    pn_1323_defer_pen_tax    NUMBER;
    pn_1323_defer_pen_tax_lc    NUMBER;
    pn_1323_defer_penalty    NUMBER;
    pn_1323_defer_penalty_lc    NUMBER;
    pn_1323_nonaccrual_gecikme_faiz    NUMBER;
    pn_1323_nonaccrual_gecikme_faiz_l    NUMBER;
    pn_1323_nonaccrual_gecikme_tax    NUMBER;
    pn_1323_nonaccrual_gecikme_tax_lc    NUMBER;
    pn_1323_accr_defer_int    NUMBER;
    pn_1323_accr_defer_int_lc    NUMBER;
    pn_1323_nonaccr_defer_int    NUMBER;
    pn_1323_nonaccr_defer_int_lc    NUMBER;
    pn_1323_accr_defer_del_int    NUMBER;
    pn_1323_accr_defer_del_int_lc    NUMBER;
    pn_1323_nonaccr_defer_del_int    NUMBER;
    pn_1323_nonaccr_defer_del_int_lc    NUMBER;
    pn_1323_ack_principial    NUMBER;
    pn_1323_ack_int    NUMBER;
    pn_1323_ack_tax    NUMBER;
    pn_1323_ack_delay_int    NUMBER;
    pn_1323_ack_delay_int_tax    NUMBER;
    pn_1323_ack_defer_int    NUMBER;
    pn_1323_ack_defer_tax    NUMBER;
    pn_1323_ack_penalty    NUMBER;
    pn_1323_ack_penalty_tax    NUMBER;
    pn_1323_ack_defer_delay_int    NUMBER;
    pn_1323_nonaccr_defer_int_tax    NUMBER;
    pn_1323_nonaccr_defer_int_tax_lc    NUMBER;
    pn_1323_nonaccr_def_del_int_tax    NUMBER;
    pn_1323_nonaccr_def_del_int_tax_l    NUMBER;
    pn_1323_ack_defer_int_tax    NUMBER;
    pn_1323_ack_defer_delay_int_tax    NUMBER;
    -- b-o-m seval.colak 07062022
    pn_1323_accr_defer_int_tax    NUMBER;
    pn_1323_accr_defer_int_tax_lc    NUMBER;
    pn_1323_accr_def_del_int_tax    NUMBER;
    pn_1323_accr_def_del_int_tax_l    NUMBER;
    -- e-o-m  seval.colak 07062022
    pn_1323_penalty_gl    NUMBER;   --seval.colak 01112022

Procedure Kontrol_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Sonrasi(pn_islem_no number) is
Begin
    Null;
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------

Procedure Onay_Sonrasi(pn_islem_no number) is
    
  Begin

      null;

  End;
  Function sf_iptal_edilebilirmi(pn_islem_no number ,pn_hesap_no number) return number
 is
  ln_tx_no number := 0 ;
  iptaledilemez            exception;
 Begin

       select max(numara)
      into   ln_tx_no
      from  cbs_islem
      where   durum  not in ('R','2') and
               islem_kod in( 3251,1323,1306,3252) and  --seval.colak 15092022 3252 eklendi.
             numara > pn_islem_no and
             hesap_numara = pn_hesap_no;

      if nvl(ln_tx_no,0) <> 0 then
        raise iptaledilemez;
      end if;

   return ln_tx_no ;

   Exception
    When iptaledilemez then
        raise_application_error(-20100,pkg_hata.getucpointer || '905' || pkg_hata.getDelimiter || to_char( ln_tx_no ) ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
        return ln_tx_no ;
     when others   then return 0;
 End;
--------------------------------------------------------------------------------
 Procedure Iptal_Onay_Sonrasi(pn_islem_no number)
  is
     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no;

/* sadece secilmis degil isleme giren tum taksitleri alinir. kredi vade guncellemesi yapilir*/
    cursor cursor_taksit is
    select *
    from cbs_hesap_kredi_taksit_islem
    where     tx_no = pn_islem_no;

    r_hesap      cur_hesap%rowtype;
    ln_numara     number := 0;
    ln_txno         number := 0;
  Begin

 /* islem bilgisi detaylari alinir */
          open cur_hesap;
         fetch cur_hesap into r_hesap;
        close cur_hesap;

   ln_numara := sf_iptal_edilebilirmi(pn_islem_no , r_hesap.hesap_no) ;
                                     
       update cbs_hesap_kredi
       set (    DURUM_KODU,  
                KREDI_VADE	,
                KREDI_KULLANDIRIM_KODU	,
                ENDEKS_DOVIZ_KODU	,
                KULLANDIRIM_DOVIZ_KODU	,
                SON_GUN_FAIZI	,
                ACILIS_KURU	,
                FAIZ_ORANI	,
                FAIZ_SIKLIK	,
                FAIZ_SIKLIK_TIPI	,
                FAIZ_TAHAKKUK_TARIHI	,
                KOMISYON_ORANI	,
                KOMISYON_TUTARI	,
                KOMISYON_TAHSILAT_DONEMI	,
                FON_ORANI	,
                BSMV_ORANI	,
                ALACAK_HESAP_NO	,
                ILISKILI_HESAP_NO	,
                KUR_FARKI	,
                EXTRE_MASRAFI	,
                SINIRLAMA_KODU	,
                KAYNAK_KODU	,
                ISTATISTIK_KODU	,
                URUN_GRUP_NO	,
                REFERANS	,
                FAIZ_TAHAKKUK_HESAP_NO	,
                VERGI_TAHAKKUK_HESAP_NO	,
                BIRIKMIS_FAIZ_TUTARI	,
                BIRIKMIS_KOMISYON_TUTARI	,
                ESAS_GUN_SAYISI	,
                ACILIS_TARIHI	,
                KAPANIS_TARIHI	,
                BSMV_ALINSIN	,
                KKDF_ALINSIN	,
                ENDEKS_DOVIZ_TUTARI	,
                GECENYIL_FAIZ_TUTARI	,
                TAHSILEDILEN_FAIZ_TUTARI	,
                TAHSILEDILEN_KOMISYON_TUTARI	,
                GECENYIL_KOMISYON_TUTARI	,
                BIRIKMIS_SCH_FAIZI	,
                GECENYIL_SCH_FAIZI	,
                SON_ISLEM_KURU	,
                GECENYIL_ANAPARAKURFARK_GELIR	,
                GECENYIL_ANAPARAKURFARK_ZARAR	,
                GECENYIL_FAIZKURFARK_GELIR	,
                GECENYIL_FAIZKURFARK_ZARAR	,
                GECENYIL_KOMISKURFARK_GELIR	,
                GECENYIL_KOMISKURFARK_ZARAR	,
                FAIZ_BASLANGIC_TARIHI	,
                SCH_FAIZ_ORANI	,
                ESKI_HESAP_NO	,
                ESKI_HESAP_EKNO	,
                ESKI_FAIZHESAP_EKNO	,
                ESKI_KOMHESAP_EKNO	,
                BIRIKMIS_FAIZ_TUTARI_ROUND	,
                BIRIKMIS_KOMISYON_TUTARI_ROUND	,
                AYS_BIRIKMIS_FAIZ_TUTARI_ROUND	,
                AYS_BIRIKMIS_KOMISYON_TUTARI_R	,
                KREDI_TURU	,
                TAKSIT_SAYISI	,
                TAKSIT_ONCE_SONRA	,
                ARTIS_SIKLIK	,
                ARTIS_ORAN	,
                ARA_ODEME_SIKLIK	,
                ARA_ODEME_TUTAR	,
                DONEM_SIKLIK	,
                ODEME_TURU	,
                SCH_FAIZ_TUR	,
                TEMDIT_TARIHI	,
                TAHAKKUK_SCH_FAIZ_TUTARI	,
                REPAYMENT_TYPE	,
                PREFIX_ISTATISTIK_KODU	,
                PREFIX_ISTATISTIK_KODU_FAIZ	,
                ISTATISTIK_KODU_FAIZ	,
                PREFIX_ISTATISTIK_KODU_KAPAMA	,
                ISTATISTIK_KODU_KAPAMA	,
                TAHSILEDILEN_FAIZ_TUTARI_LC	,
                TAHSILEDILEN_KOMIS_TUTARI_LC	,
                ANA_KREDI_HESAP_NO	,
                PASTDUE_FAIZ_ANAPARA_SEC	,
                ACILIS_KREDI_VADE	,
                PASTDUE_FAIZ_ORANI	,
                ESKI_HESAP_REFNO	,
                YEARLY_INT_RATE	,
                ESKI_DK_NO	,
                ALACAK_SECIMI	,
                ALACAK_DK_NO	,
                DISBURSEMENT_COMMISSION	,
                COMMISSION_ACCOUNT_NO	,
                GECMISYIL_TAHSIL_KOM_TOPLAMI	,
                GECMISYIL_TAHSIL_FAIZ_TOPLAMI	,
                GECMISYIL_TAHAKKUK_SCH_FAIZ	,
                CONTRACT_STATUS	,
                GECMIS_AYLARIN_FAIZI	,
                GECMIS_AYLARIN_KOMISYONU	,
                TAKSIT_BASLANGIC_TARIHI	,
                EK_TAKSIT_FAIZ	,
                REPORT_CUSTOMER_TYPE	,
                ACCRUED_INTEREST_TAX	,
                ACCRUED_COMMISSION_TAX	,
                APP_NO	,
                LOAN_NUMARA	,
                AGREEMENT_DATE	,
                AGREEMENT_NO	,               
                TRANSACTION_TYPE	,
                YEARLY_EFFECTIVE_INT_RATE	,
                PENALTY_AMOUNT	,
                NON_ACCRUAL_STATUS	,
                ODEME_PLAN_NO	,
                ODEME_GUNU	,
                TAKSIT_SIKLIK	,
                ODEMESIZ_AY_SAYISI	,
                FAIZ_YONTEMI_METHODU	,
                FAIZ_HESAPLAMA_TIPI	,
                PENALTY_RATE	,
                BIRIKMIS_GECIKME_FAIZ_TUTARI	,
                TAHSIL_GECIKME_FAIZ_TUTARI	,
                PAID_PENALTY_AMOUNT	,
                ADVANCED_COMMISSION_TYPE	,
                ADVANCED_COMMISSION_RATE	,
                ADVANCED_COMMISSION_AMOUNT	,
                GECENYIL_GECIKME_FAIZ	,
                GECENAY_GECIKME_FAIZ	,
                GECIKME_FAIZ_ACCRUEDTAX	,
                ACCRUAL_INT_ACCOUNT_NO	,
                ACCRUAL_TAX_ACCOUNT_NO	,
                ACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                NONACCRUAL_INT_ACCOUNT_NO	,
                NONACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                AP_GECIKME_GUN_SAYISI	,
                FAIZ_GECIKME_GUN_SAYISI	,
                LLP_RATE	,
                FAIZ_ORANI_TIPI	,
                MONTHLY_INT_RATE	,
                NON_ACCRUAL_STATUS_UPD_DATE,
                ACCRUAL_STATUS_UPD_DATE  )  --seval.colak 02112022
                  = 
                (select DURUM_KODU,
                KREDI_VADE	,
                KREDI_KULLANDIRIM_KODU	,
                ENDEKS_DOVIZ_KODU	,
                KULLANDIRIM_DOVIZ_KODU	,
                SON_GUN_FAIZI	,
                ACILIS_KURU	,
                FAIZ_ORANI	,
                FAIZ_SIKLIK	,
                FAIZ_SIKLIK_TIPI	,
                FAIZ_TAHAKKUK_TARIHI	,
                KOMISYON_ORANI	,
                KOMISYON_TUTARI	,
                KOMISYON_TAHSILAT_DONEMI	,
                FON_ORANI	,
                BSMV_ORANI	,
                ALACAK_HESAP_NO	,
                ILISKILI_HESAP_NO	,
                KUR_FARKI	,
                EXTRE_MASRAFI	,
                SINIRLAMA_KODU	,
                KAYNAK_KODU	,
                ISTATISTIK_KODU	,
                URUN_GRUP_NO	,
                REFERANS	,
                FAIZ_TAHAKKUK_HESAP_NO	,
                VERGI_TAHAKKUK_HESAP_NO	,
                BIRIKMIS_FAIZ_TUTARI	,
                BIRIKMIS_KOMISYON_TUTARI	,
                ESAS_GUN_SAYISI	,
                ACILIS_TARIHI	,
                KAPANIS_TARIHI	,
                BSMV_ALINSIN	,
                KKDF_ALINSIN	,
                ENDEKS_DOVIZ_TUTARI	,
                GECENYIL_FAIZ_TUTARI	,
                TAHSILEDILEN_FAIZ_TUTARI	,
                TAHSILEDILEN_KOMISYON_TUTARI	,
                GECENYIL_KOMISYON_TUTARI	,
                BIRIKMIS_SCH_FAIZI	,
                GECENYIL_SCH_FAIZI	,
                SON_ISLEM_KURU	,
                GECENYIL_ANAPARAKURFARK_GELIR	,
                GECENYIL_ANAPARAKURFARK_ZARAR	,
                GECENYIL_FAIZKURFARK_GELIR	,
                GECENYIL_FAIZKURFARK_ZARAR	,
                GECENYIL_KOMISKURFARK_GELIR	,
                GECENYIL_KOMISKURFARK_ZARAR	,
                FAIZ_BASLANGIC_TARIHI	,
                SCH_FAIZ_ORANI	,
                ESKI_HESAP_NO	,
                ESKI_HESAP_EKNO	,
                ESKI_FAIZHESAP_EKNO	,
                ESKI_KOMHESAP_EKNO	,
                BIRIKMIS_FAIZ_TUTARI_ROUND	,
                BIRIKMIS_KOMISYON_TUTARI_ROUND	,
                AYS_BIRIKMIS_FAIZ_TUTARI_ROUND	,
                AYS_BIRIKMIS_KOMISYON_TUTARI_R	,
                KREDI_TURU	,
                TAKSIT_SAYISI	,
                TAKSIT_ONCE_SONRA	,
                ARTIS_SIKLIK	,
                ARTIS_ORAN	,
                ARA_ODEME_SIKLIK	,
                ARA_ODEME_TUTAR	,
                DONEM_SIKLIK	,
                ODEME_TURU	,
                SCH_FAIZ_TUR	,
                TEMDIT_TARIHI	,
                TAHAKKUK_SCH_FAIZ_TUTARI	,
                REPAYMENT_TYPE	,
                PREFIX_ISTATISTIK_KODU	,
                PREFIX_ISTATISTIK_KODU_FAIZ	,
                ISTATISTIK_KODU_FAIZ	,
                PREFIX_ISTATISTIK_KODU_KAPAMA	,
                ISTATISTIK_KODU_KAPAMA	,
                TAHSILEDILEN_FAIZ_TUTARI_LC	,
                TAHSILEDILEN_KOMIS_TUTARI_LC	,
                ANA_KREDI_HESAP_NO	,
                PASTDUE_FAIZ_ANAPARA_SEC	,
                ACILIS_KREDI_VADE	,
                PASTDUE_FAIZ_ORANI	,
                ESKI_HESAP_REFNO	,
                YEARLY_INT_RATE	,
                ESKI_DK_NO	,
                ALACAK_SECIMI	,
                ALACAK_DK_NO	,
                DISBURSEMENT_COMMISSION	,
                COMMISSION_ACCOUNT_NO	,
                GECMISYIL_TAHSIL_KOM_TOPLAMI	,
                GECMISYIL_TAHSIL_FAIZ_TOPLAMI	,
                GECMISYIL_TAHAKKUK_SCH_FAIZ	,
                CONTRACT_STATUS	,
                GECMIS_AYLARIN_FAIZI	,
                GECMIS_AYLARIN_KOMISYONU	,
                TAKSIT_BASLANGIC_TARIHI	,
                EK_TAKSIT_FAIZ	,
                REPORT_CUSTOMER_TYPE	,
                ACCRUED_INTEREST_TAX	,
                ACCRUED_COMMISSION_TAX	,
                APP_NO	,
                LOAN_NUMARA	,
                AGREEMENT_DATE	,
                AGREEMENT_NO	,
                TRANSACTION_TYPE	,
                YEARLY_EFFECTIVE_INT_RATE	,
                PENALTY_AMOUNT	,
                NON_ACCRUAL_STATUS	,
                ODEME_PLAN_NO	,
                ODEME_GUNU	,
                TAKSIT_SIKLIK	,
                ODEMESIZ_AY_SAYISI	,
                FAIZ_YONTEMI_METHODU	,
                FAIZ_HESAPLAMA_TIPI	,
                PENALTY_RATE	,
                BIRIKMIS_GECIKME_FAIZ_TUTARI	,
                TAHSIL_GECIKME_FAIZ_TUTARI	,
                PAID_PENALTY_AMOUNT	,
                ADVANCED_COMMISSION_TYPE	,
                ADVANCED_COMMISSION_RATE	,
                ADVANCED_COMMISSION_AMOUNT	,
                GECENYIL_GECIKME_FAIZ	,
                GECENAY_GECIKME_FAIZ	,
                GECIKME_FAIZ_ACCRUEDTAX	,
                ACCRUAL_INT_ACCOUNT_NO	,
                ACCRUAL_TAX_ACCOUNT_NO	,
                ACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                NONACCRUAL_INT_ACCOUNT_NO	,
                NONACCRUAL_DELAYED_INT_ACCOUNT_NO	,
                AP_GECIKME_GUN_SAYISI	,
                FAIZ_GECIKME_GUN_SAYISI	,
                LLP_RATE	,
                FAIZ_ORANI_TIPI	,
                MONTHLY_INT_RATE	,
                NON_ACCRUAL_STATUS_UPD_DATE	,
                ACCRUAL_STATUS_UPD_DATE  --seval.colak 02112022
                from cbs_hesap_kredi_onayonce_isl
                where tx_no = pn_islem_no)
       where hesap_no = r_hesap.hesap_no  ;

     BEGIN
           DELETE  FROM CBS_HESAP_KREDI_TAKSIT
          WHERE hesap_no =  r_hesap.hesap_no ;

          insert into cbs_hesap_kredi_taksit( yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
                            taksit_gun_sayisi	,hesaplama_gun_sayisi	,taksit_baz_anapara	,taksit_faiz_orani	,taksit_bsmv_orani	,taksit_kkdf_orani	,ozel_odeme_tutari	,orj_vergi_tutari	,orj_faiz_tutari	,ek_faiz_tutari	,
                             deferred_interest	,deferred_tax	,paid_deferred_interest	,paid_deferred_tax	,tahsil_taksit	,tahsil_anapara	,tahsil_faiz	,tahsil_kkdf	,tahsil_bsmv	,tahsil_gecikme_faiz_tutari	,deferred_tax2	,paid_deferred_tax2	,tahakkuk_eh	,
                            penalty_amount	,paid_penalty_amount	,deferred_penalty_amount	,paid_deferred_penalty_amount	,ap_gecikme_gun_sayisi	,faiz_gecikme_gun_sayisi	,deferred_delayed_interest	,paid_deferred_delayed_interest	,paid_deferred_penalty_tax	,paid_nonaccrual_deferred_tax	,paid_nonaccrual_deferred_delay_tax	)
          select    nvl(yaratan_tx_no,pn_islem_no), hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
                      taksit_gun_sayisi	,hesaplama_gun_sayisi	,taksit_baz_anapara	,taksit_faiz_orani	,taksit_bsmv_orani	,taksit_kkdf_orani	,ozel_odeme_tutari	,orj_vergi_tutari	,orj_faiz_tutari	,ek_faiz_tutari	,
                      deferred_interest	,deferred_tax	,paid_deferred_interest	,paid_deferred_tax	,tahsil_taksit	,tahsil_anapara	,tahsil_faiz	,tahsil_kkdf	,tahsil_bsmv	,tahsil_gecikme_faiz_tutari	,deferred_tax2	,paid_deferred_tax2	,tahakkuk_eh	,
                      penalty_amount	,paid_penalty_amount	,deferred_penalty_amount	,paid_deferred_penalty_amount	,ap_gecikme_gun_sayisi	,faiz_gecikme_gun_sayisi	,deferred_delayed_interest	,paid_deferred_delayed_interest	,paid_deferred_penalty_tax	,paid_nonaccrual_deferred_tax	,paid_nonaccrual_deferred_delay_tax
          from cbs_hesap_kredi_taks_onay_isl
             where tx_no = pn_islem_no;
             
         EXCEPTION WHEN OTHERS THEN NULL;
     END;

          begin
             delete from CBS_HESAP_KREDI_OZEL_TKST
            where hesap_no =r_hesap.hesap_no;

            insert into  CBS_HESAP_KREDI_OZEL_TKST (YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI,TAKSIT_TIPI)  --seval.colak 20012022
            select  YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI,TAKSIT_TIPI--seval.colak 20012022
            from   CBS_HESAP_KREDI_OZLTKSTONAYISL
            where tx_no = pn_islem_no ;

       exception when others then null;
       end ;
   -- B-O-M seval.colak 30052022
   BEGIN 
   
   delete from cbs_kredi_tahakkuk
   where kredi_hesap_no = r_hesap.hesap_no ;
   
     insert into cbs_kredi_tahakkuk(
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	)
        select 
         banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	
        from cbs_kredi_tahakkuk_onay_on_isl
        where islem_no = pn_islem_no and kredi_hesap_no=r_hesap.hesap_no;
        
        exception when others then null;
       end ;
     -- E-O-M seval.colak 30052022

   Exception
       When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '909' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;
--------------------------------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
     null;
 End;
--------------------------------------------------------------------------------
Procedure Reddetme_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list                            Pkg_Muhasebe.varchar_array;
    number_list                             Pkg_Muhasebe.number_array;
    date_list                               Pkg_Muhasebe.date_array;
    boolean_list                            Pkg_Muhasebe.boolean_array;
    ---------------   
    ld_banka_tarihi                         DATE :=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ln_islem_kod                            number := 1323;       
    ln_fis_no                               number := 0;
    ln_pastdue_tax_hesap_no                 number := 0;
    ln_pastdue_faiz_hesap_no                number := 0;
    ls_hata_var                             VARCHAR2(1):= 'H';
    ls_banka_aciklama                       VARCHAR2(2000);
    ls_musteri_aciklama                     VARCHAR2(2000);  
    ls_islem_aciklama                       VARCHAR2(2000);
    ls_fis_aciklama                         VARCHAR2(2000);
    ls_aciklama                             VARCHAR2(2000);    
    ls_doviz_kodu                           VARCHAR2(3);
    ls_bolum_kodu                           CBS_HESAP_KREDI.sube_kodu%TYPE;
    ln_kredi_hesap_no                       number:=0;   
    ld_kredi_vade                           date;
    ls_aciklama_month   varchar2(100);
    ls_musteri_Adi      varchar2(200);  
    ls_taksit_durum          CBS_HESAP_KREDI_Taksit.durum_kodu%type;
    ln_taksit_toplam         number := 0 ;  
    ln_tahsil_faiz   number := 0 ;
    ln_tahsil_vergi  number := 0 ;
    ln_tahakkuk_no           number;
    ln_kalan_tahsil_faiz   number := 0 ;
    ln_kalan_tahsil_vergi  number := 0 ;
    iliskili_faiz_dk_yok             exception;
     --  iliskili_faizrees_dk_yok         exception;
    iliskili_kom_dk_yok              exception;
     --  iliskili_komrees_dk_yok          exception;
     gecikme_faiz_dk_yok        exception;
      -- faiz_iliskili_faizrees_dk_yok    exception;
     faiz_tahakkuk_hesapno_yok        exception;
     vergi_tahakkuk_hesapno_yok       exception;
     iliskili_hesapno_yok             exception;
     deferred_interest_dk_yok         exception;
    ----
   cursor cur_hesap is
    select a.* ,Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.musteri_no) dk_grup_kod ,
                pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) iliskili_hesap_doviz,
                pkg_hesap.kullanilabilir_bakiye_al(iliskili_hesap_no) iliskili_hesap_bakiye,
                abs(pkg_hesap.hesapbakiyeal(a.hesap_no)) kredi_bakiye                
    from CBS_HESAP_KREDI_islem a
    where tx_No = pn_islem_No ;

    r_hesap  cur_hesap%ROWTYPE;

     cursor cur_tahakkuk is
     select kredi_hesap_no,tahakkuk_no ,
             case when  abs(nvl(b.faiz_tahakkuk_tutar,0)) > abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0)) then    abs(abs(nvl(b.faiz_tahakkuk_tutar,0)) -    abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0))) else 0 end   faiz_tahakkuk_tutar,
             case when  abs(nvl(b.vergi_tahakkuk_tutar,0)) > abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0)) then  abs(abs(nvl(b.vergi_tahakkuk_tutar,0)) -    abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0))) else 0 end   vergi_tahakkuk_tutar
     from cbs_kredi_tahakkuk b
     where  kredi_hesap_no =ln_kredi_hesap_no and 
            BANKA_TARIHI <=ld_banka_tarihi and
            durum_kodu ='A'  
      order by tahakkuk_no ; 
      r_tahakkuk  cur_hesap%ROWTYPE;
  Begin
   ---------------------------------
        boolean_list(pn_1323_kredi_tl)  := FALSE;
        boolean_list(pn_1323_kredi_yp)  := FALSE;
        number_list(pn_1323_anapara)  := 0;
        number_list(pn_1323_anapara_lc)  := 0;
        number_list(pn_1323_deferred_interest)  := 0;
        number_list(pn_1323_deferred_interest_lc)  := 0;
        number_list(pn_1323_deferred_tax)  := 0;
        number_list(pn_1323_deferred_tax_lc)  := 0;
        number_list(pn_1323_deferred_toplam)  := 0;
        number_list(pn_1323_deferred_toplam_lc)  := 0;

        number_list(pn_1323_accrual_gecikme_faiz)  := 0;
        number_list(pn_1323_accrual_gecikme_faiz_lc)  := 0;
        number_list(pn_1323_nonaccrual_gecikme_faiz)  := 0;
        number_list(pn_1323_nonaccrual_gecikme_faiz_l)  := 0;        
        number_list(pn_1323_gecikme_faiz_toplam)  := 0;
        number_list(pn_1323_gecikme_faiz_toplam_lc)  := 0;
        number_list(pn_1323_kur)  := 0;
        number_list(pn_1323_penalty_amount)  := 0;
        number_list(pn_1323_penalty_amount_lc)  := 0;
        number_list(pn_1323_penalty_tax)  := 0;
        number_list(pn_1323_penalty_tax_lc)  := 0;
        number_list(pn_1323_penalty_toplam)  := 0;
        number_list(pn_1323_penalty_toplam_lc)  := 0;

        number_list(pn_1323_toplam_faiz)  := 0;
        number_list(pn_1323_toplam_faiz_lc)  := 0;
        number_list(pn_1323_toplam_vergi)  := 0;
        number_list(pn_1323_toplam_vergi_lc)  := 0;
    
        varchar_list(pn_1323_banka_aciklama)  := NULL; 

        varchar_list(pn_1323_fis_aciklama)  := NULL; 
        varchar_list(pn_1323_gecikme_faiz_gl)  := NULL; 
        
        varchar_list(pn_1323_iliskili_faiz_dk)  := NULL; 
        
        varchar_list(pn_1323_iliskili_hesap_doviz)  := NULL; 
        varchar_list(pn_1323_iliskili_hesap_no)  := NULL; 
        varchar_list(pn_1323_iliskili_hesap_sube)  := NULL; 
        varchar_list(pn_1323_islem_sube)  := NULL; 
        varchar_list(pn_1323_kredi_doviz)  := NULL; 
        varchar_list(pn_1323_kredi_hesap_no)  := NULL; 
        varchar_list(pn_1323_kredi_hesap_sube)  := NULL; 
        varchar_list(pn_1323_musteri_aciklama)  := NULL; 
        varchar_list(pn_1323_referans)  := NULL; 
        varchar_list(pn_1323_tax_aciklama)  := NULL; 

        --seval.colak 09122021
        varchar_list(pn_1323_accrual_int_acct_no)  := NULL; 
        varchar_list(pn_1323_accrual_tax_acct_no)  := NULL; 
        varchar_list(pn_1323_accrual_delay_int_acct_no)  := NULL; 
        varchar_list(pn_1323_nonaccrual_int_acct_no)  := NULL; 
        varchar_list(pn_1323_nonaccrual_delay_int_acct)  := NULL;  
        number_list(pn_1323_accrual_tahsil_faiz)  := 0;
        number_list(pn_1323_nonaccrual_tahsil_faiz)  := 0;
        number_list(pn_1323_accrual_tahsil_vergi)  := 0;
        number_list(pn_1323_nonaccrual_tahsil_vergi)  := 0;
        number_list(pn_1323_accrual_tahsil_faiz_lc)  := 0;
        number_list(pn_1323_nonaccrual_tahsil_faiz_lc)  := 0;
        number_list(pn_1323_accrual_tahsil_vergi_lc)  := 0;
        number_list(pn_1323_nonaccrual_tahsil_vergi_l)  := 0;
        --seval.colak 09122021   
        --seval.colak 14122021   
        number_list(pn_1323_defer_pen_toplam)  := 0;
        number_list(pn_1323_defer_pen_toplam_lc)  := 0;
        number_list(pn_1323_defer_pen_tax)  := 0;
        number_list(pn_1323_defer_pen_tax_lc)  := 0;
        number_list(pn_1323_defer_penalty)  := 0;
        number_list(pn_1323_defer_penalty_lc)  := 0;
        --seval.colak 14122021      
        --seval.colak 17122021
        number_list(pn_1323_accr_defer_int)  := 0;
        number_list(pn_1323_accr_defer_int_lc)  := 0;
        number_list(pn_1323_nonaccr_defer_int)  := 0;
        number_list(pn_1323_nonaccr_defer_int_lc)  := 0;
        number_list(pn_1323_accr_defer_del_int)  := 0;
        number_list(pn_1323_accr_defer_del_int_lc)  := 0;
        number_list(pn_1323_nonaccr_defer_del_int)  := 0;
        number_list(pn_1323_nonaccr_defer_del_int_lc)  := 0;
        --seval.colak 17122021
        --seval.colak 24122021
        varchar_list(pn_1323_ack_principial)  := NULL; 
        varchar_list(pn_1323_ack_int)  := NULL; 
        varchar_list(pn_1323_ack_tax)  := NULL; 
        varchar_list(pn_1323_ack_delay_int)  := NULL; 
        varchar_list(pn_1323_ack_delay_int_tax)  := NULL; 
        varchar_list(pn_1323_ack_defer_int)  := NULL; 
        varchar_list(pn_1323_ack_defer_tax)  := NULL; 
        varchar_list(pn_1323_ack_penalty)  := NULL; 
        varchar_list(pn_1323_ack_penalty_tax)  := NULL; 
        varchar_list(pn_1323_ack_defer_delay_int)  := NULL; 
        --seval.colak 24122021
        --b-o-m seval.colak 10012022 
        number_list(pn_1323_nonaccr_defer_int_tax)  := 0;
        number_list(pn_1323_nonaccr_defer_int_tax_lc)  := 0;
        number_list(pn_1323_nonaccr_def_del_int_tax)  := 0;
        number_list(pn_1323_nonaccr_def_del_int_tax_l)  := 0;
        varchar_list(pn_1323_ack_defer_int_tax)  := NULL; 
        varchar_list(pn_1323_ack_defer_delay_int_tax)  := NULL; 
         --e-o-m seval.colak 10012022
        --b-o-m seval.colak 07062022 
        number_list(pn_1323_accr_defer_int_tax)  := 0;
        number_list(pn_1323_accr_defer_int_tax_lc)  := 0;
        number_list(pn_1323_accr_def_del_int_tax)  := 0;
        number_list(pn_1323_accr_def_del_int_tax_l)  := 0;
         --e-o-m seval.colak 07062022
         varchar_list(pn_1323_penalty_gl)  := NULL;      --seval.colak 01112022
         
  ------------------------------------------------------------------------------------------------------            
    ls_islem_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod) ;           
    Pkg_Parametre.deger('1323_BANKA_ACIKLAMA',ls_banka_aciklama);
    Pkg_Parametre.deger('1323_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
    Pkg_Parametre.deger('1323_FIS_ACIKLAMA',ls_fis_aciklama);
    varchar_list(pn_1323_fis_aciklama)    := NVL(ls_fis_aciklama,ls_islem_aciklama);            
------------------------------------------------------------------------------------------------------          
   for c_hesap in cur_hesap loop
        r_hesap := c_hesap;
   end loop;     
      
            ln_kredi_hesap_no   := r_hesap.hesap_no;        
            ls_doviz_kodu       := r_hesap.doviz_kodu;
      if ls_doviz_kodu = pkg_genel.lc_al then
        boolean_list(pn_1323_kredi_tl) := true;
    else
        boolean_list(pn_1323_kredi_yp) := true;
    end if;        

    varchar_list(pn_1323_iliskili_faiz_dk)      := null; 
    
    varchar_list(pn_1323_islem_sube)            := r_hesap.sube_kodu; 
    varchar_list(pn_1323_kredi_doviz)           := r_hesap.doviz_kodu; 
    varchar_list(pn_1323_kredi_hesap_no)        := r_hesap.hesap_no; 
    varchar_list(pn_1323_kredi_hesap_sube)      := r_hesap.sube_kodu;            
    varchar_list(pn_1323_referans)              := r_hesap.hesap_no; 
    varchar_list(pn_1323_iliskili_hesap_doviz)  := pkg_hesap.hesaptandovizkodual(r_hesap.iliskili_hesap_no);   
    varchar_list(pn_1323_iliskili_hesap_no)     := r_hesap.iliskili_hesap_no; 
    varchar_list(pn_1323_iliskili_hesap_sube)   := pkg_hesap.hesaptansubeal(r_hesap.iliskili_hesap_no);        

        --seval.colak 09122021
    varchar_list(pn_1323_accrual_int_acct_no)    := r_hesap.accrual_int_account_no; 
    varchar_list(pn_1323_accrual_tax_acct_no)    := r_hesap.accrual_tax_account_no; 
    varchar_list(pn_1323_accrual_delay_int_acct_no)  := r_hesap.accrual_delayed_int_account_no; 
    varchar_list(pn_1323_nonaccrual_int_acct_no)  := r_hesap.nonaccrual_int_account_no; 
    varchar_list(pn_1323_nonaccrual_delay_int_acct)  := r_hesap.nonaccrual_delayed_int_account_no;
    
  -------------------------      
    ls_musteri_Adi :=  substr(trim(upper(Pkg_Musteri.Sf_Musteri_Adi(r_hesap.musteri_No))),1,100);
    ls_bolum_kodu   := varchar_list(pn_1323_kredi_hesap_sube);
    ls_aciklama     := substr('ПОГАШЕНИЕ ПРОЦЕНТОВ ПО КРЕДИТУ (' || r_hesap.hesap_no|| ')-' || ls_musteri_Adi ,1,200) ;  --seval.colak 15112022 --ls_bolum_kodu || ' ' || ls_fis_aciklama || ls_islem_aciklama ;
    varchar_list(pn_1323_fis_aciklama) := ls_aciklama ;
    
    ls_doviz_kodu   := varchar_list(pn_1323_kredi_doviz);
    ln_kredi_hesap_no   := varchar_list(pn_1323_kredi_hesap_no);
    varchar_list(pn_1323_banka_aciklama)  :=   ls_aciklama ;  --seval.colak 15112022 --TO_CHAR(ln_kredi_hesap_no) || ' ' || ls_banka_aciklama || ls_islem_aciklama ;
    varchar_list(pn_1323_musteri_aciklama):=  ls_aciklama ; --seval.colak 15112022  --TO_CHAR(ln_kredi_hesap_no) ||  ' '|| ls_musteri_aciklama || ls_islem_aciklama ;
    varchar_list(pn_1323_tax_aciklama) :=  ls_aciklama;--'Loan Payment - '||TO_CHAR(ln_kredi_hesap_no) ;
    number_list(pn_1323_kur)  :=  Pkg_Kur.doviz_doviz_karsilik(r_hesap.Doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
              
    number_list(pn_1323_anapara)                    :=  abs(nvl(r_hesap.tahsil_anapara,0));
    number_list(pn_1323_anapara_lc)                 :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_anapara,0)) ,1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_deferred_interest)          :=  abs(nvl(r_hesap.tahsil_deferred_interest,0));
    number_list(pn_1323_deferred_interest_lc)       :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_deferred_interest,0)) ,1,NULL,NULL,'N','A'),0)));
    --
     number_list(pn_1323_deferred_tax)               :=  abs(nvl(r_hesap.tahsil_deferred_tax,0));
    number_list(pn_1323_deferred_tax_lc)            :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_deferred_tax,0)) ,1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_penalty_amount)             :=  abs(nvl(r_hesap.tahsil_penalty_amount,0));   
    number_list(pn_1323_penalty_amount_lc)          :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_penalty_amount,0)) ,1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_penalty_tax)                :=  abs(nvl(r_hesap.tahsil_penalty_tax,0));   
    number_list(pn_1323_penalty_tax_lc)             :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, abs(nvl(r_hesap.tahsil_penalty_tax,0)) ,1,NULL,NULL,'N','A'),0)));     
    --seval.colak 17122021
    --number_list(pn_1323_deferred_toplam)            := number_list(pn_1323_deferred_interest) +number_list(pn_1323_deferred_tax) + number_list(pn_1323_deferred_delayed_int) ;
    --number_list(pn_1323_deferred_toplam_lc)         := number_list(pn_1323_deferred_interest_lc) +number_list(pn_1323_deferred_tax_lc) + number_list(pn_1323_deferred_delayed_int_lc) ;
    number_list(pn_1323_accr_defer_int)             :=  abs(nvl(r_hesap.accrual_tahsil_deferred_interest,0)); --seval.colak 17122021
    number_list(pn_1323_accr_defer_int_lc)          :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_1323_accr_defer_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
    number_list(pn_1323_nonaccr_defer_int)          :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_interest,0)); --seval.colak 17122021
    number_list(pn_1323_nonaccr_defer_int_lc)       :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_1323_nonaccr_defer_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
    number_list(pn_1323_accr_defer_del_int)         :=  abs(nvl(r_hesap.accrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
    number_list(pn_1323_accr_defer_del_int_lc)      :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_1323_accr_defer_del_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
    number_list(pn_1323_nonaccr_defer_del_int)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
    number_list(pn_1323_nonaccr_defer_del_int_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al, abs(nvl(pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.lc_al,null, number_list(pn_1323_nonaccr_defer_del_int) ,1,null,null,'N','A'),0))); --seval.colak 17122021
    
       --b-o-m seval.colak 10012022  
    number_list(pn_1323_nonaccr_defer_int_tax)      := abs(nvl(r_hesap.tahsil_nonaccrual_deferred_tax,0));--seval.colak 28042022 
    number_list(pn_1323_nonaccr_defer_int_tax_lc)   := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_1323_nonaccr_defer_int_tax),1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_nonaccr_def_del_int_tax)    :=  abs(nvl(r_hesap.tahsil_nonaccrual_deferred_delay_tax,0));
    number_list(pn_1323_nonaccr_def_del_int_tax_l)  := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_1323_nonaccr_def_del_int_tax),1,NULL,NULL,'N','A'),0)));
   --e-o-m seval.colak 10012022 
   
   --b-o-m seval.colak 07062022  
    number_list(pn_1323_accr_defer_int_tax)      := abs(nvl(r_hesap.tahsil_accrual_deferred_tax,0));
    number_list(pn_1323_accr_defer_int_tax_lc)   := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_1323_accr_defer_int_tax),1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_accr_def_del_int_tax)    :=  abs(nvl(r_hesap.tahsil_accrual_deferred_delay_tax,0));
    number_list(pn_1323_accr_def_del_int_tax_l)  := Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_1323_accr_def_del_int_tax),1,NULL,NULL,'N','A'),0)));
   --e-o-m seval.colak 07062022 
   
    number_list(pn_1323_deferred_toplam)            := number_list(pn_1323_deferred_tax) + number_list(pn_1323_accr_defer_int) + number_list(pn_1323_accr_defer_del_int)+ number_list(pn_1323_nonaccr_defer_int) + number_list(pn_1323_nonaccr_defer_del_int) + number_list(pn_1323_nonaccr_defer_int_tax) +number_list(pn_1323_nonaccr_def_del_int_tax) + number_list(pn_1323_accr_defer_int_tax) +number_list(pn_1323_accr_def_del_int_tax);  --seval.colak 07062022  number_list(pn_1323_accr_defer_int_tax) +number_list(pn_1323_accr_def_del_int_tax)
    number_list(pn_1323_deferred_toplam_lc)         := number_list(pn_1323_deferred_tax_lc) + number_list(pn_1323_accr_defer_int_lc) + number_list(pn_1323_accr_defer_del_int_lc)+ number_list(pn_1323_nonaccr_defer_int_lc) + number_list(pn_1323_nonaccr_defer_del_int_lc) + number_list(pn_1323_nonaccr_defer_int_tax_lc) +number_list(pn_1323_nonaccr_def_del_int_tax_l) +  number_list(pn_1323_accr_defer_int_tax_lc) +number_list(pn_1323_accr_def_del_int_tax_l) ; --seval.colak 07062022   number_list(pn_1323_accr_defer_int_tax_lc) +number_list(pn_1323_accr_def_del_int_tax_l) 
    --seval.colak 17122021
       
    number_list(pn_1323_penalty_toplam)             := number_list(pn_1323_penalty_amount) +  number_list(pn_1323_penalty_tax);
    number_list(pn_1323_penalty_toplam_lc)          := number_list(pn_1323_penalty_amount_lc) +  number_list(pn_1323_penalty_tax_lc);
 ------------------------------------------------------------------------------------------------------------------------------------
  -- seval.colak 09122021
   number_list(pn_1323_accrual_tahsil_faiz)          :=  abs(nvl(r_hesap.accrual_tahsil_faiz,0));
   number_list(pn_1323_accrual_tahsil_faiz_lc)       :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.accrual_tahsil_faiz,0)) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_nonaccrual_tahsil_faiz)       :=  abs(nvl(r_hesap.nonaccrual_tahsil_faiz,0));
   number_list(pn_1323_nonaccrual_tahsil_faiz_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.nonaccrual_tahsil_faiz,0)) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_accrual_tahsil_vergi)         :=  abs(nvl(r_hesap.accrual_tahsil_vergi,0));
   number_list(pn_1323_accrual_tahsil_vergi_lc)      :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.accrual_tahsil_vergi,0)) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_nonaccrual_tahsil_vergi)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_vergi,0));
   number_list(pn_1323_nonaccrual_tahsil_vergi_l)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,abs(nvl(r_hesap.nonaccrual_tahsil_vergi,0)) ,1,NULL,NULL,'N','A'),0)));
 
   number_list(pn_1323_toplam_faiz)                  := number_list(pn_1323_accrual_tahsil_faiz)  + number_list(pn_1323_nonaccrual_tahsil_faiz) ;
   number_list(pn_1323_toplam_faiz_lc)               := number_list(pn_1323_accrual_tahsil_faiz_lc)  + number_list(pn_1323_nonaccrual_tahsil_faiz_lc);
   number_list(pn_1323_toplam_vergi)                 := number_list(pn_1323_accrual_tahsil_vergi) + number_list(pn_1323_nonaccrual_tahsil_vergi) ;
   number_list(pn_1323_toplam_vergi_lc)              := number_list(pn_1323_accrual_tahsil_vergi_lc) + number_list(pn_1323_nonaccrual_tahsil_vergi_l) ;
   --seval.colak 16122021
   number_list(pn_1323_accrual_gecikme_faiz)     :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz,0));
   number_list(pn_1323_accrual_gecikme_faiz_lc)  :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_1323_accrual_gecikme_faiz),0) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_nonaccrual_gecikme_faiz)  :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz,0));
   number_list(pn_1323_nonaccrual_gecikme_faiz_l):=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_1323_nonaccrual_gecikme_faiz),0) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_accrual_gecikme_tax)      :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz_tax,0));
   number_list(pn_1323_accrual_gecikme_tax_lc)   :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_1323_accrual_gecikme_tax),0) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_nonaccrual_gecikme_tax)   :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz_tax,0));
   number_list(pn_1323_nonaccrual_gecikme_tax_lc):=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,nvl(number_list(pn_1323_nonaccrual_gecikme_tax),0) ,1,NULL,NULL,'N','A'),0)));
   number_list(pn_1323_gecikme_faiz_toplam)      := number_list(pn_1323_accrual_gecikme_faiz) +  number_list(pn_1323_accrual_gecikme_tax) + number_list(pn_1323_nonaccrual_gecikme_faiz) +  number_list(pn_1323_nonaccrual_gecikme_tax) ;
   number_list(pn_1323_gecikme_faiz_toplam_lc)   := number_list(pn_1323_accrual_gecikme_faiz_lc) +  number_list(pn_1323_accrual_gecikme_tax_lc) + number_list(pn_1323_nonaccrual_gecikme_faiz_l) +  number_list(pn_1323_nonaccrual_gecikme_tax_lc) ;
   --seval.colak 16122021
    
   --seval.colak 14122021  
    number_list(pn_1323_defer_penalty)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_amount,0));
    number_list(pn_1323_defer_penalty_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,number_list(pn_1323_defer_penalty),1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_defer_pen_tax)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_tax,0));
    number_list(pn_1323_defer_pen_tax_lc)    :=  Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ABS(NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL, number_list(pn_1323_defer_pen_tax),1,NULL,NULL,'N','A'),0)));
    number_list(pn_1323_defer_pen_toplam)    := number_list(pn_1323_defer_penalty)  + number_list(pn_1323_defer_pen_tax);
    number_list(pn_1323_defer_pen_toplam_lc) :=  number_list(pn_1323_defer_penalty_lc)  + number_list(pn_1323_defer_pen_tax_lc);
    --seval.colak 14122021
  
   ---Kontroller 
    if number_list(pn_1323_anapara) +  number_list(pn_1323_toplam_faiz)  + number_list(pn_1323_toplam_vergi)<> 0 and  varchar_list(pn_1323_iliskili_hesap_no)  is null then
          raise iliskili_hesapno_yok;
     end if;
      
    if number_list(pn_1323_toplam_faiz) <> 0 and varchar_list(pn_1323_accrual_int_acct_no) is null then
        raise faiz_tahakkuk_hesapno_yok;
     end if;
     
     if number_list(pn_1323_toplam_vergi) <> 0 and varchar_list(pn_1323_accrual_tax_acct_no) is null then
        raise vergi_tahakkuk_hesapno_yok;
      end if;
                  
   --DK faiz ve reeeskont bulunur 
         /*faiz gl dk */
        if  r_hesap.dk_grup_kod is not null and r_hesap.modul_tur_kod is not null and r_hesap.urun_tur_kod is not null and r_hesap.urun_sinif_kod is not null then 
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 2,  null,null, null,varchar_list(pn_1323_iliskili_faiz_dk));
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 10,null,null, null,varchar_list(pn_1323_gecikme_faiz_gl)); --seval.colak 14012022
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 12,null,null, null,varchar_list(pn_1323_penalty_gl)); --seval.colak 01112022
        end if;  

        if  ( nvl(number_list(pn_1323_TOPLAM_faiz),0) <> 0 or 
                (nvl(number_list(pn_1323_NONACCR_DEFER_INT),0) +  nvl(number_list(pn_1323_NONACCRUAL_TAHSIL_FAIZ) ,0) <> 0  )) --seval.colak 14012022
             and  varchar_list(pn_1323_iliskili_faiz_dk) is null  then
                 raise iliskili_faiz_dk_yok;               
         end if;
             
        /*DELAY interest penalty deferred dk */
          if   (  number_list(pn_1323_PENALTY_AMOUNT) + number_list(pn_1323_DEFER_PENALTY) + number_list(pn_1323_NONACCR_DEFER_DEL_INT) +number_list(pn_1323_NONACCRUAL_GECIKME_FAIZ) <>0 )  and (varchar_list(pn_1323_gecikme_faiz_gl) is null )  then
                  raise gecikme_faiz_dk_yok;
         end if;
             
------------------------------------------------------------------------------------------------------------------------------------      
 --seval.colak 24122021
 /*
 Principal –                   ПОГАШЕНИЕ СУММЫ КРЕДИТА LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME
Interest –                      ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME
Tax –                              НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME
Delayed interest –       ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT) (NUMBER OF PAST DUE DAYS, FOR EXAMPLE 1 ДЕНЬ/DAY)  NAME SURNAME
Delayed interest tax – НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT)  NAME SURNAME
Deferred interest –     ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Deferred tax –             НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Penalty amount –        ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT)  NAME SURNAME
Penalty tax –                НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ LOAN ACCOUNT)  NAME SURNAME
Deferred Delayed interest – ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ LOAN ACCOUNT) (МЕС/MONTH)  NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА
*/

    ls_aciklama_month :=null;

    if nvl(r_hesap.tahsil_taksit_no,0) <> 0 then 
        select to_char(vade_tarih,'MM/YYYY') 
        into ls_aciklama_month
        from cbs_hesap_kredi_Taksit
        where hesap_No = r_hesap.hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0);        
    end if;

        varchar_list(pn_1323_ack_principial)  := substr('ПОГАШЕНИЕ СУММЫ КРЕДИТА ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_1323_ack_int)         := substr('ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200);
        varchar_list(pn_1323_ack_tax)         := substr('НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_1323_ack_delay_int)   := substr('ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ + НСП ('||r_hesap.hesap_no ||') ('|| nvl(r_hesap.faiz_gecikme_gun_sayisi,0) || ' ДН) '||ls_musteri_Adi,1,200); 
        varchar_list(pn_1323_ack_delay_int_tax):= substr('НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_1323_ack_defer_int)   := substr('ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no||') ('|| ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200); 
        varchar_list(pn_1323_ack_defer_tax)   := substr('НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200);
        varchar_list(pn_1323_ack_penalty)     := substr('ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '|| ls_musteri_Adi,1,200); 
        varchar_list(pn_1323_ack_penalty_tax) := substr('НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '||ls_musteri_Adi,1,200);
        varchar_list(pn_1323_ack_defer_delay_int):= substr('ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА',1,200);
        --seval.colak 24122021
        
        --b-o-m seval.colak 10012022  UNUTMAAAA alttaki degiskenlerin degerlerini ogrendikten sonra duzeltecegiz .Simdilik varchar_list(pn_1323_ack_delay_int_tax) degerini koydum.
        varchar_list(pn_1323_ack_defer_int_tax)  := varchar_list(pn_1323_ack_delay_int_tax);
        varchar_list(pn_1323_ack_defer_delay_int_tax)  := varchar_list(pn_1323_ack_delay_int_tax); 
        --e-o-m seval.colak 10012022 
------------------------------------------------------------------------------------------------------------------------------------
     ln_fis_no:=pkg_muhasebe.fis_kes(ln_islem_kod,
                                       null,
                                       pn_islem_no,
                                       varchar_list ,
                                       number_list  ,
                                       date_list    ,
                                       boolean_list ,
                                       null,
                                       false,
                                       0,
                                       null);
         if nvl(ln_fis_no,0 ) <> 0 then
             pkg_muhasebe.muhasebelestir(ln_fis_no);           
         end if;   
    
       -- muhasebe sonrasi guncellemeler
       
         
        update CBS_HESAP_KREDI
        set         birikmis_faiz_tutari         =  case when  nvl(birikmis_faiz_tutari,0) >  nvl(number_list(pn_1323_toplam_faiz),0)  +  nvl(r_hesap.tahsil_deferred_interest,0)    then nvl(birikmis_faiz_tutari,0) -  ( nvl(number_list(pn_1323_toplam_faiz),0) + nvl(r_hesap.tahsil_deferred_interest,0)) else 0 end,  --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_interest,0) eklendi
                    birikmis_faiz_tutari_round   =  case when  nvl(birikmis_faiz_tutari,0) >  nvl(number_list(pn_1323_toplam_faiz),0)  +  nvl(r_hesap.tahsil_deferred_interest,0)    then  ROUND(nvl(birikmis_faiz_tutari,0) -  ( nvl(number_list(pn_1323_toplam_faiz),0) + nvl(r_hesap.tahsil_deferred_interest,0)),2) else 0 end,  --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_interest,0) eklendi
                    birikmis_gecikme_faiz_tutari =  case when  nvl(birikmis_gecikme_faiz_tutari,0) >  nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0) then nvl(birikmis_gecikme_faiz_tutari,0) -  (nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0)) else 0 end, --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_delayed_interest,0) eklendi
                    paid_penalty_amount          =  nvl(paid_penalty_amount,0)         +   nvl(r_hesap.tahsil_penalty_amount,0) + nvl(r_hesap.tahsil_deferred_penalty_amount,0),  
                    tahsiledilen_faiz_tutari     =  nvl(tahsiledilen_faiz_tutari,0)    +   number_list(pn_1323_toplam_faiz)  +   number_list(pn_1323_deferred_interest)  ,
                    tahsiledilen_faiz_tutari_lc  =  nvl(tahsiledilen_faiz_tutari_lc,0) +   number_list(pn_1323_toplam_faiz_lc) + number_list(pn_1323_deferred_interest_lc) ,
                    tahsil_gecikme_faiz_tutari   =  nvl(tahsil_gecikme_faiz_tutari,0)  +   nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0)                      
        where hesap_no = ln_kredi_hesap_no ;  

        if nvl(r_hesap.tahsil_taksit_no,0) <> 0 then              
             update CBS_HESAP_KREDI_TAKSIT
             set   tahsil_anapara = nvl(tahsil_anapara,0) + nvl(r_hesap.tahsil_anapara,0),
                   tahsil_faiz = nvl(tahsil_faiz,0) + number_list(pn_1323_toplam_faiz),   -- nvl(r_hesap.tahsil_faiz,0),
                   tahsil_bsmv = nvl(tahsil_bsmv,0) + nvl(r_hesap.tahsil_vergi,0),
                   tahsil_gecikme_faiz_tutari =  nvl(tahsil_gecikme_faiz_tutari,0) + nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0)  ,
                   paid_penalty_amount =  nvl(paid_penalty_amount,0) + nvl(r_hesap.tahsil_penalty_amount,0),
                   paid_deferred_penalty_amount =  nvl(paid_deferred_penalty_amount,0) + nvl(r_hesap.tahsil_deferred_penalty_amount,0),  
                   paid_deferred_interest =  nvl(paid_deferred_interest,0) + nvl(r_hesap.tahsil_deferred_interest,0),  
                   paid_deferred_delayed_interest =  nvl(paid_deferred_delayed_interest,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0),  --seval.colak
                   paid_deferred_tax =  nvl(paid_deferred_tax,0) + nvl(r_hesap.tahsil_deferred_tax,0)                     
             where hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
               
              update CBS_HESAP_KREDI_taksit
              set tahsil_taksit =  nvl(tahsil_anapara,0) +nvl(tahsil_faiz,0) + nvl(tahsil_bsmv,0) +
                    nvl(paid_deferred_interest,0) +  nvl(paid_deferred_tax,0) +  nvl(paid_deferred_penalty_amount,0)+ nvl(paid_deferred_delayed_interest,0) --seval.colak 14022023
             where hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
       
            select   durum_kodu,
                     abs (nvl(anapara,0) - nvl(tahsil_anapara,0) ) +
                     abs (nvl(faiz,0) - nvl(tahsil_faiz,0) ) +
                     abs (nvl(bsmv,0) - nvl(tahsil_bsmv,0) ) +
                     abs (nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) )+
                     abs (nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) )+ 
                     abs (nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0) ) +
                     abs (nvl(deferred_interest,0) - nvl(paid_deferred_interest,0) ) + 
                     abs (nvl(deferred_delayed_interest,0) - nvl(paid_deferred_delayed_interest,0) )     --seval.colak 17122021
                    --seval.colak 29082022  deferred_tax artik kullanilmayacak --  + abs (nvl(deferred_tax,0) - nvl(paid_deferred_tax,0) ) 
                    toplam
            into    ls_taksit_durum ,
                    ln_taksit_toplam
            from CBS_HESAP_KREDI_taksit 
            where hesap_no = ln_kredi_hesap_no and sira_no =  nvl(r_hesap.tahsil_taksit_no,0) ;
                    
            if trunc(ln_taksit_toplam,2) > 0 and  ls_taksit_durum <>'A' then --partial odeme durumunda taksit durumu 1306 dan  K yapildi ise A olarak guncelleyelim. 
                update CBS_HESAP_KREDI_Taksit
                set  durum_kodu='A',odeme_Tarihi =null
                where hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0);      
             end if;
            
            update  CBS_HESAP_KREDI_Taksit
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul
            where   hesap_no =  ln_kredi_hesap_no and 
                    sira_no <=  nvl(r_hesap.tahsil_taksit_no,0)  and  
                    vade_tarih <=pkg_muhasebe.banka_tarihi_Bul and
                    durum_kodu ='A' and  
                    trunc(abs (nvl(anapara,0) - nvl(tahsil_anapara,0) ),2) +
                    trunc(abs (nvl(faiz,0) - nvl(tahsil_faiz,0) ) ,2) +
                    trunc(abs (nvl(bsmv,0) - nvl(tahsil_bsmv,0) ),2) +
                    trunc(abs (nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) ),2)+
                    trunc(abs (nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) ),2)+ 
                    trunc(abs (nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0) ) ,2)+
                    trunc(abs (nvl(deferred_interest,0) - nvl(paid_deferred_interest,0) ),2) +
                    trunc(abs (nvl(deferred_delayed_interest,0) - nvl(paid_deferred_delayed_interest,0) ) ,2)      --seval.colak 17122021
                    --seval.colak 29082022  deferred_tax artik kullanilmayacak -- + trunc(abs (nvl(deferred_tax,0) - nvl(paid_deferred_tax,0) ) ,2) 
                    =  0 ;

            update  CBS_HESAP_KREDI_Taksit_islem
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul
            where   tx_no=pn_islem_no and hesap_no =  ln_kredi_hesap_no and 
                    sira_no <=  nvl(r_hesap.tahsil_taksit_no,0) and  
                    vade_tarih <=pkg_muhasebe.banka_tarihi_Bul and
                    durum_kodu ='A' and  
                    trunc(abs (nvl(anapara,0) - nvl(tahsil_anapara,0) ),2) +
                    trunc(abs (nvl(faiz,0) - nvl(tahsil_faiz,0) ) ,2) +
                    trunc(abs (nvl(bsmv,0) - nvl(tahsil_bsmv,0) ),2) +
                    trunc(abs (nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) ),2)+
                    trunc(abs (nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) ),2)+ 
                    trunc(abs (nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0) ) ,2)+
                    trunc(abs (nvl(deferred_interest,0) - nvl(paid_deferred_interest,0) ),2) +
                    trunc(abs (nvl(deferred_delayed_interest,0) - nvl(paid_deferred_delayed_interest,0) ) ,2)     --seval.colak 17122021
                   --seval.colak 29082022  deferred_tax artik kullanilmayacak-- + trunc(abs (nvl(deferred_tax,0) - nvl(paid_deferred_tax,0) ) ,2)
                     =  0 ;   
           end if;       
           
           ----
 -- B-O-M seval.colak 30052022 islem oncesi sakla
     begin
     insert into cbs_kredi_tahakkuk_onay_on_isl(
        islem_no	,
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	)
        select 
        pn_islem_no islem_no	,
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	
        from cbs_kredi_tahakkuk
        where kredi_hesap_no =r_hesap.hesap_no;
         exception when others then null;
       end ;
     -- E-O-M seval.colak 30052022               
              
        ln_kalan_tahsil_faiz :=  nvl(r_hesap.tahsil_faiz,0);
        ln_kalan_tahsil_vergi := nvl(r_hesap.tahsil_vergi,0);
        
        for c_tahakkuk in cur_tahakkuk  
        loop 
                ln_tahakkuk_no :=  c_tahakkuk.tahakkuk_no;                
                ln_tahsil_faiz := 0;
                ln_tahsil_vergi := 0;
                
                if nvl(c_tahakkuk.faiz_tahakkuk_tutar,0)  >  ln_kalan_tahsil_faiz then 
                    ln_tahsil_faiz := ln_kalan_tahsil_faiz;
                else
                    ln_tahsil_faiz := nvl(c_tahakkuk.faiz_tahakkuk_tutar,0);
                end if;
                
                    ln_kalan_tahsil_faiz := nvl(ln_kalan_tahsil_faiz,0) - nvl(ln_tahsil_faiz,0);
                 if ln_kalan_tahsil_faiz <0 then 
                        ln_kalan_tahsil_faiz := 0;
                 end if;   
                
                if nvl(c_tahakkuk.vergi_tahakkuk_tutar,0)  >  ln_kalan_tahsil_vergi then 
                    ln_tahsil_vergi := ln_kalan_tahsil_vergi;
                else
                    ln_tahsil_vergi := nvl(c_tahakkuk.vergi_tahakkuk_tutar,0) ;                   
                end if;      
                
                 ln_kalan_tahsil_vergi := nvl(ln_kalan_tahsil_vergi,0) - nvl(ln_tahsil_vergi,0);
                 if ln_kalan_tahsil_vergi <0 then 
                        ln_kalan_tahsil_vergi := 0;
                 end if;  
                    
                update  cbs_kredi_tahakkuk
                set     faiz_tahakkuk_tutar_tahsil  = nvl(faiz_tahakkuk_tutar_tahsil,0) +  nvl(ln_tahsil_faiz,0),
                        vergi_tahakkuk_tutar_tahsil = nvl(vergi_tahakkuk_tutar_tahsil,0) + nvl(ln_tahsil_vergi,0),
                        tahsilat_tx_no = pn_islem_no
                where   kredi_hesap_no  = c_tahakkuk.kredi_hesap_no and
                        tahakkuk_no     = c_tahakkuk.tahakkuk_no and
                        durum_kodu='A' ; 
         end loop;
       
        update  cbs_kredi_tahakkuk
        set     durum_kodu = 'K', 
                odeme_tarihi= pkg_muhasebe.banka_tarihi_bul,
                tahsilat_tx_no = pn_islem_no
        where   kredi_hesap_no =  ln_kredi_hesap_no and
                durum_kodu ='A' and
                trunc( nvl(faiz_tahakkuk_tutar,0)  -  nvl(faiz_tahakkuk_tutar_tahsil,0),2) <= 0 and  
                trunc( nvl(vergi_tahakkuk_tutar,0) - nvl(vergi_tahakkuk_tutar_tahsil,0),2) <= 0 ;                
       
 Exception
 when iliskili_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6828' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when faiz_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6826' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when vergi_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6827' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when iliskili_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '700' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter || r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||   r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  --when iliskili_faizrees_dk_yok then
  --  raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when iliskili_kom_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '702' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 -- when iliskili_komrees_dk_yok then
  --  raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when deferred_interest_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6851' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 when gecikme_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6863' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter || r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||   r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when others then
    raise_application_error(-20100,pkg_hata.getucpointer || '6862' || pkg_hata.getdelimiter || to_char(sqlerrm) || pkg_hata.getdelimiter || pkg_hata.getucpointer);  
 End;
----------------------------------------------------------------------------------------------------------------------------------------------------------------

BEGIN
        pn_1323_musteri_aciklama    := Pkg_Muhasebe.parametre_index_bul('1323_MUSTERI_ACIKLAMA');
        pn_1323_referans    := Pkg_Muhasebe.parametre_index_bul('1323_REFERANS');
        pn_1323_fis_aciklama    := Pkg_Muhasebe.parametre_index_bul('1323_FIS_ACIKLAMA');
        pn_1323_kur    := Pkg_Muhasebe.parametre_index_bul('1323_KUR');
        pn_1323_banka_aciklama    := Pkg_Muhasebe.parametre_index_bul('1323_BANKA_ACIKLAMA');
        pn_1323_kredi_doviz    := Pkg_Muhasebe.parametre_index_bul('1323_KREDI_DOVIZ');
        pn_1323_islem_sube    := Pkg_Muhasebe.parametre_index_bul('1323_ISLEM_SUBE');
        pn_1323_kredi_tl    := Pkg_Muhasebe.parametre_index_bul('1323_KREDI_TL');
        pn_1323_kredi_yp    := Pkg_Muhasebe.parametre_index_bul('1323_KREDI_YP');
        pn_1323_iliskili_faiz_dk    := Pkg_Muhasebe.parametre_index_bul('1323_ILISKILI_FAIZ_DK');
        pn_1323_kredi_hesap_no    := Pkg_Muhasebe.parametre_index_bul('1323_KREDI_HESAP_NO');
        pn_1323_kredi_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('1323_KREDI_HESAP_SUBE');
        pn_1323_tax_aciklama    := Pkg_Muhasebe.parametre_index_bul('1323_TAX_ACIKLAMA');
        pn_1323_deferred_interest    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_INTEREST');
        pn_1323_deferred_interest_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_INTEREST_LC');
        pn_1323_deferred_tax    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_TAX');
        pn_1323_deferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_TAX_LC');
        pn_1323_accrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_GECIKME_FAIZ');
        pn_1323_accrual_gecikme_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_GECIKME_FAIZ_LC');
        pn_1323_gecikme_faiz_gl    := Pkg_Muhasebe.parametre_index_bul('1323_GECIKME_FAIZ_GL');
        pn_1323_accrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_GECIKME_TAX');
        pn_1323_accrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_GECIKME_TAX_LC');
        pn_1323_penalty_amount    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_AMOUNT');
        pn_1323_penalty_amount_lc    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_AMOUNT_LC');
        pn_1323_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_TAX');
        pn_1323_penalty_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_TAX_LC');
        pn_1323_anapara    := Pkg_Muhasebe.parametre_index_bul('1323_ANAPARA');
        pn_1323_anapara_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ANAPARA_LC');
        pn_1323_iliskili_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('1323_ILISKILI_HESAP_SUBE');
        pn_1323_iliskili_hesap_no    := Pkg_Muhasebe.parametre_index_bul('1323_ILISKILI_HESAP_NO');
        pn_1323_iliskili_hesap_doviz    := Pkg_Muhasebe.parametre_index_bul('1323_ILISKILI_HESAP_DOVIZ');
        pn_1323_toplam_faiz    := Pkg_Muhasebe.parametre_index_bul('1323_TOPLAM_FAIZ');
        pn_1323_toplam_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('1323_TOPLAM_FAIZ_LC');
        pn_1323_toplam_vergi    := Pkg_Muhasebe.parametre_index_bul('1323_TOPLAM_VERGI');
        pn_1323_toplam_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('1323_TOPLAM_VERGI_LC');
        pn_1323_penalty_toplam    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_TOPLAM');
        pn_1323_penalty_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_TOPLAM_LC');
        pn_1323_deferred_toplam    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_TOPLAM');
        pn_1323_deferred_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFERRED_TOPLAM_LC');
        pn_1323_gecikme_faiz_toplam    := Pkg_Muhasebe.parametre_index_bul('1323_GECIKME_FAIZ_TOPLAM');
        pn_1323_gecikme_faiz_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('1323_GECIKME_FAIZ_TOPLAM_LC');
        pn_1323_accrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_INT_ACCT_NO');
        pn_1323_accrual_tax_acct_no    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_TAX_ACCT_NO');
        pn_1323_accrual_delay_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_DELAY_INT_ACCT_NO');
        pn_1323_nonaccrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_INT_ACCT_NO');
        pn_1323_nonaccrual_delay_int_acct    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_DELAY_INT_ACCT');
        pn_1323_accrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_TAHSIL_FAIZ');
        pn_1323_nonaccrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_TAHSIL_FAIZ');
        pn_1323_accrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_TAHSIL_VERGI');
        pn_1323_nonaccrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_TAHSIL_VERGI');
        pn_1323_accrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_TAHSIL_FAIZ_LC');
        pn_1323_nonaccrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_TAHSIL_FAIZ_LC');
        pn_1323_accrual_tahsil_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCRUAL_TAHSIL_VERGI_LC');
        pn_1323_nonaccrual_tahsil_vergi_l    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_TAHSIL_VERGI_L');
        pn_1323_defer_pen_toplam    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PEN_TOPLAM');
        pn_1323_defer_pen_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PEN_TOPLAM_LC');
        pn_1323_defer_pen_tax    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PEN_TAX');
        pn_1323_defer_pen_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PEN_TAX_LC');
        pn_1323_defer_penalty    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PENALTY');
        pn_1323_defer_penalty_lc    := Pkg_Muhasebe.parametre_index_bul('1323_DEFER_PENALTY_LC');
        pn_1323_nonaccrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_GECIKME_FAIZ');
        pn_1323_nonaccrual_gecikme_faiz_l    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_GECIKME_FAIZ_L');
        pn_1323_nonaccrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_GECIKME_TAX');
        pn_1323_nonaccrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCRUAL_GECIKME_TAX_LC');
        pn_1323_accr_defer_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_INT');
        pn_1323_accr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_INT_LC');
        pn_1323_nonaccr_defer_int    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_INT');
        pn_1323_nonaccr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_INT_LC');
        pn_1323_accr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_DEL_INT');
        pn_1323_accr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_DEL_INT_LC');
        pn_1323_nonaccr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_DEL_INT');
        pn_1323_nonaccr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_DEL_INT_LC');
        pn_1323_ack_principial    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_PRINCIPIAL');
        pn_1323_ack_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_INT');
        pn_1323_ack_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_TAX');
        pn_1323_ack_delay_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DELAY_INT');
        pn_1323_ack_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DELAY_INT_TAX');
        pn_1323_ack_defer_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DEFER_INT');
        pn_1323_ack_defer_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DEFER_TAX');
        pn_1323_ack_penalty    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_PENALTY');
        pn_1323_ack_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_PENALTY_TAX');
        pn_1323_ack_defer_delay_int    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DEFER_DELAY_INT');
        pn_1323_nonaccr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_INT_TAX');
        pn_1323_nonaccr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEFER_INT_TAX_LC');
        pn_1323_nonaccr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEF_DEL_INT_TAX');
        pn_1323_nonaccr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('1323_NONACCR_DEF_DEL_INT_TAX_L');
        pn_1323_accr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_INT_TAX');
        pn_1323_accr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEFER_INT_TAX_LC');
        pn_1323_accr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEF_DEL_INT_TAX');
        pn_1323_accr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('1323_ACCR_DEF_DEL_INT_TAX_L');
        pn_1323_ack_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DEFER_INT_TAX');
        pn_1323_ack_defer_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('1323_ACK_DEFER_DELAY_INT_TAX');
        pn_1323_penalty_gl    := Pkg_Muhasebe.parametre_index_bul('1323_PENALTY_GL'); --seval.colak 01112022


END ;
/

