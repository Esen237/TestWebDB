create PACKAGE BODY     "PKG_BAT_2" IS

-----------------------------------------------------------------------------------------
PROCEDURE EOD_TM_HG_ACILIS_RAP(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
BEGIN
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   INSERT INTO CBS_TM_HG_ACILIS_RAP(
            TARIH, REFERANS, LEHDAR_MUSTERI_NO, HESAP_NO, URUN_TUR, URUN_SINIF,
      DOVIZ_KODU, TUTAR, MEKTUP_TIPI, KONTRGARANTI, RISK,
      TEKLIF_URUN, VADE_TARIHI, MUHATAP_MUSTERI_NO, MUHATAP,
      IHBAR_BANKASI, KONUSU, ULKE_KODU,
      PASIF_HESAP, TAHSIL_HESAP_NO,
      ACIKLAMA, MASRAF_HESAP_NO, DONEM_BAS_SON,
      KREDI_TEKLIF_SATIR_NO, DURUM_KODU, BOLUM_KODU, BAKIYE,
      HESAP_BAKIYESI_278, VERILIS_TARIHI, ACILIS_KUR,
      ESKI_REFERANS)
    (SELECT Pkg_Muhasebe.Banka_Tarihi_Bul, REFERANS, LEHDAR_MUSTERI_NO, HESAP_NO, URUN_TUR, URUN_SINIF,
      DOVIZ_KODU, TUTAR, MEKTUP_TIPI, KONTRGARANTI, RISK,
      TEKLIF_URUN, VADE_TARIHI, MUHATAP_MUSTERI_NO, MUHATAP,
      IHBAR_BANKASI, KONUSU, ULKE_KODU,
      PASIF_HESAP,  TAHSIL_HESAP_NO,
      ACIKLAMA, MASRAF_HESAP_NO, DONEM_BAS_SON,
      KREDI_TEKLIF_SATIR_NO, DURUM_KODU, BOLUM_KODU, BAKIYE,
      HESAP_BAKIYESI_278, VERILIS_TARIHI, ACILIS_KUR,
      ESKI_REFERANS
    FROM CBS_TM_HG_ACILIS
    WHERE DURUM_KODU='ON');

   COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-----------------------------------------------------------------------------------------
 -- Tanim : GECICI_TAKSITLI_MASRAF_ODEME
 -- Yazar : Sevalb
 -- Calisma Yeri: EOD
 -- Tarih : 03/03/2005
 -----------------------------------------------------------------------------------------
PROCEDURE GECICI_TAKSITLI_MASRAF_ODEME(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;
    ln_plan_no       NUMBER := 1;
 ln_fis_no       NUMBER := 0;
 ln_islem_no          NUMBER := 0;
 ln_islem_kod               CBS_ISLEM.islem_kod%TYPE :=4121;
 ls_musteri_aciklama        VARCHAR2(2000);
 ls_banka_aciklama          VARCHAR2(2000);
 ls_fis_aciklama            VARCHAR2(2000);
 ls_aciklama       VARCHAR2(2000);
 ln_4121_banka_aciklama         NUMBER;
 ln_4121_doviz_kodu             NUMBER;
 ln_4121_komisyon_dk            NUMBER;
 ln_4121_islem_sube             NUMBER;
 ln_4121_referans              NUMBER;
 ln_4121_musteri_aciklama       NUMBER;
 ln_4121_nakit_kodu          NUMBER;
 ln_4121_hesap_sube            NUMBER;
 ln_4121_istatistik_kodu        NUMBER;
 ln_4121_tutar            NUMBER;
 ln_4121_vergi           NUMBER;
 ln_4121_tutar_vergi        NUMBER;

  CURSOR cur_masraf_taksit IS
    SELECT *
 FROM CBS_MASRAF_ITH_IHR_GECICI
 WHERE STATUS = 'A' AND
    GERCEKLESECEK_TARIH < Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.banka_tarihi_bul)  AND
    GERCEKLESECEK_TARIH >= Pkg_Muhasebe.banka_tarihi_bul
 FOR UPDATE OF status,odeme_tarihi   ;

  CURSOR cur_mt IS
    SELECT *
 FROM CBS_MASRAF_ITH_IHR_GECICI
 WHERE STATUS = 'A' AND
    GERCEKLESECEK_TARIH > Pkg_Muhasebe.banka_tarihi_bul AND
    pkg_rapor_2.dosya_bakiyesi_al(referans) = 0
 FOR UPDATE OF status,odeme_tarihi   ;

BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    ln_4121_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('4121_BANKA_ACIKLAMA');
 ln_4121_doviz_kodu :=Pkg_Muhasebe.parametre_index_bul('4121_DOVIZ_KODU');
 ln_4121_komisyon_dk :=Pkg_Muhasebe.parametre_index_bul('4121_KOMISYON_DK');
 ln_4121_islem_sube :=Pkg_Muhasebe.parametre_index_bul('4121_ISLEM_SUBE');
 ln_4121_istatistik_kodu :=Pkg_Muhasebe.parametre_index_bul('4121_ISTATISTIK_KODU');
 ln_4121_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('4121_MUSTERI_ACIKLAMA');
 ln_4121_referans :=Pkg_Muhasebe.parametre_index_bul('4121_REFERANS');
 ln_4121_tutar :=Pkg_Muhasebe.parametre_index_bul('4121_TUTAR');
 ln_4121_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('4121_HESAP_SUBE');
 ln_4121_nakit_kodu :=Pkg_Muhasebe.parametre_index_bul('4121_NAKIT_KODU');
 ln_4121_vergi :=Pkg_Muhasebe.parametre_index_bul('4121_VERGI');
 ln_4121_tutar_vergi  :=Pkg_Muhasebe.parametre_index_bul('4121_TUTAR_VERGI');

 varchar_list(ln_4121_banka_aciklama) := NULL;
 varchar_list(ln_4121_doviz_kodu) := NULL;
 varchar_list(ln_4121_hesap_sube) := NULL;
 varchar_list(ln_4121_islem_sube) := NULL;
 varchar_list(ln_4121_istatistik_kodu) := NULL;
 varchar_list(ln_4121_komisyon_dk) := NULL;
 varchar_list(ln_4121_musteri_aciklama) := NULL;
 varchar_list(ln_4121_nakit_kodu) := NULL;
 varchar_list(ln_4121_referans) := NULL;
 number_list(ln_4121_tutar):= 0;
 number_list(ln_4121_vergi):= 0;
 number_list(ln_4121_tutar_vergi) := 0 ;

   Pkg_Parametre.deger('4121_BANKA_ACIKLAMA',ls_banka_aciklama);
   Pkg_Parametre.deger('4121_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   ls_fis_aciklama :=    Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod ) ;
--   varchar_list(ln_4121_banka_aciklama) :=  NVL(ls_banka_aciklama,ls_fis_aciklama);
--   varchar_list(ln_4121_musteri_aciklama) :=  NVL(ls_musteri_aciklama,ls_fis_aciklama);

    FOR c_masraf_taksit IN cur_masraf_taksit LOOP
     ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,c_masraf_taksit.sube);
  varchar_list(ln_4121_doviz_kodu) := c_masraf_taksit.doviz_kodu;
  varchar_list(ln_4121_islem_sube) := c_masraf_taksit.sube;
  varchar_list(ln_4121_hesap_sube) := c_masraf_taksit.sube;
  varchar_list(ln_4121_referans) := c_masraf_taksit.referans;
  varchar_list(ln_4121_banka_aciklama) :=  'Reference:'||c_masraf_taksit.referans || ' Installment No:'||c_masraf_taksit.taksit_no ||' Order No:'||c_masraf_taksit.gecici_sira_no;
        varchar_list(ln_4121_musteri_aciklama) :=  'Reference:'||c_masraf_taksit.referans || ' Installment No:'||c_masraf_taksit.taksit_no ||' Order No:'||c_masraf_taksit.gecici_sira_no;
  number_list(ln_4121_tutar):= NVL(c_masraf_taksit.gerceklesecek_tutar,0);
  varchar_list(ln_4121_komisyon_dk) := Pkg_Muhasebe.Komisyon_DK_Bul(Pkg_Musteri.sf_musteri_dk_grup_kod_al(c_masraf_taksit.musteri_no),c_masraf_taksit.masraf_kodu);

  IF c_masraf_taksit.vergili_mi = 'E' THEN
   number_list(ln_4121_vergi):= Pkg_Kur.yuvarla(Pkg_Genel.lc_al,Pkg_Kur.mb_dak_to_lc(c_masraf_taksit.doviz_kodu, number_list(ln_4121_tutar)) * 15)/(100+15);
  ELSE
   number_list(ln_4121_vergi):= 0 ;
  END IF;

  number_list(ln_4121_tutar_vergi):= number_list(ln_4121_tutar) - number_list(ln_4121_vergi) ;

    /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
        ln_fis_no:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
        ln_plan_no,
        ln_islem_no,
        varchar_list ,
        number_list  ,
        date_list    ,
        boolean_list ,
        NULL,
        FALSE,
        ln_fis_no,
        ls_fis_aciklama);

   UPDATE  CBS_MASRAF_ITH_IHR_GECICI
   SET status = 'P',
    odeme_tarihi =Pkg_Muhasebe.banka_tarihi_bul
   WHERE CURRENT OF cur_masraf_taksit;

  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '980' || Pkg_Hata.getdelimiter || TO_CHAR(ln_fis_no) ||' ' ||varchar_list(ln_4121_referans)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no );
     END LOOP;

    IF NVL(ln_fis_no,0) <> 0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
 END IF;


 -----------
 --Gulnihal Cengiz Tuna 11.12.2007 Basladi
    ln_plan_no  := 1;
 ln_fis_no  := 0;
 ln_islem_no  := 0;
 ln_islem_kod    := 4121;

 varchar_list(ln_4121_banka_aciklama) := NULL;
 varchar_list(ln_4121_doviz_kodu) := NULL;
 varchar_list(ln_4121_hesap_sube) := NULL;
 varchar_list(ln_4121_islem_sube) := NULL;
 varchar_list(ln_4121_istatistik_kodu) := NULL;
 varchar_list(ln_4121_komisyon_dk) := NULL;
 varchar_list(ln_4121_musteri_aciklama) := NULL;
 varchar_list(ln_4121_nakit_kodu) := NULL;
 varchar_list(ln_4121_referans) := NULL;
 number_list(ln_4121_tutar):= 0;
 number_list(ln_4121_vergi):= 0;
 number_list(ln_4121_tutar_vergi) := 0 ;

   Pkg_Parametre.deger('4121_BANKA_ACIKLAMA',ls_banka_aciklama);
   Pkg_Parametre.deger('4121_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   ls_fis_aciklama :=    Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod ) ;
--   varchar_list(ln_4121_banka_aciklama) :=  NVL(ls_banka_aciklama,ls_fis_aciklama);
--   varchar_list(ln_4121_musteri_aciklama) :=  NVL(ls_musteri_aciklama,ls_fis_aciklama);

    FOR c_mt IN cur_mt LOOP
     ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,c_mt.sube);
  varchar_list(ln_4121_doviz_kodu) := c_mt.doviz_kodu;
  varchar_list(ln_4121_islem_sube) := c_mt.sube;
  varchar_list(ln_4121_hesap_sube) := c_mt.sube;
  varchar_list(ln_4121_referans) := c_mt.referans;
  varchar_list(ln_4121_banka_aciklama) :=  'Reference:'||c_mt.referans || ' Installment No:'||c_mt.taksit_no ||' Order No:'||c_mt.gecici_sira_no;
        varchar_list(ln_4121_musteri_aciklama) :=  'Reference:'||c_mt.referans || ' Installment No:'||c_mt.taksit_no ||' Order No:'||c_mt.gecici_sira_no;
  number_list(ln_4121_tutar):= NVL(c_mt.gerceklesecek_tutar,0);
  varchar_list(ln_4121_komisyon_dk) := Pkg_Muhasebe.Komisyon_DK_Bul(Pkg_Musteri.sf_musteri_dk_grup_kod_al(c_mt.musteri_no),c_mt.masraf_kodu);

  IF c_mt.vergili_mi = 'E' THEN
   number_list(ln_4121_vergi):= Pkg_Kur.yuvarla(Pkg_Genel.lc_al,Pkg_Kur.mb_dak_to_lc(c_mt.doviz_kodu, number_list(ln_4121_tutar)) * 15)/(100+15);
  ELSE
   number_list(ln_4121_vergi):= 0 ;
  END IF;

  number_list(ln_4121_tutar_vergi):= number_list(ln_4121_tutar) - number_list(ln_4121_vergi) ;

    /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
        ln_fis_no:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
        ln_plan_no,
        ln_islem_no,
        varchar_list ,
        number_list  ,
        date_list    ,
        boolean_list ,
        NULL,
        FALSE,
        ln_fis_no,
        ls_fis_aciklama);

   UPDATE  CBS_MASRAF_ITH_IHR_GECICI
   SET status = 'P',
    odeme_tarihi =Pkg_Muhasebe.banka_tarihi_bul
   WHERE CURRENT OF cur_mt;


  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '980' || Pkg_Hata.getdelimiter || TO_CHAR(ln_fis_no) ||' ' ||varchar_list(ln_4121_referans)|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no );
     END LOOP;

    IF NVL(ln_fis_no,0) <> 0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
 END IF;
 --Gulnihal Cengiz Tuna 11.12.2007 Bitti
 -----------

  COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-----------------------------------------------------------------------------------------
 -- Tanim : ForwardReeskontFisiKes
 -- Yazar : Sevalb
 -- Calisma Yeri: EOD
 -- Tarih : 22/03/2005
 -----------------------------------------------------------------------------------------
  PROCEDURE FORWARDREESKONTFISIKES (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
   varchar_list            pkg_muhasebe.varchar_array;
    number_list       pkg_muhasebe.number_array;
    date_list       pkg_muhasebe.date_array;
    boolean_list      pkg_muhasebe.boolean_array;
    ln_plan_no       NUMBER := 0;
 ln_fis_no       NUMBER := 0;
 ln_islem_no          NUMBER := 0;
 ln_islem_kod               CBS_ISLEM.islem_kod%TYPE :=5220;
 ls_musteri_aciklama        VARCHAR2(2000);
 ls_banka_aciklama          VARCHAR2(2000);
 ls_fis_aciklama            VARCHAR2(2000);
 ls_aciklama       VARCHAR2(2000);
 ls_bolum_kodu       VARCHAR2(200);
 ln_5220_referans                NUMBER;
 ln_5220_doviz                 NUMBER;
 ln_5220_musteri_aciklama        NUMBER;
 ln_5220_istatistik_kodu         NUMBER;
 ln_5220_banka_aciklama          NUMBER;
 ln_5220_nakit_kodu             NUMBER;
 ln_5220_hesap_tur          NUMBER;
 ln_5220_hesap_no          NUMBER;
 ln_5220_sube           NUMBER;
 ln_5220_t3            NUMBER;
 ln_5220_kur            NUMBER;
 ln_5220_t2            NUMBER;
 ln_5220_t1            NUMBER;
 ln_5220_valor_tarihi         NUMBER;
 ln_5220_lc_fc           NUMBER;
 ln_5220_fc_lc           NUMBER;
 ln_5220_fc_fc          NUMBER;
 ln_5220_t1_buyuk_t2          NUMBER;
 ln_5220_t1_kucuk_t2          NUMBER;
 ln_5220_d_buyuk_c          NUMBER;
 ln_5220_d_kucuk_c          NUMBER;
 ln_5220_profit           NUMBER;
 ln_5220_loss           NUMBER;


    CURSOR cur_bolum IS
      SELECT UNIQUE KODU  bolum_kodu
        FROM CBS_BOLUM;

/* spot-forward */
    CURSOR cur_spfw IS
  SELECT
      referans, banka_musteri_no,
      alis_doviz_kodu, satis_doviz_kodu,
      alis_tutari, satis_tutari,
      profit_amount profit, loss_amount loss,
      FORWARD_ALIS_mbKUR alis_kur,
      FORWARD_SATIS_mbKUR satis_kur ,bolum_kodu
  FROM CBS_HAZINE_SPFW
  WHERE DURUM_KODU = 'A' AND
     urun_tur_kod = 'FORWARD' AND
     ACILIS_TARIHI < PKG_MUHASEBE.BANKA_TARIHI_BUL AND
       bolum_kodu = ls_bolum_kodu
   FOR UPDATE OF   profit_amount, loss_amount ;


/* swap- forward */
   CURSOR cur_swap IS
  SELECT
      referans, banka_musteri_no,
      satis_doviz_kodu  alis_doviz_kodu,
      alis_doviz_kodu   satis_doviz_kodu,
      forward_alis_tutari alis_tutari,
      forward_satis_tutari satis_tutari,
      profit ,
      loss ,
      FORWARD_ALIS_mbKUR alis_kur,
      FORWARD_SATIS_mbKUR satis_kur,
      BOLUM_KODU
  FROM CBS_HAZINE_SWAP
  WHERE DURUM_KODU = 'A' AND
     ACILIS_TARIHI < PKG_MUHASEBE.BANKA_TARIHI_BUL AND
      bolum_kodu = ls_bolum_kodu
   FOR UPDATE OF   profit, loss ;

 doviz_plani_yok  EXCEPTION;
 loss_profit_var  EXCEPTION;
 ln_c     NUMBER := 0;
 ln_d     NUMBER := 0;
    ln_t1    NUMBER := 0;
 ln_t2     NUMBER := 0;
 ln_t3    NUMBER := 0;
    ln_sifirla    NUMBER := 0;
 ls_alis_doviz VARCHAR2(200);
 ls_satis_doviz VARCHAR2(200);

  BEGIN
    ln_5220_lc_fc :=pkg_muhasebe.parametre_index_bul('5220_LC_FC');
 ln_5220_fc_lc :=pkg_muhasebe.parametre_index_bul('5220_FC_LC');
 ln_5220_fc_fc :=pkg_muhasebe.parametre_index_bul('5220_FC_FC');
 ln_5220_t1_buyuk_t2 :=pkg_muhasebe.parametre_index_bul('5220_T1_BUYUK_T2');
 ln_5220_t1_kucuk_t2 :=pkg_muhasebe.parametre_index_bul('5220_T1_KUCUK_T2');
 ln_5220_d_buyuk_c :=pkg_muhasebe.parametre_index_bul('5220_D_BUYUK_C');
 ln_5220_d_kucuk_c :=pkg_muhasebe.parametre_index_bul('5220_D_KUCUK_C');
 ln_5220_profit :=pkg_muhasebe.parametre_index_bul('5220_PROFIT');
 ln_5220_loss :=pkg_muhasebe.parametre_index_bul('5220_LOSS');
 ln_5220_t3 :=pkg_muhasebe.parametre_index_bul('5220_T3');
 ln_5220_referans :=pkg_muhasebe.parametre_index_bul('5220_REFERANS');
 ln_5220_t2 :=pkg_muhasebe.parametre_index_bul('5220_T2');
 ln_5220_kur :=pkg_muhasebe.parametre_index_bul('5220_KUR');
 ln_5220_doviz :=pkg_muhasebe.parametre_index_bul('5220_DOVIZ');
 ln_5220_banka_aciklama :=pkg_muhasebe.parametre_index_bul('5220_BANKA_ACIKLAMA');
 ln_5220_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('5220_MUSTERI_ACIKLAMA');
 ln_5220_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('5220_ISTATISTIK_KODU');
 ln_5220_nakit_kodu :=pkg_muhasebe.parametre_index_bul('5220_NAKIT_KODU');
 ln_5220_sube :=pkg_muhasebe.parametre_index_bul('5220_SUBE');
 ln_5220_hesap_tur :=pkg_muhasebe.parametre_index_bul('5220_HESAP_TUR');
 ln_5220_hesap_no :=pkg_muhasebe.parametre_index_bul('5220_HESAP_NO');
 ln_5220_valor_tarihi :=pkg_muhasebe.parametre_index_bul('5220_VALOR_TARIHI');
 ln_5220_t1 :=pkg_muhasebe.parametre_index_bul('5220_T1');

 varchar_list(ln_5220_banka_aciklama) := NULL;
 varchar_list(ln_5220_doviz) := NULL;
 varchar_list(ln_5220_hesap_no) := NULL;
 varchar_list(ln_5220_hesap_tur) := NULL;
 varchar_list(ln_5220_istatistik_kodu) := NULL;
 varchar_list(ln_5220_musteri_aciklama) := NULL;
 varchar_list(ln_5220_nakit_kodu) := NULL;
 varchar_list(ln_5220_referans) := NULL;
 varchar_list(ln_5220_sube) := NULL;

 number_list(ln_5220_t1):= 0;
 number_list(ln_5220_t2):= 0;
 number_list(ln_5220_t3):= 0;
 date_list(ln_5220_valor_tarihi) := NULL;
 boolean_list(ln_5220_d_buyuk_c):= FALSE;
 boolean_list(ln_5220_d_kucuk_c):= FALSE;
 boolean_list(ln_5220_fc_fc):= FALSE;
 boolean_list(ln_5220_fc_lc):= FALSE;
 boolean_list(ln_5220_lc_fc):= FALSE;
 boolean_list(ln_5220_loss):= FALSE;
 boolean_list(ln_5220_profit):= FALSE;
 boolean_list(ln_5220_t1_buyuk_t2):= FALSE;
 boolean_list(ln_5220_t1_kucuk_t2):= FALSE;

   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   pkg_parametre.deger('5220_BANKA_ACIKLAMA',ls_banka_aciklama);
   pkg_parametre.deger('5220_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   ls_fis_aciklama :=    pkg_genel.ISLEM_ADI_AL(ln_islem_kod ) ;

   varchar_list(ln_5220_banka_aciklama)   := NVL(ls_banka_aciklama,ls_fis_aciklama);
   varchar_list(ln_5220_musteri_aciklama) := NVL(ls_musteri_aciklama,ls_fis_aciklama);
   date_list(ln_5220_valor_tarihi) := PKG_MUHASEBE.banka_tarihi_bul;

   --test sil


    FOR c_bolum IN cur_bolum LOOP

      ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,c_bolum.bolum_kodu);
   ls_bolum_kodu  :=c_bolum.bolum_kodu;

   varchar_list(ln_5220_sube) := c_bolum.bolum_kodu;
   ln_fis_no := 0;
      FOR c_forward IN cur_spfw LOOP
      varchar_list(ln_5220_banka_aciklama)   := c_forward.referans ||' '|| NVL(ls_banka_aciklama,ls_fis_aciklama);
    varchar_list(ln_5220_musteri_aciklama) := c_forward.referans ||' '|| NVL(ls_musteri_aciklama,ls_fis_aciklama);

      ln_d := 0;
   ln_c := 0;
   ln_t2 := 0;
   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '986' || Pkg_Hata.getdelimiter || TO_CHAR(ls_bolum_kodu) || Pkg_Hata.getdelimiter || 'SPOT-FW' ||Pkg_Hata.getdelimiter || C_FORWARD.referans||Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer) ,ln_islem_no );
   ln_plan_no := NULL;
   ls_alis_doviz := c_forward.alis_doviz_kodu;
   ls_satis_doviz := c_forward.satis_doviz_kodu;
   varchar_list(ln_5220_referans) :=  c_forward.REFERANS ;
   number_list(ln_5220_t1) := 0;
   number_list(ln_5220_t2) := 0;
   number_list(ln_5220_t3) := 0;
   boolean_list(ln_5220_d_buyuk_c):= FALSE;
   boolean_list(ln_5220_d_kucuk_c):= FALSE;
   boolean_list(ln_5220_fc_fc):= FALSE;
   boolean_list(ln_5220_fc_lc):= FALSE;
   boolean_list(ln_5220_lc_fc):= FALSE;
   boolean_list(ln_5220_loss):= FALSE;
   boolean_list(ln_5220_profit):= FALSE;
   boolean_list(ln_5220_t1_buyuk_t2):= FALSE;
   boolean_list(ln_5220_t1_kucuk_t2):= FALSE;
 /** doviz atama **/
 /* 10042005 sevil ile kazakistanda commentli olan degisiklik yapildi.
 /*LC-FC*/
   IF c_forward.alis_doviz_kodu = pkg_genel.lc_al AND  c_forward.satis_doviz_kodu <> pkg_genel.lc_al THEN
      boolean_list(ln_5220_lc_fc):= TRUE;
       --   ln_c := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,nvl(c_forward.satis_kur,0) * nvl(c_forward.satis_tutari,0)) ;
   --   ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
      ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
      ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');

 /*FC-LC*/
    ELSIF c_forward.alis_doviz_kodu <> pkg_genel.lc_al AND  c_forward.satis_doviz_kodu = pkg_genel.lc_al THEN
      boolean_list(ln_5220_fc_lc):= TRUE;
      --    ln_c := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,nvl(c_forward.alis_kur,0) * nvl(c_forward.alis_tutari,0)) ;
      --   ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
      ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
      ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');

 /*FC-FC*/
    ELSIF c_forward.alis_doviz_kodu <> pkg_genel.lc_al AND  c_forward.satis_doviz_kodu <> pkg_genel.lc_al THEN
      boolean_list(ln_5220_fc_fc):= TRUE;
      ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
      ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
    ELSE
       RAISE doviz_plani_yok;
    END IF;

   ln_t1 :=  NVL(ln_d,0) - NVL(ln_c,0) ;
   IF NVL(ln_t1,0) >= 0 THEN
    boolean_list(ln_5220_d_buyuk_c) := TRUE;
   ELSE
    boolean_list(ln_5220_d_kucuk_c) := TRUE;
   END IF;

   ln_t1 := ABS(ln_t1);
 /** loss profit atama **/
   IF NVL(c_forward.profit,0) <> 0 AND NVL(c_forward.loss,0) = 0  THEN
      boolean_list(ln_5220_profit):= TRUE;
      ln_t2 := ABS(NVL(c_forward.profit,0));
    ELSIF NVL(c_forward.profit,0)= 0 AND NVL(c_forward.loss,0) <> 0  THEN
      boolean_list(ln_5220_loss):= TRUE;
      ln_t2 := ABS(NVL(c_forward.loss,0));
    ELSIF NVL(c_forward.profit,0)= 0 AND NVL(c_forward.loss,0) = 0  THEN
      ln_t2 := 0 ;
     NULL;
    ELSE
       RAISE loss_profit_var;
    END IF;

   IF NVL(ln_t1,0) >= NVL(ln_t2,0) THEN
      boolean_list(ln_5220_t1_buyuk_t2) := TRUE;
   ELSE
      boolean_list(ln_5220_t1_kucuk_t2) := TRUE;
   END IF;

   IF  NVL(ln_t2,0) = 0  THEN
        IF boolean_list(ln_5220_d_buyuk_c) =TRUE THEN
               boolean_list(ln_5220_profit):= TRUE;
     ELSE
       boolean_list(ln_5220_loss):= TRUE;
      END IF;
    END IF;

 -- T3 hesaplamasi
  ln_sifirla := 0;

    IF  ( boolean_list(ln_5220_lc_fc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR
        ( boolean_list(ln_5220_lc_fc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE ) OR
        ( boolean_list(ln_5220_fc_lc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR -- sevalb 110405
           ( boolean_list(ln_5220_fc_lc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE ) OR -- sevalb 110405
     ( boolean_list(ln_5220_fc_fc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR
        ( boolean_list(ln_5220_fc_fc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE )-- sevalb 110405
     THEN
        ln_t3 := ABS( NVL(ln_t2,0) ) + ABS( NVL(ln_t1,0) ) ;
      ln_sifirla := 1;
   ELSE
      ln_t3 := ABS(ABS( NVL(ln_t2,0) )- ABS( NVL(ln_t1,0) )) ;
      ln_sifirla := 0;
     END IF;

  number_list(ln_5220_t1):= ABS( NVL(ln_t1,0) );
  number_list(ln_5220_t2):= ABS( NVL(ln_t2,0) );
  number_list(ln_5220_t3):= ABS( NVL(ln_t3,0) );


       /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
      ln_fis_no:=pkg_muhasebe.fis_kes(ln_islem_kod,
         ln_plan_no,
         ln_islem_no,
         varchar_list ,
         number_list  ,
         date_list    ,
         boolean_list ,
         NULL,
         FALSE,
         ln_fis_no,
         ls_fis_aciklama);
 /* ayni yonde */
   IF NVL(ln_sifirla,0) = 1  THEN
            IF boolean_list(ln_5220_profit) = TRUE THEN
      UPDATE CBS_HAZINE_SPFW
      SET profit_amount = 0 ,
        loss_amount = NVL(loss_amount,0)+ number_list(ln_5220_t1)
      WHERE CURRENT OF cur_spfw;
      END IF;

            IF boolean_list(ln_5220_loss) = TRUE THEN
      UPDATE CBS_HAZINE_SPFW
      SET loss_amount = 0,
        profit_amount = NVL(profit_amount,0)+ number_list(ln_5220_t1)
      WHERE CURRENT OF cur_spfw;
       END IF;
     ELSE
        IF boolean_list(ln_5220_profit) = TRUE THEN
       IF boolean_list(ln_5220_t1_buyuk_t2) = TRUE THEN
       UPDATE CBS_HAZINE_SPFW
       SET profit_amount = NVL(profit_amount,0)+ number_list(ln_5220_t3)
       WHERE CURRENT OF cur_spfw;
      ELSE
        UPDATE CBS_HAZINE_SPFW
       SET profit_amount = NVL(profit_amount,0)- number_list(ln_5220_t3)
       WHERE CURRENT OF cur_spfw;
      END IF;
      END IF;
            IF boolean_list(ln_5220_loss) = TRUE THEN
        IF boolean_list(ln_5220_t1_buyuk_t2) = TRUE THEN
       UPDATE CBS_HAZINE_SPFW
       SET loss_amount = NVL(loss_amount,0)+ number_list(ln_5220_t3)
       WHERE CURRENT OF cur_spfw;
      ELSE
        UPDATE CBS_HAZINE_SPFW
       SET loss_amount = NVL(loss_amount,0)- number_list(ln_5220_t3)
       WHERE CURRENT OF cur_spfw;
      END IF;
      END IF;

   END IF;
    END LOOP;

/**  swap islemleri */
      FOR c_forward IN cur_swap LOOP
        varchar_list(ln_5220_banka_aciklama)   := c_forward.referans ||' '|| NVL(ls_banka_aciklama,ls_fis_aciklama);
      varchar_list(ln_5220_musteri_aciklama) := c_forward.referans ||' '|| NVL(ls_musteri_aciklama,ls_fis_aciklama);

        ln_plan_no := NULL;
      ln_d := 0;
   ln_c := 0;
   ln_t2 := 0;
   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '986' || Pkg_Hata.getdelimiter || TO_CHAR(ls_bolum_kodu) || Pkg_Hata.getdelimiter || 'SWAP-FW' ||Pkg_Hata.getdelimiter || C_FORWARD.referans||Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer) ,ln_islem_no );
   ls_alis_doviz := c_forward.alis_doviz_kodu;
   ls_satis_doviz := c_forward.satis_doviz_kodu;
   varchar_list(ln_5220_referans) :=  c_forward.REFERANS ;
   number_list(ln_5220_t1) := 0;
   number_list(ln_5220_t2) := 0;
   number_list(ln_5220_t3) := 0;
   boolean_list(ln_5220_d_buyuk_c):= FALSE;
   boolean_list(ln_5220_d_kucuk_c):= FALSE;
   boolean_list(ln_5220_fc_fc):= FALSE;
   boolean_list(ln_5220_fc_lc):= FALSE;
   boolean_list(ln_5220_lc_fc):= FALSE;
   boolean_list(ln_5220_loss):= FALSE;
   boolean_list(ln_5220_profit):= FALSE;
   boolean_list(ln_5220_t1_buyuk_t2):= FALSE;
   boolean_list(ln_5220_t1_kucuk_t2):= FALSE;
 /** doviz atama **/
 /*LC-FC alis satis ters calisir*/
   IF c_forward.alis_doviz_kodu = pkg_genel.lc_al AND  c_forward.satis_doviz_kodu <> pkg_genel.lc_al THEN
      boolean_list(ln_5220_lc_fc):= TRUE;
          --ln_d := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,nvl(c_forward.satis_kur,0) * nvl(c_forward.satis_tutari,0)) ;
      --ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
       ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
       ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
 /*FC-LC*/
    ELSIF c_forward.alis_doviz_kodu <> pkg_genel.lc_al AND  c_forward.satis_doviz_kodu = pkg_genel.lc_al THEN
      boolean_list(ln_5220_fc_lc):= TRUE;
      --    ln_d := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,nvl(c_forward.alis_kur,0) * nvl(c_forward.alis_tutari,0)) ;
     --  ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
         ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
       ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
 /*FC-FC*/
    ELSIF c_forward.alis_doviz_kodu <> pkg_genel.lc_al AND  c_forward.satis_doviz_kodu <> pkg_genel.lc_al THEN
      boolean_list(ln_5220_fc_fc):= TRUE;
      --ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
      --ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,nvl(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');
       ln_c := Pkg_Kur.doviz_doviz_karsilik( c_forward.satis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.satis_tutari,0),1,NULL,NULL,'N','A');
       ln_d := Pkg_Kur.doviz_doviz_karsilik( c_forward.alis_doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(c_forward.alis_tutari,0),1,NULL,NULL,'N','A');

    ELSE
       RAISE doviz_plani_yok;
    END IF;

      ln_t1 :=  NVL(ln_d,0) - NVL(ln_c,0) ;
   IF NVL(ln_t1,0) >= 0 THEN
    boolean_list(ln_5220_d_buyuk_c) := TRUE;
   ELSE
    boolean_list(ln_5220_d_kucuk_c) := TRUE;
   END IF;
   ln_t1 := ABS(ln_t1);
 /** loss profit atama **/
   IF NVL(c_forward.profit,0) <> 0 AND NVL(c_forward.loss,0) = 0  THEN
      boolean_list(ln_5220_profit):= TRUE;
      ln_t2 := ABS(NVL(c_forward.profit,0));
    ELSIF NVL(c_forward.profit,0)= 0 AND NVL(c_forward.loss,0) <> 0  THEN
      boolean_list(ln_5220_loss):= TRUE;
      ln_t2 := ABS(NVL(c_forward.loss,0));
    ELSIF NVL(c_forward.profit,0)= 0 AND NVL(c_forward.loss,0) = 0  THEN
      ln_t2 := 0 ;
     NULL;
    ELSE
       RAISE loss_profit_var;
    END IF;

   IF NVL(ln_t1,0) >= NVL(ln_t2,0) THEN
      boolean_list(ln_5220_t1_buyuk_t2) := TRUE;
   ELSE
      boolean_list(ln_5220_t1_kucuk_t2) := TRUE;
   END IF;

   IF  NVL(ln_t2,0) = 0  THEN
        IF boolean_list(ln_5220_d_buyuk_c) =TRUE THEN
               boolean_list(ln_5220_profit):= TRUE;
     ELSE
       boolean_list(ln_5220_loss):= TRUE;
      END IF;
    END IF;

 -- T3 hesaplamasi
  ln_sifirla := 0;
      IF  ( boolean_list(ln_5220_lc_fc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR
        ( boolean_list(ln_5220_lc_fc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE ) OR
        ( boolean_list(ln_5220_fc_lc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR -- sevalb 110405
           ( boolean_list(ln_5220_fc_lc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE ) OR -- sevalb 110405
     ( boolean_list(ln_5220_fc_fc)= TRUE AND boolean_list(ln_5220_d_buyuk_c) =TRUE AND  boolean_list(ln_5220_loss)=TRUE ) OR
        ( boolean_list(ln_5220_fc_fc)= TRUE AND boolean_list(ln_5220_d_kucuk_c) =TRUE AND  boolean_list(ln_5220_profit)=TRUE )-- sevalb 110405
     THEN
      ln_t3 := ABS( NVL(ln_t2,0) ) + ABS( NVL(ln_t1,0) ) ;
      ln_sifirla := 1;
   ELSE
      ln_t3 := ABS(ABS( NVL(ln_t2,0) )- ABS( NVL(ln_t1,0) )) ;
      ln_sifirla := 0;
     END IF;

  number_list(ln_5220_t1):= ABS( NVL(ln_t1,0) );
  number_list(ln_5220_t2):= ABS( NVL(ln_t2,0) );
  number_list(ln_5220_t3):= ABS( NVL(ln_t3,0) );
       /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
      ln_fis_no:=pkg_muhasebe.fis_kes(ln_islem_kod,
         ln_plan_no,
         ln_islem_no,
         varchar_list ,
         number_list  ,
         date_list    ,
         boolean_list ,
         NULL,
         FALSE,
         ln_fis_no,
         ls_fis_aciklama);
 /* ayni yonde */

   IF NVL(ln_sifirla,0) = 1  THEN
            IF boolean_list(ln_5220_profit) = TRUE THEN
      UPDATE CBS_HAZINE_SWAP
      SET profit = 0 ,
        loss = ABS(NVL(loss,0))+ ABS(number_list(ln_5220_t1))
      WHERE CURRENT OF cur_swap;

      END IF;

            IF boolean_list(ln_5220_loss) = TRUE THEN
      UPDATE CBS_HAZINE_SWAP
      SET loss = 0,
        profit = ABS(NVL(profit,0))+ ABS(number_list(ln_5220_t1))
      WHERE CURRENT OF cur_swap;
       END IF;
     ELSE
        IF boolean_list(ln_5220_profit) = TRUE THEN
       IF boolean_list(ln_5220_t1_buyuk_t2) = TRUE THEN
       UPDATE CBS_HAZINE_SWAP
       SET profit = ABS( NVL(profit,0)) + ABS(number_list(ln_5220_t3))
       WHERE CURRENT OF cur_swap;
      ELSE
        UPDATE CBS_HAZINE_SWAP
       SET profit = ABS(ABS( NVL(profit,0))- ABS(number_list(ln_5220_t3)))
       WHERE CURRENT OF cur_swap;
      END IF;
      END IF;
            IF boolean_list(ln_5220_loss) = TRUE THEN
        IF boolean_list(ln_5220_t1_buyuk_t2) = TRUE THEN
       UPDATE CBS_HAZINE_SWAP
       SET loss = ABS( NVL(loss,0))+ ABS(number_list(ln_5220_t3))
       WHERE CURRENT OF cur_swap;
      ELSE
        UPDATE CBS_HAZINE_SWAP
       SET loss = ABS(ABS(NVL(loss,0))- ABS(number_list(ln_5220_t3)))
       WHERE CURRENT OF cur_swap;
      END IF;
      END IF;
   END IF;
     END LOOP;
    IF NVL(ln_fis_no,0) <> 0 THEN
    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '985' || Pkg_Hata.getdelimiter || TO_CHAR(ls_bolum_kodu) || Pkg_Hata.getdelimiter || ln_fis_no ||Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no );
       pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
    END IF;

     END LOOP;


  COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
   WHEN loss_profit_var THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,varchar_list(ln_5220_referans)  ||' reference there are both of Loss and Profit'  );
   WHEN doviz_plani_yok THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'No available plan is defined for  ' ||ls_alis_doviz  || '-'||ls_satis_doviz  );
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
 -----------------------------------------------------------------------------------------
 -- Tanim : KOMISYON_KUR_KOPYALA_SOD
 -- Yazar : SerpilA
 -- Calisma Yeri: SOD
 -- Tarih : 12/04/2005
  -----------------------------------------------------------------------------------------
 PROCEDURE KOMISYON_KUR_KOPYALA_SOD (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
  pn_islem_no NUMBER;
  ld_tarih DATE:=NULL;
  ln_hata NUMBER;

  CURSOR c_0 IS
            SELECT tarih
            FROM   CBS_KOMISYON_KUR
            WHERE  tarih = Pkg_Muhasebe.banka_tarihi_bul ;

     CURSOR kur_cursor IS
       SELECT DVZ,KUR
     FROM CBS_KOMISYON_KUR_ISL
       WHERE tx_no=pn_islem_no;

BEGIN

      Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

          OPEN c_0;
          FETCH c_0 INTO   ld_tarih;

         IF c_0%NOTFOUND THEN
            pkg_tx4056.kur_batch_kopyala(pn_islem_no);

        END IF;
            CLOSE c_0;
      COMMIT;

    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
  WHEN OTHERS THEN
    Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);

END;

 -----------------------------------------------------------------------------------------
  -- Tanim : Monthly Avarages For Eod
  -- Yazar : Mutlu Ozdemir
  -- Calisma Yeri: Sod
  -- Tarih : 18/04/2005
 -----------------------------------------------------------------------------------------
 PROCEDURE AYLIK_ORTALAMA_HESAPLA (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

 ln_yil                         NUMBER;
 ln_ay                          NUMBER;

  CURSOR c1 IS
    SELECT hesap_no, SUM(nvl(bakiye,0)) toplam_bakiye
    FROM CBS_HESAP_GUNLUK_BAKIYE
    WHERE  
    yil=ln_yil  AND ay=ln_ay and
          nvl(bakiye,0) <> 0 -- seval.colak 15042021 Eod performance tunning prevent locking
     GROUP BY hesap_no;

    ln_gun_adedi                            NUMBER;
    ln_ortalama_bakiye                        NUMBER;

  BEGIN
      Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
      ln_yil:=TO_NUMBER(TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'yyyy'));
      ln_ay:=TO_NUMBER(TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'mm'));

      -- ayin gun adedini bul
   IF Pkg_Batch.ay_sonu_mu THEN
     ln_gun_adedi:=TO_NUMBER(TO_CHAR(LAST_DAY(pkg_muhasebe.banka_tarihi_bul),'DD'));
   ELSE
        ln_gun_adedi:=TO_NUMBER(TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'dd'));
   END IF;


    FOR r_1 IN c1 LOOP
        ln_ortalama_bakiye:= 0;
        begin
          ln_ortalama_bakiye:=ROUND(nvl(r_1.toplam_bakiye,0)/ nvl(ln_gun_adedi,0),10);
          exception when others then null;      -- seval.colak 15042021 Eod performance tunning prevent char numeric error
         end;
          
          UPDATE CBS_HESAP_BAKIYE 
          SET aylik_ortalama_bakiye= nvl(ln_ortalama_bakiye,0)
          WHERE hesap_no=r_1.hesap_no ;
          
          commit;                   -- seval.colak 15042021 Eod performance tunning prevent locking
          
     END LOOP;

      COMMIT;

      Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     rollback;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-----------------------
PROCEDURE SOD_MBKUR_KOPYALA (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

  CURSOR mbkur_cursor IS

    SELECT DOVIZ_KODU,ALIS,SATIS,EALIS,ESATIS,ALIS,SATIS
      FROM CBS_HTTP_TCMBKURAL
   WHERE CBS_HTTP_TCMBKURAL.DATE_LOAD=pkg_muhasebe.Banka_Tarihi_Bul;
    ld_tarih DATE;

 ls_DOVIZ_KODU VARCHAR2(3);
    ln_ALIS NUMBER;
    ln_SATIS NUMBER;
    ln_EALIS NUMBER;
    ln_ESATIS NUMBER;
    ln_MALIS NUMBER;
    ln_MSATIS NUMBER;
    ln_PARITE NUMBER;

 NoNBRateException EXCEPTION;

  BEGIN

   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   ld_tarih:=pkg_muhasebe.Banka_Tarihi_Bul;

   --trigger marifetiyle MBKUR_LOG tablosuna atiliyor
   /* Bilal kaldirdi
   update cbs_MBKUR
   set tarih=ld_tarih;
   */
   OPEN mbkur_cursor;
   FETCH mbkur_cursor INTO ls_DOVIZ_KODU,ln_ALIS,ln_SATIS,ln_EALIS,ln_ESATIS,ln_MALIS,ln_MSATIS;
   IF mbkur_cursor%FOUND THEN
       DELETE FROM CBS_MBKUR;
    WHILE NOT mbkur_cursor%NOTFOUND
  LOOP
      INSERT INTO CBS_MBKUR(TARIH,DVZ,DVZALIS,DVZSATIS,EFALIS,EFSATIS,ESALIS,ESSATIS)
      VALUES(ld_tarih,ls_DOVIZ_KODU,ln_ALIS,ln_SATIS,ln_EALIS,ln_ESATIS,ln_ALIS,ln_SATIS);
         FETCH mbkur_cursor INTO ls_DOVIZ_KODU,ln_ALIS,ln_SATIS,ln_EALIS,ln_ESATIS,ln_MALIS,ln_MSATIS;
     END LOOP;
 ELSE
   --set the mbkur to today
   UPDATE CBS_MBKUR
      SET TARIH = ld_tarih;
 END IF;
 CLOSE mbkur_cursor;
 --TA
 --To update Cost rates on bank Rates
 UPDATE CBS_KUR a
    SET (ESALIS,ESSATIS)=(SELECT ROUND(DVZALIS,2),ROUND(DVZSATIS,2)
   FROM CBS_MBKUR b WHERE a.DVZ=b.DVZ);
    COMMIT;

    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN NoNBRateException THEN
   ROLLBACK;
      Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'No NB Rate found for next working day.');
    WHEN OTHERS THEN
   ROLLBACK;
      Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);

  END;
  --------------------------------------------------------------------------------
  PROCEDURE EOD_GAYRINAKDI_ALGAR_LOG(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
BEGIN
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   INSERT INTO CBS_KREDI_TEMINAT_TANIM_RAP(TARIH, MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU, TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA, IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI, IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR, IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO, ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI, ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR, ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI, EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI, EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI, EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI, MENKUL_REHNI_BIRIM, MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI, MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI, TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE, TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO, GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU, EMTEA_REHNI_REHIN_TARIHI, TEMLIK_ANLASMA_TARIHI, ILK_TUTAR, KEFALET_VADE_TARIHI, ANLASMA_NO)
    (SELECT Pkg_Muhasebe.Banka_Tarihi_Bul, MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU, TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA, IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI, IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR, IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO, ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI, ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR, ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI, EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI, EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI, EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI, MENKUL_REHNI_BIRIM, MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI, MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI, TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE, TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO, GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU, EMTEA_REHNI_REHIN_TARIHI, TEMLIK_ANLASMA_TARIHI, ILK_TUTAR, KEFALET_VADE_TARIHI, ANLASMA_NO
    FROM CBS_KREDI_TEMINAT_TANIM
    WHERE DURUM='ACIK');

      INSERT INTO CBS_TM_ALINAN_GARANTI_RAP(TARIH, REFERANS, ISLEM_TIPI, GON_BANKA_MUSTERI_NO, DUZENLEME_TARIHI, GON_BANKA_REFERANSI, DOVIZ_KODU, TUTAR, VADELI, VADE_TARIHI, MUHATAP_MUSTERI_NO, MUHATAP_UNVANI, MUHATAP_ADRESI, LEHDAR_MUSTERI_NO, ACIKLAMA, DURUM_KODU, MASRAF_HESAP_NO, KONU, TEMINAT_KODU, TEMINAT_ALT_KODU, BAKIYE, BOLUM_KODU, ILK_TUTAR, MASRAF_ALINSINMI)
    (SELECT Pkg_Muhasebe.Banka_Tarihi_Bul, REFERANS, ISLEM_TIPI, GON_BANKA_MUSTERI_NO, DUZENLEME_TARIHI, GON_BANKA_REFERANSI, DOVIZ_KODU, TUTAR, VADELI, VADE_TARIHI, MUHATAP_MUSTERI_NO, MUHATAP_UNVANI, MUHATAP_ADRESI, LEHDAR_MUSTERI_NO, ACIKLAMA, DURUM_KODU, MASRAF_HESAP_NO, KONU, TEMINAT_KODU, TEMINAT_ALT_KODU, BAKIYE, BOLUM_KODU, ILK_TUTAR, MASRAF_ALINSINMI
    FROM CBS_TM_ALINAN_GARANTI
    WHERE DURUM_KODU='ON');

   COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;

----------------------------------------------------------------------------------
PROCEDURE CURRENT_ACCOUNT_ACCRUATION(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
  p_2003_BANKA_ACIKLAMA       NUMBER;
  p_2003_BOLUM_KODU           NUMBER;
  p_2003_BORCLU_HESAP           NUMBER;
  p_2003_DOVIZ_KODU           NUMBER;
  p_2003_FAIZ_DK            NUMBER;
  p_2003_FC_BIRIKMIS_FAIZ       NUMBER;
 -- p_2003_FC_GECENYIL_FAIZI      NUMBER;
  p_2003_FC_TOPLAM_FAIZ       NUMBER;
  p_2003_FC_TUTAR           NUMBER;
  p_2003_FC_SON_BAKIYE       NUMBER;
  p_2003_HESAP_NO            NUMBER;
  p_2003_HESAP_TURU           NUMBER;
  p_2003_ISTATISTIK_KODU       NUMBER;
  p_2003_STATISTIC_CLOSE       NUMBER;
  p_2003_STATISTIC_INT       NUMBER;
  p_2003_KUR             NUMBER;
  p_2003_LC_BIRIKMIS_FAIZ       NUMBER;
--  p_2003_LC_GECENYIL_FAIZI      NUMBER;
  p_2003_LC_ISLEM            NUMBER;
  p_2003_LC_SON_BAKIYE       NUMBER;
  p_2003_LC_TOPLAM_FAIZ       NUMBER;
  p_2003_LC_TUTAR            NUMBER;
  p_2003_MUSTERI_ACIKLAMA       NUMBER;
  p_2003_REESKONT_DK           NUMBER;
  p_2003_VALOR_TARIHI           NUMBER;
  p_2003_ILISKILI_HESAPNO       NUMBER;
  p_2003_ILISKILI_HESAPSUBE      NUMBER;
  p_2003_LC_NETTUTAR        NUMBER;
  p_2003_FC_NETTUTAR        NUMBER;
  p_2003_LC_TAX_AMT        NUMBER;
  p_2003_FC_TAX_AMT        NUMBER;
  p_2003_LC_GECENAY_FAIZI       NUMBER;
  p_2003_FC_GECENAY_FAIZI       NUMBER;
  p_2003_FAIZ_HESAP_BOLUM NUMBER; --sevalb 14022011 SDLC14636

     varchar_list     Pkg_Muhasebe.varchar_array;
     number_list      Pkg_Muhasebe.number_array;
     date_list      Pkg_Muhasebe.date_array;
     boolean_list     Pkg_Muhasebe.boolean_array;
  ln_fis_no      NUMBER:=0;
  ln_plan_no      NUMBER:=0;
  ln_son_bakiye     NUMBER;
  ln_temp       NUMBER;
  pn_islem_no      NUMBER;
  ld_vade_tarihi     DATE;
  ld_sonraki_tarih    DATE;
  ls_durum_kodu     VARCHAR2(1);
        ls_istatistik_faiz     VARCHAR2(2000);
     ls_istatistik_kapama    VARCHAR2(2000);
  ls_interest_payment_period   VARCHAR2(100);

  CURSOR islem_cursor IS
     SELECT ch.*,Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no) DK_GRUP_KODU
          FROM CBS_HESAP ch
         WHERE ch.durum_kodu='A'
      AND ( NVL(ch.BIRIKMIS_FAIZ_POZ_ROUND,0) <>0 OR NVL(GECMIS_AYLARIN_FAIZI,0) <> 0 ) --BIRIKMIS_FAIZ_POZ Yerine BIRIKMIS_FAIZ_POZ_ROUND yapildi. sevalb 101207
      AND INTEREST_PAYMENT_PERIOD IS NOT NULL
      AND (    ( ls_interest_payment_period ='YEARLY' AND INTEREST_PAYMENT_PERIOD  IN ( 'MONTHLY','QUARTERLY','YEARLY'))
           OR ( ls_interest_payment_period ='QUARTERLY' AND INTEREST_PAYMENT_PERIOD  IN ( 'MONTHLY','QUARTERLY') )
           OR ( ls_interest_payment_period ='MONTHLY'   AND INTEREST_PAYMENT_PERIOD  IN ('MONTHLY') )
     );

  row_islem         islem_cursor%ROWTYPE;
  ln_msigv       NUMBER;
  ln_ssdf        NUMBER;
  ln_oiv        NUMBER;
  ln_retval       NUMBER;
  ls_timestamp      DATE;
  ld_kapama_tarihi                    DATE := NULL;
  ls_ISTATISTIK_KODU_2    VARCHAR2(10);
  ln_dk_grup_no      CBS_MUSTERI.DK_GRUP_KOD%TYPE;
  ln_tax_tutar      NUMBER := 0;
  ln_tax_oran       NUMBER := 0;
  ln_bugun     NUMBER;
  ln_yarin     NUMBER;

  ln_bakiye     NUMBER;
  ld_tarih     DATE;
  ln_yil NUMBER;
  ln_ay NUMBER;
  ln_gun NUMBER;
  ln_bloke_tutari NUMBER;
  ln_valorlu_bakiye    NUMBER;
  ln_hesap_no      NUMBER;
  BEGIN
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 --select systimestamp into ls_timestamp from dual;

 ln_bugun:=TO_NUMBER(TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'DD'));
 ln_yarin:=TO_NUMBER(TO_CHAR(Pkg_Muhasebe.sonraki_banka_tarihi_bul,'DD'));

   IF  Pkg_Batch.Yil_sonu_mu = TRUE OR Pkg_Batch.donem_sonu_mu  = TRUE OR Pkg_Batch.ay_sonu_mu = TRUE THEN --sevalb

       IF Pkg_Batch.Yil_sonu_mu =TRUE THEN
       ls_interest_payment_period   := 'YEARLY';
    ELSIF   Pkg_Batch.donem_sonu_mu  = TRUE THEN
      ls_interest_payment_period := 'QUARTERLY';
    ELSE
      ls_interest_payment_period := 'MONTHLY';
    END IF;

  p_2003_BANKA_ACIKLAMA:=Pkg_Muhasebe.parametre_index_bul('2003_BANKA_ACIKLAMA');
  p_2003_BOLUM_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_BOLUM_KODU');
  p_2003_BORCLU_HESAP:=Pkg_Muhasebe.parametre_index_bul('2003_BORCLU_HESAP');
  p_2003_DOVIZ_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_DOVIZ_KODU');
  p_2003_FAIZ_DK:=Pkg_Muhasebe.parametre_index_bul('2003_FAIZ_DK');
  p_2003_FC_BIRIKMIS_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_FC_BIRIKMIS_FAIZ');
--  p_2003_FC_GECENYIL_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_FC_GECENYIL_FAIZI');
  p_2003_FC_SON_BAKIYE:=Pkg_Muhasebe.parametre_index_bul('2003_FC_SON_BAKIYE');
  p_2003_FC_TOPLAM_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TOPLAM_FAIZ');
  p_2003_FC_TUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TUTAR');
  p_2003_HESAP_NO:=Pkg_Muhasebe.parametre_index_bul('2003_HESAP_NO');
  p_2003_HESAP_TURU:=Pkg_Muhasebe.parametre_index_bul('2003_HESAP_TURU');
  p_2003_ISTATISTIK_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_ISTATISTIK_KODU');
  p_2003_KUR:=Pkg_Muhasebe.parametre_index_bul('2003_KUR');
  p_2003_LC_BIRIKMIS_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_LC_BIRIKMIS_FAIZ');
--  p_2003_LC_GECENYIL_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_LC_GECENYIL_FAIZI');
  p_2003_LC_ISLEM:=Pkg_Muhasebe.parametre_index_bul('2003_LC_ISLEM');
  p_2003_LC_SON_BAKIYE:=Pkg_Muhasebe.parametre_index_bul('2003_LC_SON_BAKIYE');
  p_2003_LC_TOPLAM_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TOPLAM_FAIZ');
  p_2003_LC_TUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TUTAR');
  p_2003_MUSTERI_ACIKLAMA:=Pkg_Muhasebe.parametre_index_bul('2003_MUSTERI_ACIKLAMA');
  p_2003_REESKONT_DK:=Pkg_Muhasebe.parametre_index_bul('2003_REESKONT_DK');
  p_2003_VALOR_TARIHI:=Pkg_Muhasebe.parametre_index_bul('2003_VALOR_TARIHI');
  p_2003_ILISKILI_HESAPNO:=Pkg_Muhasebe.parametre_index_bul('2003_ILISKILI_HESAPNO');
  p_2003_ILISKILI_HESAPSUBE:=Pkg_Muhasebe.parametre_index_bul('2003_ILISKILI_HESAPSUBE');
  p_2003_LC_NETTUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_LC_NETTUTAR');
  p_2003_FC_NETTUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_FC_NETTUTAR');
  p_2003_FC_TAX_AMT:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TAX_AMT');
  p_2003_LC_TAX_AMT:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TAX_AMT');
  p_2003_STATISTIC_CLOSE:=Pkg_Muhasebe.parametre_index_bul('2003_STATISTIC_CLOSE');
  p_2003_STATISTIC_INT:=Pkg_Muhasebe.parametre_index_bul('2003_STATISTIC_INT');
  p_2003_LC_GECENAY_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_LC_GECENAY_FAIZI');
  p_2003_FC_GECENAY_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_FC_GECENAY_FAIZI');
  p_2003_FAIZ_HESAP_BOLUM:=Pkg_Muhasebe.parametre_index_bul('2003_FAIZ_HESAP_BOLUM');--sevalb 14022011 SDLC14636

  OPEN islem_cursor;
  FETCH islem_cursor INTO row_islem;
    WHILE NOT islem_cursor%NOTFOUND
  LOOP
      BEGIN
   ln_hesap_no :=row_islem.hesap_no;
   pn_islem_no:=Pkg_Batch.islem_yarat(2003,row_islem.SUBE_KODU);

   IF pkg_musteri.musteri_vergiden_muafmi(Pkg_Hesap.HesaptanMusteriNoAl(row_islem.HESAP_NO)) = 'E'
   THEN
    ln_tax_oran:=0;
   ELSE
    ln_tax_oran:=Pkg_Hesap.sf_tax_orani_al(row_islem.dk_grup_kodu,row_islem.modul_tur_kod,row_islem.urun_tur_kod,row_islem.urun_sinif_kod);
   END IF;


   varchar_list(p_2003_DOVIZ_KODU):=Pkg_Hesap.HesaptanDovizKoduAl(row_islem.HESAP_NO);
   Pkg_Muhasebe.DK_BUL(row_islem.DK_GRUP_KODU, row_islem.modul_tur_kod, row_islem.urun_tur_kod,row_islem.urun_sinif_kod, 3, NULL, NULL, NULL,varchar_list(p_2003_FAIZ_DK));
   Pkg_Muhasebe.DK_BUL(row_islem.DK_GRUP_KODU, row_islem.modul_tur_kod, row_islem.urun_tur_kod,row_islem.urun_sinif_kod, 4, NULL, NULL, NULL,varchar_list(p_2003_REESKONT_DK));
   number_list(p_2003_FC_BIRIKMIS_FAIZ):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),NVL(row_islem.BIRIKMIS_FAIZ_POZ,0));
   number_list(p_2003_LC_BIRIKMIS_FAIZ):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,NVL(row_islem.BIRIKMIS_FAIZ_POZ,0),1,NULL,NULL,'N','A'));
--   number_list(p_2003_FC_GECENYIL_FAIZI):=--0;--Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),NVL(row_islem.GECEN_YIL_FAIZ_TOPLAMI,0));                     --sevalb  291206
--   number_list(p_2003_LC_GECENYIL_FAIZI):=0;--Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,NVL(row_islem.GECEN_YIL_FAIZ_TOPLAMI,0),1,NULL,NULL,'N','A'));  --sevalb  291206
   number_list(p_2003_FC_GECENAY_FAIZI):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),NVL(row_islem.GECMIS_AYLARIN_FAIZI,0)); --sevalb  291296
   number_list(p_2003_LC_GECENAY_FAIZI):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,NVL(row_islem.GECMIS_AYLARIN_FAIZI,0),1,NULL,NULL,'N','A')); --sevalb  291206
   number_list(p_2003_FC_TOPLAM_FAIZ):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),number_list(p_2003_FC_GECENAY_FAIZI)+number_list(p_2003_FC_BIRIKMIS_FAIZ));
   number_list(p_2003_LC_TOPLAM_FAIZ):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_GECENAY_FAIZI)+number_list(p_2003_LC_BIRIKMIS_FAIZ));

   number_list(p_2003_LC_TAX_AMT):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_TOPLAM_FAIZ)*ln_Tax_oran/100);
   number_list(p_2003_FC_TAX_AMT):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_2003_DOVIZ_KODU),NULL,number_list(p_2003_LC_TAX_AMT),1,NULL,NULL,'N','A'));

   varchar_list(p_2003_HESAP_NO):=TO_CHAR( NVL(row_islem.faiz_odeme_hesap_no,row_islem.hesap_no)) ; --sevalb 240108
   varchar_list(p_2003_BOLUM_KODU):=row_islem.SUBE_KODU;--pkg_hesap.HESAPSUBEAL(row_islem.HESAP_NO);

   varchar_list(p_2003_FAIZ_HESAP_BOLUM) :=pkg_hesap.HESAPSUBEAL(varchar_list(p_2003_HESAP_NO));--sevalb 14022011 SDLC14636

   --varchar_list(p_2003_ILISKILI_HESAPNO):=TO_CHAR(row_islem.GERI_DONUS_HESAPNO);
   --IF row_islem.GERI_DONUS_HESAPNO IS NOT NULL THEN
   --   varchar_list(p_2003_ILISKILI_HESAPSUBE):=Pkg_Hesap.HESAPSUBEAL(row_islem.GERI_DONUS_HESAPNO);
   --END IF;
   number_list(p_2003_KUR):=Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
   varchar_list(p_2003_BANKA_ACIKLAMA):= row_islem.hesap_no || ' Interest Payment';
   varchar_list(p_2003_MUSTERI_ACIKLAMA):= row_islem.hesap_no || ' Interest Payment';
   number_list(p_2003_LC_NETTUTAR):=ABS(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_TOPLAM_FAIZ)-number_list(p_2003_LC_TAX_AMT)));
   number_list(p_2003_FC_NETTUTAR):=ABS(Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),number_list(p_2003_FC_TOPLAM_FAIZ)-number_list(p_2003_FC_TAX_AMT)));
   ln_son_bakiye:=Pkg_Hesap.HesapBakiyeAl(row_islem.HESAP_NO);
   number_list(p_2003_FC_SON_BAKIYE):=ABS(ln_son_bakiye+NVL(number_list(p_2003_FC_NETTUTAR),0));
   number_list(p_2003_LC_SON_BAKIYE):=ABS(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,ln_son_bakiye+NVL(number_list(p_2003_FC_NETTUTAR),0),1,NULL,NULL,'N','A')));

   ls_durum_kodu:=row_islem.DURUM_KODU;
   --ld_vade_tarihi:=row_islem.VADE_TARIHI;
   --ld_sonraki_tarih:=row_islem.SONRAKI_BASLANGIC_TARIHI;

         ls_istatistik_faiz   := NULL;--'1417'|| varchar_list(p_2003_DOVIZ_KODU) ||'840';--row_islem.prefix_istatistik_kodu_faiz||row_islem.doviz_kodu||row_islem.ISTATISTIK_KODU_faiz;
   ls_istatistik_kapama := NULL;--'1714'|| varchar_list(p_2003_DOVIZ_KODU) ||'840';--row_islem.prefix_istatistik_kodu_kapama||row_islem.doviz_kodu||row_islem.ISTATISTIK_KODU_kapama ;

   varchar_list(p_2003_STATISTIC_INT)  :=ls_istatistik_faiz;
      varchar_list(p_2003_STATISTIC_CLOSE):=ls_istatistik_kapama;

   IF varchar_list(p_2003_DOVIZ_KODU)=pkg_genel.LC_al THEN
      ln_plan_no:=22;
   ELSE
      ln_plan_no:=23;
   END IF;
   ln_fis_no:=Pkg_Muhasebe.fis_kes(2003,
        ln_plan_no,
        pn_islem_no,
        varchar_list,
        number_list,
        date_list,
        boolean_list,
        NULL,
        FALSE,
        0,
        'Current Account Accruation');


   Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

   --update payment values.
   UPDATE CBS_HESAP
   SET ODENMIS_FAIZ_TOPLAMI=NVL(ODENMIS_FAIZ_TOPLAMI,0)+NVL(number_list(p_2003_FC_TOPLAM_FAIZ),0),
    ODENMIS_FAIZ_TOPLAMI_LC=NVL(ODENMIS_FAIZ_TOPLAMI_LC,0)+NVL(number_list(p_2003_LC_TOPLAM_FAIZ),0),
    BIRIKMIS_FAIZ_POZ=0,
    BIRIKMIS_FAIZ_POZ_ROUND=0, --Sevalb 091207
    GECMIS_AYLARIN_FAIZI = 0 --sevalb  291206
   WHERE hesap_no=row_islem.hesap_no;


   --update daily balance
   SELECT NVL(BAKIYE,0),NVL(bloke_tutari,0),NVL(valorlu_bakiye,0)
   INTO ln_bakiye,ln_bloke_tutari,ln_valorlu_bakiye
   FROM CBS_HESAP_BAKIYE
   WHERE hesap_no=row_islem.hesap_no;
   ld_tarih:=Pkg_Muhasebe.Banka_Tarihi_Bul;
   LOOP
     IF TRUNC(ld_tarih) >= TRUNC(Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul) THEN
      EXIT;
     END IF;

     ln_yil:=TO_CHAR(ld_tarih,'YYYY');
     ln_ay:=TO_CHAR(ld_tarih,'MM');
     ln_gun:=TO_CHAR(ld_tarih,'DD');
     BEGIN
     UPDATE CBS_HESAP_GUNLUK_BAKIYE
     SET bakiye=ln_bakiye,
      bakiye_lc=0,
      bloke=ln_bloke_tutari,
      valorlu_bakiye=ln_valorlu_bakiye
     WHERE 
      yil=ln_yil AND ay=ln_ay AND gun=ln_gun AND
        hesap_no=row_islem.hesap_no;

    EXCEPTION WHEN OTHERS THEN NULL;
    END;
   ld_tarih:=ld_tarih+1;
   END LOOP;


-- B-O-M sevalb 240108 update daily balance for  faiz odeme hesap icin
   IF  NVL(row_islem.faiz_odeme_hesap_no,0) <> 0  THEN
   SELECT NVL(BAKIYE,0),NVL(bloke_tutari,0),NVL(valorlu_bakiye,0)
   INTO ln_bakiye,ln_bloke_tutari,ln_valorlu_bakiye
   FROM CBS_HESAP_BAKIYE
   WHERE hesap_no=row_islem.faiz_odeme_hesap_no;
   ld_tarih:=Pkg_Muhasebe.Banka_Tarihi_Bul;
   LOOP
     IF TRUNC(ld_tarih) >= TRUNC(Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul) THEN
      EXIT;
     END IF;

     ln_yil:=TO_CHAR(ld_tarih,'YYYY');
     ln_ay:=TO_CHAR(ld_tarih,'MM');
     ln_gun:=TO_CHAR(ld_tarih,'DD');
     BEGIN
     UPDATE CBS_HESAP_GUNLUK_BAKIYE
     SET bakiye=ln_bakiye,
      bakiye_lc=0,
      bloke=ln_bloke_tutari,
      valorlu_bakiye=ln_valorlu_bakiye
     WHERE balance_date=ld_tarih and--CBS-475
     --yil=ln_yil AND ay=ln_ay AND gun=ln_gun AND--CBS-475
        hesap_no=row_islem.faiz_odeme_hesap_no;

    EXCEPTION WHEN OTHERS THEN NULL;
    END;
   ld_tarih:=ld_tarih+1;
   END LOOP;
   END IF;
-- E-O-M sevalb 240108 update daily balance for  faiz odeme hesap icin

   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Current Account Accruation is finished for Account No:' || ln_hesap_no || ' Journal No:' || ln_fis_no, pn_islem_no);

   EXCEPTION
        WHEN OTHERS THEN
      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Error for Account No:'|| ln_hesap_no ||Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '4310' || Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE) ||' ' ||SQLERRM|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,pn_islem_no );
      ROLLBACK;
     END ;

   COMMIT;

  FETCH islem_cursor INTO row_islem;
     END LOOP;
     CLOSE islem_cursor;
 ELSE
  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Current Account Accruation runs on Monthly Period,Banking Date is Not EOM ');
 END IF;--AYSONU
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'Error:'|| SQLERRM ||' Account No:'||ln_hesap_no);
  END;
---------------------------------------------------------------------------------------
 PROCEDURE TREASURY_POSITION_REPORT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
 IS
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 BEGIN
  PKG_REPORT_S_B.FILL_FX_POSITION_CUR;
  PKG_REPORT_S_B.FILL_FX_POSITION_USD;
 EXCEPTION
   WHEN OTHERS THEN
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'TREASURY FX POSITION COULD NOT BE CALCULATED');
 END;
 COMMIT;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
  WHEN OTHERS THEN
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
-------------------------------------------------------------------------------------
 PROCEDURE DK_Bakiye_Kopyala (ps_tur VARCHAR2 ) IS
    ld_banka_tarihi     DATE;
  BEGIN
    ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;
     PKG_BAT_1.DKHESAP_UST_DK_GUNCELLE ; --seval.colak 27122021
    INSERT INTO CBS_RPT_MIZAN (tarih,bolum_kodu,tur,dk_numara,doviz_kod,aciklama,
                            borc_lc, alacak_lc, borc_fc,
          alacak_fc, bakiye_lc,
          bakiye_fc)
    SELECT ld_banka_tarihi,bolum_kodu,ps_tur,numara,doviz_kod,NVL(aciklama,'.'),
          NVL(lc_borc_bakiye,0), NVL(lc_alacak_bakiye,0), NVL(borc_bakiye,0),
    NVL(alacak_bakiye,0), NVL(lc_alacak_bakiye,0)-NVL(lc_borc_bakiye,0),
    NVL(alacak_bakiye,0)-NVL(borc_bakiye,0)
      FROM CBS_DKHESAP
   WHERE ( NVL(lc_borc_bakiye,0) !=0  OR NVL(lc_alacak_bakiye,0)  !=0  OR NVL(borc_bakiye,0) !=0  OR NVL(alacak_bakiye,0) !=0  OR
                ( NVL(lc_alacak_bakiye,0)-NVL(lc_borc_bakiye,0)) !=0  OR (NVL(alacak_bakiye,0)-NVL(borc_bakiye,0)) !=0);
  END;
--*******************************************************************************************
PROCEDURE VDLGecenYilFaizi(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
 CURSOR c1 IS
 SELECT hesap_no, doviz_kodu, gecen_yil_faiz_toplami, birikmis_faiz_poz,  birikmis_faiz_poz_round,gecmis_aylarin_faizi
 FROM CBS_HESAP_VADELI
 WHERE durum_kodu='A'
      AND ( NVL(birikmis_faiz_poz,0)  <> 0 OR NVL(gecmis_aylarin_faizi,0) <> 0 )

    FOR UPDATE;

 r1       c1%ROWTYPE;
 ln_commit_counter      NUMBER:=0;
 ln_faiz           NUMBER:=0;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    IF    Pkg_Batch.YIL_SONU_MU THEN
   OPEN c1;
  LOOP
   FETCH c1 INTO r1;
   EXIT WHEN c1%NOTFOUND;

   IF Pkg_Genel.doviz_kuruslu_mu(r1.DOVIZ_KODU) = 'E'
   THEN
    ln_faiz := NVL(r1.gecen_yil_faiz_toplami,0) + NVL(ROUND(NVL(r1.birikmis_faiz_poz,0), 2),0) +  NVL(ROUND(NVL(r1.gecmis_aylarin_faizi,0), 2),0);
   ELSE
    ln_faiz := NVL(r1.gecen_yil_faiz_toplami,0) + NVL(ROUND(NVL(r1.birikmis_faiz_poz,0), 0),0) +  NVL(ROUND(NVL(r1.gecmis_aylarin_faizi,0), 0),0);
   END IF;

   UPDATE CBS_HESAP_VADELI
      SET gecen_yil_faiz_toplami = ln_faiz,
         birikmis_faiz_poz = 0,
         birikmis_faiz_poz_round = 0,
         birikmis_faiz_neg = 0,
         birikmis_faiz_neg_round = 0,
       gecmis_aylarin_faizi = 0
    WHERE CURRENT OF c1;
  END LOOP;
  CLOSE c1;
    END IF;
 COMMIT;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 EXCEPTION
 WHEN OTHERS THEN
 NULL;
 Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
--*******************************************************************************************
PROCEDURE KRGecenYilFaizi(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
 CURSOR c1 IS
 SELECT hesap_no, doviz_kodu, gecenyil_faiz_tutari, gecenyil_komisyon_tutari,
     birikmis_faiz_tutari,  birikmis_komisyon_tutari,gecmis_aylarin_faizi,gecmis_aylarin_komisyonu
   FROM CBS_HESAP_KREDI
  WHERE durum_kodu='A'
    AND ( NVL(birikmis_faiz_tutari,0) <> 0 OR NVL(birikmis_komisyon_tutari,0) <> 0 OR NVL(gecmis_aylarin_faizi,0) <> 0 OR NVL(gecmis_aylarin_komisyonu,0) <> 0  )
 FOR UPDATE;

 r1       c1%ROWTYPE;
 ln_commit_counter     NUMBER:=0;
 ln_faiz        NUMBER:=0;
 ln_komisyon       NUMBER:=0;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 IF    Pkg_Batch.YIL_SONU_MU THEN
  OPEN c1;
  LOOP
   FETCH c1 INTO r1;
   EXIT WHEN c1%NOTFOUND;
   IF Pkg_Genel.doviz_kuruslu_mu(r1.DOVIZ_KODU) = 'E'
   THEN
    ln_faiz := NVL(r1.gecenyil_faiz_tutari,0) + NVL(ROUND(NVL(r1.birikmis_faiz_tutari,0), 2),0) + NVL(ROUND(NVL(r1.gecmis_aylarin_faizi,0), 2),0) ;
    ln_komisyon := NVL(r1.gecenyil_komisyon_tutari,0) + NVL(ROUND(NVL(r1.birikmis_komisyon_tutari,0), 2),0) + NVL(ROUND(NVL(r1.gecmis_aylarin_komisyonu,0), 2),0);
   ELSE
    ln_faiz := NVL(r1.gecenyil_faiz_tutari,0) + NVL(ROUND(NVL(r1.birikmis_faiz_tutari,0), 0),0) + NVL(ROUND(NVL(r1.gecmis_aylarin_faizi,0),0),0);
    ln_komisyon := NVL(r1.gecenyil_komisyon_tutari,0) + NVL(ROUND(NVL(r1.birikmis_komisyon_tutari,0), 0),0) + NVL(ROUND(NVL(r1.gecmis_aylarin_komisyonu,0), 0),0) ;
   END IF;
   UPDATE CBS_HESAP_KREDI
           SET gecenyil_faiz_tutari = ln_faiz,
       gecenyil_komisyon_tutari = ln_komisyon,
       birikmis_faiz_tutari = 0,
       birikmis_komisyon_tutari = 0,
       gecmis_aylarin_faizi = 0,
       gecmis_aylarin_komisyonu = 0
    WHERE CURRENT OF c1;
  END LOOP;
  CLOSE c1;
 END IF;
 COMMIT;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 EXCEPTION
 WHEN OTHERS THEN
 NULL;
 Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
--*******************************************************************************************
PROCEDURE YILSONU_KARZARAR_KAPAMA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
IS
    p_8000_BOLUM_KODU     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_BOLUM_KODU');
      p_8000_BAKIYE          NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_BAKIYE');
    p_8000_TOP_BAKIYE         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_TOP_BAKIYE');
      p_8000_DK_NO          NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_DK_NO');
       p_8000_BANKA_ACIKLAMA    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_BANKA_ACIKLAMA');
      p_8000_MUSTERI_ACIKLAMA     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_MUSTERI_ACIKLAMA');
      p_8000_ISTATISTIK_KODU    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8000_ISTATISTIK_KODU');

     varchar_list     Pkg_Muhasebe.varchar_array;
     number_list      Pkg_Muhasebe.number_array;
     date_list      Pkg_Muhasebe.date_array;
     boolean_list     Pkg_Muhasebe.boolean_array;

  ln_plan_no      NUMBER:=0;
  pn_islem_no      NUMBER;
     ln_counter      NUMBER:=0;
     ln_fis_numara     CBS_FIS.numara%TYPE;
     ln_temp_numara     CBS_FIS.numara%TYPE;
     ln_fark       CBS_DKHESAP.evaluasyonlu_bakiye%TYPE;
  ln_islem_numara     CBS_ISLEM.numara%TYPE;
  ln_islem_kod        NUMBER:=8000;
  ls_fis_aciklama        VARCHAR2(2000):='END OF YEAR PROFIT-LOSS CLOSING';
     ln_FC_DK_number     NUMBER:=0;
 CURSOR s1 IS
    SELECT bolum_kodu, numara, doviz_kod,alacak_bakiye, bakiye, borc_bakiye
      FROM CBS_DKHESAP
     WHERE SUBSTR(numara,1,1) IN('6','7','8') AND LENGTH(numara ) = 8;
    r_s1                            s1%ROWTYPE;

       CURSOR c1 IS
         SELECT bolum_kodu,SUBSTR(numara,1,1) dk_no,SUM(NVL(bakiye,0)) top_bakiye
        FROM CBS_DKHESAP
       WHERE NVL(bakiye,0) <> 0 AND SUBSTR(numara,1,1) IN('6','7','8') AND LENGTH(numara ) = 8
    AND doviz_kod =pkg_genel.lc_al
      GROUP BY bolum_kodu,SUBSTR(numara,1,1);
   r_c1         c1%ROWTYPE;

  CURSOR c2 IS
     SELECT  bolum_kodu, numara, doviz_kod,bakiye
          FROM CBS_DKHESAP
         WHERE NVL(bakiye,0) <> 0 AND SUBSTR(numara,1,1) IN('6','7','8')
        AND LENGTH(numara )   = 8
        AND bolum_kodu        = r_c1.bolum_kodu
       AND SUBSTR(numara,1,1)= r_c1.dk_no
       AND doviz_kod =pkg_genel.lc_al;
   r_c2            c2%ROWTYPE;

   yp_bakiye_mevcut EXCEPTION;

  BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
   IF    Pkg_Batch.YIL_SONU_MU THEN
   /* FC DK da bakiye varsa hata vermeli */
   BEGIN
  SELECT MIN(numara)
    INTO ln_fc_dk_number
       FROM CBS_DKHESAP
      WHERE NVL(bakiye,0) <> 0 AND
         SUBSTR(numara,1,1) IN( '6','7','8') AND
      LENGTH(numara ) = 8 AND
      doviz_kod <> pkg_genel.lc_al ;
   EXCEPTION
  WHEN OTHERS THEN NULL;
   END;
     IF ln_FC_DK_number <> 0 THEN
  RAISE yp_bakiye_mevcut;
   ELSE
      DELETE FROM CBS_DKHESAP_YILSONU_ONCESI
    WHERE banka_tarihi = pkg_muhasebe.banka_tarihi_bul;
   INSERT INTO CBS_DKHESAP_YILSONU_ONCESI
              (bolum_kodu, numara, doviz_kod, alacak_bakiye, bakiye, borc_bakiye, banka_tarihi, bakiye_lc)
        SELECT bolum_kodu, numara, doviz_kod,alacak_bakiye, bakiye, borc_bakiye, pkg_muhasebe.banka_tarihi_bul, bakiye_lc
             FROM CBS_DKHESAP
            WHERE SUBSTR(numara,1,1) IN( '6','7','8') AND LENGTH(numara ) = 8;
      OPEN c1; -- Her bir bolum icin
   LOOP
      FETCH c1 INTO r_c1;
      EXIT WHEN c1%NOTFOUND;
         ln_islem_numara:=Pkg_Batch.islem_yarat(ln_islem_kod,r_c1.bolum_kodu);
              varchar_list(P_8000_BOLUM_KODU):=r_c1.bolum_kodu;
            Pkg_Parametre.deger('8000_BANKA_ACIKLAMA',varchar_list(P_8000_BANKA_ACIKLAMA));
        Pkg_Parametre.deger('8000_MUSTERI_ACIKLAMA',varchar_list(P_8000_MUSTERI_ACIKLAMA));
           varchar_list(P_8000_ISTATISTIK_KODU):='.';
                 number_list(P_8000_TOP_BAKIYE):=ABS(r_c1.top_bakiye);
     /* Kar zarar Dk'sina toplam olarak fis kesilir */
       IF  r_c1.top_bakiye > 0 THEN
     ln_plan_no := 1;
    ELSE
     ln_plan_no := 2;
    END IF;
    ln_fis_numara:=Pkg_Muhasebe.fis_kes(ln_islem_kod, ln_plan_no, ln_islem_numara,
        varchar_list, number_list, date_list, boolean_list,
        NULL, FALSE, 0, ls_fis_aciklama);
             ln_counter:=0;
     OPEN c2;  -- Her bir DK NO icin
           LOOP
          FETCH c2 INTO r_c2;
          EXIT WHEN c2%NOTFOUND;
        varchar_list(P_8000_BOLUM_KODU):=r_c2.bolum_kodu;
        varchar_list(P_8000_DK_NO):=r_c2.numara;
           varchar_list(P_8000_ISTATISTIK_KODU):='.';
                    number_list(P_8000_BAKIYE):=ABS(r_c2.bakiye);
    ln_plan_no := 0;
        IF  r_c2.bakiye > 0 THEN
     ln_plan_no := 3;
    ELSE
     ln_plan_no := 4;
    END IF;
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle ( ln_islem_kod, ln_plan_no, ln_fis_numara,
                                                          varchar_list, number_list, date_list, boolean_list,
                NULL, FALSE);
            ln_counter:=ln_counter+1;
      END LOOP;
      CLOSE c2;
         IF ln_counter>0 THEN
               Pkg_Muhasebe.Muhasebelestir(ln_fis_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3150'||Pkg_Hata.GetDelimiter||r_c1.bolum_kodu||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_numara)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
            END IF;
        END LOOP;
   CLOSE c1;
     COMMIT;
      END IF;
 END IF;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod,ln_islem_numara);
  EXCEPTION
   WHEN yp_bakiye_mevcut THEN
      ROLLBACK;
      Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'4981'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_FC_DK_number)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
    WHEN OTHERS THEN
  ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM,ln_islem_numara);
END;
--*******************************************************************************************
PROCEDURE YILSONU_DKHESAP_KAPAMA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
IS
    p_8001_BOLUM_KODU     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BOLUM_KODU');
      p_8001_BAKIYE_LC         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BAKIYE_LC');
    p_8001_BAKIYE_FC         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BAKIYE_FC');
    p_8001_DOVIZ_KOD         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_DOVIZ_KOD');
      p_8001_DK_NO          NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_DK_NO');
       p_8001_BANKA_ACIKLAMA    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BANKA_ACIKLAMA');
      p_8001_MUSTERI_ACIKLAMA     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_MUSTERI_ACIKLAMA');
      p_8001_ISTATISTIK_KODU    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_ISTATISTIK_KODU');
      p_8001_BAKIYE_POZITIF    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BAKIYE_POZITIF');
       p_8001_BAKIYE_NEGATIF    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8001_BAKIYE_NEGATIF');

     varchar_list     Pkg_Muhasebe.varchar_array;
     number_list      Pkg_Muhasebe.number_array;
     date_list      Pkg_Muhasebe.date_array;
     boolean_list     Pkg_Muhasebe.boolean_array;

  ln_plan_no      NUMBER:=0;
  pn_islem_no      NUMBER;
     ln_counter      NUMBER:=0;
     ln_fis_numara     CBS_FIS.numara%TYPE;
     ln_temp_numara     CBS_FIS.numara%TYPE;
  ln_islem_numara     CBS_ISLEM.numara%TYPE;
  ln_islem_kod        NUMBER:=8001;
  ls_fis_aciklama        VARCHAR2(2000):='GL ACCOUNT END OF YEAR CLOSING';
     ln_FC_DK_number     NUMBER:=0;

  CURSOR c1 IS
         SELECT  bolum_kodu
        FROM CBS_DKHESAP
       WHERE SUBSTR(numara,1,1) NOT IN('6','7','8')
      AND LENGTH(numara ) = 8
            AND (NVL(bakiye,0) <> 0 OR NVL(bakiye_lc,0) <> 0)
      GROUP BY bolum_kodu;
   r_c1         c1%ROWTYPE;

  CURSOR c2 IS
     SELECT bolum_kodu, numara, doviz_kod,bakiye,bakiye_lc
          FROM CBS_DKHESAP
         WHERE (NVL(bakiye,0) <> 0 OR NVL(bakiye_lc,0) <> 0)
        AND LENGTH(numara )   = 8
        AND SUBSTR(numara,1,1) NOT IN('6','7','8')
        AND bolum_kodu        = r_c1.bolum_kodu;

    r_c2            c2%ROWTYPE;


  BEGIN
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

        IF    Pkg_Batch.YIL_SONU_MU THEN

      DELETE FROM CBS_DK_KAPAMA_YILSONU_ONCESI
    WHERE banka_tarihi = pkg_muhasebe.banka_tarihi_bul;

   INSERT INTO CBS_DK_KAPAMA_YILSONU_ONCESI
               (bolum_kodu, numara, doviz_kod, alacak_bakiye, borc_bakiye, bakiye_lc, bakiye_fc, banka_tarihi)
         SELECT bolum_kodu, numara, doviz_kod, alacak_bakiye, borc_bakiye, bakiye_lc, bakiye, pkg_muhasebe.banka_tarihi_bul
           FROM CBS_DKHESAP
          WHERE LENGTH(numara ) = 8
            AND SUBSTR(numara,1,1) NOT IN('6','7','8');

   OPEN c1; -- Her bir bolum icin
   LOOP
      FETCH c1 INTO r_c1;
      EXIT WHEN c1%NOTFOUND;
      ln_islem_numara:=Pkg_Batch.islem_yarat(ln_islem_kod,r_c1.bolum_kodu);
     varchar_list(P_8001_BANKA_ACIKLAMA) := 'GL Account End Of Year Closing';
     varchar_list(P_8001_MUSTERI_ACIKLAMA) := 'GL Account End Of Year Closing';
              ln_counter:=0;
     OPEN c2;  -- Her bir DK NO icin
           LOOP
          FETCH c2 INTO r_c2;
          EXIT WHEN c2%NOTFOUND;
        varchar_list(P_8001_BOLUM_KODU):=r_c2.bolum_kodu;
        varchar_list(P_8001_DK_NO):=r_c2.numara;
        varchar_list(P_8001_DOVIZ_KOD):=r_c2.doviz_kod;
           varchar_list(P_8001_ISTATISTIK_KODU):='.';
                    number_list(P_8001_BAKIYE_LC):=ABS(r_c2.bakiye_lc);
        number_list(P_8001_BAKIYE_FC):=ABS(r_c2.bakiye);
    IF  r_c2.bakiye > 0  THEN
     boolean_list(P_8001_BAKIYE_POZITIF):= TRUE ;
     boolean_list(P_8001_BAKIYE_NEGATIF):= FALSE ;
    ELSE
     boolean_list(P_8001_BAKIYE_POZITIF):= FALSE ;
     boolean_list(P_8001_BAKIYE_NEGATIF):= TRUE ;
    END IF;
    IF ln_counter = 0 THEN
       ln_fis_numara:=Pkg_Muhasebe.fis_kes(ln_islem_kod, NULL, ln_islem_numara,
        varchar_list, number_list, date_list, boolean_list,
        NULL, FALSE, 0, ls_fis_aciklama);
    ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle ( ln_islem_kod, NULL, ln_fis_numara,
        varchar_list, number_list, date_list, boolean_list,
        NULL, FALSE);
    END IF;
       ln_counter:=ln_counter+1;
      END LOOP;
      CLOSE c2;
         IF ln_counter>0 THEN
               Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3151'||Pkg_Hata.GetDelimiter||r_c2.bolum_kodu||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_numara)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
       BEGIN
        UPDATE CBS_DK_KAPAMA_YILSONU_ONCESI
           SET fis_no = ln_fis_numara
         WHERE bolum_kodu = r_c1.bolum_kodu;
        EXCEPTION
         WHEN OTHERS THEN NULL;
       END;
            END IF;
    END LOOP;
    CLOSE c1;
     COMMIT;
    END IF;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod,ln_islem_numara);
  EXCEPTION
    WHEN OTHERS THEN
  ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM,ln_islem_numara);
END;
--****************************************************************************
PROCEDURE YILSONU_DKHESAP_ACILIS(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
IS
    p_8002_BOLUM_KODU     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BOLUM_KODU');
      p_8002_BAKIYE_LC         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BAKIYE_LC');
    p_8002_BAKIYE_FC         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BAKIYE_FC');
    p_8002_DOVIZ_KOD         NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_DOVIZ_KOD');
      p_8002_DK_NO          NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_DK_NO');
       p_8002_BANKA_ACIKLAMA    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BANKA_ACIKLAMA');
      p_8002_MUSTERI_ACIKLAMA     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_MUSTERI_ACIKLAMA');
      p_8002_ISTATISTIK_KODU    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_ISTATISTIK_KODU');
      p_8002_BAKIYE_POZITIF    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BAKIYE_POZITIF');
       p_8002_BAKIYE_NEGATIF    NUMBER :=Pkg_Muhasebe.parametre_index_bul('8002_BAKIYE_NEGATIF');

     varchar_list     Pkg_Muhasebe.varchar_array;
     number_list      Pkg_Muhasebe.number_array;
     date_list      Pkg_Muhasebe.date_array;
     boolean_list     Pkg_Muhasebe.boolean_array;

  ln_plan_no      NUMBER:=0;
  pn_islem_no      NUMBER;
     ln_counter      NUMBER:=0;
     ln_fis_numara     CBS_FIS.numara%TYPE;
     ln_temp_numara     CBS_FIS.numara%TYPE;
  ln_islem_numara     CBS_ISLEM.numara%TYPE;
  ln_islem_kod        NUMBER:=8002;
  ls_fis_aciklama        VARCHAR2(2000);
  ls_banka_aciklama       VARCHAR2(2000);
  ls_musteri_aciklama       VARCHAR2(2000);
     ln_FC_DK_number     NUMBER:=0;

  CURSOR c1 IS
         SELECT bolum_kodu
        FROM CBS_DK_KAPAMA_YILSONU_ONCESI
       WHERE LENGTH(numara ) = 8
            AND (NVL(bakiye_fc,0) <> 0 OR NVL(bakiye_lc,0) <> 0)
      AND banka_tarihi >= pkg_tarih.geri_is_gunu(pkg_muhasebe.banka_tarihi_bul)
      GROUP BY bolum_kodu;
   r_c1         c1%ROWTYPE;

  CURSOR c2 IS
     SELECT bolum_kodu, numara, doviz_kod, bakiye_fc bakiye,bakiye_lc
          FROM CBS_DK_KAPAMA_YILSONU_ONCESI
         WHERE (NVL(bakiye_fc,0) <> 0 OR NVL(bakiye_lc,0) <> 0)
        AND LENGTH(numara) = 8
        AND banka_tarihi >= pkg_tarih.geri_is_gunu(pkg_muhasebe.banka_tarihi_bul)
        AND bolum_kodu = r_c1.bolum_kodu;
    r_c2            c2%ROWTYPE;


  BEGIN
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
        IF Pkg_Tarih.yilin_ilk_is_gunu =Pkg_Muhasebe.banka_tarihi_bul THEN
       DELETE FROM CBS_DK_ACILIS_YILSONU_SONRASI
    WHERE banka_tarihi = pkg_muhasebe.banka_tarihi_bul;

   INSERT INTO CBS_DK_ACILIS_YILSONU_SONRASI(bolum_kodu, numara, doviz_kod ,banka_tarihi)
               SELECT bolum_kodu, numara, doviz_kod, pkg_muhasebe.banka_tarihi_bul
           FROM CBS_DK_KAPAMA_YILSONU_ONCESI
          WHERE LENGTH(numara ) = 8
               AND banka_tarihi >= pkg_tarih.geri_is_gunu(pkg_muhasebe.banka_tarihi_bul);

  /* yilsonunda kumulatif bakiye alanlarinin sifirlanmasi */
   UPDATE CBS_DKHESAP
      SET alacak_bakiye = 0,
          borc_bakiye = 0,
          lc_alacak_bakiye = 0,
          lc_borc_bakiye = 0;

     ls_fis_aciklama := Pkg_Genel.ISLEM_ADI_AL(8002) ;
      Pkg_Parametre.deger('8002_BANKA_ACIKLAMA', ls_banka_aciklama);
     Pkg_Parametre.deger('8002_MUSTERI_ACIKLAMA', ls_musteri_Aciklama);

   OPEN c1; -- Her bir bolum icin
   LOOP
      FETCH c1 INTO r_c1;
      EXIT WHEN c1%NOTFOUND;
      ln_islem_numara := Pkg_Batch.islem_yarat(ln_islem_kod,r_c1.bolum_kodu);
              ln_counter := 0;
     OPEN c2;  -- Her bir DK NO icin
           LOOP
          FETCH c2 INTO r_c2;
          EXIT WHEN c2%NOTFOUND;
           varchar_list(p_8002_BANKA_ACIKLAMA) := r_c2.numara || ' '  || r_c2.doviz_kod || ' ' || NVL(ls_banka_aciklama,ls_fis_aciklama);
           varchar_list(p_8002_MUSTERI_ACIKLAMA) := r_c2.numara || ' ' || r_c2.doviz_kod || ' ' ||  NVL(ls_musteri_aciklama,ls_fis_aciklama);
        varchar_list(p_8002_BOLUM_KODU) := r_c2.bolum_kodu;
        varchar_list(p_8002_DK_NO) := r_c2.numara;
           varchar_list(p_8002_ISTATISTIK_KODU):='.';
        varchar_list(p_8002_DOVIZ_KOD) := r_c2.doviz_kod;
        number_list(p_8002_BAKIYE_FC) := ABS(r_c2.bakiye);
        number_list(p_8002_BAKIYE_LC):= ABS(r_c2.bakiye_lc);

    IF  r_c2.bakiye > 0  THEN
     boolean_list(P_8002_BAKIYE_POZITIF) := TRUE ;
     boolean_list(P_8002_BAKIYE_NEGATIF) := FALSE ;
    ELSE
     boolean_list(P_8002_BAKIYE_POZITIF) := FALSE ;
     boolean_list(P_8002_BAKIYE_NEGATIF) := TRUE ;
    END IF;
    IF ln_counter = 0 THEN
       ln_fis_numara:=Pkg_Muhasebe.fis_kes(ln_islem_kod, NULL, ln_islem_numara,
        varchar_list, number_list, date_list, boolean_list ,
        NULL, FALSE, 0, ls_fis_aciklama);
    ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle ( ln_islem_kod, NULL, ln_fis_numara,
        varchar_list, number_list, date_list, boolean_list,
        NULL, FALSE);
    END IF;
       ln_counter:=ln_counter+1;
      END LOOP;
      CLOSE c2;
         IF ln_counter>0 THEN
               Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3152'||Pkg_Hata.GetDelimiter||r_c2.bolum_kodu||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_numara)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
        /* Muhasebe sonrasi bakiye raporlanacak */
        BEGIN
           UPDATE CBS_DK_ACILIS_YILSONU_SONRASI a
               SET (alacak_bakiye,borc_bakiye,bakiye_lc,bakiye_fc,fis_no) =
                 (SELECT c.alacak_bakiye, c.borc_bakiye, c.bakiye_lc, c.bakiye, ln_fis_numara
                   FROM CBS_DKHESAP c
                 WHERE bolum_kodu = a.bolum_kodu AND
                   numara = a.numara AND
             doviz_kod = a.doviz_kod)
          WHERE bolum_kodu = r_c1.bolum_kodu  ;
          EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
            END IF;
    END LOOP;
    CLOSE c1;
       COMMIT;
     END IF;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod,ln_islem_numara);
  EXCEPTION
    WHEN OTHERS THEN
  ROLLBACK;
     Pkg_Batch.hata_logla(pn_grup_no, pn_log_no, ps_program_kod, SQLERRM, ln_islem_numara);
END;
--*******************************************************************************************
PROCEDURE YILSONU_HESAP_UPDATE(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
IS

BEGIN
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
   IF Pkg_Tarih.yilin_ilk_is_gunu =Pkg_Muhasebe.banka_tarihi_bul THEN
         UPDATE CBS_HESAP
      SET gecmisyil_odenmis_faiz_toplami = NVL(gecmisyil_odenmis_faiz_toplami,0) + odenmis_faiz_toplami,
          odenmis_faiz_toplami = 0
          WHERE doviz_kodu=pkg_genel.lc_al
      AND durum_kodu='A';

      UPDATE CBS_HESAP_VADELI
      SET gecmisyil_odenmis_faiz_toplami = NVL(gecmisyil_odenmis_faiz_toplami,0) + odenmis_faiz_toplami ,
          gecmisyil_tahakkuk_sch_faiz = NVL(gecmisyil_tahakkuk_sch_faiz,0) + tahakkuk_eden_sch_tutari,
          tahakkuk_eden_sch_tutari=0,
          odenmis_faiz_toplami = 0
          WHERE doviz_kodu=pkg_genel.lc_al
      AND durum_kodu='A';

   UPDATE CBS_HESAP_KREDI
      SET gecmisyil_tahsil_faiz_toplami =NVL(gecmisyil_tahsil_faiz_toplami,0) + tahsiledilen_faiz_tutari ,
          gecmisyil_tahakkuk_sch_faiz = NVL(gecmisyil_tahakkuk_sch_faiz,0) + tahakkuk_sch_faiz_tutari,
          gecmisyil_tahsil_kom_toplami =tahsiledilen_komisyon_tutari + NVL(gecmisyil_tahsil_kom_toplami,0),
          tahsiledilen_faiz_tutari = 0 ,
          tahakkuk_sch_faiz_tutari =0,
          tahsiledilen_komisyon_tutari=0
          WHERE doviz_kodu=pkg_genel.lc_al
      AND durum_kodu='A';
   END IF;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
  ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
------------------------------------------------------------------------
PROCEDURE Yil_sonu_KZ_kapama_DKKopyala(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2) IS
  -- Bu prosedur kar zarar kapamalardan sonra calistirilir ve DK bakiyelerini kopyalar
  BEGIN
 pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    IF pkg_batch.yil_sonu_mu THEN
     dk_bakiye_kopyala('1'); --
  COMMIT;
    END IF;
   pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-------------------------------------------------------------------------------
PROCEDURE Yil_sonu_DK_kapama_DKKopyala(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2) IS
  -- Bu prosedur DK kapamalardan sonra calistirilir ve DK bakiyelerini kopyalar
  BEGIN
 pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    IF    pkg_batch.yil_sonu_mu THEN
     dk_bakiye_kopyala('2'); --
  COMMIT;
    END IF;
   pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-------------------------------------------------------------------------------
PROCEDURE Yil_sonu_DK_Acilis_DKKopya(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2) IS
   BEGIN
 pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 IF Pkg_Tarih.yilin_ilk_is_gunu =Pkg_Muhasebe.banka_tarihi_bul THEN
     dk_bakiye_kopyala('3'); --
  COMMIT;
 END IF;
   pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-----------------------------------------------------------------------------
PROCEDURE ACCOUNTING_NBREPORTS(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
    ln_messageid NUMBER;
    ls_content VARCHAR2(2000);

 CURSOR cursor_hesap IS
  SELECT hesap_no FROM CBS_HESAP_VADELI
  WHERE VADE_TARIHI=pkg_tarih.ileri_is_gunu(pkg_muhasebe.Banka_Tarihi_Bul)
  AND durum_kodu='A';

 row_hesap cursor_hesap%ROWTYPE;

BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 BEGIN

  --TA
  PKG_VADEHESAP_RAPOR.UpdatePreviousHistory(PKG_DATES.get_previous_work_date(PKG_MUHASEBE.Banka_Tarihi_Bul));

  --TA Time Deposit Value date alert
  BEGIN

   OPEN cursor_hesap;
   FETCH cursor_hesap INTO row_hesap;
   IF cursor_hesap%FOUND THEN
    WHILE cursor_hesap%FOUND
    LOOP
     ls_content:=ls_content || 'Account No:' || row_hesap.hesap_no || '<BR>';
    FETCH cursor_hesap INTO row_hesap;
    END LOOP;
    ln_messageid:=pkg_genel.genel_kod_al('EMAIL-MSGID');
    pkg_email.AddToEmailQueue('TIMEDEPDATE', 50, 'info@demirbank.kz', 'XeniyaP@demirbank.kz;annag@demirbank.kz;aliyaa@demirbank.kz;ITgroup@demirbank.kz', 'TIME DEPOSIT VALUE DATE ALERT',ls_content,'HTML');
   END IF;
   CLOSE cursor_hesap;

     EXCEPTION
    WHEN OTHERS THEN
       NULL;
  END;

  --MP
  pkg_sn_srv.FILL_SN_SRV(PKG_DATES.get_previous_work_date(PKG_MUHASEBE.Banka_Tarihi_Bul));

 EXCEPTION
   WHEN OTHERS THEN
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'ACCOUNTING NB REPORTS');
 END;
 COMMIT;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
  WHEN OTHERS THEN
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
---------------------------------------------------------------------------------------------------------
PROCEDURE BRANCH_ACTIVITY_REPORT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
    ln_messageid NUMBER;
    ls_content VARCHAR2(2000);
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 --TA
 PKG_REPORT_BRANCH_ACTIVITY.EOD_PROCEDURE;

 COMMIT;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
  WHEN OTHERS THEN
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------
--Send Non Resident Clearings to transient whic is not paid in 3 days
PROCEDURE PROCESS_NONR_CLEARINGS(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
BEGIN
 NULL;
 END;
/* the following comes from KZ version hence commented out

  ln_messageid number;
  ls_content varchar2(2000);
  cursor cursor_aps is
  select * from CBS_VW_CLEARING
  where urun_tur_kod='INCOMING'
  and DEFINITE_TYPE ='N2R'
  and NR2R_STATUS in ('sTR')
  and MSG_STATUS='sDONE'
  and VALUE_DATE=pkg_tarih.geri_is_gunu(pkg_tarih.geri_is_gunu(pkg_muhasebe.Banka_Tarihi_Bul));

  row_aps        cursor_aps%rowtype;
  ln_islem_no       number;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 --TA
 OPEN cursor_aps;
 FETCH cursor_aps INTO row_aps;
  WHILE cursor_aps%found
  LOOP
   ln_islem_no :=Pkg_Batch.islem_yarat(2106,row_aps.BRANCH_CODE);

   insert into CBS_CLEARING_NONR2R_TRAN
   (TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, REFERENCE, CLEARING_TX_NO, TRANSFER_TYPE, DETAIL_ID, TO_ACCOUNT, TO_AMOUNT, NR2R_STATUS, TO_NAME)
   values
   (ln_islem_no,'CLEARING','INCOMING','NR2R',row_aps.REF_NO,row_aps.TX_NO,'TR-TR',row_aps.DETAIL_ID,row_aps.TO_ACCOUNT,row_aps.TRAN_AMOUNT,row_aps.NR2R_STATUS,row_aps.TO_NAME);

   --pkg_clearing.Process_Transaction(ln_islem_no);
   pkg_tx2106.Onay_Sonrasi(ln_islem_no);
   pkg_tx2106.Muhasebelesme(ln_islem_no);

   COMMIT;

   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Clearing Tx No:' || row_aps.TX_NO || ' Detail No:' || row_aps.DETAIL_ID);

  FETCH cursor_aps INTO row_aps;
  END LOOP;
    CLOSE cursor_aps;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
  WHEN OTHERS THEN
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
*/
-----------------------------------------------------------------------------------
procedure ACC_MAINTENANCE_FEE_CUST(pn_grup_no number, pn_log_no number, ps_program_kod varchar2,pn_customer_no number ,pd_banka_tarihi date default pkg_muhasebe.banka_tarihi_bul )
IS PRAGMA AUTONOMOUS_TRANSACTION;

 varchar_list               Pkg_Muhasebe.varchar_array;
 number_list                Pkg_Muhasebe.number_array;
 date_list                  Pkg_Muhasebe.date_array;
 boolean_list               Pkg_Muhasebe.boolean_array;

 ln_fis_numara              number;
 ln_counter                 number;
 ln_temp_numara             number;

 p_7048_ACC_BRANCH          NUMBER;
 p_7048_TRAN_BRANCH         NUMBER;
 p_7048_ACC                 NUMBER;
 p_7048_INCOME_GL           NUMBER;
 p_7048_CY                  NUMBER;
 p_7048_EXPLAIN             NUMBER;
 p_7048_AMOUNT_FC           NUMBER;
 p_7048_AMOUNT_LC           NUMBER;
 p_7048_INCOME_LC           NUMBER; --cbs-578 bahianab
 p_7048_RATE                NUMBER;

 p_7048_TAX_FC              NUMBER;
 p_7048_TAX_LC              NUMBER;
 p_7048_TAX_EXPLAIN         NUMBER;

    CURSOR c_musteri IS

  SELECT MUSTERI_NO, DK_GRUP_KOD, BOLUM_KODU
    FROM CBS_MUSTERI
   WHERE     musteri_no = pn_customer_no
         AND DURUM_KODU = 'A'
         AND MUSTERI_TIPI_KOD IN ('1', '2', '3')
         AND HESAP_UCRETI_F = 'E'
         AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
                                  FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
                                 WHERE     ISLEM_KODU = 7048
                                       AND MASRAF_KODU = 'ACCMAINFEE')
         AND MUSTERI_NO NOT IN (SELECT customer_no FROM CBS_CUSTOMER_FEE)
    ORDER BY musteri_no;

  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod in ('CURRENT','DEMAND DEP')
  and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) desc;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz varchar2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod in ('CURRENT','DEMAND DEP')
  and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) desc;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ld_bas                     DATE;
 ld_son                     DATE;
 ln_yil                     NUMBER;
 ln_ay                      NUMBER;
 ln_amnt_ind                NUMBER;
 ls_cy_ind                  VARCHAR2(3);
 ln_amnt_corp               NUMBER;
 ls_cy_corp                 VARCHAR2(3);
 ln_cnt                     NUMBER;

 ln_kur_ucret_dvz           NUMBER;
 ln_kur_hesap_dvz           NUMBER;
 ln_masraf                  NUMBER;
 ln_bakiye                  NUMBER;
 ln_amnt                    NUMBER;
 ls_cy                      VARCHAR2(3);
 ls_uygun                   VARCHAR2(1);
 ln_sira                    NUMBER;
 ln_company_no              NUMBER; --AdiletK 29082014 CQ944
 ls_kod                     VARCHAR2(50); --AdiletK 29082014 CQ944
 ls_deger                   VARCHAR2(20); --AdiletK 29082014 CQ944

 ln_toplam_tahsil           NUMBER;
 ln_kalan_tahsilat          NUMBER;
 ln_hesaptan_al             NUMBER;
 ln_muhasebelesecek_tutar   NUMBER;
 ln_tahsil_tutar            NUMBER;
 ln_kal                     NUMBER;
 ln_islem_no                NUMBER := 0;
 ls_dk                      VARCHAR2(30);
 ln_toplam_masraf           NUMBER; --cbs-578 bahianab
 ln_total_lc_amount         NUMBER; --cbs-578 bahianab 
 ln_total_fc_amount         NUMBER; --cbs-578 bahianab 
 ln_fc_tahsil_tutar         NUMBER; --cbs-578 bahianab
 ls_7048_explanation        VARCHAR2(200); --cbs-578 bahianab
 ls_7048_tax_explanation    VARCHAR2(200); --cbs-578 bahianab

 double_run_1               EXCEPTION;
 double_run_2               EXCEPTION;
 birden_fazla_parametre_var EXCEPTION;
 parametre_yok              EXCEPTION;
 dk_yok                     EXCEPTION;
 ln_rate                    NUMBER;
 ln_vergi                   NUMBER;
 ln_vergi_tl                NUMBER;
 ln_cnt1                    NUMBER;
 ln_cnt2                    NUMBER;
 
BEGIN
 --Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
 --if pkg_dates.get_last_work_day_in_month(pd_banka_tarihi) = pkg_muhasebe.Banka_Tarihi_Bul
 --then --EOM
  Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
  Pkg_Parametre.deger('AMF_EXPLANATION',ls_7048_explanation);--cbs-578 bahianab
  Pkg_Parametre.deger('AMF_TAX_EXPLANATION',ls_7048_tax_explanation);--cbs-578 bahianab

  p_7048_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_ACC_BRANCH');
  p_7048_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_TRAN_BRANCH');
  p_7048_ACC :=Pkg_Muhasebe.parametre_index_bul('7048_ACC');
  p_7048_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7048_INCOME_GL');
  p_7048_CY :=Pkg_Muhasebe.parametre_index_bul('7048_CY');
  p_7048_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_EXPLAIN');

  p_7048_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_FC');
  p_7048_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_LC');
  p_7048_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7048_INCOME_LC'); --cbs-578 bahianab
  p_7048_RATE :=Pkg_Muhasebe.parametre_index_bul('7048_RATE');

  p_7048_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_FC');
  p_7048_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_LC');
  p_7048_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_EXPLAIN');

  ln_amnt_ind := 0;
  ls_cy_ind := null;
  ln_amnt_corp := 0;
  ls_cy_corp := null;

  select count(*)
  into ln_cnt
  from cbs_masraf_kriterleri
  where CHARGE_CODE = 'ACCMAINFEE'
    and CUSTOMER_TYPE = 'INDIVIDUAL';
  if ln_cnt = 1
  then
   select CHARGE_AMOUNT, CHARGE_CURRENCY
   into ln_amnt_ind,ls_cy_ind
   from cbs_masraf_kriterleri
   where CHARGE_CODE = 'ACCMAINFEE'
     and CUSTOMER_TYPE = 'INDIVIDUAL';
  else
   raise birden_fazla_parametre_var;
  end if;
  --
  select count(*)
  into ln_cnt
  from cbs_masraf_kriterleri
  where CHARGE_CODE = 'ACCMAINFEE'
    and CUSTOMER_TYPE = 'CORPORATE';
  if ln_cnt = 1
  then
   select CHARGE_AMOUNT, CHARGE_CURRENCY
   into ln_amnt_corp,ls_cy_corp
   from cbs_masraf_kriterleri
   where CHARGE_CODE = 'ACCMAINFEE'
     and CUSTOMER_TYPE = 'CORPORATE';
  else
   raise birden_fazla_parametre_var;
  end if;
  --
  ld_bas := to_date(to_char(ltrim(rtrim('01'||to_char(pd_banka_tarihi,'MMYYYY')))),'DD.MM.YYYY');
  ld_son := LAST_DAY(pd_banka_tarihi);
  ln_yil := to_number(to_char(pd_banka_tarihi,'YYYY'));
  ln_ay := to_number(to_char(pd_banka_tarihi,'MM'));

  --
  OPEN c_musteri ;
  LOOP
   FETCH c_musteri INTO r_musteri  ;
   EXIT WHEN c_musteri%NOTFOUND;
     --    Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(r_musteri.MUSTERI_NO)||' started'); 

      select count(*)
      into ln_cnt1
      from CBS_FEE_TAHSIL_EDILEN_ACCFEE
      where CHARGE_CODE = 'ACCMAINFEE'
        and MUSTERI_NO = r_musteri.MUSTERI_NO
        and YIL = ln_yil
        and AY = ln_ay;

      select count(*)
      into ln_cnt2
      from CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      where CHARGE_CODE = 'ACCMAINFEE'
        and MUSTERI_NO = r_musteri.MUSTERI_NO
        and YIL = ln_yil
        and AY = ln_ay;

  if ln_cnt1 = 0 and ln_cnt2 = 0
  then
     ln_amnt := 0;
     ls_cy := null;
    ls_uygun := 'H';
    --
    select count(*)
    into ln_cnt
    from CBS_MUSTERI_ISLEM_MASRAF_FIX
    where musteri_no = r_musteri.musteri_no
      and islem_kodu = 7048
      and masraf_kodu = 'ACCMAINFEE';
    --
    if ln_cnt = 1
    then
     select nvl(TUTAR,0), DOVIZ
     into ln_amnt, ls_cy
     from CBS_MUSTERI_ISLEM_MASRAF_FIX
     where musteri_no = r_musteri.musteri_no
     and islem_kodu = 7048
     and masraf_kodu = 'ACCMAINFEE';
    else
     if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
     then
      ln_amnt := nvl(ln_amnt_ind,0);
      ls_cy := ls_cy_ind;
     end if;
     if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
     then
      ln_amnt := nvl(ln_amnt_corp,0);
      ls_cy := ls_cy_corp;
     end if;
    end if;
    --
    if nvl(ln_amnt,0) > 0 and ls_cy is not null
    then
     if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
     then
        -- B-O-M AdiletK 29082014 CQ944 - Altering the maintenance fee charging logic for individual customers       
      select nvl(company_of_the_staff, 0) 
      into ln_company_no 
      from cbs_musteri 
      where musteri_no = r_musteri.musteri_no;
      
      if ln_company_no <> 0 THEN
          ls_kod := '7047_ACC_MAINT_FEE_SALARY';
      else
          ls_kod := '7047_ACC_MAINT_FEE_NON_SALARY';        
      end if;
      
      select deger
      into ls_deger
      from cbs_parametre 
      where kod = ls_kod;
      
      if ls_deger = 'LOCAL' then
          select count(*)
          into ln_cnt
          from cbs_hesap
          where durum_kodu = 'A'
            and musteri_no = r_musteri.musteri_no
            and urun_tur_kod in ('CURRENT','DEMAND DEP')
            and doviz_kodu = pkg_genel.LC_al
            and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      elsif ls_deger = 'FOREIGN' then
          select count(*)
          into ln_cnt
          from cbs_hesap
          where durum_kodu = 'A'
            and musteri_no = r_musteri.musteri_no
            and urun_tur_kod in ('CURRENT','DEMAND DEP')
            and doviz_kodu <> pkg_genel.LC_al
            and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      else
          select count(*)
          into ln_cnt
          from cbs_hesap
          where durum_kodu = 'A'
            and musteri_no = r_musteri.musteri_no
            and urun_tur_kod in ('CURRENT','DEMAND DEP')
            and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      end if;
        -- E-O-M AdiletK 29082014 CQ944 - Altering the maintenance fee charging logic for individual customers   
      if ln_cnt > 0
      then
       ls_uygun := 'E';
      end if;
     end if;
     --
     if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
     then
      select count(*)
      into ln_cnt
      from cbs_hesap
      where durum_kodu = 'A'
        and musteri_no = r_musteri.musteri_no
        and urun_tur_kod in ('CURRENT','DEMAND DEP')
        and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      --
      if ln_cnt > 0
      then
       ls_uygun := 'E';
      end if;
     end if;
     --
     select count(*)
     into ln_cnt
     from CBS_MASRAF_DKGRUP_DK
     where MASRAF_KODU = 'ACCMAINFEE'
       and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

     if ln_cnt = 1
     then
      select DKHESAP_1
      into ls_dk
      from CBS_MASRAF_DKGRUP_DK
      where MASRAF_KODU = 'ACCMAINFEE'
        and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
     else
      raise dk_yok;
     end if;

     if ls_uygun = 'E' and ls_dk is not null
     then
      ln_counter := 0;

      select count(*)
      into ln_cnt
      from CBS_FEE_TAHSIL_EDILEN_ACCFEE
      where charge_code = 'ACCMAINFEE'
        and musteri_no = r_musteri.MUSTERI_NO
        and yil = ln_yil
        and ay = ln_ay;

      if ln_cnt > 0
      then
       select max(sira)
       into ln_sira
       from CBS_FEE_TAHSIL_EDILEN_ACCFEE
       where charge_code = 'ACCMAINFEE'
         and musteri_no = r_musteri.MUSTERI_NO
         and yil = ln_yil
         and ay = ln_ay;
      else
       ln_sira := 0;
      end if;

      ln_toplam_tahsil := 0;
      ln_kalan_tahsilat := ln_amnt;
      ln_hesaptan_al := 1;
 --
 ------------------------------------------------ SOM ---------------------------------------------
      OPEN c_hesap_som ;
      LOOP
       FETCH c_hesap_som INTO r_hesap_som  ;
       EXIT WHEN c_hesap_som%NOTFOUND;

        varchar_list(p_7048_ACC_BRANCH) := NULL;
        varchar_list(p_7048_TRAN_BRANCH) := NULL;
        varchar_list(p_7048_ACC) := NULL;
        varchar_list(p_7048_INCOME_GL) := NULL;
        varchar_list(p_7048_CY) := NULL;

        varchar_list(p_7048_EXPLAIN) := ls_7048_explanation||' : '||pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; --cbs-578 bahianab
        varchar_list(p_7048_TAX_EXPLAIN) := ls_7048_tax_explanation;  --cbs-578 bahianab

        number_list(p_7048_AMOUNT_FC):= 0;
        number_list(p_7048_AMOUNT_LC):= 0;
        number_list(p_7048_INCOME_LC):= 0; --cbs-578 bahianab
        number_list(p_7048_RATE) := 0 ;

        number_list(p_7048_TAX_FC):= 0;
        number_list(p_7048_TAX_LC):= 0;

        if ln_hesaptan_al = 1
        then
         ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := round((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
         ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

         ln_vergi_tl := round(((ln_masraf*ln_rate)/100),2);
         ln_vergi := ln_vergi_tl;
                  
         ln_toplam_masraf :=ln_masraf+ln_vergi; --cbs-578 bahianab
         --
         if ln_bakiye > 1 --cbs-578 bahianab --0
         then
          if ln_bakiye >= ln_toplam_masraf --cbs-578 bahianab--ln_masraf + ln_vergi
          then
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7048_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap_som.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap_som.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7048_AMOUNT_LC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7048_INCOME_LC) := ln_masraf; --cbs-578 bahianab
           number_list(p_7048_RATE) := 1;

           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     2,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       2,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,
            r_hesap_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'FULL',ln_islem_no, ln_fis_numara, ln_masraf,'ZAMANINDA');
          else
          --BOM cbs-578
           ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
           ln_vergi_tl := trunc(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
           ln_vergi := ln_vergi_tl;
           ln_toplam_masraf :=ln_muhasebelesecek_tutar+ln_vergi;
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM cbs-578

           varchar_list(p_7048_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap_som.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap_som.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7048_AMOUNT_LC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar; --cbs-578 bahianab
           number_list(p_7048_RATE) := 1;

                                           --YT 09032010
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     2,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       2,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara, ln_muhasebelesecek_tutar,'ZAMANINDA');
          end if;
         end if;  -- if ln_bakiye >= 0
        end if;
        --
        if ln_kalan_tahsilat = 0
        then
         ln_hesaptan_al := 0;
        end if;
      END LOOP;
      CLOSE c_hesap_som;

      if ln_kalan_tahsilat > 0
      then
       ln_hesaptan_al := 1;
 --
 -------------------------------------------- NON SOM --------------------------------------------
       OPEN c_hesap_non_som(ls_cy) ;
       LOOP
        FETCH c_hesap_non_som INTO r_hesap_non_som  ;
        EXIT WHEN c_hesap_non_som%NOTFOUND;

        varchar_list(p_7048_ACC_BRANCH) := NULL;
        varchar_list(p_7048_TRAN_BRANCH) := NULL;
        varchar_list(p_7048_ACC) := NULL;
        varchar_list(p_7048_INCOME_GL) := NULL;
        varchar_list(p_7048_CY) := NULL;

        varchar_list(p_7048_EXPLAIN) := ls_7048_explanation||' : '|| pkg_tx7047.month_name(ln_ay)|| ' / '|| ln_yil; --cbs-578 bahianab
        varchar_list(p_7048_TAX_EXPLAIN) := ls_7048_tax_explanation; --cbs-578 bahianab

        number_list(p_7048_AMOUNT_FC):= 0;
        number_list(p_7048_AMOUNT_LC):= 0;
        number_list(p_7048_INCOME_LC):= 0; --cbs-578 bahianab
        number_list(p_7048_RATE) := 0 ;

        number_list(p_7048_TAX_FC):=0;
        number_list(p_7048_TAX_LC):=0;

        if ln_hesaptan_al = 1
        then
         ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_kur_hesap_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)),2); --cbs-578 bahianab
         ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0)),2);

         ln_vergi_tl := round(((ln_masraf * ln_rate) / 100),2); --cbs-578 bahianab
         ln_vergi := ln_vergi_tl;
         
         ln_total_lc_amount := ln_masraf+ln_vergi; --cbs-578 bahianab
         ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); --cbs-578 bahianab
         --
         if ln_bakiye > 0
         then
          if ln_bakiye >= ln_total_fc_amount -- cbs-578 ln_masraf + ln_vergi
          then
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-578 bahianab
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7048_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap_non_som.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap_non_som.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_total_fc_amount;--cbs-578 bahianab--ln_masraf;
           number_list(p_7048_AMOUNT_LC) := ln_total_lc_amount;--cbs-578 bahianab--round((ln_tahsil_tutar*ln_kur_ucret_dvz),2);
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar;
           number_list(p_7048_RATE) := ln_kur_hesap_dvz;

           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
             r_hesap_non_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,'ZAMANINDA'); --cbs-578 bahianab ln_masraf
          else
          --BOM cbs-578
           ln_total_fc_amount := trunc((ln_bakiye-0.01),2); 
           ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); 
           ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+(ln_rate/100))),2); 
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM cbs-578

           varchar_list(p_7048_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap_non_som.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap_non_som.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_total_fc_amount;--cbs-578 bahianab--ln_muhasebelesecek_tutar;
           number_list(p_7048_AMOUNT_LC) := ln_total_lc_amount;--cbs-578 bahianab --round((number_list(p_7048_AMOUNT_FC)*ln_kur_hesap_dvz),2);
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar;--cbs-578 bahianab
           number_list(p_7048_RATE) := ln_kur_hesap_dvz;

                                           --YT 09032010
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); --cbs-578 bahianab

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
            r_hesap_non_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar, --cbs-578 bahianab
            'ZAMANINDA');
          end if;
         end if; -- if ln_bakiye >= 0
        end if;
        --
        if ln_kalan_tahsilat = 0
        then
         ln_hesaptan_al := 0;
        end if;
       END LOOP;
       CLOSE c_hesap_non_som;
      end if;

      select count(*)
      into ln_cnt
      from CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      where CHARGE_CODE = 'ACCMAINFEE'
        and yil = ln_yil
        and ay = ln_ay
        and musteri_no = r_musteri.MUSTERI_NO;

      if ln_cnt > 0
      then
          raise double_run_2;
      end if;

      if ln_kalan_tahsilat > 0
      then
       insert into CBS_FEE_TAH_EDILEMEYEN_ACCFEE
        (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
         TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
       values
       ('ACCMAINFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
        ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
      end if;

      IF ln_counter>0 THEN
       Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      END IF;
     end if; --if ls_uygun = 'E' and ls_dk is not null
    end if;
   COMMIT; 
    end if;
  END LOOP;
  CLOSE c_musteri;
 --end if; -- End Of Month

 commit;
   
 --Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 EXCEPTION
  when double_run_1 then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

   --  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  when double_run_2 then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     --Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  when birden_fazla_parametre_var then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
   --Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  when dk_yok then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
   -- Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
   log_at('ACC_MAINTENANCE_FEE',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);
   --Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
/************************************************************************************/
/* Sevalb 01.10.2012 27342 -Account maintenance fee for September
ACC_MAINTENANCE_FEE_CUST is created as autonomous and ACC_MAINTENANCE_FEE main procedure willbe calling sub -proc.
/************************************************************************************/
procedure ACC_MAINTENANCE_FEE(pn_grup_no number, pn_log_no number,ps_program_kod varchar2 )
is
    ls_mesaj                        varchar2(2000):= '';
  cursor cur_musteri is
        select  musteri_no,dk_grup_kod, bolum_kodu
        from cbs_musteri
        where durum_kodu = 'A'
          and musteri_tipi_kod in ('1','2','3')
          and hesap_ucreti_f = 'E'
          and musteri_no not in (select distinct musteri_no
                                 from cbs_musteri_islem_masraf_muaf
                                 where islem_kodu = 7048
                                   and masraf_kodu = 'ACCMAINFEE')
          and musteri_no not in (select customer_no
                                 from cbs_customer_fee)         
        order by musteri_no ;

  r_musteri  cur_musteri%rowtype;
 pd_banka_tarihi date :=pkg_muhasebe.Banka_Tarihi_Bul;
  begin

 --if pkg_dates.get_last_work_day_in_month(pd_banka_tarihi) = pkg_muhasebe.Banka_Tarihi_Bul
 --then --EOM
    pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
        for c_musteri in cur_musteri loop 
          r_musteri := c_musteri;  
          acc_maintenance_fee_cust(pn_grup_no , pn_log_no ,ps_program_kod ,r_musteri.musteri_no ,pd_banka_tarihi );
        end loop; 
                
    commit;
 --end if;

   pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 exception
   when no_data_found then null ;
    when others then
      rollback;  
      ls_mesaj := 'General Error ' || to_char(sqlcode) || ' ' || sqlerrm ;
      pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_mesaj);      
 end;
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE STATEMENT_FEE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list             Pkg_Muhasebe.number_array;
    date_list               Pkg_Muhasebe.date_array; 
    boolean_list            Pkg_Muhasebe.boolean_array;

 ln_fis_numara              NUMBER;
 ln_counter                 NUMBER;
 ln_temp_numara             NUMBER;

 p_7049_ACC_BRANCH          NUMBER;
 p_7049_TRAN_BRANCH         NUMBER;
 p_7049_ACC                 NUMBER;
 p_7049_INCOME_GL           NUMBER;
 p_7049_CY                  NUMBER;
 p_7049_EXPLAIN             NUMBER;
 p_7049_AMOUNT_FC           NUMBER;
 p_7049_AMOUNT_LC           NUMBER;
 p_7049_INCOME_LC           NUMBER; --cbs-578 bahianab
 p_7049_RATE                NUMBER;

 p_7049_TAX_FC              NUMBER;
 p_7049_TAX_LC              NUMBER;
 p_7049_TAX_EXPLAIN         NUMBER;

    CURSOR c_musteri IS
        SELECT  MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
        FROM CBS_MUSTERI
        WHERE DURUM_KODU = 'A'
          AND EKSTRE_UCRETI_ALINSIN = 'E'
          AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
                                 FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
                                 WHERE ISLEM_KODU = 7049
                                 AND MASRAF_KODU = 'STATMNTFEE')
        AND MUSTERI_NO NOT IN (SELECT customer_no
                               FROM CBS_CUSTOMER_FEE)
        ORDER BY musteri_no ;

  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ld_bas                     DATE;
 ld_son                     DATE;
 ln_yil                     NUMBER;
 ln_ay                      NUMBER;
     ln_cnt                 NUMBER;

 ln_kur_ucret_dvz           NUMBER;
 ln_kur_hesap_dvz           NUMBER;
 ln_masraf                  NUMBER;
 ln_bakiye                  NUMBER;
 ln_amnt                    NUMBER;
 ls_cy                      VARCHAR2(3);
 ls_uygun                   VARCHAR2(1);
 ln_sira                    NUMBER;

 ln_toplam_tahsil           NUMBER;
 ln_kalan_tahsilat          NUMBER;
 ln_hesaptan_al             NUMBER;
 ln_muhasebelesecek_tutar   NUMBER;
 ln_tahsil_tutar            NUMBER;
 ln_kal                     NUMBER;
 ln_islem_no                NUMBER := 0;
 ls_dk                      VARCHAR2(30);
 ln_ekstre_sikligi          NUMBER;
 ln_toplam_masraf           NUMBER; --cbs-578 bahianab
 ln_total_lc_amount         NUMBER; --cbs-578 bahianab 
 ln_total_fc_amount         NUMBER; --cbs-578 bahianab 
 ln_fc_tahsil_tutar         NUMBER; --cbs-578 bahianab
 ls_7049_explanation        VARCHAR2(200); --cbs-578 bahianab
 ls_7049_tax_explanation    VARCHAR2(200); --cbs-578 bahianab

 double_run_1               EXCEPTION;
 double_run_2               EXCEPTION;
 parametre_yok              EXCEPTION;
 birden_fazla_parametre_var EXCEPTION;
 dk_yok                     EXCEPTION;
 ln_rate                    NUMBER;
 ln_vergi                   NUMBER;
 ln_vergi_tl                NUMBER;
 ln_cnt1                    NUMBER;
 ln_cnt2                    NUMBER;
 
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 
 IF pkg_dates.get_last_work_day_in_month(pkg_muhasebe.Banka_Tarihi_Bul) = pkg_muhasebe.Banka_Tarihi_Bul
 THEN --EOM
  Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
  Pkg_Parametre.deger('SF_EXPLANATION',ls_7049_explanation);--cbs-578 bahianab
  Pkg_Parametre.deger('SF_TAX_EXPLANATION',ls_7049_tax_explanation);--cbs-578 bahianab

  p_7049_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7049_ACC_BRANCH');
  p_7049_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7049_TRAN_BRANCH');
  p_7049_ACC :=Pkg_Muhasebe.parametre_index_bul('7049_ACC');
  p_7049_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7049_INCOME_GL');
  p_7049_CY :=Pkg_Muhasebe.parametre_index_bul('7049_CY');
  p_7049_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7049_EXPLAIN');

  p_7049_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7049_AMOUNT_FC');
  p_7049_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7049_AMOUNT_LC');
  p_7049_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7049_INCOME_LC'); --cbs-578 bahianab
  p_7049_RATE :=Pkg_Muhasebe.parametre_index_bul('7049_RATE');

  p_7049_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_FC');
  p_7049_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_LC');
  p_7049_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_EXPLAIN');

  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'STATMNTFEE'
    AND CUSTOMER_TYPE = 'INDIVIDUAL';
  IF ln_cnt = 0
  THEN
   RAISE parametre_yok;
  END IF;
  --
  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'STATMNTFEE'
    AND CUSTOMER_TYPE = 'CORPORATE';
  IF ln_cnt = 0
  THEN
   RAISE parametre_yok;
  END IF;
  --
  ld_bas := TO_DATE(TO_CHAR(LTRIM(RTRIM('01'||TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'MMYYYY')))),'DD.MM.YYYY');
  ld_son := LAST_DAY(pkg_muhasebe.banka_tarihi_bul);
  ln_yil := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY'));
  ln_ay := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM'));
  --
  OPEN c_musteri ;
  LOOP
   FETCH c_musteri INTO r_musteri  ;
   EXIT WHEN c_musteri%NOTFOUND;
      SELECT COUNT(*)
      INTO ln_cnt1
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE CHARGE_CODE = 'STATMNTFEE'
        AND MUSTERI_NO = r_musteri.MUSTERI_NO
        AND YIL = ln_yil
        AND AY = ln_ay;

      SELECT COUNT(*)
      INTO ln_cnt2
      FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      WHERE CHARGE_CODE = 'STATMNTFEE'
        AND MUSTERI_NO = r_musteri.MUSTERI_NO
        AND YIL = ln_yil
        AND AY = ln_ay;

  IF ln_cnt1 = 0 AND ln_cnt2 = 0
  THEN
     ln_amnt := 0;
     ls_cy := NULL;
    ls_uygun := 'H';
    --
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_HESAP
    WHERE durum_kodu = 'A'
      AND musteri_no = r_musteri.musteri_no
      AND EKSTRE_SIKLIGI IS NOT NULL
      AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
      AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
    --
    IF ln_cnt > 0
    THEN
     ls_uygun := 'E';
    END IF;
    --
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = 'ACCSTMNFEE'
      AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = 'ACCSTMNFEE'
       AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_uygun = 'E' AND ls_dk IS NOT NULL
    THEN
     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
     WHERE musteri_no = r_musteri.musteri_no
       AND islem_kodu = 7049
       AND masraf_kodu = 'STATMNTFEE';
     --
     IF ln_cnt = 1
     THEN
      SELECT NVL(TUTAR,0), DOVIZ
      INTO ln_amnt, ls_cy
      FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
      WHERE musteri_no = r_musteri.musteri_no
      AND islem_kodu = 7049
      AND masraf_kodu = 'STATMNTFEE';
     ELSE
      SELECT MIN(EKSTRE_SIKLIGI)
      INTO ln_ekstre_sikligi
      FROM CBS_HESAP
      WHERE durum_kodu = 'A'
        AND musteri_no = r_musteri.musteri_no
        AND EKSTRE_SIKLIGI IS NOT NULL
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
        AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      --
      IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
      THEN
       SELECT COUNT(*)
       INTO ln_cnt
       FROM CBS_MASRAF_KRITERLERI
       WHERE CHARGE_CODE = 'STATMNTFEE'
         AND CUSTOMER_TYPE = 'INDIVIDUAL'
         AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       IF ln_cnt = 1
       THEN
        SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
        INTO ln_amnt,ls_cy
        FROM CBS_MASRAF_KRITERLERI
        WHERE CHARGE_CODE = 'STATMNTFEE'
          AND CUSTOMER_TYPE = 'INDIVIDUAL'
          AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       ELSE
        RAISE birden_fazla_parametre_var;
       END IF;
      END IF;
      --
      IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
      THEN
       SELECT COUNT(*)
       INTO ln_cnt
       FROM CBS_MASRAF_KRITERLERI
       WHERE CHARGE_CODE = 'STATMNTFEE'
         AND CUSTOMER_TYPE = 'CORPORATE'
         AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       IF ln_cnt = 1
       THEN
        SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
        INTO ln_amnt,ls_cy
        FROM CBS_MASRAF_KRITERLERI
        WHERE CHARGE_CODE = 'STATMNTFEE'
          AND CUSTOMER_TYPE = 'CORPORATE'
          AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       ELSE
        RAISE birden_fazla_parametre_var;
       END IF;
      END IF;
     END IF;
     --
     IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
     THEN
      ln_counter := 0;

      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = 'STATMNTFEE'
        AND musteri_no = r_musteri.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;

      IF ln_cnt > 0
      THEN
       SELECT MAX(sira)
       INTO ln_sira
       FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
       WHERE charge_code = 'STATMNTFEE'
         AND musteri_no = r_musteri.MUSTERI_NO
         AND yil = ln_yil
         AND ay = ln_ay;
      ELSE
       ln_sira := 0;
      END IF;

      ln_toplam_tahsil := 0;
      ln_kalan_tahsilat := ln_amnt;
      ln_hesaptan_al := 1;
 --
 ------------------------------------------------ SOM ---------------------------------------------
      OPEN c_hesap_som ;
      LOOP
       FETCH c_hesap_som INTO r_hesap_som  ;
       EXIT WHEN c_hesap_som%NOTFOUND;

        varchar_list(p_7049_ACC_BRANCH) := NULL;
        varchar_list(p_7049_TRAN_BRANCH) := NULL;
        varchar_list(p_7049_ACC) := NULL;
        varchar_list(p_7049_INCOME_GL) := NULL;
        varchar_list(p_7049_CY) := NULL;

        varchar_list(p_7049_TAX_EXPLAIN) := ls_7049_tax_explanation; --cbs-578 bahianab
        varchar_list(p_7049_EXPLAIN) := ls_7049_explanation||' : '|| pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; --cbs-578 bahianab

        number_list(p_7049_AMOUNT_FC):= 0;
        number_list(p_7049_AMOUNT_LC):= 0;
        number_list(p_7049_INCOME_LC):= 0; --cbs-578 bahianab 
        number_list(p_7049_RATE) := 0 ;

        number_list(p_7049_TAX_FC):=0;
        number_list(p_7049_TAX_LC):=0;

        IF ln_hesaptan_al = 1
        THEN
         ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := ROUND((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
         ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

         ln_vergi_tl := ROUND(((ln_masraf*ln_rate)/100),2);
         ln_vergi := ln_vergi_tl;
         
         ln_toplam_masraf := ln_masraf+ln_vergi; --cbs-578 bahianab
         
         --
         IF ln_bakiye > 1 --cbs-578 bahianab --0
         THEN
          IF ln_bakiye >= ln_masraf + ln_vergi
          THEN
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7049_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap_som.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap_som.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_toplam_masraf ; --cbs-578 bahianab
           number_list(p_7049_AMOUNT_LC) := ln_toplam_masraf ; --cbs-578 bahianab
           number_list(p_7049_INCOME_LC) := ln_masraf;--cbs-578 bahianab
           number_list(p_7049_RATE) := 1;

           number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
           
           log_at('sf_1',ln_toplam_masraf||'-toplam masraf',ln_masraf ||'-masraf',ln_vergi ||'-vergi');

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     2,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       2,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;

           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           VALUES
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,
            r_hesap_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'FULL',ln_islem_no, ln_fis_numara,ln_masraf,'ZAMANINDA');
          ELSE
          --BOM CBS-578
           ln_muhasebelesecek_tutar := TRUNC(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
           ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
           ln_vergi := ln_vergi_tl;
           ln_toplam_masraf := ln_muhasebelesecek_tutar+ln_vergi;
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM CBS-578
                      
           varchar_list(p_7049_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap_som.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap_som.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7049_AMOUNT_LC) := ln_toplam_masraf; --cbs-578 bahianab
           number_list(p_7049_INCOME_LC) := ln_tahsil_tutar; --cbs-578 bahianab
           number_list(p_7049_RATE) := 1;

           number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
           number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
           
           log_at('sf_2',ln_toplam_masraf||'-toplam masraf',ln_masraf ||'-masraf',ln_vergi ||'-vergi');

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     2,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation); --cbs-578 bahianab
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       2,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           VALUES
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
          END IF;
         END IF;  -- if ln_bakiye >= 0
        END IF;
        --
        IF ln_kalan_tahsilat = 0
        THEN
         ln_hesaptan_al := 0;
        END IF;
      END LOOP;
      CLOSE c_hesap_som;

      IF ln_kalan_tahsilat > 0
      THEN
       ln_hesaptan_al := 1;
 --
 -------------------------------------------- NON SOM --------------------------------------------
       OPEN c_hesap_non_som(ls_cy) ;
       LOOP
        FETCH c_hesap_non_som INTO r_hesap_non_som  ;
        EXIT WHEN c_hesap_non_som%NOTFOUND;

         varchar_list(p_7049_ACC_BRANCH) := NULL;
         varchar_list(p_7049_TRAN_BRANCH) := NULL;
         varchar_list(p_7049_ACC) := NULL;
         varchar_list(p_7049_INCOME_GL) := NULL;
         varchar_list(p_7049_CY) := NULL;

         varchar_list(p_7049_TAX_EXPLAIN) := ls_7049_tax_explanation; --cbs-578 bahianab
         varchar_list(p_7049_EXPLAIN) := ls_7049_explanation||' : '||pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; --cbs-578 bahianab
         
         number_list(p_7049_AMOUNT_FC):= 0;
         number_list(p_7049_AMOUNT_LC):= 0;
         number_list(p_7049_INCOME_LC):= 0; --cbs-578 bahianab
         number_list(p_7049_RATE) := 0 ;

         number_list(p_7049_TAX_FC):=0;
         number_list(p_7049_TAX_LC):=0;

         IF ln_hesaptan_al = 1
         THEN
          ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
          ln_kur_hesap_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
          ln_masraf := ROUND((ln_kalan_tahsilat * ln_kur_ucret_dvz),2); --cbs-578 bahianab
          ln_bakiye := TRUNC(NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0),2);

          ln_vergi_tl := ROUND(((ln_masraf * ln_rate) / 100),2); --cbs-578 bahianab
          ln_vergi := ln_vergi_tl; --cbs-578 bahianab
          
          ln_total_lc_amount := ln_masraf+ln_vergi; --cbs-578 bahianab
          ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); --cbs-578 bahianab
          --
          IF ln_bakiye > 0
          THEN
           IF ln_bakiye >= ln_total_fc_amount--cbs-578 bahianab
           THEN
            ln_tahsil_tutar := ln_kalan_tahsilat;
            ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-578 bahianab
            ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
            ln_kal := ln_kalan_tahsilat;
            ln_kalan_tahsilat := 0;

            varchar_list(p_7049_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
            varchar_list(p_7049_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
            varchar_list(p_7049_ACC) := r_hesap_non_som.hesap_no;
            varchar_list(p_7049_INCOME_GL) := ls_dk;
            varchar_list(p_7049_CY) := r_hesap_non_som.DOVIZ_KODU;

            number_list(p_7049_AMOUNT_FC) := ln_total_fc_amount ; --cbs-578 bahianab
            number_list(p_7049_AMOUNT_LC) := ln_total_lc_amount; --cbs-578 bahianab
            number_list(p_7049_INCOME_LC) := ln_tahsil_tutar;--cbs-578 bahianab
            number_list(p_7049_RATE) := ln_kur_hesap_dvz;

            number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2);--cbs-578 bahianab
            number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2);--cbs-578 bahianab
            
            log_at('sf_3',ln_total_fc_amount||'-total fc',ln_total_lc_amount ||'-total lc',ln_tahsil_tutar ||'-income');

            IF ln_counter = 0
            THEN
             ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

             ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                      1,
                      ln_islem_no,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list ,
                      NULL,
                      FALSE,
                      0,
                      ls_7049_explanation); --cbs-578 bahianab
            ELSE
             ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                        1,
                        ln_fis_numara,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        NULL,
                        FALSE);
            END IF;
            ln_counter:=ln_counter+1;
            --
            ln_sira := ln_sira + 1 ;
            INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
            (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
             TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
             STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
             TAHSIL_ZAMANI)
            VALUES
            ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
             r_hesap_non_som.DOVIZ_KODU,
             ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
              'FULL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'ZAMANINDA'); --cbs-578 bahianab
           ELSE
            --EOM
            ln_total_fc_amount := trunc((ln_bakiye-0.01),2);
            ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2);
            ln_muhasebelesecek_tutar := TRUNC((ln_total_lc_amount/(1+(ln_rate/100))),2);
            ln_tahsil_tutar := ln_muhasebelesecek_tutar;
            ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
            ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
            ln_kal := ln_kalan_tahsilat;
            ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
            --BOM
            
            varchar_list(p_7049_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
            varchar_list(p_7049_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
            varchar_list(p_7049_ACC) := r_hesap_non_som.hesap_no;
            varchar_list(p_7049_INCOME_GL) := ls_dk;
            varchar_list(p_7049_CY) := r_hesap_non_som.DOVIZ_KODU;

            number_list(p_7049_AMOUNT_FC) := ln_total_fc_amount; --cbs-578 bahianab
            number_list(p_7049_AMOUNT_LC) := ln_total_lc_amount; --cbs-578 bahianab
            number_list(p_7049_INCOME_LC) := ln_tahsil_tutar; --cbs-578 bahianab
            number_list(p_7049_RATE) := ln_kur_hesap_dvz;

            number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
            number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --cbs-578 bahianab
            
            log_at('sf_4',ln_total_fc_amount||'-total fc',ln_total_lc_amount ||'-total lc',ln_tahsil_tutar ||'-income');

            IF ln_counter = 0 THEN
             ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

             ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                      1,
                      ln_islem_no,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list ,
                      NULL,
                      FALSE,
                      0,
                      ls_7049_explanation); --cbs-578 bahianab
            ELSE
             ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                        1,
                        ln_fis_numara,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        NULL,
                        FALSE);
            END IF;
            ln_counter:=ln_counter+1;
            --
            ln_sira := ln_sira + 1 ;
            INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
            (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
             TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
             STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
             TAHSIL_ZAMANI)
            VALUES
            ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
             r_hesap_non_som.DOVIZ_KODU,
             ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
              'PARTIAL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar, --cbs-578 bahianab
              'ZAMANINDA');
           END IF;
          END IF; -- if ln_bakiye >= 0
         END IF;
         --
         IF ln_kalan_tahsilat = 0
         THEN
          ln_hesaptan_al := 0;
         END IF;
       END LOOP;
       CLOSE c_hesap_non_som;
      END IF;

      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      WHERE CHARGE_CODE = 'STATMNTFEE'
        AND yil = ln_yil
        AND ay = ln_ay
        AND musteri_no = r_musteri.MUSTERI_NO;

      IF ln_cnt > 0
      THEN
          RAISE double_run_2;
      END IF;

      IF ln_kalan_tahsilat > 0
      THEN
       INSERT INTO CBS_FEE_TAH_EDILEMEYEN_ACCFEE
        (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
         TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
       VALUES
       ('STATMNTFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
        ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
      END IF;

      IF ln_counter>0 THEN
       Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      END IF;
     END IF; --if ls_uygun = 'E' and ls_dk is not null
    END IF;
   COMMIT;
    END IF;
  END LOOP;
  CLOSE c_musteri;
 END IF; -- End Of Month
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);


 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||'STATMNTFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||'STATMNTFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5126'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5127'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
 -----------------------------------------------------------------------------------------
PROCEDURE LINE_BALANCE_UPDATE (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

    varchar_list  Pkg_Muhasebe.varchar_array;
    number_list   Pkg_Muhasebe.number_array;
    date_list   Pkg_Muhasebe.date_array;
    boolean_list  Pkg_Muhasebe.boolean_array;
    ln_counter   NUMBER:=0;
    ln_fis_numara  CBS_FIS.numara%TYPE;
    ln_islem_numara  CBS_ISLEM.numara%TYPE;
    ln_islem_kod  NUMBER:=8510;
    ls_fis_aciklama  VARCHAR2(2000);
    pn_8510_LIMIT_SUBE   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_LIMIT_SUBE');
    pn_8510_LC_TUTAR     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_LC_TUTAR');
    pn_8510_FC_TUTAR     NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_FC_TUTAR');
    pn_8510_KUR        NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_KUR');
    pn_8510_DOVIZ  NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_DOVIZ');
    pn_8510_B_ACIKLAMA   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_B_ACIKLAMA');
    pn_8510_M_ACIKLAMA   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_M_ACIKLAMA');
    pn_8510_REVIZYON_PERIYOD_BUYUK   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_REVIZYON_PERIYOD_BUYUK');
    pn_8510_REVIZYON_PERIYOD_KUCUK   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_REVIZYON_PERIYOD_KUCUK');
 pn_8510_LINE_BAKIYE_BUYUK   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_LINE_BAKIYE_BUYUK');
 pn_8510_LINE_BAKIYE_KUCUK   NUMBER :=Pkg_Muhasebe.parametre_index_bul('8510_LINE_BAKIYE_KUCUK');

 cursor cur_limit is
 SELECT  b.musteri_no,
   b.fc_doviz_kodu,
   b.LINE_AMOUNT,
   b.LINE_BAKIYESI line_bakiyesi,
   nvl(b.line_amount,0) -  NVL((  select sum(pkg_kur.yuvarla(b.fc_doviz_kodu,pkg_kur.doviz_doviz_karsilik(a.fc_doviz_kodu,b.fc_doviz_kodu,null,nvl(a.fc_risk,0),1,null,null,'N','A'))) line_risk
              from cbs_musteri_urun_limit a
           where a.musteri_no = b.musteri_no and
             line = 'YES' ),0) kull_limit,
   b.limit_revizyon_periyodu,
   pkg_kredi.sf_teklif_bolum_kodu_al(b.musteri_no) islem_sube
   from cbs_musteri_limit b
   where  nvl(b.line_bakiyesi,0) <> ( nvl(b.line_amount,0) -  NVL(( select sum(pkg_kur.yuvarla(b.fc_doviz_kodu,pkg_kur.doviz_doviz_karsilik(a.fc_doviz_kodu,b.fc_doviz_kodu,null,nvl(a.fc_risk,0),1,null,null,'N','A'))) line_risk
                                from cbs_musteri_urun_limit a
                    where a.musteri_no = b.musteri_no and
                       line = 'YES'  ),0) )
          and b.musteri_no in (select c.musteri_no from cbs_musteri c)       --sevalb 04072012 SDLC26142 
          and   pkg_kredi.sf_teklif_bolum_kodu_al(b.musteri_no) is not null   --sevalb 04072012 SDLC26142   
     for update of line_Bakiyesi;
    ln_kull_limit  number := 0;
  BEGIN

 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
   -- sevalb 210607 line amount limit degisiklikleri asagidaki cursor yukarida eklenen cur_limit ile degistirildi.
    /*FOR i IN (SELECT a.rowid,musteri_no,fc_doviz_kodu,nvl(fc_limit,0)-nvl(fc_risk,0) kull_limit,line_bakiyesi,
                  limit_revizyon_periyodu,pkg_kredi.sf_teklif_bolum_kodu_al(musteri_no) islem_sube
          FROM cbs_musteri_limit a
            WHERE line_bakiyesi is not null
                 AND line_bakiyesi != nvl(fc_limit,0)-nvl(fc_risk,0)) LOOP
 */
 for i in cur_limit loop
  ln_kull_limit := i.kull_limit ;

     ln_islem_numara := Pkg_Batch.islem_yarat(ln_islem_kod,i.islem_sube);
        ln_counter      := ln_counter + 1;
        varchar_list(pn_8510_LIMIT_SUBE) := i.islem_sube;
        varchar_list(pn_8510_DOVIZ)      := i.fc_doviz_kodu;
        number_list(pn_8510_FC_TUTAR)    := ABS(i.kull_limit - i.line_bakiyesi);
        number_list(pn_8510_LC_TUTAR)    := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,
                                            Pkg_Kur.mb_dak_to_lc(i.fc_doviz_kodu,number_list(pn_8510_FC_TUTAR)));
        number_list(pn_8510_KUR)         := Pkg_Kur.doviz_doviz_karsilik(i.fc_doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
        ls_fis_aciklama                  := 'LINE BALANCE UPDATE CUSTOMER No:'||to_char(i.musteri_no)||' CURRENCY:'||i.fc_doviz_kodu;
        varchar_list(pn_8510_B_ACIKLAMA) := ls_fis_aciklama;
        varchar_list(pn_8510_M_ACIKLAMA) := ls_fis_aciklama;
  if nvl(i.limit_revizyon_periyodu,'X') = '>1 YEAR' then
          boolean_list(pn_8510_REVIZYON_PERIYOD_BUYUK) := TRUE;
          boolean_list(pn_8510_REVIZYON_PERIYOD_KUCUK) := FALSE;
        else
          boolean_list(pn_8510_REVIZYON_PERIYOD_KUCUK) := TRUE;
          boolean_list(pn_8510_REVIZYON_PERIYOD_BUYUK) := FALSE;
        end if;
  if i.kull_limit < i.line_bakiyesi then
          boolean_list(pn_8510_LINE_BAKIYE_BUYUK) := TRUE;
          boolean_list(pn_8510_LINE_BAKIYE_KUCUK) := FALSE;
        else
          boolean_list(pn_8510_LINE_BAKIYE_KUCUK) := TRUE;
          boolean_list(pn_8510_LINE_BAKIYE_BUYUK) := FALSE;
        end if;
        ln_fis_numara:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
           null,
            ln_islem_numara,
         varchar_list ,
         number_list  ,
         date_list    ,
         boolean_list ,
         NULL,
         FALSE,
            0,
         ls_fis_aciklama);

        UPDATE cbs_musteri_limit
  SET line_bakiyesi = nvl(ln_kull_limit,0) --sevalb 210607
  WHERE current of cur_limit;

        Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);

       -- Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);

     if nvl(ln_fis_numara,0) <> 0 then
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'1009'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_numara)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
  end if;

     END LOOP;
 commit;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod,ln_islem_numara);

  EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK; --sevalb 04072012 SDLC26142 
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM,ln_islem_numara);
  END;
 -----------------------------------------------------------------------------------------
PROCEDURE EOD_MUHASEBE_BIRIKTIR_BASLA(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
  BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  UPDATE CBS_SYSTEM
     SET eod_muhasebe = 'E';
     COMMIT;
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
   ROLLBACK;
     Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
  END;
 -----------------------------------------------------------------------------------------
PROCEDURE EOD_MUHASEBE_BIRIKTIR_BITIR(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
  BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  UPDATE CBS_SYSTEM
     SET eod_muhasebe = 'H';
     COMMIT;
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
   ROLLBACK;
     Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
  END;
 -----------------------------------------------------------------------------------------
PROCEDURE EOD_MUH_FISLERI_MUHASEBELESTIR(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
  CURSOR c_1 IS
    SELECT * FROM CBS_EOD_FIS_NO
  WHERE durum = 'A'
  ORDER BY fis_numara;
   ld_date date;
   ln_fis_no number;
   ln_cnt  number :=0 ;
   p_eod varchar2(1) := 'H' ;
   eod_muhasebe_biriktir    exception;
   atm_tarihi_buyuk_var     exception;
  BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    ld_date := Pkg_Muhasebe.banka_tarihi_bul;
    -- b-o-m seval.colak 04062021 kontroller eklendi.
     select count(*)
     into ln_cnt
     from cbs_atm_parametre
     where terminal_tipi = 'ATM' and 
            atm_tarihi > pkg_muhasebe.banka_tarihi_bul;
      if ln_cnt > 0 then 
        raise atm_tarihi_buyuk_var;
      end if;
            
     select eod_muhasebe into p_eod from cbs_system;
     if p_eod = 'E' then 
        raise eod_muhasebe_biriktir ;
     end if;
    --e-o-m seval.colak 04062021 kontroller eklendi.     
    
  FOR r_1 IN c_1 LOOP
  ln_fis_no := r_1.fis_numara;
  
    UPDATE CBS_FIS
       SET gecerli_oldugu_tarih = ld_date
  WHERE numara = r_1.fis_numara;

    UPDATE CBS_SATIR s
       SET s.valor_tarihi = Pkg_Tarih.ileri_is_gunu(s.valor_tarihi)
  WHERE s.fis_numara = r_1.fis_numara;
  
     --b-o-m seval.colak 04062021 
      UPDATE CBS_HESAP_BAKIYE T
      SET    T.bakiye_karakteri = lower(t.bakiye_karakteri) 
      WHERE  T.hesap_no in (select hesap_numara from CBS_SATIR s WHERE s.fis_numara = r_1.fis_numara  and hesap_tur_kodu = 'VS') ;
    --e-o-m seval.colak 04062021
  
      Pkg_Muhasebe.muhasebelestir(r_1.fis_numara);
      
      --b-o-m seval.colak 04062021
      UPDATE CBS_HESAP_BAKIYE T
      SET    T.bakiye_karakteri = upper(t.bakiye_karakteri) 
      WHERE  T.hesap_no in (select hesap_numara from CBS_SATIR s WHERE s.fis_numara = r_1.fis_numara  and hesap_tur_kodu = 'VS') ;
      --e-o-m seval.colak 04062021

      UPDATE CBS_EOD_FIS_NO
         SET durum = 'K',
             fis_tarih = ld_date
       WHERE fis_numara = r_1.fis_numara;
       
      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'EOD Accounting is done for journal No:' ||r_1.fis_numara);
    commit;
    
    END LOOP;
    COMMIT;
    
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
    
  EXCEPTION
   -- b-o-m seval.colak 04062021 kontroller eklendi.
    when atm_tarihi_buyuk_var then
        Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6830' || Pkg_Hata.getdelimiter || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) );
    when eod_muhasebe_biriktir then
        Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6831' || Pkg_Hata.getdelimiter || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer)  );
         -- e-o-m seval.colak 04062021 kontroller eklendi. 
    WHEN OTHERS THEN
     ROLLBACK;
      Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,'r_1.fis_numara:'||ln_fis_no|| ',' ||substr(TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM),1,1900) );
  END;

-- B-O-M seval.colak 04062021 asagidaki kisim kapatilacak ,yukaridaki original procedure bakiye karakteri ilavesi yapilip acilacak.
/*
PROCEDURE EOD_MUH_FISLERI_MUHASEBELESTIR(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
  CURSOR c_1 IS
    SELECT * FROM CBS_EOD_FIS_NO
  WHERE durum = 'A'
  ORDER BY fis_numara;
   ld_date DATE;
   ln_account    NUMBER;
   ls_bakiye_karakteri   VARCHAR2(1);
  BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
  ld_date := Pkg_Muhasebe.banka_tarihi_bul;
  FOR r_1 IN c_1 LOOP
    UPDATE CBS_FIS
       SET gecerli_oldugu_tarih = ld_date
  WHERE numara = r_1.fis_numara;

    UPDATE CBS_SATIR s
       SET s.valor_tarihi = Pkg_Tarih.ileri_is_gunu(s.valor_tarihi)
  WHERE s.fis_numara = r_1.fis_numara;

  BEGIN
   Pkg_Muhasebe.muhasebelestir(r_1.fis_numara);
   EXCEPTION
   WHEN OTHERS THEN
log_at('hakan_eod_muh_001','SQLERRM',SQLERRM);
    IF SQLERRM LIKE '%ORA-20100: ***1126###ORA-20100: ***1487###%'
    THEN
     BEGIN

     ROLLBACK ; -- SEVALB 11032011  rollback edilmediginden DK_BAKIYE guncelle 2 kere guncelleme yapmis oluyordu.Balance satir farkina yol aciyordu 15885 "Disbalance on ATM GL

-- ORA-20100: ***1126###ORA-20100: ***1487###104365******
      ln_account := 0;
      ln_account := TO_NUMBER(SUBSTR(SQLERRM,
                       INSTR(SQLERRM,'1487')+7,
                    6));

log_at('hakan_eod_muh_002','ln_account',ln_account);
    --b-o-m sevalb 14032011
      UPDATE CBS_FIS
           SET gecerli_oldugu_tarih = ld_date
      WHERE numara = r_1.fis_numara;

        UPDATE CBS_SATIR s
           SET s.valor_tarihi = Pkg_Tarih.ileri_is_gunu(s.valor_tarihi)
      WHERE s.fis_numara = r_1.fis_numara;
    -- e-o-m sevalb 14032011
      SELECT bakiye_karakteri
      INTO ls_bakiye_karakteri
      FROM CBS_HESAP_BAKIYE T
      WHERE  T.hesap_no = ln_account;

      UPDATE CBS_HESAP_BAKIYE T
      SET    T.bakiye_karakteri = 'H'
      WHERE  T.hesap_no = ln_account;

      Pkg_Muhasebe.muhasebelestir(r_1.fis_numara);

      UPDATE CBS_HESAP_BAKIYE T
      SET    T.bakiye_karakteri = ls_bakiye_karakteri
      WHERE  T.hesap_no = ln_account;

      EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
          Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
     END;
    ELSE
     ROLLBACK;
     Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
    END IF;
  END;

  UPDATE CBS_EOD_FIS_NO
     SET durum = 'K',
         fis_tarih = ld_date
   WHERE fis_numara = r_1.fis_numara;
  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'EOD Accounting is done for journal No:' ||r_1.fis_numara);
  COMMIT;
  END LOOP;
     COMMIT;
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
   ROLLBACK;
     Pkg_Batch.hata_logla(pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
  END;
  */
  -- E-O-M seval.colak 04062021
-----------------------------------------------------------------------------------------

PROCEDURE INTERNET_MAINTENANCE_FEE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara   NUMBER;
 ln_counter   NUMBER;
 ln_temp_numara   NUMBER;

 p_7050_ACC_BRANCH         NUMBER;
 p_7050_TRAN_BRANCH             NUMBER;
 p_7050_ACC            NUMBER;
 p_7050_INCOME_GL             NUMBER;
 p_7050_CY              NUMBER;
 p_7050_EXPLAIN       NUMBER;
 p_7050_AMOUNT_FC          NUMBER;
 p_7050_AMOUNT_LC            NUMBER;
 p_7050_RATE        NUMBER;

 p_7050_NET_COLLECTED_LC        NUMBER;
 p_7050_VAT_AMOUNT        NUMBER;
 p_7050_SERVICE_AMOUNT   NUMBER;

 CURSOR c_musteri IS
  SELECT  MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
  FROM CBS_MUSTERI
  WHERE DURUM_KODU = 'A'
       AND MUSTERI_TIPI_KOD IN ('1','2','3')
    AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
         FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
         WHERE ISLEM_KODU = 7050
           AND MASRAF_KODU = 'INTBKOPFEE')
--   AND MUSTERI_NO IN (select distinct customer_id
--        from corpint.tbl_person
--        where to_char(dlm,'dd.mm') = to_char(pkg_muhasebe.banka_tarihi_bul,'dd.mm'))
   AND pkg_tx7047.int_tran_type(MUSTERI_NO) IS NOT NULL
  ORDER BY musteri_no ;
  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ln_yil   NUMBER;
 ln_ay   NUMBER;

 ls_cy_ind_disp  VARCHAR2(3);
 ls_cy_ind_tran  VARCHAR2(3);
 ls_cy_corp_disp  VARCHAR2(3);
 ls_cy_corp_tran  VARCHAR2(3);

 ln_amnt_ind_disp   NUMBER;
 ln_amnt_ind_tran   NUMBER;
 ln_amnt_corp_disp   NUMBER;
 ln_amnt_corp_tran   NUMBER;

 ln_cnt   NUMBER;

 ln_kur_ucret_dvz   NUMBER;
 ln_kur_hesap_dvz   NUMBER;
 ln_masraf   NUMBER;
 ln_bakiye   NUMBER;
 ln_amnt   NUMBER;
 ls_cy   VARCHAR2(3);
 ln_sira  NUMBER;

 ln_toplam_tahsil  NUMBER;
 ln_kalan_tahsilat  NUMBER;
 ln_hesaptan_al  NUMBER;
 ln_muhasebelesecek_tutar  NUMBER;
 ln_tahsil_tutar  NUMBER;
 ln_kal  NUMBER;
 ln_islem_no          NUMBER := 0;
 ls_dk   VARCHAR2(30);

 double_run_1  EXCEPTION;
 double_run_2  EXCEPTION;
 birden_fazla_parametre_var  EXCEPTION;
 parametre_yok  EXCEPTION;
 dk_yok  EXCEPTION;
 ln_vat_rate   NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
    p_7050_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7050_ACC_BRANCH');
 p_7050_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7050_TRAN_BRANCH');
 p_7050_ACC :=Pkg_Muhasebe.parametre_index_bul('7050_ACC');
 p_7050_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7050_INCOME_GL');
 p_7050_CY :=Pkg_Muhasebe.parametre_index_bul('7050_CY');
 p_7050_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7050_EXPLAIN');

 p_7050_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7050_AMOUNT_FC');
 p_7050_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7050_AMOUNT_LC');
 p_7050_RATE :=Pkg_Muhasebe.parametre_index_bul('7050_RATE');

 p_7050_NET_COLLECTED_LC :=Pkg_Muhasebe.parametre_index_bul('7050_NET_COLLECTED_LC');
 p_7050_VAT_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7050_VAT_AMOUNT');
 p_7050_SERVICE_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7050_SERVICE_AMOUNT');

 ln_amnt_ind_disp := 0;
 ln_amnt_ind_tran := 0;
 ln_amnt_corp_disp := 0;
 ln_amnt_corp_tran := 0;

 SELECT COUNT(*)
 INTO ln_cnt
 FROM CBS_MASRAF_KRITERLERI
 WHERE CHARGE_CODE = 'INTBKOPFEE';
 IF ln_cnt = 0
 THEN
  RAISE parametre_yok;
 END IF;
 --
 SELECT COUNT(*)
 INTO ln_cnt
 FROM CBS_MASRAF_KRITERLERI
 WHERE CHARGE_CODE = 'INTBKOPFEE'
   AND CUSTOMER_TYPE = 'INDIVIDUAL'
   AND INT_TRAN_TYPE = 'DISPLAY';
 IF ln_cnt = 1
 THEN
  SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
  INTO ln_amnt_ind_disp,ls_cy_ind_disp
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'INTBKOPFEE'
    AND CUSTOMER_TYPE = 'INDIVIDUAL'
    AND INT_TRAN_TYPE = 'DISPLAY';
 ELSE
  RAISE birden_fazla_parametre_var;
 END IF;
 --
 SELECT COUNT(*)
 INTO ln_cnt
 FROM CBS_MASRAF_KRITERLERI
 WHERE CHARGE_CODE = 'INTBKOPFEE'
   AND CUSTOMER_TYPE = 'INDIVIDUAL'
   AND INT_TRAN_TYPE = 'TRANSACTION';
 IF ln_cnt = 1
 THEN
  SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
  INTO ln_amnt_ind_tran,ls_cy_ind_tran
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'INTBKOPFEE'
    AND CUSTOMER_TYPE = 'INDIVIDUAL'
    AND INT_TRAN_TYPE = 'TRANSACTION';
 ELSE
  RAISE birden_fazla_parametre_var;
 END IF;
 --
 SELECT COUNT(*)
 INTO ln_cnt
 FROM CBS_MASRAF_KRITERLERI
 WHERE CHARGE_CODE = 'INTBKOPFEE'
   AND CUSTOMER_TYPE = 'CORPORATE'
   AND INT_TRAN_TYPE = 'DISPLAY';
 IF ln_cnt = 1
 THEN
  SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
  INTO ln_amnt_corp_disp,ls_cy_corp_disp
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'INTBKOPFEE'
    AND CUSTOMER_TYPE = 'CORPORATE'
    AND INT_TRAN_TYPE = 'DISPLAY';
 ELSE
  RAISE birden_fazla_parametre_var;
 END IF;
 --
 SELECT COUNT(*)
 INTO ln_cnt
 FROM CBS_MASRAF_KRITERLERI
 WHERE CHARGE_CODE = 'INTBKOPFEE'
   AND CUSTOMER_TYPE = 'CORPORATE'
   AND INT_TRAN_TYPE = 'TRANSACTION';
 IF ln_cnt = 1
 THEN
  SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
  INTO ln_amnt_corp_tran,ls_cy_corp_tran
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'INTBKOPFEE'
    AND CUSTOMER_TYPE = 'CORPORATE'
    AND INT_TRAN_TYPE = 'TRANSACTION';
 ELSE
  RAISE birden_fazla_parametre_var;
 END IF;
 --
 ln_yil := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY'));
 ln_ay := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM'));
 --
 OPEN c_musteri ;
 LOOP
  FETCH c_musteri INTO r_musteri  ;
  EXIT WHEN c_musteri%NOTFOUND;
    ln_amnt := 0;
    ls_cy := NULL;
   --
   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
   WHERE musteri_no = r_musteri.musteri_no
     AND islem_kodu = 7050
     AND masraf_kodu = 'INTBKOPFEE';
   --
   IF ln_cnt = 1
   THEN
    SELECT NVL(TUTAR,0), DOVIZ
    INTO ln_amnt, ls_cy
    FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
    WHERE musteri_no = r_musteri.musteri_no
    AND islem_kodu = 7050
    AND masraf_kodu = 'INTBKOPFEE';
   ELSE
        -- Individual - Display
    IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
      AND pkg_tx7047.int_tran_type(r_musteri.musteri_no) = 'DISPLAY'
    THEN
     ln_amnt := NVL(ln_amnt_ind_disp,0);
     ls_cy := ls_cy_ind_disp;
    END IF;

        -- Individual - Transaction
    IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
      AND pkg_tx7047.int_tran_type(r_musteri.musteri_no) = 'TRANSACTION'
    THEN
     ln_amnt := NVL(ln_amnt_ind_tran,0);
     ls_cy := ls_cy_ind_tran;
    END IF;

        -- Corporate - Display
    IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
      AND pkg_tx7047.int_tran_type(r_musteri.musteri_no) = 'DISPLAY'
    THEN
     ln_amnt := NVL(ln_amnt_corp_disp,0);
     ls_cy := ls_cy_corp_disp;
    END IF;

        -- Corporate - Transaction
    IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
      AND pkg_tx7047.int_tran_type(r_musteri.musteri_no) = 'TRANSACTION'
    THEN
     ln_amnt := NVL(ln_amnt_corp_tran,0);
     ls_cy := ls_cy_corp_tran;
    END IF;
   END IF;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = 'INTBKOPFEE'
      AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = 'INTBKOPFEE'
       AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
     WHERE charge_code = 'INTBKOPFEE'
       AND musteri_no = r_musteri.MUSTERI_NO
       AND yil = ln_yil
       AND ay = ln_ay;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = 'INTBKOPFEE'
        AND musteri_no = r_musteri.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;
--
------------------------------------------------ Asil simdi basliyor ---------------------------------------------
     OPEN c_hesap_som ;
     LOOP
      FETCH c_hesap_som INTO r_hesap_som  ;
      EXIT WHEN c_hesap_som%NOTFOUND;

       varchar_list(p_7050_ACC_BRANCH) := NULL;
       varchar_list(p_7050_TRAN_BRANCH) := NULL;
       varchar_list(p_7050_ACC) := NULL;
       varchar_list(p_7050_INCOME_GL) := NULL;
       varchar_list(p_7050_CY) := NULL;
       varchar_list(p_7050_EXPLAIN) := NULL;
       number_list(p_7050_AMOUNT_FC):= 0;
       number_list(p_7050_AMOUNT_LC):= 0;
       number_list(p_7050_RATE) := 0 ;
       number_list(p_7050_NET_COLLECTED_LC):= 0;
       number_list(p_7050_VAT_AMOUNT):= 0;
       number_list(p_7050_SERVICE_AMOUNT) := 0 ;
       ln_vat_rate := 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_RATE) := 1;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7050, r_musteri.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
           TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
           TAHSIL_ZAMANI)
          VALUES
          ('INTBKOPFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC((ln_muhasebelesecek_tutar/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_RATE) := 1;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7050, r_musteri.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
           TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
           TAHSIL_ZAMANI)
          VALUES
          ('INTBKOPFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap_som;

     IF ln_kalan_tahsilat > 0
     THEN
      ln_hesaptan_al := 1;
--
-------------------------------------------- NON SOM --------------------------------------------
      OPEN c_hesap_non_som(ls_cy) ;
      LOOP
       FETCH c_hesap_non_som INTO r_hesap_non_som  ;
       EXIT WHEN c_hesap_non_som%NOTFOUND;

       varchar_list(p_7050_ACC_BRANCH) := NULL;
       varchar_list(p_7050_TRAN_BRANCH) := NULL;
       varchar_list(p_7050_ACC) := NULL;
       varchar_list(p_7050_INCOME_GL) := NULL;
       varchar_list(p_7050_CY) := NULL;
       varchar_list(p_7050_EXPLAIN) := NULL;
       number_list(p_7050_AMOUNT_FC):= 0;
       number_list(p_7050_AMOUNT_LC):= 0;
       number_list(p_7050_RATE) := 0 ;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_kur_hesap_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
        ln_bakiye := NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;


          varchar_list(p_7050_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_non_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ROUND((number_list(p_7050_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7050_RATE) := ln_kur_hesap_dvz;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7050, r_musteri.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
           TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
           TAHSIL_ZAMANI)
          VALUES
          ('INTBKOPFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC(((ln_muhasebelesecek_tutar*ln_kur_hesap_dvz)/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_non_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ROUND((number_list(p_7050_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7050_RATE) := ln_kur_hesap_dvz;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7050, r_musteri.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
           TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
           TAHSIL_ZAMANI)
          VALUES
          ('INTBKOPFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
         END IF;
        END IF; -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap_non_som;
     END IF;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
     WHERE CHARGE_CODE = 'INTBKOPFEE'
       AND yil = ln_yil
       AND ay = ln_ay
       AND musteri_no = r_musteri.MUSTERI_NO;

     IF ln_cnt > 0
     THEN
         RAISE double_run_2;
     END IF;

     IF ln_kalan_tahsilat > 0
     THEN
      INSERT INTO CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
       TAHSIL_EDILEMEYEN,BOLUM_KODU, CUSTOMER_TYPE)
      VALUES
      ('INTBKOPFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
       ln_kalan_tahsilat, r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
     END IF;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF; --if ls_uygun = 'E' and ls_dk is not null
   END IF;
 END LOOP;
 CLOSE c_musteri;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||'INTBKOPFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||'INTBKOPFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5130'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
PROCEDURE DCF_FEE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara   NUMBER;
 ln_counter   NUMBER;
 ln_temp_numara   NUMBER;

 p_7052_ACC_BRANCH         NUMBER;
 p_7052_TRAN_BRANCH             NUMBER;
 p_7052_ACC            NUMBER;
 p_7052_INCOME_GL             NUMBER;
 p_7052_CY              NUMBER;
 p_7052_EXPLAIN       NUMBER;
 p_7052_EXPLAIN_2       NUMBER;
 p_7052_AMOUNT_FC          NUMBER;
 p_7052_AMOUNT_LC            NUMBER;
 p_7052_RATE        NUMBER;

 p_7052_NET_COLLECTED_LC        NUMBER;
 p_7052_VAT_AMOUNT        NUMBER;
 p_7052_SERVICE_AMOUNT   NUMBER;

 CURSOR c_dcf IS
  SELECT 'DCF' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE ACF_FEE IS NOT NULL
    AND NVL(CARD_TYPE,'X') <> 'C'
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND ACF_FEE > 0
    UNION ALL
  SELECT 'CARDISSUE' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE CARD_ISSUE_FEE IS NOT NULL
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND NVL(CARD_TYPE,'X') <> 'C'
    AND CARD_ISSUE_FEE > 0
    UNION ALL
  SELECT 'LSCRDISSUE' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE LS_CARD_ISSUE_FEE IS NOT NULL
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND NVL(CARD_TYPE,'X') <> 'C'
    AND LS_CARD_ISSUE_FEE > 0
    UNION ALL
  SELECT 'CDCF' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE ACF_FEE IS NOT NULL
    AND NVL(CARD_TYPE,'X') = 'C'
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND ACF_FEE > 0
    UNION ALL
  SELECT 'CCARDISSUE' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE CARD_ISSUE_FEE IS NOT NULL
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND NVL(CARD_TYPE,'X') = 'C'
    AND CARD_ISSUE_FEE > 0
    UNION ALL
  SELECT 'CLSCRDISSU' TIP,a.musteri_no MUSTERI,a.*
  FROM CBS_ATM_CARD_FEE a
  WHERE LS_CARD_ISSUE_FEE IS NOT NULL
    AND YUKLEME_TARIHI = TRUNC(SYSDATE)
    AND MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI)
    AND NVL(CARD_TYPE,'X') = 'C'
    AND LS_CARD_ISSUE_FEE > 0
  ORDER BY MUSTERI ;

  r_dcf  c_dcf%ROWTYPE;
 --
 CURSOR c_hesap_som(ln_musteri_1 NUMBER, ln_hesap_1 NUMBER) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = ln_musteri_1
  AND hesap_no = NVL(ln_hesap_1,hesap_no)
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ln_musteri_2 NUMBER, ls_dvz VARCHAR2, ln_hesap_2 NUMBER) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = ln_musteri_2
  AND hesap_no = NVL(ln_hesap_2,hesap_no)
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
 r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ln_cnt   NUMBER;

 ln_kur_ucret_dvz   NUMBER;
 ln_kur_hesap_dvz   NUMBER;
 ln_masraf   NUMBER;
 ln_bakiye   NUMBER;
 ln_amnt   NUMBER;
 ls_cy   VARCHAR2(3);
 ln_sira  NUMBER;
 ln_must   NUMBER;

 ln_toplam_tahsil  NUMBER;
 ln_kalan_tahsilat  NUMBER;
 ln_hesaptan_al  NUMBER;
 ln_muhasebelesecek_tutar  NUMBER;
 ln_tahsil_tutar  NUMBER;
 ln_kal  NUMBER;
 ln_islem_no          NUMBER := 0;
 ls_dk   VARCHAR2(30);

 dk_yok  EXCEPTION;
 ln_musteri NUMBER;
 ln_dk_grup NUMBER;
 ln_yil NUMBER;
 ln_ay NUMBER;
 ln_gun NUMBER;
 ln_vat_rate   NUMBER;
 ln_odeyecek_musteri   NUMBER;
 ln_odeyecek_musteri_hesap   NUMBER;
 ln_plan   NUMBER;
 ls_tip   VARCHAR2(30);
 ln_kur_ana_masraf   NUMBER;
 ln_lc_ana_masraf    NUMBER;
 ln_muaf    NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
    p_7052_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7052_ACC_BRANCH');
 p_7052_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7052_TRAN_BRANCH');
 p_7052_ACC :=Pkg_Muhasebe.parametre_index_bul('7052_ACC');
 p_7052_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7052_INCOME_GL');
 p_7052_CY :=Pkg_Muhasebe.parametre_index_bul('7052_CY');
 p_7052_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7052_EXPLAIN');
 p_7052_EXPLAIN_2 :=Pkg_Muhasebe.parametre_index_bul('7052_EXPLAIN_2');

 p_7052_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7052_AMOUNT_FC');
 p_7052_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7052_AMOUNT_LC');
 p_7052_RATE :=Pkg_Muhasebe.parametre_index_bul('7052_RATE');

 p_7052_NET_COLLECTED_LC :=Pkg_Muhasebe.parametre_index_bul('7052_NET_COLLECTED_LC');
 p_7052_VAT_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7052_VAT_AMOUNT');
 p_7052_SERVICE_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7052_SERVICE_AMOUNT');

 --
/*
 ln_yil := to_number(to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY'));
 ln_ay  := to_number(to_char(pkg_muhasebe.Banka_Tarihi_Bul,'MM'));
 ln_gun := to_number(to_char(pkg_muhasebe.Banka_Tarihi_Bul,'DD'));
*/
 ln_yil := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE),'YYYY'));
 ln_ay  := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE),'MM'));
 ln_gun := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE),'DD'));

 OPEN c_dcf ;
 LOOP
  FETCH c_dcf INTO r_dcf  ;
  EXIT WHEN c_dcf%NOTFOUND;
   ls_cy := 'KGS';
   ln_muaf := 0;
    IF r_dcf.TIP IN ('DCF','CDCF')
   THEN
    ln_amnt := r_dcf.ACF_FEE;
    ls_tip := 'DCF';
   END IF;
    IF r_dcf.TIP IN ('CARDISSUE','CCARDISSUE')
   THEN
    ln_amnt := r_dcf.CARD_ISSUE_FEE;
    ls_tip := 'CARDISSUE';
   END IF;
    IF r_dcf.TIP IN ('LSCRDISSUE','CLSCRDISSU')
   THEN
    ln_amnt := r_dcf.LS_CARD_ISSUE_FEE;
    ls_tip := 'LSCRDISSUE';
   END IF;

   ln_odeyecek_musteri := NULL;
   ln_odeyecek_musteri_hesap := NULL;
   ln_musteri := r_dcf.MUSTERI_NO;

   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_KART_TANIMLAMA
   WHERE MUSTERI_NO = r_dcf.MUSTERI_NO
     AND KART_NO = r_dcf.KART_NO
     AND KOMISYON_TIPI = ls_tip
     AND EXPIRE_DATE >= pkg_muhasebe.Banka_Tarihi_Bul
     AND odeyecek_musteri_hesap IS NOT NULL
     AND STATUS = 'A';

   IF ln_cnt = 1
   THEN
    SELECT odeyecek_musteri,odeyecek_musteri_hesap,MUSTERI_NO
    INTO ln_odeyecek_musteri,ln_odeyecek_musteri_hesap,ln_must
    FROM CBS_KART_TANIMLAMA
    WHERE MUSTERI_NO = r_dcf.MUSTERI_NO
      AND KART_NO = r_dcf.KART_NO
      AND KOMISYON_TIPI = ls_tip
      AND EXPIRE_DATE >= pkg_muhasebe.Banka_Tarihi_Bul
      AND odeyecek_musteri_hesap IS NOT NULL
      AND STATUS = 'A';

    ln_musteri := NVL(ln_odeyecek_musteri,ln_must);
   END IF;

   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_FEE_TAHSIL_EDILEN
   WHERE charge_code = r_dcf.TIP
     AND KART_NO = r_dcf.KART_NO
     AND musteri_no = ln_musteri
     AND yil = ln_yil
     AND ay = ln_ay
     AND gun = ln_gun;

   IF ln_cnt > 0
   THEN
    SELECT MAX(sira)
    INTO ln_sira
    FROM CBS_FEE_TAHSIL_EDILEN
    WHERE charge_code = r_dcf.TIP
      AND KART_NO = r_dcf.KART_NO
      AND musteri_no = ln_musteri
      AND yil = ln_yil
      AND ay = ln_ay
      AND gun = ln_gun;
   ELSE
    ln_sira := 0;
   END IF;

   ln_dk_grup := pkg_musteri.sf_musteri_dk_grup_kod_al(ln_musteri);

   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_MASRAF_DKGRUP_DK
   WHERE MASRAF_KODU = r_dcf.TIP
     AND DK_GRUP_KODU = ln_dk_grup;

   IF ln_cnt = 1
   THEN
    SELECT DKHESAP_1
    INTO ls_dk
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = r_dcf.TIP
      AND DK_GRUP_KODU = ln_dk_grup;
   ELSE
    RAISE dk_yok;
   END IF;
   --
   ln_kur_ana_masraf := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
   ln_lc_ana_masraf := TRUNC((ln_amnt * ln_kur_ana_masraf),2);

   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
   WHERE ISLEM_KODU = 7052
     AND musteri_no = ln_musteri
     AND MASRAF_KODU = r_dcf.TIP;

   IF ln_cnt >= 1
   THEN
    ln_sira := ln_sira + 1 ;

    ln_amnt := 0;
    ls_cy   := NULL;

    INSERT INTO CBS_FEE_TAHSIL_EDILEN
    (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
     TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
     STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
     ANA_BORC_FC, ANA_BORC_LC)
    VALUES
    (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,NULL,NULL,
     ls_cy,0,0,0,
     'FULL','MUAF',r_dcf.renewal_flag,0, 0,0,'ZAMANINDA',
     ln_amnt,ln_lc_ana_masraf);
    ln_muaf := 1;

    INSERT INTO CBS_FEE_TAHSIL_EDILEMEYEN
    (CHARGE_CODE, MUSTERI_NO, YIL, AY, GUN, KART_NO, MASRAF_TUTARI, MASRAF_DOVIZ,
     TOPLAM_TAHSIL_TUTAR, TAHSIL_EDILEMEYEN,RENEWAL, BOLUM_KODU,
     CUSTOMER_TYPE, ODEYECEK_HESAP,ANA_BORC_FC, ANA_BORC_LC)
    VALUES
    (r_dcf.TIP,ln_musteri,ln_yil,ln_ay,ln_gun,r_dcf.KART_NO,ln_amnt,ls_cy,
     0,0,r_dcf.renewal_flag,pkg_musteri.sf_bolum_kodu_al(ln_musteri),
     pkg_tx7047.musteri_tipi_ind_corp(ln_musteri),ln_odeyecek_musteri_hesap,ln_amnt,ln_lc_ana_masraf);
   END IF;
--
   IF pkg_atm_masraf.masraf_personelden_alinir(r_dcf.TIP) = 'H'
     AND pkg_musteri.Sf_Personel_mi(ln_musteri)='E'
     AND ln_muaf = 0
   THEN
    ln_sira := ln_sira + 1 ;
    ln_amnt := 0;
    ls_cy   := NULL;

    INSERT INTO CBS_FEE_TAHSIL_EDILEN
    (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
     TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
     STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
     ANA_BORC_FC, ANA_BORC_LC)
    VALUES
    (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,NULL,NULL,
     ls_cy,0,0,0,
     'FULL','PERSONEL',r_dcf.renewal_flag,0, 0,0,'ZAMANINDA',
     ln_amnt,ln_lc_ana_masraf);
    ln_muaf := 1;

    INSERT INTO CBS_FEE_TAHSIL_EDILEMEYEN
    (CHARGE_CODE, MUSTERI_NO, YIL, AY, GUN, KART_NO, MASRAF_TUTARI, MASRAF_DOVIZ,
     TOPLAM_TAHSIL_TUTAR, TAHSIL_EDILEMEYEN,RENEWAL, BOLUM_KODU,
     CUSTOMER_TYPE, ODEYECEK_HESAP,ANA_BORC_FC, ANA_BORC_LC)
    VALUES
    (r_dcf.TIP,ln_musteri,ln_yil,ln_ay,ln_gun,r_dcf.KART_NO,ln_amnt,ls_cy,
     0,0,r_dcf.renewal_flag,pkg_musteri.sf_bolum_kodu_al(ln_musteri),
     pkg_tx7047.musteri_tipi_ind_corp(ln_musteri),ln_odeyecek_musteri_hesap,ln_amnt,ln_lc_ana_masraf);
   END IF;
   --
   SELECT COUNT(*)
   INTO ln_cnt
   FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
   WHERE musteri_no = ln_musteri
     AND islem_kodu = 7052
     AND masraf_kodu = r_dcf.TIP;

   IF ln_cnt = 1
   THEN
    SELECT NVL(TUTAR,0), DOVIZ
    INTO ln_amnt, ls_cy
    FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
    WHERE musteri_no = ln_musteri
    AND islem_kodu = 7052
    AND masraf_kodu = r_dcf.TIP;

    IF ln_amnt = 0 AND ln_muaf = 0
    THEN
     ln_sira := ln_sira + 1 ;

     ln_amnt := 0;
     ls_cy   := NULL;

     INSERT INTO CBS_FEE_TAHSIL_EDILEN
     (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
      TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
      STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
      ANA_BORC_FC, ANA_BORC_LC)
     VALUES
     (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,NULL,NULL,
      ls_cy,0,0,0,
      'FULL','MUAF',r_dcf.renewal_flag,0, 0,0,'ZAMANINDA',
      0,0);
     ln_muaf := 1;

     INSERT INTO CBS_FEE_TAHSIL_EDILEMEYEN
     (CHARGE_CODE, MUSTERI_NO, YIL, AY, GUN, KART_NO, MASRAF_TUTARI, MASRAF_DOVIZ,
      TOPLAM_TAHSIL_TUTAR, TAHSIL_EDILEMEYEN,RENEWAL, BOLUM_KODU,
      CUSTOMER_TYPE, ODEYECEK_HESAP,ANA_BORC_FC, ANA_BORC_LC)
     VALUES
     (r_dcf.TIP,ln_musteri,ln_yil,ln_ay,ln_gun,r_dcf.KART_NO,ln_amnt,ls_cy,
      0,0,r_dcf.renewal_flag,pkg_musteri.sf_bolum_kodu_al(ln_musteri),
      pkg_tx7047.musteri_tipi_ind_corp(ln_musteri),ln_odeyecek_musteri_hesap,ln_amnt,ln_lc_ana_masraf);
    END IF;
   END IF;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    ln_counter := 0;


    ln_toplam_tahsil := 0;
    ln_kalan_tahsilat := ln_amnt;
    ln_hesaptan_al := 1;

    ln_kur_ana_masraf := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
    ln_lc_ana_masraf := TRUNC((ln_kalan_tahsilat * ln_kur_ana_masraf),2);

--
------------------------------------------------ Asil simdi basliyor ---------------------------------------------
    OPEN c_hesap_som(ln_musteri,ln_odeyecek_musteri_hesap) ;
    LOOP
     FETCH c_hesap_som INTO r_hesap_som  ;
     EXIT WHEN c_hesap_som%NOTFOUND;

      varchar_list(p_7052_ACC_BRANCH) := NULL;
      varchar_list(p_7052_TRAN_BRANCH) := NULL;
      varchar_list(p_7052_ACC) := NULL;
      varchar_list(p_7052_INCOME_GL) := NULL;
      varchar_list(p_7052_CY) := NULL;
      varchar_list(p_7052_EXPLAIN) := NULL;
      varchar_list(p_7052_EXPLAIN_2) := NULL;
      number_list(p_7052_AMOUNT_FC):= 0;
      number_list(p_7052_AMOUNT_LC):= 0;
      number_list(p_7052_RATE) := 0 ;
      number_list(p_7052_NET_COLLECTED_LC):= 0;
      number_list(p_7052_VAT_AMOUNT):= 0;
      number_list(p_7052_SERVICE_AMOUNT) := 0 ;

       IF r_dcf.TIP IN ('DCF','CDCF')
      THEN
        IF r_dcf.TIP = 'DCF'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 4;
      END IF;
       IF r_dcf.TIP IN ('CARDISSUE','CCARDISSUE')
      THEN
        IF r_dcf.TIP = 'CARDISSUE'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 2;
      END IF;
       IF r_dcf.TIP IN ('LSCRDISSUE','CLSCRDISSU')
      THEN
        IF r_dcf.TIP = 'LSCRDISSUE'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 2;
      END IF;

      ln_vat_rate := 0;

      IF ln_hesaptan_al = 1
      THEN
       ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
       ln_masraf := TRUNC((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
       ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);
       --
       IF ln_bakiye > 0
       THEN
        IF ln_bakiye >= ln_masraf
        THEN
         ln_muhasebelesecek_tutar := ln_masraf;
         ln_tahsil_tutar := ln_kalan_tahsilat;
         ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
         ln_kal := ln_kalan_tahsilat;
         ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

         varchar_list(p_7052_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
         varchar_list(p_7052_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
         varchar_list(p_7052_ACC) := r_hesap_som.hesap_no;
         varchar_list(p_7052_INCOME_GL) := ls_dk;
         varchar_list(p_7052_CY) := r_hesap_som.DOVIZ_KODU;
         number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_AMOUNT_LC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_RATE) := 1;

--         if pkg_tx7047.musteri_tipi_ind_corp(r_dcf.MUSTERI_NO) = 'INDIVIDUAL'
         IF r_dcf.CARD_TYPE = 'I'
         THEN
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
          number_list(p_7052_VAT_AMOUNT) :=TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
          number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                number_list(p_7052_NET_COLLECTED_LC)-
                     number_list(p_7052_VAT_AMOUNT);
         ELSE
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
          number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
          number_list(p_7052_SERVICE_AMOUNT) := 0;
         END IF;

         IF ln_counter = 0
         THEN
          ln_islem_no:=Pkg_Batch.islem_yarat(7052,varchar_list(p_7052_ACC_BRANCH));
          ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                   ln_plan,
                   ln_islem_no,
                   varchar_list,
                   number_list,
                   date_list,
                   boolean_list ,
                   NULL,
                   FALSE,
                   0,
                   varchar_list(p_7052_EXPLAIN));
         ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                     ln_plan,
                     ln_fis_numara,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list,
                     NULL,
                     FALSE);
         END IF;
         ln_counter:=ln_counter+1;
         --
         ln_sira := ln_sira + 1 ;

         INSERT INTO CBS_FEE_TAHSIL_EDILEN
         (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
          TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
          STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
          ANA_BORC_FC, ANA_BORC_LC)
         VALUES
         (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
          ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
          'FULL',NULL,r_dcf.renewal_flag,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA',
          ln_amnt,ln_lc_ana_masraf);
        ELSE
         ln_muhasebelesecek_tutar := ln_bakiye;
         ln_tahsil_tutar := TRUNC((ln_muhasebelesecek_tutar/ln_kur_ucret_dvz),2);
         ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
         ln_kal := ln_kalan_tahsilat;
         ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

         varchar_list(p_7052_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
         varchar_list(p_7052_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
         varchar_list(p_7052_ACC) := r_hesap_som.hesap_no;
         varchar_list(p_7052_INCOME_GL) := ls_dk;
         varchar_list(p_7052_CY) := r_hesap_som.DOVIZ_KODU;

         number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_AMOUNT_LC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_RATE) := 1;

--         if pkg_tx7047.musteri_tipi_ind_corp(r_dcf.MUSTERI_NO) = 'INDIVIDUAL'
         IF r_dcf.CARD_TYPE = 'I'
         THEN
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
          number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
          number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                number_list(p_7052_NET_COLLECTED_LC)-
                     number_list(p_7052_VAT_AMOUNT);
         ELSE
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
          number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
          number_list(p_7052_SERVICE_AMOUNT) := 0;
         END IF;

         IF ln_counter = 0 THEN
          ln_islem_no:=Pkg_Batch.islem_yarat(7052, varchar_list(p_7052_ACC_BRANCH));

          ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                   ln_plan,
                   ln_islem_no,
                   varchar_list,
                   number_list,
                   date_list,
                   boolean_list ,
                   NULL,
                   FALSE,
                   0,
                   varchar_list(p_7052_EXPLAIN));
         ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                     ln_plan,
                     ln_fis_numara,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list,
                     NULL,
                     FALSE);
         END IF;
         ln_counter:=ln_counter+1;
         --
         ln_sira := ln_sira + 1 ;
         INSERT INTO CBS_FEE_TAHSIL_EDILEN
         (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
          TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
          STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
          ANA_BORC_FC, ANA_BORC_LC)
         VALUES
         (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
          ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
          'PARTIAL',NULL,r_dcf.renewal_flag,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA',
          ln_amnt,ln_lc_ana_masraf);
        END IF;
       END IF;  -- if ln_bakiye >= 0
      END IF;
      --
      IF ln_kalan_tahsilat = 0
      THEN
       ln_hesaptan_al := 0;
      END IF;
    END LOOP;
    CLOSE c_hesap_som;

    IF ln_kalan_tahsilat > 0
    THEN
     ln_hesaptan_al := 1;
--
-------------------------------------------- NON SOM --------------------------------------------
     OPEN c_hesap_non_som(ln_musteri,ls_cy,ln_odeyecek_musteri_hesap) ;
     LOOP
      FETCH c_hesap_non_som INTO r_hesap_non_som  ;
      EXIT WHEN c_hesap_non_som%NOTFOUND;

      varchar_list(p_7052_ACC_BRANCH) := NULL;
      varchar_list(p_7052_TRAN_BRANCH) := NULL;
      varchar_list(p_7052_ACC) := NULL;
      varchar_list(p_7052_INCOME_GL) := NULL;
      varchar_list(p_7052_CY) := NULL;
      varchar_list(p_7052_EXPLAIN) := NULL;
      varchar_list(p_7052_EXPLAIN_2) := NULL;
      number_list(p_7052_AMOUNT_FC):= 0;
      number_list(p_7052_AMOUNT_LC):= 0;
      number_list(p_7052_RATE) := 0 ;
      number_list(p_7052_NET_COLLECTED_LC):= 0;
      number_list(p_7052_VAT_AMOUNT):= 0;
      number_list(p_7052_SERVICE_AMOUNT) := 0 ;

       IF r_dcf.TIP IN ('DCF','CDCF')
      THEN
        IF r_dcf.TIP = 'DCF'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(ln_yil)||'/'||TO_CHAR(ln_yil+1)||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 3;
      END IF;
       IF r_dcf.TIP IN ('CARDISSUE','CCARDISSUE')
      THEN
        IF r_dcf.TIP = 'CARDISSUE'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 1;
      END IF;
       IF r_dcf.TIP IN ('LSCRDISSUE','CLSCRDISSU')
      THEN
        IF r_dcf.TIP = 'LSCRDISSUE'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(r_dcf.musteri_no);
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_dcf.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(ln_musteri);
       END IF;
       ln_plan := 1;
      END IF;

      ln_vat_rate := 0;

      IF ln_hesaptan_al = 1
      THEN
       ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
       ln_kur_hesap_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
       ln_masraf := TRUNC(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
       ln_bakiye := NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0);
       --
       IF ln_bakiye > 0
       THEN
        IF ln_bakiye >= ln_masraf
        THEN
         ln_muhasebelesecek_tutar := ln_masraf;
         ln_tahsil_tutar := ln_kalan_tahsilat;
         ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
         ln_kal := ln_kalan_tahsilat;
         ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;


         varchar_list(p_7052_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
         varchar_list(p_7052_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
         varchar_list(p_7052_ACC) := r_hesap_non_som.hesap_no;
         varchar_list(p_7052_INCOME_GL) := ls_dk;
         varchar_list(p_7052_CY) := r_hesap_non_som.DOVIZ_KODU;

         number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_AMOUNT_LC) := ROUND((number_list(p_7052_AMOUNT_FC)*ln_kur_hesap_dvz),2);
         number_list(p_7052_RATE) := ln_kur_hesap_dvz;

--         if pkg_tx7047.musteri_tipi_ind_corp(r_dcf.MUSTERI_NO) = 'INDIVIDUAL'
         IF r_dcf.CARD_TYPE = 'I'
         THEN
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
          number_list(p_7052_VAT_AMOUNT) :=TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
          number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                number_list(p_7052_NET_COLLECTED_LC)-
                     number_list(p_7052_VAT_AMOUNT);
         ELSE
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_VAT_AMOUNT) :=TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
          number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
          number_list(p_7052_SERVICE_AMOUNT) := 0;
         END IF;

         IF ln_counter = 0 THEN
          ln_islem_no:=Pkg_Batch.islem_yarat(7052,varchar_list(p_7052_ACC_BRANCH));
          ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                   ln_plan,
                   ln_islem_no,
                   varchar_list,
                   number_list,
                   date_list,
                   boolean_list ,
                   NULL,
                   FALSE,
                   0,
                   varchar_list(p_7052_EXPLAIN));
         ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                     ln_plan,
                     ln_fis_numara,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list,
                     NULL,
                     FALSE);
         END IF;
         ln_counter:=ln_counter+1;
         --
         ln_sira := ln_sira + 1 ;
         INSERT INTO CBS_FEE_TAHSIL_EDILEN
         (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
          TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
          STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
          ANA_BORC_FC, ANA_BORC_LC)
         VALUES
         (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
          ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
          'FULL',NULL,r_dcf.renewal_flag,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA',
          ln_amnt,ln_lc_ana_masraf);
        ELSE
         ln_muhasebelesecek_tutar := ln_bakiye;
         ln_tahsil_tutar := TRUNC(((ln_muhasebelesecek_tutar*ln_kur_hesap_dvz)/ln_kur_ucret_dvz),2);
         ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
         ln_kal := ln_kalan_tahsilat;
         ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

         varchar_list(p_7052_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
         varchar_list(p_7052_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
         varchar_list(p_7052_ACC) := r_hesap_non_som.hesap_no;
         varchar_list(p_7052_INCOME_GL) := ls_dk;
         varchar_list(p_7052_CY) := r_hesap_non_som.DOVIZ_KODU;

         number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
         number_list(p_7052_AMOUNT_LC) := ROUND((number_list(p_7052_AMOUNT_FC)*ln_kur_hesap_dvz),2);
         number_list(p_7052_RATE) := ln_kur_hesap_dvz;

--         if pkg_tx7047.musteri_tipi_ind_corp(r_dcf.MUSTERI_NO) = 'INDIVIDUAL'
         IF r_dcf.CARD_TYPE = 'I'
         THEN
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
          number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
          number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                number_list(p_7052_NET_COLLECTED_LC)-
                     number_list(p_7052_VAT_AMOUNT);
         ELSE
          Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
          number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
          number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
          number_list(p_7052_SERVICE_AMOUNT) := 0;
         END IF;

         IF ln_counter = 0 THEN
          ln_islem_no:=Pkg_Batch.islem_yarat(7052,varchar_list(p_7052_ACC_BRANCH));
          ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                   ln_plan,
                   ln_islem_no,
                   varchar_list,
                   number_list,
                   date_list,
                   boolean_list ,
                   NULL,
                   FALSE,
                   0,
                   varchar_list(p_7052_EXPLAIN));
         ELSE
          ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                     ln_plan,
                     ln_fis_numara,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list,
                     NULL,
                     FALSE);
         END IF;
         ln_counter:=ln_counter+1;
         --
         ln_sira := ln_sira + 1 ;
         INSERT INTO CBS_FEE_TAHSIL_EDILEN
         (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
          TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
          STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
          ANA_BORC_FC, ANA_BORC_LC)
         VALUES
         (r_dcf.TIP,ln_yil,ln_ay,ln_gun,r_dcf.kart_no,ln_musteri,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
          ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
          'PARTIAL',NULL,r_dcf.renewal_flag,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA',
          ln_amnt,ln_lc_ana_masraf);
        END IF;
       END IF; -- if ln_bakiye >= 0
      END IF;
      --
      IF ln_kalan_tahsilat = 0
      THEN
       ln_hesaptan_al := 0;
      END IF;
     END LOOP;
     CLOSE c_hesap_non_som;
    END IF;
---------------------------------------------------------------------------------
    IF ln_kalan_tahsilat > 0
    THEN
     INSERT INTO CBS_FEE_TAHSIL_EDILEMEYEN
     (CHARGE_CODE, MUSTERI_NO, YIL, AY, GUN, KART_NO, MASRAF_TUTARI, MASRAF_DOVIZ,
      TOPLAM_TAHSIL_TUTAR, TAHSIL_EDILEMEYEN,RENEWAL, BOLUM_KODU,
      CUSTOMER_TYPE, ODEYECEK_HESAP,ANA_BORC_FC, ANA_BORC_LC)
     VALUES
     (r_dcf.TIP,ln_musteri,ln_yil,ln_ay,ln_gun,r_dcf.KART_NO,ln_amnt,ls_cy,
      ln_toplam_tahsil,ln_kalan_tahsilat,r_dcf.renewal_flag,pkg_musteri.sf_bolum_kodu_al(ln_musteri),
      pkg_tx7047.musteri_tipi_ind_corp(ln_musteri),ln_odeyecek_musteri_hesap,ln_amnt,ln_lc_ana_masraf);
    ELSE
     INSERT INTO CBS_FEE_TAHSIL_EDILEMEYEN
     (CHARGE_CODE, MUSTERI_NO, YIL, AY, GUN, KART_NO, MASRAF_TUTARI, MASRAF_DOVIZ,
      TOPLAM_TAHSIL_TUTAR, TAHSIL_EDILEMEYEN,RENEWAL, BOLUM_KODU,
      CUSTOMER_TYPE, ODEYECEK_HESAP,ANA_BORC_FC, ANA_BORC_LC)
     VALUES
     (r_dcf.TIP,ln_musteri,ln_yil,ln_ay,ln_gun,r_dcf.KART_NO,ln_amnt,ls_cy,
      ln_toplam_tahsil,NVL(ln_kalan_tahsilat,0),r_dcf.renewal_flag,pkg_musteri.sf_bolum_kodu_al(ln_musteri),
      pkg_tx7047.musteri_tipi_ind_corp(ln_musteri),ln_odeyecek_musteri_hesap,ln_amnt,ln_lc_ana_masraf);
    END IF;

    IF ln_counter>0 THEN
     Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
     Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_musteri)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
    END IF;
   END IF; -- if nvl(ln_amnt,0) > 0 and ls_cy is not null
 END LOOP;
 CLOSE c_dcf;

 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN dk_yok THEN
   ROLLBACK;
log_at('hakan01a','R_DCF.musteri',R_DCF.musteri);
log_at('hakan01b','r_dcf.kart_no',r_dcf.kart_no);
log_at('hakan01c','ln_amnt',ln_amnt);
log_at('hakan01d','ls_cy',ls_cy);
log_at('hakan01e','ln_musteri',ln_musteri);
log_at('hakan01f','r_dcf.TIP',r_dcf.TIP);
log_at('hakan01g','ln_dk_grup',ln_dk_grup);

   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
log_at('hakan00a','R_DCF.musteri',R_DCF.musteri);
log_at('hakan00b','r_dcf.kart_no',r_dcf.kart_no);
log_at('hakan00c','ln_amnt',ln_amnt);
log_at('hakan00d','ls_cy',ls_cy);
log_at('hakan00e','ln_musteri',ln_musteri);
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
PROCEDURE ACC_STMNT_FEE_DAILY_CHARGE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara                      NUMBER;
 ln_counter                         NUMBER;
 ln_temp_numara                     NUMBER;

 p_7054_ACC_BRANCH                  NUMBER;
 p_7054_TRAN_BRANCH                 NUMBER;
 p_7054_ACC                         NUMBER;
 p_7054_INCOME_GL                   NUMBER;
 p_7054_CY                          NUMBER;
 p_7054_EXPLAIN                     NUMBER;
 p_7054_AMOUNT_FC                   NUMBER;
 p_7054_AMOUNT_LC                   NUMBER;
 p_7054_INCOME_LC                   NUMBER;--cbs-578 bahianab
 p_7054_RATE                        NUMBER;

 p_7054_TAX_FC                      NUMBER;
 p_7054_TAX_LC                      NUMBER;
 p_7054_TAX_EXPLAIN                 NUMBER;

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
  WHERE NVL(TAHSIL_EDILEMEYEN,0) > 0
       AND CHARGE_CODE IN ('ACCMAINFEE','STATMNTFEE') and yaratildigi_tarih > to_date ('25012019','ddmmyyyy')           
       AND MUSTERI_NO IN (SELECT DISTINCT MUSTERI_NO FROM CBS_MUSTERI WHERE EKSTRE_UCRETI_ALINSIN = 'E' OR HESAP_UCRETI_F = 'E') 
       AND MUSTERI_NO NOT IN (SELECT DISTINCT customer_no FROM CBS_CUSTOMER_FEE)
       AND musteri_no NOT IN (SELECT musteri_no FROM cbs_vw_hesap_izleme WHERE BADLIST_FLAG = 'E')
  ORDER BY charge_code,musteri_no,yil,ay;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC','ELCARD NON INT.BR-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC','ELCARD NON INT.BR-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ln_yil                             NUMBER;
 ln_ay                              NUMBER;

 ln_cnt                             NUMBER;

 ln_kur_ucret_dvz                   NUMBER;
 ln_kur_hesap_dvz                   NUMBER;
 ln_masraf                          NUMBER;
 ln_bakiye                          NUMBER;
 ln_amnt                            NUMBER;
 ls_cy                              VARCHAR2(3);
 ln_sira                            NUMBER;

 ln_toplam_tahsil                   NUMBER;
 ln_kalan_tahsilat                  NUMBER;
 ln_hesaptan_al                     NUMBER;
 ln_muhasebelesecek_tutar           NUMBER;
 ln_tahsil_tutar                    NUMBER;
 ln_kal                             NUMBER;
 ln_islem_no                        NUMBER := 0;
 ls_dk                              VARCHAR2(30);
 ln_toplam_masraf                   NUMBER; --cbs-578 bahianab
 ln_total_lc_amount                 NUMBER; --cbs-578 bahianab 
 ln_total_fc_amount                 NUMBER; --cbs-578 bahianab 
 ln_fc_tahsil_tutar                 NUMBER; --cbs-578 bahianab
 ls_7054_amf_explanation            VARCHAR2(200); --cbs-578 bahianab
 ls_7054_amf_daily_explanation      VARCHAR2(200); --cbs-578 bahianab
 ls_7054_amf_tax_explanation        VARCHAR2(200); --cbs-578 bahianab
 ls_7054_sf_explanation             VARCHAR2(200); --cbs-578 bahianab
 ls_7054_sf_tax_explanation         VARCHAR2(200); --cbs-578 bahianab

 double_run_1                       EXCEPTION;
 double_run_2                       EXCEPTION;
 birden_fazla_parametre_var         EXCEPTION;
 parametre_yok                      EXCEPTION;
 dk_yok                             EXCEPTION;
 ln_rate                            NUMBER;
 ln_vergi                           NUMBER;
 ln_vergi_tl                        NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
    p_7054_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7054_ACC_BRANCH');
 p_7054_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7054_TRAN_BRANCH');
 p_7054_ACC :=Pkg_Muhasebe.parametre_index_bul('7054_ACC');
 p_7054_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7054_INCOME_GL');
 p_7054_CY :=Pkg_Muhasebe.parametre_index_bul('7054_CY');
 p_7054_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7054_EXPLAIN');

 p_7054_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7054_AMOUNT_FC');
 p_7054_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7054_AMOUNT_LC');
 p_7054_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7054_INCOME_LC'); --cbs-578 bahianab
 p_7054_RATE :=Pkg_Muhasebe.parametre_index_bul('7054_RATE');

 p_7054_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_FC');
 p_7054_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_LC');
 p_7054_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_EXPLAIN');

 --

 Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
 Pkg_Parametre.deger('AMF_EXPLANATION',ls_7054_amf_explanation);--cbs-578 bahianab
 Pkg_Parametre.deger('AMF_DAILY_EXPLANATION',ls_7054_amf_daily_explanation);--cbs-578 bahianab
 Pkg_Parametre.deger('AMF_TAX_EXPLANATION',ls_7054_amf_tax_explanation);--cbs-578 bahianab
 Pkg_Parametre.deger('SF_DAILY_EXPLANATION',ls_7054_sf_explanation);--cbs-578 bahianab
 Pkg_Parametre.deger('SF_TAX_EXPLANATION',ls_7054_sf_tax_explanation);--cbs-578 bahianab

 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
   ln_yil := r_tahsil_edilemeyen.yil;
   ln_ay := r_tahsil_edilemeyen.ay;

    ln_amnt := 0;
    ls_cy := NULL;
   --
   ln_amnt := NVL(r_tahsil_edilemeyen.TAHSIL_EDILEMEYEN,0);
   ls_cy := r_tahsil_edilemeyen.MASRAF_DOVIZ;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = DECODE(r_tahsil_edilemeyen.CHARGE_CODE,'STATMNTFEE','ACCSTMNFEE',r_tahsil_edilemeyen.CHARGE_CODE)
      AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = DECODE(r_tahsil_edilemeyen.CHARGE_CODE,'STATMNTFEE','ACCSTMNFEE',r_tahsil_edilemeyen.CHARGE_CODE)
       AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
       AND yil = ln_yil
       AND ay = ln_ay;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
        AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;
--
------------------------------------------------ SOM ---------------------------------------------
     OPEN c_hesap_som ;
     LOOP
      FETCH c_hesap_som INTO r_hesap_som  ;
      EXIT WHEN c_hesap_som%NOTFOUND;

       varchar_list(p_7054_ACC_BRANCH) := NULL;
       varchar_list(p_7054_TRAN_BRANCH) := NULL;
       varchar_list(p_7054_ACC) := NULL;
       varchar_list(p_7054_INCOME_GL) := NULL;
       varchar_list(p_7054_CY) := NULL;

       IF r_tahsil_edilemeyen.CHARGE_CODE = 'ACCMAINFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_amf_daily_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; --cbs-578 bahianab
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_amf_tax_explanation; --cbs-578 bahianab
       END IF;

       IF r_tahsil_edilemeyen.CHARGE_CODE = 'STATMNTFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_sf_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; --cbs-578 bahianab
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_sf_tax_explanation; --cbs-578 bahianab
       END IF;

       number_list(p_7054_AMOUNT_FC):= 0;
       number_list(p_7054_AMOUNT_LC):= 0;
       number_list(p_7054_INCOME_LC):= 0; --cbs-578 bahianab
       number_list(p_7054_RATE) := 0 ;

       number_list(p_7054_TAX_FC):= 0;
       number_list(p_7054_TAX_LC):= 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := ROUND((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

        ln_vergi_tl := ROUND(((ln_masraf*ln_rate)/100),2);
        ln_vergi := ln_vergi_tl;
               
        ln_toplam_masraf :=ln_masraf+ln_vergi; --cbs-578 bahianab
        --
        IF ln_bakiye > 1 --cbs-578 bahianab
        THEN
         IF ln_bakiye >= ln_toplam_masraf --cbs-578 bahianab--ln_masraf + ln_vergi
         THEN
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_7054_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap_som.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_toplam_masraf; --cbs-578 bahianab
          number_list(p_7054_AMOUNT_LC) := ln_toplam_masraf; --cbs-578 bahianab
          number_list(p_7054_INCOME_LC) := ln_masraf; --cbs-578 bahianab
          number_list(p_7054_RATE) := 1;

          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab
          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); --cbs-578 bahianab
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_masraf,'GECIKMELI');
         ELSE
         --BOM cbs-578
          ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
          ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
          ln_toplam_masraf :=ln_muhasebelesecek_tutar+ln_vergi_tl;
          ln_tahsil_tutar := ln_muhasebelesecek_tutar;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM cbs-578
           
          varchar_list(p_7054_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap_som.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_toplam_masraf; --cbs-578 bahianab
          number_list(p_7054_AMOUNT_LC) := ln_toplam_masraf; --cbs-578 bahianab
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar; --cbs-578 bahianab
          number_list(p_7054_RATE) := 1;

                                          --YT 09032010
          number_list(p_7054_TAX_FC):=ROUND((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab
          number_list(p_7054_TAX_LC):=ROUND((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); --cbs-578 bahianab
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap_som;

     IF ln_kalan_tahsilat > 0
     THEN
      ln_hesaptan_al := 1;
--
-------------------------------------------- NON SOM --------------------------------------------
      OPEN c_hesap_non_som(ls_cy) ;
      LOOP
       FETCH c_hesap_non_som INTO r_hesap_non_som  ;
       EXIT WHEN c_hesap_non_som%NOTFOUND;

       varchar_list(p_7054_ACC_BRANCH) := NULL;
       varchar_list(p_7054_TRAN_BRANCH) := NULL;
       varchar_list(p_7054_ACC) := NULL;
       varchar_list(p_7054_INCOME_GL) := NULL;
       varchar_list(p_7054_CY) := NULL;

        IF r_tahsil_edilemeyen.CHARGE_CODE = 'ACCMAINFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_amf_daily_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; --cbs-578 bahianab
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_amf_tax_explanation; --cbs-578 bahianab
       END IF;

       IF r_tahsil_edilemeyen.CHARGE_CODE = 'STATMNTFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_sf_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; --cbs-578 bahianab
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_sf_tax_explanation; --cbs-578 bahianab
       END IF;

       number_list(p_7054_AMOUNT_FC):= 0;
       number_list(p_7054_AMOUNT_LC):= 0;
       number_list(p_7054_INCOME_LC):= 0; --cbs-578 bahianab
       number_list(p_7054_RATE) := 0 ;

       number_list(p_7054_TAX_FC):=0;
       number_list(p_7054_TAX_LC):=0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_kur_hesap_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)),2); --cbs-578 bahianab
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0)),2);

        ln_vergi_tl := round(((ln_masraf * ln_rate) / 100),2); --cbs-578 bahianab
        ln_vergi := ln_vergi_tl; --cbs-578 bahianab
         
        ln_total_lc_amount := ln_masraf+ln_vergi; --cbs-578 bahianab
        ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); --cbs-578 bahianab
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_total_fc_amount -- cbs-578 ln_masraf + ln_vergi
         THEN
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-578 bahianab
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_7054_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_total_fc_amount;--cbs-578 bahianab--ln_masraf;
          number_list(p_7054_AMOUNT_LC) := ln_total_lc_amount;--cbs-578 bahianab--round((ln_tahsil_tutar*ln_kur_ucret_dvz),2);
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar;
          number_list(p_7054_RATE) := ln_kur_hesap_dvz;

          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab
          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); --cbs-578 bahianab
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI'); --cbs-578 bahianab
         ELSE
         --BOM cbs-578
          ln_total_fc_amount := trunc((ln_bakiye-0.01),2); 
          ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); 
          ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+(ln_rate/100))),2); 
          ln_tahsil_tutar := ln_muhasebelesecek_tutar;
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM cbs-578

          varchar_list(p_7054_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_total_fc_amount;--cbs-578 bahianab--ln_muhasebelesecek_tutar;
          number_list(p_7054_AMOUNT_LC) := ln_total_lc_amount;--cbs-578 bahianab --round((number_list(p_7048_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar;--cbs-578 bahianab
          number_list(p_7054_RATE) := ln_kur_hesap_dvz;

                                           --YT 09032010
          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab
          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); --cbs-578 bahianab

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); --cbs-578 bahianab
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI'); --cbs-578 bahianab
         END IF;
        END IF; -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap_non_som;
     END IF;

     UPDATE CBS_FEE_TAH_EDILEMEYEN_ACCFEE
     SET TAHSIL_EDILEMEYEN = ln_kalan_tahsilat,
         TOPLAM_TAHSIL_TUTAR = MASRAF_TUTARI-ln_kalan_tahsilat
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.musteri_no
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF; --if ls_uygun = 'E' and ls_dk is not null
   END IF;
  COMMIT;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5130'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
PROCEDURE DCF_FEE_DAILY_CHARGE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara   NUMBER;
 ln_counter   NUMBER;
 ln_temp_numara   NUMBER;

 p_7052_ACC_BRANCH         NUMBER;
 p_7052_TRAN_BRANCH             NUMBER;
 p_7052_ACC            NUMBER;
 p_7052_INCOME_GL             NUMBER;
 p_7052_CY              NUMBER;
 p_7052_EXPLAIN       NUMBER;
 p_7052_EXPLAIN_2       NUMBER;
 p_7052_AMOUNT_FC          NUMBER;
 p_7052_AMOUNT_LC            NUMBER;
 p_7052_RATE        NUMBER;

 p_7052_NET_COLLECTED_LC        NUMBER;
 p_7052_VAT_AMOUNT        NUMBER;
 p_7052_SERVICE_AMOUNT   NUMBER;
 ln_card_owner      NUMBER;
 ld_yukleme_tarihi     DATE;
 ln_cnt3        NUMBER;

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM CBS_FEE_TAHSIL_EDILEMEYEN
  WHERE NVL(TAHSIL_EDILEMEYEN,0) > 0
   AND CHARGE_CODE IN ('DCF','CARDISSUE','LSCRDISSUE','CDCF','CCARDISSUE','CLSCRDISSU')
  ORDER BY charge_code,musteri_no,yil,ay,gun;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
 --
 CURSOR c_hesap_som(ln_hesap_1 NUMBER) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND hesap_no = NVL(ln_hesap_1,hesap_no)
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2,ln_hesap_2 NUMBER) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND hesap_no = NVL(ln_hesap_2,hesap_no)
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ln_cnt   NUMBER;

 ln_kur_ucret_dvz   NUMBER;
 ln_kur_hesap_dvz   NUMBER;
 ln_masraf   NUMBER;
 ln_bakiye   NUMBER;
 ln_amnt   NUMBER;
 ls_cy   VARCHAR2(3);
 ln_sira  NUMBER;

 ln_toplam_tahsil  NUMBER;
 ln_kalan_tahsilat  NUMBER;
 ln_hesaptan_al  NUMBER;
 ln_muhasebelesecek_tutar  NUMBER;
 ln_tahsil_tutar  NUMBER;
 ln_kal  NUMBER;
 ln_islem_no          NUMBER := 0;
 ls_dk   VARCHAR2(30);
 ls_CARD_TYPE   VARCHAR2(1);

 double_run_1  EXCEPTION;
 double_run_2  EXCEPTION;
 dk_yok  EXCEPTION;
 ln_vat_rate   NUMBER;
 ln_plan    NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
    p_7052_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7052_ACC_BRANCH');
 p_7052_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7052_TRAN_BRANCH');
 p_7052_ACC :=Pkg_Muhasebe.parametre_index_bul('7052_ACC');
 p_7052_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7052_INCOME_GL');
 p_7052_CY :=Pkg_Muhasebe.parametre_index_bul('7052_CY');
 p_7052_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7052_EXPLAIN');
 p_7052_EXPLAIN_2 :=Pkg_Muhasebe.parametre_index_bul('7052_EXPLAIN_2');

 p_7052_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7052_AMOUNT_FC');
 p_7052_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7052_AMOUNT_LC');
 p_7052_RATE :=Pkg_Muhasebe.parametre_index_bul('7052_RATE');

 p_7052_NET_COLLECTED_LC :=Pkg_Muhasebe.parametre_index_bul('7052_NET_COLLECTED_LC');
 p_7052_VAT_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7052_VAT_AMOUNT');
 p_7052_SERVICE_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7052_SERVICE_AMOUNT');
 --
 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
    ln_amnt := 0;
    ls_cy := NULL;
   ln_card_owner := NULL;
   --
   ln_amnt := NVL(r_tahsil_edilemeyen.TAHSIL_EDILEMEYEN,0);
   ls_cy := r_tahsil_edilemeyen.MASRAF_DOVIZ;
   --
   ld_yukleme_tarihi := TO_DATE(TO_CHAR(r_tahsil_edilemeyen.yil,'0000')||
                              TO_CHAR(r_tahsil_edilemeyen.ay,'00')||
                 TO_CHAR(r_tahsil_edilemeyen.gun,'00'),'yyyymmdd');

   SELECT COUNT(*)
   INTO ln_cnt3
   FROM CBS_ATM_CARD_FEE
   WHERE YUKLEME_TARIHI = ld_yukleme_tarihi
     AND kart_no = r_tahsil_edilemeyen.kart_no;

   IF ln_cnt3 = 1
   THEN
    SELECT MUSTERI_NO,CARD_TYPE
    INTO ln_card_owner,ls_CARD_TYPE
    FROM CBS_ATM_CARD_FEE
    WHERE YUKLEME_TARIHI = ld_yukleme_tarihi
      AND kart_no = r_tahsil_edilemeyen.kart_no;
   END IF;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = r_tahsil_edilemeyen.CHARGE_CODE
      AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = r_tahsil_edilemeyen.CHARGE_CODE
       AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay
       AND GUN = r_tahsil_edilemeyen.gun
       AND KART_NO = r_tahsil_edilemeyen.KART_NO;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN
      WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
        AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
        AND yil = r_tahsil_edilemeyen.yil
        AND ay = r_tahsil_edilemeyen.ay
        AND GUN = r_tahsil_edilemeyen.gun
        AND KART_NO = r_tahsil_edilemeyen.KART_NO;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;
--
------------------------------------------------ Asil simdi basliyor ---------------------------------------------
     OPEN c_hesap_som(r_tahsil_edilemeyen.ODEYECEK_HESAP) ;
     LOOP
      FETCH c_hesap_som INTO r_hesap_som  ;
      EXIT WHEN c_hesap_som%NOTFOUND;

       varchar_list(p_7052_ACC_BRANCH) := NULL;
       varchar_list(p_7052_TRAN_BRANCH) := NULL;
       varchar_list(p_7052_ACC) := NULL;
       varchar_list(p_7052_INCOME_GL) := NULL;
       varchar_list(p_7052_CY) := NULL;
       number_list(p_7052_AMOUNT_FC):= 0;
       number_list(p_7052_AMOUNT_LC):= 0;
       number_list(p_7052_RATE) := 0 ;
       number_list(p_7052_NET_COLLECTED_LC):= 0;
       number_list(p_7052_VAT_AMOUNT):= 0;
       varchar_list(p_7052_EXPLAIN) := NULL;
       varchar_list(p_7052_EXPLAIN_2) := NULL;
       number_list(p_7052_SERVICE_AMOUNT) := 0 ;

        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('DCF','CDCF')
       THEN
         IF r_tahsil_edilemeyen.CHARGE_CODE = 'DCF'
        THEN
         varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        ELSE
         varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        END IF;
        ln_plan := 4;
       END IF;
        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('CARDISSUE','CCARDISSUE')
       THEN
        IF r_tahsil_edilemeyen.CHARGE_CODE = 'CARDISSUE'
        THEN
         varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        ELSE
         varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        END IF;
        ln_plan := 2;
       END IF;
        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('LSCRDISSUE','CLSCRDISSU')
       THEN
         IF r_tahsil_edilemeyen.CHARGE_CODE = 'LSCRDISSUE'
        THEN
         varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        ELSE
         varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        END IF;
        ln_plan := 2;
       END IF;

       ln_vat_rate := 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7052_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7052_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7052_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7052_INCOME_GL) := ls_dk;
          varchar_list(p_7052_CY) := r_hesap_som.DOVIZ_KODU;
          number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_RATE) := 1;

--          if pkg_tx7047.musteri_tipi_ind_corp(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no)) = 'INDIVIDUAL'
          IF ls_CARD_TYPE = 'I'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
           number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                 number_list(p_7052_NET_COLLECTED_LC)-
                      number_list(p_7052_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
           number_list(p_7052_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7053, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    varchar_list(p_7052_EXPLAIN));
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO,
           HESAP_DVZ,TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
           ANA_BORC_FC, ANA_BORC_LC)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,r_tahsil_edilemeyen.yil,r_tahsil_edilemeyen.ay,r_tahsil_edilemeyen.gun,r_tahsil_edilemeyen.kart_no,r_tahsil_edilemeyen.musteri_no,ln_sira,r_hesap_som.HESAP_NO,
           r_hesap_som.DOVIZ_KODU,ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
           'FULL',NULL,r_tahsil_edilemeyen.renewal,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI',
           r_tahsil_edilemeyen.ANA_BORC_FC,r_tahsil_edilemeyen.ANA_BORC_LC);
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC((ln_muhasebelesecek_tutar/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7052_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7052_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7052_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7052_INCOME_GL) := ls_dk;
          varchar_list(p_7052_CY) := r_hesap_som.DOVIZ_KODU;

          number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_RATE) := 1;

--          if pkg_tx7047.musteri_tipi_ind_corp(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no)) = 'INDIVIDUAL'
          IF ls_CARD_TYPE = 'I'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
           number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                 number_list(p_7052_NET_COLLECTED_LC)-
                      number_list(p_7052_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
           number_list(p_7052_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7053, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    varchar_list(p_7052_EXPLAIN));
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO,
           HESAP_DVZ,TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
           ANA_BORC_FC, ANA_BORC_LC)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,r_tahsil_edilemeyen.yil,r_tahsil_edilemeyen.ay,r_tahsil_edilemeyen.gun,r_tahsil_edilemeyen.kart_no,r_tahsil_edilemeyen.musteri_no,ln_sira,r_hesap_som.HESAP_NO,
           r_hesap_som.DOVIZ_KODU,ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
           'PARTIAL',NULL,r_tahsil_edilemeyen.renewal,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI',
           r_tahsil_edilemeyen.ANA_BORC_FC,r_tahsil_edilemeyen.ANA_BORC_LC);
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap_som;

     IF ln_kalan_tahsilat > 0
     THEN
      ln_hesaptan_al := 1;
--
-------------------------------------------- NON SOM --------------------------------------------
      OPEN c_hesap_non_som(ls_cy,r_tahsil_edilemeyen.ODEYECEK_HESAP) ;
      LOOP
       FETCH c_hesap_non_som INTO r_hesap_non_som  ;
       EXIT WHEN c_hesap_non_som%NOTFOUND;

       varchar_list(p_7052_ACC_BRANCH) := NULL;
       varchar_list(p_7052_TRAN_BRANCH) := NULL;
       varchar_list(p_7052_ACC) := NULL;
       varchar_list(p_7052_INCOME_GL) := NULL;
       varchar_list(p_7052_CY) := NULL;
       varchar_list(p_7052_EXPLAIN) := NULL;
       varchar_list(p_7052_EXPLAIN_2) := NULL;
       number_list(p_7052_AMOUNT_FC):= 0;
       number_list(p_7052_AMOUNT_LC):= 0;
       number_list(p_7052_RATE) := 0 ;
       number_list(p_7052_NET_COLLECTED_LC):= 0;
       number_list(p_7052_VAT_AMOUNT):= 0;
       number_list(p_7052_SERVICE_AMOUNT) := 0 ;

        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('DCF','CDCF')
       THEN
         IF r_tahsil_edilemeyen.CHARGE_CODE = 'DCF'
        THEN
         varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        ELSE
         varchar_list(p_7052_EXPLAIN_2) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Annual Card Fee : '||TO_CHAR(r_tahsil_edilemeyen.yil)||'/'||TO_CHAR(r_tahsil_edilemeyen.yil+1)||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(PKG_HESAp.HesaptanMusteriNoAl(r_tahsil_edilemeyen.ODEYECEK_HESAP));
        END IF;
        ln_plan := 3;
       END IF;
        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('CARDISSUE','CCARDISSUE')
       THEN
         IF r_tahsil_edilemeyen.CHARGE_CODE = 'CARDISSUE'
        THEN
         varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        ELSE
         varchar_list(p_7052_EXPLAIN_2) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
         varchar_list(p_7052_EXPLAIN) := 'Card Issuance Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
        END IF;
        ln_plan := 1;
       END IF;
        IF r_tahsil_edilemeyen.CHARGE_CODE IN ('LSCRDISSUE','CLSCRDISSU')
       THEN
        IF r_tahsil_edilemeyen.CHARGE_CODE = 'LSCRDISSUE'
       THEN
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
       ELSE
        varchar_list(p_7052_EXPLAIN_2) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Card Owner: '||pkg_musteri.sf_musteri_adi(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no));
        varchar_list(p_7052_EXPLAIN) := 'Lost/Stolen Card Fee : '||' - Card No: '||r_tahsil_edilemeyen.KART_NO||' - Payee: '||pkg_musteri.sf_musteri_adi(r_tahsil_edilemeyen.musteri_no);
       END IF;
        ln_plan := 1;
       END IF;

       ln_vat_rate := 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_kur_hesap_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
        ln_bakiye := NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;


          varchar_list(p_7052_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7052_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7052_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7052_INCOME_GL) := ls_dk;
          varchar_list(p_7052_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_AMOUNT_LC) := ROUND((number_list(p_7052_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7052_RATE) := ln_kur_hesap_dvz;

--          if pkg_tx7047.musteri_tipi_ind_corp(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no)) = 'INDIVIDUAL'
          IF ls_CARD_TYPE = 'I'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
           number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                 number_list(p_7052_NET_COLLECTED_LC)-
                      number_list(p_7052_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
           number_list(p_7052_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7053, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    varchar_list(p_7052_EXPLAIN));
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO,
           HESAP_DVZ,TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
           ANA_BORC_FC, ANA_BORC_LC)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,r_tahsil_edilemeyen.yil,r_tahsil_edilemeyen.ay,r_tahsil_edilemeyen.gun,r_tahsil_edilemeyen.kart_no,r_tahsil_edilemeyen.musteri_no,ln_sira,
            r_hesap_non_som.HESAP_NO,
           r_hesap_non_som.DOVIZ_KODU,ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
           'FULL',NULL,r_tahsil_edilemeyen.renewal,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI',
           r_tahsil_edilemeyen.ANA_BORC_FC,r_tahsil_edilemeyen.ANA_BORC_LC);
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC(((ln_muhasebelesecek_tutar*ln_kur_hesap_dvz)/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7052_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7052_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7052_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7052_INCOME_GL) := ls_dk;
          varchar_list(p_7052_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_7052_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7052_AMOUNT_LC) := ROUND((number_list(p_7052_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7052_RATE) := ln_kur_hesap_dvz;

--          if pkg_tx7047.musteri_tipi_ind_corp(NVL(ln_card_owner,r_tahsil_edilemeyen.musteri_no)) = 'INDIVIDUAL'
          IF ls_CARD_TYPE = 'I'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_NET_COLLECTED_LC) := TRUNC(number_list(p_7052_AMOUNT_LC)/ 1.24,2);
           number_list(p_7052_VAT_AMOUNT) := TRUNC(number_list(p_7052_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7052_SERVICE_AMOUNT) := number_list(p_7052_AMOUNT_LC)-
                                                 number_list(p_7052_NET_COLLECTED_LC)-
                      number_list(p_7052_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7052_VAT_AMOUNT) := TRUNC((number_list(p_7052_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7052_NET_COLLECTED_LC) := number_list(p_7052_AMOUNT_LC)-number_list(p_7052_VAT_AMOUNT);
           number_list(p_7052_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7053, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7052,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    varchar_list(p_7052_EXPLAIN));
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7052,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO,
           HESAP_DVZ,TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT, TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, MUAFIYET, RENEWAL, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC, TAHSIL_ZAMANI,
           ANA_BORC_FC, ANA_BORC_LC)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,r_tahsil_edilemeyen.yil,r_tahsil_edilemeyen.ay,r_tahsil_edilemeyen.gun,r_tahsil_edilemeyen.kart_no,r_tahsil_edilemeyen.musteri_no,ln_sira,
           r_hesap_non_som.HESAP_NO,
           r_hesap_non_som.DOVIZ_KODU,ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
           'PARTIAL',NULL,r_tahsil_edilemeyen.renewal,ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI',
           r_tahsil_edilemeyen.ANA_BORC_FC,r_tahsil_edilemeyen.ANA_BORC_LC);
         END IF;
        END IF; -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap_non_som;
     END IF;

     UPDATE CBS_FEE_TAHSIL_EDILEMEYEN
     SET TAHSIL_EDILEMEYEN = ln_kalan_tahsilat,
         TOPLAM_TAHSIL_TUTAR = MASRAF_TUTARI-ln_kalan_tahsilat
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.musteri_no
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay
       AND gun = r_tahsil_edilemeyen.gun
       AND kart_no = r_tahsil_edilemeyen.kart_no;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF; --if ls_uygun = 'E' and ls_dk is not null
   END IF;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
PROCEDURE INTERNET_FEE_DAILY_CHARGE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara   NUMBER;
 ln_counter   NUMBER;
 ln_temp_numara   NUMBER;

 p_7050_ACC_BRANCH         NUMBER;
 p_7050_TRAN_BRANCH             NUMBER;
 p_7050_ACC            NUMBER;
 p_7050_INCOME_GL             NUMBER;
 p_7050_CY              NUMBER;
 p_7050_EXPLAIN       NUMBER;
 p_7050_AMOUNT_FC          NUMBER;
 p_7050_AMOUNT_LC            NUMBER;
 p_7050_RATE        NUMBER;

 p_7050_NET_COLLECTED_LC        NUMBER;
 p_7050_VAT_AMOUNT        NUMBER;
 p_7050_SERVICE_AMOUNT   NUMBER;

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
  WHERE NVL(TAHSIL_EDILEMEYEN,0) > 0
   AND CHARGE_CODE IN ('INTBKOPFEE')
  ORDER BY charge_code,musteri_no,yil,ay;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 ln_yil   NUMBER;
 ln_ay   NUMBER;

 ln_cnt   NUMBER;

 ln_kur_ucret_dvz   NUMBER;
 ln_kur_hesap_dvz   NUMBER;
 ln_masraf   NUMBER;
 ln_bakiye   NUMBER;
 ln_amnt   NUMBER;
 ls_cy   VARCHAR2(3);
 ln_sira  NUMBER;

 ln_toplam_tahsil  NUMBER;
 ln_kalan_tahsilat  NUMBER;
 ln_hesaptan_al  NUMBER;
 ln_muhasebelesecek_tutar  NUMBER;
 ln_tahsil_tutar  NUMBER;
 ln_kal  NUMBER;
 ln_islem_no          NUMBER := 0;
 ls_dk   VARCHAR2(30);

 double_run_1  EXCEPTION;
 double_run_2  EXCEPTION;
 birden_fazla_parametre_var  EXCEPTION;
 parametre_yok  EXCEPTION;
 dk_yok  EXCEPTION;
 ln_vat_rate   NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
    p_7050_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7050_ACC_BRANCH');
 p_7050_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7050_TRAN_BRANCH');
 p_7050_ACC :=Pkg_Muhasebe.parametre_index_bul('7050_ACC');
 p_7050_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7050_INCOME_GL');
 p_7050_CY :=Pkg_Muhasebe.parametre_index_bul('7050_CY');
 p_7050_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7050_EXPLAIN');

 p_7050_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7050_AMOUNT_FC');
 p_7050_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7050_AMOUNT_LC');
 p_7050_RATE :=Pkg_Muhasebe.parametre_index_bul('7050_RATE');

 p_7050_NET_COLLECTED_LC :=Pkg_Muhasebe.parametre_index_bul('7050_NET_COLLECTED_LC');
 p_7050_VAT_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7050_VAT_AMOUNT');
 p_7050_SERVICE_AMOUNT :=Pkg_Muhasebe.parametre_index_bul('7050_SERVICE_AMOUNT');
 --
 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
   ln_yil := r_tahsil_edilemeyen.yil;
   ln_ay := r_tahsil_edilemeyen.ay;

    ln_amnt := 0;
    ls_cy := NULL;
   --
   ln_amnt := NVL(r_tahsil_edilemeyen.TAHSIL_EDILEMEYEN,0);
   ls_cy := r_tahsil_edilemeyen.MASRAF_DOVIZ;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = r_tahsil_edilemeyen.CHARGE_CODE
      AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = r_tahsil_edilemeyen.CHARGE_CODE
       AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
       AND yil = ln_yil
       AND ay = ln_ay;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
        AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;
--
------------------------------------------------ Asil simdi basliyor ---------------------------------------------
     OPEN c_hesap_som ;
     LOOP
      FETCH c_hesap_som INTO r_hesap_som  ;
      EXIT WHEN c_hesap_som%NOTFOUND;

       varchar_list(p_7050_ACC_BRANCH) := NULL;
       varchar_list(p_7050_TRAN_BRANCH) := NULL;
       varchar_list(p_7050_ACC) := NULL;
       varchar_list(p_7050_INCOME_GL) := NULL;
       varchar_list(p_7050_CY) := NULL;
       varchar_list(p_7050_EXPLAIN) := NULL;
       number_list(p_7050_AMOUNT_FC):= 0;
       number_list(p_7050_AMOUNT_LC):= 0;
       number_list(p_7050_RATE) := 0 ;
       number_list(p_7050_NET_COLLECTED_LC):= 0;
       number_list(p_7050_VAT_AMOUNT):= 0;
       number_list(p_7050_SERVICE_AMOUNT) := 0 ;
       ln_vat_rate := 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_RATE) := 1;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_tahsil_edilemeyen.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7057, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC((ln_muhasebelesecek_tutar/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_RATE) := 1;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_tahsil_edilemeyen.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7057, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap_som;

     IF ln_kalan_tahsilat > 0
     THEN
      ln_hesaptan_al := 1;
--
-------------------------------------------- NON SOM --------------------------------------------
      OPEN c_hesap_non_som(ls_cy) ;
      LOOP
       FETCH c_hesap_non_som INTO r_hesap_non_som  ;
       EXIT WHEN c_hesap_non_som%NOTFOUND;

       varchar_list(p_7050_ACC_BRANCH) := NULL;
       varchar_list(p_7050_TRAN_BRANCH) := NULL;
       varchar_list(p_7050_ACC) := NULL;
       varchar_list(p_7050_INCOME_GL) := NULL;
       varchar_list(p_7050_CY) := NULL;
       varchar_list(p_7050_EXPLAIN) := NULL;
       number_list(p_7050_AMOUNT_FC):= 0;
       number_list(p_7050_AMOUNT_LC):= 0;
       number_list(p_7050_RATE) := 0 ;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_kur_hesap_dvz := TRUNC((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),2);
        ln_masraf := TRUNC(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
        ln_bakiye := NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0);
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_masraf
         THEN
          ln_muhasebelesecek_tutar := ln_masraf;
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;


          varchar_list(p_7050_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_non_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ROUND((number_list(p_7050_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7050_RATE) := ln_kur_hesap_dvz;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_tahsil_edilemeyen.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7057, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,
           r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         ELSE
          ln_muhasebelesecek_tutar := ln_bakiye;
          ln_tahsil_tutar := TRUNC(((ln_muhasebelesecek_tutar*ln_kur_hesap_dvz)/ln_kur_ucret_dvz),2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7050_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_7050_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_7050_INCOME_GL) := ls_dk;
          varchar_list(p_7050_CY) := r_hesap_non_som.DOVIZ_KODU;
          varchar_list(p_7050_EXPLAIN) := 'INTERNET BANKING ANNUAL FEE';

          number_list(p_7050_AMOUNT_FC) := ln_muhasebelesecek_tutar;
          number_list(p_7050_AMOUNT_LC) := ROUND((number_list(p_7050_AMOUNT_FC)*ln_kur_hesap_dvz),2);
          number_list(p_7050_RATE) := ln_kur_hesap_dvz;

          IF pkg_tx7047.musteri_tipi_ind_corp(r_tahsil_edilemeyen.musteri_no) = 'INDIVIDUAL'
          THEN
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_NET_COLLECTED_LC) := TRUNC(number_list(p_7050_AMOUNT_LC)/ 1.24,2);
           number_list(p_7050_VAT_AMOUNT) := TRUNC(number_list(p_7050_NET_COLLECTED_LC)*(ln_vat_rate/100),2);
           number_list(p_7050_SERVICE_AMOUNT) := number_list(p_7050_AMOUNT_LC)-
                                                 number_list(p_7050_NET_COLLECTED_LC)-
                      number_list(p_7050_VAT_AMOUNT);
          ELSE
           Pkg_Parametre.deger('G_VAT_RATE',ln_vat_rate);
           number_list(p_7050_VAT_AMOUNT) := TRUNC((number_list(p_7050_AMOUNT_LC)*ln_vat_rate)/(100+ln_vat_rate),2);
           number_list(p_7050_NET_COLLECTED_LC) := number_list(p_7050_AMOUNT_LC)-number_list(p_7050_VAT_AMOUNT);
           number_list(p_7050_SERVICE_AMOUNT) := 0;
          END IF;

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7057, r_tahsil_edilemeyen.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7050,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    'INTERNET BANKING ANNUAL FEE');
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7050,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,
           r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         END IF;
        END IF; -- if ln_bakiye >= 0
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap_non_som;
     END IF;

     UPDATE CBS_FEE_TAH_EDILEMEYEN_ACCFEE
     SET TAHSIL_EDILEMEYEN = ln_kalan_tahsilat,
         TOPLAM_TAHSIL_TUTAR = MASRAF_TUTARI-ln_kalan_tahsilat
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.musteri_no
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF; --if ls_uygun = 'E' and ls_dk is not null
   END IF;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5130'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
PROCEDURE DCF_FILE_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
IS
 ls_filename   VARCHAR2(2000);
 ln_i NUMBER:=0;
 ls_ucpointer  VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
 ls_delimiter  VARCHAR2(3):=Pkg_Hata.getDELIMITER;
 ls_linebuf  VARCHAR2(2000);
 pdeger VARCHAR2(2000);
 ls_path VARCHAR2(2000);
 ls_path_2 VARCHAR2(2000);
 ls_hata_mesaj VARCHAR2(2000);

 ln_card_no      NUMBER;
 ls_card_type  VARCHAR2(1);
 ln_acc_no      NUMBER;
 ln_company_acc  NUMBER;
 ln_company_no  NUMBER;
 ls_company_name  VARCHAR2(40);
 ld_acf_date      DATE;
 ld_old_acf_date  DATE;
 ln_acf        NUMBER;
 ln_card_issue  NUMBER;
 ln_ls_card_issue NUMBER;
 ln_customer         NUMBER;
 ln_adet    NUMBER := 0;
 ls_renewal_flag  VARCHAR2(1);
 dosya_kopyalama_hatasi  EXCEPTION;
 ls_nls_log VARCHAR(40);
 ls_old_value VARCHAR(40);
BEGIN
 SELECT VALUE
 INTO ls_old_value
 FROM NLS_SESSION_PARAMETERS
 WHERE parameter='NLS_NUMERIC_CHARACTERS';

 dbms_session.set_nls('nls_numeric_characters',''',.''');

 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 ls_path := 'BS_OUT';
 ls_path_2 := 'BS_OUT_LOG';
 ls_filename := 'CARDFEE_'||TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD')||'.TXT';


--log_at('DCF_FILE_NAME','ls_filename',ls_filename);

 ln_i := 0;

 Pkg_Dosya.dosya_ac(ls_path,ls_filename,'r');
 BEGIN
  LOOP
   Pkg_Dosya.SatirAl(ls_linebuf);

   IF NVL(RTRIM(LTRIM(ls_linebuf)),'X') <> 'X'
   THEN
    ln_customer := TO_NUMBER(NVL(trim(SUBSTR(ls_linebuf,1,13)),'0'));
    ln_card_no := trim(SUBSTR(ls_linebuf,14,16));
    ls_card_type := trim(SUBSTR(ls_linebuf,30,1));
    ln_acc_no := TO_NUMBER(NVL(trim(SUBSTR(ls_linebuf,31,18)),'0'));
    ln_company_acc := TO_NUMBER(NVL(trim(SUBSTR(ls_linebuf,49,18)),'0'));
    ln_company_no := TO_NUMBER(NVL(trim(SUBSTR(ls_linebuf,67,7)),'0'));
    ls_company_name := trim(SUBSTR(ls_linebuf,74,40));
    ln_acf := TO_NUMBER(NVL(REPLACE(trim(SUBSTR(ls_linebuf,114,19)),'.',','),0));
    ln_card_issue := TO_NUMBER(NVL(REPLACE(trim(SUBSTR(ls_linebuf,133,19)),'.',','),0));
    ln_ls_card_issue := TO_NUMBER(NVL(REPLACE(trim(SUBSTR(ls_linebuf,152,19)),'.',','),0));
    ld_old_acf_date := TO_DATE(trim(SUBSTR(ls_linebuf,171,8)),'YYYYMMDD');
    ld_acf_date := TO_DATE(trim(SUBSTR(ls_linebuf,179,8)),'YYYYMMDD');
    ls_renewal_flag := trim(SUBSTR(ls_linebuf,187,1));

    SELECT COUNT(*)
    INTO ln_adet
    FROM   CBS_MUSTERI
    WHERE  musteri_no = ln_customer;

    IF ln_adet = 1
    THEN
     SELECT COUNT(*)
     INTO ln_adet
     FROM   CBS_ATM_CARD_FEE
     WHERE  yukleme_tarihi =  TRUNC(SYSDATE) AND
         musteri_no =  ln_customer AND
         kart_no = ln_card_no ;

     IF NVL( ln_adet,0) = 0 THEN
      INSERT INTO CBS_ATM_CARD_FEE
      (YUKLEME_TARIHI,KART_NO,CARD_TYPE,ACCOUNT_NO,COMPANY_ACCOUNT_NO,COMPANY_NO,
       COMPANY_NAME,ACF_DATE,ACF_FEE,CARD_ISSUE_FEE,LS_CARD_ISSUE_FEE,MUSTERI_NO,
       RENEWAL_FLAG,OLD_ACF_DATE)
      VALUES
      (TRUNC(SYSDATE),ln_card_no,ls_card_type,ln_acc_no,ln_company_acc,ln_company_no,
       ls_company_name,ld_acf_date,ln_acf,ln_card_issue,ln_ls_card_issue,ln_customer,
       ls_renewal_flag,ld_old_acf_date);
     ELSE
     log_at('hakan001','DOUBLE REC',ln_customer,ln_card_no);
     END IF;
    ELSE
     log_at('hakan001','NO CUSTOMER FOUND',ln_customer,ln_card_no);
    END IF;
    ln_i := ln_i + 1;
   END IF;
   END LOOP;
 dbms_session.set_nls('nls_numeric_characters',''''||ls_old_value||'''');

 COMMIT;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN
   COMMIT;
--Log_At('ACF_LOG','1');
 dbms_session.set_nls('nls_numeric_characters',''''||ls_old_value||'''');
   Pkg_Dosya.dosya_kapa('r');
 END;


 BEGIN
   pkg_dosya.kopyala( ls_path,ls_filename,ls_path_2,ls_filename);
 EXCEPTION
 WHEN OTHERS THEN
     Log_At('ACF_LOG','2',SQLERRM||' '|| SQLCODE || ' '|| SQLERRM);
     ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '6030' || ls_ucpointer);
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  END ;

     BEGIN
   PKG_DOSYA.DOSYA_SIL ( ls_path, ls_filename );
  EXCEPTION
  WHEN OTHERS THEN
   Log_At('ACF_LOG','3',SQLERRM||' '|| SQLCODE || ' '|| SQLERRM);
    ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '842' || ls_ucpointer);
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  END;

 ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '2050' || ls_delimiter || ls_filename||' '||'Kayit Adedi:'||TO_CHAR(ln_i)|| ls_delimiter || ls_ucpointer);
 Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);


 EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
 dbms_session.set_nls('nls_numeric_characters',''''||ls_old_value||'''');
 Log_At('ACF_LOG','4',SQLERRM||' '|| SQLCODE || ' '|| SQLERRM);
  IF NVL( ln_i ,0) = 0 THEN
   ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '777' ||  ls_delimiter || ls_filename|| ls_delimiter ||TO_CHAR(SQLCODE)||' '|| SUBSTR(TO_CHAR(SQLERRM),1,200)|| ls_delimiter|| ls_ucpointer);
  ELSE
   ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '2051' ||  ls_delimiter || ls_filename|| ls_delimiter ||TO_CHAR(SQLCODE)||' '|| SUBSTR(TO_CHAR(SQLERRM),1,200)|| ls_delimiter|| ls_ucpointer);
  END IF;
  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-------------------------------------------------------------------------------
PROCEDURE ATM_F1_FILE_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
 ln_dosya_no NUMBER;
 BEGIN
    --IF Pkg_Batch.ay_sonu_mu THEN   -- End of Month
  PKG_ATM_FILE.FILE_LOAD ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, 'F1.TXT' ,ln_dosya_no);
 --end if;

 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_F4_FILE_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
 ln_dosya_no NUMBER;
 BEGIN
    PKG_ATM_FILE.FILE_LOAD ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, 'F4.TXT' ,ln_dosya_no);

 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_F5_FILE_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
  ln_dosya_no NUMBER;
 BEGIN
    PKG_ATM_FILE.FILE_LOAD ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, 'F5.TXT' ,ln_dosya_no);

 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_OTMTHSL_FILE_UPDOWNLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
 ln_dosya_no  NUMBER;
 BEGIN
    PKG_ATM_FILE.GON_FILE_LOAD ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, 'OTMTHSL.GON',ln_dosya_no );

 END;
-----------------------------------------------------------------------------------------
PROCEDURE CASH_COLLATERAl_BLOKE_KALDIR(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
 BEGIN
    PKG_ATM_FILE.CASHCOLL_BLOKE_KALDIR ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD);

 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_WORKBLK_FILE_UPDOWNLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
IS
 ln_dosya_no NUMBER;
BEGIN
 PKG_ATM_FILE.sp_updownload_workblk ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD,'WORK.BLK',ln_dosya_no);
END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_CASHCOLLETERAL_DOWNLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
   ln_dosya_no NUMBER;
 BEGIN
 PKG_ATM_FILE.sp_download_cash_colleteral ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD,'CASH_COLLETERAL.TXT', ln_dosya_no);
 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_DEBITCLEARING_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
 IS
 ln_dosya_no NUMBER;
 BEGIN
    PKG_ATM_FILE.sp_upload_debit_clearing ( PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD,'DEBIT_CLEARING.TXT',ln_dosya_no);
 END;
-----------------------------------------------------------------------------------------
PROCEDURE ATM_VISA_BLOKE_COZ(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
IS
CURSOR cur_bloke IS
 SELECT  *
 FROM CBS_BLOKE
 WHERE durum_kodu = 'A' AND
    bloke_neden_kodu IN( '8','9', '55') AND --sevalb 11122007     --CQ4797 MederT 16122015
    TRUNC(bloke_bitis_tarihi) <= pkg_muhasebe.banka_tarihi_bul;

 CURSOR cur_islem IS
   SELECT
  pkg_muhasebe.banka_tarihi_bul kayit_tarih,
  SYSDATE kayit_sistem_tarihi,
  pkg_baglam.Kullanici_kodu kayit_kullanici_kodu,
  pkg_baglam.bolum_kodu kayit_kullanici_bolum_kodu,
  pkg_muhasebe.banka_tarihi_bul dogru_tarih ,
  pkg_baglam.Kullanici_kodu dogru_kullanici_kodu,
  pkg_baglam.bolum_kodu dogru_kullanici_bolum_kodu,
  pkg_muhasebe.banka_tarihi_bul onay_tarih,
  SYSDATE onay_sistem_tarihi,
  pkg_baglam.Kullanici_kodu onay_kullanici_kodu,
  pkg_baglam.bolum_kodu onay_kullanici_bolum_kodu
  FROM dual;

  r_islem        cur_islem%ROWTYPE;
  r_bloke        cur_bloke%ROWTYPE;
  ls_hesap_doviz      VARCHAR2(3);
  ln_musteri_no       NUMBER;
  ls_aciklama                 VARCHAR2 (2000) := 'VISA Debit Card Blocking Release' ;
  ls_bloke_neden              CBS_BLOKE_NEDEN_KODLARI.bloke_neden_kodu%TYPE := '8';
  ls_bloke_referans     VARCHAR2(100);
  ln_hesap_no      NUMBER;
  ls_hata_mesaj      VARCHAR2(2000);
  ls_ucpointer      VARCHAR2(3):=pkg_hata.getucpointer;
  ls_delimiter      VARCHAR2(3):=pkg_hata.getdelimiter;
  ln_dosya_no             NUMBER   := pkg_genel.genel_kod_al( 'ATM_DOSYA_NO');
  ls_err         VARCHAR2(100);
  ln_i          NUMBER := 0;
  ln_bloke_tutari       NUMBER;
BEGIN
   pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   IF TRUNC(pkg_muhasebe.Banka_Tarihi_Bul) = TRUNC(SYSDATE) THEN -- Only in business days

   pkg_baglam.Batch;
   FOR c_islem IN cur_islem  LOOP
    r_islem := c_islem ;
  END LOOP;

    FOR c_bloke IN cur_bloke LOOP
       IF  c_bloke.bloke_referans IS NOT NULL THEN
        ln_i := ln_i + 1;
        ls_bloke_referans := c_bloke.bloke_referans;
     ln_bloke_tutari  := c_bloke.bloke_tutari;
   IF  pkg_bloke.sf_bloke_durum_kodu_al(c_bloke.bloke_referans) != 'K' THEN
     ls_hesap_doviz     := pkg_hesap.HesaptanDovizKoduAl(c_bloke.HESAP_NO);
     ln_musteri_no      := pkg_hesap.HesaptanMusteriNoAl(c_bloke.HESAP_NO);
     ln_hesap_no      := c_bloke.hesap_no;
    --mevcut bloke kapama amacli cagrilir.
          BEGIN
        pkg_bloke.sp_bloke_yarat (
             ps_bloke_referans => c_bloke.bloke_referans,
             pn_musteri_no =>ln_musteri_no ,
             pn_HESAP_NO=>c_bloke.HESAP_NO,
             ps_DOVIZ_KODU=> ls_hesap_doviz,
             pn_BLOKE_TUTARI=>0,
             ps_BLOKE_NEDEN_KODU=>ls_bloke_neden,
             ps_ACIKLAMA=>ls_aciklama,
             pd_BLOKE_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
             pd_BLOKE_BITIS_TARIHI=>pkg_muhasebe.banka_tarihi_bul,
             pn_tx_no=> NULL,
             p_COZ_KAYIT_TARIH =>r_islem.kayit_tarih,
             p_COZ_KAYIT_SISTEM_TARIH=>r_islem.kayit_sistem_tarihi,
             p_COZ_KAYIT_KULLANICI_KODU=>r_islem.kayit_kullanici_kodu,
             p_COZ_KAYIT_KULLANICI_BOLUMKOD=>r_islem.kayit_kullanici_bolum_kodu,
             p_COZ_DOGRU_TARIH=>r_islem.dogru_tarih,
             p_COZ_DOGRU_KULLANICI_KODU=>r_islem.dogru_kullanici_kodu,
             p_COZ_DOGRU_KULLANICI_BOLUMKOD=>r_islem.dogru_kullanici_bolum_kodu,
             p_COZ_ONAY_TARIH=>r_islem.onay_tarih,
             p_COZ_ONAY_SISTEM_TARIH=>r_islem.onay_sistem_tarihi,
             p_COZ_ONAY_KULLANICI_KODU=>r_islem.onay_kullanici_kodu,
             p_COZ_ONAY_KULLANICI_BOLUMKOD=>r_islem.onay_kullanici_bolum_kodu,
             ps_kapama=>'KAPAMA');

     INSERT INTO CBS_ATM_BLOKE_OTOMATIK_COZ(DOSYA_NO, SIRA_NO, BATCH_GRUP_NO, BATCH_LOG_NO, BANKA_TARIHI, BLOKE_REFERANS, DOVIZ_KODU, BLOKE_TUTARI)
     VALUES ( ln_DOSYA_NO,ln_i, pn_GRUP_NO, pn_LOG_NO,pkg_muhasebe.Banka_Tarihi_Bul, ls_BLOKE_REFERANS, ls_hesap_doviz, ln_BLOKE_TUTARI);

     ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '1581' || ls_delimiter || ln_hesap_no||ls_delimiter ||ls_bloke_referans||  ls_delimiter ||ls_ucpointer);
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);

    EXCEPTION WHEN OTHERS THEN
     ls_err    := '1580';
     ls_hata_mesaj := Pkg_Hata.GenerateMessage(ls_ucpointer || '1580' || ls_delimiter || 'Bloke Referance:' || ls_bloke_referans|| ' '|| SQLCODE || ' '|| SQLERRM||' '|| ls_delimiter || ls_ucpointer);

     INSERT INTO CBS_ATM_BLOKE_OTOMATIK_COZ(DOSYA_NO, SIRA_NO, BATCH_GRUP_NO, BATCH_LOG_NO, BANKA_TARIHI, BLOKE_REFERANS, DOVIZ_KODU, BLOKE_TUTARI,hata_mesaj)
     VALUES ( ln_DOSYA_NO,ln_i, pn_GRUP_NO, pn_LOG_NO,pkg_muhasebe.Banka_Tarihi_Bul, ls_BLOKE_REFERANS, ls_hesap_doviz, ln_BLOKE_TUTARI,ls_hata_mesaj);
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_hata_mesaj);
     Pkg_Atm_file.sp_error_log(  'OTMBLKCOZ',
                 ln_dosya_no,
                ln_i ,
                      'ATM_VISA_BLOKE_COZ',
                  ls_err       ,
                  ls_hata_mesaj ,
               ls_bloke_referans   ,
               NULL,
               ln_hesap_no,
               SYSDATE,
               pkg_muhasebe.Banka_Tarihi_Bul,
               ls_hesap_doviz,
               ln_bloke_tutari,
              NULL,NULL,NULL,NULL);

       END;
     END IF;

   END IF;
  END LOOP;

     COMMIT;
 END IF; -- Only in business days
     pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
 END;
-----------------------------------------------------------------------------------------
  PROCEDURE clearing_valor_muhasebe(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

   ln_islem_no       CBS_FIS.ISLEM_NUMARA%TYPE;
 ln_fis_no       CBS_FIS.NUMARA%TYPE;
 Islem_Bulunamadi_Exception   EXCEPTION;

 CURSOR islem_cursor IS
  SELECT CBS_FIS.ISLEM_NUMARA,CBS_FIS.NUMARA
   FROM CBS_FIS,CBS_ISLEM
   WHERE CBS_FIS.ISLEM_NUMARA=CBS_ISLEM.numara
   AND CBS_FIS.tur='T'
   AND CBS_ISLEM.ISLEM_KOD IN (3555)
   AND CBS_FIS.GECERLI_OLDUGU_TARIH=Pkg_Muhasebe.BANKA_TARIHI_BUL
   ORDER BY CBS_ISLEM.ISLEM_KOD DESC;

  BEGIN
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 --Valor gunu bugun olan gecici fisileri bul gecicileri iptal et gercekleri yarat

 OPEN islem_cursor;
 FETCH islem_cursor INTO ln_islem_no, ln_fis_no;
   WHILE NOT islem_cursor%NOTFOUND
 LOOP
     BEGIN
   --Muhasebelestir
  Pkg_Tx.MUHASEBELESTIR(ln_islem_no);
  --Eski Fisi iptal Et
  Pkg_Muhasebe.GECICI_FIS_IPTAL(ln_fis_no);
  EXCEPTION
       WHEN OTHERS THEN
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
     ROLLBACK;
    END ;

  COMMIT;
   FETCH islem_cursor INTO ln_islem_no, ln_fis_no;
    END LOOP;
    CLOSE islem_cursor;

   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
  ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;

---------------------------------------------------------------------------------------------------------
PROCEDURE KMH_FAIZ_TAHAKKUK_TAHSIL (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

 ld_donemin_son_is_gunu DATE := Pkg_Tarih.donemin_son_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);
 ld_ayin_son_is_gunu    DATE := Pkg_Tarih.ayin_son_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);
 ld_yilin_son_is_gunu   DATE :=Pkg_Tarih.yilin_son_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);

 CURSOR c_hesap_bolum IS
   SELECT DISTINCT SUBE_KODU
      FROM CBS_HESAP
      WHERE (NVL(BIRIKMIS_FAIZ_NEG,0)<>0 OR NVL(GECMIS_AYLARIN_FAIZI_NEG,0) <> 0)
   AND durum_kodu = 'A'
      AND ((ld_ayin_son_is_gunu=Pkg_Muhasebe.Banka_Tarihi_Bul
           AND NVL(OVD_INTEREST_PAYMENT_PERIOD,'MONTHLY')='MONTHLY') --sevalb 06052011 SDLC17696 nvl  MONTHLY eklendi
          OR
          (ld_donemin_son_is_gunu=Pkg_Muhasebe.Banka_Tarihi_Bul
           AND OVD_INTEREST_PAYMENT_PERIOD='QUARTERLY')
          OR
          (ld_yilin_son_is_gunu=Pkg_Muhasebe.Banka_Tarihi_Bul
           AND OVD_INTEREST_PAYMENT_PERIOD='YEARLY')
        );
   r_hesap_bolum  c_hesap_bolum%ROWTYPE;

    CURSOR c_hesap IS
   SELECT *
      FROM CBS_HESAP
      WHERE ( NVL(BIRIKMIS_FAIZ_NEG,0)<>0 OR NVL(GECMIS_AYLARIN_FAIZI_NEG,0) <> 0 )
   AND durum_kodu = 'A'


   AND sube_kodu=r_hesap_bolum.sube_kodu
      AND (-- Peryoduna gore Tahakkuk tarihi gelmis olan hesaplar
          (ld_ayin_son_is_gunu=Pkg_Muhasebe.Banka_Tarihi_Bul
           AND NVL(OVD_INTEREST_PAYMENT_PERIOD,'MONTHLY')='MONTHLY') --sevalb 06052011 SDLC17696 nvl  MONTHLY eklendi
          OR
          (ld_donemin_son_is_gunu =Pkg_Muhasebe.Banka_Tarihi_Bul
           AND OVD_INTEREST_PAYMENT_PERIOD='QUARTERLY')
          OR
          (ld_yilin_son_is_gunu =Pkg_Muhasebe.Banka_Tarihi_Bul
           AND OVD_INTEREST_PAYMENT_PERIOD='YEARLY')
        )
   FOR UPDATE;

 r_hesap  c_hesap%ROWTYPE;

 ln_A NUMBER;
 ln_B NUMBER;
 ln_C NUMBER;
 ln_islem_kod NUMBER;
 ln_islem_no NUMBER;
 ln_fis_no NUMBER;

 ld_banka_tarihi DATE;
 ln_KKDF_ORANI NUMBER;
 ln_BSMV_ORANI NUMBER;
 ln_alinan_KKDF NUMBER;
 ln_alinan_BSMV NUMBER;
 ls_bsmv_dk_no CBS_DKHESAP.NUMARA%TYPE;
 ls_KKDF_dk_no CBS_DKHESAP.NUMARA%TYPE;
 ls_ILISKILI_FAIZ_DK CBS_GRUP_URUN_SINIF.DK_HESABI_7%TYPE;
 ls_ILISKILI_TAHAKKUK_DK  CBS_GRUP_URUN_SINIF.DK_HESABI_10%TYPE;
 ls_dk_10  CBS_GRUP_URUN_SINIF.DK_HESABI_10%TYPE;
 exception_iliskili_DK_null EXCEPTION;
 ln_hesap_iliskili_DK_yok NUMBER;

 varchar_list     Pkg_Muhasebe.varchar_array;
 number_list      Pkg_Muhasebe.number_array;
 date_list      Pkg_Muhasebe.date_array;
 boolean_list     Pkg_Muhasebe.boolean_array;

    p_5213_HESAP_SUBE NUMBER;
    p_5213_ISLEM_SUBE NUMBER;
    p_5213_VADESIZ_HESAP NUMBER;
    p_5213_REFERANS NUMBER;
    p_5213_ILISKILI_FAIZ_DK NUMBER;
    p_5213_ILISKILI_TAHAKKUK_DK NUMBER;
    p_5213_dk_10 NUMBER;
    p_5213_BIRIKMIS_FAIZ_NEG NUMBER;
 p_5213_BIRIKMIS_FAIZ_NEG_LC NUMBER;
 p_5213_DOVIZ_KODU NUMBER;
    p_5213_A_TUTARI NUMBER;
    p_5213_B_TUTARI NUMBER;
    p_5213_B_TUTARI_ABS NUMBER;
    p_5213_VERGI_TUTARI NUMBER;
    p_5213_FON_TUTARI NUMBER;
    p_5213_BANKA_ACIKLAMA NUMBER;
    p_5213_MUSTERI_ACIKLAMA NUMBER;
    p_5213_VERGI_ACIKLAMA NUMBER;
    p_5213_FAIZ_ACIKLAMA NUMBER;
 p_5213_KUR    NUMBER;
 ln_kalan_bakiye  NUMBER;
 ln_TAHSIL_EDILEN_FAIZ_TP  NUMBER;
 ln_TAHSIL_EDILEN_FAIZ_YP  NUMBER;
 ln_KMH_TAHAKKUK_VERGI_TUTARI  NUMBER;
 ln_KMH_TAHAKKUK_TUTARI  NUMBER;
 ln_BIRIKMIS_FAIZ_NEG  NUMBER;
 ln_counter  NUMBER;
 ln_dk_grup_kod   NUMBER;
   p_5213_VERGI_TOPLAM_LC NUMBER;
   p_5213_VERGI_TOPLAM_FC NUMBER;
   ln_rate_sales_tax    NUMBER := 0;
 -- B-O-M sevalb 20052011 gecmis aylarin faizi ayri dk ya kesilecek
    p_5213_GECMIS_AY_FAIZ_NEG NUMBER;        --5213_GECMIS_AY_FAIZ_NEG
    p_5213_GECMIS_AY_FAIZ_NEG_LC NUMBER;        --5213_GECMIS_AY_FAIZ_NEG_LC
    p_5213_FAIZ_TOPLAM NUMBER;        --5213_FAIZ_TOPLAM
    p_5213_FAIZ_TOPLAM_LC NUMBER;        --5213_FAIZ_TOPLAM_LC
    p_5213_FAIZ_REESKONT_DK NUMBER;        --5213_FAIZ_REESKONT_DK
    p_5213_VERGI_BIRIKMIS_FC NUMBER;        --5213_VERGI_BIRIKMIS_FC
    p_5213_VERGI_BIRIKMIS_LC NUMBER;        --5213_VERGI_BIRIKMIS_LC
    p_5213_VERGI_GECENAY_FC NUMBER;        --5213_VERGI_GECENAY_FC
    p_5213_VERGI_GECENAY_LC NUMBER;        --5213_VERGI_GECENAY_LC
    ls_reeskont_dk                     VARCHAR2(200):='';
    iliskili_reeskont_dk_yok         EXCEPTION;
-- E-O-M sevalb 20052011 gecmis aylarin faizi ayri dk ya kesilecek

-- B-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 
    p_5213_IS_OVERDRAFT_AT_LIMIT  NUMBER;
    p_5213_INTEREST_GL  NUMBER;
    p_5213_INTEREST_OVER_LIMIT_LC NUMBER;
    p_5213_INTEREST_OVER_LIMIT_FC NUMBER;
    p_5213_TAX_OVER_LIMIT_LC NUMBER;
    p_5213_TAX_OVER_LIMIT_FC NUMBER;
    ln_balance   NUMBER;
    ls_interest_dk varchar2(30);
-- E-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 

BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 ln_islem_kod :=5213;
 ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;

 Pkg_Parametre.deger('G_BSMV',ls_bsmv_dk_no );
 Pkg_Parametre.deger('G_DK_39022000',ls_KKDF_dk_no);

 p_5213_HESAP_SUBE := Pkg_Muhasebe.parametre_index_bul('5213_HESAP_SUBE');
 p_5213_ISLEM_SUBE := Pkg_Muhasebe.parametre_index_bul('5213_ISLEM_SUBE');
 p_5213_VADESIZ_HESAP := Pkg_Muhasebe.parametre_index_bul('5213_VADESIZ_HESAP');
 p_5213_REFERANS := Pkg_Muhasebe.parametre_index_bul('5213_REFERANS');
 p_5213_ILISKILI_FAIZ_DK := Pkg_Muhasebe.parametre_index_bul('5213_ILISKILI_FAIZ_DK');
 p_5213_ILISKILI_TAHAKKUK_DK := Pkg_Muhasebe.parametre_index_bul('5213_ILISKILI_TAHAKKUK_DK');
 p_5213_dk_10 := Pkg_Muhasebe.parametre_index_bul('5213_dk_10');
 p_5213_BIRIKMIS_FAIZ_NEG := Pkg_Muhasebe.parametre_index_bul('5213_BIRIKMIS_FAIZ_NEG');
 p_5213_A_TUTARI := Pkg_Muhasebe.parametre_index_bul('5213_A_TUTARI');
 p_5213_B_TUTARI := Pkg_Muhasebe.parametre_index_bul('5213_B_TUTARI');
 p_5213_B_TUTARI_ABS := Pkg_Muhasebe.parametre_index_bul('5213_B_TUTARI_ABS');
 p_5213_VERGI_TUTARI := Pkg_Muhasebe.parametre_index_bul('5213_VERGI_TUTARI');
 p_5213_FON_TUTARI := Pkg_Muhasebe.parametre_index_bul('5213_FON_TUTARI');
 p_5213_BANKA_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_BANKA_ACIKLAMA');
 p_5213_MUSTERI_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_MUSTERI_ACIKLAMA');
 p_5213_VERGI_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_VERGI_ACIKLAMA');
 p_5213_FAIZ_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('5213_FAIZ_ACIKLAMA');
 p_5213_BIRIKMIS_FAIZ_NEG_LC := Pkg_Muhasebe.parametre_index_bul('5213_BIRIKMIS_FAIZ_NEG_LC');
 p_5213_DOVIZ_KODU := Pkg_Muhasebe.parametre_index_bul('5213_DOVIZ_KODU');
 p_5213_KUR:= Pkg_Muhasebe.parametre_index_bul('5213_KUR');

-- B-O-M sevalb 20052011 gecmis aylarin faizi ayri dk ya kesilecek
p_5213_VERGI_TOPLAM_LC := Pkg_Muhasebe.parametre_index_bul('5213_VERGI_TOPLAM_LC');
p_5213_VERGI_TOPLAM_FC := Pkg_Muhasebe.parametre_index_bul('5213_VERGI_TOPLAM_FC');
p_5213_GECMIS_AY_FAIZ_NEG := pkg_muhasebe.parametre_index_bul('5213_GECMIS_AY_FAIZ_NEG');
p_5213_GECMIS_AY_FAIZ_NEG_LC := pkg_muhasebe.parametre_index_bul('5213_GECMIS_AY_FAIZ_NEG_LC');
p_5213_FAIZ_TOPLAM := pkg_muhasebe.parametre_index_bul('5213_FAIZ_TOPLAM');
p_5213_FAIZ_TOPLAM_LC := pkg_muhasebe.parametre_index_bul('5213_FAIZ_TOPLAM_LC');
p_5213_FAIZ_REESKONT_DK := pkg_muhasebe.parametre_index_bul('5213_FAIZ_REESKONT_DK');
p_5213_VERGI_BIRIKMIS_FC := pkg_muhasebe.parametre_index_bul('5213_VERGI_BIRIKMIS_FC');
p_5213_VERGI_BIRIKMIS_LC := pkg_muhasebe.parametre_index_bul('5213_VERGI_BIRIKMIS_LC');
p_5213_VERGI_GECENAY_FC := pkg_muhasebe.parametre_index_bul('5213_VERGI_GECENAY_FC');
p_5213_VERGI_GECENAY_LC := pkg_muhasebe.parametre_index_bul('5213_VERGI_GECENAY_LC');

-- E-O-M sevalb 20052011 gecmis aylarin faizi ayri dk ya kesilecek

-- B-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 
p_5213_IS_OVERDRAFT_AT_LIMIT  := Pkg_Muhasebe.parametre_index_bul('5213_IS_OVERDRAFT_AT_LIMIT');
p_5213_INTEREST_GL   := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_GL');
p_5213_INTEREST_OVER_LIMIT_LC := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_OVER_LIMIT_LC');
p_5213_INTEREST_OVER_LIMIT_FC := Pkg_Muhasebe.parametre_index_bul('5213_INTEREST_OVER_LIMIT_FC');
p_5213_TAX_OVER_LIMIT_LC := Pkg_Muhasebe.parametre_index_bul('5213_TAX_OVER_LIMIT_LC');
p_5213_TAX_OVER_LIMIT_FC := Pkg_Muhasebe.parametre_index_bul('5213_TAX_OVER_LIMIT_FC');
-- E-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 

 varchar_list(p_5213_HESAP_SUBE) := '';
 varchar_list(p_5213_ISLEM_SUBE) := '';
 varchar_list(p_5213_VADESIZ_HESAP) := '';
 varchar_list(p_5213_REFERANS) := '';
 varchar_list(p_5213_ILISKILI_FAIZ_DK) := '';
 varchar_list(p_5213_ILISKILI_TAHAKKUK_DK) := '';
varchar_list(p_5213_FAIZ_ACIKLAMA) := '';
 varchar_list(p_5213_VERGI_ACIKLAMA) :='';

 varchar_list(p_5213_dk_10) := '';
 number_list(p_5213_BIRIKMIS_FAIZ_NEG) := 0;
 number_list(p_5213_A_TUTARI) := 0;
 number_list(p_5213_B_TUTARI) := 0;
 number_list(p_5213_B_TUTARI_ABS) := 0;
 number_list(p_5213_VERGI_TUTARI) := 0;
 number_list(p_5213_FON_TUTARI) := 0;
 varchar_list(p_5213_BANKA_ACIKLAMA) := '';
 varchar_list(p_5213_MUSTERI_ACIKLAMA) := '';
 number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC) := 0;
 number_list(p_5213_KUR) := 0;
 number_list(p_5213_VERGI_TOPLAM_LC) := 0;
 number_list(p_5213_VERGI_TOPLAM_FC) := 0;
-- B-O-M sevalb 20052011
number_list(p_5213_GECMIS_AY_FAIZ_NEG) := 0;
number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC) := 0;
number_list(p_5213_FAIZ_TOPLAM) := 0;
number_list(p_5213_FAIZ_TOPLAM_LC) := 0;
varchar_list(p_5213_FAIZ_REESKONT_DK) := '';
number_list(p_5213_VERGI_BIRIKMIS_FC) := 0;
number_list(p_5213_VERGI_BIRIKMIS_LC) := 0;
number_list(p_5213_VERGI_GECENAY_FC) := 0;
number_list(p_5213_VERGI_GECENAY_LC) := 0;

-- E-O-M sevalb 20052011

-- B-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 
boolean_list(p_5213_IS_OVERDRAFT_AT_LIMIT) := FALSE;
varchar_list(p_5213_INTEREST_GL) := '';
number_list(p_5213_INTEREST_OVER_LIMIT_FC) := 0;
number_list(p_5213_INTEREST_OVER_LIMIT_LC) := 0;
number_list(p_5213_TAX_OVER_LIMIT_FC) := 0;
number_list(p_5213_TAX_OVER_LIMIT_LC) := 0;
-- E-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 

 OPEN c_hesap_bolum;
 LOOP
  FETCH c_hesap_bolum INTO r_hesap_bolum;
  EXIT WHEN c_hesap_bolum%NOTFOUND;

  ln_fis_no:=NULL;
  ln_islem_no:=NULL;
  ln_islem_no:=Pkg_Batch.Islem_Yarat(ln_islem_kod,r_hesap_bolum.sube_kodu);

  OPEN c_hesap;
  LOOP
   FETCH c_hesap INTO r_hesap;
   EXIT WHEN c_hesap%NOTFOUND;
   varchar_list(p_5213_HESAP_SUBE) := r_hesap.sube_kodu;
   varchar_list(p_5213_ISLEM_SUBE) := r_hesap.sube_kodu;
   varchar_list(p_5213_VADESIZ_HESAP) := r_hesap.hesap_no;
   varchar_list(p_5213_REFERANS) := r_hesap.hesap_no;

    number_list(p_5213_BIRIKMIS_FAIZ_NEG) := 0;
    number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC) := 0;
    number_list(p_5213_VERGI_TOPLAM_LC) :=0;
    number_list(p_5213_VERGI_TOPLAM_FC) :=0;

-- B-O-M sevalb 20052011
    number_list(p_5213_GECMIS_AY_FAIZ_NEG) := 0;
    number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC) := 0;
    number_list(p_5213_FAIZ_TOPLAM) := 0;
    number_list(p_5213_FAIZ_TOPLAM_LC) := 0;
    varchar_list(p_5213_FAIZ_REESKONT_DK) := '';
    number_list(p_5213_VERGI_BIRIKMIS_FC) := 0;
    number_list(p_5213_VERGI_BIRIKMIS_LC) := 0;
    number_list(p_5213_VERGI_GECENAY_FC) := 0;
    number_list(p_5213_VERGI_GECENAY_LC) := 0;

-- E-O-M sevalb 20052011

-- B-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 
    boolean_list(p_5213_IS_OVERDRAFT_AT_LIMIT) := FALSE;
    varchar_list(p_5213_INTEREST_GL) := '';
    number_list(p_5213_INTEREST_OVER_LIMIT_FC) := 0;
    number_list(p_5213_INTEREST_OVER_LIMIT_LC) := 0;
    number_list(p_5213_TAX_OVER_LIMIT_FC) := 0;
    number_list(p_5213_TAX_OVER_LIMIT_LC) := 0;
-- E-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 

/*
   SELECT DK_HESABI_7, DK_HESABI_8
   INTO   ls_ILISKILI_FAIZ_DK, ls_ILISKILI_TAHAKKUK_DK
   FROM   CBS_GRUP_URUN_SINIF
   WHERE GRUP_KOD= (SELECT DK_GRUP_KOD FROM CBS_MUSTERI WHERE musteri_no=r_hesap.musteri_no)
   AND   MODUL_TUR_KOD=r_hesap.MODUL_TUR_KOD
   AND   URUN_TUR_KOD=r_hesap.URUN_TUR_KOD
   AND   URUN_SINIF_KOD=r_hesap.URUN_SINIF_KOD ;
*/

   SELECT DK_GRUP_KOD
   INTO ln_dk_grup_kod
   FROM CBS_MUSTERI
   WHERE musteri_no=r_hesap.musteri_no;

   Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_hesap.MODUL_TUR_KOD, r_hesap.urun_tur_kod,r_hesap.urun_sinif_kod,
                       7, NULL, NULL, NULL,ls_ILISKILI_FAIZ_DK);
  --sevalb 260607
  /* Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_hesap.MODUL_TUR_KOD, r_hesap.urun_tur_kod,r_hesap.urun_sinif_kod,
                       10, NULL, NULL, NULL,ls_ILISKILI_TAHAKKUK_DK);

   Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_hesap.MODUL_TUR_KOD, r_hesap.urun_tur_kod,r_hesap.urun_sinif_kod,
        10, NULL, NULL, NULL,ls_dk_10);
   */

   IF ls_ILISKILI_FAIZ_DK IS NULL   -- OR ls_ILISKILI_TAHAKKUK_DK IS NULL OR    ls_dk_10 IS NULL --sevalb 260607
   THEN
    ln_hesap_iliskili_DK_yok:=r_hesap.hesap_no;
    RAISE exception_iliskili_DK_null;
   END IF;

   SELECT  TAHSIL_EDILEN_FAIZ_LC,
     TAHSIL_EDILEN_FAIZ_FC,
    NVL(BIRIKMIS_FAIZ_NEG,0) ,
     NVL(GECMIS_AYLARIN_FAIZI_NEG,0)         --sevalb 20052011 ayri ayri degiskenlere atanacak sekle getirildi --nvl(BIRIKMIS_FAIZ_NEG,0) + nvl(GECMIS_AYLARIN_FAIZI_NEG,0)  --sevalb 270607 gecmis ay eklendi
   INTO  ln_TAHSIL_EDILEN_FAIZ_TP,
      ln_TAHSIL_EDILEN_FAIZ_YP,
      ln_BIRIKMIS_FAIZ_NEG,
      number_list(p_5213_GECMIS_AY_FAIZ_NEG)    --sevalb 20052011
   FROM CBS_HESAP
   WHERE hesap_no=r_hesap.hesap_no;

   varchar_list(p_5213_ILISKILI_FAIZ_DK) := ls_ILISKILI_FAIZ_DK;
   varchar_list(p_5213_ILISKILI_TAHAKKUK_DK) := ls_ILISKILI_TAHAKKUK_DK;
   varchar_list(p_5213_dk_10) := ls_dk_10;

   --Bakiye Karakteri 'N' yapiliyor.
   UPDATE CBS_HESAP_BAKIYE
   SET BAKIYE_KARAKTERI='N'
   WHERE hesap_no=r_hesap.hesap_no;

   -- B tutari
   ln_B:=ROUND(NVL(Pkg_Hesap.HesapBakiyeAl(r_hesap.hesap_no),0)-
      NVL(Pkg_Hesap.Bloke_Tutari_Al(r_hesap.hesap_no),0)
      -- +NVL(r_hesap.DESTEK_HESAP_LIMITI,0)
      ,2);

   ln_A:=0;
   ln_KKDF_ORANI:=0;
   ln_BSMV_ORANI:=0;
   ln_alinan_KKDF:=0;
   ln_alinan_BSMV:=0;

   number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC) :=pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,number_list(p_5213_GECMIS_AY_FAIZ_NEG),1,NULL,NULL,'N','A'));--Sevalb 20052011
---b-o-m sevalb 20052011
--reeskont dk bulmaca

IF NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG),0) <> 0 THEN

    Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_hesap.modul_tur_kod, r_hesap.urun_tur_kod,r_hesap.urun_sinif_kod, 8, NULL, NULL, NULL,ls_reeskont_dk);
       IF  ls_reeskont_dk IS NULL THEN
          RAISE iliskili_reeskont_dk_yok;
      END IF;
  varchar_list(P_5213_FAIZ_REESKONT_DK):= ls_reeskont_dk;
 END IF;
---b-o-m sevalb 20052011

   number_list(p_5213_BIRIKMIS_FAIZ_NEG) := NVL(ln_BIRIKMIS_FAIZ_NEG,0);
   number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC) :=pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,NVL(ln_BIRIKMIS_FAIZ_NEG,0),1,NULL,NULL,'N','A'));--Sevalb 260607
   number_list( p_5213_FAIZ_TOPLAM):=   NVL(number_list(p_5213_BIRIKMIS_FAIZ_NEG),0)  + NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG),0); --sevalb 20052011
   number_list( p_5213_FAIZ_TOPLAM_LC):=   NVL(number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC),0)  + NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC),0); --sevalb 20052011
   number_list(p_5213_KUR ) :=pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,1,1,NULL,NULL,'N','A');--Sevalb 260607
   number_list(p_5213_A_TUTARI) := NVL(ln_A,0);
   number_list(p_5213_B_TUTARI) := NVL(ln_B,0);
   number_list(p_5213_B_TUTARI_ABS) := ABS(NVL(ln_B,0));
   number_list(p_5213_VERGI_TUTARI) := NVL(ln_alinan_BSMV,0);
   number_list(p_5213_FON_TUTARI) := NVL(ln_alinan_KKDF,0);
   varchar_list(p_5213_DOVIZ_KODU) := r_hesap.doviz_kodu;
--B-O-M Sevalb 18022011 SDLC12435_ovd_interest_Accrual
    ln_rate_sales_tax := 0;
    Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate_sales_tax);

    number_list(p_5213_VERGI_BIRIKMIS_FC) := ROUND((( number_list(p_5213_BIRIKMIS_FAIZ_NEG)*ln_rate_sales_tax)/100),2);
    number_list(p_5213_VERGI_BIRIKMIS_LC) := ROUND((( number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC)*ln_rate_sales_tax)/100),2);
    number_list(p_5213_VERGI_GECENAY_FC) := ROUND((( number_list(p_5213_GECMIS_AY_FAIZ_NEG)*ln_rate_sales_tax)/100),2);
    number_list(p_5213_VERGI_GECENAY_LC) := ROUND((( number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC)*ln_rate_sales_tax)/100),2);

    number_list(p_5213_VERGI_TOPLAM_FC) := NVL(number_list(p_5213_VERGI_BIRIKMIS_FC),0) + NVL( number_list(p_5213_VERGI_GECENAY_FC),0);
    number_list(p_5213_VERGI_TOPLAM_LC) :=  NVL(number_list(p_5213_VERGI_BIRIKMIS_lC),0) + NVL( number_list(p_5213_VERGI_GECENAY_lC),0);
--E-O-M Sevalb 18022011 SDLC12435_ovd_interest_Accrual

-- B-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 
    ln_balance := trunc(pkg_hesap.kullanilabilir_bakiye_al(r_hesap.hesap_no),2);


    IF ln_balance >= (number_list( p_5213_FAIZ_TOPLAM) + number_list(p_5213_VERGI_TOPLAM_FC)) AND ln_balance > 0 THEN
    -- when balance is enough to pay off the accrued interest and tax
        boolean_list(p_5213_IS_OVERDRAFT_AT_LIMIT) := FALSE;

    ELSE

        boolean_list(p_5213_IS_OVERDRAFT_AT_LIMIT) := TRUE;
        IF ln_balance <= 0 THEN
            -- when the limit is fully used
            number_list(p_5213_INTEREST_OVER_LIMIT_FC) := number_list( p_5213_FAIZ_TOPLAM);
            number_list(p_5213_TAX_OVER_LIMIT_FC) := number_list(p_5213_VERGI_TOPLAM_FC);
            number_list( p_5213_FAIZ_TOPLAM) := 0;
            number_list(p_5213_VERGI_TOPLAM_FC) := 0;
        ELSE
        -- calculate partial interest and tax to be deducted from account 
        -- and remaining amount of interest is taken from accrual GL 
            number_list( p_5213_FAIZ_TOPLAM):= ROUND(((ln_balance*100)/(100+ln_rate_sales_tax)),2);

            number_list(p_5213_VERGI_TOPLAM_FC) := ln_balance - number_list( p_5213_FAIZ_TOPLAM);

            number_list(p_5213_INTEREST_OVER_LIMIT_FC) := NVL(number_list(p_5213_BIRIKMIS_FAIZ_NEG),0)  + NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG),0) - number_list( p_5213_FAIZ_TOPLAM);

            number_list(p_5213_TAX_OVER_LIMIT_FC) := NVL(number_list(p_5213_VERGI_BIRIKMIS_FC),0) + NVL( number_list(p_5213_VERGI_GECENAY_FC),0) - number_list(p_5213_VERGI_TOPLAM_FC);
        END IF;
        
        -- depending on currency the amount are converted to appropriate currency
        IF r_hesap.doviz_kodu = pkg_genel.lc_al THEN
            number_list(p_5213_FAIZ_TOPLAM_LC) := number_list( p_5213_FAIZ_TOPLAM);
            number_list(p_5213_VERGI_TOPLAM_LC) := number_list(p_5213_VERGI_TOPLAM_FC);
            number_list(p_5213_INTEREST_OVER_LIMIT_LC) := number_list(p_5213_INTEREST_OVER_LIMIT_FC);
            number_list(p_5213_TAX_OVER_LIMIT_LC) := number_list(p_5213_TAX_OVER_LIMIT_FC);
        ELSE
            number_list( p_5213_FAIZ_TOPLAM_LC):= pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,NVL(number_list(p_5213_FAIZ_TOPLAM),0),1,NULL,NULL,'N','A'));

            number_list(p_5213_VERGI_TOPLAM_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,NVL(number_list(p_5213_VERGI_TOPLAM_FC),0),1,NULL,NULL,'N','A'));

            number_list(p_5213_INTEREST_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,number_list(p_5213_INTEREST_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
            number_list(p_5213_TAX_OVER_LIMIT_LC) := pkg_kur.yuvarla(pkg_genel.LC_AL,pkg_kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,pkg_genel.LC_AL,NULL,number_list(p_5213_TAX_OVER_LIMIT_FC),1,NULL,NULL,'N','A'));
        END IF;        
        
        -- finding accrual GL no 
        Pkg_Muhasebe.dk_bul(ln_dk_grup_kod, r_hesap.MODUL_TUR_KOD, r_hesap.urun_tur_kod,r_hesap.urun_sinif_kod, 8, NULL, NULL, NULL,ls_interest_dk);
        varchar_list(p_5213_INTEREST_GL) := ls_interest_dk;

    END IF;
-- E-O-M AdiletK 30122014 CQ1236 overdraft accumulation on separate GL 

     IF r_hesap.doviz_kodu = pkg_genel.lc_al THEN
   --MUHPL: 1 Nolu Plan
   varchar_list(p_5213_FAIZ_ACIKLAMA) :=  r_hesap.hesap_no ||' '||'account Overdraft Interest Payment';
   varchar_list(p_5213_VERGI_ACIKLAMA) :=  r_hesap.hesap_no ||' '||'account sales tax of overdraft interest';
   ln_fis_no:=Pkg_Muhasebe.fis_kes (ln_islem_kod,
            1,
            ln_islem_no,
            varchar_list,
            number_list,
            date_list,
            boolean_list,
            NULL,
            FALSE,
            NVL(ln_fis_no,0),
            'Overdraft Interest Payment');
   ELSE
   --sevalb 260607
    --MUHPL:6 Nolu Plan
   varchar_list(p_5213_FAIZ_ACIKLAMA) := r_hesap.hesap_no ||' '||'account Overdraft Interest Payment';
   varchar_list(p_5213_VERGI_ACIKLAMA) :=  r_hesap.hesap_no ||' '||'account sales tax of overdraft interest';
   ln_fis_no:=Pkg_Muhasebe.fis_kes (ln_islem_kod,
            6,
            ln_islem_no,
            varchar_list,
            number_list,
            date_list,
            boolean_list,
            NULL,
            FALSE,
            NVL(ln_fis_no,0),
            'Overdraft Interest Payment');
   END IF;

--B-O-M AdiletK 30122014 CQ1236 Update relevant account information
   UPDATE CBS_HESAP -- changed faiz_toplam to birikmis_faiz_neg + gecmis_ay_faiz_neg
   SET TAHSIL_EDILEN_FAIZ_LC = ROUND((NVL(TAHSIL_EDILEN_FAIZ_LC,0)+ NVL(number_list(p_5213_BIRIKMIS_FAIZ_NEG_LC),0)  + NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG_LC),0)),2) , --Sevalb 20052011 faiz topla ile degistirildi
    TAHSIL_EDILEN_FAIZ_FC = ROUND((NVL(TAHSIL_EDILEN_FAIZ_FC,0) + NVL(number_list(p_5213_BIRIKMIS_FAIZ_NEG),0)  + NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG),0)),2)--Sevalb 20052011 faiz topla ile degistirildi
   WHERE hesap_no=r_hesap.hesap_no; 
   
       -- Update overdraft interest amount
    update cbs_hesap 
    set ovd_total_acc_interest = ROUND((nvl(ovd_total_acc_interest,0) + number_list(p_5213_INTEREST_OVER_LIMIT_FC)),2)
    where hesap_no = r_hesap.hesap_no;
-- E-O-M AdiletK 30122014 CQ1236 Update relevant account information

   ln_kalan_bakiye := NVL(ln_B,0) - NVL(ln_A,0) - NVL( number_list(p_5213_FAIZ_TOPLAM),0) ;
   -- Hesabin degisen kolonlarinin onceki ve sonraki degerleri loglaniyor.
   --Ayrica bu log kayitlari batch sonunda bakiye karakterinin 'P' yapilmasinda da kullanilacak.
   INSERT INTO CBS_KMH_FAIZ_TAH_THSL_LOG (BANKA_TARIHI, HESAP_NO,
             TAHSIL_EDILEN_FAIZ_TP_ONCE, TAHSIL_EDILEN_FAIZ_TP_SONRA,
             TAHSIL_EDILEN_FAIZ_YP_ONCE, TAHSIL_EDILEN_FAIZ_YP_SONRA,
             KMH_TAH_VERGI_TUTARI_ONCE, KMH_TAH_VERGI_TUTARI_SONRA,
             KMH_TAH_TUTARI_ONCE, KMH_TAH_TUTARI_SONRA,
             BIRIKMIS_FAIZ_NEG_ONCE,
             GECMIS_AYLARIN_FAIZI_NEG   )   --sevalb 20052011
   SELECT ld_banka_tarihi, HESAP_NO,
     ln_TAHSIL_EDILEN_FAIZ_TP,TAHSIL_EDILEN_FAIZ_LC,
     ln_TAHSIL_EDILEN_FAIZ_YP,TAHSIL_EDILEN_FAIZ_FC,
     ln_KMH_TAHAKKUK_VERGI_TUTARI,NULL,
     ln_KMH_TAHAKKUK_TUTARI,NULL,
     ln_BIRIKMIS_FAIZ_NEG,
     NVL(number_list(p_5213_GECMIS_AY_FAIZ_NEG),0)  --sevalb 20052011
   FROM CBS_HESAP
   WHERE hesap_no=r_hesap.hesap_no;

   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5862'||Pkg_Hata.GetDelimiter||TO_CHAR(r_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
  END LOOP;
  CLOSE c_hesap;

  IF ln_islem_no IS NOT NULL AND  ln_fis_no IS NOT NULL
  THEN
   Pkg_Muhasebe.muhasebelestir(ln_fis_no);
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5863'||Pkg_Hata.GetDelimiter||TO_CHAR(r_hesap_bolum.sube_kodu)||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
  END IF;
 END LOOP;
 CLOSE c_hesap_bolum;



 --Batch basinda 'N' yapilan Bakiye Karakteri 'P' yapiliyor.
 UPDATE CBS_HESAP_BAKIYE
 SET BAKIYE_KARAKTERI='P'
 WHERE hesap_no IN
 (SELECT HESAP_NO
  FROM CBS_KMH_FAIZ_TAH_THSL_LOG
  WHERE BANKA_TARIHI=ld_banka_tarihi);

 -- Batch programin calistigi hesaplarin birikmis_faiz_neg degerleri sifirlaniyor.
 UPDATE CBS_HESAP
 SET BIRIKMIS_FAIZ_NEG =0,
  GECMIS_AYLARIN_FAIZI_NEG = 0 --SEVALB 270607
 WHERE hesap_no IN
 (SELECT HESAP_NO
  FROM CBS_KMH_FAIZ_TAH_THSL_LOG
  WHERE BANKA_TARIHI=ld_banka_tarihi);

 COMMIT;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

EXCEPTION
 WHEN iliskili_reeskont_dk_yok THEN  --sevalb 20052011
       Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.getucpointer || '1899' || Pkg_Hata.getdelimiter || TO_CHAR(r_hesap.hesap_no) || Pkg_Hata.getdelimiter || ln_dk_grup_kod || Pkg_Hata.getdelimiter || r_hesap.modul_tur_kod  || Pkg_Hata.getdelimiter ||  r_hesap.urun_tur_kod  || Pkg_Hata.getdelimiter || r_hesap.urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '1899' || Pkg_Hata.getdelimiter || TO_CHAR(r_hesap.hesap_no) || Pkg_Hata.getdelimiter || ln_dk_grup_kod || Pkg_Hata.getdelimiter ||  r_hesap.modul_tur_kod  || Pkg_Hata.getdelimiter ||   r_hesap.urun_tur_kod  || Pkg_Hata.getdelimiter || r_hesap.urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
  WHEN exception_iliskili_DK_null THEN
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5864'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_hesap_iliskili_DK_yok)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
   ROLLBACK;
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  WHEN OTHERS THEN
   ROLLBACK;
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  ROLLBACK;
END;
-----------------------------------------------------------------------------------------------------

PROCEDURE AVERAGE_BALANCE_INTEREST_PAY(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
  p_2003_BANKA_ACIKLAMA       NUMBER;
  p_2003_BOLUM_KODU           NUMBER;
  p_2003_BORCLU_HESAP           NUMBER;
  p_2003_DOVIZ_KODU           NUMBER;
  p_2003_FAIZ_DK            NUMBER;
  p_2003_FC_BIRIKMIS_FAIZ       NUMBER;
  p_2003_FC_GECENYIL_FAIZI      NUMBER;
  p_2003_FC_TOPLAM_FAIZ       NUMBER;
  p_2003_FC_TUTAR           NUMBER;
  p_2003_FC_SON_BAKIYE       NUMBER;
  p_2003_HESAP_NO            NUMBER;
  p_2003_HESAP_TURU           NUMBER;
  p_2003_ISTATISTIK_KODU       NUMBER;
  p_2003_STATISTIC_CLOSE       NUMBER;
  p_2003_STATISTIC_INT       NUMBER;
  p_2003_KUR             NUMBER;
  p_2003_LC_BIRIKMIS_FAIZ       NUMBER;
  p_2003_LC_GECENYIL_FAIZI      NUMBER;
  p_2003_LC_ISLEM            NUMBER;
  p_2003_LC_SON_BAKIYE       NUMBER;
  p_2003_LC_TOPLAM_FAIZ       NUMBER;
  p_2003_LC_TUTAR            NUMBER;
  p_2003_MUSTERI_ACIKLAMA       NUMBER;
  p_2003_REESKONT_DK           NUMBER;
  p_2003_VALOR_TARIHI           NUMBER;
  p_2003_ILISKILI_HESAPNO       NUMBER;
  p_2003_ILISKILI_HESAPSUBE      NUMBER;
  p_2003_LC_NETTUTAR        NUMBER;
  p_2003_FC_NETTUTAR        NUMBER;
  p_2003_LC_TAX_AMT        NUMBER;
  p_2003_FC_TAX_AMT        NUMBER;

     varchar_list     Pkg_Muhasebe.varchar_array;
     number_list      Pkg_Muhasebe.number_array;
     date_list      Pkg_Muhasebe.date_array;
     boolean_list     Pkg_Muhasebe.boolean_array;
  ln_fis_no      NUMBER:=0;
  ln_plan_no      NUMBER:=0;
  ln_son_bakiye     NUMBER;
  ln_temp       NUMBER;
  pn_islem_no      NUMBER;
  ld_vade_tarihi     DATE;
  ld_sonraki_tarih    DATE;
  ls_durum_kodu     VARCHAR2(1);
        ls_istatistik_faiz     VARCHAR2(2000);
     ls_istatistik_kapama    VARCHAR2(2000);
  CURSOR islem_cursor IS
     SELECT ch.*,Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no) DK_GRUP_KODU
          FROM CBS_HESAP ch
         WHERE ch.durum_kodu='A'
      AND NVL(ch.BIRIKMIS_FAIZ_POZ,0)<>0;
   /*SELECT v.*,Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no) AS DK_GRUP_KODU
    FROM CBS_HESAP_VADELI v
    WHERE durum_kodu='A'
    AND v.urun_tur_kod NOT IN ('LOAN','PLACEMENT')
    AND Pkg_Hesap.sf_vadeliurunuygunmu(v.urun_tur_kod ) = 'E'
    AND (vade_tarihi=Pkg_Muhasebe.banka_tarihi_bul
    OR NVL(sonraki_baslangic_tarihi,vade_tarihi)=Pkg_Muhasebe.banka_tarihi_bul);*/

  row_islem         islem_cursor%ROWTYPE;
  ln_msigv       NUMBER;
  ln_ssdf        NUMBER;
  ln_oiv        NUMBER;
  ln_retval       NUMBER;
  ls_timestamp      DATE;
  ld_kapama_tarihi                    DATE := NULL;
  ls_ISTATISTIK_KODU_2    VARCHAR2(10);
  ln_dk_grup_no      CBS_MUSTERI.DK_GRUP_KOD%TYPE;
  ln_tax_tutar      NUMBER := 0;
  ln_tax_oran       NUMBER := 0;
  ln_bugun     NUMBER;
  ln_yarin     NUMBER;

  ln_bakiye     NUMBER;
  ld_tarih     DATE;
  ln_yil NUMBER;
  ln_ay NUMBER;
  ln_gun NUMBER;
  ln_bloke_tutari NUMBER;
  ln_valorlu_bakiye    NUMBER;

  BEGIN
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 --select systimestamp into ls_timestamp from dual;

 ln_bugun:=TO_NUMBER(TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'DD'));
 ln_yarin:=TO_NUMBER(TO_CHAR(Pkg_Muhasebe.sonraki_banka_tarihi_bul,'DD'));

 IF ln_yarin < ln_bugun THEN --AYSONU

  p_2003_BANKA_ACIKLAMA:=Pkg_Muhasebe.parametre_index_bul('2003_BANKA_ACIKLAMA');
  p_2003_BOLUM_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_BOLUM_KODU');
  p_2003_BORCLU_HESAP:=Pkg_Muhasebe.parametre_index_bul('2003_BORCLU_HESAP');
  p_2003_DOVIZ_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_DOVIZ_KODU');
  p_2003_FAIZ_DK:=Pkg_Muhasebe.parametre_index_bul('2003_FAIZ_DK');
  p_2003_FC_BIRIKMIS_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_FC_BIRIKMIS_FAIZ');
  p_2003_FC_GECENYIL_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_FC_GECENYIL_FAIZI');
  p_2003_FC_SON_BAKIYE:=Pkg_Muhasebe.parametre_index_bul('2003_FC_SON_BAKIYE');
  p_2003_FC_TOPLAM_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TOPLAM_FAIZ');
  p_2003_FC_TUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TUTAR');
  p_2003_HESAP_NO:=Pkg_Muhasebe.parametre_index_bul('2003_HESAP_NO');
  p_2003_HESAP_TURU:=Pkg_Muhasebe.parametre_index_bul('2003_HESAP_TURU');
  p_2003_ISTATISTIK_KODU:=Pkg_Muhasebe.parametre_index_bul('2003_ISTATISTIK_KODU');
  p_2003_KUR:=Pkg_Muhasebe.parametre_index_bul('2003_KUR');
  p_2003_LC_BIRIKMIS_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_LC_BIRIKMIS_FAIZ');
  p_2003_LC_GECENYIL_FAIZI:=Pkg_Muhasebe.parametre_index_bul('2003_LC_GECENYIL_FAIZI');
  p_2003_LC_ISLEM:=Pkg_Muhasebe.parametre_index_bul('2003_LC_ISLEM');
  p_2003_LC_SON_BAKIYE:=Pkg_Muhasebe.parametre_index_bul('2003_LC_SON_BAKIYE');
  p_2003_LC_TOPLAM_FAIZ:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TOPLAM_FAIZ');
  p_2003_LC_TUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TUTAR');
  p_2003_MUSTERI_ACIKLAMA:=Pkg_Muhasebe.parametre_index_bul('2003_MUSTERI_ACIKLAMA');
  p_2003_REESKONT_DK:=Pkg_Muhasebe.parametre_index_bul('2003_REESKONT_DK');
  p_2003_VALOR_TARIHI:=Pkg_Muhasebe.parametre_index_bul('2003_VALOR_TARIHI');
  p_2003_ILISKILI_HESAPNO:=Pkg_Muhasebe.parametre_index_bul('2003_ILISKILI_HESAPNO');
  p_2003_ILISKILI_HESAPSUBE:=Pkg_Muhasebe.parametre_index_bul('2003_ILISKILI_HESAPSUBE');
  p_2003_LC_NETTUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_LC_NETTUTAR');
  p_2003_FC_NETTUTAR:=Pkg_Muhasebe.parametre_index_bul('2003_FC_NETTUTAR');
  p_2003_FC_TAX_AMT:=Pkg_Muhasebe.parametre_index_bul('2003_FC_TAX_AMT');
  p_2003_LC_TAX_AMT:=Pkg_Muhasebe.parametre_index_bul('2003_LC_TAX_AMT');
  p_2003_STATISTIC_CLOSE:=Pkg_Muhasebe.parametre_index_bul('2003_STATISTIC_CLOSE');
  p_2003_STATISTIC_INT:=Pkg_Muhasebe.parametre_index_bul('2003_STATISTIC_INT');

  OPEN islem_cursor;
  FETCH islem_cursor INTO row_islem;
    WHILE NOT islem_cursor%NOTFOUND
  LOOP
      BEGIN
   pn_islem_no:=Pkg_Batch.islem_yarat(2003,row_islem.SUBE_KODU);
   ln_tax_oran:=Pkg_Hesap.sf_tax_orani_al(row_islem.dk_grup_kodu,row_islem.modul_tur_kod,row_islem.urun_tur_kod,row_islem.urun_sinif_kod);

   varchar_list(p_2003_DOVIZ_KODU):=Pkg_Hesap.HesaptanDovizKoduAl(row_islem.HESAP_NO);
   Pkg_Muhasebe.DK_BUL(row_islem.DK_GRUP_KODU, row_islem.modul_tur_kod, row_islem.urun_tur_kod,row_islem.urun_sinif_kod, 3, NULL, NULL, NULL,varchar_list(p_2003_FAIZ_DK));
   Pkg_Muhasebe.DK_BUL(row_islem.DK_GRUP_KODU, row_islem.modul_tur_kod, row_islem.urun_tur_kod,row_islem.urun_sinif_kod, 4, NULL, NULL, NULL,varchar_list(p_2003_REESKONT_DK));
   number_list(p_2003_FC_BIRIKMIS_FAIZ):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),NVL(row_islem.BIRIKMIS_FAIZ_POZ,0));
   number_list(p_2003_LC_BIRIKMIS_FAIZ):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,NVL(row_islem.BIRIKMIS_FAIZ_POZ,0),1,NULL,NULL,'N','A'));
   number_list(p_2003_FC_GECENYIL_FAIZI):=0;--Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),NVL(row_islem.GECEN_YIL_FAIZ_TOPLAMI,0));
   number_list(p_2003_LC_GECENYIL_FAIZI):=0;--Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,NVL(row_islem.GECEN_YIL_FAIZ_TOPLAMI,0),1,NULL,NULL,'N','A'));
   number_list(p_2003_FC_TOPLAM_FAIZ):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),number_list(p_2003_FC_GECENYIL_FAIZI)+number_list(p_2003_FC_BIRIKMIS_FAIZ));
   number_list(p_2003_LC_TOPLAM_FAIZ):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_GECENYIL_FAIZI)+number_list(p_2003_LC_BIRIKMIS_FAIZ));

   number_list(p_2003_LC_TAX_AMT):=Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_TOPLAM_FAIZ)*ln_Tax_oran/100);
   number_list(p_2003_FC_TAX_AMT):=Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_2003_DOVIZ_KODU),NULL,number_list(p_2003_LC_TAX_AMT),1,NULL,NULL,'N','A'));

   varchar_list(p_2003_HESAP_NO):=TO_CHAR(row_islem.hesap_no);
   varchar_list(p_2003_BOLUM_KODU):=row_islem.SUBE_KODU;--pkg_hesap.HESAPSUBEAL(row_islem.HESAP_NO);
   --varchar_list(p_2003_ILISKILI_HESAPNO):=TO_CHAR(row_islem.GERI_DONUS_HESAPNO);
   --IF row_islem.GERI_DONUS_HESAPNO IS NOT NULL THEN
   --   varchar_list(p_2003_ILISKILI_HESAPSUBE):=Pkg_Hesap.HESAPSUBEAL(row_islem.GERI_DONUS_HESAPNO);
   --END IF;
   number_list(p_2003_KUR):=Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
   varchar_list(p_2003_BANKA_ACIKLAMA):= row_islem.hesap_no || ' ?????????? ????????? ?? ?????????????? ???????';
   varchar_list(p_2003_MUSTERI_ACIKLAMA):= row_islem.hesap_no || ' 15% ?? ??????????? ????????? ?? ?????????????? ???????';
   number_list(p_2003_LC_NETTUTAR):=ABS(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,number_list(p_2003_LC_TOPLAM_FAIZ)-number_list(p_2003_LC_TAX_AMT)));
   number_list(p_2003_FC_NETTUTAR):=ABS(Pkg_Kur.YUVARLA(varchar_list(p_2003_DOVIZ_KODU),number_list(p_2003_FC_TOPLAM_FAIZ)-number_list(p_2003_FC_TAX_AMT)));

   ln_son_bakiye:=Pkg_Hesap.HesapBakiyeAl(row_islem.HESAP_NO);
   number_list(p_2003_FC_SON_BAKIYE):=ABS(ln_son_bakiye+NVL(number_list(p_2003_FC_NETTUTAR),0));
   number_list(p_2003_LC_SON_BAKIYE):=ABS(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(varchar_list(p_2003_DOVIZ_KODU),Pkg_Genel.lc_al,NULL,ln_son_bakiye+NVL(number_list(p_2003_FC_NETTUTAR),0),1,NULL,NULL,'N','A')));

   ls_durum_kodu:=row_islem.DURUM_KODU;
   --ld_vade_tarihi:=row_islem.VADE_TARIHI;
   --ld_sonraki_tarih:=row_islem.SONRAKI_BASLANGIC_TARIHI;

         ls_istatistik_faiz   := '1417'|| varchar_list(p_2003_DOVIZ_KODU) ||'840';--row_islem.prefix_istatistik_kodu_faiz||row_islem.doviz_kodu||row_islem.ISTATISTIK_KODU_faiz;
   ls_istatistik_kapama := '1714'|| varchar_list(p_2003_DOVIZ_KODU) ||'840';--row_islem.prefix_istatistik_kodu_kapama||row_islem.doviz_kodu||row_islem.ISTATISTIK_KODU_kapama ;

   varchar_list(p_2003_STATISTIC_INT):=ls_istatistik_faiz;
      varchar_list(p_2003_STATISTIC_CLOSE):=ls_istatistik_kapama;

   IF varchar_list(p_2003_DOVIZ_KODU)=pkg_genel.LC_al THEN
      ln_plan_no:=22;
   ELSE
      ln_plan_no:=23;
   END IF;

   ln_fis_no:=Pkg_Muhasebe.fis_kes(2003,
        ln_plan_no,
        pn_islem_no,
        varchar_list,
        number_list,
        date_list,
        boolean_list,
        NULL,
        FALSE,
        0,
        'Average Balance Interest Payment');

   Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);


   --update payment values.
   UPDATE CBS_HESAP
   SET ODENMIS_FAIZ_TOPLAMI=NVL(ODENMIS_FAIZ_TOPLAMI,0)+NVL(number_list(p_2003_FC_TOPLAM_FAIZ),0),
    ODENMIS_FAIZ_TOPLAMI_LC=NVL(ODENMIS_FAIZ_TOPLAMI_LC,0)+NVL(number_list(p_2003_LC_TOPLAM_FAIZ),0),
    BIRIKMIS_FAIZ_POZ=0
   WHERE hesap_no=row_islem.hesap_no;

   --update daily balance
   SELECT NVL(BAKIYE,0),NVL(bloke_tutari,0),NVL(valorlu_bakiye,0)
   INTO ln_bakiye,ln_bloke_tutari,ln_valorlu_bakiye
   FROM CBS_HESAP_BAKIYE
   WHERE hesap_no=row_islem.hesap_no;

   ld_tarih:=Pkg_Muhasebe.Banka_Tarihi_Bul;
   LOOP
    IF TRUNC(ld_tarih) >= TRUNC(Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul) THEN
     EXIT;
    END IF;

    ln_yil:=TO_CHAR(ld_tarih,'YYYY');
    ln_ay:=TO_CHAR(ld_tarih,'MM');
    ln_gun:=TO_CHAR(ld_tarih,'DD');

    UPDATE CBS_HESAP_GUNLUK_BAKIYE
    SET bakiye=ln_bakiye,
     bakiye_lc=0,
     bloke=ln_bloke_tutari,
     valorlu_bakiye=ln_valorlu_bakiye
    WHERE 
    yil=ln_yil AND ay=ln_ay AND gun=ln_gun AND
       hesap_no=row_islem.hesap_no;

    ld_tarih:=ld_tarih+1;

    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Monthly Average Balance Update Daily Balance ' || row_islem.hesap_no || ' TXNO:' || pn_islem_no);

   END LOOP;
   --

   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Monthly Average balance Interest Payment for ' || row_islem.hesap_no || ' TXNO:' || pn_islem_no);

   EXCEPTION
        WHEN OTHERS THEN
         Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
      ROLLBACK;
     END ;

   COMMIT;

  FETCH islem_cursor INTO row_islem;
     END LOOP;
     CLOSE islem_cursor;

 ELSE
  Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Not EOM for Monthly Average balance Interest Payment');
 END IF;--AYSONU

   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;

----------------------------------------------------------------------------------

----------------------------------------------------------------------------------
  -- Tanim : DCF_PAYMENTS
  -- Yazar : Hakan Samsa
  -- Tarih : 07/06/2007
----------------------------------------------------------------------------------
PROCEDURE DCF_PAYMENTS(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
-----------------------------------------------------------------------------------------
IS
  BEGIN
 --1. Dcf file load edilir.
   BEGIN
     PKG_BAT_2.DCF_FILE_UPLOAD(0, 0, 'PKG_BAT_2.DCF_FILE_UPLOAD');
  COMMIT;
   EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
     log_at('PKG_BAT_2.DCF_FILE_UPLOAD',SQLCODE,SQLERRM);
   END ;

--2. DCF fee alinir
  BEGIN
     PKG_BAT_2.DCF_FEE(0, 0, 'PKG_BAT_2.DCF_FEE');
  COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK;
   log_at('PKG_BAT_2.DCF_FEE',SQLCODE,SQLERRM);
   END ;

--3. dcf fee gunluk ucret alinir.
  BEGIN
     PKG_BAT_2.DCF_FEE_DAILY_CHARGE(0, 0, 'PKG_BAT_2.DCF_FEE_DAILY_CHARGE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('DCF_FEE_DAILY_CHARGE',SQLCODE,SQLERRM);
   END ;

--4. Files for credit card department
  BEGIN
 pkg_atm_file.Upload_Dcf_Files_1;
 pkg_atm_file.Upload_Dcf_Files_2;
 pkg_atm_file.Upload_Dcf_Files_3;
 pkg_atm_file.delete_uncollected;
 COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('DCF_FEE_DAILY_CHARGE',SQLCODE,SQLERRM);
   END ;

--5. Acc Maint. Fee
  BEGIN
     PKG_BAT_2.ACC_MAINTENANCE_FEE(0, 0, 'PKG_BAT_2.ACC_MAINTENANCE_FEE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('ACC_MAINTENANCE_FEE',SQLCODE,SQLERRM);
   END ;

--6. Statement Fee
  BEGIN
     PKG_BAT_2.STATEMENT_FEE(0, 0, 'PKG_BAT_2.STATEMENT_FEE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('STATEMENT_FEE',SQLCODE,SQLERRM);
   END ;

--7. Daily charge for Acc Maint.Fee and Statement Fee
  BEGIN
     PKG_BAT_2.ACC_STMNT_FEE_DAILY_CHARGE(0, 0, 'PKG_BAT_2.ACC_STMNT_FEE_DAILY_CHARGE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('ACC_STMNT_FEE_DAILY_CHARGE',SQLCODE,SQLERRM);
   END ;
   
--BOM aisuluud CQ1225

--8. Daily charge of Commission Tax 
  BEGIN
     PKG_BAT_2.COMMISSION_TAX_CHARGE(0, 0, 'PKG_BAT_2.COMMISSION_TAX_CHARGE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('COMMISSION_TAX_CHARGE',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);
   END ;   
--EOM aisuluud CQ1225

--BOM bahianab 30102020 cbs-113
   --9. notification fee
    BEGIN
     PKG_BAT_2.NOTIF_CHARGE_FEE(0, 0, 'PKG_BAT_2.NOTIF_CHARGE_FEE');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('NOTIF_CHARGE_FEE',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);
   END ; 
   
   --10. daily charge of notification fee
      BEGIN
     PKG_BAT_2.NOTIF_CHARGE_FEE_DAILY(0, 0, 'PKG_BAT_2.NOTIF_CHARGE_FEE_DAILY');
  COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
     log_at('NOTIF_CHARGE_FEE_DAILY',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);
   END ;     
   --EOM bahianab 30102020 cbs-113
   
   --BOM bahianab 14022022 cbs-322
     --11.CUSFE  Acc Maint. Fee-
   BEGIN
     PKG_BAT_2.ACC_MAINTENANCE_FEE_2(0, 0, 'PKG_BAT_2.ACC_MAINTENANCE_FEE_2');
   COMMIT;
   EXCEPTION
     WHEN OTHERS THEN
      ROLLBACK;
      log_at('ACC_MAINTENANCE_FEE_2',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);      
   END ;
   
     --12.CUSFE Statement Fee
    BEGIN
     PKG_BAT_2.STATEMENT_FEE_2(0, 0, 'PKG_BAT_2.STATEMENT_FEE_2');
    COMMIT;
     EXCEPTION
      WHEN OTHERS THEN
      ROLLBACK;
      log_at('STATEMENT_FEE_2',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);      
     END;

    --13. CUSFE Daily charge for Acc Maint.Fee and Statement Fee
   BEGIN
     PKG_BAT_2.ACC_STMNT_FEE_DAILY_CHARGE_2(0, 0, 'PKG_BAT_2.ACC_STMNT_FEE_DAILY_CHARGE_2');
    COMMIT;
     EXCEPTION
      WHEN OTHERS THEN
      ROLLBACK;     
      log_at('ACC_STMNT_FEE_DAILY_CHARGE_2',SQLCODE,SQLERRM,dbms_utility.format_error_backtrace);  
   END ;      
   --EOM bahianab 14022022 cbs-322 
   
   EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
     log_at('DCF_FEE_DAILY_CHARGE',SQLCODE,SQLERRM);
  END;
-------------------------------------------------------------------
  PROCEDURE Tahakkuk_Sonrasi_Gunluk_Bakiye(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

    CURSOR cur_hesap IS
   SELECT hesap_no,bakiye,bloke_tutari
     FROM CBS_HESAP_BAKIYE
    WHERE hesap_no IN (SELECT hesap_no FROM CBS_HESAP);
 --   WHERE bakiye!=0; sevalb


    ln_commit_counter    NUMBER:=0;

 ln_yil       NUMBER;
 ln_ay       NUMBER;
 ln_gun       NUMBER;

 ld_banka_tarihi     DATE;
 ld_sonraki_banka_tarihi   DATE;
 ld_tarih      DATE;

 ln_bakiye      NUMBER;
 ln_bakiye_lc     NUMBER;
 ln_bloke            NUMBER;
 ln_adet       NUMBER := 0;

  BEGIN
   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

 ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;
 ld_sonraki_banka_tarihi:=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;

  IF Pkg_Batch.ay_sonu_mu THEN   --aysonu ise

  FOR c1 IN cur_hesap LOOP
      ln_bakiye:=ROUND(c1.bakiye,10);
   ld_tarih:=ld_banka_tarihi;

   LOOP
     IF TRUNC(ld_tarih) >= TRUNC(ld_sonraki_banka_tarihi) THEN
       EXIT;

    ELSE
          ln_yil:=TO_CHAR(ld_tarih,'YYYY');
        ln_ay:=TO_CHAR(ld_tarih,'MM');
        ln_gun:=TO_CHAR(ld_tarih,'DD');

     BEGIN
           UPDATE CBS_HESAP_GUNLUK_BAKIYE
     SET  bakiye = ln_bakiye ,
       bloke =c1.bloke_tutari,
       valorlu_bakiye =ln_bakiye --bakiye degeri valore atanir
     WHERE hesap_no =  c1.hesap_no AND       
       yil = ln_yil AND ay = ln_ay  AND  gun = ln_gun ;

     EXCEPTION WHEN OTHERS    THEN NULL;
     END;

     END IF;
     log_at(c1.hesap_no,ld_tarih);

     ld_tarih:=ld_tarih+1;
   END LOOP;
    END LOOP;

  COMMIT;
  UPDATE CBS_HESAP_BAKIYE
  SET valorlu_Bakiye =bakiye
  WHERE hesap_no IN (SELECT hesap_no FROM CBS_HESAP);

     COMMIT;
    END IF;

   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
---------------------------------------------------------------------------------
PROCEDURE PREPARE_CUSTOMER_STATEMENT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
 CURSOR c1(ld1 DATE) IS
  SELECT DISTINCT satir_hesap_numara
  FROM cbs_vw_hesap_ekstre
   WHERE NVL(PERSONEL_SICIL_NO,0)=0
     AND FIS_TUR='G'
     AND FIS_MUHASEBELESTIGI_TARIH  BETWEEN pkg_vadehesap_rapor.ekstre_bas_tarih(satir_hesap_numara, ld1) AND ld1;
 r1       c1%ROWTYPE;

 CURSOR c2 IS
  SELECT
      musteri_no,
      fis_numara,
      fis_islem_numara,
      trim(UPPER(isim_unvan)) isim_unvan,
      hesap_turu,
      vergi_no,
      hesap_doviz_kodu,
      adres,
      fis_fis_no,
      fis_tur,
      satir_numara,
      satir_tur,
      satir_hesap_bolum_kodu,
      fis_muhasebelestigi_tarih,
      satir_valor_tarihi,
      satir_dv_tutar,
      satir_doviz_kod,
      SUBSTR(satir_musteri_aciklama,1,500) satir_musteri_aciklama,
      bolum_kodu,
      fis_yaratildigi_banka_tarih,
/*      bakiye, */
      pkg_genel.bolum_adi_al_hatasiz(satir_hesap_bolum_kodu) AS bolum_adi,
      pkg_report5.GetNBEquivalent(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEquivalent,
    CASE WHEN satir_dv_tutar > 0 THEN satir_dv_tutar ELSE 0 END credit,
    CASE WHEN satir_dv_tutar < 0 THEN satir_dv_tutar ELSE 0 END debit,
   personel_sicil_no
  FROM cbs_vw_hesap_ekstre
   WHERE NVL(PERSONEL_SICIL_NO,0)=0
     AND FIS_TUR='G'
     AND satir_hesap_numara = r1.satir_hesap_numara;
 r2       c2%ROWTYPE;

 pd_last_eod DATE;


 ls_external_acc     VARCHAR2(30);
 ls_vergi      VARCHAR2(100);
 ls_donem     VARCHAR2(100);
 ln_extre_no     NUMBER;
 ln_credit          NUMBER;
 ln_debit      NUMBER;
 ln_devir_bakiye    NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
/*
 pd_last_eod:=pkg_muhasebe.Onceki_Banka_Tarihi_Bul;
    --pd_last_eod:=to_date('31.07.2008','dd.mm.yyyy');

 begin
  delete from cbs_hizli_ekstre where trunc(eod_tarih)=trunc(pd_last_eod);

  OPEN c1(pd_last_eod);
  LOOP
   FETCH c1 INTO r1;
   EXIT WHEN c1%NOTFOUND;
    if pkg_vadehesap_rapor.ekstre_basilacak(r1.satir_hesap_numara,pd_last_eod) = 'E'
    then
        ls_external_acc := pkg_hesap.External_HesapNo_Al(r1.satir_hesap_numara) ;
        ls_vergi := pkg_vadehesap_rapor.musteri_vergino_al_dairesiz(r1.satir_hesap_numara);
        ls_donem := pkg_vadehesap_rapor.ekstre_bas_donem(r1.satir_hesap_numara,pd_last_eod) || ' - '  ||to_char(pd_last_eod,'DD.MM.YYYY');
        ln_extre_no := pkg_vadehesap_rapor.ekstre_no_bul(r1.satir_hesap_numara,pd_last_eod);
        ln_devir_bakiye := pkg_vadehesap_rapor.sf_devirbakiyebul(r1.satir_hesap_numara,replace(substr(ls_donem,1,10),'.','/'));

     OPEN c2;
     LOOP
      FETCH c2 INTO r2;
      EXIT WHEN c2%NOTFOUND;

      if r2.FIS_MUHASEBELESTIGI_TARIH between pkg_vadehesap_rapor.ekstre_bas_tarih(r1.satir_hesap_numara,pd_last_eod)
                                       and pd_last_eod
      then
/*       insert into cbs_hizli_ekstre
       (MUSTERI_NO,FIS_NUMARA,FIS_ISLEM_NUMARA,ISIM_UNVAN,EXTERNAL_ACC,HESAP_TURU,VERGI_NO,
        HESAP_DOVIZ_KODU,ADRES,FIS_FIS_NO,FIS_TUR,SATIR_NUMARA,SATIR_TUR,SATIR_HESAP_BOLUM_KODU,
        SATIR_HESAP_NUMARA,FIS_MUHASEBELESTIGI_TARIH,SATIR_VALOR_TARIHI,SATIR_DV_TUTAR,SATIR_DOVIZ_KOD,
        SATIR_MUSTERI_ACIKLAMA,BOLUM_KODU,FIS_YARATILDIGI_BANKA_TARIH,BAKIYE,
        BOLUM_ADI,
        NBEQUIVALENT,
        CREDIT,DEBIT,VERGI_NO_DAIRESIZ,DONEM,EKSTRE_NO,PERSONEL_SICIL_NO,EOD_TARIH,DEVIR_BAKIYE)
       values
       (r2.musteri_no,r2.fis_numara,r2.fis_islem_numara,trim(upper(r2.isim_unvan)),ls_external_acc,r2.hesap_turu,r2.vergi_no,
        r2.hesap_doviz_kodu,r2.adres,r2.fis_fis_no,r2.fis_tur,r2.satir_numara,r2.satir_tur,r2.satir_hesap_bolum_kodu,
        r1.satir_hesap_numara,r2.fis_muhasebelestigi_tarih,r2.satir_valor_tarihi,r2.satir_dv_tutar,r2.satir_doviz_kod,
        substr(r2.satir_musteri_aciklama,1,500),r2.bolum_kodu,r2.fis_yaratildigi_banka_tarih,r2.bakiye,
        pkg_genel.bolum_adi_al_hatasiz(r2.satir_hesap_bolum_kodu),
        pkg_report5.GetNBEquivalent(r2.SATIR_DOVIZ_KOD,r2.FIS_MUHASEBELESTIGI_TARIH,r2.SATIR_DV_TUTAR),
        r2.credit,r2.debit,ls_vergi,ls_donem,ln_extre_no,r2.personel_sicil_no,pd_last_eod,ln_devir_bakiye);

                        NULL;
      end if;
     END LOOP;
     CLOSE c2;
    end if;
  END LOOP;
  CLOSE c1;

  exception
  when others then
   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,substr('Error in preparing statement'||SQLERRM,1,100));
 end;
*/
 COMMIT;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
EXCEPTION
  WHEN OTHERS THEN
   Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
END;
---------------------------------------------------------------------------------
PROCEDURE SWIFT_NOSTRO_HESAP_DATA_AKTAR(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
ln_count  NUMBER;
BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    -- sonra ilgili hesaplarin o gunku hareketleri aktarilacak

 SELECT COUNT(*)
 INTO   ln_count
 FROM   CBS_VW_FIS_SATIR
 WHERE  fis_muhasebelestigi_tarih = Pkg_Muhasebe.banka_tarihi_bul
 AND    SATIR_HESAP_NUMARA IN (SELECT to_char(hesap_no) FROM CBS_HESAP  WHERE  DURUM_KODU = 'A' --miraidat converted to char
                   AND  URUN_TUR_KOD IN ('NOSTRO-FC','NOSTRO-LC'))
 --AND    Pkg_Tx.Islem_durumu(FIS_ISLEM_NUMARA) IN ('P' ,'N')miraidat commented out
 AND SATIR_HESAP_TUR_KODU='VS' --miraidat added  'VS'
 AND    FIS_TUR NOT IN ('X')
  AND EXISTS (SELECT 1
                FROM CBS_ISLEM
                WHERE     CBS_ISLEM.NUMARA = FIS_ISLEM_NUMARA
                AND DURUM IN ('P', 'N'));--cbs 648

 IF ln_count > 0 THEN
     INSERT INTO SWT_CBS_NOSTRO_HESAP_HAREKET
  SELECT fis_muhasebelestigi_tarih,FIS_ISLEM_NUMARA,FIS_NUMARA,
      CASE WHEN Pkg_Tx.Islem_kod(FIS_ISLEM_NUMARA) = 3219 THEN
             (SELECT referans FROM  CBS_ITH_TRANSFER_ISLEM WHERE tx_no = FIS_ISLEM_NUMARA)
           WHEN Pkg_Tx.Islem_kod(FIS_ISLEM_NUMARA) = 4003 THEN
             (SELECT referans FROM CBS_YPHAVALE_GIDEN_ACILIS  WHERE tx_no = FIS_ISLEM_NUMARA )
              WHEN Pkg_Tx.Islem_kod(FIS_ISLEM_NUMARA) = 2051 THEN
             (SELECT DECODE(referans_yeni, NULL,referans,referans_yeni) FROM CBS_HAZINE_ALINANDEPO_ISLEM  WHERE tx_no = FIS_ISLEM_NUMARA )
     ELSE SATIR_REFERANS END islem_referansi,      --SATIR_REFERANS islem_referansi,
      SATIR_TUR borc_alacak_kodu,SATIR_DV_TUTAR islem_tutari,SATIR_DOVIZ_KOD islem_doviz_turu,
      SATIR_HESAP_NUMARA hesap_numara,SATIR_VALOR_TARIHI valor_tarihi,
      Pkg_Kur.yuvarla(SATIR_DOVIZ_KOD,NVL(Pkg_Dab.OncekiGunBakiyeAl(SATIR_HESAP_NUMARA,Pkg_Muhasebe.Banka_Tarihi_Bul),0)) acilis_bakiyesi,
      FIS_ACIKLAMA Aciklama, Pkg_Hesap.HesapBakiyeAl(SATIR_HESAP_NUMARA)
  FROM   CBS_VW_FIS_SATIR
  WHERE  fis_muhasebelestigi_tarih = Pkg_Muhasebe.banka_tarihi_bul
  AND    SATIR_HESAP_NUMARA IN (SELECT to_char(hesap_no) FROM CBS_HESAP  WHERE  DURUM_KODU = 'A'
                    AND  URUN_TUR_KOD IN ('NOSTRO-FC','NOSTRO-LC')) --miraidat coverting to char
  AND    fis_muhasebelestigi_tarih NOT IN (SELECT tarih FROM SWT_CBS_NOSTRO_HESAP_HAREKET)
  AND SATIR_HESAP_TUR_KODU='VS' --miraidat added  'VS'
  --AND    Pkg_Tx.Islem_durumu(FIS_ISLEM_NUMARA) IN ('P' ,'N')
    AND EXISTS (SELECT 1
                FROM CBS_ISLEM
                WHERE     CBS_ISLEM.NUMARA = FIS_ISLEM_NUMARA
                AND DURUM IN ('P', 'N'))--cbs-648
  AND    FIS_TUR NOT IN ('X');
 END IF;

 COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  ROLLBACK;
  END;
-----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
PROCEDURE ATM_F6_FILE_UPLOAD(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
IS
 ln_dosya_no NUMBER;
BEGIN
 PKG_ATM_FILE.sp_upload_f6(PN_GRUP_NO,PN_LOG_NO,PS_PROGRAM_KOD,'F6.TXT',ln_dosya_no);
END;
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
PROCEDURE NB_POSITION_REPORT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2)
IS
    CURSOR c1 IS
/*
        select filial,
               DDATE,
               KODV,
               NBS,
               sum(SUMAV1) SUMAV1,
               sum(SUMPV1) SUMPV1,
               sum(SUMAV2) SUMAV2,
               sum(SUMPV2) SUMPV2,
               (SELECT DECODE(DOVIZ_TIPI,'HARD',1,'SOFT',2) D_TYPE FROM CBS_DOVIZ_KODLARI WHERE DOVIZ_KODU = KODV) VALGR,
               null VALPOZ,
               Pkg_Kur.doviz_doviz_karsilik(KODV, Pkg_Genel.lc_al, pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 1,1,NULL,NULL,'N','A') KURS_V
               from
              (select '75' filial,
                        pkg_muhasebe.Onceki_Banka_Tarihi_Bul DDATE,
                      DOVIZ_KOD KODV,
                      substr( NUMARA ,1 ,5 )  NBS,
                      decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), 0, abs(sum(BAKIYE_LC))) SUMAV1,
                      decode(abs(sum(BAKIYE_LC)), sum(BAKIYE_LC), sum(BAKIYE_LC), 0) SUMPV1,
                      decode(abs(sum(BAKIYE)), sum(BAKIYE), 0, abs(sum(BAKIYE))) SUMAV2,
                      decode(abs(sum(BAKIYE)), sum(BAKIYE), sum(BAKIYE), 0) SUMPV2
                FROM (select DOVIZ_KOD,
                      Numara,
                      BAKIYE_LC, BAKIYE
                      from cbs_dkhesap_gunluk_bakiye
                      where yil = to_char(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'yyyy')
                        and ay = to_char(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'mm')
                        and gun = to_char(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'dd')
                        and substr(numara, 1, 5) IN ('11519', '11523', '21115') AND length(numara)=8 AND numara NOT IN (11519000,11519100))
                GROUP BY   substr( NUMARA ,1 ,5 ) ,  DOVIZ_KOD )
        group by filial, DDATE, KODV, NBS;
*/
    SELECT filial,
                       DDATE,
                       KODV,
                       NBS,
                       SUM(SUMAV1) SUMAV1,
                       SUM(SUMPV1) SUMPV1,
                       SUM(SUMAV2) SUMAV2,
                       SUM(SUMPV2) SUMPV2,
                       (SELECT DECODE(DOVIZ_TIPI,'HARD',1,'SOFT',2) D_TYPE
                          FROM CBS_DOVIZ_KODLARI
                                    WHERE DOVIZ_KODU = KODV) VALGR,
                       NULL VALPOZ,
                       Pkg_Kur.doviz_doviz_karsilik(KODV, Pkg_Genel.lc_al, pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 1,1,NULL,NULL,'N','A') KURS_V
    FROM
    (SELECT '75' filial,
            pkg_muhasebe.Onceki_Banka_Tarihi_Bul DDATE,
            DOVIZ_KOD KODV,
            SUBSTR(NUMARA,1,5) NBS,
                          DECODE(ABS(SUM(BAKIYE_LC)), SUM(BAKIYE_LC), 0, ABS(SUM(BAKIYE_LC))) SUMAV1,
            DECODE(ABS(SUM(BAKIYE_LC)), SUM(BAKIYE_LC), SUM(BAKIYE_LC), 0) SUMPV1,
            DECODE(ABS(SUM(BAKIYE)), SUM(BAKIYE), 0, ABS(SUM(BAKIYE))) SUMAV2,
            DECODE(ABS(SUM(BAKIYE)), SUM(BAKIYE), SUM(BAKIYE), 0) SUMPV2
       FROM CBS_DKHESAP_GUNLUK_BAKIYE
      WHERE yil = TO_CHAR(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'yyyy')
        AND ay = TO_CHAR(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'mm')
        AND gun = TO_CHAR(pkg_muhasebe.Onceki_Banka_Tarihi_Bul, 'dd')
        AND SUBSTR(numara, 1, 5) IN ('11519', '11523', '21115') AND LENGTH(numara)=8 AND numara NOT IN (11519001,11519101)
      GROUP BY  SUBSTR(NUMARA,1,5),  DOVIZ_KOD
      )
    GROUP BY filial, DDATE, KODV, NBS;

    r1     c1%ROWTYPE;

    attach   CLOB;
BEGIN

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    attach := 'FILIAL'||';'||
                 'DDATE'||';'||
                 'KODV'||';'||
                 'NBS'||';'||
                 'SUMAV1'||';'||
                 'SUMPV1'||';'||
                 'SUMAV2'||';'||
                 'SUMPV2'||';'||
                 'VALGR'||';'||
                 'VALPOZ'||';'||
                 'KURS_V'||CHR(13)||CHR(10);
    OPEN c1;
    LOOP
    FETCH c1 INTO r1  ;
    EXIT WHEN c1%NOTFOUND;
        attach := attach||r1.FILIAL||';'||
                             r1.DDATE||';'||
                             r1.KODV||';'||
                             r1.NBS||';'||
                             r1.SUMAV1||';'||
                             r1.SUMPV1||';'||
                             r1.SUMAV2||';'||
                             r1.SUMPV2||';'||
                             r1.VALGR||';'||
                             r1.VALPOZ||';'||
                             r1.KURS_V||CHR(13)||CHR(10);


    END LOOP;
    CLOSE c1;

    Pkg_Email.AddToEmailQueue_Atc('SUBSCRIPTION',
                                   50,
                                   'info@demirbank.kg',
                                   'yerzhan.tanatov@demirbank.kg' ,
                                   'VAL7503 - NB Position Report - '||TO_CHAR(pkg_muhasebe.Onceki_Banka_Tarihi_Bul,'dd.mm.yyyy'),
                                   'NB Position Report of the date : '||pkg_muhasebe.Onceki_Banka_Tarihi_Bul ,
                                   'NB_Position_Report_'||TO_CHAR(pkg_muhasebe.Onceki_Banka_Tarihi_Bul,'yyyy.mm.dd')||'.dbf',
                                   attach
                                   );
    pkg_email.SendAutoMessages('');

    COMMIT;
    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

    EXCEPTION
    WHEN OTHERS THEN
        Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
        ROLLBACK;
END;
/******************************************************************************
   NAME        : PROCEDURE ACC_MAINTENANCE_FEE_2 
   Purpose     : CUSFE Optimization (Special comissions)   
   Date        :10022022 CBS-322 BahianaB
******************************************************************************/
PROCEDURE ACC_MAINTENANCE_FEE_2(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
 varchar_list                       Pkg_Muhasebe.varchar_array;
 number_list                        Pkg_Muhasebe.number_array;
 date_list                          Pkg_Muhasebe.date_array;
 boolean_list                       Pkg_Muhasebe.boolean_array;

 ln_fis_numara                      NUMBER;
 ln_counter                         NUMBER;
 ln_temp_numara                     NUMBER;

 p_7048_ACC_BRANCH                  NUMBER;
 p_7048_TRAN_BRANCH                 NUMBER;
 p_7048_ACC                         NUMBER;
 p_7048_INCOME_GL                   NUMBER;
 p_7048_CY                          NUMBER;
 p_7048_EXPLAIN                     NUMBER;
 p_7048_AMOUNT_FC                   NUMBER;
 p_7048_AMOUNT_LC                   NUMBER;
 p_7048_INCOME_LC                   NUMBER; ----bahianab CBS-603 CUSFE 
 p_7048_RATE                        NUMBER;

 p_7048_TAX_FC                      NUMBER;
 p_7048_TAX_LC                      NUMBER;
 p_7048_TAX_EXPLAIN                 NUMBER;

 CURSOR c_musteri IS
  SELECT  MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
  FROM CBS_MUSTERI
  WHERE DURUM_KODU = 'A'
       AND MUSTERI_TIPI_KOD IN ('1','2','3')
       AND HESAP_UCRETI_F = 'E'
       AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
         FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
         WHERE ISLEM_KODU = 7048
           AND MASRAF_KODU = 'ACCMAINFEE')
    AND
    ('ACCMAINFEE',MUSTERI_NO,TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY')),TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM')))
    NOT IN (SELECT CHARGE_CODE, MUSTERI_NO, YIL, AY
         FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE)
    AND
    ('ACCMAINFEE',MUSTERI_NO,TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY')),TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM')))
    NOT IN (SELECT CHARGE_CODE, MUSTERI_NO, YIL, AY
         FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE)
       AND MUSTERI_NO IN (SELECT DISTINCT customer_no
        FROM CBS_CUSTOMER_FEE)
  ORDER BY musteri_no ;
  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap IS
  SELECT f.account_no hesap_no, f.CY_CODE doviz_kodu, h.sube_kodu sube_kodu
  FROM CBS_CUSTOMER_FEE f, CBS_HESAP h
  WHERE f.CUSTOMER_NO = r_musteri.musteri_no
  AND f.account_no = h.hesap_no
  AND h.durum_kodu = 'A'
  AND h.urun_tur_kod IN ('CURRENT','DEMAND DEP')
  ORDER BY ORDER_NO;

  r_hesap  c_hesap%ROWTYPE;
 --

 ld_bas                             DATE;
 ld_son                             DATE;
 ln_yil                             NUMBER;
 ln_ay                              NUMBER;
 ln_amnt_ind                        NUMBER;
 ls_cy_ind                          VARCHAR2(3);
 ln_amnt_corp                       NUMBER;
 ls_cy_corp                         VARCHAR2(3);
 ln_cnt                             NUMBER;

 ln_kur_ucret_dvz                   NUMBER;
 ln_kur_hesap_dvz                   NUMBER;
 ln_masraf                          NUMBER;
 ln_bakiye                          NUMBER;
 ln_amnt                            NUMBER;
 ls_cy                              VARCHAR2(3);
 ls_uygun                           VARCHAR2(1);
 ln_sira                            NUMBER;

 ln_toplam_tahsil                   NUMBER;
 ln_kalan_tahsilat                  NUMBER;
 ln_hesaptan_al                     NUMBER;
 ln_muhasebelesecek_tutar           NUMBER;
 ln_tahsil_tutar                    NUMBER;
 ln_kal                             NUMBER;
 ln_islem_no                        NUMBER := 0;
 ls_dk                              VARCHAR2(30);
 ln_toplam_masraf                   NUMBER;        ----bahianab CBS-603 CUSFE 
 ln_total_lc_amount                 NUMBER;        ----bahianab CBS-603 CUSFE  
 ln_total_fc_amount                 NUMBER;        ----bahianab CBS-603 CUSFE  
 ln_fc_tahsil_tutar                 NUMBER;        ----bahianab CBS-603 CUSFE 
 ls_7048_explanation                VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7048_tax_explanation            VARCHAR2(200); ----bahianab CBS-603 CUSFE 

 double_run_1                       EXCEPTION;
 double_run_2                       EXCEPTION;
 birden_fazla_parametre_var         EXCEPTION;
 parametre_yok                      EXCEPTION;
 dk_yok                             EXCEPTION;
 ln_plan                            NUMBER;
 ln_rate                            NUMBER;
 ln_vergi                           NUMBER;
 ln_vergi_tl                        NUMBER;
 
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
 if pkg_dates.get_last_work_day_in_month(pkg_muhasebe.Banka_Tarihi_Bul) = pkg_muhasebe.Banka_Tarihi_Bul
  then --EOM
  Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
  Pkg_Parametre.deger('AMF_EXPLANATION',ls_7048_explanation);----bahianab CBS-603 CUSFE 
  Pkg_Parametre.deger('AMF_TAX_EXPLANATION',ls_7048_tax_explanation);----bahianab CBS-603 CUSFE 

  p_7048_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_ACC_BRANCH');
  p_7048_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_TRAN_BRANCH');
  p_7048_ACC :=Pkg_Muhasebe.parametre_index_bul('7048_ACC');
  p_7048_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7048_INCOME_GL');
  p_7048_CY :=Pkg_Muhasebe.parametre_index_bul('7048_CY');
  p_7048_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_EXPLAIN');

  p_7048_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_FC');
  p_7048_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_LC');
  p_7048_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7048_INCOME_LC'); ----bahianab CBS-603 CUSFE 
  p_7048_RATE :=Pkg_Muhasebe.parametre_index_bul('7048_RATE');

  p_7048_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_FC');
  p_7048_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_LC');
  p_7048_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_EXPLAIN');

  ln_amnt_ind := 0;
  ls_cy_ind := NULL;
  ln_amnt_corp := 0;
  ls_cy_corp := NULL;

  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'ACCMAINFEE'
    AND CUSTOMER_TYPE = 'INDIVIDUAL';
  IF ln_cnt = 1
  THEN
   SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
   INTO ln_amnt_ind,ls_cy_ind
   FROM CBS_MASRAF_KRITERLERI
   WHERE CHARGE_CODE = 'ACCMAINFEE'
     AND CUSTOMER_TYPE = 'INDIVIDUAL';
  ELSE
   RAISE birden_fazla_parametre_var;
  END IF;
  --
  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'ACCMAINFEE'
    AND CUSTOMER_TYPE = 'CORPORATE';
  IF ln_cnt = 1
  THEN
   SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
   INTO ln_amnt_corp,ls_cy_corp
   FROM CBS_MASRAF_KRITERLERI
   WHERE CHARGE_CODE = 'ACCMAINFEE'
     AND CUSTOMER_TYPE = 'CORPORATE';
  ELSE
   RAISE birden_fazla_parametre_var;
  END IF;
  --
  ld_bas := TO_DATE(TO_CHAR(LTRIM(RTRIM('01'||TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'MMYYYY')))),'DD.MM.YYYY');
  ld_son := LAST_DAY(pkg_muhasebe.banka_tarihi_bul);
  ln_yil := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY'));
  ln_ay := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM'));
  --
  OPEN c_musteri ;
  LOOP
   FETCH c_musteri INTO r_musteri  ;
   EXIT WHEN c_musteri%NOTFOUND;
     ln_amnt := 0;
     ls_cy := NULL;
    ls_uygun := 'H';
    --
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
    WHERE musteri_no = r_musteri.musteri_no
      AND islem_kodu = 7048
      AND masraf_kodu = 'ACCMAINFEE';
    --
    IF ln_cnt = 1
    THEN
     SELECT NVL(TUTAR,0), DOVIZ
     INTO ln_amnt, ls_cy
     FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
     WHERE musteri_no = r_musteri.musteri_no
     AND islem_kodu = 7048
     AND masraf_kodu = 'ACCMAINFEE';
    ELSE
     IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
     THEN
      ln_amnt := NVL(ln_amnt_ind,0);
      ls_cy := ls_cy_ind;
     END IF;
     IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
     THEN
      ln_amnt := NVL(ln_amnt_corp,0);
      ls_cy := ls_cy_corp;
     END IF;
    END IF;
    --
    IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
    THEN
     IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
     THEN
      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_HESAP
      WHERE durum_kodu = 'A'
        AND musteri_no =  r_musteri.musteri_no
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
        --AND doviz_kodu <> pkg_genel.LC_al  230922 bahianab
        AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      IF ln_cnt > 0
      THEN
       ls_uygun := 'E';
      END IF;
     END IF;
     --
     IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
     THEN
      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_HESAP
      WHERE durum_kodu = 'A'
        AND musteri_no = r_musteri.musteri_no
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
        AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      --
      IF ln_cnt > 0
      THEN
       ls_uygun := 'E';
      END IF;
     END IF;
     --
     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = 'ACCMAINFEE'
       AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

     IF ln_cnt = 1
     THEN
      SELECT DKHESAP_1
      INTO ls_dk
      FROM CBS_MASRAF_DKGRUP_DK
      WHERE MASRAF_KODU = 'ACCMAINFEE'
        AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
     ELSE
      RAISE dk_yok;--o
     END IF;

     IF ls_uygun = 'E' AND ls_dk IS NOT NULL
     THEN
      ln_counter := 0;
      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = 'ACCMAINFEE'
        AND musteri_no = r_musteri.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;

      IF ln_cnt > 0
      THEN
       SELECT MAX(sira)
       INTO ln_sira
       FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
       WHERE charge_code = 'ACCMAINFEE'
         AND musteri_no = r_musteri.MUSTERI_NO
         AND yil = ln_yil
         AND ay = ln_ay;
      ELSE
       ln_sira := 0;
      END IF;

      ln_toplam_tahsil := 0;
      ln_kalan_tahsilat := ln_amnt;
      ln_hesaptan_al := 1;

      OPEN c_hesap;
      LOOP
       FETCH c_hesap INTO r_hesap ;
       EXIT WHEN c_hesap%NOTFOUND;

        IF r_hesap.doviz_kodu = pkg_genel.LC_al
        THEN
          ln_plan := 2;
        ELSE
          ln_plan := 1;
        END IF;

  ------------------------------------------------ SOM ---------------------------------------------        
        IF ln_plan= 2 
        THEN --LC account
        varchar_list(p_7048_ACC_BRANCH) := NULL;
        varchar_list(p_7048_TRAN_BRANCH) := NULL;
        varchar_list(p_7048_ACC) := NULL;
        varchar_list(p_7048_INCOME_GL) := NULL;
        varchar_list(p_7048_CY) := NULL;

        varchar_list(p_7048_EXPLAIN) := ls_7048_explanation||' : '||pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; ----bahianab CBS-603 CUSFE 
        varchar_list(p_7048_TAX_EXPLAIN) := ls_7048_tax_explanation;  ----bahianab CBS-603 CUSFE 

        number_list(p_7048_AMOUNT_FC):= 0;
        number_list(p_7048_AMOUNT_LC):= 0;
        number_list(p_7048_INCOME_LC):= 0; ----bahianab CBS-603 CUSFE 
        number_list(p_7048_RATE) := 0 ;

        number_list(p_7048_TAX_FC):= 0;
        number_list(p_7048_TAX_LC):= 0;

        IF ln_hesaptan_al = 1
        THEN
         ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_kur_hesap_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := ROUND(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
         ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

         ln_vergi_tl := ROUND(((ln_masraf * ln_kur_hesap_dvz * ln_rate) / 100),2);
         ln_vergi := ROUND(ln_vergi_tl/ln_kur_hesap_dvz,2);
         
         ln_toplam_masraf :=ln_masraf+ln_vergi; ----bahianab CBS-603 CUSFE 
         --
         IF ln_bakiye > 1 ----bahianab CBS-603 CUSFE 
         THEN
          IF ln_bakiye >= ln_toplam_masraf ----bahianab CBS-603 CUSFE 
          THEN
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7048_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_AMOUNT_LC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_INCOME_LC) := ln_masraf; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_RATE) := 1;

           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     ln_plan,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); ----bahianab CBS-603 CUSFE 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       ln_plan,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           VALUES
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
            r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'FULL',ln_islem_no, ln_fis_numara, ln_masraf,'ZAMANINDA');
         ELSE
         --BOM cbs-603
          ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
          ln_vergi_tl := trunc(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
          ln_vergi := ln_vergi_tl;
          ln_toplam_masraf :=ln_muhasebelesecek_tutar+ln_vergi;
          ln_tahsil_tutar := ln_muhasebelesecek_tutar;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
         --EOM cbs-603

          varchar_list(p_7048_ACC_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7048_TRAN_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7048_ACC) := r_hesap.hesap_no;
          varchar_list(p_7048_INCOME_GL) := ls_dk;
          varchar_list(p_7048_CY) := r_hesap.DOVIZ_KODU;

          number_list(p_7048_AMOUNT_FC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_AMOUNT_LC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar; ----bahianab CBS-603 CUSFE 
           number_list(p_7048_RATE) := 1;

                                           --YT 09032010
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 
           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);
           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7048_explanation); ----bahianab CBS-603 CUSFE 
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
           TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
           STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
           TAHSIL_ZAMANI)
          VALUES
          ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
           'PARTIAL',ln_islem_no, ln_fis_numara, ln_muhasebelesecek_tutar,'ZAMANINDA');
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
------------------------------------------------------------NON-SOM-----------------------------------------------------------------------------------------------------------------
/*BOM BAHIANAB CBS-322 CUSFE Optimization*/
       ELSE --ln plan
        varchar_list(p_7048_ACC_BRANCH) := NULL;
        varchar_list(p_7048_TRAN_BRANCH) := NULL;
        varchar_list(p_7048_ACC) := NULL;
        varchar_list(p_7048_INCOME_GL) := NULL;
        varchar_list(p_7048_CY) := NULL;

        varchar_list(p_7048_EXPLAIN) := ls_7048_explanation||' : '||pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; 
        varchar_list(p_7048_TAX_EXPLAIN) := ls_7048_tax_explanation;

        number_list(p_7048_AMOUNT_FC):= 0;
        number_list(p_7048_AMOUNT_LC):= 0;
        number_list(p_7048_INCOME_LC):= 0; 
        number_list(p_7048_RATE) := 0 ;

        number_list(p_7048_TAX_FC):= 0;
        number_list(p_7048_TAX_LC):= 0;
        
       if ln_hesaptan_al = 1
        then
         ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_kur_hesap_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)),2); 
         ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

         ln_vergi_tl := round(((ln_masraf * ln_rate) / 100),2);
         ln_vergi := ln_vergi_tl;
         
         ln_total_lc_amount := ln_masraf+ln_vergi; 
         ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2);
         --
         if ln_bakiye > 0
         then
          if ln_bakiye >= ln_total_fc_amount 
          then
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7048_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_total_fc_amount;
           number_list(p_7048_AMOUNT_LC) := ln_total_lc_amount;
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar;
           number_list(p_7048_RATE) := ln_kur_hesap_dvz;

           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); 
           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); 

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
             r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,'ZAMANINDA'); 
          else
           ln_total_fc_amount := trunc((ln_bakiye-0.01),2); 
           ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); 
           ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+(ln_rate/100))),2); 
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

           varchar_list(p_7048_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7048_ACC) := r_hesap.hesap_no;
           varchar_list(p_7048_INCOME_GL) := ls_dk;
           varchar_list(p_7048_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7048_AMOUNT_FC) := ln_total_fc_amount;
           number_list(p_7048_AMOUNT_LC) := ln_total_lc_amount;
           number_list(p_7048_INCOME_LC) := ln_tahsil_tutar;
           number_list(p_7048_RATE) := ln_kur_hesap_dvz;

           number_list(p_7048_TAX_FC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2); 
           number_list(p_7048_TAX_LC):=round((number_list(p_7048_AMOUNT_LC)-number_list(p_7048_INCOME_LC)),2);

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7048_explanation); 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
            r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,'ZAMANINDA');
          end if;
         end if; 
        end if;
       /*EOM BAHIANAB  CBS-322 CUSFE Optimization*/
      END IF; --ln plan
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap;

      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      WHERE CHARGE_CODE = 'ACCMAINFEE'
        AND yil = ln_yil
        AND ay = ln_ay
        AND musteri_no = r_musteri.MUSTERI_NO;

      IF ln_cnt > 0
      THEN
          RAISE double_run_2;
      END IF;

      IF ln_kalan_tahsilat > 0
      THEN
       INSERT INTO CBS_FEE_TAH_EDILEMEYEN_ACCFEE
        (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
         TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
       VALUES
       ('ACCMAINFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
        ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
      END IF;

      IF ln_counter>0 THEN
       Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      END IF;
     END IF; --if ls_uygun = 'E' and ls_dk is not null
    END IF;
   COMMIT;
  END LOOP;
  CLOSE c_musteri;
  end if; -- End Of Month
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   LOG_AT('ACC_MAINTENANCE_FEE_2',SQLERRM,dbms_utility.format_error_backtrace); ----bahianab CBS-603 CUSFE  bahianab 
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
/******************************************************************************
   NAME        : PROCEDURE STATEMENT_FEE_2 
   Purpose     :CUSFE Optimization (Special comissions)   
   Date        :10022022 CBS-322 BahianaB
******************************************************************************/
PROCEDURE STATEMENT_FEE_2(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
 varchar_list                   Pkg_Muhasebe.varchar_array;
 number_list                    Pkg_Muhasebe.number_array;
 date_list                      Pkg_Muhasebe.date_array;
 boolean_list                   Pkg_Muhasebe.boolean_array;

 ln_fis_numara                  NUMBER;
 ln_counter                     NUMBER;
 ln_temp_numara                 NUMBER;

 p_7049_ACC_BRANCH              NUMBER;
 p_7049_TRAN_BRANCH             NUMBER;
 p_7049_ACC                     NUMBER;
 p_7049_INCOME_GL               NUMBER;
 p_7049_CY                      NUMBER;
 p_7049_EXPLAIN                 NUMBER;
 p_7049_AMOUNT_FC               NUMBER;
 p_7049_AMOUNT_LC               NUMBER;
 p_7049_INCOME_LC               NUMBER; ----bahianab CBS-603 CUSFE 
 p_7049_RATE                    NUMBER;

 p_7049_TAX_FC                  NUMBER;
 p_7049_TAX_LC                  NUMBER;
 p_7049_TAX_EXPLAIN             NUMBER;

 CURSOR c_musteri IS
  SELECT  MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
  FROM CBS_MUSTERI
  WHERE DURUM_KODU = 'A'
       AND EKSTRE_UCRETI_ALINSIN = 'E'
    AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
         FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
         WHERE ISLEM_KODU = 7049
           AND MASRAF_KODU = 'STATMNTFEE'
        )
  AND
  ('STATMNTFEE',MUSTERI_NO,TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY')),TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM')))
  NOT IN (SELECT CHARGE_CODE, MUSTERI_NO, YIL, AY
       FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE)
  AND
  ('STATMNTFEE',MUSTERI_NO,TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY')),TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM')))
  NOT IN (SELECT CHARGE_CODE, MUSTERI_NO, YIL, AY
       FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE)
      AND MUSTERI_NO IN (SELECT DISTINCT customer_no
       FROM CBS_CUSTOMER_FEE)
  ORDER BY musteri_no ;
  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap IS
  SELECT f.account_no hesap_no, f.CY_CODE doviz_kodu, h.sube_kodu sube_kodu
  FROM CBS_CUSTOMER_FEE f, CBS_HESAP h
  WHERE f.CUSTOMER_NO = r_musteri.musteri_no
  AND f.account_no = h.hesap_no
  AND h.durum_kodu = 'A'
  AND h.urun_tur_kod IN ('CURRENT','DEMAND DEP')
  ORDER BY ORDER_NO;

  r_hesap  c_hesap%ROWTYPE;

 ld_bas                         DATE;
 ld_son                         DATE;
 ln_yil                         NUMBER;
 ln_ay                          NUMBER;
 ln_cnt                         NUMBER;

 ln_kur_ucret_dvz               NUMBER;
 ln_kur_hesap_dvz               NUMBER;
 ln_masraf                      NUMBER;
 ln_bakiye                      NUMBER;
 ln_amnt                        NUMBER;
 ls_cy                          VARCHAR2(3);
 ls_uygun                       VARCHAR2(1);
 ln_sira                        NUMBER;

 ln_toplam_tahsil               NUMBER;
 ln_kalan_tahsilat              NUMBER;
 ln_hesaptan_al                 NUMBER;
 ln_muhasebelesecek_tutar       NUMBER;
 ln_tahsil_tutar                NUMBER;
 ln_kal                         NUMBER;
 ln_islem_no                    NUMBER := 0;
 ls_dk                          VARCHAR2(30);
 ln_ekstre_sikligi              NUMBER;
 ln_toplam_masraf               NUMBER; ----bahianab CBS-603 CUSFE 
 ln_total_lc_amount             NUMBER; ----bahianab CBS-603 CUSFE  
 ln_total_fc_amount             NUMBER; ----bahianab CBS-603 CUSFE  
 ln_fc_tahsil_tutar             NUMBER; ----bahianab CBS-603 CUSFE 
 ls_7049_explanation            VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7049_tax_explanation        VARCHAR2(200); ----bahianab CBS-603 CUSFE 

 double_run_1                   EXCEPTION;
 double_run_2                   EXCEPTION;
 parametre_yok                  EXCEPTION;
 birden_fazla_parametre_var     EXCEPTION;
 dk_yok                         EXCEPTION;
 ln_plan                        NUMBER;
 ln_rate                        NUMBER;
 ln_vergi                       NUMBER;
 ln_vergi_tl                    NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
  if pkg_dates.get_last_work_day_in_month(pkg_muhasebe.Banka_Tarihi_Bul) = pkg_muhasebe.Banka_Tarihi_Bul
  then --EOM
  Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
  Pkg_Parametre.deger('SF_EXPLANATION',ls_7049_explanation);----bahianab CBS-603 CUSFE 
  Pkg_Parametre.deger('SF_TAX_EXPLANATION',ls_7049_tax_explanation);----bahianab CBS-603 CUSFE 

  p_7049_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7049_ACC_BRANCH');
  p_7049_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7049_TRAN_BRANCH');
  p_7049_ACC :=Pkg_Muhasebe.parametre_index_bul('7049_ACC');
  p_7049_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7049_INCOME_GL');
  p_7049_CY :=Pkg_Muhasebe.parametre_index_bul('7049_CY');
  p_7049_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7049_EXPLAIN');

  p_7049_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7049_AMOUNT_FC');
  p_7049_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7049_AMOUNT_LC');
  p_7049_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7049_INCOME_LC'); ----bahianab CBS-603 CUSFE 
  p_7049_RATE :=Pkg_Muhasebe.parametre_index_bul('7049_RATE');

  p_7049_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_FC');
  p_7049_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_LC');
  p_7049_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7049_TAX_EXPLAIN');

  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'STATMNTFEE'
    AND CUSTOMER_TYPE = 'INDIVIDUAL';
  IF ln_cnt = 0
  THEN
   RAISE parametre_yok;
  END IF;
  --
  SELECT COUNT(*)
  INTO ln_cnt
  FROM CBS_MASRAF_KRITERLERI
  WHERE CHARGE_CODE = 'STATMNTFEE'
    AND CUSTOMER_TYPE = 'CORPORATE';
  IF ln_cnt = 0
  THEN
   RAISE parametre_yok;
  END IF;
  --
  ld_bas := TO_DATE(TO_CHAR(LTRIM(RTRIM('01'||TO_CHAR(pkg_muhasebe.banka_tarihi_bul,'MMYYYY')))),'DD.MM.YYYY');
  ld_son := LAST_DAY(pkg_muhasebe.banka_tarihi_bul);
  ln_yil := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'YYYY'));
  ln_ay := TO_NUMBER(TO_CHAR(pkg_muhasebe.Banka_Tarihi_Bul,'MM'));
  --
  OPEN c_musteri ;
  LOOP
   FETCH c_musteri INTO r_musteri  ;
   EXIT WHEN c_musteri%NOTFOUND;
     ln_amnt := 0;
     ls_cy := NULL;
    ls_uygun := 'H';
    --
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_HESAP
    WHERE durum_kodu = 'A'
      AND musteri_no = r_musteri.musteri_no
      AND EKSTRE_SIKLIGI IS NOT NULL
      AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
      AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
    --
    IF ln_cnt > 0
    THEN
     ls_uygun := 'E';
    END IF;
    --
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = 'ACCSTMNFEE'
      AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = 'ACCSTMNFEE'
       AND DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_uygun = 'E' AND ls_dk IS NOT NULL
    THEN
     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
     WHERE musteri_no = r_musteri.musteri_no
       AND islem_kodu = 7049
       AND masraf_kodu = 'STATMNTFEE';
     --
     IF ln_cnt = 1
     THEN
      SELECT NVL(TUTAR,0), DOVIZ
      INTO ln_amnt, ls_cy
      FROM CBS_MUSTERI_ISLEM_MASRAF_FIX
      WHERE musteri_no = r_musteri.musteri_no
      AND islem_kodu = 7049
      AND masraf_kodu = 'STATMNTFEE';
     ELSE
      SELECT MIN(EKSTRE_SIKLIGI)
      INTO ln_ekstre_sikligi
      FROM CBS_HESAP
      WHERE durum_kodu = 'A'
        AND musteri_no = r_musteri.musteri_no
        AND EKSTRE_SIKLIGI IS NOT NULL
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
        AND pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
      --
      IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
      THEN
       SELECT COUNT(*)
       INTO ln_cnt
       FROM CBS_MASRAF_KRITERLERI
       WHERE CHARGE_CODE = 'STATMNTFEE'
         AND CUSTOMER_TYPE = 'INDIVIDUAL'
         AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       IF ln_cnt = 1
       THEN
        SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
        INTO ln_amnt,ls_cy
        FROM CBS_MASRAF_KRITERLERI
        WHERE CHARGE_CODE = 'STATMNTFEE'
          AND CUSTOMER_TYPE = 'INDIVIDUAL'
          AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       ELSE
        RAISE birden_fazla_parametre_var;
       END IF;
      END IF;
      --
      IF pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
      THEN
       SELECT COUNT(*)
       INTO ln_cnt
       FROM CBS_MASRAF_KRITERLERI
       WHERE CHARGE_CODE = 'STATMNTFEE'
         AND CUSTOMER_TYPE = 'CORPORATE'
         AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       IF ln_cnt = 1
       THEN
        SELECT CHARGE_AMOUNT, CHARGE_CURRENCY
        INTO ln_amnt,ls_cy
        FROM CBS_MASRAF_KRITERLERI
        WHERE CHARGE_CODE = 'STATMNTFEE'
          AND CUSTOMER_TYPE = 'CORPORATE'
          AND STATEMENT_FREQUENCY = ln_ekstre_sikligi;
       ELSE
        RAISE birden_fazla_parametre_var;
       END IF;
      END IF;
     END IF;
     --
     IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
     THEN
      ln_counter := 0;

      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = 'STATMNTFEE'
        AND musteri_no = r_musteri.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;

      IF ln_cnt > 0
      THEN
       SELECT MAX(sira)
       INTO ln_sira
       FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
       WHERE charge_code = 'STATMNTFEE'
         AND musteri_no = r_musteri.MUSTERI_NO
         AND yil = ln_yil
         AND ay = ln_ay;
      ELSE
       ln_sira := 0;
      END IF;

      ln_toplam_tahsil := 0;
      ln_kalan_tahsilat := ln_amnt;
      ln_hesaptan_al := 1;
      
      OPEN c_hesap ;
      LOOP
       FETCH c_hesap INTO r_hesap  ;
       EXIT WHEN c_hesap%NOTFOUND;

        IF r_hesap.doviz_kodu = pkg_genel.LC_al
        THEN
          ln_plan := 2;
        ELSE
          ln_plan := 1;
        END IF;
        
 ------------------------------------------------ SOM ---------------------------------------------         
        IF ln_plan = 2 
        THEN
        varchar_list(p_7049_ACC_BRANCH) := NULL;
        varchar_list(p_7049_TRAN_BRANCH) := NULL;
        varchar_list(p_7049_ACC) := NULL;
        varchar_list(p_7049_INCOME_GL) := NULL;
        varchar_list(p_7049_CY) := NULL;

        varchar_list(p_7049_TAX_EXPLAIN) := ls_7049_tax_explanation; ----bahianab CBS-603 CUSFE 
        varchar_list(p_7049_EXPLAIN) := ls_7049_explanation||' : '|| pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; ----bahianab CBS-603 CUSFE 

        number_list(p_7049_AMOUNT_FC):= 0;
        number_list(p_7049_AMOUNT_LC):= 0;
        number_list(p_7049_INCOME_LC):= 0; ----bahianab CBS-603 CUSFE  
        number_list(p_7049_RATE) := 0 ;

        number_list(p_7049_TAX_FC):=0;
        number_list(p_7049_TAX_LC):=0;

        IF ln_hesaptan_al = 1
        THEN
         ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_kur_hesap_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := ROUND(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
         ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

         ln_vergi_tl := ROUND(((ln_masraf * ln_kur_hesap_dvz * ln_rate) / 100),2);
         ln_vergi := ROUND(ln_vergi_tl/ln_kur_hesap_dvz,2);
         
         ln_toplam_masraf := ln_masraf+ln_vergi; ----bahianab CBS-603 CUSFE 
         
         --
         IF ln_bakiye > 1 ----bahianab CBS-603 CUSFE  --0
         THEN
          IF ln_bakiye >= ln_masraf + ln_vergi
          THEN
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7049_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_toplam_masraf ; ----bahianab CBS-603 CUSFE 
           number_list(p_7049_AMOUNT_LC) := ln_toplam_masraf ; ----bahianab CBS-603 CUSFE 
           number_list(p_7049_INCOME_LC) := ln_masraf;----bahianab CBS-603 CUSFE 
           number_list(p_7049_RATE) := 1;

           number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 
           number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     ln_plan,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation); ----bahianab CBS-603 CUSFE 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       ln_plan,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           VALUES
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
            r_hesap.DOVIZ_KODU,
             ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'FULL',ln_islem_no, ln_fis_numara,ln_masraf,'ZAMANINDA');
          ELSE
           --BOM CBS-603
           ln_muhasebelesecek_tutar := TRUNC(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
           ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
           ln_vergi := ln_vergi_tl;
           ln_toplam_masraf := ln_muhasebelesecek_tutar+ln_vergi;
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM CBS-603
                      
           varchar_list(p_7049_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_toplam_masraf; --CBS-603
           number_list(p_7049_AMOUNT_LC) := ln_toplam_masraf; --CBS-603
           number_list(p_7049_INCOME_LC) := ln_tahsil_tutar; --CBS-603
           number_list(p_7049_RATE) := 1;

           number_list(p_7049_TAX_FC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --CBS-603
           number_list(p_7049_TAX_LC):=ROUND((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); --CBS-603

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);
            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     ln_plan,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation); ----bahianab CBS-603 CUSFE 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       ln_plan,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           VALUES
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
             'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'ZAMANINDA');
          END IF;
         END IF;  -- if ln_bakiye >= 0
        END IF;
------------------------------------------------------------NON-SOM-----------------------------------------------------------------------------------------------------------------
/*BOM BAHIANAB  CBS-322 CUSFE Optimization*/
       ELSE 
        varchar_list(p_7049_ACC_BRANCH) := NULL;
        varchar_list(p_7049_TRAN_BRANCH) := NULL;
        varchar_list(p_7049_ACC) := NULL;
        varchar_list(p_7049_INCOME_GL) := NULL;
        varchar_list(p_7049_CY) := NULL;

        varchar_list(p_7049_TAX_EXPLAIN) := ls_7049_tax_explanation;
        varchar_list(p_7049_EXPLAIN) := ls_7049_explanation||' : '|| pkg_tx7047.month_name(ln_ay)||' / '|| ln_yil; 

        number_list(p_7049_AMOUNT_FC):= 0;
        number_list(p_7049_AMOUNT_LC):= 0;
        number_list(p_7049_INCOME_LC):= 0;
        number_list(p_7049_RATE) := 0 ;

        number_list(p_7049_TAX_FC):=0;
        number_list(p_7049_TAX_LC):=0;
        
       if ln_hesaptan_al = 1
        then
         ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_kur_hesap_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
         ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)),2); 
         ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

         ln_vergi_tl := round(((ln_masraf * ln_rate) / 100),2); 
         ln_vergi := ln_vergi_tl;
         
         ln_total_lc_amount := ln_masraf+ln_vergi; 
         ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2);
         --
         if ln_bakiye > 0
         then
          if ln_bakiye >= ln_total_fc_amount 
          then
           ln_tahsil_tutar := ln_kalan_tahsilat;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); 
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := 0;

           varchar_list(p_7049_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_total_fc_amount;
           number_list(p_7049_AMOUNT_LC) := ln_total_lc_amount;
           number_list(p_7049_INCOME_LC) := ln_tahsil_tutar;
           number_list(p_7049_RATE) := ln_kur_hesap_dvz;

           number_list(p_7049_TAX_LC):=round((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2); 
           number_list(p_7049_TAX_FC):=round((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2);           

           IF ln_counter = 0
           THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation); 
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
             r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,'ZAMANINDA');
          else
           ln_total_fc_amount := trunc((ln_bakiye-0.01),2); 
           ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); 
           ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+(ln_rate/100))),2); 
           ln_tahsil_tutar := ln_muhasebelesecek_tutar;
           ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
           ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
           ln_kal := ln_kalan_tahsilat;
           ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

           varchar_list(p_7049_ACC_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_TRAN_BRANCH) := r_hesap.SUBE_KODU;
           varchar_list(p_7049_ACC) := r_hesap.hesap_no;
           varchar_list(p_7049_INCOME_GL) := ls_dk;
           varchar_list(p_7049_CY) := r_hesap.DOVIZ_KODU;

           number_list(p_7049_AMOUNT_FC) := ln_total_fc_amount;
           number_list(p_7049_AMOUNT_LC) := ln_total_lc_amount;
           number_list(p_7049_INCOME_LC) := ln_tahsil_tutar;
           number_list(p_7049_RATE) := ln_kur_hesap_dvz;

           number_list(p_7049_TAX_FC):=round((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2);
           number_list(p_7049_TAX_LC):=round((number_list(p_7049_AMOUNT_LC)-number_list(p_7049_INCOME_LC)),2);

           IF ln_counter = 0 THEN
            ln_islem_no:=Pkg_Batch.islem_yarat(7049, r_musteri.BOLUM_KODU);

            ln_fis_numara:=Pkg_Muhasebe.fis_kes(7049,
                     1,
                     ln_islem_no,
                     varchar_list,
                     number_list,
                     date_list,
                     boolean_list ,
                     NULL,
                     FALSE,
                     0,
                     ls_7049_explanation);
           ELSE
            ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7049,
                       1,
                       ln_fis_numara,
                       varchar_list,
                       number_list,
                       date_list,
                       boolean_list,
                       NULL,
                       FALSE);
           END IF;
           ln_counter:=ln_counter+1;
           --
           ln_sira := ln_sira + 1 ;
           insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
           (CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
            TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
            STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
            TAHSIL_ZAMANI)
           values
           ('STATMNTFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,
            r_hesap.DOVIZ_KODU,
            ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,
            'ZAMANINDA');
          end if;
         end if; -- if ln_bakiye >= 0
        end if;
        /*EOM BAHIANAB  CBS-322 CUSFE Optimization*/        
        END IF; --ln_plan
        --
        IF ln_kalan_tahsilat = 0
        THEN
         ln_hesaptan_al := 0;
        END IF;
      END LOOP;
      CLOSE c_hesap;

      SELECT COUNT(*)
      INTO ln_cnt
      FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
      WHERE CHARGE_CODE = 'STATMNTFEE'
        AND yil = ln_yil
        AND ay = ln_ay
        AND musteri_no = r_musteri.MUSTERI_NO;

      IF ln_cnt > 0
      THEN
          RAISE double_run_2;
      END IF;

      IF ln_kalan_tahsilat > 0
      THEN
       INSERT INTO CBS_FEE_TAH_EDILEMEYEN_ACCFEE
        (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
         TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
       VALUES
       ('STATMNTFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
        ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
      END IF;

      IF ln_counter>0 THEN
       Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      END IF;
     END IF; --if ls_uygun = 'E' and ls_dk is not null
    END IF;
   COMMIT;
  END LOOP;
  CLOSE c_musteri;
  end if; -- End Of Month
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||'STATMNTFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||'STATMNTFEE'||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
     WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5126'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5127'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   LOG_AT('STATEMENT_FEE_2',SQLERRM,dbms_utility.format_error_backtrace); ----bahianab CBS-603 CUSFE  bahianab 
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
/******************************************************************************
   NAME        : PROCEDURE ACC_STMNT_FEE_DAILY_CHARGE_2 
   Purpose     :CUSFE Optimization (Special comissions)   
   Date        :10022022 CBS-322 BahianaB
******************************************************************************/
PROCEDURE ACC_STMNT_FEE_DAILY_CHARGE_2(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
 varchar_list                   Pkg_Muhasebe.varchar_array;
 number_list                    Pkg_Muhasebe.number_array;
 date_list                      Pkg_Muhasebe.date_array;
 boolean_list                   Pkg_Muhasebe.boolean_array;

 ln_fis_numara                  NUMBER;
 ln_counter                     NUMBER;
 ln_temp_numara                 NUMBER;

 p_7054_ACC_BRANCH              NUMBER;
 p_7054_TRAN_BRANCH             NUMBER;
 p_7054_ACC                     NUMBER;
 p_7054_INCOME_GL               NUMBER;
 p_7054_CY                      NUMBER;
 p_7054_EXPLAIN                 NUMBER;
 p_7054_AMOUNT_FC               NUMBER;
 p_7054_AMOUNT_LC               NUMBER;
 p_7054_INCOME_LC               NUMBER;----bahianab CBS-603 CUSFE 
 p_7054_RATE                    NUMBER;

 p_7054_TAX_FC                  NUMBER;
 p_7054_TAX_LC                  NUMBER;
 p_7054_TAX_EXPLAIN             NUMBER;

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE
  WHERE NVL(TAHSIL_EDILEMEYEN,0) > 0
   AND CHARGE_CODE IN ('ACCMAINFEE','STATMNTFEE')
      AND MUSTERI_NO IN (SELECT DISTINCT customer_no
          FROM CBS_CUSTOMER_FEE)
  ORDER BY charge_code,musteri_no,yil,ay;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
 --
 CURSOR c_hesap IS
  SELECT f.account_no hesap_no, f.CY_CODE doviz_kodu, h.sube_kodu sube_kodu
  FROM CBS_CUSTOMER_FEE f, CBS_HESAP h
  WHERE f.CUSTOMER_NO = r_tahsil_edilemeyen.musteri_no
  AND f.account_no = h.hesap_no
  AND h.durum_kodu = 'A'
  AND h.urun_tur_kod IN ('CURRENT','DEMAND DEP')
  ORDER BY ORDER_NO;

  r_hesap  c_hesap%ROWTYPE;
 --
 ln_yil                         NUMBER;
 ln_ay                          NUMBER;

 ln_cnt                         NUMBER;

 ln_kur_ucret_dvz               NUMBER;
 ln_kur_hesap_dvz               NUMBER;
 ln_masraf                      NUMBER;
 ln_bakiye                      NUMBER;
 ln_amnt                        NUMBER;
 ls_cy                          VARCHAR2(3);
 ln_sira                        NUMBER;

 ln_toplam_tahsil               NUMBER;
 ln_kalan_tahsilat              NUMBER;
 ln_hesaptan_al                 NUMBER;
 ln_muhasebelesecek_tutar       NUMBER;
 ln_tahsil_tutar                NUMBER;
 ln_kal                         NUMBER;
 ln_islem_no                    NUMBER := 0;
 ls_dk                          VARCHAR2(30);
 ln_toplam_masraf               NUMBER; ----bahianab CBS-603 CUSFE 
 ln_total_lc_amount             NUMBER; ----bahianab CBS-603 CUSFE  
 ln_total_fc_amount             NUMBER; ----bahianab CBS-603 CUSFE  
 ln_fc_tahsil_tutar             NUMBER; ----bahianab CBS-603 CUSFE 
 ls_7054_amf_explanation        VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7054_amf_daily_explanation  VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7054_amf_tax_explanation    VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7054_sf_explanation         VARCHAR2(200); ----bahianab CBS-603 CUSFE 
 ls_7054_sf_tax_explanation     VARCHAR2(200); ----bahianab CBS-603 CUSFE 

 double_run_1                   EXCEPTION;
 double_run_2                   EXCEPTION;
 birden_fazla_parametre_var     EXCEPTION;
 parametre_yok                  EXCEPTION;
 dk_yok                         EXCEPTION;
 ln_rate                        NUMBER;
 ln_vergi                       NUMBER;
 ln_vergi_tl                    NUMBER;
 ln_plan                        NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
 p_7054_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7054_ACC_BRANCH');
 p_7054_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7054_TRAN_BRANCH');
 p_7054_ACC :=Pkg_Muhasebe.parametre_index_bul('7054_ACC');
 p_7054_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7054_INCOME_GL');
 p_7054_CY :=Pkg_Muhasebe.parametre_index_bul('7054_CY');
 p_7054_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7054_EXPLAIN');

 p_7054_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7054_AMOUNT_FC');
 p_7054_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7054_AMOUNT_LC');
 p_7054_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('7054_INCOME_LC'); ----bahianab CBS-603 CUSFE 
 p_7054_RATE :=Pkg_Muhasebe.parametre_index_bul('7054_RATE');

 p_7054_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_FC');
 p_7054_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_LC');
 p_7054_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7054_TAX_EXPLAIN');
 --

 Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
 Pkg_Parametre.deger('AMF_EXPLANATION',ls_7054_amf_explanation);----bahianab CBS-603 CUSFE 
 Pkg_Parametre.deger('AMF_DAILY_EXPLANATION',ls_7054_amf_daily_explanation);----bahianab CBS-603 CUSFE 
 Pkg_Parametre.deger('AMF_TAX_EXPLANATION',ls_7054_amf_tax_explanation);----bahianab CBS-603 CUSFE 
 Pkg_Parametre.deger('SF_DAILY_EXPLANATION',ls_7054_sf_explanation);----bahianab CBS-603 CUSFE 
 Pkg_Parametre.deger('SF_TAX_EXPLANATION',ls_7054_sf_tax_explanation);----bahianab CBS-603 CUSFE 

 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
   ln_yil := r_tahsil_edilemeyen.yil;
   ln_ay := r_tahsil_edilemeyen.ay;

    ln_amnt := 0;
    ls_cy := NULL;
   --
   ln_amnt := NVL(r_tahsil_edilemeyen.TAHSIL_EDILEMEYEN,0);
   ls_cy := r_tahsil_edilemeyen.MASRAF_DOVIZ;
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = DECODE(r_tahsil_edilemeyen.CHARGE_CODE,'STATMNTFEE','ACCSTMNFEE',r_tahsil_edilemeyen.CHARGE_CODE)
      AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = DECODE(r_tahsil_edilemeyen.CHARGE_CODE,'STATMNTFEE','ACCSTMNFEE',r_tahsil_edilemeyen.CHARGE_CODE)
       AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
       AND yil = ln_yil
       AND ay = ln_ay;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN_ACCFEE
      WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
        AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;

     OPEN c_hesap;
     LOOP
      FETCH c_hesap INTO r_hesap ;
      EXIT WHEN c_hesap%NOTFOUND;

       IF r_hesap.doviz_kodu = pkg_genel.LC_al
       THEN
         ln_plan := 2;
       ELSE
         ln_plan := 1;
       END IF;

------------------------------------------------ SOM ---------------------------------------------    
       IF ln_plan= 2 
        THEN --LC account           
       varchar_list(p_7054_ACC_BRANCH) := NULL;
       varchar_list(p_7054_TRAN_BRANCH) := NULL;
       varchar_list(p_7054_ACC) := NULL;
       varchar_list(p_7054_INCOME_GL) := NULL;
       varchar_list(p_7054_CY) := NULL;
        
       IF r_tahsil_edilemeyen.CHARGE_CODE = 'ACCMAINFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_amf_daily_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; ----bahianab CBS-603 CUSFE 
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_amf_tax_explanation; ----bahianab CBS-603 CUSFE 
       END IF;

       IF r_tahsil_edilemeyen.CHARGE_CODE = 'STATMNTFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_sf_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; ----bahianab CBS-603 CUSFE 
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_sf_tax_explanation; ----bahianab CBS-603 CUSFE 
       END IF;
       
       number_list(p_7054_AMOUNT_FC):= 0;
       number_list(p_7054_AMOUNT_LC):= 0;
       number_list(p_7054_INCOME_LC):= 0; ----bahianab CBS-603 CUSFE 
       number_list(p_7054_RATE) := 0 ;

       number_list(p_7054_TAX_FC):= 0;
       number_list(p_7054_TAX_LC):= 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := ROUND((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

        ln_vergi_tl := ROUND(((ln_masraf*ln_rate)/100),2);
        ln_vergi := ln_vergi_tl;
               
        ln_toplam_masraf :=ln_masraf+ln_vergi; ----bahianab CBS-603 CUSFE 
        --
        IF ln_bakiye > 1 ----bahianab CBS-603 CUSFE 
        THEN
         IF ln_bakiye >= ln_toplam_masraf ----bahianab CBS-603 CUSFE --ln_masraf + ln_vergi
         THEN
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_7054_ACC_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_AMOUNT_LC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_INCOME_LC) := ln_masraf; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_RATE) := 1;

          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 
          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); ----bahianab CBS-603 CUSFE 
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_masraf,'GECIKMELI');
         ELSE
          --BOM cbs-603
          ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+(ln_rate/100))),2);
          ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2);
          ln_toplam_masraf :=ln_muhasebelesecek_tutar+ln_vergi_tl;
          ln_tahsil_tutar := ln_muhasebelesecek_tutar;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;
           --EOM cbs-603
           
          varchar_list(p_7054_ACC_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_AMOUNT_LC) := ln_toplam_masraf; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar; ----bahianab CBS-603 CUSFE 
          number_list(p_7054_RATE) := 1;

                                          --YT 09032010
          number_list(p_7054_TAX_FC):=ROUND((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 
          number_list(p_7054_TAX_LC):=ROUND((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2); ----bahianab CBS-603 CUSFE 

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); ----bahianab CBS-603 CUSFE 
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         END IF;
        END IF;  -- if ln_bakiye >= 0
       END IF;
       ------------------------------------------------------------NON-SOM-----------------------------------------------------------------------------------------------------------------
/*BOM BAHIANAB CBS-322 CUSFE Optimization*/
       ELSE --ln plan
       varchar_list(p_7054_ACC_BRANCH) := NULL;
       varchar_list(p_7054_TRAN_BRANCH) := NULL;
       varchar_list(p_7054_ACC) := NULL;
       varchar_list(p_7054_INCOME_GL) := NULL;
       varchar_list(p_7054_CY) := NULL;

        IF r_tahsil_edilemeyen.CHARGE_CODE = 'ACCMAINFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_amf_daily_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil; 
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_amf_tax_explanation; 
       END IF;

       IF r_tahsil_edilemeyen.CHARGE_CODE = 'STATMNTFEE'
       THEN
        varchar_list(p_7054_EXPLAIN) := ls_7054_sf_explanation||' : '||pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)||' / '||r_tahsil_edilemeyen.yil;  
        varchar_list(p_7054_TAX_EXPLAIN) := ls_7054_sf_tax_explanation;
       END IF;

       number_list(p_7054_AMOUNT_FC):= 0;
       number_list(p_7054_AMOUNT_LC):= 0;
       number_list(p_7054_INCOME_LC):= 0;
       number_list(p_7054_RATE) := 0 ;

       number_list(p_7054_TAX_FC):=0;
       number_list(p_7054_TAX_LC):=0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_kur_hesap_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)),2); 
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap.hesap_no),0)),2);

        ln_vergi_tl := round(((ln_masraf * ln_rate) / 100),2);
        ln_vergi := ln_vergi_tl;
         
        ln_total_lc_amount := ln_masraf+ln_vergi; 
        ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); 
        --
        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_total_fc_amount 
         THEN
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_7054_ACC_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_total_fc_amount;
          number_list(p_7054_AMOUNT_LC) := ln_total_lc_amount;
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar;
          number_list(p_7054_RATE) := ln_kur_hesap_dvz;

          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2);
          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2);

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    ln_plan,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation); 
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      ln_plan,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI');
         ELSE
          ln_total_fc_amount := trunc((ln_bakiye-0.01),2); 
          ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); 
          ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+(ln_rate/100))),2); 
          ln_tahsil_tutar := ln_muhasebelesecek_tutar;
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2);
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_7054_ACC_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_TRAN_BRANCH) := r_hesap.SUBE_KODU;
          varchar_list(p_7054_ACC) := r_hesap.hesap_no;
          varchar_list(p_7054_INCOME_GL) := ls_dk;
          varchar_list(p_7054_CY) := r_hesap.DOVIZ_KODU;

          number_list(p_7054_AMOUNT_FC) := ln_total_fc_amount;
          number_list(p_7054_AMOUNT_LC) := ln_total_lc_amount; 
          number_list(p_7054_INCOME_LC) := ln_tahsil_tutar;
          number_list(p_7054_RATE) := ln_kur_hesap_dvz;

          number_list(p_7054_TAX_FC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2);
          number_list(p_7054_TAX_LC):=round((number_list(p_7054_AMOUNT_LC)-number_list(p_7054_INCOME_LC)),2);

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(7054, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(7054,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_7054_amf_explanation);
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7054,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN_ACCFEE
          (CHARGE_CODE,YIL,AY,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap.HESAP_NO,r_hesap.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI');
         END IF;
        END IF; 
       END IF;
       /*EOM BAHIANAB CBS-322 CUSFE Optimization*/
      END IF; --ln plan
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap;

     UPDATE CBS_FEE_TAH_EDILEMEYEN_ACCFEE
     SET TAHSIL_EDILEMEYEN = ln_kalan_tahsilat,
         TOPLAM_TAHSIL_TUTAR = MASRAF_TUTARI-ln_kalan_tahsilat
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.musteri_no
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF; --if ls_uygun = 'E' and ls_dk is not null
   END IF;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5130'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   LOG_AT('ACC_STMNT_FEE_DAILY_CHARGE_2',SQLERRM,dbms_utility.format_error_backtrace); --bahianab CBS-603 CUSFE
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
--BOM aisuluud cq1225
PROCEDURE COMMISSION_TAX_CHARGE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;

 ln_fis_numara   NUMBER;
 ln_counter   NUMBER;
 ln_temp_numara   NUMBER;

 pn_8804_HESAP_SUBE NUMBER;
 pn_8804_ACC_TYPE NUMBER;
 pn_8804_HESAP_NO_LC NUMBER;
 pn_8804_TUTAR_TL_TAX_LC NUMBER;
 pn_8804_BANKA_ACIKLAMA_T NUMBER;
 pn_8804_MUSTERI_ACIKLAMA_T NUMBER;
 pn_8804_REFERANS NUMBER;
 pn_8804_HESAP_NO NUMBER;
 pn_8804_TAX_LC NUMBER;
 pn_8804_MASRAF_SUBE NUMBER;
 pn_8804_HESAP_NO_2 NUMBER;
 pn_8804_VADESIZ_BOS NUMBER;
 pn_8804_DK_SERVICE_TAX NUMBER;
 
 ln_tutar_tax number;
 ln_musteri_no number;
 ls_card_no varchar2(100);
 ls_from_account_number varchar2(100);
 ls_to_account_number varchar2(100);
 ln_cnt number;
 ls_terminal_id varchar2(2000);
 ls_referance varchar2(100);
 ls_musteri_aciklama varchar2(2000);
 ls_tax_aciklama varchar2(2000);
 ln_hesap_no_lc number; 
 ln_bakiye_lc number;
 ln_fis_no number;
 ls_modul_tur_kod varchar2(10);
 ls_urun_tur_kod varchar2(10);
 ls_urun_sinif_kod varchar2(20);
 ln_islem_kod number := 8803;
 pc_amir_bolum_kodu VARCHAR(10);
 pc_doviz_kod  varchar2(10);
 ls_in_branch varchar2(4);
 ln_count_in_branch number;
 ls_fis_aciklama varchar2(2000);

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM cbs_tax_debt
  WHERE STATUS = 'A'
  ORDER BY tx_no;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
--
 CURSOR c_hesap_som IS
  select distinct hesap_no,bakiye 
    from 
    (select  hesap_no ,
    pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)  bakiye
    from CBS_HESAP h, CBS_DEBIT_CARD_ACCOUNT d, CBS_DEBIT_CARD c
    WHERE h.musteri_no = d.customer_no
    AND h.hesap_no = d.account_no
    and D.CARD_ID_NO = C.CARD_ID_NO
    and C.STATUS='A'
    AND musteri_no = ln_musteri_no
    AND h.durum_kodu = 'A'
    AND h.urun_tur_kod in ('CURRENT','DEMAND DEP')
    and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
    and H.DOVIZ_KODU = Pkg_Genel.lc_al
    and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) >= ln_tutar_tax) 
    order by bakiye desc;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --


 ln_yil   NUMBER;
 ln_ay   NUMBER;


 ln_kur_ucret_dvz   NUMBER;
 ln_kur_hesap_dvz   NUMBER;
 ln_masraf   NUMBER;
 ln_bakiye   NUMBER;
 ln_amnt   NUMBER;
 ls_cy   VARCHAR2(3);
 ln_sira  NUMBER;

 ln_toplam_tahsil  NUMBER;
 ln_kalan_tahsilat  NUMBER;
 ln_hesaptan_al  NUMBER;
 ln_muhasebelesecek_tutar  NUMBER;
 ln_tahsil_tutar  NUMBER;
 ln_kal  NUMBER;
 ln_islem_no          NUMBER := 0;
 ls_dk   VARCHAR2(30);

 double_run_1  EXCEPTION;
 double_run_2  EXCEPTION;
 birden_fazla_parametre_var  EXCEPTION;
 parametre_yok  EXCEPTION;
 dk_yok  EXCEPTION;
 ln_rate       NUMBER;
 ln_vergi   NUMBER;
 ln_vergi_tl   NUMBER;
BEGIN
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
 pn_8804_HESAP_SUBE :=Pkg_Muhasebe.parametre_index_bul('8804_HESAP_SUBE');
 pn_8804_ACC_TYPE :=Pkg_Muhasebe.parametre_index_bul('8804_ACC_TYPE');
 pn_8804_HESAP_NO_LC :=Pkg_Muhasebe.parametre_index_bul('8804_HESAP_NO_LC');
 pn_8804_TUTAR_TL_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('8804_TUTAR_TL_TAX_LC');
 pn_8804_BANKA_ACIKLAMA_T :=Pkg_Muhasebe.parametre_index_bul('8804_BANKA_ACIKLAMA_T');
 pn_8804_MUSTERI_ACIKLAMA_T :=Pkg_Muhasebe.parametre_index_bul('8804_MUSTERI_ACIKLAMA_T');
 pn_8804_REFERANS :=Pkg_Muhasebe.parametre_index_bul('8804_REFERANS');
 pn_8804_HESAP_NO :=Pkg_Muhasebe.parametre_index_bul('8804_HESAP_NO');
 pn_8804_TAX_LC := Pkg_Muhasebe.parametre_index_bul('8804_TAX_LC');
 pn_8804_MASRAF_SUBE := Pkg_Muhasebe.parametre_index_bul('8804_MASRAF_SUBE');
 pn_8804_HESAP_NO_2 := pkg_muhasebe.parametre_index_bul('8804_HESAP_NO_2');
 pn_8804_VADESIZ_BOS := pkg_muhasebe.parametre_index_bul('8804_VADESIZ_BOS');
 pn_8804_DK_SERVICE_TAX := pkg_muhasebe.parametre_index_bul('8804_DK_SERVICE_TAX');


 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
  
  ls_fis_aciklama :=  pkg_genel.ISLEM_ADI_AL(ln_islem_kod);
  ln_musteri_no := r_tahsil_edilemeyen.customer_no;
  
   begin
    select card_number,
            from_account_number,
            to_account_number          
    into   ls_card_no ,
            ls_from_account_number,
            ls_to_account_number
    from cbs_atm_finansal_islem
    where tx_no =  r_tahsil_edilemeyen.tx_no;
            
   exception when others then 
   null;
   end;
   
   begin
    select modul_tur_kod,
            urun_tur_kod,
            urun_sinif_kod          
    into   ls_modul_tur_kod,
            ls_urun_tur_kod,
            ls_urun_sinif_kod
    from cbs_atm_sorgu_islem
    where tx_no =  r_tahsil_edilemeyen.tx_no;
            
   exception when others then 
   null;
   end;
   
   select count(*)
    into ln_cnt
    from   cbs_atm_islem
    where  numara = r_tahsil_edilemeyen.tx_no;
    
    if ln_cnt = 1
    then
        select terminal_id,
                referance,
                trim(terminal_id)|| ',com for '|| decode( islem_kod,8800,'ATM Money Withdrawal'||','|| nvl(ls_from_account_number,hesap_numara),8803,'Mini Statement'||','|| nvl(ls_from_account_number,hesap_numara),8805,'Mini Statement'||','|| nvl(ls_from_account_number,hesap_numara),8807,'Pos Selling Transaction'||','|| nvl(ls_from_account_number,hesap_numara),8810,'FX Buy Transaction' ||','|| nvl(ls_from_account_number,hesap_numara),8812,'Fx Sell Transaction'||','|| nvl(ls_from_account_number,hesap_numara),8806,'ATM Money Transfer from '|| to_char(ls_from_account_number)||' to '||  to_char(ls_to_account_number),pkg_genel.ISLEM_ADI_AL(islem_kod ) )||decode(ls_card_no,null,null,','||ls_card_no)  musteri_aciklama,
                trim(terminal_id)|| ',tax for '|| decode( islem_kod,8800,'ATM Money Withdrawal'||','|| nvl(ls_from_account_number,hesap_numara),8803,'Mini Statement'||','|| nvl(ls_from_account_number,hesap_numara),8805,'Mini Statement'||','|| nvl(ls_from_account_number,hesap_numara),8807,'Pos Selling Transaction'||','|| nvl(ls_from_account_number,hesap_numara),8810,'FX Buy Transaction' ||','|| nvl(ls_from_account_number,hesap_numara),8812,'Fx Sell Transaction'||','|| nvl(ls_from_account_number,hesap_numara),8806,'ATM Money Transfer from '|| to_char(ls_from_account_number)||' to '||  to_char(ls_to_account_number),pkg_genel.ISLEM_ADI_AL(islem_kod ) )||decode(ls_card_no,null,null,','||ls_card_no)  musteri_aciklama_t
        into   ls_terminal_id ,
                ls_referance,
                ls_musteri_aciklama,
                ls_tax_aciklama
        from   cbs_atm_islem
        where  numara = r_tahsil_edilemeyen.tx_no or numara = r_tahsil_edilemeyen.tx_no ;
    end if;         
    
    select count(*)
    into ln_count_in_branch
    from CBS_ATM_POS_TRAN_LOG
    where CBS_TRANSACTION_NO = r_tahsil_edilemeyen.tx_no;
    
    if ln_count_in_branch > 0 then    
        select substr(in_branch,2,3)
        into ls_in_branch
        from CBS_ATM_POS_TRAN_LOG 
        where CBS_TRANSACTION_NO = r_tahsil_edilemeyen.tx_no;
    end if;

     varchar_list(pn_8804_HESAP_SUBE) := null;
     varchar_list(pn_8804_ACC_TYPE) := null;
     varchar_list(pn_8804_HESAP_NO_LC) := null;         
     varchar_list(pn_8804_BANKA_ACIKLAMA_T) := null;
     varchar_list(pn_8804_MUSTERI_ACIKLAMA_T) := null;
     varchar_list(pn_8804_REFERANS) := null;
     varchar_list(pn_8804_HESAP_NO) := null;
     boolean_list(pn_8804_TAX_LC) := false;
     varchar_list(pn_8804_masraf_sube) := null;
     varchar_list(pn_8804_HESAP_NO_2) := null;
     varchar_list(pn_8804_VADESIZ_BOS) := null;
     varchar_list(pn_8804_DK_SERVICE_TAX) := null;
         
     number_list(pn_8804_TUTAR_TL_TAX_LC) := 0;
         
         ----------------------
         
         ln_tutar_tax := r_tahsil_edilemeyen.amount;
         
         begin
            select hesap_no,bakiye 
            into ln_hesap_no_lc, ln_bakiye_lc
            from 
            (select  hesap_no ,
            pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no)  bakiye
            from CBS_HESAP h, CBS_DEBIT_CARD_ACCOUNT d, CBS_DEBIT_CARD c
            WHERE h.musteri_no = d.customer_no
            AND h.hesap_no = d.account_no
            and D.CARD_ID_NO = C.CARD_ID_NO
            and C.STATUS='A'
            AND musteri_no = ln_musteri_no
            AND h.durum_kodu = 'A'
            AND h.urun_tur_kod in ('CURRENT','DEMAND DEP')
            and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
            and H.DOVIZ_KODU = Pkg_Genel.lc_al
            and pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) >= ln_tutar_tax
            order by bakiye desc)
            where  rownum=1;
         exception
         when others then
          log_at('ais_test_bat_2','error1', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            ln_hesap_no_lc := null;
            ln_bakiye_lc := null;
         end;
         
         if ln_hesap_no_lc is null and ln_bakiye_lc is null then
            boolean_list(pn_8804_TAX_LC) := false;
         elsif ln_hesap_no_lc is not null and ln_bakiye_lc is not null then
            boolean_list(pn_8804_TAX_LC) := true;   
         end if;
         
                            
         if boolean_list(pn_8804_TAX_LC) = true then    
         varchar_list(pn_8804_banka_aciklama_t)   := nvl(ls_tax_aciklama,'Service Tax');
         varchar_list(pn_8804_musteri_aciklama_t) := nvl(ls_tax_aciklama,'Service Tax');
         number_list(pn_8804_TUTAR_TL_TAX_LC) := r_tahsil_edilemeyen.amount;
         
         varchar_list(pn_8804_HESAP_NO_LC) := ln_hesap_no_lc;
         Pkg_Parametre.deger('G_SERVICE_TAX_2', varchar_list(pn_8804_DK_SERVICE_TAX));
         varchar_list(pn_8804_HESAP_NO) := ln_hesap_no_lc;
         Pkg_Parametre.deger('G_VADESIZ', varchar_list(pn_8804_ACC_TYPE));
         varchar_list(pn_8804_HESAP_SUBE) := pkg_hesap.HesaptanSubeAl(ln_hesap_no_lc);
         varchar_list(pn_8804_REFERANS) := ln_hesap_no_lc;
         varchar_list(pn_8804_MASRAF_SUBE) := ls_in_branch;
         varchar_list(pn_8804_HESAP_NO_2) := ln_hesap_no_lc;
         Pkg_Parametre.deger('G_VADESIZ', varchar_list(pn_8804_VADESIZ_BOS));
         
         ln_islem_no:=Pkg_Tx.islem_no_al;
         pc_doviz_kod := pkg_hesap.HesaptanDovizKoduAl(ln_hesap_no_lc);
         
         log_at('ais_test_bat_2','varchar_list(pn_8804_HESAP_NO):'||varchar_list(pn_8804_HESAP_NO) || 'varchar_list(pn_8804_HESAP_SUBE): ' || varchar_list(pn_8804_HESAP_SUBE) || 
         'varchar_list(pn_8804_ACC_TYPE): ' || varchar_list(pn_8804_ACC_TYPE) || 'varchar_list(pn_8804_HESAP_NO_LC): ' || varchar_list(pn_8804_HESAP_NO_LC) || ' number_list(pn_8804_TUTAR_TL_TAX_LC): ' ||  number_list(pn_8804_TUTAR_TL_TAX_LC)
         || 'varchar_list(pn_8804_banka_aciklama_t):'||varchar_list(pn_8804_banka_aciklama_t)|| 'varchar_list(pn_8804_musteri_aciklama_t):'||varchar_list(pn_8804_musteri_aciklama_t)||'varchar_list(pn_8804_REFERANS):'||varchar_list(pn_8804_REFERANS)
         || 'varchar_list(pn_8804_MASRAF_SUBE):'||varchar_list(pn_8804_MASRAF_SUBE)||'varchar_list(pn_8804_HESAP_NO_2):'||varchar_list(pn_8804_HESAP_NO_2)||'varchar_list(pn_8804_VADESIZ_BOS):'||varchar_list(pn_8804_VADESIZ_BOS) );
         
         begin
             INSERT INTO CBS_ISLEM (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                                  KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                                  KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                                  MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                                  MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)--,KANAL_NUMARA)
             VALUES (ln_islem_no,ln_islem_kod,'N',ls_in_branch,
                                  Pkg_ATM.kanal_user,pkg_atm.kanal_rol,ls_in_branch,
                                  Pkg_Muhasebe.banka_tarihi_bul,SYSDATE,
                                  ls_modul_tur_kod,ls_urun_tur_kod,ls_urun_sinif_kod,
                                  ln_musteri_no,ln_hesap_no_lc,0,null,pc_doviz_kod);--,pkg_atm.kanal_numara);
         
         end;       
         
         ln_fis_no:=pkg_muhasebe.fis_kes(8804,
                                        11,
                                        ln_islem_no,
                                        varchar_list ,
                                        number_list  ,
                                        date_list    ,
                                        boolean_list ,
                                        null,
                                        false,
                                        0,
                                        ls_fis_aciklama);


     UPDATE cbs_tax_debt
     SET status = 'P', tx_no_proc = ln_islem_no
     WHERE tx_no = r_tahsil_edilemeyen.tx_no;

      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
      
      update cbs_islem
        set durum = 'P',
            tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
      where numara=ln_islem_no;
      
      log_at('ais_test_bat_2','ln_fis_no:' || ln_fis_no || ' ln_islem_no:' || ln_islem_no,'r_tahsil_edilemeyen.tx_no:' || r_tahsil_edilemeyen.tx_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.customer_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      
     end if; 


  COMMIT;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  
  WHEN OTHERS THEN
  log_at('ais_test_bat_2','error2 -' || ' ln_islem_no:' || ln_islem_no, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
   Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
--EOM aisuluud cq1225
/******************************************************************************
   NAME        : PROCEDURE NOTIF_CHARGE_FEE
   Prepared By : Bahiana Bektemir kyzy 
   Date        : 30102020 CBS113
******************************************************************************/
PROCEDURE NOTIF_CHARGE_FEE(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER,PS_PROGRAM_KOD VARCHAR2) 
IS
      
      ls_mesaj                        varchar2(2000):= '';
      
      CURSOR CUR_MUSTERI IS
            SELECT  MUSTERI_NO, DK_GRUP_KOD, BOLUM_KODU
              FROM CBS_MUSTERI
            WHERE DURUM_KODU = 'A'
              AND MUSTERI_TIPI_KOD IN ('1')
              AND NOTIF_PACK in (2,3) -- only for packages "Standard" and "Premium"
              AND MUSTERI_NO IN (SELECT H.MUSTERI_NO FROM CBS_HESAP H WHERE H.DURUM_KODU = 'A')--customers with active accounts                
            ORDER BY MUSTERI_NO ;

      r_musteri  cur_musteri%rowtype;
      pd_banka_tarihi date :=pkg_muhasebe.Banka_Tarihi_Bul;
    begin
       pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

     if pkg_dates.get_last_work_day_in_month(pd_banka_tarihi) = pkg_muhasebe.Banka_Tarihi_Bul
     then
            for c_musteri in cur_musteri loop
              r_musteri := c_musteri;
              NOTIF_CHARGE_FEE_CUST(pn_grup_no , pn_log_no ,ps_program_kod ,r_musteri.musteri_no ,pd_banka_tarihi );
            end loop;
                    
        commit;
     end if;

       pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
     exception
       when no_data_found then null ;
        when others then
          rollback;  
          log_at('NOTIF_CHARGE_FEE',SQLERRM,dbms_utility.format_error_backtrace); --CBS-492 bahianab 06092021  
          ls_mesaj := 'General Error ' || to_char(sqlcode) || ' ' || sqlerrm ;
          pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_mesaj);      
    end;
/******************************************************************************
   NAME        : PROCEDURE NOTIF_CHARGE_FEE_CUST
   Prepared By : Bahiana Bektemir kyzy 
   Date        : 30102020 CBS113
******************************************************************************/
PROCEDURE NOTIF_CHARGE_FEE_CUST(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER, PS_PROGRAM_KOD VARCHAR2,PN_CUSTOMER_NO NUMBER ,PD_BANKA_TARIHI DATE DEFAULT PKG_MUHASEBE.BANKA_TARIHI_BUL )
IS pragma autonomous_transaction; --CBS-492 bahianab 06092021

 varchar_list                       Pkg_Muhasebe.varchar_array;
 number_list                        Pkg_Muhasebe.number_array;
 date_list                          Pkg_Muhasebe.date_array;
 boolean_list                       Pkg_Muhasebe.boolean_array;
 ln_fis_numara                      number;
 ln_counter                         number;
 ln_temp_numara                     number;
 p_3033_ACC_BRANCH                  NUMBER;
 p_3033_TRAN_BRANCH                 NUMBER;
 p_3033_ACC                         NUMBER;
 p_3033_INCOME_GL                   NUMBER;
 p_3033_CY                          NUMBER;
 p_3033_EXPLAIN                     NUMBER;
 p_3033_AMOUNT_FC                   NUMBER;
 p_3033_AMOUNT_LC                   NUMBER;
 p_3033_RATE                        NUMBER;
 --P_3033_TAX_FC                    NUMBER;--cbs-530 bahianab 091021 commented out
 P_3033_TAX_LC                      NUMBER;
 p_3033_TAX_EXPLAIN                 NUMBER;
 --P_3033_VAT_FC                    NUMBER; ;--cbs-530 bahianab 091021 commented out
 P_3033_VAT_LC                      NUMBER;
 p_3033_VAT_EXPLAIN                 NUMBER;
 p_3033_INCOME_LC                   NUMBER;--cbs-530 bahianab 091021

 CURSOR c_musteri IS
 SELECT  MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
    FROM CBS_MUSTERI
        WHERE musteri_no = pn_customer_no and
              DURUM_KODU = 'A'
          AND MUSTERI_TIPI_KOD in ('1')
          AND NOTIF_PACK in (2,3) -- only for packages "Standard" and "Premium"
          AND MUSTERI_NO IN (SELECT H.MUSTERI_NO FROM CBS_HESAP H WHERE DURUM_KODU = 'A')--customers with active accounts
        ORDER BY musteri_no ;       

  r_musteri  c_musteri%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod in ('CURRENT','DEMAND DEP')
  and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) desc;
  r_hesap_som  c_hesap_som%ROWTYPE;
 --
 CURSOR c_hesap_non_som(ls_dvz varchar2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_musteri.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod in ('CURRENT','DEMAND DEP')
  and urun_sinif_kod not in ('OVERBALANCE-FC','OVERBALANCE-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) desc;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 LD_BAS                             DATE;
 LD_SON                             DATE;
 LN_YIL                             NUMBER;
 LN_AY                              NUMBER;
 LN_GUN                             NUMBER;
 LN_AMNT_IND                        NUMBER;
 LS_CY_IND                          VARCHAR2(3);
 LN_AMNT_CORP                       NUMBER;
 LS_CY_CORP                         VARCHAR2(3);
 LN_CNT                             NUMBER;
 LN_KUR_UCRET_DVZ                   NUMBER;
 LN_KUR_HESAP_DVZ                   NUMBER;
 LN_MASRAF                          NUMBER;
 LN_BAKIYE                          NUMBER;
 LN_AMNT                            NUMBER;
 LS_CY                              VARCHAR2(3);
 LS_UYGUN                           VARCHAR2(1);
 LN_SIRA                            NUMBER;
 LN_COMPANY_NO                      NUMBER;
 LS_KOD                             VARCHAR2(50);
 LS_DEGER                           VARCHAR2(20);
 LN_TOPLAM_TAHSIL                   NUMBER;
 LN_KALAN_TAHSILAT                  NUMBER;
 LN_HESAPTAN_AL                     NUMBER;
 LN_MUHASEBELESECEK_TUTAR           NUMBER;
 LN_TAHSIL_TUTAR                    NUMBER;
 LN_KAL                             NUMBER;
 LN_ISLEM_NO                        NUMBER := 0;
 LS_DK                              VARCHAR2(30);
 LS_MASRAF_KOD                      VARCHAR2(30);
 LN_RATE                            NUMBER;
 LN_VAT_RATE                        NUMBER;
 LN_VERGI                           NUMBER;
 LN_VERGI_TL                        NUMBER;
 LN_VERGI_TL_2                      NUMBER; 
 LS_3033_EXPLAIN                    VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_3033_TAX_EXPLAIN                VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_3033_VAT_EXPLAIN                VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_CHARGE_NOTIF                    VARCHAR2(1); --CBS-492 bahianab 06092021
 LN_TOTAL_FC_AMOUNT                    NUMBER; --cbs-530 bahianab 091021 
 LN_TOTAL_LC_AMOUNT                    NUMBER; --cbs-530 bahianab 091021
 LN_LC_TOPLAM_MASRAF                NUMBER; --cbs-530 bahianab 091021
 LN_LC_TOPLAM_MUH_TUTAR             NUMBER; --cbs-530 bahianab 091021
 LN_FC_TAHSIL_TUTAR                 NUMBER; --cbs-530 bahianab 091021
 
 LN_CNT1                            NUMBER;
 LN_CNT2                            NUMBER;
 
 DOUBLE_RUN_1                       EXCEPTION;
 DOUBLE_RUN_2                       EXCEPTION;
 BIRDEN_FAZLA_PARAMETRE_VAR         EXCEPTION;
 PARAMETRE_YOK                      EXCEPTION;
 DK_YOK                             EXCEPTION;
BEGIN
  
  Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
  Pkg_Parametre.deger('G_NOTIF_VAT_RATE',ln_vat_rate);
  Pkg_Parametre.deger('NOTIF_FEE_EXPLANATION',ls_3033_explain); --CBS-492 bahianab 06092021
  Pkg_Parametre.deger('NOTIF_TAX_EXPLANATION',ls_3033_tax_explain); --CBS-492 bahianab 06092021
  Pkg_Parametre.deger('NOTIF_VAT_EXPLANATION',ls_3033_vat_explain); --CBS-492 bahianab 06092021

  p_3033_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('3033_ACC_BRANCH');
  p_3033_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('3033_TRAN_BRANCH');
  p_3033_ACC :=Pkg_Muhasebe.parametre_index_bul('3033_ACC');
  p_3033_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('3033_INCOME_GL');
  p_3033_CY :=Pkg_Muhasebe.parametre_index_bul('3033_CY');
  p_3033_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3033_EXPLAIN');
  p_3033_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('3033_AMOUNT_FC');
  p_3033_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('3033_AMOUNT_LC');
  p_3033_RATE :=Pkg_Muhasebe.parametre_index_bul('3033_RATE');
  --P_3033_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('3033_TAX_FC'); --cbs-530 bahianab 091021 commented out
  P_3033_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('3033_TAX_LC');
  p_3033_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3033_TAX_EXPLAIN');
  --P_3033_VAT_FC :=Pkg_Muhasebe.parametre_index_bul('3033_VAT_FC'); --cbs-530 bahianab 091021 commented out
  P_3033_VAT_LC :=Pkg_Muhasebe.parametre_index_bul('3033_VAT_LC');
  p_3033_VAT_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3033_VAT_EXPLAIN');
  p_3033_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('3033_INCOME_LC');--cbs-530 bahianab 091021

  ln_amnt_ind := 0;
  ls_cy_ind := null;
  ln_amnt_corp := 0;
  ls_cy_corp := null;  
  ld_bas := to_date(to_char(ltrim(rtrim('01'||to_char(pd_banka_tarihi,'MMYYYY')))),'DD.MM.YYYY');
  ld_son := LAST_DAY(pd_banka_tarihi);
  ln_yil := to_number(to_char(pd_banka_tarihi,'YYYY'));
  ln_ay := to_number(to_char(pd_banka_tarihi,'MM'));
  ln_gun := to_number(to_char(pd_banka_tarihi,'DD'));

  --
  OPEN c_musteri ;
  LOOP
   FETCH c_musteri INTO r_musteri  ;
   EXIT WHEN c_musteri%NOTFOUND;
      select kodu, tutar, dvz into ls_masraf_kod, ln_amnt_ind, ls_cy_ind from cbs_masraf_tur where kodu =
        (select 'NOTFEEP' || (select notif_pack - 1 from cbs_musteri where durum_kodu = 'A' and notif_pack is not null and notif_pack <> 1 and musteri_no = r_musteri.MUSTERI_NO) from dual);

      select count(*)
      into ln_cnt1
      from CBS_FEE_TAHSIL_EDILEN
      where CHARGE_CODE = ls_masraf_kod
        and MUSTERI_NO = r_musteri.MUSTERI_NO
        and YIL = ln_yil
        and AY = ln_ay;

      select count(*)
      into ln_cnt2
      from CBS_FEE_TAHSIL_EDILEMEYEN
      where CHARGE_CODE = ls_masraf_kod
        and MUSTERI_NO = r_musteri.MUSTERI_NO
        and YIL = ln_yil
        and AY = ln_ay;

      if ln_cnt1 = 0 and ln_cnt2 = 0
      then
         ln_amnt := 0;
         ln_amnt := ln_amnt_ind;
         ls_cy := null;
         ls_cy := ls_cy_ind;
         ls_uygun := PKG_NOTIF_SUB.RECEIVED_NOTIFICATION_OR_NOT (r_musteri.musteri_no,ld_bas,ld_son);--CBS-492 bahianab 06092021    
      
        if nvl(ln_amnt,0) > 0 and ls_cy is not null
        then
         select count(*)
         into ln_cnt
         from CBS_MASRAF_DKGRUP_DK
         where MASRAF_KODU = ls_masraf_kod
           and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

         if ln_cnt = 1
         then
          select DKHESAP_1
          into ls_dk
          from CBS_MASRAF_DKGRUP_DK
          where MASRAF_KODU = ls_masraf_kod
            and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
         else
          raise dk_yok;
         end if;

         if ls_uygun = 'E' and ls_dk is not null
         then
          ln_counter := 0;

          select count(*)
          into ln_cnt
          from CBS_FEE_TAHSIL_EDILEN
          where charge_code = ls_masraf_kod
            and musteri_no = r_musteri.MUSTERI_NO
            and yil = ln_yil
            and ay = ln_ay;

          if ln_cnt > 0
          then
           select max(sira)
           into ln_sira
           from CBS_FEE_TAHSIL_EDILEN
           where charge_code = ls_masraf_kod
             and musteri_no = r_musteri.MUSTERI_NO
             and yil = ln_yil
             and ay = ln_ay;
          else
           ln_sira := 0;
          end if;

          ln_toplam_tahsil := 0;
          ln_kalan_tahsilat := ln_amnt;
          ln_hesaptan_al := 1;
            --
            ------------------------------------------------SOM ---------------------------------------------         
          OPEN c_hesap_som ;          
          LOOP
           FETCH c_hesap_som INTO r_hesap_som  ;
           EXIT WHEN c_hesap_som%NOTFOUND;

            varchar_list(p_3033_ACC_BRANCH) := NULL;
            varchar_list(p_3033_TRAN_BRANCH) := NULL;
            varchar_list(p_3033_ACC) := NULL;
            varchar_list(p_3033_INCOME_GL) := NULL;
            varchar_list(p_3033_CY) := NULL;

            varchar_list(p_3033_EXPLAIN) := ls_3033_explain|| ' : '||pkg_tx7047.month_name(ln_ay) || ' / ' || ln_yil; --CBS-492 bahianab 06092021
            varchar_list(p_3033_TAX_EXPLAIN) := ls_3033_tax_explain; --CBS-492 bahianab 06092021
            varchar_list(p_3033_VAT_EXPLAIN) := ls_3033_vat_explain; --CBS-492 bahianab 06092021

            number_list(p_3033_AMOUNT_FC):= 0;
            number_list(p_3033_AMOUNT_LC):= 0;
            number_list(p_3033_INCOME_LC) := 0;--cbs-530 bahianab 091021
            number_list(p_3033_RATE) := 0 ;

            --number_list(P_3033_TAX_FC):= 0; --cbs-530 bahianab 091021 commented out
            number_list(P_3033_TAX_LC):= 0;
            
            --number_list(P_3033_VAT_FC):= 0; --cbs-530 bahianab 091021 commented out
            number_list(P_3033_VAT_LC):= 0;

            if ln_hesaptan_al = 1 
            then
             ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
             ln_masraf := round((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
             ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

             ln_vergi_tl := round(((ln_masraf*ln_rate)/100),2);
             ln_vergi_tl_2 := round(((ln_masraf*ln_vat_rate)/100),2);
             ln_vergi := ln_vergi_tl+ln_vergi_tl_2;
             
             ln_lc_toplam_masraf := ln_masraf+ln_vergi; --cbs-530 bahianab 091021
             --
             if ln_bakiye > 1 --cbs-530 bahianab 091021
             then
              if ln_bakiye >= ln_masraf + ln_vergi
              then
               ln_tahsil_tutar := ln_kalan_tahsilat;
               ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
               ln_kal := ln_kalan_tahsilat;
               ln_kalan_tahsilat := 0;

               varchar_list(p_3033_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
               varchar_list(p_3033_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
               varchar_list(p_3033_ACC) := r_hesap_som.hesap_no;
               varchar_list(p_3033_INCOME_GL) := ls_dk;
               varchar_list(p_3033_CY) := r_hesap_som.DOVIZ_KODU;

               number_list(p_3033_AMOUNT_FC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
               number_list(p_3033_AMOUNT_LC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
               number_list(p_3033_INCOME_LC) := ln_masraf;--cbs-530 bahianab 091021
               number_list(p_3033_RATE) := 1;

               number_list(P_3033_TAX_LC):=round(((number_list(p_3033_INCOME_LC)*ln_rate)/100),2);
               --number_list(P_3033_TAX_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_rate)/100),2); --cbs-530 bahianab 091021 commented out
               
               number_list(P_3033_VAT_LC):=(number_list(p_3033_AMOUNT_LC)-number_list(p_3033_INCOME_LC))-number_list(P_3033_TAX_LC);--cbs-530 bahianab rounding problem
               --number_list(P_3033_VAT_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_vat_rate)/100),2); --cbs-530 bahianab 091021 commented out

               IF ln_counter = 0
               THEN
                ln_islem_no:=Pkg_Batch.islem_yarat(3033, r_musteri.BOLUM_KODU);

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(3033,
                         2,
                         ln_islem_no,
                         varchar_list,
                         number_list,
                         date_list,
                         boolean_list ,
                         NULL,
                         FALSE,
                         0,
                         ls_3033_explain); --CBS-492 bahianab 06092021
               ELSE
                ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3033,
                           2,
                           ln_fis_numara,
                           varchar_list,
                           number_list,
                           date_list,
                           boolean_list,
                           NULL,
                           FALSE);
               END IF;
               ln_counter:=ln_counter+1;
               --
               ln_sira := ln_sira + 1 ;
               insert into CBS_FEE_TAHSIL_EDILEN
               (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
                TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
                STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
                TAHSIL_ZAMANI)
               values
               (ls_masraf_kod,ln_yil,ln_ay,ln_gun,'1',r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,
                r_hesap_som.DOVIZ_KODU,
                ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
                 'FULL',ln_islem_no, ln_fis_numara, ln_masraf,'ZAMANINDA');
              else
               ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+((ln_rate/100)+(ln_vat_rate/100)))),2); --cbs-530 bahianab 091021
               ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2); --cbs-530 bahianab 091021
               ln_vergi_tl_2 := round(((ln_muhasebelesecek_tutar*ln_vat_rate)/100),2); --cbs-530 bahianab 091021
               ln_vergi := ln_vergi_tl+ln_vergi_tl_2; --cbs-530 bahianab 091021
               ln_lc_toplam_masraf := ln_muhasebelesecek_tutar+ln_vergi; --cbs-530 bahianab 091021
               ln_tahsil_tutar := ln_muhasebelesecek_tutar; --cbs-530 bahianab 091021
               ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
               ln_kal := ln_kalan_tahsilat;
               ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

               varchar_list(p_3033_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
               varchar_list(p_3033_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
               varchar_list(p_3033_ACC) := r_hesap_som.hesap_no;
               varchar_list(p_3033_INCOME_GL) := ls_dk;
               varchar_list(p_3033_CY) := r_hesap_som.DOVIZ_KODU;

               number_list(p_3033_AMOUNT_FC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021 
               number_list(p_3033_AMOUNT_LC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
               number_list(p_3033_INCOME_LC) := ln_muhasebelesecek_tutar;--cbs-530 bahianab 091021
               number_list(p_3033_RATE) := 1;

               --number_list(P_3033_TAX_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_rate)/100),2); --cbs-530 bahianab 091021 commented out
               number_list(P_3033_TAX_LC):=round(((number_list(p_3033_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
               
               --number_list(P_3033_VAT_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_vat_rate)/100),2); --cbs-530 bahianab 091021 commented out
               number_list(P_3033_VAT_LC):=(number_list(p_3033_AMOUNT_LC)-number_list(p_3033_INCOME_LC))-number_list(P_3033_TAX_LC); --cbs-530 bahianab 091021 --rounding problem

               IF ln_counter = 0 THEN 
                ln_islem_no:=Pkg_Batch.islem_yarat(3033, r_musteri.BOLUM_KODU);

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(3033,
                         2,
                         ln_islem_no,
                         varchar_list,
                         number_list,
                         date_list,
                         boolean_list ,
                         NULL,
                         FALSE,
                         0,
                         ls_3033_explain); --CBS-492 bahianab 06092021
               ELSE
                ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3033,
                           2,
                           ln_fis_numara,
                           varchar_list,
                           number_list,
                           date_list,
                           boolean_list,
                           NULL,
                           FALSE);
               END IF;
               ln_counter:=ln_counter+1;
               --
               ln_sira := ln_sira + 1 ;
               insert into CBS_FEE_TAHSIL_EDILEN
               (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
                TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
                STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
                TAHSIL_ZAMANI)
               values
               (ls_masraf_kod,ln_yil,ln_ay,ln_gun,'1',r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
                ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
                'PARTIAL',ln_islem_no, ln_fis_numara, ln_muhasebelesecek_tutar,'ZAMANINDA');
              end if;
             end if;
            end if;
            --
            if ln_kalan_tahsilat = 0
            then
             ln_hesaptan_al := 0;
            end if;
          END LOOP;
          CLOSE c_hesap_som;

          if ln_kalan_tahsilat > 0
          then
           ln_hesaptan_al := 1;
            --
            -------------------------------------------- NON SOM --------------------------------------------
           OPEN c_hesap_non_som(ls_cy) ;
                      
           LOOP
            FETCH c_hesap_non_som INTO r_hesap_non_som  ;
            EXIT WHEN c_hesap_non_som%NOTFOUND;

            varchar_list(p_3033_ACC_BRANCH) := NULL;            
            varchar_list(p_3033_TRAN_BRANCH) := NULL;
            varchar_list(p_3033_ACC) := NULL;            
            varchar_list(p_3033_INCOME_GL) := NULL;
            varchar_list(p_3033_CY) := NULL;            
            
            varchar_list(p_3033_EXPLAIN) := ls_3033_explain || ' : ' || pkg_tx7047.month_name(ln_ay) || ' / ' || ln_yil; --CBS-492 bahianab 06092021
            varchar_list(p_3033_TAX_EXPLAIN) := ls_3033_tax_explain; --CBS-492 bahianab 06092021
            varchar_list(p_3033_VAT_EXPLAIN) := ls_3033_vat_explain; --CBS-492 bahianab 06092021
            
            number_list(p_3033_AMOUNT_FC):= 0;
            number_list(p_3033_AMOUNT_LC):= 0;
            number_list(p_3033_INCOME_LC) := 0;--cbs-530 bahianab 091021
            number_list(p_3033_RATE) := 0 ;

            --number_list(P_3033_TAX_FC):=0; --cbs-530 bahianab 091021 commented out
            number_list(P_3033_TAX_LC):=0;
            
           -- number_list(P_3033_VAT_FC):=0; --cbs-530 bahianab 091021 commented out            
            number_list(P_3033_VAT_LC):=0;  
            
            if ln_hesaptan_al = 1 
            then
             ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
             ln_kur_hesap_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
             ln_masraf := round((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);--cbs-530 bahianab 091021
             ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0)),2);        
             
             ln_vergi_tl := round(((ln_masraf*ln_rate)/100),2); --cbs-530 bahianab 091021
             ln_vergi_tl_2 := round(((ln_masraf*ln_vat_rate)/100),2); --cbs-530 bahianab 091021 
             ln_vergi := ln_vergi_tl+ln_vergi_tl_2; --cbs-530 bahianab 091021
             
             ln_total_lc_amount := ln_masraf+ln_vergi; --cbs-530 bahianab 091021
             ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021

             --
             if ln_bakiye > 0
             then
              if ln_bakiye >=ln_total_fc_amount--ln_masraf + ln_vergi 
              then                            
               ln_tahsil_tutar := ln_kalan_tahsilat;
               ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
               ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
               ln_kal := ln_kalan_tahsilat;
               ln_kalan_tahsilat := 0;

               varchar_list(p_3033_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
               varchar_list(p_3033_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
               varchar_list(p_3033_ACC) := r_hesap_non_som.hesap_no;
               varchar_list(p_3033_INCOME_GL) := ls_dk;
               varchar_list(p_3033_CY) := r_hesap_non_som.DOVIZ_KODU;

               number_list(p_3033_AMOUNT_FC) := ln_total_fc_amount; --cbs-530 bahianab 091021 
               number_list(p_3033_AMOUNT_LC) := ln_total_lc_amount;--cbs-530 bahianab 091021
               number_list(p_3033_INCOME_LC) := ln_tahsil_tutar;--cbs-530 bahianab 091021
               number_list(p_3033_RATE) := ln_kur_hesap_dvz;
               
               number_list(P_3033_TAX_LC):=round(((number_list(p_3033_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
               --number_list(P_3033_TAX_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_rate)/100),2); --cbs-530 bahianab 091021--commented out
               
               number_list(P_3033_VAT_LC):=(number_list(p_3033_AMOUNT_LC)-number_list(p_3033_INCOME_LC))- number_list(P_3033_TAX_LC); --cbs-530 bahianab 091021 --rounding problem
               --number_list(P_3033_VAT_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_vat_rate)/100),2);  --cbs-530 bahianab 091021--commented out

               IF ln_counter = 0
               THEN
                ln_islem_no:=Pkg_Batch.islem_yarat(3033, r_musteri.BOLUM_KODU);

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(3033,
                         1,
                         ln_islem_no,
                         varchar_list,
                         number_list,
                         date_list,
                         boolean_list ,
                         NULL,
                         FALSE,
                         0,
                         ls_3033_explain); --CBS-492 bahianab 06092021
               ELSE
                ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3033,
                           1,
                           ln_fis_numara,
                           varchar_list,
                           number_list,
                           date_list,
                           boolean_list,
                           NULL,
                           FALSE);
               END IF; 
               ln_counter:=ln_counter+1;
               --
               ln_sira := ln_sira + 1 ;
               insert into CBS_FEE_TAHSIL_EDILEN
               (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
                TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
                STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
                TAHSIL_ZAMANI)
               values
               (ls_masraf_kod,ln_yil,ln_ay,ln_gun,'1',r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
                 r_hesap_non_som.DOVIZ_KODU,
                ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
                'FULL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar,'ZAMANINDA'); --cbs-530 bahianab 090121
              else
               ln_total_fc_amount := trunc((ln_bakiye-0.01),2); --cbs-530 bahianab 091021
               ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
               ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+((ln_rate/100)+(ln_vat_rate/100)))),2);  --cbs-530 bahianab 091021 ---rounding problem
               ln_tahsil_tutar := ln_muhasebelesecek_tutar; --cbs-530 bahianab 091021
               ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
               ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
               ln_kal := ln_kalan_tahsilat;
               ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

               varchar_list(p_3033_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
               varchar_list(p_3033_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
               varchar_list(p_3033_ACC) := r_hesap_non_som.hesap_no;
               varchar_list(p_3033_INCOME_GL) := ls_dk;
               varchar_list(p_3033_CY) := r_hesap_non_som.DOVIZ_KODU;

               number_list(p_3033_AMOUNT_FC) := ln_total_fc_amount; --cbs-530 bahianab 091021
               number_list(p_3033_AMOUNT_LC) := ln_total_lc_amount;--cbs-530 bahianab 091021 
               number_list(p_3033_INCOME_LC) := ln_tahsil_tutar;--cbs-530 bahianab 091021
               number_list(p_3033_RATE) := ln_kur_hesap_dvz;
               
               --number_list(P_3033_TAX_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_rate)/100),2); --cbs-530 bahianab 091021 commented out
               number_list(P_3033_TAX_LC):=round(((number_list(p_3033_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
               
               --number_list(P_3033_VAT_FC):=round(((number_list(p_3033_AMOUNT_FC)*ln_vat_rate)/100),2);--cbs-530 bahianab 091021 commented out
               number_list(P_3033_VAT_LC):=(number_list(p_3033_AMOUNT_LC)-number_list(p_3033_INCOME_LC))- number_list(P_3033_TAX_LC); --cbs-530 bahianab 091021 --rounding problem

               IF ln_counter = 0
               THEN
                ln_islem_no:=Pkg_Batch.islem_yarat(3033, r_musteri.BOLUM_KODU);

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(3033,
                         1,
                         ln_islem_no,
                         varchar_list,
                         number_list,
                         date_list,
                         boolean_list ,
                         NULL,
                         FALSE,
                         0,
                         ls_3033_explain); --CBS-492 bahianab 06092021
               ELSE
                ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3033,
                           1,
                           ln_fis_numara,
                           varchar_list,
                           number_list,
                           date_list,
                           boolean_list,
                           NULL,
                           FALSE);
               END IF;
               ln_counter:=ln_counter+1;
               --
               ln_sira := ln_sira + 1 ;
               insert into CBS_FEE_TAHSIL_EDILEN
               (CHARGE_CODE, YIL, AY, GUN, KART_NO, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
                TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
                STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
                TAHSIL_ZAMANI)
               values
               (ls_masraf_kod,ln_yil,ln_ay,ln_gun,'1',r_musteri.MUSTERI_NO,ln_sira, r_hesap_non_som.HESAP_NO,
                r_hesap_non_som.DOVIZ_KODU,
                ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
                'PARTIAL',ln_islem_no, ln_fis_numara, ln_fc_tahsil_tutar, --cbs-530 bahianab
                'ZAMANINDA');
              end if;
             end if;
            end if;
             
            --
            if ln_kalan_tahsilat = 0
            then
             ln_hesaptan_al := 0;
            end if;
           END LOOP; 
           CLOSE c_hesap_non_som;
          end if;

          select count(*)
          into ln_cnt
          from CBS_FEE_TAHSIL_EDILEMEYEN
          where CHARGE_CODE = ls_masraf_kod
            and yil = ln_yil
            and ay = ln_ay
            and musteri_no = r_musteri.MUSTERI_NO;

          if ln_cnt > 0
          then
              raise double_run_2;
          end if;
          
          if ln_kalan_tahsilat > 0
          then
           insert into CBS_FEE_TAHSIL_EDILEMEYEN
            (CHARGE_CODE,MUSTERI_NO,YIL,AY,GUN,KART_NO,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
             TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
           values
           (ls_masraf_kod,r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_gun,'1',ln_amnt,ls_cy,ln_toplam_tahsil,
            ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
          end if;

          IF ln_counter>0 THEN
           Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6712'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
          END IF;
          end if;
         end if;
       COMMIT;
      end if;
  END LOOP;
  CLOSE c_musteri;

 commit;

 EXCEPTION
  when double_run_1 then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||ls_masraf_kod||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

  when double_run_2 then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||ls_masraf_kod||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
  when birden_fazla_parametre_var then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
  when dk_yok then
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
  WHEN OTHERS THEN
   ROLLBACK;
   LOG_AT('NOTIF_CHARGE_FEE_CUST',to_char(PN_CUSTOMER_NO),SQLERRM,dbms_utility.format_error_backtrace); --CBS-492 bahianab 06092021
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6710'|| Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
END;
/******************************************************************************
   NAME        : PROCEDURE NOTIF_CHARGE_FEE_DAILY
   Prepared By : Bahiana Bektemir kyzy 
   Date        : 30102020 CBS113
******************************************************************************/
PROCEDURE NOTIF_CHARGE_FEE_DAILY(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
 varchar_list                       Pkg_Muhasebe.varchar_array;
 number_list                        Pkg_Muhasebe.number_array;
 date_list                          Pkg_Muhasebe.date_array;
 boolean_list                       Pkg_Muhasebe.boolean_array;

 LN_FIS_NUMARA                      NUMBER;
 LN_COUNTER                         NUMBER;
 LN_TEMP_NUMARA                     NUMBER;
 P_3034_ACC_BRANCH                  NUMBER;
 P_3034_TRAN_BRANCH                 NUMBER;
 P_3034_ACC                         NUMBER;
 P_3034_INCOME_GL                   NUMBER;
 P_3034_CY                          NUMBER;
 P_3034_EXPLAIN                     NUMBER;
 P_3034_AMOUNT_FC                   NUMBER;
 P_3034_AMOUNT_LC                   NUMBER;
 P_3034_RATE                        NUMBER;
 --P_3034_TAX_FC                    NUMBER;  --cbs-530 bahianab 091021 commented out
 P_3034_TAX_LC                      NUMBER;
 P_3034_TAX_EXPLAIN                 NUMBER;
 --P_3034_VAT_FC                    NUMBER;  --cbs-530 bahianab 091021 commented out
 P_3034_VAT_LC                      NUMBER;
 p_3034_VAT_EXPLAIN                 NUMBER;
 p_3034_INCOME_LC                   NUMBER;--cbs-530 bahianab 091021

 CURSOR c_tahsil_edilemeyen IS
  SELECT *
  FROM CBS_FEE_TAHSIL_EDILEMEYEN
  WHERE NVL(TAHSIL_EDILEMEYEN,0) > 0
   AND CHARGE_CODE IN ('NOTFEEP1','NOTFEEP2','NOTFEEP3','NOTFEEP4') and yaratildigi_tarih > PKG_MUHASEBE.BANKA_TARIHI_BUL - 30
      AND musteri_no NOT IN (SELECT musteri_no
                                  FROM cbs_vw_hesap_izleme
                                 WHERE BADLIST_FLAG = 'E')
  ORDER BY charge_code,musteri_no,yil,ay;
  r_tahsil_edilemeyen  c_tahsil_edilemeyen%ROWTYPE;
 --
 CURSOR c_hesap_som IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC','ELCARD NON INT.BR-LC')
  AND doviz_kodu = pkg_genel.LC_al
  ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) DESC;
  r_hesap_som  c_hesap_som%ROWTYPE;
  
 --
 CURSOR c_hesap_non_som(ls_dvz VARCHAR2) IS
  SELECT *
  FROM CBS_HESAP
  WHERE musteri_no = r_tahsil_edilemeyen.musteri_no
  AND durum_kodu = 'A'
  AND urun_tur_kod IN ('CURRENT','DEMAND DEP')
  AND urun_sinif_kod NOT IN ('OVERBALANCE-FC','OVERBALANCE-LC','ELCARD NON INT.BR-LC')
  AND doviz_kodu <> pkg_genel.LC_al
  ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) DESC;
  r_hesap_non_som  c_hesap_non_som%ROWTYPE;

 LN_YIL                             NUMBER;
 LN_AY                              NUMBER;
 LN_GUN                             NUMBER;
 LN_CNT                             NUMBER;
 LN_KUR_UCRET_DVZ                   NUMBER;
 LN_KUR_HESAP_DVZ                   NUMBER;
 LN_MASRAF                          NUMBER;
 LN_BAKIYE                          NUMBER;
 LN_AMNT                            NUMBER;
 LS_CY                              VARCHAR2(3);
 LN_SIRA                            NUMBER;
 LN_TOPLAM_TAHSIL                   NUMBER;
 LN_KALAN_TAHSILAT                  NUMBER;
 LN_HESAPTAN_AL                     NUMBER;
 LN_MUHASEBELESECEK_TUTAR           NUMBER;
 LN_TAHSIL_TUTAR                    NUMBER;
 LN_KAL                             NUMBER;
 LN_ISLEM_NO                        NUMBER := 0;
 LS_DK                              VARCHAR2(30);
 LN_RATE                            NUMBER;
 LN_VAT_RATE                        NUMBER;
 LN_VERGI                           NUMBER;
 LN_VERGI_TL                        NUMBER;
 LN_VERGI_TL_2                      NUMBER;
 LS_3034_PARTIAL_EXPLAIN            VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_3034_EXPLAIN                    VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_3034_TAX_EXPLAIN                VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_3034_VAT_EXPLAIN                VARCHAR2(400); --CBS-492 bahianab 06092021
 LS_MASRAF_KOD                      VARCHAR2(200);
 LN_TOTAL_FC_AMOUNT                 NUMBER; --cbs-530 bahianab 091021 
 LN_TOTAL_LC_AMOUNT                 NUMBER; --cbs-530 bahianab 091021
 LN_LC_TOPLAM_MASRAF                NUMBER; --cbs-530 bahianab 091021
 LN_LC_TOPLAM_MUH_TUTAR             NUMBER; --cbs-530 bahianab 091021
 LN_FC_TAHSIL_TUTAR                 NUMBER; --cbs-530 bahianab 091021
 
 DOUBLE_RUN_1  EXCEPTION;
 DOUBLE_RUN_2  EXCEPTION;
 BIRDEN_FAZLA_PARAMETRE_VAR  EXCEPTION;
 PARAMETRE_YOK  EXCEPTION;
 DK_YOK  EXCEPTION;
BEGIN
 --pkg_baglam.yarat ('001', '0');
 Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 --
 p_3034_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('3034_ACC_BRANCH');
 p_3034_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('3034_TRAN_BRANCH');
 p_3034_ACC :=Pkg_Muhasebe.parametre_index_bul('3034_ACC');
 p_3034_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('3034_INCOME_GL');
 p_3034_CY :=Pkg_Muhasebe.parametre_index_bul('3034_CY');
 p_3034_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3034_EXPLAIN');
 p_3034_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('3034_AMOUNT_FC');
 p_3034_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('3034_AMOUNT_LC');
 p_3034_RATE :=Pkg_Muhasebe.parametre_index_bul('3034_RATE');
 --p_3034_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('3034_TAX_FC');  --cbs-530 bahianab 091021 commented out
 p_3034_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('3034_TAX_LC');
 p_3034_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3034_TAX_EXPLAIN');
 --P_3034_VAT_FC :=Pkg_Muhasebe.parametre_index_bul('3034_VAT_FC');  --cbs-530 bahianab 091021 commented out
 P_3034_VAT_LC :=Pkg_Muhasebe.parametre_index_bul('3034_VAT_LC');
 p_3034_VAT_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('3034_VAT_EXPLAIN');
 p_3034_INCOME_LC :=Pkg_Muhasebe.parametre_index_bul('3034_INCOME_LC');--cbs-530 bahianab 091021

 Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
 Pkg_Parametre.deger('G_NOTIF_VAT_RATE',ln_vat_rate);
 Pkg_Parametre.deger('NOTIF_FEE_PARTIAL_EXPL',ls_3034_partial_explain); --CBS-492 bahianab 06092021
 Pkg_Parametre.deger('NOTIF_FEE_EXPLANATION',ls_3034_explain); --CBS-492 bahianab 06092021
 Pkg_Parametre.deger('NOTIF_TAX_EXPLANATION',ls_3034_tax_explain); --CBS-492 bahianab 06092021
 Pkg_Parametre.deger('NOTIF_VAT_EXPLANATION',ls_3034_vat_explain); --CBS-492 bahianab 06092021

 OPEN c_tahsil_edilemeyen ;
 LOOP
  FETCH c_tahsil_edilemeyen INTO r_tahsil_edilemeyen  ;
  
  EXIT WHEN c_tahsil_edilemeyen%NOTFOUND;
   ln_yil := r_tahsil_edilemeyen.yil;
   ln_ay := r_tahsil_edilemeyen.ay;
   ln_gun := r_tahsil_edilemeyen.gun;

   ln_amnt := 0;
   ls_cy := NULL;
   --
   ln_amnt := NVL(r_tahsil_edilemeyen.TAHSIL_EDILEMEYEN,0);
   ls_cy := r_tahsil_edilemeyen.MASRAF_DOVIZ;
   select kodu into ls_masraf_kod from cbs_masraf_tur where kodu = r_tahsil_edilemeyen.CHARGE_CODE; --bahianab 09122021
        --(select 'NOTFEEP' || (select notif_pack - 1 from cbs_musteri where durum_kodu = 'A' and notif_pack is not null and notif_pack <> 1 and musteri_no = r_tahsil_edilemeyen.MUSTERI_NO) from dual);
   --
   IF NVL(ln_amnt,0) > 0 AND ls_cy IS NOT NULL
   THEN
    SELECT COUNT(*)
    INTO ln_cnt
    FROM CBS_MASRAF_DKGRUP_DK
    WHERE MASRAF_KODU = ls_masraf_kod
      AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);

    IF ln_cnt = 1
    THEN
     SELECT DKHESAP_1
     INTO ls_dk
     FROM CBS_MASRAF_DKGRUP_DK
     WHERE MASRAF_KODU = ls_masraf_kod
       AND DK_GRUP_KODU = pkg_musteri.sf_musteri_dk_grup_kod_al(r_tahsil_edilemeyen.MUSTERI_NO);
    ELSE
     RAISE dk_yok;
    END IF;

    IF ls_dk IS NOT NULL
    THEN
     ln_counter := 0;

     SELECT COUNT(*)
     INTO ln_cnt
     FROM CBS_FEE_TAHSIL_EDILEN
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
       AND yil = ln_yil
       AND ay = ln_ay;

     IF ln_cnt > 0
     THEN
      SELECT MAX(sira)
      INTO ln_sira
      FROM CBS_FEE_TAHSIL_EDILEN
      WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
        AND musteri_no = r_tahsil_edilemeyen.MUSTERI_NO
        AND yil = ln_yil
        AND ay = ln_ay;
     ELSE
      ln_sira := 0;
     END IF;

     ln_toplam_tahsil := 0;
     ln_kalan_tahsilat := ln_amnt;
     ln_hesaptan_al := 1;
     --
     ------------------------------------------------SOM ---------------------------------------------
     OPEN c_hesap_som ;
     LOOP
      FETCH c_hesap_som INTO r_hesap_som  ;
      EXIT WHEN c_hesap_som%NOTFOUND;

       varchar_list(p_3034_ACC_BRANCH) := NULL;
       varchar_list(p_3034_TRAN_BRANCH) := NULL;
       varchar_list(p_3034_ACC) := NULL;
       varchar_list(p_3034_INCOME_GL) := NULL;
       varchar_list(p_3034_CY) := NULL;

       IF r_tahsil_edilemeyen.CHARGE_CODE = ls_masraf_kod
       THEN
        varchar_list(p_3034_EXPLAIN) := ls_3034_partial_explain|| ' : ' || pkg_tx7047.month_name(r_tahsil_edilemeyen.ay)|| ' / ' || r_tahsil_edilemeyen.yil; --CBS-492 bahianab 06092021
        varchar_list(p_3034_TAX_EXPLAIN) := ls_3034_tax_explain; --CBS-492 bahianab 06092021
        varchar_list(p_3034_VAT_EXPLAIN) := ls_3034_vat_explain; --CBS-492 bahianab 06092021
       END IF;

       number_list(p_3034_AMOUNT_FC):= 0;
       number_list(p_3034_AMOUNT_LC):= 0;
       number_list(p_3034_INCOME_LC):= 0;
       number_list(p_3034_RATE) := 0 ;

       --number_list(p_3034_TAX_FC):= 0; --cbs-530 bahianab 091021 commented out
       number_list(p_3034_TAX_LC):= 0;
       
       --number_list(P_3034_VAT_FC):= 0; --cbs-530 bahianab 091021 commented out
       number_list(P_3034_VAT_LC):= 0;

       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := ROUND((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
        ln_bakiye := TRUNC((NVL(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

        ln_vergi_tl := ROUND(((ln_masraf*ln_rate)/100),2);
        ln_vergi_tl_2 := ROUND(((ln_masraf*ln_vat_rate)/100),2); 
        ln_vergi := ln_vergi_tl+ln_vergi_tl_2; 
        
        ln_lc_toplam_masraf := ln_masraf+ln_vergi; --cbs-530 bahianab 091021
        --
        IF ln_bakiye > 1 --cbs-530 bahianab 091021
        THEN
         IF ln_bakiye >= ln_masraf + ln_vergi
         THEN
          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_3034_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_3034_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_3034_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_3034_INCOME_GL) := ls_dk;
          varchar_list(p_3034_CY) := r_hesap_som.DOVIZ_KODU;

          number_list(p_3034_AMOUNT_FC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
          number_list(p_3034_AMOUNT_LC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
          number_list(p_3034_INCOME_LC) := ln_tahsil_tutar; --cbs-530 bahianab 091021
          number_list(p_3034_RATE) := 1;

          number_list(p_3034_TAX_LC):=ROUND(((number_list(p_3034_INCOME_LC)*ln_rate)/100),2);  --cbs-530 bahianab 091021
          --number_list(p_3034_TAX_FC):=ROUND(((number_list(p_3034_AMOUNT_FC)*ln_rate)/100),2);  --cbs-530 bahianab 091021 commented out
          
          number_list(P_3034_VAT_LC):=(number_list(p_3034_AMOUNT_LC)-number_list(p_3034_INCOME_LC))- number_list(p_3034_TAX_LC);--cbs-530 bahianab --rounding problem
          --number_list(P_3034_VAT_FC):=round(((number_list(p_3034_AMOUNT_FC)*ln_vat_rate)/100),2);  --cbs-530 bahianab 091021 commented out

          IF ln_counter = 0
          THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(3034, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(3034,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_3034_explain); --CBS-492 bahianab 06092021
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3034,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE,YIL,AY,GUN,KART_NO,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,ln_gun,'1',r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_masraf,'GECIKMELI');
         ELSE
          ln_muhasebelesecek_tutar := trunc(((ln_bakiye-0.01)/(1+((ln_rate/100)+(ln_vat_rate/100)))),2);  --cbs-530 bahianab 091021
          ln_vergi_tl := round(((ln_muhasebelesecek_tutar*ln_rate)/100),2); --cbs-530 bahianab 091021
          ln_vergi_tl_2 := round(((ln_muhasebelesecek_tutar*ln_vat_rate)/100),2); --cbs-530 bahianab 091021
          ln_vergi := ln_vergi_tl+ln_vergi_tl_2; --cbs-530 bahianab 091021
          ln_lc_toplam_masraf := ln_muhasebelesecek_tutar+ln_vergi; --cbs-530 bahianab 091021
          ln_tahsil_tutar := ln_muhasebelesecek_tutar; --cbs-530 bahianab 091021
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_3034_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_3034_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
          varchar_list(p_3034_ACC) := r_hesap_som.hesap_no;
          varchar_list(p_3034_INCOME_GL) := ls_dk;
          varchar_list(p_3034_CY) := r_hesap_som.DOVIZ_KODU;

          number_list(p_3034_AMOUNT_FC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
          number_list(p_3034_AMOUNT_LC) := ln_lc_toplam_masraf; --cbs-530 bahianab 091021
          number_list(p_3034_INCOME_LC) := ln_muhasebelesecek_tutar;--cbs-530 bahianab 091021
          number_list(p_3034_RATE) := 1;

          --number_list(p_3034_TAX_FC):=ROUND(((number_list(p_3034_AMOUNT_FC)*ln_rate)/100),2);  --cbs-530 bahianab 091021 commented out
          number_list(p_3034_TAX_LC):=ROUND(((number_list(p_3034_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
          
          number_list(P_3034_VAT_LC):=(number_list(p_3034_AMOUNT_LC)-number_list(p_3034_INCOME_LC))- number_list(p_3034_TAX_LC);--cbs-530 bahianab --rounding problem
          --number_list(P_3034_VAT_FC):=round(((number_list(p_3034_AMOUNT_FC)*ln_vat_rate)/100),2);  --cbs-530 bahianab 091021 commented out

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(3034, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(3034,
                    2,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_3034_explain); --CBS-492 bahianab 06092021
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3034,
                      2,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE,YIL,AY,GUN,KART_NO,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,ln_gun,'1',r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_muhasebelesecek_tutar,'GECIKMELI');
         END IF;
        END IF;
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
     END LOOP;
     CLOSE c_hesap_som;

     IF ln_kalan_tahsilat > 0
     THEN
      ln_hesaptan_al := 1;
     --
     -------------------------------------------- NON SOM --------------------------------------------
      OPEN c_hesap_non_som(ls_cy) ;
      LOOP
       FETCH c_hesap_non_som INTO r_hesap_non_som  ;
       EXIT WHEN c_hesap_non_som%NOTFOUND;

       varchar_list(p_3034_ACC_BRANCH) := NULL;
       varchar_list(p_3034_TRAN_BRANCH) := NULL;
       varchar_list(p_3034_ACC) := NULL;
       varchar_list(p_3034_INCOME_GL) := NULL;
       varchar_list(p_3034_CY) := NULL;

       IF r_tahsil_edilemeyen.CHARGE_CODE = ls_masraf_kod
       THEN
        varchar_list(p_3034_EXPLAIN) := ls_3034_partial_explain || ' : '|| pkg_tx7047.month_name(r_tahsil_edilemeyen.ay) || ' / ' || r_tahsil_edilemeyen.yil; --CBS-492 bahianab 06092021
        varchar_list(p_3034_TAX_EXPLAIN) := ls_3034_tax_explain; --CBS-492 bahianab 06092021
        varchar_list(p_3034_VAT_EXPLAIN) := ls_3034_vat_explain; --CBS-492 bahianab 06092021
       END IF;

       number_list(p_3034_AMOUNT_FC):= 0;
       number_list(p_3034_AMOUNT_LC):= 0;
       number_list(p_3034_INCOME_LC) := 0;--cbs-530 bahianab 091021
       number_list(p_3034_RATE) := 0 ;

       --number_list(p_3034_TAX_FC):=0;  --cbs-530 bahianab 091021 commented out
       number_list(p_3034_TAX_LC):=0;
       
       --number_list(P_3034_VAT_FC):=0;  --cbs-530 bahianab 091021 commented out
       number_list(P_3034_VAT_LC):=0;
  
       IF ln_hesaptan_al = 1
       THEN
        ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_kur_hesap_dvz := round((NVL(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
        ln_masraf := round((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);--cbs-530 bahianab 091021
        ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0)),2);

        ln_vergi_tl := round(((ln_masraf*ln_rate)/100),2); --cbs-530 bahianab 091021
        ln_vergi_tl_2 := round(((ln_masraf*ln_vat_rate)/100),2); --cbs-530 bahianab 091021
        ln_vergi := ln_vergi_tl+ln_vergi_tl_2; --cbs-530 bahianab 091021
        
        ln_total_lc_amount := ln_masraf+ln_vergi; --cbs-530 bahianab 091021
        ln_total_fc_amount := round(ln_total_lc_amount/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021 

        IF ln_bakiye > 0
        THEN
         IF ln_bakiye >= ln_total_fc_amount --cbs-530 bahianab 091021 
         THEN

          ln_tahsil_tutar := ln_kalan_tahsilat;
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := 0;

          varchar_list(p_3034_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_3034_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_3034_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_3034_INCOME_GL) := ls_dk;
          varchar_list(p_3034_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_3034_AMOUNT_FC) := ln_total_fc_amount; --cbs-530 bahianab 091021
          number_list(p_3034_AMOUNT_LC) := ln_total_lc_amount;--cbs-530 bahianab 091021
          number_list(p_3034_INCOME_LC) := ln_tahsil_tutar;--cbs-530 bahianab 091021
          number_list(p_3034_RATE) := ln_kur_hesap_dvz;
          
          number_list(p_3034_TAX_LC):=ROUND(((number_list(p_3034_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
          --number_list(p_3034_TAX_FC):=ROUND(((number_list(p_3034_AMOUNT_FC)*ln_rate)/100),2); --cbs-530 bahianab 091021 commented out
          
          number_list(P_3034_VAT_LC):=(number_list(p_3034_AMOUNT_LC)-number_list(p_3034_INCOME_LC))- number_list(p_3034_TAX_LC);--cbs-530 bahianab rounding problem
          --number_list(P_3034_VAT_FC):=round(((number_list(p_3034_AMOUNT_FC)*ln_vat_rate)/100),2); --cbs-530 bahianab 091021 commented out


          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(3034, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(3034,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_3034_explain); --CBS-492 bahianab 06092021
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3034,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE,YIL,AY,GUN,KART_NO,MUSTERI_NO,SIRA,HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,ln_gun,'1',r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'FULL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI'); --cbs-530 bahianab 091021
         ELSE
          ln_total_fc_amount := trunc(ln_bakiye-0.01,2); --cbs-530 bahianab 091021
          ln_total_lc_amount := round(ln_total_fc_amount*ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
          ln_muhasebelesecek_tutar := trunc((ln_total_lc_amount/(1+((ln_rate/100)+(ln_vat_rate/100)))),2);  --cbs-530 bahianab 091021 --rounding problem
          ln_tahsil_tutar := ln_muhasebelesecek_tutar; --cbs-530 bahianab 091021 
          ln_fc_tahsil_tutar := round(ln_tahsil_tutar/ln_kur_hesap_dvz,2); --cbs-530 bahianab 091021
          ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
          ln_kal := ln_kalan_tahsilat;
          ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

          varchar_list(p_3034_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;         
          varchar_list(p_3034_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
          varchar_list(p_3034_ACC) := r_hesap_non_som.hesap_no;
          varchar_list(p_3034_INCOME_GL) := ls_dk;
          varchar_list(p_3034_CY) := r_hesap_non_som.DOVIZ_KODU;

          number_list(p_3034_AMOUNT_FC) := ln_total_fc_amount; --cbs-530 bahianab 091021
          number_list(p_3034_AMOUNT_LC) := ln_total_lc_amount;--cbs-530 bahianab 091021 
          number_list(p_3034_INCOME_LC) := ln_tahsil_tutar;--cbs-530 bahianab 091021
          number_list(p_3034_RATE) := ln_kur_hesap_dvz;

          --number_list(p_3034_TAX_FC):=round(((number_list(p_3034_AMOUNT_FC)*ln_rate)/100),2);  --cbs-530 bahianab 091021 commented out
          number_list(p_3034_TAX_LC):=round(((number_list(p_3034_INCOME_LC)*ln_rate)/100),2); --cbs-530 bahianab 091021
          
          number_list(P_3034_VAT_LC):=(number_list(p_3034_AMOUNT_LC)-number_list(p_3034_INCOME_LC))- number_list(p_3034_TAX_LC);--cbs-530 bahianab --rounding problem
          --number_list(P_3034_VAT_FC):=round(((number_list(p_3034_AMOUNT_FC)*ln_vat_rate)/100),2); --cbs-530 bahianab 091021 commented out

          IF ln_counter = 0 THEN
           ln_islem_no:=Pkg_Batch.islem_yarat(3034, r_tahsil_edilemeyen.BOLUM_KODU);

           ln_fis_numara:=Pkg_Muhasebe.fis_kes(3034,
                    1,
                    ln_islem_no,
                    varchar_list,
                    number_list,
                    date_list,
                    boolean_list ,
                    NULL,
                    FALSE,
                    0,
                    ls_3034_explain); --CBS-492 bahianab 06092021
          ELSE
           ln_temp_numara:=Pkg_Muhasebe.satir_ekle (3034,
                      1,
                      ln_fis_numara,
                      varchar_list,
                      number_list,
                      date_list,
                      boolean_list,
                      NULL,
                      FALSE);
          END IF;
          ln_counter:=ln_counter+1;
          --
          ln_sira := ln_sira + 1 ;
          INSERT INTO CBS_FEE_TAHSIL_EDILEN
          (CHARGE_CODE,YIL,AY,GUN,KART_NO,MUSTERI_NO,SIRA, HESAP_NO,HESAP_DVZ,
           TAHSILAT_DVZ,TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR,TAHSILAT_SONRA_KAL_TUT,
           STATUS,ISLEM_NO, FIS_NO,TAHSIL_EDILEN_TUTAR_FC,tahsil_zamani)
          VALUES
          (r_tahsil_edilemeyen.CHARGE_CODE,ln_yil,ln_ay,ln_gun,'1',r_tahsil_edilemeyen.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,r_hesap_non_som.DOVIZ_KODU,
           ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
            'PARTIAL',ln_islem_no, ln_fis_numara,ln_fc_tahsil_tutar,'GECIKMELI'); --cbs-530 bahianab 091021
         END IF;
        END IF;
       END IF;
       --
       IF ln_kalan_tahsilat = 0
       THEN
        ln_hesaptan_al := 0;
       END IF;
      END LOOP;
      CLOSE c_hesap_non_som;
     END IF;

     UPDATE CBS_FEE_TAHSIL_EDILEMEYEN
     SET TAHSIL_EDILEMEYEN = ln_kalan_tahsilat,
         TOPLAM_TAHSIL_TUTAR = MASRAF_TUTARI-ln_kalan_tahsilat
     WHERE charge_code = r_tahsil_edilemeyen.CHARGE_CODE
       AND musteri_no = r_tahsil_edilemeyen.musteri_no
       AND yil = r_tahsil_edilemeyen.yil
       AND ay = r_tahsil_edilemeyen.ay;

     IF ln_counter>0 THEN
      Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6713'||Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     END IF;
    END IF;
   END IF;
  COMMIT;
 END LOOP;
 CLOSE c_tahsil_edilemeyen;
 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

 COMMIT;

 EXCEPTION
  WHEN double_run_1 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);

     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN double_run_2 THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
                         Pkg_Hata.GetDelimiter||r_tahsil_edilemeyen.CHARGE_CODE||
                         Pkg_Hata.GetDelimiter||TO_CHAR(r_tahsil_edilemeyen.MUSTERI_NO)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
                         Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
                Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN parametre_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5130'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN birden_fazla_parametre_var THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN dk_yok THEN
   ROLLBACK;
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  WHEN OTHERS THEN
   ROLLBACK;
   LOG_AT('NOTIF_CHARGE_FEE_DAILY',SQLERRM,dbms_utility.format_error_backtrace); --CBS-492 bahianab 06092021  
   Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6711'|| Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;

    PROCEDURE AMF_EUR_CHF_DAILY(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER, PS_PROGRAM_KOD VARCHAR2) IS
        LN_TX_NO         NUMBER;
        LN_UNPAID_AMOUNT NUMBER;

        CURSOR C_DEBTORS IS
            SELECT E.*, MD.DKHESAP_1, DVZ FROM CBS_FEE_TAH_EDILEMEYEN_ACCFEE E
            LEFT JOIN CBS_MUSTERI M ON E.MUSTERI_NO = M.MUSTERI_NO
            LEFT JOIN CBS.CBS_MASRAF_DKGRUP_DK MD ON MD.MASRAF_KODU = E.CHARGE_CODE AND MD.DK_GRUP_KODU = M.DK_GRUP_KOD
            LEFT JOIN CBS.CBS_MASRAF_TUR ON KODU = E.CHARGE_CODE
            WHERE CHARGE_CODE IN ('AMFEUR', 'AMFCHF') AND TAHSIL_EDILEMEYEN > 0;
    BEGIN
        PKG_BATCH.BASLA(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD);
        PKG_AMF_EUR_CHF.INIT_GLOBAL;
        FOR R_DEB IN C_DEBTORS LOOP
            LN_TX_NO := PKG_BATCH.ISLEM_YARAT(7046, R_DEB.BOLUM_KODU);
            LN_UNPAID_AMOUNT := PKG_AMF_EUR_CHF.ACCOUNTING_PROCESS(LN_TX_NO, R_DEB.MUSTERI_NO, R_DEB.DVZ,
                                                R_DEB.TAHSIL_EDILEMEYEN, R_DEB.DKHESAP_1, R_DEB.AY, R_DEB.YIL);

            UPDATE CBS.CBS_FEE_TAH_EDILEMEYEN_ACCFEE
            SET TOPLAM_TAHSIL_TUTAR = (R_DEB.MASRAF_TUTARI - LN_UNPAID_AMOUNT),
                TAHSIL_EDILEMEYEN   = LN_UNPAID_AMOUNT
            WHERE CHARGE_CODE = R_DEB.CHARGE_CODE AND MUSTERI_NO = R_DEB.MUSTERI_NO AND
                  YIL = R_DEB.YIL AND AY = R_DEB.AY;
        END LOOP;
        PKG_BATCH.BITIR(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD);
    EXCEPTION
    WHEN OTHERS THEN
        PKG_BATCH.LOGLA(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, SQLERRM, LN_TX_NO);
        ROLLBACK;
    END;

    PROCEDURE AMF_EUR_CHF_MONTHLY(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER, PS_PROGRAM_KOD VARCHAR2) IS

        LN_TX_NO         NUMBER;
        LD_DATE          DATE   := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL;
        LN_MONTH         NUMBER := EXTRACT(MONTH FROM LD_DATE);
        LN_YEAR          NUMBER := EXTRACT(YEAR FROM LD_DATE);
        LN_YEAR_DAYS     NUMBER := PKG_TX6208.INTEREST_BASE;
        LN_MONTH_DAYS    NUMBER := EXTRACT(DAY FROM LAST_DAY(LD_DATE));
        LN_TX_CODE       NUMBER := 7046;
        LN_CHARGE_AMOUNT NUMBER;
        LN_UNPAID_AMOUNT NUMBER;
        LN_RATE          NUMBER;
        LN_REQUIRED_AMOUNT NUMBER;

        CURSOR C_CUSTOMERS IS
            SELECT M.MUSTERI_NO, H.DOVIZ_KODU CY, NVL(MF.TUTAR, MT.YUZDE) AS AMOUNT,
                HB.ORTALAMA_BAKIYE BALANCE, H.HESAP_NO, M.BOLUM_KODU, MT.KODU, MD.DKHESAP_1
            FROM CBS.CBS_HESAP H
            LEFT JOIN CBS.CBS_MUSTERI M ON M.MUSTERI_NO = H.MUSTERI_NO
            LEFT JOIN CBS.CBS_HESAP_ORTALAMA_BAKIYE HB ON HB.HESAP_NO = H.HESAP_NO AND HB.YIL = LN_YEAR AND HB.AY = LN_MONTH
            LEFT JOIN CBS.CBS_MASRAF_TUR MT ON MT.KODU = 'AMF' || H.DOVIZ_KODU
            LEFT JOIN CBS.CBS_MASRAF_DKGRUP_DK MD ON MD.MASRAF_KODU = MT.KODU AND MD.DK_GRUP_KODU = M.DK_GRUP_KOD
            LEFT JOIN CBS.CBS_MUSTERI_ISLEM_MASRAF_FIX MF
                      ON M.MUSTERI_NO = MF.MUSTERI_NO AND MT.KODU = MF.MASRAF_KODU AND MF.ISLEM_KODU = LN_TX_CODE
            LEFT JOIN CBS.CBS_MUSTERI_ISLEM_MASRAF_MUAF MM
                      ON MM.MUSTERI_NO = M.MUSTERI_NO AND MM.MASRAF_KODU = MT.KODU AND MM.ISLEM_KODU = LN_TX_CODE
            WHERE ORTALAMA_BAKIYE >= LN_REQUIRED_AMOUNT AND
                  H.DURUM_KODU = 'A' AND H.DOVIZ_KODU IN ('EUR', 'CHF') AND
                  MUSTERI_TIPI_KOD IN ('2', '3') AND MM.MUSTERI_NO IS NULL;
    BEGIN
        PKG_BATCH.BASLA(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD);
        IF LD_DATE = PKG_TARIH.AYIN_SON_IS_GUNU(LD_DATE) THEN
            PKG_AMF_EUR_CHF.INIT_GLOBAL;
            SELECT VALUE INTO LN_REQUIRED_AMOUNT
            FROM CBS.CBS_CONST_VALUES WHERE CODE = 'AMF_EUR_CHF_NEEDED_BALANCE';
            FOR R_CUST IN C_CUSTOMERS LOOP
                LN_TX_NO := PKG_BATCH.ISLEM_YARAT(LN_TX_CODE, R_CUST.BOLUM_KODU);
                LN_RATE := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(R_CUST.CY, PKG_GENEL.LC_AL, NULL, 1, 1, NULL, NULL, 'N', 'A');
                LN_CHARGE_AMOUNT := ((R_CUST.BALANCE * R_CUST.AMOUNT) / (LN_YEAR_DAYS * 100)) * LN_MONTH_DAYS;
                LN_CHARGE_AMOUNT := ROUND(LN_CHARGE_AMOUNT * LN_RATE, 2);
                LN_UNPAID_AMOUNT := PKG_AMF_EUR_CHF.ACCOUNTING_PROCESS(LN_TX_NO, R_CUST.MUSTERI_NO, R_CUST.CY, LN_CHARGE_AMOUNT,
                                                                  R_CUST.DKHESAP_1, LN_MONTH, LN_YEAR, R_CUST.HESAP_NO);
                MERGE INTO CBS.CBS_FEE_TAH_EDILEMEYEN_ACCFEE T1
                USING (SELECT R_CUST.KODU CODE , R_CUST.MUSTERI_NO CUSTOMER FROM DUAL) T2
                ON (T1.CHARGE_CODE = T2.CODE AND T1.MUSTERI_NO = T2.CUSTOMER AND T1.YIL = LN_YEAR AND T1.AY = LN_MONTH)
                WHEN MATCHED THEN
                    UPDATE SET MASRAF_TUTARI = MASRAF_TUTARI + LN_CHARGE_AMOUNT,
                               TOPLAM_TAHSIL_TUTAR = TOPLAM_TAHSIL_TUTAR + (LN_CHARGE_AMOUNT - LN_UNPAID_AMOUNT),
                               TAHSIL_EDILEMEYEN = TAHSIL_EDILEMEYEN + LN_UNPAID_AMOUNT
                WHEN NOT MATCHED THEN
                    INSERT (CHARGE_CODE, MUSTERI_NO, YIL, AY, MASRAF_TUTARI, MASRAF_DOVIZ, TOPLAM_TAHSIL_TUTAR,
                            TAHSIL_EDILEMEYEN, BOLUM_KODU, CUSTOMER_TYPE)
                    VALUES (T2.CODE, T2.CUSTOMER, LN_YEAR, LN_MONTH, LN_CHARGE_AMOUNT,
                            PKG_GENEL.LC_AL, (LN_CHARGE_AMOUNT - LN_UNPAID_AMOUNT), LN_UNPAID_AMOUNT,
                            R_CUST.BOLUM_KODU, 'CORPORATE');
            END LOOP;
        END IF;
        PKG_BATCH.BITIR(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD);
    EXCEPTION
        WHEN OTHERS THEN
            PKG_BATCH.HATA_LOGLA(PN_GRUP_NO, PN_LOG_NO, PS_PROGRAM_KOD, SQLERRM, LN_TX_NO);
            ROLLBACK;
    END;
END;
/

