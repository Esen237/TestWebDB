create PACKAGE BODY PKG_TX1107 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

   Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_ref_tx_no 					cbs_cek_karne_islem.tx_no%type;
  ls_karne_tipi_kodu			cbs_cek_karne_islem.karne_tipi_kodu%type;
  ln_talep_edilen_karne_adedi   number := 0;
  ln_girisi_yapilan_karne_adedi number := 0;
  ls_durum_kodu					cbs_cek_karne_islem.durum_kodu%type;
  Karne_Giris_Yapildi			exception;
  Talep_Kapali					exception;
  Talep_Onceden_Iptal			exception;
  Talep_Iptal_Edilemez			exception;
  Begin

  /*  ref_tx_no ile ilgili talebin durum kodu al?n?r */
    select ref_tx_no ,karne_tipi_kodu
	into ln_ref_tx_no ,ls_karne_tipi_kodu
    from cbs_cek_karne_islem
   	where tx_no = pn_islem_no ;

	 select durum_kodu
	 into   ls_durum_kodu
     from   cbs_cek_karne_islem
	 where  tx_no =  ln_ref_tx_no ;


/* islemin durumu TG talep giris ise yapilmalidir.
  Karne girisi yapildiysa talep iptaline izin verilmeyecektir. */


  if  ls_durum_kodu in( 'TG','A') and pkg_cek.Sf_Cek_Talep_Karne_No(pn_islem_no)= 0 then
/* islem bilgisi guncellenir */
    update cbs_cek_karne_islem
	set karne_giris_tarihi = pkg_muhasebe.banka_tarihi_bul ,
	    durum_kodu = 'A'
	where tx_no = pn_islem_no ;

  /*  ref_tx_no ile ilgili talep iptal edilir*/
    update cbs_cek_karne_islem
	set durum_kodu = 'TI'
	where tx_no = ln_ref_tx_no ;
else
	if ls_durum_kodu = 'A' then
       Raise Karne_Giris_Yapildi;
	elsif ls_durum_kodu = 'TK' then
	   Raise Talep_Kapali;
	elsif ls_durum_kodu = 'TI' then
	   Raise Talep_Onceden_Iptal;
	else
		Raise Talep_Iptal_Edilemez;
    end if;
end if;

  Exception
     When Karne_Giris_Yapildi then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '400' || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     When Talep_Kapali then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '401' || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     When Talep_Onceden_Iptal then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '404' || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     When Talep_Iptal_Edilemez then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '402' || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
	 When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '139' || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_karne_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;--      Raise_application_error(-20100,'85;'||SQLERRM);
  End;
END;
/

