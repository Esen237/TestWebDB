create PACKAGE     PKG_INT_LOAN_INQ IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION GetLoans(ps_lang varchar2,
                    ps_customer_id varchar2,
                    ps_currency_code varchar2 default null,
                    ps_status varchar2 default null,
                    pc_ref OUT CursorReferenceType) RETURN varchar2;
                        
FUNCTION GetLoan(ps_lang varchar2,
                    ps_account_number varchar2,
                    pc_ref OUT CursorReferenceType) RETURN varchar2; 
                        
FUNCTION GetPaymentPlan(ps_lang varchar2,
                    ps_account_number varchar2,
                    pc_ref OUT CursorReferenceType) RETURN varchar2;      
                                                  
FUNCTION GetInstallments(ps_lang varchar2,
                    ps_account_number varchar2,
                    pc_ref OUT CursorReferenceType) RETURN varchar2;                       
                                                   
FUNCTION GetPayInstallment(ps_lang varchar2,
                    ps_account_number varchar2,
                    ps_payment_order varchar2,
                    ps_payment_date varchar2,
                    pc_ref OUT CursorReferenceType) RETURN varchar2;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
END;
/

