create PACKAGE Pkg_Scf IS

-- ?ubeler cari hesaplar?na uygulanacak faiz oranlar?

   PROCEDURE gecerli_orani_kopyala(pn_tx_no NUMBER) ;
   PROCEDURE Orani_guncelle(pn_tx_no NUMBER);
   PROCEDURE onceki_oranlari_bugune_kopyala;

-- Vadeli ?ubeler cari faiz oranlar?

   PROCEDURE vadeli_scf_gec_orani_kopyala(pn_tx_no NUMBER,pd_tarih DATE,pc_tur VARCHAR2,pc_rating_kodu VARCHAR2,pc_faiz_tur VARCHAR2);
   PROCEDURE Vadeli_scf_orani_guncelle(pn_tx_no NUMBER);
   PROCEDURE Vadeli_SCF_Orani_Kopyala;
   FUNCTION  Vadeli_sch_faiz_orani(pn_musterino NUMBER,
   			 					   ps_doviz_kodu VARCHAR2,
   			 					   ps_modul_tur_kod VARCHAR2,
								   ps_urun_tur_kod VARCHAR2,
								   ps_urun_sinif_kod VARCHAR2,
								   pn_gun_sayisi NUMBER ,
								   ps_faiz_tur VARCHAR2 DEFAULT 'S',
								   ps_overnight_evet VARCHAR2 DEFAULT 'H',
								   pd_kredi_vade DATE DEFAULT NULL) RETURN NUMBER;
  PROCEDURE sch_faiz_guncelle_bilgi_aktar(pn_islem_no IN NUMBER, pn_hesap_no IN NUMBER, ps_hesap_tipi VARCHAR2) ;
  PROCEDURE sch_faiz_tahakkuk_bilgi_aktar(pn_islem_no IN NUMBER, pn_hesap_no IN NUMBER, ps_hesap_tipi VARCHAR2) ;
END;


/

