create PACKAGE BODY     "PKG_TX2347" IS

/*---------------------------FAIZ-MASRAF-KOMISYON TAHSIL ----------------------------------------------*/
    p_2347_B_ACIKLAMA             number;
    p_2347_DOVIZ_KODU           number;
    p_2347_FC_TUTAR                  number;
    p_2347_HESAP_SUBE           number;
    p_2347_ISLEM_SUBE           number;
    p_2347_HESAP_SUBE_1           number;--CQ5638 KonstantinJ 27062017
    p_2347_ISLEM_SUBE_1           number;--CQ5638 KonstantinJ 27062017
    p_2347_ISTATISTIK_KODU       number;
    p_2347_LC_KUR                  number;
    p_2347_LC_TUTAR                  number;
    p_2347_MBANKA_HESAPNO       number;
    p_2347_M_ACIKLAMA           number;
    p_2347_REFERANS                  number;
    p_2347_VALOR_TARIHI           number;

    l_uc                       VARCHAR2(3):=pkg_hata.getUCPOINTER;
    l_ara                       VARCHAR2(3):=pkg_hata.getDELIMITER;

    --BOM CQ5627  Incoming Automation  KonstantinJ 04012017
    p_2347_ALICI_DKNO             number;
    p_2347_ALICI_HESAPNO       number;
 
    p_2347_FC_KOMISYON             number;
    p_2347_FC_NETODENEN             number;
 
    p_2347_LC_KOMISYON             number;
 
    p_2347_LC_KUR_EKRAN             number;
    p_2347_LC_NETODENEN             number;
 
    p_2347_LC_BSMV               number;
    p_2347_FC_BSMV               number;
    p_2347_LC_MASRAF_TOPLAMI   number;
    p_2347_FC_MASRAF_TOPLAMI   number;
    p_2347_LC_MAL_NETODENEN             number;
    p_2347_FC_MAL_NETODENEN             number;
    p_2347_LC_MUS_NETODENEN             number;
    p_2347_FC_MUS_NETODENEN             number;
    p_2347_ISTATISTIK_KODU_1       number;
    p_2347_ISTATISTIK_KODU_2       number;
    p_2347_KOMREF                   number;
     -- EOM CQ5627  Incoming Automation  KonstantinJ 04012017
/*------------------------------------------------------------------------------------------------------*/
 FUNCTION kur_al (ln_dvz_kod in CBS_MASRAF_KOM_TAHSIL_ISL.DVZ%TYPE) return number IS
 Begin
   NULL;
 End;
/*------------------------------------------------------------------------------------------------------*/
 Procedure Kontrol_Sonrasi(pn_islem_no number) is

  Begin


     PKG_BLACK_LIST.CHEK_update(pn_islem_no);
        
  End;

/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
   
  Begin
  
    NULL;
    
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
   Reddetme_Sonrasi(pn_islem_no);
  End;
/*------------------------------------------------------------------------------------------------------*/
 Procedure Iptal_Sonrasi(pn_islem_no number) is
  ls_referans varchar2(16);
  ln_count1 number;
  ln_count2 number;
  ln_count3 number;
  ln_count4 number;

  my_exception exception;
  l_ucpointer varchar2(3) := pkg_hata.GETUCPOINTER;
ls_ref_no cbs_yphavale_gelen_basvuru.GBANKA_REFERANS%TYPE;
 Begin
    select ref_no
     into ls_referans
     from cbs_yphavale_gelen_basvuru
     where tx_no=pn_islem_no;

   --2011
    select count(*)
     into ln_count1
     from cbs_yphavale_gelen_iade_basvur
     where REF_NO=ls_referans;

   --2012
    select count(*)
     into ln_count2
     from cbs_yphavale_gelen_odeme_basvu
     where REF_NO=ls_referans;

   --2013
    select count(*)
     into ln_count3
     from CBS_YPHAVALE_GELEN_G_BASVURU
     where REF_NO=ls_referans;

   --2014
    select count(*)
     into ln_count4
     from CBS_YPHAVALE_GELEN_ODEME_G_BAS
     where REF_NO=ls_referans;

    if ln_count1+ln_count2+ln_count3+ln_count4>0 then
          raise my_exception;
    end if;


     SELECT GBANKA_REFERANS
   INTO ls_ref_no
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no;
    
    log_at('1502231',ls_ref_no,pn_islem_no);
    
    UPDATE cbs_yphavale_gelen SET DURUM_KODU ='K' WHERE TX_NO =pn_islem_no;
    UPDATE cbs_swift_messages SET status  = 'sIncome' WHERE reference = ls_ref_no;



  exception
    when my_exception then
         Raise_application_error(-20100,l_ucpointer || '642' || l_ucpointer);
 End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number) is
  
      ls_ref_no cbs_yphavale_gelen_basvuru.GBANKA_REFERANS%TYPE;
      
  Begin
 log_at('150223',0,pn_islem_no);
 
    --ba?vuru kaydi proda aktarilacak
    insert into cbs_yphavale_gelen
    (TX_NO,REF_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, ULKE_KODU, GBANKA_BIC_KODU,
     GBANKA_REFERANS, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, ALICI_MUSTERI_NO, ALICI_HESAP_NO,
     ALICI_ADI, ALICI_ADRES, DOVIZ_KODU, TUTAR, VALOR_TARIHI, GONDEREN_ADI, GONDEREN_ADRES,
     IHRACAT_REFERANS, ISTATISTIK_KODU, ACIKLAMA, IHBAR,ACILIS_TARIHI,BOLUM_KODU,
     MBANKA_SUBE_KODU,ADRES_SEMT, ADRES_IL_KOD, ADRES_POSTA_KOD, ADRES_ULKE_KOD,GONDEREN_ADRES_2,
     GONDEREN_ULKE_KODU,PREFIX_ISTATISTIK_KODU,
     ODEME_NO  ,
 ODEME_SEKLI  ,
    NET_ODENEN_TUTAR,
      ODEME_TARIHI  ,
       REZERVASYON_NO ,
       KUR ,
       HAVALE_BAKIYESI  ,
       ODEME_TUTARI ,
       ALICI_DK_NO )
    (select
    TX_NO,REF_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, ULKE_KODU, GBANKA_BIC_KODU,
    GBANKA_REFERANS, MBANKA_MUSTERI_NO, MBANKA_HESAP_NO, ALICI_MUSTERI_NO, ALICI_HESAP_NO,
    ALICI_ADI, ALICI_ADRES, DOVIZ_KODU, TUTAR, VALOR_TARIHI, GONDEREN_ADI, GONDEREN_ADRES,
    IHRACAT_REFERANS, ISTATISTIK_KODU, ACIKLAMA, IHBAR,pkg_muhasebe.BANKA_TARIHI_BUL,BOLUM_KODU,
    MBANKA_SUBE_KODU,ADRES_SEMT, ADRES_IL_KOD, ADRES_POSTA_KOD, ADRES_ULKE_KOD,GONDEREN_ADRES_2, GONDEREN_ULKE_KODU,PREFIX_ISTATISTIK_KODU,
    ODEME_NO  ,
 ODEME_SEKLI  ,
    NET_ODENEN_TUTAR,
      ODEME_TARIHI  ,
       REZERVASYON_NO ,
       KUR ,
       HAVALE_BAKIYESI  ,
       ODEME_TUTARI ,
       ALICI_DK_NO 
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no);
    
   SELECT GBANKA_REFERANS
   INTO ls_ref_no
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no;
    
    UPDATE cbs_swift_messages SET status  = 'sProcess' WHERE reference = ls_ref_no;
 --   COMMIT;
    log_at('1511',ls_ref_no);
    
     exception    
               when Others then
               RAISE_APPLICATION_ERROR(-20100,SQLERRM||'    '||DBMS_UTILITY.FORMAT_ERROR_Backtrace);
               
    ---------------------------------------------
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  ln_rezervasyon_no number;
  ls_ref_no cbs_yphavale_gelen_basvuru.GBANKA_REFERANS%TYPE;
  Begin
  log_at('150223',3,pn_islem_no);
          SELECT GBANKA_REFERANS
   INTO ls_ref_no
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no;
    
    log_at('1502231',ls_ref_no,pn_islem_no);
    
    UPDATE cbs_yphavale_gelen SET DURUM_KODU ='K' WHERE TX_NO =pn_islem_no;
    UPDATE cbs_swift_messages SET status  = 'sIncome' WHERE reference = ls_ref_no;

  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is        -- Islem iptal edilemez
  
     ls_ref_no cbs_yphavale_gelen_basvuru.GBANKA_REFERANS%TYPE;
  
  Begin
  
  
     SELECT GBANKA_REFERANS
   INTO ls_ref_no
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no;
    
    log_at('150223',1,ls_ref_no,pn_islem_no);
    
    UPDATE cbs_yphavale_gelen SET DURUM_KODU ='K' WHERE TX_NO =pn_islem_no;
    UPDATE cbs_swift_messages SET status  = 'sIncome' WHERE reference = ls_ref_no;
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  log_at('150223',2,pn_islem_no);
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number) is
  
  Begin
  
    NULL;
      
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number) is
      varchar_list                      pkg_muhasebe.varchar_array;
    number_list                          pkg_muhasebe.number_array;
    date_list                          pkg_muhasebe.date_array;
    boolean_list                      pkg_muhasebe.boolean_array;
    ln_fis_no                          NUMBER;
    ln_plan_no                          NUMBER:=1;

    ln_masraf_komisyon                  NUMBER;--BOM CQ5627  Incoming Automation  KonstantinJ 04012017
    ln_masraf_bsmv                      NUMBER;
    ln_mal_kur                          NUMBER;
    ln_mus_kur                          NUMBER;
    ln_dk_grup_no                      cbs_musteri.DK_GRUP_KOD%type:=1021; --EOM CQ5627  Incoming Automation  KonstantinJ 04012017
    ls_ref_no                           VARCHAR2(20 BYTE);


    CURSOR islem_cursor (p_islemno cbs_islem.NUMARA%TYPE) IS
               SELECT *
            from cbs_yphavale_gelen_basvuru
            where cbs_yphavale_gelen_basvuru.TX_NO=p_islemno;

    row_islem                              islem_cursor%ROWTYPE;
    Islem_Bulunamadi_Exception          exception;

  Begin
  
  
  
  
  

  log_at('001',1,'pn_islem_no'||' '||pn_islem_no);
    
        OPEN islem_cursor(pn_islem_no);
       FETCH islem_cursor INTO row_islem;
       if islem_cursor%NOTFOUND then
          CLOSE islem_cursor;
          Raise Islem_Bulunamadi_Exception;
       end if;
       CLOSE islem_cursor;


  log_at('001',2);
  

  
       varchar_list(p_2347_B_ACIKLAMA):=row_islem.REF_NO || '-' || row_islem.ACIKLAMA;
       
  log_at('001',3,' varchar_list(p_2347_B_ACIKLAMA)'||'  '|| varchar_list(p_2347_B_ACIKLAMA));
  
       varchar_list(p_2347_DOVIZ_KODU):=row_islem.DOVIZ_KODU;
       
  log_at('001',4,'row_islem.DOVIZ_KODU'||' '||row_islem.DOVIZ_KODU);
  
       number_list(p_2347_FC_TUTAR):=row_islem.TUTAR;
       
  log_at('001',5,'row_islem.TUTAR'||' '||row_islem.TUTAR);
  
       varchar_list(p_2347_HESAP_SUBE_1):='001';--to_char(row_islem.MBANKA_SUBE_KODU); --02112022
  log_at('001',6,'to_char(row_islem.MBANKA_SUBE_KODU)'||' '||row_islem.MBANKA_SUBE_KODU);
  
   varchar_list(p_2347_ALICI_DKNO):=row_islem.ALICI_DK_NO;
    log_at('001',18,'varchar_list(p_2347_ALICI_DKNO)'||' '||varchar_list(p_2347_ALICI_DKNO));

       varchar_list(p_2347_ISLEM_SUBE_1):=pkg_baglam.bolum_kodu;--to_char(row_islem.BOLUM_KODU);--CQ5638 KonstantinJ 27062017--010
  log_at('001',7,'to_char(row_islem.BOLUM_KODU)'||'  '||row_islem.BOLUM_KODU);
   
      --bilalg
      if  pkg_tx2010.sf_istatistikkod_zorunlumu (row_islem.DOVIZ_KODU)= 'E' then
  log_at('001',8,'row_islem.DOVIZ_KODU'||'  '||row_islem.DOVIZ_KODU);
  
            varchar_list(p_2347_ISTATISTIK_KODU)  := pkg_musteri.paymentkod_formatli_al( nvl(row_islem.alici_musteri_no,row_islem.mbanka_musteri_no)  ,row_islem.ISTATISTIK_KODU) ;
  log_at('001',9, 'varchar_list(p_2347_ISTATISTIK_KODU)'||'  '|| varchar_list(p_2347_ISTATISTIK_KODU) );
      else

          varchar_list(p_2347_ISTATISTIK_KODU)  := null;
  log_at('001',10);
      end if;
      
  log_at('001',11);


       number_list(p_2347_LC_KUR):= pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,1,1,null,null,'N','A');
log_at('001',12,'number_list(p_2347_LC_KUR)'||'  '||number_list(p_2347_LC_KUR));
       number_list(p_2347_LC_TUTAR):=pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,row_islem.TUTAR,1,null,null,'N','A');
       
log_at('001',13,'number_list(p_2347_LC_TUTAR)'||' '||number_list(p_2347_LC_TUTAR));

       varchar_list(p_2347_MBANKA_HESAPNO):=to_char(row_islem.MBANKA_HESAP_NO);
 log_at('001',14, 'varchar_list(p_2347_MBANKA_HESAPNO)'||' '||varchar_list(p_2347_MBANKA_HESAPNO));
       varchar_list(p_2347_M_ACIKLAMA):=row_islem.REF_NO || '-' || row_islem.ACIKLAMA;
  log_at('001',15,' varchar_list(p_2347_M_ACIKLAMA)'||'  '|| varchar_list(p_2347_M_ACIKLAMA));
       varchar_list(p_2347_REFERANS):=row_islem.REF_NO;--'237987877AAA';--row_islem.REF_NO;
 log_at('001',16,'row_islem.REF_NO'||' '||row_islem.REF_NO);
       date_list(p_2347_VALOR_TARIHI):=row_islem.VALOR_TARIHI;
 log_at('001',17,' date_list(p_2347_VALOR_TARIHI)'||'  '|| date_list(p_2347_VALOR_TARIHI));

--BOM CQ5627  Incoming Automation  KonstantinJ 04012017
  
   
    varchar_list(p_2347_ALICI_HESAPNO):=to_char(row_islem.ALICI_HESAP_NO);
    log_at('001',19,'varchar_list(p_2347_ALICI_HESAPNO)'||'  '||varchar_list(p_2347_ALICI_HESAPNO));
    varchar_list(p_2347_B_ACIKLAMA):=row_islem.ACIKLAMA;
    log_at('001',20,'varchar_list(p_2347_B_ACIKLAMA)'||'  '||varchar_list(p_2347_B_ACIKLAMA));
    varchar_list(p_2347_M_ACIKLAMA):=row_islem.ACIKLAMA;
    log_at('001',21,'varchar_list(p_2347_M_ACIKLAMA)'||'  '||varchar_list(p_2347_M_ACIKLAMA));
    varchar_list(p_2347_REFERANS):=row_islem.REF_NO;--'237987877AAA';
    log_at('001',22,'varchar_list(p_2347_REFERANS)'||'  '||varchar_list(p_2347_REFERANS));
    varchar_list(p_2347_DOVIZ_KODU):=row_islem.DOVIZ_KODU;
    log_at('001',23,'varchar_list(p_2347_DOVIZ_KODU)'||'  '||varchar_list(p_2347_DOVIZ_KODU));
    number_list(p_2347_LC_KOMISYON):=0;--pkg_kur.YUVARLA(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,nvl(ln_masraf_komisyon,0),1,null,null,'O','A'));
    log_at('001',24);
    number_list(p_2347_FC_KOMISYON):=0;--nvl(ln_masraf_komisyon,0);
    log_at('001',25);
    number_list(p_2347_LC_BSMV):=0;--pkg_kur.YUVARLA(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,nvl(ln_masraf_bsmv,0),1,null,null,'O','A'));
    log_at('001',26);
    number_list(p_2347_FC_BSMV):=0;--nvl(ln_masraf_bsmv,0);
    log_at('001',27);
    number_list(p_2347_LC_MASRAF_TOPLAMI):=0;--nvl(number_list(p_2347_LC_KOMISYON),0)+nvl(number_list(p_2347_LC_BSMV),0);
   log_at('001',28);
    number_list(p_2347_FC_MASRAF_TOPLAMI):=0;--nvl(ln_masraf_komisyon,0)+nvl(ln_masraf_bsmv,0);
    log_at('001',29);
    number_list(p_2347_LC_KUR):= pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,1,1,null,null,'O','A');
   log_at('001',30,'number_list(p_2347_LC_KUR)'||'  '||number_list(p_2347_LC_KUR));
    
   
    if row_islem.ALICI_HESAP_NO is null then
       varchar_list(p_2347_KOMREF):=row_islem.REF_NO;
       log_at('001',31, 'varchar_list(p_2347_KOMREF)'||'  '||varchar_list(p_2347_KOMREF));
    else
        varchar_list(p_2347_KOMREF):= to_char(row_islem.ALICI_HESAP_NO);
        log_at('001',32,'varchar_list(p_2347_KOMREF)'||' '||varchar_list(p_2347_KOMREF));
    end if;



   if pkg_tx2012.sf_istatistikkod_zorunlumu(pkg_hesap.HesaptanMusteriNoAl(row_islem.ALICI_HESAP_NO),row_islem.DOVIZ_KODU)='E' then
    varchar_list(p_2347_ISTATISTIK_KODU):=pkg_musteri.paymentkod_formatli_al( pkg_hesap.HesaptanMusteriNoAl(row_islem.ALICI_HESAP_NO) ,row_islem.ISTATISTIK_KODU) ;
    log_at('001',33,'varchar_list(p_2347_ISTATISTIK_KODU)'||' '||varchar_list(p_2347_ISTATISTIK_KODU));
   end if;


    --varchar_list(p_2347_ISTATISTIK_KODU_1):=row_islem.ISTATISTIK_KODU;
    --varchar_list(p_2347_ISTATISTIK_KODU_2):=row_islem.ISTATISTIK_KODU;

    --istatistik kodu bul
    if row_islem.ODEME_SEKLI<>3 then
       /* select m.DK_GRUP_KOD
        into ln_dk_grup_no
        from cbs_musteri m
        where m.MUSTERI_NO=row_islem.ALICI_MUSTERI_NO;*/
        NULL;
        log_at('001',34);
    end if;
    if row_islem.ODEME_SEKLI=1 then
       if row_islem.REZERVASYON_NO is null then
          ln_mal_kur:=pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,1,3,null,null,'O','A');
          ln_mus_kur:=number_list(p_2347_LC_KUR);
          log_at('001',35,'ln_mal_kur'||' '||ln_mal_kur);
          log_at('001',36,'ln_mus_kur'||' '||ln_mus_kur);
          
          
       else
                 pkg_kur_rezervasyon.Rezervasyon_Alis_Bilgisi_Al(row_islem.REZERVASYON_NO,ln_mus_kur,ln_mal_kur);
          log_at('001',37);
       end if;
       number_list(p_2347_LC_MAL_NETODENEN):=pkg_kur.YUVARLA(pkg_genel.lc_al,NVL(row_islem.NET_ODENEN_TUTAR,0) * NVL(ln_mal_kur,0));
       log_at('001',38,' number_list(p_2347_LC_MAL_NETODENEN)'||' '|| number_list(p_2347_LC_MAL_NETODENEN));
          number_list(p_2347_FC_MAL_NETODENEN):=row_islem.NET_ODENEN_TUTAR;
        log_at('001',39,'number_list(p_2347_FC_MAL_NETODENEN)'||' '|| number_list(p_2347_FC_MAL_NETODENEN));
       number_list(p_2347_FC_MUS_NETODENEN):=row_islem.NET_ODENEN_TUTAR;
       log_at('001',40,'number_list(p_2347_FC_MUS_NETODENEN)'||' '||number_list(p_2347_FC_MUS_NETODENEN));
       if ln_mus_kur>ln_mal_kur then
                number_list(p_2347_LC_MUS_NETODENEN):=pkg_kur.YUVARLA(pkg_genel.lc_al,NVL(row_islem.NET_ODENEN_TUTAR,0) * NVL(ln_mus_kur-ln_mal_kur,0));
                log_at('001',41,' number_list(p_2347_LC_MUS_NETODENEN)'||' '|| number_list(p_2347_LC_MUS_NETODENEN));
             number_list(p_2347_LC_NETODENEN):=number_list(p_2347_LC_MAL_NETODENEN)+number_list(p_2347_LC_MUS_NETODENEN);
             log_at('001',42,' number_list(p_2347_LC_NETODENEN)'||' '|| number_list(p_2347_LC_NETODENEN));
       else
                number_list(p_2347_LC_MUS_NETODENEN):=pkg_kur.YUVARLA(pkg_genel.lc_al,NVL(row_islem.NET_ODENEN_TUTAR,0) * NVL(ln_mal_kur-ln_mus_kur,0));
                log_at('001',43,'number_list(p_2347_LC_MUS_NETODENEN)'||' '||number_list(p_2347_LC_MUS_NETODENEN));
             number_list(p_2347_LC_NETODENEN):=number_list(p_2347_LC_MAL_NETODENEN)-number_list(p_2347_LC_MUS_NETODENEN);
             log_at('001',44,'number_list(p_2347_LC_NETODENEN)'||' '||number_list(p_2347_LC_NETODENEN));
       end if;
          number_list(p_2347_LC_KUR_EKRAN):=row_islem.KUR;
          log_at('001',45,' number_list(p_2347_LC_KUR_EKRAN)'||' '|| number_list(p_2347_LC_KUR_EKRAN));
    else
       number_list(p_2347_LC_NETODENEN):=pkg_kur.YUVARLA(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(row_islem.DOVIZ_KODU,pkg_genel.lc_al,null,row_islem.NET_ODENEN_TUTAR,1,null,null,'O','A'));--100;
       log_at('001',46,'number_list(p_2347_LC_NETODENEN)'||' '||number_list(p_2347_LC_NETODENEN));
       number_list(p_2347_LC_KUR_EKRAN):=number_list(p_2347_LC_KUR);
       log_at('001',47,'number_list(p_2347_LC_KUR_EKRAN)'||' '||number_list(p_2347_LC_KUR_EKRAN));
    end if;
    number_list(p_2347_FC_NETODENEN):=row_islem.NET_ODENEN_TUTAR;--100;
   log_at('001',48,' number_list(p_2347_FC_NETODENEN)'||' '|| number_list(p_2347_FC_NETODENEN));

    if row_islem.ODEME_SEKLI=1 or row_islem.ODEME_SEKLI=2 then
       varchar_list(p_2347_HESAP_SUBE):= pkg_hesap.HesapSubeAl(row_islem.ALICI_HESAP_NO);--'010';
       log_at('001',49);
    end if;
    varchar_list(p_2347_ISLEM_SUBE):=pkg_baglam.bolum_kodu;--'010';--row_islem.BOLUM_KODU;
    log_at('001',50);
    --varchar_list(p_2347_ISTATISTIK_KODU):=row_islem.ISTATISTIK_KODU;

    date_list(p_2347_VALOR_TARIHI):=row_islem.VALOR_TARIHI;

    log_at('001',51,'date_list(p_2347_VALOR_TARIHI)'||' '||date_list(p_2347_VALOR_TARIHI));

    if row_islem.ODEME_SEKLI=1 then--TL Hesap
       if ln_mus_kur>ln_mal_kur then
        log_at('001',52,ln_mus_kur||' # '||ln_mal_kur);
          ln_plan_no:=3;
       else
        log_at('001',53,ln_mus_kur||' # '||ln_mal_kur);
             ln_plan_no:=7;
       end if;
    elsif row_islem.ODEME_SEKLI=2 then--DTH
        log_at('001',54,ln_mus_kur||' # '||ln_mal_kur);
        ln_plan_no:=4;
    elsif row_islem.ODEME_SEKLI=3 then---DK
        log_at('001',55,ln_mus_kur||' # '||ln_mal_kur);
        ln_plan_no:=5;
    end if;
    --BOM CQ5627  Incoming Automation  KonstantinJ 04012017
log_at('001',56,ln_plan_no);
       --fi?i kes
        ln_fis_no:=pkg_muhasebe.fis_kes(2347,
                        ln_plan_no,
                        pn_islem_no,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        row_islem.VALOR_TARIHI,
                        false,
                        0,
                        'Incoming MT Opening');

        --muhasebele?tir.
        if row_islem.VALOR_TARIHI<=pkg_muhasebe.BANKA_TARIHI_BUL then

            pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
 log_at('001',58);
        end if;
 log_at('001',59);       
        --bom bahianab cbs-113 18032021
       -- pkg_notif_sub.sf_generate_notif(pn_islem_no, 2347);
        --eom bahianab cbs-113 18032021
        
    SELECT GBANKA_REFERANS
   INTO ls_ref_no
    from cbs_yphavale_gelen_basvuru
    where TX_NO=pn_islem_no;
         
        
   UPDATE cbs_swift_messages SET status  = 'sProcess' WHERE reference = ls_ref_no;
    COMMIT;
    
 exception
       when Islem_Bulunamadi_Exception then
               Raise_application_error(-20100,l_uc || '1389'|| l_ara || pn_islem_no || l_uc);
               when Others then
               RAISE_APPLICATION_ERROR(-20100,SQLERRM||'    '||DBMS_UTILITY.FORMAT_ERROR_Backtrace);
               

  End;


/* -------------------------------------------------------------------------------------- */

  Function sf_istatistikkod_zorunlumu_1(ps_islem_sekli varchar2, pn_musteri_no number ) return varchar2
  is
   ls_musteri_tipi_kod    varchar2(1);
   ln_dk_grup_kod        number;
  Begin
         select musteri_tipi_kod,
                 dk_grup_kod
       into  ls_musteri_tipi_kod,
                ln_dk_grup_kod
       from  cbs_musteri
       where musteri_no = pn_musteri_no ;

       if (ps_islem_sekli='ACCOUNT' ) and  ( ln_dk_grup_kod = 1023 ) Then
             return 'E';
       else
             return 'H';
       end if;

      Exception
        when others then return 'H';
  End;

/* -------------------------------------------------------------------------------------- */
  Function sf_istatistikkod_zorunlumu_2(ps_islem_sekli varchar2, ps_doviz_kodu varchar2 ) return varchar2
  is
  Begin

       if (ps_islem_sekli='CASH') and ( ps_doviz_kodu<>pkg_genel.LC_al ) Then
             return 'E';
       else
             return 'H';
       end if;

      Exception
        when others then return 'H';
  End;

PROCEDURE Info_Sending (ps_reference IN VARCHAR2,                     
                        pn_tx_no in number
                       ) IS
    ln_temp number:= 0;
    lc_kasa_kod  cbs_islem.kasa_kod%TYPE;
    ld_bank_date DATE;
      
    ls_musteri_no CBS_HESAP.MUSTERI_NO%TYPE :=0;
    ls_alici_adres  CBS_YPHAVALE_GELEN_BASVURU.ALICI_ADRES%TYPE;
    ls_adres_semt  CBS_YPHAVALE_GELEN_BASVURU.ADRES_SEMT%TYPE:=' ';
    ls_adres_il_kod CBS_YPHAVALE_GELEN_BASVURU.ADRES_IL_KOD%TYPE:=' ';   
    ls_adres_posta_kod  CBS_YPHAVALE_GELEN_BASVURU.ADRES_POSTA_KOD%TYPE:=0;
    ls_adres_ulke_kod  CBS_YPHAVALE_GELEN_BASVURU.ADRES_ULKE_KOD%TYPE:=' ';
    ln_count_rec NUMBER;
    ls_ref_no CBS_YPHAVALE_GELEN_BASVURU.REF_NO%TYPE;
    ls_odeme_no CBS_YPHAVALE_GELEN_BASVURU.ODEME_NO%TYPE;  
     
    CURSOR c1_swift IS
        SELECT  CBS_HESAP.MUSTERI_NO                                 
             FROM  CBS_HESAP , CBS_MUSTERI,   cbs_swift_messages         
          WHERE  cbs_swift_messages.TO_EXTERNAL_ACCOUNT = CBS_HESAP.EXTERNAL_HESAP_NO 
               AND  CBS_HESAP.DOVIZ_KODU=cbs_swift_messages.currency    
               AND CBS_MUSTERI.MUSTERI_NO=CBS_HESAP.MUSTERI_NO             
               AND  cbs_swift_messages.reference =ps_reference;

     r_c1_swift c1_swift%ROWTYPE;
     
BEGIN
 OPEN c1_swift;




       FETCH c1_swift INTO r_c1_swift;
       
    LS_MUSTERI_NO := r_c1_swift.MUSTERI_NO;
       
    log_at('info_sending',0, LS_MUSTERI_NO);     
       
    ld_bank_date:=pkg_muhasebe.BANKA_TARIHI_BUL;
    


               
IF ls_musteri_no <>0 THEN

pkg_musteri.Sp_Musteri_Adres(ls_musteri_no,
                             ls_alici_adres,
                             ls_adres_semt,
                             ls_adres_il_kod,
                             ls_adres_posta_kod,
                             ls_adres_ulke_kod);
END IF;


log_at('info_sending',1,'ps_reference'||' '||ps_reference||'  '||'pn_tx_no'||' '||pn_tx_no);

  /*  select count(*) into ln_temp
      from cbs_swift_messages cm
     where cm.reference = ps_reference      
       and     exists (select 1 from cbs_islem i, cbs_yphavale_gelen_basvuru c
                        where c.gbanka_referans = cm.reference                        
                          and i.numara = c.tx_no
                          and i.durum in ('C', 'V', 'A', '1'));
     if nvl(ln_temp,0) = 0 then
        ln_temp := 0;
        select count(*) into ln_temp
          from cbs_swift_messages cm
         where cm.reference = ps_reference          
           and not exists (select 1 from cbs_islem i, cbs_yphavale_gelen_basvuru c
                            where c.gbanka_referans = cm.reference                           
                              and i.numara = c.tx_no
                              and i.durum in ('P', '3'));
          if nvl(ln_temp,0) = 0 then
            --give error, this payment has already been done
               Raise_application_error(-20100,pkg_hata.getucpointer || '4950' || pkg_hata.getucpointer);
         end if;
       else
         --not finished tx... give error this eft cannot be processed
               Raise_application_error(-20100,pkg_hata.getucpointer || '4951' || pkg_hata.getucpointer);
       end if;*/
log_at('info_sending',2);


ls_ref_no:=TO_CHAR(ld_bank_date,'YY') ||'.001.IMT.'|| LPAD(TO_CHAR(pkg_genel.genel_kod_al('YPGELEN001' || TO_CHAR(ld_bank_date,'YY'))),5,'0');
ls_odeme_no:=pkg_genel.genel_kod_al(ls_ref_no || 'ODE');



INSERT INTO CBS_YPHAVALE_GELEN_BASVURU
             ( /*1*/tx_no,                       --NOT NULL,
               /*2*/odeme_sekli,    --Payment Type
              -- /*3*/urun_sinif_kod,
               /*4*/doviz_kodu,-- NOT NULL
               /*5*/tutar,-- NOT NULL
               /*6*/gbanka_bic_kodu,--Senders bank bic
               --/*7*/gbanka_bic_adi,--Senders bank name
               /*8*/gbanka_referans, --reference  NOT NULL,
               /*9*/gonderen_adi, --NOT NULL,
               /*10*/gonderen_adres,
               
               /*11*/gonderen_adres_2,
               /*12*/gonderen_ulke_kodu,--Senders Country Code
              -- /*13*/gonderen_ulke_adi,--Senders Country Name
                   /*13.1*/ alici_musteri_no, --Customer No разобраться
               /*14*/external_number,
               /*15*/alici_hesap_no,--Account NO
               /*16*/alici_adi,--NOT NULL,
               /*16.1*/       alici_adres, 
               /*16.2*/       adres_semt, 
               /*1.6.3*/       adres_il_kod,
                /*16.4*/      adres_posta_kod,
                 /*16.5*/     adres_ulke_kod,
               --/*17.*/valor_tarihi,,разобраться
               --ALICI_DK_NO разобраться
               --KUR разобраться
               --EZERVASYON_NO
               /*18*/mbanka_musteri_no,--Correspond. Bank Cust.No NOT NULL,
               --/*19*/muhabir_musteri_adi,
               /*20*/mbanka_hesap_no,  -- Correspond. Bank Acc. No   NOT NULL,
               --/*21*/ulke_kodu,  разобраться   --Country code
           
             --ihracat_referans, разобраться
               /*22*/ihbar, --Advice letter, --NOT NULL,
               /*23*/aciklama, --NOT NULL,
              --BOLUM_KODU разобраться
               /*24*/istatistik_kodu,
               ---ODEME_NO разобраться
               --NET_ODENEN_TUTAR
              -- ODEME_TUTARI разобраться
             --istatistik_aciklama
             --ISTATISTIK_DOVIZ_KODUразобраться
             modul_tur_kod,
             urun_tur_kod,--NOT NULL,
             urun_sinif_kod,-- NOT NULL,
             ulke_kodu,--NOT NULL,
            -- alici_adres,--NOT NULL
             valor_tarihi,--NOT NULL
             ref_no,
             odeme_no,
             odeme_tutari,
             net_odenen_tutar
             
             )
  SELECT /*1*/pn_tx_no,--NOT NULL,
         /*2*/ 2,
         --/*3*/'OTHER',
         /*4*/currency,-- NOT NULL
         /*5*/amount,-- NOT NULL
         /*6*/SUBSTR(senders_bank_bic,1,11),  
         --/*7*/pkg_yphavale.BICUlkeAdiBul(senders_bank_bic),
         /*8*/SUBSTR(reference,1,16),-- NOT NULL,
         /*9*/NVL(SUBSTR(senders_name,1,50),'NOT FOUND'),--NOT NULL,
         /*10*/SUBSTR(senders_address,1,70),
         
         /*11*/SUBSTR(senders_address_2,1,70),
         /*12*/SUBSTR(senders_country_code,1,5),
         --/*13*/pkg_genel.ulke_adi_al(senders_country_code),--Senders Country Name
         /*13.1*/ ls_musteri_no, --Customer No разобраться
         /*14*/SUBSTR(to_external_account,1,32),
         /*15*/to_account,  
        /*16*/ NVL(SUBSTR(to_name,1,140),'NOT FOUND'),
        /*16.1*/ NVL(ls_alici_adres,'NOT FOUND'),
        /*16.2*/  ls_adres_semt,
        /*16.3*/  ls_adres_il_kod,
        /*16.4*/  ls_adres_posta_kod,
        /*16.5*/  ls_adres_ulke_kod,
           
         --'TEST',--/*16*/to_name,--NOT NULL,
         --/*17*/TO_DATE(value_date, 'dd/mm/yyyy'),
          /*18*/nvl(corr_bank_cust_no,000) , --/*18*/corr_bank_cust_no, NOT NULL,
         --/*19*/pkg_musteri.Sf_Musteri_Adi(corr_bank_cust_no),
          nvl(corr_bank_account,000),--/*20*/corr_bank_account,                 NOT NULL,
       
         --/*21*/pkg_musteri.Sf_UyrukKod_Al(corr_bank_cust_no),--Country code
         /*22*/'E',--ihbar --Advice letter         --NOT NULL,
         /*23*/NVL(substr(explanation,1,80),'NOT FOUND') , --NOT NULL,
         /*24*/statistical_code,        
         'FCTRANSFER',
         'INCOMING',--NOT NULL,
         'OTHER',--NOT NULL,
          CASE WHEN corr_bank_cust_no IS NOT NULL THEN
          
          pkg_musteri.Sf_UyrukKod_Al(corr_bank_cust_no)
          
          ELSE
          
         'NULL'
          
          END,
         --'TEST',--NOT NULL,
          pkg_muhasebe.banka_tarihi_bul,    --NOT NULL,          
          ls_ref_no,
          ls_odeme_no ,
          amount,
          amount       
          FROM cbs_swift_messages
                          WHERE reference = ps_reference;
log_at('info_sending',3);
  CLOSE c1_swift;     
            COMMIT; 
                         
    EXCEPTION
        WHEN OTHERS THEN
        log_at('info_sending',4);
            RAISE_APPLICATION_ERROR(-20100,SQLERRM||'#'|| dbms_utility.format_error_backtrace);

 END;                       
  
   
 PROCEDURE Transaction_Sending (ps_reference IN VARCHAR2, 
                        pn_tx_no in number
                       ) IS
ln_temp number:= 0;
    lc_kasa_kod  cbs_islem.kasa_kod%TYPE;
    ld_bank_date DATE;
      
    ls_musteri_no CBS_HESAP.MUSTERI_NO%TYPE;
    ls_alici_adres  CBS_YPHAVALE_GELEN_BASVURU.ALICI_ADRES%TYPE;
    ls_adres_semt  CBS_YPHAVALE_GELEN_BASVURU.ADRES_SEMT%TYPE;
    ls_adres_il_kod CBS_YPHAVALE_GELEN_BASVURU.ADRES_IL_KOD%TYPE;   
    ls_adres_posta_kod  CBS_YPHAVALE_GELEN_BASVURU.ADRES_POSTA_KOD%TYPE;
    ls_adres_ulke_kod  CBS_YPHAVALE_GELEN_BASVURU.ADRES_ULKE_KOD%TYPE;
    ln_count_rec NUMBER;     
    ls_ref_no CBS_YPHAVALE_GELEN_BASVURU.REF_NO%TYPE;
    ls_odeme_no CBS_YPHAVALE_GELEN_BASVURU.ODEME_NO%TYPE;  
    
CURSOR islem_cursor IS
       SELECT tutar, doviz_kodu, alici_musteri_no, alici_hesap_no                  
                 FROM CBS_YPHAVALE_GELEN_BASVURU
               WHERE TX_NO=pn_tx_no;
             
               r1  islem_cursor%ROWTYPE;    
    
     
BEGIN

    ld_bank_date:=pkg_muhasebe.BANKA_TARIHI_BUL;
    

SELECT  --CBS_HESAP.HESAP_NO ,
         --CBS_HESAP.EXTERNAL_HESAP_NO ,
         CBS_HESAP.MUSTERI_NO 
        -- cbs_swift_messages.reference,
         --cbs_swift_messages.currency               
             INTO /*LS_ALICI_HESAP_NO , LS_EXTERNAL_HESAP_NO */LS_MUSTERI_NO /*,LS_LOKAL_UNVAN */
             FROM  CBS_HESAP , CBS_MUSTERI,   cbs_swift_messages         
          WHERE  cbs_swift_messages.TO_EXTERNAL_ACCOUNT = CBS_HESAP.EXTERNAL_HESAP_NO 
               AND  CBS_HESAP.DOVIZ_KODU=cbs_swift_messages.currency    
               AND CBS_MUSTERI.MUSTERI_NO=CBS_HESAP.MUSTERI_NO             
               AND  cbs_swift_messages.reference =ps_reference;

pkg_musteri.Sp_Musteri_Adres(ls_musteri_no,
                             ls_alici_adres,
                             ls_adres_semt,
                             ls_adres_il_kod,
                             ls_adres_posta_kod,
                             ls_adres_ulke_kod);

log_at('info_sending',1,'ps_reference'||' '||ps_reference||'  '||'pn_tx_no'||' '||pn_tx_no);

   /* select count(*) into ln_temp
      from cbs_swift_messages cm
     where cm.reference = ps_reference      
       and     exists (select 1 from cbs_islem i, cbs_yphavale_gelen_basvuru c
                        where c.gbanka_referans = cm.reference                        
                          and i.numara = c.tx_no
                          and i.durum in ('C', 'V', 'A', '1'));
     if nvl(ln_temp,0) = 0 then
        ln_temp := 0;
        select count(*) into ln_temp
          from cbs_swift_messages cm
         where cm.reference = ps_reference          
           and not exists (select 1 from cbs_islem i, cbs_yphavale_gelen_basvuru c
                            where c.gbanka_referans = cm.reference                           
                              and i.numara = c.tx_no
                              and i.durum in ('P', '3'));
          if nvl(ln_temp,0) = 0 then
            --give error, this payment has already been done
               Raise_application_error(-23470,pkg_hata.getucpointer || '4950' || pkg_hata.getucpointer);
         end if;
       else
         --not finished tx... give error this eft cannot be processed
               Raise_application_error(-23470,pkg_hata.getucpointer || '4951' || pkg_hata.getucpointer);
       end if;*/
log_at('info_sending',2);
ls_ref_no:=TO_CHAR(ld_bank_date,'YY') ||'.001.IMT.'|| LPAD(TO_CHAR(pkg_genel.genel_kod_al('YPGELEN001' || TO_CHAR(ld_bank_date,'YY'))),5,'0');
ls_odeme_no:=pkg_genel.genel_kod_al(ls_ref_no || 'ODE');

INSERT INTO CBS_YPHAVALE_GELEN_BASVURU
             ( /*1*/tx_no,                       --NOT NULL,
               /*2*/odeme_sekli,    --Payment Type
              -- /*3*/urun_sinif_kod,
               /*4*/doviz_kodu,-- NOT NULL
               /*5*/tutar,-- NOT NULL
               /*6*/gbanka_bic_kodu,--Senders bank bic
               --/*7*/gbanka_bic_adi,--Senders bank name
               /*8*/gbanka_referans, --reference  NOT NULL,
               /*9*/gonderen_adi, --NOT NULL,
               /*10*/gonderen_adres,
               
               /*11*/gonderen_adres_2,
               /*12*/gonderen_ulke_kodu,--Senders Country Code
              -- /*13*/gonderen_ulke_adi,--Senders Country Name
                   /*13.1*/ alici_musteri_no, --Customer No разобраться
               /*14*/external_number,
               /*15*/alici_hesap_no,--Account NO
               /*16*/alici_adi,--NOT NULL,
               /*16.1*/       alici_adres, 
               /*16.2*/       adres_semt, 
               /*1.6.3*/       adres_il_kod,
                /*16.4*/      adres_posta_kod,
                 /*16.5*/     adres_ulke_kod,
               --/*17.*/valor_tarihi,,разобраться
               --ALICI_DK_NO разобраться
               --KUR разобраться
               --EZERVASYON_NO
               /*18*/mbanka_musteri_no,--Correspond. Bank Cust.No NOT NULL,
               --/*19*/muhabir_musteri_adi,
               /*20*/mbanka_hesap_no,  -- Correspond. Bank Acc. No   NOT NULL,
               --/*21*/ulke_kodu,  разобраться   --Country code
           
             --ihracat_referans, разобраться
               /*22*/ihbar, --Advice letter, --NOT NULL,
               /*23*/aciklama, --NOT NULL,
              --BOLUM_KODU разобраться
               /*24*/istatistik_kodu,
               ---ODEME_NO разобраться
               --NET_ODENEN_TUTAR
              -- ODEME_TUTARI разобраться
             --istatistik_aciklama
             --ISTATISTIK_DOVIZ_KODUразобраться
             modul_tur_kod,
             urun_tur_kod,--NOT NULL,
             urun_sinif_kod,-- NOT NULL,
             ulke_kodu,--NOT NULL,
            -- alici_adres,--NOT NULL
             valor_tarihi,--NOT NULL
             ref_no,
             odeme_no,
             odeme_tutari,
             net_odenen_tutar
             
             )
  SELECT /*1*/pn_tx_no,--NOT NULL,
         /*2*/ 2,
         --/*3*/'OTHER',
         /*4*/currency,-- NOT NULL
         /*5*/amount,-- NOT NULL
         /*6*/SUBSTR(senders_bank_bic,1,11),  
         --/*7*/pkg_yphavale.BICUlkeAdiBul(senders_bank_bic),
         /*8*/SUBSTR(reference,1,16),-- NOT NULL,
         /*9*/SUBSTR(senders_name,1,50),--NOT NULL,
         /*10*/SUBSTR(senders_address,1,70),
         
         /*11*/SUBSTR(senders_address_2,1,70),
         /*12*/SUBSTR(senders_country_code,1,5),
         --/*13*/pkg_genel.ulke_adi_al(senders_country_code),--Senders Country Name
         /*13.1*/ ls_musteri_no, --Customer No разобраться
         /*14*/SUBSTR(to_external_account,1,32),
         /*15*/to_account,  
        /*16*/ NVL(SUBSTR(to_name,1,140),'NOT FOUND'),
        /*16.1*/    NVL(ls_alici_adres,'NOT FOUND'),
        /*16.2*/   ls_adres_semt,
        /*16.3*/  ls_adres_il_kod,
        /*16.4*/  ls_adres_posta_kod,
        /*16.5*/  ls_adres_ulke_kod,
           
         --'TEST',--/*16*/to_name,--NOT NULL,
         --/*17*/TO_DATE(value_date, 'dd/mm/yyyy'),
          /*18*/nvl(corr_bank_cust_no,000) , --/*18*/corr_bank_cust_no, NOT NULL,
         --/*19*/pkg_musteri.Sf_Musteri_Adi(corr_bank_cust_no),
          nvl(corr_bank_account,000),--/*20*/corr_bank_account,                 NOT NULL,
       
         --/*21*/pkg_musteri.Sf_UyrukKod_Al(corr_bank_cust_no),--Country code
         /*22*/'E',--ihbar --Advice letter         --NOT NULL,
         /*23*/substr(explanation,1,80) , --NOT NULL,
         /*24*/statistical_code,        
         'FCTRANSFER',
         'INCOMING',--NOT NULL,
         'OTHER',--NOT NULL,
          pkg_musteri.Sf_UyrukKod_Al(nvl(corr_bank_cust_no,000)),
         --'TEST',--NOT NULL,
          pkg_muhasebe.banka_tarihi_bul,    --NOT NULL, 
         ls_ref_no,-- TO_CHAR(ld_bank_date,'YY') ||'.001.IMT.'|| LPAD(TO_CHAR(pkg_genel.genel_kod_al('YPGELEN001' || TO_CHAR(ld_bank_date,'YY'))),5,'0'),
         -- pkg_genel.genel_kod_al(TO_CHAR(ld_bank_date,'YY') ||'.001.IMT.'|| LPAD(TO_CHAR(pkg_genel.genel_kod_al('YPGELEN001' || TO_CHAR(ld_bank_date,'YY'))),5,'0') || 'ODE')
          ls_odeme_no ,
          amount,
          amount
          
          FROM cbs_swift_messages
                          WHERE reference = ps_reference;
log_at('info_sending',3);
      
            COMMIT; 
   




    



/*
ln_islem_no 13974756/
ln_islem_kod 2347/
lc_modul_tur_kod FCTRANSFER/
lc_urun_tur_kod INCOMING/
lc_urun_sinif_kod OTHER/

ln_tutar 17,24/
lc_bolum_kodu 010/
lc_doviz_kod USD/
ln_musteri_numara 47730/
lc_hesap_numara 216477/
lc_kasa_kod 
*/

         
        
         BEGIN
      log_at('info_sending',4,ps_reference); 
                     UPDATE cbs_swift_messages SET status  = 'sProcess' WHERE reference = ps_reference;
               COMMIT; 
               
                Open islem_cursor;
              FETCH islem_cursor INTO r1;
--log_at('incomings',10);
--               Pkg_Tx.islem_yarat (Pn_tx_no, 2347, 'FCTRANSFER', 'INCOMING', 'OTHER',
--                   1000, '001', 'KGS', NULL, NULL, NULL);




              Pkg_Tx.islem_yarat(pn_tx_no, 2347, 'FCTRANSFER', 'INCOMING', 'OTHER',
                                   r1.tutar, '001', r1.doviz_kodu, r1.alici_musteri_no, r1.alici_hesap_no, NULL);
                                   
           CLOSE islem_cursor;                                
                                   
               --Pkg_Int_Api.process_transaction (pn_tx_no);
           IF    pkg_tx.Dogrula_Kontrol(pn_tx_no) THEN
               NULL;
           ELSIF pkg_tx.Onay_Kontrol(pn_tx_no) THEN
               NULL;
           ELSE
                 pkg_tx.Muhasebelestir(pn_tx_no);
           END IF;
               

     log_at('1611',5,'pn_tx_no'||'  '||pn_tx_no||'/'||'r1.doviz_kodu'||' '||r1.doviz_kodu||'/ '||
                     'r1.alici_musteri_no'||' '||r1.alici_musteri_no||'/'||'r1.alici_hesap_no'||' '||r1.alici_hesap_no||'/'||'r1.tutar'||' '||r1.tutar); 
        END;         
       
                         
    EXCEPTION
        WHEN OTHERS THEN
        log_at('info_sending',4);
            RAISE_APPLICATION_ERROR(-20100, SQLERRM);

 END;                       
 
 
 
 
 

 
 
 
 
 
 
 
 
   
  BEGIN       

    p_2347_B_ACIKLAMA:=pkg_muhasebe.parametre_index_bul('2347_B_ACIKLAMA');
    p_2347_DOVIZ_KODU:=pkg_muhasebe.parametre_index_bul('2347_DOVIZ_KODU');
    p_2347_FC_TUTAR:=pkg_muhasebe.parametre_index_bul('2347_FC_TUTAR');
    p_2347_HESAP_SUBE:=pkg_muhasebe.parametre_index_bul('2347_HESAP_SUBE');
    p_2347_ISLEM_SUBE:=pkg_muhasebe.parametre_index_bul('2347_ISLEM_SUBE');
    p_2347_HESAP_SUBE_1:=pkg_muhasebe.parametre_index_bul('2347_HESAP_SUBE_1');--CQ5638 KonstantinJ 27062017
    p_2347_ISLEM_SUBE_1:=pkg_muhasebe.parametre_index_bul('2347_ISLEM_SUBE_1');--CQ5638 KonstantinJ 27062017
    p_2347_ISTATISTIK_KODU:=pkg_muhasebe.parametre_index_bul('2347_ISTATISTIK_KODU');
    p_2347_LC_KUR:=pkg_muhasebe.parametre_index_bul('2347_LC_KUR');
    p_2347_LC_TUTAR:=pkg_muhasebe.parametre_index_bul('2347_LC_TUTAR');
    p_2347_MBANKA_HESAPNO:=pkg_muhasebe.parametre_index_bul('2347_MBANKA_HESAPNO');
    p_2347_M_ACIKLAMA:=pkg_muhasebe.parametre_index_bul('2347_M_ACIKLAMA');
    p_2347_REFERANS:=pkg_muhasebe.parametre_index_bul('2347_REFERANS');
    p_2347_VALOR_TARIHI:=pkg_muhasebe.parametre_index_bul('2347_VALOR_TARIHI');
     --BOM CQ5627  Incoming Automation  KonstantinJ 04012017
 
    p_2347_ALICI_DKNO    :=pkg_muhasebe.parametre_index_bul('2347_ALICI_DKNO');
    p_2347_ALICI_HESAPNO     :=pkg_muhasebe.parametre_index_bul('2347_ALICI_HESAPNO');
 
    p_2347_FC_KOMISYON        :=pkg_muhasebe.parametre_index_bul('2347_FC_KOMISYON');
    p_2347_FC_NETODENEN          :=pkg_muhasebe.parametre_index_bul('2347_FC_NETODENEN');
    p_2347_LC_KOMISYON           :=pkg_muhasebe.parametre_index_bul('2347_LC_KOMISYON');
    p_2347_LC_KUR_EKRAN            :=pkg_muhasebe.parametre_index_bul('2347_LC_KUR_EKRAN');
    p_2347_LC_NETODENEN            :=pkg_muhasebe.parametre_index_bul('2347_LC_NETODENEN');
 
    p_2347_LC_BSMV               :=pkg_muhasebe.parametre_index_bul('2347_LC_BSMV');
    p_2347_FC_BSMV             :=pkg_muhasebe.parametre_index_bul('2347_FC_BSMV');
    p_2347_LC_MASRAF_TOPLAMI   :=pkg_muhasebe.parametre_index_bul('2347_LC_MASRAF_TOPLAMI');
    p_2347_FC_MASRAF_TOPLAMI   :=pkg_muhasebe.parametre_index_bul('2347_FC_MASRAF_TOPLAMI');
    p_2347_LC_MAL_NETODENEN            :=pkg_muhasebe.parametre_index_bul('2347_LC_MAL_NETODENEN');
    p_2347_FC_MAL_NETODENEN             :=pkg_muhasebe.parametre_index_bul('2347_FC_MAL_NETODENEN');
    p_2347_LC_MUS_NETODENEN           :=pkg_muhasebe.parametre_index_bul('2347_LC_MUS_NETODENEN');
    p_2347_FC_MUS_NETODENEN         :=pkg_muhasebe.parametre_index_bul('2347_FC_MUS_NETODENEN');
    p_2347_ISTATISTIK_KODU_1          :=pkg_muhasebe.parametre_index_bul('2347_ISTATISTIK_KODU_1');
    p_2347_ISTATISTIK_KODU_2          :=pkg_muhasebe.parametre_index_bul('2347_ISTATISTIK_KODU_2');
    p_2347_KOMREF                            :=pkg_muhasebe.parametre_index_bul('2347_KOMREF');
END;
/

