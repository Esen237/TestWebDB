create PACKAGE     PKG_TX3000 IS

 /******************************************************************************
   Name       : PKG_TX3000
   Created By : Zhukov Konstantin   
   Date          : 26.02.2015
   Purpose      : TRANFERRING SIGNATURE BASE TO CBS
******************************************************************************/
TYPE GenCurType IS REF CURSOR;

 Function Get_signature_doc_type_name( pDoc_id  Number) return varchar2;-- Get document type

  Function Get_last_modified_user( lp_Cusotmer_no  Number) return varchar2;
 Function  Get_last_modified_date (lp_Cusotmer_no  Number) return date;
  Function Get_Joint_Account (lp_Cusotmer_no  Number) return Number;

Procedure get_customer_attachments(ln_tx_no number,ln_Customer_no number); -- Get all attachments of the customer

  Procedure Kontrol_Sonrasi(pn_islem_no number);     -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);        -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);        -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);    -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);        -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);      -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);        -- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
  
END;

/

