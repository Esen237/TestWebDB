create PACKAGE BODY pkg_guvenlik IS
  function izleme_guvenlik_kosulu return varchar2 is
  begin
  	return '';
  end;
  Procedure Yetki_Yukle is

    cursor c1 is
	  select *
	    from cbs_rol_urun_islem_arabirim;

	r_c1 	 c1%rowtype;

	cursor c3 is
	  select * from cbs_islem_urun
	    where islem_kod=r_c1.islem_tanim_kod;

	r_c3 	 c3%rowtype;

	cursor c4 is
	  select * from cbs_islem_urun
	    where modul_tur_kod=r_c1.modul_tur_kod
		  and urun_tur_kod=r_c1.urun_tur_kod
		  and islem_kod=r_c1.islem_tanim_kod;

	r_c4 	 c4%rowtype;


    cursor c5 is
	  select *
	    from cbs_rol_urun_islem_dogru_ara;

	r_c5 	 c5%rowtype;

	cursor c7 is
	  select * from cbs_islem_urun
	    where islem_kod=r_c5.islem_tanim_kod;

	r_c7 	 c7%rowtype;

	cursor c8 is
	  select * from cbs_islem_urun
	    where modul_tur_kod=r_c5.modul_tur_kod
		  and urun_tur_kod=r_c5.urun_tur_kod
		  and islem_kod=r_c5.islem_tanim_kod;

	r_c8 	 c8%rowtype;

    cursor c15 is
	  select *
	    from cbs_rol_urun_islem_onay_ara;

	r_c15 	 c15%rowtype;


	cursor c17 is
	  select * from cbs_islem_urun
	    where islem_kod=r_c15.islem_tanim_kod;

	r_c17 	 c17%rowtype;

	cursor c18 is
	  select * from cbs_islem_urun
	    where modul_tur_kod=r_c15.modul_tur_kod
		  and urun_tur_kod=r_c15.urun_tur_kod
		  and islem_kod=r_c15.islem_tanim_kod;

	r_c18 	 c18%rowtype;

	-- ?ptal

    cursor c20 is
	  select *
	    from cbs_rol_urun_islem_iptal_ara;

	r_c20 	 c20%rowtype;

	cursor c21 is
	  select * from cbs_islem_urun
	    where islem_kod=r_c20.islem_tanim_kod;

	r_c21 	 c21%rowtype;

	cursor c22 is
	  select * from cbs_islem_urun
	    where modul_tur_kod=r_c20.modul_tur_kod
		  and urun_tur_kod=r_c20.urun_tur_kod
		  and islem_kod=r_c20.islem_tanim_kod;

	r_c22 	 c22%rowtype;

	ls_sqlerrm			 varchar2(2000);
  Begin

    -- Yaratma yetkilerini y?kle
    open c1;
	loop
	  fetch c1 into r_c1;
	  exit when c1%notfound;
	    if r_c1.urun_tur_kod is null then
		    -- t?m ?r?n_siniflar i?in yarat
		      open c3;
		      loop
		        fetch c3 into r_c3;
			    exit when c3%notfound;
  				  dbms_output.put_line(r_c1.ROL_NUMARA||r_c1.ISLEM_TANIM_KOD||r_c3.MODUL_TUR_KOD||r_c3.URUN_TUR_KOD||r_c3.URUN_SINIF_KOD
											   ||r_c1.ZAMAN_NUMARA||r_c1.LIMIT_NUMARA);

				begin
			     insert into cbs_rol_urun_islem (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,DOGRULAMA,ONAY,
											   DOGRULA_GUNCELLE,ONAYLA_GUNCELLE,IPTAL_ONAY,AUTO_YARATILDI) values
											  (r_c1.ROL_NUMARA,r_c1.ISLEM_TANIM_KOD,r_c3.MODUL_TUR_KOD,r_c3.URUN_TUR_KOD,r_c3.URUN_SINIF_KOD,
											   r_c1.ZAMAN_NUMARA,r_c1.LIMIT_NUMARA,r_c1.DOGRULAMA_FLAG,r_c1.ONAY_FLAG,
											   r_c1.DOGRULAMA_GUNCEL_FLAG,r_c1.ONAY_GUNCEL_FLAG,'H','E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem 1 : '||substr(ls_sqlerrm,1900),sysdate,user,
					r_c1.ROL_NUMARA||r_c1.ISLEM_TANIM_KOD||r_c3.MODUL_TUR_KOD||r_c3.URUN_TUR_KOD||r_c3.URUN_SINIF_KOD||r_c1.ZAMAN_NUMARA||r_c1.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c3;
		else
		  if r_c1.urun_sinif_kod is null then
		     -- t?m ?r?n siniflar i?in
		      open c4;
		      loop
		        fetch c4 into r_c4;
			    exit when c4%notfound;
				begin
			     insert into cbs_rol_urun_islem (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,DOGRULAMA,ONAY,
											   DOGRULA_GUNCELLE,ONAYLA_GUNCELLE,IPTAL_ONAY,AUTO_YARATILDI) values
											  (r_c1.ROL_NUMARA,r_c1.ISLEM_TANIM_KOD,r_c4.MODUL_TUR_KOD,r_c4.URUN_TUR_KOD,r_c4.URUN_SINIF_KOD,
											   r_c1.ZAMAN_NUMARA,r_c1.LIMIT_NUMARA,r_c1.DOGRULAMA_FLAG,r_c1.ONAY_FLAG,
											   r_c1.DOGRULAMA_GUNCEL_FLAG,r_c1.ONAY_GUNCEL_FLAG,'H','E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem 2 : '||substr(ls_sqlerrm,1900),sysdate,user,
					r_c1.ROL_NUMARA||r_c1.ISLEM_TANIM_KOD||r_c4.MODUL_TUR_KOD||r_c4.URUN_TUR_KOD||r_c4.URUN_SINIF_KOD||r_c1.ZAMAN_NUMARA||r_c1.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c4;
		  else
		    -- ?r?n sinif kod dolu
			    begin
			     insert into cbs_rol_urun_islem (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,DOGRULAMA,ONAY,
											   DOGRULA_GUNCELLE,ONAYLA_GUNCELLE,IPTAL_ONAY,AUTO_YARATILDI) values
											  (r_c1.ROL_NUMARA,r_c1.ISLEM_TANIM_KOD,r_c1.MODUL_TUR_KOD,r_c1.URUN_TUR_KOD,r_c1.URUN_SINIF_KOD,
											   r_c1.ZAMAN_NUMARA,r_c1.LIMIT_NUMARA,r_c1.DOGRULAMA_FLAG,r_c1.ONAY_FLAG,
											   r_c1.DOGRULAMA_GUNCEL_FLAG,r_c1.ONAY_GUNCEL_FLAG,'H','E');

				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem 3 : '||substr(ls_sqlerrm,1900),sysdate,user,
					r_c1.ROL_NUMARA||r_c1.ISLEM_TANIM_KOD||r_c1.MODUL_TUR_KOD||r_c1.URUN_TUR_KOD||r_c1.URUN_SINIF_KOD||r_c1.ZAMAN_NUMARA||r_c1.LIMIT_NUMARA );
				end ;
		  end if;
		end if;
	end loop;
	close c1;

	-- Do?rulama yetkilerini y?kle
    open c5;
	loop
	  fetch c5 into r_c5;
	  exit when c5%notfound;
	    if r_c5.urun_tur_kod is null then
		  -- t?m ?r?n_t?r'ler i?in yarat
		      open c7;
		      loop
		        fetch c7 into r_c7;
			    exit when c7%notfound;
				begin
			     insert into cbs_rol_urun_islem_dogru (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c5.ROL_NUMARA,r_c5.ISLEM_TANIM_KOD,r_c7.MODUL_TUR_KOD,r_c7.URUN_TUR_KOD,r_c7.URUN_SINIF_KOD,
											   r_c5.ZAMAN_NUMARA,r_c5.LIMIT_NUMARA,
											   r_c5.AYNI_KULLANICI_FLAG,r_c5.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_dogru 1 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c1.ROL_NUMARA||r_c5.ISLEM_TANIM_KOD||r_c7.MODUL_TUR_KOD||r_c7.URUN_TUR_KOD||r_c7.URUN_SINIF_KOD||r_c5.ZAMAN_NUMARA||r_c5.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c7;
		else
		  if r_c5.urun_sinif_kod is null then
		     -- t?m ?r?n siniflar i?in
		      open c8;
		      loop
		        fetch c8 into r_c8;
			    exit when c8%notfound;
				begin
			     insert into cbs_rol_urun_islem_dogru (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c5.ROL_NUMARA,r_c5.ISLEM_TANIM_KOD,r_c8.MODUL_TUR_KOD,r_c8.URUN_TUR_KOD,r_c8.URUN_SINIF_KOD,
											   r_c5.ZAMAN_NUMARA,r_c5.LIMIT_NUMARA,
											   r_c5.AYNI_KULLANICI_FLAG,r_c5.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_dogru 2 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c1.ROL_NUMARA||r_c5.ISLEM_TANIM_KOD||r_c8.MODUL_TUR_KOD||r_c8.URUN_TUR_KOD||r_c8.URUN_SINIF_KOD||r_c5.ZAMAN_NUMARA||r_c5.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c8;
		  else
		    -- ?r?n sinif kod dolu
			  begin
			     insert into cbs_rol_urun_islem_dogru (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c5.ROL_NUMARA,r_c5.ISLEM_TANIM_KOD,r_c5.MODUL_TUR_KOD,r_c5.URUN_TUR_KOD,r_c5.URUN_SINIF_KOD,
											   r_c5.ZAMAN_NUMARA,r_c5.LIMIT_NUMARA,
											   r_c5.AYNI_KULLANICI_FLAG,r_c5.AYNI_BOLUM_FLAG,'E');

				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_dogru 3 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c5.ROL_NUMARA||r_c5.ISLEM_TANIM_KOD||r_c5.MODUL_TUR_KOD||r_c5.URUN_TUR_KOD||r_c5.URUN_SINIF_KOD||r_c5.ZAMAN_NUMARA||r_c5.LIMIT_NUMARA );
				end ;
		  end if;
		end if;
	end loop;
	close c5;

	-- Onaylama yetkilerini y?kle

    open c15;
	loop
	  fetch c15 into r_c15;
	  exit when c15%notfound;
	    if r_c15.urun_tur_kod is null then
		  -- t?m ?r?n_t?r'ler i?in yarat
		      open c17;
		      loop
		        fetch c17 into r_c17;
			    exit when c17%notfound;
				begin
			     insert into cbs_rol_urun_islem_onay (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c15.ROL_NUMARA,r_c15.ISLEM_TANIM_KOD,r_c17.MODUL_TUR_KOD,r_c17.URUN_TUR_KOD,r_c17.URUN_SINIF_KOD,
											   r_c15.ZAMAN_NUMARA,r_c15.LIMIT_NUMARA,
											   r_c15.AYNI_KULLANICI_FLAG,r_c15.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_onay 1 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c15.ROL_NUMARA||r_c15.ISLEM_TANIM_KOD||r_c17.MODUL_TUR_KOD||r_c17.URUN_TUR_KOD||r_c17.URUN_SINIF_KOD||r_c15.ZAMAN_NUMARA||r_c15.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c17;
		else
		  if r_c15.urun_sinif_kod is null then
		     -- t?m ?r?n siniflar i?in
		      open c18;
		      loop
		        fetch c18 into r_c18;
			    exit when c18%notfound;
				begin
			     insert into cbs_rol_urun_islem_onay (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c15.ROL_NUMARA,r_c15.ISLEM_TANIM_KOD,r_c18.MODUL_TUR_KOD,r_c18.URUN_TUR_KOD,r_c18.URUN_SINIF_KOD,
											   r_c15.ZAMAN_NUMARA,r_c15.LIMIT_NUMARA,
											   r_c15.AYNI_KULLANICI_FLAG,r_c15.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_onay 2 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c15.ROL_NUMARA||r_c15.ISLEM_TANIM_KOD||r_c18.MODUL_TUR_KOD||r_c18.URUN_TUR_KOD||r_c18.URUN_SINIF_KOD||r_c15.ZAMAN_NUMARA||r_c15.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c18;
		  else
		    -- ?r?n sinif kod dolu
			begin
			     insert into cbs_rol_urun_islem_onay (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c15.ROL_NUMARA,r_c15.ISLEM_TANIM_KOD,r_c15.MODUL_TUR_KOD,r_c15.URUN_TUR_KOD,r_c15.URUN_SINIF_KOD,
											   r_c15.ZAMAN_NUMARA,r_c15.LIMIT_NUMARA,
											   r_c15.AYNI_KULLANICI_FLAG,r_c15.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_onay 3 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c15.ROL_NUMARA||r_c15.ISLEM_TANIM_KOD||r_c15.MODUL_TUR_KOD||r_c15.URUN_TUR_KOD||r_c15.URUN_SINIF_KOD||r_c15.ZAMAN_NUMARA||r_c15.LIMIT_NUMARA );
				end ;
		  end if;
		end if;
	end loop;
	close c15;

	-- ?ptal yetkilerini y?kle

    open c20;

	loop
	  fetch c20 into r_c20;
	  exit when c20%notfound;
	    if r_c20.urun_tur_kod is null then
		  -- t?m ?r?n_t?r'ler i?in yarat
		      open c21;
		      loop
		        fetch c21 into r_c21;
			    exit when c21%notfound;
				begin
			     insert into cbs_rol_urun_islem_iptal (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c20.ROL_NUMARA,r_c20.ISLEM_TANIM_KOD,r_c21.MODUL_TUR_KOD,r_c21.URUN_TUR_KOD,r_c21.URUN_SINIF_KOD,
											   r_c20.ZAMAN_NUMARA,r_c20.LIMIT_NUMARA,
											   r_c20.AYNI_KULLANICI_FLAG,r_c20.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_iptal 1 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c20.ROL_NUMARA||r_c20.ISLEM_TANIM_KOD||r_c21.MODUL_TUR_KOD||r_c21.URUN_TUR_KOD||r_c21.URUN_SINIF_KOD||r_c20.ZAMAN_NUMARA||r_c20.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c21;
		else
		  if r_c20.urun_sinif_kod is null then
		     -- t?m ?r?n siniflar i?in
		      open c22;
		      loop
			    begin
		        fetch c22 into r_c22;
			    exit when c22%notfound;
			     insert into cbs_rol_urun_islem_iptal (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c20.ROL_NUMARA,r_c20.ISLEM_TANIM_KOD,r_c22.MODUL_TUR_KOD,r_c22.URUN_TUR_KOD,r_c22.URUN_SINIF_KOD,
											   r_c20.ZAMAN_NUMARA,r_c20.LIMIT_NUMARA,
											   r_c20.AYNI_KULLANICI_FLAG,r_c20.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_iptal 2 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c20.ROL_NUMARA||r_c20.ISLEM_TANIM_KOD||r_c22.MODUL_TUR_KOD||r_c22.URUN_TUR_KOD||r_c22.URUN_SINIF_KOD||r_c20.ZAMAN_NUMARA||r_c20.LIMIT_NUMARA );
				end ;
		      end loop;
		      close c22;
		  else
		    -- ?r?n sinif kod dolu
			  begin
			     insert into cbs_rol_urun_islem_iptal (ROL_NUMARA,ISLEM_TANIM_KOD,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
			                                   ZAMAN_NUMARA,LIMIT_NUMARA,
											   AYNI_KULLANICI,AYNI_BOLUM,AUTO_YARATILDI) values
											  (r_c20.ROL_NUMARA,r_c20.ISLEM_TANIM_KOD,r_c20.MODUL_TUR_KOD,r_c20.URUN_TUR_KOD,r_c20.URUN_SINIF_KOD,
											   r_c20.ZAMAN_NUMARA,r_c20.LIMIT_NUMARA,
											   r_c20.AYNI_KULLANICI_FLAG,r_c20.AYNI_BOLUM_FLAG,'E');
				exception
				  when others then
				    ls_sqlerrm:=substr(sqlerrm,1,1900);
				    insert into cbs_yetki_hatalari values ('cbs_rol_urun_islem_iptal 3 : '||substr(ls_sqlerrm,1900),sysdate,user ,
					r_c20.ROL_NUMARA||r_c20.ISLEM_TANIM_KOD||r_c20.MODUL_TUR_KOD||r_c20.URUN_TUR_KOD||r_c20.URUN_SINIF_KOD||r_c20.ZAMAN_NUMARA||r_c20.LIMIT_NUMARA );
				end ;
		  end if;
		end if;
	end loop;
	close c20;

  End;

  Procedure Yetki_Veri_Kontrol is
    cursor c1 is
	  select *
	    from cbs_rol_urun_islem_arabirim
		 for update;

	r_c1 	 c1%rowtype;

    cursor c2 is
	  select *
	    from cbs_rol_urun_islem_dogru_ara
		 for update;

	r_c2 	 c2%rowtype;

    cursor c3 is
	  select *
	    from cbs_rol_urun_islem_onay_ara
		 for update;

	r_c3 	 c3%rowtype;

    cursor c4 is
	  select *
	    from cbs_rol_urun_islem_iptal_ara
		 for update;

	r_c4 	 c4%rowtype;

	p_dummy	 number;
	p_hata	 varchar2(2000);
  Begin
    open c1;
	loop

	  fetch c1 into r_c1;
	  exit when c1%notfound;
        p_hata:='';

		begin
 	      select count(*)
	        into p_dummy
	        from cbs_rol_urun_islem_arabirim
		   where ROL_NUMARA=r_c1.ROL_NUMARA
		     and ISLEM_TANIM_KOD=r_c1.ISLEM_TANIM_KOD
/*             and MODUL_TUR_KOD=nvl(r_c1.MODUL_TUR_KOD,MODUL_TUR_KOD )
             and URUN_TUR_KOD=nvl(r_c1.URUN_TUR_KOD,URUN_TUR_KOD )
             and URUN_SINIF_KOD=nvl(r_c1.URUN_SINIF_KOD,URUN_TUR_KOD)*/
             and MODUL_TUR_KOD=r_c1.MODUL_TUR_KOD
             and URUN_TUR_KOD=r_c1.URUN_TUR_KOD
             and URUN_SINIF_KOD=r_c1.URUN_SINIF_KOD
             and ZAMAN_NUMARA=r_c1.ZAMAN_NUMARA
		     and LIMIT_NUMARA=r_c1.LIMIT_NUMARA;
		  if p_dummy>1 then
		     p_hata:=p_hata||' Duplike kay?t';
		  end if;
		exception
		  when no_data_found then
		    null;
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_rol
		    where numara=r_c1.rol_numara;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Rol Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_islem_tanim
		    where kod=r_c1.islem_tanim_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Islem Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_modul_tur
		    where kod=r_c1.modul_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Modul Tur Yok';
		end;

		if r_c1.urun_tur_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_tur
		    where modul_tur_kod=r_c1.modul_tur_kod
			  and kod=r_c1.urun_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun Tur Yok';
		end;

		end if;

		if r_c1.urun_sinif_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_sinif
		    where modul_tur_kod=r_c1.modul_tur_kod
			  and urun_tur_kod=r_c1.urun_tur_kod
			  and kod=r_c1.urun_sinif_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun sinif Yok';
		end;

		end if;

      update cbs_rol_urun_islem_arabirim
	     set hata=p_hata
	   where current of c1;

	end loop;
	close c1;

    open c2;
	loop

	  fetch c2 into r_c2;
	  exit when c2%notfound;
        p_hata:='';

		begin
 	      select count(*)
	        into p_dummy
	        from cbs_rol_urun_islem_dogru
		   where ROL_NUMARA=r_c2.ROL_NUMARA
		     and ISLEM_TANIM_KOD=r_c2.ISLEM_TANIM_KOD
             and MODUL_TUR_KOD=r_c2.MODUL_TUR_KOD
             and URUN_TUR_KOD=r_c2.URUN_TUR_KOD
             and URUN_SINIF_KOD=r_c2.URUN_SINIF_KOD
             and ZAMAN_NUMARA=r_c2.ZAMAN_NUMARA
		     and LIMIT_NUMARA=r_c2.LIMIT_NUMARA;
		  if p_dummy>1 then
		     p_hata:=p_hata||' Duplike kay?t';
		  end if;
		exception
		  when no_data_found then
		    null;
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_rol
		    where numara=r_c2.rol_numara;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Rol Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_islem_tanim
		    where kod=r_c2.islem_tanim_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Islem Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_modul_tur
		    where kod=r_c2.modul_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Modul Tur Yok';
		end;

		if r_c2.urun_tur_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_tur
		    where modul_tur_kod=r_c2.modul_tur_kod
			  and kod=r_c2.urun_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun Tur Yok';
		end;

		end if;

		if r_c2.urun_sinif_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_sinif
		    where modul_tur_kod=r_c2.modul_tur_kod
			  and urun_tur_kod=r_c2.urun_tur_kod
			  and kod=r_c2.urun_sinif_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun sinif Yok';
		end;

		end if;

      update cbs_rol_urun_islem_dogru_ara
	     set hata=p_hata
	   where current of c2;

	end loop;
	close c2;

    open c3;
	loop

	  fetch c3 into r_c3;
	  exit when c3%notfound;
        p_hata:='';

		begin
 	      select count(*)
	        into p_dummy
	        from cbs_rol_urun_islem_onay
		   where ROL_NUMARA=r_c3.ROL_NUMARA
		     and ISLEM_TANIM_KOD=r_c3.ISLEM_TANIM_KOD
             and MODUL_TUR_KOD=r_c3.MODUL_TUR_KOD
             and URUN_TUR_KOD=r_c3.URUN_TUR_KOD
             and URUN_SINIF_KOD=r_c3.URUN_SINIF_KOD
             and ZAMAN_NUMARA=r_c3.ZAMAN_NUMARA
		     and LIMIT_NUMARA=r_c3.LIMIT_NUMARA;
		  if p_dummy>1 then
		     p_hata:=p_hata||' Duplike kay?t';
		  end if;
		exception
		  when no_data_found then
		    null;
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_rol
		    where numara=r_c3.rol_numara;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Rol Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_islem_tanim
		    where kod=r_c3.islem_tanim_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Islem Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_modul_tur
		    where kod=r_c3.modul_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Modul Tur Yok';
		end;

		if r_c3.urun_tur_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_tur
		    where modul_tur_kod=r_c3.modul_tur_kod
			  and kod=r_c3.urun_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun Tur Yok';
		end;

		end if;

		if r_c3.urun_sinif_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_sinif
		    where modul_tur_kod=r_c3.modul_tur_kod
			  and urun_tur_kod=r_c3.urun_tur_kod
			  and kod=r_c3.urun_sinif_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun sinif Yok';
		end;

		end if;

      update cbs_rol_urun_islem_onay_ara
	     set hata=p_hata
	   where current of c3;

	end loop;
	close c3;


    open c4;
	loop

	  fetch c4 into r_c4;
	  exit when c4%notfound;
        p_hata:='';

		begin
 	      select count(*)
	        into p_dummy
	        from cbs_rol_urun_islem_iptal
		   where ROL_NUMARA=r_c4.ROL_NUMARA
		     and ISLEM_TANIM_KOD=r_c4.ISLEM_TANIM_KOD
             and MODUL_TUR_KOD=r_c4.MODUL_TUR_KOD
             and URUN_TUR_KOD=r_c4.URUN_TUR_KOD
             and URUN_SINIF_KOD=r_c4.URUN_SINIF_KOD
             and ZAMAN_NUMARA=r_c4.ZAMAN_NUMARA
		     and LIMIT_NUMARA=r_c4.LIMIT_NUMARA;
		  if p_dummy>1 then
		     p_hata:=p_hata||' Duplike kay?t';
		  end if;
		exception
		  when no_data_found then
		    null;
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_rol
		    where numara=r_c4.rol_numara;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Rol Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_islem_tanim
		    where kod=r_c4.islem_tanim_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Islem Yok';
		end;

	    begin
          select 1
		    into p_dummy
			from cbs_modul_tur
		    where kod=r_c4.modul_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Modul Tur Yok';
		end;

		if r_c4.urun_tur_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_tur
		    where modul_tur_kod=r_c4.modul_tur_kod
			  and kod=r_c4.urun_tur_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun Tur Yok';
		end;

		end if;

		if r_c4.urun_sinif_kod is not null then

	    begin
          select 1
		    into p_dummy
			from cbs_urun_sinif
		    where modul_tur_kod=r_c4.modul_tur_kod
			  and urun_tur_kod=r_c4.urun_tur_kod
			  and kod=r_c4.urun_sinif_kod;
		exception
		  when no_data_found then
		    p_hata:=p_hata||' Urun sinif Yok';
		end;

		end if;

      update cbs_rol_urun_islem_iptal_ara
	     set hata=p_hata
	   where current of c4;

	end loop;
	close c4;

  End;

  Procedure Yetki_Sil is
  Begin
    delete from cbs_rol_urun_islem where auto_yaratildi='E';
    delete from cbs_rol_urun_islem_dogru where auto_yaratildi='E';
    delete from cbs_rol_urun_islem_onay where auto_yaratildi='E';
    delete from cbs_rol_urun_islem_iptal where auto_yaratildi='E';
  End;

  Procedure Arabirim_Temizle is
  Begin
  	delete from cbs_rol_urun_islem_arabirim;
	delete from cbs_rol_urun_islem_dogru_ara;
	delete from cbs_rol_urun_islem_onay_ara;
	delete from cbs_rol_urun_islem_iptal_ara;
  End;

END;
/

