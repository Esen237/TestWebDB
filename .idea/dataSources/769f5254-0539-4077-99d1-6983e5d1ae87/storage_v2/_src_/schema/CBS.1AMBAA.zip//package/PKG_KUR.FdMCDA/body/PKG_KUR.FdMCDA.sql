create PACKAGE BODY     Pkg_Kur IS


  c_kur_tip    CONSTANT NUMBER := 3;
  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;


   FUNCTION DOVIZ_KARSILIK(p_doviz_kod_1  VARCHAR2
                        , p_doviz_kod_2  VARCHAR2
                        , p_tarih        DATE DEFAULT NULL
                        , p_tutar        NUMBER
                        , p_kur_tip      NUMBER DEFAULT 3
                        , p_sabit_1             NUMBER
                        , p_sabit_2             NUMBER
                        , P_alis_satis   VARCHAR2
                        ) RETURN NUMBER IS

    n_lc_amount_1        NUMBER; --(35,8);
    n_lc_amount_2        NUMBER;--(35,8);
    n_lc_amount_3        NUMBER;--(35,8);
    n_fc_amount_1        NUMBER;--(35,8);
    n_fc_amount_2        NUMBER;--(35,8);
    n_fc_amount_3        NUMBER; --(35,8);

    s_max_dt_1            VARCHAR2(40);
    s_max_dt_2            VARCHAR2(40);
    s_carp_1            VARCHAR2(1);
    s_carp_2            VARCHAR2(1);
    l_error VARCHAR2(2000);

   TYPE CurKurlogRec IS RECORD ( maxkurdate VARCHAR2(500) );
   TYPE CurKurlogTyp IS REF CURSOR RETURN CurKurlogRec;
   cur_kurlog CurKurlogTyp;  -- declare cursor variable

   TYPE CurKurlogRec2 IS RECORD ( amount_1 number,amount_2 number,amount_3 number);
   TYPE CurKurlogTyp2 IS REF CURSOR RETURN CurKurlogRec2;
   cur_kurlog2 CurKurlogTyp2;  -- declare cursor variable

  BEGIN

       -- multiply or divide ?!
      SELECT    carp
      INTO        s_carp_1
      FROM        CBS_KUR
      WHERE        dvz = p_doviz_kod_1;

      -- multiply or divide ?!
      SELECT    carp
      INTO        s_carp_2
      FROM        CBS_KUR
      WHERE        dvz = p_doviz_kod_2;

    IF p_tarih IS NULL THEN

      IF p_alis_satis = 'A' THEN         -- alis - bidrate

          IF s_carp_1 = 'E' THEN        -- multiply
                  BEGIN
                      SELECT    ROUND((dvzalis * p_tutar)/p_sabit_1,8),ROUND( (efalis * p_tutar)/p_sabit_1,8), ROUND((esalis * p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR
                      WHERE        dvz = p_doviz_kod_1;

                   EXCEPTION
                    WHEN OTHERS THEN
                     l_error:=SQLERRM;
                     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                    --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '301'||g_ara_delimiter||p_doviz_kod_1||' '||l_error||g_uc_delimiter);
                         --RETURN -2000142;
                  END;

         ELSE-- divide
                  BEGIN
                      SELECT    ROUND((dvzalis / p_tutar)/p_sabit_1,8),ROUND( (efalis / p_tutar)/p_sabit_1,8),ROUND( (esalis / p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR
                      WHERE        dvz = p_doviz_kod_1;

                   EXCEPTION
                     WHEN OTHERS THEN
                          l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);

                         --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '302' ||g_uc_delimiter);
                           --RETURN -2000143;
                  END;
        END IF;
     ELSE -- satis - oferrate

             IF s_carp_1 = 'E' THEN        -- multiply
                  BEGIN
                      SELECT    ROUND((dvzsatis * p_tutar)/p_sabit_1,8), ROUND((efsatis * p_tutar)/p_sabit_1,8), ROUND((essatis * p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR
                      WHERE        dvz = p_doviz_kod_1;

                   EXCEPTION
                       WHEN OTHERS THEN
                     l_error:=SQLERRM;
                     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                    --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '301'||g_ara_delimiter||p_doviz_kod_1||g_uc_delimiter);
                           --RETURN -2000142;

                END;
               ELSE-- divide
                  BEGIN
                      SELECT    ROUND((dvzsatis / p_tutar)/p_sabit_1,8),ROUND( (efsatis / p_tutar)/p_sabit_1,8),ROUND( (essatis / p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR
                      WHERE        dvz = p_doviz_kod_1;

                   EXCEPTION
                     WHEN OTHERS THEN
                           l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                         --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '302' ||g_uc_delimiter);
                           --RETURN -2000143;
                  END;
        END IF;

      END IF;

        IF p_alis_satis = 'A' THEN         -- alis - bidrate
            IF s_carp_2 = 'E' THEN        -- multiply
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 / dvzalis)*p_sabit_2,8),ROUND( (n_lc_amount_2 / efalis)*p_sabit_2,8),ROUND( (n_lc_amount_3 / esalis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR
                    WHERE        dvz = p_doviz_kod_2;

                EXCEPTION
                    WHEN OTHERS THEN
                    log_at('236','2', dbms_utility.format_error_backtrace);
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '303' ||g_uc_delimiter);
                        --RETURN -2000144;
                END;
            ELSE                -- divide
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 * dvzalis)*p_sabit_2,8),ROUND( (n_lc_amount_2 * efalis)*p_sabit_2,8),ROUND( (n_lc_amount_3 * esalis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR
                    WHERE        dvz = p_doviz_kod_2;

                   EXCEPTION
                       WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '304' ||g_uc_delimiter);
                        --RETURN -2000145;
                END;
            END IF;
        ELSE -- satis - oferrate
            IF s_carp_2 = 'E' THEN        -- multiply
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 / dvzsatis)*p_sabit_2,8), ROUND((n_lc_amount_2 / efsatis)*p_sabit_2,8), ROUND((n_lc_amount_3 / essatis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR
                    WHERE        dvz = p_doviz_kod_2;

                   EXCEPTION
                       WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '305' ||g_uc_delimiter);
                        --RETURN -2000146;

                END;
            ELSE                -- divide
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 * dvzsatis)*p_sabit_2,8), ROUND((n_lc_amount_2 * efsatis)*p_sabit_2,8),ROUND( (n_lc_amount_3 * essatis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR
                    WHERE        dvz = p_doviz_kod_2;

                EXCEPTION
                    WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '306' ||g_uc_delimiter);
                        --RETURN -2000147;
                END;
            END IF;
        END IF;
   ELSE

      -- find the latest fx rate and date for that day, for doviz_1
          BEGIN
    /*sevalb*/
         OPEN cur_kurlog FOR
               SELECT TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
                FROM    CBS_KURLOG
                WHERE    dvz = p_doviz_kod_1
                    AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');

           FETCH cur_kurlog INTO s_max_dt_1;

/*           SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI')
            INTO    s_max_dt_1
            FROM    CBS_KURLOG
            WHERE    dvz = p_doviz_kod_1
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
            --to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_1;
*/
          EXCEPTION
              WHEN OTHERS THEN
                 l_error:=SQLERRM;
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '307' ||g_uc_delimiter);
                  --RETURN -2000148;
          END;

      -- find the latest fx rate and date for that day, for doviz_2
          BEGIN
         OPEN cur_kurlog FOR
               SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
                FROM    CBS_KURLOG
                 WHERE    dvz = p_doviz_kod_2
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
           FETCH cur_kurlog INTO s_max_dt_2;
/*          SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI')
                INTO    s_max_dt_2
                FROM    CBS_KURLOG
                WHERE    dvz = p_doviz_kod_2
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
            --to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_2;
*/
          EXCEPTION
              WHEN OTHERS THEN
                 l_error:=SQLERRM;
                 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '308' ||g_uc_delimiter);
                  --RETURN -2000149;
          END;

       IF p_alis_satis = 'A'
      THEN                                                   -- alis - bidrate
         IF s_carp_1 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzalis * p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efalis * p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (esalis * p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1;


               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzalis / p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efalis / p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (esalis / p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1;

               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      ELSE                                           --p_alis_satis = 's' then
         IF s_carp_1 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzsatis * p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efsatis * p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (essatis * p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1;


               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzsatis / p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efsatis / p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (essatis / p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1;

               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      END IF;

      IF p_alis_satis = 'A'
      THEN                                                   -- alis - bidrate
         IF s_carp_2 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 / dvzalis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 / efalis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 / esalis) * p_sabit_2, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE                                                        -- divide
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 * dvzalis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 * efalis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 * esalis) * p_sabit_2, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      ELSE                                                 -- satis - oferrate
         IF s_carp_2 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 / dvzsatis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 / efsatis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 / essatis) * p_sabit_2, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE                                                        -- divide
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 * dvzsatis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 * efsatis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 * essatis) * p_sabit_2, 8)
                              amount_3
                    FROM   cbs_kurlog
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      END IF;
    END IF;


    IF p_kur_tip = 1 THEN        -- doviz alis/satis
        RETURN n_fc_amount_1;

    ELSIF p_kur_tip = 2 THEN    -- efektif alis/satis
        RETURN n_fc_amount_2;

    ELSIF p_kur_tip = 3 THEN    -- esas alis/satis
        RETURN n_fc_amount_3;

    ELSE

        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '315' ||g_uc_delimiter);
        --RETURN -2000160;

    END IF;

  END;
------------------------------------------------------------------------------------------
-- B-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
  FUNCTION DOVIZ_KARSILIK(p_doviz_kod_1  VARCHAR2
                        , p_doviz_kod_2  VARCHAR2
                        , p_tarih        DATE DEFAULT NULL
                        , p_tutar        NUMBER
                        , p_kur_tip      NUMBER DEFAULT 3
                        , p_sabit_1             NUMBER
                        , p_sabit_2             NUMBER
                        , p_alis_satis   VARCHAR2
                        , p_branch         VARCHAR2) RETURN NUMBER IS

    n_lc_amount_1        NUMBER; --(35,8);
    n_lc_amount_2        NUMBER;--(35,8);
    n_lc_amount_3        NUMBER;--(35,8);
    n_fc_amount_1        NUMBER;--(35,8);
    n_fc_amount_2        NUMBER;--(35,8);
    n_fc_amount_3        NUMBER; --(35,8);

    s_max_dt_1            VARCHAR2(40);
    s_max_dt_2            VARCHAR2(40);
    s_carp_1            VARCHAR2(1);
    s_carp_2            VARCHAR2(1);
    l_error VARCHAR2(2000);

   TYPE CurKurlogRec IS RECORD ( maxkurdate VARCHAR2(500) );
   TYPE CurKurlogTyp IS REF CURSOR RETURN CurKurlogRec;
   cur_kurlog CurKurlogTyp;  -- declare cursor variable

   TYPE CurKurlogRec2 IS RECORD ( amount_1 number,amount_2 number,amount_3 number);
   TYPE CurKurlogTyp2 IS REF CURSOR RETURN CurKurlogRec2;
   cur_kurlog2 CurKurlogTyp2;  -- declare cursor variable

  BEGIN

       -- multiply or divide ?!
      SELECT    carp
      INTO        s_carp_1
      FROM        CBS_KUR_BRANCH
      WHERE        dvz = p_doviz_kod_1 
                 and  branch = p_branch;

      -- multiply or divide ?!
      SELECT    carp
      INTO        s_carp_2
      FROM        CBS_KUR_BRANCH
      WHERE        dvz = p_doviz_kod_2
                 and branch = p_branch;

    IF p_tarih IS NULL THEN

      IF p_alis_satis = 'A' THEN         -- alis - bidrate

          IF s_carp_1 = 'E' THEN        -- multiply
                  BEGIN
                      SELECT    ROUND((dvzalis * p_tutar)/p_sabit_1,8),ROUND( (efalis * p_tutar)/p_sabit_1,8), ROUND((esalis * p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR_BRANCH
                      WHERE        dvz = p_doviz_kod_1
                                  and branch = p_branch;

                   EXCEPTION
                    WHEN OTHERS THEN
                     l_error:=SQLERRM;
                     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                    --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '301'||g_ara_delimiter||p_doviz_kod_1||' '||l_error||g_uc_delimiter);
                         --RETURN -2000142;
                  END;

         ELSE-- divide
                  BEGIN
                      SELECT    ROUND((dvzalis / p_tutar)/p_sabit_1,8),ROUND( (efalis / p_tutar)/p_sabit_1,8),ROUND( (esalis / p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR_BRANCH
                      WHERE        dvz = p_doviz_kod_1
                                  and branch = p_branch;

                   EXCEPTION
                     WHEN OTHERS THEN
                          l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);

                         --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '302' ||g_uc_delimiter);
                           --RETURN -2000143;
                  END;
        END IF;
     ELSE -- satis - oferrate

             IF s_carp_1 = 'E' THEN        -- multiply
                  BEGIN
                      SELECT    ROUND((dvzsatis * p_tutar)/p_sabit_1,8), ROUND((efsatis * p_tutar)/p_sabit_1,8), ROUND((essatis * p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR_BRANCH
                      WHERE        dvz = p_doviz_kod_1
                                  and branch = p_branch;

                   EXCEPTION
                       WHEN OTHERS THEN
                     l_error:=SQLERRM;
                     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                    --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '301'||g_ara_delimiter||p_doviz_kod_1||g_uc_delimiter);
                           --RETURN -2000142;

                END;
               ELSE-- divide
                  BEGIN
                      SELECT    ROUND((dvzsatis / p_tutar)/p_sabit_1,8),ROUND( (efsatis / p_tutar)/p_sabit_1,8),ROUND( (essatis / p_tutar)/p_sabit_1,8)
                      INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                      FROM        CBS_KUR_BRANCH
                      WHERE        dvz = p_doviz_kod_1
                                  and branch = p_branch;

                   EXCEPTION
                     WHEN OTHERS THEN
                           l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                         --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '302' ||g_uc_delimiter);
                           --RETURN -2000143;
                  END;
        END IF;

      END IF;

        IF p_alis_satis = 'A' THEN         -- alis - bidrate
            IF s_carp_2 = 'E' THEN        -- multiply
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 / dvzalis)*p_sabit_2,8),ROUND( (n_lc_amount_2 / efalis)*p_sabit_2,8),ROUND( (n_lc_amount_3 / esalis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR_BRANCH
                    WHERE        dvz = p_doviz_kod_2
                                  and branch = p_branch;

                EXCEPTION
                    WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '303' ||g_uc_delimiter);
                        --RETURN -2000144;
                END;
            ELSE                -- divide
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 * dvzalis)*p_sabit_2,8),ROUND( (n_lc_amount_2 * efalis)*p_sabit_2,8),ROUND( (n_lc_amount_3 * esalis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR_BRANCH
                    WHERE        dvz = p_doviz_kod_2
                                  and branch = p_branch;

                   EXCEPTION
                       WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '304' ||g_uc_delimiter);
                        --RETURN -2000145;
                END;
            END IF;
        ELSE -- satis - oferrate
            IF s_carp_2 = 'E' THEN        -- multiply
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 / dvzsatis)*p_sabit_2,8), ROUND((n_lc_amount_2 / efsatis)*p_sabit_2,8), ROUND((n_lc_amount_3 / essatis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR_BRANCH
                    WHERE        dvz = p_doviz_kod_2
                                  and branch = p_branch;

                   EXCEPTION
                       WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '305' ||g_uc_delimiter);
                        --RETURN -2000146;

                END;
            ELSE                -- divide
                BEGIN
                    SELECT    ROUND((n_lc_amount_1 * dvzsatis)*p_sabit_2,8), ROUND((n_lc_amount_2 * efsatis)*p_sabit_2,8),ROUND( (n_lc_amount_3 * essatis)*p_sabit_2,8)
                    INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                    FROM        CBS_KUR_BRANCH
                    WHERE        dvz = p_doviz_kod_2
                                  and branch = p_branch;

                EXCEPTION
                    WHEN OTHERS THEN
                         l_error:=SQLERRM;
                         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                        --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '306' ||g_uc_delimiter);
                        --RETURN -2000147;
                END;
            END IF;
        END IF;
   ELSE

      -- find the latest fx rate and date for that day, for doviz_1
          BEGIN
    /*sevalb*/
         OPEN cur_kurlog FOR
               SELECT TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
                FROM    CBS_KURLOG_BRANCH
                WHERE    dvz = p_doviz_kod_1
                    AND branch = p_branch
                    AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');

           FETCH cur_kurlog INTO s_max_dt_1;

/*           SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI')
            INTO    s_max_dt_1
            FROM    CBS_KURLOG
            WHERE    dvz = p_doviz_kod_1
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
            --to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_1;
*/
          EXCEPTION
              WHEN OTHERS THEN
                 l_error:=SQLERRM;
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '307' ||g_uc_delimiter);
                  --RETURN -2000148;
          END;

      -- find the latest fx rate and date for that day, for doviz_2
          BEGIN
         OPEN cur_kurlog FOR
               SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
                FROM    CBS_KURLOG_BRANCH
                 WHERE    dvz = p_doviz_kod_2
                      AND branch = p_branch
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
           FETCH cur_kurlog INTO s_max_dt_2;
/*          SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI')
                INTO    s_max_dt_2
                FROM    CBS_KURLOG
                WHERE    dvz = p_doviz_kod_2
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
            --to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_2;
*/
          EXCEPTION
              WHEN OTHERS THEN
                 l_error:=SQLERRM;
                 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||l_error||g_uc_delimiter);
                --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '308' ||g_uc_delimiter);
                  --RETURN -2000149;
          END;

       IF p_alis_satis = 'A'
      THEN                                                   -- alis - bidrate
         IF s_carp_1 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzalis * p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efalis * p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (esalis * p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1
                           AND branch = p_branch;


               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzalis / p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efalis / p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (esalis / p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      ELSE                                           --p_alis_satis = 's' then
         IF s_carp_1 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzsatis * p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efsatis * p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (essatis * p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1
                           AND branch = p_branch;


               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (dvzsatis / p_tutar) / p_sabit_1, 8)
                              amount_1,
                           ROUND ( (efsatis / p_tutar) / p_sabit_1, 8)
                              amount_2,
                           ROUND ( (essatis / p_tutar) / p_sabit_1, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_1, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_1
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_lc_amount_1, n_lc_amount_2, n_lc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      END IF;

      IF p_alis_satis = 'A'
      THEN                                                   -- alis - bidrate
         IF s_carp_2 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 / dvzalis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 / efalis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 / esalis) * p_sabit_2, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE                                                        -- divide
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 * dvzalis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 * efalis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 * esalis) * p_sabit_2, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      ELSE                                                 -- satis - oferrate
         IF s_carp_2 = 'E'
         THEN                                                      -- multiply
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 / dvzsatis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 / efsatis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 / essatis) * p_sabit_2, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         ELSE                                                        -- divide
            BEGIN
               OPEN cur_kurlog2 FOR
                  SELECT   ROUND ( (n_lc_amount_1 * dvzsatis) * p_sabit_2, 8)
                              amount_1,
                           ROUND ( (n_lc_amount_2 * efsatis) * p_sabit_2, 8)
                              amount_2,
                           ROUND ( (n_lc_amount_3 * essatis) * p_sabit_2, 8)
                              amount_3
                    FROM   CBS_KURLOG_BRANCH
                   WHERE   tarih = TO_DATE (s_max_dt_2, 'DDMMYYYY HH24:MI')
                           AND dvz = p_doviz_kod_2
                           AND branch = p_branch;

               FETCH cur_kurlog2
                  INTO
                            n_fc_amount_1, n_fc_amount_2, n_fc_amount_3;
            EXCEPTION
               WHEN OTHERS
               THEN
                  l_error := SQLERRM;
                  raise_application_error (
                     -20100,
                     g_uc_delimiter || l_error || g_uc_delimiter
                  );
            END;
         END IF;
      END IF;
    END IF;


    IF p_kur_tip = 1 THEN        -- doviz alis/satis
        RETURN n_fc_amount_1;

    ELSIF p_kur_tip = 2 THEN    -- efektif alis/satis
        RETURN n_fc_amount_2;

    ELSIF p_kur_tip = 3 THEN    -- esas alis/satis
        RETURN n_fc_amount_3;

    ELSE

        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '315' ||g_uc_delimiter);
        --RETURN -2000160;

    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        return 0;
  END;
--------------------------------------------------------------------------------------------
-- E-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches

  FUNCTION DOVIZ_KARSILIK_NB(p_doviz_kod_1  VARCHAR2
                        , p_doviz_kod_2  VARCHAR2
                        , p_tarih        DATE DEFAULT NULL
                        , p_tutar        NUMBER
                        , p_kur_tip      NUMBER DEFAULT 3
                        , p_sabit_1             NUMBER
                        , p_sabit_2             NUMBER
                        , P_alis_satis   VARCHAR2
                        ) RETURN NUMBER IS

    n_lc_amount_1        NUMBER;--(35,8);
    n_lc_amount_2        NUMBER;--(35,8);
    n_lc_amount_3        NUMBER;--(35,8);
    n_fc_amount_1        NUMBER;--(35,8);
    n_fc_amount_2        NUMBER;--(35,8);
    n_fc_amount_3        NUMBER;--(35,8);

    s_max_dt_1            VARCHAR2(40);
    s_max_dt_2            VARCHAR2(40);

   TYPE CurKurlogRec IS RECORD ( maxkurdate VARCHAR2(500) );
   TYPE CurKurlogTyp IS REF CURSOR RETURN CurKurlogRec;
   cur_kurlog CurKurlogTyp;  -- declare cursor variable

   TYPE CurKurlogRec2 IS RECORD ( amount_1 number,amount_2 number,amount_3 number);
   TYPE CurKurlogTyp2 IS REF CURSOR RETURN CurKurlogRec2;
   cur_kurlog2 CurKurlogTyp2;  -- declare cursor variable

  BEGIN

    IF p_tarih IS NULL THEN

          IF p_alis_satis = 'A' THEN -- alis - bidrate
                BEGIN
                SELECT    ROUND((dvzalis * p_tutar)/p_sabit_1,8),ROUND( (efalis * p_tutar)/p_sabit_1,8),ROUND( (esalis * p_tutar)/p_sabit_1,8)
                  INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                  FROM        CBS_MBKUR
                  WHERE        dvz = p_doviz_kod_1;

                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '316' ||  g_ara_delimiter || p_doviz_kod_1 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                      --RETURN -2000161;
                END;
            ELSE --sat?? - offerrate

            IF p_alis_satis = 'S' THEN
               BEGIN
                SELECT    ROUND((dvzsatis * p_tutar)/p_sabit_1,8),ROUND( (efsatis * p_tutar)/p_sabit_1,8),ROUND( (essatis * p_tutar)/p_sabit_1,8)
                  INTO        n_lc_amount_1,             n_lc_amount_2,            n_lc_amount_3
                  FROM        CBS_MBKUR
                  WHERE        dvz = p_doviz_kod_1;

                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '316' ||  g_ara_delimiter || p_doviz_kod_1 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                      --RETURN -2000161;
               END;
             END IF;

          END IF;

        IF p_alis_satis = 'A' THEN -- alis - bidrate
              BEGIN
                  SELECT    ROUND((n_lc_amount_1 / dvzalis)*p_sabit_2,8),ROUND( (n_lc_amount_2 / efalis)*p_sabit_2,8), ROUND((n_lc_amount_3 / esalis)*p_sabit_2,8)
                  INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                  FROM        CBS_MBKUR
                  WHERE        dvz = p_doviz_kod_2;

                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '316' || g_ara_delimiter || p_doviz_kod_2 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                      --RETURN -2000162;
              END;
        ELSE -- satis - oferrate
              BEGIN
                  SELECT    ROUND((n_lc_amount_1 / dvzsatis)*p_sabit_2,8), ROUND((n_lc_amount_2 / efsatis)*p_sabit_2,8),ROUND( (n_lc_amount_3 / essatis)*p_sabit_2,8)
                  INTO        n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3
                  FROM        CBS_MBKUR
                  WHERE        dvz = p_doviz_kod_2;

                  EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '316' || g_ara_delimiter || p_doviz_kod_2  || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                      --RETURN -2000163;
              END;
        END IF;
   ELSE

      -- find the latest fx rate and date for that day, for doviz_1
          BEGIN

         OPEN cur_kurlog FOR
              SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxkurdate
                FROM    CBS_MBKURLOG   --o g?n i?in kur tan?ml? de?ilse ne yaps?n ?? mutluo
               WHERE    dvz = p_doviz_kod_1
               AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
       --mutluo  yukardaki gibi d?zeltildi. to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_1;
       FETCH cur_kurlog INTO s_max_dt_1;


              EXCEPTION
                  WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '317' || g_ara_delimiter || p_doviz_kod_1 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                  --RETURN -2000164;
          END;

      -- find the latest fx rate and date for that day, for doviz_2
          BEGIN

         OPEN cur_kurlog FOR
              SELECT    TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxkurdate
              FROM    CBS_MBKURLOG
              WHERE dvz = p_doviz_kod_2
               AND tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
            --to_char (tarih,'DDMMYYYY') <= to_char(p_tarih,'DDMMYYYY') AND dvz = p_doviz_kod_2;
           FETCH cur_kurlog INTO s_max_dt_2;

              EXCEPTION
                  WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '317' || g_ara_delimiter || p_doviz_kod_2 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                  --RETURN -2000165;
          END;

          BEGIN
         OPEN cur_kurlog2 FOR
              SELECT ROUND((dvzalis * p_tutar)/p_sabit_1,8) amount_1,ROUND( (efalis * p_tutar)/p_sabit_1,8) amount_2,ROUND( (esalis * p_tutar)/p_sabit_1,8) amount_3
                FROM CBS_MBKURLOG
               WHERE tarih = TO_DATE(s_max_dt_1,'DDMMYYYY HH24:MI')
               AND dvz = p_doviz_kod_1;

               FETCH cur_kurlog2  INTO n_lc_amount_1,             n_lc_amount_2,             n_lc_amount_3;

              EXCEPTION
                  WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '317' || g_ara_delimiter || p_doviz_kod_1 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                  --RETURN -2000166;
          END;

      IF p_alis_satis = 'A' THEN -- alis - bidrate
            BEGIN
            OPEN cur_kurlog2 FOR
                SELECT ROUND((n_lc_amount_1 / dvzalis)*p_sabit_2,8) amount_1,ROUND( (n_lc_amount_2 / efalis)*p_sabit_2,8) amount_2,ROUND( (n_lc_amount_3 / esalis)*p_sabit_2,8) amount_3
                  FROM CBS_MBKURLOG
                 WHERE tarih = TO_DATE(s_max_dt_2,'DDMMYYYY HH24:MI')
                   AND dvz = p_doviz_kod_2;
                    --to_char(tarih, 'DD/MM/YYYY HH24:MI') = s_max_dt_2 AND dvz = p_doviz_kod_2;
             FETCH cur_kurlog2   INTO n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3;
                EXCEPTION
                    WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '317' || g_ara_delimiter || p_doviz_kod_2 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                    --RETURN -2000167;
            END;
      ELSE -- satis - oferrate
            BEGIN
            OPEN cur_kurlog2 FOR
                SELECT    ROUND((n_lc_amount_1 / dvzsatis)*p_sabit_2,8) amount_1,ROUND( (n_lc_amount_2 / efsatis)*p_sabit_2,8) amount_2 ,ROUND( (n_lc_amount_3 / essatis)*p_sabit_2,8) amount_3
                  FROM    CBS_MBKURLOG
                  WHERE    tarih = TO_DATE(s_max_dt_2,'DDMMYYYY HH24:MI')
                    AND dvz = p_doviz_kod_2;
                     --    to_char(tarih, 'DD/MM/YYYY HH24:MI') = s_max_dt_2 AND dvz = p_doviz_kod_2;
                 FETCH cur_kurlog2   INTO    n_fc_amount_1,            n_fc_amount_2,            n_fc_amount_3;
                EXCEPTION
                    WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '317' || g_ara_delimiter || p_doviz_kod_2 || g_ara_delimiter || SQLCODE || g_ara_delimiter || SQLERRM || g_uc_delimiter);
                    --RETURN -2000168;
            END;
      END IF;
    END IF;

    IF p_kur_tip = 1 THEN        -- doviz alis/satis
        RETURN n_fc_amount_1;
    ELSIF p_kur_tip = 2 THEN    -- efektif alis/satis
        RETURN n_fc_amount_2;
    ELSIF p_kur_tip = 3 THEN    -- esas alis/satis
        RETURN n_fc_amount_3;
    ELSE
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '324' ||g_uc_delimiter);
        --RETURN -2000175;
    END IF;

  END;
------------------------------------------------------------------------------------------
  FUNCTION DOVIZ_DOVIZ_KARSILIK(p_doviz_kod_1      VARCHAR2
                              , p_doviz_kod_2      VARCHAR2
                              , p_tarih            DATE DEFAULT NULL
                              , p_tutar            NUMBER
                              , p_kur_tip          NUMBER DEFAULT 3
                              , p_kur_deger_1      NUMBER DEFAULT NULL
                              , p_kur_deger_2      NUMBER DEFAULT NULL
                              , p_kur_tablo        VARCHAR2 DEFAULT 'O'
                              , p_alis_satis       VARCHAR2 DEFAULT 'A'
                              , p_karsilik_tutar   OUT NUMBER) RETURN NUMBER IS

  n_kur_tip       NUMBER;
  n_lc_amount          NUMBER ;-- number(35,8);
  n_fc_amount          NUMBER ; --number(35,8);
  n_sabit_1                NUMBER;
  n_sabit_2                NUMBER;
  v_kuruslu                VARCHAR2(1);
  e_hata          EXCEPTION;
  e_kur_tablo_yok EXCEPTION;

  BEGIN

    IF NVL(P_TUTAR,0) = 0 THEN
       RETURN 0;
    END IF;

    -- kontrol the currency
    IF p_doviz_kod_1 = p_doviz_kod_2 THEN
       p_karsilik_tutar := p_tutar;
       RETURN 1;
    END IF;

      IF p_kur_tip IS NULL THEN
       n_kur_tip := c_kur_tip;
      ELSE
       n_kur_tip := p_kur_tip;
    END IF;

  -- the constant value for the crncy.. USD, DEM = 1    JPY, ITL = 100
    SELECT    birim
    INTO        n_sabit_1
    FROM        CBS_DOVIZ_KODLARI
    WHERE        doviz_kodu = p_doviz_kod_1;

    -- the constant value for the second crncy.. USD, DEM = 1    JPY, ITL = 100
    SELECT    birim, kuruslu_mu
    INTO        n_sabit_2, v_kuruslu
    FROM        CBS_DOVIZ_KODLARI
    WHERE        doviz_kodu = p_doviz_kod_2;

  IF p_kur_deger_1 IS NULL AND p_kur_deger_2 IS NULL THEN
    IF p_kur_tablo = 'O' THEN
       n_fc_amount := DOVIZ_KARSILIK(p_doviz_kod_1, p_doviz_kod_2, p_tarih, ABS(p_tutar), n_kur_tip,n_sabit_1,n_sabit_2,P_alis_satis) ;
       --if n_fc_amount < 0 then raise e_hata; end if;
       IF p_tutar < 0 THEN n_fc_amount := -1*n_fc_amount; END IF;
    ELSIF p_kur_tablo = 'N' THEN
       n_fc_amount := DOVIZ_KARSILIK_NB(p_doviz_kod_1, p_doviz_kod_2, p_tarih, ABS(p_tutar), n_kur_tip,n_sabit_1,n_sabit_2,P_alis_satis) ;
       --if n_fc_amount < 0 then raise e_hata; end if;
       IF p_tutar < 0 THEN n_fc_amount := -1*n_fc_amount; END IF;
    ELSE
        RAISE e_kur_tablo_yok;
    END IF;
  ELSE
    n_lc_amount:=(p_kur_deger_1*p_tutar);
    n_fc_amount:=(n_lc_amount/p_kur_deger_2);
  END IF;

    IF v_kuruslu = 'H' THEN
       p_karsilik_tutar := ROUND (n_fc_amount,0) ;
    ELSE
       p_karsilik_tutar := ROUND (n_fc_amount,8);
    END IF;

    RETURN 1;

  EXCEPTION
    WHEN e_kur_tablo_yok THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '325' ||g_uc_delimiter);
      --return -2000176;
      WHEN NO_DATA_FOUND   THEN
         RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '327' ||g_uc_delimiter);
        --RETURN -2000185;
    /*
    --NEDEN HATA VERD???N? ARA?TIRACAM-TA
    when others  then
      if SQLCODE=-20100 then
             RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      else
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '326' ||g_uc_delimiter);
      end if;
       --return -2000177;
    */
  END;
 ------------------------------------------------------------------------------------------
  FUNCTION DOVIZ_DOVIZ_KARSILIK(  p_doviz_kod_1      VARCHAR2
                                , p_doviz_kod_2      VARCHAR2
                                , p_tarih            DATE     DEFAULT NULL
                                , p_tutar            NUMBER
                                , p_kur_tip          NUMBER   DEFAULT 3
                                , p_kur_deger_1      NUMBER   DEFAULT NULL
                                , p_kur_deger_2      NUMBER   DEFAULT NULL
                                , p_kur_tablo        VARCHAR2 DEFAULT 'O'
                                , p_alis_satis       VARCHAR2 DEFAULT 'A' ) RETURN NUMBER IS

  n_kur_tip       NUMBER;
  n_lc_amount          NUMBER;-- number(35,8);
  n_fc_amount          NUMBER;--number(35,8);
  n_sabit_1                NUMBER;
  n_sabit_2                NUMBER;
  v_kuruslu                VARCHAR2(1);
  e_hata          EXCEPTION;
  e_kur_tablo_yok EXCEPTION;

BEGIN

   IF NVL(P_TUTAR,0) = 0 THEN
      RETURN 0;
    END IF;

      -- kontrol the currency
      IF p_doviz_kod_1 = p_doviz_kod_2 THEN
      RETURN p_tutar;
      END IF;

      IF p_kur_tip IS NULL THEN n_kur_tip := c_kur_tip;
      ELSE n_kur_tip := p_kur_tip;
      END IF;

       -- the constant value for the crncy.. USD, DEM = 1    JPY, ITL = 100
      BEGIN
          SELECT    birim
          INTO        n_sabit_1
          FROM        CBS_DOVIZ_KODLARI
          WHERE        doviz_kodu = p_doviz_kod_1;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '328' || g_ara_delimiter|| NVL(p_doviz_kod_1,'null')||g_uc_delimiter);
               --return -2000186;
      END;

      BEGIN
        -- the constant value for the second crncy.. USD, DEM = 1    JPY, ITL = 100
        SELECT    birim, kuruslu_mu
        INTO        n_sabit_2, v_kuruslu
        FROM        CBS_DOVIZ_KODLARI
        WHERE        doviz_kodu = p_doviz_kod_2;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
                 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '329' || g_ara_delimiter || p_doviz_kod_2 ||g_uc_delimiter);
               --return -2000187;
      END;

      IF p_kur_deger_1 IS NULL AND p_kur_deger_2 IS NULL THEN
        IF p_kur_tablo = 'O' THEN
           n_fc_amount := doviz_karsilik(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_kur_tip,n_sabit_1,n_sabit_2,p_alis_satis) ;
        ELSIF p_kur_tablo = 'N' THEN
           n_fc_amount := doviz_karsilik_nb(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_kur_tip,n_sabit_1,n_sabit_2,p_alis_satis) ;
        ELSE
            RAISE e_kur_tablo_yok;
        END IF;
      ELSE

        n_lc_amount:=(p_kur_deger_1*p_tutar);
        n_fc_amount:=(n_lc_amount/p_kur_deger_2);
      END IF;


      IF v_kuruslu = 'H' THEN
         RETURN ROUND (n_fc_amount,0) ;
      ELSE
         RETURN ROUND (n_fc_amount,8);
      END IF;
 -- log_at('kur10',round(n_fc_amount,0),round(n_fc_amount,8));

EXCEPTION

  WHEN e_kur_tablo_yok THEN
       --return -2000188;
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '330' ||g_uc_delimiter);
  WHEN NO_DATA_FOUND   THEN
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '338' ||g_uc_delimiter);
       --return -2000190;
  --TA-DOVIZ_KARSILIK fonksiyonunda raise edilen hatay? aynen yukar? ??kartmak i?in eklendi
       /*
  when others then

       if SQLCODE=-20100 then
             RAISE_APPLICATION_ERROR(-20100,SQLERRM);
       else
             RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
         --return -2000000;
       end if;
      */
END;
 ------------------------------------------------------------------------------------------
-- B-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
  FUNCTION DOVIZ_DOVIZ_KARSILIK(  p_doviz_kod_1      VARCHAR2
                                , p_doviz_kod_2      VARCHAR2
                                , p_tarih            DATE     DEFAULT NULL
                                , p_tutar            NUMBER
                                , p_kur_tip          NUMBER   DEFAULT 3
                                , p_kur_deger_1      NUMBER   DEFAULT NULL
                                , p_kur_deger_2      NUMBER   DEFAULT NULL
                                , p_kur_tablo        VARCHAR2 DEFAULT 'O'
                                , p_alis_satis       VARCHAR2 DEFAULT 'A'
                                , p_branch              VARCHAR2 ) RETURN NUMBER IS

  n_kur_tip       NUMBER;
  n_lc_amount          NUMBER;-- number(35,8);
  n_fc_amount          NUMBER;--number(35,8);
  n_sabit_1                NUMBER;
  n_sabit_2                NUMBER;
  v_kuruslu                VARCHAR2(1);
  e_hata          EXCEPTION;
  e_kur_tablo_yok EXCEPTION;

BEGIN

   IF NVL(P_TUTAR,0) = 0 THEN
      RETURN 0;
    END IF;

      -- kontrol the currency
      IF p_doviz_kod_1 = p_doviz_kod_2 THEN
      RETURN p_tutar;
      END IF;

      IF p_kur_tip IS NULL THEN n_kur_tip := c_kur_tip;
      ELSE n_kur_tip := p_kur_tip;
      END IF;

       -- the constant value for the crncy.. USD, DEM = 1    JPY, ITL = 100
      BEGIN
          SELECT    birim
          INTO        n_sabit_1
          FROM        CBS_DOVIZ_KODLARI
          WHERE        doviz_kodu = p_doviz_kod_1;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '328' || g_ara_delimiter|| NVL(p_doviz_kod_1,'null')||g_uc_delimiter);
      END;

      BEGIN
        -- the constant value for the second crncy.. USD, DEM = 1    JPY, ITL = 100
        SELECT    birim, kuruslu_mu
        INTO        n_sabit_2, v_kuruslu
        FROM        CBS_DOVIZ_KODLARI
        WHERE        doviz_kodu = p_doviz_kod_2;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
                 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '329' || g_ara_delimiter || p_doviz_kod_2 ||g_uc_delimiter);
      END;

      IF p_kur_deger_1 IS NULL AND p_kur_deger_2 IS NULL THEN
        IF p_kur_tablo = 'O' THEN
           n_fc_amount := doviz_karsilik(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_kur_tip,n_sabit_1,n_sabit_2,p_alis_satis, p_branch) ;
           IF n_fc_amount = 0 THEN
                n_fc_amount := doviz_karsilik(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_kur_tip,n_sabit_1,n_sabit_2,p_alis_satis) ;
           END IF;
        ELSIF p_kur_tablo = 'N' THEN
           n_fc_amount := doviz_karsilik_nb(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_kur_tip,n_sabit_1,n_sabit_2,p_alis_satis) ;
        ELSE
            RAISE e_kur_tablo_yok;
        END IF;
      ELSE

        n_lc_amount:=(p_kur_deger_1*p_tutar);
        n_fc_amount:=(n_lc_amount/p_kur_deger_2);
      END IF;

      IF v_kuruslu = 'H' THEN
         RETURN ROUND (n_fc_amount,0) ;
      ELSE
         RETURN ROUND (n_fc_amount,8);
      END IF;

EXCEPTION
  WHEN e_kur_tablo_yok THEN
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '330' ||g_uc_delimiter);
  WHEN NO_DATA_FOUND   THEN
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '338' ||g_uc_delimiter);
END;
-- E-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches 
 
FUNCTION YUVARLA(p_doviz_kod VARCHAR2, p_tutar NUMBER) RETURN NUMBER IS
    v_kuruslu                VARCHAR2(1);
BEGIN
  SELECT    kuruslu_mu
    INTO    v_kuruslu
    FROM    CBS_DOVIZ_KODLARI
   WHERE    doviz_kodu = p_doviz_kod;

  IF v_kuruslu = 'H' THEN
      RETURN(ROUND(p_tutar,0));
  ELSE
      RETURN(ROUND(p_tutar,2));
  END IF;


END;

FUNCTION fun_truncate(ps_currency VARCHAR2, pn_amount NUMBER) RETURN NUMBER IS
    v_kuruslu                VARCHAR2(1);
BEGIN
  SELECT    kuruslu_mu
    INTO    v_kuruslu
    FROM    CBS_DOVIZ_KODLARI
   WHERE    doviz_kodu = ps_currency;

  IF v_kuruslu = 'H' THEN
      RETURN(TRUNC(pn_amount,0));
  ELSE
      RETURN(TRUNC(pn_amount,2));
  END IF;
END;
 ------------------------------------------------------------------------------------------
FUNCTION yeni_kur_kaydi_yarat RETURN NUMBER IS
  CURSOR c1 IS
      SELECT *   FROM CBS_KUR;
  r_c1     c1%ROWTYPE;
  p_banka_tarihi DATE;
BEGIN
  p_banka_tarihi:=TRUNC(Pkg_Muhasebe.banka_Tarihi_bul)+1;
  -- there must be always 1 record
  OPEN c1;
  LOOP
      FETCH c1 INTO r_c1;
      EXIT WHEN c1%NOTFOUND;
         INSERT INTO CBS_KURLOG (TARIH,
                                    DVZ,
                                    CARP,
                    DVZALIS,
                    DVZSATIS,
                    EFALIS,
                    EFSATIS,
                    ESALIS,
                    ESSATIS,
                    PARITE,
                    SIRALAMA)
             VALUES (p_banka_Tarihi,
                                    r_c1.DVZ,
                                    r_c1.CARP,
                    r_c1.DVZALIS,
                    r_c1.DVZSATIS,
                    r_c1.EFALIS,
                    r_c1.EFSATIS,
                    r_c1.ESALIS,
                    r_c1.ESSATIS,
                    r_c1.PARITE,
                    r_c1.SIRALAMA);
    END LOOP;
  CLOSE c1;
  RETURN 1;
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '333' ||g_uc_delimiter);
END;
 ------------------------------------------------------------------------------------------
FUNCTION yeni_nbkur_kaydi_yarat RETURN NUMBER IS
  CURSOR c1 IS
    SELECT *
      FROM CBS_MBKUR;

  r_c1                       c1%ROWTYPE;

  p_banka_tarihi DATE;
BEGIN
  p_banka_tarihi:=TRUNC(Pkg_Muhasebe.banka_Tarihi_bul)+1;
  -- there must be always 1 record
  OPEN c1;
  LOOP
      FETCH c1 INTO r_c1;
      EXIT WHEN c1%NOTFOUND;
         INSERT INTO CBS_MBKURLOG (TARIH,
                    DVZ        ,
                    DVZALIS    ,
                    DVZSATIS   ,
                    EFALIS     ,
                    EFSATIS    ,
                    ESALIS     ,
                    ESSATIS    ,
                    PARITE     ,
                    DVZAL_ORAN ,
                    DVZSAT_ORAN,
                    EFAL_ORAN  ,
                    EFSAT_ORAN ,
                    ESAL_ORAN  ,
                    ESSAT_ORAN ,
                    MBAL       ,
                    MBSAT

            ) VALUES (
                    p_banka_Tarihi,
                    r_C1.DVZ        ,
                    r_C1.DVZALIS    ,
                    r_C1.DVZSATIS   ,
                    r_C1.EFALIS     ,
                    r_C1.EFSATIS    ,
                    r_C1.ESALIS     ,
                    r_C1.ESSATIS    ,
                    r_C1.PARITE     ,
                    r_C1.DVZAL_ORAN ,
                    r_C1.DVZSAT_ORAN,
                    r_C1.EFAL_ORAN  ,
                    r_C1.EFSAT_ORAN ,
                    r_C1.ESAL_ORAN  ,
                    r_C1.ESSAT_ORAN ,
                    r_C1.MBAL       ,
                    r_C1.MBSAT
               );
    END LOOP;
  CLOSE c1;
  RETURN 1;
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '334' ||g_uc_delimiter);
END;

/*
return value;  > 0 => fixing rate , < 0 => error
______________________________________________________________________________________*/

------------------------------------------------------------------------------------------

FUNCTION fun_get_fixing_rate( ps_currency_code IN VARCHAR2 ) RETURN NUMBER IS

  CURSOR vc_kur IS
         SELECT d.birim, k.carp,k.esalis
           FROM CBS_KUR k,CBS_DOVIZ_KODLARI d
           WHERE k.dvz = ps_currency_code
             AND d.doviz_kodu = k.dvz;
  vr_kur vc_kur%ROWTYPE;
BEGIN

   OPEN vc_kur;
   FETCH vc_kur INTO vr_kur;
   IF vc_kur%NOTFOUND THEN
      CLOSE vc_kur;
      --pkg_hata_kontrol.parametre_deger(1,ps_currency_code); pkg_hata_kontrol.parametre_deger(1,'pkg_kur.fun_get_fixing_rate');pkg_hata_kontrol.push(-5030);
      RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '335' ||g_uc_delimiter);
      --return -5030; -- Currency code or rate definition undefined. Currency :%%1 %%2
   END IF;
   CLOSE vc_kur;

   IF vr_kur.carp = 'E' THEN
      RETURN vr_kur.esalis * NVL(vr_kur.birim,1);
   ELSE
      RETURN vr_kur.esalis / NVL(vr_kur.birim,1);
   END IF;

EXCEPTION

  WHEN OTHERS THEN
        --pkg_hata_kontrol.parametre_deger( 1, sqlerrm );
        --pkg_hata_kontrol.parametre_deger( 2, 'pkg_kur.fun_get_fixing_rate ( ps_currency_code => '||ps_currency_code );
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
        --return -2000000;
END;
---------------------------------------------------------------------------------------------------------------
FUNCTION fun_validate_fixing_rate( ps_currency_code IN VARCHAR2, pn_rate IN NUMBER ) RETURN NUMBER IS

  CURSOR vc_kur IS
         SELECT k.dvzalis, k.dvzsatis
           FROM CBS_KUR k
           WHERE k.dvz = ps_currency_code;

  vr_kur vc_kur%ROWTYPE;

BEGIN

   OPEN vc_kur;
   FETCH vc_kur INTO vr_kur;
   IF vc_kur%NOTFOUND THEN
      CLOSE vc_kur;
      --pkg_hata_kontrol.parametre_deger(1,ps_currency_code); pkg_hata_kontrol.parametre_deger(1,'pkg_kur.fun_validate_fixing_rate');pkg_hata_kontrol.push(-5030);
      RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '336' ||g_uc_delimiter);
      --return -5030; -- Currency code or rate definition undefined. Currency :%%1 %%2
   END IF;
   CLOSE vc_kur;


   IF pn_rate < vr_kur.dvzalis OR pn_rate > vr_kur.dvzsatis THEN
      --pkg_hata_kontrol.parametre_deger(1, pn_rate );
      --pkg_hata_kontrol.parametre_deger(2, vr_kur.dvzalis || ' - ' || vr_kur.dvzsatis );pkg_hata_kontrol.parametre_deger(3,'pkg_kur.fun_validate_fixing_rate');
      RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '337' ||g_uc_delimiter);
      --return -5031 ; -- Fixing rate : %%1 must be between bank note bid rate and offer rate : %%2 ( %%3 )
   END IF;

   RETURN 1;

EXCEPTION

  WHEN OTHERS THEN
        --pkg_hata_kontrol.parametre_deger( 1, sqlerrm );
        --pkg_hata_kontrol.parametre_deger( 2, 'pkg_kur.fun_validate_fixing_rate -- exception when others');
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
        --return -2000000;

END;

---------------------------------------------------------------------------------------------------------------
FUNCTION fun_get_fixing_rate( ps_currency_code1 IN VARCHAR2, ps_currency_code2 IN VARCHAR2 ) RETURN NUMBER IS

  vn_rate1       NUMBER;
  vn_rate2       NUMBER;

BEGIN

   -- for first currency code
   vn_rate1 := Pkg_Kur.fun_get_fixing_rate( ps_currency_code1 );
   IF vn_rate1 < 0 THEN RETURN vn_rate1; END IF;

   -- for second currency code
   vn_rate2 := Pkg_Kur.fun_get_fixing_rate( ps_currency_code2 );
   IF vn_rate2 < 0 THEN RETURN vn_rate2; END IF;

   -- result
   RETURN vn_rate1 / vn_rate2;

EXCEPTION

  WHEN OTHERS THEN
        --pkg_hata_kontrol.parametre_deger( 1, sqlerrm );
        --pkg_hata_kontrol.parametre_deger( 2, 'pkg_kur.fun_get_fixing_rate ( ps_currency_code1 => '||ps_currency_code1||', ps_currency_code2 => ' || ps_currency_code2 );
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
        --return -2000000;
END;

---------------------------------------------------------------------------------------------------------------
FUNCTION fun_validate_fixing_rate( ps_currency_code1 IN VARCHAR2, ps_currency_code2 IN VARCHAR2, pn_rate IN NUMBER ) RETURN NUMBER IS

  CURSOR vc_kur(vs_currency_code VARCHAR2) IS
         SELECT k.dvzalis, k.dvzsatis
           FROM CBS_KUR k
           WHERE k.dvz = vs_currency_code;

  vn_dvzalis1    NUMBER;
  vn_dvzalis2    NUMBER;
  vn_dvzsatis1   NUMBER;
  vn_dvzsatis2   NUMBER;
  vn_dvzalis     NUMBER;
  vn_dvzsatis    NUMBER;
  e_norec       EXCEPTION;
BEGIN

   OPEN vc_kur(ps_currency_code1);
   FETCH vc_kur INTO vn_dvzalis1, vn_dvzsatis1;
   IF vc_kur%NOTFOUND THEN
      CLOSE vc_kur;
      --pkg_hata_kontrol.parametre_deger(1,ps_currency_code1);
      RAISE e_norec;
   END IF;
   CLOSE vc_kur;

   OPEN vc_kur(ps_currency_code2);
   FETCH vc_kur INTO vn_dvzalis2, vn_dvzsatis2;
   IF vc_kur%NOTFOUND THEN
      CLOSE vc_kur;
      --pkg_hata_kontrol.parametre_deger(1,ps_currency_code2);
      RAISE e_norec;
   END IF;
   CLOSE vc_kur;

   vn_dvzalis  := vn_dvzalis1  / vn_dvzalis2;
   vn_dvzsatis := vn_dvzsatis1 / vn_dvzsatis2;

   IF ( vn_dvzalis < vn_dvzsatis AND (pn_rate < vn_dvzalis OR pn_rate > vn_dvzsatis)) OR
      ( vn_dvzalis > vn_dvzsatis AND (pn_rate > vn_dvzalis OR pn_rate < vn_dvzsatis)) OR
      ( vn_dvzalis = vn_dvzsatis AND pn_rate = vn_dvzalis ) THEN
      --pkg_hata_kontrol.parametre_deger(1, pn_rate );
      --pkg_hata_kontrol.parametre_deger(2, vn_dvzalis || ' - ' || vn_dvzsatis );
      --pkg_hata_kontrol.parametre_deger(3,'pkg_kur.fun_validate_fixing_rate (for 2 cy)');
      RETURN -5031 ; -- Fixing rate : %%1 must be between bid rate and offer rate : %%2 ( %%3 )
   END IF;

   RETURN 1;

EXCEPTION

  WHEN e_norec THEN
       --pkg_hata_kontrol.parametre_deger(2,'pkg_kur.fun_validate_fixing_rate(for 2 cy)');
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '336' ||g_uc_delimiter);
       --return -5030; -- Currency code or rate definition undefined. Currency :%%1 %%2
  WHEN OTHERS THEN
       --pkg_hata_kontrol.parametre_deger( 1, sqlerrm );
       --pkg_hata_kontrol.parametre_deger( 2, 'pkg_kur.fun_validate_fixing_rate(for 2 cy) -- exception when others');
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
       --return -2000000;

END;
/*****************************************************************************/
 FUNCTION DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
                                                        Pkg_Genel.lc_al,
                                                        NULL,
                                                        pn_tutar,
                                                        1,
                                                        NULL,
                                                        NULL,
                                                        'O',
                                                        'A')
                            ));
 END;
/*****************************************************************************/
 FUNCTION EAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
                                                        Pkg_Genel.lc_al,
                                                        NULL,
                                                        pn_tutar,
                                                        2,
                                                        NULL,
                                                        NULL,
                                                        'O',
                                                        'S')
                            ));
 END;
/*****************************************************************************/
 FUNCTION DSK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
                                                        Pkg_Genel.lc_al,
                                                        NULL,
                                                        pn_tutar,
                                                        1,
                                                        NULL,
                                                        NULL,
                                                        'O',
                                                        'S')
                            ));
 END;
/*****************************************************************************/
 FUNCTION ESK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
                                                        Pkg_Genel.lc_al,
                                                        NULL,
                                                        pn_tutar,
                                                        2,
                                                        NULL,
                                                        NULL,
                                                        'O',
                                                        'S')
                            ));
 END;
/*****************************************************************************/

FUNCTION MB_DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
                                                        Pkg_Genel.lc_al,
                                                        NULL,
                                                        pn_tutar,
                                                        1,
                                                        NULL,
                                                        NULL,
                                                        'N',
                                                        'A')
                            ));
 END;


END;
/

