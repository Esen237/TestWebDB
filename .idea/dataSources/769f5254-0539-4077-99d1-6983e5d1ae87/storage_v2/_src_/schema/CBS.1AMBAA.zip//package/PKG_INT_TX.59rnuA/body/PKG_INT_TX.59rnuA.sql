create PACKAGE BODY     pkg_int_tx IS

SOURCE_PATH    VARCHAR2(100);
DESTINATION_PATH  VARCHAR2(100);
---------------------------------------------------------------------------------------
FUNCTION GetWaitTxToDo (ps_option      VARCHAR2,
                        ps_txno        VARCHAR2,
                        ps_channelcd   VARCHAR2,
                        ps_customerid  VARCHAR2,
                        ps_personid    VARCHAR2,
                        ps_startdate   VARCHAR2,
                        ps_enddate    VARCHAR2,
                        ps_statuscd    VARCHAR2,
                        ps_payeename     VARCHAR2,--ernestk 23062014 cqdb864 sort by payee
                        ps_from_amount   VARCHAR2,--ernestk 23062014 cqdb864 sort by amount from
                        ps_to_amount     VARCHAR2,--ernestk 23062014 cqdb864 sort by amount to
                        ps_makerid     VARCHAR2,

                        pc_ref   OUT   CursorReferenceType)  RETURN VARCHAR2  IS

      ls_returncode       VARCHAR2 (3):= '000';
      ln_count            NUMBER:=0;
      ls_option           VARCHAR2 (10):='sWAIT';
      ln_tax_rate         NUMBER;
      ls_filterAll       VARCHAR2(1) :='H';
     --ld_date1              date;
      ld_date2             date;


      END_HH24 NUMBER;
      END_MM NUMBER;
      END_HH24_GR NUMBER;
      END_MM_GR NUMBER;
      END_HH24_CL NUMBER;
      END_MM_CL NUMBER;
      HH24_SYS NUMBER;
      MM_SYS NUMBER;
      ln_gr_time VARCHAR2 (10);
      ln_cr_time VARCHAR2 (10);
      
BEGIN
 ls_option := ps_option;


   IF ps_txno='ALL' THEN
      ls_filterAll := 'E';
   END IF;
   begin
       select to_number(replace(DEGER,'.',',')) into ln_tax_rate
       from cbs_parametre
       where kod='G_SALES_TAX_RATE'
       and rownum=1;
   exception
       when others then
           begin
               select to_number(replace(DEGER,',','.')) into ln_tax_rate
               from cbs_parametre
               where kod='G_SALES_TAX_RATE'
               and rownum=1;
           exception
               when others then
                   ln_tax_rate:=0;
           end;
   end;

--Andrei CBS-309

  UPDATE TBL_TXTODO T
  SET T.STATUS='sEXPIRED'
  WHERE TO_DATE(FIELD3,'YYYYMMDD') < ld_date2 - 30
  AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
  AND TRANCD IN ('CLEARING', 'GROSS')
  AND t.STATUS='sNAPPROVED';

--ld_date1:=TO_DATE(FIELD3,'YYYYMMDD');


 UPDATE TBL_TXTODO T
  SET T.STATUS='sEXPIRED'
  WHERE TO_DATE(FIELD3,'YYYYMMDD') < ld_date2
  AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
  AND TRANCD IN ('CLEARING', 'GROSS')
  AND t.STATUS='sAPPROVE';
  
  
--  log_at('check1',0,ls_option);
 
 /* 
   --IF ls_option='sAPPROVE' THEN
  
  log_at('check1',1,'ls_option'||ls_option);
  
   SELECT end_hh24, end_mm
      INTO end_hh24_gr, end_mm_gr
       FROM cbs_int_time
    WHERE tran_cd='GROSS';
    
  log_at('check1',2,'end_hh24_gr'||end_hh24_gr||'  '||'end_mm_gr'|| end_mm_gr);
    
    SELECT end_hh24_cl, end_mm_cl
      INTO end_hh24_cl, end_mm_cl
       FROM CBS_INT_TIME
    WHERE TRAN_CD='CLEARING';
    
  log_at('check1',3,'end_hh24_cl'||end_hh24_cl||'  '||'end_mm_cl'|| end_mm_cl);
     
   ln_gr_time:=TO_CHAR(end_hh24_gr,'00') || TO_CHAR(end_mm_gr,'00');
   ln_cr_time:=TO_CHAR(end_hh24_cl,'00') || TO_CHAR(end_mm_cl,'00');
   
  log_at('check1',4.0,'ln_gr_time'||ln_gr_time||' '||'ln_cr_time'||ln_cr_time);
  
 log_at('check1',4,'systime'||TO_DATE(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')||'  '||'gross time'|| TO_DATE(ln_gr_time,'hh24:mi'));
   
 
  IF TO_DATE(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')>TO_DATE(TO_CHAR(ln_gr_time),'hh24:mi')  THEN
      
 log_at('check1',4.1);
     
     UPDATE TBL_TXTODO T
      SET T.STATUS='sEXPIRED'
      WHERE T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
      AND TRANCD IN ('GROSS')
      AND t.STATUS='sAPPROVE'; 
  
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER|| '20136' || Pkg_Hata.getUCPOINTER);

    END IF;
    
     log_at('check1',5,'systime'||TO_DATE(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')||'  '||'clearing time'|| TO_DATE(ln_cr_time,'hh24:mi'));
    IF TO_DATE(TO_CHAR(SYSDATE,'hh24:mi'),'hh24:mi')>TO_DATE(TO_CHAR(ln_cr_time),'hh24:mi')  THEN
     
  log_at('check1',5.1);
     
     UPDATE TBL_TXTODO T
      SET T.STATUS='sEXPIRED'
      WHERE T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
      AND TRANCD IN ('CLEARING')
      AND t.STATUS='sAPPROVE';
        
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '20135' || Pkg_Hata.getUCPOINTER);
     
    END IF;
    
  log_at('check1',6);
  
 
  
 -- END IF;
  
*/



 IF ls_option='sDELETE' THEN

    ls_returncode:= MakeWaitTxToDo(ps_option, ps_txno, ps_channelcd, ps_customerid, ps_personid, pc_ref);


    ls_option := 'sWAIT';
    ls_filterAll := 'E';

 END IF;

 IF ls_option='sWAIT' THEN



  UPDATE TBL_TXTODO T
  SET T.STATUS='sNAPPROVED'
  WHERE TO_DATE(FIELD3,'YYYYMMDD') < ld_date2
  AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
  AND TRANCD IN ('CLEARING', 'GROSS')
  AND t.STATUS  IN ('sVERIFY','sCHECK','sAPPROVE');



    SELECT END_HH24, END_MM
    INTO END_HH24, END_MM
    FROM CBS_INT_TIME
    WHERE TRAN_CD='SWIFT';

  IF TO_NUMBER(ps_makerid) IS NULL THEN





  OPEN pc_ref FOR
    SELECT
    t.TX_NO,--0
    t.STATUS,--t.AUTHCD,
    r.DEFINITION,--2
    t.TRANCD,--3
    DECODE(T.TRANCD,/*ChyngyzO cq4960 28.12.1*/'SALARY',  TO_CHAR(TO_DATE(t.FIELD11, 'DD/MM/YYYY'), 'YYYYMMDD') , 'CARDEBT', FIELD3, 'CLEARING',FIELD3,'GROSS', FIELD3, 'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3,  'SWIFT', TO_CHAR(MAKEDATE, 'YYYYMMDD'), DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE, --chyngyzo cq509 12/03/15 added SWIFT
    LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'GROSS', FIELD9, 'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3, 'CARDDEBT', FIELD9, 'PAYMENTS', FIELD9, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD2, 0), ' '),'0') AMOUNT,
       DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,'CARDDEBT', FIELD20,'PAYMENTS', FIELD20, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD3, 0), ' ')CURRENCY,
       DECODE(T.TRANCD,'PAYMORD',FIELD7,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'GROSS',FIELD7,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ','CARDDEBT', FIELD8, ' ')PAYEE_NAME,
       DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
    NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' '),
    NVL(t.MAKERID,' '),
    NVL(Pkg_Customer.GetPersonName(t.MAKERID),' '),
    NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
    NVL(t.VERIFYID,' '),
    NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
    NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
    NVL(t.CHECKID,' '),
    NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
    NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
    NVL(t.APPROVALID,' '),
    NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
    NVL(t.FIELD1,' '),
    NVL(t.FIELD2,' '),
    case when (TRANCD IN ('CLEARING', 'GROSS')) then to_char(TO_DATE(t.FIELD3,'YYYYMMDD') - Pkg_Muhasebe.Banka_Tarihi_Bul + 30) else NVL(t.FIELD3,' ') end,
   NVL(t.FIELD4,' '), --chyngyzo cq509 12/03/15
    --case when (TO_NUMBER(TO_CHAR(SYSDATE, 'HH24MI')) >= END_HH24*100+END_MM) AND (t.TRANCD = 'SWIFT') then to_char(PKG_TARIH.ILERI_IS_GUNU(to_date(t.FIELD5,'YYYYMMDD')),'YYYYMMDD') else NVL(t.FIELD5,' ') end,
    DECODE(T.TRANCD,'SWIFT', TO_CHAR(TO_DATE(t.FIELD5, 'DD/MM/YYYY'), 'YYYYMMDD'),  NVL(t.FIELD5,' ')),  --chyngyzo cq509 12/03/15
    NVL(t.FIELD6,' '),
    NVL(t.FIELD7,' '),
    NVL(t.FIELD8,' '),
    NVL(t.FIELD9,' '),
    NVL(t.FIELD10,' '),
    NVL(t.FIELD11,' '),
    NVL(t.FIELD12,' '),
    DECODE(T.TRANCD, 'SWIFT', NVL(t.FIELD13,' ') || '###' || (SELECT BANKA_ADI FROM CBS_BIC_KODLARI WHERE BIC_KODU=NVL(t.FIELD13,' ')), NVL(t.FIELD13,' ')),
    NVL(t.FIELD14,' '),
    NVL(t.FIELD15,' '),
    NVL(t.FIELD16,' '),
    NVL(t.FIELD17,' '),
    NVL(t.FIELD18,' '),
    NVL(t.FIELD19,' '),
    NVL(t.FIELD20,' '),
    DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10,'GROSS', FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || FIELD4 || ', ' || FIELD2, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD7, ' '),' ') EXPLANATION,
    (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
    (TO_CHAR(APPROVALDATE,'HH24:MI:SS')),
    TO_NUMBER(nvl(ltrim(pkg_message.SPLIT(t.FIELD19,'###',0),'0'),'0'),'999999999999999.9999')*ln_tax_rate/100,
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',0) ), ''),
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',1) ), ''),
    NVL((select uae.STAT_CODE from CORPINT.TBL_TXTODO_UAE_DETAILS uae where uae.TX_NO=T.TX_NO),' '),--BAKDOOLOT ibc-52 26.03.22
    NVL(t.FIELD21,' ') --Esen ibc-74 01.04.22
   FROM
     TBL_TXTODO T, corpint.TBL_TRANSACTION R, TBL_PERSON_APPROVAL A
   WHERE A.AUTH_CD= T.AUTHCD AND
      T.TRANCD = r.TRAN_CD  AND
      R.LANGUAGE_CD = 'ENG' AND

        A.PERSON_ID = TO_NUMBER(ps_personid) AND
      T.CUSTOMER_ID=TO_NUMBER(ps_customerID) AND
      t.STATUS IN ('sAPPROVE','sCHECK','sVERIFY') AND
      A.CHANNEL_CD = ps_channelcd  AND
	  (ls_filterAll='E' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) )
        --INSTR(DECODE(to_char(ls_txno),'ALL',',' || TO_CHAR(t.TX_NO) || ',',to_char(ls_txno)), ',' || TO_CHAR(t.TX_NO) || ',')>0

        AND( 
            (T.TRANCD in ('B2OBHVL','GROSS','FXSPARBTRG','CLEARING','B2BHVL','SALARY','TAXPAYMENT','ARBITRAGE','CARDDEBT')
                AND t.FIELD1 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD in ('FXSPECBUY','EXCHNGBUY','FXSPECSELL','CLEARCNCL' ,'EXCHNGSELL') 
                AND t.FIELD2 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD = 'SWIFT' 
                AND regexp_substr(t.FIELD12, '[^#]+', 1, 1) not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD = 'PAYMENTS'
                AND t.FIELD10 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            )
      ORDER BY T.TX_NO;


  ELSE


   OPEN pc_ref FOR
   SELECT
    t.TX_NO,--0
    t.STATUS,--t.AUTHCD,
    r.DEFINITION,--2
    t.TRANCD,--3
    DECODE(T.TRANCD, /*ChyngyzO cq4960 28.12.1*/'SALARY',   TO_CHAR(TO_DATE(t.FIELD11, 'DD/MM/YYYY'), 'YYYYMMDD'), 'CARDDEBT', FIELD3, 'CLEARING',FIELD3,'GROSS',FIELD3,'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3, 'SWIFT', TO_CHAR(MAKEDATE, 'YYYYMMDD'), DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE, --chyngyzo cq509 12/03/15 added SWIFT
    LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'GROSS',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3, 'CARDDEBT', FIELD9,'PAYMENTS', FIELD9, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD2, 0),' '),'0') AMOUNT,
       DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5, 'CARDDEBT', FIELD20,'PAYMENTS', FIELD20, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD3, 0),' ')CURRENCY,
       DECODE(T.TRANCD,'PAYMORD',FIELD7,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'CLEARING',FIELD7,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ', 'CARDDEBT', FIELD8,' ')PAYEE_NAME,
       DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
    NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' '),
    NVL(t.MAKERID,' '),
    NVL(Pkg_Customer.GetPersonName(t.MAKERID),' '),
    NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
    NVL(t.VERIFYID,' '),
    NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
    NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
    NVL(t.CHECKID,' '),
    NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
    NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
    NVL(t.APPROVALID,' '),
    NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
    NVL(t.FIELD1,' '),
    NVL(t.FIELD2,' '),
    case when (TRANCD IN ('CLEARING', 'GROSS')) then to_char(TO_DATE(t.FIELD3,'YYYYMMDD') - Pkg_Muhasebe.Banka_Tarihi_Bul + 30) else NVL(t.FIELD3,' ') end,
    NVL(t.FIELD4,' '),
    DECODE(T.TRANCD,'SWIFT', TO_CHAR(TO_DATE(t.FIELD5, 'DD/MM/YYYY'), 'YYYYMMDD'),  NVL(t.FIELD5,' ')),--cq509 chyngyzo
    NVL(t.FIELD6,' '),
    NVL(t.FIELD7,' '),
    NVL(t.FIELD8,' '),
    NVL(t.FIELD9,' '),
    NVL(t.FIELD10,' '),
    NVL(t.FIELD11,' '),
    NVL(t.FIELD12,' '),
    NVL(t.FIELD13,' '),
    NVL(t.FIELD14,' '),
    NVL(t.FIELD15,' '),
    NVL(t.FIELD16,' '),
    NVL(t.FIELD17,' '),
    NVL(t.FIELD18,' '),
    NVL(t.FIELD19,' '),
    NVL(t.FIELD20,' '),
    DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10, 'GROSS', FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10, 'PAYMENTS', FIELD5 || ', ' || decode(field8, null, '', field8||'-')||FIELD4 || ', ' || FIELD2, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD7, ' '),' ') EXPLANATION, --chyngyzo cq4820 16/09/2015 payments part changed
    (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
    (TO_CHAR(APPROVALDATE,'HH24:MI:SS')),
    TO_NUMBER(nvl(ltrim(pkg_message.SPLIT(t.FIELD19,'###',0),'0'),'0'),'999999999999999.9999')*ln_tax_rate/100,
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',0) ), ''),
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',1) ), ''),
    NVL((select uae.STAT_CODE from CORPINT.TBL_TXTODO_UAE_DETAILS uae where uae.TX_NO=T.TX_NO),' ')--BAKDOOLOT ibc-52 26.03.22
   FROM
     TBL_TXTODO T, corpint.TBL_TRANSACTION R, TBL_PERSON_APPROVAL A
   WHERE A.AUTH_CD= T.AUTHCD AND
      T.TRANCD = r.TRAN_CD  AND
      R.LANGUAGE_CD = 'ENG' AND

        A.PERSON_ID = TO_NUMBER(ps_personid) AND
      T.MAKERID = TO_NUMBER(ps_makerid) AND
      T.CUSTOMER_ID=TO_NUMBER(ps_customerID) AND
      t.STATUS IN ('sAPPROVE','sCHECK','sVERIFY') AND
      A.CHANNEL_CD = ps_channelcd  AND
	  (ls_filterAll='E' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) )
      --  INSTR(DECODE(to_char(ls_txno),'ALL',',' || TO_CHAR(t.TX_NO) || ',',to_char(ls_txno)), ',' || TO_CHAR(t.TX_NO) || ',')>0
      -- MODIFIED BY NURSULTAN MUKHAMBET UULU---IBC-111
        AND( 
            (T.TRANCD in ('B2OBHVL','GROSS','FXSPARBTRG','CLEARING','B2BHVL','SALARY','TAXPAYMENT','ARBITRAGE','CARDDEBT')
                AND t.FIELD1 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD in ('FXSPECBUY','EXCHNGBUY','FXSPECSELL','CLEARCNCL' ,'EXCHNGSELL') 
                AND t.FIELD2 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD = 'SWIFT' 
                AND regexp_substr(t.FIELD12, '[^#]+', 1, 1) not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            OR(T.TRANCD = 'PAYMENTS'
                AND t.FIELD10 not in (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = TO_NUMBER(ps_personid)))
            )  
        --IBC-111 -- END
      ORDER BY T.TX_NO;


  END IF;

 ELSIF ls_option='sVIEW' THEN
  BEGIN


    OPEN pc_ref FOR
      SELECT
    t.TX_NO,--0
    t.STATUS,--t.AUTHCD,
    r.DEFINITION,--2
    t.TRANCD,--3
    DECODE(T.TRANCD,/*ChyngyzO cq4960 28.12.1*/'SALARY',   TO_CHAR(TO_DATE(t.FIELD11, 'DD/MM/YYYY'), 'YYYYMMDD'), 'CARDDEBT', FIELD3, 'CLEARING',FIELD3,'GROSS', FIELD3, 'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3, 'SWIFT', TO_CHAR(MAKEDATE, 'YYYYMMDD'), DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE, --chyngyzo cq509 12/03/15 added SWIFT
    LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'PORDCNCL',FIELD6,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'GROSS', FIELD9, 'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3, 'CARDDEBT', FIELD9, 'PAYMENTS', FIELD9,/*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD2, 0),' '),'0') AMOUNT,
       DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'PORDCNCL',FIELD7,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','GROSS', 'KGS', 'EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5, 'CARDDEBT', FIELD20, 'PAYMENTS', FIELD20, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD3, 0),' ') CURRENCY, --chyngyzo cq4820 16/09/2015 payments part changed
       DECODE(T.TRANCD,'PAYMORD',FIELD7,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'GROSS', FIELD7, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ', 'CARDDEBT', FIELD8,' ') PAYEE_NAME,
       DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
    NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' '),
    NVL(t.MAKERID,' '),
    NVL(Pkg_Customer.GetPersonName(t.MAKERID),' '),
    NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
    NVL(t.VERIFYID,' '),
    NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
    NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
    NVL(t.CHECKID,' '),
    NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
    NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
    NVL(t.APPROVALID,' '),
    NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
    NVL(t.FIELD1,' '),
    NVL(t.FIELD2,' '),
    case when (TRANCD IN ('CLEARING', 'GROSS')) then to_char(TO_DATE(t.FIELD3,'YYYYMMDD') - Pkg_Muhasebe.Banka_Tarihi_Bul + 30) else NVL(t.FIELD3,' ') end,
    NVL(t.FIELD4,' '),
    DECODE(T.TRANCD,'SWIFT', TO_CHAR(TO_DATE(t.FIELD5, 'DD/MM/YYYY'), 'YYYYMMDD'),  NVL(t.FIELD5,' ')),
    NVL(t.FIELD6,' '),
    NVL(t.FIELD7,' '),
    NVL(t.FIELD8,' '),
    NVL(t.FIELD9,' '),
    NVL(t.FIELD10,' '),
    NVL(t.FIELD11,' '),
    NVL(t.FIELD12,' '),
    NVL(t.FIELD13,' '),
    NVL(t.FIELD14,' '),
    NVL(t.FIELD15,' '),
    NVL(t.FIELD16,' '),
    NVL(t.FIELD17,' '),
    NVL(t.FIELD18,' '),
    NVL(t.FIELD19,' '),
    NVL(t.FIELD20,' '),
    DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING', FIELD10, 'GROSS', FIELD10, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4, 'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || decode(field8, null, '', field8||'-')|| FIELD4 || ', ' || FIELD2, /*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD7, ' '),' ') EXPLANATION, --chyngyzo cq4820 16/09/2015 payments part changed
    (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
    (TO_CHAR(APPROVALDATE,'HH24:MI:SS')),
    TO_NUMBER(nvl(ltrim(pkg_message.SPLIT(t.FIELD19,'###',0),'0'),'0'),'999999999999999.9999')*ln_tax_rate/100,
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',0) ), ''),
    DECODE(t.TRANCD, 'SWIFT', pkg_hesap.External_HesapNo_Al( pkg_message.SPLIT(t.FIELD12,'###',1) ), ''),
    NVL((select uae.STAT_CODE from CORPINT.TBL_TXTODO_UAE_DETAILS uae where uae.TX_NO=t.TX_NO),' '),--BAKDOOLOT ibc-52 02.03.22
    NVL(t.FIELD21,' ') --Esen ibc-74 01.04.22
   FROM
     TBL_TXTODO t, corpint.TBL_TRANSACTION R
   WHERE T.TRANCD = r.TRAN_CD  AND
      R.LANGUAGE_CD = 'ENG' AND

        T.CUSTOMER_ID=TO_NUMBER(ps_customerID) AND
      (
       (TO_NUMBER(ps_personid)=T.MAKERID) OR (TO_NUMBER(ps_personid) IN (SELECT A.PERSON_ID FROM TBL_PERSON_APPROVAL A
                 WHERE A.CHANNEL_CD=ps_channelcd AND SUBSTR(A.AUTH_CD,6)=SUBSTR(t.AUTHCD,6)))
      ) AND
      t.STATUS IN DECODE(ps_statuscd,'ALL',t.STATUS,ps_statuscd) AND
      t.MAKEDATE>=TRUNC(TO_DATE(ps_startdate,'YYYYMMDD')) AND
      t.MAKEDATE<TRUNC(TO_DATE(ps_enddate,'YYYYMMDD'))+1 AND
	   (ls_filterAll='E' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) ) AND
      --INSTR(DECODE(to_char(ls_txno),'ALL',',' || TO_CHAR(TX_NO) || ',',to_char(ls_txno)), ',' || TO_CHAR(TX_NO) || ',')>0 AND -- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
      DECODE(T.TRANCD,'PAYMORD',FIELD7,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'GROSS', FIELD7, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ', 'CARDDEBT', FIELD8,' ')-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
            like decode(ps_payeename, '',  DECODE(T.TRANCD,'PAYMORD',FIELD7,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'GROSS', FIELD7, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ', 'CARDDEBT', FIELD8,' '), '%' || ps_payeename || '%')-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
     --       AND-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
     -- to_number(LTRIM(DECODE(T.TRANCD,'P2OCARD',nvl(FIELD9, 0),'ARBITRAGE',nvl(FIELD7, 0),'CNCLFXORD',nvl(FIELD7, 0),'FXORDER',nvl(FIELD9, 0),'SALPAYTBL',nvl(FIELD9, 0),'PORDCNCL',nvl(FIELD6, 0),'SWIFT',nvl(FIELD9, 0),'SALARYPAY',nvl(FIELD9, 0),'CARDPYM',nvl(FIELD9, 0),'CLEARPENS',nvl(FIELD9, 0),'CLEARCNCL',nvl(FIELD9, 0),'UTILPAY',nvl(FIELD5, 0),'B2OBHVL',nvl(FIELD3, 0),'CLEARING',nvl(FIELD9, 0),'GROSS', nvl(FIELD9, 0), 'EXCHNGBUY',nvl(FIELD9, 0),'EXCHNGSELL',nvl(FIELD9, 0),'B2BHVL',nvl(FIELD3, 0), 'CARDDEBT', nvl(FIELD9, 0),'PAYMENTS', nvl(FIELD9, 0),/*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD2, 0),' '),'0'), '999999999999.9999') <= to_number(decode(ps_to_amount, '', '9999999999999.99', ps_to_amount)) AND-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
     -- to_number(LTRIM(DECODE(T.TRANCD,'P2OCARD',nvl(FIELD9, 0),'ARBITRAGE',nvl(FIELD7, 0),'CNCLFXORD',nvl(FIELD7, 0),'FXORDER',nvl(FIELD9, 0),'SALPAYTBL',nvl(FIELD9, 0),'PORDCNCL',nvl(FIELD6, 0),'SWIFT',nvl(FIELD9, 0),'SALARYPAY',nvl(FIELD9, 0),'CARDPYM',nvl(FIELD9, 0),'CLEARPENS',nvl(FIELD9, 0),'CLEARCNCL',nvl(FIELD9, 0),'UTILPAY',nvl(FIELD5, 0),'B2OBHVL',nvl(FIELD3, 0),'CLEARING',nvl(FIELD9, 0),'GROSS', nvl(FIELD9, 0), 'EXCHNGBUY',nvl(FIELD9, 0),'EXCHNGSELL',nvl(FIELD9, 0),'B2BHVL',nvl(FIELD3, 0), 'CARDDEBT', nvl(FIELD9, 0),'PAYMENTS', nvl(FIELD9, 0),/*ChyngyzO cq4960 28.12.1*/'SALARY', nvl(FIELD2, 0),' '),'0'), '999999999999.9999') >= to_number(decode(ps_from_amount, '', '0', ps_from_amount))-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
      ORDER BY t.TX_NO;
   EXCEPTION
    WHEN NO_DATA_FOUND THEN
       LOG_AT('GetWaitTxToDo',SQLERRM);
   END;
 ELSIF ls_option IN ('sCONTROL','sCONTROLVIEW') THEN

  UPDATE TBL_TXTODO T
  SET T.STATUS='sNAPPROVED'
  WHERE TO_DATE(FIELD3,'YYYYMMDD') < Pkg_Muhasebe.Banka_Tarihi_Bul
  AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
  AND TRANCD in ('CLEARING','GROSS')
  AND t.STATUS  IN ('sVERIFY','sCHECK','sAPPROVE');

     OPEN pc_ref FOR
      SELECT
    t.TX_NO,--0
    t.STATUS,--t.AUTHCD,
    r.DEFINITION,--2
    t.TRANCD,--3
    DECODE(T.TRANCD,'CARDDEBT', FIELD3, 'CLEARING',FIELD3, 'GROSS', FIELD3,'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3,DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE,
    LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'PORDCNCL',FIELD6,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'GROSS', FIELD9, 'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,'CARDDEBT', FIELD9,'PAYMENTS', FIELD9, ' '),'0') AMOUNT,
       DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'PORDCNCL',FIELD7,'PAYMORD',FIELD7,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS', 'GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5, 'CARDDEBT', FIELD20, 'PAYMENTS', FIELD20, ' ')CURRENCY,
       DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7,'GROSS', FIELD7, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ', 'CARDDEBT', FIELD8,' ')PAYEE_NAME,
       DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
    NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' '),
    NVL(t.MAKERID,' '),
    NVL(Pkg_Customer.GetPersonName(t.MAKERID),' '),
    NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' '),
    NVL(t.VERIFYID,' '),
    NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' '),
    NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' '),
    NVL(t.CHECKID,' '),
    NVL(Pkg_Customer.GetPersonName(t.CHECKID),' '),
    NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') ,
    NVL(t.APPROVALID,' '),
    NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' '),
    NVL(t.FIELD1,' '),
    NVL(t.FIELD2,' '),
    case when (TRANCD IN ('CLEARING', 'GROSS')) then to_char(TO_DATE(t.FIELD3,'YYYYMMDD') - Pkg_Muhasebe.Banka_Tarihi_Bul + 30) else NVL(t.FIELD3,' ') end,
    NVL(t.FIELD4,' '),
    NVL(t.FIELD5,' '),
    NVL(t.FIELD6,' '),
    NVL(t.FIELD7,' '),
    NVL(t.FIELD8,' '),
    NVL(t.FIELD9,' '),
    NVL(t.FIELD10,' '),
    NVL(t.FIELD11,' '),
    NVL(t.FIELD12,' '),
    NVL(t.FIELD13,' '),
    NVL(t.FIELD14,' '),
    NVL(t.FIELD15,' '),
    NVL(t.FIELD16,' '),
    NVL(t.FIELD17,' '),
    NVL(t.FIELD18,' '),
    NVL(t.FIELD19,' '),
    NVL(t.FIELD20,' '),
    DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10, 'GROSS', FIELD10, 'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || FIELD4 || ', ' || FIELD2, ' ') EXPLANATION,
    (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
    (TO_CHAR(APPROVALDATE,'HH24:MI:SS')),
    TO_NUMBER(nvl(ltrim(pkg_message.SPLIT(t.FIELD19,'###',0),'0'),'0'),'999999999999999.9999')*ln_tax_rate/100
   FROM
     TBL_TXTODO t, corpint.TBL_TRANSACTION R
   WHERE T.TRANCD = r.TRAN_CD  AND
      R.LANGUAGE_CD = 'ENG' AND
      t.STATUS =DECODE(ls_option,'sCONTROL','sCONTROL','sCONTROLVIEW','sDONE') AND--decode(ps_statuscd,'ALL',t.STATUS,ps_statuscd) and
	   (ls_filterAll='E' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) )
     -- INSTR(DECODE(to_char(ls_txno),'ALL',',' || TO_CHAR(TX_NO) || ',',to_char(ls_txno)), ',' || TO_CHAR(TX_NO) || ',')>0
      ORDER BY t.TX_NO;

  END IF;--sCONTROL



    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
    LOG_AT('GetWaitTxToDo',SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

END;

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
FUNCTION MakeWaitTxToDo(ps_option VARCHAR2,
                        ps_txno  VARCHAR2,
                        ps_channelcd  VARCHAR2,
                        ps_customerid  VARCHAR2,
                        ps_personid  VARCHAR2,

                        pc_ref   OUT   CursorReferenceType)  RETURN VARCHAR2 IS

     ls_amount VARCHAR2(1000);
     ls_date   VARCHAR2(1000);
     ls_currency VARCHAR2(10);

    CURSOR txtodo_cursor IS
        SELECT
        t.TX_NO,--0
        t.STATUS,--t.AUTHCD,
        r.DEFINITION,--2
        t.TRANCD,--3
        DECODE(T.TRANCD,'CARDDEBT', FIELD3, 'CLEARING',FIELD3,'GROSS', FIELD3, 'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3,DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE,
        LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'PORDCNCL',FIELD6,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9, 'GROSS', FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3, 'CARDDEBT', FIELD9, 'PAYMENTS', FIELD9, ' '),'0') AMOUNT,
        DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'PORDCNCL',FIELD7,'PAYMORD',FIELD7,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS', 'GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,'CARDDEBT', FIELD20,'PAYMENTS', FIELD20, ' ')CURRENCY,
        DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7, 'GROSS', FIELD7,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ','CARDDEBT', FIELD8, ' ')PAYEE_NAME,
        DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
        NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' ') MAKEDATE,
        NVL(t.MAKERID,' ') MAKERID,
        NVL(Pkg_Customer.GetPersonName(t.MAKERID),' ') MAKERNAME,
        NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' ') VERIFYDATE,
        NVL(t.VERIFYID,' ') VERIFYID,
        NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' ') VERIFYNAME,
        NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' ') CHECKDATE,
        NVL(t.CHECKID,' ') CHECKID,
        NVL(Pkg_Customer.GetPersonName(t.CHECKID),' ') CHECKNAME,
        NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') APPROVALDATE,
        NVL(t.APPROVALID,' ') APPROVALID,
        NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' ') APPROVALNAME,
        NVL(t.FIELD1,' ') FIELD1,
        NVL(t.FIELD2,' ') FIELD2,
        NVL(t.FIELD3,' ') FIELD3,
        NVL(t.FIELD4,' ') FIELD4,
        NVL(t.FIELD5,' ') FIELD5,
        NVL(t.FIELD6,' ') FIELD6,
        NVL(t.FIELD7,' ') FIELD7,
        NVL(t.FIELD8,' ') FIELD8,
        NVL(t.FIELD9,' ') FIELD9,
        NVL(t.FIELD10,' ') FIELD10,
        NVL(t.FIELD11,' ') FIELD11,
        NVL(t.FIELD12,' ') FIELD12,
        NVL(t.FIELD13,' ') FIELD13,
        NVL(t.FIELD14,' ') FIELD14,
        NVL(t.FIELD15,' ') FIELD15,
        NVL(t.FIELD16,' ') FIELD16,
        NVL(t.FIELD17,' ') FIELD17,
        NVL(t.FIELD18,' ') FIELD18,
        NVL(t.FIELD19,' ') FIELD19,
        NVL(t.FIELD20,' ') FIELD20,
        DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10, 'GROSS', FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || FIELD4 || ', ' || FIELD2, ' ') EXPLANATION,
        (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
        T.CONTROL_DATE,
        t.FIELD21 FIELD21 --IBC-74 YadgarB
        FROM TBL_TXTODO t, corpint.TBL_TRANSACTION R, TBL_PERSON_APPROVAL A
        WHERE A.AUTH_CD = T.AUTHCD
        AND T.TRANCD = r.TRAN_CD
        AND R.LANGUAGE_CD = 'ENG'
        AND A.PERSON_ID = TO_NUMBER(ps_personid)
        AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
        AND t.STATUS IN ('sAPPROVE','sCHECK','sVERIFY')
        AND A.CHANNEL_CD = ps_channelcd
		AND (ps_txno='ALL' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) );
       -- AND INSTR(DECODE(ps_txno,'ALL',',' || TO_CHAR(TX_NO) || ',',ps_txno), ',' || TO_CHAR(TX_NO) || ',')>0;

    row_txtodo txtodo_cursor%ROWTYPE;

  --B-O-M ernestk 23062014 cqdb864 delete for all
  CURSOR txtodo_delete_cursor IS
  SELECT
        t.TX_NO,--0
        t.STATUS,--t.AUTHCD,
        r.DEFINITION,--2
        t.TRANCD,--3
        DECODE(T.TRANCD,'CARDDEBT', FIELD3, 'CLEARING',FIELD3,'GROSS', FIELD3, 'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3,DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE,
        LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'PORDCNCL',FIELD6,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9, 'GROSS', FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3, 'CARDDEBT', FIELD9, 'PAYMENTS', FIELD9, ' '),'0') AMOUNT,
        DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'PORDCNCL',FIELD7,'PAYMORD',FIELD7,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS', 'GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,'CARDDEBT', FIELD20,'PAYMENTS', FIELD20, ' ')CURRENCY,
        DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7, 'GROSS', FIELD7,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ','CARDDEBT', FIELD8, ' ')PAYEE_NAME,
        DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
        NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' ') MAKEDATE,
        NVL(t.MAKERID,' ') MAKERID,
        NVL(Pkg_Customer.GetPersonName(t.MAKERID),' ') MAKERNAME,
        NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' ') VERIFYDATE,
        NVL(t.VERIFYID,' ') VERIFYID,
        NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' ') VERIFYNAME,
        NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' ') CHECKDATE,
        NVL(t.CHECKID,' ') CHECKID,
        NVL(Pkg_Customer.GetPersonName(t.CHECKID),' ') CHECKNAME,
        NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') APPROVALDATE,
        NVL(t.APPROVALID,' ') APPROVALID,
        NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' ') APPROVALNAME,
        NVL(t.FIELD1,' ') FIELD1,
        NVL(t.FIELD2,' ') FIELD2,
        NVL(t.FIELD3,' ') FIELD3,
        NVL(t.FIELD4,' ') FIELD4,
        NVL(t.FIELD5,' ') FIELD5,
        NVL(t.FIELD6,' ') FIELD6,
        NVL(t.FIELD7,' ') FIELD7,
        NVL(t.FIELD8,' ') FIELD8,
        NVL(t.FIELD9,' ') FIELD9,
        NVL(t.FIELD10,' ') FIELD10,
        NVL(t.FIELD11,' ') FIELD11,
        NVL(t.FIELD12,' ') FIELD12,
        NVL(t.FIELD13,' ') FIELD13,
        NVL(t.FIELD14,' ') FIELD14,
        NVL(t.FIELD15,' ') FIELD15,
        NVL(t.FIELD16,' ') FIELD16,
        NVL(t.FIELD17,' ') FIELD17,
        NVL(t.FIELD18,' ') FIELD18,
        NVL(t.FIELD19,' ') FIELD19,
        NVL(t.FIELD20,' ') FIELD20,
        DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10, 'GROSS', FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || FIELD4 || ', ' || FIELD2, ' ') EXPLANATION,
        (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
        T.CONTROL_DATE
        FROM TBL_TXTODO t, corpint.TBL_TRANSACTION R
        WHERE T.TRANCD = r.TRAN_CD
        AND R.LANGUAGE_CD = 'ENG'
        AND T.CUSTOMER_ID=TO_NUMBER(ps_customerID)
        AND t.STATUS IN ('sAPPROVE','sCHECK','sVERIFY')
		AND (ps_txno='ALL' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) );
        --AND INSTR(DECODE(ps_txno,'ALL',',' || TO_CHAR(TX_NO) || ',',ps_txno), ',' || TO_CHAR(TX_NO) || ',')>0;

  row_txtodo_delete txtodo_delete_cursor%ROWTYPE;
  --E-O-M ernestk 23062014 cqdb864 delete for all

  --MH:18072006 TX TODO DETAILS CURSOR
    CURSOR txtododetails_cursor(p_txno NUMBER) IS
        SELECT  TX_NO,
                INSTALMENT_ID,
                TRAN_TYPE,
                PAYMENT_TYPE,
                START_DATE,
                END_DATE,
                PERIOD_TYPE,
                INSTALMENT_AMOUNT,
                STATUS_CD,
                HOLIDAY_TYPE,
                INFORMING
        FROM corpint.TBL_TXTODO_DETAILS
        WHERE tx_no=p_txno;

    row_txtodo_details txtododetails_cursor%ROWTYPE;

    CURSOR txcontroltodo_cursor IS
        SELECT
        t.TX_NO,--0
        t.STATUS,--t.AUTHCD,
        r.DEFINITION,--2
        t.TRANCD,--3
        DECODE(T.TRANCD,'CARDDEBT', FIELD3, 'CLEARING',FIELD3, 'GROSS', FIELD3,'CLEARCNCL',FIELD3,'CLEARPENS',FIELD3,DECODE(t.STATUS,'sDONE',TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),'sDELETE',TO_CHAR(t.MAKEDATE,'YYYYMMDD'),TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'))) TRAN_DATE,
        LTRIM(DECODE(T.TRANCD,'P2OCARD',FIELD9,'ARBITRAGE',FIELD7,'CNCLFXORD',FIELD7,'FXORDER',FIELD9,'SALPAYTBL',FIELD9,'PORDCNCL',FIELD6,'SWIFT',FIELD9,'SALARYPAY',FIELD9,'CARDPYM',FIELD9,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9, 'GROSS', FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,'CARDDEBT', FIELD9,'PAYMENTS', FIELD9, ' '),'0') AMOUNT,
        DECODE(T.TRANCD,'P2OCARD',FIELD20,'ARBITRAGE',FIELD4,'CNCLFXORD',FIELD8,'FXORDER',FIELD20,'SALPAYTBL',FIELD20,'PORDCNCL',FIELD7,'PAYMORD',FIELD7,'SWIFT',FIELD20,'SALARYPAY',FIELD20,'CARDPYM',FIELD20,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS', 'GROSS', 'KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,'CARDDEBT', FIELD20,'PAYMENTS', FIELD20, ' ')CURRENCY,
        DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD7, 'GROSS', FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ','CARDDEBT', FIELD8, ' ')PAYEE_NAME,
        DECODE(T.TRANCD,'ARBITRAGE',FIELD5,'CNCLFXORD',FIELD6,'FXORDER',FIELD4,'EXCHNGBUY',FIELD5,'EXCHNGSELL',FIELD5,1) FX_RATE,
        NVL(TO_CHAR(t.MAKEDATE,'YYYYMMDD'),' ') MAKEDATE,
        NVL(t.MAKERID,' ') MAKERID,
        NVL(Pkg_Customer.GetPersonName(t.MAKERID),' ') MAKERNAME,
        NVL(TO_CHAR(t.VERIFYDATE,'YYYYMMDD'),' ') VERIFYDATE,
        NVL(t.VERIFYID,' ') VERIFYID,
        NVL(Pkg_Customer.GetPersonName(t.VERIFYID),' ') VERIFYNAME,
        NVL(TO_CHAR(t.CHECKDATE,'YYYYMMDD'),' ') CHECKDATE,
        NVL(t.CHECKID,' ') CHECKID,
        NVL(Pkg_Customer.GetPersonName(t.CHECKID),' ') CHECKNAME,
        NVL(TO_CHAR(t.APPROVALDATE,'YYYYMMDD'),' ') APPROVALDATE,
        NVL(t.APPROVALID,' ') APPROVALID,
        NVL(Pkg_Customer.GetPersonName(t.APPROVALID),' ') APPROVALNAME,
        NVL(t.FIELD1,' ') FIELD1,
        NVL(t.FIELD2,' ') FIELD2,
        NVL(t.FIELD3,' ') FIELD3,
        NVL(t.FIELD4,' ') FIELD4,
        NVL(t.FIELD5,' ') FIELD5,
        NVL(t.FIELD6,' ') FIELD6,
        NVL(t.FIELD7,' ') FIELD7,
        NVL(t.FIELD8,' ') FIELD8,
        NVL(t.FIELD9,' ') FIELD9,
        NVL(t.FIELD10,' ') FIELD10,
        NVL(t.FIELD11,' ') FIELD11,
        NVL(t.FIELD12,' ') FIELD12,
        NVL(t.FIELD13,' ') FIELD13,
        NVL(t.FIELD14,' ') FIELD14,
        NVL(t.FIELD15,' ') FIELD15,
        NVL(t.FIELD16,' ') FIELD16,
        NVL(t.FIELD17,' ') FIELD17,
        NVL(t.FIELD18,' ') FIELD18,
        NVL(t.FIELD19,' ') FIELD19,
        NVL(t.FIELD20,' ') FIELD20,
        DECODE(T.TRANCD,'P2OCARD',FIELD3,'FXORDER',FIELD11,'PAYMORD',FIELD6,'CARDPYM',FIELD3,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD4,'B2OBHVL',FIELD4,'CLEARING',FIELD10,'GROSS',FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',FIELD4,'CARDDEBT', FIELD10,'PAYMENTS', FIELD5 || ', ' || FIELD4 || ', ' || FIELD2, ' ') EXPLANATION,
        (TO_CHAR(MAKEDATE,'HH24:MI:SS')),
        T.CUSTOMER_ID
        FROM TBL_TXTODO t, corpint.TBL_TRANSACTION R
        WHERE T.TRANCD = r.TRAN_CD
        AND R.LANGUAGE_CD = 'ENG'
        AND t.STATUS IN ('sCONTROL')
		AND (ps_txno='ALL' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txno, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) );
       -- AND INSTR(DECODE(ps_txno,'ALL',',' || TO_CHAR(TX_NO) || ',',ps_txno), ',' || TO_CHAR(TX_NO) || ',')>0;

    row_txcontroltodo txcontroltodo_cursor%ROWTYPE;
    ls_returncode     VARCHAR2(3);
    ls_rates          VARCHAR2(20);
    ln_customerid     NUMBER;
    ls_retcode        VARCHAR2(3);

    ln_charge_amount number:=0;

    END_HH24 NUMBER;
    END_MM NUMBER;

    val_date varchar2(8);
    tran_date varchar2(8);
    make_time varchar2(8);
    ls_txnos varchar2(2000):='';
    limit_exception exception; --ernestk 25042014 cqdb00000968 exception to throw if limit is exceeded

    ls_swiftValueDate varchar2(11); --chyngyzo cq509 02/04/2015
BEGIN

log_at('checkerrr1', ps_option);
    IF ps_option IN ('sMAKE','sDELETE') THEN
            IF ps_option='sMAKE' THEN
               OPEN txtodo_cursor;
               FETCH txtodo_cursor INTO row_txtodo;
               WHILE  txtodo_cursor%FOUND
               LOOP

                    SAVEPOINT BEGINNING;

                    SELECT END_HH24, END_MM
                    INTO END_HH24, END_MM
                    FROM CBS_INT_TIME
                    WHERE TRAN_CD='SWIFT';

log_at('ch1101');


















                        --1-Check Limit
                        IF row_txtodo.TRANCD NOT IN ('CLEARCNCL','B2BHVL','PAYMORD','PORDCNCL') THEN
                            ls_rates:=TO_CHAR(Pkg_Kur.DAK_to_LC('USD',1))||';'||TO_CHAR(Pkg_Kur.DAK_to_LC('EUR',1))||';'||TO_CHAR(Pkg_Kur.DAK_to_LC('RUB',1)); -- AdiletK CQ5369 17.02.2016 defect RUB limit

                            ls_returncode:=pkg_customer.CheckLimit(ps_customerid,
                                                                   row_txtodo.TRANCD,
                                                                   row_txtodo.AMOUNT,
                                                                   ps_personid,
                                                                   ps_channelcd,
                                                                   ls_rates,
                                                                   row_txtodo.CURRENCY,
                                                                   pc_ref);

                        END IF;


                        --B-O-M ernestk 25042014 cqdb00000968 check the limit
                        IF ls_returncode <> '000' THEN
                            raise limit_exception;
                        END IF;
                        --E-O-M ernestk 25042014 cqdb00000968 check the limit
                        --2-Set Verifier/Checker/Approver
                        ls_returncode:=pkg_customer.SetVerifyUpdateFlag(row_txtodo.TX_NO,ps_customerid,ps_personid,pc_ref);

log_at('ch110', row_txtodo.TX_NO,ps_customerid,ps_personid || ' ls_returncode=>' || ls_returncode);

                        --3-Make transactions
                        IF ls_returncode NOT IN ('001','002','004','007') THEN


                            IF row_txtodo.TRANCD='CLEARING' THEN
                              ls_returncode:=Pkg_Int_Transfer.MakeEFT(row_txtodo.FIELD1,row_txtodo.FIELD2,PKG_INT_TRANSFER.GetValueDate(','||row_txtodo.TX_NO,row_txtodo.FIELD3),row_txtodo.FIELD4,row_txtodo.FIELD5,
                                             Pkg_Message.Split(row_txtodo.FIELD6,';',0),row_txtodo.FIELD7,row_txtodo.FIELD8,ltrim(replace(row_txtodo.FIELD9,'+',''),'0'),row_txtodo.FIELD10,
                                             row_txtodo.FIELD11,row_txtodo.FIELD12,Pkg_Message.Split(row_txtodo.FIELD17,';',0),row_txtodo.FIELD14,row_txtodo.FIELD15, row_txtodo.FIELD10, 'CLEARING', row_txtodo.FIELD18, pc_ref); --ernestk 13062014 cqdb864 add order number column FIELD18
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                log_at('1444',1,ls_returncode);
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'CLEARING', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), 'KGS', ps_personid, ps_channelcd, ls_rates, local_ref);
                                    log_at('1444',2,ls_returncode);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='GROSS' THEN
                              ls_returncode:=PKG_INT_TRANSFER.MakeEFT(row_txtodo.FIELD1,row_txtodo.FIELD2,PKG_INT_TRANSFER.GetValueDate(','||row_txtodo.TX_NO,row_txtodo.FIELD3),row_txtodo.FIELD4,row_txtodo.FIELD5,
                                             Pkg_Message.Split(row_txtodo.FIELD6,';',0),row_txtodo.FIELD7,row_txtodo.FIELD8,ltrim(replace(row_txtodo.FIELD9,'+',''),'0'),row_txtodo.FIELD10,
                                             row_txtodo.FIELD11,row_txtodo.FIELD12,Pkg_Message.Split(row_txtodo.FIELD17,';',0),row_txtodo.FIELD14,row_txtodo.FIELD15, row_txtodo.FIELD10, 'GROSS', row_txtodo.FIELD18, pc_ref);--ernestk 13062014 cqdb864 add order number column FIELD18
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'GROSS', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), 'KGS', ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='B2OBHVL' THEN
                              ls_returncode:=Pkg_Int_Transfer.BooktoBookTransfer(row_txtodo.FIELD1,row_txtodo.FIELD2,ltrim(replace(row_txtodo.FIELD3,'+',''),'0'),row_txtodo.FIELD4,
                                             row_txtodo.FIELD5,row_txtodo.FIELD6,row_txtodo.FIELD12,row_txtodo.FIELD18, pc_ref); ----chyngyzo 10122014 cq1264 add order number FIELD18
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'B2OBHVL', ltrim(replace(row_txtodo.FIELD3,'+',''),'0'), row_txtodo.FIELD5, ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='B2BHVL' THEN
                              ls_returncode:=Pkg_Int_Transfer.BooktoBookTransfer(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,row_txtodo.FIELD4,
                                             row_txtodo.FIELD5,row_txtodo.FIELD6,row_txtodo.FIELD12,row_txtodo.FIELD18,pc_ref);----chyngyzo 10122014 cq1264 add order number FIELD18
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'B2BHVL', ltrim(replace(row_txtodo.FIELD3,'+',''),'0'), row_txtodo.FIELD5, ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='EXCHNGSELL' THEN
                              ls_returncode:=Pkg_Int_Currency.FXBuySell(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,REPLACE(pkg_int_account.GetCurrentCurrency(row_txtodo.FIELD3,row_txtodo.TRANCD),',','.'),
                                             row_txtodo.FIELD9,row_txtodo.FIELD6,NULL,row_txtodo.FIELD8,row_txtodo.FIELD4,
                                             row_txtodo.FIELD10,row_txtodo.FIELD11,pc_ref);
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'EXCHNGSELL', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), row_txtodo.FIELD3, ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='EXCHNGBUY' THEN
                              ls_returncode:=Pkg_Int_Currency.FXBuySell(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,REPLACE(pkg_int_account.GetCurrentCurrency(row_txtodo.FIELD3,row_txtodo.TRANCD),',','.'),
                                             row_txtodo.FIELD9,row_txtodo.FIELD6,NULL,row_txtodo.FIELD8,row_txtodo.FIELD4,
                                             row_txtodo.FIELD10,row_txtodo.FIELD11,pc_ref);
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'EXCHNGBUY', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), row_txtodo.FIELD3, ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='UTILPAY' THEN
                              ls_returncode:=Pkg_Int_Transfer.MakeUtilityPayment(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,row_txtodo.FIELD4,
                                             row_txtodo.FIELD5,row_txtodo.FIELD6,row_txtodo.FIELD7,row_txtodo.FIELD8,
                                             row_txtodo.FIELD9,row_txtodo.FIELD10,pc_ref);
                            ELSIF row_txtodo.TRANCD='CLEARCNCL' THEN
                              ls_returncode:=Pkg_Int_Transfer.CancelClearing(row_txtodo.FIELD1,pc_ref);
                            ELSIF row_txtodo.TRANCD='CARDPYM' THEN
                              ls_returncode:=Pkg_Int_Transfer.TransferToCard(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD9,row_txtodo.FIELD3,
                                             row_txtodo.FIELD20,pc_ref);
                            /*BOM ChyngyzO cq4960 28.12.15*/
                            ELSIF row_txtodo.TRANCD='SALARY' THEN
log_at('test_nurs2','row_txtodo.TX_NO',row_txtodo.TX_NO);
log_at('test_nurs2','row_txtodo.FIELD1',row_txtodo.FIELD1);
log_at('test_nurs2','row_txtodo.FIELD2',row_txtodo.FIELD2);
 
                                ls_returncode:=Pkg_Int_Transfer.MakeSalaryPayment(row_txtodo.TX_NO, --ps_todo_txno
                                                                                                                              row_txtodo.FIELD1, --ps_fromAccNo
                                                                                                                              row_txtodo.FIELD2,--ps_totalAmount
                                                                                                                              pc_ref);



                            /*EOM ChyngyzO cq4960 28.12.15*/
                            ELSIF row_txtodo.TRANCD='PAYMORD' THEN

                                OPEN txtododetails_cursor(row_txtodo.TX_NO);
                                FETCH txtododetails_cursor INTO row_txtodo_details;
                                WHILE  txtododetails_cursor%FOUND
                                LOOP
                                    IF row_txtodo_details.PAYMENT_TYPE='IRREGULAR' THEN
                                        ls_amount:= ls_amount || row_txtodo_details.INSTALMENT_AMOUNT || ';';
                                        ls_date:=ls_date || row_txtodo_details.START_DATE  || ';';
                                    ELSE
                                        ls_amount:=row_txtodo_details.INSTALMENT_AMOUNT;
                                        ls_date:=row_txtodo_details.START_DATE;
                                    END IF;
                                FETCH txtododetails_cursor INTO row_txtodo_details;
                                END LOOP;
                                CLOSE txtododetails_cursor;

                              ls_returncode:=Pkg_Int_Transfer.MakeOrderPayment(row_txtodo.FIELD2,ls_date,row_txtodo.FIELD5,row_txtodo.FIELD9,
                                        row_txtodo.FIELD4,row_txtodo.FIELD3,ls_amount,row_txtodo.FIELD6,
                                        row_txtodo.FIELD10,row_txtodo.FIELD11,row_txtodo.FIELD12,row_txtodo.FIELD13,
                                        row_txtodo.FIELD7,row_txtodo.FIELD14,row_txtodo.FIELD8,row_txtodo.FIELD15,
                                        row_txtodo.FIELD16,row_txtodo.FIELD17,row_txtodo_details.TRAN_TYPE,row_txtodo_details.PAYMENT_TYPE,
                                        row_txtodo_details.INFORMING,row_txtodo_details.PERIOD_TYPE,row_txtodo_details.HOLIDAY_TYPE,TO_CHAR(row_txtodo_details.END_DATE),
                                        row_txtodo.FIELD18,pc_ref);

                            ELSIF row_txtodo.TRANCD='PORDCNCL' THEN
                              ls_returncode:=Pkg_Int_Transfer.PaymentOrderCancel(row_txtodo.FIELD2,row_txtodo.FIELD3,row_txtodo.FIELD4,pc_ref);





                            ELSIF row_txtodo.TRANCD='FXORDER' THEN
                              ls_returncode:=Pkg_Int_Currency.MakeFXOrders(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,row_txtodo.FIELD5,
                                            row_txtodo.FIELD6,row_txtodo.FIELD11,row_txtodo.FIELD9,row_txtodo.FIELD10,
                                         row_txtodo.FIELD7,row_txtodo.FIELD8,row_txtodo.FIELD4,pc_ref);

                            ELSIF row_txtodo.TRANCD='CNCLFXORD' THEN
                              ls_returncode:=Pkg_Int_Currency.FXOrdersCancel(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD4,pc_ref);

                            ELSIF row_txtodo.TRANCD='ARBITRAGE' THEN
                              ls_returncode:=Pkg_Int_Currency.MakeArbitrage(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD3,row_txtodo.FIELD4,
                                           row_txtodo.FIELD5,row_txtodo.FIELD6,row_txtodo.FIELD7,pc_ref);

                            ELSIF row_txtodo.TRANCD='P2OCARD' THEN
                              ls_returncode:=Pkg_Int_Transfer.TransferToCard(row_txtodo.FIELD1,row_txtodo.FIELD2,row_txtodo.FIELD9,row_txtodo.FIELD3,
                                          row_txtodo.FIELD20,pc_ref);
                            ELSIF row_txtodo.TRANCD='SWIFT' THEN
                              --B-O-M chyngyzo cq509 13/03/15--------------------------------------
                              --check value date (in case approver approves after the threshold time)
                                ls_returncode := Pkg_Soa_Inquiry.getSwiftValueDate(TO_NUMBER(ps_customerid), TO_NUMBER(ps_personid), TRIM(row_txtodo.FIELD5),  'Y', TRIM(row_txtodo.FIELD20), TRIM(row_txtodo.FIELD11), ls_swiftValueDate);
                               
                                log_at('make_tx_todo','get swiftvaluedate',ls_returncode);

                                IF ls_returncode <> '000' AND TO_DATE(TRIM(row_txtodo.FIELD5), 'DD/MM/YYYY') = PKG_MUHASEBE.BANKA_TARIHI_BUL THEN
                                    --ls_swiftValueDate := TO_CHAR(PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL,'DD/MM/YYYY'); --cq5735 ChyngyzO 31.01.2017 commented
                                    ls_returncode:='000';
                                else
                                    ls_swiftValueDate := TRIM(row_txtodo.FIELD5); --cq5735 ChyngyzO 31.01.2017
                                END IF;

                                IF ls_returncode <> '000' then
                                    ls_returncode:='782';
                                ELSE
                                    --ls_swiftValueDate := TRIM(row_txtodo.FIELD5); --cq5735 ChyngyzO 31.01.2017 commented

                                    ln_charge_amount := to_number(pkg_message.SPLIT(row_txtodo.FIELD19,'###',0),'999999999999.9999') + to_number(pkg_message.SPLIT(row_txtodo.FIELD19,'###',1),'999999999999.9999'); --cq5548 ChyngyzO 14.09.2016

                                    UPDATE CORPINT.TBL_TXTODO SET STATUS = 'sBANKAPPR', FIELD5 = ls_swiftValueDate WHERE TX_NO = row_txtodo.TX_NO;



                                    ls_returncode := PKG_INT_TRANSFER.MAKE_SWIFT(pkg_message.SPLIT(row_txtodo.FIELD12,'###',0), --ps_sender_acc_no
                                                                                 pkg_message.SPLIT(row_txtodo.FIELD4,'###',0), --ps_country_code
                                                                                 row_txtodo.FIELD20, --ps_currency
                                                                                 row_txtodo.FIELD9, --ps_amount
                                                                                 to_char(to_date(ls_swiftValueDate, 'DD/MM/YYYY'), 'YYYYMMDD'), --ps_value_date
                                                                                 row_txtodo.FIELD11, --ps_charge_party
                                                                                 row_txtodo.FIELD3, --ps_stat_code --pkg_message.SPLIT(row_txtodo.FIELD3,'#',1), --cq5548 ChyngyzO 14.09.2016
                                                                                 row_txtodo.FIELD2, --ps_description
                                                                                 pkg_message.SPLIT(row_txtodo.FIELD12,'###',1), --ps_comm_acc_no
                                                                                 ln_charge_amount,  --ps_charge_amount
                                                                                 row_txtodo.FIELD10, --ps_ben_acc_no
                                                                                 row_txtodo.FIELD14, --ps_ben_name
                                                                                 row_txtodo.FIELD1, --ps_ben_address
                                                                                 pkg_message.SPLIT(row_txtodo.FIELD13,'###',0), --ps_ben_swiftcode
                                                                                 row_txtodo.FIELD15, --ps_ii_bic
                                                                                 row_txtodo.TX_NO,  --ps_todo_txno
                                                                                 pc_ref,
                                                                                 row_txtodo.FIELD21 --ps_inn_kpp
                                                                                 );
                                  log_at('MAKE_SWIFT',ls_returncode);
                                --E-O-M chyngyzo cq509 13/03/15--------------------------------------

                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'SWIFT', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), row_txtodo.FIELD20, ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                             END IF;
                            ELSIF row_txtodo.TRANCD='CARDDEBT' THEN
                                ls_returncode:=PKG_INT_TRANSFER.MAKECARDDEBTPAYMENT(ps_personid,
                                                                                    row_txtodo.FIELD1,
                                                                                    row_txtodo.FIELD9,
                                                                                    row_txtodo.FIELD8,
                                                                                    row_txtodo.FIELD7, -- AdiletK CQ5541 PCI DSS pseudopan
                                                                                    pc_ref);
                              --B-O-M ernestk 17042014 cqdb968 daily limit update
                              if (ls_returncode = '000') then
                                declare
                                    limit_returncode varchar2(3):='000';
                                    local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                begin
                                    limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'CARDDEBT', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), CBS.PKG_HESAP.HESAPTANDOVIZKODUAL(to_number(row_txtodo.FIELD1)) , ps_personid, ps_channelcd, ls_rates, local_ref);
                                end;
                              end if;
                              --E-O-M ernestk 17042014 cqdb968 daily limit update
                            ELSIF row_txtodo.TRANCD='PAYMENTS' THEN --almasn CQ4481

                                ls_returncode:=PKG_SOA_TRANSACTION.PayForServices(row_txtodo.FIELD10,
                                                                                  row_txtodo.FIELD9,
                                                                                  row_txtodo.FIELD2,
                                                                                  row_txtodo.FIELD20,
                                                                                  row_txtodo.FIELD5,
                                                                                  '',
                                                                                  '',
                                                                                  '',
                                                                                  row_txtodo.FIELD4,
                                                                                  pc_ref);

                                if (ls_returncode = '000') then
                                    declare
                                        limit_returncode varchar2(3):='000';
                                        local_ref        CORPINT.PKG_LIMIT.CURSORREFERENCETYPE;
                                    begin
                                        limit_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(ps_customerid, 'PAYMENTS', ltrim(replace(row_txtodo.FIELD9,'+',''),'0'), row_txtodo.FIELD20, ps_personid, ps_channelcd, ls_rates, local_ref);
                                    exception
                                        when others then
                                            log_at('PAYMENTS', 2, limit_returncode, sqlerrm);
                                    end;
                                end if;

                            END IF;

                            --If error in make tran then rollback and return;
                            IF ls_returncode<>'000' THEN
                                ROLLBACK;
                                ls_retcode:=Pkg_Int_Tx.GetWaitTxToDo('sVIEW',
                                                                     ps_txno,
                                                                     ps_channelcd,
                                                                     ps_customerid ,
                                                                     ps_personid,
                                                                     '20050101' ,
                                                                     '20990101' ,
                                                                     'ALL',
                                                                     '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                                     '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                                     '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                                     '',

                                                                     pc_ref);
                                RETURN ls_returncode;
                            END IF;

                            --4-Set Limit
                            /*IF row_txtodo.TRANCD NOT IN ('CLEARCNCL','B2BHVL') THEN
                                ls_rates:=REPLACE(ls_rates,',','.');
                                ls_returncode:=pkg_customer.UpdateLimit(ps_customerid,row_txtodo.TRANCD,row_txtodo.AMOUNT,row_txtodo.CURRENCY,
                                ps_personid,ps_channelcd,ls_rates,pc_ref);
                            END IF;*/

                        END IF;--ls_returncode not in ('001','002','004','007')

                    --END IF; IF RELATED TO SWIFT TIME IS COMMENTED OUT chyngyzo cq509 19/03/2015
                FETCH txtodo_cursor INTO row_txtodo;
                END LOOP;
                CLOSE txtodo_cursor;

            ELSIF ps_option='sDELETE' THEN
               --B-O-M ernestk 23062014 cqdb864 deletion for all authorities
               OPEN txtodo_delete_cursor;
               FETCH txtodo_delete_cursor INTO row_txtodo_delete;
               WHILE  txtodo_delete_cursor%FOUND
               LOOP
                    --2-Set Verifier/Checker/Approver
                    ls_returncode:=pkg_customer.SetVerifyUpdateFlag(row_txtodo_delete.TX_NO,ps_customerid,ps_personid,pc_ref);

                    UPDATE TBL_TXTODO T
                    SET T.STATUS='sDELETE',
                        T.APPROVALID = ps_personid
                    WHERE t.TX_NO=TO_NUMBER(row_txtodo_delete.TX_NO);

                    --4-Set Limit
                    IF row_txtodo_delete.TRANCD NOT IN ('CLEARCNCL','B2BHVL') THEN
                        ls_currency:='KGS';
                        IF row_txtodo_delete.TRANCD IN ('EXCHNGBUY','EXCHNGSELL') THEN
                            ls_rates:=1||';'||1||';'||1;
                            ls_amount:=row_txtodo_delete.FIELD11;
                        ELSIF row_txtodo.TRANCD IN ('B2BHVL','B2OBHVL','CLEARING') THEN
                            ls_rates:=1||';'||1||';'||1;
                            ls_amount:=row_txtodo_delete.FIELD9;
                        ELSIF row_txtodo.TRANCD IN ('ARBITRAGE') THEN
                            ls_rates:=row_txtodo_delete.FIELD5||';'||row_txtodo_delete.FIELD5||';'||row_txtodo_delete.FIELD5;
                            ls_amount:=row_txtodo_delete.FIELD7;
                            ls_currency := row_txtodo_delete.CURRENCY;
                        ELSE
                            ls_rates:=1||';'||1||';'||1;
                            ls_amount:='0';
                        END IF;

                        IF (INSTR(ls_rates,'.',1,1)>0) THEN
                            ls_rates:=REPLACE(ls_rates,',','');
                        ELSE
                            ls_rates:=REPLACE(ls_rates,',','.');
                        END IF;

                        IF (INSTR(ls_amount,'.',1,1)>0) THEN
                            ls_amount:=REPLACE(ls_amount,',','');
                        ELSE
                            ls_amount:=REPLACE(ls_amount,',','.');
                        END IF;

                        ls_returncode:=pkg_customer.UpdateLimit(ps_customerid,row_txtodo_delete.TRANCD, '-'||ls_amount ,ls_currency,
                        row_txtodo_delete.MAKERID,ps_channelcd,ls_rates,pc_ref);
                    END IF;

                    ls_returncode:='000';
                FETCH txtodo_delete_cursor INTO row_txtodo_delete;
                END LOOP;
                CLOSE txtodo_delete_cursor;
                --E-O-M ernestk 23062014 cqdb864 deletion for all authorities

            END IF;--'sCANCEL'

            COMMIT;
log_at('ch111');
        --5-ViewTxTODO
        ls_returncode:=Pkg_Int_Tx.GetWaitTxToDo('sVIEW', ps_txno, ps_channelcd, ps_customerid ,ps_personid, '20050101' , '20990101' , 'ALL', '', '', '', '', pc_ref);-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
log_at('ch112', ps_txno||' '|| ps_channelcd||' '|| ps_customerid||' '|| ps_personid);
        update TBL_TXTODO t
        set STATUS = 'sWAIT'
        where    t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ls_txnos, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ls_txnos, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) ;

		--INSTR(ls_txnos || ',', ',' || TO_CHAR(TX_NO) || ',')>0;
		log_at('ch112 ls_returncode',ls_returncode,ps_option);

    ELSIF ps_option IN ('sMAKECONTROL','sDELETECONTROL') THEN

        OPEN txcontroltodo_cursor;
        FETCH txcontroltodo_cursor INTO row_txcontroltodo;
        WHILE  txcontroltodo_cursor%FOUND
        LOOP
            ln_customerid:=row_txcontroltodo.CUSTOMER_ID;
            IF ps_option='sMAKECONTROL' THEN

                SAVEPOINT BEGINNING;

                --1-Check Limit
                log_at('clr',22,row_txcontroltodo.tx_no);
                IF row_txcontroltodo.TRANCD NOT IN ('CLEARCNCL','B2BHVL','PAYMORD','PORDCNCL','FXORDER') THEN
                    ls_rates:=TO_CHAR(Pkg_Kur.DAK_to_LC('USD',1))||';'||TO_CHAR(Pkg_Kur.DAK_to_LC('EUR',1));
                    ls_returncode:=pkg_customer.CheckLimit(ln_customerid,
                                                           row_txcontroltodo.TRANCD,
                                                           row_txcontroltodo.AMOUNT,
                                                           ps_personid,
                                                           ps_channelcd,
                                                           ls_rates,
                                                           row_txcontroltodo.CURRENCY,
                                                           pc_ref);
                END IF;

                --2-Set Verifier/Checker/Approver
                ls_returncode:=pkg_customer.SetVerifyUpdateFlag(row_txcontroltodo.TX_NO,ln_customerid,ps_personid,pc_ref);

            --3-Make transactions
                IF ls_returncode NOT IN ('000') THEN

                    IF row_txcontroltodo.TRANCD='CLEARING' THEN
                    log_at('clr',1,row_txcontroltodo.tx_no);
                    --pkg_TX3555.Clearing_Gross_Time_Check(row_txcontroltodo.tx_no);
                        ls_returncode:=Pkg_Int_Transfer.MakeEFT(row_txcontroltodo.FIELD1,
                                                                row_txcontroltodo.FIELD2,
                                                                row_txcontroltodo.FIELD3,
                                                                row_txcontroltodo.FIELD4,
                                                                row_txcontroltodo.FIELD5,
                                                                Pkg_Message.Split(row_txcontroltodo.FIELD6,';',0),
                                                                row_txcontroltodo.FIELD7,
                                                                row_txcontroltodo.FIELD8,
                                                                row_txcontroltodo.FIELD9,
                                                                row_txcontroltodo.FIELD10,
                                                                row_txcontroltodo.FIELD11,
                                                                row_txcontroltodo.FIELD12,
                                                                Pkg_Message.Split(row_txcontroltodo.FIELD17,';',0),
                                                                row_txcontroltodo.FIELD14,
                                                                row_txcontroltodo.FIELD15,
                                                                row_txtodo.FIELD10,
                                                                'CLEARING',
                                                                row_txtodo.FIELD18,--ernestk 13062014 cqdb864 add order number column
                                                                pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='GROSS' THEN
                    --pkg_TX3555.Clearing_Gross_Time_Check(row_txcontroltodo.tx_no);
                        ls_returncode:=Pkg_Int_Transfer.MAKEEFT(row_txcontroltodo.FIELD1,
                                                                row_txcontroltodo.FIELD2,
                                                                row_txcontroltodo.FIELD3,
                                                                row_txcontroltodo.FIELD4,
                                                                row_txcontroltodo.FIELD5,
                                                                Pkg_Message.Split(row_txcontroltodo.FIELD6,';',0),
                                                                row_txcontroltodo.FIELD7,
                                                                row_txcontroltodo.FIELD8,
                                                                row_txcontroltodo.FIELD9,
                                                                row_txcontroltodo.FIELD10,
                                                                row_txcontroltodo.FIELD11,
                                                                row_txcontroltodo.FIELD12,
                                                                Pkg_Message.Split(row_txcontroltodo.FIELD17,';',0),
                                                                row_txcontroltodo.FIELD14,
                                                                row_txcontroltodo.FIELD15,
                                                                row_txtodo.FIELD10,
                                                                'GROSS',
                                                                row_txtodo.FIELD18, --ernestk 13062014 cqdb864 add order number column FILED18
                                                                pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='B2OBHVL' THEN
                        ls_returncode:=Pkg_Int_Transfer.BooktoBookTransfer(row_txcontroltodo.FIELD1,
                                                                           row_txcontroltodo.FIELD2,
                                                                           row_txcontroltodo.FIELD3,
                                                                           row_txcontroltodo.FIELD4,
                                                                           row_txcontroltodo.FIELD5,
                                                                           row_txcontroltodo.FIELD6,
                                                                           row_txcontroltodo.FIELD12,
                                                                           row_txcontroltodo.FIELD18,----chyngyzo 10122014 cq1264 add order number FIELD18
                                                                           pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='B2BHVL' THEN
                        ls_returncode:=Pkg_Int_Transfer.BooktoBookTransfer(row_txcontroltodo.FIELD1,
                                                                           row_txcontroltodo.FIELD2,
                                                                           row_txcontroltodo.FIELD3,
                                                                           row_txcontroltodo.FIELD4,
                                                                           row_txcontroltodo.FIELD5,
                                                                           row_txcontroltodo.FIELD6,
                                                                           row_txcontroltodo.FIELD12,
                                                                           row_txcontroltodo.FIELD18,----chyngyzo 10122014 cq1264 add order number FIELD18
                                                                           pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='EXCHNGSELL' THEN
                        ls_returncode:=Pkg_Int_Currency.FXBuySell(row_txcontroltodo.FIELD1,
                                                                  row_txcontroltodo.FIELD2,
                                                                  row_txcontroltodo.FIELD3,
                                                                  row_txcontroltodo.FIELD5,
                                                                  row_txcontroltodo.FIELD9,
                                                                  row_txcontroltodo.FIELD6,
                                                                  NULL,
                                                                  row_txcontroltodo.FIELD8,
                                                                  row_txcontroltodo.FIELD4,
                                                                  row_txcontroltodo.FIELD10,
                                                                  row_txcontroltodo.FIELD11,
                                                                  pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='EXCHNGBUY' THEN
                        ls_returncode:=Pkg_Int_Currency.FXBuySell(row_txcontroltodo.FIELD1,
                                                                  row_txcontroltodo.FIELD2,
                                                                  row_txcontroltodo.FIELD3,
                                                                  row_txcontroltodo.FIELD5,
                                                                  row_txcontroltodo.FIELD9,
                                                                  row_txcontroltodo.FIELD6,
                                                                  NULL,
                                                                  row_txcontroltodo.FIELD8,
                                                                  row_txcontroltodo.FIELD4,
                                                                  row_txcontroltodo.FIELD10,
                                                                  row_txcontroltodo.FIELD11,
                                                                  pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='UTILPAY' THEN
                        ls_returncode:=Pkg_Int_Transfer.MakeUtilityPayment(row_txcontroltodo.FIELD1,
                                                                           row_txcontroltodo.FIELD2,
                                                                           row_txcontroltodo.FIELD3,
                                                                           row_txcontroltodo.FIELD4,
                                                                           row_txcontroltodo.FIELD5,
                                                                           row_txcontroltodo.FIELD6,
                                                                           row_txcontroltodo.FIELD7,
                                                                           row_txcontroltodo.FIELD8,
                                                                           row_txcontroltodo.FIELD9,
                                                                           row_txcontroltodo.FIELD10,
                                                                           pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='CLEARCNCL' THEN
                        ls_returncode:=Pkg_Int_Transfer.CancelClearing(row_txcontroltodo.FIELD1,pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='CARDPYM' THEN
                        ls_returncode:=Pkg_Int_Transfer.TransferToCard(row_txcontroltodo.FIELD1,
                                                                       row_txcontroltodo.FIELD2,
                                                                       row_txcontroltodo.FIELD9,
                                                                       row_txcontroltodo.FIELD3,
                                                                       row_txcontroltodo.FIELD20,
                                                                       pc_ref);





                    ELSIF row_txcontroltodo.TRANCD='PAYMORD' THEN
                        OPEN txtododetails_cursor(row_txcontroltodo.TX_NO);
                        FETCH txtododetails_cursor INTO row_txtodo_details;
                        WHILE  txtododetails_cursor%FOUND
                        LOOP
                            IF row_txtodo_details.PAYMENT_TYPE='IRREGULAR' THEN
                                ls_amount:= ls_amount || row_txtodo_details.INSTALMENT_AMOUNT || ';';
                                ls_date:=ls_date || row_txtodo_details.START_DATE  || ';';
                            ELSE
                                ls_amount:=row_txtodo_details.INSTALMENT_AMOUNT;
                                ls_date:=row_txtodo_details.START_DATE;
                            END IF;
                        FETCH txtododetails_cursor INTO row_txtodo_details;
                        END LOOP;
                        CLOSE txtododetails_cursor;

                    ls_returncode:=Pkg_Int_Transfer.MakeOrderPayment(row_txcontroltodo.FIELD2,
                                                                     ls_date,
                                                                     row_txcontroltodo.FIELD5,
                                                                     row_txcontroltodo.FIELD9,
                                                                     row_txcontroltodo.FIELD4,
                                                                     row_txcontroltodo.FIELD3,
                                                                     ls_amount,
                                                                     row_txcontroltodo.FIELD6,
                                                                     row_txcontroltodo.FIELD10,
                                                                     row_txcontroltodo.FIELD11,
                                                                     row_txcontroltodo.FIELD12,
                                                                     row_txcontroltodo.FIELD13,
                                                                     row_txcontroltodo.FIELD7,
                                                                     row_txcontroltodo.FIELD14,
                                                                     row_txcontroltodo.FIELD8,
                                                                     row_txcontroltodo.FIELD15,
                                                                     row_txcontroltodo.FIELD16,
                                                                     row_txcontroltodo.FIELD17,
                                                                     row_txtodo_details.TRAN_TYPE,
                                                                     row_txtodo_details.PAYMENT_TYPE,
                                                                     row_txtodo_details.INFORMING,
                                                                     row_txtodo_details.PERIOD_TYPE,
                                                                     row_txtodo_details.HOLIDAY_TYPE,
                                                                     TO_CHAR(row_txtodo_details.END_DATE),
                                                                     row_txcontroltodo.FIELD18,
                                                                     pc_ref);

                    ELSIF row_txcontroltodo.TRANCD='PORDCNCL' THEN
                        ls_returncode:=Pkg_Int_Transfer.PaymentOrderCancel(row_txcontroltodo.FIELD2,
                                                                           row_txcontroltodo.FIELD3,
                                                                           row_txcontroltodo.FIELD4,
                                                                           pc_ref);




                    ELSIF row_txcontroltodo.TRANCD='FXORDER' THEN
                        ls_returncode:=Pkg_Int_Currency.MakeFXOrders(row_txcontroltodo.FIELD1,
                                                                     row_txcontroltodo.FIELD2,
                                                                     row_txcontroltodo.FIELD3,
                                                                     row_txcontroltodo.FIELD5,
                                                                     row_txcontroltodo.FIELD6,
                                                                     row_txcontroltodo.FIELD11,
                                                                     row_txcontroltodo.FIELD9,
                                                                     row_txcontroltodo.FIELD10,
                                                                     row_txcontroltodo.FIELD7,
                                                                     row_txcontroltodo.FIELD8,
                                                                     row_txcontroltodo.FIELD4,
                                                                     pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='CNCLFXORD' THEN
                        ls_returncode:=Pkg_Int_Currency.FXOrdersCancel(row_txcontroltodo.FIELD1,
                                                                       row_txcontroltodo.FIELD2,
                                                                       row_txcontroltodo.FIELD4,
                                                                       pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='ARBITRAGE' THEN
                        ls_returncode:=Pkg_Int_Currency.MakeArbitrage(row_txcontroltodo.FIELD1,
                                                                      row_txcontroltodo.FIELD2,
                                                                      row_txcontroltodo.FIELD3,
                                                                      row_txcontroltodo.FIELD4,
                                                                      row_txcontroltodo.FIELD5,
                                                                      row_txcontroltodo.FIELD6,
                                                                      row_txcontroltodo.FIELD7,
                                                                      pc_ref);
                    ELSIF row_txcontroltodo.TRANCD='P2OCARD' THEN
                    ls_returncode:=Pkg_Int_Transfer.TransferToCard(row_txcontroltodo.FIELD1,
                                                                   row_txcontroltodo.FIELD2,
                                                                   row_txcontroltodo.FIELD9,
                                                                   row_txcontroltodo.FIELD3,
                                                                   row_txcontroltodo.FIELD20,
                                                                   pc_ref);
                    ELSIF row_txtodo.TRANCD='CARDDEBT' THEN
                            ls_returncode:=PKG_INT_TRANSFER.MAKECARDDEBTPAYMENT(ps_personid,
                                                                                row_txtodo.FIELD1,
                                                                                row_txtodo.FIELD9,
                                                                                row_txtodo.FIELD8,
                                                                                row_txtodo.FIELD7, -- AdiletK CQ5541 PCI DSS pseudopan
                                                                                pc_ref);
                    ELSIF row_txtodo.TRANCD='PAYMENTS' THEN --almasn CQ4481
                        ls_returncode:=PKG_SOA_TRANSACTION.PayForServices(row_txtodo.FIELD10,
                                                                          row_txtodo.FIELD9,
                                                                          row_txtodo.FIELD2,
                                                                          row_txtodo.FIELD20,
                                                                          row_txtodo.FIELD5,
                                                                          null,
                                                                          null,
                                                                          null,
                                                                          row_txtodo.FIELD4,
                                                                          pc_ref);
                    END IF;

                    --If error in make tran then rollback and return;
                    IF ls_returncode<>'000' THEN
                        ROLLBACK;
                        ls_retcode:=Pkg_Int_Tx.GetWaitTxToDo('sCONTROLVIEW',
                                                             ps_txno,
                                                             ps_channelcd,
                                                             ln_customerid ,
                                                             ps_personid,
                                                             '20050101' ,
                                                             '20990101' ,
                                                             'ALL',
                                                             '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                             '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                             '',-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to
                                                             '',

                                                             pc_ref);
                        RETURN ls_returncode;
                    END IF;

                    --4-Set Limit
                    /*IF row_txcontroltodo.TRANCD NOT IN ('CLEARCNCL','B2BHVL') THEN
                        ls_rates:=REPLACE(ls_rates,',','.');
                        ls_returncode:=pkg_customer.UpdateLimit(ln_customerid,row_txcontroltodo.TRANCD,row_txcontroltodo.AMOUNT,row_txcontroltodo.CURRENCY,
                        ps_personid,ps_channelcd,ls_rates,pc_ref);
                    END IF;*/

                END IF;--ls_returncode not in ('001','002','004','007')

            ELSIF ps_option='sDELETECONTROL' THEN

                --2-Set Verifier/Checker/Approver
                ls_returncode:=pkg_customer.SetVerifyUpdateFlag(row_txcontroltodo.TX_NO,ln_customerid,ps_personid,pc_ref);

                UPDATE TBL_TXTODO T
                SET T.STATUS='sDELETE',
                    T.APPROVALID=ps_personid
                WHERE t.TX_NO=TO_NUMBER(row_txcontroltodo.TX_NO);

                ls_returncode:='000';

            END IF;--'sCANCEL'

            COMMIT;

        FETCH txcontroltodo_cursor INTO row_txcontroltodo;
        END LOOP;
        CLOSE txcontroltodo_cursor;

         --5-Viewtxcontroltodo
         
         ls_returncode:=Pkg_Int_Tx.GetWaitTxToDo('sCONTROLVIEW',
                                                 ps_txno,
                                                 ps_channelcd,
                                                 ln_customerid ,
                                                 ps_personid,
                                                 '20050101' ,
                                                 '20990101' ,
                                                 'ALL', '', '', '', '', pc_ref);-- ernestk 23062014 cqdb864 sorting by payee name, amount from, amount to


    END IF;
log_at('res==',ls_returncode);
    RETURN ls_returncode;
EXCEPTION
    WHEN limit_exception THEN
        Log_At('MakeWaitTxToDo',ls_returncode, 'limit do not allow to process');
        return ls_returncode;
    WHEN OTHERS THEN
        Log_At('MakeWaitTxToDo',ls_returncode,SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        ROLLBACK;
        RETURN ls_returncode;
END;


----------------------------------------------------------------------------------------
FUNCTION GetBankHQName(ps_bankcode VARCHAR2) RETURN VARCHAR2 IS
    ls_BANKNAME      VARCHAR2(250);
BEGIN
    SELECT BANKNAME
    INTO ls_BANKNAME
    FROM CBS_BANKCODES
    WHERE BANK_BIC_CODE=ps_bankcode;

    RETURN ls_BANKNAME;
END;
-----------------------------------------------------------------------------------------
FUNCTION  istatistik_adi_al(ps_istatistik_kodu IN CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2 IS
    ls_istatistik_adi  CBS_ISTATISTIK_KODLARI.aciklama%TYPE;
BEGIN
    IF  ps_istatistik_kodu IS NOT NULL THEN
        SELECT aciklama
        INTO   ls_istatistik_adi
        FROM   CBS_ISTATISTIK_KODLARI
        WHERE  istatistik_kodu = ps_istatistik_kodu  ;
    END IF;

    RETURN ls_istatistik_adi ;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1222' || Pkg_Hata.getUCPOINTER);
END;
-----------------------------------------------------------------------------------------
FUNCTION GetPaymordDetails (ps_txno VARCHAR2,
                            pc_ref OUT   cursorreferencetype) RETURN VARCHAR2 IS
    ln_count NUMBER;
    ls_returncode  VARCHAR2 (3)  := '000';
BEGIN
    OPEN pc_ref FOR
        SELECT TX_NO,
        INSTALMENT_ID,
        TRAN_TYPE,
        PAYMENT_TYPE,
        TO_CHAR(START_DATE,'YYYYMMDD'),
        TO_CHAR(END_DATE,'YYYYMMDD'),
        PERIOD_TYPE,
        INSTALMENT_AMOUNT,
        STATUS_CD,
        HOLIDAY_TYPE,
        INFORMING
        FROM TBL_TXTODO_DETAILS t
        WHERE (ps_txNo='ALL' OR  t.TX_NO IN( select TO_NUMBER(NVL(regexp_substr(ps_txno, '[^,]+', 1, comma.column_value),-1))  as variable
                   from table(cast(multiset(select level from dual connect by level <= length (regexp_replace(ps_txNo, '[^,]+'))  + 1) as sys.OdciNumberList)) comma) );
--		INSTR(DECODE(ps_txno,'ALL',',' || TO_CHAR(TX_NO) || ',',ps_txno), ',' || TO_CHAR(TX_NO) || ',')>0;

    RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : CreditCardCPaymentTx
   Prepared By :  Nurhat UCA
   Date        : 17.12.2012
   Purpose     : Credit Card Debt Payment via IB
******************************************************************************/
FUNCTION CreditCardCPaymentTx (ps_customerid         VARCHAR2,
                               ps_personid           VARCHAR2,
                               ps_fromAccount        VARCHAR2,
                               ps_Amount             VARCHAR2,
                               ps_creditCardNo       VARCHAR2,
                               ps_pseudopan          VARCHAR2, -- AdiletK CQ5541 PCI DSS pseudopan
                               pc_ref OUT   cursorreferencetype)
   RETURN VARCHAR2
IS
   ls_returncode            VARCHAR2 (2000) := '000';
   ln_tutar                 NUMBER;
   ln_from_account_number   NUMBER;
   ln_islem_no              NUMBER;
   ln_islem_kod             NUMBER := 7723;
   lc_modul_tur_kod         VARCHAR2 (10) := 'CURR.OPS.';
   lc_urun_tur_kod          VARCHAR2 (10) := 'INTERNET';
   lc_urun_sinif_kod        VARCHAR2 (20);
   lc_doviz_kod             VARCHAR2 (3) := pkg_hesap.hesaptandovizkodual(ps_fromAccount);
   lc_hesap_no              NUMBER := TO_NUMBER (ps_fromAccount);
   ln_musteri_no NUMBER := Pkg_Hesap.hesaptanmusterinoal (TO_NUMBER (lc_hesap_no)) ;
   lc_bolum_kodu VARCHAR2 (3) := Pkg_Hesap.hesapsubeal (lc_hesap_no) ;
   lc_kasa_kod              NUMBER;
   ln_kanal_numara          NUMBER := 1;
   ln_detailid              NUMBER := 1;
   ld_date                  DATE := Pkg_Muhasebe.Banka_Tarihi_Bul;
   ls_date                  VARCHAR2(10) := TO_CHAR(ld_date,'YYYYMMDD');
   lc_rol                   NUMBER := 7777;
   ln_fisNo                   NUMBER;
   ls_ref_no                VARCHAR2 (16);
   ls_description      VARCHAR2(250);
   ls_maskedcreditCardNo  VARCHAR2(19);
   ps_reconcilation_no   VARCHAR2(7);
BEGIN
   ps_reconcilation_no:=TO_CHAR(SQ_CBS_CCDEBTPAYMENT_RECONCNO.nextVal);
   lc_urun_sinif_kod :=PKG_TX7723.sf_urun_tur_sinif_al(ps_fromAccount);
   SELECT REGEXP_REPLACE(ps_creditCardNo,'([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})','\1 XXXX XXXX \4') INTO ls_maskedcreditCardNo  FROM dual;
   ln_islem_no := Pkg_Tx.islem_no_al;
   ln_tutar := TO_NUMBER (REPLACE(ps_Amount,',',''), '99999999999.9999');
   ln_from_account_number := TO_NUMBER (ps_fromAccount);
   IF pkg_hesap.Kullanilabilir_Bakiye_Al (ln_from_account_number) < ln_tutar
   THEN
      ls_returncode := '051';
      RETURN ls_returncode;
   ELSE
      ls_ref_no := 'I' || ln_islem_no;
      ls_description:='Credit Card Payment, RIB';
      INSERT INTO CBS.CBS_INT_CARD_FINANSAL_ISLEM (TX_NO,
                                                   MODUL_TUR_KOD,
                                                   URUN_TUR_KOD,
                                                   URUN_SINIF_KOD,
                                                   TERMINAL_BRANCH,
                                                   ORIGINAL_CURRENCY_CODE,
                                                   ORIGINAL_AMOUNT,
                                                   EXPLANATION,
                                                   CARD_NUMBER,
                                                   FROM_ACCOUNT_NUMBER,
                                                   TERMINAL_ID,
                                                   REFERANCE,
                                                   KAYIT_SISTEM_TARIHI,
                                                   KAYIT_USER,
                                                   PSEUDOPAN) -- AdiletK CQ5541 PCI DSS pseudopan
        VALUES   (ln_islem_no,
                  lc_modul_tur_kod,
                  lc_urun_tur_kod,
                  lc_urun_sinif_kod,
                  NULL,
                  lc_doviz_kod,
                  ln_tutar,
                  ls_description,
                  ls_maskedcreditCardNo,
                  lc_hesap_no,
                  NULL,
                  ls_ref_no,
                  SYSDATE,
                  'CINT_CALLER',
                  ps_pseudopan); -- AdiletK CQ5541 PCI DSS pseudopan
      Pkg_Int_Api.create_transaction (ln_islem_no,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_bolum_kodu,
                                      lc_bolum_kodu,
                                      lc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_no,
                                      lc_hesap_no,
                                      lc_kasa_kod,
                                      ln_kanal_numara);


      SELECT FIS_NUMARA INTO ln_fisNo FROM CBS_ISLEM WHERE NUMARA=ln_islem_no;

     -- AdiletK testing card emails
     /*ls_returncode:= PKG_SOA_TRANSACTION.ccdebtpayment (  ps_creditCardNo, ps_Amount, lc_doviz_kod,
                                                           lc_bolum_kodu, ls_date, ls_date,
                                                           ls_description, ln_fisNo, ls_date, ps_reconcilation_no, ps_pseudopan ); -- AdiletK CQ5541 PCI DSS pseudopan
       ls_returncode := '000';
      IF ls_returncode <> '000' THEN
          ROLLBACK;
          Log_At('CreditCardCPaymentTx',ls_returncode,ls_maskedcreditCardNo || ' ' || ps_fromAccount || ' ' ||  ps_Amount || ' ' || ls_date  );
          ls_returncode :='999';
      ELSE
          Pkg_Int_Api.process_transaction (ln_islem_no);
          COMMIT;
      END IF;*/

      Pkg_Int_Api.process_transaction (ln_islem_no);
      COMMIT;
   END IF;

     -- AdiletK testing card emails
     Log_At('CreditCardCPaymentTx 1');
     ls_returncode:= PKG_SOA_TRANSACTION.ccdebtpayment (  ps_creditCardNo, ps_Amount, lc_doviz_kod,
                                                           lc_bolum_kodu, ls_date, ls_date,
                                                           ls_description, ln_fisNo, ls_date, ps_reconcilation_no, ps_pseudopan ); -- AdiletK CQ5541 PCI DSS pseudopan
      Log_At('CreditCardCPaymentTx 3',ls_returncode);
      IF ls_returncode <> '000' THEN
          update CBS_INT_CARD_FINANSAL_ISLEM
          set explanation = substr(EXPLANATION || ls_returncode, 1, 30)
          where tx_no=ln_islem_no;

          PKG_BAGLAM.yarat(lc_bolum_kodu, to_number(lc_rol));

          -- make cancel transaction
          PKG_TX.IPTAL(ln_islem_no);

          -- make cancel transaction
          PKG_TX.IPTAL_ONAY(ln_islem_no);

          Log_At('CreditCardCPaymentTx',ls_returncode,ls_maskedcreditCardNo || ' ' || ps_fromAccount || ' ' ||  ps_Amount || ' ' || ls_date  );
          ls_returncode :='999';
      END IF;

    OPEN pc_ref FOR
      SELECT  ls_returncode FROM dual;
   RETURN ls_returncode;
 EXCEPTION
    WHEN OTHERS THEN
        ls_returncode :='999';
        ROLLBACK;
        Log_At('CreditCardCPaymentTx',ls_returncode,SQLERRM);
        RETURN ls_returncode;
END;
END;
/

