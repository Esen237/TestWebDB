create PACKAGE BODY PKG_POSTA IS
--	   mailhost VARCHAR2(30) := '212.154.116.74';
       --mailhost VARCHAR2(30) := '10.0.0.251'; 
	   mailhost VARCHAR2(30) := '172.16.101.4';
 	   mail_conn utl_smtp.connection;
	   l_uc		varchar2(3):=pkg_hata.getUCPOINTER;
	   l_ara	varchar2(3):=pkg_hata.getDELIMITER;

-------------------------------------------------------------------------------------------
FUNCTION email_sender(sender IN VARCHAR2,recipient IN VARCHAR2,subject IN VARCHAR2,message IN VARCHAR2) RETURN BOOLEAN IS
	BEGIN
		mail_conn := utl_smtp.open_connection(mailhost, 25);
		utl_smtp.helo(mail_conn, mailhost);
		utl_smtp.mail(mail_conn, sender);
		utl_smtp.rcpt(mail_conn, recipient);
		utl_smtp.open_data(mail_conn);
		utl_smtp.write_data(mail_conn,'From:' || sender || utl_tcp.CRLF);
		utl_smtp.write_data(mail_conn,'To:' || recipient || utl_tcp.CRLF);
		utl_smtp.write_data(mail_conn,'Subject:' ||subject|| utl_tcp.CRLF);
		utl_smtp.write_data(mail_conn, utl_tcp.CRLF || message);
		utl_smtp.close_data(mail_conn);
		utl_smtp.quit(mail_conn);

		return true;
	EXCEPTION
     	WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
        	 utl_smtp.quit(mail_conn);
			 return false;
			 --raise_application_error(-20100, l_uc || '1922' || l_ara || sqlerrm || l_uc);
	END;
----------------------------------------------------------------------------------------------
Function EpostaAdresKontrol(ps_eposta_adres varchar2) return BOOLEAN is

	TYPE reply_type IS RECORD (
		code PLS_INTEGER, -- 3-digit reply code
		text VARCHAR2(508) -- text message
		);
	reply_msg			   reply_type;

BEGIN
	 if instr(ps_eposta_adres,'@')=0 then
	 	return false;
	 end if;

	 if instr(ps_eposta_adres,'.')=0 then
	 	return false;
	 end if;

	 return true;

exception
     when others then
	 	  return true;
END;
----------------------------------------------------------------------------------------------
 Function  EpostaAdresBul(ps_alici_kullanici_kodu varchar2) return varchar2 is
 	ls_email varchar2(2000);
 BEGIN
    select email
	into ls_email
	from cbs_kullanici
	where kodu=ps_alici_kullanici_kodu;

	return ls_email;
exception
		 when no_data_found then
		 	  raise_application_error(-20100, l_uc || '1923' || l_uc);
 END;
----------------------------------------------------------------------------------------------
   PROCEDURE EpostaGonder(ps_alici varchar2,ps_konu varchar2 default 'CBS',ps_mesaj varchar2,ps_gonderen varchar2 default 'info@cbank.com.tr',ps_oncelik_kodu NUMBER default 50,ps_eposta_kodu varchar2 default 'INFO') is
    ls_email 					   varchar2(2000);
	ls_gonderen					   varchar2(200);
	ln_messageid				   NUMBER:=pkg_genel.genel_kod_al('EPOSTAMESSAGEID');
	Eksik_Bilgi_Exception		   exception;
   BEGIN

	if ps_alici is null or ps_mesaj is null then
	  raise Eksik_Bilgi_Exception;
	end if;

	if ps_gonderen is null then
	   ls_gonderen:='info@cbank.com.tr';
    else
       ls_gonderen:=ps_gonderen;
	end if;

   	insert into cbs_eposta_mesajlar
	(MESSAGE_ID, SENDER, RECIPIENT, SUBJECT, MESSAGE_BODY, PRIORITY,MESSAGE_CODE)
	values
	(ln_messageid, ls_gonderen, ps_alici, ps_konu, ps_mesaj, ps_oncelik_kodu,ps_eposta_kodu);

	exception
		when Eksik_Bilgi_Exception then
		 raise_application_error(-20100, l_uc || '1924' || l_uc);

   END;
-------------------------------------------------------------------------------------------------
 /* PROCEDURE gonder(ps_alici_kullanici_kodu varchar2,ps_mesaj varchar2) is
    ls_email varchar2(2000);
   BEGIN

   	 select email
   	   into ls_email
   	   from cbs_kullanici
   	  where kodu=ps_alici_kullanici_kodu;

     c := utl_smtp.open_connection('www.cbank.com.tr',25);
     utl_smtp.helo(c, 'www.cbank.com.tr');
     utl_smtp.mail(c, 'info@cbank.com.tr');
     utl_smtp.rcpt(c, ls_email);
     utl_smtp.open_data(c);
     baslik('From',    '"CBS Uyari Sistemi" <info@cbank.com.tr>');
     baslik('To',      '"CBS Kullanicisi" <'||ls_email||'>');
     baslik('Subject', 'CBS');
     utl_smtp.write_data(c, utl_tcp.CRLF || ps_mesaj);
     utl_smtp.close_data(c);
     utl_smtp.quit(c);
   EXCEPTION
     WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
       BEGIN
         utl_smtp.quit(c);
       EXCEPTION
         WHEN utl_smtp.transient_error OR utl_smtp.permanent_error THEN
           NULL; -- When the SMTP server is down or unavailable, we don't
                 -- have a connection to the server. The quit call will
                 -- raise an exception that we can ignore.
       END;
       raise_application_error(-20000,
         'Failed to send mail due to the following error: ' || sqlerrm);
   END;
  */

END;
/

