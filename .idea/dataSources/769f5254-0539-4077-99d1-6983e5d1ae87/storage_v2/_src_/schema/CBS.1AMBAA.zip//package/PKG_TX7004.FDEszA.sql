create PACKAGE Pkg_Tx7004 IS

  /******************************************************************************
   Name       : PKG_TX7004
   Created By : Hakan SAMSA
   Purpose	  : Institution Definition
  ******************************************************************************/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);

  FUNCTION  InstExist( pn_code CBS_INST_DEFINITION.code%TYPE) RETURN  NUMBER;
  FUNCTION  Find_Code_Name( pn_code CBS_INST_DEFINITION.code%TYPE) RETURN  VARCHAR ;
  FUNCTION  Phone_Mandatory( pn_code  CBS_COLLECTION_DETAIL_TRAN.INSTITUTION_CODE%TYPE) RETURN  VARCHAR ;
  FUNCTION  Subscription_Mandatory( pn_code  CBS_COLLECTION_DETAIL_TRAN.INSTITUTION_CODE%TYPE) RETURN  VARCHAR ;
  FUNCTION  Invoice_Mandatory( pn_code  CBS_COLLECTION_DETAIL_TRAN.INSTITUTION_CODE%TYPE) RETURN  VARCHAR ;
  FUNCTION  Institution_Key_Mandatory( pn_code  CBS_COLLECTION_DETAIL_TRAN.INSTITUTION_CODE%TYPE) RETURN  VARCHAR ;
  FUNCTION  DevamEdenIslemVar(pn_hesap CBS_HESAP_VADELI.HESAP_NO%TYPE) RETURN  VARCHAR;
  PROCEDURE Collect_To(ps_code IN CBS_INST_DEFINITION.CODE%TYPE,
    	  							   pn_account OUT CBS_INST_DEFINITION.COLLECTION_ACCOUNT_NO%TYPE,
    	  							   ps_account_br OUT CBS_HESAP.SUBE_KODU%TYPE,
    	  							   ps_gl OUT CBS_INST_DEFINITION.COLLECTION_GL%TYPE,
    	  							   ps_gl_br OUT CBS_INST_DEFINITION.COLLECTION_GL_BRANCH%TYPE)  ;
  FUNCTION  subemi(ps_sube_kodu IN VARCHAR2) RETURN VARCHAR2  ;
  FUNCTION  sube_adi(ps_sube_kodu IN VARCHAR2) RETURN VARCHAR2  ;
  FUNCTION  FindCommission( pn_code  CBS_COLLECTION_DETAIL_TRAN.INSTITUTION_CODE%TYPE) RETURN  VARCHAR;
  FUNCTION  Sf_Musteri_Adi( pn_musteri_no CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE) RETURN VARCHAR2;
  PROCEDURE Sp_Musteri_No_Bul_Bireysel(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_BIREYSEL_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_BIREYSEL_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_BIREYSEL_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE  ,
  						ps_kimlik_id CBS_MUSTERI_BIREYSEL_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2);
  FUNCTION  Sf_Musteri_Adi_Kurumsal( pn_musteri_no CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE) RETURN VARCHAR2;
  FUNCTION  Sf_Musteri_Adi_Banka( pn_musteri_no CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE) RETURN VARCHAR2;
  PROCEDURE Sp_Musteri_No_Bul_Kurumsal(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_KURUMSAL_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_KURUMSAL_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_KURUMSAL_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE,
  						ps_kimlik_id CBS_MUSTERI_KURUMSAL_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2);
  PROCEDURE Sp_Musteri_No_Bul_Banka(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_BANKA_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_BANKA_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_BANKA_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE,
  						ps_kimlik_id CBS_MUSTERI_BANKA_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2);
  PROCEDURE Document_Insert_B(pn_musteri_no CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_BIREYSEL_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_B.yaratildigi_tarih%TYPE);
  PROCEDURE Document_Insert_K(pn_musteri_no CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_KURUMSAL_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_K.yaratildigi_tarih%TYPE);
  PROCEDURE Document_Insert_N(pn_musteri_no CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_BANKA_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_N.yaratildigi_tarih%TYPE);
  FUNCTION  Grup_Kodu_Bul( pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;
  FUNCTION  CashName( pn_cash_code CBS_NAKIT_KODLARI.KOD%TYPE) RETURN VARCHAR2;
 PROCEDURE hesap_bakiye_olustur( pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE,pn_bakiye_karakteri  CBS_HESAP_BAKIYE.bakiye_karakteri%TYPE DEFAULT NULL) ;
 FUNCTION  Find_Code_Cust_No( pn_custno CBS_HESAP.MUSTERI_NO%TYPE) RETURN  VARCHAR ;
END;


/

