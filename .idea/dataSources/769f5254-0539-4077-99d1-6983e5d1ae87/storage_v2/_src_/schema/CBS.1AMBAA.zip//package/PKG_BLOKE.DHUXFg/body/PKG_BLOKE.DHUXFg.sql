create PACKAGE BODY     "PKG_BLOKE" IS

/***************************************************************************************************************/
 /*   Procedure Sp_Bloke_Bilgi_Al                                                                                       */
 /****************************************************************************************************************/
   PROCEDURE Sp_Bloke_Bilgi_Al(pn_ref_tx_no CBS_BLOKE_ISLEM.ref_tx_no%TYPE,
                                 pn_bloke_tutari OUT CBS_BLOKE_ISLEM.bloke_tutari%TYPE,
                             ps_bloke_referans OUT CBS_BLOKE_ISLEM.bloke_referans%TYPE)
   IS
   BEGIN

        SELECT bloke_tutari,bloke_referans
       INTO   pn_bloke_tutari,ps_bloke_referans
       FROM   CBS_BLOKE_ISLEM
       WHERE  internal_ref_no =  pn_ref_tx_no;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '431' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
    END Sp_Bloke_Bilgi_Al;

/***************************************************************************************************************/
 /*   Procedure Sp_Bloke_Ana_Tabloya_Aktar                                                                                       */
 /****************************************************************************************************************/

  PROCEDURE Sp_Bloke_Ana_Tabloya_Aktar(pn_tx_no CBS_BLOKE_ISLEM.tx_no%TYPE)
   IS
   BEGIN
           INSERT INTO CBS_BLOKE( MUSTERI_NO,
                                  HESAP_NO,
                               DOVIZ_KODU,
                               DURUM_KODU,
                               BLOKE_TUTARI,
                               BLOKE_REFERANS,
                               BLOKE_NEDEN_KODU,
                               ACIKLAMA,
                               ISLEM_TANIM_KOD,
                               BLOKE_TARIHI,
                               BLOKE_BITIS_TARIHI,
                               REF_TX_NO ,
                               KAYIT_TARIH,
                                KAYIT_SISTEM_TARIHI,
                                KAYIT_KULLANICI_KODU,
                                KAYIT_KULLANICI_BOLUM_KODU,
                                DOGRU_TARIH,
                                DOGRU_KULLANICI_KODU,
                                DOGRU_KULLANICI_BOLUM_KODU,
                                ONAY_TARIH,
                                ONAY_SISTEM_TARIHI,
                                ONAY_KULLANICI_KODU,
                                ONAY_KULLANICI_BOLUM_KODU,
                                COZ_KAYIT_TARIH,
                                COZ_KAYIT_SISTEM_TARIH,
                                COZ_KAYIT_KULLANICI_KODU,
                                COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                COZ_DOGRU_TARIH,
                                COZ_DOGRU_KULLANICI_KODU,
                                COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                COZ_ONAY_TARIH,
                                COZ_ONAY_SISTEM_TARIH,
                                COZ_ONAY_KULLANICI_KODU,
                                COZ_ONAY_KULLANICI_BOLUM_KODU    ,
                                  internal_ref_no
                               )
                    SELECT    MUSTERI_NO,
                                  HESAP_NO,
                               DOVIZ_KODU,
                               DURUM_KODU,
                               BLOKE_TUTARI,
                               BLOKE_REFERANS,
                               BLOKE_NEDEN_KODU,
                               ACIKLAMA,
                               ISLEM_TANIM_KOD,
                               BLOKE_TARIHI,
                               BLOKE_BITIS_TARIHI,
                               REF_TX_NO ,
                                   KAYIT_TARIH,
                                KAYIT_SISTEM_TARIHI,
                                KAYIT_KULLANICI_KODU,
                                KAYIT_KULLANICI_BOLUM_KODU,
                                NVL(DOGRU_TARIH,ONAY_TARIH),
                                NVL(DOGRU_KULLANICI_KODU,ONAY_KULLANICI_KODU),
                                NVL(DOGRU_KULLANICI_BOLUM_KODU,ONAY_KULLANICI_BOLUM_KODU),
                                ONAY_TARIH,
                                ONAY_SISTEM_TARIHI,
                                ONAY_KULLANICI_KODU,
                                ONAY_KULLANICI_BOLUM_KODU,
                                COZ_KAYIT_TARIH,
                                COZ_KAYIT_SISTEM_TARIH,
                                COZ_KAYIT_KULLANICI_KODU,
                                COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                COZ_DOGRU_TARIH,
                                COZ_DOGRU_KULLANICI_KODU,
                                COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                COZ_ONAY_TARIH,
                                COZ_ONAY_SISTEM_TARIH,
                                COZ_ONAY_KULLANICI_KODU,
                                COZ_ONAY_KULLANICI_BOLUM_KODU,
                                internal_ref_no

                   FROM CBS_BLOKE_ISLEM
                   WHERE tx_no = pn_tx_no ;
    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '439' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END Sp_Bloke_Ana_Tabloya_Aktar;


/***************************************************************************************************************/
 /*   Procedure  Sp_Bloke_Guncelle                                                                                       */
 /****************************************************************************************************************/

 PROCEDURE Sp_Bloke_IslemTablosuna_Aktar(ps_bloke_referans CBS_BLOKE.bloke_referans%TYPE ,
                                             pn_tx_no CBS_BLOKE_ISLEM.tx_no%TYPE,
                                         ps_durum_kodu CBS_BLOKE_ISLEM.durum_kodu%TYPE DEFAULT 'BG',
                                         ps_islem_tanim_kod NUMBER DEFAULT 1201 )
 IS
 BEGIN
             INSERT INTO CBS_BLOKE_ISLEM(tx_no,
                                         MUSTERI_NO,
                                       HESAP_NO,
                                       DOVIZ_KODU,
                                       DURUM_KODU,
                                       BLOKE_TUTARI,
                                       BLOKE_REFERANS,
                                       BLOKE_NEDEN_KODU,
                                       ACIKLAMA, ISLEM_TANIM_KOD,
                                       BLOKE_TARIHI,
                                       BLOKE_BITIS_TARIHI,
                                       REF_TX_NO, KAYIT_TARIH,
                                       KAYIT_SISTEM_TARIHI,
                                       KAYIT_KULLANICI_KODU,
                                       KAYIT_KULLANICI_BOLUM_KODU,
                                       DOGRU_TARIH,
                                       DOGRU_KULLANICI_KODU,
                                       DOGRU_KULLANICI_BOLUM_KODU,
                                       ONAY_TARIH,
                                       ONAY_SISTEM_TARIHI,
                                       ONAY_KULLANICI_KODU,
                                       ONAY_KULLANICI_BOLUM_KODU,
                                       COZ_KAYIT_TARIH,
                                       COZ_KAYIT_SISTEM_TARIH,
                                       COZ_KAYIT_KULLANICI_KODU,
                                       COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                       COZ_DOGRU_TARIH, COZ_DOGRU_KULLANICI_KODU,
                                       COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                       COZ_ONAY_TARIH,
                                       COZ_ONAY_SISTEM_TARIH,
                                       COZ_ONAY_KULLANICI_KODU,
                                       COZ_ONAY_KULLANICI_BOLUM_KODU,
                                       INTERNAL_REF_NO     )

                              SELECT  pn_tx_no,
                                      MUSTERI_NO,
                                      HESAP_NO,
                                      DOVIZ_KODU,
                                      ps_durum_kodu,
                                      BLOKE_TUTARI,
                                      BLOKE_REFERANS,
                                      BLOKE_NEDEN_KODU,
                                      ACIKLAMA, ISLEM_TANIM_KOD,
                                      BLOKE_TARIHI,
                                      BLOKE_BITIS_TARIHI,
                                      internal_ref_no,
                                      KAYIT_TARIH,
                                      KAYIT_SISTEM_TARIHI,
                                      KAYIT_KULLANICI_KODU,
                                      KAYIT_KULLANICI_BOLUM_KODU,
                                      DOGRU_TARIH, DOGRU_KULLANICI_KODU,
                                      DOGRU_KULLANICI_BOLUM_KODU,
                                      ONAY_TARIH, ONAY_SISTEM_TARIHI,
                                      ONAY_KULLANICI_KODU,
                                      ONAY_KULLANICI_BOLUM_KODU,
                                      COZ_KAYIT_TARIH,
                                      COZ_KAYIT_SISTEM_TARIH,
                                      COZ_KAYIT_KULLANICI_KODU,
                                      COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                      COZ_DOGRU_TARIH,
                                      COZ_DOGRU_KULLANICI_KODU,
                                      COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                      COZ_ONAY_TARIH,
                                      COZ_ONAY_SISTEM_TARIH,
                                      COZ_ONAY_KULLANICI_KODU,
                                      COZ_ONAY_KULLANICI_BOLUM_KODU,
                                      Pkg_Genel.genel_kod_al( 'BLOKE_REF_NO')
          FROM CBS_BLOKE
          WHERE bloke_referans = ps_bloke_referans ;

 END;




  PROCEDURE Sp_Bloke_Guncelle(pn_tx_no CBS_BLOKE_ISLEM.tx_no%TYPE)
  IS
         ln_ref_tx_no                 CBS_BLOKE.ref_tx_no%TYPE;
       ls_bloke_referans            CBS_BLOKE.bloke_referans%TYPE;
       ln_adet                        NUMBER := 0 ;
       ls_yeni_referans            CBS_BLOKE.bloke_referans%TYPE;
   BEGIN

           SELECT BLOKE_REFERANS
        INTO ls_yeni_referans
        FROM CBS_BLOKE_ISLEM
        WHERE tx_no = pn_tx_no;

        BEGIN
            SELECT COUNT(*)
            INTO ln_adet
            FROM CBS_BLOKE
            WHERE  BLOKE_REFERANS = ls_yeni_referans;
        EXCEPTION WHEN OTHERS THEN NULL;
        END ;

        IF  NVL(ln_adet,0)<> 0 THEN
           UPDATE CBS_BLOKE
              SET              (MUSTERI_NO,
                          HESAP_NO,
                          DOVIZ_KODU,
                          DURUM_KODU,
                          BLOKE_TUTARI,
                          BLOKE_REFERANS,
                          BLOKE_NEDEN_KODU,
                          ACIKLAMA,
                          ISLEM_TANIM_KOD,
                          BLOKE_TARIHI,
                          BLOKE_BITIS_TARIHI,
                          REF_TX_NO,
                          KAYIT_SISTEM_TARIHI,
                        KAYIT_KULLANICI_KODU,
                        KAYIT_KULLANICI_BOLUM_KODU,
                        DOGRU_TARIH,
                        DOGRU_KULLANICI_KODU,
                        DOGRU_KULLANICI_BOLUM_KODU,
                        ONAY_TARIH,
                        ONAY_SISTEM_TARIHI,
                        ONAY_KULLANICI_KODU,
                        ONAY_KULLANICI_BOLUM_KODU,
                        COZ_KAYIT_TARIH,
                        COZ_KAYIT_SISTEM_TARIH,
                        COZ_KAYIT_KULLANICI_KODU,
                        COZ_KAYIT_KULLANICI_BOLUM_KODU,
                        COZ_DOGRU_TARIH,
                        COZ_DOGRU_KULLANICI_KODU,
                        COZ_DOGRU_KULLANICI_BOLUM_KODU,
                        COZ_ONAY_TARIH,
                        COZ_ONAY_SISTEM_TARIH,
                        COZ_ONAY_KULLANICI_KODU,
                        COZ_ONAY_KULLANICI_BOLUM_KODU     )
              =
                    (SELECT    MUSTERI_NO,
                                  HESAP_NO,
                               DOVIZ_KODU,
                               DURUM_KODU,
                               BLOKE_TUTARI,
                               BLOKE_REFERANS,
                               BLOKE_NEDEN_KODU,
                               ACIKLAMA,
                               ISLEM_TANIM_KOD,
                               BLOKE_TARIHI,
                               BLOKE_BITIS_TARIHI,
                               REF_TX_NO ,
                               KAYIT_SISTEM_TARIHI,
                                KAYIT_KULLANICI_KODU,
                                KAYIT_KULLANICI_BOLUM_KODU,
                                DOGRU_TARIH,
                                DOGRU_KULLANICI_KODU,
                                DOGRU_KULLANICI_BOLUM_KODU,
                                ONAY_TARIH,
                                ONAY_SISTEM_TARIHI,
                                ONAY_KULLANICI_KODU,
                                ONAY_KULLANICI_BOLUM_KODU,
                                COZ_KAYIT_TARIH,
                                COZ_KAYIT_SISTEM_TARIH,
                                COZ_KAYIT_KULLANICI_KODU,
                                COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                COZ_DOGRU_TARIH,
                                COZ_DOGRU_KULLANICI_KODU,
                                COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                COZ_ONAY_TARIH,
                                COZ_ONAY_SISTEM_TARIH,
                                COZ_ONAY_KULLANICI_KODU,
                                COZ_ONAY_KULLANICI_BOLUM_KODU
                    FROM CBS_BLOKE_ISLEM
                      WHERE tx_no = pn_tx_no )
             WHERE bloke_referans  = ls_yeni_referans;
        ELSE

           INSERT INTO  CBS_BLOKE
                          (MUSTERI_NO,
                       HESAP_NO,
                       DOVIZ_KODU,
                       DURUM_KODU,
                       BLOKE_TUTARI,
                       BLOKE_REFERANS,
                       BLOKE_NEDEN_KODU,
                       ACIKLAMA,
                       ISLEM_TANIM_KOD,
                       BLOKE_TARIHI,
                       BLOKE_BITIS_TARIHI,
                       REF_TX_NO,
                       KAYIT_SISTEM_TARIHI,
                        KAYIT_KULLANICI_KODU,
                        KAYIT_KULLANICI_BOLUM_KODU,
                        DOGRU_TARIH,
                        DOGRU_KULLANICI_KODU,
                        DOGRU_KULLANICI_BOLUM_KODU,
                        ONAY_TARIH,
                        ONAY_SISTEM_TARIHI,
                        ONAY_KULLANICI_KODU,
                        ONAY_KULLANICI_BOLUM_KODU,
                        COZ_KAYIT_TARIH,
                        COZ_KAYIT_SISTEM_TARIH,
                        COZ_KAYIT_KULLANICI_KODU,
                        COZ_KAYIT_KULLANICI_BOLUM_KODU,
                        COZ_DOGRU_TARIH,
                        COZ_DOGRU_KULLANICI_KODU,
                        COZ_DOGRU_KULLANICI_BOLUM_KODU,
                        COZ_ONAY_TARIH,
                        COZ_ONAY_SISTEM_TARIH,
                        COZ_ONAY_KULLANICI_KODU,
                        COZ_ONAY_KULLANICI_BOLUM_KODU     )
                    SELECT    MUSTERI_NO,
                                  HESAP_NO,
                               DOVIZ_KODU,
                               DURUM_KODU,
                               BLOKE_TUTARI,
                               BLOKE_REFERANS,
                               BLOKE_NEDEN_KODU,
                               ACIKLAMA,
                               ISLEM_TANIM_KOD,
                               BLOKE_TARIHI,
                               BLOKE_BITIS_TARIHI,
                               REF_TX_NO ,
                               KAYIT_SISTEM_TARIHI,
                                KAYIT_KULLANICI_KODU,
                                KAYIT_KULLANICI_BOLUM_KODU,
                                DOGRU_TARIH,
                                DOGRU_KULLANICI_KODU,
                                DOGRU_KULLANICI_BOLUM_KODU,
                                ONAY_TARIH,
                                ONAY_SISTEM_TARIHI,
                                ONAY_KULLANICI_KODU,
                                ONAY_KULLANICI_BOLUM_KODU,
                                COZ_KAYIT_TARIH,
                                COZ_KAYIT_SISTEM_TARIH,
                                COZ_KAYIT_KULLANICI_KODU,
                                COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                COZ_DOGRU_TARIH,
                                COZ_DOGRU_KULLANICI_KODU,
                                COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                COZ_ONAY_TARIH,
                                COZ_ONAY_SISTEM_TARIH,
                                COZ_ONAY_KULLANICI_KODU,
                                COZ_ONAY_KULLANICI_BOLUM_KODU
                    FROM CBS_BLOKE_ISLEM
                      WHERE tx_no = pn_tx_no
                      AND bloke_referans  = ls_yeni_referans;

        END IF;

             SELECT bloke_referans
            INTO ls_bloke_referans
            FROM CBS_BLOKE_ISLEM
                WHERE internal_ref_no IN (
                      SELECT ref_tx_no
                      FROM CBS_BLOKE_ISLEM
                      WHERE tx_no = pn_tx_no );

              UPDATE CBS_BLOKE
              SET              (MUSTERI_NO,
                          HESAP_NO,
                          DOVIZ_KODU,
                          DURUM_KODU,
                          BLOKE_TUTARI,
                          BLOKE_REFERANS,
                          BLOKE_NEDEN_KODU,
                          ACIKLAMA,
                          ISLEM_TANIM_KOD,
                          BLOKE_TARIHI,
                          BLOKE_BITIS_TARIHI,
                          REF_TX_NO,
                          KAYIT_SISTEM_TARIHI,
                        KAYIT_KULLANICI_KODU,
                        KAYIT_KULLANICI_BOLUM_KODU,
                        DOGRU_TARIH,
                        DOGRU_KULLANICI_KODU,
                        DOGRU_KULLANICI_BOLUM_KODU,
                        ONAY_TARIH,
                        ONAY_SISTEM_TARIHI,
                        ONAY_KULLANICI_KODU,
                        ONAY_KULLANICI_BOLUM_KODU,
                        COZ_KAYIT_TARIH,
                        COZ_KAYIT_SISTEM_TARIH,
                        COZ_KAYIT_KULLANICI_KODU,
                        COZ_KAYIT_KULLANICI_BOLUM_KODU,
                        COZ_DOGRU_TARIH,
                        COZ_DOGRU_KULLANICI_KODU,
                        COZ_DOGRU_KULLANICI_BOLUM_KODU,
                        COZ_ONAY_TARIH,
                        COZ_ONAY_SISTEM_TARIH,
                        COZ_ONAY_KULLANICI_KODU,
                        COZ_ONAY_KULLANICI_BOLUM_KODU     )
              =
                    (SELECT    MUSTERI_NO,
                                  HESAP_NO,
                               DOVIZ_KODU,
                               DURUM_KODU,
                               BLOKE_TUTARI,
                               BLOKE_REFERANS,
                               BLOKE_NEDEN_KODU,
                               ACIKLAMA,
                               ISLEM_TANIM_KOD,
                               BLOKE_TARIHI,
                               BLOKE_BITIS_TARIHI,
                               REF_TX_NO ,
                               KAYIT_SISTEM_TARIHI,
                                KAYIT_KULLANICI_KODU,
                                KAYIT_KULLANICI_BOLUM_KODU,
                                DOGRU_TARIH,
                                DOGRU_KULLANICI_KODU,
                                DOGRU_KULLANICI_BOLUM_KODU,
                                ONAY_TARIH,
                                ONAY_SISTEM_TARIHI,
                                ONAY_KULLANICI_KODU,
                                ONAY_KULLANICI_BOLUM_KODU,
                                COZ_KAYIT_TARIH,
                                COZ_KAYIT_SISTEM_TARIH,
                                COZ_KAYIT_KULLANICI_KODU,
                                COZ_KAYIT_KULLANICI_BOLUM_KODU,
                                COZ_DOGRU_TARIH,
                                COZ_DOGRU_KULLANICI_KODU,
                                COZ_DOGRU_KULLANICI_BOLUM_KODU,
                                COZ_ONAY_TARIH,
                                COZ_ONAY_SISTEM_TARIH,
                                COZ_ONAY_KULLANICI_KODU,
                                COZ_ONAY_KULLANICI_BOLUM_KODU
                    FROM CBS_BLOKE_ISLEM
                      WHERE tx_no = pn_tx_no )
             WHERE bloke_referans  = ls_bloke_referans;




    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '498' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END  Sp_Bloke_Guncelle;




 /*****************************************************************************************************************/
 /*   Function Bloke_ReferansNo_Al                                                                                      */
 /*   Girilen sube koduna bagli olarak referans numarasi alinir                                                                                                       */
 /*****************************************************************************************************************/
 FUNCTION  Sf_Bloke_ReferansNo_Al (ps_BOLUM_KODU    VARCHAR2     DEFAULT    Pkg_Baglam.bolum_kodu ) RETURN VARCHAR2
  IS
     ls_bolum_kodu   CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_referans     VARCHAR2(20);
     ln_sira_no      NUMBER := 0;
   BEGIN

/* islemi yaratan kullanicinin bolum kodu alinir . */
     ls_bolum_kodu := NVL(ps_BOLUM_KODU,Pkg_Baglam.bolum_kodu) ;
     ls_referans := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  ||'.' || ls_bolum_kodu || '.BLK';
     ln_sira_no := Pkg_Genel.genel_kod_al(ls_referans);
     ls_referans := ls_referans || '.' ||LPAD(ln_sira_no,8,0);--aisuluud 5647 defect from 6 to 8

     RETURN ls_referans;

    EXCEPTION
      WHEN OTHERS THEN
        log_at('Sf_Bloke_ReferansNo_Al', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '251' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END Sf_Bloke_ReferansNo_Al;


  /*****************************************************************************************************************/
  /*   Function    Sf_Bloke_Nedeni_Al                                                                                     */
  /*   Bloke nedenin aciklamasi alinir                                                                                 */
  /****************************************************************************************************************/
   FUNCTION Sf_Bloke_Nedeni_Al( ps_bloke_neden_kodu CBS_BLOKE_NEDEN_KODLARI.bloke_neden_kodu%TYPE ) RETURN CBS_BLOKE_NEDEN_KODLARI.aciklama%TYPE
   IS
     ls_aciklama   CBS_BLOKE_NEDEN_KODLARI.aciklama%TYPE ;
    BEGIN

       SELECT aciklama
       INTO   ls_aciklama
       FROM   CBS_BLOKE_NEDEN_KODLARI
       WHERE  bloke_neden_kodu =  ps_bloke_neden_kodu;

       RETURN ls_aciklama;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '427' || Pkg_Hata.getUCPOINTER);
    END Sf_Bloke_Nedeni_Al;

  /*****************************************************************************************************************/
  /*   Function    Sf_Onay_Bekleyen_Varmi                                                                                 */
  /*   onay bekleyen islem varsa ,numarasi dondurulur                                                             */
  /****************************************************************************************************************/
 FUNCTION  Sf_Onay_Bekleyen_Varmi( pn_hesap_no CBS_BLOKE_ISLEM.hesap_no%TYPE ,pn_islem_tanim_kod  CBS_BLOKE_ISLEM.islem_tanim_kod%TYPE ,pn_tx_no NUMBER DEFAULT 0 ) RETURN CBS_BLOKE_ISLEM.tx_no%TYPE
   IS
     ln_tx_no   CBS_BLOKE_ISLEM.tx_no%TYPE  := 0;
     onayda_bekleyen_islem_var          EXCEPTION;
    BEGIN

       SELECT  MIN(tx_no)
       INTO    ln_tx_no
       FROM   CBS_BLOKE_ISLEM a , CBS_ISLEM b
       WHERE   b.numara = a.tx_no  AND
                  a.hesap_no =pn_hesap_no AND
                -- Pkg_Tx.ISLEM_BITMIS_MI(b.numara)= 0 AND sevalb 121005
              b.durum IN ('C','V','1') AND
              a.islem_tanim_kod = pn_islem_tanim_kod AND
              a.tx_no <> pn_tx_no;

       IF  NVL(ln_tx_no,0) <> 0 THEN
              RAISE     onayda_bekleyen_islem_var;
       END IF;

       RETURN ln_tx_no ;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 0;
      WHEN onayda_bekleyen_islem_var THEN
               RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '429' ||Pkg_Hata.getdelimiter|| ln_tx_no  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '427' || Pkg_Hata.getUCPOINTER);
  END Sf_Onay_Bekleyen_Varmi;

  /*****************************************************************************************************************/
  /*   Function    Sf_Hesap_Bloke_Konan_Urunmu                                                                                     */
  /*   Bloke konulabilen urunler icerisinde degilse lov de gorulmeyecektir.                                                                                 */
  /****************************************************************************************************************/
   FUNCTION Sf_Hesap_Bloke_Konan_Urunmu(pn_hesap_no CBS_BLOKE_ISLEM.hesap_no%TYPE ) RETURN VARCHAR2
   IS
     ln_adet NUMBER;
    BEGIN

/* bloke konulmayan urunler asagidaki kosul kismina eklenir */

        SELECT  1
       INTO    ln_adet
       FROM    CBS_VW_HESAP_IZLEME
       WHERE   modul_tur_kod IN ( 'CURRENT','TIME DEP.') AND
                 (   urun_tur_kod IN ( 'FORWARD','SPOT','SWAP','SWAP-FW',
                                           'NOSTRO-LC','NOSTRO-FC' ,'LOAN','PLACEMENT',
                                     'CASH COLL.') --MederT 22.10.2013 CQDB00000515-Blocking collateral accounts of the customers issue - excluded 'COLLATERAL'
                OR 
                ( urun_tur_kod  ='DEMAND DEP' and urun_sinif_kod in ('OVERBALANCE-LC','OVERBALANCE-FC') )
                )
              AND hesap_no =pn_hesap_no;

        IF NVL(ln_adet,0) = 0 THEN
           RETURN 'E';
        ELSE
           RETURN 'H';
        END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 'E';
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '427' || Pkg_Hata.getUCPOINTER);
    END Sf_Hesap_Bloke_Konan_Urunmu;



  /*****************************************************************************************************************/
  /*   Function    Sf_Hesapdan_Bloke_RefNo_Al                                                                              */
  /*   Hesabin minimum bloke referans numarasi alinir.                                                               */
  /****************************************************************************************************************/
   FUNCTION Sf_Hesapdan_RefNo_Al(pn_hesap_no CBS_BLOKE_ISLEM.hesap_no%TYPE  ) RETURN  CBS_BLOKE_ISLEM.ref_tx_no%TYPE
   IS
     ln_ref_tx_no   CBS_BLOKE_ISLEM.ref_tx_no%TYPE := 0;
   BEGIN

  /* bloke islem referans numarasi bulunur */
        SELECT MIN(tx_no)
       INTO   ln_ref_tx_no
       FROM   CBS_BLOKE_ISLEM
       WHERE  hesap_no = pn_hesap_no
                 AND islem_tanim_kod = 1200
              AND Pkg_Tx.islem_onaylanmis_mi(tx_no)= 0
              AND durum_kodu IN ( 'A');
       RETURN ln_ref_tx_no ;
    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '430' || Pkg_Hata.getUCPOINTER);
    END Sf_Hesapdan_RefNo_Al;


 /***************************************************************************************************************/
 /*   Function Sf_Bloke_Yeni_Tutari                                                                                       */
 /*   Guncelleme kaydinin tutar bilgisi almak icin kullanildi. Gonderilen bloke isleminin tutar bilgisi verir.*/
 /****************************************************************************************************************/
  FUNCTION Sf_Bloke_Yeni_Tutari(pn_tx_no CBS_BLOKE_ISLEM.tx_no%TYPE ) RETURN  CBS_BLOKE_ISLEM.bloke_tutari%TYPE
  IS
  ln_bloke_tutari CBS_BLOKE_ISLEM.bloke_tutari%TYPE;

   BEGIN

       SELECT bloke_tutari
      INTO   ln_bloke_tutari
      FROM   CBS_BLOKE_ISLEM
      WHERE  tx_no = pn_tx_no
               AND durum_kodu IN ( 'A','K');

        RETURN   ln_bloke_tutari ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '437' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
    END Sf_Bloke_Yeni_Tutari;

  /***************************************************************************************************************/
 /*   Function Sf_Yeni_Bloke_Referansi                                                                                   */
 /*   Guncelleme kaydinin bloke referans bilgisini almak icin hazirlandi.                                         */
 /****************************************************************************************************************/
  FUNCTION Sf_Yeni_Bloke_Referansi(pn_tx_no CBS_BLOKE_ISLEM.tx_no%TYPE ) RETURN  CBS_BLOKE_ISLEM.bloke_referans%TYPE
  IS
  ls_bloke_referans CBS_BLOKE_ISLEM.bloke_referans%TYPE;

   BEGIN

       SELECT bloke_referans
      INTO   ls_bloke_referans
      FROM   CBS_BLOKE_ISLEM
      WHERE  tx_no = pn_tx_no AND
               durum_kodu IN ( 'A','K');

        RETURN   ls_bloke_referans;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '438' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END Sf_Yeni_Bloke_Referansi;


 /***************************************************************************************************************/
 /*   Function Sf_Refereansdan_Bloke_Kodu_Al                                                                      */
 /*   Bloke referansi gonderilip bloke kodunun alinmasi                                                           */
 /**************************************************************************************************************/
 FUNCTION  Sf_Referansdan_Bloke_Kodu_Al(ps_bloke_ref_no CBS_BLOKE_ISLEM.bloke_referans%TYPE ) RETURN  CBS_BLOKE_ISLEM.bloke_neden_kodu%TYPE
  IS
  ls_bloke_referans CBS_BLOKE_ISLEM.bloke_referans%TYPE;

   BEGIN

       SELECT bloke_neden_kodu
      INTO   ls_bloke_referans
      FROM   CBS_BLOKE_ISLEM
      WHERE  bloke_referans = ps_bloke_ref_no ;

        RETURN   ls_bloke_referans;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '443' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END Sf_Referansdan_Bloke_Kodu_Al;

 /***************************************************************************************************************/
 /*   Function Sf_Referansdan_Aciklama_Al                                                                  */
 /*   Bloke referansi gonderilip aciklamanin alinmasi                                                           */
 /**************************************************************************************************************/
 FUNCTION  Sf_Referansdan_Aciklama_Al(pn_bloke_ref_no CBS_BLOKE_ISLEM.bloke_referans%TYPE ) RETURN  CBS_BLOKE_ISLEM.aciklama%TYPE
  IS
  ls_aciklama CBS_BLOKE_ISLEM.aciklama%TYPE;

   BEGIN

       SELECT aciklama
      INTO   ls_aciklama
      FROM   CBS_BLOKE_ISLEM
      WHERE  bloke_referans = pn_bloke_ref_no ;

        RETURN   ls_aciklama;

    EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '444' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END Sf_Referansdan_Aciklama_Al;

 /***************************************************************************************************************/
 /*   Function Sf_BlokeRefden_IslemRefNo_Al                                                                               */
 /*   bloke referansi ile iilemin ref numarasi alinir                                                             */
 /****************************************************************************************************************/
  FUNCTION Sf_BlokeRefden_InternRefNo_Al(ps_bloke_ref_no CBS_BLOKE_ISLEM.bloke_referans%TYPE ) RETURN  CBS_BLOKE_ISLEM.ref_tx_no%TYPE
  IS
  ln_ref_tx_no CBS_BLOKE_ISLEM.ref_tx_no%TYPE;

   BEGIN

       SELECT MIN(internal_ref_no)
      INTO   ln_ref_tx_no
      FROM   CBS_BLOKE_ISLEM
      WHERE  bloke_referans = ps_bloke_ref_no;

        RETURN   ln_ref_tx_no  ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '274' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END ;

 /***************************************************************************************************************/
 /*   Function Sf_RefIslemden_IslemNoAl                                                                                  */
 /*   referans numarasinin kullanildiii islemin numarasi alinir                                                    */
 /***************************************************************************************************************/
  FUNCTION Sf_RefIslemden_IslemNoAl (pn_ref_tx_no CBS_BLOKE_ISLEM.ref_tx_no%TYPE ) RETURN  CBS_BLOKE_ISLEM.tx_no%TYPE
  IS
  ln_ref_tx_no CBS_BLOKE_ISLEM.ref_tx_no%TYPE;

   BEGIN

       SELECT MAX(tx_no)
      INTO   ln_ref_tx_no
      FROM   CBS_BLOKE_ISLEM
      WHERE  ref_tx_no = pn_ref_tx_no;

        RETURN   ln_ref_tx_no  ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '275' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END  Sf_RefIslemden_IslemNoAl;


 /***************************************************************************************************************/
 /*   Function Sf_Bloke_Sorgula                                                                                          */
 /*   Bloke guncellemesi iiin bir onceki islemin numarasi gonderilerek rowidsi alinir.                            */
 /***************************************************************************************************************/
 FUNCTION  Sf_Bloke_Sorgula( pn_ref_no CBS_BLOKE_ISLEM.internal_ref_no%TYPE ) RETURN VARCHAR2
  IS
    ls_ret VARCHAR2(2000);
   BEGIN
            SELECT ROWID
            INTO ls_ret
            FROM CBS_BLOKE_ISLEM
            WHERE   internal_ref_no = pn_ref_no;

        RETURN ls_ret;

   EXCEPTION
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '450' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END;


 PROCEDURE sp_bloke_yarat(  ps_bloke_referans  IN OUT CBS_BLOKE.BLOKE_REFERANS%TYPE,
                                pn_MUSTERI_NO        CBS_BLOKE.MUSTERI_NO%TYPE,
                            pn_HESAP_NO            CBS_BLOKE.HESAP_NO%TYPE,
                            ps_DOVIZ_KODU        CBS_BLOKE.DOVIZ_KODU%TYPE,
                            pn_BLOKE_TUTARI        CBS_BLOKE.BLOKE_TUTARI%TYPE,
                            ps_BLOKE_NEDEN_KODU    CBS_BLOKE.BLOKE_NEDEN_KODU%TYPE,
                            ps_ACIKLAMA        CBS_BLOKE.ACIKLAMA%TYPE,
                            pd_BLOKE_TARIHI        CBS_BLOKE.BLOKE_TARIHI%TYPE,
                            pd_BLOKE_BITIS_TARIHI    CBS_BLOKE.BLOKE_BITIS_TARIHI%TYPE DEFAULT NULL,
                            pn_REF_TX_NO        CBS_BLOKE.REF_TX_NO%TYPE DEFAULT NULL,
                            pn_tx_no NUMBER DEFAULT NULL,
                            p_KAYIT_TARIH    DATE    DEFAULT Pkg_Muhasebe.banka_tarihi_bul,
                            p_KAYIT_SISTEM_TARIHI    DATE    DEFAULT SYSDATE,
                            p_KAYIT_KULLANICI_KODU    VARCHAR2 DEFAULT Pkg_Baglam.Kullanici_kodu,
                            p_KAYIT_KULLANICI_BOLUM_KODU    VARCHAR2 DEFAULT    Pkg_Baglam.bolum_kodu,
                            p_DOGRU_TARIH    DATE    DEFAULT Pkg_Muhasebe.banka_tarihi_bul,
                            p_DOGRU_KULLANICI_KODU    VARCHAR2 DEFAULT Pkg_Baglam.Kullanici_kodu,
                            p_DOGRU_KULLANICI_BOLUM_KODU    VARCHAR2     DEFAULT    Pkg_Baglam.bolum_kodu,
                            p_ONAY_TARIH    DATE    DEFAULT NULL,
                            p_ONAY_SISTEM_TARIHI    DATE    DEFAULT NULL,
                            p_ONAY_KULLANICI_KODU    VARCHAR2 DEFAULT NULL    ,
                            p_ONAY_KULLANICI_BOLUM_KODU    VARCHAR2 DEFAULT NULL    ,
                            p_COZ_KAYIT_TARIH    DATE    DEFAULT NULL,
                            p_COZ_KAYIT_SISTEM_TARIH    DATE DEFAULT NULL,
                            p_COZ_KAYIT_KULLANICI_KODU    VARCHAR2    DEFAULT NULL,
                            p_COZ_KAYIT_KULLANICI_BOLUMKOD    VARCHAR2 DEFAULT NULL,
                            p_COZ_DOGRU_TARIH    DATE DEFAULT NULL    ,
                            p_COZ_DOGRU_KULLANICI_KODU    VARCHAR2    DEFAULT NULL,
                            p_COZ_DOGRU_KULLANICI_BOLUMKOD    VARCHAR2 DEFAULT NULL    ,
                            p_COZ_ONAY_TARIH    DATE DEFAULT NULL    ,
                            p_COZ_ONAY_SISTEM_TARIH    DATE DEFAULT NULL    ,
                            p_COZ_ONAY_KULLANICI_KODU    VARCHAR2 DEFAULT NULL    ,
                            p_COZ_ONAY_KULLANICI_BOLUMKOD    VARCHAR2 DEFAULT NULL,
                            ps_kapama VARCHAR2 DEFAULT NULL
                            )
  IS
    ln_internal_ref_no  NUMBER;
    ln_bloke_tutar        NUMBER;
    ls_durum_kodu        CBS_BLOKE.durum_kodu%TYPE;
    ld_bloke_bitis_tarihi DATE;
    ls_bolum_kodu VARCHAR2(200) := NULL;
  BEGIN

log_at('sp_bloke_yarat-1',pn_tx_no,1,ps_bloke_referans);

     IF    ps_bloke_referans  IS NULL THEN
log_at('sp_bloke_yarat-2',pn_tx_no,2,ps_bloke_referans);
            IF pn_tx_no IS NOT NULL THEN
                   SELECT AMIR_BOLUM_KODU
                INTO ls_bolum_kodu
                   FROM CBS_ISLEM
                WHERE numara=  pn_tx_no;
            ELSE
                 ls_bolum_kodu := NVL(p_ONAY_KULLANICI_BOLUM_KODU,Pkg_Baglam.bolum_kodu);
            END IF;
log_at('sp_bloke_yarat-3',pn_tx_no,3,ps_bloke_referans);
           --BOM CQ528 MederT 04012016
           IF ps_BLOKE_NEDEN_KODU != 12 THEN
                ps_bloke_referans := Pkg_Bloke.sf_bloke_referansno_al(ls_bolum_kodu);
           ELSE
                ps_bloke_referans := Pkg_Bloke.Sf_TMP_Bloke_ReferansNo_Al(ls_bolum_kodu);
           END IF;
           --EOM CQ528 MederT 04012016
           ln_internal_ref_no :=  Pkg_Genel.genel_kod_al( 'BLOKE_REF_NO')    ;
           ln_bloke_tutar := Pn_bloke_tutari;
log_at('sp_bloke_yarat-4',pn_tx_no,4,ps_bloke_referans);
         /* hesap bloke tutari guncellenir */
         Pkg_Hesap.BlokeTutariGuncelle(Pn_hesap_no,ln_bloke_tutar);
log_at('sp_bloke_yarat-5',pn_tx_no,5,ps_bloke_referans);
        INSERT INTO CBS_BLOKE (
            MUSTERI_NO    ,
            HESAP_NO    ,
            DOVIZ_KODU    ,
            DURUM_KODU    ,
            BLOKE_TUTARI    ,
            BLOKE_REFERANS    ,
            BLOKE_NEDEN_KODU    ,
            ACIKLAMA    ,
            ISLEM_TANIM_KOD    ,
            BLOKE_TARIHI    ,
            BLOKE_BITIS_TARIHI    ,
            REF_TX_NO,
            KAYIT_TARIH,
            KAYIT_SISTEM_TARIHI,
            KAYIT_KULLANICI_KODU,
            KAYIT_KULLANICI_BOLUM_KODU,
            DOGRU_TARIH,
            DOGRU_KULLANICI_KODU,
            DOGRU_KULLANICI_BOLUM_KODU,
            ONAY_TARIH,
            ONAY_SISTEM_TARIHI,
            ONAY_KULLANICI_KODU,
            ONAY_KULLANICI_BOLUM_KODU,
            COZ_KAYIT_TARIH,
            COZ_KAYIT_SISTEM_TARIH,
            COZ_KAYIT_KULLANICI_KODU,
            COZ_KAYIT_KULLANICI_BOLUM_KODU,
            COZ_DOGRU_TARIH,
            COZ_DOGRU_KULLANICI_KODU,
            COZ_DOGRU_KULLANICI_BOLUM_KODU,
            COZ_ONAY_TARIH,
            COZ_ONAY_SISTEM_TARIH,
            COZ_ONAY_KULLANICI_KODU,
            COZ_ONAY_KULLANICI_BOLUM_KODU,
            internal_ref_no                )
            VALUES
        (    pn_MUSTERI_NO,
            pn_HESAP_NO,
            ps_DOVIZ_KODU,
            'A',
            pn_BLOKE_TUTARI,
            ps_BLOKE_REFERANS,
            ps_BLOKE_NEDEN_KODU,
            ps_ACIKLAMA,
            1200,
            pd_BLOKE_TARIHI,
            pd_BLOKE_BITIS_TARIHI,
            pn_REF_TX_NO,
            p_KAYIT_TARIH,
            p_KAYIT_SISTEM_TARIHI,
            p_KAYIT_KULLANICI_KODU,
            p_KAYIT_KULLANICI_BOLUM_KODU,
            p_DOGRU_TARIH,
            p_DOGRU_KULLANICI_KODU,
            p_DOGRU_KULLANICI_BOLUM_KODU,
            p_ONAY_TARIH,
            p_ONAY_SISTEM_TARIHI,
            p_ONAY_KULLANICI_KODU,
            p_ONAY_KULLANICI_BOLUM_KODU,
            p_COZ_KAYIT_TARIH,
            p_COZ_KAYIT_SISTEM_TARIH,
            p_COZ_KAYIT_KULLANICI_KODU,
            p_COZ_KAYIT_KULLANICI_BOLUMKOD,
            p_COZ_DOGRU_TARIH,
            p_COZ_DOGRU_KULLANICI_KODU,
            p_COZ_DOGRU_KULLANICI_BOLUMKOD,
            p_COZ_ONAY_TARIH,
            p_COZ_ONAY_SISTEM_TARIH,
            p_COZ_ONAY_KULLANICI_KODU,
            p_COZ_ONAY_KULLANICI_BOLUMKOD,
            ln_internal_ref_no
            );
    log_at('sp_bloke_yarat-6',pn_tx_no,6,ps_bloke_referans);
    IF pn_tx_no IS NOT NULL THEN
log_at('sp_bloke_yarat-7',pn_tx_no,7,ps_bloke_referans);
           INSERT INTO CBS_BLOKE_ISLEM (
            TX_NO,
            MUSTERI_NO    ,
            HESAP_NO    ,
            DOVIZ_KODU    ,
            DURUM_KODU    ,
            BLOKE_TUTARI    ,
            BLOKE_REFERANS    ,
            BLOKE_NEDEN_KODU    ,
            ACIKLAMA    ,
            ISLEM_TANIM_KOD    ,
            BLOKE_TARIHI    ,
            BLOKE_BITIS_TARIHI    ,
            REF_TX_NO,
            KAYIT_TARIH,
            KAYIT_SISTEM_TARIHI,
            KAYIT_KULLANICI_KODU,
            KAYIT_KULLANICI_BOLUM_KODU,
            DOGRU_TARIH,
            DOGRU_KULLANICI_KODU,
            DOGRU_KULLANICI_BOLUM_KODU,
            ONAY_TARIH,
            ONAY_SISTEM_TARIHI,
            ONAY_KULLANICI_KODU,
            ONAY_KULLANICI_BOLUM_KODU,
            COZ_KAYIT_TARIH,
            COZ_KAYIT_SISTEM_TARIH,
            COZ_KAYIT_KULLANICI_KODU,
            COZ_KAYIT_KULLANICI_BOLUM_KODU,
            COZ_DOGRU_TARIH,
            COZ_DOGRU_KULLANICI_KODU,
            COZ_DOGRU_KULLANICI_BOLUM_KODU,
            COZ_ONAY_TARIH,
            COZ_ONAY_SISTEM_TARIH,
            COZ_ONAY_KULLANICI_KODU,
            COZ_ONAY_KULLANICI_BOLUM_KODU,
            internal_ref_no
                )
            VALUES
        (    pn_tx_no,
            pn_MUSTERI_NO,
            pn_HESAP_NO,
            ps_DOVIZ_KODU,
            'A',
            pn_BLOKE_TUTARI,
            ps_BLOKE_REFERANS,
            ps_BLOKE_NEDEN_KODU,
            ps_ACIKLAMA,
            1200,
            pd_BLOKE_TARIHI,
            pd_BLOKE_BITIS_TARIHI,
            pn_REF_TX_NO,
            p_KAYIT_TARIH,
            p_KAYIT_SISTEM_TARIHI,
            p_KAYIT_KULLANICI_KODU,
            p_KAYIT_KULLANICI_BOLUM_KODU,
            p_DOGRU_TARIH,
            p_DOGRU_KULLANICI_KODU,
            p_DOGRU_KULLANICI_BOLUM_KODU,
            p_ONAY_TARIH,
            p_ONAY_SISTEM_TARIHI,
            p_ONAY_KULLANICI_KODU,
            p_ONAY_KULLANICI_BOLUM_KODU,
            p_COZ_KAYIT_TARIH,
            p_COZ_KAYIT_SISTEM_TARIH,
            p_COZ_KAYIT_KULLANICI_KODU,
            p_COZ_KAYIT_KULLANICI_BOLUMKOD,
            p_COZ_DOGRU_TARIH,
            p_COZ_DOGRU_KULLANICI_KODU,
            p_COZ_DOGRU_KULLANICI_BOLUMKOD,
            p_COZ_ONAY_TARIH,
            p_COZ_ONAY_SISTEM_TARIH,
            p_COZ_ONAY_KULLANICI_KODU,
            p_COZ_ONAY_KULLANICI_BOLUMKOD,
            ln_internal_ref_no
  );
log_at('sp_bloke_yarat-8',pn_tx_no,8,ps_bloke_referans);
     END IF;




   ELSE

    log_at('sp_bloke_yarat-9',pn_tx_no,9,ps_bloke_referans);

        SELECT   BLOKE_TUTARI,
                durum_kodu
        INTO   ln_bloke_tutar,
               ls_durum_kodu
        FROM   CBS_BLOKE
        WHERE  bloke_referans = ps_bloke_referans;

    log_at('sp_bloke_yarat-10',pn_tx_no,10,ps_bloke_referans);

     IF   ls_durum_kodu <> 'K' THEN
        IF NVL(pn_bloke_tutari,0 ) = 0  OR ps_kapama = 'KAPAMA' THEN
            ls_durum_kodu  := 'K' ;
            ld_BLOKE_BITIS_TARIHI := Pkg_Muhasebe.banka_tarihi_bul;
        ELSE
            ld_BLOKE_BITIS_TARIHI := NULL;
        END IF;

    log_at('sp_bloke_yarat-11',pn_tx_no,11,ps_bloke_referans);

           UPDATE CBS_BLOKE_ISLEM
        SET  DURUM_KODU   =  ls_durum_kodu,
        --     bloke_tutari =     ln_bloke_tutari,
             coz_kayit_tarih = p_coz_kayit_tarih ,
             coz_kayit_sistem_tarih =p_coz_kayit_sistem_tarih,
             coz_kayit_kullanici_kodu     =  p_coz_kayit_kullanici_kodu ,
             coz_kayit_kullanici_bolum_kodu = p_coz_kayit_kullanici_bolumkod,
             coz_dogru_tarih                  =  p_coz_dogru_tarih    ,
             coz_dogru_kullanici_kodu      = p_coz_dogru_kullanici_kodu,
             coz_dogru_kullanici_bolum_kodu = p_coz_dogru_kullanici_bolumkod,
             coz_onay_tarih                   =  p_coz_onay_tarih,
             coz_onay_sistem_tarih           =  p_coz_onay_sistem_tarih,
             coz_onay_kullanici_kodu       =  p_coz_onay_kullanici_kodu,
             coz_onay_kullanici_bolum_kodu  = p_coz_onay_kullanici_bolumkod,
             bloke_bitis_tarihi            =ld_bloke_bitis_tarihi
             WHERE  bloke_referans = ps_bloke_referans;

    log_at('sp_bloke_yarat-12',pn_tx_no,12,ps_bloke_referans);

           UPDATE CBS_BLOKE
        SET  DURUM_KODU   =  ls_durum_kodu,
--             bloke_tutari =     pn_bloke_tutari,
             coz_kayit_tarih = p_coz_kayit_tarih ,
             coz_kayit_sistem_tarih =p_coz_kayit_sistem_tarih,
             coz_kayit_kullanici_kodu     =  p_coz_kayit_kullanici_kodu ,
             coz_kayit_kullanici_bolum_kodu = p_coz_kayit_kullanici_bolumkod,
             coz_dogru_tarih                  =  p_coz_dogru_tarih    ,
             coz_dogru_kullanici_kodu      = p_coz_dogru_kullanici_kodu,
             coz_dogru_kullanici_bolum_kodu = p_coz_dogru_kullanici_bolumkod,
             coz_onay_tarih                   =  p_coz_onay_tarih,
             coz_onay_sistem_tarih           =  p_coz_onay_sistem_tarih,
             coz_onay_kullanici_kodu       =  p_coz_onay_kullanici_kodu,
             coz_onay_kullanici_bolum_kodu  = p_coz_onay_kullanici_bolumkod,
             bloke_bitis_tarihi            =ld_bloke_bitis_tarihi
             WHERE  bloke_referans = ps_bloke_referans;

    log_at('sp_bloke_yarat-13',pn_tx_no,13,ps_bloke_referans);
            IF NVL(pn_bloke_tutari,0) <> 0 THEN
                ln_bloke_tutar :=  NVL(pn_bloke_tutari,0) - NVL(ln_bloke_tutar,0) ;
            ELSE
                ln_bloke_tutar := -1 * NVL(ln_bloke_tutar,0);
            END IF;
    log_at('sp_bloke_yarat-14',pn_tx_no,ps_bloke_referans,Pn_hesap_no);

     Pkg_Hesap.BlokeTutariGuncelle(Pn_hesap_no,ln_bloke_tutar);
    log_at('sp_bloke_yarat-15',pn_tx_no,ps_bloke_referans,Pn_hesap_no);

   END IF;
  END IF;
log_at('sp_bloke_yarat-16',pn_tx_no,ps_bloke_referans,Pn_hesap_no);

    EXCEPTION
      WHEN OTHERS THEN
      log_at('sp_bloke_yarat-99',pn_tx_no,ps_bloke_referans,SUBSTR(TO_CHAR(SQLCODE )||SQLERRM,1,2000) );
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '534' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;

 PROCEDURE sp_bloke_tutar_durum_guncelle(ps_referans CBS_BLOKE.bloke_referans%TYPE ,ps_durum CBS_BLOKE.durum_kodu%TYPE DEFAULT NULL ,pn_tutar NUMBER DEFAULT NULL)
 IS
 CURSOR cursor_bloke IS
         SELECT  hesap_no,
                   bloke_tutari
        FROM CBS_BLOKE
        WHERE bloke_referans = ps_referans;
 BEGIN

  IF ps_durum IS NOT NULL THEN
        UPDATE CBS_BLOKE
       SET durum_kodu = ps_durum
       WHERE bloke_referans = ps_referans;

       UPDATE CBS_BLOKE_ISLEM
       SET durum_kodu = ps_durum
       WHERE bloke_referans = ps_referans;
    END IF;

   IF pn_tutar    IS NOT NULL THEN
      FOR cur_bloke IN cursor_bloke LOOP
          /* hesap bloke tutari guncellenir */
          Pkg_Hesap.BlokeTutariGuncelle(cur_bloke.hesap_no,pn_tutar);
      END LOOP;
   END IF;

    EXCEPTION
     WHEN NO_DATA_FOUND THEN NULL;
      WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '558' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

 END ;
 FUNCTION  sf_bloke_durum_kodu_al(ps_referans CBS_BLOKE_ISLEM.bloke_referans%TYPE ) RETURN  CBS_BLOKE.durum_kodu%TYPE
 IS
  ls_durum  CBS_BLOKE.durum_kodu%TYPE;
 BEGIN
         SELECT durum_kodu
        INTO ls_durum
        FROM CBS_BLOKE
        WHERE bloke_referans = ps_referans;

    RETURN     ls_durum ;

 EXCEPTION WHEN OTHERS THEN RETURN NULL;
 END;
 --BOM CQ528 MederT 04012016
 Function  Sf_TMP_Bloke_ReferansNo_Al (ps_BOLUM_KODU    VARCHAR2     DEFAULT    Pkg_Baglam.bolum_kodu ) return varchar2 
 IS
     ls_bolum_kodu   CBS_ISLEM.kayit_kullanici_bolum_kodu%TYPE;
     ls_referans     VARCHAR2(20);
     ln_sira_no      NUMBER := 0;
   BEGIN

/* islemi yaratan kullanicinin bolum kodu alinir . */
     ls_bolum_kodu := NVL(ps_BOLUM_KODU,Pkg_Baglam.bolum_kodu) ;
     ls_referans := TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'YY')  || TO_CHAR(Pkg_Muhasebe.banka_tarihi_bul,'mm')  ||'.' || ls_bolum_kodu || '.TMP';
     ln_sira_no := Pkg_Genel.genel_kod_al(ls_referans);
     ls_referans := ls_referans || '.' ||LPAD(ln_sira_no,6,0);--aisuluud 5647 defect from 6 to 8, from 8 to 6

     RETURN ls_referans;

    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '251' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END Sf_TMP_Bloke_ReferansNo_Al;
 --EOM CQ528 MederT 04012016
END;
/

