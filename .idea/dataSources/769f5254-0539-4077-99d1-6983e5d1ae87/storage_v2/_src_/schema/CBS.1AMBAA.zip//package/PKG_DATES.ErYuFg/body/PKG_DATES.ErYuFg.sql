create package body PKG_DATES is

  function is_work_day(DATE_ in DATE) return VARCHAR2
  is
  begin
    if PKG_TARIH.gun_ozellik(DATE_) = 0 THEN
	  return 'YES';
	else
	  return 'NO';
	end if;
  end;

  function get_next_work_date(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.ileri_is_gunu(DATE_);
  end;

  function get_previous_work_date(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.geri_is_gunu(DATE_, NULL);
  end;

  function get_first_work_day_in_week(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.haftanin_ilk_is_gunu(DATE_);
  end;

  function get_last_work_day_in_week(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.haftanin_son_is_gunu(DATE_);
  end;

  function get_last_work_day_in_month(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.ayin_son_is_gunu(DATE_);
  end;

  function get_first_work_day_in_month(DATE_ DATE) return DATE
  is
  begin
    return(PKG_DATES.get_next_work_date(PKG_REPORT2.FIRST_DAY(DATE_)-1));
  end;

  function get_last_work_day_in_quarter(NO_ NUMBER, YEAR_ NUMBER) return DATE
  is
  begin
	return PKG_TARIH.donemin_son_is_gunu(to_date('10'|| TO_CHAR(NO_*3, '99') ||TO_CHAR(YEAR_, '9999'), 'ddmmyyyy'));
  end;

  function get_first_work_day_in_quarter(NO_ NUMBER, YEAR_ NUMBER) return DATE
  is
  begin
    if NO_ = 1 then
	  return get_next_work_date(get_last_work_day_in_quarter(4, YEAR_-1));
	else
	  return get_next_work_date(get_last_work_day_in_quarter(NO_-1, YEAR_));
	end if;
  end;

  function get_last_work_day_in_year(DATE_ DATE) return DATE
  is
  begin
    return PKG_TARIH.yilin_son_is_gunu(DATE_);
  end;

  function get_first_work_day_in_year(DATE_ DATE) return DATE
  is
  begin
    return get_next_work_date(get_last_work_day_in_year(to_date(to_char(DATE_, 'ddmm')||to_char(to_number(to_char(DATE_, 'yyyy'))-1), 'ddmmyyyy')));
  end;


  function get_first_day_in_month(DATE_ DATE) return DATE
  is
    result DATE;
  begin
    select decode(to_number(to_char(DATE_, 'mm')), 1, to_date('0101'||to_char(DATE_, 'yyyy'), 'ddmmyyyy'), last_day(to_date('1'||'/'||to_char(to_number(to_char(DATE_, 'mm'))-1)||to_char(DATE_,'/yyyy'), 'dd/mm/yyyy'))+1)
	  into result
	  from dual;
    return result;
  end;

  function get_last_day_in_month(DATE_ DATE) return DATE
  is
  begin
    return trunc(last_day(DATE_));
  end;


------------------------------------------------------------------------------------------------------------------------
END PKG_DATES;
/

