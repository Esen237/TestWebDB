create PACKAGE BODY     PKG_TX1010 IS
Procedure Kontrol_Sonrasi(pn_islem_no number) is
  ln_total_count number;
  lnRM_TYPE number;
  lnRM_FROM_ID number;
  lnRM_TO_ID number;
  Begin
      select RM_TYPE,RM_FROM_ID,RM_TO_ID into  lnRM_TYPE,
      lnRM_FROM_ID,lnRM_TO_ID
      from cbs_customer_marketing_tx
      where tx_no=pn_islem_no and ROWNUM=1;
      select count(*) into ln_total_count from CBS.CBS_CUSTOMER_MARKETING_TX
      where tx_no=pn_islem_no;
        
      if lnRM_TYPE is null or lnRM_FROM_ID is null  or lnRM_TO_ID is null then
        raise_application_error(-20100,'Need to fill all RM fields');
      end if;
      
      if ln_total_count<9 then
        raise_application_error(-20100, 'There are not enough customers for a mass transfer. Please transfer through screen 1001');
      end if;
      Exception 
      WHEN NO_DATA_FOUND then
      raise_application_error(-20100, 'There are not enough customers for a mass transfer. Please transfer through screen 1001');
       
  End;
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;
  End;
Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;
  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
 null;
 End;
Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
Procedure Onay_Sonrasi(pn_islem_no number) is

    cursor transfer IS
    select CUSTOMER_ID,RM_TYPE,RM_TO_ID from CBS.CBS_CUSTOMER_MARKETING_TX
    where pn_islem_no=TX_NO;
    begin

    For rec in transfer
    loop
    IF( rec.RM_TYPE=1) then
    update CBS.CBS_MUSTERI SET PAZARLAMA_SORUMLUSU_SICIL_NO_1=rec.RM_TO_ID
    where rec.CUSTOMER_ID=MUSTERI_NO;
    ELSIF ( rec.RM_TYPE=2) then
    update CBS.CBS_MUSTERI SET PAZARLAMA_SORUMLUSU_SICIL_NO_2=rec.RM_TO_ID
    where rec.CUSTOMER_ID=MUSTERI_NO;

    END IF;
    end loop;

End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;
  End;
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
  Procedure Muhasebelesme(pn_islem_no number) is
    BEGIN
        null;
    End;
END;
/

