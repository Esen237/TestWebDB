create PACKAGE PKG_TX4103 IS

  /******************************************************************************
   Name       : PKG_TX4103
   Created By : Bilal GUL
   Date	   	  : 25/12/2003
   Purpose	  : TM / HG IADE
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

 Procedure TM_HG_Acilis_Bilgisi_Al(ps_referans CBS_TM_HG_ACILIS.REFERANS%type,
  								   ps_lehdar_musteri_no out CBS_TM_HG_ACILIS.lehdar_musteri_no%type,
								   PS_acilan_hesap_no out CBS_TM_HG_ACILIS.hesap_no%type,
								   ps_doviz_kodu out CBS_TM_HG_ACILIS.doviz_kodu%type,
								   ps_mektup_tutari out CBS_TM_HG_ACILIS.tutar%type,
								   ps_bakiye out CBS_TM_HG_ACILIS.bakiye%type,
								   ps_mektup_tipi out CBS_TM_HG_ACILIS.mektup_tipi%type,
								   ps_vade_tarihi out CBS_TM_HG_ACILIS.vade_tarihi%type,
								   ps_muhatap_musteri_no out CBS_TM_HG_ACILIS.muhatap_musteri_no%type,
								   ps_aciklama out CBS_TM_HG_ACILIS.aciklama%type,
								   ps_urun_sinif  out CBS_TM_HG_ACILIS.urun_sinif%type,
								   ps_risk out CBS_TM_HG_ACILIS.risk%type,
								   ps_kredi_teklif_satir_no out CBS_TM_HG_ACILIS.KREDI_TEKLIF_SATIR_NO%type,
								   ps_bolum_kodu out CBS_TM_HG_ACILIS.BOLUM_KODU%type,
								   ps_kontrgaranti out CBS_TM_HG_ACILIS.KONTRGARANTI%type
								   );

 FUNCTION TxGonderReferansAl(pn_tx_no number) return varchar2;

 Procedure Hesap_Kapat (pn_islem_no number);
 Procedure Iptal_Onay_sonrasi_Hesap_Ac (pn_islem_no number);

 PROCEDURE KG_Bilgi_Al(ps_tm_referans CBS_TM_KG_KULLANIM.TM_HG_REFERANS%type,
        					   ps_kg_referans CBS_TM_KG_KULLANIM.KG_REFERANS%type,
        					   ps_kullanilacak_tutar out CBS_TM_KG_KULLANIM.KULLANILACAK_TUTAR%type,
        					   ps_gon_banka_musteri_no out CBS_TM_KG_KULLANIM.GON_BANKA_MUSTERI_NO%type,
        					   ps_top_iade_tutar out CBS_TM_KG_KULLANIM.TOP_IADE_TUTAR%type);

 PROCEDURE SP_KG_BAKIYE_IPTAL_SONRASI(PS_REFERANS VARCHAR2);
 PROCEDURE SP_KG_BAKIYE_ONAY_SONRASI(PS_REFERANS VARCHAR2);
END;


/

