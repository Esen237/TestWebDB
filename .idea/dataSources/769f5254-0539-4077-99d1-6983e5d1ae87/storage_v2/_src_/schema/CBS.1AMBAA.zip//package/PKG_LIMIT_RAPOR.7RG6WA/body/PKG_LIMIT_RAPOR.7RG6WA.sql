create PACKAGE BODY     PKG_LIMIT_RAPOR is

/******************************************************************************
  NAME       : PKG_LIMIT_RAPOR
   Created By : Seval Balci
   Date          : 23.11.2011
   Purpose      :Limit izleme ve rapor ile ilgili procedur ve fonksiyonlari icerir.
******************************************************************************/
Function sf_finans_kod_al (pn_musteri_no number  ) return varchar2
is
  ls_finans_kod  varchar2(3);
   BEGIN

      SELECT finans_kod
      INTO  ls_finans_kod
      FROM  CBS_MUSTERI
      WHERE musteri_no = pn_musteri_no ;

      RETURN ls_finans_kod;

    EXCEPTION
      WHEN OTHERS THEN Return null;
     END ;
--------------------------------------------------------------------------------------------------------------
FUNCTION sf_musteri_kredi_gl_al(pn_musteri_no number,pn_kredi_teklif_satir_numara number , pd_date date default pkg_muhasebe.banka_tarihi_bul)RETURN varchar2
IS
  ln_hesap_no number ;
  ls_musteri_dk_no    varchar2(30); 
BEGIN
    if nvl(pd_date,pkg_muhasebe.banka_tarihi_bul) = pkg_muhasebe.banka_tarihi_bul then         
        select min(hesap_no) 
        into ln_hesap_no 
        from cbs_hesap_kredi
        where musteri_no  =   pn_musteri_no and durum_kodu = 'A' and 
                kredi_teklif_Satir_numara =pn_kredi_teklif_satir_numara;    
   else
      select min(hesap_no) 
      into ln_hesap_no 
      from cbs_rpt_kredi_gunsonu_faiz f
      where f.banka_TARIHI = pd_date
      and f.musteri_no  =   pn_musteri_no and f.durum_kodu = 'A'And f.hesap_no in (select k.hesap_no from cbs_hesap_kredi k where k.musteri_no  =   pn_musteri_no and 
                k.kredi_teklif_Satir_numara =pn_kredi_teklif_satir_numara ) ;
     if nvl(ln_hesap_no,0) = 0 then 
           select min(hesap_no) 
        into ln_hesap_no 
        from cbs_hesap_kredi
        where musteri_no  =   pn_musteri_no and  
                kredi_teklif_Satir_numara =pn_kredi_teklif_satir_numara and
                acilis_tarihi <=pd_date  ;    
     end if; 
   end if;
        
        SELECT musteri_dk_no
        into ls_musteri_dk_no
        from cbs_hesap_kredi
        where hesap_no =  ln_hesap_no;

      RETURN ls_musteri_dk_no;
        
        Exception when others then return null;
END;
--------------------------------------------------------------------------------------------------------------
Function   sf_validity_date_of_line_al(pn_musteri_no cbs_musteri.musteri_no%type) return date
   IS
     ln_teklif_no   number := 0;
     ld_validity_date_of_line    date ;
  begin

    ln_teklif_no := pkg_kredi.sf_onayli_teklifi_varmi(pn_musteri_no) ;
    if nvl(ln_teklif_no,0) = 0 then 
       select  max(teklif_no)
       into    ln_teklif_no
       from    cbs_kredi_teklif a
       where   a.musteri_no = pn_musteri_no and
                durum_kodu = 'K';
    end if; 
    
       select validity_date_of_line
       into    ld_validity_date_of_line
       from    cbs_kredi_teklif_limit a
       where   a.teklif_no = ln_teklif_no ;                
    
       return ld_validity_date_of_line;

    EXCEPTION
      WHEN OTHERS THEN RETURN ld_validity_date_of_line;
    END;
-------------------------------------------------------------------------------------------------------------- 
  FUNCTION  Sf_activity_Adi_al( ps_finans_kodu CBS_FINANS_KODLARI.finans_kodu%TYPE) RETURN VARCHAR2
  IS
    ls_finans_adi      CBS_FINANS_KODLARI.aciklama%TYPE;
  BEGIN
      SELECT aciklama
    INTO   ls_finans_adi
    FROM   CBS_FINANS_KODLARI
    WHERE  finans_kodu =ps_finans_kodu  ;

    RETURN ls_finans_adi ;

  EXCEPTION
      WHEN OTHERS THEN
        return null;
  END;
----------------------
function sf_yenileme_vadesi_al(pn_musteri_no cbs_musteri.musteri_no%type) return date
   is   
    ld_limit_revize_tarihi date;
  begin

       select limit_revize_tarihi
       into    ld_limit_revize_tarihi
       from    cbs_musteri a
       where   a.musteri_no = pn_musteri_no;                
    
       return ld_limit_revize_tarihi;

    exception
      when others then return ld_limit_revize_tarihi;
    end;
   
end ;
/

