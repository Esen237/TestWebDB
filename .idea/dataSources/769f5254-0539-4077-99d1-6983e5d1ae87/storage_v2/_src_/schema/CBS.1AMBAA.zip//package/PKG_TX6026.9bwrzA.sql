create PACKAGE Pkg_Tx6026 IS

/******************************************************************************
/*   Name         : PKG_TX6026
/*   Created By   : G?lnihal Cengiz
/*   Date    	  : 25/12/2003
/*   Purpose	  : Menkul Emanet ??k??
******************************************************************************/
  FUNCTION 	MenkulEmanetCikis_Referansi_Al RETURN VARCHAR2;
  PROCEDURE Emanet_Cikis_Stok_Tablo_Yarat(pn_islem_no NUMBER,
 										  ps_mk_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
										  ps_referans CBS_MENKUL_EMANET_CIKIS_ISLEM.referans_no%TYPE DEFAULT NULL,
										  pn_musteri_no CBS_MENKUL_STOK.musteri_no_kime%TYPE,
										  pn_adet  		  NUMBER,
										  pn_nominal 	  NUMBER
										 )  ;

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

