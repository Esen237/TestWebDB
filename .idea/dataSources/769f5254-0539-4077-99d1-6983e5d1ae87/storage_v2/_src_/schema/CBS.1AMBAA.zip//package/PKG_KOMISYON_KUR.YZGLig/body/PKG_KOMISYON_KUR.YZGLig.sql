create PACKAGE BODY Pkg_Komisyon_Kur IS

  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;
-----------------------------------------------------------------------------------------------------------------
FUNCTION KOM_DOVIZ_KARSILIK(  p_doviz_kod_1  VARCHAR2
                        , p_doviz_kod_2  VARCHAR2
                        , p_tarih        DATE DEFAULT NULL
                        , p_tutar        NUMBER
                        , p_sabit_1			 NUMBER
                        , p_sabit_2			 NUMBER
                        ) RETURN NUMBER IS

    n_lc_amount_1		NUMBER; --(35,8);
    n_fc_amount_1		NUMBER;--(35,8);


    s_max_dt_1			VARCHAR2(40);
    s_max_dt_2			VARCHAR2(40);
    s_carp_1			VARCHAR2(1);
    s_carp_2			VARCHAR2(1);
    l_error VARCHAR2(2000);

   TYPE CurKurlogRec IS RECORD ( maxkurdate VARCHAR2(500) );
   TYPE CurKurlogTyp IS REF CURSOR RETURN CurKurlogRec;
   cur_kurlog CurKurlogTyp;  -- declare cursor variable

   TYPE CurKurlogRec2 IS RECORD ( amount_1 number);
   TYPE CurKurlogTyp2 IS REF CURSOR RETURN CurKurlogRec2;
   cur_kurlog2 CurKurlogTyp2;  -- declare cursor variable

  BEGIN

 -- B-O-M sevalb 240707 komisyon kurlari MBDAK Kur olarak degistirildi.
   return  Pkg_Kur.doviz_doviz_karsilik( p_doviz_kod_1 ,
						           p_doviz_kod_2,
								   p_tarih,
								   p_tutar,
									1,
									NULL,
									NULL,
									'N',
									'A');

  /*
    -- multiply or divide ?!
  	SELECT	carp
  	INTO		s_carp_1
  	FROM		CBS_KUR
  	WHERE		dvz = p_doviz_kod_1;

  	-- multiply or divide ?!
  	SELECT	carp
  	INTO		s_carp_2
  	FROM		CBS_KUR
  	WHERE		dvz = p_doviz_kod_2;


   IF p_tarih IS NULL THEN

		      	IF s_carp_1 = 'E' THEN		-- multiply
				        BEGIN
				       				SELECT	ROUND((KUR * p_tutar)/p_sabit_1,8)
				      				INTO		n_lc_amount_1
				      				FROM		CBS_KOMISYON_KUR
				      				WHERE		dvz = p_doviz_kod_1;

				   				EXCEPTION
				   					WHEN OTHERS THEN
									 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);

				      	END;
				ELSE-- divide
		      			BEGIN
		      				SELECT	ROUND((KUR / p_tutar)/p_sabit_1,8)
		      				INTO		n_lc_amount_1
		      				FROM		CBS_KOMISYON_KUR
		      				WHERE		dvz = p_doviz_kod_1;

		   				EXCEPTION
							 WHEN OTHERS THEN
							 	 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);
		      			 END;
				END IF;
				IF s_carp_2 = 'E' THEN		-- multiply
		                BEGIN
			      			SELECT	ROUND((n_lc_amount_1 / KUR)*p_sabit_2,8)
		        			INTO		n_fc_amount_1
		        			FROM		CBS_KOMISYON_KUR
		        			WHERE		dvz = p_doviz_kod_2;

		        		EXCEPTION
		        			WHEN OTHERS THEN
								 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);
		                END;
		        ELSE
		  		        BEGIN
		        			SELECT	ROUND((n_lc_amount_1 * KUR)*p_sabit_2,8)
		        			INTO		n_fc_amount_1
		        			FROM		CBS_KOMISYON_KUR
		        			WHERE		dvz = p_doviz_kod_2;

		        		EXCEPTION
		        			WHEN OTHERS THEN
								 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);
				   		END;
				END IF;
   ELSE
          BEGIN
	  	  OPEN cur_kurlog FOR
		 	  SELECT TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
  			  FROM	CBS_KOMISYON_KURLOG
  			  WHERE	dvz = p_doviz_kod_1
			        AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');

 		   FETCH cur_kurlog INTO s_max_dt_1;
           EXCEPTION
  		     WHEN OTHERS THEN
				 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);

  		   END;
		   BEGIN
		   OPEN cur_kurlog FOR
		 	  SELECT	TO_CHAR(MAX(tarih),'DDMMYYYY HH24:MI') maxdate
  			  FROM	CBS_KOMISYON_KURLOG
   			  WHERE	dvz = p_doviz_kod_2
			   AND  tarih BETWEEN TRUNC(p_tarih) AND TO_DATE(TO_CHAR(p_tarih,'DDMMYYYY') || ' 23:59:59', 'DDMMYYYY HH24:MI:SS');
 		    FETCH cur_kurlog INTO s_max_dt_2;
       	    EXCEPTION
  			WHEN OTHERS THEN
				 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);

   		    END;
         	IF s_carp_1 = 'E' THEN		-- multiply
					BEGIN
				    OPEN cur_kurlog2 FOR
					      SELECT ROUND((KUR * p_tutar)/p_sabit_1,8) amount_1
		    			  FROM CBS_KOMISYON_KURLOG
		    			  WHERE tarih = TO_DATE(s_max_dt_1, 'DDMMYYYY HH24:MI')
						   AND dvz = p_doviz_kod_1;
		 		    FETCH cur_kurlog2   INTO n_lc_amount_1;
		   			EXCEPTION
		   				WHEN OTHERS THEN
							 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);
				   	END;
			ELSE
			        BEGIN
				    OPEN cur_kurlog2 FOR
				 	  	  SELECT ROUND((KUR / p_tutar)/p_sabit_1,8) amount_1
		    			  FROM CBS_KOMISYON_KURLOG
		    			  WHERE tarih = TO_DATE(s_max_dt_1, 'DDMMYYYY HH24:MI')
						   AND dvz = p_doviz_kod_1;
		 		    FETCH cur_kurlog2   INTO n_lc_amount_1;
		   			EXCEPTION
		   				WHEN OTHERS THEN
							 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);
				   	END;
			END IF;
			IF s_carp_2 = 'E' THEN		-- multiply
		    	    BEGIN
					 OPEN cur_kurlog2 FOR
					 	  SELECT	ROUND((n_lc_amount_1 / KUR)*p_sabit_2,8) amount_1
		      			  FROM	CBS_KOMISYON_KURLOG
		      			  WHERE	tarih = TO_DATE(s_max_dt_2, 'DDMMYYYY HH24:MI')
						   AND  dvz = p_doviz_kod_2;
					 FETCH cur_kurlog2   INTO	n_fc_amount_1	;
		      			EXCEPTION
		      				WHEN OTHERS THEN
						     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);

		       		  END;
            ELSE
			         BEGIN
					 OPEN cur_kurlog2 FOR
					 	  SELECT	ROUND((n_lc_amount_1 * KUR)*p_sabit_2,8) amount_1
		      			  FROM	CBS_KOMISYON_KURLOG
		      			  WHERE	tarih = TO_DATE(s_max_dt_2, 'DDMMYYYY HH24:MI')
						   AND  dvz = p_doviz_kod_2;
					 FETCH cur_kurlog2   INTO	n_fc_amount_1	;
		      			EXCEPTION
		      				WHEN OTHERS THEN
						     RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter ||'5115'||g_uc_delimiter);

		       		  END;
			END IF;
	 END IF;

	 */
 -- E-O-M sevalb 240707
   	RETURN n_fc_amount_1;

  END;
-----------------------------------------------------------------------------------------------------
 FUNCTION KOM_DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1      VARCHAR2
                              , p_doviz_kod_2      VARCHAR2
                              , p_tarih            DATE DEFAULT NULL
                              , p_tutar            NUMBER
                              , p_kur_deger_1      NUMBER DEFAULT NULL
                              , p_kur_deger_2      NUMBER DEFAULT NULL
                              , p_karsilik_tutar   OUT NUMBER) RETURN NUMBER IS

  n_kur_tip       NUMBER;
  n_lc_amount		  NUMBER ;-- number(35,8);
  n_fc_amount		  NUMBER ; --number(35,8);
  n_sabit_1				NUMBER;
  n_sabit_2				NUMBER;
  v_kuruslu				VARCHAR2(1);
  e_hata          EXCEPTION;
  e_kur_tablo_yok EXCEPTION;

  BEGIN
 -- B-O-M sevalb 240707 komisyon kurlari MBDAK Kur olarak degistirildi.
  p_karsilik_tutar := Pkg_Kur.doviz_doviz_karsilik( p_doviz_kod_1 ,
						           p_doviz_kod_2,
								   p_tarih,
								   p_tutar,
									1,
									NULL,
									NULL,
									'N',
									'A');

  /*
	-- kontrol the currency
	IF p_doviz_kod_1 = p_doviz_kod_2 THEN
       p_karsilik_tutar := p_tutar;
       RETURN 1;
	END IF;


  -- the constant value for the crncy.. USD, DEM = 1    JPY, ITL = 100
	SELECT	birim
	INTO		n_sabit_1
	FROM		CBS_DOVIZ_KODLARI
	WHERE		doviz_kodu = p_doviz_kod_1;

	-- the constant value for the second crncy.. USD, DEM = 1    JPY, ITL = 100
	SELECT	birim, kuruslu_mu
	INTO		n_sabit_2, v_kuruslu
	FROM		CBS_DOVIZ_KODLARI
	WHERE		doviz_kodu = p_doviz_kod_2;

  IF p_kur_deger_1 IS NULL AND p_kur_deger_2 IS NULL THEN
     n_fc_amount := KOM_DOVIZ_KARSILIK(p_doviz_kod_1, p_doviz_kod_2, p_tarih, ABS(p_tutar), n_sabit_1,n_sabit_2) ;
     IF p_tutar < 0 THEN n_fc_amount := -1*n_fc_amount; END IF;
  ELSE
    n_lc_amount:=(p_kur_deger_1*p_tutar);
    n_fc_amount:=(n_lc_amount/p_kur_deger_2);
  END IF;

	IF v_kuruslu = 'H' THEN
	   p_karsilik_tutar := ROUND (n_fc_amount,0) ;
	ELSE
	   p_karsilik_tutar := ROUND (n_fc_amount,8);
	END IF;

	*/
 -- E-O-M sevalb 240707
	RETURN 1;

  EXCEPTION

  	WHEN NO_DATA_FOUND   THEN
		 RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '327' ||g_uc_delimiter);
  END;
 ------------------------------------------------------------------------------------------
 FUNCTION KOM_DOVIZ_DOVIZ_KARSILIK(  p_doviz_kod_1      VARCHAR2
                                , p_doviz_kod_2      VARCHAR2
                                , p_tarih            DATE     DEFAULT NULL
                                , p_tutar            NUMBER
                                , p_kur_deger_1      NUMBER   DEFAULT NULL
                                , p_kur_deger_2      NUMBER   DEFAULT NULL) RETURN NUMBER IS


  n_lc_amount		  NUMBER;-- number(35,8);
  n_fc_amount		  NUMBER;--number(35,8);
  n_sabit_1				NUMBER;
  n_sabit_2				NUMBER;
  v_kuruslu				VARCHAR2(1);
  e_hata          EXCEPTION;
  e_kur_tablo_yok EXCEPTION;

BEGIN
 -- B-O-M sevalb 240707 komisyon kurlari MBDAK Kur olarak degistirildi.

  return Pkg_Kur.doviz_doviz_karsilik( p_doviz_kod_1 ,
						           p_doviz_kod_2,
								   p_tarih,
								   p_tutar,
									1,
									NULL,
									NULL,
									'N',
									'A');

/*
      -- kontrol the currency
      IF p_doviz_kod_1 = p_doviz_kod_2 THEN
      RETURN p_tutar;
      END IF;

       -- the constant value for the crncy.. USD, DEM = 1    JPY, ITL = 100
      BEGIN
          SELECT	birim
          INTO		n_sabit_1
          FROM		CBS_DOVIZ_KODLARI
          WHERE		doviz_kodu = p_doviz_kod_1;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
		  RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '328' || g_ara_delimiter|| NVL(p_doviz_kod_1,'null')||g_uc_delimiter);

      END;

      BEGIN
        -- the constant value for the second crncy.. USD, DEM = 1    JPY, ITL = 100
        SELECT	birim, kuruslu_mu
        INTO		n_sabit_2, v_kuruslu
        FROM		CBS_DOVIZ_KODLARI
        WHERE		doviz_kodu = p_doviz_kod_2;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
		  	   RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '329' || g_ara_delimiter || p_doviz_kod_2 ||g_uc_delimiter);

      END;


      IF p_kur_deger_1 IS NULL AND p_kur_deger_2 IS NULL THEN
         n_fc_amount := kom_doviz_karsilik(p_doviz_kod_1, p_doviz_kod_2, p_tarih, p_tutar, n_sabit_1,n_sabit_2) ;
	  ELSE
         n_lc_amount:=(p_kur_deger_1*p_tutar);
         n_fc_amount:=(n_lc_amount/p_kur_deger_2);
      END IF;

      IF v_kuruslu = 'H' THEN
         RETURN ROUND (n_fc_amount,0) ;
      ELSE
         RETURN ROUND (n_fc_amount,8);
      END IF;

	  */
	   -- E-O-M sevalb 240707
EXCEPTION

  WHEN NO_DATA_FOUND   THEN
	   RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '338' ||g_uc_delimiter);
END;
/*****************************************************************************/
 FUNCTION KUR_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN

  -- B-O-M sevalb 240707 komisyon kurlari MBDAK Kur olarak degistirildi.
  	 	return pkg_kur.MB_DAK_to_LC (ps_doviz_kodu , pn_tutar);

   /*RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_komisyon_Kur.kom_doviz_doviz_karsilik(ps_doviz_kodu,
						                                         Pkg_Genel.lc_al,
											            		 NULL,
          														 pn_tutar,
         														 NULL,
             													 NULL)
							));
							*/
 -- E-O-M sevalb 240707 komisyon kurlari MBDAK Kur olarak degistirildi.
 END;
/*****************************************************************************/
END;
/

