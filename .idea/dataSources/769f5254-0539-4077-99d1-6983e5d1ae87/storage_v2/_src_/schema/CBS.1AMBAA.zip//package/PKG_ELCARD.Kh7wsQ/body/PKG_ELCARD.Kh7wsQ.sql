create PACKAGE BODY     PKG_ELCARD is
/******************************************************************************
   NAME        : FUNCTION makeElcardWSOutcome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease Elcard Card balance WS
******************************************************************************/
function makeelcardwsoutcome(pn_amount    in number,
                              ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (10);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_OUTCOME_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_OUTCOME_PASS', ls_payinstr_ref);

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'DecreaseAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);
        --Pkg_Soap.add_parameter(req, 'amount', 'xsd:string', trim(replace(replace(to_char(pn_amount, '9999.99'), '.', ''), ',', '')));
        pkg_soap.add_parameter(req, 'amount', 'xsd:string', trim(to_char(pn_amount, '999999999999999.99')));

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'DecreaseAccountBalanceResponse/DecreaseAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_resultcode;

        log_at('makeElcardWSOutcomeOK', 'account: ' || ps_account_number || ', amount: ' || pn_amount,  substr(req.body,1,2000), substr(result,1,2000));

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('makeElcardWSOutcome', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('makeElcardWSOutcome',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION makeElcardWSIncome
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Increase Elcard Card balance WS
******************************************************************************/
function makeelcardwsincome(pn_amount    in number,
                              ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (10);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_INCOME_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_INCOME_PASS', ls_payinstr_ref);

    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'IncreaseAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);
        pkg_soap.add_parameter(req, 'amount', 'xsd:string', trim(to_char(pn_amount, '999999999999999.99')));

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'IncreaseAccountBalanceResponse/IncreaseAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

        result := resp.doc.getclobval();

        ls_returncode := ls_resultcode;

        log_at('makeElcardWSIncomeOK', 'account: ' || ps_account_number || ', amount: ' || pn_amount,  substr(req.body,1,2000), substr(result,1,2000));

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('makeElcardWSIncome', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('makeElcardWSIncome',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS
******************************************************************************/
function checkelcardbalancews(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalance';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceResponse/CheckAccountBalanceResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWS', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWS',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSFront
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS Front
******************************************************************************/
function checkelcardbalancewsfront(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalanceFront';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceFrontResponse/CheckAccountBalanceFrontResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWSFront', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWSFront',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : FUNCTION CheckElcardBalanceWSBack
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Check Elcard Card balance WS back
******************************************************************************/
function checkelcardbalancewsback(ps_account_number in varchar2,
                              pc_ref       out cursorreferencetype) return varchar2
is

    ls_returncode varchar2(3):='0';
    --ws variables
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_resultcode varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
begin
    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);
    pkg_parametre.deger('ELCARD_BALCHECK_LOG', ls_biller_ref);
    pkg_parametre.deger('ELCARD_BALCHECK_PASS', ls_payinstr_ref);

    --Check front WS
    begin
        --GET STATUS 1
        namespace := 'http://services.demirbank.kg/';
        methodname := 'CheckAccountBalanceBack';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'billerRef', 'xsd:string', ls_biller_ref);
        pkg_soap.add_parameter(req, 'payinstrRef', 'xsd:string', ls_payinstr_ref);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', ps_account_number);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'CheckAccountBalanceBackResponse/CheckAccountBalanceBackResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ls_returncode);
        dbms_xslprocessor.valueof(l_n,'Amount',ls_resultcode);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        open pc_ref for
            select ls_resultcode, ls_errorcode, ls_errordesc from dual;

    exception
        when others then
            result := sqlerrm;
            ls_returncode:='998';

            open pc_ref for select sysdate from dual;
            log_at('CheckElcardBalanceWSBack', sqlerrm, dbms_utility.format_error_backtrace, substr(req.body||' : '||result,1,2000));
    end;

    return ls_returncode;
exception
    when others then
        result := sqlerrm;
        log_at('CheckElcardBalanceWSBack',sqlerrm);
        open pc_ref for select sysdate from dual;
        return '999';
end;

/******************************************************************************
   NAME        : PROCEDURE CallElcardWS
   Prepared By : Meder Toitonov
   Date        : 13.01.2017
   Purpose     : Decrease/Increase Elcard Card balance WS
******************************************************************************/
procedure callelcardws(ps_tur in varchar2,
                          pn_amount    in number,
                          ps_transaction_number in varchar2,
                          ps_account_number in varchar2,
                          pn_fis    in number,
                          pn_numara    in number,
                          pn_tx_no    in number
                          ) is
    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;
    ls_response varchar2(10) := '';
    ls_resultcode varchar2(100) := '';
    ls_errorcode varchar2(100) := '';
    ls_errordesc varchar2(250) := '';
    ln_try_count number := 0;
    ln_done_count number := 0;
    ln_balance number := 0;
    ls_tx varchar2(2000);
    ls_tx_part varchar2(50);
    ld_bal_time date;
    ln_min number := 0;
    ln_max number := 0;

    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
    notenoughbalance      exception;
    balancepending        exception;
    wserror      exception;
begin
    pkg_parametre.deger('ELCARD_ALLOWED_TX', ls_tx);

    if (length(ls_tx) > 0) then
        ls_tx := ls_tx || ',';
        ls_tx_part := substr(ls_tx, instr(ls_tx, to_char(ps_transaction_number)), instr(ls_tx, ',', instr(ls_tx, to_char(ps_transaction_number))) - instr(ls_tx, to_char(ps_transaction_number)));
        if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
            raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
        else
            if (ls_tx_part like '%D') or (ls_tx_part like '%C') then
                if ((ps_tur = 'A') and (ls_tx_part not like '%C')) or ((ps_tur = 'B') and (ls_tx_part not like '%D')) then
                    raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
                end if;
            end if;
        end if;
    end if;

    pkg_parametre.deger('ELCARD_DENIED_TX', ls_tx);

    if (length(ls_tx) > 0) then
        if (instr(ls_tx, to_char(ps_transaction_number)) > 0) then
            raise_application_error(-20100,g_uc_delimiter || '6177' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);
        end if;
    end if;

    pkg_parametre.deger('ELCARD_NO_WS_TX', ls_tx);
    ls_tx := ls_tx || ',';


    if (instr(ls_tx, to_char(ps_transaction_number)) = 0) and (ps_tur = 'B') then
        select count(*)
        into ln_done_count
        from cbs_ipc_ws_log
        where tx_no = pn_tx_no and fis_no = pn_fis and satir_no = pn_numara and account_no = ps_account_number
        and amount = pn_amount and tx_code = ps_transaction_number and status = 'A';

        pkg_parametre.deger('ELCARD_SKIP_BALCHECK_ACC', ls_tx);
        ls_tx := ls_tx || ',';

        if (instr(ls_tx, to_char(ps_account_number)) = 0) and (ln_done_count = 0) then

            pkg_parametre.deger('ELCARD_IMMEDIATE_BAL_TX', ls_tx);
            ls_tx := ls_tx || ',';

            while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
            loop

                ln_try_count := ln_try_count + 1;

                if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
                    ls_response := checkelcardbalancewsfront(ps_account_number, pc_ref);
                else
                    ls_response := checkelcardbalancews(ps_account_number, pc_ref);
                end if;

                if (ls_response = '1') then
                    fetch pc_ref
                    into ls_resultcode, ls_errorcode, ls_errordesc;
                    close pc_ref;

                    ln_balance := to_number(trim(ls_resultcode)) / 100;

                    if (ln_balance < pn_amount) then
                        raise notenoughbalance;
                    end if;
                end if;
            end loop;

            if (ls_response != '1') then
                pkg_parametre.deger('ELCARD_IMMEDIATE_BAL_TX', ls_tx);
                ls_tx := ls_tx || ',';

                if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
                    begin
                        select max(create_date)
                        into ld_bal_time
                        from cbs_ipc_balcheck_log
                        where account_no = ps_account_number;
                    exception
                        when others then
                            ld_bal_time := null;
                    end;

                    pkg_parametre.deger('ELCARD_BAL_MIN', ln_min);
                    pkg_parametre.deger('ELCARD_BAL_MAX', ln_max);

                    if (ld_bal_time is not null) and (ld_bal_time + ln_min/1440  < sysdate) and (ld_bal_time + ln_max/1440  > sysdate) then

                        ln_try_count := 0;

                        while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
                        loop

                            ln_try_count := ln_try_count + 1;

                            ls_response := checkelcardbalancewsback(ps_account_number, pc_ref);

                            if (ls_response = '1') then
                                fetch pc_ref
                                into ls_resultcode, ls_errorcode, ls_errordesc;
                                close pc_ref;

                                ln_balance := to_number(trim(ls_resultcode)) / 100;

                                if (ln_balance < pn_amount) then
                                    raise notenoughbalance;
                                end if;
                            end if;
                        end loop;
                    else
                        --CQ5717 fix. do not insert before min time call
                        if (ld_bal_time is null) or (ld_bal_time + ln_max/1440  < sysdate) then
                            insertelcardbalancelog(ps_account_number, 0);
                        end if;

                        raise balancepending;
                    end if;
                end if;
            end if;

            if (ls_response != '1') then
                raise wserror;
            end if;
        end if;
  end if;
exception
    when balancepending then
    log_at('mybalancepending 2');
        raise_application_error(-20100,g_uc_delimiter || '6179' || pkg_hata.getdelimiter || ln_min || pkg_hata.getdelimiter || ln_max || pkg_hata.getucpointer);     --CQ5717 fix
    when notenoughbalance then
        raise_application_error(-20100,g_uc_delimiter || '6052' || pkg_hata.getdelimiter || ps_account_number || pkg_hata.getucpointer);

    when others then
        log_at('CallElcardWS', pn_fis, ps_account_number || ' ' || ls_response || ' ' || ls_resultcode || ' ' || ls_errorcode || ' ' || ls_errordesc);
        log_at('CallElcardWS',dbms_utility.format_error_backtrace);


        insertelcardwslog(pn_tx_no, pn_fis, pn_numara, ps_tur, ps_transaction_number, ps_account_number, pn_amount, 'E', 1);

        raise_application_error(-20100,g_uc_delimiter || '6176' || pkg_hata.getdelimiter || ps_account_number || ' ' || sqlerrm || pkg_hata.getucpointer);
end;

/******************************************************************************
   NAME        : PROCEDURE AddElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : Add row to WS queue
******************************************************************************/
procedure addelcardwsqueue(ps_transaction_number in varchar2,
                              pn_tx_no    in number,
                              pn_fis    in number
                          ) is
  /*  -- seval.colak  26072021 elcard performance problem old
          cursor c_satirs(pn_islem_numara number, pn_fis number) is
        select s.fis_islem_numara, s.fis_numara, s.numara, s.tur, s.hesap_numara, s.lc_tutar from cbs_satir s
        join cbs_hesap h on h.hesap_no = s.hesap_numara
        where s.fis_islem_numara = nvl(pn_islem_numara, s.fis_islem_numara) and s.fis_numara = nvl(pn_fis, s.fis_numara)
        and (pn_islem_numara is not null or pn_fis is not null)
        and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and s.fis_tur = 'G'; -- seval.colak  26072021 elcard performance problem
        */  -- seval.colak  26072021 elcard performance problem

     -- seval.colak  26072021 elcard performance problem- new
      cursor c_satirs(pn_islem_numara number, pn_fis number) is
        select s.fis_islem_numara, s.fis_numara, s.numara, s.tur, s.hesap_numara, s.lc_tutar
        from cbs_satir s  ,cbs_hesap h
        where s.fis_islem_numara = pn_islem_numara  and s.fis_numara = pn_fis
              and h.hesap_no = s.hesap_numara
              and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and s.fis_tur = 'G'
              and s.hesap_tur_kodu ='VS' ;
       -- seval.colak  26072021 elcard performance problem

    ls_tx varchar2(2000);
    ln_done_count number := 0;
    ls_bloke_referans varchar2(100);
    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
begin
    pkg_parametre.deger('ELCARD_NO_WS_TX', ls_tx);

    ls_tx := ls_tx || ',';
    if (instr(ls_tx, to_char(ps_transaction_number)) = 0) then
        for r_satir in c_satirs(pn_tx_no, pn_fis)
        loop
        begin
            select count(*)
            into ln_done_count
            from cbs_ipc_ws_log
            where tx_no = pn_tx_no and fis_no = r_satir.fis_numara and satir_no = r_satir.numara and account_no = r_satir.hesap_numara
            and amount = r_satir.lc_tutar and tx_code = ps_transaction_number and status = 'A';

            if (ln_done_count = 0) then
                --if (r_satir.tur = 'A') and (INSTR(ls_tx, to_char(ps_transaction_number)) > 0) then
                if (r_satir.tur = 'A') then
                    ls_bloke_referans := '';
                    pkg_bloke.sp_bloke_yarat(ls_bloke_referans  ,
                                                  pkg_hesap.hesaptanmusterinoal(r_satir.hesap_numara),
                                                  r_satir.hesap_numara,
                                                  'KGS',
                                                  r_satir.lc_tutar,
                                                  33,
                                                  'Elcard Blocking' ,
                                                  pkg_muhasebe.banka_tarihi_bul,
                                                  pkg_muhasebe.banka_tarihi_bul + 40,
                                                  null,
                                                  null);
                else
                    null;
                end if;
                
                insertelcardwslog(pn_tx_no, r_satir.fis_numara, r_satir.numara, r_satir.tur, ps_transaction_number, r_satir.hesap_numara, r_satir.lc_tutar, 'A', 0);
            end if;
        exception
            when others then
                log_at('AddElcardWSQueue', pn_tx_no, r_satir.hesap_numara);
                insertelcardwslog(pn_tx_no, r_satir.fis_numara, r_satir.numara, r_satir.tur, ps_transaction_number, r_satir.hesap_numara, r_satir.lc_tutar, 'E', 0);
        end;
        end loop;

        if (ps_transaction_number != 2150) then
            processelcardwsqueue(pn_tx_no, pn_fis);
        end if;
    end if;
exception
    when others then
        raise_application_error(-20100,g_uc_delimiter || '6176' ||g_ara_delimiter || ' ' || sqlerrm||g_uc_delimiter);
end;

/******************************************************************************
   NAME        : PROCEDURE InsertElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardWSLog
******************************************************************************/
procedure insertelcardwslog(pn_tx_no    in number,
                              pn_fis    in number,
                              pn_numara    in number,
                              ps_tur in varchar2,
                              ps_transaction_number in varchar2,
                              ps_account_number in varchar2,
                              pn_amount    in number,
                              ps_status in varchar2,
                              pn_is_proc    in number
                              ) is
    pragma autonomous_transaction;
begin
    insert into cbs_ipc_ws_log(tx_no, fis_no, satir_no, account_no, amount, tx_code, status, tur, is_proc)
    values (pn_tx_no, pn_fis, pn_numara, ps_account_number, pn_amount,ps_transaction_number, ps_status, ps_tur, pn_is_proc);

    commit;
end;

/******************************************************************************
   NAME        : PROCEDURE UpdateElcardWSLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : UpdateElcardWSLog
******************************************************************************/
procedure updateelcardwslog(pn_tx_no    in number,
                              pn_fis    in number,
                              pn_numara    in number,
                              ps_account_number in varchar2,
                              pn_amount    in number,
                              ps_status in varchar2,
                              pn_is_proc    in number
                              ) is
    pragma autonomous_transaction;
begin
    update cbs_ipc_ws_log
    set is_proc = pn_is_proc, status = ps_status, update_date = sysdate
    where tx_no = pn_tx_no and fis_no = pn_fis and satir_no = pn_numara and account_no = ps_account_number and amount = pn_amount;

    commit;
end;

/******************************************************************************
   NAME        : PROCEDURE InsertElcardBalanceLog
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : InsertElcardBalanceLog
******************************************************************************/
procedure insertelcardbalancelog(ps_account_number in varchar2,
                              pn_balance    in number
                              ) is
    pragma autonomous_transaction;
begin
    insert into cbs_ipc_balcheck_log(account_no, balance)
    values (ps_account_number, pn_balance);

    commit;
end;

/******************************************************************************
   NAME        : FUNCTION getElcardIPCBalance
   Prepared By : Meder Toitonov
   Date        : 17.02.2017
   Purpose     : get Elcard Card balance WS
******************************************************************************/
function getelcardipcbalance(ps_account_number in varchar2) return number is
    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;
    ls_response varchar2(10);
    ln_balance number := 0;
    ls_resultcode varchar2(100) := '';
    ls_errorcode varchar2(100) := '';
    ls_errordesc varchar2(250) := '';

    g_uc_delimiter constant varchar2(3):=pkg_hata.getucpointer;
    g_ara_delimiter constant varchar2(3):=pkg_hata.getdelimiter;
begin
    ls_response := checkelcardbalancews(to_char(ps_account_number), pc_ref);

    if (ls_response = '1') then
        fetch pc_ref
        into ls_resultcode, ls_errorcode, ls_errordesc;
        close pc_ref;

        ln_balance := to_number(trim(ls_resultcode)) / 100;
        ln_balance := pkg_kur.yuvarla(pkg_genel.lc_al, ln_balance);
    end if;

    if (ls_response != '1') then
        log_at('getElcardIPCBalance', ls_response || ' ' || ls_resultcode || ' ' || ls_errorcode || ' ' || ls_errordesc);

        raise_application_error(-20100,g_uc_delimiter || '6176' ||g_ara_delimiter||ps_account_number || ' ' || sqlerrm || g_uc_delimiter);
    end if;

    return ln_balance;
end;

/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : Meder Toitonov
   Date        : 25.03.2017
   Purpose     : prcoess Elcard WS queue
******************************************************************************/
procedure processelcardwsqueue(pn_tx_no number default null, pn_fis number default null) is

    type cursorreferencetype is ref cursor;
    pc_ref cursorreferencetype;

    cursor c_queue is
    select * from cbs_ipc_ws_log
    where status = 'A' and is_proc = 0 and (sysdate-create_date) < 40
     and tx_no = nvl(pn_tx_no, tx_no) and fis_no = nvl(pn_fis, fis_no)
    order by create_date;

    r_q c_queue%rowtype;

    cursor c_block(pn_account_no number, pn_amount number) is
    select b.* from cbs_bloke b
    where b.bloke_neden_kodu = 33 and b.aciklama = 'Elcard Blocking' and b.durum_kodu = 'A'
    and b.hesap_no = pn_account_no and b.bloke_tutari = pn_amount;

    r_block c_block%rowtype;

    ln_count number := 0;
    ln_is_proc number := 0;
    ln_try_count number;
    ls_response varchar2(10) := '';
begin
    open c_queue;
    fetch c_queue into r_q;

    while  (c_queue%found) and (ln_count <= 1000)
    loop
    begin
        select is_proc
        into ln_is_proc
        from cbs_ipc_ws_log
        where tx_no = r_q.tx_no and fis_no = r_q.fis_no
        and satir_no = r_q.satir_no and account_no = r_q.account_no;

        if (ln_is_proc = 0) then
            updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 2);

            ls_response := '';
            ln_try_count := 0;
            while (nvl(ls_response, '0') != '1') and (ln_try_count <= 3)
            loop
                ln_try_count := ln_try_count + 1;

                if (r_q.tur = 'A') then
                    ls_response := makeelcardwsincome(r_q.amount, r_q.account_no, pc_ref);
                else
                    ls_response := makeelcardwsoutcome(r_q.amount, r_q.account_no, pc_ref);
                end if;
            end loop;

            if (ls_response = '1') then
                updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 1);

                if (r_q.tur = 'A') then
                    open c_block(r_q.account_no, r_q.amount);
                    fetch c_block into r_block;

                    if (c_block%found) then
                       begin
                            pkg_bloke.sp_bloke_yarat(r_block.bloke_referans,
                                                          r_block.musteri_no,
                                                          r_block.hesap_no,
                                                          r_block.doviz_kodu,
                                                          pn_bloke_tutari=>0,
                                                          ps_bloke_neden_kodu=>33,
                                                          ps_aciklama=>'Releasing Elcard Blocking',
                                                          pd_bloke_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                                                          pd_bloke_bitis_tarihi=>pkg_muhasebe.banka_tarihi_bul,
                                                          p_coz_kayit_tarih => pkg_muhasebe.banka_tarihi_bul,
                                                          p_coz_kayit_sistem_tarih     =>sysdate ,
                                                          p_coz_kayit_kullanici_kodu     => pkg_baglam.kullanici_kodu,
                                                          ps_kapama   => 'KAPAMA');

                            commit;
                       exception
                            when others then
                                log_at('processElcardWSQueueBloke', 'referans:' || r_block.bloke_referans || ', acc_no:' || r_q.account_no, sqlerrm, dbms_utility.format_error_backtrace);
                       end;
                    else
                        log_at('processElcardWSQueue', 'tx:' || r_q.tx_no || ', fis:' || r_q.fis_no || ', satir_no:' || r_q.satir_no || ', acc_no:' || r_q.account_no, 'No Elcard Blocking');
                    end if;
                    close c_block;
                end if;

                ln_count := ln_count + 1;
            else
                updateelcardwslog(r_q.tx_no, r_q.fis_no, r_q.satir_no, r_q.account_no, r_q.amount, 'A', 0);
            end if;
        end if;

        fetch c_queue into r_q;
    exception
        when others then
            log_at('processElcardWSQueue', 'tx:' || r_q.tx_no || ', fis:' || r_q.fis_no || ', satir_no:' || r_q.satir_no || ', acc_no:' || r_q.account_no, sqlerrm, dbms_utility.format_error_backtrace);
    end;
    end loop;
    close c_queue;
end;
--EOM CQ5717 MederT 13012017
/******************************************************************************
   NAME        : PROCEDURE processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 26.08.2020
   Purpose     : process Update Customer
******************************************************************************/
function editcustomerelcard(pn_musteri in number, pn_islem_no in varchar2) return number
is
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    ld_starttime date;
    ld_endtime date;
    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ps_result_code varchar2(100);
    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
    ln_company_no       varchar2(100);
    pn_company_name     varchar2(1000);
    company_name_notfound   exception;

    cursor cur_musteri is
      select '26' as bank_c,
            '01' as groupc,
            nvl(m.isim_eng, ' ') as f_names, --F_NAMES
            nvl(m.soyadi_eng, ' ') as surname, --SURNAME
            nvl((select ulke_a3_kodu from cbs_ulke_kodlari where cbs_ulke_kodlari.ulke_kodu = adr.ulke_kod), ' ') as r_cntry, --R_CNTRY
            m.vergi_no as person_code, --PERSON_CODE
            decode (m.cinsiyet_kod,'F','00','M','01') as title, --TITLE
            decode(m.cinsiyet_kod, 'F', '2', '1') as mar_status, --MARITAL_STATUS Семейный статус частного лица (пояснение элемента дано в разделе: 4.1. CUSTOMERS – MARITAL_STATUS)
            m.anne_kizlik_soyadi as m_name, --M_NAME
            nvl(pkg_genel.sehir_adi_al_hatasiz(nvl(adr.il_kod, (select b.il_kodu from cbs_bolum b where b.kodu = '060'))), ' ') as r_city, --R_CITY
            nvl(substr(adr.adres, 0, 60), ' ') as r_street, --R_STREET
            nvl(to_char(nvl(adr.email, adr.email)), ' ') as r_emails, --R_E_MAILS
            nvl(to_char(nvl('+996'||adr.gsm_alan_kod || adr.gsm_no, '+996'||adr.gsm_alan_kod || adr.gsm_no)), ' ') as r_mob_phone, --R_MOB_PHONE
            m.pasaport_no as id_card, --ID_CARD
            m.vergi_no as serial_no, --SERIAL_NO
            m.verildigi_yer as issued_by, --ISSUED_BY
            h.hesap_no as account_no --ACCOUNT_NO
     from cbs_musteri m
    join cbs_hesap h on h.musteri_no = m.musteri_no
    left join cbs_musteri_adres adr on adr.musteri_no = m.musteri_no
    where m.musteri_no = pn_musteri
    and h.doviz_kodu = 'KGS'
    and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and rownum = 1;

    r_app cur_musteri%rowtype;

    ls_emboss_name varchar2(1000);
begin

    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);

        ld_starttime := sysdate;
        namespace := 'http://services.demirbank.kg/';
        methodname := 'EditCustomerElcard';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        -- make suitable emboss name like ours
        select t3.embossname3 into ls_emboss_name from(
        select t2.*, length(t2.embossname2) l2,
            case
                when length(t2.embossname2)>24 and trim(t2.ikinci_isim_eng) is not null then
                    case
                        when upper(substr(trim(t2.isim_eng), 1, 3)) = 'DZH' then substr(trim(t2.isim_eng),1,3) ||'.' ||' '|| trim(t2.soyadi_eng)
                        when upper(substr(trim(t2.isim_eng), 1, 2)) in ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') then substr(trim(t2.isim_eng),1,2) ||'.' ||' '|| trim(t2.soyadi_eng)
                        else substr(trim(t2.isim_eng),1,1) ||'.' ||' '|| trim(t2.soyadi_eng)
                    end
            else t2.embossname2 end embossname3
        from (
        select t1.*, length(t1.embossname1) l1,
            case
                when length(t1.embossname1)>24 and trim(t1.ikinci_isim_eng) is not null then
                    case
                        when upper(substr(trim(t1.ikinci_isim_eng), 1, 3)) = 'DZH' then trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,3) ||'.' ||' '|| trim(t1.soyadi_eng))
                        when upper(substr(trim(t1.isim_eng), 1, 2)) in ('CH', 'ZH', 'SH', 'PH', 'TS', 'KH') then trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,2) ||'.' ||' '|| trim(t1.soyadi_eng))
                        else trim(trim(t1.isim_eng) || ' '|| substr(trim(t1.ikinci_isim_eng),1,1) ||'.' ||' '|| trim(t1.soyadi_eng))
                    end
            else
                case when ikinci_isim_eng is null or length(ikinci_isim_eng)=0 then trim( trim(isim_eng) || ' '|| trim(soyadi_eng))
                else trim(trim(isim_eng) || ' '|| trim(ikinci_isim_eng) ||' '|| trim(soyadi_eng)) end
            end embossname2
        from (
            select musteri_no, campus_id_no, university_code, isim_eng, ikinci_isim_eng, soyadi_eng,
                case when ikinci_isim_eng is null or length(ikinci_isim_eng)=0 then trim( trim(isim_eng) || ' '|| trim(soyadi_eng))
                else trim(trim(isim_eng) || ' '|| trim(ikinci_isim_eng) ||' '|| trim(soyadi_eng)) end embossname1
            from cbs_musteri
            where musteri_no=pn_musteri
        ) t1
        ) t2
        ) t3
        where rownum=1;

        --create new request
        req := pkg_soap.new_request(methodname, namespace);
      for r_app in cur_musteri loop
        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', r_app.account_no);
        pkg_soap.add_parameter(req, 'f_names', 'xsd:string', r_app.f_names);
        pkg_soap.add_parameter(req, 'surname', 'xsd:string', r_app.surname);
        pkg_soap.add_parameter(req, 'r_cntry', 'xsd:string', r_app.r_cntry);
        pkg_soap.add_parameter(req, 'person_code', 'xsd:string', r_app.person_code);
        pkg_soap.add_parameter(req, 'title', 'xsd:string', r_app.title);
        pkg_soap.add_parameter(req, 'mar_status', 'xsd:string', r_app.mar_status);
        pkg_soap.add_parameter(req, 'm_name', 'xsd:string', r_app.m_name);
        pkg_soap.add_parameter(req, 'r_city', 'xsd:string', r_app.r_city);
        pkg_soap.add_parameter(req, 'r_street', 'xsd:string', r_app.r_street);
        pkg_soap.add_parameter(req, 'r_emails', 'xsd:string', r_app.r_emails);
        pkg_soap.add_parameter(req, 'r_mob_phone', 'xsd:string', r_app.r_mob_phone);
        pkg_soap.add_parameter(req, 'id_card', 'xsd:string', r_app.id_card);
        pkg_soap.add_parameter(req, 'serial_no', 'xsd:string', r_app.serial_no);
        pkg_soap.add_parameter(req, 'issued_by', 'xsd:string', r_app.issued_by);
        pkg_soap.add_parameter(req, 'card_name','xsd:string', ls_emboss_name);
      end loop;

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'EditCustomerElcardResponse/EditCustomerElcardResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'Result',ps_result_code);
        dbms_xslprocessor.valueof(l_n,'ErrorCode',ls_errorcode);
        dbms_xslprocessor.valueof(l_n,'ErrorDesc/text()',ls_errordesc);

        ld_endtime := sysdate;
        pkg_debit_card.ws_log ('EditCustomerElcard',
                                serviceurl,
                                methodname,
                                ld_starttime,
                                ld_endtime,
                                ps_result_code,
                                ls_errorcode,
                                pn_islem_no,
                                1001,
                                result,
                                req.body);
        return 1;
exception
when company_name_notfound then
        return 0;
        raise_application_error(-20100,pkg_hata.getucpointer || '20010' || pkg_hata.getdelimiter  || ps_result_code||' '||ls_errordesc || pkg_hata.getdelimiter || pkg_hata.getucpointer );
when others then
        return 0;
        ps_result_code:= '999';
        pkg_debit_card.ws_log('EditCustomerElcard',serviceurl,methodname,ld_starttime,ld_endtime,'999 '||utl_http.get_detailed_sqlerrm,sqlcode||' '||sqlerrm || ' ' || dbms_utility.format_error_backtrace,pn_islem_no,1203,result,req.body);
end;
/******************************************************************************
   NAME        : FUNCTION processElcardWSQueue
   Prepared By : NurmilaZ
   Date        : 24072020
   Purpose     : process Elcard ListCustomerCards
******************************************************************************/
procedure getdatabyelcard(pn_customer_no in number)
is

    ls_returncode varchar2(3):='0';
    account_no varchar2(300);
    serviceurl varchar2(300);
    soapaction varchar2(100);
    namespace varchar2(100);
    methodname varchar2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result clob;

    l_parser  dbms_xmlparser.parser;
    l_doc     dbms_xmldom.domdocument;
    l_nl      dbms_xmldom.domnodelist;
    l_n       dbms_xmldom.domnode;

    ls_errorcode varchar2(100);
    ls_errordesc varchar2(250);

    ls_bank_c   varchar2 (10);
    ls_group_c   varchar2 (10);
    ls_biller_ref   varchar2 (10);
    ls_payinstr_ref   varchar2 (20);
    pan varchar2(400 byte);
    risklevel varchar2(10 byte);
    stop_cause varchar2(10 byte);
    expiry varchar2(400 byte);
    ld_starttime date;
    ld_endtime date;
    ln_count number;
    ls_name varchar2(250);
    ls_branch varchar2(10 byte);
    pragma autonomous_transaction;
begin
    ld_starttime := sysdate;

    select hesap_no into account_no from cbs_hesap p    -- seval.colak  26072021 elcard performance problem   --from cbs_vw_hesap_izleme p
        where p.musteri_no = pn_customer_no
        and p.doviz_kodu = 'KGS'
        and p.urun_sinif_kod ='ELCARD NON INT.BR-LC'
        and p.durum_kodu='A';

    pkg_parametre.deger('ELCARD_SERVICE_URL', serviceurl);
    pkg_parametre.deger('ELCARD_BANK_C', ls_bank_c);
    pkg_parametre.deger('ELCARD_GROUP_C', ls_group_c);

        namespace := 'http://services.demirbank.kg/';
        methodname := 'getDatabyElcard';
        soapaction := namespace || methodname;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := pkg_soap.new_request(methodname, namespace);

        --add parameters to request
        pkg_soap.add_parameter(req, 'bank_c', 'xsd:string', ls_bank_c);
        pkg_soap.add_parameter(req, 'groupc', 'xsd:string', ls_group_c);
        pkg_soap.add_parameter(req, 'account_no', 'xsd:string', account_no);

        --call web service, and get response
        resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);
        result := resp.doc.getstringval();
        result:= replace(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newparser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getdocument(l_parser);
        l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'getDatabyElcardResponse/getDatabyElcardResult');
        --l_n := dbms_xmldom.item(l_nl, 0);

        select count(*) into ln_count from cbs_elcard where customer_no=pn_customer_no;

        if ln_count>0 then
            delete from cbs_elcard where customer_no=pn_customer_no;
        end if;

        for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1
        loop
            l_n := dbms_xmldom.item (l_nl, cur_emp);
            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueof(l_n, 'Result', ls_returncode);
            dbms_xslprocessor.valueof(l_n, 'Pan', pan);
            dbms_xslprocessor.valueof(l_n, 'Expiry', expiry);
            dbms_xslprocessor.valueof(l_n, 'Risklevel', risklevel);
            dbms_xslprocessor.valueof(l_n, 'Stop_Cause', stop_cause);
            dbms_xslprocessor.valueof(l_n, 'Name', ls_name);
            dbms_xslprocessor.valueof(l_n, 'Branch', ls_branch);
            dbms_xslprocessor.valueof(l_n, 'ErrorCode',ls_errorcode);
            dbms_xslprocessor.valueof(l_n, 'ErrorDesc/text()',ls_errordesc);

           pan := pkg_debit_card.get_masked_Cardno(pan);
           
           insert into cbs_elcard(customer_no, pan, stop_cause, risk_level, expiry, create_date, branch)
                    values(pn_customer_no, pan, stop_cause, risklevel, to_date(expiry,'yyyy-mm-dd'), sysdate, ls_branch);
        end loop;
        ld_endtime := sysdate;
        pkg_debit_card.ws_log ('getDatabyElcard',
                                serviceurl,
                                methodname,
                               ld_starttime,
                                ld_endtime,
                                ls_errorcode,
                                ls_errordesc,
                                null,
                                null,
                                result,
                                req.body);
        commit;
exception
    when others then
        result := sqlerrm;
        pkg_debit_card.ws_log ('CREDIT CARD INFO',
                                serviceurl,
                                methodname,
                                ld_starttime,
                                ld_endtime,
                                '096',
                                sqlcode || ' ' || sqlerrm,
                                null,
                                null,
                                result,
                                req.body);
        log_at('getDatabyElcard',sqlerrm);
        rollback;
end;
end pkg_elcard;
/

