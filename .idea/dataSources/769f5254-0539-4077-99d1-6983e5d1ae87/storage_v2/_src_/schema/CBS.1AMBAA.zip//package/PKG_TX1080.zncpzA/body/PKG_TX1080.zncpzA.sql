create PACKAGE BODY     PKG_TX1080 IS

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
        NULL;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
      INSERT INTO CBS.CBS_DOCUMENT_INFORMATION(DOC_ID, DOC_VERSION, START_DATE, VALIDITY_DATE, CREATE_USER, CREATED_DATE) 
           SELECT DOC_ID, UPPER(DOC_VERSION), START_DATE, VALIDITY_DATE, USER, SYSDATE 
             FROM CBS.CBS_DOCUMENT_INFORMATION_TX 
            WHERE TX_NO = PN_ISLEM_NO;
      COMMIT;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

---------------------------------------------------------------------------
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
       Null;
  End;
---------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
---------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
---------------------------------------------------------------------------
Procedure Muhasebelesme(pn_islem_no number) IS
Begin
    NULL;   
End;

/**
* Procedure check_version_document for checking duplicate version document in CBS 
* @author Marat Mamatzhanov
* @version 1.0 (23.08.2021)
*/
PROCEDURE check_version_document(ps_ver VARCHAR2, pn_doc_id NUMBER) 
IS
    tmpVar NUMBER;
    duplicate_ver exception;
    first_latter_v exception;

BEGIN
   tmpVar := 0;
   SELECT COUNT(*)
     INTO tmpVar
     FROM CBS.CBS_DOCUMENT_INFORMATION
    WHERE doc_id = pn_doc_id AND UPPER(doc_version) = UPPER(ps_ver);
   
   IF tmpVar > 0 THEN
        RAISE duplicate_ver;
   END IF;
   
   IF SUBSTR(UPPER(ps_ver), 1, 1) NOT IN ('V') THEN
        RAISE first_latter_v;
   END IF;  
      
   EXCEPTION
     WHEN duplicate_ver THEN
       raise_application_error(-20122, PKG_HATA.GETUCPOINTER || '20122' || PKG_HATA.GETUCPOINTER);
     WHEN first_latter_v THEN
       raise_application_error(-20121, PKG_HATA.GETUCPOINTER || '20121' || PKG_HATA.GETUCPOINTER);
END;

BEGIN
    NULL;
END ;
/

