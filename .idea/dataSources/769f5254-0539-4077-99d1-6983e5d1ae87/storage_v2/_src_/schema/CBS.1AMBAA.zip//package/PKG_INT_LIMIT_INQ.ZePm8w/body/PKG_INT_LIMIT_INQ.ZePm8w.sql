create PACKAGE BODY     PKG_INT_LIMIT_INQ IS  

FUNCTION GetTopicLimit(ps_lang varchar2,
                       ps_limit_type varchar2 default null,
                       ps_code varchar2 default null,
                       pc_ref OUT CursorReferenceType,
                       pc_ref2 OUT CursorReferenceType,
                       pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for
           select limit_type 
                  from cbs_int_transaction_limit
                    where limit_type = nvl(ps_limit_type, limit_type) 
                          and code = nvl(ps_code, code)
                             group by limit_type;
                         
  open pc_ref2 for
           select limit_type,
                  code, 
                  name 
                  from cbs_int_transaction_limit
                    where limit_type = nvl(ps_limit_type, limit_type) 
                          and code = nvl(ps_code, code)
                            group by limit_type, code, name;
  open pc_ref3 for
      select limit_type, 
              code, 
              period, 
              currency_code, 
              min_limit, 
              max_limit,
              0 as realization,
              max_limit as remaining,
              name as description from cbs_int_transaction_limit 
                 where limit_type = nvl(ps_limit_type, limit_type) 
                       and code = nvl(ps_code, code);
         
    return ls_returncode;  
     
EXCEPTION
    when others then
          log_at(ps_limit_type,'GetTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
          raise;
END; 
                              
FUNCTION GetCustomerLimit(ps_lang varchar2,
                      ps_customer_id varchar2,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN
  
  ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
  if ln_customer_no is null then
    raise le_customer_not_found;
  end if;
  
  open pc_ref for
           select limit_type 
                  from cbs_int_transaction_limit
                       group by limit_type;
  open pc_ref2 for
           select limit_type,
                  code, 
                  GetTopicLimitName(ps_lang,code) as name 
                      from cbs_int_transaction_limits
                         where customer_no = ln_customer_no group by limit_type, code;
  
  open pc_ref3 for
      select code,
             period,
             currency_code,
             min_limit,
             max_limit,
             round(used_limit, 2) as realization,
             round(max_limit - used_limit, 2) as remaining,
             is_private as private_limit
          from cbs_int_transaction_limits
            where customer_no = ln_customer_no
                  order by code, period;
         
    return ls_returncode; 
      
EXCEPTION
    when le_customer_not_found then
        log_at(ln_customer_no,'GetCustomerLimit', sqlerrm, dbms_utility.format_error_backtrace);
          return '454';
    when others then
        log_at(ln_customer_no,'GetCustomerLimit', sqlerrm, dbms_utility.format_error_backtrace);
          raise;
END; 
                          
FUNCTION GetCustomerTopicLimit(ps_lang varchar2,
                            ps_customer_id varchar2,
                            ps_code varchar2,
                            ps_period varchar2 default null,
                            ps_currency_code varchar2 default null,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

      ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
      if ln_customer_no is null then
        raise le_customer_not_found;
      end if;

      if (ps_currency_code is not null) then
          open pc_ref for
              select limit_type,
                     code,
                     period, 
                     currency_code, 
                     round(Pkg_Kur.doviz_doviz_karsilik(currency_code, ps_currency_code, NULL, min_limit, 1, NULL, NULL, 'O', 'A'), 2) as min_limit,
                     round(Pkg_Kur.doviz_doviz_karsilik(currency_code, ps_currency_code, NULL, max_limit, 1, NULL, NULL, 'O', 'A'), 2) as max_limit,
                     round(Pkg_Kur.doviz_doviz_karsilik(currency_code, ps_currency_code, NULL, used_limit, 1, NULL, NULL, 'O', 'A'), 2) as realization,
                     round(Pkg_Kur.doviz_doviz_karsilik(currency_code, ps_currency_code, NULL, max_limit - used_limit, 1, NULL, NULL, 'O', 'A'), 2) as remaining
                  from cbs_int_transaction_limits
                    where customer_no = ln_customer_no
                            and code = ps_code
                            and period = nvl(ps_period, period)
                            order by code, period;
      else             
              open pc_ref for
                  select limit_type,
                     code,
                     period, 
                     currency_code, 
                     min_limit,
                     max_limit,
                     round(used_limit, 2) as realization,
                     round(max_limit - used_limit, 2) as remaining
                  from cbs_int_transaction_limits
                    where customer_no = ln_customer_no
                            and code = ps_code
                            and period = nvl(ps_period, period)
                            order by code, period;
      end if;
         
     return ls_returncode; 
      
EXCEPTION
    when le_customer_not_found then
        log_at(ln_customer_no,'GetCustomerTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
          return '454';
    when others then
        log_at(ln_customer_no,'GetCustomerTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
          raise;
END;   
FUNCTION CheckCustomerTopicLimit(ps_lang varchar2,
                            ps_customer_id varchar2,
                            ps_code varchar2,
                            ps_amount in varchar2,
                            ps_currency_code varchar2 default null,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS                            
ln_total_limit number := 0;
ln_used_limit number := 0;
ln_amount number := 0;
ld_datetime date := sysdate;
ln_customer_no number;
ln_customer_type varchar2(1 byte);
ls_limit_type varchar2(20);

cursor cur_limit(c_customer_no varchar2, c_code varchar2) is
   select currency_code, period, min_limit, max_limit, used_limit  from cbs_int_transaction_limits where customer_no=c_customer_no and code=c_code;

row_cur_limit cur_limit%rowtype;

ls_returncode varchar2(3) := '000';

dailylimitexceededexception exception;
onetimelimitexceededexception exception;
custdailylimitexceedexception exception;
custonetmlimitexceedexception exception;
bnkdailylimitexceedexception exception;
bnkonetimelimitexceedexception exception; 
le_customer_not_found exception;
BEGIN   

   ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
   if ln_customer_no is null then
     raise le_customer_not_found;
   end if;
      
   ln_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no);
   
   select decode(ln_customer_type,'3','corporate','retail') into ls_limit_type from dual;

   ls_returncode := pkg_int_limit_trx.InitCustomerLimit(ps_code, ln_customer_no, ls_limit_type); 

   select min(datetime) into ld_datetime
         from cbs_int_transaction_limits
            where customer_no = ln_customer_no;
            
   if (ld_datetime < pkg_muhasebe.banka_tarihi_bul) then
        ls_returncode := pkg_int_limit_trx.ResetCustomerLimit(ln_customer_no, ls_limit_type);
   end if; 
    
   ln_amount := to_number(ps_amount,'99999999999.9999');
   ln_amount := cbs.pkg_kur.doviz_doviz_karsilik(ps_currency_code, pkg_genel.lc_al, null, ln_amount, 1, null, null, 'O', 'A');

   FOR row_cur_limit IN cur_limit(ln_customer_no, ps_code) LOOP 

        ln_total_limit := pkg_kur.doviz_doviz_karsilik(row_cur_limit.currency_code, pkg_genel.lc_al, null, row_cur_limit.max_limit, 1, null, null, 'O', 'A');
        ln_used_limit := pkg_kur.doviz_doviz_karsilik(row_cur_limit.currency_code, pkg_genel.lc_al, null, row_cur_limit.used_limit, 1, null, null, 'O', 'A');

        if (row_cur_limit.period = 'oneTime' and ln_amount > ln_total_limit) then
            raise onetimelimitexceededexception;
        end if;

        if (row_cur_limit.period = 'daily' and ln_amount > ln_total_limit - ln_used_limit) then
            raise dailylimitexceededexception;
        end if;

        -- retail limit check
        select pkg_kur.doviz_doviz_karsilik(currency_code, pkg_genel.lc_al, null, max_limit, 1, null, null, 'O', 'A')
            into ln_total_limit
            from cbs_int_transaction_limit
                   where limit_type = ls_limit_type
                        and period = row_cur_limit.PERIOD
                        and code = ps_code
                        and rownum = 1;
                        

        if (row_cur_limit.period = 'oneTime' and ln_amount > ln_total_limit) then
            raise custonetmlimitexceedexception;
        end if;

        if (row_cur_limit.period = 'daily' and ln_amount > ln_total_limit - ln_used_limit) then
            raise custdailylimitexceedexception;
        end if;

        -- check bank limits
       select pkg_kur.doviz_doviz_karsilik(currency_code, pkg_genel.lc_al, null, max_limit, 1, null, null, 'O', 'A')
            into ln_total_limit
            from cbs_int_transaction_limit
                   where limit_type = 'bank'
                        and period = row_cur_limit.PERIOD
                        and code = ps_code
                        and rownum = 1;

        if (row_cur_limit.period = 'oneTime' and ln_amount > ln_total_limit) then
            raise bnkonetimelimitexceedexception;
        end if;

        if (row_cur_limit.period = 'daily' and ln_amount > ln_total_limit - ln_used_limit) then
            raise bnkdailylimitexceedexception;
        end if;

   end loop;
    
    cbs.log_at('checkLimit_done', ln_amount, ln_total_limit, ln_used_limit);
    
    ls_returncode := GetCustomerTopicLimit(ps_lang => ps_lang,
                                            ps_code => ps_code,
                                            ps_customer_id => ps_customer_id,
                                            pc_ref => pc_ref);
                                            
    return ls_returncode;
    
EXCEPTION
    when onetimelimitexceededexception then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '456';
    when dailylimitexceededexception then
        open pc_ref for select '' from dual;
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '457';
    when custonetmlimitexceedexception then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '458';
    when custdailylimitexceedexception then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '459';
    when bnkonetimelimitexceedexception then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '460';
    when bnkdailylimitexceedexception then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '462';
    when le_customer_not_found then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        return '454';
    when others then
        log_at(ln_customer_no,'GetCheckTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        raise;
END;
FUNCTION GetTopicLimitName(ps_lang varchar2,
                           ps_code varchar2) RETURN varchar2
IS
ls_name varchar2(100);
BEGIN
    
   select distinct name into ls_name from cbs_int_transaction_limit 
              where code = ps_code
                    and limit_type = 'retail' 
                    and period = 'daily';  
    
   return ls_name;  
    
EXCEPTION
      when others then
        return 'None';  
END;                                                                       
END;
/

