create PACKAGE BODY     PKG_TX1201 IS
   

 Procedure eod_bakiye_kontrol(pn_islem_no number) is
    ln_musteri_no                        number;
    ln_hesap_no                           number;
    ln_bloke_tutari                     number;
    ln_kullanilabilir_bakiye            number;
    ln_eod_fis_no                        number;
    ln_bekleyen_adet                   number;
  cursor cursor_bloke is
      select musteri_no,hesap_no,bloke_tutari
      from   cbs_bloke_islem
      where  tx_no =pn_islem_no ;

  cursor cursor_eod_bakiye is
     select  b.fis_numara,
                 b.hesap_numara,
                 sum(decode(b.tur,'A', nvl(b.dv_tutar,0),0)) - sum(decode(b.tur,'B', nvl(b.dv_tutar,0),0)) bakiye
       from cbs_satir b
       where b.hesap_tur_kodu <> 'DK'
                and exists (select 1 from cbs_fis c , cbs_eod_Fis_no d
                  where c.numara = b.fis_numara
                    and c.muhasebelestigi_tarih is not null
                    and c.tur = 'G'
                    and c.numara = d.fis_numara and
                    d.durum = 'A')
            and  b.hesap_numara =  ln_hesap_no
         group by b.fis_numara,b.hesap_numara;

    eod_bakiye_yetersiz       exception;
  Begin
         /*  bloke tutar? alinir hesap guncellenir. */
   for  cur_bloke in cursor_bloke
    loop
       ln_musteri_no := cur_bloke.musteri_no ;
       ln_hesap_no   := cur_bloke.hesap_no;
       ln_bloke_tutari :=   cur_bloke.bloke_tutari;
       ln_kullanilabilir_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_hesap_no);

    --eod bekleyen fis mevcutmudur.
       select max(fis_numara)
       into  ln_eod_fis_no
       from cbs_satir b
       where b.hesap_tur_kodu <> 'DK'
                and exists (select 1 from cbs_fis c , cbs_eod_Fis_no d
                  where c.numara = b.fis_numara
                    and c.muhasebelestigi_tarih is not null
                    and c.tur = 'G'
                    and c.numara = d.fis_numara and
                    d.durum = 'A')
            and  b.hesap_numara =  ln_hesap_no;


            if  nvl(ln_eod_fis_no ,0) <> 0 and nvl(ln_kullanilabilir_bakiye,0) < nvl(ln_bloke_tutari,0) and nvl(ln_bloke_tutari,0) <> 0  then
                raise eod_bakiye_yetersiz;
            end if;

        end loop;

  Exception
     When eod_bakiye_yetersiz Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1502' || pkg_hata.getDelimiter ||to_char(ln_eod_fis_no ) || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_hesap_no  number;
   ln_tx_no     number;
   onaybekleyenislemvar exception;
  Begin
      select hesap_no
      into   ln_hesap_no
      from   cbs_bloke_islem
      where  tx_no =pn_islem_no;

     ln_tx_no := Pkg_Bloke.Sf_Onay_Bekleyen_Varmi( ln_hesap_no,1201 , pn_islem_no) ;

     if  nvl(ln_tx_no,0) <>  0 then
      raise onaybekleyenislemvar;
     end if;

      eod_bakiye_kontrol(pn_islem_no );
  Exception
   When onaybekleyenislemvar then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '429' || pkg_hata.getDelimiter ||to_char( ln_tx_no)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

  End;



  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
           /* Red edildi */
    update cbs_bloke_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;

  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  ld_banka_tarihi                date ;
  ln_bloke_tutari                cbs_bloke_islem.bloke_tutari%type;
  ln_musteri_no                    cbs_bloke_islem.musteri_no%type;
  ln_hesap_no                    cbs_bloke_islem.hesap_no%type;
  ln_eski_bloke_tutari            cbs_bloke_islem.bloke_tutari%type;
  ls_eski_bloke_referans        cbs_bloke_islem.bloke_referans%type;
  ln_ref_tx_no                    cbs_bloke_islem.ref_tx_no%type;
  ls_durum_kodu                    cbs_bloke_islem.durum_kodu%type;
  ls_durum                        cbs_bloke_islem.durum_kodu%type;
  ls_bloke_neden_kodu            cbs_bloke_islem.bloke_neden_kodu%type;
  ls_yeni_bloke_referans        cbs_bloke_islem.bloke_referans%type;
  Ld_Onay_Tarih                    date;
  Ld_Onay_Sistem_Tarihi            date;
  Ls_Onay_Kullanici_Kodu            cbs_Islem.Onay_Kullanici_Kodu%type;
  Ls_Onay_Kullanici_Bolum_Kodu        cbs_Islem.Onay_Kullanici_Bolum_Kodu%type;

  Ld_kayit_Tarih                    date;
  Ld_kayit_Sistem_Tarihi            date;
  Ls_kayit_Kullanici_Kodu            cbs_Islem.Onay_Kullanici_Kodu%type;
  Ls_kayit_Kullanici_Bolum_Kodu        cbs_Islem.Onay_Kullanici_Bolum_Kodu%type;

  Ld_dogru_Tarih                    date;
  Ld_dogru_Sistem_Tarihi            date;
  Ls_dogru_Kullanici_Kodu            cbs_Islem.Onay_Kullanici_Kodu%type;
  Ls_dogru_Kullanici_Bolum_Kodu        cbs_Islem.Onay_Kullanici_Bolum_Kodu%type;
  oncedenkapanmis  exception;
  Begin

        eod_bakiye_kontrol(pn_islem_no );

     select
      kayit_Tarih    ,
      kayit_Sistem_Tarihi,
      kayit_Kullanici_Kodu,
      kayit_Kullanici_Bolum_Kodu,
      nvl(dogru_Tarih, onay_Tarih    ) dogru_tarih,
        nvl(dogru_Kullanici_Kodu,onay_kullanici_kodu) dogru_Kullanici_Kodu,
      nvl( dogru_Kullanici_Bolum_Kodu,onay_kullanici_bolum_kodu) dogru_Kullanici_Bolum_Kodu,
      onay_tarih,
      onay_sistem_tarihi,
      onay_kullanici_kodu,
      onay_kullanici_bolum_kodu
    into
      Ld_kayit_Tarih    ,
      Ld_kayit_Sistem_Tarihi,
      Ls_kayit_Kullanici_Kodu,
      Ls_kayit_Kullanici_Bolum_Kodu,
      Ld_dogru_Tarih,
      Ls_dogru_Kullanici_Kodu,
      Ls_dogru_Kullanici_Bolum_Kodu,
      ld_onay_tarih,
      ld_onay_sistem_tarihi,
      ls_onay_kullanici_kodu,
      ls_onay_kullanici_bolum_kodu
    from cbs_islem
    where numara = pn_islem_no ;

   ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;

  /*  bloke tutar? alinir hesap guncellenir. */
      select musteri_no,hesap_no,bloke_tutari,ref_tx_no ,bloke_neden_kodu
      into   ln_musteri_no,ln_hesap_no,ln_bloke_tutari ,ln_ref_tx_no,ls_bloke_neden_kodu
      from   cbs_bloke_islem
      where  tx_no =pn_islem_no;

  /* eski bloke tutar? al?n?r */
          SELECT bloke_tutari,bloke_referans ,durum_kodu
       INTO   ln_eski_bloke_tutari ,ls_eski_bloke_referans,ls_durum
       FROM   CBS_BLOKE
       WHERE  internal_ref_no =  ln_ref_tx_no;

     if ls_durum != 'A' then
         raise oncedenkapanmis ;
     else
    --   Pkg_Bloke.Sp_Bloke_Bilgi_Al(ln_ref_tx_no,ln_eski_bloke_tutari ,ls_eski_bloke_referans);

     /* hesap bakiye guncellenir */
          Pkg_Hesap.BlokeTutariGuncelle(ln_hesap_no, -1 * nvl(ln_eski_bloke_tutari,0) + nvl(ln_bloke_tutari,0));
          /* eski islem kapatilir */
          update cbs_bloke_islem
          set   durum_kodu  = 'K',
                coz_kayit_tarih =   ld_kayit_tarih,
                coz_kayit_sistem_tarih =ld_kayit_sistem_tarihi,
                coz_kayit_kullanici_kodu = ls_kayit_kullanici_kodu ,
                coz_kayit_kullanici_bolum_kodu = kayit_kullanici_bolum_kodu,
                coz_dogru_tarih   =  ld_dogru_tarih,
                coz_dogru_kullanici_kodu = ls_dogru_kullanici_kodu ,
                coz_dogru_kullanici_bolum_kodu =ls_dogru_kullanici_bolum_kodu ,
                coz_onay_tarih  =ld_onay_tarih,
                coz_onay_sistem_tarih =ld_onay_sistem_tarihi,
                coz_onay_kullanici_kodu = ls_onay_kullanici_kodu ,
                coz_onay_kullanici_bolum_kodu =ls_onay_kullanici_bolum_kodu
          where internal_ref_no =ln_ref_tx_no;

          update cbs_bloke
          set   durum_kodu  = 'K',
                coz_kayit_tarih =   ld_kayit_tarih,
                coz_kayit_sistem_tarih =ld_kayit_sistem_tarihi,
                coz_kayit_kullanici_kodu = ls_kayit_kullanici_kodu ,
                coz_kayit_kullanici_bolum_kodu = kayit_kullanici_bolum_kodu,
                coz_dogru_tarih   =  ld_dogru_tarih,
                coz_dogru_kullanici_kodu = ls_dogru_kullanici_kodu ,
                coz_dogru_kullanici_bolum_kodu =ls_dogru_kullanici_bolum_kodu ,
                coz_onay_tarih  =ld_onay_tarih,
                coz_onay_sistem_tarih =ld_onay_sistem_tarihi,
                coz_onay_kullanici_kodu = ls_onay_kullanici_kodu ,
                coz_onay_kullanici_bolum_kodu =ls_onay_kullanici_bolum_kodu
          where internal_ref_no =ln_ref_tx_no;


       /* girilen deger 0 ise bloke kapatilmak icin guncelleniyor demektir, eski deger atanir. referans korunur */
           if nvl(ln_bloke_tutari,0) = 0 then
            ls_durum_kodu := 'K';
             ls_yeni_bloke_referans := ls_eski_bloke_referans;
         else
          /* yeni bloke referansi alinir */
            ls_yeni_bloke_referans :=  pkg_bloke.sf_bloke_referansno_Al;
             ls_durum_kodu := 'A';
         end if;


      /* islem guncellenir  ,tutar 0 ise kapatilir. */
          update cbs_bloke_islem
          set    bloke_tarihi = pkg_muhasebe.banka_tarihi_bul ,
                   bloke_referans = ls_yeni_bloke_referans,
                 durum_kodu = ls_durum_kodu,
                 kayit_tarih =   ld_kayit_tarih,
                 kayit_sistem_tarihi =ld_kayit_sistem_tarihi,
                 kayit_kullanici_kodu = ls_kayit_kullanici_kodu ,
                 kayit_kullanici_bolum_kodu = kayit_kullanici_bolum_kodu,
                 dogru_tarih   =  ld_dogru_tarih,
                 dogru_kullanici_kodu = ls_dogru_kullanici_kodu ,
                 dogru_kullanici_bolum_kodu =ls_dogru_kullanici_bolum_kodu ,
                 onay_tarih  =ld_onay_tarih,
                 onay_sistem_tarihi =ld_onay_sistem_tarihi,
                 onay_kullanici_kodu = ls_onay_kullanici_kodu ,
                 onay_kullanici_bolum_kodu =ls_onay_kullanici_bolum_kodu,
                 coz_kayit_tarih =  decode(ls_durum_kodu,'K',   ld_kayit_tarih,NULL ),
                 coz_kayit_sistem_tarih =decode(ls_durum_kodu,'K', ld_kayit_sistem_tarihi,NULL),
                 coz_kayit_kullanici_kodu = decode(ls_durum_kodu,'K',ls_kayit_kullanici_kodu ,NULL),
                 coz_kayit_kullanici_bolum_kodu =decode(ls_durum_kodu,'K', kayit_kullanici_bolum_kodu,NULL),
                 coz_dogru_tarih   = decode(ls_durum_kodu,'K', ld_dogru_tarih,NULL),
                 coz_dogru_kullanici_kodu = decode(ls_durum_kodu,'K',ls_dogru_kullanici_kodu ,NULL),
                 coz_dogru_kullanici_bolum_kodu =decode(ls_durum_kodu,'K',ls_dogru_kullanici_bolum_kodu ,NULL),
                 coz_onay_tarih  =  decode(ls_durum_kodu,'K',ld_onay_tarih, NULL),
                 coz_onay_sistem_tarih =decode(ls_durum_kodu,'K',ld_onay_sistem_tarihi,NULL),
                 coz_onay_kullanici_kodu = decode(ls_durum_kodu,'K',ls_onay_kullanici_kodu ,NULL),
                 coz_onay_kullanici_bolum_kodu =decode(ls_durum_kodu,'K',ls_onay_kullanici_bolum_kodu,NULL)
          where tx_no =pn_islem_no;

         if  ls_yeni_bloke_referans != ls_eski_bloke_referans then
              insert into  cbs_bloke(
                  musteri_no, hesap_no, doviz_kodu, durum_kodu,
                  bloke_tutari, bloke_referans, bloke_neden_kodu,
                  aciklama, islem_tanim_kod, bloke_tarihi, bloke_bitis_tarihi,
                  ref_tx_no, kayit_tarih, kayit_sistem_tarihi, kayit_kullanici_kodu,
                  kayit_kullanici_bolum_kodu, dogru_tarih, dogru_kullanici_kodu,
                  dogru_kullanici_bolum_kodu, onay_tarih, onay_sistem_tarihi,
                  onay_kullanici_kodu, onay_kullanici_bolum_kodu, coz_kayit_tarih,
                  coz_kayit_sistem_tarih, coz_kayit_kullanici_kodu,
                  coz_kayit_kullanici_bolum_kodu, coz_dogru_tarih, coz_dogru_kullanici_kodu,
                  coz_dogru_kullanici_bolum_kodu, coz_onay_tarih, coz_onay_sistem_tarih,
                  coz_onay_kullanici_kodu,
                  coz_onay_kullanici_bolum_kodu, internal_ref_no)
               select
                  musteri_no, hesap_no, doviz_kodu, durum_kodu,
                  bloke_tutari, bloke_referans, bloke_neden_kodu,
                  aciklama, islem_tanim_kod, bloke_tarihi, bloke_bitis_tarihi,
                  ref_tx_no, kayit_tarih, kayit_sistem_tarihi, kayit_kullanici_kodu,
                  kayit_kullanici_bolum_kodu, dogru_tarih, dogru_kullanici_kodu,
                  dogru_kullanici_bolum_kodu, onay_tarih, onay_sistem_tarihi,
                  onay_kullanici_kodu, onay_kullanici_bolum_kodu, coz_kayit_tarih,
                  coz_kayit_sistem_tarih, coz_kayit_kullanici_kodu,
                  coz_kayit_kullanici_bolum_kodu, coz_dogru_tarih, coz_dogru_kullanici_kodu,
                  coz_dogru_kullanici_bolum_kodu, coz_onay_tarih, coz_onay_sistem_tarih,
                  coz_onay_kullanici_kodu,
                  coz_onay_kullanici_bolum_kodu, internal_ref_no
             from cbs_bloke_islem
             where tx_no =pn_islem_no;
         else
          update  cbs_bloke
          set (
              musteri_no, hesap_no, doviz_kodu, durum_kodu,
              bloke_tutari, bloke_referans, bloke_neden_kodu,
              aciklama, islem_tanim_kod, bloke_tarihi, bloke_bitis_tarihi,
              ref_tx_no, kayit_tarih, kayit_sistem_tarihi, kayit_kullanici_kodu,
              kayit_kullanici_bolum_kodu, dogru_tarih, dogru_kullanici_kodu,
              dogru_kullanici_bolum_kodu, onay_tarih, onay_sistem_tarihi,
              onay_kullanici_kodu, onay_kullanici_bolum_kodu, coz_kayit_tarih,
              coz_kayit_sistem_tarih, coz_kayit_kullanici_kodu,
              coz_kayit_kullanici_bolum_kodu, coz_dogru_tarih, coz_dogru_kullanici_kodu,
              coz_dogru_kullanici_bolum_kodu, coz_onay_tarih, coz_onay_sistem_tarih,
              coz_onay_kullanici_kodu,
              coz_onay_kullanici_bolum_kodu, internal_ref_no )
          = ( select
                 musteri_no, hesap_no, doviz_kodu, durum_kodu,
                  bloke_tutari, bloke_referans, bloke_neden_kodu,
                  aciklama, islem_tanim_kod, bloke_tarihi, bloke_bitis_tarihi,
                  ref_tx_no, kayit_tarih, kayit_sistem_tarihi, kayit_kullanici_kodu,
                  kayit_kullanici_bolum_kodu, dogru_tarih, dogru_kullanici_kodu,
                  dogru_kullanici_bolum_kodu, onay_tarih, onay_sistem_tarihi,
                  onay_kullanici_kodu, onay_kullanici_bolum_kodu, coz_kayit_tarih,
                  coz_kayit_sistem_tarih, coz_kayit_kullanici_kodu,
                  coz_kayit_kullanici_bolum_kodu, coz_dogru_tarih, coz_dogru_kullanici_kodu,
                  coz_dogru_kullanici_bolum_kodu, coz_onay_tarih, coz_onay_sistem_tarih,
                  coz_onay_kullanici_kodu,
                  coz_onay_kullanici_bolum_kodu, internal_ref_no
                  from cbs_bloke_islem
                  where tx_no =pn_islem_no)
           where bloke_referans = ls_eski_bloke_referans;
         end if;
    end if;
     --  Pkg_bloke.Sp_Bloke_Guncelle(pn_islem_no);

  Exception
   When oncedenkapanmis then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '924' || pkg_hata.getDelimiter ||ls_eski_bloke_referans||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '436' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
  null;
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     /* Red edildi */
    update cbs_bloke_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
 Begin
  null;
 End;

 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block    varchar2,ps_rowid   varchar2,
                                 ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
   guncellenmis_exception               exception;
   ln_retval              number:=0;
   ls_sqlstr              varchar2(2000);
   ls_sql_template          varchar2(2000);
   ls_source_table          varchar2(2000);
   ls_dest_table          varchar2(2000);
  Begin

   if ps_block='CBS_BLOKE_ISLEM' then
        --TODO 1: Set the source and destination table names
          ls_source_table:='CBS_BLOKE_ISLEM';
       ls_dest_table:='CBS_BLOKE_ISLEM';
   if ps_column<>'BLOKE_REFERANS' and ps_column<>'TX_NO'  then
     --TODO 2: Set the Primary Key Count (Default 1)
       ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(1);
     --TODO 3: Do not alter until next TODO :)
        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
           ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
        ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
     --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TX_NO');
           ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','REF_TX_NO');
      --insert into cbs_yphavale_test values(ls_sql_template);
       execute immediate ls_sql_template into ln_retval,ps_oldvalue;
     end if;
    end if;

    if ln_retval<>1 then
       raise  guncellenmis_exception;
     end if;
  Exception
   When  guncellenmis_exception then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   End;
   
   
   --------------------------------------------------------------------------------------------------- BaiamanG
   
  Procedure get_customer_accounts(pn_cust_no CBS_MUSTERI.MUSTERI_NO%TYPE,  pRetCur IN OUT GenCurType)
   is
  Begin   
  OPEN pRetCur FOR 
  
  SELECT HESAP_NO,SUBE_KODU, MUSTERI_NO, upper(ISIM_UNVAN) isim_unvan, DOVIZ_KODU, URUN_TUR_KOD,URUN_SINIF_KOD,DURUM_KODU  
  
FROM CBS_VW_HESAP_IZLEME
    
    WHERE MUSTERI_NO = pn_cust_no and
              Pkg_Bloke.Sf_Hesap_Bloke_Konan_Urunmu(hesap_no) = 'E' and
             hesap_no in (
                    select  hesap_no
                    from cbs_bloke
                    where  durum_kodu= 'A')         -- and substr(bloke_referans,4,3) =pkg_baglam.bolum_kodu)
          and durum_kodu = 'A'       
                --and  sube_kodu =pkg_baglam.bolum_kodu
order by upper(ISIM_UNVAN); 

   EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 
  End;   
  
  --------------------------------------------------------------------------------------------------------------BaiamanG 
   
END ;
/

