create PACKAGE BODY pkg_report1
IS

   FUNCTION cbs_rapor_srv_data (P_col_no NUMBER, P_str_no NUMBER, date_report DATE, dvz_code number)
      RETURN NUMBER
   IS
      RESULT   NUMBER;
	  tmp	   NUMBER;
   BEGIN
--**********************1-st string******************************
--**********************1-st string******************************
      result := 0;
	  select count(*)
	    into tmp
		from cbs_rpt_srv
	   where date_no = date_report;

	  IF tmp > 0 then
	    select sum(decode(p_col_no, 1, a.COL1, 2, a.COL2, a.COL4))*1000
		  into result
		  from cbs_rpt_srv_full a
		 where a.date_no = date_report and
        			 	   ((dvz_code = '0' and CURR = CURR) or
						    (dvz_code = '1' and CURR in ('KZT')) or
        				    (dvz_code = '2' and CURR in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and CURR in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and CURR in ('USD')) or
							(dvz_code = '6' and CURR in ('EUR')) or
							(dvz_code = '7' and CURR in ('GBP')) or
							(dvz_code = '8' and CURR in ('CHF')) or
							(dvz_code = '9'  and CURR in ('RUB', 'RUR')) or
							(dvz_code = '10' and CURR in ('TRL', 'TRY')) or
        					(dvz_code = '4' and CURR in ('SOM','KGS'))) and
		 	   a.str_no = p_str_no ;

	  else

      IF P_col_no = 1 AND P_str_no = 1 THEN
	    if dvz_code = '0' then
         BEGIN
            select sum(b)
              into result
              from (select (case when numara in ('1001', '1002', '1003', '1004', '1051', '8717', '1101', '1102', '8122', '8715', '8720')
                    	   		 then bakiye else 0
                    	    end-
                    	    case when numara in ('8716')
                    	   		then bakiye else 0
                    	    end)*1000 b
                      from cbs_vw_sn_balance a
                     where date_no = date_report and
                     	   numara in ('1001', '1002', '1003', '1004', '1051', '8717', '1101', '1102', '8122', '8715', '8720', '8716'));         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
	    else
         BEGIN
            select sum(b)
              into result
              from (select (case when numara in ('1001', '1002', '1003', '1004', '1051', '8717', '1101', '1102', '8122', '8715', '8720')
                    	   		 then bakiye else 0
                    	    end-
                    	    case when numara in ('8716')
                    	   		 then bakiye else 0
                    	    end)*1000 b
                      from cbs_vw_sn_balance_doviz a
                     where date_no = date_report and
        			 	   ((dvz_code = '1' and doviz_kod in ('KZT')) or
        				   (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUB', 'RUR', 'TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                     	   numara in ('1001', '1002', '1003', '1004', '1051', '8717', '1101', '1102', '8122', '8715', '8720', '8716'));         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
        end if;
      END IF;

      IF P_col_no = 2 AND P_str_no = 1 THEN
         BEGIN
		   select sum(sm)
		     into result
		    from (SELECT SUM(bakiye*1000) sm
                    FROM cbs_vw_sn_balance
                   WHERE date_no = DATE_REPORT and
      			 	   dvz_code = '0' and
                         numara IN ('2013', '2113', '2125', '2203', '2204', '2205', '2209', '2211', '2221',/* sn*/  '2880', '2862', '2856', '2852', '2302', '2053')
                   UNION all
                  SELECT SUM(bakiye*1000)
                    FROM cbs_vw_sn_balance_doviz
                   WHERE date_no = DATE_REPORT and
      			 	   ((dvz_code = '1' and doviz_kod in ('KZT')) or
      				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
      					(dvz_code = '3' and doviz_kod in ('RUB', 'RUR', 'TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
      					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                         numara IN ('2013', '2113', '2125', '2203', '2204', '2205', '2209', '2211', '2221',/* sn*/  '2880', '2862', '2856', '2852', '2302', '2053'));
         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;


      --**********************2-nd string******************************
	  --**********************2-nd string******************************
      IF P_col_no = 1 AND P_str_no = 2 THEN
	    if dvz_code = '0' then
         BEGIN
            select sum(b)
              into result
              from (select (case when numara in (/*'1456',*/ '1052', '1252', '1251', '1253', '1458', '1301', '1303', '1321', '1401', '1403', '1851',    '1853', '1854', '1855', '1856', '1860', '1864', '1867', '1870')
                    	   		 then bakiye else 0
                    	    end-
                    	    case when numara in ('8717')
                    	   		then bakiye else 0
                    	    end)*1000 b
                      from cbs_vw_sn_balance a
                     where date_no = date_report and
                     	   numara in (/*'1456', */'1052', '1252', '1251', '1253', '1458', '1301', '1303', '1321', '1401', '1403', '1851',    '1853', '1854', '1855', '1856', '1860', '1864', '1867', '1870', '8717')
					 union all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,
						   nvl(case when ((substr(b.musteri_dk_no, 1, 1) = '1') and c.BAKIYE >0) or ((substr(b.musteri_dk_no, 1, 1) = '2') and c.BAKIYE < 0)
							    then -abs(c.BAKIYE)
								else  abs(c.BAKIYE)
						   end, 0),
						   1,NULL,NULL,'N','A')) sum_
                  	  from cbs_hesap_kredi b,
                	   	   cbs_hesap_gunluk_bakiye c
					   where substr(b.musteri_dk_no, 1, 4) in ('1103', '1302', '1304','1322','1323','1407','1411','1417','1254','1255','1256','1420','1422','1429') and
                	   	   b.HESAP_NO = c.HESAP_NO and
						   --b.DURUM_KODU='A' and
                	   	   BALANCE_DATE= DATE_REPORT and
                	   	   b.kredi_vade - b.acilis_tarihi < 33);
		 EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
	    else
         BEGIN
            select sum(b)
              into result
              from (select (case when numara in (/*'1456', */'1052', '1252', '1251', '1253', '1458', '1301', '1303', '1321', '1401', '1403', '1851',    '1853', '1854', '1855', '1856', '1860', '1861', '1864', '1867', '1870')
                    	   		 then bakiye else 0
                    	    end-
                    	    case when numara in ('8717')
                    	   		then bakiye else 0
                    	    end)*1000 b
                      from cbs_vw_sn_balance_doviz a
                     where date_no = date_report and
        			 	   ((dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUB', 'RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                     	   numara in (/*'1456', */'1052', '1252', '1251', '1253', '1458', '1301', '1303', '1321', '1401', '1403', '1851',    '1853', '1854', '1855', '1856', '1860', '1864', '1867', '1870', '8717')
					 union all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,
						   nvl(case when ((substr(b.musteri_dk_no, 1, 1) = '1') and c.BAKIYE >0) or ((substr(b.musteri_dk_no, 1, 1) = '2') and c.BAKIYE < 0)
							    then -abs(c.BAKIYE)
								else  abs(c.BAKIYE)
						   end, 0),
						   1,NULL,NULL,'N','A')) sum_
                  	  from cbs_hesap_kredi b,
                	   	   cbs_hesap_gunluk_bakiye c
					   where substr(b.musteri_dk_no, 1, 4) in ('1103', '1302', '1304','1322','1323','1407','1411','1417','1254','1255','1256','1420','1422','1429') and
                	   	   b.HESAP_NO = c.HESAP_NO and
        			 	   ((dvz_code = '1' and doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kodu in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kodu in ('SOM','KGS'))) and
						   --b.DURUM_KODU='A' and
                	   	   BALANCE_DATE= DATE_REPORT and
                	   	   b.kredi_vade - b.acilis_tarihi < 33);
		 EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
        end if;
      END IF;

      IF P_col_no = 2 AND P_str_no = 2 THEN
         BEGIN
            select sum(b)
              into result
              from (select bakiye*1000 b
                      from cbs_vw_sn_balance_doviz a
                     where date_no = date_report and
        			 	   ((dvz_code = '0' and doviz_kod = doviz_kod) or
						    (dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                     	   numara in ('2851', '2855', '2860', '2867', '2870', '2255', '2853', '2854', '2857')
					 union all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,
						   nvl(case when ((substr(b.musteri_dk_no, 1, 1) = '1') and c.BAKIYE >0) or ((substr(b.musteri_dk_no, 1, 1) = '2') and c.BAKIYE < 0)
							    then -abs(c.BAKIYE)
								else  abs(c.BAKIYE)
						   end, 0),
						   1,NULL,NULL,'N','A')) sum_
                  	  from cbs_rpt_vadeli_gunsonu_faiz b,
                	   	   cbs_hesap_gunluk_bakiye c
					   where substr(b.musteri_dk_no, 1, 4) in ('2123', '2124','2127','2130','2131','2133','2206','2207','2208','2213','2215','2217','2219', '2223') and
                	   	   b.HESAP_NO = c.HESAP_NO and
        			 	   ((dvz_code = '0' and doviz_kodu = doviz_kodu) or
						    (dvz_code = '1' and doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kodu in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kodu in ('SOM','KGS'))) and
						   --b.DURUM_KODU='A' and
						   b.BANKA_TARIHI = DATE_REPORT AND
                	   	   BALANCE_DATE= DATE_REPORT and
                	   	   b.vade_tarihi - b.acilis_tarihi < 33);
		 EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;

      --**********************3,4,5 string******************************
	  --**********************3,4,5 string******************************
      IF P_col_no = 1 AND P_str_no in (3,4,5) THEN
         BEGIN
		 	   select sum(b)
			     into result
			     from (
                    select sum(bakiye)*1000 b
                      from cbs_vw_sn_balance a
                     where date_no = date_report and
                     	   numara in ('1857', '1861') and P_str_no = 5 and dvz_code=0
				     union all
                    select sum(bakiye)*1000 b
                      from cbs_vw_sn_balance_doviz a
                     where date_no = date_report and
                     	   numara in ('1857', '1861') and P_str_no = 5 and
					     ((dvz_code = '1' and doviz_kod in ('KZT')) or
        				  (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        				  (dvz_code = '3' and doviz_kod in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        				  (dvz_code = '4' and doviz_kod in ('SOM','KGS')))
				     union all
					select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,
						   nvl(case when ((substr(b.musteri_dk_no, 1, 1) = '1') and c.BAKIYE >0) or ((substr(b.musteri_dk_no, 1, 1) = '2') and c.BAKIYE < 0)
							    then -abs(c.BAKIYE)
								else  abs(c.BAKIYE)
						   end, 0),
						   1,NULL,NULL,'N','A')) sum_
                  	  from cbs_hesap_kredi b,
                	   	   cbs_hesap_gunluk_bakiye c
					   where substr(b.musteri_dk_no, 1, 4) in ('1103', '1302', '1304','1322','1323','1407','1411','1417','1254','1255','1256','1420','1422','1429') and
                	   	   b.HESAP_NO = c.HESAP_NO and
        			 	   ((dvz_code = '0' and doviz_kodu = doviz_kodu) or
						   	(dvz_code = '1' and doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kodu in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kodu in ('SOM','KGS'))) and
                	   	   BALANCE_DATE= DATE_REPORT and
						   (
						   (P_str_no=3 and b.kredi_vade - b.acilis_tarihi > 32 and
						   			 	 b.kredi_vade - b.acilis_tarihi < 93) or
						   (P_str_no=4 and b.kredi_vade - b.acilis_tarihi > 92 and
						   			 	 b.kredi_vade - b.acilis_tarihi < 183) or
						   (P_str_no=5 and b.kredi_vade - b.acilis_tarihi > 182 and
						   			 	 b.kredi_vade - b.acilis_tarihi < 368)
						   ));
		 EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;

      IF P_col_no = 2 AND P_str_no in (3,4,5) THEN
         BEGIN
		    select sum(b)
			  into result
			  from (select bakiye*1000 b
                      from cbs_vw_sn_balance_doviz a
                     where date_no = date_report and
        			 	   ((dvz_code = '0' and doviz_kod = doviz_kod) or
						    (dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                     	   numara in ('2240', '2237') and
						   P_str_no = 3
					 union all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,
						   nvl(case when ((substr(b.musteri_dk_no, 1, 1) = '1') and c.BAKIYE >0) or ((substr(b.musteri_dk_no, 1, 1) = '2') and c.BAKIYE < 0)
							    then -abs(c.BAKIYE)
								else  abs(c.BAKIYE)
						   end, 0),
						   1,NULL,NULL,'N','A')) b
                  	  from cbs_rpt_vadeli_gunsonu_faiz b,
                	   	   cbs_hesap_gunluk_bakiye c
					 where substr(b.musteri_dk_no, 1, 4) in ('2123', '2124','2127','2130','2131','2133','2206','2207','2208','2213','2215','2217','2219', '2223') and
                	   	   b.HESAP_NO = c.HESAP_NO and
        			 	   ((dvz_code = '0' and doviz_kodu = doviz_kodu) or
						    (dvz_code = '1' and doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kodu in ('RUB','RUR','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kodu in ('SOM','KGS'))) and
						   --b.DURUM_KODU='A' and
						   b.BANKA_TARIHI = DATE_REPORT and
                	   	   BALANCE_DATE= DATE_REPORT and
						   (
						   (P_str_no=3 and b.vade_tarihi - b.acilis_tarihi > 32 and
						   			 	 b.vade_tarihi - b.acilis_tarihi < 93) or
						   (P_str_no=4 and b.vade_tarihi - b.acilis_tarihi > 92 and
						   			 	 b.vade_tarihi - b.acilis_tarihi < 183) or
						   (P_str_no=5 and b.vade_tarihi - b.acilis_tarihi > 182 and
						   			 	 b.vade_tarihi - b.acilis_tarihi < 368)
						   ));
		 EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;


      --**********************6-th string******************************
	  --**********************6-th string******************************
      IF P_col_no = 1 AND P_str_no = 6
      THEN
         BEGIN
            SELECT abs(SUM (sum_))
              INTO RESULT
              FROM (SELECT SUM (bakiye_lc) sum_
                      FROM cbs_dkhesap_gunluk_bakiye
                     WHERE to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_REPORT and
        			 	   ((dvz_code = '0' and doviz_kod = doviz_kod) or
        				    (dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUR','RUB','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                           (SUBSTR(numara, 1, 4) IN ('1476') or
						    SUBSTR(numara, 1, 6) IN ('145125', '145325', '174525'))
                     UNION all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,nvl(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_
                  	  from cbs_hesap_kredi b,
                	   	   cbs_hesap_gunluk_bakiye c
                     where substr(b.musteri_dk_no, 1, 4) in ('1302', '1304','1322','1323','1407','1411','1417','1254','1255','1256','1420','1422','1429') and
        			 	   ((dvz_code = '0' and b.doviz_kodu = b.doviz_kodu) or
        				    (dvz_code = '1' and b.doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and b.doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and b.doviz_kodu in ('RUR','RUB','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and b.doviz_kodu in ('SOM','KGS'))) and
                	   	   c.HESAP_NO = b.HESAP_NO and
						   --b.DURUM_KODU='A' and
                	   	   BALANCE_DATE= DATE_REPORT and
                	   	   b.kredi_vade - b.acilis_tarihi > 367);
         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;

      IF P_col_no = 2 AND P_str_no = 6
      THEN
         BEGIN
            SELECT abs(SUM (sum_))
              INTO RESULT
              FROM (SELECT SUM (bakiye_lc) sum_
                      FROM cbs_dkhesap_gunluk_bakiye
                     WHERE to_date(to_char(gun, '99')||to_char(ay, '99')||to_char(yil, '9999'), 'ddmmyyyy') = DATE_REPORT and
        			 	   ((dvz_code = '0' and doviz_kod = doviz_kod) or
        				    (dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUR','RUB','TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                           SUBSTR(numara, 1, 4) IN ('2401', '2402', '2130', '2208')
                     UNION all
                    select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,nvl(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_
                      from cbs_rpt_vadeli_gunsonu_faiz b,
                	   	   cbs_hesap_gunluk_bakiye c
					 where substr(b.musteri_dk_no, 1, 4) in ('2215', '2223', '2123', '2219', '2206', '2207', '2124', '2127', '2131', '2133', '2213', '2217') and
        			 	   ((dvz_code = '0' and b.doviz_kodu = b.doviz_kodu) or
        				    (dvz_code = '1' and b.doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and b.doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and b.doviz_kodu in ('RUR','RUB','TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        					(dvz_code = '4' and b.doviz_kodu in ('SOM','KGS'))) and
                	   	   b.HESAP_NO = c.HESAP_NO and
						   --b.DURUM_KODU='A' and
						   b.BANKA_TARIHI = DATE_REPORT AND
                	   	   BALANCE_DATE= DATE_REPORT and
                	   	   b.vade_tarihi - b.acilis_tarihi > 367);
         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;


      IF P_col_no = 4 AND P_str_no in (2,3,4,5,6)
      THEN
         BEGIN
            SELECT SUM(sum_)
              INTO RESULT
              FROM (
			        SELECT abs(SUM(bakiye_lc)) sum_
                      FROM cbs_dkhesap_gunluk_bakiye
                     WHERE to_date(to_char(gun,'99')||to_char(ay,'99')||to_char(yil,'9999'), 'ddmmyyyy') = DATE_REPORT and
        			 	   ((dvz_code = '0' and doviz_kod = doviz_kod) or
        				    (dvz_code = '1' and doviz_kod in ('KZT')) or
        				    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and doviz_kod in ('RUR', 'RUB', 'TRL','TRY')) or
							(dvz_code = '5' and doviz_kod in ('USD')) or
							(dvz_code = '6' and doviz_kod in ('EUR')) or
							(dvz_code = '7' and doviz_kod in ('GBP')) or
							(dvz_code = '8' and doviz_kod in ('CHF')) or
							(dvz_code = '9'  and doviz_kod in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kod in ('TRL', 'TRY')) or
        					(dvz_code = '4' and doviz_kod in ('SOM','KGS'))) and
                            ((to_number(SUBSTR(numara, 1, 4)) between 6600 and 6998) or
						     SUBSTR(numara, 1, 4)='6020') and
							 P_str_no = 2
                     UNION all
                    select abs(sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,nvl(c.BAKIYE, 0),1,NULL,NULL,'N','A'))) sum_
                  	  from cbs_hesap_kredi b,
                	   	   cbs_hesap_gunluk_bakiye c
                     where (substr(b.musteri_dk_no, 1, 4) not in ('6020') and
					 	    to_number(substr(b.musteri_dk_no, 1, 4)) between 6000 and 6100) and
        			 	   ((dvz_code = '0' and b.doviz_kodu = b.doviz_kodu) or
        				    (dvz_code = '1' and b.doviz_kodu in ('KZT')) or
        				    (dvz_code = '2' and b.doviz_kodu in ('USD','EUR','GBP','CHF')) or
        					(dvz_code = '3' and b.doviz_kodu in ('RUR', 'RUB', 'TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
        					(dvz_code = '4' and b.doviz_kodu in ('SOM', 'KGS'))) and
                	   	   b.HESAP_NO = c.HESAP_NO and
                	   	   BALANCE_DATE= DATE_REPORT and
						  ((P_str_no=2 and b.kredi_vade - b.acilis_tarihi < 33) or
						   (P_str_no=3 and b.kredi_vade - b.acilis_tarihi > 32  and b.kredi_vade - b.acilis_tarihi < 93) or
						   (P_str_no=4 and b.kredi_vade - b.acilis_tarihi > 92  and b.kredi_vade - b.acilis_tarihi < 183) or
						   (P_str_no=5 and ((b.kredi_vade - b.acilis_tarihi > 182 and b.kredi_vade - b.acilis_tarihi < 368) or (b.kredi_vade is null))) or
						   (P_str_no=6 and b.kredi_vade - b.acilis_tarihi > 367))
				     union	 all
                   select abs(nvl(sum(TOTAL), 0))
                     from (select DOVIZ_KODU,
                           	   	  KEFALET_VADE_TARIHI,
                           	   	  GIRIS_TARIHI,
                           	   	  pkg_kur.doviz_doviz_karsilik(DOVIZ_KODU, pkg_genel.lc_al, DATE_REPORT, pkg_teminat.SF_DIGER_GAYRINAKDI_TUTAR_AL(musteri_no,teminat_sira_no), 1, null, null, 'N', 'A') TOTAL
                             from cbs.CBS_KREDI_TEMINAT_TANIM_RAP
                            where ANA_TEMINAT_KODU='03' and tarih=date_report
                            union all
                           SELECT DOVIZ_KODU,
                           	   	  VADE_TARIHI,
                           	   	  DUZENLEME_TARIHI,
                           	   	  pkg_kur.doviz_doviz_karsilik(DOVIZ_KODU, pkg_genel.lc_al, DATE_REPORT, TUTAR, 1, null, null, 'N', 'A')
                             FROM cbs.CBS_TM_ALINAN_GARANTI_RAP
                            where DURUM_KODU<>'IP' and tarih = date_report)
					where
        			 	 ((dvz_code = '0' and doviz_kodu = doviz_kodu) or
						  (dvz_code = '1' and doviz_kodu in ('KZT')) or
        				  (dvz_code = '2' and doviz_kodu in ('USD','EUR','GBP','CHF')) or
        				  (dvz_code = '3' and doviz_kodu in ('RUB', 'RUR', 'TRL','TRY')) or
							(dvz_code = '5' and doviz_kodu in ('USD')) or
							(dvz_code = '6' and doviz_kodu in ('EUR')) or
							(dvz_code = '7' and doviz_kodu in ('GBP')) or
							(dvz_code = '8' and doviz_kodu in ('CHF')) or
							(dvz_code = '9'  and doviz_kodu in ('RUB', 'RUR')) or
							(dvz_code = '10' and doviz_kodu in ('TRL', 'TRY')) or
        				  (dvz_code = '4' and doviz_kodu in ('SOM', 'KGS'))) and
						 ((P_str_no=2 and KEFALET_VADE_TARIHI - GIRIS_TARIHI < 33) or
						  (P_str_no=3 and KEFALET_VADE_TARIHI - GIRIS_TARIHI > 32 and KEFALET_VADE_TARIHI - GIRIS_TARIHI < 93) or
						  (P_str_no=4 and KEFALET_VADE_TARIHI - GIRIS_TARIHI > 92 and KEFALET_VADE_TARIHI - GIRIS_TARIHI < 183) or
						  (P_str_no=5 and ((KEFALET_VADE_TARIHI - GIRIS_TARIHI > 182 and KEFALET_VADE_TARIHI - GIRIS_TARIHI < 368) or (KEFALET_VADE_TARIHI IS NULL))) or
						  (P_str_no=5 and   KEFALET_VADE_TARIHI - GIRIS_TARIHI > 182 and KEFALET_VADE_TARIHI - GIRIS_TARIHI < 368                                  ) or
			              (P_str_no=6 and KEFALET_VADE_TARIHI - GIRIS_TARIHI > 367))
						   );
         EXCEPTION
            WHEN OTHERS THEN
               RESULT := 0;
         END;
      END IF;

	  end if;

      RETURN NVL (RESULT, 0);
   END cbs_rapor_srv_data;
BEGIN
   NULL;
END pkg_report1;
/

