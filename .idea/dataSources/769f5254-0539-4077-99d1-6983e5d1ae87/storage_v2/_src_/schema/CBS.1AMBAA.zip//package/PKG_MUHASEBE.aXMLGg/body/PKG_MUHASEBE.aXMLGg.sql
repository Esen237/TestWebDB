create PACKAGE BODY     pkg_muhasebe is
    g_uc_delimiter    constant varchar2(3) := pkg_hata.getucpointer;
    g_ara_delimiter   constant varchar2(3) := pkg_hata.getdelimiter;
    -- Ver. 2.3.0.0.1
    function banka_tarihi_bul
        return date is
        /*mutluo
            pdeger DATE;
            BEGIN
            Pkg_Parametre.DEGER ( 'SISTEM', 'FONKSIYON','GENEL','BANKA_TARIHI',PDEGER );
            RETURN pdeger;
        */
        ld_tarih   date;
    begin
        select banka_tarihi into ld_tarih from cbs_system;
        return ld_tarih;
    exception
        when others then
            raise_application_error(-20100, pkg_hata.getucpointer || '1030' || pkg_hata.getdelimiter || sqlerrm || pkg_hata.getucpointer);
    end;
    function onceki_banka_tarihi_bul
        return date is
        /* mutluo
            pdeger DATE;
            BEGIN
            Pkg_Parametre.DEGER ( 'SISTEM', 'FONKSIYON','GENEL','ONCEKI_BANKA_TARIHI',PDEGER );
            RETURN pdeger;
        */
        ld_tarih   date;
    begin
        select onceki_banka_tarihi into ld_tarih from cbs_system;
        return ld_tarih;
    exception
        when others then
            raise_application_error(-20100, pkg_hata.getucpointer || '1030' || pkg_hata.getdelimiter || sqlerrm || pkg_hata.getucpointer);
    end;
    function sonraki_banka_tarihi_bul
        return date is
        /*    pdeger DATE;
            BEGIN
            Pkg_Parametre.DEGER ( 'SISTEM', 'FONKSIYON','GENEL','SONRAKI_BANKA_TARIHI',PDEGER );
            RETURN pdeger;
        */
        ld_tarih   date;
    begin
        select sonraki_banka_tarihi into ld_tarih from cbs_system;
        return ld_tarih;
    exception
        when others then
            raise_application_error(-20100, pkg_hata.getucpointer || '1030' || pkg_hata.getdelimiter || sqlerrm || pkg_hata.getucpointer);
    end;
    function parametre_index_bul(p_kod varchar2)
        return number is
        p_numara   number;
    begin
        select numara
        into p_numara
        from cbs_parametre
        where kod = upper(trim(p_kod));
        return p_numara;
    exception
        when no_data_found then
            raise_application_error(-20100, g_uc_delimiter || '2246' || g_ara_delimiter || p_kod || g_uc_delimiter);
        when others then
            raise_application_error(-20100, g_uc_delimiter || '2247' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    function fis_no_bul(pn_fis_numara number)
        return number is
        ln_fis_no   number;
    begin
        select fis_no
        into ln_fis_no
        from cbs_fis
        where numara = pn_fis_numara;
        return ln_fis_no;
    end;
    function fis_numara_getir
        return number is
        p_fis_no   number;
    begin
        select sq_fis.nextval into p_fis_no from dual;
        return p_fis_no;
    exception
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1043' || g_uc_delimiter);
    end;
    function fis_no_getir(p_bolum_kodu varchar2, p_kullanici_kodu varchar2, p_tarih date, p_flag_sube_bazinda boolean default true)
        return number is
        p_max_fis_no   number;
    begin
        -- TDL-- Onemli
        -- Sevil Hanim'dan gelecek yanita gore code table veya unique sequence kullanilabilir.
        -- Yanit bekleniyor
        /*    if p_flag_sube_bazinda then
            select max(fis_no)
              into p_max_fis_no
              from cbs_fis,cbs_islem
             where cbs_fis.islem_numara=cbs_islem.numara
             and cbs_islem.kayit_kullanici_bolum_kodu=p_bolum_kodu
             and to_char(cbs_fis.muhasebelestigi_tarih,'DDMMYYYY')=to_char(p_tarih,'DDMMYYYY');

        else*/
        select max(fis_no)
        into p_max_fis_no
        from cbs_fis
        where muhasebelestigi_tarih = pkg_muhasebe.banka_tarihi_bul;
        --mutluo index kullanilmasi saglandi.....
        --         WHERE To_Char(muhasebelestigi_tarih,'DDMMYYYY')=To_Char(Pkg_Muhasebe.BANKA_TARIHI_BUL,'DDMMYYYY');
        --           and yaratan_kullanici_kodu = p_kullanici_kodu ;
        --    end if;
        p_max_fis_no   := nvl(p_max_fis_no, 0) + 1;
        return p_max_fis_no;
    exception
        when others then
            return -1;
    end;
    function get_global_boolean_value(p_par_no number, p_sira_no number, p_deger varchar2)
        return boolean is
        pp_deger   varchar2(2000);
    begin
        pp_deger   := upper(ltrim(rtrim(p_deger)));
        if (pp_deger in ('T', '1', 'D')) then
            return true;
        end if;
        return false;
    end;
    function get_global_varchar_value(p_par_no number, p_sira_no number, p_deger varchar2)
        return varchar2 is
        pp_deger   varchar2(2000);
        p_length   number;
    begin
        -- trim the "s
        pp_deger   := upper(ltrim(rtrim(p_deger)));
        p_length   := length(pp_deger);
        pp_deger   := substr(pp_deger, 2, p_length - 2);
        return pp_deger;
    end;
    function get_global_rate_value(p_par_no number, p_sira_no number, p_deger varchar2, pdoviz_kod varchar2)
        return number is
        numara_deger   cbs_satir.kur%type;
        p_kod          cbs_parametre.kod%type;
    begin
        begin
            select kod
            into p_kod
            from cbs_parametre
            where numara = p_par_no;
        exception
            when others then
                p_kod   := 'XX';
        end;
        if p_kod in ('G_FIXING') then
            numara_deger   :=
                pkg_kur.doviz_doviz_karsilik(pdoviz_kod, pkg_genel.lc_al, null, 1, null,
                                             null, null, 'O', null);
        else
            numara_deger   := to_number(p_deger, '99999999999999999999999999999999999.9999999');
        end if;
        return numara_deger;
    end;
    function get_global_number_value(p_par_no number, p_sira_no number, p_deger varchar2)
        return number is
        numara_deger   number(35, 3);
    begin
        numara_deger   := to_number(p_deger, '99999999999999999999999999999999999.9999999');
        return numara_deger;
    end;
    function get_global_date_value(p_par_no number, p_sira_no number, p_deger varchar2)
        return date is
        date_deger   date;
    begin
        if p_deger in ('TODAY', 'BUGUN') then
            date_deger   := banka_tarihi_bul;
        end if;
        if p_deger in ('YESTERDAY', 'DUN') then
            date_deger   := onceki_banka_tarihi_bul;
        end if;
        if p_deger in ('TOMORROW', 'YARIN') then
            date_deger   := sonraki_banka_tarihi_bul;
        end if;
        return date_deger;
    end;
    function get_local_date_value(p_deger varchar2)
        return date is
    begin
        return get_global_date_value(1, 1, p_deger);
    end;
    function get_local_number_value(p_deger varchar2)
        return number is
    begin
        return get_global_number_value(1, 1, p_deger);
    end;
    function get_local_boolean_value(p_deger varchar2)
        return boolean is
    begin
        return get_global_boolean_value(1, 1, p_deger);
    end;
    function fis_kes(p_islem_tanim_kod number, pmuhasebe_no in number default null, pislem_no in number, varchar_list in out varchar_array, number_list in out number_array,
                     date_list in out date_array, boolean_list in out boolean_array, p_gecerli_oldugu_tarih date default null, balans_kontrol boolean default true, p_fis_numara in number default 0,
                     p_aciklama in varchar2 default null, p_iptal_edilebilir in varchar2 default 'E')
        return number is
        p_fis_no                   number;                                                                                                                                             -- Fis no tutar
        p_fis_no2                  number;                                                                                                                                      -- Gecici Fis no tutar
        p_satir_no                 number;                                                                                                                                           -- Satir no tutar
        par_no                     number;                                                                                                               -- parametre numaralarini gecici olarak tutar
        p_kosul                    boolean;                                                                                                                                      -- Satir yazilacak mi
        p_sonuc                    boolean;                                                                                                                              -- Tx Parametre gecirilmis mi
        p_cond_flag                boolean;                                                                                                           -- Dogru muhasebe planini bulmak icin kullanildi
        p_dk_kod                   cbs_dkhesap.dk_kod%type;
        p_fis_tur                  cbs_fis.tur%type;
        p2_islem_tanim_kod         number;
        p2_muhasebe_no             number;
        p_sablon_islem_tanim_kod   number;
        p_sablon_numara            number;
        p_gecici_islem_tanim_kod   number;
        p_gecerli_oldugu_tarih_p   number;
        p_gecici_numara            number;
        p_banka_tarihi             date;
        p_onceki_banka_tarihi      date;
        p_sonraki_banka_tarihi     date;
        p2_gecerli_oldugu_tarih    date;
        --        p_eod                                         CBS_SYSTEM.eod%TYPE;
        pp_aciklama                varchar2(2000);                                                                                                          -- Fis aciklamasinin gecici degerini tutar
        p_temp_boolean             boolean;                                                                                                     -- Calculated Parametre'lerin gecici degerlerini tutar
        p_temp_varchar             varchar2(2000);                                                                                              -- Calculated Parametre'lerin gecici degerlerini tutar
        p_temp2_varchar            varchar2(2000);                                                                                              -- Calculated Parametre'lerin gecici degerlerini tutar
        p_temp_number              number;                                                                                                      -- Calculated Parametre'lerin gecici degerlerini tutar
        p_temp_date                date;                                                                                                        -- Calculated Parametre'lerin gecici degerlerini tutar
        vs_num_format              varchar2(50) := 'FM000000000000000000000000000000000000.000';
        p_borc_bakiye              cbs_dkhesap.borc_bakiye%type;
        p_alacak_bakiye            cbs_dkhesap.alacak_bakiye%type;
        p_fark                     number := 0;
        cursor c0 is
            select numara, tip, deger, p_code, p_oper1,
                   p_oper2, p_oper3, p_char_val1, p_char_val2, p_char_val3,
                   p_oper_type
            from cbs_parametre
            where islem_tanim_kod = p_islem_tanim_kod and tur = 'T'
            order by sira;
        r_c0                       c0%rowtype;
        cursor c1 is
            select *
            from cbs_muhasebe_bacak
            where islem_tanim_kod = p2_islem_tanim_kod and muhasebe_plan_numara = p2_muhasebe_no;
        r_c1                       c1%rowtype;
        cursor c2 is
            select tur, tip, sira, deger, numara,
                   format
            from cbs_parametre
            where numara = par_no;
        r_c2                       c2%rowtype;
        cursor c3 is
            select sablon_islem_tanim_kod, sablon_numara
            from cbs_alt_muhasebe_plan
            where muhasebe_islem_tanim_kod = p_islem_tanim_kod and muhasebe_plan_numara = p2_muhasebe_no;
        cursor c4 is
            select numara, tip, deger, p_code, p_oper1,
                   p_oper2, p_oper3, p_char_val1, p_char_val2, p_char_val3,
                   p_oper_type
            from cbs_parametre
            where islem_tanim_kod = p_sablon_islem_tanim_kod and tur = 'T'
            order by sira;
        r_c4                       c4%rowtype;
        r_satir                    cbs_satir%rowtype;
        cursor c5 is
            select *
            from cbs_muhasebe_plan
            where islem_tanim_kod = p_islem_tanim_kod and sablon = 'H';
        r_c5                       c5%rowtype;
        cursor c6 is
            select *
            from cbs_muhasebe_plan_kosul
            where islem_tanim_kod = p_islem_tanim_kod and muhasebe_plan_numara = r_c5.numara;
        r_c6                       c6%rowtype;
        cursor c7 is
            select *
            from cbs_muhasebe_plan_kosul
            where islem_tanim_kod = p_sablon_islem_tanim_kod and muhasebe_plan_numara = p_sablon_numara;
        r_c7                       c7%rowtype;
        cursor c9 is
            select gecici_islem_tanim_kod, gecici_plan_numara, gecerli_oldugu_tarih_par_no
            from cbs_gecici_muhasebe_plan
            where muhasebe_islem_tanim_kod = p_islem_tanim_kod and muhasebe_plan_numara = pmuhasebe_no;
        r_c9                       c9%rowtype;
        -- begin : cursors for automatic brach finding  --
        cursor c10 is
            select kayit_kullanici_bolum_kodu
            from cbs_islem
            where numara = pislem_no;
        vs_bolum_kodu              cbs_bolum.kodu%type;
        vs_bolum_kodu2             cbs_bolum.kodu%type;
        vs_islem_yarat_bolum       cbs_bolum.kodu%type;
        vb_rate_global             boolean := false;                                                                                      -- defined as global : true, defined in TX : false --
        errcode                    number;
        dbmserrcode                number;
        dbmserrtext                varchar2(200);
        bacak_adedi                number;
        ln_hesap_hareket_kod       number;
        ls_force_debit             varchar2(1);
    begin
        -- Fis No Al
        if p_fis_numara = 0 then
            p_fis_no   := fis_numara_getir;
        else
            p_fis_no   := p_fis_numara;                                                                                                                           -- Fis already exist, add new lines.
        end if;
        -- Fis Yarat
        p_banka_tarihi           := banka_tarihi_bul;
        p_onceki_banka_tarihi    := onceki_banka_tarihi_bul;
        p_sonraki_banka_tarihi   := sonraki_banka_tarihi_bul;
        /*
           BEGIN

              SELECT eod
                INTO p_eod
                FROM CBS_SYSTEM;
           EXCEPTION
             WHEN OTHERS THEN
              RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '1044' ||g_ara_delimiter||SQLERRM||g_uc_delimiter);
           END;

          -- EOD control

          IF p_eod='E' THEN
              IF p_gecerli_oldugu_tarih IS NOT NULL THEN
                   p2_gecerli_oldugu_tarih:=p_gecerli_oldugu_tarih;
              ELSE
            --       p2_gecerli_oldugu_tarih:=p_sonraki_banka_tarihi;
            -- 7*24 sisteme gecildiginde yukaridaki satir gecerli hale getirilmeli 03-11-2003 : Erguna
                   p2_gecerli_oldugu_tarih:=p_banka_tarihi;
              END IF;
          ELSE
        */
        if p_gecerli_oldugu_tarih is not null then
            p2_gecerli_oldugu_tarih   := p_gecerli_oldugu_tarih;
        else
            p2_gecerli_oldugu_tarih   := p_banka_tarihi;
        end if;
        --  END IF;
        if trunc(nvl(p_gecerli_oldugu_tarih, p_banka_tarihi)) > trunc(p_banka_tarihi) then
            p_fis_tur   := 'T';                                                                                                                                                           -- Temporary
        else
            p_fis_tur   := 'G';
        end if;
        -- tx parametreleri gecirilmis mi
        begin
            open c0;
            loop
                fetch c0 into r_c0;
                exit when c0%notfound;
                if r_c0.tip = 'V' then                                                                                                                                                      -- Varchar
                    p_sonuc   := varchar_list.exists(r_c0.numara);
                    if p_sonuc = false then
                        if r_c0.p_code = 0 then                                                                                                                                         -- No Operator
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    varchar_list(r_c0.numara)   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    varchar_list(r_c0.numara)   := varchar_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                varchar_list(r_c0.numara)   := r_c0.p_char_val1;
                            end if;
                        elsif r_c0.p_code = 1 then                                                                                                                                        -- + Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    varchar_list(r_c0.numara)   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    varchar_list(r_c0.numara)   := varchar_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                varchar_list(r_c0.numara)   := r_c0.p_char_val1;
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    varchar_list(r_c0.numara)   := varchar_list(r_c0.numara) || get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    varchar_list(r_c0.numara)   := varchar_list(r_c0.numara) || varchar_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                varchar_list(r_c0.numara)   := varchar_list(r_c0.numara) || r_c0.p_char_val2;
                            end if;
                        else                                                                                                                                                              --  Operator
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    p_temp_boolean   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    p_temp_boolean   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_boolean   := get_global_boolean_value(1, 1, r_c0.p_char_val1);
                            end if;
                            if p_temp_boolean then                                                                                                                      -- get second parameter values
                                -- second parameter
                                if r_c0.p_oper2 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper2;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        varchar_list(r_c0.numara)   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        varchar_list(r_c0.numara)   := varchar_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    varchar_list(r_c0.numara)   := r_c0.p_char_val2;
                                end if;
                            else
                                -- third parameter
                                if r_c0.p_oper3 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper3;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        varchar_list(r_c0.numara)   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        varchar_list(r_c0.numara)   := varchar_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    varchar_list(r_c0.numara)   := r_c0.p_char_val3;
                                end if;
                            end if;
                        end if;
                        p_sonuc   := true;
                    end if;
                elsif r_c0.tip = 'N' then                                                                                                                                                    -- Number
                    p_sonuc   := number_list.exists(r_c0.numara);
                    if p_sonuc = false then
                        if r_c0.p_code = 6 then                                                                                                                                         -- No Operator
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val1);
                            end if;
                        elsif r_c0.p_code = 1 then                                                                                                                                       -- + Operator
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) + get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) + number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := number_list(r_c0.numara) + get_local_number_value(r_c0.p_char_val2);
                            end if;
                        elsif r_c0.p_code = 2 then                                                                                                                                        -- - Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) - get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) - number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := number_list(r_c0.numara) - get_local_number_value(r_c0.p_char_val2);
                            end if;
                        elsif r_c0.p_code = 3 then                                                                                                                                        -- * Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) * get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) * number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := number_list(r_c0.numara) * get_local_number_value(r_c0.p_char_val2);
                            end if;
                        elsif r_c0.p_code = 4 then                                                                                                                                        -- / Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) / get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    number_list(r_c0.numara)   := number_list(r_c0.numara) / number_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                number_list(r_c0.numara)   := number_list(r_c0.numara) / get_local_number_value(r_c0.p_char_val2);
                            end if;
                        else                                                                                                                                                               --  Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    p_temp_boolean   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    p_temp_boolean   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_boolean   := get_global_boolean_value(1, 1, r_c0.p_char_val1);
                            end if;
                            if p_temp_boolean then                                                                                                                      -- get second parameter values
                                -- second parameter
                                if r_c0.p_oper2 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper2;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        number_list(r_c0.numara)   := number_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val2);
                                end if;
                            else
                                -- third parameter
                                if r_c0.p_oper3 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper3;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        number_list(r_c0.numara)   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        number_list(r_c0.numara)   := number_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    number_list(r_c0.numara)   := get_local_number_value(r_c0.p_char_val3);
                                end if;
                            end if;
                        end if;
                        p_sonuc   := true;
                    end if;
                elsif r_c0.tip = 'D' then                                                                                                                                                      -- Date
                    p_sonuc   := date_list.exists(r_c0.numara);
                    if p_sonuc = false then
                        if r_c0.p_code = 1 then                                                                                                                                         -- No Operator
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    date_list(r_c0.numara)   := get_global_date_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    date_list(r_c0.numara)   := date_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                date_list(r_c0.numara)   := get_local_date_value(r_c0.p_char_val1);
                            end if;
                        else                                                                                                                                                               --  Operand
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    p_temp_boolean   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    p_temp_boolean   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_boolean   := get_global_boolean_value(1, 1, r_c0.p_char_val1);
                            end if;
                            if p_temp_boolean then                                                                                                                      -- get second parameter values
                                -- second parameter
                                if r_c0.p_oper2 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper2;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        date_list(r_c0.numara)   := get_global_date_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        date_list(r_c0.numara)   := date_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    date_list(r_c0.numara)   := get_local_date_value(r_c0.p_char_val2);
                                end if;
                            else
                                -- third parameter
                                if r_c0.p_oper3 is not null then                                                                                                               -- Referenced parameter
                                    par_no   := r_c0.p_oper3;
                                    open c2;
                                    fetch c2 into r_c2;
                                    close c2;
                                    if r_c2.tur = 'G' then
                                        date_list(r_c0.numara)   := get_global_date_value(par_no, r_c2.sira, r_c2.deger);
                                    elsif r_c2.tur = 'T' then
                                        date_list(r_c0.numara)   := date_list(par_no);
                                    end if;
                                else                                                                                                                                                       -- Constant
                                    date_list(r_c0.numara)   := get_local_date_value(r_c0.p_char_val3);
                                end if;
                            end if;
                        end if;
                        p_sonuc   := true;
                    end if;
                elsif r_c0.tip = 'B' then                                                                                                                                                   -- Boolean
                    p_sonuc   := boolean_list.exists(r_c0.numara);
                    if p_sonuc = false then
                        if r_c0.p_code = 0 then                                                                                                                                         -- No Operator
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    boolean_list(r_c0.numara)   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    boolean_list(r_c0.numara)   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                boolean_list(r_c0.numara)   := get_local_boolean_value(r_c0.p_char_val1);
                            end if;
                        elsif r_c0.p_code = 6 then                                                                                                                                                -- |
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    boolean_list(r_c0.numara)   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    boolean_list(r_c0.numara)   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                boolean_list(r_c0.numara)   := get_local_boolean_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) or get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) or boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) or get_local_boolean_value(r_c0.p_char_val2);
                            end if;
                        elsif r_c0.p_code = 5 then                                                                                                                                                -- &
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    boolean_list(r_c0.numara)   := get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    boolean_list(r_c0.numara)   := boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                boolean_list(r_c0.numara)   := get_local_boolean_value(r_c0.p_char_val1);
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) and get_global_boolean_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) and boolean_list(par_no);
                                end if;
                            else                                                                                                                                                           -- Constant
                                boolean_list(r_c0.numara)   := boolean_list(r_c0.numara) and get_local_boolean_value(r_c0.p_char_val2);
                            end if;
                        elsif r_c0.p_code = 4 then                                                                                                                                                -- =
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_varchar   := r_c0.p_char_val1;
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp2_varchar   := r_c0.p_char_val2;
                            end if;
                            if p_temp_varchar = p_temp2_varchar then
                                boolean_list(r_c0.numara)   := true;
                            else
                                boolean_list(r_c0.numara)   := false;
                            end if;
                        elsif r_c0.p_code = 3 then                                                                                                                                               -- !=
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_varchar   := r_c0.p_char_val1;
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp2_varchar   := r_c0.p_char_val2;
                            end if;
                            if p_temp_varchar != p_temp2_varchar then
                                boolean_list(r_c0.numara)   := true;
                            else
                                boolean_list(r_c0.numara)   := false;
                            end if;
                        elsif r_c0.p_code = 2 then                                                                                                                                                -- >
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_varchar   := r_c0.p_char_val1;
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp2_varchar   := r_c0.p_char_val2;
                            end if;
                            if p_temp_varchar > p_temp2_varchar then
                                boolean_list(r_c0.numara)   := true;
                            else
                                boolean_list(r_c0.numara)   := false;
                            end if;
                        elsif r_c0.p_code = 1 then                                                                                                                                                -- <
                            -- first parameter
                            if r_c0.p_oper1 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper1;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp_varchar   := r_c0.p_char_val1;
                            end if;
                            -- second parameter
                            if r_c0.p_oper2 is not null then                                                                                                                   -- Referenced parameter
                                par_no   := r_c0.p_oper2;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(get_global_date_value(par_no, r_c2.sira, r_c2.deger), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(get_global_number_value(par_no, r_c2.sira, r_c2.deger), nvl(r_c2.format, vs_num_format));
                                    end if;
                                elsif r_c2.tur = 'T' then
                                    if r_c0.p_oper_type = 1 then                                                                                                                               -- Date
                                        p_temp2_varchar   := to_char(date_list(par_no), 'YYYYMMDD');
                                    elsif r_c0.p_oper_type = 2 then                                                                                                                         -- varchar
                                        p_temp2_varchar   := varchar_list(par_no);
                                    else                                                                                                                                                     -- number
                                        p_temp2_varchar   := to_char(number_list(par_no), nvl(r_c2.format, vs_num_format));
                                    end if;
                                end if;
                            else                                                                                                                                                           -- Constant
                                p_temp2_varchar   := r_c0.p_char_val2;
                            end if;
                            if p_temp_varchar < p_temp2_varchar then
                                boolean_list(r_c0.numara)   := true;
                            else
                                boolean_list(r_c0.numara)   := false;
                            end if;
                        end if;
                        p_sonuc   := true;
                    end if;
                end if;
                if p_sonuc = false then
                    raise_application_error(-20100, g_uc_delimiter || '1049' || g_uc_delimiter);
                end if;
            end loop;
            close c0;
        exception
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1050' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
        end;
        -- Eger muhasebe_plan_no gecirilmemis ise dogru plani bul
        if pmuhasebe_no is null then
            begin
                open c5;
                loop
                    fetch c5 into r_c5;
                    exit when c5%notfound;
                    p_cond_flag   := true;
                    open c6;
                    loop
                        fetch c6 into r_c6;
                        exit when c6%notfound;
                        p_sonuc   := boolean_list.exists(r_c6.parametre_numara);
                        if p_sonuc = true then
                            if boolean_list(r_c6.parametre_numara) = false then
                                p_cond_flag   := false;
                                exit;
                            end if;
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1051' || g_uc_delimiter);
                        end if;
                    end loop;
                    close c6;
                    if p_cond_flag = true then
                        p2_muhasebe_no   := r_c5.numara;                                                                                                              --MODIFIED BY MEHMET FROM 4 TO 5
                        pp_aciklama      := r_c5.aciklama;
                        ls_force_debit   := r_c5.force_debit;
                        exit;
                    end if;
                end loop;
                close c5;
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1052' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
            if p_cond_flag = false then
                raise_application_error(-20100, g_uc_delimiter || '1053' || g_uc_delimiter);
            end if;
        else
            p2_muhasebe_no   := pmuhasebe_no;
            begin
                select force_debit
                into ls_force_debit
                from cbs_muhasebe_plan
                where islem_tanim_kod = p_islem_tanim_kod and numara = pmuhasebe_no;
            exception
                when others then
                    raise_application_error(-20100,
                                            g_uc_delimiter || '1199' || g_ara_delimiter || p_islem_tanim_kod || g_ara_delimiter || pmuhasebe_no || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
        end if;
        --
        -- Fill explanation
        if (p_aciklama is null or p_aciklama = '') then
            if (pp_aciklama is null or pp_aciklama = '') then
                begin
                    select aciklama
                    into pp_aciklama
                    from cbs_muhasebe_plan
                    where islem_tanim_kod = p_islem_tanim_kod and numara = pmuhasebe_no;
                exception
                    when others then
                        begin
                            select aciklama
                            into pp_aciklama
                            from cbs_islem_tanim
                            where kod = p_islem_tanim_kod;
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1045' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                end;
            end if;
        else
            pp_aciklama   := p_aciklama;
        end if;
        if p_fis_numara = 0 then
            begin
                insert into cbs_fis(numara, aciklama, islem_numara, yaratan_kullanici_kodu, yaratildigi_tarih,
                                    gecerli_oldugu_tarih, yaratildigi_banka_tarih, tur, iptal_edilebilir, force_debit)
                values (p_fis_no, pp_aciklama, pislem_no, user, sysdate,
                        p2_gecerli_oldugu_tarih, p_banka_tarihi, p_fis_tur, p_iptal_edilebilir, ls_force_debit);
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1046' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
            begin
                update cbs_islem
                set fis_numara   = p_fis_no
                where numara = pislem_no;
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1047' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
            p_satir_no   := 1;
        else
            begin
                select count(*)
                into p_satir_no
                from cbs_satir, cbs_fis
                where fis_numara = p_fis_no and cbs_fis.numara = fis_numara and muhasebelestigi_tarih is null;
                p_satir_no   := p_satir_no + 1;
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1048' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
        end if;
        --
        -- Her bir muhasebe bacagi icin
        r_satir.fis_numara       := p_fis_no;
        p2_islem_tanim_kod       := p_islem_tanim_kod;
        begin
            open c1;
            loop
                fetch c1 into r_c1;
                exit when c1%notfound;
                r_satir.numara                 := p_satir_no;
                -- DV Tutar Parametresi
                begin
                    par_no   := r_c1.param_dv_tutar;
                    open c2;
                    fetch c2 into r_c2;
                    close c2;
                    if r_c2.tur = 'G' then
                        r_satir.dv_tutar   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                    elsif r_c2.tur = 'T' then
                        r_satir.dv_tutar   := number_list(par_no);
                    else
                        raise_application_error(-20100, g_uc_delimiter || '1054' || g_uc_delimiter);
                    end if;
                exception
                    when others then
                        raise_application_error(-20100, g_uc_delimiter || '1055' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                end;
                -- Doviz Kod Parametresi
                begin
                    par_no   := r_c1.param_doviz_kod;
                    open c2;
                    fetch c2 into r_c2;
                    close c2;
                    if r_c2.tur = 'G' then
                        r_satir.doviz_kod   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                    elsif r_c2.tur = 'T' then
                        r_satir.doviz_kod   := varchar_list(par_no);
                    else
                        raise_application_error(-20100, g_uc_delimiter || '1056' || g_uc_delimiter);
                    end if;
                exception
                    when others then
                        raise_application_error(-20100, g_uc_delimiter || '1057' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                end;
                -- Kur Parametresi
                begin
                    vb_rate_global   := false;
                    par_no           := r_c1.param_kur;
                    open c2;
                    fetch c2 into r_c2;
                    close c2;
                    if r_c2.tur = 'G' then
                        vb_rate_global   := true;
                        r_satir.kur      := get_global_rate_value(par_no, r_c2.sira, r_c2.deger, r_satir.doviz_kod);
                    elsif r_c2.tur = 'T' then
                        r_satir.kur   := number_list(par_no);
                    else
                        raise_application_error(-20100, g_uc_delimiter || '1058' || g_uc_delimiter);
                    end if;
                exception
                    when others then
                        raise_application_error(-20100, g_uc_delimiter || '1059' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                end;
                -- LC Tutar Parametresi
                if vb_rate_global then
                    r_satir.lc_tutar   := r_satir.dv_tutar * r_satir.kur;
                else
                    begin
                        par_no   := r_c1.param_lc_tutar;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.lc_tutar   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.lc_tutar   := number_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1060' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1062' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                end if;
                -- If lc amount = 0 then go on... otherwise process next record --
                if r_satir.lc_tutar <> 0 then
                    -- Tur Parametresi
                    begin
                        par_no   := r_c1.param_tur;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.tur   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.tur   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1063' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1064' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Hesap Tur Kodu Parametresi
                    begin
                        par_no   := r_c1.param_hesap_tur_kodu;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.hesap_tur_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.hesap_tur_kodu   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1065' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1066' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Hesap Numara Parametresi
                    begin
                        par_no   := r_c1.param_hesap_numara;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.hesap_numara   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.hesap_numara   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1067' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1068' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Hesap bolum kodu
                    begin
                        par_no   := r_c1.param_hesap_bolum_kodu;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.hesap_bolum_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.hesap_bolum_kodu   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1090' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1091' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Valor Tarihi Parametresi
                    begin
                        par_no   := r_c1.param_valor_tarihi;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.valor_tarihi   := get_global_date_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.valor_tarihi   := date_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1069' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1070' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Banka Aciklama Parametresi
                    begin
                        par_no   := r_c1.param_banka_aciklama;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.banka_aciklama   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.banka_aciklama   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1071' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1072' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Musteri Aciklama Parametresi
                    begin
                        par_no   := r_c1.param_musteri_aciklama;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.musteri_aciklama   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.musteri_aciklama   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1073' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1074' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Istatistik Kodu Parametresi
                    begin
                        par_no   := r_c1.param_istatistik_kodu;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.istatistik_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.istatistik_kodu   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1075' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1076' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Referans Parametresi
                    begin
                        par_no   := r_c1.param_referans;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.referans   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.referans   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1077' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1078' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Musteri Hesap Tur Parametresi
                    begin
                        par_no   := r_c1.param_musteri_hesap_tur;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.musteri_hesap_tur   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.musteri_hesap_tur   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1079' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1080' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Musteri Hesap Numara Parametresi
                    begin
                        par_no   := r_c1.param_musteri_hesap_numara;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.musteri_hesap_numara   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.musteri_hesap_numara   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1081' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1082' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    -- Nakit Kodu Parametresi
                    begin
                        par_no   := r_c1.param_nakit_kodu;
                        open c2;
                        fetch c2 into r_c2;
                        close c2;
                        if r_c2.tur = 'G' then
                            r_satir.nakit_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                        elsif r_c2.tur = 'T' then
                            r_satir.nakit_kodu   := varchar_list(par_no);
                        else
                            raise_application_error(-20100, g_uc_delimiter || '1083' || g_uc_delimiter);
                        end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1084' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;

                    -- B-O-M  seval.colak 01122021 gelir muhasebe degisiklikleri
                    -- gelir_musteri_no Parametresi
                    begin
                        par_no   :=  r_c1.param_gelir_musteri_no;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_musteri_no   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_musteri_no   := varchar_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_musteri_no' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_musteri_no' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_iliskili_dk_no Parametresi
                    begin
                        par_no   := r_c1.param_gelir_iliskili_dk_no;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_iliskili_dk_no   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_iliskili_dk_no   := varchar_list(par_no);
                            else
                                 raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_iliskili_dk_no' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_iliskili_dk_no' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_vergi_orani Parametresi
                    begin
                        par_no   := r_c1.param_gelir_vergi_orani;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_vergi_orani   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_vergi_orani   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_vergi_orani' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_vergi_orani' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_tutar_fc Parametresi
                    begin
                        par_no   := r_c1.param_gelir_tutar_fc;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_tutar_fc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_tutar_fc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_tutar_fc' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_tutar_fc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_doviz_kod Parametresi
                    begin
                        par_no   := r_c1.param_gelir_doviz_kod;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_doviz_kod   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_doviz_kod   := varchar_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_doviz_kod' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_doviz_kod' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- matrah_tutar_fc Parametresi
                    begin
                        par_no   := r_c1.param_matrah_tutar_fc;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.matrah_tutar_fc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.matrah_tutar_fc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_matrah_tutar_fc' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_matrah_tutar_fc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- matrah_tutar_lc Parametresi
                    begin
                        par_no   := r_c1.param_matrah_tutar_lc;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.matrah_tutar_lc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.matrah_tutar_lc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_matrah_tutar_lc' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_matrah_tutar_lc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                     -- E-O-M  seval.colak 01122021 gelir muhasebe degisiklikleri

                    if r_satir.tur = 'B' then
                        -- balans kontrolu yapmasin icin              p_borc_bakiye:=NVL(p_borc_bakiye,0)+NVL(r_satir.lc_tutar,0);
                        /*SA 3 MAYIS*/
                        p_borc_bakiye   := nvl(p_borc_bakiye, 0) + nvl(r_satir.lc_tutar, 0);
                    elsif r_satir.tur = 'A' then
                        p_alacak_bakiye   := nvl(p_alacak_bakiye, 0) + nvl(r_satir.lc_tutar, 0);
                    else
                        raise_application_error(-20100, g_uc_delimiter || '1085' || g_uc_delimiter);
                    end if;
                    if r_satir.lc_tutar < 0 or r_satir.dv_tutar < 0 then
                        raise_application_error(
                            -20100,
                            g_uc_delimiter || '1040' || g_ara_delimiter || nvl(pmuhasebe_no, 0) || g_ara_delimiter || nvl(p_satir_no, 0) || g_ara_delimiter || r_satir.hesap_numara || r_satir.
                            doviz_kod || g_uc_delimiter);
                    end if;
                    begin
                        insert into cbs_satir(fis_numara, numara, tur, hesap_bolum_kodu, hesap_tur_kodu,
                                              hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                                              banka_aciklama, musteri_aciklama, istatistik_kodu, referans, musteri_hesap_tur,
                                              musteri_hesap_numara, kur, nakit_kodu
                                              ,gelir_musteri_no,gelir_iliskili_dk_no,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc	)    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                         values (r_satir.fis_numara, p_satir_no, r_satir.tur, r_satir.hesap_bolum_kodu, r_satir.hesap_tur_kodu,
                                r_satir.hesap_numara, r_satir.valor_tarihi, r_satir.lc_tutar, r_satir.dv_tutar, r_satir.doviz_kod,
                                r_satir.banka_aciklama, r_satir.musteri_aciklama, r_satir.istatistik_kodu, r_satir.referans, r_satir.musteri_hesap_tur,
                                r_satir.musteri_hesap_numara, r_satir.kur, r_satir.nakit_kodu
                                ,r_satir.gelir_musteri_no, r_satir.gelir_iliskili_dk_no	,r_satir.gelir_vergi_orani,r_satir.gelir_tutar_fc,r_satir.gelir_doviz_kod,r_satir.matrah_tutar_fc,r_satir.matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                );
                        insert into cbs_muhasebe_plan_calisan(tx_no, fis_no, satir_no, islem_kod, muhasebe_plan_no,
                                                              muhasebe_bacak_no)
                        values (pislem_no, r_satir.fis_numara, p_satir_no, p2_islem_tanim_kod, p2_muhasebe_no,
                                r_c1.muhasebe_bacak_numara);
                    exception
                        when others then
                            raise_application_error(-20100,
                                                    g_uc_delimiter || '1086' || g_ara_delimiter || '(' || nvl(pmuhasebe_no, 0) || '-' || nvl(p_satir_no, 0) || '--' || r_c1.param_hesap_numara ||
                                                    ')' || sqlerrm || g_uc_delimiter);
                    end;
                    if r_satir.hesap_tur_kodu in ('VS', 'VD', 'KR') then
                        ---mutluo   hesap hareket kodu kontrolu
                        select nvl(hesap_hareket_kodu, 1)
                        into ln_hesap_hareket_kod
                        from cbs_vw_hesap_izleme
                        where hesap_no = r_satir.hesap_numara;
                        if r_satir.hesap_tur_kodu in ('VS', 'VD') then
                            if (ln_hesap_hareket_kod = 2 and r_satir.tur = 'B') then
                                raise_application_error(-20100, g_uc_delimiter || '1095' || g_ara_delimiter || '(' || r_satir.hesap_numara || ')' || g_uc_delimiter);
                            elsif (ln_hesap_hareket_kod = 3 and r_satir.tur = 'A') then
                                raise_application_error(-20100, g_uc_delimiter || '1094' || g_ara_delimiter || '(' || r_satir.hesap_numara || ')' || g_uc_delimiter);
                            end if;
                        end if;
                        p_satir_no   := p_satir_no + 1;
                        if r_satir.hesap_tur_kodu = 'VS' then
                            begin
                                select musteri_dk_no
                                into p_dk_kod
                                from cbs_hesap
                                where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                            exception
                                when no_data_found then
                                    raise_application_error(-20100, g_uc_delimiter || '1131' || g_ara_delimiter || to_char(r_satir.hesap_numara) || '-' || r_satir.doviz_kod || g_uc_delimiter);
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1132' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                        elsif r_satir.hesap_tur_kodu = 'VD' then                                                                                                                  -- Vadeli Hesap icin
                            begin
                                select musteri_dk_no
                                into p_dk_kod
                                from cbs_hesap_vadeli
                                where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                            exception
                                when no_data_found then
                                    raise_application_error(-20100, g_uc_delimiter || '1153' || g_ara_delimiter || to_char(r_satir.hesap_numara) || g_uc_delimiter);
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1154' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                        elsif r_satir.hesap_tur_kodu = 'KR' then                                                                                                                   -- Kredi Hesap icin
                            begin
                                select musteri_dk_no
                                into p_dk_kod
                                from cbs_hesap_kredi
                                where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                            exception
                                when no_data_found then
                                    raise_application_error(-20100, g_uc_delimiter || '3864' || g_ara_delimiter || to_char(r_satir.hesap_numara) || g_uc_delimiter);
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '3865' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                        end if;
                        begin
                            --mutluo
                            if r_satir.lc_tutar < 0 or r_satir.dv_tutar < 0 then
                                raise_application_error(-20100,
                                                        g_uc_delimiter || '1040' || g_ara_delimiter || nvl(pmuhasebe_no, 0) || g_ara_delimiter || nvl(p_satir_no, 0) || g_ara_delimiter || p_dk_kod
                                                        || r_satir.doviz_kod || g_uc_delimiter);
                            end if;
                            insert into cbs_satir(fis_numara, numara, tur, hesap_bolum_kodu, hesap_tur_kodu,
                                                  hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                                                  banka_aciklama, musteri_aciklama, istatistik_kodu, referans, musteri_hesap_tur,
                                                  musteri_hesap_numara, kur, nakit_kodu
                                                  ,gelir_musteri_no	,  gelir_iliskili_dk_no	,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                                  )
                            values (r_satir.fis_numara, p_satir_no, r_satir.tur, r_satir.hesap_bolum_kodu, 'DK',
                                    p_dk_kod, r_satir.valor_tarihi, r_satir.lc_tutar, r_satir.dv_tutar, r_satir.doviz_kod,
                                    r_satir.banka_aciklama, r_satir.musteri_aciklama, r_satir.istatistik_kodu, r_satir.referans, r_satir.hesap_tur_kodu,
                                    r_satir.hesap_numara, r_satir.kur, r_satir.nakit_kodu
                                    ,r_satir.gelir_musteri_no, r_satir.gelir_iliskili_dk_no	,r_satir.gelir_vergi_orani,r_satir.gelir_tutar_fc,r_satir.gelir_doviz_kod,r_satir.matrah_tutar_fc,r_satir.matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                    );
                             insert into cbs_muhasebe_plan_calisan(tx_no, fis_no, satir_no, islem_kod, muhasebe_plan_no,
                                                                  muhasebe_bacak_no)
                            values (pislem_no, r_satir.fis_numara, p_satir_no, p2_islem_tanim_kod, p2_muhasebe_no,
                                    r_c1.muhasebe_bacak_numara);
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1133' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                    end if;
                    p_satir_no   := p_satir_no + 1;
                end if;                                                                                                                                               -- if r_satir.LC_tutar <> 0 then
                r_satir.musteri_hesap_tur      := '';
                r_satir.musteri_hesap_numara   := '';
               
                --BOM CQ5717 MederT 13012017
                declare
                    ln_sinif_count   number;
                begin
                    select count(*)
                    into ln_sinif_count
                    from cbs_hesap
                    where hesap_no = r_satir.hesap_numara and urun_sinif_kod = 'ELCARD NON INT.BR-LC';
                    if (ln_sinif_count > 0) then
                           pkg_elcard.callelcardws(r_satir.tur, r_satir.lc_tutar, p_islem_tanim_kod, r_satir.hesap_numara, r_satir.fis_numara, r_satir.numara, pislem_no); --bahianab cbs-531 Elcard optimization
                    end if;
                end;
            
            --EOM CQ5717 MederT 13012017
            end loop;                                                                                                                                                                         -- satir
            close c1;
        exception
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1087' || g_ara_delimiter || sqlerrm ||'line:'||r_satir.numara||'-'|| 'acno:'|| to_char(r_satir.hesap_numara) || '-' || r_satir.doviz_kod || g_uc_delimiter);
        end;
        -- Sablon kullanilmis ise sablon bacaklarini dolas.
        open c3;
        loop
            fetch c3 into p_sablon_islem_tanim_kod, p_sablon_numara;
            exit when c3%notfound;
            -- Sablonda kosul varsa, tum kosullar saglaniyor mu
            begin
                p_cond_flag   := true;
                open c7;
                loop
                    fetch c7 into r_c7;
                    exit when c7%notfound;
                    p_sonuc   := boolean_list.exists(r_c7.parametre_numara);
                    if p_sonuc = true then
                        if boolean_list(r_c7.parametre_numara) = false then
                            p_cond_flag   := false;
                            exit;
                        end if;
                    else
                        raise_application_error(-20100, g_uc_delimiter || '1088' || g_uc_delimiter);
                    end if;
                end loop;
                close c7;
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1089' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
            if p_cond_flag = true then
                begin
                    p2_islem_tanim_kod   := p_sablon_islem_tanim_kod;
                    p2_muhasebe_no       := p_sablon_numara;
                    open c1;
                    loop
                        fetch c1 into r_c1;
                        exit when c1%notfound;
                        r_satir.numara   := p_satir_no;
                        -- DV Tutar Parametresi
                        begin
                            par_no   := r_c1.param_dv_tutar;
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.dv_tutar   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.dv_tutar   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '1054' || g_uc_delimiter);
                            end if;
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1055' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                        -- Doviz Kod Parametresi
                        begin
                            par_no   := r_c1.param_doviz_kod;
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.doviz_kod   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.doviz_kod   := varchar_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '1056' || g_uc_delimiter);
                            end if;
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1057' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                        -- Kur Parametresi
                        begin
                            vb_rate_global   := false;
                            par_no           := r_c1.param_kur;
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                vb_rate_global   := true;
                                r_satir.kur      := get_global_rate_value(par_no, r_c2.sira, r_c2.deger, r_satir.doviz_kod);
                            elsif r_c2.tur = 'T' then
                                r_satir.kur   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '1058' || g_uc_delimiter);
                            end if;
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1059' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                        -- LC Tutar Parametresi
                        begin
                            par_no   := r_c1.param_lc_tutar;
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.lc_tutar   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.lc_tutar   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '1060' || g_uc_delimiter);
                            end if;
                        exception
                            when others then
                                raise_application_error(-20100, g_uc_delimiter || '1062' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        end;
                        if r_satir.lc_tutar <> 0 then
                            -- Tur Parametresi
                            begin
                                par_no   := r_c1.param_tur;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.tur   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.tur   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1063' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1064' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Hesap Tur Kodu Parametresi
                            begin
                                par_no   := r_c1.param_hesap_tur_kodu;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.hesap_tur_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.hesap_tur_kodu   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1065' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1066' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Hesap Numara Parametresi
                            begin
                                par_no   := r_c1.param_hesap_numara;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.hesap_numara   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.hesap_numara   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1067' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1068' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Hesap Bolum Kodu Parametresi
                            begin
                                par_no   := r_c1.param_hesap_bolum_kodu;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.hesap_bolum_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.hesap_bolum_kodu   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1090' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1091' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Valor Tarihi Parametresi
                            begin
                                par_no   := r_c1.param_valor_tarihi;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.valor_tarihi   := get_global_date_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.valor_tarihi   := date_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1069' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1070' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Banka Aciklama Parametresi
                            begin
                                par_no   := r_c1.param_banka_aciklama;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.banka_aciklama   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.banka_aciklama   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1071' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1072' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Musteri Aciklama Parametresi
                            begin
                                par_no   := r_c1.param_musteri_aciklama;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.musteri_aciklama   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.musteri_aciklama   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1073' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1074' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Istatistik Kodu Parametresi
                            begin
                                par_no   := r_c1.param_istatistik_kodu;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.istatistik_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.istatistik_kodu   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1075' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1076' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Nakit Kodu Parametresi 22/12/04 sevalb nakit kod blok eklendi.
                            begin
                                par_no   := r_c1.param_nakit_kodu;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.nakit_kodu   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.nakit_kodu   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1075' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1076' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Referans Parametresi
                            begin
                                par_no   := r_c1.param_referans;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.referans   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.referans   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1077' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1078' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Musteri Hesap Tur Parametresi
                            begin
                                par_no   := r_c1.param_musteri_hesap_tur;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.musteri_hesap_tur   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.musteri_hesap_tur   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1079' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1080' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;
                            -- Musteri Hesap Numara Parametresi
                            begin
                                par_no   := r_c1.param_musteri_hesap_numara;
                                open c2;
                                fetch c2 into r_c2;
                                close c2;
                                if r_c2.tur = 'G' then
                                    r_satir.musteri_hesap_numara   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                                elsif r_c2.tur = 'T' then
                                    r_satir.musteri_hesap_numara   := varchar_list(par_no);
                                else
                                    raise_application_error(-20100, g_uc_delimiter || '1081' || g_uc_delimiter);
                                end if;
                            exception
                                when others then
                                    raise_application_error(-20100, g_uc_delimiter || '1082' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                            end;


                   -- B-O-M  seval.colak 01122021 gelir muhasebe degisiklikleri
                    -- gelir_musteri_no Parametresi
                    begin
                        par_no   :=  r_c1.param_gelir_musteri_no;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_musteri_no   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_musteri_no   := varchar_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_musteri_no' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_musteri_no' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_iliskili_dk_no Parametresi
                    begin
                        par_no   := r_c1.param_gelir_iliskili_dk_no;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_iliskili_dk_no   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_iliskili_dk_no   := varchar_list(par_no);
                            else
                                 raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_iliskili_dk_no' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_iliskili_dk_no' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_vergi_orani Parametresi
                    begin
                        par_no   := r_c1.param_gelir_vergi_orani;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_vergi_orani   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_vergi_orani   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_vergi_orani' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_vergi_orani' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_tutar_fc Parametresi
                    begin
                        par_no   := r_c1.param_gelir_tutar_fc;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_tutar_fc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_tutar_fc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_tutar_fc' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_tutar_fc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- gelir_doviz_kod Parametresi
                    begin
                        par_no   := r_c1.param_gelir_doviz_kod;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.gelir_doviz_kod   := get_global_varchar_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.gelir_doviz_kod   := varchar_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_gelir_doviz_kod' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_gelir_doviz_kod' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- matrah_tutar_fc Parametresi
                    begin
                        par_no   := r_c1.param_matrah_tutar_fc;
                         if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.matrah_tutar_fc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.matrah_tutar_fc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_matrah_tutar_fc' || g_uc_delimiter);
                            end if;
                          end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_matrah_tutar_fc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                    -- matrah_tutar_lc Parametresi
                    begin
                        par_no   := r_c1.param_matrah_tutar_lc;
                        if  nvl(par_no,0) <> 0 then
                            open c2;
                            fetch c2 into r_c2;
                            close c2;
                            if r_c2.tur = 'G' then
                                r_satir.matrah_tutar_lc   := get_global_number_value(par_no, r_c2.sira, r_c2.deger);
                            elsif r_c2.tur = 'T' then
                                r_satir.matrah_tutar_lc   := number_list(par_no);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '6860' ||g_ara_delimiter || 'param_matrah_tutar_lc' || g_uc_delimiter);
                            end if;
                           end if;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '6861' || g_ara_delimiter || 'param_matrah_tutar_lc' ||g_ara_delimiter || sqlerrm ||g_ara_delimiter  || g_uc_delimiter);
                    end;

                     -- E-O-M  seval.colak 01122021 gelir muhasebe degisiklikleri

                            if r_satir.tur = 'B' then
                                p_borc_bakiye   := nvl(p_borc_bakiye, 0) + nvl(r_satir.lc_tutar, 0);
                            elsif r_satir.tur = 'A' then
                                p_alacak_bakiye   := nvl(p_alacak_bakiye, 0) + nvl(r_satir.lc_tutar, 0);
                            else
                                raise_application_error(-20100, g_uc_delimiter || '1085' || g_uc_delimiter);
                            end if;
                            --mutluo
                            if r_satir.lc_tutar < 0 or r_satir.dv_tutar < 0 then
                                raise_application_error(
                                    -20100,
                                    g_uc_delimiter || '1040' || g_ara_delimiter || nvl(pmuhasebe_no, 0) || g_ara_delimiter || nvl(p_satir_no, 0) || g_ara_delimiter || r_satir.hesap_numara ||
                                    r_satir.doviz_kod || g_uc_delimiter);
                            end if;
                            begin
                                insert into cbs_satir(fis_numara, numara, tur, hesap_bolum_kodu, hesap_tur_kodu,
                                                      hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                                                      banka_aciklama, musteri_aciklama, istatistik_kodu, referans, musteri_hesap_tur,
                                                      musteri_hesap_numara, kur, nakit_kodu
                                                      ,gelir_musteri_no	,  gelir_iliskili_dk_no	,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                                      )
                                values (r_satir.fis_numara, p_satir_no, r_satir.tur, r_satir.hesap_bolum_kodu, r_satir.hesap_tur_kodu,
                                        r_satir.hesap_numara, r_satir.valor_tarihi, r_satir.lc_tutar, r_satir.dv_tutar, r_satir.doviz_kod,
                                        r_satir.banka_aciklama, r_satir.musteri_aciklama, r_satir.istatistik_kodu, r_satir.referans, r_satir.musteri_hesap_tur,
                                        to_char(r_satir.musteri_hesap_numara), r_satir.kur, r_satir.nakit_kodu
                                        ,r_satir.gelir_musteri_no, r_satir.gelir_iliskili_dk_no	,r_satir.gelir_vergi_orani,r_satir.gelir_tutar_fc,r_satir.gelir_doviz_kod,r_satir.matrah_tutar_fc,r_satir.matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                        );
                                insert into cbs_muhasebe_plan_calisan(tx_no, fis_no, satir_no, islem_kod, muhasebe_plan_no,
                                                                      muhasebe_bacak_no)
                                values (pislem_no, r_satir.fis_numara, p_satir_no, p2_islem_tanim_kod, p2_muhasebe_no,
                                        r_c1.muhasebe_bacak_numara);
                            exception
                                when others then
                                    raise_application_error(-20100,
                                                            g_uc_delimiter || '1086' || g_ara_delimiter || '(' || nvl(pmuhasebe_no, 0) || '-' || r_satir.hesap_numara || '-' || nvl(p_satir_no, 0) ||
                                                            ')' || sqlerrm || g_uc_delimiter);
                            end;
                            if r_satir.hesap_tur_kodu in ('VS', 'VD', 'KR') then
                                ---mutluo   hesap hareket kodu kontrolu
                                select nvl(hesap_hareket_kodu, 1)
                                into ln_hesap_hareket_kod
                                from cbs_vw_hesap_izleme
                                where hesap_no = r_satir.hesap_numara;
                                if r_satir.hesap_tur_kodu in ('VS', 'VD') then
                                    if (ln_hesap_hareket_kod = 2 and r_satir.tur = 'B') then
                                        raise_application_error(-20100, g_uc_delimiter || '1095' || g_ara_delimiter || '(' || r_satir.hesap_numara || ')' || g_uc_delimiter);
                                    elsif (ln_hesap_hareket_kod = 3 and r_satir.tur = 'A') then
                                        raise_application_error(-20100, g_uc_delimiter || '1094' || g_ara_delimiter || '(' || r_satir.hesap_numara || ')' || g_uc_delimiter);
                                    end if;
                                end if;
                                p_satir_no   := p_satir_no + 1;
                                if r_satir.hesap_tur_kodu = 'VS' then
                                    begin
                                        select musteri_dk_no
                                        into p_dk_kod
                                        from cbs_hesap
                                        where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                                    exception
                                        when no_data_found then
                                            raise_application_error(-20100,
                                                                    g_uc_delimiter || '1131' || g_ara_delimiter || to_char(r_satir.hesap_numara) || '-' || r_satir.doviz_kod || g_uc_delimiter);
                                        when others then
                                            raise_application_error(-20100, g_uc_delimiter || '1132' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                                    end;
                                elsif r_satir.hesap_tur_kodu = 'VD' then                                                                                                          -- Vadeli Hesap icin
                                    begin
                                        select musteri_dk_no
                                        into p_dk_kod
                                        from cbs_hesap_vadeli
                                        where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                                    exception
                                        when no_data_found then
                                            raise_application_error(-20100, g_uc_delimiter || '1153' || g_ara_delimiter || to_char(r_satir.hesap_numara) || g_uc_delimiter);
                                        when others then
                                            raise_application_error(-20100, g_uc_delimiter || '1154' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                                    end;
                                elsif r_satir.hesap_tur_kodu = 'KR' then                                                                                                           -- Kredi Hesap icin
                                    begin
                                        select musteri_dk_no
                                        into p_dk_kod
                                        from cbs_hesap_kredi
                                        where hesap_no = r_satir.hesap_numara and doviz_kodu = r_satir.doviz_kod;
                                    exception
                                        when no_data_found then
                                            raise_application_error(-20100, g_uc_delimiter || '3864' || g_ara_delimiter || to_char(r_satir.hesap_numara) || g_uc_delimiter);
                                        when others then
                                            raise_application_error(-20100, g_uc_delimiter || '3865' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                                    end;
                                end if;
                                begin
                                    --mutluo
                                    if r_satir.lc_tutar < 0 or r_satir.dv_tutar < 0 then
                                        raise_application_error(-20100,
                                                                g_uc_delimiter || '1040' || g_ara_delimiter || nvl(pmuhasebe_no, 0) || g_ara_delimiter || nvl(p_satir_no, 0) || g_ara_delimiter ||
                                                                p_dk_kod || r_satir.doviz_kod || g_uc_delimiter);
                                    end if;
                                    insert into cbs_satir(fis_numara, numara, tur, hesap_bolum_kodu, hesap_tur_kodu,
                                                          hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                                                          banka_aciklama, musteri_aciklama, istatistik_kodu, referans, musteri_hesap_tur,
                                                          musteri_hesap_numara, kur, nakit_kodu
                                                          ,gelir_musteri_no	,  gelir_iliskili_dk_no	,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                                          )
                                    values (r_satir.fis_numara, p_satir_no, r_satir.tur, r_satir.hesap_bolum_kodu, 'DK',
                                            p_dk_kod, r_satir.valor_tarihi, r_satir.lc_tutar, r_satir.dv_tutar, r_satir.doviz_kod,
                                            r_satir.banka_aciklama, r_satir.musteri_aciklama, r_satir.istatistik_kodu, r_satir.referans, r_satir.hesap_tur_kodu,
                                            r_satir.hesap_numara, r_satir.kur, r_satir.nakit_kodu
                                            ,r_satir.gelir_musteri_no, r_satir.gelir_iliskili_dk_no	,r_satir.gelir_vergi_orani,r_satir.gelir_tutar_fc,r_satir.gelir_doviz_kod,r_satir.matrah_tutar_fc,r_satir.matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                                            );
                                    insert into cbs_muhasebe_plan_calisan(tx_no, fis_no, satir_no, islem_kod, muhasebe_plan_no,
                                                                          muhasebe_bacak_no)
                                    values (pislem_no, r_satir.fis_numara, p_satir_no, p2_islem_tanim_kod, p2_muhasebe_no,
                                            r_c1.muhasebe_bacak_numara);
                                exception
                                    when others then
                                        raise_application_error(-20100, g_uc_delimiter || '1137' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                                end;
                            end if;
                            p_satir_no   := p_satir_no + 1;
                        end if;                                                                                                                                       -- if r_satir.LC_Tutar <> 0 then
                        --BOM CQ5717 MederT 13012017
                        declare
                            ln_sinif_count   number;
                        begin
                            select count(*)
                            into ln_sinif_count
                            from cbs_hesap
                            where hesap_no = r_satir.hesap_numara and urun_sinif_kod = 'ELCARD NON INT.BR-LC';
                            if (ln_sinif_count > 0) then
                                  pkg_elcard.callelcardws(r_satir.tur, r_satir.lc_tutar, p_islem_tanim_kod, r_satir.hesap_numara, r_satir.fis_numara, r_satir.numara, pislem_no); --bahianab cbs-531 Elcard optimization
                            end if;
                        end;
                    --EOM CQ5717 MederT 13012017
                    end loop;                                                                                                                                                                 -- satir
                    close c1;
                exception
                    when others then
                       -- raise_application_error(-20100, g_uc_delimiter || '1092' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                        RAISE_APPLICATION_ERROR(-20100,SQLERRM||'  '|| r_satir.hesap_numara||'  '||DBMS_UTILITY.FORMAT_ERROR_Backtrace);
                end;
            end if;
        end loop;                                                                                                                  -- end of loop =>  sablon kullanilmis ise sablon bacaklarini dolas.
        close c3;
        p_fark                   := 0;
        p_fark                   := abs(nvl(p_borc_bakiye, 0) - nvl(p_alacak_bakiye, 0));
        if balans_kontrol and nvl(p_fark, 0) >= 10 then
            raise_application_error(-20100, g_uc_delimiter || '1093' || g_uc_delimiter);
        end if;
        return p_fis_no;
    end fis_kes;
    function satir_ekle(p_islem_tanim_kod number, pmuhasebe_no in number, fis_numara in number, varchar_list in out varchar_array, number_list in out number_array,
                        date_list in out date_array, boolean_list in out boolean_array, p_gecerli_oldugu_tarih date default null, balans_kontrol boolean default true)
        return number is
        p_sonuc      number;
        p_islem_no   number;
    begin
        begin
            select islem_numara
            into p_islem_no
            from cbs_fis
            where numara = fis_numara;
        exception
            when others then
                return -900;                                                                                                                                                         -- Fis bulunamadi
        end;
        p_sonuc   :=
            fis_kes(p_islem_tanim_kod, pmuhasebe_no, p_islem_no, varchar_list, number_list,
                    date_list, boolean_list, p_gecerli_oldugu_tarih, balans_kontrol, fis_numara);
        return p_sonuc;
    end;
    --------------------------------------------------------------------
    procedure muhasebelestir(pfis_no number, p_tarih date default null) is
        cursor c0 is
            select rownum satir_isleme_numara, a.*
            from (select cbs_satir.*, decode(bakiye_karakteri, 'P', decode(tur, 'A', 1, 2), decode(tur, 'A', 2, 1)) karakter, bakiye_karakteri b_karakter, cbs_satir.rowid satir_rowid
                  from cbs_satir, cbs_hesap_bakiye hb
                  where fis_numara = pfis_no and hesap_tur_kodu != 'DK' and cbs_satir.hesap_numara = hb.hesap_no(+)
                  union
                  select cbs_satir.*, decode(dh.ba_kod, 'A', decode(tur, 'A', 1, 2), decode(tur, 'A', 2, 1)) karakter, dh.ba_kod b_karakter, cbs_satir.rowid satir_rowid
                  from cbs_satir, cbs_dkhesap dh
                  where fis_numara = pfis_no and hesap_tur_kodu = 'DK' and cbs_satir.hesap_numara = dh.numara(+) and cbs_satir.hesap_bolum_kodu = dh.bolum_kodu(+) and cbs_satir.doviz_kod =
                        dh.doviz_kod(+)
                  order by 4, 1, 6, karakter                                                                                              -- hesap_bolum_kodu,fis_numara,hesap_numara,bakiye_karakteri
                                            ) a;
        r_satir                         c0%rowtype;
        cursor c1 is
            select f.numara, f.islem_numara
            from cbs_fis f, cbs_islem i
            where f.islem_numara = i.numara and f.numara = pfis_no;
        p_muhasebelestigi_tarih         cbs_fis.muhasebelestigi_tarih%type;
        p_gecerli_oldugu_tarih          cbs_fis.muhasebelestigi_tarih%type;
        p_islem_numara                  cbs_fis.islem_numara%type;
        p_borc_bakiye                   cbs_dkhesap.borc_bakiye%type;                                                                                            -- borc/alacak kontrolunde kullanildi
        p_alacak_bakiye                 cbs_dkhesap.alacak_bakiye%type;                                                                                          -- borc/alacak kontrolunde kullanildi
        p_bakiye                        cbs_hesap_bakiye.bakiye%type;                                                                                            -- borc/alacak kontrolunde kullanildi
        p_ba_kod                        cbs_dkhesap.ba_kod%type;                                                                                                 -- borc/alacak kontrolunde kullanildi
        p_temp_bakiye                   cbs_hesap_bakiye.bakiye%type;                                                                                            -- borc/alacak kontrolunde kullanildi
        p_max_fis_no                    cbs_fis.fis_no%type;                                                                                                      -- max fis no'yu tutmakta kullanildi
        vn_ret                          number;                                                                                                                          -- function return'leri tutar
        p2_tarih                        date;
        p_fis_numara                    cbs_fis.numara%type;
        p_banka_tarihi                  date;
        p_onceki_banka_tarihi           date;
        p_sonraki_banka_tarihi          date;
        p_eod                           cbs_system.eod%type;
        p_kayit_kullanici_kodu          cbs_islem.kayit_kullanici_kodu%type;
        p_kayit_kullanici_rol_numara    cbs_islem.kayit_kullanici_rol_numara%type;
        p_kayit_kullanici_bolum_kodu    cbs_islem.kayit_kullanici_bolum_kodu%type;
        p_yaratildigi_tarih             cbs_fis.yaratildigi_tarih%type;
        vn_tx_code                      number;
        ln_eod_lc_tutar                 number;
        ln_eod_fc_tutar                 number;
        l_initial_bakiye                number;
        ln_bloke_tutari                 number;
        l_last_bakiye                   number;
        bakiye_yetersiz_exception       exception;
        bakiye_negatif_olamaz           exception;
        bakiye_pozitif_olamaz           exception;
        kapali_hesap_hareket_yaratma    exception;
        hesap_bulunamadi_exception      exception;
        ls_durum_kodu                   varchar2(1);
        ln_destek                       number;
        ls_fon                          varchar2(1);
        ls_fon_kodu                     varchar2(50);
        ln_fon_tutar                    number;
        ln_temp                         number;
        ln_kanal_no                     number;
        ls_terminal_id                  varchar2(100);
        ld_atm_date                     date;
        ls_overdraft_mi                 varchar2(1);
        ls_hesap_doviz_kodu             varchar2(3);
        ln_musteri_no                   number;
        ls_musteri_tipi_kod             varchar2(1);
        ln_urun_grup_no                 number;
        ln_musteri_urun_fc_limit        number;
        ln_musteri_urun_fc_risk         number;
        ls_musteri_urun_fc_doviz_kodu   varchar2(3);
        ln_musteri_urun_limit_bosluk    number;
        lb_musteri_urun_limit_var       boolean := false;
        ln_musteri_fc_limit             number;
        ln_musteri_fc_risk              number;
        ls_musteri_fc_doviz_kodu        varchar2(3);
        ln_musteri_limit_bosluk         number;
        lb_musteri_limit_var            boolean := false;
        ln_musteri_grup_fc_limit        number;
        ln_musteri_grup_fc_risk         number;
        ls_musteri_grup_fc_doviz_kodu   varchar2(3);
        ln_musteri_grup_limit_bosluk    number;
        lb_musteri_grup_limit_var       boolean := false;
        ls_grup_kod                     varchar2(10);
        ls_terminal_tipi                varchar2(20);
        ls_force_debit                  varchar2(1);
        ln_mus_grup_urun_fc_limit       number;
        ln_mus_grup_urun_fc_risk        number;
        ls_mus_grup_urun_fc_doviz       varchar2(3);
        ln_mus_grup_urun_limit_bosluk   number;
        lb_mus_grup_urun_limit_var      boolean;
        cursor hesap_cursor(p_hesapno number) is
            select nvl(b.bakiye, 0), nvl(b.bloke_tutari, 0)
            from cbs_hesap_bakiye b
            where b.hesap_no = p_hesapno
            for update;
        cursor hesap_acikmi(p_hesap_no number) is
            select h.durum_kodu, nvl(overdraft, 'H'), h.musteri_no, h.doviz_kodu
            from cbs_vw_hesap_izleme h
            where h.hesap_no = p_hesap_no;
        p_atm_kanal_no                  number := 8;
        ln_eod_lc_tutar_1               number;
        ln_eod_fc_tutar_1               number;
        p_cont_flag                     number;
        res_notify                      varchar2(10);                                                                                        --AdiletK 09.12.2014 CQ867 Notification function addition
        dyn_notify                      varchar2(10);                                                                                --AdiletK 09.12.2014 CQ867 Dynamic Notification function addition
        ls_pd_close_allowed_tx          varchar2(200);                                                                                                                            -- cbs-119 TemirlanT
        ln_count_pastdue                number := 0;                                                                                                                              -- cbs-119 TemirlanT
    begin
        p_banka_tarihi           := banka_tarihi_bul;
        p_onceki_banka_tarihi    := onceki_banka_tarihi_bul;
        p_sonraki_banka_tarihi   := sonraki_banka_tarihi_bul;
        if p_tarih is null then
            p2_tarih   := p_banka_tarihi;
        else
            p2_tarih   := p_tarih;
        end if;
        begin
            select f.gecerli_oldugu_tarih, f.muhasebelestigi_tarih, f.yaratildigi_tarih, f.islem_numara, i.kayit_kullanici_kodu,
                   i.kayit_kullanici_rol_numara, i.kayit_kullanici_bolum_kodu, i.islem_kod, nvl(i.kanal_numara, 0), force_debit
            into p_gecerli_oldugu_tarih, p_muhasebelestigi_tarih, p_yaratildigi_tarih, p_islem_numara, p_kayit_kullanici_kodu, p_kayit_kullanici_rol_numara,
                                       p_kayit_kullanici_bolum_kodu, vn_tx_code, ln_kanal_no, ls_force_debit
            from cbs_fis f, cbs_islem i
            where f.numara = pfis_no and i.numara = f.islem_numara;
        exception
            when no_data_found then
                raise_application_error(-20100, g_uc_delimiter || '1120' || g_uc_delimiter);
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1118' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
        end;
        if p_kayit_kullanici_bolum_kodu <> 'SYS' then
            begin
                select eod_muhasebe into p_eod from cbs_system;
            exception
                when others then
                    raise_application_error(-20100, g_uc_delimiter || '1116' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            end;
            if p_eod = 'H' then
                if ln_kanal_no = p_atm_kanal_no then                                                                                                                                   --mutluo 070330
                    --if it is from ATM and EOD for ATM is done but not for the system then treat this journal as EOD
                    begin                                                                                                                                                 --get the terminal id of ATM
                        select trim(terminal_id)
                        into ls_terminal_id
                        from cbs_atm_islem
                        where numara = p_islem_numara;
                    exception
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1117' || g_ara_delimiter || p_islem_numara || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    begin                                                                                                                                         -- get the booking date for that ATM
                        select atm_tarihi, terminal_tipi
                        into ld_atm_date, ls_terminal_tipi
                        from cbs_atm_parametre
                        where terminal_id = ls_terminal_id;
                    exception
                        when no_data_found then                                                                                                   --transaction from other networks. Process as normal
                            ld_atm_date        := p_banka_tarihi;
                            ls_terminal_tipi   := 'OTHER';
                        when others then
                            raise_application_error(-20100, g_uc_delimiter || '1134' || g_ara_delimiter || ls_terminal_id || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                    end;
                    if ls_terminal_tipi = 'ATM' then
                        if ld_atm_date > p_banka_tarihi then                                                                   -- EOD for that ATM has been done so process this journal as during EOD
                            p_eod   := 'E';
                        end if;
                    end if;
                end if;
            end if;
        else                                                                                                                                             --SYS bolumunun hic bir seyini kismiyoruz....
            p_eod   := 'H';
        end if;
        if p_eod = 'E' then
            --put fis_no into tarih into EOD table.. Consider accounting after EOD...
            select count(*)     --seval.colak 04062021
            into ln_temp
            from cbs_eod_fis_no
            where fis_numara = pfis_no;
            if nvl(ln_temp, 0) = 0 then     --seval.colak 04062021
                insert into cbs_eod_fis_no(fis_numara, fis_tarih, durum, yaratan, yaratildigi_tarih)
                values (pfis_no, p_tarih, 'A', user, sysdate);
            end if;
        end if;
        if p_muhasebelestigi_tarih is not null then
            select count(*)
            into ln_temp
            from cbs_eod_fis_no
            where fis_numara = pfis_no;
            if nvl(ln_temp, 0) = 0 then
                raise_application_error(-20100, g_uc_delimiter || '1121' || g_uc_delimiter);
            end if;
        end if;
        if to_char(p_gecerli_oldugu_tarih, 'YYYYMMDD') > to_char(p2_tarih, 'YYYYMMDD') then
            raise_application_error(-20100, g_uc_delimiter || '1122' || g_uc_delimiter);
        end if;
        pkg_limit.limit_kontrol(pfis_no, false, p_eod);
        open c0;
        loop
            fetch c0 into r_satir;
            exit when c0%notfound;
            if p_eod = 'E' then
                begin
                    select sum(decode(s.tur, 'A', nvl(lc_tutar, 0), -1 * nvl(lc_tutar, 0))), sum(decode(s.tur, 'A', nvl(dv_tutar, 0), -1 * nvl(dv_tutar, 0)))
                    into ln_eod_lc_tutar_1, ln_eod_fc_tutar_1
                    from cbs_satir s, cbs_eod_fis_no ef
                    where s.fis_numara = ef.fis_numara and ef.durum = 'A' and s.hesap_numara = r_satir.hesap_numara and s.hesap_tur_kodu = r_satir.hesap_tur_kodu and ef.fis_numara < pfis_no;
                    select sum(decode(s.tur, 'A', nvl(lc_tutar, 0), -1 * nvl(lc_tutar, 0))), sum(decode(s.tur, 'A', nvl(dv_tutar, 0), -1 * nvl(dv_tutar, 0)))
                    into ln_eod_lc_tutar, ln_eod_fc_tutar
                    from (select rownum satir_isleme_numara, a.*
                          from (select cbs_satir.*, decode(bakiye_karakteri, 'P', decode(tur, 'A', 1, 2), decode(tur, 'A', 2, 1)) karakter, bakiye_karakteri b_karakter
                                from cbs_satir, cbs_hesap_bakiye hb
                                where fis_numara = pfis_no and hesap_tur_kodu != 'DK' and cbs_satir.hesap_numara = hb.hesap_no(+)
                                union
                                select cbs_satir.*, decode(dh.ba_kod, 'A', decode(tur, 'A', 1, 2), decode(tur, 'A', 2, 1)) karakter, dh.ba_kod b_karakter
                                from cbs_satir, cbs_dkhesap dh
                                where fis_numara = pfis_no and hesap_tur_kodu = 'DK' and cbs_satir.hesap_numara = dh.numara(+) and cbs_satir.hesap_bolum_kodu = dh.bolum_kodu(+) and cbs_satir.
                                      doviz_kod =
                                      dh.doviz_kod(+)
                                order by 4, 1, 6, karakter                                                                                -- hesap_bolum_kodu,fis_numara,hesap_numara,bakiye_karakteri
                                                          ) a) s
                    where s.fis_numara in (select fis_numara
                                           from cbs_eod_fis_no ef
                                           where ef.durum = 'A') and s.hesap_numara = r_satir.hesap_numara and s.hesap_tur_kodu = r_satir.hesap_tur_kodu and ((s.fis_numara < r_satir.fis_numara) or (s.fis_numara = r_satir.fis_numara and s.satir_isleme_numara < r_satir.satir_isleme_numara)
                          );
                exception
                    when no_data_found then
                        ln_eod_lc_tutar   := 0;
                        ln_eod_fc_tutar   := 0;
                end;
                ln_eod_lc_tutar   := nvl(ln_eod_lc_tutar, 0) + nvl(ln_eod_lc_tutar_1, 0);
                ln_eod_fc_tutar   := nvl(ln_eod_fc_tutar, 0) + nvl(ln_eod_fc_tutar_1, 0);
                if r_satir.hesap_tur_kodu = 'DK' then
                    --pkg_dk.bakiye_guncelle(r_satir.hesap_bolum_kodu,r_satir.hesap_numara,r_satir.doviz_kod,r_satir.tur,r_satir.dv_tutar,r_satir.lc_tutar,true);
                    null;                                                                                          --burada son kullanma tarihi kontrolu yapiliyor. bu kontrolu yapmak gerekebilir....
                elsif r_satir.hesap_tur_kodu in ('VD', 'VS', 'KR') then
                    open hesap_acikmi(to_number(r_satir.hesap_numara));
                    fetch hesap_acikmi into ls_durum_kodu, ls_overdraft_mi, ln_musteri_no, ls_hesap_doviz_kodu;
                    if hesap_acikmi%notfound then
                        close hesap_acikmi;
                        raise hesap_bulunamadi_exception;
                    else
                        close hesap_acikmi;
                    end if;
                    if ls_durum_kodu = 'K' then
                        raise kapali_hesap_hareket_yaratma;
                    end if;
                    --------destek hesap --acik kontrolden gelir
                    --------Otomatik fon tutarini ekle
                    --                   select otomatik_fon, of_kodu
                    --                     into ls_fon, ls_fon_kodu
                    --                     from cbs_vw_hesap_izleme h
                    --                    where h.hesap_no=to_number(r_satir.hesap_numara);
                    --                   if nvl(ls_fon, 'H') = 'E' then
                    --                      ln_fon_tutar := pkg_hesap.Hesaptaki_OtmFon_Tutarini_al(to_number(r_satir.hesap_numara), ls_fon_kodu);
                    --                   else
                    ln_fon_tutar       := 0;
                    --                   end if;
                    open hesap_cursor(r_satir.hesap_numara);
                    fetch hesap_cursor into l_initial_bakiye, ln_bloke_tutari;
                    p_cont_flag        := 0;
                    if ls_overdraft_mi = 'E' and r_satir.hesap_tur_kodu = 'VS' then
                        p_cont_flag   := 1;
                        pkg_hesap.destek_hesap_limitleri(r_satir.hesap_numara, ls_hesap_doviz_kodu, ls_overdraft_mi, ln_musteri_no, ls_grup_kod,
                                                         ls_musteri_tipi_kod, ln_urun_grup_no, ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk, ls_musteri_urun_fc_doviz_kodu,
                                                         ln_musteri_urun_limit_bosluk, lb_musteri_urun_limit_var, ln_musteri_fc_limit, ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,
                                                         ln_musteri_limit_bosluk, lb_musteri_limit_var, ln_musteri_grup_fc_limit, ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu,
                                                         ln_musteri_grup_limit_bosluk, lb_musteri_grup_limit_var, ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk, ls_mus_grup_urun_fc_doviz,
                                                         ln_mus_grup_urun_limit_bosluk, lb_mus_grup_urun_limit_var, ln_destek);
                        -- b-o-m  sevalb 040208
                        if nvl(ln_destek, 0) > 0 and l_initial_bakiye < 0 and r_satir.b_karakter = 'P' and (r_satir.tur = 'B' or (ls_hesap_doviz_kodu = pkg_genel.lc_al and r_satir.lc_tutar < 0) or
                           (
                           ls_hesap_doviz_kodu <> pkg_genel.lc_al and r_satir.dv_tutar < 0)) then
                            l_initial_bakiye   := 0;
                        end if;
                    -- e-o-m  sevalb 040208
                    else                                                                                                                                                -- is not an overdraft account
                        ln_destek   := 0;
                    end if;
                    l_initial_bakiye   := nvl(l_initial_bakiye, 0) + ln_destek + ln_fon_tutar;
                    if r_satir.doviz_kod = pkg_genel.lc_al then
                        if r_satir.tur = 'A' then
                            l_last_bakiye   := l_initial_bakiye + ln_eod_lc_tutar + r_satir.lc_tutar;
                        else
                            l_last_bakiye   := l_initial_bakiye + ln_eod_lc_tutar - r_satir.lc_tutar;
                        end if;
                        if r_satir.b_karakter = 'P' and (l_last_bakiye - ln_bloke_tutari) < 0 and (r_satir.tur = 'B' or r_satir.lc_tutar < 0) then
                            if ls_force_debit = 'H' then
                                raise bakiye_negatif_olamaz;
                            end if;
                        end if;
                        if r_satir.b_karakter = 'N' and (l_last_bakiye - ln_bloke_tutari) > 0 and (r_satir.tur = 'A' or r_satir.lc_tutar < 0) then
                            raise bakiye_pozitif_olamaz;
                        end if;
                    /*
                    if p_cont_flag = 1
                    then
                        log_at('qwerty_0',r_satir.dv_tutar);
                        log_at('qwerty_1',r_satir.hesap_numara,r_satir.b_karakter,r_satir.b_karakter);
                        log_at('qwerty_2',l_initial_bakiye,ln_bloke_tutari,ln_destek);
                        log_at('qwerty_3',ls_overdraft_mi,ls_grup_kod,ln_urun_grup_no);
                        log_at('qwerty_4',ln_musteri_urun_fc_limit,ln_musteri_urun_fc_limit, ln_musteri_urun_fc_risk);
                        log_at('qwerty_5',ls_musteri_urun_fc_doviz_kodu,ln_musteri_urun_limit_bosluk,ln_musteri_fc_limit);
                        log_at('qwerty_6',ln_musteri_fc_risk, ls_musteri_fc_doviz_kodu,ln_musteri_limit_bosluk);
                        log_at('qwerty_7',ln_musteri_grup_fc_limit,ln_musteri_grup_fc_risk, ls_musteri_grup_fc_doviz_kodu);
                        log_at('qwerty_8',ln_musteri_grup_limit_bosluk,ln_mus_grup_urun_fc_limit, ln_mus_grup_urun_fc_risk);
                        log_at('qwerty_9',ls_mus_grup_urun_fc_doviz,ln_mus_grup_urun_limit_bosluk);
                    end if;
                    */
                    else
                        if r_satir.tur = 'A' then
                            l_last_bakiye   := l_initial_bakiye + ln_eod_fc_tutar + r_satir.dv_tutar;
                        else
                            l_last_bakiye   := l_initial_bakiye + ln_eod_fc_tutar - r_satir.dv_tutar;
                        end if;
                        if r_satir.b_karakter = 'P' and (l_last_bakiye - ln_bloke_tutari) < 0 and (r_satir.tur = 'B' or r_satir.dv_tutar < 0) then
                            if ls_force_debit = 'H' then
                                raise bakiye_negatif_olamaz;
                            end if;
                        end if;
                        if r_satir.b_karakter = 'N' and (l_last_bakiye - ln_bloke_tutari) > 0 and (r_satir.tur = 'A' or r_satir.dv_tutar < 0) then
                            raise bakiye_pozitif_olamaz;
                        end if;
                    end if;
                    close hesap_cursor;
                end if;
            else
                -- Hesap turune gore ilgili hesap bakiyesini guncelle
                if r_satir.hesap_tur_kodu = 'DK' then
                    pkg_dk.bakiye_guncelle(r_satir.hesap_bolum_kodu, r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, r_satir.dv_tutar,
                                           r_satir.lc_tutar, true, r_satir.fis_numara, p_yaratildigi_tarih, p_muhasebelestigi_tarih,
                                           r_satir.numara, p_islem_numara, vn_tx_code, r_satir.satir_rowid);
                elsif r_satir.hesap_tur_kodu = 'VD' then
                    pkg_hesap.bakiye_guncelle('VD', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, r_satir.dv_tutar,
                                              r_satir.lc_tutar, pfis_no, ls_force_debit);
                elsif r_satir.hesap_tur_kodu = 'VS' then
                    pkg_hesap.bakiye_guncelle('VS', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, r_satir.dv_tutar,
                                              r_satir.lc_tutar, pfis_no, ls_force_debit);
                elsif r_satir.hesap_tur_kodu = 'KR' then
                    pkg_hesap.bakiye_guncelle('KR', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, r_satir.dv_tutar,
                                              r_satir.lc_tutar, pfis_no, ls_force_debit);
                end if;
            end if;
        end loop;                                                                                                                                                                             -- satir
        close c0;
        -- Upadate status of group headings ( fis )
        open c1;
        loop
            fetch c1 into p_fis_numara, p_islem_numara;
            exit when c1%notfound;
            if p_eod = 'E' then
                update cbs_fis
                set muhasebelestigi_tarih   = p_sonraki_banka_tarihi
                where numara = p_fis_numara;
            else
                p_max_fis_no   := fis_no_getir(p_kayit_kullanici_bolum_kodu, p_kayit_kullanici_kodu, p2_tarih, false);
                if p_max_fis_no < 0 then
                    raise_application_error(-20100, g_uc_delimiter || '1123' || g_uc_delimiter);
                end if;
                begin
                    update cbs_fis
                    set muhasebelestigi_tarih = p2_tarih, fis_no = p_max_fis_no
                    where numara = p_fis_numara;
                exception
                    when others then
                        raise_application_error(-20100, g_uc_delimiter || '1124' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                end;
            end if;
        end loop;
        close c1;                                                                                                                                                                                --fis
        pkg_tahsilat_islemleri.overdraft_interest_payment(p_islem_numara);                                                                       -- AdiletK 30122014 CQ1236 Overdraft Interest Payment
          --BOM aisuluud cq4883 past due closing TemirlanT cbs-119
        pkg_parametre.deger('G_PD_CLOSE_ALLOWED_TX', ls_pd_close_allowed_tx);
        if (instr(ls_pd_close_allowed_tx, vn_tx_code) > 0) then  
            null;--    PKG_KREDI_AUTOMATION.pastdue_closing_payment_main(p_islem_numara); --seval.colak 10052022 pastdue_closing disabled with loan accrual modifications
            /*select count(*)
            into ln_count_pastdue
            from cbs_hesap_kredi k
                 right join cbs_satir s
                     on k.musteri_no = pkg_hesap.hesaptanmusterinoal(s.hesap_numara) and pkg_musteri.report_customer_type(pkg_hesap.hesaptanmusterinoal(s.hesap_numara)) in (1, 2) and s.
                        fis_islem_numara =
                        p_islem_numara and s.hesap_tur_kodu = 'VS' and s.tur = 'A'
            where k.durum_kodu = 'A' and k.urun_tur_kod != 'PD-CARD' and k.urun_sinif_kod not in ('CRD.CARD-LC') and k.pastdue_faiz_anapara_sec is not null;
            if (ln_count_pastdue > 0) then
                pkg_tahsilat_islemleri.pastdue_closing_payment(p_islem_numara);
            end if;*/
        end if; 
        --EOM aisuluud cq4883 past due closing   TemirlanT cbs-119
       res_notify               := cbs.pkg_add_notification.addtonotifylist(p_islem_numara, vn_tx_code, null);            --bahianab 04102022 CBS-760              --AdiletK 09.12.2014 CQ867 Notification function addition
       dyn_notify               := cbs.pkg_add_notification.addtodynamicnotifylist(p_islem_numara, vn_tx_code, null);     --bahianab 04102022 CBS-760             --AdiletK 09.12.2014 CQ867 dynamicTranProcess function addition
        --BOM CQ5717 MederT 13012017
        --Salary Test
        declare
            ln_count_elcard_acc   number := 0;
            ls_cust               varchar2(100);
            cursor c_accs is
                select s.hesap_numara
                from cbs_satir s
                     join cbs_hesap h on h.hesap_no = s.hesap_numara
                where h.urun_sinif_kod != 'ELCARD NON INT.BR-LC' and fis_numara = pfis_no;
        begin
            select count(*)
            into ln_count_elcard_acc
            from cbs_satir s
                 join cbs_hesap h on h.hesap_no = s.hesap_numara
            where h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and fis_numara = pfis_no;
            if (ln_count_elcard_acc > 0) and (vn_tx_code = 2150) then
                pkg_parametre.deger('ELCARD_TEST_CUST', ls_cust);
                if length(ls_cust) > 0 then
                    for r_acc in c_accs loop
                        if (instr(ls_cust, r_acc.hesap_numara) = 0) then
                            raise_application_error(-20100, g_uc_delimiter || '6180' || pkg_hata.getdelimiter || pkg_hata.getucpointer);
                        end if;
                    end loop;
                end if;
            end if;
        end;
        --EOM CQ5717 MederT 13012017
        pkg_elcard.addelcardwsqueue(vn_tx_code, p_islem_numara, pfis_no);    --bahianab cbs-531 Elcard optimization              --CQ5717 Elcard MederT 27032017
    exception
        when hesap_bulunamadi_exception then
            raise_application_error(-20100, g_uc_delimiter || '1156' || g_ara_delimiter || r_satir.hesap_numara || g_uc_delimiter);
        when bakiye_negatif_olamaz then
            raise_application_error(-20100, g_uc_delimiter || '1487' || g_ara_delimiter || r_satir.hesap_numara || g_uc_delimiter);
        when bakiye_pozitif_olamaz then
            raise_application_error(-20100, g_uc_delimiter || '1486' || g_ara_delimiter || r_satir.hesap_numara || g_uc_delimiter);
        when kapali_hesap_hareket_yaratma then
            raise_application_error(-20100, g_uc_delimiter || '1604' || g_ara_delimiter || r_satir.hesap_numara || g_uc_delimiter);
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1126' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    --------------------------------------------------------------------------------------
    function prepare_rpt_parameter(p_islem_tanim_kod in number, pmuhasebe_no in number, pislem_no in number, varchar_list in varchar_array, number_list in number_array,
                                   date_list in date_array, boolean_list in boolean_array)
        return number is
    begin
        return 1;                                                                                                                                                -- detaylari tbs'den al ve sadelestir
    end;
    --------------------------------------------------------------------------------------
    function prepare_notification(p_islem_tanim_kod in number, pmuhasebe_no in number, pislem_no in number, varchar_list in varchar_array, number_list in number_array,
                                  date_list in date_array, boolean_list in boolean_array)
        return number is
    begin
        return 1;                                                                                                                                                -- detaylari tbs'den al ve sadelestir
    end;
    function ters_fis_yarat(pn_islem_numara number, p_fis_numara cbs_fis.numara%type, p_banka_tarihi date default null)
        return number is
        -- gonderilen numarali fisin bacaklari kontrol edilir, bu fisin tersi yaratilir.
        -- Eger fis muhasebelesmisse ters fis te muhasebelestirilir.
        -- <0 anything abnormal
        -- >0 normal complete...
        -- mutluo --25/08/2000 creation
        -- mutluo --29/09/2004 change for CBS
        cursor cur_muhasebe(p_fisno cbs_fis.numara%type) is
            select muhasebelestigi_tarih
            from cbs_fis
            where numara = p_fisno;
        p_ters_fis_numara   cbs_fis.numara%type;
        p_ters_fis_no       cbs_fis.fis_no%type;
        p_muhasebe_tarih    cbs_fis.muhasebelestigi_tarih%type;
        p_banking_date      date;
        p_sonuc             number;
        ps_kullanici_kodu   cbs_kullanici.kodu%type;
        ps_bolum_kodu       cbs_bolum.kodu%type;
    begin
        ps_kullanici_kodu   := pkg_baglam.kullanici_kodu;
        ps_bolum_kodu       := pkg_baglam.bolum_kodu;
        if p_banka_tarihi is null then
            p_banking_date   := banka_tarihi_bul;
        else
            p_banking_date   := p_banka_tarihi;
        end if;
        p_ters_fis_numara   := fis_numara_getir;
        p_ters_fis_no       := fis_no_getir(ps_bolum_kodu, ps_kullanici_kodu, p_banking_date, false);
        if p_ters_fis_no < 0 then                                                                                                                                              -- error getting fis_no
            close cur_muhasebe;
            raise_application_error(-20100, g_uc_delimiter || '1123' || g_uc_delimiter);
            return -1;
        end if;
        insert into cbs_fis(numara, aciklama, islem_numara, yaratildigi_tarih, gecerli_oldugu_tarih,
                            muhasebelestigi_tarih, yaratan_kullanici_kodu, fis_no, yaratildigi_banka_tarih, iptal_edilebilir,
                            force_debit)
            (select p_ters_fis_numara, ' Reverse journal of journal ' || to_char(p_fis_numara), pn_islem_numara, sysdate, p_banking_date,
                    null, s.yaratan_kullanici_kodu, p_ters_fis_no, p_banking_date, iptal_edilebilir,
                    force_debit
             from cbs_fis s
             where s.numara = p_fis_numara);
        insert into cbs_satir(fis_numara, numara, tur, hesap_bolum_kodu, hesap_tur_kodu,
                              hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                              banka_aciklama, musteri_aciklama, istatistik_kodu, referans, yaratildigi_tarih,
                              yaratan_kullanici_kodu, kur, nakit_kodu, musteri_hesap_tur, musteri_hesap_numara
                              ,gelir_musteri_no	,  gelir_iliskili_dk_no	,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
                              )
            (select p_ters_fis_numara, numara, decode(tur, 'B', 'A', 'B'), hesap_bolum_kodu, hesap_tur_kodu,
                    hesap_numara, valor_tarihi, lc_tutar, dv_tutar, doviz_kod,
                    banka_aciklama || ' CANCELATION', musteri_aciklama || ' CANCELATION', istatistik_kodu, referans, yaratildigi_tarih,
                    yaratan_kullanici_kodu, kur, nakit_kodu, musteri_hesap_tur, musteri_hesap_numara
                     ,gelir_musteri_no	,  gelir_iliskili_dk_no	,gelir_vergi_orani,gelir_tutar_fc,gelir_doviz_kod,matrah_tutar_fc,matrah_tutar_lc    -- seval.colak 01122021 gelir muhasebe degisiklikleri
             from cbs_satir s
             where s.fis_numara = p_fis_numara);
        begin
            update cbs_islem
            set fis_numara   = p_ters_fis_numara
            where numara = pn_islem_numara;
        exception
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1047' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
                return -1;
        end;
        open cur_muhasebe(p_fis_numara);
        fetch cur_muhasebe into p_muhasebe_tarih;                                                                                                                      -- muhasebelesmis mi kontrolu..
        close cur_muhasebe;
        if p_muhasebe_tarih is not null then
            --islem muhasebelesmis - muhasebelestir
            pkg_muhasebe.muhasebelestir(p_ters_fis_numara, p_banking_date);
        else
            null;                                                                                                                                -- islem muhasebelesmemis.. ters fis muhasebelestirme
        end if;
        return p_ters_fis_numara;
    exception
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1465' || g_ara_delimiter || to_char(p_fis_numara) || g_ara_delimiter || sqlerrm || g_uc_delimiter);
            return -1;
    end;
    ----------------------------------------------------------------------------------
    -- Cancels all accounting groups belonging to given tx
    function fis_tx_iptal(pn_tx_no in number, pb_banking_date in date)
        return number is
    begin
        return 1;                                                                                                                                                -- detaylari tbs'den al ve sadelestir
    end;
    procedure fis_iptal(p_fis_numara cbs_fis.numara%type, p_banka_tarihi date default null) is
        p_islem_numara                 cbs_islem.numara%type;
        p_kayit_kullanici_kodu         cbs_islem.kayit_kullanici_kodu%type;
        p_kayit_kullanici_rol_numara   cbs_islem.kayit_kullanici_rol_numara%type;
        p_kayit_kullanici_bolum_kodu   cbs_islem.kayit_kullanici_bolum_kodu%type;
        p_onay_kullanici_bolum_kodu    cbs_islem.onay_kullanici_bolum_kodu%type;
        p_islem_kodu                   cbs_islem.islem_kod%type;
        p_banking_date                 date;
        cursor lc_fis is
            select numara, muhasebelestigi_tarih
            from cbs_fis
            where numara = p_fis_numara and iptal_edilebilir = 'E' and iptal_edildigi_tarih is null
            order by tur asc;
        p_muhasebe_tarih               cbs_fis.muhasebelestigi_tarih%type;
        p2_fis_numara                  number;
        cursor lc_satir is
            select cbs_satir.*, decode(bakiye_karakteri, 'P', decode(tur, 'A', 2, 1), decode(tur, 'A', 1, 2)) karakter, cbs_satir.rowid satir_rowid
            from cbs_satir, cbs_hesap_bakiye hb
            where fis_numara = p_fis_numara and hesap_tur_kodu != 'DK' and cbs_satir.hesap_numara = hb.hesap_no
            union
            select cbs_satir.*, decode(dh.ba_kod, 'A', decode(tur, 'A', 2, 1), decode(tur, 'A', 1, 2)) karakter, cbs_satir.rowid satir_rowid
            from cbs_satir, cbs_dkhesap dh
            where fis_numara = p_fis_numara and hesap_tur_kodu = 'DK' and cbs_satir.hesap_numara = dh.numara and cbs_satir.hesap_bolum_kodu = dh.bolum_kodu and cbs_satir.doviz_kod = dh.doviz_kod
            order by 1, 6, karakter;                                                                                                                       -- fis_numara,hesap_numara,bakiye_karakteri
        r_satir                        lc_satir%rowtype;
        p_sonuc                        number;
        p_tur                          cbs_satir.tur%type;
        vn_ret                         number;
        --eod ekleme basi 28.12.2006 mutluo
        cursor c_eod_fisi(pfis_no number) is
            select *
            from cbs_eod_fis_no efn
            where efn.fis_numara = pfis_no and efn.durum = 'A'
            for update;
        r_eod_fisi                     c_eod_fisi%rowtype;
        ls_force_debit                 varchar2(1);
        --eod ekleme sonu 28.12.2006 mutluo
        p_yaratildigi_tarih            cbs_fis.yaratildigi_tarih%type;
        p_muhasebelestigi_tarih        cbs_fis.muhasebelestigi_tarih%type;
    begin
        p_banking_date   := banka_tarihi_bul;
        begin
            select f.islem_numara, i.kayit_kullanici_kodu, i.kayit_kullanici_rol_numara, i.kayit_kullanici_bolum_kodu, i.onay_kullanici_bolum_kodu,
                   i.islem_kod, force_debit, yaratildigi_tarih, muhasebelestigi_tarih
            into p_islem_numara, p_kayit_kullanici_kodu, p_kayit_kullanici_rol_numara, p_kayit_kullanici_bolum_kodu, p_onay_kullanici_bolum_kodu, p_islem_kodu,
                               ls_force_debit, p_yaratildigi_tarih, p_muhasebelestigi_tarih
            from cbs_fis f, cbs_islem i
            where f.numara = p_fis_numara and i.numara = f.islem_numara;
        exception
            when no_data_found then
                raise_application_error(-20100, g_uc_delimiter || '1382' || g_uc_delimiter);
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1383' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
        end;
        open lc_fis;
        loop
            fetch lc_fis into p2_fis_numara, p_muhasebe_tarih;                                                                                                         -- muhasebelesmis mi kontrolu..
            exit when lc_fis%notfound;
            --eod ekleme 28.12.2006 mutluo
            --EOD sirasinda kesilmis ve henuz muhasebelesmemis ve iptal ediliyor...dikkat et....
            open c_eod_fisi(p2_fis_numara);
            fetch c_eod_fisi into r_eod_fisi;
            if c_eod_fisi%found then
                update cbs_eod_fis_no
                set durum   = 'I'
                where current of c_eod_fisi;
                update cbs_fis
                set muhasebelestigi_tarih   = p_banking_date
                where numara = p2_fis_numara;
            else
                --eod ekleme sonu 28.12.2006 mutluo
                if p_muhasebe_tarih is not null then
                    -- Islem muhasebelesmis
                    if to_char(p_muhasebe_tarih, 'ddmmyyyy') <> to_char(p_banking_date, 'ddmmyyyy') then
                        close lc_fis;                                                                                                                            -- ayni gun degil, islem yapilamaz...
                        raise_application_error(-20100, g_uc_delimiter || '1384' || g_uc_delimiter);
                    end if;
                    pkg_limit.risk_iptal(p_fis_numara);
                    open lc_satir;
                    loop
                        fetch lc_satir into r_satir;
                        exit when lc_satir%notfound;
                        -- Hesap turune gore ilgili hesap bakiyesini guncelle
                        if r_satir.hesap_tur_kodu = 'DK' then
                            pkg_dk.bakiye_guncelle(r_satir.hesap_bolum_kodu, r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, -r_satir.dv_tutar,
                                                   -r_satir.lc_tutar, true, r_satir.fis_numara, p_yaratildigi_tarih, p_muhasebelestigi_tarih,
                                                   r_satir.numara, p_islem_numara, p_islem_kodu, r_satir.satir_rowid);
                        elsif r_satir.hesap_tur_kodu = 'VD' then
                            pkg_hesap.bakiye_guncelle('VD', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, -r_satir.dv_tutar,
                                                      -r_satir.lc_tutar, p_fis_numara, ls_force_debit);                                                               --mutluo 2006-Dec  add parameter
                        elsif r_satir.hesap_tur_kodu = 'VS' then
                            pkg_hesap.bakiye_guncelle('VS', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, -r_satir.dv_tutar,
                                                      -r_satir.lc_tutar, p_fis_numara, ls_force_debit);                                                               --mutluo 2006-Dec  add parameter
                        elsif r_satir.hesap_tur_kodu = 'KR' then
                            pkg_hesap.bakiye_guncelle('KR', r_satir.hesap_numara, r_satir.doviz_kod, r_satir.tur, -r_satir.dv_tutar,
                                                      -r_satir.lc_tutar, p_fis_numara, ls_force_debit);                                                               --mutluo 2006-Dec  add parameter
                        end if;
                    end loop;                                                                                                                                                                 -- satir
                    close lc_satir;
                else
                    null;
                end if;
            --eod ekleme basi 28.12.2006 mutluo
            end if;                                                                                                                                                                         --eod fisi
            --eod ekleme sonu 28.12.2006 mutluo
            -- fisin iptal tarihi set edilir
            update cbs_fis
            set iptal_edildigi_tarih = pkg_muhasebe.banka_tarihi_bul, tur = 'X'
            where numara = p2_fis_numara;
            --TA: Fis iptal edilirse sonraki fislerin hareketli bakiyeleri tekrar hesaplanir
            update cbs_satir sa
            set sa.balance_flag   = '0'
            where sa.fis_numara >= p2_fis_numara and sa.hesap_numara in (select s.hesap_numara
                                                                         from cbs_satir s
                                                                         where s.fis_numara = p2_fis_numara and s.hesap_tur_kodu in ('VS', 'VD', 'KR'));
        end loop;
        close lc_fis;
    exception
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1385' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    ---------------------------------------------------------------------------------------
    procedure gecici_fis_iptal(p_fis_numara cbs_fis.numara%type) is
    begin
        update cbs_fis                                                                                                                                                -- fisin iptal tarihi set edilir
        set iptal_edildigi_tarih = pkg_muhasebe.banka_tarihi_bul, tur = 'I'
        where numara = p_fis_numara and tur = 'T';                                                                                                                                     -- T: Temporary
    exception
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1363' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    function gecici_fis_yap(p_fis_numara cbs_fis.numara%type,                                                                                                                        -- Ana fis numara
                                                              p_gecerli_oldugu_tarih date, p_gecici_fis_numara cbs_fis.numara%type,                                -- Gecici Olmasi istenen fis numara
                                                                                                                                    p_islem_numara cbs_islem.numara%type)
        return number is
    begin
        return 1;                                                                                                                                                -- detaylari tbs'den al ve sadelestir
    end;
    function efektif_tarih_duzelt(pfis_numara number, pefektif_banka_tarih date)
        return number is
    -- Return Codes
    --  1 : Islem basari ile tamamlandi. Duzeltildi
    -- <0 : Basarisiz
    begin
        update cbs_fis
        set gecerli_oldugu_tarih   = pefektif_banka_tarih
        where numara = pfis_numara;
        return 1;
    exception
        when others then
            return -2081;
    end;
    procedure dk_bul(pn_gl_group_code in number, ps_modul_tur_kod in varchar2, ps_urun_tur_kod in varchar2, ps_urun_sinif_kod in varchar2, pn_gl_index in number,
                     pb_kosul_1 in boolean, pb_kosul_2 in boolean, pb_kosul_3 in boolean, ps_gl_code out varchar2, pb_kosul_4 in boolean default null,
                     pb_kosul_5 in boolean default null, pb_kosul_6 in boolean default null, pb_kosul_7 in boolean default null, pb_kosul_8 in boolean default null, pb_kosul_9 in boolean default null, pb_kosul_10 in boolean default null, pn_islem_tanim_kod in number default 0, pb_kosul_11 in boolean default null, pb_kosul_12 in boolean default null, pb_kosul_13 in boolean default null
                     , pb_kosul_14 in boolean default null, pb_kosul_15 in boolean default null) is
        ps_kosul_1    varchar2(1);
        ps_kosul_2    varchar2(1);
        ps_kosul_3    varchar2(1);
        ps_kosul_4    varchar2(1);
        ps_kosul_5    varchar2(1);
        ps_kosul_6    varchar2(1);
        ps_kosul_7    varchar2(1);
        ps_kosul_8    varchar2(1);
        ps_kosul_9    varchar2(1);
        ps_kosul_10   varchar2(1);
        ps_kosul_11   varchar2(1);
        ps_kosul_12   varchar2(1);
        ps_kosul_13   varchar2(1);
        ps_kosul_14   varchar2(1);
        ps_kosul_15   varchar2(1);
    begin
        if pb_kosul_1 then
            ps_kosul_1   := 'D';
        else
            ps_kosul_1   := 'Y';
        end if;
        if pb_kosul_2 then
            ps_kosul_2   := 'D';
        else
            ps_kosul_2   := 'Y';
        end if;
        if pb_kosul_3 then
            ps_kosul_3   := 'D';
        else
            ps_kosul_3   := 'Y';
        end if;
        if pb_kosul_4 then
            ps_kosul_4   := 'D';
        else
            ps_kosul_4   := 'Y';
        end if;
        if pb_kosul_5 then
            ps_kosul_5   := 'D';
        else
            ps_kosul_5   := 'Y';
        end if;
        if pb_kosul_6 then
            ps_kosul_6   := 'D';
        else
            ps_kosul_6   := 'Y';
        end if;
        if pb_kosul_7 then
            ps_kosul_7   := 'D';
        else
            ps_kosul_7   := 'Y';
        end if;
        if pb_kosul_8 then
            ps_kosul_8   := 'D';
        else
            ps_kosul_8   := 'Y';
        end if;
        if pb_kosul_9 then
            ps_kosul_9   := 'D';
        else
            ps_kosul_9   := 'Y';
        end if;
        if pb_kosul_10 then
            ps_kosul_10   := 'D';
        else
            ps_kosul_10   := 'Y';
        end if;
        if pb_kosul_11 then
            ps_kosul_11   := 'D';
        else
            ps_kosul_11   := 'Y';
        end if;
        if pb_kosul_12 then
            ps_kosul_12   := 'D';
        else
            ps_kosul_12   := 'Y';
        end if;
        if pb_kosul_13 then
            ps_kosul_13   := 'D';
        else
            ps_kosul_13   := 'Y';
        end if;
        if pb_kosul_14 then
            ps_kosul_14   := 'D';
        else
            ps_kosul_14   := 'Y';
        end if;
        if pb_kosul_15 then
            ps_kosul_15   := 'D';
        else
            ps_kosul_15   := 'Y';
        end if;
        begin
            select decode(pn_gl_index,  1, dk_hesabi_1,  2, dk_hesabi_2,  3, dk_hesabi_3,  4, dk_hesabi_4,  5, dk_hesabi_5,  6, dk_hesabi_6,  7, dk_hesabi_7,  8, dk_hesabi_8,  9, dk_hesabi_9,  10, dk_hesabi_10,  11, dk_hesabi_11,  12, dk_hesabi_12,  13, dk_hesabi_13,  14, dk_hesabi_14,  15, dk_hesabi_15)
            into ps_gl_code
            from cbs_urun_kosul
            where modul_tur_kod = ps_modul_tur_kod and urun_tur_kod = ps_urun_tur_kod and urun_sinif_kod = ps_urun_sinif_kod and grup_kod = pn_gl_group_code and islem_tanim_kod =
                  pn_islem_tanim_kod and ps_kosul_1 = kosul_1 and ps_kosul_2 = kosul_2 and ps_kosul_3 = kosul_3 and ps_kosul_4 = kosul_4 and ps_kosul_5 = kosul_5 and ps_kosul_6 = kosul_6 and
                  ps_kosul_7 = kosul_7 and ps_kosul_8 = kosul_8 and ps_kosul_9 = kosul_9 and ps_kosul_10 = kosul_10 and ps_kosul_11 = kosul_11 and ps_kosul_12 = kosul_12 and ps_kosul_13 = kosul_13
                  and ps_kosul_14 = kosul_14 and ps_kosul_15 = kosul_15;
        exception
            when no_data_found then
                select decode(pn_gl_index,  1, dk_hesabi_1,  2, dk_hesabi_2,  3, dk_hesabi_3,  4, dk_hesabi_4,  5, dk_hesabi_5,  6, dk_hesabi_6,  7, dk_hesabi_7,  8, dk_hesabi_8,  9, dk_hesabi_9,  10, dk_hesabi_10,  11, dk_hesabi_11,  12, dk_hesabi_12,  13, dk_hesabi_13,  14, dk_hesabi_14,  15, dk_hesabi_15)
                into ps_gl_code
                from cbs_grup_urun_sinif
                where modul_tur_kod = ps_modul_tur_kod and urun_tur_kod = ps_urun_tur_kod and urun_sinif_kod = ps_urun_sinif_kod and grup_kod = pn_gl_group_code;
            when others then
                raise_application_error(-20100, g_uc_delimiter || '1702' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
        end;
    exception
        when no_data_found then
            raise_application_error(-20100,
                                    g_uc_delimiter || '1704' || g_ara_delimiter || to_char(pn_gl_group_code) || g_ara_delimiter || ps_modul_tur_kod || g_ara_delimiter || ps_urun_tur_kod ||
                                    g_ara_delimiter || ps_urun_sinif_kod || g_uc_delimiter);
        when others then
            raise_application_error(-20100, g_uc_delimiter || '1703' || g_ara_delimiter || sqlerrm || g_uc_delimiter);
    end;
    function dk_varmi(ps_bolum varchar2, ps_dk varchar2, ps_doviz varchar2)
        return varchar2 is
        ls_mevcut   varchar2(1) := 'H';
    begin
        select 'E'
        into ls_mevcut
        from cbs_dkhesap
        where bolum_kodu = ps_bolum and numara = ps_dk and doviz_kod = ps_doviz;
        return ls_mevcut;
    exception
        when others then
            return 'H';
    end;
    function komisyon_dk_bul(pn_dk_kod cbs_musteri.dk_grup_kod%type, ps_masraf_kodu cbs_masraf_tur.kodu%type, pn_index number default 1)
        return varchar2 is
        ls_dk   varchar2(20) := null;
    begin
        select decode(pn_index,  1, dkhesap_1,  2, dkhesap_2,  3, dkhesap_3,  dkhesap_1)
        into ls_dk
        from cbs_masraf_dkgrup_dk
        where masraf_kodu = ps_masraf_kodu and dk_grup_kodu = pn_dk_kod;
        return ls_dk;
    exception
        when no_data_found then
            return null;
        when others then
            return null;
    end;
end;
/

