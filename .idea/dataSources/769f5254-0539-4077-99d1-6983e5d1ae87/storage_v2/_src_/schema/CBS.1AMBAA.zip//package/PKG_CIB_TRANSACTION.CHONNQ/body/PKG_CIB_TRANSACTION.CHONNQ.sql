create PACKAGE BODY     "PKG_CIB_TRANSACTION" IS




---functions called from fmx

PROCEDURE Populate_Customer_Info ( pn_musteri_no IN CBS_MUSTERI.MUSTERI_NO%TYPE,
                                                                    pc_ref OUT RefCursorType)
IS
        lc_musteri_tipi VARCHAR2(1);
begin
    
 lc_musteri_tipi := PKG_MUSTERI.SF_MUSTERI_TIPI_AL(pn_musteri_no);
 
 if lc_musteri_tipi in ('1', '2') then
      OPEN pc_ref FOR
      select  CBS_MUSTERI_TIPI_KODLARI.MUSTERI_TIPI,
                CBS_MUSTERI_TIPI_KODLARI.ACIKLAMA,
                REPLACE(TRIM(ISIM), ' ', '_'), --cq614 ErkinZu 27042017 if ISIM or SOYADI consists of two words 
                REPLACE(TRIM(SOYADI), ' ', '_'), --like Ivan Uulu then it is converted to Ivan_Uulu
                cib_sex.cib_code sex_code_cib,
                cib_sex.cib_name sex_name_cib,     
                dogum_tarihi,  
                id doc_type_cib,  
                country_name || ' - ' || document_name doc_name_cib,
                decode(kimlik_kod, 1, nufus_cuzdani_seri_no, 2, ehliyet_belge_no, 3, pasaport_no, null) doc_no,           
                vergi_no TAX_NO
    from 
    cbs_musteri
    left join 
    cbs_cib_dir_document on uyruk_kod = cbs_uyruk_kod and kimlik_kod = cbs_kimlik_kod 
    left join
    cbs_kimlik_kodlari on kimlik_kod = kimlik_tipi
    left join
    cbs_cib_dir_sex cib_sex on cinsiyet_kod = cbs_code 
    left join 
    CBS_MUSTERI_TIPI_KODLARI on CBS_MUSTERI.MUSTERI_TIPI_KOD = CBS_MUSTERI_TIPI_KODLARI.MUSTERI_TIPI
    WHERE MUSTERI_NO =  pn_musteri_no and DURUM_KODU = 'A';
    
    else
    
       OPEN pc_ref FOR
       SELECT     T.MUSTERI_TIPI,
                        T.ACIKLAMA,
                        replace(replace(upper(m.ticari_unvan), upper(O.DESCRIPTION)), '  ', ' '), --m.ticari_unvan cust_name, 
                        C.code country_code,
                        C.DESCRIPTION country_name,                         
                        m.vergi_no INN,
                        O.CODE,
                        O.DESCRIPTION
            FROM cbs_musteri M
            LEFT JOIN 
            CBS_CIB_DIR_COUNTRY C ON M.UYRUK_KOD = C.cbs_uyruk_kod
            Left join 
            CBS_MUSTERI_TIPI_KODLARI T on M.MUSTERI_TIPI_KOD = T.MUSTERI_TIPI
            left join 
            CBS_CIB_DIR_ORGFORM O on M.LEGAL_FORM_CODE = O.CBS_LEGAL_FORM_CODE
            where MUSTERI_NO =  pn_musteri_no and DURUM_KODU = 'A';
            
            
 end if;
 

  EXCEPTION 
        WHEN OTHERS THEN
        Log_At('Populate_Customer_Info',SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  
        OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;

end;                                                                    
    
-- begin - Helper methods for getting loan parameters
FUNCTION Get_Loan_Unpaid_Amount(pn_app_no NUMBER, pd_date DATE) RETURN NUMBER IS
    ln_total_unpaid_amount NUMBER := 0;
    ln_unpaid_amount NUMBER := 0;
    ln_total_undpaid_pastdues NUMBER := 0;
    
    CURSOR cursor_loans IS 
            SELECT HESAP_NO, DOVIZ_KODU
            FROM CBS_HESAP_KREDI
            WHERE APP_NO=pn_app_no;
BEGIN
    
    FOR rw_loan IN cursor_loans
    LOOP                 
        --calculate sum of all loans' (tranches') unpaid amounts on the date pd_date  
        ln_unpaid_amount :=  ABS(pkg_kur.yuvarla ( rw_loan.DOVIZ_KODU, pkg_kredi_rapor.sf_valbakiye_al (rw_loan.HESAP_NO, pd_date)));                 
        ln_total_unpaid_amount := ln_total_unpaid_amount + ln_unpaid_amount;
    END LOOP;
    
    --calculate sum of all loans' (tranches') pastdue amounts on the date pd_date  
    ln_total_undpaid_pastdues := pkg_cib_transaction.Get_Loan_Pastdue_Amount(pn_app_no, pd_date);
    
    RETURN ln_total_unpaid_amount + ln_total_undpaid_pastdues;
END;

FUNCTION Get_Loan_Pastdue_Amount(pn_app_no NUMBER, pd_date DATE) RETURN NUMBER IS
    ln_total_unpaid_pastdues NUMBER := 0;
    ln_unpaid_pastdue NUMBER := 0;
    
    CURSOR cursor_loans IS 
            SELECT HESAP_NO, DOVIZ_KODU
            FROM CBS_HESAP_KREDI
            WHERE APP_NO=pn_app_no;
BEGIN
    
    FOR rw_loan IN cursor_loans
    LOOP                        
        --calculate total of all active pastdues on the date pd_date
        SELECT nvl(sum(decode(durum_kodu, 'A', nvl(tutar, 0), 0)), 0) into ln_unpaid_pastdue
        FROM CBS_HESAP_KREDI A 
        WHERE   A.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' 
                  AND A.ANA_KREDI_HESAP_NO = rw_loan.HESAP_NO 
                  AND acilis_tarihi <= pd_date;
                  
         ln_total_unpaid_pastdues := ln_total_unpaid_pastdues + ln_unpaid_pastdue;
    END LOOP;
       
    RETURN ln_total_unpaid_pastdues;
END;

FUNCTION Get_Loan_Pastdue_Days_Count(pn_app_no NUMBER, pd_date DATE) RETURN NUMBER
IS
    ln_total_pastdue_days NUMBER := 0;
    ln_pastdue_days NUMBER := 0;
    
    CURSOR cursor_loans IS 
        SELECT HESAP_NO, DOVIZ_KODU
        FROM CBS_HESAP_KREDI
        WHERE APP_NO=pn_app_no;
BEGIN

    FOR rw_loan IN cursor_loans
    LOOP       
        SELECT nvl(sum(decode(DURUM_KODU, 'A', NVL(pd_date - ACILIS_TARIHI + 1, 0), NVL((case when KAPANIS_TARIHI <= pd_date then KAPANIS_TARIHI else pd_date end) - ACILIS_TARIHI + 1, 0))), 0) 
            INTO ln_pastdue_days
        FROM CBS_HESAP_KREDI A 
        WHERE A.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' 
                    AND A.ANA_KREDI_HESAP_NO = rw_loan.HESAP_NO 
                    AND acilis_tarihi <= pd_date;
         
        ln_total_pastdue_days := ln_total_pastdue_days + ln_pastdue_days;       
    END LOOP;    
    
    RETURN ln_total_pastdue_days;
END;

FUNCTION Get_Loan_Repayment_Status(pn_app_no NUMBER, pd_date DATE) RETURN VARCHAR2
  IS
    ln_total_pastdue_days NUMBER := 0;
    ls_repayment_status VARCHAR2(3);
 BEGIN
    
    ln_total_pastdue_days := pkg_cib_transaction.Get_Loan_Pastdue_Days_Count(pn_app_no, pd_date);
    
     if nvl(ln_total_pastdue_days, 0) = 0 then
        ls_repayment_status := '1'; --Џлатежи по графику
       elsif ln_total_pastdue_days < 30 then --до 30 дней просрочки
        ls_repayment_status := '10'; --до 30 дней
       elsif ln_total_pastdue_days < 60 then
        ls_repayment_status := '2'; --30 дней до 59 дней просрочки
       elsif ln_total_pastdue_days < 90 then
        ls_repayment_status := '3';  --60 дней до 89 дней просрочки
       elsif ln_total_pastdue_days < 120 then
        ls_repayment_status := '4';  --90 дней  до 119 дней просрочки
        else
        ls_repayment_status := '5'; --120 дней просрочки и более
       end if;
       
    RETURN ls_repayment_status;
END;

FUNCTION Get_Loan_Repayment_Order(pn_app_no NUMBER, pn_acc_no NUMBER, pd_date DATE, pn_order NUMBER, pc_ref OUT RefCursorType) RETURN NUMBER
 IS    
    CURSOR cursor_repayments IS 
          SELECT *
          FROM CBS_HESAP_KREDI_TAKSIT
          WHERE HESAP_NO in (SELECT HESAP_NO
                                                 FROM CBS_HESAP_KREDI
                                                 WHERE APP_NO = pn_app_no)
          ORDER BY VADE_TARIH, HESAP_NO;
          
     ln_repayment_order NUMBER := 0;
     ln_count NUMBER := 0;
 BEGIN
    
   FOR rw_repayment IN cursor_repayments
    LOOP       
         ln_repayment_order := ln_repayment_order + 1;
         IF rw_repayment.HESAP_NO = pn_acc_no AND rw_repayment.ODEME_TARIHI = pd_date  THEN
            ln_count := ln_count + 1;
            IF ln_count = pn_order THEN
                OPEN pc_ref FOR SELECT ln_repayment_order, rw_repayment.ANAPARA FROM DUAL;
                RETURN ln_repayment_order;
             END IF;
         END IF;
    END LOOP;    
    
    RETURN -1;
    --RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8023' ||  Pkg_Hata.getdelimiter|| 'Pkg_Cib_Transaction.Get_Loan_Repayment_Order' || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;

FUNCTION Get_Loan_Repayment_Amount(pn_acc_no NUMBER, pd_date DATE) RETURN NUMBER
IS           
     ln_repayment_amount NUMBER := 0;
BEGIN
    
    SELECT ANAPARA INTO ln_repayment_amount
    FROM CBS_HESAP_KREDI_TAKSIT
    WHERE HESAP_NO=pn_acc_no AND ODEME_TARIHI=pd_date;
    
    RETURN ln_repayment_amount;
END;

FUNCTION Get_Loan_Repayments_Count(pn_app_no NUMBER) RETURN NUMBER
IS
    ln_payout_count NUMBER := 0;
BEGIN
             
    SELECT COUNT(VADE_TARIH) INTO ln_payout_count
    FROM CBS_HESAP_KREDI_TAKSIT
    WHERE hesap_no in (SELECT HESAP_NO 
                                         FROM CBS_HESAP_KREDI
                                         WHERE APP_NO = pn_app_no);

    RETURN ln_payout_count;                                             
END;
                                             
-- end - Helper methods for getting loan parameters
  

-------------------------GENERAL FUNCTIONS----------------------------------------------

 FUNCTION Get_Module_Type RETURN VARCHAR2 
  IS
  BEGIN
  
    RETURN 'LOAN';
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
  END;
  
  FUNCTION Get_Product_Type RETURN VARCHAR2
   IS
  BEGIN
  
    RETURN 'APPLICAT.';
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
  END;
  
  FUNCTION Get_Product_Class(pn_customer_type CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2
  IS
  BEGIN
  
    CASE
        WHEN pn_customer_type = '1' THEN RETURN 'RETAIL';
        WHEN pn_customer_type = '2' THEN RETURN 'SME';
        WHEN pn_customer_type = '3' THEN RETURN 'CORPORATE';
        WHEN pn_customer_type = '4' THEN RETURN 'BANK';
        ELSE RETURN 'No Such Product Class';
    END CASE;
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
  END;
  
  FUNCTION Get_Credit_Card_Type_Id RETURN NUMBER
  IS
  BEGIN
    RETURN 9;
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;
  
  FUNCTION Get_LG_Type_Id RETURN NUMBER
  IS
  BEGIN
    RETURN 16;
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;  
  
  FUNCTION Get_LC_Type_Id RETURN NUMBER
  IS
  BEGIN
    RETURN 17;
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;  
  
   FUNCTION Get_Overdraft_Type_Id RETURN NUMBER  --chyngyzo cq5027 18.11.2015
   IS
   BEGIN
    RETURN 4;
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;
  
   FUNCTION Get_CreditLine_Type_Id RETURN NUMBER  --chyngyzo cq5027 18.11.2015
    IS
   BEGIN
    RETURN 2;
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;
  
  FUNCTION Is_Loan_Closed(pn_app_no NUMBER) RETURN NUMBER
  IS
    ln_count NUMBER := 0;
  BEGIN
  
    select count(*) into ln_count 
    from cbs_cib_loan_application
    where app_no=pn_app_no and status='4-0';
    
    return ln_count;
    
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
  END;
  
  FUNCTION Is_Loan_Approved(pn_app_no NUMBER) RETURN NUMBER
    IS
    ln_count NUMBER := 0;
  BEGIN
  
    select count(*) into ln_count 
    from cbs_cib_loan_application
    where app_no=pn_app_no and status='2-0';
    
    return ln_count;
    
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
  END;
  
  FUNCTION Is_Loan_Account_Opened(pn_app_no NUMBER) RETURN NUMBER
      IS
    ln_count_regular NUMBER := 0;
    ln_count_overdraft NUMBER := 0;
    ln_count_lg NUMBER :=0;
    ln_count_lc NUMBER :=0;
    ln_count_credit_card NUMBER := 0;
    
  BEGIN
  
    select count(*) into ln_count_regular
    from cbs_hesap_kredi
    where app_no=pn_app_no and durum_kodu<>'I';
    
    SELECT count(*) into ln_count_overdraft
    FROM cbs_hesap_g_basvuru a 
         join CBS_ISLEM b on A.TX_NO = b.numara
    WHERE a.app_no = pn_app_no  AND b.durum in ('P', 'N', 'C', 'V', '1') 
        AND b.ISLEM_KOD=2007 
        AND A.OVERDRAFT='E'; 
                
   SELECT count(*) into ln_count_credit_card
    FROM CBS_HESAP_KREDI a 
         join CBS_KART_MUSTERI_LIMIT_ISLEM b on a.app_no = b.app_no
         join CBS_ISLEM c on b.tx_no = c.numara
    where a.app_no = pn_app_no  AND c.durum in ('P', 'N', 'C', 'V', '1')  
        AND C.ISLEM_KOD IN (7055, 7056) ;
            
    SELECT count(*) into ln_count_lg
    FROM CBS_TM_HG_ACILIS a 
         join CBS_TM_HG_ACILIS_ISLEM b on  a.REFERANS = B.REFERANS
         join CBS_ISLEM c on b.tx_no = c.numara
    where a.app_no = pn_app_no  AND c.durum in ('P', 'N', 'C', 'V', '1') 
        AND C.ISLEM_KOD IN (4100, 4101); --L/G opening, modification

    SELECT count(*) into ln_count_lc
    FROM CBS_ITH_AKREDITIF a 
         join CBS_ITH_AKREDITIF_ISLEM b on a.REFERANS = b.REFERANS
         join CBS_ISLEM c on b.tx_no = c.numara
    WHERE a.app_no = pn_app_no   AND c.durum in ('P', 'N', 'C', 'V', '1')
        AND C.ISLEM_KOD IN (3215, 3216); --IMPORT L/C OPENING;
    
    return ln_count_regular + ln_count_overdraft + ln_count_credit_card + ln_count_lg + ln_count_lc;
    
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
  END;
  
  FUNCTION Is_Regular_Credit(pn_credit_type CBS_CIB_DIR_CREDIT_TYPE.CODE%TYPE) RETURN NUMBER
  IS
  BEGIN
    IF pn_credit_type not in (4, 9, 16, 17) then --chyngyzo cq5027 4-overdraft is added 18.11.2015
        RETURN 1;
    ELSE
        RETURN 0;
    END IF;
    
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
  END;  
  
  FUNCTION Get_Credit_Status_Name(ps_credit_status CBS_CIB_DIR_CREDIT_STATUS.CODE%TYPE) RETURN VARCHAR2
  IS
    ls_name CBS_CIB_DIR_CREDIT_STATUS.DESCRIPTION%TYPE;
  BEGIN
     SELECT description INTO ls_name FROM CBS_CIB_DIR_CREDIT_STATUS WHERE CODE = ps_credit_status;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
  END;
  
  
  FUNCTION Get_Loan_Type_Name(pn_loan_type_code CBS_CIB_DIR_CREDIT_TYPE.CODE%TYPE) RETURN VARCHAR2 IS
    ls_name CBS_CIB_DIR_CREDIT_TYPE.DESCRIPTION%TYPE;
 BEGIN
    
    SELECT description INTO ls_name FROM CBS_CIB_DIR_CREDIT_TYPE WHERE CODE = pn_loan_type_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
 FUNCTION Get_Guarantor_Status_Name(ps_status_code CBS_CIB_DIR_GUARANT_STATUS.CODE%TYPE) RETURN VARCHAR2 IS
     ls_name CBS_CIB_DIR_GUARANT_STATUS.DESCRIPTION%TYPE;
 BEGIN
    
    SELECT description INTO ls_name FROM CBS_CIB_DIR_GUARANT_STATUS WHERE CODE = ps_status_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
 FUNCTION Get_Document_Type_Name(pn_document_type_id CBS_CIB_DIR_DOCUMENT.ID%TYPE) RETURN VARCHAR2 IS
    ls_name CBS_CIB_DIR_DOCUMENT.DOCUMENT_NAME%TYPE;
 BEGIN
    
    SELECT DOCUMENT_NAME INTO ls_name FROM CBS_CIB_DIR_DOCUMENT WHERE ID = pn_document_type_id;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
  
 FUNCTION  Get_Sex_Name(ps_sex_code CBS_CIB_DIR_SEX.CIB_CODE%TYPE) RETURN VARCHAR2 IS
    ls_name  CBS_CIB_DIR_SEX.CIB_NAME%TYPE;
 BEGIN
    
    SELECT CIB_NAME INTO ls_name FROM CBS_CIB_DIR_SEX WHERE CIB_CODE = ps_sex_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
 
 FUNCTION Get_Org_Form_Name(pn_orgform_code CBS_CIB_DIR_ORGFORM.CODE%TYPE) RETURN VARCHAR2  IS
    ls_name  CBS_CIB_DIR_ORGFORM.DESCRIPTION%TYPE;
 BEGIN
    
    SELECT DESCRIPTION INTO ls_name FROM CBS_CIB_DIR_ORGFORM WHERE CODE = pn_orgform_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
 FUNCTION Get_Country_Name(ps_country_code CBS_CIB_DIR_COUNTRY.CODE%TYPE) RETURN VARCHAR2 IS
     ls_name CBS_CIB_DIR_COUNTRY.DESCRIPTION%TYPE;
 BEGIN
    
    SELECT DESCRIPTION INTO ls_name FROM CBS_CIB_DIR_COUNTRY WHERE CODE = ps_country_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;
 
  FUNCTION Get_Guarantee_Type_Name(ps_guarantee_code CBS_CIB_DIR_GUARANTEE_TYPE.CODE%TYPE) RETURN VARCHAR2 IS
     ls_name CBS_CIB_DIR_GUARANTEE_TYPE.DESCRIPTION%TYPE;
 BEGIN
    
    SELECT DESCRIPTION INTO ls_name FROM CBS_CIB_DIR_GUARANTEE_TYPE WHERE CODE = ps_guarantee_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
 END;

--return existence of error (if non-cyrillic chars exists return true, and false otherwise)
FUNCTION Check_For_Non_Cyrillic_Chars(ps_input VARCHAR2, ps_error_msg OUT VARCHAR2) RETURN BOOLEAN 
IS
BEGIN
    
    if LENGTH(TRIM(TRANSLATE(ps_input, 'АаБбВвГгДдЕеЁёЖжЗзИиЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЪъЫыЬьЭэЮюЯя0123456789-+()!,.''''"@:;&#?_', '  '))) is not null then
        
        ps_error_msg := 'Only cyrillic letters are allowed!';
        return TRUE;
    end if;

return FALSE;
END;

--return existence of error (if length does not satisify CIB specifications return true, and false otherwise)
FUNCTION Check_Document_Length(pn_document_type NUMBER, ps_document_no VARCHAR2, ps_error_msg OUT VARCHAR2) RETURN BOOLEAN
IS
  ln_max NUMBER;
  ln_min NUMBER;
BEGIN
    SELECT MIN_LEN, MAX_LEN INTO ln_min, ln_max
    FROM CBS_CIB_DIR_DOCUMENT
    WHERE ID = pn_document_type;
    
    IF LENGTH(trim(ps_document_no)) >= ln_min AND LENGTH(trim(ps_document_no)) <= ln_max THEN
        return FALSE;
    END IF;
    
    ps_error_msg := 'Document No should be between ' || ln_min || ' and ' || ln_max;
     
    return TRUE;
END;

FUNCTION Check_Document_Pattern(pn_document_type NUMBER, ps_document_no VARCHAR2, ps_error_msg OUT VARCHAR2) RETURN BOOLEAN
IS
--this function checks Document no against pattern AN1234567.
--the only document type which is checked against pattern is 8 as CIB's programmer informed
--other documents are checked only for length
--ErkinZ, 15012018, defect5988
BEGIN
if(pn_document_type = 8) then
    if regexp_like(ps_document_no,'AN\d{7}\Z') then
        return false;
    else
        ps_error_msg := 'Пластиковый паспорт КР должен начинаться с символов AN';
        return true;
    end if;            
else
    return false;
end if;        

END;

FUNCTION CHECK_INN(ps_inn VARCHAR2, ps_countrycode VARCHAR2, ps_error_msg OUT VARCHAR2) RETURN BOOLEAN
IS
    ld_date DATE;
    ls_inn VARCHAR2(20) := TRIM(ps_inn);
BEGIN

    IF LOWER(TRIM(ps_countrycode)) = 'kgz'  THEN
        
        --check length
         IF LENGTH(ls_inn) <> 14 THEN
            ps_error_msg := 'INN length must be 14!';
            RETURN TRUE;      
         END IF;
         
        --check company registration date validity contained in INN
        BEGIN
            ld_date := TO_DATE( SUBSTR(ls_inn, 2, 2) ||'/'||SUBSTR(ls_inn, 4, 2)||'/'||SUBSTR(ls_inn, 6, 4), 'DD/MM/YYYY') ;
        EXCEPTION
            WHEN OTHERS THEN
             --not a valid date
             ps_error_msg := 'INN is invalid! (INN contains invalid date)';
             RETURN TRUE;  
        END;
        --company registration date cannot be earlier than 01/01/1900 and later than current date
        IF ld_date < TO_DATE('01/01/1900', 'DD/MM/YYYY') OR ld_date > TRUNC(SYSDATE) THEN
            ps_error_msg := 'INN is invalid! (INN contains invalid date)';
            RETURN TRUE;  
        END IF;







    END IF;
    
    IF LOWER(TRIM(ps_countrycode)) <> 'kgz' AND LENGTH(TRIM(ps_inn)) <> 10 THEN
     ps_error_msg := 'INN length must be 10!';   
     RETURN TRUE;     
    END IF;
        
    RETURN FALSE;
END;

FUNCTION Check_INN_comp(ps_inn VARCHAR2, ps_countrycode VARCHAR2, ps_error_msg OUT VARCHAR2) RETURN BOOLEAN
IS
ls_inn VARCHAR2(20) := TRIM(ps_inn);
BEGIN
    IF LOWER(TRIM(ps_countrycode)) = 'kgz'  THEN
        --for companies INN's first character should be either 0 (zero) or 4 (four)
        IF SUBSTR(ls_inn, 1, 1) NOT IN ('0', '4') THEN
            ps_error_msg := 'INN is invalid! (For companies INN''s first character should be either 0 or 4)';
            RETURN TRUE;  
        END IF;
    END IF;
    
    IF LOWER(TRIM(ps_countrycode)) <> 'kgz' AND LENGTH(ls_inn) <> 10 THEN
        ps_error_msg := 'INN length must be 10!';   
        RETURN TRUE;     
    END IF;
    
    RETURN FALSE;
END;

PROCEDURE Check_Customer(pn_customer_no NUMBER, pn_app_no NUMBER, pn_tx_no NUMBER DEFAULT NULL) IS
    ln_customer NUMBER; 
    ln_is_creditline NUMBER := 0;
    ln_tx_no   NUMBER  := 0;
    ln_acc_no NUMBER := 0;
    
    waiting_transaction_exists EXCEPTION;
    loan_account_exists EXCEPTION;
    
BEGIN

    select count(*) into ln_is_creditline 
    from cbs_cib_loan_application
    where app_no=pn_app_no and loan_type=PKG_CIB_TRANSACTION.GET_CREDITLINE_TYPE_ID;
    
    --check if waiting transaction exists that uses this app no
    SELECT MAX(i.tx_no) INTO ln_tx_no
    FROM  cbs_hesap_kredi_islem i
    WHERE i.tx_no <> pn_tx_no AND i.app_no = pn_app_no AND pkg_tx.islem_bitmis_mi(i.tx_no)= 0;  
          
    if nvl(ln_tx_no,0) <> 0 and nvl(ln_is_creditline, 0) = 0 then --credit line app no can be used more than once
        RAISE waiting_transaction_exists;
    end if;
    
    --check if loan was already opened with this app no
    SELECT MAX(hesap_no) INTO ln_acc_no
    FROM CBS_HESAP_KREDI
    WHERE app_no = pn_app_no;
    
    if nvl(ln_acc_no,0) <> 0 and nvl(ln_is_creditline, 0) = 0 then --credit line app no can be used more than once
        RAISE loan_account_exists;
    end if;
    
    SELECT T.CUST_NO INTO LN_CUSTOMER 
    FROM CBS_CIB_LOAN_APPLICATION T 
    WHERE T.APP_NO = PN_APP_NO AND T.CUST_NO = PN_CUSTOMER_NO;
     
EXCEPTION
    WHEN waiting_transaction_exists THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8024' ||  Pkg_Hata.getdelimiter||'App.No= '||pn_app_no||', Tx.No= '||ln_tx_no || Pkg_Hata.getUCPOINTER);
    WHEN loan_account_exists THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8025' ||  Pkg_Hata.getdelimiter||'App.No= '||pn_app_no||', Acc.No= '||ln_acc_no || Pkg_Hata.getUCPOINTER);        
    WHEN OTHERS THEN
       -- RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8008' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
       NULL;
END;


FUNCTION Get_Loan_App_No(pn_loan_acc_no CBS_HESAP_KREDI.HESAP_NO%TYPE) RETURN CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE
IS
    ln_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE;
BEGIN
    
    SELECT APP_NO into ln_app_no from CBS_HESAP_KREDI where hesap_no = pn_loan_acc_no;
    
    return ln_app_no;
    
    EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
------------------------------------------------------------------------------------------------
PROCEDURE AddRequestLog(ps_request_name IN VARCHAR2,
                        pc_request_body IN CLOB,
                        ps_response_body IN VARCHAR2) is
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    insert into CBS_CIB_WS_LOG (LOG_NO, REQUEST_NAME,  REQUEST_BODY, RESPONSE_BODY)
    values (cib_log_seq.NEXTVAL, ps_request_name, substr(pc_request_body, 1, 4000), substr(ps_response_body, 1, 4000));

    COMMIT;
END;

PROCEDURE AddToSendingList(P_TX_NO CBS_CIB_LOAN_TRANSACTIONS.TX_NO%TYPE, P_TX_CODE CBS_CIB_LOAN_TRANSACTIONS.TX_CODE%TYPE, P_APP_NO CBS_CIB_LOAN_TRANSACTIONS.APP_NO%TYPE, P_LOAN_ACC_NO CBS_CIB_LOAN_TRANSACTIONS.LOAN_ACC_NO%TYPE) is
begin

    insert into CBS_CIB_LOAN_TRANSACTIONS(TX_NO, TX_CODE, APP_NO, LOAN_ACC_NO)
    values(P_TX_NO, P_TX_CODE, P_APP_NO, P_LOAN_ACC_NO);
    
    EXCEPTION
        WHEN OTHERS THEN
           AddRequestLog('AddToSendingList', SQLERRM,  P_TX_NO || ', ' || P_TX_CODE || ', ' || P_APP_NO || ', ' || P_LOAN_ACC_NO);
end;



PROCEDURE AddCredit(ps_loan_acc_no IN CBS_HESAP_KREDI.hesap_no%TYPE ) IS
    lrow_loan_acc CBS_HESAP_KREDI%ROWTYPE;
    lrow_loan_proposal CBS_KREDI_TEKLIF%ROWTYPE;
    
    branch_code CBS_HESAP_KREDI.SUBE_KODU%TYPE;
    amount CBS_KREDI_TEKLIF_SATIR.ONERILEN_LIMIT_YP%TYPE;
    date_award CBS_HESAP_KREDI.ACILIS_TARIHI%TYPE;
    date_stop CBS_HESAP_KREDI.KAPANIS_TARIHI%TYPE;
    
BEGIN
    
    select * into lrow_loan_acc from cbs_hesap_kredi where hesap_no = ps_loan_acc_no;
    
    dbms_output.put_line(lrow_loan_acc.tutar);

    

END;
  
----***********************UPDATE METHODS*****************************
PROCEDURE SEND_UPDATES_TO_CIB(pd_date DATE) IS

        ld_bank_date DATE;
        
        CURSOR c_applications(pd_date DATE)
        IS
             SELECT 'APPLICATION' TX_NAME, c.NUMARA TX_NO, c.ISLEM_KOD TX_CODE, A.APP_NO, A.AMOUNT L_AMOUNT, A.CURRENCY L_CURRENCY, NVL (c.onay_tarih,c.kayit_tarih)  tx_time
                    FROM CBS_CIB_LOAN_APPLICATION_TX a, CBS_ISLEM c
                    WHERE A.LOAN_TYPE in (7) and --cq614, ErkinZu, 25.05.2017, send only consumer credit apps (code 7)
                    A.TX_NO = C.NUMARA and C.DURUM = 'P' and  NVL (c.onay_tarih,c.kayit_tarih) = pd_date
                        --AND A.TX_TYPE IN (1330, 1331) --new applications / modifications
                        AND A.TX_TYPE IN (1331) --send only those modified/approved in 1331 
--                        AND NOT EXISTS (SELECT 1 FROM CBS_CIB_LOAN_TRANSACTIONS WHERE TX_CODE IN (1330, 1331) AND TX_NO = A.TX_NO)
                          AND NOT EXISTS (SELECT 1 FROM CBS_CIB_LOAN_TRANSACTIONS WHERE TX_CODE IN (1331) AND TX_NO = A.TX_NO)
        UNION
              SELECT TX_NAME, TX_NO, TX_CODE, APP_NO, NULL L_AMOUNT, NULL L_CURRENCY,  tx_time
                    FROM CBS_CIB_LOAN_TRANSACTIONS
--                    WHERE TX_CODE IN (1330, 1331) and sent = 'N'
                      WHERE TX_CODE IN (1331) and sent = 'N' 
        ORDER BY TX_TIME, TX_NO DESC;
        
          rw_application c_applications%ROWTYPE;
                 
    CURSOR c_updates(pn_date DATE)
    IS
        SELECT 'DISBURSEMENT' TX_NAME,
                    c.NUMARA TX_NO, c.ISLEM_KOD TX_CODE, a.APP_NO, b.HESAP_NO LOAN_ACC_NO, NVL (c.onay_tarih,c.kayit_tarih)  tx_time 
        FROM CBS_HESAP_KREDI a, CBS_HESAP_KREDI_ISLEM b, CBS_ISLEM c
        WHERE  a.hesap_no = b.hesap_no AND a.DURUM_KODU <> 'I'  AND b.tx_no = c.numara AND c.durum in ('P', 'N')  and  a.APP_NO is not null and  NVL (c.onay_tarih,c.kayit_tarih) = pn_date
                and 
                (
                  --b.ISLEM_TANIM_KOD in (3250) and b.URUN_TUR_KOD in ('RT-FIXRATE', 'RT-VRRATE', 'COMMERCIAL', 'MORTGAGE', 'R.EST.CON.') --disbursement
                  b.ISLEM_TANIM_KOD in (3250) and b.URUN_TUR_KOD in ('RT-FIXRATE', 'RT-VRRATE') --cq614, ErkinZu, 25.05.2017, send only consumer loan disbursements
                )  

                  AND NOT EXISTS (SELECT 1 FROM CBS_CIB_LOAN_TRANSACTIONS LT  WHERE LT.APP_NO = A.APP_NO AND LT.TX_NO = C.NUMARA)   
    UNION
           SELECT 'REJECTION' TX_NAME, c.NUMARA TX_NO, c.ISLEM_KOD TX_CODE, A.APP_NO, NULL LOAN_ACC_NO, NVL (c.onay_tarih,c.kayit_tarih)  tx_time 
            FROM CBS_CIB_LOAN_APPLICATION_TX a, CBS_ISLEM c
            WHERE A.LOAN_TYPE in (7) and --cq614, ErkinZu, 25.05.2017, send only consumer credit app rejects (code 7)
            A.TX_NO = C.NUMARA and C.DURUM = 'P' and  NVL (c.onay_tarih,c.kayit_tarih) = pn_date
                AND A.TX_TYPE = 1332 and a.status <> '2-0' --application rejections    
                AND NOT EXISTS (SELECT 1 FROM CBS_CIB_LOAN_TRANSACTIONS LT  WHERE LT.APP_NO = A.APP_NO AND LT.TX_NO = C.NUMARA )     
    UNION          
        SELECT A.TX_NAME, A.TX_NO, A.TX_CODE, A.APP_NO, A.LOAN_ACC_NO, A.tx_time
        FROM CBS_CIB_LOAN_TRANSACTIONS a --not sent transactions
        /*WHERE A.SENT = 'N' and (TX_CODE IS NULL OR TX_CODE NOT IN (1330, 1331))*/ --TX_CODE is null for loan closing
        WHERE A.SENT = 'N' and TX_CODE IN (1332, 3250) --ErkinZu cq614 25.04.2017, send only non-sent results from 1332, 3250
        ORDER BY tx_time, tx_no
        NULLS LAST;
       
    rw_update c_updates%ROWTYPE;

   -- type app_no_list is varray (6) of CBS_CIB_LOAN_APPLICATION.APP_NO%type;
   TYPE app_no_list IS TABLE OF CBS_CIB_LOAN_APPLICATION.APP_NO%type;
    failed_to_send app_no_list := app_no_list();
    counter_f integer:=1;
    
    processed_apps app_no_list := app_no_list();
    counter_p integer:=1;
    
    lb_ret BOOLEAN;
    ls_sent VARCHAR2(1);
    ln_count NUMBER;
    ln_last_tx_no NUMBER;
    ln_last_tx_code NUMBER;
    
    ln_logging VARCHAR2(2000);
    ld_repayment_date DATE;
    ls_currency VARCHAR2(3);
    
BEGIN     
        -- GET BANK DATE, AND MAKE FOLLOWINGS ACCORDING TO THIS BANK DATE
        
        -- ld_bank_date := to_date('27.08.2009', 'dd.mm.yyyy');-- to_date('06.06.2011', 'dd.mm.yyyy'); -- to_date('10.12.2010', 'dd.mm.yyyy');--to_date('10.11.2010', 'dd.mm.yyyy') ;---- PKG_MUHASEBE.BANKA_TARIHI_BUL;
        
        dbms_output.put_line('**********************APPLICATION***********************');
        
       OPEN c_applications(pd_date);
       
       FETCH c_applications INTO rw_application;
       
       WHILE c_applications%FOUND 
       LOOP
         ln_logging := rw_application.TX_NAME||','|| rw_application.tx_code;
            
          IF rw_application.app_no member of processed_apps THEN    

            dbms_output.put_line(rw_application.tx_code || ' do not send, later tx was processed app_No = ' || rw_application.app_no || ', tx_no = ' || rw_application.tx_no);
            log_at('send_updates_to_cib_New_App_already_processed(not sent)', rw_application.app_no, rw_application.tx_code, rw_application.tx_no);
            
            lb_ret := false;
            ls_sent := 'X';
                      
          ELSE 

            dbms_output.put_line(rw_application.tx_code ||' send APPLICATION app_no = ' || rw_application.app_no ||', tx_no = '||rw_application.tx_no);
            log_at('send_updates_to_cib_New_App_should_be_sent', rw_application.app_no, rw_application.tx_code, rw_application.tx_no);


            lb_ret :=  PKG_CIB_TRANSACTION.Send_New_Application(rw_application.app_no);
            
            --! INSERT INTO CBS_CIB_LOAN_TRANSACTIONS with sent N or Y 
            IF lb_ret = true THEN
                dbms_output.put_line('Successfully sent!');
                log_at('send_updates_to_cib_New_App_processed(sent)', rw_application.app_no, rw_application.tx_code, rw_application.tx_no);
                ls_sent := 'Y';
            ELSE
                 failed_to_send.extend;
                 failed_to_send(counter_f)  := rw_application.app_no;
                 counter_f := counter_f + 1;
                        
                 dbms_output.put_line('Failed to send!');
                 log_at('send_updates_to_cib_New_App_not_sent', rw_application.app_no, rw_application.tx_code, rw_application.tx_no);
                 ls_sent := 'N';
            END IF;         
                        
          END IF;
          
            select count(*) into ln_count 
            from cbs_cib_loan_transactions 
            where tx_no = rw_application.tx_no;
                   
            
            IF ln_count = 0 THEN --was NOT sent before

                INSERT INTO CBS_CIB_LOAN_TRANSACTIONS(TX_NAME, TX_NO, TX_CODE, APP_NO, SENT, TX_TIME, UPDATE_DATE)
                VALUES(rw_application.TX_NAME, rw_application.tx_no, rw_application.tx_code, rw_application.APP_NO, ls_sent, rw_application.tx_time, SYSDATE);
                            
            ELSIF ln_count > 0 THEN --was sent before

                UPDATE CBS_CIB_LOAN_TRANSACTIONS 
                SET SENT = ls_sent, 
                       TX_NAME = rw_application.TX_NAME,
                       TX_CODE = rw_application.tx_code,
                       UPDATE_DATE = SYSDATE
                WHERE TX_NO = rw_application.tx_no;
                            
            END IF;
            
            processed_apps.extend;
            processed_apps(counter_p)  := rw_application.app_no;
            counter_p := counter_p + 1;
                        
            FETCH c_applications INTO rw_application;
       END LOOP;
             
       CLOSE c_applications;
                     
        dbms_output.put_line('**********************OTHER UPDATES***********************');
        
       OPEN c_updates(pd_date);
        
        FETCH c_updates INTO rw_update;
        
        WHILE c_updates%FOUND
        LOOP
            ln_logging := rw_update.TX_NAME||','|| rw_update.tx_code||','||rw_update.tx_no ||','||rw_update.LOAN_ACC_NO;

            DBMS_OUTPUT.PUT_LINE(ln_logging);
            
             IF rw_update.app_no member of failed_to_send THEN

                      dbms_output.put_line(rw_update.tx_code || ' do not send, previous tx failed to send  app_no = ' || rw_update.app_no || ', tx_no = ' || rw_update.tx_no);
                      log_at('send_updates_to_cib_Update_not_sent', rw_update.app_no, rw_update.tx_code, rw_update.tx_no);
                      
                      lb_ret := false;
                      ls_sent := 'N';                     
             ELSE
                      
                        CASE                               
                             WHEN  rw_update.tx_name = 'REJECTION'  THEN --rw_update.tx_code = 1332 and status <> '2-0' --------------------------------REJECTIONS----------------------------------------------                           
                                BEGIN
                                     dbms_output.put_line(rw_update.tx_code ||' send REJECTION app_no = ' || rw_update.app_no||', tx_no = '||rw_update.tx_no);
                                     log_at('send_updates_to_cib_Rejection_should_be_sent', rw_update.app_no, rw_update.tx_code, rw_update.tx_no);
                                     lb_ret :=  PKG_CIB_TRANSACTION.Send_Rejection(rw_update.app_no); 
                                END;
                                      

                            WHEN  rw_update.tx_name = 'DISBURSEMENT' THEN---rw_update.tx_code in (1303, 3250)-----------------------------DISBURSEMENTS----------------------------------------------
                                BEGIN

                                    dbms_output.put_line(rw_update.tx_code ||' send DISBURSEMENT app_no = ' || rw_update.app_no||', LOAN_ACC_NO = '||rw_update.LOAN_ACC_NO ||', tx_no = '||rw_update.tx_no);
                                    log_at('send_updates_to_cib_Disbursement_should_be_sent', rw_update.app_no, rw_update.tx_code, rw_update.tx_no);
                                    lb_ret := PKG_CIB_TRANSACTION.Send_Disbursement(rw_update.app_no, rw_update.LOAN_ACC_NO, rw_update.tx_no);

                                END;
 
                             ELSE 
                                 BEGIN
                                         dbms_output.put_line(rw_update.tx_code ||'NO SUCH TX_CODE ');
                                         log_at('No_such_code_for_update', rw_update.tx_code);
                                         lb_ret := false;
                                 END;
                             
                        END CASE;


                        --! INSERT INTO CBS_CIB_LOAN_TRANSACTIONS with sent N or Y 
                        IF lb_ret = true THEN
                            dbms_output.put_line('Successfully sent!');
                            log_at(rw_update.tx_name||'_successfully_sent', rw_update.app_no, rw_update.tx_code, rw_update.tx_no);
                            ls_sent := 'Y';
                        ELSE
                        
                             failed_to_send.extend;
                             failed_to_send(counter_f)  := rw_update.app_no;
                             counter_f := counter_f + 1;
                             
                             dbms_output.put_line('Failed to send!');
                             log_at(rw_update.tx_name||'_not_sent', rw_update.app_no, rw_update.tx_code, rw_update.tx_no);
                             ls_sent := 'N';
                        END IF;                     


             END IF;
                                 
                SELECT count(*) INTO ln_count 
                FROM CBS_CIB_LOAN_TRANSACTIONS 
                WHERE tx_no = rw_update.tx_no AND tx_name = rw_update.tx_name;
                        
                IF ln_count = 0 THEN --was NOT sent before

                    INSERT INTO CBS_CIB_LOAN_TRANSACTIONS(TX_NAME, TX_NO, TX_CODE, APP_NO, LOAN_ACC_NO, SENT, TX_TIME, UPDATE_DATE)
                    VALUES(rw_update.TX_NAME, rw_update.tx_no, rw_update.tx_code, rw_update.APP_NO, rw_update.LOAN_ACC_NO, ls_sent, rw_update.tx_time, SYSDATE);
                            
                ELSIF ln_count > 0 THEN --was sent before

                    UPDATE CBS_CIB_LOAN_TRANSACTIONS 
                    SET SENT = ls_sent, 
                           TX_NAME = rw_update.TX_NAME,
                           TX_CODE = rw_update.tx_code,
                           LOAN_ACC_NO = rw_update.LOAN_ACC_NO,
                           UPDATE_DATE = SYSDATE
                    WHERE TX_NO = rw_update.tx_no;
                            
                END IF;


            FETCH c_updates INTO rw_update;

        END LOOP;     

       COMMIT;
        
    EXCEPTION 
        WHEN OTHERS THEN
             AddRequestLog('SEND_UPDATES_TO_CIB',  ln_logging||' '||req.body, sqlerrm);
             COMMIT;
             DBMS_OUTPUT.PUT_LINE(sqlerrm);
END;
                              

PROCEDURE GenerateGuarantorsUL(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, 
                                                                                    l_guarantorsULName OUT VARCHAR2, 
                                                                                    l_guarantorsULOrgForm OUT VARCHAR2, 
                                                                                    l_guarantorsULCountry OUT VARCHAR2, 
                                                                                    l_guarantorsULInn OUT VARCHAR2, 
                                                                                    l_guarantorsULBdYear OUT VARCHAR2,  
                                                                                    l_guarantorsULBdMonth OUT VARCHAR2, 
                                                                                    l_guarantorsULBdDay OUT VARCHAR2) IS

  CURSOR c_guarantorUL  IS
                                select NAME, ORGFORM, COUNTRY, INN,  
                                            TO_NUMBER(to_char(REGISTRATION_DATE, 'YYYY')), 
                                            TO_NUMBER(to_char(REGISTRATION_DATE, 'MM')), 
                                            TO_NUMBER(to_char(REGISTRATION_DATE, 'DD'))
                                  from CBS_CIB_GUARANTORS_UL
                                  where app_no = pn_app_no;
                                  
    l_str1 VARCHAR2(100);
    l_str2 VARCHAR2(100);
    l_str3 VARCHAR2(100);
    l_str4 VARCHAR2(100);
    l_str5 VARCHAR2(100);
    l_str6 VARCHAR2(100);
    l_str7 VARCHAR2(100);
                                  
BEGIN
 
 open c_guarantorUL;
 
 fetch c_guarantorUL into l_str1, l_str2 , l_str3, l_str4, l_str5, l_str6, l_str7 ;
           
    while c_guarantorUL%FOUND
    loop
    
        l_guarantorsULName := l_guarantorsULName || l_str1;
        l_guarantorsULOrgForm := l_guarantorsULOrgForm || l_str2;
        l_guarantorsULCountry := l_guarantorsULCountry || l_str3;
        l_guarantorsULInn := l_guarantorsULInn || l_str4;
        l_guarantorsULBdYear := l_guarantorsULBdYear || l_str5;
        l_guarantorsULBdMonth := l_guarantorsULBdMonth || l_str6;
        l_guarantorsULBdDay := l_guarantorsULBdDay || l_str7;

        fetch c_guarantorUL into l_str1, l_str2 , l_str3, l_str4, l_str5, l_str6, l_str7 ;
          
        IF c_guarantorUL%FOUND THEN
            l_guarantorsULName := l_guarantorsULName || '[db]';
            l_guarantorsULOrgForm := l_guarantorsULOrgForm || '[db]';
            l_guarantorsULCountry := l_guarantorsULCountry || '[db]';
            l_guarantorsULInn := l_guarantorsULInn || '[db]';
            l_guarantorsULBdYear := l_guarantorsULBdYear || '[db]';
            l_guarantorsULBdMonth := l_guarantorsULBdMonth || '[db]';
            l_guarantorsULBdDay := l_guarantorsULBdDay || '[db]';
        END IF;
        
    end loop;
    
    close c_guarantorUL;
END;


PROCEDURE GenerateGuarantors(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE,
                                                                                    l_guarantorsFirstname OUT VARCHAR2, 
                                                                                    l_guarantorsLastname OUT VARCHAR2, 
                                                                                    l_guarantorsDocType OUT VARCHAR2, 
                                                                                    l_guarantorsDocNo OUT VARCHAR2, 
                                                                                    l_guarantorsSex OUT VARCHAR2,  
                                                                                    l_guarantorsStatus OUT VARCHAR2, 
                                                                                    l_guarantorsbdYear OUT VARCHAR2,
                                                                                    l_guarantorsbdMonth OUT VARCHAR2,
                                                                                    l_guarantorsbdDay OUT VARCHAR2,
                                                                                    l_guarantorsSocCode OUT VARCHAR2 --add guarantor's INN as mandatory for CIB, ErkinZ, 16012018, defect
                                                                                    ) IS

                             
  CURSOR c_guarantor  IS
                            select firstname, lastname, doc_type, 
                                        doc_no, sex, status, 
                                        TO_NUMBER(to_char(birthdate, 'YYYY')), 
                                        TO_NUMBER(to_char(birthdate, 'MM')), 
                                        TO_NUMBER(to_char(birthdate, 'DD')),
                                        p_inn --ErkinZ, defect
                              from CBS_CIB_GUARANTORS
                              where app_no = pn_app_no;
                                  
    l_str1 VARCHAR2(100);
    l_str2 VARCHAR2(100);
    l_str3 VARCHAR2(100);
    l_str4 VARCHAR2(100);
    l_str5 VARCHAR2(100);
    l_str6 VARCHAR2(100);
    l_str7 VARCHAR2(100);
    l_str8 VARCHAR2(100);
    l_str9 VARCHAR2(100);
    l_str10 VARCHAR2(100); --ErkinZ, defect
                                  
BEGIN
 
 open c_guarantor;
 
 fetch c_guarantor into l_str1, l_str2 , l_str3, l_str4, l_str5, l_str6, l_str7,  l_str8, l_str9, l_str10 ;
           
    while c_guarantor%FOUND
    loop
                                                                                        
        l_guarantorsFirstname := l_guarantorsFirstname || l_str1;
        l_guarantorsLastname := l_guarantorsLastname || l_str2;
        l_guarantorsDocType := l_guarantorsDocType || l_str3;
        l_guarantorsDocNo := l_guarantorsDocNo || l_str4;
        l_guarantorsSex := l_guarantorsSex || l_str5;
        l_guarantorsStatus := l_guarantorsStatus || l_str6;
        l_guarantorsbdYear := l_guarantorsbdYear || l_str7;
        l_guarantorsbdMonth := l_guarantorsbdMonth || l_str8;
        l_guarantorsbdDay := l_guarantorsbdDay || l_str9;
        l_guarantorsSocCode := l_guarantorsSocCode || l_str10; --ErkinZ, defect

        fetch c_guarantor into l_str1, l_str2 , l_str3, l_str4, l_str5, l_str6, l_str7,  l_str8, l_str9, l_str10  ;
          
        IF c_guarantor%FOUND THEN
         
            l_guarantorsFirstname := l_guarantorsFirstname ||  '[db]';
            l_guarantorsLastname := l_guarantorsLastname ||  '[db]';
            l_guarantorsDocType := l_guarantorsDocType ||  '[db]';
            l_guarantorsDocNo := l_guarantorsDocNo || '[db]';
            l_guarantorsSex := l_guarantorsSex ||  '[db]';
            l_guarantorsStatus := l_guarantorsStatus ||  '[db]';
            l_guarantorsbdYear := l_guarantorsbdYear ||  '[db]';
            l_guarantorsbdMonth := l_guarantorsbdMonth ||  '[db]';
            l_guarantorsbdDay := l_guarantorsbdDay ||  '[db]';
            l_guarantorsSocCode := l_guarantorsSocCode || '[db]'; --ErkinZ, defect
        
        END IF;
        
    end loop;
    
    close c_guarantor;
END;


PROCEDURE GenerateGuarantees(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, l_guaranteeListCodes OUT VARCHAR2) IS
    CURSOR c_guarantee is
            select GUARANTEE_TYPE
            from CBS_CIB_GUARANTEE
            where app_no = pn_app_no;
            
    l_str1 VARCHAR2(100);    
begin       
    
    OPEN c_guarantee;
    
    fetch c_guarantee into l_str1 ;
           
    while c_guarantee%FOUND
    loop
        l_guaranteeListCodes := l_guaranteeListCodes || l_str1;
        
        fetch c_guarantee into l_str1;
          
        IF c_guarantee%FOUND THEN
            l_guaranteeListCodes := l_guaranteeListCodes || '[db]';
        END IF;
        
    end loop;
    


    close c_guarantee;
end;


PROCEDURE AddRequiredParameters(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE) IS
     CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
          
    l_guarantorsFirstname VARCHAR2(32767);
    l_guarantorsLastname VARCHAR2(32767);
    l_guarantorsDocType VARCHAR2(32767);
    l_guarantorsDocNo VARCHAR2(32767);
    l_guarantorsSex VARCHAR2(32767);
    l_guarantorsStatus VARCHAR2(32767);
    l_guarantorsbdYear VARCHAR2(32767);
    l_guarantorsbdMonth VARCHAR2(32767);
    l_guarantorsbdDay VARCHAR2(32767);
    l_guarantorsSocCode VARCHAR2(32767);
    
    l_guarantorsULName VARCHAR2(32767);
    l_guarantorsULOrgForm VARCHAR2(32767);
    l_guarantorsULBdYear VARCHAR2(32767);
    l_guarantorsULBdMonth VARCHAR2(32767);
    l_guarantorsULBdDay VARCHAR2(32767);
    l_guarantorsULCountry VARCHAR2(32767);
    l_guarantorsULInn VARCHAR2(32767);
    
    l_guaranteeListCodes VARCHAR2(32767);
    
BEGIN
        OPEN c_app;
        
        FETCH c_app into l_app;
        
          Pkg_Soap.add_parameter(req, 'c_companyName', 'xsd:string',   l_app.company_name);
         Pkg_Soap.add_parameter(req, 'c_bdYear', 'xsd:int',  nvl(TO_NUMBER(to_char(l_app.company_bdate, 'YYYY')),1995));
         Pkg_Soap.add_parameter(req, 'c_bdMonth', 'xsd:int',   nvl(TO_NUMBER(to_char(l_app.company_bdate, 'MM')), 1));
         Pkg_Soap.add_parameter(req, 'c_bdDay', 'xsd:int',   nvl(TO_NUMBER(to_char(l_app.company_bdate, 'DD')),1 ));
         Pkg_Soap.add_parameter(req, 'c_inn', 'xsd:string',   l_app.company_inn);
         Pkg_Soap.add_parameter(req, 'c_orgForm', 'xsd:int',   nvl(l_app.company_orgform, 0));
         Pkg_Soap.add_parameter(req, 'c_country', 'xsd:string',   l_app.company_country);
        
         Pkg_Soap.add_parameter(req, 'p_firstname', 'xsd:string',   l_app.p_firstname);
         Pkg_Soap.add_parameter(req, 'p_lastname', 'xsd:string',   l_app.p_lastname);
         Pkg_Soap.add_parameter(req, 'p_sex', 'xsd:string',   l_app.p_sex);
         Pkg_Soap.add_parameter(req, 'p_bdYear', 'xsd:int',   nvl(TO_NUMBER(to_char(l_app.p_bdate, 'YYYY')), 1995));
         Pkg_Soap.add_parameter(req, 'p_bdMonth', 'xsd:int',   nvl( TO_NUMBER(to_char(l_app.p_bdate, 'MM')), 1));
         Pkg_Soap.add_parameter(req, 'p_bdDay', 'xsd:int',   nvl(TO_NUMBER(to_char(l_app.p_bdate, 'DD')), 1));
         Pkg_Soap.add_parameter(req, 'p_docType', 'xsd:int',   nvl(l_app.p_document_type, 0));
         Pkg_Soap.add_parameter(req, 'p_docNo', 'xsd:string',   l_app.p_document_no);
         Pkg_Soap.add_parameter(req, 'p_taxNo', 'xsd:string',   l_app.p_tax_no);
            
         GenerateGuarantors(pn_app_no, l_guarantorsFirstname,  l_guarantorsLastname,  
                              l_guarantorsDocType,  l_guarantorsDocNo,  l_guarantorsSex,  
                              l_guarantorsStatus,  l_guarantorsbdYear, 
                              l_guarantorsbdMonth,  l_guarantorsbdDay, 
                                l_guarantorsSocCode); --ErkinZ, 16012018, defect
         
         Pkg_Soap.add_parameter(req, 'guarantorsFirstname', 'xsd:string',   l_guarantorsFirstname);
         Pkg_Soap.add_parameter(req, 'guarantorsLastname', 'xsd:string',   l_guarantorsLastname);
         Pkg_Soap.add_parameter(req, 'guarantorsDocType', 'xsd:string',    l_guarantorsDocType);
         Pkg_Soap.add_parameter(req, 'guarantorsDocNo', 'xsd:string',   l_guarantorsDocNo);
         Pkg_Soap.add_parameter(req, 'guarantorsSex', 'xsd:string',    l_guarantorsSex);
         Pkg_Soap.add_parameter(req, 'guarantorsStatus', 'xsd:string',    l_guarantorsStatus);
         Pkg_Soap.add_parameter(req, 'guarantorsbdYear', 'xsd:string',    l_guarantorsbdYear);
         Pkg_Soap.add_parameter(req, 'guarantorsbdMonth', 'xsd:string',    l_guarantorsbdMonth);
         Pkg_Soap.add_parameter(req, 'guarantorsbdDay', 'xsd:string',    l_guarantorsbdDay);
         Pkg_Soap.add_parameter(req, 'guarantorsSocCode', 'xsd:string',    l_guarantorsSocCode);
         
         GenerateGuarantorsUL(pn_app_no, l_guarantorsULName, l_guarantorsULOrgForm, 
                                            l_guarantorsULCountry, l_guarantorsULInn,  
                                            l_guarantorsULBdYear, l_guarantorsULBdMonth,  
                                            l_guarantorsULBdDay);
         
         Pkg_Soap.add_parameter(req, 'guarantorsULName', 'xsd:string',   l_guarantorsULName);
         Pkg_Soap.add_parameter(req, 'guarantorsULOrgForm', 'xsd:string',   l_guarantorsULOrgForm);
         Pkg_Soap.add_parameter(req, 'guarantorsULBdYear', 'xsd:string',    l_guarantorsULBdYear);
         Pkg_Soap.add_parameter(req, 'guarantorsULBdMonth', 'xsd:string',    l_guarantorsULBdMonth);
         Pkg_Soap.add_parameter(req, 'guarantorsULBdDay', 'xsd:string',    l_guarantorsULBdDay);
         Pkg_Soap.add_parameter(req, 'guarantorsULCountry', 'xsd:string',    l_guarantorsULCountry);
         Pkg_Soap.add_parameter(req, 'guarantorsULInn', 'xsd:string',    l_guarantorsULInn);
         
         GenerateGuarantees(pn_app_no, l_guaranteeListCodes);
         
         Pkg_Soap.add_parameter(req, 'guaranteeListCodes', 'xsd:string',    l_guaranteeListCodes);
         
     /*dbms_output.put_line('firstnames = ' || l_guarantorsFirstname);
        dbms_output.put_line('l_guarantorsLastname = ' || l_guarantorsLastname);
        dbms_output.put_line('l_guarantorsDocType = ' || l_guarantorsDocType);
        dbms_output.put_line('l_guarantorsDocNo = ' || l_guarantorsDocNo);
        dbms_output.put_line('l_guarantorsSex = ' || l_guarantorsSex);
        dbms_output.put_line('l_guarantorsStatus = ' || l_guarantorsStatus);
        dbms_output.put_line('l_guarantorsbdYear = ' || l_guarantorsbdYear);
        dbms_output.put_line('l_guarantorsbdMonth = ' || l_guarantorsbdMonth); 
        dbms_output.put_line('l_guarantorsbdMonth = ' || l_guarantorsbdDay);*/
        
         
END;

PROCEDURE Send_Update_General(pn_app_no NUMBER, 
                                                 ps_cust_type VARCHAR2,
                                                 pd_date_award DATE,
                                                 pd_date_stop DATE,
                                                 pn_credit_type NUMBER,
                                                 ps_currency VARCHAR2,
                                                 pn_amount NUMBER,
                                                 ps_credit_status VARCHAR2,
                                                 pn_payout_count NUMBER,
                                                 pn_payout_day NUMBER,
                                                 pn_payout_amount NUMBER,
                                                 pn_actual_payout_amount NUMBER,
                                                 pn_overdue_payout_number NUMBER,
                                                 pn_overdue_amount NUMBER,
                                                 pn_unpaid_amount NUMBER,
                                                 ps_repay_status VARCHAR2,
                                                 pd_actual_repayment_date DATE,
                                                 pn_delay_day_count NUMBER                                              
                                                 ) IS 
BEGIN

    Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);                            

    namespace := 'http://services.demirbank.kg/';
    methodName := 'CreditAdd';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);          

    --add parameters to request
                       
    Pkg_Soap.add_parameter(req, 'custType', 'xsd:string', ps_cust_type);
    Pkg_Soap.add_parameter(req, 'creditNumber', 'xsd:int', pn_app_no);
    Pkg_Soap.add_parameter(req, 'dateAwardYear', 'xsd:int',   TO_NUMBER(to_char(pd_date_award, 'YYYY')));
    Pkg_Soap.add_parameter(req, 'dateAwardMonth', 'xsd:int',   TO_NUMBER(to_char(pd_date_award, 'MM')));
    Pkg_Soap.add_parameter(req, 'dateAwardDay', 'xsd:int',   TO_NUMBER(to_char(pd_date_award, 'DD')));
    Pkg_Soap.add_parameter(req, 'dueDateYear', 'xsd:int',   TO_NUMBER(to_char(pd_date_stop, 'YYYY')));
    Pkg_Soap.add_parameter(req, 'dueDateMonth', 'xsd:int',   TO_NUMBER(to_char(pd_date_stop, 'MM')));
    Pkg_Soap.add_parameter(req, 'dueDateDay', 'xsd:int',   TO_NUMBER(to_char(pd_date_stop, 'DD')));
    Pkg_Soap.add_parameter(req, 'creditType', 'xsd:string',   pn_credit_type);
    Pkg_Soap.add_parameter(req, 'currency', 'xsd:string',   ps_currency);
    Pkg_Soap.add_parameter(req, 'amount', 'xsd:string',   pn_amount);

    Pkg_Soap.add_parameter(req, 'creditStatus', 'xsd:string', ps_credit_status);                                                
    Pkg_Soap.add_parameter(req, 'payoutCount', 'xsd:int',    pn_payout_count);
    Pkg_Soap.add_parameter(req, 'payoutDay', 'xsd:int',   pn_payout_day );
    Pkg_Soap.add_parameter(req, 'payoutAmount', 'xsd:string',   pn_payout_amount);
    Pkg_Soap.add_parameter(req, 'actualPayoutAmount', 'xsd:string',  pn_actual_payout_amount);
    Pkg_Soap.add_parameter(req, 'overduePayoutNumber', 'xsd:int',   pn_overdue_payout_number);
    Pkg_Soap.add_parameter(req, 'overdueAmount', 'xsd:string',  pn_overdue_amount);
    Pkg_Soap.add_parameter(req, 'unpaidAmount', 'xsd:string',   pn_unpaid_amount);
    Pkg_Soap.add_parameter(req, 'repayStatus', 'xsd:string',   ps_repay_status); 
    Pkg_Soap.add_parameter(req, 'actualRepaymentYear', 'xsd:int',   TO_NUMBER(to_char(pd_actual_repayment_date, 'YYYY')));
    Pkg_Soap.add_parameter(req, 'actualRepaymentMonth', 'xsd:int',   TO_NUMBER(to_char(pd_actual_repayment_date, 'MM')));
    Pkg_Soap.add_parameter(req, 'actualRepaymentDay', 'xsd:int',   TO_NUMBER(to_char(pd_actual_repayment_date, 'DD')));
    Pkg_Soap.add_parameter(req, 'delayDayCount', 'xsd:int',   pn_delay_day_count); 
                                          
      AddRequiredParameters(pn_app_no);                           

     DBMS_OUTPUT.PUT_line(req.body);

    --call web service, and get response
              
    resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap
                 
    resultc := resp.doc.getclobval();         
              
    --dbms_output.put_line('*****************************result**********************');
    --dbms_output.put_line(resultc);
        
END; 

FUNCTION Send_New_Application(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
     l_app c_app%ROWTYPE;
BEGIN
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_New_Application', null, 'Application is not found!');
            RETURN FALSE;
        END IF;      
          Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                                                                       ps_cust_type => l_app.cust_type,
                                                                                       pd_date_award => l_app.application_date,
                                                                                       pd_date_stop => l_app.due_date,
                                                                                       pn_credit_type => l_app.loan_type,
                                                                                       ps_currency => l_app.currency,
                                                                                       pn_amount => l_app.amount,
                                                                                       ps_credit_status => '1-0',
                                                                                       pn_payout_count => 0,
                                                                                       pn_payout_day => 0,
                                                                                       pn_payout_amount => 0,
                                                                                       pn_actual_payout_amount => 0,
                                                                                       pn_overdue_payout_number => 0,
                                                                                       pn_overdue_amount => 0,
                                                                                       pn_unpaid_amount => 0,
                                                                                       ps_repay_status => 'NA',
                                                                                       pd_actual_repayment_date => SYSDATE,
                                                                                       pn_delay_day_count => 0);                                    

           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
             AddRequestLog('Send_New_Application App No '||pn_app_no, req.body, sqlerrm);
             dbms_output.put_line(sqlerrm);
              RETURN FALSE;
END;

FUNCTION Send_Rejection(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
     l_app c_app%ROWTYPE;
     
BEGIN
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Rejection', null, 'Application is not found!');
            RETURN FALSE;
        END IF;
                  
          Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.application_date,
                                           pd_date_stop => l_app.due_date,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.currency,
                                           pn_amount => l_app.amount,
                                           ps_credit_status => l_app.status,
                                           pn_payout_count => 0,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => 0,
                                           ps_repay_status => 'NA',
                                           pd_actual_repayment_date => SYSDATE,
                                           pn_delay_day_count => 0); 
                                                 
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
             AddRequestLog('Send_Rejection App No '||pn_app_no, req.body, sqlerrm);
             dbms_output.put_line(sqlerrm);
              RETURN FALSE;
END;


FUNCTION Send_CreditLine_Opening(pn_app_no NUMBER, pn_tx_no NUMBER, pd_date DATE) RETURN BOOLEAN
IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
BEGIN
       
       UPDATE CBS_CIB_LOAN_APPLICATION
       SET STATUS='2-0',
              DISBURSED='Y',
              L_DATE_AWARD=APPLICATION_DATE,--pd_date,
              L_DATE_STOP=DUE_DATE,
              L_PAYOUT_COUNT=1,
              L_UNPAID_AMOUNT=0,
              UPDATE_TX=pn_tx_no,
              UPDATE_DATE=SYSDATE
         WHERE APP_NO=pn_app_no;     
         
        OPEN c_app;
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_CreditLine_Opening App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
        Pkg_Cib_Transaction.Send_Update_General(  pn_app_no => l_app.app_no, 
                                                                                       ps_cust_type => l_app.cust_type,
                                                                                       pd_date_award => l_app.L_DATE_AWARD,
                                                                                       pd_date_stop => l_app.L_DATE_STOP,
                                                                                       pn_credit_type => l_app.LOAN_TYPE,
                                                                                       ps_currency => l_app.CURRENCY,
                                                                                       pn_amount => l_app.AMOUNT,
                                                                                       ps_credit_status => l_app.STATUS,
                                                                                       pn_payout_count =>  l_app.L_PAYOUT_COUNT,
                                                                                       pn_payout_day => 0,
                                                                                       pn_payout_amount => 0,
                                                                                       pn_actual_payout_amount => 0,
                                                                                       pn_overdue_payout_number => 0,
                                                                                       pn_overdue_amount => 0,
                                                                                       pn_unpaid_amount => l_app.L_UNPAID_AMOUNT,
                                                                                       ps_repay_status => 'NA',
                                                                                       pd_actual_repayment_date => SYSDATE,
                                                                                       pn_delay_day_count => 0); 
                                           
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_CreditLine_Opening App No ' ||pn_app_no, req.body, sqlerrm);
              RETURN FALSE;
END;


FUNCTION Send_Disbursement(pn_app_no NUMBER, pn_acc_no NUMBER, pn_tx_no NUMBER) RETURN BOOLEAN --chyngyzo cq5027 19.11.2015 acc no added to handle credit line tranches
IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
    
    ld_date_award DATE;
    ld_date_stop DATE;
    ls_currency VARCHAR2(4);
    ln_total_amount NUMBER;
    ln_payout_count NUMBER;
    ln_unpaid_amount NUMBER;
    
    ln_is_credit_line_tranche NUMBER:=0;
    
    old_STATUS CBS_CIB_LOAN_APPLICATION.STATUS%type;
    old_DISBURSED CBS_CIB_LOAN_APPLICATION.DISBURSED%type;
    old_L_ACC_NO CBS_CIB_LOAN_APPLICATION.L_ACC_NO%type;
    old_L_DATE_AWARD CBS_CIB_LOAN_APPLICATION.L_DATE_AWARD%type;
    old_L_DATE_STOP CBS_CIB_LOAN_APPLICATION.L_DATE_STOP%type;
    old_L_CURRENCY CBS_CIB_LOAN_APPLICATION.L_CURRENCY%type;
    old_L_AMOUNT CBS_CIB_LOAN_APPLICATION.L_AMOUNT%type;
    old_L_PAYOUT_COUNT CBS_CIB_LOAN_APPLICATION.L_PAYOUT_COUNT%type;
    old_L_UNPAID_AMOUNT CBS_CIB_LOAN_APPLICATION.L_UNPAID_AMOUNT%type;
    old_UPDATE_TX CBS_CIB_LOAN_APPLICATION.UPDATE_TX%type;
    old_UPDATE_DATE CBS_CIB_LOAN_APPLICATION.UPDATE_DATE%type;
    
BEGIN

        --check if it is credit line tranche
        SELECT COUNT(*) 
            INTO ln_is_credit_line_tranche
        FROM CBS_CIB_LOAN_APPLICATION
        WHERE APP_NO=pn_app_no AND LOAN_TYPE=PKG_CIB_TRANSACTION.Get_CreditLine_Type_Id;
        --get loan parameters
       SELECT MIN(ACILIS_TARIHI), 
                    MAX(KREDI_VADE), 
                    MAX(DOVIZ_KODU), 
                    SUM(TUTAR), 
                    SUM(decode(NVL(TAKSIT_SAYISI, 0), 0, 1, TAKSIT_SAYISI))
          INTO ld_date_award, 
                   ld_date_stop, 
                   ls_currency, 
                   ln_total_amount, 
                   ln_payout_count
       FROM CBS_HESAP_KREDI
       WHERE APP_NO = pn_app_no;
       --get loan amount 
       SELECT TUTAR
           INTO ln_unpaid_amount
       FROM CBS_HESAP_KREDI
       WHERE HESAP_NO = pn_acc_no;
       
       --BOM CQ5988 ErkinZ, 18.01.2018, backup old values in case of unsuccessful send data to CIB
       SELECT STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT, L_UNPAID_AMOUNT, UPDATE_TX, UPDATE_DATE
       INTO old_STATUS, old_DISBURSED, old_L_ACC_NO, old_L_DATE_AWARD, old_L_DATE_STOP, old_L_CURRENCY, old_L_AMOUNT, old_L_PAYOUT_COUNT, old_L_UNPAID_AMOUNT, old_UPDATE_TX, old_UPDATE_DATE
       FROM CBS_CIB_LOAN_APPLICATION
       WHERE APP_NO=pn_app_no;       
       --EOM CQ5988
       
       UPDATE CBS_CIB_LOAN_APPLICATION
       SET STATUS='2-0',
              DISBURSED='Y',
              L_ACC_NO=pn_acc_no,
              L_DATE_AWARD=DECODE(ln_is_credit_line_tranche, 0, ld_date_award, L_DATE_AWARD) ,
              L_DATE_STOP=DECODE(ln_is_credit_line_tranche, 0, ld_date_stop, L_DATE_STOP),
              L_CURRENCY=ls_currency,
              L_AMOUNT=ln_total_amount,
              L_PAYOUT_COUNT=ln_payout_count,
              L_UNPAID_AMOUNT=NVL(L_UNPAID_AMOUNT, 0)+ln_unpaid_amount,
              UPDATE_TX=pn_tx_no,
              UPDATE_DATE=SYSDATE
         WHERE APP_NO=pn_app_no;     
         
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Disbursement App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
        Pkg_Cib_Transaction.Send_Update_General(  pn_app_no => l_app.app_no, 
                                                                                       ps_cust_type => l_app.cust_type,
                                                                                       pd_date_award => l_app.L_DATE_AWARD,
                                                                                       pd_date_stop => l_app.L_DATE_STOP,
                                                                                       pn_credit_type => l_app.LOAN_TYPE,
                                                                                       ps_currency => l_app.L_CURRENCY,
                                                                                       pn_amount => l_app.L_AMOUNT,
                                                                                       ps_credit_status => l_app.STATUS,
                                                                                       pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                                                                       pn_payout_day => 0,
                                                                                       pn_payout_amount => 0,
                                                                                       pn_actual_payout_amount => 0,
                                                                                       pn_overdue_payout_number => 0,
                                                                                       pn_overdue_amount => 0,
                                                                                       pn_unpaid_amount => l_app.L_UNPAID_AMOUNT,
                                                                                       ps_repay_status => 'NA',
                                                                                       pd_actual_repayment_date => SYSDATE,
                                                                                       pn_delay_day_count => 0); 
                                           
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_Disbursement App No ' ||pn_app_no, req.body, sqlerrm);
             
             --BOM CQ5988 ErkinZ, 18.01.2018, in case of unsuccessful send insert old values
             UPDATE CBS_CIB_LOAN_APPLICATION
             SET 
             STATUS=old_STATUS,
             DISBURSED=old_DISBURSED,
             L_ACC_NO=old_L_ACC_NO,
             L_DATE_AWARD=old_L_DATE_AWARD,
             L_DATE_STOP=old_L_DATE_STOP,
             L_CURRENCY=old_L_CURRENCY,
             L_AMOUNT=old_L_AMOUNT,
             L_PAYOUT_COUNT=old_L_PAYOUT_COUNT,
             L_UNPAID_AMOUNT=old_L_UNPAID_AMOUNT,
             UPDATE_TX=old_UPDATE_TX,
             UPDATE_DATE=old_UPDATE_DATE
             WHERE APP_NO=pn_app_no; 
             --EOM CQ5988
             
              RETURN FALSE;
END;

FUNCTION Send_LG_Opening(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
BEGIN
       --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT,  L_UNPAID_AMOUNT, UPDATE_TX, UPDATE_DATE)
       = (SELECT '2-0', 'Y',  a.HESAP_NO, A.VERILIS_TARIHI, A.VADE_TARIHI, A.DOVIZ_KODU, A.TUTAR, 1,  A.TUTAR, pn_tx_no, SYSDATE
                FROM cbs_tm_hg_acilis_islem a
                WHERE TX_NO = pn_tx_no)
       WHERE APP_NO = pn_app_no;
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_LG_Opening App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
         Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => l_app.L_UNPAID_AMOUNT,
                                           ps_repay_status => 'NA',
                                           pd_actual_repayment_date => SYSDATE,
                                           pn_delay_day_count => 0); 
                                           
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_LG_Opening App No ' ||pn_app_no, req.body, sqlerrm);
              RETURN FALSE;
END;


FUNCTION Send_LG_Closure(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN
IS
    CURSOR c_app IS
            SELECT * 
            FROM CBS_CIB_LOAN_APPLICATION A 
            WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
    
    
BEGIN
      --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
      
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_PAYOUT_COUNT,  L_REPAYMENT_DATE,   L_REPAY_STATUS, UPDATE_TX, UPDATE_DATE)
       = (SELECT '4-0', 'Y', A.HESAP_NO, A.VERILIS_TARIHI, A.VADE_TARIHI, 1, A.KAPANIS_TARIHI, '1' , pn_tx_no, SYSDATE
                FROM cbs_tm_hg_acilis a
                WHERE APP_NO = pn_app_no)
       WHERE APP_NO = pn_app_no;
        
       
      OPEN c_app;
        
      FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
             AddRequestLog('Send_LG_Closure App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
               
           Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day =>1,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount =>  0,
                                           ps_repay_status => l_app.L_REPAY_STATUS,
                                           pd_actual_repayment_date => l_app.L_REPAYMENT_DATE,
                                           pn_delay_day_count => 0);     
    
    dbms_output.put_line(resultc);

       RETURN TRUE;
           
      EXCEPTION
        WHEN OTHERS THEN
             AddRequestLog('Send_LG_Closure App No ' ||pn_app_no, req.body, sqlerrm);
              dbms_output.put_line(sqlerrm);
              RETURN FALSE;
END;


FUNCTION Send_LC_Opening(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
BEGIN
       --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT,  L_UNPAID_AMOUNT, UPDATE_TX, UPDATE_DATE)
       = (SELECT '2-0', 'Y', A.KREDI_HESAP_NO, A.AKREDITIF_ACILIS_TARIHI, A.AKREDITIF_VADESI, A.DOVIZ_KODU, A.DOSYA_TUTARI, 1, A.DOSYA_TUTARI, pn_tx_no, SYSDATE
                FROM CBS_ITH_AKREDITIF_ISLEM a
                WHERE TX_NO = pn_tx_no)
       WHERE APP_NO = pn_app_no;
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_LC_Opening App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
         Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => l_app.L_UNPAID_AMOUNT,
                                           ps_repay_status => 'NA',
                                           pd_actual_repayment_date => SYSDATE,
                                           pn_delay_day_count => 0); 
                                           
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_LC_Opening App No ' ||pn_app_no, req.body, sqlerrm);
              RETURN FALSE;
END;

FUNCTION Send_LC_Closure(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN
IS
    CURSOR c_app IS
            SELECT * 
            FROM CBS_CIB_LOAN_APPLICATION A 
            WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;  
    
BEGIN
      --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
      
        UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_PAYOUT_COUNT,  L_REPAYMENT_DATE,   L_REPAY_STATUS, UPDATE_TX, UPDATE_DATE)
       = (SELECT '4-0', 'Y', A.KREDI_HESAP_NO, A.AKREDITIF_ACILIS_TARIHI, A.AKREDITIF_VADESI, 1, A.AKREDITIF_VADESI, '1' , pn_tx_no, SYSDATE
                FROM CBS_ITH_AKREDITIF_KAPAMA a
                WHERE TX_NO = pn_tx_no)
       WHERE APP_NO = pn_app_no;
        
       
      OPEN c_app;
        
      FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
             AddRequestLog('Send_LC_Closure App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
               
           Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day =>1,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount =>  0,
                                           ps_repay_status => l_app.L_REPAY_STATUS,
                                           pd_actual_repayment_date => l_app.L_REPAYMENT_DATE,
                                           pn_delay_day_count => 0);     
    
       RETURN TRUE;
           
      EXCEPTION
        WHEN OTHERS THEN
             AddRequestLog('Send_LC_Closure App No ' ||pn_app_no, req.body, sqlerrm);
              dbms_output.put_line(sqlerrm);
              RETURN FALSE;
END;

FUNCTION Send_Overdraft_Opening(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_acc_no CBS_HESAP.HESAP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN --chyngyzo cq5027 19.11.2015
IS
 CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
     
    --pc_ref RefCursorType;
    
BEGIN
       --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT,  UPDATE_TX, UPDATE_DATE)
       =
      (     SELECT '2-0', 'Y', a.hesap_numarasi, C.KAYIT_TARIH, D.DUE_DATE, B.FC_DOVIZ_KODU, B.FC_LIMIT, 1, pn_tx_no, SYSDATE
            FROM cbs_hesap_g_basvuru a
                    LEFT JOIN cbs_musteri_urun_limit b on (A.MUSTERI_NO=B.MUSTERI_NO and A.DOVIZ_KODU=B.FC_DOVIZ_KODU and A.OVD_PROPOSAL_LINE_NO=B.KREDI_TEKLIF_SATIR_NUMARA)
                    LEFT JOIN cbs_islem c on A.TX_NO=C.NUMARA
                    LEFT JOIN cbs_cib_loan_application d on A.APP_NO = D.APP_NO
            where a.app_no=pn_app_no and a.tx_no=pn_tx_no )
        WHERE APP_NO = pn_app_no;
                
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Overdraft_Opening App No ' || pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
        Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                                                                   ps_cust_type => l_app.cust_type,
                                                                                   pd_date_award => l_app.L_DATE_AWARD,
                                                                                   pd_date_stop => l_app.L_DATE_STOP,
                                                                                   pn_credit_type => l_app.loan_type,
                                                                                   ps_currency => l_app.L_CURRENCY,
                                                                                   pn_amount => l_app.L_AMOUNT,
                                                                                   ps_credit_status => l_app.STATUS,
                                                                                   pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                                                                   pn_payout_day => 0,
                                                                                   pn_payout_amount => 0,
                                                                                   pn_actual_payout_amount => 0,
                                                                                   pn_overdue_payout_number => 0,
                                                                                   pn_overdue_amount => 0,
                                                                                   pn_unpaid_amount => l_app.L_AMOUNT,--  <<<<<<<<<<<<<<<<<<<<!!!!!!!!!!!!!!!!!!!!!!! ask CIB if it is OK to send 0, because no risk is present in the beginning
                                                                                   ps_repay_status => 'NA',
                                                                                   pd_actual_repayment_date => SYSDATE,
                                                                                   pn_delay_day_count => 0);          
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_Overdraft_Opening App No ' ||pn_app_no, req.body, sqlerrm);
              RETURN FALSE;
END;

FUNCTION Send_Overdraft_Closure(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_acc_no CBS_HESAP.HESAP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE, pd_date DATE) RETURN BOOLEAN IS --chyngyzo cq5027 19.11.2015
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
        l_app c_app%ROWTYPE;    
BEGIN   
        --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, 
                L_PAYOUT_COUNT,  L_REPAY_STATUS, L_REPAYMENT_DATE, UPDATE_TX, UPDATE_DATE)
       =
            (SELECT '4-0', 'Y', a.hesap_numarasi, C.KAYIT_TARIH, D.DUE_DATE, B.FC_DOVIZ_KODU, B.FC_LIMIT, 
                            1, -- L_PAYOUT_COUNT 
                            '1',-- L_REPAY_STATUS
                            pd_date, -- L_REPAYMENT_DATE
                            pn_tx_no, SYSDATE
            FROM cbs_hesap_g_basvuru a
                    LEFT JOIN cbs_musteri_urun_limit b on (A.MUSTERI_NO=B.MUSTERI_NO and A.DOVIZ_KODU=B.FC_DOVIZ_KODU and A.OVD_PROPOSAL_LINE_NO=B.KREDI_TEKLIF_SATIR_NUMARA )
                    LEFT JOIN cbs_islem c on A.TX_NO=C.NUMARA
                    LEFT JOIN cbs_cib_loan_application d on A.APP_NO = D.APP_NO
            where a.app_no=pn_app_no and a.tx_no=pn_tx_no)
        WHERE APP_NO = pn_app_no;

        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Overdraft_Closure App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
         Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => 0,
                                           ps_repay_status => l_app.L_REPAY_STATUS,
                                           pd_actual_repayment_date => l_app.L_REPAYMENT_DATE,
                                           pn_delay_day_count => 0);          
                                                 
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
           AddRequestLog('Send_Overdraft_Closure App No ' ||pn_app_no, req.body, sqlerrm);
           RETURN FALSE;
END;

FUNCTION Send_Overdraft_Risks(pn_app_no NUMBER,  pn_limit NUMBER, ps_currency VARCHAR2, pn_risk NUMBER) RETURN BOOLEAN --chyngyzo cq5027 19.11.2015
IS
    CURSOR c_app IS
    SELECT * 
    FROM CBS_CIB_LOAN_APPLICATION A 
    WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
BEGIN
    
    UPDATE CBS_CIB_LOAN_APPLICATION 
    SET L_AMOUNT=pn_limit, L_CURRENCY=ps_currency, L_UNPAID_AMOUNT=pn_risk, UPDATE_DATE=SYSDATE
    WHERE APP_NO=pn_app_no;
    
    OPEN c_app;
        
    FETCH c_app into l_app;
            
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Overdraft_Risks App No ' || pn_app_no, null, 'Application is not found!');
        RETURN FALSE;
    END IF;
            
    Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                                                                ps_cust_type => l_app.cust_type,
                                                                                pd_date_award => l_app.L_DATE_AWARD,
                                                                                pd_date_stop => l_app.L_DATE_STOP,
                                                                                pn_credit_type => l_app.loan_type,
                                                                                ps_currency => l_app.L_CURRENCY,
                                                                                pn_amount => l_app.L_AMOUNT,
                                                                                ps_credit_status => l_app.STATUS,
                                                                                pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                                                                pn_payout_day => 0,
                                                                                pn_payout_amount => 0,
                                                                                pn_actual_payout_amount => 0,
                                                                                pn_overdue_payout_number => 0,
                                                                                pn_overdue_amount => 0,
                                                                                pn_unpaid_amount => l_app.L_UNPAID_AMOUNT,
                                                                                ps_repay_status => 'NA',
                                                                                pd_actual_repayment_date => SYSDATE,
                                                                                pn_delay_day_count => 0);          
    RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
           AddRequestLog('Send_Overdraft_Risks App No ' ||pn_app_no, req.body, sqlerrm);
           RETURN FALSE;
END;

FUNCTION Send_Card_Opening(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_acc_no CBS_HESAP_KREDI.HESAP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE ) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
     
    pc_ref RefCursorType;
    
BEGIN
       --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT,  UPDATE_TX, UPDATE_DATE)
       = ( SELECT '2-0', 'Y', a.HESAP_NO, a.ACILIS_TARIHI, a.KREDI_VADE, a.DOVIZ_KODU,  (select max(musteri_limit) from CBS_KART_MUSTERI_LIMIT where musteri_no = a.musteri_no and status = 'A' ), 1, pn_tx_no, SYSDATE
             FROM CBS_HESAP_KREDI a 
             WHERE a.APP_NO = pn_app_no AND A.HESAP_NO = pn_acc_no )
       WHERE APP_NO = pn_app_no;
        
        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Card_Opening App No ' || pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
           Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => l_app.L_AMOUNT,
                                           ps_repay_status => 'NA',
                                           pd_actual_repayment_date => SYSDATE,
                                           pn_delay_day_count => 0);          
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
             AddRequestLog('Send_Card_Opening App No ' ||pn_app_no, req.body, sqlerrm);
              RETURN FALSE;
END;

FUNCTION Send_Card_Closure(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pn_acc_no CBS_HESAP_KREDI.HESAP_NO%TYPE, pn_tx_no CBS_ISLEM.NUMARA%TYPE, pd_date DATE ) RETURN BOOLEAN IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;    
BEGIN
       --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
       
       UPDATE CBS_CIB_LOAN_APPLICATION 
       SET (STATUS, DISBURSED, L_ACC_NO, L_DATE_AWARD, L_DATE_STOP, L_CURRENCY, L_AMOUNT, L_PAYOUT_COUNT,  L_REPAY_STATUS, L_REPAYMENT_DATE, UPDATE_TX, UPDATE_DATE)
       = (SELECT '4-0', 'Y', a.HESAP_NO, a.ACILIS_TARIHI, a.KREDI_VADE, a.DOVIZ_KODU,  
                        (select max(musteri_limit) from CBS_KART_MUSTERI_LIMIT where musteri_no = a.musteri_no and status = 'A' ), --L_AMOUNT
                        12, --L_PAYOUT_COUNT
                        '1', --L_REPAY_STATUS --plateji po grafiku
                        pd_date, --L_REPAYMENT_DATE
                        pn_tx_no, SYSDATE
             FROM CBS_HESAP_KREDI a 
             WHERE a.APP_NO = pn_app_no AND A.HESAP_NO = pn_acc_no)
       WHERE APP_NO = pn_app_no;

        OPEN c_app;
        
        FETCH c_app into l_app;
        
        IF c_app%NOTFOUND THEN
            AddRequestLog('Send_Card_Closure App No ' ||pn_app_no, null, 'Application is not found!');
            RETURN FALSE;
        END IF;
        
         Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status => l_app.STATUS,
                                           pn_payout_count =>  l_app.L_PAYOUT_COUNT ,
                                           pn_payout_day => 0,
                                           pn_payout_amount => 0,
                                           pn_actual_payout_amount => 0,
                                           pn_overdue_payout_number => 0,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount => 0,
                                           ps_repay_status => l_app.L_REPAY_STATUS,
                                           pd_actual_repayment_date => l_app.L_REPAYMENT_DATE,
                                           pn_delay_day_count => 0);          
                                                 
           RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
           dbms_output.put_line(sqlerrm);
           AddRequestLog('Send_Card_Closure App No ' ||pn_app_no, req.body, sqlerrm);
           RETURN FALSE;
END;

FUNCTION Send_Repayment(pn_app_no NUMBER, pn_acc_no NUMBER,  pn_tx_no NUMBER) RETURN BOOLEAN IS
    
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
     
    ld_repayment_date DATE;  
    ln_repayment_order NUMBER;
    ln_payout_count NUMBER;
    ln_repayment_amount NUMBER;
    ln_last_update_tx NUMBER;
    
    
    pc_ref RefCursorType;
    ln_order NUMBER := 0;
    ln_unpaid_amount NUMBER := 0;
    ls_loan_status VARCHAR2(5);
    ln_return NUMBER := 0;
BEGIN
    
    SELECT  NVL (c.onay_tarih, c.kayit_tarih) INTO ld_repayment_date
    FROM CBS_ISLEM c
    WHERE c.numara = pn_tx_no;                                         
                
    OPEN c_app;                    
    FETCH c_app into l_app;
            
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Repayment App No ' ||pn_app_no, null, 'Application is not found!');
        CLOSE c_app;
        RETURN FALSE;
    END IF;
            
    --total payouts count should be updated every time, since it may change when payment plan changes                     
    ln_payout_count := pkg_cib_transaction.get_loan_repayments_count(pn_app_no);   
    ln_unpaid_amount := l_app.L_UNPAID_AMOUNT;
    ls_loan_status := '16-0';
                             
    LOOP
        ln_order := ln_order + 1;
        ln_return := pkg_cib_transaction.get_loan_repayment_order(pn_app_no, pn_acc_no, ld_repayment_date, ln_order, pc_ref);
        EXIT WHEN ln_return = -1;
                
        FETCH pc_ref INTO ln_repayment_order, ln_repayment_amount;
                
        ln_unpaid_amount := ln_unpaid_amount - ln_repayment_amount;
        
        dbms_output.put_line('ln_order = '||ln_order||', ln_repayment_order = ' ||ln_repayment_order||', ln_repayment_amount = ' ||ln_repayment_amount ||', ln_unpaid_amount = ' ||ln_unpaid_amount ||', ln_payout_count = '||ln_payout_count);    
                                    
        Pkg_Cib_Transaction.Send_Update_General(
                                           pn_app_no => l_app.app_no, 
                                           ps_cust_type => l_app.cust_type,
                                           pd_date_award => l_app.L_DATE_AWARD,
                                           pd_date_stop => l_app.L_DATE_STOP,
                                           pn_credit_type => l_app.loan_type,
                                           ps_currency => l_app.L_CURRENCY,
                                           pn_amount => l_app.L_AMOUNT,
                                           ps_credit_status =>ls_loan_status,
                                           pn_payout_count =>  ln_payout_count ,
                                           pn_payout_day => TO_NUMBER(to_char(ld_repayment_date, 'DD')),
                                           pn_payout_amount => ln_repayment_amount,
                                           pn_actual_payout_amount => ln_repayment_amount,
                                           pn_overdue_payout_number => ln_repayment_order,
                                           pn_overdue_amount => 0,
                                           pn_unpaid_amount =>  ln_unpaid_amount,
                                           ps_repay_status => nvl(l_app.L_REPAY_STATUS,'1'),
                                           pd_actual_repayment_date => ld_repayment_date,
                                           pn_delay_day_count => 0);       
    END LOOP;

    UPDATE CBS_CIB_LOAN_APPLICATION
    SET STATUS = '16-0', 
           L_ACC_NO = pn_acc_no,
           L_PAYOUT_COUNT = ln_payout_count,
           L_UNPAID_AMOUNT = ln_unpaid_amount,
           L_REPAYMENT_ORDER = ln_repayment_order,
           L_REPAYMENT_DATE = ld_repayment_date,
           L_REPAYMENT_AMOUNT = ln_repayment_amount,
           L_REPAY_STATUS = nvl(L_REPAY_STATUS,'1'),
           UPDATE_TX = pn_tx_no,
           UPDATE_DATE = SYSDATE
      WHERE APP_NO = pn_app_no;   
                                     
    CLOSE c_app;
         
    RETURN TRUE;
        
EXCEPTION
    WHEN OTHERS THEN
        AddRequestLog('Send_Repayment App No ' ||pn_app_no, req.body, sqlerrm);
        dbms_output.put_line(sqlerrm);
        IF c_app%ISOPEN THEN
            CLOSE c_app;
        END IF;
        RETURN FALSE;
END;


FUNCTION Send_Pastdue(pn_app_no NUMBER, pn_hesap_no NUMBER, pn_tx_no NUMBER) RETURN BOOLEAN
IS
    CURSOR c_app IS
            SELECT * 
            FROM CBS_CIB_LOAN_APPLICATION A 
            WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
    
    ln_repayment_amount NUMBER;
    ln_repayment_order NUMBER;
    ln_pastdue_amount NUMBER;
    ld_pastdue_opening_date DATE;
    ls_repay_status VARCHAR2(5);
    ln_payout_count NUMBER;
    ln_unpaid_amount_total NUMBER := 0;
    ln_unpaid_pastdues_total NUMBER;
    
    pc_ref RefCursorType;
BEGIN
    --UPDATE CBS_CIB_LOAN_APPLICATION TABLE     
    SELECT ABS(pkg_kur.yuvarla (DOVIZ_KODU, pkg_kredi_rapor.sf_valbakiye_al(hesap_no, acilis_tarihi))), acilis_tarihi
    INTO ln_pastdue_amount, ld_pastdue_opening_date --current pastdue amount and opening date
    FROM cbs_hesap_kredi_islem 
    WHERE tx_no = pn_tx_no;
           
    ln_repayment_amount := pkg_cib_transaction.Get_Loan_Repayment_Amount(pn_hesap_no, ld_pastdue_opening_date);
          
    ln_repayment_order := pkg_cib_transaction.Get_Loan_Repayment_Order(pn_app_no, pn_hesap_no, ld_pastdue_opening_date, 1, pc_ref);
          
    ln_payout_count := pkg_cib_transaction.Get_Loan_Repayments_Count(pn_app_no);                          
            
    ln_unpaid_amount_total := pkg_cib_transaction.Get_Loan_Unpaid_Amount(pn_app_no, ld_pastdue_opening_date); --pastdues included
    
    ln_unpaid_pastdues_total := pkg_cib_transaction.Get_Loan_Pastdue_Amount(pn_app_no, ld_pastdue_opening_date);
                    
    ls_repay_status := pkg_cib_transaction.Get_Loan_Repayment_Status(pn_app_no, ld_pastdue_opening_date);
                     
    OPEN c_app;
    FETCH c_app into l_app;
        
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Pastdue App No ' ||pn_app_no, null, 'Application is not found!');
        CLOSE c_app;
        RETURN FALSE;
    END IF;
                                                        
    Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                       ps_cust_type => l_app.cust_type,
                                       pd_date_award => l_app.L_DATE_AWARD,
                                       pd_date_stop => l_app.L_DATE_STOP,
                                       pn_credit_type => l_app.loan_type,
                                       ps_currency => l_app.L_CURRENCY,
                                       pn_amount => l_app.L_AMOUNT,
                                       ps_credit_status => '5-0',
                                       pn_payout_count =>  ln_payout_count ,
                                       pn_payout_day => TO_NUMBER(to_char(ld_pastdue_opening_date, 'DD')),
                                       pn_payout_amount => ln_repayment_amount,
                                       pn_actual_payout_amount =>  ln_pastdue_amount,--l_app.L_REPAYMENT_AMOUNT,
                                       pn_overdue_payout_number => ln_repayment_order,
                                       pn_overdue_amount => ln_unpaid_pastdues_total, --l_app.L_OVERDUE_AMOUNT,
                                       pn_unpaid_amount =>  ln_unpaid_amount_total,
                                       ps_repay_status => ls_repay_status,
                                       pd_actual_repayment_date => SYSDATE,
                                       pn_delay_day_count => 1);     
     
     CLOSE c_app;       
     
    UPDATE CBS_CIB_LOAN_APPLICATION     
    SET STATUS = '5-0', 
          L_ACC_NO = pn_hesap_no,
          L_PAYOUT_COUNT = ln_payout_count,
          L_UNPAID_AMOUNT = ln_unpaid_amount_total,
          L_REPAYMENT_ORDER = ln_repayment_order, 
          L_REPAYMENT_DATE = ld_pastdue_opening_date, 
          L_REPAYMENT_AMOUNT = ln_repayment_amount,
          L_DELAY_DAY_COUNT = 1,
          L_REPAY_STATUS = ls_repay_status,
          L_OVERDUE_AMOUNT = ln_pastdue_amount, 
          L_TOTAL_PASTDUES_SUM = ln_unpaid_pastdues_total,
          UPDATE_TX = pn_tx_no, 
          UPDATE_DATE = SYSDATE
    WHERE APP_NO = pn_app_no;                                          
                                 
   RETURN TRUE;
   
EXCEPTION
    WHEN OTHERS THEN
        AddRequestLog('Send_Pastdue App No ' ||pn_app_no, req.body, sqlerrm);
        IF c_app%ISOPEN THEN
            CLOSE c_app;
        END IF;
        dbms_output.put_line(sqlerrm);
        RETURN FALSE;
END;

FUNCTION Send_Pastdue_Closure(pn_app_no NUMBER, pn_hesap_no NUMBER, pn_tx_no NUMBER) RETURN BOOLEAN
IS
    CURSOR c_app IS
            SELECT * 
            FROM CBS_CIB_LOAN_APPLICATION A 
            WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
    
    ln_repayment_amount NUMBER;
    ln_repayment_order NUMBER;
    ln_pastdue_amount NUMBER;
    ld_pastdue_opening_date DATE;
    ld_pastdue_closing_date DATE;
    ls_repay_status VARCHAR2(5);
    ln_payout_count NUMBER;
    ln_unpaid_amount_total NUMBER := 0;
    ln_unpaid_pastdues_total NUMBER;
    ln_delay_day_count NUMBER;
    
    pc_ref RefCursorType;        
BEGIN
      --UPDATE CBS_CIB_LOAN_APPLICATION TABLE
    SELECT ABS(pkg_kur.yuvarla (A.DOVIZ_KODU, pkg_kredi_rapor.sf_valbakiye_al(A.hesap_no, A.ACILIS_TARIHI))), A.ACILIS_TARIHI, A.KAPANIS_TARIHI 
        INTO ln_pastdue_amount, ld_pastdue_opening_date, ld_pastdue_closing_date  -- take pastdue amount, opening date and closing date 
    FROM CBS_HESAP_KREDI A, CBS_HESAP_KREDI_ISLEM B
    WHERE A.HESAP_NO = B.HESAP_NO AND B.TX_NO = pn_tx_no;
      
    ln_repayment_amount := pkg_cib_transaction.Get_Loan_Repayment_Amount(pn_hesap_no, ld_pastdue_opening_date);
          
    ln_repayment_order := pkg_cib_transaction.Get_Loan_Repayment_Order(pn_app_no, pn_hesap_no, ld_pastdue_opening_date, 1, pc_ref);
    
    ln_unpaid_pastdues_total := pkg_cib_transaction.Get_Loan_Pastdue_Amount(pn_app_no, ld_pastdue_closing_date);
    
    ls_repay_status := pkg_cib_transaction.Get_Loan_Repayment_Status(pn_app_no, ld_pastdue_closing_date);
        
    ln_delay_day_count := nvl(ld_pastdue_closing_date - ld_pastdue_opening_date, 0) + 1;
    
    ln_payout_count := pkg_cib_transaction.Get_Loan_Repayments_Count(pn_app_no);                          
            
    ln_unpaid_amount_total := pkg_cib_transaction.Get_Loan_Unpaid_Amount(pn_app_no, ld_pastdue_closing_date); --pastdues included                   
            
    OPEN c_app;
    FETCH c_app into l_app;
        
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Pastdue_Closure App No ' ||pn_app_no, null, 'Application is not found!');
        CLOSE c_app;
        RETURN FALSE;
    END IF;
        
    Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                   ps_cust_type => l_app.cust_type,
                                   pd_date_award => l_app.L_DATE_AWARD,
                                   pd_date_stop => l_app.L_DATE_STOP,
                                   pn_credit_type => l_app.loan_type,
                                   ps_currency => l_app.L_CURRENCY,
                                   pn_amount => l_app.L_AMOUNT,
                                   ps_credit_status => '5-0',
                                   pn_payout_count =>  ln_payout_count ,
                                   pn_payout_day => TO_NUMBER(to_char(ld_pastdue_opening_date, 'DD')),
                                   pn_payout_amount => ln_repayment_amount,
                                   pn_actual_payout_amount => ln_pastdue_amount,
                                   pn_overdue_payout_number => ln_repayment_order,
                                   pn_overdue_amount => ln_unpaid_pastdues_total,
                                   pn_unpaid_amount =>  ln_unpaid_amount_total,
                                   ps_repay_status => ls_repay_status,
                                   pd_actual_repayment_date => SYSDATE,
                                   pn_delay_day_count => ln_delay_day_count);     
                                   
    CLOSE c_app;
    
   UPDATE CBS_CIB_LOAN_APPLICATION 
    SET STATUS = '5-0', 
          L_ACC_NO = pn_hesap_no,
          L_PAYOUT_COUNT = ln_payout_count,
          L_UNPAID_AMOUNT = ln_unpaid_amount_total,
          L_REPAYMENT_ORDER = ln_repayment_order, 
          L_REPAYMENT_DATE = ld_pastdue_opening_date, 
          L_REPAYMENT_AMOUNT = ln_repayment_amount,
          L_DELAY_DAY_COUNT = ln_delay_day_count,
          L_REPAY_STATUS = ls_repay_status,
          L_OVERDUE_AMOUNT = ln_pastdue_amount, 
          L_TOTAL_PASTDUES_SUM = ln_unpaid_pastdues_total,
          UPDATE_TX = pn_tx_no, 
          UPDATE_DATE = SYSDATE
    WHERE APP_NO = pn_app_no;
    
    RETURN TRUE;
           
EXCEPTION
    WHEN OTHERS THEN
        AddRequestLog('Send_Pastdue_Closure App No ' ||pn_app_no, req.body, sqlerrm);
        dbms_output.put_line(sqlerrm);
        IF c_app%ISOPEN THEN
            CLOSE c_app;
        END IF;
        RETURN FALSE;
END;



FUNCTION Send_Pastdue_Update(pn_app_no NUMBER, pn_hesap_no NUMBER, pn_pastdue_acc_no NUMBER, pd_sending_date DATE) RETURN BOOLEAN
IS
    CURSOR c_app IS
            SELECT * 
            FROM CBS_CIB_LOAN_APPLICATION A 
            WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
    
    ln_repayment_amount NUMBER;
    ln_repayment_order NUMBER;
    ln_pastdue_amount NUMBER;
    ld_pastdue_opening_date DATE;
    ls_repay_status VARCHAR2(5);
    ln_payout_count NUMBER;
    ln_unpaid_amount_total NUMBER := 0;
    ln_unpaid_pastdues_total NUMBER;
    ln_delay_day_count NUMBER;
    
    pc_ref RefCursorType;
BEGIN
    --UPDATE CBS_CIB_LOAN_APPLICATION TABLE    
    SELECT ABS(pkg_kur.yuvarla (A.DOVIZ_KODU, pkg_kredi_rapor.sf_valbakiye_al(A.hesap_no, A.ACILIS_TARIHI))), A.ACILIS_TARIHI  
    INTO ln_pastdue_amount, ld_pastdue_opening_date
    FROM CBS_HESAP_KREDI A
    WHERE A.HESAP_NO = pn_pastdue_acc_no;
     
    ln_repayment_amount := pkg_cib_transaction.Get_Loan_Repayment_Amount(pn_hesap_no, ld_pastdue_opening_date);
              
    ln_repayment_order := pkg_cib_transaction.Get_Loan_Repayment_Order(pn_app_no, pn_hesap_no, ld_pastdue_opening_date, 1, pc_ref);
        
    ln_unpaid_pastdues_total := pkg_cib_transaction.Get_Loan_Pastdue_Amount(pn_app_no, pd_sending_date);
        
    ls_repay_status := pkg_cib_transaction.Get_Loan_Repayment_Status(pn_app_no, pd_sending_date);
            
    ln_delay_day_count := nvl(pd_sending_date - ld_pastdue_opening_date, 0) + 1;
        
    ln_payout_count := pkg_cib_transaction.Get_Loan_Repayments_Count(pn_app_no);                          
                
    ln_unpaid_amount_total := pkg_cib_transaction.Get_Loan_Unpaid_Amount(pn_app_no, pd_sending_date); --pastdues included                            
      
    OPEN c_app;
    FETCH c_app into l_app;
        
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Pastdue_Update App No ' ||pn_app_no, null, 'Application is not found!');
        CLOSE c_app;            
        dbms_output.put_line('Application is not found!');
        RETURN FALSE;
    END IF;
        
    Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                                ps_cust_type => l_app.cust_type,
                                                pd_date_award => l_app.L_DATE_AWARD,
                                                pd_date_stop => l_app.L_DATE_STOP,
                                                pn_credit_type => l_app.loan_type,
                                                ps_currency => l_app.L_CURRENCY,
                                                pn_amount => l_app.L_AMOUNT,
                                                ps_credit_status => '5-0',
                                                pn_payout_count =>  ln_payout_count,
                                                pn_payout_day => TO_NUMBER(to_char(ld_pastdue_opening_date, 'DD')),
                                                pn_payout_amount => ln_repayment_amount,
                                                pn_actual_payout_amount => ln_pastdue_amount,
                                                pn_overdue_payout_number => ln_repayment_order,
                                                pn_overdue_amount => ln_unpaid_pastdues_total,
                                                pn_unpaid_amount =>  ln_unpaid_amount_total,
                                                ps_repay_status => ls_repay_status,
                                                pd_actual_repayment_date => SYSDATE,
                                                pn_delay_day_count => ln_delay_day_count);     
    
    CLOSE c_app;
    
    UPDATE CBS_CIB_LOAN_APPLICATION 
    SET STATUS = '5-0', 
          L_ACC_NO = pn_hesap_no,
          L_PAYOUT_COUNT = ln_payout_count,
          L_UNPAID_AMOUNT = ln_unpaid_amount_total,
          L_REPAYMENT_ORDER = ln_repayment_order, 
          L_REPAYMENT_DATE = ld_pastdue_opening_date, 
          L_REPAYMENT_AMOUNT = ln_repayment_amount,
          L_DELAY_DAY_COUNT = ln_delay_day_count,
          L_REPAY_STATUS = ls_repay_status,
          L_OVERDUE_AMOUNT = ln_pastdue_amount, 
          L_TOTAL_PASTDUES_SUM = ln_unpaid_pastdues_total,
          UPDATE_DATE = SYSDATE
    WHERE APP_NO = pn_app_no;
        
    RETURN TRUE;
           
EXCEPTION
    WHEN OTHERS THEN
        AddRequestLog('Send_Pastdue_Update App No ' ||pn_app_no, req.body, sqlerrm);
        dbms_output.put_line(sqlerrm);
        IF c_app%ISOPEN THEN
            CLOSE c_app;
        END IF;
        RETURN FALSE;
END;

FUNCTION Send_Loan_Closure(pn_app_no NUMBER, pn_acc_no NUMBER, pn_tx_no NUMBER) RETURN BOOLEAN
IS
    CURSOR c_app IS
        SELECT * 
        FROM CBS_CIB_LOAN_APPLICATION A 
        WHERE APP_NO = pn_app_no;
    
    l_app c_app%ROWTYPE;
            
    ls_repay_status VARCHAR2(5);
    ln_payout_count NUMBER;
    ld_loan_closure_date DATE;
    
BEGIN
        
    SELECT KAPANIS_TARIHI
        INTO ld_loan_closure_date
    FROM CBS_HESAP_KREDI
    WHERE HESAP_NO = pn_acc_no;    
    
    ln_payout_count := pkg_cib_transaction.Get_Loan_Repayments_Count(pn_app_no);           
    
    ls_repay_status := pkg_cib_transaction.Get_Loan_Repayment_Status(pn_app_no, ld_loan_closure_date);
           
    OPEN c_app;
    FETCH c_app into l_app;
            
    IF c_app%NOTFOUND THEN
        AddRequestLog('Send_Loan_Closure App No ' ||pn_app_no, null, 'Application is not found!');
        RETURN FALSE;
    END IF;
               
    Pkg_Cib_Transaction.Send_Update_General(pn_app_no => l_app.app_no, 
                                   ps_cust_type => l_app.cust_type,
                                   pd_date_award => l_app.L_DATE_AWARD,
                                   pd_date_stop => l_app.L_DATE_STOP,
                                   pn_credit_type => l_app.loan_type,
                                   ps_currency => l_app.L_CURRENCY,
                                   pn_amount => l_app.L_AMOUNT,
                                   ps_credit_status =>  '4-0',
                                   pn_payout_count =>  ln_payout_count ,
                                   pn_payout_day =>TO_NUMBER(to_char(ld_loan_closure_date, 'DD')),
                                   pn_payout_amount => 0,
                                   pn_actual_payout_amount => 0,
                                   pn_overdue_payout_number => 0,
                                   pn_overdue_amount => 0,
                                   pn_unpaid_amount =>  0,
                                   ps_repay_status => ls_repay_status,
                                   pd_actual_repayment_date => ld_loan_closure_date,
                                   pn_delay_day_count => 0);     
                                           
    CLOSE c_app;
    
    UPDATE CBS_CIB_LOAN_APPLICATION 
    SET STATUS = '4-0', 
          L_ACC_NO = pn_acc_no,
          L_PAYOUT_COUNT = ln_payout_count,
          L_REPAYMENT_DATE = ld_loan_closure_date, 
          L_REPAY_STATUS = ls_repay_status,
          UPDATE_TX = pn_tx_no,
          UPDATE_DATE = SYSDATE
    WHERE APP_NO = pn_app_no;
    
    RETURN TRUE;
          
EXCEPTION
    WHEN OTHERS THEN
        AddRequestLog('Send_Loan_Closure App No ' ||pn_app_no, req.body, sqlerrm);
        dbms_output.put_line(sqlerrm);
        IF c_app%ISOPEN THEN
            CLOSE c_app;
        END IF;
        RETURN FALSE;
END;
----******************************************************************

FUNCTION GetDocumentTypeName(pn_doc_type_id NUMBER) RETURN VARCHAR2 IS
    ls_name varchar2(100);
BEGIN
    
    SELECT substr(COUNTRY_NAME||' - '||DOCUMENT_NAME, 1, 100)  INTO ls_name FROM CBS_CIB_DIR_DOCUMENT WHERE ID = pn_doc_type_id;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;

FUNCTION GetOrgFormName(pn_orgform_code NUMBER) RETURN VARCHAR2 IS
    ls_name varchar2(100);
BEGIN
    
    SELECT substr(DESCRIPTION, 1, 100)  INTO ls_name FROM CBS_CIB_DIR_ORGFORM WHERE CODE = pn_orgform_code;
    
    return ls_name; 
    
    EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;


----------------------------------------------------------COMPANY METHODS-------------------------------------------------------------------------
FUNCTION GetCompanyGuid(ps_name VARCHAR2,  pn_org_form_code NUMBER, ps_country_code VARCHAR2, 
                                          pd_bdate DATE, ps_inn VARCHAR2, 
                                          ps_okpo VARCHAR2, ps_statcom VARCHAR2) RETURN VARCHAR2 IS
                            
   cursor pc_ref(resultc in clob) is 
        SELECT extractvalue(column_value, '/Id') guid
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/CompanyRequestNewResponse/CompanyRequestNewResult/Id'))) t;
        
   row_auth pc_ref%ROWTYPE;
   
   ls_name VARCHAR2(1000);
BEGIN
    
        Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
       
        namespace := 'http://services.demirbank.kg/';
        methodName := 'CompanyRequestNew';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
    
        --xml escape ps_name
        ls_name :=  DBMS_XMLGEN.CONVERT(ps_name);
            
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'companyName', 'xsd:string', ls_name);
        Pkg_Soap.add_parameter(req, 'orgFormCode', 'xsd:int', pn_org_form_code);
        Pkg_Soap.add_parameter(req, 'birthdate_year', 'xsd:int', to_number(to_char(pd_bdate, 'YYYY')));
        Pkg_Soap.add_parameter(req, 'birthdate_month', 'xsd:int', to_number(to_char(pd_bdate, 'MM')));
        Pkg_Soap.add_parameter(req, 'birthdate_day', 'xsd:int', to_number(to_char(pd_bdate, 'DD')));
        Pkg_Soap.add_parameter(req, 'country_code', 'xsd:string', ps_country_code);
        Pkg_Soap.add_parameter(req, 'tax_no', 'xsd:string', ps_inn);
        Pkg_Soap.add_parameter(req, 'okpo_code', 'xsd:string',  ps_okpo);
        Pkg_Soap.add_parameter(req, 'stat_com', 'xsd:string', ps_statcom);
        
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap 

        resultc := resp.doc.getclobval();         
                          
         OPEN pc_ref(resultc);

        FETCH pc_ref INTO row_auth;
        
          IF pc_ref%FOUND THEN
                   
               RETURN row_auth.guid;
               
        END IF;
        
        IF pc_ref%NOTFOUND THEN
                 
                 RETURN NULL;
        END IF;
        CLOSE pc_ref;
   EXCEPTION 
        WHEN OTHERS THEN
    
        if instr(sqlerrm, 'System.Exception') = 0 --if not input related error then log
        then
             AddRequestLog('CompanyRequestNew', req.body, sqlerrm); 
        end if;
      
        if pc_ref%ISOPEN THEN
            CLOSE pc_ref;
        end if;
        
        RAISE;
                                     
END;
FUNCTION CompanyCreditHistoryReady(ps_guid IN VARCHAR2, ps_status_txt OUT VARCHAR2) RETURN BOOLEAN IS

   cursor pc_ref(resultc in clob) is 
            SELECT extractvalue(column_value, '/CompanyCreditHistoryIsReadyResult/Id') status_no,
                        extractvalue(column_value, '/CompanyCreditHistoryIsReadyResult/Description') description
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/CompanyCreditHistoryIsReadyResponse/CompanyCreditHistoryIsReadyResult'))) t;
        
   row_auth pc_ref%ROWTYPE;
   lb_status BOOLEAN := FALSE;
   ln_count NUMBER :=0;
   
   ln_current_status NUMBER := 0;
BEGIN


        SELECT STATUS INTO ln_current_status FROM CBS_CIB_COMPANY_CREDIT_HISTORY WHERE GUID = ps_guid;
        IF ln_current_status IN (3,4,5) THEN
            SELECT (STATUS || ' - ' || STATUS_TEXT) INTO ps_status_txt  FROM CBS_CIB_COMPANY_CREDIT_HISTORY WHERE GUID = ps_guid;  
            RETURN TRUE;
        END IF;
           
        Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
    
        namespace := 'http://services.demirbank.kg/';
        methodName := 'CompanyCreditHistoryIsReady';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
       
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
                 
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction); -- TDL: implement in pkg_soap 
    
        resultc := resp.doc.getclobval();
               
        OPEN pc_ref(resultc);

        FETCH pc_ref INTO row_auth;
        
          IF pc_ref%FOUND THEN
               
               if to_number(row_auth.status_no) IN (3,4,5) then
                    lb_status := TRUE;
               end if;               
                
               SELECT COUNT(*) INTO ln_count FROM CBS_CIB_COMPANY_CREDIT_HISTORY WHERE guid = ps_guid;
                
               IF ln_count = 1 THEN
                    UPDATE CBS_CIB_COMPANY_CREDIT_HISTORY 
                    SET STATUS = row_auth.status_no, STATUS_TEXT = row_auth.description, STATUS_OBJ = resultc, created_at=sysdate, created_by=user
                    WHERE GUID = ps_guid;
                    COMMIT;
               END IF;
                    ps_status_txt := row_auth.status_no || ' - ' || row_auth.description ;
                
               RETURN lb_status;
          ELSE
            
                ps_status_txt := 'ERROR';  
               RETURN FALSE;
        END IF;
       

    EXCEPTION
            WHEN OTHERS THEN
               
           AddRequestLog('CompanyCreditHistoryIsReady', req.body, sqlerrm); 
      
           if pc_ref%ISOPEN THEN
                CLOSE pc_ref;
            end if;
            
            RAISE;
        
END;
FUNCTION GetCompanyCreditRelevance(pclob_debtors CLOB, ps_name VARCHAR2,  pd_bdate DATE) RETURN VARCHAR2 IS

cursor pc_debtors(resultc in clob) is 
  SELECT extractvalue(column_value, '/DebtorUL/CompanyName') companyName,
              extractvalue(column_value, '/DebtorUL/BirthDate') bdate
  FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/DebtorsUL/DebtorUL'))) t;
  
       row_debtors pc_debtors%ROWTYPE;
BEGIN


    OPEN pc_debtors(pclob_debtors);
    
     FETCH pc_debtors INTO row_debtors;
        
        WHILE  pc_debtors%FOUND
        LOOP
          
              --log_at('CIB1', UPPER(ps_firstname) || ', ' || UPPER(row_debtors.firstname) , UPPER(ps_lastname) || ', ' || UPPER(row_debtors.lastname),  pd_bdate  || ', ' ||to_date(substr(row_debtors.bdate, 1, 10), 'YYYY-MM-DD'));
              
              if UPPER(TRIM(ps_name)) = UPPER(TRIM(row_debtors.companyName)) /*AND pd_bdate = to_date(substr(row_debtors.bdate, 1, 10), 'YYYY-MM-DD')*/ then
                    return 'Заемщик';
              end if;
               
         FETCH pc_debtors INTO row_debtors;
        END LOOP;
        
        CLOSE pc_debtors;

  return 'Поручитель';
END;
PROCEDURE GetCompanyCreditHistoryH(ps_guid  IN  VARCHAR2, ps_name VARCHAR2, pd_bdate DATE,
                                        pc_ref_out OUT RefCursorType, pc_ref_requests OUT RefCursorType)  is                    
       ln_count NUMBER := 0;
begin
   
        SELECT COUNT(*) INTO ln_count FROM CBS_CIB_COMPANY_CREDIT_HISTORY WHERE GUID = ps_guid AND STATUS IN (3,4,5) AND HISTORY_OBJ is not null;
    
        IF ln_count = 0 THEN
        
            Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
           
            namespace := 'http://services.demirbank.kg/';
            methodName := 'CompanyCreditHistoryLoad';
            soapAction := namespace || methodName;
            namespace := 'xmlns="' || namespace || '"';

            --create new request
            req := Pkg_Soap.new_request(methodName, namespace);

            --add parameters to request
            Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
           
            --call web service, and get response
              resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap

            resultc := resp.doc.getclobval();
            
            UPDATE CBS_CIB_COMPANY_CREDIT_HISTORY SET HISTORY_OBJ = resultc where GUID = ps_guid;
            COMMIT;
        ELSE 
            
            SELECT HISTORY_OBJ INTO resultc  FROM CBS_CIB_COMPANY_CREDIT_HISTORY  where GUID = ps_guid AND STATUS IN (3,4,5) AND HISTORY_OBJ is not null;                             
        END IF;
                                 
                    
        OPEN pc_ref_out FOR 
        SELECT extractvalue(column_value, '/Credit/CreditStatusEx/Description') status,
                    extractvalue(column_value, '/Credit/CreditType/Description') credit_type,
                    extractvalue(column_value, '/Credit/Amount') amount,
                    to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD') date_award,
                    to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') date_stop,
                    trunc(months_between(to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') , to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'))) || ' мес. ' ||
                    (to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') - ADD_MONTHS (to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'),
                             TRUNC (MONTHS_BETWEEN (to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD'), to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'))
                            )) || ' дн.')  loan_term,  
                    extractvalue(column_value, '/Credit/Currency/Description') currency,
                   PKG_CIB_TRANSACTION.GetCompanyCreditRelevance(t.extract('/Credit/DebtorsUL').getclobval(), ps_name, pd_bdate) relevance_type,
                    extractvalue(column_value, '/Credit/CountOfDelinquency') pastdue_no,
                    extractvalue(column_value, '/Credit/RepayStatus/Code') pastdue_duration_code,
                    extractvalue(column_value, '/Credit/RepayStatus/Description') pastdue_duration,
                    extractvalue(column_value, '/Credit/Fcu/Name') ||  ' / ' ||  extractvalue(column_value, '/Credit/Fcu/BranchName') given_by            
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/CompanyCreditHistoryLoadResponse/CompanyCreditHistoryLoadResult/CreditsHistory/Credit'))) t;            
       
      OPEN pc_ref_requests FOR
      SELECT  extractvalue(column_value, '/CompanyRequest/TimeOfTheRequest') request_date,
                   (extractvalue(column_value, '/CompanyRequest/Fcu/Name')  || ' ' || extractvalue(column_value, '/CompanyRequest/Fcu/BranchName'))   request_source
      FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/CompanyCreditHistoryLoadResponse/CompanyCreditHistoryLoadResult/RequestsHistory/CompanyRequest'))) t;            
           
     EXCEPTION
        WHEN OTHERS THEN
        AddRequestLog('CompanyCreditHistoryLoad', req.body, sqlerrm);           
        RAISE; 
                                       
end;
PROCEDURE GetCompanyCreditHistory(ps_name VARCHAR2, pn_org_form_code NUMBER, ps_country_code VARCHAR2, 
                                                        pd_bdate DATE, ps_inn VARCHAR2, 
                                                        ps_okpo VARCHAR2, ps_statcom VARCHAR2,
                                                        ps_guid IN OUT VARCHAR2,
                                                        pc_ref_result   OUT RefCursorType,
                                                        ps_status_txt OUT VARCHAR2,
                                                        pc_ref_requests OUT RefCursorType
                                                    ) IS
                                                    
     ls_local_guid VARCHAR2(50) := NULL;
     lb_ready BOOLEAN := FALSE;
    
     ls_status_txt VARCHAR2(500);
     ls_gethistory_status VARCHAR2(50); 
     err_msg VARCHAR2(2000);


BEGIN
                                                       
    IF ps_guid IS NULL THEN --NO REQUEST WAS MAID PREVIOUSLY
         --CALL WS TO GET GUID
      
        ls_local_guid := GetCompanyGuid(ps_name, pn_org_form_code, ps_country_code,  pd_bdate, ps_inn, ps_okpo, ps_statcom);
                  
       /* INSERT INTO CBS_CIB_COMPANY_CREDIT_HISTORY(CBS_CIB_COMPANY_CREDIT_HISTORY.ID, GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, ORGFORM_CODE, COMPANY_NAME, INN_CODE, OKPO_CODE, COMPANY_BDATE, STATUS_TEXT) 
        VALUES(company_credit_history_seq.nextval, ls_local_guid, -1, NULL, NULL, pn_org_form_code, ps_name, ps_inn, ps_okpo, pd_bdate, NULL);*/
           INSERT INTO CBS_CIB_COMPANY_CREDIT_HISTORY(GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, ORGFORM_CODE, COMPANY_NAME, INN_CODE, OKPO_CODE, COMPANY_BDATE, STATUS_TEXT) 
            VALUES(ls_local_guid, -1, NULL, NULL, pn_org_form_code, ps_name, ps_inn, ps_okpo, pd_bdate, NULL);
        
        COMMIT;
        
    ELSE
        ls_local_guid :=  ps_guid;   
    END IF;
    
-- CHECK IF GUID HAS STATUS READY (3,4,5), THEN SAVE GUID, STATUS, STATUS_OBJ  
    lb_ready := pkg_cib_transaction.CompanyCreditHistoryReady(ls_local_guid, ps_status_txt);
    
  -- IF GUID IS READY CALL WS TO GET PERSON CREDIT HISTORY, THEN SAVE IT TO DB    
    IF lb_ready  THEN
     GetCompanyCreditHistoryH(ls_local_guid, ps_name, pd_bdate, pc_ref_result,  pc_ref_requests);
    ELSE
        pc_ref_result := NULL;
        pc_ref_requests := NULL;
    END IF;
    
    ps_guid := ls_local_guid;
-- PARSE IT AND RETURN VISIT REF CURSOR

EXCEPTION
   WHEN OTHERS THEN
     /* err_code := SQLCODE;*/
      err_msg := SUBSTR(SQLERRM, 1, 1000);
      ls_status_txt := substr(err_msg, INSTR(err_msg, 'System.Exception'));
      ls_status_txt := substr(ls_status_txt, 1, INSTR(ls_status_txt, 'at') - 5 );
      ps_status_txt := ls_status_txt;
      
      log_at('cib', err_msg, 'guid = ' || ps_guid);
      
END;
FUNCTION CompanyCreditHistoryExcel(ps_guid IN VARCHAR2) RETURN BOOLEAN IS 

 l_blob           BLOB;
 
 ln_count NUMBER;
 
 lb_result BOOLEAN;
 
BEGIN
            SELECT COUNT(*) INTO ln_count FROM CBS_CIB_EXCEL_FILE where GUID = ps_guid and CUSTOMER_TYPE = 'C';
            
            if nvl(ln_count, 0) <> 0 then 
                return TRUE;
            end if;
            
             DBMS_LOB.createtemporary(l_blob, FALSE);
             
            Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   

            namespace := 'http://services.demirbank.kg/';
            methodName := 'CompanyCreditHistoryExcel';
            soapAction := namespace || methodName;
            namespace := 'xmlns="' || namespace || '"';
             
            --create new request
            req := Pkg_Soap.new_request(methodName, namespace);
     
            --add parameters to request
            Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
               
            --call web service, and get response
            l_blob := Pkg_Soap.invoke_utf8_v11_cib_binary(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap 
           
           --insert blob into a table
            IF DBMS_LOB.GETLENGTH(l_blob) > 0 and l_blob is not null then
            
                INSERT INTO CBS_CIB_EXCEL_FILE (GUID, FILE_BLOB, CUSTOMER_TYPE)
                VALUES (ps_guid, l_blob, 'C');
                commit;
              
              DBMS_LOB.freetemporary(l_blob);
              RETURN TRUE;
              
             else
                   AddRequestLog('CompanyCreditHistoryExcel', req.body, 'Web service returned empty blob');
                
                  --DBMS_LOB.freetemporary(l_blob);
                  RETURN false;
              
            end if ;
            
    Exception
        when others then
            DBMS_LOB.freetemporary(l_blob);
            AddRequestLog('CompanyCreditHistoryExcel', req.body, sqlerrm);
            RETURN FALSE;

END; 

----------------------------------------------------------PERSON METHODS-----------------------------------------------------------------------------
FUNCTION GetPersonGuid(ps_firstname VARCHAR2, ps_secondname VARCHAR2, 
                                        ps_lastname VARCHAR2,  pd_bdate DATE, ps_sex_code VARCHAR2, 
                                        ps_social_code VARCHAR2, ps_country_code VARCHAR2, pn_document_type NUMBER, 
                                        ps_document_number VARCHAR2) RETURN VARCHAR2 IS
                            
   cursor pc_ref(resultc in clob) is 
        SELECT extractvalue(column_value, '/Id') guid
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/PersonRequestNewResponse/PersonRequestNewResult/Id'))) t;
        
   row_auth pc_ref%ROWTYPE;
   
BEGIN
        Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
        
        namespace := 'http://services.demirbank.kg/';
        methodName := 'PersonRequestNew';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
     
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'firstname', 'xsd:string', ps_firstname);
        Pkg_Soap.add_parameter(req, 'lastname', 'xsd:string', ps_lastname);
        Pkg_Soap.add_parameter(req, 'middlename', 'xsd:string', ps_secondname);
        Pkg_Soap.add_parameter(req, 'birthdate_year', 'xsd:int', to_number(to_char(pd_bdate, 'YYYY')));
        Pkg_Soap.add_parameter(req, 'birthdate_month', 'xsd:int', to_number(to_char(pd_bdate, 'MM')));
        Pkg_Soap.add_parameter(req, 'birthdate_day', 'xsd:int', to_number(to_char(pd_bdate, 'DD')));
        Pkg_Soap.add_parameter(req, 'sex_code', 'xsd:string', ps_sex_code);
        Pkg_Soap.add_parameter(req, 'social_code', 'xsd:string', ps_social_code);
        Pkg_Soap.add_parameter(req, 'document_number', 'xsd:string',  ps_document_number);
        Pkg_Soap.add_parameter(req, 'document_type', 'xsd:int', pn_document_type);
        Pkg_Soap.add_parameter(req, 'country_code', 'xsd:string', ps_country_code);
                    
        --call web service, and get response
                
       resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap   
     
        resultc := resp.doc.getclobval();                        

                                 
        OPEN pc_ref(resultc);

        FETCH pc_ref INTO row_auth; 
          
          IF pc_ref%FOUND THEN 
            RETURN row_auth.guid;      
        END IF;
        
        IF pc_ref%NOTFOUND THEN        
                 RETURN NULL;
        END IF;
        
        CLOSE pc_ref;
    EXCEPTION 
        WHEN OTHERS THEN
    
        if instr(sqlerrm, 'System.Exception') = 0 --if not input related error then log
        then
             AddRequestLog('PersonRequestNew', req.body, sqlerrm); 
        end if;
      
        if pc_ref%ISOPEN THEN
            CLOSE pc_ref;
        end if;
        
        RAISE;
END;
FUNCTION PersonCreditHistoryReady(ps_guid IN VARCHAR2, ps_status_txt OUT VARCHAR2) RETURN BOOLEAN IS

   cursor pc_ref(resultc in clob) is 
            SELECT extractvalue(column_value, '/PersonCreditHistoryIsReadyResult/Id') status_no,
                        extractvalue(column_value, '/PersonCreditHistoryIsReadyResult/Description') description
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/PersonCreditHistoryIsReadyResponse/PersonCreditHistoryIsReadyResult'))) t;
        
   row_auth pc_ref%ROWTYPE;
   lb_status BOOLEAN := FALSE;
   ln_count NUMBER :=0;
   
   ln_current_status NUMBER := 0;
BEGIN


        SELECT STATUS INTO ln_current_status FROM CBS_CIB_PERSON_CREDIT_HISTORY WHERE GUID = ps_guid;
        IF ln_current_status IN (3,4,5) THEN
            SELECT (STATUS || ' - ' || STATUS_TEXT) INTO ps_status_txt  FROM CBS_CIB_PERSON_CREDIT_HISTORY WHERE GUID = ps_guid;  
            RETURN TRUE;
        END IF;
           
        
        Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
    
        namespace := 'http://services.demirbank.kg/';
        methodName := 'PersonCreditHistoryIsReady';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
       
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
                 
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction); -- TDL: implement in pkg_soap  
    
        resultc := resp.doc.getclobval();
        
         --AddRequestLog('PersonCreditHistoryIsReady', req.body,substr(resultc,1,4000)) ; 
         
        OPEN pc_ref(resultc);

        FETCH pc_ref INTO row_auth;
        
          IF pc_ref%FOUND THEN
               
               if to_number(row_auth.status_no) IN (3,4,5) then
                    lb_status := TRUE;
               end if;               
                
               SELECT COUNT(*) INTO ln_count FROM cbs_cib_person_credit_history WHERE guid = ps_guid;
                
               IF ln_count = 1 THEN
                    UPDATE CBS_CIB_PERSON_CREDIT_HISTORY 
                    SET STATUS = row_auth.status_no, STATUS_TEXT = row_auth.description, STATUS_OBJ = resultc
                    WHERE GUID = ps_guid;
                    COMMIT;
               END IF;
                    ps_status_txt := row_auth.status_no || ' - ' || row_auth.description ;
                
               RETURN lb_status;
        ELSE
            
                ps_status_txt := 'ERROR';  
               RETURN FALSE;
        END IF;
        
       EXCEPTION
            WHEN OTHERS THEN
               
           AddRequestLog('PersonCreditHistoryIsReady', req.body, sqlerrm); 
      
           if pc_ref%ISOPEN THEN
                CLOSE pc_ref;
            end if;
            
            RAISE;
END;
FUNCTION GetPersonCreditRelevance(pclob_debtors CLOB, ps_firstname VARCHAR2, ps_lastname VARCHAR2, pd_bdate DATE) RETURN VARCHAR2 IS

cursor pc_debtors(resultc in clob) is 
  SELECT extractvalue(column_value, '/Debtor/Lastname') lastname,
              extractvalue(column_value, '/Debtor/Firstname') firstname,
              extractvalue(column_value, '/Debtor/BirthDate') bdate
  FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/Debtors/Debtor'))) t;
  
       row_debtors pc_debtors%ROWTYPE;
BEGIN


    OPEN pc_debtors(pclob_debtors);
    
     FETCH pc_debtors INTO row_debtors;
        
        WHILE  pc_debtors%FOUND
        LOOP
              
              if UPPER(TRIM(ps_firstname)) = UPPER(TRIM(row_debtors.firstname)) AND UPPER(TRIM(ps_lastname)) = UPPER(TRIM(row_debtors.lastname)) AND pd_bdate = to_date(substr(row_debtors.bdate, 1, 10), 'YYYY-MM-DD') then
                    return 'Заемщик';
              end if;
               
         FETCH pc_debtors INTO row_debtors;
        END LOOP;
        
        CLOSE pc_debtors;

  return 'Поручитель';
END;
PROCEDURE GetPersonCreditHistoryH(ps_guid  IN  VARCHAR2, ps_firstname VARCHAR2, ps_lastname VARCHAR2, pd_bdate DATE,
                                        pc_ref_out OUT RefCursorType, pc_ref_requests OUT RefCursorType)  is
   
   ln_count NUMBER := 0;
begin
   
        SELECT COUNT(*) INTO ln_count FROM CBS_CIB_PERSON_CREDIT_HISTORY WHERE GUID = ps_guid AND STATUS IN (3,4,5) AND HISTORY_OBJ is not null;
    
        IF ln_count = 0 THEN
            Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   

            namespace := 'http://services.demirbank.kg/';
            methodName := 'PersonCreditHistoryLoad';
            soapAction := namespace || methodName;
            namespace := 'xmlns="' || namespace || '"';

            --create new request
            req := Pkg_Soap.new_request(methodName, namespace);

            --add parameters to request
            Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
           
            --call web service, and get response
            resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap  

            resultc := resp.doc.getclobval();
            
            UPDATE CBS_CIB_PERSON_CREDIT_HISTORY SET HISTORY_OBJ = resultc where GUID = ps_guid;
            COMMIT;
        ELSE 
            
            SELECT HISTORY_OBJ INTO resultc  FROM CBS_CIB_PERSON_CREDIT_HISTORY  where GUID = ps_guid AND STATUS IN (3,4,5) AND HISTORY_OBJ is not null;                             
        END IF;
                                                    
        OPEN pc_ref_out FOR 
        SELECT extractvalue(column_value, '/Credit/CreditStatusEx/Description') status,
                    extractvalue(column_value, '/Credit/CreditType/Description') credit_type,
                    extractvalue(column_value, '/Credit/Amount') amount,
                    to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD') date_award,
                    to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') date_stop,
                    trunc(months_between(to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') , to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'))) || ' мес. ' ||
                    (to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD') - ADD_MONTHS (to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'),
                             TRUNC (MONTHS_BETWEEN (to_date(substr(extractvalue(column_value, '/Credit/DateStop'), 1, 10), 'YYYY-MM-DD'), to_date(substr(extractvalue(column_value, '/Credit/DateAward') , 1, 10), 'YYYY-MM-DD'))
                            )) || ' дн.')  loan_term,  
                    extractvalue(column_value, '/Credit/Currency/Description') currency,
                    pkg_cib_transaction.GetPersonCreditRelevance(t.extract('/Credit/Debtors').getclobval(), ps_firstname, ps_lastname, pd_bdate) relevance_type,
                    extractvalue(column_value, '/Credit/CountOfDelinquency') pastdue_no,
                    extractvalue(column_value, '/Credit/RepayStatus/Code') pastdue_duration_code,
                    extractvalue(column_value, '/Credit/RepayStatus/Description') pastdue_duration,
                    extractvalue(column_value, '/Credit/Fcu/Name') ||  ' / ' ||  extractvalue(column_value, '/Credit/Fcu/BranchName') given_by            
        FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/PersonCreditHistoryLoadResponse/PersonCreditHistoryLoadResult/CreditsHistory/Credit'))) t;            
       
      OPEN pc_ref_requests FOR
      SELECT  extractvalue(column_value, '/PersonRequest/TimeOfTheRequest') request_date,
                   (extractvalue(column_value, '/PersonRequest/Fcu/Name')  || ' ' || extractvalue(column_value, '/PersonRequest/Fcu/BranchName'))   request_source
      FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/PersonCreditHistoryLoadResponse/PersonCreditHistoryLoadResult/RequestsHistory/PersonRequest'))) t;            
      
      
    EXCEPTION
        WHEN OTHERS THEN
        AddRequestLog('PersonCreditHistoryLoad', req.body, sqlerrm);           
        RAISE;                                   
end;                            
PROCEDURE GetPersonCreditHistory(ps_firstname VARCHAR2, ps_secondname VARCHAR2, ps_lastname VARCHAR2,  pd_bdate DATE, ps_sex_code VARCHAR2, 
                                                    ps_social_code VARCHAR2, ps_country_code VARCHAR2, pn_document_type NUMBER, ps_document_number VARCHAR2,
                                                    ps_guid IN OUT VARCHAR2,
                                                    pc_ref_result   OUT RefCursorType,
                                                    ps_status_txt OUT VARCHAR2,
                                                    pc_ref_requests OUT RefCursorType
                                                    ) IS
                                                    
     ls_local_guid VARCHAR2(50) := NULL;
     lb_ready BOOLEAN := FALSE;
    
     ls_status_txt VARCHAR2(500);
BEGIN
                                                       
    IF ps_guid IS NULL THEN --NO REQUEST WAS MADE PREVIOUSLY
         --CALL WS TO GET GUID
         ls_local_guid := GetPersonGuid(ps_firstname, ps_secondname, ps_lastname,  pd_bdate, ps_sex_code, ps_social_code, ps_country_code, pn_document_type, ps_document_number);
        
        IF ls_local_guid IS NULL THEN
            pc_ref_result := NULL;
            pc_ref_requests := NULL;
            ps_status_txt := 'Error: Web service returned GUID = NULL';
            RETURN;
        END IF;
               
        /*INSERT INTO CBS_CIB_PERSON_CREDIT_HISTORY(CBS_CIB_PERSON_CREDIT_HISTORY.ID, GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, PERSON_FIRSTNAME, PERSON_LASTNAME, PERSON_BDATE, PERSON_DOC_TYPE, PERSON_DOC_NO, STATUS_TEXT) 
        VALUES(cib_credit_history.nextval, ls_local_guid, -1, NULL, NULL, ps_firstname, ps_lastname, pd_bdate, pn_document_type,  ps_document_number, NULL);*/
        INSERT INTO CBS_CIB_PERSON_CREDIT_HISTORY(GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, PERSON_FIRSTNAME, PERSON_LASTNAME, PERSON_BDATE, PERSON_DOC_TYPE, PERSON_DOC_NO, STATUS_TEXT) 
        VALUES(ls_local_guid, -1, NULL, NULL, ps_firstname, ps_lastname, pd_bdate, pn_document_type,  ps_document_number, NULL);
        COMMIT;
        
    ELSE
        ls_local_guid :=  ps_guid;   
    END IF;
    
-- CHECK IF GUID HAS STATUS READY (3,4,5), THEN SAVE GUID, STATUS, STATUS_OBJ  
    lb_ready := PersonCreditHistoryReady(ls_local_guid, ps_status_txt);
    
  -- IF GUID IS READY CALL WS TO GET PERSON CREDIT HISTORY, THEN SAVE IT TO DB    
    IF lb_ready THEN
      GetPersonCreditHistoryH(ls_local_guid, ps_firstname, ps_lastname, pd_bdate, pc_ref_result,  pc_ref_requests);
    ELSE
        pc_ref_result := NULL;
        pc_ref_requests := NULL;
    END IF;
    
    ps_guid := ls_local_guid;

EXCEPTION
   WHEN OTHERS THEN
  
      if instr(sqlerrm, 'System.Exception') > 0 and instr(sqlerrm, 'at') > 0 and instr(sqlerrm, 'at') < 1000
      then
          ls_status_txt := substr(SQLERRM, INSTR(SQLERRM, 'System.Exception'));
          ls_status_txt := substr(ls_status_txt, 1, INSTR(ls_status_txt, 'at') - 5 );
          ps_status_txt := trim(substr(ls_status_txt, 18));
      else
        ps_status_txt := substr(SQLERRM, 1, 9999);
      end if;
      
      pc_ref_result := NULL;
      pc_ref_requests := NULL;

END;

FUNCTION PersonCreditHistoryExcel(ps_guid IN VARCHAR2) RETURN BOOLEAN IS 

 l_blob           BLOB;
 
 ln_count NUMBER;
 
 lb_result BOOLEAN;
 
BEGIN
            SELECT COUNT(*) INTO ln_count FROM CBS_CIB_EXCEL_FILE where GUID = ps_guid and CUSTOMER_TYPE = 'P';
            
            if nvl(ln_count, 0) <> 0 then 
                return TRUE;
            end if;
            
             DBMS_LOB.createtemporary(l_blob, TRUE);
             
            Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   

            namespace := 'http://services.demirbank.kg/';
            methodName := 'PersonCreditHistoryExcel';
            soapAction := namespace || methodName;
            namespace := 'xmlns="' || namespace || '"';
             
            --create new request
            req := Pkg_Soap.new_request(methodName, namespace);
     
            --add parameters to request
            Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ps_guid);
               
            --call web service, and get response
                         
             l_blob := Pkg_Soap.invoke_utf8_v11_cib_binary(req, serviceUrl, soapAction);  -- TDL: implement in pkg_soap
                          
           --insert blob into a table
            IF DBMS_LOB.GETLENGTH(l_blob) > 0 and l_blob  is not null then
            
                INSERT INTO CBS_CIB_EXCEL_FILE (GUID, FILE_BLOB, CUSTOMER_TYPE)
                VALUES (ps_guid, l_blob, 'P');
                commit;     
                        
                 DBMS_LOB.freetemporary(l_blob);             
              RETURN TRUE;              
              
             ELSE                           
                   AddRequestLog('PersonCreditHistoryExcel', req.body, 'Web service returned empty blob');              
                  RETURN false;              
            end if ;
            
    Exception
        when others then
             log_at('exce', ps_guid, '4 ' || sqlerrm);
            DBMS_LOB.freetemporary(l_blob);
            AddRequestLog('PersonCreditHistoryExcel', req.body, sqlerrm);
            RETURN FALSE;

END; 

--BOM, cq614, Erkin Z, 20.08.2017
Procedure SubmitPersonDataToCIB(ps_firstname VARCHAR2, ps_lastname VARCHAR2, pd_bdate DATE, ps_social_code VARCHAR2, ps_sex_code VARCHAR2,
                                pn_document_type NUMBER, ps_country_code VARCHAR2, ps_document_number VARCHAR2, ps_status_txt OUT VARCHAR2)
IS
    ls_local_guid VARCHAR2(50) := null;
    ls_status_txt VARCHAR2(500);
    ls_error_at VARCHAR2(100) := 'Error at '||ps_firstname||' '||ps_lastname||': ';

    cursor pc_ref(resultc in clob) is
    SELECT extractvalue(column_value, '/PersonCreditHistoryIsReadyResult/Id') status_no,
           extractvalue(column_value, '/PersonCreditHistoryIsReadyResult/Description') description
    FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/PersonCreditHistoryIsReadyResponse/PersonCreditHistoryIsReadyResult'))) t;       
    row_auth pc_ref%ROWTYPE;
    
begin
    ps_status_txt := '';
    --send data to CIB and get GUID  
    ls_local_guid := GetPersonGuid(ps_firstname, null, ps_lastname,  pd_bdate, ps_sex_code, 
                                                        ps_social_code, ps_country_code, pn_document_type, ps_document_number); 
                                                                                                                  
    if ls_local_guid is null then
        ps_status_txt := ls_error_at||'GUID is NULL'; 
        RETURN;
    end if;
    
    --get status of request by GUID
    Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
    
    namespace := 'http://services.demirbank.kg/';
    methodName := 'PersonCreditHistoryIsReady';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);
       
    --add parameters to request
    Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ls_local_guid);
                 
    --call web service, and get response
    resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction); -- TDL: implement in pkg_soap  
    
    resultc := resp.doc.getclobval();

    OPEN pc_ref(resultc);
    FETCH pc_ref INTO row_auth;
    if pc_ref%FOUND THEN
        insert into CBS_CIB_PERSON_CREDIT_HISTORY(GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, PERSON_FIRSTNAME, PERSON_LASTNAME, PERSON_BDATE, PERSON_DOC_TYPE, PERSON_DOC_NO, STATUS_TEXT)
        values(ls_local_guid, row_auth.status_no, resultc, null, replace(ps_firstname, '_', ' '), replace(ps_lastname, '_', ' '), pd_bdate, pn_document_type, ps_document_number, row_auth.description);
    else
        ps_status_txt := ls_error_at||'Cursor not found';  
        RETURN; 
    end if;
    
    --if by some magic reason status of request is already ready(3, 4, 5) then get the history and save
    if row_auth.status_no in (3, 4, 5) then
        namespace := 'http://services.demirbank.kg/';
        methodName := 'PersonCreditHistoryLoad';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';
        
        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
        
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ls_local_guid);
        
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);
        
        resultc := resp.doc.getclobval();
        
        update CBS_CIB_PERSON_CREDIT_HISTORY
        set HISTORY_OBJ = resultc
        where GUID = ls_local_guid;
    end if;
    
exception
    WHEN OTHERS THEN
      if instr(sqlerrm, 'System.Exception') > 0 and instr(sqlerrm, 'at') > 0 and instr(sqlerrm, 'at') < 1000
      then
          ls_status_txt := substr(SQLERRM, INSTR(SQLERRM, 'System.Exception'));
          ls_status_txt := substr(ls_status_txt, 1, INSTR(ls_status_txt, 'at') - 5 );
          ps_status_txt := ls_error_at||trim(substr(ls_status_txt, 18));
      else
          ps_status_txt := ls_error_at||substr(SQLERRM, 1, 100);
      end if;
end; 

Procedure SubmitCompanyDataToCIB(ps_name VARCHAR2, pn_org_form_code NUMBER, ps_country_code VARCHAR2, pd_bdate DATE, ps_inn VARCHAR2, 
                                                ps_status_txt OUT VARCHAR2)
IS
    ls_local_guid VARCHAR2(50) := null;
    ls_status_txt VARCHAR2(500);
    ls_error_at VARCHAR2(100) := 'Error at '||ps_name||': ';

    cursor pc_ref(resultc in clob) is 
    SELECT extractvalue(column_value, '/CompanyCreditHistoryIsReadyResult/Id') status_no,
           extractvalue(column_value, '/CompanyCreditHistoryIsReadyResult/Description') description
    FROM TABLE(XMLSequence(XMLTYPE(resultc).extract('/CompanyCreditHistoryIsReadyResponse/CompanyCreditHistoryIsReadyResult'))) t;
    row_auth pc_ref%ROWTYPE;
    
begin
    ps_status_txt := '';
    --send data to CIB and get GUID  
    ls_local_guid := GetCompanyGuid(ps_name, pn_org_form_code, ps_country_code,  pd_bdate, ps_inn, null, null);                                                       
    if ls_local_guid is null then
        ps_status_txt := ls_error_at||'GUID is NULL'; 
        RETURN;
    end if;
    
    --get status of request by GUID
    Pkg_Parametre.deger('CIB_WS_SERVICE_URL',serviceUrl);   
    
    namespace := 'http://services.demirbank.kg/';
    methodName := 'CompanyCreditHistoryIsReady';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);
       
    --add parameters to request
    Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ls_local_guid);
                 
    --call web service, and get response
    resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction); -- TDL: implement in pkg_soap 
    
    resultc := resp.doc.getclobval();

    OPEN pc_ref(resultc);
    FETCH pc_ref INTO row_auth;
    if pc_ref%FOUND THEN
        insert into CBS_CIB_COMPANY_CREDIT_HISTORY(GUID, STATUS, STATUS_OBJ, HISTORY_OBJ, ORGFORM_CODE, COMPANY_NAME, COMPANY_BDATE, STATUS_TEXT)
        values(ls_local_guid, row_auth.status_no, resultc, null, pn_org_form_code, ps_name, pd_bdate, row_auth.description);
    else
        ps_status_txt := ls_error_at||'Cursor not found';   
        RETURN;
    end if;
    
    --if by some magic reason status of request is already ready(3, 4, 5) then get the history and save
    if row_auth.status_no in (3, 4, 5) then
        namespace := 'http://services.demirbank.kg/';
        methodName := 'CompanyCreditHistoryLoad';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';
        
        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);
        
        --add parameters to request
        Pkg_Soap.add_parameter(req, 'guid', 'xsd:string', ls_local_guid);
        
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);
        
        resultc := resp.doc.getclobval();
        
        update CBS_CIB_PERSON_CREDIT_HISTORY
        set HISTORY_OBJ = resultc
        where GUID = ls_local_guid;
    end if;
    
exception
    WHEN OTHERS THEN
      if instr(sqlerrm, 'System.Exception') > 0 and instr(sqlerrm, 'at') > 0 and instr(sqlerrm, 'at') < 1000
      then
          ls_status_txt := substr(SQLERRM, INSTR(SQLERRM, 'System.Exception'));
          ls_status_txt := substr(ls_status_txt, 1, INSTR(ls_status_txt, 'at') - 5 );
          ps_status_txt := ls_error_at||trim(substr(ls_status_txt, 18));
      else
          ps_status_txt := ls_error_at||substr(SQLERRM, 1, 100);
      end if;
end; 

function getCountryCodeByDocType(docType cbs_cib_dir_document.id%type) return CBS_CIB_DIR_DOCUMENT.COUNTRY_CODE%type
is
countryCode CBS_CIB_DIR_DOCUMENT.COUNTRY_CODE%type;
begin

    select COUNTRY_CODE into countryCode
    from CBS_CIB_DIR_DOCUMENT
    where id = docType;

    return countryCode;

exception
    WHEN OTHERS THEN
    log_at('getCountryCodeByDocType', 'IN: '||docType||'; OUT: '||countryCode);
return null;
end;
--EOM, cq614, Erkin Z, 20.08.2017


END Pkg_Cib_Transaction;
/

