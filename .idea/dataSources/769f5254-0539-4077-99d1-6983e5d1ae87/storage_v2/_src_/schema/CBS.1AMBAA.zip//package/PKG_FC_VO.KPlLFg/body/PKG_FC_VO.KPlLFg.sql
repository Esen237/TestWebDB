create package body pkg_fc_vo is
         FUNCTION average_kzt_fiz(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type,
		                          p_sube_kodu in cbs_rpt_vadeli_ayyilsonu_faiz.SUBE_KODU%type)return number is
		   p_var number;
		 begin
		  SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		  into p_var
          FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		       cbs_rpt_fc_vo_faiz a
          where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                         bakiye<>0 and
                  	   URUN_TUR_KOD=p_urun_tur_kod and
					   sube_kodu=p_sube_kodu and
                  	   doviz_kodu = 'KZT' and
                  	   substr(musteri_dk_no, 6, 1)= '9';
		  return p_var;
         end average_kzt_fiz;

       FUNCTION average_kzt_fiz2(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type)return number is
		   p_var number;
		 begin
		  SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		  into p_var
          FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		       cbs_rpt_fc_vo_faiz a
          where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                         bakiye<>0 and
                  	   URUN_TUR_KOD=p_urun_tur_kod and
                  	   doviz_kodu = 'KZT' and
                  	   substr(musteri_dk_no, 6, 1)= '9';
		  return p_var;
         end average_kzt_fiz2;

         FUNCTION average_fc_fiz(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type,
		                          p_sube_kodu in cbs_rpt_vadeli_ayyilsonu_faiz.SUBE_KODU%type) return number IS
		 p_var number;
	     begin
	       SELECT  avg(FAIZ_ORANI) AVERAGE_FO
		   into p_var
                    FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                 cbs_rpt_fc_vo_faiz a
                    where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                    bakiye<>0 and
                  	URUN_TUR_KOD =p_urun_tur_kod and
					sube_kodu=p_sube_kodu and
                  	doviz_kodu <> 'KZT' and
                  	substr(musteri_dk_no, 6, 1)= '9' ;
		 return p_var;
	     end average_fc_fiz;


		 FUNCTION average_fc_fiz2(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type) return number IS
		 p_var number;
	     begin
	       SELECT  avg(FAIZ_ORANI) AVERAGE_FO
		   into p_var
                    FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                 cbs_rpt_fc_vo_faiz a
                    where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                    bakiye<>0 and
                  	URUN_TUR_KOD =p_urun_tur_kod and
					doviz_kodu <> 'KZT' and
                  	substr(musteri_dk_no, 6, 1)= '9' ;
		 return p_var;
	     end average_fc_fiz2;



  		 FUNCTION average_kzt_jur(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type,
		                           p_sube_kodu in cbs_rpt_vadeli_ayyilsonu_faiz.SUBE_KODU%type)return number is
		 p_var number;
          begin
		  SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		  into p_var
                    FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                 cbs_rpt_fc_vo_faiz a
                   where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                         bakiye<>0 and
                  	   URUN_TUR_KOD =p_urun_tur_kod and
					   sube_kodu=p_sube_kodu and
                  	   doviz_kodu = 'KZT' and
                  	   substr(musteri_dk_no, 6, 1)in ('5','6','7','8') ;
		 return p_var;
         end average_kzt_jur;


		 FUNCTION average_kzt_jur2(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type)return number is
		 p_var number;
          begin
		  SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		  into p_var
                    FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                 cbs_rpt_fc_vo_faiz a
                   where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                         bakiye<>0 and
                  	   URUN_TUR_KOD =p_urun_tur_kod and
                  	   doviz_kodu = 'KZT' and
                  	   substr(musteri_dk_no, 6, 1)in ('5','6','7','8') ;
		 return p_var;
         end average_kzt_jur2;




       FUNCTION average_fc_jur(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type,
	                           p_sube_kodu in cbs_rpt_vadeli_ayyilsonu_faiz.SUBE_KODU%type)return number IS
	   p_var number;
    	begin
    	SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		into p_var
                        FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                cbs_rpt_fc_vo_faiz a
                       where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                             bakiye<>0 and
                      	   URUN_TUR_KOD =p_urun_tur_kod and
						   sube_kodu=p_sube_kodu and
                      	   doviz_kodu <> 'KZT' and
                      	   substr(musteri_dk_no, 6, 1)in ('5','6','7','8');
		return p_var;
    	  end average_fc_jur;


		  FUNCTION average_fc_jur2(p_urun_tur_kod in cbs_rpt_vadeli_AYYILSONU_FAIZ.URUN_TUR_KOD%type)return number IS
	   p_var number;
    	begin
    	SELECT   avg(FAIZ_ORANI) AVERAGE_FO
		into p_var
                        FROM CBS_RPT_VADELI_AYYILSONU_FAIZ,
		                cbs_rpt_fc_vo_faiz a
                       where BANKA_TARIHI=to_date('30062006','DDMMYYYY') and
                             bakiye<>0 and
                      	   URUN_TUR_KOD =p_urun_tur_kod and
                      	   doviz_kodu <> 'KZT' and
                      	   substr(musteri_dk_no, 6, 1)in ('5','6','7','8');
		return p_var;
    	  end average_fc_jur2;



		/*procedure balance is
		p_balance varchar2(30);
		begin
		  select
		  Case When ((Substr(Numara, 1, 4) Like '1%' Or Substr(Numara, 1, 4) Like '5%') And Bakiye_Lc >0)
		   Or ((Substr(Numara, 1, 4) Like '2%' Or Substr(Numara, 1, 4) Like '3%'
		   Or Substr(Numara, 1, 4) Like '4%') And Bakiye_Lc < 0)
		   Then -abs(Nvl(Bakiye_Lc, 0))
		   Else Abs(Nvl(Bakiye_Lc, 0))end balance1
		   into  p_balance
		   from cbs_Dkhesap_Gunluk_Bakiye

	    end	balance;		*/
  end pkg_fc_vo;
/

