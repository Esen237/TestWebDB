create PACKAGE BODY     "PKG_INT_EMAIL" IS

--Return the next email address in the list of email addresses, separated
  -- by either a "," or a ";".  The format of mailbox may be in one of these:
  --   someone@some-domain
  --   "Someone at some domain" <someone@some-domain>
  --   Someone at some domain <someone@some-domain>
  FUNCTION get_address(addr_list IN OUT VARCHAR2) RETURN VARCHAR2 IS

    addr VARCHAR2(256);
    i    PLS_INTEGER;

    FUNCTION lookup_unquoted_char(str  IN VARCHAR2,
				  chrs IN VARCHAR2) RETURN PLS_INTEGER AS
      c            VARCHAR2(5);
      i            PLS_INTEGER;
      len          PLS_INTEGER;
      inside_quote BOOLEAN;
    BEGIN
       inside_quote := FALSE;
       i := 1;
       len := LENGTH(str);
       WHILE (i <= len) LOOP

	 c := SUBSTR(str, i, 1);

	 IF (inside_quote) THEN
	   IF (c = '"') THEN
	     inside_quote := FALSE;
	   ELSIF (c = '\') THEN
	     i := i + 1; -- Skip the quote character
	   END IF;
	   GOTO next_char;
	 END IF;

	 IF (c = '"') THEN
	   inside_quote := TRUE;
	   GOTO next_char;
	 END IF;

	 IF (INSTR(chrs, c) >= 1) THEN
	    RETURN i;
	 END IF;

	 <<next_char>>
	 i := i + 1;

       END LOOP;

       RETURN 0;

    END;

  BEGIN

    addr_list := LTRIM(addr_list);
    i := lookup_unquoted_char(addr_list, ',;');
    IF (i >= 1) THEN
      addr      := SUBSTR(addr_list, 1, i - 1);
      addr_list := SUBSTR(addr_list, i + 1);
    ELSE
      addr := addr_list;
      addr_list := '';
    END IF;

    i := lookup_unquoted_char(addr, '<');
    IF (i >= 1) THEN
      addr := SUBSTR(addr, i + 1);
      i := INSTR(addr, '>');
      IF (i >= 1) THEN
	addr := SUBSTR(addr, 1, i - 1);
      END IF;
    END IF;

    RETURN addr;
  END;

  -- Write a MIME header
  PROCEDURE write_mime_header(conn  IN OUT NOCOPY utl_smtp.connection,
			      NAME  IN VARCHAR2,
			      VALUE IN VARCHAR2) IS
  BEGIN
    utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(NAME) || utl_raw.cast_to_raw(': ') || utl_raw.cast_to_raw(VALUE) || utl_raw.cast_to_raw(utl_tcp.CRLF));
  END;

  -- Mark a message-part boundary.  Set <last> to TRUE for the last boundary.
  PROCEDURE write_boundary(conn  IN OUT NOCOPY utl_smtp.connection,
			   LAST  IN            BOOLEAN DEFAULT FALSE) AS
  BEGIN
    IF (LAST) THEN
      utl_smtp.write_data(conn, LAST_BOUNDARY);
    ELSE
      utl_smtp.write_data(conn, FIRST_BOUNDARY);
    END IF;
  END;

  ------------------------------------------------------------------------
  PROCEDURE mail(sender     IN VARCHAR2,
		 recipients IN VARCHAR2,
		 subject    IN VARCHAR2,
		 message    IN VARCHAR2) IS
    conn utl_smtp.connection;
  BEGIN
    conn := begin_mail(sender, recipients, subject);
    write_text(conn, message);
    end_mail(conn);
  END;

  ------------------------------------------------------------------------
  FUNCTION begin_mail(sender     IN VARCHAR2,
		      recipients IN VARCHAR2,
		      subject    IN VARCHAR2,
		      mime_type  IN VARCHAR2    DEFAULT 'text/plain; charset=''windows-1254'' ',
		      priority   IN PLS_INTEGER DEFAULT NULL)
		      RETURN utl_smtp.connection IS
    conn utl_smtp.connection;
  BEGIN
    conn := begin_session;
    begin_mail_in_session(conn, sender, recipients, subject, mime_type,
      priority);
    RETURN conn;
  END;

  ------------------------------------------------------------------------
  PROCEDURE write_text(conn    IN OUT NOCOPY utl_smtp.connection,
		       message IN VARCHAR2) IS
  BEGIN
    utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(message));
  END;

 --------------------------
  PROCEDURE write_text2(conn    IN OUT NOCOPY utl_smtp.connection,
		       message IN CLOB) IS
			   strTemp VARCHAR2(32767);
			   i NUMBER:=-99;
			   k NUMBER:=100;
  BEGIN
    -- buraya ?zellikle clob verdim ??nk? text metni ?ok b?y?k olabilir...
	-- varchar2 en fazla 32000 karakter tutabiliyor ancak clob 2 gb ..

	 LOOP
	   i:=i+k;
	   dbms_lob.READ(message,k,i,strTemp);
       --utl_smtp.write_data(conn, strTemp);
	   utl_smtp.write_raw_data(conn,utl_raw.cast_to_raw(strTemp));
	 EXIT WHEN (dbms_lob.getlength(message) < i + k);
     END LOOP;
  END;
  ------------------------------------------------------------------------
  PROCEDURE write_mb_text(conn    IN OUT NOCOPY utl_smtp.connection,
			  message IN            VARCHAR2) IS
  BEGIN
    utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(message));
  END;

  ------------------------------------------------------------------------
  PROCEDURE write_raw(conn    IN OUT NOCOPY utl_smtp.connection,
		      message IN RAW) IS
  BEGIN
    utl_smtp.write_raw_data(conn, message);
  END;

  ------------------------------------------------------------------------
  PROCEDURE attach_text(conn         IN OUT NOCOPY utl_smtp.connection,
			DATA         IN VARCHAR2,
			mime_type    IN VARCHAR2 DEFAULT 'text/plain',
			inline       IN BOOLEAN  DEFAULT TRUE,
			filename     IN VARCHAR2 DEFAULT NULL,
		        LAST         IN BOOLEAN  DEFAULT FALSE) IS
  BEGIN
    begin_attachment(conn, mime_type, inline, filename);
    write_text(conn, DATA);
    end_attachment(conn, LAST);
  END;

  ------------------------------------------------------------------------
  PROCEDURE attach_base64(conn         IN OUT NOCOPY utl_smtp.connection,
			  DATA         IN RAW,
			  mime_type    IN VARCHAR2 DEFAULT 'application/octet',
			  inline       IN BOOLEAN  DEFAULT TRUE,
			  filename     IN VARCHAR2 DEFAULT NULL,
			  LAST         IN BOOLEAN  DEFAULT FALSE) IS
    i   PLS_INTEGER;
    len PLS_INTEGER;
  BEGIN

    begin_attachment(conn, mime_type, inline, filename, 'base64');

    -- Split the Base64-encoded attachment into multiple lines
    i   := 1;
    len := utl_raw.LENGTH(DATA);
    WHILE (i < len) LOOP
       IF (i + MAX_BASE64_LINE_WIDTH < len) THEN
	 utl_smtp.write_raw_data(conn,
	    utl_encode.base64_encode(utl_raw.SUBSTR(DATA, i,
	    MAX_BASE64_LINE_WIDTH)));
       ELSE
	 utl_smtp.write_raw_data(conn,
	   utl_encode.base64_encode(utl_raw.SUBSTR(DATA, i)));
       END IF;
       utl_smtp.write_data(conn, utl_tcp.CRLF);
       i := i + MAX_BASE64_LINE_WIDTH;
    END LOOP;

    end_attachment(conn, LAST);

  END;

  ------------------------------------------------------------------------
  PROCEDURE begin_attachment(conn         IN OUT NOCOPY utl_smtp.connection,
			     mime_type    IN VARCHAR2 DEFAULT 'text/plain',
			     inline       IN BOOLEAN  DEFAULT TRUE,
			     filename     IN VARCHAR2 DEFAULT NULL,
			     transfer_enc IN VARCHAR2 DEFAULT NULL) IS
  BEGIN
    write_boundary(conn);
    write_mime_header(conn, 'Content-Type', mime_type);

    IF (filename IS NOT NULL) THEN
       IF (inline) THEN
	  write_mime_header(conn, 'Content-Disposition',
	    'inline; filename="'||filename||'"');
       ELSE
	  write_mime_header(conn, 'Content-Disposition',
	    'attachment; filename="'||filename||'"');
       END IF;
    END IF;

    IF (transfer_enc IS NOT NULL) THEN
      write_mime_header(conn, 'Content-Transfer-Encoding', transfer_enc);
    END IF;

    utl_smtp.write_data(conn, utl_tcp.CRLF);
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_attachment(conn IN OUT NOCOPY utl_smtp.connection,
			   LAST IN BOOLEAN DEFAULT FALSE) IS
  BEGIN
    utl_smtp.write_data(conn, utl_tcp.CRLF);
    IF (LAST) THEN
      write_boundary(conn, LAST);
    END IF;
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_mail(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    end_mail_in_session(conn);
    end_session(conn);
  END;

  ------------------------------------------------------------------------
  FUNCTION begin_session RETURN utl_smtp.connection IS
    conn utl_smtp.connection;
  BEGIN
    -- open SMTP connection
    conn := utl_smtp.open_connection(smtp_host, smtp_port);
    utl_smtp.helo(conn, smtp_domain);
    RETURN conn;
  END;

  ------------------------------------------------------------------------
  PROCEDURE begin_mail_in_session(conn       IN OUT NOCOPY utl_smtp.connection,
				  sender     IN VARCHAR2,
				  recipients IN VARCHAR2,
				  subject    IN VARCHAR2,
				  mime_type  IN VARCHAR2  DEFAULT 'text/plain; charset=''windows-1254''',
				  priority   IN PLS_INTEGER DEFAULT NULL) IS
    my_recipients VARCHAR2(32767) := recipients;
    my_sender     VARCHAR2(32767) := sender;
  BEGIN

    -- Specify sender's address (our server allows bogus address
    -- as long as it is a full email address (xxx@yyy.com).
    utl_smtp.mail(conn, get_address(my_sender));

    -- Specify recipient(s) of the email.
    WHILE (my_recipients IS NOT NULL) LOOP
      utl_smtp.rcpt(conn, get_address(my_recipients));
    END LOOP;

    -- Start body of email
    utl_smtp.open_data(conn);

    -- Set "From" MIME header
    write_mime_header(conn, 'From', sender);

    -- Set "To" MIME header
    write_mime_header(conn, 'To', recipients);

    -- Set "Subject" MIME header
    write_mime_header(conn, 'Subject', subject);

    -- Set "Content-Type" MIME header
    write_mime_header(conn, 'Content-Type', mime_type);

    write_mime_header(conn, 'Content-Transfer-Encoding', '8bit');

    -- Set "X-Mailer" MIME header
    write_mime_header(conn, 'X-Mailer', MAILER_ID);

    -- Set priority:
    --   High      Normal       Low
    --   1     2     3     4     5
    IF (priority IS NOT NULL) THEN
      write_mime_header(conn, 'X-Priority', priority);
    END IF;

    -- Send an empty line to denotes end of MIME headers and
    -- beginning of message body.
    utl_smtp.write_data(conn, utl_tcp.CRLF);

    IF (mime_type LIKE 'multipart/mixed%') THEN
      write_text(conn, 'This is a multi-part message in MIME format.' ||
	utl_tcp.crlf);
    END IF;

  END;

  ------------------------------------------------------------------------
  PROCEDURE end_mail_in_session(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    utl_smtp.close_data(conn);
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_session(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    utl_smtp.quit(conn);
  END;

  ------------------------------------------------------------------------
  PROCEDURE SendHTMLEmail(ps_sender IN VARCHAR2, ps_recepient IN VARCHAR2, ps_subject IN VARCHAR2,ps_htmlcontent IN CLOB) IS
	conn utl_smtp.connection;
  BEGIN
	conn := Pkg_Int_Email.begin_mail(
	sender     => ps_sender,
	recipients => ps_recepient,
	subject    => ps_subject,
	mime_type  => 'text/html; charset=''ISO-8859-9''' );
--charset="ISO-8859-9"
	Pkg_Int_Email.write_text2(conn => conn,message => ps_htmlcontent);
	Pkg_Int_Email.end_mail( conn => conn );

  END;
  ------------------------------------------------------------------------
  PROCEDURE SendHTMLEmailToQueue(ps_MESSAGE_CODE  IN VARCHAR2,ps_sender IN VARCHAR2, ps_recepient IN VARCHAR2, ps_subject IN VARCHAR2,ps_htmlcontent IN CLOB) IS
  BEGIN
    Pkg_Email.AddToEmailQueue(ps_MESSAGE_CODE, 51, ps_sender, ps_recepient, ps_subject, ps_htmlcontent,'HTML');
  END;
  
  ------------------------------------------------------------------------
  PROCEDURE SendAutoMessages(ps_msgType IN VARCHAR2,
  							 ps_from IN VARCHAR2,
							 ps_to IN VARCHAR2,
							 ps_subject IN VARCHAR2,
							 ps_decontInfo IN VARCHAR2) IS
		ls_htmlcontent					 VARCHAR2(32000);
  BEGIN
     ls_htmlcontent :=
	 '<HTML>' ||
	 '<head><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">'||
	       '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-9"> '||
		   '<meta http-equiv="content-language" content="TR">' ||
	 '<title>Demir Kyrgyz International Bank</title><link rel="stylesheet" type="text/css" ></HEAD>'||
	 '<STYLE>' ||
	 '.DeckIssueText1{font-size:11px; color:#000000; font-weight:none; background-color:#E2E2E2; height:25}' ||
	 '.tdword2{font-weigth: normal; font-size: 11px; color: #ffffff; font-family: verdana, Tahoma, sans-serif; font-weight:bold; list-style-type: none; text-decoration: none; background-color:#a00a2a; height:28; text-indent:9; margin-left:3}'||
	 '.UserAccount{ font-size:10px; color:#000000; font-weight:none; background-color:#F2F2F2; height:20; text-indent:9; margin-left:3 }'||
     '.HomeFeatureFlag { font-size:11px; color:#cc6600;font-weight:bold}'||
     '.Cizgi       { background-image: url("https://online.demirbank.kz/dkbcib/images/cizgi.gif"); height:2 }'||
     '.Cizgi1       { background-image: url("https://online.demirbank.kz/dkbcib/images/cizgi1.gif"); height:2 }'||
	 '.UserAccount1  { font-size:10px; color:#000000; font-weight:none; background-color:#FFFFFF; height:20; text-indent:9; margin-left:3 }</STYLE>'||
     '<FORM>';

  -- ?nce logoyu tan?ml?yorum
     ls_htmlcontent :=
	 ls_htmlcontent ||
	 '<table width="570" height="77" border="0" cellpadding="0" cellspacing="0" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif"><tr><td width="230" height="77"><img border="0" src="https://online.demirbank.kz/dkbcib/images/logo.gif" width="230" height="77"></td>' ||
      '<td width="100%" height="77" valign="bottom" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif">'||
      '<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">'||
      '</table></td></tr></table><br>';

	    IF (ps_msgType = 'eft') THEN
        ls_htmlcontent := ls_htmlcontent || '<table border="0" cellpadding="0" style="border-collapse: collapse" width=600 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Transaction Type</td> <td class="DeckIssueText1" >&nbsp;'||'Clearing' ||'</td></tr><tr><td height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Transaction No</td> <td class="DeckIssueText1" >&nbsp;'||SPLIT(ps_decontInfo,'###',21) ||'</td></tr><tr><td height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Reference</td> <td class="DeckIssueText1" >&nbsp;'||SPLIT(ps_decontInfo,'###',20) ||'</td></tr><tr><td height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Transaction Date</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',0) ||'</td></tr><tr><td height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Amount</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',2) ||'</td></tr> <tr><td  height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Sender Branch</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',11)||'</td></tr><tr><td  height="2" colspan=2></td></tr>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Sender Account No</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',6) ||'</td></tr><tr><td  height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Sender Name</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',7) ||'</td></tr><tr><td  height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Sender Rnn</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',8) ||'</td></tr><tr><td height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Payee Branch</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',13) ||'</td></tr><tr><td  height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Paye Account No</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',15) ||'</td></tr><tr><td height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Payee Name</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',16) ||'</td></tr><tr><td height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Payee RNN</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',17) ||'</td></tr><tr><td height="2" colspan=2></td>';
		ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Description</td><td class="DeckIssueText1">&nbsp;'||SPLIT(ps_decontInfo,'###',22) ||'</td></tr><tr><td  height="2" colspan=2></td>';

  	  ELSIF (ps_msgType = 'fxb') THEN
        ls_htmlcontent := ls_htmlcontent || '<table border="3" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="tdword2" align=center width="30%" nowrap>D?viz Al?? ??lem e-Dekontu</td></tr>';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="Cizgi1" height="2" colspan=2></td></tr></table>';
        ls_htmlcontent := ls_htmlcontent || '<table border="5" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Transaction Type</td> <td class="UserAccount1" >&nbsp;'||'Buying Foreign Currency' ||'</td></tr><tr><td height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Transaction No</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',0)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Transaction Date</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',1)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Customer No</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',2) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Debited Account No</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',3)||'</td></tr><tr><td class="Cizgi" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Currency Code</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',4)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Amount</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',5)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Currency Rate</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',6)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Credited Account No</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',7)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Cost</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',8)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Total Amount Debited</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',9)||' '||'KGS'||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;

  	  ELSIF (ps_msgType = 'fxs') THEN
        ls_htmlcontent := ls_htmlcontent || '<table border="3" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="tdword2" align=center width="30%" nowrap>D?viz Sat?? ??lem e-Dekontu</td></tr>';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="Cizgi1" height="2" colspan=2></td></tr></table>';
        ls_htmlcontent := ls_htmlcontent || '<table border="5" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Transaction Type</td> <td class="UserAccount1" >&nbsp;'||'Selling Foreign Currency' ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Transaction No</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',0)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Transaction Date</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',6) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Debited Account No</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',1)||'</td></tr><tr><td class="Cizgi" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Currency Code</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',2)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Currenc Rate</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',3)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>Amount</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'###',4)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Credited Account</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'###',5)||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ELSIF (ps_msgType = 'txinfo') THEN
        ls_htmlcontent := ls_htmlcontent || '<table border="3" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="tdword2" align=center width="30%" nowrap>??lem e-Dekontu</td></tr>';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="Cizgi1" height="2" colspan=2></td></tr></table>';
        ls_htmlcontent := ls_htmlcontent || '<table border="5" cellpadding="0" style="border-collapse: collapse" width=570 id="table3">';
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>??lem No</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'***',6) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>??lem T?r?</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'***',5) ||'</td></tr><tr><td height="2" class="Cizgi1" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>??lem Tarihi</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'***',0) ||'</td></tr><tr><td height="2" class="Cizgi" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>D?viz Kodu</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'***',4) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>D?viz Tutar?</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'***',2) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount" width="30%" nowrap>Kalan Bakiye</td> <td class="UserAccount" >&nbsp;'||SPLIT(ps_decontInfo,'***',3) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
        ls_htmlcontent := ls_htmlcontent || '<tr><td class="UserAccount1" width="30%" nowrap>A??klama</td> <td class="UserAccount1" >&nbsp;'||SPLIT(ps_decontInfo,'***',1) ||'</td></tr><tr><td class="Cizgi1" height="2" colspan=2></td>' ;
	  END IF;
		ls_htmlcontent :=
		ls_htmlcontent || '<table width="570" border=0 cellspacing=0 cellpadding=3> <tr><td><p align=left style="margin-top:0; margin-bottom:0">'||
		'<br>This receipt is just for information. It is not an official receipt.You can get the official receipt from our bank.</td></tr><tr><td valign=top height=20>&nbsp;</td></tr></table>';
    Pkg_Int_Email.SENDHTMLEMAIL ( ps_from,ps_to,ps_subject,ls_htmlcontent);
  END;
  ------------------------------------------------------------------------
FUNCTION SPLIT(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2 IS
		ln_i				NUMBER:=1;
		ln_itemindx	   NUMBER:=0;
		ls_strOut		VARCHAR2(2000);
BEGIN

	   LOOP
	   EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
			IF ln_itemindx=pn_valindx THEN
			    IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
				   ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
				ELSE
				   ls_strOut:=SUBSTR(ps_str,ln_i);
				END IF;
			   RETURN ls_strOut;
			END IF;
			IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
			   ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
			ELSE
				ln_i:=LENGTH(ps_str)+1;
			END IF;
			ln_itemindx:=ln_itemindx+1;

	   END LOOP;

	   RETURN '';
END;
------------------------------------------------------
FUNCTION SendDecont(ps_msgType IN VARCHAR2,ps_from IN VARCHAR2,ps_to IN VARCHAR2,ps_subject IN VARCHAR2,ps_decontInfo IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
BEGIN
        OPEN pc_ref FOR
		SELECT SYSDATE FROM dual;

		SendAutoMessages(ps_msgType,ps_from,ps_to,ps_subject,ps_decontInfo);
		RETURN '000';
END;
--------------------------------------------------------------------------------
PROCEDURE SendPeriodicMessages(ps_sender IN VARCHAR2) IS

        ls_htmlcontent		CLOB:= EMPTY_CLOB; -- ?ok b?y?k body olabilir o y?zden clob kullan?yorum

		-- o g?nk? kur ekstreler i?in cursor
		CURSOR cursor_kur_ekstre IS
			SELECT e.*
			FROM CBS_INT_EKSTRE e
			WHERE TRUNC(e.NEXTRUNDATE)=TRUNC(SYSDATE)
			AND e.EKSTRETYPE='KUR'
			FOR UPDATE;

		-- o g?nk? hesap ekstreler i?in cursor
		-- burada herkese sadece 1 mail gidece?i i?in
		-- ben t?m m??teri idler?n?  se?iyorum
		-- bu idler ile gidip bir sorgu daha yapaca??m.

		CURSOR cursor_hesap_ekstre IS
			SELECT DISTINCT(h.MUSTERI_NO) musteri_no
			FROM CBS_INT_EKSTRE e,CBS_HESAP h
			WHERE TRUNC(e.NEXTRUNDATE)=TRUNC(SYSDATE)
			AND e.EKSTRETYPE='HESAP' AND
			h.HESAP_NO=e.ACCOUNTNO ;

		CURSOR cursor_ekstre_detay_bigileri(pd_customerno NUMBER) IS
		    SELECT e.*
			FROM CBS_INT_EKSTRE e,CBS_HESAP h
			WHERE e.EKSTRETYPE='HESAP'
			AND TRUNC(e.NEXTRUNDATE)=TRUNC(SYSDATE)
			AND h.HESAP_NO = e.ACCOUNTNO
			AND h.MUSTERI_NO = pd_customerno;


        -- o g?nk? d?viz kurlar? i?in ekstre
        CURSOR cursor_exchange_rate IS
          SELECT DVZ,
	  		 DVZALIS,
			 DVZSATIS,
			 EFALIS,
			 EFSATIS,
			 ACIKLAMA
	   FROM CBS_KUR,CBS_DOVIZ_KODLARI
	   WHERE dvz=doviz_kodu
	   AND ((DVZ<>Pkg_Genel.lc_al) AND (DVZ <> 'TRL'))
	   ORDER BY SIRA_NO;

	   -- hesap hareketleri i?in cursor
       CURSOR cursor_history(pd_start_date VARCHAR2,pd_end_date VARCHAR2,pn_account_no NUMBER) IS
       SELECT  fis_muhasebelestigi_tarih,
		satir_valor_tarihi,
		satir_musteri_aciklama,
		satir_dv_tutar,
		satir_hesap_numara,
		fis_numara,
		satir_numara,
		SATIR_DOVIZ_KOD
	   FROM cbs_vw_fis_satir_vsziz a
  	   WHERE  satir_hesap_numara = pn_account_no AND
		fis_muhasebelestigi_tarih BETWEEN TO_DATE(pd_start_date,'YYYYMMDD') AND TO_DATE(pd_end_date,'YYYYMMDD') AND
		fis_tur = 'G'
       ORDER BY fis_numara,fis_fis_no ;


		row_kur_ekstre cursor_kur_ekstre%ROWTYPE;
		row_hesap_ekstre cursor_hesap_ekstre%ROWTYPE;
		row_ekstre_detay_bigileri cursor_ekstre_detay_bigileri%ROWTYPE;

		row_history cursor_history%ROWTYPE;
		row_exchange_rate  cursor_exchange_rate%ROWTYPE;
    	PC_REF Pkg_Int_Email.CursorReferenceType;
		ls_returncode VARCHAR2(3):='000';
		ls_count NUMBER:= 0;
		ls_classname VARCHAR2(20):='';
		startdate VARCHAR2(100):='';
		ps_emailaddress VARCHAR2(100):='';
BEGIN
	-- ************************************************************************
    -- o g?n ekstresi gelen kur kay?tlar? al?yorum.
	-- ************************************************************************

    OPEN cursor_kur_ekstre;
	FETCH cursor_kur_ekstre INTO row_kur_ekstre;
    -- o g?n ekstresi gelen kur kay?tlar? al?yorum.

	WHILE  cursor_kur_ekstre%FOUND
 	LOOP

	dbms_lob.createtemporary(ls_htmlcontent, TRUE);
    dbms_lob.OPEN(ls_htmlcontent, dbms_lob.lob_readwrite);

	-- ekstrenin ?st k?sm?
	--******************************************************************
	-- ?nce head k?sm?n? yaz?yorum
    dbms_lob.append(ls_htmlcontent,
	 '<HTML>' ||'<head>'||'<title>Demir Kyrgyz International Bank</title><link rel=''stylesheet'' type=''text/css'' >'||utl_tcp.crlf||
	 '<meta http-equiv=''Content-Type'' content=''text/html; charset=windows-1254''>'||utl_tcp.crlf||
	 '<meta http-equiv=''Content-Type'' content=''text/html; charset=ISO-8859-9''> '||utl_tcp.crlf||
	 '</HEAD>'||'<STYLE>' ||
	 '.DeckIssueText1{font-size:11px; color:#000000; font-weight:none; background-color:#E2E2E2; height:25}' ||
	 '.tdword2{font-weigth: normal; font-size: 11px; color: #ffffff; font-family: verdana, Tahoma, sans-serif; font-weight:bold; list-style-type: none; text-decoration: none; background-color:#a00a2a; height:28; text-indent:9; margin-left:3}'||
	 '.AbstractTitleText  { height:23; font-size:10px; color:#FFFFFF; font-weight:bold; background-color:#941010 }'||
	 '.UserAccount{ font-size:10px; color:#000000; font-weight:none; background-color:#F2F2F2; height:20; text-indent:9; margin-left:3 }'||
	 '.UserAccount1  { font-size:10px; color:#000000; font-weight:none; background-color:#FFFFFF; height:20; text-indent:9; margin-left:3 }</STYLE>'||'<FORM>'||
	 '<table width="570" height="77" border="0" cellpadding="0" cellspacing="0" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif"><tr><td width="230" height="77"><img border="0" src="https://online.demirbank.kz/dkbcib/images/logo.gif" width="230" height="77"></td>' ||
     '<td width="100%" height="77" valign="bottom" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif">'||
     '<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">'||'</table></td></tr></table><br><br>');
  -- *************** ?st k?sm?n sonu  *********************


	IF (row_kur_ekstre.EKSTRETYPE='KUR') THEN
    -- burada d?viz kurlar?n? mail at?yorum
	     -- Tablo alan adlar?
	      dbms_lob.append(ls_htmlcontent,
		 '<table width="570" border=0 cellspacing=0 cellpadding=3><tr><td class=DeckIssueText><p align=left style="margin-top:0; margin-bottom:0">Bankam?za ait '|| TO_CHAR(SYSDATE,'DD/MM/YYYY') || ' tarihli d?viz kurlar? a?a??da listelenmi?tir.</td></tr><tr><td valign=top height=16>&nbsp;</td></tr></table>'||
	     '<table border=0 cellpadding=0 style="border-collapse: collapse" width="570" id="table3">' ||
	     '<tr><td width="1%" nowrap class="AbstractTitleText">&nbsp;</td>'||
	     '<td class="AbstractTitleText" align=left>D?viz Kodu</td>'||
	     '<td class="AbstractTitleText" align=left>D?viz Ad?</td>'||
	     '<td class="AbstractTitleText" align=right>Al?? Kuru &nbsp;</td>'||
	     '<td class="AbstractTitleText" align=right>Sat?? Kuru &nbsp;</td></tr>');

	    -- d?viz de?erleri
		OPEN cursor_exchange_rate;
		FETCH cursor_exchange_rate INTO row_exchange_rate;
		WHILE  cursor_exchange_rate%FOUND
		LOOP
		IF ((ls_count MOD 2) = 0) THEN
		ls_classname:='UserAccount'; ELSE
		ls_classname:='UserAccount1';
		END IF;
		ls_count := ls_count +1;

	     dbms_lob.append(ls_htmlcontent, '<tr>'||
	    '<td nowrap class="'||ls_classname||'"></td>'||
	    '<td class="'||ls_classname||  '" align=left>'||row_exchange_rate.DVZ ||'</td>'||
	    '<td class="'||ls_classname||  '" align=left>'||row_exchange_rate.ACIKLAMA ||'</td>'||
	    '<td class="'||ls_classname||  '" align=right>'||row_exchange_rate.DVZALIS ||'</td>'||
	    '<td class="'||ls_classname||  '" align=right>'||row_exchange_rate.DVZSATIS ||'</td>'||
	    '</tr>');

	FETCH cursor_exchange_rate INTO row_exchange_rate;
	END LOOP;
	dbms_lob.append(ls_htmlcontent, '</table>');
	CLOSE cursor_exchange_rate;
    END IF;

	dbms_lob.append(ls_htmlcontent,'<br><br><table width="570" border=0 cellspacing=0 cellpadding=3> <tr><td><p align=left style="margin-top:0; margin-bottom:0"> .'||
	'This receipt is just for information. It is not an official receipt.You can get the official receipt from our bank..</td></tr><tr><td valign=top height=20>&nbsp;</td></tr></table>');

	-- bu i?lemi yapar yapmaz bir sonraki g?nderim g?n?n? de?i?tiriyorum..
	-- bunun nedeni e?er mail g?ndermede problem olursa bu de?er set edilemez ve ki?iye bir daha
	-- mail g?nderilemez

	UPDATE CBS_INT_EKSTRE e
    SET e.NEXTRUNDATE=DECODE(row_kur_ekstre.PERIOD,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1)))
	WHERE CURRENT OF cursor_kur_ekstre;

	dbms_lob.CLOSE(ls_htmlcontent);
	SendHTMLEmail('online@demirbank.kz',row_kur_ekstre.EMAILADRES,'Demir Kyrgyz International Bank Automatic Receipt',ls_htmlcontent);

	FETCH cursor_kur_ekstre INTO row_kur_ekstre;
	END LOOP;COMMIT;
    CLOSE cursor_kur_ekstre;

	-- ************************************************************************
    -- ?imdi s?rada hesap ekstreleri var...
	-- onlar? da mail ataca??m..
	-- ************************************************************************

    OPEN cursor_hesap_ekstre;
	FETCH cursor_hesap_ekstre INTO row_hesap_ekstre;
    -- o g?n ekstresi gelen hesap kay?tlar? al?yorum.

	WHILE  cursor_hesap_ekstre%FOUND
 	LOOP
	 	dbms_lob.createtemporary(ls_htmlcontent, TRUE);
	    dbms_lob.OPEN(ls_htmlcontent, dbms_lob.lob_readwrite);

		-- ekstrenin ?st k?sm?
		--******************************************************************
		-- ?nce head k?sm?n? yaz?yorum
	    dbms_lob.append(ls_htmlcontent,
		 '<HTML>' ||'<head>'||'<title>Demir Kyrgyz International Bank</title><link rel=''stylesheet'' type=''text/css'' >'||utl_tcp.crlf||
		 '<meta http-equiv=''Content-Type'' content=''text/html; charset=windows-1254''>'||utl_tcp.crlf||
		 '<meta http-equiv=''Content-Type'' content=''text/html; charset=ISO-8859-9''> '||utl_tcp.crlf||
		 '</HEAD>'||'<STYLE>' ||
		 '.DeckIssueText1{font-size:11px; color:#000000; font-weight:none; background-color:#E2E2E2; height:25}' ||
		 '.tdword2{font-weigth: normal; font-size: 11px; color: #ffffff; font-family: verdana, Tahoma, sans-serif; font-weight:bold; list-style-type: none; text-decoration: none; background-color:#a00a2a; height:28; text-indent:9; margin-left:3}'||
		 '.AbstractTitleText  { height:23; font-size:10px; color:#FFFFFF; font-weight:bold; background-color:#941010 }'||
		 '.UserAccount{ font-size:10px; color:#000000; font-weight:none; background-color:#F2F2F2; height:20; text-indent:9; margin-left:3 }'||
         '.HomeFeatureFlag { font-size:11px; color:#cc6600;font-weight:bold}'||
		 '.UserAccount1  { font-size:10px; color:#000000; font-weight:none; background-color:#FFFFFF; height:20; text-indent:9; margin-left:3 }</STYLE>'||'<FORM>'||
		 '<table width="570" height="77" border="0" cellpadding="0" cellspacing="0" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif"><tr><td width="230" height="77"><img border="0" src="https://online.demirbank.kz/dkbcib/images/logo.gif" width="230" height="77"></td>' ||
	     '<td width="100%" height="77" valign="bottom" background="https://demirbank.kz/dkbcib/images/bannerzemin.gif">'||
	     '<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">'||'</table></td></tr></table><br><br>');
	  -- *************** ?st k?sm?n sonu  *********************

       OPEN cursor_ekstre_detay_bigileri(row_hesap_ekstre.musteri_no);
	   FETCH cursor_ekstre_detay_bigileri INTO row_ekstre_detay_bigileri;


       WHILE  cursor_ekstre_detay_bigileri%FOUND
       LOOP

	   ps_emailaddress:=row_ekstre_detay_bigileri.EMAILADRES;  -- nereye mail ataca??n? tutuyorum

		IF (row_ekstre_detay_bigileri.PERIOD = 'G') THEN startdate:=TO_CHAR(TRUNC(SYSDATE-1),'YYYYMMDD');
		ELSIF (row_ekstre_detay_bigileri.PERIOD = 'H') THEN startdate:=TO_CHAR(TRUNC(SYSDATE-7),'YYYYMMDD');
	    ELSE startdate:=TO_CHAR(TRUNC(ADD_MONTHS(SYSDATE,-1)),'YYYYMMDD'); END IF;

	   OPEN cursor_history(startdate,TO_CHAR(TRUNC(SYSDATE),'YYYYMMDD'),row_ekstre_detay_bigileri.ACCOUNTNO);
   	   FETCH cursor_history INTO row_history;

	   IF (cursor_history%FOUND) THEN
		dbms_lob.append(ls_htmlcontent, '<table width="570" border=0 cellspacing=0 cellpadding=3><tr>'
		||'<td class=DeckIssueText><p align=left style="margin-top:0; margin-bottom:0">'|| row_ekstre_detay_bigileri.ACCOUNTNO
		|| ' nolu hesaba ait '|| TO_CHAR(TO_DATE(startdate,'YYYYMMDD'),'DD.MM.YYYY') ||' ile ' || TO_CHAR(TRUNC(SYSDATE),'DD.MM.YYYY') ||' aral???ndaki i?lemler listelenmektedir. </td></tr>' ||
		'<tr><td valign=top height=16>&nbsp;</td></tr></table>'||
		'<table width="570" border=0 cellspacing=0 cellpadding=4>'||
		'<tr><td width="3%" nowrap class=AbstractTitleText>&nbsp;</td>'||
		'<td class=AbstractTitleText  nowrap>??lem Tarihi</td>'||
		'<td class=AbstractTitleText  nowrap>Val?r Tarihi</td>'||
		'<td class=AbstractTitleText  nowrap>A??klama</td>'||
		'<td class=AbstractTitleText align=right nowrap>Tutar</td>'||
		'<td class=AbstractTitleText align=right nowrap>Bakiye</td></tr>');

   	     WHILE  cursor_history%FOUND
	     LOOP
			IF ((ls_count MOD 2) = 0) THEN
			 ls_classname:='UserAccount';
		    ELSE
			 ls_classname:='UserAccount1';
			END IF;

		    ls_count := ls_count +1;

			dbms_lob.append(ls_htmlcontent,
		      '<TR>'||
			  '<td nowrap class="'||ls_classname||'"></td>'||
			  '<td nowrap class="'||ls_classname||'" >'||TO_CHAR(row_history.fis_muhasebelestigi_tarih,'DD/MM/YYYY') ||'</td>'||
			  '<td nowrap class="'||ls_classname||'" >'||TO_CHAR(row_history.satir_valor_tarihi,'DD/MM/YYYY')||'</td>'||
			  '<td nowrap class="'||ls_classname||'" >'||SUBSTR(row_history.satir_musteri_aciklama,0,50) ||'</td>'||
			  '<td  class="'||ls_classname||'" align=right nowrap>'||TO_CHAR(TO_NUMBER(row_history.satir_dv_tutar),'999,999,999,999,999.99')||'</td>'||
			  '<td  class="'||ls_classname||'" align=right nowrap>'||TO_CHAR(NVL(pkg_passbook.hareketlibakiyehesapla(row_history.satir_hesap_numara,row_history.fis_numara,row_history.satir_numara),0),'999,999,999,999,999.99')
		       ||'</td>' ||
			  '</TR>');
			FETCH cursor_history INTO row_history;
    END LOOP;
	dbms_lob.append(ls_htmlcontent, '</table><br>');
    ELSE
	dbms_lob.append(ls_htmlcontent,
	'<table width="570" border=0 cellspacing=0 cellpadding=3><tr><td class=DeckIssueText><p align=left style="margin-top:0; margin-bottom:0"> </td></tr>  <tr><td valign=top height=16>&nbsp;'
		 ||row_ekstre_detay_bigileri.ACCOUNTNO ||' nolu hesaba ait '
		 || TO_CHAR(TO_DATE(startdate,'YYYYMMDD'),'DD.MM.YYYY')
		 ||' ile '
		 || TO_CHAR(TRUNC(SYSDATE),'DD.MM.YYYY')
		 ||' aral???nda herhangi bir hesap hareketine rastlanmam??t?r. </td></tr></table><br>');

	 FETCH cursor_history INTO row_history;
	  END IF;
	CLOSE cursor_history;
	FETCH cursor_ekstre_detay_bigileri INTO row_ekstre_detay_bigileri;
    END LOOP;
	CLOSE cursor_ekstre_detay_bigileri;

	dbms_lob.append(ls_htmlcontent,'<br><br><table width=570 border=0 cellspacing=0 cellpadding=3> <tr><td><p align=left style="margin-top:0; margin-bottom:0"> .'||
	'This receipt is just for information. It is not an official receipt.You can get the official receipt from our bank.</td></tr><tr><td valign=top height=20>&nbsp;</td></tr></table>');

		-- bu i?lemi yapar yapmaz bir sonraki g?nderim g?n?n? de?i?tiriyorum..
		-- bunun nedeni e?er mail g?ndermede problem olursa bu de?er set edilemez ve ki?iye bir daha
		-- mail g?nderilemez

	UPDATE CBS_INT_EKSTRE e
	SET e.NEXTRUNDATE=DECODE(e.PERIOD,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1)))
	WHERE TRUNC(e.NEXTRUNDATE)=TRUNC(SYSDATE) AND
	e.EKSTRETYPE='HESAP' AND
	e.ACCOUNTNO IN ( SELECT h.HESAP_NO FROM CBS_HESAP h
	                 WHERE h.MUSTERI_NO=row_hesap_ekstre.musteri_no
	                   );

	dbms_lob.CLOSE(ls_htmlcontent);
	SendHTMLEmail('online@demirbank.kz',ps_emailaddress ,'Demir Kyrgyz International Bank Automatic Receipt',ls_htmlcontent);

	FETCH cursor_hesap_ekstre INTO row_hesap_ekstre;
	END LOOP;

	COMMIT;
    CLOSE cursor_hesap_ekstre;

END;
--------------------------------------------------------------------------------------
FUNCTION SendHatasizEMail(ps_customerid IN VARCHAR2,
  		   					ps_message IN VARCHAR2 ,
							pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
		ls_htmlcontent					 VARCHAR2(32000);
		ls_count NUMBER;
   	    ps_emailadres VARCHAR2(200):='000';
		ls_returncode VARCHAR2(3):='000';
  BEGIN

    OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;

     -- ?nce bu m?sterinin email adresi var m?...
	SELECT COUNT(*)
	INTO ls_count
	FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
	WHERE m.musteri_no = TO_NUMBER(ps_customerid)
	AND m.musteri_no = a.musteri_no
	AND m.EXTRE_ADRES_KOD = a.ADRES_KOD
	AND a.EMAIL IS NOT NULL;


	IF (ls_count > 0) THEN

	    SELECT a.EMAIL
		INTO ps_emailadres
		FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
		WHERE m.musteri_no = TO_NUMBER(ps_customerid)
		AND m.musteri_no = a.musteri_no
		AND m.EXTRE_ADRES_KOD = a.ADRES_KOD;


     ls_htmlcontent :=
	 '<HTML>' ||
	 '<head><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1254">'||
	       '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-9"> '||
		   '<meta http-equiv="content-language" content="TR">' ||
	 '<title>Demir Kyrgyz International Bank</title><link rel="stylesheet" type="text/css" ></HEAD>'||
	 '<STYLE>' ||
	 '.DeckIssueText1{font-size:11px; color:#000000; font-weight:none; background-color:#E2E2E2; height:25}' ||
	 '.tdword2{font-weigth: normal; font-size: 11px; color: #ffffff; font-family: verdana, Tahoma, sans-serif; font-weight:bold; list-style-type: none; text-decoration: none; background-color:#a00a2a; height:28; text-indent:9; margin-left:3}'||
	 '.UserAccount{ font-size:10px; color:#000000; font-weight:none; background-color:#F2F2F2; height:20; text-indent:9; margin-left:3 }'||
	 '.UserAccount1  { font-size:10px; color:#000000; font-weight:none; background-color:#FFFFFF; height:20; text-indent:9; margin-left:3 }</STYLE>'||
     '<FORM>';
  -- ?nce logoyu tan?ml?yorum
     ls_htmlcontent :=
	 ls_htmlcontent ||
	 '<table width="570" height="77" border="0" cellpadding="0" cellspacing="0" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif"><tr><td width="230" height="77"><img border="0" src="https://online.demirbank.kz/dkbcib/images/logo.gif" width="230" height="77"></td>' ||
      '<td width="100%" height="77" valign="bottom" background="https://online.demirbank.kz/dkbcib/images/bannerzemin.gif">'||
      '<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">'||
      '</table></td></tr></table><br>';

	 ls_htmlcontent :=
	 ls_htmlcontent || '<table width="610" border=0 cellspacing=0 cellpadding=3> <tr><td><p align=left style="margin-top:0; margin-bottom:0"><br>.'||
	 '<br><br><b>'||ps_message||'</b></td></tr><tr><td valign=top height=20>&nbsp;</td></tr></table>';

    Pkg_Int_Email.SENDHTMLEMAIL ('online@demirbank.kz',ps_emailadres,'Demir Kyrgyz International Bank Information Message',ls_htmlcontent);

	END IF;
	RETURN ls_returncode;

END;
FUNCTION SendHatasizDecont(ps_customerid IN VARCHAR2,
                           ps_decont_tur IN VARCHAR2,
 					       ps_decont_info IN VARCHAR2,
						   pc_ref OUT CursorReferenceType
						   ) RETURN VARCHAR2 IS

						   ls_returncode VARCHAR2(3):='000';
 				   		   ls_count NUMBER;
                    	   ps_emailadres VARCHAR2(200):='000';
BEGIN

    OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;

     -- ?nce bu m?sterinin email adresi var m?...
	SELECT COUNT(*)
	INTO ls_count
	FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
	WHERE m.musteri_no = TO_NUMBER(ps_customerid)
	AND m.musteri_no = a.musteri_no
	AND m.EXTRE_ADRES_KOD = a.ADRES_KOD
	AND a.EMAIL IS NOT NULL;


	IF (ls_count > 0) THEN

	    SELECT a.EMAIL
		INTO ps_emailadres
		FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
		WHERE m.musteri_no = TO_NUMBER(ps_customerid)
		AND m.musteri_no = a.musteri_no
		AND m.EXTRE_ADRES_KOD = a.ADRES_KOD;

        SendAutoMessages(ps_decont_tur,
		                 'online@demirbank.kz',
			 		     ps_emailadres,
						 'Demir Kyrgyz International Bank Corporate Internet Banking Receipt.',
						 ps_decont_info);


    END IF;
	RETURN ls_returncode;

END;
END;
/

