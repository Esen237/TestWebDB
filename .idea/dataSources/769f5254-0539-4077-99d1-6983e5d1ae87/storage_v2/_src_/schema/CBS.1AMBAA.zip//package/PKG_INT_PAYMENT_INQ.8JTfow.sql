create PACKAGE     PKG_INT_PAYMENT_INQ IS

TYPE CursorReferenceType IS REF CURSOR;


FUNCTION GetInstantInstitutionGroups(ps_lang varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetInstantInsSubGroups(ps_lang varchar2,
                     ps_group_code varchar2, 
                     pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetInstantInstitutions(ps_lang varchar2,
                     ps_group_code varchar2, 
                     ps_sub_group_code varchar2, 
                     pc_ref OUT CursorReferenceType) RETURN varchar2;
                     
FUNCTION GetInstantInsValidation(ps_lang varchar2,
                     ps_institution_code varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2; 
                     
FUNCTION GetInstantInsNumberExtensions(ps_lang varchar2,
                     ps_institution_code varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;                     

FUNCTION GetInstantInstitutionBarCode(pc_ref OUT CursorReferenceType) RETURN varchar2;     

FUNCTION GetInstantInsServiceNumber(ps_institution_code varchar2) RETURN varchar2;              

FUNCTION GetPayInstCommission(ps_institution_code varchar2,
                     ps_amount varchar2,
                     ps_commission_type_bank OUT varchar2,
                     ps_commission_type_company OUT varchar2,
                     pn_commission_amount_bank OUT number,
                     pn_commission_amount_company OUT number,
                     pn_commission_rate_bank OUT number,
                     pn_commission_rate_company OUT number) RETURN varchar2;
                               
FUNCTION GetInstantInstitutionPayment(ps_lang varchar2,
                     ps_iban varchar2,
                     ps_institution_code varchar2,
                     ps_ins_number_extension_code varchar2,
                     ps_institution_account_number varchar2,
                     ps_amount varchar2,
                     ps_description varchar2,
                     pc_ref OUT CursorReferenceType,
                     pc_ref2 OUT CursorReferenceType,
                     pc_ref3 OUT CursorReferenceType) RETURN varchar2;
                     
FUNCTION GetPay24ErrorCode(ps_transaction_number varchar2) RETURN varchar2;
    
FUNCTION GetOurReceiverName(ps_lang varchar2,
                     ps_institution_code varchar2,
                     ps_row_number varchar2,
                     ps_container_number varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2; 
                     
FUNCTION GetIntalLlcIban(ps_institution_code varchar2) RETURN varchar2;
                                       
FUNCTION GetTaxTypes(ps_lang varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetTaxRegions(ps_lang varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;
                     
FUNCTION GetTaxDistricts(ps_lang varchar2,
                     ps_region_code varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;
                                         
FUNCTION GetTaxSubDistricts(ps_lang varchar2,
                     ps_district_code varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetTaxTypeName(ps_lang varchar2, ps_code varchar2) RETURN varchar2;

FUNCTION GetTaxRegionName(ps_lang varchar2, ps_code varchar2) RETURN varchar2;
                     
FUNCTION GetTaxDistrictName(ps_lang varchar2, ps_code varchar2) RETURN varchar2;
                                         
FUNCTION GetTaxSubDistrictName(ps_lang varchar2, ps_code varchar2) RETURN varchar2;
                                                             
FUNCTION GetWsTaxInfo(ps_tax_number varchar2,
                     pc_ref OUT CursorReferenceType) RETURN varchar2;
                     
FUNCTION GetTaxPayment(ps_lang varchar2,
                     ps_iban varchar2,
                     ps_tax_number varchar2, 
                     ps_type_code varchar2,
                     ps_region_code varchar2,
                     ps_district_code varchar2,
                     ps_sub_district_code varchar2,
                     ps_vehicle_plate varchar2,
                     ps_amount varchar2,
                     pc_ref OUT CursorReferenceType,
                     pc_ref2 OUT CursorReferenceType,
                     pc_ref3 OUT CursorReferenceType) RETURN varchar2;                   
         
END;
/

