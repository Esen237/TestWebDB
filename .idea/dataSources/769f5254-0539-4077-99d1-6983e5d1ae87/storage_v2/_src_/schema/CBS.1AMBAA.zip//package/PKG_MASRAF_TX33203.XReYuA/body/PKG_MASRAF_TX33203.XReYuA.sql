create PACKAGE BODY     Pkg_Masraf_Tx33203  IS

p_33203_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33203_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33203_KUR						  NUMBER;
p_33203_REFERENCE				  NUMBER;
p_33203_ISTA_KOD				  NUMBER;
p_33203_MUS_ACIK				  NUMBER;
p_33203_BANKA_ACIK				  NUMBER;
p_33203_ISLEM_SUBE				  NUMBER;
p_33203_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33203_FC_MASRAF_TUTARI		  NUMBER;
p_33203_LC_MASRAF_TUTAR			  NUMBER;
p_33203_MASRAF_HESAP_SUBE		  NUMBER;
p_33203_MASRAF_HESAP_NO			  NUMBER;
p_33203_LC_MAIL_CHARGE			  NUMBER;
p_33203_LC_COMM_CHARGE			  NUMBER;
p_33203_LC_CONF_COM				  NUMBER;
p_33203_LC_ADVICE_COM			  NUMBER;
p_33203_MAIL_CHARGE_GL			  NUMBER;
p_33203_COMM_CHARGE_GL			  NUMBER;
p_33203_CONF_COM_GL				  NUMBER;
p_33203_ADVICE_COM_GL			  NUMBER;
p_33203_UNCOMFIRM				  NUMBER;
p_33203_COMFIRM					  NUMBER;
p_33203_FC						  NUMBER;
p_33203_LC						  NUMBER;
p_33203_MAILCOM_VAR				  NUMBER;
p_33203_COMMCOM_VAR				  NUMBER;
p_33203_CONFCOM_VAR				  NUMBER;
p_33203_ADVICECOM_VAR			  NUMBER;
p_33203_FC_MASRAF_ANA			  NUMBER;
p_33203_LC_MASRAF_ANA			  NUMBER;
p_33203_MAILCOM_EXP				  NUMBER;
p_33203_COMMCOM_EXP				  NUMBER;
p_33203_CONFCOM_EXP				  NUMBER;
p_33203_ADVICECOM_EXP			  NUMBER;
p_33203_MASRAF_GECICI_YOK 		  NUMBER;
p_33203_MASRAF_GECICI_VAR 		  NUMBER;

p_33203_LC_ACCEPT_COM			  NUMBER;
p_33203_ACCEPT_COM_GL			  NUMBER;
p_33203_ACCEPT_EXP				  NUMBER;
p_33203_ACCEPT_VAR				  NUMBER;

p_33203_LC_DISCREP_COM			  NUMBER;
p_33203_DISCREP_COM_GL			  NUMBER;
p_33203_DISCREP_EXP				  NUMBER;
p_33203_DISCREP_VAR				  NUMBER;

p_33203_LC_SERVICE_TAX			  NUMBER;
p_33203_FC_SERVICE_TAX			  NUMBER;
p_33203_SERVICE_TAX_VAR			  NUMBER;


/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER) IS
  BEGIN
    Pkg_Masraf.onay_sonrasi(pn_islem_no, ps_ref, pn_vs_no, 'V','EXPCONFCOM');
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER) IS		-- Islem iptal edilemez
  BEGIN
    Pkg_Masraf.Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no, ps_ref, pn_vs_no);
/*    --status iptal konumuna getirilir ve tahsil edilen vs. oldu?u gibi b?rak?l?r...
    update cbs_masraf_ith_ihr
	   set durum = 'IPTAL'
	 where referans = ps_ref
	   and vs_no = pn_vs_no
	   and source = 'V'
	   and sira_no in (select sira_no from cbs_masraf_ith_ihr_isl
	                   where islem_no = pn_islem_no);
*/
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER) IS

   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   ls_tahsil_doviz        VARCHAR2(3);
   ls_hesap_doviz         VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_tutar		  NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no NUMBER;
   ls_aciklama			  VARCHAR2(2000);

   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   lb_vergi_var           BOOLEAN := FALSE;

   CURSOR cur_masraf IS
    SELECT *
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID'
	 ORDER BY sira_no
	FOR UPDATE;
	row_masraf cur_masraf%ROWTYPE;

    CURSOR c_0 IS
    SELECT COUNT(*)
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID';
	 ln_temp NUMBER;

    CURSOR cur_akr_detay IS
    SELECT doviz_kodu,teyit_kodu,LEHDAR_MUSTERI_NO
	  FROM CBS_AKREDITIF
	 WHERE referans = ls_referans;
	row_akr_detay  cur_akr_detay%ROWTYPE;

   CURSOR cur_vs IS
     SELECT * FROM CBS_AKR_VESAIK_SEVK_ISLEM
	  WHERE tx_no = pn_islem_no;
	 row_vs cur_vs%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT_ISLEM a
	  WHERE islem_no = pn_islem_no --referans = ls_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
	 FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;

  BEGIN
    ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	OPEN cur_vs;
	FETCH cur_vs INTO row_vs;
	CLOSE cur_vs;
    ls_referans := row_vs.referans;
	OPEN cur_akr_detay;
	FETCH cur_akr_detay INTO row_akr_detay;
	CLOSE cur_akr_detay;


	 ls_akr_doviz := row_akr_detay.doviz_kodu;  --ls_islem_d?viz yerine ge?ecek
	 varchar_list(p_33203_MASRAF_HESAP_NO) := row_vs.masraf_hesap_no;
     varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_vs.masraf_hesap_no);
	 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_vs.masraf_hesap_no);
     varchar_list(p_33203_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_vs.masraf_hesap_no);
	 ls_referans := row_vs.referans;
 	 varchar_list(p_33203_ISLEM_SUBE) := row_vs.bolum_kodu;


	 IF row_akr_detay.teyit_kodu='TEYITLI' THEN
		boolean_list(p_33203_UNCOMFIRM) := FALSE ;
		boolean_list(p_33203_COMFIRM)	:= TRUE ;
	 ELSE
		boolean_list(p_33203_UNCOMFIRM) := TRUE ;
		boolean_list(p_33203_COMFIRM)	:= FALSE ;
	 END IF;
        boolean_list(p_33203_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33203_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33203_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33203_ADVICECOM_VAR) := FALSE ;
		boolean_list(p_33203_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33203_LC_MASRAF_ANA) := FALSE ;
        boolean_list(p_33203_SERVICE_TAX_VAR) := FALSE;

		IF row_vs.masraf_hesap_no IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33203_MASRAF_HESAP_NO)) );
		   varchar_list(p_33203_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		   varchar_list(p_33203_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		   varchar_list(p_33203_ADVICE_COM_GL)	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDOCCONT');
		   varchar_list(p_33203_CONF_COM_GL)	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCONFCOM');

		   varchar_list(p_33203_ACCEPT_COM_GL)  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPACCEPT');
		   varchar_list(p_33203_DISCREP_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDISCREP');

		   --20.12.2006 Gulnihal ekledi
		   IF Pkg_Musteri.musteri_vergiden_muafmi(row_akr_detay.LEHDAR_MUSTERI_NO) = 'H' THEN
		     lb_vergi_var := TRUE;
		   END IF;

    	ELSE
		   varchar_list(p_33203_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33203_COMM_CHARGE_GL) := '';
		   varchar_list(p_33203_CONF_COM_GL)	:= '';
		   varchar_list(p_33203_ADVICE_COM_GL)  := '';
		   varchar_list(p_33203_ACCEPT_COM_GL)  := '';
		   varchar_list(p_33203_DISCREP_COM_GL) := '';

	    END IF;

     	   varchar_list(p_33203_REFERENCE) := ls_referans;
	       varchar_list(p_33203_ISTA_KOD)  := ls_istatistik_kodu;

		IF varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33203_FC_MSRF_DOVIZ_KODU) := TRUE ;

		ELSE
		   boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33203_FC_MSRF_DOVIZ_KODU) := FALSE;

		END IF;

		number_list(p_33203_LC_COMM_CHARGE) := 0;
		number_list(p_33203_LC_MAIL_CHARGE) := 0;
		number_list(p_33203_LC_CONF_COM) 	:= 0;
		number_list(p_33203_LC_ADVICE_COM) 	:= 0;
		number_list(p_33203_LC_ACCEPT_COM) 	:= 0;
		number_list(p_33203_LC_DISCREP_COM) 	:= 0;
        number_list(p_33203_LC_SERVICE_TAX)   := 0;
        number_list(p_33203_FC_SERVICE_TAX)   := 0;

		number_list(p_33203_LC_MASRAF_TUTAR):= 0;
		number_list(p_33203_FC_MASRAF_TUTARI) := 0;

		varchar_list(p_33203_MAILCOM_EXP)	:='';
		varchar_list(p_33203_COMMCOM_EXP)	:='';
	    varchar_list(p_33203_CONFCOM_EXP)	:='';
	    varchar_list(p_33203_ADVICECOM_EXP) :='';
	    varchar_list(p_33203_ACCEPT_EXP)	:='';
	    varchar_list(p_33203_DISCREP_EXP) :='';

		IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
		  boolean_list(p_33203_LC) := TRUE;
	      boolean_list(p_33203_FC) := FALSE;
		ELSE
		  boolean_list(p_33203_LC) := FALSE;
	      boolean_list(p_33203_FC) := TRUE;
		END IF;

		ls_aciklama := 'EXPORT L/C DOC. ENTRY  ' ;
		varchar_list(p_33203_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33203_MUS_ACIK) :=varchar_list(p_33203_BANKA_ACIK) ;

		IF  varchar_list(p_33203_MASRAF_HESAP_NO) IS NOT NULL THEN  --masraf hesab? girilmi?se
--	        IF varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU) =Pkg_Genel.lc_al THEN
--			   number_list(p_33203_KUR) := Pkg_Komisyon_Kur.KUR_to_lc(varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU),1);
--			ELSE
        	   number_list(p_33203_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU),1);
--			END IF;
		     --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33203_MASRAF_HESAP_NO));
        END IF;

	OPEN cur_masraf;
	LOOP
	  FETCH cur_masraf INTO row_masraf;
	  EXIT WHEN cur_masraf%NOTFOUND;

  	  lb_taksit_var := FALSE ;
	   boolean_list(p_33203_COMMCOM_VAR) := FALSE ;
       boolean_list(p_33203_MAILCOM_VAR) := FALSE ;
	   boolean_list(p_33203_CONFCOM_VAR) := FALSE ;
       boolean_list(p_33203_ADVICECOM_VAR) := FALSE ;
	   boolean_list(p_33203_ACCEPT_VAR) := FALSE ;
	   boolean_list(p_33203_DISCREP_VAR) := FALSE ;
	   boolean_list(p_33203_SERVICE_TAX_VAR) := FALSE;

	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN

		  IF Pkg_Ihracat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y'  THEN

	         ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
			 IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN  --haberle?me

			   boolean_list(p_33203_COMMCOM_VAR) := TRUE ;
			   --IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	--  number_list(p_33203_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
              -- ELSE
				  number_list(p_33203_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
			  -- END IF;

				--bu iki degisken ile hesabin odemeyi alabilmek icin yeterli olup olmadigi arastirilacak
			   --eger yeterli miktar varsa, toplam satir icin toplanacak
				 ln_borc_tutar := number_list(p_33203_LC_COMM_CHARGE);--number_list(p_33203_HABR_MDV);
				 ln_borc_trl := number_list(p_33203_LC_COMM_CHARGE);
			     varchar_list(p_33203_COMMCOM_EXP) := 'EXPCOMCAT '||row_vs.referans||' Export Communication Charge' ;


			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta
				  boolean_list(p_33203_MAILCOM_VAR) := TRUE ;
				 -- IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	 --    number_list(p_33203_LC_MAIL_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
                --  ELSE
				     number_list(p_33203_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				--  END IF;
				  ln_borc_tutar := number_list(p_33203_LC_MAIL_CHARGE);--number_list(p_33203_POSTA_MDV);
				  ln_borc_trl := number_list(p_33203_LC_MAIL_CHARGE);
				  varchar_list(p_33203_MAILCOM_EXP)	:='EXPMAILCHR '||row_vs.referans||' Export Mail Charge';



			  ELSIF  row_masraf.masraf_kodu = 'EXPDOCCONT' THEN   --Advise

			      boolean_list(p_33203_ADVICECOM_VAR) := TRUE ;
			   	 -- IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	--     number_list(p_33203_LC_ADVICE_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
                --  ELSE
				     number_list(p_33203_LC_ADVICE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				--  END IF;
				  ln_borc_tutar := number_list(p_33203_LC_ADVICE_COM);--number_list(p_33203_POSTA_MDV);
				  ln_borc_trl := number_list(p_33203_LC_ADVICE_COM);
			      varchar_list(p_33203_ADVICECOM_EXP)	:='EXPDOCCONT '||row_vs.referans||' Export Documents Checking Charge';


			  ELSIF  row_masraf.masraf_kodu = 'EXPACCEPT' THEN

			      boolean_list(p_33203_ACCEPT_VAR) := TRUE ;
			   	 -- IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	 --    number_list(p_33203_LC_ACCEPT_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
                 -- ELSE
				     number_list(p_33203_LC_ACCEPT_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				--  END IF;
				  ln_borc_tutar := number_list(p_33203_LC_ACCEPT_COM);--number_list(p_33203_POSTA_MDV);
				  ln_borc_trl := number_list(p_33203_LC_ACCEPT_COM);
			      varchar_list(p_33203_ACCEPT_EXP)	:='EXPACCEPT '||row_vs.referans||' Export Exceptence Commission';


			  ELSIF  row_masraf.masraf_kodu = 'EXPDISCREP' THEN

			      boolean_list(p_33203_DISCREP_VAR) := TRUE ;
			   	--  IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	--     number_list(p_33203_LC_DISCREP_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
               --   ELSE
				     number_list(p_33203_LC_DISCREP_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				--  END IF;
				  ln_borc_tutar := number_list(p_33203_LC_DISCREP_COM);--number_list(p_33203_POSTA_MDV);
				  ln_borc_trl := number_list(p_33203_LC_DISCREP_COM);
			      varchar_list(p_33203_DISCREP_EXP)	:='EXPDISCREP '||row_vs.referans||' Discrepancy Charge';


			  ELSIF row_masraf.masraf_kodu =  'EXPCONFCOM' THEN  --Confirmation taksitli OLUR
			        boolean_list(p_33203_CONFCOM_VAR) := TRUE ;
			        ln_eski_tahsil_tutar := NVL(row_masraf.tahsil_toplam,0);


				   IF NVL(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   --daha fazlas? veya ayn?s? ?nceden al?nm??
					   --hi? bir ?ey yapma
					   ln_tahsil_tutar := 0;

				   ELSE

				   			  lb_taksit_var := TRUE;
							  OPEN cur_taksitler;
							  LOOP
							    FETCH cur_taksitler INTO row_taksit;
								EXIT WHEN cur_taksitler%NOTFOUND;

									ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
									--IF boolean_list(p_33203_LC_MSRF_DOVIZ_KODU) THEN
            	                   --    number_list(p_33203_LC_CONF_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
                                   -- ELSE
				      				   number_list(p_33203_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
									--END IF;
		 				            ln_borc_tutar := number_list(p_33203_LC_CONF_COM);--number_list(p_33203_TEYIT_MDV);
								    ln_borc_trl := number_list(p_33203_LC_CONF_COM);
		                            varchar_list(p_33203_CONFCOM_EXP)	:='EXPCONFCOM '||row_vs.referans||' Discrepancy Charge';
						        IF ln_son_bakiye >= ln_borc_tutar THEN
								   boolean_list(p_33203_COMMCOM_VAR) := FALSE ;
							       boolean_list(p_33203_MAILCOM_VAR) := FALSE ;
							       boolean_list(p_33203_ADVICECOM_VAR) := FALSE ;
								   boolean_list(p_33203_ACCEPT_VAR) := FALSE ;
								   boolean_list(p_33203_DISCREP_VAR) := FALSE ;
								   boolean_list(p_33203_SERVICE_TAX_VAR) := FALSE;

								   IF  NVL(row_vs.masraf_zamani,'B')='B' THEN
									  boolean_list(p_33203_MASRAF_GECICI_VAR) := TRUE;
									  boolean_list(p_33203_MASRAF_GECICI_YOK) := FALSE;
								   ELSE
									  boolean_list(p_33203_MASRAF_GECICI_VAR) := FALSE;
									  boolean_list(p_33203_MASRAF_GECICI_YOK) := TRUE;
								   END IF;

							        ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33203, NULL, pn_islem_no, varchar_list, number_list,
												    			  	  date_list, boolean_list, NULL, FALSE, ln_fis_no, NULL);

					     		     UPDATE CBS_MASRAF_ITH_IHR_ISL
									   SET tahsil_toplam = NVL(tahsil_toplam,0) + (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0)),
									       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0))
								     WHERE CURRENT OF cur_masraf;

		  					  		Pkg_Masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
		                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

									UPDATE CBS_MASRAF_TAKSIT_ISLEM
									   SET taksit_odeme_tarih = Pkg_Muhasebe.banka_tarihi_bul,
									       odenen_tutar = taksit_tutari
									 WHERE CURRENT OF cur_taksitler;
									 IF NVL(row_vs.masraf_zamani,'B') = 'B' THEN


									   Pkg_Masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, Pkg_Muhasebe.banka_tarihi_bul,--row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33203_LC_CONF_COM), row_vs.masraf_hesap_no,
																   row_vs.ODEME_POLICE_VADE_TARIHI, 'E');
									 END IF;

									ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
									number_list(p_33203_LC_MASRAF_TUTAR) := number_list(p_33203_LC_MASRAF_TUTAR) + ln_borc_trl;
							        number_list(p_33203_FC_MASRAF_TUTARI) := number_list(p_33203_FC_MASRAF_TUTARI) + ln_borc_tutar;
								END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
			    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;
			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_tutar THEN --bakiye yeterliyse satiri ekle
			     IF ln_tahsil_tutar <> 0 THEN

			         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33203, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_33203_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33203_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33203_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33203_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33203_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33203_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33203_ADVICECOM_VAR) = TRUE THEN
					  	 boolean_list(p_33203_ADVICECOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33203_ACCEPT_VAR) = TRUE THEN
					  	 boolean_list(p_33203_ACCEPT_VAR) := FALSE;
					  ELSIF boolean_list(p_33203_DISCREP_VAR) = TRUE THEN
					  	 boolean_list(p_33203_DISCREP_VAR) := FALSE;
					  END IF;

					  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      UPDATE CBS_MASRAF_ITH_IHR_ISL
					     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       WHERE CURRENT OF cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
					  number_list(p_33203_LC_MASRAF_TUTAR) := number_list(p_33203_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33203_FC_MASRAF_TUTARI) := number_list(p_33203_FC_MASRAF_TUTARI) + ln_borc_tutar;
				END IF;
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;

	boolean_list(p_33203_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33203_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33203_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33203_ADVICECOM_VAR):= FALSE ;
    boolean_list(p_33203_ACCEPT_VAR)  := FALSE;
	boolean_list(p_33203_DISCREP_VAR) := FALSE;
    boolean_list(p_33203_SERVICE_TAX_VAR) := FALSE;

	--20.12.2006 Gulnihal ekledi
    Pkg_Parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (NVL(number_list(p_33203_LC_COMM_CHARGE),0) + NVL(number_list(p_33203_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	IF lb_vergi_var AND ln_tax_amount != 0 THEN
	  number_list(p_33203_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33203_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU),1);
   	  boolean_list(p_33203_SERVICE_TAX_VAR) := TRUE;
	ELSE
	  boolean_list(p_33203_SERVICE_TAX_VAR) := FALSE;
	END IF;


	IF number_list(p_33203_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33203_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33203_LC_MASRAF_TUTAR)) ;
	   number_list(p_33203_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33203_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33203_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33203_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33203_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33203_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33203_LC_MASRAF_ANA) := TRUE ;

		END IF;


	       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33203,
		    			 	              	  NULL,
			     						  	  pn_islem_no,
				    					  	  varchar_list ,
					    				  	  number_list  ,
						    			  	  date_list    ,
							    		  	  boolean_list ,
								    	  	  NULL,
									     	  FALSE,
									  	      ln_fis_no,
									  	      NULL);

	END IF;
	pn_fis_no := ln_fis_no;

  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
   BEGIN
    NULL;
   END;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebe_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, NULL);
  END;
/*------------------------------------------------------------------------------------------------------*/
 FUNCTION masraf_odeyecek_kontrol(pn_islem_no NUMBER) RETURN VARCHAR2 IS
 ln_temp NUMBER;
 BEGIN
   SELECT COUNT(*)
     INTO ln_temp
	 FROM CBS_MASRAF_ITH_IHR_ISL
	WHERE islem_no = pn_islem_no
	  AND odeyecek = 'EXPORTER'
	  AND NVL(durum,'VALID') = 'VALID';
   IF ln_temp > 0 THEN
     RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
 END;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
	p_33203_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33203_FC_MSRF_DOVIZ_KODU');
	p_33203_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33203_LC_MSRF_DOVIZ_KODU');
	p_33203_KUR						  := Pkg_Muhasebe.parametre_index_bul('33203_KUR');
	p_33203_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33203_REFERENCE');
	p_33203_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33203_ISTA_KOD');
	p_33203_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33203_MUS_ACIK');
	p_33203_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33203_BANKA_ACIK');
	p_33203_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33203_ISLEM_SUBE');
	p_33203_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33203_MASRAF_HESAP_DOVIZ_KODU');
	p_33203_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33203_FC_MASRAF_TUTARI');
	p_33203_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_MASRAF_TUTAR');
	p_33203_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33203_MASRAF_HESAP_SUBE');
	p_33203_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33203_MASRAF_HESAP_NO');
	p_33203_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_MAIL_CHARGE');
	p_33203_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_COMM_CHARGE');
	p_33203_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33203_LC_CONF_COM');
	p_33203_LC_ADVICE_COM			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_ADVICE_COM');
	p_33203_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33203_MAIL_CHARGE_GL');
	p_33203_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33203_COMM_CHARGE_GL');
	p_33203_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33203_CONF_COM_GL');
	p_33203_ADVICE_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33203_ADVICE_COM_GL');
	p_33203_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33203_UNCOMFIRM');
	p_33203_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33203_COMFIRM');
	p_33203_FC						  := Pkg_Muhasebe.parametre_index_bul('33203_FC');
	p_33203_LC						  := Pkg_Muhasebe.parametre_index_bul('33203_LC');
	p_33203_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33203_MAILCOM_VAR');
	p_33203_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33203_COMMCOM_VAR');
	p_33203_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33203_CONFCOM_VAR');
	p_33203_ADVICECOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33203_ADVICECOM_VAR');
	p_33203_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33203_FC_MASRAF_ANA');
	p_33203_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_MASRAF_ANA');
	p_33203_MAILCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33203_MAILCOM_EXP');
	p_33203_COMMCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33203_COMMCOM_EXP');
	p_33203_CONFCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33203_CONFCOM_EXP');
	p_33203_ADVICECOM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33203_ADVICECOM_EXP');
    p_33203_MASRAF_GECICI_YOK         := Pkg_Muhasebe.parametre_index_bul('33203_MASRAF_GECICI_YOK');
	p_33203_MASRAF_GECICI_VAR         := Pkg_Muhasebe.parametre_index_bul('33203_MASRAF_GECICI_VAR');

    p_33203_LC_ACCEPT_COM			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_ACCEPT_COM');
    p_33203_ACCEPT_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33203_ACCEPT_COM_GL');
    p_33203_ACCEPT_EXP				  := Pkg_Muhasebe.parametre_index_bul('33203_ACCEPT_EXP');
    p_33203_ACCEPT_VAR				  := Pkg_Muhasebe.parametre_index_bul('33203_ACCEPT_VAR');

    p_33203_LC_DISCREP_COM			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_DISCREP_COM');
    p_33203_DISCREP_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33203_DISCREP_COM_GL');
    p_33203_DISCREP_EXP				  := Pkg_Muhasebe.parametre_index_bul('33203_DISCREP_EXP');
    p_33203_DISCREP_VAR				  := Pkg_Muhasebe.parametre_index_bul('33203_DISCREP_VAR');

	p_33203_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33203_LC_SERVICE_TAX');
	p_33203_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33203_FC_SERVICE_TAX');
	p_33203_SERVICE_TAX_VAR			  := Pkg_Muhasebe.parametre_index_bul('33203_SERVICE_TAX_VAR');

 END;
/

