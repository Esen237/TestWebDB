create PACKAGE BODY     PKG_TX1308 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_kredi_teklif_satir_numara			 number;
   ln_kredi_hesap_tutar  				 number;
   ls_kredi_hesap_doviz_kodu  			 cbs_doviz_kodlari.doviz_kodu%type;
   iliskili_faizrees_dk_yok   			 exception;
   iliskili_kom_dk_yok   	   			 exception;
   iliskili_komrees_dk_yok    			 exception;
   ln_faiz_orani						 number;
   ln_komisyon_orani					 number;
   ls_dk_grup_kod			             cbs_musteri.DK_GRUP_KOD%type;
   ls_modul_tur_kod			             cbs_hesap.modul_tur_kod%type;
   ls_urun_tur_kod			             cbs_hesap.urun_tur_kod%type;
   ls_urun_sinif_kod		             cbs_hesap.urun_sinif_kod%type;
   ls_komreesdk  				         varchar2(2000);
   ls_faizreesdk      		             varchar2(2000);
   ln_hesap_no				             cbs_hesap_kredi.hesap_no%type;
   ls_endeks_doviz_kodu					 cbs_doviz_kodlari.doviz_kodu%type;
   ls_teminatlar_kapat					 varchar2(1);
   cursor curs_hesap is
   select HESAP_NO  ,
   		  teminatlar_kapat
   from   cbs_teminat_toplu_islem
   where tx_no = pn_islem_no;

  Begin
   for cur_hesap in curs_hesap
   loop
   	   ln_hesap_no := cur_hesap.hesap_no;
	   ls_teminatlar_kapat := cur_hesap.teminatlar_kapat;
   end loop;
  if ls_teminatlar_kapat = 'H' then
	   select kredi_teklif_satir_numara,
	   		  tutar,
			  doviz_kodu,
			  faiz_orani,
			  komisyon_orani,
		      pkg_musteri.sf_musteri_dk_grup_kod_al(musteri_no),
		      modul_tur_kod,
	 		  urun_tur_kod,
			  urun_sinif_kod,
			  endeks_doviz_kodu
	   into   ln_kredi_teklif_satir_numara,
	   		  ln_kredi_hesap_tutar,
	          ls_kredi_hesap_doviz_kodu,
			  ln_faiz_orani,
			  ln_komisyon_orani,
			  ls_dk_grup_kod,
		      ls_modul_tur_kod,
	 		  ls_urun_tur_kod,
			  ls_urun_sinif_kod,
			  ls_endeks_doviz_kodu
	   from cbs_hesap_kredi
	   where hesap_no = ln_hesap_no;


   pkg_teminat.sp_teminat_kontrolsonra(pn_islem_no ,
	  			 ln_kredi_teklif_satir_numara ,
				 ln_kredi_hesap_tutar,
	             ls_kredi_hesap_doviz_kodu ,
				 ls_endeks_doviz_kodu );

  end if;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
	pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_No);

  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	 null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
    ln_teklif_no    cbs_kredi_teklif.teklif_no%type;
	ls_durum_kodu   cbs_kredi_teklif.durum_kodu%type;
	ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
	ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
	ls_kapat	   varchar2(200);
  Begin

	/* teminat islem Durum guncellenir */
 	 select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

     pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no ,null,null,ls_kapat);

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
	ln_faiz_tahakkuk  		cbs_hesap_kredi.hesap_no%type;
	ln_vergi_tahakkuk		cbs_hesap_kredi.hesap_no%type;
ls_kapat  varchar2(200);
  Begin
	/* teminat islem Durum guncellenir */
 	 select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

	 pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no , ls_kapat);
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
	/* teminat islem Durum guncellenir */
	pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
   guncellenmis_exception			   exception;
   ln_retval			  number:=0;
   ls_sqlstr			  varchar2(2000);
   ls_sql_template		  varchar2(2000);
   ls_source_table		  varchar2(2000);
   ls_dest_table		  varchar2(2000);
  Begin

   if ps_block='CBS_TEMINAT_ISLEM' then
   	 --TODO 1: Set the source and destination table names
   	   ls_source_table:='CBS_TEMINAT_ISLEM';
	   ls_dest_table:='CBS_TEMINAT';
   if ps_column<>'TEMINAT_NO' and ps_column<>'TX_NO'  then
	 --TODO 2: Set the Primary Key Count (Default 1)
	   ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(1);
	 --TODO 3: Do not alter until next TODO :)
	    ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
   		ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
		ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
   		ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
		ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
	 --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','TEMINAT_NO');
   	    ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','TEMINAT_NO');
	  --insert into cbs_yphavale_test values(ls_sql_template);
	   execute immediate ls_sql_template into ln_retval,ps_oldvalue;
	 end if;
    end if;

	if ln_retval<>1 then
	   raise  guncellenmis_exception;
	 end if;
  Exception
   When  guncellenmis_exception then
   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '449' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   End;

 Procedure Muhasebelesme(pn_islem_no number)
 is
  ln_fis_no number := 0;
  ls_kapat  varchar2(200);
  Begin
/* teminat islem Durum guncellenir */
 	 select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

	pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,ls_kapat);
  Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '507' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

END ;
/

