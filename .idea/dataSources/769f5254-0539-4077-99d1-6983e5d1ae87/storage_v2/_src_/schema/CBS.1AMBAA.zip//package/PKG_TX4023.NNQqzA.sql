create PACKAGE PKG_TX4023 IS

/******************************************************************************
   Name       : PKG_TX4023
   Created By : Bilal GUL
   Purpose	  : Kur Rezervasyon Onay
******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Procedure Rezervasyon_Bilgisi_Al(ps_TARIH CBS_KUR_REZERVASYON.TARIH%type,
                               ps_SUBE_KODU CBS_KUR_REZERVASYON.SUBE_KODU%type,
							   ps_REZERVASYON_NO CBS_KUR_REZERVASYON.REZERVASYON_NO%type,
							   ps_MUSTERI_NO out CBS_KUR_REZERVASYON.MUSTERI_NO%type,
							   ps_ISLEM_TIPI out CBS_KUR_REZERVASYON.ISLEM_TIPI%type,
							   ps_ISLEM_SEKLI out CBS_KUR_REZERVASYON.ISLEM_SEKLI%type,
							   ps_ALIS_DOVIZ out CBS_KUR_REZERVASYON.ALIS_DOVIZ%type,
							   ps_SATIS_DOVIZ out CBS_KUR_REZERVASYON.SATIS_DOVIZ%type,
							   ps_ALIS_TUTAR out CBS_KUR_REZERVASYON.ALIS_TUTAR%type,
							   ps_SATIS_TUTAR out CBS_KUR_REZERVASYON.SATIS_TUTAR%type,
							   ps_MUSTERI_PARITE out CBS_KUR_REZERVASYON.MUSTERI_PARITE%type,
							   ps_MUSTERI_ALIS_KURU out CBS_KUR_REZERVASYON.MUSTERI_ALIS_KURU%type,
							   ps_MUSTERI_SATIS_KURU out CBS_KUR_REZERVASYON.MUSTERI_SATIS_KURU%type,
							   ps_MALIYET_PARITE out CBS_KUR_REZERVASYON.MALIYET_PARITE%type,
							   ps_MALIYET_ALIS_KURU out CBS_KUR_REZERVASYON.MALIYET_ALIS_KURU%type,
							   ps_MALIYET_SATIS_KURU out CBS_KUR_REZERVASYON.MALIYET_SATIS_KURU%type,
							   ps_DURUM_KODU out CBS_KUR_REZERVASYON.DURUM_KODU%type,
							   ps_KUR_PARITE out CBS_KUR_REZERVASYON.KUR_PARITE%type);

END;


/

