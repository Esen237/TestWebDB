create PACKAGE Pkg_Tx7056 IS
/******************************************************************************
Name       : Pkg_Tx7056
Created By : Hakan SAMSA, 20100904
Purpose	  : CRED?T Card Definition
******************************************************************************/
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir
PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir
PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir
PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir
PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);
PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);
PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);
PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
FUNCTION  Sf_Onay_Bekleyen_Varmi( pn_musteri_no number ,pn_tx_no NUMBER DEFAULT 0 ) RETURN number;

FUNCTION Yeni_Teklif_No(pn_musteri_no number) RETURN number;
FUNCTION Yeni_Urun(pn_musteri_no number) RETURN number;
FUNCTION Yeni_Limit(pn_musteri_no number) RETURN number;

FUNCTION Limit_Bul(pn_musteri_no number, pn_grup number, pn_teklif_satir number) RETURN number;
FUNCTION Limit_Cy(pn_musteri_no number, pn_grup number, pn_teklif_satir number) RETURN varchar2;

FUNCTION Yeni_Limit_Cy(pn_musteri_no number) RETURN varchar2;
PROCEDURE BilgiAktar(pn_txno IN NUMBER,pn_musteri IN NUMBER);
/*
PROCEDURE eski_musteri_limit_al(pn_musteri IN NUMBER,
			  			   pn_limit OUT NUMBER,
			  			   ps_limit_cy OUT varchar2,
						   pn_teklif_satir_no out varchar2,
						   pn_urun_Grup_no	  out varchar2
						   ) ;
*/
END;

/

