create package body     pkg_rbo_limited is
    function gl_sum_from_sql_statement(sql_statement_in in varchar2, pd_date_in in varchar2) return gl_info_ntt
    is 
        l_res gl_info_ntt;
    begin
        execute immediate sql_statement_in bulk collect into l_res using pd_date_in, pd_date_in, pd_date_in;
        return l_res;
    end;
end pkg_rbo_limited;
/

