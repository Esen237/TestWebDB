create PACKAGE BODY     pkg_tarih IS

  FUNCTION gun_ozellik(pd_tarih in DATE, ps_country in varchar2 default null) RETURN NUMBER IS
    vs_gun1	        VARCHAR2(20);
    vs_gun_tip      VARCHAR2(1);
    vs_country      cbs_takvim.kod%type;
    vn_ret          number;
	ln_temp			number;
    cursor c_1(p_date date) is
	 select 1 from cbs_working_weekend
	  where weekend = p_date;
  BEGIN

    IF ltrim(rtrim(upper(to_char(pd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN'))))  IN ('SATURDAY','SUNDAY') THEN  
	  open c_1(pd_tarih);
	  fetch c_1 into ln_temp;
	  if c_1%found then
	    close c_1;
		return 0; --working day
	  end if;
	  close c_1;
   	  return 1;
    END IF;

    if ps_country is null then
      vs_country := pkg_genel.lokal_ulke_kod;
    else
      vs_country := ps_country;
    end if;

    SELECT gun_tip INTO vs_gun_tip
      FROM cbs_takvim
     WHERE pd_tarih = gun
       and kod = vs_country;

    IF vs_gun_tip = 'T' THEN
      return 1;  -- tatil gunu
    ELSE
      return 0;
    END IF;

  EXCEPTION
    When No_Data_Found Then
         Return 0; -- Is Gunu
	when Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '74' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);
  END gun_ozellik;

  FUNCTION ileri_is_gunu(pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE IS
    vb_flag     BOOLEAN :=TRUE;
    vd_tarih    DATE;
  BEGIN
     vd_tarih := pd_tarih;
     WHILE vb_flag = TRUE LOOP
       vd_tarih := vd_tarih + 1;
     --haftasonlari da is gunu olabilir.
--	   IF  ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SATURDAY'  THEN -- cumartesi
--         vd_tarih := vd_tarih + 2;
--       ELSIF   ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SUNDAY'  THEN -- pazar
--         vd_tarih := vd_tarih + 1;
--       END IF;
       IF gun_ozellik(vd_tarih,ps_country) = 0 THEN
         RETURN vd_tarih; -- is gunu
       END IF;
     END LOOP;

	Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '75' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END ileri_is_gunu;

  FUNCTION geri_is_gunu( pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE IS
    vb_flag   BOOLEAN :=TRUE;
    vd_tarih  DATE;
  BEGIN
     vd_tarih := pd_tarih;
     WHILE vb_flag = TRUE LOOP
      vd_tarih := vd_tarih - 1;
     --haftasonlari da is gunu olabilir.
--      IF  ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SATURDAY'  THEN -- cumartesi
--        vd_tarih := vd_tarih - 1;
--      ELSIF   ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SUNDAY'  THEN -- pazar
--        vd_tarih := vd_tarih - 2;
--      END IF;
      IF gun_ozellik(vd_tarih,ps_country) = 0 THEN
        RETURN vd_tarih; -- is gunu
      END IF;
     END LOOP;

	Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '76' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END geri_is_gunu;

  FUNCTION ileri_gun ( pd_tarih in DATE DEFAULT SYSDATE
                     , p_gun NUMBER
                     , ps_country in varchar2 default null
                     ) RETURN DATE is
    vb_flag    BOOLEAN :=TRUE;
    vd_tarih   DATE;
    vn_gun     NUMBER;
  BEGIN
     vd_tarih := pd_tarih;
     vn_gun   := nvl(p_gun,0);
     IF vn_gun > 0 THEN
     	 vb_flag := TRUE;
     ELSE
     	 return vd_tarih;
     END IF;

     WHILE vb_flag = TRUE LOOP
      vd_tarih := vd_tarih + 1;
      
     --haftasonlari da is gunu olabilir.
--      IF  ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SATURDAY'  THEN -- cumartesi
--        vd_tarih := vd_tarih + 2;
--      ELSIF  ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SUNDAY'  THEN -- pazar
--        vd_tarih := vd_tarih + 1;
--      END IF;
      IF gun_ozellik(vd_tarih,ps_country) = 0 THEN
      	vn_gun := vn_gun - 1;
      	IF vn_gun = 0 THEN
        	 RETURN vd_tarih; -- is gunu
        END IF;
      END IF;
     END LOOP;

	Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '77' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END ileri_gun;

  FUNCTION geri_gun ( pd_tarih in DATE DEFAULT SYSDATE
                    , p_gun NUMBER
                    , ps_country in varchar2 default null
                    ) RETURN DATE is
    vb_flag    BOOLEAN :=TRUE;
    vd_tarih   DATE;
    vn_gun     NUMBER;
  BEGIN
     vd_tarih := pd_tarih;
     vn_gun   := nvl(p_gun,0);
     IF vn_gun > 0 THEN
     	 vb_flag := TRUE;
     ELSE
     	 return vd_tarih;
     END IF;

     WHILE vb_flag = TRUE LOOP
        vd_tarih := vd_tarih - 1;
     --haftasonlari da is gunu olabilir.
--        IF  ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SATURDAY'  THEN -- cumartesi
--          vd_tarih := vd_tarih - 1;
--        ELSIF   ltrim(rtrim(upper(to_char(vd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'SUNDAY'  THEN -- pazar
--          vd_tarih := vd_tarih - 2;
--        END IF;
        IF gun_ozellik(vd_tarih,ps_country) = 0 THEN
        	vn_gun := vn_gun - 1;
        	IF vn_gun = 0 THEN
          	 RETURN vd_tarih; -- is gunu
          END IF;
        END IF;
     END LOOP;

	Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '78' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END geri_gun;

  FUNCTION haftanin_ilk_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                                , ps_country in varchar2 default null
                                ) RETURN DATE is
    vb_flag    BOOLEAN :=TRUE;
    vd_tarih   DATE;
    vn_gun     varchar2(100);
  BEGIN
   -- gonderilen is gunu cuma ise
   IF  ltrim(rtrim(upper(to_char(pd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN')))) = 'MONDAY' AND pkg_tarih.gun_ozellik(pd_tarih,ps_country) = 0 THEN
   	  return pd_tarih;
   END IF;
   vd_tarih := pd_tarih;
   vn_gun := ltrim(rtrim(upper(to_char(pd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN'))));
   IF vn_gun = 'MONDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 1,ps_country);
   ELSIF vn_gun = 'TUESDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 2,ps_country);
   ELSIF vn_gun = 'WEDNESDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 3,ps_country);
   ELSIF vn_gun = 'THURSDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 4,ps_country);
   ELSIF vn_gun = 'FRIDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 5,ps_country);
   ELSIF vn_gun = 'SATURDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 6,ps_country);
   ELSIF vn_gun = 'SUNDAY' THEN
      vd_tarih := pkg_tarih.ileri_is_gunu(vd_tarih - 7,ps_country);
   END IF;
   return vd_tarih;

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '79' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END haftanin_ilk_is_gunu;

  FUNCTION haftanin_son_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                                , ps_country in varchar2 default null
                                ) RETURN DATE is
    vb_flag    BOOLEAN :=TRUE;
    vd_tarih   DATE;
    vn_gun     varchar2(100);
  BEGIN
   vd_tarih := pd_tarih;
   vn_gun := ltrim(rtrim(upper(to_char(pd_tarih,'day','NLS_DATE_LANGUAGE = AMERICAN'))));
   IF  vn_gun = 'SUNDAY' AND pkg_tarih.gun_ozellik(pd_tarih,ps_country) = 0 THEN
   	  return vd_tarih;
   END IF;
   IF vn_gun = 'SUNDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih, ps_country);
   ELSIF vn_gun = 'SATURDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 2, ps_country);
   ELSIF vn_gun = 'FRIDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 3, ps_country);
   ELSIF vn_gun = 'THURSDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 4, ps_country);
   ELSIF vn_gun = 'WEDNESDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 5, ps_country);
   ELSIF vn_gun = 'TUESDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 6, ps_country);
   ELSIF vn_gun = 'MONDAY' THEN
      vd_tarih := pkg_tarih.geri_is_gunu(vd_tarih + 7, ps_country);
   END IF;
   return vd_tarih;

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '79' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END haftanin_son_is_gunu;

  FUNCTION ayin_son_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                            , ps_country in varchar2 default null
                            ) RETURN DATE is
  BEGIN
     return pkg_tarih.geri_is_gunu(trunc(add_months(pd_tarih,1),'mm'),ps_country);

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '80' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END ayin_son_is_gunu;

  FUNCTION donemin_son_is_gunu( pd_tarih in DATE DEFAULT SYSDATE
                              , ps_country in varchar2 default null
                              ) RETURN DATE is
  BEGIN
     return pkg_tarih.geri_is_gunu(trunc(add_months(pd_tarih,3),'q'),ps_country);

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '81' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END donemin_son_is_gunu;

  FUNCTION yilin_son_is_gunu( pd_tarih in DATE DEFAULT SYSDATE
                            , ps_country in varchar2 default null
                            ) RETURN DATE is
  BEGIN
     return pkg_tarih.geri_is_gunu(trunc(add_months(pd_tarih,12),'year'),ps_country);

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '82' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END yilin_son_is_gunu;

  FUNCTION vade_tarihini_bul ( pd_date in DATE DEFAULT SYSDATE
                            , ps_duration  in varchar2
                            , ps_country in varchar2 default null
                            ) RETURN DATE is

   vn_temp              number;
   vn_duration          number;
   vs_duration          varchar2(1);
   vd_date              date;
   e_format_error       exception;
  BEGIN
    vn_duration := to_number(substr(ps_duration,1,2));
    vs_duration := substr(ps_duration,3,1);

    if vn_duration = 0 then
       return pd_date;
    elsif vn_duration < 0 then
       raise e_format_error;
    end if;
    if vs_duration <> 'D' and vs_duration <> 'W' and vs_duration <> 'M' and vs_duration <> 'Q' and vs_duration <> 'Y'   then
       raise e_format_error;
    end if;

    if    vs_duration = 'D' then
       vd_date := pd_date + vn_duration;
    elsif vs_duration = 'W' then
       vd_date := pd_date + vn_duration*7;
    elsif vs_duration = 'M' then
       vd_date := add_months(pd_date, vn_duration);
    elsif vs_duration = 'Q' then
       vd_date := add_months(pd_date, vn_duration*3);
    elsif vs_duration = 'Y' then
       vd_date := add_months(pd_date , vn_duration*12);
    end if;
    vn_temp := gun_ozellik(vd_date,ps_country);
    if vn_temp = 0 then
       return vd_date;
    else
       return ileri_is_gunu(vd_date,ps_country);
    end if;

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '83' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);


  END vade_tarihini_bul;

  FUNCTION vade_tarihini_bul(pd_date          in DATE DEFAULT SYSDATE
                          , pn_duration       in number
                          , ps_duration_type  in varchar2    default 'D'
                          , ps_next_previous  in varchar2    default 'N'
                          , pd_result         out date
                          , ps_country        in varchar2 default null
                          ) return number IS

   vn_temp              number;
   vd_date              date;
  BEGIN

    if ps_duration_type  not in ('D','W','M','Q','Y')   then
        --pkg_hata_kontrol.parametre_deger(1,'pkg_tarih.fun_add_duration');
        --pkg_hata_kontrol.push(-11999);
        return -11999;
    end if;
    if ps_next_previous <> 'N' and ps_next_previous <> 'P' then
        --pkg_hata_kontrol.parametre_deger(1,'pkg_tarih.fun_add_duration');
        --pkg_hata_kontrol.push(-11998);
        return -11998;
    end if;

    if    ps_duration_type = 'D' then
       vd_date := pd_date + pn_duration;
    elsif ps_duration_type = 'W' then
       vd_date := pd_date + pn_duration*7;
    elsif ps_duration_type = 'M' then
       vd_date := add_months(pd_date, pn_duration);
    elsif ps_duration_type = 'Q' then
       vd_date := add_months(pd_date, pn_duration*3);
    elsif ps_duration_type = 'Y' then
       vd_date := add_months(pd_date , pn_duration*12);
    end if;

    vn_temp := gun_ozellik(vd_date,ps_country);
    if vn_temp = 0 then
       pd_result := vd_date;
    else
       if ps_next_previous = 'N' then
          pd_result := ileri_is_gunu(vd_date,ps_country);
       elsif ps_next_previous = 'P' then
          pd_result := geri_is_gunu(vd_date,ps_country);
       else
          pd_result := vd_date;
       end if;
    end if;
    return 1;

  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '84' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

END vade_tarihini_bul;

function ayin_son_gunu( vd_date in date ) return date is
begin
    return last_day(vd_date);

Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '85' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

end ;

function tarihten_sonraki_isgunu(pd_date in date ) return date is
ld_date   date;
i         number := 0;
check_gun number := 45;
gun_tatil number;
hatali_is_gunu exception;

begin
  ld_date := pd_date + 1;
  gun_tatil := gun_ozellik(ld_date);
  while  gun_tatil = 1 and i < check_gun loop
	  ld_date := ld_date + 1;
	  i := i + 1;
     gun_tatil := gun_ozellik(ld_date);
  end loop;
  if i >= check_gun and gun_tatil = 1 then  --45 gun sonra bile hala tatilse.....bir problem var
     raise hatali_is_gunu;
  end if;
  return ld_date;

 exception
   when hatali_is_gunu then
   	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '253' || Pkg_Hata.Getdelimiter || pd_date || Pkg_Hata.Getdelimiter || check_gun || Pkg_Hata.Getucpointer);
   when Others Then
   	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '252' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

end ;

--------------------------------
FUNCTION yilin_ilk_is_gunu( pd_tarih in DATE DEFAULT pkg_muhasebe.Banka_Tarihi_Bul
                            , ps_country in varchar2 default null
                            ) RETURN DATE is
  BEGIN
     return pkg_tarih.ileri_is_gunu(trunc(pd_tarih,'year')-1,ps_country);
  Exception
	When Others Then
  	  	 Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '89' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END yilin_ilk_is_gunu;
-----------------------------------

--BOM aisuluud cq5205 04102016
  FUNCTION ileri_is_gunu_report(pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE IS
    vb_flag     BOOLEAN :=TRUE;
    vd_tarih    DATE;
    v_day       NUMBER; --v_day=0: working day, v_day> 0: holiday for clearing, swift
    i         number := 0;
    check_gun number;
    gun_tatil number;
    PR_CHECK_GUN number;
    hatali_is_gunu exception;
  BEGIN
     pkg_parametre.deger('CHECK_GUN', PR_CHECK_GUN);
     check_gun := PR_CHECK_GUN;
     vd_tarih := pd_tarih;
     vd_tarih := vd_tarih + 1;
     gun_tatil:=gun_ozellik(vd_tarih,ps_country);
     
     select count(*) into v_day from cbs_working_weekend 
            where weekend = vd_tarih
            and is_report_weekend = 1;
            
     while (gun_tatil<>0 or v_day<>0) and i<check_gun loop
        vd_tarih := vd_tarih + 1;
        i := i + 1;
        gun_tatil := gun_ozellik(vd_tarih,ps_country);
        
        select count(*) into v_day from cbs_working_weekend 
            where weekend = vd_tarih
            and is_report_weekend = 1;
            
            
     end loop;
     
     if i >= check_gun and (gun_tatil<>0 or v_day<>0) then
        raise hatali_is_gunu ;
     end if;   
        
     return vd_tarih;   


    Exception
    When hatali_is_gunu then
    log_at('hatali_is_gunu_5205','ileri_is_gunu_report', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '253' || Pkg_Hata.Getdelimiter || pd_tarih || Pkg_Hata.Getdelimiter || check_gun || Pkg_Hata.Getucpointer);
    When Others Then
    log_at('ileri_is_gunu_report_error', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '90' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END ileri_is_gunu_report;
  
  
  
  FUNCTION ileri_gun_report ( pd_tarih in DATE DEFAULT SYSDATE
                     , p_gun NUMBER
                     , ps_country in varchar2 default null
                     ) RETURN DATE is
    vb_flag    BOOLEAN :=TRUE;
    vd_tarih   DATE;
    vn_gun     NUMBER;
    v_day      NUMBER;
    i         number := 0;
    check_gun number;
    PR_CHECK_GUN number;
    hatali_is_gunu exception;
  BEGIN
     pkg_parametre.deger('CHECK_GUN', PR_CHECK_GUN);
     check_gun := PR_CHECK_GUN;
     vd_tarih := pd_tarih;
     vn_gun   := nvl(p_gun,0);
     IF vn_gun > 0 THEN
          vb_flag := TRUE;
     ELSE
          return vd_tarih;
     END IF;

     WHILE vb_flag = TRUE and i<check_gun LOOP
      vd_tarih := vd_tarih + 1;
      
            select count(*) into v_day from cbs_working_weekend 
            where weekend = vd_tarih
            and is_report_weekend = 1;

      IF gun_ozellik(vd_tarih,ps_country) = 0 and v_day=0 THEN
          vn_gun := vn_gun - 1;
          i := 0;
          IF vn_gun = 0 THEN
             RETURN vd_tarih; -- is gunu
        END IF;
        
      elsif gun_ozellik(vd_tarih,ps_country) != 0 or v_day!=0 THEN
        i:=i+1;
      END IF;
     END LOOP;
     
     if i>=check_gun and (gun_ozellik(vd_tarih,ps_country)<>0 or v_day<>0) then
     raise hatali_is_gunu;
     end if;

    Exception
    When hatali_is_gunu then
    log_at('hatali_is_gunu_5205','ileri_gun_report', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '253' || Pkg_Hata.Getdelimiter || pd_tarih || Pkg_Hata.Getdelimiter || check_gun || Pkg_Hata.Getucpointer);
    When Others Then
    log_at('ileri_gun_report_error', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
             Raise_Application_Error(-20100,pkg_Hata.Getucpointer || '91' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);

  END ileri_gun_report;   
--EOM aisuluud cq5205 04102016
  
  -- CBS-27 IadgarB 22112018
  -- returns the last working day for input date
  FUNCTION previous_working_day(pd_tarih in DATE DEFAULT SYSDATE) RETURN DATE is
    vd_tarih DATE;
  BEGIN
    vd_tarih := pd_tarih;
--    LOOP
--      IF gun_ozellik(vd_tarih) = 0  --working day
--      THEN
--        RETURN vd_tarih;
--      END IF;
--      vd_tarih := vd_tarih - 1;
--    END LOOP;
    
    IF gun_ozellik(vd_tarih, null) = 0 THEN
        RETURN vd_tarih; -- is gunu
    ELSE 
        RETURN pkg_tarih.geri_is_gunu(vd_tarih, null);
    END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        Raise_Application_Error(-20100, pkg_Hata.Getucpointer || '91' || Pkg_Hata.Getdelimiter || Sqlerrm  || Pkg_Hata.Getucpointer);
  END; 

    
END;
/

