create PACKAGE Pkg_Lovcontrol IS

 FUNCTION UrunTur2000Uygun(ps_lovcode VARCHAR2,ps_modul VARCHAR2, ps_urun VARCHAR2) RETURN NUMBER;
 FUNCTION UrunSinifUygun(ps_modul VARCHAR2, ps_urun VARCHAR2 , ps_sinif VARCHAR2) RETURN NUMBER;
 FUNCTION UrunTur_OBJ_IHRITH_Uygun(ps_urun VARCHAR2 ) RETURN VARCHAR2 ;
 FUNCTION UrunTur_2030_Urun_Uygun(ps_urun VARCHAR2 ) RETURN VARCHAR2 ;
PROCEDURE CBS_URUN_GRUBU_LIMIT_KONTROL(pn_txno number,
 		  							   pn_limitvarYP out number,pn_limitvarTL out number,
 		  							   pn_limitvarnakdi out number,pn_limitvargnakdi out number);
END;


/

