create PACKAGE     PKG_KULLANICI IS
  Procedure Yarat (	pkodu varchar2,psifre varchar2,perr out varchar2,pdurum in out boolean);
  Procedure Sil (	pkodu varchar2,perr out varchar2,pdurum in out boolean);
  Procedure Coz (	pkodu varchar2,perr out varchar2,	pdurum in out boolean);
  Procedure Kilitle (	pkodu varchar2,perr out varchar2,pdurum in out boolean);
  Procedure Oldur (	pkodu varchar2,perr out varchar2,pdurum in out boolean);
  Procedure Sifre_degistir (ps_kodu varchar2,ps_eski_sifre varchar2,ps_yeni_sifre varchar2);

  Function Email_al return varchar2; -- User'in e-mail adresini d?nd?r?r
  Function Yazici_al return varchar2; -- User'in yazicisinin network adresini d?nd?r?r
  Function PersonelBilgiAl(ps_personno in varchar2) return varchar2; --
  Function GetManagerName(ps_kullanicikodu in varchar2) return varchar2; --
  Function GetChiefAccountName(ps_kullanicikodu in varchar2) return varchar2; --

  Function KullaniciAdiSoyadi(ps_kodu in varchar2) return varchar2; --
  Function user_status(ps_kodu in varchar2) return varchar2;
  Function password_expiry(ps_kodu in varchar2) return date;
  Function lock_date(ps_kodu in varchar2) return date;
  Function user_profile(ps_kodu in varchar2) return varchar2;
  Procedure yeni_sifre_ver (ps_kodu varchar2, ps_yeni_sifre in out varchar2,
                            ps_mail_from in varchar2 default null, ps_mail_to in varchar2 default null);
  Procedure expire_password(pkodu varchar2, perr out varchar2, pdurum in out boolean);
  FUNCTION  kullanici_personel_kodu_al(ps_kullanici_kodu CBS_KULLANICI.KODU%TYPE) RETURN NUMBER;
  PROCEDURE kullanici_tanim_kopyala(pn_islemno NUMBER, ps_kullanici_kodu VARCHAR2) ;
  procedure sifre_hata_kontrol(ls_err number, ps_error in out varchar2);
  Function GetSecondPrinter(ps_kullanicikodu in varchar2) return varchar2;
  Function PersonelBolumAl(ps_kullanicikodu in varchar2) return varchar2;
END;

/

