create PACKAGE     Pkg_Int_Office IS

TYPE CursorReferenceType IS REF CURSOR;
---------------------------------------------------------------------------------------------------------
FUNCTION GetLoanPayment(ps_option        IN VARCHAR2,
		 				ps_interest_rate IN VARCHAR2,
						ps_no_of_inst 	 IN VARCHAR2,
						ps_currency 	 IN VARCHAR2,
						ps_loan_amount 	 IN VARCHAR2,
						ps_start_date 	 IN VARCHAR2,
						ps_busin_day 	 IN VARCHAR2,
						ps_INTEREST_TYPE IN VARCHAR2,
		 				pt_plan			 IN OUT Pkg_Type.v_odeme_plan)  RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
END;


/

