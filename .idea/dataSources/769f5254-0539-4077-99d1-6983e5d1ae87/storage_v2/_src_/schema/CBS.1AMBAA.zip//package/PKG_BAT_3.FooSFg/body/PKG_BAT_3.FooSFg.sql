create PACKAGE BODY     "PKG_BAT_3" IS
-----------------------------------------------------------------------------------------
 Procedure swift_ekstre_mesaji_uretme(pn_grup_no     Number,
                                       pn_log_no      Number,
                                       ps_program_kod Varchar2) Is
    Cursor c_tx Is
      Select a.tx_no, NVL(b.ekstre_sikligi,0) ekstre_sikligi,a.hesap_No  
        From cbs_hzn_swift_ektsre_anaisl a, cbs_hesap b
       Where a.hesap_no = b.hesap_no
         And (a.ekstre_tarihi_f = pkg_muhasebe.banka_tarihi_bul Or
             a.ekstre_tarihi_m = pkg_muhasebe.banka_tarihi_bul);
    r_tx            c_tx%Rowtype;
    ls_sube         Varchar2(3);
    ln_islem_numara Number;
    ln_count        Number;
  Begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'MT940_DATA_HAZIRLA started');
    pkg_tx6460.mt940_data_hazirla(pkg_muhasebe.banka_tarihi_bul);
    Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'MT940_DATA_HAZIRLA finished');
    -- Her bir hesap icin o gune ait yeni bir islem numarasi alinmisti. O yuzden islem numarasi bazinda her kaydi ayri ayri yapilandirmak gerekiyor ,
    --  PKG_TX6460.GN_MESSAGE_LENGTH NUMBER :=1800;
    --  GPKG_TX6460.N_MESSAGE_MAX_TRX_COUNT NUMBER :=14;degerlerini asiyorsa yeni islem numarasinda ekstre devami olarak gondermeli
    for cs_tx in  c_tx loop
         r_tx := cs_tx;
        ln_count := 0;

       Select Count(*)
        Into ln_count
        From cbs_hzn_swift_ektsre_dtyisl
       Where tx_no = r_tx.tx_no;

      If NVL(ln_count,0) > 0 Or r_tx.ekstre_sikligi = 1 Or
         (r_tx.ekstre_sikligi = 2 And pkg_tarih.haftanin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 4 And pkg_tarih.ayin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 5 And pkg_tarih.donemin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 6 And pkg_tarih.yilin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Then
       
        --once 1800 karakteri asan mesaj varsa bunu iki ayri 940 kaydi gibi bolup 2 sayfa haline getir.
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||  r_tx.hesap_no ||' mt940_data_sayfa_yapilandir started', r_tx.tx_No);
        pkg_tx6460.mt940_data_sayfa_yapilandir(r_tx.tx_no);
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||  r_tx.hesap_no ||' mt940_data_sayfa_yapilandir finished', r_tx.tx_No);
      End If;
    End Loop;
    
   commit;
    
    r_tx := null;

    for cs_tx in c_Tx loop
        r_tx := cs_tx;
       ln_count := 0; 
       Select Count(*)
        Into ln_count
        From cbs_hzn_swift_ektsre_dtyisl
       Where tx_no = r_tx.tx_no;

      If NVL(ln_count,0) > 0 Or r_tx.ekstre_sikligi = 1 Or
         (r_tx.ekstre_sikligi = 2 And pkg_tarih.haftanin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 4 And pkg_tarih.ayin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 5 And pkg_tarih.donemin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Or
         (r_tx.ekstre_sikligi = 6 And pkg_tarih.yilin_son_is_gunu(pkg_muhasebe.banka_tarihi_bul) =
         pkg_muhasebe.banka_tarihi_bul) Then
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||  cs_tx.hesap_no ||' mt940_onay_sonrasi started', cs_tx.tx_No);
--Simdi de onay asamasinda swift mesajini hazirla ve gonder
        pkg_tx6460.onay_sonrasi(cs_tx.tx_no, '940',pn_grup_no,pn_log_no,ps_program_kod);
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||  cs_tx.hesap_no ||' mt940_onay_sonrasi finished', cs_tx.tx_No);
       end if; 
    End Loop;



    Commit;
    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.hata_logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
-----------------------------------------------------------------------------------
PROCEDURE Musteri_Limit_GS_LOG(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
IS
BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   insert into cbs_musteri_grub_urnlmt_gslog
  (banka_tarihi, grup_kodu, urun_grub_no, lc_limit, fc_doviz_kodu, fc_limit, lc_risk, fc_risk) --, bloke_tutar, bloke_neden)
  select pkg_muhasebe.banka_tarihi_bul,grup_kodu, urun_grub_no, 
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null , nvl(fc_limit,0), 1, null, null, 'N', 'A'))) lc_limit, 
         fc_doviz_kodu, 
         fc_limit, 
          lc_risk, 
         fc_risk 
  from cbs_musteri_grub_urun_limit;
         
     insert into cbs_musteri_grup_limit_gs_log
  (     banka_tarihi,grup_kodu, fc_doviz_kodu,
        lc_limit,lc_risk,
        nakdi_lc_limit, nakdi_lc_risk,
        gnakdi_lc_limit,gnakdi_lc_risk, 
        fc_limit, fc_risk,
        nakdi_fc_limit,nakdi_fc_risk,  
        gnakdi_fc_limit, gnakdi_fc_risk, 
        yenileme_vadesi, limit_revize_onay_tarihi)
  select pkg_muhasebe.banka_tarihi_bul,grup_kodu, fc_doviz_kodu,
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null , nvl(fc_limit,0), 1, null, null, 'N', 'A'))) lc_limit, 
         lc_risk,
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null , nvl(nakdi_fc_limit,0), 1, null, null, 'N', 'A'))) nakdi_lc_limit, 
         nakdi_lc_risk,
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null ,  nvl(gnakdi_fc_limit,0), 1, null, null, 'N', 'A'))) gnakdi_lc_limit, 
         gnakdi_lc_risk,
        fc_limit, fc_risk,
        nakdi_fc_limit,nakdi_fc_risk,  
        gnakdi_fc_limit, gnakdi_fc_risk, 
        yenileme_vadesi, limit_revize_onay_tarihi
  from   cbs_musteri_grup_limit;
  
  
     insert into cbs_musteri_limit_gs_log
  ( banka_tarihi, musteri_no,  fc_doviz_kodu, 
    lc_limit,lc_risk,
    nakdi_lc_limit, nakdi_lc_risk, 
    gnakdi_lc_limit,gnakdi_lc_risk,
    fc_limit,  fc_risk,  
    nakdi_fc_limit, nakdi_fc_risk,
     gnakdi_fc_limit,  gnakdi_fc_risk,
     yenileme_vadesi, gnakdi_bagli_limit_dvz_kodu, gnakdi_bagli_limit_tutari, urun_bagli_limit_dvz_kodu, 
    urun_bagli_limit_tutari, genel_limit_bagli_mi, genel_bagli_limit_dvz_kodu, genel_bagli_limit_tutari, nakdi_limit_bagli_mi, nakdi_bagli_limit_dvz_kodu, 
    nakdi_bagli_limit_tutari, gnakdi_limit_bagli_mi,line_bakiyesi ,limit_revizyon_periyodu,line_amount) 
  select pkg_muhasebe.banka_tarihi_bul,musteri_no, fc_doviz_kodu, 
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null , nvl(fc_limit,0), 1, null, null, 'N', 'A'))) lc_limit,
         lc_risk,
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null ,  nvl(nakdi_fc_limit,0), 1, null, null, 'N', 'A'))) nakdi_lc_limit, 
         nakdi_lc_risk, 
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null ,  nvl(gnakdi_fc_limit,0), 1, null, null, 'N', 'A'))) gnakdi_lc_limit,
         gnakdi_lc_risk,
         fc_limit, fc_risk, nakdi_fc_limit, nakdi_fc_risk,  gnakdi_fc_limit,  gnakdi_fc_risk,
         pkg_limit_rapor.sf_yenileme_vadesi_al(musteri_no),
         gnakdi_bagli_limit_dvz_kodu, gnakdi_bagli_limit_tutari, urun_bagli_limit_dvz_kodu, 
         urun_bagli_limit_tutari, genel_limit_bagli_mi, genel_bagli_limit_dvz_kodu, genel_bagli_limit_tutari, nakdi_limit_bagli_mi, nakdi_bagli_limit_dvz_kodu, 
         nakdi_bagli_limit_tutari, gnakdi_limit_bagli_mi,line_bakiyesi ,limit_revizyon_periyodu,line_amount      
  from  cbs_musteri_limit a;
  
     insert into cbs_musteri_urun_limit_gs_log
  ( banka_tarihi,musteri_no, urun_grub_no, lc_limit, fc_doviz_kodu, fc_limit, lc_risk, fc_risk, kredi_teklif_satir_numara, urun_limit_bagli_mi, 
    urun_bagli_limit_dvz_kodu, urun_bagli_limit_tutari, line ) 
  select pkg_muhasebe.banka_tarihi_bul,musteri_no, urun_grub_no, 
         pkg_kur.yuvarla(pkg_genel.lc_al,(pkg_kur.doviz_doviz_karsilik(fc_doviz_kodu, pkg_genel.lc_al, null , nvl(fc_limit,0), 1, null, null, 'N', 'A'))) lc_limit,
         fc_doviz_kodu, fc_limit, lc_risk, fc_risk, kredi_teklif_satir_numara, urun_limit_bagli_mi, 
    urun_bagli_limit_dvz_kodu, urun_bagli_limit_tutari, line
  from   cbs_musteri_urun_limit;
     
  COMMIT;
   
     Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
        Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
        ROLLBACK;
  END;
  
-----------------------------------------------------------------------------------
Procedure KURUM_TAHSILAT_IPTAL_MUHASEBE(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
is
CURSOR Cur_talep_upd is
 select a.tx_no ,b.kurum_kodu,b.    tahsilat_saati,b.islem_no,b.payment_id from cbs_tahsilat_iptal_talep a,cbs_tahsilat b
  where a.durum_kodu in( 'ACIK','ACIKTALEP') and a.tahsilat_islem_no = b.islem_no and b.durum_kodu in ( 'IPTALTALEP')
      --  and nvl(b.tahsilat_fis_no,0) <> 0 
         order by tx_no
    for update ;
    
CURSOR Cur_talep is
 select a.tx_no ,b.kurum_kodu,b.    tahsilat_saati,b.islem_no,b.payment_id from cbs_tahsilat_iptal_talep a,cbs_tahsilat b
  where a.durum_kodu in( 'ACIK','ACIKTALEP') and a.tahsilat_islem_no = b.islem_no and b.durum_kodu in ( 'IPTALTALEP')
     --   and nvl(b.tahsilat_fis_no,0) <> 0 
   order by tx_no;
    
  Begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    for c_talep in cur_talep_upd loop
     if  pkg_tahsilat_islemleri.Kurum_iptal_max_datetime(c_talep.kurum_kodu, c_talep.tahsilat_saati ) <sysdate then 
        update cbs_tahsilat_iptal_talep
        set durum_kodu = 'NOTIPTAL'  ,
            last_status_update_date =sysdate,
            last_status_update_bank_date =pkg_muhasebe.banka_tarihi_bul
        where  tx_no = c_talep.tx_no ;
 
        update cbs_tahsilat
        set durum_kodu = 'NOTIPTAL'  ,
            last_status_update_date = sysdate ,
            last_status_update_bank_date = pkg_muhasebe.banka_tarihi_bul        
        where  islem_no =c_talep.islem_no;

           Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'Max.Cancel Time is Expired.Payment Trx No:'||c_Talep.islem_no||',Payment Id:'||  c_Talep.payment_id , c_Talep.tx_no);
      end if;     
    end loop;

    Commit;
    
    for c_talep in cur_talep loop
     --if  pkg_tahsilat_islemleri.Kurum_iptal_max_datetime(c_talep.kurum_kodu, c_talep.tahsilat_saati ) >=sysdate then 
         pkg_tx6331.Kurum_Tahsilat_Iptal_Muhasebe(c_talep.tx_no,pn_grup_no , pn_log_no , ps_program_kod);         
    end loop;

    Commit;

    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
-----------------------------------------------------------------------------------
Procedure KURUM_TAHSILAT_USIP_STATU_UPD(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
    -- Tanim : KURUM_TAHSILAT_USIP_STATU_UPDATE
    -- Aciklama :tahsilat ana tablosundaki usip statu code degeri guncellenir ve loga kayit atilir. 
    -- Yazar : Seval Colak 
    -- Tarih : 06122011
--seval 06062012 this will not be used directly .The payment and cancel process  are calling webcservice status call directly ,but in case of needed for all waiting data can be used
----------------------------------------------------------------------------------
is

cursor cur_tahsilat is
  select islem_no from cbs_tahsilat
  where  ( durum_kodu  in ( 'ACIK','ACIKTALEP') and USIP_STATU_CODE <> '60' ) --  60 approved look for not approved 
               or ( durum_kodu ='IPTALTALEP'  and   pkg_tahsilat_islemleri.Kurum_iptal_max_datetime(kurum_kodu, tahsilat_saati ) >=sysdate ) 
  order by islem_no; 

    ls_statucode        varchar2(200);
    ls_statu_resultcode varchar2(200);
  begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    for c_tahsilat in cur_tahsilat loop      
        pkg_tahsilat_islemleri.usip_payment_statu_code_al(c_tahsilat.islem_no,ls_statucode,ls_statu_resultcode);
    end loop;

    commit;
    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  exception
    when others then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| sqlerrm);
      rollback;
  End;
-----------------------------------------------------------------------------------
Procedure KURUM_TAHSILAT_MUHASEBE(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
is

 cursor cur_talep_upd is
 select a.islem_no ,payment_id,a.kurum_kodu ,tahsilat_tarihi ,bloke_referans ,bloke_cozulme_tarih,bloke_cozulme_banka_tarih,hesap_no
 from cbs_tahsilat a
 where a.durum_kodu in ( 'ACIK','ACIKTALEP') and nvl(a.tahsilat_fis_no,0)= 0 
 order by islem_no
 for update of durum_kodu ,last_status_update_date , last_status_update_bank_date,bloke_cozulme_tarih , bloke_cozulme_banka_tarih ;
 r_talep_upd  cur_talep_upd%rowtype;
 cursor cur_talep is
  select a.islem_no ,payment_id,a.kurum_kodu ,tahsilat_tarihi ,bloke_referans ,bloke_cozulme_tarih,bloke_cozulme_banka_tarih
  from cbs_tahsilat a
   where a.durum_kodu in ( 'ACIK','ACIKTALEP') and nvl(a.tahsilat_fis_no,0)= 0 
   order by islem_no;
  
    ld_bloke_cozulme_tarih date :=null;
    ld_bloke_cozulme_banka_tarih    date := null;
    ln_adet_batch_webpayment_call   number := 0;
    ln_iptal_islem_kod number:= 6331;
    ls_sube varchar2(20);
    ln_iptal_trx_no number;
  Begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
-- B-O-M sevalb 19062012 Aidjan announced that automatical canceling request will not be done so below part become useless and commented     
-- update status to NOTACIK -Not activated
/*    for c_talep in cur_talep_upd loop
       r_talep_upd :=c_talep;
       ln_adet_batch_webpayment_call := 0;
      
        select COUNT(distinct log_no)
        into ln_adet_batch_webpayment_call 
        from cbs_tahsilat_usip_webserv_log
        where  tahsilat_islem_no = c_talep.islem_no and
               transaction_type = 'PAYMENT-NOT-DONE' ;
        
     if  ln_adet_batch_webpayment_call  >= 3 or c_talep.tahsilat_tarihi +1 <pkg_muhasebe.banka_tarihi_bul then   -- sorgulama sayisi 3 den fazla ise eger banka tarihi 1 gun gectiyse girilmis olan odeme iptal edilsin   
          pkg_baglam.batch;
          ls_sube := pkg_hesap.hesaptansubeal(r_talep_upd.hesap_no);
          ln_iptal_trx_no:=pkg_batch.islem_yarat(ln_iptal_islem_kod,ls_sube);
          pkg_tx6331.TalimatBilgiAktar(r_talep_upd.payment_id ,ln_iptal_trx_no);
          pkg_tx6331.Onay_Sonrasi(ln_iptal_trx_no);          
         
          Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'Max.Payment Time is Expired.Payment Trx No:'||c_Talep.islem_no||',Payment Id:'||  c_Talep.payment_id , c_Talep.islem_no);
      end if;
    end loop;

    commit;
        
 -- E-O-M sevalb 19062012 Aidjan announced that automatical canceling request will not be done 
    */
-- call payment process
    for c_talep in cur_talep loop
         pkg_tx6330.Kurum_Tahsilat_Muhasebe(c_talep.islem_no,pn_grup_no , pn_log_no , ps_program_kod);        
    end loop;

    Commit;
    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
----------------------------------------------------------------------------------
Procedure KURUM_INTER_TO_MAIN_ACCT_TRANS(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
is
cursor cur_kurum is 
 select a.* from cbs_tahsilat_kurum_tanim a
  where a.durum_kodu = 'AKTIF'
        and tahsilat_alacak_hesap = 'KURUM'
         and nvl(kurum_hesap_no,0) <> 0 
          and provider_code = 'USIP' -- ChyngyzO 20102014 CQ1253 - USIP Bug
         --and pkg_hesap.kullanilabilir_bakiye_al(kurum_hesap_no) > pkg_tahsilat_islemleri.usip_remain_amount_al
    order by kurum_kodu ;

    ln_islem_no number ;
    ln_to_account_no number;
    
    ln_kullanilabilir_bakiye number := 0;
    ln_Remain_amount number;
    ln_bakiye        number := 0;
    ln_sending_amount number:=0; -- Almasn 20190531 CBS-210
    ls_param        cbs_parametre.deger%type;
  Begin

    -- get all exception service ids
    pkg_parametre.deger('USIP_B2B_EXCEPTION_SERVICE_IDS', ls_param);

    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    ln_to_account_no :=  pkg_tahsilat_islemleri.USIP_main_account_no_al;
    ln_Remain_amount := pkg_tahsilat_islemleri.usip_remain_amount_al;
    ln_islem_no := null;
        if ln_Remain_amount is not null and ln_to_account_no is not null  then

        -- Almasn 20190531 CBS-210
        select sum(aa.tutar) into ln_sending_amount
        from cbs_tahsilat_detay_islem aa, cbs_tahsilat_ana_islem bb, cbs_islem ii
        where aa.islem_no=bb.islem_no
        and aa.islem_no=ii.numara
        and islem_kod=6330
        and ii.kayit_tarih=trunc(sysdate-1)
        and trunc(yaratildigi_tarih)=trunc(sysdate-1)
        and (select instr(deger, aa.kurum_kodu, 1, 1) from cbs_parametre where kod='NOT_USIP_REPORT_SERVICE_LIST') < 1
        and kurum_kodu not in ('AKNET','AKNET IPTV','JET (КЫРГЫЗТЕЛЕКОМ)','KYRGYZTELECOM')
        and ii.durum='P';

          for c_kurum in cur_kurum loop
            ln_kullanilabilir_bakiye :=pkg_hesap.kullanilabilir_bakiye_al(c_kurum.kurum_hesap_no) ;    
            ln_bakiye :=pkg_hesap.hesapbakiyeal(c_kurum.kurum_hesap_no) ;
            ln_islem_no := null;

            -- Almasn 20190531 CBS-210
            if (ln_kullanilabilir_bakiye > ln_sending_amount) then
                ln_kullanilabilir_bakiye := ln_sending_amount;
            end if;
            
            if  nvl(ln_kullanilabilir_bakiye,0) >= nvl( ln_remain_amount,0) and ln_kullanilabilir_bakiye > 0 and instr(ls_param, ',' || c_kurum.service_id || ',')=0 then

            pkg_tahsilat_islemleri.booktobooktransfer(
                                           pn_grup_no , pn_log_no ,  ps_program_kod,
                                           c_kurum.kurum_kodu,    
                                           c_kurum.kurum_hesap_no,
                                           ln_to_account_no,
                                           nvl(ln_kullanilabilir_bakiye,0)- nvl( ln_remain_amount,0),
                                           ln_bakiye,     
                                           ln_kullanilabilir_bakiye,
                                           ln_remain_amount,  
                                           6332,
                                          'Payment transfer from Intermediate acount to Main Account',
                                          ln_islem_no
                                          ) ;
             else       
                  Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'No transfer is done for Institut.Cd:'||c_kurum.kurum_kodu||',Acct.No:'||c_kurum.kurum_hesap_no||',Available Balance:'|| To_char(ln_kullanilabilir_bakiye, 'FM9999999999999999.99')||' is smaller than Remain amount:'||To_char(ln_remain_amount, 'FM9999999999999999.99'));
             end if;
                          
           end loop;
        else
            Pkg_Batch.logla(pn_grup_no, pn_log_no, ps_program_kod,'No transfer is done because of Main account no ,Remain amount is not defined.');
        end if;


       Commit;
     pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
 -----------------------------------------------------------------------------------
Procedure JOB_CALL_PAYMENT_AND_CANCEL(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
is
  Begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    
    --pkg_bat_3.kurum_tahsilat_usip_statu_upd(pn_grup_no,pn_log_no ,'PKG_BAT_3.KURUM_TAHSILAT_USIP_STATU_UPD');
    pkg_bat_3.kurum_tahsilat_muhasebe(pn_grup_no , pn_log_no , 'PKG_BAT_3.KURUM_TAHSILAT_MUHASEBE' );
    pkg_bat_3.kurum_tahsilat_iptal_muhasebe(pn_grup_no , pn_log_no , 'PKG_BAT_3.KURUM_TAHSILAT_IPTAL_MUHASEBE' );

    Commit;
    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
 
----------------------------------------------------------------------------------
Procedure EKSTRE(pn_grup_no Number, pn_log_no Number, ps_program_kod Varchar2)
is
  Begin
    pkg_batch.basla(pn_grup_no, pn_log_no, ps_program_kod);
    
    CBS.PKG_EKSTRE.PREPARE_CUSTOMER_STATEMENT;

    Commit;
    pkg_batch.bitir(pn_grup_no, pn_log_no, ps_program_kod);
  Exception
    When Others Then
      pkg_batch.logla(pn_grup_no, pn_log_no, ps_program_kod, sqlcode||' '|| Sqlerrm);
      Rollback;
  End;
 
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
    -- Tanim :  Account daily statements
    -- Aciklama :Starting after Ekstre, cbs-113 sms notification project
    -- Yazar : Bahiana Bektemir kyzy
    -- Tarih : 16112020  --modified with cbs-649 04042022
PROCEDURE ACC_DAILY_NOTIF(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER,PS_PROGRAM_KOD VARCHAR2) IS

LD_BANK_DATE DATE := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL; 

cursor c_fis is
SELECT hesap_no FROM CBS_HESAP WHERE musteri_no IN (SELECT customer_no FROM cbs_cust_pack_ops WHERE operation_id = 5)
       AND durum_kodu = 'A' AND urun_tur_kod IN ('CURRENT', 'DEMAND DEP') AND urun_sinif_kod NOT IN ('OVERBALANCE-FC', 'OVERBALANCE-LC','ELCARD NON INT.BR-LC')--CBS-661 'ELCARD NON INT.BR-LC' added
       AND HESAP_NO IN (SELECT TO_NUMBER(SATIR_HESAP_NUMARA) FROM CBS_VW_FIS_SATIR_VSZIZ 
                        WHERE FIS_MUHASEBELESTIGI_TARIH = LD_BANK_DATE AND FIS_TUR = 'G');        
r_fis c_fis%rowtype;

begin
Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    Delete from CBS.TBL_STATEMENT_ACC_TMP;

    OPEN c_fis;
        LOOP 
        FETCH c_fis INTO r_fis;
        EXIT WHEN c_fis%NOTFOUND;
            insert into TBL_STATEMENT_ACC_TMP (hesap_no)
            values (r_fis.hesap_no);        
            COMMIT;
        END LOOP;
    
    FOR c_tmp in (select * from CBS.TBL_STATEMENT_ACC_TMP order by 1)
        LOOP
        PKG_NOTIF_SUB.ACC_DAILY_NOTIF(c_tmp.HESAP_NO);
        PKG_BAT_3.NOTIF_EKSTRE_LOG(c_tmp.HESAP_NO,LD_BANK_DATE,PS_PROGRAM_KOD); 
        COMMIT; 
        END LOOP;
                        
Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  
  EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK; 
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM); 
     log_at ('ACC_DAILY_NOTIF',sqlerrm,dbms_utility.format_error_backtrace);
end;
----------------------------------------------------------------------------------
    -- Tanim :  Account monthly statements
    -- Aciklama :Starting after Ekstre, cbs-113 sms notification project
    -- Yazar : Bahiana Bektemir kyzy
    -- Tarih : 16112020 --modified with cbs-649 04042022
PROCEDURE ACC_MONTHLY_NOTIF(PN_GRUP_NO NUMBER, PN_LOG_NO NUMBER,PS_PROGRAM_KOD VARCHAR2) IS

LD_BANK_DATE           DATE := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL; 
ld_donemin_son_is_gunu DATE := Pkg_Tarih.donemin_son_is_gunu(LD_BANK_DATE);
ld_ayin_son_is_gunu    DATE := Pkg_Tarih.ayin_son_is_gunu(LD_BANK_DATE);
ld_yilin_son_is_gunu   DATE := Pkg_Tarih.yilin_son_is_gunu(LD_BANK_DATE);
    
cursor c_fis is
SELECT hesap_no FROM CBS_HESAP WHERE musteri_no IN (SELECT customer_no FROM cbs_cust_pack_ops WHERE operation_id = 6)
       AND durum_kodu = 'A' AND urun_tur_kod IN ('CURRENT', 'DEMAND DEP') AND urun_sinif_kod NOT IN ('OVERBALANCE-FC', 'OVERBALANCE-LC','ELCARD NON INT.BR-LC')--CBS-661 'ELCARD NON INT.BR-LC' added
       AND to_char(HESAP_NO) IN (SELECT SATIR_HESAP_NUMARA FROM CBS_VW_FIS_SATIR_VSZIZ 
                        WHERE FIS_MUHASEBELESTIGI_TARIH BETWEEN TRUNC(LD_BANK_DATE, 'MM') AND LD_BANK_DATE AND FIS_TUR = 'G');        
r_fis c_fis%rowtype;

begin
Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 IF ld_donemin_son_is_gunu = LD_BANK_DATE or ld_ayin_son_is_gunu = LD_BANK_DATE or ld_yilin_son_is_gunu = LD_BANK_DATE THEN 
            
        Delete from CBS.TBL_STATEMENT_ACC_TMP;
            
        OPEN c_fis;
            LOOP 
            FETCH c_fis INTO r_fis;
            EXIT WHEN c_fis%NOTFOUND;
                insert into TBL_STATEMENT_ACC_TMP (hesap_no)
                values (r_fis.hesap_no);        
                commit;
            end loop;            
            
        FOR c_tmp in (select * from CBS.TBL_STATEMENT_ACC_TMP order by 1)                       
            LOOP
                PKG_NOTIF_SUB.acc_monthly_notif(c_tmp.hesap_no);
                PKG_BAT_3.notif_ekstre_log(c_tmp.hesap_no,LD_BANK_DATE,PS_PROGRAM_KOD);
                commit;
            end loop;
            
 END IF;

Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  
  EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
     log_at ('ACC_MONTHLY_NOTIF',r_fis.hesap_no, sqlerrm,dbms_utility.format_error_backtrace);  
end;
/* bahianab cbs-649 04042022 */
PROCEDURE NOTIF_EKSTRE_LOG (PN_HESAP_NO NUMBER, PD_BANK_DATE DATE, PS_PROGRAM_KOD VARCHAR2)
IS PRAGMA AUTONOMOUS_TRANSACTION;
   ln_logid   NUMBER;
BEGIN
   ln_logid := pkg_genel.genel_kod_al ('NOTIFEKSTRELOGID');

   INSERT INTO tbl_ekstre_log (log_id,hesap_no,bank_date,sys_date,program_code)
        VALUES (ln_logid,pn_hesap_no,pd_bank_date,SYSDATE,ps_program_kod);
   COMMIT;
EXCEPTION
   WHEN OTHERS THEN 
   ROLLBACK;
   log_at ('NOTIF_EKSTRE_LOG', TO_CHAR (pn_hesap_no), SQLERRM);      
END;
End;
/

