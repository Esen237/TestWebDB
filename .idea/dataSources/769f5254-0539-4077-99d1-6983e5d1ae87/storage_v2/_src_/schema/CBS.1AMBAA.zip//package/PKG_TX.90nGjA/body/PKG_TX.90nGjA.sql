create PACKAGE BODY     pkg_tx IS

   Sk_mesaj varchar2(2000);
   Ss_mesaj varchar2(2000);
   St_mesaj varchar2(2000);

   Sdogrulama_iptal varchar2(2000);
   Sreddetme varchar2(2000);
   Siptal_sonrasi varchar2(2000);
   Siptal_onay_sonrasi varchar2(2000);
   Sgeri_cevir varchar2(2000);

   -- Ana Servisler

   Procedure kilit_test(pn_islem_no number) is
     ln_dummy_for_lock number;
   Begin
     select 1
       into ln_dummy_for_lock
       from cbs_islem
      where numara=pn_islem_no
        for update nowait;
   
   --bom bahianab cbs-345
   Exception
       When others Then
             Raise_application_error(-20100,pkg_hata.getUCPOINTER||'3508'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   --eom bahianab cbs-345 
   
   End;

   Procedure Kayit_Kullanim_Test (pn_islem_no number) is

     cursor c1 is
       select cid.tablo_adi,cid.kolon_adi
         from cbs_islem_dosya cid, cbs_islem ci
        where cid.islem_tanim_kod=ci.islem_kod
          and ci.numara=pn_islem_no;

     r_c1                               c1%rowtype;
     ls_plsql_block                  varchar2(2000);

   Begin
     Open c1;
     Loop
       fetch c1 into r_c1;
       exit when c1%notfound;
         -- dinamik sql olu?tur ve ?al??t?r
         ls_plsql_block := 'DECLARE '||
                           '  ln_dummy_for_lock number; '||
                           'BEGIN '||
                           '  Select 1 into ln_dummy_for_lock '||
                           '    from '||r_c1.tablo_adi||
                           '   where '||r_c1.kolon_adi||'='||to_char(pn_islem_no)||' for update nowait;'||
                           ' END;';
         EXECUTE IMMEDIATE ls_plsql_block;

     End loop;
     Close c1;

   Exception
       When others Then
           if sqlcode='-54' then
             Raise_application_error(-20100,pkg_hata.getUCPOINTER||'3508' ||pkg_hata.getUCPOINTER);
           else
             Raise_application_error(-20100,pkg_hata.getUCPOINTER||'3507'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
           end if;
   End;

   Function islem_no_al return number is
     ln_islem_no    number;
   Begin
        Select sq_islem_no.nextval
          into ln_islem_no
          from dual;
        Return ln_islem_no;
   Exception
        When Others Then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'59'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;

   Function islem_tipi_al(pn_islem_kod number) return varchar2 is
     ls_islem_tipi    varchar2(1);
   Begin
        Select islem_tipi
          into ls_islem_tipi
          from cbs_islem_tanim
         where kod=pn_islem_kod;
        return ls_islem_tipi;
   Exception
        When Others Then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'59'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;


   Procedure Islem_Calistir(pn_islem_numara number) is
   Begin
     If pkg_tx.Dogrula_Kontrol(pn_islem_numara) Then
         return;
     Elsif pkg_tx.Onay_Kontrol(pn_islem_numara) Then
         return;
     Else
         pkg_tx.muhasebelestir(pn_islem_numara);
     End If;
   End;

   Procedure Gecici_Islem_Yarat(pn_islem_numara              number
                                               ,pn_islem_kod                 number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                       ) is
    ln_islem_var number;
   Begin
      select count(*)
        into ln_islem_var
        from cbs_islem_gecici
       where numara = pn_islem_numara
         and durum = 'G';

      if ln_islem_var = 0 then
       Insert into cbs_islem_gecici (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                      values (pn_islem_numara,pn_islem_kod,'G',pkg_baglam.bolum_kodu,
                              pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                              pkg_muhasebe.banka_tarihi_bul,sysdate,
                              pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
                              pn_musteri_numara,pc_hesap_numara,pn_tutar,pc_kasa_kod,pc_doviz_kod
                      );
     else
       update cbs_islem_gecici
          set
              ISLEM_KOD = pn_islem_kod,
              AMIR_BOLUM_KODU = pkg_baglam.bolum_kodu,
              KAYIT_KULLANICI_KODU = pkg_baglam.kullanici_kodu,
              KAYIT_KULLANICI_ROL_NUMARA = pkg_baglam.rol_numara,
              KAYIT_KULLANICI_BOLUM_KODU = pkg_baglam.bolum_kodu,
              KAYIT_TARIH = pkg_muhasebe.banka_tarihi_bul,
              KAYIT_SISTEM_TARIHI = sysdate,
              MODUL_TUR_KOD = pc_modul_tur_kod,
              URUN_TUR_KOD = pc_urun_tur_kod,
              URUN_SINIF_KOD = pc_urun_sinif_kod,
              MUSTERI_NUMARA = pn_musteri_numara,
              HESAP_NUMARA = pc_hesap_numara,
              TUTAR = pn_tutar,
              KASA_KOD = pc_kasa_kod,
              DOVIZ_KOD = pc_doviz_kod
        where NUMARA = pn_islem_numara;
     end if;
      Exception
           When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
      End;

   Procedure Gecici_Islem_Sil(pn_islem_numara       number) is
   Begin
       update cbs_islem_gecici
          set durum = 'X'
        where NUMARA = pn_islem_numara;
       Commit;
   End;
   Procedure Islem_Yarat(pn_islem_numara              number
                                               ,pn_islem_kod                 number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                       ) is
   Begin

     Begin
       Insert into cbs_islem (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD)
                      values (pn_islem_numara,pn_islem_kod,'N',pkg_baglam.bolum_kodu,
                              pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,
                              pkg_muhasebe.banka_tarihi_bul,sysdate,
                              pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
                              pn_musteri_numara,pc_hesap_numara,pn_tutar,pc_kasa_kod,pc_doviz_kod
                      );

        --gecici islemden geliyorsa gecici islem durumunun set edilmesi gerekli
        --TDL: gecici islem no wait

        update cbs_islem_gecici
           set durum = 'C'
         where numara=pn_islem_numara;

      Exception
           When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'60'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
      End;

     Giris_Kontrol(pn_islem_numara);

     Harici_Kod_Cagir(pn_islem_numara,'Kontrol_Sonrasi');

   End;

   Procedure Islem_Guncelle(pn_islem_numara              number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                       ) is
   Begin

       Kilit_Test(pn_islem_numara);

        Update cbs_islem set  AMIR_BOLUM_KODU = pc_bolum_kodu,
                              MODUL_TUR_KOD=pc_modul_tur_kod,
                              URUN_TUR_KOD=pc_urun_tur_kod,
                              URUN_SINIF_KOD=pc_urun_sinif_kod,
                              MUSTERI_NUMARA=pn_musteri_numara,
                              HESAP_NUMARA=pc_hesap_numara,
                              TUTAR=pn_tutar,
                              KASA_KOD=pc_kasa_kod,
                              DOVIZ_KOD=pc_doviz_kod
                      where numara=pn_islem_numara;

   Exception
        When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1225'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;


   Procedure Giris_Kontrol(pn_islem_no number) is

   lc_dogrulama                varchar2(1);
   lc_onay                     varchar2(1);
   lc_iptal_onay            varchar2(1);
   lc_dogrula_guncelle  varchar2(1);
   lc_onay_guncelle     varchar2(1);

   cursor c1 is
    select rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      from cbs_rol_urun_islem rui,cbs_islem,cbs_zaman,cbs_limit
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum IN ('N')
       and cbs_islem.islem_kod      = rui.islem_tanim_kod
       and cbs_islem.modul_tur_kod  = rui.modul_tur_kod
       and cbs_islem.urun_tur_kod   = rui.urun_tur_kod
       and cbs_islem.urun_sinif_kod = rui.urun_sinif_kod
       and rui.rol_numara       = pkg_baglam.rol_numara
       and rui.zaman_numara     = cbs_zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = cbs_limit.numara
       and ( ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'S' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between alt and ust)  or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'F' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,cbs_limit.doviz_kod,null,ust) ) or
             ( cbs_limit.tum_dovizler ='H' and cbs_limit.karsilik = 'L' and nvl(cbs_islem.doviz_kod,pkg_genel.lc_al) = cbs_limit.doviz_kod
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,cbs_limit.doviz_kod,null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'F'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.tum_dovizler ='E' and cbs_limit.karsilik = 'L'
                                               and nvl(cbs_islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(cbs_islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( cbs_limit.karsilik = 'N' )
             );

   Begin
        Begin
       open c1;
       loop
          fetch c1 into lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          exit when c1%notfound;

          Kilit_Test(pn_islem_no);

          update cbs_islem
            set durum           = 'C' ,
                dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          where numara=pn_islem_no;

        return;
       end loop;
       close c1;
     Exception
          When Others Then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'62'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
     End;
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'61'|| pkg_hata.getDELIMITER ||TO_CHAR(SQLCODE)|| ' ' || replace(SQLERRM,'***','')||pkg_hata.getDELIMITER ||pkg_hata.getUCPOINTER);
   End;

   Function  Dogrula_Kontrol(pn_islem_no number) return boolean is

     cursor c1 is
     select cbs_islem.dogrulanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum = 'C';

     lc_dogrulama          cbs_rol_urun_islem.dogrulama%type;
     lc_durum             cbs_islem.durum%type;

   Begin
     open c1;
     loop
       fetch c1 into lc_dogrulama,lc_durum;
         exit when c1%notfound;
       if lc_dogrulama = 'H' then
          close c1;

          Harici_Kod_Cagir(pn_islem_no,'Dogrulama_Sonrasi');

          return FALSE ; -- Gerek yok
       else
          close c1;
          return TRUE ; -- Gerek var
       end if;

     end loop;
     close c1;
     Raise_application_error(-20100,pkg_hata.getUCPOINTER||'65'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;

   Function  Onay_Kontrol(pn_islem_no number) return boolean is

     cursor c1 is
     select cbs_islem.onaylanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and ( (cbs_islem.durum='C' and dogrulanmali_mi='H') or (cbs_islem.durum='V' and dogrulanmali_mi='E') ) ;

     lc_onaylama          cbs_rol_urun_islem.onay%type;
     lc_durum             cbs_islem.durum%type;

   Begin
     open c1;
     loop
       fetch c1 into lc_onaylama,lc_durum;
         exit when c1%notfound;
          log_at('onay',lc_onaylama);
       if lc_onaylama = 'H' then
          close c1;
      
          Harici_Kod_Cagir(pn_islem_no,'Onay_Sonrasi');

          return FALSE ; -- Gerek yok
       else
          close c1;
          return TRUE ; -- Gerek var
       end if;

     end loop;
     close c1;
     Raise_application_error(-20100,pkg_hata.getUCPOINTER||'66'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;

   Function  Iptal_Kontrol(pn_islem_no number) return boolean is

     cursor c1 is
     select cbs_islem.iptal_onaylanmali_mi
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum = '1';

     lc_onaylama          cbs_rol_urun_islem.onay%type;

   Begin
     open c1;
     loop
       fetch c1 into lc_onaylama;
         exit when c1%notfound;

         if lc_onaylama = 'E' then
            close c1;
            return TRUE ; -- Gerek var
         else
            close c1;

            Harici_Kod_Cagir(pn_islem_no,'Iptal_Onay_Sonrasi');
            return FALSE ; -- Gerek yok
         end if;

     end loop;
     close c1;
     Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1323'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;

   Procedure Dogrula( pn_islem_no  number ,pb_onay_red  boolean default true,ps_sebep     varchar2 default null) is
     cursor c1 is
     select cbs_islem.dogrulanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum = 'C';

     lc_dogrulama          cbs_rol_urun_islem.dogrulama%type;
     lc_durum             cbs_islem.durum%type;

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_dogru rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum           in ( 'C' )
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H')
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin
     open c1;
     fetch c1 into lc_dogrulama,lc_durum;
     close c1;
     if lc_dogrulama = 'H' then  -- Dogrulanmaya gerek yok
         return ;
     end if;

     if pkg_baglam.bolum_kodu!='SYS' then

       open c2;
       fetch c2 into ln_dummy;
       if c2%notfound then
         close c2;
         -- Dogrulama yetkisi yok
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'67'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
       else
         close c2;
       end if;

     end if;

     Kilit_Test(pn_islem_no);

     if pb_onay_red then
        update cbs_islem
           set durum                      = 'V',
               dogru_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               dogru_kullanici_rol_numara = pkg_baglam.rol_numara,
               dogru_kullanici_bolum_kodu = pkg_baglam.bolum_kodu,
               dogru_tarih                = pkg_muhasebe.banka_tarihi_bul,
               dogrulama_sistem_tarihi      = sysdate,
               dogrula_aciklama                =ps_sebep
         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Dogrulama_Sonrasi');

     else
        update cbs_islem
           set durum                      = 'D',
               dogru_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               dogru_kullanici_rol_numara = pkg_baglam.rol_numara,
               dogru_kullanici_bolum_kodu = pkg_baglam.bolum_kodu,
               dogru_tarih                = pkg_muhasebe.banka_tarihi_bul,
               dogrulama_sistem_tarihi      = sysdate,
               dogrula_aciklama                =ps_sebep
         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Dogrulama_Iptal_Sonrasi');

     end if;
   End;

   Procedure Onay( pn_islem_no  number ,pb_onay_red  boolean default true, ps_sebep varchar2 default null) is
     cursor c1 is
     select cbs_islem.onaylanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and ( (cbs_islem.durum='C' and dogrulanmali_mi='H') or (cbs_islem.durum='V' and dogrulanmali_mi='E') ) ;

     lc_onay               cbs_rol_urun_islem.onay%type;
     lc_durum             cbs_islem.durum%type;

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_onay rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and ( (islem.durum='C' and dogrulanmali_mi='H') or (islem.durum='V' and dogrulanmali_mi='E') )
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin
     open c1;
     fetch c1 into lc_onay,lc_durum;
     close c1;
     if lc_onay = 'H' then  -- Onaya gerek yok
         return ;
     end if;

     if pkg_baglam.bolum_kodu!='SYS' then

       open c2;
       fetch c2 into ln_dummy;
       if c2%notfound then
         close c2;
         -- Onay yetkisi yok
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'68' || pkg_hata.getDELIMITER || SQLERRM || pkg_hata.getUCPOINTER);
       else
         close c2;
       end if;
     end if;

     Kilit_Test(pn_islem_no);

     if pb_onay_red then
        update cbs_islem
           set durum                      = 'A',
               onay_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               onay_kullanici_rol_numara = pkg_baglam.rol_numara,
               onay_kullanici_bolum_kodu = pkg_baglam.bolum_kodu,
               onay_tarih                = pkg_muhasebe.banka_tarihi_bul,
               onay_sistem_tarihi           = sysdate,
               onay_aciklama                         = ps_sebep

         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Onay_Sonrasi');

     else
        update cbs_islem
           set durum                      = 'R',
               onay_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               onay_kullanici_rol_numara = pkg_baglam.rol_numara,
               onay_kullanici_bolum_kodu = pkg_baglam.bolum_kodu,
               onay_tarih                = pkg_muhasebe.banka_tarihi_bul,
               onay_sistem_tarihi           = sysdate,
               onay_aciklama                         = ps_sebep
         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Reddetme_Sonrasi');

     end if;
   End;

   Procedure Iptal( pn_islem_no  number ) is

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_iptal rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum in('C','V','A','P','3')
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin
     open c2;
     fetch c2 into ln_dummy;
     if c2%notfound then
       close c2;
       -- iptal yetkisi yok
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1324' || pkg_hata.getDELIMITER || SQLERRM || pkg_hata.getUCPOINTER);
     else
       close c2;
     end if;

     Kilit_Test(pn_islem_no);

        update cbs_islem
           set durum                      = '1',
               iptal_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               iptal_kullanici_rol_numara = pkg_baglam.rol_numara,
               iptal_kullanici_bolum_kodu = pkg_baglam.bolum_kodu,
               iptal_tarih                = pkg_muhasebe.banka_tarihi_bul,
               iptal_sistem_tarihi          = sysdate,
               iptal_tamamlanma_tarihi    = pkg_muhasebe.banka_tarihi_bul

         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Iptal_Sonrasi');

   End;

   Procedure iptal_muhasebelestir(pn_islem_no number ) is
   
   TYPE CursorReferenceType IS REF CURSOR;
    pc_ref CursorReferenceType;         --zhypargulc cbs-191
    
     cursor c1 is
       select numara
         from cbs_fis
        where islem_numara = pn_islem_no;
     ln_fis_numara number;
     
     
     cursor c_satirs(pn_islem_numara NUMBER) is
        select  s.fis_numara, s.numara, s.tur, s.hesap_numara, s.lc_tutar ,h.urun_sinif_kod from cbs_satir s 
        join cbs_hesap h on (h.hesap_no = s.hesap_numara)
        where s.fis_islem_numara = nvl(pn_islem_numara, s.fis_islem_numara) 
        and (pn_islem_numara is not null )
        and h.urun_sinif_kod = 'ELCARD NON INT.BR-LC' and s.fis_tur = 'X';--zhypargulc cbs-191
    
     r_q c_satirs%ROWTYPE;
     ls_response varchar2(10) := '1';
     wserror exception;
     
   Begin
     open c1;
     loop
       fetch c1 into ln_fis_numara;
       if c1%notfound then
            exit;
          end if;
       pkg_muhasebe.fis_iptal(ln_fis_numara);

     end loop;
     close c1;
     
      OPEN c_satirs(pn_islem_no);
         loop
         
         FETCH c_satirs INTO r_q;
         EXIT WHEN c_satirs%NOTFOUND;
        
         
            if (r_q.tur = 'B') then
                ls_response := pkg_elcard.makeElcardWSIncome(r_q.lc_tutar, r_q.hesap_numara, pc_ref); --bahianab cbs-531 Elcard optimization
            else
                ls_response := pkg_elcard.makeElcardWSOutcome(r_q.lc_tutar, r_q.hesap_numara, pc_ref); --bahianab cbs-531 Elcard optimization
            end if;
            
            if (ls_response = '1')  then
                pkg_elcard.UpdateElcardWSLog(pn_islem_no, r_q.fis_numara, r_q.numara, r_q.hesap_numara, r_q.lc_tutar, 'C', 2); --bahianab cbs-531 Elcard optimization
            else
            raise wserror;
            end if;
            
         end loop;
      close c_satirs;       --zhypargulc cbs-191

     Harici_Kod_Cagir(pn_islem_no,'Iptal_Muhasebelestir_Sonrasi');

     Kilit_Test(pn_islem_no);

     update cbs_islem
        set durum                           = '2',
            iptal_tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
     where numara=pn_islem_no;
        commit;

   Exception
        When wserror Then
       Rollback;
        RAISE_APPLICATION_ERROR(-20100, '6176' || pkg_hata.getdelimiter || r_q.hesap_numara || ' ' || SQLERRM || pkg_hata.getucpointer);    --zhypargulc cbs-191
        When no_data_found Then
       Rollback;
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1387'||pkg_hata.getUCPOINTER);
        When Others Then
       Rollback;
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1388'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;


   Procedure Iptal_Onay( pn_islem_no  number ,pb_onay_red  boolean default true, ps_sebep varchar2 default null) is
  cursor c2 is
    select 1
      from cbs_rol_urun_islem_iptal_onay rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum in('1')
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin

     if pkg_baglam.bolum_kodu!='SYS' then
       open c2;
       fetch c2 into ln_dummy;
       if c2%notfound then
         close c2;
         -- Iptal Onay yetkisi yok
         Raise_application_error(-20100,pkg_hata.getUCPOINTER||'1326' || pkg_hata.getDELIMITER || SQLERRM || pkg_hata.getUCPOINTER);
       else
         close c2;
       end if;
     end if;

     Kilit_Test(pn_islem_no);

     if pb_onay_red then
        update cbs_islem
           set durum                           = '2',
               iptal_onay_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               iptal_onay_rol_numara           = pkg_baglam.rol_numara,
               iptal_onay_bolum_kodu           = pkg_baglam.bolum_kodu,
               iptal_onay_tarih                = pkg_muhasebe.banka_tarihi_bul,
               iptal_onay_sistem_tarihi           = sysdate,
               iptal_onay_aciklama                         = ps_sebep,
               iptal_tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Iptal_Onay_Sonrasi');

       iptal_muhasebelestir(pn_islem_no);

     else
        update cbs_islem
           set durum                           = '3',
               iptal_onay_kullanici_kodu       = pkg_baglam.kullanici_kodu,
               iptal_onay_rol_numara           = pkg_baglam.rol_numara,
               iptal_onay_bolum_kodu           = pkg_baglam.bolum_kodu,
               iptal_onay_tarih                = pkg_muhasebe.banka_tarihi_bul,
               iptal_onay_aciklama                         = ps_sebep,
               iptal_tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
         where numara=pn_islem_no;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Iptal_Reddetme_Sonrasi');

     end if;
   End;

   Function Dogrulanabilir_mi( pn_islem_no  number) return number is
     cursor c1 is
     select cbs_islem.dogrulanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and cbs_islem.durum = 'C';

     lc_dogrulama          cbs_rol_urun_islem.dogrulama%type;
     lc_durum             cbs_islem.durum%type;

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_dogru rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum           in ( 'C' )
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin
     open c1;
     fetch c1 into lc_dogrulama,lc_durum;
     close c1;
     if lc_dogrulama = 'H' then  -- Dogrulanmaya gerek yok
         return 0 ;
     end if;

     open c2;
     fetch c2 into ln_dummy;
     if c2%notfound then
       close c2;
       return 0;   -- Dogrulama yetkisi yok
     else
       close c2;
     end if;

     return 1;
   End;


   Function Onaylanabilir_mi( pn_islem_no  number) return number is
     cursor c1 is
     select cbs_islem.onaylanmali_mi, cbs_islem.durum
      from cbs_islem
     where cbs_islem.numara = pn_islem_no
       and ( (cbs_islem.durum='C' and dogrulanmali_mi='H') or (cbs_islem.durum='V' and dogrulanmali_mi='E') ) ;

     lc_onay               cbs_rol_urun_islem.onay%type;
     lc_durum             cbs_islem.durum%type;

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_onay rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and ( (islem.durum='C' and dogrulanmali_mi='H') or (islem.durum='V' and dogrulanmali_mi='E') )
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu and nvl(islem.dogru_kullanici_kodu,' ')!= pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin
     open c1;
     fetch c1 into lc_onay,lc_durum;
     close c1;
     if lc_onay = 'H' then  -- Onaya gerek yok
         return 0;
     end if;

     open c2;
     fetch c2 into ln_dummy;
     if c2%notfound then
       close c2;
       return 0; -- Onay yetkisi yok
     else
       close c2;
     end if;

     return 1;
   End;


   Function Iptal_edilebilir_mi( pn_islem_no  number) return number is

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_iptal rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum in('C','V','A','P','3')
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin

     open c2;
     fetch c2 into ln_dummy;
     if c2%notfound then
       close c2;
       return 0; -- Iptal yetkisi yok
     else
       close c2;
     end if;

     return 1;
   End;

   Function Iptal_Onaylanabilir_mi( pn_islem_no  number) return number is

  cursor c2 is
    select 1
      from cbs_rol_urun_islem_iptal_onay rui
          ,cbs_islem islem
          ,cbs_zaman zaman
          ,cbs_limit limit
     where islem.numara          = pn_islem_no
       and islem.durum in('1')
       and islem.islem_kod       = rui.islem_tanim_kod
       and islem.modul_tur_kod   = rui.modul_tur_kod
       and islem.urun_tur_kod    = rui.urun_tur_kod
       and islem.urun_sinif_kod  = rui.urun_sinif_kod
       and rui.rol_numara        = pkg_baglam.rol_numara
       and ( ( rui.ayni_bolum='H' )
             or
             ( rui.ayni_bolum='E' and islem.amir_bolum_kodu=pkg_baglam.bolum_kodu)
           )
       and ( ( rui.ayni_kullanici='H' and islem.kayit_kullanici_kodu != pkg_baglam.kullanici_kodu)
             or
             ( rui.ayni_kullanici='E' )
           )
       and rui.zaman_numara = zaman.numara
           and to_number(to_char(sysdate,'HH24')) between baslangic and bitis
           and rui.limit_numara = limit.numara
       and ( ( limit.tum_dovizler ='H' and limit.karsilik = 'S' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between alt and ust)  or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'F' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,limit.doviz_kod,null,ust) ) or
             ( limit.tum_dovizler ='H' and limit.karsilik = 'L' and nvl(islem.doviz_kod,pkg_genel.lc_al) = limit.doviz_kod
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,limit.doviz_kod,null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'F'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.fc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.tum_dovizler ='E' and limit.karsilik = 'L'
                                               and nvl(islem.tutar,0) between
                                                   pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,alt) and
                                                     pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al,nvl(islem.doviz_kod,pkg_genel.lc_al),null,ust) ) or
               ( limit.karsilik = 'N' )
             );

   ln_dummy             number;
   Begin

     open c2;
     fetch c2 into ln_dummy;
     if c2%notfound then
       close c2;
       return 0; -- Iptal yetkisi yok
     else
       close c2;
     end if;

     return 1;
   End;

   Procedure Muhasebelestir(pn_islem_no number) is
   Begin

     Harici_Kod_Cagir(pn_islem_no,'Muhasebelesme');
log_at('Muhasebelestir',1,pn_islem_no);
     Kilit_Test(pn_islem_no);
log_at('Muhasebelestir',2,pn_islem_no);     

     update cbs_islem
        set durum = 'P',
            tamamlanma_tarihi=pkg_muhasebe.banka_tarihi_bul
      where numara=pn_islem_no;
 log_at('Muhasebelestir',3,pn_islem_no);       

     Commit;

   Exception

     When Others then

       Rollback;
       Raise_application_error(-20100,SQLERRM);

   End;

   Procedure Tamam(pn_islem_no number) is
   Begin
     Harici_Kod_Cagir(pn_islem_no,'Tamam_Sonrasi');
   End;

   Function Islem_durumu(pn_islem_no number) return varchar2 is
     lc_durum varchar2(1);
   Begin
     select cbs_islem.durum
       into lc_durum
       from cbs_islem
      where cbs_islem.numara = pn_islem_no;
     return lc_durum;
   Exception
        When no_data_found Then
       log_at('hakan_eod_error_1','pn_islem_no',pn_islem_no);
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'70'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
        When Others Then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'71'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   End;

   Procedure Harici_Kod_Cagir(pn_islem_no number, pc_cikis_yeri varchar2, pb_zorunlu_mu boolean default TRUE) is

     Cursor c1 is
       Select ci.islem_kod
         from user_procedures up, cbs_islem ci
        where ci.numara=pn_islem_no
          and object_name = 'PKG_TX'||to_char(ci.islem_kod)
          and procedure_name = upper(pc_cikis_yeri);

     ln_dummy             number;
     ln_islem_kod        number;
     lc_plsql_block         varchar2(2000);
     ls_batch_islem_mi   varchar2(1);
   Begin

     Select cit.batch_islem_mi
       into ls_batch_islem_mi
       from cbs_islem ci,cbs_islem_tanim cit
      where ci.numara=pn_islem_no
        and ci.ISLEM_KOD=cit.KOD;
        
log_at('Harici_Kod_Cagir',1,ls_batch_islem_mi);

     if ls_batch_islem_mi='E' then --Batch islemlerde callback fonksiyonlar ?a?r?lmaz.
       return;
     end if;
log_at('Harici_Kod_Cagir',2);
     open c1;
     fetch c1 into ln_islem_kod;
     if c1%notfound then
       close c1;
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'2824'|| pkg_hata.getDELIMITER ||pc_cikis_yeri||pkg_hata.getUCPOINTER);
       Return;
     end if;
log_at('Harici_Kod_Cagir',3,ln_islem_kod);
     lc_plsql_block := 'BEGIN '||'PKG_TX'||to_char(ln_islem_kod)||'.'||pc_cikis_yeri||'('||to_char(pn_islem_no)||');'||' END;';
log_at('Harici_Kod_Cagir',3.1,lc_plsql_block);
   EXECUTE IMMEDIATE lc_plsql_block;
log_at('Harici_Kod_Cagir',4);
   End;

   Function Islem_kod(pn_islem_no number) return number is
    lc_islem_kod number;
   begin
       select islem_kod
        into lc_islem_kod
        from cbs_islem
        where numara=pn_islem_no;
       return lc_islem_kod;
   end;

   Function fis_no(pn_islem_no number) return number is
    lc_fis_no number;
   begin
       select nvl(fis_no,0)
        into lc_fis_no
        from cbs_islem,cbs_fis
        where cbs_islem.numara=pn_islem_no
          and cbs_islem.fis_numara=cbs_fis.numara;
       return lc_fis_no;
   exception
        when no_data_found then
       return 0;
   end;

   Function dogrula_guncelle (pn_islem_no number) return boolean is
    lc_dogrula_guncelle varchar2(1);
   begin
       select dogrula_guncelle
        into lc_dogrula_guncelle
        from cbs_islem
        where numara=pn_islem_no;
       if lc_dogrula_guncelle = 'E' then
            return true;
       else
             return false;
       end if;
   end;

   Function onay_guncelle (pn_islem_no number) return boolean is
    lc_onay_guncelle varchar2(1);
   begin
       select onay_guncelle
        into lc_onay_guncelle
        from cbs_islem
        where numara=pn_islem_no;
       if lc_onay_guncelle = 'E' then
            return true;
       else
             return false;
       end if;
   end;

   Procedure Onay_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   begin
    Ss_mesaj:=ps_mesaj;
   end;

   Function  Onay_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   begin
     ls_mesaj:=ss_mesaj;
     ss_mesaj:='';
     return ls_mesaj;
   end;

   Procedure Tamam_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   begin
    St_mesaj:=ps_mesaj;
   end;

   Function  Tamam_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   begin
     ls_mesaj:=St_mesaj;
     St_mesaj:='';
     return ls_mesaj;
   end;

   Function Islem_bitmis_mi(pn_islem_no number) return number is
     pn_dummy number;
   Begin
     select 1
       into pn_dummy
       from cbs_islem
      where numara=pn_islem_no
        and durum in ('C','V','1');
     return 0;     -- hayir bitmemis
   Exception
     When no_data_found then
       return 1;  -- evet bitmis veya yok
   End;

   Function Islem_onaylanmis_mi(pn_islem_no number) return number
   is
     pn_dummy number;
   Begin
     select 1
       into pn_dummy
       from cbs_islem
      where numara=pn_islem_no
        and durum in ('P', '3');
     return 0;     -- hayir bitmemis
   Exception
     When no_data_found then
       return 1;  -- evet bitmis veya yok
   End;

   Function islem_yaratilmis_mi(pn_islem_no number) return number
   is
     pn_dummy number;
   Begin
     select 1
       into pn_dummy
       from cbs_islem
      where numara=pn_islem_no;
     return 1;     -- yaratilmis
   Exception
     When no_data_found then
       return 0;  -- yaratilmamis
   End;

   Function Islem_BolumKodu_Al( pn_islem_no number) return cbs_bolum.kodu%type
   is
    ls_bolum_kodu cbs_bolum.kodu%type ;
   begin
        select KAYIT_KULLANICI_BOLUM_KODU
      into  ls_bolum_kodu
      from  cbs_islem
       where numara=pn_islem_no;

       return ls_bolum_kodu;
   end;

   Function Amir_BolumKodu_Al( pn_islem_no number) return cbs_bolum.kodu%type
   is
    ls_bolum_kodu cbs_bolum.kodu%type ;
   begin
        select AMIR_BOLUM_KODU
      into  ls_bolum_kodu
      from  cbs_islem
       where numara=pn_islem_no;

       return ls_bolum_kodu;
   end;

   Function gecici_girilmis_mi(pn_islem_no number) return varchar2 is
    ln_satir_sayi number;
   begin
    select count(*)
      into ln_satir_sayi
      from cbs_satir s, cbs_fis f
     where s.fis_numara = f.numara
       and f.islem_numara = pn_islem_no
       and f.TUR='T';
    if ln_satir_sayi>0 then
     return 'E';
    else
     return 'H';
    end if;
   end;

   Function islem_batch_mi(pn_islem_no number) return boolean is
     ps_dummy varchar2(1);
   Begin
     select batch_islem_mi
       into ps_dummy
       from cbs_islem_tanim cit,cbs_islem ci
      where ci.islem_kod=cit.kod
        and numara=pn_islem_no;
     if ps_dummy='E' then
       return TRUE;
     else
       return FALSE;
     end if;
   End;

   Procedure Dinamik_Onay_Belirle ( pn_islem_no number, pc_dogrulama varchar2,pc_onay varchar2,pc_iptal_onay varchar2,pc_dogrula_guncelle varchar2,pc_onay_guncelle varchar2) is
   Begin

     Kilit_Test(pn_islem_no);

          update cbs_islem
            set durum           = 'C' ,
                dogrulanmali_mi = nvl(pc_dogrulama,dogrulanmali_mi),
                onaylanmali_mi  = nvl(pc_onay,onaylanmali_mi),
                iptal_onaylanmali_mi=nvl(pc_iptal_onay,iptal_onaylanmali_mi),
                dogrula_guncelle = nvl(pc_dogrula_guncelle,dogrula_guncelle),
                onay_guncelle = nvl(pc_onay_guncelle,onay_guncelle)
          where numara=pn_islem_no;
   End;

   Procedure Kontrol_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Sk_mesaj:=ps_mesaj;
   End;

   Function Kontrol_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=sk_mesaj;
     sk_mesaj:='';
     return ls_mesaj;
   End;

   Function Appr_Priv_branch_to_branch(pn_islem_no number) return number
   is
     result number := 0;
     lc_creator_user    cbs_kullanici.KODU%TYPE;
     lc_creator_branch  VARCHAR2(3);
     lc_approver_branch VARCHAR2(3);
     lc_tx_type            NUMBER;
   begin
     select islem.kayit_kullanici_kodu,
             nvl(kulla.CALISILAN_BOLUM, '010'),
             islem.islem_kod
       into lc_creator_user,
               lc_creator_branch,
               lc_tx_type
       from cbs_islem islem,
               cbs_kullanici kulla
      where islem.numara = pn_islem_no and
              islem.kayit_kullanici_kodu = kulla.KODU;

     select nvl(CALISILAN_BOLUM, '010')
       into lc_approver_branch
       from cbs_kullanici
      where kodu = user;

     if lc_creator_branch = lc_approver_branch then
       return 1;
     else
       select count(*)
         into result
         from CBS_MAIN_CAN_APPROVE
        where TX_TYPE = lc_tx_type and
              CREATOR_BRANCH_CODE  = lc_creator_branch and
              APPROVER_BRANCH_CODE = lc_approver_branch;
       return result;
     end if;
   exception
     when others then return 0;
   end;
------------------------------------------------------------------------
Function Islemden_Kayit_Kullanici_al(pn_islem_no number) return varchar2
is
    ls_ret   varchar2(20) ;
begin
    select KAYIT_KULLANICI_KODU
    into ls_ret
    from CBS_ISLEM
    where numara = pn_islem_no;

    return ls_ret;
end;
------------------------------------------------------------------------
   Procedure Dog_Ipt_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Sdogrulama_iptal:=ps_mesaj;
   End;

   Function Dog_Ipt_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=Sdogrulama_iptal;
     Sdogrulama_iptal:='';
     return ls_mesaj;
   End;
----------------------------
   Procedure Reddetme_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Sreddetme:=ps_mesaj;
   End;

   Function Reddetme_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=Sreddetme;
     Sreddetme:='';
     return ls_mesaj;
   End;
----------------------------
   Procedure Ipt_Sonrasi_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Siptal_sonrasi:=ps_mesaj;
   End;

   Function Ipt_Sonrasi_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=Siptal_sonrasi;
     Siptal_sonrasi:='';
     return ls_mesaj;
   End;
----------------------------
   Procedure Ipt_Onay_Son_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Siptal_onay_sonrasi:=ps_mesaj;
   End;

   Function Ipt_Onay_Son_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=Siptal_onay_sonrasi;
     Siptal_onay_sonrasi:='';
     return ls_mesaj;
   End;
----------------------------
   procedure islem_geri_gonder(pn_islem_no number, ps_sebep varchar2 default null) is
     cursor c1 is
       select numara
         from cbs_fis
        where islem_numara = pn_islem_no;
     ln_fis_numara number;
   Begin
     Kilit_Test(pn_islem_no);

     insert into cbs_islem_durum_log
           (numara, islem_kod, yeni_durum, eski_durum, degisim_sistem_tarih, degisim_banka_tarih,
            degistiren_kullanici_kodu, degistiren_rol_numara, degistiren_kullanici_bolum,
            amir_bolum_kodu, kayit_kullanici_kodu, kayit_kullanici_rol_numara, kayit_kullanici_bolum_kodu,
            kayit_tarih, efektif_banka_tarih, dogru_kullanici_kodu, dogru_kullanici_rol_numara,
            dogru_kullanici_bolum_kodu, dogru_tarih, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
            musteri_numara, hesap_numara, tutar, doviz_kod, kanal_numara, kasa_kod, fis_numara,
            dogrulanmali_mi, onaylanmali_mi, dogrula_guncelle, onay_guncelle, iptal_onaylanmali_mi,
            kayit_sistem_tarihi, dogrulama_sistem_tarihi, dogrula_aciklama, geri_cevirme_sebep)
         (select numara, islem_kod, 'N', durum, sysdate, pkg_muhasebe.banka_tarihi_bul,
                 user, pkg_baglam.rol_numara, pkg_baglam.bolum_kodu,
                 amir_bolum_kodu, kayit_kullanici_kodu, kayit_kullanici_rol_numara, kayit_kullanici_bolum_kodu,
                 kayit_tarih, efektif_banka_tarih, dogru_kullanici_kodu, dogru_kullanici_rol_numara,
                 dogru_kullanici_bolum_kodu, dogru_tarih, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                 musteri_numara, hesap_numara, tutar, doviz_kod, kanal_numara, kasa_kod, fis_numara,
                 dogrulanmali_mi, onaylanmali_mi, dogrula_guncelle, onay_guncelle, iptal_onaylanmali_mi,
                 kayit_sistem_tarihi, dogrulama_sistem_tarihi, dogrula_aciklama, ps_sebep
            from cbs_islem
           where numara = pn_islem_no);

     pkg_kur_rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);

     update cbs_islem_gecici
        set durum = 'G'
      where numara=pn_islem_no;

     open c1;
     loop
       fetch c1 into ln_fis_numara;
       exit when c1%notfound;
       pkg_muhasebe.fis_iptal(ln_fis_numara);
     end loop;
     close c1;

       Kayit_Kullanim_Test(pn_islem_no);
       Harici_Kod_Cagir(pn_islem_no,'Geri_Cevirme_Sonrasi');

      delete from cbs_islem
       where numara = pn_islem_no;

    Exception
     When Others Then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER||'44'|| pkg_hata.getDELIMITER ||SQLERRM||pkg_hata.getUCPOINTER);
   end;
  ----------------------------
   Procedure Geri_Gonder_Mesaj_Parametresi( ps_mesaj varchar2 ) is
   Begin
    Sgeri_cevir:=ps_mesaj;
   End;

   Function Geri_Gonder_Mesaj_Parametresi return varchar2 is
     ls_mesaj varchar2(2000);
   Begin
     ls_mesaj:=Sgeri_cevir;
     Sgeri_cevir:='';
     return ls_mesaj;
   End;
----------------------------
   Function geri_cevrilebilir_mi( pn_islem_no  number) return number is
   cursor c_1 is
      select 1 from cbs_islem_tanim
       where geri_cevrilebilir = 'E'
         and kod = (select islem_kod
                      from cbs_islem
                     where numara = pn_islem_no)
         and exists (select 1
                       from cbs_islem
                      where numara = pn_islem_no
                        and durum in ('C', 'V')
                        and kanal_numara is null);
    ln_temp number;
   begin
     open c_1;
     fetch c_1 into ln_temp;
     if c_1%notfound then
        ln_temp := 0;
     else
        ln_temp := 1;
     end if;
     close c_1;
     return ln_temp;
   end;
----------------------------
   Function  Black_list(pn_islem_no number) return boolean is
     num number;
   Begin
      select count(*) into num from cbs_approval where islem_numara = pn_islem_no 
                                                and islem_kod is not null
                                                and (status = 'BLOCKED' or (status = 'Suspended' and numara is null));
       if nvl(num,0) > 0 then
          
          return TRUE ; -- in black_list
       else 
          return FALSE ; -- not in black_list
       end if;
       
   End;
----------------------------   
 Function fis_numara(pn_islem_no number) return number is   --seval.colak 30092021 
    lc_fis_no number;
   begin
        select nvl(fis_numara,0)
        into lc_fis_no
        from cbs_islem
        where cbs_islem.numara=pn_islem_no;
          
       return lc_fis_no;
   exception
        when no_data_found then
       return 0;
   end;

END;
/

