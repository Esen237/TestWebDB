create PACKAGE BODY     "PKG_INT_TRANSACTION" IS

/* *********************************************************************************** */
PROCEDURE CreateTransaction (pn_tran_no NUMBER
                            ,pn_tran_code NUMBER
                            ,pc_module_type_code VARCHAR2
                            ,pc_product_type_code VARCHAR2
                            ,pc_product_class_code VARCHAR2
                            ,pn_amount NUMBER
                            ,pc_tran_branch_code VARCHAR2 DEFAULT NULL
                            ,pc_branch_code VARCHAR2 DEFAULT 'INT'
                            ,pc_role VARCHAR2 DEFAULT 7777
                            ,pc_currency_code VARCHAR2 DEFAULT NULL
                            ,pn_customer_no NUMBER DEFAULT NULL
                            ,pc_account_no VARCHAR2 DEFAULT NULL
                            ,pc_cash_code VARCHAR2 DEFAULT NULL
                            ,pn_channel_no NUMBER DEFAULT 0
                            ,pc_register_user_code VARCHAR2 DEFAULT 'CINT_CALLER') 
IS
BEGIN
   
     log_at('PKG_INT_TRANSACTION', 'create_transaction', 1, 'pn_tran_no'||' '||pn_tran_no||'/'||
                             'pn_tran_code'||' '||pn_tran_code||'/'||
                             'pc_tran_branch_code'||' '||pc_tran_branch_code||'/'||
                             'pc_register_user_code'||' '||pc_register_user_code||'/'||
                             'pc_role'||' '||pc_role||'/'||
                             'pc_branch_code'||' '||pc_branch_code||'/'||
                             'pc_module_type_code'||' '||pc_module_type_code||'/'||
                             'pc_product_type_code'||' '||pc_product_type_code||'/'||
                             'pc_product_class_code'||' '||pc_product_class_code||'/'||
                             'pn_customer_no'||' '||pn_customer_no||'/'||
                             'pc_account_no'||' '||pc_account_no||'/'||
                             'pn_amount'||' '||pn_amount||'/'||
                             'pc_cash_code'||' '||pc_cash_code||'/'||
                             'pc_currency_code'||' '||pc_currency_code||'/'||
                             'pn_channel_no'||' '||pn_channel_no);
                             
     BEGIN
       insert into cbs_islem (numara,islem_kod,durum,amir_bolum_kodu,
                              kayit_kullanici_kodu,kayit_kullanici_rol_numara,kayit_kullanici_bolum_kodu,
                              kayit_tarih,kayit_sistem_tarihi,
                              modul_tur_kod,urun_tur_kod,urun_sinif_kod,
                              musteri_numara,hesap_numara,tutar,kasa_kod,doviz_kod,kanal_numara)
                      values (pn_tran_no,pn_tran_code,'N',pc_tran_branch_code,
                              pc_register_user_code,pc_role,pc_branch_code,
                              pkg_muhasebe.banka_tarihi_bul,sysdate,
                              pc_module_type_code,pc_product_type_code,pc_product_class_code,
                              pn_customer_no,pc_account_no,pn_amount,
                              pc_cash_code,pc_currency_code,pn_channel_no);

        update cbs_islem_gecici
           set durum = 'C'
         where numara=pn_tran_no;


     exception
           when others then
         raise_application_error(-20100,pkg_hata.getucpointer||'60'|| pkg_hata.getdelimiter ||sqlerrm||pkg_hata.getucpointer);
     END;
     Pkg_Int_Api.entry_control(pn_tran_no);
END;
/* *********************************************************************************** */
PROCEDURE ProcessTransaction(pn_tran_no IN NUMBER) 
IS
BEGIN

     IF Pkg_Tx.Dogrula_Kontrol(pn_tran_no) THEN        
        BEGIN
            Pkg_Tx.dogrula(pn_tran_no,TRUE);    
                          
            IF Pkg_Tx.Onay_Kontrol(pn_tran_no) THEN
                Pkg_Tx.onay(pn_tran_no, TRUE );                  
            END IF;
            
            Pkg_Tx.muhasebelestir(pn_tran_no);
        END;
     ELSIF Pkg_Tx.Onay_Kontrol(pn_tran_no) THEN    
        BEGIN
            log_at('A1->',pn_tran_no);
            
            Pkg_Tx.onay(pn_tran_no, TRUE );
                             
            log_at('A2->',pn_tran_no);
            
            Pkg_Tx.muhasebelestir(pn_tran_no);
            
            log_at('A3->');
        END;
     ELSE                                                 
        BEGIN
            Pkg_Tx.muhasebelestir(pn_tran_no);
        END;
     END IF;
END;
/***************************************************************************************/
PROCEDURE EntryControl(pn_tran_no NUMBER) 
IS
   lc_verification                VARCHAR2(1);
   lc_approval                    VARCHAR2(1);
   lc_cancel_approval             VARCHAR2(1);
   lc_modification_verification   VARCHAR2(1);
   lc_modification_approval       VARCHAR2(1);
   
   CURSOR c1 IS
    SELECT rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      FROM CBS_ROL_URUN_ISLEM rui,CBS_ISLEM,CBS_ZAMAN,CBS_LIMIT
     WHERE CBS_ISLEM.numara = pn_tran_no
       AND CBS_ISLEM.durum IN ('N')
       AND CBS_ISLEM.islem_kod      = rui.islem_tanim_kod
       AND CBS_ISLEM.modul_tur_kod  = rui.modul_tur_kod
       AND CBS_ISLEM.urun_tur_kod   = rui.urun_tur_kod
       AND CBS_ISLEM.urun_sinif_kod = rui.urun_sinif_kod
       AND rui.rol_numara       = 7777--pkg_baglam.rol_numara
       AND rui.zaman_numara     = CBS_ZAMAN.numara
           AND TO_NUMBER(TO_CHAR(SYSDATE,'HH24')) BETWEEN baslangic AND bitis
           AND rui.limit_numara = CBS_LIMIT.numara
       AND ( ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'S' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN alt AND ust)  OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'F' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'L' AND NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'F'
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'L'
                                               AND NVL(CBS_ISLEM.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.karsilik = 'N' )
             );

   BEGIN
     BEGIN
           OPEN c1;
           
           LOOP
              FETCH c1 INTO lc_verification, lc_approval, lc_modification_verification, lc_modification_approval, lc_cancel_approval;
              EXIT WHEN c1%NOTFOUND;
              UPDATE CBS_ISLEM
                SET durum = 'C' ,
                    dogrulanmali_mi = lc_verification,
                    onaylanmali_mi = lc_approval,
                    iptal_onaylanmali_mi = lc_cancel_approval,
                    dogrula_guncelle = lc_modification_verification,
                    onay_guncelle = lc_modification_approval
              WHERE numara = pn_tran_no;
            RETURN;
           END LOOP;
           
       CLOSE c1;
     EXCEPTION
          WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'62'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
     END;
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'61'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
   END;

/* *********************************************************************************** */
 FUNCTION GetErrorCode(pc_error_text IN VARCHAR2) RETURN VARCHAR2 IS
    ls_errorstr               VARCHAR2(1000);
    ln_errorstart            NUMBER;
    ln_errorend               NUMBER;
    ls_code                   VARCHAR2(10);
    ls_returncode           VARCHAR2(3);
 BEGIN
    ls_errorstr:=pc_error_text; --mutluo SQLERRM;
    ln_errorstart:=INSTR(ls_errorstr,'***');
    ln_errorend:=INSTR(ls_errorstr,'###');
    ls_code:=SUBSTR(ls_errorstr,ln_errorstart+3,ln_errorend-ln_errorstart-3);
    IF ls_code='1126' THEN
        ls_returncode:='502';
    ELSIF ls_code='441' THEN
        ls_returncode:='502'; -- bakiye yetersiz hatas?
    ELSIF ls_code='1156' THEN -- hesap bulunamad? hatas?
        ls_returncode:='202';
    ELSIF ls_code='1704' THEN -- hesap bulunamad? hatas?
        ls_returncode:='255';
    ELSIF ls_code='1165' THEN -- bloke var hatas?
        ls_returncode:='257';
    ELSIF ls_code='1103' THEN -- onay bekleyen i?lem hatas?
        ls_returncode:='258';
    ELSIF ls_code='1168' THEN -- teminat kay?tl? hatas?
        ls_returncode:='259';
    ELSIF ls_code='1262' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='260';
    ELSIF ls_code='555' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='724'; -- eod hatas?
    ELSIF ls_code='425' THEN -- bakiye bulunamad? hatas?
        ls_returncode:='673'; -- m??teri g?ncellem yap?lamaz.
    ELSIF TO_NUMBER(NVL(ls_code, 0)) BETWEEN 350 AND 400 THEN --chyngyzo cq5220 Dealer Payments 09.12.2015
        ls_returncode := TO_NUMBER(ls_code) + 450;
    ELSE
        ls_returncode:='999';
    END IF;
    RETURN ls_returncode;
 END;
/* *********************************************************************************** */
PROCEDURE draft_entry_control(pn_islem_no NUMBER) IS
   lc_dogrulama                VARCHAR2(1);
   lc_onay                     VARCHAR2(1);
   lc_iptal_onay            VARCHAR2(1);
   lc_dogrula_guncelle  VARCHAR2(1);
   lc_onay_guncelle     VARCHAR2(1);
   CURSOR c1 IS
    SELECT rui.dogrulama,rui.onay,rui.dogrula_guncelle,rui.onayla_guncelle,rui.iptal_onay
      FROM CBS_ROL_URUN_ISLEM rui,CBS_ISLEM_GECICI,CBS_ZAMAN,CBS_LIMIT
     WHERE CBS_ISLEM_GECICI.numara = pn_islem_no
       AND CBS_ISLEM_GECICI.durum IN ('G')
       AND CBS_ISLEM_GECICI.islem_kod      = rui.islem_tanim_kod
       AND CBS_ISLEM_GECICI.modul_tur_kod  = rui.modul_tur_kod
       AND CBS_ISLEM_GECICI.urun_tur_kod   = rui.urun_tur_kod
       AND CBS_ISLEM_GECICI.urun_sinif_kod = rui.urun_sinif_kod
       AND rui.rol_numara       = 7777--pkg_baglam.rol_numara
       AND rui.zaman_numara     = CBS_ZAMAN.numara
           AND TO_NUMBER(TO_CHAR(SYSDATE,'HH24')) BETWEEN baslangic AND bitis
           AND rui.limit_numara = CBS_LIMIT.numara
       AND ( ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'S' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN alt AND ust)  OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'F' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
             ( CBS_LIMIT.tum_dovizler ='H' AND CBS_LIMIT.karsilik = 'L' AND NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al) = CBS_LIMIT.doviz_kod
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,CBS_LIMIT.doviz_kod,NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'F'
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.fc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.tum_dovizler ='E' AND CBS_LIMIT.karsilik = 'L'
                                               AND NVL(CBS_ISLEM_GECICI.tutar,0) BETWEEN
                                                   Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,alt) AND
                                                     Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,NVL(CBS_ISLEM_GECICI.doviz_kod,Pkg_Genel.lc_al),NULL,ust) ) OR
               ( CBS_LIMIT.karsilik = 'N' )
             );

   BEGIN
        BEGIN
       OPEN c1;
       LOOP
          FETCH c1 INTO lc_dogrulama,lc_onay,lc_dogrula_guncelle,lc_onay_guncelle,lc_iptal_onay;
          EXIT WHEN c1%NOTFOUND;

          --Kilit_Test(pn_islem_no);

          UPDATE CBS_ISLEM_GECICI
            SET dogrulanmali_mi = lc_dogrulama,
                onaylanmali_mi  = lc_onay,
                iptal_onaylanmali_mi=lc_iptal_onay,
                dogrula_guncelle = lc_dogrula_guncelle,
                onay_guncelle = lc_onay_guncelle
          WHERE numara=pn_islem_no;

        RETURN;
       END LOOP;
       CLOSE c1;
     EXCEPTION
          WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'62'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
     END;
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'61'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
   END;
-----------------------------------------------------------------------------------------
PROCEDURE create_draft_transaction (pn_islem_numara              NUMBER
                            ,pn_islem_kod                 NUMBER
                            ,pc_modul_tur_kod             VARCHAR2
                            ,pc_urun_tur_kod              VARCHAR2
                            ,pc_urun_sinif_kod            VARCHAR2
                            ,pn_tutar                     NUMBER
                            ,pc_amir_bolum_kodu           VARCHAR2   DEFAULT NULL
                            ,pc_bolum_kodu                VARCHAR2   DEFAULT 'INT'
                            ,pc_rol                          VARCHAR2   DEFAULT 2
                            ,pc_doviz_kod                 VARCHAR2   DEFAULT NULL
                            ,pn_musteri_numara            NUMBER     DEFAULT NULL
                            ,pc_hesap_numara              VARCHAR2   DEFAULT NULL
                            ,pc_kasa_kod                  VARCHAR2   DEFAULT NULL
                            ,pn_KANAL_NUMARA              NUMBER DEFAULT 0
                            ) IS
   BEGIN

   Pkg_Int_Api.EODControl(NULL);--eod ise i?lemi yapma

     BEGIN
       INSERT INTO CBS_ISLEM_GECICI (NUMARA,ISLEM_KOD,DURUM,AMIR_BOLUM_KODU,
                              KAYIT_KULLANICI_KODU,KAYIT_KULLANICI_ROL_NUMARA,KAYIT_KULLANICI_BOLUM_KODU,
                              KAYIT_TARIH,KAYIT_SISTEM_TARIHI,
                              MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,
                              MUSTERI_NUMARA,HESAP_NUMARA,TUTAR,KASA_KOD,DOVIZ_KOD,KANAL_NUMARA)
                      VALUES (pn_islem_numara,pn_islem_kod,'G',pc_amir_bolum_kodu,
                              'CINT_CALLER',pc_rol,pc_bolum_kodu,
                              Pkg_Muhasebe.banka_tarihi_bul,SYSDATE,
                              pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
                              pn_musteri_numara,pc_hesap_numara,pn_tutar,pc_kasa_kod,pc_doviz_kod,pn_KANAL_NUMARA);

      EXCEPTION
           WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'60'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
      END;

     draft_entry_control(pn_islem_numara);

END;
-----------------------------------------------------------------------------------------
 PROCEDURE EODControl(dummy IN VARCHAR2) IS
  ls_returncode VARCHAR2(3):='000';
  is_EOD VARCHAR2(1):='H';
  is_SOD VARCHAR2(1):='H';
  is_EOD_ACC VARCHAR2(1):='H';

  -- sistemin eod veya sod olup olmad???n? belirler...
  -- e?er ??le ise hata verir

 BEGIN
    SELECT S.EOD, S.SOD, S.EOD_MUHASEBE
    INTO  is_EOD, is_SOD, is_EOD_ACC
    FROM CBS_SYSTEM S;
    --07.06.2012 Roman Shakirov SDLC00025624   Time deposit closing through IB   
    --WHERE ADI='CBS-PROD';

    IF ((is_EOD='E') OR (is_SOD='E') OR (is_EOD_ACC='E')) THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'555'|| Pkg_Hata.getDELIMITER ||SQLERRM||Pkg_Hata.getUCPOINTER);
    END IF;

 END;

END;
/

