create PACKAGE BODY     PKG_INT_CUSTOMER_INQ IS
 
FUNCTION GetCustomerNo(ps_customer_id varchar2) RETURN number
IS
ln_customer_no number;
BEGIN

     begin
        select distinct nvl(m.musteri_no,0) into ln_customer_no
                from cbs.cbs_musteri m 
                where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                    and m.musteri_tipi_kod in ('1') 
                    and m.durum_kodu = 'A'; 
     exception
         when no_data_found then 
             select distinct nvl(m.musteri_no,0) into ln_customer_no
                from cbs.cbs_musteri m 
                where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                    and m.musteri_tipi_kod in ('2') 
                    and m.durum_kodu = 'A';
     end;

     return ln_customer_no;

EXCEPTION
    when too_many_rows then 
        return null; 
    when no_data_found then 
        return null; 
    when others then
        log_at('GetCustomerNo', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);  
        raise;      
END;

FUNCTION GetCustomerNoForTheSecondType(ps_customer_id varchar2) RETURN number
IS
ln_customer_no number;
ln_count_retail_accounts number;
BEGIN

    select count(*) into ln_count_retail_accounts
                from cbs.cbs_musteri m 
                where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                    and m.musteri_tipi_kod in ('1') 
                    and m.durum_kodu = 'A';

    if ln_count_retail_accounts = 1 then
        --retail accountu varsa, donsun
        select distinct nvl(m.musteri_no,0) into ln_customer_no
                from cbs.cbs_musteri m 
                where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                    and m.musteri_tipi_kod in ('2') 
                    and m.durum_kodu = 'A';

             return ln_customer_no;
    else
        return null;  
    end if;   

EXCEPTION
    when too_many_rows then 
        return null; 
    when no_data_found then
        return null; 
    when others then
        log_at('GetCustomerNoForTheSecondType', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);  
        raise;      
END;


FUNCTION GetCustomerNumber(ps_customer_id varchar2, 
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number := 0;
ln_customer_type number; 
BEGIN


        begin
           begin
            select distinct nvl(m.musteri_no, 0), 1  into ln_customer_no, ln_customer_type
                    from cbs.cbs_musteri m 
                    where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                        and m.musteri_tipi_kod in ('1') 
                        and m.durum_kodu = 'A';

           exception
               when no_data_found then 
                  select distinct nvl(m.musteri_no, 0), 2  into ln_customer_no, ln_customer_type
                    from cbs.cbs_musteri m 
                    where upper(ps_customer_id) in (upper(replace(m.vergi_no,' ','')),upper(replace(m.pasaport_no,' ', '')),upper(replace(m.nufus_cuzdani_seri_no,' ',''))) 
                        and m.musteri_tipi_kod in ('2') 
                        and m.durum_kodu='A';
           end; 
        end;


      open pc_ref for 
        select ln_customer_no as customer_number, ln_customer_type as customer_type from dual;

        return '000';

EXCEPTION  
    when too_many_rows then 
         return '454';    
    when no_data_found then
         open pc_ref for select '' from dual;
         return '454'; 
    when others then 
         raise;              
END;  

FUNCTION GetCustomerNumberByIban(ps_iban varchar2) RETURN number 
IS
ln_customer_no number;
BEGIN
      select distinct musteri_no
         into ln_customer_no
             from cbs_hesap
                   where external_hesap_no = ps_iban
                         and durum_kodu = 'A';

      return ln_customer_no;

EXCEPTION 
    when too_many_rows then 
        return null;
    when no_data_found then 
        return null;
    when others then 
        raise; 
END;   

FUNCTION GetMaskedName(ps_name varchar2) RETURN varchar2
IS
cursor cur_mask is
   select substr(trim(regexp_substr(ps_name, '[^ ]+', 1, level)), 1, 1) 
            || '******' || 
       substr(trim(regexp_substr(ps_name, '[^ ]+', 1, level)), 
            length(trim(regexp_substr(ps_name, '[^ ]+', 1, level))), 1)  parser_name
       from dual
          connect by trim(regexp_substr(ps_name, '[^ ]+', 1, level)) is not null;

row_cur_mask cur_mask%rowtype;

ls_returncode varchar(500) := '';
BEGIN

    for row_cur_mask in cur_mask loop 
     ls_returncode := ls_returncode || ' ' || row_cur_mask.parser_name;
    end loop;

    return trim(ls_returncode);

EXCEPTION    
    when others then 
        raise;  
END;

FUNCTION GetCustomerMaskedName(ps_lang varchar2, 
                               ps_customer_number varchar2) RETURN varchar2
IS
ls_returncode varchar(500);
BEGIN
       select 
          case
            when ps_lang = 'en' then 
                 substr(decode(musteri_tipi_kod, 
                        '1', isim_eng || decode(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                        '2', isim_eng || decode(' ' || ikinci_isim_eng || ' ','  ',' ',' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                        lokal_unvan), 1, 200)
            when ps_lang = 'ru' then 
                 substr(decode(musteri_tipi_kod, 
                        '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                        '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                        ticari_unvan), 1, 200)
            else
                 substr(decode(musteri_tipi_kod, 
                        '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                        '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                        ticari_unvan), 1, 200)
          end into ls_returncode
            from cbs_musteri where musteri_no = to_number(ps_customer_number);

        ls_returncode := GetMaskedName(ls_returncode);

        return ls_returncode;

EXCEPTION    
    when no_data_found then
        return '454'; 
    when others then 
        raise;  
END;

FUNCTION GetCustomerName(ps_lang varchar2, ps_customer_number varchar2) RETURN varchar2
IS
ls_returncode varchar(500) := '000';
BEGIN

       select 
          case
            when ps_lang = 'en' then 
                 substr(decode(musteri_tipi_kod, 
                        '1', isim_eng || decode(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                        '2', isim_eng || decode(' ' || ikinci_isim_eng || ' ','  ',' ',' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                        lokal_unvan), 1, 200)
            when ps_lang = 'ru' then 
                 substr(decode(musteri_tipi_kod, 
                        '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                        '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                        ticari_unvan), 1, 200)
            else
                 substr(decode(musteri_tipi_kod, 
                        '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                        '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                        ticari_unvan), 1, 200)
          end into ls_returncode
            from cbs_musteri where musteri_no = to_number(ps_customer_number);

        return ls_returncode;

EXCEPTION    
    when no_data_found then
        return '454'; 
    when others then 
        raise;         
END;

FUNCTION GetCustomerIdByIban(ps_iban varchar2) RETURN varchar2
IS
ls_customer_id varchar(100);
BEGIN

   select 
        case
           when m.vergi_no is not null 
                             then replace(m.vergi_no,' ','')
             when m.pasaport_no is not null 
                             then replace(m.pasaport_no,' ','') 
             when m.nufus_cuzdani_seri_no is not null 
                             then replace( m.nufus_cuzdani_seri_no,' ','') 
         end as customer_id 
         into ls_customer_id
            from cbs.cbs_musteri m
                where m.musteri_no = GetCustomerNumberByIban(ps_iban)
                      and m.durum_kodu = 'A';

     return ls_customer_id;

EXCEPTION    
    when no_data_found then
          return null; 
    when others then 
         raise;                  
END;  

FUNCTION GetCustomerIdByIban(ps_iban varchar2, 
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar(3) := '000';
BEGIN

  open pc_ref for 
    select 
        case
             when m.vergi_no is not null 
                             then replace(m.vergi_no,' ','')
             when m.pasaport_no is not null 
                             then replace(m.pasaport_no,' ','') 
             when m.nufus_cuzdani_seri_no is not null 
                             then replace( m.nufus_cuzdani_seri_no,' ','') 
         end as customer_id 
            from cbs.cbs_musteri m
               where m.musteri_no = GetCustomerNumberByIban(ps_iban)
                      and m.durum_kodu = 'A';

     return ls_returncode;

EXCEPTION    
    when no_data_found then
         return null; 
    when others then 
         raise;                  
END;  

FUNCTION GetCustomerIdByCardId(ps_card_id varchar2) RETURN varchar2
IS
ln_customer_no number;
ls_customer_id varchar(500);
BEGIN

      select customer_no into ln_customer_no from
                   (select customer_no from cbs_debit_card where status = 'A' and card_id_no = ps_card_id
                     union
                    select customer_no from cbs_credit_card where status = 'A' and card_id_no = ps_card_id);


      select 
            case
                 when m.vergi_no is not null 
                                    then replace(m.vergi_no,' ','')
                 when m.pasaport_no is not null 
                                 then replace(m.pasaport_no,' ','') 
                 when m.nufus_cuzdani_seri_no is not null 
                                 then replace( m.nufus_cuzdani_seri_no,' ','') 
            end as customer_id 
        into ls_customer_id
                 from cbs_musteri m where durum_kodu = 'A' and musteri_no = ln_customer_no;

     return ls_customer_id;

EXCEPTION    
    when no_data_found then
         return '454'; 
    when others then 
         raise;                  
END; 

FUNCTION GetCustomerTypeByIban(ps_iban varchar2) RETURN varchar2
IS
ls_type varchar(1 byte);
BEGIN

  select musteri_tipi_kod into ls_type
            from cbs.cbs_musteri m
                where m.musteri_no = GetCustomerNumberByIban(ps_iban)
                      and m.durum_kodu = 'A';

     return ls_type;

EXCEPTION    
    when no_data_found then
         return null; 
    when others then 
         raise;                  
END; 

FUNCTION GetCustomerTypeByAccount(ps_account_number varchar2) RETURN varchar2
IS
ls_type varchar(1 byte);
BEGIN

  select musteri_tipi_kod into ls_type
            from cbs_vw_hesap_izleme
            where hesap_no = to_number(ps_account_number)
                and durum_kodu = 'A';

     return ls_type;

EXCEPTION    
    when no_data_found then
         return null; 
    when others then 
         raise;                  
END; 


FUNCTION GetStatusName(ps_lang varchar2,
                       ps_status_code varchar2) RETURN varchar2
IS
ls_status_name varchar2(30 byte) := null;
BEGIN

    select 
        aciklama 
          into ls_status_name
              from cbs_durum_kodlari 
                where durum_kodu = ps_status_code;

  return ls_status_name;

EXCEPTION
    when too_many_rows then 
        return null;
    when no_data_found then 
        return null;
    when others then 
        raise;        
END;

FUNCTION GetEducationName(ps_education_code varchar2) RETURN varchar2
IS
ls_egitim_adi varchar2(200) := null;
BEGIN

      select aciklama
            into ls_egitim_adi
                from cbs_egitim_kodlari
                where egitim_kodu = ps_education_code ;

      return ls_egitim_adi ;

EXCEPTION
    when too_many_rows then 
        return null;
    when no_data_found then 
        return null;
    when others then 
        raise;   
END;

FUNCTION GetCustAddrCountries(ps_lang varchar2,
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for 
    select cbs_ulke_kodlari.ulke_kodu as country_code, 
      case
         when ps_lang = 'en' 
                         then ulke_adi
         when ps_lang = 'ru' 
                         then country_in_russian
         else country_in_russian 
      end as country_name
          from cbs_ulke_kodlari 
           order by sira_no, ulke_kodu;

  return ls_returncode;

EXCEPTION
    when others then
        log_at('GetCustAddrCountries', sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;
FUNCTION GetCustAddrCities(ps_lang varchar2,
                           ps_country_code varchar2,
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for 
    select il_kodu as city_code, 
     case
         when ps_lang = 'en' 
                         then il_adi
         when ps_lang = 'ru' 
                         then aciklama2
         else aciklama2 
     end as city_name 
        from cbs_il_kodlari 
            where ulke_kodu = nvl(ps_country_code, ulke_kodu)
               order by sira_no, il_kodu;

  return ls_returncode;

EXCEPTION
    when others then
        log_at('GetCustAddrCities', ps_country_code, sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;
FUNCTION GetCustAddrTowns(ps_lang varchar2,
                          ps_city_code varchar2,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for 
     select il_kodu as town_code, 
     case
         when ps_lang = 'en' 
                         then ilce_adi
         when ps_lang = 'ru' 
                         then ilce_adi
         else ilce_adi 
     end as town_name 
        from cbs_ilce_kodlari 
        where il_kodu = nvl(ps_city_code, il_kodu)
        order by sira_no, il_kodu;

  return ls_returncode;

EXCEPTION
    when others then
        log_at('GetCustAddrTowns', ps_city_code, sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;
FUNCTION GetCustDemoEducations(ps_lang varchar2,
                               pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for 
     select egitim_kodu as education_code, 
     case
         when ps_lang = 'en' 
                         then aciklama
         when ps_lang = 'ru' 
                         then pkg_soa_common.text_translation(aciklama,'RUS')
         else pkg_soa_common.text_translation(aciklama,'RUS') 
     end as education_name 
        from cbs_egitim_kodlari 
        order by sira_no, egitim_kodu;

  return ls_returncode;

EXCEPTION
    when others then
        log_at('GetCustDemoEducations', ps_lang, sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;
FUNCTION GetCustProfessions(ps_lang varchar2,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for 
     select meslek_kodu as profession_code, 
     case
         when ps_lang = 'en' then 
              aciklama
         when ps_lang = 'ru' then 
              pkg_soa_common.text_translation(aciklama,'RUS')
         else pkg_soa_common.text_translation(aciklama,'RUS') 
     end as profession_name 
        from cbs_meslek_kodlari 
        order by sira_no, meslek_kodu;

  return ls_returncode;

EXCEPTION
    when no_data_found then
        log_at('GetCustProfessions', sqlerrm, dbms_utility.format_error_backtrace);
         return '454'; 
    when others then
        log_at('GetCustProfessions', sqlerrm, dbms_utility.format_error_backtrace);
        raise;  
END;
FUNCTION GetProfileAddresses(ps_lang varchar2,
                             ps_customer_id varchar2,
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_no := getcustomerno(ps_customer_id);

  if ln_customer_no is null then
    raise le_customer_not_found;
  end if;

  open pc_ref for 
    select ulke_kod as country_code, 
            il_kod as city_code, 
            pkg_genel.sehir_adi_al_hatasiz(il_kod) as city_name, 
            posta_kod as zip_code,
            adres_kod as address_type,
            pkg_musteri.sf_adres_tip_adi(adres_kod) as address_type_name,
            adres as full_address_info,
            isyeri_unvani as company_address_info
       from cbs_musteri_adres
       where musteri_no = ln_customer_no;

  return ls_returncode;

EXCEPTION
    when le_customer_not_found then
          return '454'; 
    when others then
        log_at('GetProfileAddresses', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetProfileEmails(ps_lang varchar2,
                          ps_customer_id varchar2,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_no := GetCustomerNo(ps_customer_id);

  if ln_customer_no is null then
    raise le_customer_not_found;
  end if;

  open pc_ref for 
       select distinct email as email_address
              --pkg_musteri.sf_adres_tip_adi(adres_kod) as address_type 
           from cbs_musteri_adres
           where musteri_no = ln_customer_no;

  return ls_returncode;

EXCEPTION
    when le_customer_not_found then
          return '454';
    when others then
          log_at('GetprofileEmails', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetProfilePhones(ps_lang varchar2,
                          ps_customer_id varchar2,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_no := getcustomerno(ps_customer_id);

  if ln_customer_no is null then
    raise le_customer_not_found;
  end if;

  open pc_ref for 
     select rownum as sorting, 
          c.* from (
             select distinct c.* from (
                   select 'mobile' as phone_type,
                        nvl(a.ulke_gsm_kod, '996') as country_code,  
                        a.gsm_alan_kod as prefix, 
                        a.gsm_no as phone_number
                     from cbs_musteri_adres a 
                          where a.musteri_no = nvl(ln_customer_no, a.musteri_no)
                          and a.gsm_alan_kod is not null
                          and a.gsm_no is not null
                    union
                    select 'mobile' as phone_type,
                            nvl(a.ulke_gsm_kod_2, '996') as country_code,  
                            a.gsm_alan_kod_2 as prefix, 
                            a.gsm_no_2 as phone_number
                         from cbs_musteri_adres a 
                              where a.musteri_no = nvl(ln_customer_no, a.musteri_no) 
                              and a.gsm_alan_kod_2 is not null
                              and a.gsm_no_2 is not null    
                    union
                    select 'mobile' as phone_type,
                            nvl(a.ulke_gsm_kod_3, '996') as country_code,  
                            a.gsm_alan_kod_3 as prefix, 
                            a.gsm_no_3 as phone_number
                         from  cbs_musteri_adres a 
                              where a.musteri_no = ln_customer_no
                              and a.gsm_alan_kod_3 is not null
                              and a.gsm_no_3 is not null    
                    union
                    select 'home' as phone_type,
                            nvl(a.ulke_tel_kod, '312') as country_code,  
                            a.tel_alan_kod as prefix, 
                            a.tel_no as phone_number
                         from  cbs_musteri_adres a 
                              where a.musteri_no = ln_customer_no
                              and a.tel_alan_kod is not null
                              and a.tel_no is not null    
                    union
                    select 'home' as phone_type,
                            nvl(a.ulke_tel_kod_2, '312') as country_code,  
                            a.tel_alan_kod_2 as prefix, 
                            a.tel_no_2 as phone_number
                         from  cbs_musteri_adres a 
                              where a.musteri_no = ln_customer_no
                              and a.tel_alan_kod_2 is not null
                              and a.tel_no_2 is not null    
                    union
                    select 'home' as phone_type,
                            nvl(a.ulke_tel_kod_3, '312') as country_code,  
                            a.tel_alan_kod_3 as prefix, 
                            a.tel_no_3 as phone_number
                         from  cbs_musteri_adres a 
                              where a.musteri_no = ln_customer_no
                              and a.tel_alan_kod_3 is not null
                              and a.tel_no_3 is not null)c ) c order by sorting;

  return ls_returncode;

EXCEPTION
    when le_customer_not_found then
          return '454';
    when others then
          log_at('GetProfilePhones', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetProfileWorks(ps_lang varchar2,
                         ps_customer_id varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_no := GetCustomerNo(ps_customer_id); 

   if ln_customer_no is null then
    raise le_customer_not_found;
   end if;

  open pc_ref for  
   select
     meslek_kod as title_code,
     case
         when ps_lang = 'en' 
                         then pkg_musteri.sf_meslek_adi(meslek_kod)
         when ps_lang = 'ru' 
                         then pkg_soa_common.text_translation(pkg_musteri.sf_meslek_adi(meslek_kod),'RUS')
         else pkg_soa_common.text_translation(pkg_musteri.sf_meslek_adi(meslek_kod),'RUS') 
     end as title_name,
     company_of_the_staff as sector_code,
     case
         when company_of_the_staff is not null 
                         then pkg_musteri.sf_musteri_adi(company_of_the_staff)
         else ''
     end as sector_name
       from cbs_musteri where
            musteri_no = ln_customer_no;

  return ls_returncode;

EXCEPTION
    when le_customer_not_found then
          return '454';
    when others then
          log_at('GetProfileWorks', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetProfileFull(ps_lang varchar2,
                        ps_customer_id varchar2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

 ln_customer_no := getcustomerno(ps_customer_id); 

  if ln_customer_no is null then
    raise le_customer_not_found;
  end if;

  open pc_ref for  
    select a.musteri_no as customer_number, 
    a.musteri_no as customer_no, 
        yerlesim_kod as resident_type, 
        pasaport_no as passport,
          case
             when ps_lang = 'en' 
               then isim_eng
             else isim
          end as first_name,
          case
             when ps_lang = 'en' 
               then ikinci_isim_eng
             else ikinci_isim
          end as middle_name,
          case
             when ps_lang = 'en' 
               then soyadi_eng
             else soyadi
          end as surname,
          isim_eng as first_name_latin,
          ikinci_isim_eng as middle_name_latin,
          soyadi_eng as surname_latin,
          isim as first_name_cyrillic,
          ikinci_isim as middle_name_cyrillic,
          soyadi as surname_cyrillic,
          case
             when personel_sicil_no is not null
               then 'true'
             else 'false'
          end as bank_personel,
           case
             when is_pension = 'E'
               then 'true'
             else 'false'
          end as retired_customer,
          baba_adi as father_name,
          anne_adi as mother_name,
          egitim_kod as education_code,
          pkg_int_customer_inq.geteducationname(egitim_kod) as education_status,
          durum_kodu as customer_code,
          pkg_int_customer_inq.getstatusname('en',durum_kodu) as customer_status,
          musteri_tipi_kod as customer_type,
          pkg_musteri.sf_musteri_tipi_adi(musteri_tipi_kod) as customer_type_name,
          verildigi_yer as identity_series,
          nufus_cuzdani_seri_no as identity_serial_no,
          pkg_musteri.sf_kimlik_adi(kimlik_kod) as identity_type, 
          vergi_no as tax_number,
          vergi_daire_kodu as tax_office_code,
          vergi_dairesi_adi as tax_office_name,
          dogum_tarihi as birth_date,
          dogum_yeri as birth_place,
          cinsiyet_kod as gender_code,
          pkg_musteri.sf_cinsiyet_adi(cinsiyet_kod) as gender_name,
          medeni_hal_kod as marital_status_code,
          case
             when ps_lang = 'en' and medeni_hal_kod is not null then 
               pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod)
             when medeni_hal_kod is not null then 
               pkg_soa_common.text_translation(pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod),'RUS')
             else null
          end as marital_status_name,
          case
             when ehliyet_belge_no is not null
               then 'true'
             else 'false'
          end as has_driving_licence,  
          ehliyet_belge_no as driving_licence_no,
          nvl((select lang from cbs_customer_notif_settings where customer_no = a.musteri_no),'KY') as preffered_lang
     from cbs_musteri a
       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
          where a.musteri_no = ln_customer_no;

  return ls_returncode;

EXCEPTION
    when le_customer_not_found then
          return '454'; 
    when others then
          log_at('GetProfileWorks', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetProfileFullByCustomerNumber(ps_lang varchar2,
                                        ps_customer_number varchar2,
                                        pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_no number;
ls_returncode varchar2(3) := '000';
BEGIN

   ln_customer_no := TO_NUMBER (ps_customer_number); 

  open pc_ref for  
    select a.musteri_no as customer_number, 
    a.musteri_no as customer_no, 
        yerlesim_kod as resident_type, 
        pasaport_no as passport,
          case
             when ps_lang = 'en' 
               then isim_eng
             else isim
          end as first_name,
          case
             when ps_lang = 'en' 
               then ikinci_isim_eng
             else ikinci_isim
          end as middle_name,
          case
             when ps_lang = 'en' 
               then soyadi_eng
             else soyadi
          end as surname,
          isim_eng as first_name_latin,
          ikinci_isim_eng as middle_name_latin,
          soyadi_eng as surname_latin,
          isim as first_name_cyrillic,
          ikinci_isim as middle_name_cyrillic,
          soyadi as surname_cyrillic,
          case
             when personel_sicil_no is not null
               then 'true'
             else 'false'
          end as bank_personel,
           case
             when is_pension = 'E'
               then 'true'
             else 'false'
          end as retired_customer,
          baba_adi as father_name,
          anne_adi as mother_name,
          egitim_kod as education_code,
          pkg_int_customer_inq.geteducationname(egitim_kod) as education_status,
          durum_kodu as customer_code,
          pkg_int_customer_inq.getstatusname('en',durum_kodu) as customer_status,
          musteri_tipi_kod as customer_type,
          pkg_musteri.sf_musteri_tipi_adi(musteri_tipi_kod) as customer_type_name,
          verildigi_yer as identity_series,
          nufus_cuzdani_seri_no as identity_serial_no,
          pkg_musteri.sf_kimlik_adi(kimlik_kod) as identity_type, 
          vergi_no as tax_number,
          vergi_daire_kodu as tax_office_code,
          vergi_dairesi_adi as tax_office_name,
          dogum_tarihi as birth_date,
          dogum_yeri as birth_place,
          cinsiyet_kod as gender_code,
          pkg_musteri.sf_cinsiyet_adi(cinsiyet_kod) as gender_name,
          medeni_hal_kod as marital_status_code,
          case
             when ps_lang = 'en' and medeni_hal_kod is not null then 
               pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod)
             when medeni_hal_kod is not null then 
               pkg_soa_common.text_translation(pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod),'RUS')
             else null
          end as marital_status_name,
          case
             when ehliyet_belge_no is not null
               then 'true'
             else 'false'
          end as has_driving_licence,  
          ehliyet_belge_no as driving_licence_no,
          nvl((select lang from cbs_customer_notif_settings where customer_no = a.musteri_no),'KY') as preffered_lang
     from cbs_musteri a
       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
          where a.musteri_no = ln_customer_no and a.durum_kodu = 'A';

  return ls_returncode;

EXCEPTION 
    when others then
          log_at('GetProfileFullByCustomerNumber', ps_customer_number, sqlerrm, dbms_utility.format_error_backtrace);
          raise;   
END;
FUNCTION GetProfileFullByPhone(ps_lang varchar2,
                               ps_phone_number varchar2,
                               pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_count_customer number := 0;
cursor cur_address is
   select distinct musteri_no
        from cbs_musteri_adres 
          where ((nvl(ulke_gsm_kod, '996') || gsm_alan_kod  || gsm_no) = ps_phone_number
                 or (nvl(ulke_gsm_kod_2, '996') || gsm_alan_kod_2  || gsm_no_2) = ps_phone_number
                 or (nvl(ulke_gsm_kod_3, '996') || gsm_alan_kod_3  || gsm_no_3) = ps_phone_number);
                 
ln_customer_list CustomerList := CustomerList();
   
row_cur_address cur_address%rowtype;

ls_returncode varchar2(3) := '000';
BEGIN

   for row_cur_address in cur_address loop 
        ln_customer_list.extend;
        ln_count_customer := ln_count_customer + 1;
        ln_customer_list(ln_count_customer) := row_cur_address.musteri_no; 
    
   end loop;
         
   if ln_count_customer >= 3 then
          return '456';
   elsif ln_count_customer =0 then
       return '457';
   elsif ln_count_customer >1 and  GetCustomerIdByCustomer(ln_customer_list(1)) <> GetCustomerIdByCustomer(ln_customer_list(2)) then
       return '456';
   end if;

   open pc_ref for  
    select a.musteri_no as customer_number, 
        a.musteri_no as customer_no, 
        yerlesim_kod as resident_type, 
        pasaport_no as passport,
          case
             when ps_lang = 'en' 
               then isim_eng
             else isim
          end as first_name,
          case
             when ps_lang = 'en' 
               then ikinci_isim_eng
             else ikinci_isim
          end as middle_name,
          case
             when ps_lang = 'en' 
               then soyadi_eng
             else soyadi
          end as surname,
          isim_eng as first_name_latin,
          ikinci_isim_eng as middle_name_latin,
          soyadi_eng as surname_latin,
          isim as first_name_cyrillic,
          ikinci_isim as middle_name_cyrillic,
          soyadi as surname_cyrillic,
          case
             when personel_sicil_no is not null
               then 'true'
             else 'false'
          end as bank_personel,
           case
             when is_pension = 'E'
               then 'true'
             else 'false'
          end as retired_customer,
          baba_adi as father_name,
          anne_adi as mother_name,
          egitim_kod as education_code,
          pkg_int_customer_inq.geteducationname(egitim_kod) as education_status,
          durum_kodu as customer_code,
          pkg_int_customer_inq.getstatusname('en',durum_kodu) as customer_status,
          musteri_tipi_kod as customer_type,
          pkg_musteri.sf_musteri_tipi_adi(musteri_tipi_kod) as customer_type_name,
          verildigi_yer as identity_series,
          nufus_cuzdani_seri_no as identity_serial_no,
          pkg_musteri.sf_kimlik_adi(kimlik_kod) as identity_type, 
          vergi_no as tax_number,
          vergi_daire_kodu as tax_office_code,
          vergi_dairesi_adi as tax_office_name,
          dogum_tarihi as birth_date,
          dogum_yeri as birth_place,
          cinsiyet_kod as gender_code,
          pkg_musteri.sf_cinsiyet_adi(cinsiyet_kod) as gender_name,
          medeni_hal_kod as marital_status_code,
          case
             when ps_lang = 'en' and medeni_hal_kod is not null then 
               pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod)
             when medeni_hal_kod is not null then 
               pkg_soa_common.text_translation(pkg_musteri.sf_medeni_hal_adi(medeni_hal_kod),'RUS')
             else null
          end as marital_status_name,
          case
             when ehliyet_belge_no is not null
               then 'true'
             else 'false'
          end as has_driving_licence,  
          ehliyet_belge_no as driving_licence_no,
          nvl((select lang from cbs_customer_notif_settings where customer_no = a.musteri_no),'KY') as preffered_lang
     from cbs_musteri a
       left join cbs_musteri_source b on a.musteri_no = b.musteri_no
       left join cbs_musteri_adres c on a.musteri_no = c.musteri_no
          where a.musteri_no=ln_customer_list(1) ;

       return ls_returncode;

EXCEPTION
    when others then
          log_at('GetProfileFullByPhone', ps_phone_number, sqlerrm, dbms_utility.format_error_backtrace);
          raise;
END;
FUNCTION GetSpecialDates(ps_lang varchar2,
                         ps_date varchar2 default null,
                         pn_page_index number default 1,
                         pn_page_size number default 10,
                         pc_ref OUT CursorReferenceType) RETURN varchar2
IS                                  
ld_date date;
ls_returncode varchar2(3) := '000';
BEGIN

  ld_date := to_date(substr(ps_date, 1, 10), 'YYYY-MM-DD');

  open pc_ref for  
      select 
      case 
         when musteri_tipi_kod in('1', '2') then 
            isim ||
             case
               when ikinci_isim is null then ' '
               else 
                ' ' || ikinci_isim || ' ' || soyadi 
             end
         else 
             ticari_unvan 
      end full_name, 
      a.email as email,
      nvl(a.ulke_gsm_kod, '996') || a.gsm_alan_kod  || a.gsm_no as mobile_phone_number,
      nvl(a.ulke_gsm_kod_2, '996') || a.gsm_alan_kod_2  || a.gsm_no_2 as mobile_phone_number_2,
      nvl(a.ulke_gsm_kod_3, '996') || a.gsm_alan_kod_3  || a.gsm_no_3 as mobile_phone_number_3
      from cbs_musteri m, cbs_musteri_adres a 
          where m.musteri_no=a.musteri_no 
                and extract(day from m.dogum_tarihi) = extract(day from ld_date) 
                and extract(month from m.dogum_tarihi) = extract(month from ld_date);

  return ls_returncode;

EXCEPTION
    when others then
          log_at('GetSpecialDates', ps_date, sqlerrm, dbms_utility.format_error_backtrace);
          raise; 
END;
FUNCTION GetCustResidentStatus(ps_customer_id varchar2) RETURN varchar2
IS
ln_resident_status varchar2(1);
BEGIN
    select yerlesim_kod into ln_resident_status from CBS.CBS_MUSTERI where vergi_no=ps_customer_id;

    return ln_resident_status;

EXCEPTION
    when no_data_found then
          return '454'; 
    when others then
          log_at('GetCustResidentStatus', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;    
END;
FUNCTION MakeCustDataModifAttempt(ps_customer_id varchar2, 
                                  ps_description varchar2) RETURN varchar2
IS
ln_tx_no number;
ln_customer_no number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN
    ln_customer_no := GetCustomerNo(ps_customer_id);

    if ln_customer_no is null then
        raise le_customer_not_found;
    end if;

    ln_tx_no := pkg_tx.islem_no_al;

    insert into cbs.tbl_cust_data_modif_attempt(tx_no, vergi_no, kayit_sistem_tarihi, kisa_aciklama)
        values (ln_tx_no, ps_customer_id, sysdate, ps_description);

    return ls_returncode;         
EXCEPTION
    when le_customer_not_found then
          return '454'; 
    when no_data_found then
          return '454'; 
    when others then
          log_at('MakeCustDataModifAttempt', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;
FUNCTION GetCustDataModifAttempt(ps_customer_id varchar2) RETURN varchar2
IS
ln_count number;
ls_returncode varchar2(3) := '000';
BEGIN
    select count(*) into ln_count
        from cbs.tbl_cust_data_modif_attempt
            where vergi_no = ps_customer_id and kayit_sistem_tarihi >= add_months(sysdate, -1);

    if ln_count > 4 then
        ls_returncode := '456';
    end if; 

    select count(*) into ln_count
        from cbs.tbl_cust_data_modif_attempt
            where vergi_no=ps_customer_id and kayit_sistem_tarihi >= sysdate-1;

    if ln_count > 2 then
        ls_returncode := '457';
    end if;  

    return ls_returncode; 

EXCEPTION
    when no_data_found then
          return '454'; 
    when others then
          log_at('GetCustDataModifAttempt', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;     
END;
FUNCTION GetCustFullAddress(ps_customer_id varchar2) RETURN varchar2
IS
ln_full_address   varchar2(150);
ln_customer_no  number;
le_customer_not_found exception;
BEGIN
    ln_customer_no := GetCustomerNo(ps_customer_id);

    if ln_customer_no is null then
        raise le_customer_not_found;
    end if;

    select adres into ln_full_address from cbs_musteri_adres where musteri_no = ln_customer_no;

    return ln_full_address;  

EXCEPTION
    when le_customer_not_found then
          return '454'; 
    when no_data_found then
          return '454'; 
    when others then
          log_at('GetCustFullAddress', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;  
END;

FUNCTION CheckForPassportExpiredDate(ps_customer_id varchar2) RETURN number
IS
ln_return number := 1;
ls_passport_no varchar2(20);
ls_local_passport_no  varchar2(20);
ln_customer_no number;
ls_passport_expire date;
ld_birth_date date;
BEGIN
	
	ln_customer_no := getcustomerno(ps_customer_id);

	select gecerlilik_tarihi, upper(replace(pasaport_no,' ', '')), nufus_cuzdani_seri_no, dogum_tarihi into ls_passport_expire, ls_passport_no, ls_local_passport_no, ld_birth_date
	from cbs_musteri where musteri_no = ln_customer_no;
 
    if ld_birth_date is not null and (substr(ls_passport_no,1,3) = 'KGZ' or substr(ls_passport_no,1,4) = 'KP-X') then 
        ls_passport_expire := add_months(ld_birth_date, 16 * 12);
    end if;
    
    if ls_passport_expire is null or (ls_passport_no is null and ls_local_passport_no is null) then
        return 451;
    end if;
    
    if ls_passport_expire < sysdate then
        return 0;
    end if;
   
    return ln_return;

EXCEPTION
    when no_data_found then
          return 454;
    when others then
          log_at('CheckForPassportExpiredDate', ps_customer_id, sqlerrm, dbms_utility.format_error_backtrace);
          raise;   
END; 


FUNCTION CheckCustBranchIsNotActive(ps_branch_code varchar2) RETURN boolean 
IS
ld_date date;
BEGIN


      select kapanis_tarihi into ld_date from cbs_bolum where kodu = ps_branch_code;

      if ld_date is not null then
        return true;
      end if;

      return false;

EXCEPTION 
    when no_data_found then 
        return false;
    when others then 
        raise; 
END;

FUNCTION GetNotificationSettings(ps_customer_id in varchar2,
                              pc_ref OUT CursorReferenceType, 
                              pc_ref2 OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
ln_customer_no number;
BEGIN
	ln_customer_no := getcustomerno(ps_customer_id);

    open pc_ref for
          select m.notif_pack from  cbs_musteri m  where  musteri_no = ln_customer_no;

    open pc_ref2 for
         select enabled from cbs_customer_pushnotif_settings where customer_no = ln_customer_no;

    return ls_returncode ;

EXCEPTION
    when others then
       log_at('GetCustNotifPackInfo', ln_customer_no, sqlerrm, dbms_utility.format_error_backtrace);
       open pc_ref for select sysdate from dual;
       raise;
END;


FUNCTION GetExpiredDatePassport(ps_customer_id IN varchar2,
								pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
ln_customer_no number;
BEGIN

	ln_customer_no := getcustomerno(ps_customer_id);

	open pc_ref for
	   select gecerlilik_tarihi as expired_date, pasaport_no, dogum_tarihi as birth_date from cbs_musteri where musteri_no = ln_customer_no;

    return ls_returncode;

EXCEPTION
	when others then
	log_at('GetExpiredDatePassport', ln_customer_no, sqlerrm, dbms_utility.format_error_backtrace);
	raise;
END;								

FUNCTION GetCustomerIdByCustomer(ps_customer_number varchar2) RETURN varchar2
IS
ls_customer_id varchar(100);
BEGIN

       select  
         case
             when vergi_no is not null 
                             then replace(vergi_no,' ','')
             when pasaport_no is not null 
                             then replace(pasaport_no,' ','') 
             when nufus_cuzdani_seri_no is not null 
                             then replace(nufus_cuzdani_seri_no,' ','') 
         end 
        into ls_customer_id
        from cbs.cbs_musteri
           where musteri_no = to_number(ps_customer_number)
                 and durum_kodu = 'A';

     return ls_customer_id;

EXCEPTION    
    when no_data_found then
         return null; 
    when others then 
         raise;                  
END; 

END;
/

