create PACKAGE BODY     Pkg_Masraf_Tx22060  IS

p_22060_FC_MSRF_DOVIZ_KODU        NUMBER;
p_22060_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_22060_KUR						  NUMBER;
p_22060_REFERENCE				  NUMBER;
p_22060_ISTA_KOD				  NUMBER;
p_22060_MUS_ACIK				  NUMBER;
p_22060_BANKA_ACIK				  NUMBER;
p_22060_ISLEM_SUBE				  NUMBER;
p_22060_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_22060_FC_MASRAF_TUTARI		  NUMBER;
p_22060_LC_MASRAF_TUTAR			  NUMBER;
p_22060_MASRAF_HESAP_SUBE		  NUMBER;
p_22060_MASRAF_HESAP_NO			  NUMBER;
p_22060_LC_MAIL_CHARGE			  NUMBER;
p_22060_LC_COMM_CHARGE			  NUMBER;
p_22060_LC_COLL_COM				  NUMBER;
p_22060_LC_FREE_COM			  	  NUMBER;
p_22060_MAIL_CHARGE_GL			  NUMBER;
p_22060_COMM_CHARGE_GL			  NUMBER;
p_22060_COLL_COM_GL				  NUMBER;
p_22060_FREE_COM_GL			  	  NUMBER;
p_22060_FC						  NUMBER;
p_22060_LC						  NUMBER;
p_22060_MAILCOM_VAR				  NUMBER;
p_22060_COMMCOM_VAR				  NUMBER;
p_22060_COLLCOM_VAR				  NUMBER;
p_22060_FREECOM_VAR			      NUMBER;
p_22060_FC_MASRAF_ANA			  NUMBER;
p_22060_LC_MASRAF_ANA			  NUMBER;

p_22060_VERGIDEN_MUAF_DEGIL		  NUMBER;
p_22060_LC_SERVICE_TAX		      NUMBER;
p_22060_FC_SERVICE_TAX		      NUMBER;
/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', null);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   Pkg_Masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS		-- Islem iptal edilemez
  BEGIN
   Pkg_Masraf.Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no, ps_ref, 0);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER) IS
   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_fc		      NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ln_top_bsmv 			  NUMBER := 0;
   ln_bsmv				  NUMBER := 0;
   ls_istatistik_kodu     VARCHAR2(2000);
   ls_aciklama			  VARCHAR2(2000);
   ln_dk_grup_no		  NUMBER;

   CURSOR cur_masraf IS
    SELECT *
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID'
	 ORDER BY sira_no
	FOR UPDATE;
	row_masraf cur_masraf%ROWTYPE;

    CURSOR c_0 IS
    SELECT COUNT(*)
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID';
	 ln_temp NUMBER;

   CURSOR cur_akr IS
     SELECT * FROM CBS_ITH_DOSYA_ISLEM
	  WHERE tx_no = pn_islem_no;
	 row_akr cur_akr%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT_ISLEM a
	  WHERE islem_no = pn_islem_no --referans = ls_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
	 FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;
   ls_acik_tutar_ref VARCHAR2(100);
	ln_ser_tax number:=0;
  BEGIN
    ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	boolean_list(p_22060_MAILCOM_VAR) := FALSE ;
	boolean_list(p_22060_COMMCOM_VAR) := FALSE ;
	boolean_list(p_22060_COLLCOM_VAR) := FALSE ;
	boolean_list(p_22060_FREECOM_VAR) := FALSE ;
	boolean_list(p_22060_FC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22060_LC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := FALSE ;

	varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) := 'AAA';
	OPEN cur_akr;
	FETCH cur_akr INTO row_akr;
	 ls_akr_doviz := row_akr.doviz_kodu;
	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
    	 varchar_list(p_22060_MASRAF_HESAP_NO) := row_akr.masraf_hesap_no;

		 if pkg_musteri.musteri_vergiden_muafmi(row_akr.ITHALATCI_MUSTERI_NO) = 'E'
		 then
			boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := FALSE ;
		 else
			boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := TRUE ;
		 end if;
	     varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
	     varchar_list(p_22060_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_akr.masraf_hesap_no);
	 else
	 	 varchar_list(p_22060_MASRAF_HESAP_NO) := '';
	 END IF;

	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
	     ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(row_akr.ITHALATCI_MUSTERI_NO) ;
		 varchar_list(p_22060_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPMAILCHR');
		 varchar_list(p_22060_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOMCAT');
		 varchar_list(p_22060_COLL_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOLLCOM');
		 varchar_list(p_22060_FREE_COM_GL)    :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPFREECOM');
	 ELSE
		 varchar_list(p_22060_MAIL_CHARGE_GL) := '';
		 varchar_list(p_22060_COMM_CHARGE_GL) := '';
		 varchar_list(p_22060_COLL_COM_GL)	  := '';
		 varchar_list(p_22060_FREE_COM_GL)    := '';
	 END IF;

	 varchar_list(p_22060_ISLEM_SUBE) := row_akr.bolum_kodu;
	 ls_referans := row_akr.referans;

	 varchar_list(p_22060_REFERENCE) := ls_referans;

	CLOSE cur_akr;

	if boolean_list(p_22060_VERGIDEN_MUAF_DEGIL)
	then
		ls_acik_tutar_ref := RTRIM(TO_CHAR(row_akr.DOSYA_BAKIYESI,'999G999G999G999G999G999G999D99')) || ls_akr_doviz || '-' || ls_referans;

	    IF varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_22060_LC_MSRF_DOVIZ_KODU) := FALSE;
		 boolean_list(p_22060_FC_MSRF_DOVIZ_KODU) := TRUE ;
		ELSE
		 boolean_list(p_22060_LC_MSRF_DOVIZ_KODU) := TRUE;
		 boolean_list(p_22060_FC_MSRF_DOVIZ_KODU) := FALSE;
		END IF;

		number_list(p_22060_LC_COMM_CHARGE) := 0;
		number_list(p_22060_LC_MAIL_CHARGE) := 0;
		number_list(p_22060_LC_COLL_COM) := 0;
		number_list(p_22060_LC_FREE_COM) := 0;
		number_list(p_22060_LC_MASRAF_TUTAR) := 0;
		number_list(p_22060_FC_MASRAF_TUTARI) := 0;
		number_list(p_22060_LC_SERVICE_TAX) := 0;
		number_list(p_22060_FC_SERVICE_TAX) := 0;

		ls_aciklama := ls_referans || ' -  ' || row_akr.ithalatci_musteri_no || ' -  ' ||
					   Pkg_Musteri.sf_musteri_adi(row_akr.ithalatci_musteri_no) || ' -  ' ||
					   ' Import File Opening ' ;
		varchar_list(p_22060_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_22060_MUS_ACIK) :=varchar_list(p_22060_BANKA_ACIK) ;

	    IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
		  boolean_list(p_22060_LC) := TRUE;
	      boolean_list(p_22060_FC) := FALSE;
		ELSE
		  boolean_list(p_22060_LC) := FALSE;
	      boolean_list(p_22060_FC) := TRUE;
		END IF;

		IF row_akr.masraf_hesap_no IS NOT NULL THEN  --masraf hesabi girilmisse
	   	   number_list(p_22060_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),1);
			ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_22060_MASRAF_HESAP_NO));
	    END IF;


		OPEN cur_masraf;
		LOOP
		  FETCH cur_masraf INTO row_masraf;
		  EXIT WHEN cur_masraf%NOTFOUND;
		  ln_bsmv := 0;
		  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
			  IF Pkg_Ithalat.masraf_kontrol_yap_nonakr(row_masraf.ODEYECEK) = 'Y'
			  THEN
			      ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
				  IF row_masraf.masraf_kodu = 'IMPCOMCAT'  THEN   --haberlesme
				    boolean_list(p_22060_COMMCOM_VAR) := TRUE ;
					number_list(p_22060_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

					ln_borc_trl := number_list(p_22060_LC_COMM_CHARGE);
					ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
					number_list(p_22060_LC_SERVICE_TAX):=number_list(p_22060_LC_SERVICE_TAX)+ln_borc_trl;
				  ELSIF row_masraf.masraf_kodu = 'IMPMAILCHR' THEN   --posta
				  	boolean_list(p_22060_MAILCOM_VAR) := TRUE ;
				   number_list(p_22060_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

					ln_borc_trl := number_list(p_22060_LC_MAIL_CHARGE);
					ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
					number_list(p_22060_LC_SERVICE_TAX):=number_list(p_22060_LC_SERVICE_TAX)+ln_borc_trl;
				  ELSIF row_masraf.masraf_kodu = 'IMPCOLLCOM' THEN
				    boolean_list(p_22060_COLLCOM_VAR) := TRUE ;
				   number_list(p_22060_LC_COLL_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

					ln_borc_trl := number_list(p_22060_LC_COLL_COM);
					ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
				  ELSIF row_masraf.masraf_kodu =  'IMPFREECOM' THEN  --
				    boolean_list(p_22060_FREECOM_VAR) := TRUE ;
				   number_list(p_22060_LC_FREE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

					ln_borc_trl := number_list(p_22060_LC_FREE_COM);
					ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
				  ELSE
				    CLOSE cur_masraf;
			 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
				  END IF;

				  IF NOT lb_taksit_var THEN
				   IF ln_son_bakiye >= ln_borc_fc  THEN --bakiye yeterliyse satiri ekle
				     IF ln_tahsil_tutar <> 0 THEN
				         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22060, NULL, pn_islem_no, varchar_list,
							    				  	  number_list, date_list, boolean_list,
										    	  	  NULL, FALSE, ln_fis_no, NULL);

						  IF boolean_list(p_22060_MAILCOM_VAR) = TRUE THEN
						  	 boolean_list(p_22060_MAILCOM_VAR) := FALSE;
						  ELSIF boolean_list(p_22060_COMMCOM_VAR) = TRUE THEN
						  	 boolean_list(p_22060_COMMCOM_VAR) := FALSE;
						  ELSIF boolean_list(p_22060_COLLCOM_VAR) = TRUE THEN
						  	 boolean_list(p_22060_COLLCOM_VAR) := FALSE;
						  ELSIF boolean_list(p_22060_FREECOM_VAR) = TRUE THEN
						  	 boolean_list(p_22060_FREECOM_VAR) := FALSE;
						  END IF;

						  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
	                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

					      UPDATE CBS_MASRAF_ITH_IHR_ISL
						     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
							     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
					       WHERE CURRENT OF cur_masraf;

						  ln_son_bakiye := ln_son_bakiye - ln_borc_fc ;
						  number_list(p_22060_LC_MASRAF_TUTAR) := number_list(p_22060_LC_MASRAF_TUTAR) + ln_borc_trl;
						  number_list(p_22060_FC_MASRAF_TUTARI) := number_list(p_22060_FC_MASRAF_TUTARI) + ln_borc_fc;
					END IF;
				   ELSE
				       CLOSE cur_masraf;
					  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
					    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_fc, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_22060_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
				   END IF;
				  END IF;
	 	      END IF; --ihracat?? ?demesi
		  END IF;  --tahsil edilmeyen var....

		END LOOP;
		CLOSE cur_masraf;

		boolean_list(p_22060_MAILCOM_VAR) := FALSE ;
		boolean_list(p_22060_COMMCOM_VAR) := FALSE ;
		boolean_list(p_22060_COLLCOM_VAR) := FALSE ;
		boolean_list(p_22060_FREECOM_VAR) := FALSE ;

		IF number_list(p_22060_FC_MASRAF_TUTARI) > 0
		THEN
		   number_list(p_22060_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_22060_LC_MASRAF_TUTAR)) ;
		   number_list(p_22060_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_22060_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

		    IF varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
			 boolean_list(p_22060_FC_MASRAF_ANA) := TRUE ;
			 boolean_list(p_22060_LC_MASRAF_ANA) := FALSE ;
			ELSE
			 boolean_list(p_22060_FC_MASRAF_ANA) := FALSE ;
			 boolean_list(p_22060_LC_MASRAF_ANA) := TRUE ;
			END IF;

			pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_ser_tax);

			number_list(p_22060_FC_SERVICE_TAX):=Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(number_list(p_22060_LC_SERVICE_TAX)/number_list(p_22060_KUR)));
			number_list(p_22060_LC_SERVICE_TAX):=(number_list(p_22060_LC_SERVICE_TAX)* ln_ser_tax)/100;
			number_list(p_22060_FC_SERVICE_TAX):=(number_list(p_22060_FC_SERVICE_TAX)* ln_ser_tax)/100;

		   ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22060, NULL, pn_islem_no,
					    					  	 varchar_list, number_list,
												 date_list, boolean_list,
									    	  	 NULL, FALSE, ln_fis_no, NULL);
		END IF;
		pn_fis_no := ln_fis_no;
	END IF;
END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
   BEGIN
    NULL;
   END;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebe_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, NULL);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE EOD_Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER, ps_referans VARCHAR2, pn_vs_no NUMBER, ps_masraf_kodu VARCHAR2) IS
   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_fc		  NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ln_top_bsmv 			  NUMBER := 0;
   ln_bsmv				  NUMBER := 0;
   ls_istatistik_kodu     VARCHAR2(2000);
   ls_aciklama			  VARCHAR2(2000);
   ln_dk_grup_no		  NUMBER;
   ln_ser_tax		  NUMBER;

   CURSOR cur_masraf IS
    SELECT *
	  FROM CBS_MASRAF_ITH_IHR
	 WHERE referans = ps_referans
	   AND durum = 'VALID'
	   AND masraf_kodu = ps_masraf_kodu
	 ORDER BY sira_no
	FOR UPDATE;
	row_masraf cur_masraf%ROWTYPE;

    CURSOR c_0 IS
    SELECT COUNT(*)
	  FROM CBS_MASRAF_ITH_IHR
	 WHERE referans = ps_referans
	   AND durum = 'VALID'
	   AND masraf_kodu = ps_masraf_kodu;
	 ln_temp NUMBER;

   CURSOR cur_akr IS
     SELECT * FROM CBS_ITH_AKREDITIF
	  WHERE referans = ps_referans;
	 row_akr cur_akr%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT a
	  WHERE referans = ls_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
		AND masraf_kodu = ps_masraf_kodu
	 FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;
   ls_acik_tutar_ref VARCHAR2(100);
  BEGIN
    ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	boolean_list(p_22060_MAILCOM_VAR) := FALSE ;
	boolean_list(p_22060_COMMCOM_VAR) := FALSE ;
	boolean_list(p_22060_COLLCOM_VAR) := FALSE ;
	boolean_list(p_22060_FREECOM_VAR) := FALSE ;
	boolean_list(p_22060_FC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22060_LC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := FALSE ;


    varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) := 'AAA';
	OPEN cur_akr;
	FETCH cur_akr INTO row_akr;
	 ls_akr_doviz := row_akr.doviz_kodu;
	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
    	 varchar_list(p_22060_MASRAF_HESAP_NO) := row_akr.masraf_hesap_no;

		 if pkg_musteri.musteri_vergiden_muafmi(row_akr.ITHALATCI_MUSTERI) = 'E'
		 then
			boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := FALSE ;
		 else
			boolean_list(p_22060_VERGIDEN_MUAF_DEGIL) := TRUE ;
		 end if;
	     varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
	     varchar_list(p_22060_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_akr.masraf_hesap_no);
	 else
	 	 varchar_list(p_22060_MASRAF_HESAP_NO) := '';
	 END IF;

	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
	     ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(row_akr.ITHALATCI_MUSTERI) ;
		 varchar_list(p_22060_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPMAILCHR');
		 varchar_list(p_22060_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOMCAT');
		 varchar_list(p_22060_COLL_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOLLCOM');
		 varchar_list(p_22060_FREE_COM_GL)    :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPFREECOM');
	 ELSE
		 varchar_list(p_22060_MAIL_CHARGE_GL) := '';
		 varchar_list(p_22060_COMM_CHARGE_GL) := '';
		 varchar_list(p_22060_COLL_COM_GL)	  := '';
		 varchar_list(p_22060_FREE_COM_GL)    := '';
	 END IF;

	 varchar_list(p_22060_ISLEM_SUBE) := row_akr.bolum_kodu;
	 ls_referans := row_akr.referans;

	 varchar_list(p_22060_REFERENCE) := ls_referans;

	CLOSE cur_akr;

	ls_acik_tutar_ref := RTRIM(TO_CHAR(row_akr.dosya_tutari,'999G999G999G999G999G999G999D99')) || ls_akr_doviz || '-' || ls_referans;

    IF varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
	 boolean_list(p_22060_LC_MSRF_DOVIZ_KODU) := FALSE;
	 boolean_list(p_22060_FC_MSRF_DOVIZ_KODU) := TRUE ;
	ELSE
	 boolean_list(p_22060_LC_MSRF_DOVIZ_KODU) := TRUE;
	 boolean_list(p_22060_FC_MSRF_DOVIZ_KODU) := FALSE;
	END IF;

	number_list(p_22060_LC_COMM_CHARGE) := 0;
	number_list(p_22060_LC_MAIL_CHARGE) := 0;
	number_list(p_22060_LC_COLL_COM) := 0;
	number_list(p_22060_LC_FREE_COM) := 0;
	number_list(p_22060_LC_MASRAF_TUTAR) := 0;
	number_list(p_22060_FC_MASRAF_TUTARI) := 0;
	number_list(p_22060_LC_SERVICE_TAX) := 0;
	number_list(p_22060_FC_SERVICE_TAX) := 0;

	ls_aciklama := ls_referans || ' -  ' || row_akr.ithalatci_musteri || ' -  ' ||
				   Pkg_Musteri.sf_musteri_adi(row_akr.ithalatci_musteri) || ' -  ' ||
				   ' Import File Opening ' ;
	varchar_list(p_22060_BANKA_ACIK) := ls_aciklama;
	varchar_list(p_22060_MUS_ACIK) :=varchar_list(p_22060_BANKA_ACIK) ;

    IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
	  boolean_list(p_22060_LC) := TRUE;
      boolean_list(p_22060_FC) := FALSE;
	ELSE
	  boolean_list(p_22060_LC) := FALSE;
      boolean_list(p_22060_FC) := TRUE;
	END IF;

	IF row_akr.masraf_hesap_no IS NOT NULL THEN  --masraf hesabi girilmisse
   	   number_list(p_22060_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),1);
		--masraf alinacak hesabin bakiyesini al
		ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_22060_MASRAF_HESAP_NO));
    END IF;

	OPEN cur_masraf;
	LOOP
	  FETCH cur_masraf INTO row_masraf;
	  EXIT WHEN cur_masraf%NOTFOUND;
	  ln_bsmv := 0;
	  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
		  IF Pkg_Ithalat.masraf_kontrol_yap_nonakr(row_masraf.ODEYECEK) = 'Y'
		     AND boolean_list(p_22060_VERGIDEN_MUAF_DEGIL)
		  THEN
		      ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
			  IF row_masraf.masraf_kodu = 'IMPCOMCAT'  THEN   --haberlesme
			    boolean_list(p_22060_COMMCOM_VAR) := TRUE ;
				number_list(p_22060_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22060_LC_COMM_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
				number_list(p_22060_LC_SERVICE_TAX):=number_list(p_22060_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF row_masraf.masraf_kodu = 'IMPMAILCHR' THEN   --posta
			  	boolean_list(p_22060_MAILCOM_VAR) := TRUE ;
			   number_list(p_22060_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22060_LC_MAIL_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
				number_list(p_22060_LC_SERVICE_TAX):=number_list(p_22060_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF row_masraf.masraf_kodu = 'IMPCOLLCOM' THEN
			    boolean_list(p_22060_COLLCOM_VAR) := TRUE ;
			   number_list(p_22060_LC_COLL_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22060_LC_COLL_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
			  ELSIF row_masraf.masraf_kodu =  'IMPFREECOM' THEN  --
			    boolean_list(p_22060_FREECOM_VAR) := TRUE ;
			   number_list(p_22060_LC_FREE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22060_LC_FREE_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22060_KUR)));
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;

			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_fc  THEN --bakiye yeterliyse satiri ekle
			     IF ln_tahsil_tutar <> 0 THEN
			         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22060, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_22060_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_22060_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22060_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_22060_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22060_COLLCOM_VAR) = TRUE THEN
					  	 boolean_list(p_22060_COLLCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22060_FREECOM_VAR) = TRUE THEN
					  	 boolean_list(p_22060_FREECOM_VAR) := FALSE;
					  END IF;

					  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      UPDATE CBS_MASRAF_ITH_IHR
					     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       WHERE CURRENT OF cur_masraf;

					  ln_son_bakiye := ln_son_bakiye - ln_borc_fc ;
					  number_list(p_22060_LC_MASRAF_TUTAR) := number_list(p_22060_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_22060_FC_MASRAF_TUTARI) := number_list(p_22060_FC_MASRAF_TUTARI) + ln_borc_fc;
				END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_fc, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_22060_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;

	boolean_list(p_22060_MAILCOM_VAR) := FALSE ;
	boolean_list(p_22060_COMMCOM_VAR) := FALSE ;
	boolean_list(p_22060_COLLCOM_VAR) := FALSE ;
	boolean_list(p_22060_FREECOM_VAR) := FALSE ;

	IF number_list(p_22060_FC_MASRAF_TUTARI) > 0
	THEN
	   number_list(p_22060_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_22060_LC_MASRAF_TUTAR)) ;
	   number_list(p_22060_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_22060_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_22060_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_22060_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_22060_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_22060_LC_MASRAF_ANA) := TRUE ;
		END IF;

		pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_ser_tax);

		number_list(p_22060_FC_SERVICE_TAX):=Pkg_Kur.yuvarla(varchar_list(p_22060_MASRAF_HESAP_DOVIZKODU),(number_list(p_22060_LC_SERVICE_TAX)/number_list(p_22060_KUR)));
		number_list(p_22060_LC_SERVICE_TAX):=(number_list(p_22060_LC_SERVICE_TAX)* ln_ser_tax)/100;
		number_list(p_22060_FC_SERVICE_TAX):=(number_list(p_22060_FC_SERVICE_TAX)* ln_ser_tax)/100;

	   ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22060, NULL, pn_islem_no,
				    					  	 varchar_list, number_list,
											 date_list, boolean_list,
								    	  	 NULL, FALSE, ln_fis_no, NULL);
	END IF;
	pn_fis_no := ln_fis_no;
  END;
/*------------------------------------------------------------------------------------------------------*/
 Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
 ln_temp number;
 begin
   select count(*)
     into ln_temp
	 from cbs_masraf_ith_ihr_isl
	where islem_no = pn_islem_no
	  and odeyecek in ('IMPORTER');
   if ln_temp > 0 then
     return 'E';
   else
     return 'H';
   end if;
 end;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN

	p_22060_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('22060_FC_MSRF_DOVIZ_KODU');
	p_22060_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('22060_LC_MSRF_DOVIZ_KODU');
	p_22060_VERGIDEN_MUAF_DEGIL		  := Pkg_Muhasebe.parametre_index_bul('22060_VERGIDEN_MUAF_DEGIL');
	p_22060_KUR						  := Pkg_Muhasebe.parametre_index_bul('22060_KUR');
	p_22060_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('22060_REFERENCE');
	p_22060_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('22060_ISTA_KOD');
	p_22060_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('22060_MUS_ACIK');
	p_22060_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('22060_BANKA_ACIK');
	p_22060_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('22060_ISLEM_SUBE');
	p_22060_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('22060_MASRAF_HESAP_DOVIZ_KODU');
	p_22060_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('22060_FC_MASRAF_TUTARI');
	p_22060_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('22060_LC_MASRAF_TUTAR');
	p_22060_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('22060_LC_SERVICE_TAX');
	p_22060_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('22060_FC_SERVICE_TAX');
	p_22060_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('22060_MASRAF_HESAP_SUBE');
	p_22060_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('22060_MASRAF_HESAP_NO');
	p_22060_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('22060_LC_MAIL_CHARGE');
	p_22060_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('22060_LC_COMM_CHARGE');
	p_22060_LC_COLL_COM				  := Pkg_Muhasebe.parametre_index_bul('22060_LC_COLL_COM');
	p_22060_LC_FREE_COM			      := Pkg_Muhasebe.parametre_index_bul('22060_LC_FREE_COM');
	p_22060_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('22060_MAIL_CHARGE_GL');
	p_22060_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('22060_COMM_CHARGE_GL');
	p_22060_COLL_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('22060_COLL_COM_GL');
	p_22060_FREE_COM_GL			  	  := Pkg_Muhasebe.parametre_index_bul('22060_FREE_CHARGE_GL');
	p_22060_FC						  := Pkg_Muhasebe.parametre_index_bul('22060_FC');
	p_22060_LC						  := Pkg_Muhasebe.parametre_index_bul('22060_LC');
	p_22060_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('22060_MAILCOM_VAR');
	p_22060_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('22060_COMMCOM_VAR');
	p_22060_COLLCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('22060_COLLCOM_VAR');
	p_22060_FREECOM_VAR			      := Pkg_Muhasebe.parametre_index_bul('22060_FREECOM_VAR');
	p_22060_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('22060_FC_MASRAF_ANA');
	p_22060_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('22060_LC_MASRAF_ANA');

 END;
/

