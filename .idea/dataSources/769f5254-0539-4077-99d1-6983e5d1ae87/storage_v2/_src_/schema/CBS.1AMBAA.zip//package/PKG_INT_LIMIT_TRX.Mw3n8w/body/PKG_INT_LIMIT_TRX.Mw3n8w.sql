create PACKAGE BODY     PKG_INT_LIMIT_TRX IS  
              
FUNCTION PutTopicLimit(ps_lang varchar2,
                       ps_limit_type varchar2,
                       ps_code varchar2,
                       ps_period varchar2,
                       ps_min_limit varchar2,
                       ps_max_limit varchar2,
                       ps_currency_code varchar2 default 'KGS',
                       ps_description varchar2 default 'None',
                       ps_channel_code varchar2 default '1',
                       ps_user_code varchar2 default 'CINT_CALLER',       
                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS                   
ln_min_limit number;
ln_max_limit number;
ln_count number := 0;
ls_name varchar2(200 byte);
ls_returncode varchar2(3) := '000';
BEGIN 
      
         
    select count(*) into ln_count 
            from cbs_int_transaction_limit 
                where limit_type = ps_limit_type 
                       and code = ps_code 
                       and period = ps_period;
    
    ln_min_limit := to_number(ps_min_limit, '99999999999.9999');
        
    ln_max_limit := to_number(ps_max_limit, '99999999999.9999');
               
    if ln_count > 0 then
    
        update cbs_int_transaction_limit set 
                    currency_code = nvl(ps_currency_code,pkg_genel.lc_al),
                    min_limit = ln_min_limit,
                    max_limit = ln_max_limit,
                    datetime = pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)),
                    update_user = ps_user_code
                   where limit_type = ps_limit_type 
                         and code = ps_code 
                         and period = ps_period;
           
    else
        ls_name := pkg_int_limit_inq.gettopiclimitname(ps_lang, ps_code);
    
        if ls_name = 'None' then
           ls_name := ps_description;
        end if;
    
     
        insert into cbs_int_transaction_limit
               (limit_type, code, currency_code, period, min_limit, max_limit, datetime, name, create_user)
             values
               (ps_limit_type, ps_code, nvl(ps_currency_code,pkg_genel.lc_al), ps_period, ln_min_limit, ln_max_limit, pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)), ls_name, ps_user_code);
               
    end if;   

    open pc_ref for
        select to_char('000') as code from dual;

    commit;

    return ls_returncode;
    
EXCEPTION
    when others then
        log_at(ps_currency_code,'PutTopicLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        raise;
END; 
                    
FUNCTION PutCustomerLimit(ps_lang varchar2,
                      ps_customer_id varchar2,
                      ps_code varchar2,
                      ps_period varchar2,
                      ps_min_limit varchar2,
                      ps_max_limit varchar2,
                      ps_currency_code varchar2 default 'KGS',
                      ps_channel_code varchar2 default '1',
                      ps_user_code varchar2 default 'CINT_CALLER',       
                      pc_ref out CursorReferenceType) RETURN varchar2
IS                   
ln_customer_no number;
ln_customer_type varchar2(1 byte);
ls_limit_type varchar2(20);
ln_count number := 0;
ln_min_limit number;
ln_max_limit number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN 

    ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
    
    if ln_customer_no is null then
        raise le_customer_not_found;
    end if;
    
    select count(*) into ln_count 
         from cbs_int_transaction_limits 
               where customer_no = ln_customer_no 
                     and code = ps_code
                     and period = ps_period;
    
    ln_min_limit := to_number(ps_min_limit, '99999999999.9999');
        
    ln_max_limit := to_number(ps_max_limit, '99999999999.9999');
               
    if ln_count > 0 then
    
        update cbs_int_transaction_limits set 
                    currency_code = nvl(ps_currency_code,pkg_genel.lc_al),
                    min_limit = ln_min_limit,
                    max_limit = ln_max_limit,
                    datetime = pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)),
                    update_user = ps_user_code
                   where customer_no = ln_customer_no and code = ps_code and period = ps_period;
           
    else
        ln_customer_type := pkg_musteri.sf_musteri_tipi_al(ln_customer_no);
        
        select decode(ln_customer_type,'3','corporate','retail') into ls_limit_type from dual;
        
        insert into cbs_int_transaction_limits
               (customer_no, code, currency_code, period, min_limit, max_limit, used_limit, datetime, limit_type, create_user)
             values
               (ln_customer_no, ps_code, nvl(ps_currency_code,pkg_genel.lc_al), ps_period, ln_min_limit, ln_max_limit, 0, pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)), ls_limit_type, ps_user_code);
               
    end if;   

    open pc_ref for
        select '000' as code from dual;

    commit;

    return ls_returncode;
    
    
EXCEPTION
    when le_customer_not_found then
        log_at(ln_customer_no,'PutCustomerLimit', sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         return '454';
    when others then
        log_at(ln_customer_no,'PutCustomerLimit', sqlerrm, dbms_utility.format_error_backtrace);
         rollback;
         raise;
END;   

FUNCTION PutCustomerUsedLimit(ps_lang varchar2,
                          ps_customer_id varchar2,
                          ps_code varchar2,
                          ps_amount varchar2,
                          ps_currency_code varchar2,
                          ps_channel_code varchar2 default '1',
                          ps_user_code varchar2 default 'CINT_CALLER',       
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_used_limit number := 0;
ln_max_limit number := 0;
ln_amount number := 0;
ln_count number := 0;
ln_customer_no number;
temp_ref CursorReferenceType;

cursor cur_limit(c_customer_no varchar2, c_code varchar2) is
   select currency_code, period, min_limit, max_limit, used_limit 
               from cbs_int_transaction_limits 
                      where customer_no = c_customer_no 
                             and code = c_code
                             and period = 'daily';

row_cur_limit cur_limit%rowtype;

ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
le_customer_limit_found exception;
le_limit_exceed exception;
BEGIN

   ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
    if ln_customer_no is null then
       raise le_customer_not_found;
    end if;
      
    
    select count(*) into ln_count
        from cbs_int_transaction_limits
        where customer_no = ln_customer_no
            and code = ps_code
--            and period = 'daily'
            and datetime >= pkg_muhasebe.banka_tarihi_bul;

    if (ln_count != 2) then
        raise le_customer_limit_found;
    end if;

    ln_amount := to_number(ps_amount,'99999999999.9999');
    ln_amount := pkg_kur.doviz_doviz_karsilik(ps_currency_code, pkg_genel.lc_al, null, ln_amount, 1, null, null, 'O', 'A');


    for row_cur_limit in cur_limit(ln_customer_no, ps_code) loop 

            ln_used_limit := pkg_kur.doviz_doviz_karsilik(row_cur_limit.currency_code, pkg_genel.lc_al, null, row_cur_limit.used_limit, 1, null, null, 'O', 'A');  
            
            ln_max_limit := pkg_kur.doviz_doviz_karsilik(row_cur_limit.currency_code, pkg_genel.lc_al, null, row_cur_limit.max_limit, 1, null, null, 'O', 'A'); 
            
            if(ln_max_limit < ln_used_limit + ln_amount) then
               raise le_limit_exceed;
            end if;
                     
            ln_used_limit := pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al, row_cur_limit.currency_code, null, ln_used_limit + ln_amount, 1, null, null, 'O', 'S');

          
            update cbs_int_transaction_limits
                set used_limit = ln_used_limit
                    where customer_no = ln_customer_no
                        and code = ps_code
                        and period = 'daily';
    end loop;

    commit;
    
    ls_returncode := pkg_int_limit_inq.GetCustomerTopicLimit(
                                            ps_lang => ps_lang,
                                            ps_code => ps_code,
                                            ps_customer_id => ps_customer_id,
                                            pc_ref => pc_ref);


    return ls_returncode;
    
EXCEPTION
    when le_customer_not_found then
        log_at(ln_customer_no,'PutCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '454';
    when le_customer_limit_found then
        log_at(ln_customer_no,'PutCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '455';
   when le_limit_exceed then
        log_at(ln_customer_no,'PutCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '463';
    when others then
       log_at(ln_customer_no,'PutCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        raise;
END;

FUNCTION DeleteCustomerUsedLimit(ps_lang varchar2,
                             ps_customer_id varchar2,
                             ps_code varchar2,
                             ps_amount varchar2,
                             ps_currency_code varchar2,
                             ps_channel_code varchar2 default '1',
                             ps_user_code varchar2 default 'CINT_CALLER',       
                             pc_ref OUT CursorReferenceType) RETURN varchar2 
IS                 
ln_used_limit number := 0;
ln_amount number := 0;
ln_count number := 0;
ln_customer_no number;
temp_ref CursorReferenceType;

cursor cur_limit(c_customer_no varchar2, c_code varchar2) is
   select currency_code, period, min_limit, max_limit, used_limit  
           from cbs_int_transaction_limits 
                  where customer_no = c_customer_no 
                        and code = c_code
                        and period = 'daily';

row_cur_limit cur_limit%rowtype;

ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
le_customer_limit_not_found exception;
le_limit_amount_error exception;
BEGIN

   ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
    if ln_customer_no is null then
       raise le_customer_not_found;
    end if;
      
    select count(*) into ln_count
        from cbs_int_transaction_limits
            where customer_no = ln_customer_no
                    and code = ps_code
--                    and period = 'daily'
                    and datetime >= pkg_muhasebe.banka_tarihi_bul;

    if (ln_count != 2) then
        raise le_customer_limit_not_found;
    end if;

    ln_amount := to_number(ps_amount, '99999999999.9999');
    ln_amount := pkg_kur.doviz_doviz_karsilik(ps_currency_code, pkg_genel.lc_al, null, ln_amount, 1, null, null, 'O', 'A');

    for row_cur_limit in cur_limit(ln_customer_no, ps_code) loop 

            ln_used_limit := pkg_kur.doviz_doviz_karsilik(row_cur_limit.currency_code, pkg_genel.lc_al, null, row_cur_limit.used_limit, 1, null, null, 'O', 'A'); 
            
            if ln_used_limit < ln_amount then
               raise le_limit_amount_error;
            end if;
                    
            ln_used_limit := pkg_kur.doviz_doviz_karsilik(pkg_genel.lc_al, row_cur_limit.currency_code, null, ln_used_limit - ln_amount, 1, null, null, 'O', 'S');
          
                update cbs_int_transaction_limits
                    set used_limit = ln_used_limit
                        where customer_no = ln_customer_no
                                and code = ps_code
                                and period = 'daily';
    end loop;

    commit;
    
    ls_returncode := pkg_int_limit_inq.GetCustomerTopicLimit(
                                            ps_lang => ps_lang,
                                            ps_code => ps_code,
                                            ps_customer_id => ps_customer_id,
                                            pc_ref => pc_ref);


    return ls_returncode;
    
EXCEPTION
    when le_customer_not_found then
        log_at(ln_customer_no,'DeleteCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '454';
    when le_customer_limit_not_found then
        log_at(ln_customer_no,'DeleteCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;  
        return '455';
    when le_limit_amount_error then
        log_at(ln_customer_no,'DeleteCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        return '463';
    when others then
        log_at(ln_customer_no,'DeleteCustomerUsedLimit', sqlerrm, dbms_utility.format_error_backtrace);
        rollback;
        raise;
END;
FUNCTION InitCustomerLimit(ps_code varchar2,
                       pn_customer_no number,
                       ps_limit_type varchar2) RETURN varchar2
IS
ln_count number := 0;
ls_returncode varchar2(3) := '000';
BEGIN

   select count(*) into ln_count 
             from cbs_int_transaction_limits 
                  where customer_no = pn_customer_no;
   
   if ln_count = 0 then
      insert into cbs_int_transaction_limits 
              (customer_no, code, currency_code, period, min_limit, max_limit, used_limit, datetime, limit_type) 
              select pn_customer_no, code, currency_code, period, min_limit, max_limit, 0, pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)), limit_type 
                  from cbs_int_transaction_limit where limit_type = ps_limit_type;
   end if;
   
   select count(*) into ln_count 
           from cbs_int_transaction_limits 
               where customer_no = pn_customer_no
                     and code = ps_code;
   
   if ln_count > 0 then
      return ls_returncode;
   else
     insert into cbs_int_transaction_limits 
              (customer_no, code, currency_code, period, min_limit, max_limit, used_limit, datetime, limit_type) 
              select pn_customer_no, code, currency_code, period, min_limit, max_limit, 0, pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)), limit_type 
                  from cbs_int_transaction_limit where limit_type = ps_limit_type and code = ps_code;
   end if;
   
   return ls_returncode;
   
EXCEPTION
    when others then
         rollback;
         raise;  
END;      
FUNCTION ResetCustomerLimit(pn_customer_no number,
                        ps_limit_type varchar2) RETURN varchar2
IS
ln_count number := 0;

cursor cur_limit(limit_type varchar2) is
   select code, currency_code, period, min_limit, max_limit, limit_type 
           from cbs_int_transaction_limit 
                    where limit_type = limit_type;
   
row_cur_limit cur_limit%rowtype;

ls_returncode varchar2(3) := '000';
BEGIN

    FOR row_cur_limit IN cur_limit(ps_limit_type) LOOP 
    
      update cbs_int_transaction_limits 
          set currency_code = row_cur_limit.currency_code,
                 min_limit = row_cur_limit.min_limit,
                 max_limit = row_cur_limit.max_limit,
                 datetime = pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)),
                 used_limit = 0
           where code = row_cur_limit.code
                  and period = row_cur_limit.period
                  and limit_type = row_cur_limit.limit_type
                  and customer_no = pn_customer_no
                  and datetime < pkg_muhasebe.banka_tarihi_bul;

    END LOOP;
    
   return ls_returncode;
   
EXCEPTION
    when others then
         rollback;
         raise;     
END;                                                                         
END;
/

