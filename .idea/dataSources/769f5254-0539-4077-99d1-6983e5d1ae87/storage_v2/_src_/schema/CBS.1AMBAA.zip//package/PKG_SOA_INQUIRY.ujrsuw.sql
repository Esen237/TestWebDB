create PACKAGE     "PKG_SOA_INQUIRY" IS

TYPE CursorReferenceType IS REF CURSOR;
/******************************************************************************
   NAME        : FUNCTION GetPaymentCodesByOption
   Prepared By : Almas Nurhozhaev
   Date        : 31.03.08
   Purpose     : Get Customization Elements Data
******************************************************************************/
FUNCTION GetCustomizeElements(pn_personCD IN VARCHAR2,
                              ps_element_type IN VARCHAR2,
                              ps_langCD IN VARCHAR2,
                              pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetExchangeRates
   Prepared By : Almas Nurhozhaev
   Date        : 05.07.2008
   Purpose     : Exchange Rates will be returned
******************************************************************************/
FUNCTION GetExchangeRates (p_option IN VARCHAR2,
                           p_customerid IN VARCHAR2,
                           p_personid  IN VARCHAR2,
                           p_channelcd IN VARCHAR2,
                           p_trancd    IN VARCHAR2,
                           pd_tarih IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                           pc_ref4 OUT CursorReferenceType,
                           pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetAccounts
   Prepared By : Almas Nurhozhaev
   Date        : 30.06.08
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetAccounts(p_option IN VARCHAR2,
                      p_customerid IN VARCHAR2,
                      p_personid  IN VARCHAR2,
                      p_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME          : FUNCTION StatementDetail
   Prepared By   : Almas Nurhozhaev
   Date          : 22.02.2008
   Purpose       : Get last financial ten transactions
******************************************************************************/
FUNCTION GetLastTenTran(pn_CustomerNo   IN VARCHAR2,
                        pn_langCD   IN VARCHAR2,
                        pc_ref          OUT CursorReferenceType,
                        pc_ref2      OUT CursorReferenceType,
                        pc_ref3      OUT CursorReferenceType,
                        pc_ref4      OUT CursorReferenceType,
                        pc_ref5      OUT CursorReferenceType)  RETURN VARCHAR2;
                        
/******************************************************************************
   NAME          : FUNCTION GetTranHistoryUNDP
   Prepared By   : Nurhat UCA
   Date          : 12.10.2012
   Purpose       : Get latest transactions with details by transaction type - date filter
******************************************************************************/
FUNCTION GetTranHistoryUNDP (
                                           ps_accountNo         IN     VARCHAR2, 
                                           pd_startDate         IN     VARCHAR2,
                                           pd_endDate           IN     VARCHAR2,
                                           pc_ref          OUT CursorReferenceType
                                        )  RETURN VARCHAR2;
/******************************************************************************
   NAME          : FUNCTION GetLoanInstallment
   Prepared By   : Almas Nurhozhaev
   Date          : 22.02.2008
   Purpose       : Get Loan Installment
******************************************************************************/
FUNCTION GetLoanInstallment(pn_CustomerNo IN VARCHAR2,
                            pc_ref          OUT CursorReferenceType,
                            pc_ref2      OUT CursorReferenceType,
                            pc_ref3      OUT CursorReferenceType,
                            pc_ref4      OUT CursorReferenceType,
                            pc_ref5      OUT CursorReferenceType)  RETURN VARCHAR2;

/******************************************************************************
   NAME          : FUNCTION GetTimeDepositRatesAll
   Prepared By   : Almas Nurhozhaev
   Date          : 30.06.2008
   Purpose       : Get All Time Deposit Rates
******************************************************************************/
FUNCTION GetTimeDepositRatesAll(pn_CustomerId  IN VARCHAR2,
                                pn_PersonId    IN VARCHAR2,
                                ps_ChannelCd   IN VARCHAR2,
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType,
                                pc_ref4 OUT CursorReferenceType,
                                pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME          : FUNCTION GetUserWarnings
   Prepared By   : Almas Nurhozhaev
   Date          : 26.02.2008
   Purpose       : Get User Warnings
******************************************************************************/
FUNCTION GetUserWarnings(pn_warningType IN VARCHAR2,
                         ps_channel_cd IN VARCHAR2,--ernestk 14022014 cqdb00000504 news differs by channel
                         pn_langCD IN VARCHAR2,
                         pc_ref       OUT CursorReferenceType,
                         pc_ref2      OUT CursorReferenceType,
                         pc_ref3      OUT CursorReferenceType,
                         pc_ref4      OUT CursorReferenceType,
                         pc_ref5      OUT CursorReferenceType)  RETURN VARCHAR2;

/******************************************************************************
   NAME       : GetIntStatementHeader
   Prepared By: Almas Nurhozhaev
   Date          : 09.11.07
   Purpose      :
******************************************************************************/
FUNCTION GetIntStatementHeader(p_option IN VARCHAR2,
                                p_customerid IN VARCHAR2,
                                  p_personid  IN VARCHAR2,
                                 p_channelcd IN VARCHAR2,
                                p_account_no IN VARCHAR2,
                                pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                               pc_ref OUT CursorReferenceType,
                               pc_ref2 OUT CursorReferenceType,
                               pc_ref3 OUT CursorReferenceType,
                               pc_ref4 OUT CursorReferenceType,
                               pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : GetAccountHistory
   Prepared By: Almas Nurhozhaev
   Date          : 09.11.07
   Purpose      :Customer Account History will be returned
******************************************************************************/
FUNCTION  GetAccountHistory(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                            p_channelcd IN VARCHAR2,
                            p_account_no IN VARCHAR2,
                            pd_start_date IN VARCHAR2,
                            pd_end_date      IN VARCHAR2,
                            pd_islem_tur        IN VARCHAR2 DEFAULT '%',
                            pd_hareket        IN VARCHAR2 DEFAULT '%',
                            pd_alt_sinir     IN VARCHAR2,
                            pd_ust_sinir     IN VARCHAR2,
                            pd_lang     IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
                            
FUNCTION  GetAccountHistoryPaged(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                            p_channelcd IN VARCHAR2,
                            p_account_no IN VARCHAR2,
                            pd_start_date IN VARCHAR2,
                            pd_end_date      IN VARCHAR2,
                            pd_islem_tur        IN VARCHAR2 DEFAULT '%',
                            pd_hareket        IN VARCHAR2 DEFAULT '%',
                            pd_alt_sinir     IN VARCHAR2,
                            pd_ust_sinir     IN VARCHAR2,
                            pd_lang     IN VARCHAR2,
                            pn_pageSize     IN NUMBER,
                            pn_pageNumber     IN NUMBER,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType ) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION FinancialSummary
   Prepared By : Almas Nurhozhaev
   Date        : 10.12.2007
   Purpose     : Financial Summary
******************************************************************************/
FUNCTION FinancialSummary(pn_customerNo IN VARCHAR2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : GetAccountDetails
   Prepared By: Almas Nurhozhaev
   Date          : 08.11.07
   Purpose      :Customer Account Detail Informations will be returned
******************************************************************************/
FUNCTION GetAccountDetails(p_option IN VARCHAR2,
                             p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                           p_channelcd IN VARCHAR2,
                           p_account_no IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                             pc_ref2 OUT CursorReferenceType,
                             pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetTranAccounts
   Prepared By : Tastan Zhaylibayev
   Date        : 06.12.07
   Purpose     : Get Customer Accounts
******************************************************************************/
FUNCTION GetTranAccounts(pn_musteri_no IN VARCHAR2,
                          ps_currcode IN VARCHAR2,
                         pn_person_id  IN VARCHAR2,
                         pn_channel_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION EFTInquiry
   Prepared By : Tastan Zhaylibayev
   Date        : 05.12.07
   Purpose     : Search clearing transactions
******************************************************************************/
FUNCTION EFTInquiry(pn_musterino IN VARCHAR2,
                     pn_sorguno IN VARCHAR2,
                    pd_startdate IN VARCHAR2,
                    pd_enddate     IN VARCHAR2,
                    ps_payment_type IN VARCHAR2,--ernestk 14022014 cqdb00000504 new filter by payment type(gross, clearing)
                    pn_start_amount       IN VARCHAR2,--ernestk 14022014 cqdb00000504 new filter
                    pn_end_amount       IN VARCHAR2,--ernestk 14022014 cqdb00000504 new filter
                    ps_beneficiar_name IN VARCHAR2,--ernestk 14022014 cqdb00000504 new filter
                    ps_status     IN VARCHAR2,
                    pc_ref OUT CursorReferenceType,
                    pc_ref2 OUT CursorReferenceType,
                    pc_ref3 OUT CursorReferenceType,
                    pc_ref4 OUT CursorReferenceType,
                    pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetPaymentCodes
   Prepared By : Almas Nurhozhaev
   Date        : 03.07.08
   Purpose     : Get Payment Codes
******************************************************************************/
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION GetCustomerInfo
   Created By : Almas Nurhozhaev
   Date       : 05.12.07
   Purpose    : Get Customer Info
******************************************************************************/
FUNCTION GetCustomerInfo(ps_customerid IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetVirmanHesapInfo
   Prepared By : Tastan Zhaylibayev
   Date        : 07.12.07
   Purpose     : GetVirmanHesapInfo
******************************************************************************/
FUNCTION GetVirmanHesapInfo(ps_account_no IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION geteftdate
   Prepared By : Tastan Zhaylibayev
   Date        : 06.12.07
   Purpose     : Get clearing transaction date
******************************************************************************/
FUNCTION geteftdate (   pd_date IN VARCHAR2,
                        ps_transfer_option IN VARCHAR2,--ernestk 14022014 cqdb00000504 eft date by payment type 
                        pc_ref OUT cursorreferencetype) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION checktime
   Prepared By : Tastan Zhaylibayev
   Date        : 06.12.07
   Purpose     : Check clearing transaction making time
******************************************************************************/
FUNCTION checktime (pd_desc IN VARCHAR2, pd_src IN VARCHAR2) RETURN NUMBER;

/******************************************************************************
   NAME        : FUNCTION GetBankCodes
   Prepared By : Tastan Zhaylibayev
   Date        : 06.12.07
   Purpose     : Get Banks Code
******************************************************************************/
FUNCTION GetBankCodes(ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetLoanAccount
   Prepared By : Almas Nurhozhaev
   Date        : 21.12.2007
   Purpose     : Get Loan Account
******************************************************************************/
FUNCTION GetLoanAccount(pn_CustomerId IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetTimeDepositRate
   Prepared By : Almas Nurhozhaev
   Date        : 05.06.2008
   Purpose     : Get Rates of Time Deposit
******************************************************************************/
FUNCTION GetTimeDepositRate(pn_CustomerId  IN VARCHAR2,
                            pn_PersonId    IN VARCHAR2,
                            ps_ChannelCd   IN VARCHAR2,
                            ps_CurrencyCd  IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME          : FUNCTION GetIntTranAccounts
   Prepared By   : Alexandir Lee
   Date          : 27.12.2007
   Purpose       : Get Int Tran Accounts
   Modified By   : Tastan Zhaylibayev
   Modified Date : 03.01.2008
******************************************************************************/
FUNCTION  GetIntTranAccounts(pn_musteri_no IN VARCHAR2,
                              ps_currcode IN VARCHAR2,
                             pn_person_id  IN VARCHAR2,
                             pn_channel_cd IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetCurrencyInfo
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Currency Info
******************************************************************************/
FUNCTION GetCurrencyInfo(ps_option        IN VARCHAR2,
                          ps_musterino      IN VARCHAR2,
                         ps_reservationno IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetExchangeTranRate
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Exchange Tran Rate
******************************************************************************/
FUNCTION GetExchangeTranRate(ps_trantype IN VARCHAR2,
                              pn_musterino IN VARCHAR2,
                              pn_amount IN VARCHAR2,
                             ps_amountcurr     IN VARCHAR2,
                             ps_foreigncurr     IN VARCHAR2,
                             ps_rezervationno     IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetLoanAccount
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Loan Account
******************************************************************************/
FUNCTION GetLoanPaymentPlan(pn_AccountNo IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetExchangeInfo
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Exchange Rates, Account Info,Limit Info will be returned
******************************************************************************/
FUNCTION GetExchangeInfo(p_option IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                           p_channelcd IN VARCHAR2,
                         p_trancd    IN VARCHAR2,
                         pd_tarih IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType,
                         pc_ref4 OUT CursorReferenceType,
                         pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetTranAccounts
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Transaction Account Info will be returned
******************************************************************************/
FUNCTION GetTranAccounts(p_option  IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                         p_personid  IN VARCHAR2,
                         p_channelcd IN VARCHAR2,
                         p_currcode IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetRateDemandInquiry
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Get Rezervations
******************************************************************************/
FUNCTION GetRateDemandInquiry(ps_customerid IN VARCHAR2,
                               ps_demandrezerv IN VARCHAR2,
                              ps_buysell  IN VARCHAR2,
                              ps_currcode IN VARCHAR2,
                              pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                              ps_islemsekli IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION ExchangeTransactions
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Limit Info, get Exchange Transaction
******************************************************************************/
FUNCTION ExchangeTransactions(p_option IN VARCHAR2,
                               p_customerid IN VARCHAR2,
                              p_personid IN VARCHAR2,
                              p_channelcd IN VARCHAR2,
                              p_trancd IN VARCHAR2,
                               p_trantype IN VARCHAR2,
                               p_amount IN VARCHAR2,
                              p_amountcurr     IN VARCHAR2,
                              p_foreigncurr     IN VARCHAR2,
                              p_rezervationno     IN VARCHAR2,
                               pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CallExchangeTran
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Limit Info, get Exchange Transaction
******************************************************************************/
FUNCTION CallExchangeTran(p_option IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                          p_personid IN VARCHAR2,
                          p_channelcd IN VARCHAR2,
                          p_trancd IN VARCHAR2,
                          p_trantype IN VARCHAR2,
                          p_fromaccount IN VARCHAR2,
                          p_toaccount IN VARCHAR2,
                          p_amount IN VARCHAR2,
                          p_amountcurr     IN VARCHAR2,
                          p_rate IN VARCHAR2,
                          p_rezervationno     IN VARCHAR2,
                          p_description IN VARCHAR2,
                          p_totalamount IN VARCHAR2,
                          p_expence   IN VARCHAR2,
                          p_statisticcode IN VARCHAR2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION HesapMusteriKontrol
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Customer accounts
******************************************************************************/
FUNCTION HesapMusteriKontrol(pn_accountNo  IN VARCHAR2,
                             pn_customerNo IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetArbitrajeInfo
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Controls Arbitraje, gets Account Info,Limit Info
******************************************************************************/
FUNCTION  GetArbitrajeInfo(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                              p_personid  IN VARCHAR2,
                             p_channelcd IN VARCHAR2,
                           p_trancd    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                           pc_ref4 OUT CursorReferenceType,
                           pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION GetArbitrageRates
   Created By : Almas Nurhozhaev
   Date       : 07.07.2008
   Purpose    : Get Arbitrage Rates
******************************************************************************/
FUNCTION GetArbitrageRates(ps_customerid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CheckArbitraje
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Controls Arbitraje, gets Account Info,Limit Info
******************************************************************************/
FUNCTION CheckArbitraje(p_option IN VARCHAR2,
                        p_customerid IN VARCHAR2,
                        p_personid  IN VARCHAR2,
                        p_channelcd IN VARCHAR2,
                        p_trancd    IN VARCHAR2,
                        p_toaccount IN VARCHAR2,
                        p_fromaccount IN VARCHAR2,
                        p_toaccountcurr IN VARCHAR2,
                        p_fromaccountcurr IN VARCHAR2,
                        p_amount     IN VARCHAR2,
                        p_amountcurr  IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetParity
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Get parity
******************************************************************************/
FUNCTION GetParity(p_fromaccount IN VARCHAR2,
                   p_toaccount IN VARCHAR2,
                   p_amount IN VARCHAR2,
                   p_amountcurreny IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CallArbitTran
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Checks for Customer Account, Calls Arbitraje Transaction, updates limits
******************************************************************************/
FUNCTION  CallArbitTran(p_option IN VARCHAR2,
                        p_customerid IN VARCHAR2,
                        p_personid  IN VARCHAR2,
                        p_channelcd IN VARCHAR2,
                        p_trancd    IN VARCHAR2,
                        p_toaccount IN VARCHAR2,
                        p_fromaccount IN VARCHAR2,
                        p_toaccountcurr IN VARCHAR2,
                        p_fromaccountcurr IN VARCHAR2,
                        p_parity  IN VARCHAR2,
                        p_toamount IN VARCHAR2,
                        p_fromamount IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME          : FUNCTION GetTranStatement
   Prepared By   : Almas Nurhozhaev
   Date          : 16.07.2008
   Purpose       : Get Transaction Statementt
******************************************************************************/
FUNCTION GetTranStatement(pn_txno IN VARCHAR2,
                           pn_custno IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetTimeDepositInfo
   Prepared By : Muzaffar Khaloyknaza
   Date        : 12.12.2007
   Purpose     : Get Time Deposit Info
******************************************************************************/
FUNCTION GetTimeDepositInfo(pn_CustomerId  IN VARCHAR2,
                            pn_PersonId    IN VARCHAR2,
                            ps_ChannelCd   IN VARCHAR2,
                            ps_CurrencyCd  IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
 /******************************************************************************
   NAME        : FUNCTION GetTranAccountsForCurrcode
   Prepared By : Muzaffar Khalyknazarov
   Date        : 24.12.2007
   Purpose     : Get Tran Accounts for currency code
******************************************************************************/
FUNCTION GetTranAccountsForCurrcode(pn_musteri_no IN VARCHAR2,
                                    ps_currcode IN VARCHAR2,
                                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION CheckTimeDepositDate
   Prepared By : Muzaffar khalyknazarov
   Date        : 21.12.2007
   Purpose     : Check time Depoosit Date
   Modified By   : Tastan Zhaylibayev
   Modified Date : 08.01.2008
******************************************************************************/
FUNCTION CheckTimeDepositDate(pn_CustomerId         IN VARCHAR2,
                              ps_MaturityDate       IN VARCHAR2,
                              ps_MaturityDay        IN VARCHAR2,
                              ps_vade_islem_belgisi IN VARCHAR2,
                              pn_Amount             IN VARCHAR2,
                              ps_CurrencyCd         IN VARCHAR2,
                              pn_ara_odeme_bilgisi  IN VARCHAR2,
                              pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
 /******************************************************************************
   NAME        : FUNCTION CheckTimeDepositClosingDate
   Prepared By : Muzaffar Khalyknazarov
   Date        : 25.12.2007
   Purpose     : CheckTimeDepositClosingDate
******************************************************************************/
FUNCTION CheckTimeDepositClosingDate(pd_date IN VARCHAR2,
                                     pn_vadegun IN VARCHAR2,
                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetCommission
   Prepared By : Muzaffar Khalyknazarov
   Date        : 28.01.2009
   Purpose     : GetCommission
******************************************************************************/
FUNCTION GetCommission(ps_TranCd     IN VARCHAR2,
                       pn_FromAccNo  IN VARCHAR2,
                       pn_ToAccNo    IN VARCHAR2,
                       pn_Amount     IN VARCHAR2,
                       ps_CurrCd     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetTimeDepAccounts
   Prepared By : Muzaffar Khalyknazarov
   Date        : 03.02.09
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetTimeDepAccounts(p_customerid IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                             pc_ref2 OUT CursorReferenceType,
                             pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetWaitTran
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get All Waiting Transactions
******************************************************************************/
FUNCTION GetWaitTran(ps_OptionCd       IN VARCHAR2,
                     ps_TxNo           IN VARCHAR2,
                     pn_CustomerNo     IN VARCHAR2,
                      pn_PersonNo       IN VARCHAR2,
                     ps_LangCd         IN VARCHAR2,
                     ps_startdate      IN VARCHAR2 default '20050101',
                     ps_enddate        IN VARCHAR2 default '20990101',
                     ps_statuscd       IN VARCHAR2,
                     pc_ref OUT CursorReferenceType,
                     pc_ref2 OUT CursorReferenceType,
                     pc_ref3 OUT CursorReferenceType,
                     pc_ref4 OUT CursorReferenceType,
                     pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION SwiftBankInfo
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Swift Bank Info
******************************************************************************/
FUNCTION SwiftBankInfo(ps_bankcountry  IN VARCHAR2,
                       ps_bankcity     IN VARCHAR2,
                       ps_bankname     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetBankWorkingDays
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get Bank Working Days
******************************************************************************/
FUNCTION GetBankWorkingDays(ps_option VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION SwiftCountryName
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Swift Country Name
******************************************************************************/
FUNCTION SwiftCountryName(ps_customer_no      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetCorrespondentAccountNo
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get Correspondent Account No
******************************************************************************/
FUNCTION GetCorrespondentAccountNo(ps_currcode IN VARCHAR2) RETURN NUMBER;

/******************************************************************************
   NAME        : FUNCTION GetPaymentCodesByOption
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get Payment Codes By Option
******************************************************************************/
FUNCTION GetPaymentCodesByOption(ps_option IN VARCHAR2,ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetSWIFTInquiry
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get SWIFT Inquiry
******************************************************************************/
FUNCTION GetSWIFTInquiry(ps_customerid IN VARCHAR2,
                         pd_startdate IN VARCHAR2,
                         pd_enddate IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION GetAccountsForCCPayments
   Prepared By : Nurhat Uca
   Date        : 27.08.2012
   Purpose     : GetAccountsForCreditCardPayments - cq8574
******************************************************************************/
FUNCTION GetAccountsForCCPayments(ps_customer_id IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/*usip functions*/
/******************************************************************************
   NAME        : FUNCTION GetPaymentServices
   Prepared By : Almas Nurkhozhayev
   Date        : 10.11.2011
   Purpose     : Get Payment Services
******************************************************************************/
FUNCTION GetPaymentServices(ps_option IN VARCHAR2,
                            ps_group IN VARCHAR2,
                            ps_subgroup IN VARCHAR2,
                            ps_institution IN VARCHAR2,
                            ps_lang IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetCreatedPayments
   Prepared By : Almas Nurkhozhayev
   Date        : 14.11.2011
   Purpose     : Get Created Payments
******************************************************************************/
FUNCTION GetCreatedPayments(ps_option IN VARCHAR2,
                            ps_payment_id IN VARCHAR2,
                            ps_person_id IN VARCHAR2,
                            ps_customer_id IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                            
/******************************************************************************
   NAME        : FUNCTION GetPaymentINQ
   Prepared By : Volkan Gurcesme
   Date        : 27.08.2012
   Purpose     : Get Payments Inquiry
******************************************************************************/
FUNCTION GetPaymentINQ(ps_customer_id IN VARCHAR2,
                            ps_group_code IN VARCHAR2,
                            ps_subgroup_code IN VARCHAR2,
                            ps_institution IN VARCHAR2,
                            ps_start_date IN VARCHAR2,
                            ps_end_date IN VARCHAR2,
                            ps_lang IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
 /******************************************************************************
   NAME        : FUNCTION GetAccountsForUsipPayments
   Prepared By : Nurhat Uca
   Date        : 27.08.2012
   Purpose     : GetAccountsForUsipPayments 
******************************************************************************/
FUNCTION GetAccountsForUsipPayments(pn_musteri_no IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;                            
--B-O-M ernestk 03032014 cqdb00000527-usip commissioning calculation
/******************************************************************************
    Name        :calculate_ip_commission
    Prepared By : Ernest Kuttubaev
    Date:       :09.10.2013
    Purpose     : for calculation of tahsilat commission for amount by kurum tanim
******************************************************************************/      
FUNCTION calculate_ip_commission(ps_institution IN VARCHAR2,
                            ps_amount IN varchar2,
                            ps_lang IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--E-O-M ernestk 03032014 cqdb00000527-usip commission calucalation
/******************************************************************************
   NAME        : FUNCTION getPaymentCodeExplanation
   Prepared By : Ernest Kuttubaev
   Date        : 14.02.2014
   Purpose     : to get the explanation of the payment code
******************************************************************************/
FUNCTION getPaymentCodeExplanation( ps_payment_code     IN varchar2,
                                    ps_lang_cd          IN varchar2) return varchar2;
--B-O-M ernestk cqdb00000824 add inquiry invoices and get one invoice functions
/*******************************************************************************
    Name        :inquiryDDSInvoices
    Prepared By :Ernest Kuttubaev
    Date:       :20.12.2013
    Purpose     :To get tbl_invoices filtered by passed params
*******************************************************************************/
FUNCTION inquiryDDSInvoices (   ps_customer_id          IN varchar2,
                                ps_valuedate_start      IN varchar2,
                                ps_valuedate_end        IN varchar2,
                                ps_debit_account_no     IN varchar2,
                                ps_credit_account_no    IN varchar2,
                                ps_amount           IN varchar2,
                                ps_status           IN varchar2,
                                pc_ref              OUT cursorreferencetype)
                                RETURN VARCHAR2;
/*******************************************************************************
    Name        :getDDSInvoice
    Prepared By :Ernest Kuttubaev
    Date:       :20.12.2013
    Purpose     :To get tbl_invoice data by invoice id
*******************************************************************************/
FUNCTION getDDSInvoice (        ps_customer_id          IN varchar2,
                                ps_invoice_id            IN varchar2,
                                pc_ref              OUT cursorreferencetype)
                                RETURN VARCHAR2;
/*******************************************************************************
    Name        :getDDSParserName
    Prepared By :Ernest Kuttubaev
    Date:       :13.03.2014
    Purpose     :to get the parser name for the give person
*******************************************************************************/
FUNCTION getDDSParserName(  pn_person_id      IN varchar2,
                            ps_parser_name    OUT varchar2) return varchar2;
--E-O-M ernestk cqdb00000824 add inquiry invoices and get one invoice functions
--B-O-M ernestk 17032014 service name of dcs which should serve this user
/*******************************************************************************
    Name        :getDirectCreditingServiceName
    Prepared By :Ernest Kuttubaev
    Date:       :17.03.2014
    Purpose     :to get service name of the class that should service this user
*******************************************************************************/
FUNCTION getDirectCreditingServiceName(  pn_person_id      IN varchar2,
                                         ps_service_name    OUT varchar2) return varchar2;
--E-O-M ernestk 17032014 service name of dcs which should serve this user

FUNCTION getCountOfClearings(   pn_customer_id      IN varchar2,
                                pn_person_id      IN varchar2,
                                ps_order_number    IN varchar2,
                                ps_count              OUT varchar2) return varchar2;

/*******************************************************************************
    Name        :getCountOfBookToBooks
    Prepared By :Chyngyz Omurov
    Date:       :12.12.2014
    Base Project : cq1264 
    Purpose     :to get the count of book-to-books of customer by order number
*******************************************************************************/
FUNCTION getCountOfBookToBooks( pn_customer_id      IN varchar2,
                                pn_person_id      IN varchar2,
                                ps_order_number    IN varchar2,
                                ps_count   OUT varchar2) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getCreditCardDebt
    Prepared By : Adilet Kachkeev
    Date:       : 18.07.2014
    Base Project : CQDB954 - DKIB Notification Credit Card
    Purpose     : To get the debt information on credit card for particular customer
*******************************************************************************/
FUNCTION getCreditCardDebt(   ps_customer_id      IN varchar2,
                                ps_date IN varchar2,
                                pc_ref              OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getWsTaxInfo
    Prepared By : Almas Nurkhozhayev
    Date:       : 01.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : get info from tax house with Tax Identification Number
*******************************************************************************/
FUNCTION getWsTaxInfo(ps_tin_number IN varchar2,
                      pc_ref        OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getIntParams
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : get list of data from table
*******************************************************************************/
FUNCTION getIntParams(ps_param_code IN varchar2,
                      ps_parent_id  IN varchar2,
                      ps_lang_cd    IN varchar2,
                      pc_ref        OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getTaxPaymentInfo
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : return list of payments with options
*******************************************************************************/
FUNCTION getTaxPaymentInfo(ps_customer_id IN varchar2,
                          ps_tax_type_id  IN varchar2,
                          ps_start_date   IN varchar2,
                          ps_end_date     IN varchar2,
                          ps_tx_no        IN varchar2,
                          pc_ref          OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION GetPaymentById 
    Prepared By : Almas Nurkhozhayev
    Date:       : 14.11.2014
    Base Project: CQ001098 - Printing of cheques about made instant payments in Internet Banking
    Purpose     : return the only record for instant payment
*******************************************************************************/
FUNCTION GetPaymentById(ps_tx_no  IN varchar2,
                        pc_ref    OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getCreditCardOverdueReport
    Prepared By : Almas Nukrhozhayev
    Date:       : 04.06.2015
    Base Project : CQDB4768 - Automatically loading report  from card system to CBS every day
    Purpose     : Get credit card overdue report
*******************************************************************************/
FUNCTION getCreditCardOverdueReport(ps_date IN varchar2,
                                    pc_ref  OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION getNotificationInfo
    Prepared By : Adilet Kachkeev
    Date:       : 06.03.2015
    Base Project: CQ00867 - E-mail Notification
    Purpose     : get customer notification preferences
*******************************************************************************/
FUNCTION getNotificationInfo(ps_customerid      IN varchar2,
                        pc_ref         OUT CursorReferenceType) return varchar2;                               

/*******************************************************************************
    Name        : FUNCTION getWsDealerInfo
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Get information about dealer
*******************************************************************************/
FUNCTION getWsDealerInfo(ps_company_id IN varchar2,
                         ps_dealer_id IN varchar2,
                         pc_ref OUT CursorReferenceType) return varchar2;

/*******************************************************************************
    Name        : FUNCTION isDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Check if dealer payment
*******************************************************************************/
FUNCTION isDealerPayment(ps_company_id IN varchar2) return NUMBER;

/*******************************************************************************
    Name        :getCorrespondentBank
    Prepared By :Chyngyz Omurov
    Date:       :22.02.2015
    Base Project : cq509
    Purpose     :to get the correspondent bank details for given properties of swift transfer
*******************************************************************************/
FUNCTION getCorrespondentBank(pn_customer_no NUMBER, 
                            ps_currency VARCHAR2, 
                            ps_commBank VARCHAR2, 
                            pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 ;

/*******************************************************************************
    Name:   getPaymentCodesCIB
    Prepared By:    Chyngyz Omurov
    Date:   24.02.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    get the payment codes for Corp IB
*******************************************************************************/
FUNCTION getPaymentCodesCIB(pn_group_code NUMBER, 
                             ps_lang VARCHAR2, 
                             pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 ;
                             
/*******************************************************************************
    Name:   getSwiftValueDate
    Prepared By:    Chyngyz Omurov
    Date:   04.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:   get the earliest value date for swift (according to customer group: special or standard)
*******************************************************************************/
FUNCTION getSwiftValueDate(pn_customer_id NUMBER,
                                                    pn_person_id NUMBER,
                                                    ps_date_selected VARCHAR2, --'DD/MM/YYYY'
                                                    ps_check VARCHAR2 DEFAULT 'N',
                                                    ps_currency VARCHAR2,
                                                    ps_commBank VARCHAR2, --B O G (ben, our, gour)
                                                    ps_value_date OUT VARCHAR2
                                                    ) RETURN VARCHAR2;   

/*******************************************************************************
    Name:   getAttachedFileSwift
    Prepared By:    Chyngyz Omurov
    Date:   12.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - return name of the contract/invoice file uploaded by the customer for swift operation
                     - check if the user is authorized to view attachments
*******************************************************************************/
FUNCTION getAttachedFileSwift(pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_txno VARCHAR2, 
                                            ps_filename OUT VARCHAR2
                                           ) RETURN VARCHAR2;
                                           
/*******************************************************************************
    Name:   validateInterBankCode
    Prepared By:    Chyngyz Omurov
    Date:   12.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - validate intermediary bank bic code
*******************************************************************************/
FUNCTION validateInterBankCode(ps_bic_code VARCHAR2, 
                               ps_dummy OUT VARCHAR2
                                           ) RETURN VARCHAR2;                                                  

/*******************************************************************************
    Name:   fileUploadRequired
    Prepared By:    Chyngyz Omurov
    Date:   27.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - decide whether customer must upload contract/invoice file or not
*******************************************************************************/
FUNCTION fileUploadRequired(pn_customer_id NUMBER,
                                                     ps_amount VARCHAR2, --cq5548 ChyngyzO 14.06.2016
                                                     ps_currency VARCHAR2,
                                                     ps_ben_account VARCHAR2,
                                                     ps_required OUT VARCHAR2 --'Y', or 'N'
                                           ) RETURN VARCHAR2;          
                                           
/******************************************************************************
 NAME : FUNCTION CheckBalance
 Prepared By : Chyngyz Omurov, cq509
 Date : 22.06.2015
 Purpose : Check balance with currency
******************************************************************************/
FUNCTION CheckBalance(pn_accNo IN VARCHAR2,
                                            ps_amount IN VARCHAR2, --cq5548 ChyngyzO 14.06.2016
                                            ps_currency IN VARCHAR2,
                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
 NAME : PROCEDURE GetSwiftCommissionRates
 Prepared By : Chyngyz Omurov, cq509
 Date : 03.08.2015
 Purpose : Returns customer's swift commissions in CIB
******************************************************************************/
PROCEDURE GetSwiftCommissionRates(pn_customer_id NUMBER,
                                                             ps_account_no NUMBER,
                                                             ps_currency VARCHAR2,
                                                          
                                                             ps_modul_tur VARCHAR2,
                                                             ps_product_type VARCHAR2,
                                                             ps_product_class VARCHAR2,
                                                             
                                                             pn_const OUT NUMBER,
                                                             pn_prop OUT NUMBER,
                                                             pn_min OUT NUMBER,
                                                             pn_max OUT NUMBER,
                                                             
                                                             pn_cdf OUT NUMBER);
/******************************************************************************
 NAME : FUNCTION GetInterBankName
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns name of the intermediary bank 
******************************************************************************/
FUNCTION GetInterBankName(ps_ii_bic VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
 NAME : FUNCTION GetSwiftBenBankBranch
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns branch of the beneficiary bank 
******************************************************************************/
FUNCTION GetSwiftBenBankBranch(pn_tx_no NUMBER) RETURN VARCHAR2;

/******************************************************************************
 NAME : FUNCTION GetSwiftCommissionType
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns commission type 'B', 'O', 'G' (BEN, OUR, GUARANTEED OUR, respectively)
******************************************************************************/
FUNCTION GetSwiftCommissionType(pn_tx_no NUMBER) RETURN VARCHAR2;      

/******************************************************************************
 NAME : FUNCTION GetSwiftMessage
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns SWIFT message generated by SWIFT system (skyjava)
******************************************************************************/
FUNCTION GetSwiftMessage(ps_tx_no VARCHAR2,
                         ps_cust_no VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                                            
--BOM CQ5453 MederT 30052016 
/*******************************************************************************
    Name        : FUNCTION getCreditCardsOwned
    Prepared By : Adilet Kachkeev
    Date:       : 18.07.2014
    Base Project : CQDB1415 - Credit Card Calculator
    Purpose     : To get all credit cards owned by specified customer
*******************************************************************************/
FUNCTION getCreditCardsOwned(   ps_customer_id      IN varchar2,
                                pc_ref              OUT CursorReferenceType) return varchar2;
                                
/*******************************************************************************
    Name        : PROCEDURE AutoCreditCardDebtPayment
    Prepared By : Meder Toitonov
    Date:       : 30.05.2016
    Base Project: CQDB 5453 Automatic payment of credit card debt
    Purpose     : Checks CCard debt and performs payment of this debt
*******************************************************************************/
PROCEDURE AutoCreditCardDebtPayment(pn_account_no IN NUMBER);
--EOM CQ5453 MederT 30052016                  


/******************************************************************************
    Name: Check_B2b_Status
    Desc: Checking status of the b2b transaction (for Mobilnik)
    Prepared By:Chyngyz Omurov 
    Modify Date: 06.06.2016
******************************************************************************/
                                                                
FUNCTION Check_B2b_Status(pn_custno NUMBER, ps_reference_no VARCHAR2) RETURN VARCHAR2;

/*******************************************************************************
    Prepared By : Almas Nurkhozhayev
    Date:       : 09.03.2016
    Purpose     : get the list of transaction definitions with explanation
*******************************************************************************/
FUNCTION getIslemList(ps_islem_no IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) return VARCHAR2;


/*******************************************************************************
    Name        : FUNCTION getCompanyStaff
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get staff of the company
*******************************************************************************/
FUNCTION getCompanyStaff( pn_customer_no NUMBER,
                                                    pn_group_id NUMBER,
                                                   pc_ref OUT CursorReferenceType) return VARCHAR2;

/*******************************************************************************
    Name        : FUNCTION getSalaryCurrency
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get salary currency of the company
*******************************************************************************/
FUNCTION getSalaryCurrency( pn_customer_no NUMBER,
                                                     pc_ref OUT CursorReferenceType) return VARCHAR2;

/*******************************************************************************
    Name        : FUNCTION checkEmployeeAccount
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Check account of the employee (currency, active/not active, name/surname, etc)
*******************************************************************************/
FUNCTION checkEmployeeAccount(  pn_customer_no NUMBER,
                                                                ps_name VARCHAR2,
                                                                ps_surname VARCHAR2,
                                                                ps_account_no VARCHAR2, --external account no
                                                                pc_ref OUT CursorReferenceType) return VARCHAR2;      

/*******************************************************************************
    Name        : FUNCTION getSalaryCommType
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get salary commission type of the company
*******************************************************************************/
FUNCTION getSalaryCommType( pn_customer_no NUMBER,
                                                         pc_ref OUT CursorReferenceType) return VARCHAR2;

/*******************************************************************************
    Name        : FUNCTION getSalaryFirmID
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get firm ID of the salary company
*******************************************************************************/
FUNCTION getSalaryFirmID( pn_customer_no NUMBER,
                                                  pc_ref OUT CursorReferenceType) return VARCHAR2;
                                                  
/*******************************************************************************
    Name        : FUNCTION checkSalaryValueDate
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Check value date
*******************************************************************************/
FUNCTION checkSalaryValueDate( ps_date_selected VARCHAR2,
                                                           ps_value_date OUT VARCHAR2) return VARCHAR2;                                                  
                                                           
/*******************************************************************************
    Name        : FUNCTION getSalaryPaymentDetails
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get Staff List of the given salary payment
*******************************************************************************/
FUNCTION getSalaryPaymentDetails( pn_todo_txno NUMBER,
                                                    pn_person_id NUMBER,
                                                    pn_customer_no NUMBER,
                                                    pc_ref OUT CursorReferenceType) return VARCHAR2;                  
                                                    
                                                    
/*******************************************************************************
    Name        : FUNCTION getSalaryArchive
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of past salary payments
*******************************************************************************/
FUNCTION getSalaryArchive( pn_customer_no NUMBER,
                                                  pc_ref OUT CursorReferenceType) return VARCHAR2;                                                             



/*******************************************************************************
    Name        : FUNCTION getSalaryGroupStaff
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of staff group
*******************************************************************************/
FUNCTION getSalaryGroupStaff( pn_customer_no NUMBER,                                                         
                                                         pn_group_id NUMBER,
                                                         ps_group_name VARCHAR2,
                                                         ps_group_staff VARCHAR2,
                                                         ps_action VARCHAR2,
                                                         pn_person_id NUMBER,
                                                        pc_ref          OUT CursorReferenceType,
                                                        pc_ref2      OUT CursorReferenceType,
                                                        pc_ref3      OUT CursorReferenceType,
                                                        pc_ref4      OUT CursorReferenceType,
                                                        pc_ref5      OUT CursorReferenceType) return VARCHAR2;        
                                                        
/*******************************************************************************
    Name        : FUNCTION getSalaryGroups
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of  salary groups
*******************************************************************************/
FUNCTION getSalaryGroups( pn_customer_no NUMBER,
                          pc_ref OUT CursorReferenceType ) return VARCHAR2;
                          
/******************************************************************************
   NAME        : FUNCTION GetTimeDepReturnInterest
   Prepared By : Temirlan Talapkerov
   Date        : 11.01.2021
   Purpose     : Return of previosly paid interest amount
******************************************************************************/
FUNCTION  GetTimeDepReturnInterest(p_accountid IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION INQUIRYSWIFTINVOICES
   Prepared By : Azat Dzhanybekov
   Date        : 03.03.2021
   Purpose     : Returns swift invoices
******************************************************************************/
FUNCTION INQUIRYSWIFTINVOICES (
    PS_CUSTOMER_ID           IN        VARCHAR2,
    PS_VALUEDATE_START      IN        VARCHAR2,
    PS_VALUEDATE_END          IN        VARCHAR2,
    PS_DEBIT_ACCOUNT_NO      IN        VARCHAR2,
    PS_CREDIT_ACCOUNT_NO   IN        VARCHAR2,
    PS_AMOUNT                  IN        VARCHAR2,
    PS_STATUS                  IN        VARCHAR2,
    PC_REF                          OUT CURSORREFERENCETYPE
)
    RETURN VARCHAR2;
/*******************************************************************************
    Name:   get payment  code name
    Prepared By:    Omurchiev Esen
    Date:   31.05.2021
    Base Project:   CQ509 - SWIFTINPUL 
    Purpose:    get the payment code name for Colla swift_txt
*******************************************************************************/
FUNCTION getPaymentCodeName(id_payment NUMBER,pn_payment_code NUMBER,
                                                   pc_ref OUT CursorReferenceType)  RETURN VARCHAR2 ;    
/******************************************************************************
NAME        : FUNCTION Check_Inn_Phone
Prepared By : Temirlan Talapkerov
Date        : 11.03.2021
Purpose     : If the phone number is correct, need to return the customer number and full name
******************************************************************************/

FUNCTION Check_Inn_Phone(ps_inn_no varchar2,
                            ps_phone_number varchar2,
                            ps_code_country varchar2,
                            ps_code_operator varchar2,
                            pn_customer_no OUT number,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2; 
/******************************************************************************
NAME        : FUNCTION Check_Join_acount
Prepared By : Omurchiev Esen
Date        : 21.05.2021
Purpose     : if the client has joint accounts we return false otherwise true
******************************************************************************/
FUNCTION Check_Join_account(pn_customer_no in number,
                                                result_card OUT varchar2) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetAllAdditionalAccounts
   Prepared By : Esen Omurchiev
   Date        : 02.12.2021
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetAllAdditionalAccounts(p_option IN VARCHAR2,
                      p_customerid IN VARCHAR2,
                      p_personid  IN VARCHAR2,
                      p_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetAllAdditionalTranAccounts
   Prepared By : Esen Omurchiev
   Date        : 29.11.2021
   Purpose     : Get Customer Get All Additionl Tran Accounts
******************************************************************************/
FUNCTION GetAllAdditionalTranAccounts(pn_musteri_no IN VARCHAR2,
                          ps_currcode IN VARCHAR2,
                         pn_person_id  IN VARCHAR2,
                         pn_channel_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetAllAdditionalForCCPayments
   Prepared By : Esen Omurchiev
   Date        : 02.12.2021
   Purpose     : Get All Additional For CCPayments - cq8574
******************************************************************************/
FUNCTION GetAllAdditionalForCCPayments(ps_customer_id IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION GetAllAdditionalForUsipPayments
   Prepared By : Omurchiev Esen
   Date        : 02.12.2021
   Purpose     : Get All Additional For Usip Payments 
******************************************************************************/
FUNCTION GetAllAdditionalForUsipPayments(pn_musteri_no IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2; 
/******************************************************************************
   NAME        : FUNCTION SwiftCountryName
   Prepared By : Esen Omurchiev
   Date        : 12.01.2010
   Purpose     : Swift Country Name
******************************************************************************/
FUNCTION SwiftCountryNameForIB(ps_customer_no      IN VARCHAR2,
                          ps_currency      IN VARCHAR2,
                          ps_type      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION CheckSwiftCountry
   Prepared By : Esen Omurchiev
   Date        : 12.01.2010
   Purpose     : check Swift Country 
******************************************************************************/
FUNCTION checkSwiftCountry(ps_customer_no      IN VARCHAR2,
                          result OUT varchar2) RETURN VARCHAR2;     
/******************************************************************************
   NAME        : FUNCTION Active_GetHesapNoFromExternal
   Prepared By : Adil Kamchibekov
   Date        : 12.01.2010
   Purpose     :CBS-731
******************************************************************************/                                               
FUNCTION Active_GetHesapNoFromExternal(ps_externalno VARCHAR2, ps_dvz varchar2) RETURN NUMBER ; -- CBS-731  ADILK  
/******************************************************************************
   NAME        : FUNCTION Active_External_HesapNo_Al
   Prepared By : Adil Kamchibekov
   Date        : 12.01.2010
   Purpose     :CBS-731
******************************************************************************/   
FUNCTION Active_External_HesapNo_Al(pn_hesap_no NUMBER) RETURN NUMBER; -- CBS-731  ADILK                                     
END Pkg_Soa_Inquiry;
/

