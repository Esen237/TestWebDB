create PACKAGE BODY     PKG_RAPOR_IZLEME IS

  Function sf_dil_al RETURN varchar2
	is
	begin
	return 'TUR';
  END ;

  Procedure sp_cbs_rapor_islem_kayit_ata(ps_rapor_kodu varchar2,
  									     pn_islem_no  number ,
 		   							     ps_1_alan_adi varchar2 default null,
										 ps_1_degeri   varchar2 default null,
										 ps_2_alan_adi varchar2 default null,
										 ps_2_degeri   varchar2 default null ,
										 ps_3_alan_adi varchar2 default null,
										 ps_3_degeri   varchar2 default null,
										 ps_4_alan_adi varchar2 default null,
										 ps_4_degeri   varchar2 default null,
										 ps_5_alan_adi varchar2 default null,
										 ps_5_degeri   varchar2 default null,
										 ps_6_alan_adi varchar2 default null,
										 ps_6_degeri   varchar2 default null,
										 ps_7_alan_adi varchar2 default null,
										 ps_7_degeri   varchar2 default null,
										 ps_8_alan_adi varchar2 default null,
										 ps_8_degeri   varchar2 default null,
										 ps_9_alan_adi varchar2 default null,
										 ps_9_degeri   varchar2 default null,
										 ps_10_alan_adi varchar2 default null,
										 ps_10_degeri   varchar2 default null,
										 ps_11_alan_adi varchar2 default null,
										 ps_11_degeri   varchar2 default null,
										 ps_12_alan_adi varchar2 default null,
										 ps_12_degeri   varchar2 default null ,
										 ps_13_alan_adi varchar2 default null,
										 ps_13_degeri   varchar2 default null,
										 ps_14_alan_adi varchar2 default null,
										 ps_14_degeri   varchar2 default null,
										 ps_15_alan_adi varchar2 default null,
										 ps_15_degeri   varchar2 default null,
										 ps_16_alan_adi varchar2 default null,
										 ps_16_degeri   varchar2 default null,
										 ps_17_alan_adi varchar2 default null,
										 ps_17_degeri   varchar2 default null,
										 ps_18_alan_adi varchar2 default null,
										 ps_18_degeri   varchar2 default null,
										 ps_19_alan_adi varchar2 default null,
										 ps_19_degeri   varchar2 default null,
										 ps_20_alan_adi varchar2 default null,
										 ps_20_degeri   varchar2 default null
										 ) is pragma autonomous_transaction;

     cursor cur_rapor is
    	   select
	   		  p_1_alan_adi,
			  p_1_degeri,
			  p_2_alan_adi,
			  p_2_degeri,
			  p_3_alan_adi,
			  p_3_degeri,
			  p_4_alan_adi,
			  p_4_degeri,
			  p_5_alan_adi,
			  p_5_degeri,
			  p_6_alan_adi,
			  p_6_degeri,
			  p_7_alan_adi,
			  p_7_degeri,
			  p_8_alan_adi,
			  p_8_degeri,
			  p_9_alan_adi,
			  p_9_degeri,
			  p_10_alan_adi,
			  p_10_degeri,
			  p_11_alan_adi,
			  p_11_degeri,
			  p_12_alan_adi,
			  p_12_degeri,
			  p_13_alan_adi,
			  p_13_degeri,
			  p_14_alan_adi,
			  p_14_degeri,
			  p_15_alan_adi,
			  p_15_degeri,
			  p_16_alan_adi,
			  p_16_degeri,
			  p_17_alan_adi,
			  p_17_degeri,
			  p_18_alan_adi,
			  p_18_degeri,
			  p_19_alan_adi,
			  p_19_degeri,
			  p_20_alan_adi,
			  p_20_degeri
	   from cbs_rapor_parametre
	   where rapor_kodu =ps_rapor_kodu and
	   		 dil  = sf_dil_al;

		c_rapor	 cur_rapor%rowtype;
  Begin

   for c1_rapor in cur_rapor loop
     c_rapor := c1_rapor ;
	end loop;

	   insert into cbs_rapor_islem
	   (       islem_no,
			   rapor_kodu,
			   banka_tarihi,
			   yaratan_kullanici_kodu,
			   p_1_alan_adi,
			   p_1_degeri,
			   p_2_alan_adi,
			   p_2_degeri,
			   p_3_alan_adi,
			   p_3_degeri,
			   p_4_alan_adi,
			   p_4_degeri,
			   p_5_alan_adi,
			   p_5_degeri,
			   p_6_alan_adi,
			   p_6_degeri,
			   p_7_alan_adi,
			   p_7_degeri,
			   p_8_alan_adi,
			   p_8_degeri,
			   p_9_alan_adi,
			   p_9_degeri,
			   p_10_alan_adi,
			   p_10_degeri,
			   p_11_alan_adi,
			   p_11_degeri,
			   p_12_alan_adi,
			   p_12_degeri,
			   p_13_alan_adi,
			   p_13_degeri,
			   p_14_alan_adi,
			   p_14_degeri,
			   p_15_alan_adi,
			   p_15_degeri,
			   p_16_alan_adi,
			   p_16_degeri,
			   p_17_alan_adi,
			   p_17_degeri,
			   p_18_alan_adi,
			   p_18_degeri,
			   p_19_alan_adi,
			   p_19_degeri,
			   p_20_alan_adi,
			   p_20_degeri,
			   dil)
		values
			   (
			   pn_islem_no,
			   ps_rapor_kodu,
			   pkg_muhasebe.banka_tarihi_bul,
			   nvl(pkg_baglam.kullanici_kodu,user),
			   nvl(ps_1_alan_adi,c_rapor.p_1_alan_adi),
			   nvl(ps_1_degeri, c_rapor.p_1_degeri),
			   nvl(ps_2_alan_adi, c_rapor.p_2_alan_adi),
			   nvl(ps_2_degeri,	c_rapor.p_2_degeri),
			   nvl(ps_3_alan_adi, c_rapor.p_3_alan_adi),
			   nvl(ps_3_degeri, c_rapor.p_3_degeri),
			   nvl(ps_4_alan_adi,c_rapor.p_4_alan_adi),
			   nvl(ps_4_degeri, c_rapor.p_4_degeri),
			   nvl(ps_5_alan_adi,c_rapor.p_5_alan_adi),
			   nvl(ps_5_degeri, c_rapor.p_5_degeri),
			   nvl(ps_6_alan_adi,c_rapor.p_6_alan_adi),
			   nvl(ps_6_degeri, c_rapor.p_6_degeri),
			   nvl(ps_7_alan_adi,c_rapor.p_7_alan_adi),
			   nvl(ps_7_degeri, c_rapor.p_7_degeri),
			   nvl(ps_8_alan_adi,c_rapor.p_8_alan_adi),
			   nvl(ps_8_degeri, c_rapor.p_8_degeri),
			   nvl(ps_9_alan_adi,c_rapor.p_9_alan_adi),
			   nvl(ps_9_degeri, c_rapor.p_9_degeri),
			   nvl(ps_10_alan_adi,c_rapor.p_10_alan_adi),
			   nvl(ps_10_degeri, c_rapor.p_10_degeri),
			   nvl(ps_11_alan_adi,c_rapor.p_11_alan_adi),
			   nvl(ps_11_degeri, c_rapor.p_11_degeri),
			   nvl(ps_12_alan_adi,c_rapor.p_12_alan_adi),
			   nvl(ps_12_degeri, c_rapor.p_12_degeri),
			   nvl(ps_13_alan_adi,c_rapor.p_13_alan_adi),
			   nvl(ps_13_degeri, c_rapor.p_13_degeri),
			   nvl(ps_14_alan_adi,c_rapor.p_14_alan_adi),
			   nvl(ps_14_degeri, c_rapor.p_14_degeri),
			   nvl(ps_15_alan_adi,c_rapor.p_15_alan_adi),
			   nvl(ps_15_degeri, c_rapor.p_15_degeri),
			   nvl(ps_16_alan_adi,c_rapor.p_16_alan_adi),
			   nvl(ps_16_degeri, c_rapor.p_16_degeri),
			   nvl(ps_17_alan_adi,c_rapor.p_17_alan_adi),
			   nvl(ps_17_degeri, c_rapor.p_17_degeri),
			   nvl(ps_18_alan_adi,c_rapor.p_18_alan_adi),
			   nvl(ps_18_degeri, c_rapor.p_18_degeri),
			   nvl(ps_19_alan_adi,c_rapor.p_19_alan_adi),
			   nvl(ps_19_degeri, c_rapor.p_19_degeri),
			   nvl(ps_20_alan_adi,c_rapor.p_20_alan_adi),
			   nvl(ps_20_degeri, c_rapor.p_20_degeri),
			   sf_dil_al
			);
		commit;
   exception
     when no_data_found then null;
	 when others then
	   	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '815' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;

 procedure sp_rapor_degerlerini_al      (pn_islem_no number,
 		   								 ps_rapor_kodu out varchar2 ,
										 ps_rapor_adi out varchar2 ,
 		   							     ps_1_alan_adi out varchar2 ,
										 ps_1_degeri   out varchar2 ,
										 ps_2_alan_adi out varchar2 ,
										 ps_2_degeri   out varchar2  ,
										 ps_3_alan_adi out varchar2 ,
										 ps_3_degeri   out varchar2 ,
										 ps_4_alan_adi out varchar2 ,
										 ps_4_degeri   out varchar2 ,
										 ps_5_alan_adi out varchar2 ,
										 ps_5_degeri   out varchar2 ,
										 ps_6_alan_adi out varchar2 ,
										 ps_6_degeri   out varchar2 ,
										 ps_7_alan_adi out varchar2 ,
										 ps_7_degeri   out varchar2 ,
										 ps_8_alan_adi out varchar2 ,
										 ps_8_degeri   out varchar2 ,
										 ps_9_alan_adi out varchar2 ,
										 ps_9_degeri   out varchar2 ,
										 ps_10_alan_adi out varchar2,
										 ps_10_degeri   out varchar2,
										 ps_11_alan_adi out varchar2,
										 ps_11_degeri   out varchar2,
										 ps_12_alan_adi out varchar2,
										 ps_12_degeri   out varchar2,
										 ps_13_alan_adi out varchar2,
										 ps_13_degeri   out varchar2,
										 ps_14_alan_adi out varchar2,
										 ps_14_degeri   out varchar2,
										 ps_15_alan_adi out varchar2,
										 ps_15_degeri   out varchar2,
										 ps_16_alan_adi out varchar2,
										 ps_16_degeri   out varchar2,
										 ps_17_alan_adi out varchar2,
										 ps_17_degeri   out varchar2,
										 ps_18_alan_adi out varchar2,
										 ps_18_degeri   out varchar2,
										 ps_19_alan_adi out varchar2,
										 ps_19_degeri   out varchar2,
										 ps_20_alan_adi out varchar2,
										 ps_20_degeri   out varchar2)
 is
 Begin
   if   pn_islem_no is not null then
		 	    select
					   rapor_kodu,
					   UPPER(pkg_genel.rapor_adi_al(rapor_kodu)),
					   p_1_alan_adi,
					   p_1_degeri,
					   p_2_alan_adi,
					   p_2_degeri,
					   p_3_alan_adi,
					   p_3_degeri,
					   p_4_alan_adi,
					   p_4_degeri,
					   p_5_alan_adi,
					   p_5_degeri,
					   p_6_alan_adi,
					   p_6_degeri,
					   p_7_alan_adi,
					   p_7_degeri,
					   p_8_alan_adi,
					   p_8_degeri,
					   p_9_alan_adi,
					   p_9_degeri,
					   p_10_alan_adi,
					   p_10_degeri,
					   p_11_alan_adi,
					   p_11_degeri,
					   p_12_alan_adi,
					   p_12_degeri,
					   p_13_alan_adi,
					   p_13_degeri,
					   p_14_alan_adi,
					   p_14_degeri,
					   p_15_alan_adi,
					   p_15_degeri,
					   p_16_alan_adi,
					   p_16_degeri,
					   p_17_alan_adi,
					   p_17_degeri,
					   p_18_alan_adi,
					   p_18_degeri,
					   p_19_alan_adi,
					   p_19_degeri,
					   p_20_alan_adi,
					   p_20_degeri
				into   ps_rapor_kodu,
					   ps_rapor_adi,
			           ps_1_alan_adi,
					   ps_1_degeri,
					   ps_2_alan_adi,
					   ps_2_degeri,
					   ps_3_alan_adi,
					   ps_3_degeri,
					   ps_4_alan_adi,
					   ps_4_degeri,
					   ps_5_alan_adi,
					   ps_5_degeri,
					   ps_6_alan_adi,
					   ps_6_degeri,
					   ps_7_alan_adi,
					   ps_7_degeri,
					   ps_8_alan_adi,
					   ps_8_degeri,
					   ps_9_alan_adi,
					   ps_9_degeri,
					   ps_10_alan_adi,
					   ps_10_degeri,
					   ps_11_alan_adi,
					   ps_11_degeri,
					   ps_12_alan_adi,
					   ps_12_degeri,
					   ps_13_alan_adi,
					   ps_13_degeri,
					   ps_14_alan_adi,
					   ps_14_degeri,
					   ps_15_alan_adi,
					   ps_15_degeri,
					   ps_16_alan_adi,
					   ps_16_degeri,
					   ps_17_alan_adi,
					   ps_17_degeri,
					   ps_18_alan_adi,
					   ps_18_degeri,
					   ps_19_alan_adi,
					   ps_19_degeri,
					   ps_20_alan_adi,
					   ps_20_degeri
		  		from cbs_rapor_islem
				where islem_no = pn_islem_no ;

 end if;
 End;
 Function sf_dil_adi_al (ps_dil varchar2 ) return varchar2
 is
 ls_aciklama varchar2(2000);
 Begin
 	  select aciklama
	  into ls_aciklama
	  from cbs_dil_kodlari
	  where dil_kodu = ps_dil ;

	 return ls_aciklama;
  Exception when others then return null;
 End;

 Procedure Write2File(ps_dizin varchar2 default 'c:\cbs\dosya', ps_filename IN VARCHAR2, ps_inputtext IN VARCHAR2)
 is
	 f	  utl_file.file_type;
 BEGIN

	 f:=utl_file.fopen(ps_dizin,ps_filename,'w',2100);
	 utl_file.put(f, ps_inputtext);
	 utl_file.fclose(f);

 END;

 Procedure  tcmb_cek_karsiz_dosya_olustur (ps_filename  out varchar2)
 is
  cursor c_01 is
   select text
     from cbs_vw_tcmb_cek_karsiliksiz;

  r_01 c_01%rowtype;
  ls_str varchar2(2000);
  ls_ext varchar2(3) ;
  ls_file varchar2(2000);
  ld_tarih date :=sysdate;
 begin

  ls_file := to_char(ld_tarih, 'YY') || to_char(ld_tarih, 'MM')
                    || to_char(ld_tarih, 'DD') || '00kc' ;

  delete from cbs_tcmb_cek_bildirim  where file_name = ls_file;

  if c_01%isopen then
    close c_01;
  end if;

  open c_01;
  loop
    fetch c_01 into r_01;
	exit when c_01%notfound;
		insert into cbs_tcmb_cek_bildirim (file_name, text,banka_tarihi)
		values (ls_file, r_01.text,pkg_muhasebe.banka_tarihi_bul);
  end loop;

  commit;
  close c_01;

   ps_filename := ls_file;

  Exception
	  when no_data_found then null;
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '920' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

 end;
Procedure  tcmb_cek_hesap_dosya_olustur (ps_filename  out varchar2)
is
  cursor c_01 is
   select text
     from cbs_vw_tcmb_cek_hesap;

  r_01 c_01%rowtype;
  ls_str varchar2(2000);
  ls_ext varchar2(3) ;
  ls_file varchar2(2000);
  ld_tarih date :=sysdate;
 begin

  ls_file := to_char(ld_tarih, 'YY') || to_char(ld_tarih, 'MM')
                    || to_char(ld_tarih, 'DD') || '00ch' ;


  delete from cbs_tcmb_cek_bildirim  where file_name = ls_file;

  if c_01%isopen then
    close c_01;
  end if;

  open c_01;
  loop
    fetch c_01 into r_01;
	exit when c_01%notfound;
		insert into cbs_tcmb_cek_bildirim (file_name, text,banka_tarihi)
		values (ls_file, r_01.text,pkg_muhasebe.banka_tarihi_bul);
  end loop;

  commit;
  close c_01;
    ps_filename := ls_file;
	Exception
	  when no_data_found then null;
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '921' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

 end;


END;
/

