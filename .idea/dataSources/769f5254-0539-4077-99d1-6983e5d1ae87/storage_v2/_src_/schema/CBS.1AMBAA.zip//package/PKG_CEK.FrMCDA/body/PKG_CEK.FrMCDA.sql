create package body PKG_CEK is

 /*****************************************************************************************************************/
  /*   Procedure sp_cek_urun_sinif_al										  					   	   	   	   */
  /*   cek numarasi gonderilip urun sinif bilgisi alinir													  */
  /*****************************************************************************************************************/
  Procedure sp_cek_urun_sinif_al(pn_cek_no cbs_cek.cek_no%type,
  									 ps_modul_tur_kod out  cbs_islem.modul_tur_kod%type,
  									 ps_urun_tur_kod  out  cbs_islem.urun_tur_kod%type,
									 ps_urun_sinif_kod out cbs_islem.urun_sinif_kod%type)
   is

   Begin

	  select modul_tur_kod, urun_tur_kod,karne_tipi_kodu
	  into   ps_modul_tur_kod,ps_urun_tur_kod,ps_urun_sinif_kod
	  from   cbs_cek
	  where  cek_no = pn_cek_no;

	Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '266' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
   End sp_cek_urun_sinif_al;


 /*****************************************************************************************************************/
 /*   Procedure Sp_Coklu_Cek_Kayit_Yarat												       				      */
 /*   cek karnesi onaylandiktan sonra baglangis,bitis araligindaki cekler yaratilir.						      */
 /*****************************************************************************************************************/

 Procedure Sp_Coklu_Cek_Kayit_Yarat(pn_tx_no in cbs_cek_karne_islem.tx_no%type) is

   lrw_cek_karne_islem      cbs_cek_karne_islem%rowtype;
   ln_cek_no        		cbs_cek.cek_no%type;   -- number :=1;
   ln_min_cekno				cbs_cek.cek_no%type;
   cek_mevcut				exception;
   cursor cur_cek_karne is
     select  *
     from  cbs_cek_karne_islem
     where  tx_no = pn_tx_no;

 Begin

  if cur_cek_karne%isopen then
	   close cur_cek_karne;
  end if;

   Open cur_cek_karne ;
   	 Loop
      fetch cur_cek_karne  into lrw_cek_karne_islem;
         exit when cur_cek_karne%notfound;

    if nvl(lrw_cek_karne_islem.baslangic_cek_no,0) = 0 then
	   select max(cek_no)
	   into  lrw_cek_karne_islem.baslangic_cek_no
	   from	 cbs_cek ;

	   lrw_cek_karne_islem.bitis_cek_no := lrw_cek_karne_islem.baslangic_cek_no + lrw_cek_karne_islem.cek_yaprak_adedi;
	 else
		  ln_cek_no :=  Pkg_Cek.Sf_Cek_Aralik_Kontrol(lrw_cek_karne_islem.baslangic_cek_no,lrw_cek_karne_islem.bitis_cek_no);
		  if nvl(ln_cek_no,0) > 0 then
			 	Raise cek_mevcut;
		  end if;
     end if;
       for ln_cek_no in lrw_cek_karne_islem.baslangic_cek_no..lrw_cek_karne_islem.bitis_cek_no
    	 loop
      	 insert into cbs_cek
		 			 (  cek_no          ,
					    musteri_no      ,
					    hesap_sube_kodu ,
						hesap_no        ,
						doviz_kodu      ,
						durum_kodu      ,
						ref_tx_no		,
					    karne_tipi_kodu  ,
						baslangic_cek_no ,
						bitis_cek_no     ,
						cek_yaprak_adedi ,
						masraf_tutari    ,
						kasa_hesap_secimi,
						masraf_hesap_sube_kodu,
						masraf_hesap_no       ,
						dekont_basim_f        ,
						talep_tarihi          ,
						talep_edilen_karne_adedi,
						karne_giris_tarihi       ,
						girisi_yapilan_karne_adedi,
						teslim_tarihi             ,
						teslim_edilen_karne_adedi ,
						modul_tur_kod,
						urun_tur_kod
 	)
                 values (  ln_cek_no          ,
				 		   lrw_cek_karne_islem.musteri_no,
						   lrw_cek_karne_islem.hesap_sube_kodu ,
						   lrw_cek_karne_islem.hesap_no  ,
						   lrw_cek_karne_islem.doviz_kodu ,
						   lrw_cek_karne_islem.durum_kodu ,
						   lrw_cek_karne_islem.tx_no,
						   lrw_cek_karne_islem.karne_tipi_kodu  ,
						   lrw_cek_karne_islem.baslangic_cek_no ,
						   lrw_cek_karne_islem.bitis_cek_no     ,
						   lrw_cek_karne_islem.cek_yaprak_adedi ,
						   lrw_cek_karne_islem.masraf_tutari    ,
						   lrw_cek_karne_islem.kasa_hesap_secimi,
						   lrw_cek_karne_islem.masraf_hesap_sube_kodu,
						   lrw_cek_karne_islem.masraf_hesap_no       ,
						   lrw_cek_karne_islem.dekont_basim_f        ,
						   lrw_cek_karne_islem.talep_tarihi          ,
						   lrw_cek_karne_islem.talep_edilen_karne_adedi,
						   lrw_cek_karne_islem.karne_giris_tarihi       ,
						   lrw_cek_karne_islem.girisi_yapilan_karne_adedi,
						   lrw_cek_karne_islem.teslim_tarihi             ,
						   lrw_cek_karne_islem.teslim_edilen_karne_adedi,
						   lrw_cek_karne_islem.modul_tur_kod,
						   lrw_cek_karne_islem.urun_tur_kod);
           end loop;
      end loop;
  close    cur_cek_karne;
   Exception
     When no_data_found then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '142' || pkg_hata.getUCPOINTER);
     When cek_mevcut then
  	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '143' ||  pkg_hata.getDelimiter || to_char(ln_cek_no) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
     When others then
  	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '192' ||  pkg_hata.getDelimiter || to_char(sqlcode) || sqlerrm || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

 End sp_coklu_cek_kayit_yarat;


 /*****************************************************************************************************************/
 /*   Procedure  Sp_Tx1105_Cek_Bilgi_Getir													       				   */
 /*   Tx1105 formunda kullanilan cek e ait bilgiler getirilir.													   */
 /*****************************************************************************************************************/
 Procedure Sp_Tx1105_Cek_Bilgi_Getir(pn_cek_no in cbs_cek.cek_no%type ,ps_odeme_yasak_neden_kodu out cbs_cek.odeme_yasak_neden_kodu%type)
  is
    cursor cur_cek_islem is
	  select odeme_yasak_neden_kodu
	  from cbs_cek
	  where cek_no = pn_cek_no ;
  Begin
	if cur_cek_islem%isopen then
	   close cur_cek_islem;
	end if;
    open cur_cek_islem ;

   	 loop
      fetch cur_cek_islem  into ps_odeme_yasak_neden_kodu;
         exit when cur_cek_islem%notfound;
	 end loop;

	close cur_cek_islem ;
  Exception
	When Others Then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '151' || pkg_hata.getUCPOINTER);
  End Sp_Tx1105_Cek_Bilgi_Getir;


 /*****************************************************************************************************************/
 /*   Procedure Sp_Tx1106_Cek_Bilgi_Getir													       				   */
 /*   Tx1106 formunda kullanilan cek'e ait bilgiler getirilir.													   */
 /*****************************************************************************************************************/
  Procedure Sp_Tx1106_Cek_Bilgi_Getir(pn_cek_no in cbs_cek_islem.cek_no%type,
   			    			 pn_hesap_sube_kodu     out  cbs_cek.hesap_sube_kodu%type,
							 pn_hesap_no		    out	 cbs_cek.hesap_no%type,
							 pd_keside_tarihi       out	 cbs_cek.keside_tarihi%type,
							 pd_ibraz_tarihi        out	 cbs_cek.ibraz_tarihi %type,
							 pn_ibraz_edilen_sube   out  cbs_cek.ibraz_edilen_sube%type,
							 pn_cek_tutari          out  cbs_cek.cek_tutari%type,
							 ps_cek_hamili_unvan    out  cbs_cek.cek_hamili_unvan%type,
							 ps_cek_hamili_adres    out  cbs_cek.cek_hamili_adres%type,
							 ps_cek_hamili_semt     out  cbs_cek.cek_hamili_semt%type,
							 ps_cek_hamili_il_kod   out  cbs_cek.cek_hamili_il_kod%type,
							 ps_cek_hamili_posta_kod out cbs_cek.cek_hamili_posta_kod%type,
							 ps_cek_hamili_ulke_kod  out cbs_cek.cek_hamili_ulke_kod%type)
  is
     cursor cur_cek_islem is
	  select hesap_sube_kodu,
			 hesap_no,
			 keside_tarihi,
			 ibraz_tarihi,
			 ibraz_edilen_sube,
			 cek_tutari,
			 cek_hamili_unvan,
			 cek_hamili_adres,
			 cek_hamili_semt,
			 cek_hamili_il_kod,
			 cek_hamili_posta_kod,
			 cek_hamili_ulke_kod
	  from cbs_cek
	  where cek_no = pn_cek_no ;
Begin
	if cur_cek_islem%isopen then
	   close cur_cek_islem;
	end if;
    open cur_cek_islem ;
   	 loop
       fetch cur_cek_islem  into
	   		 pn_hesap_sube_kodu,
			 pn_hesap_no,
			 pd_keside_tarihi,
			 pd_ibraz_tarihi,
			 pn_ibraz_edilen_sube,
			 pn_cek_tutari,
			 ps_cek_hamili_unvan,
			 ps_cek_hamili_adres,
			 ps_cek_hamili_semt,
			 ps_cek_hamili_il_kod,
			 ps_cek_hamili_posta_kod,
			 ps_cek_hamili_ulke_kod;
         exit when cur_cek_islem%notfound;
    end loop;
	close cur_cek_islem ;

   Exception
	 When Others Then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '152' || pkg_hata.getUCPOINTER);
  End Sp_Tx1106_Cek_Bilgi_Getir;

  /*****************************************************************************************************************/
  /*   Function Sf_Cek_Baslangic_No														       				       */
  /*   Girilen cekin uygun baglangisda olup olmadigi kontrol edilir. 10 luk ise 1.11. vb baslamali		   		   */
  /*****************************************************************************************************************/
 Function Sf_Cek_Baslangic_No( pn_baslangic_cek_no cbs_cek_karne_islem.baslangic_cek_no%type , pn_cek_yaprak_adedi cbs_cek_karne_islem.cek_yaprak_adedi%type ) return number
   is
     ln_baslangic_cek_no cbs_cek_karne_islem.bitis_cek_no%type := 1;
   Begin
	   if pn_baslangic_cek_no > 1 then
		  ln_baslangic_cek_no := pn_cek_yaprak_adedi * floor(pn_baslangic_cek_no / pn_cek_yaprak_adedi) + 1 ;
		  if  pn_baslangic_cek_no <> ln_baslangic_cek_no then
			  return -1;
		  end if;
	   end if;
	   return 1;
    End Sf_Cek_Baslangic_No;
  /*****************************************************************************************************************/
  /*   Function  Sf_Karne_Tipi_Yaprak_Adedi														       			   */
  /*   Girilen karne tipinin yaprak adedini geri dondurur.														   */
  /*****************************************************************************************************************/
  Function  Sf_Karne_Tipi_Yaprak_Adedi(ps_karne_tipi_kodu  cbs_cek_karne_tipi_kodlari.karne_tipi_kodu%type)return cbs_cek_karne_tipi_kodlari.yaprak_adedi%type
  is
     ln_yaprak_adedi cbs_cek_karne_tipi_kodlari.yaprak_adedi%type := 0;
  Begin
	  select yaprak_adedi
	  into ln_yaprak_adedi
	  from cbs_cek_karne_tipi_kodlari
	  where karne_tipi_kodu = ps_karne_tipi_kodu ;

	 return ln_yaprak_adedi ;

  Exception
	When Others Then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '134' || pkg_hata.getUCPOINTER);
  End Sf_Karne_Tipi_Yaprak_Adedi;

  /*****************************************************************************************************************/
  /*   Function  Sf_Cek_Aralik_Kontrol														       				   */
  /*   Girilen cek araliginda aktif cek olup olmadigi kontrol edilir									           */
  /*****************************************************************************************************************/
   Function  Sf_Cek_Aralik_Kontrol(pn_baslangic_cek_no  cbs_cek.cek_no%type,pn_bitis_cek_no  cbs_cek.cek_no%type) return number
   is
     ln_cekno number := 0;
   Begin

	  select min(cek_no)
	  into ln_cekno
	  from cbs_cek
	  where cek_no between  pn_baslangic_cek_no and pn_bitis_cek_no;


    return ln_cekno;

   Exception
   	When no_data_found then return 0 ;
	When Others Then
	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '265' || pkg_hata.getUCPOINTER);

   End Sf_Cek_Aralik_Kontrol;

  /*****************************************************************************************************************/
  /*   Function  Sf_Karne_Aralik_Kontrol															       		   */
  /*   Girilen karne araliginda aktif karne olup olmadigi kontrol edilir									       */
  /*****************************************************************************************************************/
   Function  Sf_Karne_Aralik_Kontrol(pn_baslangic_cek_no  cbs_cek.cek_no%type,pn_bitis_cek_no  cbs_cek.cek_no%type) return number
   is
     ln_adet number := 0;
	 cek_karne_mevcut exception;
   Begin

	  select count(*)
	  into ln_adet
	  from cbs_cek_karne_islem
	  where ((pn_baslangic_cek_no between  baslangic_cek_no and bitis_cek_no) or
	  		(pn_bitis_cek_no between  baslangic_cek_no and bitis_cek_no) );


	  if ln_adet > 0 then
	    Raise cek_karne_mevcut;
	 else
	    return 0 ;
      end if;
   Exception
   	When no_data_found then return 0 ;
	When cek_karne_mevcut Then
	  	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '144' || pkg_hata.getUCPOINTER);

   End Sf_Karne_Aralik_Kontrol;

  /*****************************************************************************************************************/
  /*   Function  Sf_Odeme_Yasak_Neden_Kodu															       		   */
  /*   odeme yasaginin aciklamasi getirilir																		   */
  /*****************************************************************************************************************/
  Function  Sf_Odeme_Yasak_Neden_Kodu(ps_odeme_yasak_neden_kodu in cbs_cek_odeme_yasak_kodlari.odeme_yasak_neden_kodu%type) return cbs_cek_odeme_yasak_kodlari.aciklama%type is
  ls_odeme_aciklama cbs_cek_odeme_yasak_kodlari.aciklama%type ;
  cursor cur_odeme_yasak_neden_kodu is
    select aciklama
	  from cbs_cek_odeme_yasak_kodlari
	 where odeme_yasak_neden_kodu = ps_odeme_yasak_neden_kodu;

  Begin
    if cur_odeme_yasak_neden_kodu%isopen then
	   close cur_odeme_yasak_neden_kodu;
	end if;

	open cur_odeme_yasak_neden_kodu;
	fetch cur_odeme_yasak_neden_kodu into  ls_odeme_aciklama ;
	 if cur_odeme_yasak_neden_kodu%notfound then
	 	close cur_odeme_yasak_neden_kodu;
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '148' || pkg_hata.getUCPOINTER);
	 end if;
	close cur_odeme_yasak_neden_kodu;

	return(ls_odeme_aciklama);

  End Sf_Odeme_Yasak_Neden_Kodu;

  /*****************************************************************************************************************/
  /*   Function	 Sf_Tarih_Format_Degistir																	   */
  /*   tarih formatini  degistirir.*/
  /*****************************************************************************************************************/

  Function	 Sf_Tarih_Format_Degistir(ps_str varchar2)return varchar2
  is
  ls_str varchar2(20);
  Begin

  	select substr(ps_str,7,2) || '/'|| substr(ps_str,5,2) || '/'|| substr(ps_str,1,4)
  	into ls_str
  	from dual ;

  	return ls_str;
  End Sf_Tarih_Format_Degistir;


  /*****************************************************************************************************************/
  /*   Function	 Sf_Onayli_Cek_Talep_Islem_No																	   */
  /*   Cek karne giris (tx1101 ekrani) sirasinda karne tipi  ve hesaba ait onayli minimum talep referans numarasini bulur */
  /*****************************************************************************************************************/
  Function	 Sf_Onayli_Cek_Talep_Islem_No(ps_karne_tipi cbs_cek_karne_islem.karne_tipi_kodu%type ,pn_hesap_no cbs_cek_karne_islem.hesap_no%type ,pn_cek_yaprak_adedi cbs_cek_karne_islem.cek_yaprak_adedi%type)return cbs_cek_karne_islem.tx_no%type
  is
    cursor cur_cek is
	  select min(tx_no)
	  from cbs_cek_karne_islem
	  where  hesap_no = pn_hesap_no and
	   		 durum_kodu = 'A'  and
			 karne_tipi_kodu = ps_karne_tipi  and
			 islem_tanim_kod = 1100 and
			 cek_yaprak_adedi = pn_cek_yaprak_adedi and
			 (   (nvl(talep_edilen_karne_adedi,0)- nvl(girisi_yapilan_karne_adedi,0) > 0  and PKG_PARAMETRE.VARCHAR_AL ( MODUL_TUR_KOD, URUN_TUR_KOD, karne_tipi_kodu,'CON_MU') != 'E')
			   OR
			    (cek_yaprak_adedi > 0  and PKG_PARAMETRE.VARCHAR_AL ( MODUL_TUR_KOD, URUN_TUR_KOD, karne_tipi_kodu,'CON_MU') = 'E'));

    ln_ref_tx_no  cbs_cek_karne_islem.tx_no%type;

  Begin
  LOG_AT('AA',ps_karne_tipi ,pn_cek_yaprak_adedi );
    if cur_cek%isopen then
	   close cur_cek;
	end if;

	open cur_cek;
	fetch cur_cek into ln_ref_tx_no;
	 if cur_cek%notfound then
	 	close cur_cek;
	 end if;
	close cur_cek;
	if nvl(ln_ref_tx_no,0) <= 0 then
  LOG_AT('22',ps_karne_tipi ,pn_cek_yaprak_adedi ,ln_ref_tx_no);
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '175' ||  pkg_hata.getUCPOINTER);
		return 0;
	end if;

	return(ln_ref_tx_no);

   Exception
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '175'|| pkg_hata.getUCPOINTER);

   End  Sf_Onayli_Cek_Talep_Islem_No;

  /*****************************************************************************************************************/
  /*   Function	 Sp_Cek_Yaprak_Adedi																	           */
  /*   Islem numarasindaki Cek talep islemininin cek yaprak adedi bulunur.(1101 ve 1102 formlarindan cagrilir.)								   		   */
  /*****************************************************************************************************************/

    Procedure Sp_Onayli_Cek_Karne_Bitis_No( pn_tx_no cbs_cek_karne_islem.tx_no%type , pn_cek_yaprak_adedi out cbs_cek_karne_islem.cek_yaprak_adedi%type,pn_bitis_cek_no out cbs_cek_karne_islem.bitis_cek_no%type)
   is
   Begin

	  select cek_yaprak_adedi,bitis_cek_no
	  into pn_cek_yaprak_adedi ,pn_bitis_cek_no
	  from cbs_cek_karne_islem
	  where tx_no = pn_tx_no;

   Exception
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '176' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' || SQLERRM  || pkg_hata.getUCPOINTER);

   End Sp_Onayli_Cek_Karne_Bitis_No;

  /*****************************************************************************************************************/
  /*   Function	 Sf_Onayli_Cek_Karne_Islem_No																	   */
  /*   Cek karne teslim giris (tx1102 ekrani) sirasinda karne tipi  ve hesaba ait onayli minimum karne referans numarasini bulur */
  /*****************************************************************************************************************/
   Function	 Sf_Onayli_Cek_Karne_Islem_No(ps_karne_tipi cbs_cek_karne_islem.karne_tipi_kodu%type ,pn_hesap_no cbs_cek_karne_islem.hesap_no%type,pn_baslangic_cek_no cbs_cek_karne_islem.baslangic_cek_no%type)return cbs_cek_karne_islem.baslangic_cek_no%type
  is
    cursor cur_cek is
		select min(tx_no)
		from cbs_cek_karne_islem
		where hesap_no = pn_hesap_no and
			  durum_kodu = 'A'  and
			  teslim_tarihi is null and
			  karne_tipi_kodu =ps_karne_tipi and
   			  baslangic_cek_no = pn_baslangic_cek_no and
			  islem_tanim_kod = 1101 ;

    ln_ref_tx_no  cbs_cek_karne_islem.tx_no%type := 0;
 	ln_adet number := 0;
  Begin
    if cur_cek%isopen then
	   close cur_cek;
	end if;

	open cur_cek;
	fetch cur_cek into ln_ref_tx_no;
	  if cur_cek%notfound then
	 	close cur_cek;
	  end if;

	close cur_cek;

	if nvl(ln_ref_tx_no,0) <= 0 then

		select count(*) into ln_adet
		from cbs_cek_karne_islem
		where hesap_no = pn_hesap_no and
			  durum_kodu = 'A'  and
			  karne_tipi_kodu =ps_karne_tipi and
   			  baslangic_cek_no = pn_baslangic_cek_no and
			  islem_tanim_kod = 1101 ;
		  if nvl(ln_adet,0) > 0 then
			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '189' ||  pkg_hata.getUCPOINTER);
		  else
			Raise_application_error(-20100,pkg_hata.getUCPOINTER || '177' ||  pkg_hata.getUCPOINTER);
		  end if;
	 end if;
	return(nvl(ln_ref_tx_no,0));

   End  Sf_Onayli_Cek_Karne_Islem_No;


  /*****************************************************************************************************************/
  /*   Function	 Sf_Hesaba_Cek_Tanimlimi																	        */
  /*   Girilen hesap noya ait minimum cek numarasi dodurulur 													    */
  /*****************************************************************************************************************/
   Function	 Sf_Hesaba_Cek_Tanimlimi(pn_hesap_no cbs_cek.hesap_no%type )return cbs_cek.cek_no%type
   is
   ln_cek_no cbs_cek.cek_no%type := 0;
   Begin
	  select min(cek_no)
	  into ln_cek_no
	  from cbs_cek
	  where hesap_no = pn_hesap_no;

     return nvl(ln_cek_no,0);
   Exception
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '182' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' || SQLERRM  || pkg_hata.getUCPOINTER);

   End Sf_Hesaba_Cek_Tanimlimi;

  /*****************************************************************************************************************/
  /*   Function	 Sf_Hesap_Acik_Cek_Varmi																	        */
  /*   Girilen hesaba ait acik cek mevcut mu.Hesap kapama programindan cagrilir. 													    */
  /*****************************************************************************************************************/
   Function	 Sf_Hesap_Acik_Cek_Varmi(pn_hesap_no cbs_cek.hesap_no%type )return boolean
   is
   ln_adet number := 0;
   Begin
	  select count(*)
	  into ln_adet
	  from cbs_cek
	  where hesap_no = pn_hesap_no
	  		and durum_kodu = 'A';
      if nvl(ln_adet,0) > 0 then
	     return true;
 	  else
		 return false;
	  end if;

   Exception
   	When No_data_found Then
		 return false;
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '184' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' || SQLERRM  || pkg_hata.getUCPOINTER);

   End Sf_Hesap_Acik_Cek_Varmi;

   /*****************************************************************************************************************/
  /*   Function	 Sf_Hesap_Acik_Talep_Varmi																	        */
  /*   Girilen ait acik talep var mi																				*/
  /*****************************************************************************************************************/
   Function	 Sf_Hesap_Acik_Talep_Varmi(pn_hesap_no cbs_cek.hesap_no%type )return varchar2
   is
   ln_adet number := 0;
   Begin
	  select count(*)
	  into ln_adet
	  from cbs_cek_karne_islem
	  where islem_tanim_kod = 1100 and
	        hesap_no = pn_hesap_no and
	  		durum_kodu = 'A';
      if nvl(ln_adet,0) > 0 then
	     return 'E';
 	  else
		 return 'H';
	  end if;

   Exception
   	When No_data_found Then
		 return 'H';
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '258' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' || SQLERRM  || pkg_hata.getUCPOINTER);

   End Sf_Hesap_Acik_Talep_Varmi;

  /*****************************************************************************************************************/
  /*   Function	 Sf_Hesap_Acik_Karne_Varmi																	        */
  /*   Girilen ait acik Karne var mi																				*/
  /*****************************************************************************************************************/

   Function	Sf_Hesap_Acik_Karne_Varmi(pn_hesap_no cbs_cek.hesap_no%type )return varchar2
   is
   ln_adet number := 0;
   Begin
	  select count(*)
	  into ln_adet
	  from cbs_cek_karne_islem
	  where islem_tanim_kod = 1101 and
	        hesap_no = pn_hesap_no and
	  		durum_kodu = 'A';
      if nvl(ln_adet,0) > 0 then
	     return 'E';
 	  else
		 return 'H';
	  end if;

   Exception
   	When No_data_found Then
		 return 'H';
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '259' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' || SQLERRM  || pkg_hata.getUCPOINTER);

   End Sf_Hesap_Acik_Karne_Varmi;


  /*****************************************************************************************************************/
  /*   Function	  Sf_Islem_Gonder_Talep_Islem_Al																               */
  /*   Girilen islemin cek talep referansini bulur														           */
  /*****************************************************************************************************************/
   Function	 Sf_Islem_Gonder_Talep_Islem_Al( pn_tx_no cbs_cek_islem.tx_no%type ) return cbs_cek_karne_islem.ref_tx_no%type
    is
   ln_tx_no cbs_cek_karne_islem.tx_no%type;
   ln_ref_tx_no cbs_cek_karne_islem.tx_no%type;
   ln_islem_tanim_kod cbs_cek_karne_islem.islem_tanim_kod%type;
   Begin
   	 ln_islem_tanim_kod := 0 ;
	 ln_ref_tx_no := pn_tx_no;

    while  ln_islem_tanim_kod <> 1100
	 loop
	  select islem_tanim_kod ,ref_tx_no ,tx_no
	  into ln_islem_tanim_kod,ln_ref_tx_no ,ln_tx_no
	  from cbs_cek_karne_islem
	  where tx_no =  ln_ref_tx_no;

    end loop;

	 return ln_tx_no;
   Exception
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '190' || pkg_hata.getUCPOINTER);
   End Sf_Islem_Gonder_Talep_Islem_Al;

  /*****************************************************************************************************************/
  /*   Function	  Sf_Islem_Gonder_Karne_Islem_Al															               */
  /*   Girilen islemin cek karne referansini bulur														           */
  /*****************************************************************************************************************/
   Function	 Sf_Islem_Gonder_Karne_Islem_Al( pn_tx_no cbs_cek_islem.tx_no%type ) return cbs_cek_karne_islem.ref_tx_no%type
    is
   ln_tx_no cbs_cek_karne_islem.tx_no%type;
   ln_ref_tx_no cbs_cek_karne_islem.tx_no%type;
   ln_islem_tanim_kod cbs_cek_karne_islem.islem_tanim_kod%type;
   Begin
   	 ln_islem_tanim_kod := 0 ;
	 ln_ref_tx_no := pn_tx_no;

    while  ln_islem_tanim_kod <> 1101
	 loop
	  select islem_tanim_kod ,ref_tx_no ,tx_no
	  into ln_islem_tanim_kod,ln_ref_tx_no ,ln_tx_no
	  from cbs_cek_karne_islem
	  where tx_no =  ln_ref_tx_no;
    end loop;
   return ln_tx_no;
   Exception
	When Others Then
		Raise_application_error(-20100,pkg_hata.getUCPOINTER || '191' || pkg_hata.getUCPOINTER);

   End  Sf_Islem_Gonder_Karne_Islem_Al;

  /*****************************************************************************************************************/
  /*   Function	Sf_Talep_Tarihini_Al															                   */
  /*   talep tarihi alnir.																			   	   		   */
  /*****************************************************************************************************************/
 Function Sf_Talep_Tarihini_Al( pn_tx_no cbs_cek_karne_islem.tx_no%type ) return cbs_cek_karne_islem.talep_tarihi%type
  is
    ld_talep_tarihi date :=null;
  Begin
  	select talep_tarihi
	into   ld_talep_tarihi
	from   cbs_cek_karne_islem
	where  tx_no = pn_tx_no ;

	return ld_talep_tarihi  ;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '226' || pkg_hata.getUCPOINTER);
   End  Sf_Talep_Tarihini_Al;

  /*****************************************************************************************************************/
  /*   Function	Sf_Karne_Teslim_Tarihini_Al															                   */
  /*   karnenin teslim tarihi alinir.																			   	   */
  /*****************************************************************************************************************/
  Function  Sf_Karne_Teslim_Tarihini_Al(pn_tx_no cbs_cek_karne_islem.tx_no%type ) return  cbs_cek_karne_islem.teslim_tarihi%type
  is
    ld_teslim_tarihi date :=null;
  Begin
  	select  teslim_tarihi
	into   ld_teslim_tarihi
	from   cbs_cek_karne_islem
	where  tx_no =  pn_tx_no;

	return ld_teslim_tarihi  ;

  Exception
     When no_data_found then return null;
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '232' || pkg_hata.getUCPOINTER);
   End   Sf_Karne_Teslim_Tarihini_Al;

  /*****************************************************************************************************************/
  /*   Function	Sf_Durum_Kodunu_Al															                       */
  /*   cek talep isleminden girilen referansa ait durum kodunu  getirir.																			   	   	   */
  /*****************************************************************************************************************/
  Function Sf_Cek_Islemin_Durum_Kodunu_Al( pn_tx_no cbs_cek_karne_islem.tx_no%type ) return cbs_cek_karne_islem.durum_kodu%type
  is
    ls_durum_kodu cbs_cek_karne_islem.durum_kodu%type;
  Begin
  	select durum_kodu
	into   ls_durum_kodu
	from   cbs_cek_karne_islem
	where  tx_no = pn_tx_no ;

	return ls_durum_kodu  ;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '227' || pkg_hata.getUCPOINTER);
   End Sf_Cek_Islemin_Durum_Kodunu_Al;


  /*****************************************************************************************************************/
  /*   Function	Sf_Cek_Talep_Karne_No														                       */
  /*   cek talep islem talebi gonderilip aktif karne numarasi alinir 											   */
  /*****************************************************************************************************************/
   Function	 Sf_Cek_Talep_Karne_No( pn_tx_no cbs_cek_karne_islem.tx_no%type ) return cbs_cek_karne_islem.tx_no%type
   is
     ln_tx_no   cbs_cek_karne_islem.tx_no%type;
	begin

	   select min(tx_no)
	   into ln_tx_no
	   from cbs_cek_karne_islem
	   where islem_tanim_kod = 1101 and
	       ref_tx_no = pn_tx_no and durum_kodu = 'A';

	 return nvl(ln_tx_no,0) ;

   Exception
   	  When no_data_found Then return 0 ;
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '227' || pkg_hata.getUCPOINTER);
   End  Sf_Cek_Talep_Karne_No;

  /*****************************************************************************************************************/
  /*   Function	Sf_Cek_Durumu_Al													               				   */
  /*   cekin durum kodu alinir																	   				   */
  /*****************************************************************************************************************/
   Function  Sf_Cek_Durumu_Al( pn_cek_no cbs_cek.cek_no%type ) return  cbs_cek.durum_kodu%type
   is
     ls_durum_kodu   cbs_cek.durum_kodu%type ;
	begin

	   select durum_kodu
	   into ls_durum_kodu
	   from cbs_cek
	   where cek_no = pn_cek_no;

	   return ls_durum_kodu;

    Exception
	  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '409' || pkg_hata.getUCPOINTER);
    End  Sf_Cek_Durumu_Al;

  /*****************************************************************************************************************/
  /*   Function	Sf_Cek_Teslim_Girisi_Yapilirmi												               */
  /*   cek karne numarasi gonderilip buna ait ceklerin statulerinde karsiliksiz, odeme yasakli varsa teslim girisinin yapilmasi inlenir. */
  /*****************************************************************************************************************/
   Function  Sf_Cek_Teslim_Girisi_Yapilirmi( pn_ref_tx_no cbs_cek_karne_islem.ref_tx_no%type ) return  cbs_cek.cek_no%type
   is
     ln_cek_no    cbs_cek.cek_no%type := 0;
	 ln_ref_tx_no  cbs_cek_karne_islem.tx_no%type;
	begin

	   select min(cek_no)
	   into ln_cek_no
	   from cbs_cek
	   where ref_tx_no= pn_ref_tx_no and durum_kodu in ('K','Y','B');

	   return nvl(ln_cek_no,0);

    Exception
   	  When no_data_found Then return 0 ;
	  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '408' || pkg_hata.getUCPOINTER);
    End  Sf_Cek_Teslim_Girisi_Yapilirmi;

  /*****************************************************************************************************************/
  /*   Function	 Sf_Cek_Teslim_Tarihini_Al												               */
  /*   cek numarasi gonderilip buna ait ceklerin statulerinde karsiliksiz, odeme yasakli varsa teslim girisi yapilamaz.	   */
  /*****************************************************************************************************************/
   Function Sf_Cek_Teslim_Tarihini_Al(pn_cek_no cbs_cek.cek_no%type ) return  cbs_cek.teslim_tarihi%type
   is
	 ld_teslim_tarihi cbs_cek.teslim_tarihi%type;
	begin

	   select teslim_tarihi
	   into ld_teslim_tarihi
	   from cbs_cek
	   where cek_no = pn_cek_no;

	   return ld_teslim_tarihi;

    Exception
	  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '422' || pkg_hata.getUCPOINTER);

    End   Sf_Cek_Teslim_Tarihini_Al;

  /*****************************************************************************************************************/
  /*   Function	Sf_Cek_Onceden_Blokelimiydi												               			   */
  /*   cek numarasi gonderilip bu cekin daha onceden bloke konulup konulmadigi bulunur 				   			   */
  /*****************************************************************************************************************/

   Function Sf_Cek_Onceden_Blokelimiydi(pn_cek_no cbs_cek.cek_no%type ) return varchar2
      is
	 ls_blokeli varchar2(1) := 'H';
	begin

	   select 'E'
	   into   ls_blokeli
	   from   cbs_cek
	   where  cek_no = pn_cek_no and
	   		  cek_bloke_hesap_no is not null;

	   return ls_blokeli;

    Exception
	  When no_data_found then return ls_blokeli ;
	  When Others Then
   	  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '410' || pkg_hata.getDelimiter ||  ls_blokeli ||  pkg_hata.getDelimiter ||pkg_hata.getUCPOINTER);

    End  Sf_Cek_Onceden_Blokelimiydi;


  /*****************************************************************************************************************/
  /*   Function	 Sf_Cek_Aralik_OdemeYasak_Uygun										               			   */
  /*   Girilen cek araligi icerisinde odenmii,odeme yasakli ,Karsiliksiz,Kariiliksiz ideme yasakli varsa uyarilmali	*/
  /*****************************************************************************************************************/

   Function  Sf_Cek_Aralik_OdemeYasak_Uygun(pn_cek_no cbs_cek.cek_no%type ,pn_cek_no_2 cbs_cek.cek_no%type ) return cbs_cek.cek_no%type
   is
	 ln_cek_no      cbs_cek.cek_no%type;
	 ls_durum_kodu	cbs_cek.durum_kodu%type;
	 uygun_durum_Degil	exception;
	begin

	   select min(cek_no) ,min(durum_kodu)
	   into   ln_cek_no ,ls_durum_kodu
	   from   cbs_cek
	   where  cek_no between  pn_cek_no and decode(nvl(pn_cek_no_2,0),0,pn_cek_no,pn_cek_no_2) and
	   		  durum_kodu  in ('Y','KY','O');

	  if  nvl(ln_cek_no,0) <> 0 then
	    raise  uygun_durum_degil;
	  else
	   return 0;
	  end if ;

    Exception
	  When no_data_found then return 0 ;
	  When Others Then
   	  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '262' || pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter || to_char(ln_cek_no) ||pkg_hata.getDelimiter ||pkg_hata.getUCPOINTER);
    End   Sf_Cek_Aralik_OdemeYasak_Uygun;


  /*****************************************************************************************************************/
  /*   Function	Sf_Cek_Aralik_OYasIptal_Uygun										               			   */
  /*   Girilen cek araligi icerisinde ideme yasakli (Y) ,Kariiliksiz ideme yasakli diiinda varsa (KY) Varsa uyarilmali	*/
  /*****************************************************************************************************************/
   Function  Sf_Cek_Aralik_OYasIptal_Uygun(pn_cek_no cbs_cek.cek_no%type ,pn_cek_no_2 cbs_cek.cek_no%type ) return cbs_cek.cek_no%type
   is
	 ln_cek_no      cbs_cek.cek_no%type;
	 ls_durum_kodu	cbs_cek.durum_kodu%type;
	 uygun_durum_Degil	exception;
	begin

	   select min(cek_no) ,min(durum_kodu)
	   into   ln_cek_no ,ls_durum_kodu
	   from   cbs_cek
	   where  cek_no between  pn_cek_no and  decode(nvl(pn_cek_no_2,0),0,pn_cek_no,pn_cek_no_2) and
	   		  durum_kodu not in ('Y','KY');

	  if  nvl(ln_cek_no,0) <> 0 then
	    raise  uygun_durum_degil;
	  else
	    return 0;
	  end if ;

    Exception
	  When no_data_found then return 0 ;
	  When Others Then
   	  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '262' || pkg_hata.getDelimiter || ls_durum_kodu || pkg_hata.getDelimiter || to_char(ln_cek_no) ||pkg_hata.getDelimiter ||pkg_hata.getUCPOINTER);
    End   Sf_Cek_Aralik_OYasIptal_Uygun;


  /*****************************************************************************************************************/
  /*   Function	Sf_Onay_Bekleyen_Varmi												               				  */
  /*   onay bekleyen islem varsa ,numarasi dondurulur												   		  */
  /****************************************************************************************************************/
  Function Sf_Onay_Bekleyen_Varmi( pn_cek_no cbs_cek_islem.cek_no%type ,pn_islem_tanim_kod  cbs_cek_islem.islem_tanim_kod%type ) return cbs_cek_islem.tx_no%type
   is
     ln_tx_no   cbs_cek_islem.tx_no%type  := 0;
	 onayda_bekleyen_islem_var 		 exception;
	begin

	   select min(tx_no)
	   into   ln_tx_no
	   from   cbs_cek_islem a , cbs_islem b
	   where  a.cek_no =pn_cek_no and
	   		  a.tx_no = b.numara and
	   		  pkg_tx.ISLEM_BITMIS_MI(b.numara)= 0 and
			  a.islem_tanim_kod = pn_islem_tanim_kod;

	   if  nvl(ln_tx_no,0) <> 0 then
	   	   raise 	onayda_bekleyen_islem_var;
	   end if;

	   return ln_tx_no ;

    Exception
	  When no_data_found then return 0;
	  When onayda_bekleyen_islem_var then
  	   	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '429' ||pkg_hata.getdelimiter|| ln_tx_no  || pkg_hata.getdelimiter ||  pkg_hata.getUCPOINTER);
	  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '446' ||pkg_hata.getdelimiter || to_char(SQLCODE)|| ' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  End Sf_Onay_Bekleyen_Varmi;


  /*****************************************************************************************************************/
  /*  Procedure  Sp_Takasdan_Gelenle_Guncelle									               			   		   */
  /*  Takasdan gelen bankamiz iekine ait bilgilerin guncellenmesi										           */
  /*****************************************************************************************************************/
   Procedure  Sp_Takasdan_Gelenle_Guncelle(pn_cek_no cbs_cek.cek_no%type,
   			  							   pd_iade_tarihi cbs_cek.iade_tarihi%type,
										   ps_iade_kodu	  cbs_cek.iade_kodu%type,
										   pn_karsi_banka_kodu  cbs_cek.karsi_banka_kodu%type,
										   ps_karsi_sube_kodu   cbs_cek.karsi_sube_kodu%type,
										   pd_ibraz_tarihi		cbs_cek.ibraz_tarihi%type,
										   pn_cek_tutari		cbs_cek.cek_tutari%type,
										   pd_odeme_tarihi		cbs_cek.odeme_tarihi%type,
										   ps_durum_kodu		cbs_cek.durum_kodu%type)
   is
	begin

	  update cbs_cek
  	  set   iade_tarihi =pd_iade_tarihi,
	        iade_kodu =  ps_iade_kodu,
			karsi_banka_kodu = pn_karsi_banka_kodu,
			karsi_sube_kodu  = ps_karsi_sube_kodu,
			ibraz_tarihi= pd_ibraz_tarihi,
			cek_tutari	= pn_cek_tutari,
			odeme_tarihi = pd_odeme_tarihi,
			durum_kodu	 = ps_durum_kodu
	 where cek_no  = pn_cek_no;

    Exception
	  When Others Then
   	  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '453' || pkg_hata.getDelimiter ||to_char(SQLCODE)|| ' '|| sqlerrm || pkg_hata.getDelimiter ||pkg_hata.getDelimiter ||pkg_hata.getUCPOINTER);
    End   Sp_Takasdan_Gelenle_Guncelle;


  /*****************************************************************************************************************/
  /*  Procedure  Sp_Cek_Bilgisi_Al									               			   		   				*/
  /*  Takasdan gelen bankamiz ieklerinin izlenmesinde kullanilan bilgileri iierir.					   			   */
  /*****************************************************************************************************************/
Procedure  Sp_Cek_Bilgisi_Al(pn_cek_no cbs_cek.cek_no%type, pn_musteri_no out cbs_cek.musteri_no%type,
                                pn_hesap_no out cbs_cek.hesap_no%type, ps_durum_kodu out cbs_cek.durum_kodu%type,
								pn_cek_bloke_hesap_no out cbs_cek.cek_bloke_hesap_no%type, ps_doviz_kodu out varchar2,
								pn_ODEME_GUN_SAYISI out number)
is
	ln_cnt number;
begin
	select musteri_no  ,
		   hesap_no   ,
	       durum_kodu ,
		   cek_bloke_hesap_no,
		   doviz_kodu
	into pn_musteri_no  ,
		 pn_hesap_no   ,
		 ps_durum_kodu ,
		 pn_cek_bloke_hesap_no,
		 ps_doviz_kodu
	from cbs_cek
	where cek_no = pn_cek_no ;

	pn_ODEME_GUN_SAYISI := 0;

	select count(*)
	into ln_cnt
	from cbs_cek_karne_islem
	where pn_cek_no between BASLANGIC_CEK_NO and BITIS_CEK_NO
	  and ODEME_GUN_SAYISI is not null
	  and HESAP_NO = pn_hesap_no
	  and musteri_no = pn_musteri_no
	  and TX_NO = (select max(TX_NO)
	  	  		   from cbs_cek_karne_islem
					where pn_cek_no between BASLANGIC_CEK_NO and BITIS_CEK_NO
					  and ODEME_GUN_SAYISI is not null
					  and HESAP_NO = pn_hesap_no
					  and musteri_no = pn_musteri_no);

	if ln_cnt = 1
	then
		select ODEME_GUN_SAYISI
		into pn_ODEME_GUN_SAYISI
		from cbs_cek_karne_islem
		where pn_cek_no between BASLANGIC_CEK_NO and BITIS_CEK_NO
		  and ODEME_GUN_SAYISI is not null
		  and HESAP_NO = pn_hesap_no
		  and musteri_no = pn_musteri_no
		  and TX_NO = (select max(TX_NO)
		  	  		   from cbs_cek_karne_islem
						where pn_cek_no between BASLANGIC_CEK_NO and BITIS_CEK_NO
						  and ODEME_GUN_SAYISI is not null
						  and HESAP_NO = pn_hesap_no
						  and musteri_no = pn_musteri_no);
	end if;

    Exception
	  When Others Then
   	  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '454' || pkg_hata.getDelimiter ||to_char(SQLCODE)|| ' '|| sqlerrm || pkg_hata.getDelimiter ||pkg_hata.getDelimiter ||pkg_hata.getUCPOINTER);
    End    Sp_Cek_Bilgisi_Al;

  /*****************************************************************************************************************/
  /*  Function modul_tur_kod									               			   		   				   */
  /*  modul bilgisi dondurulur																					   */
  /*****************************************************************************************************************/
   Function modul_tur_kod return varchar2
   is
   begin
   		return 'CHEQUE';
   end;
  /*****************************************************************************************************************/
  /*  Function urun_tur_kod									               			   		   				   */
  /*  urun bilgisi dondurulur																					   */
  /*****************************************************************************************************************/
    Function urun_tur_kod return varchar2
   is
   begin
   		return 'BANK';
   end;
  /*****************************************************************************************************************/
  /*  Function  sf_cek_bloke_hesap_urunumu							               			   		   			  */
  /*  bloke konulacak hesap lov sinde secilcek olan hesap urunleri uygun mu										  */
  /*****************************************************************************************************************/
   Function sf_cek_bloke_hesap_urunumu (ps_urun_tur_kod cbs_urun_sinif.urun_tur_kod%type,ps_sinif_kod cbs_urun_sinif.kod%type) return varchar2
   is
    ls_return varchar2(1) := 'H';
  Begin

	 if substr(ps_urun_tur_kod,1,5) = 'BLOKE' then
	 	--and substr(ps_sinif_kod,1,5) = 'BANKA' then
	   ls_return := 'E';
	 else
	   ls_return := 'H';
	 end if;

    return ls_return;
    Exception
	  When Others Then return 'H';
  End;

  /*****************************************************************************************************************/
  /*  Function  sf_cek_karne_masraf_urun_uygun						               			   		   			  */
  /*  bloke konulacak hesap lov sinde secilcek olan hesap urunleri uygun mu										  */
  /*****************************************************************************************************************/
    Function sf_cek_karne_masraf_urun_uygun(pn_hesap_no cbs_hesap.hesap_no%type) return varchar2
   is
	 ln_adet number;
	begin

 /* bloke konulmayan urunler asagidaki kosul kismina eklenir */

 	   select  1
	   into    ln_adet
	   from    cbs_hesap
	   where   substr(urun_tur_kod,1,5) in  ('TEMIN','BLOKE','IHRAC')  --  ( 'NOSTROTP','NOSTROYP','BLOKETP','BLOKEYP')
	   		   and hesap_no =pn_hesap_no;

		if nvl(ln_adet,0) = 0 Then
		   return 'E';
		else
		   return 'H';
		end if;
    Exception
	  When no_data_found then return 'E';
	  When Others Then
	      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '427' || pkg_hata.getUCPOINTER);
    End ;

 FUNCTION sf_cek_durum_aciklama_al(ps_durum_kodu varchar2) RETURN VARCHAR2
   is
   ls_durum varchar2(200);
   Begin
   		Select aciklama
		into ls_durum
		from   cbs_cek_durum_kodlari
		where durum_kodu =ps_durum_kodu;

		return ls_durum;
	Exception when others then return ' ';

   End;

   Function  Sf_iptal_Neden_Kodu(ps_iptal_neden_kodu in cbs_cek_iptal_neden_kodlari.iptal_neden_kodu%type) return varchar2
   is
    ls_aciklama varchar2(2000);
   Begin
   		select aciklama
		into  ls_aciklama
		from  cbs_cek_iptal_neden_kodlari
		where iptal_neden_kodu = ps_iptal_neden_kodu;

		return ls_aciklama;

	Exception when others then return null;
   End;

 End PKG_CEK;
/

