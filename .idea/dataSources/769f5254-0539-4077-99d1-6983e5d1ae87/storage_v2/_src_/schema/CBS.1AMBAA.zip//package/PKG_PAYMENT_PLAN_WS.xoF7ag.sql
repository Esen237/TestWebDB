create PACKAGE     PKG_PAYMENT_PLAN_WS IS

type lrec_extpaylist is record   (  paymentnumber    varchar2(100),
                                     amount           varchar2(100),
                                     installmenttypes varchar2(100));
type type_extpaylist is table of lrec_extpaylist         index by     binary_integer; 

/******************************************************************************
NAME        : FUNCTION getPaymentPlan
Prepared By : Bahiana Bektemir kyzy
Date        : 27.05.2021
Purpose     : Generate payment plan for customers 
******************************************************************************/
FUNCTION getPaymentPlan( ps_caller_payment_no in varchar2 default '0',
                         ps_caller_tx_no in varchar2 default '0',
                         ps_principal in varchar2,
                         ps_term in varchar2,
                         ps_interest_rate in varchar2,
                         ps_kkdf_rate in varchar2,
                         ps_bsmv_rate in varchar2,
                         ps_payment_day in varchar2,
                         ps_custom_first_payment_date in varchar2 default null,
                         ps_first_installment_type in varchar2,
                         ps_utilization_date in varchar2,
                         ps_interest_rate_type in varchar2,
                         ps_payment_plan_type in varchar2,
                         ps_calculation_type in varchar2,
                         ps_working_day_type in varchar2,
                         ps_duration in varchar2,
                         ps_no_payment_period in varchar2 default null,
                         ps_frequency_code in varchar2,
                         ps_additional_interest in varchar2,
                         ps_rate_divider in varchar2 default null,
                         ps_expense_amount  in varchar2,
                         ps_expense_payer_type in varchar2,
                         ps_expense_type in varchar2,
                         ps_commissions in varchar2 default null,
                         ps_commission_type in varchar2,
                         ps_commission_rate in varchar2,
                         ps_commission_amount in varchar2,
                         ps_increase_rate in varchar2,
                         ps_increase_frequency in varchar2,
                         ps_frequency_value in varchar2,
                         ps_fraction_digits in varchar2,
                         ps_yearly_cost_fraction_digits in varchar2,
                         ps_interest_usage_type in varchar2,
                         ps_tbl_type_extpaylist in type_extpaylist,
                         pn_tbl_type_extpaylist_cnt in number
                         ) RETURN VARCHAR2 ;
--NurmilaZ
Procedure payment_ws_log (p_wscode varchar2,
                  p_url varchar2,
                  p_method varchar2,
                  p_starttime date,
                  p_endtime date,
                  p_status varchar2, 
                  p_errortext varchar2,
                  pn_payment_ws_callid number,
                  pn_caller_payment_no number default 0,
                  pn_caller_tx_no number default 0,
                  ps_result_msg clob default null,
                  ps_send_message clob default null);
                                                                                                                                                     
END;
/

