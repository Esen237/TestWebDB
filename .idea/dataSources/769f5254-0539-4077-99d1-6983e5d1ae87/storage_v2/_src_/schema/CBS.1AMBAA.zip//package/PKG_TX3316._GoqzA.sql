create PACKAGE     Pkg_Tx3316 IS

/******************************************************************************
   Name       : PKG_TX3316
   Created By : Gulnihal Cengiz
   Date          : 01.03.2005
   Purpose      : Kullanici tanimlama
******************************************************************************/

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);           -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);          -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE    Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);              -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);          -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);              -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);              -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER );
 PROCEDURE  Guncelleme_Kontrolu(pn_islem_no NUMBER,
                                   ps_block     VARCHAR2,
                                ps_rowid        VARCHAR2,
                                     ps_column       VARCHAR2,
                                        pd_column       VARCHAR2,
                                ps_oldvalue IN OUT VARCHAR2);

 FUNCTION  sf_personel_adi_al(pn_sicil_numara NUMBER) RETURN VARCHAR2 ;
 FUNCTION  sf_personel_soyadi_al(pn_sicil_numara NUMBER) RETURN VARCHAR2 ;
 FUNCTION  sf_personel_bolum_al(pn_sicil_numara NUMBER) RETURN VARCHAR2 ;
 FUNCTION  sf_kullanici_kodu_uygun_mu(ps_kullanici VARCHAR2) RETURN VARCHAR2;
 PROCEDURE Open_Access(pn_islem_no NUMBER); --NursultanSa cbs-272 18.05.2020
 PROCEDURE Process_requests; --NursultanSa cbs-272 18.05.2020
 FUNCTION get_start_date(ps_kodu VARCHAR2) RETURN DATE; --NursultanSa cbs-272 18.05.2020
 Procedure delete_query(ps_kodu varchar2);
END;

/

