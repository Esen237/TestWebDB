create PACKAGE     pkg_tarih IS

  FUNCTION gun_ozellik ( pd_tarih    in DATE
                       , ps_country in varchar2 default null) RETURN NUMBER; -- 0 is gunu 1 tatil

  FUNCTION ileri_is_gunu(pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION geri_is_gunu( pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION ileri_gun (   pd_tarih in DATE DEFAULT SYSDATE
                       , p_gun NUMBER
                       , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION geri_gun  (   pd_tarih in DATE DEFAULT SYSDATE
                       , p_gun NUMBER
                       , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION haftanin_ilk_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                                , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION haftanin_son_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                                , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION ayin_son_is_gunu     ( pd_tarih in DATE DEFAULT SYSDATE
                                , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION donemin_son_is_gunu ( pd_tarih in DATE DEFAULT SYSDATE
                               , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION yilin_son_is_gunu   ( pd_tarih in DATE DEFAULT SYSDATE
                               , ps_country in varchar2 default null) RETURN DATE;

  FUNCTION ayin_son_gunu  ( vd_date in date) RETURN DATE;

  -- valor tarihine girilen aral?k eklenerek vade tarihi bulunur.vade tarihi is gunu olarak geri dondurulur.
  -- ornek ps_duration: '01D' , '03W' , '03M', 01Q' , '11Y'
  -- formda duration'?n alacag? degerler  '99D' or '99W' or '99M' or '99Q' or '99Y'

  FUNCTION vade_tarihini_bul(pd_date      in DATE DEFAULT SYSDATE
                          , ps_duration  in varchar2
                          , ps_country   in varchar2 default null) RETURN DATE;
  -- ps_next_previous parameter is used to decide return date whether next working date
  -- or previous working date if it is holiday
  FUNCTION vade_tarihini_bul(pd_date            in DATE DEFAULT SYSDATE
                          , pn_duration        in number                   -- negaive duration is also accepted
                          , ps_duration_type   in varchar2     default 'D' -- 'D','W','M','Q','Y'
                          , ps_next_previous   in varchar2     default 'N' --'N' or 'P'
                          , pd_result          out date
                          , ps_country         in varchar2 default null) RETURN number;

  FUNCTION tarihten_sonraki_isgunu(pd_date in date ) return date;
  --pd_date tarihinden sonraki ilk i? gununu bulur.

  FUNCTION yilin_ilk_is_gunu   ( pd_tarih in DATE DEFAULT pkg_muhasebe.Banka_Tarihi_Bul
                               , ps_country in varchar2 default null) RETURN DATE;
                               
--BOM aisuluud cq5205 04102016                               
  FUNCTION ileri_is_gunu_report(pd_tarih in DATE DEFAULT SYSDATE
                       , ps_country in varchar2 default null) RETURN DATE;
  FUNCTION ileri_gun_report ( pd_tarih in DATE DEFAULT SYSDATE
                     , p_gun NUMBER
                     , ps_country in varchar2 default null
                     ) RETURN DATE;                       
--EOM aisuluud cq5205 04102016                                  
  
  FUNCTION previous_working_day(pd_tarih in DATE DEFAULT SYSDATE) RETURN DATE;        -- CBS-27 IadgarB 22112018
END;

/

