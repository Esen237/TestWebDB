create PACKAGE  plsql101_pack IS
            DATE_LOADED DATE;
            TYPE pkg_perform_type IS RECORD
    (person_code plsql101_person.person_code%TYPE,
    person_name plsql101_person.second_name%TYPE,
    current_sales NUMBER(8,2),
    perform_percent NUMBER(8,1),
    status VARCHAR2(30)
    );
CURSOR PKG_PER_CUR RETURN plsql101_person%ROWTYPE;
 FUNCTION pkg_comp_discounts (order_amt NUMBER) RETURN NUMBER;
 
 PROCEDURE pkg_compute_perform
                (a_person plsql101_person%ROWTYPE,
        a_perform OUT pkg_perform_type);
END plsql101_pack;

/

