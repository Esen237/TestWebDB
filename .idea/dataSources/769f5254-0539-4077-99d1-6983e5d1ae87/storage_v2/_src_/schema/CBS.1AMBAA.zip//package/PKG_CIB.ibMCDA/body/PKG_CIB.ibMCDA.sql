create PACKAGE BODY     PKG_CIB IS

procedure collect is

cursor cur_proposal_lines is
select si.TX_NO, T.TEKLIF_NO, T.MUSTERI_NO, T.DURUM_KODU, si.TEKLIF_SATIR_NO, si.LINE, si.TRANCHES, si.KREDI_TURU, si.KREDI_KULLANDIRIM_KODU, si.ONERILEN_LIMIT_YP, si.REAL_LIMIT, si.DOVIZ_KODU
       FROM cbs_kredi_teklif t, cbs_kredi_teklif_islem a, cbs_islem b, cbs_kredi_teklif_satir_islem si
      WHERE     a.teklif_no = t.teklif_no
            AND a.tx_no = b.numara
            AND a.islem_tanim_kod = 1302
            and t.DURUM_KODU in ('A')
            and A.DURUM_KODU = 'A'
            and B.DURUM = 'P' 
            and SI.TX_NO = B.NUMARA
            and SI.TEKLIF_NO = A.TEKLIF_NO
            and exists (select 1 from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and 
            (select count(1) from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and urun_tur_kod in ('DEPO', 'LNGV', 'LOAN GIVEN', 'PLACEMENT', 'IMPORT L/C')) = 0);

cursor cur_main_accs(l_teklif_satir_no number) is
select *
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

cursor cur_active_main_and_pd_anapara(l_teklif_satir_no number) is
select * 
from CBS_HESAP_kredi
where KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no
and durum_kodu in ('A')
and (ANA_KREDI_HESAP_NO is null or PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA')
and URUN_TUR_KOD NOT IN ('CRD.CARD');--exclude overlimit account;

cursor cur_start_date_1(l_teklif_satir_no number) is
select min(nvl(nvl(nvl(b.ONAY_TARIH, b.TAMAMLANMA_TARIHI), B.DOGRU_TARIH), A.TEKLIF_TARIHI)) as start_date
from cbs_kredi_teklif t, cbs_kredi_teklif_islem a, cbs_islem b, cbs_kredi_teklif_satir_islem tt 
where A.TEKLIF_NO = T.TEKLIF_NO
and A.TX_NO = B.NUMARA
and T.DURUM_KODU in ('A', 'K') -- 'K' include inactive proposals too 
and A.DURUM_KODU = 'A'
and B.DURUM in ('P', '3')
and TT.TX_NO = B.NUMARA
and TT.TEKLIF_NO = A.TEKLIF_NO
and TT.TEKLIF_SATIR_NO = l_teklif_satir_no;

cursor cur_start_date_2(l_teklif_satir_no number) is
select min(acilis_tarihi) as start_date
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

row_start_date_1 cur_start_date_1%rowtype;
row_start_date_2 cur_start_date_2%rowtype;

ex_date exception;

l_ct_code CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.TEKLIF_SATIR_NO%type;
l_branch CBS.CBS_ISLEM.amir_bolum_kodu%type;
l_branch_region CBS.CBS_CIB_BRANCHES.CIB_ITEM_VALUE%type;
ld_expected_end_date date;
l_ct_phase CBS.cbs_newcib_data.CT_PHASE%type;
l_ct_status CBS.cbs_newcib_data.CT_STATUS%type;
ld_real_end_date date;
l_ct_type CBS.cbs_newcib_data.CT_TYPE%type;
l_ownership CBS.cbs_newcib_data.OWNERSHIP%type;
l_purpose CBS.CBS_NEWCIB_DATA.PURPOSE%type;
l_ct_currency CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.DOVIZ_KODU%type;
l_total_amount CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.ONERILEN_LIMIT_YP%type;
l_total_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
ln_total_installments integer;
l_installment_type CBS.cbs_newcib_data.INSTALLMENT_TYPE%type;
l_installment_amt CBS.cbs_newcib_data.INSTALLMENT_AMT%type;
l_total_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_installments integer;
l_total_pastdue_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_days integer;
ld_start_date date;
ld_next_pay_date date;
ls_payment_periodicity varchar2(10);

ln_cust_code number;
ls_inn varchar2(14);
ls_inn_t varchar2(128);
ls_address varchar2(256);
ls_citizenship varchar2(2);
ls_ind_surname varchar2(64);
ls_ind_firstname varchar2(64);
ls_ind_patronymic varchar2(128);
ls_ind_fullname varchar2(128);
ls_ind_class varchar2(10);
ls_ind_gender varchar2(15);
ld_ind_birthdate date;
ls_ind_marital varchar2(15);
ls_ind_passno varchar2(32);
ld_ind_pass_iss_date date;
ld_ind_pass_exp_date date;
ld_ind_pass_iss_country varchar2(2);
ld_ind_pass_iss_auth varchar2(256);
ls_com_name varchar2(128);
ls_com_legal_form varchar2(128);
ld_com_est_date date;
ls_com_economic_sector varchar2(2);

li_active_credit_accounts integer;
li_closed_credit_accounts integer;
l_account_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
li_account_installments integer;
l_account_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
ld_pd_main_open_date_min date;
ld_min_pay_date date;
stringdate_from_inn varchar2(8);
ln_batch_no integer;
ln_c integer;
ln_card_count integer;
lb_flag boolean;
ls_bd varchar2(8);
ld_bd date;

flag integer; --flag is used to point to possible position of exception
n integer := 0;

begin
    select max(batch_no)
    into ln_c
    from CBS_NEWCIB_DATA
    where REPORT_DATE = trunc(sysdate);
    
    flag := 1;
                            
    if(nvl(ln_c, 0) = 0) then
        ln_batch_no := 1;
    else
        ln_batch_no := ln_c + 1;                
    end if;
    for r2 in cur_proposal_lines --proposal lines (contracts)
        loop
            begin
                if(PKG_MUSTERI.SF_MUSTERI_TIPI_AL(r2.musteri_no) in (1,2,3)) then
                
                    --Expected End date--------------------
                    begin
                        flag := 1;                
                        if(r2.LINE = 'YES' or r2.TRANCHES = 'Y' or r2.KREDI_TURU in (13, 14, 31)) then
                            select max(VALIDITY_DATE_OF_LINE)
                            into ld_expected_end_date
                            from CBS_KREDI_TEKLIF_LIMIT  
                            where TEKLIF_NO = r2.teklif_no;
                            if(r2.KREDI_TURU in (13, 14, 31) and ld_expected_end_date is null) then
                                ld_expected_end_date := to_date('01012999', 'ddmmyyyy');
                            end if;
                        else
                            select max(KREDI_VADE)
                            into ld_expected_end_date
                            from CBS_HESAP_kredi
                            where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                            and durum_kodu in ('A', 'K')
                            and ANA_KREDI_HESAP_NO is null;
                        end if;
                        flag := 2;
                    exception when others then
                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'expected end date', sqlerrm);
                    end;    
                    ---------------------------------------
                    
                    --phase of contract--------------------
                    begin
                        -- Phase of Contract
                        -- Contract Status for Open
                        if (r2.KREDI_TURU in (13, 14, 31)) then
                            if(r2.ONERILEN_LIMIT_YP = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0) then
                                l_ct_phase := 'Closed';
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';
                            end if;                           
                        elsif (r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                            if(r2.ONERILEN_LIMIT_YP = 0 or r2.REAL_LIMIT = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0 ) then
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts > 0) then
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                else
                                    l_ct_phase := 'Closed';
                                end if;
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';    
                            end if;
                        else
                            if(r2.ONERILEN_LIMIT_YP = 0) then
                                l_ct_phase := 'Closed';
                            else
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts = 0) then --if no active accs then check whether there is any closed account to define credit proposal new or not
                                    select count(1)
                                    into li_closed_credit_accounts
                                    from cbs_hesap_kredi
                                    where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                    and DURUM_KODU = 'K';
                                    if(li_closed_credit_accounts = 0) then --if no closed accs then credit proposal is new
                                        l_ct_phase := 'Open';
                                        l_ct_status := 'GrantedAndActivated';
                                    else    
                                        l_ct_phase := 'Closed';
                                    end if;
                                else
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                end if;
                            end if;
                        end if;
                        flag := 3;
                    exception
                        when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'phase of contract', sqlerrm);
                            l_ct_phase := 'unkn';
                            l_ct_status := 'unkn';
                    end;
                                    
                    --Real end date-------------------
                    ld_real_end_date := null;
                    begin                                
                        if(l_ct_phase = 'Closed') then
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                begin
                                    
                                    if(r2.ONERILEN_LIMIT_YP != 0) then
                                        --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'Credit card closed by date');
                                        ld_real_end_date := ld_expected_end_date;
                                    else
                                        select max(I.KAYIT_TARIH) 
                                        into ld_real_end_date
                                        from cbs_kredi_teklif_satir_islem si, cbs_islem i
                                        where si.TEKLIF_SATIR_NO = r2.TEKLIF_SATIR_NO
                                        and SI.TEKLIF_NO = r2.teklif_no
                                        and SI.ONERILEN_LIMIT_YP = 0
                                        and SI.TX_NO = I.NUMARA
                                        and I.DURUM in ('P', '3')
                                        and I.ISLEM_KOD = 1302;
                                    end if;    
                                    
                                exception
                                    when no_data_found then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', 'not found');
                                    when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', sqlerrm);                               
                                end;
                            else
                                select max(KAPANIS_TARIHI)
                                into ld_real_end_date
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'K'; 
                            end if;        
                        end if;
                    exception when others then
                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'real end date', sqlerrm);    
                    end;
                    ----------------------------------
                    
                    if(ld_real_end_date is null or (extract(year from ld_real_end_date) in (2018))) then   
                    --if(true) then
                                  
                        l_ct_code := r2.TEKLIF_SATIR_NO; --Contract Code
                        l_branch := PKG_GENEL.AMIR_BOLUM_NO_AL(r2.TX_NO); --Branch
                        flag := 4;                
                        begin
                            select CIB_ITEM_VALUE
                            into l_branch_region --Branch Region Lookup
                            from cbs_cib_branches
                            where CBS_BRANCH_CODE = l_branch;
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; Branch: '||l_branch, 'branch', sqlerrm);
                            l_branch_region := '41711000000000';
                        end;
                        flag := 5;
                         
                        --Type of Contract----------------
                        --Purpose of Financing------------
                        lb_flag := false; -- flag used when defining start date of contract
                        l_ct_type := null;
                        l_purpose := null;
                        begin
                            flag := 6;
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                l_ct_type := 'CreditCard';
                                l_purpose := 'PersonalLoan';
                                lb_flag := true;
                            else
                                flag := 7;
                                if(r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                                    l_ct_type := 'RevolvingCredit';
                                    lb_flag := true;
                                else
                                    if(r2.KREDI_KULLANDIRIM_KODU in (13,14,17,26)) then
                                        l_ct_type := 'Installment';
                                        if(r2.KREDI_KULLANDIRIM_KODU in (13,14)) then
                                            l_purpose := 'Construct';
                                        elsif(r2.KREDI_KULLANDIRIM_KODU in (26)) then
                                            l_purpose := 'PersonalMotorVehicle';
                                        end if;
                                    else    
                                        flag := 8;
                                        if(r2.KREDI_TURU in (23,58,15,67,71,68,69,70,22,35,17,12,24,16)) then
                                            l_ct_type := 'Installment';
                                            if(r2.KREDI_TURU in(22,35,17,12)) then
                                                l_purpose := 'Mortgage';
                                            elsif(r2.KREDI_TURU in (69,70)) then
                                                l_purpose := 'Industry';   
                                            elsif(r2.KREDI_TURU in (67,68,71)) then
                                                l_purpose := 'Agriculture';     
                                            end if;
                                        elsif(r2.KREDI_TURU in (36,7,9,37,8,10,18,19,20)) then
                                            l_ct_type := 'NonInstallment';
                                            lb_flag := true;
                                            if(r2.KREDI_TURU in (36,7,9,37,8,10)) then
                                                l_purpose := 'TradeFinanceFacility';
                                            end if;          
                                        end if;
                                    end if;       
                                end if;
                            end if;    
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'type of contract', sqlerrm);
                        end;         
                        ----------------------------------                                           
                        flag := 9;
         
                        --Contract Status for Closed------
                        begin
                            if(l_ct_phase = 'Closed') then
                                if(trunc(ld_expected_end_date) - trunc(ld_real_end_date) < 0) then
                                    l_ct_status := 'SettledLate';
                                elsif(trunc(ld_expected_end_date) - trunc(ld_real_end_date) = 0) then
                                    l_ct_status := 'SettledOnTime';
                                else
                                    l_ct_status := 'SettledInAdvance';
                                end if;
                            end if;    
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'closed contract status', sqlerrm);
                        end;  
                        ----------------------------------
                        flag := 10;

                        l_ownership := 'Individual'; --Ownership Type
                        l_ct_currency := r2.DOVIZ_KODU; --Currency of Contract
                                        
                        --Total Amount--------------------
                        if(l_ct_phase = 'Open') then
                            l_total_amount := r2.ONERILEN_LIMIT_YP; --Total Amount
                        else
                            l_total_amount := null;    
                        end if;
                        

                        --Total Taken Amount--------------
                        --Number of Installments----------
                        --Next Payment Date--------------- 
                        l_account_taken_amt := 0;
                        l_total_taken_amt := 0; 
                        li_account_installments := 0;
                        ln_total_installments := 0;
                        ld_next_pay_date := null;
                        if(r2.KREDI_TURU in (13, 14, 31)) then
                            l_total_taken_amt := r2.ONERILEN_LIMIT_YP;
                        else    
                            for r3 in cur_main_accs(r2.TEKLIF_SATIR_NO) --kredi hesaplar  
                                loop  
                                    if(r3.URUN_TUR_KOD <> 'RT-CARD') then
                                        begin
                                            if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r3.DOVIZ_KODU, l_ct_currency, r3.ACILIS_TARIHI, r3.TUTAR, null, null, null, 'N', null, l_account_taken_amt) = 1) then
                                                if(l_account_taken_amt is null) then
                                                    l_account_taken_amt := 0;
                                                end if;    
                                                l_total_taken_amt := l_total_taken_amt + l_account_taken_amt; --Total Taken Amount
                                            else
                                                --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', 'zero result');
                                                l_account_taken_amt := 0;
                                            end if;
                                        exception
                                            when others then
                                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', sqlerrm);
                                        end;  
                                    end if;  
                                    flag := 11;  
                                    begin 
                                        select count(1) --count number of active installments in account
                                        into li_account_installments
                                        from cbs_hesap_kredi_taksit
                                        where durum_kodu = 'A'
                                        and hesap_no = r3.hesap_no;
                                                                    
                                        ln_total_installments := ln_total_installments + li_account_installments; --Number of Installments
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total installments', sqlerrm);
                                    end;
                                    flag := 12;                
                                    begin
                                        select min(vade_tarih)
                                        into ld_min_pay_date
                                        from cbs_hesap_kredi_taksit
                                        where durum_kodu = 'A'
                                        and hesap_no = r3.hesap_no
                                        and vade_tarih > trunc(sysdate);
                                                        
                                        if(ld_next_pay_date is null or ld_next_pay_date > ld_min_pay_date) then
                                            ld_next_pay_date := ld_min_pay_date; --Next Payment Date
                                        end if;
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'next payment date', sqlerrm);
                                    end;
                                                               
                                end loop;
                        end if;    
                        ----------------------------------
                        ls_payment_periodicity := 'Days30'; --Payment Periodicity
                        --l_installment_type := '@@@@@'; --Installment Type
                        --l_installment_amt := 999.99; --Installment Amount --if type of installment is not fixed which should be the value? 

                        --Number of Due Installments
                        --Principal Outstanding Amount 
                        --PastDue Amount
                        --It is suggested by Maksat Dolotbakov not to report Faiz and Tax in PastDue Amount
                        --So, the total pastdue amount contains only Anapara(Main) PastDue amount
                        l_account_outstand_amt := 0;
                        l_total_outstand_amt := 0;
                        l_total_pastdue_amt := 0;
                        ld_pd_main_open_date_min := trunc(sysdate);
                        li_pd_installments := 0;
                                        
                        for r4 in cur_active_main_and_pd_anapara(r2.TEKLIF_SATIR_NO) --main and pastdue main accs. Both active 
                            loop
                                if(r4.URUN_TUR_KOD not in ('RT-CARD', 'PD-CARD')) then
                                    begin  
                                        if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r4.DOVIZ_KODU, l_ct_currency, r4.ACILIS_TARIHI, PKG_KREDI.SF_BAKIYE_AL(r4.HESAP_NO) * -1, null, null, null, 'N', null, l_account_outstand_amt) = 1) then
                                            if(l_account_outstand_amt is null) then
                                                l_account_outstand_amt := 0;
                                            end if;
                                            l_total_outstand_amt := l_total_outstand_amt + l_account_outstand_amt; --Principal Outstanding Amount
                                        else
                                            --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', 'zero or null input, just for info, delete this record');
                                            l_account_outstand_amt := 0;
                                        end if;        
                                    exception
                                        when others then
                                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', sqlerrm);
                                    end;
                                    flag := 13;                
                                    begin
                                        if(r4.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' and l_account_outstand_amt > 0) then --include only Anapara PastDue accounts whose balance > 0
                                            li_pd_installments := li_pd_installments + 1; --Number of Due Installments
                                            l_total_pastdue_amt := l_total_pastdue_amt + l_account_outstand_amt; --PastDue Amount      
                                            if(r4.ACILIS_TARIHI < ld_pd_main_open_date_min) then
                                                ld_pd_main_open_date_min := r4.ACILIS_TARIHI;
                                            end if;
                                        end if;
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total pastdue amt', sqlerrm);
                                    end;
                                end if;
                            end loop;
                            
                        --Past Due days------------------------
                        --if contract is Closed OR (Open and has no active Past due accounts) then ld_pd_main_open_date_min equals sysdate
                        li_pd_days := trunc(sysdate) - ld_pd_main_open_date_min;    
                        ---------------------------------------
                        flag := 14; 
                                       
                        --Start date---------------------------    
                        if(lb_flag) then --for these credit types all ever created proposals are considered 
                            open cur_start_date_1(r2.TEKLIF_SATIR_NO);
                            fetch cur_start_date_1 into row_start_date_1;
                            close cur_start_date_1;
                            ld_start_date := row_start_date_1.start_date;                            
                        else
                            open cur_start_date_2(r2.TEKLIF_SATIR_NO);
                            fetch cur_start_date_2 into row_start_date_2;
                            close cur_start_date_2;
                            ld_start_date := row_start_date_2.start_date;                           
                        end if;
                        ---------------------------------------
                        flag := 15;
                        
                        ln_cust_code := r2.MUSTERI_NO; --Customer Code
                        
                        select soyadi, isim, ikinci_isim, decode(musteri_tipi_kod, 1, 'Individual', 2, 'SoleTrader', 3, null), 
                            decode(musteri_tipi_kod, 3, null, decode(cinsiyet_kod, 'M', 'Male', 'F', 'Female', 'NotSpecified')), dogum_tarihi,
                            decode(musteri_tipi_kod, 3, null, decode(medeni_hal_kod, 1, 'Single', 2, 'Married', 3, 'Divorced', 'Other')), 
                            decode(musteri_tipi_kod, 3, null, decode(NUFUS_CUZDANI_SERI_NO, null, PASAPORT_NO, NUFUS_CUZDANI_SERI_NO)), TICARI_UNVAN      
                        into ls_ind_surname, ls_ind_firstname, ls_ind_patronymic, ls_ind_class, ls_ind_gender, ld_ind_birthdate, ls_ind_marital, ls_ind_passno, ls_com_name
                        from cbs_musteri
                        where musteri_no = ln_cust_code;  
                        flag := 16;  
                        ls_ind_fullname := ls_ind_surname||' '||ls_ind_firstname||' '||ls_ind_patronymic;
                                            
                        ls_address := PKG_MUSTERI.SF_ADRES_AL(ln_cust_code); --Address Line 
                        ls_citizenship := PKG_MUSTERI.SF_UYRUKKOD_AL(ln_cust_code); --Citizenship/Registration Country
                        if(ls_citizenship = 'KG') then
                            ls_inn_t := PKG_MUSTERI.SF_VERGINO_AL(ln_cust_code);
                            if(length(ls_inn_t)=14) then
                                --check gender digit
                                if(ls_ind_class is not null) then
                                    case(ls_ind_gender)
                                        when 'Male' then 
                                            if(substr(ls_inn_t, 1, 1) != '2') then
                                                raise_application_error(-20100, 'incorrect inn for male: '||ls_inn_t||'; customer: '||ln_cust_code);
                                            end if;  
                                        when 'Female' then
                                            if(substr(ls_inn_t, 1, 1) != '1') then
                                                raise_application_error(-20100, 'incorrect inn for female: '||ls_inn_t||'; customer: '||ln_cust_code);
                                            end if;     
                                   end case;
                                end if;    
                                
                                --check date digits
                                begin
                                    ls_bd := substr(ls_inn_t, 2, 8);
                                    ld_bd := to_date(ls_bd, 'ddmmyyyy');
                                    if((ls_ind_class is not null) and (ld_bd != ld_ind_birthdate)) then
                                        raise ex_date;
                                    end if;
                                exception when ex_date then
                                    raise_application_error(-20100, 'incorrect birthdate in inn : '||ls_inn_t||', birthdate: '||ld_ind_birthdate||'; customer: '||ln_cust_code);
                                when others then
                                    raise_application_error(-20100, 'wrong date digits in inn: '||ls_inn_t||', date digits: '||ls_bd||'; customer: '||ln_cust_code);                           
                                end;
                                ls_inn := ls_inn_t; --Social Security Number/INN
                            else
                                raise_application_error(-20100, 'incorrect or empty inn: '||ls_inn_t||'; customer: '||ln_cust_code);
                            end if;                      
                        else      
                            ls_inn := null;
                        end if;                    
                        flag := 17; 
                           
                        if(ls_ind_class is null) then
                            ld_com_est_date := ld_bd;
                            if(ls_inn is not null) then
                               begin
                                   stringdate_from_inn := substr(ls_inn, 2,8);
                                   ld_com_est_date := to_date(stringdate_from_inn, 'DDMMYYYY');
                                exception when others then
                                   log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; INN: '||ls_inn, 'establishment date', sqlerrm);
                                end;
                            else
                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'establishment date', 'no inn');    
                            end if;   
                        else
                            ld_com_est_date := null;    
                        end if;
                        flag := 18;

                        begin
                            insert into CBS_NEWCIB_DATA(
                                REPORT_DATE,
                                DAY_OR_MONTH,
                                BATCH_NO,
                                CT_CODE, 
                                BRANCH, 
                                BRANCH_REGION, 
                                CT_PHASE, 
                                CT_STATUS,
                                CT_TYPE,
                                OWNERSHIP,
                                CT_CURRENCY,
                                TOTAL_AMOUNT,
                                TOTAL_TAKEN_AMOUNT,
                                NUMBER_OF_ISTALLMENTS,
                                PRINCIPAL_OUTSTANDING_AMT,
                                PAST_DUE_AMT,
                                PAST_DUE_DAYS,
                                NUMBER_OF_DUE_INSTALLMENTS,
                                NEXT_PAYMENT_DATE,
                                PAYMENT_PERIODICITY,
                                START_DATE,
                                EXPECTED_END_DATE,
                                REAL_END_DATE,
                                CUSTOMER_CODE,
                                INN,
                                ADDRESS_LINE,
                                CITIZENSHIP,
                                IND_SURNAME,
                                IND_FIRSTNAME,
                                IND_PATRONYMIC,
                                IND_FULLNAME,
                                IND_CLASS,
                                IND_GENDER,
                                IND_BIRTHDATE,
                                IND_MARITAL,
                                IND_PASS_NO,
                                COM_NAME,
                                COM_EST_DATE
                            ) values(
                                trunc(sysdate),
                                'M',
                                ln_batch_no,
                                l_ct_code,
                                l_branch,
                                l_branch_region,
                                l_ct_phase,
                                l_ct_status,
                                l_ct_type,
                                l_ownership,
                                l_ct_currency,
                                l_total_amount,
                                l_total_taken_amt,
                                ln_total_installments,
                                l_total_outstand_amt,
                                l_total_pastdue_amt,
                                li_pd_days,
                                li_pd_installments,
                                ld_next_pay_date,
                                ls_payment_periodicity,
                                ld_start_date,
                                ld_expected_end_date,
                                ld_real_end_date,
                                ln_cust_code,
                                ls_inn,
                                ls_address,
                                ls_citizenship,
                                ls_ind_surname,
                                ls_ind_firstname,
                                ls_ind_patronymic,
                                ls_ind_fullname,
                                ls_ind_class,
                                ls_ind_gender,
                                ld_ind_birthdate,
                                ls_ind_marital,
                                ls_ind_passno,
                                ls_com_name,
                                ld_com_est_date
                            );
                            if(n>30) then
                                commit;
                                n:=0;
                            else
                                n:=n+1;
                            end if;        
                        exception
                            when others then
                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'insert into table', sqlerrm);
                        end;
                    end if;
                end if;
            exception when others then
                log_at('cbs_newcib_data_collect_error', 'TX NO: '||r2.tx_no ||'; Proposal: '||r2.teklif_no||'; Credit line: '||r2.TEKLIF_SATIR_NO||' date: '||trunc(sysdate)||'; batch no: '||ln_batch_no, 'main node '||flag, sqlerrm);
            end;  
        end loop;
end;



procedure collect_inactive_proposals is

cursor cur_proposal_lines is
select si.TX_NO, T.TEKLIF_NO, T.MUSTERI_NO, T.DURUM_KODU, si.TEKLIF_SATIR_NO, si.LINE, si.TRANCHES, si.KREDI_TURU, si.KREDI_KULLANDIRIM_KODU, si.ONERILEN_LIMIT_YP, si.REAL_LIMIT, si.DOVIZ_KODU
FROM cbs_kredi_teklif t, cbs_kredi_teklif_satir_islem si
WHERE SI.TEKLIF_NO = t.teklif_no
and si.tx_no = (
    select max(si2.TX_NO)
    FROM cbs_kredi_teklif t2, cbs_kredi_teklif_islem a2, cbs_islem b2, cbs_kredi_teklif_satir_islem si2
    WHERE     a2.teklif_no = t2.teklif_no
    AND a2.tx_no = b2.numara
    AND a2.islem_tanim_kod = 1302
    --and t2.MUSTERI_NO = 15883 -------
    and t2.DURUM_KODU in ('K') --------
    and A2.DURUM_KODU = 'A'
    and B2.DURUM = 'P' 
    and SI2.TX_NO = B2.NUMARA
    and SI2.TEKLIF_NO = A2.TEKLIF_NO
    and SI2.TEKLIF_SATIR_NO = SI.TEKLIF_SATIR_NO
    and exists (select 1 from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and 
            (select count(1) from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and urun_tur_kod in ('DEPO', 'LNGV', 'LOAN GIVEN', 'PLACEMENT', 'IMPORT L/C')) = 0)
    group by si2.TEKLIF_SATIR_NO
)   and not exists(
                select 1
       FROM cbs_kredi_teklif t1, cbs_kredi_teklif_islem a1, cbs_islem b1, cbs_kredi_teklif_satir_islem si1
      WHERE     a1.teklif_no = t1.teklif_no
            AND a1.tx_no = b1.numara
            AND a1.islem_tanim_kod = 1302
            --and t1.MUSTERI_NO = 15883 -------
            and t1.DURUM_KODU in ('A') --------
            and A1.DURUM_KODU = 'A'
            and B1.DURUM = 'P' 
            and SI1.TX_NO = B1.NUMARA
            and SI1.TEKLIF_NO = A1.TEKLIF_NO
            and SI1.TEKLIF_SATIR_NO = si.TEKLIF_SATIR_NO
            and exists (select 1 from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and 
            (select count(1) from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and urun_tur_kod in ('DEPO', 'LNGV', 'LOAN GIVEN', 'PLACEMENT', 'IMPORT L/C')) = 0)
            );
            
cursor cur_main_accs(l_teklif_satir_no number) is
select *
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

cursor cur_active_main_and_pd_anapara(l_teklif_satir_no number) is
select * 
from CBS_HESAP_kredi
where KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no
and durum_kodu in ('A')
and (ANA_KREDI_HESAP_NO is null or PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA')
and URUN_TUR_KOD NOT IN ('CRD.CARD');--exclude overlimit account;

cursor cur_start_date_1(l_teklif_satir_no number) is
select min(nvl(nvl(nvl(b.ONAY_TARIH, b.TAMAMLANMA_TARIHI), B.DOGRU_TARIH), A.TEKLIF_TARIHI)) as start_date
from cbs_kredi_teklif t, cbs_kredi_teklif_islem a, cbs_islem b, cbs_kredi_teklif_satir_islem tt 
where A.TEKLIF_NO = T.TEKLIF_NO
and A.TX_NO = B.NUMARA
and T.DURUM_KODU in ('A', 'K') -- 'K' include inactive proposals too 
and A.DURUM_KODU = 'A'
and B.DURUM in ('P', '3')
and TT.TX_NO = B.NUMARA
and TT.TEKLIF_NO = A.TEKLIF_NO
and TT.TEKLIF_SATIR_NO = l_teklif_satir_no;

cursor cur_start_date_2(l_teklif_satir_no number) is
select min(acilis_tarihi) as start_date
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

row_start_date_1 cur_start_date_1%rowtype;
row_start_date_2 cur_start_date_2%rowtype;

ex_date exception;

l_ct_code CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.TEKLIF_SATIR_NO%type;
l_branch CBS.CBS_ISLEM.amir_bolum_kodu%type;
l_branch_region CBS.CBS_CIB_BRANCHES.CIB_ITEM_VALUE%type;
ld_expected_end_date date;
l_ct_phase CBS.cbs_newcib_data.CT_PHASE%type;
l_ct_status CBS.cbs_newcib_data.CT_STATUS%type;
ld_real_end_date date;
l_ct_type CBS.cbs_newcib_data.CT_TYPE%type;
l_ownership CBS.cbs_newcib_data.OWNERSHIP%type;
l_purpose CBS.CBS_NEWCIB_DATA.PURPOSE%type;
l_ct_currency CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.DOVIZ_KODU%type;
l_total_amount CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.ONERILEN_LIMIT_YP%type;
l_total_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
ln_total_installments integer;
l_installment_type CBS.cbs_newcib_data.INSTALLMENT_TYPE%type;
l_installment_amt CBS.cbs_newcib_data.INSTALLMENT_AMT%type;
l_total_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_installments integer;
l_total_pastdue_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_days integer;
ld_start_date date;
ld_next_pay_date date;
ls_payment_periodicity varchar2(10);

ln_cust_code number;
ls_inn varchar2(14);
ls_inn_t varchar2(128);
ls_address varchar2(256);
ls_citizenship varchar2(2);
ls_ind_surname varchar2(64);
ls_ind_firstname varchar2(64);
ls_ind_patronymic varchar2(128);
ls_ind_fullname varchar2(128);
ls_ind_class varchar2(10);
ls_ind_gender varchar2(15);
ld_ind_birthdate date;
ls_ind_marital varchar2(15);
ls_ind_passno varchar2(32);
ld_ind_pass_iss_date date;
ld_ind_pass_exp_date date;
ld_ind_pass_iss_country varchar2(2);
ld_ind_pass_iss_auth varchar2(256);
ls_com_name varchar2(128);
ls_com_legal_form varchar2(128);
ld_com_est_date date;
ls_com_economic_sector varchar2(2);

li_active_credit_accounts integer;
li_closed_credit_accounts integer;
l_account_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
li_account_installments integer;
l_account_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
ld_pd_main_open_date_min date;
ld_min_pay_date date;
stringdate_from_inn varchar2(8);
ln_batch_no integer;
ln_c integer;
ln_card_count integer;
lb_flag boolean;
ls_bd varchar2(8);
ld_bd date;

flag integer; --flag is used to point to possible position of exception
n integer := 0;

begin
    select max(batch_no)
    into ln_c
    from CBS_NEWCIB_DATA
    where REPORT_DATE = trunc(sysdate);
    
    flag := 1;
                            
    if(nvl(ln_c, 0) = 0) then
        ln_batch_no := 1;
    else
        ln_batch_no := ln_c + 1;                
    end if;
    for r2 in cur_proposal_lines --proposal lines (contracts)
        loop
            begin
                if(PKG_MUSTERI.SF_MUSTERI_TIPI_AL(r2.musteri_no) in (1,2,3)) then
                
                    --Expected End date--------------------
                    begin
                        flag := 1;                
                        if(r2.LINE = 'YES' or r2.TRANCHES = 'Y' or r2.KREDI_TURU in (13, 14, 31)) then
                            select max(VALIDITY_DATE_OF_LINE)
                            into ld_expected_end_date
                            from CBS_KREDI_TEKLIF_LIMIT  
                            where TEKLIF_NO = r2.teklif_no;
                            if(r2.KREDI_TURU in (13, 14, 31) and ld_expected_end_date is null) then
                                ld_expected_end_date := to_date('01012999', 'ddmmyyyy');
                            end if;
                        else
                            select max(KREDI_VADE)
                            into ld_expected_end_date
                            from CBS_HESAP_kredi
                            where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                            and durum_kodu in ('A', 'K')
                            and ANA_KREDI_HESAP_NO is null;
                        end if;
                        flag := 2;
                    exception when others then
                        log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'expected end date', sqlerrm);
                    end;    
                    ---------------------------------------
                    
                    --phase of contract--------------------
                    begin
                        -- Phase of Contract
                        -- Contract Status for Open
                        if (r2.KREDI_TURU in (13, 14, 31)) then
                            if(r2.ONERILEN_LIMIT_YP = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0) then
                                l_ct_phase := 'Closed';
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';
                            end if;                           
                        elsif (r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                            if(r2.ONERILEN_LIMIT_YP = 0 or r2.REAL_LIMIT = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0 ) then
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts > 0) then
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                else
                                    l_ct_phase := 'Closed';
                                end if;
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';    
                            end if;
                        else
                            if(r2.ONERILEN_LIMIT_YP = 0) then
                                l_ct_phase := 'Closed';
                            else
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts = 0) then --if no active accs then check whether there is any closed account to define credit proposal new or not
                                    select count(1)
                                    into li_closed_credit_accounts
                                    from cbs_hesap_kredi
                                    where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                    and DURUM_KODU = 'K';
                                    if(li_closed_credit_accounts = 0) then --if no closed accs then credit proposal is new
                                        l_ct_phase := 'Open';
                                        l_ct_status := 'GrantedAndActivated';
                                    else    
                                        l_ct_phase := 'Closed';
                                    end if;
                                else
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                end if;
                            end if;
                        end if;
                        flag := 3;
                    exception
                        when others then
                            log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'phase of contract', sqlerrm);
                            l_ct_phase := 'unkn';
                            l_ct_status := 'unkn';
                    end;
                    
                    if(l_ct_phase = 'Closed') then
                        --Real end date-------------------
                        ld_real_end_date := null;
                        begin                                
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                begin       
                                    if(r2.ONERILEN_LIMIT_YP != 0) then
                                        --log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'Credit card closed by date');
                                        ld_real_end_date := ld_expected_end_date;
                                    else
                                        select max(I.KAYIT_TARIH) 
                                        into ld_real_end_date
                                        from cbs_kredi_teklif_satir_islem si, cbs_islem i
                                        where si.TEKLIF_SATIR_NO = r2.TEKLIF_SATIR_NO
                                        and SI.TEKLIF_NO = r2.teklif_no
                                        and SI.ONERILEN_LIMIT_YP = 0
                                        and SI.TX_NO = I.NUMARA
                                        and I.DURUM in ('P', '3')
                                        and I.ISLEM_KOD = 1302;
                                    end if;    
                                        
                                exception
                                    when no_data_found then
                                        log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', 'not found');
                                    when others then
                                        log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', sqlerrm);                               
                                end;
                            else
                                select max(KAPANIS_TARIHI)
                                into ld_real_end_date
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'K'; 
                            end if;        
                        exception when others then
                            log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'real end date', sqlerrm);    
                        end;
                        ----------------------------------
                    
                        if(ld_real_end_date is not null) then                                        
                            l_ct_code := r2.TEKLIF_SATIR_NO; --Contract Code
                            l_branch := PKG_GENEL.AMIR_BOLUM_NO_AL(r2.TX_NO); --Branch
                            flag := 4;                
                            begin
                                select CIB_ITEM_VALUE
                                into l_branch_region --Branch Region Lookup
                                from cbs_cib_branches
                                where CBS_BRANCH_CODE = l_branch;
                            exception when others then
                                log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; Branch: '||l_branch, 'branch', sqlerrm);
                                l_branch_region := '41711000000000';
                            end;
                            flag := 5;
                             
                            --Type of Contract----------------
                            --Purpose of Financing------------
                            lb_flag := false; -- flag used when defining start date of contract
                            l_ct_type := null;
                            l_purpose := null;
                            begin
                                flag := 6;
                                if(r2.KREDI_TURU in (13, 14, 31)) then
                                    l_ct_type := 'CreditCard';
                                    l_purpose := 'PersonalLoan';
                                    lb_flag := true;
                                else
                                    flag := 7;
                                    if(r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                                        l_ct_type := 'RevolvingCredit';
                                        lb_flag := true;
                                    else
                                        if(r2.KREDI_KULLANDIRIM_KODU in (13,14,17,26)) then
                                            l_ct_type := 'Installment';
                                            if(r2.KREDI_KULLANDIRIM_KODU in (13,14)) then
                                                l_purpose := 'Construct';
                                            elsif(r2.KREDI_KULLANDIRIM_KODU in (26)) then
                                                l_purpose := 'PersonalMotorVehicle';
                                            end if;
                                        else    
                                            flag := 8;
                                            if(r2.KREDI_TURU in (23,58,15,67,71,68,69,70,22,35,17,12,24,16)) then
                                                l_ct_type := 'Installment';
                                                if(r2.KREDI_TURU in(22,35,17,12)) then
                                                    l_purpose := 'Mortgage';
                                                elsif(r2.KREDI_TURU in (69,70)) then
                                                    l_purpose := 'Industry';   
                                                elsif(r2.KREDI_TURU in (67,68,71)) then
                                                    l_purpose := 'Agriculture';     
                                                end if;
                                            elsif(r2.KREDI_TURU in (36,7,9,37,8,10,18,19,20)) then
                                                l_ct_type := 'NonInstallment';
                                                lb_flag := true;
                                                if(r2.KREDI_TURU in (36,7,9,37,8,10)) then
                                                    l_purpose := 'TradeFinanceFacility';
                                                end if;          
                                            end if;
                                        end if;       
                                    end if;
                                end if;    
                            exception when others then
                                log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'type of contract', sqlerrm);
                            end;         
                            ----------------------------------                                           
                            flag := 9;
             
                            --Contract Status for Closed------
                            begin
                                if(trunc(ld_expected_end_date) - trunc(ld_real_end_date) < 0) then
                                    l_ct_status := 'SettledLate';
                                elsif(trunc(ld_expected_end_date) - trunc(ld_real_end_date) = 0) then
                                    l_ct_status := 'SettledOnTime';
                                else
                                    l_ct_status := 'SettledInAdvance';
                                end if;   
                            exception when others then
                                log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'closed contract status', sqlerrm);
                            end;  
                            ----------------------------------
                            flag := 10;

                            l_ownership := 'Individual'; --Ownership Type
                            l_ct_currency := r2.DOVIZ_KODU; --Currency of Contract
                                            
                            --Total Amount--------------------
                            l_total_amount := null;    

                            --Total Taken Amount--------------
                            --Number of Installments----------
                            --Next Payment Date--------------- 
                            l_account_taken_amt := 0;
                            l_total_taken_amt := 0; 
                            li_account_installments := 0;
                            ln_total_installments := 0;
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                l_total_taken_amt := r2.ONERILEN_LIMIT_YP;
                            else    
                                for r3 in cur_main_accs(r2.TEKLIF_SATIR_NO) --kredi hesaplar  
                                    loop  
                                        if(r3.URUN_TUR_KOD <> 'RT-CARD') then
                                            begin
                                                if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r3.DOVIZ_KODU, l_ct_currency, r3.ACILIS_TARIHI, r3.TUTAR, null, null, null, 'N', null, l_account_taken_amt) = 1) then
                                                    if(l_account_taken_amt is null) then
                                                        l_account_taken_amt := 0;
                                                    end if;    
                                                    l_total_taken_amt := l_total_taken_amt + l_account_taken_amt; --Total Taken Amount
                                                else
                                                    --log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', 'zero result');
                                                    l_account_taken_amt := 0;
                                                end if;
                                            exception
                                                when others then
                                                    log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', sqlerrm);
                                            end;  
                                        end if;  
                                        flag := 11;  
                                        begin 
                                            select count(1) --count number of active installments in account
                                            into li_account_installments
                                            from cbs_hesap_kredi_taksit
                                            where durum_kodu = 'A'
                                            and hesap_no = r3.hesap_no;
                                                                        
                                            ln_total_installments := ln_total_installments + li_account_installments; --Number of Installments
                                        exception when others then
                                            log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total installments', sqlerrm);
                                        end;
                                        flag := 12;                
                                                                   
                                    end loop;
                            end if;    
                            ----------------------------------
                            --ls_payment_periodicity := 'Days30'; --Payment Periodicity
                            --l_installment_type := '@@@@@'; --Installment Type
                            --l_installment_amt := 999.99; --Installment Amount --if type of installment is not fixed which should be the value? 

                            --Number of Due Installments
                            --Principal Outstanding Amount 
                            --PastDue Amount
                            --It is suggested by Maksat Dolotbakov not to report Faiz and Tax in PastDue Amount
                            --So, the total pastdue amount contains only Anapara(Main) PastDue amount
                            l_account_outstand_amt := 0;
                            l_total_outstand_amt := 0;
                            l_total_pastdue_amt := 0;
                            ld_pd_main_open_date_min := trunc(sysdate);
                            li_pd_installments := 0;
                                            
                            for r4 in cur_active_main_and_pd_anapara(r2.TEKLIF_SATIR_NO) --main and pastdue main accs. Both active 
                                loop
                                    if(r4.URUN_TUR_KOD not in ('RT-CARD', 'PD-CARD')) then
                                        begin  
                                            if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r4.DOVIZ_KODU, l_ct_currency, r4.ACILIS_TARIHI, PKG_KREDI.SF_BAKIYE_AL(r4.HESAP_NO) * -1, null, null, null, 'N', null, l_account_outstand_amt) = 1) then
                                                if(l_account_outstand_amt is null) then
                                                    l_account_outstand_amt := 0;
                                                end if;
                                                l_total_outstand_amt := l_total_outstand_amt + l_account_outstand_amt; --Principal Outstanding Amount
                                            else
                                                --log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', 'zero or null input, just for info, delete this record');
                                                l_account_outstand_amt := 0;
                                            end if;        
                                        exception
                                            when others then
                                                log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', sqlerrm);
                                        end;
                                        flag := 13;                
                                        begin
                                            if(r4.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' and l_account_outstand_amt > 0) then --include only Anapara PastDue accounts whose balance > 0
                                                li_pd_installments := li_pd_installments + 1; --Number of Due Installments
                                                l_total_pastdue_amt := l_total_pastdue_amt + l_account_outstand_amt; --PastDue Amount      
                                                if(r4.ACILIS_TARIHI < ld_pd_main_open_date_min) then
                                                    ld_pd_main_open_date_min := r4.ACILIS_TARIHI;
                                                end if;
                                            end if;
                                        exception when others then
                                            log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total pastdue amt', sqlerrm);
                                        end;
                                    end if;
                                end loop;
                                
                            --Past Due days------------------------
                            --if contract is Closed OR (Open and has no active Past due accounts) then ld_pd_main_open_date_min equals sysdate
                            li_pd_days := trunc(sysdate) - ld_pd_main_open_date_min;    
                            ---------------------------------------
                            flag := 14; 
                                           
                            --Start date---------------------------    
                            if(lb_flag) then --for these credit types all ever created proposals are considered 
                                open cur_start_date_1(r2.TEKLIF_SATIR_NO);
                                fetch cur_start_date_1 into row_start_date_1;
                                close cur_start_date_1;
                                ld_start_date := row_start_date_1.start_date;                            
                            else
                                open cur_start_date_2(r2.TEKLIF_SATIR_NO);
                                fetch cur_start_date_2 into row_start_date_2;
                                close cur_start_date_2;
                                ld_start_date := row_start_date_2.start_date;                           
                            end if;
                            ---------------------------------------
                            flag := 15;
                            
                            ln_cust_code := r2.MUSTERI_NO; --Customer Code
                            
                            select soyadi, isim, ikinci_isim, decode(musteri_tipi_kod, 1, 'Individual', 2, 'SoleTrader', 3, null), 
                                decode(musteri_tipi_kod, 3, null, decode(cinsiyet_kod, 'M', 'Male', 'F', 'Female', 'NotSpecified')), dogum_tarihi,
                                decode(musteri_tipi_kod, 3, null, decode(medeni_hal_kod, 1, 'Single', 2, 'Married', 3, 'Divorced', 'Other')), 
                                decode(musteri_tipi_kod, 3, null, decode(NUFUS_CUZDANI_SERI_NO, null, PASAPORT_NO, NUFUS_CUZDANI_SERI_NO)), TICARI_UNVAN      
                            into ls_ind_surname, ls_ind_firstname, ls_ind_patronymic, ls_ind_class, ls_ind_gender, ld_ind_birthdate, ls_ind_marital, ls_ind_passno, ls_com_name
                            from cbs_musteri
                            where musteri_no = ln_cust_code;  
                            flag := 16;  
                            ls_ind_fullname := ls_ind_surname||' '||ls_ind_firstname||' '||ls_ind_patronymic;
                                                
                            ls_address := PKG_MUSTERI.SF_ADRES_AL(ln_cust_code); --Address Line 
                            ls_citizenship := PKG_MUSTERI.SF_UYRUKKOD_AL(ln_cust_code); --Citizenship/Registration Country
                            if(ls_citizenship = 'KG') then
                                ls_inn_t := PKG_MUSTERI.SF_VERGINO_AL(ln_cust_code);
                                if(length(ls_inn_t)=14) then
                                    --check gender digit
                                    if(ls_ind_class is not null) then
                                        case(ls_ind_gender)
                                            when 'Male' then 
                                                if(substr(ls_inn_t, 1, 1) != '2') then
                                                    raise_application_error(-20100, 'incorrect inn for male: '||ls_inn_t||'; customer: '||ln_cust_code);
                                                end if;  
                                            when 'Female' then
                                                if(substr(ls_inn_t, 1, 1) != '1') then
                                                    raise_application_error(-20100, 'incorrect inn for female: '||ls_inn_t||'; customer: '||ln_cust_code);
                                                end if;     
                                        end case;
                                    end if;    
                                    
                                    --check date digits
                                    begin
                                        ls_bd := substr(ls_inn_t, 2, 8);
                                        ld_bd := to_date(ls_bd, 'ddmmyyyy');
                                        if((ls_ind_class is not null) and (ld_bd != ld_ind_birthdate)) then
                                            raise ex_date;
                                        end if;
                                    exception when ex_date then
                                        raise_application_error(-20100, 'incorrect birthdate in inn : '||ls_inn_t||', birthdate: '||ld_ind_birthdate||'; customer: '||ln_cust_code);
                                    when others then
                                        raise_application_error(-20100, 'wrong date digits in inn: '||ls_inn_t||', date digits: '||ls_bd||'; customer: '||ln_cust_code);                           
                                    end;
                                    ls_inn := ls_inn_t; --Social Security Number/INN
                                else
                                    raise_application_error(-20100, 'incorrect or empty inn: '||ls_inn_t||'; customer: '||ln_cust_code);
                                end if;                      
                            else      
                                ls_inn := null;
                            end if;                    
                            flag := 17; 
                               
                            if(ls_ind_class is null) then
                                ld_com_est_date := ld_bd;
                                if(ls_inn is not null) then
                                   begin
                                       stringdate_from_inn := substr(ls_inn, 2,8);
                                       ld_com_est_date := to_date(stringdate_from_inn, 'DDMMYYYY');
                                   exception when others then
                                       log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; INN: '||ls_inn, 'establishment date', sqlerrm);
                                   end;
                                else
                                    log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'establishment date', 'no inn');    
                                end if;    
                            else
                                ld_com_est_date := null;    
                            end if;
                            flag := 18;

                            begin
                                insert into CBS_NEWCIB_DATA(
                                    REPORT_DATE,
                                    DAY_OR_MONTH,
                                    BATCH_NO,
                                    CT_CODE, 
                                    BRANCH, 
                                    BRANCH_REGION, 
                                    CT_PHASE, 
                                    CT_STATUS,
                                    CT_TYPE,
                                    OWNERSHIP,
                                    CT_CURRENCY,
                                    TOTAL_AMOUNT,
                                    TOTAL_TAKEN_AMOUNT,
                                    NUMBER_OF_ISTALLMENTS,
                                    PRINCIPAL_OUTSTANDING_AMT,
                                    PAST_DUE_AMT,
                                    PAST_DUE_DAYS,
                                    NUMBER_OF_DUE_INSTALLMENTS,
                                    --NEXT_PAYMENT_DATE,
                                    --PAYMENT_PERIODICITY,
                                    START_DATE,
                                    EXPECTED_END_DATE,
                                    REAL_END_DATE,
                                    CUSTOMER_CODE,
                                    INN,
                                    ADDRESS_LINE,
                                    CITIZENSHIP,
                                    IND_SURNAME,
                                    IND_FIRSTNAME,
                                    IND_PATRONYMIC,
                                    IND_FULLNAME,
                                    IND_CLASS,
                                    IND_GENDER,
                                    IND_BIRTHDATE,
                                    IND_MARITAL,
                                    IND_PASS_NO,
                                    COM_NAME,
                                    COM_EST_DATE
                                ) values(
                                    trunc(sysdate),
                                    'M',
                                    ln_batch_no,
                                    l_ct_code,
                                    l_branch,
                                    l_branch_region,
                                    l_ct_phase,
                                    l_ct_status,
                                    l_ct_type,
                                    l_ownership,
                                    l_ct_currency,
                                    l_total_amount,
                                    l_total_taken_amt,
                                    ln_total_installments,
                                    l_total_outstand_amt,
                                    l_total_pastdue_amt,
                                    li_pd_days,
                                    li_pd_installments,
                                    --ld_next_pay_date,
                                    --ls_payment_periodicity,
                                    ld_start_date,
                                    ld_expected_end_date,
                                    ld_real_end_date,
                                    ln_cust_code,
                                    ls_inn,
                                    ls_address,
                                    ls_citizenship,
                                    ls_ind_surname,
                                    ls_ind_firstname,
                                    ls_ind_patronymic,
                                    ls_ind_fullname,
                                    ls_ind_class,
                                    ls_ind_gender,
                                    ld_ind_birthdate,
                                    ls_ind_marital,
                                    ls_ind_passno,
                                    ls_com_name,
                                    ld_com_est_date
                                );
                                if(n>30) then
                                    commit;
                                    n:=0;
                                else
                                    n:=n+1;
                                end if;        
                            exception
                                when others then
                                    log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'insert into table', sqlerrm);
                            end;
                        else
                            log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'Closed but real end date is null');    
                        end if;
                    else
                        log_at('cbs_newcib_data_collect_error_inactive', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'Inactive but phase is '||l_ct_phase);
                    end if;
                end if;
            exception when others then
                log_at('cbs_newcib_data_collect_error_inactive', 'TX NO: '||r2.tx_no ||'; Proposal: '||r2.teklif_no||'; Credit line: '||r2.TEKLIF_SATIR_NO||' date: '||trunc(sysdate)||'; batch no: '||ln_batch_no, 'main node '||flag, sqlerrm);
            end;  
        end loop;
end;

procedure collect_today is

cursor cur_proposal_lines is
select si.TX_NO, T.TEKLIF_NO, T.MUSTERI_NO, T.DURUM_KODU, si.TEKLIF_SATIR_NO, si.LINE, si.TRANCHES, si.KREDI_TURU, si.KREDI_KULLANDIRIM_KODU, si.ONERILEN_LIMIT_YP, si.REAL_LIMIT, si.DOVIZ_KODU
       FROM cbs_kredi_teklif t, cbs_kredi_teklif_islem a, cbs_islem b, cbs_kredi_teklif_satir_islem si
      WHERE     a.teklif_no = t.teklif_no
            AND a.tx_no = b.numara
            AND a.islem_tanim_kod = 1302
            and t.DURUM_KODU in ('A')
            and A.DURUM_KODU = 'A'
            and B.DURUM = 'P' 
            and SI.TX_NO = B.NUMARA
            and to_date(b.kayit_sistem_tarihi, 'DD/MM/YYYY') = to_date(sysdate, 'DD/MM/YYYY')
            and SI.TEKLIF_NO = A.TEKLIF_NO
            and exists (select 1 from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and 
            (select count(1) from CBS_HESAP_kredi where KREDI_TEKLIF_SATIR_NUMARA = si.TEKLIF_SATIR_NO and urun_tur_kod in ('DEPO', 'LNGV', 'LOAN GIVEN', 'PLACEMENT', 'IMPORT L/C')) = 0);

cursor cur_main_accs(l_teklif_satir_no number) is
select *
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

cursor cur_active_main_and_pd_anapara(l_teklif_satir_no number) is
select * 
from CBS_HESAP_kredi
where KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no
and durum_kodu in ('A')
and (ANA_KREDI_HESAP_NO is null or PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA')
and URUN_TUR_KOD NOT IN ('CRD.CARD');--exclude overlimit account;

cursor cur_start_date_1(l_teklif_satir_no number) is
select min(nvl(nvl(nvl(b.ONAY_TARIH, b.TAMAMLANMA_TARIHI), B.DOGRU_TARIH), A.TEKLIF_TARIHI)) as start_date
from cbs_kredi_teklif t, cbs_kredi_teklif_islem a, cbs_islem b, cbs_kredi_teklif_satir_islem tt 
where A.TEKLIF_NO = T.TEKLIF_NO
and A.TX_NO = B.NUMARA
and T.DURUM_KODU in ('A', 'K') -- 'K' include inactive proposals too 
and A.DURUM_KODU = 'A'
and B.DURUM in ('P', '3')
and TT.TX_NO = B.NUMARA
and TT.TEKLIF_NO = A.TEKLIF_NO
and TT.TEKLIF_SATIR_NO = l_teklif_satir_no;

cursor cur_start_date_2(l_teklif_satir_no number) is
select min(acilis_tarihi) as start_date
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;

row_start_date_1 cur_start_date_1%rowtype;
row_start_date_2 cur_start_date_2%rowtype;

ex_date exception;

l_ct_code CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.TEKLIF_SATIR_NO%type;
l_branch CBS.CBS_ISLEM.amir_bolum_kodu%type;
l_branch_region CBS.CBS_CIB_BRANCHES.CIB_ITEM_VALUE%type;
ld_expected_end_date date;
l_ct_phase CBS.cbs_newcib_data.CT_PHASE%type;
l_ct_status CBS.cbs_newcib_data.CT_STATUS%type;
ld_real_end_date date;
l_ct_type CBS.cbs_newcib_data.CT_TYPE%type;
l_ownership CBS.cbs_newcib_data.OWNERSHIP%type;
l_purpose CBS.CBS_NEWCIB_DATA.PURPOSE%type;
l_ct_currency CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.DOVIZ_KODU%type;
l_total_amount CBS.CBS_KREDI_TEKLIF_SATIR_ISLEM.ONERILEN_LIMIT_YP%type;
l_total_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
ln_total_installments integer;
l_installment_type CBS.cbs_newcib_data.INSTALLMENT_TYPE%type;
l_installment_amt CBS.cbs_newcib_data.INSTALLMENT_AMT%type;
l_total_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_installments integer;
l_total_pastdue_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
li_pd_days integer;
ld_start_date date;
ld_next_pay_date date;
ls_payment_periodicity varchar2(10);

ln_cust_code number;
ls_inn varchar2(14);
ls_inn_t varchar2(128);
ls_address varchar2(256);
ls_citizenship varchar2(2);
ls_ind_surname varchar2(64);
ls_ind_firstname varchar2(64);
ls_ind_patronymic varchar2(128);
ls_ind_fullname varchar2(128);
ls_ind_class varchar2(10);
ls_ind_gender varchar2(15);
ld_ind_birthdate date;
ls_ind_marital varchar2(15);
ls_ind_passno varchar2(32);
ld_ind_pass_iss_date date;
ld_ind_pass_exp_date date;
ld_ind_pass_iss_country varchar2(2);
ld_ind_pass_iss_auth varchar2(256);
ls_com_name varchar2(128);
ls_com_legal_form varchar2(128);
ld_com_est_date date;
ls_com_economic_sector varchar2(2);

li_active_credit_accounts integer;
li_closed_credit_accounts integer;
l_account_taken_amt CBS.CBS_HESAP_KREDI.TUTAR%type;
li_account_installments integer;
l_account_outstand_amt CBS.CBS_HESAP_BAKIYE.BAKIYE%type;
ld_pd_main_open_date_min date;
ld_min_pay_date date;
stringdate_from_inn varchar2(8);
ln_batch_no integer;
ln_c integer;
ln_card_count integer;
lb_flag boolean;
ls_bd varchar2(8);
ld_bd date;

flag integer; --flag is used to point to possible position of exception
n integer := 0;

begin
    select max(batch_no)
    into ln_c
    from CBS_NEWCIB_DATA
    where REPORT_DATE = trunc(sysdate);
    
    flag := 1;
                            
    if(nvl(ln_c, 0) = 0) then
        ln_batch_no := 1;
    else
        ln_batch_no := ln_c + 1;                
    end if;
    for r2 in cur_proposal_lines --proposal lines (contracts)
        loop
            begin
                if(PKG_MUSTERI.SF_MUSTERI_TIPI_AL(r2.musteri_no) in (1,2,3)) then
                
                    --Expected End date--------------------
                    begin
                        flag := 1;                
                        if(r2.LINE = 'YES' or r2.TRANCHES = 'Y' or r2.KREDI_TURU in (13, 14, 31)) then
                            select max(VALIDITY_DATE_OF_LINE)
                            into ld_expected_end_date
                            from CBS_KREDI_TEKLIF_LIMIT  
                            where TEKLIF_NO = r2.teklif_no;
                            if(r2.KREDI_TURU in (13, 14, 31) and ld_expected_end_date is null) then
                                ld_expected_end_date := to_date('01012999', 'ddmmyyyy');
                            end if;
                        else
                            select max(KREDI_VADE)
                            into ld_expected_end_date
                            from CBS_HESAP_kredi
                            where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                            and durum_kodu in ('A', 'K')
                            and ANA_KREDI_HESAP_NO is null;
                        end if;
                        flag := 2;
                    exception when others then
                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'expected end date', sqlerrm);
                    end;    
                    ---------------------------------------
                    
                    --phase of contract--------------------
                    begin
                        -- Phase of Contract
                        -- Contract Status for Open
                        if (r2.KREDI_TURU in (13, 14, 31)) then
                            if(r2.ONERILEN_LIMIT_YP = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0) then
                                l_ct_phase := 'Closed';
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';
                            end if;                           
                        elsif (r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                            if(r2.ONERILEN_LIMIT_YP = 0 or r2.REAL_LIMIT = 0 or (trunc(sysdate) - trunc(ld_expected_end_date)) > 0 ) then
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts > 0) then
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                else
                                    l_ct_phase := 'Closed';
                                end if;
                            else
                                l_ct_phase := 'Open';
                                l_ct_status := 'GrantedAndActivated';    
                            end if;
                        else
                            if(r2.ONERILEN_LIMIT_YP = 0) then
                                l_ct_phase := 'Closed';
                            else
                                select count(1)
                                into li_active_credit_accounts
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'A'
                                and TUTAR != 0;
                                if(li_active_credit_accounts = 0) then --if no active accs then check whether there is any closed account to define credit proposal new or not
                                    select count(1)
                                    into li_closed_credit_accounts
                                    from cbs_hesap_kredi
                                    where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                    and DURUM_KODU = 'K';
                                    if(li_closed_credit_accounts = 0) then --if no closed accs then credit proposal is new
                                        l_ct_phase := 'Open';
                                        l_ct_status := 'GrantedAndActivated';
                                    else    
                                        l_ct_phase := 'Closed';
                                    end if;
                                else
                                    l_ct_phase := 'Open';
                                    l_ct_status := 'GrantedAndActivated';
                                end if;
                            end if;
                        end if;
                        flag := 3;
                    exception
                        when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'phase of contract', sqlerrm);
                            l_ct_phase := 'unkn';
                            l_ct_status := 'unkn';
                    end;
                                    
                    --Real end date-------------------
                    ld_real_end_date := null;
                    begin                                
                        if(l_ct_phase = 'Closed') then
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                begin
                                    
                                    if(r2.ONERILEN_LIMIT_YP != 0) then
                                        --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'Credit card closed by date');
                                        ld_real_end_date := ld_expected_end_date;
                                    else
                                        select max(I.KAYIT_TARIH) 
                                        into ld_real_end_date
                                        from cbs_kredi_teklif_satir_islem si, cbs_islem i
                                        where si.TEKLIF_SATIR_NO = r2.TEKLIF_SATIR_NO
                                        and SI.TEKLIF_NO = r2.teklif_no
                                        and SI.ONERILEN_LIMIT_YP = 0
                                        and SI.TX_NO = I.NUMARA
                                        and I.DURUM in ('P', '3')
                                        and I.ISLEM_KOD = 1302;
                                    end if;    
                                    
                                exception
                                    when no_data_found then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', 'not found');
                                    when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'credit card real end date', sqlerrm);                               
                                end;
                            else
                                select max(KAPANIS_TARIHI)
                                into ld_real_end_date
                                from cbs_hesap_kredi
                                where KREDI_TEKLIF_SATIR_NUMARA = r2.TEKLIF_SATIR_NO
                                and DURUM_KODU = 'K'; 
                            end if;        
                        end if;
                    exception when others then
                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'real end date', sqlerrm);    
                    end;
                    ----------------------------------
                    
                    if(ld_real_end_date is null or (extract(year from ld_real_end_date) in (2018))) then   
                    --if(true) then
                                  
                        l_ct_code := r2.TEKLIF_SATIR_NO; --Contract Code
                        l_branch := PKG_GENEL.AMIR_BOLUM_NO_AL(r2.TX_NO); --Branch
                        flag := 4;                
                        begin
                            select CIB_ITEM_VALUE
                            into l_branch_region --Branch Region Lookup
                            from cbs_cib_branches
                            where CBS_BRANCH_CODE = l_branch;
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; Branch: '||l_branch, 'branch', sqlerrm);
                            l_branch_region := '41711000000000';
                        end;
                        flag := 5;
                         
                        --Type of Contract----------------
                        --Purpose of Financing------------
                        lb_flag := false; -- flag used when defining start date of contract
                        l_ct_type := null;
                        l_purpose := null;
                        begin
                            flag := 6;
                            if(r2.KREDI_TURU in (13, 14, 31)) then
                                l_ct_type := 'CreditCard';
                                l_purpose := 'PersonalLoan';
                                lb_flag := true;
                            else
                                flag := 7;
                                if(r2.LINE = 'YES' or r2.TRANCHES = 'Y') then
                                    l_ct_type := 'RevolvingCredit';
                                    lb_flag := true;
                                else
                                    if(r2.KREDI_KULLANDIRIM_KODU in (13,14,17,26)) then
                                        l_ct_type := 'Installment';
                                        if(r2.KREDI_KULLANDIRIM_KODU in (13,14)) then
                                            l_purpose := 'Construct';
                                        elsif(r2.KREDI_KULLANDIRIM_KODU in (26)) then
                                            l_purpose := 'PersonalMotorVehicle';
                                        end if;
                                    else    
                                        flag := 8;
                                        if(r2.KREDI_TURU in (23,58,15,67,71,68,69,70,22,35,17,12,24,16)) then
                                            l_ct_type := 'Installment';
                                            if(r2.KREDI_TURU in(22,35,17,12)) then
                                                l_purpose := 'Mortgage';
                                            elsif(r2.KREDI_TURU in (69,70)) then
                                                l_purpose := 'Industry';   
                                            elsif(r2.KREDI_TURU in (67,68,71)) then
                                                l_purpose := 'Agriculture';     
                                            end if;
                                        elsif(r2.KREDI_TURU in (36,7,9,37,8,10,18,19,20)) then
                                            l_ct_type := 'NonInstallment';
                                            lb_flag := true;
                                            if(r2.KREDI_TURU in (36,7,9,37,8,10)) then
                                                l_purpose := 'TradeFinanceFacility';
                                            end if;          
                                        end if;
                                    end if;       
                                end if;
                            end if;    
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'type of contract', sqlerrm);
                        end;         
                        ----------------------------------                                           
                        flag := 9;
         
                        --Contract Status for Closed------
                        begin
                            if(l_ct_phase = 'Closed') then
                                if(trunc(ld_expected_end_date) - trunc(ld_real_end_date) < 0) then
                                    l_ct_status := 'SettledLate';
                                elsif(trunc(ld_expected_end_date) - trunc(ld_real_end_date) = 0) then
                                    l_ct_status := 'SettledOnTime';
                                else
                                    l_ct_status := 'SettledInAdvance';
                                end if;
                            end if;    
                        exception when others then
                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'closed contract status', sqlerrm);
                        end;  
                        ----------------------------------
                        flag := 10;

                        l_ownership := 'Individual'; --Ownership Type
                        l_ct_currency := r2.DOVIZ_KODU; --Currency of Contract
                                        
                        --Total Amount--------------------
                        if(l_ct_phase = 'Open') then
                            l_total_amount := r2.ONERILEN_LIMIT_YP; --Total Amount
                        else
                            l_total_amount := null;    
                        end if;
                        

                        --Total Taken Amount--------------
                        --Number of Installments----------
                        --Next Payment Date--------------- 
                        l_account_taken_amt := 0;
                        l_total_taken_amt := 0; 
                        li_account_installments := 0;
                        ln_total_installments := 0;
                        ld_next_pay_date := null;
                        if(r2.KREDI_TURU in (13, 14, 31)) then
                            l_total_taken_amt := r2.ONERILEN_LIMIT_YP;
                        else    
                            for r3 in cur_main_accs(r2.TEKLIF_SATIR_NO) --kredi hesaplar  
                                loop  
                                    if(r3.URUN_TUR_KOD <> 'RT-CARD') then
                                        begin
                                            if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r3.DOVIZ_KODU, l_ct_currency, r3.ACILIS_TARIHI, r3.TUTAR, null, null, null, 'N', null, l_account_taken_amt) = 1) then
                                                if(l_account_taken_amt is null) then
                                                    l_account_taken_amt := 0;
                                                end if;    
                                                l_total_taken_amt := l_total_taken_amt + l_account_taken_amt; --Total Taken Amount
                                            else
                                                --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', 'zero result');
                                                l_account_taken_amt := 0;
                                            end if;
                                        exception
                                            when others then
                                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total taken amt', sqlerrm);
                                        end;  
                                    end if;  
                                    flag := 11;  
                                    begin 
                                        select count(1) --count number of active installments in account
                                        into li_account_installments
                                        from cbs_hesap_kredi_taksit
                                        where durum_kodu = 'A'
                                        and hesap_no = r3.hesap_no;
                                                                    
                                        ln_total_installments := ln_total_installments + li_account_installments; --Number of Installments
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'total installments', sqlerrm);
                                    end;
                                    flag := 12;                
                                    begin
                                        select min(vade_tarih)
                                        into ld_min_pay_date
                                        from cbs_hesap_kredi_taksit
                                        where durum_kodu = 'A'
                                        and hesap_no = r3.hesap_no
                                        and vade_tarih > trunc(sysdate);
                                                        
                                        if(ld_next_pay_date is null or ld_next_pay_date > ld_min_pay_date) then
                                            ld_next_pay_date := ld_min_pay_date; --Next Payment Date
                                        end if;
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r3.HESAP_NO, 'next payment date', sqlerrm);
                                    end;
                                                               
                                end loop;
                        end if;    
                        ----------------------------------
                        ls_payment_periodicity := 'Days30'; --Payment Periodicity
                        --l_installment_type := '@@@@@'; --Installment Type
                        --l_installment_amt := 999.99; --Installment Amount --if type of installment is not fixed which should be the value? 

                        --Number of Due Installments
                        --Principal Outstanding Amount 
                        --PastDue Amount
                        --It is suggested by Maksat Dolotbakov not to report Faiz and Tax in PastDue Amount
                        --So, the total pastdue amount contains only Anapara(Main) PastDue amount
                        l_account_outstand_amt := 0;
                        l_total_outstand_amt := 0;
                        l_total_pastdue_amt := 0;
                        ld_pd_main_open_date_min := trunc(sysdate);
                        li_pd_installments := 0;
                                        
                        for r4 in cur_active_main_and_pd_anapara(r2.TEKLIF_SATIR_NO) --main and pastdue main accs. Both active 
                            loop
                                if(r4.URUN_TUR_KOD not in ('RT-CARD', 'PD-CARD')) then
                                    begin  
                                        if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r4.DOVIZ_KODU, l_ct_currency, r4.ACILIS_TARIHI, PKG_KREDI.SF_BAKIYE_AL(r4.HESAP_NO) * -1, null, null, null, 'N', null, l_account_outstand_amt) = 1) then
                                            if(l_account_outstand_amt is null) then
                                                l_account_outstand_amt := 0;
                                            end if;
                                            l_total_outstand_amt := l_total_outstand_amt + l_account_outstand_amt; --Principal Outstanding Amount
                                        else
                                            --log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', 'zero or null input, just for info, delete this record');
                                            l_account_outstand_amt := 0;
                                        end if;        
                                    exception
                                        when others then
                                            log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total outstanding amt', sqlerrm);
                                    end;
                                    flag := 13;                
                                    begin
                                        if(r4.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' and l_account_outstand_amt > 0) then --include only Anapara PastDue accounts whose balance > 0
                                            li_pd_installments := li_pd_installments + 1; --Number of Due Installments
                                            l_total_pastdue_amt := l_total_pastdue_amt + l_account_outstand_amt; --PastDue Amount      
                                            if(r4.ACILIS_TARIHI < ld_pd_main_open_date_min) then
                                                ld_pd_main_open_date_min := r4.ACILIS_TARIHI;
                                            end if;
                                        end if;
                                    exception when others then
                                        log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; hesap: '||r4.HESAP_NO, 'total pastdue amt', sqlerrm);
                                    end;
                                end if;
                            end loop;
                            
                        --Past Due days------------------------
                        --if contract is Closed OR (Open and has no active Past due accounts) then ld_pd_main_open_date_min equals sysdate
                        li_pd_days := trunc(sysdate) - ld_pd_main_open_date_min;    
                        ---------------------------------------
                        flag := 14; 
                                       
                        --Start date---------------------------    
                        if(lb_flag) then --for these credit types all ever created proposals are considered 
                            open cur_start_date_1(r2.TEKLIF_SATIR_NO);
                            fetch cur_start_date_1 into row_start_date_1;
                            close cur_start_date_1;
                            ld_start_date := row_start_date_1.start_date;                            
                        else
                            open cur_start_date_2(r2.TEKLIF_SATIR_NO);
                            fetch cur_start_date_2 into row_start_date_2;
                            close cur_start_date_2;
                            ld_start_date := row_start_date_2.start_date;                           
                        end if;
                        ---------------------------------------
                        flag := 15;
                        
                        ln_cust_code := r2.MUSTERI_NO; --Customer Code
                        
                        select soyadi, isim, ikinci_isim, decode(musteri_tipi_kod, 1, 'Individual', 2, 'SoleTrader', 3, null), 
                            decode(musteri_tipi_kod, 3, null, decode(cinsiyet_kod, 'M', 'Male', 'F', 'Female', 'NotSpecified')), dogum_tarihi,
                            decode(musteri_tipi_kod, 3, null, decode(medeni_hal_kod, 1, 'Single', 2, 'Married', 3, 'Divorced', 'Other')), 
                            decode(musteri_tipi_kod, 3, null, decode(NUFUS_CUZDANI_SERI_NO, null, PASAPORT_NO, NUFUS_CUZDANI_SERI_NO)), TICARI_UNVAN      
                        into ls_ind_surname, ls_ind_firstname, ls_ind_patronymic, ls_ind_class, ls_ind_gender, ld_ind_birthdate, ls_ind_marital, ls_ind_passno, ls_com_name
                        from cbs_musteri
                        where musteri_no = ln_cust_code;  
                        flag := 16;  
                        ls_ind_fullname := ls_ind_surname||' '||ls_ind_firstname||' '||ls_ind_patronymic;
                                            
                        ls_address := PKG_MUSTERI.SF_ADRES_AL(ln_cust_code); --Address Line 
                        ls_citizenship := PKG_MUSTERI.SF_UYRUKKOD_AL(ln_cust_code); --Citizenship/Registration Country
                        if(ls_citizenship = 'KG') then
                            ls_inn_t := PKG_MUSTERI.SF_VERGINO_AL(ln_cust_code);
                            if(length(ls_inn_t)=14) then
                                --check gender digit
                                if(ls_ind_class is not null) then
                                    case(ls_ind_gender)
                                        when 'Male' then 
                                            if(substr(ls_inn_t, 1, 1) != '2') then
                                                raise_application_error(-20100, 'incorrect inn for male: '||ls_inn_t||'; customer: '||ln_cust_code);
                                            end if;  
                                        when 'Female' then
                                            if(substr(ls_inn_t, 1, 1) != '1') then
                                                raise_application_error(-20100, 'incorrect inn for female: '||ls_inn_t||'; customer: '||ln_cust_code);
                                            end if;     
                                   end case;
                                end if;    
                                
                                --check date digits
                                begin
                                    ls_bd := substr(ls_inn_t, 2, 8);
                                    ld_bd := to_date(ls_bd, 'ddmmyyyy');
                                    if((ls_ind_class is not null) and (ld_bd != ld_ind_birthdate)) then
                                        raise ex_date;
                                    end if;
                                exception when ex_date then
                                    raise_application_error(-20100, 'incorrect birthdate in inn : '||ls_inn_t||', birthdate: '||ld_ind_birthdate||'; customer: '||ln_cust_code);
                                when others then
                                    raise_application_error(-20100, 'wrong date digits in inn: '||ls_inn_t||', date digits: '||ls_bd||'; customer: '||ln_cust_code);                           
                                end;
                                ls_inn := ls_inn_t; --Social Security Number/INN
                            else
                                raise_application_error(-20100, 'incorrect or empty inn: '||ls_inn_t||'; customer: '||ln_cust_code);
                            end if;                      
                        else      
                            ls_inn := null;
                        end if;                    
                        flag := 17; 
                           
                        if(ls_ind_class is null) then
                            ld_com_est_date := ld_bd;
                            if(ls_inn is not null) then
                               begin
                                   stringdate_from_inn := substr(ls_inn, 2,8);
                                   ld_com_est_date := to_date(stringdate_from_inn, 'DDMMYYYY');
                                exception when others then
                                   log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO||'; INN: '||ls_inn, 'establishment date', sqlerrm);
                                end;
                            else
                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'establishment date', 'no inn');    
                            end if;   
                        else
                            ld_com_est_date := null;    
                        end if;
                        flag := 18;

                        begin
                            insert into CBS_NEWCIB_DATA(
                                REPORT_DATE,
                                DAY_OR_MONTH,
                                BATCH_NO,
                                CT_CODE, 
                                BRANCH, 
                                BRANCH_REGION, 
                                CT_PHASE, 
                                CT_STATUS,
                                CT_TYPE,
                                OWNERSHIP,
                                CT_CURRENCY,
                                TOTAL_AMOUNT,
                                TOTAL_TAKEN_AMOUNT,
                                NUMBER_OF_ISTALLMENTS,
                                PRINCIPAL_OUTSTANDING_AMT,
                                PAST_DUE_AMT,
                                PAST_DUE_DAYS,
                                NUMBER_OF_DUE_INSTALLMENTS,
                                NEXT_PAYMENT_DATE,
                                PAYMENT_PERIODICITY,
                                START_DATE,
                                EXPECTED_END_DATE,
                                REAL_END_DATE,
                                CUSTOMER_CODE,
                                INN,
                                ADDRESS_LINE,
                                CITIZENSHIP,
                                IND_SURNAME,
                                IND_FIRSTNAME,
                                IND_PATRONYMIC,
                                IND_FULLNAME,
                                IND_CLASS,
                                IND_GENDER,
                                IND_BIRTHDATE,
                                IND_MARITAL,
                                IND_PASS_NO,
                                COM_NAME,
                                COM_EST_DATE
                            ) values(
                                trunc(sysdate),
                                'D',
                                ln_batch_no,
                                l_ct_code,
                                l_branch,
                                l_branch_region,
                                l_ct_phase,
                                l_ct_status,
                                l_ct_type,
                                l_ownership,
                                l_ct_currency,
                                l_total_amount,
                                l_total_taken_amt,
                                ln_total_installments,
                                l_total_outstand_amt,
                                l_total_pastdue_amt,
                                li_pd_days,
                                li_pd_installments,
                                ld_next_pay_date,
                                ls_payment_periodicity,
                                ld_start_date,
                                ld_expected_end_date,
                                ld_real_end_date,
                                ln_cust_code,
                                ls_inn,
                                ls_address,
                                ls_citizenship,
                                ls_ind_surname,
                                ls_ind_firstname,
                                ls_ind_patronymic,
                                ls_ind_fullname,
                                ls_ind_class,
                                ls_ind_gender,
                                ld_ind_birthdate,
                                ls_ind_marital,
                                ls_ind_passno,
                                ls_com_name,
                                ld_com_est_date
                            );
                            if(n>30) then
                                commit;
                                n:=0;
                            else
                                n:=n+1;
                            end if;        
                        exception
                            when others then
                                log_at('cbs_newcib_data_collect_error', 'Credit line: '||r2.TEKLIF_SATIR_NO, 'insert into table', sqlerrm);
                        end;
                    end if;
                end if;
            exception when others then
                log_at('cbs_newcib_data_collect_error', 'TX NO: '||r2.tx_no ||'; Proposal: '||r2.teklif_no||'; Credit line: '||r2.TEKLIF_SATIR_NO||' date: '||trunc(sysdate)||'; batch no: '||ln_batch_no, 'main node '||flag, sqlerrm);
            end;  
        end loop;
end;

function sf_calculate_amounts(l_teklif_satir_no number, l_ct_currency varchar2) return number is 
cursor cur_main_accs(l_teklif_satir_no number) is
select *
from CBS_HESAP_kredi 
where durum_kodu in ('A', 'K')
and  ANA_KREDI_HESAP_NO is null
AND URUN_TUR_KOD NOT IN ('CRD.CARD') --exclude overlimit account
and KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no;
r3 cur_main_accs%rowtype;

cursor cur_active_main_and_pd_anapara(l_teklif_satir_no number) is
select * 
from CBS_HESAP_kredi
where KREDI_TEKLIF_SATIR_NUMARA = l_teklif_satir_no
and durum_kodu in ('A')
and (ANA_KREDI_HESAP_NO is null or PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA')
and URUN_TUR_KOD NOT IN ('CRD.CARD');--exclude overlimit account;
r4 cur_active_main_and_pd_anapara%rowtype;
ld_min_pay_date date;
l_account_outstand_amt number;
l_total_outstand_amt number;
l_total_pastdue_amt number;
ld_pd_main_open_date_min date;
li_pd_installments number;
l_account_taken_amt number;
li_account_installments number;

begin

--Total Taken Amount--------------
--Number of Installments----------
--Next Payment Date--------------- 
l_account_taken_amt := 0;
l_total_taken_amt := 0; 
li_account_installments := 0;
ln_total_installments := 0;
ld_next_pay_date := null;   
for r3 in cur_main_accs(l_TEKLIF_SATIR_NO) --kredi hesaplar  
    loop  
        if(r3.URUN_TUR_KOD <> 'RT-CARD') then
            begin
                if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r3.DOVIZ_KODU, l_ct_currency, r3.ACILIS_TARIHI, r3.TUTAR, null, null, null, 'N', null, l_account_taken_amt) = 1) then
                    if(l_account_taken_amt is null) then
                        l_account_taken_amt := 0;
                    end if;    
                    l_total_taken_amt := l_total_taken_amt + l_account_taken_amt; --Total Taken Amount
                else
                    l_account_taken_amt := 0;
                end if;
            exception
                when others then
                    return 0;
            end;  
        end if;
        begin
            select count(1) --count number of active installments in account
            into li_account_installments
            from cbs_hesap_kredi_taksit
            where durum_kodu = 'A'
            and hesap_no = r3.hesap_no;
                                                                    
            ln_total_installments := ln_total_installments + li_account_installments; --Number of Installments
        exception when others then
            return 0;
        end;
        begin
            select min(vade_tarih)
            into ld_min_pay_date
            from cbs_hesap_kredi_taksit
            where durum_kodu = 'A'
            and hesap_no = r3.hesap_no
            and vade_tarih > trunc(sysdate);
                                                        
            if(ld_next_pay_date is null or ld_next_pay_date > ld_min_pay_date) then
                ld_next_pay_date := ld_min_pay_date; --Next Payment Date
            end if;
        exception when others then
            return 0;
        end;
                                                               
    end loop; 

--Number of Due Installments
--Principal Outstanding Amount 
--PastDue Amount
--It is suggested by Maksat Dolotbakov not to report Faiz and Tax in PastDue Amount
--So, the total pastdue amount contains only Anapara(Main) PastDue amount
l_account_outstand_amt := 0;
l_total_outstand_amt := 0;
l_total_pastdue_amt := 0;
ld_pd_main_open_date_min := trunc(sysdate);
li_pd_installments := 0;
                                        
for r4 in cur_active_main_and_pd_anapara(l_TEKLIF_SATIR_NO) --main and pastdue main accs. Both active 
    loop
        if(r4.URUN_TUR_KOD not in ('RT-CARD', 'PD-CARD')) then
            begin  
                if(PKG_KUR.DOVIZ_DOVIZ_KARSILIK(r4.DOVIZ_KODU, l_ct_currency, r4.ACILIS_TARIHI, PKG_KREDI.SF_BAKIYE_AL(r4.HESAP_NO) * -1, null, null, null, 'N', null, l_account_outstand_amt) = 1) then
                    if(l_account_outstand_amt is null) then
                        l_account_outstand_amt := 0;
                    end if;
                    l_total_outstand_amt := l_total_outstand_amt + l_account_outstand_amt; --Principal Outstanding Amount
                else
                    l_account_outstand_amt := 0;
                end if;        
            exception
                when others then
                    return 0;
            end;         
            begin
                if(r4.PASTDUE_FAIZ_ANAPARA_SEC = 'ANAPARA' and l_account_outstand_amt > 0) then --include only Anapara PastDue accounts whose balance > 0
                    li_pd_installments := li_pd_installments + 1; --Number of Due Installments
                    l_total_pastdue_amt := l_total_pastdue_amt + l_account_outstand_amt; --PastDue Amount      
                    if(r4.ACILIS_TARIHI < ld_pd_main_open_date_min) then
                        ld_pd_main_open_date_min := r4.ACILIS_TARIHI;
                    end if;
                end if;
            exception when others then
                return 0;
            end;
        end if;
    end loop;
                            
--Past Due days------------------------
--if contract is Closed OR (Open and has no active Past due accounts) then ld_pd_main_open_date_min equals sysdate
li_pd_days := trunc(sysdate) - ld_pd_main_open_date_min;
return 1;
end;

function sf_get_tot_outstand_amt return number is
begin
return l_total_outstand_amt;
end;
function sf_get_tot_pastdue_amt return number is
begin
return l_total_pastdue_amt;
end;
function sf_get_tot_taken_amt return number is
begin
return l_total_taken_amt;
end;
function sf_get_tot_installments return number is
begin
return ln_total_installments;
end;
function sf_get_pd_days return number is
begin
return li_pd_days;
end;
function sf_get_pd_installments return number is
begin
return li_pd_installments;
end;
function sf_get_next_pay_date return date is
begin
return ld_next_pay_date;
end;

end;
/

