create PACKAGE BODY     PKG_DOCUMENT AS

  PROCEDURE GET_CUSTOMER_TYPE_CODE(PN_DOC_ID IN NUMBER, CUSTOMER_TYPE_CODE_LIST OUT CUSTOMER_TYPE_CODE_ARRAY) IS
    METADATA VARCHAR2(2000);
    JSON_LIST JSON_ARRAY_T := JSON_ARRAY_T();
  BEGIN
        SELECT JSON_QUERY(METADATA, '$.CustomerTypeCode')
          INTO METADATA
          FROM CBS.CBS_DOCUMENT_CODE 
         WHERE DOC_ID = PN_DOC_ID;
         
        IF METADATA IS NOT NULL THEN
          JSON_LIST := JSON_ARRAY_T(METADATA);
        
          FOR INDX IN 0 .. JSON_LIST.GET_SIZE - 1
          LOOP
            CUSTOMER_TYPE_CODE_LIST(INDX) := JSON_LIST.GET_NUMBER(INDX);
          END LOOP;             
        END IF;   
  END;
  
  PROCEDURE UPD_CUSTOMER_TYPE_CODE(PN_DOC_ID IN NUMBER, CUSTOMER_TYPE_CODE_LIST IN CUSTOMER_TYPE_CODE_ARRAY) IS
    JSON_DATA VARCHAR2(2000);
    JSON_LIST JSON_ARRAY_T := JSON_ARRAY_T();
    CUSTOMER_TYPE_CODE_OBJ JSON_OBJECT_T;
  BEGIN
        SELECT JSON_QUERY(METADATA, '$')
          INTO JSON_DATA
          FROM CBS.CBS_DOCUMENT_CODE
         WHERE DOC_ID = PN_DOC_ID;
         
        CUSTOMER_TYPE_CODE_OBJ := JSON_OBJECT_T.PARSE(JSON_DATA);
        
        IF CUSTOMER_TYPE_CODE_LIST.EXISTS(CUSTOMER_TYPE_CODE_LIST.FIRST) THEN
        
          FOR INDX IN CUSTOMER_TYPE_CODE_LIST.FIRST .. CUSTOMER_TYPE_CODE_LIST.LAST
          LOOP
              JSON_LIST.APPEND(CUSTOMER_TYPE_CODE_LIST(INDX));
          END LOOP;
          
          CUSTOMER_TYPE_CODE_OBJ.PUT('CustomerTypeCode', JSON_LIST);
        
          JSON_DATA := CUSTOMER_TYPE_CODE_OBJ.TO_STRING;
          
        ELSE
        
          SELECT JSON_OBJECTAGG('CustomerTypeCode' VALUE NULL)
            INTO JSON_DATA
            FROM DUAL;
             
        END IF;     
        
        UPDATE CBS.CBS_DOCUMENT_CODE 
           SET METADATA = JSON_DATA, CREATE_USER = USER, CREATED_DATE = SYSDATE 
         WHERE DOC_ID = PN_DOC_ID;
        
        COMMIT;
  END;
  
  FUNCTION GET_CUSTOMER_TYPE_CODE(PN_DOC_ID IN NUMBER) RETURN CLOB IS
    METADATA VARCHAR2(2000);
    RESPONSE CLOB;
    JSON_LIST JSON_ARRAY_T := JSON_ARRAY_T();
    RESPONSE_LIST JSON_ARRAY_T := JSON_ARRAY_T();
    RES_LIST CLOB;
    JSON_OBJ JSON_OBJECT_T := JSON_OBJECT_T;
  BEGIN
        SELECT JSON_QUERY(METADATA, '$.CustomerTypeCode')
          INTO METADATA
          FROM CBS.CBS_DOCUMENT_CODE 
         WHERE DOC_ID = PN_DOC_ID;
         
        IF METADATA IS NOT NULL THEN
          JSON_LIST := JSON_ARRAY_T(METADATA);
            
          FOR INDX IN 0 .. JSON_LIST.GET_SIZE - 1
          LOOP
            JSON_OBJ.PUT('CustomerTypeCode', JSON_LIST.GET_NUMBER(INDX));
            JSON_OBJ.PUT('Index', INDX + 1);
            RESPONSE_LIST.APPEND(JSON_OBJ);
          END LOOP;             
        END IF;
        
        RES_LIST := RESPONSE_LIST.TO_CLOB;
        
        SELECT JSON_QUERY(RES_LIST, '$' RETURNING CLOB PRETTY)
          INTO RESPONSE
          FROM DUAL;
         
    RETURN RESPONSE;
  END;
  
  FUNCTION CREATE_NEW_DOCUMENT(PS_DOC_NAME VARCHAR2) RETURN NUMBER IS
    DOC_NO NUMBER;
    JSON_DATA VARCHAR2(2000);
  BEGIN
        DOC_NO := CBS.PKG_GENEL.GENEL_KOD_AL('DOCNO');
    
        SELECT JSON_OBJECTAGG('CustomerTypeCode' VALUE NULL)
          INTO JSON_DATA
          FROM DUAL;
      
        INSERT INTO CBS.CBS_DOCUMENT_CODE(DOC_ID, DOC_NAME, METADATA) VALUES(DOC_NO, TRIM(PS_DOC_NAME), JSON_DATA);
    
        COMMIT;
    
        RETURN DOC_NO;
  END;
  
  PROCEDURE CREATE_VERSION_DOCUMENT(pn_doc_id NUMBER, ps_ctype VARCHAR2, ps_version VARCHAR2, pd_start_date DATE, pd_validity_date DATE, ps_descr VARCHAR2) IS
      ld_previous_version_date date;
  BEGIN
      INSERT INTO CBS.CBS_DOCUMENT_VERSION(DOC_ID, CUSTOMER_TYPE, DOC_VERSION, START_DATE, VALIDITY_DATE, EXPLANATION, CREATE_USER, CREATED_DATE)
      VALUES (pn_doc_id, ps_ctype, UPPER(ps_version), pd_start_date, pd_validity_date, ps_descr, USER, SYSDATE);

      --BOM YadgarB CBS-258
      BEGIN
          SELECT max(START_DATE)
          INTO ld_previous_version_date
          FROM CBS.CBS_DOCUMENT_VERSION
          WHERE DOC_ID = pn_doc_id
            AND CUSTOMER_TYPE = ps_ctype
            AND START_DATE < pd_start_date;

          UPDATE CBS.CBS_DOCUMENT_VERSION
          SET VALIDITY_DATE = (pd_start_date - 1)
          WHERE DOC_ID = pn_doc_id
            AND CUSTOMER_TYPE = ps_ctype
            AND START_DATE = ld_previous_version_date
            AND VALIDITY_DATE IS NULL;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
              NULL;
      END;
      --EOM YadgarB CBS-258

      COMMIT;
  END;
  
  PROCEDURE CHECK_VERSION_DOCUMENT(ps_ver VARCHAR2, ps_ctype VARCHAR2, pn_doc_id NUMBER) IS
    tmpVar NUMBER;
    duplicate_ver exception;
    first_latter_v exception;
  BEGIN
       tmpVar := 0;
       SELECT COUNT(*)
         INTO tmpVar
         FROM CBS.CBS_DOCUMENT_VERSION
        WHERE DOC_ID = pn_doc_id
        AND CUSTOMER_TYPE = ps_ctype
        AND UPPER(DOC_VERSION) = UPPER(ps_ver);
       
       IF tmpVar > 0 THEN
            RAISE duplicate_ver;
       END IF;
       
       IF SUBSTR(UPPER(ps_ver), 1, 1) NOT IN ('V') THEN
            RAISE first_latter_v;
       END IF;  
          
       EXCEPTION
         WHEN duplicate_ver THEN
           raise_application_error(-20122, CBS.PKG_HATA.GETUCPOINTER || '20122' || CBS.PKG_HATA.GETUCPOINTER);
         WHEN first_latter_v THEN
           raise_application_error(-20121, CBS.PKG_HATA.GETUCPOINTER || '20121' || CBS.PKG_HATA.GETUCPOINTER);
  END;
  
  FUNCTION GET_GENERAL_AGREEMENT_ID RETURN NUMBER IS
    ln_doc_id NUMBER;
    ls_GBAA varchar2(200);
  BEGIN
    CBS.PKG_PARAMETRE.DEGER('GBAA_NAME', ls_GBAA);

    SELECT DOC_ID 
    INTO ln_doc_id
    FROM CBS.CBS_DOCUMENT_CODE
    WHERE DOC_NAME = ls_GBAA;
    
    RETURN ln_doc_id;
  END;
  
  FUNCTION GET_DOCUMENT_NAME(pn_doc_id NUMBER) RETURN VARCHAR2 IS
    ls_doc_name VARCHAR2(2000);
  BEGIN
      IF pn_doc_id IS NOT NULL THEN
          SELECT DOC_NAME
          INTO ls_doc_name
          FROM CBS.CBS_DOCUMENT_CODE
          WHERE DOC_ID = pn_doc_id;
      END IF;
    RETURN ls_doc_name;
  END;
  
  PROCEDURE GET_DOC_LAST_VERSION(pn_doc_id IN NUMBER, ps_ctype IN VARCHAR2, ps_version OUT VARCHAR2, ps_start_date OUT VARCHAR2) IS
  BEGIN
    SELECT d.DOC_VERSION, TO_CHAR(d.START_DATE, 'DD/MM/YYYY') 
    INTO ps_version, ps_start_date
    FROM (SELECT v.DOC_ID, v.START_DATE, v.DOC_VERSION, DENSE_RANK() OVER(PARTITION BY DOC_ID, CUSTOMER_TYPE ORDER BY v.START_DATE DESC) as ord
          FROM CBS.CBS_DOCUMENT_VERSION v 
          WHERE v.DOC_ID = pn_doc_id
          AND V.CUSTOMER_TYPE = ps_ctype) d
    WHERE d.ord = 1;
  EXCEPTION
    WHEN OTHERS
        THEN NULL;
  END;

END PKG_DOCUMENT;
/

