create PACKAGE     PKG_TX7922 IS

 /******************************************************************************
   Name       : PKG_tx7922
   Created By : Rahat Abdyldaeva
   Date          : 7.05.2013
   Purpose      : TRAINEE PURPOSE LOAN ENTRYE TX.
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  FUNCTION  sf_get_loan_name(pn_loan CBS_LOAN_TYPES_RAHAT.id_no%TYPE) RETURN VARCHAR2;
  END;

/

