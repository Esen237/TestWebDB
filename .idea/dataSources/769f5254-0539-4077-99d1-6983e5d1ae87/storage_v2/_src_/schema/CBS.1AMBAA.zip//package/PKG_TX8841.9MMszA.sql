create PACKAGE     PKG_TX8841 IS
/******************************************************************************
   Name       : PKG_Tx8841
   Created By : Iadgar Babaev
   Date       : 29/11/2019
   Purpose    : Factoring amortization for Installment loans
******************************************************************************/
  Procedure Kontrol_Sonrasi(pn_islem_no number);        -- Islem giris kontrolden gectikten sonra cagrilir
  Procedure Dogrulama_Sonrasi(pn_islem_no number);      -- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);          -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );    -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Onay_Sonrasi(pn_islem_no number);           -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);       -- Islem reddedildikten sonra cagrilir
  Procedure Tamam_Sonrasi(pn_islem_no number);          -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);          -- Isleme iliskin formlar basildiktan sonra cagrilir
  Procedure Muhasebelesme(pn_islem_no number, ps_rrn varchar2, ps_flag varchar2 DEFAULT 'A', pd_date date);
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
  
  Procedure sp_factoring_inst(pn_islem_no number, pn_dosya_no number, pn_sira_no number, pn_amount number, ps_branch varchar2);
END;

/

