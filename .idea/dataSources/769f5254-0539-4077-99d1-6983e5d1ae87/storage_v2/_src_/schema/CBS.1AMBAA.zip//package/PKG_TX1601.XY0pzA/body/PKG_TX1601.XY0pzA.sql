create PACKAGE BODY     PKG_TX1601 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number,
                              pn_islem_kod number,
                              pn_tutar1 number ,
                              ps_doviz1 varchar2,
                              ps_islem_1 varchar2,
                              pn_tutar2 number default null,
                              ps_doviz2 varchar2 default null,
                              ps_islem_2 varchar2 default null,
                            ps_bakiye_guncelle varchar2 default 'E',
                            ps_sil varchar2 default 'E')
                                  -- Islem giris kontrolden gectikten sonra cagrilir

is
    ls_karsilandi varchar2(1);
    ln_islem       number := 0;
    ln_miktar        number := 0;

--190105 sevalb
    ln_tutar1 number ;
      ls_doviz1 varchar2(200);
      ls_islem_1 varchar2(200);
      ln_tutar2 number ;
      ls_doviz2 varchar2(200);
      ls_islem_2 varchar2(200);
    cursor cur_islem is
              select distinct
                   KASA_KODU,
                 SUBE_KODU,
                 DOVIZ_KODU,
                 KULLANICI_KODU,
                 tanim_no,
                 nvl(origin_islem_kod,pn_islem_kod) origin_islem_kod
          from cbs_kasa_kupur_bakiye_islem
          where tx_no = pn_islem_no;

   Begin
     if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E'  then
/* kupur adedi ve bakiyesi hesaplanir*/
/* LC ise en kucuk kupur kodu degerine yuvarlanir */

      select count(*)
      into ln_miktar
      from cbs_kasa_kupur_bakiye_islem
      where tx_no = pn_islem_no;



     ln_tutar1 :=pn_tutar1;
      ls_doviz1 :=ps_doviz1;
      ls_islem_1 :=ps_islem_1;
      ln_tutar2  := pn_tutar2;
      ls_doviz2  := ps_doviz2;
      ls_islem_2 := ps_islem_2;

      if ps_doviz2      = ps_doviz1 and ps_doviz2 is not null then
         if nvl(pn_tutar1,0) >= nvl(pn_tutar2,0) then
                 ln_tutar1 := abs(NVL(pn_tutar1,0) -NVL( pn_tutar2,0));
         else    ls_islem_1  :=     ls_islem_2;
                 ln_tutar1 := abs(NVL(pn_tutar2,0) - NVL(pn_tutar1,0));
         end if;
         ls_islem_2 := null;
         ls_doviz2  := null;
         ln_tutar2  := null;
    end if;

      if ln_miktar <> 0 then
       for c_islem in cur_islem loop

           tx1601_isleme_at(  pn_islem_no,
                                  pn_islem_kod,
                              c_islem.kasa_kodu  ,
                              c_islem.sube_kodu    ,
                              c_islem.kullanici_kodu,
                              c_islem.tanim_no ,
                              null,
                              c_islem.origin_islem_kod,
                              ln_tutar1 ,
                                ls_doviz1 ,
                                ls_islem_1 ,
                                ln_tutar2 ,
                                ls_doviz2 ,
                                ls_islem_2,
                              ps_sil);
       end loop;
     end if;
       BEGIN
           update cbs_kasa_kupur_bakiye_islem
           set      kupur_adedi =   nvl(islem_tutar1,0) - nvl(islem_tutar2,0),
                    kupur_bakiye =  ( nvl(islem_tutar1,0) - nvl(islem_tutar2,0))  * kupur_kodu,
                 param_tutar1 =nvl(ln_tutar1,0),
                 param_doviz1 =ls_doviz1,
                 param_tipi1 =ls_islem_1,
                 param_tutar2 =nvl(pn_tutar2,0),
                 param_doviz2 =ls_doviz2,
                 param_tipi2 = ls_islem_2,
                 origin_islem_kod = pn_islem_kod
           where tx_no = pn_islem_no AND
                    DOVIZ_KODU  IN( ls_doviz1);
           EXCEPTION WHEN no_data_found THEN NULL ;
        END;

           BEGIN
           update cbs_kasa_kupur_bakiye_islem
           set      kupur_adedi =   nvl(islem_tutar1,0) - nvl(islem_tutar2,0),
                    kupur_bakiye =  ( nvl(islem_tutar1,0) - nvl(islem_tutar2,0))  * kupur_kodu,
                 param_tutar1 =nvl(ln_tutar1,0),
                 param_doviz1 =ls_doviz1,
                 param_tipi1 =ls_islem_1,
                 param_tutar2 =nvl(pn_tutar2,0),
                 param_doviz2 =ls_doviz2,
                 param_tipi2 = ls_islem_2,
                 origin_islem_kod = pn_islem_kod
           where tx_no = pn_islem_no AND
                    DOVIZ_KODU  IN( ls_doviz2);
           EXCEPTION WHEN no_data_found THEN NULL ;
        END;

    -- if  ( nvl(Pn_tutar1,0) <> 0 or nvl(Pn_tutar2,0) <> 0 ) then --sevalb150605
       ls_karsilandi:= kupur_karsilandimi(pn_islem_no , pn_islem_kod ,ln_tutar1 ,ln_tutar2,ls_doviz1,ls_doviz2 );
       kasa_kullaniciya_baglimi(pn_islem_no);
        pkg_kasa.bekleyen_kasa_islemi_varmi(pn_islem_no);
       kasa_degerler_degistimi(pn_islem_no ,
                                 ln_tutar1  ,
                                 ls_doviz1 ,
                                 ls_islem_1 ,
                                 ln_tutar2 ,
                                 ls_doviz2 ,
                                 ls_islem_2);

         Kasa_Bakiye_Guncelle(pn_islem_no ,
                                   'KONTROL',
                                   ps_bakiye_guncelle,
                                pn_islem_kod );
        end if;
     --end if;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number ,
                                pn_islem_kod number,
                                pn_tutar1 number ,
                                ps_doviz1 varchar2,
                                ps_islem_1 varchar2,
                                pn_tutar2 number default null,
                                ps_doviz2 varchar2 default null,
                                ps_islem_2 varchar2 default null,
                              ps_bakiye_guncelle varchar2 default 'E') --1603 kasa kapama islemi icindir
  is
     ls_karsilandi varchar2(1);
  Begin
     if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E'   --and ( nvl(Pn_tutar1,0) <> 0 or nvl(Pn_tutar2,0) <> 0 )
       then
       ls_karsilandi:= kupur_karsilandimi(pn_islem_no , pn_islem_kod ,pn_tutar1,pn_tutar2);
       kasa_kullaniciya_baglimi(pn_islem_no);

         kasa_degerler_degistimi(pn_islem_no ,
                                 pn_tutar1  ,
                                 ps_doviz1 ,
                                 ps_islem_1 ,
                                 pn_tutar2 ,
                                 ps_doviz2 ,
                                 ps_islem_2);
        --if  nvl(pn_tutar1,0) <> 0 or nvl(pn_tutar2,0)<> 0 then
             Kasa_Bakiye_Guncelle(pn_islem_no ,'KONTROL',ps_bakiye_guncelle,pn_islem_kod);
        --end if;
     end if;
exception
when others then
    Log_At('Dogrulama_Sonrasi 1601',SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  End;

  Procedure kasa_kullaniciya_baglimi(pn_islem_no number) is
    cursor cur_kasa is
      select distinct
         tx_no,
           kasa_kodu,
           sube_kodu,
         doviz_kodu,
         kullanici_kodu,
         tanim_no
           from cbs_kasa_kupur_bakiye_islem
         where tx_no = pn_islem_no;
    r_kasa cur_kasa%rowtype;
    kasa_bagli_degil exception;
  Begin

             for c_kasa in cur_kasa loop
                  r_kasa:= c_kasa;
           end loop;
            if nvl(r_kasa.tx_no,0) = 0 then
                 raise no_data_found ;
            end if;

         if r_kasa.kasa_kodu <> pkg_kasa.ana_kasa_kodu then
                if  pkg_kasa.kullanici_kasa_kodu(r_kasa.sube_kodu ,r_kasa.kullanici_kodu) <> r_kasa.kasa_kodu  then
                raise kasa_bagli_degil;
               end if;
         end if;
     Exception
       when  kasa_bagli_degil then

           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '750' || pkg_hata.getUCPOINTER);
       when   no_data_found then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '754' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

  End;


  Procedure Iptal_Sonrasi(pn_islem_no number,pn_islem_kod number) is
  Begin
     if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E' then
         kasa_kullaniciya_baglimi(pn_islem_no);
      end if;
--     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);

  End;

  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number,pn_islem_kod number) is
  Begin
    Null;

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number,pn_islem_kod number) is
  Begin
     if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E' then
         Kasa_Bakiye_Guncelle(pn_islem_no ,'IPTAL','E',pn_islem_kod);
     end if;

  --  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ,pn_islem_kod number) is
 Begin
   null;
 End;


  Procedure Basim_Sonrasi(pn_islem_no number,pn_islem_kod number) is
  Begin
      Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number,pn_islem_kod number,
                           pn_tutar1 number ,
                           ps_doviz1 varchar2,
                           ps_islem_1 varchar2,
                           pn_tutar2 number default null,
                           ps_doviz2 varchar2 default null,
                           ps_islem_2 varchar2 default null,
                          ps_bakiye_guncelle varchar2 default 'E') --1603 kasa kapama islemi icindir
   is
   ls_karsilandi varchar2(1);
    Begin
     if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E'   --and ( nvl(Pn_tutar1,0) <> 0 or nvl(Pn_tutar2,0) <> 0 )
     then
      ls_karsilandi:= kupur_karsilandimi(pn_islem_no , pn_islem_kod ,pn_tutar1,pn_tutar2);
      kasa_degerler_degistimi(pn_islem_no ,
                                 pn_tutar1  ,
                                 ps_doviz1 ,
                                 ps_islem_1 ,
                                 pn_tutar2 ,
                                 ps_doviz2 ,
                                 ps_islem_2);
    end if;
  End ;

    Procedure Kasa_Bakiye_Guncelle(pn_islem_no number,
                ps_islem_tipi varchar2,
              ps_bakiye_guncelle varchar2 default 'E',
              pn_islem_kod number default null      )
  is
  ln_islem_kod  number ;
  ls_karsilandi varchar2(1);
  ls_kasa_kodu    cbs_kasa_kodlari.kasa_kodu%type;
  ls_sube_kodu    varchar2(20);
  ls_doviz_kodu    varchar2(3);
  ln_kupur_kodu cbs_kasa_kupur_bakiye.kupur_kodu%type;
  ln_bakiye        number := 0;
  ln_adet        number := 0;
/* kupur adet toplamindan islem bakiyesi */
  cursor cur_toplam_bakiye is
    Select kasa_kodu,
           sube_kodu,
           doviz_kodu  ,
           sum(nvl(kupur_bakiye,0)) toplam
    from cbs_kasa_kupur_bakiye_islem
    where tx_no = pn_islem_no
    group by kasa_kodu,
               sube_kodu,
             doviz_kodu
    order by kasa_kodu,
               sube_kodu,
             doviz_kodu;

/*kupur adetleri toplami */
  cursor cur_toplam_adet is
    Select kasa_kodu,
           sube_kodu,
           doviz_kodu ,
           kupur_kodu,
               sum( nvl(kupur_adedi,0)) adet,
              sum( nvl(kupur_bakiye,0)) kupur_bakiye
    from cbs_kasa_kupur_bakiye_islem
    where tx_no = pn_islem_no
    group by  kasa_kodu,
                sube_kodu,
              doviz_kodu ,
              kupur_kodu
    order by  kasa_kodu,
                sube_kodu,
              doviz_kodu  ,
                kupur_kodu;

 cursor cur_kasa_bakiye is
   select
             kasa_kodu,
             sube_kodu,
             doviz_kodu,
          bakiye,
          kk.rowid
    from cbs_kasa_bakiye kk
    where kasa_kodu = ls_kasa_kodu and
          sube_kodu = ls_sube_kodu and
             doviz_kodu = ls_doviz_kodu and
          banka_tarihi = pkg_muhasebe.banka_tarihi_bul
    ;

 cursor cur_kasa_kupur_adet is
   select kasa_kodu,
             sube_kodu,
             doviz_kodu,
          kupur_kodu,
          kupur_adedi,
          kupur_bakiye,
          bb.rowid
    from cbs_kasa_kupur_bakiye bb
    where kasa_kodu = ls_kasa_kodu and
          sube_kodu = ls_sube_kodu and
             doviz_kodu = ls_doviz_kodu and
          kupur_kodu = ln_kupur_kodu and
          banka_tarihi = pkg_muhasebe.banka_tarihi_bul
  ;

  bakiye_negatif exception;
  adet_negatif     exception;
  KUPUR_bakiye_negatif exception;
 Begin

      kasa_kullaniciya_baglimi(pn_islem_no);

     ln_islem_kod :=  pn_islem_kod;
     if pn_islem_kod is null then

           select islem_kod
          into ln_islem_kod
          from cbs_islem
          where numara = pn_islem_no ;
     end if;

 /*  kullanici kasa bakiye guncellenir */

     ls_sube_kodu := null;
    ls_kasa_kodu := null;
    ls_doviz_kodu :=null;

  if   ps_bakiye_guncelle = 'E' then
   for  c_bakiye in cur_toplam_bakiye loop
           ls_sube_kodu := c_bakiye.sube_kodu;
        ls_kasa_kodu := c_bakiye.kasa_kodu;
        ls_doviz_kodu := c_bakiye.doviz_kodu;

       kasa_doviz_sifir_bakiye_yarat(ls_kasa_kodu ,ls_sube_kodu ,ls_doviz_kodu );

      for c_kasa_bakiye in cur_kasa_bakiye loop

           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) +  nvl(c_bakiye.toplam,0);
         if ps_islem_tipi = 'IPTAL' then
           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) -  nvl(c_bakiye.toplam,0);
         else
           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) +  nvl(c_bakiye.toplam,0);
         end if;

         if ln_bakiye  < 0 then
           raise bakiye_negatif;
         end if;

              if ps_islem_tipi <> 'KONTROL' then
              update cbs_kasa_bakiye kb
             set  bakiye =ln_bakiye
             where kb.rowid = c_kasa_bakiye.rowid;
        end if;

      end loop;

     end loop;
  end if;
    ls_sube_kodu := null;
    ls_kasa_kodu := null;
    ls_doviz_kodu :=null;
    ln_kupur_kodu:= null;

   for  c_adet in cur_toplam_adet loop
           ls_sube_kodu := c_adet.sube_kodu;
        ls_kasa_kodu := c_adet.kasa_kodu;
        ls_doviz_kodu := c_adet.doviz_kodu;
         ln_kupur_kodu:= c_adet.kupur_kodu;

      kupur_doviz_sifir_adet_yarat(ls_kasa_kodu ,ls_sube_kodu ,ls_doviz_kodu ,ln_kupur_kodu);

      ln_bakiye := 0;
      ln_adet := 0;
      for c_kasa_kupur_bakiye in cur_kasa_kupur_adet loop

        if ps_islem_tipi = 'IPTAL' then
           ln_adet := nvl(c_kasa_kupur_bakiye.kupur_adedi,0) - nvl(c_adet.adet,0);
           ln_bakiye := nvl(c_kasa_kupur_bakiye.kupur_bakiye,0) - nvl(c_adet.kupur_bakiye,0);
         else
           ln_adet := nvl(c_kasa_kupur_bakiye.kupur_adedi,0) + nvl(c_adet.adet,0);
           ln_bakiye := nvl(c_kasa_kupur_bakiye.kupur_bakiye,0)+ nvl(c_adet.kupur_bakiye,0);
         end if;

          if ln_adet  < 0  and pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'KASA_KUPUR_NEGATIF') = 'H' then
           raise adet_negatif;
         end if;
         if ln_bakiye   < 0 and pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'KASA_KUPUR_NEGATIF') = 'H' then
           raise kupur_bakiye_negatif;
         end if;


         if ps_islem_tipi <> 'KONTROL' then
         update cbs_kasa_kupur_bakiye kka
         set  kupur_adedi =   ln_adet,
               kupur_bakiye=   ln_bakiye
         where kka.rowid = c_kasa_kupur_bakiye.rowid;
        end if;
      end loop;
    end loop;

  Exception
    when adet_negatif then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '755' ||  pkg_hata.getdelimiter|| ls_kasa_kodu || pkg_hata.getdelimiter || ls_doviz_kodu || pkg_hata.getdelimiter||  to_char(ln_kupur_kodu ) || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);
    when bakiye_negatif then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '752' ||  pkg_hata.getdelimiter|| ls_kasa_kodu || pkg_hata.getdelimiter || ls_doviz_kodu || pkg_hata.getdelimiter|| ls_sube_kodu || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);
    when kupur_bakiye_negatif then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '766' ||  pkg_hata.getdelimiter|| ls_kasa_kodu || pkg_hata.getdelimiter || ls_doviz_kodu || pkg_hata.getdelimiter|| to_char(ln_kupur_kodu )  || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);
    when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '753' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number,pn_islem_kod number,ps_bakiye_guncelle varchar2 default 'E' )--1603 kasa kapama islemi icindir)
  is
    cursor cur_kasa is
      select distinct
           kasa_kodu,
           sube_kodu,
         doviz_kodu,
         kullanici_kodu,
         tanim_no
          from cbs_kasa_kupur_bakiye_islem
         where tx_no = pn_islem_no;

   r_kasa cur_kasa%rowtype;
    ls_karsilandi varchar2(1);
 Begin
    if  kasa_kupur_kontrol_var(pn_islem_kod) = 'E' then
       kasa_kullaniciya_baglimi(pn_islem_no);

 /*  onay oncesi bakiye bilgisi onay oncesi islem tablosuna aktarilir */
      Begin
       open cur_kasa ;
        fetch cur_kasa into r_kasa;
                 insert into  cbs_kasa_kupur_bakiye_isl_once
                (tx_no,
                 kasa_kodu,
                 sube_kodu,
                 doviz_kodu,
                   kullanici_kodu,
                 banka_tarihi,
                 kupur_adedi,
                 kupur_kodu)
                SELECT pn_islem_no,
                       kasa_kodu,
                       sube_kodu,
                       doviz_kodu,
                       r_kasa.kullanici_kodu,
                       banka_tarihi,
                       kupur_adedi,
                        kupur_kodu
                from cbs_kasa_kupur_bakiye
                where kasa_kodu = r_kasa.kasa_kodu and
                      sube_kodu = r_kasa.sube_kodu and
                      doviz_kodu = r_kasa.doviz_kodu and
                      banka_tarihi = pkg_muhasebe.banka_tarihi_bul ;

               insert into cbs_kasa_bakiye_islem_oncesi
                       (tx_no,
                     kasa_kodu,
                     sube_kodu,
                     doviz_kodu,
                     kullanici_kodu,
                     banka_tarihi,
                     tanim_no,
                     bakiye)
                select pn_islem_no,
                       kasa_kodu,
                       sube_kodu,
                       doviz_kodu,
                       r_kasa.kullanici_kodu,
                       banka_tarihi,
                       r_kasa.tanim_no,
                       bakiye
                from cbs_kasa_bakiye
                where kasa_kodu = r_kasa.kasa_kodu and
                      sube_kodu = r_kasa.sube_kodu and
                      doviz_kodu = r_kasa.doviz_kodu and
                      banka_tarihi = pkg_muhasebe.banka_tarihi_bul ;


      Kasa_Bakiye_Guncelle(pn_islem_no ,'ONAY',ps_bakiye_guncelle ,pn_islem_kod);
     close cur_kasa;
    END;
  end if;
  End;

Procedure kasa_doviz_sifir_bakiye_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2,ps_doviz_kodu varchar2 )
  is
    ln_mevcut number := 0;
  Begin
         select count(*)
       into ln_mevcut
       from  cbs_kasa_bakiye
       where kasa_kodu = ps_kasa_kodu  and
                sube_kodu = ps_sube_kodu and
             doviz_kodu = ps_doviz_kodu  ;

       if nvl(ln_mevcut,0) = 0 then
              insert into cbs_kasa_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, bakiye)
           values ( ps_kasa_kodu, ps_sube_kodu, ps_doviz_kodu, pkg_muhasebe.banka_tarihi_bul, 0);
      end if;
  End;
  Procedure kupur_doviz_sifir_adet_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2,ps_doviz_kodu varchar2 ,pn_kupur_kodu number)
  is
    ln_mevcut number := 0;
  Begin
         select count(*)
       into ln_mevcut
       from  cbs_kasa_kupur_bakiye
       where kasa_kodu = ps_kasa_kodu  and
                sube_kodu = ps_sube_kodu and
             doviz_kodu = ps_doviz_kodu and
             kupur_kodu = pn_kupur_kodu ;

       if nvl(ln_mevcut,0) = 0 then
              insert into cbs_kasa_kupur_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, kupur_kodu ,kupur_adedi,kupur_bakiye)
           values ( ps_kasa_kodu, ps_sube_kodu, ps_doviz_kodu, pkg_muhasebe.banka_tarihi_bul,pn_kupur_kodu,0,0);
      end if;
  End;

/*Procedure kasa_bakiye_islem_kayit_at(pn_islem_no number) is
 ln_mevcut number := 0;
Begin
     select count(*)
     into ln_mevcut
     from cbs_kasa_bakiye_islem
     where tx_no = pn_islem_no;

     if ln_mevcut = 0 then
      insert into  cbs_kasa_bakiye_islem
                (tx_no,
                 sira_no,
                 kasa_kodu,
                 sube_kodu,
                 doviz_kodu,
                   kullanici_kodu,
                 banka_tarihi,
                 tanim_no,
                 modul_tur_kod,
                 urun_tur_kod,
                 urun_sinif_kod,
                 bakiye
                 )
                SELECT pn_islem_no,
                       pkg_genel.genel_kod_al('KASA_BAKIYE_SIRANO'),
                       kasa_kodu,
                       sube_kodu,
                       doviz_kodu,
                       kullanici_kodu,
                       banka_tarihi,
                       tanim_no,
                       pkg_kasa.kasa_modul_tur_kod,
                        pkg_kasa.kasa_urun_tur_kod,
                        pkg_kasa.kasa_urun_sinif_kod,
                       nvl( sum( decode(yatan_cekilen,'C',-1* nvl(kupur_adedi,0)* nvl(kupur_kodu,0),nvl(kupur_adedi,0)* nvl(kupur_kodu,0) )),0) kupur_bakiye
                from cbs_kasa_kupur_bakiye_islem
                where tx_no = pn_islem_no
                group by pn_islem_no,
                       kasa_kodu,
                       sube_kodu,
                       doviz_kodu,
                       kullanici_kodu,
                       banka_tarihi,
                       tanim_no ;
        end if;
End;
*/
 Function kasa_kupur_kontrol_var(pn_islem_kod number) return varchar2
  is
  ls_mevcut varchar2(1) := 'H';
  ls_var    varchar2(1) := 'H';
 Begin
           select KUPUR_KONTROLU
        into ls_var
        from cbs_system;
        if ls_var = 'E' then
          select decode(nvl(kupur_kontrolu,'H'),'H','H','E')
           into ls_mevcut
           from cbs_islem_tanim
           where kod = pn_islem_kod;
         else
           ls_mevcut := 'H';
         end if;
     return ls_mevcut;

  End;

  Procedure kasa_degerler_degistimi(pn_islem_no number,
                                      pn_tutar1 number ,
                                      ps_doviz1 varchar2,
                                      ps_islem_1 varchar2,
                                      pn_tutar2 number,
                                      ps_doviz2 varchar2,
                                      ps_islem_2 varchar2)
 is
  ls_mevcut varchar2(1);
  islem_degismis exception;
  cursor cur_kasa is
        select  distinct 'E' MEVCUT
      from cbs_kasa_kupur_bakiye_islem
      where tx_no = pn_islem_no and
              param_tipi1  = ps_islem_1 and
              param_doviz1 = ps_doviz1 and
            nvl(param_tutar1,0) = lc_tutar_yuvarla(nvl(pn_tutar1,0),ps_doviz1) and
            param_tipi2  = ps_islem_2 and
              param_doviz2 = ps_doviz2 and
            nvl(param_tutar2,0) = lc_tutar_yuvarla(nvl(pn_tutar2,0),ps_doviz2) ;

 Begin
  for c_kasa in cur_kasa loop
      ls_mevcut:= c_kasa.mevcut;
  end loop;
   if ls_mevcut = 'H' Then
         raise islem_degismis;
   end if;

     Exception when islem_degismis then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '765' || pkg_hata.getUCPOINTER);
 End;

 Function kupur_karsilandimi(pn_tx_no number, pn_islem_kod number ,Pn_tutar1 number ,pn_tutar2 number ,ps_doviz1 varchar2 default null ,ps_doviz2 varchar2 default null) return varchar2

 is
 /* ?slemlerden pass edilen degerlerdir */
 cursor  cur_islem is
     select  distinct
               tx_no,
              decode(PARAM_DOVIZ1, null,nvl(decode(PARAM_TIPI1,'C',-1*nvl(PARAM_TUTAR1,0),PARAM_TUTAR1),0) ,pkg_kur.yuvarla(PARAM_DOVIZ1,nvl(decode(PARAM_TIPI1,'C',-1*nvl(PARAM_TUTAR1,0),PARAM_TUTAR1),0))) PARAM_TUTAR1,
              PARAM_DOVIZ1,
              PARAM_TIPI1,
              decode(PARAM_DOVIZ2, null,nvl(decode(PARAM_TIPI2,'C',-1*nvl(PARAM_TUTAR2,0),PARAM_TUTAR2),0),pkg_kur.yuvarla(PARAM_DOVIZ2, nvl(decode(PARAM_TIPI2,'C',-1*nvl(PARAM_TUTAR2,0),PARAM_TUTAR2),0))) PARAM_TUTAR2 ,
              PARAM_DOVIZ2,
              PARAM_TIPI2
          from cbs_kasa_kupur_bakiye_islem
        where tx_no = pn_tx_No and
              doviz_kodu in (ps_doviz1,ps_doviz2);

  ls_doviz        cbs_doviz_kodlari.doviz_kodu%type;
  ln_kayit_var    number := 0;
  cursor cur_toplam is
    Select Doviz_Kodu,
          sum( (nvl(islem_tutar1,0) -  nvl(islem_tutar2,0)) * KUPUR_KODU) TOPLAM
    From CBS_KASA_KUPUR_BAKIYE_ISLEM
    where tx_no = pn_tx_No and
          doviz_kodu = ls_doviz
    group By Doviz_Kodu
    order by Doviz_Kodu;

    ln_tutar NUMBER := 0;
    ls_kupur_karsilandi varchar2(1) := 'H';
    esit exception;
    ls_return  varchar2(1):= 'E';
 Begin

      ls_kupur_karsilandi:=  pkg_kasa.kupur_kontrolu_yapilsin(pn_islem_kod);

     --sevalb 150605
          Select count(*)
             into ln_kayit_var
          from cbs_kasa_kupur_bakiye_islem
          where tx_no = pn_tx_no and
                  ( nvl(islem_tutar1,0) <> 0  or nvl(islem_tutar2,0) <> 0 );

     if NVL(ls_kupur_karsilandi,'H') <> 'H' and
          (  nvl( ln_kayit_var,0) <> 0  or  nvl(Pn_tutar1,0) <> 0 or nvl(Pn_tutar2,0) <> 0  ) then
       for c_islem in cur_islem loop
         ln_tutar := 0;
         ls_doviz := null;
/* tutar 1 karsilastirmasi */
                if c_islem.param_doviz1 is not null  and ( nvl(c_islem.param_tutar1,0 ) <> 0 or  nvl( ln_kayit_var,0) <> 0 ) then
                  ls_doviz := c_islem.param_doviz1;
               for c_toplam in cur_toplam loop
                      ln_tutar:= c_toplam.toplam ;
               end loop;
              if  ls_kupur_karsilandi = 'E' then /* esit ise */
                 if nvl(c_islem.param_tutar1,0) <> nvl(ln_tutar,0) then
                     ls_return := 'H';
                         raise esit;
                 end if;
              else
                   if  abs(nvl(c_islem.param_tutar1,0)) > abs(nvl(ln_tutar,0)) or
                      (  sign(c_islem.param_tutar1)<> sign(ln_tutar) )  then
                         ls_return := 'H';
                         raise no_data_found;
                 end if;
              end if;
           end if;

/* tutar 2 karsilastirmasi */
              ln_tutar := 0;
                if c_islem.param_doviz2 is not null and  nvl(c_islem.param_tutar2,0 ) <> 0 then

                  ls_doviz := c_islem.param_doviz2;

               for c_toplam in cur_toplam loop
                      ln_tutar:= c_toplam.toplam ;
               end loop;

              if  ls_kupur_karsilandi = 'E' then /* esit ise */
                 if nvl(c_islem.param_tutar2,0) <> nvl(ln_tutar,0) then
                     ls_return := 'H';
                     raise esit;
                 end if;
              else
                   if  abs(nvl(c_islem.param_tutar2,0)) > abs(nvl(ln_tutar,0)) or
                      (  sign(c_islem.param_tutar2)<> sign(ln_tutar) )  then
                     ls_return := 'H';
                        raise no_data_found;
                 end if;
              end if;
           end if;

        end loop;

   else
     return 'E';
  end if;
      return ls_return;
     Exception
        when no_data_found then return'H';
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '751' || pkg_hata.getUCPOINTER);
         when esit then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '769' || pkg_hata.getUCPOINTER);
         return 'H';

 End;

  Procedure tx1601_isleme_at (pn_tx_no           number,
                               pn_islem_kod      cbs_islem.islem_kod%type,
                           ps_kasa_kodu       cbs_kasa_kodlari.kasa_kodu%type,
                           ps_sube_kodu          varchar2,
                           ps_kullanici_kodu  varchar2,
                           pn_tanim_no number,
                           ps_urun_sinif_kod varchar2 default pkg_kasa.kasa_urun_sinif_kod,
                           ps_origin_islem_kod varchar2 default null,
                           pn_tutar1 number default null,
                             ps_doviz1 varchar2 default null,
                             ps_islem_1 varchar2 default null,
                             pn_tutar2 number default null,
                             ps_doviz2 varchar2 default null,
                             ps_islem_2 varchar2    default null,
                            ps_sil varchar2 default 'E')
  is

     ls_retval varchar2(200);
    ls_pkod     varchar2(200);
    ls_sube_kodu varchar2(200);
    ln_mevcut number := 0;
    kayit_yok exception;
    kasa_yok exception;
 Begin

        if ps_sil = 'E' then
           Begin
               DELETE From cbs_kasa_kupur_bakiye_islem
               where tx_no = pn_tx_no and
                        doviz_kodu  not in ( NVL(ps_doviz1,'X'),nvl(ps_doviz2,'X'));
            Exception when others then null;
            End;
        End if;
        ln_mevcut := 0;
        select count(*)
        into ln_mevcut
        from cbs_kasa_kupur_bakiye_islem
        where tx_no = pn_tx_no and doviz_kodu =ps_doviz1;

    if ps_kasa_kodu  is null then
     raise kasa_yok;
     else
        if nvl(ln_mevcut,0) = 0 then
/* Gonderilen islem doviz kodlar? icin Yatan ve Cekilen Kayitlari olusturulur.*/
/*Ps_doviz1 icin YATAN ve cekilen*/

             insert into cbs_kasa_kupur_bakiye_islem
                   (tx_no,
                  sira_no,
                  kasa_kodu,
                  sube_kodu,
                  doviz_kodu,
                  kullanici_kodu,
                  banka_tarihi,
                  tanim_no,
                  kupur_kodu,
                  kupur_adedi,
                  kupur_bakiye,
                  islem_tutar1,
                  islem_tipi1,
                  islem_tutar2,
                  islem_tipi2,
/* original karsilastirma tutarlari girilir*/
                  param_tutar1,
                  param_doviz1,
                  param_tipi1,
                  param_tutar2,
                  param_doviz2,
                  param_tipi2
                      )
                SELECT pn_tx_no,
                       pkg_genel.genel_kod_al('KASA_KUPUR_SIRANO'),
                       ps_kasa_kodu,
                       ps_sube_kodu,
                       doviz_kodu,
                       ps_kullanici_kodu,
                       pkg_muhasebe.banka_Tarihi_bul,
                       pn_tanim_no,
                       kupur_kodu,
                       0,
                       0,
                       0,--ISLEM_TUTAR1,
                         'Y',
                         0,
                         'C',
                       pn_tutar1 ,
                         ps_doviz1,
                       ps_islem_1,
                       pn_tutar2 ,
                         ps_doviz2,
                       ps_islem_2
                       from cbs_kasa_kupur_bakiye
                    where  kasa_kodu = ps_kasa_kodu and
                           sube_kodu = ps_sube_kodu and
                           banka_tarihi = pkg_muhasebe.banka_tarihi_bul and
                           doviz_kodu in ( ps_doviz1);
  else

                      update cbs_kasa_kupur_bakiye_islem
                set
                  param_tutar1 = pn_tutar1,
                  param_doviz1 = ps_doviz1,
                  param_tipi1  = ps_islem_1,
                  param_tutar2 = pn_tutar2,
                  param_doviz2 = ps_doviz2,
                  param_tipi2  = ps_islem_2
                where  tx_no = pn_tx_no and
                       kasa_kodu = ps_kasa_kodu and
                       sube_kodu = ps_sube_kodu AND
                           doviz_kodu in ( ps_doviz1);
  end if;
/*Ps_doviz2 icin yatan ve cekilen*/

         ln_mevcut := 0;
        select count(*)
        into ln_mevcut
        from cbs_kasa_kupur_bakiye_islem
        where tx_no = pn_tx_no and doviz_kodu = ps_doviz2;

    if nvl(ln_mevcut,0) = 0 then
             insert into cbs_kasa_kupur_bakiye_islem
                   (tx_no,
                  sira_no,
                  kasa_kodu,
                  sube_kodu,
                  doviz_kodu,
                  kullanici_kodu,
                  banka_tarihi,
                  tanim_no,
                  kupur_kodu,
                  kupur_adedi,
                  kupur_bakiye,
                  islem_tutar1,
                  islem_tipi1,
                  islem_tutar2,
                  islem_tipi2 ,
/* original karsilastirma tutarlari girilir*/
                  param_tutar1,
                  param_doviz1,
                  param_tipi1,
                  param_tutar2,
                  param_doviz2,
                  param_tipi2
                   )
                SELECT pn_tx_no,
                       pkg_genel.genel_kod_al('KASA_KUPUR_SIRANO'),
                       ps_kasa_kodu,
                       ps_sube_kodu,
                       doviz_kodu,
                       ps_kullanici_kodu,
                       pkg_muhasebe.banka_Tarihi_bul,
                       pn_tanim_no,
                       kupur_kodu,
                       0,
                       0,
                       0,
                         'Y',
                         0,
                         'C',
                       pn_tutar1 ,
                         ps_doviz1,
                       ps_islem_1,
                       pn_tutar2 ,
                         ps_doviz2,
                       ps_islem_2
                from cbs_kasa_kupur_bakiye
                    where  kasa_kodu = ps_kasa_kodu and
                           sube_kodu = ps_sube_kodu and
                           banka_tarihi = pkg_muhasebe.banka_tarihi_bul and
                           doviz_kodu in ( ps_doviz2);
    else

                update cbs_kasa_kupur_bakiye_islem
                set
                  param_tutar1 = pn_tutar1,
                  param_doviz1 = ps_doviz1,
                  param_tipi1  = ps_islem_1,
                  param_tutar2 = pn_tutar2,
                  param_doviz2 = ps_doviz2,
                  param_tipi2  = ps_islem_2
                where  tx_no = pn_tx_no and
                       kasa_kodu = ps_kasa_kodu and
                       sube_kodu = ps_sube_kodu AND
                        doviz_kodu in ( ps_doviz2);
       end if;
   end if;

 Exception
  when kayit_yok then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '759' || pkg_hata.getUCPOINTER);
  when kasa_yok then

         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '750' || pkg_hata.getUCPOINTER);
    when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '60' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

 End;

Function islemden_kasa_kodu_al(pn_tx_no number) return varchar2
is
 ls_kasa varchar2(20);
Begin
     select distinct kasa_kodu
     into ls_kasa
     from cbs_kasa_kupur_bakiye_islem
     where tx_no = pn_tx_no ;

 return ls_kasa;
End;

Function lc_tutar_yuvarla(pn_tutar number ,ps_doviz varchar2 ) return number
is

 ln_tutar number := 0;
Begin

 /*  if ps_doviz = pkg_genel.lc_al then

      select      decode(pn_tutar -  min(kupur_kodu) * TRUNC (pn_tutar / min(kupur_kodu)) ,0,pn_tutar, (TRUNC(pn_tutar / min(kupur_kodu)) + 1) * min(kupur_kodu))
      into ln_tutar
      from cbs_KASA_kupur_kodlari
      where doviz_kodu = pkg_genel.lc_al and gecerli_mi = 'E';

   else
          return pn_tutar;
    end if;

    */
    return pn_tutar;
    Exception when others then return pn_tutar;
End;
Function sf_kupur_validmi(ps_kupur_kodu number, ps_doviz varchar2) return varchar2
is
ls_gecerli varchar2(1) := 'H';
Begin
     select  GECERLI_MI
     into ls_gecerli
     from cbs_kasa_kupur_kodlari
     where kupur_kodu = ps_kupur_kodu and
            doviz_kodu = ps_doviz ;
    RETURN ls_gecerli;
Exception When others then return 'H';
End;

Procedure Ana_Kasa_Bakiye_Guncelle(pn_islem_no number,ps_islem_tipi varchar2)
  is
/* Ana kasa bakiyesi ters calisir. Kullanici kasasina gore C islem , Ana kasa Yatan islemi gibidir.*/
  ln_islem_kod  number ;
  ls_karsilandi varchar2(1);
  ls_kasa_kodu    cbs_kasa_kodlari.kasa_kodu%type;
  ls_sube_kodu    varchar2(20);
  ls_doviz_kodu    varchar2(3);
  ln_kupur_kodu cbs_kasa_kupur_bakiye.kupur_kodu%type;
  ln_bakiye        number := 0;
  ln_adet        number := 0;
/* kupur adet toplamindan islem bakiyesi */
  cursor cur_toplam_bakiye is
    Select kasa_kodu,
           sube_kodu,
           doviz_kodu  ,
           -1* sum( nvl(kupur_bakiye ,0)) toplam
    from cbs_kasa_kupur_bakiye_islem
    where tx_no = pn_islem_no
    group by kasa_kodu,
               sube_kodu,
             doviz_kodu
    order by kasa_kodu,
               sube_kodu,
             doviz_kodu;

/*kupur adetleri toplami */
  cursor cur_toplam_adet is
    Select kasa_kodu,
           sube_kodu,
           doviz_kodu ,
           kupur_kodu,
               -1 * sum( nvl(kupur_adedi,0)) adet,
              -1 * sum( nvl(kupur_bakiye,0))  kupur_bakiye
    from cbs_kasa_kupur_bakiye_islem
    where tx_no = pn_islem_no
    group by  kasa_kodu,
                sube_kodu,
              doviz_kodu ,
              kupur_kodu
    order by  kasa_kodu,
                sube_kodu,
              doviz_kodu  ,
                kupur_kodu;

 cursor cur_kasa_bakiye is
   select
             kasa_kodu,
             sube_kodu,
             doviz_kodu,
          bakiye,
          rowid
    from cbs_kasa_bakiye
    where kasa_kodu = ls_kasa_kodu and
          sube_kodu = ls_sube_kodu and
             doviz_kodu = ls_doviz_kodu and
          banka_tarihi = pkg_muhasebe.banka_tarihi_bul
  ;

 cursor cur_kasa_kupur_adet is
   select kasa_kodu,
             sube_kodu,
             doviz_kodu,
          kupur_kodu,
          kupur_adedi,
          kupur_bakiye,
          rowid
    from cbs_kasa_kupur_bakiye
    where kasa_kodu = ls_kasa_kodu and
          sube_kodu = ls_sube_kodu and
             doviz_kodu = ls_doviz_kodu and
          kupur_kodu = ln_kupur_kodu and
          banka_tarihi = pkg_muhasebe.banka_tarihi_bul
  ;

  bakiye_negatif exception;
  adet_negatif     exception;
 Begin

    ls_kasa_kodu := pkg_kasa.ana_kasa_kodu;
    ls_doviz_kodu :=null;
    ln_kupur_kodu:= null;

      select islem_kod
      into ln_islem_kod
      from cbs_islem
      where numara = pn_islem_no ;

--     ls_karsilandi:= pkg_kasa.kupur_karsilandimi(pn_islem_no , ln_islem_kod );
 /* kasa bakiye guncellenir */

    ls_doviz_kodu :=null;

   for  c_bakiye in cur_toplam_bakiye loop
          ls_sube_kodu := c_bakiye.sube_kodu;
        ls_doviz_kodu := c_bakiye.doviz_kodu;
         pkg_tx1601.kasa_doviz_sifir_bakiye_yarat(ls_kasa_kodu ,ls_sube_kodu ,ls_doviz_kodu );

      for c_kasa_bakiye in cur_kasa_bakiye loop
           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) +  nvl(c_bakiye.toplam,0);
         if ps_islem_tipi = 'IPTAL' then
           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) -  nvl(c_bakiye.toplam,0);
         else
           ln_bakiye:= nvl(c_kasa_bakiye.bakiye,0) +  nvl(c_bakiye.toplam,0);
         end if;

         if ln_bakiye  < 0 then
           raise bakiye_negatif;
         end if;
              if ps_islem_tipi <> 'KONTROL' then
              update cbs_kasa_bakiye kb
             set  bakiye =ln_bakiye
             where kb.rowid = c_kasa_bakiye.rowid;
           end if;
      end loop;
     end loop;

   for  c_adet in cur_toplam_adet loop
        ls_doviz_kodu := c_adet.doviz_kodu;
        ln_kupur_kodu:= c_adet.kupur_kodu;

      pkg_tx1601.kupur_doviz_sifir_adet_yarat(ls_kasa_kodu ,ls_sube_kodu ,ls_doviz_kodu ,ln_kupur_kodu);

      ln_bakiye := 0;
      ln_adet := 0;
      for c_kasa_kupur_bakiye in cur_kasa_kupur_adet loop
        if ps_islem_tipi = 'IPTAL' then
           ln_adet := nvl(c_kasa_kupur_bakiye.kupur_adedi,0) - nvl(c_adet.adet,0);
           ln_bakiye := nvl(c_kasa_kupur_bakiye.kupur_bakiye,0) - nvl(c_adet.kupur_bakiye,0);
         else
           ln_adet := nvl(c_kasa_kupur_bakiye.kupur_adedi,0) + nvl(c_adet.adet,0);
           ln_bakiye := nvl(c_kasa_kupur_bakiye.kupur_bakiye,0)+ nvl(c_adet.kupur_bakiye,0);
         end if;

          /*if ln_adet  < 0 then
           raise adet_negatif;
         end if;
         */
         if ps_islem_tipi <> 'KONTROL' then
         update cbs_kasa_kupur_bakiye kka
         set  kupur_adedi =   ln_adet,
               kupur_bakiye=   ln_bakiye
         where kka.rowid = c_kasa_kupur_bakiye.rowid;
        end if;
      end loop;
     end loop;

  Exception
    when adet_negatif then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '762' ||  pkg_hata.getdelimiter|| ls_kasa_kodu || pkg_hata.getdelimiter || ls_doviz_kodu || pkg_hata.getdelimiter||  to_char(ln_kupur_kodu ) || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);
    when bakiye_negatif then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '763' ||  pkg_hata.getdelimiter|| ls_kasa_kodu || pkg_hata.getdelimiter || ls_doviz_kodu || pkg_hata.getdelimiter|| ls_sube_kodu || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);
    when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '764' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  End;

  -- 1611 cash transfer between branches islemi icin eklenmistir.
  procedure sp_kupur_islem_yarat(pn_transfer_no          CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
                                        pn_tx_no               CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE,
                                   pn_islem_tanim_kod   CBS_KASA_SUBE_TRANSFER.islem_kod%TYPE DEFAULT 1611,
                                    ps_bolum_kodu varchar2 default pkg_baglam.bolum_kodu
                                  ) is
  ln_tx_no  number;
  ln_mevcut number := 0;

  Begin
     ln_mevcut := 0;
     select count(*)
     into ln_mevcut
     from cbs_kasa_kupur_bakiye_islem
     where tx_no = pn_tx_no ;

   if  ln_mevcut  = 0 then
      delete from  cbs_kasa_kupur_bakiye_islem
      where tx_no = pn_tx_no ;
   end if;


  if pn_islem_tanim_kod  =1611  then

        select yaratan_tx_no
      into ln_tx_no
      from cbs_kasa_sube_transfer
      where transfer_no = pn_transfer_no ;

      if nvl(ln_tx_no,0) = 0 then
           select min(tx_no)
         into ln_tx_no
         from cbs_kasa_sube_transfer_islem
         where transfer_no = pn_transfer_no and
                islem_kod= 1610;
     end if;

    --sent transfer kupurleri receive isleminda ters olarak atilir.islem tutar2 ve tutar1 degistirilir. kupur bakiye tersi ile carpilir
       insert into cbs_kasa_kupur_bakiye_islem
                   ( tx_no, sira_no, kasa_kodu, sube_kodu, doviz_kodu, kullanici_kodu, banka_tarihi, tanim_no, kupur_adedi,
                              kupur_kodu, islem_tutar1, islem_tipi1, islem_tutar2, islem_tipi2, origin_islem_kod, islem_kod,
                             kupur_bakiye, param_tutar1, param_doviz1, param_tipi1, param_tutar2, param_doviz2, param_tipi2                      )
            select pn_tx_no, sira_no, kasa_kodu, nvl(ps_bolum_kodu,pkg_baglam.bolum_kodu) , doviz_kodu, kullanici_kodu, banka_tarihi, tanim_no, kupur_adedi,
                   kupur_kodu, islem_tutar2, 'Y', islem_tutar1, islem_tipi2, 1610 origin_islem_kod,
                   pn_islem_tanim_kod , -1*kupur_bakiye,  param_tutar1, param_doviz1, 'Y', param_tutar2, param_doviz2, param_tipi2
            from cbs_kasa_kupur_bakiye_islem
            where tx_no = ln_tx_no;
     END IF;

  Exception
    when others then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '740' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);

  END;


END;
/

