create PACKAGE BODY pkg_report6
IS

   FUNCTION cbs_rapor_vpd_data (
      r_name_        IN   VARCHAR2,
      doviz_kodu_    IN   VARCHAR2,
      type_no_       IN   NUMBER,
      column_no_     IN   NUMBER,
      date_report_        DATE
   )
      RETURN NUMBER
   IS
      RESULT   NUMBER;
   BEGIN
      IF type_no_ = 0 THEN
            SELECT ABS(NVL(SUM (bakiye), 0 ))
              INTO RESULT
              FROM cbs_rpt_sn_balance
             WHERE date_no = DATE_REPORT_ and
			 	   curr_code = doviz_kodu_ AND
                   gl_no IN (SELECT h.dk_kode
                               FROM cbs_rapor_vpd_par_dk h
                              WHERE h.column_no = column_no_ AND
									h.r_name = r_name_);
      ELSIF type_no_ = 1 THEN
            SELECT ABS(NVL(SUM (bakiye), 0 ))
              INTO RESULT
              FROM cbs_rpt_sn_balance
             WHERE date_no = DATE_REPORT_ and
                   curr_code IN (SELECT a2.doviz_kodu
                                   FROM cbs_rapor_vpd_par a1,
								   		cbs_doviz_kodlari a2
                                  WHERE a1.r_name = r_name_ AND
								  		a2.numara = a1.doviz_numara) and
                   gl_no IN (SELECT h.dk_kode
                               FROM cbs_rapor_vpd_par_dk h
                              WHERE h.column_no = column_no_ AND
									h.r_name = r_name_);
      ELSIF type_no_ = 2 THEN
            SELECT ABS(NVL(SUM (bakiye), 0 ))
              INTO RESULT
              FROM cbs_rpt_sn_balance
             WHERE date_no = DATE_REPORT_ and
			 	   curr_code = doviz_kodu_ and
                   curr_code IN (SELECT a2.doviz_kodu
                                   FROM cbs_rapor_vpd_par a1,
								   		cbs_doviz_kodlari a2
                                  WHERE a1.r_name = r_name_ AND
								  		a2.numara = a1.doviz_numara) and
                   gl_no IN (SELECT h.dk_kode
                               FROM cbs_rapor_vpd_par_dk h
                              WHERE h.column_no = column_no_ AND
									h.r_name <> 'R9');
      ELSIF type_no_ = 3 THEN
            SELECT ABS(NVL(SUM (bakiye), 0 ))
              INTO RESULT
              FROM cbs_rpt_sn_balance
             WHERE date_no = DATE_REPORT_ and
                   curr_code IN (SELECT a2.doviz_kodu
                                   FROM cbs_rapor_vpd_par a1,
								   		cbs_doviz_kodlari a2
                                  WHERE a2.numara = a1.doviz_numara) and
                   gl_no IN (SELECT h.dk_kode
                               FROM cbs_rapor_vpd_par_dk h
                              WHERE h.column_no = column_no_ AND
									h.r_name <> 'R9');
      ELSIF type_no_ = 4 THEN
            SELECT NVL(SUM (ABS(bakiye)), 0 )
              INTO RESULT
              FROM cbs_rpt_sn_balance
             WHERE date_no = DATE_REPORT_ and
                   curr_code IN (SELECT a2.doviz_kodu
                                   FROM cbs_rapor_vpd_par a1,
								   		cbs_doviz_kodlari a2
                                  WHERE a2.numara = a1.doviz_numara) and
                   gl_no IN (SELECT h.dk_kode
                               FROM cbs_rapor_vpd_par_dk h
                              WHERE h.column_no = column_no_);
      END IF;

   RETURN (RESULT);

   EXCEPTION
     WHEN OTHERS THEN
       return 0;
   END cbs_rapor_vpd_data;



BEGIN
   NULL;
END pkg_report6;
/

