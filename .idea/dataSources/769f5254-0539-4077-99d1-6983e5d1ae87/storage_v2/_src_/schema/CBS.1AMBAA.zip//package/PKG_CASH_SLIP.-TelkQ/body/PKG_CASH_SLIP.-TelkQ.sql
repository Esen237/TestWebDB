create PACKAGE BODY     Pkg_CASH_SLIP IS

 PROCEDURE Cash_Slip( pn_TX_NO          cbs_cash_slip.tx_no%type,
      pn_ISLEM_TIPI     cbs_cash_slip.islem_tipi%type, -- withdrawal ise 0
      pd_ISLEM_TARIHI      cbs_cash_slip.islem_tarihi%type,-- deposit ise 1
         ps_ISLEM_TIPI_DOVIZ_KODU  cbs_cash_slip.islem_tipi_doviz_kodu%type ,--Islem tipinin doviz kodu
      pn_ISLEM_TIPI_TUTARI   cbs_cash_slip.islem_tipi_tutari%type,-- Ilgili islem tipi icin girilen tutar
      ps_ACIKLAMA       cbs_cash_slip.aciklama%type,--aciklama
      ps_ID_CARD_NO     cbs_cash_slip.id_card_no%type DEFAULT NULL,--id card no
      pn_MUSTERI_HESAP_NO     cbs_cash_slip.musteri_hesap_no%type DEFAULT NULL,--varsa hesap no.(Hesap veya GL)Yok ise musteri adi zorunlu
      ps_GL_HESAP_NO      cbs_cash_slip.gl_hesap_no%type DEFAULT NULL,-- gl hesap no .(Hesap veya GL) Yok ise musteri adi zorunlu
      ps_MUSTERI_ADI      cbs_cash_slip.musteri_adi%type DEFAULT NULL,--GL no veya hesapno girilmemis ise musteri adi gimeli
      pn_PREFIX_ISTATISTIK_KODU    cbs_cash_slip.Prefix_istatistik_kodu%type DEFAULT NULL,-- islem tipinin pre. istatistk kodu
      ps_ISTATISTIK_DOVIZ_KODU   cbs_cash_slip.istatistik_doviz_kodu%type DEFAULT NULL,-- islem tipinin istatistik doviz kodu
      ps_ISTATISTIK_KODU      cbs_cash_slip.istatistik_kodu%type DEFAULT NULL,-- islem tipinin istatistik kodu
      ps_VEREN_KURUM     cbs_cash_slip.veren_kurum%type DEFAULT NULL,--varsa veren kurum
      pd_VERILIS_TARIHI    cbs_cash_slip.verilis_tarihi%type DEFAULT NULL,--varsa verilis tarihi
      pn_KUR        cbs_cash_slip.kur%type DEFAULT NULL,
      pn_ISLEM_KOD         cbs_cash_slip.ISLEM_KOD%type DEFAULT NULL,
      ps_ARB_DVZ_1         cbs_cash_slip.ARB_DVZ_1%type DEFAULT NULL,
      ps_ARB_DVZ_2         cbs_cash_slip.ARB_DVZ_2%type DEFAULT NULL,
      pn_ARB_TUTAR_1         cbs_cash_slip.ARB_TUTAR_1%type DEFAULT NULL,
      pn_ARB_TUTAR_2         cbs_cash_slip.ARB_TUTAR_2%type DEFAULT NULL,
      PN_MUSTERI_NO         cbs_cash_slip.MUSTERI_NO%type DEFAULT NULL,
      ps_BAGLAM_BOLUM     cbs_cash_slip.BAGLAM_BOLUM%type DEFAULT NULL,
      pn_ISLEM_TIPI_LC_KARSILIK    cbs_cash_slip.ISLEM_TIPI_LC_KARSILIK%type DEFAULT NULL,--varsa verilis tarihi
        ps_param_tipi1         cbs_cash_slip.PARAM_TIPI1%type DEFAULT NULL, --cq4640 VictorK
        ps_param_tipi2         cbs_cash_slip.PARAM_TIPI2%type DEFAULT NULL,
        ps_param_doviz1         cbs_cash_slip.param_doviz1%type DEFAULT NULL,
        ps_param_doviz2         cbs_cash_slip.param_doviz2%type DEFAULT NULL,
        pn_param_tutar1         cbs_cash_slip.param_tutar1%type DEFAULT NULL,
        pn_param_tutar2         cbs_cash_slip.param_tutar2%type DEFAULT NULL,
        pn_kupur_kodu         cbs_cash_slip.kupur_kodu%type DEFAULT NULL,
        pn_islem_tutar1    cbs_cash_slip.islem_tutar1%type DEFAULT NULL,
        pn_islem_tutar2    cbs_cash_slip.islem_tutar2%type DEFAULT NULL,
        pn_referans     cbs_cash_slip.REFERANS %type DEFAULT NULL
      )
  IS
  ld_KAYIT_SISTEM_TARIHI   date;
  ln_lc_karsilik     number;
  ls_musteri_adi     varchar2(2000);
  ls_id_card_no     varchar2(20);
  ln_sira_no      number;
  PRAGMA autonomous_transaction;
  BEGIN
log_at('cbs-timka_pd','tim',6,7); 
 ln_sira_no := Pkg_Genel.genel_kod_al('CASH_SLIP');
 IF pn_MUSTERI_HESAP_NO IS NOT NULL OR PN_MUSTERI_NO IS NOT NULL
 THEN
  if PN_MUSTERI_NO IS NOT NULL
  then
   ls_musteri_adi := Pkg_Musteri.Sf_Musteri_Adi(PN_MUSTERI_NO);
  else
   ls_musteri_adi := Pkg_Musteri.Sf_Musteri_Adi(pkg_hesap.HesaptanMusteriNoAl(pn_MUSTERI_HESAP_NO) );
  end if;
 ELSE
    ls_musteri_adi := ps_MUSTERI_ADI ;
 END IF;
 log_at('cbs-timka_pd','tim',6,8); 
 if ps_GL_HESAP_NO is not null then
    if ps_MUSTERI_ADI  is null then
       ls_musteri_adi := 'DEMIR KYRGYZ INTERNATIONAL BANK' ;
    else
       ls_musteri_adi := ps_MUSTERI_ADI ;
    end if;
 end if;
log_at('cbs-timka_pd','tim',6,9); 
 INSERT INTO CBS_CASH_SLIP
 (SIRA_NO,TX_NO, ISLEM_TIPI, ISLEM_TARIHI, KAYIT_SISTEM_TARIHI, MUSTERI_HESAP_NO, GL_HESAP_NO,
  MUSTERI_ADI, PREFIX_ISTATISTIK_KODU, ISTATISTIK_DOVIZ_KODU, ISTATISTIK_KODU,
  ISLEM_TIPI_DOVIZ_KODU, ISLEM_TIPI_TUTARI, ISLEM_TIPI_LC_KARSILIK, ACIKLAMA, ID_CARD_NO,
  VEREN_KURUM,VERILIS_TARIHI,KUR,ISLEM_KOD,ARB_DVZ_1, ARB_DVZ_2, ARB_TUTAR_1, ARB_TUTAR_2,
  MUSTERI_NO,BAGLAM_BOLUM,
        PARAM_TIPI1, --cq4640 VictorK
        PARAM_TIPI2,
        param_doviz1,
        param_doviz2,
        param_tutar1,
        param_tutar2,
        kupur_kodu,
        islem_tutar1,
        islem_tutar2,
        referans
  )
 VALUES
 (ln_sira_no,pn_TX_NO, pn_ISLEM_TIPI, pd_ISLEM_TARIHI, sysdate, pn_MUSTERI_HESAP_NO,ps_GL_HESAP_NO,
  ls_MUSTERI_ADI, pn_PREFIX_ISTATISTIK_KODU, ps_ISTATISTIK_DOVIZ_KODU,ps_ISTATISTIK_KODU,
  ps_ISLEM_TIPI_DOVIZ_KODU, pn_ISLEM_TIPI_TUTARI, pn_ISLEM_TIPI_LC_KARSILIK,ps_ACIKLAMA, ps_ID_CARD_NO,
  ps_VEREN_KURUM,pd_VERILIS_TARIHI,pn_KUR,pn_ISLEM_KOD,ps_ARB_DVZ_1, ps_ARB_DVZ_2, pn_ARB_TUTAR_1, pn_ARB_TUTAR_2,
  PN_MUSTERI_NO,ps_BAGLAM_BOLUM,
        ps_param_tipi1, --cq4640 VictorK
        ps_param_tipi2,
        ps_param_doviz1,
        ps_param_doviz2,
        pn_param_tutar1,
        pn_param_tutar2,
        pn_kupur_kodu,
        pn_islem_tutar1,
        pn_islem_tutar2,
        pn_referans
  );
  log_at('cbs-timka_pd','tim',6,10); 
    COMMIT;
 EXCEPTION
   WHEN OTHERS THEN
     Rollback;
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5062' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END Cash_Slip;
/**************************************************************************************************/

 PROCEDURE Delete_Cash_Slip( pn_TX_NO  cbs_cash_slip.tx_no%type)
  IS
  PRAGMA autonomous_transaction;
  BEGIN

 delete from CBS_CASH_SLIP
 where TX_NO = pn_TX_NO ;
    COMMIT;

 EXCEPTION
   WHEN OTHERS THEN
     Rollback;
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5062' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

   END Delete_Cash_Slip;
/**************************************************************************************************/
END Pkg_CASH_SLIP;
/

