create PACKAGE BODY     Pkg_Kiralik_Kasa IS

 FUNCTION Sf_Kasa_Referans_No_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN VARCHAR2
   IS
	 ls_referans_no CBS_KIRALIK_KASA_ACILIS.referans_no%TYPE;
	BEGIN
	 select referans_no
	   into ls_referans_no
	   from cbs_kiralik_kasa_acilis
	  where durum_kodu = 'A'
	    and	sube_kodu = pn_sube_kodu
	    and SAFE_BOX_NO = pn_SAFE_BOX_NO;

	 return ls_referans_no;

    exception
	  when no_data_found then return null;
	  when others then return null;

    END  Sf_Kasa_Referans_No_Al;
--**************************************************************
 FUNCTION Sf_Kasa_Musteri_No_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN NUMBER
   IS
	 ln_musteri_no NUMBER;
	BEGIN
	 select musteri_no
	   into ln_musteri_no
	   from cbs_kiralik_kasa_acilis
	  where durum_kodu = 'A'
	    and	sube_kodu = pn_sube_kodu
	    and SAFE_BOX_NO = pn_SAFE_BOX_NO;

	 RETURN ln_musteri_no;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN RETURN NULL;

    END  Sf_Kasa_Musteri_No_Al;
--**************************************************************

 FUNCTION Sf_Kasa_Vade_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN DATE
   IS
	 ld_vade DATE;
	BEGIN
	 select vade_tarihi
	   into ld_vade
	   from cbs_kiralik_kasa_tanim
	  where durum_kodu = 'A'
	    and	sube_kodu = pn_sube_kodu
	    and SAFE_BOX_NO = pn_SAFE_BOX_NO;

	 RETURN ld_vade;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN RETURN NULL;

 END Sf_Kasa_Vade_Al;
--**************************************************************

 FUNCTION Sf_Yenileme_Tarihi_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN DATE
   IS
	 ld_yenileme DATE;
	BEGIN
	 select yenileme_tarihi
	   into ld_yenileme
	   from cbs_kiralik_kasa_tanim
	  where durum_kodu = 'A'
	    and	sube_kodu = pn_sube_kodu
	    and SAFE_BOX_NO = pn_SAFE_BOX_NO;

	 RETURN ld_yenileme;

    EXCEPTION
	  WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN RETURN NULL;

 END Sf_Yenileme_Tarihi_Al;

--**************************************************************
END;
/

