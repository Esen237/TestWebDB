create PACKAGE PKG_TX3252 IS

/******************************************************************************
   Name       : PKG_TX3252
   Created By : Seval Balci
   Date    	  : 18.07.05
   Purpose	  : Breysel Kredi Odeme Plani Degisikligi
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure	Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o gun icinde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );

  Function sf_min_acik_taksit_no_al(pn_islem_no number) return number;

  Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2);
  PROCEDURE sp_taksit_vade_tutar_kontrol(pn_islem_no NUMBER );
  PROCEDURE sp_taksit_sira_kalpara_guncel(pn_islem_no NUMBER);
  Function sf_odeme_turu_al(pn_hesap_no number) return varchar2;
  Function sf_acik_taksit_adedi(pn_hesap_no number) return number;
  PROCEDURE sp_taksitsira_guncel(pn_islem_no NUMBER);

END;


/

