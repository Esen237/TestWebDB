create PACKAGE Pkg_Menkul IS

/******************************************************************************
   Name       : PKG_MENKUL
   Created By : Gulnihal Cengiz
   Date    	  : 25/10/2003
   Purpose	  : Menkul islemleri ile ilgili procedure ve fonksiyonlar
******************************************************************************/
 TYPE Generic_CurType IS REF CURSOR;
 FUNCTION   Modul_Tur_Menkul RETURN VARCHAR2;
 FUNCTION   menkul_adi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2 ;
 FUNCTION   tahvil_tescil_grup_adi_al(pn_kod CBS_MENKUL.tahvil_tescil_grup_kod%TYPE,ps_urun_tur CBS_MENKUL.urun_tur_kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   menkul_urun_turu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_urun_sinifi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_kupon_faiz_tipi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_kupon_endeks_turu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_risk_primi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_kupon_yillik_faiz_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_kupon_odeme_donemi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_ilk_kupon_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE;
 FUNCTION   menkul_gelecek_odeme_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE;
 FUNCTION   menkul_gecmis_odeme_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE;
 FUNCTION   menkul_toplam_kupon_adedi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_gun_hesaplama_bazi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_doviz_cinsi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2 ;
 FUNCTION   menkul_dovize_endekli_mi(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2 ;
 FUNCTION   menkul_dovize_para_kodu_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_ihrac_kuru_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 FUNCTION   menkul_ihrac_tarihi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE;
 FUNCTION   menkul_kuponlu_mu(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_vade_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN DATE ;

 PROCEDURE  Kupon_Odeme_Tablosu_Olustur(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 										pn_islem_no NUMBER,pn_islem_tarihi DATE,pn_faiz_orani NUMBER) ;
 FUNCTION   kupon_odeme_tablosu_var_mi(ps_menkul_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Stoktan_Menkul_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2;
 FUNCTION   Stoktan_Stok_Tanim_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2;
 FUNCTION   Stoktan_Depo_Turu_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Stoktan_Saklama_Yeri_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Stok_Nominali_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Stok_adedi_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Stok_Tutari_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Stoktan_Kupur_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Bloke_Durumu_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2;
 FUNCTION   Bloke_Adedi_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;
 FUNCTION   Bloke_Nominali_Bul(pn_kod CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER;

 FUNCTION   Repo_rezerv_adedi(pn_stok_no  NUMBER ) RETURN NUMBER ;
 FUNCTION   Repo_rezerv_nominali(pn_stok_no  NUMBER ) RETURN NUMBER;
 FUNCTION   Repo_rezerv_tutari(pn_stok_no  NUMBER ) RETURN NUMBER;
 FUNCTION   Bloke_Referansi_Al RETURN VARCHAR2;
 FUNCTION   Kupur_Tutari_Al(pn_kod CBS_KUPUR_KODLARI.KOD%TYPE) RETURN NUMBER;

 FUNCTION 	Menkul_REPODONUS_Referansi_Al RETURN VARCHAR2;
 FUNCTION 	Menkul_TERSREPODONUS_Ref_Al RETURN VARCHAR2;
 FUNCTION 	Menkul_BANKATREPODONUS_Ref_Al RETURN VARCHAR2;
 FUNCTION   Menkul_TREPO_DONUSIPTAL_Ref_Al RETURN VARCHAR2;
 FUNCTION   Menkul_BNKTREPODONIPT_Ref_Al RETURN VARCHAR2 ;


 FUNCTION 	Menkul_Itfa_Ref_Al RETURN VARCHAR2;
 FUNCTION   borsa_adi_al(pn_kod CBS_BORSA_KODLARI.kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION  	borsa_uye_adi_al(pn_kod CBS_BORSA_UYE_KODLARI.kod%TYPE) RETURN VARCHAR2;
 FUNCTION   menkul_kiymet_tipi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE ) RETURN NUMBER;
 FUNCTION   ihrac_eden_kurulus_adi_al(pn_kod CBS_IHRACEDENKURULUS_KODLARI.kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   kupon_endeks_tur_adi_al(pn_kod CBS_KUPON_ENDEKS_TUR_KODLARI.kod%TYPE) RETURN VARCHAR2  ;
 FUNCTION   Dealer_adi_al(pn_kod CBS_DEALER_KODLARI.kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Kupur_aciklama_al(pn_kod CBS_KUPUR_KODLARI.kod%TYPE) RETURN VARCHAR2  ;
 FUNCTION   Merkez_Bankasi_Mustno_Al RETURN NUMBER ;
 FUNCTION   Takas_Bank_Mustno_Al RETURN NUMBER ;
 PROCEDURE  Stok_Tablosu_Hareket_Yarat(pn_islem_no NUMBER,pn_islem_tipi NUMBER)   	;
 FUNCTION   Stok_Tanim_adi_al(pn_kod CBS_STOK_KODLARI.kod%TYPE) RETURN VARCHAR2;
 FUNCTION   Stok_No_al RETURN CBS_MENKUL_BANKA_ALIM.stok_no%TYPE;
 FUNCTION   Yasakli_Kiymet_Seri_Kodu_Al RETURN CBS_MENKUL_YASAKLI_KIYMET_SERI.kod%TYPE ;
 PROCEDURE  Stok_Bilgileri_Getir(
 								 pn_stok_no		   		   	CBS_MENKUL_STOK.stok_no%TYPE,
								 ps_stok_tanim			   OUT	CBS_MENKUL_STOK.stok_tanim%TYPE ,
								 ps_depo_turu			   OUT	CBS_MENKUL_STOK.depo_turu%TYPE,
								 pn_saklama_yeri		   OUT	CBS_MENKUL_STOK.saklama_yeri%TYPE,
								 ps_portfoy_tipi		   OUT	CBS_MENKUL_STOK.portfoy_tipi%TYPE ,
								 ps_menkul_kiymet_kodu	   OUT	CBS_MENKUL_STOK.menkul_kiymet_kodu%TYPE ,
								 pn_kupur				   OUT	CBS_MENKUL_STOK.kupur%TYPE ,
								 pn_adet				   OUT	CBS_MENKUL_STOK.adet%TYPE ,
								 pn_nominal_tutar		   OUT	CBS_MENKUL_STOK.nominal_tutar%TYPE ,
								 pn_toplam_tutar		   OUT	CBS_MENKUL_STOK.toplam_tutar%TYPE ,
								 ps_bloke_durumu		   OUT	CBS_MENKUL_STOK.bloke_durumu%TYPE ,
								 pn_bloke_adet			   OUT	CBS_MENKUL_STOK.bloke_adet%TYPE ,
								 pn_bloke_nominal_tutar	   OUT	CBS_MENKUL_STOK.bloke_nominal_tutar%TYPE ,
								 ps_stok_durumu			   OUT	CBS_MENKUL_STOK.stok_durumu%TYPE ,
								 pn_ana_stok			   OUT	CBS_MENKUL_STOK.ana_stok%TYPE ,
								 pn_musteri_no_kime		   OUT	CBS_MENKUL_STOK.musteri_no_kime%TYPE ,
								 pn_hesap_no_kime		   OUT	CBS_MENKUL_STOK.hesap_no_kime%TYPE ,
								 pn_dovend_fiyati		   OUT	CBS_MENKUL_STOK.dovend_fiyati%TYPE ,
								 pn_temiz_fiyat			   OUT	CBS_MENKUL_STOK.temiz_fiyat%TYPE ,
								 pn_kupon_faizli_fiyat	   OUT	CBS_MENKUL_STOK.kupon_faizli_fiyat%TYPE,
								 pn_islenmis_kupon_faizi   OUT	CBS_MENKUL_STOK.islenmis_kupon_faizi%TYPE ,
								 pn_prim_iskonto_tutari	   OUT	CBS_MENKUL_STOK.prim_iskonto_tutari%TYPE
								 );
 FUNCTION   Depo_turu_adi_al(pn_kod CBS_DEPO_TUR_KODLARI.kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Saklama_yeri_adi_al(pn_kod CBS_SAKLAMA_YERI_KODLARI.kod%TYPE) RETURN VARCHAR2;
 FUNCTION   Bloke_nedeni_adi_al(pn_kod CBS_MENKUL_BLOKE_NEDEN_KODLARI.kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Kupon_odeme_tarihi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,pd_tarih DATE)
								     RETURN CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_tarihi%TYPE;
 FUNCTION   Kupon_odeme_sayisi(pn_donem CBS_MENKUL.kupon_odeme_donemi%TYPE) RETURN NUMBER;
 FUNCTION   Onceki_Kupon_Odeme_Tarihi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,pd_tarih	DATE ) RETURN DATE;
 FUNCTION   Sonraki_Kupon_Odeme_Tarihi(pd_kupon_tarihi  DATE, pn_donem CBS_MENKUL.kupon_odeme_donemi%TYPE) RETURN DATE;
 FUNCTION   Kalan_kupon_adedi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_kupon_tarihi	 DATE)
								  RETURN NUMBER;
 FUNCTION   Kalan_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER	;
 FUNCTION   Kupon_donem_faiz_orani_bul(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  								  pd_kupon_tarihi	 DATE)
								  RETURN CBS_MENKUL_KUPON_ODEME_TABLOSU.kupon_donemsel_faiz_orani%TYPE;
 FUNCTION   Gecen_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER;
 FUNCTION   Yil_gun_sayisi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
  							  pd_tarihi	 DATE)  RETURN NUMBER;
 FUNCTION   Islenmis_kupon_faizi(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
   			 					  pn_nominal_tutar NUMBER,
								  pd_portfoye_giris_tarihi DATE) RETURN NUMBER;
 FUNCTION   Menkul_kiymet_tanimli_mi(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN VARCHAR2;
 PROCEDURE  menkul_kiymet_bilgi_al(ps_kod CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 								ps_urun_tur_kod				  OUT CBS_MENKUL.urun_tur_kod%TYPE,
 								ps_urun_sinif_kod             OUT CBS_MENKUL.urun_sinif_kod%TYPE,
  							    pn_tahvil_tescil_grup_kod     OUT CBS_MENKUL.tahvil_tescil_grup_kod%TYPE,
								ps_ulke_kodu   				  OUT CBS_MENKUL.ulke_kodu%TYPE,
								ps_doviz_kodu  				  OUT CBS_MENKUL.doviz_kodu%TYPE,
  								ps_dovize_endeksli_mk     	  OUT CBS_MENKUL.dovize_endeksli_mk%TYPE,
  								ps_endeks_para_kodu       	  OUT CBS_MENKUL.endeks_para_kodu%TYPE,
  								pn_ihrac_kuru             	  OUT CBS_MENKUL.ihrac_kuru%TYPE ,
  								pn_kote_oldugu_borsa_kodu  	  OUT CBS_MENKUL.kote_oldugu_borsa_kodu%TYPE,
  								ps_ihrac_eden_kurum_kurulus   OUT CBS_MENKUL.ihrac_eden_kurum_kurulus%TYPE,
  								pd_ihrac_tarihi               OUT CBS_MENKUL.ihrac_tarihi%TYPE ,
  								pn_ihrac_birim_fiyati         OUT CBS_MENKUL.ihrac_birim_fiyati%TYPE,
  								pd_itfa_tarihi                OUT CBS_MENKUL.itfa_tarihi%TYPE,
  								ps_kupon                      OUT CBS_MENKUL.kupon%TYPE ,
  								ps_kupon_faiz_tipi            OUT CBS_MENKUL.kupon_faiz_tipi%TYPE,
  								pn_kupon_endeks_turu          OUT CBS_MENKUL.kupon_endeks_turu%TYPE  ,
  								pn_kupon_risk_primi           OUT CBS_MENKUL.kupon_risk_primi%TYPE ,
  								pn_kupon_yillik_faiz_orani    OUT CBS_MENKUL.kupon_yillik_faiz_orani%TYPE ,
  								pn_kupon_odeme_donemi         OUT CBS_MENKUL.kupon_odeme_donemi%TYPE ,
  								pd_ilk_kupon_odeme_tarihi     OUT CBS_MENKUL.ilk_kupon_odeme_tarihi%TYPE,
  								pd_gelecek_kupon_odeme_tarihi OUT CBS_MENKUL.gelecek_kupon_odeme_tarihi%TYPE ,
  								pn_toplam_kupon_adedi         OUT CBS_MENKUL.toplam_kupon_adedi%TYPE,
  								pn_gun_hesaplama_bazi         OUT CBS_MENKUL.gun_hesaplama_bazi%TYPE,
  								ps_tescil                     OUT CBS_MENKUL.tescil%TYPE   ,
  								pd_gecmis_kupon_odeme_tarihi  OUT CBS_MENKUL.gecmis_kupon_odeme_tarihi%TYPE
								  );
 FUNCTION   Urun_sinif_doviz_cinsi(ps_modul_kod  CBS_URUN_SINIF.modul_tur_kod%TYPE,
  		   						  ps_urun_tur   CBS_MENKUL.urun_tur_kod%TYPE,
  		   						  ps_urun_sinif CBS_MENKUL.urun_sinif_kod%TYPE) RETURN VARCHAR2 ;
 FUNCTION   Verim_Hesaplama_Kosulu(ps_urun_tur_kodu CBS_MENKUL.urun_tur_kod%TYPE) RETURN NUMBER;
 FUNCTION   Verim_Formul_A(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  pd_portfoye_giris_tarihi DATE,
						  pn_toplam_alis_tutari NUMBER,
 		   		 		  pn_nominal_tutar NUMBER) RETURN NUMBER;
 FUNCTION   FormulB_Toplam(pn_N NUMBER, pn_NominalTutar NUMBER ,pn_verim NUMBER ,
 		   				  pn_KFO NUMBER ,pn_KGS NUMBER, pn_DGS NUMBER ,pn_M NUMBER) RETURN NUMBER 	;

 FUNCTION   Verim_Formul_B(ps_menkul_kiymet_kodu  CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  pd_portfoye_giris_tarihi DATE,
						  pn_toplam_alis_tutari	 NUMBER,
						  pn_NominalTutar 		 NUMBER)	RETURN NUMBER	;
 PROCEDURE  Repo_TRepo_Oran_Tbl_Hazirla(pn_islem_no NUMBER,
 										ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE)   ;

 FUNCTION   Repo_TRepo_Oran_Insert_Konrol(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
									 	  pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
										  ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE) RETURN NUMBER;

 FUNCTION   Repo_TRepo_Oranlari_gnc_ctrl(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
								 	    pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
										ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE) RETURN NUMBER ;
 PROCEDURE  Repo_TRepo_Oran_BilgiAktar(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
								 	  pd_tarih	   CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
									  ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE,
									  pn_txno NUMBER) ;
 FUNCTION   Repo_TRepo_Tutar_Araligi_Bul(ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										pn_tutar CBS_MENKUL_REPO_GIRIS.toplam_repo_tutari%TYPE)
										RETURN NUMBER ;
 FUNCTION   Repo_TRepo_Vade_Araligi_Bul(ps_oran_cinsi CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
										pn_vade CBS_MENKUL_REPO_GIRIS.islem_gun_sayisi%TYPE)
										RETURN NUMBER ;
 FUNCTION   repo_trepo_oran_al(ps_oran_cinsi  CBS_MENKUL_REPO_TREPO_ORANLARI.oran_cinsi%TYPE,
							 pd_tarih	    CBS_MENKUL_REPO_TREPO_ORANLARI.tarih%TYPE,
							 ps_rating_kodu CBS_MENKUL_REPO_TREPO_ORANLARI.rating_kodu%TYPE,
							 pn_tutar 		NUMBER,
							 pn_vade		NUMBER) RETURN NUMBER ;
  FUNCTION   rating_kodu_al(pn_musteri CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;
  FUNCTION   Alt_Stok_Numarasi_Al(ps_tip VARCHAR2) RETURN VARCHAR2  	;
  PROCEDURE  Alt_Stok_Tablosu_Hareket_Yarat(pn_islem_no NUMBER,pn_islem_tipi NUMBER) ;
  FUNCTION   Alt_stok_repo_rezerv_var_mi(pn_islem_tipi NUMBER,pn_stok_no  NUMBER ) RETURN NUMBER ;
  FUNCTION   Alt_stok_repo_tekrar_rezerv(pn_islem_tipi NUMBER,
 										  pn_stok_no  NUMBER,
										  ps_referans CBS_MENKUL_ALT_STOK.islem_referans_no%TYPE
										 ) RETURN NUMBER  ;
  FUNCTION   Stoktaki_SerbestTutar_Yeter_Mi(pn_islem_no NUMBER,pn_islem_tipi NUMBER) RETURN NUMBER ;
  PROCEDURE Menkul_Marj_Orani_BilgiAktar(pd_tarih DATE) ;
  FUNCTION  Gunluk_Marj_Orani_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,pd_tarih DATE  DEFAULT NULL) RETURN NUMBER  ;
  FUNCTION  Gunluk_Satis_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,pd_tarih DATE  DEFAULT NULL) RETURN NUMBER;
  PROCEDURE Menkul_Stok_Bloke_Koy(pn_txno IN NUMBER ,pn_islem_tipi NUMBER) ;
  PROCEDURE Menkul_Stok_Bloke_Kaldir(pn_txno IN NUMBER ,pn_islem_tipi NUMBER) ;
  FUNCTION  stok_bloke_tutari_al(pn_stok_no CBS_MENKUL_STOK.stok_no%TYPE) RETURN NUMBER  ;
  FUNCTION  Gunluk_TCMB_Degerleme_Fiyat_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
  FUNCTION  Gunluk_TCMB_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  						pd_tarih CBS_MENKUL_DEGERLEME_FIYATI.tarih%TYPE DEFAULT NULL) RETURN NUMBER ;
  FUNCTION  Yasakli_Kiymet_Kontrol(ps_menkul_kiymet CBS_MENKUL_YASAKLI_KIYMET_SERI.menkul_kiymet_kodu%TYPE,
								  pn_baslangic CBS_MENKUL_YASAKLI_KIYMET_SERI.baslangic_serino%TYPE,
								  pn_bitis CBS_MENKUL_YASAKLI_KIYMET_SERI.bitis_serino%TYPE)	RETURN NUMBER;
  FUNCTION  Emanet_giris_iptal_ctrl(ps_MEC_Referans_kodu CBS_MENKUL_EMANET_GIRIS.referans_no%TYPE,
  		   							  pn_stokno NUMBER) RETURN NUMBER ;
  PROCEDURE Alis_Satis_Fiyati_BilgiAktar(pd_tarih DATE) ;
  PROCEDURE Degerleme_Fiyati_BilgiAktar(pd_tarih DATE) ;
  FUNCTION  Alis_Satis_Formulu_Kuponsuz(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  	  pd_tarih DATE,
						      pn_verim NUMBER,
 		   		 		      pn_nominal_tutar NUMBER) RETURN NUMBER ;
  FUNCTION  Alis_Satis_Formulu_Kuponlu(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		   				  	  		 pd_tarih DATE,
						      		 pn_verim NUMBER,
 		   		 		      		 pn_nominal_tutar NUMBER) RETURN NUMBER;

  FUNCTION  Kupur_kodu_al(pn_tutar NUMBER) RETURN NUMBER ;
  PROCEDURE Stok_devir_oncesi_Degerler (pn_stok_no CBS_MENKUL_STOK.stok_no%TYPE ,
 		   							   ps_referans 	CBS_MENKUL_STOK_DEVIR_STOK.referans_no%TYPE,
 		   							   pn_adet OUT NUMBER,
									   pn_nominal OUT NUMBER,
									   pn_maliyet OUT NUMBER  );
  PROCEDURE Repo_donus_log( pn_stok_no  NUMBER,ps_alt_stok_no VARCHAR2,ps_depo_turu  VARCHAR2,
  							pn_musteri_no  NUMBER,pn_hesap_no NUMBER,pn_repo_nominal NUMBER,pn_repo_tutar NUMBER,
							ps_referans_no	VARCHAR2,pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2);
  PROCEDURE TRepo_donus_log( pn_musteri_no  NUMBER,pn_hesap_no NUMBER,
  							 pn_toplam_repo_tutari NUMBER,pn_oran_net NUMBER,ps_referans_no	VARCHAR2,
							 pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2) ;
  PROCEDURE Repo_Bilgileri_Getir(
 								 ps_islem_referans_no 	   IN 	   	CBS_MENKUL_REPO_GIRIS.referans_no%TYPE,
								 pn_musteri_no   		   OUT		CBS_MENKUL_REPO_GIRIS.musteri_no%TYPE ,
								 ps_musteri_adi	   		   OUT		VARCHAR2,
								 pn_hesap_no   			   OUT		CBS_MENKUL_REPO_GIRIS.hesap_no%TYPE,
								 ps_hesap_sube			   OUT		CBS_MENKUL_REPO_GIRIS.hesabin_subesi%TYPE,
								 pd_repo_vadesi			   OUT		CBS_MENKUL_REPO_GIRIS.repo_vade_tarihi%TYPE,
								 ps_sube_adi	   		   OUT		VARCHAR2,
								 pd_repo_islem_tarihi	   OUT      CBS_MENKUL_REPO_GIRIS.islem_tarihi%TYPE,
								 pn_oran_net			   OUT		CBS_MENKUL_REPO_GIRIS.oran_net%TYPE,
								 pn_oran_brut  		       OUT		CBS_MENKUL_REPO_GIRIS.oran_brut%TYPE,
								 pn_repo_tutari			   OUT		CBS_MENKUL_REPO_GIRIS.toplam_repo_tutari%TYPE,
								 pn_donus_tutari_brut      OUT		CBS_MENKUL_REPO_GIRIS.donus_tutari_brut%TYPE,
								 pn_donus_tutari_net       OUT		CBS_MENKUL_REPO_GIRIS.donus_tutari_net%TYPE,
								 ps_urun_tur_kod		   OUT		CBS_MENKUL.urun_tur_kod%TYPE,
								 ps_urun_sinif_kod		   OUT		CBS_MENKUL.urun_tur_kod%TYPE,
 								 ps_menkul_kiymet_kodu	   OUT		CBS_MENKUL.menkul_kiymet_kodu%TYPE,
								 pn_acilis_fiyati		   OUT		CBS_MENKUL_REPO_GIRIS.acilis_fiyati%TYPE,
								 pn_kapanis_fiyati		   OUT		CBS_MENKUL_REPO_GIRIS.kapanis_fiyati%TYPE,
								 pn_repo_adedi			   OUT		CBS_MENKUL_REPO_GIRIS.toplam_repo_adedi%TYPE
								);
 FUNCTION  Gunluk_IMKB_Fiyati_Al(ps_menkul_kiymet_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
 		  						pd_tarih CBS_MENKUL_DEGERLEME_FIYATI.tarih%TYPE DEFAULT NULL) RETURN NUMBER;
 PROCEDURE Bloke_Koyma_TutarBilgileri(ps_menkul_kiymet_kodu IN CBS_MENKUL_BLOKE_KOYMA.menkul_kiymet_kodu%TYPE,
 		   							  pn_musteri_no NUMBER,
									  ps_doviz_kodu	    OUT CBS_MENKUL.doviz_kodu%TYPE,
									  ps_urun_tur_kod   OUT CBS_MENKUL.urun_tur_kod%TYPE,
									  ps_urun_sinif_kod OUT CBS_MENKUL.urun_sinif_kod%TYPE,
									  ps_itfa_tarihi    OUT CBS_MENKUL.itfa_tarihi%TYPE,
									  pn_adet			OUT NUMBER,
									  pn_nominal		OUT NUMBER,
									  pn_toplam_tutar	OUT NUMBER,
									  pn_bloke_adet		OUT NUMBER,
									  pn_bloke_nominal  OUT NUMBER,
									  pn_bloke_toplam_tutar	OUT NUMBER,
									  pn_piyasa_fiyati	OUT NUMBER	) ;
 FUNCTION  Bloke_Kaldirma_Referansi_Al RETURN VARCHAR2 ;
 PROCEDURE Stok_Tutar_Duzenle(pn_stok_no    CBS_MENKUL_STOK.stok_no%TYPE,
 		   					  pn_islem_tipi	CBS_MENKUL_STOK_HAREKET.islem_tipi%TYPE,
							  pn_islem_no   CBS_MENKUL_STOK_HAREKET.sira_no%TYPE,
							  pn_islem_nominal	NUMBER DEFAULT NULL,
							  pn_islem_tutar	NUMBER DEFAULT NULL
							 ) ;
 PROCEDURE Stok_Tutar_Duzenle_iptal(pn_stok_no    CBS_MENKUL_STOK.stok_no%TYPE,
							  		 pn_islem_nominal	NUMBER DEFAULT NULL,
							  		 pn_islem_tutar		NUMBER DEFAULT NULL
							 	  ) ;
 FUNCTION  Repo_tutar_aralik_Kontrol RETURN NUMBER;
 FUNCTION  TRepo_tutar_aralik_Kontrol RETURN NUMBER ;
 FUNCTION  Repo_vade_aralik_Kontrol RETURN NUMBER ;
 FUNCTION  TRepo_vade_aralik_Kontrol RETURN NUMBER ;
 FUNCTION  Menkul_Bnk_trepo_iptal_ctrl(ps_BTR_Referans_kodu CBS_MENKUL_BANKA_TREPO_GIRIS.referans_no%TYPE,
  		   							  pn_stokno NUMBER) RETURN NUMBER ;
 PROCEDURE Banka_TRepo_donus_log( pn_musteri_no  NUMBER,pn_hesap_no NUMBER,
  							 pn_toplam_repo_tutari NUMBER,pn_oran_net NUMBER,ps_referans_no	VARCHAR2,
							 pn_hata_kodu NUMBER,ps_hata_mesaji	VARCHAR2) ;
 FUNCTION  Borsa_Uye_Kodu_al(pn_musteri NUMBER) RETURN VARCHAR2;
 FUNCTION  Stok_Kaynagi_Bul(pn_stokno CBS_MENKUL_STOK.stok_no%TYPE) RETURN VARCHAR2;
 FUNCTION  kupon_odeme_tablosu_varmi(ps_menkul_kodu CBS_MENKUL_KUPON_ODEME_TBLISLM.menkul_kiymet_kodu%TYPE) RETURN NUMBER;
 PROCEDURE  Stok_Trepo_Bilgileri_Getir(
 								 	   pn_stok_no		   	CBS_MENKUL_STOK.stok_no%TYPE,
								 	   ps_TREPO 		OUT	CBS_MENKUL_STOK.TREPO%TYPE,
								 	   pd_TREPO_VADE	OUT	CBS_MENKUL_STOK.TREPO_VADE%TYPE
									   );

END;

/

