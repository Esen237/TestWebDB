create PACKAGE BODY     pkg_report
IS
   FUNCTION day_of_week_in_russian_word (day_no NUMBER)
      RETURN VARCHAR2

   IS

      RESULT   VARCHAR2 (14);

   BEGIN

     SELECT DECODE(day_no, 1, 'Воскресенье',

                                                                           2, 'Понедельник',

                                                                           3, 'Вторник',

                                                                           4, 'Среда',

                                                                           5, 'Четверг',

                                                                           6, 'Пятница',

                                                                           7, 'Суббота', '')

               INTO RESULT

               FROM DUAL;





      RETURN (RESULT);

   END day_of_week_in_russian_word;



   FUNCTION VIRTUAL_TABLE_INTEGER

    (

      BEGIN_ IN NUMBER,

      END_   IN NUMBER

    )

   RETURN VIRTUAL_TABLE_TYPE

   IS

     L_DATA VIRTUAL_TABLE_TYPE := VIRTUAL_TABLE_TYPE();

   BEGIN

     FOR I IN BEGIN_ .. END_ LOOP

       L_DATA.EXTEND;

       L_DATA(L_DATA.COUNT) := I;

     END LOOP;

     RETURN L_DATA;

   END;



   FUNCTION VIRTUAL_TABLE_DATE

    (

      BEGIN_DATE_ IN DATE,

      END_DATE_   IN DATE

    )

   RETURN VIRTUAL_TABLE_TYPE_DATE

   IS

     L_DATA VIRTUAL_TABLE_TYPE_DATE := VIRTUAL_TABLE_TYPE_DATE();

   BEGIN

     FOR I IN TO_NUMBER(TO_CHAR(BEGIN_DATE_, 'J')) .. TO_NUMBER(TO_CHAR(END_DATE_, 'J')) LOOP

       L_DATA.EXTEND;

       L_DATA(L_DATA.COUNT) := TO_DATE(I, 'J');

     END LOOP;

     RETURN L_DATA;

   END;



   FUNCTION fill_field (

      SOURCE   IN   VARCHAR2,

      len      IN   NUMBER,

      align    IN   VARCHAR2,                          -- RIGHT, LEFT, CENTER

      char_    IN   VARCHAR2                                           -- ' '

   )

      RETURN VARCHAR2

   IS

      RESULT   VARCHAR2 (1024);

   BEGIN

      IF LENGTH (TRIM (SOURCE)) < len

      THEN

         IF align = 'RIGHT'

         THEN

            RESULT :=

                  fill_char (SUBSTR (char_, 1, 1),

                             len - LENGTH (TRIM (SOURCE))

                            )

               || SOURCE;

         ELSIF align = 'LEFT'

         THEN

            RESULT :=

                  SOURCE

               || fill_char (SUBSTR (char_, 1, 1),

                             len - LENGTH (TRIM (SOURCE))

                            );

         ELSIF align = 'CENTER'

         THEN

            RESULT :=

                  fill_char (SUBSTR (char_, 1, 1),

                             TRUNC ((len - LENGTH (TRIM (SOURCE))) / 2)

                            )

               || SOURCE

               || fill_char (SUBSTR (char_, 1, 1),

                               (len - LENGTH (TRIM (SOURCE))

                               )

                             - TRUNC ((len - LENGTH (TRIM (SOURCE))) / 2)

                            );

         ELSE

            RESULT := SUBSTR (SOURCE, 1, len);

         END IF;

      ELSE

         RESULT := SUBSTR (SOURCE, 1, len);

      END IF;



      RETURN (RESULT);

   END fill_field;



   FUNCTION fill_char (char_ IN VARCHAR2, len IN NUMBER)

      RETURN VARCHAR2

   IS

      RESULT   VARCHAR2 (1024);

   BEGIN

      RESULT := '';



      FOR i IN 1 .. len

      LOOP

         RESULT := RESULT || char_;

      END LOOP;



      RETURN (RESULT);

   END fill_char;



   FUNCTION cbs_rapor_vpd_data (

      r_name_        IN   VARCHAR2,

      doviz_kodu_    IN   VARCHAR2,

      type_no_       IN   NUMBER,

      column_no_     IN   NUMBER,

      date_report_        DATE

   )

      RETURN NUMBER

   IS

      RESULT   NUMBER;

   BEGIN

      IF type_no_ = 0

      THEN

         BEGIN

            SELECT ABS(NVL(SUM (bakiye_lc), 0 ))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT_ AND

                                                   doviz_kod = doviz_kodu_ AND

                  (SUBSTR(numara, 1, 4) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 4 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name = r_name_) OR

                   SUBSTR (numara, 1, 5) IN (SELECT h.dk_kode

                                               FROM CBS_RAPOR_VPD_PAR_DK h

                                              WHERE LENGTH (TRIM (h.dk_kode)) = 5 AND

                                                                                                                                                            h.column_no = column_no_ AND

                                                                                                                                                            h.r_name = r_name_) OR

                   SUBSTR (numara, 1, 6) IN (SELECT h.dk_kode

                                               FROM CBS_RAPOR_VPD_PAR_DK h

                                              WHERE LENGTH (TRIM (h.dk_kode)) = 6 AND

                                                                                                                                                            h.column_no = column_no_ AND

                                                                                                                                                            h.r_name = r_name_));

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      ELSIF type_no_ = 1

      THEN

         BEGIN

            SELECT ABS(NVL(SUM (bakiye_lc), 0 ))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT_ AND

                                                   --doviz_kod = doviz_kodu_ AND

                   doviz_kod IN (SELECT a2.doviz_kodu

                                   FROM CBS_RAPOR_VPD_PAR a1,

                                                                                                                        CBS_DOVIZ_KODLARI a2

                                  WHERE a1.r_name = r_name_ AND

                                                                                                                        a2.numara = a1.doviz_numara) AND

                  (SUBSTR(numara, 1, 4) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 4 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name = r_name_) OR

                   SUBSTR(numara, 1, 5) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 5 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name = r_name_) OR

                   SUBSTR(numara, 1, 6) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 6 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name = r_name_));

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      ELSIF type_no_ = 2

      THEN

         BEGIN

            SELECT ABS(NVL(SUM (bakiye_lc), 0 ))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT_ AND

                                                   doviz_kod = doviz_kodu_ AND

                   doviz_kod IN (SELECT a2.doviz_kodu

                                   FROM CBS_RAPOR_VPD_PAR a1,

                                                                                                                        CBS_DOVIZ_KODLARI a2

                                  WHERE a1.r_name = r_name_ AND

                                                                                                                        a2.numara = a1.doviz_numara) AND

                  (SUBSTR(numara, 1, 4) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 4 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9') OR

                   SUBSTR(numara, 1, 5) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 5 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9') OR

                   SUBSTR(numara, 1, 6) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 6 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9'));

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      ELSIF type_no_ = 3

      THEN

         BEGIN

            SELECT ABS(NVL(SUM (bakiye_lc), 0 ))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT_ AND

                   doviz_kod IN (SELECT a2.doviz_kodu

                                   FROM CBS_RAPOR_VPD_PAR a1,

                                                                                                                        CBS_DOVIZ_KODLARI a2

                                  WHERE a2.numara = a1.doviz_numara) AND

                  (SUBSTR(numara, 1, 4) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 4 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9') OR

                   SUBSTR(numara, 1, 5) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 5 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9') OR

                   SUBSTR(numara, 1, 6) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 6 AND

                                                                                                                                                   h.column_no = column_no_ AND

                                                                                                                                                   h.r_name <> 'R9'));

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      ELSIF type_no_ = 4

      THEN

         BEGIN

            SELECT ABS(NVL(SUM (bakiye_lc), 0 ))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT_ AND

                   doviz_kod IN (SELECT a2.doviz_kodu

                                   FROM CBS_RAPOR_VPD_PAR a1,

                                                                                                                        CBS_DOVIZ_KODLARI a2

                                  WHERE a2.numara = a1.doviz_numara) AND

                  (SUBSTR(numara, 1, 4) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 4 AND

                                                                                                                                                   h.column_no = column_no_) OR

                   SUBSTR(numara, 1, 5) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 5 AND

                                                                                                                                                   h.column_no = column_no_) OR

                   SUBSTR(numara, 1, 6) IN (SELECT h.dk_kode

                                              FROM CBS_RAPOR_VPD_PAR_DK h

                                             WHERE LENGTH (TRIM (h.dk_kode)) = 6 AND

                                                                                                                                                   h.column_no = column_no_));

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      RETURN (RESULT);

   END cbs_rapor_vpd_data;





--**********************************************************************************************************************************************

--**********************************************************************************************************************************************



   FUNCTION cbs_rapor_srv_data (col_no NUMBER, str_no NUMBER, date_report DATE, dvz_code NUMBER)

      RETURN NUMBER

   IS

      RESULT   NUMBER;

   BEGIN

--**********************1-st string******************************

--**********************1-st string******************************

      IF col_no = 1 AND str_no = 1

      THEN

                IF dvz_code = '0' THEN

         BEGIN

            SELECT (SUM(b1)-SUM(b2))*1000

              INTO result

              FROM (SELECT CASE WHEN numara IN ('1001', '1002', '1003', '1004', '1051', '8134', '1101', '1102', '8046', '8125', '8148')

                                                THEN bakiye

                                                ELSE 0

                           END b1,

                           CASE WHEN numara IN ('8137')

                                                THEN bakiye

                                                ELSE 0

                           END b2

                      FROM cbs_vw_sn_balance a

                     WHERE date_no = date_report AND

                           numara IN ('1001', '1002', '1003', '1004', '1051', '8134', '1101', '1102', '8046', '8125', '8148', '8137'));         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

                ELSE

         BEGIN

            SELECT (SUM(b1)-SUM(b2))*1000

              INTO result

              FROM (SELECT CASE WHEN numara IN ('1001', '1002', '1003', '1004', '1051', '8134', '1101', '1102', '8046', '8125', '8148')

                                                THEN bakiye

                                                ELSE 0

                           END b1,

                           CASE WHEN numara IN ('8137')

                                                THEN bakiye

                                                ELSE 0

                           END b2

                      FROM cbs_vw_sn_balance_doviz a

                     WHERE date_no = date_report AND

                                                   ((dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                   (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUB','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                           numara IN ('1001', '1002', '1003', '1004', '1051', '8134', '1101', '1102', '8046', '8125', '8148', '8137'));         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

        END IF;

/*         BEGIN

            SELECT abs(SUM (sum_))

              INTO RESULT

              FROM (

                                                  select SUM (bakiye_lc) sum_

                                                  from cbs_dkhesap_gunluk_bakiye

                         WHERE to_date(pkg_report.fill_field(to_char(gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(ay), 2, 'RIGHT', '0')||to_char(yil), 'ddmmyyyy') = DATE_REPORT and

                                                   ((dvz_code = '0' and doviz_kod = doviz_kod) or

                                                    (dvz_code = '1' and doviz_kod in ('KZT')) or

                                                    (dvz_code = '2' and doviz_kod in ('USD','EUR','GBP','CHF')) or

                                                            (dvz_code = '3' and doviz_kod in ('RUB','TRL','TRY')) or

                                                            (dvz_code = '4' and doviz_kod in ('SOM'))) and

                                                            (SUBSTR(numara, 1, 4)IN ('1001', '1002', '1003', '1004', '1051', '1101', '1209', '1744', '1205', '1745', '1452', '1208',  '2255')or

                                                            SUBSTR(numara, 1, 5) IN ('12011') or

                                                            SUBSTR(numara, 1, 6) IN ('145111', '145113', '145115', '145415', '145311', '145313', '145315'))

                                                  UNION

                                                   select sum(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,nvl(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          from cbs_vw_hesap_izleme b,

                                       cbs_hesap_gunluk_bakiye c

                                                   where substr(b.musteri_dk_no, 1, 6) in ('105224', '105214', '125214', '125224') and

                                                   ((dvz_code = '0' and b.doviz_kodu = b.doviz_kodu) or

                                                    (dvz_code = '1' and b.doviz_kodu in ('KZT')) or

                                                    (dvz_code = '2' and b.doviz_kodu in ('USD','EUR','GBP','CHF')) or

                                                            (dvz_code = '3' and b.doviz_kodu in ('RUB','TRL','TRY')) or

                                                            (dvz_code = '4' and b.doviz_kodu in ('SOM'))) and

                                        b.HESAP_NO = c.HESAP_NO and

                                                                        b.DURUM_KODU='A' and

                                                                        pkg_musteri.Sf_UyrukKod_Al(b.MUSTERI_NO) in ('US','JP','DE') and

                                                                        to_date(pkg_report.fill_field(to_char(c.gun), 2, 'RIGHT', '0')||pkg_report.fill_field(to_char(c.ay), 2, 'RIGHT', '0')||to_char(c.yil), 'ddmmyyyy') = DATE_REPORT);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;*/

      END IF;





      IF col_no = 2 AND str_no = 1

      THEN

         BEGIN

            SELECT ABS(SUM (bakiye_lc))

              INTO RESULT

              FROM CBS_DKHESAP_GUNLUK_BAKIYE

             WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUB','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                   SUBSTR(numara, 1, 4) IN ('2013', '2203', '2211', '2204', '2205', '2221', '2209', '2113', '2125');

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 1

      THEN

         BEGIN

            RESULT := 0;

         EXCEPTION

            WHEN OTHERS

            THEN

               RESULT := 0;

         END;

      END IF;





      --**********************2-nd string******************************

--**********************2-nd string******************************

      IF col_no = 1 AND str_no = 2

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (DECODE(SUBSTR(numara, 1, 4),'2255',ABS(bakiye_lc),bakiye_lc)) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUB','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                                                                           (SUBSTR(numara, 1, 4) IN ('1851', '1853', '1854', '1855', '1856', '1857', '1454', '1860', '1861', '1862', '1863', '1870', '1880', '1455', '1102', '1867', '1458', '1251', '1206', '1207', '1403', '1103','1052', '1252','2255') OR

                                                                                    (SUBSTR(numara, 1, 4)='1201' AND SUBSTR(numara, 1, 5)NOT IN ('12011')) OR

                                                                                    (SUBSTR(numara, 1, 4)='1451' AND SUBSTR(numara, 1, 6) NOT IN ('145111', '145113', '145115', '145415', '145311', '145313', '145315')))

                     UNION

                    SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                                                               WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('1253', '1254','1255','1256','1257','1301','1302','1303','1304','1305','1401','1405','1407','1409','1411', '1414', '1417', '1420', '1422', '1322') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUB','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       b.HESAP_NO = c.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                       --TO_DATE(Pkg_Report.fill_field(TO_CHAR(c.gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(c.ay), 2, 'RIGHT', '0')||TO_CHAR(c.yil), 'ddmmyyyy') = DATE_REPORT AND
                                       c.balance_date= DATE_REPORT AND--CBS-475
                                       b.kredi_vade - b.acilis_tarihi < 33

                                                              UNION

                                                                          SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                                      FROM cbs_vw_hesap_izleme b,

                                                   CBS_HESAP_GUNLUK_BAKIYE c

                                                                           WHERE SUBSTR(b.musteri_dk_no, 1, 6) IN ('105224', '105214', '125214', '125224') AND

                                                                           ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                                            (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR
                                                                            (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR
                                                                                    (dvz_code = '3' AND b.doviz_kodu IN ('RUB','TRL','TRY')) OR
                                                                                    (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND
                                                                b.HESAP_NO = c.HESAP_NO AND
                                                                                                b.DURUM_KODU='A' AND
                                                                                                Pkg_Musteri.Sf_UyrukKod_Al(b.MUSTERI_NO) IN ('US','JP','DE') AND
                                                                                                BALANCE_DATE= DATE_REPORT);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 2

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                                                                           SUBSTR(numara, 1, 4) IN ('2851','2852','2853','2854', '2855','2856','2867','2237','2857', '2860', '2862', '2870', '2880', '2255', '2053')

                     UNION

                    SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('2215', '2223', '2123', '2219', '2206', '2207') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND
                                       b.HESAP_NO = c.HESAP_NO AND
                                       b.DURUM_KODU='A' AND
                                       BALANCE_DATE= DATE_REPORT AND

                                       b.vade_tarihi - b.valor_tarihi < 33);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 2

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                            ((TO_NUMBER(SUBSTR(numara, 1, 4)) BETWEEN 6600 AND 6998) OR

                                                                             SUBSTR(numara, 1, 4)='6020')

                     UNION

                    SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE (SUBSTR(b.musteri_dk_no, 1, 4) NOT IN ('6020') AND

                                                                            TO_NUMBER(SUBSTR(b.musteri_dk_no, 1, 4)) BETWEEN 6000 AND 6100) AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND
                                       b.HESAP_NO = c.HESAP_NO AND
                                                                           b.DURUM_KODU='A' AND
                                       BALANCE_DATE = DATE_REPORT AND
                                       b.vade_tarihi - b.valor_tarihi < 33);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



--**********************3-rd string******************************

--**********************3-rd string******************************

      IF col_no = 1 AND str_no = 3

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('1253','1254','1255','1256','1257','1301','1302','1303','1304','1305','1401','1405','1407','1409','1411','1414','1417','1420','1422','1322') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND
                                       c.HESAP_NO = b.HESAP_NO AND
                                                                           b.DURUM_KODU='A' AND
                                      BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 32 AND

                                                                           b.kredi_vade - b.acilis_tarihi < 93);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 3

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                                                             WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('2215', '2223', '2123', '2219', '2206', '2207') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       b.HESAP_NO = c.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                BALANCE_DATE= DATE_REPORT AND

                                                                           b.vade_tarihi-b.valor_tarihi > 32 AND

                                                                           b.vade_tarihi-b.valor_tarihi < 93);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 3

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE (SUBSTR(b.musteri_dk_no, 1, 4) NOT IN ('6020') AND

                                                                            TO_NUMBER(SUBSTR(b.musteri_dk_no, 1, 4)) BETWEEN 6000 AND 6099) AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND
                                                                           b.DURUM_KODU='A' AND
                                       BALANCE_DATE= DATE_REPORT AND
                                       b.kredi_vade - b.acilis_tarihi > 32 AND
                                                                           b.kredi_vade - b.acilis_tarihi < 93);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      --**********************4-th string******************************

--**********************4-th string******************************

      IF col_no = 1 AND str_no = 4

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('1253','1254','1255','1256','1257','1301','1302','1303','1304','1305','1401','1405','1407','1409','1411','1414','1417','1420','1422','1322') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                          BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 92 AND

                                                                           b.kredi_vade - b.acilis_tarihi < 183);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 4

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                                                                             SUBSTR(numara, 1, 4) IN ('224015', '224017')

                     UNION

                                                             SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                                                             WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('2215', '2223', '2123', '2219', '2206', '2207') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       b.HESAP_NO = c.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                       BALANCE_DATE= DATE_REPORT AND

                                       b.vade_tarihi - b.valor_tarihi > 92 AND

                                                                           b.vade_tarihi - b.valor_tarihi < 183);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 4

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE (SUBSTR(b.musteri_dk_no, 1, 4) NOT IN ('6020') AND

                                                                            TO_NUMBER(SUBSTR(b.musteri_dk_no, 1, 4)) BETWEEN 6000 AND 6099) AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                      BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 92 AND

                                                                           b.kredi_vade - b.acilis_tarihi < 183);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      --**********************5-th string******************************

--**********************5-th string******************************

      IF col_no = 1 AND str_no = 5

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                                                                             SUBSTR(numara, 1, 4) IN ('1857')

                     UNION

                                                             SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('1253','1254','1255','1256','1257','1301','1302','1303','1304','1305','1401','1405','1407','1409','1411','1414','1417','1420','1422','1322') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                        BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 182 AND

                                                                           b.kredi_vade - b.acilis_tarihi < 368);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 5

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                                                             WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('2215', '2223', '2123', '2219', '2206', '2207') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       b.HESAP_NO = c.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                                           BALANCE_DATE= DATE_REPORT AND

                                       b.vade_tarihi - b.valor_tarihi > 182 AND

                                                                           b.vade_tarihi - b.valor_tarihi < 368);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 5

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE (SUBSTR(b.musteri_dk_no, 1, 4) NOT IN ('6020') AND

                                                                            TO_NUMBER(SUBSTR(b.musteri_dk_no, 1, 4)) BETWEEN 6000 AND 6099) AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                       BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 182 AND

                                                                           b.kredi_vade - b.acilis_tarihi < 368);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      --**********************6-th string******************************

--**********************6-th string******************************

      IF col_no = 1 AND str_no = 6

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                           (SUBSTR(numara, 1, 4) IN ('1476') OR

                                                                            SUBSTR(numara, 1, 6) IN ('145125', '145325', '174525'))

                     UNION

                    SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                          FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('1253','1254','1255','1256','1257','1301','1302','1303','1304','1305','1401','1405','1407','1409','1411','1414','1417','1420','1422','1322') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                                           BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 367);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 6

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM (bakiye_lc) sum_

                      FROM CBS_DKHESAP_GUNLUK_BAKIYE

                     WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                           SUBSTR(numara, 1, 4) IN ('2401', '2402', '2130', '2208')



                     UNION

                    SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_VADELI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                                                             WHERE SUBSTR(b.musteri_dk_no, 1, 4) IN ('2215', '2223', '2123', '2219', '2206', '2207') AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       b.HESAP_NO = c.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                                           BALANCE_DATE= DATE_REPORT AND

                                       b.vade_tarihi - b.valor_tarihi > 367);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 6

      THEN

         BEGIN

            SELECT ABS(SUM (sum_))

              INTO RESULT

              FROM (SELECT SUM(Pkg_Kur.doviz_doviz_karsilik(b.DOVIZ_KODU,Pkg_Genel.LC_AL,DATE_REPORT,NVL(c.BAKIYE, 0),1,NULL,NULL,'N','A')) sum_

                      FROM CBS_HESAP_KREDI b,

                                       CBS_HESAP_GUNLUK_BAKIYE c

                     WHERE (SUBSTR(b.musteri_dk_no, 1, 4) NOT IN ('6020') AND

                                                                            TO_NUMBER(SUBSTR(b.musteri_dk_no, 1, 4)) BETWEEN 6000 AND 6099) AND

                                                   ((dvz_code = '0' AND b.doviz_kodu = b.doviz_kodu) OR

                                                    (dvz_code = '1' AND b.doviz_kodu IN ('KZT')) OR

                                                    (dvz_code = '2' AND b.doviz_kodu IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND b.doviz_kodu IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND b.doviz_kodu IN ('SOM'))) AND

                                       c.HESAP_NO = b.HESAP_NO AND

                                                                           b.DURUM_KODU='A' AND

                                                                           BALANCE_DATE= DATE_REPORT AND

                                       b.kredi_vade - b.acilis_tarihi > 367);

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      --**********************7-st string******************************

--**********************7-st string******************************

      IF col_no = 1 AND str_no = 7

      THEN

         BEGIN

                           SELECT SUM (bakiye_lc) sum_

                             INTO result

             FROM CBS_DKHESAP_GUNLUK_BAKIYE

            WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                  SUBSTR(numara, 1, 4) IN ('1306', '1424', '1427', '1257', '1307', '1427');

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 7

      THEN

         BEGIN

                           SELECT SUM (bakiye_lc) sum_

                             INTO result

             FROM CBS_DKHESAP_GUNLUK_BAKIYE

            WHERE TO_DATE(Pkg_Report.fill_field(TO_CHAR(gun), 2, 'RIGHT', '0')||Pkg_Report.fill_field(TO_CHAR(ay), 2, 'RIGHT', '0')||TO_CHAR(yil), 'ddmmyyyy') = DATE_REPORT AND

                                                   ((dvz_code = '0' AND doviz_kod = doviz_kod) OR

                                                    (dvz_code = '1' AND doviz_kod IN ('KZT')) OR

                                                    (dvz_code = '2' AND doviz_kod IN ('USD','EUR','GBP','CHF')) OR

                                                            (dvz_code = '3' AND doviz_kod IN ('RUR','TRL','TRY')) OR

                                                            (dvz_code = '4' AND doviz_kod IN ('SOM'))) AND

                  SUBSTR(numara, 1, 4) IN ('2038', '2058', '2059', '2068', '2225');

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 7

      THEN

         BEGIN

            RESULT := 0;

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      --**********************8-st string******************************

--**********************8-st string******************************

      IF col_no = 1 AND str_no = 8

      THEN

         BEGIN

            RESULT := 0;

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 2 AND str_no = 8

      THEN

         BEGIN

            RESULT := 0;

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      IF col_no = 4 AND str_no = 8

      THEN

         BEGIN

            RESULT := 0;

         EXCEPTION

            WHEN OTHERS THEN

               RESULT := 0;

         END;

      END IF;



      RETURN NVL (RESULT, 0);

   END cbs_rapor_srv_data;







   FUNCTION month_in_russian_word (month_no NUMBER)

      RETURN VARCHAR2

   IS

      RESULT   VARCHAR2 (14);

   BEGIN

      IF month_no = 1

      THEN

         RESULT := 'январь';

      ELSIF month_no = 2

      THEN

         RESULT := 'февраль';

      ELSIF month_no = 3

      THEN

         RESULT := 'март';

      ELSIF month_no = 4

      THEN

         RESULT := 'апрель';

      ELSIF month_no = 5

      THEN

         RESULT := 'май';

      ELSIF month_no = 6

      THEN

         RESULT := 'июнь';

      ELSIF month_no = 7

      THEN

         RESULT := 'июнь';

      ELSIF month_no = 8

      THEN

         RESULT := 'август';

      ELSIF month_no = 9

      THEN

         RESULT := 'сентябрь';

      ELSIF month_no = 10

      THEN

         RESULT := 'октябрь';

      ELSIF month_no = 11

      THEN

         RESULT := 'ноябрь';

      ELSIF month_no = 12

      THEN

         RESULT := 'декабрь';

      END IF;



      RETURN (RESULT);

   END month_in_russian_word;



   FUNCTION month_in_russian_word_genetive (month_no NUMBER)

      RETURN VARCHAR2

   IS

      RESULT   VARCHAR2 (14);

   BEGIN

      IF month_no = 1

      THEN

         RESULT := 'января';

      ELSIF month_no = 2

      THEN

         RESULT := 'февраля';

      ELSIF month_no = 3

      THEN

         RESULT := 'марта';

      ELSIF month_no = 4

      THEN

         RESULT := 'апреля';

      ELSIF month_no = 5

      THEN

         RESULT := 'мая';

      ELSIF month_no = 6

      THEN

         RESULT := 'июня';

      ELSIF month_no = 7

      THEN

         RESULT := 'июля';

      ELSIF month_no = 8

      THEN

         RESULT := 'августа';

      ELSIF month_no = 9

      THEN

         RESULT := 'сентября';

      ELSIF month_no = 10

      THEN

         RESULT := 'октября';

      ELSIF month_no = 11

      THEN

         RESULT := 'ноября';

      ELSIF month_no = 12

      THEN

         RESULT := 'декабря';

      END IF;



      RETURN (RESULT);

   END month_in_russian_word_genetive;



   FUNCTION number_to_word_eng (

      SOURCE        IN   NUMBER,

      doviz_kodu_   IN   CBS_DOVIZ_KODLARI.doviz_kodu%TYPE

   )

      RETURN VARCHAR2

   IS

      RESULT        VARCHAR2 (300);

      aciklama_     CBS_DOVIZ_KODLARI.aciklama%TYPE;

      kurus_adi_    CBS_DOVIZ_KODLARI.kurus_adi%TYPE;

      kuruslu_mu_   CBS_DOVIZ_KODLARI.kuruslu_mu%TYPE;

   BEGIN

      BEGIN

                SELECT A.NAME, A.DECIMAL_NAME

                          INTO aciklama_, kurus_adi_

                          FROM CBS_CURRENCY_NAMES a

                         WHERE a.CURRENCY = DOVIZ_KODU_ AND

                                       a.LANG = 'ENG';

      EXCEPTION

         WHEN OTHERS

         THEN

            aciklama_ := '-';

            kurus_adi_ := '-';

            kuruslu_mu_ := '-';

      END;



      -- k - копейки

      IF  nvl(kurus_adi_,'-')  IS NOT NULL --sevalb 24082011 nvl('-' ) kontrolu eklendi

      THEN

         RESULT :=

               LTRIM

                    (TO_CHAR (SOURCE,

                              '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,.99'

                             )

                    )

            || 'к';

      ELSE

         RESULT :=

            LTRIM (TO_CHAR (SOURCE,

                            '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,'

                           )

                  );

      END IF;



      -- t - тысячи; m - милионы; M - миллиарды;

      RESULT := REPLACE (RESULT, ',,,,,,', 'еМ');

      RESULT := REPLACE (RESULT, ',,,,,', 'ем');

      RESULT := REPLACE (RESULT, ',,,,', 'ет');

      -- e - единицы; d - десятки; c - сотни;

      RESULT := REPLACE (RESULT, ',,,', 'е');

      RESULT := REPLACE (RESULT, ',,', 'д');

      RESULT := REPLACE (RESULT, ',', 'с');

      --

      RESULT := REPLACE (RESULT, '0с0д0ет', '');

      RESULT := REPLACE (RESULT, '0с0д0ем', '');

      RESULT := REPLACE (RESULT, '0с0д0еМ', '');

      --

      RESULT := REPLACE (RESULT, '0с', '');

      RESULT := REPLACE (RESULT, '1с', 'one hundred ');

      RESULT := REPLACE (RESULT, '2с', 'two hundred ');

      RESULT := REPLACE (RESULT, '3с', 'three hundred ');

      RESULT := REPLACE (RESULT, '4с', 'four hundred ');

      RESULT := REPLACE (RESULT, '5с', 'five hundred ');

      RESULT := REPLACE (RESULT, '6с', 'six hundred ');

      RESULT := REPLACE (RESULT, '7с', 'seven hundred ');

      RESULT := REPLACE (RESULT, '8с', 'eight hundred ');

      RESULT := REPLACE (RESULT, '9с', 'nine hundred ');

      --

      RESULT := REPLACE (RESULT, '1д0е', 'ten ');

      RESULT := REPLACE (RESULT, '1д1е', 'eleven ');

      RESULT := REPLACE (RESULT, '1д2е', 'twelve ');

      RESULT := REPLACE (RESULT, '1д3е', 'thirteen ');

      RESULT := REPLACE (RESULT, '1д4е', 'fourteen '); --Sevalb 24082011  hatali duzeltildi.

      RESULT := REPLACE (RESULT, '1д5е', 'fifteen ');

      RESULT := REPLACE (RESULT, '1д6е', 'sixteen ');

      RESULT := REPLACE (RESULT, '1д7е', 'seventeen ');

      RESULT := REPLACE (RESULT, '1д8е', 'eighteen ');

      RESULT := REPLACE (RESULT, '1д9е', 'nineteen ');

      --

      RESULT := REPLACE (RESULT, '0д', '');

      RESULT := REPLACE (RESULT, '2д', 'twenty ');

      RESULT := REPLACE (RESULT, '3д', 'thirty ');

      RESULT := REPLACE (RESULT, '4д', 'forty ');

      RESULT := REPLACE (RESULT, '5д', 'fifty ');

      RESULT := REPLACE (RESULT, '6д', 'sixty ');

      RESULT := REPLACE (RESULT, '7д', 'seventy ');

      RESULT := REPLACE (RESULT, '8д', 'eighty ');

      RESULT := REPLACE (RESULT, '9д', 'ninety ');

      --

      RESULT := REPLACE (RESULT, '0е', '');

      RESULT := REPLACE (RESULT, '5е', 'five ');

      RESULT := REPLACE (RESULT, '6е', 'six ');

      RESULT := REPLACE (RESULT, '7е', 'seven ');

      RESULT := REPLACE (RESULT, '8е', 'eight ');

      RESULT := REPLACE (RESULT, '9е', 'nine ');

      --

      RESULT := REPLACE (RESULT, '1е.', 'one ');

      RESULT := REPLACE (RESULT, '2е.', 'two ');

      RESULT := REPLACE (RESULT, '3е.', 'three ');

      RESULT := REPLACE (RESULT, '4е.', 'four ');

      RESULT := REPLACE (RESULT, '1ет', 'one thousand ');

      RESULT := REPLACE (RESULT, '2ет', 'two thousand ');

      RESULT := REPLACE (RESULT, '3ет', 'three thousand ');

      RESULT := REPLACE (RESULT, '4ет', 'four thousand ');

      RESULT := REPLACE (RESULT, '1ем', 'one million ');

      RESULT := REPLACE (RESULT, '2ем', 'two million ');

      RESULT := REPLACE (RESULT, '3ем', 'three million ');

      RESULT := REPLACE (RESULT, '4ем', 'four million ');

      RESULT := REPLACE (RESULT, '1еМ', 'one milliard ');

      RESULT := REPLACE (RESULT, '2еМ', 'two milliard ');

      RESULT := REPLACE (RESULT, '3еМ', 'three milliard ');

      RESULT := REPLACE (RESULT, '4еМ', 'four milliard ');

      --

      RESULT := REPLACE (RESULT, '11к', '11 ');

      RESULT := REPLACE (RESULT, '12к', '12 ');

      RESULT := REPLACE (RESULT, '13к', '13 ');

      RESULT := REPLACE (RESULT, '14к', '14 ');

      RESULT := REPLACE (RESULT, '1к', '1 ');

      RESULT := REPLACE (RESULT, '2к', '2 ');

      RESULT := REPLACE (RESULT, '3к', '3 ');

      RESULT := REPLACE (RESULT, '4к', '4 ');

      --

      RESULT := REPLACE (RESULT, 'т', 'thousand ');

      RESULT := REPLACE (RESULT, 'м', 'million ');

      RESULT := REPLACE (RESULT, 'М', 'milliard ');

      RESULT := REPLACE (RESULT, 'к', ' ');



      --

      IF NOT (SUBSTR (RESULT, 1, 1) = '.')

      THEN

         RESULT := REPLACE (RESULT, '.', ' ');

      ELSE

         RESULT := REPLACE (RESULT, '.', 'Zero '); --sevalb 24082011 null replaced with zero

      END IF;



      RESULT := TRIM (RESULT);

      RESULT :=

            SUBSTR (RESULT, 1, LENGTH (RESULT) - 2)

         || aciklama_

         || ' '

         || SUBSTR (RESULT, LENGTH (RESULT) - 1, 2)

         || ' '

         || kurus_adi_;

      RETURN (RESULT);

   END number_to_word_eng;



   FUNCTION number_to_word_rus (

      SOURCE        IN   NUMBER,

      doviz_kodu_   IN   CBS_DOVIZ_KODLARI.doviz_kodu%TYPE

   )

      RETURN VARCHAR2

   IS

      RESULT        VARCHAR2 (300);

      aciklama_     CBS_DOVIZ_KODLARI.aciklama%TYPE;

      kurus_adi_    CBS_DOVIZ_KODLARI.kurus_adi%TYPE;

      kuruslu_mu_   CBS_DOVIZ_KODLARI.kuruslu_mu%TYPE;

   BEGIN

      BEGIN

                SELECT A.NAME, A.DECIMAL_NAME

                          INTO aciklama_, kurus_adi_

                          FROM CBS_CURRENCY_NAMES a

                         WHERE a.CURRENCY = DOVIZ_KODU_ AND

                                       a.LANG = 'RUS';

      EXCEPTION

         WHEN OTHERS

         THEN

            aciklama_ := '-';

            kurus_adi_ := '-';

            kuruslu_mu_ := '-';

      END;



      -- k - копейки

      IF nvl(kurus_adi_,'-') IS NOT NULL --sevalb 24082011 nvl('-' ) kontrolu eklendi

      THEN

         RESULT :=

               LTRIM

                    (TO_CHAR (SOURCE,

                              '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,.99'

                             )

                    )

            || 'k';

      ELSE

         RESULT :=

            LTRIM (TO_CHAR (SOURCE,

                            '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,'

                           )

                  );

      END IF;



      -- t - тысячи; m - милионы; M - миллиарды;

      RESULT := REPLACE (RESULT, ',,,,,,', 'eM');

      RESULT := REPLACE (RESULT, ',,,,,', 'em');

      RESULT := REPLACE (RESULT, ',,,,', 'et');

      -- e - единицы; d - десятки; c - сотни;

      RESULT := REPLACE (RESULT, ',,,', 'e');

      RESULT := REPLACE (RESULT, ',,', 'd');

      RESULT := REPLACE (RESULT, ',', 'c');

      --

      RESULT := REPLACE (RESULT, '0c0d0et', '');

      RESULT := REPLACE (RESULT, '0c0d0em', '');

      RESULT := REPLACE (RESULT, '0c0d0eM', '');

      --

      RESULT := REPLACE (RESULT, '0c', '');

      RESULT := REPLACE (RESULT, '1c', 'сто ');

      RESULT := REPLACE (RESULT, '2c', 'двести ');

      RESULT := REPLACE (RESULT, '3c', 'триста ');

      RESULT := REPLACE (RESULT, '4c', 'четыреста ');

      RESULT := REPLACE (RESULT, '5c', 'пятьсот ');

      RESULT := REPLACE (RESULT, '6c', 'шестьсот ');

      RESULT := REPLACE (RESULT, '7c', 'семьсот ');

      RESULT := REPLACE (RESULT, '8c', 'восемьсот ');

      RESULT := REPLACE (RESULT, '9c', 'девятьсот ');

      --

      RESULT := REPLACE (RESULT, '1d0e', 'десять ');

      RESULT := REPLACE (RESULT, '1d1e', 'одиннадцать ');

      RESULT := REPLACE (RESULT, '1d2e', 'двенадцать ');

      RESULT := REPLACE (RESULT, '1d3e', 'тринадцать ');

      RESULT := REPLACE (RESULT, '1d4e', 'четырнадцать ');

      RESULT := REPLACE (RESULT, '1d5e', 'пятнадцать ');

      RESULT := REPLACE (RESULT, '1d6e', 'шестнадцать ');

      RESULT := REPLACE (RESULT, '1d7e', 'семьнадцать ');

      RESULT := REPLACE (RESULT, '1d8e', 'восемнадцать ');

      RESULT := REPLACE (RESULT, '1d9e', 'девятнадцать ');

      --

      RESULT := REPLACE (RESULT, '0d', '');

      RESULT := REPLACE (RESULT, '2d', 'двадцать ');

      RESULT := REPLACE (RESULT, '3d', 'тридцать ');

      RESULT := REPLACE (RESULT, '4d', 'сорок ');

      RESULT := REPLACE (RESULT, '5d', 'пятьдесят ');

      RESULT := REPLACE (RESULT, '6d', 'шестьдесят ');

      RESULT := REPLACE (RESULT, '7d', 'семьдесят ');

      RESULT := REPLACE (RESULT, '8d', 'восемьдесят ');

      RESULT := REPLACE (RESULT, '9d', 'девяносто ');

      --

      RESULT := REPLACE (RESULT, '0e', '');

      RESULT := REPLACE (RESULT, '5e', 'пять ');

      RESULT := REPLACE (RESULT, '6e', 'шесть ');

      RESULT := REPLACE (RESULT, '7e', 'семь ');

      RESULT := REPLACE (RESULT, '8e', 'восемь ');

      RESULT := REPLACE (RESULT, '9e', 'девять ');

      --

      RESULT := REPLACE (RESULT, '1e.', 'один ');

      RESULT := REPLACE (RESULT, '2e.', 'два ');

      RESULT := REPLACE (RESULT, '3e.', 'три ');

      RESULT := REPLACE (RESULT, '4e.', 'четыре ');

      RESULT := REPLACE (RESULT, '1et', 'одна тысяча ');

      RESULT := REPLACE (RESULT, '2et', 'две тысячи ');

      RESULT := REPLACE (RESULT, '3et', 'три тысячи ');

      RESULT := REPLACE (RESULT, '4et', 'четыре тысячи ');

      RESULT := REPLACE (RESULT, '1em', 'один миллион ');

      RESULT := REPLACE (RESULT, '2em', 'два миллиона ');

      RESULT := REPLACE (RESULT, '3em', 'три миллиона ');

      RESULT := REPLACE (RESULT, '4em', 'четыре миллиона ');

      RESULT := REPLACE (RESULT, '1eM', 'один милиард ');

      RESULT := REPLACE (RESULT, '2eM', 'два милиарда ');

      RESULT := REPLACE (RESULT, '3eM', 'три милиарда ');

      RESULT := REPLACE (RESULT, '4eM', 'четыре милиарда ');

      --

      RESULT := REPLACE (RESULT, '11k', '11 ');

      RESULT := REPLACE (RESULT, '12k', '12 ');

      RESULT := REPLACE (RESULT, '13k', '13 ');

      RESULT := REPLACE (RESULT, '14k', '14 ');

      RESULT := REPLACE (RESULT, '1k', '1 ');

      RESULT := REPLACE (RESULT, '2k', '2 ');

      RESULT := REPLACE (RESULT, '3k', '3 ');

      RESULT := REPLACE (RESULT, '4k', '4 ');

      --

      RESULT := REPLACE (RESULT, 't', 'тысяч ');

      RESULT := REPLACE (RESULT, 'm', 'миллионов ');

      RESULT := REPLACE (RESULT, 'M', 'милиардов ');

      RESULT := REPLACE (RESULT, 'k', ' ');



      --

      IF NOT (SUBSTR (RESULT, 1, 1) = '.')

      THEN

         RESULT := REPLACE (RESULT, '.', ' ');

      ELSE

         RESULT := REPLACE (RESULT, '.', 'ноль ');

      END IF;



      RESULT := TRIM (RESULT);

      RESULT :=

            SUBSTR (RESULT, 1, LENGTH (RESULT) - 2)

         || aciklama_

         || ' '

         || SUBSTR (RESULT, LENGTH (RESULT) - 1, 2)

         || ' '

         || kurus_adi_;

      RETURN (RESULT);

   END number_to_word_rus;


   -- B-O-M ErkinZu CQ5232 11.10.2016. This function returns kg name of numeric value
   FUNCTION number_to_word_kgz (

      SOURCE        IN   NUMBER,

      doviz_kodu_   IN   CBS_DOVIZ_KODLARI.doviz_kodu%TYPE

   )

      RETURN VARCHAR2

   IS

      RESULT        VARCHAR2 (300);

      aciklama_     CBS_DOVIZ_KODLARI.aciklama%TYPE;

      kurus_adi_    CBS_DOVIZ_KODLARI.kurus_adi%TYPE;

      kuruslu_mu_   CBS_DOVIZ_KODLARI.kuruslu_mu%TYPE;

   BEGIN

      BEGIN

                SELECT A.NAME, A.DECIMAL_NAME

                          INTO aciklama_, kurus_adi_

                          FROM CBS_CURRENCY_NAMES a

                         WHERE a.CURRENCY = DOVIZ_KODU_ AND

                                       a.LANG = 'KGZ';

      EXCEPTION

         WHEN OTHERS

         THEN

            aciklama_ := '-';

            kurus_adi_ := '-';

            kuruslu_mu_ := '-';

      END;



      -- k - копейки

      IF nvl(kurus_adi_,'-') IS NOT NULL --sevalb 24082011 nvl('-' ) kontrolu eklendi

      THEN

         RESULT :=

               LTRIM

                    (TO_CHAR (SOURCE,

                              '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,.99'

                             )

                    )

            || 'k';

      ELSE

         RESULT :=

            LTRIM (TO_CHAR (SOURCE,

                            '9,9,,9,,,,,,9,9,,9,,,,,9,9,,9,,,,9,9,,9,,,'

                           )

                  );

      END IF;



      -- t - тысячи; m - милионы; M - миллиарды;

      RESULT := REPLACE (RESULT, ',,,,,,', 'eM');

      RESULT := REPLACE (RESULT, ',,,,,', 'em');

      RESULT := REPLACE (RESULT, ',,,,', 'et');

      -- e - единицы; d - десятки; c - сотни;

      RESULT := REPLACE (RESULT, ',,,', 'e');

      RESULT := REPLACE (RESULT, ',,', 'd');

      RESULT := REPLACE (RESULT, ',', 'c');

      --

      RESULT := REPLACE (RESULT, '0c0d0et', '');

      RESULT := REPLACE (RESULT, '0c0d0em', '');

      RESULT := REPLACE (RESULT, '0c0d0eM', '');

      --

      RESULT := REPLACE (RESULT, '0c', '');

      RESULT := REPLACE (RESULT, '1c', 'ж\04AFз ');

      RESULT := REPLACE (RESULT, '2c', 'эки ж\04AFз ');

      RESULT := REPLACE (RESULT, '3c', '\04AFч ж\04AFз ');

      RESULT := REPLACE (RESULT, '4c', 'т\04E9рт ж\04AFз ');

      RESULT := REPLACE (RESULT, '5c', 'беш ж\04AFз ');

      RESULT := REPLACE (RESULT, '6c', 'алты ж\04AFз ');

      RESULT := REPLACE (RESULT, '7c', 'жети ж\04AFз ');

      RESULT := REPLACE (RESULT, '8c', 'сегиз ж\04AFз ');

      RESULT := REPLACE (RESULT, '9c', 'тогуз ж\04AFз ');

      --

      RESULT := REPLACE (RESULT, '1d0e', 'он ');

      RESULT := REPLACE (RESULT, '1d1e', 'он бир ');

      RESULT := REPLACE (RESULT, '1d2e', 'он эки ');

      RESULT := REPLACE (RESULT, '1d3e', 'он  \04AFч');

      RESULT := REPLACE (RESULT, '1d4e', 'он т\04E9рт ');

      RESULT := REPLACE (RESULT, '1d5e', 'он беш ');

      RESULT := REPLACE (RESULT, '1d6e', 'он алты ');

      RESULT := REPLACE (RESULT, '1d7e', 'он жети ');

      RESULT := REPLACE (RESULT, '1d8e', 'он сегиз ');

      RESULT := REPLACE (RESULT, '1d9e', 'он тогуз ');

      --

      RESULT := REPLACE (RESULT, '0d', '');

      RESULT := REPLACE (RESULT, '2d', 'жыйырма ');

      RESULT := REPLACE (RESULT, '3d', 'отуз ');

      RESULT := REPLACE (RESULT, '4d', 'кырк ');

      RESULT := REPLACE (RESULT, '5d', 'эл\04AF\04AF ');

      RESULT := REPLACE (RESULT, '6d', 'алтымыш ');

      RESULT := REPLACE (RESULT, '7d', 'жетимиш ');

      RESULT := REPLACE (RESULT, '8d', 'сексен ');

      RESULT := REPLACE (RESULT, '9d', 'токсон ');

      --

      RESULT := REPLACE (RESULT, '0e', '');

      RESULT := REPLACE (RESULT, '5e', 'беш ');

      RESULT := REPLACE (RESULT, '6e', 'алты ');

      RESULT := REPLACE (RESULT, '7e', 'жети ');

      RESULT := REPLACE (RESULT, '8e', 'сегиз ');

      RESULT := REPLACE (RESULT, '9e', 'тогуз ');

      --

      RESULT := REPLACE (RESULT, '1e.', 'бир ');

      RESULT := REPLACE (RESULT, '2e.', 'эки ');

      RESULT := REPLACE (RESULT, '3e.', '\04AFч ');

      RESULT := REPLACE (RESULT, '4e.', 'т\04E9рт ');

      RESULT := REPLACE (RESULT, '1et', 'бир ми\04A3 ');

      RESULT := REPLACE (RESULT, '2et', 'эки ми\04A3 ');

      RESULT := REPLACE (RESULT, '3et', '\04AFч ми\04A3 ');

      RESULT := REPLACE (RESULT, '4et', 'т\04E9рт ми\04A3 ');

      RESULT := REPLACE (RESULT, '1em', 'бир миллион ');

      RESULT := REPLACE (RESULT, '2em', 'эки миллион ');

      RESULT := REPLACE (RESULT, '3em', '\04AFч миллион ');

      RESULT := REPLACE (RESULT, '4em', 'т\04E9рт миллион ');

      RESULT := REPLACE (RESULT, '1eM', 'бир миллиард ');

      RESULT := REPLACE (RESULT, '2eM', 'эки миллиард ');

      RESULT := REPLACE (RESULT, '3eM', '\04AFч миллиард ');

      RESULT := REPLACE (RESULT, '4eM', 'т\04E9рт миллиард ');

      --

      RESULT := REPLACE (RESULT, '11k', '11 ');

      RESULT := REPLACE (RESULT, '12k', '12 ');

      RESULT := REPLACE (RESULT, '13k', '13 ');

      RESULT := REPLACE (RESULT, '14k', '14 ');

      RESULT := REPLACE (RESULT, '1k', '1 ');

      RESULT := REPLACE (RESULT, '2k', '2 ');

      RESULT := REPLACE (RESULT, '3k', '3 ');

      RESULT := REPLACE (RESULT, '4k', '4 ');

      --

      RESULT := REPLACE (RESULT, 't', 'ми\04A3 ');

      RESULT := REPLACE (RESULT, 'm', 'миллион ');

      RESULT := REPLACE (RESULT, 'M', 'миллиард ');

      RESULT := REPLACE (RESULT, 'k', ' ');



      --

      IF NOT (SUBSTR (RESULT, 1, 1) = '.')

      THEN

         RESULT := REPLACE (RESULT, '.', ' ');

      ELSE

         RESULT := REPLACE (RESULT, '.', 'ноль ');

      END IF;



      RESULT := TRIM (RESULT);

      RESULT :=

            SUBSTR (RESULT, 1, LENGTH (RESULT) - 2)

         || aciklama_

         || ' '

         || SUBSTR (RESULT, LENGTH (RESULT) - 1, 2)

         || ' '

         || kurus_adi_;

      RETURN (RESULT);

   END number_to_word_kgz;
   -- E-O-M ErkinZu CQ5232 11.10.2016. This function returns kg name of numeric value

   PROCEDURE cbs_rapor_1sb_par (month_ NUMBER, year_ VARCHAR2, recalc_ NUMBER)

   IS

      tmp             NUMBER;

      col_1_str_1     NUMBER;

      col_2_str_1     NUMBER;

      col_3_str_1     NUMBER;

      col_4_str_1     NUMBER;

      col_5_str_1     NUMBER;

      col_6_str_1     NUMBER;

      col_1_str_2     NUMBER;

      col_2_str_2     NUMBER;

      col_3_str_2     NUMBER;

      col_4_str_2     NUMBER;

      col_5_str_2     NUMBER;

      col_6_str_2     NUMBER;

      col_1_str_3     NUMBER;

      col_2_str_3     NUMBER;

      col_3_str_3     NUMBER;

      col_4_str_3     NUMBER;

      col_5_str_3     NUMBER;

      col_6_str_3     NUMBER;

      col_1_str_4     NUMBER;

      col_2_str_4     NUMBER;

      col_3_str_4     NUMBER;

      col_4_str_4     NUMBER;

      col_5_str_4     NUMBER;

      col_6_str_4     NUMBER;

      col_1_str_5     NUMBER;

      col_2_str_5     NUMBER;

      col_3_str_5     NUMBER;

      col_4_str_5     NUMBER;

      col_5_str_5     NUMBER;

      col_6_str_5     NUMBER;

      col_1_str_6     NUMBER;

      col_2_str_6     NUMBER;

      col_3_str_6     NUMBER;

      col_4_str_6     NUMBER;

      col_5_str_6     NUMBER;

      col_6_str_6     NUMBER;

      col_1_str_7     NUMBER;

      col_2_str_7     NUMBER;

      col_3_str_7     NUMBER;

      col_4_str_7     NUMBER;

      col_5_str_7     NUMBER;

      col_6_str_7     NUMBER;

      col_1_str_8     NUMBER;

      col_2_str_8     NUMBER;

      col_3_str_8     NUMBER;

      col_4_str_8     NUMBER;

      col_5_str_8     NUMBER;

      col_6_str_8     NUMBER;

      col_1_str_9     NUMBER;

      col_2_str_9     NUMBER;

      col_3_str_9     NUMBER;

      col_4_str_9     NUMBER;

      col_5_str_9     NUMBER;

      col_6_str_9     NUMBER;

      col_1_str_10    NUMBER;

      col_2_str_10    NUMBER;

      col_3_str_10    NUMBER;

      col_4_str_10    NUMBER;

      col_5_str_10    NUMBER;

      col_6_str_10    NUMBER;

      col_1_str_11    NUMBER;

      col_2_str_11    NUMBER;

      col_3_str_11    NUMBER;

      col_4_str_11    NUMBER;

      col_5_str_11    NUMBER;

      col_6_str_11    NUMBER;

      col_1_str_12    NUMBER;

      col_2_str_12    NUMBER;

      col_3_str_12    NUMBER;

      col_4_str_12    NUMBER;

      col_5_str_12    NUMBER;

      col_6_str_12    NUMBER;

      col_1_str_13    NUMBER;

      col_2_str_13    NUMBER;

      col_3_str_13    NUMBER;

      col_4_str_13    NUMBER;

      col_5_str_13    NUMBER;

      col_6_str_13    NUMBER;

      col_1_str_14    NUMBER;

      col_2_str_14    NUMBER;

      col_3_str_14    NUMBER;

      col_4_str_14    NUMBER;

      col_5_str_14    NUMBER;

      col_6_str_14    NUMBER;

      col_1_str_15    NUMBER;

      col_2_str_15    NUMBER;

      col_3_str_15    NUMBER;

      col_4_str_15    NUMBER;

      col_5_str_15    NUMBER;

      col_6_str_15    NUMBER;

      col_7_str_15    NUMBER;

      col_8_str_15    NUMBER;

      col_9_str_15    NUMBER;

      col_10_str_15   NUMBER;

      col_11_str_15   NUMBER;

      col_12_str_15   NUMBER;

      col_1_str_16    NUMBER;

      col_2_str_16    NUMBER;

      col_3_str_16    NUMBER;

      col_4_str_16    NUMBER;

      col_5_str_16    NUMBER;

      col_6_str_16    NUMBER;

      col_7_str_16    NUMBER;

      col_8_str_16    NUMBER;

      col_9_str_16    NUMBER;

      col_10_str_16   NUMBER;

      col_11_str_16   NUMBER;

      col_12_str_16   NUMBER;

      col_1_str_17    NUMBER;

      col_2_str_17    NUMBER;

      col_3_str_17    NUMBER;

      col_4_str_17    NUMBER;

      col_5_str_17    NUMBER;

      col_6_str_17    NUMBER;

      col_7_str_17    NUMBER;

      col_8_str_17    NUMBER;

      col_9_str_17    NUMBER;

      col_10_str_17   NUMBER;

      col_11_str_17   NUMBER;

      col_12_str_17   NUMBER;

      col_1_str_18    NUMBER;

      col_2_str_18    NUMBER;

      col_3_str_18    NUMBER;

      col_4_str_18    NUMBER;

      col_5_str_18    NUMBER;

      col_6_str_18    NUMBER;

      col_7_str_18    NUMBER;

      col_8_str_18    NUMBER;

      col_9_str_18    NUMBER;

      col_10_str_18   NUMBER;

      col_11_str_18   NUMBER;

      col_12_str_18   NUMBER;

      col_1_str_19    NUMBER;

      col_2_str_19    NUMBER;

      col_3_str_19    NUMBER;

      col_4_str_19    NUMBER;

      col_5_str_19    NUMBER;

      col_6_str_19    NUMBER;

      col_7_str_19    NUMBER;

      col_8_str_19    NUMBER;

      col_9_str_19    NUMBER;

      col_10_str_19   NUMBER;

      col_11_str_19   NUMBER;

      col_12_str_19   NUMBER;

      col_1_str_20    NUMBER;

      col_2_str_20    NUMBER;

      col_3_str_20    NUMBER;

      col_4_str_20    NUMBER;

      col_5_str_20    NUMBER;

      col_6_str_20    NUMBER;

      col_7_str_20    NUMBER;

      col_8_str_20    NUMBER;

      col_9_str_20    NUMBER;

      col_10_str_20   NUMBER;

      col_11_str_20   NUMBER;

      col_12_str_20   NUMBER;

      col_1_str_21    NUMBER;

      col_2_str_21    NUMBER;

      col_3_str_21    NUMBER;

      col_4_str_21    NUMBER;

      col_5_str_21    NUMBER;

      col_6_str_21    NUMBER;

      col_7_str_21    NUMBER;

      col_8_str_21    NUMBER;

      col_9_str_21    NUMBER;

      col_10_str_21   NUMBER;

      col_11_str_21   NUMBER;

      col_12_str_21   NUMBER;

      col_1_str_22    NUMBER;

      col_2_str_22    NUMBER;

      col_3_str_22    NUMBER;

      col_4_str_22    NUMBER;

      col_5_str_22    NUMBER;

      col_6_str_22    NUMBER;

      col_7_str_22    NUMBER;

      col_8_str_22    NUMBER;

      col_9_str_22    NUMBER;

      col_10_str_22   NUMBER;

      col_11_str_22   NUMBER;

      col_12_str_22   NUMBER;

      col_1_str_23    NUMBER;

      col_2_str_23    NUMBER;

      col_3_str_23    NUMBER;

      col_4_str_23    NUMBER;

      col_5_str_23    NUMBER;

      col_6_str_23    NUMBER;

      col_7_str_23    NUMBER;

      col_8_str_23    NUMBER;

      col_9_str_23    NUMBER;

      col_10_str_23   NUMBER;

      col_11_str_23   NUMBER;

      col_12_str_23   NUMBER;

      col_1_str_24    NUMBER;

      col_2_str_24    NUMBER;

      col_3_str_24    NUMBER;

      col_4_str_24    NUMBER;

      col_5_str_24    NUMBER;

      col_6_str_24    NUMBER;

      col_7_str_24    NUMBER;

      col_8_str_24    NUMBER;

      col_9_str_24    NUMBER;

      col_10_str_24   NUMBER;

      col_11_str_24   NUMBER;

      col_12_str_24   NUMBER;

      col_1_str_25    NUMBER;

      col_2_str_25    NUMBER;

      col_3_str_25    NUMBER;

      col_4_str_25    NUMBER;

      col_5_str_25    NUMBER;

      col_6_str_25    NUMBER;

      col_7_str_25    NUMBER;

      col_8_str_25    NUMBER;

      col_9_str_25    NUMBER;

      col_10_str_25   NUMBER;

      col_11_str_25   NUMBER;

      col_12_str_25   NUMBER;

      col_1_str_26    NUMBER;

      col_2_str_26    NUMBER;

      col_3_str_26    NUMBER;

      col_4_str_26    NUMBER;

      col_5_str_26    NUMBER;

      col_6_str_26    NUMBER;

      col_7_str_26    NUMBER;

      col_8_str_26    NUMBER;

      col_9_str_26    NUMBER;

      col_10_str_26   NUMBER;

      col_11_str_26   NUMBER;

      col_12_str_26   NUMBER;

      col_1_str_27    NUMBER;

      col_2_str_27    NUMBER;

      col_3_str_27    NUMBER;

      col_4_str_27    NUMBER;

      col_5_str_27    NUMBER;

      col_6_str_27    NUMBER;

      col_7_str_27    NUMBER;

      col_8_str_27    NUMBER;

      col_9_str_27    NUMBER;

      col_10_str_27   NUMBER;

      col_11_str_27   NUMBER;

      col_12_str_27   NUMBER;

      col_1_str_28    NUMBER;

      col_2_str_28    NUMBER;

      col_3_str_28    NUMBER;

      col_4_str_28    NUMBER;

      col_5_str_28    NUMBER;

      col_6_str_28    NUMBER;

      col_7_str_28    NUMBER;

      col_8_str_28    NUMBER;

      col_9_str_28    NUMBER;

      col_10_str_28   NUMBER;

      col_11_str_28   NUMBER;

      col_12_str_28   NUMBER;

      col_1_str_29    NUMBER;

      col_2_str_29    NUMBER;

      col_3_str_29    NUMBER;

      col_4_str_29    NUMBER;

      col_5_str_29    NUMBER;

      col_6_str_29    NUMBER;

      col_7_str_29    NUMBER;

      col_8_str_29    NUMBER;

      col_9_str_29    NUMBER;

      col_10_str_29   NUMBER;

      col_11_str_29   NUMBER;

      col_12_str_29   NUMBER;

      col_1_str_30    NUMBER;

      col_2_str_30    NUMBER;

      col_3_str_30    NUMBER;

      col_4_str_30    NUMBER;

      col_5_str_30    NUMBER;

      col_6_str_30    NUMBER;

      col_7_str_30    NUMBER;

      col_8_str_30    NUMBER;

      col_9_str_30    NUMBER;

      col_10_str_30   NUMBER;

      col_11_str_30   NUMBER;

      col_12_str_30   NUMBER;

      col_1_str_31    NUMBER;

      col_2_str_31    NUMBER;

      col_3_str_31    NUMBER;

      col_4_str_31    NUMBER;

      col_5_str_31    NUMBER;

      col_6_str_31    NUMBER;

      col_7_str_31    NUMBER;

      col_8_str_31    NUMBER;

      col_9_str_31    NUMBER;

      col_10_str_31   NUMBER;

      col_11_str_31   NUMBER;

      col_12_str_31   NUMBER;

      col_1_str_32    NUMBER;

      col_2_str_32    NUMBER;

      col_3_str_32    NUMBER;

      col_4_str_32    NUMBER;

      col_5_str_32    NUMBER;

      col_6_str_32    NUMBER;

      col_7_str_32    NUMBER;

      col_8_str_32    NUMBER;

      col_9_str_32    NUMBER;

      col_10_str_32   NUMBER;

      col_11_str_32   NUMBER;

      col_12_str_32   NUMBER;

      col_1_str_33    NUMBER;

      col_2_str_33    NUMBER;

      col_3_str_33    NUMBER;

      col_4_str_33    NUMBER;

      col_5_str_33    NUMBER;

      col_6_str_33    NUMBER;

      col_7_str_33    NUMBER;

      col_8_str_33    NUMBER;

      col_9_str_33    NUMBER;

      col_10_str_33   NUMBER;

      col_11_str_33   NUMBER;

      col_12_str_33   NUMBER;

      col_1_str_34    NUMBER;

      col_2_str_34    NUMBER;

      col_3_str_34    NUMBER;

      col_4_str_34    NUMBER;

      col_5_str_34    NUMBER;

      col_6_str_34    NUMBER;

      col_7_str_34    NUMBER;

      col_8_str_34    NUMBER;

      col_9_str_34    NUMBER;

      col_10_str_34   NUMBER;

      col_11_str_34   NUMBER;

      col_12_str_34   NUMBER;

      col_1_str_35    NUMBER;

      col_2_str_35    NUMBER;

      col_3_str_35    NUMBER;

      col_4_str_35    NUMBER;

      col_5_str_35    NUMBER;

      col_6_str_35    NUMBER;

      col_7_str_35    NUMBER;

      col_8_str_35    NUMBER;

      col_9_str_35    NUMBER;

      col_10_str_35   NUMBER;

      col_11_str_35   NUMBER;

      col_12_str_35   NUMBER;

      col_1_str_36    NUMBER;

      col_2_str_36    NUMBER;

      col_3_str_36    NUMBER;

      col_4_str_36    NUMBER;

      col_5_str_36    NUMBER;

      col_6_str_36    NUMBER;

      col_7_str_36    NUMBER;

      col_8_str_36    NUMBER;

      col_9_str_36    NUMBER;

      col_10_str_36   NUMBER;

      col_11_str_36   NUMBER;

      col_12_str_36   NUMBER;

      col_1_str_37    NUMBER;

      col_2_str_37    NUMBER;

      col_3_str_37    NUMBER;

      col_4_str_37    NUMBER;

      col_5_str_37    NUMBER;

      col_6_str_37    NUMBER;

      col_7_str_37    NUMBER;

      col_8_str_37    NUMBER;

      col_9_str_37    NUMBER;

      col_10_str_37   NUMBER;

      col_11_str_37   NUMBER;

      col_12_str_37   NUMBER;

      col_1_str_38    NUMBER;

      col_2_str_38    NUMBER;

      col_3_str_38    NUMBER;

      col_4_str_38    NUMBER;

      col_5_str_38    NUMBER;

      col_6_str_38    NUMBER;

      col_7_str_38    NUMBER;

      col_8_str_38    NUMBER;

      col_9_str_38    NUMBER;

      col_10_str_38   NUMBER;

      col_11_str_38   NUMBER;

      col_12_str_38   NUMBER;

      col_1_str_39    NUMBER;

      col_2_str_39    NUMBER;

      col_3_str_39    NUMBER;

      col_4_str_39    NUMBER;

      col_5_str_39    NUMBER;

      col_6_str_39    NUMBER;

      col_7_str_39    NUMBER;

      col_8_str_39    NUMBER;

      col_9_str_39    NUMBER;

      col_10_str_39   NUMBER;

      col_11_str_39   NUMBER;

      col_12_str_39   NUMBER;

      col_1_str_40    NUMBER;

      col_2_str_40    NUMBER;

      col_3_str_40    NUMBER;

      col_4_str_40    NUMBER;

      col_5_str_40    NUMBER;

      col_6_str_40    NUMBER;

      col_7_str_40    NUMBER;

      col_8_str_40    NUMBER;

      col_9_str_40    NUMBER;

      col_10_str_40   NUMBER;

      col_11_str_40   NUMBER;

      col_12_str_40   NUMBER;

      col_1_str_41    NUMBER;

      col_2_str_41    NUMBER;

      col_3_str_41    NUMBER;

      col_4_str_41    NUMBER;

      col_5_str_41    NUMBER;

      col_6_str_41    NUMBER;

      col_7_str_41    NUMBER;

      col_8_str_41    NUMBER;

      col_9_str_41    NUMBER;

      col_10_str_41   NUMBER;

      col_11_str_41   NUMBER;

      col_12_str_41   NUMBER;

      col_1_str_42    NUMBER;

      col_2_str_42    NUMBER;

      col_3_str_42    NUMBER;

      col_4_str_42    NUMBER;

      col_5_str_42    NUMBER;

      col_6_str_42    NUMBER;

      col_7_str_42    NUMBER;

      col_8_str_42    NUMBER;

      col_9_str_42    NUMBER;

      col_10_str_42   NUMBER;

      col_11_str_42   NUMBER;

      col_12_str_42   NUMBER;

      col_1_str_43    NUMBER;

      col_2_str_43    NUMBER;

      col_3_str_43    NUMBER;

      col_4_str_43    NUMBER;

      col_5_str_43    NUMBER;

      col_6_str_43    NUMBER;

      col_7_str_43    NUMBER;

      col_8_str_43    NUMBER;

      col_9_str_43    NUMBER;

      col_10_str_43   NUMBER;

      col_11_str_43   NUMBER;

      col_12_str_43   NUMBER;

      col_1_str_44    NUMBER;

      col_2_str_44    NUMBER;

      col_3_str_44    NUMBER;

      col_4_str_44    NUMBER;

      col_5_str_44    NUMBER;

      col_6_str_44    NUMBER;

      col_7_str_44    NUMBER;

      col_8_str_44    NUMBER;

      col_9_str_44    NUMBER;

      col_10_str_44   NUMBER;

      col_11_str_44   NUMBER;

      col_12_str_44   NUMBER;

      col_1_str_45    NUMBER;

      col_2_str_45    NUMBER;

      col_3_str_45    NUMBER;

      col_4_str_45    NUMBER;

      col_5_str_45    NUMBER;

      col_6_str_45    NUMBER;

      col_7_str_45    NUMBER;

      col_8_str_45    NUMBER;

      col_9_str_45    NUMBER;

      col_10_str_45   NUMBER;

      col_11_str_45   NUMBER;

      col_12_str_45   NUMBER;

      col_1_str_46    NUMBER;

      col_2_str_46    NUMBER;

      col_3_str_46    NUMBER;

      col_4_str_46    NUMBER;

      col_5_str_46    NUMBER;

      col_6_str_46    NUMBER;

      col_7_str_46    NUMBER;

      col_8_str_46    NUMBER;

      col_9_str_46    NUMBER;

      col_10_str_46   NUMBER;

      col_11_str_46   NUMBER;

      col_12_str_46   NUMBER;

      col_1_str_47    NUMBER;

      col_2_str_47    NUMBER;

      col_3_str_47    NUMBER;

      col_4_str_47    NUMBER;

      col_5_str_47    NUMBER;

      col_6_str_47    NUMBER;

      col_7_str_47    NUMBER;

      col_8_str_47    NUMBER;

      col_9_str_47    NUMBER;

      col_10_str_47   NUMBER;

      col_11_str_47   NUMBER;

      col_12_str_47   NUMBER;

      col_1_str_48    NUMBER;

      col_2_str_48    NUMBER;

      col_3_str_48    NUMBER;

      col_4_str_48    NUMBER;

      col_5_str_48    NUMBER;

      col_6_str_48    NUMBER;

      col_7_str_48    NUMBER;

      col_8_str_48    NUMBER;

      col_9_str_48    NUMBER;

      col_10_str_48   NUMBER;

      col_11_str_48   NUMBER;

      col_12_str_48   NUMBER;

      col_1_str_49    NUMBER;

      col_2_str_49    NUMBER;

      col_3_str_49    NUMBER;

      col_4_str_49    NUMBER;

      col_5_str_49    NUMBER;

      col_6_str_49    NUMBER;

      col_7_str_49    NUMBER;

      col_8_str_49    NUMBER;

      col_9_str_49    NUMBER;

      col_10_str_49   NUMBER;

      col_11_str_49   NUMBER;

      col_12_str_49   NUMBER;

      col_1_str_50    NUMBER;

      col_2_str_50    NUMBER;

      col_3_str_50    NUMBER;

      col_4_str_50    NUMBER;

      col_5_str_50    NUMBER;

      col_6_str_50    NUMBER;

      col_7_str_50    NUMBER;

      col_8_str_50    NUMBER;

      col_9_str_50    NUMBER;

      col_10_str_50   NUMBER;

      col_11_str_50   NUMBER;

      col_12_str_50   NUMBER;

   BEGIN

      SELECT COUNT (*)

        INTO tmp

        FROM CBS_RAPOR_1SB_TEMP

       WHERE month_no = month_ AND year_no = year_;



      IF NOT (tmp > 0 AND recalc_ = 0)

      THEN

         DELETE FROM CBS_RAPOR_1SB_TEMP

               WHERE month_no = month_ AND year_no = year_;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate

              INTO col_1_str_2, col_2_str_2, col_3_str_2,

                   col_4_str_2, col_5_str_2, col_6_str_2

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 11;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_2 := 0;

               col_2_str_2 := 0;

               col_3_str_2 := 0;

               col_4_str_2 := 0;

               col_5_str_2 := 0;

               col_6_str_2 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate

              INTO col_1_str_3, col_2_str_3, col_3_str_3,

                   col_4_str_3, col_5_str_3, col_6_str_3

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 12;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_3 := 0;

               col_2_str_3 := 0;

               col_3_str_3 := 0;

               col_4_str_3 := 0;

               col_5_str_3 := 0;

               col_6_str_3 := 0;

         END;



         --col_1_str_5

           --deposits uriki

           --GL 221517, 222317 (LOCAL)



         --col_3_str_5

           --deposits uriki

           --GL 221517, 222317 (HARD)



         --col_5_str_5

           --deposits uriki

           --GL 221517, 222317 (SOFT)



         --col_1_str_6

           --deposits fiziki

           --GL 221519, 220519, 220619, 221119 (LOCAL)



         --col_3_str_6

           --deposits fiziki

           --GL 221519, 220519, 220619, 221119 (HARD)



         --col_5_str_6

           --deposits fiziki

           --GL 221519, 220519, 220619, 221119 (SOFT)



         --col_1_str_8

           --un_deposits uriki

           --GL 221517, 222317 (LOCAL)



         --col_3_str_8

           --un_deposits uriki

           --GL 221517, 222317 (HARD)



         --col_5_str_8

           --un_deposits uriki

           --GL 221517, 222317 (SOFT)



         --col_1_str_9

           --un_deposits fiziki

           --GL 221519, 220519, 220619, 221119 (LOCAL)



         --col_3_str_9

           --un_deposits fiziki

           --GL 221519, 220519, 220619, 221119 (HARD)



         --col_5_str_9

           --un_deposits fiziki

           --GL 221519, 220519, 220619, 221119 (SOFT)

         col_1_str_11 := col_1_str_2 + col_1_str_5 - col_1_str_8;

         col_3_str_11 := col_3_str_2 + col_3_str_5 - col_3_str_8;

         col_5_str_11 := col_5_str_2 + col_5_str_5 - col_5_str_8;

         col_1_str_12 := col_1_str_3 + col_1_str_6 - col_1_str_9;

         col_3_str_12 := col_3_str_3 + col_3_str_6 - col_3_str_9;

         col_5_str_12 := col_5_str_3 + col_5_str_6 - col_5_str_9;

         col_1_str_1 := col_1_str_2 + col_1_str_3;

         col_3_str_1 := col_3_str_2 + col_3_str_3;

         col_5_str_1 := col_5_str_2 + col_5_str_3;

         col_1_str_4 := col_1_str_5 + col_1_str_6;

         col_3_str_4 := col_3_str_5 + col_3_str_6;

         col_5_str_4 := col_5_str_5 + col_5_str_6;

         col_1_str_7 := col_1_str_8 + col_1_str_9;

         col_3_str_7 := col_3_str_8 + col_3_str_9;

         col_5_str_7 := col_5_str_8 + col_5_str_9;

         col_1_str_10 := col_1_str_11 + col_1_str_12;

         col_3_str_10 := col_3_str_11 + col_3_str_12;

         col_5_str_10 := col_5_str_11 + col_5_str_12;

         col_1_str_13 :=

                      (col_1_str_1 + col_1_str_4 - col_1_str_7) + col_1_str_10;

         col_3_str_13 :=

                      (col_3_str_1 + col_3_str_4 - col_3_str_7) + col_3_str_10;

         col_5_str_13 :=

                      (col_5_str_1 + col_5_str_4 - col_5_str_7) + col_5_str_10;

         col_1_str_14 :=

                      (col_1_str_2 + col_1_str_5 - col_1_str_8) + col_1_str_11;

         col_3_str_14 :=

                      (col_3_str_2 + col_3_str_5 - col_3_str_8) + col_3_str_11;

         col_5_str_14 :=

                      (col_5_str_2 + col_5_str_5 - col_5_str_8) + col_5_str_11;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_15, col_2_str_15, col_3_str_15,

                   col_4_str_15, col_5_str_15, col_6_str_15,

                   col_7_str_15, col_8_str_15, col_9_str_15,

                   col_10_str_15, col_11_str_15, col_12_str_15

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 42;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_15 := 0;

               col_2_str_15 := 0;

               col_3_str_15 := 0;

               col_4_str_15 := 0;

               col_5_str_15 := 0;

               col_6_str_15 := 0;

               col_7_str_15 := 0;

               col_8_str_15 := 0;

               col_9_str_15 := 0;

               col_10_str_15 := 0;

               col_11_str_15 := 0;

               col_12_str_15 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_16, col_2_str_16, col_3_str_16,

                   col_4_str_16, col_5_str_16, col_6_str_16,

                   col_7_str_16, col_8_str_16, col_9_str_16,

                   col_10_str_16, col_11_str_16, col_12_str_16

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 43;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_16 := 0;

               col_2_str_16 := 0;

               col_3_str_16 := 0;

               col_4_str_16 := 0;

               col_5_str_16 := 0;

               col_6_str_16 := 0;

               col_7_str_16 := 0;

               col_8_str_16 := 0;

               col_9_str_16 := 0;

               col_10_str_16 := 0;

               col_11_str_16 := 0;

               col_12_str_16 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_17, col_2_str_17, col_3_str_17,

                   col_4_str_17, col_5_str_17, col_6_str_17,

                   col_7_str_17, col_8_str_17, col_9_str_17,

                   col_10_str_17, col_11_str_17, col_12_str_17

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 44;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_17 := 0;

               col_2_str_17 := 0;

               col_3_str_17 := 0;

               col_4_str_17 := 0;

               col_5_str_17 := 0;

               col_6_str_17 := 0;

               col_7_str_17 := 0;

               col_8_str_17 := 0;

               col_9_str_17 := 0;

               col_10_str_17 := 0;

               col_11_str_17 := 0;

               col_12_str_17 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_18, col_2_str_18, col_3_str_18,

                   col_4_str_18, col_5_str_18, col_6_str_18,

                   col_7_str_18, col_8_str_18, col_9_str_18,

                   col_10_str_18, col_11_str_18, col_12_str_18

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 45;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_18 := 0;

               col_2_str_18 := 0;

               col_3_str_18 := 0;

               col_4_str_18 := 0;

               col_5_str_18 := 0;

               col_6_str_18 := 0;

               col_7_str_18 := 0;

               col_8_str_18 := 0;

               col_9_str_18 := 0;

               col_10_str_18 := 0;

               col_11_str_18 := 0;

               col_12_str_18 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_19, col_2_str_19, col_3_str_19,

                   col_4_str_19, col_5_str_19, col_6_str_19,

                   col_7_str_19, col_8_str_19, col_9_str_19,

                   col_10_str_19, col_11_str_19, col_12_str_19

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 46;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_19 := 0;

               col_2_str_19 := 0;

               col_3_str_19 := 0;

               col_4_str_19 := 0;

               col_5_str_19 := 0;

               col_6_str_19 := 0;

               col_7_str_19 := 0;

               col_8_str_19 := 0;

               col_9_str_19 := 0;

               col_10_str_19 := 0;

               col_11_str_19 := 0;

               col_12_str_19 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_20, col_2_str_20, col_3_str_20,

                   col_4_str_20, col_5_str_20, col_6_str_20,

                   col_7_str_20, col_8_str_20, col_9_str_20,

                   col_10_str_20, col_11_str_20, col_12_str_20

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 47;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_20 := 0;

               col_2_str_20 := 0;

               col_3_str_20 := 0;

               col_4_str_20 := 0;

               col_5_str_20 := 0;

               col_6_str_20 := 0;

               col_7_str_20 := 0;

               col_8_str_20 := 0;

               col_9_str_20 := 0;

               col_10_str_20 := 0;

               col_11_str_20 := 0;

               col_12_str_20 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_21, col_2_str_21, col_3_str_21,

                   col_4_str_21, col_5_str_21, col_6_str_21,

                   col_7_str_21, col_8_str_21, col_9_str_21,

                   col_10_str_21, col_11_str_21, col_12_str_21

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 48;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_21 := 0;

               col_2_str_21 := 0;

               col_3_str_21 := 0;

               col_4_str_21 := 0;

               col_5_str_21 := 0;

               col_6_str_21 := 0;

               col_7_str_21 := 0;

               col_8_str_21 := 0;

               col_9_str_21 := 0;

               col_10_str_21 := 0;

               col_11_str_21 := 0;

               col_12_str_21 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_22, col_2_str_22, col_3_str_22,

                   col_4_str_22, col_5_str_22, col_6_str_22,

                   col_7_str_22, col_8_str_22, col_9_str_22,

                   col_10_str_22, col_11_str_22, col_12_str_22

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 49;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_22 := 0;

               col_2_str_22 := 0;

               col_3_str_22 := 0;

               col_4_str_22 := 0;

               col_5_str_22 := 0;

               col_6_str_22 := 0;

               col_7_str_22 := 0;

               col_8_str_22 := 0;

               col_9_str_22 := 0;

               col_10_str_22 := 0;

               col_11_str_22 := 0;

               col_12_str_22 := 0;

         END;



         BEGIN

            SELECT sm_local_amount, sm_local_rate, sm_hard_amount,

                   sm_hard_rate, sm_soft_amount, sm_soft_rate,

                   lo_local_amount, lo_local_rate, lo_hard_amount,

                   lo_hard_rate, lo_soft_amount, lo_soft_rate

              INTO col_1_str_23, col_2_str_23, col_3_str_23,

                   col_4_str_23, col_5_str_23, col_6_str_23,

                   col_7_str_23, col_8_str_23, col_9_str_23,

                   col_10_str_23, col_11_str_23, col_12_str_23

              FROM CBS_RAPOR_1SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 50;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               col_1_str_23 := 0;

               col_2_str_23 := 0;

               col_3_str_23 := 0;

               col_4_str_23 := 0;

               col_5_str_23 := 0;

               col_6_str_23 := 0;

               col_7_str_23 := 0;

               col_8_str_23 := 0;

               col_9_str_23 := 0;

               col_10_str_23 := 0;

               col_11_str_23 := 0;

               col_12_str_23 := 0;

         END;



         col_1_str_25 := 0;

         col_2_str_25 := 0;

         col_3_str_25 := 0;

         col_4_str_25 := 0;

         col_5_str_25 := 0;

         col_6_str_25 := 0;

         --col_7_str_25 :=

           -- deposit fiziki

           -- GL 221119, 220519 (LOCAL)

         col_8_str_25 := 0;

         --col_9_str_25 :=

           -- deposit fiziki

           -- GL 221119, 220519 (HARD)

         col_10_str_25 := 0;

         --col_11_str_25 :=

           -- deposit fiziki

           -- GL 221119, 220519 (SOFT)

         col_12_str_25 := 0;

         --col_1_str_26 :=

           --deposit  uriki

           --GL 221917 (LOCAL)

         col_2_str_26 := 0;

         --col_3_str_26 :=

           --deposit  uriki

           --GL 221917 (HARD)

         col_4_str_26 := 0;

         --col_5_str_26 :=

           --deposit  uriki

           --GL 221917 (SOFT)

         col_6_str_26 := 0;

         --col_7_str_26 :=

           --deposit fiziki

           --GL 221919, 220819 (LOCAL)

         col_8_str_26 := 0;

         --col_9_str_26 :=

           --deposit fiziki

           --GL 221919, 220819 (HARD)

         col_10_str_26 := 0;

         --col_11_str_26 :=

           --deposit fiziki

           --GL 221919, 220819 (SOFT)

         col_12_str_26 := 0;

           --до 1 месяца

         --col_1_str_28 :=

           --deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_28 :=-ДИНАРА

         --col_3_str_28 :=

           --deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_28 :=-ДИНАРА

         --col_5_str_28 :=

           --deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_28 :=-ДИНАРА

         --col_7_str_28 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_28 :=-ДИНАРА

         --col_9_str_28 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_28 :=-ДИНАРА

         --col_11_str_28 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_28 :=-ДИНАРА



         --от 1 до 3 месяцев

         --col_1_str_29 :=

           --deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_29 :=-ДИНАРА

         --col_3_str_29 :=

           --deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_29 :=-ДИНАРА

         --col_5_str_29 :=

           --deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_29 :=-ДИНАРА

         --col_7_str_29 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_29 :=-ДИНАРА

         --col_9_str_29 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_29 :=-ДИНАРА

         --col_11_str_29 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_29 :=-ДИНАРА



         --от 3 месяцев до 1 года

         --col_1_str_30 :=

           --deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_30 :=-ДИНАРА

         --col_3_str_30 :=

           --deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_30 :=-ДИНАРА

         --col_5_str_30 :=

           --deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_30 :=-ДИНАРА

         --col_7_str_30 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_30 :=-ДИНАРА

         --col_9_str_30 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_30 :=-ДИНАРА

         --col_11_str_30 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_30 :=-ДИНАРА



         --от 1 года до 5 лет

         --col_1_str_31 :=

           --deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_31 :=-ДИНАРА

         --col_3_str_31 :=

           --deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_31 :=-ДИНАРА

         --col_5_str_31 :=

           --deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_31 :=-ДИНАРА

         --col_7_str_31 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_31 :=-ДИНАРА

         --col_9_str_31 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_31 :=-ДИНАРА

         --col_11_str_31 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_31 :=-ДИНАРА



         --от 5 лет и более

         --col_1_str_32 :=

           --deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_32 :=-ДИНАРА

         --col_3_str_32 :=

           --deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_32 :=-ДИНАРА

         --col_5_str_32 :=

           --deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_32 :=-ДИНАРА

         --col_7_str_32 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_32 :=-ДИНАРА

         --col_9_str_32 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_32 :=-ДИНАРА

         --col_11_str_32 :=

           --deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_32 :=-ДИНАРА

         col_1_str_27 :=

              col_1_str_28

            + col_1_str_29

            + col_1_str_30

            + col_1_str_31

            + col_1_str_32;

         col_2_str_27 :=

              (  col_1_str_28 * col_2_str_28

               + col_1_str_29 * col_2_str_29

               + col_1_str_30 * col_2_str_30

               + col_1_str_31 * col_2_str_31

               + col_1_str_32 * col_2_str_32

              )

            / col_1_str_27;

         col_3_str_27 :=

              col_3_str_28

            + col_3_str_29

            + col_3_str_30

            + col_3_str_31

            + col_3_str_32;

         col_4_str_27 :=

              (  col_3_str_28 * col_4_str_28

               + col_3_str_29 * col_4_str_29

               + col_3_str_30 * col_4_str_30

               + col_3_str_31 * col_4_str_31

               + col_3_str_32 * col_4_str_32

              )

            / col_3_str_27;

         col_5_str_27 :=

              col_5_str_28

            + col_5_str_29

            + col_5_str_30

            + col_5_str_31

            + col_5_str_32;

         col_6_str_27 :=

              (  col_5_str_28 * col_6_str_28

               + col_5_str_29 * col_6_str_29

               + col_5_str_30 * col_6_str_30

               + col_5_str_31 * col_6_str_31

               + col_5_str_32 * col_6_str_32

              )

            / col_5_str_27;

         col_7_str_27 :=

              col_7_str_28

            + col_7_str_29

            + col_6_str_30

            + col_7_str_31

            + col_7_str_32;

         col_8_str_27 :=

              (  col_7_str_28 * col_8_str_28

               + col_7_str_29 * col_8_str_29

               + col_7_str_30 * col_8_str_30

               + col_7_str_31 * col_8_str_31

               + col_7_str_32 * col_8_str_32

              )

            / col_7_str_27;

         col_9_str_27 :=

              col_9_str_28

            + col_9_str_29

            + col_9_str_30

            + col_9_str_31

            + col_9_str_32;

         col_10_str_27 :=

              (  col_9_str_28 * col_10_str_28

               + col_9_str_29 * col_10_str_29

               + col_9_str_30 * col_10_str_30

               + col_9_str_31 * col_10_str_31

               + col_9_str_32 * col_10_str_32

              )

            / col_9_str_27;

         col_11_str_27 :=

              col_11_str_28

            + col_11_str_29

            + col_11_str_30

            + col_11_str_31

            + col_11_str_32;

         col_12_str_27 :=

              (  col_11_str_28 * col_12_str_28

               + col_11_str_29 * col_12_str_29

               + col_11_str_30 * col_12_str_30

               + col_11_str_31 * col_12_str_31

               + col_11_str_32 * col_12_str_32

              )

            / col_11_str_27;

         col_1_str_24 := col_1_str_25 + col_1_str_26 + col_1_str_27;

         col_2_str_24 := col_1_str_27 * col_2_str_27 / col_1_str_24;

         col_3_str_24 := col_3_str_25 + col_3_str_26 + col_3_str_27;

         col_4_str_24 := col_3_str_27 * col_4_str_27 / col_3_str_24;

         col_5_str_24 := col_5_str_25 + col_5_str_26 + col_5_str_27;

         col_6_str_24 := col_5_str_27 * col_6_str_27 / col_5_str_24;

         col_7_str_24 := col_7_str_25 + col_7_str_26 + col_7_str_27;

         col_8_str_24 := col_7_str_27 * col_8_str_27 / col_7_str_24;

         col_9_str_24 := col_9_str_25 + col_9_str_26 + col_9_str_27;

         col_10_str_24 := col_9_str_27 * col_10_str_27 / col_9_str_24;

         col_11_str_24 := col_11_str_25 + col_11_str_26 + col_11_str_27;

         col_12_str_24 := col_11_str_27 * col_12_str_27 / col_11_str_24;

         col_1_str_34 := 0;

         col_2_str_34 := 0;

         col_3_str_34 := 0;

         col_4_str_34 := 0;

         col_5_str_34 := 0;

         col_6_str_34 := 0;

         --col_7_str_34 :=

           -- un deposit fiziki

           -- GL 221119, 220519 (LOCAL)

         col_8_str_34 := 0;

         --col_9_str_34 :=

           -- un deposit fiziki

           -- GL 221119, 220519 (HARD)

         col_10_str_34 := 0;

         --col_11_str_34 :=

           -- un deposit fiziki

           -- GL 221119, 220519 (SOFT)

         col_12_str_34 := 0;

         --col_1_str_35 :=

           --un deposit  uriki

           --GL 221917 (LOCAL)

         col_2_str_35 := 0;

         --col_3_str_35 :=

           --un deposit  uriki

           --GL 221917 (HARD)

         col_4_str_35 := 0;

         --col_5_str_35 :=

           --un deposit  uriki

           --GL 221917 (SOFT)

         col_6_str_35 := 0;

         --col_7_str_35 :=

           --un deposit fiziki

           --GL 221919, 220819 (LOCAL)

         col_8_str_35 := 0;

         --col_9_str_35 :=

           --un deposit fiziki

           --GL 221919, 220819 (HARD)

         col_10_str_35 := 0;

         --col_11_str_35 :=

           --un deposit fiziki

           --GL 221919, 220819 (SOFT)

         col_12_str_35 := 0;

           --до 1 месяца

         --col_1_str_37 :=

           --un deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_37 :=-ДИНАРА

         --col_3_str_37 :=

           --un deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_37 :=-ДИНАРА

         --col_5_str_37 :=

           --un deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_37 :=-ДИНАРА

         --col_7_str_37 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_37 :=-ДИНАРА

         --col_9_str_37 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_37 :=-ДИНАРА

         --col_11_str_37 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_37 :=-ДИНАРА



         --от 1 до 3 месяцев

         --col_1_str_38 :=

           --un deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_38 :=-ДИНАРА

         --col_3_str_38 :=

           --deposit uriki

           --un GL 221517, 222317 (HARD)

         --col_4_str_38 :=-ДИНАРА

         --col_5_str_38 :=

           --un deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_38 :=-ДИНАРА

         --col_7_str_38 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_38 :=-ДИНАРА

         --col_9_str_38 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_38 :=-ДИНАРА

         --col_11_str_38 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_38 :=-ДИНАРА



         --от 3 месяцев до 1 года

         --col_1_str_39 :=

           --un deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_39 :=-ДИНАРА

         --col_3_str_39 :=

           --un deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_39 :=-ДИНАРА

         --col_5_str_39 :=

           --un deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_39 :=-ДИНАРА

         --col_7_str_39 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_39 :=-ДИНАРА

         --col_9_str_39 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_39 :=-ДИНАРА

         --col_11_str_39 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_39 :=-ДИНАРА



         --от 1 года до 5 лет

         --col_1_str_40 :=

           --un deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_40 :=-ДИНАРА

         --col_3_str_40 :=

           --un deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_40 :=-ДИНАРА

         --col_5_str_40 :=

           --un deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_40 :=-ДИНАРА

         --col_7_str_40 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_40 :=-ДИНАРА

         --col_9_str_40 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_40 :=-ДИНАРА

         --col_11_str_40 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_40 :=-ДИНАРА



         --от 5 лет и более

         --col_1_str_41 :=

           --un deposit uriki

           --GL 221517, 222317 (LOCAL)

         --col_2_str_41 :=-ДИНАРА

         --col_3_str_41 :=

           --un deposit uriki

           --GL 221517, 222317 (HARD)

         --col_4_str_41 :=-ДИНАРА

         --col_5_str_41 :=

           --un deposit uriki

           --GL 221517, 222317 (SOFT)

         --col_6_str_41 :=-ДИНАРА

         --col_7_str_41 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (LOCAL)

         --col_8_str_41 :=-ДИНАРА

         --col_9_str_41 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (HARD)

         --col_10_str_41 :=-ДИНАРА

         --col_11_str_41 :=

           --un deposit fiziki

           --GL 221519, 220619, 220719 (SOFT)

         --col_12_str_41 :=-ДИНАРА

         col_1_str_36 :=

              col_1_str_37

            + col_1_str_38

            + col_1_str_39

            + col_1_str_40

            + col_1_str_41;

         col_2_str_36 :=

              (  col_1_str_37 * col_2_str_37

               + col_1_str_38 * col_2_str_38

               + col_1_str_39 * col_2_str_39

               + col_1_str_40 * col_2_str_40

               + col_1_str_41 * col_2_str_41

              )

            / col_1_str_36;

         col_3_str_36 :=

              col_3_str_37

            + col_3_str_38

            + col_3_str_39

            + col_3_str_40

            + col_3_str_41;

         col_4_str_36 :=

              (  col_3_str_37 * col_4_str_37

               + col_3_str_38 * col_4_str_38

               + col_3_str_39 * col_4_str_39

               + col_3_str_40 * col_4_str_40

               + col_3_str_41 * col_4_str_41

              )

            / col_3_str_36;

         col_5_str_36 :=

              col_5_str_37

            + col_5_str_38

            + col_5_str_39

            + col_5_str_40

            + col_5_str_41;

         col_6_str_36 :=

              (  col_5_str_37 * col_6_str_37

               + col_5_str_38 * col_6_str_38

               + col_5_str_39 * col_6_str_39

               + col_5_str_40 * col_6_str_40

               + col_5_str_41 * col_6_str_41

              )

            / col_5_str_36;

         col_7_str_36 :=

              col_7_str_37

            + col_7_str_38

            + col_6_str_39

            + col_7_str_40

            + col_7_str_41;

         col_8_str_36 :=

              (  col_7_str_37 * col_8_str_37

               + col_7_str_38 * col_8_str_38

               + col_7_str_39 * col_8_str_39

               + col_7_str_40 * col_8_str_40

               + col_7_str_41 * col_8_str_41

              )

            / col_7_str_36;

         col_9_str_36 :=

              col_9_str_37

            + col_9_str_38

            + col_9_str_39

            + col_9_str_40

            + col_9_str_41;

         col_10_str_36 :=

              (  col_9_str_37 * col_10_str_37

               + col_9_str_38 * col_10_str_38

               + col_9_str_39 * col_10_str_39

               + col_9_str_40 * col_10_str_40

               + col_9_str_41 * col_10_str_41

              )

            / col_9_str_36;

         col_11_str_36 :=

              col_11_str_37

            + col_11_str_38

            + col_11_str_39

            + col_11_str_40

            + col_11_str_41;

         col_12_str_36 :=

              (  col_11_str_37 * col_12_str_37

               + col_11_str_38 * col_12_str_38

               + col_11_str_39 * col_12_str_39

               + col_11_str_40 * col_12_str_40

               + col_11_str_41 * col_12_str_41

              )

            / col_11_str_36;

         col_1_str_33 := col_1_str_34 + col_1_str_35 + col_1_str_36;

         col_2_str_33 := col_1_str_36 * col_2_str_36 / col_1_str_33;

         col_3_str_33 := col_3_str_34 + col_3_str_35 + col_3_str_36;

         col_4_str_33 := col_3_str_36 * col_4_str_36 / col_3_str_33;

         col_5_str_33 := col_5_str_34 + col_5_str_35 + col_5_str_36;

         col_6_str_33 := col_5_str_36 * col_6_str_36 / col_5_str_33;

         col_7_str_33 := col_7_str_34 + col_7_str_35 + col_7_str_36;

         col_8_str_33 := col_7_str_36 * col_8_str_36 / col_7_str_33;

         col_9_str_33 := col_9_str_34 + col_9_str_35 + col_9_str_36;

         col_10_str_33 := col_9_str_36 * col_10_str_36 / col_9_str_33;

         col_11_str_33 := col_11_str_34 + col_11_str_35 + col_11_str_36;

         col_12_str_33 := col_11_str_36 * col_12_str_36 / col_11_str_33;

         col_1_str_42 := col_1_str_15 + col_1_str_24 - col_1_str_33;

         col_1_str_43 := col_1_str_16 + col_1_str_25 - col_1_str_34;

         col_1_str_44 := col_1_str_17 + col_1_str_26 - col_1_str_35;

         col_1_str_45 := col_1_str_18 + col_1_str_27 - col_1_str_36;

         col_1_str_46 := col_1_str_19 + col_1_str_28 - col_1_str_37;

         col_1_str_47 := col_1_str_20 + col_1_str_29 - col_1_str_38;

         col_1_str_48 := col_1_str_21 + col_1_str_30 - col_1_str_39;

         col_1_str_49 := col_1_str_22 + col_1_str_31 - col_1_str_40;

         col_1_str_50 := col_1_str_23 + col_1_str_32 - col_1_str_41;

         col_3_str_42 := col_3_str_15 + col_3_str_24 - col_3_str_33;

         col_3_str_43 := col_3_str_16 + col_3_str_25 - col_3_str_34;

         col_3_str_44 := col_3_str_17 + col_3_str_26 - col_3_str_35;

         col_3_str_45 := col_3_str_18 + col_3_str_27 - col_3_str_36;

         col_3_str_46 := col_3_str_19 + col_3_str_28 - col_3_str_37;

         col_3_str_47 := col_3_str_20 + col_3_str_29 - col_3_str_38;

         col_3_str_48 := col_3_str_21 + col_3_str_30 - col_3_str_39;

         col_3_str_49 := col_3_str_22 + col_3_str_31 - col_3_str_40;

         col_3_str_50 := col_3_str_23 + col_3_str_32 - col_3_str_41;

         col_5_str_42 := col_5_str_15 + col_5_str_24 - col_5_str_33;

         col_5_str_43 := col_5_str_16 + col_5_str_25 - col_5_str_34;

         col_5_str_44 := col_5_str_17 + col_5_str_26 - col_5_str_35;

         col_5_str_45 := col_5_str_18 + col_5_str_27 - col_5_str_36;

         col_5_str_46 := col_5_str_19 + col_5_str_28 - col_5_str_37;

         col_5_str_47 := col_5_str_20 + col_5_str_29 - col_5_str_38;

         col_5_str_48 := col_5_str_21 + col_5_str_30 - col_5_str_39;

         col_5_str_49 := col_5_str_22 + col_5_str_31 - col_5_str_40;

         col_5_str_50 := col_5_str_23 + col_5_str_32 - col_5_str_41;

         col_7_str_42 := col_7_str_15 + col_7_str_24 - col_7_str_33;

         col_7_str_43 := col_7_str_16 + col_7_str_25 - col_7_str_34;

         col_7_str_44 := col_7_str_17 + col_7_str_26 - col_7_str_35;

         col_7_str_45 := col_7_str_18 + col_7_str_27 - col_7_str_36;

         col_7_str_46 := col_7_str_19 + col_7_str_28 - col_7_str_37;

         col_7_str_47 := col_7_str_20 + col_7_str_29 - col_7_str_38;

         col_7_str_48 := col_7_str_21 + col_7_str_30 - col_7_str_39;

         col_7_str_49 := col_7_str_22 + col_7_str_31 - col_7_str_40;

         col_7_str_50 := col_7_str_23 + col_7_str_32 - col_7_str_41;

         col_9_str_42 := col_9_str_15 + col_9_str_24 - col_9_str_33;

         col_9_str_43 := col_9_str_16 + col_9_str_25 - col_9_str_34;

         col_9_str_44 := col_9_str_17 + col_9_str_26 - col_9_str_35;

         col_9_str_45 := col_9_str_18 + col_9_str_27 - col_9_str_36;

         col_9_str_46 := col_9_str_19 + col_9_str_28 - col_9_str_37;

         col_9_str_47 := col_9_str_20 + col_9_str_29 - col_9_str_38;

         col_9_str_48 := col_9_str_21 + col_9_str_30 - col_9_str_39;

         col_9_str_49 := col_9_str_22 + col_9_str_31 - col_9_str_40;

         col_9_str_50 := col_9_str_23 + col_9_str_32 - col_9_str_41;

         col_11_str_42 := col_11_str_15 + col_11_str_24 - col_11_str_33;

         col_11_str_43 := col_11_str_16 + col_11_str_25 - col_11_str_34;

         col_11_str_44 := col_11_str_17 + col_11_str_26 - col_11_str_35;

         col_11_str_45 := col_11_str_18 + col_11_str_27 - col_11_str_36;

         col_11_str_46 := col_11_str_19 + col_11_str_28 - col_11_str_37;

         col_11_str_47 := col_11_str_20 + col_11_str_29 - col_11_str_38;

         col_11_str_48 := col_11_str_21 + col_11_str_30 - col_11_str_39;

         col_11_str_49 := col_11_str_22 + col_11_str_31 - col_11_str_40;

         col_11_str_50 := col_11_str_23 + col_11_str_32 - col_11_str_41;

         --col_2_str_43 :=-ДИНАРА

         --col_2_str_44 :=-ДИНАРА

         --col_2_str_46 :=-ДИНАРА

         --col_2_str_47 :=-ДИНАРА

         --col_2_str_48 :=-ДИНАРА

         --col_2_str_49 :=-ДИНАРА

         --col_2_str_50 :=-ДИНАРА



         --col_4_str_43 :=-ДИНАРА

         --col_4_str_44 :=-ДИНАРА

         --col_4_str_46 :=-ДИНАРА

         --col_4_str_47 :=-ДИНАРА

         --col_4_str_48 :=-ДИНАРА

         --col_4_str_49 :=-ДИНАРА

         --col_4_str_50 :=-ДИНАРА



         --col_6_str_43 :=-ДИНАРА

         --col_6_str_44 :=-ДИНАРА

         --col_6_str_46 :=-ДИНАРА

         --col_6_str_47 :=-ДИНАРА

         --col_6_str_48 :=-ДИНАРА

         --col_6_str_49 :=-ДИНАРА

         --col_6_str_50 :=-ДИНАРА



         --col_8_str_43 :=-ДИНАРА

         --col_8_str_44 :=-ДИНАРА

         --col_8_str_46 :=-ДИНАРА

         --col_8_str_47 :=-ДИНАРА

         --col_8_str_48 :=-ДИНАРА

         --col_8_str_49 :=-ДИНАРА

         --col_8_str_50 :=-ДИНАРА



         --col_10_str_43 :=-ДИНАРА

         --col_10_str_44 :=-ДИНАРА

         --col_10_str_46 :=-ДИНАРА

         --col_10_str_47 :=-ДИНАРА

         --col_10_str_48 :=-ДИНАРА

         --col_10_str_49 :=-ДИНАРА

         --col_10_str_50 :=-ДИНАРА



         --col_12_str_43 :=-ДИНАРА

         --col_12_str_44 :=-ДИНАРА

         --col_12_str_46 :=-ДИНАРА

         --col_12_str_47 :=-ДИНАРА

         --col_12_str_48 :=-ДИНАРА

         --col_12_str_49 :=-ДИНАРА

         --col_12_str_50 :=-ДИНАРА

         col_2_str_45 :=

              (  col_1_str_46 * col_2_str_46

               + col_1_str_47 * col_2_str_47

               + col_1_str_48 * col_2_str_48

               + col_1_str_49 * col_2_str_49

               + col_1_str_50 * col_2_str_50

              )

            / col_1_str_45;

         col_2_str_42 :=

              (  col_1_str_43 * col_2_str_43

               + col_1_str_44 * col_2_str_44

               + col_1_str_45 * col_2_str_45

              )

            / col_1_str_42;

         col_4_str_45 :=

              (  col_3_str_46 * col_4_str_46

               + col_3_str_47 * col_4_str_47

               + col_3_str_48 * col_4_str_48

               + col_3_str_49 * col_4_str_49

               + col_3_str_50 * col_4_str_50

              )

            / col_3_str_45;

         col_4_str_42 :=

              (  col_3_str_43 * col_4_str_43

               + col_3_str_44 * col_4_str_44

               + col_3_str_45 * col_4_str_45

              )

            / col_3_str_42;

         col_6_str_45 :=

              (  col_5_str_46 * col_6_str_46

               + col_5_str_47 * col_6_str_47

               + col_5_str_48 * col_6_str_48

               + col_5_str_49 * col_6_str_49

               + col_5_str_50 * col_6_str_50

              )

            / col_5_str_45;

         col_6_str_42 :=

              (  col_5_str_43 * col_6_str_43

               + col_5_str_44 * col_6_str_44

               + col_5_str_45 * col_6_str_45

              )

            / col_5_str_42;

         col_8_str_45 :=

              (  col_7_str_46 * col_8_str_46

               + col_7_str_47 * col_8_str_47

               + col_7_str_48 * col_8_str_48

               + col_7_str_49 * col_8_str_49

               + col_7_str_50 * col_8_str_50

              )

            / col_7_str_45;

         col_8_str_42 :=

              (  col_7_str_43 * col_8_str_43

               + col_7_str_44 * col_8_str_44

               + col_7_str_45 * col_8_str_45

              )

            / col_7_str_42;

         col_10_str_45 :=

              (  col_9_str_46 * col_10_str_46

               + col_9_str_47 * col_10_str_47

               + col_9_str_48 * col_10_str_48

               + col_9_str_49 * col_10_str_49

               + col_9_str_50 * col_10_str_50

              )

            / col_9_str_45;

         col_10_str_42 :=

              (  col_9_str_43 * col_10_str_43

               + col_9_str_44 * col_10_str_44

               + col_9_str_45 * col_10_str_45

              )

            / col_9_str_42;

         col_12_str_45 :=

              (  col_11_str_46 * col_12_str_46

               + col_11_str_47 * col_12_str_47

               + col_11_str_48 * col_12_str_48

               + col_11_str_49 * col_12_str_49

               + col_11_str_50 * col_12_str_50

              )

            / col_11_str_45;

         col_12_str_42 :=

              (  col_11_str_43 * col_12_str_43

               + col_11_str_44 * col_12_str_44

               + col_11_str_45 * col_12_str_45

              )

            / col_11_str_42;

         col_2_str_5 := col_2_str_24;

         col_4_str_5 := col_4_str_24;

         col_6_str_5 := col_6_str_24;

         col_2_str_6 := col_8_str_24;

         col_4_str_6 := col_10_str_24;

         col_6_str_6 := col_12_str_24;

         col_2_str_8 := col_2_str_33;

         col_4_str_8 := col_4_str_33;

         col_6_str_8 := col_6_str_33;

         col_2_str_9 := col_8_str_33;

         col_4_str_9 := col_10_str_33;

         col_6_str_9 := col_12_str_33;

         col_2_str_11 := col_2_str_42;

         col_4_str_11 := col_4_str_42;

         col_6_str_11 := col_6_str_42;

         col_2_str_12 := col_8_str_42;

         col_4_str_12 := col_10_str_42;

         col_6_str_12 := col_12_str_42;



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '1. Остатки денег на счетах вкладов юридических и физических лиц на начало отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '1',                                           --code_no

                          col_1_str_1, NULL,

                      col_1_str_2, NULL, col_1_str_2,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 1,                                      --order_no

                              1,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('юридические лица', '2',                       --code_no

                                              col_1_str_2, col_2_str_2,

                      col_3_str_2, col_4_str_2, col_5_str_2,

                      col_6_str_2, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 2,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('физические лица', '3',                        --code_no

                                             col_1_str_3, col_2_str_3,

                      col_3_str_3, col_4_str_3, col_5_str_3,

                      col_6_str_3, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 3,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '2. Привлечено денег на счета вкладов юридических и физических лиц за отчетный период, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '4',                                           --code_no

                          col_1_str_4, NULL,

                      col_3_str_4, NULL, col_5_str_4,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 4,                                      --order_no

                              1,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('юридические лица', '5',                       --code_no

                                              col_1_str_5, col_2_str_5,

                      col_3_str_5, col_4_str_5, col_5_str_5,

                      col_6_str_5, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 5,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('физические лица', '6',                        --code_no

                                             col_1_str_6, col_2_str_6,

                      col_3_str_6, col_4_str_6, col_5_str_6,

                      col_6_str_6, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 6,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '3. Отозвано денег с текущих счетов вкладов юридических и физических лиц за отчетный период, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '7',                                           --code_no

                          col_1_str_7, NULL,

                      col_3_str_7, NULL, col_5_str_7,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 7,                                      --order_no

                              1,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('юридические лица', '8',                       --code_no

                                              col_1_str_8, col_2_str_8,

                      col_3_str_8, col_4_str_8, col_5_str_8,

                      col_6_str_8, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 8,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('физические лица', '9',                        --code_no

                                             col_1_str_9, col_2_str_9,

                      col_3_str_9, col_4_str_9, col_5_str_9,

                      col_6_str_9, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 9,                                      --order_no

                              0,                                   --format_no

                                month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '4. Остатки денег на текущих счетах вкладов юридических и физических лиц на конец отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '10',                                          --code_no

                           col_1_str_10, NULL,

                      col_3_str_10, NULL, col_5_str_10,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 10,                                     --order_no

                               1,                                  --format_no

                                 month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('юридические лица', '11',                      --code_no

                                               col_1_str_11, col_2_str_11,

                      col_3_str_11, col_4_str_11, col_5_str_11,

                      col_6_str_11, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 11,                                     --order_no

                               0,                                  --format_no

                                 month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('физические лица', '12',                       --code_no

                                              col_1_str_12, col_2_str_12,

                      col_3_str_12, col_4_str_12, col_5_str_12,

                      col_6_str_12, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 12,                                     --order_no

                               0,                                  --format_no

                                 month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('5. Курсовая разница, всего', '13',            --code_no

                                                         col_1_str_13, NULL,

                      col_3_str_13, NULL, col_5_str_13,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 13,                                     --order_no

                               1,                                  --format_no

                                 month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('6. Другие изменения в объеме вкладов юридических и физических лиц, образовавшиеся за отчетный период, всего',

                      '14',                                          --code_no

                           col_1_str_14, NULL,

                      col_3_str_14, NULL, col_5_str_14,

                      NULL, NULL, NULL,

                      NULL, NULL, NULL,

                      NULL, 14,                                     --order_no

                               1,                                  --format_no

                                 month_, year_,

                      1

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '7.  Остатки денег на счетах вкладов юридических и физических лиц на начало отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '15',                                          --code_no

                           col_1_str_15, col_2_str_15,

                      col_3_str_15, col_4_str_15, col_5_str_15,

                      col_6_str_15, col_7_str_15, col_8_str_15,

                      col_9_str_15, col_10_str_15, col_11_str_15,

                      col_12_str_15, 15,                            --order_no

                                        1,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до востребования', '16',                      --code_no

                                               col_1_str_16, col_2_str_16,

                      col_3_str_16, col_4_str_16, col_5_str_16,

                      col_6_str_16, col_7_str_16, col_8_str_16,

                      col_9_str_16, col_10_str_16, col_11_str_16,

                      col_12_str_16, 16,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('условные', '17',                              --code_no

                                       col_1_str_17, col_2_str_17,

                      col_3_str_17, col_4_str_17, col_5_str_17,

                      col_6_str_17, col_7_str_17, col_8_str_17,

                      col_9_str_17, col_10_str_17, col_11_str_17,

                      col_12_str_17, 17,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('срочные, всего' || CHR (13) || CHR (10)

                      || 'в том числе:',

                      '18',                                          --code_no

                           col_1_str_18, col_2_str_18,

                      col_3_str_18, col_4_str_18, col_5_str_18,

                      col_6_str_18, col_7_str_18, col_8_str_18,

                      col_9_str_18, col_10_str_18, col_11_str_18,

                      col_12_str_18, 18,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до 1 месяца', '19',                           --code_no

                                          col_1_str_19, col_2_str_19,

                      col_3_str_19, col_4_str_19, col_5_str_19,

                      col_6_str_19, col_7_str_19, col_8_str_19,

                      col_9_str_19, col_10_str_19, col_11_str_19,

                      col_12_str_19, 19,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 до 3 месяцев', '20',                     --code_no

                                                col_1_str_20, col_2_str_20,

                      col_3_str_20, col_4_str_20, col_5_str_20,

                      col_6_str_20, col_7_str_20, col_8_str_20,

                      col_9_str_20, col_10_str_20, col_11_str_20,

                      col_12_str_20, 20,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('от 3 месяцев до 1 года', '21',                --code_no

                                                     col_1_str_21,

                      col_2_str_21, col_3_str_21, col_4_str_21,

                      col_5_str_21, col_6_str_21, col_7_str_21,

                      col_8_str_21, col_9_str_21, col_10_str_21,

                      col_11_str_21, col_12_str_21, 21,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 года до 5 лет', '22',                    --code_no

                                                 col_1_str_22, col_2_str_22,

                      col_3_str_22, col_4_str_22, col_5_str_22,

                      col_6_str_22, col_7_str_22, col_8_str_22,

                      col_9_str_22, col_10_str_22, col_11_str_22,

                      col_12_str_22, 22,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 5 лет и более', '23',                      --code_no

                                               col_1_str_23, col_2_str_23,

                      col_3_str_23, col_4_str_23, col_5_str_23,

                      col_6_str_23, col_7_str_23, col_8_str_23,

                      col_9_str_23, col_10_str_23, col_11_str_23,

                      col_12_str_23, 23,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '8. Привлечено денег на счета  вкладов юридических и физических лиц за отчетный период, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '24',                                          --code_no

                           col_1_str_24, col_2_str_24,

                      col_3_str_24, col_4_str_24, col_5_str_24,

                      col_6_str_24, col_7_str_24, col_8_str_24,

                      col_9_str_24, col_10_str_24, col_11_str_24,

                      col_12_str_24, 24,                            --order_no

                                        1,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до востребования', '25',                      --code_no

                                               col_1_str_25, col_2_str_25,

                      col_3_str_25, col_4_str_25, col_5_str_25,

                      col_6_str_25, col_7_str_25, col_8_str_25,

                      col_9_str_25, col_10_str_25, col_11_str_25,

                      col_12_str_25, 25,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('условные', '26',                              --code_no

                                       col_1_str_26, col_2_str_26,

                      col_3_str_26, col_4_str_26, col_5_str_26,

                      col_6_str_26, col_7_str_26, col_8_str_26,

                      col_9_str_26, col_10_str_26, col_11_str_26,

                      col_12_str_26, 26,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('срочные, всего:' || CHR (13) || CHR (10)

                      || 'в том числе:',

                      '27',                                          --code_no

                           col_1_str_27, col_2_str_27,

                      col_3_str_27, col_4_str_27, col_5_str_27,

                      col_6_str_27, col_7_str_27, col_8_str_27,

                      col_9_str_27, col_10_str_27, col_11_str_27,

                      col_12_str_27, 27,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до 1 месяца', '28',                           --code_no

                                          col_1_str_28, col_2_str_28,

                      col_3_str_28, col_4_str_28, col_5_str_28,

                      col_6_str_28, col_7_str_28, col_8_str_28,

                      col_9_str_28, col_10_str_28, col_11_str_28,

                      col_12_str_28, 28,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 до 3 месяцев', '29',                     --code_no

                                                col_1_str_29, col_2_str_29,

                      col_3_str_29, col_4_str_29, col_5_str_29,

                      col_6_str_29, col_7_str_29, col_8_str_29,

                      col_9_str_29, col_10_str_29, col_11_str_29,

                      col_12_str_29, 29,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('от 3 месяцев до 1 года', '30',                --code_no

                                                     col_1_str_30,

                      col_2_str_30, col_3_str_30, col_4_str_30,

                      col_5_str_30, col_6_str_30, col_7_str_30,

                      col_8_str_30, col_9_str_30, col_10_str_30,

                      col_11_str_30, col_12_str_30, 30,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 года до 5 лет', '31',                    --code_no

                                                 col_1_str_31, col_2_str_31,

                      col_3_str_31, col_4_str_31, col_5_str_31,

                      col_6_str_31, col_7_str_31, col_8_str_31,

                      col_9_str_31, col_10_str_31, col_11_str_31,

                      col_12_str_31, 31,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 5 лет и более', '32',                      --code_no

                                               col_1_str_32, col_2_str_32,

                      col_3_str_32, col_4_str_32, col_5_str_32,

                      col_6_str_32, col_7_str_32, col_8_str_32,

                      col_9_str_32, col_10_str_32, col_11_str_32,

                      col_12_str_32, 32,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '9. Отозвано денег со счетов вкладов юридических и физических лиц за отчетный период, всего '

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '33',                                          --code_no

                           col_1_str_33, col_2_str_33,

                      col_3_str_33, col_4_str_33, col_5_str_33,

                      col_6_str_33, col_7_str_33, col_8_str_33,

                      col_9_str_33, col_10_str_33, col_11_str_33,

                      col_12_str_33, 33,                            --order_no

                                        1,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до востребования', '34',                      --code_no

                                               col_1_str_34, col_2_str_34,

                      col_3_str_34, col_4_str_34, col_5_str_34,

                      col_6_str_34, col_7_str_34, col_8_str_34,

                      col_9_str_34, col_10_str_34, col_11_str_34,

                      col_12_str_34, 34,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('условные', '35',                              --code_no

                                       col_1_str_35, col_2_str_35,

                      col_3_str_35, col_4_str_35, col_5_str_35,

                      col_6_str_35, col_7_str_35, col_8_str_35,

                      col_9_str_35, col_10_str_35, col_11_str_35,

                      col_12_str_35, 35,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('срочные, всего' || CHR (13) || CHR (10)

                      || 'в том числе:',

                      '36',                                          --code_no

                           col_1_str_36, col_2_str_36,

                      col_3_str_36, col_4_str_36, col_5_str_36,

                      col_6_str_36, col_7_str_36, col_8_str_36,

                      col_9_str_36, col_10_str_36, col_11_str_36,

                      col_12_str_36, 36,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до 1 месяца', '37',                           --code_no

                                          col_1_str_37, col_2_str_37,

                      col_3_str_37, col_4_str_37, col_5_str_37,

                      col_6_str_37, col_7_str_37, col_8_str_37,

                      col_9_str_37, col_10_str_37, col_11_str_37,

                      col_12_str_37, 37,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 до 3 месяцев', '38',                     --code_no

                                                col_1_str_38, col_2_str_38,

                      col_3_str_38, col_4_str_38, col_5_str_38,

                      col_6_str_38, col_7_str_38, col_8_str_38,

                      col_9_str_38, col_10_str_38, col_11_str_38,

                      col_12_str_38, 38,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('от 3 месяцев до 1 года', '39',                --code_no

                                                     col_1_str_39,

                      col_2_str_39, col_3_str_39, col_4_str_39,

                      col_5_str_39, col_6_str_39, col_7_str_39,

                      col_8_str_39, col_9_str_39, col_10_str_39,

                      col_11_str_39, col_12_str_39, 39,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 года до 5 лет', '40',                    --code_no

                                                 col_1_str_40, col_2_str_40,

                      col_3_str_40, col_4_str_40, col_5_str_40,

                      col_6_str_40, col_7_str_40, col_8_str_40,

                      col_9_str_40, col_10_str_40, col_11_str_40,

                      col_12_str_40, 40,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('свыше 5  лет и более', '41',                  --code_no

                                                   col_1_str_41,

                      col_2_str_41, col_3_str_41, col_4_str_41,

                      col_5_str_41, col_6_str_41, col_7_str_41,

                      col_8_str_41, col_9_str_41, col_10_str_41,

                      col_11_str_41, col_12_str_41, 41,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME,

                      string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES (   '10. Остатки денег на счетах вкладов юридических и физических лиц  на конец отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '42',                                          --code_no

                           col_1_str_42, col_2_str_42,

                      col_3_str_42, col_4_str_42, col_5_str_42,

                      col_6_str_42, col_7_str_42, col_8_str_42,

                      col_9_str_42, col_10_str_42, col_11_str_42,

                      col_12_str_42, 42,                            --order_no

                                        1,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до востребования', '43',                      --code_no

                                               col_1_str_43, col_2_str_43,

                      col_3_str_43, col_4_str_43, col_5_str_43,

                      col_6_str_43, col_7_str_43, col_8_str_43,

                      col_9_str_43, col_10_str_43, col_11_str_43,

                      col_12_str_43, 43,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('условные', '44',                              --code_no

                                       col_1_str_44, col_2_str_44,

                      col_3_str_44, col_4_str_44, col_5_str_44,

                      col_6_str_44, col_7_str_44, col_8_str_44,

                      col_9_str_44, col_10_str_44, col_11_str_44,

                      col_12_str_44, 44,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('срочные, всего', '45',                        --code_no

                                             col_1_str_45, col_2_str_45,

                      col_3_str_45, col_4_str_45, col_5_str_45,

                      col_6_str_45, col_7_str_45, col_8_str_45,

                      col_9_str_45, col_10_str_45, col_11_str_45,

                      col_12_str_45, 45,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('до 1 месяца', '46',                           --code_no

                                          col_1_str_46, col_2_str_46,

                      col_3_str_46, col_4_str_46, col_5_str_46,

                      col_6_str_46, col_7_str_46, col_8_str_46,

                      col_9_str_46, col_10_str_46, col_11_str_46,

                      col_12_str_46, 46,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 до 3 месяцев', '47',                     --code_no

                                                col_1_str_47, col_2_str_47,

                      col_3_str_47, col_4_str_47, col_5_str_47,

                      col_6_str_47, col_7_str_47, col_8_str_47,

                      col_9_str_47, col_10_str_47, col_11_str_47,

                      col_12_str_47, 47,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('от 3 месяцев до 1 года', '48',                --code_no

                                                     col_1_str_48,

                      col_2_str_48, col_3_str_48, col_4_str_48,

                      col_5_str_48, col_6_str_48, col_7_str_48,

                      col_8_str_48, col_9_str_48, col_10_str_48,

                      col_11_str_48, col_12_str_48, 48,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount, sm_local_rate,

                      sm_hard_amount, sm_hard_rate, sm_soft_amount,

                      sm_soft_rate, lo_local_amount, lo_local_rate,

                      lo_hard_amount, lo_hard_rate, lo_soft_amount,

                      lo_soft_rate, order_no, format_no, month_no, year_no,

                      report_no

                     )

              VALUES ('от 1 года до 5 лет', '49',                    --code_no

                                                 col_1_str_49, col_2_str_49,

                      col_3_str_49, col_4_str_49, col_5_str_49,

                      col_6_str_49, col_7_str_49, col_8_str_49,

                      col_9_str_49, col_10_str_49, col_11_str_49,

                      col_12_str_49, 49,                            --order_no

                                        0,                         --format_no

                                          month_, year_,

                      2

                     );                                            --report_no



         INSERT INTO CBS_RAPOR_1SB_TEMP

                     (NAME, string_code, sm_local_amount,

                      sm_local_rate, sm_hard_amount, sm_hard_rate,

                      sm_soft_amount, sm_soft_rate, lo_local_amount,

                      lo_local_rate, lo_hard_amount, lo_hard_rate,

                      lo_soft_amount, lo_soft_rate, order_no, format_no,

                      month_no, year_no, report_no

                     )

              VALUES ('свыше 5  лет и более', '50',                  --code_no

                                                   col_1_str_50,

                      col_2_str_50, col_3_str_50, col_4_str_50,

                      col_5_str_50, col_6_str_50, col_7_str_50,

                      col_8_str_50, col_9_str_50, col_10_str_50,

                      col_11_str_50, col_12_str_50, 50,             --order_no

                                                       0,          --format_no

                      month_, year_, 2

                     );                                            --report_no



         COMMIT;

      END IF;

   END cbs_rapor_1sb_par;



   PROCEDURE cbs_rapor_5sb_par (month_ NUMBER, year_ VARCHAR2, recalc_ NUMBER)

   IS

      tmp              NUMBER;

      p_col_1_str_2    NUMBER;

      p_col_2_str_2    NUMBER;

      p_col_3_str_2    NUMBER;

      p_col_1_str_3    NUMBER;

      p_col_2_str_3    NUMBER;

      p_col_3_str_3    NUMBER;

      p_col_1_str_5    NUMBER;

      p_col_2_str_5    NUMBER;

      p_col_3_str_5    NUMBER;

      p_col_1_str_6    NUMBER;

      p_col_2_str_6    NUMBER;

      p_col_3_str_6    NUMBER;

      p_col_1_str_8    NUMBER;

      p_col_2_str_8    NUMBER;

      p_col_3_str_8    NUMBER;

      p_col_1_str_9    NUMBER;

      p_col_2_str_9    NUMBER;

      p_col_3_str_9    NUMBER;

      p_col_1_str_11   NUMBER;

      p_col_2_str_11   NUMBER;

      p_col_3_str_11   NUMBER;

      p_col_1_str_12   NUMBER;

      p_col_2_str_12   NUMBER;

      p_col_3_str_12   NUMBER;

      p_col_1_str_14   NUMBER;

      p_col_2_str_14   NUMBER;

      p_col_3_str_14   NUMBER;

      p_col_1_str_15   NUMBER;

      p_col_2_str_15   NUMBER;

      p_col_3_str_15   NUMBER;

   BEGIN

      SELECT COUNT (*)

        INTO tmp

        FROM CBS_RAPOR_5SB_TEMP

       WHERE month_no = month_ AND year_no = year_;



      IF NOT (tmp > 0 AND recalc_ = 0)

      THEN

         DELETE FROM CBS_RAPOR_5SB_TEMP

               WHERE month_no = month_ AND year_no = year_;



         BEGIN

            SELECT local_amount, hard_amount, soft_amount

              INTO p_col_1_str_2, p_col_2_str_2, p_col_3_str_2

              FROM CBS_RAPOR_5SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 11;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               p_col_1_str_2 := 0;

               p_col_2_str_2 := 0;

               p_col_3_str_2 := 0;

         END;



         BEGIN

            SELECT local_amount, hard_amount, soft_amount

              INTO p_col_1_str_3, p_col_2_str_3, p_col_3_str_3

              FROM CBS_RAPOR_5SB_TEMP

             WHERE year_no =

                      DECODE (month_,

                              1, TO_CHAR (TO_NUMBER (year_) - 1),

                              year_

                             )

               AND month_no = DECODE (month_, 1, 12, month_)

               AND order_no = 12;

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               p_col_1_str_3 := 0;

               p_col_2_str_3 := 0;

               p_col_3_str_3 := 0;

         END;



         /*

         220317

         220318

         222117

         тенге /1000

         credit

         */--p_col_1_str_5 := ?

           --p_col_2_str_5 := ?

           --p_col_3_str_5 := ?



         /*

         220419

         220919

         222119

         тенге /1000

         credit

         */

           --p_col_1_str_6 := ?

           --p_col_2_str_6 := ?

           --p_col_3_str_6 := ?



         /*

         220317

         220318

         222117

         тенге /1000

         debet

         */

           --p_col_1_str_8 := ?

           --p_col_2_str_8 := ?

           --p_col_3_str_8 := ?



         /*

         220419

         220919

         222119

         тенге /1000

         debet

         */

           --p_col_1_str_9 := ?

           --p_col_2_str_9 := ?

           --p_col_3_str_9 := ?

         p_col_1_str_11 := p_col_1_str_2 + p_col_1_str_5 - p_col_1_str_8;

         p_col_2_str_11 := p_col_2_str_2 + p_col_2_str_5 - p_col_2_str_8;

         p_col_3_str_11 := p_col_3_str_2 + p_col_3_str_5 - p_col_3_str_8;

         p_col_1_str_12 := p_col_1_str_3 + p_col_1_str_6 - p_col_1_str_9;

         p_col_2_str_12 := p_col_2_str_3 + p_col_2_str_6 - p_col_2_str_9;

         p_col_3_str_12 := p_col_3_str_3 + p_col_3_str_6 - p_col_3_str_9;

         p_col_1_str_14 :=

              (p_col_1_str_2 + p_col_1_str_5 - p_col_1_str_8) + p_col_1_str_11;

         p_col_2_str_14 :=

              (p_col_2_str_2 + p_col_2_str_5 - p_col_2_str_8) + p_col_2_str_11;

         p_col_3_str_14 :=

              (p_col_3_str_2 + p_col_3_str_5 - p_col_3_str_8) + p_col_3_str_11;

         p_col_1_str_15 :=

              (p_col_1_str_3 + p_col_1_str_6 - p_col_1_str_9) + p_col_1_str_12;

         p_col_2_str_15 :=

              (p_col_2_str_3 + p_col_2_str_6 - p_col_2_str_9) + p_col_2_str_12;

         p_col_3_str_15 :=

              (p_col_3_str_3 + p_col_3_str_6 - p_col_3_str_9) + p_col_3_str_12;



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME,

                      string_code, local_amount, local_rate,

                      hard_amount, hard_rate,

                      soft_amount, soft_rate, order_no, format_no, month_no,

                      year_no

                     )

              VALUES (   '1. Остатки денег на текущих счетах юридических и физических лиц на начало отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '1', p_col_1_str_2 + p_col_1_str_3, NULL,

                      p_col_2_str_2 + p_col_2_str_3, NULL,

                      p_col_3_str_2 + p_col_3_str_3, NULL, 1, 1, month_,

                      year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '2', p_col_1_str_2, NULL,

                      p_col_2_str_2, NULL, p_col_3_str_2, NULL,

                      2, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '3', p_col_1_str_3, NULL,

                      p_col_2_str_3, NULL, p_col_3_str_3, NULL,

                      3, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME,

                      string_code, local_amount, local_rate,

                      hard_amount, hard_rate,

                      soft_amount, soft_rate, order_no, format_no, month_no,

                      year_no

                     )

              VALUES (   '2. Поступило на текущие счета юридических и физических лиц за отчетный период, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '4', p_col_1_str_5 + p_col_1_str_6, NULL,

                      p_col_2_str_5 + p_col_2_str_6, NULL,

                      p_col_3_str_5 + p_col_3_str_6, NULL, 4, 1, month_,

                      year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '5', p_col_1_str_5, NULL,

                      p_col_2_str_5, NULL, p_col_3_str_5, NULL,

                      5, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '6', p_col_1_str_6, NULL,

                      p_col_2_str_6, NULL, p_col_3_str_6, NULL,

                      6, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME,

                      string_code, local_amount, local_rate,

                      hard_amount, hard_rate,

                      soft_amount, soft_rate, order_no, format_no, month_no,

                      year_no

                     )

              VALUES (   '3. Отозвано денег с текущих счетов юридических и физических лиц за отчетный период, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '7', p_col_1_str_8 + p_col_1_str_9, NULL,

                      p_col_2_str_8 + p_col_2_str_9, NULL,

                      p_col_3_str_8 + p_col_3_str_9, NULL, 7, 1, month_,

                      year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '8', p_col_1_str_8, NULL,

                      p_col_2_str_8, NULL, p_col_3_str_8, NULL,

                      8, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '9', p_col_1_str_9, NULL,

                      p_col_2_str_9, NULL, p_col_3_str_9, NULL,

                      9, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME,

                      string_code, local_amount, local_rate,

                      hard_amount, hard_rate,

                      soft_amount, soft_rate, order_no, format_no, month_no,

                      year_no

                     )

              VALUES (   '4. Остатки денег на текущих счетах юридических и физических лиц на конец отчетного периода, всего'

                      || CHR (13)

                      || CHR (10)

                      || 'в том числе:',

                      '10', p_col_1_str_11 + p_col_1_str_12, NULL,

                      p_col_2_str_11 + p_col_2_str_12, NULL,

                      p_col_3_str_11 + p_col_3_str_12, NULL, 10, 1, month_,

                      year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '11', p_col_1_str_11, NULL,

                      p_col_2_str_11, NULL, p_col_3_str_11, NULL,

                      11, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '12', p_col_1_str_12, NULL,

                      p_col_2_str_12, NULL, p_col_3_str_12, NULL,

                      12, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code,

                      local_amount, local_rate,

                      hard_amount, hard_rate,

                      soft_amount, soft_rate, order_no, format_no, month_no,

                      year_no

                     )

              VALUES ('5. Курсовая разница, всего', '13',

                      p_col_1_str_14 + p_col_1_str_15, NULL,

                      p_col_2_str_14 + p_col_2_str_15, NULL,

                      p_col_3_str_14 + p_col_3_str_15, NULL, 13, 1, month_,

                      year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '14', p_col_1_str_14, NULL,

                      p_col_2_str_14, NULL, p_col_3_str_14, NULL,

                      14, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '15', p_col_1_str_15, NULL,

                      p_col_2_str_15, NULL, p_col_3_str_15, NULL,

                      15, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME,

                      string_code, local_amount, local_rate, hard_amount,

                      hard_rate, soft_amount, soft_rate, order_no, format_no,

                      month_no, year_no

                     )

              VALUES ('6. Другие изменения в объеме текущих счетов юридических и физических лиц, образовавшиеся за отчетный период, всего',

                      '16', NULL, NULL, NULL,

                      NULL, NULL, NULL, 16, 1,

                      month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('юридические лица', '17', NULL, NULL,

                      NULL, NULL, NULL, NULL,

                      17, 0, month_, year_

                     );



         INSERT INTO CBS_RAPOR_5SB_TEMP

                     (NAME, string_code, local_amount, local_rate,

                      hard_amount, hard_rate, soft_amount, soft_rate,

                      order_no, format_no, month_no, year_no

                     )

              VALUES ('физические лица', '18', NULL, NULL,

                      NULL, NULL, NULL, NULL,

                      18, 0, month_, year_

                     );



         COMMIT;

      END IF;

   END cbs_rapor_5sb_par;

BEGIN

   NULL;

END Pkg_Report;
/

