create package     pkg_nbkr_xml_report 
is 
    function get_customer_list return varchar2_nt;
    function get_bank_info return varchar2_nt;
    function get_credit_card_list (pd_date in date) return varchar2_nt;
    function get_deposit_list (pd_date in date) return varchar2_nt;
end;
/

