create PACKAGE     PKG_TX1300 IS
/******************************************************************************
   Name       : PKG_TX1300
   Created By : Seval Balci
   Date          : 06.10.03
   Purpose      : Kredi Teklif Giri?i
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);                -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);              -- Islem dogrulandiktan sonra cagrilir
  Procedure    Dogrulama_Iptal_Sonrasi (pn_islem_no number);    -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);                   -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);               -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);                  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);                  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);                  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);                  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);             -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);         -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Guncelleme_Kontrolu(pn_islem_no number, ps_block varchar2, ps_rowid varchar2, 
                                ps_column varchar2, pd_column varchar2, ps_oldvalue in out varchar2);   --g?ncellenen alanlar? bulmak i?in

  Procedure sp_teklifislem_durum_guncelle(pn_islem_no number, ps_yeni_durum_kodu cbs_kredi_teklif.durum_kodu%type);

  FUNCTION Kullanici_Maas_Izleyebilir(pn_musteri number, ps_kullanici varchar2) RETURN VARCHAR2;

  FUNCTION sf_overdraft_urun_adet(pn_islem_no number) RETURN NUMBER;
  FUNCTION sf_teklif_overdraft_urun_mu(pn_urun_grup_no  number) RETURN VARCHAR2;
  FUNCTION sf_kredi_kart_urun_mu(pn_urun_grup_no  number) RETURN VARCHAR2;
  FUNCTION sf_cashcall_is_not_zero(pn_musteri_no number) RETURN BOOLEAN;
  FUNCTION sf_credit_accounts_is_not_zero(pn_musteri_no number) RETURN VARCHAR2;
  FUNCTION sf_kredi_kart_install(pn_urun_grup_no NUMBER) RETURN VARCHAR2 ;--GulkaiyrK cbs293

END;
/

