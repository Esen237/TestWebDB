create PACKAGE BODY     PKG_PAYMENT_CODE
IS
    procedure Prepare_Id (pn_id_out out number)
    IS
        ln_id NUMBER;
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        select PAYMENT_CODE_SEQ.NEXTVAL into ln_id from dual;
        INSERT INTO CBS_PAYMENT_CODE_TEMP_DATA (id, data) VALUES (ln_id, NULL);

        COMMIT;
        pn_id_out := ln_id;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            pn_id_out := -1;
    END;

--------------------------------------------------------------------------------------------
    FUNCTION Load_Data (pn_blob_id NUMBER, ps_mode varchar2, ps_delimiter varchar2 default ';') RETURN BOOLEAN
    IS
        l_data BLOB;
        ln_cnt binary_integer := 0;
        ls_buffer VARCHAR2(32767);
        l_buff_size BINARY_INTEGER := 20000;
        l_start PLS_INTEGER := 1;
        v_array apex_application_global.vc_arr2;
        ln_max_iter number;
    BEGIN
        SELECT data
        INTO l_data
        FROM CBS_PAYMENT_CODE_TEMP_DATA
        WHERE id = pn_blob_id;

        row_array.delete;

        ln_max_iter := CEIL(DBMS_LOB.GETLENGTH(l_data) / l_buff_size);
        FOR i IN 1..ln_max_iter
        LOOP
            ls_buffer := UTL_RAW.CAST_TO_VARCHAR2(DBMS_LOB.SUBSTR(l_data, l_buff_size, l_start));
            l_start := l_start + l_buff_size;

            if i!=1 then 
                ls_buffer := v_array(v_array.last) || ls_buffer;
            end if;

            v_array := apex_util.string_to_table(ls_buffer, chr(10));  

            for j in v_array.first .. v_array.last - 1 
            loop
                if length(trim(v_array(j))) > 8 then 
                    if ln_cnt!=0 then Parse(ltrim(rtrim(v_array(j),chr(13)||chr(10)),chr(13)||chr(10)), ln_cnt, ps_mode, ps_delimiter); end if;
                    ln_cnt := ln_cnt + 1;
                end if;
            end loop;

            if i=ln_max_iter and length(trim(v_array(v_array.last))) > 8 then 
                if ln_cnt!=0 then Parse(ltrim(rtrim(v_array(v_array.last),chr(13)||chr(10)),chr(13)||chr(10)), ln_cnt, ps_mode, ps_delimiter); end if;
                ln_cnt := ln_cnt + 1; 
            end if;
        END LOOP;

        if ps_mode = 'UPDATE' then
            for i in row_array.first .. row_array.last
            loop
                if is_group(i) then row_array(i).type := 'GROUP';
                else row_array(i).type := 'CODE';
                end if;
            end loop;
        end if;

        Clear_Temp_Data(pn_blob_id);
        RETURN true;
    exception
        when others then
            Clear_Temp_Data(pn_blob_id);
            raise_application_error(-20010, 'Error in CSV file at line ' || (ln_cnt+1) || '. Please, check CSV file and try again');
    end;

---------------------------------------------------------------------------------------------------------
    Procedure Parse(ps_line in varchar2, pn_num binary_integer, ps_mode in varchar2, ps_delimiter in varchar2 default ';')
    IS
        v_array apex_application_global.vc_arr2;
    BEGIN
        v_array := apex_util.string_to_table(ps_line, ps_delimiter);

        if ps_mode='UPDATE' then
            row_array(pn_num).kod := trim(v_array(1));
            row_array(pn_num).description_ru := trim(v_array(2));
            row_array(pn_num).description_en := trim(v_array(3));
        end if;

        if ps_mode='REPAIR_CBS' then
            payment_code_array(pn_num).kod := trim(v_array(1));
            payment_code_array(pn_num).ACIKLAMA_ING := trim(v_array(2));
            payment_code_array(pn_num).ACIKLAMA_RUS := trim(v_array(3));
            payment_code_array(pn_num).CLEARING := trim(v_array(4));
            payment_code_array(pn_num).YARATILDIGI_TARIH := sysdate;
            payment_code_array(pn_num).YARATAN_KULLANICI := user;
        end if;

        if ps_mode='REPAIR_IB' then
            payment_code_group_array(pn_num).id := trim(v_array(1));
            payment_code_group_array(pn_num).PARENT_GROUP_ID := trim(v_array(2));
            payment_code_group_array(pn_num).DESCRIPTION_ENG:= trim(v_array(3));
            payment_code_group_array(pn_num).DESCRIPTION_RUS := trim(v_array(4));
            payment_code_group_array(pn_num).CHANNEL_CODE := trim(v_array(5));
            payment_code_group_array(pn_num).TRAN_CODE := trim(v_array(6));
            payment_code_group_array(pn_num).CHILDREN := trim(v_array(7));
            payment_code_group_array(pn_num).STATUS_CD := trim(v_array(8));
            --payment_code_group_array(pn_num).KOD := trim(v_array(9));
            payment_code_group_array(pn_num).CREATED_BY := user;
            payment_code_group_array(pn_num).CREATED_AT := sysdate;
        end if;
    END;

------------------------------------------------------------------------------------------------------------
    function update_cbs_payment_codes return boolean
    is 
        r_payment_code  cbs_payment_code%ROWTYPE;
        f boolean;
        pragma AUTONOMOUS_TRANSACTION;
    begin
        update cbs_payment_code set clearing = 'H';
        for i in row_array.first .. row_array.last
        loop
            if row_array(i).type='CODE' then
                begin
                    select * into r_payment_code 
                    from cbs_payment_code
                    where trim(kod) = trim(row_array(i).kod);
                exception
                when no_data_found then
                    null;
                end;

                if trim(r_payment_code.KOD) = trim(row_array(i).KOD) then
                    /*if upper(trim(r_payment_code.ACIKLAMA_RUS)) = upper(trim(row_array(i).description_ru)) then
                        update cbs_payment_code
                        set CLEARING = 'E'
                        where trim(kod) = trim(r_payment_code.kod);
                    else*/
                        update cbs_payment_code
                        set ACIKLAMA_RUS = row_array(i).description_ru,
                            ACIKLAMA_ING = row_array(i).description_en,
                            CLEARING = 'E'
                        where trim(kod) = trim(r_payment_code.kod);
                    --end if;
                else
                    insert into cbs_payment_code (kod, ACIKLAMA_RUS, ACIKLAMA_ING, CLEARING, YARATAN_KULLANICI, YARATILDIGI_TARIH)
                    values (row_array(i).KOD, row_array(i).description_ru, row_array(i).description_en, 'E', user, sysdate);
                end if;
            end if;
        end loop;
        commit;
        return true;
    exception
        when others then
            rollback;
            return false;
    end;

------------------------------------------------------------------------------------------------------------
    function update_ib_payment_codes return boolean
    is 
        l_configs configs_t;
    begin
        delete from cbs_payment_code_group;

        for i in row_array.first .. row_array.last
        loop
            l_configs := get_configs(i);

            if l_configs.count>0 then
                for j in l_configs.first .. l_configs.last
                loop
                    if row_array(i).type = 'GROUP' then 
                        add_group(get_parent_group_kod(i), i, l_configs(j));
                    else 
                        add_child(get_parent_group_kod(i), row_array(i).kod, l_configs(j));
                    end if;
                end loop;                    
            end if;
        end loop;

        commit;
        return true;
    exception
        when others then 
            rollback;
            return false;
    end;

--------------------------------------------------------------------------------------------------------------------
    function repair_data(ps_source varchar2) return boolean
    is 
        pragma AUTONOMOUS_TRANSACTION;
    begin
        if ps_source = 'CBS' then
            delete from cbs_payment_code;
            for i in payment_code_array.first .. payment_code_array.last
            loop
                insert into cbs_payment_code values payment_code_array(i);
            end loop;
        end if;

        if ps_source = 'IB' then
            delete from cbs_payment_code_group;
            for i in payment_code_group_array.first .. payment_code_group_array.last
            loop
                insert into cbs_payment_code_group values payment_code_group_array(i);
            end loop;
        end if;

        commit;
        return true;
    exception
        when others then
            rollback;
            return false;
    end;

---------------------------------------------------------------------------------------------------------------------
    function get_next_kod(pn_index in binary_integer) return varchar2
    is 
    begin
        if row_array.exists(pn_index+1) then return row_array(pn_index+1).kod;
        else return null;
        end if;
    end;

-------------------------------------------------------------------------------------------------------
    function is_group(pn_index in binary_integer) return boolean
    is 
        ln_current_degree number;
        ln_prev_degree number;
        ln_next_degree number;
    begin
        ln_prev_degree := degree(get_prev_kod(pn_index));
        ln_next_degree := degree(get_next_kod(pn_index));
        ln_current_degree := degree(row_array(pn_index).kod);

        if  ln_prev_degree = ln_current_degree 
            or ln_next_degree = ln_current_degree 
            or (ln_prev_degree < ln_current_degree and ln_next_degree < ln_current_degree)
            or (ln_prev_degree < ln_current_degree and ln_next_degree is null)
        then return false; 
        else return true;
        end if;
    end;

----------------------------------------------------------------------------------------------------------------
    procedure add_group(pn_parent_kod in varchar2, pn_index in binary_integer, p_config config_rt)
    is 
        l_id integer;
        l_parent_id integer;
    begin
        select nvl(max(id),0)+1 into l_id from cbs_payment_code_group;

        begin
            select id into l_parent_id 
            from cbs_payment_code_group 
            where trim(id) = trim(get_parent_group_kod(pn_index))
                    and tran_code=p_config.tran_code
                    and channel_code=p_config.channel_code;
        exception
            when no_data_found then l_parent_id := null;
        end;

        insert into cbs_payment_code_group (
            ID,
            PARENT_GROUP_ID ,
            DESCRIPTION_ENG ,
            DESCRIPTION_RUS ,
            CHANNEL_CODE ,
            TRAN_CODE ,
            CHILDREN ,
            CREATED_BY ,
            CREATED_AT ,
            STATUS_CD--,
            --kod --1812main
        )
        values (
            l_id, 
            l_parent_id,
            row_array(pn_index).description_en,
            row_array(pn_index).description_ru,
            p_config.channel_code,
            p_config.tran_code,
            null,
            user,
            sysdate,
            'sENAB'--,
            --row_array(pn_index).kod--1812main
        );
    end;

--------------------------------------------------------------------------------------------------------------
    procedure add_child(ps_group_kod in varchar2, ps_kod in varchar2, p_config config_rt)
    is 
    begin
        update cbs_payment_code_group
        set children = ltrim(children || ',' || ps_kod, ',')
        where trim(id) = trim(ps_group_kod) --where trim(kod) = trim(ps_group_kod)--1812main
            and CHANNEL_CODE = p_config.channel_code
            and TRAN_CODE = p_config.tran_code;
    end;

----------------------------------------------------------------------------------------------------------------
    function get_prev_kod(pn_index in binary_integer) return varchar2
    is 
    begin
        if row_array.exists(pn_index-1) then return row_array(pn_index-1).kod;
        else return null;
        end if;
    end;

-------------------------------------------------------------------------------------------------------------
    function degree(ps_kod varchar2) return number
    is 
    begin
        return length(rtrim(ps_kod,'0 '));
    end;

-------------------------------------------------------------------------------------------------------
    function get_parent_group_kod(pn_index in binary_integer) return varchar2
    is 
    begin
        if row_array.exists(pn_index-1) then
            for i in reverse row_array.first .. pn_index-1
            loop
                if row_array(i).type = 'GROUP' 
                    and degree(row_array(pn_index).kod) > degree(row_array(i).kod) 
                then
                    return row_array(i).kod;
                end if;
            end loop;
        end if;
        return null;
    end;

------------------------------------------------------------------------------------------------------------
    procedure config_groups
    is 
        pragma AUTONOMOUS_TRANSACTION;

        ls_cib_clearing varchar2(2);
        ls_cib_b20bhvl  varchar2(2);
        ls_rib_clearing varchar2(2);
        ls_rib_b20bhvl  varchar2(2);
    begin
        delete from cbs_payment_code_config;

        for i in row_array.first .. row_array.last
        loop
            if row_array(i).type = 'GROUP' then 
                ls_cib_clearing := 'H';
                ls_cib_b20bhvl  := 'H';
                ls_rib_clearing := 'H';
                ls_rib_b20bhvl  := 'H';

                for c_rec in (select CHANNEL_CODE, TRAN_CODE
                                from cbs_payment_code_group
                                where trim(id) = (row_array(i).kod))--where trim(kod) = (row_array(i).kod))----1812main
                loop
                    if c_rec.CHANNEL_CODE='cDKBCIB' and c_rec.TRAN_CODE='CLEARING' then ls_cib_clearing := 'E'; end if;
                    if c_rec.CHANNEL_CODE='cDKBRIB' and c_rec.TRAN_CODE='CLEARING' then ls_rib_clearing := 'E'; end if;
                    if c_rec.CHANNEL_CODE='cDKBCIB' and c_rec.TRAN_CODE='B2OBHVL'  then ls_cib_b20bhvl  := 'E'; end if;
                    if c_rec.CHANNEL_CODE='cDKBRIB' and c_rec.TRAN_CODE='B2OBHVL'  then ls_rib_b20bhvl  := 'E'; end if;
                end loop;
 
                insert into cbs_payment_code_config (
                    kod,
                    description_ru,
                    CIB_clearing,
                    RIB_clearing,
                    CIB_B2OBHVL,
                    RIB_B2OBHVL
                )
                values (
                    row_array(i).kod,
                    row_array(i).description_ru,
                    ls_cib_clearing,
                    ls_rib_clearing,
                    ls_cib_b20bhvl,
                    ls_rib_b20bhvl
                );
            end if;
        end loop;

        commit;
    exception
        when others then
            rollback;
    end;

----------------------------------------------------------------------------------------------------------
    function get_configs(pn_index in binary_integer) return configs_t
    is 
        l_configs configs_t;
        ln_cnt binary_integer := 0;
        ls_kod varchar2(10);
    begin
        if row_array(pn_index).type='GROUP' then ls_kod := row_array(pn_index).kod;
        else ls_kod := get_parent_group_kod(pn_index);
        end if;

        for c_rec in (
            select 'cDKBCIB' channel_code, 'CLEARING' tran_code from cbs_payment_code_config 
            where trim(kod)=trim(ls_kod) and CIB_CLEARING='E' 
                union
            select 'cDKBRIB' channel_code, 'CLEARING' tran_code from cbs_payment_code_config 
            where trim(kod)=trim(ls_kod) and RIB_CLEARING='E' 
                union
            select 'cDKBCIB' channel_code, 'B2OBHVL' tran_code from cbs_payment_code_config 
            where trim(kod)=trim(ls_kod) and CIB_B2OBHVL='E'
                union
            select 'cDKBRIB' channel_code, 'B2OBHVL' tran_code from cbs_payment_code_config 
            where trim(kod)=trim(ls_kod) and RIB_B2OBHVL='E'
        )  
        loop
            l_configs(ln_cnt).channel_code := c_rec.channel_code;
            l_configs(ln_cnt).tran_code := c_rec.tran_code;
            ln_cnt := ln_cnt + 1;
        end loop;

        return l_configs;
    end;

-----------------------------------------------------------------------------------------------------
    PROCEDURE Clear_Temp_Data (pn_id IN NUMBER)
    is
        pragma AUTONOMOUS_TRANSACTION;
    begin
        delete from CBS_PAYMENT_CODE_TEMP_DATA where id = pn_id;
        commit;
    end;

END;
/

