create PACKAGE BODY PKG_TX1400 IS
p_1400_ISLEM_SUBE number;            --??LEM ?UBE
p_1400_TEMINAT_TUTARI_LC number;     --TEMINAT TUTARI LC
p_1400_TEMINAT_TUTARI_FC number;     --TEMINAT TUTARI FC
p_1400_ACIKLAMA number;              --A?IKLAMA
p_1400_DOVIZ_KODU number;            --DOVIZ_KODU
p_1400_KUR number;              	 --KUR

p_1400_TEMINAT_TUR_IPOTEK number;
p_1400_TEMINAT_TUR_KEFALET number;
p_1400_TEMINAT_TUR_REHIN number;
p_1400_TEMINAT_TUR_TEMLIK number;
p_1400_TEMINAT_TUR_SIGORTA_POL number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
  	update CBS_KREDI_TEMINAT_GIRIS
    	set DURUM='ACIK'
    	where TX_NO=PN_ISLEM_NO;


INSERT INTO CBS_KREDI_TEMINAT_TANIM(
  MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU,
  TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA,
  IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI,
  IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR,
  IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO,
  TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI,
  TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR,
  ALTIN_REHNI_FATURA_NO,ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI,
  ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR,
  ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI,EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI,
  EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI,
  EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI,
  MENKUL_REHNI_BIRIM,MENKUL_REHNI_MIKTARI,MENKUL_REHNI_YERI,
  MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI,
  TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI,
  SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE,
  TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO,
  GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU,
  EMTEA_REHNI_REHIN_TARIHI,TEMLIK_ANLASMA_TARIHI,ILK_TUTAR,KEFALET_VADE_TARIHI,ANLASMA_NO)

(SELECT
  MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU,
  TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA,
  IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI,
  IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR,
  IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL,
  TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI,
  TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI,
  ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO,ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI,
  ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR,
  ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI,EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI,
  EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI,
  EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI,
  MENKUL_REHNI_BIRIM,MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI,
  MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI,
  TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI,
  SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR,
  SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE,
  TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO,
  GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU,
  EMTEA_REHNI_REHIN_TARIHI,TEMLIK_ANLASMA_TARIHI,TUTAR,KEFALET_VADE_TARIHI,ANLASMA_NO

FROM CBS_KREDI_TEMINAT_GIRIS
where TX_NO=pn_islem_no);


exception
	 when others then
   		Raise_application_error(-20100,'2104' || sqlerrm);

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
   ln_musteri_no number;
   ln_teminat_sira_no number;
   ln_count1 number;
   ln_count2 number;
   exception_kayit_var exception;
  Begin

	select MUSTERI_NO, TEMINAT_SIRA_NO
	 into ln_musteri_no, ln_teminat_sira_no
	 from CBS_KREDI_TEMINAT_GIRIS
	 where TX_NO=PN_ISLEM_NO;

	select nvl(count(*),0)
	 into ln_count1
	 from cbs_teminat
	 where MUSTERI_NO=ln_musteri_no
	 and KREDI_TEMINAT_TANIM_SIRA_NO=ln_teminat_sira_no;

	select nvl(count(*),0)
	 into ln_count2
	 from CBS_KREDI_TEMINAT_GIRIS
	 where MUSTERI_NO=ln_musteri_no
	 and TEMINAT_SIRA_NO=ln_teminat_sira_no;


	if ln_count1>0 or ln_count2>1 then
	   -- Terminat dosyas?nda varsa veya kay?t g?ncellenmi?se
	   --(kay?t ?zerine ba?ka i?lem varsa) iptal edeme.
	   raise exception_kayit_var;
	else

	update CBS_KREDI_TEMINAT_GIRIS
     set DURUM='IPTAL'
     where TX_NO=PN_ISLEM_NO;

	update CBS_KREDI_TEMINAT_TANIM
     set DURUM='IPTAL'
     where (musteri_no,Teminat_sira_no) in (select musteri_no,Teminat_sira_no
	 	   								    from CBS_KREDI_TEMINAT_GIRIS
											where TX_NO=PN_ISLEM_NO);
    end if;

  Exception
  when exception_kayit_var then
  	Raise_application_error(-20100,pkg_hata.getUCPOINTER || '5107' || pkg_hata.getUCPOINTER);

  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  	ln_fis_no number;
	ln_fis_no_temp number;

    varchar_list	pkg_muhasebe.varchar_array;
    number_list		pkg_muhasebe.number_array;
    date_list		pkg_muhasebe.date_array;
    boolean_list	pkg_muhasebe.boolean_array;

	cursor cur_KREDI_TEMINAT_GIRIS is
	  select *
      from CBS_KREDI_TEMINAT_GIRIS
	  where tx_no = pn_islem_no;
	  row_KREDI_TEMINAT_GIRIS cur_KREDI_TEMINAT_GIRIS%rowtype;


  Begin
   open cur_KREDI_TEMINAT_GIRIS;
   fetch cur_KREDI_TEMINAT_GIRIS into row_KREDI_TEMINAT_GIRIS;
   close cur_KREDI_TEMINAT_GIRIS;

    boolean_list(p_1400_TEMINAT_TUR_IPOTEK) := FALSE;
    boolean_list(p_1400_TEMINAT_TUR_KEFALET) := FALSE;
    boolean_list(p_1400_TEMINAT_TUR_REHIN) := FALSE;
    boolean_list(p_1400_TEMINAT_TUR_TEMLIK) := FALSE;
    boolean_list(p_1400_TEMINAT_TUR_SIGORTA_POL) := FALSE;


	CASE row_KREDI_TEMINAT_GIRIS.ANA_TEMINAT_KODU

		 WHEN '02' THEN --IPOTEK ISE
		   boolean_list(p_1400_TEMINAT_TUR_IPOTEK) := TRUE;
		 WHEN '03' THEN --KEFALET ISE
		   boolean_list(p_1400_TEMINAT_TUR_KEFALET) := TRUE;
		 WHEN '04' THEN --REHIN ise
           boolean_list(p_1400_TEMINAT_TUR_REHIN) := TRUE;
		 WHEN '05' THEN --TEMLIK ise
           boolean_list(p_1400_TEMINAT_TUR_TEMLIK) := TRUE;
		 WHEN '10' THEN --SIGORTA POLICESI ise
           boolean_list(p_1400_TEMINAT_TUR_SIGORTA_POL) := TRUE;

		 ELSE
		 null;

	END CASE;

    varchar_list(p_1400_ISLEM_SUBE) := row_KREDI_TEMINAT_GIRIS.BOLUM_KODU;
	number_list(p_1400_TEMINAT_TUTARI_FC) := row_KREDI_TEMINAT_GIRIS.TUTAR;
    number_list(p_1400_TEMINAT_TUTARI_LC) := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU,PKG_GENEL.LC_AL,null,row_KREDI_TEMINAT_GIRIS.TUTAR,1,null,null,'N','A');
    number_list(p_1400_KUR) := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU,PKG_GENEL.LC_AL,null,1,1,null,null,'N','A');
    varchar_list(p_1400_ACIKLAMA) := row_KREDI_TEMINAT_GIRIS.ACIKLAMA;
	varchar_list(p_1400_DOVIZ_KODU) := row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU;

	ln_fis_no:=pkg_muhasebe.fis_kes (1400,
   				 	              	 null,
   		 						  	 pn_islem_no,
   								  	 varchar_list ,
   								  	 number_list  ,
   								  	 date_list    ,
   								  	 boolean_list ,
   								  	 pkg_muhasebe.BANKA_TARIHI_BUL,
   								  	 false,
   								  	 0,
   								  	 'Definition of non-cash Collateral' );

	pkg_muhasebe.muhasebelestir(ln_fis_no);

  End;

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number) is
   begin
    null;
  end;

Begin

p_1400_ISLEM_SUBE 		 := pkg_muhasebe.parametre_index_bul('1400_ISLEM_SUBE');
p_1400_TEMINAT_TUTARI_LC:= pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUTARI_LC');
p_1400_TEMINAT_TUTARI_FC:= pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUTARI_FC');
p_1400_ACIKLAMA:= pkg_muhasebe.parametre_index_bul('1400_ACIKLAMA');
p_1400_DOVIZ_KODU:= pkg_muhasebe.parametre_index_bul('1400_DOVIZ_KODU');
p_1400_KUR:= pkg_muhasebe.parametre_index_bul('1400_KUR');

p_1400_TEMINAT_TUR_IPOTEK:= pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUR_IPOTEK');
p_1400_TEMINAT_TUR_KEFALET:=pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUR_KEFALET');
p_1400_TEMINAT_TUR_REHIN := pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUR_REHIN');
p_1400_TEMINAT_TUR_TEMLIK := pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUR_TEMLIK');
p_1400_TEMINAT_TUR_SIGORTA_POL := pkg_muhasebe.parametre_index_bul('1400_TEMINAT_TUR_SIGORTA_POL');


END ;
/

