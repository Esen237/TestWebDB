create PACKAGE     PKG_TX5010 IS

 /******************************************************************************
   Name       : PKG_TX5010
   Created By : Victor K.
   Date          : 08.06.2015
   Purpose      :  Package of the transactional screen 5010 - Income of Customer
******************************************************************************/
TYPE GenCurType IS REF CURSOR;

 

Procedure get_customer_attachments(ln_tx_no number,ln_Cust_no number); -- Get all attachments of the customer
Function  get_loan_type_code( pn_kredi_turu_no  CBS_LOAN_PROG_TYPES.numara%TYPE)
RETURN CBS_LOAN_PROG_TYPES.loan_numara%TYPE; 

Function  get_loan_type_description( pn_kredi_turu_no  CBS_LOAN_PROG_TYPES.loan_numara%TYPE)
RETURN CBS_LOAN_PROG_TYPES.aciklama%TYPE;

FUNCTION Get_Loan_Type_No(pn_loan_acc_no CBS_HESAP_KREDI.HESAP_NO%TYPE) 
RETURN CBS_LOAN_PROG_TYPES.LOAN_NUMARA%TYPE;
     
  Procedure Kontrol_Sonrasi(pn_islem_no number);     -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);        -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);        -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);    -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);        -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);      -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);        -- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);


  
END;

/

