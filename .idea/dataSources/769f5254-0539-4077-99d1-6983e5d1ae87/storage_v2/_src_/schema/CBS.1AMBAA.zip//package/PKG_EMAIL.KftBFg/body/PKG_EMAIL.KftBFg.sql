create PACKAGE BODY     "PKG_EMAIL" IS

  -- Return the next email address in the list of email addresses, separated
  -- by either a "," or a ";".  The format of mailbox may be in one of these:
  --   someone@some-domain
  --   "Someone at some domain" <someone@some-domain>
  --   Someone at some domain <someone@some-domain>
  FUNCTION get_address(addr_list IN OUT VARCHAR2) RETURN VARCHAR2 IS

    addr VARCHAR2(256);
    i    PLS_INTEGER;

    FUNCTION lookup_unquoted_char(str  IN VARCHAR2,
                  chrs IN VARCHAR2) RETURN PLS_INTEGER AS
      c            VARCHAR2(5);
      i            PLS_INTEGER;
      len          PLS_INTEGER;
      inside_quote BOOLEAN;
    BEGIN
       inside_quote := FALSE;
       i := 1;
       len := LENGTH(str);
       WHILE (i <= len) LOOP

     c := SUBSTR(str, i, 1);

     IF (inside_quote) THEN
       IF (c = '"') THEN
         inside_quote := FALSE;
       ELSIF (c = '\') THEN
         i := i + 1; -- Skip the quote character
       END IF;
       GOTO next_char;
     END IF;

     IF (c = '"') THEN
       inside_quote := TRUE;
       GOTO next_char;
     END IF;

     IF (INSTR(chrs, c) >= 1) THEN
        RETURN i;
     END IF;

     <<next_char>>
     i := i + 1;

       END LOOP;

       RETURN 0;

    END;

  BEGIN

    addr_list := LTRIM(addr_list);
    i := lookup_unquoted_char(addr_list, ',;');
    IF (i >= 1) THEN
      addr      := SUBSTR(addr_list, 1, i - 1);
      addr_list := SUBSTR(addr_list, i + 1);
    ELSE
      addr := addr_list;
      addr_list := '';
    END IF;

    i := lookup_unquoted_char(addr, '<');
    IF (i >= 1) THEN
      addr := SUBSTR(addr, i + 1);
      i := INSTR(addr, '>');
      IF (i >= 1) THEN
    addr := SUBSTR(addr, 1, i - 1);
      END IF;
    END IF;

    RETURN addr;
  END;

  -- Write a MIME header
  PROCEDURE write_mime_header(conn  IN OUT NOCOPY utl_smtp.connection,
                  name  IN VARCHAR2,
                  value IN VARCHAR2) IS
  --B-O-M AdiletK CQ867 07.07.2015 Subject in russian language
  ls_charset VARCHAR2(100);
  BEGIN
    BEGIN
        SELECT
            case when regexp_like(value,'[а-яА-Я]') then 'WIN1251'
                   else 'UTF-8'
            end
        INTO ls_charset
        FROM dual;
    EXCEPTION WHEN OTHERS THEN
        ls_charset := 'UTF-8';
    END;
    IF name = 'Subject' and ls_charset = 'WIN1251' THEN
       utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(name || ': ' || '=?windows-1251?B?' || utl_raw.cast_to_varchar2(utl_encode.base64_encode(utl_raw.cast_to_raw(convert(value, 'CL8MSWIN1251')))) || '?=' || utl_tcp.CRLF));
       log_at('check_email_test', 1, value);
    ELSE
       utl_smtp.write_data(conn, name || ': ' || value || utl_tcp.CRLF);
       log_at('check_email_test', 2, value);
    END IF;
  --E-O-M AdiletK CQ867 07.07.2015 Subject in russian language
  END;

  -- Mark a message-part boundary.  Set <last> to TRUE for the last boundary.
  PROCEDURE write_boundary(conn  IN OUT NOCOPY utl_smtp.connection,
               last  IN            BOOLEAN DEFAULT FALSE) AS
  BEGIN
    IF (last) THEN
      utl_smtp.write_data(conn, LAST_BOUNDARY);
    ELSE
      utl_smtp.write_data(conn, FIRST_BOUNDARY);
    END IF;
  END;

  ------------------------------------------------------------------------
  PROCEDURE mail(sender     IN VARCHAR2,
         recipients IN VARCHAR2,
         subject    IN VARCHAR2,
         message    IN VARCHAR2) IS
    conn utl_smtp.connection;
  BEGIN
    conn := begin_mail(sender, recipients, subject);
    write_text(conn, message);
    end_mail(conn);
  END;

  ------------------------------------------------------------------------
  FUNCTION begin_mail(sender     IN VARCHAR2,
              recipients IN VARCHAR2,
              subject    IN VARCHAR2,
              mime_type  IN VARCHAR2    DEFAULT 'text/plain',
              priority   IN PLS_INTEGER DEFAULT NULL)
              RETURN utl_smtp.connection IS
    conn utl_smtp.connection;
  BEGIN
    conn := begin_session;
    begin_mail_in_session(conn, sender, recipients, subject, mime_type,
      priority);
    RETURN conn;
  END;

  ------------------------------------------------------------------------
  PROCEDURE write_text(conn    IN OUT NOCOPY utl_smtp.connection,
               message IN CLOB) IS
l_offset number;
l_ammount number;
  BEGIN
    --utl_smtp.write_data(conn, message);
    utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(to_char(message)));

  Exception
        when others then
        log_at('WRITE TEXT',sqlerrm);
  END;

  PROCEDURE write_text2(conn    IN OUT NOCOPY utl_smtp.connection,
               message IN CLOB) IS
               strTemp VARCHAR2(32767);
               i NUMBER:=-99;
               k NUMBER:=100;
  BEGIN
    -- buraya ?zellikle clob verdim ??nk? text metni ?ok b?y?k olabilir...
    -- varchar2 en fazla 32000 karakter tutabiliyor ancak clob 2 gb ..

     LOOP
       i:=i+k;
       dbms_lob.READ(message,k,i,strTemp);
       --utl_smtp.write_data(conn, strTemp);
       utl_smtp.write_raw_data(conn,utl_raw.cast_to_raw(strTemp));
     EXIT WHEN (dbms_lob.getlength(message) < i + k);
     END LOOP;
  END;
  ------------------------------------------------------------------------
  PROCEDURE write_mb_text(conn    IN OUT NOCOPY utl_smtp.connection,
              message IN            VARCHAR2) IS
  BEGIN
    utl_smtp.write_raw_data(conn, utl_raw.cast_to_raw(message));
  END;

  ------------------------------------------------------------------------
  PROCEDURE write_raw(conn    IN OUT NOCOPY utl_smtp.connection,
              message IN RAW) IS
  BEGIN
    utl_smtp.write_raw_data(conn, message);
  END;

  ------------------------------------------------------------------------
  PROCEDURE attach_text(conn         IN OUT NOCOPY utl_smtp.connection,
            data         IN CLOB,
            mime_type    IN VARCHAR2 DEFAULT 'text/plain',
            inline       IN BOOLEAN  DEFAULT TRUE,
            filename     IN VARCHAR2 DEFAULT NULL,
                last         IN BOOLEAN  DEFAULT FALSE) IS
  BEGIN
    begin_attachment(conn, mime_type, inline, filename);
    --write_text(conn, data);
    write_mb_text(conn, data);
    end_attachment(conn, last);
  Exception
        when others then
        Log_at('Attach_text',sqlerrm);
  END;

  ------------------------------------------------------------------------
  PROCEDURE attach_base64(conn         IN OUT NOCOPY utl_smtp.connection,
              data         IN RAW,
              mime_type    IN VARCHAR2 DEFAULT 'application/octet',
              inline       IN BOOLEAN  DEFAULT TRUE,
              filename     IN VARCHAR2 DEFAULT NULL,
              last         IN BOOLEAN  DEFAULT FALSE) IS
    i   PLS_INTEGER;
    len PLS_INTEGER;
  BEGIN

    begin_attachment(conn, mime_type, inline, filename, 'base64');

    -- Split the Base64-encoded attachment into multiple lines
    i   := 1;
    len := utl_raw.LENGTH(data);
    WHILE (i < len) LOOP
       IF (i + MAX_BASE64_LINE_WIDTH < len) THEN
     utl_smtp.write_raw_data(conn,
        utl_encode.base64_encode(utl_raw.SUBSTR(data, i,
        MAX_BASE64_LINE_WIDTH)));
       ELSE
     utl_smtp.write_raw_data(conn,
       utl_encode.base64_encode(utl_raw.SUBSTR(data, i)));
       END IF;
       utl_smtp.write_data(conn, utl_tcp.CRLF);
       i := i + MAX_BASE64_LINE_WIDTH;
    END LOOP;

    end_attachment(conn, last);

  END;

  ------------------------------------------------------------------------
  PROCEDURE begin_attachment(conn         IN OUT NOCOPY utl_smtp.connection,
                 mime_type    IN VARCHAR2 DEFAULT 'text/plain',
                 inline       IN BOOLEAN  DEFAULT TRUE,
                 filename     IN VARCHAR2 DEFAULT NULL,
                 transfer_enc IN VARCHAR2 DEFAULT NULL) IS
  BEGIN
    write_boundary(conn);
    write_mime_header(conn, 'Content-Type', mime_type);

    IF (filename IS NOT NULL) THEN
       IF (inline) THEN
      write_mime_header(conn, 'Content-Disposition',
        'inline; filename="'||filename||'"');
       ELSE
      write_mime_header(conn, 'Content-Disposition',
        'attachment; filename="'||filename||'"');
       END IF;
    END IF;

    IF (transfer_enc IS NOT NULL) THEN
      write_mime_header(conn, 'Content-Transfer-Encoding', transfer_enc);
    END IF;

    utl_smtp.write_data(conn, utl_tcp.CRLF);
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_attachment(conn IN OUT NOCOPY utl_smtp.connection,
               last IN BOOLEAN DEFAULT FALSE) IS
  BEGIN
    utl_smtp.write_data(conn, utl_tcp.CRLF);
    IF (last) THEN
      write_boundary(conn, last);
    END IF;
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_mail(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    end_mail_in_session(conn);
    end_session(conn);
  END;

  ------------------------------------------------------------------------
  FUNCTION begin_session RETURN utl_smtp.connection IS
    conn utl_smtp.connection;
  BEGIN
    -- open SMTP connection
    conn := utl_smtp.open_connection(smtp_host, smtp_port);
    utl_smtp.helo(conn, smtp_domain);
    RETURN conn;
  END;

  ------------------------------------------------------------------------
  PROCEDURE begin_mail_in_session(conn       IN OUT NOCOPY utl_smtp.connection,
                  sender     IN VARCHAR2,
                  recipients IN VARCHAR2,
                  subject    IN VARCHAR2,
                  mime_type  IN VARCHAR2  DEFAULT 'text/plain',
                  priority   IN PLS_INTEGER DEFAULT NULL) IS
    my_recipients VARCHAR2(32767) := recipients;
    my_sender     VARCHAR2(32767) := sender;
  BEGIN

    -- Specify sender's address (our server allows bogus address
    -- as long as it is a full email address (xxx@yyy.com).
    utl_smtp.mail(conn, get_address(my_sender));

    -- Specify recipient(s) of the email.
    WHILE (my_recipients IS NOT NULL) LOOP
      utl_smtp.rcpt(conn, get_address(my_recipients));
    END LOOP;

    -- Start body of email
    utl_smtp.open_data(conn);

    -- Set "From" MIME header
    write_mime_header(conn, 'From', sender);

    -- Set "To" MIME header
    write_mime_header(conn, 'To', recipients);

    -- Set "Subject" MIME header
    write_mime_header(conn, 'Subject', subject);

    -- Set "Content-Type" MIME header
    write_mime_header(conn, 'Content-Type', mime_type);

    -- Set "X-Mailer" MIME header
    write_mime_header(conn, 'X-Mailer', MAILER_ID);

    -- Set priority:
    --   High      Normal       Low
    --   1     2     3     4     5
    IF (priority IS NOT NULL) THEN
      write_mime_header(conn, 'X-Priority', priority);
    END IF;

    -- Send an empty line to denotes end of MIME headers and
    -- beginning of message body.
    utl_smtp.write_data(conn, utl_tcp.CRLF);

    IF (mime_type LIKE 'multipart/mixed%') THEN
      write_text(conn, 'This is a multi-part message in MIME format.' ||
    utl_tcp.crlf);
    END IF;

  END;

  ------------------------------------------------------------------------
  PROCEDURE end_mail_in_session(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    utl_smtp.close_data(conn);
  END;

  ------------------------------------------------------------------------
  PROCEDURE end_session(conn IN OUT NOCOPY utl_smtp.connection) IS
  BEGIN
    utl_smtp.quit(conn);
  END;

  ------------------------------------------------------------------------
  PROCEDURE SendHTMLEmail(ps_sender IN VARCHAR2, ps_recepient IN VARCHAR2, ps_subject IN VARCHAR2,ps_htmlcontent IN CLOB) IS
    conn utl_smtp.connection;
  BEGIN
    conn := Pkg_Email.begin_mail(
    sender     => ps_sender,
    recipients => ps_recepient,
    subject    => ps_subject,
    mime_type  => 'text/html');

    --Pkg_Email.write_text(conn => conn,message => ps_htmlcontent);
    Pkg_Email.write_text2(conn => conn,message => ps_htmlcontent);

    Pkg_Email.end_mail( conn => conn );
  Exception
      when others then
      log_at('SEND HTML',sqlerrm);
  END;
---------------------------------------------------------------------------
  PROCEDURE SendAttachmentEmail(ps_sender IN VARCHAR2, ps_recepient IN VARCHAR2, ps_subject IN VARCHAR2, ps_content IN VARCHAR2, ps_filename IN VARCHAR2,ps_attachcontent IN VARCHAR2) IS
    conn utl_smtp.connection;
  BEGIN
    conn := Pkg_Email.begin_mail(
    sender     => ps_sender,
    recipients => ps_recepient,
    subject    => ps_subject,
    mime_type  => Pkg_Email.MULTIPART_MIME_TYPE);

    Pkg_Email.attach_text(conn => conn,
                   data => ps_content,
                   mime_type => 'text/plain');

    Pkg_Email.attach_text(conn => conn,
                           data => ps_attachcontent,
                           mime_type => 'text/plain',
                           filename => ps_filename,
                           inline => FALSE,
                           last => TRUE);

    Pkg_Email.end_mail( conn => conn );

  END;

------------------------------------------------------------------------
PROCEDURE SendAutoMessages(ps_sender IN VARCHAR2) IS
  CURSOR cursor_email IS
                 SELECT *
              FROM CBS_EMAIL_MESSAGES
              WHERE STATUS_CD='sWAIT';
              --FOR UPDATE; almasn 24072015 commented because of email notification locks

 CURSOR cursor_attach (pn_messageid IN NUMBER) IS
                 SELECT *
              FROM CBS_EMAIL_ATTACHMENTS
              WHERE MESSAGE_ID=pn_messageid;

 row_email     cursor_email%ROWTYPE;
 row_attach     cursor_attach%ROWTYPE;
 conn utl_smtp.connection;

BEGIN

    OPEN cursor_email;
    FETCH cursor_email INTO row_email;
    WHILE cursor_email%FOUND
    LOOP
    begin

        IF row_email.CONTENT_TYPE='HTML' THEN
           Pkg_Email.SendHTMLEmail(NVL(row_email.SENDER,'info@demirbank.kg'), row_email.RECIPIENT, row_email.SUBJECT,row_email.BODY_CONTENT);
        ELSE--TEXT
            conn := Pkg_Email.begin_mail(
            sender     => NVL(row_email.SENDER,'info@demirbank.kg'),
            recipients => row_email.RECIPIENT,
            subject    => row_email.SUBJECT,
            mime_type  => Pkg_Email.MULTIPART_MIME_TYPE);

            Pkg_Email.attach_text(conn => conn,
                           data => row_email.BODY_CONTENT,
                           mime_type => 'text/plain;charset=utf-8');

            OPEN cursor_attach (row_email.MESSAGE_ID);
            FETCH cursor_attach INTO row_attach;
            IF cursor_attach%FOUND THEN

                Pkg_Email.attach_text(conn => conn,
                                       data => row_attach.FILE_CONTENT,
                                       mime_type => 'text/plain;utf-8',
                                       filename => row_attach.FILENAME,
                                       inline => FALSE,
                                       last => TRUE);

            END IF;
            CLOSE cursor_attach;

            Pkg_Email.end_mail( conn => conn );
        END IF;--HTML

        UPDATE CBS_EMAIL_MESSAGES
        SET STATUS_CD = 'sSEND',SEND_DATE=SYSDATE
        WHERE message_id = row_email.message_id; -- almasn 24072015 commented because of email notification locks
    exception
        when others then
            UPDATE CBS_EMAIL_MESSAGES
            SET STATUS_CD = 'sERROR'
            WHERE message_id = row_email.message_id; --almasn 24072015 commented because of email notification locks
    end;
    FETCH cursor_email INTO row_email;
    END LOOP;
    CLOSE cursor_email;


EXCEPTION
     WHEN OTHERS THEN
          Log_At('SEND EMAIL',SQLERRM,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
 END;
---------------------------------------------------------------------------
PROCEDURE AddToEmailQueue(ps_MESSAGE_CODE  IN VARCHAR2,
                            ps_PRIORITY IN NUMBER,
                          ps_SENDER  IN VARCHAR2,
                          ps_RECIPIENT  IN VARCHAR2,
                          ps_SUBJECT  IN VARCHAR2,
                          ps_BODY_CONTENT IN CLOB,
                          ps_CONTENT_TYPE  IN VARCHAR2 DEFAULT 'TEXT') IS
          PRAGMA AUTONOMOUS_TRANSACTION;
          ln_messageid                    NUMBER;
          ls_sender                        VARCHAR2(50);
BEGIN
    ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

    IF LENGTH(ps_SENDER)<5 THEN
       ls_sender:='info@demirbank.kg';
    ELSE
       ls_sender:=ps_SENDER;
    END IF;

    INSERT INTO CBS_EMAIL_MESSAGES
    (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT,CONTENT_TYPE)
    VALUES
    (ln_messageid, ps_MESSAGE_CODE, ps_PRIORITY, ls_sender, ps_RECIPIENT, ps_SUBJECT, ps_BODY_CONTENT,ps_CONTENT_TYPE);

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
         Log_At('EMAIL',SQLERRM);
END;
------------------------------------------------------------------------
PROCEDURE AddToEmailQueue_Atc(ps_MESSAGE_CODE  IN VARCHAR2,
                                ps_PRIORITY IN NUMBER,
                              ps_SENDER  IN VARCHAR2,
                              ps_RECIPIENT  IN VARCHAR2,
                              ps_SUBJECT  IN VARCHAR2,
                              ps_BODY_CONTENT IN CLOB,
                              ps_FILE_NAME  IN VARCHAR2,
                              ps_ATACHMENT_CONTENT IN CLOB,
                              ps_CONTENT_TYPE  IN VARCHAR2 DEFAULT 'TEXT') IS
          PRAGMA AUTONOMOUS_TRANSACTION;
          ln_messageid                    NUMBER;
          ls_sender                        VARCHAR2(50);
BEGIN
    ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

    IF LENGTH(ps_SENDER)<5 THEN
       ls_sender:='info@demirbank.kg';
    ELSE
       ls_sender:=ps_SENDER;
    END IF;

    INSERT INTO CBS_EMAIL_MESSAGES
    (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT,CONTENT_TYPE)
    VALUES
    (ln_messageid, ps_MESSAGE_CODE, ps_PRIORITY, ls_sender, ps_RECIPIENT, ps_SUBJECT, ps_BODY_CONTENT,ps_CONTENT_TYPE);

    INSERT INTO CBS_EMAIL_ATTACHMENTS
    (MESSAGE_ID, FILENAME, FILE_CONTENT)
    VALUES
    (ln_messageid, ps_FILE_NAME, ps_ATACHMENT_CONTENT);

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
         Log_At('EMAIL',SQLERRM);
END;
------------------------------------------------------------------------
PROCEDURE SendMultipleBlobAttachments (p_to          IN VARCHAR2,
                                                               p_cc        IN VARCHAR2 DEFAULT NULL,
                                                               p_bcc       IN VARCHAR2 DEFAULT NULL,
                                                               p_from        IN VARCHAR2,
                                                               p_subject     IN VARCHAR2,
                                                               p_text_msg    IN VARCHAR2 DEFAULT NULL,
                                                               p_attach_name IN VARCHAR2 DEFAULT NULL,
                                                               p_attach_name2 IN VARCHAR2 DEFAULT NULL,
                                                               p_attach_name3 IN VARCHAR2 DEFAULT NULL,
                                                               p_attach_mime IN VARCHAR2 DEFAULT NULL,
                                                               p_attach_blob IN BLOB DEFAULT NULL,
                                                               p_attach_blob2 IN BLOB DEFAULT NULL,
                                                               p_attach_blob3 IN CLOB DEFAULT NULL)
AS
  l_mail_conn   UTL_SMTP.connection;
  l_boundary    VARCHAR2(50) := '----=*#abc1234321cba#*=';
  l_step        PLS_INTEGER  := 12000; -- make sure you set a multiple of 3 not higher than 24573
  
  TYPE t_split_array IS TABLE OF VARCHAR2(4000);
   
  FUNCTION split_text (p_text       IN  CLOB,
                     p_delimeter  IN  VARCHAR2 DEFAULT ',')
  RETURN t_split_array IS
-- ----------------------------------------------------------------------------
  l_array  t_split_array   := t_split_array();
  l_text   CLOB := p_text;
  l_idx    NUMBER;
BEGIN
  l_array.delete;

  IF l_text IS NULL THEN
    RAISE_APPLICATION_ERROR(-20000, 'P_TEXT parameter cannot be NULL');
  END IF;

  WHILE l_text IS NOT NULL LOOP
    l_idx := INSTR(l_text, p_delimeter);
    l_array.extend;
    IF l_idx > 0 THEN
      l_array(l_array.last) := SUBSTR(l_text, 1, l_idx - 1);
      l_text := SUBSTR(l_text, l_idx + 1);
    ELSE
      l_array(l_array.last) := l_text;
      l_text := NULL;
    END IF;
  END LOOP;
  RETURN l_array;
END split_text;

  PROCEDURE process_recipients(p_mail_conn IN OUT UTL_SMTP.connection,
                               p_list      IN     VARCHAR2)
  AS
   
    l_tab t_split_array;
  BEGIN
    IF TRIM(p_list) IS NOT NULL THEN
      l_tab := split_text(p_list);
      FOR i IN 1 .. l_tab.COUNT LOOP
        UTL_SMTP.rcpt(p_mail_conn, TRIM(l_tab(i)));
      END LOOP;
    END IF;
  END;
BEGIN
  l_mail_conn := UTL_SMTP.open_connection(smtp_host, smtp_port);
  UTL_SMTP.helo(l_mail_conn, smtp_host);
  UTL_SMTP.mail(l_mail_conn, p_from);
  process_recipients(l_mail_conn, p_to);
  process_recipients(l_mail_conn, p_cc);
  process_recipients(l_mail_conn, p_bcc);

  UTL_SMTP.open_data(l_mail_conn);
  
  UTL_SMTP.write_data(l_mail_conn, 'Date: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') || UTL_TCP.crlf);
  UTL_SMTP.write_data(l_mail_conn, 'To: ' || p_to || UTL_TCP.crlf);
  IF TRIM(p_cc) IS NOT NULL THEN
    UTL_SMTP.write_data(l_mail_conn, 'CC: ' || REPLACE(p_cc, ',', ';') || UTL_TCP.crlf);
  END IF;
  IF TRIM(p_bcc) IS NOT NULL THEN
    UTL_SMTP.write_data(l_mail_conn, 'BCC: ' || REPLACE(p_bcc, ',', ';') || UTL_TCP.crlf);
  END IF;
  UTL_SMTP.write_data(l_mail_conn, 'From: ' || p_from || UTL_TCP.crlf);
  UTL_SMTP.write_data(l_mail_conn, 'Subject: ' || p_subject || UTL_TCP.crlf);
  UTL_SMTP.write_data(l_mail_conn, 'Reply-To: ' || p_from || UTL_TCP.crlf);
  UTL_SMTP.write_data(l_mail_conn, 'MIME-Version: 1.0' || UTL_TCP.crlf);
  UTL_SMTP.write_data(l_mail_conn, 'Content-Type: multipart/mixed; boundary="' || l_boundary || '"' || UTL_TCP.crlf || UTL_TCP.crlf);
  
  IF p_text_msg IS NOT NULL THEN
    UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Type: text/plain; charset="iso-8859-1"' || UTL_TCP.crlf || UTL_TCP.crlf);

    UTL_SMTP.write_data(l_mail_conn, p_text_msg);
    UTL_SMTP.write_data(l_mail_conn, UTL_TCP.crlf || UTL_TCP.crlf);
  END IF;

  IF p_attach_name IS NOT NULL THEN
    UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Type: ' || p_attach_mime || '; name="' || p_attach_name || '"' || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Transfer-Encoding: base64' || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Disposition: attachment; filename="' || p_attach_name || '"' || UTL_TCP.crlf || UTL_TCP.crlf);

    FOR i IN 0 .. TRUNC((DBMS_LOB.getlength(p_attach_blob) - 1 )/l_step) LOOP
      UTL_SMTP.write_data(l_mail_conn, UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(DBMS_LOB.substr(p_attach_blob, l_step, i * l_step + 1))));
    END LOOP;

    UTL_SMTP.write_data(l_mail_conn, UTL_TCP.crlf || UTL_TCP.crlf);
    
    ---second_attachment---
    UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Type: ' || p_attach_mime || '; name="' || p_attach_name2 || '"' || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Transfer-Encoding: base64' || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Disposition: attachment; filename="' || p_attach_name2 || '"' || UTL_TCP.crlf || UTL_TCP.crlf);

    FOR i IN 0 .. TRUNC((DBMS_LOB.getlength(p_attach_blob2) - 1 )/l_step) LOOP
      UTL_SMTP.write_data(l_mail_conn, UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(DBMS_LOB.substr(p_attach_blob2, l_step, i * l_step + 1))));
    END LOOP;

    UTL_SMTP.write_data(l_mail_conn, UTL_TCP.crlf || UTL_TCP.crlf);
    ---end second_attachment
    
      ---third_attachment---
    UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Type: ' || 'text/plain' || '; name="' || p_attach_name3 || '"' || UTL_TCP.crlf);
    UTL_SMTP.write_data(l_mail_conn, 'Content-Disposition: attachment; filename="' || p_attach_name3 || '"' || UTL_TCP.crlf || UTL_TCP.crlf);

    FOR i IN 0 .. TRUNC((DBMS_LOB.getlength(p_attach_blob3) - 1 )/l_step) LOOP
       UTL_SMTP.write_data(l_mail_conn, DBMS_LOB.substr(p_attach_blob3, l_step, i * l_step + 1)); -- for clob
    END LOOP;

    UTL_SMTP.write_data(l_mail_conn, UTL_TCP.crlf || UTL_TCP.crlf);
    ---end third_attachment
  END IF;
  
  UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || '--' || UTL_TCP.crlf);
  UTL_SMTP.close_data(l_mail_conn);

  UTL_SMTP.quit(l_mail_conn);
END;
--------------------------------------------------------------------------------------------------------
END;
/

