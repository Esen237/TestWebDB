create PACKAGE pkg_kg_report IS
   FUNCTION getresidentstatus(gl_no VARCHAR2) RETURN VARCHAR2;
   FUNCTION getgl(id NUMBER) RETURN VARCHAR2;
   PROCEDURE rap09_temp_tablo(pd_date1       IN DATE
                             ,pd_date2       IN DATE
                             ,pd_date3       IN DATE
                             ,pd_date4       IN DATE
                             ,pd_date5       IN DATE
                             ,pd_date6       IN DATE
                             ,pd_date7       IN DATE
                             ,pn_usd_fark    IN NUMBER
                             ,pn_eur_fark    IN NUMBER
                             ,pn_jpy_fark    IN NUMBER
                             ,pn_rezerv_rate IN NUMBER
                             ,pn_work_days   IN NUMBER);
   PROCEDURE rap01_temp_tablo(pd_date IN DATE );
   PROCEDURE rap02_temp_tablo(pd_date IN DATE );
END pkg_kg_report;


/

