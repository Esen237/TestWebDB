create PACKAGE     PKG_INT_PAYMENT_TRX IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION PostInstantInstitutionPayment(ps_lang varchar2,
                        ps_iban varchar2,
                        ps_institution_code varchar2,
                        ps_ins_number_extension_code varchar2,
                        ps_institution_account_number varchar2,
                        ps_amount varchar2,
                        ps_description varchar2,
                        ps_channel_code varchar2 default '1',
                        ps_user_code varchar2 default 'CINT_CALLER',  
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType) RETURN varchar2;

FUNCTION PostTaxPayment(ps_lang varchar2,
                        ps_iban varchar2,
                        ps_tax_number varchar2, 
                        ps_type_code varchar2,
                        ps_region_code varchar2,
                        ps_district_code varchar2,
                        ps_sub_district_code varchar2,
                        ps_vehicle_plate varchar2,
                        ps_amount varchar2,
                        ps_channel_code varchar2 default '1',
                        ps_user_code varchar2 default 'CINT_CALLER',  
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType) RETURN varchar2;               
END;
/

