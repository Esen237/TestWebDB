create PACKAGE     Pkg_Limit IS

/******************************************************************************
   Name       : PKG_LIMIT
   Created By : Gulnihal Cengiz
   Date          : 08/10/2003
   Purpose      : Limit Modulu icin gerekli function ve procedure tanimlari
******************************************************************************/
 TYPE Generic_CurType IS REF CURSOR;


 FUNCTION  Musteri_Grubunun_Limiti_Var_Mi(ps_grupkod CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE) RETURN NUMBER ;

 FUNCTION Musteri_Limiti_Var_Mi(pn_musteri_no CBS_GRUP_KODLARI.grup_kodu%TYPE ) RETURN NUMBER ;

 PROCEDURE MusteriGrubu_limit_BilgiAktar(ps_grup_kodu IN CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE,
                                          p_txno IN NUMBER);
 FUNCTION Musteri_Limiti_guncelle_ctrl(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN NUMBER;
 FUNCTION MusteriGrupLimit_guncelle_ctrl(pn_grup_kodu CBS_MUSTERI_GRUP_LIMIT.grup_kodu%TYPE) RETURN NUMBER;
 PROCEDURE Musteri_limit_BilgiAktar(pn_musteri_no IN CBS_MUSTERI_LIMIT.musteri_no%TYPE,
                                          p_txno IN NUMBER) ;
 FUNCTION Musteri_Tipi_Al(pn_musteri CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2 ;
 PROCEDURE Baglantili_musterileri_getir(ps_grup_kodu CBS_GRUP_KODLARI.grup_kodu%TYPE,
                                           pRetCur       IN OUT Pkg_Rapor.Generic_CurType) ;
 PROCEDURE urun_grubuna_bagli_urunleri_al(pn_grup_kodu CBS_URUN_GRUBU.numara%TYPE,
                                           pRetCur       IN OUT Pkg_Rapor.Generic_CurType) ;
 PROCEDURE urun_grubuna_bagli_uruntur_al(pn_grup_kodu CBS_URUN_GRUBU.numara%TYPE,
                                            pRetCur       IN OUT Pkg_Rapor.Generic_CurType) ;


 -- Kredi Limit Kontrol? ile ilgili fonksiyonlar

 PROCEDURE Limit_Kontrol(pn_fis_numara CBS_FIS.numara%TYPE, pb_iptal_flag BOOLEAN DEFAULT FALSE, p_EOD varchar2 DEFAULT 'H' );

 PROCEDURE Risk_Iptal(pn_fis_numara CBS_FIS.numara%TYPE);

 --

 FUNCTION Urun_limit_grubu_adi_al(pn_numara CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2 ;

 FUNCTION  Urun_grubu_no_al RETURN NUMBER;

/* Kredi teklif giris de kullan?lmak uzere haz?rlanm?? proc & fonksiyonlar */
 PROCEDURE Sp_Musteri_Limit_Risk_Al (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                         ps_doviz_kodu  OUT CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                     pn_lc_limit OUT NUMBER,pn_fc_limit OUT NUMBER,
                                     pn_lc_risk OUT NUMBER,pn_fc_risk OUT NUMBER,
                                     pn_nakdi_lc_limit  OUT NUMBER,pn_nakdi_fc_limit  OUT NUMBER,
                                     pn_nakdi_lc_risk   OUT NUMBER, pn_nakdi_fc_risk   OUT NUMBER,
                                     pn_gnakdi_lc_limit OUT NUMBER,pn_gnakdi_fc_limit OUT NUMBER,
                                     pn_gnakdi_lc_risk  OUT NUMBER,pn_gnakdi_fc_risk  OUT NUMBER,
                                     pn_line_amount OUT NUMBER);
 PROCEDURE Sp_Musteri_Urun_Limit_Risk_Al (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
                                              pn_urun_grub_no   CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE,
                                            ps_doviz_kodu     CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                          pn_kredi_teklif_satir_numara CBS_MUSTERI_URUN_LIMIT.kredi_teklif_satir_numara%TYPE,
                                          pn_lc_limit OUT NUMBER,
                                          pn_fc_limit OUT NUMBER,
                                          pn_lc_risk OUT NUMBER,
                                          pn_fc_risk OUT NUMBER);
 PROCEDURE Sp_Musteri_Limit_Guncelle (pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,ps_genel_doviz_kodu  CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                      pn_lc_limit  NUMBER,pn_fc_limit NUMBER, pn_nakdi_lc_limit NUMBER, pn_nakdi_fc_limit NUMBER,
                                      pn_gnakdi_lc_limit  NUMBER,pn_gnakdi_fc_limit NUMBER);
 PROCEDURE Sp_Musteri_Urun_Limit_Guncelle (pn_musteri_no        CBS_MUSTERI.musteri_no%TYPE,
                                               pn_urun_grub_no      CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE,
                                           pn_teklif_satir_no   CBS_MUSTERI_URUN_LIMIT.kredi_teklif_satir_numara%TYPE,
                                             ps_doviz_kodu         CBS_MUSTERI_LIMIT.fc_doviz_kodu%TYPE,
                                           pn_lc_limit             CBS_MUSTERI_URUN_LIMIT.lc_limit%TYPE,
                                           pn_fc_limit          CBS_MUSTERI_URUN_LIMIT.fc_limit%TYPE);

 PROCEDURE sp_musteri_grup_urun_limiti_al( pn_musteri_no     CBS_MUSTERI.musteri_no%TYPE,
                                              ps_FC_DOVIZ_KODU OUT CBS_MUSTERI_GRUP_LIMIT.FC_DOVIZ_KODU%TYPE,
                                            pn_LC_LIMIT      OUT CBS_MUSTERI_GRUP_LIMIT.LC_LIMIT%TYPE ,
                                               pn_FC_LIMIT      OUT CBS_MUSTERI_GRUP_LIMIT.FC_LIMIT%TYPE,
                                               pn_LC_RISK       OUT CBS_MUSTERI_GRUP_LIMIT.lc_risk%TYPE,
                                               pn_FC_RISK          OUT CBS_MUSTERI_GRUP_LIMIT.fc_risk%TYPE);
 FUNCTION sf_musteri_urun_grub_limit_var(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,pn_urun_grub_no CBS_MUSTERI_URUN_LIMIT.urun_grub_no%TYPE) RETURN VARCHAR2;
 FUNCTION sf_musterinin_urun_limiti_var(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2;
FUNCTION  urun_sinif_risklimi(ps_modul_tur_kod IN CBS_URUN_SINIF.modul_tur_kod%TYPE,ps_urun_tur_kod IN CBS_URUN_SINIF.urun_tur_kod%TYPE,ps_kod IN CBS_URUN_SINIF.kod%TYPE) RETURN CBS_URUN_SINIF.RISK_YARAT%TYPE;
PROCEDURE Bagli_musterileri_getir(ps_grup_kodu CBS_BAGLI_MUSTERI_GRUPLARI.grup_kodu%TYPE,
                                      pRetCur       IN OUT Pkg_Rapor.Generic_CurType);
 FUNCTION Baglama_Referansi_Al RETURN VARCHAR2;
 FUNCTION musteri_genel_limit_dvz_al(pn_numara NUMBER) RETURN VARCHAR2;
 FUNCTION musteri_genel_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER;
 FUNCTION musteri_nakdi_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER;
 FUNCTION musteri_gnakdi_fc_limiti_al(pn_numara NUMBER) RETURN NUMBER;
 FUNCTION musteri_urun_limit_dvz_al(pn_numara NUMBER,pn_grup NUMBER) RETURN VARCHAR2;
 FUNCTION musteri_urun_fc_limiti_al(pn_numara NUMBER,pn_grup NUMBER) RETURN NUMBER;
 FUNCTION musteri_urun_lc_limiti_al(pn_numara NUMBER,pn_grup NUMBER) RETURN NUMBER;
END;
/

