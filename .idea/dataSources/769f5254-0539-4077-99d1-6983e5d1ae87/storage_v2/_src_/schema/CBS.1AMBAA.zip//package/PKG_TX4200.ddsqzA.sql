create PACKAGE PKG_TX4200 IS

  /******************************************************************************
   Name       : PKG_TX4200
   Created By : Bilal G?L
   Date	   	  : 22/06/2004
   Purpose	  : AVANS TALEP ??LEM?
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrili

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Function Musteri_Avans_Al(pn_musteri_no number) return varchar2;

END;


/

