create PACKAGE pkg_type IS
 TYPE v_odeme_satir is RECORD (
    v_sira number,
    v_taksit number(24,6),
    v_anapara number(24,6),
    v_faiz number(24,6),
    v_kkdf number(24,6),
    v_bsmv number(24,6),
    v_kalan_anapara number(24,6),
    v_kdv number(24,6),
    v_vade date);
 TYPE v_odeme_plan is VARRAY(240) of v_odeme_satir;

END;


/

