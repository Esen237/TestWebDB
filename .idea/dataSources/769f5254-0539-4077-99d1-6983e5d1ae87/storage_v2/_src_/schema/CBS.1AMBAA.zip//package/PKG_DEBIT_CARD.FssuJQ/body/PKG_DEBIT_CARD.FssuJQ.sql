create PACKAGE BODY     PKG_DEBIT_CARD  IS
  l_uc             VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  l_ara             VARCHAR2(3):=Pkg_Hata.getDELIMITER;    
    
---------------------------------------------------------------------------------------------------
PROCEDURE WS_LOG (p_wscode VARCHAR2,p_url VARCHAR2,p_method VARCHAR2,p_starttime DATE,p_endtime DATE,p_status VARCHAR2, p_errortext VARCHAR2,p_txno NUMBER,pn_app_id number default null  ,ps_result_msg clob default null,ps_Send_message clob default null) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    ln_logid NUMBER;
BEGIN
  ln_logid:=Pkg_Genel.genel_kod_al('CARDWSCALLID');

  INSERT INTO CBS_CARD_WSLOG
  (LOG_ID, WS_CODE, WS_URL, WS_METHOD, WS_STARTTIME, WS_ENDTIME, CALLER_USER,STATUS_CD,ERROR_TXT,TX_NO ,APP_ID ,RESULT,SEND_MESSAGE)
  VALUES
  (ln_logid,p_wscode, p_url,p_method , p_starttime, p_endtime,USER,trim(p_status),p_errortext,p_txno,pn_app_id,ps_result_msg,ps_Send_message );

  COMMIT;
Exception when others then 
    log_At( 'WS_LOG-Error',p_wscode||' '||p_method||' '||p_txno, sqlcode,sqlerrm );
END;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 FUNCTION get_card_Account_type(pn_account_no NUMBER) RETURN VARCHAR2 
 is  
  
 cursor cur_card is 
     select card_account_type
     from   cbs_debit_card_account
     where  account_no = pn_account_no;
  ls_card_account_type   CBS_debit_Card_account.card_account_type%type;
 BEGIN
    for c_card in cur_Card loop
        ls_card_account_type := c_card.card_account_type;
    end loop;

    RETURN ls_card_account_type ;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN return null;       

 END;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION get_card_no(pn_account_no NUMBER) RETURN VARCHAR2 
 is  
  
  cursor cur_card is 
     select card_no
     from   cbs_debit_card_account
     where  account_no = pn_account_no;
  ls_card_no  CBS_debit_Card_account.card_no%type;
 BEGIN
    for c_card in cur_Card loop
        ls_card_no := c_card.card_no;
    end loop;

    RETURN ls_card_no ;

    EXCEPTION
    WHEN NO_DATA_FOUND THEN return null;       

 END;

--------------------------------------------------------------------------------
FUNCTION  card_oper_application_code_Exp( ps_code varchar2 ) RETURN VARCHAR2
  IS
    ls_EXPLANATION      CBS_CARD_OPER_APPLICATION_CODE.EXPLANATION%TYPE;
  BEGIN
    SELECT EXPLANATION
    INTO   ls_EXPLANATION
    FROM   CBS_CARD_OPER_APPLICATION_CODE
    WHERE  APPLICATION_TYPE_CODE =ps_code  ;

    RETURN ls_EXPLANATION ;

  EXCEPTION
      WHEN OTHERS THEN return null;
      
  END;
----------------------------------------------------------------------------------------
FUNCTION  card_oper_statu_code_Exp( ps_code varchar2 ) RETURN VARCHAR2
  IS
    ls_EXPLANATION      CBS_CARD_OPERATION_STATU_CODE.EXPLANATION%TYPE;
  BEGIN
    SELECT EXPLANATION
    INTO   ls_EXPLANATION
    FROM   CBS_CARD_OPERATION_STATU_CODE
    WHERE  STATUS_CODE =ps_code  ;

    RETURN ls_EXPLANATION ;

  EXCEPTION
      WHEN OTHERS THEN return null;
      
  END;
----------------------------------------------------------------------------------------
FUNCTION get_masked_Cardno( ps_cardno  varchar2 ) return varchar2
  IS
    ls_cardno varchar2(20) :=ps_cardno;
    card_length_exception  exception ;
  BEGIN

    if length(ls_cardno)<  16 then 
       ls_cardno := null;
    else
        ls_cardno := substr(ls_cardno,1,6) ||'XXXXXX'||substr(ls_cardno,13) ;
    end if;
    
    return ls_cardno;

  EXCEPTION
     when others then   return null;

  END;
----------------------------------------------------------------------------------------
FUNCTION musteri_aktif_debit_kart_Varmi( pn_musteri_no  number ) return varchar2
is

ln_adet number := 0;
Begin
    select count(*)
    into ln_adet    
    from cbs_debit_Card a
    where customer_no = pn_musteri_No and 
          a.status = 'A' ;
          
   if nvl(ln_adet,0) <> 0  then
        return 'E';
    else
        return 'H';
   end if;  

End;
----------------------------------------------------------------------------------------
FUNCTION hesap_debit_karta_bagli( pn_hesap_no  number ) return varchar2
is

ln_adet number := 0;
Begin
    select count(*)
    into ln_adet    
    from cbs_debit_Card a,cbs_Debit_card_Account b
    where a.customer_no = b.customer_no and
          a.card_no  =b.card_no and
          a.card_id_no = b.card_id_no and
          a.status = 'A' and
          b.account_no = pn_hesap_no ;

   if nvl(ln_adet,0) <> 0  then
        return 'E';
    else
        return 'H';
   end if;  

End;
-----------------------------------------------------------------------------------------
FUNCTION hesap_primary_karta_baglimi( pn_hesap_no  number ) return varchar2
is

ln_adet number := 0;
Begin
    select count(*)
    into ln_adet    
    from cbs_debit_card a,cbs_debit_card_account b
    where a.customer_no = b.customer_no and
          a.card_no  =b.card_no and
          a.card_id_no = b.card_id_no and
          a.status = 'A' and
          b.account_no = pn_hesap_no and
          card_account_type = 'PRIMARY'  
            ;

   if nvl(ln_adet,0) <> 0  then
        return 'E';
    else
        return 'H';
   end if;  

End;
-----------------------------------------------------------------------------------------
FUNCTION hesap_secondary_karta_baglimi( pn_hesap_no  number ) return varchar2
is

ln_adet number := 0;
Begin
    select count(*)
    into ln_adet    
    from cbs_debit_card a,cbs_debit_card_account b
    where a.customer_no = b.customer_no and
          a.card_no  =b.card_no and
          a.card_id_no = b.card_id_no and
          a.status = 'A' and
          b.account_no = pn_hesap_no and
          card_account_type = 'SECONDARY'  
            ;

   if nvl(ln_adet,0) <> 0  then
        return 'E';
    else
        return 'H';
   end if;  

End;
-----------------------------------------------------------------------------------------
Function sf_customer_salary_firm_id(pn_musteri_no number  ) return varchar2
  is
   ln_company_of_the_staff  number;
   ln_firm_id  number;    
   BEGIN
        select company_of_the_staff
        into ln_company_of_the_staff
        from cbs_musteri 
        where musteri_no =pn_musteri_no ;  

     if nvl(ln_company_of_the_staff,0) <> 0 then 
        select max( firm_id)
        into  ln_firm_id
        from   CBS_SALARY_PAYMENT_FIRM_DEF
        where  firm_no =ln_company_of_the_staff ;
     end if;      
       
    return  ln_firm_id;

    exception
      when others then return null;
     end ;
-----------------------------------------------------------------------------------------
Function sf_work_Salary_cust_firm_id(pn_firma_musteri_no number  ) return varchar2
  is
   ln_firm_id  number;    

   BEGIN
    
     select firm_id
     into  ln_firm_id
     from   cbs_salary_payment_firm_def
     where  firm_no =pn_firma_musteri_no ;
       
    return  ln_firm_id;

 Exception
   when others then return null;
     
End;
-----------------------------------------------------------------------------------------
Function sf_work_Salary_cust_BS_compno(pn_firma_musteri_no number  ) return varchar2
  is
   ln_bs_companyno  number;    

   BEGIN
    
     select bs_companyno
     into  ln_bs_companyno
     from   cbs_salary_payment_firm_def
     where  firm_no =pn_firma_musteri_no ;
       
    return  ln_bs_companyno;

 Exception
   when others then return null;
     
End;
-----------------------------------------------------------------------------------------
Function sf_work_Salary_firm_eng_name(pn_firma_musteri_no number  ) return varchar2
  is
   ln_firm_id  number;    
   ls_firma_adi varchar2(100); 
 BEGIN
    
   ln_firm_id:= sf_work_Salary_cust_firm_id(pn_firma_musteri_no ); 
     if nvl(ln_firm_id,0) <> 0 then 
        ls_firma_adi := substr(pkg_musteri.Sf_Musteri_Eng_Adi(pn_firma_musteri_no),1,100);
     end if;

    return ls_firma_adi ;

 Exception
   when others then return null;
     
End;
-----------------------------------------------------------------------------------------
Function sf_work_Salary_firm_name(pn_firma_musteri_no number  ) return varchar2
  is
   ln_firm_id  number;    
   ls_firma_adi varchar2(100); 
 BEGIN
    
   ln_firm_id:= sf_work_Salary_cust_firm_id(pn_firma_musteri_no ); 
     if nvl(ln_firm_id,0) <> 0 then 
        ls_firma_adi := substr(pkg_musteri.Sf_Musteri_Adi(pn_firma_musteri_no),1,100);
     end if;

    return ls_firma_adi ;

 Exception
   when others then return null;
     
End;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
procedure sp_WS_dbInsertUpdateCustomer(pn_app_id number ,
                                           ps_response_code out varchar2 ,        
                                           ps_response_desc out varchar2 ,
                                           ps_newcardno   out   varchar2    ,        
                                           ps_newpanno out varchar2  
)is pragma autonomous_transaction;

cursor cur_app is
 select * from cbs_card_debit_app_islem
 where app_id = pn_app_id;
 
 r_app cur_App%rowtype;

 serviceUrl VARCHAR2(2000);
 soapAction VARCHAR2(2000);
 namespace VARCHAR2(2000);
 methodName VARCHAR2(2000);
 req Pkg_Soap.request;
 resp Pkg_Soap.response;
 result CLOB;--NVARCHAR2(32767);
 referenceId INTEGER;

 l_parser  dbms_xmlparser.Parser;
 l_doc     dbms_xmldom.DOMDocument;
 l_nl      dbms_xmldom.DOMNodeList;
 l_n       dbms_xmldom.DOMNode;

 ld_starttime DATE;
 ld_endtime DATE;

 ls_BS_WS_SERVICE_URL VARCHAR2(200) ;-- := 'http://10.0.0.43/WebService/DBWS.asmx'; test 
 ls_header_method VARCHAR2(256);
 ls_header_user VARCHAR2(256);
 ls_header_pass VARCHAR2(256);
BEGIN
 
 pkg_parametre.deger('BS_WS_SERVICE_URL',ls_BS_WS_SERVICE_URL);
 
for c_app in cur_app loop
    r_app :=c_app;
end loop;

 ld_starttime:=SYSDATE;

 serviceUrl :=ls_BS_WS_SERVICE_URL;
 namespace := 'http://www.banksoft.com.tr';
 methodName := 'dbInsertUpdateCustomer';
 soapAction := namespace || '/DBWS/' || methodName;
 namespace := 'xmlns="' || namespace || '"';

 req := Pkg_Soap.new_request(methodName, namespace);
 pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
 pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
 ls_header_method := 'UserCredentials';
 PKG_SOAP.NEW_HEADER(req, ls_header_method,
 '<userName>' || ls_header_user || '</userName>' ||
 '<password>' || ls_header_pass || '</password>');
 Pkg_Soap.add_parameter(
  req, 'app', NULL,
'<InsertUpdate xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.record_type   || ']]></InsertUpdate>' ||
'<CustomerNumber xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.CustomerNumber   || ']]></CustomerNumber>' ||
'<name xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.name   || ']]></name>' ||
'<middleName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.middleName   || ']]></middleName>' ||
'<surname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.surname   || ']]></surname>' ||
'<title xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.title   || ']]></title>' ||
'<embossName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.embossName   || ']]></embossName>' ||
'<maidenSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.maidenSurname   || ']]></maidenSurname>' ||
'<IDTypeEmployee xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.IDTypeEmployee   || ']]></IDTypeEmployee>' ||
'<BISerial xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.BISerial   || ']]></BISerial>' ||
'<BINumber xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.BINumber   || ']]></BINumber>' ||
'<driverLicense xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.driverLicense   || ']]></driverLicense>' ||
'<passport xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.passport   || ']]></passport>' ||
'<motherMaidenName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.motherMaidenName   || ']]></motherMaidenName>' ||
'<dateOfBirth xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.dateOfBirth   || ']]></dateOfBirth>' ||
'<placeOfBirth xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.placeOfBirth   || ']]></placeOfBirth>' ||
'<sex xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sex   || ']]></sex>' ||
'<maritialStatus xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.maritialStatus   || ']]></maritialStatus>' ||
'<nationalityCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.nationalityCode   || ']]></nationalityCode>' ||
'<nationalityDesc xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.nationalityDesc   || ']]></nationalityDesc>' ||
'<motherName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.motherName   || ']]></motherName>' ||
'<fatherName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fatherName   || ']]></fatherName>' ||
'<branchID xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.branchID   || ']]></branchID>' ||
'<taxNumber xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.taxNumber   || ']]></taxNumber>' ||
'<taxOffice xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.taxOffice   || ']]></taxOffice>' ||
'<workPlace xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workPlace   || ']]></workPlace>' ||
'<position xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.position   || ']]></position>' ||
'<groupCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.groupCode   || ']]></groupCode>' ||
'<subGroupCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.subGroupCode   || ']]></subGroupCode>' ||
'<companyFlag xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.companyFlag   || ']]></companyFlag>' ||
'<companyNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.companyNo   || ']]></companyNo>' ||
'<companyName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.companyName   || ']]></companyName>' ||
'<companyEmbossedName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.companyEmbossedName   || ']]></companyEmbossedName>' ||
'<pinDeliveryType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.pinDeliveryType   || ']]></pinDeliveryType>' ||
'<pinDeliveryAddress xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.pinDeliveryAddress   || ']]></pinDeliveryAddress>' ||
'<cardSendType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.cardSendType   || ']]></cardSendType>' ||
'<cardSendAddress xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.cardSendAddress   || ']]></cardSendAddress>' ||
'<pinDeliveryBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.pinDeliveryBranch   || ']]></pinDeliveryBranch>' ||
'<cardDeliveryBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.cardDeliveryBranch   || ']]></cardDeliveryBranch>' ||
'<homeEMail xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeEMail   || ']]></homeEMail>' ||
'<homeAddress1 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeAddress1   || ']]></homeAddress1>' ||
'<homeAddress2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeAddress2   || ']]></homeAddress2>' ||
'<homeAddress3 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeAddress3   || ']]></homeAddress3>' ||
'<homeCounty xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeCounty   || ']]></homeCounty>' ||
'<homeCityCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeCityCode   || ']]></homeCityCode>' ||
'<homeCity xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeCity   || ']]></homeCity>' ||
'<homePostalCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homePostalCode   || ']]></homePostalCode>' ||
'<homeCountry xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeCountry   || ']]></homeCountry>' ||
'<homePhoneCountryCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homePhoneCountryCode   || ']]></homePhoneCountryCode>' ||    -- AdiletK 13.10.2015 CQ4961         
'<homePhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homePhoneRegionCode   || ']]></homePhoneRegionCode>' ||
'<homePhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homePhone   || ']]></homePhone>' ||
'<homeFaxRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeFaxRegionCode   || ']]></homeFaxRegionCode>' ||
'<homeFax xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.homeFax   || ']]></homeFax>' ||
'<mobilePhoneCountryCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.mobilePhoneCountryCode   || ']]></mobilePhoneCountryCode>' ||   -- AdiletK 13.10.2015 CQ4961        
'<mobilePhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.mobilePhoneRegionCode   || ']]></mobilePhoneRegionCode>' ||
'<mobilePhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.mobilePhone   || ']]></mobilePhone>' ||
'<foreignMobilePhoneCountryCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.foreignMobileCountryCode   || ']]></foreignMobilePhoneCountryCode>' ||  -- AdiletK 13.10.2015 CQ4961      new fields are added    
'<foreignMobilePhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.foreignMobileRegionCode   || ']]></foreignMobilePhoneRegionCode>' ||        -- AdiletK 13.10.2015 CQ4961          
'<foreignMobilePhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.foreignMobilePhone   || ']]></foreignMobilePhone>' ||  
/*'<workAddress1 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workAddress1   || ']]></workAddress1>' ||
'<workAddress2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workAddress2   || ']]></workAddress2>' ||
'<workAddress3 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workAddress3   || ']]></workAddress3>' ||
'<workCounty xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workCounty   || ']]></workCounty>' ||
'<workCityCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workCityCode   || ']]></workCityCode>' ||
'<workCity xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workCity   || ']]></workCity>' ||
'<workPostalCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workPostalCode   || ']]></workPostalCode>' ||
'<workCountry xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workCountry   || ']]></workCountry>' ||
'<workPhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workPhoneRegionCode   || ']]></workPhoneRegionCode>' ||
'<workPhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workPhone   || ']]></workPhone>' ||
'<workPhoneExtension xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workPhoneExtension   || ']]></workPhoneExtension>' ||
'<workFaxRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workFaxRegionCode   || ']]></workFaxRegionCode>' ||
'<workFax xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workFax   || ']]></workFax>' ||*/
'<workEmail xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.workEmail   || ']]></workEmail>' ||
'<requestingUserCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.requestingUserCode   || ']]></requestingUserCode>' ||
'<requestingTerminal xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.requestingTerminal   || ']]></requestingTerminal>' ||
/*'<tempActive xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempActive   || ']]></tempActive>' ||
'<tempType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempType   || ']]></tempType>' ||
'<tempAddress1 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempAddress1   || ']]></tempAddress1>' ||
'<tempAddress2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempAddress2   || ']]></tempAddress2>' ||
'<tempAddress3 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempAddress3   || ']]></tempAddress3>' ||
'<tempCounty xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempCounty   || ']]></tempCounty>' ||
'<tempCityCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempCityCode   || ']]></tempCityCode>' ||
'<tempCity xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempCity   || ']]></tempCity>' ||
'<tempPostalCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempPostalCode   || ']]></tempPostalCode>' ||
'<tempCountry xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempCountry   || ']]></tempCountry>' ||
'<tempPhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempPhoneRegionCode   || ']]></tempPhoneRegionCode>' ||
'<tempPhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempPhone   || ']]></tempPhone>' ||
'<tempPhoneExtension xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempPhoneExtension   || ']]></tempPhoneExtension>' ||
'<tempFaxRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempFaxRegionCode   || ']]></tempFaxRegionCode>' ||
'<tempFax xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempFax   || ']]></tempFax>' ||*/
'<tempEmail xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.tempEmail   || ']]></tempEmail>' ||
'<createCardFlag xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.createCardFlag   || ']]></createCardFlag>' ||
'<BIN xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.BIN   || ']]></BIN>' ||
'<embossPriority xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.embossPriority   || ']]></embossPriority>' ||
'<cardStyle xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.cardStyle   || ']]></cardStyle>' ||
'<DefaultPhoneSelection xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.default_mobile_phone   || ']]></DefaultPhoneSelection>' ||       --CQ5510 MederT 28072016
'<DailyCOTALimit xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.daily_cota_limit   || ']]></DailyCOTALimit>' ||                         --CQ5510 MederT 28072016
'<OfflinePermitFlag xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.offline_permit   || ']]></OfflinePermitFlag>' ||                     --CQ5510 MederT 28072016
'<primaryAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountNo   || ']]></primaryAccountNo>' ||
'<primaryAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountBranch   || ']]></primaryAccountBranch>' ||
'<primaryAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountAlias   || ']]></primaryAccountAlias>' ||
'<primaryAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountCustomerId   || ']]></primaryAccountCustomerId>' ||
'<primaryAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountNameSurname   || ']]></primaryAccountNameSurname>' ||
'<primaryAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountCurrency   || ']]></primaryAccountCurrency>' ||
'<primaryAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.primaryAccountType   || ']]></primaryAccountType>' ||
'<primaryExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.primaryexternalAccNo || ']]></primaryExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<firstAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountNo   || ']]></firstAccountNo>' ||
'<firstAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountBranch   || ']]></firstAccountBranch>' ||
'<firstAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountAlias   || ']]></firstAccountAlias>' ||
'<firstAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountCustomerId   || ']]></firstAccountCustomerId>' ||
'<firstAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountNameSurname   || ']]></firstAccountNameSurname>' ||
'<firstAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountCurrency   || ']]></firstAccountCurrency>' ||
'<firstAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.firstAccountType   || ']]></firstAccountType>' ||
'<firstExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.firstexternalAccNo || ']]></firstExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<secondAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountNo   || ']]></secondAccountNo>' ||
'<secondAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountBranch   || ']]></secondAccountBranch>' ||
'<secondAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountAlias   || ']]></secondAccountAlias>' ||
'<secondAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountCustomerId   || ']]></secondAccountCustomerId>' ||
'<secondAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountNameSurname   || ']]></secondAccountNameSurname>' ||
'<secondAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountCurrency   || ']]></secondAccountCurrency>' ||
'<secondAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.secondAccountType   || ']]></secondAccountType>' ||
'<secondExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.secondexternalAccNo || ']]></secondExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<thirdAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountNo   || ']]></thirdAccountNo>' ||
'<thirdAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountBranch   || ']]></thirdAccountBranch>' ||
'<thirdAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountAlias   || ']]></thirdAccountAlias>' ||
'<thirdAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountCustomerId   || ']]></thirdAccountCustomerId>' ||
'<thirdAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountNameSurname   || ']]></thirdAccountNameSurname>' ||
'<thirdAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountCurrency   || ']]></thirdAccountCurrency>' ||
'<thirdAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.thirdAccountType   || ']]></thirdAccountType>' ||
'<thirdExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.thirdexternalAccNo || ']]></thirdExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<fourthAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountNo   || ']]></fourthAccountNo>' ||
'<fourthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountBranch   || ']]></fourthAccountBranch>' ||
'<fourthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountAlias   || ']]></fourthAccountAlias>' ||
'<fourthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountCustomerId   || ']]></fourthAccountCustomerId>' ||
'<fourthAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountNameSurname   || ']]></fourthAccountNameSurname>' ||
'<fourthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountCurrency   || ']]></fourthAccountCurrency>' ||
'<fourthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fourthAccountType   || ']]></fourthAccountType>' ||
'<fourthExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.fourthexternalAccNo || ']]></fourthExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<fifthAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountNo   || ']]></fifthAccountNo>' ||
'<fifthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountBranch   || ']]></fifthAccountBranch>' ||
'<fifthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountAlias   || ']]></fifthAccountAlias>' ||
'<fifthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountCustomerId   || ']]></fifthAccountCustomerId>' ||
'<fifthAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountNameSurname   || ']]></fifthAccountNameSurname>' ||
'<fifthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountCurrency   || ']]></fifthAccountCurrency>' ||
'<fifthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.fifthAccountType   || ']]></fifthAccountType>' ||
'<fifthExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.fifthexternalAccNo || ']]></fifthExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<sixthAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountNo   || ']]></sixthAccountNo>' ||
'<sixthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountBranch   || ']]></sixthAccountBranch>' ||
'<sixthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountAlias   || ']]></sixthAccountAlias>' ||
'<sixthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountCustomerId   || ']]></sixthAccountCustomerId>' ||
'<sixthAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountNameSurname   || ']]></sixthAccountNameSurname>' ||
'<sixthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountCurrency   || ']]></sixthAccountCurrency>' ||
'<sixthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.sixthAccountType   || ']]></sixthAccountType>' ||
'<sixthExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.sixthexternalAccNo || ']]></sixthExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<seventhAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountNo   || ']]></seventhAccountNo>' ||
'<seventhAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountBranch   || ']]></seventhAccountBranch>' ||
'<seventhAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountAlias   || ']]></seventhAccountAlias>' ||
'<seventhAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountCustomerId   || ']]></seventhAccountCustomerId>' ||
'<seventhAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountNameSurname   || ']]></seventhAccountNameSurname>' ||
'<seventhAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountCurrency   || ']]></seventhAccountCurrency>' ||
'<seventhAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.seventhAccountType   || ']]></seventhAccountType>' ||
'<seventhExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.seventhexternalAccNo || ']]></seventhExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<eightAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountNo   || ']]></eightAccountNo>' ||
'<eightAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountBranch   || ']]></eightAccountBranch>' ||
'<eightAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountAlias   || ']]></eightAccountAlias>' ||
'<eightAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountCustomerId   || ']]></eightAccountCustomerId>' ||
'<eightAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountNameSurname   || ']]></eightAccountNameSurname>' ||
'<eightAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountCurrency   || ']]></eightAccountCurrency>' ||
'<eightAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.eightAccountType   || ']]></eightAccountType>' ||
'<eightExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.eightexternalAccNo || ']]></eightExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<ninthAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountNo   || ']]></ninthAccountNo>' ||
'<ninthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountBranch   || ']]></ninthAccountBranch>' ||
'<ninthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountAlias   || ']]></ninthAccountAlias>' ||
'<ninthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountCustomerId   || ']]></ninthAccountCustomerId>' ||
'<ninthAccountNameSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountNameSurname   || ']]></ninthAccountNameSurname>' ||
'<ninthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountCurrency   || ']]></ninthAccountCurrency>' ||
'<ninthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.ninthAccountType   || ']]></ninthAccountType>' ||
'<ninthExternalAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA[' || r_app.ninthexternalAccNo || ']]></ninthExternalAccountNo>' ||--External account number project NurzalatA 22012018
'<BankCode  xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| '01' ||']]></BankCode >' ||
'<NoName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| r_app.noname ||']]></NoName>'||--aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
'<PinPrintFlag xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerInput"><![CDATA['|| nvl(r_app.pin_print_flag, 'N') ||']]></PinPrintFlag>');--PINPrintFlag project NurzalatA 29122017

resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
 result := resp.doc.getstringval();
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCustomerResult"','');
 l_parser := dbms_xmlparser.newParser;

 dbms_xmlparser.parseclob(l_parser, result);
 l_doc := dbms_xmlparser.getDocument(l_parser);

 l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'dbInsertUpdateCustomerResponse/dbInsertUpdateCustomerResult');

 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
  l_n := dbms_xmldom.item(l_nl, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n,'responseCode/text()',ps_response_Code);
  dbms_xslprocessor.valueOf(l_n,'responseCodeDesc/text()',ps_response_Desc);
  dbms_xslprocessor.valueOf(l_n,'newCardNo/text()',ps_newCardNo);
  dbms_xslprocessor.valueOf(l_n,'newPANNo/text()',ps_newpanno);

    --log_At('sp_WS_dbInsertUpdateCustomer',pn_app_id,'ps_newCardNo',ps_newCardNo);
    --log_At('sp_WS_dbInsertUpdateCustomer',pn_app_id,'ps_newPANNo',ps_newPANNo);
    
 END LOOP;

 ld_endtime:=SYSDATE;

 Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,ps_response_Code,NULL,r_app.tx_no,pn_app_id,result ,REQ.BODY); --SEVALB 14052013 '000' replaced with ps_response_Code
 
 commit;  

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   ps_response_Code:= '999';
   ps_response_Desc := sqlcode||' '||sqlerrm ; 
   Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,'999',sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE,r_app.tx_no,pn_app_id,result,REQ.BODY);
END;
-----------------------------------------------------------------------------------------
 procedure sp_WS_dbLinkAccountsToCard(pn_app_id number ,
                                           ps_response_code out varchar2 ,        
                                           ps_response_desc out varchar2   
)is pragma autonomous_transaction;

cursor cur_app is
 select * from cbs_card_debit_app_islem
 where app_id = pn_app_id;
 
 r_app cur_App%rowtype;

 serviceUrl VARCHAR2(2000);
 soapAction VARCHAR2(2000);
 namespace VARCHAR2(2000);
 methodName VARCHAR2(2000);
 req Pkg_Soap.request;
 resp Pkg_Soap.response;
 result CLOB;--NVARCHAR2(32767);
 referenceId INTEGER;

 l_parser  dbms_xmlparser.Parser;
 l_doc     dbms_xmldom.DOMDocument;
 l_nl      dbms_xmldom.DOMNodeList;
 l_n       dbms_xmldom.DOMNode;

 ld_starttime DATE;
 ld_endtime DATE;

 ls_BS_WS_SERVICE_URL VARCHAR2(200) ;-- := 'http://10.0.0.43/WebService/DBWS.asmx'; test 
 ls_header_method VARCHAR2(256);
 ls_header_user VARCHAR2(256);
 ls_header_pass VARCHAR2(256); 
BEGIN
 
 pkg_parametre.deger('BS_WS_SERVICE_URL',ls_BS_WS_SERVICE_URL);

for c_app in cur_app loop
    r_app :=c_app;
end loop;

 ld_starttime:=SYSDATE;

 serviceUrl :=ls_BS_WS_SERVICE_URL;
 namespace := 'http://www.banksoft.com.tr';
 methodName := 'dbLinkAccountsToCard';
 soapAction := namespace || '/DBWS/' || methodName;
 namespace := 'xmlns="' || namespace || '"';

 req := Pkg_Soap.new_request(methodName, namespace);

 pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
 pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
 ls_header_method := 'UserCredentials';
 PKG_SOAP.NEW_HEADER(req, ls_header_method,
 '<userName>' || ls_header_user || '</userName>' ||
 '<password>' || ls_header_pass || '</password>');

 Pkg_Soap.add_parameter(
  req, 'app', NULL,
'<pseudoPANNo xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.pseudoPANNo || ']]></pseudoPANNo>' ||
'<statusWillBeUpdated xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.statusWillBeUpdated || ']]></statusWillBeUpdated>' ||
'<newCardStatus xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.newCardStatus || ']]></newCardStatus>' ||
'<statusChangeDesc xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.statusChangeDesc || ']]></statusChangeDesc>' ||
'<requestingUserCode xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.requestingUserCode || ']]></requestingUserCode>' ||
'<requestingTerminal xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.requestingTerminal || ']]></requestingTerminal>' ||
'<primaryAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountNo || ']]></primaryAccountNo>' ||
'<primaryAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountBranch || ']]></primaryAccountBranch>' ||
'<primaryAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountAlias || ']]></primaryAccountAlias>' ||
'<primaryAccountCustomerId    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountCustomerId    || ']]></primaryAccountCustomerId>' ||
'<primaryAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountNameSurname    || ']]></primaryAccountNameSurname>' ||
'<primaryAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountCurrency || ']]></primaryAccountCurrency>' ||
'<primaryAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.primaryAccountType || ']]></primaryAccountType>' ||
'<firstAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountNo  || ']]></firstAccountNo>' ||
'<firstAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountBranch || ']]></firstAccountBranch>' ||
'<firstAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountAlias || ']]></firstAccountAlias>' ||
'<firstAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountCustomerId || ']]></firstAccountCustomerId>' ||
'<firstAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountNameSurname    || ']]></firstAccountNameSurname>' ||
'<firstAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountCurrency || ']]></firstAccountCurrency>' ||
'<firstAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.firstAccountType || ']]></firstAccountType>' ||
'<secondAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountNo || ']]></secondAccountNo>' ||
'<secondAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountBranch || ']]></secondAccountBranch>' ||
'<secondAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountAlias || ']]></secondAccountAlias>' ||
'<secondAccountCustomerId    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountCustomerId    || ']]></secondAccountCustomerId>' ||
'<secondAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountNameSurname    || ']]></secondAccountNameSurname>' ||
'<secondAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountCurrency || ']]></secondAccountCurrency>' ||
'<secondAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.secondAccountType || ']]></secondAccountType>' ||
'<thirdAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountNo  || ']]></thirdAccountNo>' ||
'<thirdAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountBranch || ']]></thirdAccountBranch>' ||
'<thirdAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountAlias || ']]></thirdAccountAlias>' ||
'<thirdAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountCustomerId || ']]></thirdAccountCustomerId>' ||
'<thirdAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountNameSurname    || ']]></thirdAccountNameSurname>' ||
'<thirdAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountCurrency || ']]></thirdAccountCurrency>' ||
'<thirdAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.thirdAccountType || ']]></thirdAccountType>' ||
'<fourthAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountNo || ']]></fourthAccountNo>' ||
'<fourthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountBranch || ']]></fourthAccountBranch>' ||
'<fourthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountAlias || ']]></fourthAccountAlias>' ||
'<fourthAccountCustomerId    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountCustomerId    || ']]></fourthAccountCustomerId>' ||
'<fourthAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountNameSurname    || ']]></fourthAccountNameSurname>' ||
'<fourthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountCurrency || ']]></fourthAccountCurrency>' ||
'<fourthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fourthAccountType || ']]></fourthAccountType>' ||
'<fifthAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountNo  || ']]></fifthAccountNo>' ||
'<fifthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountBranch || ']]></fifthAccountBranch>' ||
'<fifthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountAlias || ']]></fifthAccountAlias>' ||
'<fifthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountCustomerId || ']]></fifthAccountCustomerId>' ||
'<fifthAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountNameSurname    || ']]></fifthAccountNameSurname>' ||
'<fifthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountCurrency || ']]></fifthAccountCurrency>' ||
'<fifthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.fifthAccountType || ']]></fifthAccountType>' ||
'<sixthAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountNo  || ']]></sixthAccountNo>' ||
'<sixthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountBranch || ']]></sixthAccountBranch>' ||
'<sixthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountAlias || ']]></sixthAccountAlias>' ||
'<sixthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountCustomerId || ']]></sixthAccountCustomerId>' ||
'<sixthAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountNameSurname    || ']]></sixthAccountNameSurname>' ||
'<sixthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountCurrency || ']]></sixthAccountCurrency>' ||
'<sixthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.sixthAccountType || ']]></sixthAccountType>' ||
'<seventhAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountNo || ']]></seventhAccountNo>' ||
'<seventhAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountBranch || ']]></seventhAccountBranch>' ||
'<seventhAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountAlias || ']]></seventhAccountAlias>' ||
'<seventhAccountCustomerId    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountCustomerId    || ']]></seventhAccountCustomerId>' ||
'<seventhAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountNameSurname    || ']]></seventhAccountNameSurname>' ||
'<seventhAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountCurrency || ']]></seventhAccountCurrency>' ||
'<seventhAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.seventhAccountType || ']]></seventhAccountType>' ||
'<eightAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountNo  || ']]></eightAccountNo>' ||
'<eightAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountBranch || ']]></eightAccountBranch>' ||
'<eightAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountAlias || ']]></eightAccountAlias>' ||
'<eightAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountCustomerId || ']]></eightAccountCustomerId>' ||
'<eightAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountNameSurname    || ']]></eightAccountNameSurname>' ||
'<eightAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountCurrency || ']]></eightAccountCurrency>' ||
'<eightAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.eightAccountType || ']]></eightAccountType>' ||
'<ninthAccountNo  xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountNo  || ']]></ninthAccountNo>' ||
'<ninthAccountBranch xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountBranch || ']]></ninthAccountBranch>' ||
'<ninthAccountAlias xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountAlias || ']]></ninthAccountAlias>' ||
'<ninthAccountCustomerId xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountCustomerId || ']]></ninthAccountCustomerId>' ||
'<ninthAccountNameSurname    xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountNameSurname    || ']]></ninthAccountNameSurname>' ||
'<ninthAccountCurrency xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountCurrency || ']]></ninthAccountCurrency>' ||
'<ninthAccountType xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardInput"><![CDATA['|| r_app.ninthAccountType || ']]></ninthAccountType>' );

 resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
 result := resp.doc.getstringval();

 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/DBWS/dbLinkAccountsToCardResult"','');
 l_parser := dbms_xmlparser.newParser;

 dbms_xmlparser.parseclob(l_parser, result);
 l_doc := dbms_xmlparser.getDocument(l_parser);

 l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'dbLinkAccountsToCardResponse/dbLinkAccountsToCardResult');

 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
  l_n := dbms_xmldom.item(l_nl, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n,'responseCode/text()',ps_response_Code);
  dbms_xslprocessor.valueOf(l_n,'responseCodeDesc/text()',ps_response_Desc);


 END LOOP;

 ld_endtime:=SYSDATE;

 Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,ps_response_Code,NULL,r_app.tx_no,pn_app_id,result,REQ.BODY); --SEVALB 14052013 '000' replaced with ps_response_Code

 commit;  

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   ps_response_Code:= '999';
   ps_response_Desc := sqlcode||' '||sqlerrm ; 
   Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,'999',sqlcode||' '||sqlerrm,r_app.tx_no,pn_app_id,result,REQ.BODY);
END;
--------------------------------------------------------
procedure sp_upd_debit_card_app_islem( ps_debit_option varchar2,
                                       pn_app_id number ,
                                       ps_response_code  varchar2 ,        
                                       ps_response_desc  varchar2,
                                       ps_newcardno   varchar2 default null,
                                       ps_newpanno varchar2    default null    
                
)is pragma autonomous_transaction;
begin
   if  ps_debit_option in('NEW CARD', 'NEW CARD WITH PIN') then --CQDB5981 PINPrintFlag project NurzalatA added 'NEW CARD WITH PIN'
    update cbs_card_debit_app_islem
    set response_code = ps_response_code,
        response_desc = ps_response_desc,
        response_date  =sysdate ,
        newcardno = trim(ps_newcardno),
        newpanno = trim(ps_newpanno),
        card_No = trim(ps_newcardno),
        card_id_no =trim(ps_newpanno)
    where app_id = pn_app_id;
   else
        update cbs_card_debit_app_islem
        set response_code = ps_response_code,
            response_desc = ps_response_desc,
            response_date  =sysdate       
        where app_id = pn_app_id;
   end if;
    commit;
exception
 when others then
   rollback;
   log_at('SP_UPD_DEBIT_CARD_APP_ISLEM-ERROR',pn_app_id, sqlcode||' '||sqlerrm );
end;
--------------------------------------------------------
procedure sp_ins_debit_Card_app_islem 
 (  pn_app_id                              number            ,
    pn_tx_no                               number    default    null    ,
    ps_record_type                         varchar2,
    pn_musteri_no                          number,
    pn_multiple_tx_internal_no             number      default    null    ,
    ps_card_no                             varchar2    default    null    ,
    pn_card_id_no                          varchar2    default    null    ,
    ps_debit_option                        varchar2    default    null    ,
    pn_ref_tx_no                           number      default    null    ,
    pn_tran_code                           number      default    null    ,
    ps_response_code                       varchar2    default    null    ,
    ps_response_desc                       varchar2    default    null    ,
    pd_response_date                       varchar2    default    null    ,
    ps_newcardno                           varchar2    default    null    ,
    ps_newpanno                            varchar2    default    null    ,
    p_CustomerNumber                       varchar2    default    null    ,
    p_name                                 varchar2    default    null    ,
    p_middleName                           varchar2    default    null    ,
    p_surname                              varchar2    default    null    ,
    p_title                                varchar2    default    null    ,
    p_embossName                           varchar2    default    null    ,
    p_maidenSurname                        varchar2    default    null    ,
    p_IDTypeEmployee                       varchar2    default    null    ,
    p_BISerial                             varchar2    default    null    ,
    p_BINumber                             varchar2    default    null    ,
    p_driverLicense                        varchar2    default    null    ,
    p_passport                             varchar2    default    null    ,
    p_motherMaidenName                     varchar2    default    null    ,
    p_dateOfBirth                          varchar2    default    null    ,
    p_placeOfBirth                         varchar2    default    null    ,
    p_sex                                  varchar2    default    null    ,
    p_maritialStatus                       varchar2    default    null    ,
    p_nationalityCode                      varchar2    default    null    ,
    p_nationalityDesc                      varchar2    default    null    ,
    p_motherName                           varchar2    default    null    ,
    p_fatherName                           varchar2    default    null    ,
    p_branchID                             varchar2    default    null    ,
    p_taxNumber                            varchar2    default    null    ,
    p_taxOffice                            varchar2    default    null    ,
    p_workPlace                            varchar2    default    null    ,
    p_position                             varchar2    default    null    ,
    p_groupCode                            varchar2    default    null    ,
    p_subGroupCode                         varchar2    default    null    ,
    p_companyFlag                          varchar2    default    null    ,
    p_companyNo                            varchar2    default    null    ,
    p_companyName                          varchar2    default    null    ,
    p_companyEmbossedName                  varchar2    default    null    ,
    p_pinDeliveryType                      varchar2    default    null    ,
    p_pinDeliveryAddress                   varchar2    default    null    ,
    p_cardSendType                         varchar2    default    null    ,
    p_cardSendAddress                      varchar2    default    null    ,
    p_pinDeliveryBranch                    varchar2    default    null    ,
    p_cardDeliveryBranch                   varchar2    default    null    ,
    p_homeEMail                            varchar2    default    null    ,
    p_homeAddress1                         varchar2    default    null    ,
    p_homeAddress2                         varchar2    default    null    ,
    p_homeAddress3                         varchar2    default    null    ,
    p_homeCounty                           varchar2    default    null    ,
    p_homeCityCode                         varchar2    default    null    ,
    p_homeCity                             varchar2    default    null    ,
    p_homePostalCode                       varchar2    default    null    ,
    p_homeCountry                          varchar2    default    null    ,
    p_homePhoneCountryCode                  varchar2    default    null    , -- AdiletK 13.10.2015 CQ4961  
    p_homePhoneRegionCode                  varchar2    default    null    ,
    p_homePhone                            varchar2    default    null    ,
    p_homeFaxRegionCode                    varchar2    default    null    ,
    p_homeFax                              varchar2    default    null    ,
    p_mobilePhoneCountryCode                varchar2    default    null    , -- AdiletK 13.10.2015 CQ4961
    p_mobilePhoneRegionCode                varchar2    default    null    ,
    p_mobilePhone                          varchar2    default    null    ,
    p_foreignMobileCountryCode varchar2 default null      , -- AdiletK 13.10.2015 CQ4961 adding card style field  and others           
    p_foreignMobileRegionCode varchar2 default null      ,  -- AdiletK 13.10.2015 CQ4961             
    p_foreignMobilePhone                  varchar2 default null      ,  -- AdiletK 13.10.2015 CQ4961 
    p_workAddress1                         varchar2    default    null    ,
    p_workAddress2                         varchar2    default    null    ,
    p_workAddress3                         varchar2    default    null    ,
    p_workCounty                           varchar2    default    null    ,
    p_workCityCode                         varchar2    default    null    ,
    p_workCity                             varchar2    default    null    ,
    p_workPostalCode                       varchar2    default    null    ,
    p_workCountry                          varchar2    default    null    ,
    p_workPhoneRegionCode                  varchar2    default    null    ,
    p_workPhone                            varchar2    default    null    ,
    p_workPhoneExtension                   varchar2    default    null    ,
    p_workFaxRegionCode                    varchar2    default    null    ,
    p_workFax                              varchar2    default    null    ,
    p_workEmail                            varchar2    default    null    ,
    p_requestingUserCode                   varchar2    default    null    ,
    p_requestingTerminal                   varchar2    default    null    ,
    p_tempActive                           varchar2    default    null    ,
    p_tempType                             varchar2    default    null    ,
    p_tempAddress1                         varchar2    default    null    ,
    p_tempAddress2                         varchar2    default    null    ,
    p_tempAddress3                         varchar2    default    null    ,
    p_tempCounty                           varchar2    default    null    ,
    p_tempCityCode                         varchar2    default    null    ,
    p_tempCity                             varchar2    default    null    ,
    p_tempPostalCode                       varchar2    default    null    ,
    p_tempCountry                          varchar2    default    null    ,
    p_tempPhoneRegionCode                  varchar2    default    null    ,
    p_tempPhone                            varchar2    default    null    ,
    p_tempPhoneExtension                   varchar2    default    null    ,
    p_tempFaxRegionCode                    varchar2    default    null    ,
    p_tempFax                              varchar2    default    null    ,
    p_tempEmail                            varchar2    default    null    ,
    p_createCardFlag                       varchar2    default    null    ,
    p_BIN                                  varchar2    default    null    ,
    p_embossPriority                       varchar2    default    null    ,
    p_cardStyle                            varchar2    default    null    ,
    p_primaryAccountNo                     varchar2    default    null    ,
    p_primaryAccountBranch                 varchar2    default    null    ,
    p_primaryAccountAlias                  varchar2    default    null    ,
    p_primaryAccountCustomerId             varchar2    default    null    ,
    p_primaryAccountNameSurname            varchar2    default    null    ,
    p_primaryAccountCurrency               varchar2    default    null    ,
    p_primaryAccountType                   varchar2    default    null    ,
    p_firstAccountNo                       varchar2    default    null    ,
    p_firstAccountBranch                   varchar2    default    null    ,
    p_firstAccountAlias                    varchar2    default    null    ,
    p_firstAccountCustomerId               varchar2    default    null    ,
    p_firstAccountNameSurname              varchar2    default    null    ,
    p_firstAccountCurrency                 varchar2    default    null    ,
    p_firstAccountType                     varchar2    default    null    ,
    p_secondAccountNo                      varchar2    default    null    ,
    p_secondAccountBranch                  varchar2    default    null    ,
    p_secondAccountAlias                   varchar2    default    null    ,
    p_secondAccountCustomerId              varchar2    default    null    ,
    p_secondAccountNameSurname             varchar2    default    null    ,
    p_secondAccountCurrency                varchar2    default    null    ,
    p_secondAccountType                    varchar2    default    null    ,
    p_thirdAccountNo                       varchar2    default    null    ,
    p_thirdAccountBranch                   varchar2    default    null    ,
    p_thirdAccountAlias                    varchar2    default    null    ,
    p_thirdAccountCustomerId               varchar2    default    null    ,
    p_thirdAccountNameSurname              varchar2    default    null    ,
    p_thirdAccountCurrency                 varchar2    default    null    ,
    p_thirdAccountType                     varchar2    default    null    ,
    p_fourthAccountNo                      varchar2    default    null    ,
    p_fourthAccountBranch                  varchar2    default    null    ,
    p_fourthAccountAlias                   varchar2    default    null    ,
    p_fourthAccountCustomerId              varchar2    default    null    ,
    p_fourthAccountNameSurname             varchar2    default    null    ,
    p_fourthAccountCurrency                varchar2    default    null    ,
    p_fourthAccountType                    varchar2    default    null    ,
    p_fifthAccountNo                       varchar2    default    null    ,
    p_fifthAccountBranch                   varchar2    default    null    ,
    p_fifthAccountAlias                    varchar2    default    null    ,
    p_fifthAccountCustomerId               varchar2    default    null    ,
    p_fifthAccountNameSurname              varchar2    default    null    ,
    p_fifthAccountCurrency                 varchar2    default    null    ,
    p_fifthAccountType                     varchar2    default    null    ,
    p_sixthAccountNo                       varchar2    default    null    ,
    p_sixthAccountBranch                   varchar2    default    null    ,
    p_sixthAccountAlias                    varchar2    default    null    ,
    p_sixthAccountCustomerId               varchar2    default    null    ,
    p_sixthAccountNameSurname              varchar2    default    null    ,
    p_sixthAccountCurrency                 varchar2    default    null    ,
    p_sixthAccountType                     varchar2    default    null    ,
    p_seventhAccountNo                     varchar2    default    null    ,
    p_seventhAccountBranch                 varchar2    default    null    ,
    p_seventhAccountAlias                  varchar2    default    null    ,
    p_seventhAccountCustomerId             varchar2    default    null    ,
    p_seventhAccountNameSurname            varchar2    default    null    ,
    p_seventhAccountCurrency               varchar2    default    null    ,
    p_seventhAccountType                   varchar2    default    null    ,
    p_eightAccountNo                       varchar2    default    null    ,
    p_eightAccountBranch                   varchar2    default    null    ,
    p_eightAccountAlias                    varchar2    default    null    ,
    p_eightAccountCustomerId               varchar2    default    null    ,
    p_eightAccountNameSurname              varchar2    default    null    ,
    p_eightAccountCurrency                 varchar2    default    null    ,
    p_eightAccountType                     varchar2    default    null    ,
    p_ninthAccountNo                       varchar2    default    null    ,
    p_ninthAccountBranch                   varchar2    default    null    ,
    p_ninthAccountAlias                    varchar2    default    null    ,
    p_ninthAccountCustomerId               varchar2    default    null    ,
    p_ninthAccountNameSurname              varchar2    default    null    ,
    p_ninthAccountCurrency                 varchar2    default    null    ,
    p_ninthAccountType                     varchar2    default    null    ,
    p_pseudopanno                          varchar2    default    null    ,
    p_statuswillbeupdated                  varchar2    default    null    ,
    p_newcardstatus                        varchar2    default    null    ,
    p_statuschangedesc                     varchar2    default    null  
    , p_default_mobile_phone               varchar2    default    '01'      --CQ5510 MederT 28072016
    , p_daily_cota_limit                   varchar2    default    0      --CQ5510 MederT 28072016
    , p_offline_permit                     varchar2    default    'N'      --CQ5510 MederT 28072016
    , p_noname                             varchar2    default    'N'   --aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
    , p_pin_print_flag                     varchar2--PINPrintFlag project NurzalatA 29122017
    , p_primaryexaccNo                     varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_firstexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_secondexaccNo                      varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_thirdexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_fourthexaccNo                      varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_fifthexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_sixthexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_seventhexaccNo                     varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_eightexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    , p_ninthexaccNo                       varchar2    default    null --nurzalata CQDB5992 full and short account numbers
    )is pragma autonomous_transaction;
    
Begin

 insert into cbs_card_debit_app_islem(     app_id,
                                            tx_no,    
                                            record_type,
                                            customer_no,
                                            multiple_tx_internal_no, 
                                            card_no,    
                                            card_id_no,
                                            debit_option,        
                                            ref_tx_no,   
                                            tran_code,                  
                                            response_code,        
                                            response_desc,        
                                            response_date,        
                                            newcardno,        
                                            newpanno,       
                                            CustomerNumber                        ,
                                            name                                  ,
                                            middleName                            ,
                                            surname                               ,
                                            title                                 ,
                                            embossName                            ,
                                            maidenSurname                         ,
                                            IDTypeEmployee                        ,
                                            BISerial                              ,
                                            BINumber                              ,
                                            driverLicense                         ,
                                            passport                              ,
                                            motherMaidenName                      ,
                                            dateOfBirth                           ,
                                            placeOfBirth                          ,
                                            sex                                   ,
                                            maritialStatus                        ,
                                            nationalityCode                       ,
                                            nationalityDesc                       ,
                                            motherName                            ,
                                            fatherName                            ,
                                            branchID                              ,
                                            taxNumber                             ,
                                            taxOffice                             ,
                                            workPlace                             ,
                                            position                              ,
                                            groupCode                             ,
                                            subGroupCode                          ,
                                            companyFlag                           ,
                                            companyNo                             ,
                                            companyName                           ,
                                            companyEmbossedName                   ,
                                            pinDeliveryType                       ,
                                            pinDeliveryAddress                    ,
                                            cardSendType                          ,
                                            cardSendAddress                       ,
                                            pinDeliveryBranch                     ,
                                            cardDeliveryBranch                    ,
                                            homeEMail                             ,
                                            homeAddress1                          ,
                                            homeAddress2                          ,
                                            homeAddress3                          ,
                                            homeCounty                            ,
                                            homeCityCode                          ,
                                            homeCity                              ,
                                            homePostalCode                        ,
                                            homeCountry                           ,
                                            homePhoneCountryCode               ,  -- AdiletK 13.10.2015 CQ4961
                                            homePhoneRegionCode                   ,
                                            homePhone                             ,
                                            homeFaxRegionCode                     ,
                                            homeFax                               ,
                                            mobilePhoneCountryCode         ,    -- AdiletK 13.10.2015 CQ4961
                                            mobilePhoneRegionCode                 ,
                                            mobilePhone                           ,
                                            foreignMobileCountryCode,       -- AdiletK 13.10.2015 CQ4961  
                                            foreignMobileRegionCode,        -- AdiletK 13.10.2015 CQ4961  
                                            foreignMobilePhone ,                -- AdiletK 13.10.2015 CQ4961
                                            workAddress1                          ,
                                            workAddress2                          ,
                                            workAddress3                          ,
                                            workCounty                            ,
                                            workCityCode                          ,
                                            workCity                              ,
                                            workPostalCode                        ,
                                            workCountry                           ,
                                            workPhoneRegionCode                   ,
                                            workPhone                             ,
                                            workPhoneExtension                    ,
                                            workFaxRegionCode                     ,
                                            workFax                               ,
                                            workEmail                             ,
                                            requestingUserCode                    ,
                                            requestingTerminal                    ,
                                            tempActive                            ,
                                            tempType                              ,
                                            tempAddress1                          ,
                                            tempAddress2                          ,
                                            tempAddress3                          ,
                                            tempCounty                            ,
                                            tempCityCode                          ,
                                            tempCity                              ,
                                            tempPostalCode                        ,
                                            tempCountry                           ,
                                            tempPhoneRegionCode                   ,
                                            tempPhone                             ,
                                            tempPhoneExtension                    ,
                                            tempFaxRegionCode                     ,
                                            tempFax                               ,
                                            tempEmail                             ,
                                            createCardFlag                        ,
                                            BIN                                   ,
                                            embossPriority                        ,
                                            cardStyle                             ,
                                            primaryAccountNo                         ,
                                            primaryAccountBranch                     ,
                                            primaryAccountAlias                      ,
                                            primaryAccountCustomerId                 ,
                                            primaryAccountNameSurname                ,
                                            primaryAccountCurrency                   ,
                                            primaryAccountType                       ,
                                            firstAccountNo                           ,
                                            firstAccountBranch                       ,
                                            firstAccountAlias                        ,
                                            firstAccountCustomerId                   ,
                                            firstAccountNameSurname                  ,
                                            firstAccountCurrency                     ,
                                            firstAccountType                         ,
                                            secondAccountNo                          ,
                                            secondAccountBranch                      ,
                                            secondAccountAlias                       ,
                                            secondAccountCustomerId                  ,
                                            secondAccountNameSurname                 ,
                                            secondAccountCurrency                    ,
                                            secondAccountType                        ,
                                            thirdAccountNo                           ,
                                            thirdAccountBranch                       ,
                                            thirdAccountAlias                        ,
                                            thirdAccountCustomerId                   ,
                                            thirdAccountNameSurname                  ,
                                            thirdAccountCurrency                     ,
                                            thirdAccountType                         ,
                                            fourthAccountNo                          ,
                                            fourthAccountBranch                      ,
                                            fourthAccountAlias                       ,
                                            fourthAccountCustomerId                  ,
                                            fourthAccountNameSurname                 ,
                                            fourthAccountCurrency                    ,
                                            fourthAccountType                        ,
                                            fifthAccountNo                           ,
                                            fifthAccountBranch                       ,
                                            fifthAccountAlias                        ,
                                            fifthAccountCustomerId                   ,
                                            fifthAccountNameSurname                  ,
                                            fifthAccountCurrency                     ,
                                            fifthAccountType                         ,
                                            sixthAccountNo                           ,
                                            sixthAccountBranch                       ,
                                            sixthAccountAlias                        ,
                                            sixthAccountCustomerId                   ,
                                            sixthAccountNameSurname                  ,
                                            sixthAccountCurrency                     ,
                                            sixthAccountType                         ,
                                            seventhAccountNo                         ,
                                            seventhAccountBranch                     ,
                                            seventhAccountAlias                      ,
                                            seventhAccountCustomerId                 ,
                                            seventhAccountNameSurname                ,
                                            seventhAccountCurrency                   ,
                                            seventhAccountType                       ,
                                            eightAccountNo                           ,
                                            eightAccountBranch                       ,
                                            eightAccountAlias                        ,
                                            eightAccountCustomerId                   ,
                                            eightAccountNameSurname                  ,
                                            eightAccountCurrency                     ,
                                            eightAccountType                         ,
                                            ninthAccountNo                           ,
                                            ninthAccountBranch                       ,
                                            ninthAccountAlias                        ,
                                            ninthAccountCustomerId                   ,
                                            ninthAccountNameSurname                  ,
                                            ninthAccountCurrency                     ,
                                            ninthAccountType    ,
                                            pseudopanno ,
                                            statuswillbeupdated ,
                                            newcardstatus,
                                            statuschangedesc 
                                            , default_mobile_phone, daily_cota_limit, offline_permit    --CQ5510 MederT 28072016
                                            , noname --aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
                                            , pin_print_flag--PINPrintFlag project NurzalatA 29122017
                                            , primaryexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , firstexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , secondexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , thirdexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , fourthexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , fifthexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , sixthexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , seventhexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , eightexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            , ninthexternalaccno --nurzalata CQDB5992 full and short account numbers
                                            )
                                    
                            values
                                        (
                                        pn_app_id,
                                        pn_tx_no,    
                                        ps_record_type,
                                        pn_musteri_no,
                                        pn_multiple_tx_internal_no,
                                        ps_card_no,    
                                        pn_card_id_no,
                                        ps_debit_option,        
                                        pn_tx_no,     
                                        pn_tran_code,                        
                                        ps_response_code,        
                                        ps_response_desc,        
                                        pd_response_date,        
                                        ps_newcardno,        
                                        ps_newpanno,        
                                        p_CustomerNumber                        ,
                                        p_name                                  ,
                                        p_middleName                            ,
                                        p_surname                               ,
                                        p_title                                 ,
                                        p_embossName                            ,
                                        p_maidenSurname                         ,
                                        p_IDTypeEmployee                        ,
                                        p_BISerial                              ,
                                        p_BINumber                              ,
                                        p_driverLicense                         ,
                                        p_passport                              ,
                                        p_motherMaidenName                      ,
                                        p_dateOfBirth                           ,
                                        p_placeOfBirth                          ,
                                        p_sex                                   ,
                                        p_maritialStatus                        ,
                                        p_nationalityCode                       ,
                                        p_nationalityDesc                       ,
                                        p_motherName                            ,
                                        p_fatherName                            ,
                                        p_branchID                              ,
                                        p_taxNumber                             ,
                                        p_taxOffice                             ,
                                        p_workPlace                             ,
                                        p_position                              ,
                                        p_groupCode                             ,
                                        p_subGroupCode                          ,
                                        p_companyFlag                           ,
                                        p_companyNo                             ,
                                        p_companyName                           ,
                                        p_companyEmbossedName                   ,
                                        p_pinDeliveryType                       ,
                                        p_pinDeliveryAddress                    ,
                                        p_cardSendType                          ,
                                        p_cardSendAddress                       ,
                                        p_pinDeliveryBranch                     ,
                                        p_cardDeliveryBranch                    ,
                                        p_homeEMail                             ,
                                        p_homeAddress1                          ,
                                        p_homeAddress2                          ,
                                        p_homeAddress3                          ,
                                        p_homeCounty                            ,
                                        p_homeCityCode                          ,
                                        p_homeCity                              ,
                                        p_homePostalCode                        ,
                                        p_homeCountry                           ,
                                        p_homePhoneCountryCode             ,  -- AdiletK 13.10.2015 CQ4961 
                                        p_homePhoneRegionCode                   ,
                                        p_homePhone                             ,
                                        p_homeFaxRegionCode                     ,
                                        p_homeFax                               ,
                                        p_mobilePhoneCountryCode         ,    -- AdiletK 13.10.2015 CQ4961
                                        p_mobilePhoneRegionCode                 ,
                                        p_mobilePhone                           ,
                                        p_foreignMobileCountryCode      ,     -- AdiletK 13.10.2015 CQ4961
                                        p_foreignMobileRegionCode       ,     -- AdiletK 13.10.2015 CQ4961
                                        p_foreignMobilePhone                ,    -- AdiletK 13.10.2015 CQ4961
                                        p_workAddress1                          ,
                                        p_workAddress2                          ,
                                        p_workAddress3                          ,
                                        p_workCounty                            ,
                                        p_workCityCode                          ,
                                        p_workCity                              ,
                                        p_workPostalCode                        ,
                                        p_workCountry                           ,
                                        p_workPhoneRegionCode                   ,
                                        p_workPhone                             ,
                                        p_workPhoneExtension                    ,
                                        p_workFaxRegionCode                     ,
                                        p_workFax                               ,
                                        p_workEmail                             ,
                                        p_requestingUserCode                    ,
                                        p_requestingTerminal                    ,
                                        p_tempActive                            ,
                                        p_tempType                              ,
                                        p_tempAddress1                          ,
                                        p_tempAddress2                          ,
                                        p_tempAddress3                          ,
                                        p_tempCounty                            ,
                                        p_tempCityCode                          ,
                                        p_tempCity                              ,
                                        p_tempPostalCode                        ,
                                        p_tempCountry                           ,
                                        p_tempPhoneRegionCode                   ,
                                        p_tempPhone                             ,
                                        p_tempPhoneExtension                    ,
                                        p_tempFaxRegionCode                     ,
                                        p_tempFax                               ,
                                        p_tempEmail                             ,
                                        p_createCardFlag                        ,
                                        p_BIN                                   ,
                                        p_embossPriority                        ,
                                        p_cardStyle                             ,
                                        p_primaryAccountNo                         ,
                                        p_primaryAccountBranch                     ,
                                        p_primaryAccountAlias                      ,
                                        p_primaryAccountCustomerId                 ,
                                        p_primaryAccountNameSurname                ,
                                        p_primaryAccountCurrency                   ,
                                        p_primaryAccountType                       ,
                                        p_firstAccountNo                           ,
                                        p_firstAccountBranch                       ,
                                        p_firstAccountAlias                        ,
                                        p_firstAccountCustomerId                   ,
                                        p_firstAccountNameSurname                  ,
                                        p_firstAccountCurrency                     ,
                                        p_firstAccountType                         ,
                                        p_secondAccountNo                          ,
                                        p_secondAccountBranch                      ,
                                        p_secondAccountAlias                       ,
                                        p_secondAccountCustomerId                  ,
                                        p_secondAccountNameSurname                 ,
                                        p_secondAccountCurrency                    ,
                                        p_secondAccountType                        ,
                                        p_thirdAccountNo                           ,
                                        p_thirdAccountBranch                       ,
                                        p_thirdAccountAlias                        ,
                                        p_thirdAccountCustomerId                   ,
                                        p_thirdAccountNameSurname                  ,
                                        p_thirdAccountCurrency                     ,
                                        p_thirdAccountType                         ,
                                        p_fourthAccountNo                          ,
                                        p_fourthAccountBranch                      ,
                                        p_fourthAccountAlias                       ,
                                        p_fourthAccountCustomerId                  ,
                                        p_fourthAccountNameSurname                 ,
                                        p_fourthAccountCurrency                    ,
                                        p_fourthAccountType                        ,
                                        p_fifthAccountNo                           ,
                                        p_fifthAccountBranch                       ,
                                        p_fifthAccountAlias                        ,
                                        p_fifthAccountCustomerId                   ,
                                        p_fifthAccountNameSurname                  ,
                                        p_fifthAccountCurrency                     ,
                                        p_fifthAccountType                         ,
                                        p_sixthAccountNo                           ,
                                        p_sixthAccountBranch                       ,
                                        p_sixthAccountAlias                        ,
                                        p_sixthAccountCustomerId                   ,
                                        p_sixthAccountNameSurname                  ,
                                        p_sixthAccountCurrency                     ,
                                        p_sixthAccountType                         ,
                                        p_seventhAccountNo                         ,
                                        p_seventhAccountBranch                     ,
                                        p_seventhAccountAlias                      ,
                                        p_seventhAccountCustomerId                 ,
                                        p_seventhAccountNameSurname                ,
                                        p_seventhAccountCurrency                   ,
                                        p_seventhAccountType                       ,
                                        p_eightAccountNo                           ,
                                        p_eightAccountBranch                       ,
                                        p_eightAccountAlias                        ,
                                        p_eightAccountCustomerId                   ,
                                        p_eightAccountNameSurname                  ,
                                        p_eightAccountCurrency                     ,
                                        p_eightAccountType                         ,
                                        p_ninthAccountNo                           ,
                                        p_ninthAccountBranch                       ,
                                        p_ninthAccountAlias                        ,
                                        p_ninthAccountCustomerId                   ,
                                        p_ninthAccountNameSurname                  ,
                                        p_ninthAccountCurrency                     ,
                                        p_ninthAccountType ,
                                        p_pseudopanno ,
                                        p_statuswillbeupdated ,
                                        p_newcardstatus,
                                        p_statuschangedesc 
                                        , p_default_mobile_phone, p_daily_cota_limit, p_offline_permit    --CQ5510 MederT 28072016
                                        , p_noname --aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
                                        , p_pin_print_flag--PINPrintFlag project NurzalatA 29122017
                                        , p_primaryexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_firstexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_secondexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_thirdexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_fourthexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_fifthexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_sixthexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_seventhexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_eightexaccno --nurzalata CQDB5992 full and short account numbers
                                        , p_ninthexaccno --nurzalata CQDB5992 full and short account numbers
                                        );

    commit;

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   log_At('SP_INS_DEBIT_CARD_APP_ISLEM-ERROR',pn_app_id, sqlcode||' '||sqlerrm ); 
   raise_application_error(-20100,pkg_hata.getucpointer || '6702' || pkg_hata.getdelimiter ||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   

End;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
procedure SP_DCARD_INSERT_APP_CALL_WS(pn_tx_no number ,
                                       pn_musteri_no number ,
                                       pn_app_id out number,
                                       pn_tran_code number default null,
                                       pn_multiple_tx_internal_no number default null, 
                                       ps_debit_option varchar2 default null,  
                                       ps_card_no          in out  varchar2 ,
                                       pn_card_id_no        in out   VARCHAR2 , 
                                       ps_tx_branch_code varchar2 default pkg_baglam.bolum_kodu,
                                       ps_emboss_name_eng varchar2 default null,
                                       ps_emboss_second_name_eng varchar2 default null,
                                       ps_emboss_surname_eng varchar2 default null ,
                                       ps_response_code out varchar2 ,
                                       ps_response_desc out varchar2 ,
                                       ps_delivery_branch varchar2 default pkg_baglam.bolum_kodu --aisuluud cq5550 added ps_delivery_branch varchar2 default pkg_baglam.bolum_kodu
                                        
) is
        l_CustomerNumber                            varchar2(13);
        l_name                                      varchar2(20);
        l_middleName                                varchar2(20);
        l_surname                                   varchar2(20);
        l_title                                     varchar2(20);
        l_embossName                                varchar2(26);
        l_maidenSurname                             varchar2(20);
        l_IDTypeEmployee                            varchar2(1);
        l_BISerial                                  varchar2(3);
        l_BINumber                                  varchar2(8);
        l_driverLicense                             varchar2(10);
        l_passport                                  varchar2(10);
        l_motherMaidenName                          varchar2(20);
        l_dateOfBirth                               varchar2(10);
        l_placeOfBirth                              varchar2(20);
        l_sex                                       varchar2(1);
        l_maritialStatus                            varchar2(2);
        l_nationalityCode                           varchar2(2);
        l_nationalityDesc                           varchar2(20);
        l_motherName                                varchar2(20);
        l_fatherName                                varchar2(20);
        l_branchID                                  varchar2(5);
        l_taxNumber                                 varchar2(20);
        l_taxOffice                                 varchar2(20);
        l_workPlace                                 varchar2(40);
        l_position                                  varchar2(40);
        l_groupCode                                 varchar2(3);
        l_subGroupCode                              varchar2(8);
        l_companyFlag                               varchar2(1);
        l_companyNo                                 varchar2(8);
        l_companyName                               varchar2(40);
        l_companyEmbossedName                       varchar2(25);
        l_pinDeliveryType                           varchar2(1);
        l_pinDeliveryAddress                        varchar2(1);
        l_cardSendType                              varchar2(1);
        l_cardSendAddress                           varchar2(1);
        l_pinDeliveryBranch                         varchar2(5);
        l_cardDeliveryBranch                        varchar2(5);
        ls_card_branch_code                         varchar2(5);
----adres
        l_homeEMail                                 varchar2(40);
        l_homeAddress1                              varchar2(40);
        l_homeAddress2                              varchar2(40);
        l_homeAddress3                              varchar2(40);
        l_homeCounty                                varchar2(25);
        l_homeCityCode                              varchar2(2);
        l_homeCity                                  varchar2(25);
        l_homePostalCode                            varchar2(8);
        l_homeCountry                               varchar2(25);
        l_homePhoneCountryCode                       varchar2(4); -- AdiletK 13.10.2015 CQ4961
        l_homePhoneRegionCode                       varchar2(3);
        l_homePhone                                 varchar2(6);
        l_homeFaxRegionCode                         varchar2(3);
        l_homeFax                                   varchar2(6);
        l_mobilePhoneCountryCode                     varchar2(4); -- AdiletK 13.10.2015 CQ4961
        l_mobilePhoneRegionCode                     varchar2(3);
        l_mobilePhone                               varchar2(10);    --CQ5510 MederT 28072016
        l_foreignMobileCountryCode            varchar2(4); -- AdiletK 13.10.2015 CQ4961 adding card style field
        l_foreignMobileRegionCode              varchar2(3); -- AdiletK 13.10.2015 CQ4961           
        l_foreignMobilePhone                      varchar2(10); -- AdiletK 13.10.2015 CQ4961
        l_workAddress1                              varchar2(40);
        l_workAddress2                              varchar2(40);
        l_workAddress3                              varchar2(40);
        l_workCounty                                varchar2(25);
        l_workCityCode                              varchar2(2);
        l_workCity                                  varchar2(25);
        l_workPostalCode                            varchar2(8);
        l_workCountry                               varchar2(25);
        l_workMobilePhoneCountryCode                     varchar2(4);   -- AdiletK 13.10.2015 CQ4961
        l_workMobilePhoneRegionCode                     varchar2(3);   -- AdiletK 13.10.2015 CQ4961
        l_workMobilePhone                               varchar2(10);       -- AdiletK 13.10.2015 CQ4961
        l_workPhoneCountryCode                       varchar2(4);        -- AdiletK 13.10.2015 CQ4961
        l_workPhoneRegionCode                       varchar2(3);
        l_workPhone                                 varchar2(6);
        l_workPhoneExtension                        varchar2(6);
        l_workFaxRegionCode                         varchar2(3);
        l_workFax                                   varchar2(6);
        l_workEmail                                 varchar2(40);
        l_workForeignMobileCountryCode            varchar2(4); -- AdiletK 13.10.2015 CQ4961 adding card style field
        l_workForeignMobileRegionCode              varchar2(3); -- AdiletK 13.10.2015 CQ4961           
        l_workForeignMobilePhone                      varchar2(10); -- AdiletK 13.10.2015 CQ4961          
        l_requestingUserCode                        varchar2(8) := nvl(substr(user,1,8),' ');
        l_requestingTerminal                        varchar2(8) := nvl(substr(ps_tx_branch_Code,1,8),' ');
        l_tempActive                                varchar2(1);
        l_tempType                                  varchar2(1);
        l_tempAddress1                              varchar2(40);
        l_tempAddress2                              varchar2(40);
        l_tempAddress3                              varchar2(40);
        l_tempCounty                                varchar2(25);
        l_tempCityCode                              varchar2(2);
        l_tempCity                                  varchar2(25);
        l_tempPostalCode                            varchar2(8);
        l_tempCountry                               varchar2(25);
        l_tempPhoneCountryCode                       varchar2(4); -- AdiletK 13.10.2015 CQ4961
        l_tempPhoneRegionCode                       varchar2(3);
        l_tempPhone                                 varchar2(6);
        l_tempPhoneExtension                        varchar2(6);
        l_tempFaxRegionCode                         varchar2(3);
        l_tempFax                                   varchar2(6);
        l_tempEmail                                 varchar2(40);
        l_tempmobilePhoneCountryCode                     varchar2(4); -- AdiletK 13.10.2015 CQ4961
        l_tempmobilePhoneRegionCode                     varchar2(3);
        l_tempmobilePhone                               varchar2(10);    --CQ5510 MederT 28072016
        l_tempForeignMobileCountryCode            varchar2(4); -- AdiletK 13.10.2015 CQ4961 adding card style field
        l_tempForeignMobileRegionCode              varchar2(3); -- AdiletK 13.10.2015 CQ4961           
        l_tempForeignMobilePhone                      varchar2(10); -- AdiletK 13.10.2015 CQ4961
            
        l_createCardFlag                            varchar2(1);
        l_BIN                                       varchar2(8); --NurmilaZ CBS-669
        l_embossPriority                            varchar2(2);
        l_cardStyle                                 varchar2(10);  -- AdiletK 13.10.2015 CQ4961 adding card style field
        l_primaryAccountNo                             varchar2(18);
        l_primaryAccountBranch                         varchar2(5);
        l_primaryAccountAlias                          varchar2(15);
        l_primaryAccountCustomerId                     varchar2(13);
        l_primaryAccountNameSurname                    varchar2(40);
        l_primaryAccountCurrency                       varchar2(3);
        l_primaryAccountType                           varchar2(1);
        l_primaryexaccNo                               varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_firstAccountNo                               varchar2(18);
        l_firstAccountBranch                           varchar2(5);
        l_firstAccountAlias                            varchar2(15);
        l_firstAccountCustomerId                       varchar2(13);
        l_firstAccountNameSurname                      varchar2(40);
        l_firstAccountCurrency                         varchar2(3);
        l_firstAccountType                             varchar2(1);
        l_firstexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_secondAccountNo                              varchar2(18);
        l_secondAccountBranch                          varchar2(5);
        l_secondAccountAlias                           varchar2(15);
        l_secondAccountCustomerId                      varchar2(13);
        l_secondAccountNameSurname                     varchar2(40);
        l_secondAccountCurrency                        varchar2(3);
        l_secondAccountType                            varchar2(1);
        l_secondexaccNo                                varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_thirdAccountNo                               varchar2(18);
        l_thirdAccountBranch                           varchar2(5);
        l_thirdAccountAlias                            varchar2(15);
        l_thirdAccountCustomerId                       varchar2(13);
        l_thirdAccountNameSurname                      varchar2(40);
        l_thirdAccountCurrency                         varchar2(3);
        l_thirdAccountType                             varchar2(1);
        l_thirdexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_fourthAccountNo                              varchar2(18);
        l_fourthAccountBranch                          varchar2(5);
        l_fourthAccountAlias                           varchar2(15);
        l_fourthAccountCustomerId                      varchar2(13);
        l_fourthAccountNameSurname                     varchar2(40);
        l_fourthAccountCurrency                        varchar2(3);
        l_fourthAccountType                            varchar2(1);
        l_fourthexaccNo                                varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_fifthAccountNo                               varchar2(18);
        l_fifthAccountBranch                           varchar2(5);
        l_fifthAccountAlias                            varchar2(15);
        l_fifthAccountCustomerId                       varchar2(13);
        l_fifthAccountNameSurname                      varchar2(40);
        l_fifthAccountCurrency                         varchar2(3);
        l_fifthAccountType                             varchar2(1);
        l_fifthexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_sixthAccountNo                               varchar2(18);
        l_sixthAccountBranch                           varchar2(5);
        l_sixthAccountAlias                            varchar2(15);
        l_sixthAccountCustomerId                       varchar2(13);
        l_sixthAccountNameSurname                      varchar2(40);
        l_sixthAccountCurrency                         varchar2(3);
        l_sixthAccountType                             varchar2(1);
        l_sixthexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_seventhAccountNo                             varchar2(18);
        l_seventhAccountBranch                         varchar2(5);
        l_seventhAccountAlias                          varchar2(15);
        l_seventhAccountCustomerId                     varchar2(13);
        l_seventhAccountNameSurname                    varchar2(40);
        l_seventhAccountCurrency                       varchar2(3);
        l_seventhAccountType                           varchar2(1);
        l_seventhexaccNo                               varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_eightAccountNo                               varchar2(18);
        l_eightAccountBranch                           varchar2(5);
        l_eightAccountAlias                            varchar2(15);
        l_eightAccountCustomerId                       varchar2(13);
        l_eightAccountNameSurname                      varchar2(40);
        l_eightAccountCurrency                         varchar2(3);
        l_eightAccountType                             varchar2(1);
        l_eightexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_ninthAccountNo                               varchar2(18);
        l_ninthAccountBranch                           varchar2(5);
        l_ninthAccountAlias                            varchar2(15);
        l_ninthAccountCustomerId                       varchar2(13);
        l_ninthAccountNameSurname                      varchar2(40);
        l_ninthAccountCurrency                         varchar2(3);
        l_ninthAccountType                             varchar2(1);
        l_ninthexaccNo                                 varchar2(16);--nurzalata CQDB5992 full and short account numbers
        l_pseudopanno                                  varchar2(16);
        l_statuswillbeupdated                          varchar2(1);
        l_newcardstatus                                varchar2(1);
        l_statuschangedesc                             varchar2(40);
        ls_card_acccount_type                          varchar2(20);
        ls_noname                                      varchar2(1);--aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
        ls_pin_print_flag                              varchar2(1);--PINPrintFlag project NurzalatA 29122017
        
        --BOM CQ5510 MederT 28072016
        ls_default_mobile_phone         varchar2(10);
        ls_daily_cota_limit             number := 0;
        ls_offline_permit               varchar2(10) := 'N';
        --EOM CQ5510 MederT 28072016
    
        ln_home_Adres_cnt number := 0;
        ln_work_Adres_cnt number := 0;
        ln_contact_Adres_cnt number := 0;
        adres_yok           exception;
    cursor cur_hesap is
      select 
            lpad(substr(account_no,1,18),18,'0')  accountno,                            
            lpad(substr(nvl(pkg_hesap.hesaptansubeal(account_no),'0'),1,4),4,'0') accountbranch,
            nvl(trim(pkg_hesap.hesaptandovizkodual(account_no)),' ')  accountalias,
            lpad(substr(customer_no,1,13),13,'0')  accountcustomerid ,
            upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_musteri.sf_musteri_eng_adi(customer_no))),' '),1,40)) accountnamesurname,
            nvl(trim(pkg_hesap.hesaptandovizkodual(account_no)),' ') accountcurrency,
            DECODE(ls_card_acccount_type,'PRIMARY','A','V') accounttype    
           from cbs_debit_card_account
        where customer_no = pn_musteri_no and
              card_account_type=ls_card_acccount_type and
              card_no =  ps_card_no  and   
              card_id_no = pn_card_id_no and
              account_no in (select hesap_no from cbs_hesap where  durum_kodu in ('A','D')) --NurmilaZ
              and nvl(pn_tran_code,0) <> 2304   --2304 isleminde butun bagli hesaplar ana tabldan al?n?p aktarildigi icin bu islem haric tutulur.diger 2300 ve 2002 kapamalarda ana tabldan da bagli hesaplar alinir.
              AND NVL(ps_debit_option,'X') <> 'NEW CARD'
              AND NVL(ps_debit_option,'X') <> 'NEW CARD WITH PIN'--nurzalata pinprintflag project
              AND NVL(ps_debit_option,'X') <> 'NEW CARD WITHOUT PIN'--nurzalata pinprintflag project
         union --2300 multiple accunt entry
         select 
            lpad(substr(hesap_no,1,18),18,'0')  accountno,                
            lpad(substr(nvl(pkg_hesap.hesaptansubeal(hesap_no),'0'),1,4),4,'0') accountbranch,
            nvl(trim(pkg_hesap.hesaptandovizkodual(hesap_no)),' ')  accountalias,
            lpad(substr(musteri_no,1,13),13,'0')  accountcustomerid ,
            upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_musteri.sf_musteri_eng_adi(musteri_no))),' '),1,40)) accountnamesurname,
            nvl(trim(pkg_hesap.hesaptandovizkodual(hesap_no)),' ') accountcurrency,
            DECODE(ls_card_acccount_type,'PRIMARY','A','V') accounttype    
           from cbs_hesap_basvuru_toplu_hes_is
         where tx_no = pn_tx_no and
               internal_no  =pn_multiple_tx_internal_no and
               pn_tran_code = 2300 and   
               musteri_no = pn_musteri_no and
               card_account_type=ls_card_acccount_type and
              -- card_no = nvl(ps_card_no,card_no)  and
              -- card_id_no = nvl(pn_card_id_no,card_id_no) and 
               hesap_no in (select hesap_no from cbs_hesap where durum_kodu in ('A','D')) --NurmilaZ
         union --2304 debit card mdification
         select 
            lpad(substr(account_no,1,18),18,'0')  accountno,                       
            lpad(substr(nvl(pkg_hesap.hesaptansubeal(account_no),'0'),1,4),4,'0') accountbranch,
              nvl(trim(pkg_hesap.hesaptandovizkodual(account_no)),' ')  accountalias,
            lpad(substr(customer_no,1,13),13,'0')  accountcustomerid ,
            upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_musteri.sf_musteri_eng_adi(customer_no))),' '),1,40)) accountnamesurname,
            nvl(trim(pkg_hesap.hesaptandovizkodual(account_no)),' ') accountcurrency,
            DECODE(ls_card_acccount_type,'PRIMARY','A','V') accounttype    
           from cbs_debit_card_account_tran
         where tx_no = pn_tx_no and
               pn_tran_code = 2304 and   
               customer_no = pn_musteri_no and
               card_account_type=ls_card_acccount_type and
             --  card_no = nvl(ps_card_no,card_no)  and
             --  card_id_no = nvl(pn_card_id_no,card_id_no) and 
               account_no in (select hesap_no from cbs_hesap where durum_kodu in ('A','D')); --NurmilaZ
   
        ln_indx_hesap number := 0;
        ln_adet       number := 0; 
        ls_record_type  varchar2(1);

    --    ln_card_id_no    number ;
     --   ls_card_no   varchar2(20);
         ld_response_date  date :=sysdate;       
        ls_newcardno                varchar2(100);
        ls_newpanno                varchar2(100);  

        p_emboss_full_name varchar2(200);
        ln_card_Adet  number:= 0;           
Begin
     


--inital parameters
   pn_app_id :=pkg_genel.genel_kod_al('CBS_CARD_DEBIT_APP');

   l_requestingUserCode := nvl(substr(user,1,8),' ');
   log_at('db','1',l_requestingUserCode);
   l_requestingTerminal:= nvl(substr(ps_tx_branch_Code,1,8),' ');
   log_at('db','2',l_requestingTerminal);
   p_emboss_full_name := pkg_Debit_Card.Sf_emboss_full_name(ps_emboss_name_Eng, ps_emboss_Second_name_eng, ps_emboss_surname_eng);

   select count(*)
   into ln_adet   
   from cbs_debit_card
   where customer_no = pn_musteri_no ;

   if nvl(ln_adet,0) <> 0 then 
        ls_record_type := 'U';
   else
        ls_record_type := 'I';
   end if; 
   
   l_createCardFlag := 'N';
   l_statuswillbeupdated:= 'N'; 
   l_statuschangedesc := ' ';
    l_newcardstatus := 'N';
   if ps_debit_option is not null then  
   
       if ps_debit_option in ('NEW CARD', 'NEW CARD WITH PIN', 'NEW CARD WITHOUT PIN') then  --nurzalata CQDB5981 added 'NEW CARD WITH PIN'
         l_createCardFlag :='Y';
       else
         l_createCardFlag := 'N';
        end if;

       if ps_debit_option = 'CANCEL CARD' then
          l_statuswillbeupdated :='Y'; 
          l_newcardstatus := 'T';   -- T :Card Request Cancellation       
          l_statuschangedesc := substr('Card Req.Cancel by tx no :'|| pn_tx_no,1,40);
       end if;   
           --Begin CQ1256 Debit card activation KonstantinJ 08.12.2014    
          if ps_debit_option = 'CARD ACTIVATION' then
          l_statuswillbeupdated :='Y'; 
          l_newcardstatus := 'N';  --N: Card Activation request
          l_statuschangedesc := substr('Card Req.Activation by tx no :'|| pn_tx_no,1,40);
       end if;   
           --End CQ1256 Debit card activation KonstantinJ 08.12.2014   
           
           --BOM aisuluud CQ5754
       if ps_debit_option = 'BLOCKING CARD' then
          l_statuswillbeupdated :='Y'; 
          l_newcardstatus := 'G';  --N: Card Blocking request
          l_statuschangedesc := substr('Card Req.Blocking by tx no :'|| pn_tx_no,1,40);
       end if; 
           --EOM aisuluud CQ5754 
       
       
       if ps_card_no is not null and  pn_card_id_no is not null then  --EXISTING CUSTOMER, CARD  
           select branch_code
           into ls_card_branch_code       
           from cbs_Debit_Card
           where card_no =ps_card_no and 
                 card_id_no =pn_card_id_no ;
       end if;
        
           
   end if; 

   l_bin            := '417221';
   l_embosspriority  :='01';
   l_pseudopanno :=  lpad(substr(nvl(pn_card_id_no,0),1,16),16,'0');

-- B-O-M AdiletK 13.10.2015 CQ4961 adding card style field   
    BEGIN
        IF pn_tran_code = 2304 THEN
            select card_style, pin_print_flag--nurzalata CQDB5981 added pin_print_flag
            into l_cardstyle, ls_pin_print_flag--nurzalata CQDB5981 added pin_print_flag
            from cbs_debit_card_main_tran
            where tx_no = pn_tx_no;
        ELSIF pn_tran_code = 2300 THEN
            select card_style, pin_print_flag--nurzalata CQDB5981 added pin_print_flag
            into l_cardstyle, ls_pin_print_flag--nurzalata CQDB5981 added pin_print_flag
            from cbs_hesap_basvuru_toplu_isl
            where tx_no = pn_tx_no;            
        ELSE
            select card_style
            into l_cardstyle
            from cbs_debit_card
            where card_no= ps_card_no and 
                 card_id_no =pn_card_id_no;
        END IF;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        l_cardstyle := '';  
    END;
 -- E-O-M AdiletK 13.10.2015 CQ4961 adding card style field
 
   --BOM C!5510 MederT 28072016
    IF LENGTH(l_cardstyle) > 0 THEN
        BEGIN
            --bom nurzalata jira: cbs-21 28092018 added new columns group_code and subgroup_code
            SELECT daily_cota_limit, offline_permit, bin_number, noname_flag, group_code, subgroup_code--nurzalata 16042018 NEW BIN for VDG, BIN number automation
            INTO ls_daily_cota_limit, ls_offline_permit, l_bin, ls_noname, l_groupcode, l_subgroupcode--took noname flag into table nurzalata 31052018
            FROM cbs_card_styles 
            WHERE code = l_cardstyle;
            --eom nurzalata jira: cbs-21 28092018 added new columns group_code and subgroup_code
        EXCEPTION WHEN NO_DATA_FOUND THEN
        ls_noname := 'N';--took noname flag into table nurzalata 31052018
        ls_daily_cota_limit := 0;
        ls_offline_permit := '';
        l_bin := '417221';--nurzalata 16042018 NEW BIN for VDG, BIN number automation
    END;
    END IF;
    --EOM C!5510 MederT 28072016 
    
    --bom nurzalata 16042018 NEW BIN for VDG, BIN number automation
    /*--BOM nurzalata CQDB5986
    if l_cardstyle = 'MEC' then
        l_bin := '670662';
    end if;
    --EOM nurzalata CQDB5986*/
    --eom nurzalata 16042018 NEW BIN for VDG, BIN number automation
  
--Customer information
 select                  
     lpad(substr(musteri_no,1,13),13,'0')   customernumber,
     pkg_Debit_card.CYR2LAT(upper(substr(nvl(decode(musteri_tipi_kod, 3, manager_name, isim_eng),' '),1,20)) )        custname,
     pkg_Debit_card.CYR2LAT(upper(substr(nvl(decode(musteri_tipi_kod, 3, manager_patronymic_name, ikinci_isim_eng),' '),1,20)))   custmiddlename,
     pkg_Debit_card.CYR2LAT(upper(substr(nvl(decode(musteri_tipi_kod, 3, manager_surname, soyadi_eng),' '),1,20)) )       custsurname,
     ' ' title,
     upper(pkg_Debit_card.CYR2LAT( substr(nvl(p_emboss_full_name,' '),1,26)))   embossname,
     ' '    maidensurname,
     nvl(decode(decode(musteri_tipi_kod, 3, manager_id_type, kimlik_kod),'1','N','2','E','3','P',' '),' ') idtypeemployee,
     substr(nvl(trim(pkg_Debit_card.CYR2LAT(decode(musteri_tipi_kod, 3, manager_passport_series, nufus_cuzdani_seri_no))),' '),1,3)        biserial,
     substr(nvl(trim(pkg_Debit_card.CYR2LAT(decode(musteri_tipi_kod, 3, manager_passport_number, nufus_cuzdani_seri_no))),' '),4,8)      binumber,
     substr(nvl(trim(pkg_Debit_card.CYR2LAT(ehliyet_belge_no)),' '),1,10)    driverlicense,
     substr(nvl(trim(pkg_Debit_card.CYR2LAT(decode(musteri_tipi_kod, 3, manager_passport_number, pasaport_no))),' '),1,10)    passport,
     upper( substr(nvl(trim(pkg_Debit_card.CYR2LAT(anne_kizlik_soyadi)),' '),1,20))    mothermaidenname,
     substr(nvl(to_char(dogum_tarihi,'YYYYMMDD'),' '),1,8)    dateofbirth,
     upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(dogum_yeri)),' '),1,20))  placeofbirth,
     nvl(decode(decode(musteri_tipi_kod, 3, 'M', cinsiyet_kod),'M','E','F','F',' '),' ') sex,
     nvl(decode(medeni_hal_kod,'1','BE','2','EV','3','BO','BE'),'BE')   maritialstatus,
     nvl(uyruk_kod,' ') nationalitycode,
     upper(substr(nvl(upper(pkg_genel.ulke_adi_al(uyruk_kod)),' '),1,20)) nationalitydesc,
     upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(anne_adi)),' '),1,20))  mothername,
     upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(baba_adi)),' '),1,20))  fathername,
     lpad(substr(nvl( nvl(ls_card_branch_code,ps_tx_branch_code),'0'),1,4),4,'0')   branchid, -----aisuluud cq5550 returned back ls_card_branch_code
     --lpad(substr(nvl( nvl(ls_card_branch_code,ps_tx_branch_code),'0'),1,4),4,'0'), 
     substr(nvl(trim(vergi_no),' '),1,20)  taxnumber,
     upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(vergi_dairesi_adi)),' '),1,20))  taxoffice,
     upper(substr(nvl(pkg_Debit_card.CYR2LAT(pkg_musteri.sf_musteri_adi(company_of_the_staff)),' '),1,40))  workplace,
-- E-O-M AdiletK 13.10.2015 CQ4961 adding card style field   
     ' ' position,
    nvl(l_groupcode, decode( nvl(pkg_debit_card.sf_work_salary_cust_firm_id(nvl(company_of_the_staff,musteri_no)),0),0,'VG','VP')) groupcode,--nurzalata 07052018 VDG customer group defect 
    nvl(l_subgroupcode, decode( nvl(pkg_debit_card.sf_work_salary_cust_firm_id(nvl(company_of_the_staff,musteri_no)),0),0,'VFC','SLR'))  subgroupcode,--nurzalata 07052018 VDG customer group defect
    decode( nvl(pkg_debit_card.sf_work_salary_cust_firm_id(nvl(company_of_the_staff,musteri_no)),0),0,'N','Y') companyflag,
    nvl(pkg_debit_card.sf_work_Salary_cust_BS_compno(nvl(company_of_the_staff,musteri_no)),' ')     companyno,
    upper(substr(nvl(pkg_debit_card.cyr2lat(pkg_debit_card.sf_work_salary_firm_eng_name(nvl(company_of_the_staff,musteri_no))),' '),1,40))  companyname,
    upper(substr(nvl(pkg_debit_card.cyr2lat(pkg_debit_card.sf_work_salary_firm_eng_name(nvl(company_of_the_staff,musteri_no))),' '),1,25))  companyembossedname,
    'S' pindeliverytype,
    'S' pindeliveryaddress,
    'S' cardsendtype,
    'I' cardSendAddress,
     lpad(substr(nvl(ps_delivery_branch,'0'),1,4),4,'0')  pindeliverybranch,  --aisuluud cq5550 added   ps_delivery_branch instead of ps_tx_branch_code               
     lpad(substr(nvl(ps_delivery_branch,'0'),1,4),4,'0')  carddeliverybranch   --aisuluud cq5550 added   ps_delivery_branch instead of ps_tx_branch_code 
      , nvl(default_mobile_phone, '01')         --CQ5510 MederT 28072016
 into       l_customernumber      ,
            l_name                ,
            l_middlename          ,
            l_surname             ,
            l_title               ,
            l_embossname          ,
            l_maidensurname       ,
            l_idtypeemployee      ,
            l_biserial            ,
            l_binumber            ,
            l_driverlicense       ,
            l_passport            ,
            l_mothermaidenname    ,
            l_dateofbirth         ,
            l_placeofbirth        ,
            l_sex                 ,
            l_maritialstatus      ,
            l_nationalitycode     ,
            l_nationalitydesc     ,
            l_mothername          ,
            l_fathername          ,
            l_branchid            ,
            l_taxnumber           ,
            l_taxoffice           ,
            l_workplace           ,
            l_position            ,
            l_groupcode           ,
            l_subgroupcode        ,
            l_companyflag         ,
            l_companyno           ,
            l_companyname         ,
            l_companyembossedname ,
            l_pindeliverytype     ,
            l_pindeliveryaddress  ,
            l_cardsendtype        ,
            l_cardsendaddress     ,
            l_pindeliverybranch   ,
            l_carddeliverybranch  ,  
            ls_default_mobile_phone         --CQ5510 MederT 28072016
     from cbs_musteri
     where musteri_no = pn_musteri_no;
---Address information
 --1. Home
 
   Begin     
             ln_home_Adres_cnt     := 0; 
             select count(*)
             into ln_home_Adres_cnt
             from cbs_musteri_Adres
             where musteri_no = pn_musteri_no and
                  ADRES_KOD= '1';
                  
         select    
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(email)),' '),1,40)) homeemail,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),1,40)) homeaddress1,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),41,40)) homeaddress2,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),81,40)) homeaddress3,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT('KG')),' '),1,25)) homecounty, -- AdiletK 13.10.2015 CQ4961
              upper(substr(nvl(trim(pkg_debit_Card.sf_bs_city_code(il_kod)),' '),1,2)) homecitycode ,--map edilecek
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz(il_kod))),' '),1,25)) homecity, --map edilecek
              substr(nvl(trim(pkg_Debit_card.CYR2LAT(posta_kod)),' '),1,8) homepostalcode,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.ulke_adi_al_hatasiz(ulke_kod))),' '),1,25)) homecountry,
              substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_tel_kod,996)),1,4) homephonecountrycode,  -- AdiletK 13.10.2015 CQ4961
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(tel_alan_kod),1,3) homephoneregioncode,
              substr(pkg_debit_Card.sf_tel_alan_no_formatli(tel_no),1,6) homephone,
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(fax_alan_kod),1,3) homefaxregioncode,
              substr(pkg_debit_Card.sf_tel_alan_no_formatli(fax_no),1,6) homefax,
              substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_gsm_kod,996)),1,4) mobilePhoneCountryCode,  -- AdiletK 13.10.2015 CQ4961
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod),1,3) mobilePhoneRegionCode,
              substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no),1,10) mobilePhone,    --CQ5510 MederT 28072016
              substr(pkg_debit_card.sf_country_code_formatted(nvl(ulke_gsm_kod_2,996)),1,4) foreignMobileCountryCode,  -- AdiletK 13.10.2015 CQ4961       
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod_2),1,3) foreignMobileRegionCode,  -- AdiletK 13.10.2015 CQ4961       
              substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no_2),1,10)  foreignMobilePhone  -- AdiletK 13.10.2015 CQ4961       
         into 
                l_homeEMail                 ,
                l_homeAddress1              ,
                l_homeAddress2              ,
                l_homeAddress3              ,
                l_homeCounty                ,
                l_homeCityCode              ,
                l_homeCity                  ,
                l_homePostalCode            ,
                l_homeCountry               ,
                l_homePhoneCountryCode      ,-- AdiletK 13.10.2015 CQ4961
                l_homePhoneRegionCode       ,
                l_homePhone                 ,
                l_homeFaxRegionCode         ,
                l_homeFax                   ,
                l_mobilePhoneCountryCode    ,-- AdiletK 13.10.2015 CQ4961     
                l_mobilePhoneRegionCode     ,             
                l_mobilePhone               ,
                l_foreignMobileCountryCode  ,-- AdiletK 13.10.2015 CQ4961 
                l_foreignMobileRegionCode   ,-- AdiletK 13.10.2015 CQ4961 
                l_foreignMobilePhone         -- AdiletK 13.10.2015 CQ4961                         
         from cbs_musteri_Adres
             where musteri_no = pn_musteri_no and
                  ADRES_KOD= '1';
 Exception when others then null;
 End;
log_at('l_mobilePhone-1', l_mobilePhone);
 --2. Business
  Begin  
  
             ln_work_adres_cnt     := 0; 
             select count(*)
             into ln_work_adres_cnt
             from cbs_musteri_adres
             where musteri_no = pn_musteri_no and
                  adres_kod= '2';
                  
         select    
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),1,40)) workaddress1,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),41,40)) workaddress2,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),81,40)) workaddress3,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT('KG')),' '),1,25)) workcounty,
          upper(substr(nvl(trim(pkg_debit_Card.sf_bs_city_code(il_kod)),' '),1,2)) workcitycode ,--map edilecek
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz(il_kod))),' '),1,25)) workcity, --map edilecek
          substr(nvl(trim(pkg_Debit_card.CYR2LAT(posta_kod)),' '),1,8) workpostalcode,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.ulke_adi_al_hatasiz(ulke_kod))),' '),1,25)) workcountry,
          substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_gsm_kod,996)),1,4) workMobilePhoneCountryCode,  -- AdiletK 13.10.2015 CQ4961       
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod),1,3) workMobilePhoneRegionCode, -- AdiletK 13.10.2015 CQ4961     

          substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no),1,10) workMobilePhone,    --CQ5510 MederT 28072016
          substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_tel_kod,996)),1,4) workphonecountrycode, -- AdiletK 13.10.2015 CQ4961 
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(tel_alan_kod),1,3) workphoneregioncode,
          substr(pkg_debit_Card.sf_tel_alan_no_formatli(tel_no),1,6) workphone,
          ' ' WorkPhoneExtension,
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(fax_alan_kod),1,3) workfaxregioncode,
          substr(pkg_debit_Card.sf_tel_alan_no_formatli(fax_no),1,6) workfax,
          upper(substr(nvl(pkg_Debit_card.CYR2LAT(email),' '),1,40)) workemail,
          substr(pkg_debit_card.sf_country_code_formatted(nvl(ulke_gsm_kod_2,996)),1,4) workForeignMobileCountryCode,  -- AdiletK 13.10.2015 CQ4961       
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod_2),1,3) workForeignMobileRegionCode,      -- AdiletK 13.10.2015 CQ4961       
          substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no_2),1,10)  workForeignMobilePhone               -- AdiletK 13.10.2015 CQ4961  
        into 
                l_workAddress1   ,                   
                l_workAddress2    ,                  
                l_workAddress3    ,                  
                l_workCounty      ,                  
                l_workCityCode    ,                  
                l_workCity        ,                  
                l_workPostalCode  ,                  
                l_workCountry     ,        
                l_workMobilePhoneCountryCode, -- AdiletK 13.10.2015 CQ4961
                l_workMobilePhoneRegionCode,  -- AdiletK 13.10.2015 CQ4961
                l_workMobilePhone,                   -- AdiletK 13.10.2015 CQ4961
                l_workPhoneCountryCode,          -- AdiletK 13.10.2015 CQ4961          
                l_workPhoneRegionCode,               
                l_workPhone          ,               
                l_workPhoneExtension ,               
                l_workFaxRegionCode  ,               
                l_workFax            ,               
                l_workEmail,
                l_workForeignMobileCountryCode, -- AdiletK 13.10.2015 CQ4961
                l_workForeignMobileRegionCode, -- AdiletK 13.10.2015 CQ4961
                l_workForeignMobilePhone          -- AdiletK 13.10.2015 CQ4961                        
         from cbs_musteri_Adres
         where musteri_no = pn_musteri_no and
                  adres_kod= '2';
 exception when others then null;
 End;       

 --3. Contact
  Begin  
             ln_contact_adres_cnt     := 0; 
             select count(*)
             into ln_contact_adres_cnt
             from cbs_musteri_adres
             where musteri_no = pn_musteri_no and
                  adres_kod= '3';
                  
         select    
            '' tempActive,                        
            'S' tempType,    
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),1,40)) tempaddress1,  
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),41,40)) tempaddress2,     
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),81,40)) tempaddress3,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT('KG')),' '),1,25)) tempcounty,
              upper(substr(nvl(trim(pkg_debit_Card.sf_bs_city_code(il_kod)),' '),1,2)) tempcitycode ,--map edilecek
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz(il_kod))),' '),1,25)) tempcity, --map edilecek
              substr(nvl(trim(pkg_Debit_card.CYR2LAT(posta_kod)),' '),1,8) temppostalcode,
              upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.ulke_adi_al_hatasiz(ulke_kod))),' '),1,25)) tempcountry,
              substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_tel_kod,996)),1,4) tempphonecountrycode, -- AdiletK 13.10.2015 CQ4961
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(tel_alan_kod),1,3) tempphoneregioncode,
              substr(pkg_debit_Card.sf_tel_alan_no_formatli(tel_no),1,6) tempphone,
              ' ' tempPhoneExtension,
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(fax_alan_kod),1,3) tempfaxregioncode,
              substr(pkg_debit_Card.sf_tel_alan_no_formatli(fax_no),1,6) tempfax,
              upper(substr(nvl(pkg_Debit_card.CYR2LAT(email),' '),1,40)) tempemail,
              substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_gsm_kod,996)),1,4) mobilePhoneCountryCode, -- AdiletK 13.10.2015 CQ4961
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod),1,3) mobilePhoneRegionCode,

              substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no),1,10) mobilePhone,    --CQ5510 MederT 28072016
              substr(pkg_debit_Card.sf_country_code_formatted(nvl(ulke_gsm_kod_2,996)),1,4) foreignMobileCountryCode,  -- AdiletK 13.10.2015 CQ4961       
              substr(pkg_debit_Card.sf_tel_alan_kod_formatli(gsm_alan_kod_2),1,3) foreignMobileRegionCode,  -- AdiletK 13.10.2015 CQ4961       
              substr(pkg_debit_Card.sf_phone_number_formatted(gsm_no_2),1,10)   foreignMobilePhone  -- AdiletK 13.10.2015 CQ4961 
        into 
                l_tempActive    ,                    
                l_tempType       ,                   
                l_tempAddress1   ,                   
                l_tempAddress2   ,                   
                l_tempAddress3   ,                   
                l_tempCounty     ,                   
                l_tempCityCode   ,                   
                l_tempCity       ,                   
                l_tempPostalCode ,                  
                l_tempCountry    ,   
                l_tempPhoneCountryCode,           -- AdiletK 13.10.2015 CQ4961                
                l_tempPhoneRegionCode,               
                l_tempPhone        ,                 
                l_tempPhoneExtension,                
                l_tempFaxRegionCode,                 
                l_tempFax        ,                   
                l_tempEmail   ,
                l_tempmobilePhoneCountryCode,    -- AdiletK 13.10.2015 CQ4961  
                l_tempmobilePhoneRegionCode,             
                l_tempmobilePhone,
                l_tempForeignMobileCountryCode,    -- AdiletK 13.10.2015 CQ4961    
                l_tempForeignMobileRegionCode,      -- AdiletK 13.10.2015 CQ4961    
                l_tempForeignMobilePhone               -- AdiletK 13.10.2015 CQ4961                   
         from cbs_musteri_Adres
         where musteri_no = pn_musteri_no and
                  adres_kod= '3';
 exception when others then null;
 End;
    
     if nvl(ln_home_Adres_cnt,0) = 0 and  nvl(ln_work_Adres_cnt,0) = 0 and nvl(ln_contact_Adres_cnt,0) = 0 then
        raise adres_yok;
    end if;

-- B-O-M AdiletK 13.10.2015 CQ4961       
     if nvl(ln_home_Adres_cnt,0) = 0 and  nvl(ln_work_Adres_cnt,0) <> 0 then                                  
                l_homeAddress1          :=  l_workAddress1;                                      
                l_homeAddress2          :=  l_workAddress2;                                    
                l_homeAddress3          :=  l_workAddress3;                             
                l_homeCounty            :=  l_workCounty;       
                l_homeCityCode          :=  l_workCityCode;  
                l_homeCity              :=  l_workCity;            
                l_homePostalCode        :=  l_workPostalCode;             
                l_homeCountry           :=  l_workCountry;                              
                l_homePhoneCountryCode   :=  l_workPhoneCountryCode;       
                l_homePhoneRegionCode   :=  l_workPhoneRegionCode;           
                l_homePhone             :=  l_workPhone;                                      
                l_homeFaxRegionCode     :=  l_workFaxRegionCode;                  
                l_homeFax               :=  l_workFax;                                      
                l_mobilePhoneCountryCode :=  l_workMobilePhoneCountryCode;  
                l_mobilePhoneRegionCode :=  l_workMobilePhoneRegionCode;        
                l_mobilePhone           :=  l_workMobilePhone;                            
                l_foreignMobileCountryCode := l_workForeignMobileCountryCode;   
                l_foreignMobileRegionCode := l_workForeignMobileRegionCode;    
                l_foreignMobilePhone         := l_workForeignMobilePhone;               
     elsif nvl(ln_home_Adres_cnt,0) = 0 and  nvl(ln_work_Adres_cnt,0) = 0 and nvl(ln_contact_Adres_cnt,0) <> 0 then     
                l_homeEMail             :=  l_tempEmail;                        
                l_homeAddress1          :=  l_tempAddress1;                      
                l_homeAddress2          :=  l_tempAddress2;                   
                l_homeAddress3          :=  l_tempAddress3;                   
                l_homeCounty            :=  l_tempCounty;                     
                l_homeCityCode          :=  l_tempCityCode;                     
                l_homeCity              :=  l_tempCity;                      
                l_homePostalCode        :=  l_tempPostalCode;                    
                l_homeCountry           :=  l_tempCountry;       
                l_homePhoneCountryCode   :=  l_tempPhoneCountryCode;            
                l_homePhoneRegionCode   :=  l_tempPhoneRegionCode;               
                l_homePhone             :=  l_tempPhone;                   
                l_homeFaxRegionCode     :=  l_tempFaxRegionCode;                
                l_homeFax               :=  l_tempFax;                  
                l_mobilePhoneCountryCode :=  l_tempmobilePhoneCountryCode; 
                l_mobilePhoneRegionCode :=  l_tempmobilePhoneRegionCode;            
                l_mobilePhone           :=  l_tempmobilePhone;
                l_foreignMobileCountryCode := l_tempForeignMobileCountryCode;
                l_foreignMobileRegionCode := l_tempForeignMobileRegionCode;     
                l_foreignMobilePhone         := l_tempForeignMobilePhone;  
     end if;
-- E-O-M AdiletK 13.10.2015 CQ4961             
    
-- card account relation
--1.primary 
    ls_card_acccount_type:='PRIMARY';
  For  c_hesap in cur_hesap loop
        l_primaryaccountno            := c_hesap.accountno;                
        l_primaryaccountbranch        := c_hesap.accountbranch;              
        l_primaryaccountalias         := c_hesap.accountalias ;             
        l_primaryaccountcustomerid    := c_hesap.accountcustomerid;            
        l_primaryaccountnamesurname   := c_hesap.accountnamesurname ;            
        l_primaryaccountcurrency      := c_hesap.accountcurrency;            
        l_primaryaccounttype          := c_hesap.accounttype ;
        l_primaryexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
  end loop;

--2.seondary accounts 
    ln_indx_hesap := 0;
    ls_card_acccount_type:='SECONDARY';
    for  c_hesap in cur_hesap loop
        ln_indx_hesap := ln_indx_hesap +1 ;
        if  ln_indx_hesap = 1 then         
                l_firstaccountno            := c_hesap.accountno;                
                l_firstaccountbranch        := c_hesap.accountbranch;              
                l_firstaccountalias         := c_hesap.accountalias ;             
                l_firstaccountcustomerid    := c_hesap.accountcustomerid;            
                l_firstaccountnamesurname   := c_hesap.accountnamesurname ;            
                l_firstaccountcurrency      := c_hesap.accountcurrency;            
                l_firstaccounttype          := c_hesap.accounttype ;
                l_firstexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
         end if;
         if ln_indx_hesap = 2 then         
                l_secondaccountno           := c_hesap.accountno;                
                l_secondaccountbranch       := c_hesap.accountbranch;              
                l_secondaccountalias        := c_hesap.accountalias ;             
                l_secondaccountcustomerid   := c_hesap.accountcustomerid;            
                l_secondaccountnamesurname  := c_hesap.accountnamesurname ;            
                l_secondaccountcurrency     := c_hesap.accountcurrency;            
                l_secondaccounttype         := c_hesap.accounttype ;  
                l_secondexaccno             := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;

     if ln_indx_hesap = 3 then         
            l_thirdaccountno            := c_hesap.accountno;                
            l_thirdaccountbranch        := c_hesap.accountbranch;              
            l_thirdaccountalias         := c_hesap.accountalias ;             
            l_thirdaccountcustomerid    := c_hesap.accountcustomerid;            
            l_thirdaccountnamesurname   := c_hesap.accountnamesurname ;            
            l_thirdaccountcurrency      := c_hesap.accountcurrency;            
            l_thirdaccounttype          := c_hesap.accounttype ; 
            l_thirdexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno); --nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 4 then         
            l_fourthaccountno           := c_hesap.accountno;                
            l_fourthaccountbranch       := c_hesap.accountbranch;              
            l_fourthaccountalias        := c_hesap.accountalias ;             
            l_fourthaccountcustomerid   := c_hesap.accountcustomerid;            
            l_fourthaccountnamesurname  := c_hesap.accountnamesurname ;            
            l_fourthaccountcurrency     := c_hesap.accountcurrency;            
            l_fourthaccounttype         := c_hesap.accounttype ;  
            l_fourthexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 5 then         
            l_fifthaccountno            := c_hesap.accountno;                
            l_fifthaccountbranch        := c_hesap.accountbranch;              
            l_fifthaccountalias         := c_hesap.accountalias ;             
            l_fifthaccountcustomerid    := c_hesap.accountcustomerid;            
            l_fifthaccountnamesurname   := c_hesap.accountnamesurname ;            
            l_fifthaccountcurrency      := c_hesap.accountcurrency;            
            l_fifthaccounttype          := c_hesap.accounttype ;
            l_fifthexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 6 then         
            l_sixthaccountno            := c_hesap.accountno;                
            l_sixthaccountbranch        := c_hesap.accountbranch;              
            l_sixthaccountalias         := c_hesap.accountalias ;             
            l_sixthaccountcustomerid    := c_hesap.accountcustomerid;            
            l_sixthaccountnamesurname   := c_hesap.accountnamesurname ;            
            l_sixthaccountcurrency      := c_hesap.accountcurrency;            
            l_sixthaccounttype          := c_hesap.accounttype ;
            l_sixthexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 7 then         
            l_seventhaccountno          := c_hesap.accountno;                
            l_seventhaccountbranch      := c_hesap.accountbranch;              
            l_seventhaccountalias       := c_hesap.accountalias ;             
            l_seventhaccountcustomerid  := c_hesap.accountcustomerid;            
            l_seventhaccountnamesurname := c_hesap.accountnamesurname ;            
            l_seventhaccountcurrency    := c_hesap.accountcurrency;            
            l_seventhaccounttype        := c_hesap.accounttype ;
            l_seventhexaccno            := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 8 then         
            l_eightaccountno            := c_hesap.accountno;                
            l_eightaccountbranch        := c_hesap.accountbranch;              
            l_eightaccountalias         := c_hesap.accountalias ;             
            l_eightaccountcustomerid    := c_hesap.accountcustomerid;            
            l_eightaccountnamesurname   := c_hesap.accountnamesurname ;            
            l_eightaccountcurrency      := c_hesap.accountcurrency;            
            l_eightaccounttype          := c_hesap.accounttype ;
            l_eightexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
     if ln_indx_hesap = 9 then         
            l_ninthaccountno            := c_hesap.accountno;                
            l_ninthaccountbranch        := c_hesap.accountbranch;              
            l_ninthaccountalias         := c_hesap.accountalias ;             
            l_ninthaccountcustomerid    := c_hesap.accountcustomerid;            
            l_ninthaccountnamesurname   := c_hesap.accountnamesurname ;            
            l_ninthaccountcurrency      := c_hesap.accountcurrency;            
            l_ninthaccounttype          := c_hesap.accounttype ;
            l_ninthexaccno              := pkg_hesap.external_hesapno_al(c_hesap.accountno);--nurzalata CQDB5992 full and short account numbers
     end if;
  end loop;
  log_at('l_mobilePhone-2', l_mobilePhone,'l_primaryexaccno='||l_primaryexaccno);
  
  --BOM replaced control with table selection from updated cbs_card_styles table nurzalata 31052018 
  /*--Demir Noname Visa card issuing
  --BOM NoName card DNV style NurzalatA 30122017
    IF l_cardstyle = 'DNV' then
        ls_noname := 'Y';
    ELSE
      --BOM aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
        ls_noname := 'N';
      --EOM aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
     --end if;
    end if;
    --EOM NoName card DNV style NurzalatA 30122017*/
    --EOM replaced control with table selection from updated cbs_card_styles table nurzalata 31052018
    sp_ins_debit_Card_app_islem     (
                                        pn_app_id,
                                        pn_tx_no,    
                                        ls_record_type,
                                        pn_musteri_no,
                                        pn_multiple_tx_internal_no,
                                        ps_card_no,    
                                        pn_card_id_no,
                                        ps_debit_option,        
                                        pn_tx_no,     
                                        pn_tran_code,                        
                                        ps_response_code,        
                                        ps_response_desc,        
                                        ld_response_date,        
                                        ls_newcardno,        
                                        ls_newpanno,        
                                        l_CustomerNumber                        ,
                                        l_name                                  ,
                                        l_middleName                            ,
                                        l_surname                               ,
                                        l_title                                 ,
                                        l_embossName                            ,
                                        l_maidenSurname                         ,
                                        l_IDTypeEmployee                        ,
                                        l_BISerial                              ,
                                        l_BINumber                              ,
                                        l_driverLicense                         ,
                                        l_passport                              ,
                                        l_motherMaidenName                      ,
                                        l_dateOfBirth                           ,
                                        l_placeOfBirth                          ,
                                        l_sex                                   ,
                                        l_maritialStatus                        ,
                                        l_nationalityCode                       ,
                                        l_nationalityDesc                       ,
                                        l_motherName                            ,
                                        l_fatherName                            ,
                                        l_branchID                              ,
                                        l_taxNumber                             ,
                                        l_taxOffice                             ,
                                        l_workPlace                             ,
                                        l_position                              ,
                                        l_groupCode                             ,
                                        l_subGroupCode                          ,
                                        l_companyFlag                           ,
                                        l_companyNo                             ,
                                        l_companyName                           ,
                                        l_companyEmbossedName                   ,
                                        l_pinDeliveryType                       ,
                                        l_pinDeliveryAddress                    ,
                                        l_cardSendType                          ,
                                        l_cardSendAddress                       ,
                                        l_pinDeliveryBranch                     ,
                                        l_cardDeliveryBranch                    ,
                                        l_homeEMail                             ,
                                        l_homeAddress1                          ,
                                        l_homeAddress2                          ,
                                        l_homeAddress3                          ,
                                        l_homeCounty                            ,
                                        l_homeCityCode                          ,
                                        l_homeCity                              ,
                                        l_homePostalCode                        ,
                                        l_homeCountry                           ,
                                        l_homePhoneCountryCode                   , -- AdiletK 13.10.2015 CQ4961
                                        l_homePhoneRegionCode                   ,
                                        l_homePhone                             ,
                                        l_homeFaxRegionCode                     ,
                                        l_homeFax                               ,
                                        l_mobilePhoneCountryCode                 ,-- AdiletK 13.10.2015 CQ4961
                                        l_mobilePhoneRegionCode                 ,
                                        l_mobilePhone                           ,
                                        l_foreignMobileCountryCode        ,   -- AdiletK 13.10.2015 CQ4961 adding card style field             
                                        l_foreignMobileRegionCode           ,  -- AdiletK 13.10.2015 CQ4961      
                                        l_foreignMobilePhone                    , -- AdiletK 13.10.2015 CQ4961
                                        l_workAddress1                          ,
                                        l_workAddress2                          ,
                                        l_workAddress3                          ,
                                        l_workCounty                            ,
                                        l_workCityCode                          ,
                                        l_workCity                              ,
                                        l_workPostalCode                        ,
                                        l_workCountry                           ,
                                        l_workPhoneRegionCode                   ,
                                        l_workPhone                             ,
                                        l_workPhoneExtension                    ,
                                        l_workFaxRegionCode                     ,
                                        l_workFax                               ,
                                        l_workEmail                             ,
                                        l_requestingUserCode                    ,
                                        l_requestingTerminal                    ,
                                        l_tempActive                            ,
                                        l_tempType                              ,
                                        l_tempAddress1                          ,
                                        l_tempAddress2                          ,
                                        l_tempAddress3                          ,
                                        l_tempCounty                            ,
                                        l_tempCityCode                          ,
                                        l_tempCity                              ,
                                        l_tempPostalCode                        ,
                                        l_tempCountry                           ,
                                        l_tempPhoneRegionCode                   ,
                                        l_tempPhone                             ,
                                        l_tempPhoneExtension                    ,
                                        l_tempFaxRegionCode                     ,
                                        l_tempFax                               ,
                                        l_tempEmail                             ,
                                        l_createCardFlag                        ,
                                        l_BIN                                   ,
                                        l_embossPriority                        ,
                                        l_cardStyle                             ,
                                        l_primaryAccountNo                         ,
                                        l_primaryAccountBranch                     ,
                                        l_primaryAccountAlias                      ,
                                        l_primaryAccountCustomerId                 ,
                                        l_primaryAccountNameSurname                ,
                                        l_primaryAccountCurrency                   ,
                                        l_primaryAccountType                       ,
                                        l_firstAccountNo                           ,
                                        l_firstAccountBranch                       ,
                                        l_firstAccountAlias                        ,
                                        l_firstAccountCustomerId                   ,
                                        l_firstAccountNameSurname                  ,
                                        l_firstAccountCurrency                     ,
                                        l_firstAccountType                         ,
                                        l_secondAccountNo                          ,
                                        l_secondAccountBranch                      ,
                                        l_secondAccountAlias                       ,
                                        l_secondAccountCustomerId                  ,
                                        l_secondAccountNameSurname                 ,
                                        l_secondAccountCurrency                    ,
                                        l_secondAccountType                        ,
                                        l_thirdAccountNo                           ,
                                        l_thirdAccountBranch                       ,
                                        l_thirdAccountAlias                        ,
                                        l_thirdAccountCustomerId                   ,
                                        l_thirdAccountNameSurname                  ,
                                        l_thirdAccountCurrency                     ,
                                        l_thirdAccountType                         ,
                                        l_fourthAccountNo                          ,
                                        l_fourthAccountBranch                      ,
                                        l_fourthAccountAlias                       ,
                                        l_fourthAccountCustomerId                  ,
                                        l_fourthAccountNameSurname                 ,
                                        l_fourthAccountCurrency                    ,
                                        l_fourthAccountType                        ,
                                        l_fifthAccountNo                           ,
                                        l_fifthAccountBranch                       ,
                                        l_fifthAccountAlias                        ,
                                        l_fifthAccountCustomerId                   ,
                                        l_fifthAccountNameSurname                  ,
                                        l_fifthAccountCurrency                     ,
                                        l_fifthAccountType                         ,
                                        l_sixthAccountNo                           ,
                                        l_sixthAccountBranch                       ,
                                        l_sixthAccountAlias                        ,
                                        l_sixthAccountCustomerId                   ,
                                        l_sixthAccountNameSurname                  ,
                                        l_sixthAccountCurrency                     ,
                                        l_sixthAccountType                         ,
                                        l_seventhAccountNo                         ,
                                        l_seventhAccountBranch                     ,
                                        l_seventhAccountAlias                      ,
                                        l_seventhAccountCustomerId                 ,
                                        l_seventhAccountNameSurname                ,
                                        l_seventhAccountCurrency                   ,
                                        l_seventhAccountType                       ,
                                        l_eightAccountNo                           ,
                                        l_eightAccountBranch                       ,
                                        l_eightAccountAlias                        ,
                                        l_eightAccountCustomerId                   ,
                                        l_eightAccountNameSurname                  ,
                                        l_eightAccountCurrency                     ,
                                        l_eightAccountType                         ,
                                        l_ninthAccountNo                           ,
                                        l_ninthAccountBranch                       ,
                                        l_ninthAccountAlias                        ,
                                        l_ninthAccountCustomerId                   ,
                                        l_ninthAccountNameSurname                  ,
                                        l_ninthAccountCurrency                     ,
                                        l_ninthAccountType ,
                                        l_pseudopanno ,
                                        l_statuswillbeupdated ,
                                        l_newcardstatus,
                                        l_statuschangedesc 
                                        , ls_default_mobile_phone, ls_daily_cota_limit, ls_offline_permit   --CQ5510 MederT 28072016
                                        , ls_noname --aisuluud noname kompanion--NurzalatA CQDB5959 update due to method changes
                                        , ls_pin_print_flag--PINPrintFlag project NurzalatA 29122017 CQDB5981
                                        , l_primaryexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_firstexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_secondexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_thirdexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_fourthexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_fifthexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_sixthexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_seventhexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_eightexaccno--nurzalata CQDB5992 full and short account numbers
                                        , l_ninthexaccno--nurzalata CQDB5992 full and short account numbers
                                        );

-- call  BS webservices 
-- update after webservice 

-- webservis sonrasi application log tablosundaki carno,card_id_no alanlari guncellenmeli.
   if  ps_debit_option in('NEW CARD', 'NEW CARD WITH PIN','NEW CARD WITHOUT PIN','EXISTING CUSTOMER') then--CQDB5981 PINPrintFlag project NurzalatA added 'NEW CARD WITH PIN'
       -- pn_card_id_no  := PKG_GENEL.GENEL_KOD_AL('DEBIT_CARD_ID_NO');            --TEST AMACLIDIR SILECEMMM SEVAL
       -- ps_card_no :='417221'||'XXXXXX'||rpad(substr(pn_card_id_no ,1,4),4,'0');        --TEST AMACLIDIR             --TEST AMACLIDIR SILECEMMM SEVAL
        pkg_Debit_Card.sp_ws_dbinsertupdatecustomer(pn_app_id  ,
                                           ps_response_code ,        
                                           ps_response_desc ,
                                           ls_newcardno ,        
                                           ls_newpanno);
                                           
        --log_at ('SP_DCARD_INSERT_APP_CALL_WS',pn_app_id,ls_newcardno , ls_newpanno );                                            
        ls_newcardno := trim(ls_newcardno);
        ls_newpanno := trim(ls_newpanno);                                    
        ps_card_no   :=ls_newcardno;        
        pn_card_id_no:=ls_newpanno;                                           

   end if;

    if  ps_debit_option   = 'EXISTING CARD' then 
-- webservis sonrasi application log tablosundaki carno,card_id_no alanlari guncellenmeli.
         pkg_debit_card.sp_ws_dblinkaccountstocard(pn_app_id  ,
                                                   ps_response_code ,        
                                                   ps_response_desc );
                                                   log_at('dbcard2',pn_app_id,ps_response_code,ps_response_desc);
    end if;

    if  ps_debit_option   = 'CANCEL CARD' then 
-- webservis sonrasi application log tablosundaki carno,card_id_no alanlari guncellenmeli.
       pkg_Debit_Card.sp_WS_dbLinkAccountsToCard(pn_app_id  ,
                                                 ps_response_code ,        
                                                 ps_response_desc );
    end if;
    
  --Begin CQ1256 Debit card activation KonstantinJ 08.12.2014    
    if  ps_debit_option   = 'CARD ACTIVATION' then 
-- webservis sonrasi application log tablosundaki carno,card_id_no alanlari guncellenmeli.
       pkg_Debit_Card.sp_WS_dbLinkAccountsToCard(pn_app_id  ,
                                                 ps_response_code ,        
                                                 ps_response_desc );
    end if;
  --End CQ1256 Debit card activation KonstantinJ 08.12.2014    
  
  --BOM aisuluud CQ5754
    if  ps_debit_option   = 'BLOCKING CARD' then 
-- webservis sonrasi application log tablosundaki carno,card_id_no alanlari guncellenmeli.
       pkg_Debit_Card.sp_WS_dbLinkAccountsToCard(pn_app_id  ,
                                                 ps_response_code ,        
                                                 ps_response_desc );
    end if;
  --EOM aisuluud CQ5754  
    
        sp_upd_debit_Card_app_islem(ps_debit_option,
                                   pn_app_id  ,
                                   ps_response_code ,        
                                   ps_response_desc,    
                                   ls_newcardno,
                                   ls_newpanno  );

    
    ln_card_Adet := 0;
      if nvl(pn_tran_code,0) not in (2300,2304) and ps_debit_option  in ('EXISTING CARD','CANCEL CARD' ) then  
        select count(*)
        into ln_card_Adet
        from   cbs_debit_card
        where  customer_no = pn_musteri_no and
               card_no = ps_card_no and
               card_id_no =pn_card_id_no;
        
        if  nvl(ln_card_Adet,0) <> 0 then
         if  ps_debit_option = 'CANCEL CARD' then
                begin
                 update cbs_debit_card
                 set  status = 'K',   
                      closed_sys_date = sysdate,
                      closed_bank_date =pkg_baglam.bolum_kodu,
                      closed_by =  user 
                 where customer_no = pn_musteri_no and
                       card_no = ps_card_no and
                       card_id_no = pn_card_id_no ;
                    exception when others then null; 
                end ;
          end if;

         if  ps_debit_option = 'EXISTING CARD' then
            update cbs_debit_card
            set  --status = nvl(ps_status,'a') ,   
                      emboss_name_eng = ps_emboss_name_eng,
                      emboss_second_name_eng = ps_emboss_second_name_eng,
                      emboss_surname_eng = ps_emboss_surname_eng,
                      branch_code = ps_tx_branch_code                   
             where customer_no = pn_musteri_no and
                       card_no = ps_card_no and
                       card_id_no = pn_card_id_no ;
          end if;   

        end if;
     end if;

 Exception
    
    when adres_yok then
      log_at('SP_INSERT_APP_CALL_WS ERROR :ADDRESS IS NOT DEFINED',sqlcode,sqlerrm);
      raise_application_error(-20100,pkg_hata.getucpointer || '6707' || pkg_hata.getdelimiter ||'Customer No:'||pn_musteri_no|| pkg_hata.getdelimiter || pkg_hata.getucpointer);
    when others then
      log_at('SP_INSERT_APP_CALL_WS ERROR',sqlcode,sqlerrm ,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);--aisuluud cq5550 added DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
      raise_application_error(-20100,pkg_hata.getucpointer || '6697' || pkg_hata.getdelimiter ||'Customer No:'||pn_musteri_no||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);

  End;
--------------------------------------------------------------------------------------------
 Function sf_tel_alan_kod_formatli(ps_tel_alan_kod varchar2  ) return varchar2
  IS
    ls_tel_alan_kod    varchar2(100) :=trim(ps_tel_alan_kod);
    ls_return varchar2(3):= null;
  BEGIN
--(90 212)
    if length(ls_tel_alan_kod) <= 3 and sf_is_number(ls_tel_alan_kod) = 1 then 
          ls_return :=  substr(  ls_tel_alan_kod,1,3);
    else
        ls_tel_alan_kod:= trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace( replace(ls_tel_alan_kod,'+90'),'(90)'),'(90') ,'+99'),'(99)'),'(99'),'('),')'),'+'),'.'),'.'),'-'),'/'),'\'),':'));
        if substr(ls_tel_alan_kod,1,1) = '0' then 
            ls_tel_alan_kod := substr(ls_tel_alan_kod,2);
             if substr(ls_tel_alan_kod,1,1) = '0' then 
                 ls_tel_alan_kod := substr(ls_tel_alan_kod,2);
            end if; 
        end if;

        if length(ls_tel_alan_kod) <= 3 and sf_is_number(ls_tel_alan_kod) = 1 then
            ls_return := substr(ls_tel_alan_kod,1,3);
        end if;
       
    end if;

    RETURN ls_return ;

  EXCEPTION
      WHEN OTHERS THEN return null;
      
  END;
--------------------------------------------------------------------------------------------
 Function sf_tel_alan_no_formatli(ps_tel_alan_no varchar2 ) return varchar2
  IS
    ls_tel_alan_no    varchar2(100) :=trim(ps_tel_alan_no);
    ln_length number := 6;
    ls_return varchar2(20):= null;
    
  BEGIN

    if length(ls_tel_alan_no) <= ln_length and sf_is_number(ls_tel_alan_no) = 1 then 
          ls_return :=  substr(  ls_tel_alan_no,1,ln_length);
    else
        ls_tel_alan_no:= trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace( replace(ls_tel_alan_no,'+90'),'(90)'),'(90') ,'+99'),'(99)'),'(99'),'('),')'),'+'),'.'),'.'),'-'),'/'),'\'),':'));
        if substr(ls_tel_alan_no,1,1) = '0' then 
            ls_tel_alan_no := substr(ls_tel_alan_no,2);
             if substr(ls_tel_alan_no,1,1) = '0' then 
                 ls_tel_alan_no := substr(ls_tel_alan_no,2);
            end if; 
        end if;

        if length(ls_tel_alan_no) <= ln_length and sf_is_number(ls_tel_alan_no) = 1 then
            ls_return := substr(ls_tel_alan_no,1,ln_length);
        end if;
       
    end if;

    RETURN ls_return ;

  EXCEPTION
      WHEN OTHERS THEN 
    log_At('sf_tel_alan_no_formatli-hata',sqlcode,sqlerrm);
    return null;
      
  END;

-------------------------------------------
function sf_bs_city_code(ps_cbs_il_kodu varchar2  ) return varchar2
is
 ls_bs_city_code varchar2(10);   
begin
    select bs_city_code
    into ls_bs_city_code
    from cbs_il_kodlari
    where il_kodu = ps_cbs_il_kodu;
    
    return ls_bs_city_code;

exception when others then return null;

end;
--------------------------------------------------------------------------------------------
 FUNCTION  Sf_emboss_full_name( ps_emboss_name varchar2 ,ps_emboss_second_name varchar2 ,ps_surname varchar2 ) RETURN VARCHAR2
  IS
    ls_musteri_adi      VARCHAR2(200) := NULL;
  BEGIN
     if trim(ps_emboss_second_name) is null then 
      ls_musteri_adi:= trim( trim(ps_emboss_name) || ' '|| trim(ps_surname)) ;
    else
      ls_musteri_adi:= trim(trim(ps_emboss_name) || ' '|| trim(ps_emboss_second_name) ||' '|| trim(ps_surname)) ;
    end if;

    RETURN UPPER(trim(ls_musteri_adi)) ;

  EXCEPTION
    WHEN  OTHERS THEN return null;
        
  END;
--------------------------------------------------------------------------------------------
Procedure sp_contact_name_parse_et (ps_contact_name varchar2, ps_isim out varchar2 ,ps_ikinci_isim out varchar2 ,ps_soyadi out varchar2  ) 
is
   ls_isim2  cbs_musteri.lokal_unvan%type;
   ls_isim3  cbs_musteri.lokal_unvan%type;
   ls_isim4   cbs_musteri.lokal_unvan%type;
   ls_isim5   cbs_musteri.lokal_unvan%type;
   ps_delimeter  varchar2(1) :=  ' ';
   ls_lokal_unvan       cbs_musteri.lokal_unvan%type;
    
   BEGIN
    ls_lokal_unvan:= upper(trim(replace(ps_contact_name,'  ',' ')));
    
    ps_isim := trim(pkg_message.Split( ls_lokal_unvan   ,ps_delimeter,0));
    ls_isim2 := trim(pkg_message.Split( ls_lokal_unvan   ,ps_delimeter,1 ));
    ls_isim3 := trim(pkg_message.Split( ls_lokal_unvan   ,ps_delimeter,2 ));
    ls_isim4 := trim(pkg_message.Split( ls_lokal_unvan   ,ps_delimeter,3 ));  --exceptionalcustomers
    ls_isim5 := trim(pkg_message.Split( ls_lokal_unvan   ,ps_delimeter,4 ));  --exceptionalcustomers

        if ls_isim3 is not null then 
            ps_ikinci_isim := ls_isim2;
            ps_soyadi := trim(replace( ls_lokal_unvan,ps_isim ||' '|| ls_isim2) );
            if ps_soyadi is not null then 
                 ps_ikinci_isim := ls_isim2;                
            else
                 ps_ikinci_isim := null;
                 ps_soyadi   :=ls_isim2;
            end if;
      
        else
            ps_ikinci_isim:= null;
            ps_soyadi := trim(ls_isim2);
        end if;

    EXCEPTION
      WHEN OTHERS THEN 
        log_At('sp_contact_name_parse_et hata',sqlcode,sqlerrm);
            ps_isim:= substr(trim(ps_contact_name),1,20);
            ps_soyadi:= substr(trim(ps_contact_name),21,20);
        null;
     END ;
--------------------------------------------------------------------------------------------
  FUNCTION  sf_activity_adi( ps_activity_code  varchar2 ) RETURN VARCHAR2
  IS
    ls_sektor_adi      CBS_finans_KODLARI.ACIKLAMA%TYPE;
  BEGIN
    SELECT SUBSTR(ACIKLAMA,1,200)   
    INTO   ls_sektor_adi
    FROM   CBS_finans_KODLARI
    WHERE  finans_kodu =ps_activity_code  ;
    RETURN ls_sektor_adi ;

  EXCEPTION       
      WHEN OTHERS THEN
         return null;
  END;
--------------------------------------------------------------------------------------------
procedure sp_WS_dbInsertUpdateCompanyInf(pn_app_id number ,
                                           ps_response_code out varchar2 ,        
                                           ps_response_desc out varchar2   
)is pragma autonomous_transaction;

cursor cur_app is
 select * from cbs_salary_firm_app_islem
 where app_id = pn_app_id;
 
 r_app cur_App%rowtype;

 serviceUrl VARCHAR2(2000);
 soapAction VARCHAR2(2000);
 namespace VARCHAR2(2000);
 methodName VARCHAR2(2000);
 req Pkg_Soap.request;
 resp Pkg_Soap.response;
 result CLOB;--NVARCHAR2(32767);
 referenceId INTEGER;

 l_parser  dbms_xmlparser.Parser;
 l_doc     dbms_xmldom.DOMDocument;
 l_nl      dbms_xmldom.DOMNodeList;
 l_n       dbms_xmldom.DOMNode;

 ld_starttime DATE;
 ld_endtime DATE;

 ls_BS_WS_SERVICE_URL VARCHAR2(200) ;-- := 'http://10.0.0.43/WebService/DBWS.asmx'; test 
 
 --BOM aisuluud cq5800 add header
 ls_header_method VARCHAR2(256);
 ls_header_user VARCHAR2(256);
 ls_header_pass VARCHAR2(256);
 --EOM aisuluud cq5800 add header
 
BEGIN
 
 pkg_parametre.deger('BS_WS_SERVICE_URL',ls_BS_WS_SERVICE_URL);
 
for c_app in cur_app loop
    r_app :=c_app;
end loop;

 ld_starttime:=SYSDATE;

 serviceUrl :=ls_BS_WS_SERVICE_URL;
 namespace := 'http://www.banksoft.com.tr';
 methodName := 'dbInsertUpdateCompanyInfo';
 soapAction := namespace || '/DBWS/' || methodName;
 namespace := 'xmlns="' || namespace || '"';

req := Pkg_Soap.new_request(methodName, namespace);

--BOM aisuluud cq5800 add header
 pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
 pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
 ls_header_method := 'UserCredentials';
 PKG_SOAP.NEW_HEADER(req, ls_header_method,
 '<userName>' || ls_header_user || '</userName>' ||
 '<password>' || ls_header_pass || '</password>');
 --EOM aisuluud cq5800 add header
 
 Pkg_Soap.add_parameter(
  req, 'app', NULL,
'<InsertUpdate xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.record_type || ']]></InsertUpdate>' ||
'<companyNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyNo || ']]></companyNo>' ||
'<companyName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyName || ']]></companyName>' ||
'<authorizedTitle xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.authorizedTitle || ']]></authorizedTitle>' ||
'<authorizedFirstName xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.authorizedFirstName || ']]></authorizedFirstName>' ||
'<authorizedSurname xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.authorizedSurname || ']]></authorizedSurname>' ||
'<companyActivityField xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyActivityField || ']]></companyActivityField>' ||
'<companyAddress1 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyAddress1 || ']]></companyAddress1>' ||
'<companyAddress2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyAddress2 || ']]></companyAddress2>' ||
'<companyAddress3 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyAddress3 || ']]></companyAddress3>' ||
'<companyCounty xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyCounty || ']]></companyCounty>' ||
'<companyCityCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyCityCode || ']]></companyCityCode>' ||
'<companyCity xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyCity || ']]></companyCity>' ||
'<companyPostalCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyPostalCode || ']]></companyPostalCode>' ||
'<companyCountry xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyCountry || ']]></companyCountry>' ||
'<companyPhoneRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyPhoneRegionCode || ']]></companyPhoneRegionCode>' ||
'<companyPhone xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyPhone || ']]></companyPhone>' ||
'<companyPhoneRegionCode2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyPhoneRegionCode2 || ']]></companyPhoneRegionCode2>' ||
'<companyPhone2 xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyPhone2 || ']]></companyPhone2>' ||
'<companyFaxRegionCode xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyFaxRegionCode || ']]></companyFaxRegionCode>' ||
'<companyFax xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyFax || ']]></companyFax>' ||
'<companyEMail xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyEMail || ']]></companyEMail>' ||
'<requestingUserId xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.requestingUserId || ']]></requestingUserId>' ||
'<companyValid xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyValid || ']]></companyValid>' ||
'<companyAccountNo xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyAccountNo || ']]></companyAccountNo>' ||
'<companyYearlyFeeDate xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyYearlyFeeDate || ']]></companyYearlyFeeDate>' ||
'<companyFeePeriod xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoInput"><![CDATA['|| r_app.companyFeePeriod || ']]></companyFeePeriod>' );

 resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
 result := resp.doc.getstringval();

 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/DBWS/dbInsertUpdateCompanyInfoResult"','');
 l_parser := dbms_xmlparser.newParser;

 dbms_xmlparser.parseclob(l_parser, result);
 l_doc := dbms_xmlparser.getDocument(l_parser);

 l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'dbInsertUpdateCompanyInfoResponse/dbInsertUpdateCompanyInfoResult');

 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
  l_n := dbms_xmldom.item(l_nl, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n,'responseCode/text()',ps_response_Code);
  dbms_xslprocessor.valueOf(l_n,'responseCodeDesc/text()',ps_response_Desc);


 END LOOP;

 ld_endtime:=SYSDATE;

 Pkg_debit_Card.WS_LOG('SALARY FIRM',serviceUrl,methodName,ld_starttime,ld_endtime,ps_response_Code,NULL,r_app.ref_tx_no,pn_app_id,result,REQ.BODY); --SEVALB 14052013 '000' replaced with ps_response_Code
 log_at('debitWs_header',req.header);--aisuluud cq 5800 add header logs
  commit;  

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   ps_response_Code:= '999';
   ps_response_Desc := sqlcode||' '||sqlerrm ; 
   Pkg_debit_Card.WS_LOG('SALARY FIRM',serviceUrl,methodName,ld_starttime,ld_endtime,'999',sqlcode||' '||sqlerrm,r_app.ref_tx_no,pn_app_id,result,REQ.BODY);
   log_at('debitWs_header_error',req.header);--aisuluud cq 5800 add header logs
END;
--------------------------------------------------------
procedure sp_ins_salary_firm_app_islem 
  (             pn_app_id                    NUMBER,
                pn_firm_customer_no          NUMBER,
                pn_firm_id                   NUMBER  ,
                PS_record_type               VARCHAR2,
                P_companyno                  VARCHAR2 DEFAULT NULL,
                P_companyname                VARCHAR2 DEFAULT NULL,
                P_authorizedtitle            VARCHAR2 DEFAULT NULL,
                P_authorizedfirstname        VARCHAR2 DEFAULT NULL,
                P_authorizedsurname          VARCHAR2 DEFAULT NULL,
                P_companyactivityfield       VARCHAR2 DEFAULT NULL,
                P_companyaddress1            VARCHAR2 DEFAULT NULL,
                P_companyaddress2            VARCHAR2 DEFAULT NULL,
                P_companyaddress3            VARCHAR2 DEFAULT NULL,          
                P_companycounty              VARCHAR2 DEFAULT NULL,
                P_companycitycode            VARCHAR2 DEFAULT NULL,
                P_companycity                VARCHAR2 DEFAULT NULL,
                P_companypostalcode          VARCHAR2 DEFAULT NULL,   
                P_companycountry             VARCHAR2 DEFAULT NULL,   
                P_companyphoneregioncode     VARCHAR2 DEFAULT NULL,
                P_companyphone               VARCHAR2 DEFAULT NULL,
                P_companyphoneregioncode2    VARCHAR2 DEFAULT NULL,
                P_companyphone2              VARCHAR2 DEFAULT NULL,
                P_companyfaxregioncode       VARCHAR2 DEFAULT NULL,
                P_companyfax                 VARCHAR2 DEFAULT NULL,
                P_companyemail               VARCHAR2 DEFAULT NULL,
                P_requestinguserid           VARCHAR2 DEFAULT NULL,
                P_companyvalid               VARCHAR2 DEFAULT NULL,
                P_companyaccountno           VARCHAR2 DEFAULT NULL,   
                P_companyyearlyfeedate       VARCHAR2 DEFAULT NULL,
                P_companyfeeperiod           VARCHAR2 DEFAULT NULL,
                pn_tx_no                     NUMBER DEFAULT NULL)
 is pragma autonomous_transaction;
    
Begin
       insert into cbs_salary_firm_app_islem
                        (   app_id    ,
                            firm_customer_no    ,
                            firm_id    ,
                            record_type    ,
                            companyNo    ,
                            companyName    ,
                            authorizedTitle    ,
                            authorizedFirstName    ,
                            authorizedSurname    ,
                            companyActivityField    ,
                            companyAddress1    ,
                            companyAddress2    ,
                            companyAddress3    ,
                            companyCounty    ,
                            companyCityCode    ,
                            companyCity    ,
                            companyPostalCode    ,
                            companyCountry    ,
                            companyPhoneRegionCode    ,
                            companyPhone    ,
                            companyPhoneRegionCode2    ,
                            companyPhone2    ,
                            companyFaxRegionCode    ,
                            companyFax    ,
                            companyEMail    ,
                            requestingUserId    ,
                            companyValid    ,
                            companyAccountNo    ,
                            companyYearlyFeeDate    ,
                            companyfeeperiod    ,                          
                            ref_tx_no    )
            values
            (
                                pn_app_id                     ,
                                pn_firm_customer_no    ,
                                pn_firm_id    ,
                                PS_record_type    ,
                                P_companyno    ,
                                P_companyname    ,
                                P_authorizedtitle    ,
                                P_authorizedfirstname    ,
                                P_authorizedsurname    ,
                                P_companyactivityfield    ,
                                P_companyaddress1    ,
                                P_companyaddress2    ,
                                P_companyaddress3    ,
                                P_companycounty    ,
                                P_companycitycode    ,
                                P_companycity    ,
                                P_companypostalcode    ,
                                P_companycountry    ,
                                P_companyphoneregioncode    ,
                                P_companyphone    ,
                                P_companyphoneregioncode2    ,
                                P_companyphone2    ,
                                P_companyfaxregioncode    ,
                                P_companyfax    ,
                                P_companyemail    ,
                                P_requestinguserid    ,
                                P_companyvalid    ,
                                P_companyaccountno    ,
                                P_companyyearlyfeedate    ,
                                P_companyfeeperiod    ,                             
                                pn_tx_no   );
    commit;

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   log_At('SP_INS_SALARY_FIRM_APP_ISLEM-ERROR',pn_app_id, sqlcode||' '||sqlerrm ); 
   raise_application_error(-20100,pkg_hata.getucpointer || '6698' || pkg_hata.getdelimiter ||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
End;
--------------------------------------------------------
procedure sp_upd_salary_firm_app_islem(pn_app_id number ,
                                       ps_response_code  varchar2 ,        
                                       ps_response_desc  varchar2   
)is pragma autonomous_transaction;
Begin
    update cbs_salary_firm_app_islem
    set response_code = ps_response_code,
        response_desc = ps_response_desc,
        response_date  =sysdate
    where app_id = pn_app_id;
    commit;
EXCEPTION
 WHEN OTHERS THEN
   rollback;
   log_At('SP_UPD_SALARY_FIRM_APP_ISLEM-ERROR',pn_app_id, sqlcode||' '||sqlerrm );
End;

procedure SP_SFIRM_INSERT_APP_CALL_WS( pn_firm_customer_no number ,
                                       pn_firm_id       number,
                                       ps_bscompany_no  number default null, 
                                       ps_insert_update_recordtype varchar2 default null, 
                                       ps_contact_name varchar2 default null,
                                       pn_annual_fee_rate number default null,
                                       pn_tx_no number default null,                                    
                                       pn_app_id out number,
                                       ps_response_code out varchar2 ,
                                       ps_response_desc out varchar2                                  
                                       ) 
 is
    l_InsertUpdate                   varchar2(1);
    l_companyNo                      number;
    l_companyName                    varchar2(40);
    l_authorizedTitle                varchar2(20);
    l_authorizedFirstName            varchar2(20);
    l_authorizedSurname              varchar2(20);
    l_companyActivityField           varchar2(40);
    l_companyAddress1                varchar2(40);
    l_companyAddress2                varchar2(40);
    l_companyAddress3                varchar2(40);
    l_companyCounty                  varchar2(20);
    l_companyCityCode                varchar2(3);
    l_companyCity                    varchar2(20);
    l_companyPostalCode              varchar2(8);
    l_companyCountry                 varchar2(20);
    l_companyPhoneRegionCode         varchar2(3);
    l_companyPhone                   varchar2(6);
    l_companyPhoneRegionCode2        varchar2(3);
    l_companyPhone2                  varchar2(6);
    l_companyFaxRegionCode           varchar2(3);
    l_companyFax                     varchar2(6);
    l_companyEMail                   varchar2(40);
    l_requestingUserId               varchar2(8) := nvl(substr(user,1,8),' ');
    l_companyValid                   varchar2(1);
    l_companyAccountNo               varchar2(18);
    l_companyYearlyFeeDate           varchar2(4);
    l_companyFeePeriod               varchar2(1);
 
    ln_adet number          := 0;
    ls_record_type          varchar2(1);
      ld_response_date        date :=sysdate;       
    ls_isim      varchar2(200);
    ls_ikinci_isim      varchar2(200);
    ls_soyadi      varchar2(200);   
    
    cursor cur_Adres is
      select    
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),1,40)) companyaddress1,  
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),41,40)) companyaddress2,     
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(adres)),' '),81,40)) companyaddress3,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT('KG')),' '),1,25)) companycounty, -- AdiletK 13.10.2015 CQ4961
          upper(substr(nvl(trim(pkg_debit_Card.sf_bs_city_code(il_kod)),' '),1,2)) companycitycode ,--map edilecek
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.sehir_adi_al_hatasiz(il_kod))),' '),1,25)) companycity, --map edilecek
          substr(nvl(trim(pkg_Debit_card.CYR2LAT(posta_kod)),' '),1,8) companypostalcode,
          upper(substr(nvl(trim(pkg_Debit_card.CYR2LAT(pkg_genel.ulke_adi_al_hatasiz(ulke_kod))),' '),1,25)) companycountry,
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(tel_alan_kod),1,3) companyphoneregioncode,
          substr(pkg_debit_Card.sf_tel_alan_no_formatli(tel_no),1,6) companyphone,
          ' ' companyPhoneRegionCode2,    
          ' ' companyPhone2 ,
          substr(pkg_debit_Card.sf_tel_alan_kod_formatli(fax_alan_kod),1,3) companyfaxregioncode,                       
          substr(pkg_debit_Card.sf_tel_alan_no_formatli(fax_no),1,6) companyfax,
          '' companyemail               -- AdiletK 13.10.2015 CQ4961        
       from cbs_musteri_Adres
       where musteri_no = pn_firm_customer_no 
       order by adres_kod desc; 
    
        r_adres cur_Adres%rowtype;
Begin
   --0. initial parameters
  pn_app_id :=pkg_genel.genel_kod_al('CBS_SALARY_FIRM_APP');
  l_companyValid := 'Y';               
  l_companyAccountNo := ' ';           
  l_companyYearlyFeeDate := ' ';

   if nvl(pn_annual_fee_rate,0)<> 0 then        
        l_companyFeePeriod := 'Y';
        l_companyYearlyFeeDate := '1299';
   else
        l_companyFeePeriod := 'N';
        l_companyYearlyFeeDate:=' ';
   end if;                     

  if   ps_insert_update_recordtype is null  then    
    select count(*)
    into ln_adet   
    from cbs_salary_payment_firm_def 
    where firm_no = pn_firm_customer_no and
          firm_id = pn_firm_id  ;

      if nvl(ln_adet,0) <> 0 then 
            ls_record_type := 'U';
      else
            ls_record_type := 'I';
      end if; 
   else
      ls_record_type :=  ps_insert_update_recordtype ;
  end if;   

  if  ps_bscompany_no is null then
       l_companyno:= substr(pn_firm_id,1,8);
    else
       l_companyno:= substr(ps_bscompany_no,1,8);
  end if;   
    
     
    if trim(ps_contact_name) is not null then 
        pkg_Debit_Card.sp_contact_name_parse_et (pkg_Debit_card.CYR2LAT(ps_contact_name) , ls_isim   ,ls_ikinci_isim   ,ls_soyadi );
        if trim(ls_isim) is  null and ls_soyadi is null then  
            ls_isim := substr(pkg_Debit_card.CYR2LAT(ps_contact_name),1,20);
            ls_soyadi := substr(pkg_Debit_card.CYR2LAT(ps_contact_name),21,20);
        end if;
    end if;

-- B-O-M AdiletK 13.10.2015 CQ4961 authorized personel uploading
/*
   --1. customer information 
    select 
         --substr(a.musteri_no,1,8)   companyNo ,
         upper(substr(nvl(pkg_Debit_card.CYR2LAT(pkg_musteri.Sf_Musteri_Eng_Adi(musteri_no)),' '),1,40))  companyname ,
        ' ' authorizedTitle ,
         upper(substr(nvl(pkg_Debit_card.CYR2LAT(ls_isim ||' '||ls_ikinci_isim),' '),1,20))    authorizedFirstName,
         upper(substr(nvl(pkg_Debit_card.CYR2LAT(ls_soyadi),' '),1,20))    authorizedSurname,
         upper(substr(nvl(pkg_Debit_card.CYR2LAT(sf_activity_adi(FINANS_KOD)),' '),1,40))     companyActivityField
    into 
       --   l_companyno    ,
          l_companyname    ,
          l_authorizedtitle    ,
          l_authorizedfirstname    ,
          l_authorizedsurname    ,
          l_companyactivityfield             
    from cbs_musteri a
    where a.musteri_no = pn_firm_customer_no;
*/    

    select 
        upper(substr(nvl(pkg_Debit_card.CYR2LAT(pkg_musteri.Sf_Musteri_Eng_Adi(musteri_no)),' '),1,40))  companyname ,
        upper(substr(nvl(pkg_Debit_card.CYR2LAT(r.tanim),' '),1,20))  authorizedTitle,
        upper(substr(nvl(pkg_Debit_card.CYR2LAT(k.adi),' '),1,20))    authorizedFirstName,
        upper(substr(nvl(pkg_Debit_card.CYR2LAT(k.soyadi),' '),1,20))    authorizedSurname,         
        upper(substr(nvl(pkg_Debit_card.CYR2LAT(sf_activity_adi(FINANS_KOD)),' '),1,40))     companyActivityField
    into
         l_companyname    ,
         l_authorizedtitle    ,
         l_authorizedfirstname    ,
         l_authorizedsurname    ,
         l_companyactivityfield      
    from cbs_musteri m
    left join cbs_kullanici k
    on k.personel_numara = m.pazarlama_sorumlusu_sicil_no_1 or 
         k.personel_numara = m.pazarlama_sorumlusu_sicil_no_2
    left join cbs_erisim_rol e
    on k.kodu = e.erisim_kullanici_kodu and 
        k.calisilan_bolum = e.bolum_kodu
    left join cbs_rol r
    on r.numara = e.rol_numara 
    where m.musteri_no = pn_firm_customer_no and
              rownum = 1
    order by e.yaratildigi_tarih;
-- E-O-M AdiletK 13.10.2015 CQ4961 authorized personel uploading

   --2. adress information 
  Begin  

      open cur_adres;
      fetch cur_adres   
      into 
                l_companyaddress1   ,                   
                l_companyaddress2    ,                  
                l_companyaddress3    ,                  
                l_companycounty      ,                  
                l_companycitycode    ,                  
                l_companycity        ,                  
                l_companypostalcode  ,                  
                l_companycountry     ,                  
                l_companyphoneregioncode,               
                l_companyphone          ,
                l_companyphoneregioncode2,               
                l_companyphone2          ,              
                l_companyfaxregioncode  ,  
                l_companyfax            ,               
                l_companyemail ; 
       close cur_adres;

     exception when others then null;
     End;       

        sp_ins_salary_firm_app_islem(
                pn_app_id    ,
                pn_firm_customer_no    ,
                pn_firm_id    ,
                ls_record_type    ,
                l_companyno    ,
                l_companyname    ,
                l_authorizedtitle    ,
                l_authorizedfirstname    ,
                l_authorizedsurname    ,
                l_companyactivityfield    ,
                l_companyaddress1    ,
                l_companyaddress2    ,
                l_companyaddress3    ,
                l_companycounty    ,
                l_companycitycode    ,
                l_companycity    ,
                l_companypostalcode    ,
                l_companycountry    ,
                l_companyphoneregioncode    ,
                l_companyphone    ,
                l_companyphoneregioncode2    ,
                l_companyphone2    ,
                l_companyfaxregioncode    ,
                l_companyfax    ,
                l_companyemail    ,
                l_requestinguserid    ,
                l_companyvalid    ,
                l_companyaccountno    ,
                l_companyyearlyfeedate    ,
                l_companyfeeperiod    ,
                pn_tx_no    );

    sp_ws_dbinsertupdatecompanyinf(pn_app_id  ,
                                   ps_response_code ,        
                                   ps_response_desc);

    sp_upd_salary_firm_app_islem(pn_app_id  ,
                                   ps_response_code ,        
                                   ps_response_desc);

  Exception
    when others then
      log_at('SP_INSERT_SALARY_APP_ISLEM ERROR',sqlcode,sqlerrm);
      raise_application_error(-20100,pkg_hata.getucpointer || '6703' || pkg_hata.getdelimiter ||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);

End;
--------------------------------------------------------
Function sf_salary_firm_musteri_mi(pn_musteri_no number  ) return varchar2
is
 ln_adet number := 0;
Begin

    select count(*)
    into ln_adet
    from  cbs_salary_payment_firm_def
    where firm_no = pn_musteri_no and
          STATUS = 'A'; --AntonPa 150223

    if nvl(ln_adet,0) <> 0 then
      return 'E';
    else
        return 'H';
    end if;

Exception when others then return 'H';
End;
--------------------------------------------------------
Function sf_salary_firm_id_al(pn_musteri_no number  ) return number
is
 ln_firm_id number ;
Begin

    select firm_id
    into   ln_firm_id
    from  cbs_salary_payment_firm_def
    where firm_no = pn_musteri_no;

    return ln_firm_id;

Exception when others then return null;
End;
--------------------------------------------------------
function sf_salary_bscompany_no_al(pn_musteri_no number  ) return number
is
 ln_bs_companyno number ;
begin

    select max(bs_companyno)
    into   ln_bs_companyno
    from  cbs_salary_payment_firm_def
    where firm_no = pn_musteri_no;

    return ln_bs_companyno;

exception when others then return null;
End;
--------------------------------------------------------
FUNCTION  bs_card_statu_code_Exp( ps_code varchar2 ) RETURN VARCHAR2
  IS
    ls_EXPLANATION      VARCHAR2(200);
  BEGIN
    SELECT EXPLANATION
    INTO   ls_EXPLANATION
    FROM   CBS_BS_CARD_STATU_CODE
    WHERE  STATU_CODE =ps_code  ;

    RETURN ls_EXPLANATION ;

  EXCEPTION
      WHEN OTHERS THEN return null;
      
  END;

--------------------------------------------------------
FUNCTION  bs_card_statu_valid( ps_code varchar2 ) RETURN VARCHAR2
  IS
    LS_VALID      VARCHAR2(1);
  BEGIN
    SELECT VALID
    INTO   LS_VALID
    FROM   CBS_BS_CARD_STATU_CODE
    WHERE  STATU_CODE =ps_code  ;

    RETURN LS_VALID ;

  EXCEPTION
      WHEN OTHERS THEN return 'N';
      
  END;
--------------------------------------------------------
FUNCTION CYR2LAT(STRING VARCHAR2) RETURN VARCHAR2
IS
  CH                      VARCHAR2(2);
  D_CH                    VARCHAR2(4);--transliteration standard update (2013)ICAO NurzalatA CQDB5912 (2) 
  D_STRING                VARCHAR2(1000);
BEGIN
     D_STRING := '';
     if STRING is not null
     then
         FOR I IN 1 .. LENGTH(STRING) LOOP
             CH := SUBSTR(UPPER(STRING), I, 1);
             SELECT  
                     CASE WHEN CH = 'А' THEN 'A'
                          WHEN CH = 'Б' THEN 'B'
                          WHEN CH = 'В' THEN 'V'
                          WHEN CH = 'Г' THEN 'G'
                          WHEN CH = 'Д' THEN 'D'
                          WHEN CH = 'Е' THEN 'E'
                          WHEN CH = 'Ё' THEN 'E'--WHEN CH = 'Ё' THEN 'YO' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ж' THEN 'ZH'--WHEN CH = 'Ж' THEN 'J' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'З' THEN 'Z'
                          WHEN CH = 'И' THEN 'I'
                          WHEN CH = 'Й' THEN 'I'--WHEN CH = 'Й' THEN 'Y' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'К' THEN 'K'
                          WHEN CH = 'Л' THEN 'L'
                          WHEN CH = 'М' THEN 'M'
                          WHEN CH = 'Н' THEN 'N'
                          WHEN CH = 'О' THEN 'O'
                          WHEN CH = 'П' THEN 'P'
                          WHEN CH = 'Р' THEN 'R'
                          WHEN CH = 'С' THEN 'S'
                          WHEN CH = 'Т' THEN 'T'
                          WHEN CH = 'У' THEN 'U'
                          WHEN CH = 'Ф' THEN 'F'
                          WHEN CH = 'Х' THEN 'KH'--WHEN CH = 'Х' THEN 'H' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ц' THEN 'TS'
                          WHEN CH = 'Ч' THEN 'CH'
                          WHEN CH = 'Ш' THEN 'SH'--WHEN CH = 'Ш' OR CH = 'Щ' THEN 'SH' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Щ' THEN 'SHCH'--WHEN CH = 'Ш' OR CH = 'Щ' THEN 'SH' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ъ' THEN 'IE'--WHEN CH = 'Ь' OR CH = 'Ъ' THEN '' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ы' THEN 'Y'
                          WHEN CH = 'Ь' THEN ''--WHEN CH = 'Ь' OR CH = 'Ъ' THEN '' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Э' THEN 'E'
                          WHEN CH = 'Ю' THEN 'IU'--WHEN CH = 'Ю' THEN 'YU' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Я' THEN 'IA'--WHEN CH = 'Я' THEN 'YA' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          ELSE CH
                     END CHR
             INTO D_CH FROM DUAL;
             D_STRING := D_STRING || D_CH;
         END LOOP;
     END if;
     RETURN D_STRING;
exception
  when others then
  log_at('PKG_DEBIT_CARD_CYR2LAT_ERR','STRING',STRING);
END;

/******************************************************************************
 NAME : FUNCTION SP_WS_GetDebitCard_info
 Prepared By : Konstantin Zhukov
 Date : 09.12.2014
 Purpose : Function Calls web service and return Debit card information
******************************************************************************/
FUNCTION SP_WS_GetDebitCard_info(ps_customer_id IN     varchar2,
                                                       ps_card_no        in     varchar2,
                                                       pc_ref               OUT CursorReferenceType) return varchar2
IS
   ls_returncode VARCHAR2(3):='60';
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_RCODE VARCHAR2(100);
    ls_RDESC VARCHAR2(100);
    ls_CARDNO VARCHAR2(100);
    ls_STATUS_CODE VARCHAR2(100);
    ls_CUSTNO VARCHAR2(100);
    ls_EMBOSS_NAME VARCHAR2(100);


    url_web VARCHAR2(200 CHAR):='http://10.30.10.8/BanksoftServices/BanksoftServices.asmx';--aisuluud 5477 18102016 --'http://10.0.0.38/services.demirbank.kg/BanksoftServices.asmx';
BEGIN
   serviceUrl := url_web;
 
    BEGIN
        namespace := 'http://services.demirbank.kg/';
        methodName := 'getDebitCardInformation';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
      req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'cardno', 'xsd:string',ps_card_no);
        Pkg_Soap.add_parameter(req, 'custno', 'xsd:string', ps_customer_id);

        --call web service, and get response
         resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
        result := resp.doc.getstringval();
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newParser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'getDebitCardInformationResponse/getDebitCardInformationResult');
        l_n := dbms_xmldom.item(l_nl, 0);
        

    
        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueOf(l_n,'RCODE',ls_RCODE);
        dbms_xslprocessor.valueOf(l_n,'RDESC',ls_RDESC);
        dbms_xslprocessor.valueOf(l_n,'CARDNO',ls_CARDNO);
        dbms_xslprocessor.valueOf(l_n,'STATUS_CODE',ls_STATUS_CODE);
        dbms_xslprocessor.valueOf(l_n,'CUSTNO',ls_CUSTNO);
        dbms_xslprocessor.valueOf(l_n,'EMBOSS_NAME',ls_EMBOSS_NAME);
      
      
        OPEN pc_ref FOR 
            SELECT ls_CARDNO,ls_STATUS_CODE,ls_CUSTNO,ls_EMBOSS_NAME,ls_RDESC,ls_RCODE FROM DUAL;

              
    EXCEPTION
        WHEN OTHERS THEN
        
        
            result := SQLERRM;
            ls_returncode:='999';
        
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    END;

    return ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION sf_country_code_formatted
    Prepared By : Adilet Kachkeev
    Date:       : 13.10.2015
    Base Project: CQ0004961 - Adding new fields in CBS and built logic for transferring them to Debit Card System
    Purpose     : To format country codes
*******************************************************************************/
 Function sf_country_code_formatted(ps_country_code varchar2) return varchar2 IS
    ls_country_code varchar2(50) := trim(ps_country_code);
    ls_return varchar2(4) := null;
begin
    if length(ls_country_code) <= 4 and sf_is_number(ls_country_code) = 1 then
        ls_return := substr(ls_country_code, 1, 3);
    else
        select regexp_replace(ls_country_code, '[^[:digit:]]')
        into ls_country_code
        from dual;
    end if;
    
    for ln_count in 1..length(ls_country_code)
    LOOP
        if SUBSTR(ls_country_code, 1, 1) = '0' then
            ls_country_code := substr(ls_country_code, 2);
        end if;
    END LOOP;
    
    return ls_country_code;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_debit_card.country_code', ps_country_code, SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '';
END;
 
/*******************************************************************************
    Name        : FUNCTION sf_phone_number_formatted
    Prepared By : Adilet Kachkeev
    Date:       : 13.10.2015
    Base Project: CQ0004961 - Adding new fields in CBS and built logic for transferring them to Debit Card System
    Purpose     : To format phone numbers
*******************************************************************************/ 
 Function sf_phone_number_formatted(ps_phone_number varchar2 ) return varchar2 IS
    ls_phone_number varchar2(50) := trim(ps_phone_number);
    ls_return varchar2(10) := null;
BEGIN
    select regexp_replace(ls_phone_number, '[^[:digit:]]')
    into ls_phone_number
    from dual;
    
    return ls_phone_number;
EXCEPTION WHEN OTHERS THEN
    log_at('pkg_debit_card.phone_number', ps_phone_number, SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '';
END;

 --BOM CQ5510 MederT 28072016
 /*******************************************************************************
    Name        : FUNCTION sf_card_style_daily_cota_limit
    Prepared By :Meder toitonov
    Date:       : 29.07.2016
    Base Project: CQDB 5510 Debit Web Service Optimization
    Purpose     : Get Daily COTA Limit of Card Style
*******************************************************************************/ 
 Function sf_card_style_daily_cota_limit(ps_card_style_code varchar2 ) return number IS
    ls_return number := 0;
 BEGIN
    SELECT daily_cota_limit 
    INTO ls_return
    FROM cbs_card_styles 
    WHERE code = ps_card_style_code;
    
    return ls_return;
 EXCEPTION WHEN OTHERS THEN
    log_at('pkg_debit_card.sf_card_style_daily_cota_limit', ps_card_style_code, SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return 0;
 END;
 
/*******************************************************************************
    Name        : FUNCTION sf_card_style_offline_permit
    Prepared By :Meder toitonov
    Date:       : 29.07.2016
    Base Project: CQDB 5510 Debit Web Service Optimization
    Purpose     : Get Offline Permit of Card Style
*******************************************************************************/ 
 Function sf_card_style_offline_permit(ps_card_style_code varchar2 ) return varchar2 IS
    ls_return varchar2(10) := null;
 BEGIN
    SELECT offline_permit 
    INTO ls_return
    FROM cbs_card_styles 
    WHERE code = ps_card_style_code;
    
    return ls_return;
 EXCEPTION WHEN OTHERS THEN
    log_at('pkg_debit_card.sf_card_style_offline_permit', ps_card_style_code, SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    return '';
 END;
 --EOM CQ5510 MederT 28072016
 
 --BOM aisuluud CQ5754

procedure sp_dcard_pin_renewal(pn_tx_no number ,
                                       pn_customer_no number,
                                       ps_card_no varchar2,
                                       pn_app_id out number,
                                       pn_card_id_no VARCHAR2 ,
                                       ps_debit_option varchar2,
                                       ps_emboss_name_eng varchar2 default null,
                                       ps_emboss_second_name_eng varchar2 default null,
                                       ps_emboss_surname_eng varchar2 default null ,
                                       ps_response_code out varchar2 ,
                                       ps_response_desc out varchar2 ,
                                       ps_delivery_branch varchar2 default pkg_baglam.bolum_kodu --aisuluud cq5550 added ps_delivery_branch varchar2 default pkg_baglam.bolum_kodu 
) is

ls_renewal_type varchar2(2);
ls_emboss_full_name varchar2(200);
ls_embossname varchar2(26);
--BOM aisuluud cq5550
ls_pinDeliveryBranch  varchar2(5);
ls_cardDeliveryBranch varchar2(5);
--EOM aisuluud cq5550

begin
pn_app_id :=pkg_genel.genel_kod_al('CBS_CARD_DEBIT_APP');

    if ps_debit_option = 'CARD RENEWAL' then
    ls_renewal_type := 'RN';

    elsif ps_debit_option = 'CARD RENEWAL NEW PIN' then
    ls_renewal_type := 'RP';

    elsif ps_debit_option = 'NEW PIN' then
    ls_renewal_type := 'PN';

    end if;
    
    ls_emboss_full_name := pkg_Debit_Card.Sf_emboss_full_name(ps_emboss_name_Eng, ps_emboss_Second_name_eng, ps_emboss_surname_eng);
    ls_embossname := upper(pkg_Debit_card.CYR2LAT( substr(nvl(ls_emboss_full_name,' '),1,26)));
    
    --BOM aisuluud cq5550
    ls_pinDeliveryBranch := lpad(substr(nvl(ps_delivery_branch,'0'),1,4),4,'0');            
    ls_cardDeliveryBranch := lpad(substr(nvl(ps_delivery_branch,'0'),1,4),4,'0')  ; 
    --EOM aisuluud cq5550
    
    pkg_Debit_Card.sp_ins_dcard_pin_renewal(pn_app_id,
                            pn_tx_no,
                            pn_customer_no,
                            ps_card_no,
                            ps_debit_option,
                            pn_card_id_no,
                            ls_renewal_type,
                            ls_embossname,
                            ps_response_code,
                            ps_response_desc,
                            ls_pinDeliveryBranch,--aisuluud cq5550
                            ls_cardDeliveryBranch --aisuluud cq5550
                            );

    pkg_Debit_Card.sp_WS_dbRenewal(pn_app_id  ,
                                   ps_response_code ,        
                                   ps_response_desc );
                                   
    pkg_Debit_Card.sp_upd_dcard_pin_renewal (pn_app_id  ,
                                   ps_response_code ,        
                                   ps_response_desc );                                  
                            
    

Exception
    
        when others then
      log_at('SP_DCARD_PIN_RENEWAL', sqlcode,sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      raise_application_error(-20100,pkg_hata.getucpointer || '6599' || pkg_hata.getdelimiter ||'pn_customer_no:'||pn_customer_no||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);

  End;

--EOM aisuluud CQ5754 

--BOM aisuluud CQ5754

procedure sp_ins_dcard_pin_renewal (pn_app_id number, 
                                       pn_tx_no number ,
                                       pn_customer_no number,
                                       ps_card_no varchar2,
                                       ps_debit_option varchar2,
                                       pn_card_id_no VARCHAR2 ,
                                       ps_renewal_type varchar2,
                                       ps_embossname varchar2 default null,
                                       ps_response_code varchar2 default null,
                                       ps_response_desc varchar2 default null,
                                       ps_pinDeliveryBranch varchar2 default null, --aisuluud cq5550
                                       ps_cardDeliveryBranch varchar2 default null)  --aisuluud cq5550
                                       is pragma autonomous_transaction;


begin

insert into cbs_renewal_card_pin (  tx_no,
                                    app_id,
                                    customer_no,
                                    debit_option,
                                    card_no,
                                    pseudopan,
                                    renewaltype,
                                    embossname,
                                    RESPONSE_CODE,
                                    RESPONSE_DESC,
                                    PINDELIVERYBRANCH, --aisuluud cq5550
                                    CARDDELIVERYBRANCH ) --aisuluud cq5550
                             values(pn_tx_no,
                                    pn_app_id,
                                    pn_customer_no,
                                    ps_debit_option,
                                    ps_card_no,
                                    pn_card_id_no,
                                    ps_renewal_type,
                                    ps_embossname,
                                    ps_response_code,
                                    ps_response_desc ,
                                    ps_pinDeliveryBranch, --aisuluud cq5550
                                    ps_cardDeliveryBranch ); --aisuluud cq5550
                                    
commit;                                    
                                    


EXCEPTION
 WHEN OTHERS THEN
 log_at('sp_ins_dcard_pin_renewal',pn_app_id, sqlcode||' '||sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   rollback;
   raise_application_error(-20100,pkg_hata.getucpointer || '6598' || pkg_hata.getdelimiter ||to_char(sqlcode) ||' '|| sqlerrm || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 
end;
--EOM aisuluud CQ5754

--BOM aisuluud CQ5754
procedure sp_WS_dbRenewal(pn_app_id number ,
                                           ps_response_code out varchar2 ,        
                                           ps_response_desc out varchar2   
)is pragma autonomous_transaction;

cursor cur_renewal is
 select * from cbs_renewal_card_pin
 where app_id = pn_app_id;
 
 r_renewal cur_renewal%rowtype;

 serviceUrl VARCHAR2(2000);
 soapAction VARCHAR2(2000);
 namespace VARCHAR2(2000);
 methodName VARCHAR2(2000);
 req Pkg_Soap.request;
 resp Pkg_Soap.response;
 result CLOB;--NVARCHAR2(32767);
 referenceId INTEGER;

 l_parser  dbms_xmlparser.Parser;
 l_doc     dbms_xmldom.DOMDocument;
 l_nl      dbms_xmldom.DOMNodeList;
 l_n       dbms_xmldom.DOMNode;

 ld_starttime DATE;
 ld_endtime DATE;

 ls_BS_WS_SERVICE_URL VARCHAR2(200) ;-- := 'http://10.0.0.43/WebService/DBWS.asmx'; test 
 ls_header_method VARCHAR2(256);
 ls_header_user VARCHAR2(256);
 ls_header_pass VARCHAR2(256); 
BEGIN
 
 pkg_parametre.deger('BS_WS_SERVICE_URL',ls_BS_WS_SERVICE_URL);

for c_renewal in cur_renewal loop
    r_renewal :=c_renewal;
end loop;

 ld_starttime:=SYSDATE; 

 serviceUrl :=ls_BS_WS_SERVICE_URL;
 namespace := 'http://www.banksoft.com.tr';
 methodName := 'dbRenewal';
 soapAction := namespace || '/DBWS/' || methodName;
 namespace := 'xmlns="' || namespace || '"';

 req := Pkg_Soap.new_request(methodName, namespace);

 pkg_parametre.deger('CARD_WEB_USER', ls_header_user);
 pkg_parametre.deger('CARD_WEB_PASS', ls_header_pass);
 ls_header_method := 'UserCredentials';
 PKG_SOAP.NEW_HEADER(req, ls_header_method,
 '<userName>' || ls_header_user || '</userName>' ||
 '<password>' || ls_header_pass || '</password>');

 Pkg_Soap.add_parameter(
  req, 'app', NULL,
'<pseudoPAN xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalInput"><![CDATA['|| r_renewal.PSEUDOPAN || ']]></pseudoPAN>' ||
'<renewalType xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalInput"><![CDATA['|| r_renewal.RENEWALTYPE || ']]></renewalType>' ||
'<embossName xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalInput"><![CDATA['|| r_renewal.EMBOSSNAME || ']]></embossName>' ||
'<cardDeliveryBranchCode xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalInput"><![CDATA['|| r_renewal.CARDDELIVERYBRANCH || ']]></cardDeliveryBranchCode>' || --aisuluud cq5550
'<PINDeliveryBranchCode xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalInput"><![CDATA['|| r_renewal.PINDELIVERYBRANCH || ']]></PINDeliveryBranchCode>'   --aisuluud cq5550
);

 resp := Pkg_Soap.invoke_utf8_v11_card(req, serviceUrl, soapAction);
 result := resp.doc.getstringval();

 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr"','');
 result:= REPLACE(result,' xmlns="http://www.banksoft.com.tr/DBWS/dbRenewalResult"','');
 l_parser := dbms_xmlparser.newParser;

 dbms_xmlparser.parseclob(l_parser, result);
 l_doc := dbms_xmlparser.getDocument(l_parser);

 l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'dbRenewalResponse/dbRenewalResult');

 FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
  l_n := dbms_xmldom.item(l_nl, cur_emp);
  -- Use XPATH syntax to assign values to he elements of the collection.
  dbms_xslprocessor.valueOf(l_n,'responseCode/text()',ps_response_Code);
  dbms_xslprocessor.valueOf(l_n,'responseCodeDesc/text()',ps_response_Desc);


 END LOOP;

 ld_endtime:=SYSDATE;

 Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,ps_response_Code,NULL,r_renewal.tx_no,pn_app_id,result,REQ.BODY); 

 commit;  

EXCEPTION
 WHEN OTHERS THEN
   rollback;
   ps_response_Code:= '999';
   ps_response_Desc := sqlcode||' '||sqlerrm ; 
   Pkg_debit_Card.WS_LOG('DEBIT CARD',serviceUrl,methodName,ld_starttime,ld_endtime,'999',sqlcode||' '||sqlerrm,r_renewal.tx_no,pn_app_id,result,REQ.BODY);
   log_at('sp_WS_dbRenewal', sqlcode||' '||sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

--EOM aisuluud CQ5754

--BOM aisuluud CQ5754
procedure sp_upd_dcard_pin_renewal( pn_app_id number ,
                                       ps_response_code  varchar2 ,        
                                       ps_response_desc  varchar2  
                
)is pragma autonomous_transaction;
begin

 update cbs_renewal_card_pin
        set response_code = ps_response_code,
            response_desc = ps_response_desc,
            response_date  =sysdate       
        where app_id = pn_app_id;

     commit;
exception
 when others then
   rollback;
   log_at('SP_UPD_DCARD_PIN_RENEWAL-ERROR',pn_app_id, sqlcode||' '||sqlerrm );
end;
--EOM aisuluud CQ5754

END PKG_DEBIT_CARD;
/

