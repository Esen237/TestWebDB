create PACKAGE     "PKG_TX7063" IS
/******************************************************************************
   Name       : CBS.PKG_TX7063
   Created By : Hakan SAMSA
   Date          : 08/07/2010
   Purpose      : DATA UPDATE
******************************************************************************/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);           -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);          -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten sonra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);              -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);          -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);              -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);            -- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);              -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Onaylari_Ayarla(pn_islem_no NUMBER);
  PROCEDURE Onaylayan_Ayarla(pn_islem_no NUMBER,pv_it_aciklama VARCHAR2 default null, pv_DML VARCHAR2 default null, pv_user VARCHAR2 , pn_rol_numara NUMBER,pv_onay_aciklama VARCHAR2 default null,pn_son_onay_adim NUMBER,pv_ilgili_modul  VARCHAR2);
  FUNCTION Onay_Uygunluk(pn_rol_numara NUMBER, pn_son_onay_adim number) RETURN NUMBER;
  FUNCTION Directory_al RETURN VARCHAR2;
  FUNCTION image_import(ps_dosya_path VARCHAR2,pn_tx_no NUMBER) RETURN VARCHAR2;
  FUNCTION Dosya_Ad_Al(ps_sourcetext  VARCHAR2) RETURN VARCHAR2;
  FUNCTION Dosya_Varmi(pn_islemno number,ps_dosya_adi varchar2) RETURN VARCHAR2 ;
   function onay_yetki_kontrol (pn_onay_adimi number,pn_rol number) return number;
 FUNCTION str_ayrac_yeri_bul(ps_str IN OUT VARCHAR2,ps_aranan_kisim IN OUT VARCHAR2 ,ps_ayrac    VARCHAR2 DEFAULT ';') RETURN NUMBER;
   Function file_size_al     Return Number ;
   Function file_name_al (ps_sourcetext Varchar2) Return Varchar2 ;
END;


/

