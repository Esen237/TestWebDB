create PACKAGE PKG_XML_MANUAL IS

/******************************************************************************
   Name       : PKG_XML_MANUAL
   Created By : Hakan Samsa
   Date    	  : 27.08.2008
   Purpose	  : XML procedures
******************************************************************************/


	ls_PATH   varchar2(100):='D:\SHARED\AML_CASH'; --Prod
	out_file  utl_file.file_type;
	in_file  utl_file.file_type;

Function Replace_special_chars(ps_str varchar) return varchar;
Procedure CreateXML_AntiMoney_Laundering(pn_bas number, pn_son number) ;
Function Remove_Numbers(ps_str varchar) return varchar ;
Function Remove_Characters(ps_str varchar) return varchar ;
procedure XML_PARCALA(pn_bas number,pn_son number);
END;


/

