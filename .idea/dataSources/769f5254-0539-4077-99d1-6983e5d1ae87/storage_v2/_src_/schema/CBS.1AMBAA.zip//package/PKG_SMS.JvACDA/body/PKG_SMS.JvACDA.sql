create PACKAGE BODY pkg_sms IS

------------------------------------------------------------------------
PROCEDURE SendAutoSMS(ps_sender in varchar2) is
  cursor cursor_sms is
	   		  select *
			  from cbs_sms_messages
			  where STATUS_CD='sWAIT'
              for update;

 row_sms	 cursor_sms%rowtype;
 ls_result varchar2(4000);

BEGIN

	open cursor_sms;
	fetch cursor_sms into row_sms;
	while cursor_sms%found
	LOOP

	    ls_result:=pkg_sms.SendSMSMessage(row_sms.RECIPIENT, row_sms.BODY_CONTENT);

		if substr(ls_result,1,3)='ID:' then
			UPDATE cbs_sms_messages
			SET STATUS_CD = 'sSEND',SEND_DATE=sysdate,RESPONSE_TEXT=ls_result
			where current of cursor_sms;
	    else
			UPDATE cbs_sms_messages
			SET STATUS_CD = 'sERROR',SEND_DATE=sysdate,RESPONSE_TEXT=ls_result
			where current of cursor_sms;
		end if;
	fetch cursor_sms into row_sms;
	END LOOP;
	close cursor_sms;


EXCEPTION
	 WHEN OTHERS THEN
		  log_at('SEND SMS',sqlerrm);
	 	  ROLLBACK;
 END;
---------------------------------------------------------------------------
PROCEDURE AddToSMSQueue(ps_MESSAGE_CODE  in varchar2, ps_PRIORITY in number, ps_RECIPIENT  in varchar2, ps_BODY_CONTENT in varchar2) is
		  PRAGMA AUTONOMOUS_TRANSACTION;
		  ln_messageid					number;
		  ls_phoneno					varchar2(11);
BEGIN

	--log_at('EMAIL',ps_BODY_CONTENT);

	ln_messageid:=pkg_genel.genel_kod_al('SMS-MSGID');

	ls_phoneno:=pkg_message.Split(ps_RECIPIENT,';',0);

	insert into CBS_SMS_MESSAGES
	(MESSAGE_ID, MESSAGE_CODE, PRIORITY, RECIPIENT, BODY_CONTENT)
	values
	(ln_messageid, ps_MESSAGE_CODE, ps_PRIORITY, ls_phoneno, ps_BODY_CONTENT);

	COMMIT;

exception
	when others then
		 log_at('SMS',sqlerrm);
END;
------------------------------------------------------------------------
FUNCTION SendSMSMessage(ps_RECIPIENT  in varchar2, ps_BODY_CONTENT in varchar2) return varchar2 is
   ls_result varchar2(4000);
   ls_invoke_url varchar2(4000);
BEGIN

   ls_invoke_url:= sms_host || ps_RECIPIENT || '&text=' || url_filter(ps_BODY_CONTENT) ;

   ls_result:=utl_http.request(ls_invoke_url);

   return ls_result;

END;
------------------------------------------------------------------------------------
function url_filter(ps_url varchar2) return varchar2 is
	ls_newurl varchar2(4000);
begin
	ls_newurl:=replace(ps_url,' ','%20');

	return ls_newurl;
end;
-------------------------------------------------------------------------------------
END;
/

