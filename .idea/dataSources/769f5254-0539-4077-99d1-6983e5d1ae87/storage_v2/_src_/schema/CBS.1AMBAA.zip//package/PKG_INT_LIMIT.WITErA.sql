create PACKAGE     Pkg_Int_Limit IS

TYPE CursorReferenceType IS REF CURSOR;
----------------------------------------------------------------------------------------------
FUNCTION GetLimitInfo(pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
		 				pn_amount IN VARCHAR2,
						ps_currcode IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION UpdateLimit(ps_type IN VARCHAR2,
		 			 	pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
		 				pn_amount IN VARCHAR2,
						ps_currcode IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

----------------------------------------------------------------------------------------------
FUNCTION GetTranLimits(pn_musteri_no IN VARCHAR2,
					   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION SetCustomerLimits(pn_musteri_no IN VARCHAR2,
		 				   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION GetGnLimitInfo(pn_musteri_no IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION SetGnLimitInfo(pn_trancd IN VARCHAR2,
                        pn_lowerlimit IN VARCHAR2,
						pn_upperlimit IN VARCHAR2,
                        pn_dailylimit IN VARCHAR2,
						pn_limitcurrency IN VARCHAR2,
						pn_limitcode IN VARCHAR2,
						pn_multiplier IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION CreateGnLimitInfo(pn_trancd IN VARCHAR2,
                           pn_lowerlimit IN VARCHAR2,
						   pn_upperlimit IN VARCHAR2,
                           pn_dailylimit IN VARCHAR2,
						   pn_limitcurrency IN VARCHAR2,
						   pn_multiplier IN VARCHAR2,
                           pn_description IN VARCHAR2,
						   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION DeleteGnLimitInfo(pn_trancd IN VARCHAR2,
                           pn_limitcurrency IN VARCHAR2,
						   pn_limitcode IN VARCHAR2,
						   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION GetMusteriGuvLimitleri(pn_customerid IN VARCHAR2,
		                        pn_trancd IN VARCHAR2,
								pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION GetSysTranLimitInfo(
		   ps_transcd IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------------
FUNCTION GetKullaniciLimitDegerKontrol(
           ps_islemtur IN VARCHAR2,
		   ps_gunluklimit IN VARCHAR2,
		   ps_onaylimit IN VARCHAR2,
		   ps_bilgilimit IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
--------------------------------------------------------------
FUNCTION SetKullaniciGuvLimitDeger(
           ps_islemtur IN VARCHAR2,
		   ps_gunluklimit IN VARCHAR2,
		   ps_onaylimit IN VARCHAR2,
		   ps_bilgilimit IN VARCHAR2,
		   ps_onaytur IN VARCHAR2,
		   ps_bilgitur IN VARCHAR2,
		   ps_customerid IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------
FUNCTION  CheckKullaniciGuvLimitDeger(
           ps_islemtur IN VARCHAR2,
		   ps_customerid IN VARCHAR2,
		   ps_amount IN VARCHAR2,
		   ps_tur IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------
FUNCTION  SendSMS(
		   ps_customerid IN VARCHAR2,
		   ps_message IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------
FUNCTION  SendHatasizSmsMessage(
		   ps_customerid IN VARCHAR2,
		   ps_message IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
-----------------------------------------------------------------
Function CheckTimeLimit(ps_trancd varchar2) return varchar2;
-----------------------------------------------------------------

END;
/

