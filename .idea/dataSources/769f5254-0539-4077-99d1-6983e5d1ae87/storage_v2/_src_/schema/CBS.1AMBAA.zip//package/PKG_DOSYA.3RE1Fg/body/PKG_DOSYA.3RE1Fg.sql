create PACKAGE BODY     Pkg_Dosya IS
 PROCEDURE Dosya_Ac(ps_location   IN VARCHAR2 DEFAULT 'C:\CBS\DOSYA',
                  ps_filename     IN VARCHAR2,
                  ps_open_mode    IN VARCHAR2)
 IS
  ls_err VARCHAR2(2000);
 BEGIN
  /*text Dosyayi Acar*/
  -- Ps_Open_Mode  = W Ise Yazma Amacli
  -- Ps_Open_Mode  = R Ise Okuma Amacli
    log_at('dosya_ac_error1',1);
    in_File := utl_file.Fopen(Ps_Location,trim(Ps_Filename),ps_Open_Mode );
    log_at('dosya_ac_error1',2);

    IF ps_open_mode = 'w' THEN
    log_at('dosya_ac_error1',3);
    out_file :=  utl_file.Fopen(Ps_Location,trim(Ps_Filename),'w' );
    log_at('dosya_ac_error1',4);
  ELSE
    log_at('dosya_ac_error1',5);
  in_File := utl_file.Fopen(Ps_Location,trim(Ps_Filename),'r' );
    log_at('dosya_ac_error1',6);
    END IF;
    log_at('dosya_ac_error1',7);
 EXCEPTION WHEN OTHERS THEN
 log_at('dosya_ac_error',Ps_Location || ' ' || trim(Ps_Filename),sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );--aisuluud
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '777' ||  Pkg_Hata.getdelimiter|| Ps_Filename||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 END;


 PROCEDURE Kayit_ekle(ps_text VARCHAR2) IS
 BEGIN

   utl_file.Put(out_file,ps_text);
 END;


 PROCEDURE SatirAc IS
 BEGIN

  utl_file.New_Line(out_file);
 END;


 PROCEDURE SatirAl( ps_line OUT VARCHAR2) IS
 BEGIN
  utl_file.Get_Line(in_file,ps_line);
 END;


 PROCEDURE dosya_kapa(ps_amac VARCHAR2) IS
 BEGIN
  IF ps_amac = 'w' THEN
    utl_file.FClose(out_file);
  ELSE
    utl_file.FClose(in_file);
   END IF;

   utl_file.fclose_all;

  EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '843' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 END;


  FUNCTION f_get_token(p_sourcetext IN OUT VARCHAR2, p_separator VARCHAR2) RETURN VARCHAR2
  IS
  p NUMBER;
  sourcetext VARCHAR2(1000);
  P_RET  VARCHAR2(1000);

 BEGIN

  sourcetext :=p_sourcetext;
  p := INSTR(sourcetext, p_separator);
  IF p = 0 THEN
   P_RET := sourcetext  ;
   sourcetext := ' '  ;
  ELSE
   P_RET := SUBSTR(sourcetext, 1, p - 1) ;
   p_sourcetext := SUBSTR(sourcetext, LENGTH(p_ret)+2,LENGTH(sourcetext) - p);
  END IF;

  RETURN P_RET;

 END;

Procedure dosya_sil(ps_location   IN VARCHAR2 default 'C:\CBS\DOSYA',
                  ps_filename     IN VARCHAR2)
 is
 Begin
       utl_file.fremove(Ps_Location,trim(Ps_Filename));

  EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '841' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;

  PROCEDURE kopyala(src_location  IN VARCHAR2,
                    src_filename  IN VARCHAR2,
                    dest_location IN VARCHAR2,
                    dest_filename IN VARCHAR2,
                    start_line    IN BINARY_INTEGER DEFAULT 1,
                    end_line      IN BINARY_INTEGER DEFAULT NULL)
 is
 Begin
       utl_file.fcopy(src_location,
                    src_filename ,
                    dest_location,
                    dest_filename,
                    start_line  ,
                    end_line  );

  EXCEPTION WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '841' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;

    --BOM YadgarB CBS-810
    PROCEDURE json_open(ps_location IN VARCHAR2 DEFAULT 'C:\CBS\DOSYA', ps_filename IN VARCHAR2) IS
    BEGIN
        json_in_file := bfilename(ps_location, ps_filename);
        DBMS_LOB.OPEN(json_in_file);
    END;

    PROCEDURE json_read(ps_text OUT CLOB) IS
        c clob;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(c, TRUE);
        DBMS_LOB.LOADFROMFILE(c, json_in_file, DBMS_LOB.GETLENGTH(json_in_file));
        ps_text := replace(to_char(c), '\n', '');
        DBMS_LOB.FREETEMPORARY(c);
    END;

    PROCEDURE json_close IS
    BEGIN
        DBMS_LOB.CLOSE(json_in_file);
    END;
    --EOM YadgarB CBS-810
END;
/

