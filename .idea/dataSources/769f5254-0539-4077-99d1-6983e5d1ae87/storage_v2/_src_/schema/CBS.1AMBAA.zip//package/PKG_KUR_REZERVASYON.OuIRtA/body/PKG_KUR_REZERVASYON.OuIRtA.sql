create PACKAGE BODY     PKG_KUR_REZERVASYON IS

g_uc_delimiter constant varchar2(3):=pkg_hata.getUCPOINTER;
g_ara_delimiter constant varchar2(3):=pkg_hata.getDELIMITER;

Function Rezerve_Kur_Tutar_Uygunmu(pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
 		  							pn_tutar number,
									pn_Alis_Satis varchar,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_marj number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ln_count number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;
 begin

 --Rezervasyon tutar? bulunuyor
 --( rezervasyon s?ras?nda al?s ve sat?s tutarlar?ndan sadece biri girilebildi?inden
 --  rezervasyon tutar?n? bulmak i?in bu iki tutar toplan?yor. )
 select nvl(alis_tutar,0)+nvl(satis_tutar,0)
  into ln_rezerve_tutar
  from cbs_kur_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 --Rezerve edilen tutar?n nekadarl?k k?sm?n?n kullan?ld??? hesaplan?yor...
 select nvl(sum(tutar),0)
  into ln_kullanilan_tutar
  from CBS_KUR_REZERVASYON_KULLANIM
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 if pn_Alis_Satis='A' then
    select alis_doviz
     into ls_doviz_kodu
     from cbs_kur_rezervasyon
     where  TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no;
  else
  if pn_Alis_Satis='S' then
      select satis_doviz
       into ls_doviz_kodu
       from cbs_kur_rezervasyon
       where  TARIH=pd_TARIH
       and SUBE_KODU=ps_SUBE_KODU
       and rezervasyon_no=pn_rezervasyon_no;
	end if;
 end if;


 --D?viz i?in girilen MARJ al?n?yor.

  select count(*)
   into ln_count
   from CBS_KUR_REZERVASYON_MARJ
   where doviz_kodu=ls_doviz_kodu;

 if ln_count>0 then

  select nvl(marj,0)
   into ln_marj
   from CBS_KUR_REZERVASYON_MARJ
   where doviz_kodu=ls_doviz_kodu;

  else
   ln_marj:=0;
  end if;


 --kullan?labilir tutar bulunuyor.(max-kullanilan)
 ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
 ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;

 if pn_tutar<=ln_kullanilabilir_tutar then
   return true;
 else
   return false;
 end if;

 /* when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
*/

end;
-------------------------------------------------------------------------------------

 Function Rezervasyon_Kullanim_Orani(pd_tarih cbs_kur_rezervasyon.tarih%type,
 		  							 ps_sube_kodu cbs_kur_rezervasyon.sube_kodu%type,
 		  							 pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type
 		  					         ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_marj number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_alis_doviz_kodu varchar2(3);
 ls_satis_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ln_alis_tutar number;
 ln_satis_tutar number;
 ln_kullanim_orani number;
 ln_count number;

 begin

 --Rezervasyon tutar? bulunuyor
 --( rezervasyon s?ras?nda al?s ve sat?s tutarlar?ndan sadece biri girilebildi?inden
 --  rezervasyon tutar?n? bulmak i?in bu iki tutar toplan?yor. )
 select nvl(alis_tutar,0)+nvl(satis_tutar,0)
  into ln_rezerve_tutar
  from cbs_kur_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 --Rezerve edilen tutar?n nekadarl?k k?sm?n?n kullan?ld??? hesaplan?yor...
 select nvl(sum(tutar),0)
  into ln_kullanilan_tutar
  from CBS_KUR_REZERVASYON_KULLANIM
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 select islem_sekli,alis_doviz,satis_doviz,alis_tutar,satis_tutar
  into ls_Alis_Satis,ls_alis_doviz_kodu,ls_satis_doviz_kodu,ln_alis_tutar,ln_satis_tutar
  from CBS_KUR_REZERVASYON
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 if ls_Alis_Satis='ALIS' then
   ls_doviz_kodu:=ls_alis_doviz_kodu;
   else
   if ls_Alis_Satis='SATIS' then
      ls_doviz_kodu:=ls_satis_doviz_kodu;
      else
      if ls_Alis_Satis='ARBITRAJ' then
  	  	 if ln_alis_tutar is not null then  ls_doviz_kodu:=ls_alis_doviz_kodu;
 		 else
		   if ln_satis_tutar is not null then  ls_doviz_kodu:=ls_satis_doviz_kodu;
		   end if;
		 end if;
	  end if;
	end if;
 end if;

 --D?viz i?in girilen MARJ al?n?yor.
  select count(*)
   into ln_count
   from CBS_KUR_REZERVASYON_MARJ
   where doviz_kodu=ls_doviz_kodu;

 if ln_count>0 then

 select nvl(marj,0)
  into ln_marj
  from CBS_KUR_REZERVASYON_MARJ
  where doviz_kodu=ls_doviz_kodu;
 else
 ln_marj:=0;
 end if;


 --kullan?labilir tutar bulunuyor.(max-kullanilan)
 /*ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
 ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;
 */
 ln_kullanim_orani:=ROUND(ln_kullanilan_tutar/ln_rezerve_tutar*100,2);

   return ln_kullanim_orani;

 /* when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '99' || pkg_hata.getDelimiter || to_char(ln_mevcut_musteri_no) ||pkg_hata.getUCPOINTER);
*/

end;
--------------------------------------------------------------------------------------

 Function Rezervasyon_Tutar_Turu_Al( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
 		  					         pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									 ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
									) return varchar is
 ln_alis_tutar number;
 ln_satis_tutar number;
 ls_tutar_tur varchar2(10);
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin
   select alis_tutar,satis_tutar
    into ln_alis_tutar,ln_satis_tutar
    from CBS_KUR_REZERVASYON
    where  TARIH=pd_TARIH
    and SUBE_KODU=ps_SUBE_KODU
    and rezervasyon_no=pn_rezervasyon_no;

  if nvl(ln_alis_tutar,0)<>0 then ls_tutar_tur:='ALIS';
   else
     if nvl(ln_satis_tutar,0)<>0 then ls_tutar_tur:='SATIS';
	 end if;
  end if;

 return ls_tutar_tur;

 end;

-----------------------------------------------------------------------------------------
 Function Rezervasyon_Bakiye( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
                              pn_islem_numara cbs_islem.NUMARA%type,
 		  					  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
							  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
							 ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_max_tutar number;
 ln_marj number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_alis_doviz_kodu varchar2(3);
 ls_satis_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ln_alis_tutar number;
 ln_satis_tutar number;
 ln_count number;
 ln_kullanim_count number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin
 --pd_TARIH:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU:=PKG_BAGLAM.BOLUM_KODU;

 --Rezervasyon tutar? bulunuyor
 --( rezervasyon s?ras?nda al?s ve sat?s tutarlar?ndan sadece biri girilebildi?inden
 --  rezervasyon tutar?n? bulmak i?in bu iki tutar toplan?yor. )
 select nvl(alis_tutar,0)+nvl(satis_tutar,0)
  into ln_rezerve_tutar
  from cbs_kur_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 --Rezerve edilen tutar?n nekadarl?k k?sm?n?n kullan?ld??? hesaplan?yor...
 select nvl(sum(tutar),0)
  into ln_kullanilan_tutar
  from CBS_KUR_REZERVASYON_KULLANIM
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 select islem_sekli,alis_doviz,satis_doviz,alis_tutar,satis_tutar
  into ls_Alis_Satis,ls_alis_doviz_kodu,ls_satis_doviz_kodu,ln_alis_tutar,ln_satis_tutar
  from CBS_KUR_REZERVASYON
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 if ls_Alis_Satis='ALIS' then
   ls_doviz_kodu:=ls_alis_doviz_kodu;
   else
   if ls_Alis_Satis='SATIS' then
      ls_doviz_kodu:=ls_satis_doviz_kodu;
      else
      if ls_Alis_Satis='ARBITRAJ' then
  	  	 if ln_alis_tutar is not null then  ls_doviz_kodu:=ls_alis_doviz_kodu;
 		 else
		   if ln_satis_tutar is not null then  ls_doviz_kodu:=ls_satis_doviz_kodu;
		   end if;
		 end if;
	  end if;
	end if;
 end if;
 /*
 if ls_Alis_Satis='ALIS' then
    select alis_doviz
     into ls_doviz_kodu
     from cbs_kur_rezervasyon
     where  TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no;
  else
  if ls_Alis_Satis='SATIS' then
      select satis_doviz
       into ls_doviz_kodu
       from cbs_kur_rezervasyon
       where  TARIH=pd_TARIH
       and SUBE_KODU=ps_SUBE_KODU
       and rezervasyon_no=pn_rezervasyon_no;
	end if;
 end if;
 */

 --D?viz i?in girilen MARJ al?n?yor.
 select count(*)
 into ln_count
 from CBS_KUR_REZERVASYON_MARJ
 where doviz_kodu=ls_doviz_kodu;

 if ln_count>0 then

 select nvl(marj,0)
  into ln_marj
  from CBS_KUR_REZERVASYON_MARJ
  where doviz_kodu=ls_doviz_kodu;

 else
  ln_marj:=0;
 end if;

 --kullan?labilir tutar bulunuyor.(max-kullanilan)
 ln_max_tutar:=ln_rezerve_tutar*(ln_marj+100)/100;
 ln_kullanilabilir_tutar:=ln_max_tutar-ln_kullanilan_tutar;


 --Rezervasyon,m?svetteye gidip i?lem numaras?yla kaydedilmi? olabilir.
 --Bu durumda, tekrar m?svetteden ?a?r?lan i?lemin bakiye hatas? almamas?
 --i?in bakiye, kullanim tutar? kadar art?r?l?yor.
  ln_kullanim_count:=0;
  ln_kullanilan_tutar:=0;

  select count(*)
   into ln_kullanim_count
   from CBS_KUR_REZERVASYON_KULLANIM
   where TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no
     and islem_no=pn_islem_numara;

 if ln_kullanim_count>0 then
  select nvl(sum(tutar),0)
   into ln_kullanilan_tutar
   from CBS_KUR_REZERVASYON_KULLANIM
   where TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no
	 and islem_no=pn_islem_numara;

  ln_kullanilabilir_tutar:=ln_kullanilabilir_tutar+ln_kullanilan_tutar;
 end if;


   return ln_kullanilabilir_tutar;

  exception
     when others then
       Raise_application_error(-20100,pkg_hata.getUCPOINTER || '4542' || pkg_hata.GetDELIMITER || sqlerrm || pkg_hata.getUCPOINTER);


end;
-------------------------------------------------------------------------------------

 Function Rezervasyon_Gercek_Bakiye( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                     ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
 		  					         ) return number is
 ln_rezerve_tutar number;
 ln_kullanilan_tutar number;
 ln_kullanilabilir_tutar number;
 ls_doviz_kodu varchar2(3);
 ls_alis_doviz_kodu varchar2(3);
 ls_satis_doviz_kodu varchar2(3);
 ls_Alis_Satis varchar2(10);
 ln_alis_tutar number;
 ln_satis_tutar number;
 pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin
 --pd_TARIH:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU:=PKG_BAGLAM.BOLUM_KODU;

 --Rezervasyon tutar? bulunuyor
 --( rezervasyon s?ras?nda al?s ve sat?s tutarlar?ndan sadece biri girilebildi?inden
 --  rezervasyon tutar?n? bulmak i?in bu iki tutar toplan?yor. )
 select nvl(alis_tutar,0)+nvl(satis_tutar,0)
  into ln_rezerve_tutar
  from cbs_kur_rezervasyon
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 --Rezerve edilen tutar?n nekadarl?k k?sm?n?n kullanild??? hesaplan?yor...
 select nvl(sum(tutar),0)
  into ln_kullanilan_tutar
  from CBS_KUR_REZERVASYON_KULLANIM
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;

 select islem_sekli,alis_doviz,satis_doviz,alis_tutar,satis_tutar
  into ls_Alis_Satis,ls_alis_doviz_kodu,ls_satis_doviz_kodu,ln_alis_tutar,ln_satis_tutar
  from CBS_KUR_REZERVASYON
  where  TARIH=pd_TARIH
  and SUBE_KODU=ps_SUBE_KODU
  and rezervasyon_no=pn_rezervasyon_no;


 if ls_Alis_Satis='ALIS' then
   ls_doviz_kodu:=ls_alis_doviz_kodu;
   else
   if ls_Alis_Satis='SATIS' then
      ls_doviz_kodu:=ls_satis_doviz_kodu;
      else
      if ls_Alis_Satis='ARBITRAJ' then
  	  	 if ln_alis_tutar is not null then  ls_doviz_kodu:=ls_alis_doviz_kodu;
 		 else
		   if ln_satis_tutar is not null then  ls_doviz_kodu:=ls_satis_doviz_kodu;
		   end if;
		 end if;
	  end if;
	end if;
 end if;

 --kullanilabilir tutar bulunuyor.
 ln_kullanilabilir_tutar:=nvl(ln_rezerve_tutar,0)-nvl(ln_kullanilan_tutar,0);

   return nvl(ln_kullanilabilir_tutar,0);

end;


--------------------------------------------------------------------------------------
Function Rezervasyon_Maliyet_Kur_Al(pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
									pn_Alis_Satis varchar,
									pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return number is

 ln_maliyet_kuru number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin

 if pn_Alis_Satis='A' then
    select maliyet_alis_kuru
     into ln_maliyet_kuru
     from cbs_kur_rezervasyon
     where  TARIH=pd_TARIH
     and SUBE_KODU=ps_SUBE_KODU
     and rezervasyon_no=pn_rezervasyon_no;
  else
  if pn_Alis_Satis='S' then
      select maliyet_satis_kuru
       into ln_maliyet_kuru
       from cbs_kur_rezervasyon
       where  TARIH=pd_TARIH
       and SUBE_KODU=ps_SUBE_KODU
       and rezervasyon_no=pn_rezervasyon_no;
	end if;
 end if;

   return ln_maliyet_kuru;

 /* when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '332' ||g_uc_delimiter);
*/

end;


--------------------------------------------------------------------------------------

Function Kur_Rezervasyon_Kullanilmismi( pn_rezervasyon_no cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                        pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									    ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) return boolean is
 ln_count number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin

 select count(*)
 into ln_count
 from CBS_KUR_REZERVASYON_KULLANIM
 where  TARIH=pd_TARIH
 and SUBE_KODU=ps_SUBE_KODU
 and rezervasyon_no=pn_rezervasyon_no;

 if ln_count=0 then
  return False;
   else
      return True;
 end if;

 end;
-----------------------------------------------------------------------------------
 Procedure Rezervasyon_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                  pn_musteri_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								  pn_musteri_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								  pn_maliyet_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								  pn_maliyet_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								  pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
								  ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu
								  ) is

  --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
  --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin

 select musteri_alis_kuru,musteri_satis_kuru,maliyet_alis_kuru,maliyet_satis_kuru
 into pn_musteri_alis_kuru,pn_musteri_satis_kuru,pn_maliyet_alis_kuru,pn_maliyet_satis_kuru
 from CBS_KUR_REZERVASYON
 where  TARIH=pd_TARIH
 and SUBE_KODU=ps_SUBE_KODU
 and rezervasyon_no=pn_rezervasyon_no;


 exception
    when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);

 end;
------------------------------------------------------------------------------------------

 Procedure Rezervasyon_Alis_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                       pn_musteri_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								       pn_maliyet_alis_kuru out cbs_kur_rezervasyon.MUSTERI_ALIS_KURU%type,
								       pd_date in date default pkg_muhasebe.banka_tarihi_bul,
									   ps_sube in varchar2 default pkg_baglam.bolum_kodu) is

 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;

 begin

 select musteri_alis_kuru,maliyet_alis_kuru
 into pn_musteri_alis_kuru,pn_maliyet_alis_kuru
 from CBS_KUR_REZERVASYON
 where  TARIH=pd_date
 and SUBE_KODU=ps_sube
 and rezervasyon_no=pn_rezervasyon_no;


 exception
    when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2131' ||g_uc_delimiter);

 end;
----------------------------------------------------------------------------------------

 Procedure Rezervasyon_Satis_Bilgisi_Al(pn_rezervasyon_no in cbs_kur_rezervasyon.REZERVASYON_NO%type,
                                        pn_musteri_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
								        pn_maliyet_satis_kuru out cbs_kur_rezervasyon.MUSTERI_SATIS_KURU%type,
										pd_date in date default pkg_muhasebe.banka_tarihi_bul,
									    ps_sube in varchar2 default pkg_baglam.bolum_kodu
								        ) is

 begin

 select musteri_satis_kuru,maliyet_satis_kuru
 into pn_musteri_satis_kuru,pn_maliyet_satis_kuru
 from CBS_KUR_REZERVASYON
 where  TARIH=pd_date
 and SUBE_KODU=ps_sube
 and rezervasyon_no=pn_rezervasyon_no;

 exception
    when others then
       RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2132' ||g_uc_delimiter);

 end;

--------------------------------------------------------------------------------------

 --Kur rezervasyonunun kullanild??? i?lemlerin listesi tutuluyor...
 Procedure Rezervasyon_Kullanim_Kaydet(pn_REZERVASYON_NO in number,
                                       pn_islem_numara in number,
									   pn_TUTAR in number,
									   pd_TARIH in date default pkg_muhasebe.banka_tarihi_bul,
									   ps_SUBE_KODU in varchar2 default pkg_baglam.bolum_kodu) is
 ln_count number;
 --pd_TARIH DATE:=PKG_MUHASEBE.BANKA_TARIHI_BUL;
 --ps_SUBE_KODU varchar2(10):=PKG_BAGLAM.BOLUM_KODU;
 begin

 select count(*)
 into ln_count
 from  CBS_KUR_REZERVASYON_KULLANIM
 where tarih = pd_TARIH
   and sube_kodu = ps_SUBE_KODU
   and islem_no=pn_islem_numara;

 --Bu i?lemin kulland??? rezervasyon varsa sil
 --( ??lem M?sveddeeye her kaydedildi?inde eski rez.kullanim kayd? siliniyor.)
 if ln_count>0 then

   delete from CBS_KUR_REZERVASYON_KULLANIM
	where tarih = pd_TARIH
     and sube_kodu = ps_SUBE_KODU
     and islem_no=pn_islem_numara;

 end if;

  INSERT INTO CBS_KUR_REZERVASYON_KULLANIM(TARIH,SUBE_KODU,REZERVASYON_NO,ISLEM_NO,TUTAR)
  VALUES(pd_TARIH, ps_SUBE_KODU, pn_REZERVASYON_NO, pn_islem_numara, pn_TUTAR);

 exception
    when others then
       --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);
	   null;
 end;

--------------------------------------------------------------------------------------

 Procedure Rezervasyon_Kullanim_Iptal(pn_islem_numara in number) is
 begin

 delete from CBS_KUR_REZERVASYON_KULLANIM
 where islem_no=pn_islem_numara;

 exception
    when others then
       --RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '2037' ||g_uc_delimiter);
	   null;
 end;

 -------------------------------------------------------------------------------------

 Function Kur_Marj_Al( ps_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type,ps_Alis_Satis varchar) return number is
 ln_count number;
 ln_alis_kur_marj number;
 ln_satis_kur_marj number;
 begin

 select count(*)
 into ln_count
 from CBS_KUR_REZERVASYON_MARJ
 where doviz_kodu=ps_doviz_kodu;

 if ln_count>0 then

 select nvl(alis_kur_marj,0),nvl(satis_kur_marj,0)
  into ln_alis_kur_marj,ln_satis_kur_marj
  from CBS_KUR_REZERVASYON_MARJ
  where doviz_kodu=ps_doviz_kodu;
 else
   ln_alis_kur_marj:=0;
   ln_satis_kur_marj:=0;
 end if;

 if ps_Alis_Satis='A' then return ln_alis_kur_marj;
  elsif ps_Alis_Satis='S' then return ln_satis_kur_marj;
 end if;

 end;
------------------------------------------------------------------------------------------
 FUNCTION CalculateParity(ps_currency_1 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
 		  				  ps_currency_2 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
						  ps_buy_sell VARCHAR2) RETURN NUMBER IS

 ln_parite_base_sira_1 NUMBER;
 ln_parite_base_sira_2 NUMBER;
 ls_base_doviz VARCHAR2(3);
 ls_karsi_doviz VARCHAR2(3);
 ln_a NUMBER;
 ln_b NUMBER;

 BEGIN

 SELECT DVZSATIS
 INTO ln_parite_base_sira_1
 FROM CBS_KUR
 WHERE DVZ=ps_currency_1;

 SELECT DVZALIS
 INTO ln_parite_base_sira_2
 FROM CBS_KUR
 WHERE DVZ=ps_currency_2;

 IF ln_parite_base_sira_1>ln_parite_base_sira_2 THEN
    ls_base_doviz:=ps_currency_1;
	ls_karsi_doviz:=ps_currency_2;
 ELSE
    ls_base_doviz:=ps_currency_2;
	ls_karsi_doviz:=ps_currency_1;
 END IF;

 	IF ps_buy_sell='A' THEN

	   ln_a:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_base_doviz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S');
	   ln_b:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_karsi_doviz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');

	   RETURN ln_a /ln_b;
	ELSE

	   ln_a:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_base_doviz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');
	   ln_b:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_karsi_doviz,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S');

	   RETURN ln_a/ln_b;


	END IF;

 END;
--------------------------------------------------------------------------------------------------------
 FUNCTION sf_base_doviz_hangisi(ps_currency_1 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE,
 		  					    ps_currency_2 CBS_DOVIZ_KODLARI.DOVIZ_KODU%TYPE) RETURN VARCHAR IS
 ln_parite_base_sira_1 NUMBER;
 ln_parite_base_sira_2 NUMBER;
 ls_base_doviz VARCHAR2(3);

 BEGIN

 SELECT DVZSATIS
 INTO ln_parite_base_sira_1
 FROM CBS_KUR
 WHERE DVZ=ps_currency_1;

 SELECT DVZALIS
 INTO ln_parite_base_sira_2
 FROM CBS_KUR
 WHERE DVZ=ps_currency_2;

 IF ln_parite_base_sira_1>ln_parite_base_sira_2 THEN
    ls_base_doviz:=ps_currency_1;
 ELSE
    ls_base_doviz:=ps_currency_2;
 END IF;

  RETURN  ls_base_doviz;
 END;
---------------------------------------------------------------------------------------------------------
END;
/

