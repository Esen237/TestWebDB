create PACKAGE BODY Pkg_Tx1501 IS
	pn_1501_musteri_aciklama        NUMBER;
	pn_1501_doviz_kod        NUMBER;
	pn_1501_lc_tutar        NUMBER;
	pn_1501_fc_tutar        NUMBER;
	pn_1501_banka_aciklama        NUMBER;
	pn_1501_borclu_hesap_sube_kodu        NUMBER;
	pn_1501_borclu_hesap_no        NUMBER;
	pn_1501_referans        NUMBER;
	pn_1501_fis_aciklama        NUMBER;
	pn_1501_kur_lc        NUMBER;
	pn_1501_istatistik_kod        NUMBER;
	pn_1501_islem_sube_kodu        NUMBER;
	pn_1501_tl_mi        NUMBER;
	pn_1501_yp_mi        NUMBER;
	pn_1501_damga_vergi_tutari        NUMBER;
	pn_1501_bsmv_tutari        NUMBER;
	pn_1501_musteri_tahsil_tutar        NUMBER;
	pn_1501_toplam_vergi        NUMBER;
	pn_1501_fark_tutar        NUMBER;
	pn_1501_musteri_aciklama_2        NUMBER;
	pn_1501_damga_vergi_orani        NUMBER;
	pn_1501_dv_aciklama_1        NUMBER;
	pn_1501_dv_aciklama_2        NUMBER;
	pn_1501_dv_aciklama_3        NUMBER;
	pn_1501_genel        NUMBER;
	pn_1501_ek        NUMBER;
	pn_1501_bireysel        NUMBER;
	pn_1501_kmh        NUMBER;


  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	   NULL;
  END;

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	UPDATE CBS_SOZLESME_ISLEM
	SET durum_kodu = 'ACIK'
	WHERE tx_no = pn_islem_no;
  END;

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	UPDATE CBS_SOZLESME_ISLEM
	SET durum_kodu = 'IPTAL'
	WHERE tx_no = pn_islem_no;
  END;

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER)
  IS
  BEGIN
  /* muhasebelestirme sonras? ana tablo guncellenir */
		NULL;

  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
   BEGIN

   	UPDATE CBS_SOZLESME_ISLEM
	SET durum_kodu = 'IPTAL'
	WHERE tx_no = pn_islem_no;

   	UPDATE CBS_SOZLESME
	SET durum_kodu = 'IPTAL'
	WHERE (musteri_no,sozlesme_no,ek_sozlesme_no) IN (SELECT musteri_no,sozlesme_no,ek_sozlesme_no
		  										   FROM CBS_SOZLESME_ISLEM
												   WHERE tx_no = pn_islem_no) ;

  END;


  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	UPDATE CBS_SOZLESME_ISLEM
	SET durum_kodu = 'RED'
	WHERE tx_no = pn_islem_no;

  END;

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

   PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,ps_block	VARCHAR2,ps_rowid   VARCHAR2,
  							   ps_column VARCHAR2,pd_column VARCHAR2,ps_oldvalue IN OUT VARCHAR2)
 IS
   guncellenmis_exception			   EXCEPTION;
   ln_retval			  NUMBER:=0;
   ls_sqlstr			  VARCHAR2(2000);
   ls_sql_template		  VARCHAR2(2000);
   ls_source_table		  VARCHAR2(2000);
   ls_dest_table		  VARCHAR2(2000);
  BEGIN

   IF ps_block='CBS_SOZLESME_ISLEM' THEN
   	 --TODO 1: Set the source and destination table names
   	   ls_source_table:='CBS_SOZLESME_ISLEM';
	   ls_dest_table:='CBS_SOZLESME';
   IF ps_column<>'MUSTERI_NO' AND ps_column<>'TX_NO'  AND ps_column<> 'SOZLESME_NO' AND ps_column<> 'EK_SOZLESME_NO'  THEN
	 --TODO 2: Set the Primary Key Count (Default 1)
	   ls_sql_template:=Pkg_Guncel.DifferenceTemplateSingleRecord(3);
	 --TODO 3: Do not alter until next TODO :)
	    ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
   		ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_COLUMN',pd_column);
		ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_TABLE',ls_source_table);
   		ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_COLUMN',ps_column);
		ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_ROWID',ps_rowid);
	 --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

        ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_PK1','MUSTERI_NO');
        ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_PK2','SOZLESME_NO');
        ls_sql_template:=REPLACE(ls_sql_template,'DESTINATION_PK3','EK_SOZLESME_NO');

   	    ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_PK1','MUSTERI_NO');
   	    ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_PK2','SOZLESME_NO');
   	    ls_sql_template:=REPLACE(ls_sql_template,'SOURCE_PK3','EK_SOZLESME_NO');

	  --insert into cbs_yphavale_test values(ls_sql_template);
	   EXECUTE IMMEDIATE ls_sql_template INTO ln_retval,ps_oldvalue;
	 END IF;
    END IF;

	IF ln_retval<>1 THEN
	   RAISE  guncellenmis_exception;
	 END IF;
  EXCEPTION
   WHEN  guncellenmis_exception THEN
   	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '449' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '449' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END;


  PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS

  	ln_sozlesme_no NUMBER;
	ln_ek_sozlesme_no NUMBER;
	ln_sozlesme_tutari NUMBER;
	ln_eski_tutar	   NUMBER;
	ld_sozlesme_tarihi DATE;
	ln_son_fis_no	   NUMBER;
	tarih_degismis 	   EXCEPTION;
	ln_ters_fisno	   NUMBER;
	ln_musteri_no 	   CBS_MUSTERI.musteri_no%TYPE;
   BEGIN

	SELECT musteri_no,
		 sozlesme_no,
		 ek_sozlesme_no	,
	     NVL(sozlesme_tutari,0),
		 sozlesme_tarihi
	INTO  ln_musteri_no ,
		  ln_sozlesme_no,
		  ln_ek_sozlesme_no,
		  ln_sozlesme_tutari,
		  ld_sozlesme_tarihi
	FROM CBS_SOZLESME_ISLEM
	WHERE tx_no = pn_islem_no ;

	SELECT  NVL(sozlesme_tutari,0),
	   		son_fis_numara
	INTO ln_eski_tutar ,
	  		ln_son_fis_no
	FROM CBS_SOZLESME
	WHERE  musteri_no  =ln_musteri_no AND
		   sozlesme_no = ln_sozlesme_no AND
		   ek_sozlesme_no = ln_ek_sozlesme_no;

		IF ln_eski_tutar <> ln_sozlesme_tutari  THEN
		   IF ld_sozlesme_tarihi<> Pkg_Muhasebe.banka_tarihi_bul THEN
		   	  RAISE tarih_degismis ;
		   ELSE
		   	  ln_ters_fisno := Pkg_Muhasebe.Ters_fis_yarat(pn_islem_no,ln_son_fis_no);
--		  	  Pkg_Muhasebe.MUHASEBELESTIR(ln_ters_fisno);
		   	  Pkg_Tx1501.Muhasebelesme_Sozlesme_Giris(pn_islem_no);
		   END IF;
		END IF;

		Pkg_Sozlesme.SP_SOZLESME_GUNCELLE(pn_islem_no);
 EXCEPTION
  WHEN tarih_degismis  THEN
  	   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '595' || Pkg_Hata.getUCPOINTER);
  WHEN OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '581' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);

  END;



  PROCEDURE Muhasebelesme_Sozlesme_Giris(pn_islem_no NUMBER) IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;

	ln_fis_no				   CBS_FIS.numara%TYPE ;
	ls_islem_kod               CBS_ISLEM.islem_kod%TYPE :='1501';
	ls_musteri_aciklama        VARCHAR2(2000);
	ls_banka_aciklama          VARCHAR2(2000);
	ls_fis_aciklama            VARCHAR2(2000);
	ls_aciklama				   VARCHAR2(2000);
	ls_musteri_aciklama_2      VARCHAR2(2000);
	ls_dv_aciklama_1            VARCHAR2(2000);
	ls_dv_aciklama_2            VARCHAR2(2000);
	ls_dv_aciklama_3            VARCHAR2(2000);
	ln_musteri_no			   CBS_MUSTERI.musteri_no%TYPE;
	ls_islem_sube_kodu  CBS_HESAP.sube_kodu%TYPE;
    ln_borclu_hesap_no		   CBS_HESAP.hesap_no%TYPE;
	ls_borclu_hesap_sube_kodu  CBS_HESAP.sube_kodu%TYPE;
	ln_tutar			   	   NUMBER;
	ln_kur			   	   	   NUMBER;
	ln_istatistik_kodu		   NUMBER;
	ls_doviz_kodu			   CBS_HESAP.doviz_kodu%TYPE;
	ln_plan_no				   NUMBER ;
    ln_MUSTERI_TAHSIL_EDIL_TUTAR NUMBER;
	ln_sozlesme_no NUMBER;
	ln_DAMGA_VERGISI_MUSTERI_PAYI NUMBER;
	ln_dv_matrah				  NUMBER;
	ln_dv_tutar NUMBER;
	ln_dv_oran  NUMBER;
	ln_bsmv_oran NUMBER;
	ln_retval NUMBER;
	ln_BSMV_tutar NUMBER;
	ls_sozlesme_tur_kodu   CBS_SOZLESME.sozlesme_tur_kodu%TYPE;
	sozlesme_tur_yok EXCEPTION;
	ln_ek_sozlesme_no NUMBER;

	CURSOR islem_cursor IS
		SELECT
		 musteri_no,
		 dv_tahsil_hesap_no ,
		 DECODE(dv_tahsil_hesap_no,NULL,NULL,Pkg_Hesap.HesaptanSubeAl(dv_tahsil_hesap_no)),
		 doviz_kodu,
		 sozlesme_tutari     ,
		 Pkg_Tx.Amir_BolumKodu_Al( tx_no),
		 sozlesme_no,
		 musteri_tahsil_edilecek_tutar,
		 damga_vergisi_musteri_payi,
		 sozlesme_tur_kodu ,
		 ek_sozlesme_no
	   FROM CBS_SOZLESME_ISLEM
	   WHERE tx_no = pn_islem_no ;
  BEGIN

/* islem bilgisi detaylari alinir */
	 IF islem_cursor%isopen THEN
	   CLOSE islem_cursor;
	 END IF;

  	   OPEN islem_cursor;
	    FETCH islem_cursor INTO
			  ln_musteri_no,
			  ln_borclu_hesap_no,
			  ls_borclu_hesap_sube_kodu,
			  ls_doviz_kodu,
			  ln_tutar     ,
			  ls_islem_sube_kodu,
			  ln_sozlesme_no,
			  ln_musteri_tahsil_edil_tutar,
			  ln_DAMGA_VERGISI_MUSTERI_PAYI,
			  ls_sozlesme_tur_kodu,
			  ln_ek_sozlesme_no;

	   IF islem_cursor%NOTFOUND THEN
	          CLOSE islem_cursor;
       END IF;
	   CLOSE islem_cursor;

/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/

   Pkg_Parametre.deger('1501_FIS_ACIKLAMA',ls_fis_aciklama);
   Pkg_Parametre.deger('1501_BANKA_ACIKLAMA',ls_banka_aciklama);
   Pkg_Parametre.deger('1501_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   Pkg_Parametre.deger('1501_MUSTERI_ACIKLAMA_2',ls_musteri_aciklama_2);
   Pkg_Parametre.deger('1501_DV_ACIKLAMA_1',ls_dv_aciklama_1);
   Pkg_Parametre.deger('1501_DV_ACIKLAMA_2',ls_dv_aciklama_2);
   Pkg_Parametre.deger('1501_DV_ACIKLAMA_3',ls_dv_aciklama_3);
   Pkg_Parametre.deger('1501_DAMGA_VERGI_ORANI',ln_dv_oran);

   ln_retval := Pkg_Parametre.al ( 'G_BSMV_YUZDE', ln_bsmv_oran );
 /**** boolean list ****/
    boolean_list(pn_1501_tl_mi ):=FALSE;
    boolean_list(pn_1501_YP_mi ):=FALSE;
	boolean_list(pn_1501_EK):=FALSE;
	boolean_list(pn_1501_kmh):=FALSE;
	boolean_list(pn_1501_bireysel):=FALSE;
	boolean_list(pn_1501_genel):=FALSE;
/**** number list ****/
  IF ls_doviz_kodu = Pkg_Genel.lc_al THEN
 	  boolean_list(pn_1501_tl_mi ) := TRUE;
   ELSE
 	   boolean_list(pn_1501_yp_mi ) := TRUE;
   END IF;

   CASE  ls_sozlesme_tur_kodu
	 	 WHEN   'EK' THEN
	   	  	  boolean_list(pn_1501_ek) := TRUE;
	 	 WHEN   'BIREYSEL KREDI' THEN
	   	  	  boolean_list(pn_1501_bireysel) := TRUE;
	 	 WHEN   'GENEL KREDI' THEN
	   	  	  boolean_list(pn_1501_genel) := TRUE;
	 	 WHEN   'KMH' THEN
	   	  	  boolean_list(pn_1501_kmh) := TRUE;
		 ELSE
			 RAISE sozlesme_tur_yok;
	END CASE;

 IF  NVL(ln_DAMGA_VERGISI_MUSTERI_PAYI,0) <> 0 THEN
 	ln_dv_matrah :=   Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'N','S') );
	ln_dv_tutar  :=  Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,(ln_dv_matrah  * ln_dv_oran ) /10000 );
	ln_bsmv_tutar := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, (ln_dv_tutar * ln_bsmv_oran ) /100);
 END IF;

  number_list(pn_1501_lc_tutar) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, Pkg_Kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,Pkg_Genel.LC_AL,NULL,ln_tutar,1,NULL,NULL,'O','A'));
  number_list(pn_1501_fc_tutar) := ln_tutar;
  number_list(pn_1501_kur_lc)   :=  Pkg_Kur.doviz_doviz_karsilik(ls_DOVIZ_KODU,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');

  number_list(pn_1501_damga_vergi_tutari) :=NVL(ln_dv_tutar,0);
  number_list(pn_1501_bsmv_tutari) := NVL(ln_bsmv_tutar,0);
  number_list(pn_1501_musteri_tahsil_tutar) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL, NVL((ln_dv_TUTAR * ln_DAMGA_VERGISI_MUSTERI_PAYI)/ 100 ,0));
  number_list(pn_1501_toplam_vergi) :=  number_list(pn_1501_damga_vergi_tutari) + number_list(pn_1501_bsmv_tutari);
  number_list(pn_1501_fark_tutar) :=  number_list(pn_1501_damga_vergi_tutari) -  number_list(pn_1501_musteri_tahsil_tutar);

/*varchar list */

   ls_aciklama := TO_CHAR(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || TO_CHAR(ln_sozlesme_no) || ls_musteri_aciklama_2;
   ls_dv_aciklama_1 := TO_CHAR(ln_sozlesme_no) || ls_Dv_aciklama_1  || TO_CHAR(  number_list(pn_1501_toplam_vergi)) ;
   ls_dv_aciklama_2 := TO_CHAR(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || TO_CHAR(ln_sozlesme_no) || ls_Dv_aciklama_2 || TO_CHAR(ln_dv_matrah);
   ls_dv_aciklama_3 := TO_CHAR(ln_musteri_no)  || ls_musteri_aciklama  ||'  ' || TO_CHAR(ln_sozlesme_no) || ls_Dv_aciklama_3 || TO_CHAR(ln_bsmv_tutar);

   varchar_list(pn_1501_fis_aciklama) 	        := ls_fis_aciklama ;
   varchar_list(pn_1501_banka_aciklama)         := ls_aciklama;
   varchar_list(pn_1501_musteri_aciklama)       := ls_aciklama;
   varchar_list(pn_1501_dv_aciklama_1)          :=  ls_dv_aciklama_1;
   varchar_list(pn_1501_dv_aciklama_2)          :=  ls_dv_aciklama_2;
   varchar_list(pn_1501_dv_aciklama_3)          :=  ls_dv_aciklama_3;
   varchar_list(pn_1501_referans) 	   	 		:= TO_CHAR(ln_musteri_no);
   varchar_list(pn_1501_doviz_kod) 		 	    := ls_doviz_kodu;
   varchar_list(pn_1501_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
   varchar_list(pn_1501_borclu_hesap_no)        := TO_CHAR(ln_borclu_hesap_no);
   varchar_list(pn_1501_islem_sube_kodu) 		:= ls_islem_sube_kodu;


/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=Pkg_Muhasebe.fis_kes(ls_islem_kod,
							ln_plan_no,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							NULL,
							FALSE,
							0,
							ls_fis_aciklama);

	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

/* fis no alan? guncellenir */
		UPDATE CBS_SOZLESME_ISLEM
		SET son_fis_numara = ln_fis_no
	    WHERE tx_no = pn_islem_no ;

		Pkg_Sozlesme.sp_sozlesme_guncelle(pn_islem_no);

 EXCEPTION
  WHEN sozlesme_tur_yok THEN
  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '583' || Pkg_Hata.getUCPOINTER);
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '581' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);

 END;


 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
 BEGIN
  NULL;
 END;

 BEGIN
		pn_1501_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1501_MUSTERI_ACIKLAMA');
		pn_1501_doviz_kod :=Pkg_Muhasebe.parametre_index_bul('1501_DOVIZ_KOD');
		pn_1501_lc_tutar :=Pkg_Muhasebe.parametre_index_bul('1501_LC_TUTAR');
		pn_1501_fc_tutar :=Pkg_Muhasebe.parametre_index_bul('1501_FC_TUTAR');
		pn_1501_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1501_BANKA_ACIKLAMA');
		pn_1501_borclu_hesap_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1501_BORCLU_HESAP_SUBE_KODU');
		pn_1501_borclu_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1501_BORCLU_HESAP_NO');
		pn_1501_referans :=Pkg_Muhasebe.parametre_index_bul('1501_REFERANS');
		pn_1501_fis_aciklama :=Pkg_Muhasebe.parametre_index_bul('1501_FIS_ACIKLAMA');
		pn_1501_kur_lc :=Pkg_Muhasebe.parametre_index_bul('1501_KUR_LC');
		pn_1501_istatistik_kod :=Pkg_Muhasebe.parametre_index_bul('1501_ISTATISTIK_KOD');
		pn_1501_islem_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1501_ISLEM_SUBE_KODU');
		pn_1501_tl_mi :=Pkg_Muhasebe.parametre_index_bul('1501_TL_MI');
		pn_1501_yp_mi :=Pkg_Muhasebe.parametre_index_bul('1501_YP_MI');
		pn_1501_damga_vergi_tutari :=Pkg_Muhasebe.parametre_index_bul('1501_DAMGA_VERGI_TUTARI');
		pn_1501_bsmv_tutari :=Pkg_Muhasebe.parametre_index_bul('1501_BSMV_TUTARI');
		pn_1501_musteri_tahsil_tutar :=Pkg_Muhasebe.parametre_index_bul('1501_MUSTERI_TAHSIL_TUTAR');
		pn_1501_toplam_vergi :=Pkg_Muhasebe.parametre_index_bul('1501_TOPLAM_VERGI');
		pn_1501_fark_tutar :=Pkg_Muhasebe.parametre_index_bul('1501_FARK_TUTAR');
		pn_1501_musteri_aciklama_2 :=Pkg_Muhasebe.parametre_index_bul('1501_MUSTERI_ACIKLAMA_2');
		pn_1501_damga_vergi_orani :=Pkg_Muhasebe.parametre_index_bul('1501_DAMGA_VERGI_ORANI');
		pn_1501_dv_aciklama_1 :=Pkg_Muhasebe.parametre_index_bul('1501_DV_ACIKLAMA_1');
		pn_1501_dv_aciklama_2 :=Pkg_Muhasebe.parametre_index_bul('1501_DV_ACIKLAMA_2');
		pn_1501_dv_aciklama_3 :=Pkg_Muhasebe.parametre_index_bul('1501_DV_ACIKLAMA_3');
		pn_1501_genel :=Pkg_Muhasebe.parametre_index_bul('1501_GENEL');
		pn_1501_ek :=Pkg_Muhasebe.parametre_index_bul('1501_EK');
		pn_1501_bireysel :=Pkg_Muhasebe.parametre_index_bul('1501_BIREYSEL');
		pn_1501_kmh :=Pkg_Muhasebe.parametre_index_bul('1501_KMH');
END;
/

