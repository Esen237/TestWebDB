create PACKAGE     "PKG_MASRAF" IS

  CURSOR cur_masraf(pn_islem_no NUMBER) IS
         SELECT *
           FROM CBS_MASRAF
          WHERE islem_no = pn_islem_no
          order by SIRA;

  row_masraf cur_masraf%ROWTYPE;

  FUNCTION  masraf_yaratilmali(pn_islem_kodu IN NUMBER,
                               pc_modul_tur_kod CBS_ISLEM.modul_tur_kod%TYPE,
                               pc_urun_tur_kod CBS_ISLEM.urun_tur_kod%TYPE,
                               pc_urun_sinif_kod CBS_ISLEM.urun_sinif_kod%TYPE)
                              RETURN BOOLEAN;

--BOM CQ4879 MederT 02112015
--nospec
function masraf_fix_var(ps_masraf_kod in cbs_masraf_tur.kodu%type,
                        pn_islem_kodu in number,
                        pn_musteri_no in number,
                        ps_modul in varchar2 default null,
                        ps_urun_tur in varchar2 default null,
                        ps_urun_sinif in varchar2 default null,
                        pn_tutar in out number, ps_dvz in out varchar2,
                        pn_min_tutar out number, pn_max_tutar out number)return number;
--EOM CQ4879 MederT 02112015
/*--------------------------------------------------------------------------------------------------- */
--nospec
function masraf_muaf_var(ps_masraf_kod in cbs_masraf_tur.kodu%type,
                         pn_islem_kodu in number,
                         pn_musteri_no in number,
                         ps_modul in varchar2 default null,
                         ps_urun_tur in varchar2 default null,
                         ps_urun_sinif in varchar2 default null)return number;
/* --------------------------------------------------------------------------------------------------- */
--nospec
procedure masraf_tutarlari_al(ps_masraf_kod varchar2, pn_islem_kodu number,
                               ps_modul varchar2, ps_urun_tur varchar2, ps_urun_sinif varchar2,
                              pn_min_yuzde out number, pn_max_yuzde out number,
                              pn_min_tutar out number, pn_max_tutar out number,
                              pn_tutar out number, ps_bsmv_al out varchar2,
                              ps_sabit_oran out varchar2, pn_yuzde out number,
                              ps_dvz out varchar2, ps_tum_doviz out varchar2,
                              ps_kom_kur_kullan out varchar2);
/* --------------------------------------------------------------------------------------------------- */
--nospec
procedure masraf_aralik_tutar_al(ps_masraf_kod varchar2, pn_islem_kodu number,
                                  ps_modul varchar2, ps_urun_tur varchar2,
                                 ps_urun_sinif varchar2, pn_tutar number,
                                 ps_dvz varchar2 /*masraf_tanim doviz*/,
                                 ps_msrf_dvz varchar2 /*istenen cinsteki doviz */,
                                 ps_doviz varchar2 /*islem dovizi */,
                                 pn_min_tutar in out number, pn_max_tutar in out number,
                                 pn_tutar_o in out number,
                                 ps_kom_kur_kullan in varchar2);
/* --------------------------------------------------------------------------------------------------- */
--nospec
procedure masraf_aralik_yuzde_tutar_al(ps_masraf_kod varchar2, pn_islem_kodu number,
                                        ps_modul varchar2, ps_urun_tur varchar2,
                                       ps_urun_sinif varchar2, pn_tutar number,
                                        ps_dvz varchar2 /*masraf_tanim doviz*/,
                                        ps_msrf_dvz varchar2 /*istenen cinsteki doviz */,
                                        ps_doviz varchar2 /*islem dovizi */,
                                        pn_min_yuzde in out number, pn_max_yuzde in out number,
                                        pn_yuzde in out number, pn_min_tutar in out number,
                                        pn_max_tutar in out number,
                                       ps_kom_kur_kullan in varchar2);
/* --------------------------------------------------------------------------------------------------- */
--nospec
  procedure masraf_hesapla(ps_masraf_kod in cbs_masraf_tur.kodu%type, pn_tutar in number,
                           pn_islem_kodu in number, pn_rol in number, pn_musteri_no in number, ps_doviz in varchar2,
                           pn_masraf out number, pn_bsmv out number, ps_msrf_dvz in varchar2 default null,
                           ps_modul in varchar2 default null, ps_urun_tur in varchar2 default null,
                           ps_urun_sinif in varchar2 default null,
                           pc_bolum_kodu in varchar2 default null,
                           pc_hesap_numara in number default null);
/*--------------------------------------------------------------------------------------------------- */
--nospec
procedure get_rol_min_max_tutar(pn_hesaplanan number, pn_rol_marj_arti number, pn_rol_marj_eksi number,
                                pn_rol_min_tutar number, pn_rol_max_tutar number, pn_max_tutar number,
                                pn_min_tutar number, pn_max in out number, pn_min in out number);
/* --------------------------------------------------------------------------------------------------- */
--nospec
procedure get_min_max_tutar(pn_tutar number, ps_sabit_oran varchar2,
                            pn_max_tutar number, pn_min_tutar number, pn_max_yuzde number, pn_min_yuzde number,
                             pn_max_hesap_tutar in out number, pn_min_hesap_tutar in out number);
/* --------------------------------------------------------------------------------------------------- */

  FUNCTION  Sf_Masraf_Adi( ps_masraf_kodu CBS_MASRAF_TUR.kodu%TYPE) RETURN VARCHAR2;

  PROCEDURE masraf_kontrol(pn_alinan IN NUMBER, pn_hesaplanan IN NUMBER,
                           ps_masraf_kod  IN CBS_MASRAF_TUR.kodu%TYPE, pn_tutar IN NUMBER,
                           pn_islem_kodu IN NUMBER, pn_rol IN NUMBER, pn_musteri_no IN NUMBER, ps_doviz IN VARCHAR2,
                           pn_masraf IN OUT NUMBER, pn_bsmv IN OUT NUMBER, ps_msrf_dvz IN VARCHAR2 DEFAULT NULL,
                           ps_modul IN VARCHAR2 DEFAULT NULL, ps_urun_tur IN VARCHAR2 DEFAULT NULL,
                           ps_urun_sinif IN VARCHAR2 DEFAULT NULL);

  PROCEDURE check_default_deger(ps_masraf_kod IN CBS_MASRAF_ODEYEN.masraf_kodu%TYPE);

  FUNCTION default_odeyen(ps_masraf_kod IN CBS_MASRAF_ODEYEN.masraf_kodu%TYPE) RETURN VARCHAR2;

  FUNCTION masraf_girilmis(pn_islem_no NUMBER, pn_islem_kodu IN NUMBER,
                           pc_modul_tur_kod CBS_ISLEM.modul_tur_kod%TYPE,
                           pc_urun_tur_kod CBS_ISLEM.urun_tur_kod%TYPE,
                           pc_urun_sinif_kod CBS_ISLEM.urun_sinif_kod%TYPE
                           ) RETURN BOOLEAN;

  FUNCTION  masraf_hesaplanan_al(pn_islem_kodu IN NUMBER ,ps_masraf_kod IN CBS_MASRAF_TUR.kodu%TYPE) RETURN NUMBER;

  PROCEDURE open_masraf_cur(pn_islem_no NUMBER);

  PROCEDURE fetch_masraf_cur(row_masraf OUT cur_masraf%ROWTYPE, ls_ok OUT VARCHAR2);

  PROCEDURE close_masraf_cur;

  PROCEDURE masraf_yarat(pn_islem_no NUMBER, pn_islem_kod CBS_ISLEM.islem_kod%TYPE,
                         pc_modul_tur_kod CBS_ISLEM.modul_tur_kod%TYPE,
                         pc_urun_tur_kod CBS_ISLEM.urun_tur_kod%TYPE,
                         pc_urun_sinif_kod CBS_ISLEM.urun_sinif_kod%TYPE,
                         pn_tutar CBS_ISLEM.tutar%TYPE,
                         pc_bolum_kodu CBS_ISLEM.amir_bolum_kodu%TYPE,
                         pc_doviz_kod CBS_ISLEM.doviz_kod%TYPE,
                         pn_musteri_numara CBS_ISLEM.musteri_numara%TYPE,
                         pc_hesap_numara CBS_ISLEM.hesap_numara%TYPE,
                         pc_kasa_kod CBS_ISLEM.kasa_kod%TYPE,
                         ps_msrf_dvz CBS_ISLEM.doviz_kod%TYPE DEFAULT NULL);

  FUNCTION masraf_yaratilmis(pn_islem_no IN NUMBER, pn_islem_kodu IN NUMBER,
                             pc_modul_tur_kod CBS_ISLEM.modul_tur_kod%TYPE,
                              pc_urun_tur_kod CBS_ISLEM.urun_tur_kod%TYPE,
                              pc_urun_sinif_kod CBS_ISLEM.urun_sinif_kod%TYPE
                             ) RETURN VARCHAR2;

   PROCEDURE masraf_update_et (pn_islem_no    NUMBER,
                               pn_sira        NUMBER,
                               
                               pn_alinan      NUMBER,
                               ps_odeyecek    VARCHAR2,
                               pn_bsmv        NUMBER);
   procedure masraf_update_data(pn_islem_no number, pn_sira number,pn_hesaplanan number, pn_alinan number,
                             ps_odeyecek varchar2, pn_bsmv number);

  PROCEDURE validate_masraf(pn_islem_no NUMBER);

  FUNCTION masraf_can_be_changed(pn_islem_no NUMBER) RETURN VARCHAR2;

  FUNCTION toplam_masraf(pn_islem_no NUMBER) RETURN NUMBER;

  PROCEDURE masraf_toplamlari(pn_islem_no IN NUMBER, pn_masraf OUT NUMBER, pn_bsmv OUT NUMBER);

  FUNCTION bsmv_hesapla(pn_tutar NUMBER) RETURN NUMBER;

  PROCEDURE secimlik_masraf_yarat(pn_islem_no NUMBER, pn_islem_kod CBS_ISLEM.islem_kod%TYPE,
                         pc_modul_tur_kod CBS_ISLEM.modul_tur_kod%TYPE,
                         pc_urun_tur_kod CBS_ISLEM.urun_tur_kod%TYPE,
                         pc_urun_sinif_kod CBS_ISLEM.urun_sinif_kod%TYPE,
                         pn_tutar CBS_ISLEM.tutar%TYPE,
                         pc_bolum_kodu CBS_ISLEM.amir_bolum_kodu%TYPE,
                         pc_doviz_kod CBS_ISLEM.doviz_kod%TYPE,
                         pn_musteri_numara CBS_ISLEM.musteri_numara%TYPE,
                         pc_hesap_numara CBS_ISLEM.hesap_numara%TYPE,
                         pc_kasa_kod CBS_ISLEM.kasa_kod%TYPE,
                         ps_referans VARCHAR2);

  FUNCTION bsmv_hesapla(ps_masraf_kodu CBS_MASRAF_TUR.kodu%TYPE, pn_tutar NUMBER) RETURN NUMBER;

  PROCEDURE iptal_icin_log_at(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_sira_no NUMBER, ps_masraf_kodu VARCHAR2, pn_tahsil_tutar NUMBER, pn_vs_no NUMBER DEFAULT 0);

  PROCEDURE iptal_icin_log_at_taksit(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_taksit_no NUMBER, pd_taksit_odeme_tarih DATE, pn_taksit_tutari NUMBER, ps_masraf_kodu VARCHAR2, pn_vs_no NUMBER DEFAULT 0);

  PROCEDURE  Masraf_Guncelleme_Kontrolu(pn_islem_no NUMBER,
                                    ps_block     VARCHAR2,
                                 ps_rowid        VARCHAR2,
                                      ps_column       VARCHAR2,
                                         pd_column       VARCHAR2,
                                 ps_oldvalue IN OUT VARCHAR2);
  PROCEDURE onay_sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2,
                         pn_vs_no NUMBER, ps_source VARCHAR2,
                         ps_masraf VARCHAR2);
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2);
  PROCEDURE Iptal_Onay_Sonrasi_odeme(pn_islem_no NUMBER, ps_ref VARCHAR2);
  PROCEDURE Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER);
  PROCEDURE Muhasebe_Sonrasi_odeme(pn_islem_no NUMBER, ps_ref VARCHAR2);
  PROCEDURE Muhasebe_Sonrasi_grs_guncel(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER);
  FUNCTION  min_masraf_al(ps_masraf_kodu VARCHAR2, ps_dvz VARCHAR2) RETURN NUMBER;
  FUNCTION  REFERANSTAN_MUSTERI_NO_AL(PS_REFERANS VARCHAR2) RETURN NUMBER;
  FUNCTION  MASRAF_ADI_AL(PS_MASRAF_KODU VARCHAR2) RETURN VARCHAR2;
  PROCEDURE islem_komisyon_oran_tutar_al(pn_islem_no NUMBER, pn_oran OUT NUMBER,pn_komisyon_toplami OUT NUMBER);
  FUNCTION  masraf_girilen_tutar_al(pn_islem_kodu IN NUMBER ,ps_masraf_kod IN CBS_MASRAF_TUR.kodu%TYPE) RETURN NUMBER ;
  PROCEDURE masraf_koduna_dkgrup_dk_aktar(ps_masraf_kodu CBS_MASRAF_DKGRUP_DK.MASRAF_KODU%TYPE);
  FUNCTION  masraf_girilmis_mi(pn_islem_no NUMBER,
                                   ps_masraf_kodu CBS_MASRAF_DKGRUP_DK.MASRAF_KODU%TYPE)  RETURN NUMBER ;
  FUNCTION tum_masraf_dkgruplar_tanimlimi(ps_masraf_kodu CBS_MASRAF_DKGRUP_DK.MASRAF_KODU%TYPE) return varchar2;

  PROCEDURE gecici_gercek_icin_kaydet(pn_islem_no number, ps_referans varchar2, ps_masraf_kodu varchar2,
                                      pn_vs_no number, pn_taksit_no number, pd_taksit_odeme_tarih date,
                                      pn_taksit_tutari number, pn_hesap number, pd_vade date default null,
                                      ps_sureli varchar2 default 'E', ps_sube varchar2 default null,
                                      pn_musteri number default null, ps_vergi varchar2 default 'H' );
  Function Sf_Masraf_UrunUygunmu( ps_urun_tur_kod cbs_hesap.urun_tur_kod%type ) return varchar2;
  PROCEDURE gecici_gercek_icin_kaydet_eod(pn_yarat_tx number, pn_sira_no number, ps_referans varchar2, ps_masraf_kodu varchar2,
                                      pn_vs_no number, pn_taksit_no number, pd_taksit_odeme_tarih date,
                                      pn_taksit_tutari number, pn_hesap number, pd_vade date default null,
                                      ps_sureli varchar2 default 'E', ps_sube varchar2,
                                      pn_musteri number default null, ps_vergi varchar2 default 'H' );


 Function musteri_tipi_al(pn_musteri_no number) return varchar2;

/*******************************************************************************
    Name:   calculate_commissions_for_CIB
    Prepared By:    Chyngyz Omurov
    Date:   06.07.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    calculate special commissions for swift in CIB
*******************************************************************************/

Function calculate_commissions_for_CIB(pn_islem_no number,
                                        ps_urun_sinif_kod   cbs_islem.urun_sinif_kod%TYPE,
                                        pn_tutar cbs_islem.tutar%TYPE,
                                        ps_doviz_kod cbs_islem.doviz_kod%TYPE,
                                        pn_musteri_numara cbs_islem.musteri_numara%TYPE,
                                        pn_hesap_numara cbs_islem.hesap_numara%TYPE) RETURN NUMBER;

/*******************************************************************************
    Name:   calculate_CDF_for_CIB
    Prepared By:    Chyngyz Omurov
    Date:   18.02.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    calculate cash deposit fee for the given customer account
*******************************************************************************/

Function calculate_CDF_for_CIB(pn_islem_no number,
                              pn_islem_kod                         cbs_islem.islem_kod%TYPE,
                              ps_modul_tur_kod                     cbs_islem.modul_tur_kod%TYPE,
                              ps_urun_tur_kod                      cbs_islem.urun_tur_kod%TYPE,
                              ps_urun_sinif_kod                    cbs_islem.urun_sinif_kod%TYPE,
                              pn_tutar                             cbs_islem.tutar%TYPE,
                              ps_doviz_kod                         cbs_islem.doviz_kod%TYPE,
                              pn_musteri_numara                    cbs_islem.musteri_numara%TYPE,
                              pn_hesap_numara                      cbs_islem.hesap_numara%TYPE) RETURN NUMBER;
  
/*******************************************************************************
    Name:   CD_sum_for_period
    Prepared By:    Chyngyz Omurov
    Date:   18.02.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    calculate total amount in user balance which deposited with cash for the given period
*******************************************************************************/                                                            
                                                    
Function CD_sum_for_period(pn_hesapno NUMBER, pd_begindate DATE, pd_enddate DATE) RETURN NUMBER;

Function CD_sum_for_period_OLD(pn_hesapno NUMBER, pd_begindate DATE, pd_enddate DATE) RETURN NUMBER;

-- AdiletK 22.02.2017 CQ1016 calculates commission amount but doesn't put it into the cbs_masraf
 Function masraf_tutari_hesapla(ps_masraf_kod cbs_masraf_tur.kodu%type, pn_tutar number,
                                                pn_islem_kodu number, pn_rol number, pn_musteri_no number,
                                                ps_doviz varchar2, ps_msrf_dvz varchar2 default null, 
                                                ps_modul varchar2 default null, ps_urun_tur varchar2 default null, 
                                                ps_urun_sinif varchar2 default null, pc_bolum_kodu varchar2 default null, 
                                                pc_hesap_numara varchar2 default null) return number;


END;
/

