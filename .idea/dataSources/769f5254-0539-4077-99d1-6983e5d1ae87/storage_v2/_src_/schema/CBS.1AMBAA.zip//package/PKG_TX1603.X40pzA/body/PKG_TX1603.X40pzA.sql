create PACKAGE BODY PKG_TX1603 IS
	pn_1603_banka_aciklama        number;
	pn_1603_islem_sube        number;
	pn_1603_OUTLET_CASH_GL	  number;
	pn_1603_referans        number;
	pn_1603_istatistik_kodu        number;
	pn_1603_musteri_aciklama        number;
	pn_1603_doviz_kodu        number;
	pn_1603_kasa_eksik        number;
	pn_1603_kasa_eksik_lc        number;
	pn_1603_kasa_fazla_lc        number;
	pn_1603_kasa_fazla        number;
	pn_1603_kur        number;
	pn_1603_fc_islem        number;
	pn_1603_lc_islem        number;
	pn_1603_eksik        number;
	pn_1603_fazla        number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
	    Bakiye_Kontrol(pn_islem_no ,'H');
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin

     Bakiye_Kontrol(pn_islem_no ,'H');
  End;


  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
	 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
  End;

  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin

    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getUCPOINTER);
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
  	   null;
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is

    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
    ln_fis_no				   cbs_fis.numara%type :=0;
	ls_islem_kod               cbs_islem.islem_kod%type :='1603';
	ls_musteri_aciklama        varchar2(2000);
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama            varchar2(2000);
	ls_aciklama				   varchar2(2000);
	ls_musteri_aciklama_2      varchar2(2000);
	ls_kasa_kodu 			   varchar2(2000);
	ls_doviz_kodu			   varchar2(2000);
	ln_plan_no				   number;

     cursor cur_bakiye is
	    select distinct
			   kasa_kodu,
			   sube_kodu,
			   tanim_no
		from cbs_kasa_islem
		where tx_no = pn_islem_no;

		cursor cur_islem_cursor is
		select
			 tx_no,
			 kasa_kodu,
			 sube_kodu,
			 doviz_kodu,
			 kullanici_kodu,
			 tanim_no,
			 bakiye,
			 islem_kod,
			 nvl(bakiye_fazla,0) bakiye_fazla ,
			 nvl(bakiye_eksik,0) bakiye_eksik
	   from cbs_kasa_bakiye_islem
	   where tx_no = pn_islem_no and
	   		 (nvl(bakiye_fazla,0) <> 0 or nvl(bakiye_eksik,0)<> 0 )  ;


	ls_durum varchar2(200);
	r_bakiye cur_bakiye%rowtype;
	kasa_kapali exception;

  Begin
/******** 1603 Muhasebe islemleri****/
    varchar_list(pn_1603_banka_aciklama)  := ls_aciklama;
	varchar_list(pn_1603_banka_aciklama) := NULL;
	varchar_list(pn_1603_doviz_kodu) := NULL;
	varchar_list(pn_1603_islem_sube) := NULL;
	varchar_list(pn_1603_OUTLET_CASH_GL) := NULL;
	varchar_list(pn_1603_istatistik_kodu) := NULL;
	varchar_list(pn_1603_musteri_aciklama) := NULL;
	varchar_list(pn_1603_referans) := NULL;
	number_list(pn_1603_kasa_eksik):= 0;
	number_list(pn_1603_kasa_eksik_lc):= 0;
	number_list(pn_1603_kasa_fazla):= 0;
	number_list(pn_1603_kasa_fazla_lc):= 0;
	number_list(pn_1603_kur):= 0;
	boolean_list(pn_1603_eksik):= FALSE;
	boolean_list(pn_1603_fazla):= FALSE;
	boolean_list(pn_1603_fc_islem):= FALSE;
	boolean_list(pn_1603_lc_islem):= FALSE;
/*** Liste Deger Atama K?sm? **/

   pkg_parametre.deger('1603_BANKA_ACIKLAMA',varchar_list(pn_1603_banka_aciklama));
   pkg_parametre.deger('1603_MUSTERI_ACIKLAMA',varchar_list(pn_1603_musteri_aciklama));
  ls_aciklama := 	varchar_list(pn_1603_banka_aciklama);
    for c_islem_cursor in cur_islem_cursor loop

		    ls_kasa_kodu := c_islem_cursor.kasa_kodu;
		    ls_doviz_kodu := c_islem_cursor.doviz_kodu;
			boolean_list(pn_1603_eksik):= FALSE;
			boolean_list(pn_1603_fazla):= FALSE;
			boolean_list(pn_1603_fc_islem):= FALSE;
			boolean_list(pn_1603_lc_islem):= FALSE;

			varchar_list(pn_1603_doviz_kodu) := c_islem_cursor.doviz_kodu;
			varchar_list(pn_1603_islem_sube) := c_islem_cursor.sube_kodu;
			varchar_list(pn_1603_referans) := c_islem_cursor.kasa_kodu;
			number_list(pn_1603_kasa_eksik):= c_islem_cursor.bakiye_eksik;
			number_list(pn_1603_kasa_eksik_lc):=  pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.bakiye_eksik,1,null,null,'N','A'));
			number_list(pn_1603_kasa_fazla):=  c_islem_cursor.bakiye_fazla;
			number_list(pn_1603_kasa_fazla_lc):= pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.bakiye_fazla,1,null,null,'N','A'));
			number_list(pn_1603_kur) :=pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'));

		  -- hs,20100118, for outlet
		  if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1603_islem_sube)) = 'H' then
		      pkg_parametre.deger('G_DK_FC_CASH_GL', 	 varchar_list(pn_1603_OUTLET_CASH_GL));
		  else
		      pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1603_OUTLET_CASH_GL));
		  end if;
		  -- hs,20100118, for outlet


			if ls_doviz_kodu = pkg_genel.lc_al then
			   boolean_list(pn_1603_lc_islem) := true;
			 else
			     boolean_list(pn_1603_fc_islem) := true;
			end if;

			if nvl(c_islem_cursor.bakiye_fazla,0) > 0 then
			   boolean_list(pn_1603_fazla) := true;
			 else
			   boolean_list(pn_1603_eksik) := true;
			end if;

/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							ln_plan_no,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							ln_fis_no,
							ls_fis_aciklama);

  end loop;
    if nvl(ln_fis_no,0) <> 0 then
     	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
	end if;

/********kasa muhasebe sonrasi islemler ***/

	Bakiye_Kontrol(pn_islem_no ,'E');

	for c_bakiye in cur_bakiye loop
		r_bakiye:=c_bakiye;
	end loop;

   	select durum_kodu
	into ls_durum
	from cbs_kasa_kullanici_tanim
	where kasa_kodu = r_bakiye.kasa_kodu and
		  sube_kodu = r_bakiye.sube_kodu and
		  tanim_no = r_bakiye.tanim_no ;

	 if ls_durum = 'ACIK' then
			update cbs_kasa_kullanici_tanim
			set durum_kodu = 'KAPALI',
				KULLANICI_KODU = NULL,
				kapama_tarihi = pkg_muhasebe.banka_tarihi_bul
			where kasa_kodu = r_bakiye.kasa_kodu and
				  sube_kodu = r_bakiye.sube_kodu and
				  tanim_no = r_bakiye.tanim_no ;
	else
		raise kasa_kapali;
	end if;
	Exception when kasa_kapali then
	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '767' || pkg_hata.getUCPOINTER);
  End;

  Procedure Bakiye_Kontrol(pn_islem_no number,ps_bakiye_guncelle varchar2 default 'H' )
  is
	ls_doviz varchar2(200);
	ln_adet  number := 0;
	ln_max_adet number := 5;
    ls_doviz_kodu varchar2(3);
	ls_kasa_kodu varchar2(200);
    ls_sube_kodu varchar2(200);

	cursor cur_doviz is
	 select distinct doviz_kodu
	 from  cbs_kasa_bakiye_islem b
	 where tx_no  = pn_islem_no and
	 	   ( nvl(bakiye_fazla,0) <>0  or nvl(bakiye_eksik,0) <> 0) and
	 	   doviz_kodu not in ( select distinct doviz_kodu
		   			  	  	   from cbs_kasa_kupur_bakiye_islem
		   			  	  	   where tx_no =pn_islem_no);

	cursor cur_bakiye is
	 select  a.kasa_kodu,
	 		 a.sube_kodu,
	 		 a.doviz_kodu,
	 		 (nvl(a.bakiye,0) +  nvl(bakiye_fazla,0)  - nvl(bakiye_eksik,0)) bakiye_kasa
	 from  cbs_kasa_bakiye_islem b ,
	 	   cbs_kasa_bakiye a ,
		 (select  tx_no ,
		 		  KASA_KODU,
				  SUBE_KODU,
				  DOVIZ_KODU ,
				  sum( nvl(kupur_bakiye,0)) kupur_bakiye
		 from    cbs_kasa_kupur_bakiye_islem
		 group by tx_no ,
		 		  KASA_KODU,
				  SUBE_KODU,
				  DOVIZ_KODU )	c
	 where b.tx_no  = pn_islem_no and
	 	   b.KASA_KODU =a.kasa_kodu and
		   b.SUBE_KODU =a.sube_kodu and
		   b.DOVIZ_KODU = a.doviz_kodu and
		   b.BANKA_TARIHI = a.banka_tarihi and
		   b.tx_no  = c.tx_no and
	 	   b.KASA_KODU =c.kasa_kodu and
		   b.SUBE_KODU =c.sube_kodu and
		   b.DOVIZ_KODU = c.doviz_kodu and
		   c.kupur_bakiye <>  (nvl(a.bakiye,0) +  nvl(bakiye_fazla,0)  - nvl(bakiye_eksik,0))  ;

	bakiye_buyuk 		   exception;
	karsilanmadi 		   exception;
	max_doviz_asildi 	   exception;

	cursor cur_bakiye_islem is
	  select
	  	  tx_no,
		  doviz_kodu,
		  kasa_kodu,
		  sube_kodu,
		  bakiye_fazla,
		  bakiye_eksik,
		  banka_tarihi
	  from cbs_kasa_bakiye_islem
	  where tx_no = pn_islem_no;

	cursor cur_kupur_bakiye_islem is
	  select
	  	  tx_no,
		  doviz_kodu,
		  kasa_kodu,
		  sube_kodu,
		  banka_tarihi,
		  nvl(kupur_adedi,0) kupur_adedi,
		  kupur_kodu
	  from cbs_kasa_kupur_bakiye_islem
	  where tx_no = pn_islem_no;


 Begin

	update cbs_kasa_kupur_bakiye_islem
	set kupur_bakiye = nvl(kupur_Adedi,0)* nvl(kupur_kodu,0)
	where tx_no = pn_islem_no ;

	ls_doviz := null;
	for c_doviz in cur_doviz loop
		ls_doviz := c_doviz.doviz_kodu ;
	end loop;

	if ls_doviz is not null then
	  raise karsilanmadi;
	 end if;

	 ls_doviz := null;
 	 for  c_bakiye in cur_bakiye loop
	 	 ls_doviz := c_bakiye.doviz_kodu;
	 end loop;

	if ls_doviz is not null then
	  raise karsilanmadi;
	 end if;

 	if ps_bakiye_guncelle = 'E' Then
	   /* guncellenir */
	   for c_bakiye_islem in cur_bakiye_islem loop
  	   	    update cbs_kasa_bakiye
			set bakiye = nvl(bakiye,0) +  nvl(c_bakiye_islem.bakiye_fazla,0)  - nvl(c_bakiye_islem.bakiye_eksik,0)
			where  doviz_kodu = c_bakiye_islem.doviz_kodu and
				   sube_kodu =  c_bakiye_islem.sube_kodu and
				   kasa_kodu =  c_bakiye_islem.kasa_kodu and
				   banka_tarihi = c_bakiye_islem.banka_tarihi;
	 	end loop;


	   for c_kupbakiye_islem in cur_kupur_bakiye_islem loop
  	   	    update cbs_kasa_kupur_bakiye
			set kupur_adedi = c_kupbakiye_islem.kupur_adedi ,
				kupur_bakiye = c_kupbakiye_islem.kupur_adedi * kupur_kodu
			where  doviz_kodu = c_kupbakiye_islem.doviz_kodu and
				   sube_kodu =  c_kupbakiye_islem.sube_kodu and
				   kasa_kodu =  c_kupbakiye_islem.kasa_kodu and
				   banka_tarihi = c_kupbakiye_islem.banka_tarihi and
				   kupur_kodu =  c_kupbakiye_islem.kupur_kodu ;
	 	end loop;

	end if;

	Exception
	 when karsilanmadi then
	 	 		 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '760' ||  pkg_hata.getdelimiter|| to_char(ls_doviz) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  End;

  Function kupur_girisi_yapilmali(pn_islem_no number) return varchar2
  is
   ls_mevcut varchar2(1) := 'H';
  Begin
  	   select distinct 'E'
	   into  ls_mevcut
	   from   cbs_kasa_bakiye
	   where (kasa_kodu ,sube_kodu) in (select kasa_kodu,sube_kodu from cbs_kasa_islem
	   		 		   			  	 where tx_no= pn_islem_no)
			and nvl(bakiye,0) <> 0	 ;
	 return ls_mevcut;
	 Exception when others then return 'H';
  End;
Begin

	pn_1603_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1603_BANKA_ACIKLAMA');
	pn_1603_islem_sube :=pkg_muhasebe.parametre_index_bul('1603_ISLEM_SUBE');
	pn_1603_OUTLET_CASH_GL :=pkg_muhasebe.parametre_index_bul('1603_OUTLET_CASH_GL');
	pn_1603_kasa_eksik :=pkg_muhasebe.parametre_index_bul('1603_KASA_EKSIK');
	pn_1603_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1603_DOVIZ_KODU');
	pn_1603_fc_islem :=pkg_muhasebe.parametre_index_bul('1603_FC_ISLEM');
	pn_1603_kasa_fazla :=pkg_muhasebe.parametre_index_bul('1603_KASA_FAZLA');
	pn_1603_kasa_fazla_lc :=pkg_muhasebe.parametre_index_bul('1603_KASA_FAZLA_LC');
	pn_1603_referans :=pkg_muhasebe.parametre_index_bul('1603_REFERANS');
	pn_1603_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1603_ISTATISTIK_KODU');
	pn_1603_kur :=pkg_muhasebe.parametre_index_bul('1603_KUR');
	pn_1603_lc_islem :=pkg_muhasebe.parametre_index_bul('1603_LC_ISLEM');
	pn_1603_kasa_eksik_lc :=pkg_muhasebe.parametre_index_bul('1603_KASA_EKSIK_LC');
	pn_1603_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1603_MUSTERI_ACIKLAMA');
	pn_1603_eksik :=pkg_muhasebe.parametre_index_bul('1603_EKSIK');
	pn_1603_fazla :=pkg_muhasebe.parametre_index_bul('1603_FAZLA');

END;
/

