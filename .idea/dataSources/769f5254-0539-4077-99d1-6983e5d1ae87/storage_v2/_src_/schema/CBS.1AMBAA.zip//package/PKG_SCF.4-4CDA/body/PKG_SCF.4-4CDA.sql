create PACKAGE BODY Pkg_Scf IS

  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;

------------------------------------------------------------------------------------------
  PROCEDURE gecerli_orani_kopyala(pn_tx_no NUMBER) IS
  BEGIN
  	INSERT INTO CBS_SCF_ORANI_GIRIS_DETAY (tx_no,doviz_kodu,faiz_orani)
  	  SELECT pn_tx_no,doviz_kodu,faiz_orani FROM CBS_SCF_ORANLARI WHERE TRUNC(islem_tarihi)=TRUNC(Pkg_Muhasebe.banka_tarihi_bul);
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2506' || Pkg_Hata.getUCPOINTER);
    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2507' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
------------------------------------------------------------------------------------------
  PROCEDURE onceki_oranlari_bugune_kopyala IS
  BEGIN
  	INSERT INTO CBS_SCF_ORANLARI (islem_tarihi,doviz_kodu,faiz_orani)
  	     SELECT Pkg_Muhasebe.banka_tarihi_bul,doviz_kodu,faiz_orani
  	       FROM CBS_SCF_ORANLARI
  	      WHERE TRUNC(islem_tarihi)=TRUNC(Pkg_Muhasebe.onceki_banka_tarihi_bul);
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
	    NULL; -- Daha once yaratilmis, yeniden yaratilmamali
    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2507' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
  END;
------------------------------------------------------------------------------------------
   PROCEDURE Orani_guncelle(pn_tx_no NUMBER) IS
     ld_islem_tarihi				 DATE;
	 ls_doviz_kodu					 VARCHAR2(3);
	 ln_faiz_orani					 NUMBER;

	 CURSOR c1 IS
     SELECT islem_tarihi,doviz_kodu,faiz_orani
	   FROM CBS_SCF_ORANI_GIRIS,CBS_SCF_ORANI_GIRIS_DETAY
      WHERE CBS_SCF_ORANI_GIRIS.tx_no=CBS_SCF_ORANI_GIRIS_DETAY.tx_no
        AND CBS_SCF_ORANI_GIRIS.tx_no=pn_tx_no;

   BEGIN
     OPEN c1;
     LOOP
	   FETCH c1 INTO ld_islem_tarihi,ls_doviz_kodu,ln_faiz_orani;
	   EXIT WHEN c1%NOTFOUND;

	   BEGIN
    	   INSERT INTO CBS_SCF_ORANLARI(islem_tarihi,doviz_kodu,faiz_orani)
     	        VALUES (ld_islem_tarihi,ls_doviz_kodu,ln_faiz_orani);
       EXCEPTION
         WHEN DUP_VAL_ON_INDEX THEN
           BEGIN
   	         UPDATE CBS_SCF_ORANLARI
		        SET faiz_orani=ln_faiz_orani
  	          WHERE islem_tarihi=ld_islem_tarihi
		        AND doviz_kodu=ls_doviz_kodu;
	       EXCEPTION
	         WHEN OTHERS THEN
	            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2509' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	       END;
	   END;

	 END LOOP;
	 CLOSE c1;

  EXCEPTION
    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2508' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END;
------------------------------------------------------------------------------------------
   PROCEDURE vadeli_scf_gec_orani_kopyala(pn_tx_no NUMBER,pd_tarih DATE,pc_tur VARCHAR2,pc_rating_kodu VARCHAR2,pc_faiz_tur VARCHAR2) IS
   BEGIN

	INSERT INTO CBS_VADELI_SCF_ORANLARI_ISL_DE (tx_no,vade_araligi,scf_urun_grubu_kod,trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani)
	     SELECT pn_tx_no,vade_araligi,scf_urun_grubu_kod,trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani
		  FROM  CBS_VADELI_SCF_ORANLARI
		  WHERE TRUNC(tarih)=TRUNC(pd_tarih)
		    AND tur=pc_tur
			AND rating_kodu=pc_rating_kodu
			AND faiz_tur=pc_faiz_tur;

  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2744' || Pkg_Hata.getUCPOINTER);
    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2745' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END;

------------------------------------------------------------------------------------------
   PROCEDURE Vadeli_scf_orani_guncelle(pn_tx_no NUMBER) IS

	 CURSOR c1 IS
     SELECT tarih,tur,faiz_tur,rating_kodu,vade_araligi,scf_urun_grubu_kod,
	        trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani
	   FROM CBS_VADELI_SCF_ORANLARI_ISL,CBS_VADELI_SCF_ORANLARI_ISL_DE
      WHERE CBS_VADELI_SCF_ORANLARI_ISL.tx_no=CBS_VADELI_SCF_ORANLARI_ISL_DE.tx_no
        AND CBS_VADELI_SCF_ORANLARI_ISL.tx_no=pn_tx_no;

	 r_c1							  c1%ROWTYPE;

   BEGIN
     OPEN c1;
     LOOP
	   FETCH c1 INTO r_c1;
	   EXIT WHEN c1%NOTFOUND;

	   BEGIN
    	   INSERT INTO CBS_VADELI_SCF_ORANLARI (tarih,tur,faiz_tur,rating_kodu,vade_araligi,scf_urun_grubu_kod,trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani)
     	        VALUES (r_c1.tarih,r_c1.tur,r_c1.faiz_tur,r_c1.rating_kodu,r_c1.vade_araligi,r_c1.scf_urun_grubu_kod,r_c1.trl_faiz_orani,r_c1.usd_faiz_orani,r_c1.eur_faiz_orani,r_c1.diger_faiz_orani);
       EXCEPTION
         WHEN DUP_VAL_ON_INDEX THEN
           BEGIN
   	         UPDATE CBS_VADELI_SCF_ORANLARI
		        SET trl_faiz_orani=r_c1.trl_faiz_orani,
					usd_faiz_orani=r_c1.usd_faiz_orani,
					eur_faiz_orani=r_c1.eur_faiz_orani,
					diger_faiz_orani=r_c1.diger_faiz_orani
  	          WHERE tarih=r_c1.tarih
				AND tur=r_c1.tur
				AND faiz_tur=r_c1.faiz_tur
				AND	rating_kodu=r_c1.rating_kodu
				AND	vade_araligi=r_c1.vade_araligi
				AND	scf_urun_grubu_kod=r_c1.scf_urun_grubu_kod;
	       EXCEPTION
	         WHEN OTHERS THEN
	            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2747' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
	       END;
	   END;

	 END LOOP;
	 CLOSE c1;

  EXCEPTION
    WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2508' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END;
------------------------------------------------------------------------------------------
   PROCEDURE Vadeli_SCF_Orani_Kopyala IS
   BEGIN
  	 INSERT INTO CBS_VADELI_SCF_ORANLARI (tarih,tur,faiz_tur,rating_kodu,vade_araligi,scf_urun_grubu_kod,trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani)
  	     SELECT Pkg_Muhasebe.banka_tarihi_bul,tur,faiz_tur,rating_kodu,vade_araligi,scf_urun_grubu_kod,trl_faiz_orani,usd_faiz_orani,eur_faiz_orani,diger_faiz_orani
  	       FROM CBS_VADELI_SCF_ORANLARI
  	      WHERE TRUNC(tarih)=TRUNC(Pkg_Muhasebe.onceki_banka_tarihi_bul);
   EXCEPTION
     WHEN DUP_VAL_ON_INDEX THEN
	    NULL; -- Daha once yaratilmis, yeniden yaratilmamali
     WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2787' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
   END;
------------------------------------------------------------------------------------------
   FUNCTION  Vadeli_sch_faiz_orani(pn_musterino NUMBER,
   			 					   ps_doviz_kodu VARCHAR2,
   			 					   ps_modul_tur_kod VARCHAR2,
								   ps_urun_tur_kod VARCHAR2,
								   ps_urun_sinif_kod VARCHAR2,
								   pn_gun_sayisi NUMBER ,
								   ps_faiz_tur VARCHAR2 DEFAULT 'S',
								   ps_overnight_evet VARCHAR2 DEFAULT 'H',
								   pd_kredi_vade DATE DEFAULT NULL) RETURN NUMBER
  IS
  ln_faiz_orani		NUMBER := 0;

 CURSOR cursor_sch IS
 SELECT
		NVL(  DECODE(ps_doviz_kodu,'USD',USD_FAIZ_ORANI,
			  'EUR',EUR_FAIZ_ORANI, Pkg_Genel.LC_AL,TRL_FAIZ_ORANI,DIGER_FAIZ_ORANI),0) faiz_orani
	FROM
		 CBS_VADELI_SCF_ORANLARI S,
		 CBS_MUSTERI m,
		 CBS_VADE_ARALIKLARI a,
		 CBS_SCF_URUN_GRUBU_URUN u
	WHERE
		 m.MUSTERI_NO=pn_musterino
		 AND m.RATING_KODU = S.RATING_KODU
		 AND a.kod=S.VADE_ARALIGI
		 AND pn_gun_sayisi BETWEEN a.BASLANGIC AND a.BITIS
		 AND S.SCF_URUN_GRUBU_KOD=u.KOD
		 AND u.MODUL_TUR_KOD=ps_modul_tur_kod
		 AND u.URUN_TUR_KOD=ps_urun_tur_kod
		 AND u.URUN_SINIF_KOD=ps_urun_sinif_kod
		 AND faiz_tur =  ps_faiz_tur;

 CURSOR cursor_sch1 IS
 SELECT
		NVL(  DECODE(ps_doviz_kodu,'USD',USD_FAIZ_ORANI,
			  'EUR',EUR_FAIZ_ORANI, Pkg_Genel.LC_AL,TRL_FAIZ_ORANI,DIGER_FAIZ_ORANI),0) faiz_orani
	FROM
		 CBS_VADELI_SCF_ORANLARI S,
		 CBS_MUSTERI m,
		 CBS_VADE_ARALIKLARI a,
		 CBS_SCF_URUN_GRUBU_URUN u
	WHERE
	 	 a.kod = 'ON'
		 AND m.MUSTERI_NO=pn_musterino
		 AND m.RATING_KODU = S.RATING_KODU
		 AND a.kod=S.VADE_ARALIGI
		-- and pn_gun_sayisi between a.BASLANGIC and a.BITIS
		 AND S.SCF_URUN_GRUBU_KOD=u.KOD
		 AND u.MODUL_TUR_KOD=ps_modul_tur_kod
		 AND u.URUN_TUR_KOD=ps_urun_tur_kod
		 AND u.URUN_SINIF_KOD=ps_urun_sinif_kod
		 AND faiz_tur =  ps_faiz_tur;

BEGIN
/* nakdi kredilerde overnight orani E olarak gonderilir ve kredi vadesi sonraki is gunune esit ise ON orani al?n?r */
   IF ps_overnight_evet = 'E' AND pd_kredi_vade = Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.banka_tarihi_bul) THEN
      FOR cur_sch IN cursor_sch1 LOOP
		   ln_faiz_orani := cur_sch.faiz_orani;
	  END LOOP;
	ELSE
		FOR cur_sch IN cursor_sch LOOP
		   ln_faiz_orani := cur_sch.faiz_orani;
		END LOOP;
   END IF;

	RETURN NVL(ln_faiz_orani,0);

EXCEPTION
	WHEN NO_DATA_FOUND THEN RETURN 0;
--	 	  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '3643' || pkg_hata.getdelimiter || pn_musterino  || pkg_hata.getdelimiter || ps_modul_tur_kod ||  pkg_hata.getdelimiter || ps_urun_tur_kod || pkg_hata.getdelimiter || ps_urun_sinif_kod || pkg_hata.getdelimiter || pn_gun_sayisi || pkg_hata.getUCPOINTER);
END;
------------------------------------------------------------------------------------------

 PROCEDURE sch_faiz_guncelle_bilgi_aktar(pn_islem_no IN NUMBER, pn_hesap_no IN NUMBER, ps_hesap_tipi VARCHAR2) IS
 BEGIN

	 IF ps_hesap_tipi = 'KREDI' THEN
		 INSERT INTO CBS_SCF_ORAN_TUTAR_GUNCELLEME
		 SELECT pn_islem_no, 'Y', sube_kodu, ps_hesap_tipi,musteri_no, doviz_kodu, hesap_no, urun_tur_kod,
		 		urun_sinif_kod,Pkg_Hesap.HesapBakiyeAl(hesap_no), faiz_orani, SCH_FAIZ_TUR, SCH_FAIZ_ORANI, NULL,
				birikmis_sch_faizi, NULL, gecenyil_sch_faizi
		 FROM   CBS_HESAP_KREDI
		 WHERE  hesap_no = pn_hesap_no;
	 ELSE
		 INSERT INTO CBS_SCF_ORAN_TUTAR_GUNCELLEME
		 SELECT pn_islem_no, 'Y', sube_kodu, ps_hesap_tipi, musteri_no, doviz_kodu, hesap_no, urun_tur_kod,
		 		urun_sinif_kod,Pkg_Hesap.HesapBakiyeAl(hesap_no), faiz_orani, 'S', SCH_FAIZ_ORANI, NULL,
				sch_birikmis_faizi, NULL, SCH_GECENYIL_FAIZI
		 FROM   CBS_HESAP_VADELI
		 WHERE  hesap_no = pn_hesap_no;
	 END IF;

  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2053' ||  Pkg_Hata.getDelimiter ||
                              Pkg_Hata.getDelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
 END;
------------------------------------------------------------------------------------------

 PROCEDURE sch_faiz_tahakkuk_bilgi_aktar(pn_islem_no IN NUMBER, pn_hesap_no IN NUMBER, ps_hesap_tipi VARCHAR2) IS
 BEGIN

	 IF ps_hesap_tipi = 'KREDI' THEN
		 INSERT INTO CBS_SCF_TAHAKKUKU
		 SELECT pn_islem_no, 'Y', sube_kodu, ps_hesap_tipi,musteri_no, doviz_kodu, hesap_no, urun_tur_kod,
		 		urun_sinif_kod,Pkg_Hesap.HesapBakiyeAl(hesap_no),TAHAKKUK_SCH_FAIZ_TUTARI,NULL,NULL,NULL
		 FROM   CBS_HESAP_KREDI
		 WHERE  hesap_no = pn_hesap_no;
	 ELSE
		 INSERT INTO CBS_SCF_TAHAKKUKU
		 SELECT pn_islem_no, 'Y', sube_kodu, ps_hesap_tipi, musteri_no, doviz_kodu, hesap_no, urun_tur_kod,
		 		urun_sinif_kod,Pkg_Hesap.HesapBakiyeAl(hesap_no),TAHAKKUK_EDEN_SCH_TUTARI,NULL,NULL,NULL
		 FROM   CBS_HESAP_VADELI
		 WHERE  hesap_no = pn_hesap_no;
	 END IF;

  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2053' ||  Pkg_Hata.getDelimiter ||
                              Pkg_Hata.getDelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
 END;

 -----------------------------------------------------------------------------------
END;
/

