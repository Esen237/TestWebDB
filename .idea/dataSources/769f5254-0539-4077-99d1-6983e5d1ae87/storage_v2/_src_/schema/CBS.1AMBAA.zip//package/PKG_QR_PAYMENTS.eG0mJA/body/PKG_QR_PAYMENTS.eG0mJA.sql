create PACKAGE BODY     "PKG_QR_PAYMENTS" IS
--STEP1
---------------------------ADMIN - For Adding new Bank **----------------------------
PROCEDURE Participant_Banks_Add ( 
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2 DEFAULT '0',
                                 pd_registration_date    DATE DEFAULT SYSDATE,
                                 pd_closing_date         DATE DEFAULT NULL,
                                 pd_closed_user          VARCHAR2 DEFAULT NULL                                     
                                 ) IS 




BEGIN

 
 INSERT INTO qroperator_app.participant_banks
        (bank_id,
         bank_name,
         tax_no,
         bic,
         --bank_account,
         website,
         contact_email,
         contact_phone,
         ip,
         registration_date,
         status,
         closing_date,
         closed_user,
         address)
 VALUES(seq.nextval,
        ps_bank_name,        
        pn_tax_no,
        pn_bic,
        ps_website,
        ps_contact_email,
        ps_contact_phone,
        ps_ip,       
      nvl(pd_registration_date,sysdate),
        ps_status,
        pd_closing_date,
        pd_closed_user,
        ps_address);  
          
 COMMIT;
 
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 

END;
---------------------------**ADMIN- For Updating Bank **----------------------------
PROCEDURE Participant_Banks_Update (ps_bank_id              NUMBER, --add unique constraint 
                                 ps_bank_name            VARCHAR2,
                                 pn_bic                  NUMBER,
                                 pn_tax_no               NUMBER,--ИНН
                                 ps_address              VARCHAR2,
                                 ps_ip                   VARCHAR2,
                                 ps_website              VARCHAR2,
                                 ps_contact_email        VARCHAR2, 
                                 ps_contact_phone        VARCHAR2,
                                 ps_status               VARCHAR2,
                                 pd_registration_date    DATE ,  
                                 pd_closing_date         DATE, 
                                 pd_closed_user          VARCHAR2                                                  
                                 ) IS 




BEGIN

 
 UPDATE qroperator_app.participant_banks
       SET 
           --bank_name=ps_bank_name,
           tax_no=pn_tax_no,
           bic=pn_bic,
           website=ps_website,
           contact_email=ps_contact_email,
           contact_phone=ps_contact_phone,
           ip=ps_ip,
--           registration_date=pd_registration_date,
           status=ps_status,
           closed_user=pd_closed_user,
           closing_date=pd_closing_date,
           address=ps_address
     WHERE bank_id=ps_bank_id;
          
 COMMIT;
 
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 

END;

---------------------------**ADMIN- For Adding new Application under Bank **----------------------------
PROCEDURE  Participant_Apps_Add (pn_bank_id              NUMBER,
                            -- pn_app_id               NUMBER , --add unique constraint 
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         VARCHAR2,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             pd_registration_date    DATE DEFAULT SYSDATE, 
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE DEFAULT NULL,
                             ps_closed_user          VARCHAR2 DEFAULT NULL ,
                             ps_port                 VARCHAR2,
                             ps_path                 VARCHAR2                                        
                               ) IS 


BEGIN

  INSERT INTO qroperator_app.participant_apps
        (bank_id,
         app_id,
         app_name,
         app_type,
         bank_account,
         app_tax_number,
         address,
         qr_provider,
         ip_address,
         contact_email,
         contact_phone,
         status,
         registration_date,
         created_user,
         closing_date,
         closed_user,
         port,
         path )
 VALUES(pn_bank_id,
        seq.nextval,
        ps_app_name,
        ps_app_type,
        pn_bank_account,
        ps_app_tax_number,
        ps_address ,
        ps_qr_provider,
        ps_ip_address,
        ps_contact_email, 
        ps_contact_phone,
        ps_status,
        nvl(pd_registration_date,sysdate),
        ps_created_user,                         
        pd_closing_date, 
        ps_closed_user,
        ps_port,
        ps_path 
       ); 
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END;

---------------------------**ADMIN- For Updating  Application **----------------------------
PROCEDURE  Participant_Apps_Update (pn_bank_id              NUMBER,
                             pn_app_id               NUMBER,
                             ps_app_name             VARCHAR2,
                             ps_app_type             VARCHAR2,
                             pn_bank_account         VARCHAR2,
                             ps_app_tax_number       VARCHAR2,--ИНН
                             ps_address              VARCHAR2,
                             ps_qr_provider          VARCHAR2,
                             ps_ip_address           VARCHAR2,
                             ps_contact_email        VARCHAR2, 
                             ps_contact_phone        VARCHAR2,
                             ps_status               VARCHAR2,
                             ps_created_user         VARCHAR2,                         
                             pd_closing_date         DATE,
                             ps_closed_user          VARCHAR2,
                             ps_port                 VARCHAR2,
                             ps_path                 VARCHAR2                                         
                               ) IS 


BEGIN
	

  UPDATE qroperator_app.participant_apps
     SET 
         
         --app_name=ps_app_name,
         app_type=ps_app_type,
         bank_account=pn_bank_account,
         app_tax_number=ps_app_tax_number,
         address=ps_app_tax_number,
        -- qr_provider=ps_qr_provider,
         ip_address=ps_ip_address,
         contact_email=ps_contact_email,
         contact_phone=ps_contact_phone,
         status=ps_status,
         created_user=ps_created_user,
         closing_date=pd_closing_date,
         closed_user=ps_closed_user,
         port=ps_port,
         path=ps_path
   WHERE bank_id=pn_bank_id and  app_id=pn_app_id;
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END;

---------------------------** For setting new and updating current  Bank limits **----------------------------
PROCEDURE  Bank_Limit_Setting(pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE,
                              ps_type                VARCHAR2
                              ) IS                            
  ln_count_rec NUMBER;
  bank_limit_error EXCEPTION;
--  bank_currently_added  EXCEPTION;
  
                            
  ln_count_state NUMBER;    
  ln_count_bank NUMBER;    
                           
BEGIN


log_at ('banklimit', ps_type,pn_bank_limit);
/*log_at('Bank_Limit_Setting',1,'pn_bank_id'||' '||pn_bank_id||' / '||
                           'pn_bank_limit'||' '||pn_bank_limit||' / '||
                         'ps_created_user'||' '||ps_created_user||' / '||
                        'pd_creation_date'||' '||pd_creation_date);*/

--     SELECT COUNT(*)
--        INTO ln_count_state
--         FROM qroperator_app.bank_limit_settings 
--       WHERE bank_id = pn_bank_id AND state='NEW';
       
--IF ln_count_state >0 THEN

     SELECT COUNT(*)
        INTO ln_count_rec
         FROM qroperator_app.bank_limit_settings 
       WHERE bank_id = pn_bank_id;
       
IF ln_count_rec>0 THEN 
        
--       SELECT COUNT(*)
--        INTO ln_count_bank
--         FROM qroperator_app.bank_limit_settings 
--       WHERE bank_id = pn_bank_id
--        AND state<>'NEW'
--        AND  bank_limit = pn_bank_limit ;
--       
--       IF ln_count_bank>0 THEN
--       RAISE bank_currently_added;
--       END IF;
--       
--       
--  
       SELECT COUNT(*)
        INTO ln_count_state
         FROM qroperator_app.bank_limit_settings 
       WHERE bank_id = pn_bank_id and state='NEW';
        
       if   ln_count_state =0 then --  ln_count_state >0 then 
       
     
             INSERT INTO qroperator_app.bank_limit_settings_log
                    (bank_id,
                     bank_limit,
                     credit_limit,
                     debit_limit,
                     created_user,
                     creation_date,
                     is_active,
                     bank_bic,
                     transaction_number)
            (SELECT bank_id,
                    bank_limit,
                    credit_limit,
                    debit_limit,
                    created_user,
                    creation_date,
                    'NO',
                     bank_bic,
                   transaction_number                   
            FROM qroperator_app.bank_limit_settings WHERE bank_id = pn_bank_id );
     
     
--          SELECT COUNT(*)
--            INTO ln_count_state
--             FROM qroperator_app.bank_limit_settings 
--           WHERE bank_id = pn_bank_id;
     
     
         IF ps_type ='CREA' THEN
         
           
            
             UPDATE qroperator_app.bank_limit_settings
               SET 
                  -- bank_limit=bank_limit+pn_bank_limit,
                   credit_limit=pn_bank_limit,
                   debit_limit=0,--?
                   created_user=ps_created_user,
                   creation_date=nvl(pd_creation_date,sysdate),
                   state='NEW',
                   bank_bic=PKG_QR_PAYMENTS.GET_BANK_BIC_BY_ID(pn_bank_id),         
                   transaction_number=corpint.pkg_common.getsequenceid('sqQR_TRX'),
                   type='CREA'
               WHERE bank_id=pn_bank_id;
         
         ELSIF ps_type ='RLSE' THEN 
          
            
            
             UPDATE qroperator_app.bank_limit_settings
               SET  
                 -- bank_limit=bank_limit-pn_bank_limit,
                   credit_limit=0,--?
                   debit_limit=pn_bank_limit,
                   created_user=ps_created_user,
                   creation_date=nvl(pd_creation_date,sysdate),
                   state='NEW',
                   bank_bic=PKG_QR_PAYMENTS.GET_BANK_BIC_BY_ID(pn_bank_id),         
                   transaction_number=corpint.pkg_common.getsequenceid('sqQR_TRX'),
                   type='RLSE'
               WHERE bank_id=pn_bank_id;

         
         END IF;
    
         ELSE
         
         Log_at('raiselog','1');
         
                        RAISE bank_limit_error; --финальный результат 

     END IF;


ELSE     
--             SELECT COUNT(*)
--        INTO ln_count_rec
--         FROM qroperator_app.bank_limit_settings 
--       WHERE bank_id = pn_bank_id;
--             Log_at('raiselog','2');
--       IF  ln_count_rec=0 
--       then   
          
  
  INSERT INTO qroperator_app.bank_limit_settings
                (bank_id, 
                 bank_limit, 
                 credit_limit,
                 debit_limit,
                 created_user,
                 creation_date,
                 state,
                 bank_bic,
                 transaction_number,
                 type
                )
        VALUES(pn_bank_id,
               0,
               pn_bank_limit,
               0,
               ps_created_user,
               nvl(pd_creation_date,sysdate),
               'NEW',
               PKG_QR_PAYMENTS.GET_BANK_BIC_BY_ID(pn_bank_id),
               corpint.pkg_common.getsequenceid('sqQR_TRX'),
               'CREA'     
               );    

--else  raise  bank_currently_added; end if ; 
-- RAISE bank_currently_added;

END IF;


 COMMIT;

EXCEPTION
--WHEN bank_currently_added THEN
--    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'20140'|| pkg_hata.getDELIMITER );

WHEN bank_limit_error THEN
    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'20139'|| pkg_hata.getDELIMITER );
  
-- 
--WHEN OTHERS THEN
--   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
--           
END;

---------------------------** For setting new and updating current  App limits **----------------------------
PROCEDURE  App_Limit_Setting (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              pn_app_limit           NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE
                              ) IS
   ln_count_rec NUMBER; 
   ln_app_limit NUMBER; 
   ln_bank_limit NUMBER; 
   limit_error EXCEPTION;                         
BEGIN


    ln_app_limit :=0; 
    ln_bank_limit :=0;

    SELECT SUM(NVL(app_limit,0)) 
      INTO ln_app_limit
    FROM qroperator_app.app_limit_settings 
     WHERE bank_id = pn_bank_id 
      AND app_id<>pn_app_id;


  SELECT NVL(bank_limit,0) 
      INTO ln_bank_limit
    FROM qroperator_app.bank_limit_settings 
    WHERE bank_id = pn_bank_id ;

    ln_app_limit :=ln_app_limit+pn_app_limit;

    IF ln_app_limit>ln_bank_limit THEN

    RAISE limit_error;

    END IF;

      SELECT COUNT(*)
        INTO ln_count_rec
         FROM qroperator_app.app_limit_settings 
       WHERE bank_id = pn_bank_id AND app_id=pn_app_id;
       
    

 IF ln_count_rec>0 THEN

     INSERT INTO qroperator_app.app_limit_settings_log
            (bank_id,
             app_id,
             app_limit,
             created_user,
             creation_date,
             is_active
            )
    (SELECT bank_id,
            app_id,
            app_limit,
            created_user,
            creation_date,
            'NO'  
     FROM qroperator_app.app_limit_settings  WHERE bank_id = pn_bank_id AND app_id=pn_app_id     
           );
           
     UPDATE qroperator_app.app_limit_settings
           SET 
               app_id=pn_app_id,
               app_limit=pn_app_limit,
               created_user=ps_created_user,
               creation_date=NVL(pd_creation_date,SYSDATE)
               WHERE bank_id=pn_bank_id;
 ELSE
        
     INSERT INTO qroperator_app.app_limit_settings
            (bank_id,
             app_id,
             app_limit,
             created_user,
             creation_date
            )
     VALUES(pn_bank_id,
            pn_app_id,
            pn_app_limit,
            ps_created_user,
            NVL(pd_creation_date,SYSDATE)      
           );
 
 END IF;

  COMMIT;

EXCEPTION
WHEN limit_error THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
   
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,pkg_hata.getUCPOINTER||'20137'|| pkg_hata.getDELIMITER); 
           
END;

---------------------------**ADMIN  For commission definition on Application base  **----------------------------
PROCEDURE  App_Comission_Def (pn_bank_id             NUMBER,
                              pn_app_id              NUMBER,
                              ps_comission_code      VARCHAR2,
                              ps_comission_rate      VARCHAR2,
                              ps_is_fix_comission    VARCHAR2,                         
                              ps_is_exemption        VARCHAR2
                              ) IS
  ln_count_rec NUMBER;                            
  comission_error EXCEPTION;
                           
BEGIN


     SELECT COUNT(*)
        INTO ln_count_rec
         FROM qroperator_app.app_commission_def 
       WHERE app_id = pn_app_id;

IF ln_count_rec>0 THEN

RAISE comission_error;

END IF;


 INSERT INTO qroperator_app.app_commission_def
        (bank_id,         
         app_id,
         comission_code,
         comission_rate,
         is_fix_comission,
         is_exemption
        )
 VALUES(pn_bank_id,
        pn_app_id,
        ps_comission_code,
        ps_comission_rate,
        ps_is_fix_comission,                         
        ps_is_exemption            
       );
 COMMIT;

EXCEPTION
WHEN comission_error THEN
   Raise_application_error(-20100,pkg_hata.getUCPOINTER||'20141'|| pkg_hata.getDELIMITER );
        
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
           
END;

---------------------------**ADMIN  For adding new users under Bank **----------------------------
PROCEDURE  Add_App_Users (pn_bank_id             NUMBER,                        
                          ps_username            VARCHAR2,
                          ps_password            VARCHAR2,
                          pn_role                NUMBER,
                          ps_status              VARCHAR2,                         
                          ps_is_exemption        VARCHAR2,
                          ps_created_user        VARCHAR2,
                          pd_create_date         DATE DEFAULT SYSDATE,
                          ps_deactivate_user     VARCHAR2,
                          pd_deactivate_date     DATE,
                          pn_app_id              NUMBER 
                          ) IS
BEGIN

 INSERT INTO qroperator_app.remote_users
        (bank_id,
        username,
        password,
        role,
        status,
        created_user,
        create_date,
        deactivate_user,
        deactivate_date,
        app_id         
        )
 VALUES(pn_bank_id,                        
        ps_username,
        ps_password,
        pn_role,
        ps_status,                                
        ps_created_user,
        sysdate, --miraidat2101
        ps_deactivate_user,
        pd_deactivate_date,
        pn_app_id             
       );

 COMMIT;
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;

---------------------------**ADMIN  For updating users under bank **----------------------------
PROCEDURE  Update_App_Users (pn_bank_id             NUMBER,                        
                             ps_username            VARCHAR2,
                             pn_role                NUMBER,
                             ps_status              VARCHAR2,                                                   
                             ps_deactivate_user     VARCHAR2,
                             pd_deactivate_date     DATE,
                             ps_changed_user       VARCHAR2

                          ) IS
BEGIN

 UPDATE qroperator_app.remote_users
     SET 
        --password=ps_password,
        role=pn_role,
        status=ps_status,        
      deactivate_user=ps_deactivate_user,
        deactivate_date=pd_deactivate_date
       -- force_password = ps_force_password*/
--        app_id  = pn_app_id    miraidat2101
 WHERE username=ps_username AND bank_id=pn_bank_id;  
 
 
 
 
  INSERT INTO QROPERATOR_APP.REMOTE_USERS_LOG 
            (change_id,
             changed_item,
             changed_user,
             change_date) 
             VALUES (2, pn_role||'+'||ps_status,ps_changed_user, sysdate );
     COMMIT;

 COMMIT;
 
EXCEPTION
WHEN OTHERS THEN
  RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;


---------------------------**SYS-JOB For collecting EOD data   **----------------------------
PROCEDURE  Eod_Daily_Transactions IS

ls_expl VARCHAR2(200);
ls_ist_code VARCHAR2(200);
ls_code VARCHAR2(200);
ls_expl_1 VARCHAR2(2000);

CURSOR c1_eod_daily_transactions IS 
    SELECT *
    FROM qroperator_app.transactions
 WHERE execute_process_time >=SYSDATE-1 AND execute_process_time < SYSDATE AND final_status='50';

r_c1_eod_daily_transactions c1_eod_daily_transactions%ROWTYPE;

ls_tag varchar2(2000);
ln_count number;

BEGIN
OPEN c1_eod_daily_transactions;
   LOOP
       FETCH c1_eod_daily_transactions INTO r_c1_eod_daily_transactions;
       EXIT WHEN c1_eod_daily_transactions%NOTFOUND; 
 
        INSERT INTO qroperator_app.eod_daily_transactions      
          (operator_transaction_id,  
           bank_date ,
           bank_bic,
           bank_id,
           app_id,
           app_name,
           app_bank_account,
           transaction_type ,
           amount,
           comission,
           dt_cr_flag ,
           original_receipt_id ,
           execute_request_time,
           execute_process_time,
           status ,
           is_our_network,
           is_internal,
           currency_code)

        VALUES
           (r_c1_eod_daily_transactions.operator_transaction_id,--индекс
            trunc(SYSDATE-1),
            r_c1_eod_daily_transactions.sender_bank_bic,
            pkg_qr_payments.Get_Bank_ID_By_App(r_c1_eod_daily_transactions.sender_app_id),--r_c1_eod_daily_transactions.bank_id,--найти по app_id          с  participant apps
            r_c1_eod_daily_transactions.sender_app_id,
            pkg_qr_payments.Get_App_Name_By_App(r_c1_eod_daily_transactions.sender_app_id),-- r_c1_eod_daily_transactions.app_name,--найти по app_id       с     participant apps    
            pkg_qr_payments.Get_Bank_Account_By_App(r_c1_eod_daily_transactions.sender_app_id),-- r_c1_eod_daily_transactions.app_bank_account,--найти по app_id       с     participant apps
            r_c1_eod_daily_transactions.transaction_type,
            NVL(r_c1_eod_daily_transactions.qr_amount,0)*-1,
            r_c1_eod_daily_transactions.comission,
            'DT',--r_c1_eod_daily_transactions.db_cr_flag,--вручную DT или CR
            TO_NUMBER( r_c1_eod_daily_transactions.sender_receipt_no),   
            r_c1_eod_daily_transactions.execute_request_time,
            r_c1_eod_daily_transactions.execute_process_time,
            r_c1_eod_daily_transactions.final_status,
            r_c1_eod_daily_transactions.is_our_network,
            pkg_qr_payments.Is_Internal(r_c1_eod_daily_transactions.sender_bank_bic,  r_c1_eod_daily_transactions.beneficiary_bank_bic),
             r_c1_eod_daily_transactions.qr_currency_code
           -- r_c1_eod_daily_transactions.is_internal--через функ YES NO
            );
         

        INSERT INTO qroperator_app.eod_daily_transactions      
          (operator_transaction_id,  
           bank_date ,
           bank_bic,
           bank_id,
           app_id,
           app_name,
           app_bank_account,
           transaction_type ,
           amount,
           comission,
           dt_cr_flag ,
           original_receipt_id ,
           execute_request_time,
           execute_process_time,
           status ,
           is_our_network,
           is_internal,
           currency_code)

        VALUES
           (r_c1_eod_daily_transactions.operator_transaction_id,--индекс
            TRUNC(SYSDATE-1),
            r_c1_eod_daily_transactions.beneficiary_bank_bic,
            pkg_qr_payments.Get_Bank_ID_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),--r_c1_eod_daily_transactions.bank_id,--найти по app_id          с  participant apps
            r_c1_eod_daily_transactions.beneficiary_app_id,
            pkg_qr_payments.Get_App_Name_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),-- r_c1_eod_daily_transactions.app_name,--найти по app_id       с     participant apps    
            pkg_qr_payments.Get_Bank_Account_By_App(r_c1_eod_daily_transactions.beneficiary_app_id),-- r_c1_eod_daily_transactions.app_bank_account,--найти по app_id       с     participant apps
            r_c1_eod_daily_transactions.transaction_type,
            NVL(r_c1_eod_daily_transactions.qr_amount,0),
            r_c1_eod_daily_transactions.comission,
            'CR',--r_c1_eod_daily_transactions.db_cr_flag,--вручную DT или CR
             TO_NUMBER(r_c1_eod_daily_transactions.ben_receipt_no),   
            r_c1_eod_daily_transactions.execute_request_time,
            r_c1_eod_daily_transactions.execute_process_time,
            r_c1_eod_daily_transactions.final_status,
            r_c1_eod_daily_transactions.is_our_network,
            pkg_qr_payments.Is_Internal(r_c1_eod_daily_transactions.sender_bank_bic,  r_c1_eod_daily_transactions.beneficiary_bank_bic),
            r_c1_eod_daily_transactions.qr_currency_code
           -- r_c1_eod_daily_transactions.is_internal--через функ YES NO
            );  
    
    
    END LOOP;
CLOSE c1_eod_daily_transactions;
COMMIT;
END;

---------------------------**Function for using in  internal select  **----------------------------
FUNCTION Get_Bank_ID_By_App (pn_app_id NUMBER) RETURN NUMBER IS

ln_bank_id NUMBER;
  
  BEGIN
  
   SELECT bank_id 
     INTO  ln_bank_id
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;
  
  RETURN ln_bank_id; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;

---------------------------**Function for using in  internal select  **----------------------------
FUNCTION Get_App_Name_By_App (pn_app_id NUMBER) RETURN VARCHAR IS

ls_app_name VARCHAR2(200 BYTE);
  
  BEGIN
  
     SELECT app_name 
     INTO  ls_app_name
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;

  RETURN ls_app_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;


---------------------------**Function for using in  internal select  **----------------------------
FUNCTION Get_Bank_Account_By_App (pn_app_id NUMBER) RETURN NUMBER IS

ln_bank_account VARCHAR2(200 BYTE);
  
  BEGIN
  
     SELECT bank_account 
     INTO  ln_bank_account
       FROM qroperator_app.participant_apps
     WHERE app_id =pn_app_id;

  RETURN ln_bank_account; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;
---------------------------**SYS-API inserting QR transaction  data **----------------------------
PROCEDURE  QR_Transactions ( ps_operator_transaction_id    VARCHAR2,
                            pn_sender_bank_bic             NUMBER,
                            pn_sender_app_id               NUMBER,
                            pn_sender_customer_type        NUMBER,
                            ps_sender_transaction_no       VARCHAR2,--NUMBER,
                            ps_sender_receipt_no           VARCHAR2, --NUMBER,--VarCchar 2
                            pn_transaction_type            NUMBER,
                            ps_qr_type                     VARCHAR2,
                            ps_qr_merchant_provider        VARCHAR2,
                            ps_qr_merchant_id              VARCHAR2,
                            ps_qr_service_id               VARCHAR2,
                            ps_qr_service_name             VARCHAR2,
                            pn_qr_ben_account_number       VARCHAR2,
                            pn_qr_merchant_code            NUMBER,
                            pn_qr_currency_code            NUMBER,
                            ps_qr_transaction_id           VARCHAR2,
                            ps_qr_comment                  VARCHAR2,
                            pn_qr_amount                   NUMBER,
                            pn_comission                   NUMBER, 
                            ps_qr_link_hash                VARCHAR2, 
                            pd_create_request_time         DATE                 DEFAULT SYSDATE,
                            pn_beneficiary_bank_bic        NUMBER,
                            pn_beneficiary_app_id          NUMBER,
                            ps_beneficiary_name            VARCHAR2,
                            pn_ben_customer_type           NUMBER,
                            ps_ben_receipt_no              VARCHAR2,--NUMBER,
                            pd_create_response_time        DATE,
                            pn_create_status               NUMBER,
                            pd_execute_request_time        DATE,
                            pd_execute_process_time        DATE,
                            pd_error_time                  DATE,
                            pn_final_status                NUMBER,
                            ps_is_our_network              VARCHAR2, 
                            ps_other_operator_id           VARCHAR2           
                               ) IS 


BEGIN

   INSERT INTO qroperator_app.transactions 
     (operator_transaction_id,
      sender_bank_bic,
      sender_app_id,
      sender_customer_type,
      sender_transaction_no,
      sender_receipt_no,
      transaction_type,
      qr_type,
      qr_merchant_provider,
      qr_merchant_id,
      qr_service_id,
      qr_service_name,
      qr_ben_account_number,
      qr_merchant_code,
      qr_currency_code,
      qr_transaction_id,
      qr_comment,
      qr_amount,
      comission,
      qr_link_hash,
      create_request_time,
      beneficiary_bank_bic,
      beneficiary_app_id,
      beneficiary_name ,
      ben_customer_type ,
      ben_receipt_no,
      create_response_time,
      create_status,
      execute_request_time,
      execute_process_time,
      error_time,
      final_status,
      is_our_network,
      other_operator_id
      )
      
   VALUES(ps_operator_transaction_id,
          pn_sender_bank_bic,
          pn_sender_app_id,
          pn_sender_customer_type ,
          ps_sender_transaction_no,
          ps_sender_receipt_no,
          pn_transaction_type,
          ps_qr_type ,
          ps_qr_merchant_provider,
          ps_qr_merchant_id,
          ps_qr_service_id,
          ps_qr_service_name,
          pn_qr_ben_account_number ,
          pn_qr_merchant_code,
          pn_qr_currency_code,
          ps_qr_transaction_id,
          ps_qr_comment,
          pn_qr_amount ,
          pn_comission, 
          ps_qr_link_hash, 
          NVL(pd_create_request_time,SYSDATE),
          pn_beneficiary_bank_bic,
          pn_beneficiary_app_id ,
          ps_beneficiary_name,
          pn_ben_customer_type,
          ps_ben_receipt_no ,
          pd_create_response_time ,
          pn_create_status,
          pd_execute_request_time,
          pd_execute_process_time,
          pd_error_time,
          pn_final_status,
          ps_is_our_network,
          ps_other_operator_id);
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 

---------------------------**SYS-API inserting QR CHECK DATA  **----------------------------
PROCEDURE  QR_Check_Transactions (pn_sender_app_id              NUMBER,
                                  pn_sender_customer_type       NUMBER,
                                  ps_qr_type                    VARCHAR2,
                                  ps_qr_merchant_provider       VARCHAR2,
                                  ps_qr_merchant_id             VARCHAR2,
                                  ps_qr_service_id              VARCHAR2,
                                  ps_qr_service_name            VARCHAR2,
                                  ps_qr_ben_account_number      VARCHAR2,
                                  pn_qr_merchant_code           NUMBER,
                                  pn_qr_currency_code           NUMBER,
                                  ps_qr_transaction_id          VARCHAR2,
                                  ps_qr_comment                 VARCHAR2,
                                  pn_qr_amount                  NUMBER,
                                  ps_qr_link_hash               VARCHAR2,
                                  pd_requested_date             DATE ,
                                  pn_beneficiary_app_id_number  NUMBER,
                                  ps_beneficiary_name           VARCHAR2,
                                  pn_ben_customer_type          NUMBER,
                                  pn_operator_tran_type         NUMBER,
                                  pn_check_status               NUMBER,
                                  pd_response_date              DATE            
                               ) IS 


BEGIN

   INSERT INTO qroperator_app.check_transactions 
                          (operator_request_id,
                           sender_app_id,
                           sender_customer_type,
                           qr_type,
                           qr_merchant_provider,
                           qr_merchant_id ,
                           qr_service_id,
                           qr_service_name,
                           qr_ben_account_number ,
                           qr_merchant_code,
                           qr_currency_code ,
                           qr_transaction_id,
                           qr_comment,
                           qr_amount  ,
                           qr_link_hash  ,
                           requested_date    ,
                           beneficiary_app_id_number ,
                           beneficiary_name  ,
                           ben_customer_type,
                           operator_tran_type,
                           check_status     ,
                           response_date )
      
                   VALUES(corpint.pkg_common.getsequenceid('sqQR_TRX'),--pn_operator_request_id,
                          pn_sender_app_id,
                          pn_sender_customer_type,
                          ps_qr_type ,
                          ps_qr_merchant_provider,
                          ps_qr_merchant_id,
                          ps_qr_service_id,
                          ps_qr_service_name ,
                          ps_qr_ben_account_number,
                          pn_qr_merchant_code,
                          pn_qr_currency_code,
                          ps_qr_transaction_id,
                          ps_qr_comment,
                          pn_qr_amount,
                          ps_qr_link_hash ,
                          pd_requested_date,
                          pn_beneficiary_app_id_number,
                          ps_beneficiary_name ,
                          pn_ben_customer_type ,
                          pn_operator_tran_type ,
                          pn_check_status ,
                          pd_response_date );
         
 COMMIT;
 
EXCEPTION
    WHEN OTHERS THEN
    ROLLBACK;
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 

---------------------------**Function for checking demirbank acccounts  **----------------------------
FUNCTION Is_Internal (pn_sender_bic NUMBER, pn_beneficiary_bic NUMBER) RETURN VARCHAR IS

ln_bank_account VARCHAR2(200 BYTE);
  
  BEGIN
  
     IF SUBSTR(pn_sender_bic,1,6)=118000 AND SUBSTR(pn_beneficiary_bic,1,6)=118000 THEN
        RETURN 'YES';
     ELSE 
        RETURN 'NO';
     END IF;
  
      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
  END;

---------------------------**MARLEN QUESTION MARK **----------------------------
PROCEDURE Get_App_By_App_Id (pn_app_id IN NUMBER, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.participant_apps WHERE /*STATUS = '1' AND*/ app_id =pn_app_id; --status 1 -Active -2 -Closed
  END;
    

---------------------------**Function for updating assigned token  **----------------------------  
FUNCTION Token_Update (pn_app_id NUMBER, ps_token VARCHAR2,pn_signing_version NUMBER) RETURN NUMBER IS

ls_token VARCHAR2(2000 BYTE);
ls_revoke_token VARCHAR2(10 BYTE);

  BEGIN
  
  
  SELECT NVL(token, 'NULL')   
    INTO ls_token
  FROM qroperator_app.participant_apps
  WHERE app_id=pn_app_id;
  
  
  SELECT NVL(revoke_token, 'NULL')   
    INTO ls_revoke_token
  FROM qroperator_app.participant_apps
  WHERE app_id=pn_app_id;
  
  
  
  IF ls_token ='NULL' AND ls_revoke_token ='NULL' THEN
  
    UPDATE qroperator_app.participant_apps
      SET token = ps_token,
          revoke_token ='NO',
          SIGNING_VERSION = pn_signing_version
    WHERE app_id=pn_app_id;
    
    RETURN 1;
  
  ELSIF ls_token <>'NULL' AND ls_revoke_token ='YES' THEN
  
    UPDATE qroperator_app.participant_apps
      SET token = ps_token,
          revoke_token ='NO',
          SIGNING_VERSION = pn_signing_version               
    WHERE app_id=pn_app_id;
    
    RETURN 1;
   
  ELSIF ls_token <>'NULL' AND ls_revoke_token ='NO'THEN
      
    RETURN 0;
   
  ELSE
   
    RETURN 0;
  
  END IF;
  
   COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
    --RETURN 0;
    RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
 
  END;  
  
 ----------**Function for switching token **--------------   
FUNCTION Revoke_Token_Param_Update (pn_app_id NUMBER, ps_revoke_token VARCHAR2) RETURN NUMBER IS



  BEGIN

      UPDATE qroperator_app.participant_apps
         SET revoke_token =  'YES', token = ps_revoke_token
        WHERE app_id=pn_app_id;
    
       RETURN 1;
  
   COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
    RETURN 0;
    --RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
 
  END;    


---------------------------**MARLEN QUESTION MARK  **----------------------------  
PROCEDURE Get_Transaction_By_Sender_Tx_Id (pn_sender_tx_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.TRANSACTIONS WHERE SENDER_TRANSACTION_NO = pn_sender_tx_id;
  END;

---------------------------**For getting current balance   **----------------------------    
PROCEDURE Get_Bank_Balance_Info (ps_bank_id IN NUMBER, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    
  log_at('getinfolimit', ps_bank_id);
  
    OPEN pc_ref FOR
    
    SELECT 
       l.bank_name,
       l.bic,
       l.bank_limit, 
       --(NVL(l.bank_limit,0)+
       NVL(BEN_AMOUNT,0)-NVL(sent_amount,0)  current_balance,                  
       l.bank_id  
    FROM (SELECT
                    b.bank_name,
                    b.bic,
                    a.bank_limit,
                    b.bank_id
                FROM qroperator_app.bank_limit_settings a,qroperator_app.participant_banks b
                     WHERE a.bank_bic = NVL(pkg_qr_payments.Get_Bank_BIC_By_Id(ps_bank_id),a.bank_bic)  
                AND a.bank_bic = b.bic ) L 
                
      LEFT JOIN 
              (SELECT sender_bank_bic,
                      SUM(qr_amount)/100 sent_amount 
                 FROM qroperator_app.transactions 
               WHERE EXECUTE_PROCESS_TIME>SYSDATE-1 
                    AND EXECUTE_PROCESS_TIME<SYSDATE+1
                    AND final_status= 50
                    GROUP BY sender_bank_bic) S
                    
      ON l.bic=s.sender_bank_bic
      
      LEFT JOIN 
            (SELECT beneficiary_bank_bic ,
                    SUM(qr_amount)/100 ben_amount 
             FROM qroperator_app.transactions 
                WHERE EXECUTE_PROCESS_TIME>SYSDATE-1 
                      AND EXECUTE_PROCESS_TIME<SYSDATE+1
                      AND final_status= 50
                      GROUP BY beneficiary_bank_bic) B
      ON l.bic=b.beneficiary_bank_bic;
   

  END;


---------------------------**For getting current balance of Application   **----------------------------   
PROCEDURE Get_Application_Balance_Info (ps_bank_id IN NUMBER,ps_app_id IN NUMBER, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
   
	  log_at ('testPP',ps_bank_id);
    OPEN pc_ref FOR
    
       SELECT  L.APP_ID,
            L.APP_LIMIT ,
            --L.APP_LIMIT+
            ( NVL(CREDIT,0 )  - NVL(DEBIT,0)) CURRENT_BALANCE,
            L.app_name,
            L.qr_provider,
            L.bank_account         
    FROM ( SELECT  s.app_id, s.app_limit, a.app_name, a.qr_provider, a.bank_account  
                  FROM qroperator_app.app_limit_settings  s,  qroperator_app.participant_apps a 
    where s.bank_id=ps_bank_id AND s.app_id=nvl(ps_app_id,s.app_id) AND s.app_id= a.app_id ) L 
    LEFT JOIN  
           ( SELECT SENDER_APP_ID , SUM (NVL(qr_amount,0)) /100  DEBIT  from qroperator_app.transactions
    GROUP BY  SENDER_APP_ID )   A
    ON L.APP_ID=A.SENDER_APP_ID 
    LEFT JOIN  
           ( SELECT BENEFICIARY_APP_ID , SUM (NVL(qr_amount,0))/100  CREDIT  from qroperator_app.transactions
    GROUP BY  BENEFICIARY_APP_ID )   b
    ON L.APP_ID=b.BENEFICIARY_APP_ID;
    
 
  EXCEPTION
    WHEN OTHERS THEN
    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);  
        
  END;




--qroperator_app.bank_limit_settings


---------------------------**MARLEN QUESTION MARK **----------------------------   
PROCEDURE Get_Transaction_By_Bank_Id (ps_bank_id IN VARCHAR,ps_app_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.transactions WHERE SENDER_TRANSACTION_NO = ps_bank_id;
  END;

--qroperator_app.bank_limit_settings


---------------------------**For using in internal select    **----------------------------   
FUNCTION Get_Bank_BIC_By_Id (pn_bank_id NUMBER) RETURN NUMBER IS

ln_bic NUMBER;
  
  BEGIN
  
   SELECT bic 
     INTO  ln_bic
       FROM qroperator_app.participant_banks   
     WHERE bank_id = pn_bank_id;
  
  RETURN ln_bic; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;


---------------------------**PANEL -For getting list of transactions **----------------------------   
PROCEDURE  Get_QR_Transactions (pn_bank_id                 NUMBER,--qroperator_app.participant_banks 
                                pn_app_id                  NUMBER DEFAULT NULL,
                                pd_start_date              VARCHAR2 DEFAULT NULL,
                                pd_end_date                VARCHAR2 DEFAULT NULL,
                                ps_status                  NUMBER DEFAULT NULL,
                                pn_page_index              NUMBER,
                                pn_page_size               NUMBER,
                                ps_operator_transaction_id    VARCHAR2 DEFAULT NULL,
                                pc_ref OUT SYS_REFCURSOR                     
                               ) IS 

BEGIN

log_at('Get_QR_Transactions','pn_bank_id'||' '||pn_bank_id||' / '||
                             'pn_app_id'||' '||pn_app_id||' / '||
                             'pd_start_date '||' '||pd_start_date||' / '||
                             'pd_end_date'||' '||  pd_end_date ||' / '||   
                             'ps_status' ||'+'||   ps_status  ||' / '|| 
                             'pn_page_index'||' '||pn_page_index||' / '||  
                             'pn_page_size'||' '||pn_page_size);
                            


OPEN pc_ref FOR
   SELECT 
   distinct 
      operator_transaction_id,
      sender_bank_bic bic,
      (SELECT bank_name FROM qroperator_app.participant_banks WHERE bank_id=pn_bank_id) bank_name,
      pkg_qr_payments.Get_App_Name_By_App (SENDER_APP_ID) app_name,
      'DT' TR_TYPE,
      (qr_amount)*(-1)/100 amount,
      nvl(comission, 0) comission,
      create_request_time,
      execute_process_time,     
      pkg_qr_payments.Get_Status_Name_By_Code (nvl (final_status, create_status)) status,    
      DECODE (is_our_network, 'YES','Да','NO','Нет') is_our_network
         FROM qroperator_app.transactions 
         WHERE sender_bank_bic = pkg_qr_payments.Get_Bank_BIC_By_Id (pn_bank_id) 
           AND sender_app_id=nvl(pn_app_id, sender_app_id)
           AND create_request_time >=TO_DATE(NVL(pd_start_date, TO_CHAR(SYSDATE, 'yyyymmdd')), 'yyyymmdd')                              
           AND execute_process_time < TO_DATE(NVL(pd_end_date, TO_CHAR(SYSDATE, 'yyyymmdd')), 'yyyymmdd') + 1
          	AND (final_status=NVL(ps_status, final_status) OR create_status=NVL(ps_status, create_status))
           AND operator_transaction_id =NVL(ps_operator_transaction_id,operator_transaction_id)
 UNION 
   SELECT 
   distinct
      operator_transaction_id,
      beneficiary_bank_bic bic,
      (SELECT bank_name FROM qroperator_app.participant_banks WHERE bank_id=pn_bank_id) bank_name,
      pkg_qr_payments.Get_App_Name_By_App (BENEFICIARY_APP_ID) app_name,
      'CR' TR_TYPE,
      qr_amount/100 amount,
       nvl(comission, 0) comission,
      create_request_time,
      execute_process_time,
      pkg_qr_payments.Get_Status_Name_By_Code (nvl (final_status, create_status)) status,
        DECODE (is_our_network, 'YES','Да','NO','Нет') is_our_network
         FROM qroperator_app.transactions      
             WHERE beneficiary_bank_bic = pkg_qr_payments.Get_Bank_BIC_By_Id (pn_bank_id)
               AND BENEFICIARY_APP_ID=nvl(pn_app_id, BENEFICIARY_APP_ID)
               AND create_request_time >=TO_DATE(NVL(pd_start_date, TO_CHAR(SYSDATE, 'yyyymmdd')), 'yyyymmdd')                              
               AND execute_process_time < TO_DATE(NVL(pd_end_date, TO_CHAR(SYSDATE, 'yyyymmdd')), 'yyyymmdd') + 1
                 AND (final_status=nvl(ps_status, final_status) OR create_status=NVL(ps_status, create_status))
                 AND operator_transaction_id = NVL(ps_operator_transaction_id,operator_transaction_id)
                 ORDER BY create_request_time desc
                    offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows ONLY;

 
EXCEPTION
    WHEN OTHERS THEN
    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 


---------------------------**MARLEN QUESTION MARK   **----------------------------   
PROCEDURE Get_App_By_Qr_Provider (pn_qr_provider IN VARCHAR, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.participant_apps WHERE/* STATUS = '1' AND*/ qr_provider = pn_qr_provider;
  END;
  

---------------------------**PANEL For getting list  of EOD transactions   **----------------------------     
PROCEDURE  Get_EOD_Operations(pn_bank_id           NUMBER,                                 
                              pd_date              DATE DEFAULT SYSDATE, 
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                             
                              pc_ref OUT SYS_REFCURSOR                     
                               ) IS 


BEGIN
log_at('date', pd_date);
OPEN pc_ref FOR
   SELECT 
      operator_transaction_id,
      --transaction_type,
      bank_date,
      bank_bic,
      bank_id,
      PKG_QR_PAYMENTS.GET_BANK_NAME_BY_ID(bank_id) bankname,
      --app_id,
      app_name,
      app_bank_account, 
      dt_cr_flag,    
      amount,--(amount/100) amount,
      comission,
      execute_process_time,
      is_our_network,
      is_internal,
      app_id,
      currency_code
         FROM qroperator_app.eod_daily_transactions 
         WHERE bank_id = pn_bank_id 
          AND bank_date>=TRUNC(pd_date) AND bank_date<TRUNC(pd_date)+1
            ORDER BY bank_date DESC offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;

 
EXCEPTION
    WHEN OTHERS THEN
    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 


---------------------------**For getting list GROSS transactions   **----------------------------   
PROCEDURE  Get_EOD_Net_Gross_Positions(                             
                              pd_date                    DATE DEFAULT SYSDATE,
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                              
                              pc_ref OUT SYS_REFCURSOR                     
                               ) IS 


BEGIN

OPEN pc_ref FOR
   SELECT 
      transaction_no,
      bank_date,
      pkg_qr_payments.get_bank_name_by_id(bank_id) bank_name,
      bank_bic,
      credit_amount,
      debit_amount,
      state,
      maturity_date 
         FROM  qroperator_app.eod_net_gross
        WHERE maturity_date>=TRUNC(pd_date) AND maturity_date<TRUNC(pd_date)+1
              ORDER BY maturity_date DESC offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;


EXCEPTION
    WHEN OTHERS THEN
    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 


---------------------------**For getting EOD book to book transactions    **----------------------------   
PROCEDURE  Get_B2B_Positions(                             
                              pd_date                    DATE DEFAULT SYSDATE,
                              pn_page_index              NUMBER,
                              pn_page_size               NUMBER,                              
                              pc_ref OUT SYS_REFCURSOR                     
                               ) IS 


BEGIN

OPEN pc_ref FOR
   SELECT 
     transaction_number ,
     bank_date,
     sender_acc,
     receiver_acc,
     total_amount,
     payer_desc,
     create_date ,
     sent_date,
     state
       FROM  qroperator_app.eod_net_b2b         
         WHERE bank_date>=TRUNC(pd_date) AND bank_date<TRUNC(pd_date)+1       
             ORDER BY bank_date DESC offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;

EXCEPTION
    WHEN OTHERS THEN
    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END; 



---------------------------**For using in internal select  **----------------------------   
FUNCTION Get_Bank_Name_By_Id (pn_bank_id NUMBER) RETURN VARCHAR2 IS

ls_bank_name VARCHAR2(200 BYTE);
  
  BEGIN
  
   SELECT bank_name 
     INTO  ls_bank_name
       FROM qroperator_app.participant_banks   
     WHERE bank_id = pn_bank_id;
  
  RETURN ls_bank_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;


---------------------------**For using in internal select  **----------------------------   

FUNCTION Get_App_Name_By_Bank_Id (pn_bank_id NUMBER) RETURN VARCHAR2 IS

ls_app_name VARCHAR2(200 BYTE);
  
  BEGIN
  
   SELECT app_name 
     INTO  ls_app_name
       FROM qroperator_app.participant_apps   
     WHERE bank_id = pn_bank_id;
  
  RETURN ls_app_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;




---------------------------**PANEL - For list of bank limits  **----------------------------   
Procedure Get_Bank_Limits (pn_bank_id NUMBER DEFAULT NULL, pc_ref OUT SYS_REFCURSOR )  IS

ls_app_name VARCHAR2(200 BYTE);
  
  BEGIN
  OPEN pc_ref FOR
  
   SELECT 
      bank_bic,
      pkg_qr_payments.Get_Bank_Name_By_Id (bank_id) bank_name,
      bank_limit,
      DECODE(state, 'NEW','Новый','SET','Установлен','Ошибка при установке')  state,
      creation_date,
      bank_id,
      created_user        
  FROM qroperator_app.bank_limit_settings WHERE bank_id =nvl(pn_bank_id,bank_id);

      EXCEPTION
        WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
        
  END;



---------------------------**PANEL-For list of app limits  **----------------------------   
Procedure Get_App_Limits (pn_bank_id NUMBER DEFAULT NULL, pc_ref OUT SYS_REFCURSOR )  IS

ls_app_name VARCHAR2(200 BYTE);
  
  BEGIN
  OPEN pc_ref FOR
  
   SELECT 
    bank_id,
    app_id,
    pkg_qr_payments.Get_Bank_Name_By_Id (bank_id) bank_name,
    pkg_qr_payments.Get_App_Name_By_Bank_Id (bank_id) app_name,
    app_limit,
    creation_date,
    created_user   
   FROM qroperator_app.app_limit_settings WHERE bank_id =nvl(pn_bank_id,bank_id);
   
   
    

      EXCEPTION
        WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
        
  END;



---------------------------**For using in internal select  **----------------------------   
FUNCTION Get_Status_Name_By_Code (pn_code NUMBER) RETURN VARCHAR2 IS

ls_status_name VARCHAR2(200 BYTE);
  
  BEGIN
  
   SELECT status 
     INTO  ls_status_name
       FROM qroperator_app.operator_status_list   
     WHERE code = pn_code;
  
  RETURN ls_status_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;



---------------------------**PANEL -For LOV  **----------------------------   
PROCEDURE Get_Status_List (pc_ref OUT SYS_REFCURSOR) IS

ls_status_name VARCHAR2(200 BYTE);
  
  BEGIN
  
  OPEN pc_ref FOR 
   SELECT code,
          status 
   FROM qroperator_app.operator_status_list;
  

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
        
  END;

---------------------------**PANEL -For LOV  **----------------------------   
PROCEDURE Get_Participant_Banks_List (pn_bank_id NUMBER, pc_ref OUT SYS_REFCURSOR) IS
  
  BEGIN
  
  OPEN pc_ref FOR 
   SELECT bank_id,
          bank_name
   FROM qroperator_app.participant_banks where bank_id=NVL(pn_bank_id,bank_id) and status='1' ;
  

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
        
  END;

---------------------------**PANEL -For LOV  **----------------------------   --
PROCEDURE Get_Participant_Apps_List (pn_bank_id NUMBER,pc_ref OUT SYS_REFCURSOR) IS
  
  BEGIN
  
  OPEN pc_ref FOR 
   SELECT bank_id,
          app_id,
          app_name 
   FROM qroperator_app.participant_apps
     WHERE bank_id=NVL(pn_bank_id,bank_id) and status='1';

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
        
  END;


---------------------------**PANEL For getting transaction details **----------------------------   
PROCEDURE Get_Transaction_Details (ps_trx_no VARCHAR2,pc_ref OUT SYS_REFCURSOR) IS
  
  BEGIN
  
  OPEN pc_ref FOR
   
  SELECT  
      operator_transaction_id , 
       pkg_qr_payments.Get_Transaction_Name_By_Type (transaction_type) transaction_type, -- cюда значение from   select * from QROPERATOR_APP.OPERATOR_TRANSACTION_TYPE
      qr_amount/100 amount ,  
      nvl(comission,0)comission  , 
      pkg_qr_payments.Get_Status_Name_By_Code (COALESCE (final_status, create_status)) status,  
      PKG_QR_PAYMENTS.GET_APP_NAME_BY_APP(sender_app_id) sender_app_id , 
      sender_transaction_no , 
      sender_receipt_no, 
      qr_merchant_provider, 
      beneficiary_name , 
      SUBSTR(qr_ben_account_number,1,4)||'********'||SUBSTR(qr_ben_account_number,-4) ben_account, --первые 4 и последние 4 значения  
      create_request_time , 
      execute_process_time, 
      error_time  
  FROM qroperator_app.transactions
  WHERE operator_transaction_id = ps_trx_no;

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
        
  END;
  
  
---------------------------**For internal select   **----------------------------   
FUNCTION Get_Transaction_Name_By_Type (ps_type VARCHAR2) RETURN VARCHAR2 IS

ls_name VARCHAR2(200 BYTE);
  
  BEGIN
  
   SELECT name 
     INTO  ls_name
       FROM qroperator_app.operator_transaction_type  
     WHERE TRANSACTION_CODE  = ps_type;
  
  RETURN ls_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;
  
---------------------------**SYS-API for updateting final success status**----------------------------     
FUNCTION Update_Trx_By_Transaction_ID (ps_transaction_id VARCHAR2,pd_execute_request_time DATE,pd_execute_process_time DATE,pn_final_status NUMBER) RETURN NUMBER IS

ls_name VARCHAR2(200 BYTE);
  
  BEGIN
  log_at('Update1601',1,ps_transaction_id ||'  '||pd_execute_request_time ||'  '||pd_execute_process_time ||'  '||pn_final_status);
  UPDATE qroperator_app.transactions
     SET execute_request_time=pd_execute_request_time,
         execute_process_time=pd_execute_process_time,
         final_status=pn_final_status
  WHERE operator_transaction_id=ps_transaction_id;
  log_at('Update1601',2);
  COMMIT;
  
  RETURN 1;
  
      EXCEPTION
  
        WHEN OTHERS THEN
              log_at('Update1601',3);
      RETURN 0;
        
  END;

---------------------------**SYS-API for updateting error time and status**---------------------------- 
FUNCTION Update_Trx_By_Trans_ID_Err (ps_transaction_id VARCHAR2,pn_final_status NUMBER,pd_error_time DATE) RETURN NUMBER IS

ls_name VARCHAR2(200 BYTE);
  
  BEGIN
  
  UPDATE qroperator_app.transactions
     SET final_status=pn_final_status,
         error_time=pd_error_time
  WHERE operator_transaction_id=ps_transaction_id;

  COMMIT;
  
  RETURN 1;
  
      EXCEPTION
        WHEN OTHERS THEN
      RETURN 0;
        
  END;

---------------------------* PANEL get user list**---------------------------- 
PROCEDURE Get_User_By_Username (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR) AS
  ln_role NUMBER;
  
  BEGIN
    
  ln_role:= pkg_qr_payments.Get_Role_By_Username(ps_username);
  

   IF ln_role=1 THEN
    
    OPEN pc_ref FOR    
      SELECT
        bank_id ,
        pkg_qr_payments.Get_Bank_Name_By_Id(bank_id) bank_name ,
        pkg_qr_payments.get_app_name_by_app( app_id) app_name , 
        username,
        pkg_qr_payments.Get_Role_Name_By_ID(role) role,
        DECODE( status , '1', 'Активный', 'Деактивирован') status,
        role roleid,
        created_user,
        create_date,
        deactivate_user ,
        deactivate_date 
       FROM qroperator_app.remote_users  WHERE role in (3,4);
	
   
   ELSIF ln_role=2 THEN
    
    OPEN pc_ref FOR 
      SELECT
        bank_id ,
        pkg_qr_payments.Get_Bank_Name_By_Id(bank_id) bank_name ,
          pkg_qr_payments.get_app_name_by_app( app_id) app_name , 
        username,
        pkg_qr_payments.Get_Role_Name_By_ID(role) role,
        DECODE( status , '1', 'Активный', 'Деактивирован') status,
        created_user ,
        create_date,
        deactivate_user ,
        deactivate_date
      FROM qroperator_app.remote_users	
	    WHERE role in (3,4);


   ELSIF ln_role=0 THEN
    
    OPEN pc_ref FOR 
      SELECT
        bank_id ,
        pkg_qr_payments.Get_Bank_Name_By_Id(bank_id) bank_name ,
          pkg_qr_payments.get_app_name_by_app( app_id) app_name , 
        username,
       pkg_qr_payments.Get_Role_Name_By_ID(role) role,
        DECODE( status , '1', 'Активный', 'Деактивирован') status,
        created_user ,
        create_date,
        deactivate_user ,
        deactivate_date
      FROM qroperator_app.remote_users    
        WHERE role in (0,1,2) ;
     
   ELSE
   
   NULL; 
    
   END IF;
    
       
    
  END;


--PANEL For getting list of roles 
PROCEDURE Get_User_Roles (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR) AS
    ln_role NUMBER;
  BEGIN
  
  ln_role:= pkg_qr_payments.Get_Role_By_Username(ps_username);
  
   IF ln_role=1 THEN
    
    OPEN pc_ref FOR    
    SELECT * FROM qroperator_app.USER_ROLES WHERE ROLE_ID in (3,4) ;
   
   ELSIF  ln_role=2 THEN
    
    OPEN pc_ref FOR 
    SELECT * FROM qroperator_app.USER_ROLES WHERE ROLE_ID in (3,4);
    
   ELSIF  ln_role=0 THEN
    
    OPEN pc_ref FOR 
    SELECT * FROM qroperator_app.USER_ROLES WHERE ROLE_ID in (0,1,2);
     
   ELSE
   
   NULL; 
    
   END IF;

    
  END;



---PANEL   for checking login  authorization 
PROCEDURE Auth_Connected_User (ps_username IN VARCHAR2, pc_ref OUT SYS_REFCURSOR) AS
  ln_role NUMBER;
  BEGIN
  
     OPEN pc_ref FOR    

    SELECT  username, password, pkg_qr_payments.Get_Role_Name_By_ID(role) user_role,bank_id,app_id,force_password, STATUS FROM qroperator_app.remote_users 
   WHERE  username=ps_username ;--STATUS =1 AND

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM);
   
    
  END;
 
 
 --- For internal select 
FUNCTION Get_Role_By_Username (ps_username VARCHAR2) RETURN NUMBER IS

ls_role NUMBER;
  
  BEGIN
  
  SELECT role 
   INTO  ls_role
     FROM qroperator_app.remote_users 
  WHERE username =ps_username;
 
  
  RETURN ls_role; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;

 --PANEL  List of banks  
PROCEDURE Get_Participant_Banks_All_Info (pn_bank_id NUMBER,pc_ref OUT SYS_REFCURSOR) IS

  
  BEGIN
  
  OPEN pc_ref FOR 
  
  SELECT  
      bank_id, 
      bank_name,
      tax_no,  
      bic,    
      website,       
      contact_email,  
      contact_phone,
      ip,            
      registration_date,
      DECODE( status , '1', 'Активный', 'Закрытый') status,--26012023AndreiD           
      closing_date,       
      closed_user,      
      address              
  FROM qroperator_app.participant_banks WHERE bank_id = NVL(pn_bank_id, bank_id); 

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
        
  END;

 --PANEL- List of app  
PROCEDURE Get_Participant_Apps_All_Info (pn_app_id NUMBER,pc_ref OUT SYS_REFCURSOR) IS

  
  BEGIN
  
  OPEN pc_ref FOR 

  SELECT 
      bank_id,
      pkg_qr_payments.Get_Bank_Name_By_Id(bank_id) bank_name,
      app_id,
      app_name,
      pkg_qr_payments.Get_App_Type_By_Code(app_type) app_type, 
      qr_provider,
      bank_account,
      bank_bic,--ask Miraida
      app_tax_number,
      address,
      ip_address,
      contact_email,
      contact_phone,
      DECODE( status , '1', 'Активный', 'Закрытый') status,--26012023AndreiD
      registration_date,
      created_user,
      closing_date,
      closed_user,
      port,
      path            
  FROM qroperator_app.participant_apps WHERE app_id= NVL(pn_app_id, app_id); 

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
        
  END;
  
--- For internal select  
  
FUNCTION Get_Role_Name_By_ID (pn_role_id NUMBER) RETURN VARCHAR2 IS

ls_role_name  VARCHAR2(30 BYTE);
  
  BEGIN
  
  SELECT role_name 
   INTO  ls_role_name
     FROM qroperator_app.user_roles 
  WHERE role_id = pn_role_id;
 
  
  RETURN ls_role_name; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END;
  
PROCEDURE Get_Comission_List (pn_app_id NUMBER,pc_ref OUT SYS_REFCURSOR) IS

  
  BEGIN
  
  OPEN pc_ref FOR 


SELECT

    pkg_qr_payments.Get_Bank_Name_By_Id(bank_id)  bank_name,     
    bank_id,
    pkg_qr_payments.Get_App_Name_By_App(app_id) app_name, 
    app_id,
    comission_code,
    pkg_qr_payments.Get_Comm_Descr_By_Comm_Code(comission_code) comission_description,
    comission_rate,
    is_fix_comission,
    is_exemption
    
FROM qroperator_app.app_commission_def 
WHERE app_id =NVL(pn_app_id,app_id);



  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
        
  END;
    
  
  
  
FUNCTION Get_Comm_Descr_By_Comm_Code (ps_code VARCHAR2) RETURN VARCHAR2 IS

ls_description  VARCHAR2(200 BYTE);
  
  BEGIN
  
  SELECT description 
   INTO  ls_description
     FROM qroperator_app.commission_types
  WHERE code = ps_code;
 
  
  RETURN ls_description; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END; 
  
  
  
PROCEDURE Get_Comission_Types_List (pc_ref OUT SYS_REFCURSOR) IS

  
  BEGIN
  
  OPEN pc_ref FOR 

   SELECT * FROM qroperator_app.commission_types;

  EXCEPTION
    WHEN OTHERS THEN    
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
        
  END;  
  
 FUNCTION Update_Comission (pn_app_id NUMBER,ps_comission_code VARCHAR2,ps_comission_rate VARCHAR2,ps_is_fix_comission VARCHAR2,ps_is_exemption VARCHAR2) RETURN NUMBER IS
  
  BEGIN
  
     UPDATE qroperator_app.app_commission_def
      SET  comission_code    = ps_comission_code,  
           comission_rate    = ps_comission_rate,
           is_fix_comission  =  ps_is_fix_comission,
           is_exemption      =  ps_is_exemption
      WHERE app_id=pn_app_id;

  COMMIT;
  
  RETURN 1;
  
      EXCEPTION
        WHEN OTHERS THEN
      RETURN 0;
        
  END;  
 PROCEDURE  Holidays_Add ( pn_day              DATE,                         
                          ps_explanation      VARCHAR2,
                          ps_status           VARCHAR2,
                          pd_created_date     DATE,
                          ps_created_user     VARCHAR2                                                                            
                               ) IS 


BEGIN
/*
  INSERT INTO qroperator_app.holidays
        (day,       
         explanation,
         status,
         created_date,
         created_user
         )
 VALUES(pn_day,        
        ps_explanation,
        ps_status,
        pd_created_date,
        ps_created_user        
       ); 
         
 COMMIT;
 */
 NULL;
EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
END;



 FUNCTION Update_Holidays (pd_day DATE,                         
                           ps_explanation      VARCHAR2,
                           ps_status           VARCHAR2,
                           pd_created_date     DATE,
                           ps_created_user     VARCHAR2) RETURN NUMBER IS
  
  BEGIN
  /*
     UPDATE qroperator_app.holidays
      SET    
           explanation = ps_explanation,
           status = ps_status,
           created_date = pd_created_date,
           created_user = ps_created_user           
     WHERE day = pd_day;

  COMMIT;
  
  RETURN 1;
  */
  NULL;
      EXCEPTION
        WHEN OTHERS THEN
      RETURN 0;
        
  END;

PROCEDURE Get_Transaction_By_Tx_Id (pn_tx_id IN VARCHAR, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.TRANSACTIONS WHERE OPERATOR_TRANSACTION_ID = pn_tx_id;
  END;
PROCEDURE Get_Holidays_Info (pd_day DATE,pc_ref OUT SYS_REFCURSOR) AS

  BEGIN
    OPEN pc_ref FOR
  --  SELECT * FROM qroperator_app.holidays WHERE day=NVL(pd_day,day);
  -- SELECT * FROM cbs.cbs_takvim WHERE gun>ADD_MONTHS( SYSDATE, 1 );
      SELECT * FROM cbs.cbs_takvim WHERE gun >=SYSDATE 
    AND gun<=ADD_MONTHS(SYSDATE, 1);
    
  END;  
 
FUNCTION Modify_Holidays (pd_day DATE
                           ) RETURN NUMBER IS
  
  BEGIN
  
	/*  log_at('testda', pd_day);
    DELETE FROM qroperator_app.holidays
      WHERE  day = pd_day;  
                    
  COMMIT;
  
  RETURN 1;
  */
  NULL;
      EXCEPTION
        WHEN OTHERS THEN
      RETURN 0;
        
  END;  
  
PROCEDURE Get_Application_Types_Info (pc_ref OUT SYS_REFCURSOR) AS

  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.application_types;
  END;    
 
PROCEDURE  Eod_Net_Gross IS

ld_maturity_date DATE;

CURSOR c1_eod_net_gross IS  
   
SELECT 
       l.bank_id, 
       l.bank_name,      
       l.bank_bic,
       ben_amount credit_amount, 
       sent_amount debit_amount                          
      
      FROM (SELECT 
                    a.bank_id,
                    a.bank_name,
                    b.bank_bic                                     
                FROM qroperator_app.participant_banks a,qroperator_app.eod_daily_transactions b
                    WHERE b.is_internal='NO'
                AND a.bic = b.bank_bic AND a.bank_id=b.bank_id AND rownum=1) l 
                
      LEFT JOIN 
              (SELECT bank_bic,
                      SUM (NVL (amount, 0)) * (-1) / 100 sent_amount
                 FROM qroperator_app.eod_daily_transactions 
               WHERE /*bank_date=TRUNC(SYSDATE)-1 
                    --AND EXECUTE_PROCESS_TIME<SYSDATE+1
                    AND*/ is_internal='NO' AND dt_cr_flag='DT'
                    GROUP BY bank_bic) s
                    
      ON l.bank_bic=s.bank_bic
      
      LEFT JOIN 
            (SELECT bank_bic ,                
                     SUM (NVL (amount, 0)) / 100 ben_amount 
             FROM qroperator_app.eod_daily_transactions  
                WHERE /*bank_date=TRUNC(SYSDATE)-1  
                    -- AND*/ 
                     is_internal='NO'AND dt_cr_flag='CR'
                      GROUP BY bank_bic) b
      ON l.bank_bic=b.bank_bic;

r_c1_eod_net_gross c1_eod_net_gross%ROWTYPE;


BEGIN

ld_maturity_date := SYSDATE;
OPEN c1_eod_net_gross;
 --  LOOP
       FETCH c1_eod_net_gross INTO r_c1_eod_net_gross;
      -- EXIT WHEN c1_eod_net_grosss%NOTFOUND; 
 
        INSERT INTO qroperator_app.eod_net_gross      
          (transaction_no,
           bank_date,
           bank_id,
           bank_bic,
           credit_amount,
           debit_amount ,
           state ,
           maturity_date)

        VALUES
           (corpint.pkg_common.getsequenceid('sqQR_TRX'),
            TRUNC(SYSDATE)-1,
            r_c1_eod_net_gross.bank_id,
            r_c1_eod_net_gross.bank_bic,
            r_c1_eod_net_gross.credit_amount,
            r_c1_eod_net_gross.debit_amount,
            'NEW',
            ld_maturity_date          
            );
    
  --  END LOOP;
CLOSE c1_eod_net_gross;
COMMIT;

END;  

PROCEDURE Get_Reconciliation  (pn_bank_id IN NUMBER,pn_app_id IN NUMBER ,pd_bank_date DATE,
                               pn_page_index NUMBER, pn_page_size NUMBER, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
  
    OPEN pc_ref FOR

    SELECT 
      bank_date, 
      operator_transaction_id,
      dt_cr_flag,      
      amount,--NVL(amount, 0) / 100 amount,
      comission,
      currency_code,
      transaction_type,
      bank_bic,
      app_bank_account,
      app_id,
      bank_id,
      execute_request_time,
      execute_process_time      
         FROM qroperator_app.eod_daily_transactions
     WHERE  bank_date =pd_bank_date AND bank_id = pn_bank_id  AND app_id = nvl(pn_app_id,app_id)
     ORDER BY execute_request_time desc
      offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
    
  END;
   PROCEDURE Get_Lps_Online (pn_page_index NUMBER,pn_page_size NUMBER,pd_date DATE, pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
  
  log_at('lps_online',pn_page_index ||pn_page_size,pd_date);
  OPEN pc_ref FOR
      
  
  
  SELECT  
        a.p_21_id reference,
        a.maturity_date,
        a.p_state state ,
        b.p_state_name state_name ,
        a.err_text, 
        a.msg_type,
        a.docs_amount,
        a.from_bank_bic,
        a.from_bank_name,
--        a.to_bank_bic,
--        a.to_bank_name, 
        a.create_date,
        a.sent_date        
  FROM lps_app.payments a,lps_app.payment_states b
    WHERE p_type='QROG'
       AND  a.p_state=B.P_STATE_ID
       AND  maturity_date = pd_date
       ORDER BY a.create_date desc
                    offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
    
  END; 
  
   PROCEDURE Get_Summary_Data (pd_date DATE, pn_bank_id NUMBER,pn_app_id NUMBER, 
                               pn_page_index NUMBER,pn_page_size NUMBER,pc_ref OUT SYS_REFCURSOR) AS
  BEGIN
  
  OPEN pc_ref FOR
  
  select pd_date bank_date,
       app.bank_bic,
       app.app_id,
       app.bank_id,
       app.app_name,
       app.bank_account,
       nvl(d.debit_amount,0) debit_amount ,
       nvl(c.credit_amount,0) credit_amount ,
       (nvl(c.credit_amount,0)+nvl(d.debit_amount,0)) total
  from (select bank_id,
               bank_bic,
               app_id,
               app_name,
               bank_account
          from qroperator_app.participant_apps where  bank_id = NVL(pn_bank_id, bank_id)  and app_id = nvl(pn_app_id, app_id)
       ) app
       left join (  select bank_id,
                           app_id,
                           bank_date,
                           sum (nvl (amount, 0)) * (-1) / 100 debit_amount
                      from qroperator_app.eod_daily_transactions
                     where dt_cr_flag = 'DT'           and bank_date=pd_date
                  group by bank_id, app_id, bank_date) d
          on app.bank_id = d.bank_id and app.app_id = d.app_id
       left join (  select bank_id,
                           app_id,
                           bank_date,
                           sum (nvl (amount, 0)) / 100 credit_amount
                      from qroperator_app.eod_daily_transactions
                     where dt_cr_flag = 'CR'           and bank_date=pd_date
                  group by bank_id, app_id, bank_date) c
          on app.bank_id = c.bank_id and app.app_id = c.app_id       
                ORDER BY bank_bic desc
                    offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
       
      
 /* SELECT  
        bank_date, 
        bank_bic, 
        app_name,
        app_bank_account, 
        SUM (amount)/100 sum_amount ,
        dt_cr_flag
        FROM qroperator_app.eod_daily_transactions
         WHERE  bank_id = NVL(pn_bank_id, bank_id)  and app_id = nvl(pn_app_id, app_id)
        GROUP BY 
          bank_date, 
          bank_bic, 
          app_name,
          app_bank_account,
          dt_cr_flag;*/
    
  END;
  
   ----------**PANEL Function for updating user password  **--------------   
FUNCTION Remote_User_Pass_Update (ps_username VARCHAR, ps_password VARCHAR2, ps_force_password VARCHAR, ps_connection_user VARCHAR) RETURN NUMBER IS



  BEGIN


      UPDATE QROPERATOR_APP.REMOTE_USERS
         SET force_password =ps_force_password, password= ps_password
        WHERE username=ps_username;
    
  
    INSERT INTO QROPERATOR_APP.REMOTE_USERS_LOG 
            (change_id,
             changed_item,
             changed_user,
             change_date) 
             VALUES (1, 'PassChange',ps_connection_user, sysdate );
     COMMIT;
  
         RETURN 1;
  

  
  EXCEPTION
    WHEN OTHERS THEN
    RETURN 0;
    --RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm); 
 
  END;    
  
  PROCEDURE Get_External_Transactions_In_Process(pc_ref OUT SYS_REFCURSOR)  AS
  BEGIN
    OPEN pc_ref FOR
    select * from QROPERATOR_APP.TRANSACTIONS where IS_OUR_NETWORK = 'NO' and FINAL_STATUS = '20' order by EXECUTE_PROCESS_TIME asc;
  END;
  
PROCEDURE Get_Xsigning_Version(pc_ref OUT SYS_REFCURSOR)  AS
    
  BEGIN
    OPEN pc_ref FOR
    SELECT * FROM qroperator_app.xsigning_version;
  END;
  
PROCEDURE Get_Limit_Type(pc_ref OUT SYS_REFCURSOR) AS

   BEGIN
    OPEN pc_ref FOR
    SELECT * FROM QROPERATOR_APP.LIMIT_TYPE;
  END; 

PROCEDURE Bank_Lim_Updating_By_Status (ps_state VARCHAR2, ps_msg_type VARCHAR2, pn_docs_amount NUMBER, pn_batch_no NUMBER) IS

BEGIN

log_at('LPScheck',ps_state||'+'||ps_msg_type||'+'||pn_docs_amount||'+'||pn_batch_no);

IF  ps_msg_type ='CREA' AND ps_state ='OUT-Proc' THEN
  
         UPDATE qroperator_app.bank_limit_settings
           SET bank_limit=bank_limit+pn_docs_amount,
               state='SET'
           WHERE transaction_number=pn_batch_no and state='NEW';
     
ELSIF  ps_msg_type ='RLSE' AND ps_state='OUT-Proc' THEN

   UPDATE qroperator_app.bank_limit_settings
           SET bank_limit=bank_limit-pn_docs_amount,
               state='SET'
        WHERE transaction_number=pn_batch_no and state='NEW';
     
         /* UPDATE qroperator_app.bank_limit_settings
           SET  state='ERROR'
         WHERE transaction_number=pn_batch_no;
 
END IF; */ 

/*                
IF  ps_msg_type ='RLSE' AND ps_state='OUT-Proc' THEN
                
        UPDATE qroperator_app.bank_limit_settings
           SET bank_limit=bank_limit-pn_docs_amount,
               state='SET'
        WHERE transaction_number=pn_batch_no; */
     
     
ELSE 
         UPDATE qroperator_app.bank_limit_settings
           SET   state='ERROR'
         WHERE transaction_number=pn_batch_no and state='NEW';


END IF;

EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
     
END;
  
FUNCTION Get_App_Type_By_Code (ps_application_code VARCHAR2) RETURN VARCHAR2 IS

ls_app_type  VARCHAR2(200 BYTE);
  
  BEGIN
  
  SELECT application_type 
   INTO  ls_app_type
     FROM qroperator_app.application_types
  WHERE application_code = ps_application_code;
 
  
  RETURN ls_app_type; 

      EXCEPTION
        WHEN OTHERS 
        THEN RETURN NULL;
        
  END; 
PROCEDURE Reserve_Update (pn_bic NUMBER, pn_reserve NUMBER) IS

BEGIN

log_at('LPScheck',pn_bic||'+'||pn_reserve);


  
         UPDATE qroperator_app.bank_limit_settings
           SET bank_limit=pn_reserve
           WHERE bank_bic=pn_bic;
           COMMIT;
          

EXCEPTION
    WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,TO_CHAR('SQLCODE') || SQLERRM); 
     
END;


PROCEDURE  Bank_Limit_Adding (pn_bank_id             NUMBER,
                              pn_bank_limit          NUMBER,
                              ps_created_user        VARCHAR2,                         
                              pd_creation_date       DATE DEFAULT SYSDATE,
                              ps_type                VARCHAR2
                              ) IS                            

  bank_currently_added EXCEPTION;                             
  ln_count_bank NUMBER;    
                           
BEGIN


log_at ('banklimit', ps_type,pn_bank_limit);


      SELECT COUNT(*)
        INTO ln_count_bank
         FROM qroperator_app.bank_limit_settings 
      WHERE bank_id = pn_bank_id;
  

       IF ln_count_bank>0 THEN
           
          RAISE bank_currently_added;
      
      ELSE
       
          INSERT INTO qroperator_app.bank_limit_settings
                (bank_id, 
                 bank_limit, 
                 credit_limit,
                 debit_limit,
                 created_user,
                 creation_date,
                 state,
                 bank_bic,
                 transaction_number,
                 type
                )
        VALUES(pn_bank_id,
               0,
               pn_bank_limit,
               0,
               ps_created_user,
               nvl(pd_creation_date,sysdate),
               'NEW',
               PKG_QR_PAYMENTS.GET_BANK_BIC_BY_ID(pn_bank_id),
               corpint.pkg_common.getsequenceid('sqQR_TRX'),
               'CREA'     
               ); 
       
       
       
       END IF;


 COMMIT;

EXCEPTION
WHEN bank_currently_added THEN
    Raise_application_error(-20100,pkg_hata.getUCPOINTER||'20140'|| pkg_hata.getDELIMITER );
WHEN OTHERS THEN
   RAISE_APPLICATION_ERROR(-20100,to_char('SQLCODE') || sqlerrm);    
           
END;



BEGIN
--STEP2
    Null;
End;
/

