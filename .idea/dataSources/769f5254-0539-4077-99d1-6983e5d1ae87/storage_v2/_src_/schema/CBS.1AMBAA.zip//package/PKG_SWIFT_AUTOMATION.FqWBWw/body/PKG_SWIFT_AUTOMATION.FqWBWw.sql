create PACKAGE BODY     "PKG_SWIFT_AUTOMATION" IS
--STEP1

PROCEDURE SWIFT_Messages_Parse (ps_type VARCHAR2,pd_start_date VARCHAR2,pd_end_date VARCHAR2,pd_svadat VARCHAR)IS 

   sblock4_1   VARCHAR2(4000 BYTE);
   text1  VARCHAR2(40);
   text2 VARCHAR2(1000);

CURSOR swift_cursor_940_950 IS


WITH a_cte AS (
    SELECT /*+ materialize */ 
      SUBSTR(sblock4_1, 1, 4000) sblock4_1,
                                 sadat ,
                                 svadat         
        FROM SWIFTGW.SWTTRNPF
           WHERE ((stype = '940' AND ssndr NOT IN ('ALFARUMMXXX','RZBMRUMMXXX')) OR stype = '950')     
--          AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE('09.08.2022', 'dd.mm.yyyy') , 'yyyymmdd')) 
--          AND sadat <= TO_NUMBER(TO_CHAR(TO_DATE('11.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))             
            AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-1, 'yyyymmdd') )
            AND sadat <  TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))
            AND ssts IN ('INBND', 'ACK')) 
                          
    SELECT /*+use_hash(C,D)*/ text1,
           NVL ( (REGEXP_SUBSTR(sblock4_1, ':52A:/?/?(.+)\s',1,1,NULL,1)),ssndr) senders_bic,
           (REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1))beneficiary_account,
           (REGEXP_SUBSTR(sblock4_1, ':59\w?:/.+\s(.+\s?.+)\s:70',1,1,NULL,1)) beneficiary_name,
           pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur) to_account,   
           pkg_musteri.sf_musteri_adi(pkg_hesap.getmusterinofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)))) to_name,
           NVL2(pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur),'Yes','No') AS "MATCHED", 
           (REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s(.+\s?)',1,1,NULL,1)) senders_name,
           --(REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s?.+\s?(.+\s?)',1,1,NULL,1)) senders_address,
           --(REGEXP_SUBSTR(SUBSTR(SBLOCK4_1,REGEXP_INSTR(SBLOCK4_1,':50\w:'),REGEXP_INSTR(SBLOCK4_1,':52\w:')- REGEXP_INSTR(SBLOCK4_1,':50\w:')),':50\w?:.+\s?.+\s?(.+\s?.+\s?.+\s?.+\s?.+\s?)',1,1,null,1)) senders_address_2 ,
           (REGEXP_SUBSTR(sblock4_1, ':50\w?:(.+\s?)',1,1,NULL,1)) senders_address,--AndreiD06102022
          -- (REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s.+\s(.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?):52',1,1,NULL,1)) senders_address_2, --AndreiD12102022
           sblock4_1,
           stransref,
           samnt,
           scur ,
           svadat,
           sadat,
           ssndr   
   FROM (
      SELECT /*+ leading(a) use_nl(b) */-- DISTINCT
              REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+//(\+?.+)\s',1,b.n,NULL,1) text1,
                                                                              sadat, 
                REGEXP_SUBSTR(sblock4_1 , ':61:(\d\d\d\d\d\d).*C.+//',1,b.n,NULL,1)  svadat                        
               FROM a_cte a,(SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 100)  b  
                 WHERE REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+//(\+?.+)\s',1,b.n,NULL,1) IS NOT NULL
                 AND TO_NUMBER (TO_CHAR( TO_DATE(REGEXP_SUBSTR(sblock4_1, ':61:(\d\d\d\d\d\d).*C.+//',1,b.n,NULL,1), 'yymmdd') , 'yyyymmdd' ))= TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd'))
                 ) c,   
        
      
        (SELECT sblock4_1,
                stransref,                   
                REGEXP_SUBSTR(sblock4_1, ':20:(\+?.+)\s',1,1,NULL,1) text2,
                samnt,
                scur ,
               -- svadat,
                ssndr  
          FROM SWIFTGW.SWTTRNPF          
          WHERE  stype IN ('103', '202', '20C') AND ssndr <>'DEMIKG22XXX'       
          -- AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE('01.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))
           --AND sadat <= TO_NUMBER(TO_CHAR(TO_DATE('18.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))
            AND ssts IN ('INBND', 'ACK')
            AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
            AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))          
            ) d
            
            
WHERE trim(text1) = trim(text2) AND trim(text1) NOT IN (SELECT REFERENCE FROM CBS_SWIFT_MESSAGES 
                                                WHERE sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
                                                   AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd')));

  r_swift_940_950 swift_cursor_940_950%ROWTYPE;



CURSOR swift_940_950_second IS
    WITH a_cte AS (
        SELECT /*+ materialize */ 
          SUBSTR(sblock4_1, 1, 4000) sblock4_1,
                                     sadat,
                                     svadat                         
          FROM SWIFTGW.SWTTRNPF
          WHERE ((stype = '940' AND ssndr NOT IN ('ALFARUMMXXX','RZBMRUMMXXX')) OR stype = '950')
    --      and sadat >= to_number(to_char(to_date('09.08.2022', 'dd.mm.yyyy') , 'yyyymmdd')) 
    --      and sadat <= to_number(to_char(to_date('11.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))         
            AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-1, 'yyyymmdd') )
            AND sadat <  TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))     
            AND ssts IN ('INBND', 'ACK'))
           
    SELECT /*+use_hash(C,D)*/ text1,
           NVL ( (REGEXP_SUBSTR(sblock4_1, ':52A:/?/?(.+)\s',1,1,NULL,1)),ssndr) senders_bic,
           (REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)) beneficiary_account,
           (REGEXP_SUBSTR(sblock4_1, ':59\w?:/.+\s(.+\s?.+)\s:70',1,1,NULL,1)) beneficiary_name,
           pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur) to_account,   
           pkg_musteri.sf_musteri_adi(pkg_hesap.getmusterinofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)))) to_name,
           NVL2(pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur),'Yes','No') AS "MATCHED", 
           (REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s(.+\s?)',1,1,NULL,1)) senders_name,
--           (REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s?.+\s?(.+\s?)',1,1,NULL,1)) senders_address,
--           (REGEXP_SUBSTR(SUBSTR(SBLOCK4_1,REGEXP_INSTR(SBLOCK4_1,':50\w:'),REGEXP_INSTR(SBLOCK4_1,':52\w:')- REGEXP_INSTR(SBLOCK4_1,':50\w:')),':50\w?:.+\s?.+\s?(.+\s?.+\s?.+\s?.+\s?.+\s?)',1,1,NULL,1)) senders_address_2 ,
           (REGEXP_SUBSTR(sblock4_1, ':50\w?:(.+\s?)',1,1,NULL,1)) senders_address,--AndreiD06102022
           --(REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s.+\s(.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?):52',1,1,NULL,1)) senders_address_2, --AndreiD12102022        
           sblock4_1,
           stransref,
           samnt,
           scur ,
           sadat,
           svadat,
           ssndr  
        FROM(  
           SELECT /*+ leading(a) use_nl(b) */ DISTINCT              
                   NVL(REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+NTRF(.+)//',1,b.n,NULL,1), REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+S\d\d\d(.+)//',1,b.n,NULL,1)) text1,
                     -- REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+//(\+?.+)\s',1,b.n,NULL,1) text5,  
                     
                     NVL(REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+NTRF.+//(\+?.+)\s',1,b.n,NULL,1), REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+S\d\d\d.+//(\+?.+)\s',1,b.n,NULL,1)) text5,                                                                          
                     sadat,
                       
                      REGEXP_SUBSTR(sblock4_1 , ':61:(\d\d\d\d\d\d).*C.+//',1,b.n,NULL,1) svadat
                                                                             
              FROM a_cte a,(SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 100) b    
              WHERE  REGEXP_SUBSTR(sblock4_1, ':61:\d*+C.+(.+)//',1,b.n,NULL,1) IS NOT NULL            
               AND TO_NUMBER (TO_CHAR( TO_DATE(REGEXP_SUBSTR(sblock4_1, ':61:(\d\d\d\d\d\d).*C.+//',1,b.n,NULL,1), 'yymmdd') , 'yyyymmdd' ))= TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd'))                
            ) c,   
            
           (SELECT sblock4_1,                          
                   stransref,                                                    
                   REGEXP_SUBSTR(sblock4_1, ':20:(\+?.+)\s',1,1,NULL,1) text2 ,
                   samnt,
                   scur ,
--                   svadat,
                   ssndr            
              FROM SWIFTGW.SWTTRNPF
                WHERE  stype IN ('103', '202', '20C') AND ssndr <>'DEMIKG22XXX'        
              -- and d.sadat >= to_number(to_char(to_date('01.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))
              -- and d.sadat <= to_number(to_char(to_date('18.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))         
                    AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
                    AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))
                           
                    AND ssts IN ('INBND', 'ACK')
            ) d
            
            
     where trim(text1) = trim(text2) 
     AND trim(text5) NOT IN (SELECT REFERENCE FROM CBS_SWIFT_MESSAGES  
                              WHERE sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
                                AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))) 
     AND trim(text1) NOT IN (SELECT REFERENCE FROM CBS_SWIFT_MESSAGES  
                              WHERE sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
                                AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd')));
                                                                                      
     r_swift_940_950_second swift_940_950_second%ROWTYPE;

       
CURSOR swift_cursor_910 IS

WITH a_cte AS (
    SELECT /*+ materialize */ 
           SUBSTR(sblock4_1, 1, 4000) sblock4_1,
           sadat,
           svadat
      FROM SWIFTGW.SWTTRNPF
     WHERE stype = '910'
       --and sadat >= to_number(to_char(to_date('09.08.2022', 'dd.mm.yyyy') , 'yyyymmdd')) 
      -- and sadat <= to_number(to_char(to_date('11.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))       
        AND sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-1, 'yyyymmdd') )
        AND sadat <  TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd'))
        AND ssts IN ('INBND', 'ACK'))       
          
SELECT /*+use_hash(C,D)*/text1,
       NVL ( (REGEXP_SUBSTR(sblock4_1, ':52A:/?/?(.+)\s',1,1,NULL,1)),ssndr) senders_bic,
       NVL( (REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),'0') beneficiary_account,
       (REGEXP_SUBSTR(sblock4_1, ':59\w?:/.+\s(.+\s?.+)\s:70',1,1,NULL,1)) beneficiary_name,
       pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur) to_account,   
       pkg_musteri.sf_musteri_adi(pkg_hesap.getmusterinofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)))) to_name,
       NVL2(pkg_hesap.gethesapnofromexternal((REGEXP_SUBSTR(sblock4_1, ':59\w?:/(.{16})',1,1,NULL,1)),scur),'Yes','No') AS "MATCHED", 
       (REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s(.+\s?)',1,1,NULL,1)) senders_name,
       --(REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s?.+\s?(.+\s?)',1,1,NULL,1)) senders_address,
       (REGEXP_SUBSTR(SBLOCK4_1, ':70:(.+\s?.+\s?.+\s?.+\s?.+\s?)\s:\d\d\w?:',1,1,NULL,1)) explanation,  
      -- (REGEXP_SUBSTR(SUBSTR(SBLOCK4_1,REGEXP_INSTR(SBLOCK4_1,':50\w:'),REGEXP_INSTR(SBLOCK4_1,':52\w:')- REGEXP_INSTR(SBLOCK4_1,':50\w:')),':50\w?:.+\s?.+\s?(.+\s?.+\s?.+\s?.+\s?.+\s?)',1,1,NULL,1)) senders_address_2 ,
       (REGEXP_SUBSTR(sblock4_1, ':50\w?:(.+\s?)',1,1,NULL,1)) senders_address,--AndreiD06102022
       --(REGEXP_SUBSTR(sblock4_1, ':50\w?:.+\s.+\s(.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?.+\s?):52',1,1,NULL,1)) senders_address_2, --AndreiD12102022
       sblock4_1,
       stransref,
       samnt,
       scur ,
       svadat,
       sadat,
       ssndr   

  FROM (SELECT /*+ leading(a) use_nl(b) */ DISTINCT
               REGEXP_SUBSTR(SBLOCK4_1, ':21:(.+)\s',1,b.n,NULL,1) text1, 
               REGEXP_SUBSTR(SBLOCK4_1, ':20:(.+)\s',1,b.n,NULL,1) text11,                
               sadat, 
               REGEXP_SUBSTR(sblock4_1, ':32\w?:(\d\d\d\d\d\d)',1,b.n,NULL,1) svadat                            
          FROM a_cte a,(SELECT LEVEL n FROM dual CONNECT BY LEVEL <= 100) b
             WHERE REGEXP_SUBSTR(sblock4_1, ':21:(.+)\s',1,b.n,NULL,1) IS NOT NULL
              AND TO_NUMBER (TO_CHAR( TO_DATE(REGEXP_SUBSTR(sblock4_1, ':32\w?:(\d\d\d\d\d\d)',1,b.n,NULL,1), 'yymmdd') , 'yyyymmdd' ))= TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd'))
        ) c,
        
        
       (SELECT sblock4_1,
               stransref,
               REGEXP_SUBSTR(sblock4_1, ':20:(.+)\s',1,1,null,1) text2,
               samnt,
               scur ,
--               svadat,
               ssndr  
          FROM SWIFTGW.SWTTRNPF
         WHERE stype IN ('103', '202', '20C')
--          and sadat >= to_number(to_char(to_date('01.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))
--          and sadat <= to_number(to_char(to_date('18.08.2022', 'dd.mm.yyyy') , 'yyyymmdd'))        
           AND sadat >= TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') 
           AND sadat < TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd')           
--           AND TO_NUMBER (TO_CHAR( TO_DATE(LPAD (svadat,6,'0'), 'yymmdd') , 'yyyymmdd' )) = TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd'))                             
           AND ssts IN ('INBND', 'ACK')
        ) d
        
        
 WHERE trim(text1) = trim(text2)
    AND trim(text1) NOT IN (SELECT REFERENCE FROM CBS_SWIFT_MESSAGES  
                             WHERE sadat >= TO_NUMBER(TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') )
                                 AND sadat < TO_NUMBER(TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd')))
                                
   AND ( SELECT /*+ materialize */ COUNT (*) FROM SWIFTGW.SWTTRNPF
     WHERE sblock4_1 LIKE '%'||text11||'%'AND ((stype = '940' AND ssndr NOT IN ('ALFARUMMXXX','RZBMRUMMXXX')) OR stype = '950')  ) >0 
                                                              AND sadat >= TO_CHAR(TO_DATE(pd_start_date, 'dd.mm.yyyy')-16 , 'yyyymmdd') 
                                                              AND sadat < TO_CHAR(TO_DATE(pd_end_date, 'dd.mm.yyyy')+1 , 'yyyymmdd');
 
    r_swift_910 swift_cursor_910%ROWTYPE;

ld_date DATE;
ls_send_country_code CBS_BIC_KODLARI.BIC_ULKE_KODU%TYPE :='';--VARCHAR2(2BYTE)
ls_corr_bank_customer_no CBS_SWIFT_MESSAGES.CORR_BANK_CUST_NO%TYPE :='';
ls_corr_bank_account CBS_SWIFT_MESSAGES.CORR_BANK_ACCOUNT%TYPE :='';
ls_corr_bank_country CBS_SWIFT_MESSAGES.CORR_BANK_COUNTRY_CODE%TYPE :='';
ls_status CBS_SWIFT_MESSAGES.STATUS%TYPE :='';
ls_statistical_code CBS_SWIFT_MESSAGES.STATISTICAL_CODE%TYPE :='';
ls_beneficiary_n  CBS_SWIFT_MESSAGES.BENEFICIARY_NAME%TYPE :='';
ls_senders_address_2 CBS_SWIFT_MESSAGES.SENDERS_ADDRESS_2%TYPE :='';
ls_explanation CBS_SWIFT_MESSAGES.EXPLANATION%TYPE :='';
ls_explanation_full CBS_SWIFT_MESSAGES.EXPLANATION%TYPE :='';

ls_text1 CBS_SWIFT_MESSAGES.REFERENCE%TYPE;
ln_ST NUMBER;
ln_end NUMBER;
ln_leng NUMBER;

/*BOM AndreiD 12102022*/
ln_st1 NUMBER;
ln_end1 NUMBER;
ln_leng1 NUMBER;
/*EOM AndreiD 12102022*/


BEGIN
    
ls_status  := 'sIncome'; --AndreiD12102022

IF ps_type='MT 940/MT 950' THEN

   FOR r_swift_940_950 IN swift_cursor_940_950 LOOP            
   EXIT WHEN swift_cursor_940_950%NOTFOUND;  
   
     /*BOM AndreiD 28092022*/
     ls_beneficiary_n := NULL;
     ls_explanation_full  := NULL;
     ls_senders_address_2:= NULL;
     ls_send_country_code:= NULL;
     ls_corr_bank_customer_no:= NULL;
     ls_corr_bank_account:= NULL;
     ls_corr_bank_country:= NULL;
    -- ls_status:= NULL;
     ls_statistical_code:= NULL;
     ln_st:= NULL;
     ln_end:= NULL;
     ln_leng := NULL;
     ls_explanation:= NULL; 
    /*EOM AndreiD 28092022*/   
     
     /*BOM AndreiD 12102022*/
     ln_st1:= NULL;
     ln_end1:= NULL;
     ln_leng1 := NULL;
     
     /*EOM AndreiD 12102022*/

   
    ls_send_country_code := pkg_swift_automation.Contry_Code_By_BIC(NVL ( (REGEXP_SUBSTR(r_swift_940_950.sblock4_1, ':52\w?:/?/?(.+)\s',1,1,NULL,1)),r_swift_940_950.SSNDR));   
    --ls_corr_bank_customer_no :=  pkg_swift_automation.Customer_No_By_BIC(r_swift_940_950.SSNDR);
    --ls_corr_bank_account := pkg_swift_automation.Get_Bank_Account(r_swift_940_950.SCUR,  pkg_swift_automation.Customer_No_By_BIC(r_swift_940_950.SSNDR));
    --ls_corr_bank_country :=   pkg_swift_automation.Contry_Code_By_BIC(r_swift_940_950.SSNDR);   
    --ls_senders_address_2  := r_swift_940_950.senders_address_2; -- (REGEXP_SUBSTR(r_swift_940_950.sblock4_1, ':50\w?:.+\s?.+\s?.+\s?([^.*\s?]*):52',1,1,'m',1));--AndreiD06102022

 

     /*BOM AndreiD 29112022*/
    BEGIN
        SELECT musteri_no 
        INTO ls_corr_bank_customer_no
        FROM cbs_musteri
        WHERE musteri_tipi_kod='4' AND bic_kod = SUBSTR(r_swift_940_950.ssndr, 0, LENGTH(r_swift_940_950.ssndr) - 3) || 'XXX'
        AND 0 < (SELECT COUNT(*) FROM cbs_hesap WHERE cbs_hesap.musteri_no = cbs_musteri.musteri_no AND 
        pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod,'NOSTRO_MU') = 'E')
        AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_customer_no := NULL;
    END; 
     
     
    BEGIN
        SELECT TO_CHAR(hesap_no), /*TO_CHAR(cbs_hesap.sube_kodu),*/ TO_CHAR(cbs_musteri.uyruk_kod)
        INTO ls_corr_bank_account, /*ls_sender_corr_branch,*/ ls_corr_bank_country
        FROM cbs_hesap, cbs_musteri
        WHERE (cbs_hesap.musteri_no = cbs_musteri.musteri_no) AND cbs_hesap.doviz_kodu = r_swift_940_950.scur
            AND cbs_hesap.durum_kodu = 'A' AND cbs_hesap.modul_tur_kod = pkg_tx2010.Sf_Rg_HesapModulTur
            --and (pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod, 'NOSTRO_MU') = 'E')
            AND cbs_hesap.URUN_TUR_KOD in ( 'NOSTRO-FC')--AndreiD21122022
            and cbs_hesap.musteri_no = ls_corr_bank_customer_no AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_account := NULL;
            ls_corr_bank_country := NULL;
           -- ls_sender_corr_branch := NULL;
    END;
         
     /*EOM AndreiD 29112022*/

      IF INSTR(r_swift_940_950.sblock4_1,':70:')> 0 THEN
        
         IF REGEXP_INSTR(r_swift_940_950.sblock4_1,':71\w:')> 0 THEN

          ln_st:=REGEXP_INSTR(r_swift_940_950.sblock4_1,':70:');
          ln_end:= ( REGEXP_INSTR(r_swift_940_950.sblock4_1,':71\w?:',ln_st,1, 0, 'i'));
          ln_leng:=ln_end-ln_st;
          ls_explanation := SUBSTR(r_swift_940_950.sblock4_1,ln_st+4,ln_leng-4);
       
         ELSIF REGEXP_INSTR(r_swift_940_950.sblock4_1,':33\w:')> 0 THEN

          ln_st:=(REGEXP_INSTR(r_swift_940_950.sblock4_1,':70:'));  
          ln_end:= ( REGEXP_INSTR(r_swift_940_950.sblock4_1,':33\w?:',ln_st,1, 0, 'i'));
          ln_leng:=ln_end-ln_st;
          ls_explanation := SUBSTR(r_swift_940_950.sblock4_1,ln_st+4,ln_leng-4);    
       
         END IF;
      
     END IF;

       ls_explanation_full := ls_explanation;
   
       IF r_swift_940_950.SENDERS_NAME IS NOT NULL THEN
        ls_explanation_full := ls_explanation_full ||' от '||r_swift_940_950.SENDERS_NAME;
       END IF ;
       
       IF r_swift_940_950.BENEFICIARY_NAME IS NOT NULL THEN
       
        ls_explanation_full := ls_explanation_full ||' для '|| r_swift_940_950.BENEFICIARY_NAME;
        
        IF r_swift_940_950.SCUR ='RUB' THEN
          ls_beneficiary_n := pkg_report4.CYR2LAT_RUB( r_swift_940_950.beneficiary_name);      
        ELSE
          ls_beneficiary_n := pkg_report4.CYR2LAT( r_swift_940_950.beneficiary_name);
        END IF;
            
        
       END IF ;
       
       IF r_swift_940_950.SCUR ='RUB' Then
        ls_explanation_full:= REGEXP_REPLACE (ls_explanation_full,'`','"');         
       END IF ;

       IF  ls_explanation IS NOT NULL THEN
           ls_statistical_code:= pkg_swift_automation.Get_Istatistical_Code(ls_explanation);
       END IF; 
         
      /*BOM AndreiD 12102022*/
       IF REGEXP_INSTR(r_swift_940_950.sblock4_1,':50\w?:')> 0 THEN

          ln_st1:=REGEXP_INSTR(r_swift_940_950.sblock4_1,':50\w?:.+\s.+\s',1,1,1);
          ln_end1:= (REGEXP_INSTR(r_swift_940_950.sblock4_1,':52\w?:',ln_st1,1, 0, 'i'));
          ln_leng1:=ln_end1-ln_st1;
          ls_senders_address_2 := SUBSTR(r_swift_940_950.sblock4_1,ln_st1,ln_leng1);
        
       END IF;
     /*EOM AndreiD 12102022*/
  
       ls_text1:=trim(r_swift_940_950.text1);
  
       INSERT INTO CBS_SWIFT_MESSAGES (reference,senders_bank_bic,beneficiary_account,beneficiary_name,amount,currency,value_date,to_external_account,to_account,to_name,matched,explanation,message_type,
                                        senders_name,senders_address,senders_address_2,senders_country_code,corr_bank_bic,corr_bank_cust_no,corr_bank_account,corr_bank_country_code,status,statistical_code,sadat)
       VALUES
         (trim(r_swift_940_950.text1), r_swift_940_950.senders_bic,r_swift_940_950.beneficiary_account,
         ls_beneficiary_n,r_swift_940_950.samnt,r_swift_940_950.scur,TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd')),r_swift_940_950.beneficiary_account,r_swift_940_950.to_account,
         r_swift_940_950.to_name,r_swift_940_950.matched,ls_explanation_full,ps_type,r_swift_940_950.senders_name,r_swift_940_950.senders_address,ls_senders_address_2,
         ls_send_country_code,r_swift_940_950.ssndr,ls_corr_bank_customer_no,ls_corr_bank_account,ls_corr_bank_country, ls_status,ls_statistical_code,r_swift_940_950.sadat);

       ls_text1:=NULL;
     
     
   END LOOP;--2
       
   COMMIT;   

   FOR r_swift_940_950_second IN swift_940_950_second LOOP                 
   EXIT WHEN swift_940_950_second%NOTFOUND;  
   
     /*BOM AndreiD 28092022*/
     ls_beneficiary_n := NULL;
     ls_explanation_full  := NULL;
     ls_senders_address_2:= NULL;
     ls_send_country_code:= NULL;
     ls_corr_bank_customer_no:= NULL;
     ls_corr_bank_account:= NULL;
     ls_corr_bank_country:= NULL;
     --ls_status:= NULL;
     ls_statistical_code:= NULL;   
     ln_st:= NULL;
     ln_end:= NULL;
     ln_leng := NULL;
     ls_explanation:= NULL;
     /*EOM AndreiD 28092022*/
      
       /*BOM AndreiD 12102022*/
     ln_st1:= NULL;
     ln_end1:= NULL;
     ln_leng1 := NULL;
     /*EOM AndreiD 12102022*/

     ls_send_country_code := pkg_swift_automation.Contry_Code_By_BIC(NVL ( (regexp_substr(r_swift_940_950_second.SBLOCK4_1, ':52\w?:/?/?(.+)\s',1,1,null,1)),r_swift_940_950_second.SSNDR));    
     --ls_corr_bank_customer_no :=  pkg_swift_automation.Customer_No_By_BIC(r_swift_940_950_second.SSNDR);   
     --ls_corr_bank_account := pkg_swift_automation.Get_Bank_Account(r_swift_940_950_second.SCUR,  pkg_swift_automation.Customer_No_By_BIC(r_swift_940_950_second.SSNDR));
     --ls_corr_bank_country :=   pkg_swift_automation.Contry_Code_By_BIC(r_swift_940_950_second.SSNDR);  
     --ls_senders_address_2  :=   r_swift_940_950_second.senders_address_2; --(regexp_substr(r_swift_940_950_second.sblock4_1, ':50\w?:.+\s?.+\s?.+\s?([^.*\s?]*):52',1,1,'m',1)); --AndreiD06102022

     
     /*BOM AndreiD 29112022*/
    BEGIN
        SELECT musteri_no 
        INTO ls_corr_bank_customer_no
        FROM cbs_musteri
        WHERE musteri_tipi_kod='4' AND bic_kod = SUBSTR(r_swift_940_950_second.ssndr, 0, LENGTH(r_swift_940_950_second.ssndr) - 3) || 'XXX'
        AND 0 < (SELECT COUNT(*) FROM cbs_hesap WHERE cbs_hesap.musteri_no = cbs_musteri.musteri_no AND 
        pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod,'NOSTRO_MU') = 'E')
        AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_customer_no := NULL;
    END; 
     
     
    BEGIN
        SELECT TO_CHAR(hesap_no), /*TO_CHAR(cbs_hesap.sube_kodu),*/ TO_CHAR(cbs_musteri.uyruk_kod)
        INTO ls_corr_bank_account, /*ls_sender_corr_branch,*/ ls_corr_bank_country
        FROM cbs_hesap, cbs_musteri
        WHERE (cbs_hesap.musteri_no = cbs_musteri.musteri_no) AND cbs_hesap.doviz_kodu = r_swift_940_950_second.scur--AndreiD22122022
            AND cbs_hesap.durum_kodu = 'A' AND cbs_hesap.modul_tur_kod = pkg_tx2010.Sf_Rg_HesapModulTur
           -- and (pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod, 'NOSTRO_MU') = 'E')
            AND cbs_hesap.URUN_TUR_KOD in ( 'NOSTRO-FC')--AndreiD21122022
            and cbs_hesap.musteri_no = ls_corr_bank_customer_no AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_account := NULL;
            ls_corr_bank_country := NULL;
           -- ls_sender_corr_branch := NULL;
    END;
         
     /*EOM AndreiD 29112022*/



      IF INSTR(r_swift_940_950_second.SBLOCK4_1,':70:')> 0 THEN
         
         IF REGEXP_INSTR(r_swift_940_950_second.SBLOCK4_1,':71\w:')> 0 THEN

          ln_st:=regexp_instr(r_swift_940_950_second.SBLOCK4_1,':70:');
          ln_end:= ( regexp_instr(r_swift_940_950_second.SBLOCK4_1,':71\w?:',ln_st,1, 0, 'i'));
          ln_leng:=ln_end-ln_st;  
          ls_explanation := SUBSTR(r_swift_940_950_second.SBLOCK4_1,ln_st+4,ln_leng-4);
       
         ELSIF REGEXP_INSTR(r_swift_940_950_second.SBLOCK4_1,':33\w:')> 0 THEN

          ln_st:=(regexp_instr(r_swift_940_950_second.SBLOCK4_1,':70:'));     
          ln_end:= ( regexp_instr(r_swift_940_950_second.SBLOCK4_1,':33\w?:',ln_st,1, 0, 'i'));    
          ln_leng:=ln_end-ln_st;
          ls_explanation := SUBSTR(r_swift_940_950_second.SBLOCK4_1,ln_st+4,ln_leng-4);

        END IF;
      
     END IF;

       ls_explanation_full := ls_explanation;
   
       IF r_swift_940_950_second.SENDERS_NAME IS NOT NULL THEN
          ls_explanation_full := ls_explanation_full ||' от '||r_swift_940_950_second.SENDERS_NAME;
       END IF ;
           
       IF r_swift_940_950_second.BENEFICIARY_NAME IS NOT NULL THEN
       
          ls_explanation_full := ls_explanation_full ||' для '|| r_swift_940_950_second.BENEFICIARY_NAME;
          
           IF r_swift_940_950_second.SCUR ='RUB' THEN
            ls_beneficiary_n := pkg_report4.CYR2LAT_RUB( r_swift_940_950_second.beneficiary_name);      
           ELSE
            ls_beneficiary_n := pkg_report4.CYR2LAT( r_swift_940_950_second.beneficiary_name);
           END IF;
           
       END IF ;
           
       IF r_swift_940_950_second.SCUR ='RUB' Then
          ls_explanation_full:= REGEXP_REPLACE (ls_explanation_full,'`','"');
       END IF ;

       IF  ls_explanation IS NOT NULL THEN
          ls_statistical_code:= pkg_swift_automation.Get_Istatistical_Code(ls_explanation);
       END IF;   

      /*BOM AndreiD 12102022*/
       IF REGEXP_INSTR(r_swift_940_950_second.sblock4_1,':50\w?:')> 0 THEN

          ln_st1:=REGEXP_INSTR(r_swift_940_950_second.sblock4_1,':50\w?:.+\s.+\s',1,1,1);
          ln_end1:= (REGEXP_INSTR(r_swift_940_950_second.sblock4_1,':52\w?:',ln_st1,1, 0, 'i'));
          ln_leng1:=ln_end1-ln_st1;
          ls_senders_address_2 := SUBSTR(r_swift_940_950_second.sblock4_1,ln_st1,ln_leng1);
        
       END IF;
     /*EOM AndreiD 12102022*/

   
   INSERT INTO CBS_SWIFT_MESSAGES (reference,senders_bank_bic,beneficiary_account,beneficiary_name,amount,currency,value_date,to_external_account,to_account,to_name,matched,explanation,message_type,
                                    senders_name,senders_address,senders_address_2,senders_country_code,corr_bank_bic,corr_bank_cust_no,corr_bank_account,corr_bank_country_code,status,statistical_code,sadat)
   VALUES
     (trim(r_swift_940_950_second.text1), r_swift_940_950_second.senders_bic,r_swift_940_950_second.beneficiary_account,ls_beneficiary_n,r_swift_940_950_second.samnt,r_swift_940_950_second.scur,
     TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd')),r_swift_940_950_second.beneficiary_account,r_swift_940_950_second.to_account,r_swift_940_950_second.to_name,r_swift_940_950_second.matched,
     ls_explanation_full,ps_type,r_swift_940_950_second.senders_name,r_swift_940_950_second.senders_address,ls_senders_address_2,ls_send_country_code,r_swift_940_950_second.SSNDR,ls_corr_bank_customer_no,
     ls_corr_bank_account,ls_corr_bank_country,  ls_status,ls_statistical_code,r_swift_940_950_second.sadat);
   END LOOP;--2*/  

  COMMIT;

ELSE
     
   FOR r_swift_910 IN swift_cursor_910 LOOP            
    EXIT WHEN swift_cursor_910%NOTFOUND; 
    
    /*BOM AndreiD 28092022*/
     ls_beneficiary_n := NULL;
     ls_explanation_full  := NULL;
     ls_senders_address_2:= NULL;
     ls_send_country_code:= NULL;
     ls_corr_bank_customer_no:= NULL;
     ls_corr_bank_account:= NULL;
     ls_corr_bank_country:= NULL;
     --ls_status:= NULL;
     ls_statistical_code:= NULL;
     ln_st:= NULL;
     ln_end:= NULL;
     ln_leng := NULL;
     ls_explanation:= NULL;
     /*EOM AndreiD 28092022*/     
     
     /*BOM AndreiD 12102022*/
     ln_st1:= NULL;
     ln_end1:= NULL;
     ln_leng1 := NULL;     
     /*EOM AndreiD 12102022*/

      
         IF INSTR(r_swift_910.SBLOCK4_1,':70:')> 0 THEN    
               IF REGEXP_INSTR(r_swift_910.SBLOCK4_1,':71\w:')> 0 THEN
                  ln_st:=REGEXP_INSTR(r_swift_910.SBLOCK4_1,':70:'); 
                  ln_end:= ( regexp_instr(r_swift_910.SBLOCK4_1,':71\w?:',ln_st,1, 0, 'i'));--end 
                  ln_leng:=ln_end-ln_st;
                  ls_explanation := SUBSTR(r_swift_910.SBLOCK4_1,ln_st+4,ln_leng-4);   
              ELSIF REGEXP_INSTR(r_swift_910.SBLOCK4_1,':33\w:')> 0 THEN

            ln_st:=(regexp_instr(r_swift_910.SBLOCK4_1,':70:'));
            ln_end:= ( regexp_instr(r_swift_910.SBLOCK4_1,':33\w?:',ln_st,1, 0, 'i'));--end
            ln_leng:=ln_end-ln_st;
            ls_explanation := SUBSTR(r_swift_910.SBLOCK4_1,ln_st,ln_leng);
           
            END IF;
          
         END IF; 
   
   ls_send_country_code := pkg_swift_automation.Contry_Code_By_BIC(NVL ( (regexp_substr(r_swift_910.SBLOCK4_1, ':52\w?:/?/?(.+)\s',1,1,null,1)),r_swift_910.SSNDR));
   --ls_corr_bank_customer_no :=  pkg_swift_automation.Customer_No_By_BIC(r_swift_910.SSNDR);
   --ls_corr_bank_account := pkg_swift_automation.Get_Bank_Account(r_swift_910.SCUR,  pkg_swift_automation.Customer_No_By_BIC(r_swift_910.SSNDR));
   --ls_corr_bank_country :=   pkg_swift_automation.Contry_Code_By_BIC(r_swift_910.SSNDR);
   
   
        /*BOM AndreiD 29112022*/
    BEGIN
        SELECT musteri_no 
        INTO ls_corr_bank_customer_no
        FROM cbs_musteri
        WHERE musteri_tipi_kod='4' AND bic_kod = SUBSTR(r_swift_910.ssndr, 0, LENGTH(r_swift_910.ssndr) - 3) || 'XXX'
        AND 0 < (SELECT COUNT(*) FROM cbs_hesap WHERE cbs_hesap.musteri_no = cbs_musteri.musteri_no AND 
        pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod,'NOSTRO_MU') = 'E')
        AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_customer_no := NULL;
    END; 
     
     
    BEGIN
        SELECT TO_CHAR(hesap_no), /*TO_CHAR(cbs_hesap.sube_kodu),*/ TO_CHAR(cbs_musteri.uyruk_kod)
        INTO ls_corr_bank_account, /*ls_sender_corr_branch,*/ ls_corr_bank_country
        FROM cbs_hesap, cbs_musteri
        WHERE (cbs_hesap.musteri_no = cbs_musteri.musteri_no) AND cbs_hesap.doviz_kodu = r_swift_910.scur
            AND cbs_hesap.durum_kodu = 'A' AND cbs_hesap.modul_tur_kod = pkg_tx2010.Sf_Rg_HesapModulTur
            --and (pkg_parametre.deger(pkg_tx2010.Sf_Rg_HesapModulTur, cbs_hesap.urun_tur_kod, cbs_hesap.urun_sinif_kod, 'NOSTRO_MU') = 'E')
            AND cbs_hesap.URUN_TUR_KOD in ( 'NOSTRO-FC')--AndreiD21122022
            and cbs_hesap.musteri_no = ls_corr_bank_customer_no AND ROWNUM = 1;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            ls_corr_bank_account := NULL;
            ls_corr_bank_country := NULL;
           -- ls_sender_corr_branch := NULL;
    END;
         
     /*EOM AndreiD 29112022*/
   
   
   IF ls_explanation IS NOT NULL THEN
    ls_explanation_full := ls_explanation;
    END IF;
 
   IF r_swift_910.SENDERS_NAME IS NOT NULL THEN
      ls_explanation_full := ls_explanation_full ||' от '||r_swift_910.SENDERS_NAME;
   END IF ;
   
   IF r_swift_910.BENEFICIARY_NAME IS NOT NULL THEN
   
       ls_explanation_full := ls_explanation_full ||' для '|| r_swift_910.BENEFICIARY_NAME;
           
       IF r_swift_910.SCUR ='RUB' THEN
        ls_beneficiary_n := pkg_report4.CYR2LAT_RUB( r_swift_910.beneficiary_name);      
       ELSE
        ls_beneficiary_n := pkg_report4.CYR2LAT( r_swift_910.beneficiary_name);
       END IF;
       
   END IF ;
  
   IF r_swift_910.SCUR ='RUB' Then
    ls_explanation_full:= REGEXP_REPLACE (ls_explanation_full,'`','"');
   END IF ;

   IF  r_swift_910.EXPLANATION IS NOT NULL THEN
    ls_statistical_code:= pkg_swift_automation.Get_Istatistical_Code(r_swift_910.EXPLANATION);
   END IF ;


        /*BOM AndreiD 12102022*/
       IF REGEXP_INSTR(r_swift_910.sblock4_1,':50\w?:')> 0 THEN

          ln_st1:=REGEXP_INSTR(r_swift_910.sblock4_1,':50\w?:.+\s.+\s',1,1,1);
          ln_end1:= (REGEXP_INSTR(r_swift_910.sblock4_1,':52\w?:',ln_st1,1, 0, 'i'));
          ln_leng1:=ln_end1-ln_st1;
          ls_senders_address_2 := SUBSTR(r_swift_910.sblock4_1,ln_st1,ln_leng1);
        
       END IF;
     /*EOM AndreiD 12102022*/

   
   INSERT INTO CBS_SWIFT_MESSAGES (reference,senders_bank_bic,beneficiary_account,beneficiary_name,amount,currency,value_date,to_external_account,to_account,to_name,matched,explanation,message_type,         
                                   senders_name,senders_address,senders_address_2,senders_country_code,corr_bank_bic,corr_bank_cust_no,corr_bank_account,corr_bank_country_code,status,statistical_code,sadat)
   VALUES
     (trim(r_swift_910.text1), r_swift_910.senders_bic,r_swift_910.beneficiary_account,ls_beneficiary_n,r_swift_910.samnt,r_swift_910.scur, TO_NUMBER(TO_CHAR(TO_DATE(pd_svadat, 'dd.mm.yyyy') , 'yyyymmdd')),
     r_swift_910.beneficiary_account,r_swift_910.to_account,r_swift_910.to_name,r_swift_910.matched,ls_explanation_full,ps_type,r_swift_910.senders_name,r_swift_910.senders_address,ls_senders_address_2,
     ls_send_country_code,r_swift_910.ssndr,ls_corr_bank_customer_no,ls_corr_bank_account,ls_corr_bank_country,ls_status,ls_statistical_code,r_swift_910.sadat
     );
 
   END LOOP; 
    
END IF;
    
COMMIT;
EXCEPTION
    WHEN OTHERS THEN
     log_at('SF30012023',ls_text1);
     RAISE_APPLICATION_ERROR(-20100,ls_text1||' '||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE|| sqlerrm);
    
END;


FUNCTION  Contry_Code_By_BIC(ps_bic_kodu IN CBS_BIC_KODLARI.BIC_KODU%TYPE) RETURN VARCHAR2 IS
    ls_country_code                        VARCHAR2(100):='';
    ls_count NUMBER;
BEGIN

   /* SELECT  cbs_bic_kodlari.bic_ulke_kodu
      INTO ls_country_code
         FROM cbs_bic_kodlari
    WHERE cbs_bic_kodlari.bic_kodu=ps_bic_kodu;*/ 
    
     

     SELECT count(*)
        INTO ls_count
        FROM CBS_BIC_KODLARI 
        WHERE bic_kodu = ps_bic_kodu;
                            
                 
    
/*BOM AndreiD 12102022*/
    IF ps_bic_kodu IS NOT NULL AND ls_count>0 THEN
    
     SELECT bic_ulke_kodu
        INTO ls_country_code
        FROM CBS_BIC_KODLARI 
        WHERE bic_kodu = ps_bic_kodu;
    
    END IF;
/*EOM AndreiD 12102022*/

--  IF ls_country_code IS NULL THEN  
  
  
     IF INSTR (ps_bic_kodu,'RU') > 0 THEN 
  
       ls_country_code:= 'RU' ;
   
     ELSE 
  
       ls_country_code := SUBSTR (ps_bic_kodu,5,2);
  
     END IF;
   
   
   
   
--  END IF;
  
 
    RETURN ls_country_code;
  
EXCEPTION
     WHEN NO_DATA_FOUND THEN
           --ls_country_code := SUBSTR (ps_bic_kodu,5,2);
           RETURN ls_country_code;
END;

FUNCTION  Customer_No_By_BIC(ps_bic_kodu IN cbs_bic_kodlari.bic_kodu%TYPE) RETURN VARCHAR2 IS
    ln_customer_no                        VARCHAR2(200 BYTE):='';
BEGIN
    

 
    SELECT TO_CHAR(musteri_no)
       INTO ln_customer_no
    FROM cbs_musteri  
    WHERE  bic_kod = ps_bic_kodu
    AND  CBS_MUSTERI.MUSTERI_TIPI_KOD='4';
    RETURN ln_customer_no;
    
EXCEPTION
     WHEN NO_DATA_FOUND THEN
           RETURN ln_customer_no;    
           WHEN OTHERS THEN
 RETURN ln_customer_no;   
           
END;


FUNCTION  Get_Bank_Account (ps_currency IN VARCHAR2, pn_customer_no IN CBS_HESAP.HESAP_NO%TYPE) RETURN VARCHAR2 IS
    ln_bank_account VARCHAR2(200 BYTE):='';
BEGIN
   
    SELECT TO_CHAR( CBS_HESAP.HESAP_NO)
       INTO ln_bank_account       
    FROM CBS_HESAP  
     WHERE  MUSTERI_NO = pn_customer_no
      AND DOVIZ_KODU =ps_currency   
      AND DURUM_KODU='A'
      AND CBS_HESAP.MODUL_TUR_KOD='CURRENT'
      AND ROWNUM=1;      
    
    RETURN ln_bank_account;
    
EXCEPTION
     WHEN NO_DATA_FOUND THEN
           RETURN ln_bank_account;
END;

FUNCTION  Get_Istatistical_Code (ps_explanation  cbs_swift_messages.explanation%TYPE) RETURN VARCHAR2 IS

ls_expl VARCHAR2(200);
ls_ist_code VARCHAR2(200);
ls_code VARCHAR2(200);
ls_expl_1 VARCHAR2(2000);

CURSOR c1_expl IS 
    SELECT istatistik_kodu,swift_tags FROM cbs_istatistik_kodlari
WHERE swift_tags IS NOT NULL;--AndreiD 23092022


r_c1_expl c1_expl%ROWTYPE;
ls_tag varchar2(2000);
ln_count number;

BEGIN

    FOR r_tx IN c1_expl LOOP
        ln_count := 0;
        LOOP
            ls_tag := PKG_TX3556.SPLITSTR(r_tx.swift_tags,ln_count, ',');
            
            log_at('0802','ls_tag'||'  '||ls_tag);
            
            EXIT WHEN ls_tag IS NULL;
            
            log_at('0802','ps_explanation'||'  '||ps_explanation);
            
--           IF INSTR(ps_explanation, ls_tag)>0 THEN
--             RETURN r_tx.istatistik_kodu;
--           END IF;
            IF ps_explanation LIKE '%'||' '||ls_tag||' '||'%'  THEN
                RETURN r_tx.istatistik_kodu;
            END IF;
            ln_count := ln_count + 1;
        END LOOP;
    END LOOP;


RETURN '040801';
EXCEPTION
     WHEN NO_DATA_FOUND THEN
           RETURN '040801';

END;


FUNCTION  Check_Customer_Name (ps_cust_name  cbs_swift_messages.beneficiary_name%TYPE, pn_account cbs_swift_messages.to_account%TYPE ) RETURN NUMBER IS

    ls_snd_customer varchar2(200 BYTE);
    ls_our_cust_name varchar2(200 BYTE);
    ls_our_cust_name_eng varchar2(200 BYTE);
    ln_similarity NUMBER;
    ln_similarity_eng NUMBER;
    ln_our_cust_no NUMBER;

BEGIN
log_at('1502',0,ps_cust_name||' '||pn_account);
   ln_our_cust_no := pkg_hesap.GetMusteriNoFromExternal(trim(pn_account));
   
log_at('1502',1,ln_our_cust_no||' '||ln_our_cust_no);

    SELECT NVL (TICARI_UNVAN, ISIM||' '||IKINCI_ISIM||' '||SOYADI)
     INTO ls_our_cust_name
       FROM cbs_musteri 
    WHERE musteri_no=ln_our_cust_no;
    
    
    SELECT NVL(LOKAL_UNVAN,'')
     INTO ls_our_cust_name_eng
       FROM cbs_musteri 
    WHERE musteri_no=ln_our_cust_no;
    
log_at('1502',2,ls_our_cust_name||' '||ls_our_cust_name);
log_at('1502',3,'ls_our_cust_name'||' '||ls_our_cust_name||'-'||'ps_cust_name'||' '||ps_cust_name);

    SELECT UTL_MATCH.EDIT_DISTANCE_SIMILARITY(ls_our_cust_name, ps_cust_name)     
     INTO ln_similarity
    FROM DUAL;
    
    SELECT UTL_MATCH.EDIT_DISTANCE_SIMILARITY(ls_our_cust_name_eng, ps_cust_name)     
     INTO ln_similarity_eng
    FROM DUAL;
    
    
log_at('1502',4,'ln_similarity'||' '||ln_similarity);

   IF (ln_similarity>60 OR ln_similarity_eng>60) THEN
   
         RETURN 1;
   ELSE      
         RETURN 0;
         
   END IF;


EXCEPTION
     WHEN NO_DATA_FOUND THEN
           RETURN 0;

END;




BEGIN
--STEP2
    Null;
End;
/

