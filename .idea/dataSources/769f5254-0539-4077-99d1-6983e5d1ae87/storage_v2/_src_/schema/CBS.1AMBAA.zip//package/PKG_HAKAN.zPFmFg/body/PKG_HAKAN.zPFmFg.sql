create PACKAGE BODY PKG_HAKAN is
-----------------------------------------------------------------------------------
PROCEDURE ACC_MAINTENANCE_FEE(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2)
IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;

	ln_fis_numara   number;
	ln_counter   number;
	ln_temp_numara   number;

	p_7048_ACC_BRANCH         NUMBER;
	p_7048_TRAN_BRANCH             NUMBER;
	p_7048_ACC        	   NUMBER;
	p_7048_INCOME_GL             NUMBER;
	p_7048_CY          	   NUMBER;
	p_7048_EXPLAIN       NUMBER;
	p_7048_AMOUNT_FC          NUMBER;
	p_7048_AMOUNT_LC        	   NUMBER;
	p_7048_RATE        NUMBER;

	p_7048_TAX_FC          NUMBER;
	p_7048_TAX_LC          NUMBER;
	p_7048_TAX_EXPLAIN          NUMBER;

	CURSOR c_musteri IS
		SELECT 	MUSTERI_NO,DK_GRUP_KOD, BOLUM_KODU
		FROM CBS_MUSTERI
		WHERE DURUM_KODU = 'A'
		     AND MUSTERI_TIPI_KOD in ('1','2','3')
and musteri_no > 40024
		     AND HESAP_UCRETI_F = 'E'
		     AND MUSTERI_NO NOT IN (SELECT DISTINCT MUSTERI_NO
								 FROM CBS_MUSTERI_ISLEM_MASRAF_MUAF
								 WHERE ISLEM_KODU = 7048
								   AND MASRAF_KODU = 'ACCMAINFEE')
		and
		('ACCMAINFEE',MUSTERI_NO,to_number(to_char(to_date('30062009','ddmmyyyy'),'YYYY')),to_number(to_char(to_date('30062009','ddmmyyyy'),'MM')))
		not in (select CHARGE_CODE, MUSTERI_NO, YIL, AY
			    from CBS_FEE_TAHSIL_EDILEN_ACCFEE)
		and
		('ACCMAINFEE',MUSTERI_NO,to_number(to_char(to_date('30062009','ddmmyyyy'),'YYYY')),to_number(to_char(to_date('30062009','ddmmyyyy'),'MM')))
		not in (select CHARGE_CODE, MUSTERI_NO, YIL, AY
			    from CBS_FEE_TAH_EDILEMEYEN_ACCFEE)
	     AND MUSTERI_NO NOT IN (SELECT DISTINCT customer_no
							FROM CBS_CUSTOMER_FEE)
		ORDER BY musteri_no ;
		r_musteri		c_musteri%ROWTYPE;
	--
	CURSOR c_hesap_som IS
		SELECT *
		FROM CBS_HESAP
		WHERE musteri_no = r_musteri.musteri_no
		AND durum_kodu = 'A'
		AND urun_tur_kod in ('CURRENT','DEMAND DEP')
		AND doviz_kodu = pkg_genel.LC_al
		ORDER BY pkg_hesap.Kullanilabilir_Bakiye_Al(hesap_no) desc;
		r_hesap_som 	c_hesap_som%ROWTYPE;
	--
	CURSOR c_hesap_non_som(ls_dvz varchar2) IS
		SELECT *
		FROM CBS_HESAP
		WHERE musteri_no = r_musteri.musteri_no
		AND durum_kodu = 'A'
		AND urun_tur_kod in ('CURRENT','DEMAND DEP')
		AND doviz_kodu <> pkg_genel.LC_al
		ORDER BY pkg_tx7047.hesap_bakiye_goreceli(HESAP_NO,ls_dvz) desc;
		r_hesap_non_som 	c_hesap_non_som%ROWTYPE;

	ld_bas   DATE;
	ld_son   DATE;
	ln_yil   NUMBER;
	ln_ay   NUMBER;
	ln_amnt_ind   NUMBER;
	ls_cy_ind   VARCHAR2(3);
	ln_amnt_corp   NUMBER;
	ls_cy_corp   VARCHAR2(3);
	ln_cnt   NUMBER;

	ln_kur_ucret_dvz   NUMBER;
	ln_kur_hesap_dvz   NUMBER;
	ln_masraf   NUMBER;
	ln_bakiye   NUMBER;
	ln_amnt   NUMBER;
	ls_cy   VARCHAR2(3);
	ls_uygun   VARCHAR2(1);
	ln_sira  number;

	ln_toplam_tahsil  number;
	ln_kalan_tahsilat  number;
	ln_hesaptan_al  number;
	ln_muhasebelesecek_tutar  number;
	ln_tahsil_tutar  number;
	ln_kal  number;
	ln_islem_no			   	   NUMBER := 0;
	ls_dk   VARCHAR2(30);

	double_run_1  exception;
	double_run_2  exception;
	birden_fazla_parametre_var  exception;
	parametre_yok  exception;
	dk_yok  exception;
	ln_rate       number;
	ln_vergi	 number;
	ln_vergi_tl	 number;
BEGIN
	Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
	--
		Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);

	    p_7048_ACC_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_ACC_BRANCH');
		p_7048_TRAN_BRANCH :=Pkg_Muhasebe.parametre_index_bul('7048_TRAN_BRANCH');
		p_7048_ACC :=Pkg_Muhasebe.parametre_index_bul('7048_ACC');
		p_7048_INCOME_GL :=Pkg_Muhasebe.parametre_index_bul('7048_INCOME_GL');
		p_7048_CY :=Pkg_Muhasebe.parametre_index_bul('7048_CY');
		p_7048_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_EXPLAIN');

		p_7048_AMOUNT_FC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_FC');
		p_7048_AMOUNT_LC :=Pkg_Muhasebe.parametre_index_bul('7048_AMOUNT_LC');
		p_7048_RATE :=Pkg_Muhasebe.parametre_index_bul('7048_RATE');

		p_7048_TAX_FC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_FC');
		p_7048_TAX_LC :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_LC');
		p_7048_TAX_EXPLAIN :=Pkg_Muhasebe.parametre_index_bul('7048_TAX_EXPLAIN');

		ln_amnt_ind := 0;
		ls_cy_ind := null;
		ln_amnt_corp := 0;
		ls_cy_corp := null;

		select count(*)
		into ln_cnt
		from cbs_masraf_kriterleri
		where CHARGE_CODE = 'ACCMAINFEE'
		  and CUSTOMER_TYPE = 'INDIVIDUAL';
		if ln_cnt = 1
		then
			select CHARGE_AMOUNT, CHARGE_CURRENCY
			into ln_amnt_ind,ls_cy_ind
			from cbs_masraf_kriterleri
			where CHARGE_CODE = 'ACCMAINFEE'
			  and CUSTOMER_TYPE = 'INDIVIDUAL';
		else
			raise birden_fazla_parametre_var;
		end if;
		--
		select count(*)
		into ln_cnt
		from cbs_masraf_kriterleri
		where CHARGE_CODE = 'ACCMAINFEE'
		  and CUSTOMER_TYPE = 'CORPORATE';
		if ln_cnt = 1
		then
			select CHARGE_AMOUNT, CHARGE_CURRENCY
			into ln_amnt_corp,ls_cy_corp
			from cbs_masraf_kriterleri
			where CHARGE_CODE = 'ACCMAINFEE'
			  and CUSTOMER_TYPE = 'CORPORATE';
		else
			raise birden_fazla_parametre_var;
		end if;
		--
		ld_bas := to_date(to_char(ltrim(rtrim('01'||to_char(to_date('30062009','ddmmyyyy'),'MMYYYY')))),'DD.MM.YYYY');
		ld_son := LAST_DAY(to_date('30062009','ddmmyyyy'));
		ln_yil := to_number(to_char(to_date('30062009','ddmmyyyy'),'YYYY'));
		ln_ay := to_number(to_char(to_date('30062009','ddmmyyyy'),'MM'));
		--
		OPEN c_musteri ;
		LOOP
			FETCH c_musteri INTO r_musteri  ;
			EXIT WHEN c_musteri%NOTFOUND;
		 		ln_amnt := 0;
		 		ls_cy := null;
				ls_uygun := 'H';
				--
				select count(*)
				into ln_cnt
				from CBS_MUSTERI_ISLEM_MASRAF_FIX
				where musteri_no = r_musteri.musteri_no
				  and islem_kodu = 7048
				  and masraf_kodu = 'ACCMAINFEE';
				--
				if ln_cnt = 1
				then
					select nvl(TUTAR,0), DOVIZ
					into ln_amnt, ls_cy
					from CBS_MUSTERI_ISLEM_MASRAF_FIX
					where musteri_no = r_musteri.musteri_no
					and islem_kodu = 7048
					and masraf_kodu = 'ACCMAINFEE';
				else
					if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
					then
						ln_amnt := nvl(ln_amnt_ind,0);
						ls_cy := ls_cy_ind;
					end if;
					if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
					then
						ln_amnt := nvl(ln_amnt_corp,0);
						ls_cy := ls_cy_corp;
					end if;
				end if;
				--
				if nvl(ln_amnt,0) > 0 and ls_cy is not null
				then
					if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'INDIVIDUAL'
					then
						select count(*)
						into ln_cnt
						from cbs_hesap
						where durum_kodu = 'A'
						  and musteri_no = r_musteri.musteri_no
						  and urun_tur_kod in ('CURRENT','DEMAND DEP')
						  and doviz_kodu <> pkg_genel.LC_al
						  and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';

						if ln_cnt > 0
						then
							ls_uygun := 'E';
						end if;
					end if;
					--
					if pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no) = 'CORPORATE'
					then
						select count(*)
						into ln_cnt
						from cbs_hesap
						where durum_kodu = 'A'
						  and musteri_no = r_musteri.musteri_no
						  and urun_tur_kod in ('CURRENT','DEMAND DEP')
						  and pkg_tx7047.hesap_hareket_gormusmu(hesap_no,ld_bas,ld_son)='E';
						--
						if ln_cnt > 0
						then
							ls_uygun := 'E';
						end if;
					end if;
					--
					select count(*)
					into ln_cnt
					from CBS_MASRAF_DKGRUP_DK
					where MASRAF_KODU = 'ACCMAINFEE'
					  and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;

					if ln_cnt = 1
					then
						select DKHESAP_1
						into ls_dk
						from CBS_MASRAF_DKGRUP_DK
						where MASRAF_KODU = 'ACCMAINFEE'
						  and DK_GRUP_KODU = r_musteri.DK_GRUP_KOD;
					else
						raise dk_yok;
					end if;

					if ls_uygun = 'E' and ls_dk is not null
					then
						ln_counter := 0;

						select count(*)
						into ln_cnt
						from CBS_FEE_TAHSIL_EDILEN_ACCFEE
						where charge_code = 'ACCMAINFEE'
						  and musteri_no = r_musteri.MUSTERI_NO
						  and yil = ln_yil
						  and ay = ln_ay;

						if ln_cnt > 0
						then
							select max(sira)
							into ln_sira
							from CBS_FEE_TAHSIL_EDILEN_ACCFEE
							where charge_code = 'ACCMAINFEE'
							  and musteri_no = r_musteri.MUSTERI_NO
							  and yil = ln_yil
							  and ay = ln_ay;
						else
							ln_sira := 0;
						end if;

						ln_toplam_tahsil := 0;
						ln_kalan_tahsilat := ln_amnt;
						ln_hesaptan_al := 1;
	--
	------------------------------------------------ Asil simdi basliyor ---------------------------------------------
						OPEN c_hesap_som ;
						LOOP
							FETCH c_hesap_som INTO r_hesap_som  ;
							EXIT WHEN c_hesap_som%NOTFOUND;

								varchar_list(p_7048_ACC_BRANCH) := NULL;
								varchar_list(p_7048_TRAN_BRANCH) := NULL;
								varchar_list(p_7048_ACC) := NULL;
								varchar_list(p_7048_INCOME_GL) := NULL;
								varchar_list(p_7048_CY) := NULL;

								varchar_list(p_7048_EXPLAIN) := 'Account Maintenance Fee : '||
															 pkg_tx7047.month_name(ln_ay)||
															 ' / '||
															 ln_yil;

								varchar_list(p_7048_TAX_EXPLAIN) := 'Account Maintenance Fee Tax';

								number_list(p_7048_AMOUNT_FC):= 0;
								number_list(p_7048_AMOUNT_LC):= 0;
								number_list(p_7048_RATE) := 0 ;

								number_list(p_7048_TAX_FC):= 0;
								number_list(p_7048_TAX_LC):= 0;

								if ln_hesaptan_al = 1
								then
									ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
									ln_masraf := round((ln_kalan_tahsilat * ln_kur_ucret_dvz),2);
									ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_som.hesap_no),0)),2);

									ln_vergi_tl := round(((ln_masraf*ln_rate)/100),2);
									ln_vergi := ln_vergi_tl;
									--
									if ln_bakiye > 0
									then
										if ln_bakiye >= ln_masraf + ln_vergi
										then
											ln_tahsil_tutar := ln_kalan_tahsilat;
											ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
											ln_kal := ln_kalan_tahsilat;
											ln_kalan_tahsilat := 0;

											varchar_list(p_7048_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
											varchar_list(p_7048_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
											varchar_list(p_7048_ACC) := r_hesap_som.hesap_no;
											varchar_list(p_7048_INCOME_GL) := ls_dk;
											varchar_list(p_7048_CY) := r_hesap_som.DOVIZ_KODU;

											number_list(p_7048_AMOUNT_FC) := ln_masraf;
											number_list(p_7048_AMOUNT_LC) := ln_masraf;
											number_list(p_7048_RATE) := 1;

											number_list(p_7048_TAX_LC):=round(((number_list(p_7048_AMOUNT_LC)*ln_rate)/100),2);
											number_list(p_7048_TAX_FC):=round(((number_list(p_7048_AMOUNT_FC)*ln_rate)/100),2);

											IF ln_counter = 0
											THEN
												ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

												ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
																					2,
																					ln_islem_no,
																					varchar_list,
																					number_list,
																					date_list,
																					boolean_list ,
																					NULL,
																					FALSE,
																					0,
																					'ACCOUNT MAINTENANCE FEE');
											ELSE
												ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
																						 2,
																						 ln_fis_numara,
																						 varchar_list,
																						 number_list,
																						 date_list,
																						 boolean_list,
																						 NULL,
																						 FALSE);
											END IF;
											ln_counter:=ln_counter+1;
											--
											ln_sira := ln_sira + 1 ;
											insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
											(CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
											 TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
											 STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
											 TAHSIL_ZAMANI)
											values
											('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,
											 r_hesap_som.DOVIZ_KODU,
											 ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
	 										 'FULL',ln_islem_no, ln_fis_numara, ln_masraf,'ZAMANINDA');
										else
											ln_muhasebelesecek_tutar := trunc((ln_bakiye/(1+(ln_rate/100))),2);
											ln_tahsil_tutar := trunc((ln_muhasebelesecek_tutar/ln_kur_ucret_dvz),2);
											ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
											ln_kal := ln_kalan_tahsilat;
											ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

											varchar_list(p_7048_ACC_BRANCH) := r_hesap_som.SUBE_KODU;
											varchar_list(p_7048_TRAN_BRANCH) := r_hesap_som.SUBE_KODU;
											varchar_list(p_7048_ACC) := r_hesap_som.hesap_no;
											varchar_list(p_7048_INCOME_GL) := ls_dk;
											varchar_list(p_7048_CY) := r_hesap_som.DOVIZ_KODU;

											number_list(p_7048_AMOUNT_FC) := ln_muhasebelesecek_tutar;
											number_list(p_7048_AMOUNT_LC) := ln_muhasebelesecek_tutar;
											number_list(p_7048_RATE) := 1;

											number_list(p_7048_TAX_FC):=ln_bakiye - ln_muhasebelesecek_tutar;
											number_list(p_7048_TAX_LC):=round(((number_list(p_7048_AMOUNT_LC)*ln_rate)/100),2);

											IF ln_counter = 0 THEN
												ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

												ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
																					2,
																					ln_islem_no,
																					varchar_list,
																					number_list,
																					date_list,
																					boolean_list ,
																					NULL,
																					FALSE,
																					0,
																					'ACCOUNT MAINTENANCE FEE');
											ELSE
												ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
																						 2,
																						 ln_fis_numara,
																						 varchar_list,
																						 number_list,
																						 date_list,
																						 boolean_list,
																						 NULL,
																						 FALSE);
											END IF;
											ln_counter:=ln_counter+1;
											--
											ln_sira := ln_sira + 1 ;
											insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
											(CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
											 TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
											 STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
											 TAHSIL_ZAMANI)
											values
											('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_som.HESAP_NO,r_hesap_som.DOVIZ_KODU,
											 ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
											 'PARTIAL',ln_islem_no, ln_fis_numara, ln_muhasebelesecek_tutar,'ZAMANINDA');
										end if;
									end if;  -- if ln_bakiye >= 0
								end if;
								--
								if ln_kalan_tahsilat = 0
								then
									ln_hesaptan_al := 0;
								end if;
						END LOOP;
						CLOSE c_hesap_som;

						if ln_kalan_tahsilat > 0
						then
							ln_hesaptan_al := 1;
	--
	-------------------------------------------- NON SOM --------------------------------------------
							OPEN c_hesap_non_som(ls_cy) ;
							LOOP
								FETCH c_hesap_non_som INTO r_hesap_non_som  ;
								EXIT WHEN c_hesap_non_som%NOTFOUND;

								varchar_list(p_7048_ACC_BRANCH) := NULL;
								varchar_list(p_7048_TRAN_BRANCH) := NULL;
								varchar_list(p_7048_ACC) := NULL;
								varchar_list(p_7048_INCOME_GL) := NULL;
								varchar_list(p_7048_CY) := NULL;

								varchar_list(p_7048_EXPLAIN) := 'Account Maintenance Fee : '||
															 pkg_tx7047.month_name(ln_ay)||
															 ' / '||
															 ln_yil;

								varchar_list(p_7048_TAX_EXPLAIN) := 'Account Maintenance Fee Tax';

								number_list(p_7048_AMOUNT_FC):= 0;
								number_list(p_7048_AMOUNT_LC):= 0;
								number_list(p_7048_RATE) := 0 ;

								number_list(p_7048_TAX_FC):=0;
								number_list(p_7048_TAX_LC):=0;

								if ln_hesaptan_al = 1
								then
									ln_kur_ucret_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(ls_cy,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
									ln_kur_hesap_dvz := round((nvl(Pkg_Kur.doviz_doviz_karsilik(r_hesap_non_som.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4);
									ln_masraf := round(((ln_kalan_tahsilat * ln_kur_ucret_dvz)/ln_kur_hesap_dvz),2);
									ln_bakiye := trunc((nvl(pkg_hesap.Kullanilabilir_Bakiye_Al(r_hesap_non_som.hesap_no),0)),2);

									ln_vergi_tl := round(((ln_masraf * ln_kur_hesap_dvz * ln_rate) / 100),2);
									ln_vergi := round(ln_vergi_tl/ln_kur_hesap_dvz,2);
									--
									if ln_bakiye > 0
									then
										if ln_bakiye >= ln_masraf + ln_vergi
										then
											ln_tahsil_tutar := ln_kalan_tahsilat;
											ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
											ln_kal := ln_kalan_tahsilat;
											ln_kalan_tahsilat := 0;

											varchar_list(p_7048_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
											varchar_list(p_7048_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
											varchar_list(p_7048_ACC) := r_hesap_non_som.hesap_no;
											varchar_list(p_7048_INCOME_GL) := ls_dk;
											varchar_list(p_7048_CY) := r_hesap_non_som.DOVIZ_KODU;

											number_list(p_7048_AMOUNT_FC) := ln_masraf;
											number_list(p_7048_AMOUNT_LC) := round((ln_tahsil_tutar*ln_kur_ucret_dvz),2);
											number_list(p_7048_RATE) := ln_kur_hesap_dvz;

											number_list(p_7048_TAX_LC):=round(((number_list(p_7048_AMOUNT_LC)*ln_rate)/100),2);
											number_list(p_7048_TAX_FC):=round(((number_list(p_7048_AMOUNT_FC)*ln_rate)/100),2);

											IF ln_counter = 0
											THEN
												ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

												ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
																					1,
																					ln_islem_no,
																					varchar_list,
																					number_list,
																					date_list,
																					boolean_list ,
																					NULL,
																					FALSE,
																					0,
																					'ACCOUNT MAINTENANCE FEE');
											ELSE
												ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
																						 1,
																						 ln_fis_numara,
																						 varchar_list,
																						 number_list,
																						 date_list,
																						 boolean_list,
																						 NULL,
																						 FALSE);
											END IF;
											ln_counter:=ln_counter+1;
											--
											ln_sira := ln_sira + 1 ;
											insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
											(CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
											 TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
											 STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
											 TAHSIL_ZAMANI)
											values
											('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
											  r_hesap_non_som.DOVIZ_KODU,
											 ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
											 'FULL',ln_islem_no, ln_fis_numara, ln_masraf,'ZAMANINDA');
										else
											ln_muhasebelesecek_tutar := trunc((ln_bakiye/(1+(ln_rate/100))),2);
											ln_tahsil_tutar := trunc(((ln_muhasebelesecek_tutar*ln_kur_hesap_dvz)/ln_kur_ucret_dvz),2);
											ln_toplam_tahsil := ln_toplam_tahsil + ln_tahsil_tutar;
											ln_kal := ln_kalan_tahsilat;
											ln_kalan_tahsilat := ln_kalan_tahsilat - ln_tahsil_tutar;

											varchar_list(p_7048_ACC_BRANCH) := r_hesap_non_som.SUBE_KODU;
											varchar_list(p_7048_TRAN_BRANCH) := r_hesap_non_som.SUBE_KODU;
											varchar_list(p_7048_ACC) := r_hesap_non_som.hesap_no;
											varchar_list(p_7048_INCOME_GL) := ls_dk;
											varchar_list(p_7048_CY) := r_hesap_non_som.DOVIZ_KODU;

											number_list(p_7048_AMOUNT_FC) := ln_muhasebelesecek_tutar;
											number_list(p_7048_AMOUNT_LC) := round((number_list(p_7048_AMOUNT_FC)*ln_kur_hesap_dvz),2);
											number_list(p_7048_RATE) := ln_kur_hesap_dvz;

											number_list(p_7048_TAX_FC):=ln_bakiye - ln_muhasebelesecek_tutar;
											number_list(p_7048_TAX_LC):=round(((number_list(p_7048_AMOUNT_LC)*ln_rate)/100),2);

											IF ln_counter = 0 THEN
												ln_islem_no:=Pkg_Batch.islem_yarat(7048, r_musteri.BOLUM_KODU);

												ln_fis_numara:=Pkg_Muhasebe.fis_kes(7048,
																					1,
																					ln_islem_no,
																					varchar_list,
																					number_list,
																					date_list,
																					boolean_list ,
																					NULL,
																					FALSE,
																					0,
																					'ACCOUNT MAINTENANCE FEE');
											ELSE
												ln_temp_numara:=Pkg_Muhasebe.satir_ekle (7048,
																						 1,
																						 ln_fis_numara,
																						 varchar_list,
																						 number_list,
																						 date_list,
																						 boolean_list,
																						 NULL,
																						 FALSE);
											END IF;
											ln_counter:=ln_counter+1;
											--
											ln_sira := ln_sira + 1 ;
											insert into CBS_FEE_TAHSIL_EDILEN_ACCFEE
											(CHARGE_CODE, YIL, AY, MUSTERI_NO, SIRA, HESAP_NO, HESAP_DVZ,
											 TAHSILAT_DVZ, TAHSILAT_ONCE_KAL_TUT,TAHSIL_EDILEN_TUTAR, TAHSILAT_SONRA_KAL_TUT,
											 STATUS, ISLEM_NO, FIS_NO, TAHSIL_EDILEN_TUTAR_FC,
											 TAHSIL_ZAMANI)
											values
											('ACCMAINFEE',ln_yil,ln_ay,r_musteri.MUSTERI_NO,ln_sira,r_hesap_non_som.HESAP_NO,
											 r_hesap_non_som.DOVIZ_KODU,
											 ls_cy,ln_kal,ln_tahsil_tutar,ln_kalan_tahsilat,
											 'PARTIAL',ln_islem_no, ln_fis_numara, ln_muhasebelesecek_tutar,
											 'ZAMANINDA');
										end if;
									end if; -- if ln_bakiye >= 0
								end if;
								--
								if ln_kalan_tahsilat = 0
								then
									ln_hesaptan_al := 0;
								end if;
							END LOOP;
							CLOSE c_hesap_non_som;
						end if;

						select count(*)
						into ln_cnt
						from CBS_FEE_TAH_EDILEMEYEN_ACCFEE
						where CHARGE_CODE = 'ACCMAINFEE'
						  and yil = ln_yil
						  and ay = ln_ay
						  and musteri_no = r_musteri.MUSTERI_NO;

						if ln_cnt > 0
						then
						    raise double_run_2;
						end if;

						if ln_kalan_tahsilat > 0
						then
							insert into CBS_FEE_TAH_EDILEMEYEN_ACCFEE
							 (CHARGE_CODE,MUSTERI_NO,YIL,AY,MASRAF_TUTARI,MASRAF_DOVIZ,TOPLAM_TAHSIL_TUTAR,
							  TAHSIL_EDILEMEYEN,BOLUM_KODU,CUSTOMER_TYPE)
							values
							('ACCMAINFEE',r_musteri.MUSTERI_NO,ln_yil,ln_ay,ln_amnt,ls_cy,ln_toplam_tahsil,
							 ln_kalan_tahsilat,r_musteri.BOLUM_KODU,pkg_tx7047.musteri_tipi_ind_corp(r_musteri.musteri_no));
						end if;

						IF ln_counter>0 THEN
							Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
							Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'2604'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_counter)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
							Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5121'||Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
						END IF;
					end if; --if ls_uygun = 'E' and ls_dk is not null
				end if;
			COMMIT;
		END LOOP;
		CLOSE c_musteri;
--	end if; -- End Of Month
	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

	EXCEPTION
		when double_run_1 then
			ROLLBACK;
			Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5123'||
													            Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
													            Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
													            Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
													            Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
																Pkg_Hata.GetUCPOINTER,ln_islem_no);

		  	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
		when double_run_2 then
			ROLLBACK;
			Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5122'||
													            Pkg_Hata.GetDelimiter||'ACCMAINFEE'||
													            Pkg_Hata.GetDelimiter||TO_CHAR(r_musteri.MUSTERI_NO)||
													            Pkg_Hata.GetDelimiter||TO_CHAR(ln_yil)||
													            Pkg_Hata.GetDelimiter||TO_CHAR(ln_ay)||
																Pkg_Hata.GetUCPOINTER,ln_islem_no);
		  	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
		when birden_fazla_parametre_var then
			ROLLBACK;
			Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5125'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
		  	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
		when dk_yok then
			ROLLBACK;
			Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5128'||Pkg_Hata.GetUCPOINTER,ln_islem_no);
		  	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
		WHEN OTHERS THEN
			ROLLBACK;
			Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'5124'||
			Pkg_Hata.GetDelimiter||SQLERRM||Pkg_Hata.GetUCPOINTER);
		  	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
-----------------------------------------------------------------------------------
END;
/

