create PACKAGE BODY     Pkg_Int_Card IS

SOURCE_PATH		  VARCHAR2(100);
DESTINATION_PATH  VARCHAR2(100);
---------------------------------------------------------------------------------------
FUNCTION GetCustomerCards(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ls_account_count NUMBER := 0;
 	noCardFound   EXCEPTION;
	ln_count NUMBER;
BEGIN

	SELECT COUNT(*)
	INTO ln_count
	FROM CBS_CARD_INFO
	WHERE CUSTOMER_NO=TO_NUMBER(pn_musteri_no)
	AND status_code='sVALID';

	IF ln_count=0 THEN
	   RAISE noCardFound;
	END IF;

  OPEN pc_ref FOR
  	   SELECT CARD_NO, CUSTOMER_NO, Pkg_Musteri.Sf_Musteri_Adi( CUSTOMER_NO), ACCOUNT_NO, STATUS_CODE
	   FROM CBS_CARD_INFO
	   WHERE CUSTOMER_NO=TO_NUMBER(pn_musteri_no)
	   AND status_code='sVALID';

  RETURN ls_returncode;

EXCEPTION
	WHEN noCardFound THEN
  	 OPEN pc_ref FOR SELECT '-' FROM dual;
	 ls_returncode:= '509';
	 RETURN ls_returncode;

	 	--OPEN pc_ref FOR
		--select 'NO' from dual;
	  --return '250';
END;

---------------------------------------------------------------------------------------
FUNCTION GetCardPaymentInfo(pn_musteri_no IN VARCHAR2,pd_start_date IN VARCHAR2,pd_end_date IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ls_account_count NUMBER := 0;
	ld_startdate  DATE;
  	ld_enddate	  DATE;

  not_valid_date EXCEPTION;
  PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- yanl?? zaman girilmesi durumunda

BEGIN
    -- burada e?er hatal? tarih girilmi? ise kullan?c?y? uyarmal?y?m o y?zden
	-- verecek ise burada hata versin diyorum

	ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
	ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');

--log_at('CARD',pn_musteri_no);

  OPEN pc_ref FOR
  	   SELECT TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO,
	   		  FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_CARD_NO, BOLUM_KODU,
			  PAYMENT_DESCRIPTION, AMOUNT, CURRENCY_CODE, TO_CARD_CUSTOMER_NO, TO_CARD_CUSTOMER_NAME,
			  TO_CHAR(PAYMENT_DATE,'YYYYMMDD'), STATUS_CD, PAYMENT_TYPE_DESC, DETAIL_ID, PAYMENT_FILE, CHARGE_AMOUNT, CHARGE_ACCOUNT
	   FROM CBS_CARD_PAYMENT
	   WHERE FROM_CUSTOMER_NO=TO_NUMBER(pn_musteri_no)
	   AND PAYMENT_DATE>=TO_DATE(pd_start_date,'YYYYMMDD')
	   AND PAYMENT_DATE<=TO_DATE(pd_end_date,'YYYYMMDD');
	   --and STATUS_CD='sVALID';

  RETURN ls_returncode;


EXCEPTION
	WHEN NO_DATA_FOUND THEN
	 	OPEN pc_ref FOR
		SELECT 'NO' FROM dual;
	  RETURN '250';
END;
-----------------------------------------------------------------------------------------
FUNCTION CardControl(pn_card_no IN VARCHAR2,
		 			 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ls_account_count NUMBER := 0;
 	noCardFound   EXCEPTION;
	ln_count NUMBER;
BEGIN

	SELECT COUNT(*)
	INTO ln_count
	FROM CBS_CARD_INFO
	WHERE CARD_NO=pn_card_no
	AND status_code='sVALID';

	IF ln_count=0 THEN
	   RAISE noCardFound;
	END IF;

	Log_At('test',pn_card_no,ln_count);
  OPEN pc_ref FOR
  	   SELECT CARD_NO, CUSTOMER_NO, Pkg_Musteri.Sf_Musteri_Adi( CUSTOMER_NO), ACCOUNT_NO, STATUS_CODE
	   FROM CBS_CARD_INFO
	   WHERE CARD_NO=pn_card_no
	   AND status_code='sVALID';

  RETURN ls_returncode;

EXCEPTION
	WHEN noCardFound THEN
  	 OPEN pc_ref FOR SELECT '-' FROM dual;
	 ls_returncode:= '509';
	 RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------
/*******************************************************************************
    Name        : FUNCTION updateCardStatus
    Prepared By : Temirlan Talapkerov
    Date:       : 03.03.2022
    Base Project: MB-236 debit card block/unblock
*******************************************************************************/
FUNCTION updateCardStatus(ps_pseudopan in varchar2,
                          ps_debit_card_status in varchar2,
                          ps_account_number in varchar2 default '0',
                          ps_transaction_type in varchar2 default 'status') return varchar2
is
     ln_islem_kod number := 2304;
     ln_islem_no number;
     ln_skip_add number;
     ls_branch_code CBS_MUSTERI.BOLUM_KODU%TYPE;
     ls_modul_tur_kod CBS_ISLEM.MODUL_TUR_KOD%TYPE := 'CUSTOMER';
     ls_urun_tur_kod CBS_ISLEM.URUN_TUR_KOD%TYPE := 'GENERAL';
     ls_urun_sinif_kod CBS_ISLEM.URUN_SINIF_KOD%TYPE := 'GENERAL';

     ls_card_no CBS_DEBIT_CARD.CARD_NO%TYPE;
     ls_card_id_no CBS_DEBIT_CARD.CARD_ID_NO%TYPE;
     ls_customer_no CBS_DEBIT_CARD.CUSTOMER_NO%TYPE;
     ls_status CBS_DEBIT_CARD.STATUS%TYPE;
     ls_emboss_name_eng CBS_DEBIT_CARD.EMBOSS_NAME_ENG%TYPE;
     ls_emboss_second_name_eng CBS_DEBIT_CARD.EMBOSS_SECOND_NAME_ENG%TYPE;
     ls_emboss_surname_eng CBS_DEBIT_CARD.EMBOSS_SURNAME_ENG%TYPE;
     ls_card_style CBS_DEBIT_CARD.CARD_STYLE%TYPE;
     ls_debit_card_option CBS_DEBIT_CARD_MAIN_TRAN.DEBIT_CARD_OPTION%TYPE;
     ls_card_account_type CBS_DEBIT_CARD_ACCOUNT.CARD_ACCOUNT_TYPE%TYPE;
     ls_account_no CBS_DEBIT_CARD_ACCOUNT.ACCOUNT_NO%TYPE;
     ls_currency_code CBS_DEBIT_CARD_ACCOUNT_TRAN.CURRENCY_CODE%TYPE;
     ls_acct_branch_code CBS_DEBIT_CARD_ACCOUNT_TRAN.ACCT_BRANCH_CODE%TYPE;
     ls_acct_product_type CBS_DEBIT_CARD_ACCOUNT_TRAN.ACCT_PRODUCT_TYPE%TYPE;
     ls_acct_product_class CBS_DEBIT_CARD_ACCOUNT_TRAN.ACCT_PRODUCT_CLASS%TYPE;
     ls_acct_status_code CBS_DEBIT_CARD_ACCOUNT_TRAN.ACCT_STATUS_CODE%TYPE;
     ls_rol CBS_ERISIM_ROL.ROL_NUMARA%TYPE;

    CURSOR c_debit IS
        select * from cbs_debit_card_account
        where CARD_ID_NO = ps_pseudopan;
    r_debit  c_debit%ROWTYPE;

     ln_card_count NUMBER;
     ln_primary_account_count NUMBER;
     ln_account_count NUMBER;
     noCardFound   EXCEPTION;
     noPrimaryAccountFound   EXCEPTION;
     primaryAccountCannotBeUnlinked   EXCEPTION;
     noAccountFound   EXCEPTION;
     accountAlreadyLinked EXCEPTION;
begin
    ln_islem_no := CBS.pkg_tx.islem_no_al;
    ls_rol := 7777;

    select count(*) into ln_card_count from cbs_debit_card
    where card_id_no = ps_pseudopan and status = 'A';

    if ln_card_count != 1 then
	   raise noCardFound;
	end if;

    select card_no, card_id_no, customer_no, status, emboss_name_eng, emboss_second_name_eng, emboss_surname_eng, card_style
    into ls_card_no, ls_card_id_no, ls_customer_no, ls_status, ls_emboss_name_eng, ls_emboss_second_name_eng, ls_emboss_surname_eng, ls_card_style
    from cbs_debit_card
    where card_id_no = ps_pseudopan and status = 'A';

    select BOLUM_KODU into ls_branch_code from CBS_MUSTERI where MUSTERI_NO = ls_customer_no;

    if ls_customer_no is not null then
        Pkg_Tx2304.Sf_Onay_Bekleyen_Varmi(ls_customer_no,ln_islem_no ,ln_islem_kod);
    end if;

  IF ps_transaction_type = 'status' THEN
  	 IF ps_debit_card_status = 'N' THEN
        ls_debit_card_option := 'CARD ACTIVATION';
    ELSIF ps_debit_card_status = 'G' THEN
        ls_debit_card_option := 'BLOCKING CARD';
    END IF;
  ELSIF ps_transaction_type = 'primary' OR ps_transaction_type = 'link' OR ps_transaction_type = 'unlink' THEN 
  	 ls_debit_card_option := 'EXISTING CARD';
  END IF;

    insert into CBS_DEBIT_CARD_MAIN_TRAN (TX_NO,
                                          CUSTOMER_NO,
                                          CARD_NO,
                                          CARD_ID_NO,
                                          DEBIT_CARD_OPTION,
                                          EMBOSS_NAME_ENG,
                                          EMBOSS_SECOND_NAME_ENG,
                                          EMBOSS_SURNAME_ENG,
                                          TX_BRANCH_CODE,
                                          CREATED_DATE,
                                          CREATED_BY,
                                          TRAN_CODE,
                                          CARD_STYLE)
                                  values (ln_islem_no,
                                          ls_customer_no,
                                          ls_card_no,
                                          ls_card_id_no,
                                          ls_debit_card_option,
                                          ls_emboss_name_eng,
                                          ls_emboss_second_name_eng,
                                          ls_emboss_surname_eng,
                                          ls_branch_code,
                                          SYSDATE,
                                          'CINT_CALLER',
                                          ln_islem_kod,
                                          ls_card_style);

    select count(*) into ln_primary_account_count from cbs_debit_card_account
    where CARD_ID_NO = ps_pseudopan;
    if ln_primary_account_count = 0 and  ps_transaction_type='link' and  ps_debit_card_status!='P'  then
	   raise noPrimaryAccountFound;
	end if; 
    OPEN c_debit;
    LOOP
        FETCH c_debit INTO r_debit;
        EXIT WHEN c_debit%NOTFOUND;
        ln_skip_add :=0;
        IF ps_transaction_type ='unlink' and ps_account_number=r_debit.ACCOUNT_NO and   r_debit.CARD_ACCOUNT_TYPE='PRIMARY' THEN
	      raise primaryAccountCannotBeUnlinked;
        END IF;
        IF ps_transaction_type ='unlink' and ps_account_number=r_debit.ACCOUNT_NO THEN
          --do not add unlinked account to account tran table
          ln_skip_add :=1;
        END IF;
        IF ln_skip_add=0 THEN
            if ps_transaction_type = 'primary' then
                if r_debit.ACCOUNT_NO = ps_account_number then
                    ls_card_account_type := 'PRIMARY';
                else
                    ls_card_account_type := 'SECONDARY';
                end if;
            else
                ls_card_account_type := r_debit.CARD_ACCOUNT_TYPE;
            end if;
            IF ps_transaction_type='link'  and ps_account_number=r_debit.ACCOUNT_NO THEN
                 raise  accountAlreadyLinked;
            END IF;
            IF  ps_transaction_type='link' and ps_debit_card_status='P' and ls_card_account_type='PRIMARY' THEN
                --new linked account will be primary
                ls_card_account_type := 'SECONDARY'; 
            END IF;
            ls_account_no := r_debit.ACCOUNT_NO;
       
            select count(*) into ln_account_count from cbs_hesap
            where hesap_no = ls_account_no;
            if ln_account_count != 1 then
                raise noAccountFound;
            end if;
    
            select urun_tur_kod, urun_sinif_kod, durum_kodu
            into ls_acct_product_type, ls_acct_product_class, ls_acct_status_code
            from cbs_hesap
            where hesap_no = ls_account_no;
    
            ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ls_account_no);
            ls_acct_branch_code := PKG_HESAP.HESAPTANSUBEAL(ls_account_no);
          
            insert into CBS_DEBIT_CARD_ACCOUNT_TRAN(TX_NO,
                                                CUSTOMER_NO,
                                                CARD_NO,
                                                CARD_ID_NO,
                                                CARD_ACCOUNT_TYPE,
                                                ACCOUNT_NO,
                                                CURRENCY_CODE,
                                                ACCT_BRANCH_CODE,
                                                ACCT_PRODUCT_TYPE,
                                                ACCT_PRODUCT_CLASS,
                                                ACCT_STATUS_CODE,
                                                CREATED_DATE,
                                                CREATED_BY,
                                                CREATOR_TXNO)
                                        values (ln_islem_no,
                                                ls_customer_no,
                                                ls_card_no,
                                                ls_card_id_no,
                                                ls_card_account_type,
                                                ls_account_no,
                                                ls_currency_code,
                                                ls_acct_branch_code,
                                                ls_acct_product_type,
                                                ls_acct_product_class,
                                                ls_acct_status_code,
                                                SYSDATE,
                                                'CINT_CALLER',
                                                null);
          END IF;
        
    END LOOP;
    CLOSE c_debit; 
    if ps_transaction_type = 'link'   then 
        IF ps_debit_card_status ='P' THEN
            ls_card_account_type := 'PRIMARY';
        ELSE
            ls_card_account_type := 'SECONDARY';
        END IF;

        select count(*) into ln_account_count from cbs_hesap
        where hesap_no = ps_account_number;
        if ln_account_count != 1 then
	        raise noAccountFound;
	    end if;
        ls_account_no := ps_account_number;

        select urun_tur_kod, urun_sinif_kod, durum_kodu
        into ls_acct_product_type, ls_acct_product_class, ls_acct_status_code
        from cbs_hesap
        where hesap_no = ls_account_no;

        ls_currency_code := PKG_HESAP.HESAPTANDOVIZKODUAL(ls_account_no);
        ls_acct_branch_code := PKG_HESAP.HESAPTANSUBEAL(ls_account_no);

        insert into CBS_DEBIT_CARD_ACCOUNT_TRAN(TX_NO,
                                            CUSTOMER_NO,
                                            CARD_NO,
                                            CARD_ID_NO,
                                            CARD_ACCOUNT_TYPE,
                                            ACCOUNT_NO,
                                            CURRENCY_CODE,
                                            ACCT_BRANCH_CODE,
                                            ACCT_PRODUCT_TYPE,
                                            ACCT_PRODUCT_CLASS,
                                            ACCT_STATUS_CODE,
                                            CREATED_DATE,
                                            CREATED_BY,
                                            CREATOR_TXNO)
                                    values (ln_islem_no,
                                            ls_customer_no,
                                            ls_card_no,
                                            ls_card_id_no,
                                            ls_card_account_type,
                                            ls_account_no,
                                            ls_currency_code,
                                            ls_acct_branch_code,
                                            ls_acct_product_type,
                                            ls_acct_product_class,
                                            ls_acct_status_code,
                                            SYSDATE,
                                            'CINT_CALLER',
                                            null);

    end if;

    CBS.PKG_BAGLAM.YARAT(ls_branch_code, '7777');
    pkg_int_api.create_transaction (ln_islem_no,
                                    ln_islem_kod,
                                    ls_modul_tur_kod,
                                     ls_urun_tur_kod,
                                      ls_urun_sinif_kod,
                                      0,
                                      ls_acct_branch_code,
                                      ls_acct_branch_code,
                                      ls_rol,
                                    ls_currency_code,
                                      ls_customer_no,
                                      ls_account_no,
                                      null);
    ls_branch_code := PKG_BAGLAM.BOLUM_KODU;
    
      pkg_int_api.process_transaction (ln_islem_no);
    return '000';
exception
    when noCardFound then
	    return '507';
    when noPrimaryAccountFound then
	    return '508'; 
    when noAccountFound then
	    return '509';
    when primaryAccountCannotBeUnlinked then
	    return '510';
    when accountAlreadyLinked then
	    return '511';
    when others then
        RAISE;
end;
------------------------------------------------------------------------------------------------------------
/*******************************************************************************
    Name        : FUNCTION getDebitCardAccounts
    Prepared By : Temirlan Talapkerov
    Date:       : 28.06.2022
    Base Project: MB-289 Link account to debit cards/change account type
*******************************************************************************/
FUNCTION getDebitCardAccounts(ps_pseudopan in varchar2,
                              ps_customer_number in varchar2,
                              pc_ref OUT CursorReferenceType) return varchar2
    is
begin
    
    OPEN pc_ref FOR
        SELECT  Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                MUSTERI_NO,
                ISIM_UNVAN,
                ACILIS_TARIHI,
                sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                HESAP_NO,
                DOVIZ_KODU,
               (select CARD_ACCOUNT_TYPE from CBS_DEBIT_CARD_ACCOUNT where ACCOUNT_NO = HESAP_NO and CARD_ID_NO = ps_pseudopan) account_type,
                NVL(BAKIYE,0) balance,
                NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) available_balance,
                1 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2),
                EXTERNAL_HESAP_NO,
                URUN_SINIF_KOD
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no = TO_NUMBER(ps_customer_number) AND durum_kodu = 'A' AND modul_tur_kod= 'CURRENT'
          AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND URUN_SINIF_KOD not in ('ELCARD NON INT.BR-LC', 'OVERBALANCE-LC')--added FilippK 'OVERBALANCE-LC' 14.09.2022
          AND HESAP_NO IN (SELECT ACCOUNT_NO FROM CBS_DEBIT_CARD_ACCOUNT WHERE CARD_ID_NO = ps_pseudopan)
        ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu ;
    return '000';
EXCEPTION 
    WHEN OTHERS  THEN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        return '999';
end;
------------------------------------------------------------------------------------------------------------
/*******************************************************************************
    Name        : FUNCTION getNonDebitCardAccounts
    Prepared By : Temirlan Talapkerov
    Date:       : 28.06.2022
    Base Project: MB-289 Link account to debit cards/change account type
*******************************************************************************/
FUNCTION getNonDebitCardAccounts(ps_pseudopan in varchar2,
                                 ps_customer_number in varchar2,
                                 pc_ref OUT CursorReferenceType) return varchar2
is

begin
    OPEN pc_ref FOR
        SELECT  Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                MUSTERI_NO,
                ISIM_UNVAN,
                ACILIS_TARIHI,
                sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                HESAP_NO,
                DOVIZ_KODU,
                NVL(BAKIYE,0),
                NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0),
                1 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2),
                EXTERNAL_HESAP_NO,
                URUN_SINIF_KOD
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no = TO_NUMBER(ps_customer_number) AND durum_kodu = 'A' AND modul_tur_kod= 'CURRENT' AND DOVIZ_KODU in ('KGS', 'USD', 'EUR')
          AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND URUN_SINIF_KOD not in ('ELCARD NON INT.BR-LC', 'OVERBALANCE-LC')--added FilippK 'OVERBALANCE-LC' 14.09.2022
          AND HESAP_NO NOT IN (SELECT ACCOUNT_NO FROM CBS_DEBIT_CARD_ACCOUNT WHERE CARD_ID_NO = ps_pseudopan)
        ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu;
    return '000';
end;

------------------------------------------------------------------------------------------------------------
/*******************************************************************************
    Name        : FUNCTION getDebitCardAutoconversion
    Prepared By : Temirlan Talapkerov
    Date:       : 03.08.2022
    Base Project: MB-289 Change Debit Card Autoconversion Status
*******************************************************************************/
FUNCTION getDebitCardAutoconversion(ps_pseudopan in varchar2,
                                    ps_autoconversion in varchar2,
                                    ps_customer_number in varchar2) return varchar2
is
    ls_debit_card_accounts NUMBER;
    noAccountFound EXCEPTION;
    noMoreAccounts EXCEPTION;
    ln_tran_no number;
    ln_tran_code number;
    ls_module_type_code varchar2(10);
    ls_customer_type varchar2(1 byte);
    ls_product_type_code varchar2(10);
    ls_product_class_code varchar2(20);
    ls_tran_branch_code varchar2(3);
    ls_branch_code varchar(10);
    ln_role number := 7777;
    ln_currency_code varchar2(3) := pkg_genel.lc_al;
    ls_account_number varchar(20 byte);
    ls_cash_code varchar2(10 byte);
    ls_returncode varchar2(3):='000';
    ps_channel_code number := 1;
    ps_user_code varchar2(20) := 'CINT_CALLER';
    ls_status varchar2(3 byte);
        
begin
    ln_tran_code:=1001;
    ls_module_type_code := 'CUSTOMER';
    ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ps_customer_number);
    ls_product_type_code := pkg_musteri.sf_musteri_urun_tur_al (ls_customer_type);
    ls_product_class_code := pkg_musteri.sf_musteri_urun_sinif_al (ls_module_type_code,
                                               ls_product_type_code);
    ls_tran_branch_code := pkg_musteri.sf_bolum_kodu_al(ps_customer_number);    
    ls_branch_code := pkg_musteri.sf_bolum_kodu_al(ps_customer_number);        
    
    select count(*) into ls_debit_card_accounts from CBS_DEBIT_CARD_ACCOUNT where CARD_ID_NO = ps_pseudopan;
    if ls_debit_card_accounts = 0 then
        raise noAccountFound;
    elsif ls_debit_card_accounts = 1 then
        raise noMoreAccounts;
    end if;
    
    pkg_baglam.yarat(ls_branch_code, ln_role);
    
    ls_status := pkg_musteri.sf_musteri_kodu_al(ps_customer_number);
    
    if ls_status = 'A' then
    pkg_musteri.sp_musteri_guncel_kaydi_olus (ps_customer_number, 
                                                ln_tran_no, 
                                                ls_status);                                                  
    else
        raise noAccountFound;
    end if;

    update cbs_musteri_guncellenen set fx_convert = nvl(ps_autoconversion, fx_convert)--Bakdoolot
            where tx_no = ln_tran_no;
       
      pkg_int_api.create_transaction (ln_tran_no, ln_tran_code,
                                   ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   0, ls_tran_branch_code, ls_branch_code, ln_role,
                                   ln_currency_code, ps_customer_number, ls_account_number,
                                   ls_cash_code, to_number(ps_channel_code), ps_user_code);

      pkg_int_api.process_transaction (ln_tran_no);

   commit;
         
  return ls_returncode;

exception
    when noAccountFound then
        return '606';
    when noMoreAccounts then
        return '608';
    when others then
        return '999';
end;

------------------------------------------------------------------------------------------------------------
/*******************************************************************************
    Name        : FUNCTION getDebitCardAutoconversionStatus
    Prepared By : Temirlan Talapkerov
    Date:       : 30.06.2022
    Base Project: MB-289 Debit Card Autoconversion Status
*******************************************************************************/
FUNCTION getDebitCardAutoconversionStatus(ps_customer_number in varchar2,
                                          pc_ref OUT CursorReferenceType) return varchar2
is
    ls_customer_count NUMBER;
    noCustomerFound EXCEPTION;
begin
    select count(*) into ls_customer_count from CBS_MUSTERI where MUSTERI_NO = ps_customer_number;
    if ls_customer_count != 1 then
        raise noCustomerFound;
    end if;
    open pc_ref for
        select FX_CONVERT from CBS_MUSTERI where MUSTERI_NO = ps_customer_number;
    
    return '000';
EXCEPTION 
    WHEN noCustomerFound THEN
        return '608';
    WHEN OTHERS THEN   
        RAISE;
end;
    
END;
/

