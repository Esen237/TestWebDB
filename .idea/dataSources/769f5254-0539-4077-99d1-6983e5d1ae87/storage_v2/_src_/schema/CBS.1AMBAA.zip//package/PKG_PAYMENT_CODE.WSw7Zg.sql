create PACKAGE PKG_PAYMENT_CODE
IS
/******************************************************************************
Name       : PKG_PAYMENT_CODE
Created By : Nursultan Sabitakun uulu
Purpose    : Update payment codes
******************************************************************************/
    type row_rt is record (
        kod varchar2(10),
        description_ru varchar2(500),
        description_en varchar2(500),
        type varchar2(10)
    );
    type rows_t is table of row_rt index by binary_integer;

    type config_rt is record (
        tran_code cbs_payment_code_group.tran_code%TYPE,
        channel_code cbs_payment_code_group.channel_code%TYPE
    );
    type configs_t is table of config_rt index by binary_integer;

    type payment_code_t is table of cbs_payment_code%ROWTYPE index by binary_integer;
    type payment_code_group_t is table of cbs_payment_code_group%ROWTYPE index by binary_integer;
    
    row_array rows_t;
    payment_code_array payment_code_t;
    payment_code_group_array payment_code_group_t;

    Procedure Prepare_Id (pn_id_out out number);    
    FUNCTION Load_Data (pn_blob_id NUMBER, ps_mode varchar2, ps_delimiter varchar2 default ';') RETURN BOOLEAN;
    Procedure Parse(ps_line in varchar2, pn_num binary_integer, ps_mode in varchar2, ps_delimiter in varchar2 default ';');    

    function update_cbs_payment_codes return boolean;
    function update_ib_payment_codes return boolean;
    function repair_data(ps_source varchar2) return boolean;

    function is_group(pn_index in binary_integer) return boolean;
    function degree(ps_kod varchar2) return number;
    function get_next_kod(pn_index in binary_integer) return varchar2;
    function get_prev_kod(pn_index in binary_integer) return varchar2;
    function get_parent_group_kod(pn_index in binary_integer) return varchar2;

    procedure add_group(pn_parent_kod in varchar2, pn_index in binary_integer, p_config config_rt);
    procedure add_child(ps_group_kod in varchar2, ps_kod in varchar2, p_config config_rt);

    procedure config_groups;
    function get_configs(pn_index in binary_integer) return configs_t;

    PROCEDURE Clear_Temp_Data (pn_id IN NUMBER);
END;
/

