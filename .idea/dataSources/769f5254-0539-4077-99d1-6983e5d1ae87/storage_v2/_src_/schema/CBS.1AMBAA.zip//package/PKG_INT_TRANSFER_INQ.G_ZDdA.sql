create PACKAGE     PKG_INT_TRANSFER_INQ IS 

TYPE CursorReferenceType IS REF CURSOR;  


FUNCTION GetDateByChannelCode(ps_channel_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2; 

FUNCTION GetNextBusinessDate(ps_channel_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2; 

FUNCTION GetPreviousBusinessDate(ps_channel_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;  

FUNCTION GetPaymentDestCode(ps_lang varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;        
                          
FUNCTION GetPurposeCodes(ps_lang varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2; 
                           
FUNCTION GetPaymentCodes(ps_lang varchar2,
                         ps_customer_type varchar2,
                         ps_transfer_type varchar2, 
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2;                                                    

FUNCTION GetClearingBicCodes(ps_lang varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;
                           
FUNCTION GetSwiftCountries(ps_lang varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;    

FUNCTION GetSwiftBicCodes(ps_lang varchar2, 
                         ps_country_code varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;    
                                                                        
FUNCTION GetBankInfoBySwiftCode(ps_swift_code varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;
                                                        
FUNCTION GetTransferIsFirst(ps_source_iban varchar2, 
                         ps_target_iban varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;    
                                                  
FUNCTION GetIbanToAccount(ps_lang varchar2,  
                         ps_iban varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;
                                                                              
FUNCTION GetAccountToIban(ps_lang varchar2, 
                         ps_account_number varchar2,   
                         pc_ref OUT CursorReferenceType) RETURN varchar2;                          

FUNCTION GetRecentTransfers(ps_lang varchar2, 
                         ps_customer_id varchar2,
                         ps_transfer_type varchar2,
                         pn_page_index number,
                         pn_page_size number, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetFrequentTransfers(ps_lang varchar2, 
                         ps_customer_id varchar2,
                         pn_page_index number,
                         pn_page_size number, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;         
                           
FUNCTION GetFrequentTransfersByAccount(ps_lang varchar2, 
                         ps_customer_id varchar2,
                         ps_target_iban varchar2,
                         ps_transfer_type varchar2,
                         pn_page_index number,
                         pn_page_size number,
                         ps_from_date varchar2, 
                         ps_to_date varchar2, 
                         pc_ref OUT CursorReferenceType) RETURN varchar2;                                             

FUNCTION GetSwiftCommission(ps_source_iban varchar2,
                         ps_amount varchar2,
                         ps_commission_type varchar2,
                         ps_execution_type varchar2,
                         ps_swift_code varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;
                       
FUNCTION GetOwnAccountTransfer(ps_lang varchar2,
                         ps_source_iban varchar2, 
                         ps_target_iban varchar2, 
                         ps_amount varchar2,
                         ps_description varchar2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2; 
                               
FUNCTION GetAnotherAccountTransfer(ps_lang varchar2,
                         ps_source_iban varchar2, 
                         ps_target_iban varchar2, 
                         ps_amount varchar2,
                         ps_description varchar2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2;                                                       

FUNCTION GetClearingTransfer(ps_lang varchar2,
                         ps_source_iban varchar2,
                         ps_target_full_name varchar2,
                         ps_target_iban varchar2,
                         ps_bic_code varchar2,
                         ps_payment_code varchar2,
                         ps_amount varchar2,
                         ps_description varchar2,
                         ps_transfer_type varchar2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2;

FUNCTION GetSwiftTransfer(ps_lang varchar2, 
                         ps_source_iban varchar2,
                         ps_currency_code varchar2,
                         ps_country_code varchar2,
                         ps_swift_code varchar2,
                         ps_amount varchar2,       
                         ps_commission_type varchar2, 
                         ps_execution_type varchar2, 
                         ps_target_iban varchar2,
                         ps_target_bank_city_name varchar2,     
                         ps_target_full_name varchar2,  
                         ps_target_address varchar2, 
                         ps_target_phone_number varchar2,  
                         ps_target_passport varchar2,  
                         ps_payment_dest_code varchar2,                   
                         ps_purpose_code varchar2,
                         ps_payment_code varchar2,
                         ps_payment_details varchar2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType) RETURN varchar2;
                          
FUNCTION CheckClearingIban(ps_target_iban varchar2,
                         pc_ref OUT CursorReferenceType) RETURN varchar2;   
                         
FUNCTION GetPaymentCodeDesc(ps_lang varchar2, 
                         ps_kod varchar2) RETURN varchar2;
                                                                                          
END PKG_INT_TRANSFER_INQ;
/

