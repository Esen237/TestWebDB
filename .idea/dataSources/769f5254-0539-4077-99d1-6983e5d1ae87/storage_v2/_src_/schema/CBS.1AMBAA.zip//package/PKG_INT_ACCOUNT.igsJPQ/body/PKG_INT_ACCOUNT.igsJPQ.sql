create PACKAGE BODY     Pkg_Int_Account IS


------------------------------------------------------------------------------------------------
FUNCTION GetTxDate (pn_islem_no IN NUMBER) RETURN DATE IS
  ln_date DATE;
BEGIN
  SELECT TAMAMLANMA_TARIHI
  INTO ln_date
  FROM CBS_ISLEM
  WHERE numara=pn_islem_no;

  RETURN ln_date;
END;
----------------------------------------------------------------------------------------------------
FUNCTION GetCustomerInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode VARCHAR2(3):='000';
 ln_musterino  NUMBER;
BEGIN
  OPEN pc_ref FOR
  SELECT Pkg_Musteri.Sf_Musteri_Adi(pn_musteri_no),
         TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'), m.DOGUM_YERI,
         m.CINSIYET_KOD, m.MEDENI_HAL_KOD,m.VERGI_NO,m.VERGI_DAIRESI_ADI, m.UYRUK_KOD,u.ACIKLAMA, m.TC_KIMLIK_NO,
   a.ADRES, a.SEMT, a.IL_KOD,i.IL_ADI, a.POSTA_KOD, a.ULKE_KOD,b.ULKE_ADI, a.EMAIL, a.TEL_ALAN_KOD,
   a.TEL_NO, a.GSM_ALAN_KOD, a.GSM_NO, a.ADRES_KOD, m.MUSTERI_TIPI_KOD,NVL(TO_CHAR(m.DOGUM_TARIHI,'MMDD'),' '),NVL(TO_CHAR(SYSDATE,'MMDD'),' '),l.ACIKLAMA
   FROM CBS_MUSTERI m, CBS_MUSTERI_ADRES a , CBS_IL_KODLARI i, CBS_UYRUK_KODLARI u,  CBS_ULKE_KODLARI b,CBS_ADRES_KODLARI k,CBS_MESLEK_KODLARI l
   WHERE m.musteri_no = TO_NUMBER(pn_musteri_no) AND
         m.musteri_no = a.musteri_no AND
    m.EXTRE_ADRES_KOD = a.ADRES_KOD AND
         m.UYRUK_KOD  = u.UYRUK_KODU AND
         a.ULKE_KOD   = b.ULKE_KODU  AND
   a.il_kod     = i.il_kodu AND
   k.ADRES_TIPI = a.ADRES_KOD AND
   l.MESLEK_KODU(+)= m.MESLEK_KOD;

 SELECT   pn_musteri_no
 INTO ln_musterino
 FROM CBS_MUSTERI m, CBS_MUSTERI_ADRES a , CBS_IL_KODLARI i, CBS_UYRUK_KODLARI u,  CBS_ULKE_KODLARI b
 WHERE m.musteri_no = TO_NUMBER(pn_musteri_no) AND
 m.musteri_no = a.musteri_no AND
 m.UYRUK_KOD  = u.UYRUK_KODU AND
 a.ULKE_KOD   = b.ULKE_KODU   AND
 a.il_kod     = i.il_kodu;

  RETURN ls_returncode;
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      RETURN '025';
END;

/******************************************************************************
   NAME       : FUNCTION GetCustomerAccounts
   Created By : Seval Balci
   Date       : 17.06.04
   Purpose   :Customer Accounts Informations are returned
******************************************************************************/
FUNCTION GetCustomerAccounts(pn_musteri_no IN VARCHAR2,
		 					 pn_person_id  IN VARCHAR2,
							 pn_channel_cd IN VARCHAR2,
		 					 pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;

BEGIN
   log_at('ACCOUNTS04');
  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;
  -- hesap var m? yok mu?
  SELECT COUNT(*)
  INTO ls_account_count
  FROM
 (
  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,BIRIKMIS_FAIZ_NEG
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_no AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'CURRENT' AND
   urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
   AND URUN_SINIF_KOD not in ('ELCARD NON INT.BR-LC') --NurmilaZ
   UNION
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     2 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'TIME DEP.'
   UNION
   SELECT
       'Cash Credits' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     3 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
    FROM CBS_vw_hesap_izleme a
    WHERE
   musteri_no = pn_musteri_no AND
      durum_kodu = 'A' AND
   urun_tur_kod != 'LEASING' AND
   modul_tur_kod= 'LOAN'  AND
   Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E'
   UNION
   SELECT
       'Guarantee' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     5 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE
   musteri_no = pn_musteri_no AND
      durum_kodu = 'A' AND
   urun_tur_kod = 'L/G' AND
   modul_tur_kod= 'LOAN'
   )
   WHERE HESAP_NO NOT IN (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = pn_person_id);

  IF (ls_account_count= 0) THEN
  RAISE noAccoutFound;
  END IF;

  OPEN pc_ref FOR
  SELECT *
  FROM
 (
  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'CURRENT' AND
   urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
   AND URUN_SINIF_KOD not in ('ELCARD NON INT.BR-LC') --NurmilaZ
   UNION
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     2 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'TIME DEP.'
   UNION
   SELECT
       'Cash Credits' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     3 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
    FROM CBS_vw_hesap_izleme a
    WHERE
   musteri_no = pn_musteri_No AND
      durum_kodu = 'A' AND
   urun_tur_kod != 'LEASING' AND
   modul_tur_kod= 'LOAN'  AND
   Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E'
   UNION
   SELECT
       'Guarantee' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     5 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE
   musteri_no = pn_musteri_No AND
      durum_kodu = 'A' AND
   urun_tur_kod = 'L/G' AND
   modul_tur_kod= 'LOAN'
  UNION
  -------------------------------------------Related Accounts
  SELECT   'Related Current Accounts' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     6 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE IN ('sVIEW','sTRAN')
       ) AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'CURRENT' AND
   urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
   AND URUN_SINIF_KOD not in ('ELCARD NON INT.BR-LC') --NurmilaZ
   UNION
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     7 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE IN ('sVIEW','sTRAN')
       ) AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'TIME DEP.'
   UNION
   SELECT
       'Cash Credits' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     8 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
    FROM CBS_vw_hesap_izleme a
    WHERE
   hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE IN ('sVIEW','sTRAN')
       ) AND
      durum_kodu = 'A' AND
   urun_tur_kod != 'LEASING' AND
   modul_tur_kod= 'LOAN'  AND
   Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E'
   UNION
   SELECT
       'Guarantee' modul_tur_kod,
       MUSTERI_NO,
     ISIM_UNVAN,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
     HESAP_NO,
     DOVIZ_KODU,
     NVL(BAKIYE,0),
     NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
     9 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
   FROM CBS_vw_hesap_izleme a
   WHERE
   hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE IN ('sVIEW','sTRAN')
       ) AND
      durum_kodu = 'A' AND
   urun_tur_kod = 'L/G' AND
   modul_tur_kod= 'LOAN'
   )
   WHERE HESAP_NO NOT IN (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = pn_person_id)
   ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu ;

  RETURN ls_returncode;
  EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '503';
 RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------------

FUNCTION GetAccountTypeName(ps_modul_tur_kod VARCHAR2) RETURN VARCHAR2
IS
ls_modul VARCHAR2(50);
BEGIN
 SELECT DECODE( ps_modul_tur_kod,'KREDI','Kredi Hesaplar',
               'VADELI','Vadeli Hesaplar',
         'VADESIZ','Vadesiz Hesaplar')
 INTO ls_modul
 FROM dual;

  RETURN ls_modul;
END;

/******************************************************************************
   NAME       : GetCustomerAccountDetails
   Created By : Seval Balci
   Date       : 17.06.04
   Purpose   :Customer Account Detail Informations are returned
******************************************************************************/
FUNCTION GetCustomerAccountDetails(pn_account_no IN VARCHAR2,
              pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
  SELECT    hesap_no,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
   trim(doviz_kodu),
   kisa_isim,
   modul_tur_kod,
        urun_tur_kod,
   urun_sinif_kod,
       TO_CHAR(acilis_tarihi,'YYYYMMDD') acilis_tarihi,
   TO_CHAR(vade_tarihi,'YYYYMMDD') vade_tarihi,
      NVL(faiz_orani,0),
        NVL(bakiye,0),
        NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
   NVL(bloke_tutari,0) bloke_tutari,
--   DECODE(cek_karnesi,'E','Evet','Hay?r') cek_karnesi,
   cek_karnesi,
--    DECODE(ekstre_basim_kodu,'E','Evet','Hay?r') ekstre_basim_kodu,
    ekstre_basim_kodu,
    NVL(birikmis_faiz_poz,0) birikmis_faiz_poz,
   NVL(birikmis_faiz_neg,0) birikmis_faiz_neg,
   NVL(gecen_yil_faiz_toplami,0) gecen_yil_faiz_toplami,
   NVL(odenmis_faiz_toplami,0)   odenmis_faiz_toplami  ,
   Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod) siralama,
--   DECODE(vade_islem_bilgisi,1,'Kapama',2,'Ana Para Temdit',3,'Faizli Bakiye Temdit') vade_islem_bilgisi,
   vade_islem_bilgisi,
   otomatik_temdit,
--   NVL(TO_CHAR(period_sure),' ') || DECODE(NVL(period_cins,' '),'G','G?n','A','AY','Y','Y?l','AS','AySonu','YS','Y?lSonu') temdit_periodu,
   NVL(TO_CHAR(period_sure),' ') || NVL(period_cins,' ') temdit_periodu,
      (SELECT TO_CHAR(faiz_tahakkuk_tarihi,'YYYYMMDD') FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') faiz_tahakkuk_tarihi,
      (SELECT NVL(komisyon_orani,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') komisyon_orani,
      (SELECT NVL(birikmis_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') birikmis_komisyon_tutari,
      (SELECT NVL(tahsiledilen_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') tahsiledilen_komisyon_tutari,
      (SELECT NVL(gecenyil_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') gecenyil_komisyon_tutari,
   Pkg_Kredi.sf_endeks_doviz_kodu_al(hesap_no) end_dovz_kodu,
   (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_doviz_tutari,
      (SELECT referans FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_referans,
      (SELECT NVL(tutar,0) FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) tm_tutar,
      (SELECT TO_CHAR(verilis_tarihi,'YYYYMMDD') FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_verilis_tarihi,
      (SELECT muhatap FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_muhatap ,
   (SELECT referans FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) AKR_Referans,
   (SELECT NVL(dosya_tutari,0) FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) dosya_tutari,
   (SELECT urun_sinif FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) akreditifin_cinsi,
--   Pkg_Int.GetAccountType(Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod),urun_tur_kod,urun_sinif_kod) hesap_turu,
   (SELECT NVL(acilis_kuru ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_acilis_kuru,
   ISIM_UNVAN,
   EXTERNAL_HESAP_NO,
   Pkg_Musteri.Sf_Musteri_Adi(musteri_no) MUSTERI_ADI
   FROM     CBS_vw_hesap_izleme a
   WHERE    HESAP_NO = TO_NUMBER(pn_account_No);

  RETURN ls_returncode;
EXCEPTION WHEN OTHERS THEN
 Log_At(SQLERRM);
 END;
----------------------------------------------------------------------------------------------------------
FUNCTION GetCustomerExtAccountDetails(pn_extaccount_no IN VARCHAR2,ps_doviz IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS ls_returncode VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
  SELECT    hesap_no,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
   trim(doviz_kodu),
   kisa_isim,
   modul_tur_kod,
        urun_tur_kod,
   urun_sinif_kod,
       TO_CHAR(acilis_tarihi,'YYYYMMDD') acilis_tarihi,
   TO_CHAR(vade_tarihi,'YYYYMMDD') vade_tarihi,
      NVL(faiz_orani,0),
        NVL(bakiye,0),
        NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
   NVL(bloke_tutari,0) bloke_tutari,
--   DECODE(cek_karnesi,'E','Evet','Hay?r') cek_karnesi,
   cek_karnesi,
--    DECODE(ekstre_basim_kodu,'E','Evet','Hay?r') ekstre_basim_kodu,
    ekstre_basim_kodu,
    NVL(birikmis_faiz_poz,0) birikmis_faiz_poz,
   NVL(birikmis_faiz_neg,0) birikmis_faiz_neg,
   NVL(gecen_yil_faiz_toplami,0) gecen_yil_faiz_toplami,
   NVL(odenmis_faiz_toplami,0)   odenmis_faiz_toplami  ,
   Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod) siralama,
--   DECODE(vade_islem_bilgisi,1,'Kapama',2,'Ana Para Temdit',3,'Faizli Bakiye Temdit') vade_islem_bilgisi,
   vade_islem_bilgisi,
   otomatik_temdit,
--   NVL(TO_CHAR(period_sure),' ') || DECODE(NVL(period_cins,' '),'G','G?n','A','AY','Y','Y?l','AS','AySonu','YS','Y?lSonu') temdit_periodu,
   NVL(TO_CHAR(period_sure),' ') || NVL(period_cins,' ') temdit_periodu,
      (SELECT TO_CHAR(faiz_tahakkuk_tarihi,'YYYYMMDD') FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') faiz_tahakkuk_tarihi,
      (SELECT NVL(komisyon_orani,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') komisyon_orani,
      (SELECT NVL(birikmis_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') birikmis_komisyon_tutari,
      (SELECT NVL(tahsiledilen_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') tahsiledilen_komisyon_tutari,
      (SELECT NVL(gecenyil_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') gecenyil_komisyon_tutari,
   Pkg_Kredi.sf_endeks_doviz_kodu_al(hesap_no) end_dovz_kodu,
   (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_doviz_tutari,
      (SELECT referans FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_referans,
      (SELECT NVL(tutar,0) FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) tm_tutar,
      (SELECT TO_CHAR(verilis_tarihi,'YYYYMMDD') FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_verilis_tarihi,
      (SELECT muhatap FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_muhatap ,
   (SELECT referans FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) AKR_Referans,
   (SELECT NVL(dosya_tutari,0) FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) dosya_tutari,
   (SELECT urun_sinif FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) akreditifin_cinsi,
--   Pkg_Int.GetAccountType(Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod),urun_tur_kod,urun_sinif_kod) hesap_turu,
   (SELECT NVL(acilis_kuru ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_acilis_kuru,
   ISIM_UNVAN,
   EXTERNAL_HESAP_NO,
   Pkg_Musteri.Sf_Musteri_Adi(musteri_no) MUSTERI_ADI,
   Pkg_Hesap.GetIRSCode(a.DK_GRUP_KOD),
   Pkg_Hesap.GetSECOCode(a.DK_GRUP_KOD),
   MUSTERI_NO
   FROM     CBS_vw_hesap_izleme a
   WHERE    EXTERNAL_HESAP_NO = pn_extaccount_No
   AND  DOVIZ_KODU = ps_doviz;

  RETURN ls_returncode;
EXCEPTION WHEN OTHERS THEN
 Log_At(SQLERRM);
 END;

----------------------------------------------------------------
FUNCTION GetAccountHistory(pn_account_no IN VARCHAR2,
         pd_start_date IN VARCHAR2,
         pd_end_date   IN VARCHAR2,
            pd_islem_tur  IN VARCHAR2 DEFAULT '%',
         pd_hareket  IN VARCHAR2 DEFAULT '%',
            pd_alt_sinir     IN VARCHAR2,
         pd_ust_sinir     IN VARCHAR2,
         pd_lang     IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
  ls_returncode VARCHAR2(3):='000';
  ld_startdate  DATE;
  ld_enddate   DATE;


  not_valid_date EXCEPTION;
  PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- yanl?? zaman girilmesi durumunda

BEGIN
    -- burada e?er hatal? tarih girilmi? ise kullan?c?y? uyarmal?y?m o y?zden
 -- verecek ise burada hata versin diyorum

 ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
 ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');

  OPEN pc_ref FOR
 SELECT  TO_CHAR(a.fis_muhasebelestigi_tarih,'YYYYMMDD'),
   TO_CHAR(a.satir_valor_tarihi,'YYYYMMDD'),
   a.satir_musteri_aciklama,
   a.satir_dv_tutar,
   NVL(pkg_passbook.hareketlibakiyehesapla(a.satir_hesap_numara,a.fis_numara,a.satir_numara),0) son_bakiye,
   SATIR_DOVIZ_KOD,
   DECODE(i.KOD,'2102','Clearing','2000','Opening Current Account','4025','Buying Currency','1202','Selling Currency', i.ACIKLAMA),
   i.ACIKLAMA,
   k.NUMARA,
   k.ISLEM_KOD,
   pd_lang,
   Pkg_Report5.GetNBEquivalent(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEquivalent,
    Pkg_Musteri.Sf_Musteri_Adi(MUSTERI_NUMARA)
 FROM cbs_vw_fis_satir_vsziz a,CBS_ISLEM k, CBS_ISLEM_TANIM i
 WHERE  satir_hesap_numara = pn_account_no AND
     fis_muhasebelestigi_tarih BETWEEN TO_DATE(pd_start_date,'YYYYMMDD') AND TO_DATE(pd_end_date,'YYYYMMDD')
     AND fis_tur = 'G'
     AND k.numara=a.FIS_ISLEM_NUMARA
     AND i.kod=k.islem_kod
     AND a.SATIR_TUR LIKE pd_hareket
     --AND ABS(a.SATIR_DV_TUTAR) >= TO_NUMBER(REPLACE(REPLACE(pd_alt_sinir,',',''),'.',','))
     --AND ABS(a.SATIR_DV_TUTAR) <= TO_NUMBER(REPLACE(REPLACE(pd_ust_sinir,',',''),'.',','))
   ORDER BY a.FIS_NUMARA, a.SATIR_NUMARA;


  RETURN ls_returncode;

 EXCEPTION
   WHEN not_valid_date THEN
   ls_returncode:='414';
 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
 RETURN ls_returncode;

    WHEN OTHERS THEN
 ls_returncode:='999';
 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
 RETURN ls_returncode;

END;

FUNCTION GetAccountSort(ps_modul IN VARCHAR2,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN NUMBER IS
 ln_returncode NUMBER ;
BEGIN

  IF ps_modul = 'VADESIZ' THEN
    ln_returncode := 1;
  ELSIF ps_modul = 'VADELI' THEN
  ln_returncode := 2;
  ELSIF ps_modul = 'KREDI' THEN
    IF  ps_urun = 'TEM.MEKTUP'  OR ps_urun = 'VER.GARAN' THEN
     ln_returncode := 5;
    ELSIF  ps_urun = 'ITH.AKR' OR  ps_urun = 'KABULKRED' OR ps_urun = 'AKREDITIF' THEN
     ln_returncode := 6;
    ELSIF  ps_urun = 'LEASING' THEN
     ln_returncode := 7;
  ELSIF ps_urun != 'LEASING' AND Pkg_Genel.urun_sinif_nakdimi(ps_modul,ps_urun,ps_sinif) ='E' AND
      Pkg_Kredi.sf_dovize_endeksli_kredimi(ps_modul,ps_urun,ps_sinif) = 'H'  THEN
     ln_returncode := 3;
    ELSIF Pkg_Kredi.sf_dovize_endeksli_kredimi(ps_modul,ps_urun,ps_sinif) = 'E' THEN
     ln_returncode := 4;
  END IF;
  END IF;

  RETURN ln_returncode;
END;


FUNCTION GetAccountPaymentPolicyInfo(pn_account_no IN VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
  ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
  SELECT b.sira_no, TO_CHAR(b.vade_valor,'YYYYMMDD'), NVL(b.tutar,0), NVL(b.faiz_tutari,0), NVL(b.muhabir_masrafi,0) ,b.referans
  FROM   CBS_HESAP_KREDI a ,CBS_ITH_VESAIK_ODEME b
  WHERE  b.referans = a.referans AND
   a.hesap_no = TO_NUMBER(pn_account_No) AND
   b.durum_kodu = 'A' AND
   a.durum_kodu = 'A';
  RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN Log_At(SQLERRM);
END;


FUNCTION GetAccountType(ps_tur IN NUMBER,ps_urun IN VARCHAR2,ps_sinif IN VARCHAR2) RETURN VARCHAR2 IS
 ln_returncode VARCHAR2(100) ;
BEGIN

  SELECT HESAP_TURU
  INTO   ln_returncode
  FROM   CBS_INT_HESAP_TURU
  WHERE  HESAP_TIPI     = ps_tur AND
     URUN_TUR_KOD     = ps_urun AND
     URUN_SINIF_KOD    = ps_sinif ;

  RETURN ln_returncode;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
   ln_returncode := ' ' ;
  WHEN OTHERS THEN
   ln_returncode :=' ';

END;
-----------------------------------------------------------------------------------
FUNCTION GetStaffInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode VARCHAR2(3):='000';
   ln_pnumara    NUMBER;
BEGIN

  OPEN pc_ref FOR
  SELECT ADI ||' '|| SOYADI,KODU,TO_CHAR(SYSDATE,'YYYYMMDD'),'', SIFRE, PERSONEL_NUMARA, TUR,
      DEKONT_YAZICI, RAPOR_YAZICI, PROFIL_KOD, YARATILDIGI_TARIH,
      YARATAN_KULLANICI_KODU, VERSIYON, AGENT, EMAIL, CALISILAN_BOLUM,
      GOREV_KODU, RAPOR_SUNUCUSU
  FROM CBS_KULLANICI
  WHERE PERSONEL_NUMARA=TO_NUMBER(pn_musteri_no);

 SELECT PERSONEL_NUMARA
 INTO ln_pnumara
 FROM CBS_KULLANICI
 WHERE PERSONEL_NUMARA=TO_NUMBER(pn_musteri_no);

  RETURN ls_returncode;

EXCEPTION
 WHEN NO_DATA_FOUND THEN
   RETURN '024';
END;
------------------------------------------------------------------------------------
FUNCTION GetTranAccounts(pn_musteri_no IN VARCHAR2,
		 			     ps_currcode IN VARCHAR2,
						 pn_person_id  IN VARCHAR2,
					     pn_channel_cd IN VARCHAR2,
						 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  noAccoutFound        EXCEPTION;
  ls_account_count NUMBER:=0;
BEGIN
     OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;
  log_at('ACCOUNTS05');
   SELECT COUNT(*)
   INTO ls_account_count
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = pn_musteri_No
   AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
   AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
   AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
   AND HESAP_NO NOT IN (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = pn_person_id);

   IF (ls_account_count= 0) THEN
   RAISE noAccoutFound;
   END IF;

  OPEN pc_ref FOR
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
      ISIM_UNVAN,
      sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
      HESAP_NO,
      DOVIZ_KODU,
      NVL(BAKIYE,0),
      NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
      1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,kisa_isim,
      external_hesap_no,
      Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = pn_musteri_No
       AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
    AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
    AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
	AND HESAP_NO NOT IN (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = pn_person_id)
  UNION
  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
      ISIM_UNVAN,
      sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
      HESAP_NO,
      DOVIZ_KODU,
      NVL(BAKIYE,0),
      NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
      2 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,kisa_isim,
      external_hesap_no,
      Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
    FROM CBS_vw_hesap_izleme a
    WHERE hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE ='sTRAN')
       AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
    AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
    AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
	AND HESAP_NO NOT IN (select HESAP_NO from CORPINT.TBL_ACCOUNT_ASSIGN where PERSON_ID = pn_person_id)
    ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;
  EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '503';
 RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
FUNCTION GetBranchCodes(ps_langcd IN VARCHAR2,ps_bankcd IN VARCHAR2,ps_citycd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

  OPEN pc_ref FOR
 --select lpad(s.sube_kodu,3,'0'), s.sube_adi, i.il_kodu, i.il_adi
 SELECT s.sube_kodu, s.sube_adi, i.il_kodu, i.il_adi
 FROM CBS_BANKA_SUBE_KODLARI s,
   CBS_IL_KODLARI i,
   CBS_BANKA_KODLARI b
 WHERE b.banka_tcmb_kodu = LPAD(ps_bankcd,3,'0')
 AND s.banka_kodu = b.banka_kodu
 AND s.il_kodu = NVL(LPAD(ps_citycd,3,'0'), s.il_kodu)
 AND s.il_kodu = i.il_kodu
 AND s.kapanma_tarihi IS NULL
 ORDER BY s.sube_adi;

   RETURN ls_returncode;

 END;
--------------------------------------------------------------------------------------\
FUNCTION GetInterestRate(ps_trantype IN VARCHAR2,
        ps_vade1 IN VARCHAR2,
        pn_vade2 IN VARCHAR2,
       ps_currency  IN VARCHAR2,
        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode   VARCHAR2(3):='000';

BEGIN
  -- en son tarihli orani al?yorum

  OPEN pc_ref FOR
   --SELECT TARIH, VADE_1, VADE_2, TRL, USD, EUR, GBP
   --FROM CBS_CARI_VADELI_MEVDUAT_FO
   --ORDER BY VADE_1;
         SELECT TARIH, VADE_1, VADE_2, TRL, USD, EUR, GBP
   FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO)
   ORDER BY VADE_1;

 RETURN ls_returncode;
END;

FUNCTION CreateCurrentAccount(ps_customerid  IN VARCHAR2,
          ps_modul_tur   IN VARCHAR2,
          pn_urun_tur    IN VARCHAR2,
         ps_urun_sinif  IN VARCHAR2,
         ps_doviz_kod   IN VARCHAR2,
         ps_bolum_kodu  IN VARCHAR2,
            ps_nickname    IN VARCHAR2,
         ps_cek_karnesi IN VARCHAR2,
         ps_hesap_hareket_kodu IN VARCHAR2,
         ps_dekont IN VARCHAR2,
         ps_ekstre_kodu IN VARCHAR2,
         ps_esas_gun_sayisi IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode   VARCHAR2(3):='000';
   ln_hesap_no    NUMBER;
BEGIN

  ln_hesap_no:=Pkg_Hesap.VadesizHesapAcilis(TO_NUMBER(ps_customerid),
          ps_modul_tur,
          pn_urun_tur,
          ps_urun_sinif,
          ps_doviz_kod,
          ps_bolum_kodu,
          ps_nickname,
          ps_cek_karnesi,
          TO_NUMBER(ps_hesap_hareket_kodu),
          ps_dekont,
          ps_ekstre_kodu,
          TO_NUMBER(ps_esas_gun_sayisi));
 OPEN pc_ref FOR
   SELECT  TO_CHAR(ln_hesap_no) FROM DUAL;

 RETURN ls_returncode;
 EXCEPTION
   WHEN OTHERS THEN
   ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
   ROLLBACK;
   OPEN pc_ref FOR
              SELECT SYSDATE FROM dual;
   RETURN ls_returncode;
END;
---------------------------------------------------------------------------------------
FUNCTION GetCreditClc(ps_amount IN VARCHAR2,
        ps_currencycode IN VARCHAR2,
                      ps_loannumber IN VARCHAR2,
       ps_taksit_index IN VARCHAR2,-- bu taksit index t?m arraylari d?nemedi?im i?in varray?n ilgili eleman?n? d?nece?im.
                                   -- b?ylece taksit say?s? kadar d?ng? kuraca??m.
       ps_startdate IN VARCHAR2,
       ps_credittype IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  lv_odeme_1 Pkg_Type.v_odeme_plan:=Pkg_Type.v_odeme_plan(); -- ?deme plan? outputu
  lv_odeme_satiri Pkg_Type.v_odeme_satir;
  ln_faiz_orani NUMBER := 5 ; -- bunu mutlu s?yledi teyit et.
  ln_kkdv_orani NUMBER := 10 ; -- bunu mutlu s?yledi teyit et.
  ln_bsmv_orani NUMBER := 1 ; -- mutluya sor.
  ln_total_orani NUMBER := 0 ; -- kendisi otomatik olarak buluyor v set ediyor
  ln_kdv_orani NUMBER := 0 ; -- mutluya sor
  ls_vergi VARCHAR2(1) := 'E'; --vergi kesintisi var m??
  ls_fon VARCHAR2(1) := 'E';  -- fon kesintisi var m??
  ls_kdv VARCHAR2(1) := 'H';  -- kdv kesintisi var m??
  ln_taksit_sayisi NUMBER := TO_NUMBER(ps_loannumber); -- taksit say?s?
  ls_doviz VARCHAR2(3) := ps_currencycode; -- d?viz kuru
  ln_kalan_anapara NUMBER :=TO_NUMBER(REPLACE(REPLACE(ps_amount,',',''),'.',',')); -- ana para
  ld_ilk_taksit_tarih DATE := TO_DATE(ps_startdate,'YYYYMMDD'); -- bunu mutluya sor
  ls_once_sonra VARCHAR2(6) :=''; -- bunu mutluya sor
  pd_donem_bas_son VARCHAR2(1) :='S'; --default de?eri mutluya sor
  pn_faiz_ilave NUMBER := 0;
  BEGIN

  OPEN pc_ref FOR
  SELECT SYSDATE FROM DUAL; -- hata vermemesi i?in dummy bir de?er

  -- ?nce gidip kredi faiz oralnlarini ??reniyorum

 SELECT c.KKDF,c.KDV,c.BSMV
 INTO ln_kkdv_orani,ln_kdv_orani,ln_bsmv_orani
 FROM CBS_KREDI_TUR c
 WHERE c.KOD_NO=TO_NUMBER(ps_credittype);

  -- bir kredi t?r?ne ait pek ?ok faiz de?eri olabilir
  -- bu y?zden numaras? en k???k olan yani vadesi en d???k olan? se?iyorum

 SELECT v.FAIZ_ORANI
 INTO ln_faiz_orani
 FROM CBS_KREDI_TUR_VADE v
 WHERE v.KREDI_TUR_KOD_NO = TO_NUMBER(ps_credittype)
 AND v.NUMARA = (
  SELECT MIN(NUMARA)
  FROM CBS_KREDI_TUR_VADE v
  WHERE v.KREDI_TUR_KOD_NO=TO_NUMBER(ps_credittype)
 );

  -- ?nce PKG_FAIZ_HESAPLARI alt?nda sabit ?demeli fonksyonunu ?a??r
  Pkg_Faiz_Hesaplari.sabit_odemeli(lv_odeme_1,
                                   ln_faiz_orani,
           ln_kkdv_orani,
           ln_bsmv_orani,
           ln_total_orani,
           ln_kdv_orani,
           ls_vergi,
           ls_fon,
           ls_kdv,
           ln_taksit_sayisi,
           ls_doviz,
           ln_kalan_anapara,
           ld_ilk_taksit_tarih,
           ls_once_sonra,
           pd_donem_bas_son,
           pn_faiz_ilave);

-- Bana ?deme plan? ?n?ldi ?imdi ben ilgili taksidi alaca??m.

    lv_odeme_satiri := lv_odeme_1(TO_NUMBER(ps_taksit_index+1));
 OPEN pc_ref FOR
    SELECT lv_odeme_satiri.v_sira,
        lv_odeme_satiri.v_taksit,
     lv_odeme_satiri.v_anapara,
     lv_odeme_satiri.v_faiz,
     lv_odeme_satiri.v_kkdf,
     lv_odeme_satiri.v_bsmv,
     lv_odeme_satiri.v_kalan_anapara,
     lv_odeme_satiri.v_kdv,
     TO_CHAR(lv_odeme_satiri.v_vade ,'YYYYMMDD'),
     ln_faiz_orani*100
 FROM DUAL;

  RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS THEN
   Log_At(SQLERRM);
    RETURN '888';

 END;


-----------------------------------------------------------------------------------
FUNCTION GetCustomerIdFromAccount(ps_account_no IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ln_musteri_no  NUMBER:=0; -- default de?er null olmas? durumunda
BEGIN

 SELECT Pkg_Hesap.HesaptanMusteriNoAl(TO_NUMBER(ps_account_no))
 INTO ln_musteri_no
 FROM dual;

 OPEN pc_ref FOR
 SELECT ln_musteri_no FROM DUAL;
 RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS THEN
    ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
 RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------

FUNCTION GetVirmanHesapInfo(ps_account_no IN VARCHAR2,
        ps_currency IN VARCHAR2,
             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ln_hesap_count  NUMBER:=0;
   noAccoutFound        EXCEPTION;
   ls_returncodetmp  VARCHAR2(3):='000';
BEGIN

 OPEN pc_ref FOR
 SELECT SYSDATE FROM DUAL;

 SELECT COUNT(*)
 INTO ln_hesap_count
 FROM CBS_vw_hesap_izleme
    WHERE EXTERNAL_HESAP_NO = ps_account_no; -- var ise detay?n? al?yorum ??nk? detay kodu bunu handle etmiyor

 IF (ln_hesap_count > 0) THEN
    ls_returncodetmp := Pkg_Int_Account.GetCustomerExtAccountDetails(ps_account_no,ps_currency,pc_ref);
 ELSE
     RAISE noAccoutFound;
 END IF;

 RETURN ls_returncode;
EXCEPTION
    WHEN noAccoutFound THEN
       ls_returncode:='505';
 RETURN ls_returncode;
 WHEN OTHERS THEN
       ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
    OPEN pc_ref FOR
         SELECT SYSDATE FROM dual;
 RETURN ls_returncode;
END;


-----------------------------------------------------------------------------------
FUNCTION GetSonrakiIsGunu(ps_date IN VARCHAR2,
             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ps_tmpdate           DATE;
   gecmisgunhatasi      EXCEPTION;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;


 IF ( TO_DATE(ps_date,'YYYYMMDD') < ps_sistem_tarih ) THEN
 RAISE gecmisgunhatasi;
 END IF;

 -- e?er kullan?c? vade sonu olarak belirli bir tarih belirlemi? ise o tarihden bir sonraki uygun tarih bulunur
 SELECT TRUNC(Pkg_Tarih.tarihten_sonraki_isgunu(TO_DATE(ps_date,'YYYYMMDD')-1 ))
 INTO ps_tmpdate
 FROM DUAL;

 OPEN pc_ref FOR
 SELECT TO_CHAR(ps_tmpdate,'YYYYMMDD')
 FROM DUAL;

 RETURN ls_returncode;
EXCEPTION
 WHEN gecmisgunhatasi THEN
       ls_returncode:='215'; -- ge?mi? g?n hatas?
 RETURN ls_returncode;


 WHEN OTHERS THEN
       ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
    OPEN pc_ref FOR
       SELECT SYSDATE FROM dual;
 RETURN ls_returncode;
END;

-----------------------------------------------------------------------------------
FUNCTION GetSureSonra(ps_date IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ps_tmpdate           DATE;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;
BEGIN

 SELECT Pkg_Tarih.tarihten_sonraki_isgunu(ps_sistem_tarih + TO_NUMBER(ps_date)-1)
 INTO ps_tmpdate
 FROM DUAL;

 OPEN pc_ref FOR
 SELECT TO_CHAR(ps_tmpdate,'YYYYMMDD')
 FROM DUAL;

 RETURN ls_returncode;
EXCEPTION
 WHEN OTHERS THEN
       ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
    OPEN pc_ref FOR
       SELECT SYSDATE FROM dual;
 RETURN ls_returncode;
END;
-------------------------------------------------------------------
FUNCTION GetUygunVadeOraniforDate(ps_date IN VARCHAR2,
                                  ps_currcode IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ps_tmpdate           DATE;
   ps_kur               NUMBER:=0;
   uygunFaizOraniBulunamadi EXCEPTION;

BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual; -- dummy

    IF (ps_currcode = 'USD') THEN

 SELECT USD
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= TO_NUMBER(ps_date) AND VADE_2 >= TO_NUMBER(ps_date);

   IF (ps_kur > 0) THEN
    OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
   ELSE
   RAISE NO_DATA_FOUND;
   END IF;


    ELSIF (ps_currcode = 'EUR') THEN

 SELECT EUR
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= TO_NUMBER(ps_date) AND VADE_2 >= TO_NUMBER(ps_date);

  IF (ps_kur > 0) THEN
   OPEN pc_ref FOR
  SELECT ps_kur FROM DUAL;
   ELSE
  RAISE NO_DATA_FOUND;
    END IF;

    ELSIF (ps_currcode = 'GBP') THEN

 SELECT GBP
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= TO_NUMBER(ps_date) AND VADE_2 >= TO_NUMBER(ps_date);

  IF (ps_kur > 0) THEN
   OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
  ELSE
   RAISE NO_DATA_FOUND;
     END IF;

 ELSIF (ps_currcode = 'TRY') THEN

 SELECT TRL
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= TO_NUMBER(ps_date) AND VADE_2 >= TO_NUMBER(ps_date);

    IF (ps_kur > 0) THEN
  OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
 ELSE
   RAISE NO_DATA_FOUND;
 END IF;
 ELSE
    RAISE uygunFaizOraniBulunamadi;

 END IF;

 RETURN ls_returncode;
EXCEPTION
 WHEN uygunFaizOraniBulunamadi THEN
       ls_returncode:=216;
 RETURN ls_returncode;

 WHEN NO_DATA_FOUND THEN
   ls_returncode:=217; -- uygun faiz oran? bulunamad?
     OPEN pc_ref FOR
     SELECT SYSDATE FROM dual; -- dummy
 RETURN ls_returncode;
END;
-----------------------------------------------------------------------------------
FUNCTION GetUygunVadeOraniforExactDate(ps_date IN VARCHAR2,
                                  ps_currcode IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode  VARCHAR2(3):='000';
   ps_tmpdate           DATE;
   ps_kur               NUMBER:=0;
   uygunFaizOraniBulunamadi EXCEPTION;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;

BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual; -- dummy

    IF (ps_currcode = 'USD') THEN

 SELECT USD
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= (TO_DATE(ps_date,'YYYYMMDD')- ps_sistem_tarih)  AND VADE_2 >= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih);

    IF (ps_kur > 0) THEN
  OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
    ELSE
   RAISE NO_DATA_FOUND;
    END IF;

    ELSIF (ps_currcode = 'EUR') THEN

 SELECT EUR
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih) AND VADE_2 >= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih);

    IF (ps_kur > 0) THEN
  OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
    ELSE
   RAISE NO_DATA_FOUND;
    END IF;

    ELSIF (ps_currcode = 'GBP') THEN

 SELECT GBP
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih) AND VADE_2 >=(TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih);

    IF (ps_kur > 0) THEN
  OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
    ELSE
   RAISE NO_DATA_FOUND;
    END IF;

 ELSIF (ps_currcode = 'TRY') THEN

 SELECT TRL
 INTO ps_kur
    FROM CBS_CARI_VADELI_MEVDUAT_FO WHERE
 TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO ) AND
 VADE_1 <= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih) AND VADE_2 >= (TO_DATE(ps_date,'YYYYMMDD')-ps_sistem_tarih);

    IF (ps_kur > 0) THEN
  OPEN pc_ref FOR
   SELECT ps_kur FROM DUAL;
    ELSE
   RAISE NO_DATA_FOUND;
    END IF;

 ELSE
    RAISE uygunFaizOraniBulunamadi;

 END IF;

 RETURN ls_returncode;
EXCEPTION
 WHEN uygunFaizOraniBulunamadi THEN
       ls_returncode:=216;
 RETURN ls_returncode;

 WHEN NO_DATA_FOUND THEN
       ls_returncode:=217;
      OPEN pc_ref FOR
      SELECT SYSDATE FROM dual; -- dummy
 RETURN ls_returncode;
END;
--------------------------------------------------------------
FUNCTION CreateTimeDepositeAccount(ps_customerid IN VARCHAR2,
                                   ps_modultur IN VARCHAR2,
                                   ps_uruntur IN VARCHAR2,
                                   ps_urunsinif IN VARCHAR2,
                                   ps_nickname IN VARCHAR2,
           ps_currcode IN VARCHAR2,
                                   ps_anapara IN VARCHAR2,
                                   ps_valortarihi IN VARCHAR2,
           ps_borckaydi IN VARCHAR2,
           ps_borcluhesapnumarasi IN VARCHAR2,
           ps_muhabirhesapnumarasi IN VARCHAR2,
           ps_dknumarasi IN VARCHAR2,
           ps_vade_islem_bilgisi IN VARCHAR2,
           ps_ara_odeme_bilgisi IN VARCHAR2,
                                   ps_otomatik_temdit IN VARCHAR2,
                                   ps_periodsure IN VARCHAR2,
                                   ps_periodcins IN VARCHAR2,
                                   ps_sonraki_baslangic_tarihi IN VARCHAR2,
                                   ps_ara_odeme_islem_bilgisi IN VARCHAR2,
                                   ps_vade_tarihi IN VARCHAR2,
                                   ps_geri_donus_hesap_numarasi IN VARCHAR2,
                                   ps_esas_gun_sayisi IN VARCHAR2,
                                   ps_faiz_orani IN VARCHAR2,
                                   ps_aciklama IN VARCHAR2,
                                   ps_sube IN VARCHAR2,
           ps_acilistarihi IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode   VARCHAR2(3):='000';
   ln_hesap_no    NUMBER;
   pn_islem_no NUMBER;
   pn_islem_kod NUMBER;
   pc_modul_tur_kod VARCHAR2(20):=ps_modultur;
   pc_urun_tur_kod VARCHAR2(20):=ps_uruntur;
   pc_urun_sinif_kod VARCHAR2(20):=ps_urunsinif;

   ps_BOLUM_KODU VARCHAR2(3):=Pkg_Hesap.HesapSubeAl(ps_borcluhesapnumarasi);
   pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
   pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
   pc_rol NUMBER:=5000;
   ln_tutar NUMBER:= TO_NUMBER(REPLACE(REPLACE(ps_anapara,',',''),'.',','));
   pc_doviz_kod VARCHAR(10):= ps_currcode ;
   pn_musteri_numara NUMBER:= Pkg_Hesap.HesaptanMusteriNoAl(TO_NUMBER(ps_borcluhesapnumarasi));
   pc_hesap_numara NUMBER:= TO_NUMBER(ps_borcluhesapnumarasi);
   pc_kasa_kod NUMBER;
   pn_KANAL_NUMARA NUMBER:= 1;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;
BEGIN

    pn_islem_no:=Pkg_Tx.islem_no_al;
 pn_islem_kod:=2003 ;
 ln_hesap_no:=Pkg_Genel.genel_kod_al('HESAP.VDSZ');


 OPEN pc_ref FOR
 SELECT SYSDATE FROM DUAL;

 INSERT INTO CBS_HESAP_VADELI_BASVURU(
 TX_NO, HESAP_NUMARASI, MUSTERI_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, KISA_ISIM,
 DOVIZ_KODU, TUTAR, VALOR_TARIHI, BORC_KAYDI, BORCLU_HESAP_NO, MUHABIR_HESAP_NO, DK_NO,
 VADE_ISLEM_BILGISI, ARA_ODEME_BILGISI, OTOMATIK_TEMDIT, PERIOD_SURE, PERIOD_CINS, SONRAKI_BASLANGIC_TARIHI,
 ARA_ODEME_ISLEM_BILGISI, VADE_TARIHI, GERI_DONUS_HESAPNO, ESAS_GUN_SAYISI, FAIZ_ORANI, ACIKLAMA,
 EKSTRE_BASIM_KODU,EKSTRE_SIKLIGI, DEKONT, SUBE_KODU, ACILIS_TARIHI, MIN_IMZA_ADEDI, MUSTERI_DK_NO, MUHASEBE_TARIHI)

 VALUES (pn_islem_no,ln_hesap_no,TO_NUMBER(ps_customerid),ps_modultur,ps_uruntur,ps_urunsinif,ps_nickname,
         ps_currcode,TO_NUMBER(REPLACE(REPLACE(ps_anapara,',',''),'.',',')),ps_sistem_tarih,ps_borckaydi,TO_NUMBER(ps_borcluhesapnumarasi),ps_muhabirhesapnumarasi,ps_dknumarasi,
   ps_vade_islem_bilgisi,ps_ara_odeme_bilgisi,ps_otomatik_temdit,ps_periodsure,ps_periodcins,ps_sonraki_baslangic_tarihi,
            ps_ara_odeme_islem_bilgisi,TO_DATE(ps_vade_tarihi,'YYYYMMDD'),ps_geri_donus_hesap_numarasi,TO_NUMBER(ps_esas_gun_sayisi),TO_NUMBER(ps_faiz_orani),ps_aciklama,
   'X','','X',ps_sube,ps_sistem_tarih,'','',ps_sistem_tarih);

 Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
          pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
             ln_TUTAR, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
          pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
          pc_kasa_kod,pn_KANAL_NUMARA);


 Pkg_Int_Api.process_transaction (pn_islem_no);

 OPEN pc_ref FOR
 SELECT TO_CHAR(ln_hesap_no) FROM DUAL;

 RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
 ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
 Log_At(SQLERRM);
 ROLLBACK;
 OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;
 RETURN ls_returncode;
END;
----------------------------------------------
FUNCTION GetTranAccountsForCurrcode(pn_musteri_no IN VARCHAR2,
                                 ps_currcode IN VARCHAR2,
         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ls_accountcount NUMBER:=0;
  noAccoutFound EXCEPTION;
BEGIN

   SELECT   COUNT(*)
   INTO ls_accountcount
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = pn_musteri_No
       AND durum_kodu = 'A'
    AND modul_tur_kod= 'VADESIZ'
    AND urun_tur_kod IN ('MUSTAK-TP','MUSTAK-YP','TEMINAT-TP','TEMINAT-YP','BLOKE-TP','BLOKE-YP','TASARRF-TP','TASARRF-YP')
    AND DOVIZ_KODU=ps_currcode;

     IF (ls_accountcount= 0) THEN
   RAISE noAccoutFound;
   END IF;

  OPEN pc_ref FOR
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
      ISIM_UNVAN,
      sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
      HESAP_NO,
      DOVIZ_KODU,
      NVL(BAKIYE,0),
      NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
      1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = pn_musteri_No
       AND durum_kodu = 'A'
    AND modul_tur_kod= 'VADESIZ'
    AND urun_tur_kod IN ('MUSTAK-TP','MUSTAK-YP','TEMINAT-TP','TEMINAT-YP','BLOKE-TP','BLOKE-YP','TASARRF-TP','TASARRF-YP')
    AND DOVIZ_KODU=ps_currcode
    ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;
    EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '503';
 RETURN ls_returncode;


END;
--------------------------------------------------------------------------------------------
FUNCTION GetBankDate(dummyvalue IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
     SELECT  TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD')
  FROM DUAL;
RETURN ls_returncode;

END;
--------------------------------------------------------------
FUNCTION GetCustomerTDAccountCount(ps_customerid IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ln_accountcount NUMBER:=0;

BEGIN
 SELECT  COUNT(*) INTO ln_accountcount
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = ps_customerid AND
      durum_kodu = 'A' AND
   modul_tur_kod= 'VADELI';

 OPEN pc_ref FOR
 SELECT ln_accountcount FROM dual;

RETURN ls_returncode;
END;
-----------------------------------------------------------------------------
FUNCTION CloseTimeDepositAcount(ps_customerid IN VARCHAR2,
         ps_hesapnumarasi IN VARCHAR2,
        ps_dovizkodu IN VARCHAR2,
        ps_aciklama IN VARCHAR2,
        ps_odemesekli IN VARCHAR2,
        ps_odenecekhesap IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode VARCHAR2(3):='000';
   pn_islem_no NUMBER;
   pn_islem_kod NUMBER;
   pc_modul_tur_kod VARCHAR2(20);
   pc_urun_tur_kod VARCHAR2(20);
   pc_urun_sinif_kod VARCHAR2(20);

   ps_BOLUM_KODU VARCHAR2(3):=Pkg_Hesap.HesapSubeAl(TO_NUMBER(ps_hesapnumarasi));
   pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
   pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
   pc_rol NUMBER:=5000; -- herhalde internet ?ubesi bu oluyor
   ln_tutar NUMBER:=Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi));
   pc_doviz_kod VARCHAR(10):= ps_dovizkodu ;
   pn_musteri_numara NUMBER:= TO_NUMBER(ps_customerid);
   pc_hesap_numara NUMBER:= TO_NUMBER(ps_hesapnumarasi);
   pc_kasa_kod NUMBER;
   pn_KANAL_NUMARA NUMBER:= 1;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;

BEGIN
   pn_islem_no:=Pkg_Tx.islem_no_al;
   pn_islem_kod:=2004 ;
   Pkg_Hesap.UrunBilgiAl(TO_NUMBER(ps_hesapnumarasi),pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

   OPEN pc_ref FOR
 SELECT SYSDATE FROM DUAL;

   IF (ps_dovizkodu = Pkg_Genel.LC_al) THEN

   INSERT INTO CBS_HESAP_VDLI_KAPAMA_BASVURU
   (TX_NO, MUSTERI_NO, HESAP_NO, DOVIZ_KODU,BAKIYE_TUTARI,ACIKLAMA,
 NET_ODENEN_TUTAR,TL_ODEME_SEKLI, TL_ODEME_HESAP_NO, DEKONT,KUR,TL_KARSILIK,BIRIKMIS_FAIZ, GECEN_YIL_FAIZI,
 TOPLAM_FAIZ_TUTARI, MSIGV, SSDF, OZEL_ISLEM_VERGISI,TL_ODEME_TUTARI)

   VALUES
   (pn_islem_no,TO_NUMBER(ps_customerid),TO_NUMBER(ps_hesapnumarasi),ps_dovizkodu,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),
    ps_aciklama,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)), '2', TO_NUMBER(ps_odenecekhesap),'X',Pkg_Kur.doviz_doviz_karsilik(ps_dovizkodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),
 Pkg_Kur.yuvarla(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(ps_dovizkodu,Pkg_Genel.LC_AL,NULL,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),1,NULL,NULL,'O','A'))
 ,0,0,0,0,0,0,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)));

   ELSE
    INSERT INTO CBS_HESAP_VDLI_KAPAMA_BASVURU
 (TX_NO, MUSTERI_NO, HESAP_NO, DOVIZ_KODU, BAKIYE_TUTARI,ACIKLAMA,
  NET_ODENEN_TUTAR,YP_ODEME_SEKLI, YP_ODEME_HESAP_NO, DEKONT,KUR,BIRIKMIS_FAIZ, GECEN_YIL_FAIZI,
 TOPLAM_FAIZ_TUTARI, MSIGV, SSDF, OZEL_ISLEM_VERGISI,YP_ODEME_TUTARI,TL_KARSILIK)

 VALUES
 (pn_islem_no,TO_NUMBER(ps_customerid),TO_NUMBER(ps_hesapnumarasi),ps_dovizkodu,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),
 ps_aciklama,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),'2', TO_NUMBER(ps_odenecekhesap),'X',Pkg_Kur.doviz_doviz_karsilik(ps_dovizkodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A'),0,0,0,0,0,0,
 Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),Pkg_Kur.yuvarla(Pkg_Genel.lc_al,Pkg_Kur.doviz_doviz_karsilik(ps_dovizkodu,Pkg_Genel.LC_AL,NULL,Pkg_Hesap.HesapBakiyeAl(TO_NUMBER(ps_hesapnumarasi)),1,NULL,NULL,'O','A')));
   END IF;


 Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
          pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
             ln_TUTAR, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
          pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
          pc_kasa_kod,pn_KANAL_NUMARA);

 Pkg_Int_Api.process_transaction (pn_islem_no);

RETURN ls_returncode;
EXCEPTION
   WHEN OTHERS THEN
 ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
 Log_At(SQLERRM);
 ROLLBACK;
 OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;
RETURN ls_returncode;
END;
--------------------------------------------------------------
FUNCTION ControlSameCurrecyAccount
(pn_musteri_no IN VARCHAR2,ps_currcode IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode VARCHAR2(3):='000';
  noAccoutFound        EXCEPTION;
  ls_account_count NUMBER:=0;

  CURSOR cursor_auth IS
     SELECT  COUNT(*) lala
  FROM CBS_vw_hesap_izleme a
  WHERE musteri_no = pn_musteri_No
   AND durum_kodu = 'A'
   AND modul_tur_kod= 'VADESIZ'
   AND urun_tur_kod IN ('MUSTAK-TP','MUSTAK-YP','TEMINAT-TP','TEMINAT-YP','BLOKE-TP','BLOKE-YP','TASARRF-TP','TASARRF-YP')
   AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
   AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
  GROUP BY DOVIZ_KODU
  HAVING COUNT(*) > 1;

  row_auth cursor_auth%ROWTYPE;

BEGIN

  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;

  OPEN cursor_auth;
 FETCH cursor_auth INTO row_auth;

  IF  (cursor_auth%NOTFOUND) THEN
  ls_returncode := '504';
  END IF;

  CLOSE cursor_auth;

  RETURN ls_returncode;
END;

----------------------------------------------------
FUNCTION SetEkstreInfo(ps_accountNo IN VARCHAR2,
                 p_hesapEkstre IN VARCHAR2,
                 p_dovizEkstre IN VARCHAR2,
        p_ekstreEMail IN VARCHAR2,
                       p_hesapekstreperiod IN VARCHAR2,
         p_kurekstreperiod IN VARCHAR2,
           p_kurEMail IN VARCHAR2,
           p_personID IN VARCHAR2,
         p_varlik IN VARCHAR2,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode    VARCHAR2(3):='000';
 ps_dovizekstrecount   NUMBER := 0;
 ps_hesapekstrecount   NUMBER := 0;
 ln_ekstreeid NUMBER;

 BEGIN
 OPEN pc_ref FOR
 SELECT SYSDATE FROM DUAL;

 -- once bakal?m daha ?nceden kay?t var m?? var ise silecez ve tekrar yazacaz..

   IF (p_personID IS NOT NULL) THEN
        -- o persona ait olan kur ekstre bilgilerini sil var ise
  SELECT COUNT(*)
  INTO ps_dovizekstrecount
  FROM CBS_INT_EKSTRE t
  WHERE t.PERSONID = p_personID AND t.EKSTRETYPE='KUR';

  IF (ps_dovizekstrecount > 0) THEN
    DELETE FROM
    CBS_INT_EKSTRE t
    WHERE t.PERSONID = p_personID AND t.EKSTRETYPE='KUR';
  END IF;
    END IF ;

 IF (ps_accountNo IS NOT NULL) THEN
  SELECT COUNT(*)
  INTO ps_hesapekstrecount
  FROM CBS_INT_EKSTRE t
  WHERE t.ACCOUNTNO=TO_NUMBER(ps_accountNo) AND t.EKSTRETYPE='HESAP';

  IF (ps_hesapekstrecount > 0) THEN
    DELETE FROM
    CBS_INT_EKSTRE t
    WHERE t.ACCOUNTNO=TO_NUMBER(ps_accountNo) AND t.EKSTRETYPE='HESAP';
  END IF;
 END IF;

 -- ?imdi insert zaman?

 IF (p_hesapEkstre = 'HESAP') THEN
     INSERT INTO CBS_INT_EKSTRE( EKSTRETYPE, NEXTRUNDATE, PERIOD, ACCOUNTNO, EMAILADRES,VARLIKBILGI)
   VALUES('HESAP',DECODE( p_hesapekstreperiod,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
  p_hesapekstreperiod,ps_accountNo,p_ekstreEMail,p_varlik);
 END IF;

 IF (p_dovizEkstre = 'KUR') THEN
     INSERT INTO CBS_INT_EKSTRE(EKSTRETYPE, NEXTRUNDATE, PERIOD, PERSONID, EMAILADRES)
  VALUES('KUR',DECODE(p_kurekstreperiod,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
  p_kurekstreperiod,p_personID, p_kurEMail);
 END IF;


    RETURN ls_returncode;
EXCEPTION
  WHEN OTHERS THEN
 RETURN '999';
END;
-----------------------------------------------------------------------------------

FUNCTION GetEkstreInfo(ps_accountNo IN VARCHAR2,
                       ps_type IN VARCHAR2,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode    VARCHAR2(3):='000';
 BEGIN

 -- kur bilgileri accounta ba?l? olarak tutulmad??? i?in
 -- account no k?sm?na girilen de?er asl?nda personid de?eri
 --
    IF (ps_type = 'KUR') THEN
  OPEN pc_ref FOR
  SELECT t.PERIOD,t.EMAILADRES FROM CBS_INT_EKSTRE t
  WHERE t.EKSTRETYPE=ps_type AND
        t.PERSONID=ps_accountNo; --person no

 ELSIF (ps_type = 'HESAP') THEN
  OPEN pc_ref FOR
  SELECT t.PERIOD,t.EMAILADRES,t.ACCOUNTNO,t.VARLIKBILGI FROM CBS_INT_EKSTRE t,CBS_HESAP h
  WHERE
  t.ACCOUNTNO=h.HESAP_NO AND
  h.MUSTERI_NO=ps_accountNo AND
  t.EKSTRETYPE=ps_type;

 ELSE
  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;
 END IF ;


    RETURN ls_returncode;

 EXCEPTION
   WHEN OTHERS THEN
 RETURN '999';
END;
----------------------------------------------------------------------
FUNCTION GetTRYValue(ps_YtlValue IN VARCHAR2,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode    VARCHAR2(3):='000';
 BEGIN

 OPEN PC_REF FOR
 SELECT TO_NUMBER(REPLACE(REPLACE(ps_YtlValue,',',''),'.',',')) * 1000000
 FROM dual;
 RETURN ls_returncode;

 EXCEPTION
   WHEN OTHERS THEN
   OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;
 RETURN '999';
END;
-----------------------------------------------------------------------
FUNCTION TXDecont(pn_txno IN VARCHAR2,
                  ps_accountno IN VARCHAR2,
               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
        ls_returncode    VARCHAR2(3):='000';
 BEGIN

 OPEN PC_REF FOR
 SELECT  TO_CHAR(a.fis_muhasebelestigi_tarih,'YYYYMMDD'),
   TO_CHAR(a.satir_valor_tarihi,'YYYYMMDD'),
   UPPER(a.satir_musteri_aciklama),
   a.satir_dv_tutar,
   NVL(pkg_passbook.hareketlibakiyehesapla(a.satir_hesap_numara,a.fis_numara,a.satir_numara),0) son_bakiye,
   SATIR_DOVIZ_KOD,
   DECODE(i.KOD,'1203','Transfer To Your Account','2102','Clearing','2000','Opening Current Account','4025','Buying Fx','1202','Selling Fx', i.ACIKLAMA),
   k.NUMARA,
   k.ISLEM_KOD
 FROM cbs_vw_fis_satir_vsziz a,CBS_ISLEM k, CBS_ISLEM_TANIM i
 WHERE  satir_hesap_numara = ps_accountno
        AND k.NUMARA = pn_txno
     AND fis_tur = 'G'
     AND k.numara=a.FIS_ISLEM_NUMARA
     AND i.kod=k.islem_kod;

    RETURN ls_returncode;

 EXCEPTION
   WHEN OTHERS THEN
   OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;
 RETURN '999';
END;
--------------------------------------------------------------
FUNCTION HesapMusteriKontrol(pn_accountNo  IN VARCHAR2,
                             pn_customerNo IN VARCHAR2,
                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
       ls_returncode VARCHAR2(3):='000';
       ls_count NUMBER:=0;
       ls_count1 NUMBER:=0;


BEGIN
    -- bu hesap ger?ekten bu m??teriye mi ait
 -- hack edilme durumlar? i?in yap?lm??t?r
 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    SELECT COUNT(*)
 INTO ls_count
 FROM CBS_vw_hesap_izleme a
 WHERE a.HESAP_NO = TO_NUMBER(pn_accountNo)
 AND a.MUSTERI_NO = TO_NUMBER(pn_customerNo)
 AND a.DURUM_KODU = 'A';

 IF(ls_count = 0) THEN

 SELECT COUNT(*)
 INTO ls_count1
 FROM CBS_JOIN_ACCOUNT
 WHERE REL_ACCOUNT = TO_NUMBER(pn_accountNo)
 AND CUST_NO = TO_NUMBER(pn_customerNo);

    IF (ls_count1 = 0) THEN
    ls_returncode:='432';
 END IF;
 END IF;

 IF Pkg_Hesap.BadListFlag(pn_accountNo)='E' THEN
    ls_returncode:='431';
 END IF;

    RETURN ls_returncode;

END;
---------------------------------------------------------------------------
FUNCTION HesapEkstreleriSil(pn_customerNo IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
       ls_returncode VARCHAR2(3):='000';
       ls_count NUMBER:=0;
-- hesap ekstrelerini update etmeden ?nce hepsini siliyorum
BEGIN
 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 SELECT COUNT(*)
 INTO  ls_count
 FROM CBS_INT_EKSTRE E
 WHERE E.EKSTRETYPE='HESAP' AND
 E.ACCOUNTNO IN ( SELECT H.HESAP_NO  FROM CBS_HESAP H
                  WHERE H.MUSTERI_NO=PN_CUSTOMERNO);

 IF (ls_count > 0) THEN

 DELETE FROM CBS_INT_EKSTRE E
 WHERE E.EKSTRETYPE='HESAP' AND
 E.ACCOUNTNO IN ( SELECT H.HESAP_NO  FROM CBS_HESAP H
                  WHERE H.MUSTERI_NO=PN_CUSTOMERNO);
 COMMIT;
 END IF;

    RETURN LS_RETURNCODE;

END;
-------------------------------------------------------------------------
FUNCTION FinSumHoldingsList(pn_customerNo IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
            ls_returncode VARCHAR2(3):='000';

BEGIN

 OPEN pc_ref FOR
 SELECT * FROM
 (
     -- current accounts in KGS
  SELECT 'KGS Current Accounts' hesap_tanim,
         NVL(SUM(a.BAKIYE),0) bakiye_toplam,
      1 siralama,
      1 varlikborcsiralama
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU=Pkg_Genel.lc_al
 UNION
        -- current accounts in USD
  SELECT 'USD Current Accounts' hesap_tanim,
         NVL(SUM(a.BAKIYE),0) bakiye_toplam,
      2 siralama,
      1 varlikborcsiralama
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'USD'
 UNION
        -- current accounts in EUR
  SELECT 'EUR Current Accounts' hesap_tanim,
         NVL(SUM(a.BAKIYE),0) bakiye_toplam,
      3 siralama,
      1 varlikborcsiralama
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'EUR'
 UNION
        -- current accounts in other currency
  SELECT 'Current Accounts in other currency' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam,
      4 siralama,
      1 varlikborcsiralama
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
     UNION
         SELECT
       'Cash Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
      5 siralama,
   2 varlikborcsiralama
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = TO_NUMBER(pn_customerNo) AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = Pkg_Genel.LC_al
     UNION
         SELECT
       'Cash Credits in USD' hesap_tanim,
      ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
      6 siralama,
   2 varlikborcsiralama
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = TO_NUMBER(pn_customerNo) AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'USD'
     UNION
         SELECT
       'cash Credits in EUR' hesap_tanim,
      ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
      7 siralama,
   2 varlikborcsiralama
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = TO_NUMBER(pn_customerNo) AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'EUR'
     UNION
         SELECT
       'Cash Credits in Other currency ' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0)) bakiye_toplam,
       8 siralama,
    2 varlikborcsiralama
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = TO_NUMBER(pn_customerNo) AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
     UNION

       SELECT
        'FCY Credits in KGS' hesap_tanim,
      ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
      9 siralama,
      2 varlikborcsiralama
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = TO_NUMBER(pn_customerNo) AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = Pkg_Genel.LC_al
     UNION
       SELECT
        'FCY Credits in USD' hesap_tanim,
      ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
      10 siralama,
      2 varlikborcsiralama
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = TO_NUMBER(pn_customerNo) AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'USD'
     UNION
       SELECT
        'FCY Credits in EUR' hesap_tanim,
      ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
      11 siralama,
      2 varlikborcsiralama
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = TO_NUMBER(pn_customerNo) AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'EUR'
     UNION
       SELECT
        'FCY Credits in other currency' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam,
      12 siralama,
      2 varlikborcsiralama
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = TO_NUMBER(pn_customerNo) AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
   )
   ORDER BY siralama ;

    RETURN ls_returncode;

EXCEPTION
   WHEN OTHERS THEN
      Log_At('FINSUM-1',SQLERRM);
END;
------------------------------------------------------------------------
FUNCTION FinSumHoldings(pn_customerNo IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

            ls_returncode VARCHAR2(3):='000';

BEGIN
 OPEN pc_ref FOR
 SELECT * FROM
 (
  SELECT NVL(SUM(bakiye_toplam),0),1 SIRALAMA FROM
  (
      -- currenct accounts in KGS
   SELECT 'Total Holdings in KGS' hesap_tanim,
          NVL(SUM(a.BAKIYE),0) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
      WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
        a.durum_kodu = 'A' AND
     (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
     a.DOVIZ_KODU=Pkg_Genel.lc_al

    )UNION
     SELECT NVL(SUM(bakiye_toplam),0),2 SIRALAMA FROM
  (
   SELECT 'Total Holdings in USA' hesap_tanim,
          NVL(SUM(a.BAKIYE),0) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
      WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
        a.durum_kodu = 'A' AND
     (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
     a.DOVIZ_KODU = 'USD'
    )
    UNION
     SELECT NVL(SUM(bakiye_toplam),0),3 SIRALAMA FROM
  (
   SELECT 'Current Account in EUR' hesap_tanim,
          NVL(SUM(a.BAKIYE),0) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
      WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
        a.durum_kodu = 'A' AND
     (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
     a.DOVIZ_KODU = 'EUR'

    ) UNION
  SELECT NVL(SUM(bakiye_toplam),0),4 SIRALAMA FROM
  (
         -- current account in other currency
   SELECT 'Current Account in other currency' hesap_tanim,
          NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
      WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
        a.durum_kodu = 'A' AND
     (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
         a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
     a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
    )
   )ORDER BY SIRALAMA;

    RETURN ls_returncode;

EXCEPTION
   WHEN OTHERS THEN
      Log_At('FINSUM-2',SQLERRM);

END;
------------------------------------------------------------------------------------
FUNCTION FinSumLiabilities(pn_customerNo IN VARCHAR2,
                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                ls_returncode VARCHAR2(3):='000';
 BEGIN
-- Burada varliklarim listesinde bulunan try de?erleri topluyorum
  OPEN pc_ref FOR
  SELECT * FROM
  (
     SELECT NVL(SUM(bakiye_toplam),0),1 SIRALAMA FROM
      (
    SELECT
        'Cash Credits in KGS' hesap_tanim,
       ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
       WHERE
     musteri_no = TO_NUMBER(pn_customerNo) AND
        durum_kodu = 'A' AND
     urun_tur_kod != 'LEASING' AND
     modul_tur_kod= 'LOAN'  AND
     Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
        Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
     DOVIZ_KODU = Pkg_Genel.LC_al
            UNION
      SELECT
         'FCY Credits in KGS' hesap_tanim,
       ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE
        musteri_no = TO_NUMBER(pn_customerNo) AND
          durum_kodu = 'A' AND
       modul_tur_kod= 'LOAN'  AND
          Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
       a.DOVIZ_KODU = Pkg_Genel.LC_al
           )
  UNION
     SELECT NVL(SUM(bakiye_toplam),0),2 SIRALAMA FROM
      (
          SELECT
        'Cash Credits in USD' hesap_tanim,
       ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
       WHERE
     musteri_no = TO_NUMBER(pn_customerNo) AND
        durum_kodu = 'A' AND
     urun_tur_kod != 'LEASING' AND
     modul_tur_kod= 'LOAN'  AND
     Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
        Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
     DOVIZ_KODU = 'USD'

            UNION
           SELECT
         'FCY Credits in USD' hesap_tanim,
       ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
       WHERE
        musteri_no = TO_NUMBER(pn_customerNo) AND
          durum_kodu = 'A' AND
       modul_tur_kod= 'LOAN'  AND
          Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
       a.DOVIZ_KODU = 'USD'
            )
  UNION
     SELECT NVL(SUM(bakiye_toplam),0),3 SIRALAMA FROM
  (
          SELECT
        'Cash Credits in EUR' hesap_tanim,
       ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
       WHERE
     musteri_no = TO_NUMBER(pn_customerNo) AND
        durum_kodu = 'A' AND
     urun_tur_kod != 'LEASING' AND
     modul_tur_kod= 'LOAN'  AND
     Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
        Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
     DOVIZ_KODU = 'EUR'
          UNION
        SELECT
         'FCY Credits in EUR' hesap_tanim,
       ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE
        musteri_no = TO_NUMBER(pn_customerNo) AND
          durum_kodu = 'A' AND
       modul_tur_kod= 'LOAN'  AND
          Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
       a.DOVIZ_KODU = 'EUR'
  )
     UNION
     SELECT NVL(SUM(bakiye_toplam),0),4 SIRALAMA FROM
  (
          SELECT
        'Cash credits in other currency' hesap_tanim,
       ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0)) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
       WHERE
     musteri_no = TO_NUMBER(pn_customerNo) AND
        durum_kodu = 'A' AND
     urun_tur_kod != 'LEASING' AND
     modul_tur_kod= 'LOAN'  AND
     Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
        Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
     DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
          UNION
       SELECT
        'FCY Credits in other currency' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = TO_NUMBER(pn_customerNo) AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )


   )ORDER BY SIRALAMA;
   RETURN ls_returncode;

EXCEPTION
   WHEN OTHERS THEN
      Log_At('FINSUM-3',SQLERRM);


END;
------------------------------------------------------------------------------------
FUNCTION FinSumTotalHoldings(pn_customerNo IN VARCHAR2,
                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                ls_returncode VARCHAR2(3):='000';
  BEGIN

    OPEN pc_ref FOR
 SELECT * FROM
 (
     SELECT 'Holdings in KGS' hesap_tanim,1 SIRALAMA,SUM(bakiye_toplam) FROM
  (
     -- current account in KGS
  SELECT 'Current Accounts in KGS' hesap_tanim,
         NVL(SUM(a.BAKIYE),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU=Pkg_Genel.lc_al
     UNION
        -- current account in USD
  SELECT 'Current Account in USD' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S') ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'USD'
     UNION
        -- current account in EUR
  SELECT 'Current Accounts in EUR' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
   (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'EUR'
     UNION
        -- Current Accounts in other currency
  SELECT 'Current Accounts in other currency' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
   (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
         a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )
 UNION
     SELECT 'Holdings in USD' hesap_tanim,2 SIRALAMA,SUM(bakiye_toplam) FROM
  (
     -- currenst account in KGS
  SELECT 'Current Accounts in KGS' hesap_tanim,
         NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
      ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU=Pkg_Genel.lc_al
     UNION
        -- current account in usd
  SELECT 'Currenst Accounts in USD' hesap_tanim,
         NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
      ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'USD'
     UNION
        -- current account in eur
  SELECT 'Current Accounts in EUR' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'EUR'
     UNION
        -- current account in other account
  SELECT 'Current Account in other currency' hesap_tanim,
         NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
      ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
         a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )
 UNION
     SELECT 'Holdings in EUR' hesap_tanim,3 SIRALAMA,SUM(bakiye_toplam) FROM
  (
     -- current accounts in KGS
  SELECT 'Current Accounts in KGS' hesap_tanim,
         NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
      ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
     a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU=Pkg_Genel.lc_al
     UNION
        -- Currenst Accounts in usd
  SELECT 'Currenst Accounts in USD' hesap_tanim,
         NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
      ),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'USD'
     UNION
        -- Currenst Accounts in EUR
  SELECT 'Currenst Accounts in EUR' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
    a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU = 'EUR'
     UNION
        -- current accounts in other currency
  SELECT 'Current Accounts in other currency' hesap_tanim,
         NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
     FROM CBS_vw_hesap_izleme a
     WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
       a.durum_kodu = 'A' AND
    (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
        a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL') AND
    a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )
   )ORDER BY siralama;

  RETURN ls_returncode;

EXCEPTION
   WHEN OTHERS THEN
      Log_At('FINSUM-4',SQLERRM);

 END;
--------------------------------------------------------------------------------
FUNCTION FinSumTotalLiabilities(pn_customerNo IN VARCHAR2,
                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
                ls_returncode VARCHAR2(3):='000';
  BEGIN


OPEN pc_ref FOR

 SELECT * FROM
 (
     SELECT 'Liabilities in KGS' hesap_tanim,1 SIRALAMA,SUM(bakiye_toplam) FROM
  (

         SELECT
       'Cash Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = Pkg_Genel.LC_al
   UNION
         SELECT
       'Cash Credits in USD' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'USD'
         UNION
         SELECT
       'Cash Credits in EURO' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'EUR'
         UNION
         SELECT
       'Cash Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
   ,0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
         UNION
      SELECT
        'FCY Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
   WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = Pkg_Genel.LC_al
       UNION
      SELECT
        'FCY Credits in USD' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'USD'
          UNION
       SELECT
        'FCY Credits in EUR' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')
      ),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'EUR'
     UNION
       SELECT
        'FCY Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )
      UNION

      SELECT 'Liabilities in USD' hesap_tanim,2 SIRALAMA,SUM(bakiye_toplam) FROM
  (
         SELECT
       'Cash Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = Pkg_Genel.LC_al
   UNION
         SELECT
       'Cash Credits in USD' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'USD'
         UNION
         SELECT
       'Cash Credits in EURO' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'EUR'
         UNION
         SELECT
       'Cash Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
   ,0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
         UNION
      SELECT
        'FCY Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
   WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = Pkg_Genel.LC_al
       UNION
      SELECT
        'FCY Credits in USD' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'USD'
          UNION
       SELECT
        'FCY Credits in EUR' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')
      ),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'EUR'
     UNION
       SELECT
        'FCY Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )

      UNION

      SELECT 'Liabilities in EUR' hesap_tanim,3 SIRALAMA,SUM(bakiye_toplam) FROM
  (
         SELECT
       'Cash Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = Pkg_Genel.LC_al
   UNION
         SELECT
       'Cash Credits in USD' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'USD'
         UNION
         SELECT
       'Cash Credits in EURO' hesap_tanim,
      ABS(NVL(SUM(NVL(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
   ,0)),0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU = 'EUR'
         UNION
         SELECT
       'Cash Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
   Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
   ,0)) bakiye_toplam
       FROM CBS_vw_hesap_izleme a
      WHERE
    musteri_no = pn_customerNo AND
       durum_kodu = 'A' AND
    urun_tur_kod != 'LEASING' AND
    modul_tur_kod= 'LOAN'  AND
    Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
       Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
    DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
         UNION
      SELECT
        'FCY Credits in KGS' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
      FROM CBS_vw_hesap_izleme a
   WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = Pkg_Genel.LC_al
       UNION
      SELECT
        'FCY Credits in USD' hesap_tanim,
      ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'USD'
          UNION
       SELECT
        'FCY Credits in EUR' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
      ,1,NULL,NULL,'O','S')
      ),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU = 'EUR'
     UNION
       SELECT
        'FCY Credits in Other Currency' hesap_tanim,
      ABS(NVL(SUM(
      Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
      (SELECT NVL(endeks_doviz_tutari ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
    FROM CBS_vw_hesap_izleme a
    WHERE
       musteri_no = pn_customerNo AND
         durum_kodu = 'A' AND
      modul_tur_kod= 'LOAN'  AND
         Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
      a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
  )
    )ORDER BY siralama;



  RETURN ls_returncode;
EXCEPTION
   WHEN OTHERS THEN
      Log_At('FINSUM-5',SQLERRM);

 END;
------------------------------------------------------------------------------------
FUNCTION BakiyeYeterlimi(pn_hesapNumarasi IN VARCHAR2,
     pn_miktar IN VARCHAR2,
                 pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

              ls_returncode VARCHAR2(3):='000';
BEGIN
  OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;
    log_at( 'Bakiye yeterli degil',Pkg_Hesap.Kullanilabilir_Bakiye_Al(pn_hesapNumarasi) , TO_NUMBER(pn_miktar,'99999999999.99') );
    
  IF (Pkg_Hesap.Kullanilabilir_Bakiye_Al(pn_hesapNumarasi) < TO_NUMBER(pn_miktar,'99999999999.99')) THEN
  	log_at('Bakiye yeterli degil',pn_hesapNumarasi,Pkg_Hesap.Kullanilabilir_Bakiye_Al(pn_hesapNumarasi),TO_NUMBER(pn_miktar,'99999999999.99'));
    RETURN '502';
  END IF;

  RETURN ls_returncode;

END;
-----------------------------------------------------------------------------------------
FUNCTION GetTranStatement(pn_txno IN VARCHAR2,
         pn_custno IN VARCHAR2,
         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  ln_txno        NUMBER;
  ln_islemkod          NUMBER;
  ld_tamamlanma       DATE;
  NoStatementFound      EXCEPTION;

BEGIN
 ln_txno:=TO_NUMBER(pn_txno);

 SELECT islem_kod,KAYIT_SISTEM_TARIHI
 INTO ln_islemkod,ld_tamamlanma
 FROM CBS_ISLEM
 WHERE numara=ln_txno;

 IF ln_islemkod NOT IN ('1203','3555','3556','4025','1202','7004','2130') THEN
    ls_returncode:='269';
    RAISE NoStatementFound;
 END IF;

 IF ln_islemkod='1203' THEN
  --INTERNAL MONEY TRANSFER
   OPEN pc_ref FOR
    SELECT TX_NO,
      TO_CHAR(ld_tamamlanma,'DD/MM/YYYY') TRAN_DATE,
      BORC_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)) BORCLU_ADI,
     BORC_EXTERNAL_HESAP,
     BORC_VERGI_NO,
     SUBSTR(PREFIX_ISTATISTIK_KODU,1,2) BORCLU_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO))) BBANK_NAME,
     ALACAK_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(ALACAK_HESAP_NO)) ALACAKLI_ADI,
     ALACAK_EXTERNAL_HESAP,
     ALACAK_VERGI_NO,
     SUBSTR(PREFIX_ISTATISTIK_KODU,3,2) ALACAK_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO)) ALACAK_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO))) ABANK_NAME,
     DOVIZ_KODU,
     TUTAR,
     ACIKLAMA,
     ISTATISTIK_KODU,
     PREFIX_ISTATISTIK_KODU,
     Pkg_Report.Number_To_Word_Eng( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     ln_islemkod,
     CHARGE_AMOUNT
    FROM CBS_VIRMAN_ISLEM
    WHERE  TX_NO=ln_txno;

 ELSIF ln_islemkod='7004' THEN
  --UTILITY PAYMENT
   OPEN pc_ref FOR
    SELECT TX_NO,
      TO_CHAR(COLLECTION_DATE,'DD/MM/YYYY'),
     ACCOUNT_NO,
     Pkg_Musteri.Sf_Musteri_Adi(CUSTOMER_NO) SENDER_NAME,
     LPAD(Pkg_Hesap.External_HesapNo_Al(ACCOUNT_NO),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(CUSTOMER_NO) RNN,
     SUBSTR(PREFIX_STATISTICAL_CODE,1,2),
     Pkg_Genelkz.GetOurBICCode(BRANCH) BIC_CODE,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(BRANCH)) BANK_NAME,
     COLLECTION_ACCOUNT_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(COLLECTION_ACCOUNT_NO)),
     LPAD(Pkg_Hesap.External_HesapNo_Al(COLLECTION_ACCOUNT_NO),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(COLLECTION_ACCOUNT_NO)),
     SUBSTR(PREFIX_STATISTICAL_CODE,3,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(COLLECTION_ACCOUNT_NO)),
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(COLLECTION_ACCOUNT_NO))),
     CURRENCY_CODE,
     COLLECTION_AMOUNT,
     EXPLANATION,
     STATISTICAL_CODE,
     PREFIX_STATISTICAL_CODE,
     Pkg_Report.Number_To_Word_Eng( COLLECTION_AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( COLLECTION_AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     ln_islemkod,
     '-'
    FROM CBS_VW_COLLECTIONS
    WHERE  TX_NO=ln_txno
    AND CUSTOMER_NO=pn_custno;

    ELSIF ln_islemkod='2130' THEN
  --CARD PAYMENT
   OPEN pc_ref FOR
    SELECT TX_NO,
      TO_CHAR(PAYMENT_DATE,'DD/MM/YYYY'),
     FROM_ACCOUNT_NO,
     FROM_NAME,
     LPAD(Pkg_Hesap.External_HesapNo_Al(FROM_ACCOUNT_NO),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(FROM_CUSTOMER_NO) RNN,
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO)),
     FROM_BANK_CODE,
     Pkg_Hesap.GetBankHQName(FROM_BANK_CODE) BANK_NAME,
     '-',
     TO_CARD_CUSTOMER_NAME,
     TO_CARD_NO,
     Pkg_Musteri.Sf_VergiNo_Al(TO_CARD_CUSTOMER_NO),
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(TO_CARD_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(TO_CARD_CUSTOMER_NO)),
     '-',--toBankCode,
     '-',--ToBankName
     CURRENCY_CODE,
     AMOUNT,
     PAYMENT_DESCRIPTION,
     '-',--STATISTICAL_CODE,
     '-',--PREFIX_STATISTICAL_CODE,
     Pkg_Report.Number_To_Word_Eng( AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     ln_islemkod,
     '-'
    FROM CBS_CARD_PAYMENT
    WHERE  TX_NO=ln_txno
    AND FROM_CUSTOMER_NO=pn_custno;

 ELSIF ln_islemkod='3555' or ln_islemkod='3556' THEN
 --CLEARING
  OPEN pc_ref FOR
      SELECT  YARATAN_TX_NO,
     TO_CHAR(MATURITY_DATE,'DD/MM/YYYY'),
     ' ' BORC_HESAPNO,
     Pkg_Musteri.Sf_Musteri_Adi(pn_custno),
     pkg_hesap.External_HesapNo_Al(FROM_ACCOUNT),
     ' ' FROM_RNN,
     ' ' ,
     ' ',
     ' ' ,
     ' ' ALACAK_HESAP_NO,
     TO_NAME,
     TO_ACCOUNT_EXTERNAL_NUMBER,
     ' ' TO_RNN,
     ' ' ,
     TO_BANK_BIC,
        Pkg_Hesap.GetBankName(TO_BANK_BIC) TO_BANK_BIC,
     ' ' TRAN_CURR,
     AMOUNT,--TRAN_AMOUNT,
     EXPLANATION,
     CODE_OF_PAYMENT,
     ' ' ISTATISTIK_KOD,
     Pkg_Report.Number_To_Word_Eng(AMOUNT, ' ') TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus(AMOUNT, ' ') TUTAR_YAZI_ILE,
     CODE_OF_PAYMENT,
     ' ' DOC_NUM,
     ln_islemkod,
     CHARGE_AMOUNT
  FROM cbs_vw_clearing
  WHERE  YARATAN_TX_NO=ln_txno;
  --AND TO_NUMBER(pn_custno)=DECODE(URUN_TUR_KOD,'INCOMING',Pkg_Hesap.GetMusteriNoFromExternal(TO_ACCOUNT_EXTERNAL_NUMBER),Pkg_Hesap.GetMusteriNoFromExternal(FROM_ACCOUNT_EXTERNAL_NUMBER));

 ELSIF ln_islemkod IN ('4025') THEN
 --FX BUY
  OPEN pc_ref FOR
   SELECT  TX_NO,
     TO_CHAR(ISLEM_TARIHI,'DD/MM/YYYY'),
     MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(MUSTERI_HESAP_NO),
     MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,3,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(MUSTERI_HESAP_NO))) BBANK_NAME,
     DTH_MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(DTH_MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(MUSTERI_HESAP_NO),
     DTH_MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,1,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(DTH_MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(DTH_MUSTERI_HESAP_NO))) BBANK_NAME,
     DOVIZ_KODU,
     DOVIZ_TUTARI,
     ACIKLAMA,
     '-',
     '-',
--does not exist     ISTATISTIK_KODU_ALIS,
--      ISTATISTIK_KODU_SATIS,
     Pkg_Report.Number_To_Word_Eng( DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus( DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE,
     '' DOC_BCLASS,
     TX_NO DOC_NUM,
     ln_islemkod,
     KUR,
     Pkg_Kur.yuvarla(Pkg_Genel.LC_al,DOVIZ_TUTARI*KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
     ISLEM_SUBE
  FROM CBS_DTH_DOVIZ_SATIS_ISLEM
  WHERE  TX_NO=ln_txno;

 ELSIF ln_islemkod IN ('1202') THEN
 --FX SELL
  OPEN pc_ref FOR
   SELECT  TX_NO,
     TO_CHAR(Pkg_Int_Account.GetTxDate(TX_NO),'DD/MM/YYYY'),
     BORC_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)),
     LPAD(BORC_EXTERNAL_HESAP,9,'0'),
     BORC_VERGI_NO,
     SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,3,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO))) BBANK_NAME,
     ALACAK_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(ALACAK_HESAP_NO)),
     LPAD(ALACAK_EXTERNAL_HESAP,9,'0'),
     ALACAK_VERGI_NO,
     SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,1,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO))) BBANK_NAME,
     DOVIZ_KODU,
     TUTAR,
     ACIKLAMA,
--     ISTATISTIK_KODU_ALIS,
--     ISTATISTIK_KODU_SATIS,
                    '-',
     '-',
     Pkg_Report.Number_To_Word_Eng( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE,
     '' DOC_BCLASS,
     TX_NO DOC_NUM,
     ln_islemkod,
     KUR,
     Pkg_Kur.yuvarla(Pkg_Genel.LC_al,TUTAR*KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
     '' ISLEM_SUBE
  FROM CBS_DTH_TL_ODEME_ISLEM
  WHERE  TX_NO=ln_txno;

 END IF;


 RETURN ls_returncode;

EXCEPTION
   WHEN NoStatementFound THEN
      OPEN pc_ref FOR
   SELECT 'NOTFOUND' FROM dual;
      RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------------
FUNCTION GetIntStatementHeader(pn_hesapno IN VARCHAR2,
           pd_startdate IN VARCHAR2,
          pd_enddate IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
BEGIN


 OPEN pc_ref FOR
   SELECT
   TO_CHAR(b.hesap_no) hesap_no,
   EXTERNAL_HESAP_NO,
   b.musteri_no musteri_no,
   Pkg_Musteri.sf_musteri_adi(musteri_no) isim_unvan ,
   Pkg_Musteri.sf_adres_al(b.musteri_no) adres,
   b.urun_tur_kod || ' \ ' ||urun_sinif_kod hesap_turu,
   DOVIZ_KODU hesap_doviz_kodu,
   b.modul_tur_kod,
   b.urun_tur_kod,
   b.urun_sinif_kod,
   b.durum_kodu,
         b.sube_kodu,
   SUBSTR(Pkg_Genel.bolum_adi_al(b.sube_kodu),1,50)  bolum_adi,
   Pkg_Musteri.Sf_VergiNo_Al(b.musteri_no) rnn
  FROM cbs_vw_hesap_izleme b
  WHERE b.hesap_no=pn_hesapno;

    RETURN '000';
END;
------------------------------------------------------------------------------------------------
FUNCTION GetIntStatementBalance(pn_hesapno IN VARCHAR2,
           pd_startdate IN VARCHAR2,
          pd_enddate IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ln_credit  NUMBER;
 ln_debit  NUMBER;
 ls_doviz_kodu      VARCHAR2(3) ;
 ld_startdate      VARCHAR2(8);
 ln_devirbakiye      NUMBER;
BEGIN
 IF TO_DATE(pd_startdate,'YYYYMMDD')>Pkg_Muhasebe.Banka_Tarihi_Bul THEN
  ld_startdate:=TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD');
 ELSE
  ld_startdate:=pd_startdate;
 END IF;

 SELECT
  SUM(CASE WHEN satir_dv_tutar > 0 THEN satir_dv_tutar ELSE 0   END) credit,
  SUM(CASE WHEN satir_dv_tutar < 0 THEN satir_dv_tutar ELSE 0   END) debit
 INTO
  ln_credit,ln_debit
 FROM cbs_vw_fis_satir_vsziz
 WHERE satir_hesap_numara=pn_hesapno
 AND FIS_TUR='G'
 AND fis_muhasebelestigi_tarih BETWEEN TO_DATE(ld_startdate,'YYYYMMDD') AND TO_DATE(NVL(pd_enddate,'20990101'),'YYYYMMDD');

 ls_doviz_kodu:=Pkg_Hesap.HesaptanDovizKoduAl(pn_hesapno);

 ln_devirbakiye:=Pkg_Vadehesap_Rapor.sf_devirbakiyebul(pn_hesapno,TO_CHAR(TO_DATE(ld_startdate,'YYYYMMDD'),'DD/MM/YYYY'));

 OPEN pc_ref FOR
  SELECT ln_devirbakiye  devir_bakiye,
   Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu, Pkg_Genel.LC_AL, MAX(fis_muhasebelestigi_tarih), ln_devirbakiye, 1, NULL, NULL, 'N', 'A') devir_bakiye_lc_prev,
   Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu, Pkg_Genel.LC_AL, TO_DATE(ld_startdate,'YYYYMMDD'), ln_devirbakiye , 1, NULL, NULL, 'N', 'A')  devir_bakiye_lc_today,
   Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu, Pkg_Genel.LC_AL, TO_DATE(ld_startdate,'YYYYMMDD'), ln_devirbakiye , 1, NULL, NULL, 'N', 'A')- Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu, Pkg_Genel.LC_AL, MAX(fis_muhasebelestigi_tarih), ln_devirbakiye , 1, NULL, NULL, 'N', 'A') dif,
   ln_credit,ln_debit
  FROM cbs_vw_fis_satir_vsziz
  WHERE fis_tur='G'
  AND satir_hesap_numara=pn_hesapno
  AND fis_muhasebelestigi_tarih<TO_DATE(ld_startdate,'YYYYMMDD');

 RETURN '000';
END;
------------------------------------------------------------------
FUNCTION JoinAccounts (ps_custno VARCHAR2,
              ps_relcustno VARCHAR2,
             ps_relaccounts VARCHAR2,
          ps_channelcd VARCHAR2,
        ps_trantype VARCHAR2,
        pc_ref OUT   cursorreferencetype) RETURN VARCHAR2
   IS
    ln_count NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 AccountException    EXCEPTION;
BEGIN

   OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
   SELECT COUNT(*)
     INTO ln_count
     FROM CBS_JOIN_ACCOUNT
     WHERE REL_ACCOUNT=TO_NUMBER(ps_relaccounts)
    AND CUST_NO=TO_NUMBER(ps_custno)
    AND REL_CUST_NO=TO_NUMBER(ps_relcustno);

 IF(ln_count!=0) THEN
 RAISE AccountException;
 END IF;

  INSERT INTO CBS_JOIN_ACCOUNT
  (CUST_NO, REL_CUST_NO, REL_ACCOUNT,
   STATUS_CD, BIRTH_DATE, CHANNEL_CD,TRAN_TYPE)

   VALUES
   (TO_NUMBER(ps_custno),TO_NUMBER(ps_relcustno),TO_NUMBER(ps_relaccounts),
   'sNEW',SYSDATE,ps_channelcd,ps_trantype);

   RETURN ls_returncode;

EXCEPTION
 WHEN AccountException THEN
 OPEN pc_ref FOR SELECT '-' FROM dual;
  ls_returncode:= '030';
  RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------------
FUNCTION GetCustomerJoinAccounts (ps_custno VARCHAR2,
               ps_channelcd VARCHAR2,
             pc_ref OUT   cursorreferencetype) RETURN VARCHAR2
   IS
    ln_count NUMBER;
 ls_returncode  VARCHAR2 (3)  := '000';
 DeleteAccountException    EXCEPTION;
BEGIN

 SELECT COUNT(*)
 INTO ln_count
 FROM CBS_JOIN_ACCOUNT
  WHERE CUST_NO=TO_NUMBER(ps_custno)
  AND CHANNEL_CD=ps_channelcd;

 IF ln_count=0 THEN
    RAISE DeleteAccountException;
 END IF;

  OPEN pc_ref FOR
    SELECT Pkg_Musteri.Sf_Musteri_Adi(ps_custno),
    CUST_NO,
    REL_CUST_NO,
   REL_ACCOUNT,
   STATUS_CD,
   BIRTH_DATE,
   CHANNEL_CD,
   TRAN_TYPE
  FROM CBS_JOIN_ACCOUNT
  WHERE CUST_NO=TO_NUMBER(ps_custno)
  AND CHANNEL_CD=ps_channelcd;

  RETURN ls_returncode;

EXCEPTION
 WHEN DeleteAccountException THEN
  ls_returncode:= '031';
  RETURN ls_returncode;
 END;
------------------------------------------------------------------------------------------------
FUNCTION DeleteCustomerJoinAccounts (ps_custno  IN VARCHAR2,
           ps_relcustno IN VARCHAR2,
          ps_relaccountno IN VARCHAR2,
                 ps_channelcd IN VARCHAR2,
          ps_newstatus IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 ls_returncode  VARCHAR2 (3)  := '000';
BEGIN
  OPEN pc_ref FOR SELECT '-' FROM DUAL;
 IF ps_newstatus='D' THEN

  UPDATE CBS_JOIN_ACCOUNT
   SET STATUS_CD='sDELETE'
   WHERE CUST_NO=TO_NUMBER(ps_custno)
   AND   REL_CUST_NO=TO_NUMBER(ps_relcustno)
   AND   REL_ACCOUNT=TO_NUMBER(ps_relaccountno)
   AND   CHANNEL_CD=ps_channelcd;

 ELSIF ps_newstatus='A' THEN
  UPDATE CBS_JOIN_ACCOUNT
   SET STATUS_CD='sACTIV'
   WHERE CUST_NO=TO_NUMBER(ps_custno)
   AND   REL_CUST_NO=TO_NUMBER(ps_relcustno)
   AND   REL_ACCOUNT=TO_NUMBER(ps_relaccountno)
   AND   CHANNEL_CD=ps_channelcd;
 END IF;

   RETURN ls_returncode;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     RETURN '031';
END;
------------------------------------------------------------------------------------------------
FUNCTION GetExtAccountDetails(pn_extaccount_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS ls_returncode VARCHAR2(3):='000';
BEGIN

  OPEN pc_ref FOR
  SELECT    hesap_no,
     sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
   trim(doviz_kodu),
   kisa_isim,
   ISIM_UNVAN,
   EXTERNAL_HESAP_NO,
   Pkg_Musteri.Sf_Musteri_Adi(musteri_no) MUSTERI_ADI,
   Pkg_Hesap.GetIRSCode(a.DK_GRUP_KOD),
   Pkg_Hesap.GetSECOCode(a.DK_GRUP_KOD)
   FROM     CBS_vw_hesap_izleme a
   WHERE    EXTERNAL_HESAP_NO = pn_extaccount_No ;

  RETURN ls_returncode;
EXCEPTION WHEN OTHERS THEN
 Log_At(SQLERRM);
 END;
------------------------------------------------------------------------------------------------
FUNCTION SumLoanAmount(pn_customerno IN VARCHAR2,
         pc_ref OUT CursorReferenceType) RETURN VARCHAR2

IS ls_returncode VARCHAR2(3):='000';

BEGIN
 OPEN pc_ref FOR
    SELECT DOVIZ_KODU ,
         SUM(ABS(NVL(bakiye,0)))  BAKIYE,
        Pkg_Kur.yuvarla(doviz_kodu,SUM( Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(BIRIKMIS_FAIZ_TUTARI,0)) +  ABS(NVL(GECENYIL_FAIZ_TUTARI,0))) )) BIRIKMIS_FAIZ
    FROM  CBS_VW_KREDI_HESAP_IZLEME
 WHERE MUSTERI_NO=TO_NUMBER(pn_customerno)
 GROUP BY DOVIZ_KODU
 ORDER BY DOVIZ_KODU;

 RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN
      Log_At(SQLERRM);
END;
----------------------------------------------------------------
FUNCTION GetRetailLoans(pn_customerno IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2

  IS
  ls_returncode VARCHAR2(3):='000';
  ln_count NUMBER;
  NoInfoFound EXCEPTION;

BEGIN

 SELECT COUNT(*)
 INTO ln_count
    FROM  CBS_VW_BIREY_KREDI_IZLEME
 WHERE MUSTERI_NO=TO_NUMBER(pn_customerno);

 IF ln_count=0 THEN
    RAISE NoInfoFound;
 END IF;

 OPEN pc_ref FOR

    SELECT HESAP_NO, MUSTERI_NO, UNVAN, DOVIZ_KODU, ACILIS_TUTAR, DURUM_KODU,
     SUBE_KODU||' '|| Pkg_Genel.bolum_adi_al(SUBE_KODU) SUBE, BAKIYE, TO_CHAR(KREDI_VADE,'YYYYMMDD'),
     KREDI_KULLANDIRIM_KODU, TAKSIT_TUTARI, TAKSIT_ANAPARA, TAKSIT_FAIZ,STATUS, TO_CHAR(ACILIS_TARIHI,'YYYYMMDD')
    FROM  CBS_VW_BIREY_KREDI_IZLEME
 WHERE MUSTERI_NO=TO_NUMBER(pn_customerno)
 ORDER BY KREDI_VADE;

 RETURN ls_returncode;

 EXCEPTION
 WHEN NoInfoFound THEN
    OPEN pc_ref FOR SELECT '-' FROM dual;
  ls_returncode:= '510';
  RETURN ls_returncode;
END;
----------------------------------------------------------------
FUNCTION GetLoansInfo(pn_accountno IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2

IS ls_returncode VARCHAR2(3):='000';

BEGIN
 OPEN pc_ref FOR
    SELECT HESAP_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV,
     TO_CHAR(VADE_TARIH,'YYYYMMDD'), KAL_ANAPARA, TAHSIL_EDILECEK_TAKSIT,
     DURUM_KODU, TO_CHAR(ODEME_TARIHI,'YYYYMMDD')
    FROM  CBS_HESAP_KREDI_TAKSIT
 WHERE HESAP_NO=TO_NUMBER(pn_accountno)
 ORDER BY VADE_TARIH;

 RETURN ls_returncode;

 EXCEPTION WHEN OTHERS THEN
      Log_At(SQLERRM);
END;
----------------------------------------------------------------
FUNCTION GetTxStatement(pn_txno IN VARCHAR2,
       pn_custno IN VARCHAR2,
       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  ln_txno        NUMBER;
  ls_trancd         VARCHAR2(15);
  ld_tamamlanma       DATE;
  NoStatementFound      EXCEPTION;

BEGIN
 ln_txno:=TO_NUMBER(pn_txno);

 SELECT TRANCD
 INTO ls_trancd
 FROM corpint.tbl_txtodo
 WHERE TX_NO=ln_txno;

 IF ls_trancd NOT IN ('CLEARING','B2OBHVL','EXCHNGBUY','EXCHNGSELL') THEN
    ls_returncode:='269';
    RAISE NoStatementFound;
 END IF;

 IF ls_trancd='CLEARING' THEN
  --CLEARING
   OPEN pc_ref FOR
    SELECT TX_NO,
      field3 TRAN_DATE,
      '',
     FIELD4,
     Pkg_Hesap.External_HesapNo_Al(FIELD1),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1))),
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,0))))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,0)))) BORCLU_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD1)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD1))) BBANK_NAME,
     FIELD8,
     '' ALACAKLI_ADI,
     FIELD7 ALACAK_EXTERNAL_HESAP,
     FIELD14 ALACAK_VERGI_NO,
     --FIELD16 ALACAK_IIK,
     FIELD6 ALACAK_BANKA,
     Pkg_Hesap.GetBankHQName(FIELD6) BANK_NAME,
     --FIELD20 DOVIZ_KODU,
     FIELD9 TUTAR,
     FIELD10 ACIKLAMA,
     --SUBSTR(FIELD17,1,3) ISTATISTIK_KODU,
     '' PREFIX_ISTATISTIK_KODU,
     --Pkg_Report.Number_To_Word_Eng( FIELD9, FIELD20) TUTAR_YAZI_ILE_ENG,
           --Pkg_Report.Number_To_Word_Rus( FIELD9, FIELD20) TUTAR_YAZI_ILE_RUS,
     '' BCLASS,
     TX_NO DOC_NO,
     ls_trancd
    FROM corpint.TBL_TXTODO
    WHERE  TX_NO=ln_txno;

 ELSIF ls_trancd='B2OBHVL' THEN
  --UTILITY PAYMENT
   OPEN pc_ref FOR
    SELECT TX_NO,
      TO_CHAR(MAKEDATE,'DD/MM/YYYY') TRAN_DATE,
      FIELD1,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(FIELD1)) BORCLU_ADI,
     Pkg_Hesap.External_HesapNo_Al(FIELD1),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1))),
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,'0'))))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,'0')))) BORCLU_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD1)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD1))) BBANK_NAME,
     '' ALACAK_HESAP_NO,
     FIELD10 ALACAKLI_ADI,
     FIELD2 ALACAK_EXTERNAL_HESAP,
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(FIELD2))ALACAK_VERGI_NO,
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(FIELD2)))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(FIELD2))) ALACAK_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(Pkg_Hesap.GetHesapNoFromExternal(FIELD2,FIELD5))) ALACAK_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(Pkg_Hesap.GetHesapNoFromExternal(FIELD2,FIELD5)))) ABANK_NAME,
     FIELD5 DOVIZ_KODU,
     FIELD3 TUTAR,
     FIELD4 ACIKLAMA,
     SUBSTR(FIELD12,1,3) ISTATISTIK_KODU,
     '' PREFIX_ISTATISTIK_KODU,
     Pkg_Report.Number_To_Word_Eng( TO_NUMBER(FIELD3,'99999999999.99'), FIELD5) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( TO_NUMBER(FIELD3,'99999999999.99'), FIELD5) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     'B2OBHVL'
    FROM corpint.TBL_TXTODO
    WHERE  TX_NO=ln_txno;

    ELSIF ls_trancd='CARDPYM' THEN
  --CARD PAYMENT
   OPEN pc_ref FOR
    SELECT TX_NO,
      TO_CHAR(MAKEDATE,'DD/MM/YYYY'),
     FIELD1 FROM_ACCOUNT_NO,
     FIELD5 FROM_NAME,
     LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1))) RNN,
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1))))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1)))),
     Pkg_Hesap.GetBankCode(Pkg_Hesap.HesapSubeAl(FIELD1))  FROM_BANK_CODE,
     Pkg_Hesap.GetBankHQName(Pkg_Hesap.GetBankCode(Pkg_Hesap.HesapSubeAl(FIELD1))) BANK_NAME,
     '-',
     FIELD5,
     FIELD2,
     '-',
     '-',
     '-',--toBankCode,
     '-',--ToBankName
     --FIELD20 CURRENCY_CODE,
     FIELD9 AMOUNT,
     FIELD3 PAYMENT_DESCRIPTION,
     '-',--STATISTICAL_CODE,
     '-',--PREFIX_STATISTICAL_CODE,
     --Pkg_Report.Number_To_Word_Eng( TO_NUMBER(FIELD9,'99999999999.99'), FIELD20) TUTAR_YAZI_ILE_ENG,
           --Pkg_Report.Number_To_Word_Rus( TO_NUMBER(FIELD9,'99999999999.99'), FIELD20) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     ls_trancd
    FROM corpint.TBL_TXTODO
    WHERE  TX_NO=ln_txno;

 ELSIF ls_trancd='B2BHVL' THEN
 --CLEARING
  OPEN pc_ref FOR
   SELECT  TX_NO
  FROM corpint.TBL_TXTODO
  WHERE  TX_NO=ln_txno;

 ELSIF ls_trancd IN ('UTILPAY') THEN
 --FX BUY
  OPEN pc_ref FOR
   SELECT  TX_NO,
     TO_CHAR(MAKEDATE,'DD/MM/YYYY'),
     FIELD1,
     FIELD2 SENDER_NAME,
     LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD1),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD1))) RNN,
     '',
     Pkg_Hesap.GetBankCode(FIELD1) BIC_CODE,
     Pkg_Hesap.GetBankHQName(Pkg_Hesap.GetBankCode(FIELD1)) BANK_NAME,
     '' COLLECTION_ACCOUNT_NO,
     '',
     '',
     '',
     '',
     '',
     '',
     --FIELD20,
     FIELD9,
     FIELD4,
     '' STATISTICAL_CODE,
     '',
     --Pkg_Report.Number_To_Word_Eng( FIELD9, FIELD20) TUTAR_YAZI_ILE_ENG,
           --Pkg_Report.Number_To_Word_Rus( FIELD9, FIELD20) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     TX_NO DOC_NO,
     ls_trancd
  FROM corpint.TBL_TXTODO
  WHERE  TX_NO=ln_txno;

 ELSIF ls_trancd IN ('EXCHNGBUY','EXCHNGSELL') THEN
 --FX SELL
  OPEN pc_ref FOR
   SELECT  TX_NO,
     TO_CHAR(MAKEDATE,'DD/MM/YYYY'),
     FIELD2,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD2))),
     LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD2),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD2))),
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD2),9,'0'))))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD2),9,'0')))),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD2)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD2))) BBANK_NAME,
     FIELD6 DTH_MUSTERI_NO,
     Pkg_Musteri.Sf_Musteri_Adi(FIELD6),
     LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD6),9,'0'),
     Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(Pkg_Hesap.External_HesapNo_Al(FIELD6))),
     Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD6),9,'0'))))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(FIELD6),9,'0')))),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD6)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(FIELD6))) BBANK_NAME,
     FIELD3 DOVIZ_KODU,
     FIELD9 DOVIZ_TUTARI,
     FIELD8 ACIKLAMA,
     '' ISTATISTIK_KODU_ALIS,
     '' ISTATISTIK_KODU_SATIS,
     Pkg_Report.Number_To_Word_Eng( TO_NUMBER(FIELD9,'99999999999.99'), FIELD3) TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus( TO_NUMBER(FIELD9,'99999999999.99'), FIELD3) TUTAR_YAZI_ILE,
     '' DOC_BCLASS,
     TX_NO DOC_NUM,
     ls_trancd,
     FIELD5 KUR,
     FIELD11 TAHSIL_ADILEN_TOPLAM_TUTAR,
     Pkg_Hesap.HesapSubeAl(FIELD2) ISLEM_SUBE
  FROM corpint.TBL_TXTODO
  WHERE  TX_NO=ln_txno;

 END IF;

      RETURN ls_returncode;

EXCEPTION
   WHEN NoStatementFound THEN
      OPEN pc_ref FOR
   SELECT 'NOTFOUND' FROM dual;
      RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------------
FUNCTION GetNonResidentDetail(pn_customerno IN VARCHAR2,
          pc_ref OUT CursorReferenceType) RETURN VARCHAR2

  IS
  ls_returncode VARCHAR2(3):='000';
  ln_count NUMBER;
  NoInfoFound EXCEPTION;

BEGIN

 /*SELECT COUNT(*)
 INTO ln_count
    FROM  CBS_VW_CLEARING
 WHERE TO_RNN=Pkg_Musteri.Sf_VergiNo_Al(pn_customerno) AND
    FROM_IRS='2';

 IF ln_count=0 THEN
    RAISE NoInfoFound;
 END IF;

 OPEN pc_ref FOR

    SELECT TX_NO, REF_NO, VALUE_DATE, MSG_KIND,
     MSG_STATUS, DETAIL_ID, TRAN_CURR, TRAN_AMOUNT,
     FROM_ACCOUNT, FROM_NAME, TO_ACCOUNT
    FROM  CBS_VW_CLEARING
 WHERE TO_RNN=Pkg_Musteri.Sf_VergiNo_Al(pn_customerno) AND
    FROM_IRS='2'
 ORDER BY VALUE_DATE;*/

 RETURN ls_returncode;

 EXCEPTION
 WHEN NoInfoFound THEN
    OPEN pc_ref FOR SELECT '-' FROM dual;
  ls_returncode:= '511';
  RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------
FUNCTION ExtAccountControl(pn_currency      IN VARCHAR2,
          pn_accountno  IN VARCHAR2,
                  pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
 ls_count NUMBER:=0;

BEGIN

 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    SELECT COUNT(*)
 INTO ls_count
 FROM CBS_vw_hesap_izleme
 WHERE HESAP_NO = TO_NUMBER(pn_accountno)
 AND DOVIZ_KODU=pn_currency
 AND DURUM_KODU = 'A';

 IF(ls_count = 0) THEN

    ls_returncode:='432';
 END IF;

    RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION GetCustTranAccounts(pn_musteri_no IN VARCHAR2,
         ps_currcode IN VARCHAR2,
        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  noAccoutFound        EXCEPTION;
  ls_account_count NUMBER:=0;
BEGIN
     OPEN pc_ref FOR
  SELECT SYSDATE FROM dual;
 log_at('ACCOUNTS06');
   SELECT COUNT(*)
   INTO ls_account_count
   FROM CBS_vw_hesap_izleme a
   WHERE musteri_no = TO_NUMBER(pn_musteri_no)
   AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
   AND DOVIZ_KODU=ps_currcode;

   IF (ls_account_count= 0) THEN
   RAISE noAccoutFound;
   END IF;


  OPEN pc_ref FOR
   SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
      ISIM_UNVAN,
      sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
      HESAP_NO,
      DOVIZ_KODU,
      NVL(BAKIYE,0),
      NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
      1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,kisa_isim,
      external_hesap_no,
      Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = TO_NUMBER(pn_musteri_no)
       AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
    AND DOVIZ_KODU=ps_currcode
  UNION
  SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
      ISIM_UNVAN,
      sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
      HESAP_NO,
      DOVIZ_KODU,
      NVL(BAKIYE,0),
      NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
      2 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,kisa_isim,
      external_hesap_no,
      Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
    FROM CBS_vw_hesap_izleme a
    WHERE hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
             WHERE CUST_NO=TO_NUMBER(pn_musteri_no) AND STATUS_CD='sACTIV' AND TRAN_TYPE ='sTRAN')
       AND durum_kodu = 'A'
   AND modul_tur_kod= 'CURRENT'
   AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
    AND DOVIZ_KODU=ps_currcode
    ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;
  EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '503';
 RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------------------------------------
FUNCTION ArbitrageControl(ps_customerid IN VARCHAR2,
           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
        ls_returncode VARCHAR2(3):='000';
  ls_count NUMBER:=0;
  BEGIN

 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

 SELECT  COUNT(DISTINCT(a.DOVIZ_KODU))
 INTO ls_count
 FROM cbs_vw_hesap_izleme a,
      CBS_DOVIZ_KODLARI dk
 WHERE musteri_no = ps_customerid
 AND durum_kodu = 'A'
 AND modul_tur_kod= 'CURRENT'
 AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
 AND a.DOVIZ_KODU=DECODE('FC','LC',Pkg_Genel.LC_al,a.DOVIZ_KODU)
 AND a.DOVIZ_KODU<>DECODE('FC','FC',Pkg_Genel.LC_al,'ALL')
 AND dk.DOVIZ_KODU = a.DOVIZ_KODU;

 IF (ls_count < 2) THEN
    RETURN '350';
 END IF;

   RETURN ls_returncode;
 END;
-------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------
FUNCTION ExtAccControl(pn_extaccno      IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
 ls_count NUMBER:=0;
 ls_error VARCHAR2(1);

BEGIN

 OPEN pc_ref FOR
 SELECT SYSDATE FROM dual;

    ls_error:=Pkg_Tx3555.External_hesap_dogrumu(pn_extaccno);

 IF ls_error='H' THEN

    ls_returncode:='432';
 END IF;

    RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION GetAllCustomerAccounts(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
IS
ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;

BEGIN
log_at('ACCOUNTS07');
  OPEN pc_ref FOR
      SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
         MUSTERI_NO,
       ISIM_UNVAN,
       sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
       HESAP_NO,
       DOVIZ_KODU,
       NVL(BAKIYE,0),
       NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
       1 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
     FROM CBS_vw_hesap_izleme a
     WHERE musteri_no = pn_musteri_No AND
        durum_kodu = 'A' AND
     modul_tur_kod= 'CURRENT' AND
     urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL')
  UNION
   SELECT   'Related Current Accounts' modul_tur_kod,
         MUSTERI_NO,
       ISIM_UNVAN,
       sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
       HESAP_NO,
       DOVIZ_KODU,
       NVL(BAKIYE,0),
       NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
       6 siralama ,TO_CHAR(vade_tarihi ,'YYYYMMDD')  vade_tarihi,KISA_ISIM,ROUND(BIRIKMIS_FAIZ_NEG,2)
     FROM CBS_vw_hesap_izleme a
     WHERE hesap_no IN (SELECT  REL_ACCOUNT  FROM CBS_JOIN_ACCOUNT
               WHERE CUST_NO=pn_musteri_no AND STATUS_CD='sACTIV' AND TRAN_TYPE IN ('sVIEW','sTRAN')
         ) AND
        durum_kodu = 'A' AND
     modul_tur_kod= 'CURRENT' AND
     urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLETERAL');

  RETURN ls_returncode;
  EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '503';
 RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------------------------

FUNCTION GetDailyFXandB2OBStatement(pn_islemkod IN VARCHAR2,
		 							ps_channel_code IN VARCHAR2,
               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  ln_txno        NUMBER;
  ln_islemkod          NUMBER;
  ld_tamamlanma       DATE;
  NoStatementFound      EXCEPTION;

BEGIN

 IF pn_islemkod NOT IN ('1203','4025') THEN
    ls_returncode:='269';
    RAISE NoStatementFound;
 END IF;

 IF pn_islemkod='1203' THEN
  --INTERNAL MONEY TRANSFER
   OPEN pc_ref FOR
     SELECT i.TX_NO,
      --TO_CHAR(ld_tamamlanma,'DD/MM/YYYY') TRAN_DATE,
     pkg_int_account.GetB2OBStatementDate(i.TX_NO),
      i.BORC_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(i.BORC_HESAP_NO)) BORCLU_ADI,
     i.BORC_EXTERNAL_HESAP,
     i.BORC_VERGI_NO,
     SUBSTR(i.PREFIX_ISTATISTIK_KODU,1,2) BORCLU_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.BORC_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.BORC_HESAP_NO))) BBANK_NAME,
     i.ALACAK_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(i.ALACAK_HESAP_NO)) ALACAKLI_ADI,
     i.ALACAK_EXTERNAL_HESAP,
     i.ALACAK_VERGI_NO,
     SUBSTR(i.PREFIX_ISTATISTIK_KODU,3,2) ALACAK_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.ALACAK_HESAP_NO)) ALACAK_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.ALACAK_HESAP_NO))) ABANK_NAME,
     i.DOVIZ_KODU,
     i.TUTAR,
     i.ACIKLAMA,
     i.ISTATISTIK_KODU,
     i.PREFIX_ISTATISTIK_KODU,
     Pkg_Report.Number_To_Word_Eng( i.TUTAR, i.DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( i.TUTAR, i.DOVIZ_KODU) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     i.TX_NO DOC_NO,
     pn_islemkod,
     i.CHARGE_AMOUNT
    FROM CBS_VIRMAN_ISLEM i,
         cbs_islem e
             WHERE  i.TX_NO=e.NUMARA
    and    e.DURUM='P'
             and  i.TX_NO in (SELECT NUMARA FROM CBS_ISLEM WHERE DURUM='P' and  KAYIT_TARIH=trunc(sysdate-1) and islem_kod=pn_islemkod)
    and e.KAYIT_KULLANICI_KODU='CINT_CALLER'
	and	pkg_hesap.HesaptanMusteriNoAl(i.BORC_HESAP_NO) in (select distinct customer_id from corpint.tbl_person_auth a, corpint.tbl_person b where CHANNEL_CD like '%'||ps_channel_code||'%' and a.person_id=b.person_id);

 ELSIF pn_islemkod IN ('4025') THEN
 --FX BUY
  OPEN pc_ref FOR
   SELECT  i.TX_NO,
     TO_CHAR(i.ISLEM_TARIHI,'DD/MM/YYYY'),
     i.MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(i.MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(i.MUSTERI_HESAP_NO),
     i.MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,3,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.MUSTERI_HESAP_NO))) BBANK_NAME,
     i.DTH_MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(i.DTH_MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(i.MUSTERI_HESAP_NO),
     i.DTH_MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,1,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.DTH_MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.DTH_MUSTERI_HESAP_NO))) BBANK_NAME,
     i.DOVIZ_KODU,
     i.DOVIZ_TUTARI,
     i.ACIKLAMA,
     '-',
     '-',
--does not exist     ISTATISTIK_KODU_ALIS,
--      ISTATISTIK_KODU_SATIS,
     Pkg_Report.Number_To_Word_Eng( i.DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus( i.DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE,
     '' DOC_BCLASS,
     i.TX_NO DOC_NUM,
     pn_islemkod,
     i.KUR,
     Pkg_Kur.yuvarla(Pkg_Genel.LC_al,i.DOVIZ_TUTARI*i.KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
     i.ISLEM_SUBE
  FROM CBS_DTH_DOVIZ_SATIS_ISLEM i, cbs_islem e
  WHERE  i.ISLEM_TARIHI=trunc(sysdate)-1
  and e.KAYIT_KULLANICI_KODU='CINT_CALLER'
  and i.TX_NO=e.NUMARA
  and MUSTERI_NO in (select distinct customer_id from corpint.tbl_person_auth a, corpint.tbl_person b where CHANNEL_CD like '%'||ps_channel_code||'%' and a.person_id=b.person_id);

 END IF;

 RETURN ls_returncode;

EXCEPTION
   WHEN NoStatementFound THEN
      OPEN pc_ref FOR
   SELECT 'NOTFOUND' FROM dual;
      RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION GetB2OBStatementDate(pn_txno IN VARCHAR2) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  ln_txno        NUMBER;
  ln_islemkod          NUMBER;
  ld_tamamlanma       varchar2(10);
  NoStatementFound      EXCEPTION;

BEGIN
 ln_txno:=TO_NUMBER(pn_txno);

      SELECT to_char(KAYIT_TARIH,'DD/MM/YYYY')
   into  ld_tamamlanma
   FROM CBS_ISLEM
   WHERE NUMARA=ln_txno
   and DURUM='P'
   and islem_kod='1203';

 RETURN ld_tamamlanma;

EXCEPTION
   WHEN NoStatementFound THEN
         RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION FXandB2OBStatementInquiry(pn_islemkod IN VARCHAR2,
									pd_startdate    IN VARCHAR2,
									pd_enddate      IN VARCHAR2,
									ps_channel_code IN VARCHAR2,
             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  ln_txno        NUMBER;
  ln_islemkod          NUMBER;
  ld_tamamlanma       DATE;
  NoStatementFound      EXCEPTION;

BEGIN

 --ln_txno:=TO_NUMBER(pn_txno);

     /* SELECT KAYIT_TARIH
   into  ld_tamamlanma
   FROM CBS_ISLEM
   WHERE DURUM='P'
   and  KAYIT_TARIH=trunc(sysdate-4) and islem_kod=pn_islemkod;*/

 IF ln_islemkod NOT IN ('1203','4025') THEN
    ls_returncode:='269';
    RAISE NoStatementFound;
 END IF;

 IF pn_islemkod='1203' THEN
  --INTERNAL MONEY TRANSFER
   OPEN pc_ref FOR
    SELECT i.TX_NO,
      --TO_CHAR(ld_tamamlanma,'DD/MM/YYYY') TRAN_DATE,
     pkg_int_account.GetB2OBStatementDate(i.TX_NO),
      i.BORC_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(i.BORC_HESAP_NO)) BORCLU_ADI,
     i.BORC_EXTERNAL_HESAP,
     i.BORC_VERGI_NO,
     SUBSTR(i.PREFIX_ISTATISTIK_KODU,1,2) BORCLU_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.BORC_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.BORC_HESAP_NO))) BBANK_NAME,
     i.ALACAK_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(i.ALACAK_HESAP_NO)) ALACAKLI_ADI,
     i.ALACAK_EXTERNAL_HESAP,
     i.ALACAK_VERGI_NO,
     SUBSTR(i.PREFIX_ISTATISTIK_KODU,3,2) ALACAK_IIK,
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.ALACAK_HESAP_NO)) ALACAK_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.ALACAK_HESAP_NO))) ABANK_NAME,
     i.DOVIZ_KODU,
     i.TUTAR,
     i.ACIKLAMA,
     i.ISTATISTIK_KODU,
     i.PREFIX_ISTATISTIK_KODU,
     Pkg_Report.Number_To_Word_Eng( i.TUTAR, i.DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
           Pkg_Report.Number_To_Word_Rus( i.TUTAR, i.DOVIZ_KODU) TUTAR_YAZI_ILE_RUS,
     '-' BCLASS,
     i.TX_NO DOC_NO,
     pn_islemkod,
     i.CHARGE_AMOUNT
    FROM CBS_VIRMAN_ISLEM i,
         cbs_islem e
             WHERE  i.TX_NO=e.NUMARA
    and    e.DURUM='P'
    AND  e.KAYIT_TARIH BETWEEN TO_DATE(pd_startdate,'YYYYMMDD') AND TO_DATE(pd_enddate,'YYYYMMDD')
    and e.KAYIT_KULLANICI_KODU='CINT_CALLER'
	and	pkg_hesap.HesaptanMusteriNoAl(i.BORC_HESAP_NO) in (select distinct customer_id from corpint.tbl_person_auth a, corpint.tbl_person b where CHANNEL_CD like '%'||ps_channel_code||'%' and a.person_id=b.person_id);


 ELSIF pn_islemkod IN ('4025') THEN
 --FX BUY
  OPEN pc_ref FOR
   SELECT  i.TX_NO,
     TO_CHAR(i.ISLEM_TARIHI,'DD/MM/YYYY'),
     i.MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(i.MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(i.MUSTERI_HESAP_NO),
     i.MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,3,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.MUSTERI_HESAP_NO))) BBANK_NAME,
     i.DTH_MUSTERI_HESAP_NO,
     Pkg_Musteri.Sf_Musteri_Adi(i.DTH_MUSTERI_NO),
     pkg_hesap.External_HesapNo_Al(i.MUSTERI_HESAP_NO),
     i.DTH_MUSTERI_VERGI_NO,
     '-',
--     SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,1,2),
     Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.DTH_MUSTERI_HESAP_NO)) BORCLU_BANKA,
     Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(i.DTH_MUSTERI_HESAP_NO))) BBANK_NAME,
     i.DOVIZ_KODU,
     i.DOVIZ_TUTARI,
     i.ACIKLAMA,
     '-',
     '-',
--does not exist     ISTATISTIK_KODU_ALIS,
--      ISTATISTIK_KODU_SATIS,
     Pkg_Report.Number_To_Word_Eng( i.DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
     Pkg_Report.Number_To_Word_Rus( i.DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE,
     '' DOC_BCLASS,
     i.TX_NO DOC_NUM,
     pn_islemkod,
     i.KUR,
     Pkg_Kur.yuvarla(Pkg_Genel.LC_al,i.DOVIZ_TUTARI*i.KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
     i.ISLEM_SUBE
  FROM CBS_DTH_DOVIZ_SATIS_ISLEM i, cbs_islem e
  WHERE  ISLEM_TARIHI BETWEEN TO_DATE(pd_startdate,'YYYYMMDD') AND TO_DATE(pd_enddate,'YYYYMMDD')
  and e.KAYIT_KULLANICI_KODU='CINT_CALLER'
  and i.TX_NO=e.NUMARA
  and MUSTERI_NO in (select distinct customer_id from corpint.tbl_person_auth a, corpint.tbl_person b where CHANNEL_CD like '%'||ps_channel_code||'%' and a.person_id=b.person_id);


 END IF;


 RETURN ls_returncode;

EXCEPTION
   WHEN NoStatementFound THEN
      OPEN pc_ref FOR
   SELECT 'NOTFOUND' FROM dual;
      RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION GetCurrentCurrency(ps_currency IN VARCHAR2, ps_fxtype IN VARCHAR2) RETURN VARCHAR2 IS

  ls_returncode       VARCHAR2(3):='000';
  NoStatementFound      EXCEPTION;
  ln_rate                             varchar2(50);

BEGIN

  if ps_fxtype='EXCHNGBUY' then

  SELECT CBS_KUR.DVZSATIS
  into ln_rate
  FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_MBKUR
  WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
  AND CBS_KUR.dvz=CBS_MBKUR.dvz
  AND CBS_KUR.DVZ=ps_currency
  AND CBS_KUR.DVZ<>Pkg_Genel.lc_al
  ORDER BY SIRA_NO;

   elsif ps_fxtype='EXCHNGSELL' then


       SELECT CBS_KUR.DVZALIS
    into ln_rate
    FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_MBKUR
    WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
    AND CBS_KUR.dvz=CBS_MBKUR.dvz
    AND CBS_KUR.DVZ=ps_currency
    AND CBS_KUR.DVZ<>Pkg_Genel.lc_al
    ORDER BY SIRA_NO;

 end if;


 RETURN ln_rate;

EXCEPTION
   WHEN NoStatementFound THEN
         RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION CheckAccountNo(pn_accountno IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
 ls_count NUMBER:=0;
 ls_error VARCHAR2(1);
 ls_status VARCHAR2(2);
 ln_accountno1 NUMBER;
  ln_accountno2 NUMBER;
 ln_value1 NUMBER;
  ln_value2 NUMBER;

    noAccoutFound      EXCEPTION;


BEGIN

			ln_accountno1:=SUBSTR(pn_accountno,0,14);
			ln_accountno2:=SUBSTR(pn_accountno,0,3);
	  BEGIN
			SELECT 'OK'
			INTO ls_status
			FROM dual
			WHERE ln_accountno2 IN (SELECT SUBSTR(BANKA_KODU,0,3)
			FROM  CBS_BANKA_KODLARI );

			 EXCEPTION WHEN NO_DATA_FOUND THEN
			  ls_returncode:='877';

	  END;

    IF ls_status='OK' THEN

	 ln_value1:=MOD(ln_accountno1,97);
				 IF LENGTH( ln_value1)=2 THEN
				      ln_value2:=ln_accountno1||ln_value1;
				 ELSIF LENGTH( ln_value1)=1 AND ln_value1=0 THEN
				      ln_value2:=ln_accountno1||97;
				 ELSIF LENGTH( ln_value1)=1 THEN
				      ln_value2:=ln_accountno1||0||ln_value1;
				 END IF;
	ELSE
			   ls_returncode:='877';
	END IF;

	IF TO_NUMBER(pn_accountno)= ln_value2 THEN
	     ls_returncode:='000';
	ELSE
	     ls_returncode:='877';
    END IF ;

	OPEN pc_ref FOR
		SELECT ln_value2 FROM dual;

    RETURN ls_returncode;

 EXCEPTION
 WHEN noAccoutFound THEN
   ls_returncode:= '877';
 RETURN ls_returncode;

END;
--------------------------------------------------------------------------------------------------------
FUNCTION UpdateAccountEmailStatement(ps_option IN VARCHAR2,
									ps_personid IN VARCHAR2,
									ps_customerno IN VARCHAR2,
									ps_accountno IN VARCHAR2,
									ps_channelcd IN VARCHAR2,
									ps_rate IN VARCHAR2,
									ps_move IN VARCHAR2,
									ps_period1 IN VARCHAR2 ,
									ps_period2 IN VARCHAR2 ,
									ps_email1 IN VARCHAR2 ,
									ps_email2 IN VARCHAR2 ,
									pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is

ls_returncode VARCHAR2(3):='000';
ls_count1 NUMBER:=0;
ls_count2 NUMBER:=0;
begin

	if ps_option='GET' then
		OPEN pc_ref FOR
			SELECT PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,
				   ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT
			FROM corpint.tbl_email_subscription
			where CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
	elsif ps_option='UPDATE' then

		 SELECT COUNT(*)
		 INTO	ls_count1
		 FROM	corpint.tbl_email_subscription
		 WHERE	ACCOUNT_NO = ps_accountno
		 AND	MSG_TYPE = 'CURRENCY';
		 --check if customer subscribed for movement
	 	 SELECT COUNT(*)
		 INTO	ls_count2
		 FROM	corpint.tbl_email_subscription
		 WHERE	ACCOUNT_NO = ps_accountno
		 AND	MSG_TYPE = 'MOVEMENT';

		IF (ps_rate = 'Y' AND ls_count1=0) THEN --subscribe for currency
			INSERT INTO corpint.tbl_email_subscription
			(PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE,
			MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,STATUS_CD,ACCOUNT_NO,PERIOD_COUNT)
			VALUES
			(TO_NUMBER(ps_personid),TO_NUMBER(ps_customerno),ps_channelcd,TRUNC(SYSDATE),
			'CURRENCY',ps_period1,DECODE(ps_period1,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
			ps_email1,'sENAB',TO_NUMBER(ps_accountno),1);
		elsif (ps_rate='Y' AND ls_count1>0) then
			update corpint.tbl_email_subscription
			set SUBSCRIBE_DATE=trunc(sysdate),
				PERIOD=ps_period1,
				NEXTRUNDATE=DECODE(ps_period1,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
				EMAIL=ps_email1,
				STATUS_CD='sENAB',
				PERIOD_COUNT=1
			where MSG_TYPE='CURRENCY'
			and	  CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
		else
			delete from corpint.tbl_email_subscription
			where MSG_TYPE='CURRENCY'
			and	  CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
		end if;

		IF (ps_move = 'Y' AND ls_count2=0) THEN --subscrive for movement
			INSERT INTO corpint.tbl_email_subscription
			(PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE,
			MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,STATUS_CD,ACCOUNT_NO,PERIOD_COUNT)
			VALUES
			(TO_NUMBER(ps_personid),TO_NUMBER(ps_customerno),ps_channelcd,TRUNC(SYSDATE),
			'MOVEMENT',ps_period2,DECODE(ps_period2,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
			ps_email1,'sENAB',TO_NUMBER(ps_accountno),1);
		elsif (ps_move = 'Y' AND ls_count2>0) then
			update corpint.tbl_email_subscription
			set SUBSCRIBE_DATE=trunc(sysdate),
				PERIOD=ps_period2,
				NEXTRUNDATE=DECODE(ps_period2,'G',TRUNC(SYSDATE+1),'H',TRUNC(SYSDATE+7),'A',TRUNC(ADD_MONTHS(SYSDATE,1))),
				EMAIL=ps_email1,
				STATUS_CD='sENAB',
				PERIOD_COUNT=1
			where MSG_TYPE='MOVEMENT'
			and	  CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
		else
			delete from corpint.tbl_email_subscription
			where MSG_TYPE='MOVEMENT'
			and	  CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
		end if;

		OPEN pc_ref FOR
			SELECT PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL,
				   ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT
			FROM corpint.tbl_email_subscription
			where CUSTOMER_NO=ps_customerno
			and	  ACCOUNT_NO=ps_accountno;
	elsif ps_option='DELETE' then
		delete from corpint.tbl_email_subscription
		where CUSTOMER_NO=ps_customerno
		and	  ACCOUNT_NO=ps_accountno;

		OPEN pc_ref FOR
			SELECT sysdate FROM dual;
	end if;

	return ls_returncode;
exception
		 when others then
		 log_at('UPDATE EMAIL',sqlerrm);
end;
--------------------------------------------------------------------------------------------------------
FUNCTION SendDemoEmail(ps_option IN VARCHAR2,
					   ps_sql 	 IN VARCHAR2,
					   ps_email  IN VARCHAR2,
					   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is
ls_returncode varchar2(3):='000';
CURSOR c1 IS
	select ACCOUNT_NO from corpint.tbl_email_subscription;
ln_num number;
ln_count number:=0;
begin
if ps_option='delete' then
	delete from CORPINT.TBL_EMAIL_SUBSCRIPTION;
	delete from CBS_EMAIL_MESSAGES;
end if;

update CORPINT.TBL_EMAIL_SUBSCRIPTION
set NEXTRUNDATE=Pkg_Muhasebe.Banka_Tarihi_Bul;

	OPEN c1;
		LOOP
			FETCH c1 INTO
			ln_num;
			EXIT WHEN c1%NOTFOUND;
			pkg_jobs.SendSubscription('');
			pkg_email.SendAutoMessages('');
			--ln_count := ln_count + 1;
			--log_at('email',ln_count);
		END LOOP;
	CLOSE c1;

update CORPINT.TBL_EMAIL_SUBSCRIPTION
set NEXTRUNDATE=Pkg_Muhasebe.Banka_Tarihi_Bul;

/*INSERT INTO CORPINT.TBL_EMAIL_SUBSCRIPTION ( PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE,
PERIOD, NEXTRUNDATE, EMAIL, ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT ) VALUES
(2, 1379, 'cDKBRIB',  TO_Date( '11/12/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), 'MOVEMENT', 'G',  TO_Date( '11/13/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), ps_email, NULL, NULL, 'sENAB', 100720, 1);
INSERT INTO CORPINT.TBL_EMAIL_SUBSCRIPTION ( PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE,
PERIOD, NEXTRUNDATE, EMAIL, ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT ) VALUES
(2, 1379, 'cDKBRIB',  TO_Date( '11/12/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), 'MOVEMENT', 'G',  TO_Date( '11/13/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), ps_email, NULL, NULL, 'sENAB', 100719, 1);
INSERT INTO CORPINT.TBL_EMAIL_SUBSCRIPTION ( PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE,
PERIOD, NEXTRUNDATE, EMAIL, ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT ) VALUES
(2, 1379, 'cDKBRIB',  TO_Date( '11/12/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), 'MOVEMENT', 'G',  TO_Date( '11/13/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), ps_email, NULL, NULL, 'sENAB', 100716, 1);
INSERT INTO CORPINT.TBL_EMAIL_SUBSCRIPTION ( PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE,
PERIOD, NEXTRUNDATE, EMAIL, ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT ) VALUES
(2, 1379, 'cDKBRIB',  TO_Date( '11/12/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), 'CURRENCY', 'G',  TO_Date( '11/13/2007 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), ps_email, NULL, NULL, 'sENAB', 100720, 1);

pkg_jobs.SendSubscription('');
pkg_email.SendAutoMessages('');
pkg_jobs.SendSubscription('');
pkg_email.SendAutoMessages('');
pkg_jobs.SendSubscription('');
pkg_email.SendAutoMessages('');*/

	if ps_sql='tbl_email_subscription' then
		OPEN pc_ref FOR
			SELECT PERSONID, CUSTOMER_NO, CHANNEL_CD, SUBSCRIBE_DATE, MSG_TYPE, PERIOD, NEXTRUNDATE, EMAIL, ASSNDATE, ENDDATE, STATUS_CD, ACCOUNT_NO, PERIOD_COUNT
			from corpint.tbl_email_subscription;
	elsif ps_sql='cbs_email_messages' then
		OPEN pc_ref FOR
			SELECT MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT, STATUS_CD, INSERT_DATE, SEND_DATE, CONTENT_TYPE
			from cbs_email_messages;
	elsif ps_sql='cbs_debug_log' then
		OPEN pc_ref FOR
			SELECT D1, D2, D3, D4, YARAT_TARIH, YARATAN
			from cbs_debug_log
			where trunc(YARAT_TARIH)=trunc(sysdate)
			order by YARAT_TARIH desc;
	else
		OPEN pc_ref FOR
			SELECT sysdate FROM dual;
	end if;

	return ls_returncode;
end;
--------------------------------------------------------------------------------------------------------

/*******************************************************************************
Name        : FUNCTION ARRESTED_ACCOUNT_CHECK
Prepared By :  Adil Kamchibekov
Date        : 01.09.2022
Purpose     : check blocked or arrested acounts  CBS-721
*******************************************************************************/
FUNCTION ARRESTED_ACCOUNT_CHECK  (pn_musteri_no IN Number,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 is 
    ln_blk_acc_count number :=0;
    ld_pass_exp_date date;
    blk_acc_except   exception;
    passport_expiry_exp exception;
begin

    OPEN pc_ref for select (
            SELECT count(*)  from CBS_BAD_LIST where CUSTOMER_NO =pn_musteri_no and STATUS_CODE='ACTIVE'
        )
            +
        (
            SELECT count(*) from cbs_bloke where musteri_no =pn_musteri_no and DURUM_KODU='A'and BLOKE_NEDEN_KODU in (70,1)
        )
    FROM dual;
    fetch pc_ref into ln_blk_acc_count;
    select GECERLILIK_TARIHI into ld_pass_exp_date from cbs_musteri where musteri_no=pn_musteri_no;
    
    if ln_blk_acc_count > 0 then
        Raise blk_acc_except;
    end if;
    if ld_pass_exp_date < sysdate -1 then 
        Raise passport_expiry_exp;
    end if;
        
    return '000';

Exception
    when blk_acc_except
        then
        return '999';
        
    when passport_expiry_exp
    then
        return '998';

end;


-----------------------------------------------------------------------------------------------------

/*******************************************************************************
Name        : FUNCTION getAccountsByPhoneNumber
Prepared By : Nursultan Kazbekov
Date        : 30.08.2022
Purpose     : get accounts by phone number mb-277
*******************************************************************************/
FUNCTION getAccountsByPhoneNumber(country_code IN  varchar2, operator_code IN varchar2, phone_number IN varchar2, pc_ref OUT CursorReferenceType)
	RETURN varchar2
	IS
	ls_returncode varchar2(3):='000';
	phone_number_duplicate_exception EXCEPTION;
	phone_number_count NUMBER := 0;

BEGIN
	SELECT count(*) INTO phone_number_count FROM CBS_MUSTERI_ADRES WHERE ULKE_GSM_KOD=country_code
	AND GSM_ALAN_KOD=operator_code AND gsm_no=phone_number;

IF phone_number_count > 1 THEN
Raise phone_number_duplicate_exception;
END IF;

OPEN pc_ref FOR SELECT KISA_ISIM AS accountOwner , EXTERNAL_HESAP_NO AS accountNumber FROM CBS_HESAP WHERE MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI_ADRES WHERE 
ulke_gsm_kod=country_code AND gsm_alan_kod=operator_code AND gsm_no=phone_number);
RETURN ls_returncode;
 
EXCEPTION
	WHEN phone_number_duplicate_exception THEN
	ls_returncode:='001';
	RETURN ls_returncode;
	WHEN OTHERS THEN
	ls_returncode:='999';
	RETURN ls_returncode;
END;

--------------------------------------------------------------------------------------------------------------
/*******************************************************************************
Name        : FUNCTION getAccountsByEmail
Prepared By : Nursultan Kazbekov
Date        : 30.08.2022
Purpose     : get accounts by email mb-277
*******************************************************************************/
FUNCTION getAccountsByEmail(customer_email IN varchar2, pc_ref OUT CursorReferenceType)
	RETURN varchar2
	IS
	ls_returncode varchar2(3):='000';
	email_count NUMBER:=0;
	email_duplicate_exception EXCEPTION;

BEGIN
	SELECT count(*) INTO email_count FROM CBS_MUSTERI_ADRES WHERE EMAIL=customer_email;

IF email_count > 1 THEN
Raise email_duplicate_exception;
END IF;

OPEN pc_ref FOR SELECT KISA_ISIM AS accountOwner , EXTERNAL_HESAP_NO AS accountNumber
FROM CBS_HESAP WHERE MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI_ADRES WHERE EMAIL=customer_email);
RETURN ls_returncode; 

EXCEPTION
	WHEN email_duplicate_exception 
	THEN ls_returncode:='001';
	RETURN ls_returncode;
	WHEN OTHERS THEN
	ls_returncode:='999';
	RETURN ls_returncode;
END; 

----------------------------------------------------------------------------------------------------------
/*******************************************************************************
Name        : FUNCTION getAccountsByInn
Prepared By : Nursultan Kazbekov
Date        : 30.08.2022
Purpose     : get accounts by inn mb-277
*******************************************************************************/
FUNCTION getAccountsByInn(customer_inn IN varchar2, pc_ref OUT CursorReferenceType)
	RETURN varchar2
	IS
	ls_returncode varchar2(3):='000';
	inn_count NUMBER:=0;
	inn_duplicate_exception EXCEPTION;
	
BEGIN
	SELECT count(*) INTO inn_count FROM CBS_MUSTERI WHERE VERGI_NO = customer_inn;

IF inn_count > 1 then
	raise inn_duplicate_exception;
end IF;

	OPEN pc_ref FOR SELECT KISA_ISIM AS accountOwner , EXTERNAL_HESAP_NO AS accountNumber
	FROM CBS_HESAP WHERE MUSTERI_NO IN (SELECT MUSTERI_NO FROM CBS_MUSTERI WHERE VERGI_NO = customer_inn);
RETURN ls_returncode; 

EXCEPTION
	WHEN inn_duplicate_exception THEN
	ls_returncode:='001';
	RETURN ls_returncode;
	WHEN OTHERS THEN
	ls_returncode:='999';
	RETURN ls_returncode;
END;
 
--------------------------------------------------------------------------------------------------------
END;
/

