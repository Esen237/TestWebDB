create PACKAGE BODY     pkg_kullanici_log IS
----------------------------------------------------------------------------------------------------------------------------------
     Procedure Ekle (ps_program_adi varchar2) is
    pragma autonomous_transaction;
    Begin
        insert into cbs_kullanici_log (numara,kullanici_kodu,rol_numara,bolum_kodu,banka_tarihi,sistem_tarihi,program_kodu)
           values ( sq_cbs_kullanici_log.nextval,pkg_baglam.kullanici_kodu,pkg_baglam.rol_numara,pkg_baglam.bolum_kodu,pkg_muhasebe.banka_tarihi_bul,sysdate,ps_program_adi);
      commit;
    Exception
        When Others then
          Rollback;
    End;
----------------------------------------------------------------------------------------------------------------------------------   
-- cbs_main to log clientinfo log    seval.colak 0507202
----------------------------------------------------------------------------------------------------------------------------------        
    Procedure clientinfo (ps_program_adi varchar2, 
                    p_clientinfo_user_name           cbs_kullanici_log.clientinfo_user_name%type  default null ,
                    p_clientinfo_ip_address          cbs_kullanici_log.clientinfo_ip_address%type  default null ,
                    p_clientinfo_host_name           cbs_kullanici_log.clientinfo_host_name%type  default null ,
                    p_clientinfo_operating_system     cbs_kullanici_log.clientinfo_operating_system%type  default null ,
                    p_clientinfo_java_version        cbs_kullanici_log.clientinfo_java_version%type  default null ,
                   -- p_clientinfo_path_seperator      cbs_kullanici_log.clientinfo_path_seperator%type  default null ,
                   -- p_clientinfo_file_seperator      cbs_kullanici_log.clientinfo_file_seperator%type  default null ,
                    p_clientinfo_language            cbs_kullanici_log.clientinfo_language%type  default null ,
                    p_clientinfo_time_zone           cbs_kullanici_log.clientinfo_time_zone%type  default null ,
                    p_clientinfo_date_time           cbs_kullanici_log.clientinfo_date_time%type  default null,
                    p_client_action_message           varchar2 default null 
                   
    ) is
    pragma autonomous_transaction;
    Begin
        insert into cbs_kullanici_log (numara,kullanici_kodu,rol_numara,bolum_kodu,banka_tarihi,sistem_tarihi,program_kodu,
                                        clientinfo_user_name,
                                        clientinfo_ip_address,
                                        clientinfo_host_name,
                                        clientinfo_operating_system,
                                        clientinfo_java_version,
                                       --clientinfo_path_seperator,
                                       -- clientinfo_file_seperator,
                                        clientinfo_language,
                                        clientinfo_time_zone,
                                        clientinfo_date_time,
                                        --serverside columns
                                        srv_action,
                                        srv_audited_cursorid,
                                        srv_authenticated_identity,
                                        srv_authentication_data,
                                        srv_authentication_method,
                                        srv_bg_job_id,
                                        srv_client_identifier,
                                        srv_client_info,
                                        srv_current_bind,
                                        srv_current_schema,
                                        srv_current_schemaid,
                                        srv_current_sql,
                                        srv_current_sqln,
                                        srv_current_sql_length,
                                        srv_db_domain,
                                        srv_db_name,
                                        srv_db_unique_name,
                                        srv_entryid,
                                        srv_enterprise_identity,
                                        srv_fg_job_id,
                                        srv_global_context_memory,
                                        srv_global_uid,
                                        srv_host,
                                        srv_identification_type,
                                        srv_instance,
                                        srv_instance_name,
                                        srv_ip_address,
                                        srv_isdba,
                                        srv_lang,
                                        srv_language,
                                        srv_module,
                                        srv_network_protocol,
                                        srv_nls_calendar,
                                        srv_nls_currency,
                                        srv_nls_date_format,
                                        srv_nls_date_language,
                                        srv_nls_sort,
                                        srv_nls_territory,
                                        srv_os_user,
                                        srv_policy_invoker,
                                        srv_proxy_enterprise_identity,
                                        srv_proxy_user,
                                        srv_proxy_userid,
                                        srv_server_host,
                                        srv_service_name,
                                        srv_session_user,
                                        srv_session_userid,
                                        srv_sessionid,
                                        srv_sid,
                                        srv_statementid,
                                        srv_terminal ,
                                        client_action_message                               
                                        )
                                 values ( sq_cbs_kullanici_log.nextval,nvl(nvl(pkg_baglam.kullanici_kodu,user),p_clientinfo_user_name),nvl(pkg_baglam.rol_numara,0),nvl(pkg_baglam.bolum_kodu,'000'),pkg_muhasebe.banka_tarihi_bul,sysdate,upper(ps_program_adi),
                                        p_clientinfo_user_name,
                                        p_clientinfo_ip_address,
                                        p_clientinfo_host_name,
                                        p_clientinfo_operating_system,
                                        p_clientinfo_java_version,
                                     --   p_clientinfo_path_seperator,
                                     --   p_clientinfo_file_seperator,
                                        p_clientinfo_language,
                                        p_clientinfo_time_zone,
                                        p_clientinfo_date_time ,
                                        --serverside info
                                        sys_context('USERENV','ACTION') ,--   ACTION    ,
                                        sys_context('USERENV','AUDITED_CURSORID') ,--   AUDITED_CURSORID    ,
                                        sys_context('USERENV','AUTHENTICATED_IDENTITY') ,--   AUTHENTICATED_IDENTITY    ,
                                        sys_context('USERENV','AUTHENTICATION_DATA') ,--   AUTHENTICATION_DATA    ,
                                        sys_context('USERENV','AUTHENTICATION_METHOD'),--    AUTHENTICATION_METHOD    ,
                                        sys_context('USERENV','BG_JOB_ID'),--    BG_JOB_ID    ,
                                        sys_context('USERENV','CLIENT_IDENTIFIER'),--    CLIENT_IDENTIFIER    ,
                                        sys_context('USERENV','CLIENT_INFO') ,--   CLIENT_INFO    ,
                                        sys_context('USERENV','CURRENT_BIND'),--    CURRENT_BIND    ,
                                        sys_context('USERENV','CURRENT_SCHEMA'),--    CURRENT_SCHEMA    ,
                                        sys_context('USERENV','CURRENT_SCHEMAID'),--    CURRENT_SCHEMAID    ,
                                        sys_context('USERENV','CURRENT_SQL') ,--   CURRENT_SQL    ,
                                        sys_context('USERENV','CURRENT_SQLn'),--    CURRENT_SQLn    ,
                                        sys_context('USERENV','CURRENT_SQL_LENGTH'),--    CURRENT_SQL_LENGTH    ,
                                        sys_context('USERENV','DB_DOMAIN'),--    DB_DOMAIN    ,
                                        sys_context('USERENV','DB_NAME') ,--   DB_NAME    ,
                                        sys_context('USERENV','DB_UNIQUE_NAME'),--    DB_UNIQUE_NAME    ,
                                        sys_context('USERENV','ENTRYID') ,--   ENTRYID    ,
                                        sys_context('USERENV','ENTERPRISE_IDENTITY'),--    ENTERPRISE_IDENTITY    ,
                                        sys_context('USERENV','FG_JOB_ID'),--    FG_JOB_ID    ,
                                        sys_context('USERENV','GLOBAL_CONTEXT_MEMORY'),--    GLOBAL_CONTEXT_MEMORY    ,
                                        sys_context('USERENV','GLOBAL_UID'),--    GLOBAL_UID    ,
                                        sys_context('USERENV','HOST'),--    HOST    ,
                                        sys_context('USERENV','IDENTIFICATION_TYPE') ,--   IDENTIFICATION_TYPE    ,
                                        sys_context('USERENV','INSTANCE'),--    INSTANCE    ,
                                        sys_context('USERENV','INSTANCE_NAME') ,--   INSTANCE_NAME    ,
                                        sys_context('USERENV','IP_ADDRESS'),--    IP_ADDRESS    ,
                                        sys_context('USERENV','ISDBA'),--    ISDBA    ,
                                        sys_context('USERENV','LANG'),--    LANG    ,
                                        sys_context('USERENV','LANGUAGE'),--    LANGUAGE    ,
                                        sys_context('USERENV','MODULE'),--    MODULE    ,
                                        sys_context('USERENV','NETWORK_PROTOCOL'),--    NETWORK_PROTOCOL    ,
                                        sys_context('USERENV','NLS_CALENDAR'),--    NLS_CALENDAR    ,
                                        sys_context('USERENV','NLS_CURRENCY'),--    NLS_CURRENCY    ,
                                        sys_context('USERENV','NLS_DATE_FORMAT'),--    NLS_DATE_FORMAT    ,
                                        sys_context('USERENV','NLS_DATE_LANGUAGE'),--    NLS_DATE_LANGUAGE    ,
                                        sys_context('USERENV','NLS_SORT'),--    NLS_SORT    ,
                                        sys_context('USERENV','NLS_TERRITORY'),--    NLS_TERRITORY    ,
                                        sys_context('USERENV','OS_USER'),--    OS_USER    ,
                                        sys_context('USERENV','POLICY_INVOKER'),--    POLICY_INVOKER    ,
                                        sys_context('USERENV','PROXY_ENTERPRISE_IDENTITY'),--    PROXY_ENTERPRISE_IDENTITY    ,
                                        sys_context('USERENV','PROXY_USER'),--    PROXY_USER    ,
                                        sys_context('USERENV','PROXY_USERID'),--    PROXY_USERID    ,
                                        sys_context('USERENV','SERVER_HOST'),--    SERVER_HOST    ,
                                        sys_context('USERENV','SERVICE_NAME'),--    SERVICE_NAME    ,
                                        sys_context('USERENV','SESSION_USER'),--    SESSION_USER    ,
                                        sys_context('USERENV','SESSION_USERID'),--    SESSION_USERID    ,
                                        sys_context('USERENV','SESSIONID'),--    SESSIONID    ,
                                        sys_context('USERENV','SID'),--    SID    ,
                                        sys_context('USERENV','STATEMENTID'),--    STATEMENTID    ,
                                        sys_context('USERENV','TERMINAL'),--    TERMINAL
                                        UPPER(substr(p_client_action_message,1,2000))   
                                        );
                                                    
      commit;
    Exception
        When Others then
            log_at('PKG_KULLANICI_LOG.CLIENTINFO','ERROR', TO_CHAR(SQLCODE)|| ' ' || SQLERRM  ||'kullanici_kodu:'||nvl(nvl(pkg_baglam.kullanici_kodu,user),p_clientinfo_user_name) );
          Rollback;
    End;
  Procedure Rollb_TX is
  
  begin
     Rollback;
  end;
 ----------------------------------------------------------------------------------------------------------------------------------     
END;
/

