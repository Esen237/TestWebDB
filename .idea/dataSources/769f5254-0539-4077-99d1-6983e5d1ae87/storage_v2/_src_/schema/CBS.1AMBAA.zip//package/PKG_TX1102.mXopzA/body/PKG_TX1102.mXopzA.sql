create PACKAGE BODY     PKG_TX1102 IS
    pn_1102_CASH_CODE             number;
    pn_1102_masraf_tutari         number;
    pn_1102_masraf_hesap_no       number;
    pn_1102_masraf_hesap_sube     number;
    pn_1102_cek_islem_sube        number;
    pn_1102_cek_tutar_1_tl        number;
    pn_1102_cek_yaprak_adet       number;
    pn_1102_banka_aciklama        number;
    pn_1102_musteri_aciklama      number;
    pn_1102_cek_referans          number;
    pn_1102_fis_aciklama          number;
    pn_1102_kur_lc                  number;
    pn_1102_masraf_kasa              number;
    pn_1102_masraf_hesap          number;
    pn_1102_masraf_yok              number;
    pn_1102_karne_continuous      number;
    pn_1102_karne_10              number;
    pn_1102_karne_25              number;
    pn_1102_doviz_tl              number;
    pn_1102_doviz_yp              number;
    pn_1102_istatistik_kodu        number;
    pn_1102_DK_CEK_MASRAF           number;
    pn_1102_KUR                      number;
    pn_1102_DOVIZ_KODU              number;
    pn_1102_LC_CEK_TUTAR_1_TL      number;
    pn_1102_CASH_GL                  number;
    pn_1102_sales_tax_amount        number; --b-o-m sevalb 23022011 
    pn_1102_vat_amount              number;
    pn_1102_tax_total_amount        number;  
    pn_1102_masraf_lc                number;        --masraf lc
    pn_1102_masraf_fc                number;        --masraf fc
    pn_1102_vat_amount_lc            number;        --1102_vat_amount_lc
    pn_1102_masraf_tutari_lc         number;        --1102_masraf_tutari_lc
    pn_1102_sales_tax_amount_lc      number;        --1102_sales_tax_amount_lc
    pn_1102_tax_total_amount_lc      number;        --1102_tax_total_amount_lc
    pn_1102_masraf_hesap_doviz       number;        --1102_masraf_hesap_doviz
                                              --e-o-m sevalb 23022011

------------------------------------------------------------
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   cursor cur_islem is
    select DOVIZ_KODU,
           NVL(MASRAF_TUTARI,0) + NVL(SALES_TAX_AMOUNT,0) +  NVL(VAT_AMOUNT,0) masraf_tutari, --sevalb 23022011
           KASA_HESAP_SECIMI,
           modul_tur_kod,
           urun_tur_kod,
           HESAP_NO,
           baslangic_cek_no,
           bitis_cek_no,
           musteri_no,
           prefix_istatistik_kodu,
           istatistik_kodu,
           masraf_doviz_kodu    
    from cbs_cek_karne_islem
    where tx_no = pn_islem_no;

     ls_musteri_aciklama varchar2(2000);
     ls_islem_aciklama varchar2(2000);
    ls_dk_grup_kod               varchar2(2000);
    ls_masraf_kodu                varchar2(200) :='CEK_MASRAF';
    ls_dk_cek_masraf           varchar2(2000);
    dk_bulunamadi                exception;
    ln_hesap_no                   number;

  Begin

    ls_islem_aciklama :=  Pkg_Genel.Islem_Adi_Al(1102);
    for c_islem in cur_islem loop
     if c_islem.KASA_HESAP_SECIMI ='CASH' then
        pkg_tx1601.Kontrol_Sonrasi(pn_islem_no,
                                   '1102',
                                    c_islem.masraf_tutari,
                                    c_islem.masraf_doviz_kodu,
                                    'Y',
                                    null,null,null,'H',null );

         ls_dk_grup_kod := pkg_musteri.sf_musteri_dk_grup_kod_al(c_islem.musteri_no);
         ls_dk_cek_masraf := pkg_muhasebe.komisyon_dk_bul(ls_dk_grup_kod,ls_masraf_kodu);
         if ls_dk_cek_masraf is null  AND nvl (c_islem.masraf_tutari,0) <> 0 then
               raise dk_bulunamadi ;
         end if;

    end if;
    end loop;

    for c_islem in cur_islem loop
     if c_islem.KASA_HESAP_SECIMI = 'CASH' then
       ls_musteri_aciklama := ls_islem_aciklama  || ' Account No :' || to_char(c_islem.hesap_no) || ' Start No:' || to_char(c_islem.baslangic_cek_no) || ' End No:' || to_char(c_islem.bitis_cek_no);
         BEGIN
            pkg_cash_slip.cash_slip( pn_islem_no,
                                          1, --Deposit
                                          pkg_muhasebe.banka_tarihi_bul ,
                                          c_islem.masraf_doviz_kodu,
                                          c_islem.masraf_tutari,
                                          ls_musteri_aciklama,
                                          null,
                                          null,
                                          ls_dk_cek_masraf,
                                          null,
                                          c_islem.prefix_istatistik_kodu,
                                          c_islem.masraf_doviz_kodu,
                                          c_islem.istatistik_kodu,
                                          null,
                                          null);

         EXCEPTION WHEN OTHERS THEN
                    pkg_cash_slip.Delete_Cash_Slip(pn_islem_no);
        End;

    end if;
    end loop;

    select MASRAF_HESAP_NO
    into ln_hesap_no
    from cbs_cek_karne_islem
    where tx_no = pn_islem_no;

    if ln_hesap_no is not null then
      pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1102',ln_hesap_no);
    end if;

 Exception
  when dk_bulunamadi then
  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '743' || pkg_hata.getDelimiter || ls_dk_grup_kod  || pkg_hata.getDelimiter ||ls_masraf_kodu || pkg_hata.getUCPOINTER);

  End;
------------------------------------------------------------
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is

   cursor cur_islem is
    select DOVIZ_KODU,
             NVL(MASRAF_TUTARI,0) + NVL(SALES_TAX_AMOUNT,0) +  NVL(VAT_AMOUNT,0) masraf_tutari, --sevalb 23022011
             KASA_HESAP_SECIMI,
           modul_tur_kod,
           urun_tur_kod,
           masraf_doviz_kodu 
    from cbs_cek_karne_islem
    where tx_no = pn_islem_no;
  Begin
    for c_islem in cur_islem loop
     if c_islem.KASA_HESAP_SECIMI = 'CASH' then
        pkg_tx1601.Dogrulama_Sonrasi(pn_islem_no,
                                   '1102',
                                    c_islem.masraf_tutari,
                                    c_islem.masraf_doviz_kodu,
                                    'Y' );
    end if;
    end loop;
  End;
------------------------------------------------------------
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;
------------------------------------------------------------
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
------------------------------------------------------------
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;
------------------------------------------------------------
  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
------------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1191' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;
------------------------------------------------------------
  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_musteri_no number := 0;
  ln_adet        number := 0;
  ld_banka_tarihi date ;
  ln_baslangic_cek_no  cbs_cek_karne_islem.baslangic_cek_no%type;
  ln_bitis_cek_no       cbs_cek_karne_islem.bitis_cek_no%type;

  ln_talep_tx_no       cbs_cek_karne_islem.tx_no%type;
  ln_ref_tx_no         cbs_cek_karne_islem.tx_no%type;
  ln_cek_no            cbs_cek.cek_no%type;
  ls_durum_kodu           cbs_cek.durum_kodu%type;
  onceden_teslim_edilmis    exception;
  odeme_yasakli_cek_mevcut  exception;
  karsiliksiz_cek_mevcut    exception;
  cek_teslimetme            exception;
  ln_hesap                    number;
  ls_cek                    varchar2(20);
  ls_bolum                   varchar2(20);
  ls_doviz_kodu                varchar2(20);
 cursor cur_islem is
    select DOVIZ_KODU,
           NVL(MASRAF_TUTARI,0) + NVL(SALES_TAX_AMOUNT,0) +  NVL(VAT_AMOUNT,0) masraf_tutari, --sevalb 23022011
           KASA_HESAP_SECIMI,
           modul_tur_kod,
           urun_tur_kod,
            prefix_istatistik_kodu||doviz_kodu||ISTATISTIK_KODU istatistik_kodu,
            masraf_doviz_kodu
    from cbs_cek_karne_islem
    where tx_no = pn_islem_no;
  Begin

   ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;
   ln_ref_tx_no    := pkg_cek.Sf_Islem_Gonder_Karne_Islem_Al(pn_islem_no);
   ln_cek_no       := Pkg_cek.Sf_Cek_Teslim_Girisi_Yapilirmi(ln_ref_tx_no) ;

 if ln_cek_no =0 then

     /* girilen cek numaralari ?nceden teslim edildiyse hata verilmelidir. */
       select count(*)
       into   ln_adet
       from   cbs_cek
       where  ref_tx_no = ln_ref_tx_no and
                 teslim_tarihi is not null  ;

     if  nvl(ln_adet,0) > 0 then
       raise  onceden_teslim_edilmis        ;
     else
       select musteri_no ,HESAP_NO ,nvl(nvl(hesap_sube_kodu,pkg_tx.Amir_BolumKodu_Al(pn_islem_no)),pkg_baglam.bolum_kodu    ),doviz_kodu
       into ln_musteri_no ,Ln_HESAP ,ls_bolum,ls_doviz_kodu
       from cbs_cek_karne_islem
       where  tx_no = pn_islem_no;

       select nvl(CEK_KARNESI,'H')
       into ls_cek
       from cbs_hesap
       where hesap_no = ln_hesap;

       if ls_cek <> 'E' then
         raise cek_teslimetme ;
        end if;
      /* islemin durum kodu guncellenir. */
        update  cbs_cek_karne_islem
        set   teslim_tarihi =ld_banka_tarihi ,durum_kodu = 'A',
              hesap_sube_kodu = ls_bolum
        where  tx_no = pn_islem_no;

     /* cek yapraklar?n?n teslim tarihi guncellenir. */
        update  cbs_cek
        set     teslim_tarihi = ld_banka_tarihi,
                musteri_no =ln_musteri_no ,
                hesap_no = Ln_HESAP,
                hesap_sube_kodu = ls_bolum,
                doviz_kodu =ls_doviz_kodu --sevalb 23022011
        where   ref_tx_no = ln_ref_tx_no
                and durum_kodu = 'A';--sevalb 23022011

    /* cek karnesini teslim tarihi guncellenir. */
        update  cbs_cek_karne_islem
        set  teslim_tarihi =ld_banka_tarihi
        where  tx_no = ln_ref_tx_no;
    end if;
  else
        select Pkg_cek.Sf_Cek_Durumu_Al(ln_cek_no)
      into ls_durum_kodu
      from dual;
  /* odeme yasakli yada karsilikzi cek durum kodunda olan cek kaydi mevcuttur. teslim iptali yapilamaz. */
        if ls_durum_kodu = 'Y' then
           raise odeme_yasakli_cek_mevcut;
       else
            raise karsiliksiz_cek_mevcut;
      end if;
  end if;


    for c_islem in cur_islem loop
     if c_islem.KASA_HESAP_SECIMI = 'CASH' then
        pkg_tx1601.Onay_Sonrasi(pn_islem_no,
                                   '1102',
                                    c_islem.masraf_tutari,
                                    c_islem.masraf_doviz_kodu,
                                    'Y' );
     end if;
    end loop;

  Exception
     When onceden_teslim_edilmis then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '189' || pkg_hata.getUCPOINTER);
       When odeme_yasakli_cek_mevcut then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '406' ||  pkg_hata.getDelimiter || ln_cek_no || pkg_hata.getUCPOINTER);
       When karsiliksiz_cek_mevcut then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '407' ||  pkg_hata.getDelimiter || ln_cek_no || pkg_hata.getUCPOINTER);
       When cek_teslimetme then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '343'   || pkg_hata.getUCPOINTER);
      When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '141' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
  End;
------------------------------------------------------------
  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     /* Red edildi */
    update cbs_cek_karne_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;
  End;
------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
------------------------------------------------------------
 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;

    ln_fis_no                   cbs_fis.numara%type ;
    ls_islem_kod               cbs_islem.islem_kod%type :='1102';
    ls_aciklama                varchar2(2000);
    ls_genel_aciklama          varchar2(2000);
    ln_musteri_no               cbs_musteri.musteri_no%TYPE;
    ln_hesap_no                      cbs_cek_karne_islem.hesap_no%TYPE;
    ls_hesap_sube_kodu              cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_tutar                      cbs_cek_karne_islem.masraf_TUTARi%TYPE;
    ls_karne_tipi_kodu           cbs_cek_karne_islem.karne_tipi_kodu%TYPE;
    ls_doviz_kodu               cbs_hesap_basvuru.DOVIZ_KODU%TYPE;
    ln_cek_yaprak_adedi           cbs_cek_karne_islem.cek_yaprak_adedi%TYPE;
    ln_baslangic_cek_no           cbs_cek_karne_islem.baslangic_cek_no%type;
    ln_bitis_cek_no               cbs_cek_karne_islem.bitis_cek_no%type;
    ls_kasa_hesap_secimi       cbs_cek_karne_islem.kasa_hesap_secimi%type;
    ls_islem_sube_kodu           cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    
    ls_masraf_hesap_sube_kodu  cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_masraf_hesap_no           cbs_cek_karne_islem.hesap_no%TYPE;
    ls_modul_tur_kod           cbs_cek_karne_islem.modul_tur_kod%type;
    ls_urun_tur_kod               cbs_cek_karne_islem.urun_tur_kod%type;
    ln_tax_rate                   number := 0;
    ln_tax_amount               number := 0;
    ln_service_tax_rate           number ;
    ln_vat_tax_rate           number;
    ls_musteri_tipi_kod            VARCHAR2(10);
    ls_vergi_muafmi              VARCHAR2(10);
    ls_dk_grup_kod               varchar2(2000);
    ls_islem_doviz_kodu        varchar2(3);
    ls_masraf_doviz_kodu          varchar2(3);    
    ls_masraf_kodu                varchar2(200) :='CEK_MASRAF';
    ls_sales_tax_alinsin    varchar2(1) := 'H'; --sevalb 02092011
    ls_vat_alinsin    varchar2(1) := 'H'; --sevalb 02092011        
    dk_bulunamadi                exception;

    cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
               select musteri_no,
                   hesap_sube_kodu,
                   hesap_no,
                   karne_tipi_kodu,
                   cek_yaprak_adedi,
                   baslangic_cek_no,
                   bitis_cek_no,
                    nvl(masraf_tutari,0),
                   pkg_hesap.HesaptanDovizKoduAl(hesap_no) ,
                   Decode( masraf_hesap_no,null,null,Pkg_Hesap.HesaptanSubeAl(masraf_hesap_no) ),
                   masraf_hesap_no    ,
                   modul_tur_kod,
                   urun_tur_kod,
                   pkg_tx.Amir_BolumKodu_Al(tx_no),
                   cash_code,
                   prefix_istatistik_kodu||doviz_kodu||ISTATISTIK_KODU istatistik_kodu,
                   sales_tax_amount  ,      --sevalb 23022011
                   vat_amount       ,       --sevalb 23022011
                   kasa_hesap_secimi ,
                   doviz_kodu  islem_doviz_kodu,    --sevalb 30032011
                   Decode( masraf_hesap_no,null,masraf_doviz_kodu,Pkg_Hesap.HesaptandovizkoduAl(masraf_hesap_no) ) masraf_doviz_kodu, --sevalb 30032011
                   nvl(sales_tax_alinsin,'H')  sales_tax_alinsin,
                   nvl(vat_alinsin,'H')  vat_alinsin
            from cbs_cek_karne_islem
            where tx_no=pn_islemno;

  Begin

    
   varchar_list(pn_1102_dk_cek_masraf) :=null;
/* islem bilgisi detaylari alinir */
         open islem_cursor(pn_islem_no);
           fetch islem_cursor into ln_musteri_no,ls_hesap_sube_kodu,ln_hesap_no,ls_karne_tipi_kodu,
                                    ln_cek_yaprak_adedi ,ln_baslangic_Cek_no,ln_bitis_cek_no,
                                    number_list(pn_1102_masraf_tutari)   ,
                                    ls_doviz_kodu, ls_masraf_hesap_sube_kodu ,ln_masraf_hesap_no,
                                    ls_modul_tur_kod,ls_urun_tur_kod,    varchar_list(pn_1102_cek_islem_sube),
                                    varchar_list(pn_1102_CASH_CODE),
                                    varchar_list(pn_1102_ISTATISTIK_KODU),
                                    number_list(pn_1102_SALES_TAX_AMOUNT),
                                    number_list(pn_1102_VAT_AMOUNT),
                                    ls_kasa_hesap_secimi,
                                    ls_islem_doviz_kodu ,
                                    ls_masraf_doviz_kodu,
                                    ls_sales_tax_alinsin,
                                    ls_vat_alinsin;
           if islem_cursor%notfound then
              close islem_cursor;
           end if;
          close islem_cursor;

         ls_dk_grup_kod := pkg_musteri.sf_musteri_dk_grup_kod_al(ln_musteri_no);
         varchar_list(pn_1102_dk_cek_masraf) := pkg_muhasebe.komisyon_dk_bul(ls_dk_grup_kod,ls_masraf_kodu);

         if varchar_list(pn_1102_dk_cek_masraf) is null and nvl( number_list(pn_1102_masraf_tutari) ,0) <> 0 then
               raise dk_bulunamadi ;
         end if;
/**** varchar list ****/
   ls_genel_aciklama :=  Pkg_Genel.Islem_Adi_Al(1102);
   ls_genel_aciklama := ls_genel_aciklama  || ' Account No :' || to_char(ln_hesap_no) || ' Start No:' || to_char(ln_baslangic_cek_no) || ' End No:' || to_char(ln_bitis_cek_no);

   pkg_parametre.deger('1102_FIS_ACIKLAMA',ls_aciklama);
   varchar_list(pn_1102_fis_aciklama)      := ls_aciklama ;
   varchar_list(pn_1102_banka_aciklama)  := ls_genel_aciklama;
   varchar_list(pn_1102_musteri_aciklama):= ls_genel_aciklama;
   varchar_list(pn_1102_cek_referans)      := to_char(ln_hesap_no);
   varchar_list(pn_1102_masraf_hesap_no) := to_char(ln_masraf_hesap_no);
   varchar_list(pn_1102_masraf_hesap_sube):=ls_masraf_hesap_sube_kodu;
   varchar_list(pn_1102_DOVIZ_KODU)         := ls_doviz_kodu ;

/**** boolean list ****/
    boolean_list(pn_1102_masraf_kasa):=false;
    boolean_list(pn_1102_masraf_hesap):=false;
    boolean_list(pn_1102_masraf_yok):=false;
    boolean_list(pn_1102_karne_10):=false;
    boolean_list(pn_1102_karne_25):=false;
    boolean_list(pn_1102_karne_continuous):=false;
    boolean_list(pn_1102_doviz_tl):=false;
    boolean_list(pn_1102_doviz_yp):=false;
-- b-o-m sevalb 30032011 
    boolean_list(pn_1102_masraf_lc) := false;
    boolean_list(pn_1102_masraf_fc) := false;
    number_list(pn_1102_vat_amount_lc) := 0;
    number_list(pn_1102_masraf_tutari_lc) := 0;
    number_list(pn_1102_sales_tax_amount_lc) := 0;
    number_list(pn_1102_tax_total_amount_lc) := 0;
    varchar_list(pn_1102_masraf_hesap_doviz) := nvl(ls_masraf_doviz_kodu,ls_islem_doviz_kodu) ;
-- e-o-m sevalb 30032011

  if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1102_cek_islem_sube)) = 'H' then
      pkg_parametre.deger('G_DK_FC_CASH_GL', varchar_list(pn_1102_cash_gl));
  else
      pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1102_cash_gl));
  end if;
    

 /* masraf deger atamalari*/
 if  NVL(number_list(pn_1102_masraf_tutari),0 ) <> 0 then
   if ls_kasa_hesap_secimi ='ACCNT' then 
      boolean_list(pn_1102_masraf_hesap):=true;
   else
      boolean_list(pn_1102_masraf_kasa):=true;
   end if;
 else
      boolean_list(pn_1102_masraf_yok):=true;
 end if;

/* karne tipi atamalari */

  if  PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = 'CONTINUOUS' then
      boolean_list(pn_1102_karne_continuous):=true;
   elsif   PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = '10' then
      boolean_list(pn_1102_karne_10):=true;
   else
        boolean_list(pn_1102_karne_25):=true;
   end if;

--Sevalb  22022011 SDLC8695_cheque_book Asagidaki kisim kapatiliyor her zaman lc olacak hale getiriliyor.
  boolean_list(pn_1102_doviz_tl):=true; --eklendi. 
 
/* d?viz tipi atamalari */
/*   if ls_doviz_kodu = pkg_genel.lc_al  then
      boolean_list(pn_1102_doviz_tl):=true;
   else
        boolean_list(pn_1102_doviz_yp):=true;
   end if;
   */
   
/**** number list ****/
     pkg_parametre.deger('1102_CEK_TUTAR_1_TL',number_list(pn_1102_cek_tutar_1_tl));

     number_list(pn_1102_cek_yaprak_adet)      := ln_cek_yaprak_adedi;
     number_list(pn_1102_kur_lc)                := 1;--pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     number_list(pn_1102_KUR)                  := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     number_list(pn_1102_LC_CEK_TUTAR_1_TL)   := number_list(pn_1102_cek_tutar_1_tl) * number_list(pn_1102_KUR) ;
    
     pkg_parametre.deger('G_SALES_TAX_RATE',ln_service_tax_rate);
     pkg_parametre.deger('G_VAT_RATE',ln_vat_tax_rate);

 

-- b-o-m sevalb 30032011
if  NVL(number_list(pn_1102_masraf_tutari),0 ) <> 0 then
   if varchar_list(pn_1102_masraf_hesap_doviz) =pkg_genel.lc_al then 
        boolean_list(pn_1102_masraf_lc) := true;
        number_list(pn_1102_masraf_tutari_lc) := number_list(pn_1102_masraf_tutari);    
--        number_list(pn_1102_vat_amount_lc) := number_list(pn_1102_vat_amount);    --sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri 
--        number_list(pn_1102_sales_tax_amount_lc) := number_list(pn_1102_sales_tax_amount);--sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
--        number_list(pn_1102_tax_total_amount_lc) := number_list(pn_1102_tax_total_amount);--sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
    else
        boolean_list(pn_1102_masraf_fc) :=  true;
        number_list(pn_1102_masraf_tutari_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(varchar_list(pn_1102_masraf_hesap_doviz),pkg_genel.LC_AL,null,number_list(pn_1102_masraf_tutari),1,null,null,'N','A') ) ;
--        number_list(pn_1102_vat_amount_lc)       := pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(varchar_list(pn_1102_masraf_hesap_doviz),pkg_genel.LC_AL,null,number_list(pn_1102_vat_amount),1,null,null,'N','A') ) ;--sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
 --       number_list(pn_1102_sales_tax_amount_lc) :=  pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(varchar_list(pn_1102_masraf_hesap_doviz),pkg_genel.LC_AL,null,number_list(pn_1102_sales_tax_amount),1,null,null,'N','A')) ;--sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
  --      number_list(pn_1102_tax_total_amount_lc) :=  number_list(pn_1102_masraf_tutari_lc)  + number_list(pn_1102_SALES_TAX_AMOUNT_lc) +   number_list(pn_1102_VAT_AMOUNT_lc);--sevalb 11052011  kapatildi lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
    end if;

 --b-o-m sevalb 11052011 lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
    if ls_sales_tax_alinsin = 'E' then --sevalb 02092011
       number_list(pn_1102_sales_tax_amount_lc)  :=  round((( number_list(pn_1102_masraf_tutari_LC) * nvl(ln_service_tax_rate,0)) /100) ,2);
       number_list(pn_1102_sales_tax_amount):= pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL,varchar_list(pn_1102_masraf_hesap_doviz),null,number_list(pn_1102_sales_tax_amount_lc),1,null,null,'N','A') ) ;
    else
         number_list(pn_1102_sales_tax_amount_lc)  := 0;
         number_list(pn_1102_sales_tax_amount):= 0;
    end if;
    if ls_vat_alinsin = 'E' then
       number_list(pn_1102_vat_amount_lc)  :=  round((( number_list(pn_1102_masraf_tutari_LC) * nvl(ln_vat_tax_rate,0)) /100) ,2);
       number_list(pn_1102_vat_amount):= pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL,varchar_list(pn_1102_masraf_hesap_doviz),null,number_list(pn_1102_vat_amount_lc),1,null,null,'N','A') ) ;
    else
      number_list(pn_1102_vat_amount_lc)  := 0;
      number_list(pn_1102_vat_amount):=  0 ;
    end if;  
--e-o-m sevalb 11052011 lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri   

    number_list(pn_1102_TAX_TOTAL_AMOUNT) :=  number_list(pn_1102_masraf_tutari)  + number_list(pn_1102_SALES_TAX_AMOUNT) +   number_list(pn_1102_VAT_AMOUNT); --sevalb 11052011 lc uzerinden sales tax tutarinin hesaplanmasi degisiklikleri
    number_list(pn_1102_tax_total_amount_lc) := number_list(pn_1102_masraf_tutari_lc)  + number_list(pn_1102_SALES_TAX_AMOUNT_lc) +   number_list(pn_1102_VAT_AMOUNT_lc);
end if;  
  --e-o-m sevalb 30032011

/**** date list ****/
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            ls_aciklama);

    pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

 Exception
  when dk_bulunamadi then
  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '743' || pkg_hata.getDelimiter || ls_dk_grup_kod  || pkg_hata.getDelimiter ||ls_masraf_kodu || pkg_hata.getUCPOINTER);
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '185' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

Begin
/* parametre index numaralar? bulunur.*/
    pn_1102_masraf_tutari             :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_TUTARI');
    pn_1102_masraf_hesap_no         :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_HESAP_NO');
    pn_1102_masraf_hesap_sube         :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_HESAP_SUBE');
    pn_1102_cek_islem_sube             :=pkg_muhasebe.parametre_index_bul('1102_CEK_ISLEM_SUBE');
    pn_1102_cek_tutar_1_tl             :=pkg_muhasebe.parametre_index_bul('1102_CEK_TUTAR_1_TL');
    pn_1102_cek_yaprak_adet         :=pkg_muhasebe.parametre_index_bul('1102_CEK_YAPRAK_ADET');
    pn_1102_banka_aciklama             :=pkg_muhasebe.parametre_index_bul('1102_BANKA_ACIKLAMA');
    pn_1102_musteri_aciklama         :=pkg_muhasebe.parametre_index_bul('1102_MUSTERI_ACIKLAMA');
    pn_1102_cek_referans             :=pkg_muhasebe.parametre_index_bul('1102_CEK_REFERANS');
    pn_1102_fis_aciklama             :=pkg_muhasebe.parametre_index_bul('1102_FIS_ACIKLAMA');
    pn_1102_kur_lc                     :=pkg_muhasebe.parametre_index_bul('1102_KUR_LC');
    pn_1102_masraf_kasa             :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_KASA');
    pn_1102_masraf_hesap             :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_HESAP');
    pn_1102_masraf_yok                 :=pkg_muhasebe.parametre_index_bul('1102_MASRAF_YOK');
    pn_1102_karne_continuous         :=pkg_muhasebe.parametre_index_bul('1102_KARNE_CONTINUOUS');
    pn_1102_karne_10                 :=pkg_muhasebe.parametre_index_bul('1102_KARNE_10');
    pn_1102_karne_25                 :=pkg_muhasebe.parametre_index_bul('1102_KARNE_25');
    pn_1102_doviz_tl                 :=pkg_muhasebe.parametre_index_bul('1102_DOVIZ_TL');
    pn_1102_doviz_yp                 :=pkg_muhasebe.parametre_index_bul('1102_DOVIZ_YP');
    pn_1102_cash_code                 :=pkg_muhasebe.parametre_index_bul('1102_CASH_CODE');
    pn_1102_istatistik_kodu            :=pkg_muhasebe.parametre_index_bul('1102_ISTATISTIK_KODU');
    Pn_1102_DK_CEK_MASRAF            :=pkg_muhasebe.parametre_index_bul('1102_DK_CEK_MASRAF');
    pn_1102_SALES_TAX_AMOUNT          :=pkg_muhasebe.parametre_index_bul('1102_SALES_TAX_AMOUNT');
    pn_1102_VAT_AMOUNT                :=pkg_muhasebe.parametre_index_bul('1102_VAT_AMOUNT');
    pn_1102_TAX_TOTAL_AMOUNT           :=pkg_muhasebe.parametre_index_bul('1102_TAX_TOTAL_AMOUNT');

    pn_1102_KUR                          :=pkg_muhasebe.parametre_index_bul('1102_KUR');
    pn_1102_DOVIZ_KODU                  :=pkg_muhasebe.parametre_index_bul('1102_DOVIZ_KODU');
    pn_1102_LC_CEK_TUTAR_1_TL         :=pkg_muhasebe.parametre_index_bul('1102_LC_CEK_TUTAR_1_TL');
    pn_1102_CASH_GL                    :=pkg_muhasebe.parametre_index_bul('1102_CASH_GL');
-- b-o-m sevalb 30032011
    pn_1102_MASRAF_LC := pkg_muhasebe.parametre_index_bul('1102_MASRAF_LC');
    pn_1102_MASRAF_FC := pkg_muhasebe.parametre_index_bul('1102_MASRAF_FC');
    pn_1102_VAT_AMOUNT_LC := pkg_muhasebe.parametre_index_bul('1102_VAT_AMOUNT_LC');
    pn_1102_MASRAF_TUTARI_LC := pkg_muhasebe.parametre_index_bul('1102_MASRAF_TUTARI_LC');
    pn_1102_SALES_TAX_AMOUNT_LC := pkg_muhasebe.parametre_index_bul('1102_SALES_TAX_AMOUNT_LC');
    pn_1102_TAX_TOTAL_AMOUNT_LC := pkg_muhasebe.parametre_index_bul('1102_TAX_TOTAL_AMOUNT_LC');
    pn_1102_MASRAF_HESAP_DOVIZ := pkg_muhasebe.parametre_index_bul('1102_MASRAF_HESAP_DOVIZ');
-- e-o-m sevalb 30032011   
  
    
END ;
/

