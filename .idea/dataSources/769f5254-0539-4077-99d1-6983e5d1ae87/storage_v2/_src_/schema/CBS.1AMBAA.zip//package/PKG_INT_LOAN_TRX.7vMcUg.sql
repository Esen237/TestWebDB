create PACKAGE     PKG_INT_LOAN_TRX IS

TYPE CursorReferenceType IS REF CURSOR;

FUNCTION PostPayInstallment(ps_lang varchar2,
                        ps_account_number varchar2,
                        ps_source_iban varchar2,
                        ps_channel_code varchar2 default '1',
                        ps_user_code varchar2 default 'CINT_CALLER',      
                        pc_ref OUT CursorReferenceType) RETURN varchar2;
                                                                                                                                                                                                                                                                                                                                                                                                                                               
END;
/

