create PACKAGE BODY     "PKG_SOA_DDS" 
AS
/******************************************************************************
   NAME:        log_invoice_upload
   PURPOSE:     Save the information (log) about the user file upload.
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
FUNCTION log_invoice_upload(    ps_person_id       IN  varchar2,
                                ps_tran_cd         IN  varchar2,
                                ps_filename        IN  varchar2,
                                ps_invoice_count   IN  varchar2,
                                ps_error_message   IN  varchar2,
                                pc_ref             OUT CursorReferenceType) RETURN varchar2
IS
    ls_returncode       varchar2(3):='000';
    ln_sequence_id      number;
BEGIN
    ln_sequence_id := CORPINT.PKG_COMMON.GETSEQUENCEID('TBLINVUPLOADSEQ');
    
    insert  into    corpint.tbl_invoice_file_upload
                    (id, tran_cd, filename,invoice_count, error_message, uploaded_by)
            values  (ln_sequence_id, ps_tran_cd, ps_filename, to_number(ps_invoice_count, '999999999999999'), ps_error_message, to_number(ps_person_id,'99999999999'));
    
    open pc_ref for select ln_sequence_id from dual;
    
    return ls_returncode;
    EXCEPTION
    WHEN OTHERS THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.LOG_INVOICE_UPLOAD',sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        insert_invoice
   PURPOSE:     Save the invoice to table for further processing
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
  FUNCTION insert_invoice(
                                ps_tran_cd         IN  varchar2,
                                ps_customer_id     IN  varchar2,
                                ps_file_upload_id  IN  varchar2,
                                ps_invoice_no      IN  varchar2,
                                ps_invoice_date    IN  varchar2,
                                ps_customer_okpo   IN  varchar2,
                                ps_customer_inn    IN  varchar2,
                                ps_customer_sfkr   IN  varchar2,
                                ps_customer_bank_bic   IN  varchar2,
                                ps_customer_name       IN  varchar2,
                                ps_customer_debit_account_no   IN  varchar2,
                                ps_customer_bank_name  IN  varchar2,
                                ps_beneficiar_name     IN  varchar2,
                                ps_beneficiar_cr_account_no    IN  varchar2,
                                ps_beneficiar_account_no           IN  varchar2,
                                ps_beneficiar_bank_bic IN  varchar2,
                                ps_beneficiar_bank_name    IN  varchar2,
                                ps_payment_code        IN  varchar2,
                                ps_payment_details     IN  varchar2,
                                ps_amount              IN  varchar2,
                                ps_currency            IN  varchar2,
                                ps_created_by          IN  varchar2,
                                ps_amount_in_words     IN  varchar2,
                                ps_alloc_reference     IN  varchar2,
                                ps_customer_ref_id     IN  varchar2,
                                pc_ref                 OUT  CursorReferenceType) RETURN VARCHAR2
IS
    ls_returncode       varchar2(3):='000';
    ln_sequence_id      number;
    
    ls_status           varchar2(10):='sNEW';
    ls_error_desc       varchar2(1000):='';
BEGIN
    ln_sequence_id := CORPINT.PKG_COMMON.GETSEQUENCEID('TBLINVOICESEQ');
    
    if (ps_currency is null OR instr('KGS, USD, EUR, RUB, KZT, TRY', ps_currency) = 0) THEN
        ls_status := 'sFAIL';
        ls_error_desc := 'Invalid Currency Code';
    end if;
    
    insert  into    
    CORPINT.TBL_INVOICE (   id,
                    customer_id,
                    file_upload_id,
                    invoice_no,
                    invoice_date,
                    customer_okpo,
                    customer_inn,
                    customer_sfkr,
                    customer_bank_bic,
                    customer_name,
                    customer_debit_account_no,
                    customer_bank_name,
                    beneficiar_name,
                    beneficiar_credit_account_no,
                    beneficiar_account_no,
                    beneficiar_bank_bic,
                    beneficiar_bank_name,
                    payment_code,
                    payment_details,
                    amount,
                    currency,
                    status,
                    created_by,
                    amount_in_words,
                    alloc_reference,
                    customer_ref_id,
                    tran_cd,
                    error_desc)
    VALUES  (
                    ln_sequence_id,
                    ps_customer_id,
                    to_number(ps_file_upload_id, '999999999'),
                    ps_invoice_no,
                    to_date(ps_invoice_date, 'YYYYMMDD'),
                    ps_customer_okpo,
                    ps_customer_inn,
                    ps_customer_sfkr,
                    ps_customer_bank_bic,
                    ps_customer_name,
                    ps_customer_debit_account_no,
                    ps_customer_bank_name,
                    ps_beneficiar_name,
                    ps_beneficiar_cr_account_no,
                    ps_beneficiar_account_no,
                    ps_beneficiar_bank_bic,
                    ps_beneficiar_bank_name,
                    ps_payment_code,
                    ps_payment_details,
                    to_number(ps_amount, '999999999999.99'),
                    ps_currency,
                    ls_status,
                    ps_created_by,
                    ps_amount_in_words,
                    ps_alloc_reference,
                    ps_customer_ref_id,
                    ps_tran_cd,
                    ls_error_desc
    );
    
    open pc_ref for select ln_sequence_id from dual;
    
    return ls_returncode;
    
    EXCEPTION
    WHEN   OTHERS THEN
        if pc_ref%isopen then
            close pc_ref;
        end if;
        --CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.INSERT_INVOICE',sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        process_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
FUNCTION process_invoice (      ps_channel_cd   IN    varchar2,
                                ps_customer_id  IN    varchar2,
                                ps_invoice_id   IN    varchar2) RETURN VARCHAR2
IS
    CURSOR  invoice_cursor  IS
        SELECT * FROM CORPINT.TBL_INVOICE inv
        WHERE   INV.CUSTOMER_ID = ps_customer_id
        AND     INV.ID          = to_number(ps_invoice_id, '999999999');
        
    invoice_row                 invoice_cursor%rowtype;
    ls_returncode               varchar2(3):='000';
    ln_debit_account_no         number;
    ln_debit_musteri_no         number;
    ln_credit_account_no         number;
    ln_credit_account_musteri_no number;
    lb_is_dbt_account_extrnl    boolean := false;
    lb_is_crd_account_intrnl    boolean := true;
    ln_clearing_max_amount      number;
    
    
    pc_ref                      cursorreferencetype;
    ls_status                   varchar2(10);
    ls_payment_table            varchar2(50);
    ln_txno                     number;
    ls_value_date               varchar2(10);
    ls_payment_method           varchar2(20);
    ls_tran_table               varchar2(50);
    ln_bic                      varchar2(5); -- cq4997 bic number urmata 11092015
    
    DEBIT_ACCOUNT_NOT_FOUND     EXCEPTION;
    NOT_CUSTOMERS_DEBIT_ACCOUNT EXCEPTION;
    INVALID_CURRENCY_FOR_CLEARING EXCEPTION;
    InvoiceNotFound             EXCEPTION;
    ALREADY_PROCESSED           EXCEPTION;
    TRANSFER_TO_SAME_ACCOUNT    EXCEPTION;
    DAILY_LIMIT_EXCEEDED        EXCEPTION;
    TRAN_LIMIT_EXCEEDED         EXCEPTION;
    LIMIT_CHECK_FAILED          EXCEPTION;
    BAKIYE_YETERLI_DEGIL        EXCEPTION;
    NOT_DB_ACCOUNT              EXCEPTION;  -- cq4997  urmata 11092015
    
    ls_nls_num_char cbs_parametre.deger%type; --CQ4965 numeric defect

BEGIN
    pkg_parametre.deger('NLS_NUMERIC_CHARACTERS', ls_nls_num_char);--CQ4965 numeric defect

    OPEN    invoice_cursor;
    FETCH   invoice_cursor INTO invoice_row;
    IF      invoice_cursor%NOTFOUND THEN
        RAISE InvoiceNotFound;
    END IF;   
    
    IF      invoice_row.status <> 'sNEW' THEN
        RAISE ALREADY_PROCESSED;
    END IF;
    
    ln_debit_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(invoice_row.customer_debit_account_no, invoice_row.currency); 
    
    if ln_debit_account_no is null then
        lb_is_dbt_account_extrnl := true;
        -- 001 - account not found
        update_invoice_status(ps_invoice_id, 'sFAIL', '001', 'Account for ' || invoice_row.customer_debit_account_no || ' and currency ' || invoice_row.currency || ' is not found');
        raise DEBIT_ACCOUNT_NOT_FOUND;
    end if;
    
    ln_debit_musteri_no := PKG_HESAP.HESAPTANMUSTERINOAL(ln_debit_account_no);
    
    if ln_debit_musteri_no <> ps_customer_id then
        update_invoice_status(ps_invoice_id, 'sFAIL', '003', 'Account ' || ln_debit_musteri_no || ' does not belong to customer '||ps_customer_id);
        raise NOT_CUSTOMERS_DEBIT_ACCOUNT;
    end if;
    
    ln_credit_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(invoice_row.beneficiar_credit_account_no, invoice_row.currency);
    
    if ln_credit_account_no is null then
        lb_is_crd_account_intrnl := false;
    end if;   
    
    /*Add check existence of account with DB bic cq4997 urmata 11092015 */
    if lb_is_crd_account_intrnl = false then
        pkg_parametre.deger('DB_BIC', ln_bic);
        if substr(invoice_row.beneficiar_credit_account_no,1,3) = ln_bic then
            raise NOT_DB_ACCOUNT;
        end if;
    end if;
    /* urmata 11092015 */
    
    ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_debit_account_no), 
                                                     to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point 
                                                     pc_ref);
    
    if pc_ref%isopen then
        close pc_ref;
    end if;
    
    if ls_returncode <> '000' then
        update_invoice_status(ps_invoice_id, 'sFAIL', '008', 'Account ' || ln_debit_account_no||' have not amount '||invoice_row.amount);
        raise BAKIYE_YETERLI_DEGIL;
    end if;

    if lb_is_crd_account_intrnl = true then
        ln_credit_account_musteri_no := PKG_HESAP.HESAPTANMUSTERINOAL(ln_credit_account_no);
        
        if ln_debit_account_no = ln_credit_account_no THEN
            update_invoice_status(ps_invoice_id, 'sFAIL', '004', 'Cannot make transfer B2B to the same account: ' || ln_debit_musteri_no || ', '||ln_debit_account_no||','||ln_credit_account_no);
            raise TRANSFER_TO_SAME_ACCOUNT;
        end if;
        
        if ln_debit_musteri_no = ln_credit_account_musteri_no THEN -- b2b
            ls_returncode := CORPINT.PKG_LIMIT.CHECKLIMIT(
                                to_char(ln_debit_musteri_no),
                                'B2BHVL',
                                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                                invoice_row.created_by,
                                ps_channel_cd,
                                '1',
                                invoice_row.currency,
                                pc_ref);
            if ls_returncode = '057' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '005', 'Amount exceeds the daily limit of company '||ln_debit_musteri_no||' for transaction B2BHVL');
                raise DAILY_LIMIT_EXCEEDED;
            elsif ls_returncode in ('052', '051') then
                update_invoice_status(ps_invoice_id, 'sFAIL', '006', 'Amount exceeds the tran limit of company '||ln_debit_musteri_no||' for transaction B2BHVL');
                raise TRAN_LIMIT_EXCEEDED;
            elsif ls_returncode = '050' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '007', 'Could not check limit of company '||ln_debit_musteri_no||' for transaction B2BHVL');
                raise LIMIT_CHECK_FAILED;
            end if;
            
            close pc_ref; 
            ls_returncode := create_b2b_transfer(
                    ps_channel_cd,
                    ps_customer_id,
                    to_char(ln_debit_account_no),
                    invoice_row.beneficiar_credit_account_no,
                    to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                    invoice_row.payment_details,
                    invoice_row.currency,
                    'X',
                    invoice_row.created_by,
                    invoice_row.beneficiar_name,
                    '',
                    '321;',
                    '',
                    '',
                    '',
                    invoice_row.invoice_no,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                    pc_ref);
             if(ls_returncode='000') then
                -- 000 - success
                fetch pc_ref into ls_status, ls_payment_table, ln_txno, ls_value_date;
                close pc_ref;
                
                update_invoice_status(ps_invoice_id, ls_status, '000', '');
                update_payment_info(ps_invoice_id, 'B2B', ls_payment_table, ls_value_date, ''||ln_txno);
            end if;
                                        
        else -- b2ob
            ls_returncode := CORPINT.PKG_LIMIT.CHECKLIMIT(
                                to_char(ln_debit_musteri_no),
                                'B2OBHVL',
                                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                                invoice_row.created_by,
                                ps_channel_cd,
                                '1',
                                invoice_row.currency,
                                pc_ref);
            if ls_returncode = '057' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '005', 'Amount exceeds the daily limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction B2OBHVL');
                raise DAILY_LIMIT_EXCEEDED;
            elsif ls_returncode in ('052', '051') then
                update_invoice_status(ps_invoice_id, 'sFAIL', '006', 'Amount exceeds the tran limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction B2OBHVL');
                raise TRAN_LIMIT_EXCEEDED;
            elsif ls_returncode = '050' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '007', 'Could not check limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction B2OBHVL');
                raise LIMIT_CHECK_FAILED;
            end if;

            close pc_ref;
             ls_returncode := create_b2ob_transfer(
                    ps_channel_cd,
                    ps_customer_id,
                    to_char(ln_debit_account_no),
                    invoice_row.beneficiar_credit_account_no,
                    to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                    invoice_row.payment_details,
                    invoice_row.currency,
                    'X',
                    invoice_row.created_by,
                    invoice_row.beneficiar_name,
                    '',
                    invoice_row.payment_code,
                    '',
                    '',
                    '',
                    invoice_row.invoice_no,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                    pc_ref);
            if(ls_returncode='000') then
                -- 000 - success
                fetch pc_ref into ls_status, ls_payment_table, ln_txno, ls_value_date;
                close pc_ref;
                
                update_invoice_status(ps_invoice_id, ls_status, '000', '');
                update_payment_info(ps_invoice_id, 'B2OB', ls_payment_table, ls_value_date, ''||ln_txno);
            end if;            
        end if;
    else -- clearing

        if  invoice_row.currency <> 'KGS' THEN
            -- 002 - invalid currency for clearing
            update_invoice_status(ps_invoice_id, 'sFAIL', '002', 'Cannot make clearing payment on currency '
                ||invoice_row.currency);
            RAISE INVALID_CURRENCY_FOR_CLEARING;
        end if;

        --cq4705 almasn 25042015
        
        if (instr(invoice_row.payment_details, '#GROSS#')>0) then
            ls_payment_method := 'GROSS';
        else
            ls_payment_method := 'CLEARING';
        end if;

        select  to_number(value, '999999999999999.9999') 
        into    ln_clearing_max_amount
        from    CORPINT.tbl_configuration
        where   key='cib.max.clearing.amount';
        
        if invoice_row.amount > ln_clearing_max_amount or ls_payment_method = 'GROSS' then -- gross --cq4705 almasn 25042015
            ls_returncode := CORPINT.PKG_LIMIT.CHECKLIMIT(
                                to_char(ln_debit_musteri_no),
                                'GROSS',
                                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                                invoice_row.created_by,
                                ps_channel_cd,
                                '1',
                                invoice_row.currency,
                                pc_ref);
            if ls_returncode = '057' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '005', 'Amount exceeds the daily limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction GROSS');
                raise DAILY_LIMIT_EXCEEDED;
            elsif ls_returncode in ('052', '051') then
                update_invoice_status(ps_invoice_id, 'sFAIL', '006', 'Amount exceeds the tran limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction GROSS');
                raise TRAN_LIMIT_EXCEEDED;
            elsif ls_returncode = '050' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '007', 'Could not check limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction GROSS');
                raise LIMIT_CHECK_FAILED;
            end if;
            
            close pc_ref;
            
            ls_returncode := create_gross_transfer(
                ps_channel_cd,
                ps_customer_id,
                invoice_row.created_by,
                to_char(ln_debit_account_no),
                to_char(invoice_row.invoice_date,'YYYYMMDD'),
                invoice_row.customer_name,
                '',
                invoice_row.beneficiar_bank_bic || ';' || invoice_row.beneficiar_bank_name,
                invoice_row.beneficiar_name,
                invoice_row.beneficiar_credit_account_no,
                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                replace(invoice_row.payment_details,'#GROSS#',''), --cq4705 almasn 28042015
                invoice_row.payment_code || ';' || invoice_row.payment_details,
                invoice_row.invoice_no,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                invoice_row.currency, -- Nursultan Mukhambet uulu 22.04.2022 ibc-101
                pc_ref
            );
            
            if(ls_returncode='000') then
                -- 000 - success
                fetch pc_ref into ls_status, ls_payment_table, ln_txno, ls_value_date;
                close pc_ref;
                
                update_invoice_status(ps_invoice_id, ls_status, '000', '');
                update_payment_info(ps_invoice_id, 'GROSS', ls_payment_table, ls_value_date, ''||ln_txno);
            end if;
        else -- clearing
            ls_returncode := CORPINT.PKG_LIMIT.CHECKLIMIT(
                                to_char(ln_debit_musteri_no),
                                'CLEARING',
                                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                                invoice_row.created_by,
                                ps_channel_cd,
                                '1',
                                invoice_row.currency,
                                pc_ref);
            if ls_returncode = '057' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '005', 'Amount exceeds the daily limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction CLEARING');
                raise DAILY_LIMIT_EXCEEDED;
            elsif ls_returncode in ('052', '051') then
                update_invoice_status(ps_invoice_id, 'sFAIL', '006', 'Amount exceeds the tran limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction CLEARING');
                raise TRAN_LIMIT_EXCEEDED;
            elsif ls_returncode = '050' then
                update_invoice_status(ps_invoice_id, 'sFAIL', '007', 'Could not check limit of company '||ln_debit_musteri_no||','||invoice_row.created_by||' for transaction CLEARING');
                raise LIMIT_CHECK_FAILED;
            end if;
            
            close pc_ref;
            
            ls_returncode := create_clearing_transfer(
                ps_channel_cd,
                ps_customer_id,
                invoice_row.created_by,
                to_char(ln_debit_account_no),
                to_char(invoice_row.invoice_date, 'YYYYMMDD'),
                invoice_row.customer_name,
                '',
                invoice_row.beneficiar_bank_bic || ';' || invoice_row.beneficiar_bank_name,
                invoice_row.beneficiar_name,
                invoice_row.beneficiar_credit_account_no,
                to_char(invoice_row.amount, '999999999999999999.99'), --CQ5826 decimal point changed --CQ4965 numeric defect, get only decimal point
                invoice_row.payment_details,
                invoice_row.payment_code || ';' || invoice_row.payment_details,
                invoice_row.invoice_no,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                invoice_row.currency,
                pc_ref
            );
            if(ls_returncode='000') then
                -- 000 - success
                fetch pc_ref into ls_status, ls_payment_table, ln_txno, ls_value_date;
                close pc_ref;
                
                update_invoice_status(ps_invoice_id, ls_status, '000', '');
                update_payment_info(ps_invoice_id, 'CLEARING', ls_payment_table, ls_value_date, ''||ln_txno);
            end if;
        end if;
    end if;
    
    close invoice_cursor;
    
    if(ls_returncode<>'000') then
        -- 999 - unknown error
        update_invoice_status(ps_invoice_id, 'sFAIL', '999', 'Unknow error with return code '||ls_returncode);
    end if;
    
    if pc_ref%isopen then
        close pc_ref;
    end if;
     
    return ls_returncode;
    
    EXCEPTION
    WHEN    ALREADY_PROCESSED               THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVOICE_ALREADY_PROCESSED', ps_invoice_id);
        return '042';
    WHEN    INVALID_CURRENCY_FOR_CLEARING   THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVALID_CURRENCY_FOR_CLEARING', ps_invoice_id);
        return '052';
    WHEN    DEBIT_ACCOUNT_NOT_FOUND THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'DEBIT_ACCOUNT_NOT_FOUND', ps_invoice_id);
        return '062';
    WHEN    InvoiceNotFound THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVOICE_NOT_FOUND', ps_invoice_id);
        return '072';
    WHEN    NOT_CUSTOMERS_DEBIT_ACCOUNT THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'NOT_CUSTOMERS_DEBIT_ACCOUNT', ps_invoice_id);
        return '073';
    WHEN    TRANSFER_TO_SAME_ACCOUNT    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'TRANSFER_TO_SAME_ACCOUNT', ps_invoice_id);
        return '074';
    WHEN    DAILY_LIMIT_EXCEEDED    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'DAILY_LIMIT_EXCEEDED', ps_invoice_id);
        return '075';
    WHEN    TRAN_LIMIT_EXCEEDED     THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'TRAN_LIMIT_EXCEEDED', ps_invoice_id);
        return '076';
    WHEN    LIMIT_CHECK_FAILED      THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'LIMIT_CHECK_FAILED', ps_invoice_id);
        return '077';
    WHEN    BAKIYE_YETERLI_DEGIL    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'BAKIYE_YETERLI_DEGIL', ps_invoice_id);
        return '078';
    WHEN    NOT_DB_ACCOUNT    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'NOT_DB_ACCOUNT', ps_invoice_id);
        return '079';
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE',sqlerrm, ps_invoice_id);
        return '999';
END;
/******************************************************************************
   NAME:        update_invoice_status
   PURPOSE:     To update the status of the payment
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
PROCEDURE update_invoice_status( ps_invoice_id   IN    varchar2,
                                ps_status       IN    varchar2,
                                ps_error_code   IN    varchar2,
                                ps_error_desc   IN    varchar2)
IS
BEGIN
    UPDATE   corpint.tbl_invoice
       SET   status = ps_status,
             ERROR_CODE = ps_error_code,
             error_desc = ps_error_desc
     WHERE   id = TO_NUMBER (ps_invoice_id);
    
    EXCEPTION
    WHEN OTHERS THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.UPDATE_INVOICE_STATUS', sqlerrm);
END;
/******************************************************************************
   NAME:        update_payment_info
   PURPOSE:     To set the payment information, to set transaction no by which
                payment was done, and set payment method 
                ('CLEARING', 'GROSS', ..)
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
PROCEDURE update_payment_info(  ps_invoice_id   IN  varchar2,
                                ps_payment_method   IN  varchar2,
                                ps_payment_table    IN  varchar2,
                                ps_value_date       IN  varchar2,
                                pn_txno         IN      varchar2)
IS
BEGIN
    UPDATE   corpint.tbl_invoice
       SET   payment_method = ps_payment_method,
             payment_table  = ps_payment_table,
             value_date     = to_date(ps_value_date, 'YYYYMMDD'),
             tx_ref_id      = to_number(pn_txno, '99999999999999')
     WHERE   id = TO_NUMBER (ps_invoice_id);
    
    EXCEPTION
    WHEN OTHERS THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.UPDATE_INVOICE_STATUS', sqlerrm);
END;
/******************************************************************************
   NAME:        refresh_invoice_statuses
   PURPOSE:     To refresh invoice statuses, to refresh if the transactions were
                approved, canceled, done and so on.
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
PROCEDURE refresh_invoice_statuses( ps_customer_id   IN  varchar2)
IS
    ls_return_code varchar2(3);
BEGIN
    UPDATE   corpint.tbl_invoice
       SET   status = case 
                        when lower(payment_table)='corpint.tbl_txtodo' then
                            decode((select txtodo.status from corpint.tbl_txtodo txtodo where TXTODO.TX_NO=tx_ref_id), 
                                'sDONE', 'sDONE', 'sVERIFY', 'sVERIFY', 'sAPPROVE', 'sAPPROVE', 'sCHECK', 'sCHECK', 
                                'sEXPIRED', 'sEXPIRED', 'sWAIT', 'sWAIT', 'sNEW')
                        else
                            'sDONE'
                      end
     WHERE   customer_id = ps_customer_id
     AND     status not in ('sDONE', 'sFAIL', 'sCANCEL', 'sEXPIRED', 'sNAPPROVED')
     AND     tx_ref_id is not null;
END;
/******************************************************************************
   NAME:        create_b2b_transfer
   PURPOSE:     To create b2b transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
FUNCTION create_b2b_transfer(   ps_channel_cd   IN      varchar2,
                                ps_customer_id  IN      varchar2,
                                ps_fromaccount  IN      varchar2,
                                ps_toaccount    IN      varchar2,
                                ps_amount       IN      varchar2,
                                ps_description  IN      varchar2,
                                ps_currencycode IN      varchar2,
                                ps_discontistiyormu IN  varchar2,
                                ps_person_id        IN  varchar2,
                                ps_payeename        IN  varchar2,
                                ps_internalacc      IN  varchar2,
                                ps_paymentcode      IN  varchar2,
                                ps_fromirsseco      IN  varchar2,
                                ps_toirsseco        IN  varchar2,
                                ps_commission       IN  varchar2,
                                ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                pc_ref              OUT CursorReferenceType) return VARCHAR2
IS
    ls_returncode   varchar2(3):='000';
    ls_txtodo_stat  varchar2(10);
    lc_ref          CORPINT.PKG_ADMIN.cursorReferencetype;
    ln_islem_no     number;
    
BEGIN
    ls_returncode := CORPINT.PKG_ADMIN.NEEDAPPROVE(ps_customer_id, 'B2BHVL', '', lc_ref);
    fetch lc_ref into ls_txtodo_stat;
    close lc_ref;
            
    if ls_txtodo_stat = 'sMAKE' then
        ls_returncode := CBS.PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER(
            ps_fromaccount, 
            ps_toaccount, 
            ps_amount, 
            ps_description, 
            ps_currencycode, 
            ps_discontistiyormu, 
            ps_paymentcode,
--            ' ',  --chyngyzo cq1264 add payment order number parameter
            ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
            lc_ref);
   
        if ls_returncode = '000' then
            fetch lc_ref into ln_islem_no;
            close lc_ref;
            
            ls_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(
                                ps_customer_id,
                                'B2BHVL',
                                ps_amount,
                                ps_currencycode,
                                ps_person_id,
                                ps_channel_cd,
                                '1',
                                pc_ref);
            ls_returncode := '000';
            close pc_ref;
            
            open pc_ref for select 'sDONE', 'cbs.cbs_virman_islem', ln_islem_no, to_char(sysdate, 'YYYYMMDD') from dual;
        end if;
    else
        ls_returncode := CORPINT.PKG_AUTH.BOOKTOBOOKTRANSFERTODO(
            ps_fromaccount,
            ps_toaccount,
            ps_amount,
            ps_description,
            ps_currencycode,
            ps_discontistiyormu,
            ls_txtodo_stat,
            ps_person_id,
            'B2BHVL',
            ps_payeename,
            ps_internalacc,
            ps_paymentcode,
            ps_fromirsseco,
            ps_toirsseco,
            ps_commission,
--            ' ', --chyngyzo cq1264 add payment order number parameter
            ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
            lc_ref);
        if ls_returncode = '000' then
            fetch lc_ref into ln_islem_no;
            close lc_ref;
            
            open pc_ref for select ls_txtodo_stat, 'corpint.tbl_txtodo', ln_islem_no, to_char(sysdate, 'YYYYMMDD') from dual;
        end if;
    end if;
    
    return ls_returncode;
    
    EXCEPTION
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.CREATE_B2B_TRANSFER',sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        create_b2ob_transfer
   PURPOSE:     To create b20b transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
FUNCTION create_b2ob_transfer(  ps_channel_cd   IN      varchar2, 
                                ps_customer_id  IN      varchar2,
                                ps_fromaccount  IN      varchar2,
                                ps_toaccount    IN      varchar2,
                                ps_amount       IN      varchar2,
                                ps_description  IN      varchar2,
                                ps_currencycode IN      varchar2,
                                ps_discontistiyormu IN  varchar2,
                                ps_person_id        IN  varchar2,
                                ps_payeename        IN  varchar2,
                                ps_internalacc      IN  varchar2,
                                ps_paymentcode      IN  varchar2,
                                ps_fromirsseco      IN  varchar2,
                                ps_toirsseco        IN  varchar2,
                                ps_commission       IN  varchar2,
                                ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                pc_ref              OUT CursorReferenceType) return VARCHAR2
IS
    ls_returncode   varchar2(3):='000';
    ls_txtodo_stat  varchar2(10);
    ln_islem_no     number;
    lc_ref          CORPINT.pkg_admin.cursorReferencetype;
BEGIN

    ls_returncode := CORPINT.PKG_ADMIN.NEEDAPPROVE(ps_customer_id, 'B2OBHVL', '', lc_ref);
    fetch lc_ref into ls_txtodo_stat;
    close lc_ref;
            
    if ls_txtodo_stat = 'sMAKE' then
        ls_returncode := CBS.PKG_INT_TRANSFER.BOOKTOBOOKTRANSFER(
            ps_fromaccount, 
            ps_toaccount, 
            ps_amount, 
            ps_description, 
            ps_currencycode, 
            ps_discontistiyormu, 
            ps_paymentcode,
--            ' ',--chyngyzo cq1264 add payment order number parameter
            ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
            lc_ref);
        if ls_returncode = '000' then
            fetch lc_ref into ln_islem_no;
            close lc_ref;
            
            ls_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(
                            ps_customer_id,
                            'B2OBHVL',
                            ps_amount,
                            ps_currencycode,
                            ps_person_id,
                            ps_channel_cd,
                            '1',
                            pc_ref);
            ls_returncode := '000';
            close pc_ref;
            
            open pc_ref for select 'sDONE', 'cbs.cbs_virman_islem', ln_islem_no, to_char(sysdate, 'YYYYMMDD') from dual;
        end if;
    else
        ls_returncode := CORPINT.PKG_AUTH.BOOKTOBOOKTRANSFERTODO(
            ps_fromaccount,
            ps_toaccount,
            ps_amount,
            ps_description,
            ps_currencycode,
            ps_discontistiyormu,
            ls_txtodo_stat,
            ps_person_id,
            'B2OBHVL',
            ps_payeename,
            ps_internalacc,
            ps_paymentcode,
            ps_fromirsseco,
            ps_toirsseco,
            ps_commission,
--            ' ',--chyngyzo cq1264 add payment order number parameter
            ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
            lc_ref);
        if ls_returncode = '000' then
            fetch lc_ref into ln_islem_no;
            close lc_ref;
            
            open pc_ref for select ls_txtodo_stat, 'corpint.tbl_txtodo', ln_islem_no, to_char(sysdate, 'YYYYMMDD') from dual;
        end if;
    end if;
    
    return ls_returncode;
    
    EXCEPTION
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.CREATE_B2OB_TRANSFER',sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        create_gross_transfer
   PURPOSE:     To create gross transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
function create_gross_transfer(     ps_channel_cd   IN  varchar2,
                                    ps_customer_id  IN  varchar2,
                                    ps_person_id    IN  varchar2,
                                    ps_fromaccount  IN  varchar2,
                                    ps_transfer_date    IN  varchar2,
                                    ps_sender_name      IN  varchar2,
                                    ps_sender_phone     IN  varchar2,
                                    ps_bank_code        IN  varchar2,
                                    ps_payee_name       IN  varchar2,
                                    ps_toaccount    IN  varchar2,
                                    ps_amount       IN  varchar2,
                                    ps_description  IN  varchar2,
                                    ps_payment_code      IN  varchar2,
                                    ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                    ps_currency        IN  varchar2, -- Nursultan Mukhambet uulu 22.04.2022 ibc-101
                                    pc_ref              OUT CursorReferenceType) return VARCHAR2
IS
    ls_returncode   varchar2(3):='000';
    ls_txtodo_stat  varchar2(10);
    lc_admin_ref          CORPINT.pkg_admin.cursorReferencetype;
    lc_soa_inquiry_ref    CBS.PKG_SOA_INQUIRY.CURSORREFERENCETYPE;
    
    ln_islem_no     number;
    ls_refno        varchar2(20);
   
    ls_tran_date    varchar2(10);
    ln_tmp          number;
    ls_ileri_gun    varchar2(10);
    ls_ileri_is_gun  varchar2(10);
    ls_ileri_gun2  varchar2(10);
    
    l_ref_cur sys_refcursor;
    l_ret_code varchar2(100);
    ln_commission number;
    ln_tax_rate number;
    ln_tax_rate_comm number;
BEGIN
    l_ret_code := pkg_int.GetCommission('GROSS' ,
                       ps_fromaccount,
                       ps_toaccount,
                       ps_amount,
                       ps_currency,
                       l_ref_cur);
    
    fetch l_ref_cur into ln_commission, ln_tax_rate, ln_tax_rate_comm;
    close l_ref_cur;

    ls_returncode := CORPINT.PKG_ADMIN.NEEDAPPROVE(ps_customer_id, 'GROSS', '', lc_admin_ref);
    fetch lc_admin_ref into ls_txtodo_stat;
    close lc_admin_ref;
    
    ls_returncode := CBS.PKG_SOA_INQUIRY.GETEFTDATE(ps_transfer_date, 'GROSS', lc_soa_inquiry_ref);
    
    fetch lc_soa_inquiry_ref into ls_tran_date, ln_tmp, ls_ileri_gun, ls_ileri_is_gun, ls_ileri_gun2;
    close lc_soa_inquiry_ref;
    
    if ls_txtodo_stat = 'sMAKE' THEN
        ls_returncode := CBS.PKG_INT_TRANSFER.MAKEEFT(
                ps_fromaccount,
                '',
                ls_tran_date,
                ps_sender_name,
                ps_sender_phone,
                ps_bank_code,
                ps_payee_name,
                ps_toaccount,
                ps_amount,
                ps_description,
                'H',
                '',
                ps_payment_code,
                '',
                '',
                '',
                'GROSS',
--                '', -- ernestk 13062014 cqdb864 add order number column
                ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                lc_soa_inquiry_ref);
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ls_refno, ln_islem_no;
            close lc_soa_inquiry_ref;
            
            ls_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(
                            ps_customer_id,
                            'GROSS',
                            ps_amount,
                            'KGS',
                            ps_person_id,
                            ps_channel_cd,
                            '1',
                            pc_ref);
            ls_returncode := '000';
            close pc_ref;
            
            open pc_ref for select 'sDONE', 'cbs.cbs_clearing_islem', ln_islem_no, ls_tran_date from dual;
        end if;
    else
        ls_returncode := CORPINT.PKG_AUTH.CLEARINGTODO(
                ps_fromaccount,
                '',
                ls_tran_date,
                ps_sender_name,
                ps_sender_phone,
                ps_bank_code,
                ps_payee_name,
                ps_toaccount,
                ps_amount,
                ps_description,
                'H',
                '',
                ps_payment_code,
                ls_txtodo_stat,
                ps_person_id,
                '',
                '',
                '',
                ln_commission,
                'GROSS',
--                '',--ernestk 13062014 cqdb864 add order number column
                ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                lc_soa_inquiry_ref);
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ln_islem_no;
            close lc_soa_inquiry_ref;
            
           open pc_ref for select ls_txtodo_stat, 'corpint.tbl_txtodo', ln_islem_no, ls_tran_date from dual;
        end if;
    end if;
    return ls_returncode;
    
    EXCEPTION
    WHEN OTHERS THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.CREATE_GROSS_TRANSFER', sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        create_clearing_transfer
   PURPOSE:     To create clearing transaction
   PREPARED BY: Ernest Kuttubaev
   DATE:        17.02.2014     
******************************************************************************/
FUNCTION create_clearing_transfer(  ps_channel_cd       IN  varchar2,
                                    ps_customer_id      IN  varchar2,
                                    ps_person_id        IN  varchar2,
                                    ps_fromaccount      IN  varchar2,
                                    ps_transfer_date    IN  varchar2,
                                    ps_sender_name      IN  varchar2,
                                    ps_sender_phone     IN  varchar2,
                                    ps_bank_code        IN  varchar2,
                                    ps_payee_name       IN  varchar2,
                                    ps_toaccount        IN  varchar2,
                                    ps_amount           IN  varchar2,
                                    ps_description      IN  varchar2,
                                    ps_payment_code     IN  varchar2,
                                    ps_reference       IN  varchar2,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                                    ps_currency        IN  varchar2, -- Nursultan Mukhambet uulu 22.04.2022 ibc-101
                                    pc_ref              OUT cursorReferenceType) return VARCHAR2
IS
    ls_returncode   varchar2(3):='000';
    ls_txtodo_stat  varchar2(10);
    lc_admin_ref          CORPINT.pkg_admin.cursorReferencetype;
    lc_soa_inquiry_ref    CBS.PKG_SOA_INQUIRY.CURSORREFERENCETYPE;
    
    ls_refno        varchar2(20);
    ln_islem_no     number;
    
    ls_tran_date    varchar2(10);
    ln_tmp          number;
    ls_ileri_gun    varchar2(10);
    ls_ileri_is_gun  varchar2(10);
    ls_ileri_gun2  varchar2(10);
    
    l_ref_cur sys_refcursor;
    l_ret_code varchar2(100);
    ln_commission number;
    ln_tax_rate number;
    ln_tax_rate_comm number;
    
BEGIN
l_ret_code := pkg_int.GetCommission('CLEARING' ,
                       ps_fromaccount,
                       ps_toaccount,
                       ps_amount,
                       ps_currency,
                       l_ref_cur);
fetch l_ref_cur into ln_commission, ln_tax_rate, ln_tax_rate_comm;
    close l_ref_cur;

CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','1');
    ls_returncode := CORPINT.PKG_ADMIN.NEEDAPPROVE(ps_customer_id, 'CLEARING', '', lc_admin_ref);
    fetch lc_admin_ref into ls_txtodo_stat;
    close lc_admin_ref;
    
    ls_returncode := CBS.PKG_SOA_INQUIRY.GETEFTDATE(ps_transfer_date, 'CLEARING', lc_soa_inquiry_ref);
    CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','2');
    fetch lc_soa_inquiry_ref into ls_tran_date, ln_tmp, ls_ileri_gun, ls_ileri_is_gun, ls_ileri_gun2;
    close lc_soa_inquiry_ref;
    CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','21');
    if ls_txtodo_stat = 'sMAKE' then
    CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','22');
        ls_returncode := CBS.PKG_INT_TRANSFER.MAKEEFT(
                ps_fromaccount,
                '',
                ls_tran_date,
                ps_sender_name,
                ps_sender_phone,
                ps_bank_code,
                ps_payee_name,
                ps_toaccount,
                ps_amount,
                ps_description,
                'H',
                '',
                ps_payment_code,
                '',
                '',
                '',
                'CLEARING',
--                '', --ernestk 13062014 cqdb864 add order number column
                ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                lc_soa_inquiry_ref);
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ls_refno, ln_islem_no;
            close lc_soa_inquiry_ref;
            
            ls_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(
                            ps_customer_id,
                            'CLEARING',
                            ps_amount,
                            'KGS',
                            ps_person_id,
                            ps_channel_cd,
                            '1',
                            pc_ref);
            ls_returncode := '000';
            close pc_ref;
            
            open pc_ref for select 'sDONE', 'cbs.cbs_clearing_islem', ln_islem_no, ls_tran_date from dual;
        end if;
                CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','3');
    else
    CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','23', ln_commission);
        ls_returncode := corpint.pkg_auth.clearingtodo(
                ps_fromaccount,
                '',
                ls_tran_date,
                ps_sender_name,
                ps_sender_phone,
                ps_bank_code,
                ps_payee_name,
                ps_toaccount,
                ps_amount,
                ps_description,
                'H',
                '',
                ps_payment_code,
                ls_txtodo_stat,
                ps_person_id,
                '',
                '',
                '',
                TO_CHAR(ln_commission),
                'CLEARING',
--                '', --ernestk 13062014 cqdb864 add order number column
                ps_reference,--Azat Dzhanybekov 02.03.2021 added new parameter ibc-59
                lc_soa_inquiry_ref);
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ln_islem_no;
            close lc_soa_inquiry_ref;
            CORPINT.PKG_LOG.ADDCUSTOMLOG('nursTest','4');
            open pc_ref for select ls_txtodo_stat, 'corpint.tbl_txtodo', ln_islem_no, ls_tran_date from dual;
        end if;
    end if;
    
    return ls_returncode;
    
    EXCEPTION   
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.CREATE_CLEARING_TRANSFER',sqlerrm);
        return '999';
END;
/******************************************************************************
   NAME:        insert_swift_invoice
   PURPOSE:     Save the invoice to table for further processing
   PREPARED BY: Azat Dzhanybekov
   DATE:        17.12.2020
******************************************************************************/
  FUNCTION insert_swift_invoice(  
               ps_customer_debit_account_no   IN  varchar2, 
               ps_value_date          IN  varchar2,   
               ps_amount              IN  varchar2, 
               ps_currency            IN  varchar2,   
               ps_commission_type IN  varchar2,    
               ps_commission_account_no IN  varchar2, 
               ps_beneficiar_country_code   IN  varchar2,
               ps_beneficiar_bank_bic IN  varchar2,
               ps_beneficiar_cr_account_no    IN  varchar2, 
               ps_beneficiar_name     IN  varchar2,
               ps_beneficiar_address   IN  varchar2,
               ps_beneficiar_bank_branch_name    IN  varchar2,
               ps_payment_code        IN  varchar2,
               ps_payment_details     IN  varchar2,
               ps_contract_date    IN  varchar2,
               ps_contract_no      IN  varchar2,
               ps_invoice_date    IN  varchar2,
               ps_invoice_no      IN  varchar2, 
               ps_customer_id     IN  varchar2,    
               ps_created_by          IN  varchar2,                  
               pc_ref                 OUT  CursorReferenceType) RETURN VARCHAR2
IS
    ls_returncode       varchar2(3):='000';
    ln_sequence_id      number;
    
    ls_status           varchar2(10):='sNEW';
    ls_error_desc       varchar2(1000):='';
BEGIN
    ln_sequence_id := CORPINT.PKG_COMMON.GETSEQUENCEID('TBLINVOICESEQ');
    log_at('insert_swift_invoice','begin');
--    log_at('insert_swift_invoice',
--    ps_tran_cd||','||ps_customer_id||','||ps_invoice_no||','||ps_invoice_date||','||ps_contract_no||','||ps_contract_date||','||ps_customer_name||','||ps_customer_debit_account_no||','||
--    ps_customer_bank_name||','||ps_commission_type||','||ps_commission_account_no||','||ps_beneficiar_name||','||ps_beneficiar_cr_account_no||','||ps_beneficiar_bank_bic||
--    ps_beneficiar_bank_branch_name||','||ps_beneficiar_country_code||','||ps_beneficiar_address||','||ps_payment_code||','||ps_payment_details||','||ps_amount||','||
--    ps_currency||','||ps_created_by||','||ps_charge_amount);
    if (ps_currency is null OR instr('KGS, USD, EUR, RUB, KZT, TRY', ps_currency) = 0) THEN
        ls_status := 'sFAIL';
        ls_error_desc := 'Invalid Currency Code';
    end if;
    log_at('insert_swift_invoice','before insert');
    insert  into    
    CORPINT.TBL_INVOICE (   id,                 
                    invoice_no,
                    invoice_date,    
                    contract_no,
                    contract_date,                    
                    customer_debit_account_no,
                    commission_type,
                    commission_account_no,      
                    beneficiar_name,
                    beneficiar_credit_account_no,                    
                    beneficiar_bank_bic,
                    beneficiar_bank_branch_name,
                    beneficiar_country_code,
                    beneficiar_address,
                    payment_code,
                    payment_details,
                    amount,
                    currency,
                    status,
                    error_desc,
                    value_date,
                    customer_id,
                    created_by,
                    customer_name
                   )
    VALUES  (
                    ln_sequence_id,
                 
                    ps_invoice_no,
                    to_date(ps_invoice_date, 'YYYYMMDD'),
                    ps_contract_no,
                    to_date(ps_contract_date, 'YYYYMMDD'),                        

                    ps_customer_debit_account_no,

                    ps_commission_type,
                    ps_commission_account_no,                    
                    ps_beneficiar_name,
                    ps_beneficiar_cr_account_no,                    
                    ps_beneficiar_bank_bic,
                    ps_beneficiar_bank_branch_name,
                    ps_beneficiar_country_code,
                    ps_beneficiar_address,
                    ps_payment_code,
                    ps_payment_details,
                    to_number(ps_amount, '999999999999.99'),
                    ps_currency,
                    ls_status,                 
                    ls_error_desc,
                    to_date(ps_value_date, 'YYYYMMDD'),
                    ps_customer_id,
                    ps_created_by,
                    pkg_musteri.Sf_Musteri_Adi(ps_customer_id)                    
    );
    log_at('insert_swift_invoice','after insert');
    open pc_ref for select ln_sequence_id from dual;
    
    return ls_returncode;
    
    EXCEPTION
    WHEN   OTHERS THEN
        if pc_ref%isopen then
            close pc_ref;
        end if;
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.INSERT_SWIFT_INVOICE',sqlerrm);
        return '999';
END;        

/******************************************************************************
   NAME:        process_swift_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Azat Dzhanybekov
   DATE:        21.12.2020
******************************************************************************/
FUNCTION process_swift_invoice (      ps_channel_cd   IN    varchar2,
                                ps_customer_id  IN    varchar2,
                                ps_invoice_id   IN    varchar2) RETURN VARCHAR2
IS
    CURSOR  invoice_cursor  IS
        SELECT * FROM CORPINT.TBL_INVOICE inv
        WHERE   INV.CUSTOMER_ID = ps_customer_id
        AND     INV.ID          = to_number(ps_invoice_id, '999999999');
        
    invoice_row                 invoice_cursor%rowtype;
    ls_returncode               varchar2(3):='000';
    
    ln_debit_account_no         number;
    ln_debit_musteri_no         number;
    ln_credit_account_no         number;
    ln_credit_account_musteri_no number;
    lb_is_dbt_account_extrnl    boolean := false;
    lb_is_crd_account_intrnl    boolean := true;
    ln_clearing_max_amount      number;
    
    
    ln_commission_account_no         number;
    ln_commission_musteri_no         number;
    ln_commission_amount         number :=0;
    
    
    pc_ref                      cursorreferencetype;
    ls_status                   varchar2(10);
    ls_payment_table            varchar2(50);
    ln_txno                     number;
    ls_value_date               varchar2(10);
    ls_payment_method           varchar2(20);
    ls_tran_table               varchar2(50);
    
    str1 varchar2(201);
    str2 varchar2(201);
    str3 varchar2(201);
    str4 varchar2(201);
    str5 varchar2(201);
    str6 varchar2(201);
    str7 varchar2(201);
    str8 varchar2(201);
    str9 varchar2(201);
    str10 varchar2(201);
    str11 varchar2(201);
    str12 varchar2(201);
    str13 varchar2(201);
    str14 varchar2(201);
    str15 varchar2(201);
    str16 varchar2(201);
    str17 varchar2(201);
    str18 varchar2(201);
    str19 varchar2(201);
    str20 varchar2(201);
    str21 varchar2(201);
    str22 varchar2(201);
    str23 varchar2(201);
--    i number :=0;
--AzatD 15.03.21 added variables to save numeric outputs of pacakges
    num1 number;
    num2 number;
    num3 number;
    num4 number;
    num5 number;
    num6 number;
    num7 number;
    num8 number;
    num9 number;
    
    ben_country_name varchar2(201);
    ben_bank_bic varchar2(201);
    commission varchar2(201);
    payment_code varchar2(201) :=null;
    correspondent_bank_name varchar2(201);
    ln_value_date varchar2(12);        
    
    DEBIT_ACCOUNT_NOT_FOUND     EXCEPTION;--handled
    NOT_CUSTOMERS_DEBIT_ACCOUNT EXCEPTION;--handled
    INVALID_CURRENCY_FOR_SWIFT  EXCEPTION;--handled
    InvoiceNotFound             EXCEPTION;
    ALREADY_PROCESSED           EXCEPTION;
    TRANSFER_TO_SAME_ACCOUNT    EXCEPTION;
    DAILY_LIMIT_EXCEEDED        EXCEPTION;
    TRAN_LIMIT_EXCEEDED         EXCEPTION;
    LIMIT_CHECK_FAILED          EXCEPTION;
    BAKIYE_YETERLI_DEGIL        EXCEPTION;--handled
    VALUE_DATE_INVALID          EXCEPTION;--handled
    COMMISSION_ACCOUNT_NOT_FOUND     EXCEPTION;--handled
    NOT_CUSTOMERS_CMMSSN_ACCOUNT EXCEPTION;--handled
    INVALID_COUNTRY_CODE_EXCEPTION EXCEPTION;--handled
    INVALID_BANK_BIC EXCEPTION;--handled
    INVALID_PAYMENT_CODE EXCEPTION;
    VALUE_DATE_NOT_WORKING_DAY  EXCEPTION;--AzatD 23.03.2021 ibc-53
       
BEGIN
log_at('process_swift_invoice','1 begin',ps_invoice_id);
    OPEN    invoice_cursor;
    FETCH   invoice_cursor INTO invoice_row;
    IF      invoice_cursor%NOTFOUND THEN
        RAISE InvoiceNotFound;
    END IF;   
   
   log_at('process_swift_invoice','2 before ALREADY_PROCESSED',ps_invoice_id);
    IF      invoice_row.status <> 'sNEW' THEN
        RAISE ALREADY_PROCESSED;
    END IF;
    log_at('process_swift_invoice','3 before length(invoice_row.customer_debit_account_no)>=16',ps_invoice_id);
    if length(invoice_row.customer_debit_account_no)>=16 then            
        ln_debit_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(invoice_row.customer_debit_account_no, invoice_row.currency);
    else 
        ln_debit_account_no := pkg_hesap.External_HesapNo_Al(invoice_row.customer_debit_account_no);
        ln_debit_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(ln_debit_account_no, invoice_row.currency);
--        ln_debit_account_no := invoice_row.customer_debit_account_no;
    end if; 
    --raise exception if debit account not found from external no
    log_at('process_swift_invoice','4 before DEBIT_ACCOUNT_NOT_FOUND',ps_invoice_id||','||ln_debit_account_no);
    if ln_debit_account_no is null then
        lb_is_dbt_account_extrnl := true;
        -- 001 - account not found
        update_invoice_status(ps_invoice_id, 'sFAIL', '001', 'Account for ' || invoice_row.customer_debit_account_no || ' and currency ' || invoice_row.currency || ' is not found');
        raise DEBIT_ACCOUNT_NOT_FOUND;
    end if;
    
    ln_debit_musteri_no := PKG_HESAP.HESAPTANMUSTERINOAL(ln_debit_account_no);
    --raise exception if debit account does not belong to customer
    log_at('process_swift_invoice','5 before NOT_CUSTOMERS_DEBIT_ACCOUNT',ln_debit_musteri_no||','||ps_customer_id);
    if ln_debit_musteri_no <> ps_customer_id then
        update_invoice_status(ps_invoice_id, 'sFAIL', '003', 'Account ' || ln_debit_musteri_no || ' does not belong to customer '||ps_customer_id);
        raise NOT_CUSTOMERS_DEBIT_ACCOUNT;
    end if;
    
    
    
    

    
  --START OF CHECK BAKIYE FOR MAIN AMOUNT bakiye yeterli mi?
    
    ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_debit_account_no),  TO_CHAR((invoice_row.amount),'99999999999.99'), pc_ref);--AzatD added number to char formatter
 
    if pc_ref%isopen then
        close pc_ref;
    end if;
    log_at('process_swift_invoice','6 before BAKIYE_YETERLI_DEGIL');
    if ls_returncode <> '000' then
        update_invoice_status(ps_invoice_id, 'sFAIL', '008', 'Account ' || ln_debit_account_no||' have not amount '||invoice_row.amount);
        raise BAKIYE_YETERLI_DEGIL;
    end if;
 
--    if pc_ref%isopen then
--        close pc_ref;
--    end if;   
--    log_at('process_swift_invoice','before BAKIYE_YETERLI_DEGIL');
--    if ls_returncode <> '000' then
--        update_invoice_status(ps_invoice_id, 'sFAIL', '018', 'Commission Account ' || ln_commission_account_no||' have not amount '||invoice_row.charge_amount);
--        raise BAKIYE_YETERLI_DEGIL;
--    end if;
       
    log_at('process_swift_invoice','7 after BAKIYE_YETERLI_DEGIL check',ps_invoice_id);
--END OF CHECK BAKIYE FOR MAIN AMOUNT bakiye yeterli mi?    
    if  invoice_row.currency = 'KGS' THEN
        -- 002 - invalid currency for swift
        update_invoice_status(ps_invoice_id, 'sFAIL', '002', 'Cannot make swift payment on currency '
            ||invoice_row.currency);
        RAISE INVALID_CURRENCY_FOR_SWIFT;
    end if;
        
    

--START OF COUNTRY-CODE CHECK-----------------------------------

    ls_returncode :=cbs.pkg_soa_inquiry.SwiftCountryName(ps_customer_id,pc_ref);
    log_at('process_swift_invoice','8 Expected Country code:'||invoice_row.beneficiar_country_code||'. Return code ',ls_returncode);
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;
    
    LOOP
        fetch pc_ref into str1, str2;
        exit when pc_ref%notfound or instr(str1, invoice_row.beneficiar_country_code)>0;
    END LOOP;
    CLOSE pc_ref;
    log_at('process_swift_invoice','9 Expected Country code:'||invoice_row.beneficiar_country_code||'. Found ',str1);
    IF instr(invoice_row.beneficiar_country_code,str1)=0 THEN 
        update_invoice_status(ps_invoice_id, 'sFAIL', '019', 'Country code ' || invoice_row.beneficiar_country_code || ' is not valid for SWIFT ');
        RAISE INVALID_COUNTRY_CODE_EXCEPTION;
    END IF;
--END OF COUNTRY-CODE CHECK-----------------------------------
    
    
        
--START OF COMMISSION ACCOUNT EXCEPTION HANDLING--------------------
    if length(invoice_row.commission_account_no)>=16 then            
        ln_commission_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(invoice_row.commission_account_no, invoice_row.currency);
    else 
        ln_commission_account_no := pkg_hesap.External_HesapNo_Al(invoice_row.commission_account_no);
        ln_commission_account_no := PKG_HESAP.GETHESAPNOFROMEXTERNAL(ln_commission_account_no, invoice_row.currency);
--        ln_debit_account_no := invoice_row.customer_debit_account_no;
    end if; 
    --raise exception if debit account not found from external no
    log_at('process_swift_invoice','10 before COMMISSION_ACCOUNT_NOT_FOUND',ps_invoice_id||','||ln_debit_account_no);
    if ln_commission_account_no is null then
        -- 001 - account not found
        update_invoice_status(ps_invoice_id, 'sFAIL', '011', 'Account for commission account' || invoice_row.commission_account_no || ' and currency ' || invoice_row.currency || ' is not found');
        raise COMMISSION_ACCOUNT_NOT_FOUND;
    end if;
    
    ln_commission_musteri_no := PKG_HESAP.HESAPTANMUSTERINOAL(ln_commission_account_no);
    --raise exception if debit account does not belong to customer
    log_at('process_swift_invoice','11 before NOT_CUSTOMERS_CMMSSN_ACCOUNT',ln_commission_musteri_no||','||ps_customer_id);
    if ln_commission_musteri_no <> ps_customer_id then
        update_invoice_status(ps_invoice_id, 'sFAIL', '012', 'Commission Account ' || ln_commission_account_no || ' does not belong to customer '||ps_customer_id);
        raise NOT_CUSTOMERS_CMMSSN_ACCOUNT;
    end if;
    
    
  --COMMISSION_ACCOUNT_NO bakiye yeterli mi?
--    if(ln_commission_account_no=ln_debit_account_no) then
--        ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_commission_account_no), invoice_row.amount+invoice_row.charge_amount, pc_ref);
--    else
--        ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_commission_account_no),invoice_row.charge_amount, pc_ref);
--    end if;
--    log_at('process_swift_invoice','after Commission check',ps_invoice_id);
 --  END OF COMMISSION CHECK ------------------------------------------ 
 
 
 --START OF VALUE-DATE CHECK-----------------------------------   
    log_at( 'process_swift_invoice', '12 value-date '|| to_date(invoice_row.value_date,'DD.MM.YYYY') || ';;;'||to_char(PKG_MUHASEBE.BANKA_TARIHI_BUL));
    
    log_at( 'process_swift_invoice', '13 bank-date: date-char-date='|| to_date(to_char(PKG_MUHASEBE.BANKA_TARIHI_BUL,'DD.MM.YYYY'),'DD.MM.YYYY') 
                                                ||'; naked='||PKG_MUHASEBE.BANKA_TARIHI_BUL||'; char='||to_char(PKG_MUHASEBE.BANKA_TARIHI_BUL,'DD.MM.YYYY'));      
    if invoice_row.value_date < PKG_MUHASEBE.BANKA_TARIHI_BUL then
        log_at( 'process_swift_invoice', '14 value-date '||'else ',to_date(invoice_row.value_date,'DD.MM.YYYY') || ';;;'||PKG_MUHASEBE.BANKA_TARIHI_BUL);
        update_invoice_status(ps_invoice_id, 'sFAIL', '010', 'Value date ' || invoice_row.value_date||' has expired becuase less than '||PKG_MUHASEBE.BANKA_TARIHI_BUL);
        raise VALUE_DATE_INVALID;
    elsif invoice_row.value_date=PKG_MUHASEBE.BANKA_TARIHI_BUL then
        --compare time 
        log_at( 'process_swift_invoice', '15 value-date '|| to_date(invoice_row.value_date,'DD.MM.YYYY') || ';;;'||to_char(PKG_MUHASEBE.BANKA_TARIHI_BUL));
        if to_char(sysdate, 'hh24:mi')>'16:00' then   -- change Esen 12:00
            update_invoice_status(ps_invoice_id, 'sFAIL', '010', 'Value date ' || invoice_row.value_date||' has expired beacuse done after 12.00 '||PKG_MUHASEBE.BANKA_TARIHI_BUL);
            raise VALUE_DATE_INVALID;
        end if;        
    end if;
    
    
    
     ls_returncode := cbs.pkg_soa_inquiry.getSwiftValueDate(invoice_row.customer_id,invoice_row.created_by,to_char(invoice_row.value_date,'dd/mm/yyyy'),'Y',invoice_row.currency,invoice_row.commission_type, ln_value_date );
      if ls_returncode<>'000' then
            update_invoice_status(ps_invoice_id, 'sFAIL', '015', 'Value date ' || invoice_row.value_date||' is not a working day of our or correspondent bank');
            raise VALUE_DATE_NOT_WORKING_DAY;
        end if; 
    --AzatD 23.03.2021 ibc-53  end 
     log_at( 'process_swift_invoice', '16 value-date from inquiry',ln_value_date);
--      update corpint.tbl_invoice set value_date= to_date(ln_value_date,'DD/MM/YYYY') where id = invoice_row.id; AzatD 23.03.2021 ibc-53
--     if(invoice_row.value_date<>ln_value_date) then 
--        update corpint.tbl_invoice set value_date=ln_value_date where id = invoice_row.id;
--     end if;
       
--         
--    IF ls_returncode <> '000' THEN
--        return ls_returncode;
--    END IF;     
--    
--    LOOP
--    log_at('process_swift_invoice','inside loop commission',commission);
--        fetch pc_ref into str1, str2, str3,str4, str5, str6,str7, str8, str9;
--
--        exit when pc_ref%notfound;
--
--    END LOOP;
--    CLOSE pc_ref;
    
    
         
--END OF VALUE-DATE CHECK-----------------------------------    
    

    
         
--START OF SWIFT-BANK-INFO CHECK-----------------------------------        
    
    /*AzatD 19.01.2021 complete information*/
    
    log_at('process_swift_invoice','17 after VALUE_DATE_INVALID',ls_returncode||','||invoice_row.beneficiar_country_code);
    /*beneficiary bank info completion*/
    ls_returncode := cbs.pkg_soa_inquiry.SwiftBankInfo(invoice_row.beneficiar_country_code,null,null,pc_ref);
    log_at('process_swift_invoice','18 before SwiftBankInfo log check',ls_returncode||','||invoice_row.beneficiar_country_code);
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;     
    
    LOOP
--        log_at('process_swift_invoice','inside loop SwiftBankInfo log check',ps_amountComm||','||ps_taxComm);
        fetch pc_ref into str1, str2, str3,str4, str5, str6,str7, str8, str9,str10, str11, str12,str13, str14, str15,str16, str17, str18,str19, str20, str21,str22, str23;
--        i:=i+1;
--        exit when i<2;--pc_ref%notfound or str1=invoice_row.beneficiar_bank_bic;

        exit when pc_ref%notfound or instr(invoice_row.beneficiar_bank_bic,str1)>0;
--        ps_amountComm := str1;
--        ps_taxComm := str3;
    END LOOP;
    CLOSE pc_ref;
    
    log_at('process_swift_invoice','19 after SwiftBankInfo bank bic is: ',str1||','||invoice_row.beneficiar_country_code);
    if instr(invoice_row.beneficiar_bank_bic,str1) =0 then
        update_invoice_status(ps_invoice_id, 'sFAIL', '013', 'Beneficiary bank bic ' || invoice_row.beneficiar_bank_bic || ' is not found');
        raise  INVALID_BANK_BIC;
    end if; 
    
    if str17 is not null then
        ben_country_name := invoice_row.beneficiar_country_code||'###'||str17;    
    end if;
    
    if str3 is not null then
        ben_bank_bic := invoice_row.beneficiar_bank_bic||'###'||str3||'###'||invoice_row.beneficiar_bank_branch_name;    
    end if;                            
    

         
--END OF SWIFT-BANK-INFO CHECK-----------------------------------       



--START OF COMMISSION-INFO CHECK-----------------------------------         
    log_at('process_swift_invoice','20 before GetCommission','SWIFT###CIB###'|| str1 ||','||invoice_row.commission_type,invoice_row.commission_account_no ||','||ben_country_name||','||ben_bank_bic);
    
    
    /*commission info completion*/


    select decode(invoice_row.commission_type, 'O', 'OUR','B','BEN','G','GOUR') into str1 from dual;
    ls_returncode := cbs.pkg_soa_inquiry.GetCommission('SWIFT###CIB###'|| str1,invoice_row.commission_account_no,null,invoice_row.amount,invoice_row.currency,pc_ref );
    
    
    log_at('process_swift_invoice','21 after GetCommission',ls_returncode ||';'||'SWIFT###CIB###'|| str1,invoice_row.commission_account_no||';'||invoice_row.amount||';'||invoice_row.currency);
         
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;     
    
    LOOP
        log_at('process_swift_invoice','22 inside loop commission',num1 || ';'||num3 ||';'||num4);
        fetch pc_ref into num1, num2, num3, num4, num5, num6,num7, num8, num9; --AzatD changing varcahr to numeric

        exit when pc_ref%notfound;

    END LOOP;
    CLOSE pc_ref;
    
   
    commission := to_number(num1)||'###'||to_number(num3)||'###'||to_number(num4);
    
     log_at('process_swift_invoice','23 after loop commission',commission);
--END OF COMMISSION-INFO CHECK-----------------------------------


--START OF PAYMENT-CODE CHECK-----------------------------------     
     /*payment code info completion*/
     
     SELECT count(id || DECODE(stat_code, NULL, '', '#'||stat_code || '#' ||DECODE(UPPER(TRIM('RUS')), 'ENG', name, name_rus) ||'#' ||name)) --, stat_code, DECODE(UPPER(TRIM('RUS')), 'ENG', name, name_rus) 
                        into payment_code FROM CBS.CBS_STATISTICAL_CODES_CIB  
                        WHERE  stat_code=PKG_MESSAGE.SPLIT(invoice_row.payment_code,'#',1) and id=PKG_MESSAGE.SPLIT(invoice_row.payment_code,'#',0);
      log_at('process_swift_invoice','24 before payment_code:' || invoice_row.payment_code,payment_code); 
    if payment_code=0 then 
        --update_status
        --raise an exception        
        update_invoice_status(ps_invoice_id, 'sFAIL', '014', 'Payment code for ' || invoice_row.payment_code || ' is not found');
        raise  INVALID_PAYMENT_CODE;
    end if;  
    
    
     SELECT id || DECODE(stat_code, NULL, '', '#'||stat_code || '#' ||DECODE(UPPER(TRIM('RUS')), 'ENG', name, name_rus) ||'#' ||name) --, stat_code, DECODE(UPPER(TRIM('RUS')), 'ENG', name, name_rus) 
                        into payment_code FROM CBS.CBS_STATISTICAL_CODES_CIB  
                        WHERE  stat_code=PKG_MESSAGE.SPLIT(invoice_row.payment_code,'#',1) and id=PKG_MESSAGE.SPLIT(invoice_row.payment_code,'#',0);
                        
    log_at('process_swift_invoice','25 after payment_code',payment_code);                      
     
    
--END OF PAYMENT-CODE CHECK----------------------------------- 
    
    
--START OF CORRESPONDING BANK----------------------------------- 
    
    ls_returncode := cbs.pkg_soa_inquiry.getCorrespondentBank(ps_customer_id,invoice_row.currency, invoice_row.commission_type,pc_ref);
    
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;     
    
    LOOP
    log_at('process_swift_invoice','26 inside loop corresponding bank',commission);
        fetch pc_ref into num1, num2, str3,str4;--AzatD changing varcahr to numeric

        exit when pc_ref%notfound;

    END LOOP;
    CLOSE pc_ref;
    
    correspondent_bank_name:=str3;
    log_at('process_swift_invoice','27 after loop corresponding bank',correspondent_bank_name);
 --END OF CORRESPONDING BANK-----------------------------------
 
 --START OF EXCHANGE RATES-----------------------------------
    ls_returncode := cbs.pkg_int_currency.GetExchangeRates(null,pc_ref);    
    
    IF ls_returncode <> '000' THEN
        return ls_returncode;
    END IF;     
    
    LOOP
    log_at('process_swift_invoice','28 inside loop GetExchangeRates',commission);
        fetch pc_ref into str1, num2, num3,num4,num5,str6,num7; --AzatD changing varcahr to numeric
        if str1='USD' then
            num8:= num2;
        elsif str1 = 'EUR' then
            num9:=num2;        
            
        end if;
        exit when pc_ref%notfound;

    END LOOP;
    CLOSE pc_ref;        
            
--END OF EXCHANGE RATES-----------------------------------


--START OF CHECK LIMIT FOR MAIN AMOUNT-----------------------------------        
    log_at('process_swift_invoice','29 before CHECKLIMIT returncode is :',
    to_char(ln_debit_musteri_no) ||','||
                        'SWIFT'||','||
                        to_char(invoice_row.amount)||','||
                        invoice_row.created_by||','||
                        ps_channel_cd||','||
                        num8||';'||num9||','||
                        invoice_row.currency);    
    ls_returncode := CORPINT.PKG_LIMIT.CHECKLIMIT(
                        to_char(ln_debit_musteri_no),
                        'SWIFT',
                        to_char(invoice_row.amount),
                        invoice_row.created_by,
                        ps_channel_cd,
                        num8||';'||num9,
                        invoice_row.currency,
                        pc_ref);
    log_at('process_swift_invoice','29 after CHECKLIMIT returncode is :'||ls_returncode||','||commission);
    if ls_returncode = '057' then
        update_invoice_status(ps_invoice_id, 'sFAIL', '005', 'Amount exceeds the daily limit of company '||ln_debit_musteri_no||' for transaction SWIFT');
        raise DAILY_LIMIT_EXCEEDED;
    elsif ls_returncode in ('052', '051') then
        update_invoice_status(ps_invoice_id, 'sFAIL', '006', 'Amount exceeds the tran limit of company '||ln_debit_musteri_no||' for transaction SWIFT');
        raise TRAN_LIMIT_EXCEEDED;
    elsif ls_returncode = '050' then
        update_invoice_status(ps_invoice_id, 'sFAIL', '007', 'Could not check limit of company '||ln_debit_musteri_no||' for transaction SWIFT');
        raise LIMIT_CHECK_FAILED;
    end if;                       
 
    if pc_ref%isopen then
        close pc_ref;
    end if;
    
--END OF CHECK LIMIT-----------------------------------



--START OF CHECKBALANCE FOR COMMISSION
--    str1 := --commission account
    ln_commission_amount := to_number( pkg_message.SPLIT(commission, '###', 0)) + to_number( pkg_message.SPLIT(commission, '###', 1))+to_number( pkg_message.SPLIT(commission, '###', 2));
    
     log_at('process_swift_invoice','29 commission split is: ', to_number( pkg_message.SPLIT(commission, '###', 0))||','||
     to_number( pkg_message.SPLIT(commission, '###', 1))||','||to_number( pkg_message.SPLIT(commission, '###', 2)), invoice_row.amount+ln_commission_amount );
    log_at('process_swift_invoice','29 commission amount is: '||ln_commission_amount,to_char(ln_commission_account_no) ||','|| (invoice_row.amount+ln_commission_amount) );
    if ln_commission_account_no = ln_debit_account_no then                
        ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_commission_account_no), TO_CHAR((invoice_row.amount+ln_commission_amount),'99999999999.99'), pc_ref);--AzatD added number to char formatter
    else
        ls_returncode := PKG_INT_ACCOUNT.BAKIYEYETERLIMI(to_char(ln_commission_account_no), TO_CHAR((ln_commission_amount),'99999999999.99'), pc_ref);--AzatD added number to char formatter
    end if;
 
    log_at('process_swift_invoice','30 before BAKIYE_YETERLI_DEGIL returncode:',ls_returncode);
 
    if pc_ref%isopen then
        close pc_ref;
    end if;   
    log_at('process_swift_invoice','30 before BAKIYE_YETERLI_DEGIL');
    if ls_returncode <> '000' then
        update_invoice_status(ps_invoice_id, 'sFAIL', '018', 'Commission Account ' || ln_commission_account_no||' have not amount '||ln_commission_amount);
        raise BAKIYE_YETERLI_DEGIL;
    end if;
           


--END OF CHECKBALANCE FOR COMMISSION
        
    log_at('process_swift_invoice','31 before create_swift_transfer;',ps_invoice_id||','||ln_value_date||','||invoice_row.value_date);
--    cbs.pkg_soa_inquiry.swiftbankinfo('DE','','',pc_ref);
    


    
    ls_returncode := create_swift_transfer(
        ps_channel_cd,
        ps_customer_id,
        invoice_row.created_by,
        'tx_no',
        invoice_row.customer_debit_account_no,
        ben_country_name,
        invoice_row.currency,
        to_char(invoice_row.amount, '999999999999999.99'),--to_char(invoice_row.amount),
        to_char(invoice_row.value_date,'DD/MM/YYYY'),
        invoice_row.commission_type,
        payment_code, --stat_code
        invoice_row.payment_details,
        invoice_row.commission_account_no,
        commission,--charge_amount
        invoice_row.beneficiar_credit_account_no,
        invoice_row.beneficiar_name,
        invoice_row.beneficiar_address,
        ben_bank_bic,
        null,--ii_bic,
        invoice_row.created_by,
        'sVERIFY',--change -> Esen Omurchiev 25.06.2021 'sAPPROVE',--tran_status,
        invoice_row.contract_date,
        invoice_row.contract_no,
        correspondent_bank_name,--correspondent_bank_name,
        null,--file name
        invoice_row.beneficiar_bank_branch_name,
        invoice_row.invoice_date,
        invoice_row.invoice_no,
        pc_ref
        --use as an example
--        to_char(ln_debit_account_no),
--        to_char(invoice_row.invoice_date,'YYYYMMDD'),
--        invoice_row.customer_name,
--        '',
--        invoice_row.beneficiar_bank_bic || ';' || invoice_row.beneficiar_bank_name,
--        invoice_row.beneficiar_name,
--        invoice_row.beneficiar_credit_account_no,
--        to_char(invoice_row.amount, '999999999999999.99'),
--        replace(invoice_row.payment_details,'#GROSS#',''), --cq4705 almasn 28042015
--        invoice_row.payment_code || ';' || invoice_row.payment_details,
--        pc_ref
    );
    
    log_at('process_swift_invoice','32 after create_swift_transfer;'||ls_returncode,ps_invoice_id);
            
    if(ls_returncode='000') then
        -- 000 - success
        fetch pc_ref into ls_status, ls_payment_table, ln_txno, ls_value_date;
        close pc_ref;
                
        update_invoice_status(ps_invoice_id, ls_status, '000', '');
        update_payment_info(ps_invoice_id, 'GROSS', ls_payment_table, ls_value_date, ''||ln_txno);
    end if;
    
    close invoice_cursor;
    
    if(ls_returncode<>'000') then
        -- 999 - unknown error
        update_invoice_status(ps_invoice_id, 'sFAIL', '999', 'Unknow error with return code '||ls_returncode);
    end if;
    
    if pc_ref%isopen then
        close pc_ref;
    end if;
     
    return ls_returncode;
    
    EXCEPTION
    WHEN    ALREADY_PROCESSED               THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'INVOICE_ALREADY_PROCESSED', ps_invoice_id);
        return '042';
    WHEN    INVALID_CURRENCY_FOR_SWIFT   THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'INVALID_CURRENCY_FOR_SWIFT', ps_invoice_id);
        return '052';
    WHEN    DEBIT_ACCOUNT_NOT_FOUND THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'DEBIT_ACCOUNT_NOT_FOUND', ps_invoice_id);
        return '062';
    WHEN    InvoiceNotFound THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'INVOICE_NOT_FOUND', ps_invoice_id);
        return '072';
    WHEN    NOT_CUSTOMERS_DEBIT_ACCOUNT THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'NOT_CUSTOMERS_DEBIT_ACCOUNT', ps_invoice_id);
        return '073';
    WHEN    TRANSFER_TO_SAME_ACCOUNT    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_SWIFT_INVOICE', 'TRANSFER_TO_SAME_ACCOUNT', ps_invoice_id);
        return '074';
    WHEN    DAILY_LIMIT_EXCEEDED    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'DAILY_LIMIT_EXCEEDED', ps_invoice_id);
        return '075';
    WHEN    TRAN_LIMIT_EXCEEDED     THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'TRAN_LIMIT_EXCEEDED', ps_invoice_id);
        return '076';
    WHEN    LIMIT_CHECK_FAILED      THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'LIMIT_CHECK_FAILED', ps_invoice_id);
        return '077';
    WHEN    BAKIYE_YETERLI_DEGIL    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'BAKIYE_YETERLI_DEGIL', ps_invoice_id);
        return '078';
    WHEN    VALUE_DATE_INVALID    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'VALUE_DATE_INVALID', ps_invoice_id);
        return '079';
    WHEN    COMMISSION_ACCOUNT_NOT_FOUND    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'COMMISSION_ACCOUNT_NOT_FOUND', ps_invoice_id);
        return '080'; 
    WHEN    NOT_CUSTOMERS_CMMSSN_ACCOUNT    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'NOT_CUSTOMERS_CMMSSN_ACCOUNT', ps_invoice_id);
        return '090';  
        
    WHEN INVALID_COUNTRY_CODE_EXCEPTION THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVALID_COUNTRY_CODE_EXCEPTION', ps_invoice_id); 
        return '091';  
    WHEN INVALID_BANK_BIC THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVALID_BANK_BIC', ps_invoice_id); 
        return '092';   
     WHEN INVALID_PAYMENT_CODE THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'INVALID_PAYMENT_CODE', ps_invoice_id); 
        return '093';   
    WHEN VALUE_DATE_NOT_WORKING_DAY    THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE', 'VALUE_DATE_NOT_WORKING_DAY', ps_invoice_id);
        return '094';                                              
--
--
            
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.PROCESS_INVOICE',sqlerrm, ps_invoice_id);
        return '999';
END;            

/******************************************************************************
   NAME:        process_swift_invoice
   PURPOSE:     To make a payment transaction by the invoice
   PREPARED BY: Azat Dzhanybekov
   DATE:        21.12.2020
******************************************************************************/
FUNCTION  create_swift_transfer(  ps_channel_cd       IN  VARCHAR2,
                                           ps_customer_id      IN  VARCHAR2,
                                           ps_person_id        IN  VARCHAR2,
                                           ps_todo_txno IN  VARCHAR2,
                                           ps_sender_acc_no IN VARCHAR2,
                                           ps_country_code IN VARCHAR2,
                                           ps_currency IN VARCHAR2,
                                           ps_amount IN VARCHAR2,
                                           ps_value_date IN VARCHAR2,
                                           ps_charge_party IN VARCHAR2, --who pays charge,  (BEN, OUR, GOUR)
                                           ps_stat_code IN VARCHAR2, 
                                           ps_description IN VARCHAR2,
                                           ps_comm_acc_no IN VARCHAR2,
                                           ps_charge_amount IN VARCHAR2,
                                           ps_ben_acc_no IN VARCHAR2,
                                           ps_ben_name IN VARCHAR2,
                                           ps_ben_address IN VARCHAR2,
                                           ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                                           ps_ii_bic IN VARCHAR2,                 --intermediary institution bic code 
                                           
                                           ps_person        IN VARCHAR2,
                                           ps_tran_status    IN VARCHAR2,
                                           ps_contract_date IN VARCHAR2,
                                           ps_contract_no IN VARCHAR2,
                                           ps_corrbank_name IN VARCHAR2,
                                           ps_filename IN VARCHAR2,
                                           ps_ben_bank_branch IN VARCHAR2, 
                                           
                                           ps_invoice_date IN VARCHAR2,
                                           ps_invoice_no IN VARCHAR2,
                                           
                                           pc_ref OUT cursorreferencetype) RETURN VARCHAR2
IS
    ls_returncode   varchar2(3):='000';
    ls_txtodo_stat  varchar2(10);
    lc_admin_ref          CORPINT.pkg_admin.cursorReferencetype;
    lc_soa_inquiry_ref    CBS.PKG_SOA_INQUIRY.CURSORREFERENCETYPE;
    
    ls_refno        varchar2(20);
    ln_islem_no     number;
    
    ls_tran_date    varchar2(10) := to_char(sysdate);
    ln_tmp          number;
    ls_ileri_gun    varchar2(10);
    ls_ileri_is_gun  varchar2(10);
    ls_ileri_gun2  varchar2(10);
    
BEGIN
    log_at('create_swift_transfer','before need approve');
    ls_returncode := CORPINT.PKG_ADMIN.NEEDAPPROVE(ps_customer_id, 'SWIFT', '', lc_admin_ref);
    log_at('create_swift_transfer','after need approve');
    fetch lc_admin_ref into ls_txtodo_stat;
    close lc_admin_ref;
    log_at('create_swift_transfer','after fetch1',ls_txtodo_stat);
    ls_txtodo_stat:='sAPPROVE';
    --ls_returncode := CBS.PKG_SOA_INQUIRY.GETEFTDATE(ps_transfer_date, 'CLEARING', lc_soa_inquiry_ref);
    
--    fetch lc_soa_inquiry_ref into ls_tran_date, ln_tmp, ls_ileri_gun, ls_ileri_is_gun, ls_ileri_gun2;
--    close lc_soa_inquiry_ref;
    log_at('create_swift_transfer','after fetch2:'||ls_tran_date||','||ln_tmp||','|| ls_ileri_gun||','|| ls_ileri_is_gun||','|| ls_ileri_gun2);
    if ls_txtodo_stat = 'sMAKE' then
--        ls_returncode := CBS.PKG_INT_TRANSFER.MAKEEFT(
--                ps_fromaccount,
--                '',
--                ls_tran_date,
--                ps_sender_name,
--                ps_sender_phone,
--                ps_bank_code,
--                ps_payee_name,
--                ps_toaccount,
--                ps_amount,
--                ps_description,
--                'H',
--                '',
--                ps_payment_code,
--                '',
--                '',
--                '',
--                'CLEARING',
--                '', --ernestk 13062014 cqdb864 add order number column
--                lc_soa_inquiry_ref);
                
                
                
    
    ls_returncode := CBS.PKG_INT_TRANSFER.Make_Swift(ps_sender_acc_no,
                                          ps_country_code,
                                          ps_currency,
                                          ps_amount,
                                          ps_value_date,
                                          ps_charge_party, --who pays charge,  (BEN, OUR, GOUR)
                                          ps_stat_code, 
                                          ps_description,
                                          ps_comm_acc_no,
                                          ps_charge_amount,
                                          ps_ben_acc_no,
                                          ps_ben_name,
                                          ps_ben_address,
                                          ps_ben_swiftcode, --bic code of beneficiary bank
                                          ps_ii_bic,                 --intermediary institution bic code         
                                          ps_todo_txno ,                           
                                          lc_soa_inquiry_ref );
                                          
                                                          
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ls_refno, ln_islem_no;
            close lc_soa_inquiry_ref;
            
            ls_returncode := CORPINT.PKG_LIMIT.UPDATELIMIT(
                            ps_customer_id,
                            'CLEARING',
                            ps_amount,
                            'KGS',
                            ps_person_id,
                            ps_channel_cd,
                            '1',
                            pc_ref);
            ls_returncode := '000';
            close pc_ref;
            
            open pc_ref for select 'sDONE', 'cbs.cbs_clearing_islem', ln_islem_no, ls_tran_date from dual;
        end if;
                
    else
    
        log_at('create_swift_transfer','before SWIFTTODO');
        ls_returncode := CORPINT.PKG_AUTH.SWIFTTODO(
                                           ps_sender_acc_no,
                                           ps_country_code,
                                           ps_currency,
                                           ps_amount,
                                           ps_value_date,
                                           ps_charge_party, --who pays charge,  (BEN, OUR, GOUR)
                                           ps_stat_code, 
                                           ps_description,
                                           ps_comm_acc_no,
                                           ps_charge_amount,
                                           ps_ben_acc_no,
                                           ps_ben_name,
                                           ps_ben_address,
                                           ps_ben_swiftcode, --bic code of beneficiary bank
                                           ps_ii_bic,                 --intermediary institution bic code 
                                           
                                           ps_person,
                                           ps_tran_status,
                                           ps_contract_date,
                                           ps_contract_no,
                                           ps_corrbank_name,
                                           ps_filename,
                                           ps_ben_bank_branch, 
                                           
                                           ps_invoice_date,
                                           ps_invoice_no,
                                           
                                           null,
                                         null,
                                           
                                           lc_soa_inquiry_ref);
    log_at('create_swift_transfer','after  SWIFTTODO',ls_returncode);                                           
        if ls_returncode = '000' then
            fetch lc_soa_inquiry_ref into ln_islem_no;
            close lc_soa_inquiry_ref;
            
            open pc_ref for select ls_txtodo_stat, 'corpint.tbl_txtodo', ln_islem_no, ls_tran_date from dual;
        end if;
    end if;
    log_at('create_swift_transfer','before return',ls_returncode);
    return ls_returncode;
    
    EXCEPTION   
    WHEN    OTHERS  THEN
        CORPINT.PKG_LOG.ADDCUSTOMLOG('PKG_DDS.CREATE_SWIFT_TRANSFER',sqlerrm);
        return '999';
END;                             
   
END PKG_SOA_DDS;
/

