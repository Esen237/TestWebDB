create PACKAGE BODY     PKG_INT_TRANSFER
IS
/**************************************************************************************/
   FUNCTION geteftdate (pd_date IN VARCHAR2, pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ld_date          DATE;
      ls_returncode    VARCHAR2 (3)  := '000';
      ps_starthour     VARCHAR2 (10);
      ps_endhour       VARCHAR2 (10);
      ps_tmp           NUMBER        := 0;
                                       --0 ise an?nda 1 ise ileri tarihli eft
      not_valid_date   EXCEPTION;
      PRAGMA EXCEPTION_INIT (not_valid_date, -01839);
                                          -- yanl?? zaman girilmesi durumunda
   BEGIN

      ps_tmp := Pkg_Int_Transfer.geteftsaatsinirlari (ps_starthour, ps_endhour);
      IF (TO_DATE (pd_date, 'YYYYMMDD') < TRUNC (SYSDATE))
      THEN
         ls_returncode := '413';
      -- 2.
      -- burada o g?n i?in EOD al?nm?? ve banka tarihi bir sonraki i? g?n?n? g?steriyor demektir.
      -- bu durumda ilk i? g?n?n? otomatik olarak set edece?im ve ileri tarihli eft olarak tan?mlayaca??m.
      ELSIF (    (TO_DATE (pd_date, 'YYYYMMDD') = TRUNC (SYSDATE))
             AND ((TO_DATE (pd_date, 'YYYYMMDD') <
                                         TRUNC (Pkg_Muhasebe.banka_tarihi_bul)
                  )
                 )
            )
      THEN
         ld_date := Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date,'YYYYMMDD'));
         ps_tmp := 1;
       -- 3.
      -- Burada girilen tarih sistem tarihinden b?y?k banka tarihinden k???k ise(bu durum sadece hafta sonlar? olur)
      -- ileri tarihli eft olarak i?lem yap?yoruz.
      ELSIF ((TO_DATE (pd_date, 'YYYYMMDD') > TRUNC (SYSDATE))
             AND ((TO_DATE (pd_date, 'YYYYMMDD') <=
                                         TRUNC (Pkg_Muhasebe.banka_tarihi_bul))))
      THEN
         ld_date := Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date, 'YYYYMMDD'));
         ps_tmp := 1;
      ELSIF TO_DATE (pd_date, 'YYYYMMDD') < TRUNC (Pkg_Muhasebe.sonraki_banka_tarihi_bul)
             AND TRUNC(SYSDATE) > TRUNC(Pkg_Muhasebe.banka_tarihi_bul)
      THEN
         ld_date := Pkg_Muhasebe.sonraki_banka_tarihi_bul;
         ps_tmp := 1;
       -- 4
      -- eft g?n? banka tarihi ile ayn? ise sorun yok saatlere bak ve i?lem yap.
      ELSIF (
               TO_DATE(pd_date, 'YYYYMMDD') = TRUNC (Pkg_Muhasebe.banka_tarihi_bul)
            )
      THEN
         -- mesai saatlerinde ise
         IF (    (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_starthour) = 1)
             AND (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_endhour) = 2)
            )
         THEN
            ld_date := TO_DATE (pd_date, 'YYYYMMDD');
            ps_tmp := 0;
         -- mesai saatinden ?nce ise
         ELSIF (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_starthour) = 2)
         THEN
            ld_date := TO_DATE (pd_date, 'YYYYMMDD');
            ps_tmp := 0;
         -- mesai saatinden sonra ise
         ELSE
            ld_date :=
                      Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date, 'YYYYMMDD'));
            ps_tmp := 1;

         END IF;
      ELSE
                                          -- ileri tarihli ise
         IF Pkg_Tarih.gun_ozellik (TO_DATE (pd_date, 'YYYYMMDD')) = 0
         THEN
            ld_date := TO_DATE (pd_date, 'YYYYMMDD');
            ps_tmp := 1;
         ELSE
            ld_date :=
                      Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date, 'YYYYMMDD'));
            ps_tmp := 1;
         END IF;
      END IF;

      OPEN pc_ref
       FOR
          SELECT TO_CHAR (ld_date, 'YYYYMMDD'), ps_tmp
            FROM DUAL;

      RETURN ls_returncode;
   EXCEPTION
      WHEN not_valid_date
      THEN
         ls_returncode := '414';

         OPEN pc_ref
          FOR
             SELECT SYSDATE
               FROM DUAL;

         RETURN ls_returncode;
   END;

/**************************************************************************************/
   FUNCTION MakeEFT (
      ps_from_acc                VARCHAR2,
      ps_payee_info              VARCHAR2,
      pd_trandate                VARCHAR2,
      ps_sender_name             VARCHAR2,
      ps_sender_phone            VARCHAR2,
      ps_bank_code               VARCHAR2,
      ps_payee_name              VARCHAR2,
      ps_to_account              VARCHAR2,
      pn_amount                  VARCHAR2,
      ps_description             VARCHAR2,
      ps_save_payee_flag         VARCHAR2,
      ps_payee_nick              VARCHAR2,
      pn_paycode                 VARCHAR2,
      pn_subaccount                 VARCHAR2,
      ps_subname                 VARCHAR2,
      ps_payforservice             VARCHAR2,
      ps_transfer_option            VARCHAR2,
      ps_order_number               VARCHAR2 DEFAULT '', --ernestk 120602014 cqdb864 add order number
      pc_ref               OUT   cursorreferencetype
   )
      RETURN VARCHAR2
   IS
         lc_refno   VARCHAR2 (16) ;
       ld_date DATE;
       --datem DATE;
      ls_returncode       VARCHAR2 (3):= '000';
      ls_stat             VARCHAR2 (4);
      ln_charge_amount    NUMBER;
      ln_islem_no         NUMBER;
      ln_islem_kod        NUMBER;
      lc_modul_tur_kod    VARCHAR2 (10);
      lc_urun_tur_kod     VARCHAR2 (10);
      lc_urun_sinif_kod   VARCHAR2 (20);
      lc_doviz_kod        VARCHAR (3):= Pkg_Genel.lc_al;
      lc_hesap_no         NUMBER:= TO_NUMBER (ps_from_acc);
      lc_from_exacc          VARCHAR2(16):=Pkg_Hesap.External_HesapNo_Al(lc_hesap_no);
      ln_musteri_no       NUMBER:= Pkg_Hesap.hesaptanmusterinoal (TO_NUMBER (lc_hesap_no));
      lc_bolum_kodu       VARCHAR2(3):= Pkg_Hesap.hesapsubeal (lc_hesap_no);
      ls_from_bank_bic      varchar2(6);
      ls_from_description   varchar2(500);
      ls_from_rnn         VARCHAR2(20):=Pkg_Musteri.Sf_VergiNo_Al(ln_musteri_no);
      ls_from_okpo        VARCHAR2(20):=Pkg_Musteri.sf_OKPO_al(ln_musteri_no);
      ls_from_social      VARCHAR2(20):=Pkg_Musteri.sf_SOSYAL_FON_NO_al(ln_musteri_no);
      ls_to_bank_bic       VARCHAR2(6):=Pkg_Message.Split(ps_bank_code ,';',0);
      ls_to_main_bank_bic  VARChAR2(6):=substr(ls_to_bank_bic, 1, 3)||'001';
      ls_payee_name         varchar2(500);
      ln_payment_code     NUMBER:=TO_NUMBER(Pkg_Message.Split(pn_paycode  ,';',0));
      ln_tutar            NUMBER;
      ps_starthour        VARCHAR2 (10);
      ps_endhour          VARCHAR2 (10);
      ps_tmp               NUMBER:= 0;
      lc_rol               NUMBER:= 7777 ;
      ls_description      VARCHAR2 (250);
      lc_kasa_kod          NUMBER;
      ln_kanal_numara      NUMBER:= 1;
      eft_time_expired    EXCEPTION;
            -- tam i?lem yap?laca?? s?rada zaman dolmu? ise adam geri d?necek
      ln_detailid         NUMBER:= 1;
      ps_ILERITARIHLI      VARCHAR2(1):='0';
      ln_currenthour      NUMBER;
      ls_ref_no          VARCHAR2(15);
      TimeException             EXCEPTION;
      ls_retval                 varchar2(3):='000';
      ls_from_region_code   VARCHAR2(2) := '';
      ls_to_region_code     VARCHAR2(2) := '';
      ls_dummy_returncode   varchar2(3) := '000';

      notenoughbalance      exception; --ernestk 29042014 cqdb00001011 if not enough balance

   BEGIN
    ld_date := TO_DATE(pd_trandate,'YYYYMMDD');--VALUE DATE

    --ls_retval:=Pkg_Int_Limit.CheckTimeLimit(ps_transfer_option);

/*    IF ls_retval<>'000' AND (ld_date = Pkg_Muhasebe.Banka_Tarihi_Bul) THEN
       --RAISE TimeException;

       ld_date:=Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);

    ELSE
        ls_returncode:='000';
    END IF;*/







      ln_islem_no       :=Pkg_Tx.islem_no_al;
      ln_islem_kod      :=3555;
      lc_modul_tur_kod  :='CLEARING';
      lc_urun_tur_kod   :='OUTGOING';
log_at('1407',1,'ln_islem_no'||' '||ln_islem_no);
      IF ps_transfer_option = 'GROSS' THEN
        lc_urun_sinif_kod := 'CIBGROSS';
      ELSE
        lc_urun_sinif_kod := 'CIBCLEARING';
      END IF;

      begin
          select    '118'||bolum.eft_kodu
          into      ls_from_bank_bic
          from      cbs.cbs_bolum bolum
          where     bolum.kodu = lc_bolum_kodu;
      exception
        when no_data_found then
          ls_from_bank_bic := '118005';
      end;

      ls_from_description := ls_from_bank_bic || ' ' || ps_sender_name;
      if length(ls_description) > 200 then
        ls_from_description := substr(ls_from_description, 1, 200);
      end if;

      ls_payee_name := ps_payee_name;

      IF ps_transfer_option = 'GROSS' THEN
        begin
          select  lpad(region_no, 2, '0') into ls_from_region_code
          from cbs.cbs_bolum where kodu = lc_bolum_kodu;
        exception
            when others then
                ls_from_region_code := '01';
        end;

        begin
          select  lpad(region_no, 2, '0') into ls_to_region_code
          from cbs.cbs_banka_kodlari where banka_kodu = ls_to_bank_bic;
        exception
            when others then
                ls_to_region_code := '01';
        end;

          ls_payee_name := ls_to_bank_bic || ' ' || ps_payee_name;
      END IF;


      if length(ls_payee_name) > 200 then
        ls_payee_name := substr(ls_payee_name, 1, 200);
      end if;

      lc_doviz_kod      :=Pkg_Genel.lc_al;
      ln_CHARGE_AMOUNT  := 0;
      ln_TUTAR:=TO_NUMBER(pn_amount,'999999999999999.9999');

      IF (ld_date > Pkg_Muhasebe.Banka_Tarihi_Bul) THEN
           ps_ILERITARIHLI:='1';
      END IF;

      ls_description:=NVL(ps_description,'CLEARING PAYMENT');

      ln_CHARGE_AMOUNT  :=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_no, lc_hesap_no, lc_kasa_kod);

      --B-O-M ernestk 29042014 cqdb00001011 check if balance is available
      IF PKG_HESAP.KULLANILABILIR_BAKIYE_AL(lc_hesap_no) < (ln_tutar + ln_charge_amount) THEN
        raise notenoughbalance;
      END IF;
      --E-O-M ernestk 29042014 cqdb00001011 check if balance is available

      -- check if clearing is favour made
      ls_dummy_returncode := PKG_INT_TRANSFER.CHECKIFPAYMENTISFAVOURMADE(to_char(ln_musteri_no), ps_from_acc, ps_transfer_option, ls_payee_name);

      --ls_ref_no := nvl(trim(ps_order_number), 'I'||Pkg_Tx.islem_no_al);--ernestk 12062014 cqdb864 ps_order_number if not specified use generated one
      ls_ref_no := 'I' || nvl( trim(SUBSTR(to_char(ps_order_number), 1, 15)), Pkg_Tx.islem_no_al); --chyngyzo 17122014 cq1264
log_at('1407',2);
      INSERT INTO CBS_CLEARING_ISLEM
      (TX_NO, URUN_TUR_KOD, REF_NO, PAYMENT_TYPE, MATURITY_DATE,
      FROM_ACCOUNT, FROM_ACCOUNT_EXTERNAL_NUMBER, FROM_RNN, FROM_OKPO, FROM_SOCIAL_FUND_NUMBER,
      TO_ACCOUNT_EXTERNAL_NUMBER, TO_SUBACCOUNT, TO_NAME, TO_BANK_BIC, CODE_OF_PAYMENT,
      AMOUNT, EXPLANATION, CHARGE_AMOUNT, YARATILDIGI_TARIH, YARATAN_KULLANICI,
      MUSTERI_NO, FROM_DESCRIPTION, TO_ACCOUNT_NUMBER, GL_FLAG, GL_ACCOUNT,
      TO_SUBACCOUNT_NAME, BOLUM_KODU, GIRIS_KULLANICI, ONAY_KULLANICI, INTERNAL_NO,
      SIRA_NO, MSG_STATUS, FROM_REGION_CODE, TO_REGION_CODE, TYPE_OF_PAYMENT, PAYMENT_DETAILS)
      VALUES
      (ln_islem_no, lc_urun_tur_kod, ls_ref_no, DECODE(ps_transfer_option, 'GROSS', 'GROSS', 'CLEARING'), ld_date,
       lc_hesap_no, lc_from_exacc, ls_from_rnn, ls_from_okpo, ls_from_social,
       ps_to_account, pn_subaccount, ls_payee_name, DECODE(ps_transfer_option, 'GROSS', ls_to_main_bank_bic, ls_to_bank_bic), ln_payment_code,
       ln_TUTAR, ps_description, ln_CHARGE_AMOUNT, SYSDATE, 'CINT_CALLER',
       ln_musteri_no, DECODE(ps_transfer_option, 'GROSS', ls_from_description, ps_sender_name), NULL, NULL, NULL,
       ps_subname, lc_bolum_kodu, 'CINT_CALLER', 'CINT_CALLER', NULL,
       NULL, 'sNEW', ls_from_region_code, ls_to_region_code, 'CRED', 'SHA');
log_at('1407',3);
         Pkg_Int_Api.create_transaction (ln_islem_no,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_bolum_kodu,
                                      lc_bolum_kodu,
                                      lc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_no,
                                      lc_hesap_no,
                                      lc_kasa_kod,
                                      ln_kanal_numara);
      --CLEARING WILL BE APPROVED
   log_at('1407',4);   
      Pkg_Int_Api.process_transaction (ln_islem_no);

    SELECT REF_NO
    INTO lc_refno
    FROM CBS_CLEARING_ISLEM
    WHERE tx_no = ln_islem_no ;

    OPEN pc_ref FOR SELECT lc_refno,ln_islem_no    FROM dual;
log_at('1407',5,lc_refno,ln_islem_no);
    COMMIT;

    RETURN ls_returncode;
EXCEPTION
       --B-O-M ernestk 29042014 cqdb00001011 if not enough balance
       WHEN notenoughbalance THEN
           ROLLBACK;
           ls_returncode := '502';
           log_at('Bakiye yeterli degil',lc_hesap_no,Pkg_Hesap.Kullanilabilir_Bakiye_Al(lc_hesap_no), ln_TUTAR + ln_CHARGE_AMOUNT);
           OPEN pc_ref FOR SELECT lc_refno,ln_islem_no    FROM dual;
           return ls_returncode;
       --E-O-M ernestk 29042014 cqdb00001011 if not enough balance
         WHEN TimeException THEN
           OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;
         RETURN ls_returncode;

       WHEN eft_time_expired THEN
           OPEN pc_ref FOR SELECT SYSDATE FROM dual;
           RETURN ls_returncode;

       WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At('CLEARING',ln_islem_no,SQLERRM,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            --ROLLBACK;
            OPEN pc_ref FOR    SELECT TO_CHAR(ln_islem_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;
END;

--------------------------------------------------------------------------------------
   FUNCTION eftinquiry (
      pn_musterino   IN       VARCHAR2,
      pn_sorguno     IN       VARCHAR2,
      pd_startdate   IN       VARCHAR2,
      pd_enddate     IN       VARCHAR2,
      ps_status      IN       VARCHAR2,
      pc_ref         OUT      cursorreferencetype
   )
      RETURN VARCHAR2
   IS
      ls_returncode    VARCHAR2 (3) := '000';
      ld_startdate     DATE;
      ld_enddate       DATE;
      not_valid_date   EXCEPTION;
      PRAGMA EXCEPTION_INIT (not_valid_date, -01839);
                                          -- yanl?? zaman girilmesi durumunda
   BEGIN
      IF LENGTH(pd_startdate)=8 THEN
          ld_startdate := TO_DATE (pd_startdate, 'YYYYMMDD');
          ld_enddate := TO_DATE (pd_enddate, 'YYYYMMDD');
      END IF;
      IF ps_status!='I' THEN
          IF (pn_sorguno IS NULL)
          THEN
                OPEN pc_ref FOR
              SELECT TO_CHAR(a.MATURITY_DATE,'DD.MM.YYYY') MATURITY_DATE, a.MSG_STATUS,'', a.BOLUM_KODU, TO_CHAR(a.YARATILDIGI_TARIH,'DD.MM.YYYY') YARATILDIGI_TARIH,
                    a.AMOUNT, a.FROM_ACCOUNT,'','','',
                    '',pkg_int_transfer.GetBranchName(a.BOLUM_KODU),'','','',
                    a.TO_ACCOUNT_EXTERNAL_NUMBER, a.TO_NAME,'','','',
                    a.REF_NO, a.URUN_TUR_KOD, a.YARATAN_TX_NO,'',a.EXPLANATION,a.CHARGE_AMOUNT, b.DURUM, Pkg_Int.GetBankName(a.TO_BANK_BIC),CODE_OF_PAYMENT,
                    pkg_musteri.Sf_Musteri_Adi(a.MUSTERI_NO),
                    '',to_char(YARATILDIGI_TARIH,'dd.mm.yyyy hh24:mi:ss'), YARATAN_KULLANICI
                    FROM CBS_CLEARING a, CBS_ISLEM b
                    WHERE a.YARATAN_TX_NO=b.NUMARA
                    AND a.from_account IN  (SELECT to_char(hesap_no) FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino))--CBS-508 to_char added
                   AND a.YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY')) AND a.YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1--CBS-508  corrected conditions
        UNION
        SELECT         TO_CHAR(a.MATURITY_DATE,'DD.MM.YYYY') MATURITY_DATE, a.MSG_STATUS,'', a.BOLUM_KODU, TO_CHAR(a.YARATILDIGI_TARIH,'DD.MM.YYYY') YARATILDIGI_TARIH,
                    a.AMOUNT, a.FROM_ACCOUNT,'','','',
                    '',pkg_int_transfer.GetBranchName(a.BOLUM_KODU),'','','',
                    a.TO_ACCOUNT_EXTERNAL_NUMBER, a.TO_NAME,'','','',
                    a.REF_NO, a.URUN_TUR_KOD, a.YARATAN_TX_NO,'',a.EXPLANATION,a.CHARGE_AMOUNT,'',Pkg_Int.GetBankName(a.TO_BANK_BIC),CODE_OF_PAYMENT,
                    pkg_musteri.Sf_Musteri_Adi(a.MUSTERI_NO),
                    '',to_char(YARATILDIGI_TARIH,'dd.mm.yyyy hh24:mi:ss'), YARATAN_KULLANICI
                    FROM CBS_CLEARING a
                    WHERE a.from_account IN  (SELECT to_char(hesap_no) FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino))--CBS-508 to_char added
                    AND a.MSG_STATUS='sDONE'
                    AND a.YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY'))AND a.YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1--CBS-508  corrected conditions
                         ORDER BY YARATILDIGI_TARIH;
          ELSE
             OPEN pc_ref FOR
                 SELECT TO_CHAR(MATURITY_DATE,'DD.MM.YYYY') MATURITY_DATE, MSG_STATUS,'', BOLUM_KODU, TO_CHAR(YARATILDIGI_TARIH,'DD.MM.YYYY') YARATILDIGI_TARIH,
                    AMOUNT, FROM_ACCOUNT,FROM_DESCRIPTION,'','',
                    '',pkg_int_transfer.GetBranchName(BOLUM_KODU),'','','',
                    TO_ACCOUNT_EXTERNAL_NUMBER, TO_NAME,'','','',
                    REF_NO, URUN_TUR_KOD, YARATAN_TX_NO,EXPLANATION,CHARGE_AMOUNT,'',Pkg_Int.GetBankName(TO_BANK_BIC),CODE_OF_PAYMENT,
                    pkg_musteri.Sf_Musteri_Adi(MUSTERI_NO),
                    '',to_char(YARATILDIGI_TARIH,'dd.mm.yyyy hh24:mi:ss'), YARATAN_KULLANICI
                    FROM CBS_CLEARING
                    WHERE from_account IN  (SELECT to_char(hesap_no) FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino))--CBS-508 to_char added
                   AND YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY')) AND YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1--CBS-508  corrected conditions
                    ORDER BY MATURITY_DATE,ref_no;
          END IF;
      ELSE--only sWAIT status
      OPEN pc_ref FOR
             SELECT TO_CHAR(a.MATURITY_DATE,'DD.MM.YYYY') MATURITY_DATE, a.MSG_STATUS,'', a.BOLUM_KODU, TO_CHAR(a.YARATILDIGI_TARIH,'DD.MM.YYYY') YARATILDIGI_TARIH,
                    a.AMOUNT, a.FROM_ACCOUNT,a.FROM_DESCRIPTION,'','',
                    '',pkg_int_transfer.GetBranchName(a.BOLUM_KODU),'','','',
                    a.TO_ACCOUNT_EXTERNAL_NUMBER, a.TO_NAME,'','','',
                    a.REF_NO, a.URUN_TUR_KOD, a.YARATAN_TX_NO,EXPLANATION,a.CHARGE_AMOUNT,'',Pkg_Int.GetBankName(a.TO_BANK_BIC),CODE_OF_PAYMENT,
                    pkg_musteri.Sf_Musteri_Adi(a.MUSTERI_NO),
                    '',to_char(YARATILDIGI_TARIH,'dd.mm.yyyy hh24:mi:ss'), YARATAN_KULLANICI
                    FROM CBS_CLEARING a-- , CBS_ISLEM b
                    WHERE a.from_account IN  (SELECT to_char(hesap_no) FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino))--CBS-508 to_char added
                    AND a.MSG_STATUS='sNEW'
                      AND a.MATURITY_DATE>Pkg_Muhasebe.Banka_Tarihi_Bul
                    --AND a.TX_NO = b.NUMARA
                    --AND b.DURUM = 'C'
               ORDER BY a.MATURITY_DATE,ref_no;
      END IF;--status!='I' all status

             /*OPEN pc_ref FOR
                SELECT TO_CHAR(VALUE_DATE,'DD.MM.YYYY') VALUE_DATE,MSG_STATUS,TOTAL_TRAN_AMOUNT,BRANCH_CODE,TO_CHAR(TRAN_DATE,'DD.MM.YYYY'),
                    TRAN_AMOUNT,Pkg_Hesap.GetHesapNoFromExternal(from_account),FROM_NAME,FROM_RNN,FROM_IRS,
                    FROM_SECO,FROM_BRANCH,FROM_HQ,TO_BRANCH,TO_HQ,
                    TO_ACCOUNT_NUMBER,TO_NAME,TO_RNN,TO_IRS,TO_SECO,
                    REF_NO,URUN_TUR_KOD,YARATAN_TX_NO,DOC_ASSIGN
                    FROM cbs_vw_clearing
                    WHERE from_account IN  (SELECT external_hesap_no FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino) AND external_hesap_no IS NOT NULL)
                    AND MATURITY_DATE >= NVL (ld_startdate, TO_DATE ('01011900', 'DDMMYYYY'))
                    AND MATURITY_DATE <= NVL (ld_enddate, TO_DATE ('01012900', 'DDMMYYYY'))
                UNION
                SELECT TO_CHAR(VALUE_DATE,'DD.MM.YYYY') VALUE_DATE,MSG_STATUS,TOTAL_TRAN_AMOUNT,BRANCH_CODE,TO_CHAR(TRAN_DATE,'DD.MM.YYYY'),
                    TRAN_AMOUNT,Pkg_Hesap.GetHesapNoFromExternal(from_account),FROM_NAME,FROM_RNN,FROM_IRS,
                    FROM_SECO,FROM_BRANCH,FROM_HQ,TO_BRANCH,TO_HQ,
                    TO_ACCOUNT,TO_NAME,TO_RNN,TO_IRS,TO_SECO,
                    REF_NO,URUN_TUR_KOD,TX_NO,DOC_ASSIGN
                    FROM cbs_vw_clearing_draft
                    WHERE from_account IN  (SELECT external_hesap_no FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino) AND external_hesap_no IS NOT NULL)
                    AND value_date >= NVL (ld_startdate, TO_DATE ('01011900', 'DDMMYYYY'))
                    AND value_date <= NVL (ld_enddate, TO_DATE ('01012900', 'DDMMYYYY'))
                 ORDER BY value_date,ref_no;

          ELSE
             OPEN pc_ref FOR
                SELECT TO_CHAR(VALUE_DATE,'DD.MM.YYYY'),MSG_STATUS,TOTAL_TRAN_AMOUNT,BRANCH_CODE,TO_CHAR(TRAN_DATE,'DD.MM.YYYY'),
                    TRAN_AMOUNT,Pkg_Hesap.GetHesapNoFromExternal(from_account),FROM_NAME,FROM_RNN,FROM_IRS,
                    FROM_SECO,FROM_BRANCH,FROM_HQ,TO_BRANCH,TO_HQ,
                    TO_ACCOUNT,TO_NAME,TO_RNN,TO_IRS,TO_SECO,
                    REF_NO,URUN_TUR_KOD,TX_NO,DOC_ASSIGN
                FROM cbs_vw_clearing
                WHERE from_account IN  (SELECT external_hesap_no FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino) AND external_hesap_no IS NOT NULL)
                     AND ref_no = pn_sorguno
                 ORDER BY value_date,ref_no;
          END IF;
      ELSE--only sWAIT status
      OPEN pc_ref FOR
             SELECT TO_CHAR(VALUE_DATE,'DD.MM.YYYY') VALUE_DATE,MSG_STATUS,TOTAL_TRAN_AMOUNT,BRANCH_CODE,TO_CHAR(TRAN_DATE,'DD.MM.YYYY'),
                    TRAN_AMOUNT,Pkg_Hesap.GetHesapNoFromExternal(from_account),FROM_NAME,FROM_RNN,FROM_IRS,
                    FROM_SECO,FROM_BRANCH,FROM_HQ,TO_BRANCH,TO_HQ,
                    TO_ACCOUNT,TO_NAME,TO_RNN,TO_IRS,TO_SECO,
                    REF_NO,URUN_TUR_KOD,TX_NO,DOC_ASSIGN
                    FROM cbs_vw_clearing_draft
                    WHERE from_account IN  (SELECT external_hesap_no FROM CBS_HESAP WHERE musteri_no=TO_NUMBER (pn_musterino) AND external_hesap_no IS NOT NULL)
                    AND MSG_STATUS='sWAIT'
                    ORDER BY value_date,ref_no;
      END IF;--status!='I' all status*/
      RETURN ls_returncode;

   EXCEPTION
      WHEN not_valid_date  THEN
         ls_returncode := '414';

         OPEN pc_ref     FOR   SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
      WHEN OTHERS      THEN
         ls_returncode := '999';
         Log_At(SQLERRM);
         OPEN pc_ref         FOR            SELECT SYSDATE            FROM DUAL;

         RETURN ls_returncode;
   END;

--------------------------------------------------------------------------------------
   FUNCTION booktobooktransfer(pn_fromaccountno   IN       VARCHAR2,
                               pn_toaccountno     IN       VARCHAR2,
                               ps_amount          IN       VARCHAR2,
                               ps_description     IN       VARCHAR2,
                               ps_currencycode    IN       VARCHAR2,
                               ps_isdekont        IN       VARCHAR2,
                               ps_paymentcode     IN       VARCHAR2,
                               ps_order_number    IN       VARCHAR2 DEFAULT '', --chyngyzo 10122014 cq1264 add order number
                               pc_ref             OUT      cursorreferencetype) RETURN VARCHAR2 IS

      ls_returncode        VARCHAR2 (3)  := '000';
      pn_islem_no          NUMBER;
      pn_islem_kod         NUMBER;
      pc_modul_tur_kod     VARCHAR2 (20);
      pc_urun_tur_kod      VARCHAR2 (20);
      pc_urun_sinif_kod    VARCHAR2 (20);
      ps_fromaccountno     NUMBER        := TO_NUMBER (pn_fromaccountno);
      ps_toaccountno       NUMBER        := TO_NUMBER (pn_toaccountno);
      --ln_tutar             NUMBER := TO_NUMBER (REPLACE(REPLACE(ps_amount, ',', ''),'.',','));
      ln_tutar             NUMBER :=TO_NUMBER(ps_amount,'999999999999999.9999');
      ps_bolum_kodu        VARCHAR2 (3)
                                  := Pkg_Hesap.hesapsubeal (pn_fromaccountno);
      pc_bolum_kodu        VARCHAR (10)  := ps_bolum_kodu;
      pc_amir_bolum_kodu   VARCHAR (10)  := ps_bolum_kodu;
      pc_rol               NUMBER        := 7777;
                                        -- herhalde internet ?ubesi bu oluyor
      pc_doviz_kod         VARCHAR (10)  := ps_currencycode;
      pn_musteri_numara    NUMBER:= Pkg_Hesap.hesaptanmusterinoal (TO_NUMBER (pn_fromaccountno));
      pc_hesap_numara      NUMBER        := TO_NUMBER (pn_fromaccountno);
      pc_kasa_kod          NUMBER;

      pn_kanal_numara      NUMBER        := 1;
      exacc_b               VARCHAR2(16);
      exacc_a               VARCHAR2(16);
      ls_ISTATISTIK_KODU    VARCHAR2(10);
      ls_PREFIX_STAT        VARCHAR2(4);
      ln_toaccno            NUMBER;
      ln_CHARGE_AMOUNT        NUMBER;

      notenoughbalance      exception;--ernestk 29042014 cqdb00001011 if not enough balance
      isCloseAccount 			EXCEPTION; --IF CLOSED hesap

      ls_order_number VARCHAR2(16); --chyngyzo 10122014 cq1264  order number

   BEGIN
      pn_islem_no := Pkg_Tx.islem_no_al;
      pn_islem_kod := 1203;
      exacc_b := TO_CHAR(Pkg_Hesap.External_HesapNo_Al(ps_fromaccountno));--,'FM000000000');
      exacc_a := LPAD(ps_toaccountno,16,'0');--TO_CHAR(Pkg_Hesap.External_HesapNo_Al(ps_toaccountno),'FM000000000');

      ln_toaccno:=Pkg_Hesap.GetHesapNoFromExternal(exacc_a,ps_currencycode);
      ls_PREFIX_STAT := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ps_fromaccountno))) ||
                        Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ps_fromaccountno))) ||
                        Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_toaccno))) ||
                        Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ln_toaccno))) ;

      ls_ISTATISTIK_KODU:=Pkg_Message.Split(ps_paymentcode,';',0);


       --sevalb 310507  virman modul tur urun tur urun siniflari degisti
        Pkg_Tx1203.sp_urun_tur_sinif_al(  pn_fromaccountno,
                                            ln_toaccno  ,
                                           ps_currencycode ,
                                           'E',
                                           pc_modul_tur_kod,
                                            pc_urun_tur_kod,
                                            pc_urun_sinif_kod);

   --sevalb 310507  virman modul tur urun tur urun siniflari asagidaki kisim kapatildi.
      /*ap.urunbilgial (pc_hesap_numara,
                             pc_modul_tur_kod,
                             pc_urun_tur_kod,
                             pc_urun_sinif_kod
                            );*/

      IF pc_doviz_kod=Pkg_Genel.LC_al THEN
          IF Pkg_Musteri.sf_musteri_tipi_al(pn_musteri_numara)=3 THEN
              ln_CHARGE_AMOUNT:=Pkg_Aps.ChargeAutoCalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
          ELSE
                ln_CHARGE_AMOUNT:=Pkg_Aps.ChargeAutoCalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
          END IF;
      ELSE
            ln_CHARGE_AMOUNT:=Pkg_Aps.ChargeAutoCalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);
      END IF;

      --B-O-M ernestk 29042014 cqdb00001011 check if available balance


      IF PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pc_hesap_numara) < (ln_tutar + ln_charge_amount) THEN
        raise notenoughbalance;
      END IF;
      --E-O-M ernestk 29042014 cqdb00001011 check if available balance
    
     --checking the account closed
    OPEN pc_ref FOR SELECT 1 FROM CBS_HESAP WHERE EXTERNAL_HESAP_NO = pn_toaccountno AND
    	DURUM_KODU='A' AND HESAP_HAREKET_KODU IN (1,2);
    IF pc_ref IS NULL THEN
    raise isCloseAccount;
    END IF;

      OPEN pc_ref   FOR        SELECT pn_islem_no            FROM DUAL;

    --BOM chyngyzo  10122014 cq1264  order number assignment
    IF nvl(length(trim(ps_order_number)), 0) = 0 THEN
        ls_order_number :=  'I' || trim(SUBSTR(to_char(pn_islem_no), 1, 15));
    ELSE
        ls_order_number :=  'I' || trim(SUBSTR(ps_order_number, 1, 15));
    END IF;
    --EOM chyngyzo  10122014 cq1264  order number assignment


      INSERT INTO CBS_VIRMAN_ISLEM
                  (tx_no, borc_hesap_no, doviz_kodu, tutar,alacak_hesap_no, aciklama, dekont_basim_f,
                  BORC_EXTERNAL_HESAP,ALACAK_EXTERNAL_HESAP, BORC_VERGI_NO,ALACAK_VERGI_NO,PREFIX_ISTATISTIK_KODU, ISTATISTIK_KODU,CHARGE_AMOUNT, REF_NO) --chyngyzo 10122014 cq1264 add order number
           VALUES (pn_islem_no, ps_fromaccountno, ps_currencycode, ln_tutar,
                   ln_toaccno, ps_description, ps_isdekont,exacc_b,exacc_a,Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(pn_fromaccountno)),
                   Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(ln_toaccno)),  ls_PREFIX_STAT ,ls_ISTATISTIK_KODU,ln_CHARGE_AMOUNT, ls_order_number); --chyngyzo 10122014 cq1264 add order number

      Pkg_Int_Api.create_transaction (pn_islem_no,
                                      pn_islem_kod,
                                      pc_modul_tur_kod,
                                      pc_urun_tur_kod,
                                      pc_urun_sinif_kod,
                                      ln_tutar,
                                      pc_amir_bolum_kodu,
                                      pc_bolum_kodu,
                                      pc_rol,
                                      pc_doviz_kod,
                                      pn_musteri_numara,
                                      pc_hesap_numara,
                                      pc_kasa_kod,
                                      pn_kanal_numara
                                     );

      Pkg_Int_Api.process_transaction (pn_islem_no);

      RETURN ls_returncode;

   EXCEPTION
      --B-O-M ernestk 29042014 cqdb00001011 if not enough balance
      WHEN notenoughbalance THEN
         ROLLBACK;
         ls_returncode := '502';
         log_at('Bakiye yeterli degil',pc_hesap_numara,Pkg_Hesap.Kullanilabilir_Bakiye_Al(pc_hesap_numara), ln_TUTAR + ln_CHARGE_AMOUNT);
         OPEN pc_ref   FOR        SELECT pn_islem_no            FROM DUAL;
         return ls_returncode;
      --E-O-M ernestk 29042014 cqdb00001011 if not enough balance
      WHEN isCloseAccount THEN
         ROLLBACK;
       	 ls_returncode := '548';
       	 RETURN ls_returncode;
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('B2OBHVL',SQLERRM, ls_returncode,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         ROLLBACK;

         OPEN pc_ref
          FOR
             SELECT SYSDATE
               FROM DUAL;

         RETURN ls_returncode;
   END;

--------------------------------------------------------------------------------------
   FUNCTION booktobooktransferdecont (
      pn_txno   IN       VARCHAR2,
      pc_ref    OUT      cursorreferencetype
   )
      RETURN VARCHAR2
   IS
      ls_returncode         VARCHAR2 (3)                            := '000';
      ps_borclumusteriadi   cbs_vw_hesap_izleme.isim_unvan%TYPE;
      ps_alacakmusteriadi   cbs_vw_hesap_izleme.isim_unvan%TYPE;
      ps_borclumusterino    cbs_vw_hesap_izleme.musteri_no%TYPE;
      ps_alacakmusterino    cbs_vw_hesap_izleme.musteri_no%TYPE;
      ps_borcluhesapno      CBS_VIRMAN_ISLEM.borc_hesap_no%TYPE;
      ps_alacaklihesapno    CBS_VIRMAN_ISLEM.alacak_hesap_no%TYPE;
   BEGIN
      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;

      SELECT TO_CHAR (v.borc_hesap_no)
        INTO ps_borcluhesapno
        FROM CBS_VIRMAN_ISLEM v
       WHERE v.tx_no = TO_NUMBER (pn_txno);

      SELECT v.alacak_hesap_no
        INTO ps_alacaklihesapno
        FROM CBS_VIRMAN_ISLEM v
       WHERE v.tx_no = TO_NUMBER (pn_txno);

      Pkg_Hesap.musteribilgial (ps_borcluhesapno,
                                ps_borclumusterino,
                                ps_borclumusteriadi
                               );
      Pkg_Hesap.musteribilgial (ps_alacaklihesapno,
                                ps_alacakmusterino,
                                ps_alacakmusteriadi
                               );

      OPEN pc_ref
       FOR
          SELECT v.tx_no, Pkg_Hesap.hesaptansubeal (v.borc_hesap_no),
                 v.borc_hesap_no,
                 Pkg_Hesap.hesaptansubeal (v.alacak_hesap_no),
                 v.alacak_hesap_no, v.doviz_kodu, v.tutar, v.aciklama,
                 TO_CHAR (i.kayit_tarih, 'YYYYMMDD'), ps_borclumusteriadi,
                 ps_alacakmusteriadi
            FROM CBS_VIRMAN_ISLEM v, CBS_ISLEM i
           WHERE v.tx_no = TO_NUMBER (pn_txno) AND v.tx_no = i.numara;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '288';
         RETURN ls_returncode;
   END;
--------------------------------------------------------------------------------------
   FUNCTION ClearingDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
      ln_count  NUMBER;
      Ex     EXCEPTION;
   BEGIN
      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;

             SELECT COUNT(*)
             INTO ln_count
             FROM CBS_CLEARING_MT102 a,CBS_CLEARING_MT102_DETAIL b
             WHERE a.tx_no = pn_txno
                AND a.tx_no = b.tx_no;

  IF ln_count = 0
  THEN
        RAISE Ex;
  END IF;

      OPEN pc_ref
       FOR
             SELECT
                TO_CHAR(a.VALUE_DATE,'DD.MM.YYYY'),a.MSG_STATUS,a.TOTAL_TRAN_AMOUNT,a.BRANCH_CODE,TO_CHAR(b.TRAN_DATE,'DD.MM.YYYY'),
                b.TRAN_AMOUNT,Pkg_Hesap.GetHesapNoFromExternal(b.from_account,Pkg_Genel.LC_al),b.FROM_NAME,b.FROM_RNN,b.FROM_IRS,
                b.FROM_SECO,b.FROM_BRANCH,b.FROM_HQ,b.TO_BRANCH,b.TO_HQ,
                b.TO_ACCOUNT,b.TO_NAME,b.TO_RNN,b.TO_IRS,b.TO_SECO,
                b.REF_NO,b.tx_no,b.DOC_ASSIGN
             FROM CBS_CLEARING_MT102 a,CBS_CLEARING_MT102_DETAIL b
             WHERE a.tx_no = pn_txno
                AND a.tx_no = b.tx_no;
      RETURN ls_returncode;
   EXCEPTION
      WHEN Ex  THEN
         ls_returncode := '028';
         RETURN ls_returncode;
      WHEN OTHERS  THEN
         ls_returncode := '288';
         RETURN ls_returncode;
   END;
--------------------------------------------------------------------------------------
   FUNCTION efttimecontrol (
      ps_dummy   IN       VARCHAR2,
      pc_ref     OUT      cursorreferencetype
   )
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3)  := '000';
      ls_result       VARCHAR2 (1)  := '0';
      ps_starthour    VARCHAR2 (10);
      ps_endhour      VARCHAR2 (10);
      ps_tmp          NUMBER        := 0;
      TimeException     EXCEPTION;
   BEGIN
      ps_tmp := Pkg_Int_Transfer.geteftsaatsinirlari (ps_starthour, ps_endhour);

      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;

      IF (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_endhour) = 1)
      THEN                                          -- ?st s?n?rdan sonra ise
        RAISE TimeException;
      ELSIF (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_starthour) = 2)
      THEN                                            -- alt s?n?rdan ?nce ise
        RAISE TimeException;
      ELSE
         NULL;
      END IF;

--      IF (Pkg_Muhasebe.Banka_Tarihi_Bul <> TRUNC (SYSDATE))
--      THEN
--        RAISE TimeException;
--     END IF;

      OPEN pc_ref
       FOR
          SELECT ps_starthour, ps_endhour
            FROM DUAL;

      ls_returncode := '000';
      RETURN ls_returncode;
    EXCEPTION
        WHEN TimeException THEN
        OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;
        RETURN '055';
   END;
-----------------------------------------------------------------
   FUNCTION checktime (pd_desc IN VARCHAR2, pd_src IN VARCHAR2)
      RETURN NUMBER
   IS
   BEGIN
       -- desc su an ki saat dilimi 16:44 mesela
      -- src de sistemde kay?tl? bulunan saat 16:00 mesela
      IF (TO_NUMBER (SUBSTR (pd_desc, 0, 2)) >
                                             TO_NUMBER (SUBSTR (pd_src, 0, 2))
         )
      THEN
         RETURN 1;                                                   -- b?y?k
      ELSIF (TO_NUMBER (SUBSTR (pd_desc, 0, 2)) <
                                             TO_NUMBER (SUBSTR (pd_src, 0, 2))
            )
      THEN
         RETURN 2;                                                   -- k???k
      ELSE
         IF (TO_NUMBER (SUBSTR (pd_desc, 4, 2)) >
                                             TO_NUMBER (SUBSTR (pd_src, 4, 2))
            )
         THEN
            RETURN 1;                                                 --b?y?k
         ELSE
            RETURN 2;                                                 --k???k
         END IF;
      END IF;
   END;

-----------------------------------------------------------------
   FUNCTION geteftsaatsinirlari (ps_start OUT VARCHAR2, ps_end OUT VARCHAR2)
      RETURN NUMBER
   IS

   BEGIN

      SELECT t.ILK_SAAT, t.SON_SAAT
      INTO ps_start,ps_end
      FROM CBS_EFT_SAAT t;

      IF (LENGTH(ps_start)<> 5 ) THEN
       ps_start:='07:00';
      END IF;
      IF (LENGTH(ps_end)<> 5 ) THEN
       ps_end:='11:00';
      END IF;

      RETURN 1;

   EXCEPTION
      WHEN OTHERS
      THEN
         ps_start := '07:00';
         ps_end := '11:00';
         RETURN 1;
   END;

---------------------------------------------------------------------
/*   FUNCTION eftcancel (ps_txno IN VARCHAR2, pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;

      Pkg_Tx.gecici_islem_sil (ps_txno);
      COMMIT;
      Pkg_Eft.iptal_sonrasi_iptal_et (ps_txno);
      COMMIT;
      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         ROLLBACK;

         OPEN pc_ref
          FOR
             SELECT SYSDATE
               FROM DUAL;

         RETURN ls_returncode;
   END;
*/
---------------------------------------------------------------------------
   FUNCTION FxBuyDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;

      OPEN pc_ref  FOR
        SELECT
        TX_NO,TO_CHAR(ISLEM_TARIHI,'DD.MM.YYYY'),MUSTERI_NO,MUSTERI_HESAP_NO,DOVIZ_KODU,
        DOVIZ_TUTARI,KUR,DTH_MUSTERI_HESAP_NO,MASRAF,TAHSIL_ADILEN_TOPLAM_TUTAR
        FROM CBS_DTH_DOVIZ_SATIS_ISLEM
        WHERE tx_no = pn_txno;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '288';
         RETURN ls_returncode;
   END;
------------------------------------------------------------------------------
   FUNCTION FxSellDekont (pn_txno IN VARCHAR2, pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      OPEN pc_ref
       FOR
          SELECT SYSDATE
            FROM DUAL;
      OPEN pc_ref  FOR
        SELECT
            a.TX_NO,a.BORC_HESAP_NO,a.DOVIZ_KODU,a.KUR,a.TUTAR,
            a.ALACAK_HESAP_NO,TO_CHAR(b.ONAY_SISTEM_TARIHI,'DD.MM.YYYY')
        FROM CBS_DTH_TL_ODEME_ISLEM a, CBS_ISLEM b
        WHERE a.tx_no = pn_txno
          AND a.tx_no = b.numara;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '288';
         RETURN ls_returncode;
   END;
------------------------------------------------------------------------------
   FUNCTION CheckRNNExternalAccount (pn_bankcode IN VARCHAR2,
                                    pn_externalaccount IN VARCHAR2,
                                 pn_rnn IN VARCHAR2,
                                    pc_ref OUT cursorreferencetype)  RETURN VARCHAR2  IS

      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN

     --log_at(pn_bankcode,pn_externalaccount,pn_rnn);

     IF Pkg_Hesap.Check_External_HesapNo(pn_bankcode,pn_externalaccount)=0 THEN
         ls_returncode:='023';
     END IF;
     IF Pkg_Musteri.TaxNumberControl(pn_rnn)=0 THEN
         ls_returncode:='022';
     END IF;


     OPEN pc_ref  FOR SELECT SYSDATE   FROM DUAL;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         ls_returncode := '288';
         RETURN ls_returncode;
   END;
------------------------------------------------------------------------------------
FUNCTION MakeUtilityPayment(p_FromAccount IN VARCHAR2,
                             p_SenderName IN VARCHAR2,
                            p_InstitutionCD IN VARCHAR2,
                            p_Description     IN VARCHAR2,
                            p_Amount     IN VARCHAR2,
                            p_AreaCD     IN VARCHAR2,
                            p_PhoneNo     IN       VARCHAR2,
                            p_SubscriptionNo     IN       VARCHAR2,
                            p_InvoiceNo     IN       VARCHAR2,
                            p_KeyNo     IN       VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ls_fromaccountno     NUMBER;
        ln_tutar             NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777; -- herhalde internet ?ubesi bu oluyor
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER;
        pn_kanal_numara      NUMBER:= 1;
        exacc_b               VARCHAR2(9);
        exacc_a               VARCHAR2(9);
        ls_ISTATISTIK_KODU    VARCHAR2(3);
        ls_PREFIX_STAT        VARCHAR2(4);
        ls_description        VARCHAR2(200);
        ls_sendername        VARCHAR2(250);

        ls_INSTITUTION_CODE        VARCHAR2(20);
        ls_COLLECTION_ACCOUNT_NO       NUMBER;
        ls_COLLECTION_ACCOUNT_BR       VARCHAR2(10);
        ls_COLLECTION_GL               VARCHAR2(8);
        ls_COLLECTION_GL_BR               VARCHAR2(10);

   BEGIN

        ln_islem_no             :=Pkg_Tx.islem_no_al;
        ln_islem_kod      :=7004;
        lc_modul_tur_kod  :='COLLECTION';
        lc_urun_tur_kod   :='ACCOUNT';
        lc_urun_sinif_kod :='LC';
        ln_hesap_numara   :=TO_NUMBER(p_FromAccount);
        ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);
        --ln_tutar          :=TO_NUMBER (REPLACE(REPLACE(p_Amount, ',', ''),'.',','));
        ln_tutar          :=TO_NUMBER(p_Amount,'99999999999.99');
        lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
        lc_amir_bolum_kodu:=lc_bolum_kodu;
        lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);
        ls_INSTITUTION_CODE:=p_InstitutionCD ;

        IF LENGTH(LTRIM(p_SenderName))<5 THEN
           ls_sendername:=Pkg_Musteri.Sf_Musteri_Adi(ln_musteri_numara);
        ELSE
           ls_sendername:=p_SenderName;
        END IF;

        Pkg_Tx7004.Collect_To(ls_INSTITUTION_CODE,
                                            ls_COLLECTION_ACCOUNT_NO,
                                            ls_COLLECTION_ACCOUNT_BR,
                                            ls_COLLECTION_GL,
                                            ls_COLLECTION_GL_BR);

        ls_PREFIX_STAT := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(ln_musteri_numara)) ||
                        Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(ln_musteri_numara)) ||
                        Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ls_COLLECTION_ACCOUNT_NO))) ||
                        Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(ls_COLLECTION_ACCOUNT_NO))) ;

          ls_ISTATISTIK_KODU:='852';

        ls_description:=NVL(p_Description || 'No:' || p_AreaCD || p_PhoneNo ,'KCELL PAYMENT' || 'No:' || p_AreaCD || p_PhoneNo);

        INSERT INTO CBS_COLLECTION_MASTER_TRAN
        (TX_NO, COLLECTION_DATE, COLLECTION_TYPE, COLLECTION_CHANNEL, BRANCH, CUSTOMER_NO, ACCOUNT_NO, NAME_TITLE, CURRENCY_CODE, EXPLANATION, CASH_CODE, PREFIX_STATISTICAL_CODE, STATISTICAL_CODE, ACCOUNT_BRANCH)
        VALUES
        (ln_islem_no, Pkg_Muhasebe.Banka_Tarihi_Bul, lc_urun_tur_kod, 'INTERNET', lc_bolum_kodu, ln_musteri_numara, ln_hesap_numara, ls_sendername, lc_doviz_kod, ls_description, NULL, ls_PREFIX_STAT, ls_ISTATISTIK_KODU, lc_bolum_kodu);

        INSERT INTO CBS_COLLECTION_DETAIL_TRAN
        (TX_NO, INSTITUTION_CODE, COLLECTION_AMOUNT, AREA_CODE, PHONE_NO, SUBSCRIPTION_NO, INVOICE_NO, INSTITUTION_KEY_NO, COLLECTION_GL, COLLECTION_ACCOUNT_NO, COLLECTION_GL_BR, COLLECTION_ACCOUNT_BR, FROMBANK_BIC, STATUS_CD, DETAIL_ID,NAME_TITLE)
        VALUES
        (ln_islem_no, ls_INSTITUTION_CODE, ln_tutar, p_AreaCD, p_PhoneNo, NULL, NULL, NULL, ls_COLLECTION_GL, ls_COLLECTION_ACCOUNT_NO,ls_COLLECTION_GL_BR,ls_COLLECTION_ACCOUNT_BR, NULL, 'sWAIT', Pkg_Genel.genel_kod_al('COLLECTION_DETAIL'),ls_sendername);

        Pkg_Int_Api.create_transaction (ln_islem_no,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_amir_bolum_kodu,
                                      lc_bolum_kodu,
                                      pc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_numara,
                                      ln_hesap_numara,
                                      pc_kasa_kod,
                                      pn_kanal_numara);
        Pkg_Int_Api.process_transaction (ln_islem_no);

        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;

        RETURN ls_returncode;


   EXCEPTION
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At (SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
   END;

------------------------------------------------------------------------------------------
FUNCTION CancelClearing(p_TXNO IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode            VARCHAR2(3):='000';
    ln_count                NUMBER;
BEGIN

     OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

     UPDATE CBS_CLEARING t
     SET t.MSG_STATUS = 'sCANCEL'
     WHERE t.YARATAN_TX_NO = TO_NUMBER(p_TXNO);

     UPDATE CBS_ISLEM
     SET durum='2'
     WHERE NUMARA=TO_NUMBER(p_TXNO);

      DELETE FROM CBS_SATIR
      WHERE FIS_NUMARA IN (SELECT NUMARA FROM CBS_FIS WHERE ISLEM_NUMARA=TO_NUMBER(p_TXNO) AND TUR='T');

     DELETE FROM CBS_FIS
     WHERE ISLEM_NUMARA=TO_NUMBER(p_TXNO)
     AND TUR='T';

     RETURN ls_returncode;
END;

-----------------------------------------------------------------------------------------
FUNCTION ControlPensionPayment(p_CustomerID IN VARCHAR2,
                                p_strFromAccount IN VARCHAR2,
                                p_strFromRNN IN VARCHAR2,
                               p_str32A_Date IN VARCHAR2,
                               p_str32A_Amount IN VARCHAR2,
                               p_str32A_CAmount IN VARCHAR2,
                               p_strToAccount IN VARCHAR2,
                               p_strToNBAccount IN VARCHAR2,
                               p_strToBranch IN VARCHAR2,
                               p_strToRNN IN VARCHAR2,
                               p_strKNP IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode            VARCHAR2(3):='000';
BEGIN
  RETURN ls_returncode;

/* should be checked for internet

    CURSOR cursor_clearchk(ps_FIELD_59 VARCHAR2) IS
                 SELECT *
               FROM CBS_CLEARING_CHECKLIST
               WHERE FIELD_59 = ps_FIELD_59;
    row_clearchk     cursor_clearchk%ROWTYPE;

    ErrorPERIODException                     EXCEPTION;
    ErrorCheckException                         EXCEPTION;
    TotalTranSumWrong                         EXCEPTION;
    InvalidBankCode                             EXCEPTION;
    ToBankCodeAccountError                     EXCEPTION;
    FromBankCodeAccountError                 EXCEPTION;
    FromAccountError                         EXCEPTION;
    ToRNNError                                 EXCEPTION;
    FromRNNError                             EXCEPTION;
    FromBankAccountError                     EXCEPTION;

    ln_32AAmount                             NUMBER;
    ln_32AAmountCalculated                     NUMBER;
    ln_musterino                             NUMBER;
    ls_frombankcode                             VARCHAR2(9);


BEGIN

    OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

    --1-From Account is Correct?
    BEGIN
        ln_musterino:=Pkg_Hesap.GetMusteriNoFromExternal(p_strFromAccount);
        ls_frombankcode:=Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(Pkg_Hesap.GetHesapNoFromExternal(p_strFromAccount)));
    EXCEPTION
        WHEN OTHERS THEN
           RAISE FromAccountError;
    END;
    IF TO_NUMBER(p_CustomerID)!=ln_musterino THEN
       RAISE FromBankCodeAccountError;
    END IF;

    --2-From Account and Bank Code is Correct?
    IF Pkg_Hesap.Check_External_HesapNo(ls_frombankcode,p_strFromAccount)=0 THEN
       RAISE FromBankAccountError;
    END IF;

    --2-From RNN is Correct?
    IF Pkg_Musteri.TaxNumberControl(p_strFromRNN)=0 THEN
       RAISE FromRNNError;
    END IF;

    --3-To Account  and Bank Code is Correct?
    IF Pkg_Hesap.Check_External_HesapNo(p_strToBranch,p_strToAccount)=0 THEN
       RAISE ToBankCodeAccountError;
    END IF;

    --4-TO RNN is Correct?
    IF Pkg_Musteri.TaxNumberControl(p_strToRNN)=0 THEN
       RAISE ToRNNError;
    END IF;

    --5-Check Rules Correct?
    OPEN cursor_clearchk(p_strToAccount);
    FETCH cursor_clearchk INTO row_clearchk;
    IF cursor_clearchk%FOUND THEN
       IF INSTR(row_clearchk.FIELD_57B,p_strToBranch)=0 OR
                 INSTR(row_clearchk.FIELD_RNN,p_strToRNN)=0 OR
              INSTR(NVL(row_clearchk.FIELD_54C,NVL(p_strToNBAccount,'-')),NVL(p_strToNBAccount,'-'))=0 OR
              INSTR(row_clearchk.FIELD_KNP,p_strKNP)=0 THEN
            RAISE ErrorCheckException;
       END IF;
    END IF;
    CLOSE cursor_clearchk;

    --6-Total Amount is Equal to calculated amount?
    ln_32AAmount:=TO_NUMBER(REPLACE(p_str32A_Amount,'.','.'));
    --ln_32AAmount:=TO_NUMBER(replace(p_str32A_Amount,',','.'),'99999999999.99');
    --log_at('CONTROL PENSION',ln_32AAmount);
    ln_32AAmountCalculated:=TO_NUMBER(ROUND(p_str32A_CAmount,2));
    --ln_32AAmountCalculated:=Round(TO_NUMBER(replace(p_str32A_CAmount,',','.')),2);
    --log_at('CONTROL PENSION',ln_32AAmountCalculated);

    IF ln_32AAmount!=ln_32AAmountCalculated THEN
       RAISE TotalTranSumWrong;
    END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN TotalTranSumWrong THEN
         ls_returncode:='601';
         RETURN ls_returncode;
    WHEN ErrorCheckException THEN
         ls_returncode:='602';
         RETURN ls_returncode;
    WHEN ToBankCodeAccountError THEN
         ls_returncode:='603';
         RETURN ls_returncode;
    WHEN FromBankCodeAccountError THEN
         ls_returncode:='604';
         RETURN ls_returncode;
    WHEN FromAccountError THEN
         ls_returncode:='605';
         RETURN ls_returncode;
    WHEN ToRNNError THEN
         ls_returncode:='606';
         RETURN ls_returncode;
    WHEN FromRNNError THEN
         ls_returncode:='607';
         RETURN ls_returncode;
    WHEN FromBankAccountError THEN
         ls_returncode:='608';
         RETURN ls_returncode;

    WHEN OTHERS THEN
         Log_At('CONTROL PENSION',p_str32A_CAmount,p_str32A_Amount,SQLERRM);
         */
END;
-----------------------------------------------------------------------------------------
FUNCTION TransferToCard(pn_fromaccountno IN VARCHAR2,
                             pn_tocardno IN VARCHAR2,
                            ps_amount IN VARCHAR2,
                            ps_description     IN VARCHAR2,
                            ps_currencycode     IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ln_tutar             NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777; -- herhalde internet ?ubesi bu oluyor
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER;
        pn_kanal_numara      NUMBER:= 1;
        ls_description        VARCHAR2(200);
        ls_FROM_EXTERNAL_ACCOUNT VARCHAR2(9);
        ls_FROM_TAX_NUMBER         VARCHAR2(12);
        ls_FROM_NAME             VARCHAR2(250);
        ls_FROM_BANK_CODE         VARCHAR2(9);
        ln_TO_CARD_CUSTOMER_NO     NUMBER;
        ls_TO_CARD_CUSTOMER_NAME VARCHAR2(250);
        ls_PAYMENT_TYPE_DESC     VARCHAR2(32);
        ln_CHARGE_ACCOUNT         NUMBER;
        ln_CHARGE_AMOUNT         NUMBER;
        TimeException             EXCEPTION;
   BEGIN

           ls_returncode:=Pkg_Int_Limit.CheckTimeLimit('CARDPYM');
        IF ls_returncode<>'000' THEN
           RAISE TimeException;
        END IF;

        ln_islem_no             :=Pkg_Tx.islem_no_al;
        ln_islem_kod      :=2130;
        lc_modul_tur_kod  :='CARD';
        lc_urun_tur_kod   :='TRANSFER';
        lc_urun_sinif_kod :='TOCARD';
        ls_PAYMENT_TYPE_DESC := 'P2C';
        ln_hesap_numara   :=TO_NUMBER(pn_fromaccountno);
        ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);
        ln_tutar          :=TO_NUMBER(ps_amount,'99999999999.99');
        lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
        lc_amir_bolum_kodu:=lc_bolum_kodu;
        lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);
        ls_description      :=ps_description;
        ls_FROM_EXTERNAL_ACCOUNT := LPAD(Pkg_Hesap.External_HesapNo_Al(ln_hesap_numara),9,0);
        ls_FROM_TAX_NUMBER:=Pkg_Musteri.Sf_VergiNo_Al(ln_musteri_numara);
        ls_FROM_NAME      :=Pkg_Musteri.Sf_Musteri_Adi(ln_musteri_numara);
        ls_FROM_BANK_CODE :=Pkg_Genelkz.GetOurBICCode(lc_bolum_kodu);
        ln_TO_CARD_CUSTOMER_NO := Pkg_Card.GetCustomerFromCardNo(pn_tocardno);
        ls_TO_CARD_CUSTOMER_NAME :=Pkg_Musteri.Sf_Musteri_Adi(ln_TO_CARD_CUSTOMER_NO);
        ln_CHARGE_ACCOUNT:=ln_hesap_numara;

        IF Pkg_Card.IsSalaryCard(pn_tocardno)='Y' THEN
            ln_CHARGE_AMOUNT  :=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, ln_hesap_numara, pc_kasa_kod);
        ELSE
            ln_CHARGE_AMOUNT  := 0;
        END IF;
        INSERT INTO CBS_CARD_PAYMENT_ISLEM
        (TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO, FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_CARD_NO, BOLUM_KODU, PAYMENT_DESCRIPTION, AMOUNT, CURRENCY_CODE, TO_CARD_CUSTOMER_NO, TO_CARD_CUSTOMER_NAME, PAYMENT_TYPE_DESC, CHARGE_AMOUNT, CHARGE_ACCOUNT)
        VALUES
        (ln_islem_no,lc_modul_tur_kod ,lc_urun_tur_kod,lc_urun_sinif_kod,ln_musteri_numara,ln_hesap_numara, ls_FROM_EXTERNAL_ACCOUNT, ls_FROM_TAX_NUMBER, ls_FROM_NAME, ls_FROM_BANK_CODE, pn_tocardno, lc_bolum_kodu, ls_description, ln_tutar, ps_currencycode, ln_TO_CARD_CUSTOMER_NO, ls_TO_CARD_CUSTOMER_NAME, ls_PAYMENT_TYPE_DESC,ln_CHARGE_AMOUNT, ln_CHARGE_ACCOUNT);


        Pkg_Int_Api.create_transaction (ln_islem_no,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_amir_bolum_kodu,
                                      lc_bolum_kodu,
                                      pc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_numara,
                                      ln_hesap_numara,
                                      pc_kasa_kod,
                                      pn_kanal_numara);

        --Pkg_Int_Api.process_transaction (ln_islem_no);

        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;

        RETURN ls_returncode;


   EXCEPTION
         WHEN TimeException THEN
           OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;
         RETURN ls_returncode;

      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('P2OCARD',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION MakeSalaryPayment
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Make Salary Payment
*******************************************************************************/
FUNCTION MakeSalaryPayment( ps_todo_txno IN VARCHAR2,
                                                         ps_fromAccNo IN VARCHAR2,
                                                         ps_totalAmount IN VARCHAR2,
                                                         pc_ref OUT CursorReferenceType ) RETURN VARCHAR2   IS
        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ln_tutar             NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777;
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER ;
        pn_kanal_numara      NUMBER:= 1;

        ln_CHARGE_AMOUNT          NUMBER;

        lc_tmp CursorReferenceType;
        ls_firmID CBS_SALARY_PAYMENT_FIRM_DEF.FIRM_ID%TYPE;
        ls_fileName VARCHAR2(200);
        ln_staffCount NUMBER;
        ls_description VARCHAR2(500);
        ls_valueDate VARCHAR2(10);

        CURSOR status_updates IS
            SELECT STATUS,
                         PKG_HESAP.HESAPTANMUSTERINOAL(PKG_HESAP.GETHESAPNOFROMEXTERNAL(STAFF_ACC_NO, CURRENCY)) STAFF_CUSTNO,
                         COMPANY_CUST_NO

            FROM corpint.TBL_SALARY_PAYMENT_TX
            WHERE TODO_TXNO=ps_todo_txno and STATUS IN ('NEW', 'DELETE');

        ln_company_of_the_staff NUMBER;
        ln_company_of_the_staff_2 NUMBER;
        ln_company_of_the_staff_3 NUMBER;

        notenoughbalance EXCEPTION;
        ls_bloke_referans   CBS_BLOKE.BLOKE_REFERANS%TYPE;

    ls_user VARCHAR2(12) := 'CINT_CALLER';
    ls_branch VARCHAR2(5) := '010';


 BEGIN

    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

     ln_tutar          :=  TO_NUMBER(ps_totalAmount,'99999999999.99');

     --add / delete staff -------------------------------------------------------------------------
     FOR rw_status IN status_updates LOOP

       SELECT COMPANY_OF_THE_STAFF, COMPANY_OF_THE_STAFF_2 , COMPANY_OF_THE_STAFF_3
                INTO ln_company_of_the_staff, ln_company_of_the_staff_2, ln_company_of_the_staff_3
           FROM CBS_MUSTERI
            WHERE MUSTERI_NO=rw_status.STAFF_CUSTNO;

        IF rw_status.STATUS = 'NEW'
            AND (ln_company_of_the_staff IS NULL OR ln_company_of_the_staff <> rw_status.COMPANY_CUST_NO )
            AND (ln_company_of_the_staff_2 IS NULL OR ln_company_of_the_staff_2 <> rw_status.COMPANY_CUST_NO)
            AND (ln_company_of_the_staff_3 IS NULL OR ln_company_of_the_staff_3 <> rw_status.COMPANY_CUST_NO)  THEN


            IF ln_company_of_the_staff IS NULL THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF = rw_status.COMPANY_CUST_NO
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
            ELSIF ln_company_of_the_staff_2 IS NULL THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF_2 = rw_status.COMPANY_CUST_NO
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
             ELSIF ln_company_of_the_staff_3 IS NULL THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF_3 = rw_status.COMPANY_CUST_NO
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
            END IF;

        ELSIF rw_status.STATUS = 'DELETE' THEN

            IF ln_company_of_the_staff = rw_status.COMPANY_CUST_NO THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF = NULL
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
            END IF;

            IF ln_company_of_the_staff_2 = rw_status.COMPANY_CUST_NO THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF_2 = NULL
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
            END IF;

            IF ln_company_of_the_staff_3 = rw_status.COMPANY_CUST_NO THEN
                UPDATE CBS_MUSTERI
                SET COMPANY_OF_THE_STAFF_3 = NULL
                WHERE MUSTERI_NO = rw_status.STAFF_CUSTNO;
            END IF;
        END IF;
     END LOOP;
     --------------------------------------------------------------------------------------------

     if  ln_tutar  <= 0 then
        return ls_returncode;
    end if;


    --ln_islem_no :=  Pkg_Tx.islem_no_al;
    ln_islem_kod := 2150;
    lc_modul_tur_kod  :='CUSTOMER';
    lc_urun_tur_kod   :='SALARY';
    lc_urun_sinif_kod :='CIBPAYMENT';
    ln_hesap_numara   :=TO_NUMBER(ps_fromAccNo);
    ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);

    lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
    lc_amir_bolum_kodu:=lc_bolum_kodu;
    lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);

    ls_returncode := pkg_soa_inquiry.getSalaryFirmID(ln_musteri_numara, lc_tmp);


    if ls_returncode <> '000' then
        return ls_returncode;
    end if;

    FETCH lc_tmp INTO ls_firmID;

    SELECT FIELD7, FIELD8,  FIELD9, FIELD11, FIELD12
        INTO ls_description, ls_fileName, ln_staffCount, ls_valueDate, ln_islem_no
    FROM CORPINT.TBL_TXTODO
    WHERE TX_NO=ps_todo_txno;

       /* SELECT SUM(NVL(AMOUNT,0))
        INTO ln_tutar
        FROM CBS_SALARY_DETAIL_ISLEM
        WHERE TX_NO=ln_islem_no;*/


    ln_CHARGE_AMOUNT  :=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                                                                                     ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, ln_hesap_numara, pc_kasa_kod);
    Pkg_Masraf.validate_masraf(ln_islem_no);

    IF PKG_HESAP.KULLANILABILIR_BAKIYE_AL(ln_hesap_numara) < (ln_tutar + ln_charge_amount) THEN
        raise notenoughbalance;
    END IF;


   /*block payment amount*/    --AlmasN 20170630 No need to do blockage because no risk here
   /*pkg_bloke.sp_bloke_yarat (
                                     ls_bloke_referans, --ps_bloke_referans
                                     ln_musteri_numara, --pn_MUSTERI_NO
                                     ln_hesap_numara, --pn_HESAP_NO
                                     lc_doviz_kod, --ps_DOVIZ_KODU
                                     ln_tutar + ln_charge_amount, --pn_BLOKE_TUTARI
                                     13, --ps_BLOKE_NEDEN_KODU
                                     'Blockage of Salary Payment via IB ', --ps_ACIKLAMA
                                     pkg_muhasebe.banka_tarihi_bul, --pd_BLOKE_TARIHI
                                     null, --pd_BLOKE_BITIS_TARIHI
                                     null, --pn_REF_TX_NO
                                     null, --pn_tx_no
                                     pkg_muhasebe.banka_tarihi_bul, --p_KAYIT_TARIH
                                     sysdate, --p_KAYIT_SISTEM_TARIHI
                                     ls_user, --p_KAYIT_KULLANICI_KODU
                                     ls_branch,  --p_KAYIT_KULLANICI_BOLUM_KODU
                                    p_ONAY_KULLANICI_BOLUM_KODU => ls_branch
                                    ) ;*/
       /*********************/

        SELECT count(*) into ln_staffCount
           FROM corpint.TBL_SALARY_PAYMENT_TX
           WHERE TODO_TXNO=ps_todo_txno and AMOUNT > 0 and STATUS IN ('EXISTING', 'NEW');


     INSERT INTO CBS_SALARY_ISLEM(TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, SALARY_DATE, FILE_NAME, CUSTOMER_NO, STAFF_COUNT, TOTAL_AMOUNT, CHARGE_AMOUNT, FIRM_ID, BLOKE_REFERANS)
     VALUES(ln_islem_no,lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod, TO_DATE(ls_valueDate, 'dd/mm/yyyy'), ls_fileName, ln_musteri_numara, ln_staffCount, ps_totalAmount, ln_CHARGE_AMOUNT, ls_firmID, ls_bloke_referans);

     INSERT INTO CBS_SALARY_DETAIL_ISLEM
    (TX_NO, COMPANY_ACCOUNT_NO, STAFF_ACCOUNT_NO, AMOUNT, CURRENCY_CODE,
     PAYMENT_DATE, DESCRIPTION, PAYROL_NO, FIRM_CODE, ORDER_NO,
     COMPANY_ACC_IS_GL, FROM_GL_ACC_BRANCH, NAME, SURNAME, INN)
           SELECT ln_islem_no, COMPANY_ACC_NO, PKG_HESAP.GETHESAPNOFROMEXTERNAL(STAFF_ACC_NO, CURRENCY), AMOUNT,  CURRENCY,
                SYSDATE,  ls_description, NULL, ls_firmID, ORDERING,
                'H', lc_bolum_kodu,  NAME, SURNAME, NULL
           FROM corpint.TBL_SALARY_PAYMENT_TX
           WHERE TODO_TXNO=ps_todo_txno and AMOUNT > 0 and STATUS IN ('EXISTING', 'NEW');


        IF TO_DATE(ls_valueDate, 'dd/mm/yyyy') <= PKG_MUHASEBE.BANKA_TARIHI_BUL THEN

            Pkg_Int_Api.create_transaction (  ln_islem_no,
                                                                      ln_islem_kod,
                                                                      lc_modul_tur_kod,
                                                                      lc_urun_tur_kod,
                                                                      lc_urun_sinif_kod,
                                                                      ln_tutar,
                                                                      lc_amir_bolum_kodu,
                                                                      lc_bolum_kodu,
                                                                      pc_rol,
                                                                      lc_doviz_kod,
                                                                      ln_musteri_numara,
                                                                      ln_hesap_numara,
                                                                      pc_kasa_kod,
                                                                      pn_kanal_numara);

            Pkg_Int_Api.process_transaction (ln_islem_no);

        END IF;

log_at('checkln_islem_no', ln_islem_no);
        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;

        RETURN ls_returncode;


   EXCEPTION

    WHEN notenoughbalance THEN
            ROLLBACK;
            ls_returncode := '502';
            log_at('MakeSalaryPayment', '1='||ln_islem_no||' 2='||Pkg_Hesap.Kullanilabilir_Bakiye_Al(ln_hesap_numara)||' 5='||(ln_tutar + ln_CHARGE_AMOUNT));
            OPEN pc_ref FOR SELECT TO_CHAR(ln_islem_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;

      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('MakeSalaryPayment',SQLERRM, ls_returncode, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION JobMakeSalaryPayment
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Make Salary Payment in Job
*******************************************************************************/
PROCEDURE JobMakeSalaryPayment(pd_date DATE) IS

    CURSOR c_payments IS
        SELECT S.TX_NO, S.MODUL_TUR_KOD, S.URUN_TUR_KOD, S.URUN_SINIF_KOD, S.TOTAL_AMOUNT, S.CUSTOMER_NO
        FROM CBS_SALARY_ISLEM S
            LEFT JOIN CBS_ISLEM I ON S.TX_NO = I.NUMARA
        WHERE I.NUMARA IS NULL --tx is not created yet
        AND S.MODUL_TUR_KOD='CUSTOMER' AND S.URUN_TUR_KOD='SALARY' AND S.URUN_SINIF_KOD='CIBPAYMENT' --via CIB
        AND SALARY_DATE <= pd_date; --date has come or passed (if weekends)

        ln_hesap_numara      NUMBER;
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777;
        lc_doviz_kod         VARCHAR (10);
        pc_kasa_kod          NUMBER ;
        pn_kanal_numara      NUMBER:= 1;

        ls_error_code        VARCHAR2(2000);

BEGIN

    FOR rw_payment IN c_payments LOOP

        begin
            --get company acc no
            SELECT COMPANY_ACCOUNT_NO INTO ln_hesap_numara
            FROM CBS_SALARY_DETAIL_ISLEM
            WHERE TX_NO = rw_payment.TX_NO AND ROWNUM = 1;

            lc_amir_bolum_kodu := Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
            lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);


            Pkg_Int_Api.create_transaction (  rw_payment.TX_NO,
                                              2150,  --pn_islem_kod
                                              rw_payment.MODUL_TUR_KOD,
                                              rw_payment.URUN_TUR_KOD,
                                              rw_payment.URUN_SINIF_KOD,
                                              rw_payment.TOTAL_AMOUNT,
                                              lc_amir_bolum_kodu,
                                              lc_amir_bolum_kodu,
                                              pc_rol,
                                              lc_doviz_kod,
                                              rw_payment.CUSTOMER_NO,
                                              ln_hesap_numara,
                                              pc_kasa_kod,
                                              pn_kanal_numara);

            Pkg_Int_Api.process_transaction (rw_payment.TX_NO);
        exception
            when others then

                ls_error_code := SQLERRM;

                /* SEND EMAIL START */
                declare
                    ls_ret VARCHAR2(3);
                    TYPE CursorReferenceType IS REF CURSOR;
                    pc_ref CursorReferenceType;
                    ls_emails CBS_PARAMETRE.deger%TYPE;
                    ls_current_year varchar2(10);

                BEGIN

                     --replaced by GulkaiyrK  SELECT lower(wm_concat(bb.isim_eng || '.' || bb.soyadi_eng || '@demirbank.kg')), to_char(sysdate, 'yyyy')
                    SELECT    lower(trim (trailing','from
                      LISTAGG(bb.isim_eng || '.' || bb.soyadi_eng || '@demirbank.kg'||',')
                      WITHIN GROUP (ORDER BY bb.isim_eng,bb.soyadi_eng))), to_char(sysdate, 'yyyy')
                      INTO ls_emails, ls_current_year
                    FROM cbs_musteri_adres aa, cbs_musteri bb
                    WHERE aa.musteri_no=bb.musteri_no
                    and personel_sicil_no in (
                        select pazarlama_sorumlusu_sicil_no_1 from cbs_musteri
                        where musteri_no=rw_payment.CUSTOMER_NO
                        union all
                        select pazarlama_sorumlusu_sicil_no_2 from cbs_musteri
                        where musteri_no=rw_payment.CUSTOMER_NO
                    );

                    ls_ret := CORPINT2.PKG_NOTIFICATION.sendHtmlEmail(ls_emails, 'Automatic Salary Payment Report ! ! !', '{"##CUSTOMER_NO##":"'|| rw_payment.CUSTOMER_NO || '", "##CURRENT_YEAR##":"'|| ls_current_year || '", "##FULL_BANK_NAME##":"Demir Kyrgyz International Bank", "##ERROR_CODE##":"'|| ls_error_code || '", "##ERROR_MESSAGE##":"'|| pkg_hata.generatemessage(ls_error_code) || '"}', 'salary_auto', pc_ref);

                EXCEPTION
                    WHEN OTHERS THEN
                        log_at('salaryjob email',SQLERRM, substr(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 1500));
                END;
                /* SEND EMAIL END */

                Log_At ('salaryjob',SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                dbms_output.put_line('ERROR occured during salary payment : ' || '(' || rw_payment.TX_NO || ') ' || SQLERRM || ', with stack trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        end;
    END LOOP;

    EXCEPTION
    WHEN OTHERS   THEN
         Log_At ('salaryjob',SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
------------------------------------------------------------------------------------------
FUNCTION SwiftBankInfo ( ps_bankcountry      IN VARCHAR2,
                             ps_bankcity          IN VARCHAR2,
                            ps_bankname          IN VARCHAR2,
                            ps_bankcode              IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS

        ls_sqlstr       VARCHAR2(2000);

        ls_returncode            VARCHAR2(3):='000';


    BEGIN

    ls_sqlstr:= 'SELECT * FROM CBS_BIC_KODLARI    WHERE ULKE_ADI LIKE ''%' || UPPER(ps_bankcountry) || '%'' AND SEHIR_ADI LIKE ''%' || UPPER(ps_bankcity) || '%'' AND BANKA_ADI LIKE ''%' || UPPER(ps_bankname) || '%''AND BIC_KODU LIKE ''%' || UPPER(ps_bankcode) || '%''';

    OPEN pc_ref   FOR ls_sqlstr;

    RETURN ls_returncode;

END;

/******************************************************************************
    Name: Create_Swift_Transaction
    Desc: Function to create swift transaction. It will be called from CIB, CBS (4005) and EOD
    Prepared By:Chyngyz Omurov cq509
    Modify Date: 06.04.2015
******************************************************************************/
FUNCTION Create_Swift_Transaction(pn_tx_no NUMBER, ps_product_class VARCHAR2, pn_amount NUMBER, ps_branch_no VARCHAR2, ps_currency VARCHAR2, pn_custno NUMBER, pn_accno NUMBER, ps_ben_name VARCHAR2) RETURN VARCHAR2
IS
    ln_tx_code NUMBER := 4003;
    ls_module_type VARCHAR2(10) := 'FCTRANSFER';
    ls_product_type VARCHAR2(10) := 'OUTGOING';
    ln_role_code NUMBER := 7777;

   ls_msg_return VARCHAR2(2000);
   ls_returncode VARCHAR2(3):='000';

   ln_swttrnpf_sasrn NUMBER;
BEGIN
      Pkg_Int_Api.create_transaction(pn_tx_no, ln_tx_code,
                                     ls_module_type, ls_product_type, ps_product_class,
                                     pn_amount, ps_branch_no, ps_branch_no, ln_role_code,
                                     ps_currency, pn_custno, pn_accno,
                                     NULL, NULL);
   -- COMMIT;



    Pkg_Swift.SP_MESAJ_SIL(pn_tx_no);

    Pkg_Swift.mesaj_olustur(4003,pn_tx_no,1,'103',NULL,NULL,NULL,NULL,ls_msg_return);



    IF (ls_msg_return = 'SKYACK' OR ls_msg_return LIKE '%SKYBLCK') THEN


        ls_returncode:='000';

          IF (pkg_black_list.checkcustomerinblacklist_str(pkg_report4.cyr2lat(ps_ben_name))  <> '0'
                 OR pkg_black_list.checkcustomerinblacklist_str(ps_ben_name)  <> '0') THEN

                --transaction should be verified and approved by Bank
                UPDATE CBS_ISLEM SET DOGRULANMALI_MI='E', ONAYLANMALI_MI='E'

                WHERE NUMARA = pn_tx_no;

                --send email notification to Compliance department
                pkg_black_list.black_list_report(null, 4003, null, null, pn_tx_no, 'SWIFT IB - Black list alert '||to_char(sysdate, 'dd/mm/yyyy'));
            ELSE
                --transaction should be only approved by Bank
                UPDATE CBS_ISLEM SET DOGRULANMALI_MI='H', ONAYLANMALI_MI='E'

                WHERE NUMARA = pn_tx_no;
            END IF;

    ELSE

        ls_returncode:='777';

        IF (ls_msg_return LIKE '%BICNACK%') THEN
            ls_returncode:='761';


        ELSIF (ls_msg_return LIKE '%SKYE01%' OR ls_msg_return LIKE '%SKYE02%' OR ls_msg_return LIKE '%SKYE03%') THEN
            ls_returncode:='763';
        ELSIF (ls_msg_return LIKE '%SKYE04%') THEN
            ls_returncode:='764';
        ELSIF (ls_msg_return LIKE '%SKYE05%') THEN
            ls_returncode:='765';
        ELSIF (ls_msg_return LIKE '%SKYE06%') THEN
            ls_returncode:='766';
        ELSIF (ls_msg_return LIKE '%SKYE07%') THEN
            ls_returncode:='767';
        ELSIF (ls_msg_return LIKE '%SKYE08%' OR ls_msg_return LIKE '%SKYE09%') THEN
            ls_returncode:='768';
        ELSIF (ls_msg_return LIKE '%SKYE10%') THEN
            ls_returncode:='769';
        ELSIF (ls_msg_return LIKE '%SKYE11%') THEN
            ls_returncode:='770';
        ELSIF (ls_msg_return LIKE '%SKYE12%') THEN
            ls_returncode:='771';
        ELSIF (ls_msg_return LIKE '%SKYE13%') THEN
            ls_returncode:='772';
        ELSIF (ls_msg_return LIKE '%SKYE14%' OR ls_msg_return LIKE '%SKYE15%') THEN
            ls_returncode:='773';
        ELSIF (ls_msg_return LIKE '%SKYE14 (57A)%') THEN
            ls_returncode:='774';
        ELSIF (ls_msg_return LIKE '%SKYNACK (59N)%') THEN
            ls_returncode:='775';
        END IF;

        SELECT SASRN INTO ln_swttrnpf_sasrn
        FROM swttrnpf
        WHERE TX_NO = pn_tx_no
        AND ROWNUM=1;

        FOR i IN (SELECT ARAERR FROM swtarapf_cbs
                        WHERE ARASRN = ln_swttrnpf_sasrn)
        LOOP
        IF i.ARAERR IS NOT NULL THEN
            log_at('swiftcib pkg_int_transfer.Create_Swift_Transaction SKY_ERROR', '1='||pn_custno||' 2=' || pn_accno ||' 3=' || pn_amount||' 4='||ls_msg_return, SUBSTR(i.ARAERR,1,2000));
        END IF;
        END LOOP;

    END IF;

    RETURN ls_returncode;

END;



/******************************************************************************
   NAME        : FUNCTION Make_Swift
   Prepared By : Chyngyz Omurov
   Date        :  02.03.2015, cq509
   Purpose     : Make SWIFT transaction in Corporate IB
   Note: called only from CIB, either after creation (if no approve needed) or after customer approval
******************************************************************************/
    FUNCTION Make_Swift(ps_sender_acc_no IN VARCHAR2,
                        ps_country_code IN VARCHAR2,
                        ps_currency IN VARCHAR2,
                        ps_amount IN VARCHAR2,
                        ps_value_date IN VARCHAR2,
                        ps_charge_party IN VARCHAR2, --who pays charge,  (BEN, OUR, GOUR)
                        ps_stat_code IN VARCHAR2,
                        ps_description IN VARCHAR2,
                        ps_comm_acc_no IN VARCHAR2,
                        ps_charge_amount IN VARCHAR2,
                        ps_ben_acc_no IN VARCHAR2,
                        ps_ben_name IN VARCHAR2,
                        ps_ben_address IN VARCHAR2,
                        ps_ben_swiftcode IN VARCHAR2, --bic code of beneficiary bank
                        ps_ii_bic IN VARCHAR2, --intermediary institution bic code
                        ps_todo_txno VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        ps_inn_kpp VARCHAR2 DEFAULT NULL --IBC-74 YadgarB
                        )
    RETURN VARCHAR2 IS PRAGMA AUTONOMOUS_TRANSACTION;
        ls_returncode VARCHAR2(3):='000';

        ln_tx_no NUMBER;
        ld_today DATE := Pkg_Muhasebe.Banka_Tarihi_Bul;
        ls_branch_no VARCHAR2(3); --:= '010';--Pkg_Hesap.HesapSubeAl(TO_NUMBER(ps_sender_acc_no));
        ln_sender_cust_no NUMBER;
        ls_referans VARCHAR2(16) ;--:= TO_CHAR(ld_today,'YY')||'.'||ls_branch_no||'.'||'OMT'||'.'|| LPAD(Pkg_Genel.GENEL_KOD_AL('YPHAVALE.GIDEN'||TO_CHAR(ld_today,'YY')||ls_branch_no),5,'0');

        ln_tx_code  NUMBER := 4003;
        ln_role_code NUMBER := 7777;
        ls_head_office VARCHAR2(3) := '001';
        ls_user_name VARCHAR2(20) := 'CINT_CALLER';

        ls_module_type VARCHAR2(10) := 'FCTRANSFER';
        ls_product_type VARCHAR2(10) := 'OUTGOING';
        ls_product_class CBS_YPHAVALE_GIDEN_ACILIS.URUN_SINIF_KOD%TYPE;

        ls_message_103 VARCHAR2(1):='E';
        ls_message_202 VARCHAR2(1):='H';

        ln_amount NUMBER;-- := TO_NUMBER(REPLACE(ps_amount,',',''),'99999999999.99');
        ld_value_date DATE; --:= TO_DATE(ps_value_date,'YYYYMMDD');

        ln_corr_cust_no NUMBER;
        ln_corr_acc_no NUMBER;
        ls_corr_bank_name VARCHAR2(100);
        ls_dummy VARCHAR2(50);

        lcref_bank_info CursorReferenceType;

        ls_tmp_returncode VARCHAR2(3) := '000';
        ls_commBank VARCHAR2(5);
        ln_charge_amount NUMBER := TO_NUMBER(ps_charge_amount);
        ln_spec_commission NUMBER := 0;

        ls_corr_bic VARCHAR2(11);

        pc_oc_isim_adres_1 VARCHAR2(35 CHAR);
        pc_oc_isim_adres_2 VARCHAR2(35 CHAR);
        pc_oc_isim_adres_3 VARCHAR2(35 CHAR);
        pc_oc_isim_adres_4 VARCHAR2(35 CHAR); --CBS-565 AntonPa 20.12.21
        pc_bc_isim_adres_1 VARCHAR2(35 CHAR);
        pc_bc_isim_adres_2 VARCHAR2(35 CHAR);
        pc_bc_isim_adres_3 VARCHAR2(35 CHAR);
        pc_bc_isim_adres_4 VARCHAR2(35 CHAR); --CBS-565 AntonPa 20.12.21
        pc_ri_1 VARCHAR2(35 CHAR);
        pc_ri_2 VARCHAR2(35 CHAR);
        pc_ri_3 VARCHAR2(35 CHAR);
        pc_ri_4 VARCHAR2(35 CHAR);
        pc_pre_stri_1 VARCHAR2(8 BYTE) := '';

        ps_UAE_stat_code VARCHAR2(50 BYTE); --Bakdoolot ibc-52 02.03.22

        ls_name_address VARCHAR2(2000 CHAR);

        ln_count NUMBER:=0;
        ls_awi_bic  VARCHAR2(15);
        ln_cdf_total_charge NUMBER := 0;
        ls_msg_return VARCHAR2(2000);
        ls_ii_bic  VARCHAR2(11):='';
        ln_swttrnpf_sasrn NUMBER;

        ls_senders_dvz   CBS_YPHAVALE_GIDEN_ACILIS.SENDERS_DVZ%TYPE;
        ls_senders_charges CBS_YPHAVALE_GIDEN_ACILIS.SENDERS_CHARGES%TYPE;

        ls_cia_doviz CBS_YPHAVALE_GIDEN_ACILIS.CIA_DOVIZ%TYPE;
        ln_cia_tutar CBS_YPHAVALE_GIDEN_ACILIS.CIA_TUTAR%TYPE;

        correspondentBankNotDefined EXCEPTION;
        notenoughbalance    EXCEPTION;
        notenoughbalanceCommission    EXCEPTION;
        ln_commAmount NUMBER := 0;

        ls_block_ref_amount   CBS_BLOKE.BLOKE_REFERANS%TYPE;
        ls_block_ref_comm CBS_BLOKE.BLOKE_REFERANS%TYPE;

        lc_dummy_ref  CursorReferenceType;

        --BOM IBC-74 YadgarB
        ls_sc                   CBS_YPHAVALE_GIDEN_ACILIS.SC%TYPE;
        ls_sc_party_identifier  CBS_YPHAVALE_GIDEN_ACILIS.SC_PARTY_IDENTIFIER%TYPE;
        ls_awi_party_identifier CBS_YPHAVALE_GIDEN_ACILIS.AWI_PARTY_IDENTIFIER_D%TYPE;
        ls_post_stri_1          CBS_YPHAVALE_GIDEN_ACILIS.POST_STRI_1%TYPE;
        ls_awi_address          VARCHAR2(2000 CHAR);
        ls_awi_isim_adres_1     CBS_YPHAVALE_GIDEN_ACILIS.AWI_ISIM_ADRES_1%TYPE;
        ls_awi_isim_adres_2     CBS_YPHAVALE_GIDEN_ACILIS.AWI_ISIM_ADRES_2%TYPE;
        ls_awi_isim_adres_3     CBS_YPHAVALE_GIDEN_ACILIS.AWI_ISIM_ADRES_3%TYPE;
        ls_awi_isim_adres_4     CBS_YPHAVALE_GIDEN_ACILIS.AWI_ISIM_ADRES_4%TYPE;
        --EOM IBC-74 YadgarB
        ln_tr_amount number := 0;--AndreiD CBS-868
        ln_eqv_amount number;--AndreiD CBS-868
    BEGIN

        --if this swift transaction was already inserted to CBS_YPHAVALE_GIDEN_ACILIS, then do not insert again
         ls_branch_no := Pkg_Hesap.HesapSubeAl(to_number(ps_sender_acc_no));

         ln_sender_cust_no :=Pkg_Hesap.HesaptanMusteriNoAl(to_number(ps_sender_acc_no));

         ls_referans := TO_CHAR(ld_today,'YY')||'.'||ls_branch_no||'.'||'OMT'||'.'|| LPAD(Pkg_Genel.GENEL_KOD_AL('YPHAVALE.GIDEN'||TO_CHAR(ld_today,'YY')||ls_branch_no),5,'0');

         ln_amount := TO_NUMBER(REPLACE(ps_amount,',',''),'99999999999.99');

         ld_value_date := TO_DATE(ps_value_date,'YYYYMMDD');

         ln_tx_no := Pkg_Tx.islem_no_al;

        SELECT DECODE(ps_charge_party, 'B', 'BEN', 'O', 'OUR', 'G', 'GOUR', 'X') INTO ls_commBank FROM DUAL;
        ls_product_class := 'CIB ' || ls_commBank || ' ' || ps_currency;

        log_at('MAKE_SWIFT', 'ps_charge_party', ps_charge_party);

        --BOM NurmilaZ IB-93 08092021
        IF TRIM(ps_charge_party) = 'G' THEN
            pc_pre_stri_1 := 'FND';
        END IF;
        --EOM NurmilaZ IB-93 08092021

        --Get correspondence bank customer no and account no---------------------------------------------------------
        ls_tmp_returncode := Pkg_Soa_Inquiry.GetCorrespondentBank(ln_sender_cust_no, ps_currency, ps_charge_party, lcref_bank_info);

        log_at('MAKE_SWIFT','get correspondent bank', ls_tmp_returncode);

        IF ls_tmp_returncode <> '000' THEN --correspondent bank is not defined
            RAISE correspondentBankNotDefined;
        END IF;

        FETCH lcref_bank_info INTO ln_corr_cust_no, ln_corr_acc_no, ls_corr_bank_name, ls_dummy, ls_sc_party_identifier; --IBC-74 YadgarB

        log_at('MAKE_SWIFT', 'ln_corr_cust_no', ln_corr_cust_no);

        ls_corr_bic := Pkg_Swift.GetMubabirBICCode(ln_corr_cust_no);

        --ordering customer name and address
        --BOM AzatDz 18092019
        IF ps_currency = 'USD' OR ps_currency = 'EUR' THEN
            ls_name_address := Pkg_Musteri.Sf_Musteri_Eng_Adi(TO_NUMBER(ln_sender_cust_no)) || ' ' || Pkg_Musteri.sf_adres_al(TO_NUMBER(ln_sender_cust_no));
        ELSE
--             ls_name_address := RPAD(Pkg_Musteri.Sf_Musteri_Adi(TO_NUMBER(ln_sender_cust_no)), 35, ' ') || RPAD(Pkg_Musteri.sf_adres_al(TO_NUMBER(ln_sender_cust_no)), 70, ' ') || RPAD('INN' || Pkg_Musteri.SF_VERGINO_AL(TO_NUMBER(ln_sender_cust_no)), 35, ' '); --IBC-74 YadgarB added INN field
            ls_name_address := Pkg_Musteri.Sf_Musteri_Adi(TO_NUMBER(ln_sender_cust_no)) || ' ' || Pkg_Musteri.sf_adres_al(TO_NUMBER(ln_sender_cust_no)) || ' ' || 'INN' || Pkg_Musteri.SF_VERGINO_AL(TO_NUMBER(ln_sender_cust_no)); --IBC-74 YadgarB added INN field
        END IF;
        --EOM AzatDz 18092019

        --BOM IBC-74 YadgarB
        IF ps_currency = 'RUB' THEN
            pc_oc_isim_adres_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,1,35))); --CBS-565 AntonPa 20.12.21  (1, 33)
            pc_oc_isim_adres_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,36,35))); --CBS-565 AntonPa 20.12.21 (34, 33)
            pc_oc_isim_adres_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,71,35))); --CBS-565 AntonPa 20.12.21 (67, 33)
            pc_oc_isim_adres_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,106,35))); --CBS-565 AntonPa 20.12.21 New
            --beneficiary customer name and address
            ls_name_address := ps_ben_name || ' ' || ps_ben_address;

            IF ps_inn_kpp IS NOT NULL THEN
--                 ls_name_address := RPAD(ps_inn_kpp, 35, ' ') || ls_name_address;
                ls_name_address := ps_inn_kpp || ' ' || ls_name_address;
            END IF;

            pc_bc_isim_adres_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,1,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,36,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,71,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(ls_name_address,106,35))); --CBS-565 AntonPa 20.12.21
            --remittance info
            pc_ri_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_description),1,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_description),36,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_description),71,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_description),106,35)); --CBS-565 AntonPa 20.12.21 (100, 33)
        ELSE
            pc_oc_isim_adres_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address ),1,35))); --CBS-565 AntonPa 20.12.21  (1, 33)
            pc_oc_isim_adres_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address ),36,35))); --CBS-565 AntonPa 20.12.21 (34, 33)
            pc_oc_isim_adres_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat( ls_name_address),71,35))); --CBS-565 AntonPa 20.12.21 (67, 33)
            pc_oc_isim_adres_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat( ls_name_address),106,35))); --CBS-565 AntonPa 20.12.21 New
            --beneficiary customer name and address
            ls_name_address := ps_ben_name || ' ' || ps_ben_address;

            IF ps_currency = 'KZT' AND ps_inn_kpp IS NOT NULL THEN
--                 ls_name_address := RPAD(ps_inn_kpp, 35, ' ') || ls_name_address;
                ls_name_address := ps_inn_kpp || ' ' || ls_name_address;
            END IF;

            pc_bc_isim_adres_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address),1,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address),36,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address),71,35))); --CBS-565 AntonPa 20.12.21
            pc_bc_isim_adres_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(UPPER(SUBSTR(pkg_report4.cyr2lat(ls_name_address),106,35))); --CBS-565 AntonPa 20.12.21
            --remittance info
            pc_ri_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_description)),1,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_description)),36,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_description)),71,35)); --CBS-565 AntonPa 20.12.21
            pc_ri_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_description)),106,35)); --CBS-565 AntonPa 20.12.21 (100, 33)
        END IF;
        --EOM IBC-74 YadgarB

        IF LENGTH(ps_ii_bic) = 8 THEN
            ls_ii_bic := ps_ii_bic || 'XXX';
        ELSE
            ls_ii_bic := ps_ii_bic;
        END IF;

        IF ps_todo_txno IS NOT NULL AND (ps_currency = 'USD' OR ps_currency = 'EUR') AND SUBSTR(ps_country_code, 1, 5) = 'AE' THEN
            SELECT ('/BENEFRES/' || SUBSTR(ps_country_code, 1, 5) || '//' || SUBSTR(uae.STAT_CODE, INSTR(uae.STAT_CODE, '#', 1) + 1, 3) || '/')
            INTO ps_UAE_stat_code
            FROM CORPINT.TBL_TXTODO_UAE_DETAILS uae
            WHERE uae.TX_NO = ps_todo_txno;
        END IF; --Bakdoolot ibc-52 02.03.22

        log_at('MAKE_SWIFT', 'ps_ben_swiftcode', ps_ben_swiftcode);

        SELECT COUNT(*)
        INTO ln_count --?? BANKS FOR WHICH SWIFT NOT SENT TO BRANCHES, BUT DIRECTLY TO HEAD OFFICE
        FROM CBS_BIC_KODLARI
        WHERE BIC_KODU = ps_ben_swiftcode
          AND SUBSTR(BIC_KODU, 1, 4) IN ( SELECT SUBSTR(SBKEKD, 1, 4) FROM SWTBKEPF );

        IF (ln_count > 0) THEN
            ls_awi_bic := ps_ben_swiftcode;
        ELSE
            IF LENGTH(ps_ben_swiftcode) = 11 THEN
                ls_awi_bic := SUBSTR(ps_ben_swiftcode, 1, LENGTH(ps_ben_swiftcode) - 3) || 'XXX';
            ELSE
                ls_awi_bic := ps_ben_swiftcode || 'XXX';
            END IF;
        END IF;



  /*BOM  CBS-868 AndreiD*/
        
        pkg_parametre.deger('COMM_TR', ln_tr_amount);
        
        log_at('tr_help1',1,ln_tr_amount );
        
 
       
           ln_eqv_amount := Pkg_Kur.doviz_doviz_karsilik(ps_currency,'USD', NULL,ln_amount,1,NULL,NULL,'O','A');
                                
        IF ps_country_code = 'TR' AND  ln_eqv_amount<= ln_tr_amount  AND ln_tr_amount <> 0 THEN
           ln_charge_amount:=0;
           ln_spec_commission := 0;
           ln_cdf_total_charge:= 0;
           
        log_at('tr_help1',2,ln_tr_amount||'    '|| ln_amount);    
        
        
        ELSE
         --calculate standard commissions (BEN, OUR, GOUR)
        ln_charge_amount  := Pkg_Aps.ChargeAutoCalculate(ln_tx_no, ln_tx_code, ls_module_type, ls_product_type, ls_product_class, ln_amount, ls_head_office, ps_currency, ln_sender_cust_no, ps_sender_acc_no, null);
        log_at('tr_help1',3,ln_charge_amount);                              

        --calculate special commissions (BEN, OUR, GOUR) *updates cbs_masraf
        ln_spec_commission := PKG_MASRAF.CALCULATE_COMMISSIONS_FOR_CIB(ln_tx_no, ls_product_class, ln_amount, ps_currency, ln_sender_cust_no, ps_sender_acc_no);    
       log_at('tr_help1',3.1,ln_spec_commission);             
        
        --add cash deposit fee to the commssion *updates cbs_masraf
        ln_cdf_total_charge := PKG_MASRAF.CALCULATE_CDF_FOR_CIB(ln_tx_no, ln_tx_code, ls_module_type, ls_product_type, ls_product_class,  ln_amount, ps_currency, ln_sender_cust_no, ps_sender_acc_no ); 
       log_at('tr_help1',3.2,ln_cdf_total_charge);  
 
        --recalculate commissions
        ln_charge_amount  := Pkg_Aps.ChargeAutoCalculate(ln_tx_no, ln_tx_code, ls_module_type, ls_product_type, ls_product_class, ln_amount, ls_head_office, ps_currency, ln_sender_cust_no, ps_sender_acc_no, null);
        log_at('tr_help1',3.3,ln_charge_amount);                              


       END IF;
    /*EOM  CBS-868 AndreiD*/   




        IF Pkg_Hesap.Kullanilabilir_Bakiye_Al(ps_sender_acc_no) < (ln_amount) THEN
            RAISE notenoughbalance;
        END IF;

        IF ps_sender_acc_no = ps_comm_acc_no THEN
            ln_commAmount := ln_amount + ln_charge_amount;
        ELSE
            ln_commAmount := ln_charge_amount;
        END IF;


        IF PKG_SOA_INQUIRY.CHECKBALANCE(ps_comm_acc_no, ln_commAmount, ps_currency, lc_dummy_ref) != '000' THEN
            RAISE notenoughbalanceCommission;
        END IF;

        IF TRIM(ps_charge_party) = 'B' THEN
            ls_senders_charges := 0;
            ls_senders_dvz := ps_currency;

            ls_cia_doviz := ps_currency;
            ln_cia_tutar := ps_amount;
        END IF;

        --BOM IBC-74 YadgarB
        IF ps_currency = 'RUB' THEN

            BEGIN
                SELECT '//' || DESCRIPTION || '.' || CORRESPONDENT_ACCOUNT,
                       BANK_NAME || ' ' || CITY || ' ' || ADDRESS_1
                INTO ls_awi_party_identifier, ls_awi_address
                FROM CBS.CBS_BIC_CODES_RU
                WHERe BIC_CODE = ps_ben_swiftcode;
            EXCEPTION
                WHEN OTHERS THEN
                    NULL;
            END;

            ls_awi_isim_adres_1 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ls_awi_address),1,35));
            ls_awi_isim_adres_2 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ls_awi_address),36,35));
            ls_awi_isim_adres_3 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ls_awi_address),71,35));
            ls_awi_isim_adres_4 := PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ls_awi_address),106,35));

            pc_pre_stri_1 := 'RPP';
            ls_post_stri_1 := SUBSTR(ls_referans, -3) || '.' || TO_CHAR(ld_value_date, 'YYMMDD') || '.5.ELEK.01';
        END IF;

        IF ps_currency in ('RUB', 'KZT') THEN
            ls_sc := 'B';
        END IF;
        --EOM IBC-74 YadgarB

        SELECT COUNT(*)
        INTO LN_COUNT
        FROM CBS_YPHAVALE_GIDEN_ACILIS
        WHERE TODO_TXNO = PS_TODO_TXNO;

        IF NVL(LN_COUNT, 0) > 0 THEN
            DELETE FROM CBS_YPHAVALE_GIDEN_ACILIS
            WHERE TODO_TXNO = PS_TODO_TXNO;
        END IF;

        pc_oc_isim_adres_1 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_1, '-');
        pc_oc_isim_adres_2 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_2, '-');
        pc_oc_isim_adres_3 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_3, '-');
        pc_oc_isim_adres_4 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_oc_isim_adres_4, '-');
        
        pc_ri_1 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_1, '-');
        pc_ri_2 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_2, '-');
        pc_ri_3 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_3, '-');
        pc_ri_4 := CBS.pkg_data_inquiry.Swift_Character_Cannotstart(pc_ri_4, '-'); --Bakdoolot IBC-110 27.06.2022
        
        INSERT INTO CBS_YPHAVALE_GIDEN_ACILIS (TX_NO, REFERANS, GONDEREN_SUBE, MUSTERI_NO, MODUL_TUR_KOD,
                                               URUN_TUR_KOD, URUN_SINIF_KOD, ULKE_KODU, CEK_ILE_F, CEK_NO,
                                               TRANSFER_DOVIZ_KODU, TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU, KUR,
                                               PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, VALOR_TARIHI,
                                               TRANSFER_SEKLI, BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO,
                                               MUH_BANK_HESAP_NO, ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO,
                                               BOC, OC, BC, DOC, AWI, OC_HESAP_NO_K, DURUM_KODU, ACILIS_TARIHI,
                                               MASRAF_TOPLAMI, RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD, SWIFT_TUTARI,
                                               RG_MESAJ_OLUSTUR, ALICI_BIC, MUHABIR_BIC, MESAJ_103, MESAJ_202,
                                               OC_ISIM_ADRES_1, OC_ISIM_ADRES_2, OC_ISIM_ADRES_3, OC_ISIM_ADRES_4, --CBS-565 AntonPa 20.12.21
                                               BC_HESAP_NO_N, BC_ISIM_ADRES_1, BC_ISIM_ADRES_2, BC_ISIM_ADRES_3, BC_ISIM_ADRES_4, --CBS-565 AntonPa 20.12.21
                                               VALOR_TARIHI_CH, TUTAR_CH, BC_HESAP_NO_CH, BI, II_BIC, AWI_BIC,
                                               SC, SC_BIC, AWI_LOCATION, RI_1, RI_2, RI_3, RI_4, II,
                                               AML_TO_NAME, AML_TO_ORG_NAME, AML_ACCOUNT_NO, AML_FROM_CUST_TYPE,
                                               AML_BANK_BIC, AML_TO_BANK_NAME, AML_BANK_COUNTRY_CODE, AML_COUNTRY_CODE,
                                               AML_BANK_CORR_ADR,
                                               SENDERS_CHARGES, SENDERS_DVZ, CIA_DOVIZ, CIA_TUTAR, TODO_TXNO, PRE_STRI_1,
                                               RR_1, --Bakdoolot ibc-52 added RR_1 02.03.22
                                               SC_PARTY_IDENTIFIER_B, AWI_PARTY_IDENTIFIER_D, POST_STRI_1,
                                               AWI_ISIM_ADRES_1, AWI_ISIM_ADRES_2, AWI_ISIM_ADRES_3, AWI_ISIM_ADRES_4 --IBC-74 YadgarB
                                               )
        VALUES (ln_tx_no, ls_referans, ls_branch_no, ln_sender_cust_no, ls_module_type,
                ls_product_type, ls_product_class, SUBSTR(ps_country_code, 1, 5), 'H', NULL,
                ps_currency, ln_amount, 'N', ps_currency, NULL,
                NULL, NULL, NULL, ln_amount, ld_value_date,
                'M', ps_sender_acc_no, NULL, ln_corr_cust_no, ln_corr_acc_no,
                pkg_message.SPLIT(ps_stat_code, '#', 1), SUBSTR(pkg_message.SPLIT(ps_stat_code, '#', 2), 1, 80),
                ps_comm_acc_no, 'CRED', 'K', --cq5548 ChyngyzO 14.09.2016
                'N', DECODE(ps_charge_party, 'B', 'BEN', 'O', 'OUR', 'G', 'OUR', 'OUR'), DECODE(ps_currency, 'RUB', 'D', 'A'), --IBC-74 YadgarB
                PKG_HESAP.EXTERNAL_HESAPNO_AL(ps_sender_acc_no), NULL,
                ld_today, ln_charge_amount, NULL, NULL, ln_amount,
                'E', ls_corr_bic, ls_corr_bic, ls_message_103, ls_message_202,
                pc_oc_isim_adres_1, pc_oc_isim_adres_2, pc_oc_isim_adres_3, pc_oc_isim_adres_4, --CBS-565 AntonPa 20.12.21
                DECODE(ps_currency, 'RUB', PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_ben_acc_no), 1, 34)), PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_ben_acc_no)), 1, 34))), --IBC-74 YadgarB
                pc_bc_isim_adres_1, pc_bc_isim_adres_2, pc_bc_isim_adres_3, pc_bc_isim_adres_4, --CBS-565 AntonPa 20.12.21
                ld_value_date, ln_amount, NULL,
                NULL, ps_ii_bic, DECODE(ps_currency, 'RUB', NULL, ls_awi_bic), --IBC-74 YadgarB SKYE12(57D)
                ls_sc, NULL, NULL, pc_ri_1, pc_ri_2, pc_ri_3, pc_ri_4, 'A',
                DECODE(ps_currency, 'RUB', PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_ben_name), 1, 33)), PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_ben_name)), 1, 33))),  --IBC-74 YadgarB
                DECODE(ps_currency, 'RUB', PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_ben_address), 1, 100)), PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_ben_address)), 1, 100))),  --IBC-74 YadgarB
                DECODE(ps_currency, 'RUB', PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(ps_ben_acc_no), 1, 34)), PKG_GENEL.SWIFT_CHARACTER_CONTROL(SUBSTR(UPPER(pkg_report4.cyr2lat(ps_ben_acc_no)), 1, 34))),  --IBC-74 YadgarB
                'C', ls_awi_bic, SUBSTR(pkg_swift.bic_adi(ls_awi_bic), 1, 35), SUBSTR(ps_country_code, 1, 5),
                SUBSTR(ps_country_code, 1, 5), pkg_tx4003.Bic_Ulkesi(ls_awi_bic),
                ls_senders_charges, ls_senders_dvz, ls_cia_doviz, ln_cia_tutar, ps_todo_txno, pc_pre_stri_1,
                ps_UAE_stat_code, --Bakdoolot ibc-52 added ps_UAE_stat_code 02.03.22
                ls_sc_party_identifier, ls_awi_party_identifier, ls_post_stri_1,
                ls_awi_isim_adres_1, ls_awi_isim_adres_2, ls_awi_isim_adres_3, ls_awi_isim_adres_4 --IBC-74 YadgarB
                );
        --block main amount
        CBS.PKG_TX4003.CREATE_BLOCK(ps_sender_acc_no, ln_amount, ps_currency, ls_block_ref_amount);

        --block commission (if commission amount is bigger than zero)
        IF ln_charge_amount > 0 THEN
            CBS.PKG_TX4003.CREATE_BLOCK(ps_comm_acc_no, ln_charge_amount, ps_currency, ls_block_ref_comm);
        END IF;

        UPDATE CBS_YPHAVALE_GIDEN_ACILIS
        SET BLOCK_REF_AMOUNT = ls_block_ref_amount,
            BLOCK_REF_COMM   = ls_block_ref_comm
        WHERE TX_NO = ln_tx_no;

        COMMIT; --cq5548 ChyngyzO 14.09.2016

        OPEN pc_ref FOR

       SELECT TO_CHAR(ln_tx_no) ISLEM_NO FROM dual;


        IF TRUNC(ld_value_date) <> TRUNC(ld_today) THEN
            --value date is NOT today, so just save information and return
            RETURN ls_returncode;
        END IF;

        ls_returncode := Pkg_Int_Transfer.Create_Swift_Transaction(ln_tx_no,
                                                                    ls_product_class,
                                                                    ln_amount,
                                                                    ls_head_office, --ls_branch_no
                                                                    ps_currency,
                                                                    ln_sender_cust_no,
                                                                    ps_sender_acc_no,
                                                                    ps_ben_name);
        ---BOM cq5548 ChyngyzO 14.09.2016
        if ls_returncode <> '000' then
            ROLLBACK;

            --ublock main amount
            PKG_TX4003.REMOVE_BLOCK(ls_block_ref_amount ); --used also for cq4849
            --ublock comm amount
            PKG_TX4003.REMOVE_BLOCK(ls_block_ref_comm );
        end if;
         ---EOM cq5548 ChyngyzO 14.09.2016
         COMMIT;

         RETURN ls_returncode;
    EXCEPTION
        WHEN notenoughbalance THEN
            ROLLBACK;
            ls_returncode := '502';
            log_at('swiftcib pkg_int_transfer.Make_Swift notenoughbalance', '1='||ln_sender_cust_no||' 2=' || ps_sender_acc_no ||' 3=' || ps_amount||' 4='||Pkg_Hesap.Kullanilabilir_Bakiye_Al(ps_sender_acc_no)||' 5='||(ln_amount + ln_charge_amount));
            OPEN pc_ref FOR SELECT TO_CHAR(ln_tx_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;

        WHEN notenoughbalanceCommission THEN
             ROLLBACK;
            ls_returncode := '501';
            log_at('swiftcib pkg_int_transfer.Make_Swift notenoughbalanceCommission',  '1='||ln_sender_cust_no||' 2=' || ps_sender_acc_no ||' 3=' || ps_amount||' 4='||Pkg_Hesap.Kullanilabilir_Bakiye_Al(ps_sender_acc_no)||' 5='||(ln_amount + ln_charge_amount));
            OPEN pc_ref FOR SELECT TO_CHAR(ln_tx_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;

        WHEN correspondentBankNotDefined THEN
            ROLLBACK;
            ls_returncode := '779';
            log_at('swiftcib pkg_int_transfer.Make_Swift correspondentBankNotDefined', '1='||ln_sender_cust_no||' 2=' || ps_currency ||' 3=' || ps_charge_party);
            OPEN pc_ref FOR SELECT TO_CHAR(ln_tx_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;

        WHEN OTHERS THEN
            ROLLBACK;
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            log_at('swiftcib pkg_int_transfer.Make_Swift others',SQLCODE||':'||SQLERRM,ls_returncode||'-'||ln_tx_no, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

            /*SELECT COUNT(*)
            INTO ln_count
            FROM CBS_YPHAVALE_GIDEN_ACILIS T
            WHERE T.TX_NO = ln_tx_no;

            IF (ln_count > 0) THEN
                  DELETE FROM CBS_YPHAVALE_GIDEN_ACILIS T
                  WHERE T.TX_NO = ln_tx_no;
            END IF;

            SELECT COUNT(*)
            INTO ln_count
            FROM CBS_ISLEM T
            WHERE T.NUMARA = ln_tx_no;

            IF (ln_count > 0) THEN
                  DELETE FROM CBS_ISLEM T
                  WHERE T.NUMARA = ln_tx_no;
            END IF;

            COMMIT;*/

            OPEN pc_ref FOR SELECT TO_CHAR(ln_tx_no) ISLEM_NO FROM dual;
            RAISE_APPLICATION_ERROR(-20100,SQLERRM);
            RETURN ls_returncode;
    END;

-----------------------------------------------------------------------------------------
FUNCTION MAKESwift_old(pd_amount IN VARCHAR2,
                   pd_currency IN VARCHAR2,
                   pd_accountid IN VARCHAR2,
                   ps_ulkekodu IN VARCHAR2,
                   ps_valor_tarihi IN VARCHAR2,
                   ps_aciklama IN VARCHAR2,
                     ps_acilistarihi IN VARCHAR2,
                      ps_swiftbickodu IN VARCHAR2,
                   p_PayeeName IN VARCHAR2,
                   p_PayeeAddress IN VARCHAR2,
                     ps_toAccountNo IN VARCHAR2,
                   ps_muhabirmasraf IN VARCHAR2,
                      ps_bildirimtelno IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode VARCHAR2(3):='000';
        ld_date DATE;

        pn_islem_no NUMBER;
        pn_islem_kod NUMBER;
        pc_modul_tur_kod VARCHAR2(10);
        pc_urun_tur_kod VARCHAR2(10);
        pc_urun_sinif_kod VARCHAR2(10);
        pc_rol NUMBER:=5000;
        pc_kasa_kod NUMBER;
        pc_doviz_kod VARCHAR(3):=pd_currency;
        pc_hesap_numara NUMBER:=TO_NUMBER(pd_accountid);
        pn_musteri_numara NUMBER:=Pkg_Hesap.HesaptanMusteriNoAl(TO_NUMBER(pd_accountid));
        ps_BOLUM_KODU VARCHAR2(3):=Pkg_Hesap.HesapSubeAl(pd_accountid);

        pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
        pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
        pc_cek  VARCHAR2(1):='H';
        ps_transfer_doviz VARCHAR2(20):=pd_currency;
        ln_tutar NUMBER;
        ps_net_brut VARCHAR2(1):='N';
        pc_tahsil_doviz VARCHAR2(3):=Pkg_Hesap.HesaptanDovizKoduAl(pd_accountid);
        pd_valor_tarihi DATE := TO_DATE(ps_valor_tarihi,'YYYYMMDD');
        pc_transfer_sekli VARCHAR2(1):='M';
        pn_muhabir_hesap_no NUMBER;-- := PKG_DUZENLI_ODEME.Muhabir_Hesap_No(pc_doviz_kod);
        pn_muhabir_musteri_no NUMBER;
        pn_muhabir_masraf NUMBER := 0; -- muabir masraf al?nmayacak
        ps_muhabir_bic VARCHAR2(11);

        ps_ist_kod VARCHAR2(10); --Kemal bey verecek

        pc_aciklama VARCHAR2(200) := ps_aciklama;
        pd_acilis_tarih DATE := TO_DATE(ps_acilistarihi,'YYYYMMDD');
        ps_bank_opr_code VARCHAR2(4):='CRED';
        ps_ordering_customer VARCHAR2(1):='K';
        ps_ben_customer VARCHAR2(1):='N';
        ps_detail_charges VARCHAR2(3);
        ps_acc_ins VARCHAR2(1):='A';
        ls_referans VARCHAR2(16);
        pd_bugun DATE := Pkg_Muhasebe.Banka_Tarihi_Bul;

        pc_oc_isim_adres_1 VARCHAR2(35);
        pc_oc_isim_adres_2 VARCHAR2(35);
        pc_oc_isim_adres_3 VARCHAR2(35);
        ln_tahsil_tutari NUMBER;
        ln_bdsk          NUMBER;
        ln_net_transfer_tutar  NUMBER:=0;

        ps_mesaj_kodu     VARCHAR2(5):='103';
        ls_sonuc VARCHAR2(2000);
        ln_kur NUMBER;
        ln_bloke_tutar NUMBER;
        ln_count NUMBER;
        ln_CHARGE_AMOUNT NUMBER;
        ps_paymentcode     VARCHAR2(3);

 BEGIN

        pn_islem_no:=Pkg_Tx.islem_no_al;
        pn_islem_kod := '4003';
        pc_modul_tur_kod:='YPHAVALE';
        pc_urun_tur_kod:='OUTGOING';
        pc_urun_sinif_kod:='SAME DAY_1';
        ls_referans:=TO_CHAR(pd_bugun,'YY')||'.'||ps_bolum_kodu||'.OMT.'|| LPAD(Pkg_Genel.GENEL_KOD_AL('YPHAVALE.GIDEN'||TO_CHAR(pd_bugun,'YY')||ps_bolum_kodu),5,'0');
        ps_net_brut := ps_muhabirmasraf;
        pc_oc_isim_adres_1 := SUBSTR(Pkg_Musteri.Sf_Musteri_Adi(TO_NUMBER(pn_musteri_numara)),0,34);
        pc_oc_isim_adres_2 := SUBSTR(Pkg_Musteri.sf_adres_al(TO_NUMBER(pn_musteri_numara)),0,34);
        pc_oc_isim_adres_3 := SUBSTR(Pkg_Musteri.sf_adres_al(TO_NUMBER(pn_musteri_numara)),34,34);
        ln_TUTAR:=TO_NUMBER(REPLACE(pd_amount,',',''));
        ln_tahsil_tutari := Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,pc_tahsil_doviz,NULL,ln_tutar,1,NULL, NULL,'O', 'S');
        ln_bdsk:=Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,Pkg_Genel.lc_al,NULL,1,1,NULL, NULL,'O', 'S');
        --pn_muhabir_hesap_no:=pkg_swift.GetMubabirAccountNo(pd_currency);
        pn_muhabir_musteri_no:=Pkg_Hesap.HesaptanMusteriNoAl(pn_muhabir_hesap_no);
        --ps_muhabir_bic:=pkg_swift.GetMubabirBICCode(pn_muhabir_musteri_no);

        ln_CHARGE_AMOUNT:=Pkg_Aps.ChargeAutoCalculate(pn_islem_no, pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                           ln_tutar,  pc_bolum_kodu, pc_doviz_kod, pn_musteri_numara, pc_hesap_numara, pc_kasa_kod);

        IF (UPPER(ps_ulkekodu) = 'KG' ) THEN
            ps_ist_kod := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||
                             Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||'19';
        ELSE
            ps_ist_kod := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||
                             Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(pn_musteri_numara)) ||'29';
        END IF;

        IF     ps_net_brut = 'N' THEN
            ps_detail_charges := 'OUR';
        ELSE
            ps_detail_charges := 'SHA';
        END IF;

        IF ps_net_brut = 'B' THEN
           ln_net_transfer_tutar := ln_tutar-ln_CHARGE_AMOUNT; --- pn_muhabir_masraf;
           pn_muhabir_masraf := 0;
        ELSE
           ln_net_transfer_tutar := ln_tutar;--+ pn_muhabir_masraf;
              pn_muhabir_masraf := 0;--pkg_duzenli_odeme.Muhabir_Tutar_Al(pc_doviz_kod,ln_tutar);
        END IF;
/*
        TX_NO, REFERANS, GONDEREN_SUBE, MUSTERI_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD,
        ULKE_KODU, CEK_ILE_F, CEK_NO, TRANSFER_DOVIZ_KODU, TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU,
        KUR, PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, VALOR_TARIHI,
        TRANSFER_SEKLI, BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO, MUH_BANK_HESAP_NO,
        ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO, HAVALE_KOMISYONU, DOVIZ_AL_SAT_KOMISYONU, HABERLESME_MASRAFI,
        BOC, IC, IC_ACIKLAMA, TTC, VCA, CIA_DOVIZ, ER, OC, OC_BEI, OC_HESAP_NO, OC_ISIM_ADRES, OI, OI_PARTY_IDENTIFIER, OI_BIC, OI_ISIM, OI_ISIM_ADRES, SC, SC_PARTY_IDENTIFIER, SC_BIC, SC_LOCATION, SC_ISIM_ADRES, RC, RC_PARTY_IDENTIFIER, RC_BIC, RC_LOCATION, RC_ISIM_ADRES, TRI, TRI_PARTY_IDENTIFIER, TRI_BIC, TRI_LOCATION, TRI_ISIM_ADRES, II, II_PARTY_IDENTIFIER, II_BIC, II_LOCATION, II_ISIM_ADRES, AWI, AWI_PARTY_IDENTIFIER, AWI_BIC, AWI_LOCATION, AWI_ISIM_ADRES, BC, BC_BEI, BC_HESAP_NO, BC_ISIM_ADRES, RI, DOC, SENDERS_CHARGES, SENDERS_DVZ, RECEIVERS_CHARGES, RECEIVERS_DVZ, STRI, RR, DURUM_KODU, ACILIS_TARIHI, SENDER_BIC, RECEIVER_BIC, MASRAF_TOPLAMI, CIA_TUTAR, REZERVASYON_NO, SI_PARTY_IDENTIFIER, SI_BIC, SI, BI, BI_PARTY_IDENTIFIER, BI_BIC, BI_ISIM_ADRES, RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD, CHARGE_AMOUNT
        */
        INSERT INTO CBS_YPHAVALE_GIDEN_ACILIS
        (TX_NO, REFERANS, GONDEREN_SUBE, MUSTERI_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD,
        ULKE_KODU, CEK_ILE_F, CEK_NO, TRANSFER_DOVIZ_KODU, TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU,
        KUR, PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, VALOR_TARIHI,
        TRANSFER_SEKLI, BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO, MUH_BANK_HESAP_NO,
        ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO,
        BOC,OC,BC,DOC,AWI,
        OC_HESAP_NO, OC_ISIM_ADRES,BC_ISIM_ADRES,
        DURUM_KODU, ACILIS_TARIHI, MASRAF_TOPLAMI,RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD)
        VALUES
        (pn_islem_no,ls_referans,ps_BOLUM_KODU,pn_musteri_numara,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
        ps_ulkekodu,'H',NULL,ps_transfer_doviz,ln_tutar,ps_net_brut,pc_tahsil_doviz,
        ln_bdsk,NULL,NULL,NULL,ln_net_transfer_tutar,pd_valor_tarihi,
        'M', pc_hesap_numara, NULL, pn_muhabir_musteri_no, pn_muhabir_hesap_no,
        ps_paymentcode, SUBSTR(ps_aciklama,1,80),pc_hesap_numara,
        ps_bank_opr_code,ps_ordering_customer,ps_ben_customer, ps_detail_charges,ps_acc_ins,
        pc_hesap_numara, pc_oc_isim_adres_1 || pc_oc_isim_adres_2 || pc_oc_isim_adres_3, p_PayeeName || p_PayeeAddress,
        NULL, pd_acilis_tarih,ln_CHARGE_AMOUNT,'NONREF',ps_ist_kod);

        /*INSERT INTO CBS_YPHAVALE_GIDEN_ACILIS
              (tx_no, gonderen_sube, musteri_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
               ulke_kodu, cek_ile_f, transfer_doviz_kodu, tutar, net_brut, tahsil_doviz_kodu,
               valor_tarihi, transfer_sekli, borclu_hesap_no, muh_bank_hesap_no,
               istatistik_kodu, aciklama, acilis_tarihi, alici_bic,bc_hesap_no_n,
               bc_isim_adres_1, bc_isim_adres_2, bc_isim_adres_3,ri_1, ri_2, ri_3, ri_4,
               boc,oc,bc,doc,awi,awi_bic,referans,muh_bank_musteri_no, net_transfer_tutari,
               related_reference,masraf_toplami,muhabir_bic,
               mesaj_olustur, mesaj_103, mesaj_202,oc_isim_adres_1,oc_isim_adres_2,oc_isim_adres_3,muhabir_masraf_tutar,
               tahsil_tutari,kur,MUH_MASRAF_HESAP_NO,MUSTERI_TEL_NO,SWIFT_TUTARI,
               ACILIS_TRANSFER_ALIS_KURU,
               ACILIS_TRANSFER_SATIS_KURU,
               ACILIS_TAHSIL_ALIS_KURU,
               ACILIS_TAHSIL_SATIS_KURU,
               ACILIS_TRANSFER_MAL_ALIS_KURU,
               ACILIS_TRANSFER_MAL_SATIS_KURU,
               ACILIS_TAHSIL_MAL_ALIS_KURU,
               ACILIS_TAHSIL_MAL_SATIS_KURU,
               ACILIS_MUHABIR_HES_DVZ_KURU)

        VALUES(pn_islem_no,ps_BOLUM_KODU,pn_musteri_numara,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod,
               ps_ulkekodu,pc_cek,ps_transfer_doviz,ln_tutar,ps_net_brut,pc_tahsil_doviz,
               pd_valor_tarihi,pc_transfer_sekli,pc_hesap_numara, pn_muhabir_hesap_no,
               ps_ist_kod,decode(pc_aciklama,'','.', substr(pc_aciklama,0,80)),pd_acilis_tarih,ps_muhabir_bic,ps_toAccountNo,
               substr(p_PayeeName,0,34),
               substr(p_PayeeAddress,0,34),
               substr(p_PayeeAddress,34,34),
               substr(pc_aciklama,0,34),
               substr(pc_aciklama,34,34),
               substr(pc_aciklama,68,34),
               substr(pc_aciklama,102,34),
               ps_bank_opr_code ,ps_ordering_customer, ps_ben_customer, ps_detail_charges,
               ps_acc_ins,ps_swiftbickodu,ls_referans,pkg_hesap.HesaptanMusteriNoAl(pn_muhabir_hesap_no),ln_net_transfer_tutar,
               'NONREF',0,ps_muhabir_bic,
               'E','E','H' ,
               pc_oc_isim_adres_1,
               pc_oc_isim_adres_2,
               pc_oc_isim_adres_3,
               pn_muhabir_masraf,ln_tahsil_tutari,ln_bdsk,
               --ps_muhabirID
               pn_muhabir_hesap_no,ps_bildirimtelno,ln_TUTAR,
               Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'A'),
               Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'S'),
               Pkg_Kur.doviz_doviz_karsilik (pc_tahsil_doviz,Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'A'),
               Pkg_Kur.doviz_doviz_karsilik (pc_tahsil_doviz,Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'S'),
               Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,Pkg_Genel.lc_al,null,1,3,NULL, NULL,'O', 'A'),
               Pkg_Kur.doviz_doviz_karsilik (ps_transfer_doviz,Pkg_Genel.lc_al,null,1,3,NULL, NULL,'O', 'S'),
               Pkg_Kur.doviz_doviz_karsilik (pc_tahsil_doviz,Pkg_Genel.lc_al,null,1,3,NULL, NULL,'O', 'A'),
               Pkg_Kur.doviz_doviz_karsilik (pc_tahsil_doviz,Pkg_Genel.lc_al,null,1,3,NULL, NULL,'O', 'S'),
               Pkg_Kur.doviz_doviz_karsilik (Pkg_Hesap.HesaptanDovizKoduAl(pn_muhabir_hesap_no),Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'A')
               );

               if pc_hesap_numara is not null then
                    update CBS_YPHAVALE_GIDEN_ACILIS
                    set ACILIS_BORCLU_HES_DVZ_KURU=Pkg_Kur.doviz_doviz_karsilik (Pkg_Hesap.HesaptanDovizKoduAl(pc_hesap_numara),Pkg_Genel.lc_al,null,1,1,NULL, NULL,'O', 'A')
                     where tx_no=pn_islem_no;
               end if;*/

        --commit;
        -- bu commiti ?zellikle kald?rd?m mutlu ve bilal?n tavsiyesi ?zerine


        OPEN pc_ref FOR
             SELECT TO_CHAR(pn_islem_no),ls_referans ISLEM_NO FROM dual;

        /*Pkg_Hesap.Islem_Bloke_Artirim(pc_hesap_numara,ln_tahsil_tutari,pn_islem_no );*/

        Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                   ln_TUTAR, pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                   pc_doviz_kod, pn_musteri_numara,pc_hesap_numara, pc_kasa_kod,1);

        --Approve will be done by Staff
        --Pkg_Int_Api.process_transaction (pn_islem_no);

        /*commit;
        pkg_swift.mesaj_olustur(pn_islem_kod,pn_islem_no,0,ps_mesaj_kodu,null,null,null,null,ls_sonuc);
        log_at(ls_sonuc);
        log_at('swift islem numaras?',pn_islem_no);

        if ((ls_sonuc = 'SKYACK') OR (ls_sonuc = 'SKYBLCK'))then
            ls_returncode:='000';
            pkg_int_api.process_transaction (pn_islem_no);
        else
            pkg_duzenli_odeme.swift_islem_sil(pn_islem_no);
            ls_returncode:='777';
        end if;*/

        RETURN ls_returncode;

 EXCEPTION
     WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At(SQLERRM,ls_returncode);
        ROLLBACK;

        -- e?er burda bir hata olu?mu? ise commitden ?nceki de?erleri geri yerine getiriyorum
        /*SELECT COUNT(*)
        INTO ln_count
        FROM CBS_YPHAVALE_GIDEN_ACILIS T
        WHERE T.TX_NO = pn_islem_no;

        IF (ln_count > 0) THEN
            DELETE FROM CBS_YPHAVALE_GIDEN_ACILIS T
            WHERE T.TX_NO = pn_islem_no;
        END IF;

        Pkg_Hesap.Islem_Bloke_Azaltim(pc_hesap_numara,ln_tahsil_tutari,pn_islem_no );

        SELECT COUNT(*)
        INTO ln_count
        FROM CBS_ISLEM T
        WHERE T.NUMARA = pn_islem_no;

        IF (ln_count > 0) THEN
            DELETE FROM CBS_ISLEM T
            WHERE T.NUMARA = pn_islem_no;
        END IF;*/

        OPEN pc_ref FOR
             SELECT TO_CHAR(pn_islem_no) ISLEM_NO FROM dual;
        RETURN ls_returncode;
 END;
----------------------------------------------------------------------------------------------
FUNCTION GetSwiftDate (pd_startdate VARCHAR2,
                                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode VARCHAR2(3):='000';

    BEGIN
         RETURN ( TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD'));
    /*OPEN pc_ref   FOR ld_date;
        return ls_returncode;*/
 END;
----------------------------------------------------------------------------------------------
FUNCTION GetSWIFTInquiry(ps_customerid IN VARCHAR2,
                              pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ld_startdate  DATE;
    ld_enddate      DATE;
BEGIN

      IF pd_startdate IS NULL OR pd_enddate IS NULL THEN
          ld_startdate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
        ld_enddate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
      ELSE
           ld_startdate:=TO_DATE(pd_startdate,'YYYYMMDD');
         ld_enddate:=TO_DATE(pd_enddate,'YYYYMMDD');
      END IF;

      OPEN pc_ref FOR
        SELECT REFERANS, GONDEREN_SUBE, MUSTERI_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, ULKE_KODU, CEK_ILE_F, CEK_NO, TRANSFER_DOVIZ_KODU,
               TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU, KUR, PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, TO_CHAR(VALOR_TARIHI,'YYYYMMDD'),
               TRANSFER_SEKLI, BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO, MUH_BANK_HESAP_NO, ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO,
               HAVALE_KOMISYONU, DOVIZ_AL_SAT_KOMISYONU, HABERLESME_MASRAFI, BOC, IC, IC_ACIKLAMA, TTC, VCA, CIA_DOVIZ, ER, OC, OC_BEI, OC_HESAP_NO,
               OC_ISIM_ADRES, OI, OI_PARTY_IDENTIFIER, OI_BIC, OI_ISIM, OI_ISIM_ADRES, SC, SC_PARTY_IDENTIFIER, SC_BIC, SC_LOCATION, SC_ISIM_ADRES,
               RC, RC_PARTY_IDENTIFIER, RC_BIC, RC_LOCATION, RC_ISIM_ADRES, TRI, TRI_PARTY_IDENTIFIER, TRI_BIC, TRI_LOCATION, TRI_ISIM_ADRES, II,
               II_PARTY_IDENTIFIER, II_BIC, II_LOCATION, II_ISIM_ADRES, AWI, AWI_PARTY_IDENTIFIER, AWI_BIC, AWI_LOCATION, AWI_ISIM_ADRES, BC, BC_BEI,
               BC_HESAP_NO, BC_ISIM_ADRES, RI, DOC, SENDERS_CHARGES, SENDERS_DVZ, RECEIVERS_CHARGES, RECEIVERS_DVZ, STRI, RR, DURUM_KODU,
               TO_CHAR(ACILIS_TARIHI,'YYYYMMDD'), SENDER_BIC, RECEIVER_BIC, MASRAF_TOPLAMI, CIA_TUTAR, REZERVASYON_NO, SI_PARTY_IDENTIFIER, SI_BIC, SI,
               BI, BI_PARTY_IDENTIFIER, BI_BIC, BI_ISIM_ADRES, RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD, CHARGE_AMOUNT, 'bankname'
        FROM CBS_YPHAVALE_GIDEN
        WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
        AND VALOR_TARIHI BETWEEN ld_startdate AND ld_enddate;



    RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------------------
FUNCTION GetBankName(ps_biccode IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

BEGIN
    OPEN pc_ref FOR
         SELECT bankname FROM CBS_BANKCODES
                 WHERE BANK_BIC_CODE=ps_biccode;

        RETURN ls_returncode;
END;
-------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------
FUNCTION MakeOrderPayment(pn_from_acc                VARCHAR2,
                            pd_startdate               VARCHAR2,
                            ps_sender_name             VARCHAR2,
                            ps_bank_code               VARCHAR2,
                            ps_payee_name              VARCHAR2,
                            ps_to_account              VARCHAR2,
                            pn_total_amount            VARCHAR2,
                            ps_description             VARCHAR2,
                            ps_senderirsseco           VARCHAR2,
                            pn_rnn                     VARCHAR2,
                            pn_doc_no                  VARCHAR2,
                            pn_income                  VARCHAR2,
                            ps_currency                VARCHAR2,
                            pn_payee_internal_acc      VARCHAR2,
                            pn_payment_code            VARCHAR2,
                            pn_institution_cd          VARCHAR2,
                            pn_area_cd                 VARCHAR2,
                            pn_phone_no                VARCHAR2,
                            ps_tran_type               VARCHAR2,
                            ps_payment_type            VARCHAR2,
                            pn_informing               VARCHAR2,
                            pn_payment_period          VARCHAR2,
                            pn_endofweek               VARCHAR2,
                            pd_end_date                VARCHAR2,
                            pn_payment_no              VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_delimiter         VARCHAR2(1):=';';
        v_LoopCounter        BINARY_INTEGER := 0;
        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_order_id          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ls_fromaccountno     NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777; -- herhalde internet ?ubesi bu oluyor
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER;
        pn_kanal_numara      NUMBER:= 1;

        ln_from_acc            NUMBER(10);
        ln_external_acc      VARCHAR2(10);
        ln_rnn               VARCHAR2(15);
        ln_to_acc            NUMBER(10);
        ls_external_to_acc      VARCHAR2(10);
        ls_bank_code          VARCHAR2(200);
        ln_to_rnn               VARCHAR2(15);
        ls_to_name              VARCHAR2(50);
        ls_senderirsseco      VARCHAR2(5);
        ls_from_irseco          VARCHAR2(5);
        ln_area_cd           NUMBER(5);
          ln_phone_no          NUMBER(10);
        ln_payment_code      VARCHAR(100);
        ld_paymentdate       DATE;
        ld_enddate           DATE;
        ln_installmentid     NUMBER:=1;
        ln_count             NUMBER:=0;
        ln_paymentamount     NUMBER;


   BEGIN

           ld_paymentdate    :=TO_DATE(pd_startdate);
        ld_enddate        :=TO_DATE(pd_end_date);
        ln_paymentamount  :=TO_NUMBER(Pkg_Message.Split(pn_total_amount,ls_delimiter,v_LoopCounter));

        ln_islem_no             :=Pkg_Tx.islem_no_al;
        ln_order_id       :=Pkg_Genel.genel_kod_al('APS_ORDERID');
        ln_islem_kod      :=2200;
        lc_modul_tur_kod  :='COLLECTION';
        lc_urun_tur_kod   :='APS';
        lc_urun_sinif_kod :='PAYMENT';
        ln_hesap_numara   :=TO_NUMBER(pn_from_acc);
        ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);
        lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
        lc_amir_bolum_kodu:=lc_bolum_kodu;
        lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);

        IF ps_tran_type='CLEARING' THEN
         ln_to_acc                     :=TO_NUMBER('');
         ls_external_to_acc           :=ps_to_account;
         ls_bank_code               :=SUBSTR(ps_bank_code,1,9);
         ln_to_rnn                   :=pn_rnn;
         ls_to_name                   :=ps_payee_name;
         ls_senderirsseco           :=ps_senderirsseco;
         ls_from_irseco               :=Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)));
         ln_area_cd                   :=TO_NUMBER('');
         ln_phone_no               :=TO_NUMBER('');
         ln_payment_code           :=SUBSTR(pn_payment_code,1,3);
         END IF;

        IF ps_tran_type='B2OBHVL' THEN
         ln_to_acc                   :=TO_NUMBER(Pkg_Hesap.GetHesapNoFromExternal(ps_to_account,ps_currency));
         ls_external_to_acc           :=ps_to_account;
         ls_bank_code               :=ps_bank_code;
         ln_to_rnn                   :=pn_rnn;
         ls_to_name                   :=ps_payee_name;
         ls_senderirsseco           :='';
         ls_from_irseco               :=Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)));
         ln_area_cd                   :=TO_NUMBER('');
         ln_phone_no               :=TO_NUMBER('');
         ln_payment_code           :=SUBSTR(pn_payment_code,1,3);
         END IF;

        IF ps_tran_type='UTILPAY' THEN
         ln_to_acc                   :=TO_NUMBER('');
         ls_external_to_acc           :='';
         ls_bank_code               :='';
         ln_to_rnn                   :='';
         ls_to_name                   :='';
         ls_senderirsseco           :='';
         ls_from_irseco               :=Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)));
         ln_area_cd                   :=TO_NUMBER(pn_area_cd);
         ln_phone_no               :=TO_NUMBER(pn_phone_no);
         ln_payment_code           :='';
         END IF;



        IF ps_payment_type='IRREGULAR' THEN
             WHILE  v_LoopCounter<TO_NUMBER(pn_payment_no)
             LOOP

        INSERT INTO CBS_APS_INSTALMENTS_ISLEM
        (ORDER_ID, INSTALMENT_ID, INSTALMENT_DATE, INSTALMENT_AMOUNT, TX_NO, STATUS_CD, ERROR_DESC)
        VALUES
        (ln_order_id, v_LoopCounter+1, TO_DATE(Pkg_Message.Split(pd_startdate,ls_delimiter,v_LoopCounter)) , TO_NUMBER(Pkg_Message.Split(pn_total_amount,ls_delimiter,v_LoopCounter)),
         ln_islem_no,'sWAIT','');

        v_LoopCounter:=v_LoopCounter+1;
        END LOOP;

        INSERT INTO CBS_APS_ORDERS_ISLEM
        (TX_NO, ORDER_ID, ORDER_TYPE, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO,
         FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_ACCOUNT,
         TO_EXTERNAL_ACCOUNT, TO_BANK_CODE, TO_RNN, TO_NAME, CURRENCY_CODE,
         STATISTICS_PAYMENT_CODE, STATISTICS_OPERATION_CODE, STATISTICS_SPECIAL_CODE, STATISTICS_USER_FROM,
         STATISTICS_USER_TO, PERIOD_BA_FLAG, PERIOD_START_DATE, PERIOD_TYPE,
         MODUL_TUR_KOD, URUN_TUR_KOD,
         URUN_SINIF_KOD, PAYMENT_TYPE, BOLUM_KODU,
         STATUS_CD, PAYMENT_DESCRIPTION, AREA_CODE, PHONE_NO)
        VALUES
        (ln_islem_no,ln_order_id, ps_tran_type, TO_NUMBER(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)), pn_from_acc,
         LPAD(Pkg_Hesap.External_HesapNo_Al(pn_from_acc),9,0),Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)), Pkg_Hesap.HesapKisaIsimAl(pn_from_acc), Pkg_Hesap.GetBankCode(Pkg_Musteri.sf_bolum_kodu_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc))), ln_to_acc,
         ls_external_to_acc, ls_bank_code,  ln_to_rnn, ls_to_name, ps_currency,
         ln_payment_code, '01', '01', ls_from_irseco,
         ls_senderirsseco, pn_endofweek, TO_DATE(Pkg_Message.Split(pd_startdate,ls_delimiter,v_LoopCounter)), pn_payment_period,
         lc_modul_tur_kod, lc_urun_tur_kod,
         lc_urun_sinif_kod, ps_payment_type, Pkg_Musteri.sf_bolum_kodu_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)),
         'sVALID', ps_description, ln_area_cd, ln_phone_no);

            Pkg_Int_Api.create_transaction (ln_islem_no,
                                           ln_islem_kod,
                                         lc_modul_tur_kod,
                                         lc_urun_tur_kod,
                                         lc_urun_sinif_kod,
                                         TO_NUMBER(Pkg_Message.Split(pn_total_amount,ls_delimiter,v_LoopCounter)),
                                         lc_amir_bolum_kodu,
                                         lc_bolum_kodu,
                                         pc_rol,
                                         lc_doviz_kod,
                                         ln_musteri_numara,
                                         ln_hesap_numara,
                                         pc_kasa_kod,
                                         pn_kanal_numara);

        Pkg_Int_Api.process_transaction (ln_islem_no);


        ELSE

        /*INSERT INTO CBS_APS_INSTALMENTS_ISLEM
        (ORDER_ID, INSTALMENT_ID, INSTALMENT_DATE, INSTALMENT_AMOUNT, TX_NO, STATUS_CD, ERROR_DESC)
        values
        (ln_order_id, v_LoopCounter+1, to_date(pkg_message.Split(pd_startdate,ls_delimiter,v_LoopCounter)) , to_number(pkg_message.Split(pn_total_amount,ls_delimiter,v_LoopCounter)), ln_islem_no,'sWAIT','');
         */
         WHILE ld_paymentdate < ld_enddate
           LOOP

                IF pn_payment_period='WEEK' THEN
                   ld_paymentdate:=ld_paymentdate+7*ln_count;
                ELSIF pn_payment_period='MONTH' THEN
                   ld_paymentdate:=ADD_MONTHS(ld_paymentdate,1*ln_count);
                END IF;

               IF Pkg_Tarih.gun_ozellik(ld_paymentdate)=1 THEN
                     IF pn_endofweek='B' THEN
                       ld_paymentdate:=Pkg_Tarih.geri_is_gunu(ld_paymentdate);
                  ELSE--A
                     ld_paymentdate:=Pkg_Tarih.ileri_is_gunu(ld_paymentdate);
                  END IF;
               END IF;

                IF ld_paymentdate<=ld_enddate THEN

                       INSERT INTO CBS_APS_INSTALMENTS_ISLEM
                    (ORDER_ID, INSTALMENT_ID, INSTALMENT_DATE, INSTALMENT_AMOUNT, TX_NO,STATUS_CD)
                    VALUES
                    (ln_order_id, ln_installmentid, ld_paymentdate, ln_paymentamount, ln_islem_no,'sWAIT');

               END IF;

                   ln_installmentid:=ln_installmentid+1;
                ln_count:=ln_count+1;

           END LOOP;

        INSERT INTO CBS_APS_ORDERS_ISLEM
        (TX_NO, ORDER_ID, ORDER_TYPE, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO,
         FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_ACCOUNT,
         TO_EXTERNAL_ACCOUNT, TO_BANK_CODE, TO_RNN, TO_NAME, CURRENCY_CODE,
         STATISTICS_PAYMENT_CODE, STATISTICS_OPERATION_CODE, STATISTICS_SPECIAL_CODE, STATISTICS_USER_FROM,
         STATISTICS_USER_TO, PERIOD_BA_FLAG, PERIOD_START_DATE, PERIOD_END_DATE, PERIOD_TYPE,
         PERIOD_LENGTH, AMOUNT, MODUL_TUR_KOD, URUN_TUR_KOD,
         URUN_SINIF_KOD, PAYMENT_TYPE, BOLUM_KODU,
         STATUS_CD, PAYMENT_DESCRIPTION, AREA_CODE, PHONE_NO)
        VALUES
        (ln_islem_no,ln_order_id, ps_tran_type, TO_NUMBER(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)), pn_from_acc,
         LPAD(Pkg_Hesap.External_HesapNo_Al(pn_from_acc),9,0),Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)), Pkg_Hesap.HesapKisaIsimAl(pn_from_acc), Pkg_Hesap.GetBankCode(Pkg_Musteri.sf_bolum_kodu_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc))), ln_to_acc,
         ls_external_to_acc, ls_bank_code,  ln_to_rnn, ls_to_name, ps_currency,
         ln_payment_code, '01', '01', ls_from_irseco,
         ls_senderirsseco, pn_endofweek, TO_DATE(Pkg_Message.Split(pd_startdate,ls_delimiter,v_LoopCounter)), TO_DATE(Pkg_Message.Split(pd_end_date,ls_delimiter,v_LoopCounter)), pn_payment_period,
         1, TO_NUMBER(pn_total_amount), lc_modul_tur_kod, lc_urun_tur_kod,
         lc_urun_sinif_kod, ps_payment_type, Pkg_Musteri.sf_bolum_kodu_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_from_acc)),
         'sVALID', ps_description, ln_area_cd, ln_phone_no);

         Pkg_Int_Api.create_transaction (ln_islem_no,
                                         ln_islem_kod,
                                           lc_modul_tur_kod,
                                           lc_urun_tur_kod,
                                           lc_urun_sinif_kod,
                                           TO_NUMBER(pn_total_amount),
                                           lc_amir_bolum_kodu,
                                           lc_bolum_kodu,
                                           pc_rol,
                                           lc_doviz_kod,
                                           ln_musteri_numara,
                                           ln_hesap_numara,
                                           pc_kasa_kod,
                                           pn_kanal_numara);

        Pkg_Int_Api.process_transaction (ln_islem_no);

        END IF;


        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;
        RETURN ls_returncode;


   EXCEPTION
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('PAYMORD',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
   END;
----------------------------------------------------------------------------------------------------------------
FUNCTION GetAPSInquiry(ps_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER;
    NoPaymentOrder EXCEPTION;
BEGIN

         SELECT COUNT(*)
        INTO ln_count
        FROM CBS_APS_ORDERS
        WHERE FROM_CUSTOMER_NO=TO_NUMBER(ps_customerid);

        IF ln_count=0 THEN
           RAISE NoPaymentOrder;
        END IF;

      OPEN pc_ref FOR
        SELECT TX_NO, ORDER_ID, ORDER_TYPE, FROM_EXTERNAL_ACCOUNT, TO_EXTERNAL_ACCOUNT,
               TO_NAME, CURRENCY_CODE, TO_CHAR(PERIOD_START_DATE,'YYYYMMDD'), PERIOD_TYPE, AMOUNT,
               PAYMENT_TYPE, BOLUM_KODU, STATUS_CD, AREA_CODE, PHONE_NO, TO_CARD_NO
        FROM CBS_APS_ORDERS
        WHERE FROM_CUSTOMER_NO=TO_NUMBER(ps_customerid)
        ORDER BY TX_NO;

    RETURN ls_returncode;

EXCEPTION
    WHEN NoPaymentOrder THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;
----------------------------------------------------------------------------------------------------------------
FUNCTION GetInstalment(pn_order_id IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';

BEGIN

      OPEN pc_ref FOR
        SELECT ORDER_ID, INSTALMENT_ID, TO_CHAR(INSTALMENT_DATE,'YYYYMMDD'), INSTALMENT_AMOUNT,
               TO_CHAR(INSTALMENT_PAYMENT_DATE,'YYYYMMDD'), INSTALMENT_PAYMENT_AMOUNT, TX_NO, STATUS_CD, ERROR_DESC
        FROM CBS_APS_INSTALMENTS
        WHERE ORDER_ID=TO_NUMBER(pn_order_id)
        ORDER BY INSTALMENT_ID;

    RETURN ls_returncode;

END;
----------------------------------------------------------------------------------------------------------------
FUNCTION GetAPSInfo(ps_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER;
    NoPaymentOrder EXCEPTION;
BEGIN

         SELECT COUNT(*)
        INTO ln_count
        FROM CBS_APS_ORDERS
        WHERE FROM_CUSTOMER_NO=TO_NUMBER(ps_customerid)
        AND STATUS_CD='sVALID';

        IF ln_count=0 THEN
           RAISE NoPaymentOrder;
        END IF;

      OPEN pc_ref FOR
        SELECT TX_NO, ORDER_ID, ORDER_TYPE, FROM_EXTERNAL_ACCOUNT, TO_EXTERNAL_ACCOUNT,
               TO_NAME, CURRENCY_CODE, TO_CHAR(PERIOD_START_DATE,'YYYYMMDD'), PERIOD_TYPE, AMOUNT,
               PAYMENT_TYPE, BOLUM_KODU, STATUS_CD, AREA_CODE, PHONE_NO, TO_CARD_NO
        FROM CBS_APS_ORDERS
        WHERE FROM_CUSTOMER_NO=TO_NUMBER(ps_customerid)
        AND STATUS_CD='sVALID'
        ORDER BY TX_NO;

    RETURN ls_returncode;

EXCEPTION
    WHEN NoPaymentOrder THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;
----------------------------------------------------------------------------------------------------------------
FUNCTION PaymentOrderCancel(ps_txno                    VARCHAR2,
                            pn_orderid                 VARCHAR2,
                            pn_from_acc                VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_order_id          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ls_fromaccountno     NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777; -- herhalde internet ?ubesi bu oluyor
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER;
        pn_kanal_numara      NUMBER:= 1;
        ln_amount            NUMBER;


   BEGIN

        ln_islem_no             :=Pkg_Tx.islem_no_al;
        --ln_order_id       :=pkg_genel.genel_kod_al('APS_ORDERID');
        ln_order_id       :=TO_NUMBER(pn_orderid);
        ln_islem_kod      :=2201;
        lc_modul_tur_kod  :='COLLECTION';
        lc_urun_tur_kod   :='APS';
        lc_urun_sinif_kod :='PAYMENT';
        ln_hesap_numara   :=TO_NUMBER(Pkg_Hesap.GetHesapNoFromExternal(pn_from_acc,Pkg_Genel.LC_al));
        ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);
        lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
        lc_amir_bolum_kodu:=lc_bolum_kodu;
        lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);


       SELECT SUM(INSTALMENT_AMOUNT)
                 INTO ln_amount
       FROM CBS_APS_INSTALMENTS
       WHERE ORDER_ID=TO_NUMBER(pn_orderid) AND
                STATUS_CD='sWAIT';


       INSERT INTO CBS_APS_ORDERS_ISLEM
        (TX_NO, ORDER_ID, ORDER_TYPE, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO,
         FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_ACCOUNT,
         TO_EXTERNAL_ACCOUNT, TO_BANK_CODE, TO_RNN, TO_NAME, CURRENCY_CODE,
         STATISTICS_PAYMENT_CODE, STATISTICS_OPERATION_CODE, STATISTICS_SPECIAL_CODE, STATISTICS_PAYMENT_TYPE, STATISTICS_USER_FROM,
         STATISTICS_USER_TO, PERIOD_BA_FLAG, PERIOD_START_DATE, PERIOD_END_DATE, PERIOD_TYPE,
         PERIOD_LENGTH, AMOUNT, PERCENTOFBALANCE, MODUL_TUR_KOD, URUN_TUR_KOD,
         URUN_SINIF_KOD, TO_CARD_NO, TO_BANK_NAME, PAYMENT_TYPE, BOLUM_KODU,
         STATUS_CD, PAYMENT_DESCRIPTION, AREA_CODE, PHONE_NO, TO_GL_ACCOUNT)
        SELECT
               ln_islem_no, ORDER_ID, ORDER_TYPE, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO,
               FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_ACCOUNT,
               TO_EXTERNAL_ACCOUNT, TO_BANK_CODE, TO_RNN, TO_NAME, CURRENCY_CODE,
               STATISTICS_PAYMENT_CODE, STATISTICS_OPERATION_CODE, STATISTICS_SPECIAL_CODE, STATISTICS_PAYMENT_TYPE, STATISTICS_USER_FROM,
               STATISTICS_USER_TO, PERIOD_BA_FLAG, PERIOD_START_DATE, PERIOD_END_DATE, PERIOD_TYPE,
               PERIOD_LENGTH, AMOUNT, PERCENTOFBALANCE, MODUL_TUR_KOD, URUN_TUR_KOD,
               URUN_SINIF_KOD, TO_CARD_NO, TO_BANK_NAME, PAYMENT_TYPE, BOLUM_KODU,
               'sCANCEL', PAYMENT_DESCRIPTION, AREA_CODE, PHONE_NO, TO_GL_ACCOUNT
        FROM CBS_APS_ORDERS
        WHERE ORDER_ID=TO_NUMBER(pn_orderid);


       INSERT INTO CBS_APS_INSTALMENTS_ISLEM
        (ORDER_ID, INSTALMENT_ID, INSTALMENT_DATE, INSTALMENT_AMOUNT, INSTALMENT_PAYMENT_DATE,
         INSTALMENT_PAYMENT_AMOUNT, TX_NO, STATUS_CD, ERROR_DESC)
       SELECT ORDER_ID, INSTALMENT_ID, INSTALMENT_DATE, INSTALMENT_AMOUNT, INSTALMENT_PAYMENT_DATE,
               INSTALMENT_PAYMENT_AMOUNT, ln_islem_no, STATUS_CD, ERROR_DESC
       FROM CBS_APS_INSTALMENTS
       WHERE ORDER_ID=TO_NUMBER(pn_orderid);


         Pkg_Int_Api.create_transaction (ln_islem_no,
                                         ln_islem_kod,
                                           lc_modul_tur_kod,
                                           lc_urun_tur_kod,
                                           lc_urun_sinif_kod,
                                           ln_amount,
                                           lc_amir_bolum_kodu,
                                           lc_bolum_kodu,
                                           pc_rol,
                                           lc_doviz_kod,
                                           ln_musteri_numara,
                                           ln_hesap_numara,
                                           pc_kasa_kod,
                                           pn_kanal_numara);

        Pkg_Int_Api.process_transaction (ln_islem_no);


        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;
        RETURN ls_returncode;


   EXCEPTION
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('PORDCNCL',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
   END;
----------------------------------------------------------------------------------------------------------------

FUNCTION GetBranchName(pn_KODU in varchar2) RETURN VARCHAR2 IS

    ls_returncode            VARCHAR2(3):='000';

    ls_DESCRIPTION             VARCHAR2(250);

BEGIN
                SELECT KODU || '-' || ADI
               into ls_DESCRIPTION
               FROM CBS_BOLUM
               WHERE KODU=pn_KODU;

     RETURN ls_DESCRIPTION;

END;
-------------------------------------------------------------------------------
FUNCTION GetValueDate(pn_txno     in varchar2,
                            pd_trandate in varchar2) RETURN VARCHAR2
IS

ld_date   DATE;
ls_retval varchar2(3):='000';
ld_makedate     date;
ls_tx_tran_cd   varchar2(50);
ln_syshour number:=0;
ls_START_HH24 varchar2(3);
ls_START_MM varchar2(3);
ls_END_HH24 varchar2(3);
ls_END_MM varchar2(3);
BEGIN
        select MAKEDATE, to_date(FIELD3,'yyyymmdd'), trancd
        into ld_makedate, ld_date, ls_tx_tran_cd
        from CORPINT.tbl_txtodo
        WHERE  tx_no=Pkg_Message.split(pn_txno,',',1);

        ln_syshour := to_number(to_char(sysdate,'hh24'));

        if (ln_syshour>11)and(trunc(ld_makedate)=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul))and(trunc(sysdate)=Pkg_Muhasebe.Banka_Tarihi_Bul) then
           ld_date:=Pkg_Tarih.ileri_is_gunu_report(Pkg_Muhasebe.Banka_Tarihi_Bul);--Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul); aisuluud cq5778 Defect: clearing/gross report day value date

                UPDATE CORPINT.tbl_txtodo
                SET        FIELD3=TO_CHAR(ld_date,'YYYYMMDD'),
                           MAKEDATE=to_date(to_char(Pkg_Muhasebe.Banka_Tarihi_Bul,'yyyymmdd')||to_char(sysdate,'hh24miss'),'yyyymmddhh24miss')

                WHERE  tx_no=Pkg_Message.split(pn_txno,',',1);

                RETURN TO_CHAR(ld_date,'YYYYMMDD');
        end if;

        ld_date:=TO_DATE(pd_trandate,'YYYYMMDD');--VALUE DATE

        IF ls_tx_tran_cd in ('CLEARING', 'GROSS') THEN

            IF ls_tx_tran_cd = 'CLEARING' THEN
                ls_retval:=Pkg_Int_Limit.CheckTimeLimit('CLEARING');

                select START_HH24, START_MM, END_HH24, END_MM
                 into ls_START_HH24, ls_START_MM, ls_END_HH24, ls_END_MM
                 from cbs_int_time
                 where tran_cd='CLEARING';
            ELSE
                ls_retval:=Pkg_Int_Limit.CheckTimeLimit('GROSS');

                select START_HH24, START_MM, END_HH24, END_MM
                 into ls_START_HH24, ls_START_MM, ls_END_HH24, ls_END_MM
                 from cbs_int_time
                 where tran_cd='GROSS';
            END IF;

            ln_syshour := to_number(rpad(to_char(sysdate,'hh24mi'),4,'0'));

            IF (to_number(rpad(ls_END_HH24||ls_END_MM,4,'0'))<ln_syshour) AND (ld_date = Pkg_Muhasebe.Banka_Tarihi_Bul)and(trunc(sysdate)=Pkg_Muhasebe.Banka_Tarihi_Bul) THEN

               ld_date:=Pkg_Tarih.ileri_is_gunu_report(Pkg_Muhasebe.Banka_Tarihi_Bul);--Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul); aisuluud cq5778 Defect: clearing/gross report day value date

               UPDATE CORPINT.tbl_txtodo
               SET    FIELD3=TO_CHAR(ld_date,'YYYYMMDD')
               WHERE  tx_no=Pkg_Message.split(pn_txno,',',1);
            END IF;

        END IF;

        RETURN TO_CHAR(ld_date,'YYYYMMDD');
Exception
    when others then
        log_at('GetValueDate',sqlerrm,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
/******************************************************************************
    Name: sendApprovedGrossReport
    Desc: Function to prepare report about the number of approved gross paymetns
          and send to treasury nd payment departments
    Prepared By: Ernest Kuttubaev
    Modify Date: 25.11.2013
*******************************************************************************/
FUNCTION sendApprovedGrossReport(ps_date in varchar2) return varchar2
IS
    ls_return_code              varchar2(3):='000';
    lc_ref                      CURSORREFERENCETYPE;
    ls_from                     varchar2(25);
    ls_to                       varchar2(25);
    ln_count                    number; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    ln_amount                   number; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    ln_payment_total_count      number:=0; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    ln_payment_total_amount     number:=0; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    ln_count_in_this_hour       number:=0; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    ls_from_time                CORPINT.TBL_CONFIGURATION.VALUE%TYPE;
    ls_to_time                    CORPINT.TBL_CONFIGURATION.VALUE%TYPE;
    ls_mail_content             clob:='';
    ls_mail_sender              varchar2(50):='info@demirbank.kg';
    ls_mail_reciepent_treasury  varchar2(50):='d-hpmd@demirbank.kg';
    ls_mail_reciepent_payment   varchar2(50):='deptreasury@demirbank.kg';
    ls_mail_type                varchar2(10):='HTML';
    ls_mail_subject             varchar2(50);
    ls_mail_messagecode         varchar2(50):='SUBSCRIPTION';
    ln_mail_priority            number:=50;
    ld_date                     date;
BEGIN
    ld_date:=to_date(ps_date, 'YYYYMMDD');

    select value into ls_from_time from CORPINT.TBL_CONFIGURATION where key='ib.gross.email.notification.from.time'; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    select value into ls_to_time from CORPINT.TBL_CONFIGURATION where key='ib.gross.email.notification.to.time'; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    select value into ls_mail_sender from CORPINT.TBL_CONFIGURATION where key='ib.email.from'; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    select value into ls_mail_reciepent_treasury from CORPINT.TBL_CONFIGURATION where key='ib.email.dep.treasury'; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
    select value into ls_mail_reciepent_payment from CORPINT.TBL_CONFIGURATION where key='ib.email.dep.payment'; --AlmasN CQ1209 03102014 gross payments, email for treasury dep

    ls_mail_subject:='Approved Gross Payments for date ' || to_char(ld_date,'DD-MM-YYYY');

    open lc_ref for
        select to_char(from_date, 'HH24:MI'), to_char(till_date, 'HH24:MI'), count(tx_no), sum(amount)
        from (
                select
                        case
                             when trunc(clr.yaratildigi_tarih,'HH24') < to_date(ps_date || ' ' || ls_from_time, 'YYYYMMDD HH24:MI')
                             then to_date(ps_date || ' ' || ls_to_time, 'YYYYMMDD HH24:MI')-1
                             else trunc(clr.yaratildigi_tarih,'HH24')
                        end as from_date,
                        case
                             when trunc(clr.yaratildigi_tarih,'HH24') < to_date(ps_date || ' ' || ls_from_time, 'YYYYMMDD HH24:MI')
                             then to_date(ps_date || ' ' || ls_from_time, 'YYYYMMDD HH24:MI')
                             else trunc(clr.yaratildigi_tarih,'HH24')+1/24
                        end as till_date,
                        CLR.YARATAN_TX_NO as tx_no,
                        clr.amount amount --AlmasN CQ1209 03102014 gross payments, email for treasury dep
                from cbs_clearing clr, cbs_islem isl
                where
                    CLR.YARATAN_TX_NO = ISL.NUMARA
                    and CLR.PAYMENT_TYPE='GROSS'
                    and isl.durum in ('P', '3')
                    and CLR.YARATILDIGI_TARIH < to_date(ps_date || ' ' || ls_to_time, 'YYYYMMDD HH24:MI')
                    and CLR.YARATILDIGI_TARIH > to_date(ps_date || ' ' || ls_to_time, 'YYYYMMDD HH24:MI')-1
             )
        group by from_date, till_date
        order by from_date asc;

    ls_mail_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
    ls_mail_content:=ls_mail_content || '<table width=570 cellspacing="0" cellpadding="0">';

    ls_mail_content:=ls_mail_content || '<thead><tr>'
                    ||'<th>Time period, '||to_char(ld_date-1, 'DD.MM.YYYY')||'-'||to_char(ld_date, 'DD.MM.YYYY')||'</th>'
                    ||'<th>Quantity of payments</th>'
                    ||'<th>Amount of payments</th>'
                    ||'</tr></thead>';
    loop
        fetch lc_ref into ls_from, ls_to, ln_count, ln_amount;
        exit when lc_ref%notfound;
        ls_mail_content:=ls_mail_content || '<tr>'
                                        || '<td style="border: 1px solid" align="center">' || ls_from || '-' || ls_to || '</td>'
                                        || '<td style="border: 1px solid" align="center">' || ln_count || '</td>'
                                        || '<td style="border: 1px solid" align="center">' || to_char(ln_amount, '999,999,999,999.99') || '</td>'
                                        || '</tr>';
        ln_payment_total_count:=ln_payment_total_count + ln_count; --AlmasN CQ1209 03102014 gross payments, email for treasury dep
        ln_payment_total_amount:=ln_payment_total_amount + ln_amount; --AlmasN CQ1209 03102014 gross payments, email for treasury dep

        --AlmasN CQ1209 03102014 gross payments, email for treasury dep
        if (to_date(to_char(sysdate, 'yyyymmdd') || ls_from, 'yyyymmddhh24:mi') < sysdate and sysdate <= to_date(to_char(sysdate, 'yyyymmdd') || ls_to, 'yyyymmddhh24:mi')) then
            ln_count_in_this_hour := ln_count;
        end if;

    end loop;
    close lc_ref;

    ls_mail_content:=ls_mail_content || '<tr>'
                                    || '<td style="border: 1px solid" align="center"><strong>TOTAL</strong></td>'
                                    || '<td style="border: 1px solid" align="center">'||ln_payment_total_count||'</td>'
                                    || '<td style="border: 1px solid" align="center">'||to_char(ln_payment_total_amount, '999,999,999,999.99')||'</td>'
                                    || '</tr>';
    ls_mail_content:=ls_mail_content || '</table></body></html>';

    if (ln_count_in_this_hour > 0) then --AlmasN CQ1209 03102014 gross payments, email for treasury dep
        PKG_EMAIL.ADDTOEMAILQUEUE(ls_mail_messagecode, ln_mail_priority, ls_mail_sender, ls_mail_reciepent_payment,ls_mail_subject, ls_mail_content, ls_mail_type);
        PKG_EMAIL.ADDTOEMAILQUEUE(ls_mail_messagecode, ln_mail_priority, ls_mail_sender, ls_mail_reciepent_treasury,ls_mail_subject, ls_mail_content, ls_mail_type);
    end if;

    return ls_return_code;

EXCEPTION
   WHEN OTHERS THEN
        ls_return_code:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At('SENDAPPROVEDGROSSREPORT',SQLERRM);
        RETURN ls_return_code;
END;

/******************************************************************************
    Name: notifyBranchAboutGrossFavour
    Desc: Function to prepare email and send to branch directors about customers
           transactoin
    Prepared By: Ernest Kuttubaev
    Modify Date: 25.11.2013
*******************************************************************************/
FUNCTION notifyBranchAboutGrossFavour(
                    ps_customer_id varchar2,
                    ps_form_acc varchar2,
                    ps_tran_cd varchar2)
                    return varchar2
IS
    ls_return_code              varchar2(3):='000';
    ls_branch_director_email    varchar2(50);
    ls_customer_branch_code     varchar2(10):=PKG_MUSTERI.SF_BOLUM_KODU_AL(to_number(ps_customer_id));
    ls_mail_type                varchar2(50):='HTML';
    ln_mail_priority            number:=50;
    ls_mail_subject             varchar2(50):='Favour Transaction of the Customer';
    ls_mail_content             varchar2(1000):='';
    ls_mail_sender              varchar2(50):='info@demirbank.kg';
    ls_customer_name            varchar2(100):=PKG_MUSTERI.SF_MUSTERI_ADI(to_number(ps_customer_id));
BEGIN
    begin
        pkg_genel.get_branch_director_data(ls_customer_branch_code, ls_branch_director_email);

        exception
        when OTHERS then
            ls_branch_director_email:='d-hpmd@demirbank.kg';
    end;

    ls_mail_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
    ls_mail_content:=ls_mail_content || 'Dear<br/>';
    ls_mail_content:=ls_mail_content || 'Notifying you about transaction customer might made in favour of himself <br/>';
    ls_mail_content:=ls_mail_content || '<table width=570>';
    ls_mail_content:=ls_mail_content || '<tr><td>From Account</td><td>Client number</td><td>Client Name</td></tr>';
    ls_mail_content:=ls_mail_content || '<tr><td>'||ps_form_acc||'</td><td>'||ps_customer_id||'</td><td>'||ls_customer_name||'</td></tr>';
    ls_mail_content:=ls_mail_content || '</table></body></html>';

    PKG_EMAIL.ADDTOEMAILQUEUE('SUBSCRIPTION', ln_mail_priority, ls_mail_sender, ls_branch_director_email, ls_mail_subject, ls_mail_content, ls_mail_type);


    return ls_return_code;

EXCEPTION
   WHEN OTHERS THEN
        ls_return_code:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At('SENDAPPROVEDGROSSREPORT',SQLERRM);
        RETURN ls_return_code;
END;
/*******************************************************************************
    Name:   checkIfPaymentIsFavour
    Author: Ernest Kuttubaev
    Modify Date:    26.11.2013

    Desc: Check if the customer makes to himself of other bank by payeename and
          if payment is made favour of him send email to branch director
*******************************************************************************/
FUNCTION checkIfPaymentIsFavourMade(    ps_customer_id  IN varchar2,
                                        ps_form_acc     IN varchar2,
                                        ps_tran_cd      IN varchar2,
                                        ps_payeename    IN varchar2) RETURN VARCHAR2
IS
    ls_return_code           varchar2(3):='000';
    ls_customer_lfname       varchar2(50);
    ls_customer_llname       varchar2(50);
    ls_customer_lunvan       varchar2(200);
    ls_customer_tunvan       varchar2(100);
    ls_customer_efname       varchar2(50);
    ls_customer_elname       varchar2(50);

    ls_customer_name         varchar2(100);
    ls_payeename             varchar2(100);
BEGIN
    ls_payeename:=upper(replace(replace(ps_payeename, ' ', ''), ',', ''));

    select  t.isim, t.soyadi, T.LOKAL_UNVAN, T.TICARI_UNVAN,T.ISIM_ENG, T.SOYADI_ENG
    into    ls_customer_lfname, ls_customer_llname, ls_customer_lunvan, ls_customer_tunvan, ls_customer_efname, ls_customer_elname
    from    cbs_musteri t
    where   T.MUSTERI_NO=trim(ps_customer_id);

    ls_customer_name:=replace(upper(coalesce(ls_customer_lfname, '') || coalesce(ls_customer_llname, '')), ' ', '');

    if instr(ls_payeename, ls_customer_name) > 0 then
        ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    ls_customer_name:=replace(upper(coalesce(ls_customer_llname, '') || coalesce(ls_customer_lfname, '')), ' ', '');
    if instr(ls_payeename, ls_customer_name) > 0 then
        ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    ls_customer_name:=replace(upper(coalesce(ls_customer_efname, '') || coalesce(ls_customer_elname, '')), ' ', '');
    if instr(ls_payeename, ls_customer_name) > 0 then
       ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    ls_customer_name:=replace(upper(coalesce(ls_customer_elname, '') || coalesce(ls_customer_efname, '')), ' ', '');
    if instr(ls_payeename, ls_customer_name) > 0 then
        ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    ls_customer_name:=replace(upper(ls_customer_lunvan), ' ', '');
    if instr(ls_payeename, ls_customer_name) > 0 then
        ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    ls_customer_name:=replace(upper(ls_customer_tunvan), ' ', '');
    if instr(ls_payeename, ls_customer_name) > 0 then
        ls_return_code:=PKG_INT_TRANSFER.NOTIFYBRANCHABOUTGROSSFAVOUR(ps_customer_id,ps_form_acc, ps_tran_cd);
        return ls_return_code;
    end if;

    RETURN ls_return_code;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '888';
    WHEN OTHERS THEN
        RETURN '999';
END;
--B-O-M ernestk 24032014 cqdb00000862 add function to make card debt payment
/*******************************************************************************
    Name        :makeCardDebtPayment
    Prepared By :Ernest Kuttubaev
    Modify Date :24.03.2014
    Pupose      : To make card debt payment
*******************************************************************************/
FUNCTION MakeCardDebtPayment(  ps_personid           VARCHAR2,
                               ps_fromAccount        VARCHAR2,
                               ps_Amount             VARCHAR2,

                               ps_creditCardNo       VARCHAR2,
                               ps_pseudopan         VARCHAR2, -- AdiletK CQ5541 PCI DSS pseudopan
                               pc_ref OUT   cursorreferencetype)
   RETURN VARCHAR2
IS
   ls_returncode            VARCHAR2 (2000) := '000';
   ln_tutar                 NUMBER;
   ln_from_account_number   NUMBER;
   ln_islem_no              NUMBER;
   ln_islem_kod             NUMBER := 7723;
   lc_modul_tur_kod         VARCHAR2 (10) := 'CURR.OPS.';
   lc_urun_tur_kod          VARCHAR2 (10) := 'INTERNET';
   lc_urun_sinif_kod        VARCHAR2 (20);
   lc_doviz_kod             VARCHAR2 (3) := pkg_hesap.hesaptandovizkodual(ps_fromAccount);
   lc_hesap_no              NUMBER := TO_NUMBER (ps_fromAccount);
   ln_musteri_no NUMBER := Pkg_Hesap.hesaptanmusterinoal (TO_NUMBER (lc_hesap_no)) ;
   lc_bolum_kodu VARCHAR2 (3) := Pkg_Hesap.hesapsubeal (lc_hesap_no) ;
   lc_kasa_kod              NUMBER;
   ln_kanal_numara          NUMBER := 1;
   ln_detailid              NUMBER := 1;
   ld_date                  DATE := Pkg_Muhasebe.Banka_Tarihi_Bul;
   ls_date                  VARCHAR2(10) := TO_CHAR(ld_date,'YYYYMMDD');
   lc_rol                   NUMBER := 7777;
   ln_fisNo                   NUMBER;
   ls_ref_no                VARCHAR2 (16);
   ls_description      VARCHAR2(250);
   ls_maskedcreditCardNo  VARCHAR2(19);
   ps_reconcilation_no   VARCHAR2(7);
BEGIN
   ps_reconcilation_no:=TO_CHAR(SQ_CBS_CCDEBTPAYMENT_RECONCNO.nextVal);
   lc_urun_sinif_kod :=PKG_TX7723.sf_urun_tur_sinif_al(ps_fromAccount);
   SELECT REGEXP_REPLACE(ps_creditCardNo,'([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})','\1 XXXX XXXX \4') INTO ls_maskedcreditCardNo  FROM dual;
   ln_islem_no := Pkg_Tx.islem_no_al;
   ln_tutar := TO_NUMBER (REPLACE(ps_Amount,',',''), '99999999999.9999');
   ln_from_account_number := TO_NUMBER (ps_fromAccount);
   IF pkg_hesap.Kullanilabilir_Bakiye_Al (ln_from_account_number) < ln_tutar
   THEN
      ls_returncode := '051';
      RETURN ls_returncode;
   ELSE
      ls_ref_no := 'I' || ln_islem_no;
      ls_description:='Credit Card Payment, RIB';
      INSERT INTO CBS.CBS_INT_CARD_FINANSAL_ISLEM (TX_NO,
                                                   MODUL_TUR_KOD,
                                                   URUN_TUR_KOD,
                                                   URUN_SINIF_KOD,
                                                   TERMINAL_BRANCH,
                                                   ORIGINAL_CURRENCY_CODE,
                                                   ORIGINAL_AMOUNT,
                                                   EXPLANATION,
                                                   CARD_NUMBER,
                                                   FROM_ACCOUNT_NUMBER,
                                                   TERMINAL_ID,
                                                   REFERANCE,
                                                   KAYIT_SISTEM_TARIHI,

                                                   KAYIT_USER,
                                                   PSEUDOPAN)
        VALUES   (ln_islem_no,
                  lc_modul_tur_kod,
                  lc_urun_tur_kod,
                  lc_urun_sinif_kod,
                  NULL,
                  lc_doviz_kod,
                  ln_tutar,
                  ls_description,
                  ls_maskedcreditCardNo,
                  lc_hesap_no,
                  NULL,
                  ls_ref_no,
                  SYSDATE,
                  'CINT_CALLER',
                  ps_pseudopan); -- AdiletK CQ5541 PCI DSS pseudopan
      Pkg_Int_Api.create_transaction (ln_islem_no,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_bolum_kodu,
                                      lc_bolum_kodu,
                                      lc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_no,
                                      lc_hesap_no,
                                      lc_kasa_kod,
                                      ln_kanal_numara);

      SELECT FIS_NUMARA INTO ln_fisNo FROM CBS_ISLEM WHERE NUMARA=ln_islem_no;


      /*ls_returncode:= PKG_SOA_TRANSACTION.ccdebtpayment (  ps_creditCardNo, ps_Amount, lc_doviz_kod,
                                                           lc_bolum_kodu, ls_date, ls_date,
                                                           ls_description, ln_fisNo, ls_date, ps_reconcilation_no, ps_pseudopan ); -- AdiletK CQ5541 PCI DSS pseudopan*/

/*      IF ls_returncode <> '000' THEN
          ROLLBACK;
          Log_At('CreditCardCPaymentTx',ls_returncode,ls_maskedcreditCardNo || ' ' || ps_fromAccount || ' ' ||  ps_Amount || ' ' || ls_date  );
          ls_returncode :='999';
      ELSE
          Pkg_Int_Api.process_transaction (ln_islem_no);
          COMMIT;
      END IF; */

        Pkg_Int_Api.process_transaction (ln_islem_no);
        COMMIT;
   END IF;

     ls_returncode:= PKG_SOA_TRANSACTION.ccdebtpayment (  ps_creditCardNo, ps_Amount, lc_doviz_kod,
                                                           lc_bolum_kodu, ls_date, ls_date,
                                                           ls_description, ln_fisNo, ls_date, ps_reconcilation_no, ps_pseudopan ); -- AdiletK CQ5541 PCI DSS pseudopan

      IF ls_returncode <> '000' THEN
          update CBS_INT_CARD_FINANSAL_ISLEM
          set explanation = substr(EXPLANATION || ls_returncode, 1, 30)
          where tx_no=ln_islem_no;

          PKG_BAGLAM.yarat(lc_bolum_kodu, to_number(lc_rol));

          -- make cancel transaction
          PKG_TX.IPTAL(ln_islem_no);

          -- make cancel transaction
          PKG_TX.IPTAL_ONAY(ln_islem_no);

          Log_At('CreditCardCPaymentTx',ls_returncode,ls_maskedcreditCardNo || ' ' || ps_fromAccount || ' ' ||  ps_Amount || ' ' || ls_date  );
          ls_returncode :='999';
      END IF;

    OPEN pc_ref FOR
      SELECT  ls_returncode FROM dual;
   RETURN ls_returncode;
 EXCEPTION
    WHEN OTHERS THEN
        ls_returncode :='999';
        ROLLBACK;
        Log_At('CreditCardCPaymentTx',ls_returncode,SQLERRM);
        RETURN ls_returncode;
END;
--E-O-M ernestk 24032014 cqdb00000862 add function to make card debt payment


/******************************************************************************
    Name: sendCibSwiftReport
    Desc: Function to prepare report about the number of swift payments and send to treasury department
    Prepared By: Chyngyz Omurov cq509
    Modify Date: 06.04.2015
*******************************************************************************/
FUNCTION sendCibSwiftReport(ps_date in varchar2) return varchar2
IS
    ls_return_code              varchar2(3):='000';
    ls_notify_time                CORPINT.TBL_CONFIGURATION.VALUE%TYPE;
    ln_count NUMBER := 0;

    ls_mail_content             clob:='';
    ls_mail_sender              varchar2(50):='info@demirbank.kg';
    ls_mail_reciepent_treasury  varchar2(50):='d-hpmd@demirbank.kg';
    ls_mail_type                varchar2(10):='HTML';
    ls_mail_subject             varchar2(500);
    ls_mail_messagecode         varchar2(50):='SUBSCRIPTION';
    ln_mail_priority            number:=50;
    ld_date date;

    CURSOR lc_ref(pd_date DATE, ps_notify_time VARCHAR2) IS
    select CORR_BANK, CURRENCY, VALUE_DATE, TOTAL_AMOUNT, APPROVED_AMOUNT, WAITING_AMOUNT, TX_COUNT

    FROM
             (select nvl(C.CORRBANK_NAME, PKG_MUSTERI.SF_MUSTERI_ADI(A.MUH_BANK_MUSTERI_NO)) CORR_BANK,
                        A.TRANSFER_DOVIZ_KODU CURRENCY,
                        PKG_MUHASEBE.BANKA_TARIHI_BUL VALUE_DATE,
                        SUM (I.TUTAR) TOTAL_AMOUNT,
                        SUM ( DECODE(I.DURUM, 'P', I.TUTAR, 0)) APPROVED_AMOUNT,
                        SUM ( DECODE(I.DURUM, 'P', 0,  I.TUTAR)) WAITING_AMOUNT,

                        COUNT (TX_NO) TX_COUNT
                from CBS_YPHAVALE_GIDEN_ACILIS a
                    left join CBS_ISLEM i on A.TX_NO = I.NUMARA
                    left join CORPINT.TBL_SWIFT_SETTINGS_CIB c on A.MUH_BANK_MUSTERI_NO = C.CORRBANK_CUSTNO
                where I.KAYIT_TARIH = pd_date --transaction is created today (customer selected value date may differ)
                    and I.URUN_SINIF_KOD like 'CIB%' --operation was created in CIB
                    and I.DURUM in ('P', 'C', 'V') --operation is whether processed, created or verified in CBS (not rejected, refused)
                    --and A.MUSTERI_NO in (15728)  --<<<<<<<<<<<<<<<<<<<<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!REMOVE
                group by nvl(C.CORRBANK_NAME, PKG_MUSTERI.SF_MUSTERI_ADI(A.MUH_BANK_MUSTERI_NO)), A.TRANSFER_DOVIZ_KODU
                UNION
                select nvl(C.CORRBANK_NAME, PKG_MUSTERI.SF_MUSTERI_ADI(A.MUH_BANK_MUSTERI_NO)) CORR_BANK,    --2 Created next VD from 17:00 yesterday till 17:00 today
                           A.TRANSFER_DOVIZ_KODU CURRENCY,
                       A.VALOR_TARIHI  VALUE_DATE,
                        SUM (A.TUTAR) TOTAL_AMOUNT,
                        SUM ( DECODE(NVL(I.DURUM, ''), 'P', A.TUTAR, 0)) APPROVED_AMOUNT, -->>>>SHOULD BE ZERO ALWAYS
                        SUM ( DECODE(NVL(I.DURUM, ''), 'P', 0,  A.TUTAR)) WAITING_AMOUNT, -->>>> SHOULD BE EQUAL TO TOTAL_AMOUNT ALMAYS

                        COUNT (TX_NO) TX_COUNT
                from CBS_YPHAVALE_GIDEN_ACILIS a
                     left join CBS_ISLEM i on A.TX_NO = I.NUMARA
                      left join CORPINT.TBL_SWIFT_SETTINGS_CIB c on A.MUH_BANK_MUSTERI_NO = C.CORRBANK_CUSTNO
                where A.VALOR_TARIHI > PKG_MUHASEBE.BANKA_TARIHI_BUL --customer selected value date is later than today

                    and A.URUN_SINIF_KOD like 'CIB%' --opearation was created in CIB
                    and I.NUMARA IS NULL --transaction is not yet created in CBS, i.e., not already created before
                    --and A.MUSTERI_NO in (15728)   --<<<<<<<<<<<<<<<<<<<<!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!REMOVE
                    and (A.YARATILDIGI_TARIH BETWEEN TO_DATE(TO_CHAR(PKG_MUHASEBE.Onceki_Banka_Tarihi_Bul, 'YYYYMMDD') || ' ' || ps_notify_time, 'YYYYMMDD HH24:MI') --created in time period between previous bank date 17:00 and current bank date 17:00
                                                AND TO_DATE(TO_CHAR(PKG_MUHASEBE.BANKA_TARIHI_BUL, 'YYYYMMDD') || ' ' || ps_notify_time, 'YYYYMMDD HH24:MI')
                                                --OR ---for testing environment
                             /*A.YARATILDIGI_TARIH BETWEEN TO_DATE(TO_CHAR(SYSDATE - 3, 'YYYYMMDD') || ' ' || ps_notify_time, 'YYYYMMDD HH24:MI') --created in time period between previous bank date 17:00 and current bank date 17:00
                                                AND TO_DATE(TO_CHAR(SYSDATE, 'YYYYMMDD') || ' ' || ps_notify_time , 'YYYYMMDD HH24:MI')*/)
                group by nvl(C.CORRBANK_NAME, PKG_MUSTERI.SF_MUSTERI_ADI(A.MUH_BANK_MUSTERI_NO)), A.TRANSFER_DOVIZ_KODU,   A.VALOR_TARIHI
                ORDER BY  VALUE_DATE);

BEGIN
   ld_date:=to_date(ps_date, 'YYYYMMDD');

    select value into ls_notify_time from CORPINT.TBL_CONFIGURATION where key='cib.swift.email.notification.time';


    select value into ls_mail_sender from CORPINT.TBL_CONFIGURATION where key='ib.email.from';
    select value into ls_mail_reciepent_treasury from CORPINT.TBL_CONFIGURATION where key='ib.email.dep.treasury';

    ls_mail_subject:= 'Swift Payments for period '||to_char(ld_date-1, 'DD.MM.YYYY')||' '||ls_notify_time||' - '||to_char(ld_date, 'DD.MM.YYYY')||' '||ls_notify_time;

    ls_mail_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251"></head><body>';
    ls_mail_content:=ls_mail_content || '<table width=820 cellspacing="0" cellpadding="0">';

    ls_mail_content:=ls_mail_content || '<thead><tr>'
                    ||'<th>Corr.bank name</th>'
                    ||'<th>Currency</th>'
                    ||'<th>Value Date</th>'
                    ||'<th>Total Amount</th>'
                    ||'<th>Approved by Bank</th>'
                    ||'<th>Waiting for Bank''s approval</th>'

                    ||'<th>Total Number of transactions</th>'
                    ||'</tr></thead>';


   FOR lrow in lc_ref(ld_date, ls_notify_time)
    LOOP
        ls_mail_content:=ls_mail_content || '<tr >'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || lrow.CORR_BANK || '</td>'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || lrow.CURRENCY || '</td>'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || to_char(lrow.VALUE_DATE, 'DD.MM.YYYY') || '</td>'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || to_char(lrow.TOTAL_AMOUNT, '999,999,999,999.99')  || '</td>'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || to_char(lrow.APPROVED_AMOUNT, '999,999,999,999.99')  || '</td>'
                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || to_char(lrow.WAITING_AMOUNT, '999,999,999,999.99') || '</td>'

                                        || '<td style="border: 1px solid; border-collapse: collapse;" align="center">' || lrow.TX_COUNT ||'</td>'
                                        || '</tr>';

        ln_count := ln_count + 1;
    end loop;


    if ln_count = 0 then
        ls_mail_content := ls_mail_content || '<tr><td colspan=''7''> No SWIFT Payments via Coporate IB for this time period!</td></tr>';
    end if;

    ls_mail_content:=ls_mail_content || '</table></body></html>';


    PKG_EMAIL.ADDTOEMAILQUEUE(ls_mail_messagecode, ln_mail_priority, ls_mail_sender, ls_mail_reciepent_treasury, ls_mail_subject, ls_mail_content, ls_mail_type);



    return ls_return_code;

EXCEPTION
   WHEN OTHERS THEN
        ls_return_code:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        Log_At('swiftcib pkg_int_transfer.sendCibSwiftReport',SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN ls_return_code;
END;

END;
/

