create PACKAGE BODY PKG_TX1307 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    pkg_teminat.sp_teminat_kontrolsonra(pn_islem_No);
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
	pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_No);

  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
	null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	 null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
    ln_teklif_no    cbs_kredi_teklif.teklif_no%type;
	ls_durum_kodu   cbs_kredi_teklif.durum_kodu%type;
	ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
	ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
	ls_kapat	   varchar2(200);
  Begin

     select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

	 pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no,null,null,ls_kapat);

	exception when no_data_found then null;

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
	ln_faiz_tahakkuk  		cbs_hesap_kredi.hesap_no%type;
	ln_vergi_tahakkuk		cbs_hesap_kredi.hesap_no%type;
	ls_kapat  varchar2(200);
  Begin
	/* teminat islem Durum guncellenir */
 	 select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

	 pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no , ls_kapat);

  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
	/* teminat islem Durum guncellenir */
	pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;


 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
 Begin
    pkg_teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue );

 End;

 Procedure Muhasebelesme(pn_islem_no number)
 is
  ln_fis_no number := 0;
  ls_kapat  varchar2(200);
  Begin
/* teminat islem Durum guncellenir */
 	 select decode( TEMINATLAR_KAPAT,'E','KAPAMA',null)
	 into ls_kapat
	 from cbs_teminat_toplu_islem
	 where tx_no = pn_islem_no ;

	pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,ls_kapat);

  Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '507' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

END ;
/

