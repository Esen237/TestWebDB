create PACKAGE     Pkg_Tx7060 IS
/******************************************************************************
Name       : Pkg_Tx7060
Created By : Serpil Aytemiz, 20071231
Purpose       : Definition of charges exemption for Customer on transaction basis
******************************************************************************/
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);     -- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);    -- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);        -- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);        -- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);    -- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);        -- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);      -- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);        -- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
PROCEDURE Sf_Onay_Bekleyen_Varmi( pn_musteri_no number ,pn_islem_no CBS_ISLEM.numara%TYPE ,pn_islem_tanim_kod  CBS_ISLEM.islem_kod%TYPE DEFAULT 7060);
PROCEDURE islem_kopyala(pn_islem_no NUMBER,pn_musteri_no NUMBER) ;
Function sf_company_of_the_staff_var (pn_musteri_no number  ) return varchar2;

END;

/

