create PACKAGE BODY     PKG_REPORT4 IS

  FUNCTION GET8SB_ROW_CODE(URUN_TUR_KOD_ VARCHAR2, YERLESIM_KOD_ VARCHAR2, URUN_SINIF_KOD_ VARCHAR2, UYRUK_KOD_ VARCHAR2) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(2);
	A NUMBER;
  BEGIN
    IF URUN_SINIF_KOD_ IN ('OVERNIGHT-FC', 'OVERNIGHT-LC', 'SHORT TERM 1M-FC', 'SHORT TERM 1M-LC') THEN
	   A := 1;
	ELSE
	   A := 2;
	END IF;

    IF UPPER(URUN_TUR_KOD_) IN ('LOAN GIVEN', 'DEPO') THEN
       IF YERLESIM_KOD_ = '1' THEN
	      IF A = 1 THEN
	      	 RESULT := '02';
		   ELSE
		   	 RESULT := '03';
		  END IF;
	   ELSE
	   	  IF UYRUK_KOD_ = 'RU' THEN
	         IF A = 1 THEN
	      	    RESULT := '08';
		     ELSE
			 	RESULT := '09';
		     END IF;
		  ELSE
	         IF A = 1 THEN
	      	    RESULT := '05';
		     ELSE
			 	RESULT := '06';
		     END IF;
		  END IF;
       END IF;
    END IF;

  	IF UPPER(URUN_TUR_KOD_) IN ('LOAN', 'PLACEMENT') THEN
       IF YERLESIM_KOD_ = '1' THEN
	      IF A = 1 THEN
	      	 RESULT := '11';
		   ELSE
		   	 RESULT := '12';
		  END IF;
	   ELSE
	   	  IF UYRUK_KOD_ = 'RU' THEN
	         IF A = 1 THEN
	      	    RESULT := '17';
		     ELSE
			 	RESULT := '18';
		     END IF;
		  ELSE
	         IF A = 1 THEN
	      	    RESULT := '14';
		     ELSE
			 	RESULT := '15';
		     END IF;
		  END IF;
       END IF;
    END IF;

	RETURN RESULT;
  END;
  ---------------------------------------------------------
  FUNCTION GET9SB_ROW_CODE(CUR_CODE VARCHAR2, BANK_TYPE VARCHAR2) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(2);
  BEGIN
  	   IF CUR_CODE = 'USD' THEN
	   	  IF BANK_TYPE = '0' THEN RESULT := '01'; END IF;
	   	  IF BANK_TYPE = '1' THEN RESULT := '02'; END IF;
	   	  IF BANK_TYPE = '2' THEN RESULT := '03'; END IF;
	   END IF;
  	   IF CUR_CODE = 'EUR' THEN
	   	  IF BANK_TYPE = '0' THEN RESULT := '04'; END IF;
	   	  IF BANK_TYPE = '1' THEN RESULT := '05'; END IF;
	   	  IF BANK_TYPE = '2' THEN RESULT := '06'; END IF;
	   END IF;
  	   IF CUR_CODE = 'RUB' THEN
	   	  IF BANK_TYPE = '0' THEN RESULT := '07'; END IF;
	   	  IF BANK_TYPE = '1' THEN RESULT := '08'; END IF;
	   	  IF BANK_TYPE = '2' THEN RESULT := '09'; END IF;
	   END IF;
	RETURN RESULT;
  END;
  ---------------------------------------------------------

FUNCTION GET8SB_TUTAR_FAIZ(PS_URUNTURKOD VARCHAR2, PS_CURRENCY VARCHAR2,PS_ROWCODE VARCHAR2, PS_TYPE VARCHAR2, PS_BD DATE, PS_ED DATE) RETURN NUMBER
IS
		 LN_TUTAR				   NUMBER;
		 LN_FAIZ				   NUMBER;

BEGIN
SELECT TUTAR, FAIZ_ORANI
  INTO LN_TUTAR, LN_FAIZ
  FROM (SELECT PKG_REPORT4.GET8SB_ROW_CODE(D.URUN_TUR_KOD, M.YERLESIM_KOD, D.URUN_SINIF_KOD, DECODE(M.UYRUK_KOD, 'KZ', 'KZ', 'FC')) SATIR_CODE,
			   D.URUN_TUR_KOD,
			   DECODE(D.URUN_SINIF_KOD, 'OVERNIGHT-FC', 'L30','OVERNIGHT-LC', 'L30', 'SHORT TERM 1M-FC', 'L30', 'SHORT TERM 1M-LC', 'L30', 'G30') URUN_SINIF_KOD,
			   M.YERLESIM_KOD,
			   DECODE(M.UYRUK_KOD, 'KZ', 'KZ', 'FC') UYRUK_KOD,
			   D.DOVIZ_KODU,
			   ROUND(SUM(D.TUTAR)/1000, 2) TUTAR,
			   ROUND(SUM((TUTAR/1000) * FAIZ_ORANI) / SUM(TUTAR/1000), 2) FAIZ_ORANI
		  FROM CBS_VW_DEPO D,CBS_MUSTERI M
		 WHERE VALOR_TARIHI(+) BETWEEN PS_BD AND PS_ED
		  	   AND D.VADE_ISLEM_BILGISI = 1
		 	   AND D.BANKA_MUSTERI_NO=M.MUSTERI_NO
		 GROUP BY PKG_REPORT4.GET8SB_ROW_CODE(D.URUN_TUR_KOD, M.YERLESIM_KOD, D.URUN_SINIF_KOD, DECODE(M.UYRUK_KOD, 'KZ', 'KZ', 'FC')),
		  	   	  D.URUN_TUR_KOD,
				  M.YERLESIM_KOD,
				  DECODE(D.URUN_SINIF_KOD, 'OVERNIGHT-FC', 'L30','OVERNIGHT-LC', 'L30', 'SHORT TERM 1M-FC', 'L30', 'SHORT TERM 1M-LC', 'L30', 'G30'),
				  DECODE(M.UYRUK_KOD, 'KZ', 'KZ', 'FC'),
				  DOVIZ_KODU
		UNION ALL
		SELECT PKG_REPORT4.GET8SB_ROW_CODE(D.URUN_TUR_KOD, M.YERLESIM_KOD, D.URUN_SINIF_KOD, M.UYRUK_KOD) SATIR_CODE,
			   D.URUN_TUR_KOD,
			   DECODE(D.URUN_SINIF_KOD, 'OVERNIGHT-FC', 'L30','OVERNIGHT-LC', 'L30', 'SHORT TERM 1M-FC', 'L30', 'SHORT TERM 1M-LC', 'L30', 'G30') URUN_SINIF_KOD,
			   M.YERLESIM_KOD,
			   M.UYRUK_KOD UYRUK_KOD,
			   D.DOVIZ_KODU,
			   ROUND(SUM(D.TUTAR)/1000, 2) TUTAR,
			   ROUND(SUM((TUTAR/1000) * FAIZ_ORANI) / SUM(TUTAR/1000), 2) FAIZ_ORANI
		  FROM CBS_VW_DEPO D,CBS_MUSTERI M
		 WHERE VALOR_TARIHI(+) BETWEEN PS_BD AND PS_ED
		  	   AND D.VADE_ISLEM_BILGISI = 1
		 	   AND D.BANKA_MUSTERI_NO=M.MUSTERI_NO
			   AND M.UYRUK_KOD = 'RU'
		 GROUP BY PKG_REPORT4.GET8SB_ROW_CODE(D.URUN_TUR_KOD, M.YERLESIM_KOD, D.URUN_SINIF_KOD, M.UYRUK_KOD),
		  	   	  D.URUN_TUR_KOD,
				  M.YERLESIM_KOD,
				  DECODE(D.URUN_SINIF_KOD, 'OVERNIGHT-FC', 'L30','OVERNIGHT-LC', 'L30', 'SHORT TERM 1M-FC', 'L30', 'SHORT TERM 1M-LC', 'L30', 'G30'),
				  M.UYRUK_KOD,
				  DOVIZ_KODU)
	 WHERE URUN_TUR_KOD=PS_URUNTURKOD
	 AND DOVIZ_KODU=PS_CURRENCY
	 AND SATIR_CODE=PS_ROWCODE;

	 IF PS_TYPE = 'T' THEN
	 	RETURN LN_TUTAR;
	 ELSE
	 	RETURN LN_FAIZ;
	 END IF;
EXCEPTION
		 WHEN NO_DATA_FOUND THEN
		 	  RETURN NULL;
END;
----------------------------------------------------------------------------------
FUNCTION CYR2LAT(STRING VARCHAR2) RETURN VARCHAR2
IS
  CH 	 				VARCHAR2(2);
  D_CH 					VARCHAR2(4);--transliteration standard update (2013)ICAO NurzalatA CQDB5912 (2) 
  D_STRING 				VARCHAR2(1000);
  /*Updates with NurzalatA tag have been made due to 2013 table on wiki
  https://en.wikipedia.org/wiki/Romanization_of_Russian*/
BEGIN
	 D_STRING := '';
	 if STRING is not null
	 then
		 FOR I IN 1 .. LENGTH(STRING) LOOP
		 	 CH := SUBSTR(UPPER(STRING), I, 1);
			 SELECT  
			         CASE WHEN CH = 'А' THEN 'A'
					 	  WHEN CH = 'Б' THEN 'B'
						  WHEN CH = 'В' THEN 'V'
						  WHEN CH = 'Г' THEN 'G'
						  WHEN CH = 'Д' THEN 'D'
						  WHEN CH = 'Е' THEN 'E'
						  WHEN CH = 'Ё' THEN 'E'--WHEN CH = 'Ё' THEN 'YO' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  WHEN CH = 'Ж' THEN 'ZH'--WHEN CH = 'Ж' THEN 'J' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  WHEN CH = 'З' THEN 'Z'
						  WHEN CH = 'И' THEN 'I'
						  WHEN CH = 'Й' THEN 'I'--WHEN CH = 'Й' THEN 'Y' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  WHEN CH = 'К' THEN 'K'
						  WHEN CH = 'Л' THEN 'L'
						  WHEN CH = 'М' THEN 'M'
						  WHEN CH = 'Н' THEN 'N'
						  WHEN CH = 'О' THEN 'O'
						  WHEN CH = 'П' THEN 'P'
						  WHEN CH = 'Р' THEN 'R'
						  WHEN CH = 'С' THEN 'S'
						  WHEN CH = 'Т' THEN 'T'
						  WHEN CH = 'У' THEN 'U'
						  WHEN CH = 'Ф' THEN 'F'
						  WHEN CH = 'Х' THEN 'KH'
						  WHEN CH = 'Ц' THEN 'TS'
						  WHEN CH = 'Ч' THEN 'CH'
						  WHEN CH = 'Ш' THEN 'SH'--WHEN CH = 'Ш' OR CH = 'Щ' THEN 'SH' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  WHEN CH = 'Щ' THEN 'SHCH'--WHEN CH = 'Ш' OR CH = 'Щ' THEN 'SH' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ъ' THEN 'IE'--WHEN CH = 'Ь' OR CH = 'Ъ' THEN '' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Ы' THEN 'Y'
                          WHEN CH = 'Ь' THEN ''--WHEN CH = 'Ь' OR CH = 'Ъ' THEN '' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  WHEN CH = 'Э' THEN 'E'
						  WHEN CH = 'Ю' THEN 'IU'--WHEN CH = 'Ю' THEN 'YU' transliteration standard update (2013)ICAO NurzalatA CQDB5912
                          WHEN CH = 'Я' THEN 'IA'--WHEN CH = 'Я' THEN 'YA' transliteration standard update (2013)ICAO NurzalatA CQDB5912
						  ELSE CH
					 END CHR
			 INTO D_CH FROM DUAL;
			 D_STRING := D_STRING || D_CH;
		 END LOOP;
	 END if;
	 RETURN D_STRING;
exception
  when others then
  log_at('hakan_report_error','STRING',STRING);
END;
----------------------------------------------------------------------------------
FUNCTION COMM_GET_DATE(RPT_DATE DATE, WEEK NUMBER, DATE_TYPE VARCHAR2) RETURN DATE
IS
  F_BEGIN_DATE			   DATE;
  F_END_DATE			   DATE;
BEGIN
	 IF WEEK = 1 THEN
	    SELECT BEGIN_DATE, END_DATE
	      INTO F_BEGIN_DATE, F_END_DATE
	      FROM CBS_RPT_PERIODS
		 WHERE RPT_DATE BETWEEN BEGIN_DATE AND END_DATE;
	 END IF;
	 IF WEEK = 2 THEN
	 	SELECT MAX(BEGIN_DATE), MAX(END_DATE)
		  INTO F_BEGIN_DATE, F_END_DATE
		  FROM CBS_RPT_PERIODS
		 WHERE BEGIN_DATE < (SELECT BEGIN_DATE
		                       FROM CBS_RPT_PERIODS
		                      WHERE RPT_DATE BETWEEN BEGIN_DATE AND END_DATE);
	 END IF;
	 IF WEEK = 3 THEN
	 	SELECT MAX(BEGIN_DATE), MAX(END_DATE)
		  INTO F_BEGIN_DATE, F_END_DATE
		  FROM CBS_RPT_PERIODS
		 WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
							   FROM CBS_RPT_PERIODS
							  WHERE BEGIN_DATE < (SELECT BEGIN_DATE
								                    FROM CBS_RPT_PERIODS
								                   WHERE RPT_DATE BETWEEN BEGIN_DATE AND END_DATE) );
     END IF;
	 IF WEEK = 4 THEN
	 	SELECT MAX(BEGIN_DATE), MAX(END_DATE)
		  INTO F_BEGIN_DATE, F_END_DATE
		  FROM CBS_RPT_PERIODS
		 WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
							   FROM CBS_RPT_PERIODS
							  WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
												    FROM CBS_RPT_PERIODS
												   WHERE BEGIN_DATE < (SELECT BEGIN_DATE
													                     FROM CBS_RPT_PERIODS
													                    WHERE RPT_DATE BETWEEN BEGIN_DATE AND END_DATE) ) );
     END IF;
	 IF WEEK = 5 THEN
	 	SELECT MAX(BEGIN_DATE), MAX(END_DATE)
		  INTO F_BEGIN_DATE, F_END_DATE
		  FROM CBS_RPT_PERIODS
		 WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
							   FROM CBS_RPT_PERIODS
							  WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
												    FROM CBS_RPT_PERIODS
												   WHERE BEGIN_DATE < (SELECT MAX(BEGIN_DATE)
																	     FROM CBS_RPT_PERIODS
																	    WHERE BEGIN_DATE < (SELECT BEGIN_DATE
																		                      FROM CBS_RPT_PERIODS
																		                     WHERE RPT_DATE BETWEEN BEGIN_DATE AND END_DATE) ) ) );
	 END IF;
     IF DATE_TYPE = 'BEGIN' THEN
	    RETURN F_BEGIN_DATE;
	   ELSE
	    RETURN F_END_DATE;
	 END IF;
END;
----------------------------------------------------------------------------------
FUNCTION CYR2LAT_RUB(STRING VARCHAR2) RETURN VARCHAR2
IS
  CH 	 				VARCHAR2(2);
  D_CH 					VARCHAR2(2);
  D_STRING 				VARCHAR2(1000);
BEGIN
	 D_STRING := '';
	 if STRING is not null
	 then
		 FOR I IN 1 .. LENGTH(STRING) LOOP
		 	 CH := SUBSTR(UPPER(STRING), I, 1);
			 SELECT  
			         CASE WHEN CH = 'А' THEN 'A'
					 	  WHEN CH = 'Б' THEN 'B'
						  WHEN CH = 'В' THEN 'V'
						  WHEN CH = 'Г' THEN 'G'
						  WHEN CH = 'Д' THEN 'D'
						  WHEN CH = 'Е' THEN 'E'
						  WHEN CH = 'Ё' THEN 'o'
						  WHEN CH = 'Ж' THEN 'J'
						  WHEN CH = 'З' THEN 'Z'
						  WHEN CH = 'И' THEN 'I'
						  WHEN CH = 'Й' THEN 'i'
						  WHEN CH = 'К' THEN 'K'
						  WHEN CH = 'Л' THEN 'L'
						  WHEN CH = 'М' THEN 'M'
						  WHEN CH = 'Н' THEN 'N'
						  WHEN CH = 'О' THEN 'O'
						  WHEN CH = 'П' THEN 'P'
						  WHEN CH = 'Р' THEN 'R'
						  WHEN CH = 'С' THEN 'S'
						  WHEN CH = 'Т' THEN 'T'
						  WHEN CH = 'У' THEN 'U'
						  WHEN CH = 'Ф' THEN 'F'
						  WHEN CH = 'Х' THEN 'H'
						  WHEN CH = 'Ц' THEN 'C'
						  WHEN CH = 'Ч' THEN 'c'
						  WHEN CH = 'Ш' THEN 'Q'
						  WHEN CH = 'Щ' THEN 'q'
						  WHEN CH = 'Ъ' THEN 'x'
						  WHEN CH = 'Ь' THEN 'X'
						  WHEN CH = 'Ы' THEN 'Y'
						  WHEN CH = 'Э' THEN 'e'
						  WHEN CH = 'Ю' THEN 'u'
						  WHEN CH = 'Я' THEN 'a'
						  ELSE CH
					 END CHR
			 INTO D_CH FROM DUAL;
			 D_STRING := D_STRING || D_CH;
		 END LOOP;
	 END if;
	 RETURN D_STRING;
exception
  when others then
  log_at('hakan_report_error','STRING',STRING);
END;
----------------------------------------------------------------------------------
END PKG_REPORT4;
/

