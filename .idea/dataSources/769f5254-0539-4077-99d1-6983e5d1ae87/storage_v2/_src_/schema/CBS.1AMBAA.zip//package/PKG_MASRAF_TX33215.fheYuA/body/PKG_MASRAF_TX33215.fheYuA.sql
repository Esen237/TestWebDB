create PACKAGE BODY     Pkg_Masraf_Tx33215  IS
/*p_33215_HABR_TRL NUMBER;        		--HABERLE?ME TRL
p_33215_POSTA_TRL NUMBER;        	--POSTA MASRAFI TRL
p_33215_KOM_TOPLAMI NUMBER;        	--TOPLAM TRL MASRAF
p_33215_M_HESAP NUMBER;        		--MASRAF HESAP NO
p_33215_M_HESAP_DVZ NUMBER;          --MASRAF HESAP TRL DE??L
p_33215_MHESAP_SUBE NUMBER;          --MASRAF HESABININ ?UBES?
p_33215_ISLEM_SUBE NUMBER;        	--??LEM YAPILAN ?UBE
p_33215_TEYIT_MDV NUMBER;        	--TEYIT MASRAF HESAP D?V?Z? KARSILI?I
p_33215_IHBAR_MDV NUMBER;        	--?HBAR MASRAF HESAP D?V?Z? KAR?ILI?I
p_33215_HABR_MDV NUMBER;        		--HABERLE?ME MASRAF HESAP D?V?Z? KAR?ILI?I
p_33215_POSTA_MDV NUMBER;       		--POSTA MASRAF HESAP D?V?Z? KAR?ILI?I
p_33215_KOM_MDV_TOPLAM NUMBER;       --TOPLAM MASRAF, MASRAF HESAP D?V?Z? KAR?ILI?I
p_33215_MAS_ACIKLAMA NUMBER;         --ANA F?? A?IKLAMASI
p_33215_MAS_TEY_ACIKLAMA NUMBER;     --TEYIT BOLUM A?IKLAMASI
p_33215_MAS_HABR_ACIKLAMA NUMBER;    --HABR BOLUM A?IKLAMASI
p_33215_MAS_IHBAR_ACIKLAMA NUMBER;   --IHBAR BOLUM A?IKLAMASI
p_33215_MAS_POST_ACIKLAMA NUMBER;    --POSTA BOLUM A?IKLAMASI
p_33215_KUR_TUTAR NUMBER;        	--KUR B?LG?S?
p_33215_TEYIT_VAR NUMBER;        	--TEYIT MASRAFI VAR
p_33215_IHBAR_VAR NUMBER;        	--IHBAR MASRAFI VAR
p_33215_HABR_VAR NUMBER;        		--HABERLE?ME MASRAFI VAR
p_33215_POSTA_VAR NUMBER;        	--POSTA MASRAFI VAR
p_33215_M_HESAP_TRL NUMBER;        	--MASRAF HESAP TRL
p_33215_MHESAP_DVZ NUMBER;        	--MASRAF HESABININ D?V?Z?
p_33215_TEYIT_TRL NUMBER;        	--TEYIT TRL KARSILI?I
p_33215_IHBAR_TRL NUMBER;        	--IHBAR TRL KARSILIK
p_33215_MAS_TP_ANA NUMBER;			--ANA MASRAF HESABI
p_33215_MAS_YP_ANA NUMBER;			--ANA MASRAF HESABI
p_33215_BSMV_TOPLAM NUMBER;			--BSMV TOPLAMI
P_33215_TEYITLI NUMBER;				--AKREDITIF TEYITLI
P_33215_TEYITSIZ NUMBER;			--AKREDITIF TEYITSIZ
P_33215_TP NUMBER;					--AKREDITIF TP
P_33215_YP NUMBER;					--AKREDITIF YP*/

p_33215_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33215_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33215_KUR						  NUMBER;
p_33215_REFERENCE				  NUMBER;
p_33215_ISTA_KOD				  NUMBER;
p_33215_MUS_ACIK				  NUMBER;
p_33215_BANKA_ACIK				  NUMBER;
p_33215_ISLEM_SUBE				  NUMBER;
p_33215_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33215_FC_MASRAF_TUTARI		  NUMBER;
p_33215_LC_MASRAF_TUTAR			  NUMBER;
p_33215_MASRAF_HESAP_SUBE		  NUMBER;
p_33215_MASRAF_HESAP_NO			  NUMBER;
p_33215_LC_MAIL_CHARGE			  NUMBER;
p_33215_LC_COMM_CHARGE			  NUMBER;
p_33215_LC_CONF_COM				  NUMBER;
p_33215_LC_ISSUING_COM			  NUMBER;
p_33215_MAIL_CHARGE_GL			  NUMBER;
p_33215_COMM_CHARGE_GL			  NUMBER;
p_33215_CONF_COM_GL				  NUMBER;
p_33215_ISSUING_COM_GL			  NUMBER;
p_33215_UNCOMFIRM				  NUMBER;
p_33215_COMFIRM					  NUMBER;
p_33215_UNCOVER					  NUMBER;
p_33215_COVER					  NUMBER;
p_33215_FC						  NUMBER;
p_33215_LC						  NUMBER;
p_33215_MAILCOM_VAR				  NUMBER;
p_33215_COMMCOM_VAR				  NUMBER;
p_33215_CONFCOM_VAR				  NUMBER;
p_33215_ISSUINGCOM_VAR			  NUMBER;
p_33215_FC_MASRAF_ANA			  NUMBER;
p_33215_LC_MASRAF_ANA			  NUMBER;

p_33215_LC_PREADVS_CHARGE		  NUMBER;
p_33215_PREADVS_CHARGE_GL	      NUMBER;
p_33215_PREADVS_VAR				  NUMBER;

p_33215_LC_SERVICE_TAX			  NUMBER;
p_33215_FC_SERVICE_TAX			  NUMBER;
p_33215_SERVICE_TAX_VAR			  NUMBER;
p_33215_SERVICE_TAX_GL			  NUMBER;



/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.onay_sonrasi(pn_islem_no, ps_ref, 0, 'A', 'IMPISSUE');
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
   Pkg_Masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
  	NULL;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS		-- Islem iptal edilemez
  BEGIN
   Pkg_Masraf.Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no, ps_ref, 0);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER) IS

   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   lb_vergi_var           BOOLEAN;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_tutar		  NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   ln_top_bsmv 			  NUMBER := 0;
   ln_bsmv				  NUMBER := 0;
   ls_istatistik_kodu     VARCHAR2(2000);
   ls_aciklama			  VARCHAR2(2000);
   ls_1  VARCHAR2(2000);
   ls_2  VARCHAR2(2000);
   ls_3  VARCHAR2(2000);
   ls_4  VARCHAR2(2000);
   ln_1 BOOLEAN;
   ln_dk_grup_no  NUMBER;

   CURSOR cur_masraf IS
    SELECT *
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID'
	   and pkg_ithalat.masraf_kontrol_yap(ODEYECEK) = 'Y'
	 ORDER BY sira_no
	FOR UPDATE;
	row_masraf cur_masraf%ROWTYPE;

    CURSOR c_0 IS
    SELECT COUNT(*)
	  FROM CBS_MASRAF_ITH_IHR_ISL
	 WHERE islem_no = pn_islem_no
	   AND durum = 'VALID'
	   and pkg_ithalat.masraf_kontrol_yap(ODEYECEK) = 'Y';
	 ln_temp NUMBER;

   CURSOR cur_akr IS
     SELECT * FROM CBS_ITH_AKREDITIF_ISLEM
	  WHERE tx_no = pn_islem_no;
	 row_akr cur_akr%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT_ISLEM a
	  WHERE islem_no = pn_islem_no --referans = ls_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
	 FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;
   ls_acik_tutar_ref VARCHAR2(100);
  BEGIN
    ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33215_PREADVS_VAR) := FALSE ;
	boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE ;
	boolean_list(p_33215_FC_MASRAF_ANA) := FALSE ;
	boolean_list(p_33215_LC_MASRAF_ANA) := FALSE ;
    boolean_list(p_33215_SERVICE_TAX_VAR) := FALSE;

	varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) := 'AAA';
	OPEN cur_akr;
	FETCH cur_akr INTO row_akr;
	 ls_akr_doviz := row_akr.doviz_kodu;
	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
    	 varchar_list(p_33215_MASRAF_HESAP_NO) := row_akr.masraf_hesap_no;
	     varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
	     varchar_list(p_33215_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_akr.masraf_hesap_no);

	 END IF;

	 IF varchar_list(p_33215_MASRAF_HESAP_NO) IS NOT NULL THEN
	     ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33215_MASRAF_HESAP_NO)) );
		 varchar_list(p_33215_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPMAILCHR');
		 varchar_list(p_33215_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOMCAT');
		 varchar_list(p_33215_CONF_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCONFCOM');
		 varchar_list(p_33215_ISSUING_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPISSUE');
		 varchar_list(p_33215_PREADVS_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPPREADVS');
         varchar_list(p_33215_SERVICE_TAX_GL) := '';
		 if pkg_musteri.musteri_vergiden_muafmi(row_akr.ithalatci_musteri) = 'H' then
		   lb_vergi_var := TRUE;
		 end if;
	 ELSE
		 varchar_list(p_33215_MAIL_CHARGE_GL) := '';
		 varchar_list(p_33215_PREADVS_CHARGE_GL) := '';
		 varchar_list(p_33215_COMM_CHARGE_GL) := '';
		 varchar_list(p_33215_CONF_COM_GL)	  := '';
		 varchar_list(p_33215_ISSUING_COM_GL) := '';
 		 varchar_list(p_33215_SERVICE_TAX_GL) := '';

	 END IF;

	 varchar_list(p_33215_ISLEM_SUBE) := row_akr.bolum_kodu;
	 ls_referans := row_akr.referans;
	 ls_istatistik_kodu := (TO_CHAR(NVL(row_akr.pre_istatistik_kodu,0)) || NVL(row_akr.istatistik_doviz_kodu,' ') || TO_CHAR(NVL(row_akr.istatistik_kodu,0)));

	 varchar_list(p_33215_REFERENCE) := ls_referans;
	 varchar_list(p_33215_ISTA_KOD)  := ls_istatistik_kodu;

	 IF row_akr.teyit_kodu='TEYITLI' THEN
		boolean_list(p_33215_UNCOMFIRM) := FALSE ;
		boolean_list(p_33215_COMFIRM)	:= TRUE ;
	 ELSE
		boolean_list(p_33215_UNCOMFIRM) := TRUE ;
		boolean_list(p_33215_COMFIRM)	:= FALSE ;
	 END IF;

	 IF row_akr.teminatli_mi='COVERED' THEN
		boolean_list(p_33215_UNCOVER) := FALSE ;
		boolean_list(p_33215_COVER)	:= TRUE ;
	 ELSE
		boolean_list(p_33215_UNCOVER) := TRUE ;
		boolean_list(p_33215_COVER)	:= FALSE ;
	 END IF;

	CLOSE cur_akr;

	ls_acik_tutar_ref := RTRIM(TO_CHAR(row_akr.dosya_tutari,'999G999G999G999G999G999G999D99')) || ls_akr_doviz || '-' || ls_referans;

    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
	 boolean_list(p_33215_LC_MSRF_DOVIZ_KODU) := FALSE;
	 boolean_list(p_33215_FC_MSRF_DOVIZ_KODU) := TRUE ;
	ELSE
	 boolean_list(p_33215_LC_MSRF_DOVIZ_KODU) := TRUE;
	 boolean_list(p_33215_FC_MSRF_DOVIZ_KODU) := FALSE;
	END IF;

	number_list(p_33215_LC_COMM_CHARGE) := 0;

	number_list(p_33215_LC_MAIL_CHARGE) := 0;

	number_list(p_33215_LC_CONF_COM) := 0;

	number_list(p_33215_LC_ISSUING_COM) := 0;

	number_list(p_33215_LC_MASRAF_TUTAR)  := 0;
	number_list(p_33215_FC_MASRAF_TUTARI) := 0;
    number_list(p_33215_LC_SERVICE_TAX)   := 0;
    number_list(p_33215_FC_SERVICE_TAX)   := 0;

	ls_aciklama := ls_referans || ' -  ' || row_akr.ithalatci_musteri || ' -  ' ||
				   Pkg_Musteri.sf_musteri_adi(row_akr.ithalatci_musteri) || ' -  ' ||
				   ' L/C Opening' ;
	varchar_list(p_33215_BANKA_ACIK) := ls_aciklama;
	varchar_list(p_33215_MUS_ACIK) :=varchar_list(p_33215_BANKA_ACIK) ;

    IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
	  boolean_list(p_33215_LC) := TRUE;
      boolean_list(p_33215_FC) := FALSE;
	ELSE
	  boolean_list(p_33215_LC) := FALSE;
      boolean_list(p_33215_FC) := TRUE;
	END IF;

	IF row_akr.masraf_hesap_no IS NOT NULL THEN  --masraf hesabi girilmisse
		number_list(p_33215_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),1);
		--masraf alinacak hesabin bakiyesini al
		ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33215_MASRAF_HESAP_NO));
    END IF;

	OPEN cur_masraf;
	LOOP
	  FETCH cur_masraf INTO row_masraf;
	  EXIT WHEN cur_masraf%NOTFOUND;
	  ln_bsmv := 0;

	  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
		  IF Pkg_Ithalat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y' THEN
		      ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
			  IF row_masraf.masraf_kodu = 'IMPCOMCAT'  THEN   --haberlesme
			  	boolean_list(p_33215_COMMCOM_VAR) := TRUE ;
			  --masraflar akreditif kurunda, onlari masraf hesabinin kuruna cevirmek gerekli......
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_COMM_CHARGE);
				END IF;
			  --bu iki degisken ile hesabin odemeyi alabilmek icin yeterli olup olmadigi arastirilacak
			  --eger yeterli miktar varsa, toplam satir icin toplanacak
				ln_borc_tutar := number_list(p_33215_LC_COMM_CHARGE);--number_list(p_33215_HABR_MDV);
				ln_borc_trl := number_list(p_33215_LC_COMM_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPMAILCHR' THEN   --posta
			  	boolean_list(p_33215_MAILCOM_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_MAIL_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_MAIL_CHARGE);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_MAIL_CHARGE);--number_list(p_33215_POSTA_MDV);
				ln_borc_trl := number_list(p_33215_LC_MAIL_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPPREADVS' THEN   --posta
			  	boolean_list(p_33215_PREADVS_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_PREADVS_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_PREADVS_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_PREADVS_CHARGE);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_PREADVS_CHARGE);
				ln_borc_trl := number_list(p_33215_LC_PREADVS_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPCONFCOM' THEN   --Teyit
			  	boolean_list(p_33215_CONFCOM_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_CONF_COM) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_CONF_COM);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_CONF_COM);--number_list(p_33215_POSTA_MDV);
				ln_borc_trl := number_list(p_33215_LC_CONF_COM);
			  ELSIF row_masraf.masraf_kodu =  'IMPISSUE' THEN  --
			    boolean_list(p_33215_ISSUINGCOM_VAR) := TRUE ;
			    ln_eski_tahsil_tutar := NVL(row_masraf.tahsil_toplam,0);
				IF NVL(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
				   --daha fazlas? veya ayn?s? ?nceden al?nm??
				   --hi? bir ?ey yapma
				   ln_tahsil_tutar := 0;
				ELSE
					  lb_taksit_var := TRUE;
					  OPEN cur_taksitler;
					  LOOP
					    FETCH cur_taksitler INTO row_taksit;
						EXIT WHEN cur_taksitler%NOTFOUND;
						ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
--					    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
						   number_list(p_33215_LC_ISSUING_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--						ELSE
--						   number_list(p_33215_LC_ISSUING_COM) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--						END IF;

				        IF NVL(row_taksit.bsmv,0) > 0 THEN
						   ln_bsmv := number_list(p_33215_LC_ISSUING_COM);
						END IF;

						ln_borc_tutar := number_list(p_33215_LC_ISSUING_COM);--number_list(p_33215_TEYIT_MDV);
						ln_borc_trl := number_list(p_33215_LC_ISSUING_COM);
						IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN
						    boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
							boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
							boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
							boolean_list(p_33215_PREADVS_VAR) := FALSE ;

						    ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no, varchar_list, number_list,
										    			  	  date_list, boolean_list, NULL, FALSE, ln_fis_no, NULL);

							--pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                            --                             row_masraf.masraf_kodu, (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)), row_masraf.vs_no);

						    UPDATE CBS_MASRAF_ITH_IHR_ISL
							   SET tahsil_toplam = NVL(tahsil_toplam,0) + (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0)),
							       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0))
						     WHERE CURRENT OF cur_masraf;

  					  		Pkg_Masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

							UPDATE CBS_MASRAF_TAKSIT_ISLEM
							   SET taksit_odeme_tarih = Pkg_Muhasebe.banka_tarihi_bul,
							       odenen_tutar = taksit_tutari
							 WHERE CURRENT OF cur_taksitler;
							  Pkg_Masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33215_LC_ISSUING_COM), row_akr.masraf_hesap_no,
																   row_akr.AKREDITIF_VADESI, 'E');


							ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
							number_list(p_33215_LC_MASRAF_TUTAR) := number_list(p_33215_LC_MASRAF_TUTAR) + ln_borc_trl;
							number_list(p_33215_FC_MASRAF_TUTARI) := number_list(p_33215_FC_MASRAF_TUTARI) + ln_borc_tutar;
							ln_top_bsmv := ln_top_bsmv + ln_bsmv;
			            ELSE
						 CLOSE cur_taksitler;
						 CLOSE cur_masraf;
				        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_33215_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
						END IF;
					  END LOOP;
					  CLOSE cur_taksitler;
				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;
			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN --bakiye yeterliyse satiri ekle
			     IF ln_tahsil_tutar <> 0 THEN

			         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_33215_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_ISSUINGCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_PREADVS_VAR) = TRUE THEN
					  	 boolean_list(p_33215_PREADVS_VAR) := FALSE;
					  END IF;
					  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      UPDATE CBS_MASRAF_ITH_IHR_ISL
					     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       WHERE CURRENT OF cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
					  number_list(p_33215_LC_MASRAF_TUTAR) := number_list(p_33215_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33215_FC_MASRAF_TUTARI) := number_list(p_33215_FC_MASRAF_TUTARI) + ln_borc_tutar;
					  ln_top_bsmv := ln_top_bsmv + ln_bsmv;
				END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_33215_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;
	boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33215_PREADVS_VAR) := FALSE ;
	boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE ;

    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (nvl(number_list(p_33215_LC_COMM_CHARGE),0) + nvl(number_list(p_33215_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	if lb_vergi_var and ln_tax_amount != 0 then
	  number_list(p_33215_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33215_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),1);
      boolean_list(p_33215_SERVICE_TAX_VAR) := TRUE;
	else
	  boolean_list(p_33215_SERVICE_TAX_VAR) := FALSE;
	end if;


	IF number_list(p_33215_FC_MASRAF_TUTARI) > 0 THEN

	   number_list(p_33215_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33215_LC_MASRAF_TUTAR)) ;
	   number_list(p_33215_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33215_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33215_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33215_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33215_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33215_LC_MASRAF_ANA) := TRUE ;

		END IF;

       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no,
			    					  	 varchar_list, number_list,
										 date_list, boolean_list,
							    	  	 NULL, FALSE, ln_fis_no, NULL);
	END IF;
	pn_fis_no := ln_fis_no;
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
   BEGIN
    NULL;
   END;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebe_Sonrasi(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
  BEGIN
    Pkg_Masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, NULL);
  END;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE EOD_Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER, ps_referans VARCHAR2, pn_vs_no NUMBER, ps_masraf_kodu VARCHAR2) IS

   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   lb_vergi_var           BOOLEAN;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_tutar		  NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ln_top_bsmv 			  NUMBER := 0;
   ln_bsmv				  NUMBER := 0;
   ls_istatistik_kodu     VARCHAR2(2000);
   ls_aciklama			  VARCHAR2(2000);
   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   ls_1  VARCHAR2(2000);
   ls_2  VARCHAR2(2000);
   ls_3  VARCHAR2(2000);
   ls_4  VARCHAR2(2000);
   ln_1 BOOLEAN;
   ln_dk_grup_no		NUMBER;

   CURSOR cur_masraf IS
    SELECT *
	  FROM CBS_MASRAF_ITH_IHR
	 WHERE referans = ps_referans
	   AND durum = 'VALID'
	   AND masraf_kodu = ps_masraf_kodu
	 ORDER BY sira_no
	FOR UPDATE;
	row_masraf cur_masraf%ROWTYPE;

    CURSOR c_0 IS
    SELECT COUNT(*)
	  FROM CBS_MASRAF_ITH_IHR
	 WHERE referans = ps_referans
	   AND durum = 'VALID'
	   AND masraf_kodu = ps_masraf_kodu;
	 ln_temp NUMBER;

   CURSOR cur_akr IS
     SELECT * FROM CBS_ITH_AKREDITIF
	  WHERE referans = ps_referans;
	 row_akr cur_akr%ROWTYPE;

   CURSOR cur_taksitler IS
     SELECT * FROM CBS_MASRAF_TAKSIT a
	  WHERE referans = ls_referans
	    AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul
	    AND NVL(odenen_tutar,0) < taksit_tutari
		AND masraf_kodu = ps_masraf_kodu
	 FOR UPDATE;
   row_taksit cur_taksitler%ROWTYPE;
   ls_acik_tutar_ref VARCHAR2(100);
  BEGIN
    ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33215_PREADVS_VAR) := FALSE ;
	boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE ;
	boolean_list(p_33215_FC_MASRAF_ANA) := FALSE ;
	boolean_list(p_33215_LC_MASRAF_ANA) := FALSE ;
    boolean_list(p_33215_SERVICE_TAX_VAR) := FALSE;

	varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) := 'AAA';
	OPEN cur_akr;
	FETCH cur_akr INTO row_akr;
	 ls_akr_doviz := row_akr.doviz_kodu;
	 IF row_akr.masraf_hesap_no IS NOT NULL THEN
    	 varchar_list(p_33215_MASRAF_HESAP_NO) := row_akr.masraf_hesap_no;
	     varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_akr.masraf_hesap_no);
	     varchar_list(p_33215_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_akr.masraf_hesap_no);

	 END IF;
	 varchar_list(p_33215_ISLEM_SUBE) := row_akr.bolum_kodu;
	 ls_referans := row_akr.referans;
	 ls_istatistik_kodu := (TO_CHAR(NVL(row_akr.pre_istatistik_kodu,0)) || NVL(row_akr.istatistik_doviz_kodu,' ') || TO_CHAR(NVL(row_akr.istatistik_kodu,0)));

	 IF varchar_list(p_33215_MASRAF_HESAP_NO) IS NOT NULL THEN
	     ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33215_MASRAF_HESAP_NO)) );
		 varchar_list(p_33215_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPMAILCHR');
		 varchar_list(p_33215_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOMCAT');
		 varchar_list(p_33215_CONF_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCONFCOM');
		 varchar_list(p_33215_ISSUING_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPISSUE');
		 varchar_list(p_33215_PREADVS_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPPREADVS');
         varchar_list(p_33215_SERVICE_TAX_GL) := '';
		 if pkg_musteri.musteri_vergiden_muafmi(row_akr.ithalatci_musteri) = 'H' then
		   lb_vergi_var := TRUE;
		 end if;
	 ELSE
		 varchar_list(p_33215_MAIL_CHARGE_GL) := '';
		 varchar_list(p_33215_COMM_CHARGE_GL) := '';
		 varchar_list(p_33215_CONF_COM_GL)	  := '';
		 varchar_list(p_33215_ISSUING_COM_GL) := '';
		 varchar_list(p_33215_PREADVS_CHARGE_GL) := '';
		 varchar_list(p_33215_SERVICE_TAX_GL) := '';
	 END IF;



	 varchar_list(p_33215_REFERENCE) := ls_referans;
	 varchar_list(p_33215_ISTA_KOD)  := ls_istatistik_kodu;

	 IF row_akr.teyit_kodu='TEYITLI' THEN
		boolean_list(p_33215_UNCOMFIRM) := FALSE ;
		boolean_list(p_33215_COMFIRM)	:= TRUE ;
	 ELSE
		boolean_list(p_33215_UNCOMFIRM) := TRUE ;
		boolean_list(p_33215_COMFIRM)	:= FALSE ;
	 END IF;

	 IF row_akr.teminatli_mi='COVERED' THEN
		boolean_list(p_33215_UNCOVER) := FALSE ;
		boolean_list(p_33215_COVER)	:= TRUE ;
	 ELSE
		boolean_list(p_33215_UNCOVER) := TRUE ;
		boolean_list(p_33215_COVER)	:= FALSE ;
	 END IF;

	CLOSE cur_akr;

	ls_acik_tutar_ref := RTRIM(TO_CHAR(row_akr.dosya_tutari,'999G999G999G999G999G999G999D99')) || ls_akr_doviz || '-' || ls_referans;

    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
	 boolean_list(p_33215_LC_MSRF_DOVIZ_KODU) := FALSE;
	 boolean_list(p_33215_FC_MSRF_DOVIZ_KODU) := TRUE ;
	ELSE
	 boolean_list(p_33215_LC_MSRF_DOVIZ_KODU) := TRUE;
	 boolean_list(p_33215_FC_MSRF_DOVIZ_KODU) := FALSE;
	END IF;

	number_list(p_33215_LC_COMM_CHARGE) := 0;

	number_list(p_33215_LC_MAIL_CHARGE) := 0;

	number_list(p_33215_LC_CONF_COM) := 0;

	number_list(p_33215_LC_ISSUING_COM) := 0;

	number_list(p_33215_LC_MASRAF_TUTAR) := 0;
	number_list(p_33215_FC_MASRAF_TUTARI) := 0;
    number_list(p_33215_LC_SERVICE_TAX)   := 0;
    number_list(p_33215_FC_SERVICE_TAX)   := 0;

	ls_aciklama := ls_referans || ' -  ' || row_akr.ithalatci_musteri || ' -  ' ||
				   Pkg_Musteri.sf_musteri_adi(row_akr.ithalatci_musteri) || ' -  ' ||
				   ' L/C Opening' ;
	varchar_list(p_33215_BANKA_ACIK) := ls_aciklama;
	varchar_list(p_33215_MUS_ACIK) :=varchar_list(p_33215_BANKA_ACIK) ;

    IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
	  boolean_list(p_33215_LC) := TRUE;
      boolean_list(p_33215_FC) := FALSE;
	ELSE
	  boolean_list(p_33215_LC) := FALSE;
      boolean_list(p_33215_FC) := TRUE;
	END IF;

	IF row_akr.masraf_hesap_no IS NOT NULL THEN  --masraf hesabi girilmisse
		number_list(p_33215_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),1);
		--masraf alinacak hesabin bakiyesini al
		ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33215_MASRAF_HESAP_NO));
    END IF;

	OPEN cur_masraf;
	LOOP
	  FETCH cur_masraf INTO row_masraf;
	  EXIT WHEN cur_masraf%NOTFOUND;
	  ln_bsmv := 0;

	  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
		  IF Pkg_Ithalat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y' THEN
		      ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
			  IF row_masraf.masraf_kodu = 'IMPCOMCAT'  THEN   --haberlesme
			  	boolean_list(p_33215_COMMCOM_VAR) := TRUE ;
			  --masraflar akreditif kurunda, onlari masraf hesabinin kuruna cevirmek gerekli......
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;


				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_COMM_CHARGE);
				END IF;
			  --bu iki degisken ile hesabin odemeyi alabilmek icin yeterli olup olmadigi arastirilacak
			  --eger yeterli miktar varsa, toplam satir icin toplanacak
				ln_borc_tutar := number_list(p_33215_LC_COMM_CHARGE);--number_list(p_33215_HABR_MDV);
				ln_borc_trl := number_list(p_33215_LC_COMM_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPMAILCHR' THEN   --posta
			  	boolean_list(p_33215_MAILCOM_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_MAIL_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_MAIL_CHARGE);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_MAIL_CHARGE);--number_list(p_33215_POSTA_MDV);
				ln_borc_trl := number_list(p_33215_LC_MAIL_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPPREADVS' THEN   --posta
			  	boolean_list(p_33215_PREADVS_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_PREADVS_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_PREADVS_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;

				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_PREADVS_CHARGE);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_PREADVS_CHARGE);--number_list(p_33215_POSTA_MDV);
				ln_borc_trl := number_list(p_33215_LC_PREADVS_CHARGE);

			  ELSIF row_masraf.masraf_kodu = 'IMPCONFCOM' THEN   --Teyit
			  	boolean_list(p_33215_CONFCOM_VAR) := TRUE ;
--			    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
				   number_list(p_33215_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--				ELSE
--				   number_list(p_33215_LC_CONF_COM) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--				END IF;


				IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33215_LC_CONF_COM);
				END IF;
				ln_borc_tutar := number_list(p_33215_LC_CONF_COM);--number_list(p_33215_POSTA_MDV);
				ln_borc_trl := number_list(p_33215_LC_CONF_COM);
			  ELSIF row_masraf.masraf_kodu =  'IMPISSUE' THEN  --
			    boolean_list(p_33215_ISSUINGCOM_VAR) := TRUE ;
			    ln_eski_tahsil_tutar := NVL(row_masraf.tahsil_toplam,0);
				IF NVL(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
				   --daha fazlas? veya ayn?s? ?nceden al?nm??
				   --hi? bir ?ey yapma
				   ln_tahsil_tutar := 0;
				ELSE
					  lb_taksit_var := TRUE;
					  OPEN cur_taksitler;
					  LOOP
					    FETCH cur_taksitler INTO row_taksit;
						EXIT WHEN cur_taksitler%NOTFOUND;
						ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
--					    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
						   number_list(p_33215_LC_ISSUING_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));
--						ELSE
--						   number_list(p_33215_LC_ISSUING_COM) := Pkg_Komisyon_Kur.KUR_to_LC(row_masraf.DVZ, ln_tahsil_tutar);
--						END IF;

				        IF NVL(row_taksit.bsmv,0) > 0 THEN
						   ln_bsmv := number_list(p_33215_LC_ISSUING_COM);
						END IF;

						ln_borc_tutar := number_list(p_33215_LC_ISSUING_COM);--number_list(p_33215_TEYIT_MDV);
						ln_borc_trl := number_list(p_33215_LC_ISSUING_COM);
						IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN
						    boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
							boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
							boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
							boolean_list(p_33215_PREADVS_VAR) := FALSE ;


						    ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no, varchar_list, number_list,
										    			  	  date_list, boolean_list, NULL, FALSE, ln_fis_no, NULL);

							--pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                            --                             row_masraf.masraf_kodu, (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)), row_masraf.vs_no);

						    UPDATE CBS_MASRAF_ITH_IHR
							   SET tahsil_toplam = NVL(tahsil_toplam,0) + (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0)),
							       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0))
						     WHERE CURRENT OF cur_masraf;

  					  		Pkg_Masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

							UPDATE CBS_MASRAF_TAKSIT
							   SET taksit_odeme_tarih = Pkg_Muhasebe.banka_tarihi_bul,
							       odenen_tutar = taksit_tutari
							 WHERE CURRENT OF cur_taksitler;
							  Pkg_Masraf.gecici_gercek_icin_kaydet_eod(pn_islem_no, row_masraf.sira_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33215_LC_ISSUING_COM), row_akr.masraf_hesap_no,
																   row_akr.AKREDITIF_VADESI, 'E', row_akr.bolum_kodu);

							ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
							number_list(p_33215_LC_MASRAF_TUTAR) := number_list(p_33215_LC_MASRAF_TUTAR) + ln_borc_trl;
							number_list(p_33215_FC_MASRAF_TUTARI) := number_list(p_33215_FC_MASRAF_TUTARI) + ln_borc_tutar;
							ln_top_bsmv := ln_top_bsmv + ln_bsmv;
			            ELSE
						 CLOSE cur_taksitler;
						 CLOSE cur_masraf;
				        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_33215_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
						END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;
			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN --bakiye yeterliyse satiri ekle
			     IF ln_tahsil_tutar <> 0 THEN

			         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_33215_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_ISSUINGCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33215_PREADVS_VAR) = TRUE THEN
					  	 boolean_list(p_33215_PREADVS_VAR) := FALSE;
					  END IF;
					  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      UPDATE CBS_MASRAF_ITH_IHR
					     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       WHERE CURRENT OF cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
					  number_list(p_33215_LC_MASRAF_TUTAR) := number_list(p_33215_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33215_FC_MASRAF_TUTARI) := number_list(p_33215_FC_MASRAF_TUTARI) + ln_borc_tutar;
					  ln_top_bsmv := ln_top_bsmv + ln_bsmv;
				END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_33215_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;
	boolean_list(p_33215_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33215_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33215_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33215_ISSUINGCOM_VAR) := FALSE ;
	boolean_list(p_33215_PREADVS_VAR) := FALSE ;

    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (nvl(number_list(p_33215_LC_COMM_CHARGE),0) + nvl(number_list(p_33215_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	if lb_vergi_var and ln_tax_amount != 0 then
	  number_list(p_33215_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33215_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),1);
  	  boolean_list(p_33215_SERVICE_TAX_VAR) := TRUE;
	else
	  boolean_list(p_33215_SERVICE_TAX_VAR) := FALSE;
	end if;

	IF number_list(p_33215_FC_MASRAF_TUTARI) > 0 THEN

	   number_list(p_33215_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33215_LC_MASRAF_TUTAR)) ;
	   number_list(p_33215_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33215_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33215_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33215_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33215_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33215_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33215_LC_MASRAF_ANA) := TRUE ;

		END IF;

       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33215, NULL, pn_islem_no,
			    					  	 varchar_list, number_list,
										 date_list, boolean_list,
							    	  	 NULL, FALSE, ln_fis_no, NULL);
	END IF;
	pn_fis_no := ln_fis_no;

  END;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
	/*p_33215_HABR_TRL := Pkg_Muhasebe.parametre_index_bul('33215_HABR_TRL');
	p_33215_POSTA_TRL := Pkg_Muhasebe.parametre_index_bul('33215_POSTA_TRL');
	p_33215_KOM_TOPLAMI := Pkg_Muhasebe.parametre_index_bul('33215_KOM_TOPLAMI');
	p_33215_M_HESAP := Pkg_Muhasebe.parametre_index_bul('33215_M_HESAP');
	p_33215_M_HESAP_DVZ := Pkg_Muhasebe.parametre_index_bul('33215_M_HESAP_DVZ');
	p_33215_MHESAP_SUBE := Pkg_Muhasebe.parametre_index_bul('33215_MHESAP_SUBE');
	p_33215_ISLEM_SUBE := Pkg_Muhasebe.parametre_index_bul('33215_ISLEM_SUBE');
	p_33215_TEYIT_MDV := Pkg_Muhasebe.parametre_index_bul('33215_TEYIT_MDV');
	p_33215_IHBAR_MDV := Pkg_Muhasebe.parametre_index_bul('33215_IHBAR_MDV');
	p_33215_HABR_MDV := Pkg_Muhasebe.parametre_index_bul('33215_HABR_MDV');
	p_33215_POSTA_MDV := Pkg_Muhasebe.parametre_index_bul('33215_POSTA_MDV');
	p_33215_KOM_MDV_TOPLAM := Pkg_Muhasebe.parametre_index_bul('33215_KOM_MDV_TOPLAM');
	p_33215_MAS_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_ACIKLAMA');
	p_33215_MAS_TEY_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_TEY_ACIKLAMA');
	p_33215_MAS_HABR_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_HABR_ACIKLAMA');
	p_33215_MAS_IHBAR_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_IHBAR_ACIKLAMA');
	p_33215_MAS_POST_ACIKLAMA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_POST_ACIKLAMA');
	p_33215_KUR_TUTAR := Pkg_Muhasebe.parametre_index_bul('33215_KUR_TUTAR');
	p_33215_TEYIT_VAR := Pkg_Muhasebe.parametre_index_bul('33215_TEYIT_VAR');
	p_33215_IHBAR_VAR := Pkg_Muhasebe.parametre_index_bul('33215_IHBAR_VAR');
	p_33215_HABR_VAR := Pkg_Muhasebe.parametre_index_bul('33215_HABR_VAR');
	p_33215_POSTA_VAR := Pkg_Muhasebe.parametre_index_bul('33215_POSTA_VAR');
	p_33215_M_HESAP_TRL := Pkg_Muhasebe.parametre_index_bul('33215_M_HESAP_TRL');
	p_33215_MASRAF_HESAP_DOVIZKODU := Pkg_Muhasebe.parametre_index_bul('33215_MHESAP_DVZ');
	p_33215_TEYIT_TRL := Pkg_Muhasebe.parametre_index_bul('33215_TEYIT_TRL');
	p_33215_IHBAR_TRL := Pkg_Muhasebe.parametre_index_bul('33215_IHBAR_TRL');
	p_33215_MAS_TP_ANA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_TP_ANA');
	p_33215_MAS_YP_ANA := Pkg_Muhasebe.parametre_index_bul('33215_MAS_YP_ANA');
	p_33215_BSMV_TOPLAM := Pkg_Muhasebe.parametre_index_bul('33215_BSMV_TOPLAM');
    p_33215_TEYITLI := Pkg_Muhasebe.parametre_index_bul('33215_TEYITLI');
    p_33215_TEYITSIZ := Pkg_Muhasebe.parametre_index_bul('33215_TEYITSIZ');
    p_33215_TP := Pkg_Muhasebe.parametre_index_bul('33215_TP');
    p_33215_YP := Pkg_Muhasebe.parametre_index_bul('33215_YP');*/


	p_33215_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33215_FC_MSRF_DOVIZ_KODU');
	p_33215_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33215_LC_MSRF_DOVIZ_KODU');
	p_33215_KUR						  := Pkg_Muhasebe.parametre_index_bul('33215_KUR');
	p_33215_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33215_REFERENCE');
	p_33215_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33215_ISTA_KOD');
	p_33215_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33215_MUS_ACIK');
	p_33215_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33215_BANKA_ACIK');
	p_33215_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33215_ISLEM_SUBE');
	p_33215_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33215_MASRAF_HESAP_DOVIZ_KODU');
	p_33215_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33215_FC_MASRAF_TUTARI');
	p_33215_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_MASRAF_TUTAR');
	p_33215_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33215_MASRAF_HESAP_SUBE');
	p_33215_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33215_MASRAF_HESAP_NO');
	p_33215_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_MAIL_CHARGE');
	p_33215_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_COMM_CHARGE');
	p_33215_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33215_LC_CONF_COM');
	p_33215_LC_ISSUING_COM			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_ISSUING_COM');
	p_33215_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33215_MAIL_CHARGE_GL');
	p_33215_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33215_COMM_CHARGE_GL');
	p_33215_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33215_CONF_COM_GL');
	p_33215_ISSUING_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33215_ISSUING_COM_GL');
	p_33215_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33215_UNCOMFIRM');
	p_33215_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33215_COMFIRM');
	p_33215_UNCOVER					  := Pkg_Muhasebe.parametre_index_bul('33215_UNCOVER');
	p_33215_COVER					  := Pkg_Muhasebe.parametre_index_bul('33215_COVER');
	p_33215_FC						  := Pkg_Muhasebe.parametre_index_bul('33215_FC');
	p_33215_LC						  := Pkg_Muhasebe.parametre_index_bul('33215_LC');
	p_33215_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33215_MAILCOM_VAR');
	p_33215_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33215_COMMCOM_VAR');
	p_33215_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33215_CONFCOM_VAR');
	p_33215_ISSUINGCOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33215_ISSUINGCOM_VAR');
	p_33215_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33215_FC_MASRAF_ANA');
	p_33215_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_MASRAF_ANA');

	p_33215_LC_PREADVS_CHARGE		  := Pkg_Muhasebe.parametre_index_bul('33215_LC_PREADVS_CHARGE');
	p_33215_PREADVS_CHARGE_GL	      := Pkg_Muhasebe.parametre_index_bul('33215_PREADVS_CHARGE_GL');
	p_33215_PREADVS_VAR				  := Pkg_Muhasebe.parametre_index_bul('33215_PREADVS_VAR');

	p_33215_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33215_LC_SERVICE_TAX');
	p_33215_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33215_FC_SERVICE_TAX');
	p_33215_SERVICE_TAX_VAR			  := Pkg_Muhasebe.parametre_index_bul('33215_SERVICE_TAX_VAR');
	p_33215_SERVICE_TAX_GL			  := Pkg_Muhasebe.parametre_index_bul('33215_SERVICE_TAX_GL');

 END;
/

