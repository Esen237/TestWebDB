create PACKAGE     Pkg_Tutar IS
  -- General package to turn a number into a string
  -- ..ie..71 - Seventy One
  -- Savas Sasmaz
  -- 23-08-2000
  FUNCTION CC_al RETURN VARCHAR2 ;
  FUNCTION TUTAR_YUZ(p_tutar NUMBER,p_doviz_kod VARCHAR2) RETURN VARCHAR2;
  -- Returns a string for 3 digits... should be called recursively
  -- YAZI_TUTAR tarafindan cagrilir
  -- Negatif degerler basarisiz

  FUNCTION YAZI_TUTAR(p_tutar NUMBER,p_doviz_kod VARCHAR2) RETURN VARCHAR2;
  -- Returns a string for p_tutar in p_doviz_kod
  -- For TRL and ROL currencies
  -- Recursively calls TUTAR_YUZ

  FUNCTION num2words (number_in IN NUMBER) RETURN VARCHAR2;
  -- For USD values

  FUNCTION num2words_rol(p_tutar NUMBER) RETURN VARCHAR2;
  -- For ROL values
  FUNCTION Number2Words(p_tutar NUMBER,p_doviz_kod VARCHAR2,p_dil_kodu VARCHAR2) RETURN VARCHAR2;
    FUNCTION f_get_token(ps_sourcetext IN OUT VARCHAR2, ps_separator VARCHAR2) RETURN VARCHAR2;
    Function Rounding(amount number) return number; -- CQ516 Roundings KonstantinJ 28052014
--  pragma restrict_references (TUTAR_YUZ, wnds, wnps);
--  pragma restrict_references (YAZI_TUTAR, wnds, wnps);
--  pragma restrict_references (num2words, wnds, wnps);

END;
/

