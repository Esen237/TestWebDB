create PACKAGE BODY pkg_tim IS

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
  	   null;
  End;

END;
/

