create PACKAGE     Pkg_Muhasebe IS

/*

Programmer        :
Creation Date     :
Purpose           :
Explanation       : Core Accounting Engine

Parameters        :

*/
	-- TX'ler tarafindan kullanilacak yapilar

  TYPE varchar_array IS TABLE OF VARCHAR2(2000) INDEX BY BINARY_INTEGER;
  TYPE number_array  IS TABLE OF NUMBER         INDEX BY BINARY_INTEGER;
  TYPE date_array    IS TABLE OF DATE           INDEX BY BINARY_INTEGER;
  TYPE boolean_array IS TABLE OF BOOLEAN        INDEX BY BINARY_INTEGER;


	-- Yardimci servisler

	FUNCTION Parametre_Index_Bul(p_kod VARCHAR2) RETURN NUMBER;
	FUNCTION Banka_Tarihi_Bul RETURN DATE;
	FUNCTION Onceki_Banka_Tarihi_Bul RETURN DATE;
	FUNCTION Sonraki_Banka_Tarihi_Bul RETURN DATE;
	FUNCTION Fis_Numara_Getir RETURN NUMBER;
	FUNCTION Fis_No_Bul(pn_fis_numara NUMBER) RETURN NUMBER;
	FUNCTION Fis_No_Getir(p_bolum_kodu VARCHAR2,p_kullanici_kodu VARCHAR2,p_tarih DATE,p_flag_sube_bazinda BOOLEAN DEFAULT TRUE) RETURN NUMBER;

  -- Ana servisler

  FUNCTION fis_kes ( p_islem_tanim_kod      NUMBER,
  									 pmuhasebe_no           IN NUMBER DEFAULT NULL,
  									 pislem_no              IN NUMBER ,
  									 varchar_list           IN OUT varchar_array,
  									 number_list            IN OUT number_array,
  									 date_list              IN OUT date_array,
  									 boolean_list           IN OUT boolean_array,
  									 p_gecerli_oldugu_tarih DATE DEFAULT NULL,
  									 balans_kontrol 		    BOOLEAN DEFAULT TRUE,
  									 p_fis_numara           IN NUMBER DEFAULT 0,
  									 p_aciklama             IN VARCHAR2 DEFAULT NULL,
									 p_iptal_edilebilir		IN VARCHAR2 DEFAULT 'E'
  								 ) RETURN NUMBER ;

	-- Return Code
	-- >0   : Fis Numarasi
	-- <0   : Hata Numarasi

  FUNCTION satir_ekle ( p_islem_tanim_kod      NUMBER,
      									pmuhasebe_no           IN NUMBER ,
      									fis_numara             IN NUMBER ,
      									varchar_list           IN OUT varchar_array,
      									number_list            IN OUT number_array,
      									date_list              IN OUT date_array,
      									boolean_list           IN OUT boolean_array,
      									p_gecerli_oldugu_tarih DATE DEFAULT NULL,
      									balans_kontrol BOOLEAN DEFAULT TRUE
      								) RETURN NUMBER ;


  PROCEDURE muhasebelestir ( pfis_no NUMBER,
                            p_tarih DATE  DEFAULT NULL);


  FUNCTION prepare_rpt_parameter
          ( p_islem_tanim_kod 		IN NUMBER,
  					pmuhasebe_no          IN NUMBER ,
  					pislem_no 	          IN NUMBER ,
  					varchar_list          IN varchar_array,
  					number_list           IN number_array,
  					date_list             IN date_array,
  					boolean_list          IN boolean_array
  				) RETURN NUMBER ;

	-- Return Code
	-- >0			: Form basariyla hazirlandi
	-- <0			: Hata numarasi

  FUNCTION prepare_notification (  p_islem_tanim_kod IN NUMBER,
                									 pmuhasebe_no      IN NUMBER ,
                									 pislem_no         IN NUMBER ,
                									 varchar_list      IN varchar_array,
                									 number_list       IN number_array,
                									 date_list         IN date_array,
                									 boolean_list      IN boolean_array
                									) RETURN NUMBER ;


	-- Return Code
	-- 1			: Uyari basariyla hazirlandi
	-- <0			: Hata numarasi

  PROCEDURE fis_iptal( p_fis_numara    CBS_FIS.numara%TYPE ,p_banka_tarihi  DATE DEFAULT NULL );

  FUNCTION Ters_fis_yarat(pn_islem_numara NUMBER,p_fis_numara CBS_FIS.numara%TYPE,p_banka_tarihi DATE DEFAULT NULL) RETURN NUMBER;

  PROCEDURE Gecici_Fis_iptal(p_fis_numara CBS_FIS.numara%TYPE);

   -- Cancels all accounting groups belonging to given tx
  FUNCTION  fis_tx_iptal ( pn_tx_no IN NUMBER, pb_banking_date IN DATE ) RETURN NUMBER ;

  FUNCTION Efektif_Tarih_Duzelt(pfis_numara NUMBER,pefektif_banka_tarih DATE ) RETURN NUMBER;

  PROCEDURE dk_bul        ( pn_gl_group_code     IN NUMBER
                           ,ps_modul_tur_kod     IN VARCHAR2
                           ,ps_urun_tur_kod      IN VARCHAR2
                           ,ps_urun_sinif_kod    IN VARCHAR2
                           ,pn_gl_index          IN NUMBER
						   ,pb_kosul_1			 IN BOOLEAN
						   ,pb_kosul_2			 IN BOOLEAN
						   ,pb_kosul_3		     IN BOOLEAN
                           ,ps_gl_code           OUT VARCHAR2
						   ,pb_kosul_4			 IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_5			 IN BOOLEAN	DEFAULT NULL
						   ,pb_kosul_6		     IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_7			 IN BOOLEAN	DEFAULT NULL
						   ,pb_kosul_8			 IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_9		     IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_10		     IN BOOLEAN DEFAULT NULL
  						   ,pn_islem_tanim_kod	 IN NUMBER DEFAULT 0
						   ,pb_kosul_11			 IN BOOLEAN	DEFAULT NULL
						   ,pb_kosul_12		     IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_13			 IN BOOLEAN	DEFAULT NULL
						   ,pb_kosul_14			 IN BOOLEAN DEFAULT NULL
						   ,pb_kosul_15		     IN BOOLEAN DEFAULT NULL
						    );
FUNCTION DK_Varmi(ps_bolum VARCHAR2,ps_dk VARCHAR2 ,ps_doviz VARCHAR2 ) RETURN VARCHAR2 ;
FUNCTION Komisyon_DK_Bul(pn_dk_kod CBS_MUSTERI.DK_GRUP_KOD%TYPE,ps_masraf_kodu CBS_MASRAF_TUR.KODU%TYPE,pn_index number DEFAULT 1) RETURN VARCHAR2 ;
END;
/

