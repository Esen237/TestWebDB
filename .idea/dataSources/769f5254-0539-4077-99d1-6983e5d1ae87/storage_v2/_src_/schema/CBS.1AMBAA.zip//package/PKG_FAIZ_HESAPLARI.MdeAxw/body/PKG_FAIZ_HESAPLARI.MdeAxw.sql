create PACKAGE BODY     Pkg_Faiz_Hesaplari IS

	FUNCTION artan_ilk_taksit_bul(pn_kredi_tutar NUMBER, pn_taksit_no NUMBER, pn_faiz_orani NUMBER,
								  pn_tlp_artis_orani NUMBER, pn_tlp_artis_period NUMBER) RETURN NUMBER
	IS
	 ln_taksit NUMBER;
	 ln_donem NUMBER := 0;
	 ln_top NUMBER := 0;
	BEGIN
		FOR i IN 1.. pn_taksit_no LOOP
		  ln_donem := CEIL(i/pn_tlp_artis_period);
		  ln_top := ln_top + (POWER(1+pn_tlp_artis_orani, ln_donem-1)*(1/POWER(1+pn_faiz_orani, i)));
		END LOOP;
		ln_taksit := pn_kredi_tutar / ln_top;
	  RETURN(ln_taksit);
	END;
-------------------------------------------------------------------------------
	FUNCTION sabit_taksit_bul(pn_kredi_tutar NUMBER, pn_taksit_no NUMBER, pn_faiz_orani NUMBER) RETURN NUMBER
	IS
	 ln_taksit NUMBER;
	BEGIN
	  IF pn_faiz_orani >0 THEN
	     ln_taksit := pn_kredi_tutar * ((POWER((1+pn_faiz_orani), pn_taksit_no)*pn_faiz_orani) /
	        (POWER((1+pn_faiz_orani), pn_taksit_no)-1) ) ;
	  ELSE
	     ln_taksit := pn_kredi_tutar/pn_taksit_no;
	  END IF;
	  RETURN(ln_taksit);
	END;
-------------------------------------------------------------------------------
	PROCEDURE taksit_ayarla(pv_odeme_1 IN OUT Pkg_Type.v_odeme_plan, pn_taksit_sayi IN NUMBER,
	                        pn_anapara IN NUMBER, pn_kkdf_orani IN NUMBER, pn_bsmv_orani IN NUMBER,
	                        ps_doviz VARCHAR2, pn_faiz_ilave IN NUMBER, pn_kdv_oran IN NUMBER DEFAULT 0) IS
	ln_faiz_top NUMBER:=0;
	ln_kal_anapara NUMBER := pn_anapara;
	ln_temp number;
	ln_total_principal number:=0;
	BEGIN

     FOR num IN 1..pn_taksit_sayi LOOP
	   	IF pv_odeme_1(num).v_taksit > 0 THEN
		   IF pv_odeme_1(num).v_taksit <> round(pv_odeme_1(num).v_taksit,0) then
		      ln_temp := round(pv_odeme_1(num).v_taksit,0) - pv_odeme_1(num).v_taksit;
			  pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_anapara + ln_temp;
			  pv_odeme_1(num).v_taksit := round(pv_odeme_1(num).v_taksit,0);
			  pv_odeme_1(num).v_kalan_anapara := pv_odeme_1(num).v_kalan_anapara + ln_temp;
		   END IF;
		END IF;
		ln_total_principal := ln_total_principal + pv_odeme_1(num).v_anapara;
		if num = pn_taksit_sayi then
		--for the last installment adjust principal so sum totals credit amount
		  if ln_total_principal <> pn_anapara then
		     -- because of rounding sum of principal amounts in installments does not equal loan amount.
			 ln_temp := abs(ln_total_principal - pn_anapara);
			 if  ln_total_principal > pn_anapara then
			    pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_anapara - ln_temp;
				pv_odeme_1(num).v_taksit := pv_odeme_1(num).v_taksit - ln_temp;
			 else
			    pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_anapara + ln_temp;
				pv_odeme_1(num).v_taksit := pv_odeme_1(num).v_taksit + ln_temp;
			 end if;
		  end if;
		end if;
     END LOOP;

	  FOR num IN 1..pn_taksit_sayi LOOP     --0 olarak girilmi? kontrol
	  	IF pv_odeme_1(num).v_taksit = 0 THEN
	  		 ln_faiz_top := ln_faiz_top + pv_odeme_1(num).v_faiz;
	       pv_odeme_1(num).v_faiz := 0;
	       pv_odeme_1(num).v_kkdf := 0;
	       pv_odeme_1(num).v_bsmv := 0;
	       pv_odeme_1(num).v_anapara := 0;
	       IF num=1 THEN
	          pv_odeme_1(num).v_kalan_anapara := pn_anapara;
	       ELSE
	     	    pv_odeme_1(num).v_kalan_anapara := pv_odeme_1(num-1).v_kalan_anapara;
	       END IF;
	  	ELSE
	  	   pv_odeme_1(num).v_faiz := ln_faiz_top + pv_odeme_1(num).v_faiz;
	  	   ln_faiz_top := 0;
	       pv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_kkdf_orani);
	       pv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_bsmv_orani);
	       pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_taksit -
	                                   (pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv);
	       IF num = pn_taksit_sayi THEN --son taksitte ne kaldiysa al...
			   IF num<>1 THEN
		         pv_odeme_1(num).v_anapara := pv_odeme_1(num-1).v_kalan_anapara;
			   ELSE
			     pv_odeme_1(num).v_anapara := pn_anapara;
			   END IF;
	       ELSE
	          pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_taksit -
	                                 ( pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv);
	       END IF;
	       IF num=1 THEN
	          pv_odeme_1(num).v_kalan_anapara := pn_anapara - pv_odeme_1(num).v_anapara;
	       ELSE
	     	    pv_odeme_1(num).v_kalan_anapara := pv_odeme_1(num-1).v_kalan_anapara - pv_odeme_1(num).v_anapara;
	       END IF;
	  	END IF;
	  END LOOP;
	  ln_faiz_top := 0;
     FOR num IN 1..pn_taksit_sayi LOOP
	   	IF pv_odeme_1(num).v_anapara < 0 THEN
		   pv_odeme_1(num).v_anapara := 0;
		END IF;
     END LOOP;

     FOR num IN 1..pn_taksit_sayi LOOP
	   	IF pv_odeme_1(num).v_taksit > 0 THEN
		   IF pn_faiz_ilave > 0 THEN
		     pv_odeme_1(num).v_faiz := pv_odeme_1(num).v_faiz + pn_faiz_ilave;
		     pv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_kkdf_orani);
		     pv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_bsmv_orani);
			 pv_odeme_1(num).v_taksit := pv_odeme_1(num).v_anapara + pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv;
		   END IF;
		   pv_odeme_1(num).v_kdv := Pkg_Kur.yuvarla(ps_doviz, pv_odeme_1(num).v_taksit * pn_kdv_oran);
		END IF;
     END LOOP;

/* sadece ana para tutar? negatifse 0 olarak g?ster.. Faizi kredilendir....

	  for num in 1..pn_taksit_sayi loop     --Faiz Taksit ayarlamas? yap?l?r.
	  	if pv_odeme_1(num).v_anapara < 0 then
	  	   ln_faiz_top := ln_faiz_top  + pv_odeme_1(num).v_faiz;
	  	   pv_odeme_1(num).v_faiz  := pkg_kur.yuvarla(ps_doviz,pv_odeme_1(num).v_taksit/(1+pn_kkdf_orani+pn_bsmv_orani));
	  	   ln_faiz_top := ln_faiz_top - pv_odeme_1(num).v_faiz; --al?nan? ??kar
	       pv_odeme_1(num).v_kkdf := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_kkdf_orani);
	       pv_odeme_1(num).v_bsmv := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_bsmv_orani);
	       pv_odeme_1(num).v_anapara := 0;
	       pv_odeme_1(num).v_kalan_anapara := ln_kal_anapara;
	  	else
	  	   pv_odeme_1(num).v_faiz := ln_faiz_top  + pv_odeme_1(num).v_faiz;
	  	   pv_odeme_1(num).v_kkdf := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_kkdf_orani);
	       pv_odeme_1(num).v_bsmv := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_bsmv_orani);
	       if pv_odeme_1(num).v_taksit < pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv  then
	  		    --hala kucukse
	  		  pv_odeme_1(num).v_faiz  := pkg_kur.yuvarla(ps_doviz,pv_odeme_1(num).v_taksit/(1+pn_kkdf_orani+pn_bsmv_orani));
	  		  ln_faiz_top := ln_faiz_top - pv_odeme_1(num).v_faiz; --al?nan? ??kar
	          pv_odeme_1(num).v_kkdf := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_kkdf_orani);
	          pv_odeme_1(num).v_bsmv := pkg_kur.yuvarla(ps_doviz, pv_odeme_1(num).v_faiz*pn_bsmv_orani);
	          pv_odeme_1(num).v_anapara := 0;
	          pv_odeme_1(num).v_kalan_anapara := ln_kal_anapara;
	       else
	       	  if num = pn_taksit_sayi then
			   if num<>1 then
		         pv_odeme_1(num).v_anapara := pv_odeme_1(num-1).v_kalan_anapara;
			   else
			     pv_odeme_1(num).v_anapara := pn_anapara;
			   end if;
	       	  else
	       	    pv_odeme_1(num).v_anapara := pv_odeme_1(num).v_taksit - (pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv );
	       	  end if;
	       	  pv_odeme_1(num).v_kalan_anapara := ln_kal_anapara - pv_odeme_1(num).v_anapara;
	       	  ln_kal_anapara := pv_odeme_1(num).v_kalan_anapara;
	       	  ln_faiz_top := 0;
	       end if;
	  	end if;
	  end loop;
*/
	END;
-------------------------------------------------------------------------------
/*	PROCEDURE taksit_hatali_mi(pv_odeme_1 IN OUT Pkg_Type.v_odeme_plan, pn_taksit_sayi IN NUMBER,
	                           pn_err_no NUMBER DEFAULT NULL) IS
	  ln_arali NUMBER;
	  ln_arasiz NUMBER;
	  ln_uc VARCHAR2(3);
	  ln_err_no NUMBER:= NVL(pn_err_no,690);
	BEGIN
	  ln_arali := 0;
	  ln_arasiz := 0;
	  FOR num IN 1..pn_taksit_sayi LOOP
	  	IF pv_odeme_1(num).v_taksit < 0 OR
		   pv_odeme_1(num).v_anapara < 0 OR
		   pv_odeme_1(num).v_faiz < 0 OR
		   pv_odeme_1(num).v_bsmv < 0 OR
		   pv_odeme_1(num).v_kkdf < 0 OR
		   pv_odeme_1(num).v_kdv < 0   THEN
	  		ln_uc := Pkg_Hata.getUcPointer;
	  		RAISE_APPLICATION_ERROR(-20100,ln_uc||ln_err_no||ln_uc);
	  	ELSE
	  		 ln_arali := ln_arali + pv_odeme_1(num).v_taksit;
	  		 ln_arasiz := ln_arasiz + pv_odeme_1(num).v_anapara + pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv;
	  	END IF;
	  END LOOP;
	  IF ln_arali  <> ln_arasiz THEN
	     pv_odeme_1(pn_taksit_sayi).v_faiz := pv_odeme_1(pn_taksit_sayi).v_faiz + (ln_arali - ln_arasiz);
	  END IF;
	END;*/
PROCEDURE taksit_hatali_mi(pv_odeme_1 IN OUT Pkg_Type.v_odeme_plan, pn_taksit_sayi IN NUMBER,
	pn_err_no NUMBER DEFAULT NULL) IS
	ln_arali NUMBER;
	ln_arasiz NUMBER;
	ln_uc VARCHAR2(3);
	ln_err_no NUMBER:= NVL(pn_err_no,690);
BEGIN
	ln_arali := 0;
	ln_arasiz := 0;
	FOR num IN 1..pn_taksit_sayi LOOP
	IF pv_odeme_1(num).v_taksit < 0 OR
	pv_odeme_1(num).v_anapara < 0 OR
	pv_odeme_1(num).v_faiz < 0 OR
	pv_odeme_1(num).v_bsmv < 0 OR
	pv_odeme_1(num).v_kkdf < 0 OR
	pv_odeme_1(num).v_kdv < 0 THEN
	ln_uc := Pkg_Hata.getUcPointer;
	RAISE_APPLICATION_ERROR(-20100,ln_uc||ln_err_no||ln_uc);
	ELSIF pv_odeme_1(num).v_taksit < (pv_odeme_1(num).v_faiz +
	pv_odeme_1(num).v_bsmv +
	pv_odeme_1(num).v_kkdf +
	pv_odeme_1(num).v_kdv ) THEN
	ln_uc := Pkg_Hata.getUcPointer;
	RAISE_APPLICATION_ERROR(-20100,ln_uc||ln_err_no||ln_uc);
	ELSE
	ln_arali := ln_arali + pv_odeme_1(num).v_taksit;
	ln_arasiz := ln_arasiz + pv_odeme_1(num).v_anapara + pv_odeme_1(num).v_faiz + pv_odeme_1(num).v_kkdf + pv_odeme_1(num).v_bsmv;
	END IF;
	END LOOP;
	IF ln_arali <> ln_arasiz THEN
	pv_odeme_1(pn_taksit_sayi).v_faiz := pv_odeme_1(pn_taksit_sayi).v_faiz + (ln_arali - ln_arasiz);
	IF pv_odeme_1(pn_taksit_sayi).v_faiz < 0 THEN
	ln_uc := Pkg_Hata.getUcPointer;
	RAISE_APPLICATION_ERROR(-20100,ln_uc||ln_err_no||ln_uc);
	END IF;
	END IF;
END;

-------------------------------------------------------------------------------
	FUNCTION taksit_tarihi_al(pd_ilk_taksit_tarihi DATE, pn_kacinci NUMBER, pn_once_sonra VARCHAR2) RETURN DATE IS
	ld_candidate DATE;
	BEGIN
	  ld_candidate := ADD_MONTHS(pd_ilk_taksit_tarihi,pn_kacinci);
      --ld_candidate := Last_Day(pd_ilk_taksit_tarihi);--GulkaiyrK

	  --TA: Lastday of month problem in ADD_MONTH
	  if to_char(ld_candidate,'DD')>to_char(pd_ilk_taksit_tarihi,'DD') then
	  	 ld_candidate:=ld_candidate-2;
	  end if;

	  IF Pkg_Tarih.gun_ozellik(ld_candidate ) = 1 THEN
	  	IF pn_once_sonra = 'ONCEKI' THEN  --:ana.tlp_once_sonra = 'ONCEKI' then
	       RETURN Pkg_Tarih.geri_is_gunu(ld_candidate);
	  	ELSE
	  		 RETURN Pkg_Tarih.ileri_is_gunu(ld_candidate);
	  	END IF;
	  ELSE
	  	RETURN ld_candidate;
	  END IF;
	END;
-------------------------------------------------------------------------------
	PROCEDURE oranlari_al (pn_faiz_orani IN OUT NUMBER, pn_kkdf_orani IN OUT NUMBER,
	                       pn_bsmv_orani IN OUT NUMBER, pn_total_oran IN OUT NUMBER,
	                       pn_kdv_orani IN OUT NUMBER, ps_vergi_kes VARCHAR2,
	                       ps_fon_kes VARCHAR2, ps_kdv_kes VARCHAR2)IS
	ln_vergi_kes NUMBER := 1;
	ln_fon_kes NUMBER := 1;
	ln_kdv_kes NUMBER := 1;
	BEGIN
	  IF ps_vergi_kes='H' THEN
	    ln_vergi_kes :=0;
	  END IF;
	  IF ps_fon_kes='H' THEN
	    ln_fon_kes:=0;
	  END IF;
	  IF ps_kdv_kes='H' THEN
	    ln_kdv_kes:=0;
	  END IF;
	  pn_faiz_orani := (pn_faiz_orani/100);
	  pn_kkdf_orani := (pn_kkdf_orani/100)*ln_fon_kes;
	  pn_bsmv_orani := (pn_bsmv_orani/100)*ln_vergi_kes ;
	  pn_total_oran := (pn_faiz_orani) + (pn_bsmv_orani*pn_faiz_orani) + (pn_kkdf_orani*pn_faiz_orani);
	  pn_kdv_orani  := (pn_kdv_orani/100)*ln_kdv_kes ;

	END;
-------------------------------------------------------------------------------
	PROCEDURE ozel_odemeli(lv_ozel_odeme IN OUT Pkg_Type.v_odeme_plan,
	          lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS
	ln_arali  NUMBER;
    ln_arasiz NUMBER;
	ln_ara_odeme NUMBER;
	ln_arasiz_taksit NUMBER;
	BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	                                 ls_vergi, ls_fon, ls_kdv);
	  ln_arali := 0;
	  ln_arasiz := 0;

	  FOR j IN 	1..ln_taksit_sayi LOOP  --sabit ?denecek taksiti bul
	  	IF lv_ozel_odeme(j).v_taksit >= 0 THEN  --bu ayki ?deme girilen ?deme olacak...
	      ln_ara_odeme := lv_ozel_odeme(j).v_taksit * (1/(POWER(1+ln_total_oran, j)));
	      ln_arali := ln_arali + ln_ara_odeme;
	  	ELSE --bu ayki ?deme hesaplanacak ?deme olacak...
	      ln_ara_odeme := (1/(POWER(1+ln_total_oran, j)));
	      ln_arasiz := ln_arasiz + ln_ara_odeme;
	    END IF;
	  END LOOP;

	  ln_arasiz_taksit := Pkg_Kur.yuvarla(ls_doviz, (ln_kalan_anapara - ln_arali)/ln_arasiz) ;    --?demesiz taksit tutar?

	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;

	  	 IF lv_ozel_odeme(num).v_taksit >= 0 THEN  --?zel ?demenin oldu?u aylar
	  	 	  lv_odeme_1(num).v_taksit := lv_ozel_odeme(num).v_taksit;
	   	 ELSE
	  	 	  lv_odeme_1(num).v_taksit := ln_arasiz_taksit;
	   	 END IF;
		   IF num=1 THEN
		      lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
		   ELSE
		   	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
		   END IF;

	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;

	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 690);
  	END;
-------------------------------------------------------------------------------
	PROCEDURE ara_odemeli(lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, ln_tlp_ara_odeme_period NUMBER,
			  ln_tlp_ara_odeme_tutari NUMBER, pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS
	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_ara_odeme_bd NUMBER;
	ln_arasiz_taksit NUMBER;
    ln_ara_odeme_sayisi NUMBER;
	ln_taksit_tutari NUMBER;

	BEGIN
	 Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);

	  ln_ara_odeme_sayisi := FLOOR(ln_taksit_sayi/ln_tlp_ara_odeme_period);
	  ln_arali_anapara := 0;
	  ln_arasiz_anapara := 0;

	  FOR j IN 	1..ln_ara_odeme_sayisi LOOP  --ara ?demelerin bug?nk? de?erleri toplam? bul
	    ln_ara_odeme_bd := ln_tlp_ara_odeme_tutari*(1/(POWER(1+ln_total_oran, j*ln_tlp_ara_odeme_period)));
	    ln_arali_anapara := ln_arali_anapara + ln_ara_odeme_bd;
	  END LOOP;
	  ln_arasiz_anapara := ln_kalan_anapara - ln_arali_anapara; --ara ?demesiz kredi tutari

	  ln_taksit_tutari:=Pkg_Kur.yuvarla(ls_doviz,Pkg_Faiz_Hesaplari.sabit_taksit_bul(ln_arasiz_anapara, ln_taksit_sayi, ln_total_oran));
	  ln_arasiz_taksit := ln_taksit_tutari;    --ara ?demesiz taksit tutar?

	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;

	  	 IF MOD(num, ln_tlp_ara_odeme_period) = 0 THEN  --ara ?demenin oldu?u aylar
	  	 	  lv_odeme_1(num).v_taksit := ln_arasiz_taksit + ln_tlp_ara_odeme_tutari;
	   	 ELSE
	  	 	  lv_odeme_1(num).v_taksit := ln_arasiz_taksit;
	   	 END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;

	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 687);

   END;
-------------------------------------------------------------------------------
	PROCEDURE donemsel_odemeli(lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, ln_donem_period NUMBER,
			  pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS

	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_odeme_bd NUMBER;
	ln_taksit_tutari NUMBER;

    BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);
	  ln_total_oran := ln_total_oran*ln_donem_period;
	  ln_faiz_orani := ln_faiz_orani*ln_donem_period;

	  ln_arali_anapara := 0;
	  ln_arasiz_anapara := 0;

	  FOR j IN 	1..ln_taksit_sayi LOOP
	    ln_odeme_bd:= 1/(POWER(1+ln_total_oran, j));
	    ln_arali_anapara := ln_arali_anapara + ln_odeme_bd;
	  END LOOP;
	  ln_taksit_tutari:=ln_kalan_anapara/ln_arali_anapara;

	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;

	     lv_odeme_1(num).v_taksit := Pkg_Kur.yuvarla(ls_doviz, ln_taksit_tutari);

	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num * NVL(ln_donem_period,1), ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, (num-1) * NVL(ln_donem_period,1), ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;
	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 689);

    END;
-------------------------------------------------------------------------------
	PROCEDURE karma_ara_odemeli(lv_ozel_odeme IN OUT Pkg_Type.v_odeme_plan,
	          lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS

	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_ara_odeme_bd NUMBER;
	ln_arasiz_taksit NUMBER;
	ln_taksit_tutari NUMBER;

	BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);

	  ln_arali_anapara := 0;
	  ln_arasiz_anapara := 0;

	  FOR j IN 	1..ln_taksit_sayi LOOP  --?demelerin bug?nk? de?erleri toplam? bul
	  	IF lv_ozel_odeme(j).v_taksit > 0 THEN
	      ln_ara_odeme_bd := lv_ozel_odeme(j).v_taksit *(1/(POWER(1+ln_total_oran, j)));
	      ln_arali_anapara := ln_arali_anapara + ln_ara_odeme_bd;
	    END IF;
	  END LOOP;
	  ln_arasiz_anapara := ln_kalan_anapara - ln_arali_anapara; --?demesiz kredi tutari

	  ln_taksit_tutari:=Pkg_Kur.yuvarla(ls_doviz, Pkg_Faiz_Hesaplari.sabit_taksit_bul(ln_arasiz_anapara, ln_taksit_sayi, ln_total_oran));
	  ln_arasiz_taksit := ln_taksit_tutari;    --?demesiz taksit tutar?

	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;

	  	 IF lv_ozel_odeme(num).v_taksit > 0 THEN  --?zel ?demenin oldu?u aylar
	  	 	  lv_odeme_1(num).v_taksit := ln_arasiz_taksit + lv_ozel_odeme(num).v_taksit;
	   	 ELSE
	  	 	  lv_odeme_1(num).v_taksit := ln_arasiz_taksit;
	   	 END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;
	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 690);

    END;
-------------------------------------------------------------------------------
	PROCEDURE sabit_odemeli(lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS

	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_ara_odeme_bd NUMBER;
	ln_arasiz_taksit NUMBER;
	ln_taksit_tutari NUMBER;

	BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);

	  ln_taksit_tutari:=Pkg_Kur.yuvarla(ls_doviz, Pkg_Faiz_Hesaplari.sabit_taksit_bul(ln_kalan_anapara, ln_taksit_sayi, ln_total_oran));
      log_at('SEVAL-SABIT ODEME-0', 'ln_taksit_tutari' ,ln_taksit_tutari  ) ;
	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;
	     lv_odeme_1(num).v_taksit := ln_taksit_tutari;
	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);

		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;
     
     FOR num IN 1..ln_taksit_sayi LOOP
       log_at('SEVAL-SABIT ODEME-1', lv_odeme_1(num).v_sira ,'TAKSIT',lv_odeme_1(num).v_taksit  ) ;
        log_at('SEVAL-SABIT ODEME-1', lv_odeme_1(num).v_sira ,'ANAPARA',lv_odeme_1(num).v_anapara  ) ;
        log_at('SEVAL-SABIT ODEME-1', lv_odeme_1(num).v_sira ,'FAIZ',lv_odeme_1(num).v_faiz  ) ;
        log_at('SEVAL-SABIT ODEME-1', lv_odeme_1(num).v_sira ,'KALAN ANAPARA',lv_odeme_1(num).v_kalan_anapara  ) ;
     END LOOP; 
      
	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
        FOR num IN 1..ln_taksit_sayi LOOP
        log_at('SEVAL-SABIT ODEME-2', lv_odeme_1(num).v_sira ,'TAKSIT',lv_odeme_1(num).v_taksit  ) ;
        log_at('SEVAL-SABIT ODEME-2', lv_odeme_1(num).v_sira ,'ANAPARA',lv_odeme_1(num).v_anapara  ) ;
        log_at('SEVAL-SABIT ODEME-2', lv_odeme_1(num).v_sira ,'FAIZ',lv_odeme_1(num).v_faiz  ) ;
        log_at('SEVAL-SABIT ODEME-2', lv_odeme_1(num).v_sira ,'KALAN ANAPARA',lv_odeme_1(num).v_kalan_anapara  ) ;
      END LOOP; 
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 690);
        FOR num IN 1..ln_taksit_sayi LOOP
        log_at('SEVAL-SABIT ODEME-3', lv_odeme_1(num).v_sira ,'TAKSIT',lv_odeme_1(num).v_taksit  ) ;
        log_at('SEVAL-SABIT ODEME-3', lv_odeme_1(num).v_sira ,'ANAPARA',lv_odeme_1(num).v_anapara  ) ;
        log_at('SEVAL-SABIT ODEME-3', lv_odeme_1(num).v_sira ,'FAIZ',lv_odeme_1(num).v_faiz  ) ;
        log_at('SEVAL-SABIT ODEME-3', lv_odeme_1(num).v_sira ,'KALAN ANAPARA',lv_odeme_1(num).v_kalan_anapara  ) ;
         END LOOP; 
    END;
-------------------------------------------------------------------------------
	PROCEDURE artan_oranli_odeme(lv_odeme_1 IN OUT Pkg_Type.v_odeme_plan,
	          ln_faiz_orani IN OUT NUMBER, ln_kkdf_orani IN OUT NUMBER,
			  ln_bsmv_orani IN OUT NUMBER, ln_total_oran IN OUT NUMBER,
			  ln_kdv_orani IN OUT NUMBER, ls_vergi IN OUT VARCHAR2,
			  ls_fon IN OUT VARCHAR2, ls_kdv IN OUT VARCHAR2,
			  ln_taksit_sayi IN OUT NUMBER, ls_doviz VARCHAR2,
			  ln_kalan_anapara IN OUT NUMBER, ld_ilk_taksit_tarih IN OUT DATE,
			  ls_once_sonra IN OUT VARCHAR2, ln_tlp_artis_orani NUMBER,
			  ln_tlp_artis_period NUMBER, pd_donem_bas_son VARCHAR2 DEFAULT 'S',
			  pn_faiz_ilave IN NUMBER DEFAULT 0) IS

	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_ara_odeme_bd NUMBER;
	ln_arasiz_taksit NUMBER;
	ln_taksit_tutari NUMBER;
	ln_ilk_taksit_tutari NUMBER;
	ln_artis_oran NUMBER;

	BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);
				  log_At('1',ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani);
	  ln_artis_oran := ln_tlp_artis_orani/100;
				  log_At('2',  ln_artis_oran);
	  ln_taksit_tutari:=Pkg_Kur.yuvarla(ls_doviz, artan_ilk_taksit_bul(ln_kalan_anapara, ln_taksit_sayi, ln_total_oran, ln_artis_oran, ln_tlp_artis_period));
				  log_At('3',  ln_taksit_tutari);
	  ln_ilk_taksit_tutari := ln_taksit_tutari;
	  				  log_At('4',  ln_ilk_taksit_tutari);
	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;
		 ln_taksit_tutari := Pkg_Kur.yuvarla(ls_doviz, POWER(1+ln_artis_oran, CEIL(num/ln_tlp_artis_period)-1)*ln_ilk_taksit_tutari);
	     lv_odeme_1(num).v_taksit := ln_taksit_tutari;
	  				  log_At('5', num,ln_taksit_tutari );
	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	  				  log_At('6', num,ln_taksit_tutari );

	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;
	  				  log_At('7', num,ln_taksit_tutari );

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
		 	  				  log_At('8', num, lv_odeme_1(num).v_anapara);

	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;
	  		 	  				  log_At('9');
	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  		 	  				  log_At('10');
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 690);
	  		 	  				  log_At('11');
    END;
-------------------------------------------------------------------------------
   PROCEDURE sp_ins_rpt_odemeplan_islem
		(
		pn_rapor_islem_no					CBS_RPT_ODEMEPLAN_ISLEM.rapor_islem_no%TYPE,
		pn_tx_no							CBS_RPT_ODEMEPLAN_ISLEM.tx_no%TYPE,
		ps_odeme_turu						CBS_RPT_ODEMEPLAN_ISLEM.odeme_turu%TYPE,
		pn_tlp_kredi_miktari				CBS_RPT_ODEMEPLAN_ISLEM.tlp_kredi_miktari%TYPE,
		pn_tlp_vergi_kesilecek				CBS_RPT_ODEMEPLAN_ISLEM.tlp_vergi_kesilecek%TYPE,
		pn_bsmv_orani						CBS_RPT_ODEMEPLAN_ISLEM.bsmv_orani%TYPE,
		pn_tlp_taksit_sayisi				CBS_RPT_ODEMEPLAN_ISLEM.tlp_taksit_sayisi%TYPE,
		ps_tlp_fon_kesilecek				CBS_RPT_ODEMEPLAN_ISLEM.tlp_fon_kesilecek%TYPE,
		pn_kkdf_orani						CBS_RPT_ODEMEPLAN_ISLEM.kkdf_orani%TYPE,
		pn_tlp_once_sonra					CBS_RPT_ODEMEPLAN_ISLEM.tlp_once_sonra%TYPE,
		pn_tlp_faiz_orani					CBS_RPT_ODEMEPLAN_ISLEM.tlp_faiz_orani%TYPE,
		ps_tlp_kdv_kesilecek				CBS_RPT_ODEMEPLAN_ISLEM.tlp_kdv_kesilecek%TYPE,
		ps_tlp_doviz						CBS_RPT_ODEMEPLAN_ISLEM.tlp_doviz%TYPE,
		pd_tlp_acilis_tarihi				CBS_RPT_ODEMEPLAN_ISLEM.tlp_acilis_tarihi%TYPE,
		pn_tlp_artis_period					CBS_RPT_ODEMEPLAN_ISLEM.tlp_artis_period%TYPE,
		pn_tlp_artis_orani					CBS_RPT_ODEMEPLAN_ISLEM.tlp_artis_orani%TYPE,
		pn_tlp_ara_odeme_period				CBS_RPT_ODEMEPLAN_ISLEM.tlp_ara_odeme_period%TYPE,
		pn_tlp_ara_odeme_tutari				CBS_RPT_ODEMEPLAN_ISLEM.tlp_ara_odeme_tutari%TYPE,
		pn_tlp_donem_period					CBS_RPT_ODEMEPLAN_ISLEM.tlp_donem_period%TYPE,
		ps_tlp_imza_1						cbs_rpt_odemeplan_islem.tlp_imza_1%type,
		ps_tlp_imza_2						cbs_rpt_odemeplan_islem.tlp_imza_2%type,
		ps_tlp_sozlesme_no						cbs_rpt_odemeplan_islem.tlp_sozlesme_no%type,
		pd_tlp_sozlesme_tarihi					cbs_rpt_odemeplan_islem.tlp_sozlesme_tarihi%type
		)
	IS PRAGMA autonomous_transaction;
	BEGIN
	   INSERT INTO 	 CBS_RPT_ODEMEPLAN_ISLEM
	   (
		   rapor_islem_no,
		   tx_no,
		   odeme_turu,
		   tlp_kredi_miktari,
		   tlp_vergi_kesilecek,
		   bsmv_orani,
		   tlp_taksit_sayisi,
		   tlp_fon_kesilecek,
		   kkdf_orani,
		   tlp_once_sonra,
		   tlp_faiz_orani,
		   tlp_kdv_kesilecek,
		   tlp_doviz,
		   tlp_acilis_tarihi,
		   tlp_artis_period,
		   tlp_artis_orani,
		   tlp_ara_odeme_period,
		   tlp_ara_odeme_tutari,
		   tlp_donem_period ,
		   tlp_imza_1,
		   tlp_imza_2	,
		   tlp_sozlesme_no,
		   tlp_sozlesme_tarihi	   )
		VALUES (
			pn_rapor_islem_no	,
			pn_tx_no			,
			ps_odeme_turu		,
			pn_tlp_kredi_miktari,
			pn_tlp_vergi_kesilecek,
			pn_bsmv_orani	,
			pn_tlp_taksit_sayisi,
			ps_tlp_fon_kesilecek,
			pn_kkdf_orani		,
			pn_tlp_once_sonra	,
			pn_tlp_faiz_orani	,
			ps_tlp_kdv_kesilecek,
			ps_tlp_doviz		,
			pd_tlp_acilis_tarihi,
			pn_tlp_artis_period	,
			pn_tlp_artis_orani	,
			pn_tlp_ara_odeme_period,
			pn_tlp_ara_odeme_tutari,
			pn_tlp_donem_period,
		    ps_tlp_imza_1,
		    ps_tlp_imza_2,
			ps_tlp_sozlesme_no,
		    pd_tlp_sozlesme_tarihi
			)	;

	COMMIT;
	END;
-------------------------------------------------------------------------------

   PROCEDURE sp_ins_rpt_odemeplntkst_islem
		(
		pn_rapor_islem_no					CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.rapor_islem_no%TYPE,
		pn_sira_no							CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.sira_no%TYPE,
		pn_tx_no							CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.tx_no%TYPE,
		pn_taksit							CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.taksit%TYPE,
		pn_anapara							CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.anapara%TYPE,
		pn_faiz								CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.faiz%TYPE,
		pn_kkdf								CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.kkdf%TYPE,
		pn_bsmv								CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.bsmv%TYPE,
		pd_vade_tarih						CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.vade_tarih%TYPE,
		pn_kal_anapara						CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.kal_anapara%TYPE,
		pn_kdv								CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.kdv%TYPE,
		pn_kdvli_taksit						CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.kdvli_taksit%TYPE,
		pn_toplam							CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM.toplam%TYPE)
 IS PRAGMA autonomous_transaction;
 BEGIN
	  	   INSERT INTO CBS_RPT_ODEMEPLAN_TAKSIT_ISLEM
		   (   rapor_islem_no,
		   	   sira_no,
			   tx_no,
		   	   taksit,
			   anapara,
			   faiz,
			   kkdf,
		   	   bsmv,
			   vade_tarih,
			   kal_anapara,
			   kdv,
			   kdvli_taksit,
			   toplam)
		   VALUES
		   (
		  		pn_rapor_islem_no,
				pn_sira_no,
				pn_tx_no,
				pn_taksit,
				pn_anapara,
				pn_faiz	,
				pn_kkdf	,
				pn_bsmv		,
				pd_vade_tarih,
				pn_kal_anapara,
				pn_kdv,
				pn_kdvli_taksit,
				pn_toplam	);
	COMMIT;
 END;
-------------------------------------------------------------------------------
	procedure esit_anapara_odemeli(lv_odeme_1 in out pkg_type.v_odeme_plan,
	          ln_faiz_orani in out number, ln_kkdf_orani in out number,
			  ln_bsmv_orani in out number, ln_total_oran in out number,
			  ln_kdv_orani in out number, ls_vergi in out varchar2,
			  ls_fon in out varchar2, ls_kdv in out varchar2,
			  ln_taksit_sayi in out number, ls_doviz varchar2,
			  ln_kalan_anapara in out number, ld_ilk_taksit_tarih in out date,
			  ls_once_sonra in out varchar2, pd_donem_bas_son varchar2 default 'S',
			  pn_faiz_ilave in number default 0) is

	ln_arali_anapara  NUMBER;
    ln_arasiz_anapara NUMBER;
	ln_ara_odeme_bd NUMBER;
	ln_arasiz_taksit NUMBER;
	ln_anapara_tutari NUMBER;
	ln_kredi_tutari number;

	BEGIN
	  Pkg_Faiz_Hesaplari.oranlari_al(ln_faiz_orani, ln_kkdf_orani, ln_bsmv_orani, ln_total_oran, ln_kdv_orani,
	              ls_vergi, ls_fon, ls_kdv);

	  ln_kredi_tutari := ln_kalan_anapara;

	  ln_anapara_tutari := round(ln_kredi_tutari/ln_taksit_sayi,2);

	  FOR num IN 1..ln_taksit_sayi LOOP
	     lv_odeme_1.extend;
	     lv_odeme_1(num).v_sira := num;
	     lv_odeme_1(num).v_anapara := ln_anapara_tutari;
	     IF num=1 THEN
	        lv_odeme_1(num).v_faiz:=Pkg_Kur.yuvarla(ls_doviz, ln_kalan_anapara * ln_faiz_orani);
	     ELSE
	     	  lv_odeme_1(num).v_faiz := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num-1).v_kalan_anapara * ln_faiz_orani);
	     END IF;
	     lv_odeme_1(num).v_kkdf := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_kkdf_orani);
	     lv_odeme_1(num).v_bsmv := Pkg_Kur.yuvarla(ls_doviz, lv_odeme_1(num).v_faiz*ln_bsmv_orani);
		 lv_odeme_1(num).v_taksit := lv_odeme_1(num).v_anapara + lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv;
		 IF pd_donem_bas_son = 'S' THEN
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 ELSE
	        lv_odeme_1(num).v_vade := Pkg_Faiz_Hesaplari.taksit_tarihi_al(ld_ilk_taksit_tarih, num-1, ls_once_sonra);
		 END IF;

	     IF num = ln_taksit_sayi THEN --son taksitte ne kald?ysa al...
		   IF num<>1 THEN
	         lv_odeme_1(num).v_anapara := lv_odeme_1(num-1).v_kalan_anapara;
		   ELSE
		     lv_odeme_1(num).v_anapara := ln_kalan_anapara;
		   END IF;
	     ELSE
	        lv_odeme_1(num).v_anapara := lv_odeme_1(num).v_taksit -
	                                 ( lv_odeme_1(num).v_faiz + lv_odeme_1(num).v_kkdf + lv_odeme_1(num).v_bsmv);
	     END IF;
	     IF num=1 THEN
	        lv_odeme_1(num).v_kalan_anapara := ln_kalan_anapara - lv_odeme_1(num).v_anapara;
	     ELSE
	     	  lv_odeme_1(num).v_kalan_anapara := lv_odeme_1(num-1).v_kalan_anapara - lv_odeme_1(num).v_anapara;
	     END IF;
	  END LOOP;
	  --0(s?f?r) girilmi? taksitler i?in ayarlama yap?l?r....
	  taksit_ayarla(lv_odeme_1, ln_taksit_sayi, ln_kalan_anapara, ln_kkdf_orani, ln_bsmv_orani, ls_doviz, pn_faiz_ilave, ln_kdv_orani);
	  --odeme plan? kullan?labilir mi?
	  taksit_hatali_mi(lv_odeme_1, ln_taksit_sayi, 690);
    END;
-------------------------------------------------------------------------------

END;
/

