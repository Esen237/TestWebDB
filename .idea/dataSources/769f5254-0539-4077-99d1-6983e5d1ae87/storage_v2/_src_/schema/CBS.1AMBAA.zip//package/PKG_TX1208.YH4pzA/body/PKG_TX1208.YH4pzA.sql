create PACKAGE BODY     PKG_TX1208 IS

 
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Sonrasi(pn_islem_no number) is
Begin
    Null;
End;
--------------------------------------------------------------------------------
Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------

Procedure Onay_Sonrasi(pn_islem_no number) is
    
  Begin

      null;

  End;
--------------------------------------------------------------------------------
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
        null;
  End;
--------------------------------------------------------------------------------
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
     null;
 End;
--------------------------------------------------------------------------------
Procedure Reddetme_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
--------------------------------------------------------------------------------
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
--------------------------------------------------------------------------------
 Procedure Muhasebelesme(pn_islem_no number) is
 
  Begin
     
    null;

 End;
----------------------------------------------------------------------------------------------------------------------------------------------------------------


END ;
/

