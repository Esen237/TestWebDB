create PACKAGE     PKG_NOTIF_SUB
AS
/******************************************************************************
 NAME :         PKG_NOTIF_SUB
 Prepared By :  Nurzalat Alimzhan uulu
 Date :         07.05.2019
 Purpose :      Notification Sending for operations
******************************************************************************/
   FUNCTION SF_CHECK_SUB (PN_CUSTOMER_NO   IN     NUMBER,
                          PN_OP_ID_NO IN NUMBER,
                          PS_EMAIL            OUT BOOLEAN,
                          PS_SMS              OUT BOOLEAN,
                          PS_PUSH             OUT BOOLEAN,
                          PS_NOT_LANG         OUT VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE SF_GENERATE_NOTIF (PN_TX_NO IN NUMBER, PN_ISLEM_KOD IN NUMBER);

   FUNCTION SF_GET_CUST_EMAIL (PN_CUSTOMER_NO IN NUMBER)
      RETURN VARCHAR2;
   
   FUNCTION SF_GET_CUST_PHONE (PN_CUSTOMER_NO IN NUMBER)
      RETURN VARCHAR2;
   
   FUNCTION GENERATE_2300_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
      FUNCTION GENERATE_2000_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PN_EXTERNAL_ACC_NO in VARCHAR2,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
 FUNCTION GENERATE_2010_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PN_EXTERNAL_ACC_NO in VARCHAR2,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_2304_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT VARCHAR2,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_1001_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT VARCHAR2,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2,
                               PS_EMAILS          OUT VARCHAR2,
                               PS_PHONES          OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_2150_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_6200_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_1203_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_1203_OUT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;      --BAHIANAB CBS-562 09122021      
   FUNCTION GENERATE_3556_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_8800_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_8800_QR (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2; --BAHIANAB CBS-607 03022022         
   FUNCTION GENERATE_8806_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_8806_QR (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2; --BAHIANAB CBS-607 03022022         
   FUNCTION GENERATE_8807_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_8821_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   FUNCTION GENERATE_8826_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   --NurmilaZ Interbank QR 18/11/2022 CBS-807
   FUNCTION GENERATE_7000_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
   --NurmilaZ Interbank QR 18/11/2022 CBS-807
   FUNCTION GENERATE_7000_OUT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2;
      
   PROCEDURE SP_PACK_OPS_UPD (PN_TX_NO IN NUMBER);
   FUNCTION SF_CUST_OP_UNSUB (PN_CUSTOMER_NO NUMBER, PN_OPERATION_ID NUMBER, PB_EMAIL BOOLEAN, PB_SMS BOOLEAN, PB_PUSH BOOLEAN) RETURN VARCHAR2;
   FUNCTION SF_CUST_PACK_RESET (PN_CUSTOMER_NO NUMBER) RETURN VARCHAR2;
   FUNCTION SF_GET_BRANCH_BIC (PS_BRANCH_CODE VARCHAR2) RETURN VARCHAR2;
   PROCEDURE ACC_DAILY_NOTIF(PN_ACCOUNT_NO NUMBER);
   PROCEDURE ACC_MONTHLY_NOTIF(PN_ACCOUNT_NO NUMBER);
   PROCEDURE IB_USER_CREATION(PN_CUSTOMER_NO NUMBER);
   PROCEDURE INTERNET_PAYMENT_ACTIVATION(PN_CUSTOMER_NO NUMBER, PS_CARD_NO VARCHAR2);   
   FUNCTION  RUSCA_ULKE_ADI_AL_HATASIZ(PS_ULKE_KOD IN CBS_ULKE_KODLARI.ULKE_KODU%TYPE) RETURN VARCHAR2;
   FUNCTION RECEIVED_NOTIFICATION_OR_NOT(PN_CUSTOMER_NO IN NUMBER, PD_DATE1 DATE, PD_DATE2 DATE) RETURN VARCHAR2; --CBS-492 BAHIANAB 06.09.2021
   FUNCTION GENERATE_8837_NOT (PN_TX_NO        IN     NUMBER,
                           PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                           PS_EMAIL_BODY      OUT CLOB,
                           PS_SMS_BODY        OUT VARCHAR2,
                           PS_PUSH_BODY       OUT VARCHAR2)
   RETURN VARCHAR2; --bahianab cbs-662 new internet transactions
   
/******************************************************************************
    NAME :         GENERATE_4141_NOT
    Prepared By :  Panychev Anton
    Date :         11.01.2023
    Purpose :      Generate notif for 4141 tx
******************************************************************************/ 
   FUNCTION GENERATE_4141_NOT (PN_TX_NO        IN     NUMBER,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
   RETURN VARCHAR2;
END PKG_NOTIF_SUB;
/

