create PACKAGE BODY     "PKG_INT_CURRENCY" IS

/**************************************************************************************/
FUNCTION GetExchangeTranRate(ps_trantype IN VARCHAR2,
                             pn_musterino IN VARCHAR2,
                             pn_amount IN VARCHAR2,
                            ps_amountcurr     IN VARCHAR2,
                            ps_foreigncurr     IN VARCHAR2,
                            ps_rezervationno     IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     ln_amount       NUMBER;

     ln_fromamount     NUMBER;
     ln_tax_kambiyo     NUMBER;
     ln_total_amount NUMBER;

     ls_destcurr   VARCHAR2(3);
     ls_destcurrname VARCHAR2(100);
     ln_desccurrBuyrate NUMBER;
     ln_desccurrSellrate NUMBER;
     ln_destamount     NUMBER;
     ln_rezamount     NUMBER;
     ErrorDifferentAmount    EXCEPTION;
     ErrorDifferentCurrency    EXCEPTION;
BEGIN
    --log_at(ps_trantype,ps_amountcurr,pn_amount,ps_foreigncurr);
    ln_amount:=TO_NUMBER(pn_amount,'99999999999.99');
   --log_at('&&&&&&&&&&&&&&',ps_trantype);
    IF ps_rezervationno IS NOT NULL THEN
       SELECT r.DOVIZ, r.MUSTERI_KUR, r.MUSTERI_KUR,d.ACIKLAMA,r.TUTAR
       INTO ls_destcurr , ln_desccurrBuyrate,ln_desccurrSellrate,ls_destcurrname,ln_rezamount
       FROM CBS_VW_KUR_REZERVASYON r,CBS_DOVIZ_KODLARI d
       WHERE r.REZERVASYON_NO=TO_NUMBER(ps_rezervationno)
       AND d.DOVIZ_KODU=r.DOVIZ
       AND d.DOVIZ_KODU=ps_foreigncurr
       AND r.MUSTERI_NO=pn_musterino;

       IF ln_rezamount!=ln_amount THEN
             RAISE ErrorDifferentAmount;
       END IF;

       IF ps_foreigncurr!=ls_destcurr THEN
             RAISE ErrorDifferentCurrency;
       END IF;

       IF ps_trantype='A' THEN-- alis
           ln_destamount:=ln_amount;
           ln_fromamount:=ln_amount*ln_desccurrBuyrate;
       ELSE--SATIS
           ln_destamount:=ln_amount;
           ln_fromamount:=ln_amount*ln_desccurrSellrate;
       END IF;

    ELSE

        SELECT DVZ, DVZALIS, DVZSATIS, ACIKLAMA
        INTO ls_destcurr , ln_desccurrBuyrate,ln_desccurrSellrate,ls_destcurrname
        FROM CBS_KUR k,CBS_DOVIZ_KODLARI d
        WHERE k.dvz=d.doviz_kodu
        AND k.DVZ=ps_foreigncurr;
        IF ps_trantype='A' THEN-- alis
            ln_destamount:=Pkg_Kur.YUVARLA(ps_foreigncurr,Pkg_Kur.doviz_doviz_karsilik(ps_amountcurr,ps_foreigncurr,NULL,ln_amount,1,NULL,NULL,'O','S'));
            ln_fromamount:=Pkg_Kur.YUVARLA(Pkg_Genel.LC_al,Pkg_Kur.doviz_doviz_karsilik(ls_destcurr,Pkg_Genel.LC_al,NULL,ln_destamount,1,NULL,NULL,'O','S'));
        ELSE--S : satis
            ln_destamount:=Pkg_Kur.YUVARLA(ps_foreigncurr,Pkg_Kur.doviz_doviz_karsilik(ps_amountcurr,ps_foreigncurr,NULL,ln_amount,1,NULL,NULL,'O','A'));
            ln_fromamount:=Pkg_Kur.YUVARLA(Pkg_Genel.LC_al,Pkg_Kur.doviz_doviz_karsilik(ls_destcurr,Pkg_Genel.LC_al,NULL,ln_destamount,1,NULL,NULL,'O','A'));
        END IF;

    END IF;


    OPEN pc_ref FOR
         SELECT
             ls_destcurr,
             ls_destcurrname,
             ROUND(ln_desccurrBuyrate,4),
             ROUND(ln_desccurrSellrate,4),
             ROUND(ln_fromamount,2),
             ROUND(ln_destamount,2)
         FROM dual;
    RETURN ls_returncode;
EXCEPTION
         WHEN ErrorDifferentAmount THEN
              OPEN pc_ref FOR
                 SELECT
                     ls_destcurr,
                     ls_destcurrname,
                     ln_desccurrBuyrate,
                     ln_desccurrSellrate,
                     ln_fromamount,
                     ln_destamount
                 FROM dual;
               RETURN '404';
         WHEN ErrorDifferentCurrency THEN
              OPEN pc_ref FOR
                 SELECT
                     ls_destcurr,
                     ls_destcurrname,
                     ln_desccurrBuyrate,
                     ln_desccurrSellrate,
                     ln_fromamount,
                     ln_destamount
                 FROM dual;
               RETURN '405';
         WHEN OTHERS THEN
               Log_At(SQLERRM);
               RETURN '444';

END;
-------------------------------------------------------------------------------------------------
FUNCTION GetCurrencyInfo(ps_option        IN VARCHAR2,
                          ps_musterino      IN VARCHAR2,
                         ps_reservationno IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

BEGIN
    IF ps_option = 'DVZCOD' THEN
       OPEN pc_ref FOR
        SELECT DVZ , ACIKLAMA
        FROM CBS_KUR k,CBS_DOVIZ_KODLARI d
        WHERE k.dvz=d.doviz_kodu;

     ELSE
       OPEN pc_ref FOR SELECT '-' FROM dual;
     END IF;
     RETURN '000';
END;
-------------------------------------------------------------------------------------------------
FUNCTION FXBuySell(ps_trantype IN VARCHAR2,
                    pn_BORC_HESAP_NO IN VARCHAR2,
                    ps_DOVIZ_KODU IN VARCHAR2,
                    pn_KUR IN VARCHAR2,
                    pn_TUTAR IN VARCHAR2,
                    pn_ALACAK_HESAP_NO IN VARCHAR2,
                    ps_ISTATISTIK_KODU IN VARCHAR2,
                    ps_ACIKLAMA IN VARCHAR2,
                    pn_REZERVASYON_NO IN VARCHAR2,
                    ps_MASRAF IN VARCHAR2,
                    ps_TAHSIL_ADILEN_TOPLAM_TUTAR IN VARCHAR2,
                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    pn_islem_no        NUMBER;
    pn_islem_kod NUMBER;
    pc_modul_tur_kod VARCHAR2(10);
    pc_urun_tur_kod VARCHAR2(10);
    pc_urun_sinif_kod VARCHAR2(20);
    pc_rol NUMBER:=7777;
    pc_kasa_kod NUMBER;
    pc_doviz_kod VARCHAR(3):=ps_DOVIZ_KODU;
    pc_hesap_numara NUMBER:=pn_BORC_HESAP_NO;
    pn_musteri_numara NUMBER:=Pkg_Hesap.HesaptanMusteriNoAl(TO_NUMBER(pn_BORC_HESAP_NO));
    ps_BOLUM_KODU VARCHAR2(3):=Pkg_Hesap.HesapSubeAl(pn_BORC_HESAP_NO);
    pc_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
    pc_amir_bolum_kodu VARCHAR(10):=ps_BOLUM_KODU;
    pn_KANAL_NUMARA       NUMBER:=1;-- 0==CBS 1 =INTERNET  2= CALLCENTER

    ls_ISTATISTIK_KODU       VARCHAR2(10);
    ls_DOVIZ_ULKE_KODU       VARCHAR2(3);
    ls_DEKONT_BASIM_F       VARCHAR2(1);
    ls_stat_buy       VARCHAR2(4);
    ls_stat_sell       VARCHAR2(4);
    ln_TUTAR               NUMBER;
    ln_TAHSIL_ADILEN_TOPLAM_TUTAR NUMBER;
    ls_returncode           VARCHAR2(3):='000';
    FXBuySellOver           EXCEPTION;
    ls_explanation           VARCHAR2(100);
    NoRezervationError       EXCEPTION;
    ln_count               NUMBER;
    ln_REZERVASYON_NO       NUMBER;
    CORP_IB_FX_LIMIT       varchar2(200):='-1';
BEGIN
    pn_islem_no:=Pkg_Tx.islem_no_al;

    ln_TUTAR:=TO_NUMBER(pn_TUTAR,'99999999999.99');

    IF pn_REZERVASYON_NO IS NOT NULL AND LENGTH(LTRIM(RTRIM(pn_REZERVASYON_NO)))>0 THEN
       ln_REZERVASYON_NO:=TO_NUMBER(pn_REZERVASYON_NO);

       SELECT COUNT(*)
       INTO ln_count
       FROM CBS_VW_KUR_REZERVASYON r
       WHERE r.REZERVASYON_NO=ln_REZERVASYON_NO
       AND r.BAKIYE<>0
       AND MUSTERI_NO=pn_musteri_numara;

       IF ln_count=0 THEN
             RAISE NoRezervationError;
       END IF;

       Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(ln_REZERVASYON_NO,pn_islem_no,ln_TUTAR,Pkg_Muhasebe.banka_tarihi_bul,ps_BOLUM_KODU);
    END IF;

    SELECT ulke_kodu
    INTO ls_DOVIZ_ULKE_KODU
    FROM CBS_DOVIZ_KODLARI
    WHERE doviz_kodu = ps_DOVIZ_KODU;

    ls_stat_buy := '14' || Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_BORC_HESAP_NO))) ||
                 Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_BORC_HESAP_NO))) ;

    ls_stat_sell := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_BORC_HESAP_NO))) ||
                 Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_BORC_HESAP_NO))) || '14';

    ln_TAHSIL_ADILEN_TOPLAM_TUTAR:=TO_NUMBER(ps_TAHSIL_ADILEN_TOPLAM_TUTAR,'99999999999.99');--TO_NUMBER(REPLACE(REPLACE(ps_TAHSIL_ADILEN_TOPLAM_TUTAR,',',''),'.',','));

    Pkg_Hesap.UrunBilgiAl(pn_BORC_HESAP_NO,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

    IF ps_trantype='A' THEN
        pn_islem_kod:=4025;
        ls_ISTATISTIK_KODU := '213';
        ls_explanation:=' ' || pkg_jobs.GetLangLabels('FXBUYSELL', 1, 1, 'RUS') || ps_DOVIZ_KODU|| ' ' || pkg_jobs.GetLangLabels('FXBUYSELL', 1, 2, 'RUS') || pn_KUR;
        INSERT INTO CBS_DTH_DOVIZ_SATIS_ISLEM
        (TX_NO,
         ISLEM_TARIHI,
         MUSTERI_NO,
         MUSTERI_HESAP_NO,
         DOVIZ_KODU,
         DOVIZ_TUTARI,
         REZERVASYON_NO,
         KUR,
         DTH_MUSTERI_NO,
         DTH_MUSTERI_HESAP_NO,
         ACIKLAMA,
         MASRAF,
         TAHSIL_ADILEN_TOPLAM_TUTAR,
         ISLEM_SUBE,
         MUSTERI_EXTERNAL_HESAP,
         MUSTERI_VERGI_NO,
         DTH_MUSTERI_EXTERNAL_HESAP,
         DTH_MUSTERI_VERGI_NO)
        VALUES
        (pn_islem_no,
         Pkg_Muhasebe.Banka_Tarihi_Bul,
         pn_musteri_numara,
         pn_BORC_HESAP_NO,
         ps_DOVIZ_KODU,
         ln_TUTAR,
         ln_REZERVASYON_NO,
         TO_NUMBER(pn_KUR,'99999999999.9999'),--TO_NUMBER(REPLACE(REPLACE(pn_KUR,',',''),'.',',')),
         pn_musteri_numara,
         pn_ALACAK_HESAP_NO,
         SUBSTR(ps_ACIKLAMA ||ls_explanation,1,100),
         TO_NUMBER(ps_MASRAF,'99999999999.99'),--TO_NUMBER(REPLACE(REPLACE(ps_MASRAF,',',''),'.',',')),
         ln_TAHSIL_ADILEN_TOPLAM_TUTAR,
         ps_BOLUM_KODU,
         LPAD(NVL(Pkg_Hesap.External_HesapNo_Al(pn_BORC_HESAP_NO),0),16,'0'),
         NVL(Pkg_Musteri.Sf_VergiNo_Al(pn_musteri_numara),0),
         LPAD(NVL(Pkg_Hesap.External_HesapNo_Al(pn_ALACAK_HESAP_NO),0),16,'0'),
         NVL(Pkg_Musteri.Sf_VergiNo_Al(pn_musteri_numara),0));

    Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
                               pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                               ln_TUTAR,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                               pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                               pc_kasa_kod,pn_KANAL_NUMARA);

    --Onay olmayacak.Cunku once kontrol etmek istiyorlar
    Pkg_Int_Api.process_transaction (pn_islem_no);

    ELSIF ps_trantype='S' THEN
         pn_islem_kod:=1202;
            ls_ISTATISTIK_KODU := '223';
         ls_explanation:=' ' || pkg_jobs.GetLangLabels('FXBUYSELL', 1, 1, 'RUS') || ps_DOVIZ_KODU|| ' ' || pkg_jobs.GetLangLabels('FXBUYSELL', 1, 2, 'RUS') || pn_KUR;
         INSERT INTO CBS_DTH_TL_ODEME_ISLEM
         (TX_NO,
          BORC_HESAP_NO,
          DOVIZ_KODU,
          KUR,
          TUTAR,
          ALACAK_HESAP_NO,
          ISTATISTIK_KODU_ALIS,
          DOVIZ_ULKE_KODU,
          ACIKLAMA,
          DEKONT_BASIM_F,
          REZERVASYON_NO,
          PREFIX_ISTATISTIK_KODU_ALIS,
          PREFIX_ISTATISTIK_KODU_SATIS,
          ISTATISTIK_KODU_SATIS,
          BORC_EXTERNAL_HESAP,
          BORC_VERGI_NO,
          ALACAK_EXTERNAL_HESAP,
          ALACAK_VERGI_NO)
         VALUES
         (pn_islem_no,
          pn_BORC_HESAP_NO,
          ps_DOVIZ_KODU,
          TO_NUMBER(pn_KUR,'99999999999.9999'),--TO_NUMBER(REPLACE(REPLACE(pn_KUR,',',''),'.',',')),
          ln_TUTAR,
          pn_ALACAK_HESAP_NO,
          ls_ISTATISTIK_KODU,
          ls_DOVIZ_ULKE_KODU,
          ls_explanation,
          ls_DEKONT_BASIM_F,
           NULL,
         TO_NUMBER(ls_stat_buy),
         TO_NUMBER(ls_stat_sell),
          ls_ISTATISTIK_KODU,
          LPAD(NVL(Pkg_Hesap.External_HesapNo_Al(pn_BORC_HESAP_NO),0),16,'0'),
          NVL(Pkg_Musteri.Sf_VergiNo_Al(pn_musteri_numara),0),
          LPAD(NVL(Pkg_Hesap.External_HesapNo_Al(pn_ALACAK_HESAP_NO),0),16,'0'),
          NVL(Pkg_Musteri.Sf_VergiNo_Al(pn_musteri_numara),0));

        Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
                                   pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                   ln_TUTAR,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                   pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                                   pc_kasa_kod,pn_KANAL_NUMARA);

        Pkg_Int_Api.process_transaction (pn_islem_no);
    END IF;

    OPEN pc_ref FOR
    SELECT 'aaa',TO_CHAR(pn_islem_no) ISLEM_NO
    FROM dual;

    /*    TODO END    */
    RETURN ls_returncode;
EXCEPTION
         WHEN NoRezervationError THEN
               ls_returncode:='402';
              ROLLBACK;
              OPEN pc_ref FOR
                SELECT TO_CHAR(pn_islem_no) ISLEM_NO FROM dual;
                RETURN ls_returncode;
         WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At(pn_islem_kod, pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod);
            Log_At(SQLERRM,ls_returncode,ln_REZERVASYON_NO,pn_musteri_numara);
            ROLLBACK;
            OPEN pc_ref FOR
              SELECT TO_CHAR(pn_islem_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;
END;
--------------------------------------------------------------------------------------
 FUNCTION GetExchangeRates(pd_tarih IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
  IF pd_TARIH IS NULL THEN
      OPEN pc_ref FOR
        SELECT CBS_KUR.DVZ,
               CBS_KUR.DVZALIS,
             CBS_KUR.DVZSATIS,
             CBS_KUR.EFALIS,
             CBS_KUR.EFSATIS,
             CBS_DOVIZ_KODLARI.ACIKLAMA,
             CBS_MBKUR.DVZALIS MBKUR
       FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_MBKUR
       WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
       AND CBS_KUR.dvz=CBS_MBKUR.dvz
       AND CBS_KUR.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KGS','KZT')
       AND CBS_KUR.DVZ<>Pkg_Genel.lc_al
       ORDER BY SIRA_NO;
  ELSE
      OPEN pc_ref FOR
      SELECT CBS_KURLOG.DVZ,
               CBS_KURLOG.DVZALIS,
             CBS_KURLOG.DVZSATIS,
             CBS_KURLOG.EFALIS,
             CBS_KURLOG.EFSATIS,
             CBS_DOVIZ_KODLARI.ACIKLAMA,
             CBS_MBKURLOG.DVZALIS MBKUR
       FROM CBS_KURLOG,CBS_DOVIZ_KODLARI,CBS_MBKURLOG
       WHERE CBS_KURLOG.dvz=doviz_kodu
       AND CBS_KURLOG.dvz=CBS_MBKURLOG.dvz
          AND CBS_KURLOG.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KGS','KZT')
       AND TO_CHAR(CBS_KURLOG.tarih,'YYYYMMDD')=pd_TARIH
         AND TO_CHAR(CBS_MBKURLOG.tarih,'YYYYMMDD')=pd_TARIH
       AND CBS_KURLOG.gecerli_kur='E'
       --and tarih=(select max(tarih) from cbs_kurlog where TO_CHAR(tarih,'YYYYMMDD')=pd_TARIH)
       AND CBS_KURLOG.DVZ<>Pkg_Genel.lc_al
       ORDER BY SIRA_NO;
    END IF;

   RETURN ls_returncode;

 END;
------------------------------------------------------------------------------------------

 FUNCTION GetNBExchangeRates(pd_tarih IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

  IF pd_TARIH IS NULL THEN
      OPEN pc_ref FOR
        SELECT CBS_KUR.DVZ,
               CBS_KUR.DVZALIS,
             CBS_KUR.DVZSATIS,
             CBS_KUR.EFALIS,
             CBS_KUR.EFSATIS,
             CBS_DOVIZ_KODLARI.ACIKLAMA,
             CBS_MBKUR.DVZALIS MBKUR
       FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_MBKUR
       WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
       AND CBS_KUR.dvz=CBS_MBKUR.dvz
       --and CBS_KUR.DVZ in ('USD','EUR','TRY','GBP','CHF','RUB')
       AND ((CBS_KUR.DVZ<>Pkg_Genel.lc_al) AND (CBS_KUR.DVZ <> 'TRY'))
       ORDER BY SIRA_NO;
  ELSE
      OPEN pc_ref FOR
      SELECT CBS_MBKURLOG.DVZ,
               CBS_MBKURLOG.DVZALIS,
             CBS_MBKURLOG.DVZSATIS,
             CBS_MBKURLOG.EFALIS,
             CBS_MBKURLOG.EFSATIS,
             CBS_DOVIZ_KODLARI.ACIKLAMA,
             CBS_MBKURLOG.DVZALIS MBKUR
       FROM CBS_DOVIZ_KODLARI,CBS_MBKURLOG
       WHERE CBS_MBKURLOG.dvz=doviz_kodu
          --and CBS_KURLOG.DVZ in ('USD','EUR','TRY','GBP','CHF','RUB')
         AND TO_CHAR(CBS_MBKURLOG.tarih,'YYYYMMDD')=pd_TARIH
       AND CBS_MBKURLOG.gecerli_kur='E'
       --and tarih=(select max(tarih) from cbs_kurlog where TO_CHAR(tarih,'YYYYMMDD')=pd_TARIH)
       AND CBS_MBKURLOG.DVZ<>Pkg_Genel.lc_al
       ORDER BY SIRA_NO;
    END IF;

   RETURN ls_returncode;

 END;

--------------------------------------------------------------------------------------
FUNCTION GetDekontForFXBUY(ps_txno IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

   OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;

   OPEN pc_ref FOR
   SELECT A.TX_NO,A.ISLEM_SUBE,A.DTH_MUSTERI_HESAP_NO,A.MUSTERI_NO,
          TO_CHAR(A.ISLEM_TARIHI,'YYYYMMDD'),A.DOVIZ_KODU,A.DOVIZ_TUTARI,A.KUR,
          A.ACIKLAMA,A.TAHSIL_ADILEN_TOPLAM_TUTAR,A.MUSTERI_HESAP_NO FROM CBS_DTH_DOVIZ_SATIS_ISLEM A
   WHERE A.TX_NO=TO_NUMBER(ps_txno);


   RETURN ls_returncode;
 END;
-------------------------------------------------------------------------------------
FUNCTION GetDekontForFXSELL(ps_txno IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

   OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;

   OPEN pc_ref FOR
   SELECT A.TX_NO,I.KAYIT_KULLANICI_BOLUM_KODU,A.ALACAK_HESAP_NO,I.MUSTERI_NUMARA,
          TO_CHAR(I.KAYIT_TARIH,'YYYYMMDD'),A.DOVIZ_KODU,A.TUTAR,A.KUR,
          A.ACIKLAMA,A.TUTAR*A.KUR,A.BORC_HESAP_NO
          FROM
          CBS_DTH_TL_ODEME_ISLEM A,
          CBS_ISLEM I
   WHERE A.TX_NO=TO_NUMBER(ps_txno)
         AND A.TX_NO=I.NUMARA;

   RETURN ls_returncode;
 END;
-------------------------------------------------------------------------------------
FUNCTION GetKurGuncelmiKontrolu(ps_desckur IN VARCHAR2,
                                ps_desccurrency IN VARCHAR2,
                                ps_type IN VARCHAR2,
                                pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN
   OPEN pc_ref FOR
   SELECT SYSDATE FROM dual;
   RETURN ls_returncode;
 END;
-------------------------------------------------------------------------------------
FUNCTION GetCurrencyConvert(cycode1 IN VARCHAR2,
                            cycode2 IN VARCHAR2,
                            tran    IN VARCHAR2,
                            amount  IN NUMBER) RETURN NUMBER IS

 ln_amount NUMBER ;
 BEGIN
   ln_amount := Pkg_Kur.doviz_doviz_karsilik(CYCODE1,CYCODE2,NULL,NVL(AMOUNT,0),1,NULL,NULL,'O',tran);
   RETURN ln_amount;
 END;
-------------------------------------------------------------------------------
FUNCTION MakeRateDemand(ps_option IN VARCHAR2,
                        ps_customerid IN VARCHAR2,
                        ps_buysell IN VARCHAR2,
                        ps_currcode IN VARCHAR2,
                        ps_amount IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    pn_islem_no        NUMBER;
    pn_islem_kod NUMBER;
    pc_modul_tur_kod VARCHAR2(10);
    pc_urun_tur_kod VARCHAR2(10);
    pc_urun_sinif_kod VARCHAR2(20);
    pc_rol NUMBER:=7777;
    pc_kasa_kod NUMBER;
    pc_doviz_kod VARCHAR(3);
    pc_hesap_numara NUMBER;
    pn_musteri_numara NUMBER;
    pc_bolum_kodu VARCHAR(10);
    pn_KANAL_NUMARA       NUMBER:=1;-- 0==CBS 1 =INTERNET  2= CALLCENTER

    ls_ISTATISTIK_KODU       VARCHAR2(10);
    ls_DOVIZ_ULKE_KODU       VARCHAR2(3);
    ln_TUTAR               NUMBER;
    ls_returncode           VARCHAR2(3):='000';
    FXBuySellOver           EXCEPTION;
    ls_explanation           VARCHAR2(100);
    ls_trantype               VARCHAR2(1);
    ls_trankind               VARCHAR2(10);
    ls_ALIS_DOVIZ           VARCHAR2(3);
    ls_SATIS_DOVIZ           VARCHAR2(3);
    ln_ALIS_TUTAR           NUMBER;
    ln_SATIS_TUTAR           NUMBER;
    ln_MUSTERI_ALIS_KURU   NUMBER;
    ln_MUSTERI_SATIS_KURU  NUMBER;
    ln_MALIYET_ALIS_KURU  NUMBER;
    ln_MALIYET_SATIS_KURU NUMBER;
    ls_content              VARCHAR2(2000);
BEGIN

    pn_islem_no:=Pkg_Tx.islem_no_al;
    pn_islem_kod:=4020;
    pc_modul_tur_kod:='SYSTEM';
    pc_urun_tur_kod:='RATE';
    pc_urun_sinif_kod:='COST_DEMAND';
    ln_TUTAR:=TO_NUMBER(ps_amount,'99999999999.99');
    pn_musteri_numara:=TO_NUMBER(ps_customerid);
    pc_doviz_kod:=ps_currcode;
    pc_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(pn_musteri_numara);

    IF ps_option='RATEDEMAND' THEN
       ls_trantype:='M';
    ELSE--REZERVATION
       ls_trantype:='R';
    END IF;

    IF ps_buysell='BUY' THEN
        ls_trankind:='ALIS';
        ls_ALIS_DOVIZ:=pc_doviz_kod;
        ls_SATIS_DOVIZ:=NULL;
        ln_ALIS_TUTAR:=ln_TUTAR;
        ln_SATIS_TUTAR:=NULL;
        ln_MUSTERI_ALIS_KURU:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_ALIS_DOVIZ,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');
        ln_MALIYET_ALIS_KURU:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_ALIS_DOVIZ,Pkg_Genel.LC_AL,NULL,1,3,NULL,NULL,'N','A');
        ln_MUSTERI_SATIS_KURU:=NULL;
        ln_MALIYET_SATIS_KURU:=NULL;
    ELSE--SELL
        ls_trankind:='SATIS';
        ls_ALIS_DOVIZ:=NULL;
        ls_SATIS_DOVIZ:=pc_doviz_kod;
        ln_ALIS_TUTAR:=NULL;
        ln_SATIS_TUTAR:=ln_TUTAR;
        ln_MUSTERI_ALIS_KURU:=NULL;
        ln_MALIYET_ALIS_KURU:=NULL;
        ln_MUSTERI_SATIS_KURU:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_SATIS_DOVIZ,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S');
        ln_MALIYET_SATIS_KURU:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ls_SATIS_DOVIZ,Pkg_Genel.LC_AL,NULL,1,3,NULL,NULL,'N','S');
    END IF;

    /*if to_number(to_char(sysdate,'HH24'))>15 then
       raise FXBuySellOver;
    end if;*/

    INSERT INTO CBS_KUR_REZERVASYON_TALEP
    (TX_NO, TARIH, SUBE_KODU, REZERVASYON_NO, MUSTERI_NO, ISLEM_TIPI, ISLEM_SEKLI, ALIS_DOVIZ, SATIS_DOVIZ, ALIS_TUTAR, SATIS_TUTAR, MUSTERI_PARITE, MUSTERI_ALIS_KURU, MUSTERI_SATIS_KURU, MALIYET_PARITE, MALIYET_ALIS_KURU, MALIYET_SATIS_KURU, DURUM_KODU, KUR_PARITE)
    VALUES
    (pn_islem_no, Pkg_Muhasebe.Banka_Tarihi_Bul, pc_bolum_kodu, NULL, pn_musteri_numara, ls_trantype, ls_trankind, ls_ALIS_DOVIZ, ls_SATIS_DOVIZ,ln_ALIS_TUTAR, ln_SATIS_TUTAR, NULL, ln_MUSTERI_ALIS_KURU, ln_MUSTERI_SATIS_KURU, NULL, ln_MALIYET_ALIS_KURU, ln_MALIYET_SATIS_KURU, NULL, NULL);

    Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
                               pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                               ln_TUTAR,pc_bolum_kodu, pc_bolum_kodu,pc_rol,
                               pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                               pc_kasa_kod,pn_KANAL_NUMARA);

    --Onay olmayacak.Cunku once kontrol etmek istiyorlar
    Pkg_Int_Api.process_transaction (pn_islem_no);

    ls_content:='Customer No:' ||pn_musteri_numara || '<BR>Customer Name:' || Pkg_Musteri.Sf_Musteri_Adi(pn_musteri_numara) || '<BR>Transaction Type:' || ps_buysell || '<BR>Amount:' || ln_TUTAR || '<BR>Currency:' || pc_doviz_kod;
    Pkg_Email.AddToEmailQueue('RATEDEMAND', 50, 'info@demirbank.kz', 'treasurygroup@demirbank.kz;ITgroup@demirbank.kz;KuralayZ@demirbank.kz', 'Rate Demand Request From Customer',ls_content,'HTML');

    OPEN pc_ref FOR    SELECT 'aaa',TO_CHAR(pn_islem_no) ISLEM_NO    FROM dual;


    RETURN ls_returncode;

EXCEPTION
         WHEN FXBuySellOver THEN
               ls_returncode:='268';
              ROLLBACK;
              OPEN pc_ref FOR
                SELECT TO_CHAR(pn_islem_no) ISLEM_NO FROM dual;
                RETURN ls_returncode;
         WHEN OTHERS THEN
            ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
            Log_At(SQLERRM);
            ROLLBACK;
            OPEN pc_ref FOR     SELECT TO_CHAR(pn_islem_no) ISLEM_NO FROM dual;
            RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------
FUNCTION GetRateDemandInquiry(ps_customerid IN VARCHAR2,
                               ps_demandrezerv IN VARCHAR2,
                              ps_buysell  IN VARCHAR2,
                              ps_currcode IN VARCHAR2,
                              pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                              ps_islemsekli IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ld_startdate  DATE;
    ld_enddate      DATE;
BEGIN

      IF pd_startdate IS NULL OR pd_enddate IS NULL THEN
          ld_startdate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
        ld_enddate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
      ELSE
           ld_startdate:=TO_DATE(pd_startdate,'YYYYMMDD');
         ld_enddate:=TO_DATE(pd_enddate,'YYYYMMDD');
      END IF;

      OPEN pc_ref FOR
        SELECT TO_CHAR(TARIH,'YYYYMMDD'), REZERVASYON_NO, MUSTERI_NO,ISLEM_TIPI,ISLEM_SEKLI, SUBE_KODU,DOVIZ, TUTAR, BAKIYE,
               MUSTERI_KUR, DURUM_KODU, MALIYET_KUR,
               Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(NVL(DOVIZ,Pkg_Genel.LC_AL),Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S') BANK_ALIS_KURU,
               Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(NVL(DOVIZ,Pkg_Genel.LC_AL),Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A') BANK_SATIS_KURU
        FROM CBS_VW_KUR_REZERVASYON
        WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
        AND ISLEM_TIPI='M'
        AND BAKIYE<>0
        AND TARIH BETWEEN ld_startdate AND ld_enddate
        AND ISLEM_SEKLI=DECODE(NVL(ps_islemsekli,'-'),'ALIS','ALIS','SATIS','SATIS',ISLEM_SEKLI)
        ORDER BY TARIH;

        /*select to_char(TARIH,'YYYY.MM.DD'), REZERVASYON_NO, MUSTERI_NO, ISLEM_TIPI, ISLEM_SEKLI, ALIS_DOVIZ, SATIS_DOVIZ,
               ALIS_TUTAR, SATIS_TUTAR, MUSTERI_ALIS_KURU, MUSTERI_SATIS_KURU, DURUM_KODU,
               pkg_kur.DOVIZ_DOVIZ_KARSILIK(NVL(ALIS_DOVIZ,PKG_GENEL.LC_AL),PKG_GENEL.LC_AL,NULL,1,1,null,null,'O','S') BANK_ALIS_KURU,
               pkg_kur.DOVIZ_DOVIZ_KARSILIK(NVL(SATIS_DOVIZ,PKG_GENEL.LC_AL),PKG_GENEL.LC_AL,NULL,1,1,null,null,'O','A') BANK_SATIS_KURU
        from  CBS_KUR_REZERVASYON
        where MUSTERI_NO=to_number(ps_customerid)
        and ISLEM_TIPI='M'
        and TARIH between to_date(pd_startdate,'YYYYMMDD') and to_date(pd_enddate,'YYYYMMDD')
        order by TARIH;*/


    RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------
FUNCTION IsRateDemandCustomer(ps_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ln_count      NUMBER;
BEGIN
     SELECT COUNT(*)
     INTO ln_count
     FROM CBS_INT_RATEDEMAND_CUST
     WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
     AND STATUS_CD='sVALID';

     OPEN pc_ref FOR
           SELECT ln_count FROM dual;

     IF ln_count=0 THEN
         RETURN '401';
     ELSE
          RETURN ls_returncode;
     END IF;

END;
------------------------------------------------------------------------------------------------------------
FUNCTION MakeFXOrders(ps_trantype      IN  VARCHAR2,
                      pn_fromaccount   IN  VARCHAR2,
                      ps_currency      IN  VARCHAR2,
                      pn_to_account    IN  VARCHAR2,
                      ps_irsseco        IN  VARCHAR2,
                      ps_description   IN  VARCHAR2,
                      pn_fxamount      IN  VARCHAR2,
                      pn_totalamount   IN  VARCHAR2,
                      ps_periodtype    IN  VARCHAR2,
                      ps_periodlength  IN  VARCHAR2,
                      ps_rate          IN  VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    pn_order_id        NUMBER;
    pn_islem_no        NUMBER;
    pn_islem_kod NUMBER;
    pc_modul_tur_kod VARCHAR2(10);
    pc_urun_tur_kod VARCHAR2(10);
    pc_urun_sinif_kod VARCHAR2(20);
    pc_rol NUMBER:=7777;
    pc_bolum_kodu VARCHAR2(3);
    pc_kasa_kod NUMBER;
    pn_KANAL_NUMARA       NUMBER:=1;-- 0==CBS 1 =INTERNET  2= CALLCENTER

    ln_amount               NUMBER;
    ln_TAHSIL_ADILEN_TOPLAM_TUTAR NUMBER;
    ls_returncode           VARCHAR2(3):='000';
    FXBuySellOver           EXCEPTION;
    ls_explanation           VARCHAR2(100);
    ln_customer_no    NUMBER;

BEGIN

    ls_returncode:=Pkg_Int_Limit.CheckTimeLimit('FXORDER');
    IF ls_returncode<>'000' THEN
        RAISE FXBuySellOver;
    END IF;

        pn_islem_no:=Pkg_Tx.islem_no_al;
        pn_islem_kod:=9007;
        pn_order_id:=Pkg_Genel.genel_kod_al('FXORDER_ID');
        ln_amount:=TO_NUMBER(pn_fxamount,'99999999999.99');
        ln_customer_no:=Pkg_Hesap.HesaptanMusteriNoAl(TO_NUMBER(pn_fromaccount));
        ls_explanation:='???????? ???????? ('|| ps_currency|| ' ?? ????? ' || ps_rate || ')/Foreign exchange (' || ps_currency|| ' rate ' || ps_rate || ')';
        pc_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(ln_customer_no);
        pc_modul_tur_kod:='COLLECTION';
        pc_urun_tur_kod:='APS';
        pc_urun_sinif_kod:='FXORDER';


        INSERT INTO CBS_FXORDERS_TRAN(
        TX_NO, FXORDER_ID, CUSTOMER_NO, ORDER_DATE, TRAN_TYPE, FROM_ACCOUNT,
        TO_ACCOUNT, RATE, AMOUNT, CURRENCY, PERIOD_TYPE,
        PERIOD_LENGTH, STATUS, DESCRIPTION)
        VALUES
        (pn_islem_no,pn_order_id,ln_customer_no,SYSDATE,ps_trantype,TO_NUMBER(pn_fromaccount),
         TO_NUMBER(pn_to_account),TO_NUMBER(ps_rate,'99999999999.99'),ln_amount,ps_currency,ps_periodtype,
         TO_NUMBER(ps_periodlength),'sWAIT',ls_explanation);

    Pkg_Int_Api.create_transaction (pn_islem_no,
                                      pn_islem_kod,
                                         pc_modul_tur_kod,
                                      pc_urun_tur_kod,
                                      pc_urun_sinif_kod,
                                         ln_amount,
                                      pc_bolum_kodu,
                                      pc_bolum_kodu,
                                      pc_rol,
                                         ps_currency,
                                      ln_customer_no,
                                      pn_fromaccount,
                                         pc_kasa_kod,
                                      pn_KANAL_NUMARA);

    Pkg_Int_Api.process_transaction (pn_islem_no);


    OPEN pc_ref FOR
    SELECT TO_CHAR(pn_islem_no) ISLEM_NO
    FROM dual;

    /*    TODO END    */
    RETURN ls_returncode;

   EXCEPTION

         WHEN FXBuySellOver THEN
               ls_returncode:='268';
              ROLLBACK;
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('FXORDER',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;

END;
----------------------------------------------------------------------------------------------------------------
FUNCTION GetFXOrders(ps_customerid IN VARCHAR2,
                      ps_option     IN VARCHAR2,
                     pd_startdate  IN VARCHAR2,
                     pd_enddate    IN VARCHAR2,
                     ps_status     IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count NUMBER;
    NoFXOrders EXCEPTION;
BEGIN

         SELECT COUNT(*)
        INTO ln_count
        FROM CBS_FXORDERS
        WHERE CUSTOMER_NO=TO_NUMBER(ps_customerid)
        AND STATUS IN DECODE(ps_option,'LIST',STATUS,'CANCEL','sWAIT');

        IF ln_count=0 THEN
           RAISE NoFXOrders;
        END IF;

      IF ps_option='LIST' THEN

      OPEN pc_ref FOR

        SELECT TX_NO, CUSTOMER_NO, TO_CHAR(ORDER_DATE,'YYYYMMDD'), TRAN_TYPE, FROM_ACCOUNT,
               TO_ACCOUNT, RATE, AMOUNT, CURRENCY, PERIOD_TYPE, PERIOD_LENGTH,
               STATUS, TRAN_RATE, TRAN_KZT_EQ, TO_CHAR(TRAN_DATE,'YYYYMMDD'), DESCRIPTION, FXORDER_ID
        FROM CBS_FXORDERS
        WHERE CUSTOMER_NO=TO_NUMBER(ps_customerid) AND
              TO_DATE(pd_startdate,'YYYYMMDD') <= TRUNC(ORDER_DATE) AND
              TO_DATE(pd_enddate,'YYYYMMDD') >= TRUNC(ORDER_DATE) AND
              STATUS IN DECODE(ps_status,'ALL',STATUS,ps_status)
        ORDER BY TX_NO;

      ELSIF ps_option='CANCEL' THEN

      OPEN pc_ref FOR

          SELECT TX_NO, CUSTOMER_NO, TO_CHAR(ORDER_DATE,'YYYYMMDD'), TRAN_TYPE, FROM_ACCOUNT,
               TO_ACCOUNT, RATE, AMOUNT, CURRENCY, PERIOD_TYPE, PERIOD_LENGTH,
               STATUS, TRAN_RATE, TRAN_KZT_EQ, TO_CHAR(TRAN_DATE,'YYYYMMDD'), DESCRIPTION, FXORDER_ID
        FROM CBS_FXORDERS
        WHERE CUSTOMER_NO=TO_NUMBER(ps_customerid) AND
              STATUS='sWAIT'
        ORDER BY TX_NO;

        END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN NoFXOrders THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;
------------------------------------------------------------------------------------------------------------
FUNCTION FXOrdersCancel(ps_txno                    VARCHAR2,
                          pn_orderid                 VARCHAR2,
                          pn_from_acc                VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode        VARCHAR2 (3)  := '000';
        ln_islem_no          NUMBER;
        ln_order_id          NUMBER;
        ln_islem_kod         NUMBER;
        lc_modul_tur_kod     VARCHAR2 (20);
        lc_urun_tur_kod      VARCHAR2 (20);
        lc_urun_sinif_kod    VARCHAR2 (20);
        ls_fromaccountno     NUMBER;
        lc_bolum_kodu        VARCHAR (10);
        lc_amir_bolum_kodu   VARCHAR (10);
        pc_rol               NUMBER:= 7777; -- herhalde internet ?ubesi bu oluyor
        lc_doviz_kod         VARCHAR (10);
        ln_musteri_numara    NUMBER;
        ln_hesap_numara      NUMBER;
        pc_kasa_kod          NUMBER;
        pn_kanal_numara      NUMBER:= 1;
        ln_amount            NUMBER;


   BEGIN

        ln_islem_no             :=Pkg_Tx.islem_no_al;
        ln_order_id       :=TO_NUMBER(pn_orderid);
        ln_islem_kod      :=9008;
        lc_modul_tur_kod  :='COLLECTION';
        lc_urun_tur_kod   :='APS';
        lc_urun_sinif_kod :='FXORDER';
        ln_hesap_numara   :=TO_NUMBER(pn_from_acc);
        ln_musteri_numara :=Pkg_Hesap.HesaptanMusteriNoAl(ln_hesap_numara);
        lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(ln_hesap_numara);
        lc_amir_bolum_kodu:=lc_bolum_kodu;
        lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(ln_hesap_numara);


       INSERT INTO CBS_FXORDERS_TRAN
       (TX_NO, FXORDER_ID, CUSTOMER_NO, ORDER_DATE, TRAN_TYPE,
        FROM_ACCOUNT, TO_ACCOUNT, RATE, AMOUNT, CURRENCY,
        PERIOD_TYPE, PERIOD_LENGTH, STATUS, TRAN_RATE, TRAN_KZT_EQ,
        TRAN_DATE, DESCRIPTION)

        SELECT ln_islem_no, FXORDER_ID, CUSTOMER_NO, ORDER_DATE, TRAN_TYPE,
               FROM_ACCOUNT, TO_ACCOUNT, RATE, AMOUNT, CURRENCY,
               PERIOD_TYPE, PERIOD_LENGTH, 'sCANCEL', TRAN_RATE,
               TRAN_KZT_EQ, SYSDATE, DESCRIPTION
        FROM CBS_FXORDERS
        WHERE FXORDER_ID=TO_NUMBER(pn_orderid);

        Pkg_Int_Api.create_transaction  (ln_islem_no,
                                         ln_islem_kod,
                                           lc_modul_tur_kod,
                                           lc_urun_tur_kod,
                                           lc_urun_sinif_kod,
                                           ln_amount,
                                           lc_amir_bolum_kodu,
                                           lc_bolum_kodu,
                                           pc_rol,
                                           lc_doviz_kod,
                                           ln_musteri_numara,
                                           ln_hesap_numara,
                                           pc_kasa_kod,
                                           pn_kanal_numara);

        Pkg_Int_Api.process_transaction (ln_islem_no);


        OPEN pc_ref      FOR         SELECT ln_islem_no        FROM DUAL;
        RETURN ls_returncode;


   EXCEPTION
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('CNCLFXORD',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;
   END;
------------------------------------------------------------------------------------------------------------
FUNCTION GetArbitrageRates(ps_customerid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

  ls_returncode VARCHAR2(3):='000';

  BEGIN

      OPEN pc_ref FOR

      SELECT * FROM
      (
      SELECT
      1 SIRALAMA,
         Pkg_Int.IntCalculateParity('USD','EUR'),
      'USD###EUR',
      'USD',
      'EUR'
      FROM DUAL
      UNION
      SELECT
      2 SIRALAMA,
      Pkg_Int.IntCalculateParity('EUR','USD'),
      'EUR###USD',
      'EUR',
      'USD'
      FROM DUAL
      UNION
      SELECT
      3 SIRALAMA,
      Pkg_Int.IntCalculateParity('USD','GBP'),
      'USD###GBP',
      'USD',
      'GBP'
      FROM DUAL
      UNION
      SELECT
      4 SIRALAMA,
      Pkg_Int.IntCalculateParity('GBP','USD'),
      'GBP###USD',
      'GBP',
      'USD'
      FROM DUAL
      UNION
      SELECT
      5 SIRALAMA,
      Pkg_Int.IntCalculateParity('USD','CHF'),
      'USD###CHF',
      'USD',
      'CHF'
      FROM DUAL
      UNION
      SELECT
      6 SIRALAMA,
      Pkg_Int.IntCalculateParity('CHF','USD'),
      'CHF###USD',
      'CHF',
      'USD'
      FROM DUAL
      UNION
      SELECT
      7 SIRALAMA,
      Pkg_Int.IntCalculateParity('USD','TRY'),
      'USD###TRY',
      'USD',
      'TRY'
      FROM DUAL
      UNION
      SELECT
      8 SIRALAMA,
      Pkg_Int.IntCalculateParity('TRY','USD'),
      'TRY###USD',
      'TRY',
      'USD'
      FROM DUAL
      UNION
      SELECT
      9 SIRALAMA,
      Pkg_Int.IntCalculateParity('USD','RUB'),
      'USD###RUB',
      'USD',
      'RUB'
      FROM DUAL
      UNION
      SELECT
      10 SIRALAMA,
         Pkg_Int.IntCalculateParity('RUB','USD'),
      'RUB###USD',
      'RUB',
      'USD'
      FROM DUAL
      UNION
      SELECT
      11 SIRALAMA,
      Pkg_Int.IntCalculateParity('USD','KGS'),
      'USD###KGS',
      'USD',
      'KGS'
      FROM DUAL
      UNION
      SELECT
      12 SIRALAMA,
         Pkg_Int.IntCalculateParity('KGS','USD'),
      'KGS###USD',
      'KGS',
      'USD'
      FROM DUAL
      )
      ORDER BY SIRALAMA;

   RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------------------------
FUNCTION GetParity(ps_fromaccount IN VARCHAR2,
                   ps_toaccount IN VARCHAR2,
                   ps_amount IN VARCHAR2,
                   ps_amountcurreny IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
        ls_returncode VARCHAR2(3):='000';
        ps_temp VARCHAR2(100);
 BEGIN
 --log_at(ps_fromaccount,ps_toaccount,ps_amount,ps_amountcurreny);
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    IF (ps_amountcurreny = 'LC' ) THEN
    ps_temp := ps_fromaccount;
    ELSE
    ps_temp := ps_toaccount;
    END IF;

    IF ( Pkg_Kur_Rezervasyon.sf_base_doviz_hangisi(ps_fromaccount,ps_toaccount) = ps_temp) THEN
        OPEN pc_ref FOR
        SELECT
        TO_NUMBER(ps_amount,'99999999999.99'),
        ROUND(TO_NUMBER(ps_amount,'99999999999.99') * ROUND(Pkg_Int.IntCalculateParity(ps_fromaccount,ps_toaccount),5),2)
        FROM DUAL;
    ELSE
        OPEN pc_ref FOR
        SELECT
        TO_NUMBER(ps_amount,'99999999999.99'),
        ROUND(TO_NUMBER(ps_amount,'99999999999.99') / ROUND(Pkg_Int.IntCalculateParity(ps_fromaccount,ps_toaccount),5),2)
        FROM DUAL;
    END IF;

    RETURN ls_returncode;
 END;
------------------------------------------------------------------------------------------------------------
FUNCTION ParityControl(ps_fromaccount IN VARCHAR2,
                          ps_toaccount IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

        ls_returncode VARCHAR2(3):='000';
 BEGIN

 --log_at('control',ps_fromaccount,ps_toaccount);
    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    IF ((ps_fromaccount <> 'USD') AND (ps_fromaccount <> 'EUR') AND (ps_fromaccount <> 'GBP') AND (ps_fromaccount <> 'CHF') AND (ps_fromaccount <> 'RUB') AND (ps_fromaccount <> 'KGS')) THEN
    RETURN '733';
    END IF;

    IF ((ps_toaccount <> 'USD') AND (ps_toaccount <> 'EUR') AND (ps_toaccount <> 'GBP') AND (ps_toaccount <> 'CHF') AND (ps_fromaccount <> 'RUB') AND (ps_fromaccount <> 'KGS')) THEN
    RETURN '733';
    END IF;

    OPEN pc_ref FOR
    SELECT
    Pkg_Int.IntCalculateParity(ps_fromaccount,ps_toaccount)
    FROM dual;

    RETURN ls_returncode;
 END;
------------------------------------------------------------------------------------------------------------
FUNCTION MakeArbitrage(pn_fromaccountno IN VARCHAR2,
                       pn_toaccountno IN VARCHAR2,
                       ps_fromcurrency IN VARCHAR2,
                       ps_tocurrency IN VARCHAR2,
                       pn_parity IN VARCHAR2,
                       pn_fromamount IN VARCHAR2,
                       pn_toamount IN VARCHAR2,
                        pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS


         pn_islem_no            NUMBER;
         pn_islem_kod              NUMBER;
         pc_modul_tur_kod          VARCHAR2(10);
         pc_urun_tur_kod          VARCHAR2(10);
         pc_urun_sinif_kod          VARCHAR2(20);
         pc_rol                  NUMBER:=7777;
         pc_kasa_kod              NUMBER;
         pn_KANAL_NUMARA         NUMBER:=1;-- 0==CBS 1 =INTERNET  2= CALLCENTER
         pc_bolum_kodu             VARCHAR2(10);
         pc_amir_bolum_kodu      VARCHAR2(10);
         pc_doviz_kod              VARCHAR2(3);
         pn_musteri_numara          NUMBER;
         pc_hesap_numara          NUMBER;
         ln_buy_rate              NUMBER;
         ln_sell_rate              NUMBER;
         ln_debit_extaccount     VARCHAR(9);
         ln_credit_extaccount     VARCHAR(9);
         ln_debit_taxno         NUMBER;
         ln_credit_taxno         NUMBER;
         ls_stat_buy            NUMBER;
         ls_stat_sell            NUMBER;
         ln_parity              NUMBER;

         ls_ISTATISTIK_KODU_ALIS        VARCHAR2(10);
         ls_ISTATISTIK_KODU_SATIS        VARCHAR2(10);
         ls_DOVIZ_ULKE_KODU           VARCHAR2(3);
         ln_TUTAR                   NUMBER;
         ln_TAHSIL_ADILEN_TOPLAM_TUTAR NUMBER;
         ls_returncode            VARCHAR2(3):='000';
         FXBuySellOver            EXCEPTION;
         ls_explanation            VARCHAR2(100);

   BEGIN

          pn_islem_no:=Pkg_Tx.islem_no_al;
         pn_islem_kod:=1204;
         ls_ISTATISTIK_KODU_ALIS:= '213';
         ls_ISTATISTIK_KODU_SATIS:= '223';
         pc_hesap_numara:=TO_NUMBER(pn_fromaccountno);
         pn_musteri_numara:=Pkg_Hesap.HesaptanMusteriNoAl(pc_hesap_numara);
         pc_bolum_kodu:=Pkg_Musteri.sf_bolum_kodu_al(pn_musteri_numara);
         pc_amir_bolum_kodu:=pc_bolum_kodu;
         pc_doviz_kod:=ps_fromcurrency;
         ln_buy_rate:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ps_fromcurrency,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A');
         ln_sell_rate:=Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ps_tocurrency,Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S');
         ln_debit_extaccount:=LPAD(Pkg_Hesap.External_HesapNo_Al(pn_toaccountno),9,0);
         ln_credit_extaccount:=LPAD(Pkg_Hesap.External_HesapNo_Al(pn_fromaccountno),9,0);
         ln_debit_taxno:=Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(pn_toaccountno),9,0)));
         ln_credit_taxno:=Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.GetMusteriNoFromExternal(LPAD(Pkg_Hesap.External_HesapNo_Al(pn_fromaccountno),9,0)));
         ls_explanation:='???????? ???????? ' || ps_tocurrency || '-' || ps_fromcurrency || ' ?? ????? ' || pn_parity;
         ls_stat_buy := '14' || Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_fromaccountno))) ||
                 Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_fromaccountno))) ;

         ls_stat_sell := Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_fromaccountno))) ||
                 Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(pn_fromaccountno))) || '14';
         ln_TUTAR:=TO_NUMBER(pn_fromamount,'99999999999.99');
         ln_parity:=TO_NUMBER(pn_parity,'99999999999.99999');


         Pkg_Hesap.UrunBilgiAl(pn_fromaccountno,pc_modul_tur_kod,pc_urun_tur_kod,pc_urun_sinif_kod);

         INSERT INTO CBS_ARBITRAJ_ISLEM
         (TX_NO, ALIS_DOVIZ_KODU, SATIS_DOVIZ_KODU, ALIS_KURU, SATIS_KURU,
          PARITE,CARP_BOL_SECIMI, ALIS_TUTARI,SATIS_TUTARI, ALIS_HESAP_NO,
          SATIS_HESAP_NO, ACIKLAMA, KAYIT_GIRIS_TARIHI, KAYIT_YARATAN_KULLANICI_KODU, KUR_PARITE_SECIM,
          PREFIX_ISTATISTIK_KODU_ALIS, ISTATISTIK_KODU_ALIS, PREFIX_ISTATISTIK_KODU_SATIS, ISTATISTIK_KODU_SATIS, DEBIT_EXTERNAL_ACCOUNT,
          DEBIT_TAX_NO, CREDIT_EXTERNAL_ACCOUNT, CREDIT_TAX_NO, ISLEM_KOD, MUSTERI_NO, ISLEM_TARIHI
          )
         VALUES
         (pn_islem_no,ps_fromcurrency,ps_tocurrency,ln_buy_rate,ln_sell_rate,
          ln_parity,'CARP',ln_TUTAR, TO_NUMBER(pn_toamount,'99999999999.99'),TO_NUMBER(pn_fromaccountno),
          TO_NUMBER(pn_toaccountno),ls_explanation,SYSDATE,'CINT_CALLER','P',
          ls_stat_buy,ls_ISTATISTIK_KODU_ALIS,ls_stat_sell,ls_ISTATISTIK_KODU_SATIS,ln_debit_extaccount,ln_debit_taxno,
          ln_credit_extaccount,ln_credit_taxno,pn_islem_kod,pn_musteri_numara,Pkg_Muhasebe.Banka_Tarihi_Bul
          );


          Pkg_Int_Api.create_transaction (pn_islem_no, pn_islem_kod,
                                             pc_modul_tur_kod, pc_urun_tur_kod, pc_urun_sinif_kod,
                                          ln_TUTAR,pc_amir_bolum_kodu, pc_bolum_kodu,pc_rol,
                                             pc_doviz_kod, pn_musteri_numara,pc_hesap_numara,
                                             pc_kasa_kod,pn_KANAL_NUMARA);


          --Onay olmayacak.Cunku once kontrol etmek istiyorlar
          Pkg_Int_Api.process_transaction (pn_islem_no);


          OPEN pc_ref FOR
          SELECT 'aaa',TO_CHAR(pn_islem_no) ISLEM_NO
          FROM dual;

          /*    TODO END    */
          RETURN ls_returncode;

 EXCEPTION
      WHEN OTHERS   THEN
         ls_returncode := Pkg_Int_Api.geterrorcode (SQLERRM);
         Log_At ('ARBITRAGE',SQLERRM, ls_returncode);
         ROLLBACK;

         OPEN pc_ref   FOR        SELECT SYSDATE          FROM DUAL;

         RETURN ls_returncode;

END;
------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : FUNCTION GetExchangeRates
   Prepared By : Almas Nurkhozhayev
   Date        : 11.01.2009
   Purpose     : Exchange rates with specified DVZ, Tarih and Bank (DemirBank and NB -  National Bank)
******************************************************************************/
 FUNCTION GetExchangeRates_BP_NB(ps_dvz IN VARCHAR2,
                                 ps_nb IN VARCHAR2,
                                 pd_TARIH IN VARCHAR2,
                                 pc_ref OUT CursorReferenceType,
                                 pc_ref2 OUT CursorReferenceType,
                                 pc_ref3 OUT CursorReferenceType,
                                 pc_ref4 OUT CursorReferenceType,
                                 pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
BEGIN
   OPEN pc_ref FOR SELECT '-' FROM dual;
   OPEN pc_ref2 FOR SELECT '-' FROM dual;
   OPEN pc_ref3 FOR SELECT '-' FROM dual;
   OPEN pc_ref4 FOR SELECT '-' FROM dual;
   OPEN pc_ref5 FOR SELECT '-' FROM dual;             

    IF ps_nb = 'DKIB' THEN
      OPEN pc_ref FOR          
          SELECT m.DVZ,
                 m.DVZALIS,
                 m.DVZSATIS,
                 m.EFALIS,
                 m.EFSATIS,
                 n.ACIKLAMA,
                 k.DVZALIS MBKUR
           FROM CBS_KURLOG m,CBS_DOVIZ_KODLARI n,CBS_MBKURLOG k
           WHERE ( ( ps_dvz = 'ALL' 
                     AND m.dvz IN ('EUR','USD','KZT','RUB','TRY','GBP','KGS','CHF') )
                  OR
                   ( m.dvz = ps_dvz ) )
            AND m.DVZ = n.DOVIZ_KODU
            AND k.DVZ = m.DVZ           
            AND m.tarih BETWEEN  TO_DATE (pd_TARIH||' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH||' 23:59', 'YYYYMMDD HH24:MI')
            AND k.tarih BETWEEN  TO_DATE (pd_TARIH||' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH||' 23:59', 'YYYYMMDD HH24:MI')
            AND m.gecerli_kur='E'       
            AND (m.DVZ<>Pkg_Genel.lc_al AND (m.DVZ <> 'TRL'))
            ORDER BY SIRA_NO;
    ELSIF ps_nb = 'NB' THEN
       OPEN pc_ref FOR
          SELECT m.DVZ,
                 m.DVZALIS,
                 m.DVZSATIS,
                 m.EFALIS,
                 m.EFSATIS,
                 n.ACIKLAMA,
                 m.DVZALIS
           FROM CBS_DOVIZ_KODLARI n,CBS_MBKURLOG m
           WHERE ( ( ps_dvz = 'ALL'
                     AND m.dvz IN ('EUR','USD','KZT','RUB','TRY','GBP','KGS','CHF') )
                  OR
                   ( m.dvz = ps_dvz ) )
            AND m.tarih BETWEEN  TO_DATE (pd_TARIH||' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH||' 23:59', 'YYYYMMDD HH24:MI')
            AND m.gecerli_kur='E'
            and n.DOVIZ_KODU = m.DVZ
            AND (m.DVZ<>Pkg_Genel.lc_al AND (m.DVZ <> 'TRL'))
            ORDER BY SIRA_NO;
    END IF;               

   RETURN ls_returncode;
END;

END;
/

