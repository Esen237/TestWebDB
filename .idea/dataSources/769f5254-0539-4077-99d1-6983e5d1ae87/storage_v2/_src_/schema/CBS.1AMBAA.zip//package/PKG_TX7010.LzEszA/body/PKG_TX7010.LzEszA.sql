create PACKAGE BODY     "PKG_TX7010" IS
p_7010_HESAP_SUBE            NUMBER;
p_7010_ESKI_DK                     NUMBER;
p_7010_YENI_DK             NUMBER;
p_7010_DOVIZ_KODU             NUMBER;
p_7010_B_ACIKLAMA             NUMBER;
p_7010_M_ACIKLAMA             NUMBER;
p_7010_REFERANS             NUMBER;
p_7010_VALOR                     NUMBER;
p_7010_FC_TUTAR               NUMBER;
p_7010_LC_TUTAR               NUMBER;
p_7010_KUR                            NUMBER;
 --*****************************************************************
PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER) IS
  BEGIN
    NULL;
  END;
--*************************************************************************************--
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
    ln_hata_sayi NUMBER;
    ln_eksik_dk NUMBER;
  BEGIN

   SELECT COUNT(*)
   INTO   ln_hata_sayi
   FROM   CBS_MUSTERI_GKDEG_ISLEM_HATA
   WHERE  tx_no = pn_islem_no ;

   SELECT COUNT(*)
   INTO   ln_eksik_dk
   FROM   CBS_MUSTERI_GKDEG_ISLEM_DETAIL
   WHERE  tx_no = pn_islem_no
    AND (YENI_DK_NO IS NULL OR
         (KMH_DK_NO IS NOT NULL AND YENI_KMH_DK_NO IS NULL));

   IF ln_hata_sayi > 0 THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5155' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END IF;
   IF ln_eksik_dk > 0 THEN
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5987' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   END IF;

  END;
--*************************************************************************************--
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
         NULL;
  END;
--*************************************************************************************--
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER) IS
   ln_tx_no         NUMBER;
   ln_musteri_no         NUMBER;
   ln_ESKI_GRUP_KODU         NUMBER;
   ln_YENI_GRUP_KODU         NUMBER;

    CURSOR c_islem IS
    SELECT TX_NO,SUBE_KODU,HESAP_NO,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,DOVIZ_KODU,DK_NO,YENI_DK_NO,
           KMH_DK_NO, YENI_KMH_DK_NO, DK_NO_INTEREST, NEW_DK_NO_INTEREST --aisuluud cq5721 added DK_NO_INTEREST, NEW_DK_NO_INTEREST
    FROM   CBS_MUSTERI_GKDEG_ISLEM_DETAIL
    WHERE  tx_no       = pn_islem_no ;

    r_islem  c_islem%ROWTYPE;

    ls_sube         VARCHAR2(10);
  BEGIN
      SELECT TX_NO, MUSTERI_NO, ESKI_GRUP_KODU, YENI_GRUP_KODU
      INTO ln_tx_no, ln_musteri_no, ln_ESKI_GRUP_KODU, ln_YENI_GRUP_KODU
      FROM CBS_MUSTERI_GKDEG_ISLEM_MASTER
      WHERE tx_no = pn_islem_no;

      INSERT INTO CBS_MUSTERI_GKDEG_MASTER
      (TX_NO, MUSTERI_NO, ESKI_GRUP_KODU, YENI_GRUP_KODU)
      VALUES
      (ln_tx_no, ln_musteri_no, ln_ESKI_GRUP_KODU, ln_YENI_GRUP_KODU);

   OPEN c_islem;
   LOOP
        FETCH c_islem INTO r_islem;
        EXIT WHEN c_islem%NOTFOUND;

        INSERT INTO CBS_MUSTERI_GKDEG_DETAIL
        (TX_NO,SUBE_KODU,HESAP_NO,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,DOVIZ_KODU,DK_NO,YENI_DK_NO,
         KMH_DK_NO, YENI_KMH_DK_NO, DK_NO_INTEREST, NEW_DK_NO_INTEREST) --aisuluud cq5721 added DK_NO_INTEREST, NEW_DK_NO_INTEREST
        VALUES
        (r_islem.TX_NO,r_islem.SUBE_KODU,r_islem.HESAP_NO,r_islem.MODUL_TUR_KOD,r_islem.URUN_TUR_KOD,r_islem.URUN_SINIF_KOD,
         r_islem.DOVIZ_KODU,r_islem.DK_NO,r_islem.YENI_DK_NO,
         r_islem.KMH_DK_NO, r_islem.YENI_KMH_DK_NO, r_islem.DK_NO_INTEREST, r_islem.NEW_DK_NO_INTEREST); --aisuluud cq5721 added r_islem.DK_NO_INTEREST, r_islem.NEW_DK_NO_INTEREST
   END LOOP ;
   CLOSE c_islem;

   EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4534' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;
--*************************************************************************************
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
     NULL;
  END;
--*************************************************************************************--
  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--*************************************************************************************--
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT TX_NO,SUBE_KODU,HESAP_NO,MODUL_TUR_KOD,URUN_TUR_KOD,URUN_SINIF_KOD,DOVIZ_KODU,DK_NO,YENI_DK_NO,
           KMH_DK_NO, YENI_KMH_DK_NO, DK_NO_INTEREST, NEW_DK_NO_INTEREST --aisuluud cq5721 added DK_NO_INTEREST, NEW_DK_NO_INTEREST
    FROM   CBS_MUSTERI_GKDEG_ISLEM_DETAIL
    WHERE  tx_no       = pn_islem_no ;

    r_islem  c_islem%ROWTYPE;
    varchar_list              Pkg_Muhasebe.varchar_array;
    number_list              Pkg_Muhasebe.number_array;
    date_list              Pkg_Muhasebe.date_array;
    boolean_list              Pkg_Muhasebe.boolean_array;
    ln_fis_no              NUMBER;
    ls_doviz_kodu          VARCHAR2(3);
    ln_bakiye              NUMBER ;
    ln_plan_no              NUMBER ;
    ln_yeni_dk           NUMBER ;
    ln_musteri          NUMBER ;
    ls_yerlesim           VARCHAR2(1);
    ln_gecmis_aylarin_faizi NUMBER; --aisuluud cq5721
    ln_GecenYilFaizToplami number; --aisuluud cq5721
    ln_ovd_total_acc_interest number; --aisuluud cq5721
    ln_interest number; --aisuluud cq5721
  BEGIN
    ln_fis_no := 0;
    varchar_list(p_7010_HESAP_SUBE)   := '' ;
    varchar_list(p_7010_ESKI_DK)              := '' ;
    varchar_list(p_7010_YENI_DK)                 := '' ;
    varchar_list(p_7010_DOVIZ_KODU)        := '' ;
    varchar_list(p_7010_B_ACIKLAMA)         := '' ;
    varchar_list(p_7010_M_ACIKLAMA)     := '' ;
    varchar_list(p_7010_REFERANS)         := '' ;
    date_list(p_7010_VALOR)                      := '' ;
    number_list(p_7010_FC_TUTAR)           := 0 ;
    number_list(p_7010_LC_TUTAR)           := 0 ;
    number_list(p_7010_KUR)                    := 0 ;

   OPEN c_islem;
   LOOP
        FETCH c_islem INTO r_islem;
        EXIT WHEN c_islem%NOTFOUND;
            ls_doviz_kodu := Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) ;
            ln_bakiye := Pkg_Hesap.HesapBakiyeAl(r_islem.hesap_no)  ;
            
            --bom aisuluud cq5721
            
            if r_islem.modul_tur_kod in (Pkg_Hesap.modul_tur_vadeli,Pkg_Kredi.modul_tur_kod) then
                ln_gecmis_aylarin_faizi := Pkg_Hesap.Gecmis_Aylarin_Faizi(r_islem.hesap_no);            
                ln_gecenyilfaiztoplami := pkg_hesap.GecenYilFaizToplami(r_islem.hesap_no); 
            end if;
            
            if r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz then
                select OVD_TOTAL_ACC_INTEREST
                into ln_ovd_total_acc_interest
                from cbs_hesap 
                where hesap_no=r_islem.hesap_no;
            end if;
            
            select 
                CASE WHEN r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz THEN
                ln_ovd_total_acc_interest
                ELSE CASE WHEN r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli THEN
                nvl(ln_gecmis_aylarin_faizi,0)+nvl(ln_gecenyilfaiztoplami,0)
                ELSE CASE WHEN r_islem.modul_tur_kod = Pkg_Kredi.modul_tur_kod THEN
                nvl(ln_gecmis_aylarin_faizi,0)+nvl(ln_gecenyilfaiztoplami,0)
                END END END 
            into ln_interest
            from dual;
            
            --eom aisuluud cq5721

             IF ln_bakiye <> 0 AND
                (r_islem.DK_NO <> r_islem.YENI_DK_NO OR
                 (r_islem.DK_NO = r_islem.YENI_DK_NO AND
                  r_islem.MODUL_TUR_KOD='CURRENT' AND
                  ln_bakiye < 0 AND
                  NVL(r_islem.KMH_DK_NO,-1)<>NVL(r_islem.YENI_KMH_DK_NO,-1))
                 )
             THEN
                varchar_list(p_7010_HESAP_SUBE)   := r_islem.sube_kodu ;
                varchar_list(p_7010_ESKI_DK)              := r_islem.dk_no     ;
                varchar_list(p_7010_YENI_DK)                 := r_islem.yeni_dk_no     ;
                varchar_list(p_7010_DOVIZ_KODU)        := ls_doviz_kodu ;
                varchar_list(p_7010_B_ACIKLAMA)         :='G/L Group code modification. Account No : ' || r_islem.hesap_no || ' Old G/L No : ' || r_islem.dk_no || ' New G/L No : ' || r_islem.yeni_dk_no ;
                varchar_list(p_7010_M_ACIKLAMA)     :='G/L Group code modification. Account No : ' || r_islem.hesap_no || ' Old G/L No : ' || r_islem.dk_no || ' New G/L No : ' || r_islem.yeni_dk_no ;
                varchar_list(p_7010_REFERANS)         := '';
                date_list(p_7010_VALOR)                      := Pkg_Muhasebe.Banka_Tarihi_Bul ;
                number_list(p_7010_KUR)                    := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A')  ;

                IF ln_bakiye < 0
                THEN
                    number_list(p_7010_FC_TUTAR)           := ln_bakiye * (-1) ;
                ELSE
                    number_list(p_7010_FC_TUTAR)           := ln_bakiye;
                END IF ;

                number_list(p_7010_LC_TUTAR)           := Pkg_Kur.yuvarla(ls_doviz_kodu, number_list(p_7010_FC_TUTAR) * number_list(p_7010_KUR)) ;

                IF ls_doviz_kodu = Pkg_Genel.lc_al AND ln_bakiye < 0
                THEN
                    ln_plan_no:=1 ;
                END IF ;
                IF ls_doviz_kodu = Pkg_Genel.lc_al AND ln_bakiye > 0
                THEN
                    ln_plan_no:=2 ;
                END IF ;
                IF ls_doviz_kodu <> Pkg_Genel.lc_al AND ln_bakiye < 0
                THEN
                    ln_plan_no:=3 ;
                END IF ;
                IF ls_doviz_kodu <> Pkg_Genel.lc_al AND ln_bakiye > 0
                THEN
                    ln_plan_no:=4 ;
                END IF ;

                IF r_islem.MODUL_TUR_KOD<>'CURRENT' OR
                   (r_islem.MODUL_TUR_KOD='CURRENT' AND ln_bakiye <> 0)--ln_bakiye > 0) --aisuluud cq5721
                   THEN
                  ln_fis_no:=Pkg_Muhasebe.fis_kes(7010,
                        ln_plan_no,
                        pn_islem_no,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        NULL,
                        FALSE,
                        0,
                        'Customer G/L Group code modification');

                  Pkg_Muhasebe.muhasebelestir(ln_fis_no);

                END IF;
                IF r_islem.MODUL_TUR_KOD='CURRENT' AND
                   ln_bakiye < 0 AND
                   r_islem.KMH_DK_NO IS NOT NULL
                   THEN

                  varchar_list(p_7010_ESKI_DK) := r_islem.KMH_DK_NO;
                  varchar_list(p_7010_YENI_DK) := r_islem.YENI_KMH_DK_NO;

                  ln_fis_no:=Pkg_Muhasebe.fis_kes(7010,
                        ln_plan_no,
                        pn_islem_no,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        NULL,
                        FALSE,
                        0,
                        'Customer G/L Group code modification');

                  Pkg_Muhasebe.muhasebelestir(ln_fis_no);

                END IF;

            END IF;
            
            --bom aisuluud cq5721
            
            if nvl(ln_interest,0) > 0 
            then
                varchar_list(p_7010_HESAP_SUBE)    := r_islem.sube_kodu ;
                varchar_list(p_7010_B_ACIKLAMA)    :='G/L Group code modification. Account No : ' || r_islem.hesap_no || ' Old G/L No : ' || r_islem.dk_no || ' New G/L No : ' || r_islem.yeni_dk_no ;
                varchar_list(p_7010_M_ACIKLAMA)    :='G/L Group code modification. Account No : ' || r_islem.hesap_no || ' Old G/L No : ' || r_islem.dk_no || ' New G/L No : ' || r_islem.yeni_dk_no ;
                varchar_list(p_7010_REFERANS)      := '';
                varchar_list(p_7010_ESKI_DK)       := r_islem.DK_NO_INTEREST     ;
                varchar_list(p_7010_YENI_DK)       := r_islem.NEW_DK_NO_INTEREST     ;
                varchar_list(p_7010_DOVIZ_KODU)    := ls_doviz_kodu ;
                
                date_list(p_7010_VALOR)                      := Pkg_Muhasebe.Banka_Tarihi_Bul ;
                
                number_list(p_7010_KUR)                    := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.LC_AL,NULL, 1,1,NULL,NULL,'O','A')  ;
                number_list(p_7010_FC_TUTAR)           := nvl(ln_interest,0);
                number_list(p_7010_LC_TUTAR)           := Pkg_Kur.yuvarla(ls_doviz_kodu, number_list(p_7010_FC_TUTAR) * number_list(p_7010_KUR)) ;
                
                IF ls_doviz_kodu = Pkg_Genel.lc_al and r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli
                THEN
                    ln_plan_no:=2 ;
                END IF ;
                IF ls_doviz_kodu <> Pkg_Genel.lc_al and r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli
                THEN
                    ln_plan_no:=4 ;
                END IF ;
                IF ls_doviz_kodu = Pkg_Genel.lc_al AND r_islem.modul_tur_kod <> Pkg_Hesap.modul_tur_vadeli
                THEN
                    ln_plan_no:=1 ;
                END IF ;
                IF ls_doviz_kodu <> Pkg_Genel.lc_al AND r_islem.modul_tur_kod <> Pkg_Hesap.modul_tur_vadeli
                THEN
                    ln_plan_no:=3 ;
                END IF ;
                
                ln_fis_no:=Pkg_Muhasebe.fis_kes(7010,
                        ln_plan_no,
                        pn_islem_no,
                        varchar_list,
                        number_list,
                        date_list,
                        boolean_list,
                        NULL,
                        FALSE,
                        0,
                        'Customer G/L Group code modification');

                  Pkg_Muhasebe.muhasebelestir(ln_fis_no);

            end if;
            --eom aisuluud cq5721
                -------------------------------------- CBS_HESAP_xxx  ve CBS_MUSTERI update leri --------------------------------
                ln_yeni_dk := 0;
                ln_musteri := 0;
                ls_yerlesim := '';
                SELECT musteri_no,YENI_GRUP_KODU
                INTO ln_musteri, ln_yeni_dk
                FROM   CBS_MUSTERI_GKDEG_ISLEM_MASTER
                WHERE  tx_no       = pn_islem_no ;

                SELECT yerlesim_tipi
                INTO ls_yerlesim
                FROM   CBS_DK_GRUP_KODLARI
                WHERE dk_grup_kodu  = ln_yeni_dk ;

                UPDATE CBS_MUSTERI
                SET DK_GRUP_KOD = ln_yeni_dk,
                        yerlesim_kod = ls_yerlesim
                WHERE musteri_no = ln_musteri ;

                IF r_islem.modul_tur_kod = 'CURRENT'
                THEN
                  UPDATE CBS_HESAP
                     SET musteri_dk_no = r_islem.yeni_dk_no
                   WHERE hesap_no = r_islem.hesap_no ;
                  IF r_islem.YENI_KMH_DK_NO IS NOT NULL THEN
                    UPDATE CBS_HESAP
                    SET OVD_DK_NO = r_islem.YENI_KMH_DK_NO
                    WHERE hesap_no = r_islem.hesap_no ;
                  END IF;
                END IF;
                IF r_islem.modul_tur_kod = 'TIME DEP.'
                THEN
                    UPDATE CBS_HESAP_VADELI
                    SET musteri_dk_no = r_islem.yeni_dk_no
                    WHERE hesap_no = r_islem.hesap_no ;
                END IF;
                IF r_islem.modul_tur_kod = 'LOAN'
                THEN
                    UPDATE CBS_HESAP_KREDI
                    SET musteri_dk_no = r_islem.yeni_dk_no
                    WHERE hesap_no = r_islem.hesap_no ;
                END IF;
                -------------------------------------- CBS_HESAP_xxx  ve CBS_MUSTERI update leri --------------------------------
   END LOOP ;
   CLOSE c_islem;
     EXCEPTION
       WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '5029'  || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER) IS
   BEGIN
    NULL;
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '699' || Pkg_Hata.getucpointer);
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
      NULL;
  END;
--------------------------------------------------------------------------------------------------------------
  PROCEDURE Hata_Kontrolleri(pn_islem_no NUMBER) IS
    CURSOR c_islem IS
    SELECT m.TX_NO, m.MUSTERI_NO, m.ESKI_GRUP_KODU, m.YENI_GRUP_KODU,
                     d.SUBE_KODU, d.HESAP_NO, d.MODUL_TUR_KOD, d.URUN_TUR_KOD, d.URUN_SINIF_KOD, d.DOVIZ_KODU,
                  d.DK_NO, d.YENI_DK_NO
    FROM   CBS_MUSTERI_GKDEG_ISLEM_MASTER m, CBS_MUSTERI_GKDEG_ISLEM_DETAIL d
    WHERE  m.tx_no       = pn_islem_no
           AND m.tx_no = d.tx_no
           and d.urun_Tur_kod not in('ACCRUAL','NONACCRUAL'); -- seval.colak 16022023  accrual,nonaccrual kontrollere girmesin.
    r_islem  c_islem%ROWTYPE;
    ln_mus_count               NUMBER;
    ls_hata                    VARCHAR2(2000);
    ls_ana_dk_no               VARCHAR2(2000);
    ls_2_dk_no                 VARCHAR2(2000);
    ls_3_dk_no                 VARCHAR2(2000);
    ls_4_dk_no                 VARCHAR2(2000);
    ls_5_dk_no                 VARCHAR2(2000);
    ls_6_dk_no                 VARCHAR2(2000);
    ls_8_dk_no                 VARCHAR2(2000);--aisuluud cq5721
    ln_sube_count              NUMBER;
    ln_2_dk_count             NUMBER;
    ln_3_dk_count             NUMBER;
    ln_4_dk_count             NUMBER;
    ln_5_dk_count             NUMBER;
    ln_6_dk_count             NUMBER;
    ln_8_dk_count             NUMBER; --aisuluud cq5721
    ln_FAIZ_ORANI               NUMBER;
    ln_BIRIKMIS_FAIZ_POZ       NUMBER;
    ln_KOMISYON_ORANI           NUMBER;
    ln_BIRIKMIS_KOMISYON       NUMBER;
    ln_hata_count       NUMBER;
    LN_OVD_TOTAL_ACC_INTEREST  NUMBER; --AISULUUD CQ5721
    ln_GECMIS_AYLARIN_FAIZI number; --AISULUUD CQ5721
    ln_GECEN_YIL_FAIZ_TOPLAMI number; --AISULUUD CQ5721
    ln_GECENYIL_FAIZ_TUTARI number; --AISULUUD CQ5721
    LN_BLOCK_TX_NO NUMBER; --AntonPa CBS-643 150822
  BEGIN
    DELETE FROM  CBS_MUSTERI_GKDEG_ISLEM_HATA
    WHERE tx_no = pn_islem_no ;

   OPEN c_islem;
   LOOP
        FETCH c_islem INTO r_islem;
        EXIT WHEN c_islem%NOTFOUND;

--1.hata kontrolu
    SELECT COUNT(*)
    INTO   ln_mus_count
    FROM   CBS_GRUP_URUN_SINIF
    WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
    AND    modul_tur_kod  = r_islem.modul_tur_kod
    AND    urun_tur_kod   = r_islem.urun_tur_kod
    AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

    IF ln_mus_count  = 0 THEN
        ls_hata := 'Module : ' || r_islem.modul_tur_kod ||  ', Product type : ' || r_islem.urun_tur_kod ||
                   ', Product Class : ' || r_islem.urun_sinif_kod     ||  ', ' ||
                   r_islem.YENI_GRUP_KODU ||  ' G/L Group Code not defined. ' ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
    ELSE
    --2.hata kontrolu
        SELECT NVL(DK_HESABI_1,0)
        INTO   ls_ana_dk_no
        FROM   CBS_GRUP_URUN_SINIF
        WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
        AND    modul_tur_kod  = r_islem.modul_tur_kod
        AND    urun_tur_kod   = r_islem.urun_tur_kod
        AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

        IF ls_ana_dk_no  = 0 THEN
            ls_hata := 'Module : ' || r_islem.modul_tur_kod ||  ', Product type : ' || r_islem.urun_tur_kod ||
                       ', Product Class : ' || r_islem.urun_sinif_kod     ||  ', ' ||
                       ' Main G/L no not defined in G/L group: '||r_islem.YENI_GRUP_KODU  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
        END IF;

    --3.hata kontrolu
        -- sube degismis ise...
                SELECT COUNT(*)
                INTO   ln_sube_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_ana_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_sube_count  = 0 THEN
                    ls_hata :=  ' G/L ' || r_islem.yeni_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

    --4.hata kontrolu
        -- vadesiz ise...
        IF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz THEN
          SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_POZ,0), NVL(OVD_TOTAL_ACC_INTEREST,0) --AISULUUD CQ5721 ADDED NVL(OVD_TOTAL_ACC_INTEREST,0)
          INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ, LN_OVD_TOTAL_ACC_INTEREST --AISULUUD CQ5721 ADDED LN_OVD_TOTAL_ACC_INTEREST
          FROM   CBS_HESAP
          WHERE  hesap_no = r_islem.hesap_no ;

          IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN
                SELECT NVL(DK_HESABI_3,0)
                INTO   ls_3_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_3_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_3_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_3_dk_count  = 0 THEN
                    ls_hata :=  ' G/L: ' ||ls_3_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

                IF Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) <> Pkg_Genel.lc_al
                THEN
                    SELECT COUNT(*)
                    INTO   ln_3_dk_count
                    FROM   CBS_DKHESAP
                    WHERE  numara     = ls_3_dk_no
                    AND    doviz_kod  = Pkg_Genel.lc_al
                    AND    bolum_kodu = r_islem.sube_kodu ;

                    IF ln_3_dk_count  = 0 THEN
                        ls_hata :=  'G/L '|| ls_3_dk_no || ' is not defined with currency: ' ||
                                    Pkg_Genel.lc_al || ' and branch: ' ||
                                    r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                    END IF;
                END IF;


                SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_4_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

          END IF;
          
          --BOM AISULUUD CQ5721
          IF
          LN_OVD_TOTAL_ACC_INTEREST <>0 THEN
          SELECT NVL(DK_HESABI_8,0)
                INTO   ls_8_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_8_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_8_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_8_dk_count  = 0 THEN
                    ls_hata :=  ' G/L: ' ||ls_8_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;
          
          END IF;
          --EOM AISULUUD CQ5721
        END IF; -- hesap vadesi ise

    --5.hata kontrolu
        -- vadeli ise...
        IF r_islem.modul_tur_kod = Pkg_Hesap.modul_tur_vadeli THEN
          SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_POZ,0), nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECEN_YIL_FAIZ_TOPLAMI,0) --aisuluud cq5721 added nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECEN_YIL_FAIZ_TOPLAMI,0)
          INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ, ln_GECMIS_AYLARIN_FAIZI, ln_GECEN_YIL_FAIZ_TOPLAMI --aisuluud  cq5721 added ln_GECMIS_AYLARIN_FAIZI, ln_GECEN_YIL_FAIZ_TOPLAMI
          FROM   CBS_HESAP_VADELI
          WHERE  hesap_no = r_islem.hesap_no ;

          IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN
                SELECT NVL(DK_HESABI_3,0)
                INTO   ls_3_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_3_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_3_dk_no
                AND    doviz_kod  = Pkg_Genel.lc_al --Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)   aisuluud cq5721 replaced with Pkg_Genel.lc_al
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_3_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_3_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

                IF Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) <> Pkg_Genel.lc_al
                THEN
                    SELECT COUNT(*)
                    INTO   ln_3_dk_count
                    FROM   CBS_DKHESAP
                    WHERE  numara     = ls_3_dk_no
                    AND    doviz_kod  = Pkg_Genel.lc_al
                    AND    bolum_kodu = r_islem.sube_kodu ;

                    IF ln_3_dk_count  = 0 THEN
                        ls_hata :=  'G/L '|| ls_3_dk_no || ' is not defined with currency: ' ||
                                    Pkg_Genel.lc_al  || ' and branch: ' ||
                                    r_islem.sube_kodu  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                    END IF;
                END IF;

                SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_4_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)|| ' and branch: ' ||
                                r_islem.sube_kodu  ;


            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

          END IF;
          
          --bom aisuluud cq5721
          if nvl(ln_GECMIS_AYLARIN_FAIZI,0) <>0 or nvl(ln_GECEN_YIL_FAIZ_TOPLAMI,0)<>0 then
          
          SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_4_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;
          
          end if;
          --eom aisuluud cq5721
        END IF; -- hesap vadeli ise

    --6.hata kontrolu
        -- kredi ise...
        IF r_islem.modul_tur_kod = Pkg_Kredi.modul_tur_kod THEN
          SELECT NVL(FAIZ_ORANI,0), NVL(BIRIKMIS_FAIZ_TUTARI,0),NVL(KOMISYON_ORANI,0), NVL(BIRIKMIS_KOMISYON_TUTARI,0), nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECENYIL_FAIZ_TUTARI,0)  --aisuluud cq5721 added nvl(GECMIS_AYLARIN_FAIZI,0), nvl(GECENYIL_FAIZ_TUTARI,0)
          INTO   ln_FAIZ_ORANI , ln_BIRIKMIS_FAIZ_POZ,ln_KOMISYON_ORANI , ln_BIRIKMIS_KOMISYON, ln_GECMIS_AYLARIN_FAIZI, ln_GECENYIL_FAIZ_TUTARI  --aisuluud cq5721 added ln_GECMIS_AYLARIN_FAIZI, ln_GECENYIL_FAIZ_TUTARI
          FROM   CBS_HESAP_KREDI
          WHERE  hesap_no = r_islem.hesap_no ;

          IF ln_FAIZ_ORANI <> 0 OR ln_BIRIKMIS_FAIZ_POZ <> 0 THEN
                SELECT NVL(DK_HESABI_2,0)
                INTO   ls_2_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;
            
                SELECT COUNT(*)
                INTO   ln_2_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_2_dk_no
                AND    doviz_kod  = Pkg_Genel.lc_al     --sevalb 25042012  changed with lc --Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_2_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_2_dk_no || ' is not defined with currency: ' ||
                                Pkg_Genel.lc_al || ' and branch: ' ||
                                r_islem.sube_kodu  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;
        
            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;
                /*--B-o-m sevalb 25042012 yukaridaki kisim Pkg_Genel.lc_al olarak yapildi alta gerek kalmadi 
                IF Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) <> Pkg_Genel.lc_al
                THEN
                    SELECT COUNT(*)
                    INTO   ln_2_dk_count
                    FROM   CBS_DKHESAP
                    WHERE  numara     = ls_2_dk_no
                    AND    doviz_kod  = Pkg_Genel.lc_al
                    AND    bolum_kodu = r_islem.sube_kodu ;

                    IF ln_2_dk_count  = 0 THEN
                        ls_hata :=  'G/L '|| ls_2_dk_no || ' is not defined with currency: ' ||
                                    Pkg_Genel.lc_al || ' and branch: ' ||
                                    r_islem.sube_kodu  ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                
                    END IF;
                END IF;
                */  --E-o-m sevalb 25042012 yukaridaki kisim Pkg_Genel.lc_al olarak yapildi 
 
                SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_4_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

          END IF;

    --7.hata kontrolu
          IF ln_KOMISYON_ORANI <> 0 OR ln_BIRIKMIS_KOMISYON <> 0 THEN
                SELECT NVL(DK_HESABI_5,0)
                INTO   ls_5_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_5_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_5_dk_no
                AND    doviz_kod  = pkg_genel.lc_al  --sevalb 25042012  changed with lc --Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_5_dk_count  = 0 THEN
                    ls_hata :=  'G/L '||  ls_5_dk_no || ' is not defined with currency: ' ||
                                pkg_genel.lc_al || ' and branch: ' || -- --sevalb 25042012  changed with lc --Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;
                 /*--B-o-m sevalb 25042012 yukaridaki kisim Pkg_Genel.lc_al olarak yapildi alta gerek kalmadi
                /*
                IF Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) <> Pkg_Genel.lc_al
                THEN
                    SELECT COUNT(*)
                    INTO   ln_5_dk_count
                    FROM   CBS_DKHESAP
                    WHERE  numara     = ls_5_dk_no
                    AND    doviz_kod  = Pkg_Genel.lc_al
                    AND    bolum_kodu = r_islem.sube_kodu ;

                    IF ln_5_dk_count  = 0 THEN
                        ls_hata :=  'G/L '||  ls_5_dk_no || ' is not defined with currency: ' ||
                                    Pkg_Genel.lc_al || ' and branch: ' ||
                                    r_islem.sube_kodu ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                    END IF;
                END IF;
                */
                 --E-o-m sevalb 25042012 yukaridaki kisim Pkg_Genel.lc_al olarak yapildi alta gerek kalmadi
  
                SELECT NVL(DK_HESABI_6,0)
                INTO   ls_6_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_6_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_6_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_6_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_6_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

          END IF;
          
          --bom aisuluud cq5721
          if  (nvl(ln_GECMIS_AYLARIN_FAIZI,0)<>0 or nvl(ln_GECENYIL_FAIZ_TUTARI,0)<>0) then
          SELECT NVL(DK_HESABI_4,0)
                INTO   ls_4_dk_no
                FROM   CBS_GRUP_URUN_SINIF
                WHERE  grup_kod       = r_islem.YENI_GRUP_KODU
                AND    modul_tur_kod  = r_islem.modul_tur_kod
                AND    urun_tur_kod   = r_islem.urun_tur_kod
                AND    urun_sinif_kod = r_islem.urun_sinif_kod     ;

                SELECT COUNT(*)
                INTO   ln_4_dk_count
                FROM   CBS_DKHESAP
                WHERE  numara     = ls_4_dk_no
                AND    doviz_kod  = Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no)
                AND    bolum_kodu = r_islem.sube_kodu ;

                IF ln_4_dk_count  = 0 THEN
                    ls_hata :=  'G/L '|| ls_4_dk_no || ' is not defined with currency: ' ||
                                Pkg_Hesap.HesaptanDovizKoduAl(r_islem.hesap_no) || ' and branch: ' ||
                                r_islem.sube_kodu   ;

            SELECT COUNT(*)
            INTO ln_hata_count
            FROM CBS_MUSTERI_GKDEG_ISLEM_HATA
            WHERE tx_no = pn_islem_no
                 AND hata = ls_hata;

            IF ln_hata_count = 0
            THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;
            END IF ;
                END IF;

         end if;
         
         
          --eom aisuluud cq5721
        END IF; -- 7.kontrol
    END IF;  --- GUSIN de var
   END LOOP ;
   CLOSE c_islem;
  --BOM AntonPa CBS-643 120822 
   SELECT MIN(NUMARA) INTO LN_BLOCK_TX_NO FROM CBS.CBS_ISLEM
   WHERE ISLEM_KOD = 1001 AND DURUM = 'C' AND
        MUSTERI_NUMARA IN (SELECT MUSTERI_NO FROM CBS_MUSTERI_GKDEG_ISLEM_MASTER WHERE TX_NO = pn_islem_no);
        
   IF LN_BLOCK_TX_NO IS NOT NULL THEN
       ls_hata := 'Not approved 1001 transaction for this customer. Tx_no = ' || LN_BLOCK_TX_NO;
       INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_HATA (TX_NO,HATA) VALUES (pn_islem_no , ls_hata) ;            
   END IF;
  --EOM AntonPa CBS-643 120822
  END;
--------------------------------------------------------------------------------------------------------------
PROCEDURE BilgiAktar(pn_txno IN NUMBER,
                                        pn_musteri_no IN NUMBER,
                                        pn_eski_gk IN NUMBER,
                                        pn_yeni_gk IN NUMBER) IS
 CURSOR c1 IS
  SELECT i.*, (select k.pastdue_faiz_anapara_sec 
              from cbs_hesap_kredi k
              where k.hesap_no=i.hesap_no  ) pastdue_faiz_anapara_sec -- seval.colak 16022023  aisuluud cq5721   left outer yerine subquery
          FROM CBS_VW_HESAP_IZLEME i         
        WHERE i.musteri_no = pn_musteri_no
              AND i.durum_kodu = 'A'
              and i.urun_tur_kod  not in('NONACCRUAL') -- seval.colak 16022023 non accruallar gl leri ayni statik oldugundan buraya getirlmeyecek.
              and not exists (select 1 from cbs_hesap_kredi b where b.hesap_no =i.hesap_no and b.pastdue_faiz_anapara_sec  ='ACCRUAL-TAX' ) ;
 
R1      c1%ROWTYPE;
ln_count  NUMBER;
ls_yeni_dk     VARCHAR2(20);
ls_yeni_dk_kmh VARCHAR2(20);
ls_new_dk_interest VARCHAR2(20); --aisuluud cq5721
ls_dk_interest VARCHAR2(20);--aisuluud cq5721

 --b-o-m seval.colak 16022023
ls_ana_modul_tur_kod    varchar2(100) ;
ls_ana_urun_tur_kod varchar2(100) ; 
ls_ana_urun_sinif_kod varchar2(100) ;
ls_musteri_accrual_tax_dk_no    varchar2(100) ;
 --e-o-m seval.colak 16022023
BEGIN
DELETE
FROM CBS_MUSTERI_GKDEG_ISLEM_DETAIL
WHERE tx_no = pn_txno;

 pkg_parametre.deger('G_DK_ACCRUAL_TAX_RECEIVAL', ls_musteri_accrual_tax_dk_no); --seval.colak 16022023
 
    OPEN c1;
    LOOP
      FETCH c1 INTO  R1;
      EXIT WHEN c1%NOTFOUND;
        BEGIN
        
        ls_yeni_dk := NULL ;        --b-o-m seval.colak 16022023 seems problem related with aisuluud cq5721 there was not  set null values in cursor ,solved.
        ls_yeni_dk_kmh := NULL ;
        ls_dk_interest := NULL;
        ls_new_dk_interest := NULL; --e-o-m seval.colak 16022023 
               
        --b-o-m seval.colak 16022023
          if r1.urun_tur_kod in ('ACCRUAL','NONACCRUAL') and nvl(r1.accrual_ana_hesap_no,0) <> 0  then  --
                select modul_tur_kod,urun_tur_kod,urun_sinif_kod
                into  ls_ana_modul_tur_kod,ls_ana_urun_tur_kod,ls_ana_urun_sinif_kod
                from cbs_vw_hesap_izleme i
                where hesap_no=r1.accrual_ana_hesap_no ;      
                 
                begin
                 select  case when r1.pastdue_faiz_anapara_sec  = 'ACCRUAL-DELAYED-INTEREST' then dk_hesabi_11
                              when  r1.pastdue_faiz_anapara_sec = 'ACCRUAL-TAX'              then ls_musteri_accrual_tax_dk_no
                              else  dk_hesabi_4 end
                 into ls_yeni_dk    
                 from cbs_grup_urun_sinif 
                 where grup_kod = pn_yeni_gk
                        and modul_tur_kod = ls_ana_modul_tur_kod
                        and urun_tur_kod  =  ls_ana_urun_tur_kod
                        and urun_sinif_kod = ls_ana_urun_sinif_kod;
                   exception when others then null;
                 end;       
        -- e-o-m seval.colak seval.colak 16022023
        else 
             SELECT COUNT(*)
             INTO ln_count
             FROM CBS_GRUP_URUN_SINIF
             WHERE grup_kod = pn_yeni_gk
                    AND modul_tur_kod = R1.modul_tur_kod
                    AND urun_tur_kod = R1.urun_tur_kod
                    AND urun_sinif_kod = R1.urun_sinif_kod ;

            IF ln_count <> 0 then
              --bom aisuluud cq5721            
            SELECT  
            case when r1.PASTDUE_FAIZ_ANAPARA_SEC = 'TAX' then DK_HESABI_5
            else case when r1.PASTDUE_FAIZ_ANAPARA_SEC = 'FAIZ' then DK_HESABI_4
            else dk_hesabi_1 end end, 
            dk_hesabi_9 ,
                CASE WHEN modul_tur_kod = 'CURRENT' THEN
                DK_HESABI_8
                ELSE CASE WHEN modul_tur_kod = 'TIME DEP.' THEN
                DK_HESABI_4
                ELSE CASE WHEN modul_tur_kod = 'LOAN' THEN
                DK_HESABI_4
                END END END YENI_DK_INTEREST,
                (SELECT
                CASE WHEN modul_tur_kod = 'CURRENT' THEN
                DK_HESABI_8
                ELSE CASE WHEN modul_tur_kod = 'TIME DEP.' THEN
                DK_HESABI_4
                ELSE CASE WHEN modul_tur_kod = 'LOAN' THEN
                DK_HESABI_4
                END END END eski_DK_INTEREST
                 FROM CBS_GRUP_URUN_SINIF
                 WHERE grup_kod = pn_eski_gk
                            AND modul_tur_kod = R1.modul_tur_kod
                        AND urun_tur_kod = R1.urun_tur_kod
                        AND urun_sinif_kod = R1.urun_sinif_kod) eski_DK_INTEREST
                 INTO ls_yeni_dk, ls_yeni_dk_kmh,ls_new_dk_interest, ls_dk_interest      
                 FROM CBS_GRUP_URUN_SINIF 
                 WHERE grup_kod = pn_yeni_gk
                            AND modul_tur_kod = R1.modul_tur_kod
                        AND urun_tur_kod = R1.urun_tur_kod
                        AND urun_sinif_kod = R1.urun_sinif_kod ;
           

            --eom aisuluud cq5721
            
                 /*SELECT dk_hesabi_1,dk_hesabi_9
                 INTO ls_yeni_dk, ls_yeni_dk_kmh
                 FROM CBS_GRUP_URUN_SINIF
                 WHERE grup_kod = pn_yeni_gk
                            AND modul_tur_kod = R1.modul_tur_kod
                        AND urun_tur_kod = R1.urun_tur_kod
                        AND urun_sinif_kod = R1.urun_sinif_kod ;*/ --aisuluud cq5721 commented out by replacing with code above
            END IF;

            IF R1.OVD_DK_NO IS NULL THEN
              ls_yeni_dk_kmh := NULL;
            END IF;
            
          END IF;       --seval.colak 16022023
          
            INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_DETAIL
            (TX_NO, SUBE_KODU, HESAP_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, DOVIZ_KODU, DK_NO,YENI_DK_NO,
             KMH_DK_NO, YENI_KMH_DK_NO, DK_NO_INTEREST, NEW_DK_NO_INTEREST) --aisuluud cq5721 added DK_NO_INTEREST, NEW_DK_NO_INTEREST
            VALUES
            (pn_txno, R1.sube_kodu, R1.hesap_no, R1.MODUL_TUR_KOD, R1.URUN_TUR_KOD, R1.URUN_SINIF_KOD, R1.DOVIZ_KODU, R1.musteri_DK_NO, ls_yeni_dk,
             R1.OVD_DK_NO, ls_yeni_dk_kmh, ls_dk_interest, ls_new_dk_interest); --aisuluud cq5721 added ls_dk_interest, ls_new_dk_interest

            /*
            --ozgurc ..kmh dk lar?nda aktar?lmas? 19012007
            IF R1.kmh_dk_no IS NOT NULL THEN
                INSERT INTO CBS_MUSTERI_GKDEG_ISLEM_DETAIL
                (TX_NO, SUBE_KODU, HESAP_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, DOVIZ_KODU, DK_NO,YENI_DK_NO)
                VALUES
                (pn_txno, R1.sube_kodu, R1.hesap_no, R1.MODUL_TUR_KOD, R1.URUN_TUR_KOD, R1.URUN_SINIF_KOD, R1.DOVIZ_KODU, R1.kmh_dk_no, ls_yeni_dk_kmh);
            END IF;*/
        END;
        
         
    END LOOP;
    COMMIT ;
    CLOSE c1;
  END;
------------------------------------------------------------------
BEGIN
    p_7010_HESAP_SUBE    := Pkg_Muhasebe.parametre_index_bul('7010_HESAP_SUBE');
    p_7010_ESKI_DK        := Pkg_Muhasebe.parametre_index_bul('7010_ESKI_DK');
    p_7010_YENI_DK        := Pkg_Muhasebe.parametre_index_bul('7010_YENI_DK');
    p_7010_DOVIZ_KODU    := Pkg_Muhasebe.parametre_index_bul('7010_DOVIZ_KODU');
    p_7010_B_ACIKLAMA        := Pkg_Muhasebe.parametre_index_bul('7010_B_ACIKLAMA');
    p_7010_M_ACIKLAMA        := Pkg_Muhasebe.parametre_index_bul('7010_M_ACIKLAMA');
    p_7010_REFERANS            := Pkg_Muhasebe.parametre_index_bul('7010_REFERANS');
    p_7010_VALOR            := Pkg_Muhasebe.parametre_index_bul('7010_VALOR');
    p_7010_FC_TUTAR    := Pkg_Muhasebe.parametre_index_bul('7010_FC_TUTAR');
    p_7010_LC_TUTAR    := Pkg_Muhasebe.parametre_index_bul('7010_LC_TUTAR');
    p_7010_KUR                := Pkg_Muhasebe.parametre_index_bul('7010_KUR');
END;
/

