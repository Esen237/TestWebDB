create PACKAGE BODY     "PKG_LLP" 
--Yerzhan Tanatov
is
   procedure createllpforaccount (p_account_no    number,
                                  p_gl_code       varchar2,
                                  p_bakiye        number default 0)
   is
      n_adv_value   varchar2 (200 byte) default null ;
      n_llp_rate    number default null;
      n_sql varchar2(2000 byte);
   begin
      for r in (select   *
                  from   cbs_llp_grup_gl
                 where   gl_code = p_gl_code)
      loop
         if r.advanced = 'Y'
         then
            if r.adv_params_code is not null
            then
               begin
                 --In this package or in advanced functions,
                 --you must not select from CBS_HESAP_BAKIYE table,
                 --because this table's trigger is used for calling this function
                  for y in (select   *
                              from   cbs_llp_advanced_params
                             where   params_code = r.adv_params_code)
                  loop
                              n_sql:= 'select '
                                      || replace (upper (y.from_column),
                                                  'BAKIYE',
                                                  replace(p_bakiye,',','.'))
                                      || ' from '
                                      || y.from_table
                                      || ' where hesap_no = '
                                      || to_char (p_account_no);
                        execute immediate n_sql
                        into   n_adv_value;
                     if n_adv_value <> -1
                     then                        --if -1 then don't create llp
                        select   llp_rate
                          into   n_llp_rate
                          from   cbs_llp_grup_advanced
                         where   params_code = r.adv_params_code
                                 and value = n_adv_value;
                        createllp (p_account_no, n_llp_rate);
                     end if;
                  end loop;
               exception
                  when others
                  then
                     log_at ('createLLPforAccount',
                             'AdvancedParams',
                             n_sql,
                             sqlerrm);
                     raise_application_error (
                        -20100,
                           pkg_hata.getucpointer
                        || '7501'
                        || pkg_hata.getdelimiter
                        || to_char (p_account_no)
                        || ' '
                        || sqlerrm
                        || pkg_hata.getdelimiter
                        || pkg_hata.getucpointer
                     );
               end;
            end if;
         else
            n_llp_rate := r.llp_rate;
            createllp (p_account_no, n_llp_rate);
         end if;
      end loop;
   exception
      when others
      then
         log_at ('createLLPforAccount', p_account_no, sqlerrm);
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '7500'
            || pkg_hata.getdelimiter
            || to_char (p_account_no)
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer
         );
   end;

   --------------------------------------------
    procedure createllp (n_account     number,
                        n_llp_rate    number,
                        n_llp_amount  number default null, --BahianaB CBS-735 10102022 llp_amount added
                        n_mod_user    varchar2 default null,
                        n_mod_date    date default null) 
   is
   v_curr varchar2(5) :=null;
   v_prod varchar2(20):=null;
   v_rate number:=0;
   v_card number;
   v_overdraft number;
   
   begin
      -- parametrize LLP rate  CQ004953 UrmatA 20150824
      begin  
          select urun_tur_kod into v_prod 
          from cbs_hesap_kredi kr where KR.HESAP_NO = n_account;
      exception
            when no_data_found
            then
                select urun_tur_kod into v_prod 
                from cbs_hesap kr where KR.HESAP_NO = n_account;
      end; 
      
      if v_prod in ('PD-FIXRATE', 'PAST DUE') then
        begin
        select llp.llp_rate into v_rate 
        from cbs_hesap_kredi kr, cbs_llp_account llp 
        where kr.hesap_no = n_account
        and kr.ana_kredi_hesap_no = LLP.HESAP_NO;
        exception
            when no_data_found
            then v_rate:=0;  
        end;
      else
          begin  
          select doviz_kodu into v_curr 
          from cbs_hesap_kredi kr where KR.HESAP_NO = n_account;
          exception
            when no_data_found
            then
                select doviz_kodu into v_curr 
                from cbs_hesap kr where KR.HESAP_NO = n_account;
          end;
          select count(*) into v_card from cbs_vw_credit_card cc where CC.ACCOUNT_NO = n_account;
          select count(*) into v_overdraft from cbs_vw_real_overdraft rovd where ROVD.ACCOUNT_NO = n_account;
           
          if v_curr = 'KGS' then
            if v_card > 0 then        
                pkg_parametre.deger('LLP_RATE_KGS_CARD', v_rate);
            elsif v_overdraft > 0 then
                pkg_parametre.deger('LLP_RATE_KGS_OVERDRAFT', v_rate);
            else
                pkg_parametre.deger('LLP_RATE_KGS_LOAN', v_rate);
            end if;
          else 
          
            if v_card > 0 then        
                pkg_parametre.deger('LLP_RATE_FCUR_CARD', v_rate);
            elsif v_overdraft > 0 then
                pkg_parametre.deger('LLP_RATE_FCUR_OVERDRAFT', v_rate);
            else
            
                pkg_parametre.deger('LLP_RATE_FCUR_LOAN', v_rate);
            
            end if;
            
          end if;
      end if;
      --  CQ004953 UrmatA 20150824
       
      insert into cbs_llp_account (hesap_no, llp_rate, llp_amount)
        values   (n_account, v_rate, n_llp_amount); --BahianaB CBS-735 10102022 llp_amount added
         
   exception
      when dup_val_on_index
      then
         update   cbs_llp_account
            set   llp_rate = n_llp_rate,
                  llp_amount = n_llp_amount, --BahianaB CBS-735 10102022 llp_amount added
                  modified_staff = n_mod_user,
                  modified_date = n_mod_date
          where   hesap_no = n_account;
      when others
      then
         log_at ('createLLP', n_account, sqlerrm);
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '7502'
            || pkg_hata.getdelimiter
            || to_char (n_account)
            || ' '
            || v_rate
            || ' '
            || sqlerrm
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer
         );
   end;

   --------------------------------------------
   function gettypeofcollateral (n_hesap_no      number,
                                 n_musteri_no    number,
                                 p_bakiye        number default 0)
      return varchar2
   is
      n_teklif_no      number;
      n_per_sicil_no   number;
   begin
      select   personel_sicil_no
        into   n_per_sicil_no
        from   cbs_musteri
       where   musteri_no = n_musteri_no;

      select   tkl.teklif_no
        into   n_teklif_no
        from   cbs_kredi_teklif tkl
       where   tkl.musteri_no = n_musteri_no and tkl.durum_kodu = 'A';

      return getcreditcardgroupnumber (n_musteri_no,
                                       n_teklif_no,
                                       n_per_sicil_no);
   end;

   --------------------------------------------
   --yerzhan tanatov
   function getcreditcardgroupnumber (m_musteri_no    number,
                                      n_teklif_no     number,
                                      per_sicil_no    number)
      return int
   is
      n_return            int;
      n_teminat_kodu_03   varchar2 (2 byte);
      n_teminat_kodu_12   varchar2 (2 byte);
      n_teminat_kodu_00   varchar2 (2 byte);
      n_time_dep          int default 0 ;
   begin
      begin
         select   distinct ttem.teminat_kodu
           into   n_teminat_kodu_03
           from   cbs_kredi_teklif_teminat ttem
          where   ttem.teklif_no = n_teklif_no and ttem.teminat_kodu = '03';
      exception
         when no_data_found
         then
            begin
               select   distinct tsatir.teminat_kodu
                 into   n_teminat_kodu_03
                 from   cbs_kredi_teklif_satir_teminat tsatir
                where   tsatir.teklif_no = n_teklif_no
                        and tsatir.teminat_kodu = '03';
            exception
               when no_data_found
               then
                  n_teminat_kodu_03 := null;
            end;
      end;

      begin
         select   distinct ttem.teminat_kodu
           into   n_teminat_kodu_12
           from   cbs_kredi_teklif_teminat ttem
          where   ttem.teklif_no = n_teklif_no and ttem.teminat_kodu = '12';
      exception
         when no_data_found
         then
            begin
               select   distinct tsatir.teminat_kodu
                 into   n_teminat_kodu_12
                 from   cbs_kredi_teklif_satir_teminat tsatir
                where   tsatir.teklif_no = n_teklif_no
                        and tsatir.teminat_kodu = '12';
            exception
               when no_data_found
               then
                  n_teminat_kodu_12 := null;
            end;
      end;

      select   count (1)
        into   n_time_dep
        from   cbs_hesap_vadeli
       where   musteri_no = m_musteri_no and urun_tur_kod = 'CRED.CARD+';

      select   case
                  when per_sicil_no is not null
                  then
                     4
                  when n_time_dep > 0
                  then
                     2
                  when n_teminat_kodu_03 is not null
                  then
                     3
                  when n_teminat_kodu_12 is not null
                  then
                     1
                  when n_teminat_kodu_03 is null
                       and n_teminat_kodu_12 is null
                  then
                     5
               end
        into   n_return
        from   dual;

      return n_return;
   end;

   --------------------------------------------
   function gettypeofoverdraft (n_hesap_no      number,
                                n_musteri_no    number,
                                p_bakiye        number default 0)
      return int
   is
      n_count                      number;
      n_related_loans_tot_amount   number default 0 ;
   begin

      n_related_loans_tot_amount := pkg_llp.getrelatedloans (n_hesap_no);

      -- first check is this real overdraft
      select   count (1)
        into   n_count
        from                     cbs_musteri b
                              inner join
                                 cbs_musteri_urun_limit a
                              on     b.musteri_no = a.musteri_no
                                 and b.durum_kodu = 'A'
                                 and a.fc_limit <> 0
                                 and a.urun_grub_no in (18, 19, 20, 44, 59)
                           inner join
                              cbs_hesap c
                           on     b.musteri_no = c.musteri_no
                              and c.overdraft = 'E'
                              and c.durum_kodu = 'A'
                        inner join
                           cbs_dkhesap d
                        on     d.numara = c.ovd_dk_no
                           and d.doviz_kod = c.doviz_kodu
                           and d.bolum_kodu = c.sube_kodu
                     inner join
                        cbs_kredi_teklif e
                     on e.musteri_no = b.musteri_no and e.durum_kodu = 'A'
                  inner join
                     cbs_kredi_teklif_satir s
                  on e.teklif_no = s.teklif_no
                     and s.kredi_turu = a.urun_grub_no
               inner join
                  cbs_kredi_teklif_limit f
               on e.teklif_no = f.teklif_no
       where   c.hesap_no = n_hesap_no and p_bakiye < 0
               and ( (n_related_loans_tot_amount = 0)
                    or (abs (p_bakiye) > n_related_loans_tot_amount));

      if n_count > 0
      then
         return 1;
      end if;

      --if it's not real then check for technical overdraft
      select   count (1)
        into   n_count
        from         cbs_musteri b
                  inner join
                     cbs_hesap c
                  on b.musteri_no = c.musteri_no --and c.overdraft = 'e'
                     and c.durum_kodu = 'A'
               inner join
                  cbs_dkhesap d
               on     d.numara = c.ovd_dk_no
                  and d.doviz_kod = c.doviz_kodu
                  and d.bolum_kodu = c.sube_kodu
                  and not exists
                        (select   1
                           from   cbs_musteri_urun_limit a
                          where       b.musteri_no = a.musteri_no
                                  and b.durum_kodu = 'A'
                                  and a.fc_limit <> 0
                                  and a.urun_grub_no in (18, 19, 20, 44, 59))
       where   c.hesap_no = n_hesap_no and p_bakiye < 0
               and ( (n_related_loans_tot_amount = 0)
                    or (abs (p_bakiye) > n_related_loans_tot_amount));

      if n_count > 0
      then
         return 2;
      end if;
   return -1;
   end;

   --------------------------------------------
   function getrelatedloans (p_account number)
      return number
   is
      l_return_code   number default 0 ;
   begin
      select   sum (getinstallmentandtaxforloans (hesap_no,
                                                  anapara,
                                                  taksit,
                                                  faiz,
                                                  sira_no))
        into   l_return_code
        from   cbs_hesap_kredi_taksit
       where   odeme_tarihi = pkg_muhasebe.banka_tarihi_bul
               and hesap_no in
                        (select   hesap_no
                           from   cbs_hesap_kredi
                          where   iliskili_hesap_no = p_account
                                  and durum_kodu = 'A');

      return nvl (l_return_code, 0);
   end;

   function getinstallmentandtaxforloans (p_account               number,
                                          p_principal             number,
                                          p_installment_amount    number,
                                          p_interest              number,
                                          p_sira_no               number)
      return number
   is
      l_date                   date;
      l_return_val             number;
      l_birikmis_faiz_tutari   number;
      l_faiz_orani             number;
      l_tax_rate               number default 0.025 ;
   begin
      if p_installment_amount is null and p_interest is null
      then
         if p_sira_no = 1
         then
            select   acilis_tarihi
              into   l_date
              from   cbs_hesap_kredi
             where   hesap_no = p_account;
         else
            select   vade_tarih
              into   l_date
              from   cbs_hesap_kredi_taksit
             where   hesap_no = p_account and sira_no = p_sira_no - 1;
         end if;

         select   faiz_orani
           into   l_faiz_orani
           from   cbs_hesap_kredi
          where   hesap_no = p_account;

         l_birikmis_faiz_tutari :=
            round (
               (pkg_muhasebe.banka_tarihi_bul - l_date)
               * (abs (pkg_hesap.hesapbakiyeal (p_account))
                  + nvl (p_principal, 0))
               * (l_faiz_orani / 100)
               / 360,
               4
            );
         l_return_val :=
              l_birikmis_faiz_tutari * l_tax_rate
            + l_birikmis_faiz_tutari
            + p_principal;
      elsif p_installment_amount is not null and p_interest is null
      then
         if p_sira_no = 1
         then
            select   acilis_tarihi
              into   l_date
              from   cbs_hesap_kredi
             where   hesap_no = p_account;
         else
            select   vade_tarih
              into   l_date
              from   cbs_hesap_kredi_taksit
             where   hesap_no = p_account and sira_no = p_sira_no - 1;
         end if;

         select   faiz_orani
           into   l_faiz_orani
           from   cbs_hesap_kredi
          where   hesap_no = p_account;

         l_birikmis_faiz_tutari :=
            round (
               (pkg_muhasebe.banka_tarihi_bul - l_date)
               * (abs (pkg_hesap.hesapbakiyeal (p_account))
                  + nvl (p_principal, 0))
               * (l_faiz_orani / 100)
               / 360,
               4
            );
         l_return_val :=
            l_birikmis_faiz_tutari * l_tax_rate + p_installment_amount;
      elsif p_installment_amount is not null and p_interest is not null
      then
         l_return_val := p_installment_amount + l_tax_rate * p_interest;
      end if;

      return nvl (l_return_val, 0);
   exception when no_data_found then
   return 0;
   end;
/******************************************************************************
   NAME       : PROCEDURE setPDcardRatesStr
   Created By : Urmat Aymambetov
   Date       : 13.04.2016
   Purpose    : CQ5257 urmata 13042016 New procedure for set rates to PD cards
******************************************************************************/
   procedure setPDcardRatesStr(p_str IN varchar)
   is
    ln_pd_acc_no number;
    ln_cust_no   number;
    ln_pd_rate   number;
    str_len    number;
    ln_pd_days number;
    ls_str varchar2(100);
       
    CURSOR c_pd_card(pn_cust_no number) IS
    SELECT h.hesap_no from cbs_hesap_kredi h
    where H.MUSTERI_NO = pn_cust_no
    and ((H.URUN_SINIF_KOD in ('CRD.CARD-LC','CREDIT CARD-LC')) or H.URUN_TUR_KOD = 'CRD.CARD');
    
   begin
    ls_str := regexp_replace(p_str,'[[:cntrl:]]');
    ln_cust_no :=  (substr(ls_str, 1, instr(ls_str, ';')-1)); 
    str_len := instr(ls_str, ';');
    ls_str := substr(ls_str, str_len+1, length(ls_str)-instr( ls_str, ';')+1);
    ln_pd_days :=  ls_str;                            
   
   OPEN c_pd_card(ln_cust_no);
     LOOP
         FETCH c_pd_card
         INTO ln_pd_acc_no; 
         EXIT WHEN c_pd_card%NOTFOUND;
                                    
         select r.rate into ln_pd_rate from cbs_llp_rate r
         where ln_pd_days >= R.MIN_DAYS and ln_pd_days <= R.MAX_DAYS;               
                   
         update cbs_llp_account 
         set llp_rate = ln_pd_rate
             ,modified_staff = user
             ,modified_date = sysdate
         where hesap_no = ln_pd_acc_no;
             
     END LOOP;
     commit;
   exception when no_data_found then
    log_at('Set PD card rate no_data_found');
            when Others Then
    log_at('Set PD card rate',substr(sqlerrm,1,2000));
   end;
end;
/

