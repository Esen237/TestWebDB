create PACKAGE Pkg_Tx6060 IS

/******************************************************************************
   Name       : PKG_TX6060
   Created By : G?lnihal Cengiz
   Date    	  : 06/02/2004
   Purpose	  : Menkul K?ymet Musteri Al?m Sisteme Tan?mlamas?
******************************************************************************/
  FUNCTION  MenkulMusteriAlim_Referansi_Al RETURN VARCHAR2;
  FUNCTION  Sf_Menkul_UrunTuru_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Depo_Turu_Uygunmu(ps_depo_turu CBS_DEPO_TUR_KODLARI.kod%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Uygun_Stok_Kodu(ps_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  PROCEDURE Menkul_MustAlim_StokTbl_Yarat(pn_islem_no NUMBER,
 										   ps_mk_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
										   ps_referans CBS_MENKUL_MUSTERI_ALIM_ISLEM.referans_no%TYPE DEFAULT NULL,
										   pn_temiz_fiyat  NUMBER DEFAULT 0,
										   pn_kirli_fiyat  NUMBER DEFAULT 0,
										   pn_dovend_fiyat NUMBER DEFAULT 0,
										   pn_musteri_no   NUMBER DEFAULT NULL);

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

