create PACKAGE BODY     Pkg_Tx1205 IS
	pn_1205_banka_aciklama          NUMBER;
	pn_1205_tahsilhesap_sube        NUMBER;
	pn_1205_tahsilhesap_no        	NUMBER;
	pn_1205_tahsilhesap_doviz       NUMBER;
	pn_1205_musteri_aciklama        NUMBER;
	pn_1205_fis_aciklama        	NUMBER;
	pn_1205_referans        		NUMBER;
	pn_1205_muhabirhesap_no        	NUMBER;
	pn_1205_muhabir_doviz        	NUMBER;
	pn_1205_islem_subesi        	NUMBER;
	pn_1205_muhabirhesap_sube       NUMBER;
	pn_1205_lc_tutar        		NUMBER;
	pn_1205_kur_lc        			NUMBER;
	pn_1205_kur						NUMBER;
	pn_1205_vergi_tutar        		NUMBER;
	pn_1205_fc_tutar        		NUMBER;
	pn_1205_tahsilsekli_dth_ise     NUMBER;
	pn_1205_tahsilsekli_bunye       NUMBER;
	pn_1205_tahsilsekli_tl        	NUMBER;
	pn_1205_dsb_istatistik_kodu	    NUMBER;
    pn_1205_istatistik_kodu_borc   	NUMBER;
    pn_1205_istatistik_kodu_alacak 	NUMBER;
    pn_1205_dk_no					NUMBER;
 PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
  ln_hesap_no number;
  BEGIN
   select TAHSIL_HESAP_NO
   into ln_hesap_no
   from CBS_MUHABIRMASRAF_DOVSATISISL
   where tx_no=pn_islem_no;

   pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1205',ln_hesap_no);

  END;

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
 BEGIN
 	  NULL;
     --pkg_dsb.DSB_IPTAL(pn_islem_no);
 END;

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	Pkg_Tx1205.Onay_Sonrasi_Kur_Guncelle(pn_islem_no);
  END;


  PROCEDURE Onay_Sonrasi_Kur_Guncelle(pn_islem_no NUMBER) IS
	ln_kur 	         CBS_DTH_TL_ODEME_ISLEM.kur%TYPE;
	ls_doviz_kodu	 CBS_MUHABIRMASRAF_DOVSATISISL.doviz_kodu%TYPE;
  BEGIN

/* BDSK kuru ile guncellenir */
		UPDATE CBS_MUHABIRMASRAF_DOVSATISISL
		SET kur =Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','S')
		WHERE tx_no = pn_islem_no ;

  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;


  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

---------------------------------------------------------------------------
  Function sf_istatistikkod_zorunlumu(pn_musteri_no number) return varchar2
  is
   ls_musteri_tipi_kod	varchar2(1);
   ln_dk_grup_kod		number;
  Begin
  	   select musteri_tipi_kod,
	   		  dk_grup_kod
	   into  ls_musteri_tipi_kod,
	   		 ln_dk_grup_kod
	   from  cbs_musteri
	   where musteri_no = pn_musteri_no ;

	   if ln_dk_grup_kod = 1023  Then
	   	  return 'E';
	   else
	   	  return 'H';
	   end if;

	  Exception
	    when others then return 'H';
  End;
 ---------------------------------------------------------------------------
 PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;
	ls_aciklama				   VARCHAR2(2000);
	ln_fis_no				   CBS_FIS.numara%TYPE ;
	ls_islem_kod               CBS_ISLEM.islem_kod%TYPE :='1205';
	ls_musteri_aciklama        VARCHAR2(2000);
	ls_banka_aciklama          VARCHAR2(2000);
	ls_fis_aciklama            VARCHAR2(2000);
	ls_dsb_istatistik_kodu     VARCHAR2(2000);
	ls_vergilimi			   CBS_MUHABIRMASRAF_DOVSATISISL.vergilimi%TYPE;
	ls_tahsil_sekli			   CBS_MUHABIRMASRAF_DOVSATISISL.tahsil_sekli%TYPE;
	ln_kmv_oran 			   NUMBER;
	ln_deger				   NUMBER;
	ln_musteri_no			   NUMBER;
	ln_borc_musteri_no 		   NUMBER;
	ln_alacak_musteri_no	   NUMBER;
	ls_sube_adi				   VARCHAR2(2000);
	ls_istatistik_kodu		   VARCHAR2(2000);
	CURSOR islem_cursor IS
		SELECT
			Pkg_Tx.Amir_BolumKodu_Al(tx_no),
			muhabir_hesap_no,
			Pkg_Hesap.HESAPTANSUBEAL(muhabir_hesap_no),
			doviz_kodu,
			aciklama,
			--TO_CHAR(muhabir_hesap_no),
			Pkg_Hesap.HESAPTANDOVIZKODUAL(tahsil_hesap_no),
			tahsil_hesap_no,
			Pkg_Hesap.HESAPTANSUBEAL(tahsil_hesap_no),
			tutar,
			NVL(Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.LC_AL,NULL,tutar,1,NULL,NULL,'N','S'),0) ,
			kur ,
			vergilimi,
			tahsil_sekli,
			Pkg_Hesap.HESAPTANMUSTERINOAL(muhabir_hesap_no),
			ISTATISTIK_KODU istatistik_kodu,
			NVL(ILISKILI_REFERANS,TO_CHAR(muhabir_hesap_no)),
			dk_no
	    FROM CBS_MUHABIRMASRAF_DOVSATISISL
	    WHERE tx_no = pn_islem_no ;
  BEGIN

			number_list(pn_1205_fc_tutar) := 0;
			number_list(pn_1205_lc_tutar) := 0;
			number_list(pn_1205_kur_lc)   := 0;
			number_list(pn_1205_kur)   	  := 1;
			number_list(pn_1205_vergi_tutar) := 0;
			varchar_list(pn_1205_referans) := null;
/* islem bilgisi detaylari alinir */
	 IF islem_cursor%isopen THEN
	   CLOSE islem_cursor;
	 END IF;

  	   OPEN islem_cursor;
	    FETCH islem_cursor INTO
			varchar_list(pn_1205_islem_subesi),
			varchar_list(pn_1205_muhabirhesap_no),
			varchar_list(pn_1205_muhabirhesap_sube),
			varchar_list(pn_1205_muhabir_doviz),
			ls_aciklama,
			--varchar_list(pn_1205_referans),
			varchar_list(pn_1205_tahsilhesap_doviz),
			varchar_list(pn_1205_tahsilhesap_no),
			varchar_list(pn_1205_tahsilhesap_sube),
			number_list(pn_1205_fc_tutar),
			number_list(pn_1205_lc_tutar),
			number_list(pn_1205_kur_lc),
			ls_vergilimi,
			ls_tahsil_sekli,
			ln_musteri_no,
			ls_istatistik_kodu,
			varchar_list(pn_1205_referans),
			varchar_list(pn_1205_dk_no)	;

	   IF islem_cursor%NOTFOUND THEN
	          CLOSE islem_cursor;
       END IF;
	   CLOSE islem_cursor;

/*** Liste Deger Atama Kismi **/

/**** varchar list ****/
   Pkg_Parametre.deger('1205_FIS_ACIKLAMA',ls_fis_aciklama);
   Pkg_Parametre.deger('1205_BANKA_ACIKLAMA',ls_banka_aciklama);
   Pkg_Parametre.deger('1205_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   Pkg_Parametre.deger('1205_DSB_ISTATISTIK_KODU',ls_dsb_istatistik_kodu);

   varchar_list(pn_1205_fis_aciklama) 	 := NVL(ls_fis_aciklama,ls_aciklama);
   varchar_list(pn_1205_banka_aciklama)  := NVL(ls_banka_aciklama,ls_aciklama);
   varchar_list(pn_1205_musteri_aciklama):= NVL(ls_musteri_aciklama,ls_aciklama); --ls_musteri_aciklama;

  --sevalb 260507
   ln_borc_musteri_no := Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(pn_1205_tahsilhesap_no)) ;
   if  PKG_TX1203.sf_istatistikkod_zorunlumu (ln_borc_musteri_no ,varchar_list(pn_1205_muhabir_doviz) )= 'E' then
  	   varchar_list(pn_1205_istatistik_kodu_borc)  := pkg_musteri.paymentkod_formatli_al( ln_borc_musteri_no ,ls_istatistik_kodu) ;
   else
      varchar_list(pn_1205_istatistik_kodu_borc)  := null;
   end if;

   if varchar_list(pn_1205_muhabirhesap_no) is not null then
     ln_alacak_musteri_no :=Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(pn_1205_muhabirhesap_no));
     varchar_list(pn_1205_istatistik_kodu_alacak)  := pkg_musteri.paymentkod_formatli_al( ln_alacak_musteri_no ,ls_istatistik_kodu) ;
	else
	varchar_list(pn_1205_istatistik_kodu_alacak):= null;
   end if;
/**** boolean list ****/
	boolean_list(pn_1205_tahsilsekli_dth_ise) := FALSE;
	boolean_list(pn_1205_tahsilsekli_tl) := FALSE;
	boolean_list(pn_1205_tahsilsekli_BUNYE) := FALSE;

	IF ls_tahsil_sekli = 'DTH' THEN
	   boolean_list(pn_1205_tahsilsekli_dth_ise) := TRUE;
	 ELSIF 	ls_tahsil_sekli = 'TL' THEN
	   boolean_list(pn_1205_tahsilsekli_tl) := TRUE;
    ELSE
	   boolean_list(pn_1205_tahsilsekli_BUNYE) := TRUE;
	 END IF;
	 number_list(pn_1205_kur) := number_list(pn_1205_kur_lc) ;
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=Pkg_Muhasebe.fis_kes(ls_islem_kod,
								    NULL,
									pn_islem_no,
									varchar_list ,
									number_list  ,
									date_list    ,
									boolean_list ,
									NULL,
									FALSE,
									0,
									ls_fis_aciklama);

	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

	/* dth dsindakiler icin dsb uretilir */
	IF ls_tahsil_sekli <> 'DTH' THEN

		SELECT
		Pkg_Genel.BOLUM_ADI_AL(varchar_list(pn_1205_islem_subesi))
		INTO ls_sube_adi
		FROM CBS_ISLEM
		WHERE numara = pn_islem_no ;

	END IF;
 END;

BEGIN
	pn_1205_dsb_istatistik_kodu :=Pkg_Muhasebe.parametre_index_bul('1205_DSB_ISTATISTIK_KODU');
	pn_1205_lc_tutar :=Pkg_Muhasebe.parametre_index_bul('1205_LC_TUTAR');
	pn_1205_fc_tutar :=Pkg_Muhasebe.parametre_index_bul('1205_FC_TUTAR');
	pn_1205_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1205_BANKA_ACIKLAMA');
	pn_1205_tahsilhesap_sube :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILHESAP_SUBE');
	pn_1205_tahsilhesap_no :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILHESAP_NO');
	pn_1205_tahsilhesap_doviz :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILHESAP_DOVIZ');
	pn_1205_muhabirhesap_sube :=Pkg_Muhasebe.parametre_index_bul('1205_MUHABIRHESAP_SUBE');
	pn_1205_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1205_MUSTERI_ACIKLAMA');
	pn_1205_referans :=Pkg_Muhasebe.parametre_index_bul('1205_REFERANS');
	pn_1205_fis_aciklama :=Pkg_Muhasebe.parametre_index_bul('1205_FIS_ACIKLAMA');
	pn_1205_kur_lc :=Pkg_Muhasebe.parametre_index_bul('1205_KUR_LC');
	pn_1205_tahsilsekli_dth_ise :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILSEKLI_DTH_ISE');
	pn_1205_islem_subesi :=Pkg_Muhasebe.parametre_index_bul('1205_ISLEM_SUBESI');
	pn_1205_muhabirhesap_no :=Pkg_Muhasebe.parametre_index_bul('1205_MUHABIRHESAP_NO');
	pn_1205_muhabir_doviz :=Pkg_Muhasebe.parametre_index_bul('1205_MUHABIR_DOVIZ');
	pn_1205_tahsilsekli_tl :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILSEKLI_TL');
    pn_1205_tahsilsekli_bunye :=Pkg_Muhasebe.parametre_index_bul('1205_TAHSILSEKLI_BUNYE');
	pn_1205_vergi_tutar :=Pkg_Muhasebe.parametre_index_bul('1205_VERGI_TUTAR');
	pn_1205_istatistik_kodu_borc :=Pkg_Muhasebe.parametre_index_bul('1205_ISTATISTIK_KODU_BORC');
	pn_1205_istatistik_kodu_alacak :=Pkg_Muhasebe.parametre_index_bul('1205_ISTATISTIK_KODU_ALACAK');
	pn_1205_kur :=Pkg_Muhasebe.parametre_index_bul('1205_KUR');
	pn_1205_dk_no :=Pkg_Muhasebe.parametre_index_bul('1205_DK_NO');
END ;
/

