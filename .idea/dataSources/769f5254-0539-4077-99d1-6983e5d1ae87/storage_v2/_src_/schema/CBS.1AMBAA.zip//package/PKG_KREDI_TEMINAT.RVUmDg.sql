create PACKAGE PKG_KREDI_TEMINAT IS

  Function  KrediTeminatAltKodAdi(ps_ana_tem_kodu in cbs_teminat_alt_kodlari.TEMINAT_KODU%type,ps_alt_tem_kodu in cbs_teminat_alt_kodlari.TEMINAT_ALT_KODU%type) return varchar2;
  Function  KrediTeminatAnaKodAdi(ps_ana_tem_kodu in cbs_teminat_kodlari.TEMINAT_KODU%type) return varchar2;
  Function  KrediTeminatKullanilmismi(pn_musteri_no in cbs_kredi_teminat_tanim.MUSTERI_NO%type,pn_teminat_sira_no in cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type) return varchar2;
  Function  KrediTeminatKullanimTutari(pn_musteri_no in cbs_kredi_teminat_tanim.MUSTERI_NO%type,pn_teminat_sira_no in cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type) return number;
  Function  Sf_Kredi_Teminat_SiraNo_Al(pn_musteri_no cbs_musteri.musteri_no%type ) return cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type;
  END;

/

