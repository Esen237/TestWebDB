create PACKAGE     PKG_TX6332 IS

/******************************************************************************
   Name       : PKG_TX6332
   Created By : Seval Balci
   Date       : 11.05.2012
   Purpose    : USIP Payment Transfer from Intermediata Account to Main Account 
    (1203 Virmandan baz alinmistir)
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure    Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  Function  sf_istatistikkod_zorunlumu(pn_musteri_no number  ,ps_doviz_kodu varchar2) return varchar2;
  Procedure sp_urun_tur_sinif_al(pn_fromaccountno   IN       VARCHAR2,
                                   pn_toaccountno     IN       VARCHAR2,
                                 ps_currencycode    IN       VARCHAR2,
                                 ps_from_internet   in            varchar2 default null,
                                 ps_modul_tur        out         varchar2,
                                 ps_urun_tur         out       varchar2,
                                 ps_urun_sinif         out varchar2 );
Procedure Batch_Muhasebelesme(pn_islem_no number,pn_fis_no out number);              -- Islemin muhasebelesmesi icin cagrilir


END;

/

