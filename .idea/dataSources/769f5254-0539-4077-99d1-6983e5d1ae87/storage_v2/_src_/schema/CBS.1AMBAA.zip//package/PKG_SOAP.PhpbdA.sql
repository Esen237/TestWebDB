create PACKAGE     "PKG_SOAP" AS

  /* A type to represent a SOAP RPC request */
  TYPE request IS RECORD (
    method     VARCHAR2(256),
    namespace  VARCHAR2(256),
    body       VARCHAR2(32767),
    header_method VARCHAR2(256), -- AdiletK Kompanion Sponsorship	
    header    VARCHAR2(16384));


  /* A type to represent a SOAP RPC response */
  TYPE response IS RECORD (
    doc xmltype);

  /*
   * Create a new SOAP RPC request.
   */
  FUNCTION new_request(method    IN VARCHAR2,
                       namespace IN VARCHAR2)
                       RETURN request;
-- BOM AdiletK Kompanion Sponsorship	
  /*
   * Create a new SOAP RPC header.
   * AdiletK new web service Card Operations
   */
  PROCEDURE new_header(req   IN OUT NOCOPY request,
                       header_method    IN VARCHAR2,
                       header IN CLOB);
-- EOM AdiletK Kompanion Sponsorship	
  /*  
   * Add a simple parameter to the SOAP RPC request.
   */
  PROCEDURE add_parameter(req   IN OUT NOCOPY request,
                          name  IN VARCHAR2,
                          type  IN VARCHAR2,
                          value IN VARCHAR2);

  /*
   * Make the SOAP RPC call.
   */
  FUNCTION invoke_utf8(req    IN OUT NOCOPY request,
                       url    IN VARCHAR2,
                       action IN VARCHAR2) RETURN response;

  /*
   * Retrieve the sipmle return value of the SOAP RPC call.
   */
  FUNCTION get_return_value(resp      IN OUT NOCOPY response,
                            name      IN VARCHAR2,
                            namespace IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION get_value(source_str in varchar2, search_str in varchar2, start_pos in out number) return varchar2;
  /*
   * Make the SOAP RPC call.
   */
  FUNCTION invoke_utf8_v11(req    IN OUT NOCOPY request,
                           url    IN VARCHAR2,
                           action IN VARCHAR2) RETURN response;

    /*******************************************************************************
        Name        :invoke_utf8_v11_cib_clob
        Prepared By :Chyngyz Omurov
        Date:       07.08.2014
        Base Project :  CQ614 - CIB Automatization
        Purpose     :  to make web service call to CIB for credit history retrieval
    *******************************************************************************/
  FUNCTION invoke_utf8_v11_cib_clob(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response;
                              
   /*******************************************************************************
    Name        :invoke_utf8_v11_cib_binary
    Prepared By :Chyngyz Omurov
    Date:       :07.08.2014
    Base Project :  CQ614 - CIB Automatization
    Purpose     : to download excel file from CIB
*******************************************************************************/
  FUNCTION invoke_utf8_v11_cib_binary(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN BLOB;

  PROCEDURE generate_envelope_mi(req IN OUT NOCOPY request,
                                 env IN OUT NOCOPY clob);                          

  FUNCTION invoke_utf8_v11_mi(req    IN OUT NOCOPY request,
                              url    IN VARCHAR2, 
                              action IN VARCHAR2) RETURN response;
-- BOM AdiletK Kompanion Sponsorship							  
    /*******************************************************************************
        Name        :invoke_utf8_v11_card
        Prepared By :Adilet Kachkeev
        Date:       23.11.2016
        Base Project :  New call to web service from Card Operations Dep
        Purpose     :  to make web service call to Card Operation's server
    *******************************************************************************/
  FUNCTION invoke_utf8_v11_card(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response;
-- EOM AdiletK Kompanion Sponsorship	

    /*******************************************************************************
        Name        : invoke_utf8_v11_auto_credit
        Prepared By : Askhat Serikov
        Date        : 09.10.2017
        Base Project : CQ5453 New call to web service from Card Operations Dep
        Purpose     : to make web service call to Card Operation's server.create xml from CLOB
    *******************************************************************************/
  FUNCTION invoke_utf8_v11_auto_credit(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response;                              

  /*******************************************************************************
    Name            :invoke_utf8_v11_card_clob
    Prepared By     :NursultanSa
    Date:           :18.07.2022
    Base Project    :CBS-415
    Purpose         :Web service from Card Operations Dep, answer more than 32767 bytes
  *******************************************************************************/  
  FUNCTION invoke_utf8_v11_card_clob(req  IN OUT NOCOPY request,
                              url    IN VARCHAR2,
                              action IN VARCHAR2) RETURN response;  					  
END;
/

