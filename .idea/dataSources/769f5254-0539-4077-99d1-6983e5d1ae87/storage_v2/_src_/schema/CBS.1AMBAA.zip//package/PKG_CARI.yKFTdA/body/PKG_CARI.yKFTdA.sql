create PACKAGE BODY     "PKG_CARI" IS

  FUNCTION Modul_Tur_CURROPS RETURN VARCHAR2
  IS
  BEGIN
     RETURN 'CURR.OPS.';
  END;

 FUNCTION  Vdl_Mevduat_vade_kontrol RETURN NUMBER
  IS
    ln_sonuc        NUMBER;
    ln_vade_1        NUMBER;
    ln_vade_2        NUMBER;
    ln_vade_11        NUMBER;
    ln_vade_22        NUMBER;

    CURSOR c_vade IS
    SELECT vade_1,vade_2
    FROM   CBS_VADELI_MEVDUAT_VADE_GSAYI
    WHERE  gecerli='E'
    ORDER BY vade_1;

    CURSOR c_vade_aralik IS
    SELECT vade_1,vade_2
    FROM   CBS_VADELI_MEVDUAT_VADE_GSAYI
    WHERE  gecerli='E'
    ORDER BY vade_1 ;

  BEGIN
      ln_sonuc := 0 ;
      OPEN c_vade ;
    LOOP
      FETCH  c_vade INTO ln_vade_1,ln_vade_2;
      EXIT WHEN c_vade%NOTFOUND;

           OPEN c_vade_aralik ;
        LOOP
          FETCH  c_vade_aralik INTO ln_vade_11,ln_vade_22;
          EXIT WHEN c_vade_aralik%NOTFOUND;
              IF ln_vade_1 <> ln_vade_11 AND ln_vade_2 <> ln_vade_22 THEN
                IF ln_vade_1 >= ln_vade_11 AND ln_vade_1 <= ln_vade_22 THEN
                   ln_sonuc := 1 ;
                   EXIT ;
                END IF ;
                IF ln_vade_2 >= ln_vade_11 AND ln_vade_2 <= ln_vade_22 THEN
                   ln_sonuc := 1 ;
                   EXIT ;
                END IF ;

            END IF;
        END LOOP;
        CLOSE c_vade_aralik;

    END LOOP;
    CLOSE c_vade;

    RETURN ln_sonuc ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4538' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
 FUNCTION  VDL_MEV_ORAN_INSERT_KONROL(pd_tarih      CBS_CARI_VADELI_MEVDUAT_FO.tarih%TYPE) RETURN NUMBER
  IS
    ln_count        NUMBER;
  BEGIN
         /* ln_count = 0 ise islem yapilabilir. ln_count = 1 ise islem yapilamaz.*/
         log_at('cbs_33_2',1);
    SELECT COUNT(*)
    INTO   ln_count
    FROM   CBS_CARI_VADELI_MEVDUAT_FO
    WHERE  tarih = pd_tarih;
log_at('cbs_33_2',1);
    IF ln_count <> 0 THEN
       ln_count := 1 ;
    END IF;

log_at('cbs_33_2',2);
    RETURN ln_count ;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2663' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/

 PROCEDURE  VDL_MEV_ORAN_TBL_HAZIRLA(pn_islem_no NUMBER)

  IS

  BEGIN
  log_at('cbs_33_2',3);
      INSERT INTO CBS_CARI_VADELI_MEVDUAT_FOISL
        (TX_NO, TARIH, VADE_1, VADE_2, TRL, USD, EUR, GBP, RUB,KZT,CHF,CNY,DVZ1, DVZ2, MUSTERI_TIPI) -- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
        SELECT pn_islem_no,Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul,
                    vade_1,vade_2,0,0,0,0,0,0,0,0,0,0,'1'
         FROM CBS_VADELI_MEVDUAT_VADE_GSAYI
         WHERE      gecerli='E'
         ORDER BY vade_1,vade_2;

         INSERT INTO CBS_CARI_VADELI_MEVDUAT_FOISL
        (TX_NO, TARIH, VADE_1, VADE_2, TRL, USD, EUR, GBP, RUB,KZT,CHF,CNY,DVZ1, DVZ2, MUSTERI_TIPI) -- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
        SELECT pn_islem_no,Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul,
                    vade_1,vade_2,0,0,0,0,0,0,0,0,0,0,'2'
         FROM CBS_VADELI_MEVDUAT_VADE_GSAYI
         WHERE      gecerli='E'
         ORDER BY vade_1,vade_2;
         log_at('cbs_33_2',4);

    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2645' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
/*******************************************************/
PROCEDURE  VDL_MEV_ORAN_SON_GUN_KOPYALA(pn_islem_no NUMBER)
IS
BEGIN
      INSERT INTO CBS_CARI_VADELI_MEVDUAT_FOISL
    (TX_NO, TARIH, MUSTERI_TIPI, VADE_1, VADE_2, TRL, USD, EUR, GBP, RUB,KZT,CHF,CNY,DVZ1, DVZ2)-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
    select pn_islem_no,Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul,
    musteri_tipi,vade1,  vade2, tr, us,  eu,  gb,rb,kz,cf,cy , dv1,  dv2-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
    from(
/*
            SELECT '1' MUSTERI_TIPI, vade_1 vade1,vade_2 vade2 ,0 tr,0 us,0 eu,0 gb,0 dv1,0 dv2
            FROM  CBS_VADELI_MEVDUAT_VADE_GSAYI
            where  vade_1 not in (select b.vade_1 from CBS_CARI_VADELI_MEVDUAT_FO b where b.tarih =pkg_muhasebe.Banka_Tarihi_Bul)
            or vade_2 not in (select c.vade_2 from CBS_CARI_VADELI_MEVDUAT_FO c where c.tarih =pkg_muhasebe.Banka_Tarihi_Bul)
            and gecerli='E'
        UNION ALL
            SELECT '2' MUSTERI_TIPI, vade_1 vade1,vade_2 vade2 ,0 tr,0 us,0 eu,0 gb,0 dv1,0 dv2
            FROM  CBS_VADELI_MEVDUAT_VADE_GSAYI
            where  vade_1 not in (select b.vade_1 from CBS_CARI_VADELI_MEVDUAT_FO b where b.tarih =pkg_muhasebe.Banka_Tarihi_Bul)
            or vade_2 not in (select c.vade_2 from CBS_CARI_VADELI_MEVDUAT_FO c where c.tarih =pkg_muhasebe.Banka_Tarihi_Bul)
            and gecerli='E'
        UNION ALL
*/
            SELECT MUSTERI_TIPI MUSTERI_TIPI, VADE_1 vade1, VADE_2 vade2, TRL tr, USD us, EUR eu, GBP gb,RUB rb,KZT kz,CHF cf,CNY cy, DVZ1 dv1, DVZ2 dv2-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
            FROM  CBS_CARI_VADELI_MEVDUAT_FO
            where   tarih =pkg_muhasebe.Banka_Tarihi_Bul
        );
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2645' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
/*******************************************************/
  FUNCTION VDL_MEV_ORAN_GNC_CTRL(pd_tarih    CBS_CARI_VADELI_MEVDUAT_FO.tarih%TYPE) RETURN NUMBER
   IS
    ln_sonuc      NUMBER;
    ln_txno      NUMBER;
    ln_count     NUMBER;

  BEGIN
    --    ln_sonuc = 0 ise guncellenemez,ln_sonuc=1 guncellenebilir
log_at('cbs_33_2',5);
    SELECT NVL(MAX(tx_no),0)
    INTO   ln_txno
    FROM   CBS_CARI_VADELI_MEV_ORANGNC
    WHERE  tarih        = pd_tarih
    AND    durum_kodu  = 'G';

    ln_sonuc := Pkg_Tx.islem_bitmis_mi(ln_txno) ;
log_at('cbs_33_2',6);

    RETURN ln_sonuc  ;
      EXCEPTION
          WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2702' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
  /***************************************/
 PROCEDURE VDL_MEV_ORAN_BILGIAKTAR(pd_tarih    CBS_CARI_VADELI_MEVDUAT_FO.tarih%TYPE,pn_txno NUMBER) IS
  BEGIN
        INSERT INTO CBS_CARI_VADELI_MEV_ORANGNC
        (tx_no, tarih, durum_kodu )
        VALUES
        (pn_txno, pd_tarih, 'A' );
        log_at('cbs_33_2',7);
         INSERT INTO CBS_CARI_VADELI_MEVDUAT_FOGNC
        (TX_NO, TARIH, MUSTERI_TIPI, VADE_1, VADE_2, TRL, USD, EUR, GBP,RUB,KZT,CHF,CNY, DVZ1, DVZ2, period_code)-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
        (select pn_txno,pd_tarih,
                MUSTERI_TIPI, vade1,  vade2,  tr,  us,  eu,  gb,rb,kz,cf,cy ,  dv1,  dv2, period_code-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
         from(
/*
             SELECT '1' MUSTERI_TIPI,vade_1 vade1,vade_2 vade2 ,0 tr,0 us,
                    0 eu,0 gb,0 dv1,0 dv2
             FROM CBS_VADELI_MEVDUAT_VADE_GSAY
             where vade_1 not in (select b.vade_1 from CBS_CARI_VADELI_MEVDUAT_FO b where b.tarih = pd_tarih)
                or vade_2 not in (select c.vade_2 from CBS_CARI_VADELI_MEVDUAT_FO c where c.tarih = pd_tarih)
                 and gecerli='E'
            UNION ALL
                SELECT '2' MUSTERI_TIPI,vade_1 vade1,vade_2 vade2 ,0 tr,0 us,
                       0 eu,0 gb,0 dv1,0 dv2
                FROM CBS_VADELI_MEVDUAT_VADE_GSAY
                where vade_1 not in (select b.vade_1 from CBS_CARI_VADELI_MEVDUAT_FO b where b.tarih = pd_tarih)
                   or vade_2 not in (select c.vade_2 from CBS_CARI_VADELI_MEVDUAT_FO c where c.tarih = pd_tarih)
                  and gecerli='E'
            UNION ALL
*/
                SELECT MUSTERI_TIPI MUSTERI_TIPI,VADE_1 vade1, VADE_2 vade2, TRL tr, USD us,
                       EUR eu, GBP gb,RUB rb,KZT kz,CHF cf,CNY cy, DVZ1 dv1, DVZ2 dv2, period_code-- CQ5328 Additional fields for 6204,6205 KonstantinJ 11042016 (RUB,KZT,CHF,CNY)
                FROM CBS_CARI_VADELI_MEVDUAT_FO
                where tarih = pd_tarih
                ));
          log_at('cbs_33_2',8);
--Temirlan cbs-33 added a new column 'period_code'
    EXCEPTION
           WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2443' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

  END;
 /*******************************************************/
 END Pkg_Cari;
/

