create PACKAGE BODY     pkg_masraf_tx22030  IS

p_22030_FC_MSRF_DOVIZ_KODU        NUMBER;
p_22030_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_22030_KUR						  NUMBER;
p_22030_REFERENCE				  NUMBER;
p_22030_ISTA_KOD				  NUMBER;
p_22030_MUS_ACIK				  NUMBER;
p_22030_BANKA_ACIK				  NUMBER;
p_22030_ISLEM_SUBE				  NUMBER;
p_22030_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_22030_FC_MASRAF_TUTARI		  NUMBER;
p_22030_LC_MASRAF_TUTAR			  NUMBER;
p_22030_MASRAF_HESAP_SUBE		  NUMBER;
p_22030_MASRAF_HESAP_NO			  NUMBER;
p_22030_LC_MAIL_CHARGE			  NUMBER;
p_22030_LC_COMM_CHARGE			  NUMBER;
p_22030_LC_FREE_COM			  	  NUMBER;
p_22030_MAIL_CHARGE_GL			  NUMBER;
p_22030_COMM_CHARGE_GL			  NUMBER;
p_22030_FREE_COM_GL			  	  NUMBER;
p_22030_FC						  NUMBER;
p_22030_LC						  NUMBER;
p_22030_MAILCOM_VAR				  NUMBER;
p_22030_COMMCOM_VAR				  NUMBER;
p_22030_FREECOM_VAR			      NUMBER;
p_22030_FC_MASRAF_ANA			  NUMBER;
p_22030_LC_MASRAF_ANA			  NUMBER;

p_22030_LC_DOCPREP_COM			  NUMBER;
p_22030_DOCPREP_COM_GL			  NUMBER;
p_22030_DOCPREP_VAR			      NUMBER;

p_22030_VERGIDEN_MUAF_DEGIL		  NUMBER;
p_22030_LC_SERVICE_TAX   NUMBER;
p_22030_FC_SERVICE_TAX   NUMBER;
/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2, ps_no number) is
	  cursor c_01 is
	     select a.masraf_kodu, a.sira_no, a.referans,
		        nvl(a.tutar,0) eski_tutar, nvl(b.tutar,0) yeni_tutar,
				nvl(b.tahsil_edilemeyen,0) tahsil_edilemeyen
		   from cbs_masraf_ith_ihr a, cbs_masraf_ith_ihr_isl b
		  where b.islem_no = pn_islem_no
		    and b.komisyon_tipi = 'SABIT'    --not like 'D?NEMSEL%'
		    and a.referans = b.referans
			and a.vs_no = b.vs_no
			and b.vs_no = 0		 	   --source ?nemli de?ili sa?lar....
		    and a.masraf_kodu = b.masraf_kodu
			and a.sira_no = b.sira_no
			and a.tutar <> b.tutar;
		r_01 c_01%rowtype;

  begin
    update cbs_masraf_ith_ihr_isl
	   set referans = ps_ref,
	       durum = 'VALID',
		   vs_no = 0
	 where islem_no = pn_islem_no;

--Yeni taksitli olmayan masraf girilmi?se
     update cbs_masraf_ith_ihr_isl b
	   set tahsil_edilemeyen =  decode(komisyon_tipi, 'SABIT', tutar, tahsil_edilemeyen),
	       tahsil_toplam = 0
	 where islem_no = pn_islem_no
	   and komisyon_tipi not like 'DONEMSEL%'
	   and not exists (select 1
	                     from cbs_masraf_ith_ihr a
						where a.referans = b.referans
						  and a.masraf_kodu = b.masraf_kodu
						  and a.vs_no = b.vs_no
		                  and a.vs_no = 0);

--Eskiden var olanlar?n masraf miktar? artt?r?lm??sa...

	  open c_01;
	  loop
	   fetch c_01 into r_01;
	   exit when c_01%notfound;

	    update cbs_masraf_ith_ihr_isl
		   set tahsil_edilemeyen =  r_01.tahsil_edilemeyen + r_01.yeni_tutar - r_01.eski_tutar
		 where islem_no = pn_islem_no
		   and masraf_kodu = r_01.masraf_kodu
		   and sira_no = r_01.sira_no;

	  end loop;
	  close c_01;
---------------------------

/*
     update cbs_masraf_ith_ihr_isl
	   set tahsil_edilemeyen = decode(komisyon_tipi, 'SABIT', tutar, tahsil_edilemeyen),
	       tahsil_toplam = 0
	 where islem_no = pn_islem_no
	   and komisyon_tipi not like 'D?NEMSEL%';*/
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   update cbs_masraf_ith_ihr_isl
      set durum = 'RED'
	where islem_no = pn_islem_no;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is		-- Islem iptal edilemez
 BEGIN
    --status iptal konumuna getirilir ve tahsil edilen vs. oldu?u gibi b?rak?l?r...
    update cbs_masraf_ith_ihr
	   set durum = 'IPTAL'
	 where referans = ps_ref
	   and vs_no = 0
	   and sira_no in (select sira_no from cbs_masraf_ith_ihr_isl
	                   where islem_no = pn_islem_no);

    --masraf logu iptal edilir....
    update cbs_masraf_ith_ihr_ipt_log
	   set durum = 'IPTAL'
	 where islem_no = pn_islem_no;

    update cbs_masraf_ith_ihr_isl
	   set durum = 'IPTAL'
	 where islem_no = pn_islem_no;


  end;
/*------------------------------------------------------------------------------------------------------*/
  PROCEDURE Muhasebelesme(pn_islem_no NUMBER, pn_fis_no IN OUT NUMBER) IS
   varchar_list		      Pkg_Muhasebe.varchar_array;
   number_list			  Pkg_Muhasebe.number_array;
   date_list			  Pkg_Muhasebe.date_array;
   boolean_list			  Pkg_Muhasebe.boolean_array;
   ln_fis_no			  NUMBER;
   ls_referans 			  VARCHAR2(16);
   ls_sube				  VARCHAR2(10);
   ls_akr_doviz           VARCHAR2(3);
   lb_taksit_var		  BOOLEAN := FALSE;
   ln_son_bakiye		  NUMBER := 0;
   ln_borc_fc		  NUMBER := 0;
   ln_borc_trl			  NUMBER := 0;
   ln_eski_tahsil_tutar	  NUMBER;
   ln_tahsil_tutar		  NUMBER;
   ln_top_bsmv 			  NUMBER := 0;
   ln_bsmv				  NUMBER := 0;
   ls_istatistik_kodu     VARCHAR2(2000);
   ls_aciklama			  VARCHAR2(2000);
   ln_dk_grup_no		  NUMBER;
	ls_acik_tutar_ref VARCHAR2(100);
	ln_ser_tax number:=0;
   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID'
	 order by sira_no desc   --en son girilen ?deme komisyonu ilk al?nmaya ?al???lacak...
	for update;
	row_masraf cur_masraf%rowtype;

   cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID';
	 ln_temp number;

	CURSOR islem_cursor IS
	   	 	SELECT * from cbs_ihracat_islem
			where TX_NO=pn_islem_no;
	 row_islem islem_cursor%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and masraf_kodu = row_masraf.masraf_kodu
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

Begin
   ln_fis_no := pn_fis_no;
	OPEN c_0;
	FETCH c_0 INTO ln_temp;
	CLOSE c_0;
	IF ln_temp <= 0 THEN
	  RETURN;
	END IF;

	boolean_list(p_22030_FREECOM_VAR) := FALSE ;
	boolean_list(p_22030_COMMCOM_VAR) := FALSE ;
	boolean_list(p_22030_MAILCOM_VAR) := FALSE ;
	boolean_list(p_22030_DOCPREP_VAR) := FALSE ;
	boolean_list(p_22030_FC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22030_LC_MASRAF_ANA) := FALSE ;
	boolean_list(p_22030_VERGIDEN_MUAF_DEGIL) := FALSE ;

	varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU) := 'AAA';
	OPEN islem_cursor;
	FETCH islem_cursor INTO row_islem;
	 ls_akr_doviz := row_islem.doviz_kodu;
	 IF row_islem.masraf_hesap_no IS NOT NULL THEN
    	 varchar_list(p_22030_MASRAF_HESAP_NO) := row_islem.masraf_hesap_no;

		 if pkg_musteri.musteri_vergiden_muafmi(row_islem.IHRACATCI_MUSTERI_NO) = 'E'
		 then
			boolean_list(p_22030_VERGIDEN_MUAF_DEGIL) := FALSE ;
		 else
			boolean_list(p_22030_VERGIDEN_MUAF_DEGIL) := TRUE ;
		 end if;
	     varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_islem.masraf_hesap_no);
	     varchar_list(p_22030_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_islem.masraf_hesap_no);
	 else
	 	 varchar_list(p_22030_MASRAF_HESAP_NO) := '';
	 END IF;

	 IF row_islem.masraf_hesap_no IS NOT NULL THEN
	     ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(row_islem.IHRACATCI_MUSTERI_NO) ;
		 varchar_list(p_22030_FREE_COM_GL)    :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPFREECOM');
		 varchar_list(p_22030_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		 varchar_list(p_22030_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		 varchar_list(p_22030_DOCPREP_COM_GL)    :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDOCPREP');
	 ELSE
		 varchar_list(p_22030_FREE_COM_GL)    := '';
		 varchar_list(p_22030_COMM_CHARGE_GL) := '';
		 varchar_list(p_22030_MAIL_CHARGE_GL) := '';
		 varchar_list(p_22030_DOCPREP_COM_GL)    := '';
	 END IF;

	 varchar_list(p_22030_ISLEM_SUBE) := row_islem.bolum_kodu;
	 ls_referans := row_islem.referans_no;

	 varchar_list(p_22030_REFERENCE) := ls_referans;

	CLOSE islem_cursor;

	ls_acik_tutar_ref := RTRIM(TO_CHAR(row_islem.tutar,'999G999G999G999G999G999G999D99')) || ls_akr_doviz || '-' || ls_referans;

    IF varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
	 boolean_list(p_22030_LC_MSRF_DOVIZ_KODU) := FALSE;
	 boolean_list(p_22030_FC_MSRF_DOVIZ_KODU) := TRUE ;
	ELSE
	 boolean_list(p_22030_LC_MSRF_DOVIZ_KODU) := TRUE;
	 boolean_list(p_22030_FC_MSRF_DOVIZ_KODU) := FALSE;
	END IF;

	number_list(p_22030_LC_COMM_CHARGE) := 0;
	number_list(p_22030_LC_MAIL_CHARGE) := 0;
	number_list(p_22030_LC_FREE_COM) := 0;
	number_list(p_22030_LC_DOCPREP_COM) := 0;

	number_list(p_22030_LC_MASRAF_TUTAR) := 0;
	number_list(p_22030_FC_MASRAF_TUTARI) := 0;
	number_list(p_22030_LC_SERVICE_TAX) := 0;
	number_list(p_22030_FC_SERVICE_TAX) := 0;

	ls_aciklama := ls_referans || ' -  ' || row_islem.ihracatci_musteri_no || ' -  ' ||
				   Pkg_Musteri.sf_musteri_adi(row_islem.ihracatci_musteri_no) || ' -  ' ||
				   ' Export File Opening ' ;
	varchar_list(p_22030_BANKA_ACIK) := ls_aciklama;
	varchar_list(p_22030_MUS_ACIK) :=varchar_list(p_22030_BANKA_ACIK) ;

    IF ls_akr_doviz = Pkg_Genel.LC_AL THEN
	  boolean_list(p_22030_LC) := TRUE;
      boolean_list(p_22030_FC) := FALSE;
	ELSE
	  boolean_list(p_22030_LC) := FALSE;
      boolean_list(p_22030_FC) := TRUE;
	END IF;

	IF row_islem.masraf_hesap_no IS NOT NULL THEN  --masraf hesabi girilmisse
   	   number_list(p_22030_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),1);
		ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_22030_MASRAF_HESAP_NO));
    END IF;


	OPEN cur_masraf;
	LOOP
	  FETCH cur_masraf INTO row_masraf;
	  EXIT WHEN cur_masraf%NOTFOUND;
	  ln_bsmv := 0;
	  IF NVL(row_masraf.tahsil_edilemeyen,0) > 0  THEN
		  IF Pkg_ihracat.masraf_kontrol_yap_nonakr(row_masraf.ODEYECEK) = 'Y'
		     AND boolean_list(p_22030_VERGIDEN_MUAF_DEGIL)

		  THEN
		      ln_tahsil_tutar := row_masraf.tutar - NVL(row_masraf.tahsil_toplam,0);
			  IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN   --haberlesme
			    boolean_list(p_22030_COMMCOM_VAR) := TRUE ;
			   number_list(p_22030_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22030_LC_COMM_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22030_KUR)));
				number_list(p_22030_LC_SERVICE_TAX):=number_list(p_22030_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta
			  	boolean_list(p_22030_MAILCOM_VAR) := TRUE ;
			   number_list(p_22030_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22030_LC_MAIL_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22030_KUR)));
				number_list(p_22030_LC_SERVICE_TAX):=number_list(p_22030_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF row_masraf.masraf_kodu =  'EXPFREECOM' THEN  --
			    boolean_list(p_22030_FREECOM_VAR) := TRUE ;
			   number_list(p_22030_LC_FREE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22030_LC_FREE_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22030_KUR)));
			  ELSIF row_masraf.masraf_kodu = 'EXPDOCPREP' THEN
			    boolean_list(p_22030_DOCPREP_VAR) := TRUE ;
			   number_list(p_22030_LC_DOCPREP_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(row_masraf.DVZ, ln_tahsil_tutar));

				ln_borc_trl := number_list(p_22030_LC_DOCPREP_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_22030_KUR)));
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;

			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_fc  THEN --bakiye yeterliyse satiri ekle
			     IF ln_tahsil_tutar <> 0 THEN
			         ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22030, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_22030_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_22030_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22030_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_22030_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22030_FREECOM_VAR) = TRUE THEN
					  	 boolean_list(p_22030_FREECOM_VAR) := FALSE;
					  ELSIF boolean_list(p_22030_DOCPREP_VAR) = TRUE THEN
					  	 boolean_list(p_22030_DOCPREP_VAR) := FALSE;
					  END IF;

					  Pkg_Masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      UPDATE CBS_MASRAF_ITH_IHR_ISL
					     SET tahsil_toplam = NVL(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       WHERE CURRENT OF cur_masraf;

					  ln_son_bakiye := ln_son_bakiye - ln_borc_fc ;
					  number_list(p_22030_LC_MASRAF_TUTAR) := number_list(p_22030_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_22030_FC_MASRAF_TUTARI) := number_list(p_22030_FC_MASRAF_TUTARI) + ln_borc_fc;
				END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_fc, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_22030_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;

	boolean_list(p_22030_MAILCOM_VAR) := FALSE ;
	boolean_list(p_22030_COMMCOM_VAR) := FALSE ;
	boolean_list(p_22030_FREECOM_VAR) := FALSE ;
	boolean_list(p_22030_DOCPREP_VAR) := FALSE ;

	IF number_list(p_22030_FC_MASRAF_TUTARI) > 0
	THEN
	   number_list(p_22030_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_22030_LC_MASRAF_TUTAR)) ;
	   number_list(p_22030_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_22030_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_22030_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_22030_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_22030_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_22030_LC_MASRAF_ANA) := TRUE ;
		END IF;

		pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_ser_tax);

		number_list(p_22030_FC_SERVICE_TAX):=Pkg_Kur.yuvarla(varchar_list(p_22030_MASRAF_HESAP_DOVIZKODU),(number_list(p_22030_LC_SERVICE_TAX)/number_list(p_22030_KUR)));
		number_list(p_22030_LC_SERVICE_TAX):=(number_list(p_22030_LC_SERVICE_TAX)* ln_ser_tax)/100;
		number_list(p_22030_FC_SERVICE_TAX):=(number_list(p_22030_FC_SERVICE_TAX)* ln_ser_tax)/100;

	   ln_fis_no:=Pkg_Muhasebe.fis_kes ( 22030, NULL, pn_islem_no,
				    					  	 varchar_list, number_list,
											 date_list, boolean_list,
								    	  	 NULL, FALSE, ln_fis_no, NULL);
	END IF;
	pn_fis_no := ln_fis_no;

End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
Procedure Muhasebelesme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
Begin

	 delete    from CBS_MASRAF_ITH_IHR a
   where referans = ps_ref
     and vs_no = 0
     and exists (select 1 from cbs_masraf_ith_ihr_isl b
	              where referans = ps_ref
				    and islem_no = pn_islem_no
					and b.masraf_kodu = a.masraf_kodu
					and b.sira_no = a.sira_no
					and b.vs_no = 0);
-----------------------------
  insert into cbs_masraf_ith_ihr
	         (referans, sira_no, masraf_kodu, adi, dvz, komisyon_tipi,
			  tahsil_toplam, tahsil_edilemeyen, odeyecek, oran, tutar,
			  devre_gun_sayisi, taksit_sayisi, taksit_bas_tarih,
			  taksit_bitis_tarih, hesaplanan, bsmv, durum, vs_no)
      (select referans, sira_no, masraf_kodu, adi, dvz, komisyon_tipi,
	          tahsil_toplam, tahsil_edilemeyen, odeyecek, oran, tutar,
			  devre_gun_sayisi, taksit_sayisi, taksit_bas_tarih,
			  taksit_bitis_tarih, hesaplanan, bsmv, durum, vs_no
		 from cbs_masraf_ith_ihr_isl
		where islem_no = pn_islem_no);
---------------------------------
  insert into  cbs_masraf_taksit
              (referans, taksit_no, taksit_tarihi, taksit_tutari,
		       taksit_odeme_tarih, odenen_tutar, bsmv, vs_no, masraf_kodu)
	   (select referans, taksit_no, taksit_tarihi, taksit_tutari,
		       taksit_odeme_tarih, odenen_tutar, bsmv, vs_no, masraf_kodu
		  from cbs_masraf_taksit_islem
		 where islem_no = pn_islem_no);

end;
/*------------------------------------------------------------------------------------------------------*/
  Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
 ln_temp number;
 begin
   select count(*)
     into ln_temp
	 from cbs_masraf_ith_ihr_isl
	where islem_no = pn_islem_no
	  and odeyecek in ('EXPORTER');
   if ln_temp > 0 then
     return 'E';
   else
     return 'H';
   end if;
 end;

/*------------------------------------------------------------------------------------------------------*/
 /*------------------------------------------------------------------------------------------------------*/
 BEGIN
	p_22030_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('22030_FC_MSRF_DOVIZ_KODU');
	p_22030_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('22030_LC_MSRF_DOVIZ_KODU');
	p_22030_KUR						  := Pkg_Muhasebe.parametre_index_bul('22030_KUR');
	p_22030_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('22030_REFERENCE');
	p_22030_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('22030_ISTA_KOD');
	p_22030_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('22030_MUS_ACIK');
	p_22030_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('22030_BANKA_ACIK');
	p_22030_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('22030_ISLEM_SUBE');
	p_22030_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('22030_MASRAF_HESAP_DOVIZ_KODU');
	p_22030_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('22030_FC_MASRAF_TUTARI');
	p_22030_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_MASRAF_TUTAR');
	p_22030_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('22030_MASRAF_HESAP_SUBE');
	p_22030_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('22030_MASRAF_HESAP_NO');
	p_22030_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_MAIL_CHARGE');
	p_22030_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_COMM_CHARGE');
	p_22030_LC_FREE_COM			      := Pkg_Muhasebe.parametre_index_bul('22030_LC_FREE_COM');
	p_22030_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('22030_MAIL_CHARGE_GL');
	p_22030_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('22030_COMM_CHARGE_GL');
	p_22030_FREE_COM_GL			  	  := Pkg_Muhasebe.parametre_index_bul('22030_FREE_CHARGE_GL');
	p_22030_FC						  := Pkg_Muhasebe.parametre_index_bul('22030_FC');
	p_22030_LC						  := Pkg_Muhasebe.parametre_index_bul('22030_LC');
	p_22030_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('22030_MAILCOM_VAR');
	p_22030_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('22030_COMMCOM_VAR');
	p_22030_FREECOM_VAR			      := Pkg_Muhasebe.parametre_index_bul('22030_FREECOM_VAR');
	p_22030_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('22030_FC_MASRAF_ANA');
	p_22030_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_MASRAF_ANA');

    p_22030_LC_DOCPREP_COM			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_DOCPREP_COM');
    p_22030_DOCPREP_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('22030_DOCPREP_COM_GL');
    p_22030_DOCPREP_VAR			      := Pkg_Muhasebe.parametre_index_bul('22030_DOCPREP_VAR');

	p_22030_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('22030_LC_SERVICE_TAX');
	p_22030_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('22030_FC_SERVICE_TAX');
	p_22030_VERGIDEN_MUAF_DEGIL			  := Pkg_Muhasebe.parametre_index_bul('22030_VERGIDEN_MUAF_DEGIL');
END;
/

