create package     pkg_prbo
is
    function get_prbo_gl_balances (p_rbo_code in varchar2, 
                                         p_colname  in varchar2,
                                         pd_date_in in date, 
                                         ps_curr    in varchar2) 
    return cbs.rbo4_ntt;

end pkg_prbo;
/

