create PACKAGE BODY     PKG_INT_EXCHANGE_INQ IS  

FUNCTION GetExchangeRates(ps_lang varchar2, 
                          pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_returncode varchar2(3) := '000';
BEGIN

   open pc_ref for
        select cbs_kur.dvz as currency_code,
               cbs_doviz_kodlari.aciklama as currency_name,
               cbs_kur.dvzalis as buying,
               cbs_kur.dvzsatis as selling,
               GetChangeRate(cbs_kur.dvzalis, cbs_kur.dvz, cbs_kur.dvz) as change_rate
           from cbs_kur,cbs_doviz_kodlari
               where cbs_kur.dvz=cbs_doviz_kodlari.doviz_kodu
                   and cbs_kur.dvz in ('USD','EUR','RUB','KZT','TRY','GBP','CHF')
                        order by sira_no;
                
        return ls_returncode;
        
EXCEPTION 
    when others then 
        raise; 
END;
FUNCTION GetArbitrageRates(ps_lang varchar2, 
                           ps_currency varchar2, 
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

  open pc_ref for
       select r.*, GetChangeRate(buying, ps_currency, r.currency_code) as change_rate from
          (select 1 as sorting, 
          pkg_int.intcalculateparity(ps_currency,'USD') as buying, 
          pkg_int.intcalculateparity('USD',ps_currency) as selling, 
          'USD' as currency_code, 
          pkg_genel.doviz_adi_al('USD') as currency_name from dual
          union
          select 2 as sorting, 
          pkg_int.intcalculateparity(ps_currency,'EUR') as buying, 
          pkg_int.intcalculateparity('EUR',ps_currency) as selling, 
          'EUR' as currency_code, 
          pkg_genel.doviz_adi_al('EUR') as currency_name from dual
          union
          select 3 as sorting, pkg_int.intcalculateparity(ps_currency,'GBP') as buying, 
          pkg_int.intcalculateparity('GBP',ps_currency) as selling, 
          'GBP' as currency_code, 
          pkg_genel.doviz_adi_al('GBP') as currency_name from dual
          union
          select 4 as sorting, pkg_int.intcalculateparity(ps_currency,'RUB') as buying, 
          pkg_int.intcalculateparity('RUB',ps_currency) as selling, 
          'RUB' as currency_code, 
          pkg_genel.doviz_adi_al('RUB') as currency_name from dual
          union     
          select 5 as sorting, 
          pkg_int.intcalculateparity(ps_currency,'CHF') as buying, 
          pkg_int.intcalculateparity('CHF',ps_currency) as selling, 
          'CHF' as currency_code, 
          pkg_genel.doviz_adi_al('CHF') as currency_name from dual
          union
          select 6 as sorting, 
          pkg_int.intcalculateparity(ps_currency,'TRY') as buying, 
          pkg_int.intcalculateparity('TRY',ps_currency) as selling, 
          'TRY' as currency_code, 
          pkg_genel.doviz_adi_al('TRY') as currency_name from dual
          union
          select 7 as sorting, 
          pkg_int.intcalculateparity(ps_currency,'KZT') as buying, 
          pkg_int.intcalculateparity('KZT',ps_currency) as selling, 
          'KZT' as currency_code, 
          pkg_genel.doviz_adi_al('KZT') as currency_name from dual) r where currency_code <> ps_currency order by sorting;
          
     return ls_returncode;
     
EXCEPTION 
    when others then 
        raise; 
END;

FUNCTION GetChangeRate(pn_new_rate number,
                       ps_currency_code_1 varchar2,
                       ps_currency_code_2 varchar2) RETURN number 
IS
ln_change_rate number := 0;
ln_old_rate number;

ln_parity_base_orber_1 number;
ln_parity_base_order_2 number;
ls_base_currency varchar2(3);
ls_against_currency varchar2(3);
ln_credit number;
ln_debit number;
BEGIN

      if ps_currency_code_1 = ps_currency_code_2 then
      
           select dvzalis into ln_old_rate from cbs_kurlog 
                                            where 
                                            gecerli_kur = 'H' 
                                            and dvz = ps_currency_code_1
                                            and tarih >= pkg_muhasebe.onceki_banka_tarihi_bul
                                            order by tarih desc offset 0 rows fetch next 1 rows only;
      else
      
            select dvzsatis into ln_parity_base_orber_1 from cbs_kurlog 
                                            where 
                                            gecerli_kur = 'H' 
                                            and dvz = ps_currency_code_1
                                            and tarih >= pkg_muhasebe.onceki_banka_tarihi_bul
                                            order by tarih desc offset 0 rows fetch next 1 rows only;
                                            
            select dvzalis into ln_parity_base_order_2 from cbs_kurlog 
                                            where 
                                            gecerli_kur = 'H' 
                                            and dvz = ps_currency_code_2
                                            and tarih >= pkg_muhasebe.onceki_banka_tarihi_bul
                                            order by tarih desc offset 0 rows fetch next 1 rows only;

              if ln_parity_base_orber_1 > ln_parity_base_order_2 then
                ls_base_currency := ps_currency_code_1;
                ls_against_currency := ps_currency_code_2;
              else
                ls_base_currency := ps_currency_code_2;
                ls_against_currency := ps_currency_code_1;
              end if;
     
              if ls_base_currency = ps_currency_code_1 then
         
                  ln_credit := pkg_kur.doviz_doviz_karsilik(ls_base_currency, pkg_genel.lc_al, null, 1, 1, null, null, 'O', 'S');
                  ln_debit := pkg_kur.doviz_doviz_karsilik(ls_against_currency, pkg_genel.lc_al , null, 1, 1, null, null, 'O', 'A');

                  ln_old_rate := round(ln_credit / ln_debit, 5);
                  
              else
     
                  ln_credit := pkg_kur.doviz_doviz_karsilik(ls_base_currency, pkg_genel.lc_al, null, 1, 1, null, null, 'O', 'A');
                  ln_debit := pkg_kur.doviz_doviz_karsilik(ls_against_currency, pkg_genel.lc_al, null, 1, 1, null, null, 'O', 'S');

                  ln_old_rate := round(ln_credit / ln_debit, 5);
                  
              end if; 
      end if;
                
      ln_change_rate := ((pn_new_rate - ln_old_rate) / ln_old_rate) * 100;
                
      return round(ln_change_rate, 5);
        
EXCEPTION 
    when no_data_found then 
        return 0; 
    when others then 
        raise; 
END;

FUNCTION GetConverter(ps_source_currency_code varchar2, 
                          ps_target_currency_code varchar2,
                          ps_amount varchar2,
                          ps_customer_id varchar2 default null, 
                          ps_reservation_number varchar2 default null,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_res_sell_rate number := 0;
ln_res_buy_rate number := 0;
ln_res_amount number := 0;
ln_sell_amount number := 0;
ln_buy_amount number := 0;
ln_amount number := 0;
ln_customer_no number;
ln_count number;
ls_returncode varchar2(3) := '000';
noreservationerror exception;
BEGIN


      ln_amount :=  to_number(ps_amount,'99999999999.99');
      
      if ps_reservation_number is not null then
      
          ln_customer_no := pkg_int_customer_inq.getcustomerno(ps_customer_id);
          
               select count(*)
                   into ln_count
                   from cbs_vw_kur_rezervasyon r
                           where r.rezervasyon_no = to_number(ps_reservation_number)
                                   and r.bakiye <> 0
                                   and musteri_no = ln_customer_no;

                if ln_count = 0 then
                     raise noreservationerror;
                end if;
                   
               select r.musteri_kur, r.musteri_kur, r.tutar
                   into ln_res_buy_rate, ln_res_sell_rate, ln_res_amount
                       from cbs_vw_kur_rezervasyon r,cbs_doviz_kodlari d
                            where r.rezervasyon_no = to_number(ps_reservation_number)
                                   and d.doviz_kodu = r.doviz
                                   and d.doviz_kodu = ps_target_currency_code
                                   and r.musteri_no = ln_customer_no;
  
              
          ln_sell_amount := ln_amount;
                    
          ln_buy_amount := ln_amount * ln_res_sell_rate;
                    
      else 
          ln_sell_amount := ln_amount;
         
          if ps_target_currency_code = pkg_genel.lc_al then
           ln_buy_amount := pkg_kur.yuvarla(ps_target_currency_code,pkg_kur.doviz_doviz_karsilik(ps_source_currency_code,ps_target_currency_code,null,ln_amount,1,null,null,'O','A'));
          elsif ps_source_currency_code = pkg_genel.lc_al then
           ln_buy_amount := pkg_kur.yuvarla(ps_target_currency_code,pkg_kur.doviz_doviz_karsilik(ps_source_currency_code,ps_target_currency_code,null,ln_amount,1,null,null,'O','S'));
          else 
           ln_buy_amount := ln_sell_amount / pkg_int.intcalculateparity(ps_source_currency_code,ps_target_currency_code);
          end if;
         
      end if;
      
      open pc_ref for
        select
         ln_amount as amount,
         ln_sell_amount as sell_amount,
         ln_buy_amount as buy_amount 
         from dual;
         
    return ls_returncode;   
    
EXCEPTION
    when noreservationerror then
        return '454';
    when others then
        log_at('newib','GetConverter', sqlerrm, dbms_utility.format_error_backtrace);
        raise; 
end;

FUNCTION GetExcBuyToAccount(ps_source_iban varchar2, 
                            ps_target_iban varchar2,
                            ps_amount varchar2,
                            ps_amount_currency varchar2,
                            ps_reservation_number varchar2 default null,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_currency_code varchar2(3 byte);
ls_source_currency_code varchar2(3 byte);
ln_source_initial_balance number;
ln_source_amount number;
ln_source_final_balance number;
ln_exchange_rate number;
ls_target_currency_code varchar2(3 byte);
ln_target_initial_balance number;
ln_target_amount number;
ln_target_final_balance number;
ln_amount number;
ln_customer_no number;
ls_res_curr varchar2(3 byte);
ln_res_buy_rate number;
ln_res_sell_rate number;
ln_res_amount number;
ln_count number;
ls_returncode varchar2(3):='000';
erroramountexception exception;
errorresdifferentamount exception;
errorresdifferentcurrency exception;
noreservationerror exception;
BEGIN
   
   ln_amount := to_number(ps_amount,'99999999999.99');
                         
   select doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no), musteri_no 
       into ls_source_currency_code, ln_source_initial_balance, ln_customer_no
            from cbs_vw_hesap_izleme 
                   where external_hesap_no = ps_source_iban 
                         and durum_kodu='A';
       
   select doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no) 
       into ls_target_currency_code, ln_target_initial_balance
           from cbs_vw_hesap_izleme 
                 where external_hesap_no = ps_target_iban
                       and durum_kodu = 'A';
       
    if ps_reservation_number is not null then
    
          select count(*)
                   into ln_count
                   from cbs_vw_kur_rezervasyon r
                           where r.rezervasyon_no = to_number(ps_reservation_number)
                                   and r.bakiye <> 0
                                   and musteri_no = ln_customer_no;

           if ln_count = 0 then
                raise noreservationerror;
           end if;
                
    
           select r.doviz, r.musteri_kur, r.musteri_kur, r.tutar
               into ls_res_curr, ln_res_buy_rate, ln_res_sell_rate, ln_res_amount
                   from cbs_vw_kur_rezervasyon r,cbs_doviz_kodlari d
                        where r.rezervasyon_no = to_number(ps_reservation_number)
                               and d.doviz_kodu = r.doviz
                               and d.doviz_kodu = ls_target_currency_code
                               and r.musteri_no = ln_customer_no;
            
            if ln_res_amount != ln_amount then
                 raise errorresdifferentamount;
            end if;

            if ls_target_currency_code != ls_res_curr then
                 raise errorresdifferentcurrency;
            end if;
            
            if ps_amount_currency = ls_source_currency_code then
               ln_source_amount := ln_amount;
               ln_target_amount := ln_amount / ln_res_buy_rate;
            else
               ln_source_amount := ln_amount * ln_res_buy_rate;
               ln_target_amount := ln_amount;
            end if;

            ln_exchange_rate := ln_res_buy_rate;
         
                    
    else 
            if ps_amount_currency = ls_source_currency_code then
               ln_source_amount := ln_amount;
               ln_target_amount := round(pkg_kur.doviz_doviz_karsilik(ls_source_currency_code,ls_target_currency_code,null,ln_amount,1,null,null,'O','S'), 4);
            else
               ln_source_amount := round(pkg_kur.doviz_doviz_karsilik(ls_target_currency_code,ls_source_currency_code,null,ln_amount,1,null,null,'O','S'), 4);
               ln_target_amount := ln_amount;
            end if;


            if ls_source_currency_code = pkg_genel.lc_al then
                ln_exchange_rate := round(pkg_kur.doviz_doviz_karsilik(ls_target_currency_code,ls_source_currency_code,null,1,1,null,null,'O','S'), 4);
                --Pkg_Int.IntCalculateParity(ls_target_currency_code,ls_source_currency_code);
            else
                ln_exchange_rate := pkg_int.intcalculateparity(ls_source_currency_code,ls_target_currency_code); 
            end if;
            
    end if;
    
   ls_currency_code := ls_target_currency_code;

   ln_source_final_balance := ln_source_initial_balance - ln_source_amount;
   ln_target_final_balance := ln_target_initial_balance + ln_target_amount;
            
    if (ln_source_final_balance < 0) then 
       raise erroramountexception;
    end if;

    open pc_ref for
       select ls_currency_code as currency_code,
              ln_target_amount as target_amount,
              ls_target_currency_code as target_currency_code,
              ln_exchange_rate as exchange_rate,
              ln_source_amount as source_amount,
              ls_source_currency_code as source_currency_code,
              ln_source_initial_balance as source_initial_balance,
              ln_source_final_balance as source_final_balance,
              ln_target_initial_balance as target_initial_balance,
              ln_target_final_balance as target_final_balance from dual;
              
    return ls_returncode; 
     
EXCEPTION
    when noreservationerror then
           return '490';
    when errorresdifferentamount then
           return '490';
    when errorresdifferentcurrency then
           return '490';
    when erroramountexception then
           return '456';
    when no_data_found then
        log_at('newib','GetExchangeBuyToAccount', sqlerrm, dbms_utility.format_error_backtrace);
         return '490'; 
    when others then
        log_at('newib','GetExchangeBuyToAccount', sqlerrm, dbms_utility.format_error_backtrace);
        raise; 
END; 

FUNCTION GetExcSellToAccount(ps_source_iban varchar2, 
                             ps_target_iban varchar2,
                             ps_amount varchar2,
                             ps_amount_currency varchar2,
                             ps_reservation_number varchar2 default null,
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_currency_code varchar2(3 byte);
ls_source_currency_code varchar2(3 byte);
ln_source_initial_balance number;
ln_source_amount number;
ln_source_final_balance number;
ln_exchange_rate number;
ls_target_currency_code varchar2(3 byte);
ln_target_initial_balance number;
ln_target_amount number;
ln_target_final_balance number;
ln_amount number;
ln_customer_no number;
ls_res_curr varchar2(3 byte);
ln_res_buy_rate number;
ln_res_sell_rate number;
ln_res_amount number;
ln_count number;
ls_returncode varchar2(3) := '000';
erroramountexception exception;
errorresdifferentamount exception;
errorresdifferentcurrency exception;
noreservationerror exception;
BEGIN
      
   ln_amount :=  to_number(ps_amount,'99999999999.99');
                         
   select doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no), musteri_no
       into ls_source_currency_code, ln_source_initial_balance, ln_customer_no
       from cbs_vw_hesap_izleme where external_hesap_no = ps_source_iban and durum_kodu='A';
       
   select doviz_kodu, pkg_hesap.kullanilabilir_bakiye_al(hesap_no) 
       into ls_target_currency_code, ln_target_initial_balance
       from cbs_vw_hesap_izleme where external_hesap_no = ps_target_iban and durum_kodu='A';
       
    if ps_reservation_number is not null then
    
         select count(*)
                   into ln_count
                   from cbs_vw_kur_rezervasyon r
                           where r.rezervasyon_no = to_number(ps_reservation_number)
                                   and r.bakiye <> 0
                                   and musteri_no = ln_customer_no;

           if ln_count = 0 then
                raise noreservationerror;
           end if;
           
        select r.doviz, r.musteri_kur, r.musteri_kur, r.tutar
               into ls_res_curr, ln_res_buy_rate, ln_res_sell_rate, ln_res_amount
                   from cbs_vw_kur_rezervasyon r,cbs_doviz_kodlari d
                        where r.rezervasyon_no=to_number(ps_reservation_number)
                               and d.doviz_kodu=r.doviz
                               and d.doviz_kodu=ls_target_currency_code
                               and r.musteri_no=ln_customer_no;
            
            if ln_res_amount != ln_amount then
                 raise errorresdifferentamount;
            end if;

            if ls_target_currency_code!=ls_res_curr then
                 raise errorresdifferentcurrency;
            end if;
            
            if ps_amount_currency = ls_source_currency_code then
               ln_source_amount := ln_amount;
               ln_target_amount := ln_amount / ln_res_sell_rate;
            else
               ln_source_amount := ln_amount * ln_res_sell_rate;
               ln_target_amount := ln_amount;
            end if;

            ln_exchange_rate := ln_res_sell_rate;
    else 
    
            if ps_amount_currency = ls_source_currency_code then
               ln_source_amount := ln_amount;
               ln_target_amount := round(pkg_kur.doviz_doviz_karsilik(ls_source_currency_code,ls_target_currency_code,null,ln_amount,1,null,null,'O','A'), 4);
            else
               ln_source_amount := round(pkg_kur.doviz_doviz_karsilik(ls_target_currency_code,ls_source_currency_code,null,ln_amount,1,null,null,'O','A'), 4);
               ln_target_amount := ln_amount;
            end if;

            ln_exchange_rate := round(pkg_kur.doviz_doviz_karsilik(ls_source_currency_code,ls_target_currency_code,null,1,1,null,null,'O','A'), 4);
            
    end if;
    
    ls_currency_code := ls_source_currency_code;
     
    ln_source_final_balance := ln_source_initial_balance - ln_source_amount;
    ln_target_final_balance := ln_target_initial_balance + ln_target_amount;
    
    
    if (ln_source_final_balance < 0) then 
       raise erroramountexception;
    end if;

    open pc_ref for
       select ls_currency_code as currency_code,
              ln_target_amount as target_amount,
              ls_target_currency_code as target_currency_code,
              ln_exchange_rate as exchange_rate,
              ln_source_amount as source_amount,
              ls_source_currency_code as source_currency_code,
              ln_source_initial_balance as source_initial_balance,
              ln_source_final_balance as source_final_balance,
              ln_target_initial_balance as target_initial_balance,
              ln_target_final_balance as target_final_balance from dual;
    
    return ls_returncode;   
    
EXCEPTION
    when noreservationerror then
           return '490';
    when errorresdifferentamount then
           return '490';
    when errorresdifferentcurrency then
           return '490';
    when erroramountexception then
           return '456';
    when no_data_found then
        log_at('newib','GetExchangeBuyToAccount', sqlerrm, dbms_utility.format_error_backtrace);
         return '490'; 
    when others then
        log_at('newib','GetExchangeBuyToAccount', sqlerrm, dbms_utility.format_error_backtrace);
        raise; 
END;                                
END;
/

