create PACKAGE Pkg_Tx6050 IS

/******************************************************************************
   Name       : PKG_TX6050
   Created By : G?lnihal Cengiz
   Date    	  : 29/12/2003
   Purpose	  : Menkul Stok Devir
******************************************************************************/
  FUNCTION  Menkul_StokDevir_Referans_Al RETURN VARCHAR2 ;
  FUNCTION  Sf_Uygun_Stok_Kodu(ps_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Depo_Turu_Uygunmu(ps_depo_turu CBS_DEPO_TUR_KODLARI.kod%TYPE ) RETURN VARCHAR2 ;

  PROCEDURE Stok_Devir_Stok_Tablosu_Yarat(pn_islem_no NUMBER,
 										  ps_mk_kodu CBS_MENKUL.menkul_kiymet_kodu%TYPE,
										  ps_referans CBS_MENKUL_STOK_DEVIR_ISLEM.referans_no%TYPE DEFAULT NULL,
										  ps_siralama_onceligi CBS_MENKUL_STOK_DEVIR.siralama_onceligi%TYPE DEFAULT NULL,
										  pn_adet	 NUMBER DEFAULT NULL,
										  pn_nominal NUMBER DEFAULT NULL,
										  pn_arama_stok_no	NUMBER DEFAULT NULL,
										  ps_stok_tanim		CBS_MENKUL_STOK_DEVIR.stok_tanim%TYPE DEFAULT NULL ,
										  ps_depo_turu		CBS_MENKUL_STOK_DEVIR.depo_turu%TYPE  DEFAULT NULL ,
										  pn_saklama_yeri	CBS_MENKUL_STOK_DEVIR.saklama_yeri%TYPE  DEFAULT NULL
										  );
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

