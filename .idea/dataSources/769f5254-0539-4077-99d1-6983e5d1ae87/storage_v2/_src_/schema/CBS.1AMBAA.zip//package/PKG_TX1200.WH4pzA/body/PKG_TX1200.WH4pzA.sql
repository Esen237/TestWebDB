create PACKAGE BODY     PKG_TX1200 IS
    pn_1200_alacak_hesap_sube_kodu  number;
    pn_1200_alacak_hesap_no         number;
    pn_1200_istatistik_kod          number;
    pn_1200_doviz_kodu                number;
    pn_1200_lc_tutar                  number;
    pn_1200_fc_tutar                number;
    pn_1200_banka_aciklama          number;  
    pn_1200_hesap_sube_kodu         number;
    pn_1200_hesap_no                number;
    pn_1200_bloke_hesap_sube_kodu   number;
    pn_1200_bloke_hesap_no          number;
    pn_1200_musteri_aciklama        number;
    pn_1200_cek_referans            number;
    pn_1200_fis_aciklama            number;
    pn_1200_kur_lc                    number;



 Procedure Kontrol_Sonrasi(pn_islem_no number) is
    ln_musteri_no                        number;
    ln_hesap_no                           number;
    ln_bloke_tutari                     number;
    ln_kullanilabilir_bakiye            number;
    ln_eod_fis_no                        number;
    ln_bekleyen_adet                   number;
  cursor cursor_bloke is
      select musteri_no,hesap_no,bloke_tutari
      from   cbs_bloke_islem
      where  tx_no =pn_islem_no ;

  cursor cursor_eod_bakiye is
     select  b.fis_numara,
                 b.hesap_numara,
                 sum(decode(b.tur,'A', nvl(b.dv_tutar,0),0)) - sum(decode(b.tur,'B', nvl(b.dv_tutar,0),0)) bakiye
       from cbs_satir b
       where b.hesap_tur_kodu <> 'DK'
                and exists (select 1 from cbs_fis c , cbs_eod_Fis_no d
                  where c.numara = b.fis_numara
                    and c.muhasebelestigi_tarih is not null
                    and c.tur = 'G'
                    and c.numara = d.fis_numara and
                    d.durum = 'A')
            and  b.hesap_numara =  ln_hesap_no
         group by b.fis_numara,b.hesap_numara;

    eod_bakiye_yetersiz       exception;
  Begin
         /*  bloke tutar? alinir hesap guncellenir. */
   for  cur_bloke in cursor_bloke
    loop
       ln_musteri_no := cur_bloke.musteri_no ;
       ln_hesap_no   := cur_bloke.hesap_no;
       ln_bloke_tutari :=   cur_bloke.bloke_tutari;
       ln_kullanilabilir_bakiye := pkg_hesap.Kullanilabilir_Bakiye_Al(ln_hesap_no);

    --eod bekleyen fis mevcutmudur.
       select max(fis_numara)
       into  ln_eod_fis_no
       from cbs_satir b
       where b.hesap_tur_kodu <> 'DK'
                and exists (select 1 from cbs_fis c , cbs_eod_Fis_no d
                  where c.numara = b.fis_numara
                    and c.muhasebelestigi_tarih is not null
                    and c.tur = 'G'
                    and c.numara = d.fis_numara and
                    d.durum = 'A')
            and  b.hesap_numara =  ln_hesap_no;

            if  nvl(ln_eod_fis_no ,0) <> 0 and nvl(ln_kullanilabilir_bakiye,0) < nvl(ln_bloke_tutari,0)  then
                raise eod_bakiye_yetersiz;
            end if;

        end loop;

  Exception
     When eod_bakiye_yetersiz Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '1502' || pkg_hata.getDelimiter ||to_char(ln_eod_fis_no ) || pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin

    update  cbs_bloke_islem
    set (
          KAYIT_TARIH,
          KAYIT_SISTEM_TARIHI,
          KAYIT_KULLANICI_KODU,
          KAYIT_KULLANICI_BOLUM_KODU,
         dogru_tarih,
         dogru_kullanici_kodu,
         dogru_kullanici_bolum_kodu) = (select   KAYIT_TARIH,
                                                  KAYIT_SISTEM_TARIHI,
                                                  KAYIT_KULLANICI_KODU,
                                                  KAYIT_KULLANICI_BOLUM_KODU,
                                                      dogru_tarih,
                                                   dogru_kullanici_kodu,
                                                  dogru_kullanici_bolum_kodu
                                              from cbs_islem
                                              where numara= pn_islem_no )
    where tx_no= pn_islem_no ;


  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
           /* Red edildi */
    update cbs_bloke_islem
    set durum_kodu = 'R',
         dogru_tarih =null,
         dogru_kullanici_kodu =null,
         dogru_kullanici_bolum_kodu=null
    where tx_no = pn_islem_no ;

  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
            Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  ld_banka_tarihi                date ;
  ln_bloke_tutari                cbs_bloke_islem.bloke_tutari%type;
  ln_musteri_no                    cbs_bloke_islem.musteri_no%type;
  ln_hesap_no                    cbs_bloke_islem.hesap_no%type;
  Ld_Onay_Tarih                    date;
  Ld_Onay_Sistem_Tarihi            date;
  Ls_Onay_Kullanici_Kodu            cbs_Islem.Onay_Kullanici_Kodu%type;
  Ls_Onay_Kullanici_Bolum_Kodu        cbs_Islem.Onay_Kullanici_Bolum_Kodu%type;
  ln_bloke_neden_kodu               cbs_bloke_islem.bloke_neden_kodu%type;  --TemirlanT cbs-119 bloke_neden_kodu
  ls_bolum_kodu                     cbs_hesap.sube_kodu%type;  --TemirlanT cbs-119 bolum_kodu

  cursor cursor_bloke is
      select musteri_no,hesap_no,bloke_tutari ,internal_ref_no, bloke_neden_kodu   --TemirlanT cbs-119 bloke_neden_kodu
      from   cbs_bloke_islem
      where  tx_no =pn_islem_no ;
  Begin

  kontrol_sonrasi(pn_islem_no);

  ld_banka_tarihi := TO_DATE(SYSDATE);
  --maksat cbs-710 070922

    select
      onay_tarih,
      onay_sistem_tarihi,
      onay_kullanici_kodu,
      onay_kullanici_bolum_kodu
    into
      ld_onay_tarih,
      ld_onay_sistem_tarihi,
      ls_onay_kullanici_kodu,
      ls_onay_kullanici_bolum_kodu
    from cbs_islem
    where numara = pn_islem_no ;

  /*  bloke tutar? alinir hesap guncellenir. */
   for  cur_bloke in cursor_bloke
    loop
       ln_musteri_no := cur_bloke.musteri_no ;
       ln_hesap_no   := cur_bloke.hesap_no;
       ln_bloke_tutari := cur_bloke.bloke_tutari;
       ln_bloke_neden_kodu := cur_bloke.bloke_neden_kodu;  --TemirlanT cbs-119 bloke_neden_kodu
/* bloke tutari guncellenir */
     Pkg_Hesap.BlokeTutariGuncelle(ln_hesap_no,ln_bloke_tutari);
    end loop;
    
    ls_bolum_kodu := PKG_HESAP.HESAPTANSUBEAL(ln_hesap_no); --TemirlanT cbs-119 bolum_kodu
    
  /* islem guncellenir */
    if ln_bloke_neden_kodu = 11 then    -- BOM TemirlanT cbs-119 bolum_kodu
        update cbs_bloke_islem
        set    bloke_tarihi = to_date(sysdate),
        --maksat cbs-710 070922
               bloke_referans = pkg_bloke.sf_bloke_referansno_Al(ls_bolum_kodu),
             durum_kodu = 'A',
             ONAY_TARIH =ld_ONAY_TARIH,
             ONAY_SISTEM_TARIHI = ld_ONAY_SISTEM_TARIHI,
             ONAY_KULLANICI_KODU = ls_ONAY_KULLANICI_KODU,
             ONAY_KULLANICI_BOLUM_KODU = ls_ONAY_KULLANICI_BOLUM_KODU
        where tx_no =pn_islem_no ;
    else                                -- EOM TemirlanT cbs-119 bolum_kodu
        update cbs_bloke_islem
        set    bloke_tarihi = to_date(sysdate),
        --maksat cbs-710 070922
               bloke_referans = pkg_bloke.sf_bloke_referansno_Al,
             durum_kodu = 'A',
             ONAY_TARIH =ld_ONAY_TARIH,
             ONAY_SISTEM_TARIHI = ld_ONAY_SISTEM_TARIHI,
             ONAY_KULLANICI_KODU = ls_ONAY_KULLANICI_KODU,
             ONAY_KULLANICI_BOLUM_KODU = ls_ONAY_KULLANICI_BOLUM_KODU
        where tx_no =pn_islem_no ;
    end if;                             --TemirlanT cbs-119 bolum_kodu

       pkg_bloke.Sp_Bloke_Ana_Tabloya_Aktar(    pn_islem_no);

  Exception
   When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '428' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     /* Red edildi */
    update cbs_bloke_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is
 Begin
  null;
 End;
 
 Procedure get_customer_accounts(pn_cust_no CBS_MUSTERI.MUSTERI_NO%TYPE,  pRetCur IN OUT GenCurType) is
 Begin
  OPEN pRetCur FOR
 
       
SELECT HEsap_no, doviz_kodu
  FROM cbs_hesap
 WHERE     musteri_no = pn_cust_no
       AND durum_kodu = 'A'
       AND Pkg_Bloke.Sf_Hesap_Bloke_Konan_Urunmu (hesap_no) = 'E'
       AND modul_tur_kod IN
              (PKG_hesap.modul_tur_vadesiz, PKG_hesap.modul_tur_vadeli)
       AND sube_kodu = pkg_baglam.bolum_kodu
UNION ALL
SELECT HEsap_no, doviz_kodu
  FROM cbs_hesap_vadeli                      -- Begin CQ1228 Add time dep. acc KonstantinZ 14102014
 WHERE     musteri_no = pn_cust_no
       AND durum_kodu = 'A'
       AND Pkg_Bloke.Sf_Hesap_Bloke_Konan_Urunmu (hesap_no) = 'E'
       AND modul_tur_kod IN
              (PKG_hesap.modul_tur_vadesiz, PKG_hesap.modul_tur_vadeli)
       AND sube_kodu = pkg_baglam.bolum_kodu
ORDER BY hesap_no;                            --CQ1228 End Add time dep. acc KonstantinZ 14102014
        
        
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;
 
 Procedure save_rows(pn_tx_no cbs_bloke_islem.tx_no%type, pn_cust_no cbs_musteri.musteri_no%type, pn_hesap_no cbs_bloke_islem.hesap_no%type, pc_doviz_kodu cbs_bloke_islem.doviz_kodu%type, pn_bloke_tutari cbs_bloke_islem.bloke_tutari%type,
    pn_bloke_neden_kodu cbs_bloke_islem.bloke_neden_kodu%type, pc_aciklama cbs_bloke_islem.aciklama%type, pd_bloke_tarihi cbs_bloke_islem.bloke_tarihi%type, pd_bloke_bitis_tarihi cbs_bloke_islem.bloke_bitis_tarihi%type) is
 Begin
    INSERT INTO cbs_bloke_islem (tx_no, musteri_no, hesap_no, doviz_kodu, bloke_tutari, bloke_neden_kodu, aciklama, bloke_tarihi, bloke_bitis_tarihi, durum_kodu, islem_tanim_kod, internal_ref_no)
    VALUES (pn_tx_no, pn_cust_no, pn_hesap_no, pc_doviz_kodu, pn_bloke_tutari, pn_bloke_neden_kodu, pc_aciklama, pd_bloke_tarihi, pd_bloke_bitis_tarihi, 'BG', '1200', pkg_genel.genel_kod_al( 'BLOKE_REF_NO'));
        
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1723' ||Pkg_Hata.getdelimiter || TO_CHAR(SQLCODE)|| ' '|| SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
 End;
END ;
/

