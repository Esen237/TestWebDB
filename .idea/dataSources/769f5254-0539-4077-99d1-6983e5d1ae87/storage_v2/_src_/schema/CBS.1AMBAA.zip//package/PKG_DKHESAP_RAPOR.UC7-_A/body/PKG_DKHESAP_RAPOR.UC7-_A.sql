create PACKAGE BODY     PKG_DKHESAP_RAPOR is
/******************************************************************************
   NAME       : PKG_DKHESAP_RAPOR
   Created By : Seval Balci
   Date       : 02.11.07
   Purpose   :DK hesap rapor fonk. icerir.
******************************************************************************/
 Function sf_dk_ba_tur_al ( ps_dk_numara varchar2) return varchar2
 is
  ls_dk_ba_kod varchar2(1);

  cursor cur_dk is
   select distinct ba_kod
   from  cbs_dkhesap
   where  numara  = ps_dk_numara;   
 Begin
  open cur_dk;
 fetch cur_dk into ls_dk_ba_kod;
 close cur_dk;
 
 return ls_dk_ba_kod ;
 Exception when others then return null; 
 End;
---------------------------------------------------------------------------------
 Function mizan_gosterim_bakiye_karakter( ps_dk_numara varchar2 ,pn_bakiye number) return varchar2
 is
  ls_ba_kod varchar2(1);
  ls_gosterim  varchar2(1);
 Begin
  if length(ps_dk_numara) = 8 then   
   ls_ba_kod := pkg_dkhesap_rapor.sf_dk_ba_tur_al ( ps_dk_numara); 
  
  if ls_ba_kod ='A' and nvl(pn_bakiye,0) <0  then 
       ls_gosterim := '*';
  end if;
  if ls_ba_kod ='B' and nvl(pn_bakiye,0) > 0 then 
       ls_gosterim := '*';
  end if;
 end if ;  
 return ls_gosterim;
 Exception when others then return null; 
 End;
 ---------------------------------------------------------------------------------
END ;
/

