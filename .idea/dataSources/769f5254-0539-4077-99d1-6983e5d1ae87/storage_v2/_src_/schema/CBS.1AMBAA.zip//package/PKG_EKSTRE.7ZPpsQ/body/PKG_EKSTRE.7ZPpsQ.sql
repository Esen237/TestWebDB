create PACKAGE BODY     "PKG_EKSTRE" IS
----------------------------------------------------------------------------------------
PROCEDURE PREPARE_CUSTOMER_STATEMENT IS
    CURSOR c1 IS
        SELECT hesap_no,musteri_no
        FROM cbs_hesap
        WHERE durum_kodu = 'A';
    r1                         c1%ROWTYPE;
    pd_last_eod DATE;
    ld_bas_tarih     DATE; 
    CURSOR c2 IS
        SELECT /*+ RULE */ musteri_no,
         fis_numara,
         fis_islem_numara,
         trim(UPPER(isim_unvan)) isim_unvan,
         hesap_turu,
         vergi_no,
         hesap_doviz_kodu,
         adres,
         fis_fis_no,
         fis_tur,
         satir_numara,
         satir_tur,
         satir_hesap_bolum_kodu,
         fis_muhasebelestigi_tarih,
         satir_valor_tarihi,
         satir_dv_tutar,
         satir_doviz_kod,
         SUBSTR(satir_musteri_aciklama,1,500) satir_musteri_aciklama,
         bolum_kodu,
         fis_yaratildigi_banka_tarih,
         Pkg_Genel.bolum_adi_al_hatasiz(satir_hesap_bolum_kodu) AS bolum_adi,
         Pkg_Report5.GetNBEquivalent(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEquivalent,
                CASE WHEN satir_dv_tutar > 0 THEN satir_dv_tutar ELSE 0 END credit,
                CASE WHEN satir_dv_tutar < 0 THEN satir_dv_tutar ELSE 0 END debit,
            personel_sicil_no
        FROM cbs_vw_hesap_ekstre
         WHERE satir_hesap_numara = TO_CHAR(r1.hesap_no)  AND
                fis_tur = 'G' AND               --sevalb 29092011
                FIS_MUHASEBELESTIGI_TARIH BETWEEN ld_bas_tarih AND pd_last_eod;  --sevalb 29092011

    r2                         c2%ROWTYPE;




    ls_external_acc VARCHAR2(30);
    ls_vergi          VARCHAR2(100);
    ls_donem         VARCHAR2(100);
    ln_extre_no      NUMBER;
    ln_credit      NUMBER;
    ln_debit          NUMBER;
    ln_devir_bakiye     NUMBER;
    ln_ok          NUMBER;
    ln_cnt             NUMBER;
    ls_bitti          VARCHAR2(1);


    ls_content CLOB :='';
    ls_header VARCHAR2(100):='';
    ln_bakiye                     NUMBER;
    ln_sicil                     NUMBER;
    say                            NUMBER;
    say2                            NUMBER;
    
    ls_json CLOB; --NURZALATA 20.06.17
    ls_ret varchar2(3); --NURZALATA 20.06.17
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE; --NURZALATA 24.06.17

--
------------AML variables --------------
    ld_date DATE;

    CURSOR c_0(pd_date DATE) IS
        SELECT * FROM CBS_VW_ANTI_MONEY_LAUNDERING
     WHERE --LC_AMOUNT>=1000000
        --AND --CBS-31, CBS-32 NurdinI commented out
        TX_DATE=pd_date
        ORDER BY TX_CODE;
---------------------------------------------*********************************************************************************************
    CURSOR c_1(pd_date DATE) IS
        SELECT DISTINCT tbl.TX_CODE,tbl.TX_NO,tbl.TX_NAME,tbl.TX_DATE,tbl.ISLEM_TARIH_SAAT,tbl.CURRENCY_CODE,
                        tbl.AMOUNT,tbl.LC_AMOUNT,tbl.EXPLANATION,tbl.FROM_TYP,tbl.FROM_CUSTOMER_NO,tbl.FROM_CUST_TYPE,
                        tbl.FROM_NAME,tbl.FROM_ISIM,tbl.FROM_IKINCI_ISIM,tbl.FROM_SOYADI,tbl.FROM_ADDRESS,tbl.FROM_DOC_SERIAL,
                        tbl.FROM_DOC_ORGAN,tbl.FROM_BIRTH_DATE,tbl.FROM_BIRTHPLACE,tbl.FROM_BIC_ACC,tbl.FROM_BANK_NAME,
                        tbl.FROM_BIC_BANK,tbl.FROM_ORGNAME,tbl.FROM_REGNUM,tbl.FROM_OKPO,tbl.FROM_ORGAN,tbl.FROM_ORGFORM_CODE,
                        tbl.FROM_RES,tbl.TO_TYP,tbl.TO_CUSTOMER_NO,tbl.TO_CUST_TYPE,tbl.TO_NAME,tbl.TO_ADDRESS,tbl.TO_DOC_SERIAL,
                        tbl.TO_DOC_ORGAN,tbl.TO_BIRTH_DATE,tbl.TO_BIRTHPLACE,tbl.TO_BIC_ACC,tbl.TO_BANK_NAME,tbl.TO_BIC_BANK,
                        tbl.TO_ORGNAME,tbl.TO_REGNUM,tbl.TO_OKPO,tbl.TO_ORGAN,tbl.TO_ORGFORM_CODE,tbl.TO_RES,tbl.TO_COUNTRY_CODE,
                        tbl.BANK_CORRESPONDENT, tbl.BANK_CORRESPONDENT_ADRES, tbl.ACCOUNT_NO, tbl.OPERATION_NO, tbl.CONTROL_NO,
                        tbl.FROM_COUNTRY_CODE,tbl.FROM_DOC_ORGAN_ISSUE_DATE,tbl.INDIVIDUAL_REGISTRY,tbl.TO_DOC_ORGAN_ISSUE_DATE,
                        tbl.INDIVIDUAL_REGISTRY2,tbl.SUMTGT FROM(
                                SELECT a.*
                                FROM CBS_VW_ANTI_MONEY_LAUND14 a,
                                    (
                                    SELECT from_bic_acc, to_bic_acc, SUM(lc_amount) sum_lc_amount
                                    FROM CBS_VW_ANTI_MONEY_LAUND14 d
                                    WHERE TX_Date BETWEEN (pd_date-14) AND pd_date
                                    --AND lc_amount < 1000000 --CBS-31, CBS-32 NurdinI commented out
                                    and currency_code is not null -- CQ1176 problem with null currency code which raise error 328
                                    AND d.tx_no NOT IN (SELECT c.tx_no FROM table1 c WHERE c.tx_no=d.tx_no )----------------!!!!!
                                    AND d.tx_no NOT IN (SELECT e.tx_no FROM cbs_anti_money_laund14 e WHERE e.tx_no=d.tx_no )----------------!!!!!
                                    GROUP BY from_bic_acc, to_bic_acc
                                    ) b
                                WHERE --b.sum_lc_amount>=1000000
                                 --AND   CBS-31, CBS-32 NurdinI commented out
                                 (a.tx_date) BETWEEN (pd_date-14) AND pd_date
                                 AND a.from_bic_acc=b.from_bic_acc
                                 AND a.to_bic_acc=b.to_bic_acc
                                 and currency_code is not null -- CQ1176 problem with null currency code which raise error 328
                                 AND a.tx_no NOT IN (SELECT c.tx_no FROM table1 c WHERE c.tx_no=a.tx_no )---------------!!!!
                                 AND a.tx_no NOT IN (SELECT e.tx_no FROM cbs_anti_money_laund14 e WHERE e.tx_no=a.tx_no )----------------!!!!!
                                 --AND a.lc_amount < 1000000 --CBS-31, CBS-32 NurdinI commented out
                                ) TBL
                                --  b-o-m sevalb 15022011 asagidaki kismin gereksiz oldugu anlasildi kapatiyorum.
                             /*   ,(SELECT a.*
                                 FROM CBS_VW_ANTI_MONEY_LAUND14 a,
                                    (
                                     SELECT from_bic_acc, to_bic_acc, sum(lc_amount) sum_lc_amount
                                     FROM CBS_VW_ANTI_MONEY_LAUND14 d
                                     WHERE TX_Date between (pd_date-14) and pd_date
                                     and lc_amount < 1000000
                                     And d.tx_no not in (select c.tx_no from table1 c where c.tx_no=d.tx_no )
                                     And d.tx_no not in (select e.tx_no from cbs_anti_money_laund14 e where e.tx_no=d.tx_no )----------------!!!!!
                                     GROUP BY from_bic_acc, to_bic_acc
                                     ) b
                                WHERE b.sum_lc_amount>=1000000
                             and (a.tx_date) Between (pd_date-14) And pd_date
                                 and a.from_bic_acc=b.from_bic_acc
                                 and a.to_bic_acc=b.to_bic_acc
                                 and a.tx_no not in (select c.tx_no from table1 c where c.tx_no=a.tx_no )----------!!!!
                                 and a.tx_no not in (select e.tx_no from cbs_anti_money_laund14 e where e.tx_no=a.tx_no )----------------!!!!!
                                 and a.lc_amount < 1000000
                                 ) TBL1
                    where tbl.to_customer_no||tbl.from_customer_no=tbl1.to_customer_no||tbl1.from_customer_no
                    -- e-o-m sevalb 15022011 asagidaki kismin gereksiz oldugu anlasildi kapatiyorum.
                    */
            ORDER BY tbl.tx_code,tbl.from_customer_no,tbl.to_customer_no,tbl.islem_tarih_saat;

    r_0 c_0%ROWTYPE;
    r_1 c_1%ROWTYPE;

    CURSOR c_custu(pd_date DATE) IS
        SELECT m.BOLUM_KODU,h.HESAP_NO,h.MUSTERI_NO,h.DOVIZ_KODU,s.dv_tutar,f.MUHASEBELESTIGI_TARIH,
         m.PAZARLAMA_SORUMLUSU_SICIL_NO_1,m.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
             F.NUMARA fis_no, S.NUMARA satir_no,m.REPORT_CUSTOMER_TYPE,s.lc_tutar, I.NUMARA, I.ISLEM_KOD
        FROM cbs_hesap h, cbs_fis f, cbs_satir s,cbs_islem i,cbs_musteri m
        WHERE h.durum_kodu= 'A'
         AND s.tur = 'A'
         AND h.musteri_no = m.musteri_no
         AND f.islem_numara = i.numara
         AND i.islem_kod IN (1203, 2012, 3556, 6200, 2150, 6202, 1207, 4025, 3199)       --CQ5583 MederT 08092016
         AND s.hesap_tur_kodu = 'VS'
         AND s.hesap_numara = TO_CHAR(h.hesap_no)
         AND f.tur = 'G'
         AND f.numara = s.fis_numara
         AND f.MUHASEBELESTIGI_TARIH >= pd_date
         AND f.MUHASEBELESTIGI_TARIH <= pd_date;

    r_custu               c_custu%ROWTYPE;
    ld_date_custu            DATE;
    sayac                    NUMBER;

    ld_date_activ            DATE;

-- SALARY variables
    CURSOR c11 IS
        SELECT *
        FROM CBS_VW_SALARY_MONITOR;
    r11 c11%ROWTYPE;

    kont     NUMBER:=0;
    bastar      DATE;
    bittar      DATE;

    ls_FIRM_CONTACT_INFORMATION             VARCHAR2(200);
    ls_Title                             VARCHAR2(200);
    ln_Last_Salary_Amount                 NUMBER;
    ld_Last_Payment_Date                 DATE;
    ln_EXISTING_lIMIT                     NUMBER;
    ln_Last_3_Months_Salary             NUMBER;
    ls_Address                             VARCHAR2(500);
    ls_email                            VARCHAR2(100);
    ls_home                             VARCHAR2(30);
    ls_gsm                                VARCHAR2(30);
-- SALARY variables


-------- SALARY WARNING VARIABLES --------
    CURSOR c1_sw(pd_date_1_sw DATE, pd_date_2_sw DATE) IS
        SELECT DISTINCT STAFF_ACCOUNT_NO
        FROM cbs_islem i, CBS_SALARY_DETAIL s
        WHERE i.numara = s.TX_NO
         AND i.durum = 'P'
         AND NVL(i.ONAY_SISTEM_TARIHI,i.KAYIT_SISTEM_TARIHI) BETWEEN pd_date_1_sw AND pd_date_2_sw;
    r1_sw c1_sw%ROWTYPE;

    CURSOR c2_sw(pd_date_11_sw DATE, pd_date_12_sw DATE) IS
        SELECT *
        FROM cbs_islem i, CBS_SALARY_DETAIL s
        WHERE i.numara = s.TX_NO
         AND i.durum = 'P'
         AND s.STAFF_ACCOUNT_NO = r1_sw.STAFF_ACCOUNT_NO
         AND NVL(i.ONAY_SISTEM_TARIHI,i.KAYIT_SISTEM_TARIHI) BETWEEN pd_date_11_sw AND pd_date_12_sw
         AND s.tx_no = (SELECT MAX(tx_no)
                         FROM cbs_islem i, CBS_SALARY_DETAIL s
                         WHERE i.numara = s.TX_NO
                         AND i.durum = 'P'
                         AND s.STAFF_ACCOUNT_NO = r1_sw.STAFF_ACCOUNT_NO
                         AND NVL(i.ONAY_SISTEM_TARIHI,i.KAYIT_SISTEM_TARIHI) BETWEEN pd_date_11_sw AND pd_date_12_sw);
    r2_sw c2_sw%ROWTYPE;

    say_sw                          NUMBER:=0;
    say_2_sw                          NUMBER:=0;
    ln_rate_sw                     NUMBER:=0;
    ln_mail_rate_sw             NUMBER:=0;
    ln_fark_sw                     NUMBER:=0;
    ln_fark_2_sw                     NUMBER:=0;
    ln_last_3_months_sw         NUMBER:=0;
    ln_firm_no_sw                 NUMBER:=0;
    ln_diff_sw                     NUMBER:=0;
    ls_inc_dec_sw                 VARCHAR2(1);
    ld_date_sw                      DATE;
    ld_date_1_sw                 DATE;
    ld_date_2_sw                 DATE;

    ln_sum_sw                       NUMBER;
    ln_musteri_sw                  NUMBER;

    ls_content_sw CLOB :='';
    ls_html_sw CLOB:='';
    ls_header_sw VARCHAR2(100):='';
-------- SALARY WARNING VARIABLES --------

-------- CUSTOMER NOTIFICATION VARIABLES -------- AdiletK 09.12.2014 CQ867 Sending notifications at EOD
CURSOR cust_list IS
   SELECT customer_no 
   FROM cbs_customer_notification
   WHERE frequency <> 'NOW';
    
   r_list cust_list%ROWTYPE;
   
   ls_cust_result VARCHAR2(30);    
   ls_ads_result VARCHAR2(30);    
   
   ls_email_list CBS_PARAMETRE.DEGER%TYPE;
   
-------- CUSTOMER NOTIFICATION VARIABLES --------
BEGIN
    pkg_parametre.deger('EOD_EMAIL_LIST', ls_email_list);
-------------
-------------
-------------
-------------
-------------
---------------- AML Program Starts Here ----------------
--
    BEGIN 
        BEGIN
            ls_header := ' AML Batch program started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            ls_content:='AML Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages(''); 
            
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);   
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_aml_mail_error_1',SQLERRM);
        END;
    Log_At('pkg_ekstre_hakan_aml_1mio_batch_started');

        ld_date := Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul;
    --    ld_date := to_date('23102008','ddmmyyyy');

        say := 0;

        DELETE FROM cbs_anti_money_laundering
        WHERE EOD_DATE = ld_date;

        DELETE FROM cbs_anti_money_laund14
        WHERE EOD_DATE = ld_date;

        OPEN c_0(ld_date);
        LOOP
            FETCH c_0 INTO r_0;
            EXIT WHEN c_0%NOTFOUND;

            INSERT INTO cbs_anti_money_laundering
            (TX_CODE, TX_NO, TX_NAME, TX_DATE, ISLEM_TARIH_SAAT, CURRENCY_CODE, AMOUNT, LC_AMOUNT,
             EXPLANATION, FROM_TYP, FROM_CUSTOMER_NO, FROM_CUST_TYPE, FROM_NAME, FROM_ISIM, FROM_IKINCI_ISIM,
             FROM_SOYADI, FROM_ADDRESS, FROM_DOC_SERIAL, FROM_DOC_ORGAN, FROM_BIRTH_DATE, FROM_BIRTHPLACE,
             FROM_BIC_ACC, FROM_BANK_NAME, FROM_BIC_BANK, FROM_ORGNAME, FROM_REGNUM, FROM_OKPO, FROM_ORGAN,
             FROM_ORGFORM_CODE, FROM_RES, TO_TYP, TO_CUSTOMER_NO, TO_CUST_TYPE, TO_NAME, TO_ADDRESS,
             TO_DOC_SERIAL, TO_DOC_ORGAN, TO_BIRTH_DATE, TO_BIRTHPLACE, TO_BIC_ACC, TO_BANK_NAME,
             TO_BIC_BANK, TO_ORGNAME, TO_REGNUM, TO_OKPO, TO_ORGAN, TO_ORGFORM_CODE, TO_RES,
             TO_COUNTRY_CODE, BANK_CORRESPONDENT, BANK_CORRESPONDENT_ADRES, ACCOUNT_NO, OPERATION_NO,
             CONTROL_NO, FROM_COUNTRY_CODE, FROM_DOC_ORGAN_ISSUE_DATE, INDIVIDUAL_REGISTRY,
             TO_DOC_ORGAN_ISSUE_DATE, INDIVIDUAL_REGISTRY2, SUMTGT, EOD_DATE,FROM_ACTIVITIES,-- start CQ 578 Konstantin Zhukov 15.04.2014
 TO_ACTIVITIES,
 FROM_DISPONENT_NAME,
 TO_DISPONENT_NAME,
   FROM_DISPONENT_DOC_CODE,
   TO_DISPONENT_DOC_CODE,
   FROM_DISPONENT_DOC_SERIES,
   TO_DISPONENT_DOC_SERIES,
   FROM_DISPONENT_DOC_NUM,
   TO_DISPONENT_DOC_NUM,
   FROM_DISPONENT_DOC_ISSUEDATE,
   TO_DISPONENT_DOC_ISSUEDATE,
 FROM_DISPONENT_DOC_ORGAN,
 TO_DISPONENT_DOC_ORGAN,
 FROM_OWNER_ACTIVITIES,
 TO_OWNER_ACTIVITIES    )-- end CQ 578 Konstantin Zhukov 15.04.2014
            VALUES
            (r_0.TX_CODE, r_0.TX_NO, r_0.TX_NAME, r_0.TX_DATE, r_0.ISLEM_TARIH_SAAT, r_0.CURRENCY_CODE, r_0.AMOUNT, r_0.LC_AMOUNT,
             SUBSTR(r_0.EXPLANATION,1,200), r_0.FROM_TYP, r_0.FROM_CUSTOMER_NO, r_0.FROM_CUST_TYPE, r_0.FROM_NAME, r_0.FROM_ISIM, r_0.FROM_IKINCI_ISIM,
             r_0.FROM_SOYADI, r_0.FROM_ADDRESS, r_0.FROM_DOC_SERIAL, r_0.FROM_DOC_ORGAN, r_0.FROM_BIRTH_DATE, r_0.FROM_BIRTHPLACE,
             r_0.FROM_BIC_ACC, r_0.FROM_BANK_NAME, r_0.FROM_BIC_BANK, r_0.FROM_ORGNAME, r_0.FROM_REGNUM, r_0.FROM_OKPO, r_0.FROM_ORGAN,
             r_0.FROM_ORGFORM_CODE, r_0.FROM_RES, r_0.TO_TYP, r_0.TO_CUSTOMER_NO, r_0.TO_CUST_TYPE, r_0.TO_NAME, r_0.TO_ADDRESS,
             r_0.TO_DOC_SERIAL, r_0.TO_DOC_ORGAN, r_0.TO_BIRTH_DATE, r_0.TO_BIRTHPLACE, r_0.TO_BIC_ACC, r_0.TO_BANK_NAME,
             r_0.TO_BIC_BANK, r_0.TO_ORGNAME, r_0.TO_REGNUM, r_0.TO_OKPO, r_0.TO_ORGAN, r_0.TO_ORGFORM_CODE, r_0.TO_RES,
             r_0.TO_COUNTRY_CODE, r_0.BANK_CORRESPONDENT, r_0.BANK_CORRESPONDENT_ADRES, r_0.ACCOUNT_NO, r_0.OPERATION_NO,
             r_0.CONTROL_NO, r_0.FROM_COUNTRY_CODE, r_0.FROM_DOC_ORGAN_ISSUE_DATE, r_0.INDIVIDUAL_REGISTRY,
             r_0.TO_DOC_ORGAN_ISSUE_DATE, r_0.INDIVIDUAL_REGISTRY2, r_0.SUMTGT,  ld_date, r_0.FROM_ACTIVITIES,-- start CQ 578 Konstantin Zhukov 15.04.2014
  r_0.TO_ACTIVITIES,
  r_0.FROM_DISPONENT_NAME,
  r_0.TO_DISPONENT_NAME,
    r_0.FROM_DISPONENT_DOC_CODE,
    r_0.TO_DISPONENT_DOC_CODE,
    r_0.FROM_DISPONENT_DOC_SERIES,
    r_0.TO_DISPONENT_DOC_SERIES,
    r_0.FROM_DISPONENT_DOC_NUM,
    r_0.TO_DISPONENT_DOC_NUM,
    r_0.FROM_DISPONENT_DOC_ISSUEDATE,
    r_0.TO_DISPONENT_DOC_ISSUEDATE,
  r_0.FROM_DISPONENT_DOC_ORGAN,
  r_0.TO_DISPONENT_DOC_ORGAN,
  r_0.FROM_OWNER_ACTIVITIES,
  r_0.TO_OWNER_ACTIVITIES    );-- end CQ 578 Konstantin Zhukov 15.04.2014

            say := say + 1;
            IF say = 30
            THEN
                COMMIT;
                say := 0;
            END IF;
        END LOOP;
        CLOSE c_0;
        COMMIT;
    Log_At('pkg_ekstre_hakan_aml_1mio_batch_finished');

    Log_At('pkg_ekstre_hakan_aml_14days_batch_started');
    say := 0;

        OPEN c_1(ld_date);
        LOOP
        FETCH c_1 INTO r_1;
        EXIT WHEN c_1%NOTFOUND;
          BEGIN
            INSERT INTO cbs_anti_money_laund14
            (TX_CODE, TX_NO, TX_NAME, TX_DATE, ISLEM_TARIH_SAAT, CURRENCY_CODE, AMOUNT, LC_AMOUNT,
             EXPLANATION, FROM_TYP, FROM_CUSTOMER_NO, FROM_CUST_TYPE, FROM_NAME, FROM_ISIM, FROM_IKINCI_ISIM,
             FROM_SOYADI, FROM_ADDRESS, FROM_DOC_SERIAL, FROM_DOC_ORGAN, FROM_BIRTH_DATE, FROM_BIRTHPLACE,
             FROM_BIC_ACC, FROM_BANK_NAME, FROM_BIC_BANK, FROM_ORGNAME, FROM_REGNUM, FROM_OKPO, FROM_ORGAN,
             FROM_ORGFORM_CODE, FROM_RES, TO_TYP, TO_CUSTOMER_NO, TO_CUST_TYPE, TO_NAME, TO_ADDRESS,
             TO_DOC_SERIAL, TO_DOC_ORGAN, TO_BIRTH_DATE, TO_BIRTHPLACE, TO_BIC_ACC, TO_BANK_NAME,
             TO_BIC_BANK, TO_ORGNAME, TO_REGNUM, TO_OKPO, TO_ORGAN, TO_ORGFORM_CODE, TO_RES,
             TO_COUNTRY_CODE, BANK_CORRESPONDENT, BANK_CORRESPONDENT_ADRES, ACCOUNT_NO, OPERATION_NO,
             CONTROL_NO, FROM_COUNTRY_CODE, FROM_DOC_ORGAN_ISSUE_DATE, INDIVIDUAL_REGISTRY,
             TO_DOC_ORGAN_ISSUE_DATE, INDIVIDUAL_REGISTRY2, SUMTGT, EOD_DATE)
            VALUES
            (r_1.TX_CODE, r_1.TX_NO, SUBSTR(r_1.TX_NAME,1,200), r_1.TX_DATE, r_1.ISLEM_TARIH_SAAT, SUBSTR(r_1.CURRENCY_CODE,1,3), r_1.AMOUNT, r_1.LC_AMOUNT,
             SUBSTR(r_1.EXPLANATION,1,200), r_1.FROM_TYP, r_1.FROM_CUSTOMER_NO, r_1.FROM_CUST_TYPE, SUBSTR(r_1.FROM_NAME,1,200),
             SUBSTR(r_1.FROM_ISIM,1,200), SUBSTR(r_1.FROM_IKINCI_ISIM,1,200),
             SUBSTR(r_1.FROM_SOYADI,1,200), SUBSTR(r_1.FROM_ADDRESS,1,200), r_1.FROM_DOC_SERIAL, r_1.FROM_DOC_ORGAN, r_1.FROM_BIRTH_DATE, r_1.FROM_BIRTHPLACE,
             r_1.FROM_BIC_ACC, SUBSTR(r_1.FROM_BANK_NAME,1,200), SUBSTR(r_1.FROM_BIC_BANK,1,50), SUBSTR(r_1.FROM_ORGNAME,1,200),SUBSTR( r_1.FROM_REGNUM,1,50), r_1.FROM_OKPO, SUBSTR(r_1.FROM_ORGAN,1,200),
             SUBSTR(r_1.FROM_ORGFORM_CODE,1,2), r_1.FROM_RES, r_1.TO_TYP, r_1.TO_CUSTOMER_NO, r_1.TO_CUST_TYPE, SUBSTR(r_1.TO_NAME,1,200), SUBSTR(r_1.TO_ADDRESS,1,200),
             r_1.TO_DOC_SERIAL, r_1.TO_DOC_ORGAN, r_1.TO_BIRTH_DATE, r_1.TO_BIRTHPLACE, r_1.TO_BIC_ACC, SUBSTR(r_1.TO_BANK_NAME,1,200),
             SUBSTR(r_1.TO_BIC_BANK,1,50), SUBSTR(r_1.TO_ORGNAME,1,200), SUBSTR( r_1.TO_REGNUM,1,50),SUBSTR( r_1.TO_OKPO,1,50), SUBSTR(r_1.TO_ORGAN,1,200), SUBSTR(r_1.TO_ORGFORM_CODE,1,2), r_1.TO_RES,
             r_1.TO_COUNTRY_CODE, r_1.BANK_CORRESPONDENT,SUBSTR( r_1.BANK_CORRESPONDENT_ADRES,1,200), r_1.ACCOUNT_NO, r_1.OPERATION_NO,
             r_1.CONTROL_NO, r_1.FROM_COUNTRY_CODE, r_1.FROM_DOC_ORGAN_ISSUE_DATE, r_1.INDIVIDUAL_REGISTRY,
             r_1.TO_DOC_ORGAN_ISSUE_DATE, r_1.INDIVIDUAL_REGISTRY2, r_1.SUMTGT, ld_date);
           EXCEPTION WHEN OTHERS THEN
            Log_At('AML Batch hatali kayit',r_1.TX_NO,SQLCODE,SUBSTR(SQLERRM,1,200));
            ROLLBACK;
           END;
          COMMIT;
        END LOOP;
        CLOSE c_1;

        COMMIT;

        BEGIN
            ls_header := ' AML Batch Program finished succesfully (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">AML Batch Program finished succesfully...</font></td></tr></table>';
            ls_content:='AML Batch Program finished succesfully...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages(''); 
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);  
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_aml_mail_error_3',SQLERRM);
        END;

    Log_At('pkg_ekstre_hakan_aml_14days_batch_finished');
    EXCEPTION
        WHEN OTHERS THEN
        ROLLBACK;
        Log_At('pkg_ekstre_AML_Error_log','AML Batch Program error: 1',SQLERRM);
        BEGIN
            ls_header := ' AML Batch Program Error-1';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">AML Batch Program got error-1. Please contact to C Bilisim...</font></td></tr></table>';
            ls_content:='AML Batch Program got error-1. Please contact to C Bilisim...';
            --ls_content:=ls_content || '</body></html>';
            -- Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_aml_mail_error_1',SQLERRM);
        END;
    END;
-------------
-------------
---------------- AML Program FINISHED----------------
-------------
-------------
-------------
-------------
---------------- CUSTU Program Starts Here----------------
-------------
-------------
    BEGIN
        BEGIN
            ls_header := ' CUSTU Batch program started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">CUSTU Batch program started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
            ls_content:='CUSTU Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            -- Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_custu_mail_error_1',SQLERRM);
        END;

        ld_date_custu := Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul;
Log_At('pkg_ekstre_ld_date_custu',ld_date_custu);

        sayac := 0;

        OPEN c_custu(ld_date_custu);
        LOOP
        FETCH c_custu INTO r_custu;
        EXIT WHEN c_custu%NOTFOUND;
            INSERT INTO CBS_CUSTOMER_TURNOVER
            (MUSTERI_NO, SUBE_KODU, HESAP_NO, DOVIZ_KODU, AMOUNT, EOD_DATE,
             PAZ_SIC_1,PAZ_SIC_2, FIS_NO, SATIR_NO,MUSTERI_SME_TIPI,LC_AMOUNT,TX_NO,TRAN_CODE)
            VALUES
            (r_custU.MUSTERI_NO, r_custu.BOLUM_KODU, r_custu.HESAP_NO, r_custu.DOVIZ_KODU, r_custu.dv_tutar, r_custu.MUHASEBELESTIGI_TARIH,
             r_custu.PAZARLAMA_SORUMLUSU_SICIL_NO_1,r_custu.PAZARLAMA_SORUMLUSU_SICIL_NO_2,r_custu.fis_no,r_custu.satir_no,
             r_custu.REPORT_CUSTOMER_TYPE,r_custu.lc_tutar,r_custu.numara,r_custu.islem_kod);

            sayac := sayac + 1;
            IF sayac = 50
            THEN
                COMMIT;
                sayac := 0;
            END IF;
        END LOOP;
        CLOSE c_custu;

        COMMIT;
Log_At('pkg_ekstre_custu_bitti');

        BEGIN
            ls_header := ' Custu Batch Program finished succesfully (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Custu Batch Program finished succesfully...</font></td></tr></table>';
            ls_content:='Custu Batch Program finished succesfully...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_custu_mail_error_3',SQLERRM);
        END;

        EXCEPTION
            WHEN OTHERS THEN
            ROLLBACK;
            Log_At('pkg_ekstre_Custu_Error_log','Custu Batch Program error: 1',SQLERRM);
            BEGIN
                ls_header := ' Custu Batch Program Error-1 (TESTDB)';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Custu Batch Program got error-1. Please contact to C Bilisim...</font></td></tr></table>';
                ls_content:='Custu Batch Program got error-1. Please contact to C Bilisim...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_custu_mail_error_1',SQLERRM);
            END;
    END;
-------------
-------------
---------------- CUSTU Program FINISHED----------------
-------------
-------------
-------------
-------------
-------------
---------------- ACTIV Program Starts Here----------------
-------------
-------------
    BEGIN
        BEGIN
            ls_header := ' ACTIV Batch program started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">ACTIV Batch program started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
            ls_content:='ACTIV Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_activ_mail_error_1',SQLERRM);
        END;

        ld_date_activ := Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul;
Log_At('pkg_ekstre_ld_date_activ',ld_date_activ);

        sayac := 0;

        INSERT INTO cbs_active_customer
        (FIS_NUMARA, FIS_MUHASEBELESTIGI_TARIH, MUSTERI_NO)
        (
        SELECT DISTINCT
        f.numara,
        f.MUHASEBELESTIGI_TARIH,
        h.musteri_no
        FROM cbs_fis f, cbs_satir s, cbs_hesap h,cbs_islem i
        WHERE f.numara = s.fis_numara
        AND f.islem_numara = i.numara
        AND TO_CHAR(h.hesap_no) = s.hesap_numara
        AND f.tur = 'G'
        AND s.HESAP_TUR_KODU = 'VS'
        AND i.islem_kod NOT IN (7048, 7049, 7050, 7052, 7053, 7054, 7057)
        AND i.durum IN ('P', '3','N')
        AND f.muhasebelestigi_tarih BETWEEN ld_date_activ-10 AND ld_date_activ
        AND ROUND((ROUND((NVL(Pkg_Kur.doviz_doviz_karsilik(h.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4))*S.DV_TUTAR,2)>=50*NVL(Pkg_Kur.doviz_doviz_karsilik('USD',Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)
        AND NOT EXISTS (SELECT 1
                        FROM cbs_active_customer a
                        WHERE a.fis_numara=s.fis_numara
                          AND a.musteri_no=h.musteri_no )
        );

/*
        insert into cbs_active_customer
        (FIS_NUMARA, SATIR_NUMARA, FIS_MUHASEBELESTIGI_TARIH, SATIR_HESAP_NUMARA, MUSTERI_NO)
        (
        SELECT
        f.numara,
        s.NUMARA,
        f.MUHASEBELESTIGI_TARIH,
        s.hesap_numara,
        h.musteri_no
        FROM cbs_fis f, cbs_satir s, cbs_hesap_vadeli h,cbs_islem i
        WHERE f.numara = s.fis_numara
        and f.islem_numara = i.numara
        and to_char(h.hesap_no) = s.hesap_numara
        and f.tur = 'G'
        and s.HESAP_TUR_KODU = 'VD'
        and i.islem_kod NOT IN (7048, 7049, 7050, 7052, 7053, 7054, 7057)
        AND i.durum IN ('P', '3','N')
        AND f.muhasebelestigi_tarih BETWEEN ld_date_activ-10 AND ld_date_activ
        and round((round((nvl(Pkg_Kur.doviz_doviz_karsilik(h.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)),4))*S.DV_TUTAR,2)>=50*nvl(Pkg_Kur.doviz_doviz_karsilik('USD',Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A'),0)
        and (s.FIS_NUMARA,s.NUMARA) not in (select FIS_NUMARA, SATIR_NUMARA from cbs_active_customer)
        );
*/

        COMMIT;
Log_At('pkg_ekstre_activ_bitti');

        BEGIN
            ls_header := ' Activ Batch Program finished succesfully (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Activ Batch Program finished succesfully...</font></td></tr></table>';
            ls_content:='Activ Batch Program finished succesfully...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_activ_mail_error_3',SQLERRM);
        END;

        EXCEPTION
            WHEN OTHERS THEN
            ROLLBACK;
            Log_At('pkg_ekstre_activ_Error_log','Activ Batch Program error: 1 (TESTDB)',SQLERRM);
            BEGIN
                ls_header := ' Activ Batch Program Error-1';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Activ Batch Program got error-1. Please contact to C Bilisim...</font></td></tr></table>';
                ls_content:='Activ Batch Program got error-1. Please contact to C Bilisim...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_activ_mail_error_1',SQLERRM);
            END;
    END;
-------------
-------------
---------------- ACTIV Program FINISHED----------------
-------------
-------------


-------------
---------------- SALARY Program Starts Here----------------
-------------
-------------
    say:= 1;
    BEGIN
        BEGIN
            ls_header := ' SALARY Batch program started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">SALARY Batch program started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
            ls_content:='SALARY Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_salary_mail_error_1',SQLERRM);
        END;

Log_At('pkg_ekstre_salary_basla');

 IF Pkg_Dates.get_last_work_day_in_month(Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul) = Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul
 THEN --EOM
    DELETE CBS_SALARY_3_MONTHS
    WHERE BANK_DATE = Pkg_Muhasebe.Banka_Tarihi_Bul;

    bastar := Pkg_Dates.get_first_day_in_month(ADD_MONTHS(Pkg_Muhasebe.Banka_Tarihi_Bul,-3));
    bittar := Pkg_Dates.get_last_day_in_month(ADD_MONTHS(Pkg_Muhasebe.Banka_Tarihi_Bul,-1));

    OPEN c11;
    LOOP
    FETCH c11 INTO r11;
    EXIT WHEN c11%NOTFOUND;
        kont := 1;

        IF r11.SOURCE_SCREEN = '2150'
        THEN
            SELECT COUNT(*)
            INTO ln_cnt
            FROM CBS_SALARY_DETAIL
            WHERE STAFF_ACCOUNT_NO = r11.account_no
              AND payment_date BETWEEN bastar AND bittar;

            IF ln_cnt = 0
            THEN
                kont := 0;
            ELSE
                ls_FIRM_CONTACT_INFORMATION := Pkg_Musteri.Sf_Musteri_Adi(r11.FIRM_NO) ;
                ls_Title := Pkg_Musteri.Sf_Musteri_Adi(r11.customer_no);
                ln_Last_Salary_Amount := Pkg_Genel_2.Last_Salary_Amount(r11.account_no);
                ld_Last_Payment_Date := Pkg_Genel_2.Last_Payment_Date(r11.account_no);
                ln_EXISTING_lIMIT := Pkg_Genel_2.Kredi_Limit(r11.customer_no);
                ln_Last_3_Months_Salary := Pkg_Genel_2.Total_Salary_Amount(r11.account_no);
                ls_Address := Pkg_Musteri.sf_adres_al(r11.customer_no);

                SELECT EMAIL,TEL_ALAN_KOD||TEL_NO,GSM_ALAN_KOD||GSM_NO
                INTO ls_email, ls_home, ls_gsm
                FROM cbs_musteri_adres
                WHERE MUSTERI_NO = r11.customer_no
                  AND adres_kod = (SELECT MAX(adres_kod)
                                   FROM cbs_musteri_adres a
                                   WHERE a.MUSTERI_NO = r11.customer_no);
            END IF;
        ELSE
            SELECT COUNT(*)
            INTO ln_cnt
            FROM cbs_hesap h, cbs_sba_satir_islem c, cbs_islem i
            WHERE UPPER(c.banka_aciklama) LIKE '%SALARY%'
            AND c.tur = 'A'
            AND c.hesap_tur_kodu = 'VS'
            AND h.hesap_no = r11.account_no
            AND TO_CHAR(h.hesap_no) = c.HESAP_NUMARA
            AND i.numara = c.tx_no
            AND c.tx_no = r11.tx_no
            AND i.durum IN ('P', '3')
            AND i.ONAY_SISTEM_TARIHI BETWEEN bastar AND bittar;
            IF ln_cnt = 0
            THEN
                kont := 0;
            ELSE
                ls_Title := Pkg_Musteri.Sf_Musteri_Adi(r11.customer_no);
                ln_Last_Salary_Amount := Pkg_Genel_2.Last_Salary_Amount(r11.account_no) ;
                ld_Last_Payment_Date := Pkg_Genel_2.Last_Payment_Date(r11.account_no) ;
                ln_EXISTING_lIMIT := Pkg_Genel_2.Kredi_Limit(r11.customer_no) ;
                ln_Last_3_Months_Salary := Pkg_Genel_2.Total_Salary_Amount(r11.account_no) ;
                ls_Address := Pkg_Musteri.sf_adres_al(r11.customer_no);

                SELECT EMAIL,TEL_ALAN_KOD||TEL_NO,GSM_ALAN_KOD||GSM_NO
                INTO ls_email, ls_home, ls_gsm
                FROM cbs_musteri_adres
                WHERE MUSTERI_NO = r11.customer_no
                  AND adres_kod = (SELECT MAX(adres_kod)
                                   FROM cbs_musteri_adres a
                                   WHERE a.MUSTERI_NO = r11.customer_no);
            END IF;
        END IF;

        IF kont = 1
        THEN
            INSERT INTO CBS_SALARY_3_MONTHS
            (COMPANY_ACCOUNT_NO, FIRM_ID, FIRM_NO, FIRM_CONTACT_INFORMATION, TITLE, BRANCH,
             ACCOUNT_NO, CUSTOMER_NO, LAST_SALARY_AMOUNT, CURRENCY_CODE, LAST_PAYMENT_DATE,
             PASAPORT_NO, EXISTING_LIMIT, ACCOUNT_OPENING_DATE, LAST_3_MONTHS_SALARY, E_MAIL,
             PLACE_OF_PASSPORT_ISSUE, DATE_OF_PASSPORT_ISSUE, DATE_OF_PASSPORT_VALIDITY, BIRTH_DATE,
             ADDRESS, TEL_NO, SOURCE_SCREEN,BANK_DATE,TX_NO)
            VALUES
            (r11.COMPANY_ACCOUNT_NO, r11.FIRM_ID, r11.FIRM_NO, ls_FIRM_CONTACT_INFORMATION, ls_Title, r11.BRANCH,
             r11.ACCOUNT_NO, r11.CUSTOMER_NO, ln_Last_Salary_Amount, r11.CURRENCY_CODE, ld_Last_Payment_Date,
             r11.PASAPORT_NO, ln_EXISTING_lIMIT, r11.ACCOUNT_OPENING_DATE, ln_Last_3_Months_Salary, ls_email,
             r11.PLACE_OF_PASSPORT_ISSUE, r11.DATE_OF_PASSPORT_ISSUE, r11.DATE_OF_PASSPORT_VALIDITY, r11.BIRTH_DATE,
             ls_Address, NVL(ls_home,ls_gsm),r11.SOURCE_SCREEN,Pkg_Muhasebe.Banka_Tarihi_Bul,r11.TX_NO);

            say:= say+1;
            IF say = 300
            THEN
                say:= 0;
                COMMIT;
            END IF;
        END IF;
    END LOOP;
    CLOSE c11;
    COMMIT;
 END IF;
Log_At('pkg_ekstre_salary_bit');

        BEGIN
            ls_header := ' SALARY Batch Program finished succesfully (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">SALARY Batch Program finished succesfully...</font></td></tr></table>';
            ls_content:='SALARY Batch Program finished succesfully...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_salary_mail_error_3',SQLERRM);
        END;

        EXCEPTION
            WHEN OTHERS THEN
            ROLLBACK;
            Log_At('pkg_ekstre_salary_Error_log','Salary Batch Program error: 1',SQLERRM);
            BEGIN
                ls_header := ' SALARY Batch Program Error-1 (TESTDB)';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">SALARY Batch Program got error-1. Please contact to C Bilisim...</font></td></tr></table>';
                ls_content:='SALARY Batch Program got error-1. Please contact to C Bilisim...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_salary_mail_error_1',SQLERRM);
            END;
    END;
-------------
-------------
---------------- SALARY Program FINISHED----------------
-------------
-------------

-------------
-------------
---------------- SALARY WARNING Program STARTED----------------
-------------
-------------

Log_At('pkg_ekstre_salary warning basladi',ld_date_activ);
    BEGIN
        ls_header_sw := ' SALARY DIFFERENCE program started to run (TESTDB)';
        --ls_content_sw:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
        --ls_content_sw:=ls_content_sw||'<table width=570><tr><td align=center><font size="+1">SALARY DIFFERENCE Batch program started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
        ls_content_sw:='SALARY DIFFERENCE Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
        --ls_content_sw:=ls_content_sw || '</body></html>';
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.SendAutoMessages('');
        
        -- SurmaliI 22.05.18
        ls_json := '{';
        ls_json := ls_json || '"##BODY##":"' || ls_content_sw || '"';
        ls_json := ls_json || '}';
        ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header_sw, to_char(ls_json), 'default_template', pc_ref);
     
        EXCEPTION
        WHEN OTHERS THEN
            Log_At('pkg_ekstre_salary_diff_mail_error_1',SQLERRM);
    END;

    ld_date_sw   := Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul;
    --ld_date_sw   := to_date('28082010','ddmmyyyy');

    say_sw := 0;
    say_2_sw := 0;
    IF Pkg_Dates.get_last_work_day_in_month(ld_date_sw) = ld_date_sw
    THEN --EOM
        Pkg_Parametre.deger('G_SALARY_INC_DEC',ln_rate_sw);
        Pkg_Parametre.deger('G_SALARY_INC_MAIL',ln_mail_rate_sw);

        ld_date_1_sw := Pkg_Dates.get_first_day_in_month(ld_date_sw);
        ld_date_2_sw := Pkg_Dates.get_last_day_in_month(ld_date_sw);

        ls_header_sw := ' SALARY DIFFERENCE FOUND';
        --ls_content_sw:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251"></head><body>';

        OPEN c1_sw(ld_date_1_sw,ld_date_2_sw);
        LOOP
        FETCH c1_sw INTO r1_sw;
        EXIT WHEN c1_sw%NOTFOUND;
            ln_sum_sw               := 0;
            ln_musteri_sw          := 0;
            ln_fark_sw           := 0;
            ln_fark_2_sw           := 0;
            ln_last_3_months_sw  := 0;

            ln_last_3_months_sw := Pkg_Genel_2.Last_3_Months_Salary(r1_sw.STAFF_ACCOUNT_NO,ld_date_1_sw);

            IF NVL(ln_last_3_months_sw,0) > 0
            THEN
                SELECT SUM(AMOUNT)
                INTO ln_sum_sw
                FROM cbs_islem i,  CBS_SALARY_DETAIL s
                WHERE i.numara = s.TX_NO
                  AND i.durum = 'P'
                  AND s.STAFF_ACCOUNT_NO = r1_sw.STAFF_ACCOUNT_NO
                  AND NVL(i.ONAY_SISTEM_TARIHI,i.KAYIT_SISTEM_TARIHI) BETWEEN ld_date_1_sw AND ld_date_2_sw;

                ln_fark_sw := (ln_last_3_months_sw * ln_rate_sw)/100;
                ln_fark_2_sw := (ln_last_3_months_sw * ln_mail_rate_sw)/100;

                IF ln_last_3_months_sw-ln_fark_sw > ln_sum_sw OR
                   ln_last_3_months_sw+ln_fark_sw < ln_sum_sw
                THEN
                    IF NVL(Pkg_Musteri.Sf_PersonelSicilNoAl(ln_musteri_sw),0) = 0
                    THEN
                        say_sw := say_sw + 1;

                        IF ln_last_3_months_sw-ln_fark_sw > ln_sum_sw
                        THEN
                            ls_inc_dec_sw := 'D';
                        ELSE
                            ls_inc_dec_sw := 'I';
                        END IF;
                        ln_diff_sw := ABS(ROUND(((ln_last_3_months_sw-ln_sum_sw)/ln_last_3_months_sw)*100,2));
                        ln_musteri_sw := Pkg_Hesap.HesaptanMusteriNoAl(r1_sw.STAFF_ACCOUNT_NO);

                        OPEN c2_sw(ld_date_1_sw,ld_date_2_sw);
                        FETCH c2_sw INTO r2_sw;
                        CLOSE c2_sw;

                        BEGIN  --sevalb 02052011 hata aldigindan exception eklendi.
                         SELECT firm_no
                         INTO ln_firm_no_sw
                         FROM CBS_SALARY_PAYMENT_FIRM_DEF
                         WHERE firm_id = r2_sw.FIRM_CODE;
                        EXCEPTION WHEN OTHERS THEN Log_At('salary diff r2_sw.FIRM_CODE',r2_sw.FIRM_CODE);
                        END ;

                         INSERT INTO CST_SALARY_DIFF
                         (CREATED_TX, CREATED_ORDER, CUSTOMER_NO, ACCOUNT_NO, FIRM_CODE, LAST_3_MONTHS, LAST_SALARY,
                          COMPANY_ACCOUNT_NO, CY_CODE, PAYMENT_DATE, PAYROL_NO, DESCRIPTION, NAME, SURNAME,
                          INC_DEC,FIRM_NO,DIFF_RATE,BANK_DATE,APPROVE_DATE)
                         VALUES
                         (r2_sw.TX_NO,r2_sw.ORDER_NO,ln_musteri_sw,r2_sw.STAFF_ACCOUNT_NO,r2_sw.FIRM_CODE,ln_last_3_months_sw,ln_sum_sw,
                           r2_sw.COMPANY_ACCOUNT_NO, r2_sw.CURRENCY_CODE, r2_sw.PAYMENT_DATE, r2_sw.PAYROL_NO, r2_sw.DESCRIPTION, r2_sw.NAME, r2_sw.SURNAME,
                          ls_inc_dec_sw,ln_firm_no_sw,ln_diff_sw,ld_date_sw,NVL(r2_sw.ONAY_SISTEM_TARIHI,r2_sw.KAYIT_SISTEM_TARIHI));
                    END IF;
                END IF;

                IF ln_last_3_months_sw-ln_fark_2_sw > ln_sum_sw OR
                   ln_last_3_months_sw+ln_fark_2_sw < ln_sum_sw
                THEN
                    IF NVL(Pkg_Musteri.Sf_PersonelSicilNoAl(ln_musteri_sw),0) = 0
                    THEN
                        say_2_sw := say_2_sw + 1;

                        IF ln_last_3_months_sw-ln_fark_2_sw > ln_sum_sw
                        THEN
                            ls_inc_dec_sw := 'D';
                        ELSE
                            ls_inc_dec_sw := 'I';
                        END IF;
                        ln_diff_sw := ABS(ROUND(((ln_last_3_months_sw-ln_sum_sw)/ln_last_3_months_sw)*100,2));
                        ln_musteri_sw := Pkg_Hesap.HesaptanMusteriNoAl(r1_sw.STAFF_ACCOUNT_NO);
                        
                        /*
                        --Tynarbek Arzymatov Mail size cok fazla buyudugu icin HTML tablosundaki suslemeler kaldirildi.
                        ls_content_sw:= ls_content_sw ||'<tr>'
                        ||'<td>'
                       -- ||'<span style="color: Black">'
                        ||TO_CHAR(ln_musteri_sw)
                       -- ||'</span>'
                        ||'</td>'
                        --||'<td valign="top" style="text-align: left; border-style: solid">'
                        --||'<span style="color: Black">'
                        --||pkg_musteri.sf_musteri_adi(ln_musteri_sw)
                        --||'</span>'
                        --||'</td>'
                        ||'<td>'
                        --||'<td valign="top" style="text-align: left; border-style: solid">'
                        --||'<span style="color: Black">'
                        ||CASE WHEN ls_inc_dec_sw = 'I' THEN 'Inc' ELSE 'Dec' END
                        --||'</span>'
                        ||'</td>'
                        ||'<td>'
                        --||'<td valign="top" style="text-align: left; border-style: solid">'
                        --||'<span style="color: Black">'
                        ||TO_CHAR(ln_diff_sw)
                        --||'</span>'
                        ||'</td>'
                        ||'</tr>';
                        */
                        --ls_content:=ls_content || 'Customer No : '||to_char(ln_musteri)
                        --                       ||' / Customer Name : '|| pkg_musteri.sf_musteri_adi(ln_musteri)
                        --                       ||' / Diff. Rate% : '
                        --                       ||case when ls_inc_dec = 'I' then ' + ' else ' - ' end
                        --                       ||' '|| to_char(ln_diff)
                        --                       || '<br/>';

                    END IF;
                END IF;
            END IF;
        END LOOP;
        CLOSE c1_sw;

        BEGIN
            ls_content_sw:='SALARY difference found for previous month over defined limit. Please check SALPA screen... ';
            /*
            ls_content_sw:='<table width=570><tr><td align=center><font size="+1">SALARY difference found for previous month over defined limit. Please check SALPA screen... '
                         || ' <br/><br/>Limit to Track: %25'
                         ||ln_rate_sw||'<br/><br/>Limit for Message : %25'
                         ||ln_mail_rate_sw||'<br/><br/></font></td></tr></table>'
                         ||'<br/><br/>Total Count (Limit to Track) = '
                         ||say_sw
                         ||'<br/><br/>Total Count (Over Limit for Message / Except DKIB Staff if Exist)= '
                         ||say_2_sw
                         ||'<br/><br/>'
            ||'<div align="left">'
            ||'<table style="border-collapse: collapse" border="1">'
            ||'<tr>'
            ||'<td valign="top" style="background: #4BACC6" width="100">'
            ||'<b><span style="color: Black">Customer No</span></b>'
            ||'</td>'
            --||'<td valign="top" style="background: #4BACC6" width="500">'
            --||'<b><span style="color: Black">Customer Name</span></b>'
            --||'</td>'
            ||'<td valign="top" style="background: #4BACC6" width="140">'
            ||'<b><span style="color: Black">Increased/Decreased</span></b>'
            ||'</td>'
            ||'<td valign="top" style="background: #4BACC6" width="120">'
            ||'<b><span style="color: Black">Difference Rate</span></b>'
            ||'</td>'
            ||'</tr>'
            ||ls_content_sw
            || '</table></div></body></html>';
            
            */
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Yana.Barabanova@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Victor.Vlasov@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');            
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' ,  ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' ,  ls_header_sw, ls_content_sw,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content_sw 
                       || '", "##RATE_SW##":"' || ln_rate_sw 
                       || '", "##MAIL_RATE_SW##":"' || ln_mail_rate_sw 
                       || '", "##SAY_SW##":"' || say_sw 
                       || '", "##SAY2_SW##":"' || say_2_sw 
                       || '", "##MUSTERI_SW##":"' || TO_CHAR(ln_musteri_sw)
                       || '", "##MUSTERI_ADI_SW##":"' || pkg_musteri.sf_musteri_adi(ln_musteri_sw)
                       || '", "##INC_DEC_SW##":"' || CASE WHEN ls_inc_dec_sw = 'I' THEN 'Inc' ELSE 'Dec' END 
                       || '", "##DIFF_SW##":"' || TO_CHAR(ln_diff_sw)
                       || '", "##CURRENT_YEAR##":"' || TO_CHAR(SYSDATE, 'YYYY');
            ls_json := ls_json || '"}';
            
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header_sw, to_char(ls_json), 'salary_difference', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_salary_diff_error_2',SQLERRM);
        END;

        COMMIT;
    END IF;

    BEGIN
        ls_header_sw := ' SALARY DIFFERENCE program finished (TESTDB)';
        --ls_content_sw:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
        --ls_content_sw:=ls_content_sw||'<table width=570><tr><td align=center><font size="+1">SALARY DIFFERENCE Batch program started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
        ls_content_sw:='SALARY DIFFERENCE Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
        --ls_content_sw:=ls_content_sw || '</body></html>';
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');
        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header_sw, ls_content_sw,'HTML');

        --Pkg_Email.SendAutoMessages('');
        
        -- SurmaliI 22.05.18
        ls_json := '{';
        ls_json := ls_json || '"##BODY##":"' || ls_content_sw || '"';
        ls_json := ls_json || '}';
        ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header_sw, to_char(ls_json), 'default_template', pc_ref);
            
        EXCEPTION
        WHEN OTHERS THEN
            Log_At('pkg_ekstre_salary_diff_mail_error_3',SQLERRM);
    END;
Log_At('pkg_ekstre_salary warning bitti',ld_date_activ);
-------------
-------------
---------------- SALARY WARNING Program FINISHED----------------
-------------


-- B-O-M  Sevalb SDLC00008047-Calculation of K3- liquidity coefficient  07122010
---------------- K3 Program Starts Here----------------
-------------
-------------
    BEGIN
        BEGIN
            ls_header := ' K3 Batch program started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            ls_content:='K3 Batch program started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_K3_mail_error_1',SQLERRM);
        END;


    Log_At('pkg_ekstre_ld_date_K3',Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul);

       Fill_Liquidity(Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul);
        COMMIT;
     Log_At('pkg_ekstre_K3_bitti');

        BEGIN
            ls_header := ' K3 Batch Program finished succesfully (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">K3 Batch Program finished succesfully...</font></td></tr></table>';
            ls_content:='K3 Batch Program finished succesfully...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_ekstre_hakan_K3_mail_error_3',SQLERRM);
        END;

        EXCEPTION
            WHEN OTHERS THEN
            ROLLBACK;
            Log_At('pkg_ekstre_K3_Error_log','K3 Batch Program error: 1',SQLERRM);
            BEGIN
                ls_header := ' K3 Batch Program Error-1 (TESTDB)';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">K3 Batch Program got error-1. Please contact to C Bilisim...</font></td></tr></table>';
                ls_content:='K3 Batch Program got error-1. Please contact to C Bilisim...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_K3_mail_error_1',SQLERRM);
            END;
    END;
-------------
-------------
---------------- K3 Program FINISHED----------------
-------------

-- E-O-M  Sevalb SDLC00008047-Calculation of K3- liquidity coefficient  07122010

-- sevalb statement yeri degistirildi  en yukaridaydi en alta alindi nedeni ehr ay sonunda digerlerinin bitmesini engelliyor olmasidir..03032011
------------- STATEMENT STARTED-------------
-------------
-------------
    BEGIN
        BEGIN
            ls_header := ' Statement.bat started to run (TESTDB)';
            --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
            --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Statement.bat started to run. If you do not get the FINISHED mail, please check the logs...</font></td></tr></table>';
            ls_content:='Statement.bat started to run. If you do not get the FINISHED mail, please check the logs...';
            --ls_content:=ls_content || '</body></html>';
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
            --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
            --Pkg_Email.SendAutoMessages('');
            
            -- SurmaliI 22.05.18
            ls_json := '{';
            ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
            ls_json := ls_json || '}';
            ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
            
            EXCEPTION
            WHEN OTHERS THEN
                Log_At('CBS.pkg_ekstre_hakan_ekstre_mail_error_1',SQLERRM);
        END;

        pd_last_eod:=Pkg_Muhasebe.Onceki_Banka_Tarihi_Bul;
    -- pd_last_eod:=to_date('11.08.2008','dd.mm.yyyy');
        Log_At('CBS.pkg_ekstre_statement_program_log','statement program started.',pd_last_eod);

        BEGIN
        -- b-o--m sevalb tekrar calistirilmasi durumunda problem cikardigidndna eklendi . 03032011
            DELETE FROM CBS_HIZLI_EKSTRE_WORKING
            WHERE tarih = pd_last_eod;

            DELETE FROM cbs_hizli_ekstre
            WHERE eod_tarih = pd_last_eod;

            COMMIT;
        -- e-o--m sevalb tekrar calistirilmasi durumunda problem cikardigidndna eklendi . 03032011

            ln_ok := 0;
            ln_cnt := 0;
            ls_bitti := NULL;


            SELECT COUNT(*)
            INTO ln_cnt
            FROM CBS_HIZLI_EKSTRE_WORKING
            WHERE tarih = pd_last_eod;

            IF ln_cnt = 1
            THEN
                SELECT BITTI
                INTO ls_bitti
                FROM CBS_HIZLI_EKSTRE_WORKING
                WHERE tarih = pd_last_eod;

                IF ls_bitti IS NOT NULL
                THEN
                    ln_ok := 2;   -- calismis ve bitmis tekrar calisabilir
                END IF;
            ELSE
                ln_ok := 1;  -- ilk calismasi
            END IF;

            IF ln_ok > 0
            THEN
                IF ln_ok = 1
                THEN
                    INSERT INTO CBS_HIZLI_EKSTRE_WORKING
                    (TARIH, BASLADI)
                    VALUES
                    (pd_last_eod, 'E');

                    COMMIT;
                ELSE
                    UPDATE CBS_HIZLI_EKSTRE_WORKING
                    SET BITTI = NULL
                    WHERE tarih = pd_last_eod;

                    COMMIT;
                END IF;
                DELETE FROM cbs_hizli_ekstre
                WHERE eod_tarih = pd_last_eod;

                say := 0;
                say2 := 0;

                OPEN c1;
                LOOP
                    FETCH c1 INTO r1;
                    EXIT WHEN c1%NOTFOUND;
                        IF Pkg_Vadehesap_Rapor.ekstre_basilacak(r1.hesap_no,pd_last_eod) = 'E'
                        THEN
                            SELECT NVL(PERSONEL_SICIL_NO,0)
                            INTO ln_sicil
                            FROM cbs_musteri
                            WHERE musteri_no = r1.musteri_no;

                            IF ln_sicil = 0
                            THEN
                                BEGIN
                                 ls_external_acc := Pkg_Hesap.External_HesapNo_Al(r1.hesap_no) ;
                                 ls_vergi := Pkg_Vadehesap_Rapor.musteri_vergino_al_dairesiz(r1.hesap_no);
                                 ls_donem := Pkg_Vadehesap_Rapor.ekstre_bas_donem_yeni(r1.hesap_no,pd_last_eod) || ' - '  ||TO_CHAR(pd_last_eod,'DD.MM.YYYY');
                                 ln_extre_no := Pkg_Vadehesap_Rapor.ekstre_no_bul_yeni(r1.hesap_no,pd_last_eod);
                                 ln_devir_bakiye := Pkg_Vadehesap_Rapor.sf_devirbakiyebul(r1.hesap_no,REPLACE(SUBSTR(ls_donem,1,10),'.','/'));

                                 ld_bas_tarih := TO_DATE(Pkg_Vadehesap_Rapor.ekstre_bas_donem_yeni(r1.hesap_no,pd_last_eod),'dd.mm.yyyy');
                                   EXCEPTION WHEN OTHERS THEN
                                    Log_At('ekstre-hata',r1.hesap_no,SQLCODE,SQLERRM);
                                   END;
                                OPEN c2;
                                LOOP
                                    FETCH c2 INTO r2;
                                    EXIT WHEN c2%NOTFOUND;

                                    IF r2.FIS_TUR = 'G'
                                    THEN
                                        IF r2.FIS_MUHASEBELESTIGI_TARIH BETWEEN ld_bas_tarih AND pd_last_eod
                                        THEN
                                            ln_bakiye := Pkg_Hesap.HareketliBakiyeHesapla(r1.hesap_no,r2.FIS_NUMARA,r2.SATIR_NUMARA);

                                            INSERT INTO cbs_hizli_ekstre
                                            (MUSTERI_NO,FIS_NUMARA,FIS_ISLEM_NUMARA,ISIM_UNVAN,EXTERNAL_ACC,HESAP_TURU,VERGI_NO,
                                             HESAP_DOVIZ_KODU,ADRES,FIS_FIS_NO,FIS_TUR,SATIR_NUMARA,SATIR_TUR,SATIR_HESAP_BOLUM_KODU,
                                             SATIR_HESAP_NUMARA,FIS_MUHASEBELESTIGI_TARIH,SATIR_VALOR_TARIHI,SATIR_DV_TUTAR,SATIR_DOVIZ_KOD,
                                             SATIR_MUSTERI_ACIKLAMA,BOLUM_KODU,FIS_YARATILDIGI_BANKA_TARIH,BAKIYE,
                                             BOLUM_ADI,
                                             NBEQUIVALENT,
                                             CREDIT,DEBIT,VERGI_NO_DAIRESIZ,DONEM,EKSTRE_NO,PERSONEL_SICIL_NO,EOD_TARIH,DEVIR_BAKIYE)
                                            VALUES
                                            (r2.musteri_no,r2.fis_numara,r2.fis_islem_numara,trim(UPPER(r2.isim_unvan)),ls_external_acc,r2.hesap_turu,r2.vergi_no,
                                             r2.hesap_doviz_kodu,r2.adres,r2.fis_fis_no,r2.fis_tur,r2.satir_numara,r2.satir_tur,r2.satir_hesap_bolum_kodu,
                                             r1.hesap_no,r2.fis_muhasebelestigi_tarih,r2.satir_valor_tarihi,r2.satir_dv_tutar,r2.satir_doviz_kod,
                                             SUBSTR(r2.satir_musteri_aciklama,1,500),r2.bolum_kodu,r2.fis_yaratildigi_banka_tarih,ln_bakiye,
                                             Pkg_Genel.bolum_adi_al_hatasiz(r2.satir_hesap_bolum_kodu),
                                             Pkg_Report5.GetNBEquivalent(r2.SATIR_DOVIZ_KOD,r2.FIS_MUHASEBELESTIGI_TARIH,r2.SATIR_DV_TUTAR),
                                             r2.credit,r2.debit,ls_vergi,ls_donem,ln_extre_no,r2.personel_sicil_no,pd_last_eod,ln_devir_bakiye);

                                            say := say + 1;
                                            IF say = 30
                                            THEN
                                                COMMIT;
                                                say := 0;
                                                say2 := say2 + 1;
                                                Log_At('pkg_ekstre_statement_log_insert','say2',say2);
                                            END IF;
                                        END IF;
                                    END IF;
                                END LOOP;
                                CLOSE c2;
                            END IF;
                        END IF;
                END LOOP;
                CLOSE c1;
            END IF;

            say2 := say2 + 1;
            Log_At('pkg_ekstre_statement_log_insert','say2',say2);
                EXCEPTION
                WHEN OTHERS THEN

                BEGIN
                    ls_header := ' Statement.bat got error-1 (TESTDB)';
                    --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                    --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Statement.bat got error-1. Please contact to C Bilisim...</font></td></tr></table>';
                    ls_content:='Statement.bat got error-1. Please contact to C Bilisim...';
                    --ls_content:=ls_content || '</body></html>';
                    -- Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                    --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                    -- Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                    --Pkg_Email.SendAutoMessages('');
                    
                    -- SurmaliI 22.05.18
                    ls_json := '{';
                    ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                    ls_json := ls_json || '}';
                    ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                    
                    EXCEPTION
                    WHEN OTHERS THEN
                        Log_At('pkg_ekstre_hakan_ekstre_mail_error_2',SQLERRM);
                END;

                Log_At('pkg_ekstre_statement_program_log','statement program error: 1',pd_last_eod,SQLERRM);
            END;

            UPDATE CBS_HIZLI_EKSTRE_WORKING
            SET BITTI = 'E'
            WHERE tarih = pd_last_eod;

            Log_At('pkg_ekstre_statement_program_log','statement program finished succesfully',pd_last_eod);

            COMMIT;

            BEGIN
                ls_header := ' Statement.bat finished succesfully (TESTDB)';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Statement.bat finished succesfully...</font></td></tr></table>';
                ls_content:='Statement.bat finished succesfully...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_hakan_ekstre_mail_error_3',SQLERRM);
            END;
        EXCEPTION
            WHEN OTHERS THEN

            UPDATE CBS_HIZLI_EKSTRE_WORKING
            SET BITTI = 'E'
            WHERE tarih = pd_last_eod;

            BEGIN
                ls_header := ' Statement.bat got error-2 (TESTDB)';
                --ls_content:='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
                --ls_content:=ls_content||'<table width=570><tr><td align=center><font size="+1">Statement.bat got error-2. Please contact to C Bilisim...</font></td></tr></table>';
                ls_content:='Statement.bat got error-2. Please contact to C Bilisim...';
                --ls_content:=ls_content || '</body></html>';
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','artemt@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','AkmalS@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','DolonA@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dianah@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','dilmuratz@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','andreya@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','medarv@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','almasn@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Guray.YILMAZ@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','raddim.smailov@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Seval.Colak@bankpozitif.com.tr' , ls_header, ls_content,'HTML');
                --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg','Tynarbek.Arzymatov@demirbank.kg' , ls_header, ls_content,'HTML');
                --Pkg_Email.SendAutoMessages('');
                
                -- SurmaliI 22.05.18
                ls_json := '{';
                ls_json := ls_json || '"##BODY##":"' || ls_content || '"';
                ls_json := ls_json || '}';
                ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(ls_email_list, ls_header, to_char(ls_json), 'default_template', pc_ref);
                
                EXCEPTION
                WHEN OTHERS THEN
                    Log_At('pkg_ekstre_hakan_ekstre_mail_error_4',SQLERRM);
            END;

            Log_At('pkg_ekstre_statement_program_log','statement program error: 2',SQLERRM);
            COMMIT;
    END;
    
-------------
-------------
------------- STATEMENT FINISHED-------------
-------------

------------- NBKR REPORTS START ------------

   BEGIN
        pkg_soa_common.EXPORT_TO_DBF_MAIL(to_char(pkg_muhasebe.Onceki_Banka_Tarihi_Bul,'DD.MM.YYYY'));
   EXCEPTION
         WHEN OTHERS THEN
                log_at('pkg_soa_common.EXPORT_TO_DBF_MAIL', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;          
------------- NBKR REPORTS FINISHED ----------

------------- CUSTOMER NOTIFICATIONS STARTED ------------ AdiletK 09.12.2014 CQ867 Sending notifications at EOD
/*   BEGIN
        OPEN cust_list;
        FETCH cust_list INTO r_list;    
        WHILE cust_list%FOUND
        LOOP -- going through each subscribed customer and sending transactional notifications
            null;--ls_cust_result := cbs.pkg_soa_transaction.notifyCustomer(null, null, r_list.customer_no, 'E');            
        END LOOP;
        CLOSE cust_list;
        log_at('sendAds');
        -- sending marketing and advertisement notifications
   EXCEPTION
         WHEN OTHERS THEN
                log_at('pkg_ekstre.customer_notification', ls_cust_result || ' ' || ls_ads_result, sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END;          */
------------- CUSTOMER NOTIFICATIONS FINISHED ----------

END;

 PROCEDURE Hourly_Reports IS
    ls_returncode VARCHAR2(3) := '000';
    ls_dcs_time CBS_PARAMETRE.DEGER%TYPE;

    ls_eod varchar2(1) := 'H';
    ls_sod varchar2(1) := 'H';
    ls_EOD_MUHASEBE varchar2(1) := 'H';
      
    ls_time CBS_PARAMETRE.DEGER%TYPE;--CQ4768 almasn 09062015
    lc_ref CursorReferenceType;--CQ4768 almasn 09062015
  BEGIN
        
    BEGIN
  
    IF (TO_CHAR(SYSDATE, 'hh24') >= 9 AND TO_CHAR(SYSDATE, 'hh24') <= 18) THEN
        ls_returncode := PKG_INT_TRANSFER.SENDAPPROVEDGROSSREPORT(TO_CHAR(SYSDATE, 'YYYYMMDD'));
    END IF;
    
    EXCEPTION
    WHEN OTHERS THEN
        log_at('SENDAPPROVEDGROSSREPORT', SQLERRM, DBMS_UTILITY.format_error_backtrace);
    END;
    
    BEGIN

    Pkg_Parametre.deger('DCS_JOB_TIME',ls_dcs_time);

    select eod,sod ,eod_muhasebe
    into ls_eod,ls_sod ,ls_eod_muhasebe
    from cbs_system;

    if nvl(ls_eod,'H') = 'H' and nvl(ls_sod,'H') = 'H'  and nvl(ls_eod_muhasebe,'H') = 'H' and (INSTR(ls_dcs_time, to_char(sysdate, 'HH24'))>0) then
        PKG_DCS.PERFORMPAYMENTSFROMJOB();
    END IF;
    
    EXCEPTION
    WHEN OTHERS THEN
        log_at('PKG_DCS.PERFORMPAYMENTSFROMJOB', SQLERRM, DBMS_UTILITY.format_error_backtrace);
    END;
    
    BEGIN
        PKG_SOA_COMMON.START_REPORTS(null);
    EXCEPTION
    WHEN OTHERS THEN
        log_at('PKG_SOA_COMMON.START_REPORTS', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;
    
    --CQ4768 almasn 09062015 get data from web service which return card overdue list
    BEGIN
        Pkg_Parametre.deger('CARD_OVERDUE_WS_CALL_TIME',ls_time);

        if (INSTR(ls_time, to_char(sysdate, 'HH24'))>0) then
            ls_returncode := PKG_SOA_INQUIRY.getCreditCardOverdueReport(to_char(sysdate-1,'yyyymmdd'), lc_ref);
        end if;

    EXCEPTION
        WHEN OTHERS THEN
            log_at('PKG_SOA_INQUIRY.getCreditCardOverdueReport', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;
    
    --CQ5062 urmata 03122015 Country, bank limits 
    BEGIN
        PKG_SOA_COMMON.CheckCountryLimits;
    EXCEPTION
    WHEN OTHERS THEN
        log_at('PKG_SOA_COMMON.CheckCountryLimits', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;

  END;
    
END ;
/

