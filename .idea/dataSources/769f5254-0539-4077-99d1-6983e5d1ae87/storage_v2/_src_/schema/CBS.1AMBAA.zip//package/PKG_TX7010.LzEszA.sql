create PACKAGE     Pkg_Tx7010 IS
  /******************************************************************************
   Name       : Pkg_Tx7010
   Created By : Hakan SAMSA
   Purpose	  : Customer G/L Group code modification
  ******************************************************************************/
PROCEDURE Yaratma_Oncesi(pn_islem_no NUMBER) ;
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Muhasebelesme(pn_islem_no NUMBER) ;
PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) ;
PROCEDURE Hata_Kontrolleri(pn_islem_no NUMBER) ;
PROCEDURE BilgiAktar(pn_txno IN NUMBER,
  					 		 pn_musteri_no IN NUMBER,
  					 		 pn_eski_gk IN NUMBER,
  					 		 pn_yeni_gk IN NUMBER) ;
END;
/

