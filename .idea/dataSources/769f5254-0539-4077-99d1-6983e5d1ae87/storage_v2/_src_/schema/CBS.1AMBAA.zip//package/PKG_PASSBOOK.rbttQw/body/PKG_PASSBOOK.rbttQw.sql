create PACKAGE BODY     "PKG_PASSBOOK" IS

g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;
---------------------------------------------------------------------------------------------------
--
-- CBS_PASSBOOK da WVI hesapno procedurunde cagirilir
--
PROCEDURE HesapKontrol(pn_hesap_no IN VARCHAR2,
                         pn_baslangic_tarihi OUT date,
                       pn_son_fis_no OUT number,
                       pn_son_satir_no OUT number,
                       pn_passbook_no OUT number,
                       pn_kaldigi_satir_no OUT number)
IS
BEGIN
  SELECT baslangic_tarihi,son_fis_no,son_satir_no,passbook_no,kaldigi_satir_no
  INTO pn_baslangic_tarihi,pn_son_fis_no,pn_son_satir_no,pn_passbook_no,pn_kaldigi_satir_no
  FROM CBS_PASSBOOK
  WHERE hesap_no = TO_NUMBER(pn_hesap_no);
EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20100,g_uc_delimiter || '4844' ||g_ara_delimiter||pn_hesap_no||g_uc_delimiter);
END;
---------------------------------------------------------------------------------------------------
--
-- CBS_PASSBOOK reportunda AfterReport triggerinda cagirilir ve kaldigi fis no ve fis satiri update eder
-- Bunu iptal ettim, her satirda yazdigi yeri update etsin, bkz.altttaki 2 func.
FUNCTION SonSatirUpdate(pn_hesap_no IN number) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

ln_maxfisno   number ;
ln_maxsatirno number ;

ls_returncode2 VARCHAR2(3):='000';
BEGIN  SELECT  MAX(FIS_NUMARA)
  INTO ln_maxfisno
  FROM   CBS_VW_FIS_SATIR_VSZIZ
  WHERE SATIR_HESAP_NUMARA = pn_hesap_no;

  SELECT  MAX(SATIR_NUMARA)
  INTO ln_maxsatirno
  FROM   CBS_VW_FIS_SATIR_VSZIZ
  WHERE SATIR_HESAP_NUMARA = pn_hesap_no
    and FIS_NUMARA = ln_maxfisno;

  UPDATE CBS_PASSBOOK
  SET   SON_FIS_NO   = ln_maxfisno,
        SON_SATIR_NO = ln_maxsatirno
  WHERE hesap_no =  pn_hesap_no;
  RETURN ls_returncode2;
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
--
---------------------------------------------------------------------------------------------------
FUNCTION Fis_No_Update(pn_hesap_no IN number,pn_fis_no number) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
  UPDATE CBS_PASSBOOK
  SET   SON_FIS_NO   = pn_fis_no
  WHERE hesap_no =  pn_hesap_no;
  RETURN ls_returncode;
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
---------------------------------------------------------------------------------------------------
FUNCTION Satir_No_Update(pn_hesap_no IN number,pn_satir_no number) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
  UPDATE CBS_PASSBOOK
  SET SON_SATIR_NO = pn_satir_no
  WHERE hesap_no =  pn_hesap_no;
  RETURN ls_returncode;
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);
END;
---------------------------------------------------------------------------------------------------
--
-- CBS_PASSBOOK reportunda querry icinde formulada
--
FUNCTION SatirNoUpdate(pn_hesap_no IN number) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

ln_satirno number ;

BEGIN
  UPDATE CBS_PASSBOOK
  SET SATIR_NO = mod((nvl(SATIR_NO,0) + 1),47)
  WHERE hesap_no =  pn_hesap_no;
  return '000';
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

END;
---------------------------------------------------------------------------------------------------
FUNCTION KalanSatirNoUpdate(pn_hesap_no IN number) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

ln_satirno number ;

BEGIN
  UPDATE CBS_PASSBOOK
  SET KALDIGI_SATIR_NO = NVL(SATIR_NO,0),
        SATIR_NO = 0
  WHERE hesap_no =  pn_hesap_no;
  return '000';
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

END;
---------------------------------------------------------------------------------------------------
--
-- Satir numarasini alir.0 degilse baslik yazmaz
--
FUNCTION SonSatir(pn_hesap_no IN number) RETURN NUMBER IS
ls_returncode VARCHAR2(3):='000';
ls_satir NUMBER;

BEGIN
  SELECT NVL(KALDIGI_SATIR_NO,0)
  INTO ls_satir
  FROM CBS_PASSBOOK
  WHERE hesap_no =  pn_hesap_no;
  return ls_satir;
  EXCEPTION
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '270' ||  Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' ' || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getUCPOINTER);

END;
---------------------------------------------------------------------------------------------------
FUNCTION Hesap_Passbook_Tanimli(pn_hesap_no IN number) RETURN VARCHAR2 IS
    ln_cnt   number;
BEGIN
    SELECT count(*)
    INTO ln_cnt
    FROM CBS_PASSBOOK
    WHERE hesap_no =  pn_hesap_no;

    if ln_cnt = 0
    then
        return 'H';
    else
        return 'E';
    end if;
END;
---------------------------------------------------------------------------------------------------
FUNCTION Ortak_Al(pn_hesap_no IN number) RETURN VARCHAR2 IS
    ln_cnt   number;

    CURSOR c1 IS
               SELECT *
            FROM CBS_HESAP_ORTAK_BILGI
            WHERE ANA_HESAP_NO = pn_hesap_no;
    r1      c1%ROWTYPE;
    sayac    number;
    ls_str   varchar2(200);
BEGIN
    ls_str := null;
    sayac := 0;
    OPEN c1;
    LOOP
        FETCH c1 INTO  r1;
        EXIT WHEN c1%NOTFOUND;
        BEGIN
            sayac := sayac + 1 ;
            if sayac < 3
            then
                ls_str := ls_str || rtrim(ltrim(r1.ORTAK_ADI_SOYADI)) || '   ';
            end if;
        END;
    END LOOP;
    CLOSE c1;
    return ls_str;
END;
---------------------------------------------------------------------------------------------------
FUNCTION HareketliBakiyeHesapla(pn_hesap_no NUMBER,pn_fis_numara NUMBER,pn_satir_no NUMBER) RETURN NUMBER IS
   PRAGMA AUTONOMOUS_TRANSACTION;
     ln_bakiye NUMBER;
     ln_sum_hareket NUMBER;
    ls_count       VARCHAR2(1);
    ln_balance_after      NUMBER;
    --bom aisuluud cq6047
    ln_eod_amount number;
    ln_balance_after_new number;
    --eom aisuluud cq6047

    CURSOR cursor_hareket IS

        SELECT /*+ RULE */ SUM(satir_dv_tutar)
          FROM cbs_vw_fis_satir_vsziz
         WHERE fis_tur = 'G' AND
               satir_HESAP_NUMARA = TO_CHAR(pn_hesap_no) AND
               FIS_NUMARA >= pn_fis_numara AND
               FIS_MUHASEBELESTIGI_TARIH IS NOT NULL AND
               satir_NUMARA > DECODE(FIS_NUMARA, pn_fis_numara, pn_satir_no,-1);
 BEGIN
     SELECT balance_flag,balance_after
    INTO ls_count,ln_balance_after
     FROM CBS_SATIR
    WHERE fis_numara = pn_fis_numara
    AND numara=pn_satir_no;

    IF ls_count='0' THEN
        SELECT bakiye
        INTO ln_bakiye
        FROM CBS_HESAP_BAKIYE
        WHERE hesap_no=pn_hesap_no;

        OPEN cursor_hareket;
        FETCH cursor_hareket INTO ln_sum_hareket;
        IF cursor_hareket%NOTFOUND THEN
           ln_sum_hareket:=0;
        END IF;
        CLOSE cursor_hareket;
        
        --bom aisuluud cq6047
            
            SELECT sum(decode(s.tur,'A', nvl(dv_tutar,0), -1*nvl(dv_tutar,0)))
                into ln_eod_amount
                FROM CBS_SATIR s, CBS_EOD_FIS_NO ef
               WHERE s.fis_numara = ef.fis_numara
                 AND ef.durum = 'A'
                 AND s.hesap_numara = TO_CHAR(pn_hesap_no)
                 AND s.hesap_tur_kodu <> 'DK';
                 
            ln_balance_after_new := (ln_bakiye + nvl(ln_eod_amount,0)) - NVL(ln_sum_hareket,0);     
        
        --eom aisuluud cq6047

        UPDATE CBS_SATIR
          SET balance_flag = '1',
                --balance_after = ln_bakiye-NVL(ln_sum_hareket,0)--aisuluud cq6047 commented out
              balance_after = ln_balance_after_new--aisuluud cq6047
        WHERE fis_numara = pn_fis_numara
              AND numara=pn_satir_no;

        /*update cbs_satir
          set balance_flag= '0'
         where fis_numara > pn_fis_numara
         and hesap_numara in (select hesap_numara from cbs_satir
         where pn_fis_numara=fis_numara
         and hesap_tur_kodu in ('VS','VD','KR'));*/

          COMMIT;

         --RETURN (ln_bakiye-NVL(ln_sum_hareket,0));--aisuluud cq6047 commented out
         RETURN ln_balance_after_new;-- aisuluud cq6047
    END IF;
         RETURN ln_balance_after;
         
 END;
---------------------------------------------------------------------------------------------------
END;
/

