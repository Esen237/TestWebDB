create PACKAGE     Pkg_Tx2059 IS

procedure faiz_hesapla(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );
procedure geri_odeme(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 );

end pkg_tx2059;

/

