create PACKAGE     PKG_INT_TRANSLATION_INQ IS 

TYPE CursorReferenceType IS REF CURSOR;  

FUNCTION GetTranslate(ps_lang varchar2,  
                      ps_label_cd varchar2,
                      ps_label_type varchar2) RETURN varchar2;
                           
FUNCTION GetErrorCode(ps_lang varchar2,  
                      ps_label_cd varchar2,
                      ps_label_type varchar2,
                      pc_ref OUT CursorReferenceType) RETURN varchar2;

END pkg_int_translation_inq;
/

