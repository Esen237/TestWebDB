create PACKAGE     PKG_TX8870 IS

/******************************************************************************
Name       : PKG_TX8870
Created By :Meder Toitonov
Date          : 27/11/2015
Purpose      : EXD files processing
******************************************************************************/
Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir
Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir
Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir
Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir
Procedure Muhasebelesme(pn_islem_no number ,pn_dosya_no number ,ps_file_type varchar2,ps_err out number,ps_error_mesaj out varchar2,pn_sira_no number default null);              -- Islemin muhasebelesmesi icin cagrilir
Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
PROCEDURE InsertElcardEXDLog(pn_tx_no    IN NUMBER,
                              pn_sira_no    IN NUMBER,
                              ps_account_number IN VARCHAR2,
                              pn_amount    IN NUMBER,
                              pn_is_proc    IN NUMBER
                              );
PROCEDURE UpdateElcardWSLog(pn_tx_no    IN NUMBER,
                              pn_sira_no    IN NUMBER,
                              ps_account_number IN VARCHAR2,
                              pn_amount    IN NUMBER,
                              pn_is_proc    IN NUMBER
                              );                              
PROCEDURE processElcardEXDQueue;
END;

/

