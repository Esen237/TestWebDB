create PACKAGE BODY Pkg_Menkul_Rapor IS
  FUNCTION   islem_tipi_adi_al(pn_kod NUMBER) RETURN VARCHAR2
   IS
   ls_stok_kaynagi   VARCHAR2(2000);
  BEGIN

	SELECT DECODE(pn_kod,6011,'Banka Kesin Al??',6016,'Banka Kesin Al??- G?ncelleme',6060,'M??teri Kesin Al??',
		   		  6062,'M??teri Kesin Sat??',6030,'Repo Sat??',6031,'Repo Sat??-G?ncelleme',6040,'M??teri Ters Repo',
				  6041,'M??teri Ters Repo - G?ncelleme',6044,'Banka Ters Repo',6045,'Banka Ters Repo - G?ncelleme',
				  6020,'Banka Kesin Sat??',6021,'Banka Kesin Sat?? - G?ncelleme',6024,'Emanet Giri?',6025,'Emanet Giri?-G?ncelleme',
				  6026,'Emanet ??k??',6052,'Bloke Koyma',6053,'Bloke Koyma - G?ncelleme',6054,'Bloke Kald?rma',6055,'Bloke Kald?rma-G?ncelleme',
				  6032,'Repo D?n??',6042,'Ters Repo D?n??',6046,'Banka Ters Repo D?n??',' ')
	INTO  ls_stok_kaynagi
	FROM  dual;

	RETURN ls_stok_kaynagi ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4447' || Pkg_Hata.getUCPOINTER);
  END;
---------------------------

  FUNCTION stok_kartina_giris_tarihi(pn_stok NUMBER) RETURN DATE
   IS
   ld_tarih   DATE;
  BEGIN

	SELECT islem_tarihi
	INTO   ld_tarih
	FROM   CBS_MENKUL_STOK_HAREKET
	WHERE  sira_no = (SELECT MIN(sira_no) FROM CBS_MENKUL_STOK_HAREKET WHERE Stok_no = pn_stok)
	AND    stok_no = pn_stok;

	RETURN ld_tarih ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4448' || Pkg_Hata.getUCPOINTER);
  END;
------------------

  FUNCTION Kupon_odeme_donemi_aciklamasi(pn_donem NUMBER) RETURN VARCHAR2
   IS
   ls_aciklama   VARCHAR2(10);
  BEGIN

	SELECT DECODE(pn_donem,1,'1-Ay',2,'3-Ay',3,'6-Ay',4,'12-ay',5,'91-G?n',6,'182-G?n',' ')
	INTO  ls_aciklama
	FROM  dual;

	RETURN ls_aciklama ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4467' || Pkg_Hata.getUCPOINTER);
  END;
------------------

  FUNCTION Gun_Hesaplama_Bazi_Aciklamasi(pn_gun NUMBER) RETURN VARCHAR2
   IS
   ls_aciklama   VARCHAR2(20);
  BEGIN

	SELECT DECODE(pn_gun,1,'Ger?ek-365',2,'Ger?ek/Ger?ek',3,'Ger?ek/260',4,'30/360',' ')
	INTO  ls_aciklama
	FROM  dual;

	RETURN ls_aciklama ;

  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4468' || Pkg_Hata.getUCPOINTER);
  END;

FUNCTION  urun_grubu_nakdi_mi(pn_urun_grubu CBS_URUN_GRUBU.numara%TYPE) RETURN VARCHAR2
   IS
    ls_nakdi 	 CBS_URUN_GRUBU.NAKDI_MI%TYPE;
  BEGIN
    SELECT nakdi_mi
	INTO   ls_nakdi
	FROM   CBS_URUN_GRUBU
	WHERE  numara = pn_urun_grubu ;

	RETURN ls_nakdi ;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN RETURN ' ';
  END;

END Pkg_Menkul_Rapor ;
/

