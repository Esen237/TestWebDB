create PACKAGE BODY PKG_TX1105 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;
  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_adet number := 0;
  ln_cek_no 	 	  				 cbs_cek.cek_no%type;
  ln_cek_no_2 	 	  				 cbs_cek.cek_no%type;
  ln_cek_no_sub 	  				 cbs_cek.cek_no%type;
  ln_cek_no_except          		 cbs_cek.cek_no%type;

  ls_odeme_yasak_neden_kodu 		 cbs_cek.odeme_yasak_neden_kodu%type ;
  ls_durum_kodu						 cbs_cek.durum_kodu%type;

    cursor cur_cek_islem is
     select cek_no ,odeme_yasak_neden_kodu ,decode(nvl(cek_no_2,0),0,cek_no,cek_no_2)
 	 from cbs_cek_islem
	 where tx_no = pn_islem_no;

	cursor cur_cek is
	select cek_no,durum_kodu
	from   cbs_cek
	where cek_no between ln_cek_no and nvl(ln_cek_no_2,ln_cek_no)
	for update of durum_kodu;

  Begin

/* islem bilgisi guncellenir */
    update cbs_cek_islem
	set duzeltme_tarihi = pkg_muhasebe.banka_tarihi_bul ,
	    durum_kodu = 'A'
	where tx_no = pn_islem_no ;

/* ilgili cek numarasinin durum kodu d?zeltme  'D' olarak guncellenir. */
 if cur_cek_islem%isopen then
	   close cur_cek_islem;
 end if;

 open cur_cek_islem ;
  loop
  	  fetch cur_cek_islem into ln_cek_no , ls_odeme_yasak_neden_kodu ,ln_cek_no_2 ;
    	exit when cur_cek_islem%notfound;

		ln_cek_no_except := Pkg_cek.Sf_Cek_Aralik_OYasIptal_Uygun(ln_cek_no ,ln_cek_no_2);

	   if cur_cek%isopen then
	   	 close cur_cek;
	    end if;

		open cur_cek ;
		  loop
		   fetch cur_cek into ln_cek_no_sub,ls_durum_kodu ;
		      exit when cur_cek%notfound;

			 if ls_durum_kodu = 'KY' then
			    ls_durum_kodu := 'K' ;
			 elsif pkg_cek.sf_cek_onceden_blokelimiydi(ln_cek_no_sub)= 'E' then
			    ls_durum_kodu := 'B' ;
			 else
			  	ls_durum_kodu := 'A' ;
			 end if;

		     update cbs_cek
			 set durum_kodu = ls_durum_kodu ,
 			     odeme_yasak_neden_kodu = null,
			 	 duzeltme_tarihi = pkg_muhasebe.banka_tarihi_bul
			 where current of cur_cek;

		  end loop;
	  close cur_cek;
  end loop;
  	 close 	 cur_cek_islem ;
  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '149' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_karne_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;
  End;
END;
/

