create PACKAGE BODY     PKG_INT_CARD_INQ IS

FUNCTION GetDebitCardAccounts(ps_pseudopan varchar2,
                              ps_customer_number varchar2,
                              pc_ref OUT CursorReferenceType) return varchar2
IS
BEGIN
    
    open pc_ref for
        select  pkg_int.getaccounttypename(modul_tur_kod) modul_tur_kod,
                musteri_no,
                isim_unvan,
                acilis_tarihi,
                sube_kodu||' '|| pkg_genel.bolum_adi_al(sube_kodu) sube,
                hesap_no,
                doviz_kodu,
               (select card_account_type from cbs_debit_card_account where account_no = hesap_no and card_id_no = ps_pseudopan) account_type,
                nvl(bakiye,0) balance,
                nvl(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),0) available_balance,
                1 siralama, to_char(vade_tarihi ,'YYYYMMDD') vade_tarihi, kisa_isim, round(birikmis_faiz_neg,2),
                external_hesap_no,
                urun_sinif_kod
        from cbs_vw_hesap_izleme a
        where musteri_no = to_number(ps_customer_number) 
          and durum_kodu = 'A' and modul_tur_kod= 'CURRENT'
          and urun_tur_kod in ('CURRENT','DEMAND DEP','COLLATERAL') 
          and urun_sinif_kod not in ('ELCARD NON INT.BR-LC', 'OVERBALANCE-LC')
          and hesap_no in (select account_no from cbs_debit_card_account where card_id_no = ps_pseudopan)
        order by siralama , hesap_no, sube,doviz_kodu ;
    
    return '000';
    
EXCEPTION 
    when others then 
       raise;
END;
------------------------------------------------------------------------------------------------------------------------------
FUNCTION GetDebitCardAccountByIban(ps_iban in varchar2,
                              	   pc_ref OUT CursorReferenceType) return varchar2
IS
BEGIN
    
    open pc_ref for
        select  pkg_int.getaccounttypename(modul_tur_kod) modul_tur_kod,
                musteri_no,
                isim_unvan,
                acilis_tarihi,
                sube_kodu||' '|| pkg_genel.bolum_adi_al(sube_kodu) sube,
                hesap_no,
                doviz_kodu,
                nvl(bakiye,0) balance,
                nvl(pkg_hesap.kullanilabilir_bakiye_al(hesap_no),0) available_balance,
                1 siralama, to_char(vade_tarihi ,'YYYYMMDD') vade_tarihi, kisa_isim, round(birikmis_faiz_neg,2),
                external_hesap_no,
                urun_sinif_kod
        from cbs_vw_hesap_izleme a
        where durum_kodu = 'A' and modul_tur_kod= 'CURRENT'
          and urun_tur_kod in ('CURRENT','DEMAND DEP','COLLATERAL') 
          and urun_sinif_kod not in ('ELCARD NON INT.BR-LC', 'OVERBALANCE-LC')
          and external_hesap_no = ps_iban 
        order by siralama , hesap_no, sube,doviz_kodu;
        
    return '000';
    
EXCEPTION 
    when others then 
       raise;
END;
------------------------------------------------------------------------------------------------------------------------------

FUNCTION GetDebitCardAutoconversionStatus(ps_customer_number in varchar2,
                                          pc_ref OUT CursorReferenceType) return varchar2
IS
ls_customer_count number;
nocustomerfound exception;
BEGIN
 
   select count(*) into ls_customer_count from cbs_musteri where musteri_no = ps_customer_number;
   
    if ls_customer_count != 1 then
        raise nocustomerfound;
    end if;
    
    open pc_ref for
        select fx_convert from cbs_musteri where musteri_no = ps_customer_number;
    
    return '000';
    
EXCEPTION 
    when nocustomerfound then
        return '608';
    when others then   
       raise;
END;
END;
/

