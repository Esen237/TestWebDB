create PACKAGE Pkg_Tx6111 IS

/******************************************************************************
   Name       : PKG_TX6111
   Created By : G?lnihal Cengiz
   Date    	  : 2/06/2004
   Purpose	  : ?ubeler Cari Faiz Tahakkuku
******************************************************************************/

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER) ;

END;


/

