create PACKAGE Pkg_Ithalat IS
	--------------
	PROCEDURE referans_alim_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2);
	---------------------------------------
    PROCEDURE provizyon_kopyala(pn_islem NUMBER, ps_ref VARCHAR2, pn_provizyon_no NUMBER);
	---------------------------------------
	PROCEDURE akreditif_acilis_bilgi_al(ps_referans VARCHAR2, pn_provizyon NUMBER,
	                                    pn_ithalatci OUT NUMBER, ps_doviz OUT VARCHAR2,
										pn_dosya_tutari OUT NUMBER, pn_sight_tutar OUT NUMBER,
										pn_vadeli_tutar OUT NUMBER, pn_kabul_kredili_tutar OUT NUMBER,
										pn_pesin_tutar OUT NUMBER, ps_ulke_kodu OUT VARCHAR2,
										pd_yukleme_vadesi OUT DATE, pd_akreditif_vadesi OUT DATE,
										ps_mal_cinsi OUT VARCHAR2, ps_teyit_kodu OUT VARCHAR2,
										ps_akreditifin_sekli OUT VARCHAR2, psihracatci_firma_unvani OUT VARCHAR2,
										ps_ihrfirma_adr1 OUT VARCHAR2, ps_ihrfirma_adr2 OUT VARCHAR2,
										ps_ihrfirma_adr3 OUT VARCHAR2, ps_ihrfirma_adr4 OUT VARCHAR2,
										pn_muhabir_banka OUT NUMBER, pn_rambursman OUT NUMBER,
										ps_urun_turu OUT VARCHAR2, ps_urun_sinif OUT VARCHAR2,
										ps_bolum_kodu OUT VARCHAR2);
	---------------------------------------
	FUNCTION dv_tutar_hesapla(pn_tutar NUMBER, ps_doviz VARCHAR2) RETURN NUMBER;
	---------------------------------------
	FUNCTION masraf_kontrol_yap(ps_odeyecek VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION masraf_odeyecek_kontrol(pn_islem_no NUMBER) RETURN VARCHAR2;
	---------------------------------------
	PROCEDURE akreditif_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2);
	---------------------------------------
	PROCEDURE  BakiyeGuncelle(pn_islem_no NUMBER, ps_tur VARCHAR2,ps_islem_tur VARCHAR2,ps_referans VARCHAR2,pn_vesaikno NUMBER,pn_tutar NUMBER);
	---------------------------------------
	PROCEDURE  DurumGuncelle(ps_islem_tur VARCHAR2,ps_referans VARCHAR2,pn_vesaikno NUMBER,ps_durum VARCHAR2);
	---------------------------------------
	PROCEDURE masraf_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_vesaikno NUMBER DEFAULT 0);
	---------------------------------------
	PROCEDURE IthalatDosyaBilgiAktar(pn_txno NUMBER,ps_refno VARCHAR2);
	---------------------------------------
	FUNCTION TransferToplami(ps_referans VARCHAR2, pn_vesaikno NUMBER DEFAULT 0) RETURN NUMBER;
	---------------------------------------
	FUNCTION pt_kullanilan_bakiye(ps_referans VARCHAR2, pn_odeme_no NUMBER) RETURN NUMBER;
	---------------------------------------
	---------------------------------------
	FUNCTION ith_akr_acilis_tarihi_al(ps_ref VARCHAR2) RETURN DATE;
	---------------------------------------
	PROCEDURE ith_vesaik_tutar_uygun(ps_referans VARCHAR2, pn_tutar NUMBER,  ps_hata OUT VARCHAR2);
	---------------------------------------
	PROCEDURE akreditif_bilgi_al (
      pn_referans VARCHAR2, pn_ith_musteri OUT VARCHAR2, ps_display_ith_musteri OUT VARCHAR2,
      pn_akr_tutar OUT NUMBER, ps_akr_doviz OUT VARCHAR2, ps_urun_tur OUT VARCHAR2,
	  ps_urun_sinif OUT VARCHAR2, ps_ihracat_ulke OUT VARCHAR2, ps_teyit_kodu OUT VARCHAR2);
	---------------------------------------
    FUNCTION pesin_transfer_tarih_al(ps_referans VARCHAR2, pn_pes_trans_no NUMBER) RETURN DATE;
	---------------------------------------
	FUNCTION pt_kalan_bakiye(ps_referans VARCHAR2, pn_odeme_no NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION vs_pesin_transfer_tutar(ps_referans VARCHAR2, pn_vesaik_no NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION ith_akreditif_bakiye_al(ps_referans VARCHAR2) RETURN NUMBER;
	---------------------------------------
	PROCEDURE vesaik_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER);
	---------------------------------------
	FUNCTION akreditif_yukleme_toplam_al(ps_referans VARCHAR2) RETURN NUMBER;
	---------------------------------------
	FUNCTION akreditif_tutar_al(ps_referans VARCHAR2) RETURN NUMBER;
	---------------------------------------
	FUNCTION kismi_yukleme_al(ps_referans VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION akr_urun_turu_al(ps_ref VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION akr_urun_sinif_al(ps_ref VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	PROCEDURE vs_pesin_transfer_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER);
	---------------------------------------
	PROCEDURE vs_odeme_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER);
	---------------------------------------
	PROCEDURE ithalatci_musteri_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pn_ith_musteri OUT NUMBER);
	---------------------------------------
	PROCEDURE dosya_doviz_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_doviz OUT VARCHAR2);
	---------------------------------------
	PROCEDURE dosya_teslim_sekli_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_teslim_sekli OUT VARCHAR2 );
	---------------------------------------
	PROCEDURE dosya_rambursman_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_rambursman OUT VARCHAR2 );
	---------------------------------------
    PROCEDURE odeme_non_db_al(ps_ref VARCHAR2, pn_vesaik NUMBER,
	                          pn_bakiye OUT NUMBER, pn_dosya_tutar OUT NUMBER,
							  ps_urun_tur OUT VARCHAR2, ps_urun_sinif OUT VARCHAR2,
							  ps_ithalat_tipi OUT VARCHAR2);
	---------------------------------------
	PROCEDURE odeme_vade_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pd_valor OUT DATE);
	---------------------------------------
	PROCEDURE pt_tutar_uygun(ps_referans VARCHAR2, pn_tutar NUMBER);
	---------------------------------------
	FUNCTION dosya_bakiyesi(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION ithalat_tipi(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN VARCHAR2;
	---------------------------------------
	PROCEDURE ihracatci_masraflar_toplami_al(pn_islem_no NUMBER, pn_ihr_masraflar OUT NUMBER);
	---------------------------------------
	PROCEDURE IthalatPoliceBilgiAktar(pn_txno NUMBER,ps_refno VARCHAR2,pn_police_no NUMBER);
	---------------------------------------
	FUNCTION kredi_teklif_satir_no(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION dosya_urun_turu_al(ps_ref VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION dosya_tutar(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION Taahhut_Kapama_Toplami(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION Terkin_Toplami(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION dosya_urun_sinif(ps_ref VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION teyit_kodu_al(ps_ref VARCHAR2) RETURN VARCHAR2;
	---------------------------------------
	FUNCTION ithalatci_musteri_al(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
	---------------------------------------
	FUNCTION police_vade_al(ps_ref VARCHAR2, pn_police_no NUMBER) RETURN DATE;
	---------------------------------------
	PROCEDURE odeme_vade_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pn_odeme_no NUMBER, pd_valor OUT DATE);
    ---------------------------------------
FUNCTION  sf_modul_tur_kodu_al(ps_modul_tur_kod CBS_URUN_TUR.MODUL_TUR_KOD%TYPE) RETURN VARCHAR2 ;
FUNCTION Modul_Tur_Import RETURN VARCHAR2 ;
FUNCTION  sf_musteri_tipi_al(ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2 ;
FUNCTION  sf_durum_kodu_al(ps_durum_kodu CBS_MUSTERI.durum_kodu%TYPE) RETURN VARCHAR2 ;
FUNCTION Tanim_Tipi RETURN VARCHAR2 ;
FUNCTION Durum_Kodu RETURN VARCHAR2 ;
FUNCTION Import_Loan_Urun_Tur RETURN VARCHAR2 ;
FUNCTION akreditif_urun_sinif_al(ps_modul_tur VARCHAR2,
 		  						  ps_urun_tur  VARCHAR2,
								  ps_covered   VARCHAR2,
								  ps_confirmed VARCHAR2	,
								  ps_lc_fc     VARCHAR2
 		  						  ) RETURN VARCHAR2 ;
FUNCTION police_urun_uygunmu( ps_urun_tur VARCHAR2,ps_urun_sinif VARCHAR2) RETURN VARCHAR2 ;
FUNCTION musteri_tip_uygunmu( ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2 ;
FUNCTION police_vesaik_urun_uygunmu( ps_urun_tur VARCHAR2,ps_urun_sinif VARCHAR2) RETURN VARCHAR2 ;
FUNCTION loan_urun_tur_uygunmu(ps_urun_tur_kod CBS_URUN_SINIF.URUN_TUR_KOD%TYPE) RETURN VARCHAR2 ;
FUNCTION loan_urun_tur RETURN VARCHAR2 ;
FUNCTION urun_akreditifmi(ps_urun_tur_kod CBS_URUN_SINIF.URUN_TUR_KOD%TYPE) RETURN VARCHAR2 ;
PROCEDURE vesaik_teslim_guncelle(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_teslim VARCHAR2, pd_teslim DATE, pn_tx_no NUMBER);
PROCEDURE vesaik_teslim_guncelle_geri_al(pn_tx_no NUMBER);
FUNCTION vesaik_cikis_urun_uygun(ps_modul VARCHAR2, ps_urun VARCHAR2) RETURN NUMBER;
FUNCTION vesaik_teslim_referans_uygun(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER;
PROCEDURE vesaik_cikis_bilgileri(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_cikis OUT VARCHAR2, pd_cikis OUT DATE) ;
---------------------------------------------------------------------------------------------------------
FUNCTION masraf_kontrol_yap_nonakr(ps_odeyecek VARCHAR2) RETURN VARCHAR2;
END;

/

