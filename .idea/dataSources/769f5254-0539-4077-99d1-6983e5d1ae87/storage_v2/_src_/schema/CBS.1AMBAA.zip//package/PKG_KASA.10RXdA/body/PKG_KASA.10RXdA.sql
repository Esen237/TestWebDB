create PACKAGE BODY Pkg_Kasa IS

 Function  sf_yeni_kasakodu_Al(ps_branch varchar2 ) return  varchar2
 is
  ls_kod varchar2(10);
 begin


   ls_kod := ps_branch ||lpad( pkg_genel.genel_kod_al( 'KASA_KODU'||ps_branch),'5','0') ;
   return 	ls_kod;

 exception when others then return null;
 end;

 Function kasa_modul_tur_kod return varchar2
 is
 Begin
 	  return 'CURR.OPS.';
 End;

 Function kasa_urun_tur_kod return varchar2
 is
 Begin
 	  return 'CASH';
 End;
 Function kasa_urun_sinif_kod return varchar2
  is
 Begin
 	  return 'GENERAL';
 End;

 Function kasa_baglimi(ps_kasa_kodu varchar2) return varchar2
 is
  ls_mevcut varchar2(1) := 'H';
  cursor cur_kasa is
	  select 'E' mevcut
	  from cbs_kasa_kullanici_tanim
	  where kasa_kodu = ps_kasa_kodu
	  	and sube_kodu = pkg_baglam.bolum_kodu
		and durum_kodu = 'ACIK';
 Begin
   open cur_kasa;
    fetch cur_kasa into ls_mevcut;
   close cur_kasa;
   return ls_mevcut;
  Exception
    When others then return ls_mevcut;
 End;


 Function kullanici_kasaya_baglimi(ps_kullanici_kodu varchar2) return varchar2
 is
  ls_mevcut varchar2(1) := 'H';
  cursor cur_kasa is
	  select 'E' mevcut
	  from cbs_kasa_kullanici_tanim
	  where kullanici_kodu = ps_kullanici_kodu
	  		and durum_kodu = 'ACIK';
 Begin
   open cur_kasa;
    fetch cur_kasa into ls_mevcut;

   return ls_mevcut;
  Exception
    When others then return ls_mevcut;
 End;

 Procedure kasa_kodu_al(ps_sube varchar2,ps_kullanici_kodu varchar2, ps_kasa_kodu out varchar2,pn_tanim_no out number)
 is
 Begin
 /* kullaniciya bagli kasa bulunamazsa hata raise edilir.giris engellenir*/
 	  select kasa_kodu ,tanim_no
	  into   ps_kasa_kodu,pn_tanim_no
	  from cbs_kasa_kullanici_tanim
	  where kullanici_kodu = ps_kullanici_kodu and
	  		sube_kodu  = ps_sube and
	  		durum_kodu = 'ACIK';
	if  ps_kasa_kodu is null then
	   raise no_data_found ;
	 end if;

   Exception
     when no_data_found then
	     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '750' || pkg_hata.getUCPOINTER);
 End;

 Function kupur_kod_adi_al(pn_kupur_kodu number,ps_doviz varchar2) return varchar2
 is
  ls_aciklama cbs_kupur_kodlari.aciklama%type;
 Begin
 	  select aciklama
	  into ls_aciklama
	  from cbs_kasa_kupur_kodlari
	  where KUPUR_KODU =  pn_kupur_kodu and
	  		doviz_kodu =ps_doviz ;

	  return ls_aciklama;
 End;

Procedure kasa_sifir_bakiyeli_yarat(ps_kasa_kodu varchar2, ps_sube_kodu varchar2 ,ps_doviz_kodu varchar2 default null)
  is
  ls_doviz varchar2(3);
  cursor cur_doviz is
	 select doviz_kodu
	 from cbs_doviz_kodlari
	 where doviz_kodu = nvl(ps_doviz_kodu,doviz_kodu);

  cursor cur_kasa_kupur is
   select kupur_kodu
   from cbs_kasa_kupur_kodlari
   where doviz_kodu = ls_doviz and
   		 GECERLI_MI = 'E';

	ln_mevcut number := 0;
	ls_sonuc varchar2(1);

  Begin

  	   select count(*)
	   into ln_mevcut
	   from  cbs_kasa_bakiye
	   where kasa_kodu = ps_kasa_kodu  and
	   		 sube_kodu =ps_sube_kodu AND
			 doviz_kodu = nvl(ps_doviz_kodu,doviz_kodu);

	   if nvl(ln_mevcut,0) = 0 then
	    if ps_doviz_kodu is not null then
		 /*cbs_doviz_kodlari triggerinda mutate olmamasi icin eklendi*/

	   	   insert into cbs_kasa_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, bakiye)
			   values ( ps_kasa_kodu, ps_sube_kodu, ps_doviz_kodu, pkg_muhasebe.banka_tarihi_bul, 0);

		    for c_kasa_kupur in cur_kasa_kupur loop
		   	   insert into cbs_kasa_kupur_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, kupur_kodu,kupur_adedi,kupur_bakiye)
				values ( ps_kasa_kodu, ps_sube_kodu,ps_doviz_kodu, pkg_muhasebe.banka_tarihi_bul,c_kasa_kupur.kupur_kodu, 0,0);
			end loop;
		 else

    	  for c_doviz in cur_doviz loop

		   	   insert into cbs_kasa_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, bakiye)
			   values ( ps_kasa_kodu, ps_sube_kodu, c_doviz.doviz_kodu, pkg_muhasebe.banka_tarihi_bul, 0);

			   ls_doviz := c_doviz.doviz_kodu;
			    for c_kasa_kupur in cur_kasa_kupur loop
				   ln_mevcut := 0;
				   select count(*)
				   into ln_mevcut
				   from  cbs_kasa_kupur_bakiye
				   where kasa_kodu = ps_kasa_kodu  and
				   		 sube_kodu =ps_sube_kodu AND
						 doviz_kodu = ls_doviz and
						 kupur_kodu = c_kasa_kupur.kupur_kodu ;
				  if ln_mevcut = 0 then
				   	   insert into cbs_kasa_kupur_bakiye(kasa_kodu, sube_kodu, doviz_kodu, banka_tarihi, kupur_kodu,kupur_adedi,kupur_bakiye)
					   values ( ps_kasa_kodu, ps_sube_kodu, c_doviz.doviz_kodu, pkg_muhasebe.banka_tarihi_bul,c_kasa_kupur.kupur_kodu, 0,0);

				  end if;
			   end loop;
		   end loop;
		 end if;
	  end if;

  End;
  /*****************************************************************************************************************/
 /*  Function kupur_kontrolu_yapilsin, kupur kontrolu system ve islem kod seviyesindedir.
 /*  E :Esit																			     							*/
 /*  H :Yapmas?n
 /*  B :B?y?k esit
 /****************************************************************************************************************/

 Function kupur_kontrolu_yapilsin(pn_islem_kod number default null) return varchar2
 is
  ls_kupur_kontrolu varchar2(1) := 'H';

 Begin
 	  select nvl(kupur_kontrolu,'H')
	  into ls_kupur_kontrolu
	  from cbs_system;

	  if ls_kupur_kontrolu 	<> 'H' then
		  if pn_islem_kod is not null then
		  	 select kupur_kontrolu
			 into ls_kupur_kontrolu
			 from cbs_islem_tanim
			 where kod = pn_islem_kod ;
		  end if;
	  end if;

	  return ls_kupur_kontrolu;
 End;

 Function kullanici_kasa_kodu(ps_sube varchar2,ps_kullanici_kodu varchar2) return varchar2
 is
  ls_kasa_kodu cbs_kasa_kodlari.KASA_KODU%type;
  ln_tanim_no number ;
 Begin
 	  kasa_kodu_al(ps_sube ,ps_kullanici_kodu, ls_kasa_kodu,ln_tanim_no );

	  return  ls_kasa_kodu;
 End;

 Function ana_kasa_kodu return varchar2
 is
 Begin
 		  return '01000000';
 End;

  Procedure ana_kasa_yarat( ps_sube_kodu varchar2)
  is
  ln_var number :=0 ;
 Begin
	  select count(*)
	  into ln_var
	  from cbs_kasa_kodlari
	  WHERE kasa_kodu in ana_kasa_kodu and
	  		sube_kodu = ps_sube_kodu;

	  if ln_var = 0 then
		  insert into cbs_kasa_kodlari(  kasa_kodu,aciklama, sira_no,
		  		 	  					 yaratan_kullanici_kodu, sube_kodu)
		  values ( ana_kasa_kodu ,'MAIN CASH',0,'CBS',ps_sube_kodu );

		  pkg_kasa.kasa_sifir_bakiyeli_yarat(ana_kasa_kodu ,ps_sube_kodu );
	 end if;

	 --sevalb exchange kasa yaratilmadigindan kapatildi 110407
	 /* select count(*)
	  into ln_var
	  from cbs_kasa_kodlari
	  WHERE kasa_kodu in exchange_kasa_kodu and
	  		sube_kodu = ps_sube_kodu;

 	  if ln_var = 0 then
		  insert into cbs_kasa_kodlari(  kasa_kodu,aciklama, sira_no,
		  		 	  					 yaratan_kullanici_kodu, sube_kodu)
		  values ( exchange_kasa_kodu ,'EXCHANGE CASH',0,'CBS',ps_sube_kodu );

		  pkg_kasa.kasa_sifir_bakiyeli_yarat(exchange_kasa_kodu ,ps_sube_kodu );
	 end if;
	 */
 -- Exception When Others then return 'H';
 End;

 Procedure kasa_isleme_at (pn_tx_no 		  number,
 		   				   pn_islem_kod	  cbs_islem.islem_kod%type,
						   ps_kasa_kodu       cbs_kasa_kodlari.kasa_kodu%type,
						   ps_sube_kodu		  varchar2,
						   ps_kullanici_kodu  varchar2,
						   pn_tanim_no number,
						   ps_urun_sinif_kod varchar2 default pkg_kasa.kasa_urun_sinif_kod,
						   ps_origin_islem_kod varchar2 default null,
						   pn_tutar1 number default null,
  						   ps_doviz1 varchar2 default null,
  						   ps_islem_1 varchar2 default null,
  						   pn_tutar2 number default null,
  						   ps_doviz2 varchar2 default null,
  						   ps_islem_2 varchar2	default null
  )
 is
 	ls_retval varchar2(200);
	ls_pkod	 varchar2(200);
	ls_kasa_kodu varchar2(200);
	ls_sube_kodu varchar2(200);
	ln_mevcut number := 0;
	kayit_yok exception;
 Begin

    ls_retval := pkg_parametre.varchar_al ( pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod,NULL,'ANAKASAAL');
	  if ps_urun_sinif_kod =  ls_RetVal  then
	  /* ANA KASA ALINAN ISE ana kasa doviz kodu dolu olan bakiyeleri */
	    ls_kasa_kodu := pkg_kasa.ana_kasa_kodu ;
		ls_sube_kodu := ps_sube_kodu;
		else
	    ls_kasa_kodu := ps_kasa_kodu;
		ls_sube_kodu := ps_sube_kodu;
	  end if;

	    select count(*)
		into ln_mevcut
		from cbs_kasa_bakiye
		where  kasa_kodu = ls_kasa_kodu and
			   sube_kodu = ls_sube_kodu and
			   banka_tarihi = pkg_muhasebe.banka_tarihi_bul   and
 		       nvl(bakiye,0) <> 0 ;

		if nvl(ln_mevcut,0) = 0 and pn_islem_kod <> 1603  then --kasa kapama disinda
		   raise kayit_yok;
		end if;

		ln_mevcut := 0;
		select count(*)
		into ln_mevcut
		from cbs_kasa_islem
		where tx_no = pn_tx_no ;

		if nvl(ln_mevcut,0) = 0 then
			insert into cbs_kasa_islem(
					tx_no, kasa_kodu, sube_kodu,
					kullanici_kodu,banka_tarihi,
				    tanim_no, modul_tur_kod,
					urun_tur_kod, urun_sinif_kod,
					islem_kod, origin_islem_kod)
			values
			( 	  	pn_tx_no, ps_kasa_kodu, ps_sube_kodu,
					ps_kullanici_kodu,pkg_muhasebe.banka_tarihi_bul,
			  		pn_tanim_no, pkg_kasa.kasa_modul_tur_kod,
					pkg_kasa.kasa_urun_tur_kod,
					nvl(ps_urun_sinif_kod,pkg_kasa.kasa_urun_sinif_kod),
					pn_islem_kod, ps_origin_islem_kod
					 );
		end if;

		ln_mevcut := 0;
		select count(*)
		into ln_mevcut
		from cbs_kasa_bakiye_islem
		where tx_no = pn_tx_no;

		if nvl(ln_mevcut,0) = 0 then

	 	    insert into cbs_kasa_bakiye_islem
		  		 (tx_no,
				  kasa_kodu,
				  sube_kodu,
				  doviz_kodu,
				  banka_tarihi,
				  bakiye,
				  tanim_no,
				  kullanici_kodu,
				  sira_no,
				  islem_kod,
				  modul_tur_kod,
				  urun_tur_kod ,
				  urun_sinif_kod)
				SELECT pn_tx_no,
					   ps_kasa_kodu,
					   ps_sube_kodu,
					   doviz_kodu,
				       banka_tarihi,
					   decode (pn_islem_kod,1602,0,1604,0,bakiye),
					   pn_tanim_no,
	   				   ps_kullanici_kodu,
					   pkg_genel.genel_kod_al('KASA_BAKIYE_SIRANO'),
					   pn_islem_kod,
					   pkg_kasa.kasa_modul_tur_kod,
					   pkg_kasa.kasa_urun_tur_kod,
					   nvl(ps_urun_sinif_kod,pkg_kasa.kasa_urun_sinif_kod)
					from cbs_kasa_bakiye
					where  kasa_kodu = ls_kasa_kodu and
						   sube_kodu = ls_sube_kodu and
						   banka_tarihi = pkg_muhasebe.banka_tarihi_bul
						   and 	  nvl(bakiye,0) <> 0 ;
       end if;

 if pn_islem_kod in(1603,1602) then /* kasa kapama ise */
   	   if pn_islem_kod = 1603 then /* kasa kapama ise */
  	 	    insert into cbs_kasa_kupur_bakiye_islem
		  		 (tx_no,
				  sira_no,
				  kasa_kodu,
				  sube_kodu,
				  doviz_kodu,
				  kullanici_kodu,
				  banka_tarihi,
				  tanim_no,
				  kupur_kodu,
				  kupur_adedi,
				  kupur_bakiye
/* original karsilastirma tutarlari girilir*/
   				   )
				SELECT pn_tx_no,
				       pkg_genel.genel_kod_al('KASA_KUPUR_SIRANO'),
					   kasa_kodu,
					   sube_kodu,
					   doviz_kodu,
					   ps_kullanici_kodu,
				       pkg_muhasebe.banka_Tarihi_bul,
					   pn_tanim_no,
					   kupur_kodu,
					   kupur_adedi,
					   kupur_bakiye
	   				from cbs_kasa_kupur_bakiye
					where  kasa_kodu = ps_kasa_kodu and
						   sube_kodu = ps_sube_kodu and
						   banka_tarihi = pkg_muhasebe.banka_tarihi_bul;
		/*else
		  	 	  insert into cbs_kasa_kupur_bakiye_islem
		  		 (tx_no,
				  sira_no,
				  kasa_kodu,
				  sube_kodu,
				  doviz_kodu,
				  kullanici_kodu,
				  banka_tarihi,
				  tanim_no,
				  kupur_kodu,
				  kupur_adedi,
				  kupur_bakiye
   				   )
				SELECT pn_tx_no,
				       pkg_genel.genel_kod_al('KASA_KUPUR_SIRANO'),
					   kasa_kodu,
					   sube_kodu,
					   doviz_kodu,
					   ps_kullanici_kodu,
				       pkg_muhasebe.banka_Tarihi_bul,
					   pn_tanim_no,
					   kupur_kodu,
					   0,
					   0
	   				from cbs_kasa_kupur_bakiye
					where  kasa_kodu = ps_kasa_kodu and
						   sube_kodu = ps_sube_kodu and
						   banka_tarihi = pkg_muhasebe.banka_tarihi_bul;
						   */
		end if;

      end if;
 Exception
  when kayit_yok then
	     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '759' || pkg_hata.getUCPOINTER);


 End;


 Function kullanici_kapama_yetkilimi( ps_kasa_kodu varchar2, ps_sube varchar2,ps_kullanici_kodu varchar2) return varchar2
  is
  ls_mevcut varchar2(1) := 'H';

  cursor cur_kasa is
  	  select distinct 'E' mevcut
	  from cbs_kasa_kullanici_tanim
	  where kullanici_kodu = ps_kullanici_kodu and
	  		sube_kodu  = ps_sube and
	  		durum_kodu = 'ACIK' and
			kasa_kodu = ps_kasa_kodu;

 cursor cur_erisim is
  select distinct 'E' mevcut
   from cbs_erisim_rol
   where rol_numara in (
		  select rol_numara from cbs_rol_urun_islem
		  where  islem_tanim_kod = 1602 )
		  	     and not exists  (select 1 from cbs_kasa_kullanici_tanim
			   	  	  		    where kullanici_kodu = ps_kullanici_kodu and
								  durum_kodu = 'ACIK');
  Begin

	for c_kasa in cur_kasa loop
		ls_mevcut := c_kasa.mevcut;
	end loop;

		if ls_mevcut = 'H' Then
			 for c_erisim in cur_erisim loop
			 	ls_mevcut :=  c_erisim.mevcut;
			 end loop;
		end if;

		return ls_mevcut;
  End;

 Function kasa_bakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pd_date date default null) return number
 is
  ln_bakiye number := 0;
  ln_adet number := 1;
    cursor cur_bakiye is
  	  select  bakiye
	  from cbs_vw_kasa_bakiye
	  where kasa_kodu = ps_kasa_kodu and
	  	    sube_kodu = ps_sube and
   		    doviz_kodu = ps_doviz_kodu and
		    banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);
 Begin

	     for c_bakiye in cur_bakiye loop
		 	 ln_bakiye := c_bakiye.bakiye;
		 end loop;

		 return nvl(ln_bakiye,0);

 End;
 Function kasa_kupur_bakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pn_kupur_kodu number, pd_date date default null) return number
 is
  ln_bakiye number := 0;
  ln_adet number := 1;

    cursor cur_bakiye is
  	  select  kupur_bakiye
	  from cbs_vw_kasa_kupur_bakiye
	  where kasa_kodu = ps_kasa_kodu and
	  	    sube_kodu = ps_sube and
   		    doviz_kodu = ps_doviz_kodu and
			kupur_kodu = pn_kupur_kodu and
		    banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);
 Begin

	     for c_bakiye in cur_bakiye loop
		 	 ln_bakiye := c_bakiye.kupur_bakiye;
		 end loop;
		 return nvl(ln_bakiye,0);

 End;

 Procedure bekleyen_kasa_islemi_varmi(pn_islem_no number,ps_kasa_kodu varchar2)
 is
  ln_numara number := 0;
  bekleyen_mevcut exception;
  ls_kasa_kodu    cbs_kasa_kupur_bakiye_islem.kasa_kodu%type;
 Begin
/*   if ps_kasa_kodu is null then
 	  Select distinct kasa_kodu
	  into ls_kasa_kodu
	  from cbs_kasa_bakiye_islem
	  where tx_no = pn_islem_no
	  union
      Select distinct kasa_kodu
	  from cbs_kasa_kupur_bakiye_islem
	  where tx_no = pn_islem_no ;

	 else
	 ls_kasa_kodu := ps_kasa_kodu;
  end if;
  */
  /* kasa kapama varsa engellensin */
 	  select max(numara)
	  into ln_numara
	  from cbs_islem a ,cbs_kasa_kupur_bakiye_islem b
	  where   a.durum in ('C','V','1') and --pkg_tx.Islem_bitmis_mi( numara ) = 0 and
			  a.numara <> pn_islem_no  and
			  a.numara= b.tx_no and
			  kasa_kodu = ls_kasa_kodu and
			  a.ISLEM_KOD = 1603 ;

	 if ln_numara <> 0  then
	 	raise bekleyen_mevcut;
	 end if;

 Exception
    when bekleyen_mevcut then
	   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '756' ||  pkg_hata.getdelimiter|| to_char(ln_numara) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
	when others then null;
End;
 Function kasa_kupur_islem_kod( ps_kod varchar2) return varchar2
 is
  ls_aciklama varchar2(200);
 Begin
 	  select aciklama
	  into ls_aciklama
	  from cbs_kasa_kupur_islem_kodlari
	  where ISLEM_KODU = ps_kod ;

	  return ls_aciklama;
 End;
 Function kasa_kupur_toplambakiye_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2, pd_date date default null) return number
 is
  ln_bakiye number := 0;
  ln_adet number := 1;

    cursor cur_bakiye is
  	  select  sum(nvl(kupur_bakiye,0)) kupur_bakiye
	  from cbs_vw_kasa_kupur_bakiye
	  where kasa_kodu = ps_kasa_kodu and
	  	    sube_kodu = ps_sube and
   		    doviz_kodu = ps_doviz_kodu and
		    banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);
 Begin

	     for c_bakiye in cur_bakiye loop
		 	 ln_bakiye := c_bakiye.kupur_bakiye;
		 end loop;
		 return nvl(ln_bakiye,0);

 End;
  Function kasa_kupur_toplamadet_al( ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2, pd_date date default null) return number
 is

  ln_adet number := 0;

    cursor cur_adet is
  	  select  sum(nvl(KUPUR_ADEDI,0)) KUPUR_ADEDI
	  from cbs_vw_kasa_kupur_bakiye
	  where kasa_kodu = ps_kasa_kodu and
	  	    sube_kodu = ps_sube and
   		    doviz_kodu = ps_doviz_kodu and
		    banka_tarihi = nvl(pd_date,pkg_muhasebe.banka_tarihi_bul);
 Begin

	     for c_adet in cur_adet loop
		 	 ln_adet := c_adet.KUPUR_ADEDI;
		 end loop;
		 return nvl(ln_adet,0);

 End;
 Procedure kasa_gunsonu_bakiye_at(pd_date date default pkg_muhasebe.banka_tarihi_bul)
 is
 Begin

 	  DELETE from cbs_kasa_bakiye_gunluk
	  WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

 	  insert into cbs_kasa_bakiye_gunluk(KASA_KODU, SUBE_KODU, DOVIZ_KODU, BANKA_TARIHI, BAKIYE)
	  select KASA_KODU, SUBE_KODU, DOVIZ_KODU, BANKA_TARIHI, BAKIYE
	  from cbs_kasa_bakiye
	  WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

	  update cbs_kasa_bakiye
	  set BANKA_TARIHI = pkg_tarih.ileri_is_gunu(nvl(pd_date,pkg_muhasebe.banka_tarihi_bul))
	  WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

 	  DELETE from cbs_kasa_kupur_bakiye_gunluk
	  WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

	  insert into cbs_kasa_kupur_bakiye_gunluk(KASA_KODU, SUBE_KODU, DOVIZ_KODU, BANKA_TARIHI, KUPUR_ADEDI, KUPUR_KODU, KUPUR_BAKIYE)
	  select KASA_KODU, SUBE_KODU, DOVIZ_KODU, BANKA_TARIHI, KUPUR_ADEDI, KUPUR_KODU, KUPUR_BAKIYE
	  from cbs_kasa_kupur_bakiye
	   WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

	  update cbs_kasa_kupur_bakiye
	  set BANKA_TARIHI = pkg_tarih.ileri_is_gunu(nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL))
	  WHERE BANKA_TARIHI = nvl(pd_date,pkg_muhasebe.banka_tarihi_BUL);

	  --sevalb 261206
	 /*
	  update cbs_kasa_kullanici_tanim
	  set durum_kodu = 'KAPALI' ,
	  	  KULLANICI_KODU = NULL	,
		  KAPAMA_TARIHI = PKG_MUHASEBE.banka_tarihi_bul
	  where durum_kodu  = 'ACIK';
	  */

 End;

 Function subeye_kasa_baglanabilir(ps_sube varchar2 ) return varchar2
 is
   ls_mevcut varchar2(1) := 'H';
 Begin
 	  select KASA_MEVCUT_MU
	  into ls_mevcut
	  from cbs_bolum
	  where kodu = ps_sube;

	  Return ls_mevcut;
 End;

  Procedure yenidovizkodu_tanimlaninca(ps_doviz_kodu varchar2 )
  is

   cursor cur_kasa is
    Select * from cbs_kasa_kodlari
	where durum_kodu = 'ACIK';

  Begin
  	   For c_kasa in cur_kasa loop
 		   kasa_sifir_bakiyeli_yarat(c_kasa.kasa_kodu  , c_kasa.sube_kodu ,ps_doviz_kodu  );
	   End loop;
  End;
 Function kasa_uygunmu( ps_sube_kodu varchar2,ps_kasa_kodu varchar2) return varchar2
 is
 ls_durum   VARCHAR2(20);
 Begin
 	  if ps_kasa_kodu = ana_kasa_kodu then
	    return 'H';
	   else
	   	   select durum_kodu
		   into ls_durum
	       from cbs_kasa_kodlari
		   where sube_kodu = ps_sube_kodu and
		   		 kasa_kodu = ps_kasa_kodu ;
		   	if ls_durum = 'ACIK' then
			   return 'E';
			 else
			    return 'H';
			end if;
		end if;
	Exception when others then return 'H';

 End;
 ------------------------------------------------------------------------
  Procedure kasa_bakiye_kontrol(ps_kasa_kodu varchar2, ps_sube varchar2, ps_doviz_kodu varchar2,pn_tutar number default 0,pd_date date default null)
  is
   bakiye_uygun_Degil exception;
  begin
  		if nvl(pn_tutar,0) > nvl(kasa_bakiye_al( ps_kasa_kodu , ps_sube , ps_doviz_kodu ,pd_date),0) then
		   raise bakiye_uygun_Degil;
		end if;
  Exception
	When bakiye_uygun_Degil then
	 	 		 Raise_application_error(-20100,pkg_hata.getUCPOINTER || '735' ||  pkg_hata.getdelimiter|| to_char(ps_doviz_kodu) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end ;
 ------------------------------------------------------------------------
 Function exchange_kasa_kodu  return varchar2
 is
 Begin
 		  return '01000001';
 End;
END;
/

