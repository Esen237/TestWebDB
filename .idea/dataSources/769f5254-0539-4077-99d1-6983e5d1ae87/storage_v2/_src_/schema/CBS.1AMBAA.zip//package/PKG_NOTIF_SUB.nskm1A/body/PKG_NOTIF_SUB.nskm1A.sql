create PACKAGE BODY     PKG_NOTIF_SUB
AS
   /******************************************************************************
    NAME :         SF_CHECK_SUB
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Checks if client subbed for this notification
    ******************************************************************************/
   FUNCTION SF_CHECK_SUB (PN_CUSTOMER_NO   IN     NUMBER,
                          PN_OP_ID_NO      IN     NUMBER,
                          PS_EMAIL            OUT BOOLEAN,
                          PS_SMS              OUT BOOLEAN,
                          PS_PUSH             OUT BOOLEAN,
                          PS_NOT_LANG         OUT VARCHAR2)
      RETURN VARCHAR2 IS
      LS_SMS          VARCHAR2 (1);
      LS_EMAIL        VARCHAR2 (1);
      LS_PUSH         VARCHAR2 (1);
      LS_STATUS       VARCHAR2 (1);
      LN_NOTIF_PACK   NUMBER;
   BEGIN
      SELECT STATUS INTO LS_STATUS FROM CBS_NOTIF_OPS_LIST WHERE ID = PN_OP_ID_NO;
      IF LS_STATUS = 'A' THEN
          SELECT NOTIF_PACK INTO LN_NOTIF_PACK FROM CBS_MUSTERI WHERE MUSTERI_NO = PN_CUSTOMER_NO AND MUSTERI_TIPI_KOD in ('1'); --bahianab according to request from Retail HO
          IF LN_NOTIF_PACK IS NOT NULL THEN
            SELECT SMS_NOTIFICATION, EMAIL_NOTIFICATION, PUSH_NOTIFICATION INTO LS_SMS, LS_EMAIL, LS_PUSH 
            FROM CBS_CUST_PACK_OPS WHERE CUSTOMER_NO = PN_CUSTOMER_NO AND OPERATION_ID = PN_OP_ID_NO;
            IF LS_EMAIL = 'Y' THEN PS_EMAIL := TRUE; ELSE PS_EMAIL := FALSE; END IF;
            IF LS_SMS = 'Y' THEN PS_SMS := TRUE; ELSE PS_SMS := FALSE; END IF;
            IF LS_PUSH = 'Y' THEN PS_PUSH := TRUE; ELSE PS_PUSH := FALSE; END IF;
            return '000';
          ELSE
             ps_email := FALSE;
             ps_sms := FALSE;
             ps_push := FALSE;
             RETURN '999';
          END IF;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN 0;
      WHEN OTHERS
      THEN
         log_at('SMS_NOTIF','SF_CHECK_SUB',SQLERRM,dbms_utility.format_error_backtrace);
         RAISE_APPLICATION_ERROR ( -20100, PKG_HATA.GETUCPOINTER || '201' || PKG_HATA.GETDELIMITER || PN_CUSTOMER_NO || PKG_HATA.GETUCPOINTER);
         
   END;

   /******************************************************************************
    NAME :         SF_GENERATE_NOTIF
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Calls needed function to generate notification text
    ******************************************************************************/
   PROCEDURE SF_GENERATE_NOTIF (PN_TX_NO IN NUMBER, PN_ISLEM_KOD IN NUMBER) IS
      LS_RES          VARCHAR2 (3);
      LS_RET          VARCHAR2 (3);
      LS_SUB_RES      VARCHAR2 (3);
      LS_EMAIL_BODY   VARCHAR2 (32766);
      LS_SMS_BODY     VARCHAR2 (1000);
      LS_PUSH_BODY    VARCHAR2 (200);
      ps_external     varchar2(20);
      lN_CUSTOMER_NO  number;
      ls_not_lang     VARCHAR2 (3);
      lb_email        boolean;
      lb_sms          boolean;
      lb_push         boolean;
      pc_ref          CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
      pc_res          CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
      l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; --bahianab cbs-113 
      ls_tran_code    VARCHAR2 (4); --bahianab cbs-607 03022022 
      ls_emails       varchar2(2000);
      ls_phones       varchar2(2000);
   BEGIN
   
   l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1); --bahianab cbs-113
   
      IF PN_ISLEM_KOD = 2300 THEN
         DECLARE
            CURSOR CUR_2300 IS SELECT * FROM cbs_hesap_basvuru_toplu_isl WHERE TX_NO = PN_TX_NO;
            REC_2300 CUR_2300%ROWTYPE;
             
         BEGIN
            open cur_2300;
            LOOP
                 FETCH CUR_2300 INTO REC_2300;
                 EXIT WHEN CUR_2300%NOTFOUND;
                 
                 IF REC_2300.CARD_TYPE IS not NULL THEN
                     LS_SUB_RES := sf_check_sub(REC_2300.MUSTERI_NO, 1, lb_email, lb_sms, lb_push, ls_not_lang);
                     if LS_SUB_RES = '000' then
                         LS_RES := GENERATE_2300_NOT (PN_TX_NO, REC_2300.MUSTERI_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                         IF LS_RES = '000'
                         THEN
                            IF lb_email THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL( SF_GET_CUST_EMAIL (REC_2300.MUSTERI_NO), 'New Account Info', LS_EMAIL_BODY, 'new_account', pc_ref);
                                l_recipients(1) := SF_GET_CUST_EMAIL (REC_2300.MUSTERI_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(TO_CHAR(LS_EMAIL_BODY), 'New Account Info', 'info@demirbank.kg',l_recipients, 'HTML', 'new_account',null,null); --bahianab cbs-113
                            END IF;
                            IF lb_sms THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS (SF_GET_CUST_PHONE (REC_2300.MUSTERI_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                                l_recipients(1) := SF_GET_CUST_PHONE (REC_2300.MUSTERI_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                            END IF;
                            IF lb_push THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDPUSHNOTIFICATION(TO_CHAR(LS_PUSH_BODY), REC_2300.MUSTERI_NO, 'New Account Info', pc_ref);
                                --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(REC_2300.MUSTERI_NO); --bahianab cbs-469 --bahianab cbs-113                 
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),REC_2300.MUSTERI_NO);  --bahianab cbs-469--bahianab cbs-113
                            END IF;
                         END IF;
                     end if;
                 else
                     null;
                 END IF;
            END LOOP;
            close cur_2300;
          END;
      ELSIF PN_ISLEM_KOD = 2000 THEN
         select musteri_no into lN_CUSTOMER_NO from cbs_hesap_basvuru where tx_no = pn_tx_no;
         LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 1, lb_email, lb_sms, lb_push, ls_not_lang);
         if LS_SUB_RES = '000' then
             select external_hesap_no into ps_external from cbs_hesap where hesap_no = (select hesap_numara from cbs_islem where numara = pn_tx_no);
             LS_RES := GENERATE_2000_NOT (PN_TX_NO, lN_CUSTOMER_NO, ps_external, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
             IF LS_RES = '000'
             THEN
                IF lb_email THEN
                    --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(SF_GET_CUST_EMAIL (lN_CUSTOMER_NO), 'New Account Info', TO_CHAR (LS_EMAIL_BODY), 'new_account', pc_ref);
                    l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'New Account Info', 'info@demirbank.kg',l_recipients, 'HTML', 'new_account',null,null); --bahianab cbs-113
                END IF;
                IF lb_sms THEN
                    --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (lN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                    l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                END IF;
                IF lb_push THEN
                    --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'New Account Info', pc_ref);
                    --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO); --bahianab cbs-469 --bahianab cbs-113               
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                END IF;
             END IF;
         end if;
      ELSIF PN_ISLEM_KOD = 2010 THEN --swift added
         select ALICI_MUSTERI_NO into lN_CUSTOMER_NO from cbs_yphavale_gelen_basvuru where tx_no = pn_tx_no;
         LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 23, lb_email, lb_sms, lb_push, ls_not_lang);
         if LS_SUB_RES = '000' then
             select external_hesap_no into ps_external from cbs_hesap where hesap_no = (select hesap_numara from cbs_islem where numara = pn_tx_no);
             LS_RES := GENERATE_2010_NOT (PN_TX_NO, lN_CUSTOMER_NO, ps_external, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
             IF LS_RES = '000'
             THEN
                IF lb_email THEN
                    --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(SF_GET_CUST_EMAIL (lN_CUSTOMER_NO), 'SWIFT Inflow transaction', TO_CHAR (LS_EMAIL_BODY), 'swift_inflow', pc_ref);
                    l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'SWIFT Inflow transaction', 'info@demirbank.kg',l_recipients, 'HTML', 'swift_inflow',null,null); --bahianab cbs-113
                END IF;
                IF lb_sms THEN
                    --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (lN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                    l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                END IF;
                IF lb_push THEN
                    --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'SWIFT Inflow transaction', pc_ref);
                    --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                END IF;
             END IF;
         end if;   
      ELSIF PN_ISLEM_KOD = 1001
      THEN
         select musteri_numara into ln_customer_no from cbs_islem where numara = pn_tx_no;
         LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 2, lb_email, lb_sms, lb_push, ls_not_lang);
         if LS_SUB_RES = '000' then
             LS_RES := GENERATE_1001_NOT (PN_TX_NO, lN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY, ls_emails, ls_phones);

             IF LS_RES = '000'
             THEN
                IF lb_email THEN
                    if instr(ls_emails, ',') > 0 then
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (substr(ls_emails, 1, instr(ls_emails, ',')), 'Information Update', TO_CHAR (LS_EMAIL_BODY), 'update_info', pc_ref);
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (substr(ls_emails, instr(ls_emails, ',') + 1), 'Information Update', TO_CHAR (LS_EMAIL_BODY), 'update_info', pc_ref);
                        l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1,2); --bahianab cbs-113
                        l_recipients(1) := ls_emails; --bahianab cbs-113
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Information Update', 'info@demirbank.kg',l_recipients, 'HTML', 'update_info',null,null); --bahianab cbs-113
                    else
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (ls_emails, 'Information Update', TO_CHAR (LS_EMAIL_BODY), 'update_info', pc_ref);
                        l_recipients(1) := ls_emails; --bahianab cbs-113
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Information Update', 'info@demirbank.kg',l_recipients, 'HTML', 'update_info',null,null); --bahianab cbs-113
                    end if;
                END IF;
                IF lb_sms THEN
                    if instr(ls_phones, ',') > 0 then
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( substr(ls_phones, 1, instr(ls_phones, ',')), TO_CHAR(LS_SMS_BODY), pc_ref);
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( substr(ls_phones, instr(ls_phones, ',') + 1), TO_CHAR(LS_SMS_BODY), pc_ref);
                        l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1,2); --bahianab cbs-113
                        l_recipients(1) := ls_phones; --bahianab cbs-113
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                    else
                        --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( ls_phones, TO_CHAR(LS_SMS_BODY), pc_ref);
                        l_recipients(1) := ls_phones; --bahianab cbs-113
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                    end if;
                END IF;
                IF lb_push THEN
                    --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Information Update', pc_ref);
                    --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                    LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                END IF;
             END IF;
         end if;
      ELSIF PN_ISLEM_KOD = 2304
      THEN
         select customer_no into ln_customer_no from cbs_debit_card_main_tran where tx_no = pn_tx_no;
         LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 1, lb_email, lb_sms, lb_push, ls_not_lang);
         if LS_SUB_RES = '000' then
         LS_RES := GENERATE_2304_NOT (PN_TX_NO, lN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

         IF LS_RES = '000'
         THEN
            IF lb_email THEN
                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (lN_CUSTOMER_NO), 'Bind account to debit card', TO_CHAR (LS_EMAIL_BODY), 'card_acc_tie', pc_ref);
                l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Bind account to debit card', 'info@demirbank.kg',l_recipients, 'HTML', 'card_acc_tie',null,null); --bahianab cbs-113
            END IF;
            IF lb_sms THEN
                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (lN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
            END IF;
            IF lb_push THEN
                --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Bind account to debit card', pc_ref);
                --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
            END IF;
         END IF;
         end if;
      ELSIF PN_ISLEM_KOD = 2150
      THEN
         DECLARE
         CURSOR CUR_2150 IS SELECT * FROM CBS_SALARY_DETAIL_ISLEM WHERE TX_NO = PN_TX_NO;
         REC_2150 CUR_2150%ROWTYPE;
         BEGIN
             open CUR_2150;
             LOOP
                 FETCH CUR_2150 INTO REC_2150;
                 exit when CUR_2150%notfound;
                 LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(REC_2150.STAFF_ACCOUNT_NO);
                 LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 20, lb_email, lb_sms, lb_push, ls_not_lang);
                 if LS_SUB_RES = '000' then
                     LS_RES := GENERATE_2150_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Salary payment', TO_CHAR (LS_EMAIL_BODY), 'temp_salary', pc_ref);
                            l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Salary payment', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_salary',null,null); --bahianab cbs-113
                        END IF;
                        IF lb_sms THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                        END IF;
                        IF lb_push THEN
                            --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Salary payment', pc_ref);
                            --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                        END IF;
                     END IF;
                 end if;
             END LOOP;
             close CUR_2150;
         END;
      ELSIF PN_ISLEM_KOD = 6200
      THEN
         DECLARE
         CURSOR CUR_6200 IS SELECT musteri_no, THIRD_PERSON_NAME FROM CBS_CARI_NAKIT_YATAN_ISLEM WHERE TX_NO = PN_TX_NO;
         REC_6200 CUR_6200%ROWTYPE;
         BEGIN
             open CUR_6200;
             LOOP
                 FETCH CUR_6200 INTO REC_6200;
                 exit when CUR_6200%notfound;
                 lN_CUSTOMER_NO := rec_6200.musteri_no;
                 if rec_6200.THIRD_PERSON_NAME is null then
                     LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 17, lb_email, lb_sms, lb_push, ls_not_lang);
                     if LS_SUB_RES = '000' then
                         LS_RES := GENERATE_6200_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                         IF LS_RES = '000'
                         THEN
                            IF lb_email THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Account Replenishment', TO_CHAR (LS_EMAIL_BODY), 'temp_6200', pc_ref);
                                l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Account Replenishment', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_6200',null,null); --bahianab cbs-113                            
                                END IF;
                            IF lb_sms THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                                l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                            END IF;
                            IF lb_push THEN
                                --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Account Replenishment', pc_ref);
                                --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113
                            END IF;
                         END IF;
                     end if;
                 else
                    LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 18, lb_email, lb_sms, lb_push, ls_not_lang);
                     if LS_SUB_RES = '000' then
                         LS_RES := GENERATE_6200_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                         IF LS_RES = '000'
                         THEN
                            IF lb_email THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Account Replenishment', TO_CHAR (LS_EMAIL_BODY), 'temp_6200', pc_ref);
                                l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Account Replenishment', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_6200',null,null); --bahianab cbs-113
                            END IF;
                            IF lb_sms THEN
                                --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                                l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                            END IF;
                            IF lb_push THEN
                                --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Account Replenishment', pc_ref);
                                --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469 --bahianab cbs-113              
                                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                            END IF;
                         END IF;
                     end if;
                 end if;
             END LOOP;
             close CUR_6200;
         END;
      ELSIF PN_ISLEM_KOD = 1203
      THEN
         DECLARE
         CURSOR CUR_1203 IS SELECT ALACAK_EXTERNAL_HESAP,BORC_EXTERNAL_HESAP FROM CBS_VIRMAN_ISLEM WHERE TX_NO = PN_TX_NO;
         REC_1203 CUR_1203%ROWTYPE;
         BEGIN
             open CUR_1203;
             LOOP
                 FETCH CUR_1203 INTO REC_1203;
                 exit when CUR_1203%notfound;
                 ln_customer_no := PKG_HESAP.GETMUSTERINOFROMEXTERNAL(rec_1203.ALACAK_EXTERNAL_HESAP);
                 LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 21, lb_email, lb_sms, lb_push, ls_not_lang);
                 if LS_SUB_RES = '000' then
                     LS_RES := GENERATE_1203_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Incoming Transfer', TO_CHAR (LS_EMAIL_BODY), 'temp_1203', pc_ref);
                            l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Incoming Transfer', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_1203',null,null); --bahianab cbs-113
                        END IF;
                        IF lb_sms THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                        END IF;
                        IF lb_push THEN
                            --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Incoming Transfer', pc_ref);
                            --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);   --bahianab cbs-469 --bahianab cbs-113             
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                        END IF;
                     END IF;
                 end if;
                 /*BOM bahianab CBS-562 09122021*/
                 ln_customer_no := PKG_HESAP.GETMUSTERINOFROMEXTERNAL(rec_1203.BORC_EXTERNAL_HESAP);
                 LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 21, lb_email, lb_sms, lb_push, ls_not_lang);
                 if LS_SUB_RES = '000' then
                     LS_RES := GENERATE_1203_OUT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN                           
                            l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO);
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Outgoing Transfer', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_1203_out',null,null);
                        END IF;
                        IF lb_sms THEN
                            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO);
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients);
                        END IF;
                        IF lb_push THEN           
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);
                        END IF;
                     END IF;
                 end if;
                 /*EOM bahianab CBS-562 09122021*/
             END LOOP;
             close CUR_1203;
         END;
      ELSIF PN_ISLEM_KOD = 3556
      THEN
         DECLARE
         CURSOR CUR_3556 IS SELECT TO_ACCOUNT_EXTERNAL_NUMBER FROM CBS_CLEARING_ISLEM WHERE TX_NO = PN_TX_NO;
         REC_3556 CUR_3556%ROWTYPE;
         BEGIN
             open CUR_3556;
             LOOP
                 FETCH CUR_3556 INTO REC_3556;
                 exit when CUR_3556%notfound;
                 LN_CUSTOMER_NO := PKG_HESAP.GETMUSTERINOFROMEXTERNAL(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER);
                 LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 22, lb_email, lb_sms, lb_push, ls_not_lang);
                 if LS_SUB_RES = '000' then
                     LS_RES := GENERATE_3556_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Incoming Transfer', TO_CHAR (LS_EMAIL_BODY), 'temp_3556', pc_ref);
                            l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Incoming Transfer', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_3556',null,null); --bahianab cbs-113
                        END IF;
                        IF lb_sms THEN
                            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                        END IF;
                        IF lb_push THEN
                            --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Incoming Transfer', pc_ref);
                            --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);   --bahianab cbs-469 --bahianab cbs-113           
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                        END IF;
                     END IF;
                 end if;
             END LOOP;
             close CUR_3556;
         END;
      ELSIF PN_ISLEM_KOD = 8800
      THEN
         DECLARE
         cursor cur_fin is select FROM_ACCOUNT_NUMBER from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01'; --CBS-461 bahianab 160621 kompanion trx issue
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER);
             select tran_code into ls_tran_code from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01';--bahianab cbs-607 03022022 
             LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 7, lb_email, lb_sms, lb_push, ls_not_lang);
               if LS_SUB_RES = '000' then
               --BOM bahianab cbs-607 03022022
               IF LS_TRAN_CODE= '0509' THEN  
                   LS_RES := GENERATE_8800_QR (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                    IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO);
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'QR Money Withdrawal', 'info@demirbank.kg',l_recipients, 'HTML', 'debit_wthdr_qr',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO);
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients);
                      END IF;
                      IF lb_push THEN            
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);
                      END IF;
                   END IF;    
               ELSE 
               --EOM bahianab cbs-607 03022022
                   LS_RES := GENERATE_8800_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Card Money Withdrawal', TO_CHAR (LS_EMAIL_BODY), 'debit_wthdr', pc_ref);
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Card Money Withdrawal', 'info@demirbank.kg',l_recipients, 'HTML', 'debit_wthdr',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                      END IF;
                      IF lb_push THEN
                          --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Card Money Withdrawal', pc_ref);
                          --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO); --bahianab cbs-469 --bahianab cbs-113               
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                      END IF;
                   END IF;
               END IF; --bahianab cbs-607 03022022 
               end if; 
          END LOOP;
          CLOSE CUR_FIN;
         END;
      ELSIF PN_ISLEM_KOD = 8806
      THEN
         DECLARE
         cursor cur_fin is select TO_ACCOUNT_NUMBER from cbs_atm_finansal_islem where tx_no = pn_tx_no and nvl(FROM_ACCOUNT_NUMBER, 0) = 0 and card_bank_code ='01'; --cbs-461 bahianab 160621 kompanion trx issue
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER);
             select tran_code into ls_tran_code from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01';--bahianab cbs-607 03022022 
             LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 19, lb_email, lb_sms, lb_push, ls_not_lang);
               if LS_SUB_RES = '000' then
               --BOM bahianab cbs-607 03022022
               IF LS_TRAN_CODE= '0511' THEN
               LS_RES := GENERATE_8806_QR (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO);
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'QR Replenishment', 'info@demirbank.kg',l_recipients, 'HTML', 'debit_inflow_qr',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO);
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients);
                      END IF;
                      IF lb_push THEN         
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);
                      END IF;
                   END IF;
               ELSE    
               --EOM bahianab cbs-607 03022022
                   LS_RES := GENERATE_8806_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'ATM Replenishment', TO_CHAR (LS_EMAIL_BODY), 'debit_inflow', pc_ref);
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'ATM Replenishment', 'info@demirbank.kg',l_recipients, 'HTML', 'debit_inflow',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                      END IF;
                      IF lb_push THEN
                          --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'ATM Replenishment', pc_ref);
                          --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);   --bahianab cbs-469 --bahianab cbs-113             
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113
                      END IF;
                   END IF;
               END IF; --cbs-607 bahianab 03022022  
               end if;
          END LOOP;
          CLOSE CUR_FIN;
         END;
      ELSIF PN_ISLEM_KOD = 8807
      THEN
         DECLARE
         cursor cur_fin is select FROM_ACCOUNT_NUMBER from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01'; --cbs-461 bahianab 160621 kompanion trx issue
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER);
             LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 9, lb_email, lb_sms, lb_push, ls_not_lang);
               if LS_SUB_RES = '000' then
                   LS_RES := GENERATE_8807_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'POS Sales', TO_CHAR (LS_EMAIL_BODY), 'dkib_pos_debit', pc_ref);
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'POS Sales', 'info@demirbank.kg',l_recipients, 'HTML', 'dkib_pos_debit',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                      END IF;
                      IF lb_push THEN
                          --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'POS Sales', pc_ref);
                          --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113                
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
                      END IF;
                   END IF;
               end if;
          END LOOP;
          CLOSE CUR_FIN;
         END;
      ELSIF PN_ISLEM_KOD = 8821
      THEN
         DECLARE
         cursor cur_fin is select FROM_ACCOUNT_NUMBER, merchant_location from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01'; --cbs-461 bahianab 160621 kompanion trx issue
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER);
             if instr(rec_fin.merchant_location, 'KG') > 0 then
                   LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 11, lb_email, lb_sms, lb_push, ls_not_lang);
                   if LS_SUB_RES = '000' then
                       LS_RES := GENERATE_8821_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                       IF LS_RES = '000'
                       THEN
                          IF lb_email THEN
                              --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'POS Sales', TO_CHAR (LS_EMAIL_BODY), 'dkib_pos_debit', pc_ref);
                              l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'POS Sales', 'info@demirbank.kg',l_recipients, 'HTML', 'dkib_pos_debit',null,null); --bahianab cbs-113
                          END IF;
                          IF lb_sms THEN
                              --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                              l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                          END IF;
                          IF lb_push THEN
                              --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'POS Sales', pc_ref);
                              --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113                
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
                          END IF;
                       END IF;
                   end if;
             else
                  LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 13, lb_email, lb_sms, lb_push, ls_not_lang);
                   if LS_SUB_RES = '000' then
                       LS_RES := GENERATE_8821_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                       IF LS_RES = '000'
                       THEN
                          IF lb_email THEN
                              --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'POS Sales', TO_CHAR (LS_EMAIL_BODY), 'dkib_pos_debit', pc_ref);
                              l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'POS Sales', 'info@demirbank.kg',l_recipients, 'HTML', 'dkib_pos_debit',null,null); --bahianab cbs-113
                          END IF;
                          IF lb_sms THEN
                              --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                              l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                          END IF;
                          IF lb_push THEN
                              --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'POS Sales', pc_ref);
                              --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO); --bahianab cbs-469 --bahianab cbs-113                
                              LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
                          END IF;
                       END IF;
                   end if;
             end if;
          END LOOP;
          CLOSE CUR_FIN;
         END;
      ELSIF PN_ISLEM_KOD in (8826,8820,8824) --bahianab cbs-662 adding new internet transactions
      THEN
         DECLARE
         cursor cur_fin is select FROM_ACCOUNT_NUMBER from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01'; --cbs-461 bahianab 160621 kompanion trx issue
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER);
             LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 15, lb_email, lb_sms, lb_push, ls_not_lang);
               if LS_SUB_RES = '000' then
                   LS_RES := GENERATE_8826_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL (SF_GET_CUST_EMAIL (LN_CUSTOMER_NO), 'Internet Sales', TO_CHAR (LS_EMAIL_BODY), 'internet_pymt', pc_ref);
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Internet Sales', 'info@demirbank.kg',l_recipients, 'HTML', 'internet_pymt',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN
                          --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (LN_CUSTOMER_NO), TO_CHAR(LS_SMS_BODY), pc_ref);
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
                      END IF;
                      IF lb_push THEN
                          --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), lN_CUSTOMER_NO, 'Internet Sales', pc_ref);
                          --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(lN_CUSTOMER_NO);  --bahianab cbs-469--bahianab cbs-113                
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
                      END IF;
                   END IF;
               end if;
          END LOOP;
          CLOSE CUR_FIN;
         END;
      ELSIF PN_ISLEM_KOD in (8837) --bahianab cbs-662 adding new internet transactions
      THEN
         DECLARE
         cursor cur_fin is select TO_ACCOUNT_NUMBER from cbs_atm_finansal_islem where tx_no = pn_tx_no and card_bank_code ='01';
         rec_fin cur_fin%rowtype;
         BEGIN
          OPEN CUR_FIN;
          LOOP
             FETCH CUR_FIN INTO REC_FIN;
             EXIT WHEN CUR_FIN%NOTFOUND;
             LN_CUSTOMER_NO := PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER);
             LS_SUB_RES := sf_check_sub(lN_CUSTOMER_NO, 15, lb_email, lb_sms, lb_push, ls_not_lang);
               if LS_SUB_RES = '000' then
                   LS_RES := GENERATE_8837_NOT (PN_TX_NO, LN_CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);
                   IF LS_RES = '000'
                   THEN
                      IF lb_email THEN                          
                          l_recipients(1) := SF_GET_CUST_EMAIL (lN_CUSTOMER_NO); 
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Visa Money Send', 'info@demirbank.kg',l_recipients, 'HTML', 'debit_inflow',null,null); --bahianab cbs-113
                      END IF;
                      IF lb_sms THEN                          
                          l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); 
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); 
                      END IF;
                      IF lb_push THEN                          
                          LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO);
                      END IF;
                   END IF;
               end if;
          END LOOP;
          CLOSE CUR_FIN;
         END;   
      ELSIF PN_ISLEM_KOD in (7000) --NurmilaZ Interbank QR 18/11/2022
      THEN
        DECLARE
         CURSOR CUR_7000 IS SELECT CUSTOMER_NO, DIRECTION FROM CBS_IPC_QR_PAYMENTS WHERE TX_NO = PN_TX_NO;
         REC_7000 CUR_7000%ROWTYPE;
         BEGIN
             open CUR_7000;
             LOOP
                 FETCH CUR_7000 INTO REC_7000;
                 exit when CUR_7000%notfound;
                 LS_SUB_RES := sf_check_sub(REC_7000.CUSTOMER_NO, 21, lb_email, lb_sms, lb_push, ls_not_lang);
                 if REC_7000.DIRECTION = 'IN' then
                     LS_RES := GENERATE_7000_NOT (PN_TX_NO, REC_7000.CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN
                            l_recipients(1) := SF_GET_CUST_EMAIL (REC_7000.CUSTOMER_NO); 
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Incoming interbank QR transfer', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_7000_in',null,null); 
                        END IF;
                        IF lb_sms THEN
                            l_recipients(1) := SF_GET_CUST_PHONE (REC_7000.CUSTOMER_NO); 
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); 
                        END IF;
                        IF lb_push THEN            
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),REC_7000.CUSTOMER_NO);  
                        END IF;
                     END IF;
                     
                 elsif REC_7000.DIRECTION = 'OUT' then
                 
                     LS_RES := GENERATE_7000_OUT (PN_TX_NO, REC_7000.CUSTOMER_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

                     IF LS_RES = '000'
                     THEN
                        IF lb_email THEN                           
                            l_recipients(1) := SF_GET_CUST_EMAIL (REC_7000.CUSTOMER_NO);
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Outgoing interbank QR Transfer', 'info@demirbank.kg',l_recipients, 'HTML', 'temp_7000_out',null,null);
                        END IF;
                        IF lb_sms THEN
                            l_recipients(1) := SF_GET_CUST_PHONE (REC_7000.CUSTOMER_NO);
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients);
                        END IF;
                        IF lb_push THEN           
                            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),REC_7000.CUSTOMER_NO);
                        END IF;
                     END IF;
                 end if;
             END LOOP;
             close CUR_7000;
         END;
    --BOM AntonPa CBS-821 110123     
      ELSIF PN_ISLEM_KOD = 4141
      THEN
         SELECT RECEIVER_CUSTOMER_NO INTO LN_CUSTOMER_NO FROM CBS_GOLD_CROWN_OPERATIONS WHERE TX_NO = PN_TX_NO;
         LS_SUB_RES := SF_CHECK_SUB(LN_CUSTOMER_NO, 1, LB_EMAIL, LB_SMS, LB_PUSH, LS_NOT_LANG);
         IF LS_SUB_RES = '000' THEN
         LS_RES := GENERATE_4141_NOT (PN_TX_NO, LS_EMAIL_BODY, LS_SMS_BODY, LS_PUSH_BODY);

         IF LS_RES = '000'
         THEN
            IF LB_EMAIL THEN                           
                L_RECIPIENTS(1) := 'bermet.bazarova@ctechnology.kg';--SF_GET_CUST_EMAIL(LN_CUSTOMER_NO);
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(TO_CHAR(LS_EMAIL_BODY), 'Zolotaya Korona Money Transfer', 'info@demirbank.kg',L_RECIPIENTS, 'HTML', 'gold_crown_MT',NULL,NULL);
            END IF;
            IF LB_SMS THEN
                L_RECIPIENTS(1) := SF_GET_CUST_PHONE (LN_CUSTOMER_NO); 
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),L_RECIPIENTS); 
            END IF;
            IF LB_PUSH THEN     
                LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),LN_CUSTOMER_NO);  
            END IF;
         END IF;
         end if;
    --EOM AntonPa CBS-821 110123  
      END IF;

   EXCEPTION
      WHEN OTHERS
      THEN
         null;
         log_at('SMS_NOTIF','SF_GENERATE_NOTIF',SQLERRM,dbms_utility.format_error_backtrace);
         log_at('SMS_NOTIF','SF_GENERATE_NOTIF',to_char(PN_ISLEM_KOD), to_char(PN_TX_NO));   --bahianab 16092021    
   END;

   /******************************************************************************
    NAME :         SF_GET_CUST_EMAIL
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Returns clients email
    ******************************************************************************/
   FUNCTION SF_GET_CUST_EMAIL (PN_CUSTOMER_NO IN NUMBER)
      RETURN VARCHAR2 IS
      CURSOR cur_email IS
         SELECT email FROM cbs_musteri_adres
          WHERE musteri_no = pn_customer_no;

      r_email    cur_email%ROWTYPE;
      LS_EMAIL   CBS_MUSTERI_ADRES.EMAIL%TYPE;
   BEGIN
      OPEN cur_email;
      LOOP
         FETCH cur_email INTO r_email;
         EXIT WHEN cur_email%NOTFOUND;
         IF r_email.email IS NOT NULL
         THEN
            ls_email := r_email.email;
         END IF;
      END LOOP;
      CLOSE cur_email;

      RETURN LS_EMAIL;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RAISE_APPLICATION_ERROR (-20100, PKG_HATA.GETUCPOINTER || '1923' || PKG_HATA.GETDELIMITER || PN_CUSTOMER_NO || PKG_HATA.GETUCPOINTER);
      WHEN OTHERS
      THEN
         log_at('SMS_NOTIF','SF_GET_CUST_EMAIL',SQLERRM,dbms_utility.format_error_backtrace);
         RAISE_APPLICATION_ERROR (-20100, PKG_HATA.GETUCPOINTER || '201' || PKG_HATA.GETDELIMITER || PN_CUSTOMER_NO || PKG_HATA.GETUCPOINTER);
         
   END;

   /******************************************************************************
    NAME :         SF_GET_CUST_PHONE
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Returns clients GSM phone number
    ******************************************************************************/
   FUNCTION SF_GET_CUST_PHONE (PN_CUSTOMER_NO IN NUMBER)
      RETURN VARCHAR2
   IS
      ln_telefon   VARCHAR2 (200);

      CURSOR cur_ekstre_adres IS
         SELECT TRIM (ULKE_GSM_KOD) || GSM_ALAN_KOD || GSM_NO
           FROM CBS_MUSTERI_ADRES a, CBS_MUSTERI b
          WHERE     a.musteri_no = b.musteri_no
                AND adres_kod = b.extre_adres_kod
                AND a.musteri_no = PN_CUSTOMER_NO;

      CURSOR cur_musteri IS
         SELECT TRIM (ULKE_GSM_KOD) || GSM_ALAN_KOD || GSM_NO
           FROM CBS_MUSTERI_ADRES a, CBS_MUSTERI b
          WHERE     a.musteri_no = b.musteri_no
                AND adres_kod = DECODE (b.musteri_tipi_kod, '1', '1', '2')
                AND a.musteri_no = PN_CUSTOMER_NO;

      CURSOR cur_musteri_contact IS
         SELECT TRIM (ULKE_GSM_KOD) || GSM_ALAN_KOD || GSM_NO
           FROM CBS_MUSTERI_ADRES a, CBS_MUSTERI b
          WHERE     a.musteri_no = b.musteri_no
                AND adres_kod = '3'
                AND a.musteri_no = PN_CUSTOMER_NO;
   BEGIN
      IF cur_ekstre_adres%ISOPEN /*extra phone number is taken */
      THEN
         CLOSE cur_ekstre_adres;
      END IF;

      OPEN cur_ekstre_adres;

      LOOP
         FETCH cur_ekstre_adres INTO ln_telefon;

         EXIT WHEN cur_ekstre_adres%NOTFOUND;
      END LOOP;

      CLOSE cur_ekstre_adres;

      IF ln_telefon IS NULL /* if there is no extra phone number */
      THEN
         IF cur_musteri%ISOPEN
         THEN
            CLOSE cur_musteri;
         END IF;

         OPEN cur_musteri;

         LOOP
            FETCH cur_musteri INTO ln_telefon;

            EXIT WHEN cur_musteri%NOTFOUND;
         END LOOP;

         CLOSE cur_musteri;
      END IF;

      IF ln_telefon IS NULL/* if there is no home or work telephone, communication phone number is taken */
      THEN
         IF cur_musteri_contact%ISOPEN
         THEN
            CLOSE cur_musteri_contact;
         END IF;

         OPEN cur_musteri_contact;

         LOOP
            FETCH cur_musteri_contact INTO ln_telefon;

            EXIT WHEN cur_musteri_contact%NOTFOUND;
         END LOOP;

         CLOSE cur_musteri_contact;
      END IF;

      RETURN ln_telefon;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
         log_at('SMS_NOTIF','SF_GET_CUST_PHONE',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   
   FUNCTION GENERATE_2300_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PS_EMAIL_BODY       OUT CLOB,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      CURSOR c_2300
      IS
         SELECT *
           FROM cbs_hesap_basvuru_toplu_hes_is
          WHERE tx_no = pn_tx_no AND musteri_no = pn_customer_no;

      r_2300            c_2300%ROWTYPE;
      ls_acc_list_ENG   VARCHAR2 (32767);
      ls_acc_list_rus   VARCHAR2 (32767);
      ls_acc_list_kgz   VARCHAR2 (32767);
      ls_bic_code       VARCHAR2 (200);
      
   BEGIN
   select kayit_kullanici_bolum_kodu into ls_bic_code from cbs_islem where numara = PN_TX_NO;
   ls_bic_code := SF_GET_BRANCH_BIC(ls_bic_code);
      ls_acc_list_eng :=
            '<tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\"> - BIC : '
            || ls_bic_code;
      ls_acc_list_rus :=
            '<tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\"> - БИК : '
            || ls_bic_code;
      ls_acc_list_kgz := ls_acc_list_rus;
      OPEN c_2300;

      LOOP
         FETCH c_2300 INTO r_2300;
         EXIT WHEN c_2300%NOTFOUND;
         ls_acc_list_eng := ls_acc_list_eng
            || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2300.doviz_kodu || ' No.'
            || pkg_hesap.external_hesapno_al (r_2300.hesap_no)
            || '</td></tr>';
         ls_acc_list_rus :=
               ls_acc_list_rus
            || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2300.doviz_kodu || ' No.'
            || pkg_hesap.external_hesapno_al (r_2300.hesap_no)
            || '</td></tr>';
         ls_acc_list_kgz :=
               ls_acc_list_kgz
            || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2300.doviz_kodu || ' No.'
            || pkg_hesap.external_hesapno_al (r_2300.hesap_no)
            || '</td></tr>';
      END LOOP;

      CLOSE c_2300;

      --PS_SMS_BODY := 'Uvazhaemyi Klient, pozdravlyaem s otkrytiem bankovskogo scheta v DemirBank. Podrobnaya informaciya po nomeru:0(312) 610 613, 2222'; --cbs-454 bahianab
      PS_SMS_BODY := 'Pozdravlyaem s otkrytiem bankovskogo scheta.Tel:+996312610610'; --CBS-726 bahianab 230822
      PS_PUSH_BODY := PS_SMS_BODY; --cbs-454 bahianab
      PS_EMAIL_BODY := '{';
      PS_EMAIL_BODY := PS_EMAIL_BODY
         || '"##NAME_SURNAME_ENG##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_ENG##":"' || ls_acc_list_eng || '", '
         || '"##NAME_SURNAME_RUS##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_RUS##":"' || ls_acc_list_RUS || '", '
         || '"##NAME_SURNAME_KGZ##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_KGZ##":"' || ls_acc_list_KGZ 
         || '"}';
      RETURN '000';
      
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_2300_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   
   FUNCTION GENERATE_2000_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PN_EXTERNAL_ACC_NO in VARCHAR2,
      PS_EMAIL_BODY       OUT CLOB,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      CURSOR c_2000
      IS
         SELECT *
           FROM cbs_hesap_basvuru
          WHERE tx_no = pn_tx_no;

      r_2000            c_2000%ROWTYPE;
      ls_acc_list_ENG   VARCHAR2 (32767);
      ls_acc_list_rus   VARCHAR2 (32767);
      ls_acc_list_kgz   VARCHAR2 (32767);
      ls_bic_code       VARCHAR2 (200);
      ls_doviz_kod      VARCHAR2 (200);
      ln_hesap_no       number;
   BEGIN
   select kayit_kullanici_bolum_kodu into ls_bic_code from cbs_islem where numara = PN_TX_NO;
   ls_bic_code := SF_GET_BRANCH_BIC(ls_bic_code);
      ls_acc_list_eng :=
            '<tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\"> - BIC : '
            || ls_bic_code;
      ls_acc_list_rus :=
            '<tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\"> - БИК : '
            || ls_bic_code;
      ls_acc_list_kgz := ls_acc_list_rus;
      
      OPEN c_2000;

      LOOP
         FETCH c_2000 INTO r_2000;
         EXIT WHEN c_2000%NOTFOUND;
      ls_acc_list_eng :=
           ls_acc_list_ENG
        || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2000.doviz_kodu || ' No.'
        || pkg_hesap.external_hesapno_al (r_2000.hesap_numarasi)
        || '</td></tr>';
      ls_acc_list_rus :=
           ls_acc_list_rus
        || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2000.doviz_kodu || ' No.'
        || pkg_hesap.external_hesapno_al (r_2000.hesap_numarasi)
        || '</td></tr>';
      ls_acc_list_kgz :=
           ls_acc_list_kgz
        || '</td></tr><tr><td style=\"font: 14px/19px Arial, Helvetica, sans-serif; color: #333332;\">' || r_2000.doviz_kodu || ' No.'
        || pkg_hesap.external_hesapno_al (r_2000.hesap_numarasi)
        || '</td></tr>';
      END LOOP;

      CLOSE c_2000;

      --PS_SMS_BODY := 'Uvazhaemyi Klient, pozdravlyaem s otkrytiem bankovskogo scheta v DemirBank. Podrobnaya informaciya po nomeru:0(312) 610 613, 2222';
      PS_SMS_BODY := 'Pozdravlyaem s otkrytiem bankovskogo scheta.Tel:+996312610610'; --CBS-726 bahianab 230822
      PS_PUSH_BODY := PS_SMS_BODY;
      PS_EMAIL_BODY := '{';
      PS_EMAIL_BODY := PS_EMAIL_BODY
         || '"##NAME_SURNAME_ENG##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_ENG##":"' || ls_acc_list_eng || '", '
         || '"##NAME_SURNAME_RUS##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_RUS##":"' || ls_acc_list_RUS || '", '
         || '"##NAME_SURNAME_KGZ##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
         || '"##ACCOUNTS_KGZ##":"' || ls_acc_list_KGZ || '"}';
      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_2000_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;

FUNCTION GENERATE_2010_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PN_EXTERNAL_ACC_NO in VARCHAR2,
      PS_EMAIL_BODY       OUT CLOB,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2)
      RETURN VARCHAR2
   IS
      CURSOR c_2010
      IS
         SELECT *
           FROM cbs_yphavale_gelen_basvuru
          WHERE tx_no = pn_tx_no;

      r_2010            c_2010%ROWTYPE;
      ls_acc_list_ENG   VARCHAR2 (32767);
      ls_acc_list_rus   VARCHAR2 (32767);
      ls_acc_list_kgz   VARCHAR2 (32767);
      ls_doviz_kod      VARCHAR2 (200);
      ln_hesap_no       number;
   BEGIN
      OPEN c_2010;
      LOOP
         FETCH c_2010 INTO r_2010;
         EXIT WHEN c_2010%NOTFOUND;
         
         /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' na Vash schet ' || PKG_HESAP.EXTERNAL_HESAPNO_AL( r_2010.alici_hesap_no) ||
                            ' postupil denezhnyi perevod v inostrannoi valiute na summu ' || to_char(r_2010.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| r_2010.doviz_kodu|| '. Podrobnee v Internet-Bankinge'; */ 
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy poluchili perevod ' || to_char(r_2010.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| r_2010.doviz_kodu|| '.Tel+996312610610'; --CBS-726 bahianab 230822
         PS_PUSH_BODY := PS_SMS_BODY; --cbs-454 bahianab
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
             || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pn_customer_no) || '", '
             || '"##ACCOUNT_NO##":"' || PKG_HESAP.EXTERNAL_HESAPNO_AL( r_2010.alici_hesap_no) || '", '
             || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(r_2010.alici_hesap_no),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| r_2010.doviz_kodu || '", ' --cbs-454 bahianab  
             || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
             || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
             || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
             || '"##AMOUNT##":"' || to_char(r_2010.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| r_2010.doviz_kodu || '"}'; --cbs-454 bahianab 
         
      END LOOP;
      CLOSE c_2010;

      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_2010_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   
   FUNCTION GENERATE_2304_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PS_EMAIL_BODY       OUT VARCHAR2,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2)
      RETURN VARCHAR2 IS
      CURSOR c_1 IS
         SELECT * FROM cbs_debit_card_account_tran
          WHERE tx_no = pn_tx_no AND customer_no = pn_customer_no;

      r1       c_1%ROWTYPE;

      CURSOR cur_card IS
         SELECT * FROM cbs_debit_card_main_tran
          WHERE tx_no = pn_tx_no;

      r_card   cur_card%ROWTYPE;
   BEGIN
      NULL;
      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_2304_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;

   FUNCTION GENERATE_1001_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PS_EMAIL_BODY       OUT VARCHAR2,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2,
      PS_EMAILS           OUT VARCHAR2,
      PS_PHONES           OUT VARCHAR2)
      RETURN VARCHAR2 IS
      CURSOR cur_cust IS
         SELECT email, gsm_alan_kod || gsm_no
           FROM cbs_musteri_adres
          WHERE musteri_no = pn_customer_no;

      ls_cust_email           VARCHAR2 (200);
      ls_cust_tel             VARCHAR2 (200);

      CURSOR cur_cust_temp
      IS
         SELECT email, gsm_alan_kod || gsm_no
           FROM cbs_musteri_guncel_adres
          WHERE tx_no = pn_tx_no;

      ls_cust_email_temp      VARCHAR2 (200);
      ls_cust_tel_temp        VARCHAR2 (200);
      ls_upd_field_text_eng   VARCHAR2 (2000) := '';
      ls_upd_field_text_rus   VARCHAR2 (2000) := '';
      ls_upd_field_text_kgz   VARCHAR2 (2000) := '';
      ls_upd_field_text_sms   VARCHAR2 (2000) := '';
      ls_old_values           VARCHAR2 (2000) := '';
      ls_new_values           VARCHAR2 (2000) := '';
   BEGIN
      OPEN cur_cust;

      FETCH cur_cust INTO ls_cust_email, ls_cust_tel;

      CLOSE cur_cust;

      OPEN cur_cust_temp;

      FETCH cur_cust_temp INTO ls_cust_email_temp, ls_cust_tel_temp;

      CLOSE cur_cust_temp;

      IF     ls_cust_email <> ls_cust_email_temp
         AND ls_cust_tel <> ls_cust_tel_temp
      THEN
         ls_upd_field_text_eng := 'email and phone number';
         ls_upd_field_text_rus := 'email и номер телефона';
         ls_upd_field_text_kgz := 'email жана телефон номер';
         ls_upd_field_text_sms := 'email i nomer telefona';
         ls_old_values := ls_cust_email || ', ' || ls_cust_tel;
         ls_new_values := ls_cust_email_temp || ', ' || ls_cust_tel_temp;
         ps_emails := ls_cust_email || ',' || ls_cust_email_temp;
         ps_phones := '996' || ls_cust_tel || ',996' || ls_cust_tel_temp;
      ELSIF ls_cust_email <> ls_cust_email_temp
      THEN
         ls_upd_field_text_eng := 'email';
         ls_upd_field_text_rus := 'email';
         ls_upd_field_text_kgz := 'email';
         ls_upd_field_text_sms := 'email';
         ls_old_values := ls_cust_email;
         ls_new_values := ls_cust_email_temp;
         ps_emails := ls_cust_email || ',' || ls_cust_email_temp;
         ps_phones := '996' || ls_cust_tel;
      ELSIF ls_cust_tel <> ls_cust_tel_temp
      THEN
         ls_upd_field_text_eng := 'phone number';
         ls_upd_field_text_rus := 'номер телефона';
         ls_upd_field_text_kgz := 'телефон номер';
         ls_upd_field_text_sms := 'nomer telefona';
         ls_old_values := ls_cust_tel;
         ls_new_values := ls_cust_tel_temp;
         ps_phones := '996' || ls_cust_tel || ',996' || ls_cust_tel_temp;
         ps_emails := ls_cust_email;
      END IF;

      if ls_old_values <> '' or ls_old_values is not null then
          --Ps_sms_body := 'Uvazhaemyi Klient, Vy uspeshno pomenyali svoi ' || ls_upd_field_text_sms || '. Podrobnaya informaciya po nomeru:0(312) 610 613, 2222';
          Ps_sms_body := 'Vy pomenyali svoi ' || ls_upd_field_text_sms || '.Tel+996312610610'; --CBS-726 bahianab 230822
          PS_PUSH_BODY := PS_SMS_BODY;
          PS_EMAIL_BODY := '{';
          PS_EMAIL_BODY := PS_EMAIL_BODY
             || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pn_customer_no) || '", '
             || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
             || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
             || '"##UPDATED_FIELD_ENG##":"' || ls_upd_field_text_eng || '", '
             || '"##OLD_VALUE##":"' || ls_old_values || '", '
             || '"##NEW_VALUE##":"' || ls_new_values || '", '
             || '"##UPDATED_FIELD_RUS##":"' || ls_upd_field_text_rus || '", '
             || '"##UPDATED_FIELD_KGZ##":"' || ls_upd_field_text_kgz || '"}';
          RETURN '000';
      else
          return '001';
      end if;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_1001_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;

   FUNCTION GENERATE_2150_NOT (
      PN_TX_NO         IN     NUMBER,
      PN_CUSTOMER_NO   IN     CBS_MUSTERI.MUSTERI_NO%TYPE,
      PS_EMAIL_BODY       OUT CLOB,
      PS_SMS_BODY         OUT VARCHAR2,
      PS_PUSH_BODY        OUT VARCHAR2)
      RETURN VARCHAR2 IS
      CURSOR cur_salary IS
         SELECT * FROM cbs_salary_detail_islem
          WHERE     tx_no = pn_tx_no
                AND PKG_HESAP.HESAPTANMUSTERINOAL (STAFF_ACCOUNT_NO) = PN_CUSTOMER_NO;

      r_salary   cur_salary%ROWTYPE;
   BEGIN
      OPEN cur_salary;

      LOOP
         FETCH cur_salary INTO r_salary;
         EXIT WHEN cur_salary%NOTFOUND;
         /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' vash schet ' || PKG_HESAP.EXTERNAL_HESAPNO_AL( R_SALARY.STAFF_ACCOUNT_NO) || ' popolnen na summu ' || 
                        to_char(R_SALARY.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| R_SALARY.CURRENCY_CODE || '. Balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(R_SALARY.STAFF_ACCOUNT_NO),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| R_SALARY.CURRENCY_CODE|| ' 00996312610613, 2222';*/
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Schet popolnen na ' || to_char(R_SALARY.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| R_SALARY.CURRENCY_CODE || '.Tel+996312610610'; --CBS-726 bahianab 230822
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || PKG_HESAP.EXTERNAL_HESAPNO_AL( R_SALARY.STAFF_ACCOUNT_NO ) || '", '
            || '"##AMOUNT##":"' || to_char(R_SALARY.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') || ' ' || R_SALARY.CURRENCY_CODE || '", '  --cbs-454 bahianab
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL (R_SALARY.STAFF_ACCOUNT_NO),'FM999G999G999G999G999G999G999G999G999D00') || '", ' --cbs-454 bahianab
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
            || '"##TRAN_DESC_RU##":"' || 'перевод заработной платы' || '", '
            --|| '"##OTHER_NAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL (R_SALARY.COMPANY_ACCOUNT_NO)) || '", ' 
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '", '
            || '"##TRAN_DESC_KG##":"' || 'айлык акыны которуу' || '", '
            --|| '"##OTHER_NAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL (R_SALARY.COMPANY_ACCOUNT_NO)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pn_customer_no) || '", '
            || '"##TRAN_DESC_EN##":"' || 'salary transfer' || '"}';
            --|| '"##OTHER_NAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL (R_SALARY.COMPANY_ACCOUNT_NO)) || '"}';
      END LOOP;
      
      close cur_salary;

      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_2150_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;

   FUNCTION GENERATE_6200_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      CURSOR CUR_6200 IS SELECT * FROM CBS_CARI_NAKIT_YATAN_ISLEM WHERE TX_NO = PN_TX_NO;
      REC_6200 CUR_6200%ROWTYPE;
   begin
      OPEN CUR_6200;

      LOOP
         FETCH CUR_6200 INTO REC_6200;
         EXIT WHEN CUR_6200%NOTFOUND;
         if rec_6200.THIRD_PERSON_NAME is null then
             /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' vy popolnili svoi schet ' || PKG_HESAP.External_HesapNo_Al(REC_6200.hesap_no) || ' na summu ' || 
                            to_char(REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || ' cherez kassu DKIB. Balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(REC_6200.hesap_no),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_6200.doviz_kodu|| ' 00996312610613, 2222';*/
             PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili schet na '|| to_char(REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || '.Tel+996312610610'; --CBS-726 bahianab 230822
             PS_PUSH_BODY := PS_SMS_BODY;
             PS_EMAIL_BODY := '{';
             PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##ACCOUNT_NO##":"' || PKG_HESAP.External_HesapNo_Al(REC_6200.hesap_no) || '", '
                || '"##AMOUNT##":"' || to_char(REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || '", ' --cbs-454 bahianab
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL (REC_6200.hesap_no), 'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_6200.doviz_kodu || '", ' --cbs-454 bahianab
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (REC_6200.musteri_no) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (REC_6200.musteri_no) || '", '
                || '"##TEXT_RU##":"Вы пополнили свой счет", '
                || '"##TEXT_EN_1##":"you replenished your account", '
                || '"##TEXT_EN_2##":"", '
                || '"##TEXT_KG_1##":"эсебинизди", '
                || '"##TEXT_KG_2##":"толуктаганынызды ", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (REC_6200.musteri_no) || '"}';
         else
             /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' vash schet ' || PKG_HESAP.External_HesapNo_Al(REC_6200.hesap_no) || ' popolnen na summu ' || 
                            to_char(REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || ' cherez kassu DKIB. Balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(REC_6200.hesap_no),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_6200.doviz_kodu|| ' 00996312610613, 2222';*/
             PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Schet popolnen na '|| to_char(REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || '.Tel+996312610610';--CBS-726 bahianab 230822
             PS_PUSH_BODY := PS_SMS_BODY;
             PS_EMAIL_BODY := '{';
             PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##ACCOUNT_NO##":"' || PKG_HESAP.External_HesapNo_Al(REC_6200.hesap_no) || '", '
                || '"##AMOUNT##":"' || to_char (REC_6200.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_6200.doviz_kodu || '", ' --cbs-454 bahianab
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL (REC_6200.hesap_no),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_6200.doviz_kodu || '", ' --cbs-454 bahianab
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (REC_6200.musteri_no) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (REC_6200.musteri_no) || '", '
                || '"##TEXT_RU##":"Вам пополнили счет", '
                || '"##TEXT_EN_1##":"your account", '
                || '"##TEXT_EN_2##":"was replenished ", '
                || '"##TEXT_KG_1##":"эсебиниздин", '
                || '"##TEXT_KG_2##":"толукталганын ", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (REC_6200.musteri_no) || '"}';
         end if;
      END LOOP;
      close cur_6200;

      RETURN '000';
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_6200_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
   
   FUNCTION GENERATE_1203_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      CURSOR CUR_1203 IS SELECT * FROM CBS_VIRMAN_ISLEM WHERE TX_NO = PN_TX_NO;
      REC_1203 CUR_1203%ROWTYPE;
   begin
      OPEN CUR_1203;

      LOOP
         FETCH CUR_1203 INTO REC_1203;
         EXIT WHEN CUR_1203%NOTFOUND;
         /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' na vash schet ' || REC_1203.ALACAK_EXTERNAL_HESAP || ' postupil denezhnyi perevod v summe ' || 
                            to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_1203.doviz_kodu||'. Balans sostavlyaet '|| to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_1203.ALACAK_EXTERNAL_HESAP, REC_1203.doviz_kodu)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu || '. Podrobnee v Internet-Bankinge';*/
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy poluchili perevod ' || to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_1203.doviz_kodu||'.Tel+996312610610'; --CBS-726 bahianab 230822
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || REC_1203.ALACAK_EXTERNAL_HESAP || '", '
            || '"##AMOUNT##":"' || to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_1203.doviz_kodu || '", '  --cbs-454 bahianab
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_1203.ALACAK_EXTERNAL_HESAP, REC_1203.doviz_kodu)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu || '", ' --cbs-454 bahianab
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.ALACAK_EXTERNAL_HESAP)) || '", '
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.ALACAK_EXTERNAL_HESAP)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.ALACAK_EXTERNAL_HESAP)) || '"}';
      END LOOP;
      close cur_1203;

      RETURN '000';
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_1203_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
   /*BOM bahianab CBS-562 09122021*/
   FUNCTION GENERATE_1203_OUT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      CURSOR CUR_1203 IS SELECT * FROM CBS_VIRMAN_ISLEM WHERE TX_NO = PN_TX_NO;
      REC_1203 CUR_1203%ROWTYPE;
   begin
      OPEN CUR_1203;

      LOOP
         FETCH CUR_1203 INTO REC_1203;
         EXIT WHEN CUR_1203%NOTFOUND;
         /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy uspeshno osushestvili perevod na summu '||to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu||' so svoego scheta ' || REC_1203.BORC_EXTERNAL_HESAP ||' '|| REC_1203.doviz_kodu||' na schet '|| REC_1203.ALACAK_EXTERNAL_HESAP ||' '|| REC_1203.doviz_kodu
            || '. Balans sostavlyaet '|| to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_1203.BORC_EXTERNAL_HESAP, REC_1203.doviz_kodu)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu || '. Podrobnee v Internet-Bankinge';*/ 
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy osushestvili perevod '||to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu||'.Tel+996312610610'; --CBS-726 bahianab 230822
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || REC_1203.BORC_EXTERNAL_HESAP || '", '
            || '"##REC_ACCOUNT_NO##":"' || REC_1203.ALACAK_EXTERNAL_HESAP || '", '
            || '"##AMOUNT##":"' || to_char(REC_1203.tutar,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_1203.doviz_kodu || '", ' 
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_1203.BORC_EXTERNAL_HESAP, REC_1203.doviz_kodu)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_1203.doviz_kodu || '", ' 
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.BORC_EXTERNAL_HESAP)) || '", '
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.BORC_EXTERNAL_HESAP)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_1203.BORC_EXTERNAL_HESAP)) || '"}';
      END LOOP;
      close cur_1203;

      RETURN '000';
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_1203_OUT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
   /*EOM bahianab CBS-562 09122021*/
   FUNCTION GENERATE_3556_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      CURSOR CUR_3556 IS SELECT * FROM CBS_CLEARING_ISLEM WHERE TX_NO = PN_TX_NO;
      REC_3556 CUR_3556%ROWTYPE;
   begin
      OPEN CUR_3556;

      LOOP
         FETCH CUR_3556 INTO REC_3556;
         EXIT WHEN CUR_3556%NOTFOUND;
         /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' na vash schet ' || REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER || ' postupil denezhnyi perevod v summe ' || 
                            to_char(REC_3556.amount,'FM999G999G999G999G999G999G999G999G999D00') || ' KGS. Balans sostavlyaet '||to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER, 'KGS')),'FM999G999G999G999G999G999G999G999G999D00')|| ' KGS. Podrobnee v Internet-Bankinge';*/
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy poluchili perevod ' || to_char(REC_3556.amount,'FM999G999G999G999G999G999G999G999G999D00') || ' KGS.Tel+996312610610'; --CBS-726 bahianab 230822
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER || '", '
            || '"##AMOUNT##":"' || to_char(REC_3556.amount,'FM999G999G999G999G999G999G999G999G999D00') || ' KGS", ' --cbs-454 bahianab
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER, 'KGS')),'FM999G999G999G999G999G999G999G999G999D00')|| ' KGS' || '", ' --cbs-454 bahianab
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER)) || '", '
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_3556.TO_ACCOUNT_EXTERNAL_NUMBER)) || '"}';
      END LOOP;
      close CUR_3556;

      RETURN '000';
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_3556_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
   
   FUNCTION GENERATE_8800_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no;
      rec_fin cur_fin%rowtype;
      ls_merchant_location varchar2(2000);
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           ls_merchant_location := replace(replace(replace(rec_fin.MERCHANT_LOCATION, ' ', ' _'), '_ '), '_');
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vasha karta ' || rec_fin.card_number || ' ispolzovana v ATM: ' || 
             to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ', ' || ls_merchant_location --cbs-454 bahianab
             || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy obnalichili ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel+996312610610';--CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
             || '"##CARD_NUMBER##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
             || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
             || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
             || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
             || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
             || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
             || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
             || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8800_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
/*BOM BAHIANAB 03022022 Notification for QR CASH WITHDRAWAL*/
   FUNCTION GENERATE_8800_QR (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no and tran_code = 0509;
      rec_fin cur_fin%rowtype;
      ls_merchant_location varchar2(2000);
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           ls_merchant_location := replace(replace(replace(rec_fin.MERCHANT_LOCATION, ' ', ' _'), '_ '), '_');
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vash schet ' || pkg_hesap.external_hesapno_al (rec_fin.FROM_ACCOUNT_NUMBER)|| ' ispolzovan v ATM: ' || 
             to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ', ' || ls_merchant_location 
             || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/ 
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy obnalichili ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel+996312610610'; --CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
             || '"##ACCOUNT_NO##":"' || pkg_hesap.external_hesapno_al (rec_fin.FROM_ACCOUNT_NUMBER) ||'", '
             || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' 
             || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' 
             || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
             || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
             || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
             || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
             || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8800_QR',SQLERRM,dbms_utility.format_error_backtrace);
   end;   
/*EOM BAHIANAB 03022022 Notification for QR CASH WITHDRAWAL*/   
FUNCTION GENERATE_8806_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no and nvl(FROM_ACCOUNT_NUMBER, 0) = 0;
      rec_fin cur_fin%rowtype;
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili svoiu kartu DKIB ' || replace(rec_fin.card_number, 'X', '*') || ' na summu ' ||
                to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' v ' || rec_fin.MERCHANT_LOCATION  --cbs-454 bahianab
                || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/ 
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili kartu na ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel+996312610610'; --CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##CARD_NO##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                || '"##ACCOUNT_NO##":"' || rec_fin.TO_ACCOUNT_NUMBER || '", '
                || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##MERCHANT_PLACE##":"' || rec_fin.MERCHANT_LOCATION || '", '
                || '"##COUNTRY_RU##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_KG##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_EN##":"' || pkg_genel.ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8806_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
/*BOM BAHIANAB 03022022 Notification for QR CASH-IN TRX*/ 
   FUNCTION GENERATE_8806_QR (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no and nvl(FROM_ACCOUNT_NUMBER, 0) = 0 and tran_code = 0511;
      rec_fin cur_fin%rowtype;
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili svoi schet DKIB ' || pkg_hesap.external_hesapno_al (rec_fin.TO_ACCOUNT_NUMBER) || ' na summu ' ||
                to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' v ' || rec_fin.MERCHANT_LOCATION 
                || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/ 
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili schet na ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel+996312610610'; --CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##ACCOUNT_NO##":"' || pkg_hesap.external_hesapno_al (rec_fin.TO_ACCOUNT_NUMBER) || '", '
                || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' 
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER) || '", ' 
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##MERCHANT_PLACE##":"' || rec_fin.MERCHANT_LOCATION || '", '
                || '"##COUNTRY_RU##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_KG##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_EN##":"' || pkg_genel.ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8806_QR',SQLERRM,dbms_utility.format_error_backtrace);
   end;
/*EOM BAHIANAB 03022022 Notification for QR CASH-IN TRX*/    
   FUNCTION GENERATE_8807_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no;
      rec_fin cur_fin%rowtype;
      ls_merchant_location varchar2(2000);
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
               ls_merchant_location := replace(replace(replace(rec_fin.MERCHANT_LOCATION, ' ', ' _'), '_ '), '_');
               /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy uspeshno oplatili kartoi DKIB ' ||
                    to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' cherez POS terminal v ' || ls_merchant_location --cbs-454 bahianab
                    || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/
               PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy oplatili ' ||to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||' v POS.Tel:+996312610610'; --CBS-726 bahianab 230822
               PS_PUSH_BODY := PS_SMS_BODY;
               PS_EMAIL_BODY := '{';
               PS_EMAIL_BODY := PS_EMAIL_BODY
                    || '"##CARD_NUMBER##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                    || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
                    || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
                    || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                    || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
                    || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8807_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
   
   FUNCTION GENERATE_8821_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no;
      rec_fin cur_fin%rowtype;
      ls_merchant_location varchar2(2000);
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           ls_merchant_location := replace(replace(replace(rec_fin.MERCHANT_LOCATION, ' ', ' _'), '_ '), '_');
           if instr(rec_fin.MERCHANT_LOCATION, 'KG') > 0 then
               /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy uspeshno oplatili kartoi DKIB ' ||
                    to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' cherez POS terminal v ' || ls_merchant_location --cbs-454 bahianab
                    || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00')||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/
               PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy oplatili ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||' v POS.Tel:+996312610610'; --CBS-726 bahianab 230822
               PS_PUSH_BODY := PS_SMS_BODY;
               PS_EMAIL_BODY := '{';
               PS_EMAIL_BODY := PS_EMAIL_BODY
                    || '"##CARD_NUMBER##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                    || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
                    || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
                    || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                    || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
                    || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
           else
               PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy oplatili ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||' v POS.Tel:+996312610610'; --CBS-726 bahianab 230822
               PS_PUSH_BODY := PS_SMS_BODY;
               PS_EMAIL_BODY := '{';
               PS_EMAIL_BODY := PS_EMAIL_BODY
                    || '"##CARD_NUMBER##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                    || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
                    || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
                    || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                    || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
                    || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                    || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
           end if;
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8821_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end; 
   
   FUNCTION GENERATE_8826_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no;
      rec_fin cur_fin%rowtype;
      ls_merchant_location varchar2(2000);
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           ls_merchant_location := replace(replace(replace(rec_fin.MERCHANT_LOCATION, ' ', ' _'), '_ '), '_');
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy uspeshno oplatili kartoi DKIB ' ||
                to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' v ' || ls_merchant_location  --cbs-454 bahianab
                || ' Vash balans sostavlyaet '|| to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '||  PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy oplatili kartoi ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel:+996312610610'; --CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##CARD_NUMBER##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' --cbs-454 bahianab
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.FROM_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.FROM_ACCOUNT_NUMBER) || '", ' --cbs-454 bahianab
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##MERCHANT_LOCATION##":"' || ls_merchant_location || '", '
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.FROM_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8826_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
  
  FUNCTION GENERATE_7000_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
     RETURN VARCHAR2 is
    CURSOR CUR_7000 IS SELECT * FROM CBS_IPC_QR_PAYMENTS WHERE TX_NO = PN_TX_NO;
      REC_7000 CUR_7000%ROWTYPE;
   BEGIN
      OPEN CUR_7000;

      LOOP
         FETCH CUR_7000 INTO REC_7000;
         EXIT WHEN CUR_7000%NOTFOUND;
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy poluchili perevod ' || to_char(REC_7000.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_7000.CURRENCY||'.Tel+996312610610'; 
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || REC_7000.EXTERNAL_ACCOUNT || '", '
            || '"##SENDER##":"' || REC_7000.RECIPIENT || '", '
            || '"##AMOUNT##":"' || to_char(REC_7000.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_7000.CURRENCY || '", '  
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_7000.EXTERNAL_ACCOUNT, REC_7000.CURRENCY)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_7000.CURRENCY || '", ' 
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '", '
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '"}';
      END LOOP;
      close CUR_7000;

      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_7000_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   
   FUNCTION GENERATE_7000_OUT (PN_TX_NO IN NUMBER,
                               PN_CUSTOMER_NO IN CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY OUT CLOB,
                               PS_SMS_BODY OUT VARCHAR2,
                               PS_PUSH_BODY OUT VARCHAR2)
    RETURN VARCHAR2 is
     CURSOR CUR_7000 IS SELECT * FROM CBS_IPC_QR_PAYMENTS WHERE TX_NO = PN_TX_NO;
      REC_7000 CUR_7000%ROWTYPE;
   BEGIN
      OPEN CUR_7000;

      LOOP
         FETCH CUR_7000 INTO REC_7000;
         EXIT WHEN CUR_7000%NOTFOUND;
         PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy osushestvili perevod '||to_char(REC_7000.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_7000.CURRENCY||'.Tel+996312610610'; 
         PS_PUSH_BODY := PS_SMS_BODY;
         PS_EMAIL_BODY := '{';
         PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##ACCOUNT_NO##":"' || REC_7000.EXTERNAL_ACCOUNT || '", '
            || '"##RECIPIENT##":"' || REC_7000.RECIPIENT || '", '
            || '"##AMOUNT##":"' || to_char(REC_7000.AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_7000.CURRENCY || '", ' 
            || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
            || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(pkg_hesap.GetHesapNoFromExternal(REC_7000.EXTERNAL_ACCOUNT, REC_7000.CURRENCY)),'FM999G999G999G999G999G999G999G999G999D00')||' '|| REC_7000.CURRENCY || '", ' 
            || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '", '
            || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '", '
            || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (pkg_hesap.GetMusteriNoFromExternal(REC_7000.EXTERNAL_ACCOUNT)) || '"}';
      END LOOP;
      close CUR_7000;

      RETURN '000';
      EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_7000_OUT',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   
   /******************************************************************************
    NAME :         SP_PACK_OPS_UPD
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Used when changing package's content of notifications list
    ******************************************************************************/
   PROCEDURE SP_PACK_OPS_UPD (pn_tx_no IN NUMBER)
   IS
      ls_branch_code        VARCHAR2 (3);
      baglam_yaratilamadi   EXCEPTION;
   BEGIN
      INSERT INTO cbs_notif_packages_tx
           SELECT pn_tx_no, p.*
             FROM cbs_notif_packages p
         ORDER BY id ASC;

      INSERT INTO cbs_notif_pack_ops_tx
           SELECT pn_tx_no, p.*
             FROM cbs_notif_pack_ops p
         ORDER BY package_id, operation_id;

      INSERT INTO cbs_notif_ops_list_tx
           SELECT pn_tx_no, p.id, P.OPERATION_NAME, P.OPERATION_DESC, P.ABLE_TO_UNSUBSCRIBE, P.SCREENS
             FROM cbs_notif_ops_list p
         ORDER BY id;

   EXCEPTION
      WHEN baglam_yaratilamadi
      THEN
         RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getUCPOINTER || '425' || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
      WHEN OTHERS
      THEN
         RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getUCPOINTER || '105' || Pkg_Hata.getDelimiter || TO_CHAR (SQLCODE) || SQLERRM || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
         log_at('SMS_NOTIF','SP_PACK_OPS_UPD',SQLERRM,dbms_utility.format_error_backtrace);
   END;

   /******************************************************************************
    NAME :         SF_CUST_OP_UNSUB
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Unsubscribes from chosen notification
    ******************************************************************************/
   FUNCTION SF_CUST_OP_UNSUB (PN_CUSTOMER_NO     NUMBER,
                              PN_OPERATION_ID    NUMBER,
                              PB_EMAIL           BOOLEAN,
                              PB_SMS             BOOLEAN,
                              PB_PUSH            BOOLEAN)
      RETURN VARCHAR2 IS
      LS_UNSUB   VARCHAR2 (1);
   BEGIN
      SELECT ABLE_TO_UNSUBSCRIBE
        INTO LS_UNSUB
        FROM CBS_NOTIF_OPS_LIST
       WHERE ID = PN_OPERATION_ID;

      IF LS_UNSUB = 'Y'
      THEN
         IF PB_SMS
         THEN
            UPDATE CBS_CUST_PACK_OPS
               SET SMS_NOTIFICATION = 'N'
             WHERE     customer_no = pn_customer_no
                   AND operation_id = PN_OPERATION_ID;
         END IF;

         IF PB_PUSH
         THEN
            UPDATE CBS_CUST_PACK_OPS
               SET PUSH_NOTIFICATION = 'N'
             WHERE     customer_no = pn_customer_no
                   AND operation_id = PN_OPERATION_ID;
         END IF;

         IF PB_EMAIL
         THEN
            UPDATE CBS_CUST_PACK_OPS
               SET EMAIL_NOTIFICATION = 'N'
             WHERE     customer_no = pn_customer_no
                   AND operation_id = PN_OPERATION_ID;
         END IF;
      END IF;

      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RAISE_APPLICATION_ERROR (-201000, Pkg_Hata.getUCPOINTER || '105' || Pkg_Hata.getDelimiter || TO_CHAR (SQLCODE) || SQLERRM || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
         log_at('SMS_NOTIF','SF_CUST_OP_UNSUB',SQLERRM,dbms_utility.format_error_backtrace);
   END;

   /******************************************************************************
    NAME :         SF_CUST_PACK_RESET
    Prepared By :  Nurzalat Alimzhan uulu
    Date :         07.05.2019
    Purpose :      Reset notification list for customer subscription
    ******************************************************************************/
   FUNCTION SF_CUST_PACK_RESET (PN_CUSTOMER_NO NUMBER)
      RETURN VARCHAR2 IS
   BEGIN
      UPDATE cbs_musteri
         SET notif_pack = 1
       WHERE musteri_no = pn_customer_no;

      DELETE FROM cbs_cust_pack_ops
            WHERE customer_no = pn_customer_no;

      INSERT INTO cbs_cust_pack_ops
         (SELECT pn_customer_no, o.*
            FROM cbs_notif_pack_ops o
           WHERE package_id = 1);

      RETURN '000';
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN '999';
         log_at('SMS_NOTIF','SF_CUST_PACK_RESET',SQLERRM,dbms_utility.format_error_backtrace);
   END;
   FUNCTION SF_GET_BRANCH_BIC (PS_BRANCH_CODE VARCHAR2)
    RETURN VARCHAR2 IS
    LS_RET VARCHAR2(6);
   BEGIN
        if ps_branch_code = '001' then ls_ret := '118001';
        elsif ps_branch_code = '010' then ls_ret := '118005';
        else ls_ret := '1180' || substr(ps_branch_code, 1, 2);
        end if;
        return ls_ret;
   END;
   
     /******************************************************************************
    NAME :         ACC_DAILY_NOTIF
    Prepared By :  Bahiana Bektemir kyzy
    Date :         16.11.2020
    Purpose :      Account Daily Notification
   ******************************************************************************/
    PROCEDURE ACC_DAILY_NOTIF(PN_ACCOUNT_NO NUMBER) IS
    
            CURSOR C_FIS IS
            SELECT FIS_NUMARA, FIS_ACIKLAMA, FIS_ISLEM_NUMARA,
                          FIS_YARATILDIGI_TARIH, FIS_YARATILDIGI_BANKA_TARIH,
                          FIS_MUHASEBELESTIGI_TARIH, FIS_TUR, SATIR_NUMARA,
                          SATIR_HESAP_NUMARA, SATIR_LC_TUTAR, SATIR_DV_TUTAR,
                          SATIR_DOVIZ_KOD, SATIR_BANKA_ACIKLAMA, SATIR_MUSTERI_ACIKLAMA,
                          SATIR_MUSTERI_HESAP_NUMARA, MUSTERI_NO,
                          NVL(PKG_PASSBOOK.HAREKETLIBAKIYEHESAPLA(SATIR_HESAP_NUMARA,FIS_NUMARA,SATIR_NUMARA),0) SON_BAKIYE
            FROM CBS_VW_FIS_SATIR_VSZIZ A
            WHERE SATIR_HESAP_NUMARA = TO_CHAR(PN_ACCOUNT_NO)
            AND FIS_TUR = 'G'
            AND  FIS_MUHASEBELESTIGI_TARIH =PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL --bahianab cbs-649
            ORDER BY A.FIS_YARATILDIGI_TARIH, A.FIS_NUMARA, A.SATIR_NUMARA;
            
    r_fis c_fis%rowtype;
    ls_email_body clob := '';
    ls_push_body varchar2(250) := '';
    ls_sms_body varchar2(250) := '';
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; --bahianab cbs-113 
    LS_SUB_RES varchar2(3);
    ls_res varchar2(3);
    lb_email boolean;
    lb_sms boolean;
    lb_push boolean;
    ls_not_lang varchar2(3);
    LS_RET varchar2(3);

    ln_customer_no number;
    ln_external_acc varchar2(26);
    ln_branch_no varchar2(200);
    ln_branch_bic_no varchar2(200); --CBS-451 AntonPa 04.08.2021    
    ld_date_interval varchar2(2000);
    ld_prev_bank_date varchar2(2000); --bahianab CBS-649 01042022 
    ln_opening_balance number;
    ln_closing_balance number;
    lc_table CLOB:='';  --CBS-451 AntonPa 04.08.2021
    ls_row varchar2(32767);
    ln_i number := 0;
    ln_balance_after number;
    ln_tutar number;
    ln_rownum number;
    ln_banka_aciklama varchar2(2000);
     
     BEGIN

     ln_rownum := 0;
     ln_customer_no := PKG_HESAP.HESAPTANMUSTERINOAL(pn_account_no);
     ln_external_acc := PKG_HESAP.EXTERNAL_HESAPNO_AL(pn_account_no);
     lc_table := '<table style=''border-collapse:collapse;'' width=''570'' border=''0'' cellspacing=''0'' cellpadding=''0'' align=''center'' style=''border-''><tr><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Date</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Explanation</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Amount</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Balance</b></td></tr>';
     ld_date_interval := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL; --cbs-649
     ln_branch_no := PKG_HESAP.HESAPTANSUBEAL(pn_account_no);
     ln_branch_bic_no := sf_get_branch_bic(ln_branch_no); --CBS-451 AntonPa 04.08.2021
     LS_SUB_RES := sf_check_sub(ln_customer_no, 5, lb_email, lb_sms, lb_push, ls_not_lang);
     l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1); --bahianab cbs-113
     ld_prev_bank_date := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL ; --bahianab CBS-649 01042022
     
     IF LS_SUB_RES = '000' then
        IF lb_email THEN
            ls_email_body := ls_email_body || '{' ||
                                '"##TITLE_1##":"Customer Name","##NAME_SURNAME##":"' || PKG_MUSTERI.Sf_Musteri_Eng_Adi(ln_customer_no) || '",' ||
                                '"##TITLE_2##":"Customer Number","##CUSTOMER_NO##":"' || ln_customer_no || '",' ||
                                '"##TITLE_3##":"Account Number","##ACCOUNT_NO##":"' || PKG_HESAP.HESAPTANDOVIZKODUAL(pn_account_no) || ', ' || pn_account_no || '",' ||--CBS-451 AntonPa 04.08.2021
                                '"##TITLE_4##":"External Number","##EXT_ACCOUNT_NO##":"' || ln_external_acc || '",' ||
                                '"##TITLE_5##":"Account Branch","##BRANCH_NO##":"' || ln_branch_bic_no || ' ' || replace(PKG_GENEL.BOLUM_ADI_AL(ln_branch_no), '"', '') || '",' ||--CBS-451 AntonPa 04.08.2021
                                '"##TITLE_6##":"Date","##DATE_INTERVAL##":"' || to_char(PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL, 'DD/MM/YYYY') || '",'; --bahianab cbs-649
                                
            OPEN c_fis;
            LOOP
                FETCH c_fis INTO r_fis;
                EXIT WHEN c_fis%NOTFOUND;
                ln_i := ln_i + 1;
                
                if (r_fis.SATIR_DOVIZ_KOD ='KGS') then ln_tutar := r_fis.SATIR_LC_TUTAR; else ln_tutar := r_fis.SATIR_DV_TUTAR; end if;
                                
                ln_balance_after:= r_fis.SON_BAKIYE; --ANTONPA 23.09.21
                
                if (ln_rownum=0) then
                    ln_opening_balance:=ln_tutar*(-1)+r_fis.SON_BAKIYE; --23.09.21
                end if;
                
                ln_banka_aciklama:= r_fis.satir_musteri_aciklama;
                
                if mod(ln_i, 2) = 0 then
                    ls_row := '<tr><td bgcolor=''f9f9f9'' style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(r_fis.FIS_YARATILDIGI_TARIH, 'DD/MM/YYYY')||'</td><td bgcolor=''f9f9f9'' style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ln_banka_aciklama||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_tutar,'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_balance_after,'FM999G999G999G999G999G999G999G999G990D00')|| ' ' ||r_fis.satir_doviz_kod||'</td></tr>';  --CBS-451 AntonPa 04.08.2021
                else
                    ls_row := '<tr><td style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(r_fis.FIS_YARATILDIGI_TARIH, 'DD/MM/YYYY')||'</td><td style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ln_banka_aciklama||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_tutar,'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_balance_after,'FM999G999G999G999G999G999G999G999G990D00')|| ' ' ||r_fis.satir_doviz_kod||'</td></tr>';  --CBS-451 AntonPa 04.08.2021
                end if;
                lc_table := lc_table || ls_row;
                ln_rownum := ln_rownum+1;
            end loop;
            lc_table := lc_table || '</table>';
            ls_email_body := ls_email_body || '"##TITLE_7##":"Opening Balance","##OPENING_BALANCE##":"' || to_char(ln_opening_balance,'FM999G999G999G999G999G999G999G999G990D00') || '",'; --CBS-451 AntonPa 04.08.2021
            ls_email_body := ls_email_body || '"##TITLE_8##":"Closing Balance","##CLOSING_BALANCE##":"' || to_char (ln_balance_after,'FM999G999G999G999G999G999G999G999G990D00') || '",'; --CBS-451 AntonPa 04.08.2021
            ls_email_body := ls_email_body || '"##TABLE##":"' || lc_table || '"}';
            l_recipients(1) := SF_GET_CUST_EMAIL (ln_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(LS_EMAIL_BODY, 'Daily Account Statement', 'info@demirbank.kg',l_recipients, 'HTML', 'notif_statement',null,null, ld_prev_bank_date); --bahianab CBS-649 01042022 --bahianab cbs-113            
        END IF;
        IF lb_sms THEN
            --ls_sms_body := 'Vy poluchili email s otchetom vashego scheta ' || ln_external_acc || '.'|| ' 00996312610613, 2222';
            ls_sms_body := 'Vy poluchili email s otchetom vashego scheta.Tel:+996312610610'; --CBS-726 bahianab 230822
            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
        END IF;
        IF lb_push THEN
            ls_push_body := ls_sms_body; --CBS-726 bahianab 230822      
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
        END IF;
     END IF;
     
     EXCEPTION
         WHEN OTHERS THEN
         log_at('SMS_NOTIF','ACC_DAILY_NOTIF',SQLERRM ||' '|| TO_CHAR(PN_ACCOUNT_NO),dbms_utility.format_error_backtrace); --ANTONPA 23.09.21
    END;

  /******************************************************************************
    NAME :         ACC_MONTHLY_NOTIF
    Prepared By :  Bahiana Bektemir kyzy
    Date :         16.11.2020
    Purpose :      Account Monthly Notification
 ******************************************************************************/
    PROCEDURE ACC_MONTHLY_NOTIF(PN_ACCOUNT_NO NUMBER) IS

           CURSOR C_FIS IS
            SELECT FIS_NUMARA, FIS_ACIKLAMA, FIS_ISLEM_NUMARA,
                          FIS_YARATILDIGI_TARIH, FIS_YARATILDIGI_BANKA_TARIH,
                          FIS_MUHASEBELESTIGI_TARIH, FIS_TUR, SATIR_NUMARA,
                          SATIR_HESAP_NUMARA, SATIR_LC_TUTAR, SATIR_DV_TUTAR,
                          SATIR_DOVIZ_KOD, SATIR_BANKA_ACIKLAMA, SATIR_MUSTERI_ACIKLAMA,
                          SATIR_MUSTERI_HESAP_NUMARA, MUSTERI_NO,
                          NVL(PKG_PASSBOOK.HAREKETLIBAKIYEHESAPLA(SATIR_HESAP_NUMARA,FIS_NUMARA,SATIR_NUMARA),0) SON_BAKIYE
            FROM CBS_VW_FIS_SATIR_VSZIZ A
            WHERE SATIR_HESAP_NUMARA = TO_CHAR(PN_ACCOUNT_NO)
            AND FIS_TUR = 'G'
            AND  FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE('01'||TO_CHAR(PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL, 'MMYYYY'), 'DDMMYYYY') AND PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL --bahianab cbs-649
            ORDER BY A.FIS_YARATILDIGI_TARIH, A.FIS_NUMARA, A.SATIR_NUMARA;
                
    r_fis c_fis%rowtype;
    ls_email_body clob := '';
    ls_push_body varchar2(250) := '';
    ls_sms_body varchar2(250) := '';
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; --bahianab cbs-113
    LS_SUB_RES varchar2(3);
    ls_res varchar2(3);
    lb_email boolean;
    lb_sms boolean;
    lb_push boolean;
    ls_not_lang varchar2(3);
    LS_RET varchar2(3);

    ln_customer_no number;
    ln_external_acc varchar2(26);
    ln_branch_no varchar2(200);
    ln_branch_bic_no varchar2(200);  --CBS-451 AntonPa 04.08.2021    
    ld_date_interval varchar2(2000);
    ld_prev_bank_date varchar2(2000); --bahianab CBS-649 01042022 
    ln_opening_balance number;
    ln_closing_balance number;
    lc_table CLOB:='';  --CBS-451 AntonPa 04.08.2021
    ls_row varchar2(32767);
    ln_i number := 0;
    ln_balance_after number;
    ln_tutar number;
    ln_rownum number;
    ln_banka_aciklama varchar2(2000);
     
     BEGIN

     ln_rownum := 0;
     ln_customer_no := PKG_HESAP.HESAPTANMUSTERINOAL(pn_account_no);
     ln_external_acc := PKG_HESAP.EXTERNAL_HESAPNO_AL(pn_account_no);
     lc_table := '<table style=''border-collapse:collapse;'' width=''570'' border=''0'' cellspacing=''0'' cellpadding=''0'' align=''center'' style=''border-''><tr><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Date</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Explanation</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Amount</b></td><td style=''padding:10px; border-bottom:2px solid #bfbfbf; font: 12px/15px  Arial, Helvetica, sans-serif; color: #40403f;''><b>Balance</b></td></tr>';
     ld_date_interval := PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL; --cbs-649
     ln_branch_no := PKG_HESAP.HESAPTANSUBEAL(pn_account_no);
     ln_branch_bic_no := sf_get_branch_bic(ln_branch_no); --CBS-451 AntonPa 04.08.2021
     LS_SUB_RES := sf_check_sub(ln_customer_no, 6, lb_email, lb_sms, lb_push, ls_not_lang);
     l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1); --bahianab cbs-113    
     ld_prev_bank_date := CBS.PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL ; --bahianab CBS-649 01042022
     
     IF LS_SUB_RES = '000' then
        IF lb_email THEN
            ls_email_body := ls_email_body || '{' ||
                                '"##TITLE_1##":"Customer Name","##NAME_SURNAME##":"' || PKG_MUSTERI.Sf_Musteri_Eng_Adi(ln_customer_no) || '",' ||
                                '"##TITLE_2##":"Customer Number","##CUSTOMER_NO##":"' || ln_customer_no || '",' ||
                                '"##TITLE_3##":"Account Number","##ACCOUNT_NO##":"' || PKG_HESAP.HESAPTANDOVIZKODUAL(pn_account_no) || ', ' || pn_account_no || '",' ||--CBS-451 AntonPa 04.08.2021
                                '"##TITLE_4##":"External Number","##EXT_ACCOUNT_NO##":"' || ln_external_acc || '",' ||
                                '"##TITLE_5##":"Account Branch","##BRANCH_NO##":"' || ln_branch_bic_no || ' ' || replace(PKG_GENEL.BOLUM_ADI_AL(ln_branch_no), '"', '') || '",' ||--CBS-451 AntonPa 04.08.2021
                                '"##TITLE_6##":"Date","##DATE_INTERVAL##":"' || to_char(PKG_MUHASEBE.ONCEKI_BANKA_TARIHI_BUL, 'DD/MM/YYYY') || '",'; --bahianab cbs-649
                                
            OPEN c_fis;
            LOOP
                FETCH c_fis INTO r_fis;
                EXIT WHEN c_fis%NOTFOUND;
                ln_i := ln_i + 1;
                
                if (r_fis.SATIR_DOVIZ_KOD ='KGS') then ln_tutar := r_fis.SATIR_LC_TUTAR; else ln_tutar := r_fis.SATIR_DV_TUTAR; end if;
                                
                ln_balance_after:= r_fis.SON_BAKIYE;  --ANTONPA 23.09.21
                log_at ('SMS_NOTIF','1',ln_balance_after, sqlerrm);
                
                if (ln_rownum=0) then
                    ln_opening_balance:=ln_tutar*(-1)+r_fis.SON_BAKIYE; --23.09.21
                end if;
                
                ln_banka_aciklama:= r_fis.satir_musteri_aciklama;
                
                if mod(ln_i, 2) = 0 then
                    ls_row := '<tr><td bgcolor=''f9f9f9'' style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(r_fis.FIS_YARATILDIGI_TARIH, 'DD/MM/YYYY')||'</td><td bgcolor=''f9f9f9'' style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ln_banka_aciklama||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_tutar,'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td><td bgcolor=''f9f9f9'' style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_balance_after, 'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td></tr>';--CBS-451 AntonPa 04.08.2021
                else
                    ls_row := '<tr><td style=''padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(r_fis.FIS_YARATILDIGI_TARIH, 'DD/MM/YYYY')||'</td><td style=''padding:5px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||ln_banka_aciklama||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_tutar,'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td><td style=''white-space:nowrap; padding:10px; border-bottom:1px solid #bfbfbf; font: 12px/15px Arial, Helvetica, sans-serif; color: #070d0d;''>'||to_char(ln_balance_after, 'FM999G999G999G999G999G999G999G999G990D00')||' '||r_fis.satir_doviz_kod||'</td></tr>';--CBS-451 AntonPa 04.08.2021
                end if;
                lc_table := lc_table || ls_row;
                ln_rownum := ln_rownum+1;
            end loop;
            lc_table := lc_table || '</table>';
            ls_email_body := ls_email_body || '"##TITLE_7##":"Opening Balance","##OPENING_BALANCE##":"' || to_char(ln_opening_balance, 'FM999G999G999G999G999G999G999G999G990D00') || '",'; --CBS-451 AntonPa 04.08.2021
            ls_email_body := ls_email_body || '"##TITLE_8##":"Closing Balance","##CLOSING_BALANCE##":"' || to_char(ln_balance_after, 'FM999G999G999G999G999G999G999G999G990D00') || '",'; --CBS-451 AntonPa 04.08.2021
            ls_email_body := ls_email_body || '"##TABLE##":"' || lc_table || '"}';
            l_recipients(1) := SF_GET_CUST_EMAIL (ln_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(LS_EMAIL_BODY, 'Monthly Account Statement', 'info@demirbank.kg',l_recipients, 'HTML', 'notif_statement',null,null,ld_prev_bank_date); --bahianab CBS-649 01042022 --bahianab cbs-113
            
            
        END IF;
        IF lb_sms THEN
            --ls_sms_body := 'Vy poluchili email s otchetom vashego scheta ' || ln_external_acc || '.'|| ' 00996312610613, 2222'; --cbs-454 bahianab
            ls_sms_body := 'Vy poluchili email s otchetom vashego scheta.Tel:+996312610610'; --CBS-726 bahianab 230822
            l_recipients(1) := SF_GET_CUST_PHONE (lN_CUSTOMER_NO); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
        END IF;
        IF lb_push THEN
            ls_push_body := ls_sms_body; --CBS-726 bahianab 230822           
            ls_ret := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),lN_CUSTOMER_NO); --bahianab cbs-469--bahianab cbs-113
        END IF;
     END IF;
     EXCEPTION
         WHEN OTHERS THEN
         log_at('SMS_NOTIF','ACC_MONTHLY_NOTIF',SQLERRM ||' '|| TO_CHAR(PN_ACCOUNT_NO),dbms_utility.format_error_backtrace); --ANTONPA 23.09.21  
     
    END;
PROCEDURE IB_USER_CREATION(PN_CUSTOMER_NO NUMBER) IS
 
ls_email_body clob := '';
ls_push_body varchar2(250) := '';
ls_sms_body varchar2(250) := '';
pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; --bahianab cbs-113 
LS_SUB_RES varchar2(3);
lb_email boolean;
lb_sms boolean;
lb_push boolean;
ls_not_lang varchar2(3);
LS_RET varchar2(3);

begin
l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1); --bahianab cbs-113
LS_SUB_RES := sf_check_sub(pn_customer_no, 3, lb_email, lb_sms, lb_push, ls_not_lang);
     if LS_SUB_RES = '000' then
        IF lb_email THEN
            ls_email_body := ls_email_body || '{"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '",' ||
                            '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '",' || 
                            '"##NAME_SURNAME_EN##":"' || PKG_MUSTERI.Sf_Musteri_Eng_Adi(pn_customer_no) || '"}';
            l_recipients(1) := SF_GET_CUST_EMAIL (pn_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'IB/MB Access', 'info@demirbank.kg',l_recipients, 'HTML', 'ib_user_creation',null,null); --bahianab cbs-113
        END IF;
        IF lb_sms THEN
            --ls_sms_body := 'Uvazhaemyi Klient,pozdravlyaem s uspeshoi activaciey Internet i Mobilnogo Bankinga. Podrobnaya informaciya na saite:www.demirbank.kg';
            ls_sms_body := 'Internet i Mobilnyi Banking uspeshno aktivirovany.'; --CBS-726 bahianab 230822
            l_recipients(1) := SF_GET_CUST_PHONE (pn_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
        END IF;
        IF lb_push THEN
            ls_push_body := ls_sms_body; --CBS-726 bahianab 230822               
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),pn_customer_no); --bahianab cbs-469--bahianab cbs-113
        END IF;
     end if;
EXCEPTION
WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '1' || Pkg_Hata.getUCPOINTER);
        log_at('SMS_NOTIF','IB_USER_CREATION',SQLERRM,dbms_utility.format_error_backtrace);
end;
procedure internet_payment_activation(pn_customer_no number, ps_card_no varchar2) is
ls_email_body clob := '';
ls_push_body varchar2(250) := '';
ls_sms_body varchar2(250) := '';
pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; --bahianab cbs-113 
LS_SUB_RES varchar2(3);
lb_email boolean;
lb_sms boolean;
lb_push boolean;
ls_not_lang varchar2(3);
LS_RET varchar2(3);
begin
LS_SUB_RES := sf_check_sub(pn_customer_no, 4, lb_email, lb_sms, lb_push, ls_not_lang);
l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1); --bahianab cbs-113
     if LS_SUB_RES = '000' then
        IF lb_email THEN
            ls_email_body := ls_email_body || '{"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '",' ||
                            '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (pn_customer_no) || '",' || 
                            '"##NAME_SURNAME_EN##":"' || PKG_MUSTERI.Sf_Musteri_Eng_Adi(pn_customer_no) || '",' ||
                            '"##CARD_NUMBER##":"' || ps_card_no || '"}';
            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL( SF_GET_CUST_EMAIL (pn_customer_no), 'Internet Payments via unsecure sites', to_char(LS_EMAIL_BODY), 'internet_payments', pc_ref);
            l_recipients(1) := SF_GET_CUST_EMAIL (pn_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(to_char(LS_EMAIL_BODY), 'Internet Payments via unsecure sites', 'info@demirbank.kg',l_recipients, 'HTML', 'internet_payments',null,null); --bahianab cbs-113
            
        END IF;
        IF lb_sms THEN
            ls_sms_body := 'Uvazhaemyi Klient,po Vashei karte ' || ps_card_no || ' aktivirovan dostup na internet platezhy. Podrobnaya informaciya na saite:www.demirbank.kg';
            --LS_RET := CORPINT2.PKG_NOTIFICATION.SENDSMS ( SF_GET_CUST_PHONE (pn_customer_no), TO_CHAR(LS_SMS_BODY), pc_ref);
            l_recipients(1) := SF_GET_CUST_PHONE (pn_customer_no); --bahianab cbs-113
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDSMSTOQUEUENEW (TO_CHAR(LS_SMS_BODY),l_recipients); --bahianab cbs-113
        END IF;
        IF lb_push THEN
            ls_push_body := 'Uvazhaemyi Klient,po Vashei karte ' || ps_card_no || ' aktivirovan dostup na internet platezhy. Podrobnaya informaciya na saite:www.demirbank.kg';
            --ls_ret := corpint2.pkg_notification.sendpushnotification(TO_CHAR(LS_PUSH_BODY), pn_customer_no, 'Internet Payments via unsecure sites', pc_ref);
            --l_recipients(1) := CORPINT2.PKG_NOTIFICATION.GETCUSTDEVICE(pn_customer_no);  --bahianab cbs-469--bahianab cbs-113                
            LS_RET := CORPINT2.PKG_NOTIFICATION.ADDPUSHTOQUEUENEW(TO_CHAR(LS_PUSH_BODY),pn_customer_no); --bahianab cbs-469--bahianab cbs-113
        END IF;
     end if;
end;
FUNCTION  rusca_ulke_adi_al_hatasiz(ps_ulke_kod IN CBS_ULKE_KODLARI.ulke_kodu%TYPE) RETURN VARCHAR2
IS
    ls_ulke_adi      CBS_ULKE_KODLARI.ulke_adi%TYPE;
  BEGIN
      SELECT UPPER(COUNTRY_IN_RUSSIAN)
    INTO   ls_ulke_adi
    FROM   CBS_ULKE_KODLARI
    WHERE  ulke_kodu = ps_ulke_kod  ;

    RETURN ls_ulke_adi ;

  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '87' || Pkg_Hata.getUCPOINTER);
  END;
    /******************************************************************************
    NAME :         RECEIVED_NOTIFICATION_OR_NOT
    Prepared By :  Bahiana Bektemir kyzy
    Date :         06.09.2021
    Purpose :      Checks if customer received notification or not
 ******************************************************************************/
FUNCTION received_notification_or_not (pn_customer_no   IN NUMBER, pd_date1 DATE, pd_date2 DATE) RETURN VARCHAR2
IS
   ln_cnt     NUMBER;
   ls_ret     VARCHAR2 (1);
   ls_phone   VARCHAR2 (200);
   ls_email   VARCHAR2 (300);
BEGIN
   ls_phone := SF_GET_CUST_PHONE (pn_customer_no);
   ls_email := SF_GET_CUST_EMAIL (pn_customer_no);

   SELECT count(R.recipient)
     INTO ln_cnt
     FROM corpint2.tbl_notification n, CORPINT2.TBL_NOTIFICATION_RESULT r
    WHERE     N.NOTIF_ID = R.NOTIF_ID
          AND (R.RECIPIENT = ls_phone OR R.RECIPIENT =ls_email)
          AND N.BANK_DATE BETWEEN pd_date1 AND pd_date2 --bahianab cbs-629 03032022 
          AND r.STATUS_CD = 'sDONE';

   IF ln_cnt > 0
   THEN
      ls_ret := 'E';
   ELSE
      ls_ret := 'H';
   END IF;
   
   RETURN ls_ret;
EXCEPTION
   WHEN OTHERS THEN
      log_at ('SMS_NOTIF','RECEIVED_NOTIFICATION',SQLERRM ||' '|| TO_CHAR (PN_CUSTOMER_NO),DBMS_UTILITY.format_error_backtrace);
      RETURN 'H';
END;
   /*BOM bahianab cbs-662 new internet transactions */
   FUNCTION GENERATE_8837_NOT (PN_TX_NO        IN     NUMBER,
                               PN_CUSTOMER_NO in CBS_MUSTERI.MUSTERI_NO%TYPE,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      cursor cur_fin is select * from cbs_atm_finansal_islem where tx_no = pn_tx_no;
      rec_fin cur_fin%rowtype;
   begin
       open cur_FIN;
       loop
           fetch cur_FIN into rec_FIN;
           exit when cur_FIN%notfound;
           /*PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili svoiu kartu DKIB ' || replace(rec_fin.card_number, 'X', '*') || ' na summu ' ||
                to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || ' v ' || rec_fin.MERCHANT_LOCATION 
                || '. Vash balans sostavlyaet ' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER)|| ' 00996312610613, 2222';*/ 
           PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy popolnili kartu na ' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE ||'.Tel+996312610610'; --CBS-726 bahianab 230822
           PS_PUSH_BODY := PS_SMS_BODY;
           PS_EMAIL_BODY := '{';
           PS_EMAIL_BODY := PS_EMAIL_BODY
                || '"##CARD_NO##":"' || replace(rec_fin.card_number, 'X', '*') || '", '
                || '"##ACCOUNT_NO##":"' || rec_fin.TO_ACCOUNT_NUMBER || '", '
                || '"##AMOUNT##":"' || to_char(rec_fin.original_amount,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| REC_fin.ORIGINAL_CURRENCY_CODE || '", ' 
                || '"##AVAILABLE_BALANCE##":"' || to_char(PKG_HESAP.KULLANILABILIR_BAKIYE_AL(rec_fin.TO_ACCOUNT_NUMBER),'FM999G999G999G999G999G999G999G999G999D00') ||' '|| PKG_HESAP.HESAPTANDOVIZKODUAL(rec_fin.TO_ACCOUNT_NUMBER) || '", ' 
                || '"##DATE_TIME##":"' || to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || '", '
                || '"##MERCHANT_PLACE##":"' || rec_fin.MERCHANT_LOCATION || '", '
                || '"##COUNTRY_RU##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_KG##":"' || rusca_ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##COUNTRY_EN##":"' || pkg_genel.ulke_adi_al_hatasiz(substr(rec_fin.MERCHANT_LOCATION, -2)) || '", '
                || '"##NAME_SURNAME_RU##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_KG##":"' || pkg_musteri.Sf_Musteri_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '", '
                || '"##NAME_SURNAME_EN##":"' || pkg_musteri.Sf_Musteri_Eng_Adi (PKG_HESAP.HESAPTANMUSTERINOAL(rec_fin.TO_ACCOUNT_NUMBER)) || '"}';
       end loop;
       close cur_FIN;
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_8837_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;    
   /*EOM bahianab cbs-662 new internet transactions */

/******************************************************************************
    NAME :         GENERATE_4141_NOT
    Prepared By :  Panychev Anton
    Date :         11.01.2023
    Purpose :      Generate notif for 4141 tx
******************************************************************************/   
   FUNCTION GENERATE_4141_NOT (PN_TX_NO        IN     NUMBER,
                               PS_EMAIL_BODY      OUT CLOB,
                               PS_SMS_BODY        OUT VARCHAR2,
                               PS_PUSH_BODY       OUT VARCHAR2)
      RETURN VARCHAR2 is
      LR_TX CBS_GOLD_CROWN_OPERATIONS%ROWTYPE;
   begin
       
       SELECT * INTO LR_TX
       FROM CBS_GOLD_CROWN_OPERATIONS
       WHERE TX_NO = PN_TX_NO;
       PS_SMS_BODY := to_date(SYSDATE, 'DD.MM.YYYY HH24:MI:SS') || ' Vy poluchili perevod po sisteme Zolotaya Korona v summe ' || TO_CHAR(LR_TX.OPERATION_AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') ||' '|| LR_TX.OPERATION_AMOUNT_CURRENCY ||' Tel: 2222';
       PS_PUSH_BODY := PS_SMS_BODY;
       PS_EMAIL_BODY := '{';
       PS_EMAIL_BODY := PS_EMAIL_BODY
            || '"##SURNAME_N##":"' || LR_TX.RECEIVER_FULLNAME || '", '
            || '"##TX_DATE##":"' || TO_CHAR(LR_TX.PROCESSED_DATE, 'DD-MM-YY') || '", '
            || '"##OPERATION_AMOUNT##":"' || TO_CHAR(LR_TX.OPERATION_AMOUNT,'FM999G999G999G999G999G999G999G999G999D00') || '", ' 
            || '"##OPERATION_CURRENCY##":"' || LR_TX.OPERATION_AMOUNT_CURRENCY || '"}';
       
       RETURN '000';
       EXCEPTION
       WHEN OTHERS
       THEN
         RETURN '999';
         log_at('SMS_NOTIF','GENERATE_4141_NOT',SQLERRM,dbms_utility.format_error_backtrace);
   end;
END PKG_NOTIF_SUB;
/

