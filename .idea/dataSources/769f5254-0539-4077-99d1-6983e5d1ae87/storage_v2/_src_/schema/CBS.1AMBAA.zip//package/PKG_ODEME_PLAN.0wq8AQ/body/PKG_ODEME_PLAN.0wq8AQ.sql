create PACKAGE BODY     PKG_ODEME_PLAN IS

 Procedure sp_odeme_plan_islem_at       (   p_odeme_plan_no          cbs_odeme_plan_islem.odeme_plan_no%type ,
                                            p_tran_tipi              cbs_odeme_plan_islem.tran_tipi%type ,
                                            p_odeme_plan_tipi        cbs_odeme_plan_islem.odeme_plan_tipi%type ,
                                            p_sozlesme_no            cbs_odeme_plan_islem.sozlesme_no%type ,
                                            p_sozlesme_tarihi        cbs_odeme_plan_islem.sozlesme_tarihi%type ,
                                            p_kredi_tutari           cbs_odeme_plan_islem.kredi_tutari%type ,
                                            p_doviz_kodu             cbs_odeme_plan_islem.doviz_kodu%type ,                                            
                                            p_taksit_sayisi          cbs_odeme_plan_islem.taksit_sayisi%type ,
                                            p_kullandirim_tarihi     cbs_odeme_plan_islem.kullandirim_tarihi%type ,
                                            p_ilk_taksit_tarihi      cbs_odeme_plan_islem.ilk_taksit_tarihi%type ,
                                            p_odeme_gunu             cbs_odeme_plan_islem.odeme_gunu%type ,
                                            p_odeme_tarihi_secimi    cbs_odeme_plan_islem.odeme_tarihi_secimi%type ,
                                            p_faiz_tipi              cbs_odeme_plan_islem.faiz_tipi%type ,
                                            p_faiz_orani             cbs_odeme_plan_islem.faiz_orani%type ,
                                            p_sozlesme_faiz_orani    cbs_odeme_plan_islem.sozlesme_faiz_orani%type ,
                                            p_faiz_hesaplama_tipi    cbs_odeme_plan_islem.faiz_hesaplama_tipi%type ,
                                            p_faiz_siklik_tipi       cbs_odeme_plan_islem.faiz_siklik_tipi%type ,
                                            p_faiz_siklik            cbs_odeme_plan_islem.faiz_siklik%type ,
                                            p_vergi1_orani           cbs_odeme_plan_islem.vergi1_orani%type ,
                                            p_vergi2_orani           cbs_odeme_plan_islem.vergi2_orani%type ,
                                            p_komisyon_tipi          cbs_odeme_plan_islem.komisyon_tipi%type ,
                                            p_komisyon_orani         cbs_odeme_plan_islem.komisyon_orani%type ,
                                            p_komisyon_tutari        cbs_odeme_plan_islem.komisyon_tutari%type ,
                                            p_taksit_siklik          cbs_odeme_plan_islem.taksit_siklik%type ,
                                            p_taksit_artis_siklik    cbs_odeme_plan_islem.taksit_artis_siklik%type ,
                                            p_taksit_artis_orani     cbs_odeme_plan_islem.taksit_artis_orani%type ,
                                            p_odemesiz_ay_sayisi     cbs_odeme_plan_islem.odemesiz_ay_sayisi%type ,
                                            p_faiz_yontemi_methodu   cbs_odeme_plan_islem.faiz_yontemi_methodu%type ,
                                            p_ek_faiz_tutari         cbs_odeme_plan_islem.ek_faiz_tutari%type ,
                                            p_imza_1_adi             cbs_odeme_plan_islem.imza_1_adi%type ,
                                            p_imza_2_adi             cbs_odeme_plan_islem.imza_2_adi%type  ,
                                            p_musteri_no             cbs_odeme_plan_islem.musteri_no%type ,
                                            p_kredi_hesap_No         number default 0 ,--seval.colak 23012022
                                            p_payment_amount          number default 0, --seval.colak 03022022
                                            p_file_servis            varchar2 default 'WS',
                                            p_file_name              varchar2 default null,
                                            p_kredi_tipi             cbs_odeme_plan_islem.kredi_tipi%type  default null ,
                                            p_penalty_rate           cbs_odeme_plan_islem.penalty_rate%type  default null,
                                            p_pastdue_faiz_orani     cbs_odeme_plan_islem.pastdue_faiz_orani%type , 
                                            p_yearly_effective_int_rate            number default null   ,     --seval.colak 29082022                                             
                                            p_Expense_type_1            varchar2 default 'CreditAllocationFee',
                                            p_Expense_payer_type_1      varchar2 default 'Customer',
                                            p_Expense_fee_amount_1      number default 0 ,
                                            p_Expense_type_2            varchar2 default null,
                                            p_Expense_payer_type_2      varchar2 default 'Customer',
                                            p_Expense_fee_amount_2      number default 0 ,
                                            p_Expense_type_3            varchar2 default null,
                                            p_Expense_payer_type_3      varchar2 default 'Customer',
                                            p_Expense_fee_amount_3      number default 0 ,                               
                                            p_Expense_type_4            varchar2 default null,
                                            p_Expense_payer_type_4      varchar2 default 'Customer',
                                            p_Expense_fee_amount_4      number default 0 ,
                                            p_Expense_type_5            varchar2 default null,
                                            p_Expense_payer_type_5      varchar2 default 'Customer',
                                            p_Expense_fee_amount_5      number default 0                                                                                        
                                         ) is pragma autonomous_transaction;
 
  Begin

       insert into CBS_ODEME_PLAN_ISLEM
       (        odeme_plan_no    ,
                tran_tipi    ,
                odeme_plan_tipi    ,
                sozlesme_no    ,
                sozlesme_tarihi    ,
                kredi_tutari    ,
                doviz_kodu,
                taksit_sayisi    ,
                kullandirim_tarihi    ,
                ilk_taksit_tarihi    ,
                odeme_gunu    ,
                odeme_tarihi_secimi    ,
                faiz_tipi    ,
                faiz_orani    ,
                sozlesme_faiz_orani    ,
                faiz_hesaplama_tipi   ,
                faiz_siklik_tipi    ,
                faiz_siklik    ,
                vergi1_orani    ,
                vergi2_orani    ,
                komisyon_tipi    ,
                komisyon_orani    ,
                komisyon_tutari    ,
                taksit_siklik    ,
                taksit_artis_siklik    ,
                taksit_artis_orani    ,
                odemesiz_ay_sayisi    ,
                faiz_yontemi_methodu    ,
                ek_faiz_tutari    ,
                imza_1_adi    ,
                imza_2_adi  ,
                banka_tarihi  ,
                musteri_no,
                file_servis,
                file_name,
                kredi_tipi,
                penalty_rate,
                pastdue_faiz_orani,
                expense_type_1,
                expense_payer_type_1,
                expense_fee_amount_1,
                expense_type_2,
                expense_payer_type_2,
                expense_fee_amount_2,
                expense_type_3,
                expense_payer_type_3,
                expense_fee_amount_3,
                expense_type_4,
                expense_payer_type_4,
                expense_fee_amount_4,
                expense_type_5,
                expense_payer_type_5,
                expense_fee_amount_5,
                kredi_hesap_No , --seval.colak 23012022
                payment_amount  ,--seval.colak 03022022
                yearly_effective_int_rate   --seval.colak 29082022
                
   )
        values
               (
                p_odeme_plan_no    ,
                p_tran_tipi    ,
                p_odeme_plan_tipi    ,
                p_sozlesme_no    ,
                p_sozlesme_tarihi    ,
                p_kredi_tutari    ,
                p_doviz_kodu,
                p_taksit_sayisi    ,
                p_kullandirim_tarihi    ,
                p_ilk_taksit_tarihi    ,
                p_odeme_gunu    ,
                p_odeme_tarihi_secimi    ,
                p_faiz_tipi    ,
                p_faiz_orani    ,
                p_sozlesme_faiz_orani    ,
                p_faiz_hesaplama_tipi    ,
                p_faiz_siklik_tipi    ,
                p_faiz_siklik    ,
                p_vergi1_orani    ,
                p_vergi2_orani    ,
                p_komisyon_tipi    ,
                p_komisyon_orani    ,
                p_komisyon_tutari    ,
                p_taksit_siklik    ,
                p_taksit_artis_siklik    ,
                p_taksit_artis_orani    ,
                p_odemesiz_ay_sayisi    ,
                p_faiz_yontemi_methodu    ,
                p_ek_faiz_tutari    ,
                p_imza_1_adi    ,
                p_imza_2_adi  ,
                pkg_muhasebe.banka_tarihi_bul,
                p_musteri_no ,
                p_file_servis,
                substr(p_file_name,1,2000),
                p_kredi_tipi,
                p_penalty_rate,
                p_pastdue_faiz_orani,
                p_expense_type_1,
                p_expense_payer_type_1,
                p_expense_fee_amount_1,
                p_expense_type_2,
                p_expense_payer_type_2,
                p_expense_fee_amount_2,
                p_expense_type_3,
                p_expense_payer_type_3,
                p_expense_fee_amount_3,
                p_expense_type_4,
                p_expense_payer_type_4,
                p_expense_fee_amount_4,
                p_expense_type_5,
                p_expense_payer_type_5,
                p_expense_fee_amount_5,
                p_kredi_hesap_No,  --seval.colak 23012022
                p_payment_amount , --seval.colak 03022022   
                p_yearly_effective_int_rate   --seval.colak 29082022
                 );
        commit;
        
   exception
     when no_data_found then null;
     when others then
          rollback;  
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6801' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;
----------------------------------------------------------------------------------------------------------------------------------------
  Procedure sp_ozel_odeme_plan_islem_at (   p_odeme_plan_no          cbs_ozel_odeme_plan_islem.odeme_plan_no%type ,
                                            p_taksit_no              cbs_ozel_odeme_plan_islem.taksit_no%type ,
                                            p_taksit_tipi            cbs_ozel_odeme_plan_islem.taksit_tipi%type,
                                            p_tutar                  cbs_ozel_odeme_plan_islem.tutar%type                                       
                                         ) is pragma autonomous_transaction;
 
  Begin

       insert into cbs_ozel_odeme_plan_islem
           (   odeme_plan_no,
               taksit_no,
               taksit_tipi,
               tutar,
               banka_tarihi
            )
        values
               (
                 p_odeme_plan_no,
                 p_taksit_no,
                 p_taksit_tipi ,
                 p_tutar,
                 pkg_muhasebe.banka_tarihi_bul
               );
       commit;
         
   exception
     when no_data_found then null;
     when others then
         rollback;
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6802' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_taksit_odeme_plan_islem_at( p_odeme_plan_no          cbs_taksit_odeme_plan_islem.odeme_plan_no%type ,
                                          p_taksit_no              cbs_taksit_odeme_plan_islem.taksit_no%type ,
                                          p_taksit                 cbs_taksit_odeme_plan_islem.taksit%type ,
                                          p_anapara                cbs_taksit_odeme_plan_islem.anapara%type ,
                                          p_faiz                   cbs_taksit_odeme_plan_islem.faiz%type ,
                                          p_vergi1                 cbs_taksit_odeme_plan_islem.vergi1%type ,
                                          p_vergi2                 cbs_taksit_odeme_plan_islem.vergi2%type ,
                                          p_vade_tarih             cbs_taksit_odeme_plan_islem.vade_tarih%type ,
                                          p_kal_anapara            cbs_taksit_odeme_plan_islem.kal_anapara%type ,
                                          p_taksit_gun_sayisi      cbs_taksit_odeme_plan_islem.taksit_gun_sayisi%type ,
                                          p_hesaplama_gun_sayisi   cbs_taksit_odeme_plan_islem.hesaplama_gun_sayisi%type ,
                                          p_taksit_baz_anapara     cbs_taksit_odeme_plan_islem.taksit_baz_anapara%type ,
                                          p_taksit_faiz_orani      cbs_taksit_odeme_plan_islem.taksit_faiz_orani%type ,
                                          p_taksit_vergi1_orani    cbs_taksit_odeme_plan_islem.taksit_vergi1_orani%type ,
                                          p_taksit_vergi2_orani    cbs_taksit_odeme_plan_islem.taksit_vergi2_orani%type,
                                          p_ozel_odeme_tutari      cbs_taksit_odeme_plan_islem.ozel_odeme_tutari%type,  
                                          p_orj_vergi_tutari       cbs_taksit_odeme_plan_islem.orj_vergi_tutari%type,
                                          p_orj_faiz_tutari        cbs_taksit_odeme_plan_islem.orj_faiz_tutari%type  ,
                                          p_ek_faiz_tutari         cbs_taksit_odeme_plan_islem.ek_faiz_tutari%type ,
                                          p_deferred_interest      cbs_taksit_odeme_plan_islem.deferred_interest%type ,
                                          p_deferred_delayed_interest cbs_taksit_odeme_plan_islem.deferred_delayed_interest%type , --seval.colak 17122021
                                          p_deferred_tax           cbs_taksit_odeme_plan_islem.deferred_tax%type ,
                                          p_delayed_interest       cbs_taksit_odeme_plan_islem.delayed_interest%type ,
                                          p_penalty_amount          cbs_taksit_odeme_plan_islem.penalty_amount%type  default null ,
                                          p_deferred_penalty_amount   cbs_taksit_odeme_plan_islem.deferred_penalty_amount%type  default null ,
                                          p_yearly_cost_rate          cbs_taksit_odeme_plan_islem.yearly_cost_rate%type  default null ,
                                          p_monthly_cost_rate         cbs_taksit_odeme_plan_islem.monthly_cost_rate%type  default null                                         
                                            
 )    is pragma autonomous_transaction;
 
  Begin

       insert into cbs_taksit_odeme_plan_islem
           (    odeme_plan_no,
                taksit_no,
                taksit,
                anapara,
                faiz,
                vergi1,
                vergi2,
                vade_tarih,
                kal_anapara,
                taksit_gun_sayisi,
                hesaplama_gun_sayisi,
                taksit_baz_anapara,
                taksit_faiz_orani,
                taksit_vergi1_orani,
                taksit_vergi2_orani,
                ozel_odeme_tutari ,  
                orj_vergi_tutari,
                orj_faiz_tutari , 
                banka_tarihi  ,
                ek_faiz_tutari ,
                deferred_interest,
                deferred_delayed_interest, --seval.colak 17122021
                deferred_tax,
                delayed_interest,
                penalty_amount,
                deferred_penalty_amount ,
                yearly_cost_rate,
                monthly_cost_rate                                   
            )
        values
           (
                p_odeme_plan_no,
                p_taksit_no,
                p_taksit,
                p_anapara,
                p_faiz,
                p_vergi1,
                p_vergi2,
                p_vade_tarih,
                p_kal_anapara,
                p_taksit_gun_sayisi,
                p_hesaplama_gun_sayisi,
                p_taksit_baz_anapara,
                p_taksit_faiz_orani,
                p_taksit_vergi1_orani,
                p_taksit_vergi2_orani,
                p_ozel_odeme_tutari ,  
                p_orj_vergi_tutari,
                p_orj_faiz_tutari ,
                pkg_muhasebe.banka_tarihi_bul,
                p_ek_faiz_tutari,
                p_deferred_interest,
                p_deferred_delayed_interest, --seval.colak 17122021
                p_deferred_tax,
                p_delayed_interest,
                p_penalty_amount,
                p_deferred_penalty_amount,
                p_yearly_cost_rate,
                p_monthly_cost_rate                  
                );
           
       commit;
         
   exception
     when no_data_found then null;
     when others then
        rollback;
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6803' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;  

----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_plan_anatab_at(p_odeme_plan_no  number ) 
 is pragma autonomous_transaction;
 ld_ilk_taksit_tarihi date;
 Begin
   
   select min(vade_tarih) 
   into ld_ilk_taksit_tarihi
   from cbs_taksit_odeme_plan_islem
   where odeme_plan_no = p_odeme_plan_no ;
   
        
     insert into  cbs_odeme_plan(          odeme_plan_no, tran_tipi, odeme_plan_tipi, 
                                           kredi_tutari, doviz_kodu, taksit_sayisi, 
                                           kullandirim_tarihi, faiz_orani, sozlesme_no, 
                                           sozlesme_tarihi, ilk_taksit_tarihi, odeme_gunu, 
                                           odeme_tarihi_secimi, faiz_tipi, sozlesme_faiz_orani, 
                                           faiz_hesaplama_tipi, faiz_siklik_tipi, faiz_siklik, 
                                           vergi1_orani, vergi2_orani, komisyon_tipi, 
                                           komisyon_orani, komisyon_tutari, taksit_siklik, 
                                           taksit_artis_siklik, taksit_artis_orani, odemesiz_ay_sayisi, 
                                           faiz_yontemi_methodu, ek_faiz_tutari, imza_1_adi, 
                                           imza_2_adi, musteri_no,file_servis, file_name ,  
                                           kredi_tipi,penalty_rate,
                                           yearly_cost_rate,monthly_cost_rate,total_days,pastdue_faiz_orani ,
                                            expense_type_1,expense_payer_type_1,expense_fee_amount_1,
                                            expense_type_2,expense_payer_type_2,expense_fee_amount_2,
                                            expense_type_3,expense_payer_type_3,expense_fee_amount_3,
                                            expense_type_4,expense_payer_type_4,expense_fee_amount_4,
                                            expense_type_5,expense_payer_type_5,expense_fee_amount_5,
                                            kredi_hesap_no ,--seval.colak 23012022
                                            payment_amount, --seval.colak 03022022
                                            banka_tarihi  ,  --seval.colak 31052022
                                            yearly_effective_int_rate--seval.colak 29082022
                                     
 )
     select 
           odeme_plan_no, tran_tipi, odeme_plan_tipi, 
           kredi_tutari, doviz_kodu, taksit_sayisi, 
           kullandirim_tarihi, faiz_orani, sozlesme_no, 
           sozlesme_tarihi,  nvl(ilk_taksit_tarihi,ld_ilk_taksit_tarihi), odeme_gunu, 
           odeme_tarihi_secimi, faiz_tipi,  round(yearly_cost_rate,2) , --sozlesme_faiz_orani, 
           faiz_hesaplama_tipi, faiz_siklik_tipi, faiz_siklik, 
           vergi1_orani, vergi2_orani, komisyon_tipi, 
           komisyon_orani, komisyon_tutari, taksit_siklik, 
           taksit_artis_siklik, taksit_artis_orani, odemesiz_ay_sayisi, 
           faiz_yontemi_methodu, ek_faiz_tutari, imza_1_adi, 
           imza_2_adi, musteri_no,file_servis, file_name,kredi_tipi,penalty_rate,
           yearly_cost_rate,monthly_cost_rate,total_days ,pastdue_faiz_orani,
           expense_type_1,expense_payer_type_1,expense_fee_amount_1,
           expense_type_2,expense_payer_type_2,expense_fee_amount_2,
           expense_type_3,expense_payer_type_3,expense_fee_amount_3,
           expense_type_4,expense_payer_type_4,expense_fee_amount_4,
           expense_type_5,expense_payer_type_5,expense_fee_amount_5,
           kredi_hesap_no ,--seval.colak 23012022
           payment_amount ,--seval.colak 03022022     
           pkg_muhasebe.banka_tarihi_bul  banka_tarihi,    --seval.colak 31052022     
            yearly_effective_int_rate--seval.colak 29082022
        from cbs_odeme_plan_islem
        where odeme_plan_no = p_odeme_plan_no;
        
    commit;
    
  EXCEPTION
   WHEN OTHERS THEN
      rollback;
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6804' || Pkg_Hata.getDelimiter ||'Table Name:CBS_ODEME_PLAN_ISLEM '||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 End;
----------------------------------------------------------------------------------------------------------------------------------------                                         
 Procedure sp_ozel_odeme_plan_anatab_at(p_odeme_plan_no  number)
  is pragma autonomous_transaction;
 Begin
     insert into  cbs_ozel_odeme_plan(odeme_plan_no, taksit_no, tutar, taksit_tipi )
     select  odeme_plan_no, taksit_no, tutar, taksit_tipi
        from cbs_ozel_odeme_plan_islem
        where odeme_plan_no = p_odeme_plan_no;
    commit;
  EXCEPTION
   WHEN OTHERS THEN
   rollback;
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6804' || Pkg_Hata.getDelimiter ||'Table Name:CBS_OZEL_ODEME_PLAN_ISLEM '||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 End;
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_taksit_odeme_plan_anatab_at(p_odeme_plan_no number)
  is pragma autonomous_transaction;
 Begin
     insert into  cbs_taksit_odeme_plan(
                   odeme_plan_no, taksit_no, durum_kodu, 
                   taksit, anapara, faiz,  vergi1, vergi2, vade_tarih, 
                   kal_anapara, taksit_gun_sayisi, hesaplama_gun_sayisi, 
                   taksit_baz_anapara, taksit_faiz_orani, taksit_vergi1_orani, 
                   taksit_vergi2_orani, ozel_odeme_tutari, orj_vergi_tutari,   
                   orj_faiz_tutari,ek_faiz_tutari,deferred_interest,  deferred_delayed_interest, --seval.colak 17122021 
                   deferred_tax,delayed_interest,
                   penalty_amount,deferred_penalty_amount,
                   yearly_cost_rate, monthly_cost_rate     ) 
     select        odeme_plan_no, taksit_no, durum_kodu, 
                   nvl(taksit,0), nvl(anapara,0), nvl(faiz,0),  nvl(vergi1,0), nvl(vergi2,0), vade_tarih, 
                   nvl(kal_anapara,0), taksit_gun_sayisi, hesaplama_gun_sayisi, 
                   nvl(taksit_baz_anapara,0), taksit_faiz_orani, taksit_vergi1_orani, 
                   taksit_vergi2_orani, nvl(ozel_odeme_tutari,0), nvl(orj_vergi_tutari,0),   
                   nvl(orj_faiz_tutari,0) ,nvl(ek_faiz_tutari,0),
                   nvl(deferred_interest,0),
                    nvl(deferred_delayed_interest,0), --seval.colak 17122021 
                   nvl(deferred_tax,0), nvl(delayed_interest,0) ,
                   nvl(penalty_amount,0), nvl(deferred_penalty_amount,0),
                   nvl(yearly_cost_rate,0),nvl(monthly_cost_rate,0)    
        from cbs_taksit_odeme_plan_islem
        where odeme_plan_no = p_odeme_plan_no;
   commit;
  EXCEPTION
   WHEN OTHERS THEN 
      rollback;
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6804' || Pkg_Hata.getDelimiter ||'Table Name:CBS_TAKSIT_ODEME_PLAN_ISLEM '||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 End;
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_taksit_kontrol(p_odeme_plan_no  number ) 
 is
     ln_no              number := 0; 
     ln_kredi_tutari    number :=0;
     ln_anapara         number := 0;
     ln_taksit_sayisi   number := 0;
     ls_err_msg         varchar2(2000);
      --B-O-M seval.colak 23062022 
     ln_isl_deferred_interest      number := 0;
     ln_isl_deferred_delayed_interest  number := 0;
     ln_isl_deferred_tax   number := 0;
     ln_isl_deferred_penalty_amount  number := 0;
     ln_isl_delayed_interest   number := 0;
     ln_isl_penalty_amount            number := 0;  
     
     ln_unpaid_deferred_interest      number := 0;
     ln_unpaid_deferred_delayed_interest  number := 0;
     ln_unpaid_deferred_tax   number := 0;
     ln_unpaid_deferred_penalty_amount  number := 0;
     ln_unpaid_delayed_interest   number := 0;
     ln_unpaid_penalty_amount            number := 0;  
    
     ls_sum_value_column     varchar2(200);
     ln_new_value       number := 0;  
     ln_existing_Value  number := 0;
     ln_kredi_hesap_no number  := 0;
     --E-O-M seval.colak 23062022      
     --B-O-M seval.colak 29082022  
     ln_paid_deferred_interest      number := 0;
     ln_paid_deferred_delayed_interest  number := 0;
     ln_paid_deferred_tax   number := 0;
     ln_paid_deferred_penalty_amount  number := 0;
     ln_paid_delayed_interest   number := 0;
     ln_paid_penalty_amount             number := 0;  
     ln_min_taksit_no                   number := 0;    
     ls_tran_tipi                   varchar2(100);    
     --E-O-M seval.colak 29082022
     
     anapara_kredi_tutar_farkli      exception;
     taksit_sayisi_farkli            exception;
     taksit_kayit_yok                exception; 
     taksit_vade_tarihi_bos          exception; 
     taksit_vade_tarihi_kucuk        exception;  
     odemeplan_toplam_esit_degil     exception;     
     odemeplan_toplam_buyuk_esit_degil  exception;
     taksit_tutari_uygun_degil          exception;
     
 Begin  
      ln_no := 0 ;
      select count(*)
      into ln_no 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no 
            and taksit_no <1000;
        
      if nvl(ln_no,0) = 0 then 
        raise taksit_kayit_yok;
      end if;
 
 
      select sum(nvl(anapara,0)) 
      into ln_anapara 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no; 

      select sum(nvl(kredi_tutari,0) -nvl(payment_amount,0)) 
      into ln_kredi_tutari
      from cbs_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no;            
      
      if nvl(ln_kredi_tutari,0) <>  nvl(ln_anapara,0) then 
        raise anapara_kredi_tutar_farkli;
      end if; 
      
      ln_no := 0 ;
      select count(*) 
      into ln_no 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no
         and taksit_no <1000; 
    
    
      select nvl(taksit_sayisi,0) 
      into ln_taksit_sayisi
      from cbs_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no;            
      
      if nvl(ln_taksit_sayisi,0) <>  nvl(ln_no,0) then 
        raise taksit_sayisi_farkli;
      end if;       
 
 
      ln_no := 0 ;
      select min(taksit_no)
      into ln_no 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no and vade_tarih is null ;
        
      if nvl(ln_no,0) <> 0 then 
        raise  taksit_vade_tarihi_bos;
      end if;
      
      select count(*)
      into ln_no 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no and 
            vade_tarih < pkg_muhasebe.banka_tarihi_bul ;
    
      if nvl(ln_no,0) <> 0 then 
        raise  taksit_vade_tarihi_kucuk;
      end if;
      
      -- B-O-M seval.colak 23062022
      select  kredi_hesap_no , tran_tipi
      into    ln_kredi_hesap_no ,ls_tran_tipi
      from cbs_odeme_plan_islem
      where odeme_plan_no =  p_odeme_plan_no ;
      
       if nvl(ln_kredi_hesap_no,0)  <> 0  AND ls_tran_tipi <> 'RESTRUCTURE' then 
       select 
         sum(abs(nvl(b.delayed_interest,0))) delay_interest,
         sum(abs(nvl(b.penalty_amount,0)))  penalty_amount,
         sum(abs(nvl(b.deferred_interest,0)) )  deferred_interest,
         sum(abs(nvl(b.deferred_delayed_interest,0))) deferred_delayed_interest,
         sum(abs( nvl(b.deferred_tax,0))) deferred_tax ,
         sum(abs( nvl(b.deferred_penalty_amount,0)) ) deferred_penalty_amount 
      into 
          ln_isl_delayed_interest,
          ln_isl_penalty_amount,    
          ln_isl_deferred_interest ,
          ln_isl_deferred_delayed_interest,
          ln_isl_deferred_tax,
          ln_isl_deferred_penalty_amount 
      from  cbs_taksit_odeme_plan_islem b
      where      b.odeme_plan_no = p_odeme_plan_no and
                 b.durum_kodu = 'A' ; 
      -- log_At('seval','ln_isl_deferred_interest',ln_isl_deferred_interest);
  select  
         sum(abs(nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))) unpaid_tahsil_delay_interest,
         sum(abs(nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)))  unpaid_tahsil_penalty_amount,
         sum(abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) )  unpaid_tahsil_deferred_interest,
         sum(abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))) unpaid_tahsil_deferred_delayed_interest,
         sum(abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) ) unpaid_tahsil_deferred_tax ,
         sum(abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) ) unpaid_tahsil_deferred_penalty_amount ,
         -- b-o-m  seval.colak 29082022
         sum(abs(nvl(b.tahsil_gecikme_faiz_tutari,0))) tahsil_delay_interest,
         sum(abs(nvl(b.paid_penalty_amount,0)))  tahsil_penalty_amount,
         sum(abs(nvl(b.paid_deferred_interest,0)) )  tahsil_deferred_interest,
         sum(abs(nvl(b.paid_deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
         sum(abs(nvl(b.paid_deferred_tax,0)) ) tahsil_deferred_tax ,
         sum(abs(nvl(b.paid_deferred_penalty_amount,0)) ) tahsil_deferred_penalty_amount  
           -- e-o-m  seval.colak 29082022        
into      ln_unpaid_delayed_interest,
          ln_unpaid_penalty_amount,
          ln_unpaid_deferred_interest,
          ln_unpaid_deferred_delayed_interest,
          ln_unpaid_deferred_tax ,
          ln_unpaid_deferred_penalty_amount ,
          
          ln_paid_delayed_interest,
          ln_paid_penalty_amount,
          ln_paid_deferred_interest,
          ln_paid_deferred_delayed_interest,
          ln_paid_deferred_tax ,
          ln_paid_deferred_penalty_amount                                  
from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
where a.hesap_no = b.hesap_no and  
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           a.hesap_no = ln_kredi_hesap_no ;               
                       
            ln_new_value := 0;  
            ln_existing_Value := 0;
              
       /* -- seval.colak 29082022 UNPAID kontrolu istenmedi.sagidaki kisim kapatildi. PAID den kucuk girilirse hata verilmesi istendi.     
          if   nvl(ln_isl_deferred_interest,0) <>  nvl(ln_unpaid_deferred_interest,0) then  
               ls_sum_value_column := 'DEFERRED INTEREST';    
               ln_new_value         :=  ln_isl_deferred_interest;
               ln_existing_Value    :=  ln_unpaid_deferred_interest;     
               raise odemeplan_toplam_esit_degil;         
           end if;   
           
            if   nvl(ln_isl_deferred_tax,0) <>  nvl(ln_unpaid_deferred_tax,0) then  
               ls_sum_value_column := 'DEFERRED TAX'; 
               ln_new_value         := ln_isl_deferred_tax;
               ln_existing_Value    :=  ln_unpaid_deferred_tax;
               raise odemeplan_toplam_esit_degil;                 
           end if;   
           
            if   nvl(ln_isl_deferred_delayed_interest,0) <>  nvl(ln_unpaid_deferred_delayed_interest,0) then  
               ls_sum_value_column := 'DEFERRED DELAYED INTEREST';   
               ln_new_value         := ln_isl_deferred_delayed_interest;
               ln_existing_Value    :=  ln_unpaid_deferred_delayed_interest;      
               raise odemeplan_toplam_esit_degil;         
           end if;   
           
             if   nvl(ln_isl_delayed_interest,0) <>  nvl(ln_unpaid_delayed_interest,0)   then              
               ls_sum_value_column := 'DELAYED INTEREST';    
               ln_new_value         :=  ln_isl_delayed_interest;
               ln_existing_Value    :=  ln_unpaid_delayed_interest;
                raise odemeplan_toplam_esit_degil;   
           end if;  
               
           if   nvl(ln_isl_penalty_amount,0) <>  nvl(ln_unpaid_penalty_amount,0) then  
               ls_sum_value_column  := 'PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_penalty_amount;
               ln_existing_Value    :=  ln_unpaid_penalty_amount; 
               raise odemeplan_toplam_esit_degil;               
           end if; 
           
           if   nvl(ln_isl_deferred_penalty_amount,0) <>  nvl(ln_unpaid_deferred_penalty_amount,0) then  
               ls_sum_value_column  := 'DEFERRED PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_deferred_penalty_amount;
               ln_existing_Value    :=  ln_unpaid_deferred_penalty_amount; 
               raise odemeplan_toplam_esit_degil;               
           end if;  
       */ -- E-O-M seval.colak 29082022 UNPAID kontrolu istenmedi.sagidaki kisim kapatildi. PAID den kucuk girilirse hata verilmesi istendi. 
        
        
        -- B-O-M seval.colak 29082022 Eklendi. PAID den kucuk girilirse hata verilmesi istendi. 
       
         if   nvl(ln_isl_deferred_interest,0) < nvl(ln_paid_deferred_interest,0) then  
               ls_sum_value_column := 'DEFERRED INTEREST';    
               ln_new_value         :=  ln_isl_deferred_interest;
               ln_existing_Value    :=  ln_paid_deferred_interest;     
               raise odemeplan_toplam_buyuk_esit_degil;         
           end if;   
           
            if   nvl(ln_isl_deferred_tax,0) <  nvl(ln_paid_deferred_tax,0) then  
               ls_sum_value_column := 'DEFERRED TAX'; 
               ln_new_value         := ln_isl_deferred_tax;
               ln_existing_Value    :=  ln_paid_deferred_tax;
               raise odemeplan_toplam_buyuk_esit_degil;                 
           end if;   
           
            if   nvl(ln_isl_deferred_delayed_interest,0) <  nvl(ln_paid_deferred_delayed_interest,0) then  
               ls_sum_value_column := 'DEFERRED DELAYED INTEREST';   
               ln_new_value         := ln_isl_deferred_delayed_interest;
               ln_existing_Value    :=  ln_paid_deferred_delayed_interest;      
               raise odemeplan_toplam_buyuk_esit_degil;         
           end if;   
           
             if   nvl(ln_isl_delayed_interest,0) <  nvl(ln_paid_delayed_interest,0)   then              
               ls_sum_value_column := 'DELAYED INTEREST';    
               ln_new_value         :=  ln_isl_delayed_interest;
               ln_existing_Value    :=  ln_paid_delayed_interest;
                raise odemeplan_toplam_buyuk_esit_degil;   
           end if;  
               
           if   nvl(ln_isl_penalty_amount,0) <  nvl(ln_paid_penalty_amount,0) then  
               ls_sum_value_column  := 'PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_penalty_amount;
               ln_existing_Value    :=  ln_paid_penalty_amount; 
               raise odemeplan_toplam_buyuk_esit_degil;               
           end if; 
           
           if   nvl(ln_isl_deferred_penalty_amount,0) <  nvl(ln_paid_deferred_penalty_amount,0) then  
               ls_sum_value_column  := 'DEFERRED PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_deferred_penalty_amount;
               ln_existing_Value    :=  ln_paid_deferred_penalty_amount; 
               raise odemeplan_toplam_buyuk_esit_degil;               
           end if;  
        -- E-O-M seval.colak 29082022 eklendi. PAID den kucuk girilirse hata verilmesi istendi. 
      end if;
       -- E-O-M seval.colak 23062022
       
    --B-O-M seval.colak 29082022   
      select min(taksit_no)   
      into ln_min_taksit_no 
      from cbs_taksit_odeme_plan_islem
      where odeme_plan_no = p_odeme_plan_no and 
            nvl(taksit,0) <>   (nvl(anapara,0) + nvl(faiz,0) +  nvl(vergi1,0) + nvl(vergi2,0) + nvl(deferred_interest,0) +  nvl(deferred_tax,0) +  nvl(deferred_penalty_amount,0)+ nvl(deferred_delayed_interest,0) );
    
       if nvl(ln_min_taksit_no,0)  <> 0 then
          raise taksit_tutari_uygun_degil;
       end if;
       
     --E-O-M seval.colak 29082022      
EXCEPTION
   when anapara_kredi_tutar_farkli then 
     raise_application_error(-20100,pkg_hata.getucpointer || '6806' || pkg_hata.getucpointer);  
   when taksit_sayisi_farkli then 
     raise_application_error(-20100,pkg_hata.getucpointer || '6807' || pkg_hata.getucpointer);  
   when taksit_kayit_yok then 
     raise_application_error(-20100,pkg_hata.getucpointer || '6808' || pkg_hata.getucpointer);  
   when taksit_vade_tarihi_bos then 
     raise_application_error(-20100,pkg_hata.getucpointer || '6809' ||pkg_hata.getdelimiter|| to_char(ln_no)  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);  
   when taksit_vade_tarihi_kucuk then 
     raise_application_error(-20100,pkg_hata.getucpointer || '6810' ||pkg_hata.getdelimiter|| to_char(ln_no)  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);  
   When  odemeplan_toplam_esit_degil then  --seval.colak 23062022
       raise_application_error(-20100,pkg_hata.getucpointer || '943' ||  pkg_hata.getDelimiter || to_char(ls_sum_value_column) ||pkg_hata.getDelimiter||to_char(ln_new_value) ||pkg_hata.getDelimiter|| to_char(ln_existing_Value) ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
 When  odemeplan_toplam_buyuk_esit_degil then  --seval.colak 29082022
       raise_application_error(-20100,pkg_hata.getucpointer || '6873' ||  pkg_hata.getDelimiter || to_char(ls_sum_value_column) ||pkg_hata.getDelimiter||to_char(ln_new_value) ||pkg_hata.getDelimiter|| to_char(ln_existing_Value) ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
 when taksit_tutari_uygun_degil then 
      raise_application_error(-20100,pkg_hata.getucpointer || '6874' ||pkg_hata.getdelimiter|| to_char(ln_no)  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer); 
  when others then 
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6811' || Pkg_Hata.getDelimiter || substr(ls_err_msg ||' '||TO_CHAR(SQLCODE) || SQLERRM,1,2000) ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
 End; 
 ----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_plan_anatabloya_at(p_odeme_plan_no  number ) 
 is 
 Begin
    sp_odeme_taksit_kontrol(p_odeme_plan_no);
    sp_odeme_plan_anatab_at(p_odeme_plan_no);
    sp_taksit_odeme_plan_anatab_at(p_odeme_plan_no);
    sp_ozel_odeme_plan_anatab_at(p_odeme_plan_no);
    
 End;

----------------------------------------------------------------------------------------------------------------------------------------
-- sp_taksit_test sadece test etme amacli silinecek sonrasinda
  Procedure sp_taksit_test_kopyala   ( p_odeme_plan_no    cbs_taksit_odeme_plan_islem.odeme_plan_no%type  ,
                                       p_taksit_faiz_orani    cbs_taksit_odeme_plan_islem.taksit_faiz_orani%type ,
                                       p_taksit_vergi1_orani    cbs_taksit_odeme_plan_islem.taksit_vergi1_orani%type ,
                                       p_taksit_vergi2_orani    cbs_taksit_odeme_plan_islem.taksit_vergi2_orani%type,
                                       p_ek_faiz_tutari    number ,
                                       pn_hesap_no number default 0   )
   is pragma autonomous_transaction;
  Begin

       insert into cbs_taksit_odeme_plan_islem
           (    odeme_plan_no,
                taksit_no,
                taksit,
                anapara,
                faiz,
                vergi1,
                vergi2,
                vade_tarih,
                kal_anapara,
                taksit_gun_sayisi,
                hesaplama_gun_sayisi,
                taksit_baz_anapara,
                taksit_faiz_orani,
                taksit_vergi1_orani,
                taksit_vergi2_orani,
                banka_tarihi ,
                ek_faiz_tutari              
            )
            
            select 
                p_odeme_plan_no,
                sira_no,
                nvl(taksit,0),
                nvl(anapara,0),
                nvl(faiz,0),
                nvl(bsmv,0) vergi1,
                nvl(kkdf,0) vergi2,
                vade_tarih,
                nvl(kal_anapara,0),
                30 taksit_gun_sayisi,
                30 hesaplama_gun_sayisi,
                anapara,
                p_taksit_faiz_orani,
                p_taksit_vergi1_orani,
                p_taksit_vergi2_orani,
                pkg_muhasebe.banka_tarihi_bul ,
                nvl(p_ek_faiz_tutari,0)         
            from cbs_hesap_kredi_taksit 
            where hesap_no= nvl(pn_hesap_no,0);
            
       commit;
         
   exception
     when no_data_found then null;
     when others then
      rollback; 
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6803' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;     
                                    
----------------------------------------------------------------------------------------------------------------------------------------
  Procedure sp_ws_getPaymentPlan   (   p_odeme_plan_no              number ,  
                                       pn_caller_tx_no              number default 0,
                                       pn_principal                 number ,
                                       pn_term                      number ,
                                       pn_interestRate              number ,
                                       pn_kkdfRate                  number,
                                       pn_bsmvRate                  number,
                                       pn_paymentDay                number,
                                       pd_customFirstPaymentDate    date,
                                       pd_utilizationDate           date,
                                       ps_interestRateType          varchar2,
                                       ps_paymentPlanType           varchar2,
                                       ps_calculationType           varchar2,
                                       ps_workingDayType            varchar2,
                                       pn_duration                  number,
                                       pn_noPaymentPeriod           number,  
                                       ps_frequencyCode             varchar2,
                                       pn_additionalInterest        number,
                                       ps_commissionType            varchar2,
                                       pn_commissionRate            number,
                                       pn_commissionAmount          number,    
                                       pn_increaseRate              number,
                                       pn_increaseFrequency         number,
                                       pn_frequencyValue            number, 
                                       ps_interestUsageType         varchar2,
                                       ps_tbl_type_extpaylist       pkg_payment_plan_ws.type_extpaylist,
                                       pn_tbl_type_extpaylist_cnt   number ,
                                       p_Expense_type_1            varchar2 default 'CreditAllocationFee',
                                       p_Expense_payer_type_1      varchar2 default 'Customer',
                                       p_Expense_fee_amount_1      number default 0 ,
                                       p_Expense_type_2            varchar2 default null,
                                       p_Expense_payer_type_2      varchar2 default 'Customer',
                                       p_Expense_fee_amount_2      number default 0 ,
                                       p_Expense_type_3            varchar2 default null,
                                       p_Expense_payer_type_3      varchar2 default 'Customer',
                                       p_Expense_fee_amount_3      number default 0 ,                               
                                       p_Expense_type_4            varchar2 default null,
                                       p_Expense_payer_type_4      varchar2 default 'Customer',
                                       p_Expense_fee_amount_4      number default 0 ,
                                       p_Expense_type_5            varchar2 default null,
                                       p_Expense_payer_type_5      varchar2 default 'Customer',
                                       p_Expense_fee_amount_5      number default 0             
                                       )
 is pragma autonomous_transaction;
     ls_returncode varchar2(3)   :='000';
   --  ln_yearly_cost_rate number  := 0;
    -- ln_monthly_cost_rate number := 0;
     i number := 0 ;
     ls_payment_list varchar2(2000);
  Begin
    /*
       for i in 1..pn_tbl_type_extpaylist_cnt
         loop
             log_At('seval', ps_tbl_type_extpaylist(i).paymentnumber , ps_tbl_type_extpaylist(i).amount,ps_tbl_type_extpaylist(i).installmenttypes);
        end loop; 
       */
--- parametre degerlerini loglayalim.
/*log_at( 'seval', 'sp_ws_getPaymentPlan-2',
     'pn_caller_payment_no='||to_char(NVL(p_odeme_plan_no,0),'9999999999999999')||','||  --pn_caller_payment_no
      'pn_caller_tx_no='||to_char(NVL(pn_caller_tx_no,0),'9999999999999999') ||','|| --pn_caller_tx_no
     'pn_principal='||to_char( NVL(pn_principal,0) ,'9999999999999990.99') ||','|| --principal  
     'pn_term='||to_char(NVL(pn_term,0),'9999999999999999') ||','|| --term
     'pn_interestRate='||to_char(nvl(pn_interestRate,0) ,'9999999999999990.9999') ||','|| --interestRate
     'pn_kkdfRate='||to_char(nvl(pn_kkdfRate,0) ,'9999999999999990.9999') ||','|| --kkdfRate
     'pn_bsmvRate='||to_char( nvl(pn_bsmvRate,0) ,'9999999999999990.9999') ||','|| --bsmvRate
     'pn_paymentDay='||to_char(NVL(pn_paymentDay,0),'9999999999999999') ||','|| --paymentDay
     'pd_customFirstPaymentDate='||to_char(pd_customFirstPaymentDate,'YYYY-MM-DD') ||','|| -- customFirstPaymentDate
      'firstInstallmentType='||'InFirstInstallment' ||','|| --firstInstallmentType
     'pd_utilizationDate='||to_char(pd_utilizationDate,'YYYY-MM-DD') ||','||   --utilizationDate
     'ps_interestRateType='||nvl(ps_interestRateType,'Monthly') ||','|| --interestRateType
     'ps_paymentPlanType='||nvl(ps_paymentPlanType,'RegularPaymentPlan') ||','||  --paymentPlanType
     'ps_calculationType='||nvl(ps_calculationType,'MonthlyInterest') ||','||  --calculationType
     'ps_workingDayType='||nvl(ps_workingDayType ,'NextWorkingDay') ||','|| --'NextWorkingDay', --workingDayType
     'pn_duration='||to_char(NVL(pn_duration,0),'9999999999999999') ||','|| --'1', --duration
     'pn_noPaymentPeriod='||to_char(NVL(pn_noPaymentPeriod,0),'9999999999999999') ||','|| -- noPaymentPeriod
     'ps_frequencyCode='||nvl(ps_frequencyCode,'Regular') ||','|| --   'Regular', --frequencyCode
     'pn_additionalInterest='||to_char( nvl(pn_additionalInterest,0) ,'9999999999999990.99') ||','|| --additionalInterest
     'rateDivider='||null ||','|| --rateDivider
    'expense_amount='||'0' ||','|| --expense_amount
    'expense_payer_type='||'Customer' ||','|| --expense_payer_type
    'expense_type='||'AppraisalFee' ||','|| --expense_type
    'commissions='|| null ||','|| --commissions
    'ps_commissionType='|| nvl(ps_commissionType,'NoCommission' ) ||','|| --'NoCommission', --commissionType
     'pn_commissionRate='||to_char(nvl(pn_commissionRate,0) ,'9999999999999990.9999') ||','||   --'0', --commissionRate
     'pn_commissionAmount='||to_char(nvl(pn_commissionAmount,0) ,'9999999999999990.99') ||','|| --commissionAmount 
     'pn_increaseRate='||to_char(nvl(pn_increaseRate,0) ,'9999999999999990.9999') ||','|| --increaseRate
     'pn_increaseFrequency='||to_char(nvl(pn_increaseFrequency,0),'9999999999999999') ||','|| --increaseFrequency
     'pn_frequencyValue='||to_char(nvl(pn_frequencyValue,0),'9999999999999999') ||','|| --frequencyValue
    'fractionDigits='||'2' ||','|| --fractionDigits
    'yearlyCostFractionDigits='||'4'||','|| --yearlyCostFractionDigits
     'ps_interestUsageType='|| nvl(ps_interestUsageType,'NotAvailable'),
     'extrapcnt='||NVL(pn_tbl_type_extpaylist_cnt,0) ||','||SUBSTR(ls_payment_list,1,1900)     --extraPaymentList  
       ) ; */
            
    ls_returncode := pkg_payment_plan_ws.getPaymentPlan(
     to_char(NVL(p_odeme_plan_no,0),'9999999999999999'), --pn_caller_payment_no
     to_char(NVL(pn_caller_tx_no,0),'9999999999999999'), --pn_caller_tx_no
     to_char( NVL(pn_principal,0) ,'9999999999999990.99'), --principal  
     to_char(NVL(pn_term,0),'9999999999999999'), --term
     to_char(nvl(pn_interestRate,0) ,'9999999999999990.9999'), --interestRate
     to_char(nvl(pn_kkdfRate,0) ,'9999999999999990.9999'), --kkdfRate
     to_char(nvl(pn_bsmvRate ,0),'9999999999999990.9999') , --bsmvRate
     to_char(NVL(pn_paymentDay,0),'9999999999999999'), --paymentDay
     to_char(pd_customFirstPaymentDate,'YYYY-MM-DD'), -- customFirstPaymentDate
      'InFirstInstallment', --firstInstallmentType
     to_char(pd_utilizationDate,'YYYY-MM-DD'),   --utilizationDate
     nvl(ps_interestRateType,'Monthly') , --interestRateType
     nvl(ps_paymentPlanType,'RegularPaymentPlan') ,  --paymentPlanType
     nvl(ps_calculationType,'MonthlyInterest') ,  --calculationType
     nvl(ps_workingDayType ,'NextWorkingDay') , --'NextWorkingDay', --workingDayType
     to_char(NVL(pn_duration,0),'9999999999999999'), --'1', --duration
     to_char(NVL(pn_noPaymentPeriod,0),'9999999999999999'), -- noPaymentPeriod
     nvl(ps_frequencyCode,'Regular') , --   'Regular', --frequencyCode
     to_char(NVL(pn_additionalInterest,0) ,'9999999999999990.99'), --additionalInterest
     null, --rateDivider
    to_char(NVL(p_Expense_fee_amount_1,0) ,'9999999999999990.99'), --'0', --expense_amount
    p_Expense_payer_type_1,--'Customer', --expense_payer_type
    p_Expense_type_1,--'AppraisalFee', --expense_type
     null, --commissions
     nvl(ps_commissionType,'NoCommission' ) , --'NoCommission', --commissionType
     to_char(nvl(pn_commissionRate,0) ,'9999999999999990.9999') ,   --'0', --commissionRate
     to_char(nvl(pn_commissionAmount,0) ,'9999999999999990.99') , --commissionAmount 
     to_char(nvl(pn_increaseRate,0) ,'9999999999999990.9999'), --increaseRate
     to_char(nvl(pn_increaseFrequency,0),'9999999999999999'), --increaseFrequency
     to_char(nvl(pn_frequencyValue,0),'9999999999999999'), --frequencyValue
    '2', --fractionDigits
    '4', --yearlyCostFractionDigits
     nvl(ps_interestUsageType,'NotAvailable') , --interestUsageType
     ps_tbl_type_extpaylist,      --nvl(ps_extraPaymentList, '[]' ) --extraPaymentList  
     NVL(pn_tbl_type_extpaylist_cnt,0) ) ;
    
   --log_at( 'seval', 'sp_ws_getPaymentPlan',3,ls_returncode);          

insert into cbs_taksit_odeme_plan_islem
      (     odeme_plan_no    ,
            taksit_no    ,
            taksit    ,
            anapara    ,
            faiz    ,
            vergi1    ,
            vergi2    ,
            vade_tarih    ,
            kal_anapara    ,
            taksit_gun_sayisi    ,
            hesaplama_gun_sayisi    ,
            taksit_baz_anapara    ,
            taksit_faiz_orani    ,
            taksit_vergi1_orani    ,
            taksit_vergi2_orani    ,
            ozel_odeme_tutari    ,
            orj_vergi_tutari    ,
            orj_faiz_tutari ,
            ek_faiz_tutari ,
            yearly_cost_rate,
            monthly_cost_rate ,
            total_days,
            commission_type,
            commission_rate,
            commission_amount     
              )
    select 
        caller_payment_no    ,
        payment_number    ,
        amount    ,
        principal_portion    ,
        interest_portion    ,
        bsmv    ,
        kkdf    ,
        payment_date    ,
        principal_balance    ,
        days    ,
        period_days    ,
        principal    ,
        interest    ,
        bsmv_interest    ,
        kkdf_interest    ,
        extra_payment_amount    ,
        orij_bsmv    ,
        orij_int_portion    ,
        additional_interest ,
        round(yearly_cost_rate,1), --seval.colak 13012022 testlerde bunu istediler.
        monthly_cost_rate ,  
        total_days,
        commission_type,
        commission_rate,
        commission_amount       
     from CBS_PAYMENT_PLAN_WS
     where  caller_payment_no =   p_odeme_plan_no ;
    
 --log_at('seval', 'sp_ws_getPaymentPlan',4,ls_returncode);
   /* select yearly_cost_rate,monthly_cost_rate , total_days ,commission_type, commission_rate , commission_amount
    into   ln_yearly_cost_rate,ln_monthly_cost_rate
    from   cbs_payment_plan_ws 
    where  caller_payment_no = p_odeme_plan_no and rownum =1;
   */
   -- taksit tablosunda donen uniq. olan degerleri cbs_odeme_plan_islem tablosunda ilgili alanlari ile guncelleyelim
    update cbs_odeme_plan_islem
    set   ( yearly_cost_rate ,
            monthly_cost_rate,
            total_days ,
            advanced_commission_type,
            advanced_commission_rate,
            advanced_commission_amount,
            yearly_effective_int_rate --seval.colak 29082022
        ) = ( select round(yearly_cost_rate,1),monthly_cost_rate ,  total_days ,commission_type, commission_rate , commission_amount,
                    round(yearly_cost_rate,1)        --seval.colak 29082022
                                    from   cbs_payment_plan_ws 
                                    where  caller_payment_no = p_odeme_plan_no and rownum =1    )   
    where  odeme_plan_no= p_odeme_plan_no;    

--log_at('seval', 'sp_ws_getPaymentPlan',5,ls_returncode);
    commit;
         
   exception
     when others then
      rollback; 
      --log_at('seval', 'sp_ws_getPaymentPlan',ls_returncode,sqlcode||'-'||sqlerrm);
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6803' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;                                       
----------------------------------------------------------------------------------------------------------------------------------------
Procedure sp_taksit_odeme_plan_isltbl_at  (p_odeme_plan_no           number ,
                                            pv_odeme                   pkg_odeme_plan.v_odeme_plan ,
                                            pn_taksit_sayi             number 
 )   is pragma autonomous_transaction;
  Begin
  
  
  FOR num IN 1..pn_taksit_sayi LOOP
      
       insert into cbs_taksit_odeme_plan_islem
           (    odeme_plan_no,
                taksit_no,
                taksit,
                anapara,
                faiz,
                vergi1,
                vergi2 ,
                vade_tarih,
                kal_anapara,
                taksit_gun_sayisi,
                hesaplama_gun_sayisi,
                taksit_baz_anapara,
                taksit_faiz_orani,
                taksit_vergi1_orani,
                taksit_vergi2_orani,
                ozel_odeme_tutari ,
                orj_vergi_tutari ,
                orj_faiz_tutari ,
                deferred_interest, 
                deferred_delayed_interest, --seval.colak 17122021
                deferred_tax,
                delayed_interest ,
                banka_tarihi   ,
                penalty_amount,
                deferred_penalty_amount           
            )
            
            values( 
                p_odeme_plan_no,
                pv_odeme(num).v_sira ,
                pv_odeme(num).v_taksit ,
                pv_odeme(num).v_anapara ,
                pv_odeme(num).v_faiz,
                pv_odeme(num).v_vergi1 ,
                pv_odeme(num).v_vergi2 ,
                pv_odeme(num).v_vade ,
                pv_odeme(num).v_kalan_anapara,
                pv_odeme(num).v_taksit_gun_sayisi ,
                pv_odeme(num).v_hesaplama_gun_sayisi ,
                pv_odeme(num).v_taksit_baz_anapara,
                pv_odeme(num).v_taksit_faiz_orani,
                pv_odeme(num).v_taksit_vergi1_orani,
                pv_odeme(num).v_taksit_vergi2_orani,
                pv_odeme(num).v_ozel_odeme_tutari ,
                pv_odeme(num).v_orj_vergi_tutari ,
                pv_odeme(num).v_orj_faiz_tutari ,
                pv_odeme(num).v_deferred_interest,
                pv_odeme(num).v_deferred_delayed_interest, --seval.colak 17122021
                pv_odeme(num).v_deferred_tax,
                pv_odeme(num).v_delayed_interest,
                pkg_muhasebe.banka_tarihi_bul,
                pv_odeme(num).v_penalty_amount,
                pv_odeme(num).v_deferred_penalty_amount
                );            
        End loop;
        
       commit;
         
   exception
     when no_data_found then null;
     when others then
      rollback;
      Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6803' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;  
 ----------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE sp_vw_odeme_plan_bilgi_al( p_odeme_plan_no              cbs_vw_odeme_plan.odeme_plan_no%type ,
                                    p_musteri_no                  out  cbs_vw_odeme_plan.musteri_no%type ,
                                    p_durum_kodu                  out  cbs_vw_odeme_plan.durum_kodu%type ,
                                    p_tran_tipi                   out  cbs_vw_odeme_plan.tran_tipi%type ,
                                    p_odeme_plan_tipi             out  cbs_vw_odeme_plan.odeme_plan_tipi%type ,
                                    p_sozlesme_no                 out  cbs_vw_odeme_plan.sozlesme_no%type ,
                                    p_sozlesme_tarihi             out  cbs_vw_odeme_plan.sozlesme_tarihi%type ,
                                    p_kredi_tutari                out  cbs_vw_odeme_plan.kredi_tutari%type ,
                                    p_doviz_kodu                  out  cbs_vw_odeme_plan.doviz_kodu%type ,
                                    p_taksit_sayisi               out  cbs_vw_odeme_plan.taksit_sayisi%type ,
                                    p_kullandirim_tarihi          out  cbs_vw_odeme_plan.kullandirim_tarihi%type ,
                                    p_ilk_taksit_tarihi           out  cbs_vw_odeme_plan.ilk_taksit_tarihi%type ,
                                    p_vade_tarihi                 out  cbs_vw_odeme_plan.ilk_taksit_tarihi%type ,
                                    p_odeme_gunu                  out  cbs_vw_odeme_plan.odeme_gunu%type ,
                                    p_taksit_once_sonra           out  cbs_vw_odeme_plan.taksit_once_sonra%type ,
                                    p_faiz_tipi                   out  cbs_vw_odeme_plan.faiz_tipi%type ,
                                    p_faiz_orani                  out  cbs_vw_odeme_plan.faiz_orani%type ,
                                    p_sozlesme_faiz_orani         out  cbs_vw_odeme_plan.sozlesme_faiz_orani%type ,
                                    p_monthly_interest_rate       out  cbs_vw_odeme_plan.monthly_interest_rate%type ,
                                    p_yearly_int_rate             out  cbs_vw_odeme_plan.yearly_int_rate%type ,
                                    p_yearly_effective_int_rate   out  cbs_vw_odeme_plan.yearly_effective_int_rate%type ,
                                    p_faiz_hesaplama_tipi         out  cbs_vw_odeme_plan.faiz_hesaplama_tipi%type ,
                                    p_faiz_siklik_tipi            out  cbs_vw_odeme_plan.faiz_siklik_tipi%type ,
                                    p_faiz_siklik                 out  cbs_vw_odeme_plan.faiz_siklik%type ,
                                    p_bsmv_alinsin                out  cbs_vw_odeme_plan.bsmv_alinsin%type ,
                                    p_bsmv_orani                  out  cbs_vw_odeme_plan.bsmv_orani%type ,
                                    p_kkdf_alinsin                out  cbs_vw_odeme_plan.kkdf_alinsin%type ,
                                    p_fon_orani                   out  cbs_vw_odeme_plan.fon_orani%type ,
                                    p_komisyon_tipi               out  cbs_vw_odeme_plan.komisyon_tipi%type ,
                                    p_komisyon_orani              out  cbs_vw_odeme_plan.komisyon_orani%type ,
                                    p_komisyon_tutari             out  cbs_vw_odeme_plan.komisyon_tutari%type ,
                                    p_taksit_siklik               out  cbs_vw_odeme_plan.taksit_siklik%type ,
                                    p_taksit_artis_siklik         out  cbs_vw_odeme_plan.taksit_artis_siklik%type ,
                                    p_taksit_artis_orani          out  cbs_vw_odeme_plan.taksit_artis_orani%type ,
                                    p_odemesiz_ay_sayisi          out  cbs_vw_odeme_plan.odemesiz_ay_sayisi%type ,
                                    p_faiz_yontemi_methodu        out  cbs_vw_odeme_plan.faiz_yontemi_methodu%type ,
                                    p_ek_faiz_tutari              out  cbs_vw_odeme_plan.ek_faiz_tutari%type ,
                                    p_imza_1_adi                  out  cbs_vw_odeme_plan.imza_1_adi%type ,
                                    p_imza_2_adi                  out  cbs_vw_odeme_plan.imza_2_adi%type ,
                                    p_odeme_turu                  out  cbs_vw_odeme_plan.odeme_turu%type ,
                                    p_file_servis                 out  cbs_vw_odeme_plan.file_servis %type ,
                                    p_file_name                   out  cbs_vw_odeme_plan.file_name %type ,
                                    p_kredi_tipi                  out  cbs_vw_odeme_plan.kredi_tipi%type ,
                                    p_penalty_rate                out  cbs_vw_odeme_plan.penalty_rate%type,
                                    p_pastdue_Faiz_orani          out  cbs_vw_odeme_plan.pastdue_Faiz_orani%type            
                                    )
 IS
 BEGIN
       SELECT  
                musteri_no,
                durum_kodu,
                tran_tipi,
                odeme_plan_tipi,
                sozlesme_no,
                sozlesme_tarihi,
                kredi_tutari,
                doviz_kodu,
                taksit_sayisi,
                kullandirim_tarihi,
                ilk_taksit_tarihi,
                vade_tarihi,
                odeme_gunu,
                taksit_once_sonra,
                faiz_tipi,
                faiz_orani,
                sozlesme_faiz_orani,
                monthly_interest_rate,
                yearly_int_rate,
                yearly_effective_int_rate,
                faiz_hesaplama_tipi,
                faiz_siklik_tipi,
                faiz_siklik,
                bsmv_alinsin,
                bsmv_orani,
                kkdf_alinsin,
                fon_orani,
                komisyon_tipi,
                komisyon_orani,
                komisyon_tutari,
                taksit_siklik,
                taksit_artis_siklik,
                taksit_artis_orani,
                odemesiz_ay_sayisi,
                faiz_yontemi_methodu,
                ek_faiz_tutari,
                imza_1_adi,
                imza_2_adi,
                odeme_turu,
                file_servis, 
                file_name,
                kredi_tipi,
                penalty_rate,
                pastdue_Faiz_orani
     INTO      
            p_musteri_no,
            p_durum_kodu,
            p_tran_tipi,
            p_odeme_plan_tipi,
            p_sozlesme_no,
            p_sozlesme_tarihi,
            p_kredi_tutari,
            p_doviz_kodu,
            p_taksit_sayisi,
            p_kullandirim_tarihi,
            p_ilk_taksit_tarihi,
            p_vade_tarihi,
            p_odeme_gunu,
            p_taksit_once_sonra,
            p_faiz_tipi,
            p_faiz_orani,
            p_sozlesme_faiz_orani,
            p_monthly_interest_rate,
            p_yearly_int_rate,
            p_yearly_effective_int_rate,
            p_faiz_hesaplama_tipi,
            p_faiz_siklik_tipi,
            p_faiz_siklik,
            p_bsmv_alinsin,
            p_bsmv_orani,
            p_kkdf_alinsin,
            p_fon_orani,
            p_komisyon_tipi,
            p_komisyon_orani,
            p_komisyon_tutari,
            p_taksit_siklik,
            p_taksit_artis_siklik,
            p_taksit_artis_orani,
            p_odemesiz_ay_sayisi,
            p_faiz_yontemi_methodu,
            p_ek_faiz_tutari,
            p_imza_1_adi,
            p_imza_2_adi,
            p_odeme_turu,
            p_file_servis, 
            p_file_name,
            p_kredi_tipi,
            p_penalty_rate,
            p_pastdue_Faiz_orani
      FROM  CBS_VW_ODEME_PLAN
      WHERE odeme_plan_no =p_odeme_plan_no;
 END;
----------------------------------------------------------------------------------------------------------------------------------------
 Procedure sp_odeme_plan_hes_kredi_isl_at( p_tx_no    number,
                                          p_islem_kod number,  
                                          p_sube_kodu varchar2 ,    
                                          p_odeme_plan_no     number,
                                          p_repayment_type    varchar2  default 'INSTALLMENT DATE',  
                                          p_musteri_no number,   
                                          p_hesap_no number default null,
                                          p_faiz_indirimi varchar2 default null        ) 
is
    ln_max_taksit_no number := 0;
    ls_repayment_type   varchar2(100) ;

    ln_pd_int_total number := 0;
    ln_delayed_int_total number := 0;
    ln_penalty_int_total number := 0;
    ln_undue_int_total number := 0;    

   Begin
   
   if nvl(p_odeme_plan_no,0) <> 0 then 
     if   nvl(p_hesap_no,0)  = 0  then --seval.colak 24012022 
       --1. insert cbs_hesap_kredi_islem
         insert into cbs_hesap_kredi_islem
                            (tx_no,   
                            odeme_plan_no,
                            musteri_no,
                           -- durum_kodu,
                            agreement_no,
                            agreement_Date,
                            tutar,
                            doviz_kodu,
                            taksit_sayisi,
                            acilis_tarihi,
                            taksit_baslangic_tarihi ,
                            kredi_vade,
                            odeme_gunu,
                            taksit_once_sonra,
                            faiz_orani,
                            yearly_int_rate,
                            yearly_effective_int_rate,
                            faiz_hesaplama_tipi,
                            faiz_siklik_tipi,
                            faiz_siklik,
                            bsmv_alinsin,
                            bsmv_orani,
                            kkdf_alinsin,
                            fon_orani,
                           -- komisyon_orani, --seval.colak 12082021 ekrandan girilecek 
                          --  komisyon_tutari,--seval.colak 12082021 ekrandan girilecek 
                            taksit_siklik,
                            artis_siklik,
                            artis_oran,
                            odemesiz_ay_sayisi,
                            faiz_yontemi_methodu,
                            ek_taksit_faiz,
                            odeme_turu ,
                          --  hesap_no,
                            islem_tanim_kod ,      
                            repayment_type,
                            sube_kodu,
                            modul_tur_kod,
                            penalty_rate,
                            advanced_commission_type,
                            advanced_commission_rate,
                            advanced_commission_amount,
                            pastdue_faiz_orani,
                            faiz_tahakkuk_tarihi,
                            disbursement_commission,--seval.colak 21102021
                            faiz_orani_tipi,  --seval.colak 29032022
                            monthly_int_rate , --seval.colak 29032022  
                            faiz_indirimi   --seval.colak 25052022
                  )
      select               p_tx_no,   
                            odeme_plan_no,
                            musteri_no,
                          --  durum_kodu,
                            sozlesme_no,
                            sozlesme_tarihi,
                            kredi_tutari,
                            doviz_kodu,
                            taksit_sayisi,
                            kullandirim_tarihi,
                            ilk_taksit_tarihi,
                            vade_tarihi ,
                            odeme_gunu,
                            taksit_once_sonra,
                           -- CASE WHEN p_islem_kod between 1303 and 1309 then YEARLY_INT_RATE --seval.colak 03022022
                            case  when kredi_tipi ='CORPORATE' then yearly_int_rate
                                                       else 
                                                           monthly_interest_rate
                            end as faiz_orani,
                            yearly_int_rate,
                            yearly_effective_int_rate,
                            faiz_hesaplama_tipi,
                            faiz_siklik_tipi,
                            faiz_siklik,
                            bsmv_alinsin,
                            bsmv_orani,
                            kkdf_alinsin,
                            fon_orani,
                            --komisyon_orani, --seval.colak 12082021 ekrandan girilecek 
                            --komisyon_tutari,--seval.colak 12082021 ekrandan girilecek 
                            taksit_siklik,
                            taksit_artis_siklik,
                            taksit_artis_orani,
                            odemesiz_ay_sayisi,
                            faiz_yontemi_methodu,
                            ek_faiz_tutari ek_taksit_faiz,
                            odeme_turu ,
                            --kredi_hesap_no,
                            p_islem_kod ,      
                            p_repayment_type ,
                            p_sube_kodu ,
                            pkg_kredi.modul_tur_kod ,
                            penalty_rate ,
                            advanced_commission_type,
                            advanced_commission_rate,
                            advanced_commission_amount,
                            pastdue_faiz_orani ,
                            faiz_tahakkuk_tarihi ,
                            expense_fee_amount_1 ,      --seval.colak 21102021
                            upper(faiz_tipi) ,  --seval.colak 29032022
                            monthly_interest_rate , --seval.colak 29032022  
                            p_faiz_indirimi   --seval.colak 25052022
                      from  cbs_vw_odeme_plan
                    where odeme_plan_no =p_odeme_plan_no;
           else    --  b-o-m seval.colak 24012022
                    if  p_islem_kod = 3252 then   
                        if  p_repayment_type in ( 'INSTALLMENT DATE','TAKSIT TARIHI') then  --seval.colak 13092022 
                            ls_repayment_type := 'TAKSIT TARIHI' ;
                           else 
                           ls_repayment_type :=p_repayment_type;
                          end if;           --seval.colak 13092022 
                        pkg_Kredi.sp_kredihesap_isleme_at(p_hesap_no,p_tx_no,p_islem_kod,0,'A',NULL,ls_repayment_type,p_faiz_indirimi);                    
                     end if;   
                        -- b-o-m seval.colak 03022022
                       if  p_islem_kod = 3251 then   -- repayment type BALOON baloon payment 
                           pkg_Kredi.sp_kredihesap_isleme_at(p_hesap_no,p_tx_no,p_islem_kod,0,null,'ARA',null,p_faiz_indirimi);
                     end if;  
                        -- e-o-m seval.colak 03022022          
                    update cbs_hesap_kredi_islem
                    set           ( 
                                odeme_plan_no,
                               -- agreement_no,   --seval.colak 13092022
                               -- agreement_Date,  --seval.colak 13092022 
                                tutar,
                                doviz_kodu,
                                kalan_taksit_sayisi,
                                taksit_baslangic_tarihi ,
                                kredi_vade,
                                odeme_gunu,
                                taksit_once_sonra,
                                faiz_orani,
                                yearly_int_rate,
                                yearly_effective_int_rate,
                                faiz_hesaplama_tipi,
                                faiz_siklik_tipi,
                                faiz_siklik,
                                bsmv_alinsin,
                                bsmv_orani,
                                kkdf_alinsin,
                                fon_orani,
                               -- komisyon_orani, --seval.colak 12082021 ekrandan girilecek 
                              --  komisyon_tutari,--seval.colak 12082021 ekrandan girilecek 
                                taksit_siklik,
                                artis_siklik,
                                artis_oran,
                                odemesiz_ay_sayisi,
                                faiz_yontemi_methodu,
                                ek_taksit_faiz,
                                odeme_turu ,
                                repayment_type,
                                penalty_rate,
                                advanced_commission_type,
                                advanced_commission_rate,
                                advanced_commission_amount,
                                pastdue_faiz_orani,
                                faiz_tahakkuk_tarihi,
                                disbursement_commission ,
                                araodeme_tutari, --SEVAL.COLAK 03022022
                                faiz_orani_tipi,  --seval.colak 29032022
                                monthly_int_rate ,  --seval.colak 29032022
                                TAHSIL_ANAPARA  , --seval.colak 18052022
                                HSPLN_ANAPARA   --seval.colak 18052022
                    ) =
                (select          odeme_plan_no,
                              --  sozlesme_no,           --seval.colak 13092022
                              --  sozlesme_tarihi,      --seval.colak 13092022
                                kredi_tutari,
                                doviz_kodu,
                                taksit_sayisi,
                                ilk_taksit_tarihi,
                                vade_tarihi ,
                                odeme_gunu,
                                taksit_once_sonra,
                                /*CASE WHEN p_islem_kod between 1303 and 1306 then YEARLY_INT_RATE
                                     else faiz_orani 
                                end  as   faiz_orani,
                                */
                               -- CASE WHEN p_islem_kod between 1303 and 1309 then YEARLY_INT_RATE --seval.colak 29032022
                                 case    when kredi_tipi ='CORPORATE' then yearly_int_rate
                                                       else 
                                                           monthly_interest_rate
                                       end as faiz_orani,
                                yearly_int_rate,
                                yearly_effective_int_rate,
                                faiz_hesaplama_tipi,
                                faiz_siklik_tipi,
                                faiz_siklik,
                                bsmv_alinsin,
                                bsmv_orani,
                                kkdf_alinsin,
                                fon_orani,
                                --komisyon_orani, --seval.colak 12082021 ekrandan girilecek 
                                --komisyon_tutari,--seval.colak 12082021 ekrandan girilecek 
                                taksit_siklik,
                                taksit_artis_siklik,
                                taksit_artis_orani,
                                odemesiz_ay_sayisi,
                                faiz_yontemi_methodu,
                                ek_faiz_tutari ek_taksit_faiz,
                                odeme_turu ,
                                nvl(repayment_type , p_repayment_type ) ,
                                penalty_rate ,
                                advanced_commission_type,
                                advanced_commission_rate,
                                advanced_commission_amount,
                                pastdue_faiz_orani ,
                                faiz_tahakkuk_tarihi ,
                                expense_fee_amount_1 ,       --seval.colak 21102021  
                                payment_amount  ,            --seval.colak 03022022  
                                upper(faiz_tipi) ,  --seval.colak 29032022
                                monthly_interest_rate , --seval.colak 29032022  
                                payment_amount  ,            --seval.colak 18052022
                                 payment_amount            --seval.colak 18052022                                  
                        from  cbs_vw_odeme_plan
                        where odeme_plan_no =p_odeme_plan_no )
                       where tx_no = p_tx_no ;
                   
                --seval.colak 14092022
                  if  p_repayment_type = 'RESTRUCTURE'  then                  
                       ln_pd_int_total :=  pkg_odeme_plan.sf_pastdue_interest_total(p_hesap_no);
                       ln_delayed_int_total := pkg_odeme_plan.sf_delayed_interest_total(p_hesap_no);
                       ln_penalty_int_total := pkg_odeme_plan.sf_penalty_amount_total(p_hesap_no);
                       ln_undue_int_total := pkg_odeme_plan.sf_cumint_for_undue_principal(p_hesap_no);   -- CUMINT_FOR_UNDUE_PRINCIPAL
                             
                        update cbs_hesap_kredi_islem
                          set   pd_int_total_amt = ln_pd_int_total ,
                                undue_int_total_amt =ln_undue_int_total,
                                delay_int_total_amt =ln_delayed_int_total,
                                penalty_int_total_amt =ln_penalty_int_total                           
                         where tx_no = p_tx_no ;
        

                         update cbs_hesap_kredi_islem
                          set  ( 
                                rst_agreement_no,   
                                rst_agreement_Date)   
                            =   (select    
                                        sozlesme_no,           
                                        sozlesme_tarihi     
                                from  cbs_vw_odeme_plan
                                where odeme_plan_no =p_odeme_plan_no )
                               where tx_no = p_tx_no ;
                                                 
                               
                  else
                       update cbs_hesap_kredi_islem
                              set  ( 
                                    agreement_no,   
                                    agreement_Date)   
                                =   (select    
                                            sozlesme_no,           
                                            sozlesme_tarihi     
                                    from  cbs_vw_odeme_plan
                                    where odeme_plan_no =p_odeme_plan_no )
                                   where tx_no = p_tx_no ;
                  end if;
                 --seval.colak 14092022      
                       
                       delete from cbs_hesap_kredi_ozel_tkst_isl o
                       where o.tx_no = p_tx_no  and exists (Select 1 from CBS_HESAP_KREDI_TAKSIT_ISLEM t where t.tx_no = p_tx_no and t.tx_no = o.tx_no and  t.sira_no =o. taksit_sira_no and t.durum_kodu  in ('A','R','I'));
                       
                       delete from CBS_HESAP_KREDI_TAKSIT_ISLEM 
                       where tx_no = p_tx_no  and durum_kodu  in ('A','R','I');
                     --  e-o-m seval.colak 24012022 
           end if; 
        else        --1303,3250 
             insert into cbs_hesap_kredi_islem
                        (tx_no,   
                        odeme_plan_no,
                        musteri_no,
                        durum_kodu,
                        tutar,
                        doviz_kodu,
                        hesap_no,
                        islem_tanim_kod ,      
                        repayment_type,
                        sube_kodu,
                        modul_tur_kod)
              values  ( p_tx_no,   
                        p_odeme_plan_no,
                        p_musteri_no,
                        'A',
                        0,
                        PKG_GENEL.LC_AL,
                        p_hesap_no,
                        nvl(p_islem_kod,1303),      
                        p_repayment_type,
                        p_sube_kodu,
                        pkg_kredi.modul_tur_kod ) ;
    end if;      
        ln_max_taksit_no := 0 ;
        select NVL(max(sira_no),0)
        into ln_max_taksit_no
        from cbs_hesap_kredi_taksit_islem
        where tx_no = p_tx_no  ;
      
   --2. insert cbs_hesap_kredi_taksit_islem
      insert into cbs_hesap_kredi_taksit_islem
            (      tx_no    ,
                    sira_no    ,
                    taksit    ,
                    anapara    ,
                    faiz    ,
                    kkdf    ,
                    bsmv    ,
                    vade_tarih    ,
                    kal_anapara    ,
                    tahsil_edilecek_taksit    ,
                    hesap_no    ,
                    durum_kodu    ,
                    taksit_gun_sayisi    ,
                    hesaplama_gun_sayisi    ,
                    taksit_baz_anapara    ,
                    taksit_faiz_orani    ,
                    taksit_bsmv_orani    ,
                    taksit_kkdf_orani    ,
                    ozel_odeme_tutari    ,
                    orj_vergi_tutari    ,
                    orj_faiz_tutari    ,
                    ek_faiz_tutari,
                    yaratan_tx_no  ,
                    deferred_interest,
                    deferred_delayed_interest,
                    deferred_tax,
                    gecikme_faiz_tutari  ,
                    penalty_amount,
                    deferred_penalty_amount   
                      )
                        
                select     
                    p_tx_no,    
                     nvl(taksit_no ,0) + nvl(ln_max_taksit_no,0)   ,
                    taksit    ,
                    anapara    ,
                    faiz    ,
                     vergi2 as kkdf  ,  
                    vergi1 as bsmv   , 
                    vade_tarih    ,
                    kal_anapara    ,
                    taksit tahsil_edilecek_taksit ,   
                    p_hesap_no hesap_no    ,
                    nvl(durum_kodu,'A')   ,  
                    taksit_gun_sayisi    ,
                    hesaplama_gun_sayisi ,   
                    taksit_baz_anapara  ,  
                    taksit_faiz_orani   , 
                    taksit_vergi1_orani taksit_bsmv_orani  , 
                    taksit_vergi2_orani taksit_kkdf_orani  , 
                    ozel_odeme_tutari  ,  
                    orj_vergi_tutari  ,  
                    orj_faiz_tutari  ,  
                    ek_faiz_tutari ,
                    p_tx_no   ,
                    deferred_interest,
                    deferred_delayed_interest,
                    deferred_tax,
                    delayed_interest ,
                    penalty_amount,
                    deferred_penalty_amount  
                from   cbs_taksit_odeme_plan_islem    
                where  odeme_plan_no   = p_odeme_plan_no;

--3.CBS_HESAP_KREDI_OZEL_TKST_ISL
          insert into cbs_hesap_kredi_ozel_tkst_isl
                (tx_no, taksit_sira_no, odeme, taksit_tipi,yaratan_tx_no)
             select
                  p_tx_no, nvl(taksit_no ,0) + nvl(ln_max_taksit_no,0), tutar as odeme, taksit_tipi,p_tx_no
             from cbs_ozel_odeme_plan_islem
             where  odeme_plan_no   = p_odeme_plan_no;
       
          
    update cbs_hesap_kredi_islem
    set   kalan_taksit_Sayisi =  (    select count(*)
                                      from cbs_hesap_kredi_taksit_islem
                                       where tx_no = p_tx_no and durum_kodu = 'A' ) 
     where tx_no=  p_tx_no;
                                        
   exception
     when no_data_found then null;
     when others then
      rollback; 
     Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6812' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  end;  
----------------------------------------------------------------------------------------------------------------------------------------
FUNCTION sf_bitmemis_planislem_var_mi( pn_musteri_no cbs_musteri.musteri_no%type,
                                       pn_islem_no cbs_islem.numara%type,
                                       pn_odeme_plan_no number default 0 ) return number
  is
    ln_tx_no   cbs_islem.numara%type  := 0;
    onayda_bekleyen_islem_var          exception;
  begin
       select  max(tx_no)
       into    ln_tx_no
       from   cbs_hesap_kredi_islem a , cbs_islem b
       where  a.musteri_no = pn_musteri_no and
                 a.tx_no = b.numara and
              a.tx_no <> pn_islem_no and
               nvl(a.odeme_plan_no,0) =  nvl(pn_odeme_plan_no,0) and
               pkg_tx.islem_bitmis_mi(b.numara)= 0;


       if  nvl(ln_tx_no,0) <> 0 then
              raise     onayda_bekleyen_islem_var;
       end if;

       return ln_tx_no ;

    exception
      when others then
               raise_application_error(-20100,pkg_hata.getucpointer || '456' ||pkg_hata.getdelimiter|| ln_tx_no  || pkg_hata.getdelimiter ||  pkg_hata.getucpointer);
    end;
----------------------------------------------------------------------------------------------------------------------------------------  
-- B-O-M asagidaki kisim pkg_kredi_rapor dan alindi. degistirilebilir. KRPFI Accrued Loan Interest  izlemede kullanailan fonksiyonlardirPast due principal
-------------------------------------------------------------------------------------------------------------------------

Function sf_kredi_taksitli_mi(pn_kredi_hesap_no number) return varchar2 -- yeni taksitli yapida taksit tablosunda kaydi olan ve  repayment_type = 'INSTALLMENT DATE' kayit taksitlidir.
is 
ln_Adet number := 0;
ls_taksitli_mi  varchar2(1) := 'H';
Begin
            SELECT count(*)       
             into  ln_Adet
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_No   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.repayment_type = 'INSTALLMENT DATE' ;
                   
            if nvl(ln_Adet,0)  > 0 then 
                ls_taksitli_mi := 'E';
            end if;    
   
   return  nvl(ls_taksitli_mi,'H');
   
  Exception when others then   return  nvl(ls_taksitli_mi,'H');        
 End;                
------------------------------------------------------------------------------------------------------------------------------------------------
 Function sf_pastdue_principal_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
   
    cursor cur_hesap is
           select  abs(pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(hesap_no))) principal_amount
           from cbs_hesap_kredi a
           where  hesap_No = pn_kredi_hesap_no and
                 --a.durum_kodu = 'A' and 
                 a.kredi_Vade  <=  ld_banka_tarihi and
                 a.repayment_type = 'MATURITY DATE' 
               -- and pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'  
                 
            union all 
             SELECT  sum( case when nvl(b.anapara,0) -   nvl(b.tahsil_anapara,0) > 0 then nvl(b.anapara,0) -   nvl(b.tahsil_anapara,0) else 0 end)  principal_amount       
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_No   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.durum_kodu = 'A' and 
                   b.durum_kodu = 'A' and 
                   b.vade_tarih <=  ld_banka_tarihi and
                   repayment_type = 'INSTALLMENT DATE'  
           group by a.hesap_no;
                 --  and pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E';
 Begin
   --    ld_banka_tarihi := pkg_muhasebe.banka_tarihi_bul;
       
       for c_hesap in cur_hesap loop
           ln_tutar := c_hesap.principal_amount ; 
        end loop;   
      
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;
-------------------------------------------------------------------------------------------------------------------------
 Function sf_pastdue_interest_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
 Begin
       if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then 
                select  SUM(   ( case when  abs(nvl(b.faiz,0)) > abs(nvl(b.tahsil_faiz,0)) then  abs(abs(nvl(b.faiz,0)) -    abs(nvl(b.tahsil_faiz,0))) else 0 end  ) + 
                                 case when  abs(nvl(b.deferred_interest,0)) > abs(nvl(b.paid_deferred_interest,0)) then  nvl(deferred_interest,0)  -  nvl(paid_deferred_interest,0)  else 0 end ) --seval.colak 2308202
                into  ln_tutar
                from cbs_hesap_kredi_taksit b
                where hesap_no = pn_kredi_hesap_no and
                      durum_kodu ='A' and  
                      vade_tarih <=ld_banka_tarihi ;           
           else
                select SUM(case when  abs(nvl(b.faiz_tahakkuk_tutar,0)) > abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0)) then   nvl( faiz_tahakkuk_tutar,0) - nvl(faiz_tahakkuk_tutar_tahsil,0)  else 0 end  )
                into ln_tutar
                from cbs_kredi_tahakkuk b
                 where kredi_hesap_no = pn_kredi_hesap_no and 
                       durum_kodu ='A' and
                       banka_tarihi <= ld_banka_tarihi ;
           end if;  
         return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;
 Function sf_pastdue_tax_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
 Begin
       if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then 
                select  SUM(case when  abs(nvl(b.bsmv,0)) > abs(nvl(b.tahsil_bsmv,0)) then  abs(abs(nvl(b.bsmv,0)) -    abs(nvl(b.tahsil_bsmv,0))) else 0 end  )
                into  ln_tutar
                from cbs_hesap_kredi_taksit b
                where hesap_no = pn_kredi_hesap_no and
                      durum_kodu ='A' and  
                      vade_tarih <=ld_banka_tarihi ;           
           else
                select SUM(case when  abs(nvl(b.vergi_tahakkuk_tutar,0)) > abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0)) then   nvl( vergi_tahakkuk_tutar,0) - nvl(vergi_tahakkuk_tutar_tahsil,0)  else 0 end  )
                into ln_tutar
                from cbs_kredi_tahakkuk b
                 where kredi_hesap_no = pn_kredi_hesap_no and 
                       durum_kodu ='A' and
                       banka_tarihi <= ld_banka_tarihi ;
           end if;  
         return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;
Function sf_accrued_int_amount(pn_kredi_hesap_no number) return number
is
   ln_tutar number := 0;
 Begin
        select  case when nvl(ACCRUAL_INT_ACCOUNT_NO,0) <> 0  then   pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(ACCRUAL_INT_ACCOUNT_NO))
                 else  0 
                 end   
        into ln_tutar
        from cbs_hesap_kredi
        where hesap_no =pn_kredi_hesap_no ;         
    
        return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;

-- seval.colak 28102021 non accrued hesap ile ilgili degisiklikler yapilinca asagidaki kisim degistirilecek 
Function sf_non_accrued_int_amount(pn_kredi_hesap_no number) return number
is
   ln_tutar number := 0;
 Begin
       
        select  case when nvl(nonaccrual_int_account_no,0) <> 0  then   pkg_kur.yuvarla(doviz_kodu,pkg_kredi.sf_bakiye_al(nonaccrual_int_account_no))
                 else  0 
                 end   
        into ln_tutar
        from cbs_hesap_kredi
        where hesap_no =pn_kredi_hesap_no ;             
       
        return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;

Function sf_cumulated_int_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
 Begin
       
   ln_tutar:=  ( nvl(sf_accrued_int_amount(pn_kredi_hesap_no),0)  +
                nvl(sf_non_accrued_int_amount(pn_kredi_hesap_no),0))  -
                nvl(sf_pastdue_interest_total(pn_kredi_hesap_no),0);            
        
        return  nvl(ln_tutar,0);
        
    Exception when others then return 0 ;
 End;

Function sf_delay_days_of_principal(pn_kredi_hesap_no number) return number
is
   ld_date date ;
    ln_penalty_days number := 0; 
 Begin
       -- ln_penalty_days:= pkg_odeme_plan.sf_ap_gecikme_gun_sayisi(pn_kredi_hesap_no); --seval.colak 13042022 kapatildi direk tablodan getirilecek.
                select ap_gecikme_gun_sayisi
                into ln_penalty_days
                from cbs_hesap_kredi b
                 where hesap_no = pn_kredi_hesap_no ;  

       return  ln_penalty_days;
    Exception when others then return 0 ;
 End;
-------------------------------------------------------------------------------------------------------------------------
Function sf_delay_days_of_interest(pn_kredi_hesap_no number) return number
is
    ld_date date ;
    ln_penalty_days number := 0; 
 Begin
       --ln_penalty_days:= pkg_odeme_plan.sf_faiz_gecikme_gun_sayisi(pn_kredi_hesap_no); --seval.colak 13042022 kapatildi direk tablodan getirilecek.
                select faiz_gecikme_gun_sayisi
                into ln_penalty_days
                from cbs_hesap_kredi b
                 where hesap_no = pn_kredi_hesap_no ;  
       return  ln_penalty_days;
    Exception when others then return 0 ;
 End;
 
-------------------------------------------------------------------------------------------------------------------------
Function sf_delayed_interest_total(pn_kredi_hesap_no number) return number
is
ln_delayed_interest_amount number := 0;
begin
  -- seval.colak 18042022 taksitli icinde hesap kredi den getirmesi istendi.
   /*if   pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) = 'E' then
          select  sum(abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))) 
          into   ln_delayed_interest_amount
          from   cbs_hesap_kredi_taksit b
          where   hesap_no =pn_kredi_hesap_no ;
    ELSE */
          select     abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2))  + 
                     abs(round(nvl(gecenyil_gecikme_faiz,0),2))        +
                     abs(round(nvl(gecenay_gecikme_faiz,0),2))        
          into   ln_delayed_interest_amount
          from   cbs_hesap_kredi
          where   hesap_no =pn_kredi_hesap_no ;
    --end if;
    
return  nvl(ln_delayed_interest_amount,0) ;
  Exception when others then  return 0;
end ;  

Function sf_delayed_interest_tax_total(pn_kredi_hesap_no number) return number
is
ln_delayed_interest_amount number := 0;
ln_delayed_interest_tax number := 0;
ln_sales_tax_rate       number;
begin
         pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 
         ln_delayed_interest_amount := sf_delayed_interest_total(pn_kredi_hesap_no) ;
         ln_delayed_interest_tax := abs(round(( NVL(ln_delayed_interest_amount,0)* nvl(ln_sales_tax_rate,0) /100),2 )); 
 
    return  nvl(ln_delayed_interest_tax,0) ;
  Exception when others then  return 0;
end ;  

------------------------------------------------------------------------------------------------------------------------
Function sf_delayed_interest_accruedtax_total(pn_kredi_hesap_no number) return number                                                                                                                   
is
ln_accrued_interest_tax   number := 0;
begin
          select abs(round(nvl(a.gecikme_faiz_accruedtax,0),2))  
          into   ln_accrued_interest_tax
          from   cbs_hesap_kredi a
          where   hesap_no =pn_kredi_hesap_no ;
   
return  nvl(ln_accrued_interest_tax,0) ;
  Exception when others then  return 0;
end ;
------------------------------------------------------------------------------------------------------------------------
Function sf_penalty_amount_total(pn_kredi_hesap_no number) return number                                                                                                                   
is
ln_penalty_amount   number := 0;
begin
    -- seval.colak 18042022 taksitli icinde hesap kredi den getirmesi istendi.
/*    if   pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) = 'E' then
          select sum(nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) )  
          into   ln_penalty_amount
          from   cbs_hesap_kredi_taksit
          where   hesap_no =pn_kredi_hesap_no ;
    else
    */
          select nvl(penalty_amount,0) -nvl(paid_penalty_amount,0) 
          into   ln_penalty_amount
          from   cbs_hesap_kredi
          where   hesap_no =pn_kredi_hesap_no ;
   -- end if;  

return  nvl(ln_penalty_amount,0) ;
  Exception when others then  return 0;
end ;
---------------------------------------------------------------------------------------------------------------------------
FUNCTION  sf_urun_tahakkuk_eh(ps_modul_tur_kod IN varchar2, 
                              ps_urun_tur_kod IN varchar2,
                              ps_urun_sinif_kod varchar2 ) RETURN VARCHAR2
IS
    ls_tahakkuk_eh    VARCHAR2(1) :='H';
  BEGIN
         SELECT tahakkuk_eh
         INTO   ls_tahakkuk_eh
         FROM   CBS_URUN_SINIF
         WHERE  modul_tur_kod  = ps_modul_tur_kod and
                urun_tur_kod   = ps_urun_tur_kod and 
                kod = ps_urun_sinif_kod;

    RETURN ls_tahakkuk_eh;

  EXCEPTION
      WHEN OTHERS THEN RETURN 'H';
        --RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '2016' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------
Function sf_min_pastdue_int_hesno(pn_kredi_hesap_no number) return number 
is
ln_hesap_No number;
begin

      select  min(hesap_no) 
      into ln_hesap_No
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'FAIZ' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
            
return  ln_hesap_No ;
EXCEPTION
      WHEN OTHERS THEN RETURN null;
 End;
--------------------------------------------------------------------------------------------------------------------------                                                                                                                                        
Function sf_min_pastdue_tax_hesno(pn_kredi_hesap_no number) return number is
ln_hesap_No number;
begin

      select  min(hesap_no) 
      into ln_hesap_No
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'TAX' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
            
return  ln_hesap_No ;
EXCEPTION
      WHEN OTHERS THEN RETURN null;
 End;
-------------------------------------------------------------------------------------------------------------------------- 
Function sf_min_pastdue_principal_hesno(pn_kredi_hesap_no number) return number is
ln_hesap_No number;
begin

      select  min(hesap_no) 
      into ln_hesap_No
      from cbs_hesap_kredi
      where ana_kredi_hesap_no =pn_kredi_hesap_no and
            pastdue_faiz_anapara_sec = 'ANAPARA' and 
             durum_kodu = 'A' and
            ( urun_tur_kod like 'PAST%' or urun_tur_kod = 'PD-%' );
            
return  ln_hesap_No ;
EXCEPTION
      WHEN OTHERS THEN RETURN null;
 End;
--------------------------------------------------------------------------------------------------------------------------
Function sf_pastdue_tax_hesno(pn_kredi_hesap_no number) return number is
ln_hesap_No number;
begin

      select  ACCRUAL_TAX_ACCOUNT_NO      --vergi_tahakkuk_hesap_no 
      into ln_hesap_No
      from cbs_hesap_kredi
      where hesap_no =pn_kredi_hesap_no ;            
            
            
return  ln_hesap_No ;
EXCEPTION
      WHEN OTHERS THEN RETURN null;
 End;
-------------------------------------------------------------------------------------------------------------------------- 
Function sf_pastdue_int_hesno(pn_kredi_hesap_no number) return number is
ln_hesap_No number;
begin

      select ACCRUAL_INT_ACCOUNT_NO       --faiz_tahakkuk_hesap_no 
      into ln_hesap_No
      from cbs_hesap_kredi
      where hesap_no =pn_kredi_hesap_no ;            
            
return  ln_hesap_No ;
EXCEPTION
      WHEN OTHERS THEN RETURN null;
 End; 
--------------------------------------------------------------------------------------------------------------------------
Function sf_ap_gecikme_gun_sayisi(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
 Begin
       if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then 
                select max(nvl(ap_gecikme_gun_sayisi,0))
                into  ln_tutar
                from cbs_hesap_kredi_taksit b
                where hesap_no = pn_kredi_hesap_no and
                      durum_kodu ='A' and  
                      vade_tarih <=ld_banka_tarihi ;           
           else
                select ap_gecikme_gun_sayisi
                into ln_tutar
                from cbs_hesap_kredi b
                 where hesap_no = pn_kredi_hesap_no ;                       
           end if;  
         return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;
 --------------------------------------------------------------------------------------------------------------------------
Function sf_faiz_gecikme_gun_sayisi(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
 Begin
       if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then 
                select max(nvl(faiz_gecikme_gun_sayisi,0))
                into  ln_tutar
                from cbs_hesap_kredi_taksit b
                where hesap_no = pn_kredi_hesap_no and
                      durum_kodu ='A' and  
                      vade_tarih <=ld_banka_tarihi ;           
           else
                select faiz_gecikme_gun_sayisi
                into ln_tutar
                from cbs_hesap_kredi b
                 where hesap_no = pn_kredi_hesap_no ;                       
           end if;  
         return  ABS(nvl(ln_tutar,0));
        
    Exception when others then return 0 ;
 End;
------------------------------------------------------------------------------------------------
Function sf_pastdue_opening_date(pn_kredi_hesap_no number) return date
 is
   ln_tarih date := null;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
 Begin
       if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then 
                select min(vade_tarih)
                into  ln_tarih
                from cbs_hesap_kredi_taksit b
                where hesap_no = pn_kredi_hesap_no and
                      nvl(tahakkuk_eh,'H') ='E' and
                      vade_tarih <=ld_banka_tarihi and
                      ( nvl(taksit,0)<> 0  or nvl(anapara,0) <> 0)  ;            
           else
                select min(banka_tarihi)
                into ln_tarih
                from cbs_kredi_tahakkuk b
                 where kredi_hesap_no = pn_kredi_hesap_no and 
                       banka_tarihi <= ld_banka_tarihi ;
         end if;  
         return  ln_tarih;
        
    Exception when others then return null ;
 End;
------------------------------------------------------------------------------------------------
 Function sf_acik_taksit_adedi(pn_hesap_no number) return number
 is
   ln_adet number;
 Begin
       select count(*)
      into ln_adet
      from cbs_hesap_kredi_taksit
      where hesap_no = pn_hesap_no and
              durum_kodu = 'A';

      return ln_adet;
 End;
 -------------------------------------------------
 Function sf_max_odenmis_taksit_no (pn_hesap_no cbs_hesap_kredi.hesap_no%type) return number
 is
  ln_sira_no number := 0;
 Begin
	   select max(sira_no)
	   into ln_sira_no
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
	   		 durum_kodu  in(  'O','K','T') ;
  return nvl(ln_sira_no,0);

  exception when others then return 0;
 End;
 ------------------------------------------------------------------------------------------------ 
 function sf_hesap_taksit_maxno_al(pn_hesap_no  number) return number
 IS
   ln_sira NUMBER;
  BEGIN

       SELECT MAX(sira_no)
      INTO ln_sira
      FROM CBS_HESAP_KREDI_TAKSIT
      WHERE hesap_no = pn_hesap_no;       

    RETURN NVL(ln_sira,0);
    EXCEPTION WHEN OTHERS THEN RETURN 0;
 END;
 ------------------------------------------------------------------------------------------------
 Function sf_ensonodenmis_vadetarihial( pn_hesap_no number) return date

 is
   ld_vade	date;
  Begin

  	   select max(vade_tarih)
	   into ld_vade
	   from cbs_hesap_kredi_taksit
	   where hesap_no = pn_hesap_no and
             durum_kodu in('O','K','T' ); --odeme_tarihi is not null  ;

	  if ld_vade is null then
	   	   select acilis_Tarihi
		   into ld_vade
		   from cbs_hesap_kredi
		   where hesap_no = pn_hesap_no ;
	 end if;

	 return ld_vade;

    Exception
	when no_data_found then

	   	   select acilis_Tarihi
		   into ld_vade
		   from cbs_hesap_kredi
		   where hesap_no = pn_hesap_no ;

		   return ld_vade;
  End;
 ------------------------------------------------------------------------------------------------
 Procedure sp_vw_odeme_plan_hesap_bilgi( p_hesapno               number ,
                                            p_sozlesme_tarihi       out date ,
                                            p_sozlesme_no           out varchar2,
                                            p_kredi_tutari          out number,
                                            p_doviz                 out varchar2,
                                            p_taksit_sayisi         out number,
                                            p_acilis_tarihi         out date,		
                                            p_odeme_gunu            out number,
                                            p_odeme_tarihi_secimi   out varchar2,
                                            p_faiz_tipi             out varchar2,
                                            p_faiz_orani            out number,
                                            p_faiz_hesaplama_tipi   out varchar2,
                                            p_faiz_siklik_tipi      out varchar2,
                                            p_faiz_siklik           out number,
                                            p_taksit_siklik         out number,
                                            p_taksit_artis_siklik   out number,
                                            p_taksit_artis_orani    out number,
                                            p_odemesiz_ay_sayisi    out number,
                                            p_faiz_yontemi_methodu  out varchar2,
                                            p_ek_faiz_tutari        out number,
                                            p_odeme_plan_tipi       out varchar2,
                                            p_penalty_rate          out number,
                                            p_pastdue_faiz_orani    out number,
                                            p_yearly_effective_int_rate  out  number  )     --seval.colak 29082022)
is 
 Begin
 
 if nvl(p_hesapno,0) <> 0 then 
  select  
		sozlesme_tarihi,
		sozlesme_no,
		bakiye,
		doviz_kodu,
		kalan_taksit_sayisi,
		sonodenmis_vadetarihi,
		odeme_gunu,
		odeme_tarihi_secimi,
		faiz_tipi,
		faiz_orani,
		faiz_hesaplama_tipi,
		faiz_siklik_tipi,
		faiz_siklik,
		taksit_siklik,
		artis_siklik,
		artis_oran,
		odemesiz_ay_sayisi,
		faiz_yontemi_methodu,
		ek_taksit_faiz,
		odeme_plan_tipi,
		penalty_rate,
		pastdue_faiz_orani
	into 
		p_sozlesme_tarihi,
		p_sozlesme_no,
		p_kredi_tutari,
		p_doviz,
		p_taksit_sayisi,
		p_acilis_tarihi,		
		p_odeme_gunu,
		p_odeme_tarihi_secimi,
		p_faiz_tipi,
		p_faiz_orani,
		p_faiz_hesaplama_tipi,
		p_faiz_siklik_tipi,
		p_faiz_siklik,
		p_taksit_siklik,
		p_taksit_artis_siklik,
		p_taksit_artis_orani,
		p_odemesiz_ay_sayisi,
		p_faiz_yontemi_methodu,
		p_ek_faiz_tutari,
		p_odeme_plan_tipi,
		p_penalty_rate,
		p_pastdue_faiz_orani
	from cbs_vw_odeme_plan_hesap
	where hesap_no = p_hesapno;
end if;	
Exception
   when others then
          log_at ('sp_vw_odeme_plan_hesap_bilgi',p_hesapno,sqlcode,sqlerrm);
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '6866' ||  pkg_hata.getdelimiter|| to_Char(p_hesapno) ||'-'|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
End;          
 --b-o-m seval.colak 23062022
 PROCEDURE sp_installment_unpaid_amounts( pn_hesap_no   number ,
                                          pn_taksit_no  number default 0 , --0 means all installments
                                          pn_unpaid_principal out number  ,
                                          pn_unpaid_interest out number  ,
                                          pn_unpaid_tax out number  ,
                                          pn_unpaid_delayed_interest out number  ,
                                          pn_unpaid_penalty_amount  out number  ,
                                          pn_unpaid_deferred_interest out number ,
                                          pn_unpaid_deferred_delayed_interest out number ,
                                          pn_unpaid_deferred_tax  out number ,
                                          pn_unpaid_deferred_penalty_amount out number )                                                                    
 is
 Begin                                  
 select  
         sum(nvl(b.anapara,0)-nvl(b.tahsil_anapara,0))  unpaid_principal   ,
         sum( abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) ) unpaid_interest,
         sum(abs(nvl(b.bsmv,0) - nvl(b.tahsil_bsmv,0)) ) unpaid_tax, 
         sum(abs(nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))) unpaid_delayed_interest,
         sum(abs(nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)))  unpaid_penalty_amount,
         sum(abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) )  unpaid_deferred_interest,
         sum(abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))) unpaid_deferred_delayed_interest,
         sum(0)  unpaid_deferred_tax , --seval.colak 29082022 -- sum(abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) ) unpaid_deferred_tax ,
         sum(abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) ) unpaid_deferred_penalty_amount        
into      
          pn_unpaid_principal ,
          pn_unpaid_interest ,
          pn_unpaid_tax  ,
          pn_unpaid_delayed_interest,
          pn_unpaid_penalty_amount,
          pn_unpaid_deferred_interest,
          pn_unpaid_deferred_delayed_interest,
          pn_unpaid_deferred_tax ,
          pn_unpaid_deferred_penalty_amount                            
from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
where a.hesap_no = b.hesap_no and  
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           a.hesap_no = pn_hesap_no and
           (( nvl(pn_taksit_no,0) = 0 ) or  -- all
            ( nvl(pn_taksit_no,0) <> 0  and b.sira_no = pn_taksit_no) ) ;   
   End; 
    --e-o-m seval.colak 23062022      
 ---------------------------------------------------------------------------------------------
  -- B-O-M seval.colak 02092022
 Function sf_deferred_int_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
                       
 Begin

      select  sum( case when nvl(b.deferred_interest,0) -   nvl(b.paid_deferred_interest,0) > 0 then nvl(b.deferred_interest,0) -   nvl(b.paid_deferred_interest,0) else 0 end)  deferred_interest  
      into      ln_tutar
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_no   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.durum_kodu = 'A' and 
                   b.durum_kodu = 'A' and 
                   b.vade_tarih <=  ld_banka_tarihi and
                   repayment_type = 'INSTALLMENT DATE'  ;
      
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;   
   
 Function sf_deferred_delayed_int_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
                       
 Begin

   select  sum( case when nvl(b.deferred_delayed_interest,0) -   nvl(b.paid_deferred_delayed_interest,0) > 0 then nvl(b.deferred_delayed_interest,0) -   nvl(b.paid_deferred_delayed_interest,0) else 0 end)  deferred_delayed_interest
   into      ln_tutar
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_no   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.durum_kodu = 'A' and 
                   b.durum_kodu = 'A' and 
                   b.vade_tarih <=  ld_banka_tarihi and
                   repayment_type = 'INSTALLMENT DATE'  ;
      
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;   
  
 Function sf_deferred_penalty_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
                       
 Begin

    SELECT  sum( case when nvl(b.DEFERRED_PENALTY_AMOUNT,0) -   nvl(b.PAID_DEFERRED_PENALTY_AMOUNT,0) > 0 then nvl(b.DEFERRED_PENALTY_AMOUNT,0) -   nvl(b.PAID_DEFERRED_PENALTY_AMOUNT,0) else 0 end)  DEFERRED_PENALTY_AMOUNT       
    into      ln_tutar
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_no   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.durum_kodu = 'A' and 
                   b.durum_kodu = 'A' and 
                   b.vade_tarih <=  ld_banka_tarihi and
                   repayment_type = 'INSTALLMENT DATE'  ;
      
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;  
 
 Function sf_deferred_tax_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
   ln_sales_tax_rate NUMBER ;                   
 Begin
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 

       ln_tutar :=  ROUND(( ( ( abs(nvl(sf_deferred_int_total(pn_kredi_hesap_no),0)) + abs(nvl(sf_deferred_delayed_int_total(pn_kredi_hesap_no),0)) + abs(nvl(sf_deferred_PENALTY_total(pn_kredi_hesap_no),0)) )  * ln_sales_tax_rate ) /100 ),2);
     
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;     
 
 Function sf_cumint_for_undue_principal(pn_kredi_hesap_no number) return number
 is
   ln_faiz                    number := 0;
   ld_banka_tarihi             date := pkg_muhasebe.banka_tarihi_bul;
   ld_max_vade_tarih      date :=null;
   ld_acilis_tarihi            date;
   ld_kredi_vade               date;
   ln_bakiye   number := 0;
   ln_faiz_orani               number := 0; 
   ln_gun_sayisi               number := 0;   
   ln_esas_gun_sayisi          number := 360;
   Begin
   
     -- seval.colak 03102022 eklendi 
   SELECT  case when  abs(round(nvl(birikmis_faiz_tutari,0),2))  > abs(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no)) then  abs(round(nvl(birikmis_faiz_tutari,0),2))  - abs(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no))
   else 0 end 
   into ln_faiz
   from cbs_hesap_kredi
   where hesap_no = pn_kredi_hesap_no;
   
      /*  -- seval.colak 03102022 kapatiyoruz  direk olarak bikimis faiz - pd faiz toplam farkini kullanacagiz.
   if  pkg_odeme_plan.sf_kredi_taksitli_mi(pn_kredi_hesap_no) ='E' then  
       
                select acilis_tarihi,
                       kredi_vade,
                       nvl(yearly_int_rate ,faiz_orani) faiz_orani,
                       nvl(esas_gun_sayisi,0),
                       abs(nvl(pkg_kredi.sf_bakiye_al (hesap_no),0)) - abs(nvl( pkg_odeme_plan.sf_pastdue_principal_total (hesap_no) ,0))  undue_principal_bakiye
                into   ld_acilis_tarihi, 
                       ld_kredi_vade,
                       ln_faiz_orani,                      
                       ln_esas_gun_sayisi,
                       ln_bakiye
                from cbs_hesap_kredi
                where hesap_no =pn_kredi_hesap_no;
           begin        -- bugunden onceki max vade tarihi bulunur.
                select max(vade_tarih)
                into   ld_max_vade_tarih
                from   cbs_hesap_kredi_taksit
                where hesap_no = pn_kredi_hesap_no and                     
                      trunc(vade_tarih) <= ld_banka_tarihi;
                    
                    if ld_max_vade_tarih is null then 
                        ld_max_vade_tarih := ld_acilis_tarihi ;
                    end if;
                    
            exception 
            when others then
                      ld_max_vade_tarih := ld_acilis_tarihi ;
            end;
                        
            ln_gun_sayisi := TRUNC(ld_banka_tarihi) -  TRUNC(ld_max_vade_tarih);
            
            begin  
            ln_faiz:=  abs(ROUND(ln_gun_sayisi*NVL(ln_bakiye,0)*NVL(ln_faiz_orani,0)/(ln_esas_gun_sayisi*100),2));
              exception 
            when others then
                      ln_faiz := 0 ;
            end;  
      else
           select   abs(round(nvl(birikmis_faiz_tutari,0),2)) 
           into ln_faiz    
           from cbs_hesap_kredi a
           where  hesap_No = pn_kredi_hesap_no and
                 a.durum_kodu = 'A' and 
                 a.kredi_Vade  > ld_banka_tarihi and
                 a.repayment_type = 'MATURITY DATE' ;
      
      end if;
       */
        return  abs(nvl(ln_faiz,0));  
         
    Exception when others then return 0 ;
 End;
 
 Function sf_undue_deferred_total(pn_kredi_hesap_no number) return number
 is
   ln_tutar number := 0;
   ld_banka_tarihi date := pkg_muhasebe.banka_tarihi_bul;
                       
 Begin

      select  sum( nvl(deferred_interest,0) +
                    nvl(deferred_tax,0) +
                    nvl(deferred_penalty_amount,0) +
                    nvl(deferred_delayed_interest,0)                   
                    )                     
      into      ln_tutar
             from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
             where a.hesap_no   = pn_kredi_hesap_no and  
                   a.hesap_no   = b.hesap_no and 
                   a.durum_kodu = 'A' and 
                   b.durum_kodu = 'A' and 
                   b.vade_tarih >  ld_banka_tarihi and
                   repayment_type = 'INSTALLMENT DATE'  ;
      
        return  abs(nvl(ln_tutar,0));  
         
    Exception when others then return 0 ;
 End;   
    -- E-O-M seval.colak 02092022  
END;
/

