create PACKAGE     PKG_TX2094
IS
   /******************************************************************************
     Name       : PKG_tx2094
     Created By : Temirlan Talapkerov
     Date          : 09.01.2019
     Purpose      : Credit register
  ******************************************************************************/
   PROCEDURE Kontrol_Sonrasi (pn_islem_no NUMBER); -- Islem giris kontrolden gectikten sonra cagrilir
   PROCEDURE Dogrulama_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulandiktan sonra cagrilir
   PROCEDURE Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir
   PROCEDURE Onay_Sonrasi (pn_islem_no NUMBER); -- Islem onaylandiktan sonra cagrilir
   PROCEDURE Reddetme_Sonrasi (pn_islem_no NUMBER); -- Islem reddedildikten sonra cagrilir
   PROCEDURE Tamam_Sonrasi (pn_islem_no NUMBER); -- Islem tamamlandiktan sonra cagrilir
   PROCEDURE Basim_Sonrasi (pn_islem_no NUMBER); -- Isleme iliskin formlar basildiktan sonra cagrilir
   PROCEDURE Muhasebelesme (pn_islem_no NUMBER); -- Islemin muhasebelesmesi icin cagrilir
   PROCEDURE Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
   PROCEDURE Iptal_Onay_Sonrasi (pn_islem_no NUMBER); -- Islem muhasebe iptalinin onay sonrasi cagrilir.
   PROCEDURE Iptal_Reddetme_Sonrasi (pn_islem_no NUMBER); -- Islem muhasebe iptalinin onay sonrasi cagrilir
   PROCEDURE Iptal_Muhasebelestir_Sonrasi (pn_islem_no NUMBER);
   FUNCTION pastdue_gunleri(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE, pn_dk_no NUMBER, ps_durum VARCHAR2) RETURN NUMBER; -- Cbs-142 
   FUNCTION pastdue_balance(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE, pn_dk_no NUMBER, ps_durum VARCHAR2) RETURN NUMBER; -- Cbs-142 
   FUNCTION transaction_type_restructure(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE) RETURN NUMBER; -- Cbs-142 
   FUNCTION kredi_tutaral(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE) RETURN CBS_HESAP_KREDI.tutar%TYPE; -- Cbs-142 
   FUNCTION previous_working_day(pd_tarih IN DATE DEFAULT SYSDATE) return DATE; -- Cbs-142 
   FUNCTION pastdue_balance_month(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE, ps_durum VARCHAR2) RETURN CBS_HESAP_BAKIYE.BAKIYE%TYPE; -- Cbs-142
   FUNCTION repayment_status(pn_hesap_no CBS_HESAP_KREDI.HESAP_NO%TYPE, ps_durum VARCHAR2) RETURN NUMBER; -- Cbs-142
END;

/

