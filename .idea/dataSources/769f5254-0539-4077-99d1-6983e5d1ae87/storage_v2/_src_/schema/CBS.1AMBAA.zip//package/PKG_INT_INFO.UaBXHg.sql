create PACKAGE     Pkg_Int_Info IS

TYPE CursorReferenceType IS REF CURSOR;

---------------------------------------------------------------------------------------------------------
FUNCTION MakeSubscription(  pn_customername IN VARCHAR2,
		 					ps_customeremail IN VARCHAR2,
							ps_subscribecd	 IN VARCHAR2,
							ps_subscribeperiod	 IN VARCHAR2,
		 					pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
---------------------------------------------------------------------------------------------------------
FUNCTION ConvertCurrency(ps_FromCurr IN VARCHAR2,
		 					pn_ToCurr IN VARCHAR2,
		 					pn_Amount IN VARCHAR2,
							ps_BankNBType	 IN VARCHAR2,
							ps_BuySellType	 IN VARCHAR2,
		 					pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
----------------------------------------------------------------------------------------
END;


/

