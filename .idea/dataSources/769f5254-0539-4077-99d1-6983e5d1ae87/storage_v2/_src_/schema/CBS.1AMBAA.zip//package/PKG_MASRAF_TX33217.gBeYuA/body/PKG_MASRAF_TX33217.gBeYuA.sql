create PACKAGE BODY     pkg_masraf_tx33217  IS

p_33217_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33217_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33217_KUR						  NUMBER;
p_33217_REFERENCE				  NUMBER;
p_33217_ISTA_KOD				  NUMBER;
p_33217_MUS_ACIK				  NUMBER;
p_33217_BANKA_ACIK				  NUMBER;
p_33217_ISLEM_SUBE				  NUMBER;
p_33217_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33217_FC_MASRAF_TUTARI		  NUMBER;
p_33217_LC_MASRAF_TUTAR			  NUMBER;
p_33217_MASRAF_HESAP_SUBE		  NUMBER;
p_33217_MASRAF_HESAP_NO			  NUMBER;
p_33217_LC_MAIL_CHARGE			  NUMBER;
p_33217_LC_COMM_CHARGE			  NUMBER;
p_33217_LC_CONF_COM				  NUMBER;
p_33217_LC_ISSUING_COM			  NUMBER;
p_33217_MAIL_CHARGE_GL			  NUMBER;
p_33217_COMM_CHARGE_GL			  NUMBER;
p_33217_CONF_COM_GL				  NUMBER;
p_33217_ISSUING_COM_GL			  NUMBER;
p_33217_UNCOMFIRM				  NUMBER;
p_33217_COMFIRM					  NUMBER;
p_33217_UNCOVER					  NUMBER;
p_33217_COVER					  NUMBER;
p_33217_FC						  NUMBER;
p_33217_LC						  NUMBER;
p_33217_MAILCOM_VAR				  NUMBER;
p_33217_COMMCOM_VAR				  NUMBER;
p_33217_CONFCOM_VAR				  NUMBER;
p_33217_ISSUINGCOM_VAR			  NUMBER;
p_33217_FC_MASRAF_ANA			  NUMBER;
p_33217_LC_MASRAF_ANA			  NUMBER;
p_33217_MAILCOM_EXP				  NUMBER;
p_33217_COMMCOM_EXP				  NUMBER;
p_33217_CONFCOM_EXP				  NUMBER;
p_33217_ISSUINGCOM_EXP			  NUMBER;
p_33217_MASRAF_GECICI_YOK 		  NUMBER;
p_33217_MASRAF_GECICI_VAR 		  NUMBER;

p_33217_LC_DISCREP_CHARGE		  NUMBER;
p_33217_DISCREP_CHARGE_GL		  NUMBER;
p_33217_DISCREP_VAR				  NUMBER;
p_33217_DISCREP_EXP				  NUMBER;

p_33217_LC_DOCDELV_CHARGE		  NUMBER;
p_33217_DOCDELV_CHARGE_GL		  NUMBER;
p_33217_DOCDELV_VAR				  NUMBER;
p_33217_DOCDELV_EXP				  NUMBER;

p_33217_LC_SERVICE_TAX			  NUMBER;
p_33217_FC_SERVICE_TAX			  NUMBER;
p_33217_SERVICE_TAX_VAR			  NUMBER;
p_33217_SERVICE_TAX_GL			  NUMBER;

/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2, pn_vs_no number) is
  begin

	Pkg_Masraf.onay_sonrasi(pn_islem_no, ps_ref,pn_vs_no, 'V', 'IMPISSUE');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   pkg_masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2, pn_vs_no number) is		-- Islem iptal edilemez
  begin
   pkg_masraf.Iptal_Onay_Sonrasi_grs_guncel(pn_islem_no, ps_ref, pn_vs_no );
/*    --status iptal konumuna getirilir ve tahsil edilen vs. oldu?u gibi b?rak?l?r...
    update cbs_masraf_ith_ihr
	   set durum = 'IPTAL'
	 where referans = ps_ref
	   and vs_no = pn_vs_no
	   and source = 'V'
	   and sira_no in (select sira_no from cbs_masraf_ith_ihr_isl
	                   where islem_no = pn_islem_no);
*/
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_islem_doviz         varchar2(3);
   ls_tahsil_doviz        varchar2(3);
   ls_hesap_doviz         varchar2(3);
   lb_taksit_var		  boolean := false;
   lb_vergi_var           boolean;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ln_top_bsmv 			  number := 0;
   ln_bsmv				  number := 0;
   ls_aciklama			  VARCHAR2(2000);
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no number;
   ln_tax_rate            NUMBER;
   ln_tax_amount          NUMBER;
   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID'
	 order by sira_no
	for update;
	row_masraf cur_masraf%rowtype;

    cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID';
	 ln_temp number;

    cursor cur_akr_detay is
    select *
	  from cbs_ith_akreditif
	 where referans = ls_referans;
	row_akr_detay  cur_akr_detay%rowtype;

   cursor cur_vs is
     select * from cbs_ith_vesaik_islem --akr_vesaik_sevk_islem
	  where tx_no = pn_islem_no;
	 row_vs cur_vs%rowtype;

   cursor cur_vso is
     select max(VADE_VALOR) vade from CBS_ITH_VESAIK_ODEME_ISLEM
	  where tx_no = pn_islem_no;
	 row_vso cur_vso%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;
   ls_acik_tutar_ref varchar2(100);
  BEGIN
	    ln_fis_no := pn_fis_no;
		open c_0;
		fetch c_0 into ln_temp;
		close c_0;
		if ln_temp <= 0 then
		  return;
		end if;

		open cur_vs;
		fetch cur_vs into row_vs;
		close cur_vs;

		open cur_vso;
		fetch cur_vso into row_vso;
		close cur_vso;

		ls_referans := row_vs.referans;

		open cur_akr_detay;
		fetch cur_akr_detay into row_akr_detay;
		close cur_akr_detay;

		if row_vs.masraf_zamani = 'T' then
		  return;
		end if;

		boolean_list(p_33217_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33217_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33217_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33217_ISSUINGCOM_VAR) := FALSE ;
		boolean_list(p_33217_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33217_LC_MASRAF_ANA) := FALSE ;
        boolean_list(p_33217_SERVICE_TAX_VAR) := FALSE;

		ls_islem_doviz := row_akr_detay.doviz_kodu;

		varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU) := 'AAA';
		IF row_vs.masraf_hesap_no is not null then
			 varchar_list(p_33217_MASRAF_HESAP_NO) := row_vs.masraf_hesap_no;
		     varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_vs.masraf_hesap_no);
			 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_vs.masraf_hesap_no);

		     varchar_list(p_33217_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_vs.masraf_hesap_no);
		END IF;

		IF varchar_list(p_33217_MASRAF_HESAP_NO) IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33217_MASRAF_HESAP_NO)) );
		   varchar_list(p_33217_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPMAILCHR');
		   varchar_list(p_33217_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPCOMCAT');
		   varchar_list(p_33217_CONF_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPDOCCONT');
		   varchar_list(p_33217_ISSUING_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'ISSUINGCOM');
		   varchar_list(p_33217_DOCDELV_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPDOCDELV');
		   varchar_list(p_33217_DISCREP_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'IMPDISCREP');
           varchar_list(p_33217_SERVICE_TAX_GL) := '';
		   if pkg_musteri.musteri_vergiden_muafmi(row_akr_detay.ithalatci_musteri) = 'H' then
		     lb_vergi_var := TRUE;
		   end if;
		ELSE
		   varchar_list(p_33217_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33217_COMM_CHARGE_GL) := '';
		   varchar_list(p_33217_CONF_COM_GL)	:= '';
		   varchar_list(p_33217_ISSUING_COM_GL) := '';
		   varchar_list(p_33217_DOCDELV_CHARGE_GL) := '';
		   varchar_list(p_33217_DISCREP_CHARGE_GL) := '';
           varchar_list(p_33217_SERVICE_TAX_GL) := '';
	    END IF;



		varchar_list(p_33217_ISLEM_SUBE) := row_vs.bolum_kodu;
		ls_referans := row_vs.referans;
		ls_istatistik_kodu := (TO_CHAR(NVL(row_akr_detay.pre_istatistik_kodu,0)) || NVL(row_akr_detay.istatistik_doviz_kodu,' ') || TO_CHAR(NVL(row_akr_detay.istatistik_kodu,0)));

     	varchar_list(p_33217_REFERENCE) := ls_referans;
	  --  varchar_list(p_33217_ISTA_KOD)  := ls_istatistik_kodu;


	    ls_acik_tutar_ref := rtrim(to_char(row_akr_detay.dosya_tutari,'999G999G999G999G999G999G999D99')) || ls_islem_doviz || '-' || ls_referans;

		IF varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33217_FC_MSRF_DOVIZ_KODU) := TRUE ;

		ELSE
		   boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33217_FC_MSRF_DOVIZ_KODU) := FALSE;

		END IF;
	    IF row_akr_detay.teminatli_mi='COVERED' THEN
		   boolean_list(p_33217_UNCOVER) := FALSE ;
		   boolean_list(p_33217_COVER)	:= TRUE ;
     	ELSE
		   boolean_list(p_33217_UNCOVER) := TRUE ;
		   boolean_list(p_33217_COVER)	:= FALSE ;
	    END IF;
		IF row_akr_detay.teyit_kodu='TEYITLI' THEN
			boolean_list(p_33217_UNCOMFIRM) := FALSE ;
			boolean_list(p_33217_COMFIRM)	:= TRUE ;
		ELSE
			boolean_list(p_33217_UNCOMFIRM) := TRUE ;
			boolean_list(p_33217_COMFIRM)	:= FALSE ;
		END IF;

		number_list(p_33217_LC_COMM_CHARGE) := 0;
		number_list(p_33217_LC_MAIL_CHARGE) := 0;
		number_list(p_33217_LC_CONF_COM) := 0;
		number_list(p_33217_LC_ISSUING_COM) := 0;
		number_list(p_33217_LC_DISCREP_CHARGE) := 0;
		number_list(p_33217_LC_DOCDELV_CHARGE) := 0;
        number_list(p_33217_LC_SERVICE_TAX)   := 0;
        number_list(p_33217_FC_SERVICE_TAX)   := 0;

		number_list(p_33217_LC_MASRAF_TUTAR) := 0;
		number_list(p_33217_FC_MASRAF_TUTARI) := 0;
		varchar_list(p_33217_MAILCOM_EXP)	:='';
		varchar_list(p_33217_COMMCOM_EXP)	:='';
	    varchar_list(p_33217_CONFCOM_EXP)	:='';
	    varchar_list(p_33217_ISSUINGCOM_EXP):='';
		varchar_list(p_33217_DISCREP_EXP)	:='';
		varchar_list(p_33217_DOCDELV_EXP)	:='';

		IF ls_islem_doviz = Pkg_Genel.LC_AL THEN
		  boolean_list(p_33217_LC) := TRUE;
	      boolean_list(p_33217_FC) := FALSE;
		ELSE
		  boolean_list(p_33217_LC) := FALSE;
	      boolean_list(p_33217_FC) := TRUE;
		END IF;
		ls_aciklama := 'IMPORT DOCUMENTS ENTRY  ' || ls_acik_tutar_ref;
		varchar_list(p_33217_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33217_MUS_ACIK) :=varchar_list(p_33217_BANKA_ACIK) ;

		IF row_vs.masraf_hesap_no IS NOT NULL THEN  --masraf hesab? girilmi?se
--		    if varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU) =pkg_genel.lc_al then
--			   number_list(p_33217_KUR) := Pkg_Komisyon_Kur.KUR_to_lc(varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU),1);
--			else
        	   number_list(p_33217_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU),1);
--			end if;

		     --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33217_MASRAF_HESAP_NO));
        END IF;
	open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  ln_bsmv := 0;
	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF nvl(row_masraf.tahsil_edilemeyen,0) > 0  THEN
		  IF pkg_ithalat.masraf_kontrol_yap(row_masraf.ODEYECEK) = 'Y'  THEN
		      ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
			  IF row_masraf.masraf_kodu = 'IMPCOMCAT'  THEN  --haberle?me
			     boolean_list(p_33217_COMMCOM_VAR) := TRUE ;
--			     IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
--	            	number_list(p_33217_LC_COMM_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--	             ELSE
  					number_list(p_33217_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				 END IF;
				 IF NVL(row_masraf.bsmv,0) > 0 THEN
				     ln_bsmv := number_list(p_33217_LC_COMM_CHARGE);
				 END IF;
			   --bu iki degisken ile hesabin odemeyi alabilmek icin yeterli olup olmadigi arastirilacak
			   --eger yeterli miktar varsa, toplam satir icin toplanacak
				 ln_borc_tutar := number_list(p_33217_LC_COMM_CHARGE);--number_list(p_33217_HABR_MDV);
				 ln_borc_trl := number_list(p_33217_LC_COMM_CHARGE);
			     varchar_list(p_33217_COMMCOM_EXP) := ls_referans||' Import Communication Charge' ;
		      ELSIF row_masraf.masraf_kodu = 'IMPMAILCHR' THEN   --posta
				  boolean_list(p_33217_MAILCOM_VAR) := TRUE ;
--				  IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
--	            	 number_list(p_33217_LC_MAIL_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--	              ELSE
                	 number_list(p_33217_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  IF NVL(row_masraf.bsmv,0) > 0 THEN
					 ln_bsmv := number_list(p_33217_LC_MAIL_CHARGE);
				  END IF;
				  ln_borc_tutar := number_list(p_33217_LC_MAIL_CHARGE);--number_list(p_33217_POSTA_MDV);
				  ln_borc_trl := number_list(p_33217_LC_MAIL_CHARGE);
				  varchar_list(p_33217_MAILCOM_EXP)	:=ls_referans||' Import Mail Charge';

			  ELSIF  row_masraf.masraf_kodu = 'IMPDOCCONT' THEN   --Teyit
			      boolean_list(p_33217_CONFCOM_VAR) := TRUE ;
--			   	  IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
--	            	 number_list(p_33217_LC_CONF_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--	              ELSE
                	 number_list(p_33217_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  IF NVL(row_masraf.bsmv,0) > 0 THEN
				    ln_bsmv := number_list(p_33217_LC_CONF_COM);
				  END IF;
				  ln_borc_tutar := number_list(p_33217_LC_CONF_COM);--number_list(p_33217_POSTA_MDV);
				  ln_borc_trl := number_list(p_33217_LC_CONF_COM);
			      varchar_list(p_33217_CONFCOM_EXP)	:=ls_referans||' Import Checking of Documents ' ;

		      ELSIF row_masraf.masraf_kodu = 'IMPDOCDELV' THEN   --posta
				  boolean_list(p_33217_DOCDELV_VAR) := TRUE ;
--				  IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
--	            	 number_list(p_33217_LC_DOCDELV_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--	              ELSE
                	 number_list(p_33217_LC_DOCDELV_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  IF NVL(row_masraf.bsmv,0) > 0 THEN
					 ln_bsmv := number_list(p_33217_LC_DOCDELV_CHARGE);
				  END IF;
				  ln_borc_tutar := number_list(p_33217_LC_DOCDELV_CHARGE);--number_list(p_33217_POSTA_MDV);
				  ln_borc_trl := number_list(p_33217_LC_DOCDELV_CHARGE);
				  varchar_list(p_33217_DOCDELV_EXP)	:=ls_referans||' Import Documents Delivering' ;

		      ELSIF row_masraf.masraf_kodu = 'IMPDISCREP' THEN   --posta
				  boolean_list(p_33217_DISCREP_VAR) := TRUE ;
--				  IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
--	            	 number_list(p_33217_LC_DISCREP_CHARGE) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
--	              ELSE
                	 number_list(p_33217_LC_DISCREP_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
--				  END IF;
				  IF NVL(row_masraf.bsmv,0) > 0 THEN
					 ln_bsmv := number_list(p_33217_LC_DISCREP_CHARGE);
				  END IF;
				  ln_borc_tutar := number_list(p_33217_LC_DISCREP_CHARGE);--number_list(p_33217_POSTA_MDV);
				  ln_borc_trl := number_list(p_33217_LC_DISCREP_CHARGE);
				  varchar_list(p_33217_DISCREP_EXP)	:=ls_referans||' Import Discrepancy Fee' ;

			  /* ELSIF row_masraf.masraf_kodu =  'ISSUINGCOM' THEN  --Kabul kredisi TAKS?TL? OLUR
			       boolean_list(p_33217_ISSUINGCOM_VAR) := TRUE ;
			       ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				   IF nvl(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   --daha fazlas? veya ayn?s? ?nceden al?nm??
					   --hi? bir ?ey yapma
					   ln_tahsil_tutar := 0;
				   ELSE
					  lb_taksit_var := true;
					  open cur_taksitler;
					  loop
					    fetch cur_taksitler into row_taksit;
						exit when cur_taksitler%notfound;

							ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
							IF boolean_list(p_33217_LC_MSRF_DOVIZ_KODU) THEN
	            	           number_list(p_33217_LC_ISSUING_COM) := Pkg_Komisyon_Kur.KUR_to_LC(ls_tahsil_doviz, ln_tahsil_tutar);
	                        ELSE
                			   number_list(p_33217_LC_ISSUING_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
						    END IF;
 				            IF NVL(row_taksit.bsmv,0) > 0 THEN
						       ln_bsmv := number_list(p_33217_LC_ISSUING_COM);
  						    END IF;
 						    ln_borc_tutar := number_list(p_33217_LC_ISSUING_COM);--number_list(p_33217_TEYIT_MDV);
						    ln_borc_trl := number_list(p_33217_LC_ISSUING_COM);
                            varchar_list(p_33217_ISSUINGCOM_EXP)	:='ISSUING COM. INSTALLMENT COLLECTIONS' || ls_referans;

						IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN
						    boolean_list(p_33217_COMMCOM_VAR) := FALSE ;
							boolean_list(p_33217_MAILCOM_VAR) := FALSE ;
							boolean_list(p_33217_CONFCOM_VAR) := FALSE ;
							if  nvl(row_vs.masraf_zamani,'B')='B' then
							  boolean_list(p_33217_MASRAF_GECICI_VAR) := TRUE;
							  boolean_list(p_33217_MASRAF_GECICI_YOK) := FALSE;
							else
							  boolean_list(p_33217_MASRAF_GECICI_VAR) := FALSE;
							  boolean_list(p_33217_MASRAF_GECICI_YOK) := TRUE;
							end if;
						    ln_fis_no:=pkg_muhasebe.fis_kes ( 33217, null, pn_islem_no, varchar_list, number_list,
										    			  	  date_list, boolean_list, null, false, ln_fis_no, null);


						     update cbs_masraf_ith_ihr_isl
							   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
							       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
						     where current of cur_masraf;

  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

							 update cbs_masraf_taksit_islem
							   set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
							       odenen_tutar = taksit_tutari
							 where current of cur_taksitler;
							 	    if nvl(row_vs.masraf_zamani,'B') = 'B' then
									   pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33217_LC_CONF_COM), row_vs.masraf_hesap_no,
																   row_vso.vade, 'E');
									 end if;
                            ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
							number_list(p_33217_LC_MASRAF_TUTAR) := number_list(p_33217_LC_MASRAF_TUTAR) + ln_borc_trl;
							number_list(p_33217_FC_MASRAF_TUTARI) := number_list(p_33217_FC_MASRAF_TUTARI) + ln_borc_tutar;
							ln_top_bsmv := ln_top_bsmv + ln_bsmv;
						END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar*/
			  ELSE
			    CLOSE cur_masraf;
		 	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '341' ||  pkg_hata.getDelimiter || row_masraf.masraf_kodu || pkg_hata.getUCPOINTER);
			  END IF;
			  IF NOT lb_taksit_var THEN
			   IF ln_son_bakiye >= ln_borc_tutar + Pkg_Masraf.bsmv_hesapla(ln_bsmv) THEN --bakiye yeterliyse satiri ekle
			      IF ln_tahsil_tutar <> 0 THEN

			         ln_fis_no:=pkg_muhasebe.fis_kes ( 33217, null, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  null, false, ln_fis_no, null);

                      IF boolean_list(p_33217_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33217_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33217_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33217_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33217_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33217_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33217_ISSUINGCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33217_ISSUINGCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33217_DISCREP_VAR) = TRUE THEN
					  	 boolean_list(p_33217_DISCREP_VAR) := FALSE;
					  ELSIF boolean_list(p_33217_DOCDELV_VAR) = TRUE THEN
					  	 boolean_list(p_33217_DOCDELV_VAR) := FALSE;
					  END IF;

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);
                       update cbs_masraf_ith_ihr_isl
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;

					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar - Pkg_Masraf.bsmv_hesapla(ln_bsmv);
					  number_list(p_33217_LC_MASRAF_TUTAR) := number_list(p_33217_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33217_FC_MASRAF_TUTARI) := number_list(p_33217_FC_MASRAF_TUTARI) + ln_borc_tutar;
					  ln_top_bsmv := ln_top_bsmv + ln_bsmv;

				 END IF;
				 ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
				    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '644' ||  Pkg_Hata.getDelimiter || LTRIM(TO_CHAR(ln_borc_tutar, '999,999,999,999,999,999,999.99')) || Pkg_Hata.GetDELIMITER || varchar_list(p_33217_MASRAF_HESAP_NO) || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_son_bakiye, '999,999,999,999,999,999,999.99')) || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	        END IF; --ihracat?? ?demesi
	   END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;
	boolean_list(p_33217_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33217_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33217_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33217_ISSUINGCOM_VAR) := FALSE ;
	boolean_list(p_33217_DISCREP_VAR) := FALSE ;
	boolean_list(p_33217_DOCDELV_VAR) := FALSE ;

    pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_tax_rate);
	ln_tax_amount := (nvl(number_list(p_33217_LC_COMM_CHARGE),0) + nvl(number_list(p_33217_LC_MAIL_CHARGE),0)) * ln_tax_rate / 100;
	if lb_vergi_var and ln_tax_amount != 0 then
	  number_list(p_33217_LC_SERVICE_TAX)   := ln_tax_amount;
      number_list(p_33217_FC_SERVICE_TAX)   := ln_tax_amount/Pkg_Kur.MB_dak_to_lc(varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU),1);
   	  boolean_list(p_33217_SERVICE_TAX_VAR) := TRUE;
	else
	  boolean_list(p_33217_SERVICE_TAX_VAR) := FALSE;
	end if;

	IF number_list(p_33217_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33217_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33217_LC_MASRAF_TUTAR)) ;
	   number_list(p_33217_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33217_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33217_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33217_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33217_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33217_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33217_LC_MASRAF_ANA) := TRUE ;

		END IF;

	       ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33217, NULL, pn_islem_no,
				    					  	 varchar_list, number_list,
											 date_list, boolean_list,
								    	  	 NULL, FALSE, ln_fis_no, NULL);

	END IF;
	pn_fis_no := ln_fis_no;
 END;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebe_Sonrasi(pn_islem_no number, ps_ref varchar2, pn_vs_no number) is
  begin
    pkg_masraf.Muhasebe_Sonrasi_grs_guncel(pn_islem_no, ps_ref, pn_vs_no);
  End;
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/
 BEGIN
    p_33217_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33217_FC_MSRF_DOVIZ_KODU');
	p_33217_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33217_LC_MSRF_DOVIZ_KODU');
	p_33217_KUR						  := Pkg_Muhasebe.parametre_index_bul('33217_KUR');
	p_33217_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33217_REFERENCE');
	p_33217_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33217_ISTA_KOD');
	p_33217_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33217_MUS_ACIK');
	p_33217_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33217_BANKA_ACIK');
	p_33217_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33217_ISLEM_SUBE');
	p_33217_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33217_MASRAF_HESAP_DOVIZ_KODU');
	p_33217_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33217_FC_MASRAF_TUTARI');
	p_33217_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_MASRAF_TUTAR');
	p_33217_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33217_MASRAF_HESAP_SUBE');
	p_33217_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33217_MASRAF_HESAP_NO');
	p_33217_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_MAIL_CHARGE');
	p_33217_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_COMM_CHARGE');
	p_33217_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33217_LC_CONF_COM');
	p_33217_LC_ISSUING_COM			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_ISSUING_COM');
	p_33217_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33217_MAIL_CHARGE_GL');
	p_33217_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33217_COMM_CHARGE_GL');
	p_33217_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33217_CONF_COM_GL');
	p_33217_ISSUING_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33217_ISSUING_COM_GL');
	p_33217_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33217_UNCOMFIRM');
	p_33217_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33217_COMFIRM');
	p_33217_UNCOVER					  := Pkg_Muhasebe.parametre_index_bul('33217_UNCOVER');
	p_33217_COVER					  := Pkg_Muhasebe.parametre_index_bul('33217_COVER');
	p_33217_FC						  := Pkg_Muhasebe.parametre_index_bul('33217_FC');
	p_33217_LC						  := Pkg_Muhasebe.parametre_index_bul('33217_LC');
	p_33217_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33217_MAILCOM_VAR');
	p_33217_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33217_COMMCOM_VAR');
	p_33217_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33217_CONFCOM_VAR');
	p_33217_ISSUINGCOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33217_ISSUINGCOM_VAR');
	p_33217_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33217_FC_MASRAF_ANA');
	p_33217_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_MASRAF_ANA');
	p_33217_MAILCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33217_MAILCOM_EXP');
	p_33217_COMMCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33217_COMMCOM_EXP');
	p_33217_CONFCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33217_CONFCOM_EXP');
	p_33217_ISSUINGCOM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33217_ISSUINGCOM_EXP');
    p_33217_MASRAF_GECICI_YOK         := Pkg_Muhasebe.parametre_index_bul('33217_MASRAF_GECICI_YOK');
	p_33217_MASRAF_GECICI_VAR         := Pkg_Muhasebe.parametre_index_bul('33217_MASRAF_GECICI_VAR');

    p_33217_LC_DISCREP_CHARGE		  := Pkg_Muhasebe.parametre_index_bul('33217_LC_DISCREP_CHARGE');
    p_33217_DISCREP_CHARGE_GL		  := Pkg_Muhasebe.parametre_index_bul('33217_DISCREP_CHARGE_GL');
    p_33217_DISCREP_VAR				  := Pkg_Muhasebe.parametre_index_bul('33217_DISCREP_VAR');
    p_33217_DISCREP_EXP				  := Pkg_Muhasebe.parametre_index_bul('33217_DISCREP_EXP');

    p_33217_LC_DOCDELV_CHARGE		  := Pkg_Muhasebe.parametre_index_bul('33217_LC_DOCDELV_CHARGE');
    p_33217_DOCDELV_CHARGE_GL		  := Pkg_Muhasebe.parametre_index_bul('33217_DOCDELV_CHARGE_GL');
    p_33217_DOCDELV_VAR				  := Pkg_Muhasebe.parametre_index_bul('33217_DOCDELV_VAR');
    p_33217_DOCDELV_EXP				  := Pkg_Muhasebe.parametre_index_bul('33217_DOCDELV_EXP');

	p_33217_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33217_LC_SERVICE_TAX');
	p_33217_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33217_FC_SERVICE_TAX');
	p_33217_SERVICE_TAX_VAR			  := Pkg_Muhasebe.parametre_index_bul('33217_SERVICE_TAX_VAR');
	p_33217_SERVICE_TAX_GL			  := Pkg_Muhasebe.parametre_index_bul('33217_SERVICE_TAX_GL');

 END;
/

