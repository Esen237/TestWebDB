create PACKAGE BODY     PKG_TX1401 IS
p_1401_BOLUM_KODU number;        	 --BOLUM KODU
p_1401_ISLEM_SUBE number;            --??LEM ?UBE
p_1401_TEMINAT_TUTARI_LC number;       --TEMINAT TUTARI LC
p_1401_TUTAR_ARTIYOR number;           --TEMINAT TUTARI ARTIRILIYOR
p_1401_TUTAR_AZALIYOR number;          --TEMINAT TUTARI AZALTILIYOR
p_1401_DOVIZ_KODU number;        	   --TEMINAT D?VIZ_KODU
p_1401_KUR number;        			   --KUR
p_1401_ACIKLAMA number;        		   --A?IKLAMA
p_1401_TEMINAT_TUTARI_FC number;       --TEMINAT TUTARI FC
p_1401_DURUM_KODU_KAPALI number;

p_1401_TEMINAT_TUR_IPOTEK number;
p_1401_TEMINAT_TUR_KEFALET number;
P_1401_TEMINAT_TUR_REHIN number;
P_1401_TEMINAT_TUR_TEMLIK number;
P_1401_TEMINAT_TUR_SIGORTA_POL number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is 
  -- ASKHATS CQ5791 added check to disallow closing collateral, if it was already closed  at approving phase to avoid disbalance
  -- BOM ASKHATS CQ5791
    cursor cur_KREDI_TEMINAT_GIRIS is 
    select *
    from CBS_KREDI_TEMINAT_GIRIS
    where tx_no = pn_islem_no;
    
    ls_status varchar2(10);
    row_KREDI_TEMINAT_GIRIS cur_KREDI_TEMINAT_GIRIS%rowtype;
  begin
    open cur_KREDI_TEMINAT_GIRIS;
      fetch cur_KREDI_TEMINAT_GIRIS into row_KREDI_TEMINAT_GIRIS;
    close cur_KREDI_TEMINAT_GIRIS;
    
    SELECT DURUM INTO ls_status FROM CBS_KREDI_TEMINAT_TANIM WHERE MUSTERI_NO = row_KREDI_TEMINAT_GIRIS.MUSTERI_NO AND TEMINAT_SIRA_NO = row_KREDI_TEMINAT_GIRIS.TEMINAT_SIRA_NO;
    
    IF row_KREDI_TEMINAT_GIRIS.DURUM = 'KAPALI' AND ls_status = 'KAPALI' THEN
      Raise_application_error(-20100, pkg_hata.getUCPOINTER || '6029' || pkg_hata.getUCPOINTER);
    END IF;
  -- EOM ASKHATS CQ5791
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin

  Raise_application_error(-20100,pkg_hata.getUCPOINTER || '647' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  /*
   update CBS_KREDI_TEMINAT_TANIM
    set DURUM='ACIK'
    where (MUSTERI_NO, TEMINAT_SIRA_NO) in (select MUSTERI_NO, TEMINAT_SIRA_NO
		  			   					    from CBS_KREDI_TEMINAT_GIRIS
											where TX_NO=PN_ISLEM_NO);
  */
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is

  	ln_fis_no number:=0;
	ln_fis_no_temp number;
	ln_eski_tutar number;
	ln_temp number;

    varchar_list	pkg_muhasebe.varchar_array;
    number_list		pkg_muhasebe.number_array;
    date_list		pkg_muhasebe.date_array;
    boolean_list	pkg_muhasebe.boolean_array;

	cursor cur_KREDI_TEMINAT_GIRIS is
	  select *
      from CBS_KREDI_TEMINAT_GIRIS
	  where tx_no = pn_islem_no;
	  row_KREDI_TEMINAT_GIRIS cur_KREDI_TEMINAT_GIRIS%rowtype;

  Begin

   open cur_KREDI_TEMINAT_GIRIS;
    fetch cur_KREDI_TEMINAT_GIRIS into row_KREDI_TEMINAT_GIRIS;
   close cur_KREDI_TEMINAT_GIRIS;

   select tutar
   into ln_eski_tutar
   from CBS_KREDI_TEMINAT_TANIM
   where MUSTERI_NO=row_KREDI_TEMINAT_GIRIS.musteri_no
     and TEMINAT_SIRA_NO=row_KREDI_TEMINAT_GIRIS.TEMINAT_SIRA_NO;

	   boolean_list(p_1401_TUTAR_ARTIYOR)      := FALSE;
       boolean_list(p_1401_TUTAR_AZALIYOR)     := FALSE;
       number_list(p_1401_TEMINAT_TUTARI_FC) :=row_KREDI_TEMINAT_GIRIS.TUTAR;

    IF row_KREDI_TEMINAT_GIRIS.TUTAR>LN_ESKI_TUTAR THEN
	   boolean_list(p_1401_TUTAR_ARTIYOR)      := TRUE;
       boolean_list(p_1401_TUTAR_AZALIYOR)     := FALSE;

	   number_list(p_1401_TEMINAT_TUTARI_FC) := row_KREDI_TEMINAT_GIRIS.TUTAR-LN_ESKI_TUTAR;

	ELSIF row_KREDI_TEMINAT_GIRIS.TUTAR<LN_ESKI_TUTAR THEN
	   boolean_list(p_1401_TUTAR_ARTIYOR)      := FALSE;
       boolean_list(p_1401_TUTAR_AZALIYOR)     := TRUE;

	   number_list(p_1401_TEMINAT_TUTARI_FC) := LN_ESKI_TUTAR-row_KREDI_TEMINAT_GIRIS.TUTAR;
	END IF;

	if row_KREDI_TEMINAT_GIRIS.durum='KAPALI' then
	   boolean_list(p_1401_DURUM_KODU_KAPALI):= TRUE;
	  else
	   boolean_list(p_1401_DURUM_KODU_KAPALI):= FALSE;
	end if;


      number_list(p_1401_TEMINAT_TUTARI_LC) := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU,PKG_GENEL.LC_AL,null,number_list(p_1401_TEMINAT_TUTARI_FC),1,null,null,'N','A');


    boolean_list(p_1401_TEMINAT_TUR_IPOTEK) := FALSE;
	boolean_list(p_1401_TEMINAT_TUR_KEFALET) := FALSE;
	boolean_list(P_1401_TEMINAT_TUR_REHIN) := FALSE;
	boolean_list(P_1401_TEMINAT_TUR_TEMLIK) := FALSE;
	boolean_list(P_1401_TEMINAT_TUR_SIGORTA_POL) := FALSE;

	CASE row_KREDI_TEMINAT_GIRIS.ANA_TEMINAT_KODU

		 WHEN '02' THEN --IPOTEK ISE
		   boolean_list(p_1401_TEMINAT_TUR_IPOTEK) := TRUE;
		 WHEN '03' THEN --KEFALET ISE
		   boolean_list(p_1401_TEMINAT_TUR_KEFALET) := TRUE;
		 WHEN '04' THEN --REHIN ise
           boolean_list(p_1401_TEMINAT_TUR_REHIN) := TRUE;
		 WHEN '05' THEN --TEMLIK ise
           boolean_list(p_1401_TEMINAT_TUR_TEMLIK) := TRUE;
		 WHEN '10' THEN --SIGORTA POLICESI ise
           boolean_list(p_1401_TEMINAT_TUR_SIGORTA_POL) := TRUE;

		 ELSE
		 null;

	END CASE;

    varchar_list(p_1401_DOVIZ_KODU) := row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU;
    number_list(p_1401_KUR) := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(row_KREDI_TEMINAT_GIRIS.DOVIZ_KODU,PKG_GENEL.LC_AL,null,1,1,null,null,'N','A');
    varchar_list(p_1401_ACIKLAMA) := row_KREDI_TEMINAT_GIRIS.ACIKLAMA;
    varchar_list(p_1401_ISLEM_SUBE)     := pkg_tx.Amir_BolumKodu_Al(pn_islem_no);

  if 	boolean_list(p_1401_TUTAR_ARTIYOR)= TRUE
     or boolean_list(p_1401_TUTAR_AZALIYOR)= TRUE
	 or boolean_list(p_1401_DURUM_KODU_KAPALI)= TRUE then
	ln_fis_no:=pkg_muhasebe.fis_kes (1401,
   				 	              	 null,
   		 						  	 pn_islem_no,
   								  	 varchar_list ,
   								  	 number_list  ,
   								  	 date_list    ,
   								  	 boolean_list ,
   								  	 pkg_muhasebe.BANKA_TARIHI_BUL,
   								  	 false,
   								  	 0,
   								  	 'Modification of non-cash Collateral' );

	pkg_muhasebe.muhasebelestir(ln_fis_no);
  end if;
	--??lemin onaylanmas?, muhasebede kullan?lacak eski tutar?n ezilmemesi i?in
	-- muhasebe sonras?nda yap?l?yor.
	muhasebe_sonrasi_onay(row_KREDI_TEMINAT_GIRIS.TX_NO);

  End;

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number) is
   begin
    null;
  end;


 Procedure  Guncelleme_Kontrolu(pn_islem_no NUMBER,
  			 					ps_block	 VARCHAR2,
								ps_rowid   	 VARCHAR2,
		  				   		ps_column  	 VARCHAR2,
  		   				   		pd_column  	 VARCHAR2,
								ps_oldvalue IN OUT VARCHAR2) is
	   Guncellenmis_Exception			   exception;
	   ln_retval						   NUMBER:=0;
	   ls_sqlstr						   VARCHAR2(2000);
	   ls_sql_template					   VARCHAR2(2000);
	   ls_source_table					   VARCHAR2(30);
	   ls_dest_table					   VARCHAR2(30);
  Begin

  --Template of SQL

   if ps_block='CBS_KREDI_TEMINAT_TANIM' then
   	   --TODO 1: Set the source and destination table names
   	   ls_source_table:='CBS_KREDI_TEMINAT_GIRIS';
	   ls_dest_table:='CBS_KREDI_TEMINAT_TANIM';
	   if ps_column<>'TX_NO' then
	   	   --TODO 2: Set the Primary Key Count (Default 1)
	   	   ls_sql_template:=pkg_guncel.DifferenceTemplateSingleRecord(2);
		   --TODO 3: Do not alter until next TODO :)
	   	   ls_sql_template:=Replace(ls_sql_template,'DESTINATION_TABLE',ls_dest_table);
   		   ls_sql_template:=Replace(ls_sql_template,'DESTINATION_COLUMN',pd_column);
		   ls_sql_template:=Replace(ls_sql_template,'SOURCE_TABLE',ls_source_table);
   		   ls_sql_template:=Replace(ls_sql_template,'SOURCE_COLUMN',ps_column);
		   ls_sql_template:=Replace(ls_sql_template,'SOURCE_ROWID',ps_rowid);
		   --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK
   		   ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK1','MUSTERI_NO');
   		   ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK1','MUSTERI_NO');
		   ls_sql_template:=Replace(ls_sql_template,'DESTINATION_PK2','TEMINAT_SIRA_NO');
   		   ls_sql_template:=Replace(ls_sql_template,'SOURCE_PK2','TEMINAT_SIRA_NO');

		   --insert into cbs_yphavale_test values(ls_sql_template);
		   execute immediate ls_sql_template into ln_retval,ps_oldvalue;
	   end if;
    end if;

	  if ln_retval<>1 then
	  	  Raise_Application_Error(-20100,'Not Updated');
	  end if;
 End;


  Procedure KrediTeminatBilgiAktar(pn_txno number,ps_musteri_no number,ps_teminat_sira_no varchar2) is
   BEGIN
    --Al?nan garanti sat?rlar? g?ncelleme amac?yla i?lem tablosuna al?n?yor...
    insert into CBS_KREDI_TEMINAT_GIRIS
   	 (TX_NO, MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU, TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA, IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI, IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR, IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO, ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI, ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR, ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI, EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI, EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI, EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI, MENKUL_REHNI_BIRIM, MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI, MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI, TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE, TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO, GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU, EMTEA_REHNI_REHIN_TARIHI,TEMLIK_ANLASMA_TARIHI,KEFALET_VADE_TARIHI, ANLASMA_NO)
   	 (select pn_txno, MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU, TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA, IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI, IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR, IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO, ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI, ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR, ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI, EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI, EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI, EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI, MENKUL_REHNI_BIRIM, MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI, MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI, TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE, TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO, GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU, EMTEA_REHNI_REHIN_TARIHI,TEMLIK_ANLASMA_TARIHI,KEFALET_VADE_TARIHI, ANLASMA_NO
   	  from CBS_KREDI_TEMINAT_TANIM
   	  where MUSTERI_NO=ps_musteri_no and TEMINAT_SIRA_NO=ps_teminat_sira_no);
  END;

  Procedure muhasebe_sonrasi_onay(pn_islem_no number) is
    ln_MUSTERI_NO number;
    ln_TEMINAT_SIRA_NO number;
    ln_TUTAR number;
    my_exception exception;
   Begin

   select MUSTERI_NO, TEMINAT_SIRA_NO,TUTAR
	into ln_MUSTERI_NO, ln_TEMINAT_SIRA_NO,ln_TUTAR
  	from CBS_KREDI_TEMINAT_GIRIS
	where TX_NO=pn_islem_no;

  --??lemdeki kullan?m tutar?
  --onay esnas?ndaki kulln?m tutar?ndan k???k ise i?lemi ONAYLAMA !!!
 if nvl(ln_TUTAR,0)<pkg_teminat.sf_diger_gayrin_kullan_tutari(ln_MUSTERI_NO,ln_TEMINAT_SIRA_NO,null,'E') then

  raise my_exception;

 else

  update CBS_KREDI_TEMINAT_TANIM
	set (  MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU,
  TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA,
  IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI,
  IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR,
  IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL, TASIT_REHNI_PLAKA_NO,
  TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI, TASIT_REHNI_SIGORTA_SIRKETI,
  TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI, ALTIN_REHNI_AYAR,
  ALTIN_REHNI_FATURA_NO, ALTIN_REHNI_BIRIM,ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI,
  ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR,
  ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI,EMTEA_REHNI_BIRIM, EMTEA_REHNI_MIKTARI,
  EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI,
  EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI,
  MENKUL_REHNI_BIRIM,MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI,
  MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI,
  TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI, SIG_TEMINATI_SIGORTA_SIRKETI,
  SIG_TEMINATI_POLICE_BAS_TAR, SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE,
  TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO,
  GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU, EMTEA_REHNI_REHIN_TARIHI,
  TEMLIK_ANLASMA_TARIHI, KEFALET_VADE_TARIHI, ANLASMA_NO)
	=(select MUSTERI_NO, TEMINAT_SIRA_NO, DURUM, ANA_TEMINAT_KODU, DETAY_TEMINAT_KODU,
             TUTAR, ACIKLAMA, IPOTEK_CINSI, IPOTEK_YERI, IPOTEK_MALIKI, IPOTEK_PAFTA,
             IPOTEK_ADA, IPOTEK_PARSEL, IPOTEK_EXPERTIZ_DEGERI, IPOTEK_EXPERTIZ_TARIHI,
             IPOTEK_DERECE, IPOTEK_SIGORTA_SIRKETI, IPOTEK_SIGORTA_BAS_TAR,
             IPOTEK_SIGORTA_VADESI, TASIT_REHNI_MARKA, TASIT_REHNI_MODEL,
             TASIT_REHNI_PLAKA_NO, TASIT_REHNI_SASI_NO, TASIT_REHNI_REHIN_TARIHI,
             TASIT_REHNI_SIGORTA_SIRKETI, TASIT_REHNI_SIG_BAS_TAR, TASIT_REHNI_SIGORTA_VADESI,
             ALTIN_REHNI_AYAR, ALTIN_REHNI_FATURA_NO,ALTIN_REHNI_BIRIM, ALTIN_REHNI_MIKTARI, ALTIN_REHNI_TESLIM_TARIHI,
             ALTIN_REHNI_REHIN_TARIHI, ALTIN_REHNI_SIGORTA_SIRKETI, ALTIN_REHNI_SIG_BAS_TAR,
             ALTIN_REHNI_SIGORTA_VADESI, EMTEA_REHNI_CINSI, EMTEA_REHNI_BIRIM,EMTEA_REHNI_MIKTARI,
             EMTEA_REHNI_FATURA_DEGERI, EMTEA_REHNI_YER, EMTEA_REHNI_SIGORTA_SIRKETI,
             EMTEA_REHNI_SIG_BAS_TAR, EMTEA_REHNI_SIGORTA_VADESI, MENKUL_REHNI_CINSI,
             MENKUL_REHNI_BIRIM,MENKUL_REHNI_MIKTARI, MENKUL_REHNI_YERI,
             MENKUL_REHNI_SIGORTA_SIRKETI, MENKUL_REHNI_SIG_BAS_TAR, MENKUL_REHNI_SIGORTA_VADESI,
             TEMLIK_CINSI, TEMLIK_VADESI, SIG_TEMINATI_ADI_UNVANI,
             SIG_TEMINATI_SIGORTA_SIRKETI, SIG_TEMINATI_POLICE_BAS_TAR,
             SIG_TEMINATI_POLICE_VADESI, TEMINAT_MEKTUBU_BANKA_SUBE,
             TEMINAT_MEKTUBU_REFERANS_NO, TEMINAT_MEKTUBU_VADE, KEFALET_KEFIL_MUSTERI_NO,
             GIRIS_TARIHI, DOVIZ_KODU, IPOTEK_IPOTEK_TARIHI, BOLUM_KODU,
			 EMTEA_REHNI_REHIN_TARIHI,TEMLIK_ANLASMA_TARIHI,KEFALET_VADE_TARIHI, ANLASMA_NO
  			 from CBS_KREDI_TEMINAT_GIRIS
  			 where TX_NO=pn_islem_no)

  where MUSTERI_NO=ln_MUSTERI_NO and
	    TEMINAT_SIRA_NO=ln_TEMINAT_SIRA_NO;

 end if;


exception
when my_exception then
   		Raise_application_error(-20100,'2736' || sqlerrm);
	 when others then
   		Raise_application_error(-20100,'2104' || sqlerrm);

end;

Begin

p_1401_BOLUM_KODU := pkg_muhasebe.parametre_index_bul('1401_BOLUM_KODU');
p_1401_ISLEM_SUBE := pkg_muhasebe.parametre_index_bul('1401_ISLEM_SUBE');
p_1401_TEMINAT_TUTARI_LC := pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUTARI_LC');
p_1401_TUTAR_ARTIYOR := pkg_muhasebe.parametre_index_bul('1401_TUTAR_ARTIYOR');
p_1401_TUTAR_AZALIYOR := pkg_muhasebe.parametre_index_bul('1401_TUTAR_AZALIYOR');
p_1401_DOVIZ_KODU := pkg_muhasebe.parametre_index_bul('1401_DOVIZ_KODU');
p_1401_KUR := pkg_muhasebe.parametre_index_bul('1401_KUR');
p_1401_ACIKLAMA := pkg_muhasebe.parametre_index_bul('1401_ACIKLAMA');
p_1401_TEMINAT_TUTARI_FC := pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUTARI_FC');
p_1401_DURUM_KODU_KAPALI :=pkg_muhasebe.parametre_index_bul('1401_DURUM_KODU_KAPALI');

p_1401_TEMINAT_TUR_IPOTEK := pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUR_IPOTEK');
p_1401_TEMINAT_TUR_KEFALET:=pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUR_KEFALET');
P_1401_TEMINAT_TUR_REHIN:=pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUR_REHIN');
P_1401_TEMINAT_TUR_TEMLIK:=pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUR_TEMLIK');
P_1401_TEMINAT_TUR_SIGORTA_POL:=pkg_muhasebe.parametre_index_bul('1401_TEMINAT_TUR_SIGORTA_POL');



END ;
/

