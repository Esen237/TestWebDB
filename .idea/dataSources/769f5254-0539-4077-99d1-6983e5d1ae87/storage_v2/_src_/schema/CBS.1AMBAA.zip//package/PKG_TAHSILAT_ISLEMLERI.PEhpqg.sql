create PACKAGE     "PKG_TAHSILAT_ISLEMLERI" IS
/******************************************************************************
   Name       : PKG_TAHSILAT_ISLEMLERI
   Created By : Seval colak 05082011   
   Purpose      : Kurum Tahsilatlari
******************************************************************************/

 FUNCTION  Modul_Tur_Tahsilat RETURN VARCHAR2 ;
 FUNCTION  Urun_Tur_Kod(pn_KOD NUMBER) RETURN VARCHAR2 ;
 PROCEDURE TAHSILAT_KURUM_KAYDI_AC(ps_kurum_kodu VARCHAR2,ps_kurum_adi VARCHAR2);
 FUNCTION  TAHSILAT_KURUM_KAYDI_VARMI(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION  Kurum_adi_al(ps_kurum_kodu VARCHAR2 ,ps_dil varchar2 default 'ENG') RETURN VARCHAR2 ;
 FUNCTION  Kurum_Hesabi_Urun_Tur_Uygun_mu(ps_urun VARCHAR2,ps_anlasma_sekli VARCHAR2 DEFAULT 'BANKAMIZ') RETURN VARCHAR2;
 FUNCTION  DK_Hesabi_Uygun_mu(ps_dk VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Sozlesme_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION  Fatura_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Telefon_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Tesisat_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Kurum_ozel_no_zorunlu_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Kurum_Hesabi_al(ps_kurum_kodu VARCHAR2, pn_kanal_no NUMBER DEFAULT 0) RETURN VARCHAR2 ;
 FUNCTION  Kurum_DK_Hesabi_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Kurum_DK_Hesap_Subesi_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION  Kurum_Tahsilat_Hesap_DK(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 PROCEDURE Tahsilat_Talimati_Log_Kaydet(pn_MUSTERI_NO        NUMBER ,
                                         pn_HESAP_NO             NUMBER ,
                                       ps_KURUM_KODU         VARCHAR2,
                                       ps_DURUM_KODU         VARCHAR2 DEFAULT NULL,
                                       pn_IPTAL_NEDENI         NUMBER   DEFAULT NULL,
                                       pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                       pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                         ps_TELEFON_ALAN_KOD  VARCHAR2      DEFAULT NULL,
                                       ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                       pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                       pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL,
                                       pn_ISLEM_NO             NUMBER      DEFAULT NULL,
                                       pd_ISLEM_TARIHI         DATE      DEFAULT SYSDATE,
                                       pn_YARATAN_KULLANICI VARCHAR  DEFAULT USER,
                                       ps_TALIMAT_SEKLI        VARCHAR2 DEFAULT NULL,
                                       pn_TALIMAT_LIMITI    NUMBER   DEFAULT NULL) ;

 PROCEDURE sp_Talimatli_Musteri_Kaydet(pn_MUSTERI_NO        NUMBER ,
                                         pn_HESAP_NO             NUMBER ,
                                       ps_KURUM_KODU         VARCHAR2,
                                       pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                       pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                         ps_TELEFON_ALAN_KOD  VARCHAR2      DEFAULT NULL,
                                       ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                       pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                       pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL,
                                       ps_TALIMAT_SEKLI        VARCHAR2 DEFAULT NULL,
                                       pn_TALIMAT_LIMITI    NUMBER   DEFAULT NULL,
                                       pd_TALIMAT_TARIHI    DATE     DEFAULT NULL,
                                       pn_ISLEM_NO            NUMBER   DEFAULT NULL,
                                       pn_IPTAL_ISLEM_NO    NUMBER   DEFAULT NULL,
                                       ps_ABONE_ADI            VARCHAR2 DEFAULT NULL) ;

 FUNCTION  Hesap_Talimat_Sekli_al(pn_HESAP_NO             NUMBER ,
                                  ps_KURUM_KODU         VARCHAR2,
                                  pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                  pn_FATURA_NO             VARCHAR2      DEFAULT NULL,
                                    ps_TELEFON_ALAN_KOD   VARCHAR2      DEFAULT NULL,
                                  ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                  pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                  pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL) RETURN VARCHAR2 ;

 FUNCTION  Hesap_Talimat_Limiti_al(pn_HESAP_NO             NUMBER ,
                                  ps_KURUM_KODU         VARCHAR2,
                                  pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                  pn_FATURA_NO             VARCHAR2      DEFAULT NULL,
                                    ps_TELEFON_ALAN_KOD   VARCHAR2      DEFAULT NULL,
                                  ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                  pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                  pn_KURUM_OZEL_NO        VARCHAR2      DEFAULT NULL) RETURN NUMBER ;

 PROCEDURE Tahsilat_OTMFatura_Log_Kaydet(pn_TX_NO            NUMBER ,
                                          pn_MUSTERI_NO       NUMBER ,
                                          pn_HESAP_NO         NUMBER ,
                                        ps_KURUM_KODU         VARCHAR2,
                                        pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                        pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                          ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                                        ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                        pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                        pn_KURUM_OZEL_NO    VARCHAR2      DEFAULT NULL,
                                        ps_DOVIZ_KODU         VARCHAR2 DEFAULT NULL,
                                        pn_TUTAR            NUMBER   DEFAULT NULL,
                                        pn_ODENEN_TUTAR        NUMBER   DEFAULT NULL,
                                        pd_SON_ODEME_TARIHI DATE      DEFAULT NULL,
                                        ps_KISMI_TAHSILAT    VARCHAR  DEFAULT NULL,
                                        ps_DURUM            VARCHAR2 DEFAULT NULL);

 PROCEDURE Tahsilat_Batch_Log_Kaydet(pd_TARIH             DATE,
                                    ps_PROGRAM_KODU       VARCHAR2 DEFAULT NULL,
                                       pn_YARATAN_TX_NO      NUMBER DEFAULT NULL,
                                       pn_HATA_KODU          NUMBER DEFAULT NULL,
                                       ps_HATA_ACIKLAMASI    VARCHAR2 DEFAULT NULL,
                                    pd_CALISMA_ZAMANI      DATE DEFAULT SYSDATE) ;
 PROCEDURE sp_OTMFatura_Iptal_Log_Kaydet(ps_KURUM_KODU         VARCHAR2,
                                        pn_SOZLESME_NO         NUMBER      DEFAULT NULL,
                                        pn_FATURA_NO         VARCHAR2      DEFAULT NULL,
                                          ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                                        ps_TELEFON_NO         VARCHAR2      DEFAULT NULL,
                                        pn_TESISAT_NO         NUMBER      DEFAULT NULL,
                                        pn_KURUM_OZEL_NO    VARCHAR2      DEFAULT NULL,
                                        pn_TUTAR            NUMBER     DEFAULT NULL,
                                        pd_SON_ODEME_TARIHI DATE      DEFAULT NULL,
                                        ps_IPTAL_EDILEMEME_NEDENI    VARCHAR  DEFAULT NULL,
                                        pd_ISLEM_TARIHI        DATE DEFAULT NULL,
                                        ps_HATA_KODU        VARCHAR2 DEFAULT NULL,
                                        ps_HATA_ACIKLAMASI    VARCHAR2 DEFAULT NULL) ;
 FUNCTION Kurum_tahsilat_Saati_Uygun_mu(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION Iptal_Neden_Aciklamasi_Al(pn_kod NUMBER) RETURN VARCHAR2;
 FUNCTION Talimat_Tarihi_al(pn_MUSTERI_NO          NUMBER ,
                             ps_KURUM_KODU          VARCHAR2,
                             pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                             pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                               ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                             ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                             pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                             pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN DATE ;
  FUNCTION Talimat_Hesap_no_al(pn_MUSTERI_NO          NUMBER ,
                             ps_KURUM_KODU          VARCHAR2,
                             pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                             pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                               ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                             ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                             pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                             pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN NUMBER;
 
 FUNCTION Abone_adi_al(ps_KURUM_KODU      VARCHAR2,
                     pn_SOZLESME_NO      NUMBER      DEFAULT NULL,
                     pn_FATURA_NO          VARCHAR2      DEFAULT NULL,
                      ps_TELEFON_ALAN_KOD VARCHAR2      DEFAULT NULL,
                     ps_TELEFON_NO          VARCHAR2      DEFAULT NULL,
                     pn_TESISAT_NO          NUMBER      DEFAULT NULL,
                     pn_KURUM_OZEL_NO     VARCHAR2      DEFAULT NULL) RETURN VARCHAR2 ;
  FUNCTION Kurum_OtmTahsilat_Hesabi_al(ps_kurum_kodu VARCHAR2) RETURN NUMBER ;
 FUNCTION Kurum_Anlasma_Sekli_Al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION Kurum_musteri_no_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION Kurum_anlasmali_musteri_no_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION Kurum_Otomatik_Tahsilat_var_mi(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION AktiflikTarihi_Aciklama_Al(ps_Kod VARCHAR2) RETURN VARCHAR2;
 
 FUNCTION Kurum_Grup_Aciklama_Al(ps_grup_kod varchar2,ps_dil varchar2 default 'ENG') RETURN VARCHAR2;
 FUNCTION Kurum_alt_Grup_Aciklama_Al(ps_grup_kod varchar2 ,ps_alt_grup_kod varchar2,ps_dil varchar2 default 'ENG') RETURN VARCHAR2;
 FUNCTION Kurum_min_Digit_Al(ps_Kurum VARCHAR2) RETURN NUMBER ;
 FUNCTION Kurum_max_Digit_Al(ps_Kurum VARCHAR2) RETURN NUMBER ;
 FUNCTION Kurum_Digit_Mesaj_Al(ps_Kurum VARCHAR2) RETURN VARCHAR2 ;
 FUNCTION kanal_adi_al(pn_kanal_no NUMBER)  RETURN VARCHAR2;
 FUNCTION Grup_koduna_bagli_kurum_Var(ps_grup_kod varchar2) RETURN VARCHAR2;
 FUNCTION AltGrup_koduna_bagli_kurum_Var(ps_grup_kod varchar2,ps_alt_grup_kod varchar2) RETURN VARCHAR2;
 FUNCTION Kurum_grup_kodu_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION Kurum_alt_grup_kodu_al(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION Kurum_iptal_talebi_girilebilmi(ps_kurum_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION Kurum_iptal_max_datetime(ps_kurum_kodu VARCHAR2,Pd_date date default sysdate ) RETURN DATE;
------------------------------------------------------------------------------------------------------
--B-O=M ernestk 12052014 cqdb00000524 function to get provider code of kurum
 /*
    Name:           kurum_provider_code_al
    Modify Date:    12052014
    Modified By:    Ernest Kuttubaev
    
    Description:    to get the provider of this tahsilat
 */
 FUNCTION Kurum_provider_code_al(ps_kurum_kodu varchar2) RETURN VARCHAR2;
--E-O=M ernestk 12052014 cqdb00000524 function to get provider code of kurum
 FUNCTION Usip_Response_Code_Explanation(pn_response_code number) Return Varchar2;
 Function Usip_Response_Code_Short_Expl(pn_response_code Number) Return Varchar2;
 Function Usip_Response_Code_Long_Expl(pn_response_code Number) Return Varchar2;
 Function Usip_Response_Code_Eng_Expl(pn_response_code Number) Return Varchar2;
 Function Usip_Statu_Code_Expl(Pn_statu_code Number) Return Varchar2;
------------------------------------------------------------------------------------------------------
PROCEDURE ins_tahsilat_usip_webserv_log( 
                pn_islem_tanim_kod  number default 6330,    
                ps_transaction_type  varchar2 default null,   
                pn_tx_no    number,        
                pn_tahsilat_islem_no  number default 0,        
                pn_tahsilat_islem_sira_no number default 0,        
                pn_payment_id   number default 0,
                pn_service_id number   default 0,        
                ps_usip_status_code varchar2 default null,        
                ps_usip_result_code    varchar2 default null ,        
                ps_usip_transactionnumber varchar2 default null,        
                ps_usip_serviceid   varchar2 default null,        
                ps_usip_amount      varchar2 default null,        
                ps_usip_accountnumber   varchar2 default null ,
                ps_error_message    varchar2 default null);
------------------------------------------------------------------------------------------------------
Function Usip_service_id(ps_kurum_kodu varchar2) Return number;
-------------------------------------------------------------------------------------------------
PROCEDURE upd_tahsilat_usip_statu_code( pn_tx_no   number,ps_usip_status_code varchar2);
procedure Usip_payment_statu_code_al(pn_tx_no number ,ps_statu_code out varchar2 ,ps_result_code out varchar2 ) ;

FUNCTION Kurum_min_payment_amount_Al(ps_Kurum VARCHAR2) RETURN NUMBER ;
FUNCTION Kurum_max_payment_amount_Al(ps_Kurum VARCHAR2) RETURN NUMBER ;
PROCEDURE BLOKE_YARAT(pn_tx_no number, pn_hesap_no number,pn_bloke_tutari number , ps_bloke_referans out varchar2  );
PROCEDURE BLOKE_COZ(pn_tx_no number, ps_bloke_referans varchar2 default null );
FUNCTION USIP_main_account_no_al RETURN number;
function usip_remain_amount_al return number;
Procedure booktobooktransfer(pn_grup_no Number default 0, pn_log_no Number default 0, ps_program_kod Varchar2 default 'PKG_BAT_3.KURUM_INTER_TO_MAIN_ACCT_TRANS',
                             ps_instution_code varchar2,
                             pn_fromaccountno number,
                             pn_toaccountno  number,
                             pn_amount        number,
                             pn_instution_balance number default null,
                             pn_instution_available_bal number default null,
                             pn_Remain_amount number default null,   
                             pn_islem_kod     number default 6332,
                             ps_description   IN VARCHAR2 default 'Payment transfer from Intermediate acount to Main Account',                           
                             pn_islem_no out number
                             ) ;
FUNCTION  sf_usip_durum_kodu_al(ps_durum_kodu varchar2 ) RETURN  varchar2;

--B-O-M chyngyzo 09062014 cqdb00000728 GET_SERVICE_ID
/*******************************************************************************
    Name: GET_SERVICE_ID
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns service id of the given institution code
********************************************************************************/    
FUNCTION GET_SERVICE_ID( ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE) RETURN VARCHAR2;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_SERVICE_ID

--B-O-M chyngyzo 09062014 cqdb00000728 GET_KURUM_GRUP_KOD
/*******************************************************************************
    Name: GET_KURUM_GRUP_KOD
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns group code of the given institution code
********************************************************************************/    
FUNCTION GET_KURUM_GRUP_KOD( ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE) RETURN VARCHAR2;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_KURUM_GRUP_KOD

--B-O-M chyngyzo 09062014 cqdb00000728 GET_PROVIDER_CODE
/*******************************************************************************
    Name: GET_PROVIDER_CODE
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns provider code of the given institution code
********************************************************************************/    
FUNCTION GET_PROVIDER_CODE( ps_kurum_kodu CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%TYPE) RETURN VARCHAR2;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_PROVIDER_CODE

--B-O-M chyngyzo 09062014 cqdb00000728 KT_CALL_WS
/*******************************************************************************
    Name: KT_CALL_WS
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Makes web service call to KyrgyzTelecom
********************************************************************************/    
PROCEDURE KT_CALL_WS(PN_TX_NO                  NUMBER,
                                       PN_OP VARCHAR2,
                                       PN_QID NUMBER,
                                       PN_SERVICE_ID        NUMBER,
                                       PN_SUBSCRIBER_NO          NUMBER,
                                       PN_SUM NUMBER,
                                       PN_WS_SUM          OUT NUMBER,
                                       PS_WS_STATUS       OUT VARCHAR2,
                                       PS_WS_MSG          OUT VARCHAR2,
                                       PS_ERROR OUT VARCHAR2);
--E-O-M chyngyzo 09062014 cqdb00000728 KT_CALL_WS

--B-O-M chyngyzo 09062014 cqdb00000728 LOG_WS_REQUEST
/*******************************************************************************
    Name: LOG_WS_REQUEST
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Logs each web service call to table CBS_KT_WS_LOG
********************************************************************************/                                                                   
PROCEDURE LOG_WS_REQUEST(                
               pn_TX_NO                         NUMBER,
               ps_KT_OP                         VARCHAR2,
               pd_KT_DTS                        DATE,
               ps_KT_QID                        VARCHAR2,
               ps_KT_QM                         VARCHAR2,
               pn_KT_SERVICE_ID                 NUMBER,
               pn_KT_SUM_PAYMENT_AMOUNT         NUMBER,
               ps_KT_PARAM1_PERSONAL_NUMBER  VARCHAR2,
               ps_KT_STATUS                     VARCHAR2,
               ps_KT_STATUS_EXPLANATION         VARCHAR2,
               pn_KT_SUM_AMOUNT_RETURNED       NUMBER,
               ps_KT_MSG             VARCHAR2
                );
--E-O-M chyngyzo 09062014 cqdb00000728 LOG_WS_REQUEST


--B-O-M chyngyzo 09062014 cqdb00000728 GET_LAST_WS_CALL
/*******************************************************************************
    Name: GET_LAST_WS_CALL
    Author: Chyngyz Omurov
    Modify Date: 09.06.14
    
    Desc: Returns last retrieved data from QE11 web service
********************************************************************************/         
PROCEDURE GET_LAST_WS_CALL(pn_txno NUMBER, pn_subscriber_no CBS_CARI_NAKIT_YATAN.SUBSCRIBER_NO%TYPE,  pn_name OUT CBS_KT_WS_LOG.MSG%TYPE, pn_sum OUT CBS_KT_WS_LOG.SUM_AMOUNT_RETURNED%TYPE, pn_status OUT VARCHAR2) ;
--E-O-M chyngyzo 09062014 cqdb00000728 GET_LAST_WS_CALL
    
--B-O-M AdiletK 30122014 CQ1236 Overdraft Interest Payment
/*******************************************************************************
    Name: Overdraft_Interest_Payment 
    Author: Adilet Kachkeev
    Modify Date: 30.12.2014
    
    Desc: Payment of Overdraft Interest when the account receives monetary inflows
********************************************************************************/                                                                   
PROCEDURE Overdraft_Interest_Payment (pn_islem_no NUMBER);
--E-O-M AdiletK 30122014 CQ1236 Overdraft Interest Payment

--B-O-M CBS-119 Past due closing
/*******************************************************************************
    Desc: Closing of Past Due when the account receives monetary inflows
********************************************************************************/ 
PROCEDURE PASTDUE_CLOSING_PAYMENT (pn_islem_no NUMBER);
--E-O-M Past due closing
 --NurmilaZ
 FUNCTION  get_priority(pn_priority number) RETURN boolean;
END;
/

