create PACKAGE     Pkg_Personel IS

PROCEDURE SP_LOG_PERSONEL_HESAP_ISLEM( pn_islem_no CBS_PERSONEL_HESAP_ISLEM.islem_no%type, pn_islem_kodu CBS_PERSONEL_HESAP_ISLEM.islem_kodu%type, pn_hesap_no CBS_PERSONEL_HESAP_ISLEM.hesap_no%type);
FUNCTION SF_FISTE_PERSONEL_HESABI_VARMI( pn_islem_no number) return varchar2;
FUNCTION KULLANICI_MAASHES_IZLEYEBILIR( pn_kullanici_kodu cbs_kullanici.KODU%type) return varchar2;
FUNCTION TRAN_DISPLAY(pn_islem_no number) return varchar2;
Function Kullanici_Maas_Izleyebilir(pn_musteri number, ps_kullanici varchar2) return varchar2;
FUNCTION Fis_PersonelHesapVarmi( pn_fis_no number ) RETURN varchar2;
FUNCTION TRAN_DISPLAY_2(pn_islem_no number) return varchar2 ;
FUNCTION SF_FISTE_GOSTER(ps_hesap_tipi varchar2, ps_satir_hesap_no varchar2, pn_kullanici_sicil number, pn_fis_no number) return varchar2 ;
FUNCTION Kullanicinin_Personel_No(ps_user varchar2) return varchar2 ;
FUNCTION Personel_Hesap_Mi(pn_musteri_no number) RETURN NUMBER;
FUNCTION  Loan_display_crd_card_rol (ln_hesap_no number,pn_rol_numara NUMBER) RETURN varchar2;--GulkaiyrK cbs-438
--
END;
/

