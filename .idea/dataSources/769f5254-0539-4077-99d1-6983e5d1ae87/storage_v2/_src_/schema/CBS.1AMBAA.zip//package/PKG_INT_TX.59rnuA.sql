create PACKAGE     "PKG_INT_TX" IS

TYPE CursorReferenceType IS REF CURSOR;
---------------------------------------------------------------------------------------------------------
FUNCTION GetWaitTxToDo(ps_option      VARCHAR2,
		 			   ps_txno        VARCHAR2,
					   ps_channelcd   VARCHAR2,
					   ps_customerid  VARCHAR2,
					   ps_personid    VARCHAR2,
					   ps_startdate   VARCHAR2,
					   ps_enddate 	  VARCHAR2,
					   ps_statuscd    VARCHAR2,
						ps_payeename     VARCHAR2,--ernestk 23062014 cqdb864 sort by payee
						ps_from_amount   VARCHAR2,--ernestk 23062014 cqdb864 sort by amount from
						ps_to_amount     VARCHAR2,--ernestk 23062014 cqdb864 sort by amount to
					   ps_makerid  	  VARCHAR2,
		 			   pc_ref   OUT   CursorReferenceType)  RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION MakeWaitTxToDo(ps_option VARCHAR2,
		 			   ps_txno  VARCHAR2,
					   ps_channelcd  VARCHAR2,
					   ps_customerid  VARCHAR2,
					   ps_personid  VARCHAR2,
		 			   pc_ref   OUT   CursorReferenceType)  RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------
FUNCTION GetBankHQName(ps_bankcode VARCHAR2) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION  istatistik_adi_al(ps_istatistik_kodu IN CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
FUNCTION GetPaymordDetails (ps_txno VARCHAR2,
					        pc_ref OUT   cursorreferencetype) RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------------
/******************************************************************************
   NAME        : CreditCardCPaymentTx
   Prepared By :  Nurhat UCA
   Date        : 17.12.2012
   Purpose     : Credit Card Debt Payment via IB
******************************************************************************/
FUNCTION CreditCardCPaymentTx( ps_customerid  VARCHAR2,
                       ps_personid  VARCHAR2,
                       ps_fromAccount  VARCHAR2,
                       ps_Amount  VARCHAR2,
                       ps_CreditCardNo  VARCHAR2,
					   ps_pseudopan  VARCHAR2, -- AdiletK CQ5541 PCI DSS pseudopan
                       pc_ref OUT   cursorreferencetype)RETURN VARCHAR2;
                       
/*FUNCTION ProcessWaitTxToDo RETURN VARCHAR2;

FUNCTION NotifyProcessedTx(ps_bulk_id RAW) RETURN VARCHAR2;*/
                       

END;
/

