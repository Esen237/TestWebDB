create PACKAGE BODY     PKG_TX1331 IS

  Procedure ToSendOrNotToSend(date_of_cibin_request DATE, date_of_1331_request DATE, changed BOOLEAN, send OUT BOOLEAN) is
  Begin
        if (date_of_cibin_request is null AND date_of_1331_request is null) then
            send := TRUE;
            log_at('33aug_tosendornottosend', 1);
        elsif (date_of_cibin_request is null) then
            if (trunc(sysdate) - trunc(date_of_1331_request) > 30) then
                send := TRUE;
                log_at('33aug_tosendornottosend', 2);
            else
                if (changed) then
                    send := TRUE;
                    log_at('33aug_tosendornottosend', 3);
                else                        
                    send := FALSE;    
                    log_at('33aug_tosendornottosend', 4);
                end if;
            end if;
        elsif (date_of_1331_request is null) then
            if (trunc(sysdate) - trunc(date_of_cibin_request)) > 30 then
                send := TRUE;
                log_at('33aug_tosendornottosend', 5);
            else
                send := FALSE; 
                log_at('33aug_tosendornottosend', 6);       
            end if;
        else
            if (date_of_cibin_request > date_of_1331_request) then
                if (trunc(sysdate) - trunc(date_of_cibin_request) > 30) then
                    send := TRUE;
                    log_at('33aug_tosendornottosend', 7);
                else
                    send := FALSE;
                    log_at('33aug_tosendornottosend', 8);
                end if;        
            else
                if (trunc(sysdate) - trunc(date_of_1331_request) > 30) then
                    send := TRUE;
                    log_at('33aug_tosendornottosend', 9);
                else
                    if (changed) then
                        send := TRUE;
                        log_at('33aug_tosendornottosend', 10);
                    else                        
                        send := FALSE; 
                        log_at('33aug_tosendornottosend', 11);   
                    end if;
                end if;
            end if;
        end if;
  End;

Procedure Get_Application(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pc_ref  IN OUT GenCurType)
IS
BEGIN

    OPEN pc_ref FOR
         SELECT APP_NO,CUST_TYPE,  CUST_NO, LOAN_TYPE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, 
                    APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO,
                    COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, DUE_DATE
         FROM CBS_CIB_LOAN_APPLICATION
         WHERE APP_NO = pn_app_no;
        
     EXCEPTION
    WHEN OTHERS THEN
        pc_ref := null;

END;

Procedure Get_Guarantors(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pc_ref  IN OUT GenCurType)
IS
BEGIN
    
    OPEN pc_ref FOR
        SELECT APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO, P_INN
        FROM CBS_CIB_GUARANTORS
        WHERE APP_NO = pn_app_no;
        
   EXCEPTION
    WHEN OTHERS THEN
        pc_ref := null;
END;

Procedure Get_Guarantors_Ul(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pc_ref  IN OUT GenCurType)
IS

BEGIN
    OPEN pc_ref FOR
          SELECT APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO
          FROM CBS_CIB_GUARANTORS_UL
          WHERE APP_NO = pn_app_no;
          
    EXCEPTION
        WHEN OTHERS THEN
            pc_ref := null;
END;

Procedure Get_Guarantees(pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE, pc_ref  IN OUT GenCurType)
IS
BEGIN
    OPEN pc_ref FOR
             SELECT APP_NO, GUARANTEE_TYPE
             FROM CBS_CIB_GUARANTEE
             WHERE APP_NO = pn_app_no;
             
      EXCEPTION
        WHEN OTHERS THEN
            pc_ref := null;
END;


FUNCTION  CreateModificationEntry(pn_tx_no CBS_ISLEM.NUMARA%TYPE, pn_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE) RETURN NUMBER
IS
 ln_count_guarant NUMBER;
 
BEGIN
    
     INSERT INTO CBS_CIB_LOAN_APPLICATION_TX(TX_NO, APP_NO, CUST_TYPE, TX_TYPE, CUST_NO, LOAN_TYPE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, DUE_DATE)
     SELECT pn_tx_no, APP_NO,CUST_TYPE, 1331,  CUST_NO, LOAN_TYPE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, DUE_DATE
     FROM CBS_CIB_LOAN_APPLICATION
     WHERE APP_NO = pn_app_no;
     
     
     INSERT INTO CBS_CIB_GUARANTEE_TX(TX_NO, APP_NO, GUARANTEE_TYPE)
     SELECT pn_tx_no,  APP_NO, GUARANTEE_TYPE
     FROM CBS_CIB_GUARANTEE
     WHERE APP_NO = pn_app_no;
     
     INSERT INTO CBS_CIB_GUARANTORS_TX(TX_NO, APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO)
     SELECT pn_tx_no, APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO
     FROM CBS_CIB_GUARANTORS
     WHERE APP_NO = pn_app_no;
     
     INSERT INTO CBS_CIB_GUARANTORS_UL_TX(TX_NO, APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO)
     SELECT pn_tx_no, APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO
     FROM CBS_CIB_GUARANTORS_UL
     WHERE APP_NO = pn_app_no;
    
    COMMIT;
    
    RETURN 1;

EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8002' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
END;
 

  /*Procedure delete_guarant(PN_TX_NO CBS_ISLEM.NUMARA%TYPE, PS_NAME CBS_CIB_LOAN_GUARANT_TX.NAME%TYPE, PS_INVOLVEMENT CBS_CIB_LOAN_GUARANT.INVOLVEMENT%TYPE) IS
  BEGIN
       
  DELETE FROM CBS_CIB_LOAN_GUARANT_TX WHERE TX_NO =PN_TX_NO AND NAME = PS_NAME AND INVOLVEMENT = PS_INVOLVEMENT;
    COMMIT;
    EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8004' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;*/
  
  
  Procedure ApplicationStatusCheck(pn_islem_no CBS_ISLEM.NUMARA%TYPE) is
     
     Ln_tx_no   cbs_islem.numara%type  := 0;
     ln_app_no CBS_CIB_LOAN_APPLICATION.STATUS%TYPE;
  begin
  
    SELECT APP_NO into ln_app_no 
    FROM CBS_CIB_LOAN_APPLICATION_TX
    WHERE TX_NO = pn_islem_no;

   Select  max(tx_no)
   into    ln_tx_no
   from   CBS_CIB_LOAN_APPLICATION_TX a , cbs_islem b
   where  b.numara <> NVL (pn_islem_no, 0) and 
              A.APP_NO=ln_app_no and 
             a.tx_no=b.numara and     
             B.ISLEM_KOD  in (1331, 1332) and pkg_tx.islem_bitmis_mi(b.numara)=0; --pending modification or approval tx exists
         
    if  nvl(ln_tx_no,0) <> 0 then
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8006' || Pkg_Hata.getDelimiter ||TO_CHAR(ln_tx_no) ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    end if;
    
   Select  max(tx_no)
   into    ln_tx_no
   from   CBS_CIB_LOAN_APPLICATION_TX a , cbs_islem b
   where  b.numara <> NVL (pn_islem_no, 0) and 
              A.APP_NO=ln_app_no and 
             a.tx_no=b.numara and     
             B.ISLEM_KOD =1332  and B.DURUM = 'P'; --processed approval tx exists, i.e., application is already approved or rejected
         
    if  nvl(ln_tx_no,0) <> 0 then
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8003' || Pkg_Hata.getDelimiter ||TO_CHAR(ln_tx_no) ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
    end if;
     
 end;
  
 Procedure Kontrol_Sonrasi(pn_islem_no number) is
   
  Begin
   
    PKG_TX1330.KONTROL_SONRASI(pn_islem_no);
    
    ApplicationStatusCheck(pn_islem_no);
    
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;

  End;

    Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    null;
 End;


  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
      
      ln_app_no CBS_CIB_LOAN_APPLICATION.APP_NO%TYPE;
      lb_send BOOLEAN;
      ls_global_status VARCHAR2(2000);
      ls_local_status VARCHAR2(200);
      ls_app_status CBS_CIB_LOAN_APPLICATION.STATUS%TYPE;
      
      ld_1331_req_last_app_age DATE;
      ld_cibin_req_last_app_age DATE;
      lb_changed BOOLEAN;

        cursor cibin_pers_cur(fname CBS_CIB_PERSON_CREDIT_HISTORY.PERSON_FIRSTNAME%type, 
                            lname CBS_CIB_PERSON_CREDIT_HISTORY.PERSON_LASTNAME%type,
                            bdate CBS_CIB_PERSON_CREDIT_HISTORY.PERSON_BDATE%type,
                            doctype CBS_CIB_PERSON_CREDIT_HISTORY.PERSON_DOC_TYPE%type,
                            docno CBS_CIB_PERSON_CREDIT_HISTORY.PERSON_DOC_NO%type) is
      select CREATED_AT
      from CBS_CIB_PERSON_CREDIT_HISTORY
      where upper(PERSON_FIRSTNAME) = upper(fname)
      and upper(PERSON_LASTNAME) = upper(lname)
      and upper(PERSON_DOC_NO) = upper(docno)
      and PERSON_BDATE = bdate
      and PERSON_DOC_TYPE = doctype
      order by CREATED_AT desc;
      
      cursor cibin_comp_cur(cname CBS_CIB_COMPANY_CREDIT_HISTORY.COMPANY_NAME%type,
                            cinn CBS_CIB_COMPANY_CREDIT_HISTORY.INN_CODE%type,
                            cdate CBS_CIB_COMPANY_CREDIT_HISTORY.COMPANY_BDATE%type,
                            orgfmcd CBS_CIB_COMPANY_CREDIT_HISTORY.ORGFORM_CODE%type) is
      select CREATED_AT
      from CBS_CIB_COMPANY_CREDIT_HISTORY
      where upper(COMPANY_NAME) = upper(cname)
      and INN_CODE = cinn
      and COMPANY_BDATE = cdate
      and ORGFORM_CODE = orgfmcd
      order by CREATED_AT desc;                      
                            
      
      cursor applicant_old_cur(cust CBS_CIB_LOAN_APPLICATION.CUST_NO%TYPE) is
      select   replace(P_FIRSTNAME, '_', ' ') P_FIRSTNAME,       
               replace(P_LASTNAME, '_', ' ') P_LASTNAME, 
               P_SEX, 
               P_BDATE, 
               P_DOCUMENT_TYPE, 
               P_DOCUMENT_NO,
               P_TAX_NO, 
               COMPANY_NAME, 
               COMPANY_BDATE, 
               COMPANY_COUNTRY, 
               COMPANY_INN, 
               COMPANY_ORGFORM,
               CREATED_AT
      from CBS_CIB_LOAN_APPLICATION
      where CUST_NO = cust
      and STATUS <> '-11'
      order by CREATED_AT desc;
      
      cursor g_pers_old_cur(cust CBS_CIB_LOAN_APPLICATION.CUST_NO%TYPE) is
      select   replace(FIRSTNAME, '_', ' ') FIRSTNAME,  
               replace(LASTNAME, '_', ' ') LASTNAME,
               DOC_TYPE, 
               DOC_NO, 
               SEX,  
               BIRTHDATE,
               P_INN,
               CREATED_AT         
      from CBS_CIB_GUARANTORS g
      where g.CUST_NO = cust
      and exists (select 1 from CBS_CIB_LOAN_APPLICATION where APP_NO = g.APP_NO and STATUS <> '-11')
      order by g.CREATED_AT desc;
      
      cursor g_comp_old_cur(cust CBS_CIB_LOAN_APPLICATION.CUST_NO%TYPE) is
      select   NAME, 
               ORGFORM, 
               REGISTRATION_DATE, 
               COUNTRY, 
               INN,
               CREATED_AT
      from CBS_CIB_GUARANTORS_UL g
      where g.CUST_NO = cust
      and exists (select 1 from CBS_CIB_LOAN_APPLICATION where APP_NO = g.APP_NO and STATUS <> '-11')
      order by g.CREATED_AT desc;
      
      cursor applicant_new_cur is
      select   replace(P_FIRSTNAME, '_', ' ') P_FIRSTNAME,       
               replace(P_LASTNAME, '_', ' ') P_LASTNAME, 
               P_SEX, 
               P_BDATE, 
               P_DOCUMENT_TYPE, 
               P_DOCUMENT_NO,
               P_TAX_NO,  
               COMPANY_NAME, 
               COMPANY_BDATE, 
               COMPANY_COUNTRY, 
               COMPANY_INN, 
               COMPANY_ORGFORM,
               CUST_NO 
      from CBS_CIB_LOAN_APPLICATION_TX
      where TX_NO = pn_islem_no;         
      
      cursor g_pers_new_cur is
      select   replace(FIRSTNAME, '_', ' ') FIRSTNAME,  
               replace(LASTNAME, '_', ' ') LASTNAME, 
               DOC_TYPE, 
               DOC_NO, 
               SEX,  
               BIRTHDATE,
               P_INN,
               CUST_NO        
      from CBS_CIB_GUARANTORS_TX
      where TX_NO = pn_islem_no;

      cursor g_comp_new_cur is
      select   NAME, 
               ORGFORM, 
               REGISTRATION_DATE, 
               COUNTRY, 
               INN,
               CUST_NO        
      from CBS_CIB_GUARANTORS_UL_TX
      where TX_NO = pn_islem_no;    
  
  BEGIN
       
        ApplicationStatusCheck(pn_islem_no);
         
        SELECT APP_NO INTO ln_app_no
        FROM CBS_CIB_LOAN_APPLICATION_TX
        WHERE TX_NO = pn_islem_no;
               
        --BOM cq614, ErkinZu, 16.08.2017.Define which request is younger - 1331 or CIBIN
        for app_new_r in applicant_new_cur
        loop
            for app_old_r in applicant_old_cur(app_new_r.CUST_NO)
            loop
                ld_1331_req_last_app_age := app_old_r.CREATED_AT;
                log_at('30aug_ld_1331_req_last_app_age', to_char(ld_1331_req_last_app_age));
                if(app_new_r.P_FIRSTNAME = app_old_r.P_FIRSTNAME 
                    AND app_new_r.P_LASTNAME = app_old_r.P_LASTNAME
                        AND app_new_r.P_SEX = app_old_r.P_SEX
                            AND app_new_r.P_BDATE = app_old_r.P_BDATE
                                AND app_new_r.P_TAX_NO = app_old_r.P_TAX_NO
                                    AND app_new_r.P_DOCUMENT_TYPE = app_old_r.P_DOCUMENT_TYPE
                                        AND app_new_r.P_DOCUMENT_NO = app_old_r.P_DOCUMENT_NO) then
                    lb_changed := FALSE;
                    log_at('30aug_lb_changed', 'FALSE');
                else 
                    lb_changed := TRUE;
                    log_at('30aug_lb_changed', 'TRUE');    
                end if;                                
                exit;
            end loop;
            
            for cibin_pers_r in cibin_pers_cur(app_new_r.P_FIRSTNAME, app_new_r.P_LASTNAME, app_new_r.P_BDATE,
                            app_new_r.P_DOCUMENT_TYPE, app_new_r.P_DOCUMENT_NO)           
            loop
                ld_cibin_req_last_app_age := cibin_pers_r.CREATED_AT;
                log_at('30aug_ld_cibin_req_last_app_age', to_char(ld_cibin_req_last_app_age));
                exit;
            end loop;

            ToSendOrNotToSend(ld_cibin_req_last_app_age, ld_1331_req_last_app_age, lb_changed, lb_send);

            if lb_send then
            log_at('Will be sent (APPL.)', app_new_r.P_FIRSTNAME||' '||app_new_r.P_LASTNAME||' '||app_new_r.P_BDATE||' '||app_new_r.P_TAX_NO||' '||app_new_r.P_SEX||' '||app_new_r.P_DOCUMENT_TYPE||
                ' '||pkg_cib_transaction.getCountryCodeByDocType(app_new_r.P_DOCUMENT_TYPE)||' '||app_new_r.P_DOCUMENT_NO, 'TX_NO: '||pn_islem_no||'; APP_NO: '||ln_app_no);
            
                --UNCOMMENT PKG_CIB_TRANSACTION.SUBMITPERSONDATATOCIB IN PROD
                /*PKG_CIB_TRANSACTION.SUBMITPERSONDATATOCIB(app_new_r.P_FIRSTNAME, app_new_r.P_LASTNAME, app_new_r.P_BDATE, app_new_r.P_TAX_NO, 
                app_new_r.P_SEX, app_new_r.P_DOCUMENT_TYPE, pkg_cib_transaction.getCountryCodeByDocType(app_new_r.P_DOCUMENT_TYPE),app_new_r.P_DOCUMENT_NO, ls_local_status);*/
            
--                ls_local_status := 'test error at '||app_new_r.P_FIRSTNAME||' '||app_new_r.P_LASTNAME;
                if length(ls_local_status) is not null then    
                    ls_global_status := ls_global_status||ls_local_status||', ';
                    ls_local_status := '';
                end if;

            end if;
            lb_send := null;
            lb_changed := null;
            ld_cibin_req_last_app_age := null;
            ld_1331_req_last_app_age := null;
        end loop;
        
        for g_pers_new_r in g_pers_new_cur
        loop
            for g_pers_old_r in g_pers_old_cur(g_pers_new_r.CUST_NO)
            loop
                ld_1331_req_last_app_age := g_pers_old_r.CREATED_AT;
                log_at('31aug_ld_1331_req_last_app_age', to_char(ld_1331_req_last_app_age));
                if(g_pers_new_r.FIRSTNAME = g_pers_old_r.FIRSTNAME 
                        AND g_pers_new_r.LASTNAME = g_pers_old_r.LASTNAME
                            AND g_pers_new_r.DOC_TYPE = g_pers_old_r.DOC_TYPE
                                AND g_pers_new_r.DOC_NO = g_pers_old_r.DOC_NO
                                    AND g_pers_new_r.SEX = g_pers_old_r.SEX
                                        AND g_pers_new_r.BIRTHDATE = g_pers_old_r.BIRTHDATE
                                            AND g_pers_new_r.P_INN = g_pers_old_r.P_INN) then
                    lb_changed := FALSE;
                    log_at('31aug_lb_changed', 'FALSE');
                else
                    lb_changed := TRUE;
                    log_at('31aug_lb_changed', 'TRUE');
                end if;
                exit;                                
            end loop; 
            
            for cibin_pers_r in cibin_pers_cur(g_pers_new_r.FIRSTNAME, g_pers_new_r.LASTNAME, g_pers_new_r.BIRTHDATE,
                            g_pers_new_r.DOC_TYPE, g_pers_new_r.DOC_NO)
            loop
                ld_cibin_req_last_app_age := cibin_pers_r.CREATED_AT;
                log_at('31aug_ld_cibin_req_last_app_age', to_char(ld_cibin_req_last_app_age));
                exit;
            end loop; 
            
            ToSendOrNotToSend(ld_cibin_req_last_app_age, ld_1331_req_last_app_age, lb_changed, lb_send);
            
            if lb_send then
                log_at('Will be sent (PERSON)', g_pers_new_r.FIRSTNAME||' '||g_pers_new_r.LASTNAME||' '||g_pers_new_r.BIRTHDATE||' '||g_pers_new_r.P_INN||' '||g_pers_new_r.SEX||
                ' '||g_pers_new_r.DOC_TYPE||' '||pkg_cib_transaction.getCountryCodeByDocType(g_pers_new_r.DOC_TYPE)||' '||g_pers_new_r.DOC_NO, 'TX_NO: '||pn_islem_no||'; APP_NO: '||ln_app_no);
                
                --UNCOMMENT PKG_CIB_TRANSACTION.SUBMITPERSONDATATOCIB IN PROD    
                /*PKG_CIB_TRANSACTION.SUBMITPERSONDATATOCIB(g_pers_new_r.FIRSTNAME, g_pers_new_r.LASTNAME, g_pers_new_r.BIRTHDATE, g_pers_new_r.P_INN, 
                g_pers_new_r.SEX, g_pers_new_r.DOC_TYPE, pkg_cib_transaction.getCountryCodeByDocType(g_pers_new_r.DOC_TYPE), g_pers_new_r.DOC_NO, ls_local_status);*/ 
                
--                ls_local_status := 'test error at '||g_pers_new_r.FIRSTNAME||' '||g_pers_new_r.LASTNAME;     
                if length(ls_local_status) is not null then    
                    ls_global_status := ls_global_status||ls_local_status||', ';
                    ls_local_status := '';
                end if;
            end if;              
            lb_send := null;
            lb_changed := null;
            ld_cibin_req_last_app_age := null;
            ld_1331_req_last_app_age := null;
        end loop;
        
        for g_comp_new_r in g_comp_new_cur
        loop
            for g_comp_old_r in g_comp_old_cur(g_comp_new_r.CUST_NO)
            loop
                ld_1331_req_last_app_age := g_comp_old_r.CREATED_AT;
                log_at('32aug_ld_1331_req_last_app_age', to_char(ld_1331_req_last_app_age));
                if(g_comp_new_r.NAME = g_comp_old_r.NAME 
                    AND g_comp_new_r.ORGFORM = g_comp_old_r.ORGFORM
                        AND g_comp_new_r.REGISTRATION_DATE = g_comp_old_r.REGISTRATION_DATE
                            AND g_comp_new_r.COUNTRY = g_comp_old_r.COUNTRY
                                AND g_comp_new_r.INN = g_comp_old_r.INN) then
                    lb_changed := FALSE;
                    log_at('32aug_lb_changed', 'FALSE');
                else
                    lb_changed := TRUE;
                    log_at('32aug_lb_changed', 'TRUE');
                end if;                            
                exit;
            end loop;
            
            for cibin_comp_r in cibin_comp_cur(g_comp_new_r.NAME, g_comp_new_r.INN, g_comp_new_r.REGISTRATION_DATE,
                    g_comp_new_r.ORGFORM)
            loop
                ld_cibin_req_last_app_age := cibin_comp_r.CREATED_AT;
                log_at('32aug_ld_cibin_req_last_app_age', to_char(ld_cibin_req_last_app_age));
                exit;
            end loop;  
            
            ToSendOrNotToSend(ld_cibin_req_last_app_age, ld_1331_req_last_app_age, lb_changed, lb_send);      
            
            if lb_send then
                log_at('Will be sent (COMP.)', g_comp_new_r.NAME||' '||g_comp_new_r.ORGFORM||' '||g_comp_new_r.COUNTRY||' '
                    ||g_comp_new_r.REGISTRATION_DATE||' '||g_comp_new_r.INN, 'TX_NO: '||pn_islem_no||'; APP_NO: '||ln_app_no);
                
                --UNCOMMENT PKG_CIB_TRANSACTION.SUBMITPERSONDATATOCIB IN PROD    
                /*PKG_CIB_TRANSACTION.SUBMITCOMPANYDATATOCIB(g_comp_new_r.NAME, g_comp_new_r.ORGFORM, g_comp_new_r.COUNTRY, g_comp_new_r.REGISTRATION_DATE,
                g_comp_new_r.INN, ls_local_status);*/
                
--                ls_local_status := 'test error at '||g_comp_new_r.NAME;
                if length(ls_local_status) is not null then    
                    ls_global_status := ls_global_status||ls_local_status||', ';
                    ls_local_status := '';
                end if;
            end if;    
            lb_send := null;
            lb_changed := null;
            ld_cibin_req_last_app_age := null;
            ld_1331_req_last_app_age := null;
        end loop;
        
        if length(ls_global_status) is not null then
            ls_global_status := substr(ls_global_status, 1, length(ls_global_status)-2);
            ls_global_status := ls_global_status||' - use CIBIN screen to send data';
            PKG_TX.TAMAM_MESAJ_PARAMETRESI(ls_global_status);
            log_at('Error result of sending to CIB', 'TX_NO: '||pn_islem_no, 'Test: '||ls_global_status);
        end if;
        --EOM cq614
        --*********************************************************************        

        DELETE FROM CBS_CIB_GUARANTEE WHERE APP_NO = ln_app_no;
        DELETE FROM CBS_CIB_GUARANTORS WHERE APP_NO = ln_app_no;
        DELETE FROM CBS_CIB_GUARANTORS_UL WHERE APP_NO = ln_app_no;
        
        --BOM cq614 ErkinZ 17.08.2017
        select status into ls_app_status
        from CBS_CIB_LOAN_APPLICATION
        where app_no = ln_app_no;
        --EOM cq614

        UPDATE CBS_CIB_LOAN_APPLICATION SET
        (CUST_TYPE, STATUS, CUST_NO, LOAN_TYPE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE, P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, DUE_DATE, CREATED_AT, CREATED_BY, UPDATE_TX, UPDATE_DATE)
             =
         (SELECT  CUST_TYPE, DECODE(ls_app_status, '-11', '1-0', ls_app_status), CUST_NO, LOAN_TYPE, AMOUNT, CURRENCY, SOURCE_OF_REPAYMENT, EXPLANATION, APPLICATION_DATE,  P_FIRSTNAME, P_LASTNAME, P_SEX, P_BDATE, P_DOCUMENT_TYPE, P_DOCUMENT_NO, P_TAX_NO, COMPANY_NAME, COMPANY_BDATE, COMPANY_COUNTRY, COMPANY_INN, COMPANY_ORGFORM, BRANCH, DUE_DATE, CREATED_AT, CREATED_BY, TX_NO, SYSDATE
                                                            FROM CBS_CIB_LOAN_APPLICATION_TX
                                                            WHERE TX_NO = pn_islem_no) 
        WHERE APP_NO = ln_app_no;

       INSERT INTO CBS_CIB_GUARANTORS_UL(APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO)
                                                       SELECT APP_NO, NAME, ORGFORM, REGISTRATION_DATE, COUNTRY, INN, CUST_NO
                                                       FROM CBS_CIB_GUARANTORS_UL_TX
                                                       WHERE TX_NO = pn_islem_no;
      
       INSERT INTO CBS_CIB_GUARANTORS(APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO, P_INN)
                                                   SELECT APP_NO, FIRSTNAME, LASTNAME, DOC_TYPE, DOC_NO, SEX, STATUS, BIRTHDATE, CUST_NO, P_INN
                                                   FROM CBS_CIB_GUARANTORS_TX
                                                   WHERE TX_NO = pn_islem_no;
       
       INSERT INTO CBS_CIB_GUARANTEE(APP_NO, GUARANTEE_TYPE)
                                                SELECT APP_NO, GUARANTEE_TYPE
                                                FROM CBS_CIB_GUARANTEE_TX
                                                WHERE TX_NO = pn_islem_no;
        
        
    EXCEPTION
    WHEN  OTHERS THEN
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '8002' || Pkg_Hata.getDelimiter ||TO_CHAR(SQLCODE) || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
   End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is    
  Begin
      null;
  End;
  
END;
/

