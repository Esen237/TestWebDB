create PACKAGE     "PKG_SOA_COMMON" IS
TYPE CursorReferenceType IS REF CURSOR;

/******************************************************************************
   NAME        : FUNCTION GetBankName
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Get Banks Code
******************************************************************************/
 FUNCTION GetBankName(ps_bankcode IN VARCHAR2) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION BakiyeYeterlimi
   Prepared By : Almas Nurhozhaev
   Date        : 12.12.2007
   Purpose     : Bakiye Yeterlimi
******************************************************************************/
FUNCTION BakiyeYeterlimi(pn_hesapNumarasi IN VARCHAR2,
                         pn_miktar IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/******************************************************************************
   NAME        : FUNCTION HesapMusteriKontrol
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Check Customer
******************************************************************************/
FUNCTION HesapMusteriKontrol(pn_accountNo  IN VARCHAR2,
                             pn_customerNo IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : FUNCTION CheckRNNExternalAccount
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Check customers external account, and RNN number
******************************************************************************/
FUNCTION CheckRNNExternalAccount(pn_bankcode IN VARCHAR2,
                                 pn_externalaccount IN VARCHAR2,
                                 pn_rnn IN VARCHAR2,
                                 pc_ref OUT cursorreferencetype)  RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  SaveCustElemSettings
   Created By : Almas Nurhozhaev
   Date       : 06.06.08
   Purpose    : Save Person Customization element settings
******************************************************************************/
FUNCTION  SaveCustElemSettings(pn_personcd   IN VARCHAR2,
                               ps_elementids    IN VARCHAR2,
                               pn_visible IN VARCHAR2,
                               pc_ref OUT CursorReferenceType,
                               pc_ref2 OUT CursorReferenceType,
                               pc_ref3 OUT CursorReferenceType,
                               pc_ref4 OUT CursorReferenceType,
                               pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION  GetRateForLimit
   Created By : Almas Nurhozhaev
   Date       : 07.07.08
   Purpose    : Get rates for limit
******************************************************************************/
FUNCTION GetRateForLimit(ps_Currency IN VARCHAR2) RETURN NUMBER;

/******************************************************************************
   NAME        : IsRateDemandCustomer
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Can this customer make rezervation
  ******************************************************************************/
FUNCTION IsRateDemandCustomer(p_customerid IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME       : FUNCTION ArbitrageControl
   Created By : Almas Nurhozhaev
   Date       : 07.07.2008
   Purpose    : Control Accounts for Arbitrage
******************************************************************************/
FUNCTION ArbitrageControl(pn_CustomerId IN VARCHAR2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : ParityControl
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Control Parity, of not OK raise error
  ******************************************************************************/
FUNCTION ParityControl(p_fromaccount IN VARCHAR2,
                          p_toaccount IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2;

/******************************************************************************
   NAME        : IntCalculateParity
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Calculates the Parity
 ******************************************************************************/
FUNCTION IntCalculateParity(p_fromaccount IN VARCHAR2,
                            p_toaccount IN VARCHAR2) RETURN NUMBER;
/******************************************************************************
   NAME        : FUNCTION GetCustomerPrefixCode
   Prepared By : Muzaffar Khalyknazarov
   Date        : 21.12.2007
   Purpose     : Get Customer Prefix Code
******************************************************************************/
  FUNCTION GetCustomerPrefixCode(pn_customerno VARCHAR2) RETURN NUMBER;
/******************************************************************************
   NAME       : FUNCTION  ChangeCustomerInfo
   Created By : Almas Nurkhozhayev
   Date       : 16.12.09
   Purpose    : Change Address
******************************************************************************/
FUNCTION ChangeCustomerInfo(pn_person_id   IN VARCHAR2,
                            ps_address    IN VARCHAR2,
                            pn_telnumber IN VARCHAR2,
                            pn_mobnumber IN VARCHAR2,
                            ps_email IN VARCHAR2,
                            pn_tel_kod IN VARCHAR2,
                            pn_gsm_kod IN VARCHAR2,
                            ps_ekstre_adres_kod IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
/*****************************************************************************
   NAME       : PROCEDURE  NB_POSITION_REPORT
   Created By : Urmat Aymambetov
   Date       : 10.11.14
   Purpose    : Send val75 to treasury
*****************************************************************************/
PROCEDURE NB_POSITION_REPORT(p_date in date);
/*****************************************************************************
   NAME       : PROCEDURE  Export_TO_DBF_mail
   Created By : Urmat Aymambetov
   Date       : 10.11.14
   Purpose    : Prepare data for send to NBKR
*****************************************************************************/
PROCEDURE Export_TO_DBF_mail(
  p_date in date);
/*****************************************************************************
   NAME       : PROCEDURE  Start_Reports
   Created By : Urmat Aymambetov
   Date       : 10.11.14
   Purpose    : launch procedures for sending reprots to NBKR
*****************************************************************************/

 PROCEDURE Start_Reports(Param1 IN NUMBER DEFAULT NULL);
/*****************************************************************************
   NAME       : PROCEDURE  create_blob_val75
   Created By : Urmat Aymambetov
   Date       : 10.11.14
   Purpose    : form binary file in dbf format
*****************************************************************************/                                                                  
 PROCEDURE create_blob_val75(
  pv_Table     in varchar2,
  p_blob in out blob,
  p_date in date);
/*****************************************************************************
   NAME       : PROCEDURE  create_blob_kor75
   Created By : Urmat Aymambetov
   Date       : 10.11.14
   Purpose    : form binary file in dbf format
*****************************************************************************/  
  PROCEDURE create_blob_kor75(
  pv_Table     in varchar2,
  p_blob in out blob,
  p_date in date);

/******************************************************************************
   NAME       : FUNCTION  text_translation
   Created By : Victor Kirsanov
   Date       : 11.12.14
   Purpose    : Translation
******************************************************************************/  
FUNCTION text_translation (ps_string VARCHAR2, ps_lang VARCHAR2) RETURN VARCHAR2;  
 
/******************************************************************************
   NAME       : FUNCTION  ChangeNotificationInfo
   Created By : Adilet Kachkeev
   Date       : 10.03.15
   Purpose    : Change Notification settings
******************************************************************************/
FUNCTION ChangeNotificationInfo(ps_customer_id   IN VARCHAR2,
                            ps_status    IN VARCHAR2,
                            ps_frequency IN VARCHAR2,
                            ps_outflows IN VARCHAR2,
                            ps_inflows IN VARCHAR2,
                            ps_other IN VARCHAR2,
                            ps_ads IN VARCHAR2,
                            ps_email IN VARCHAR2,
                            ps_sms IN VARCHAR2,
                            ps_push IN VARCHAR2,
                            ps_lang IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
                            
/******************************************************************************
   NAME       : FUNCTION CheckCountryLimits
   Created By : Urmat Aymambetov
   Date       : 05.11.2015
   Purpose    : Check Country Limits
******************************************************************************/
PROCEDURE CheckCountryLimits;

/******************************************************************************
   NAME       : PROCEDURE GET_CORRECT_COMMISSION
   Created By : Panychev Anton
   Date       : 28.06.2021
   Purpose    : Correct commission in intervals
******************************************************************************/
PROCEDURE GET_CORRECT_COMMISSION(INSTITUTION IN VARCHAR2,
                                 AMOUNT IN NUMBER,
                                 AMOUNT_WITHOUT_COMMISSION IN NUMBER,
                                 USE_INTERVALS_BANK IN VARCHAR2,
                                 USE_INTERVALS_COMPANY IN VARCHAR2,                                                                  
                                 COMMISSION_TYPE_BANK IN VARCHAR2,
                                 COMMISSION_TYPE_COMPANY IN VARCHAR2,
                                 COMMISSION_AMOUNT_BANK IN OUT NUMBER,
                                 COMMISSION_AMOUNT_COMPANY IN OUT NUMBER,
                                 COMMISSION_RATE_BANK IN OUT NUMBER,
                                 COMMISSION_RATE_COMPANY IN OUT NUMBER);                                                          
 
---------------------------------------------
/*******************************************************************************
    Name        : FUNCTION getNotifPackInfoCustomer
    Prepared By : Omurchiev Esen
    Date:       : 25.02.2022 
    Base Project:  update notif pack by IB or MB
    Purpose     : Get notig packinfo
*******************************************************************************/
FUNCTION  getNotifPackInfoCustomer(ps_customer_no in varchar2,
                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2;
END Pkg_Soa_Common;
/

