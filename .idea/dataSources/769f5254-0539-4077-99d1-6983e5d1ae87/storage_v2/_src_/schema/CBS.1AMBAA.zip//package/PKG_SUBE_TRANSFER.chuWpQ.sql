create PACKAGE PKG_SUBE_TRANSFER IS

/******************************************************************************
   Name       : PKG_SUBE_TRANSFER
   Created By : Seval Balci
   Date    	  : 04.02.04
   Purpose	  : Kasa sube transfer islemleri
******************************************************************************/
 Function urun_sinif_send return varchar2;
 Function urun_sinif_receive return varchar2;
 PROCEDURE sp_transfer_isleme_at (pn_transfer_no  	    CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
  			   			          pn_tx_no 	  			CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE,
								  pn_islem_tanim_kod    CBS_KASA_SUBE_TRANSFER.islem_kod%TYPE DEFAULT 1611,
								  ps_urun_sinif			CBS_KASA_SUBE_TRANSFER.urun_sinif_kod%TYPE
								  );

 FUNCTION Sf_Bitmemis_Islem_VarMi(pn_transfer_no  	    CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
  			   			          pn_tx_no 	  			CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE)  return number;

 END;


/

