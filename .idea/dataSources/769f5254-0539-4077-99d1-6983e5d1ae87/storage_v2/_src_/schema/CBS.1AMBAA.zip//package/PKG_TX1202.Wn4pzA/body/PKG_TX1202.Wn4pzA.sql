create PACKAGE BODY Pkg_Tx1202 IS
	pn_1202_borclu_hesap_doviz_kod        NUMBER;
	pn_1202_lc_tutar       				  NUMBER;
	pn_1202_fc_tutar       		    	  NUMBER;
	pn_1202_banka_aciklama           	  NUMBER;
	pn_1202_borclu_hesap_sube_kodu        NUMBER;
	pn_1202_borclu_hesap_no      		  NUMBER;
	pn_1202_alacak_hesap_sube_kodu        NUMBER;
	pn_1202_alacak_hesap_no      		  NUMBER;
	pn_1202_musteri_aciklama        	  NUMBER;
	pn_1202_referans       				  NUMBER;
	pn_1202_fis_aciklama        		  NUMBER;
	pn_1202_kur_lc       			      NUMBER;
	pn_1202_istatistik_kod_alis    		  NUMBER;
	pn_1202_rezervasyon_varmi        	  NUMBER;
	pn_1202_rezervasyon_yokmu       	  NUMBER;
	pn_1202_musteri_kur_buyukmu        	  NUMBER;
	pn_1202_musteri_kur_kucukmu        	  NUMBER;
	pn_1202_borc_tutar       		      NUMBER;
	pn_1202_alacak_tutar        		  NUMBER;
	pn_1202_kur_farkli_tutar        	  NUMBER;
	pn_1202_islem_subesi				  NUMBER;
	pn_1202_istatistik_kodu_satis		  NUMBER;


  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
    ln_doviz_tutari NUMBER;
	ln_bakiye NUMBER;

	CURSOR islem_cursor IS
	   	 	SELECT * FROM CBS_DTH_TL_ODEME_ISLEM
			WHERE TX_NO=pn_islem_no;

	row_islem islem_cursor%ROWTYPE;
   BEGIN

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

	IF row_islem.REZERVASYON_NO IS NOT NULL THEN

	   ln_bakiye:=Pkg_Kur_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

	   IF row_islem.TUTAR >ln_bakiye THEN --Bakiye Yetersiz..
	      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
	   ELSE
	      Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
	 		    										  pn_islem_no,
	     												  row_islem.TUTAR);
	   END IF;

	END IF;

	Pkg_Personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1202',row_islem.BORC_HESAP_NO);

END;
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  END;

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   NULL;
  END;

 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
 BEGIN
 	   NULL;

 END;

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	Pkg_Tx1202.Onay_Sonrasi_Kur_Guncelle(pn_islem_no);
  END;


  PROCEDURE Onay_Sonrasi_Kur_Guncelle(pn_islem_no NUMBER) IS
	ln_kur 	         CBS_DTH_TL_ODEME_ISLEM.kur%TYPE;
	ls_doviz_kodu      CBS_DTH_TL_ODEME_ISLEM.doviz_kodu%TYPE;
	ln_rezervasyon_no  CBS_DTH_TL_ODEME_ISLEM.rezervasyon_no%TYPE;
  BEGIN
	  SELECT
  	    doviz_kodu,
		kur       ,
		rezervasyon_no
	  INTO ls_doviz_kodu ,
	  	   ln_kur ,
		   ln_rezervasyon_no
	  FROM CBS_DTH_TL_ODEME_ISLEM
	  WHERE tx_no = pn_islem_no ;

	  UPDATE CBS_DTH_TL_ODEME_ISLEM
	  SET MUSTERI_NO=Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO),
	  	  ISLEM_TARIHI=Pkg_Muhasebe.Banka_Tarihi_Bul
	  WHERE tx_no=pn_islem_no;

	/*rezervasyonsuz ise onay andaki banka alis kuru alinir. islem bu kayit ile guncellenir.*/

	  /*IF NVL(ln_rezervasyon_no,0) = 0 THEN
		UPDATE CBS_DTH_TL_ODEME_ISLEM
		SET kur =Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'O','A')
		WHERE tx_no = pn_islem_no ;
	  END IF;*/
  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  END;


  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	Pkg_Kur_Rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  END;

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  	NULL;
  END;

 PROCEDURE Muhasebelesme(pn_islem_no NUMBER) IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;

	ln_fis_no				   CBS_FIS.numara%TYPE ;
	ls_islem_kod               CBS_ISLEM.islem_kod%TYPE :='1202';
	ls_musteri_aciklama        VARCHAR2(2000);
	ls_banka_aciklama          VARCHAR2(2000);
	ls_fis_aciklama            VARCHAR2(2000);
	ln_musteri_no			   CBS_MUSTERI.musteri_no%TYPE;
	ln_hesap_no		   		   CBS_HESAP.hesap_no%TYPE;
	ln_alacak_hesap_no		   CBS_HESAP.hesap_no%TYPE;
	ls_alacak_hesap_sube_kodu  CBS_HESAP.sube_kodu%TYPE;
    ln_borclu_hesap_no		   CBS_HESAP.hesap_no%TYPE;
	ls_borclu_hesap_sube_kodu  CBS_HESAP.sube_kodu%TYPE;
	ln_tutar			   	   CBS_DTH_TL_ODEME_ISLEM.tutar%TYPE;
	ln_kur			   	   	   CBS_DTH_TL_ODEME_ISLEM.kur%TYPE;
	ls_istatistik_kodu_alis	   CBS_DTH_TL_ODEME_ISLEM.istatistik_kodu_alis%TYPE;
	ls_istatistik_kodu_satis   CBS_DTH_TL_ODEME_ISLEM.istatistik_kodu_satis%TYPE;
	ls_doviz_kodu			   CBS_HESAP.doviz_kodu%TYPE;
	ln_rezervasyon_no		   CBS_DTH_TL_ODEME_ISLEM.rezervasyon_no%TYPE;
	ln_musteri_kur			   NUMBER;
	ln_maliyet_kur			   NUMBER;
	kur_degeri_sifir           EXCEPTION;
	ls_kayit_bolum_kodu   	   CBS_ISLEM.KAYIT_KULLANICI_BOLUM_KODU%TYPE;
	ln_borc_musteri_no    	   NUMBER;
	ls_doviz_ulke_kodu			   VARCHAR2(200);
	CURSOR islem_cursor IS
		SELECT
		 borc_hesap_no,
		 Pkg_Hesap.HesaptanSubeAl(borc_hesap_no),
		 doviz_kodu,
		 kur       ,
		 tutar     ,
		 alacak_hesap_no,
		 Pkg_Hesap.HesaptanSubeAl(alacak_hesap_no),
		-- TO_CHAR(NVL(prefix_ISTATISTIK_KODU_ALIS,0)) ||NVL(doviz_kodu,' ') || TO_CHAR(NVL(ISTATISTIK_KODU_ALIS,0)) istatistik_kodu_alis  ,
		-- TO_CHAR(NVL(prefix_ISTATISTIK_KODU_SATIS,0)) ||  Pkg_Genel.lc_al || TO_CHAR(NVL(ISTATISTIK_KODU_SATIS,0)) istatistik_kodu_satis  ,
		 aciklama		  ,
		 rezervasyon_no	  ,
		 Pkg_Hesap.HesaptanMusteriNoAl(borc_hesap_no),
		 DOVIZ_ULKE_KODU,
		 Pkg_Tx.Amir_BolumKodu_Al(tx_no)
	   FROM CBS_DTH_TL_ODEME_ISLEM
	   WHERE tx_no = pn_islem_no ;
  BEGIN

/* islem bilgisi detaylari alinir */
	 IF islem_cursor%isopen THEN
	   CLOSE islem_cursor;
	 END IF;

  	   OPEN islem_cursor;
	    FETCH islem_cursor INTO
			  ln_borclu_hesap_no,
			  ls_borclu_hesap_sube_kodu,
			  ls_doviz_kodu,
		 	  ln_kur,
			  ln_tutar     ,
			  ln_alacak_hesap_no,
			  ls_alacak_hesap_sube_kodu,
--			  ls_istatistik_kodu_alis  ,
--			  ls_istatistik_kodu_satis  ,
			  ls_banka_aciklama,
			  ln_rezervasyon_no,
			  ln_borc_musteri_no ,
			  ls_doviz_ulke_kodu,
			   varchar_list(pn_1202_islem_subesi)	   ;


	   IF islem_cursor%NOTFOUND THEN
	          CLOSE islem_cursor;
       END IF;
	   CLOSE islem_cursor;

/*** Liste Deger Atama K?sm? **/

/* istatistik kod eslesme */

--  varchar_list(pn_1202_istatistik_kod_alis):= ls_istatistik_kodu_alis ;/*Pkg_Genel.Istatistik_Kodu_Bul(ls_islem_kod,
--	   								     Pkg_Musteri.SF_MUSTERI_DK_GRUP_KOD_AL(ln_borc_musteri_no),
--									     1);*/
--  varchar_list(pn_1202_istatistik_kodu_satis)	:= TO_CHAR(ls_istatistik_kodu_satis);

/**** varchar list ****/
   Pkg_Parametre.deger('1202_FIS_ACIKLAMA',ls_fis_aciklama);

   varchar_list(pn_1202_fis_aciklama) 	 := ls_fis_aciklama ;
   varchar_list(pn_1202_banka_aciklama)  := ls_banka_aciklama;
   varchar_list(pn_1202_musteri_aciklama):= ls_banka_aciklama; --ls_musteri_aciklama;
   varchar_list(pn_1202_referans) 	   	 := TO_CHAR(ln_borclu_hesap_no);

   varchar_list(pn_1202_borclu_hesap_doviz_kod) := ls_doviz_kodu;
   varchar_list(pn_1202_alacak_hesap_sube_kodu) := ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1202_alacak_hesap_no)        := TO_CHAR(ln_alacak_hesap_no);
   varchar_list(pn_1202_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
   varchar_list(pn_1202_borclu_hesap_no)        := TO_CHAR(ln_borclu_hesap_no);


/**** boolean list ****/
    boolean_list(pn_1202_rezervasyon_varmi):=FALSE;
    boolean_list(pn_1202_musteri_kur_buyukmu):=FALSE;
    boolean_list(pn_1202_rezervasyon_yokmu):=FALSE;
    boolean_list(pn_1202_musteri_kur_kucukmu):=FALSE;

	IF NVL(ln_rezervasyon_no,0) = 0 THEN
	/*rezervasyonsuz */
	   ln_maliyet_kur := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,Pkg_Genel.lc_al,NULL,1,3,NULL,NULL,'O','A');
	   ln_musteri_kur := ln_kur;
	   boolean_list(pn_1202_rezervasyon_yokmu):= TRUE;
   ELSE
	/*rezervasyonlu */
	   boolean_list(pn_1202_rezervasyon_varmi):=TRUE;
       Pkg_Kur_Rezervasyon.Rezervasyon_Alis_Bilgisi_Al(ln_rezervasyon_no,ln_musteri_kur,ln_maliyet_kur);
	 END IF;

	   IF	NVL(ln_musteri_kur,0) = 0 AND  NVL(ln_maliyet_kur,0) = 0 THEN
		   RAISE kur_degeri_sifir;
		ELSE
			IF ln_musteri_kur > ln_maliyet_kur THEN
				    boolean_list( pn_1202_musteri_kur_buyukmu):=TRUE;
			ELSE
				    boolean_list( pn_1202_musteri_kur_kucukmu):=TRUE;
			END IF;
	   END IF;


		number_list(pn_1202_lc_tutar) := ln_tutar *ln_maliyet_kur;
		number_list(pn_1202_borc_tutar) := number_list(pn_1202_lc_tutar);

	    number_list(pn_1202_kur_farkli_tutar) := ABS( NVL(ln_musteri_kur,0) - NVL(ln_maliyet_kur,0) ) * ln_tutar;

	    number_list(pn_1202_alacak_tutar) :=  NVL(ln_musteri_kur,0) * ln_tutar;

	    number_list(pn_1202_fc_tutar) := ln_tutar ;
	    number_list(pn_1202_kur_lc)	 := ln_kur;
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=Pkg_Muhasebe.fis_kes(ls_islem_kod,
								    NULL,
									pn_islem_no,
									varchar_list ,
									number_list  ,
									date_list    ,
									boolean_list ,
									NULL,
									FALSE,
									0,
									ls_fis_aciklama);

	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

 EXCEPTION
   WHEN kur_degeri_sifir THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '500' ||  Pkg_Hata.getUCPOINTER);
   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '441' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);

 END;

BEGIN
	pn_1202_istatistik_kodu_satis :=Pkg_Muhasebe.parametre_index_bul('1202_ISTATISTIK_KODU_SATIS');
	pn_1202_borclu_hesap_doviz_kod :=Pkg_Muhasebe.parametre_index_bul('1202_BORCLU_HESAP_DOVIZ_KOD');
	pn_1202_lc_tutar :=Pkg_Muhasebe.parametre_index_bul('1202_LC_TUTAR');
	pn_1202_fc_tutar :=Pkg_Muhasebe.parametre_index_bul('1202_FC_TUTAR');
	pn_1202_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1202_BANKA_ACIKLAMA');
	pn_1202_borclu_hesap_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1202_BORCLU_HESAP_SUBE_KODU');
	pn_1202_borclu_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1202_BORCLU_HESAP_NO');
	pn_1202_alacak_hesap_sube_kodu :=Pkg_Muhasebe.parametre_index_bul('1202_ALACAK_HESAP_SUBE_KODU');
	pn_1202_alacak_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1202_ALACAK_HESAP_NO');
	pn_1202_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1202_MUSTERI_ACIKLAMA');
	pn_1202_referans :=Pkg_Muhasebe.parametre_index_bul('1202_REFERANS');
	pn_1202_fis_aciklama :=Pkg_Muhasebe.parametre_index_bul('1202_FIS_ACIKLAMA');
	pn_1202_kur_lc :=Pkg_Muhasebe.parametre_index_bul('1202_KUR_LC');
	pn_1202_istatistik_kod_alis :=Pkg_Muhasebe.parametre_index_bul('1202_ISTATISTIK_KOD_ALIS');
	pn_1202_rezervasyon_varmi :=Pkg_Muhasebe.parametre_index_bul('1202_REZERVASYON_VARMI');
	pn_1202_rezervasyon_yokmu :=Pkg_Muhasebe.parametre_index_bul('1202_REZERVASYON_YOKMU');
	pn_1202_musteri_kur_buyukmu :=Pkg_Muhasebe.parametre_index_bul('1202_MUSTERI_KUR_BUYUKMU');
	pn_1202_musteri_kur_kucukmu :=Pkg_Muhasebe.parametre_index_bul('1202_MUSTERI_KUR_KUCUKMU');
	pn_1202_borc_tutar :=Pkg_Muhasebe.parametre_index_bul('1202_BORC_TUTAR');
	pn_1202_alacak_tutar :=Pkg_Muhasebe.parametre_index_bul('1202_ALACAK_TUTAR');
	pn_1202_kur_farkli_tutar :=Pkg_Muhasebe.parametre_index_bul('1202_KUR_FARKLI_TUTAR');
	pn_1202_islem_subesi :=Pkg_Muhasebe.parametre_index_bul('1202_ISLEM_SUBESI');
END ;
/

