create PACKAGE pkg_uyari IS

  Procedure Is_Yarat;

  Procedure Is_Bitir;

  procedure islem_sonrasi_kontrol(pn_islem_numara 	   number,
    							  ps_eski_durum_kodu   varchar2,
   							      ps_yeni_durum_kodu   varchar2,
  								  pn_islem_tanim_kod   number,
								  ps_modul_tur_kod	   varchar2,
								  ps_urun_tur_kod	   varchar2,
								  ps_urun_sinif_kod	   varchar2,
								  pn_tutar			   number,
								  ps_doviz_kod		   varchar2
    );
  procedure mesaj_gonder;
END;


/

