create PACKAGE     pkg_tx IS

   -- Main Servisler

   Procedure kilit_test(pn_islem_no number);  --TemirlanT 
   
   Function islem_no_al return number;

   Procedure Gecici_Islem_Yarat(pn_islem_numara       number
                           ,pn_islem_kod                 number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                       );

   Procedure Gecici_Islem_Sil(pn_islem_numara       number);

   Procedure Islem_Yarat(pn_islem_numara              number
                           ,pn_islem_kod                 number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                        );

   Procedure Islem_Guncelle(pn_islem_numara           number
                        ,pc_modul_tur_kod             varchar2
                        ,pc_urun_tur_kod              varchar2
                        ,pc_urun_sinif_kod            varchar2
                        ,pn_tutar                     number
                        ,pc_bolum_kodu                varchar2   default null
                        ,pc_doviz_kod                 varchar2   default null
                        ,pn_musteri_numara            number     default null
                        ,pc_hesap_numara              varchar2   default null
                        ,pc_kasa_kod                  varchar2   default null
                       );

   Function islem_tipi_al(pn_islem_kod number) return varchar2;


   Procedure Giris_Kontrol(pn_islem_no number);

   Function  Dogrula_Kontrol(pn_islem_no number) RETURN BOOLEAN;

   Function  Onay_Kontrol(pn_islem_no number) RETURN BOOLEAN;

   Function  Iptal_Kontrol(pn_islem_no number) RETURN BOOLEAN;

   Procedure Dogrula( pn_islem_no  number
                     ,pb_onay_red  boolean default true
                     ,ps_sebep     varchar2 default null
                    );

   Procedure Onay( pn_islem_no  in number
                  ,pb_onay_red  boolean default true
                  ,ps_sebep     varchar2 default null
                 );

   Procedure Muhasebelestir(pn_islem_no number);

   Procedure iptal_muhasebelestir(pn_islem_no number );

   Procedure Tamam(pn_islem_no number);


   Procedure Iptal( pn_islem_no  number );

   Procedure Iptal_Onay( pn_islem_no  number
                        ,pb_onay_red  boolean default true
                        ,ps_sebep     varchar2 default null);


   Procedure Islem_Calistir(pn_islem_numara number);

   -- Yardimci servisler

   Function Islem_durumu(pn_islem_no number) return varchar2;
   Function Islem_bitmis_mi(pn_islem_no number) return number;
   Function Islem_onaylanmis_mi(pn_islem_no number) return number;
   Function islem_batch_mi(pn_islem_no number) return boolean;

   Function Islem_kod(pn_islem_no number) return number;
   Function fis_no(pn_islem_no number) return number;

   Function Dogrulanabilir_mi( pn_islem_no  number) return number;
   Function Onaylanabilir_mi( pn_islem_no  number) return number;

   Function Iptal_edilebilir_mi( pn_islem_no  number) return number;
   Function Iptal_Onaylanabilir_mi( pn_islem_no  number) return number;

   Function dogrula_guncelle (pn_islem_no number) return boolean;
   Function onay_guncelle (pn_islem_no number) return boolean;

   Procedure Kontrol_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function  Kontrol_Mesaj_Parametresi return varchar2;

   Procedure Onay_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function  Onay_Mesaj_Parametresi return varchar2;

   Procedure Tamam_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function  Tamam_Mesaj_Parametresi return varchar2;

   --

   Procedure Dinamik_Onay_Belirle ( pn_islem_no number, pc_dogrulama varchar2,pc_onay varchar2,pc_iptal_onay varchar2,pc_dogrula_guncelle varchar2,pc_onay_guncelle varchar2);
   Procedure Harici_Kod_Cagir(pn_islem_no number, pc_cikis_yeri varchar2, pb_zorunlu_mu boolean default TRUE);
   Function islem_yaratilmis_mi(pn_islem_no number) return number;
   Function Islem_BolumKodu_Al( pn_islem_no number) return cbs_bolum.kodu%type;
   --
   Function gecici_girilmis_mi(pn_islem_no number) return varchar2;

   Function Amir_BolumKodu_Al( pn_islem_no number) return cbs_bolum.kodu%type;

   Function Appr_Priv_branch_to_branch(pn_islem_no number) return number;
Function Islemden_Kayit_Kullanici_al(pn_islem_no number) return varchar2;
   Procedure Dog_Ipt_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function Dog_Ipt_Mesaj_Parametresi return varchar2;

   Procedure Reddetme_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function Reddetme_Mesaj_Parametresi return varchar2;

   Procedure Ipt_Sonrasi_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function Ipt_Sonrasi_Mesaj_Parametresi return varchar2;

   Procedure Ipt_Onay_Son_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function Ipt_Onay_Son_Mesaj_Parametresi return varchar2;

   procedure islem_geri_gonder(pn_islem_no number, ps_sebep varchar2 default null);
   Procedure Geri_Gonder_Mesaj_Parametresi( ps_mesaj varchar2 );
   Function Geri_Gonder_Mesaj_Parametresi return varchar2;
   Function geri_cevrilebilir_mi( pn_islem_no  number) return number;
   Function  Black_list(pn_islem_no number) return boolean;
   Function fis_numara(pn_islem_no number) return number; --seval.colak 30092021 
END;
/

