create PACKAGE     PKG_KUR IS


  FUNCTION DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1 varchar2,
                                 p_doviz_kod_2 varchar2,
                                 p_tarih date default null,
                                 p_tutar number,
                                 p_kur_tip number default 3,
                                 p_kur_deger_1 number default null,
                                 p_kur_deger_2 number default null,
                                 p_kur_tablo   varchar2 default 'O',
                                 P_alis_satis  varchar2 default 'A') RETURN NUMBER;
  -- p_kur_tip = 1->Doviz Alis 2->Efektif Alis 3->Esas Alis (maliyet)
  -- Returns the eqivalent of p_tutar in p_doviz_kod_2.
  -- The original currency of p_tutar is p_doviz_kod_1.
  -- p_doviz_kod_1 : Source Currency
  -- p_doviz_kod_2 : Destination Currency
  -- p_kur_tablo   : O->Our Bank  N->National Bank
  -- p_alis_satis  : A->Bidrate   S->Oferrate

  FUNCTION DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1    varchar2,
                                 p_doviz_kod_2    varchar2,
                                 p_tarih          date default null,
                                 p_tutar          number,
                                 p_kur_tip        number default 3,
                                 p_kur_deger_1    number default null,
                                 p_kur_deger_2    number default null,
                                 p_kur_tablo      varchar2 default 'O',
                                 P_alis_satis     varchar2 default 'A',
                                 p_karsilik_tutar out number ) return number;
                                 
-- B-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches
  FUNCTION DOVIZ_DOVIZ_KARSILIK( p_doviz_kod_1 varchar2,
                                 p_doviz_kod_2 varchar2,
                                 p_tarih date default null,
                                 p_tutar number,
                                 p_kur_tip number default 3,
                                 p_kur_deger_1 number default null,
                                 p_kur_deger_2 number default null,
                                 p_kur_tablo   varchar2 default 'O',
                                 P_alis_satis  varchar2 default 'A',
                                 p_branch varchar2) RETURN NUMBER;
-- E-O-M AdiletK CQ1153 12.06.2015 Currency rates for branches

  FUNCTION YUVARLA(p_doviz_kod varchar2, p_tutar number) RETURN NUMBER;

  -- Checks to see if p_tutar contains cents.....

  FUNCTION fun_truncate(ps_currency varchar2, pn_amount number) RETURN NUMBER;

  FUNCTION yeni_kur_kaydi_yarat return number;

  FUNCTION yeni_nbkur_kaydi_yarat return number;

  --pragma restrict_references (DOVIZ_DOVIZ_KARSILIK, wnds, wnps);

  function fun_get_fixing_rate( ps_currency_code in varchar2 ) return number;

  function fun_get_fixing_rate( ps_currency_code1 in varchar2
                              , ps_currency_code2 in varchar2 ) return number;

  function fun_validate_fixing_rate( ps_currency_code in varchar2, pn_rate in number ) return number;

  function fun_validate_fixing_rate( ps_currency_code1 in varchar2
                                   , ps_currency_code2 in varchar2
                                   , pn_rate           in number ) return number;

  Function DAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function EAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function DSK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
  Function ESK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;

  Function MB_DAK_to_LC(ps_doviz_kodu varchar2, pn_tutar number) return number;
END;
/

