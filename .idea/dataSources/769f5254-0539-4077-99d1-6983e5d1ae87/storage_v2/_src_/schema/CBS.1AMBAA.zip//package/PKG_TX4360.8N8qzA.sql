create PACKAGE     PKG_TX4360 IS

  /******************************************************************************
   Name       : PKG_TX4360
   Created By : Bilal GUL
   Date             : 11/10/2004
   Purpose      : DAB LIST ENTRY
  ******************************************************************************/

  -- TX Event Listesi
  
  
TYPE GenCurType IS REF CURSOR;         -- BaiamanG

  Procedure Kontrol_Sonrasi(pn_islem_no number);     -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);        -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);        -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);    -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);        -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);      -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);        -- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
  
  Procedure get_customer_accounts(pn_cust_no CBS_MUSTERI.MUSTERI_NO%TYPE, pRetCur IN OUT GenCurType); -- Get all accounts of the customer    BaiamanG

  FUNCTION sf_Sending_Inst_Explanation(pn_code number) RETURN Varchar2;

  FUNCTION sf_Tax_Type_Explanation(pn_code number) RETURN Varchar2;
  
END;

/

