create PACKAGE BODY     PKG_INT_EXCHANGE_TRX IS  
                    
FUNCTION PostExchangeBuyToAccount(ps_lang varchar2,
                             ps_source_iban varchar2, 
                             ps_target_iban varchar2,
                             ps_amount varchar2,
                             ps_amount_currency varchar2,
                             ps_rate varchar2,
                             ps_reservation_number varchar2 default null,
                             ps_channel_code varchar2 default '1',
                             ps_user_code varchar2 default 'CINT_CALLER',       
                             pc_ref OUT CursorReferenceType) RETURN varchar2
IS                   
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_cash_code number;
ln_from_account_number number;
ln_from_customer_number number;
ls_from_branch_code varchar2(3);
ls_branch_code varchar(10);
ls_tran_branch_code varchar(10);
ls_reason_code varchar2(10);
ln_amount number;
ln_total_amount_charged number;
ls_explanation varchar2(100);
ln_count number;
ln_reservation_no number;
ln_amount_in_kgs number;
ln_rate number;
ln_commission number;
retail_ib_fx_limit varchar2(200) := '-1';
use_ib_product cbs_parametre.deger%type;
ls_lang varchar2(10);
pc_get_ref CursorReferenceType;
ls_currency_code varchar2(3 byte);
ls_source_currency_code varchar2(3 byte);
ln_source_initial_balance number;
ln_source_amount number;
ln_source_final_balance number;
ln_exchange_rate number;
ls_target_currency_code varchar2(3 byte);
ln_target_initial_balance number;
ln_target_amount number;
ln_target_final_balance number;
ls_returncode varchar2(3) := '000';
le_rate_exception exception;
no_reservation_error exception;

BEGIN 
    
    ls_returncode := pkg_int_exchange_inq.getexcbuytoaccount(
                                            ps_source_iban => ps_source_iban, 
                                            ps_target_iban => ps_target_iban, 
                                            ps_amount => ps_amount,
                                            ps_amount_currency => ps_amount_currency,
                                            pc_ref => pc_get_ref);
    if ls_returncode <> '000' then
       return ls_returncode;
    end if;
    
                                            
    loop
        fetch pc_get_ref into 
                ls_currency_code,
                ln_target_amount,
                ls_target_currency_code,
                ln_exchange_rate,
                ln_source_amount,
                ls_source_currency_code,
                ln_source_initial_balance,
                ln_source_final_balance,
                ln_target_initial_balance,
                ln_target_final_balance;
        exit when pc_get_ref%notfound;  
    end loop;
    close pc_get_ref;    
    
    if to_number(ps_rate,'99999999999.9999') <> ln_exchange_rate then
        raise le_rate_exception;
    end if;       
                                
    select decode(ps_lang, 'en', 'ENG', 'ru', 'RUS', 'RUS') into ls_lang from dual;
    
    ln_transaction_code := 4025;
    ln_transaction_number := pkg_tx.islem_no_al;
    ls_currency_code := ls_currency_code;
    ln_from_account_number := pkg_int_account_inq.GetAccountNumberByIban(ps_source_iban);
    ln_from_customer_number := pkg_hesap.hesaptanmusterinoal(to_number(ln_from_account_number));
    ls_from_branch_code := pkg_hesap.hesapsubeal(ln_from_account_number);
    ls_branch_code := ls_from_branch_code;
    ls_tran_branch_code := ls_from_branch_code;
    ln_amount := ln_target_amount;   --ln_amount := to_number(ps_amount,'99999999999.99');
    ln_commission := 0;--to_number(ps_commission,'99999999999.99');
    ln_rate := ln_exchange_rate; --to_number(ps_rate,'99999999999.9999');
    ln_total_amount_charged := ln_source_amount;
    ln_amount_in_kgs := ln_source_amount;
    ls_reason_code := '213';
    ls_explanation := pkg_jobs.getlanglabels('FXBUYSELL', 1, 1, ls_lang) || ' ' || ls_currency_code || ' ' || pkg_jobs.getlanglabels('FXBUYSELL', 1, 2, ls_lang) || ' ' ||  ln_rate;
    ls_explanation := substr(ls_explanation,1,100);
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary

    pkg_parametre.deger('RETAIL_IB_FX_LIMIT', retail_ib_fx_limit);
    

    if ps_reservation_number is not null and length(ltrim(rtrim(ps_reservation_number)))>0 then
    
       ln_reservation_no := to_number(ps_reservation_number);

       select count(*)
           into ln_count
           from cbs_vw_kur_rezervasyon r
               where r.rezervasyon_no = ln_reservation_no
                     and r.bakiye <> 0
                     and musteri_no = ln_from_customer_number;

       if ln_count = 0 then
            raise no_reservation_error;
       end if;

       pkg_kur_rezervasyon.rezervasyon_kullanim_kaydet(ln_reservation_no,ln_transaction_number,ln_amount,pkg_muhasebe.banka_tarihi_bul,ls_from_branch_code);
       
    end if;

    pkg_hesap.urunbilgial(ln_from_account_number,ls_module_type_code,ls_product_type_code,ls_product_class_code);

    if to_number(ps_channel_code) = 1 or to_number(ps_channel_code) = 9 then
        pkg_parametre.deger('G_RIBFXBUYSELL_USE_IB_PRODUCT', use_ib_product);
        if (use_ib_product = 'Y') then
            ls_module_type_code := 'IB' || ls_module_type_code;
        end if;
    end if;
    
       
     insert into cbs_dth_doviz_satis_islem
        (tx_no, islem_tarihi, musteri_no, musteri_hesap_no, doviz_kodu,
         doviz_tutari, rezervasyon_no, kur, dth_musteri_no, dth_musteri_hesap_no,
         aciklama, masraf, tahsil_adilen_toplam_tutar, islem_sube, musteri_external_hesap,
         musteri_vergi_no, dth_musteri_external_hesap, dth_musteri_vergi_no)
     values
        (ln_transaction_number, pkg_muhasebe.banka_tarihi_bul, ln_from_customer_number, ln_from_account_number, ls_currency_code,
         ln_amount, ln_reservation_no, ln_rate, ln_from_customer_number, pkg_int_account_inq.GetAccountNumberByIban(ps_target_iban),
         ls_explanation, ln_commission, ln_total_amount_charged,
         ls_from_branch_code, ps_source_iban,
         nvl(pkg_musteri.sf_vergino_al(ln_from_customer_number),0),
         ps_target_iban,
         nvl(pkg_musteri.sf_vergino_al(ln_from_customer_number),0));
     
     
     pkg_int_api.create_transaction(ln_transaction_number, 
                                   ln_transaction_code,
                                   ls_module_type_code, 
                                   ls_product_type_code, 
                                   ls_product_class_code,
                                   ln_amount, 
                                   ls_tran_branch_code, 
                                   ls_branch_code, 
                                   ln_role,
                                   ls_currency_code, 
                                   ln_from_customer_number, 
                                   ln_from_account_number,
                                   ln_cash_code, 
                                   to_number(ps_channel_code), 
                                   ps_user_code);

     if to_number(retail_ib_fx_limit) > 0 and ln_amount_in_kgs <= to_number(retail_ib_fx_limit) then
          pkg_int_api.process_transaction (ln_transaction_number);
     end if;

    open pc_ref for
        select  ln_transaction_number as transaction_number,
                ls_currency_code as currency_code,
                ln_target_amount as target_amount,
                ls_target_currency_code as target_currency_code,
                ln_exchange_rate as exchange_rate,
                ln_source_amount as source_amount,
                ls_source_currency_code as source_currency_code,
                ln_source_initial_balance as source_initial_balance,
                ln_source_final_balance as source_final_balance,
                ln_target_initial_balance as target_initial_balance,
                ln_target_final_balance as target_final_balance
        from dual;
    commit;   
      
    return ls_returncode;
    
EXCEPTION
    when le_rate_exception then
        rollback;
        return '453';
    when no_reservation_error then
        rollback;
        return '490';
    when others then
        log_at('TranExchangeBuyToAccount', ps_source_iban || ' ' || ln_transaction_number, sqlerrm, dbms_utility.format_error_backtrace);
        ls_returncode := pkg_int_api.geterrorcode(sqlerrm); 
        rollback;
        if ls_returncode = '999' then
          raise;
        end if;
        return ls_returncode;
END;                                         
FUNCTION PostExchangeSellToAccount(ps_lang varchar2,
                              ps_source_iban varchar2, 
                              ps_target_iban varchar2,
                              ps_amount varchar2,
                              ps_amount_currency varchar2,
                              ps_rate varchar2,
                              ps_reservation_number varchar2 default null,
                              ps_channel_code varchar2 default '1',
                              ps_user_code varchar2 default 'CINT_CALLER',       
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS                    
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_cash_code number;
ln_from_account_number number;
ln_from_customer_number number;
ls_from_branch_code varchar2(3);
ls_branch_code varchar(10);
ls_tran_branch_code varchar(10);
ls_reason_code varchar2(10);
ls_currency_country_code varchar2(3);
ls_receipt_print_f varchar2(1);
ls_buying_prefix_statistics_code varchar2(4);
ls_selling_prefix_statistics_code varchar2(4);
ln_amount number;
ls_explanation varchar2(100);
ln_count number;
ln_reservation_no number;
ln_amount_in_kgs number;
ln_rate number;
retail_ib_fx_limit varchar2(200):='-1';
use_ib_product cbs_parametre.deger%type;
ls_lang varchar2(10);
pc_get_ref CursorReferenceType;
ls_currency_code varchar2(3 byte);
ls_source_currency_code varchar2(3 byte);
ln_source_initial_balance number;
ln_source_amount number;
ln_source_final_balance number;
ln_exchange_rate number;
ls_target_currency_code varchar2(3 byte);
ln_target_initial_balance number;
ln_target_amount number;
ln_target_final_balance number;
ls_returncode varchar2(3) := '000';
no_reservation_error exception;
le_rate_exception exception;
BEGIN

    ls_returncode := pkg_int_exchange_inq.getexcselltoaccount(
                                            ps_source_iban => ps_source_iban, 
                                            ps_target_iban => ps_target_iban, 
                                            ps_amount => ps_amount,
                                            ps_amount_currency => ps_amount_currency,
                                            pc_ref => pc_get_ref);
    if ls_returncode <> '000' then
       return ls_returncode;
    end if;
                                            
     loop
        fetch pc_get_ref into 
                ls_currency_code,
                ln_target_amount,
                ls_target_currency_code,
                ln_exchange_rate,
                ln_source_amount,
                ls_source_currency_code,
                ln_source_initial_balance,
                ln_source_final_balance,
                ln_target_initial_balance,
                ln_target_final_balance;
        exit when pc_get_ref%notfound;  
    end loop;
    close pc_get_ref;    
    
    
    if to_number(ps_rate,'99999999999.9999') <> ln_exchange_rate then
        raise le_rate_exception;
    end if;      
    
    select decode(ps_lang, 'en', 'ENG', 'ru', 'RUS', 'RUS') into ls_lang from dual;
    
    ln_transaction_code:=1202;
    ln_transaction_number := pkg_tx.islem_no_al;      
    ln_from_account_number := pkg_int_account_inq.GetAccountNumberByIban(ps_source_iban);
    ln_from_customer_number := pkg_hesap.hesaptanmusterinoal(to_number(ln_from_account_number));
    ls_from_branch_code := pkg_hesap.hesapsubeal(ln_from_account_number);
    ls_branch_code := ls_from_branch_code;
    ls_tran_branch_code := ls_from_branch_code;
    ln_amount := ln_source_amount;  --ln_amount := to_number(ps_amount,'99999999999.99');
    ln_rate := ln_exchange_rate; --to_number(ps_rate,'99999999999.9999');
    ln_amount_in_kgs := ln_amount * ln_rate;
    ls_reason_code := '223';
    ls_explanation := pkg_jobs.getlanglabels('FXBUYSELL', 1, 1, ls_lang) || ' ' || ls_currency_code || ' ' || pkg_jobs.getlanglabels('FXBUYSELL', 1, 2, ls_lang) || ' ' || ln_rate;
    
    pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
    
    pkg_parametre.deger('RETAIL_IB_FX_LIMIT', retail_ib_fx_limit);
    

    if ps_reservation_number is not null and length(ltrim(rtrim(ps_reservation_number)))>0 then
       ln_reservation_no:=to_number(ps_reservation_number);

       select count(*) into ln_count
           from cbs_vw_kur_rezervasyon r
             where r.rezervasyon_no=ln_reservation_no
               and r.bakiye<>0
               and musteri_no=ln_from_customer_number;

       if ln_count=0 then
             raise no_reservation_error;
       end if;

       pkg_kur_rezervasyon.rezervasyon_kullanim_kaydet(ln_reservation_no,ln_transaction_number,ln_amount,pkg_muhasebe.banka_tarihi_bul,ls_from_branch_code);
    end if;

    select ulke_kodu
        into ls_currency_country_code
            from cbs_doviz_kodlari
              where doviz_kodu = ls_currency_code;

    ls_buying_prefix_statistics_code := '14' || pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) ||
                 pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) ;

    ls_selling_prefix_statistics_code := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) ||
                 pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) || '14';

    pkg_hesap.urunbilgial(ln_from_account_number,ls_module_type_code,ls_product_type_code,ls_product_class_code);

    pkg_parametre.deger('G_RIBFXBUYSELL_USE_IB_PRODUCT', use_ib_product);
    
    if (use_ib_product = 'Y') then
       ls_module_type_code := 'IB' || ls_module_type_code;
    end if;

      insert into cbs_dth_tl_odeme_islem
         (tx_no, borc_hesap_no, doviz_kodu, kur, tutar,
          alacak_hesap_no, istatistik_kodu_alis, doviz_ulke_kodu, aciklama,
          dekont_basim_f, rezervasyon_no, prefix_istatistik_kodu_alis,
          prefix_istatistik_kodu_satis, istatistik_kodu_satis,
          borc_external_hesap, borc_vergi_no, alacak_external_hesap, alacak_vergi_no)
      values
         (ln_transaction_number, ln_from_account_number, ls_currency_code, ln_rate,
          ln_amount, pkg_int_account_inq.GetAccountNumberByIban(ps_target_iban), ls_reason_code, ls_currency_country_code,
          ls_explanation, ls_receipt_print_f, null, to_number(ls_buying_prefix_statistics_code),
          to_number(ls_selling_prefix_statistics_code), ls_reason_code,
          lpad(nvl(ps_source_iban,0),16,'0'),
          nvl(pkg_musteri.sf_vergino_al(ln_from_customer_number),0),
          lpad(nvl(ps_target_iban,0),16,'0'),
          nvl(pkg_musteri.sf_vergino_al(ln_from_customer_number),0));
          
       pkg_int_api.create_transaction (ln_transaction_number, ln_transaction_code,
                                   ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   ln_amount,ls_tran_branch_code, ls_branch_code, ln_role,
                                   ls_currency_code, ln_from_customer_number,ln_from_account_number,
                                   ln_cash_code, to_number(ps_channel_code) ,ps_user_code); 
                                   
    if to_number(retail_ib_fx_limit)>0 and ln_amount_in_kgs<=to_number(retail_ib_fx_limit) then
       pkg_int_api.process_transaction (ln_transaction_number);
    end if;

    open pc_ref for
        select  ln_transaction_number as transaction_number,
                ls_currency_code as currency_code,
                ln_target_amount as target_amount,
                ls_target_currency_code as target_currency_code,
                ln_exchange_rate as exchange_rate,
                ln_source_amount as source_amount,
                ls_source_currency_code as source_currency_code,
                ln_source_initial_balance as source_initial_balance,
                ln_source_final_balance as source_final_balance,
                ln_target_initial_balance as target_initial_balance,
                ln_target_final_balance as target_final_balance from dual;                 
    commit;     
    return ls_returncode;
    
EXCEPTION
     when le_rate_exception then
        rollback;
        return '453';
    when no_reservation_error then
        rollback;
        return '490';
    when others then
        log_at('PostExchangeSellToAccount', ps_source_iban || ' ' || ln_transaction_number, sqlerrm, dbms_utility.format_error_backtrace);
        ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
        rollback;
        if ls_returncode= '999' then
          raise;
        end if;
        return ls_returncode;
END;                                                           
FUNCTION PostExcBuySellArbitraje(ps_lang varchar2,
                                ps_source_iban varchar2, 
                                ps_target_iban varchar2,
                                ps_amount varchar2,
                                ps_amount_currency varchar2,
                                ps_rate varchar2,
                                ps_reservation_number varchar2 default null,
                                ps_channel_code varchar2 default '1',
                                ps_user_code varchar2 default 'CINT_CALLER',       
                                pc_ref OUT CursorReferenceType) RETURN varchar2    
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_role number := 7777;
ln_cash_code number;
ls_branch_code varchar2(10);
ls_tran_branch_code varchar2(10);
ln_from_customer_number number;
ln_from_account_number number;
ln_buy_rate number;
ln_sell_rate number;
ln_debit_extaccount varchar(9);
ln_credit_extaccount varchar(9);
ln_debit_taxno number;
ln_credit_taxno number;
ln_buying_prefix_statistics_code number;
ln_selling_prefix_statistics_code number;
ln_parity number;
ls_istatistik_kodu_alis varchar2(10);
ls_istatistik_kodu_satis varchar2(10);
ln_amount number;
ls_explanation varchar2(100);
pc_get_ref CursorReferenceType;
ls_currency_code varchar2(3 byte);
ls_source_currency_code varchar2(3 byte);
ln_source_initial_balance number;
ln_source_amount number;
ln_source_final_balance number;
ln_exchange_rate number;
ls_target_currency_code varchar2(3 byte);
ln_target_initial_balance number;
ln_target_amount number;
ln_target_final_balance number;
ls_returncode varchar2(3) := '000';
fxbuysellover exception;
le_rate_exception exception;
BEGIN

         ls_returncode := pkg_int_exchange_inq.getexcbuytoaccount(
                                                ps_source_iban => ps_source_iban, 
                                                ps_target_iban => ps_target_iban, 
                                                ps_amount => ps_amount,
                                                ps_amount_currency => ps_amount_currency,
                                                pc_ref => pc_get_ref);
         if ls_returncode <> '000' then
            return ls_returncode;
         end if;
                                           
         loop
            fetch pc_get_ref into 
                    ls_currency_code,
                    ln_target_amount,
                    ls_target_currency_code,
                    ln_exchange_rate,
                    ln_source_amount,
                    ls_source_currency_code,
                    ln_source_initial_balance,
                    ln_source_final_balance,
                    ln_target_initial_balance,
                    ln_target_final_balance;
            exit when pc_get_ref%notfound;  
         end loop;
         close pc_get_ref;    
        
         if to_number(ps_rate,'99999999999.99999') <> ln_exchange_rate then
             raise le_rate_exception;
         end if;        
    
         ln_transaction_code := 1207;
         ln_transaction_number := pkg_tx.islem_no_al;
         
         pkg_parametre.deger('G_RIBARBITRAGE_MODUL_TYPE', ls_module_type_code);
         pkg_parametre.deger('G_RIBARBITRAGE_PRODUCT_TYPE', ls_product_type_code);
         pkg_parametre.deger('G_RIBARBITRAGE_PRODUCT_CLASS', ls_product_class_code);

         ls_istatistik_kodu_alis := '213';
         ls_istatistik_kodu_satis := '223';
         ln_from_account_number := pkg_int_account_inq.GetAccountNumberByIban(ps_source_iban);
         ln_from_customer_number := pkg_hesap.hesaptanmusterinoal(ln_from_account_number);
         ls_branch_code := pkg_musteri.sf_bolum_kodu_al(ln_from_customer_number);
         ls_tran_branch_code := ls_branch_code;
         ls_currency_code := ls_source_currency_code;
         ln_buy_rate := pkg_kur.doviz_doviz_karsilik(ls_source_currency_code,pkg_genel.lc_al,null,1,1,null,null,'O','A');
         ln_sell_rate := pkg_kur.doviz_doviz_karsilik(ls_target_currency_code,pkg_genel.lc_al,null,1,1,null,null,'O','S');
         ln_debit_extaccount := lpad(ps_target_iban,9,0);
         ln_credit_extaccount := lpad(ps_source_iban,9,0);
         ln_debit_taxno := pkg_musteri.sf_vergino_al(pkg_hesap.getmusterinofromexternal(lpad(ps_target_iban,9,0)));
         ln_credit_taxno := pkg_musteri.sf_vergino_al(pkg_hesap.getmusterinofromexternal(lpad(ps_source_iban,9,0)));
         ls_explanation := 'To Currency ' || ls_target_currency_code ||'-'|| ls_source_currency_code || ' ' || ln_exchange_rate;
         ln_buying_prefix_statistics_code := '14' || pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) ||
         pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number)));
         ln_selling_prefix_statistics_code := pkg_hesap.getirscode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) ||
         pkg_hesap.getsecocode(pkg_musteri.sf_musteri_dk_grup_kod_al(pkg_hesap.hesaptanmusterinoal(ln_from_account_number))) || '14';
         ln_amount := ln_source_amount; --to_number(ps_source_amount,'99999999999.99');
         ln_parity := ln_exchange_rate; --to_number(ls_parity,'99999999999.99999');

         pkg_baglam.yarat(ls_branch_code, ln_role); --temporary
 
         insert into cbs_arbitraj_islem
             (tx_no, alis_doviz_kodu, satis_doviz_kodu, alis_kuru, satis_kuru,
              parite,carp_bol_secimi, alis_tutari,satis_tutari, alis_hesap_no,
              satis_hesap_no, aciklama, kayit_giris_tarihi, kayit_yaratan_kullanici_kodu, kur_parite_secim,
              islem_kod, urun_tur_kod, urun_sinif_kod, musteri_no, islem_tarihi,kur_tipi)
         values
             (ln_transaction_number,ls_source_currency_code,ls_target_currency_code,ln_buy_rate,ln_sell_rate,
              ln_parity,'CARP',ln_amount, ln_target_amount,ln_from_account_number,
              pkg_int_account_inq.GetAccountNumberByIban(ps_target_iban),ls_explanation,sysdate,ps_user_code,'P',
              1204, ls_product_type_code, ls_product_class_code, ln_from_customer_number,pkg_muhasebe.banka_tarihi_bul, 'COMMERCIAL');

          pkg_int_api.create_transaction (ln_transaction_number, 
                                          ln_transaction_code,
                                          ls_module_type_code, 
                                          ls_product_type_code, 
                                          ls_product_class_code,
                                          ln_amount,
                                          ls_tran_branch_code, 
                                          ls_branch_code, 
                                          ln_role,
                                          ls_currency_code, 
                                          ln_from_customer_number,
                                          ln_from_account_number,
                                          ln_cash_code, 
                                          to_number(ps_channel_code), 
                                          ps_user_code);

          pkg_int_api.process_transaction (ln_transaction_number);

      open pc_ref for
        select  ln_transaction_number as transaction_number,
                ls_currency_code as currency_code,
                ln_target_amount as target_amount,
                ls_target_currency_code as target_currency_code,
                ln_exchange_rate as exchange_rate,
                ln_source_amount as source_amount,
                ls_source_currency_code as source_currency_code,
                ln_source_initial_balance as source_initial_balance,
                ln_source_final_balance as source_final_balance,
                ln_target_initial_balance as target_initial_balance,
                ln_target_final_balance as target_final_balance from dual; 
         
    commit;       
    return ls_returncode;
    
EXCEPTION
     when le_rate_exception then
        rollback;
        return '453';
    when others then
        log_at('PostExcBuySellArbitraje', ps_source_iban || ' ' || ln_transaction_number, sqlerrm, dbms_utility.format_error_backtrace);
        ls_returncode := pkg_int_api.geterrorcode(sqlerrm);
        rollback;
        if ls_returncode = '999' then
          raise;
        end if;
        return ls_returncode;
END;                                   
END;
/

