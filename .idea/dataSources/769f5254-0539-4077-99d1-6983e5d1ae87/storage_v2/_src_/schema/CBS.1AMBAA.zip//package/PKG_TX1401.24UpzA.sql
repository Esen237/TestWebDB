create PACKAGE PKG_TX1401 IS

/******************************************************************************
   Name       : PKG_TX1401
   Created By : Bilal GUL
   Date    	  : 03.12.03
   Purpose	  : Kredi Teminatlar?n?n G?ncellenmesi
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure	Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure  Guncelleme_Kontrolu(pn_islem_no NUMBER,
  			 					 ps_block	 VARCHAR2,
								 ps_rowid   	 VARCHAR2,
		  				   		 ps_column  	 VARCHAR2,
  		   				   		 pd_column  	 VARCHAR2,
								 ps_oldvalue IN OUT VARCHAR2);

  Procedure KrediTeminatBilgiAktar(pn_txno number,ps_musteri_no number,ps_teminat_sira_no varchar2);

  Procedure muhasebe_sonrasi_onay(pn_islem_no number);
END;

/

