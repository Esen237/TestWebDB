create PACKAGE BODY     Pkg_Int_Limit IS

FUNCTION GetLimitInfo(pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ln_musterino  NUMBER;
	ln_limitflag  NUMBER;
	ln_limit_code_flag NUMBER;

	ln_CUSTGUVLIMIT NUMBER;
	ls_count NUMBER:=0;
BEGIN

	SELECT COUNT(*)
	INTO ln_limit_code_flag
	FROM CBS_INT_LIMIT_CODES A
    WHERE a.MUSTERI_NO=pn_musteri_no
	AND a.TRAN_CD=ps_trancd;

	IF ln_limit_code_flag=0 THEN
	INSERT INTO CBS_INT_LIMIT_CODES
		(MUSTERI_NO, TRAN_CD, LIMIT_CODE)
		VALUES
		(pn_musteri_no,ps_trancd,'1');
	END IF;

	SELECT COUNT(*)
	INTO ln_limitflag
	FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no
	AND a.TRAN_CD=ps_trancd
	AND a.LIMIT_DATE=TRUNC(SYSDATE);

	IF ln_limitflag=0 THEN
		INSERT INTO CBS_INT_LIMIT_CUSTOMER
		(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
		VALUES
		(pn_musteri_no, 0, ps_trancd, TRUNC(SYSDATE));
	END IF;

-- bu adam?n kenid ?zel limit var m??
-- var ise ona g?re de?er g?nder
-- yok ise i?lem yapt?rma


    SELECT COUNT(*)
	INTO ls_count
	FROM CBS_INT_LIMIT_CUST_GUV G
	WHERE G.MUSTERINO=pn_musteri_no
	AND G.TRANTYPE=ps_trancd
	AND G.GUNLUKLIMIT IS NOT NULL;

	IF (ls_count > 0) THEN
		OPEN pc_ref FOR
		SELECT b.LOWER_LIMIT, b.UPPER_LIMIT, g.GUNLUKLIMIT-a.LIMIT_USED, b.MULTIPLIER ,b.LIMIT_CURRENCY
		FROM CBS_INT_LIMIT_CUSTOMER a,CBS_INT_LIMIT_CODES c,CBS_INT_LIMIT b,CBS_INT_LIMIT_CUST_GUV g
		WHERE a.MUSTERI_NO=TO_NUMBER(pn_musteri_no)
		AND a.MUSTERI_NO=c.MUSTERI_NO
		AND a.TRAN_CD=c.TRAN_CD
		AND c.TRAN_CD=b.TRAN_CD
		AND c.LIMIT_CODE=b.LIMIT_CODE
		AND a.TRAN_CD=ps_trancd
		AND g.TRANTYPE=ps_trancd
		AND g.MUSTERINO=TO_NUMBER(pn_musteri_no)
		AND a.LIMIT_DATE=TRUNC(SYSDATE);
	ELSE
		OPEN pc_ref FOR
		SELECT b.LOWER_LIMIT, b.UPPER_LIMIT, b.DAILY_LIMIT-a.LIMIT_USED, b.MULTIPLIER ,b.LIMIT_CURRENCY
		FROM CBS_INT_LIMIT_CUSTOMER a,CBS_INT_LIMIT_CODES c,CBS_INT_LIMIT b
		WHERE a.MUSTERI_NO=TO_NUMBER(pn_musteri_no)
		AND a.MUSTERI_NO=c.MUSTERI_NO
		AND a.TRAN_CD=c.TRAN_CD
		AND c.TRAN_CD=b.TRAN_CD
		AND c.LIMIT_CODE=b.LIMIT_CODE
		AND a.TRAN_CD=ps_trancd
		AND a.LIMIT_DATE=TRUNC(SYSDATE);
	END IF;



  RETURN ls_returncode;

EXCEPTION
		 WHEN NO_DATA_FOUND THEN
		 	  RETURN '050';
END;
----------------------------------------------------------------------------------------------
FUNCTION CheckLimit(pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
		 				pn_amount IN VARCHAR2,
						ps_currcode IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode VARCHAR2(3):='000';
	ln_musterino  NUMBER;
	ln_LOWER_LIMIT NUMBER;
	ln_UPPER_LIMIT NUMBER;
	ln_DAILY_LIMIT NUMBER;
	ln_MULTIPLIER NUMBER;
	ln_LIMIT_USED NUMBER;
	ln_CUSTGUVLIMIT NUMBER;

	ln_amount NUMBER;
	LimitErrorException	 EXCEPTION;
	ls_limitcurr		 VARCHAR2(3);
	ls_count NUMBER:=0;

BEGIN

	OPEN pc_ref FOR
	 SELECT 'DUMMY' FROM dual;

	-- ?nce m??teri ?zel bir limit var m??
	-- var ise bunu kullanca??m

    SELECT COUNT(*)
	INTO ls_count
	FROM CBS_INT_LIMIT_CUST_GUV G
	WHERE G.MUSTERINO=pn_musteri_no
	AND G.TRANTYPE=ps_trancd
	AND G.GUNLUKLIMIT IS NOT NULL;

	IF (ls_count > 0) THEN
	    SELECT G.GUNLUKLIMIT
		INTO ln_CUSTGUVLIMIT
		FROM CBS_INT_LIMIT_CUST_GUV G
		WHERE G.MUSTERINO=pn_musteri_no
		AND G.TRANTYPE=ps_trancd
		AND G.GUNLUKLIMIT IS NOT NULL;
	END IF;

	SELECT b.LOWER_LIMIT, b.UPPER_LIMIT, b.DAILY_LIMIT, b.MULTIPLIER, a.LIMIT_USED, b.LIMIT_CURRENCY
	INTO ln_LOWER_LIMIT, ln_UPPER_LIMIT, ln_DAILY_LIMIT, ln_MULTIPLIER, ln_LIMIT_USED,ls_limitcurr
	FROM CBS_INT_LIMIT_CUSTOMER a,CBS_INT_LIMIT_CODES c,CBS_INT_LIMIT b
	WHERE a.MUSTERI_NO=TO_NUMBER(pn_musteri_no)
	AND a.MUSTERI_NO=c.MUSTERI_NO
	AND a.TRAN_CD=c.TRAN_CD
	AND c.TRAN_CD=b.TRAN_CD
	AND c.LIMIT_CODE=b.LIMIT_CODE
	AND a.TRAN_CD=ps_trancd
	AND a.LIMIT_DATE=TRUNC(SYSDATE);

	ln_amount:=TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.',','));
	ln_amount:=Pkg_Kur.YUVARLA(ps_currcode,Pkg_Kur.doviz_doviz_karsilik(ps_currcode,ls_limitcurr,NULL,ln_amount,1,NULL,NULL,'O','A'));

	--Lower Limit control
	IF ln_amount< ln_LOWER_LIMIT THEN
	   ls_returncode:='051';
	   RAISE LimitErrorException;
	END IF;

	-- Upper Limit
	IF ln_amount> ln_UPPER_LIMIT THEN
	   ls_returncode:='052';
	   RAISE LimitErrorException;
	END IF;

	IF (ln_CUSTGUVLIMIT > 0) THEN
		--Daily Limit control
		IF (ln_amount+ln_LIMIT_USED)> ln_CUSTGUVLIMIT THEN
		   ls_returncode:='053';
		   RAISE LimitErrorException;
		END IF;
	END IF;

	--Daily Limit control
	IF (ln_amount+ln_LIMIT_USED)> ln_DAILY_LIMIT THEN
	   ls_returncode:='053';
	   RAISE LimitErrorException;
	END IF;

		--Multiplier control
	IF MOD(TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.',',')),ln_MULTIPLIER)!=0 THEN
	   ls_returncode:='054';
	   RAISE LimitErrorException;
	END IF;


  RETURN ls_returncode;

EXCEPTION
		 WHEN LimitErrorException THEN
		 	  RETURN ls_returncode;
		 WHEN OTHERS THEN
		 	  Log_At(SQLERRM,ps_currcode);
		 	  RETURN '050';
END;
----------------------------------------------------------------------------------------------
FUNCTION UpdateLimit(ps_type IN VARCHAR2,
		 			    pn_musteri_no IN VARCHAR2,
		 				ps_trancd IN VARCHAR2,
		 				pn_amount IN VARCHAR2,
						ps_currcode IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ln_musterino  NUMBER;
	ln_LOWER_LIMIT NUMBER;
	ln_UPPER_LIMIT NUMBER;
	ln_DAILY_LIMIT NUMBER;
	ln_MULTIPLIER NUMBER;
	ln_LIMIT_USED NUMBER;

	ln_amount NUMBER;

BEGIN

    OPEN pc_ref FOR
	 SELECT 'DUMMY' FROM dual;

	IF ps_type='PLUS' THEN
	   ln_amount:=TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.',','));
	ELSE
	   ln_amount:=-1*TO_NUMBER(REPLACE(REPLACE(pn_amount,',',''),'.',','));
	END IF;

	UPDATE CBS_INT_LIMIT_CUSTOMER a
	SET a.LIMIT_USED=a.LIMIT_USED+ln_amount
	WHERE a.MUSTERI_NO=pn_musteri_no
	AND a.TRAN_CD=ps_trancd
	AND a.LIMIT_DATE=TRUNC(SYSDATE);


  RETURN ls_returncode;

EXCEPTION
		 WHEN OTHERS THEN
		 	  RETURN '050';
END;

----------------------------------------------------------------------------------------------
FUNCTION GetTranLimits(pn_musteri_no IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode VARCHAR2(3):='000';
	ln_limit_code_flag   NUMBER:=0;
	ln_limitflag NUMBER:=0;
BEGIN
-- Bu ki?iye ait limit bilgileri daha ?nceden girilmemi? ise girilmektedir.

	SELECT COUNT(*)
	INTO ln_limit_code_flag FROM CBS_INT_LIMIT_CODES A WHERE a.MUSTERI_NO=pn_musteri_no	AND a.TRAN_CD='B2OBHVL';
	IF ln_limit_code_flag=0 THEN
	INSERT INTO CBS_INT_LIMIT_CODES (MUSTERI_NO, TRAN_CD, LIMIT_CODE)VALUES(pn_musteri_no,'B2OBHVL','1');END IF;

	SELECT COUNT(*)
	INTO ln_limit_code_flag FROM CBS_INT_LIMIT_CODES A WHERE a.MUSTERI_NO=pn_musteri_no	AND a.TRAN_CD='EXCHNGSELL';
	IF ln_limit_code_flag=0 THEN
	INSERT INTO CBS_INT_LIMIT_CODES (MUSTERI_NO, TRAN_CD, LIMIT_CODE)VALUES(pn_musteri_no,'EXCHNGSELL','1');END IF;

	SELECT COUNT(*)
	INTO ln_limit_code_flag FROM CBS_INT_LIMIT_CODES A WHERE a.MUSTERI_NO=pn_musteri_no	AND a.TRAN_CD='EXCHNGBUY';
	IF ln_limit_code_flag=0 THEN
	INSERT INTO CBS_INT_LIMIT_CODES (MUSTERI_NO, TRAN_CD, LIMIT_CODE)VALUES(pn_musteri_no,'EXCHNGBUY','1');END IF;

	SELECT COUNT(*)
	INTO ln_limit_code_flag FROM CBS_INT_LIMIT_CODES A WHERE a.MUSTERI_NO=pn_musteri_no	AND a.TRAN_CD='EFT';
	IF ln_limit_code_flag=0 THEN
	INSERT INTO CBS_INT_LIMIT_CODES (MUSTERI_NO, TRAN_CD, LIMIT_CODE)VALUES(pn_musteri_no,'EFT','1');END IF;

	-- vadeli hesap a??l?nca bunu da a?
	--SELECT COUNT(*)
	--INTO ln_limit_code_flag FROM CBS_INT_LIMIT_CODES A WHERE a.MUSTERI_NO=pn_musteri_no	AND a.TRAN_CD='TDACCOPEN';
	--IF ln_limit_code_flag=0 THEN
	--INSERT INTO CBS_INT_LIMIT_CODES (MUSTERI_NO, TRAN_CD, LIMIT_CODE)VALUES(pn_musteri_no,'TDACCOPEN','1');END IF;


	SELECT COUNT(*)	INTO ln_limitflag FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no AND a.TRAN_CD='B2OBHVL' AND a.LIMIT_DATE=TRUNC(SYSDATE);
	IF ln_limitflag=0 THEN INSERT INTO CBS_INT_LIMIT_CUSTOMER(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
	VALUES(pn_musteri_no, 0, 'B2OBHVL', TRUNC(SYSDATE));END IF;

	SELECT COUNT(*)	INTO ln_limitflag FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no AND a.TRAN_CD='EXCHNGSELL' AND a.LIMIT_DATE=TRUNC(SYSDATE);
	IF ln_limitflag=0 THEN INSERT INTO CBS_INT_LIMIT_CUSTOMER(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
	VALUES(pn_musteri_no, 0, 'EXCHNGSELL', TRUNC(SYSDATE));END IF;

	SELECT COUNT(*)	INTO ln_limitflag FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no AND a.TRAN_CD='EXCHNGBUY' AND a.LIMIT_DATE=TRUNC(SYSDATE);
	IF ln_limitflag=0 THEN INSERT INTO CBS_INT_LIMIT_CUSTOMER(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
	VALUES(pn_musteri_no, 0, 'EXCHNGBUY', TRUNC(SYSDATE));END IF;

	SELECT COUNT(*)	INTO ln_limitflag FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no AND a.TRAN_CD='EXCHNGBUY' AND a.LIMIT_DATE=TRUNC(SYSDATE);
	IF ln_limitflag=0 THEN INSERT INTO CBS_INT_LIMIT_CUSTOMER(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
	VALUES(pn_musteri_no, 0, 'EXCHNGBUY', TRUNC(SYSDATE));END IF;

	SELECT COUNT(*)	INTO ln_limitflag FROM CBS_INT_LIMIT_CUSTOMER a
	WHERE a.MUSTERI_NO=pn_musteri_no AND a.TRAN_CD='EFT' AND a.LIMIT_DATE=TRUNC(SYSDATE);
	IF ln_limitflag=0 THEN INSERT INTO CBS_INT_LIMIT_CUSTOMER(MUSTERI_NO, LIMIT_USED, TRAN_CD, LIMIT_DATE)
	VALUES(pn_musteri_no, 0, 'EFT', TRUNC(SYSDATE));END IF;



	 OPEN pc_ref FOR
	   SELECT c.tran_cd, b.LOWER_LIMIT, b.UPPER_LIMIT, b.DAILY_LIMIT-NVL(a.LIMIT_USED,0), b.MULTIPLIER ,b.LIMIT_CURRENCY,b.DESCRIPTION,b.DAILY_LIMIT
				FROM CBS_INT_LIMIT_CODES c,CBS_INT_LIMIT b,CBS_INT_LIMIT_CUSTOMER a
				WHERE c.MUSTERI_NO=TO_NUMBER(pn_musteri_no)
				AND c.TRAN_CD=b.TRAN_CD
				AND c.LIMIT_CODE=b.LIMIT_CODE
				AND a.MUSTERI_NO(+)=c.MUSTERI_NO
				AND a.TRAN_CD(+)=c.TRAN_CD
				AND a.LIMIT_DATE(+)=TRUNC(SYSDATE);
	RETURN ls_returncode;
END;

----------------------------------------------------------------------------------------------
FUNCTION SetCustomerLimits(pn_musteri_no IN VARCHAR2,
		 				pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode		VARCHAR2(3):='000';
BEGIN
	 --LIMIT_CODE=1 en dusuk limit duzeyi--DEGISTIRILEBILIR
	 INSERT INTO CBS_INT_LIMIT_CODES(MUSTERI_NO, TRAN_CD, LIMIT_CODE)
	 SELECT pn_musteri_no,TRAN_CD,LIMIT_CODE FROM CBS_INT_LIMIT WHERE LIMIT_CODE=1;

	 RETURN ls_returncode;
END;

--------------------------------------------------------------------------------------
FUNCTION GetGnLimitInfo(pn_musteri_no IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode VARCHAR2(3):='000';
BEGIN
	 OPEN pc_ref FOR
	   SELECT tran_cd, LOWER_LIMIT, UPPER_LIMIT, DAILY_LIMIT,LIMIT_CURRENCY,DESCRIPTION,LIMIT_CODE,MULTIPLIER
    	FROM CBS_INT_LIMIT;

	RETURN ls_returncode;
END;

--------------------------------------------------------------------------------------
FUNCTION SetGnLimitInfo(pn_trancd IN VARCHAR2,
                        pn_lowerlimit IN VARCHAR2,
						pn_upperlimit IN VARCHAR2,
                        pn_dailylimit IN VARCHAR2,
						pn_limitcurrency IN VARCHAR2,
						pn_limitcode IN VARCHAR2,
 					    pn_multiplier IN VARCHAR2,
						pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	LimitErrorException	 EXCEPTION;

BEGIN

	OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;
	/* dummy expressions */

	IF ( TO_NUMBER(REPLACE(REPLACE(pn_lowerlimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')))THEN
	ls_returncode :='061'; /*alt de?er ?st de?erden b?y?k olamaz*/
	RAISE LimitErrorException;
	END IF;

	IF (TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(pn_dailylimit,',',''),'.',',')))THEN
	ls_returncode :='062'; /*?st de?er g?nl?k de?erden b?y?k olamaz*/
	RAISE LimitErrorException;
	END IF;

	IF (TO_NUMBER(REPLACE(REPLACE(pn_multiplier,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(pn_lowerlimit,',',''),'.',',')))THEN
	ls_returncode :='063'; /*?st de?er g?nl?k de?erden b?y?k olamaz*/
	RAISE LimitErrorException;
	END IF;


	UPDATE CBS_INT_LIMIT a
	SET
	(a.LOWER_LIMIT,a.UPPER_LIMIT,a.DAILY_LIMIT,a.MULTIPLIER) =
	(
	SELECT TO_NUMBER(REPLACE(REPLACE(pn_lowerlimit,',',''),'.',',')),
	 TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')),
	 TO_NUMBER(REPLACE(REPLACE(pn_dailylimit,',',''),'.',',')),
	 TO_NUMBER(REPLACE(REPLACE(pn_multiplier,',',''),'.',','))
	 FROM dual)
    WHERE
	a.TRAN_CD = pn_trancd AND a.LIMIT_CURRENCY = pn_limitcurrency AND a.LIMIT_CODE=TO_NUMBER(pn_limitcode);

	RETURN ls_returncode;

EXCEPTION
		 WHEN LimitErrorException THEN
		 	  RETURN ls_returncode;
		 WHEN OTHERS THEN
		 	  RETURN '050';
END;

---------------------------------------------------------------------------------------

FUNCTION CreateGnLimitInfo( pn_trancd IN VARCHAR2,
                            pn_lowerlimit IN VARCHAR2,
							pn_upperlimit IN VARCHAR2,
                            pn_dailylimit IN VARCHAR2,
							pn_limitcurrency IN VARCHAR2,
							pn_multiplier IN VARCHAR2,
                            pn_description IN VARCHAR2,
							pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    LimitErrorException	 EXCEPTION;
	ls_returncode VARCHAR2(3):='000';
	cnt NUMBER;

BEGIN

	OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;
	/*dummy expressions*/

	IF ( TO_NUMBER(REPLACE(REPLACE(pn_lowerlimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')))THEN
	ls_returncode :='061'; /*alt de?er ?st de?erden b?y?k olamaz*/
	RAISE LimitErrorException;
	END IF;

	IF (TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(pn_dailylimit,',',''),'.',',')))THEN
	ls_returncode :='062'; /*?st de?er g?nl?k de?erden b?y?k olamaz*/
	RAISE LimitErrorException;
	END IF;



	SELECT COUNT(*) INTO cnt FROM
	CBS_INT_LIMIT WHERE TRAN_CD=pn_trancd;
	/*and LIMIT_CURRENCY=pn_limitcurrency;*/ /*Bunu timu?ine sor*/

	IF (cnt = 0) THEN
	 INSERT INTO
	 CBS_INT_LIMIT(LIMIT_CODE, TRAN_CD, LOWER_LIMIT, UPPER_LIMIT, DAILY_LIMIT, MULTIPLIER, LIMIT_CURRENCY, DESCRIPTION)
	 VALUES (1, /*defaul olarak 1 kaydediyorum*/
	         pn_trancd,
			 TO_NUMBER(REPLACE(REPLACE(pn_lowerlimit,',',''),'.',',')),
			 TO_NUMBER(REPLACE(REPLACE(pn_upperlimit,',',''),'.',',')),
			 TO_NUMBER(REPLACE(REPLACE(pn_dailylimit,',',''),'.',',')),
			 TO_NUMBER(pn_multiplier),
			 pn_limitcurrency,
			 pn_description);
	 ELSE
	 ls_returncode:='055';
	 RAISE LimitErrorException;
	 END IF;
	RETURN ls_returncode;

	EXCEPTION
		 WHEN LimitErrorException THEN
		 	  RETURN ls_returncode;
END;
---------------------------------------------------------------------------------------
FUNCTION DeleteGnLimitInfo(pn_trancd IN VARCHAR2,
                           pn_limitcurrency IN VARCHAR2,
						   pn_limitcode IN VARCHAR2,
						   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode VARCHAR2(3):='000';
	cnt NUMBER;

BEGIN

	OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;/*dummy expressions*/

	DELETE FROM CBS_INT_LIMIT
	WHERE LIMIT_CODE=TO_NUMBER(pn_limitcode) AND TRAN_CD=pn_trancd AND LIMIT_CURRENCY=pn_limitcurrency;

	RETURN ls_returncode;

	EXCEPTION
      	 WHEN OTHERS THEN
		 	  RETURN '050';
END;
--------------------------------------------------------------
FUNCTION GetMusteriGuvLimitleri(pn_customerid IN VARCHAR2,
		                        pn_trancd IN VARCHAR2,
								PC_REF OUT CursorReferenceType) RETURN VARCHAR2 IS
	ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN PC_REF FOR
	SELECT G.TRANTYPE,
	       L.DESCRIPTION,
		   G.GUNLUKLIMIT,
		   G.ONAYLIMIT,
		   G.BILGILIMIT,
		   G.ONAYTYPE,
		   G.BILGITYPE
	FROM CBS_INT_LIMIT_CUST_GUV G,CBS_INT_LIMIT L
	WHERE G.MUSTERINO=pn_customerid
	      AND G.TRANTYPE=pn_trancd
		  AND L.TRAN_CD=G.TRANTYPE;
    RETURN ls_returncode;

EXCEPTION
	WHEN OTHERS THEN
	RETURN '999';
END;
---------------------------------------------------------------
FUNCTION GetSysTranLimitInfo(
		   ps_transcd IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
		   -- sadece belli bir transactionun g?nl?k limitini g?sterir
	ls_returncode VARCHAR2(3):='000';
BEGIN
	 OPEN pc_ref FOR
	   SELECT tran_cd, LOWER_LIMIT, UPPER_LIMIT, DAILY_LIMIT,LIMIT_CURRENCY,DESCRIPTION,LIMIT_CODE,MULTIPLIER
    	FROM CBS_INT_LIMIT T WHERE T.TRAN_CD=ps_transcd;

	RETURN ls_returncode;
END;
---------------------------------------------------------------
FUNCTION GetKullaniciLimitDegerKontrol(
           ps_islemtur IN VARCHAR2,
		   ps_gunluklimit IN VARCHAR2,
		   ps_onaylimit IN VARCHAR2,
		   ps_bilgilimit IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	       ls_returncode VARCHAR2(3):='000';
		   pn_gunluksyslimit NUMBER := 0 ;
BEGIN

    SELECT DAILY_LIMIT
	INTO  pn_gunluksyslimit
	FROM CBS_INT_LIMIT p
	WHERE p.TRAN_CD=ps_islemtur;

    OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;

    IF (ps_gunluklimit IS NOT NULL) THEN
	    IF (TO_NUMBER(REPLACE(REPLACE(ps_gunluklimit,',',''),'.',',')) > pn_gunluksyslimit ) THEN
			RETURN '701'; -- g?nl?k limit sistem limitinden fazla olamaz
		END IF;
	END IF;

	IF (ps_bilgilimit IS NOT NULL) THEN
        IF (ps_gunluklimit IS NOT NULL) THEN
		     IF (TO_NUMBER(REPLACE(REPLACE(ps_bilgilimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(ps_gunluklimit,',',''),'.',','))) THEN
				RETURN '702'; -- bilgi limiti g?nl?k limitden fazla olamaz
	 		 END IF;
		ELSIF (TO_NUMBER(REPLACE(REPLACE(ps_bilgilimit,',',''),'.',',')) > pn_gunluksyslimit ) THEN
			RETURN '703'; -- bilgi limiti sistem limitden fazla olamaz
		END IF;
	END IF;

   IF (ps_onaylimit IS NOT NULL) THEN
		IF (ps_gunluklimit IS NOT NULL) THEN
		     IF (TO_NUMBER(REPLACE(REPLACE(ps_onaylimit,',',''),'.',',')) > TO_NUMBER(REPLACE(REPLACE(ps_gunluklimit,',',''),'.',','))) THEN
				RETURN '705'; -- onay gunklukden fazla olamaz
	 		 END IF;
        ELSIF (TO_NUMBER(REPLACE(REPLACE(ps_onaylimit,',',''),'.',',')) > pn_gunluksyslimit ) THEN
			RETURN '706'; -- onay sistem limitinden fazla olamaz
		END IF;
   END IF;

	RETURN ls_returncode;
END;
--------------------------------------------------------------------------
FUNCTION SetKullaniciGuvLimitDeger(
           ps_islemtur IN VARCHAR2,
		   ps_gunluklimit IN VARCHAR2,
		   ps_onaylimit IN VARCHAR2,
		   ps_bilgilimit IN VARCHAR2,
		   ps_onaytur IN VARCHAR2,
		   ps_bilgitur IN VARCHAR2,
		   ps_customerid IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
 		   ls_returncode VARCHAR2(3):='000';
		   pn_onaytur VARCHAR2(1):='';
		   pn_bilgitur VARCHAR2(1):='';
BEGIN
	-- ?nce var olan limitleri siliyorum
	DELETE FROM CBS_INT_LIMIT_CUST_GUV g
	WHERE G.MUSTERINO=ps_customerid AND
	g.TRANTYPE=ps_islemtur;

	IF (ps_onaylimit IS NOT NULL) THEN
	pn_onaytur := ps_onaytur;
	END IF;

	IF (ps_bilgilimit IS NOT NULL) THEN
	pn_bilgitur := ps_bilgitur;
	END IF;


	IF (NOT((ps_gunluklimit IS NULL) AND (ps_onaylimit IS NULL) AND (ps_bilgilimit IS NULL)))  THEN

	INSERT INTO
	CBS_INT_LIMIT_CUST_GUV(MUSTERINO,
						   TRANTYPE,
						   GUNLUKLIMIT,
						   ONAYLIMIT,
						   BILGILIMIT,
						   ONAYTYPE,
						   BILGITYPE,
						   STATUS)
	VALUES (ps_customerid,
	        ps_islemtur,
			TO_NUMBER(REPLACE(REPLACE(ps_gunluklimit,',',''),'.',',')),
			TO_NUMBER(REPLACE(REPLACE(ps_onaylimit,',',''),'.',',')),
			TO_NUMBER(REPLACE(REPLACE(ps_bilgilimit,',',''),'.',',')),
			pn_onaytur,
			pn_bilgitur,
			'sACTIVE');
	END IF;

	OPEN PC_REF FOR
	SELECT SYSDATE FROM DUAL;
	COMMIT;

	RETURN ls_returncode;
END;
-----------------------------------------------------------
FUNCTION  CheckKullaniciGuvLimitDeger(
           ps_islemtur IN VARCHAR2,
		   ps_customerid IN VARCHAR2,
		   ps_amount IN VARCHAR2,
		   ps_tur IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

		   ls_returncode VARCHAR2(3):='000';
		   ps_custamount NUMBER;
		   ps_onaytype VARCHAR2(3):='000';
		   ps_bilgitype VARCHAR2(3):='000';
		   ls_count NUMBER:=0;
		   ps_sonuc VARCHAR2(3):='000';
BEGIN


	-- e?er onay limit var ise ve kullan?c?ya sms ile mesaj gidecek ise
	-- girilen de?er ile bu limit kar??la?t?r?l?r
	-- a??yor ise mesaj yarat?l?r...

	IF (ps_tur = 'onay') THEN

		SELECT COUNT(*)
		INTO ls_count
		FROM CBS_INT_LIMIT_CUST_GUV G
		WHERE g.MUSTERINO=ps_customerid
		AND g.TRANTYPE=ps_islemtur
		AND g.ONAYLIMIT IS NOT NULL
		AND g.ONAYTYPE IS NOT NULL;

	    IF (ls_count > 0) THEN

			SELECT G.ONAYLIMIT,G.ONAYTYPE
			INTO ps_custamount,ps_onaytype
			FROM CBS_INT_LIMIT_CUST_GUV G
			WHERE g.MUSTERINO=ps_customerid
			AND g.TRANTYPE=ps_islemtur
			AND g.ONAYLIMIT IS NOT NULL
			AND g.ONAYTYPE IS NOT NULL;

		    IF (TO_NUMBER(REPLACE(REPLACE(ps_amount,',',''),'.',',')) >= ps_custamount) THEN

				IF (ps_onaytype = 'S' ) THEN
				    ps_sonuc := '111';-- sms g?nder
				ELSE
				    ps_sonuc := '222';-- token olay?
				END IF;
		    END IF;
		END IF;
    ELSIF (ps_tur = 'bilgi') THEN

		SELECT COUNT(*)
		INTO ls_count
		FROM CBS_INT_LIMIT_CUST_GUV G
		WHERE g.MUSTERINO=ps_customerid
		AND g.TRANTYPE=ps_islemtur
		AND g.BILGILIMIT IS NOT NULL
		AND g.BILGITYPE IS NOT NULL;

	    IF (ls_count > 0) THEN

			SELECT G.BILGILIMIT ,G.BILGITYPE
			INTO ps_custamount,ps_bilgitype
			FROM CBS_INT_LIMIT_CUST_GUV G
			WHERE g.MUSTERINO=ps_customerid
			AND g.TRANTYPE=ps_islemtur
			AND g.BILGILIMIT IS NOT NULL
			AND g.BILGITYPE IS NOT NULL;

		    IF (TO_NUMBER(REPLACE(REPLACE(ps_amount,',',''),'.',',')) >= ps_custamount) THEN

				IF (ps_bilgitype = 'S' ) THEN
				    ps_sonuc := '111';-- sms g?nder
				ELSIF (ps_bilgitype = 'E' ) THEN
				    ps_sonuc := '222';-- mail at
				ELSE
				    ps_sonuc := '333';-- hem mail at hem de sms at nas?lsa bele?...
				END IF;
		    END IF;
		END IF;
	END IF;

    OPEN PC_REF FOR
	SELECT ps_sonuc FROM DUAL;

	RETURN ls_returncode;
END;
---------------------------------------------------------
FUNCTION  SendSMS(
		   ps_customerid IN VARCHAR2,
		   ps_message IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ls_count NUMBER;
	ps_phonenumber VARCHAR2(200):='000';

BEGIN

	OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;/*dummy expressions*/


    SELECT COUNT(*)
	INTO ls_count
	FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
	WHERE m.musteri_no = TO_NUMBER(ps_customerid)
	AND m.musteri_no = a.musteri_no
	AND m.EXTRE_ADRES_KOD = a.ADRES_KOD
	AND a.GSM_ALAN_KOD IS NOT NULL
	AND a.GSM_NO IS NOT NULL;


	IF (ls_count > 0) THEN

	    SELECT a.GSM_ALAN_KOD||a.GSM_NO
		INTO ps_phonenumber
		FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
		WHERE m.musteri_no = TO_NUMBER(ps_customerid)
		AND m.musteri_no = a.musteri_no
		AND m.EXTRE_ADRES_KOD = a.ADRES_KOD;

        --send_sms(ps_phonenumber,ps_message); -- sms yi g?nder
	ELSE
		ls_returncode:='892';-- numara yok karde?im mesaj?
	END IF;

	RETURN ls_returncode;
	EXCEPTION
      	 WHEN OTHERS THEN
		 	  RETURN '999';
END;
--------------------------------------------------------------
FUNCTION  SendHatasizSmsMessage(
		   ps_customerid IN VARCHAR2,
		   ps_message IN VARCHAR2,
		   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

	ls_returncode VARCHAR2(3):='000';
	ls_count NUMBER;
	ps_phonenumber VARCHAR2(200):='000';

BEGIN

	OPEN pc_ref FOR
	SELECT SYSDATE FROM dual;/*dummy expressions*/

    SELECT COUNT(*)
	INTO ls_count
	FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
	WHERE m.musteri_no = TO_NUMBER(ps_customerid)
	AND m.musteri_no = a.musteri_no
	AND m.EXTRE_ADRES_KOD = a.ADRES_KOD
	AND a.GSM_ALAN_KOD IS NOT NULL
	AND a.GSM_NO IS NOT NULL;


	IF (ls_count > 0) THEN

	    SELECT a.GSM_ALAN_KOD||a.GSM_NO
		INTO ps_phonenumber
		FROM CBS_MUSTERI m,CBS_MUSTERI_ADRES a
		WHERE m.musteri_no = TO_NUMBER(ps_customerid)
		AND m.musteri_no = a.musteri_no
		AND m.EXTRE_ADRES_KOD = a.ADRES_KOD;

        --send_sms(ps_phonenumber,ps_message); -- sms yi g?nder
	END IF;

	RETURN ls_returncode;
	EXCEPTION
      	 WHEN OTHERS THEN
		 	  RETURN '999';
END;
--------------------------------------------------------------
Function CheckTimeLimit(ps_trancd varchar2) return varchar2 is
		ln_START_HH24 number;
		ln_START_MM number;
		ln_END_HH24 number;
		ln_END_MM number;

		ln_current_hh24 number;
		ln_current_mm number;

		TimeException exception;
BEGIN
	 select START_HH24, START_MM, END_HH24, END_MM
	 into ln_START_HH24, ln_START_MM, ln_END_HH24, ln_END_MM
	 from cbs_int_time
	 where tran_cd=ps_trancd;

	 ln_current_hh24:=to_number(to_char(sysdate,'HH24'));
	 ln_current_mm:=to_number(to_char(sysdate,'MI'));

	 if ln_END_HH24<ln_current_hh24 then
	 	raise TimeException;
	 else
	 	 if ln_END_HH24=ln_current_hh24 then
		 	 if ln_END_MM<=ln_current_mm then
			 	raise TimeException;
			 end if;
		 end if;
	 end if;

--	 log_at(ln_START_HH24,ln_current_hh24,ln_START_MM,ln_current_mm);

	 if ln_START_HH24>ln_current_hh24 then
	 	raise TimeException;
	 else
	 	 if ln_START_HH24=ln_current_hh24 then
		 	 if ln_START_MM>=ln_current_mm then
			 	raise TimeException;
			 end if;
		 end if;
	 end if;

	 return '000';

exception
		when TimeException then
			 return '056';
END;
--------------------------------------------------------------


END;
/

