create package pkg_rapor is

  -- Author  : G?lnihal_C
  -- Created :
  -- Purpose : BDDK ve TCMB i?in haz?rlanan g?zetim raporlar? i?in kullan?lmaktad?r.

  TYPE Generic_CurType IS REF CURSOR; /* Gulnihal 04/08/2003*/

  PROCEDURE sp_rpt_ULAS(pc_rapor   VARCHAR2, pRetCur IN OUT Pkg_rapor.Generic_CurType);
  Function  Sf_Rpt_SiraAdi( ps_rpt_raporkod cbs_rpt_hesaptip.raporkod%type,pn_rpt_sirano cbs_rpt_hesaptip.raporkod%type) return varchar2 ;
  Function  Sf_Rpt_satirsayisi(pc_tabloadi  VARCHAR2, pd_donem  DATE,pc_kosul  VARCHAR2  ) return NUMBER ;
  Function  Sf_Rpt_HesapAdi(pn_rpt_sirano cbs_rpt_hesapkod.hesapno%type) return varchar2 ;
  PROCEDURE sp_rpt_FR200AS(pc_rapor VARCHAR2,pd_donem  DATE,pc_parakod VARCHAR2,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_LR200AS(pc_rapor VARCHAR2,pd_donem  DATE,pc_parakod VARCHAR2,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KT100H(pc_rapor VARCHAR2,pd_donem  DATE,pc_parakod VARCHAR2,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_GM200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_GS100AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_EK100US(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_CM100US(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_EM100AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_HS200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KA200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KR100AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KR201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KR202AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KR203AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KR206AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_KS100AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MB100AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_IS200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_FK100US(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_BD101AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_BL200GS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_BL201GS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_BL200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_BL201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_BL202AS(pc_rapor VARCHAR2,pd_donem  DATE,pn_subekodu NUMBER,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_KZ200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_KZ201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_KZ202AS(pc_rapor VARCHAR2,pd_donem  DATE,pn_subekodu NUMBER,pRetCur  IN OUT Pkg_rapor.Generic_CurType);
  PROCEDURE sp_rpt_MB101AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MD200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MD201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MS200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MS201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MV101AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MZ200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_SY200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_ST300A(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_MD202HS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_RP200HS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_YY200HS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_NH200HS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_UL200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_UL201AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_YP200AS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_YP200HS(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_DP100H(pc_rapor VARCHAR2,pd_donem  DATE,pc_parakod VARCHAR2,pc_bilanco VARCHAR2,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_DOVIZTAKIP(pc_rapor VARCHAR2,pd_donem  DATE,pc_parakod VARCHAR2,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_TUKKREDFRM(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_AKTIFFRM(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
  PROCEDURE sp_rpt_PASIFFRM(pc_rapor VARCHAR2,pd_donem  DATE,pRetCur IN OUT Pkg_rapor.Generic_CurType );
end pkg_rapor;

/

