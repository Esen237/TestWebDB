create PACKAGE BODY     pkg_masraf_tx33207  IS
p_33207_FC_MSRF_DOVIZ_KODU        NUMBER;
p_33207_LC_MSRF_DOVIZ_KODU		  NUMBER;
p_33207_KUR						  NUMBER;
p_33207_REFERENCE				  NUMBER;
p_33207_ISTA_KOD				  NUMBER;
p_33207_MUS_ACIK				  NUMBER;
p_33207_BANKA_ACIK				  NUMBER;
p_33207_ISLEM_SUBE				  NUMBER;
p_33207_MASRAF_HESAP_DOVIZKODU	  NUMBER;
p_33207_FC_MASRAF_TUTARI		  NUMBER;
p_33207_LC_MASRAF_TUTAR			  NUMBER;
p_33207_MASRAF_HESAP_SUBE		  NUMBER;
p_33207_MASRAF_HESAP_NO			  NUMBER;
p_33207_LC_MAIL_CHARGE			  NUMBER;
p_33207_LC_COMM_CHARGE			  NUMBER;
p_33207_LC_CONF_COM				  NUMBER;
p_33207_LC_ADVICE_COM			  NUMBER;
p_33207_LC_COLL_COM			  	  NUMBER;
p_33207_LC_DIS_COM			  	  NUMBER;
p_33207_MAIL_CHARGE_GL			  NUMBER;
p_33207_COMM_CHARGE_GL			  NUMBER;
p_33207_CONF_COM_GL				  NUMBER;
p_33207_ADVICE_COM_GL			  NUMBER;
p_33207_COLLCOM_GL			  	  NUMBER;
p_33207_DISCOM_GL			  	  NUMBER;
p_33207_UNCOMFIRM				  NUMBER;
p_33207_COMFIRM					  NUMBER;
p_33207_FC						  NUMBER;
p_33207_LC						  NUMBER;
p_33207_MAILCOM_VAR				  NUMBER;
p_33207_COMMCOM_VAR				  NUMBER;
p_33207_CONFCOM_VAR				  NUMBER;
p_33207_ADVICECOM_VAR			  NUMBER;
p_33207_COLLCOM_VAR			  	  NUMBER;
p_33207_DISCOM_VAR			  	  NUMBER;
p_33207_FC_MASRAF_ANA			  NUMBER;
p_33207_LC_MASRAF_ANA			  NUMBER;
p_33207_MAILCOM_EXP				  NUMBER;
p_33207_COMMCOM_EXP				  NUMBER;
p_33207_CONFCOM_EXP				  NUMBER;
p_33207_ADVICECOM_EXP			  NUMBER;
p_33207_COLLCOM_EXP			  	  NUMBER;
p_33207_DISCOM_EXP			  	  NUMBER;

p_33207_LC_INQUIRY_CHARGE		  NUMBER;
p_33207_INQUIRY_CHARGE_GL		  NUMBER;
p_33207_INQUIRY_COM_VAR			  NUMBER;
p_33207_INQUIRY_COM_EXP			  NUMBER;


p_33207_VERGIDEN_MUAF_DEGIL		  NUMBER;
p_33207_LC_SERVICE_TAX   NUMBER;
p_33207_FC_SERVICE_TAX   NUMBER;

/*--------------------- ?THALAT ?HRACAT MASRAFLARI ----------------------------------------------*/
  Procedure Kontrol_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
   null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Onay_Sonrasi(pn_islem_no number, ps_ref varchar2, ps_no number) is
  begin
    pkg_masraf.onay_sonrasi(pn_islem_no, ps_ref, ps_no, 'O', 'EXPCONFCOM');
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Reddetme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
    pkg_masraf.Reddetme_Sonrasi(pn_islem_no, ps_ref);
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Basim_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  Begin
  	Null;
  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number, ps_ref varchar2) is		-- Islem iptal edilemez
  begin
    pkg_masraf.Iptal_Onay_Sonrasi_odeme(pn_islem_no, ps_ref);
  end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme(pn_islem_no number, pn_fis_no in out number) is
   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   ls_tahsil_doviz        varchar2(3);
   ls_hesap_doviz         varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_fc		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no number;
   ls_aciklama			  VARCHAR2(2000);
	ln_ser_tax number;
   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID'
	 order by sira_no desc   --en son girilen ?deme komisyonu ilk al?nmaya ?al???lacak...
	for update;
	row_masraf cur_masraf%rowtype;

   cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr_isl
	 where islem_no = pn_islem_no
	   and durum = 'VALID';
	 ln_temp number;

   cursor cur_po is
     select * from cbs_ihracat_odeme_islem
	  where tx_no = pn_islem_no;
	 row_po cur_po%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit_islem a
	  where islem_no = pn_islem_no --referans = ls_referans
	    and masraf_kodu = row_masraf.masraf_kodu
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
    ln_fis_no := pn_fis_no;
	open c_0;
	fetch c_0 into ln_temp;
	close c_0;
	if ln_temp <= 0 then
	  return;
	end if;

	open cur_po;
	fetch cur_po into row_po;
     varchar_list(p_33207_MASRAF_HESAP_NO) := row_po.masraf_hesap_no;
     varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_po.masraf_hesap_no);
	 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_po.masraf_hesap_no);
     varchar_list(p_33207_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_po.masraf_hesap_no);
	 ls_referans :=  row_po.referans_no;
 	 varchar_list(p_33207_ISLEM_SUBE) :=  pkg_tx.amir_bolumkodu_al(pn_islem_no); --pkg_baglam.bolum_kodu;
	close cur_po;

        boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33207_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
		boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
		boolean_list(p_33207_DISCOM_VAR) := FALSE ;
		boolean_list(p_33207_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33207_LC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33207_VERGIDEN_MUAF_DEGIL) := FALSE ;

	    IF varchar_list(p_33207_MASRAF_HESAP_NO) IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33207_MASRAF_HESAP_NO)) );
		   varchar_list(p_33207_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		   varchar_list(p_33207_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		   varchar_list(p_33207_CONF_COM_GL)	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCONFCOM');
		   varchar_list(p_33207_ADVICE_COM_GL) 	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPPAYMENT');
   		   varchar_list(p_33207_COLLCOM_GL) 	:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDOCCONT');
   		   varchar_list(p_33207_DISCOM_GL) 		:=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDISCREP');
		   varchar_list(p_33207_INQUIRY_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPINQUIRY');

    	ELSE
		   varchar_list(p_33207_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33207_COMM_CHARGE_GL) := '';
		   varchar_list(p_33207_CONF_COM_GL)	:= '';
		   varchar_list(p_33207_ADVICE_COM_GL) 	:= '';
	       varchar_list(p_33207_COLLCOM_GL) 	:='';
   		   varchar_list(p_33207_DISCOM_GL) 		:='';
		   varchar_list(p_33207_INQUIRY_CHARGE_GL) := '';
	    END IF;

     	   varchar_list(p_33207_REFERENCE) := ls_referans;
	       varchar_list(p_33207_ISTA_KOD)  := ls_istatistik_kodu;
        IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33207_FC_MSRF_DOVIZ_KODU) := TRUE ;

		ELSE
		   boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33207_FC_MSRF_DOVIZ_KODU) := FALSE;

		END IF;

		number_list(p_33207_LC_COMM_CHARGE) := 0;
		number_list(p_33207_LC_MAIL_CHARGE) := 0;
		number_list(p_33207_LC_CONF_COM) := 0;
		number_list(p_33207_LC_ADVICE_COM) := 0;
		number_list(p_33207_LC_COLL_COM) := 0;
		number_list(p_33207_LC_DIS_COM) := 0;
		number_list(p_33207_LC_INQUIRY_CHARGE) := 0;

		number_list(p_33207_LC_SERVICE_TAX) := 0;
		number_list(p_33207_FC_SERVICE_TAX) := 0;

		number_list(p_33207_LC_MASRAF_TUTAR) := 0;
		number_list(p_33207_FC_MASRAF_TUTARI) := 0;
		varchar_list(p_33207_MAILCOM_EXP)	:='';
		varchar_list(p_33207_COMMCOM_EXP)	:='';
	    varchar_list(p_33207_CONFCOM_EXP)	:='';
	    varchar_list(p_33207_ADVICECOM_EXP):='';
		varchar_list(p_33207_COLLCOM_EXP):='';
		varchar_list(p_33207_DISCOM_EXP):='';
		varchar_list(p_33207_INQUIRY_COM_EXP)	:='';

		ls_aciklama := 'EXPORT PAYMENT  ' ;
		varchar_list(p_33207_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33207_MUS_ACIK) :=varchar_list(p_33207_BANKA_ACIK) ;

		IF  varchar_list(p_33207_MASRAF_HESAP_NO) IS NOT NULL THEN  --masraf hesab? girilmi?se

			 if pkg_musteri.musteri_vergiden_muafmi(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33207_MASRAF_HESAP_NO))) = 'E'
			 then
				boolean_list(p_33207_VERGIDEN_MUAF_DEGIL) := FALSE ;
			 else
				boolean_list(p_33207_VERGIDEN_MUAF_DEGIL) := TRUE ;
			 end if;

		    IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) =pkg_genel.lc_al then
			   number_list(p_33207_KUR) := Pkg_Kur.mb_dak_to_lc(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),1);
			else
        	   number_list(p_33207_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),1);
			end if;
             --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33207_MASRAF_HESAP_NO));
        END IF;
    open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF nvl(row_masraf.tahsil_edilemeyen,0) > 0  THEN
      	  IF pkg_ihracat.masraf_kontrol_yap_nonakr(row_masraf.ODEYECEK) = 'Y'
		  THEN
		     ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
		    IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN  --haberle?me
				boolean_list(p_33207_COMMCOM_VAR) := TRUE ;
				number_list(p_33207_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_COMMCOM_EXP) :=row_po.referans_no||' Export Communication Charge ' ;

				ln_borc_trl := number_list(p_33207_LC_COMM_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
				number_list(p_33207_LC_SERVICE_TAX):=number_list(p_33207_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta
				boolean_list(p_33207_MAILCOM_VAR) := TRUE ;
				number_list(p_33207_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_MAILCOM_EXP)	:=row_po.referans_no||' Export Mail Charge';

				ln_borc_trl := number_list(p_33207_LC_MAIL_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
				number_list(p_33207_LC_SERVICE_TAX):=number_list(p_33207_LC_SERVICE_TAX)+ln_borc_trl;
			  ELSIF  row_masraf.masraf_kodu in ('EXPPAYMENT','EXPADVCOM') THEN   --Advise
				boolean_list(p_33207_ADVICECOM_VAR) := TRUE ;
				number_list(p_33207_LC_ADVICE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_ADVICECOM_EXP)	:=row_po.referans_no||' Export Payment Commission ' ;

				ln_borc_trl := number_list(p_33207_LC_ADVICE_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
			  ELSIF  row_masraf.masraf_kodu = 'EXPDOCCONT' THEN
				boolean_list(p_33207_COLLCOM_VAR) := TRUE ;
				number_list(p_33207_LC_COLL_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_COLLCOM_EXP)	:=row_po.referans_no||' Checking of Documents' ;

				ln_borc_trl := number_list(p_33207_LC_COLL_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
			  ELSIF  row_masraf.masraf_kodu = 'EXPDISCREP' THEN   --DISCREPANCY
				boolean_list(p_33207_DISCOM_VAR) := TRUE ;
				number_list(p_33207_LC_DIS_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_DISCOM_EXP)	:=row_po.referans_no||' Discrepancy Commission ' ;

				ln_borc_trl := number_list(p_33207_LC_DIS_COM);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
			  ELSIF row_masraf.masraf_kodu = 'EXPINQUIRY' THEN   --posta
				boolean_list(p_33207_INQUIRY_COM_VAR) := TRUE ;
				number_list(p_33207_LC_INQUIRY_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				varchar_list(p_33207_INQUIRY_COM_EXP)	:=row_po.referans_no||' Export L/C Inquery Charge';

				ln_borc_trl := number_list(p_33207_LC_INQUIRY_CHARGE);
				ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));
			  ELSIF row_masraf.masraf_kodu =  'EXPCONFCOM' then  --Confirmation taksitli OLUR
			       boolean_list(p_33207_CONFCOM_VAR) := TRUE ;
			       ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				   IF nvl(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   ln_tahsil_tutar := 0;
				   ELSE
					  lb_taksit_var := true;
					  open cur_taksitler;
					  loop
					    fetch cur_taksitler into row_taksit;
						exit when cur_taksitler%notfound;

							ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
							number_list(p_33207_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
                            varchar_list(p_33207_CONFCOM_EXP)	:=row_po.referans_no||' Export L/C Confirmtion Commission' ;

							ln_borc_trl := number_list(p_33207_LC_CONF_COM);
							ln_borc_fc := Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(ln_borc_trl/number_list(p_33207_KUR)));

						if ln_son_bakiye >= ln_borc_fc then
						   boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
					       boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
					       boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
					       boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
					       boolean_list(p_33207_DISCOM_VAR) := FALSE ;
						   boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE ;


				           ln_fis_no:=pkg_muhasebe.fis_kes ( 33207, null, pn_islem_no, varchar_list, number_list,
										    			  	  date_list, boolean_list, null, false, ln_fis_no, null);
			     		     update cbs_masraf_ith_ihr_isl
							   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
							       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
						     where current of cur_masraf;

  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

							update cbs_masraf_taksit_islem
						    set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
							       odenen_tutar = taksit_tutari
							where current of cur_taksitler;
  							 pkg_masraf.gecici_gercek_icin_kaydet(pn_islem_no, row_taksit.referans,
					                                       row_masraf.masraf_kodu, row_masraf.vs_no,
					                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
							   						  	   number_list(p_33207_LC_CONF_COM), row_po.masraf_hesap_no,
														   row_po.valor_tarihi, 'E');

							ln_son_bakiye := ln_son_bakiye - ln_borc_fc;
							number_list(p_33207_LC_MASRAF_TUTAR) := number_list(p_33207_LC_MASRAF_TUTAR) + ln_borc_trl;
					        number_list(p_33207_FC_MASRAF_TUTARI) := number_list(p_33207_FC_MASRAF_TUTARI) + ln_borc_fc;
					    ELSE
						 CLOSE cur_taksitler;
						 CLOSE cur_masraf;
				        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
						   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
						END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_fc then --bakiye yeterliyse satiri ekle
			     if ln_tahsil_tutar <> 0 then

		            ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33207, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_33207_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_ADVICECOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_ADVICECOM_VAR) := FALSE;
                      ELSIF boolean_list(p_33207_COLLCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_COLLCOM_VAR) := FALSE;
                      ELSIF boolean_list(p_33207_DISCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_DISCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_INQUIRY_COM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE;
					  END IF;

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      update cbs_masraf_ith_ihr_isl
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_fc;
					  number_list(p_33207_LC_MASRAF_TUTAR) := number_list(p_33207_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33207_FC_MASRAF_TUTARI) := number_list(p_33207_FC_MASRAF_TUTARI) + ln_borc_fc;
	 			END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
 				  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;
	boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33207_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
	boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
	boolean_list(p_33207_DISCOM_VAR) := FALSE ;
	boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE;

	IF number_list(p_33207_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33207_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33207_LC_MASRAF_TUTAR)) ;
	   number_list(p_33207_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33207_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33207_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33207_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33207_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33207_LC_MASRAF_ANA) := TRUE ;

		END IF;

		pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_ser_tax);

		number_list(p_33207_FC_SERVICE_TAX):=Pkg_Kur.yuvarla(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),(number_list(p_33207_LC_SERVICE_TAX)/number_list(p_33207_KUR)));
		number_list(p_33207_LC_SERVICE_TAX):=(number_list(p_33207_LC_SERVICE_TAX)* ln_ser_tax)/100;
		number_list(p_33207_FC_SERVICE_TAX):=(number_list(p_33207_FC_SERVICE_TAX)* ln_ser_tax)/100;

	    ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33207, NULL, pn_islem_no,
			    					  	 varchar_list, number_list,
										 date_list, boolean_list,
							    	  	 NULL, FALSE, ln_fis_no, NULL);


	END IF;
	pn_fis_no := ln_fis_no;

  End;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2) is
   begin
    null;
   end;
/*------------------------------------------------------------------------------------------------------*/
  Procedure Muhasebelesme_Sonrasi(pn_islem_no number, ps_ref varchar2) is
  begin
    pkg_masraf.Muhasebe_Sonrasi_odeme(pn_islem_no, ps_ref);
   end;
/*------------------------------------------------------------------------------------------------------*/
 Function masraf_odeyecek_kontrol(pn_islem_no number) return varchar2 is
 ln_temp number;
 begin
   select count(*)
     into ln_temp
	 from cbs_masraf_ith_ihr_isl
	where islem_no = pn_islem_no
	  and odeyecek in ('EXPORTER');
   if ln_temp > 0 then
     return 'E';
   else
     return 'H';
   end if;
 end;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

 Procedure EOD_Muhasebelesme(pn_islem_no number, pn_fis_no in out number, ps_referans varchar2, pn_vs_no number) is

   varchar_list		      pkg_muhasebe.varchar_array;
   number_list			  pkg_muhasebe.number_array;
   date_list			  pkg_muhasebe.date_array;
   boolean_list			  pkg_muhasebe.boolean_array;
   ln_fis_no			  number;
   ls_referans 			  varchar2(16);
   ls_sube				  varchar2(10);
   ls_akr_doviz           varchar2(3);
   ls_tahsil_doviz        varchar2(3);
   ls_hesap_doviz         varchar2(3);
   lb_taksit_var		  boolean := false;
   ln_son_bakiye		  number := 0;
   ln_borc_tutar		  number := 0;
   ln_borc_trl			  number := 0;
   ln_eski_tahsil_tutar	  number;
   ln_tahsil_tutar		  number;
   ls_istatistik_kodu     VARCHAR2(2000);
   ln_dk_grup_no number;
   ls_aciklama			  VARCHAR2(2000);
   cursor cur_masraf is
    select *
	  from cbs_masraf_ith_ihr
	 where referans = ps_referans
	   and durum = 'VALID'
	 order by sira_no desc   --en son girilen ?deme komisyonu ilk al?nmaya ?al???lacak...
	for update;
	row_masraf cur_masraf%rowtype;

   cursor c_0 is
    select count(*)
	  from cbs_masraf_ith_ihr
	 where referans = ps_referans
	   and durum = 'VALID';
	 ln_temp number;

   cursor cur_po is
     select * from cbs_vw_masraf
	  where REFERANS = ps_referans
	    and vs_no = pn_vs_no;
	 row_po cur_po%rowtype;

   cursor cur_taksitler is
     select * from cbs_masraf_taksit a
	  where referans = ps_referans --referans = ls_referans
	    and masraf_kodu = row_masraf.masraf_kodu
	    and taksit_tarihi <= pkg_muhasebe.banka_tarihi_bul
	    and nvl(odenen_tutar,0) < taksit_tutari
	 for update;
   row_taksit cur_taksitler%rowtype;

  Begin
    ln_fis_no := pn_fis_no;
	open c_0;
	fetch c_0 into ln_temp;
	close c_0;
	if ln_temp <= 0 then
	  return;
	end if;

	open cur_po;
	fetch cur_po into row_po;
     varchar_list(p_33207_MASRAF_HESAP_NO) := row_po.hesap_no;
     varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU):= Pkg_Hesap.HesaptanDovizKoduAl(row_po.hesap_no);
	 ls_hesap_doviz:=Pkg_Hesap.HesaptanDovizKoduAl(row_po.hesap_no);
     varchar_list(p_33207_MASRAF_HESAP_SUBE) := Pkg_Hesap.HesapSubeAl(row_po.hesap_no);
	 ls_referans :=  row_po.referans;
 	 varchar_list(p_33207_ISLEM_SUBE) := row_po.bolum_kodu;
	close cur_po;


	    boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
		boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
		boolean_list(p_33207_CONFCOM_VAR) := FALSE ;
		boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
		boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
		boolean_list(p_33207_DISCOM_VAR) := FALSE ;
		boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE ;

		boolean_list(p_33207_FC_MASRAF_ANA) := FALSE ;
		boolean_list(p_33207_LC_MASRAF_ANA) := FALSE ;

	    IF varchar_list(p_33207_MASRAF_HESAP_NO) IS NOT NULL THEN
	       ln_dk_grup_no :=Pkg_Musteri.sf_musteri_dk_grup_kod_al(Pkg_Hesap.HesaptanMusteriNoAl(varchar_list(p_33207_MASRAF_HESAP_NO)) );
		   varchar_list(p_33207_MAIL_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPMAILCHR');
		   varchar_list(p_33207_COMM_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCOMCAT');
		   varchar_list(p_33207_CONF_COM_GL)	  :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPCONFCOM');
		   varchar_list(p_33207_ADVICE_COM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPPAYMENT');
   		   varchar_list(p_33207_COLLCOM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDOCCONT');
   		   varchar_list(p_33207_DISCOM_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPDISCREP');
		   varchar_list(p_33207_INQUIRY_CHARGE_GL) :=Pkg_Muhasebe.Komisyon_DK_Bul( ln_dk_grup_no,'EXPINQUIRY');
    	ELSE
		   varchar_list(p_33207_MAIL_CHARGE_GL) := '';
		   varchar_list(p_33207_COMM_CHARGE_GL) := '';
		   varchar_list(p_33207_CONF_COM_GL)	  := '';
		   varchar_list(p_33207_ADVICE_COM_GL) := '';
	       varchar_list(p_33207_COLLCOM_GL) :='';
   		   varchar_list(p_33207_DISCOM_GL) :='';
		   varchar_list(p_33207_INQUIRY_CHARGE_GL) := '';
	    END IF;

     	   varchar_list(p_33207_REFERENCE) := ls_referans;
	       varchar_list(p_33207_ISTA_KOD)  := ls_istatistik_kodu;
        IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		   boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) := FALSE;
		   boolean_list(p_33207_FC_MSRF_DOVIZ_KODU) := TRUE ;

		ELSE
		   boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) := TRUE;
		   boolean_list(p_33207_FC_MSRF_DOVIZ_KODU) := FALSE;

		END IF;

		number_list(p_33207_LC_COMM_CHARGE) := 0;
		number_list(p_33207_LC_MAIL_CHARGE) := 0;
		number_list(p_33207_LC_CONF_COM) := 0;
		number_list(p_33207_LC_ADVICE_COM) := 0;
		number_list(p_33207_LC_COLL_COM) := 0;
		number_list(p_33207_LC_DIS_COM) := 0;
		number_list(p_33207_LC_INQUIRY_CHARGE) := 0;

		number_list(p_33207_LC_MASRAF_TUTAR) := 0;
		number_list(p_33207_FC_MASRAF_TUTARI) := 0;
		varchar_list(p_33207_MAILCOM_EXP)	:='';
		varchar_list(p_33207_COMMCOM_EXP)	:='';
	    varchar_list(p_33207_CONFCOM_EXP)	:='';
	    varchar_list(p_33207_ADVICECOM_EXP):='';
		varchar_list(p_33207_COLLCOM_EXP):='';
		varchar_list(p_33207_DISCOM_EXP):='';
		varchar_list(p_33207_INQUIRY_COM_EXP)	:='';

		ls_aciklama := 'Export Payment Com.  ' ||row_po.REFERANS
                                   ||' Customer No:'||row_po.MUSTERI_NO
								   ||' -'||pkg_musteri.Sf_Musteri_Adi(row_po.MUSTERI_NO);

		varchar_list(p_33207_BANKA_ACIK) := ls_aciklama;
		varchar_list(p_33207_MUS_ACIK) :=varchar_list(p_33207_BANKA_ACIK) ;

		IF  varchar_list(p_33207_MASRAF_HESAP_NO) IS NOT NULL THEN  --masraf hesab? girilmi?se
		     IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) =pkg_genel.lc_al then
			   number_list(p_33207_KUR) := Pkg_Kur.mb_dak_to_lc(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),1);
			else
        	   number_list(p_33207_KUR) := Pkg_Kur.MB_dak_to_lc(varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),1);
			end if;
		     --masraf alinacak hesabin bakiyesini al
		     ln_son_bakiye := Pkg_Hesap.KULLANILABILIR_BAKIYE_AL(varchar_list(p_33207_MASRAF_HESAP_NO));
        END IF;

open cur_masraf;
	loop
	  fetch cur_masraf into row_masraf;
	  exit when cur_masraf%notfound;
	  ls_tahsil_doviz:=row_masraf.DVZ;

	  IF nvl(row_masraf.tahsil_edilemeyen,0) > 0  THEN
      	  IF pkg_ihracat.masraf_kontrol_yap_nonakr(row_masraf.ODEYECEK) = 'Y'  THEN
		     ln_tahsil_tutar := row_masraf.tutar - nvl(row_masraf.tahsil_toplam,0);
		    IF row_masraf.masraf_kodu = 'EXPCOMCAT'  THEN  --haberle?me
			     boolean_list(p_33207_COMMCOM_VAR) := TRUE ;
			     IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	number_list(p_33207_LC_COMM_CHARGE) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                 ELSE
				    number_list(p_33207_LC_COMM_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				 END IF;
				--bu iki degisken ile hesabin odemeyi alabilmek icin yeterli olup olmadigi arastirilacak
			   --eger yeterli miktar varsa, toplam satir icin toplanacak
				 ln_borc_tutar := number_list(p_33207_LC_COMM_CHARGE);--number_list(p_33207_HABR_MDV);
				 ln_borc_trl := number_list(p_33207_LC_COMM_CHARGE);
			     varchar_list(p_33207_COMMCOM_EXP) := row_masraf.referans||' Export Communication Charge ' ;

			  ELSIF row_masraf.masraf_kodu = 'EXPMAILCHR' THEN   --posta
				  boolean_list(p_33207_MAILCOM_VAR) := TRUE ;
				  IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	number_list(p_33207_LC_MAIL_CHARGE) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                  ELSE
				    number_list(p_33207_LC_MAIL_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				  END IF;
				  ln_borc_tutar := number_list(p_33207_LC_MAIL_CHARGE);--number_list(p_33207_POSTA_MDV);
				  ln_borc_trl := number_list(p_33207_LC_MAIL_CHARGE);
				  varchar_list(p_33207_MAILCOM_EXP)	:=row_masraf.referans||' Export Mail Charge';

			  ELSIF  row_masraf.masraf_kodu = 'EXPPAYMENT' THEN   --Advise

			      boolean_list(p_33207_ADVICECOM_VAR) := TRUE ;
			   	  IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	number_list(p_33207_LC_ADVICE_COM) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                  ELSE
				    number_list(p_33207_LC_ADVICE_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				  END IF;
				  ln_borc_tutar := number_list(p_33207_LC_ADVICE_COM);--number_list(p_33207_POSTA_MDV);
				  ln_borc_trl := number_list(p_33207_LC_ADVICE_COM);
			      varchar_list(p_33207_ADVICECOM_EXP)	:=row_masraf.referans||' Export Payment Commission' ;

			  ELSIF  row_masraf.masraf_kodu = 'EXPDOCCONT' THEN   --COLLECTION

			      boolean_list(p_33207_COLLCOM_VAR) := TRUE ;
			   	  IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	number_list(p_33207_LC_COLL_COM) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                  ELSE
				    number_list(p_33207_LC_COLL_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				  END IF;
				  ln_borc_tutar := number_list(p_33207_LC_COLL_COM);--number_list(p_33207_POSTA_MDV);
				  ln_borc_trl := number_list(p_33207_LC_COLL_COM);
			      varchar_list(p_33207_COLLCOM_EXP)	:=row_masraf.referans||' Checking of Documents' ;

			  ELSIF  row_masraf.masraf_kodu = 'EXPDISCREP' THEN   --DISCREPANCY

			      boolean_list(p_33207_DISCOM_VAR) := TRUE ;
			   	  IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	 number_list(p_33207_LC_DIS_COM) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                  ELSE
				     number_list(p_33207_LC_DIS_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				  END IF;
				  ln_borc_tutar := number_list(p_33207_LC_DIS_COM);--number_list(p_33207_POSTA_MDV);
				  ln_borc_trl := number_list(p_33207_LC_DIS_COM);
			      varchar_list(p_33207_DISCOM_EXP)	:=row_masraf.referans||' Discrepancy Commission ' ;

			  ELSIF row_masraf.masraf_kodu = 'EXPINQUIRY' THEN   --posta
				  boolean_list(p_33207_INQUIRY_COM_VAR) := TRUE ;
				  IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	number_list(p_33207_LC_INQUIRY_CHARGE) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
	              ELSE
				    number_list(p_33207_LC_INQUIRY_CHARGE) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
				  END IF;
				  ln_borc_tutar := number_list(p_33207_LC_INQUIRY_CHARGE);--number_list(p_33207_POSTA_MDV);
				  ln_borc_trl := number_list(p_33207_LC_INQUIRY_CHARGE);
				  varchar_list(p_33207_INQUIRY_COM_EXP)	:=row_masraf.referans||' Export L/C Inquery Charge';

			  ELSIF row_masraf.masraf_kodu in  ('EXPCONFCOM') then  --Confirmation taksitli OLUR
			       boolean_list(p_33207_CONFCOM_VAR) := TRUE ;
			       ln_eski_tahsil_tutar := nvl(row_masraf.tahsil_toplam,0);
				   IF nvl(row_masraf.tahsil_edilemeyen,0) <= 0  THEN
					   --daha fazlas? veya ayn?s? ?nceden al?nm??
					   --hi? bir ?ey yapma
					   ln_tahsil_tutar := 0;
				   ELSE
							  lb_taksit_var := true;
							  open cur_taksitler;
							  loop
							    fetch cur_taksitler into row_taksit;
								exit when cur_taksitler%notfound;

									ln_tahsil_tutar := row_taksit.taksit_tutari - NVL(row_taksit.odenen_tutar,0);
									IF boolean_list(p_33207_LC_MSRF_DOVIZ_KODU) THEN
	            	                   number_list(p_33207_LC_CONF_COM) := Pkg_Kur.mb_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar);
                                    ELSE
       			            		   number_list(p_33207_LC_CONF_COM) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,Pkg_Kur.MB_dak_to_lc(ls_tahsil_doviz, ln_tahsil_tutar));
									END IF;
		 				            ln_borc_tutar := number_list(p_33207_LC_CONF_COM);--number_list(p_33207_TEYIT_MDV);
								    ln_borc_trl := number_list(p_33207_LC_CONF_COM);
		                            varchar_list(p_33207_CONFCOM_EXP)	:=row_masraf.referans||' Export L/C Confirmtion Commission' ;


								if ln_son_bakiye >= ln_borc_tutar then
								   boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
							       boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
							       boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
   							       boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
   							       boolean_list(p_33207_DISCOM_VAR) := FALSE ;
								   boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE ;


						           ln_fis_no:=pkg_muhasebe.fis_kes ( 33207, null, pn_islem_no, varchar_list, number_list,
												    			  	  date_list, boolean_list, null, false, ln_fis_no, null);
					     		     update cbs_masraf_ith_ihr
									   set tahsil_toplam = nvl(tahsil_toplam,0) + (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0)),
									       tahsil_edilemeyen = tahsil_edilemeyen - (row_taksit.taksit_tutari - nvl(row_taksit.odenen_tutar,0))
								     where current of cur_masraf;

		  					  		pkg_masraf.iptal_icin_log_at_taksit(pn_islem_no, row_taksit.referans, row_taksit.taksit_no,
		                                                         row_taksit.taksit_odeme_tarih, row_taksit.taksit_tutari, row_masraf.masraf_kodu, row_masraf.vs_no);

									update cbs_masraf_taksit
								    set taksit_odeme_tarih = pkg_muhasebe.banka_tarihi_bul,
									       odenen_tutar = taksit_tutari
									where current of cur_taksitler;
									 Pkg_Masraf.gecici_gercek_icin_kaydet_eod(pn_islem_no, row_masraf.sira_no, row_taksit.referans,
							                                       row_masraf.masraf_kodu, row_masraf.vs_no,
							                                       row_taksit.taksit_no, row_taksit.taksit_odeme_tarih,
									   						  	   number_list(p_33207_LC_CONF_COM), row_po.hesap_no,
																   row_po.VADE_tarihi, 'E', row_po.bolum_kodu);

 								    ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
									number_list(p_33207_LC_MASRAF_TUTAR) := number_list(p_33207_LC_MASRAF_TUTAR) + ln_borc_trl;
							        number_list(p_33207_FC_MASRAF_TUTARI) := number_list(p_33207_FC_MASRAF_TUTARI) + ln_borc_tutar;
					    ELSE
						 CLOSE cur_taksitler;
						 CLOSE cur_masraf;
				        --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...
						   RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
						END IF;
					  END LOOP;
					  CLOSE cur_taksitler;

				END IF; --row_masraf.hesaplanan < ln_eski_tahsil_tutar
			  ELSE
			    CLOSE cur_masraf;
		 	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			  END IF;
			  if not lb_taksit_var then
			   if ln_son_bakiye >= ln_borc_tutar then --bakiye yeterliyse satiri ekle
			     if ln_tahsil_tutar <> 0 then

		            ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33207, NULL, pn_islem_no, varchar_list,
						    				  	  number_list, date_list, boolean_list,
									    	  	  NULL, FALSE, ln_fis_no, NULL);

					  IF boolean_list(p_33207_MAILCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_MAILCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_COMMCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_COMMCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_CONFCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_CONFCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_ADVICECOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_ADVICECOM_VAR) := FALSE;
                      ELSIF boolean_list(p_33207_COLLCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_COLLCOM_VAR) := FALSE;
                      ELSIF boolean_list(p_33207_DISCOM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_DISCOM_VAR) := FALSE;
					  ELSIF boolean_list(p_33207_INQUIRY_COM_VAR) = TRUE THEN
					  	 boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE;
					  END IF;

					  pkg_masraf.iptal_icin_log_at(pn_islem_no, row_masraf.referans, row_masraf.sira_no,
                                                   row_masraf.masraf_kodu, ln_tahsil_tutar, row_masraf.vs_no);

				      update cbs_masraf_ith_ihr
					     set tahsil_toplam = nvl(tahsil_toplam,0) + ln_tahsil_tutar,
						     tahsil_edilemeyen = tahsil_edilemeyen - ln_tahsil_tutar
				       where current of cur_masraf;
					  ln_son_bakiye := ln_son_bakiye - ln_borc_tutar;
					  number_list(p_33207_LC_MASRAF_TUTAR) := number_list(p_33207_LC_MASRAF_TUTAR) + ln_borc_trl;
					  number_list(p_33207_FC_MASRAF_TUTARI) := number_list(p_33207_FC_MASRAF_TUTARI) + ln_borc_tutar;
	 			END IF;
			   ELSE
			       CLOSE cur_masraf;
				  --komisyon/masraflar al?nmak isteniyorsa mutlaka al?nmal? yoksa hata...

 				  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '341' ||  Pkg_Hata.getDelimiter || row_masraf.masraf_kodu || Pkg_Hata.getUCPOINTER);
			   END IF;
			  END IF;
 	      END IF; --ihracat?? ?demesi
	  END IF;  --tahsil edilmeyen var....

	END LOOP;
	CLOSE cur_masraf;
	boolean_list(p_33207_MAILCOM_VAR) := FALSE ;
	boolean_list(p_33207_COMMCOM_VAR) := FALSE ;
	boolean_list(p_33207_CONFCOM_VAR) := FALSE ;
	boolean_list(p_33207_ADVICECOM_VAR) := FALSE ;
	boolean_list(p_33207_COLLCOM_VAR) := FALSE ;
	boolean_list(p_33207_DISCOM_VAR) := FALSE ;
	boolean_list(p_33207_INQUIRY_COM_VAR) := FALSE;

	IF number_list(p_33207_FC_MASRAF_TUTARI) > 0 THEN
	   number_list(p_33207_LC_MASRAF_TUTAR) := Pkg_Kur.yuvarla(Pkg_Genel.LC_AL,number_list(p_33207_LC_MASRAF_TUTAR)) ;
	   number_list(p_33207_FC_MASRAF_TUTARI) := Pkg_Kur.doviz_doviz_karsilik(Pkg_Genel.lc_al,varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU),NULL, number_list(p_33207_LC_MASRAF_TUTAR),1,NULL,NULL,'N','A');

	    IF varchar_list(p_33207_MASRAF_HESAP_DOVIZKODU) <> Pkg_Genel.LC_AL THEN
		 boolean_list(p_33207_FC_MASRAF_ANA) := TRUE ;
		 boolean_list(p_33207_LC_MASRAF_ANA) := FALSE ;
		ELSE
		 boolean_list(p_33207_FC_MASRAF_ANA) := FALSE ;
		 boolean_list(p_33207_LC_MASRAF_ANA) := TRUE ;

		END IF;

	    ln_fis_no:=Pkg_Muhasebe.fis_kes ( 33207, NULL, pn_islem_no,
			    					  	 varchar_list, number_list,
										 date_list, boolean_list,
							    	  	 NULL, FALSE, ln_fis_no, NULL);


	END IF;
	pn_fis_no := ln_fis_no;
  End;

/*------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------*/

 BEGIN
	p_33207_FC_MSRF_DOVIZ_KODU        := Pkg_Muhasebe.parametre_index_bul('33207_FC_MSRF_DOVIZ_KODU');
	p_33207_LC_MSRF_DOVIZ_KODU		  := Pkg_Muhasebe.parametre_index_bul('33207_LC_MSRF_DOVIZ_KODU');
	p_33207_KUR						  := Pkg_Muhasebe.parametre_index_bul('33207_KUR');
	p_33207_REFERENCE				  := Pkg_Muhasebe.parametre_index_bul('33207_REFERENCE');
	p_33207_ISTA_KOD				  := Pkg_Muhasebe.parametre_index_bul('33207_ISTA_KOD');
	p_33207_MUS_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33207_MUS_ACIK');
	p_33207_BANKA_ACIK				  := Pkg_Muhasebe.parametre_index_bul('33207_BANKA_ACIK');
	p_33207_ISLEM_SUBE				  := Pkg_Muhasebe.parametre_index_bul('33207_ISLEM_SUBE');
	p_33207_MASRAF_HESAP_DOVIZKODU	  := Pkg_Muhasebe.parametre_index_bul('33207_MASRAF_HESAP_DOVIZ_KODU');
	p_33207_FC_MASRAF_TUTARI		  := Pkg_Muhasebe.parametre_index_bul('33207_FC_MASRAF_TUTARI');
	p_33207_LC_MASRAF_TUTAR			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_MASRAF_TUTAR');
	p_33207_MASRAF_HESAP_SUBE		  := Pkg_Muhasebe.parametre_index_bul('33207_MASRAF_HESAP_SUBE');
	p_33207_MASRAF_HESAP_NO			  := Pkg_Muhasebe.parametre_index_bul('33207_MASRAF_HESAP_NO');
	p_33207_LC_MAIL_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_MAIL_CHARGE');
	p_33207_LC_COMM_CHARGE			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_COMM_CHARGE');
	p_33207_LC_CONF_COM				  := Pkg_Muhasebe.parametre_index_bul('33207_LC_CONF_COM');
	p_33207_LC_ADVICE_COM			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_ADVICE_COM');
	p_33207_LC_COLL_COM			  	  := Pkg_Muhasebe.parametre_index_bul('33207_LC_COLL_COM');
	p_33207_LC_DIS_COM			  	  := Pkg_Muhasebe.parametre_index_bul('33207_LC_DIS_COM');
	p_33207_MAIL_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33207_MAIL_CHARGE_GL');
	p_33207_COMM_CHARGE_GL			  := Pkg_Muhasebe.parametre_index_bul('33207_COMM_CHARGE_GL');
	p_33207_CONF_COM_GL				  := Pkg_Muhasebe.parametre_index_bul('33207_CONF_COM_GL');
	p_33207_ADVICE_COM_GL			  := Pkg_Muhasebe.parametre_index_bul('33207_ADVICE_COM_GL');
	p_33207_COLLCOM_GL			  	  := Pkg_Muhasebe.parametre_index_bul('33207_COLLCOM_GL');
	p_33207_DISCOM_GL			  	  := Pkg_Muhasebe.parametre_index_bul('33207_DISCOM_GL');
	p_33207_UNCOMFIRM				  := Pkg_Muhasebe.parametre_index_bul('33207_UNCOMFIRM');
	p_33207_COMFIRM					  := Pkg_Muhasebe.parametre_index_bul('33207_COMFIRM');
	p_33207_FC						  := Pkg_Muhasebe.parametre_index_bul('33207_FC');
	p_33207_LC						  := Pkg_Muhasebe.parametre_index_bul('33207_LC');
	p_33207_MAILCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33207_MAILCOM_VAR');
	p_33207_COMMCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33207_COMMCOM_VAR');
	p_33207_CONFCOM_VAR				  := Pkg_Muhasebe.parametre_index_bul('33207_CONFCOM_VAR');
	p_33207_ADVICECOM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33207_ADVICECOM_VAR');
	p_33207_COLLCOM_VAR			  	  := Pkg_Muhasebe.parametre_index_bul('33207_COLLCOM_VAR');
	p_33207_DISCOM_VAR			  	  := Pkg_Muhasebe.parametre_index_bul('33207_DISCOM_VAR');
	p_33207_FC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33207_FC_MASRAF_ANA');
	p_33207_LC_MASRAF_ANA			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_MASRAF_ANA');
	p_33207_MAILCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33207_MAILCOM_EXP');
	p_33207_COMMCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33207_COMMCOM_EXP');
	p_33207_CONFCOM_EXP				  := Pkg_Muhasebe.parametre_index_bul('33207_CONFCOM_EXP');
	p_33207_ADVICECOM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33207_ADVICECOM_EXP');
	p_33207_COLLCOM_EXP			  	  := Pkg_Muhasebe.parametre_index_bul('33207_COLLCOM_EXP');
	p_33207_DISCOM_EXP			  	  := Pkg_Muhasebe.parametre_index_bul('33207_DISCOM_EXP');

    p_33207_LC_INQUIRY_CHARGE		  := Pkg_Muhasebe.parametre_index_bul('33207_LC_INQUIRY_CHARGE');
    p_33207_INQUIRY_CHARGE_GL		  := Pkg_Muhasebe.parametre_index_bul('33207_INQUIRY_CHARGE_GL');
    p_33207_INQUIRY_COM_VAR			  := Pkg_Muhasebe.parametre_index_bul('33207_INQUIRY_COM_VAR');
    p_33207_INQUIRY_COM_EXP			  := Pkg_Muhasebe.parametre_index_bul('33207_INQUIRY_COM_EXP');

	p_33207_LC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33207_LC_SERVICE_TAX');
	p_33207_FC_SERVICE_TAX			  := Pkg_Muhasebe.parametre_index_bul('33207_FC_SERVICE_TAX');
	p_33207_VERGIDEN_MUAF_DEGIL			  := Pkg_Muhasebe.parametre_index_bul('33207_VERGIDEN_MUAF_DEGIL');
 END;
/

