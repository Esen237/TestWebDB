create Package     PKG_LIMIT_RAPOR is

/******************************************************************************
   NAME       : PKG_LIMIT_RAPOR
   Created By : Seval Balci
   Date          : 23.11.2011
   Purpose      :Limit izleme ve rapor ile ilgili procedur ve fonksiyonlari icerir.
******************************************************************************/
 Function sf_finans_kod_al (pn_musteri_no number  ) return varchar2;
 FUNCTION sf_musteri_kredi_gl_al(pn_musteri_no number, pn_kredi_teklif_satir_numara number ,pd_date date default pkg_muhasebe.banka_tarihi_bul)RETURN varchar2;
 Function   sf_validity_date_of_line_al(pn_musteri_no cbs_musteri.musteri_no%type) return date;
 FUNCTION  Sf_activity_Adi_al( ps_finans_kodu CBS_FINANS_KODLARI.finans_kodu%TYPE) RETURN VARCHAR2;
 Function   sf_yenileme_vadesi_al(pn_musteri_no cbs_musteri.musteri_no%type) return date;
End ;
/

