create PACKAGE pkg_utility IS

--------------------------------------------------------------------------------------------------------------
Function  InvokeKartelPayment(pn_txno number, ps_msisdn IN varchar2,pn_amount in number,
		  					  ps_payid out number, ps_timestamp out varchar2) return varchar2;
--------------------------------------------------------------------------------------------------------------
Function  CheckKartelPayment(pn_txno number, ps_payid number,ps_timestamp out varchar2) return varchar2;
--------------------------------------------------------------------------------------------------------------
Function  CommitKartelPayment(pn_txno number, ps_payid number,
		  					  ps_receipt out varchar2, ps_timestamp out varchar2) return varchar2;
--------------------------------------------------------------------------------------------------------------
Function  MakeKartelPayment(pn_txno number, ps_msisdn IN varchar2,pn_amount in number) return varchar2;
--------------------------------------------------------------------------------------------------------------
Function  GetKartelPayID(pn_txno number) return varchar2;
------------------------------------------------------------------------------------------------------------
Function  GetKartelReceiptID(pn_txno number) return varchar2;
------------------------------------------------------------------------------------------------------------
Function  GetKartelTimeStamp(pn_txno number) return varchar2;
------------------------------------------------------------------------------------------------------------
END;


/

