create package pkg_prudence
is
  function Capital(p_date DATE) return NUMBER;
end pkg_prudence;


/

