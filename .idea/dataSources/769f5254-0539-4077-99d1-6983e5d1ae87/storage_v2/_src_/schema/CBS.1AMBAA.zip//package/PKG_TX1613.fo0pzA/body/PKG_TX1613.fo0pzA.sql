create PACKAGE BODY     PKG_TX1613 IS
    pn_1613_banka_aciklama                  number;
    pn_1613_dekont_aciklama                  number;
    pn_1613_islem_sube                      number;
    pn_1613_OUTLET_CASH_GL                    number;
    pn_1613_borc_sube                      number;
    pn_1613_referans                      number;
    pn_1613_istatistik_kodu                  number;
    pn_1613_musteri_aciklama              number;
    pn_1613_doviz_kodu                      number;
    pn_1613_kur                              number;
    pn_1613_fc_islem                      number;
    pn_1613_lc_islem                      number;
    pn_1613_TUTAR                          number;
    pn_1613_TUTAR_TL                      number;
    pn_1613_nakit_kodu_lc                     number;
    pn_1613_nakit_kodu_fc                    number;
    pn_1613_nbk_hesap_sube                  number;
    pn_1613_nbk_hesap_no                  number;
    pn_1613_ATM                              number;
    pn_1613_NBKR                          number;
    pn_1613_BANK                          number;
    pn_1613_INTERBANK_TRANSIT             number;
    pn_1613_DATE                          number;
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye,
           b.nakit_kodu nakit_kodu_lc,
           b.nakit_kodu nakit_kodu_fc,
           transfer_edilen_kisi,
           nufus_seri_no,
           verildigi_yer, verildigi_tarih,
           prefix_istatistik_kodu,
           istatistik_kodu    ,
           alici_sube_kodu,
           a.secenek,
           b.NBK_ACCOUNT_NO
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
     deger_girilmeli  exception;
     ls_doviz        varchar2(200);
     nakit_lc_yok    exception;
      nakit_fc_yok    exception;
     ls_dekont_aciklama       varchar2(2000);
      ln_transfer_no  number;
     ln_adet         number;
     ls_aciklama     varchar2(2000);
       ls_dk_no                    varchar2(2000);
  Begin
log_at('asd1106',1);
    select transfer_no
    into  ln_transfer_no
    from  cbs_kasa_sube_transfer_islem
    where tx_no = pn_islem_no;

    select count(*)
    into ln_adet
    from cbs_kasa_kupur_bakiye_islem
    where tx_no = pn_islem_no ;

    if nvl(ln_adet,0) = 0 then
       PKG_TX1601.sp_kupur_islem_yarat( ln_transfer_no,pn_islem_no,1613);
    end if;


      Bakiye_Kontrol(pn_islem_no);
log_at('asd1106',2);    
    ls_islem_tipi :='Y';
    pkg_parametre.deger('1613_DEKONT_ACIKLAMA',ls_dekont_aciklama);

       Begin
          delete from cbs_kasa_kupur_bakiye_islem
           where tx_no = pn_islem_no and
                      doviz_kodu  not in ( select doviz_kodu
                                             from cbs_kasa_sube_trnsf_det_islem
                                          where tx_no = pn_islem_no);
          Exception when others then null;
      End;

    for c_bakiye in cur_bakiye loop
        ls_doviz := c_bakiye.doviz_kodu;
        if ls_doviz = pkg_genel.lc_al then
                  if c_bakiye.nakit_kodu_lc is null then
                     raise nakit_lc_yok;
                end if;
        else
                if c_bakiye.nakit_kodu_fc is null then
                     raise nakit_fc_yok;
                end if;
        end if;

            pkg_tx1601.Kontrol_Sonrasi(pn_islem_no,
                                       '1613',
                                        c_bakiye.bakiye,
                                        c_bakiye.doviz_kodu,
                                        ls_islem_tipi,
                                        null,null,null,null,'H' );


    end loop;
log_at('asd1106',3);
     if ls_doviz is null then
         raise deger_girilmeli;
     end if;

       for c_bakiye in cur_bakiye loop
        ls_doviz := c_bakiye.doviz_kodu;
        ls_aciklama := ls_dekont_aciklama ||' '||c_bakiye.alici_sube_kodu||'-'|| pkg_genel.bolum_adi_al(c_bakiye.alici_sube_kodu);

         if c_bakiye.doviz_kodu = PKG_GENEL.LC_AL Then
           pkg_parametre.deger('G_LC_KASA',ls_dk_no);
         else
          pkg_parametre.deger('G_FC_KASA',ls_dk_no);
         end if;

         BEGIN
            pkg_cash_slip.cash_slip( pn_islem_no,
                                          1, --Deposit
                                          pkg_muhasebe.banka_tarihi_bul ,
                                          ls_doviz,
                                          c_bakiye.bakiye,
                                          ls_aciklama,
                                          c_bakiye.nufus_seri_no ,
                                          null,
                                          ls_dk_no,
                                          null,
                                          c_bakiye.prefix_istatistik_kodu,
                                          ls_doviz,
                                          c_bakiye.istatistik_kodu,
                                          c_bakiye.verildigi_yer,
                                          c_bakiye.verildigi_tarih);
        EXCEPTION WHEN OTHERS THEN NULL;
        End;
    End loop;
log_at('asd1106',4);


  Exception
    when  deger_girilmeli then
          pkg_cash_slip.Delete_Cash_Slip(pn_islem_no);
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '736' || pkg_hata.getUCPOINTER);
     when  nakit_lc_yok then
           pkg_cash_slip.Delete_Cash_Slip(pn_islem_no);
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '737' || pkg_hata.getUCPOINTER);
     when  nakit_fc_yok then
          pkg_cash_slip.Delete_Cash_Slip(pn_islem_no);
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '738' || pkg_hata.getUCPOINTER);

  End;


  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
  Begin
log_at('asd1106',5);
      Bakiye_Kontrol(pn_islem_no);

    ls_islem_tipi :='Y';

    for c_bakiye in cur_bakiye loop

        pkg_tx1601.Dogrulama_Sonrasi(pn_islem_no,
                                   '1613',
                                    c_bakiye.bakiye,
                                    c_bakiye.doviz_kodu,
                                    ls_islem_tipi );
    end loop;
log_at('asd1106',6);    
  End;


  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    iptal_edilebilir_mi(pn_islem_no);
  End;


  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin

    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    iptal_edilebilir_mi(pn_islem_no);
       pkg_tx1601.iptal_onay_sonrasi(pn_islem_no ,'1613' );

  End;

  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    PKG_Tx1601.Iptal_Muhasebelestir_Sonrasi(pn_islem_no ,'1613');
 End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
     ls_istatistik varchar2(200);
     ls_nakit_lc   varchar2(200);
     ls_nakit_fc   varchar2(200);

  Begin
log_at('asd1106',7);
      Bakiye_Kontrol(pn_islem_no);

    ls_islem_tipi :='Y';

    for c_bakiye in cur_bakiye loop

            PKG_Tx1601.Onay_Sonrasi(pn_islem_no,
                                   '1613',
                                    c_bakiye.bakiye,
                                    c_bakiye.doviz_kodu,
                                    ls_islem_tipi );
    end loop;
    

 log_at('asd1106',8);    
   
      begin
          insert into cbs_kasa_sube_transfer(transfer_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                                              durum_kodu, kasa_kodu, gonderen_sube_kodu, alici_sube_kodu,
                                            kullanici_kodu, banka_tarihi, islem_kod,
                                            transfer_edilen_kisi, nufus_seri_no, verildigi_yer, verildigi_tarih,
                                            yaratan_tx_no,REFERENCE, SECENEK, VALUE_DATE, BANK_ACCOUNT, BANK_NAME
                                            )
         select transfer_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                                              durum_kodu, kasa_kodu, gonderen_sube_kodu, alici_sube_kodu,
                                            kullanici_kodu, banka_tarihi, islem_kod,
                                            transfer_edilen_kisi, nufus_seri_no, verildigi_yer, verildigi_tarih,
                                            tx_no, REFERENCE, SECENEK, VALUE_DATE, BANK_ACCOUNT, BANK_NAME

         from cbs_kasa_sube_transfer_islem
         where tx_no = pn_islem_no ;
         exception when no_data_found then null;
     end ;
     begin
          insert into cbs_kasa_sube_transfer_detay(transfer_no, doviz_kodu, tutar,yaratan_tx_no, NAKIT_KODU, ISTATISTIK_KODU,NBK_ACCOUNT_NO)
         select transfer_no, doviz_kodu, tutar,tx_no,NAKIT_KODU, ISTATISTIK_KODU,NBK_ACCOUNT_NO
         from cbs_kasa_sube_trnsf_det_islem
         where tx_no = pn_islem_no ;
         exception when no_data_found then null;
     end ;
    log_at('asd1106',9); 
     
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is

    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ln_fis_no                   cbs_fis.numara%type :=0;
    ls_islem_kod               cbs_islem.islem_kod%type :='1613';
    ls_musteri_aciklama        varchar2(2000);
    ls_banka_aciklama          varchar2(2000);
    ls_fis_aciklama            varchar2(2000);
    ls_aciklama                   varchar2(2000);
    ls_musteri_aciklama_2      varchar2(2000);
    ls_kasa_kodu                varchar2(2000);
    ls_doviz_kodu               varchar2(2000);
    ln_plan_no                   number;

    ls_durum varchar2(200);
    kasa_kapali exception;

 cursor cur_islem_cursor is
    select gonderen_sube_kodu,
           alici_sube_kodu,
           doviz_kodu,
           urun_sinif_kod,
           tutar,
           prefix_istatistik_kodu||doviz_kodu||ISTATISTIK_KODU istatistik_kodu ,
           b.nakit_kodu nakit_kodu_lc,
           b.nakit_kodu nakit_kodu_fc,
           DECODE(b.NBK_ACCOUNT_NO,NULL,NULL,pkg_hesap.HesapSubeAl(b.NBK_ACCOUNT_NO)) nbk_hesap_sube,
           b.NBK_ACCOUNT_NO,
           A.secenek,
           a.VALUE_DATE,
           a.BANK_NAME,
           a.BANK_ACCOUNT,
           a.REFERENCE
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

  Begin
log_at('asd1106',10);
  /******** 1613 Muhasebe islemleri****/
    varchar_list(pn_1613_banka_aciklama)  := ls_aciklama;
    varchar_list(pn_1613_banka_aciklama) := NULL;
    varchar_list(pn_1613_doviz_kodu) := NULL;
    varchar_list(pn_1613_islem_sube) := NULL;
    varchar_list(pn_1613_OUTLET_CASH_GL) := NULL;
    varchar_list(pn_1613_istatistik_kodu) := NULL;
    varchar_list(pn_1613_nakit_kodu_lc) := NULL;
    varchar_list(pn_1613_nakit_kodu_fc) := NULL;
    varchar_list(pn_1613_musteri_aciklama) := NULL;
    varchar_list(pn_1613_referans) := NULL;
    varchar_list(pn_1613_INTERBANK_TRANSIT) := NULL;
    number_list(pn_1613_TUTAR):= 0;
    number_list(pn_1613_TUTAR_TL):= 0;
    number_list(pn_1613_kur):= 0;
    boolean_list(pn_1613_fc_islem):= FALSE;
    boolean_list(pn_1613_lc_islem):= FALSE;

    boolean_list(pn_1613_ATM):= FALSE;
    boolean_list(pn_1613_NBKR):= FALSE;
    boolean_list(pn_1613_BANK):= FALSE;
    date_list(pn_1613_DATE):= NULL;
/*** Liste Deger Atama K?sm? **/

   pkg_parametre.deger('1613_BANKA_ACIKLAMA',ls_banka_aciklama);
   pkg_parametre.deger('1613_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   ls_aciklama :=     varchar_list(pn_1613_banka_aciklama);
     ls_fis_aciklama :=    pkg_genel.ISLEM_ADI_AL(1613) ;

    for c_islem_cursor in cur_islem_cursor loop
            boolean_list(pn_1613_fc_islem):= FALSE;
            boolean_list(pn_1613_lc_islem):= FALSE;
            boolean_list(pn_1613_ATM):= FALSE;
            boolean_list(pn_1613_NBKR):= FALSE;
            boolean_list(pn_1613_BANK):= FALSE;
            date_list(pn_1613_DATE):= NULL;--AndreiD

            ls_doviz_kodu := c_islem_cursor.doviz_kodu;
            varchar_list(pn_1613_banka_aciklama) :=  ls_banka_aciklama ;--|| PKG_genel.bolum_adi_al(c_islem_cursor.gonderen_sube_kodu);
            varchar_list(pn_1613_musteri_aciklama) :=  ls_musteri_aciklama; --|| PKG_genel.bolum_adi_al(c_islem_cursor.gonderen_sube_kodu);

            varchar_list(pn_1613_doviz_kodu) := c_islem_cursor.doviz_kodu;

            if sf_istatistik_kod_zorunlumu(c_islem_cursor.secenek,c_islem_cursor.doviz_kodu )='E' then
               varchar_list(pn_1613_istatistik_kodu) := c_islem_cursor.istatistik_kodu||'01';
            end if;
log_at('asd1106',11);
            varchar_list(pn_1613_nakit_kodu_lc) := c_islem_cursor.nakit_kodu_lc;
            varchar_list(pn_1613_nakit_kodu_fc) := c_islem_cursor.nakit_kodu_fc;
            varchar_list(pn_1613_islem_sube) := c_islem_cursor.ALICI_sube_kodu;
            varchar_list(pn_1613_borc_sube) := c_islem_cursor.alici_sube_kodu;
            varchar_list(pn_1613_referans) := c_islem_cursor.reference;
            number_list(pn_1613_tutar):= c_islem_cursor.tutar;
            number_list(pn_1613_tutar_tl):=  pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.TUTAR,1,null,null,'N','A'));
            number_list(pn_1613_kur) :=pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'));
            varchar_list(pn_1613_nbk_hesap_sube):= c_islem_cursor.nbk_hesap_sube;
            varchar_list(pn_1613_nbk_hesap_no):= c_islem_cursor.nbk_account_no;
            date_list(pn_1613_date):= c_islem_cursor.value_date;--AndreiD

          -- hs,20100118, for outlet
          if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1613_islem_sube)) = 'H' then
              pkg_parametre.deger('G_DK_FC_CASH_GL',      varchar_list(pn_1613_OUTLET_CASH_GL));
          else
              pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1613_OUTLET_CASH_GL));
          end if;
          -- hs,20100118, for outlet

            if ls_doviz_kodu = pkg_genel.lc_al then
               boolean_list(pn_1613_lc_islem) := true;
             else
                 boolean_list(pn_1613_fc_islem) := true;
            end if;

            if c_islem_cursor.secenek = 'ATM' then
                boolean_list(pn_1613_ATM):= true;
            elsif c_islem_cursor.secenek = 'BANK' then
                boolean_list(pn_1613_BANK):= true;
                
                varchar_list(pn_1613_banka_aciklama) := 'Assets exchange with'||' '|| c_islem_cursor.BANK_NAME;
                varchar_list(pn_1613_musteri_aciklama) := 'Assets exchange with'||' '|| c_islem_cursor.BANK_NAME;
                ls_fis_aciklama := 'Assets exchange with'||' '||c_islem_cursor.BANK_NAME ;
                
                
                
                
                if TRUNC(c_islem_cursor.value_date)<=Pkg_Muhasebe.BANKA_TARIHI_BUL THEN
                    pkg_parametre.deger('G_DK_INTERBANK_TRANSIT', varchar_list(pn_1613_INTERBANK_TRANSIT));    --21111400               
                    
                     if  boolean_list(pn_1613_fc_islem) then
                        pkg_parametre.deger('G_DK_FC_CASH_GL', varchar_list(pn_1613_OUTLET_CASH_GL));--10001000 FC
                    end if;   
                     if boolean_list(pn_1613_lc_islem)  then
                        pkg_parametre.deger('G_DK_LC_CASH_GL', varchar_list(pn_1613_OUTLET_CASH_GL));--10001000 LC
                    end if;   
                                  
                else
                    pkg_parametre.deger('G_DK_NBKR_TRANSIT', varchar_list(pn_1613_INTERBANK_TRANSIT));--10003000
                   
                  if  boolean_list(pn_1613_fc_islem) then
                        pkg_parametre.deger('G_DK_FC_CASH_GL', varchar_list(pn_1613_OUTLET_CASH_GL));--10001000 FC
                    end if;   
                     if boolean_list(pn_1613_lc_islem)  then
                        pkg_parametre.deger('G_DK_LC_CASH_GL', varchar_list(pn_1613_OUTLET_CASH_GL));--10001000 LC
                    end if;  
                    
                end if;
            else
                boolean_list(pn_1613_NBKR):= true;
            end if;
log_at('asd1106',12);
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            ln_plan_no,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            ln_fis_no,
                            ls_fis_aciklama);

  end loop;
    if nvl(ln_fis_no,0) <> 0 then
         pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
    end if;
log_at('asd1106',13);
      PKG_Tx1601.Muhasebelesme(pn_islem_no ,'1613');
log_at('asd1106',14);
  End;

  Procedure Bakiye_Kontrol(pn_islem_no number)
  is
   ls_urun_sinif varchar2(200) := null;
     ls_retval varchar2(200);
    ls_pkod     varchar2(200);
    ls_kasa_kodu varchar2(200);
    ls_sube_kodu varchar2(200);
    ls_doviz varchar2(200);
    ln_adet  number := 0;
    cursor cur_doviz is
     select distinct doviz_kodu
     from  CBS_KASA_SUBE_TRNSF_DET_ISLEM b
     where tx_no  = pn_islem_no and
            doviz_kodu not in ( select distinct doviz_kodu
                                      from cbs_kasa_kupur_bakiye_islem
                                      where tx_no =pn_islem_no);


    bakiye_buyuk            exception;
    karsilanmadi            exception;

 Begin
       log_at('asd1106',15);
         select distinct urun_sinif_kod ,kasa_kodu,GONDEREN_SUBE_KODU
       into ls_urun_sinif,ls_kasa_kodu ,ls_sube_kodu
       from CBS_KASA_SUBE_TRANSFER_ISLEM
       where tx_no = pn_islem_no ;

        for c_doviz in cur_doviz loop
            ls_doviz := c_doviz.doviz_kodu ;
        end loop;
        if ls_doviz is not null then
          raise karsilanmadi;
         end if;
log_at('asd1106',16);
     Exception
     when no_data_found then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '757' || pkg_hata.getUCPOINTER);
     when karsilanmadi then
                   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '760' ||  pkg_hata.getdelimiter|| to_char(ls_doviz) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
  End;

 Procedure iptal_edilebilir_mi(pn_islem_no  number)
    is
    Begin
         NULL;
    End;

Function sf_istatistik_kod_uygunmu(ps_istatistik_kodu varchar2) return varchar2
  is
  Begin
            return 'E';
  End;

 Function sf_merkezbankasi_hesap_al (ps_doviz varchar2 )return number
 is
   ln_hesap_no                         number;
  Begin
        /* select  max(hesap_no)
       into ln_hesap_no
       from cbs_vw_hesap_izleme
       where modul_tur_kod = pkg_hesap.Modul_tur_Vadesiz and
                urun_tur_kod  = decode(ps_doviz, pkg_genel.lc_al,'NOSTRO-LC' ,'NOSTRO-FC') and
             urun_sinif_kod = decode(ps_doviz, pkg_genel.lc_al,'LC' ,'FC') and
             DK_GRUP_KOD = 1000 and
             durum_kodu = 'A';*/

        
        
     /*   
     select hesap_no
     into ln_hesap_no
from cbs_hesap  where musteri_no= 17413 
              and doviz_kodu=ps_doviz 
                AND modul_tur_kod = pkg_hesap.Modul_tur_Vadesiz and
                urun_tur_kod  = decode(ps_doviz, pkg_genel.lc_al,'NOSTRO-LC' ,'NOSTRO-FC') and
                urun_sinif_kod = decode(ps_doviz, pkg_genel.lc_al,'LC' ,'FC') and
                 
                durum_kodu = 'A';   
        
        
        return ln_hesap_no;
        */
        
        
        
         select  max(hesap_no)
       into ln_hesap_no
       from cbs_vw_hesap_izleme
       where modul_tur_kod = pkg_hesap.Modul_tur_Vadesiz and
                urun_tur_kod  = decode(ps_doviz, pkg_genel.lc_al,'NOSTRO-LC' ,'NOSTRO-FC') and
             urun_sinif_kod = decode(ps_doviz, pkg_genel.lc_al,'LC' ,'FC') and
             DK_GRUP_KOD = 1000 and
             durum_kodu = 'A'and
             doviz_kodu =ps_doviz;

        return ln_hesap_no;

        
     Exception
      when others then return null;
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '930' ||  pkg_hata.getdelimiter|| to_char(sqlcode)|| ' ' || sqlerrm || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
log_at('asd1106',17);
  End;

  Function sf_istatistik_kod_zorunlumu(ps_choice varchar2, ps_doviz varchar2) return varchar2
  is
  begin

  if ps_choice='NBKR' and ps_doviz<>pkg_genel.LC_al then
    return 'E';
  else
      return 'H';
  end if;

  end;
   
   Function bank_name (pn_hesap number) return varchar2
  is
  ls_name varchar2 (200);
  
  begin

  SELECT KISA_ISIM 
  INTO ls_name
  FROM CBS_HESAP where hesap_no=pn_hesap;
RETURN ls_name;
/*
RETURN (NULL);
*/
  end;

Begin
    pn_1613_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1613_BANKA_ACIKLAMA');
    pn_1613_dekont_aciklama :=pkg_muhasebe.parametre_index_bul('1613_DEKONT_ACIKLAMA');
    pn_1613_islem_sube :=pkg_muhasebe.parametre_index_bul('1613_ISLEM_SUBE');
    pn_1613_OUTLET_CASH_GL :=pkg_muhasebe.parametre_index_bul('1613_OUTLET_CASH_GL');
    pn_1613_borc_sube :=pkg_muhasebe.parametre_index_bul('1613_BORC_SUBE');
    pn_1613_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1613_DOVIZ_KODU');
    pn_1613_fc_islem :=pkg_muhasebe.parametre_index_bul('1613_FC_ISLEM');
    pn_1613_referans :=pkg_muhasebe.parametre_index_bul('1613_REFERANS');
    pn_1613_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1613_ISTATISTIK_KODU');
    pn_1613_NAKIT_kodu_LC :=pkg_muhasebe.parametre_index_bul('1613_NAKIT_KODU_LC');
    pn_1613_NAKIT_kodu_FC :=pkg_muhasebe.parametre_index_bul('1613_NAKIT_KODU_FC');
    pn_1613_kur :=pkg_muhasebe.parametre_index_bul('1613_KUR');
    pn_1613_tutar :=pkg_muhasebe.parametre_index_bul('1613_TUTAR');
    pn_1613_tutar_tl :=pkg_muhasebe.parametre_index_bul('1613_TUTAR_TL');
    pn_1613_lc_islem :=pkg_muhasebe.parametre_index_bul('1613_LC_ISLEM');
    pn_1613_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1613_MUSTERI_ACIKLAMA');
    pn_1613_nbk_hesap_sube := pkg_muhasebe.parametre_index_bul('1613_NBK_HESAP_SUBE');
    pn_1613_nbk_hesap_no  := pkg_muhasebe.parametre_index_bul('1613_NBK_HESAP_NO');
    pn_1613_ATM :=pkg_muhasebe.parametre_index_bul('1613_ATM');
    pn_1613_NBKR :=pkg_muhasebe.parametre_index_bul('1613_NBKR');
    pn_1613_BANK :=pkg_muhasebe.parametre_index_bul('1613_BANK');
    pn_1613_INTERBANK_TRANSIT:=pkg_muhasebe.parametre_index_bul('1613_INTERBANK_TRANSIT');
    pn_1613_DATE :=pkg_muhasebe.parametre_index_bul('1613_DATE');
    log_at('asd1106',18);
END;
/

