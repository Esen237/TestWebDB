create PACKAGE BODY     "PKG_KREDI_TAHSILAT" IS
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    PROCEDURE KRGECIKMEFAIZHESAPLA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
    ld_banka_tarihi                 DATE;
    ld_sonraki_banka_tarihi         DATE;
    ln_bugun                        NUMBER;
    ln_yarin                        NUMBER;
    ln_songun                       NUMBER;
    ln_gun_farki                    NUMBER;
    ln_durum_kodu                   NUMBER:=0;
    ln_faiz                         NUMBER ;
    ln_tutar                        NUMBER ;
    ln_komisyon                     NUMBER ;
    ln_penalty_faiz                 NUMBER ;
    
   CURSOR cur_hesap IS
     SELECT 'TAKSITLI' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             nvl(b.taksit,0) taksit,
             nvl(a.PASTDUE_FAIZ_ORANI,0) gecikme_faiz_orani,
             nvl(b.gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             sira_no taksit_no,
             nvl(b.anapara,0) anapara,
             nvl(b.tahsil_anapara,0) tahsil_anapara,
             nvl(b.faiz,0) faiz,
             nvl(b.tahsil_faiz,0) tahsil_faiz,
             nvl(a.esas_gun_sayisi,360) esas_gun_sayisi,
             a.rowid kredi_master_rowid,
             b.rowid kredi_taksit_rowid,
             null valorlu_bakiye,
             null faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
             nvl(a.penalty_amount,0)   penalty_amount ,
             b.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             b.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi         
     from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
     where a.hesap_no = b.hesap_no and 
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           b.vade_tarih <=ld_banka_tarihi and
           a.repayment_type = 'INSTALLMENT DATE' and 
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'
union all
        SELECT 'TAKSITSIZ-ANAPARA' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             null taksit,
             nvl(a.pastdue_faiz_orani,0) gecikme_faiz_orani,
             nvl(a.birikmis_gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             0 taksit_no,
             null anapara,
             null tahsil_anapara,
             null faiz,
             null tahsil_Faiz,
             nvl(a.esas_gun_sayisi,360) esas_gun_sayisi,
             a.rowid kredi_master_rowid,
             null kredi_taksit_rowid,
             abs(nvl(c.valorlu_Bakiye,0)) valorlu_bakiye,
             null faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
             nvl(a.penalty_amount,0)   penalty_amount,
             a.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             a.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi             
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and 
           a.durum_kodu = 'A' and 
           a.kredi_vade <= ld_banka_tarihi and
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and  
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
          -- and not exists (Select 1 from cbs_hesap_kredi_taksit b where b.hesap_no = a.hesap_no ) 
union all
        SELECT 'TAKSITSIZ-FAIZ' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             null taksit,
             nvl(a.PASTDUE_FAIZ_ORANI,0) gecikme_faiz_orani,
             nvl(a.birikmis_gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             0 taksit_no,
             null anapara,
             null tahsil_anapara,
             null faiz,
             null tahsil_Faiz,
             nvl(a.esas_gun_sayisi,360) esas_gun_sayisi,
             a.rowid kredi_master_rowid,
             null kredi_taksit_rowid,
             abs(nvl(c.valorlu_Bakiye,0)) valorlu_bakiye,
             abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
              nvl(a.penalty_amount,0)   penalty_amount ,
             a.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             a.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi            
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and 
           a.durum_kodu = 'A' and 
           --a.kredi_vade <= ld_banka_tarihi and
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' and
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and  
          -- and not exists (Select 1 from cbs_hesap_kredi_taksit b where b.hesap_no = a.hesap_no ) 
            pkg_odeme_plan.sf_pastdue_interest_total (a.hesap_no) > 0
          order by hesap_no,taksit_no   ;   
     
  BEGIN

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ld_sonraki_banka_tarihi:=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;

    delete from CBS_KRGECIKMEFAIZ_GUN_LOG
    where banka_Tarihi = ld_banka_tarihi;
    
    ln_bugun:=TO_NUMBER(TO_CHAR(ld_banka_tarihi,'DD'));
    ln_yarin:=TO_NUMBER(TO_CHAR(ld_sonraki_banka_tarihi,'DD'));
    ln_songun:=TO_NUMBER(TO_CHAR(LAST_DAY(ld_banka_tarihi),'DD'));

    IF ln_yarin > ln_bugun THEN    -- Aysonu deil
      IF ln_yarin > ln_bugun+1 THEN
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3268'||Pkg_Hata.GetUCPOINTER);
            ln_durum_kodu:=1;           -- Normal Haftasonu veya Tatil gnsonu
         ln_gun_farki:=ln_yarin-ln_bugun;
      ELSE
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3267'||Pkg_Hata.GetUCPOINTER);
         ln_durum_kodu:=2;           -- Normal Haftaici gnsonu
         ln_gun_farki:=1;
      END IF;
    ELSE                             -- Aysonu
      IF ln_bugun=ln_songun AND ln_yarin = 1 THEN        -- Aysonu Haftasonu veya Tatil'e denk gelmiyor
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3266'||Pkg_Hata.GetUCPOINTER);
         ln_durum_kodu:=3;           -- Normal Haftasonu veya Tatil gnsonu
         ln_gun_farki:=1;
      ELSE
           Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3265'||Pkg_Hata.GetUCPOINTER);
         ln_durum_kodu:=4;           -- Aysonu Haftasonunda
         ln_gun_farki:=ln_songun-ln_bugun+1;
      END IF;
    END IF;
      
 for c_hesap in cur_hesap loop
      ln_tutar := 0;
      ln_penalty_faiz  := 0; 
      
    if c_hesap.hesap_ayraci = 'TAKSITLI' then
        ln_tutar        := round(( (nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0))  * nvl(c_hesap.gecikme_Faiz_orani,0) * (ln_gun_Farki) ) /(c_hesap.esas_gun_sayisi * 100) ,2) ;
        ln_penalty_faiz := round(( (nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0) )  * nvl(c_hesap.penalty_rate,0) * (ln_gun_Farki) ) /(c_hesap.esas_gun_sayisi * 100) ,2) ;
        
        update cbs_hesap_kredi_taksit
        set gecikme_faiz_tutari = nvl(gecikme_faiz_tutari,0) + nvl(ln_tutar,0) , 
            penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0) ,  
            ap_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and  nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0) > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else  --B-O-M seval.colak 06122021
                                    nvl(ap_gecikme_gun_sayisi,0) end ,
            faiz_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0)  > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else
                                      nvl(faiz_gecikme_gun_sayisi,0) end     --E-O-M seval.colak 06122021                   
        where rowid = c_hesap.kredi_taksit_rowid ;
         -- b-o-m seval.colak 06042022
        update cbs_hesap_kredi
        set birikmis_gecikme_faiz_tutari = nvl(birikmis_gecikme_faiz_tutari,0) + nvl(ln_tutar,0),
            penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0),
            ap_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0) > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else --B-O-M seval.colak 06122021
                                    nvl(ap_gecikme_gun_sayisi,0) end ,
            faiz_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0)  > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else
                                      nvl(faiz_gecikme_gun_sayisi,0) end                                           
              --E-O-M seval.colak 06122021     
        where rowid = c_hesap.kredi_master_rowid  ;
        -- e-o-m seval.colak 06042022
        
        insert into CBS_KRGECIKMEFAIZ_GUN_LOG( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no,hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_gun_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
        
     elsif c_hesap.hesap_ayraci = 'TAKSITSIZ-ANAPARA' then
        
        ln_tutar        := round(( nvl(c_hesap.valorlu_bakiye,0)  * nvl(c_hesap.gecikme_Faiz_orani,0) * (ln_gun_Farki) ) /(c_hesap.esas_gun_sayisi * 100) ,2) ;
       
        update cbs_hesap_kredi
        set birikmis_gecikme_faiz_tutari = nvl(birikmis_gecikme_faiz_tutari,0) + nvl(ln_tutar,0),
             ap_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and nvl(ln_tutar,0) > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else --B-O-M seval.colak 06122021
                                        nvl(ap_gecikme_gun_sayisi,0) end 
              --E-O-M seval.colak 06122021     
        where rowid = c_hesap.kredi_master_rowid  ;
       
        insert into CBS_KRGECIKMEFAIZ_GUN_LOG( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no, hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_gun_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
        
    elsif c_hesap.hesap_ayraci = 'TAKSITSIZ-FAIZ' then
    
        ln_penalty_faiz := round(( nvl(c_hesap.faiz_tahakkuk_bakiye,0)  * nvl(c_hesap.penalty_rate,0) * (ln_gun_Farki) ) /(c_hesap.esas_gun_sayisi * 100) ,2) ;
        
        update cbs_hesap_kredi
        set  penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0) ,
             faiz_gecikme_gun_sayisi = case when nvl(ln_gun_farki,0) > 0  and ln_penalty_faiz > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_gun_Farki,0) else    --B-O-M seval.colak 06122021
                                        nvl(faiz_gecikme_gun_sayisi,0) end     --E-O-M seval.colak 06122021   
        where rowid = c_hesap.kredi_master_rowid ;
        
        update cbs_kredi_Tahakkuk       --seval.colak 07122021
        set gecikme_gun_sayisi = (Select faiz_gecikme_gun_sayisi from cbs_hesap_kredi where hesap_no = c_hesap.hesap_no)
        where banka_tarihi = ld_banka_tarihi and  kredi_hesap_no = c_hesap.hesap_no ; 
       
        insert into CBS_KRGECIKMEFAIZ_GUN_LOG( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no,hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_gun_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
        
    end if;
     
 end loop; 
 commit;
 ---seval.colak 13042022  taksitliler icin faiz_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi h
set faiz_gecikme_gun_sayisi = (   select nvl(max(nvl(f.faiz_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=ld_banka_tarihi
                                           and nvl(f.faiz,0) - nvl(f.tahsil_faiz,0)  > 0 ) --seval.colak 20012023
where h.durum_kodu = 'A' and 
      h.repayment_type = 'INSTALLMENT DATE' and
      pkg_odeme_plan.sf_urun_tahakkuk_eh(h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod) = 'E' ;
       
-- ap_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi h
set ap_gecikme_gun_sayisi = (   select nvl(max(nvl(f.ap_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=ld_banka_tarihi 
                                         and nvl(f.anapara,0) - nvl(f.tahsil_anapara,0)  > 0 ) --seval.colak 20012023
where h.durum_kodu = 'A' and 
      h.repayment_type = 'INSTALLMENT DATE' and
      pkg_odeme_plan.sf_urun_tahakkuk_eh(h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod) = 'E' ;
 commit;
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    PROCEDURE KRGECIKMEAYBASIFAIZHESAPLA(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
    ld_banka_tarihi                 DATE;
    ld_sonraki_banka_tarihi         DATE;
    ln_bugun                        NUMBER;
    ln_yarin                        NUMBER;
    ln_songun                       NUMBER;
    ln_ay_Farki                    NUMBER := 0;
    ln_durum_kodu                   NUMBER:=0;
    ln_faiz                         NUMBER ;
    ln_tutar                        NUMBER ;
    ln_komisyon                     NUMBER ;
    ln_penalty_faiz                 NUMBER ;
    
   CURSOR cur_hesap IS
     SELECT 'TAKSITLI' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             nvl(b.taksit,0) taksit,
             nvl(a.PASTDUE_FAIZ_ORANI,0) gecikme_faiz_orani,
             nvl(b.gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             sira_no taksit_no,
             nvl(b.anapara,0) anapara,
             nvl(b.tahsil_anapara,0) tahsil_anapara,
             nvl(b.faiz,0) faiz,
             nvl(b.tahsil_faiz,0) tahsil_faiz,
             nvl(a.esas_gun_sayisi,360) esas_ay_sayisi,
             a.rowid kredi_master_rowid,
             b.rowid kredi_taksit_rowid,
             null valorlu_bakiye,
             null faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
             nvl(a.penalty_amount,0)   penalty_amount ,
             faiz_baslangic_tarihi,
             b.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             b.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi        
     from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
     where a.hesap_no = b.hesap_no and 
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           b.vade_tarih <=ld_banka_tarihi and
           a.repayment_type = 'INSTALLMENT DATE' and 
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'
union all
        SELECT 'TAKSITSIZ-ANAPARA' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             null taksit,
             nvl(a.pastdue_faiz_orani,0) gecikme_faiz_orani,
             nvl(a.birikmis_gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             0 taksit_no,
             null anapara,
             null tahsil_anapara,
             null faiz,
             null tahsil_Faiz,
             nvl(a.esas_gun_sayisi,360) esas_ay_sayisi,
             a.rowid kredi_master_rowid,
             null kredi_taksit_rowid,
             abs(nvl(c.valorlu_Bakiye,0)) valorlu_bakiye,
             null faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
             nvl(a.penalty_amount,0)   penalty_amount ,
             faiz_baslangic_tarihi    ,
             a.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             a.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi      
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and 
           a.durum_kodu = 'A' and 
           a.kredi_vade <= ld_banka_tarihi and
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and  
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
          -- and not exists (Select 1 from cbs_hesap_kredi_taksit b where b.hesap_no = a.hesap_no ) 
union all
        SELECT 'TAKSITSIZ-FAIZ' hesap_ayraci,
             a.hesap_no,
             a.doviz_kodu,
             null taksit,
             nvl(a.PASTDUE_FAIZ_ORANI,0) gecikme_faiz_orani,
             nvl(a.birikmis_gecikme_faiz_tutari,0)  gecikme_faiz_tutari,
             0 taksit_no,
             null anapara,
             null tahsil_anapara,
             null faiz,
             null tahsil_Faiz,
             nvl(a.esas_gun_sayisi,360) esas_ay_sayisi,
             a.rowid kredi_master_rowid,
             null kredi_taksit_rowid,
             abs(nvl(c.valorlu_Bakiye,0)) valorlu_bakiye,
             abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) faiz_tahakkuk_Bakiye ,
             a.penalty_rate ,
              nvl(a.penalty_amount,0)   penalty_amount  ,
              faiz_baslangic_tarihi     ,
             a.ap_gecikme_gun_sayisi onceki_ap_gecikme_gun_sayisi,
             a.faiz_gecikme_gun_sayisi onceki_faiz_gecikme_gun_sayisi     
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and 
           a.durum_kodu = 'A' and 
           --a.kredi_vade <= ld_banka_tarihi and
            nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and  
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
           --and not exists (Select 1 from cbs_hesap_kredi_taksit b where b.hesap_no = a.hesap_no ) 
           and pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no) > 0
          order by hesap_no,taksit_no   ;   
     
  BEGIN

   Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ld_sonraki_banka_tarihi:=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;

    delete from cbs_krgecikmefaiz_ay_log
    where banka_Tarihi = ld_banka_tarihi;
       

    ln_bugun:=TO_NUMBER(TO_CHAR(ld_banka_tarihi,'DD'));
    ln_yarin:=TO_NUMBER(TO_CHAR(ld_sonraki_banka_tarihi,'DD'));
    ln_songun:=TO_NUMBER(TO_CHAR(LAST_DAY(ld_banka_tarihi),'DD'));

    IF ln_bugun > ln_yarin THEN    -- Aysonu
       IF ln_bugun=ln_songun AND ln_yarin = 1 THEN        -- Aysonu Haftasonu veya Tatil'e denk gelmiyor
         NULL;
         Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3266'||Pkg_Hata.GetUCPOINTER);
       ELSE
             ln_durum_kodu:=4;           -- Aysonu Haftasonunda
          ln_ay_Farki:=ln_yarin-1;
       END IF;
    ELSE
      Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3270'||Pkg_Hata.GetUCPOINTER);
    END IF;

    IF ln_durum_kodu=4 THEN
       Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'3265'||Pkg_Hata.GetUCPOINTER);
          for c_hesap in cur_hesap loop
                ln_tutar := 0;
                ln_penalty_faiz  := 0; 
                    
                 IF TRUNC(ld_banka_tarihi) >= NVL(TRUNC(c_hesap.faiz_baslangic_tarihi),TRUNC(ld_banka_tarihi)) THEN
                       if c_hesap.hesap_ayraci = 'TAKSITLI' then
                        ln_tutar        := round(( (nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0))  * nvl(c_hesap.gecikme_Faiz_orani,0) * (ln_ay_Farki) ) /(c_hesap.esas_ay_sayisi * 100) ,2) ;
                        ln_penalty_faiz := round(( (nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0) )  * nvl(c_hesap.penalty_rate,0) * (ln_ay_Farki) ) /(c_hesap.esas_ay_sayisi * 100) ,2) ;
                        
                        update cbs_hesap_kredi_taksit
                        set gecikme_faiz_tutari = nvl(gecikme_faiz_tutari,0) + nvl(ln_tutar,0) ,
                            penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0),
                            ap_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0) > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else --B-O-M seval.colak 06122021
                                                      nvl(ap_gecikme_gun_sayisi,0) end ,
                            faiz_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0)  > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else
                                                         nvl(faiz_gecikme_gun_sayisi,0) end     --E-O-M seval.colak 06122021     
                        where rowid = c_hesap.kredi_taksit_rowid ;
                        
                          -- b-o-m seval.colak 06042022
                        update cbs_hesap_kredi
                        set birikmis_gecikme_faiz_tutari = nvl(birikmis_gecikme_faiz_tutari,0) + nvl(ln_tutar,0),
                             penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0),
                              ap_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and nvl(c_hesap.anapara,0) - nvl(c_hesap.tahsil_anapara,0) > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else --B-O-M seval.colak 06122021
                                                      nvl(ap_gecikme_gun_sayisi,0) end ,
                            faiz_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and nvl(c_hesap.faiz,0) - nvl(c_hesap.tahsil_faiz,0)  > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else
                                                         nvl(faiz_gecikme_gun_sayisi,0) end       
                               --E-O-M seval.colak 06122021     
                        where rowid = c_hesap.kredi_master_rowid  ;
                        -- e-o-m seval.colak 06042022
                        
                        insert into cbs_krgecikmefaiz_ay_log( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no,hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
                        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_ay_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
                        
                       elsif c_hesap.hesap_ayraci = 'TAKSITSIZ-ANAPARA' then
                        
                        ln_tutar        := round(( nvl(c_hesap.valorlu_bakiye,0)  * nvl(c_hesap.gecikme_Faiz_orani,0) * (ln_ay_Farki) ) /(c_hesap.esas_ay_sayisi * 100) ,2) ;
                       
                        update cbs_hesap_kredi
                        set birikmis_gecikme_faiz_tutari = nvl(birikmis_gecikme_faiz_tutari,0) + nvl(ln_tutar,0),
                                ap_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and ln_tutar > 0  then nvl(ap_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else --B-O-M seval.colak 06122021
                                                        nvl(ap_gecikme_gun_sayisi,0) end    --E-O-M seval.colak 06122021     
                        where rowid = c_hesap.kredi_master_rowid  ;
                       
                        insert into cbs_krgecikmefaiz_ay_log( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no,hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
                        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_ay_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
                        
                       elsif c_hesap.hesap_ayraci = 'TAKSITSIZ-FAIZ' then
                    
                        ln_penalty_faiz := round(( nvl(c_hesap.faiz_tahakkuk_bakiye,0)  * nvl(c_hesap.penalty_rate,0) * (ln_ay_Farki) ) /(c_hesap.esas_ay_sayisi * 100) ,2) ;
                        
                        update cbs_hesap_kredi
                        set  penalty_amount  = nvl(penalty_amount,0) + nvl(ln_penalty_faiz,0),
                             faiz_gecikme_gun_sayisi = case when nvl(ln_ay_Farki,0) > 0  and ln_penalty_faiz > 0  then nvl(faiz_gecikme_gun_sayisi,0) + nvl(ln_ay_Farki,0) else    --B-O-M seval.colak 06122021
                                                       nvl(faiz_gecikme_gun_sayisi,0) end     --E-O-M seval.colak 06122021   
                        where rowid = c_hesap.kredi_master_rowid ;
                       
                         update cbs_kredi_Tahakkuk       --seval.colak 07122021
                         set gecikme_gun_sayisi = (Select faiz_gecikme_gun_sayisi from cbs_hesap_kredi where hesap_no = c_hesap.hesap_no)
                         where banka_tarihi = ld_banka_tarihi and  kredi_hesap_no = c_hesap.hesap_no ; 
                          
                        insert into cbs_krgecikmefaiz_ay_log( banka_tarihi,hesap_no,taksit_no,hesap_ayraci,durum_kodu,gecikme_faiz_orani,penalty_rate,gecikme_faiz_tutari,onceki_gecikme_faiz_tutari,  penalty_amount,onceki_penalty_amount,grup_no,log_no,hesaplanan_gun_Farki, onceki_ap_gecikme_gun_sayisi,onceki_faiz_gecikme_gun_sayisi )
                        values (ld_banka_tarihi,c_hesap.hesap_no,c_hesap.taksit_no,c_hesap.hesap_ayraci, 'A',c_hesap.gecikme_faiz_orani,c_hesap.penalty_rate,ln_tutar,c_hesap.gecikme_faiz_tutari,ln_penalty_faiz,c_hesap.penalty_amount,pn_grup_no,pn_log_no,ln_ay_Farki ,c_hesap.onceki_ap_gecikme_gun_sayisi,c_hesap.onceki_faiz_gecikme_gun_sayisi);
                        
                    end if;
                  END IF;
     
           end loop; 
        END IF;      
    commit;

---seval.colak 13042022  taksitliler icin faiz_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi h
set faiz_gecikme_gun_sayisi = (   select nvl(max(nvl(f.faiz_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=ld_banka_tarihi
                                         and nvl(f.faiz,0) - nvl(f.tahsil_faiz,0)  > 0 ) --seval.colak 20012023
where h.durum_kodu = 'A' and 
      h.repayment_type = 'INSTALLMENT DATE' and
      pkg_odeme_plan.sf_urun_tahakkuk_eh(h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod) = 'E' ;
 
-- ap_gecikme_gun_sayisi max ile guncelleyelim
update cbs_hesap_kredi h
set ap_gecikme_gun_sayisi = (   select nvl(max(nvl(f.ap_gecikme_gun_sayisi,0)),0)
                                  from cbs_hesap_kredi_taksit f
                                   where f.hesap_no = h.hesap_no and
                                         f.durum_kodu ='A' and f.vade_tarih <=ld_banka_tarihi
                                          and nvl(f.anapara,0) - nvl(f.tahsil_anapara,0)  > 0 )--seval.colak 20012023
where h.durum_kodu = 'A' and 
      h.repayment_type = 'INSTALLMENT DATE' and
      pkg_odeme_plan.sf_urun_tahakkuk_eh(h.modul_tur_kod,h.urun_tur_kod,h.urun_sinif_kod) = 'E';
      
  commit;
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE sp_insert_cbsrptkredifaiztahak(
            pn_grup_no NUMBER, 
            pn_log_no NUMBER,
            pn_kredi_hesap_no        number,
            ps_hata_mesaj            VARCHAR2,
            pn_islem_tanim_kod number default 0 ) IS
PRAGMA autonomous_transaction;
BEGIN
      INSERT INTO CBS_RPT_KREDIFAIZTAHAK_HATALI
               ( kredi_hesap_no, hata_mesaj,
               banka_tarihi, grup_no, log_no,
               islem_tanim_kod)
      VALUES (pn_kredi_hesap_no,SUBSTR(ps_hata_mesaj,1,2000),
              Pkg_Muhasebe.banka_tarihi_bul,
              pn_grup_no, pn_log_no ,
              pn_islem_tanim_kod);
      COMMIT;
  
  Exception when others then 
      log_at('PKG_KREDI_TAHSILAT','sp_insert_cbsrptkredifaiztahak',pn_kredi_hesap_no,to_char(sqlcode) || ' ' ||to_char(sqlerrm) );
      rollback;
END;
 ---------------------------------------------------------------------------
  --seval.colak 01122021 
 PROCEDURE KREDI_TAHAKKUK(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 )
 IS
    ld_banka_tarihi             date := Pkg_Muhasebe.Banka_Tarihi_Bul;
    ld_sonraki_banka_tarihi     date := Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
    ld_onceki_banka_tarihi      date := Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;
    ln_sales_tax_rate           number := 0;
    ln_islem_no                number:=0;
    ln_fis_no                  number:=0;
    ln_hesap_no                 number:=0;  
    ld_faiz_tahakkuk            date;
    ld_kredi_vade               date;
    ln_taksit_sira_no           number ;
    ls_doviz_kodu               varchar2(3);
    ln_accrual_delayed_int_account_no   number := 0;
 CURSOR cur_hesap  IS
     SELECT 
            'TAKSITLI' hesap_ayraci,
             a.musteri_no,
             a.hesap_no,
             a.sube_kodu,
             a.doviz_kodu,
             a.iliskili_hesap_no,
             sira_no taksit_no,
             a.rowid kredi_master_rowid,
             b.rowid kredi_taksit_rowid,
             faiz_tahakkuk_tarihi as   faiz_tahakkuk_tarihi  ,
             a.kredi_vade as vade_tarihi ,
             case when  abs(nvl(b.faiz,0)) > abs(nvl(b.tahsil_faiz,0)) then  abs(abs(nvl(b.faiz,0)) -    abs(nvl(b.tahsil_faiz,0))) else 0 end faiz_tahakkuk_tutar,
             case when  abs(nvl(b.bsmv,0)) > abs(nvl(b.tahsil_bsmv,0)) then  abs(abs(nvl(b.bsmv,0)) -    abs(nvl(b.tahsil_bsmv,0))) else 0 end vergi_tahakkuk_tutar,
             a.accrual_int_account_no,
             a.accrual_tax_account_no ,        
             a.faiz_siklik_Tipi ,
             nvl(a.faiz_siklik,0) faiz_siklik ,
             repayment_type,
             b.FAIZ_GECIKME_GUN_SAYISI  GECIKME_GUN_SAYISI    --seval.colak 06122021                
      from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
     where a.hesap_no = b.hesap_no and 
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           b.vade_tarih <=ld_banka_tarihi and
           a.repayment_type = 'INSTALLMENT DATE' and  -- seval ekledim 16092021
            pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'
           and nvl(b.tahakkuk_eh,'H') = 'H'            
           and substr(a.urun_tur_kod,1,3) <> 'PD-' and
               a.urun_tur_kod not like '%CARD%' and
               a.urun_sinif_kod not like '%CARD%' 
            and a.URUN_TUR_KOD NOT IN ('ACCRUAL','PAST DUE','NONACCRUAL') 
 union all
        SELECT 'TAKSITSIZ' hesap_ayraci,
             a.musteri_no,
             a.hesap_no,
             a.sube_kodu,
             a.doviz_kodu,
             a.iliskili_hesap_no,
             0 taksit_no,
             a.rowid kredi_master_rowid,
             null kredi_taksit_rowid,
             faiz_tahakkuk_tarihi,
             a.kredi_vade as vade_tarihi ,
            case when  (abs(ROUND(nvl(birikmis_faiz_tutari,0),2))  -  ABS(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no))) > 0 then  (abs(ROUND(nvl(birikmis_faiz_tutari,0),2))  -  ABS(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no))) else 0 end  faiz_tahakkuk_tutar,
            round(( case when  (abs(ROUND(nvl(birikmis_faiz_tutari,0),2))  -  ABS(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no))) > 0 then  (abs(ROUND(nvl(birikmis_faiz_tutari,0),2))  -  ABS(pkg_odeme_plan.sf_pastdue_interest_total (hesap_no))) else 0 end * nvl(ln_sales_tax_rate,0) /100),2 )  vergi_tahakkuk_tutar,
            a.ACCRUAL_INT_ACCOUNT_NO,
            a.ACCRUAL_TAX_ACCOUNT_NO  ,
            a.faiz_siklik_Tipi ,
             nvl(a.faiz_siklik,0) faiz_siklik ,
             repayment_type,
             a.FAIZ_GECIKME_GUN_SAYISI   GECIKME_GUN_SAYISI --seval.colak 06122021             
      from cbs_hesap_kredi a 
     where a.durum_kodu = 'A' and 
           a.faiz_tahakkuk_tarihi >  ld_onceki_banka_tarihi and a.faiz_tahakkuk_tarihi <= ld_banka_tarihi and
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'  and 
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE'          
           and  substr(a.urun_tur_kod,1,3) <> 'PD-' and
               a.urun_tur_kod not like '%CARD%' and
               a.urun_sinif_kod not like '%CARD%' 
            and a.URUN_TUR_KOD NOT IN ('ACCRUAL','PAST DUE','NONACCRUAL')     
           -- and a.hesap_no =523922
        order by hesap_no,taksit_no;  
 begin
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    ld_banka_tarihi:= Pkg_Muhasebe.Banka_Tarihi_Bul;
    ld_sonraki_banka_tarihi:=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
    ld_onceki_banka_tarihi:=Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;
    
   for c_hesap in cur_hesap loop
            ln_hesap_no   := c_hesap.hesap_no;        
            ls_doviz_kodu := c_hesap.doviz_kodu;
            ln_taksit_sira_no := c_hesap.taksit_no;
            ld_kredi_vade     := c_hesap.vade_tarihi;
            ld_faiz_tahakkuk := c_hesap.faiz_tahakkuk_tarihi;
            ln_islem_no   := 0;
           
        if c_hesap.faiz_siklik_tipi  = 'INSTALLMENT DATE' or  c_hesap.repayment_type  = 'INSTALLMENT DATE' then
                     begin
                        select min(vade_tarih)
                        into ld_faiz_tahakkuk
                        from cbs_hesap_kredi_taksit b
                        where b.hesap_no = ln_hesap_no and
                              b.durum_kodu = 'A' and
                              trunc(b.vade_tarih) > ld_banka_tarihi and
                              nvl(b.faiz,0) <> 0  ;
                    exception when others then
                              ld_faiz_tahakkuk := ld_kredi_vade ;
                    end;
         else
                 ld_faiz_tahakkuk := pkg_kredi.sf_faiz_tahakkuk_tarihi_bul( nvl(c_hesap.faiz_siklik_tipi,'MATURITY DATE') ,nvl(c_hesap.faiz_siklik,0) ,nvl(c_hesap.faiz_tahakkuk_tarihi,ld_kredi_vade ),ld_kredi_vade);

         end if;
             
                
      if ld_faiz_tahakkuk > ld_kredi_vade or ld_faiz_tahakkuk is null then
            ld_faiz_tahakkuk := ld_kredi_vade ;
       end if;
  
    update cbs_hesap_kredi
    set birikmis_sch_faizi = 0,
        gecenyil_sch_faizi = 0,
        faiz_tahakkuk_tarihi = nvl(ld_faiz_tahakkuk,kredi_vade)   
     where hesap_no = ln_hesap_no ;
                    
                                          
    if c_hesap.hesap_ayraci = 'TAKSITLI' then
         update cbs_hesap_kredi_taksit
         set tahakkuk_EH = 'E'
         where hesap_no = ln_hesap_no and sira_no = nvl(ln_taksit_sira_no,0);
    end if;
                    
      if c_hesap.hesap_ayraci = 'TAKSITSIZ' then                        
        if  nvl(c_hesap.faiz_tahakkuk_tutar,0)  > 0 then          
           insert into CBS_KREDI_TAHAKKUK
            (       banka_tarihi	,
                    musteri_no	,
                    kredi_hesap_no	,
                    kredi_doviz_kodu	,
                    faiz_tahakkuk_tarihi	,
                    vade_tarihi,	
                    yeni_faiz_tahakkuk_tarihi	,
                    faiz_tahakkuk_tutar	,
                    vergi_tahakkuk_tutar	,
                    faiz_tahakkuk_tutar_tahsil	,
                    vergi_tahakkuk_tutar_tahsil	,
                    gecikme_gun_sayisi	,
                    yaratan_islem_kod	,
                    yaratan_tx_no	,
                    muhasebe_fis_no	,
                    grup_no	,
                    log_no,
                    tahakkuk_no	)
            values
           (    ld_banka_tarihi,    	
                 c_hesap.musteri_no	,
                 c_hesap.hesap_no	,
                 c_hesap.doviz_kodu	,
                 c_hesap.faiz_tahakkuk_tarihi	,
                 c_hesap.vade_tarihi	,      
                 ld_faiz_tahakkuk	,
                 c_hesap.faiz_tahakkuk_tutar ,--FAIZ_TAHAKKUK_TUTAR	,               --??
                 c_hesap.vergi_tahakkuk_tutar, --VERGI_TAHAKKUK_TUTAR	,           
                 0,--FAIZ_TAHAKKUK_TUTAR_TAHSIL	,
                 0,--VERGI_TAHAKKUK_TUTAR_TAHSIL	,
                 c_hesap.gecikme_gun_sayisi,  --seval.colak 06122021      
                 0,-- ln_islem_kod	,
                 ln_islem_no,-- ln_islem_no	,
                 ln_fis_no,--ln_fis_no	,
                 pn_grup_no	,
                 pn_log_no,
                 pkg_genel.genel_kod_al('KREDITAHAKKUKNO')) ;                                  
            end if;
         end if;     
         
         -- B-O-M seval.colak 12042022
           ln_accrual_delayed_int_account_no := 0;
           
           select accrual_delayed_int_account_no 
           into ln_accrual_delayed_int_account_no
           from  cbs_hesap_kredi a
           where hesap_no = ln_hesap_no;
         
         IF  nvl(ln_accrual_delayed_int_account_no,0) = 0  THEN
            Begin
             PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(  ln_hesap_no,
                                                  --  c_hesap.iliskili_hesap_no,
                                                    ln_islem_no,
                                                    ln_islem_no,
                                                    0,--c_hesap.faiz_tahakkuk_tutar,
                                                    'ACCRUAL-DELAYED-INTEREST',
                                                    ln_accrual_delayed_int_account_no
                                                    ) ;
              Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_accrual_delayed_int_account_no)||Pkg_Hata.GetDelimiter||'ACCRUAL-DELAYED-INTEREST'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
              
             Exception when others
                then rollback; null;
             end;
             
         END IF;  
         commit;
        -- E-O-M seval.colak 12042022
    end loop; 
    
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
     rollback;
     LOG_AT('KREDI_TAHAKKUK',ln_hesap_no,ln_fis_no,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
    Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||ln_hesap_no ||' '||TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Procedure sf_accrual_int_tax_account_open(  pn_kredi_hesap_no number,
                                            pn_yaratan_islem_no    number default 0,                                           
                                            pn_tutar number default 0 
                                         )
IS
ln_iliskili_hesap_no        number;
ln_accrual_int_accountno    number;
ln_accrual_tax_accountno    number;
 Begin
 
     select iliskili_hesap_no ,a.accrual_int_account_no, a.accrual_tax_account_no           
     into ln_iliskili_hesap_no , ln_accrual_int_accountno ,ln_accrual_tax_accountno        
     from cbs_hesap_kredi a
     where hesap_no = pn_kredi_hesap_no;
     
    if nvl(ln_accrual_int_accountno,0)= 0 then 
        pkg_kredi_tahsilat.sf_pastdue_accrual_kredi_hesap_ac(pn_kredi_hesap_no,pn_yaratan_islem_no ,pn_yaratan_islem_no,pn_tutar,'ACCRUAL-INTEREST',ln_accrual_int_accountno);
    end if;
    if nvl(ln_accrual_tax_accountno,0) = 0 then
        pkg_kredi_tahsilat.sf_pastdue_accrual_kredi_hesap_ac(pn_kredi_hesap_no,pn_yaratan_islem_no ,pn_yaratan_islem_no,pn_tutar,'ACCRUAL-TAX',ln_accrual_tax_accountno);
     end if;
 End;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Procedure sf_nonaccrual_accounts_opening(  pn_kredi_hesap_no number,
                                            pn_yaratan_islem_no    number default 0,                                           
                                            pn_tutar number default 0 
                                      )
IS
ln_iliskili_hesap_no        number;
ln_nonaccrual_int_account_no    number;
ln_nonaccrual_delayed_int_account_no    number;
 Begin
 
     select a.iliskili_hesap_no ,a.nonaccrual_int_account_no, a.nonaccrual_delayed_int_account_no        
     into ln_iliskili_hesap_no ,ln_nonaccrual_int_account_no ,ln_nonaccrual_delayed_int_account_no         
     from cbs_hesap_kredi a
     where hesap_no = pn_kredi_hesap_no;
     if nvl(ln_nonaccrual_int_account_no,0)= 0 then 
        pkg_kredi_tahsilat.sf_pastdue_accrual_kredi_hesap_ac(pn_kredi_hesap_no,pn_yaratan_islem_no ,pn_yaratan_islem_no,pn_tutar,'NONACCRUAL-INTEREST',ln_nonaccrual_int_account_no);
    end if;
    if nvl(ln_nonaccrual_delayed_int_account_no,0)= 0 then 
        pkg_kredi_tahsilat.sf_pastdue_accrual_kredi_hesap_ac(pn_kredi_hesap_no,pn_yaratan_islem_no ,pn_yaratan_islem_no,pn_tutar,'NONACCRUAL-DELAYED-INTEREST',ln_nonaccrual_delayed_int_account_no);
     end if;
 End; 
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 Procedure sf_pastdue_accrual_kredi_hesap_ac(pn_kredi_hesap_no number,
                                             pn_yaratan_islem_no    number default 0,
                                             pn_yeni_islem_no    number default 0 ,
                                             pn_tutar number,
                                             ps_faiz_anapara varchar2 default 'FAIZ',
                                             pn_pastdue_hesap_no out number
                                        ) is

   ls_musteri_dk_no  cbs_hesap_kredi.musteri_dk_no%type;
   ld_vade_faiz date;

    CURSOR cursor_hesap IS
             SELECT
                     modul_tur_kod,
                    urun_tur_kod ,
                    urun_sinif_kod,
                    hesap_no,
                    MUSTERI_NO,
                    DOVIZ_KODU,
                    pn_tutar  tutar,
                    'A' durum_kodu,
                    sube_kodu,
                    iliskili_hesap_no ,
                    kredi_vade,
                    extre_masrafi ,
                    ACCRUAL_INT_ACCOUNT_NO,
                    ACCRUAL_TAX_ACCOUNT_NO,
                    kredi_teklif_satir_numara,
                    kredi_kullandirim_kodu,
                    0 faiz_siklik,
                    'MATURITY DATE' faiz_siklik_tipi,
                    kullandirim_doviz_kodu,
                    son_gun_faizi,
                    sinirlama_kodu,
                    kaynak_kodu,
                    urun_grup_no,
                    esas_gun_sayisi,
                    pkg_muhasebe.banka_tarihi_bul acilis_tarihi,
                    kredi_turu,
                    prefix_istatistik_kodu_faiz,
                    prefix_istatistik_kodu_kapama,
                    istatistik_kodu_faiz,
                    istatistik_kodu_kapama,
                    pastdue_faiz_orani,
                    yearly_int_rate                                   
         FROM  CBS_HESAP_KREDI
         WHERE hesap_no = pn_kredi_hesap_no ;
        
    ls_msg_err      varchar2(2000) := null;
    r_hesap     cursor_hesap%rowtype ;
   BEGIN

   FOR cur_hesap IN cursor_hesap LOOP
   r_hesap :=cur_hesap;
   End loop;
   
  if ps_faiz_anapara = 'ACCRUAL-INTEREST' then
          ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(r_hesap.MUSTERI_NO,
                                                         pkg_kredi.modul_tur_kod,
                                                         r_hesap.urun_tur_kod,
                                                         r_hesap.urun_sinif_kod,4) ;
          r_hesap.urun_tur_kod := 'ACCRUAL';          
          SELECT 'INTEREST' ||'-' || DECODE(r_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
          into r_hesap.urun_sinif_kod
          from dual;          
          ld_vade_faiz := r_hesap.kredi_vade;
    elsif ps_faiz_anapara = 'ACCRUAL-TAX' then
          pkg_parametre.deger('G_DK_ACCRUAL_TAX_RECEIVAL', ls_musteri_dk_no);
          r_hesap.urun_tur_kod := 'ACCRUAL';
          SELECT 'TAX' ||'-' || DECODE(r_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
          into r_hesap.urun_sinif_kod
          from dual;          
          ld_vade_faiz := r_hesap.kredi_vade;  
    elsif ps_faiz_anapara = 'ACCRUAL-DELAYED-INTEREST' then  
             ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(r_hesap.MUSTERI_NO,
                                                pkg_kredi.modul_tur_kod,
                                                r_hesap.urun_tur_kod,
                                                r_hesap.urun_sinif_kod,11) ;
             
             r_hesap.urun_tur_kod := 'ACCRUAL';          
              SELECT 'DELAYED-INTEREST' ||'-' || DECODE(r_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
              into r_hesap.urun_sinif_kod
              from dual;          
              ld_vade_faiz := r_hesap.kredi_vade;

--B-O-M SEVAL.COLAK 23112021
    elsif ps_faiz_anapara = 'NONACCRUAL-INTEREST' then
        /*  ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(r_hesap.MUSTERI_NO,
                                                         pkg_kredi.modul_tur_kod,
                                                         r_hesap.ana_kredi_urun_tur_kod,
                                                         r_hesap.ana_kredi_urun_sinif_kod,4) ;
          */                                               
          pkg_parametre.deger('G_DK_NONACCRUAL_INT_DEBIT', ls_musteri_dk_no); -- seval.colak 23112021
          r_hesap.urun_tur_kod := 'NONACCRUAL';          
          SELECT 'INTEREST' ||'-' || DECODE(r_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
          into r_hesap.urun_sinif_kod
          from dual;          
          ld_vade_faiz := r_hesap.kredi_vade;   
    elsif ps_faiz_anapara = 'NONACCRUAL-DELAYED-INTEREST' then   
            /* ls_musteri_dk_no :=pkg_kredi.sf_kredi_dk_bul(r_hesap.MUSTERI_NO,
                                                pkg_kredi.modul_tur_kod,
                                                r_hesap.urun_tur_kod,
                                                r_hesap.urun_sinif_kod,4) ;
             */
              pkg_parametre.deger('G_DK_NONACCRUAL_INT_DEBIT', ls_musteri_dk_no); -- seval.colak 23112021
             r_hesap.urun_tur_kod := 'NONACCRUAL';          
              SELECT 'DELAYED-INTEREST' ||'-' || DECODE(r_hesap.doviz_kodu,pkg_genel.lc_al,'LC','FC')
              into r_hesap.urun_sinif_kod
              from dual;          
              ld_vade_faiz := r_hesap.kredi_vade;
     end if;       
     
      
      ls_msg_err  := r_hesap.hesap_no ||','||r_hesap.urun_tur_kod ||','||r_hesap.urun_sinif_kod||','||ls_musteri_dk_no ||','||ps_faiz_anapara ;
   
   if ps_faiz_anapara  is not null then                                     
     pkg_kredi.kredi_hesap_ac (      pkg_kredi.modul_tur_kod,
                                     r_hesap.urun_tur_kod,
                                     r_hesap.urun_sinif_kod,
                                     r_hesap.MUSTERI_NO,
                                     r_hesap.DOVIZ_kodu,
                                     r_hesap.SUBE_KODU,
                                     nvl(ld_vade_faiz,r_hesap.kredi_vade),
                                     NULL,
                                     pn_pastdue_hesap_no,
                                     p_musteri_dk_no => ls_musteri_dk_no,  --musteri_dk_no
                                     p_tutar => pn_tutar , --tutar
                                     p_extre_masrafi => r_hesap.extre_masrafi,--    extre_masrafi
                                     p_iliskili_hesap_no =>  r_hesap.iliskili_hesap_no,
                                     p_kredi_teklif_satir_numara => r_hesap.KREDI_TEKLIF_SATIR_NUMARA,
                                     p_kredi_kullandirim_kodu =>r_hesap.kredi_kullandirim_kodu,
                                     p_faiz_siklik => r_hesap.faiz_siklik,
                                     p_faiz_siklik_tipi => r_hesap.faiz_siklik_tipi,
                                     p_faiz_tahakkuk_tarihi=> nvl(ld_vade_faiz,r_hesap.kredi_vade),
                                     p_kullandirim_doviz_kodu=> r_hesap.kullandirim_doviz_kodu,
                                     p_son_gun_faizi => r_hesap.son_gun_faizi,
                                     p_sinirlama_kodu => r_hesap.sinirlama_kodu,
                                     p_kaynak_kodu => r_hesap.kaynak_kodu,
                                     p_urun_grup_no => r_hesap.urun_grup_no,
                                     p_esas_gun_sayisi => r_hesap.esas_gun_sayisi,
                                     p_acilis_tarihi => r_hesap.acilis_tarihi,
                                     p_kredi_turu => r_hesap.kredi_turu,
                                     p_prefix_istatistik_kodu_faiz => r_hesap.prefix_istatistik_kodu_faiz,
                                     p_prefix_istatistik_kodu_kapa => r_hesap.prefix_istatistik_kodu_kapama,
                                     p_istatistik_kodu_faiz =>r_hesap.istatistik_kodu_faiz,
                                     p_istatistik_kodu_kapama => r_hesap.istatistik_kodu_kapama,
                                     p_ana_kredi_hesap_no    => r_hesap.HESAP_NO,
                                     p_pastdue_faiz_anapara_sec =>ps_faiz_anapara,
                                     p_faiz_orani => 0,--seval.colak  faiz orani 0 olan pastduelari aciyoruz.  
                                     p_pastdue_faiz_orani => 0
                                         );
   end if;
         
   if ps_faiz_anapara  = 'ACCRUAL-INTEREST' then
        UPDATE CBS_HESAP_KREDI
        SET accrual_int_account_no = pn_pastdue_hesap_no          
        WHERE hesap_no = pn_kredi_hesap_no ;
        if nvl(pn_yaratan_islem_no,0) <> 0 then         
            UPDATE CBS_HESAP_KREDI_ISLEM
            SET accrual_int_account_no = pn_pastdue_hesap_no          
            WHERE tx_no = pn_yaratan_islem_no  ;
        end if;        
    elsif ps_faiz_anapara  = 'ACCRUAL-TAX' then        
        UPDATE CBS_HESAP_KREDI
        SET accrual_tax_account_no = pn_pastdue_hesap_no          
        WHERE hesap_no = pn_kredi_hesap_no ;        
        if nvl(pn_yaratan_islem_no,0) <> 0 then         
            UPDATE CBS_HESAP_KREDI_ISLEM
            SET accrual_tax_account_no = pn_pastdue_hesap_no          
            WHERE tx_no = pn_yaratan_islem_no  ;
        end if;        
    elsif ps_faiz_anapara  =  'ACCRUAL-DELAYED-INTEREST' then        
        UPDATE CBS_HESAP_KREDI
        SET accrual_delayed_int_account_no = pn_pastdue_hesap_no          
        WHERE hesap_no = pn_kredi_hesap_no ;  
         if nvl(pn_yaratan_islem_no,0) <> 0 then         
            UPDATE CBS_HESAP_KREDI_ISLEM
            SET accrual_delayed_int_account_no = pn_pastdue_hesap_no          
            WHERE tx_no = pn_yaratan_islem_no  ;
        end if; 
-- seval.colak 23112021 
    elsif ps_faiz_anapara  = 'NONACCRUAL-INTEREST' then        
        UPDATE CBS_HESAP_KREDI
        SET nonaccrual_int_account_no = pn_pastdue_hesap_no          
        WHERE hesap_no = pn_kredi_hesap_no ;  
        if nvl(pn_yaratan_islem_no,0) <> 0 then         
            UPDATE CBS_HESAP_KREDI_ISLEM
            SET nonaccrual_int_account_no = pn_pastdue_hesap_no          
            WHERE tx_no = pn_yaratan_islem_no  ;
        end if;       
    elsif ps_faiz_anapara  =  'NONACCRUAL-DELAYED-INTEREST' then        
        UPDATE CBS_HESAP_KREDI
        SET nonaccrual_delayed_int_account_no = pn_pastdue_hesap_no          
        WHERE hesap_no = pn_kredi_hesap_no ; 
         if nvl(pn_yaratan_islem_no,0) <> 0 then         
            UPDATE CBS_HESAP_KREDI_ISLEM
            SET nonaccrual_delayed_int_account_no = pn_pastdue_hesap_no          
            WHERE tx_no = pn_yaratan_islem_no  ;
        end if;   
-- e-o-m seval.colak 23112021                      
    end if;
    --Pkg_Kredi.sp_kredihesap_isleme_at (pn_pastdue_hesap_no,
      --                                       pn_yeni_islem_no,
      
    -- b-o-m seval.colak 23122021 accrual,nonaccrual hesaplar bakiye karakteri H her ikisi de olacak sekilde olmali. 
        update cbs_hesap_bakiye
        set bakiye_karakteri = 'H'        
        where hesap_no = pn_pastdue_hesap_no ;
    -- e-o-m seval.colak  23122021
        
    EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '6855' || Pkg_Hata.getDelimiter || substr(TO_CHAR(SQLCODE) ||' -'|| ls_msg_err|| SQLERRM ,1,2000)||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);

   END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE sp_insert_cbsrptkreditahsilat(
            pn_grup_no NUMBER, 
            pn_log_no NUMBER,
            pn_kredi_hesap_no           number,
            ps_hata_mesaj               varchar2,
            pn_islem_tanim_kod          number default 1323,
            pn_kredi_tahsilat_log_no    number,
            ps_islem_tipi               varchar2 default null,
            pn_taksit_no                number default 0   ,
            pn_islem_no                 number default 0 ,
            pn_fis_no                   number default 0 ) is
PRAGMA autonomous_transaction;
BEGIN
      insert into cbs_rpt_kredi_tahsilat_hatali
               ( hata_no,kredi_hesap_no, hata_mesaj,
               banka_tarihi, grup_no, log_no,
               islem_tanim_kod,
               kredi_tahsilat_log_no,
               taksit_no,islem_tipi,yaratan_tx_no,muhasebe_Fis_No )
      values ( pkg_genel.genel_kod_al('KREDI_TAHSIL_HATA_NO'),pn_kredi_hesap_no,substr(ps_hata_mesaj,1,2000),
              pkg_muhasebe.banka_tarihi_bul,
              pn_grup_no, pn_log_no ,
              pn_islem_tanim_kod,
              pn_kredi_tahsilat_log_no,
              pn_taksit_no,ps_islem_tipi,pn_islem_no,pn_fis_no);
      commit;

  Exception
    when others then 
      log_at('PKG_KREDI_TAHSILAT','sp_insert_cbsrptkreditahsilat',pn_kredi_hesap_no,to_char(sqlcode) || ' ' ||to_char(sqlerrm) );
      rollback;
      
      
END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  function TAHSILAT_MUSTERI_TOP_BAKIYE_AL(pn_musteri_no number, ps_convert_dvz varchar2) return number is
    cursor c1 is 
      select pkg_hesap.kullanilabilir_bakiye_al(hesap_no) amount, hesap_no, doviz_kodu
        from cbs_hesap  a ,cbs_musteri b 
       where a.musteri_no = b.musteri_no
         and a.durum_kodu = 'A' 
         and a.musteri_no =pn_musteri_no
         and b.musteri_no = pn_musteri_no 
         and pkg_hesap.kullanilabilir_bakiye_al(a.hesap_no) >0  
         and a.hesap_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where status = 'ACTIVE' and nvl(ortaklik_tipi, 'XX') <>'OY')  
         and a.urun_tur_kod not in (  'SWAP','SWAP-FW' ,'SPOT','FORWARD','CASH COLL.') --seval.colak 18012023
         and a.urun_tur_kod in ('CURRENT','DEMAND DEP' ) --seval.colak 18012023
         and a.urun_tur_kod not like '%CARD%'
         and a.urun_sinif_kod not like '%CARD%'
         and a.urun_sinif_kod not in ('OVERBALANCE-LC','OVERBALANCE-FC')
         and  exists (select 1 from cbs_hesap_bakiye c where c.hesap_no  =a.hesap_no and bakiye_karakteri ='P') 
         and a.URUN_TUR_KOD NOT IN ('ACCRUAL','PAST DUE','NONACCRUAL') 
         and  substr(a.URUN_TUR_KOD,1,3)  <> 'PD-'  ;
    
    r1 c1%rowtype;
    ln_balance number;
  BEGIN
    ln_balance := 0;
    for r1 in c1 loop
        if r1.amount > 0 then
            if ps_convert_dvz = r1.doviz_kodu then
                ln_balance := ln_balance + r1.amount;
            else
                ln_balance := ln_balance +pkg_kur.yuvarla(ps_convert_dvz, (r1.amount 
                                        * pkg_kur.doviz_doviz_karsilik(r1.doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A') 
                                        / pkg_kur.doviz_doviz_karsilik(ps_convert_dvz,pkg_genel.lc_al,null,1,1,null,null,'O','S')));
            end if;
        end if; 
    end loop;
    
    return nvl(ln_balance,0);
    Exception when others then     
        return 0 ;
  END;  
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------  

 function TAHSILAT_HESAP_BAKIYE_AL(pn_hesap_no number, ps_convert_dvz varchar2) return number is
    cursor c1 is 
      select pkg_hesap.kullanilabilir_bakiye_al(hesap_no) amount, hesap_no, doviz_kodu
        from cbs_hesap  a 
       where a.durum_kodu = 'A'  
         and a.hesap_no = pn_hesap_no 
         and pkg_hesap.kullanilabilir_bakiye_al(a.hesap_no) >0  
         and a.hesap_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where status = 'ACTIVE' and nvl(ortaklik_tipi, 'XX') <>'OY') 
         and a.urun_tur_kod not in (  'SWAP','SWAP-FW' ,'SPOT','FORWARD','CASH COLL.') --seval.colak 18012023
         and a.urun_tur_kod in ('CURRENT','DEMAND DEP' ) --seval.colak 18012023
         and a.urun_tur_kod not like '%CARD%'
         and a.urun_sinif_kod not like '%CARD%'
         and a.urun_sinif_kod not in ('OVERBALANCE-LC','OVERBALANCE-FC')
         and  exists (select 1 from cbs_hesap_bakiye c where c.hesap_no  =a.hesap_no and bakiye_karakteri ='P')       
         and nvl(a.badlist_flag,'H') <> 'E';    --seval.colak 24112022 badlist customer will not be collected with automatic payment  
         
    r1 c1%rowtype;
    ln_balance number;
  BEGIN
    ln_balance := 0;
    for r1 in c1 loop
        if r1.amount > 0 then
            if ps_convert_dvz = r1.doviz_kodu then
                ln_balance := ln_balance + r1.amount;
            else
                ln_balance := ln_balance +   ( (r1.amount * pkg_kur.doviz_doviz_karsilik(r1.doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A')) 
                                                 /  pkg_kur.doviz_doviz_karsilik(ps_convert_dvz,pkg_genel.lc_al,null,1,1,null,null,'O','S') );
            end if;
        end if;
        
    end loop;
   
    return nvl(ln_balance,0);
    Exception when others then 
    
        return 0 ;
  END;    
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
procedure TAHSILAT_TRANSFER (   pn_grup_no number, 
                                pn_log_no number,
                                ps_program_kod varchar2 ,                       
                                pn_kredi_hesap_no number, 
                                pn_from_account number,
                                pn_to_related_account number,  
                                pn_amount number,  
                                pn_islem_no out number) is pragma autonomous_transaction;
                                
                                
                                
 
     ln_musteri_no number; 
     ls_account_currency            cbs_hesap.doviz_kodu%type;
     ls_account_branch              cbs_hesap.sube_kodu%type;
     ls_to_related_currency         cbs_hesap.doviz_kodu%type;
     ln_bakiye                      number; 
     ln_islem_kod                   number  :=1203;
     ln_islem_no                    number; 
     ls_modul_tur_kod               cbs_islem.modul_tur_kod%type;
     ls_urun_tur_kod                cbs_islem.urun_tur_kod%type;
     ls_urun_sinif_kod              cbs_islem.urun_sinif_kod%type;
     ls_alis_doviz_kodu             varchar2(3);
     ls_satis_doviz_kodu            varchar2(3);
     ln_alis_tutari                 number;
     ln_satis_tutari                number;
     ln_alis_hesap_no               number;
     ln_satis_hesap_no              number;
     ls_name_surname                varchar2(300);
     ls_explanation                 varchar2(100);
     ln_lc_amount                    number;
     ls_istatistik_kodu             cbs_virman_islem.istatistik_kodu%type;
     ls_mesaj                       varchar2(2000):= '';
     ls_islem_tipi                  varchar2(200) := 'TRANSFER';
     ln_fis_no                      number := 0;
     ln_kredi_transfer_log_no       number;
     ld_banka_tarihi                date := pkg_muhasebe.banka_tarihi_bul;
     ls_kredi_doviz_kodu            cbs_hesap_kredi.doviz_kodu%type;
     ls_musteri_adi                 varchar2(200);
begin
    
    ls_account_currency         := pkg_hesap.HesaptanDovizKoduAl(pn_from_account);
    ls_to_related_currency      := pkg_hesap.HesaptanDovizKoduAl(pn_to_related_account);
    ln_musteri_no               := pkg_hesap.HesaptanMusteriNoAl(pn_from_account);    
    ls_account_branch           := pkg_hesap.HesapSubeAl(pn_from_account);
    ls_musteri_adi              := trim(upper(pkg_hesap.hesapkisaisimal(pn_from_account)));   -- seval.colak 29112022
    if ls_musteri_adi is null then 
        ls_musteri_adi              := substr(trim(upper(pkg_musteri.sf_musteri_adi(  ln_musteri_no))),1,30);
    end if;
    ls_to_related_currency     :=  pkg_hesap.hesaptandovizkodual(pn_to_related_account);
   
    ls_kredi_doviz_kodu := ls_to_related_currency;

    
    ls_explanation := substr('ПЕРЕВОД С (' || pn_from_account || ') НА (' || pn_to_related_account || ') ДЛЯ ПОГАШЕНИЯ КРЕДИТА (' || pn_kredi_hesap_no || ')-'  || ls_musteri_adi,1,100); --seval.colak 15112022
    ln_alis_tutari := pn_amount;
    
    ln_bakiye := round(pkg_hesap.kullanilabilir_bakiye_al(pn_from_account),2);
    ln_kredi_transfer_log_no := pkg_genel.genel_kod_al('KREDI_TRANSFER_LOGNO');
    
       if pn_to_related_account is not null and pn_to_related_account <> pn_from_account and pn_amount > 0 and ln_bakiye > 0 and ls_to_related_currency = ls_account_currency and ls_kredi_doviz_kodu = ls_to_related_currency then
            ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,ls_account_branch); 
             pn_islem_no := ln_islem_no;
                          
             if ln_bakiye >= pn_amount then 
                ln_alis_tutari := pn_amount ;
             else
               ln_alis_tutari := ln_bakiye ;
             end if;   
            
            pkg_tx1203.sp_urun_tur_sinif_al(pn_from_account, pn_to_related_account, ls_account_currency, null, ls_modul_tur_kod,ls_urun_tur_kod, ls_urun_sinif_kod);
            pkg_parametre.deger('ISTAT_KODU_B2B_FOR_PD_CLOSING', ls_istatistik_kodu );
            
            insert into cbs_virman_islem (tx_no                   ,
                                      borc_hesap_no           ,
                                      doviz_kodu              ,
                                      tutar                   ,
                                      alacak_hesap_no         ,
                                      aciklama                ,
                                      borc_external_hesap     ,
                                      borc_vergi_no           ,
                                      alacak_external_hesap   ,
                                      alacak_vergi_no         ,
                                      istatistik_kodu         ,
                                      charge_amount           )
            values          (ln_islem_no, 
                             pn_from_account,
                             ls_account_currency,
                             ln_alis_tutari,
                             pn_to_related_account,
                             ls_explanation,
                             pkg_hesap.external_hesapno_al(pn_from_account),
                             pkg_musteri.sf_vergino_al(ln_musteri_no),
                             pkg_hesap.external_hesapno_al(pn_to_related_account),
                             pkg_musteri.sf_vergino_al(ln_musteri_no),
                             ls_istatistik_kodu,
                             0); 
                           
                pkg_tx1203.muhasebelesme(ln_islem_no);
                ln_fis_no:=  pkg_tx.fis_no(ln_islem_no);
           
                 insert into cbs_rpt_kredi_transfer ( 
                                                    transfer_log_no    ,
                                                    banka_tarihi    ,
                                                    islem_tipi    ,
                                                    musteri_no    ,
                                                    kredi_hesap_no    ,
                                                    tutar    ,
                                                    doviz_kodu,
                                                    from_account,
                                                    to_account,
                                                    from_account_bakiye,
                                                    grup_no    ,
                                                    log_no,
                                                    yaratan_islem_kod,
                                                    yaratan_tx_no,
                                                    muhasebe_fis_no
                                                        )
                                                values (ln_kredi_transfer_log_no,
                                                         ld_banka_tarihi    ,
                                                        ls_islem_tipi   ,
                                                        ln_musteri_no    ,
                                                        pn_kredi_hesap_no   ,
                                                        ln_alis_tutari,
                                                        ls_kredi_doviz_kodu    ,
                                                        pn_from_account   ,
                                                        pn_to_related_account  ,
                                                        ln_bakiye,
                                                        pn_grup_no    ,
                                                        pn_log_no,
                                                        ln_islem_kod,
                                                        ln_islem_no,
                                                        ln_fis_no
                                                        );
                                                        
                
                pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,pkg_hata.generatemessage(pkg_hata.getucpointer || '6825' || pkg_hata.getdelimiter || to_char(pn_from_account) || pkg_hata.getdelimiter || to_char(ln_fis_no) || pkg_hata.getdelimiter || pkg_hata.getucpointer) ,ln_islem_no );             
        end if;
                          
 commit;
exception
       when others then
         rollback;
          ls_mesaj := pkg_hata.generatemessage(pkg_hata.getucpointer || '6824' || pkg_hata.getdelimiter || to_char(pn_from_account) || pkg_hata.getdelimiter || to_char(ln_fis_no) || pkg_hata.getdelimiter ||  to_char(sqlcode)|| ' ' ||sqlerrm  || pkg_hata.getdelimiter || pkg_hata.getucpointer) ;
          pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_mesaj ,ln_islem_no);
          sp_insert_cbsrptkreditahsilat(pn_grup_no,pn_log_no,pn_kredi_hesap_no,ls_mesaj,ln_islem_kod,ln_kredi_transfer_log_no,ls_islem_tipi,0,ln_islem_no,ln_fis_no);
end;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 PROCEDURE TAHSILAT_ARBITRAGE  (
                                pn_grup_no number, 
                                pn_log_no number,
                                ps_program_kod varchar2 ,                       
                                pn_kredi_hesap_no number, 
                                pn_from_account number,
                                pn_to_related_account number,  
                                pn_amount number,  
                                pn_islem_no out number) is pragma autonomous_transaction; 
 
     ln_musteri_no              number; 
     ln_available_balance       number;
     ls_account_currency        cbs_hesap.doviz_kodu%type;
     ls_account_branch          cbs_hesap.sube_kodu%type;
     ln_bakiye                  number;  
     ln_islem_kod               number :=1207;
     ln_islem_no                number; 
     ls_modul_tur_kod           cbs_islem.modul_tur_kod%type;
     ls_urun_tur_kod            cbs_islem.urun_tur_kod%type;
     ls_urun_sinif_kod          cbs_islem.urun_sinif_kod%type;
     ls_kredi_doviz_kodu        cbs_hesap_kredi.doviz_kodu%type;
     ls_kur_tipi                cbs_arbitraj_islem.kur_tipi%type;
     ls_alis_doviz_kodu         cbs_arbitraj_islem.alis_doviz_kodu%type;
     ls_satis_doviz_kodu        cbs_arbitraj_islem.satis_doviz_kodu%type;
     ls_residency_code          cbs_arbitraj_islem.residency_code%type;
     ls_citizen_code            cbs_arbitraj_islem.citizen_code%type;
     ls_tax_number              cbs_arbitraj_islem.tax_number%type;
     ls_kur_parite_secim        cbs_arbitraj_islem.kur_parite_secim%type;
     ln_alis_kuru               cbs_arbitraj_islem.alis_kuru%type;
     ln_satis_kuru              cbs_arbitraj_islem.satis_kuru%type;
     ln_alis_tutari             cbs_arbitraj_islem.alis_tutari%type;
     ln_satis_tutari            cbs_arbitraj_islem.satis_tutari%type;
     ln_alis_hesap_no           cbs_arbitraj_islem.alis_hesap_no%type;
     ln_satis_hesap_no          cbs_arbitraj_islem.satis_hesap_no%type;
     ls_name_surname            cbs_arbitraj_islem.name_surname%type;
     ls_aciklama                cbs_arbitraj_islem.aciklama%type;
     ls_istatistik_kodu_alis    cbs_arbitraj_islem.istatistik_kodu_alis%type;
     ls_istatistik_kodu_satis   cbs_arbitraj_islem.istatistik_kodu_satis%type;     
     ln_related_account         cbs_hesap_kredi.iliskili_hesap_no%type;
     ls_to_related_currency     cbs_hesap.doviz_kodu%type;
     ln_related_acc_count       number;     
     ln_account_no              cbs_hesap.hesap_no%type;
     ln_currency                cbs_hesap.doviz_kodu%type;
     ln_account_count           number; 
     ln_parity                  cbs_arbitraj_islem.parite%type;
     ls_carp_bol_secimi         cbs_arbitraj_islem.carp_bol_secimi%type;
     lb_buy_loan_currency       boolean := false;
     lb_bought_amount           boolean := false;
     ln_satis_hesap_avail_bal   number;
     ln_fis_no                  number;   
     ln_kredi_transfer_log_no   number;
     ls_mesaj                   varchar2(2000):= '';
     ls_islem_tipi              varchar2(100):='ARBITRAGE';
     ld_banka_tarihi            date    :=Pkg_Muhasebe.Banka_Tarihi_Bul;
     ln_fis_msg_kuru            number ;
begin

    ln_related_account      :=  pn_to_related_account;
    ls_account_currency     :=  pkg_hesap.HesaptanDovizKoduAl(pn_from_account);
    ln_musteri_no           :=  pkg_hesap.HesaptanMusteriNoAl(pn_from_account);
    ls_account_branch       :=  pkg_hesap.HesapSubeAl(pn_from_account);
    ls_name_surname            := trim(upper(pkg_hesap.hesapkisaisimal(pn_from_account)));   -- seval.colak 29112022
    if ls_name_surname is null then 
        ls_name_surname              := substr(trim(upper(pkg_musteri.sf_musteri_adi(  ln_musteri_no))),1,30);
    end if;
    
    ls_to_related_currency     :=  pkg_hesap.HesaptanDovizKoduAl(pn_to_related_account);
    ls_kredi_doviz_kodu := ls_to_related_currency; 
  --  ls_aciklama := pkg_genel.islem_adi_al(ln_islem_kod) ||' from '|| pn_from_account || ' to ' || pn_to_related_account || ' for Loan Repayment ';-- || pn_kredi_hesap_no;
    
    ln_satis_tutari := pn_amount ; 
    ln_bakiye := TRUNC( tahsilat_hesap_bakiye_al(pn_from_account , ls_to_related_currency),2);
    ln_alis_tutari := TRUNC( tahsilat_hesap_bakiye_al(pn_from_account , ls_account_currency),2); 
    ls_alis_doviz_kodu :=  ls_account_currency ;
    
    ln_kredi_transfer_log_no := pkg_genel.genel_kod_al('KREDI_TRANSFER_LOGNO');

    if pn_to_related_account is not null and pn_to_related_account <> pn_from_account and TRUNC(pn_amount,2) > 0 and  TRUNC(ln_bakiye,2) > 0 and ls_to_related_currency <> ls_account_currency  and ls_kredi_doviz_kodu = ls_to_related_currency  then
             ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,ls_account_branch); 
             ls_modul_tur_kod := 'CURR.OPS.';
             ls_urun_tur_kod := 'ACC-ACC';
             
              if ln_bakiye >= pn_amount then 
                ln_satis_tutari := pn_amount ;                
             else
               ln_satis_tutari := ln_bakiye ;               
             end if;   
       if ls_to_related_currency = PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-LC';
                ls_alis_doviz_kodu := ls_account_currency;
               -- ln_satis_tutari := pn_amount; 
                ln_alis_hesap_no := pn_from_account;
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_to_related_currency;
                end if;  
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A');
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S');
                ln_alis_tutari :=  round(( ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2);     
                ln_fis_msg_kuru := ln_alis_kuru;  --seval.colak 17112022         
       elsif ls_to_related_currency <> PKG_GENEL.LC_AL and ls_account_currency = PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'LC-FC';
                ls_alis_doviz_kodu := ls_account_currency;
               -- ln_satis_tutari := pn_amount; 
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_to_related_currency;
                end if;    
                ln_alis_hesap_no := pn_from_account;                
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A');
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S');
                ln_alis_tutari := round((ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2);
                ln_fis_msg_kuru := ln_satis_kuru; --seval.colak 17112022  
                                 
        elsif ls_to_related_currency <> PKG_GENEL.LC_AL and ls_account_currency <> PKG_GENEL.LC_AL then
                ls_urun_sinif_kod := 'FC-FC';
               ls_alis_doviz_kodu := ls_account_currency;
               -- ln_satis_tutari := pn_amount; 
                if ln_related_account is not null then
                    ln_satis_hesap_no := ln_related_account;
                    ls_satis_doviz_kodu := ls_to_related_currency;
                end if;    
                ln_alis_hesap_no := pn_from_account;
                
                ln_alis_kuru := pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','A');
                ln_satis_kuru := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'O','S');
                ln_alis_tutari := round( (ln_satis_tutari * nvl(ln_satis_kuru,0) / nvl(ln_alis_kuru,0)),2);  
                ln_fis_msg_kuru := ln_satis_kuru/ln_alis_kuru;   --seval.colak 17112022             
           end if;  
     
         ls_kur_tipi := 'COMMERCIAL';
         ls_residency_code := pkg_musteri.sf_get_residency_code (ln_musteri_no);
         ls_citizen_code := pkg_musteri.sf_get_citizenship_country(ln_musteri_no);
         ls_tax_number := pkg_musteri.Sf_VergiNo_Al(ln_musteri_no);
         ls_kur_parite_secim := 'K'; --RATE
         
         ls_aciklama := substr('КОНВЕРТАЦИЯ ДЛЯ ПОГАШЕНИЯ КРЕДИТА ('|| pn_kredi_hesap_no || ')- ' || ls_name_surname ||' ПО КУРСУ (' || trim(to_char(ln_fis_msg_kuru,'99999999990.99999')) || ') ',1,150); --seval.colak15112022
            
         ls_istatistik_kodu_alis := '040202';
         ls_istatistik_kodu_satis := '040202';
           
        insert into cbs_arbitraj_islem a 
        (tx_no,urun_tur_kod, urun_sinif_kod, kur_tipi, alis_doviz_kodu, satis_doviz_kodu, residency_code, citizen_code, tax_number, 
         kur_parite_secim, alis_kuru, satis_kuru, alis_tutari, satis_tutari, alis_hesap_no, satis_hesap_no, name_surname, aciklama, istatistik_kodu_alis, istatistik_kodu_satis) values
        (ln_islem_no,
         ls_urun_tur_kod, 
         ls_urun_sinif_kod ,
         ls_kur_tipi ,
         ls_alis_doviz_kodu ,
         ls_satis_doviz_kodu ,
         ls_residency_code ,
         ls_citizen_code ,
         ls_tax_number ,
         ls_kur_parite_secim ,
         ln_alis_kuru ,
         ln_satis_kuru ,
         ln_alis_tutari ,
         ln_satis_tutari ,
         ln_alis_hesap_no ,
         ln_satis_hesap_no ,
         ls_name_surname ,
         ls_aciklama ,
         ls_istatistik_kodu_alis ,
         ls_istatistik_kodu_satis );
          
         pkg_tx1207.muhasebelesme(ln_islem_no);
         ln_fis_no:=  pkg_tx.fis_no(ln_islem_no);
          insert into cbs_rpt_kredi_transfer ( 
                                                    transfer_log_no    ,
                                                    banka_tarihi    ,
                                                    islem_tipi    ,
                                                    musteri_no    ,
                                                    kredi_hesap_no    ,
                                                    tutar    ,
                                                    doviz_kodu,
                                                    from_account,
                                                    to_account,
                                                    from_account_bakiye,
                                                    grup_no    ,
                                                    log_no,
                                                    yaratan_islem_kod,
                                                    yaratan_tx_no,
                                                    muhasebe_fis_no
                                                        )
                                                values (ln_kredi_transfer_log_no,
                                                        ld_banka_tarihi    ,
                                                        ls_islem_tipi   ,
                                                        ln_musteri_no    ,
                                                        pn_kredi_hesap_no   ,
                                                        ln_alis_tutari,
                                                        ls_kredi_doviz_kodu    ,
                                                        pn_from_account   ,
                                                        pn_to_related_account  ,
                                                        ln_bakiye,
                                                        pn_grup_no    ,
                                                        pn_log_no,
                                                        ln_islem_kod,
                                                        ln_islem_no,
                                                        ln_fis_no
                                                        );
               
                pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,pkg_hata.generatemessage(pkg_hata.getucpointer || '6825' || pkg_hata.getdelimiter || to_char(pn_from_account) || pkg_hata.getdelimiter || to_char(ln_fis_no) || pkg_hata.getdelimiter || pkg_hata.getucpointer) ,ln_islem_no );             
        end if;
                          
 commit;
 Exception
   When others then
         rollback;
          ls_mesaj := pkg_hata.generatemessage(pkg_hata.getucpointer || '6824' || pkg_hata.getdelimiter || to_char(pn_from_account) || pkg_hata.getdelimiter || to_char(ln_fis_no) || pkg_hata.getdelimiter ||  to_char(sqlcode)|| ' ' ||sqlerrm  || pkg_hata.getdelimiter || pkg_hata.getucpointer) ;
          pkg_batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_mesaj ,ln_islem_no);
          sp_insert_cbsrptkreditahsilat(pn_grup_no,pn_log_no,pn_kredi_hesap_no,ls_mesaj,ln_islem_kod,ln_kredi_transfer_log_no,ls_islem_tipi,0,ln_islem_no,ln_fis_no);
end;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE TRANSFER_ARBITRAGE(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is
  ld_banka_tarihi                 DATE :=Pkg_Muhasebe.Banka_Tarihi_Bul;
  ld_sonraki_banka_tarihi         DATE :=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
  ld_onceki_banka_tarihi          DATE :=Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;    
  ln_kredi_tahsilat_log_no        number;  
  ln_islem_no                     number;
  ln_fis_no                       number;
  ln_kalan_tahsil_edilecek_tutar  number := 0;     
  ln_iliskili_hesap_no            number;    
  ls_iliskili_hesap_doviz         varchar2(3); 
  ln_musteri_no                   number;
  ln_sales_tax_rate               number ;                    
 
   cursor cur_hesap is
     SELECT 
            -- islem_tipi,
             musteri_no       musteri_no,
             iliskili_hesap_no,
             pkg_hesap.hesaptandovizkodual(iliskili_hesap_no) iliskili_hesap_doviz,
             sum( nvl(tahsil_edilecek_tutar,0) )    tahsil_edilecek_tutar,
             min(kredi_hesap_no) kredi_hesap_no --seval.colak 17112022
             from (
   
                 select 'TAKSITLI-BAKIYE-YETERSIZ' islem_tipi,
                         a.musteri_no       musteri_no,
                         a.hesap_no         kredi_hesap_no,
                         a.doviz_kodu       kredi_doviz_kodu,
                         a.sube_kodu        kredi_sube_kodu,
                         a.iliskili_hesap_no,
                       --  pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
                          sum( abs( nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)) +  
                                 abs( nvl(b.faiz,0)-nvl(b.tahsil_faiz,0)) +
                                 abs( nvl(b.bsmv,0)-nvl(b.tahsil_bsmv,0)) +                      
                                 abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) +
                                 abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) +  
                                 abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) +
                                 abs(round((  abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0))* nvl(ln_sales_tax_rate,0) /100),2 )) +     --seval.colak 27042022 tahsil_deferred_penalty_tax
                                 abs( nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) +
                                 abs( nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0)) + --seval.colak 17122021
                                -- abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) +  --seval.colak 29082022 artik kullanilmayacak 
                                 abs(round((  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))* nvl(ln_sales_tax_rate,0) /100),2 )) + 
                                 abs(round((  case when abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) > 0 then  abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))+
                                 abs(round(( case when abs( nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > case when pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) end then  abs( nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0))- case when pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) end else  0 end * nvl(ln_sales_tax_rate,0) /100),2 ))  +-- nonaccrual_tahsil_deferred_interest_tax, --seval.colak 28042022  
                                 abs(round((  case when abs( nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > case when pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) end then  abs( nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0))- case when pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) end else  0 end * nvl(ln_sales_tax_rate,0) /100),2 )) + --    nonaccrual_tahsil_deferred_delayed_int_tax  --seval.colak 28042022
                          abs(round(( case when abs( nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > case when pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) end then  case when pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) end else  abs( nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0))    end  * nvl(ln_sales_tax_rate,0) /100),2 )) + -- accrual_tahsil_deferred_interest_tax,  --seval.colak 07062022
        abs(round(( case when abs( nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > case when pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) end then  case when pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) > 0 then 0 else abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) end else  abs( nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0))  end * nvl(ln_sales_tax_rate,0) /100),2 ))  -- accrual_tahsil_deferred_delayed_int_tax,  --seval.colak 07062022
                                 ) tahsil_edilecek_tutar                                      
                 from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
                 where a.hesap_no = b.hesap_no and 
                       a.durum_kodu = 'A' and 
                       b.durum_kodu = 'A' and 
                       b.vade_tarih <=ld_banka_tarihi and
                       pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
                       and a.repayment_type  = 'INSTALLMENT DATE' 
                       and   abs( nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)) +  
                             abs( nvl(b.faiz,0)-nvl(b.tahsil_faiz,0)) +
                             abs( nvl(b.bsmv,0)-nvl(b.tahsil_bsmv,0)) +                      
                             abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) +
                             abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) +  
                             abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) +
                             abs( nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) +
                             abs( nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))  --seval.colak 17122021
                             --- + abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) --seval.colak 29082022  deferred_tax artik kullanilmayacak 
                             
                            > 0 
                             and exists (select 1 from cbs_musteri m where m.musteri_no = a.musteri_no and musteri_tipi_kod in ('1','2') )  --seval.colak 13122021
                             and  a.otomatik_tahsilat = 'E'  --seval.colak 15082022
                             and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment  
                       group by  a.musteri_no  , a.hesap_no ,a.doviz_kodu,  a.sube_kodu,  a.iliskili_hesap_no
                       having  sum ( abs( nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)) +  
                             abs( nvl(b.faiz,0)-nvl(b.tahsil_faiz,0)) +
                             abs( nvl(b.bsmv,0)-nvl(b.tahsil_bsmv,0)) +                      
                             abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) +
                             abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) +  
                             abs( nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) +
                             abs( nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) +
                             abs( nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))  --seval.colak 17122021
                            -- +  abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0))  --seval.colak 29082022  deferred_tax artik kullanilmayacak 
                                 )  >  0
                     union all   
                    select 'TAKSITSIZ-BAKIYE-YETERSIZ' islem_tipi,
                         a.musteri_no          musteri_no    ,
                         a.hesap_no            kredi_hesap_no,
                         a.doviz_kodu          kredi_doviz_kodu,
                         a.sube_kodu           kredi_sube_kodu,
                         a.iliskili_hesap_no ,
                        -- pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
                         case when  a.kredi_vade <= ld_banka_tarihi  then  abs(c.bakiye) else 0 end  +---  ANAPARA ALINMALI 
                         case  when  a.faiz_tahakkuk_tarihi >  ld_onceki_banka_tarihi and a.faiz_tahakkuk_tarihi <= ld_banka_tarihi then 
                                   abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no))  + abs(round(nvl(a.gecmis_aylarin_faizi,0),2))     + abs(round(nvl(a.gecenyil_faiz_tutari,0),2)) +  abs(round(nvl(birikmis_faiz_tutari,0),2))  
                                                + abs(round(nvl(a.gecmis_aylarin_komisyonu,0),2)) + abs(round(nvl(a.gecenyil_komisyon_tutari,0),2)) + abs(round(nvl(birikmis_komisyon_tutari,0),2))
                                                + abs(round(nvl(a.birikmis_gecikme_faiz_tutari,0),2)) + abs(round(nvl(a.gecenyil_gecikme_faiz ,0),2)) + abs(round(nvl(a.gecenay_gecikme_faiz ,0),2)) + 
                                                + abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  --  faiz_tahakkuk_tutar,
                                                + abs(pkg_odeme_plan.sf_pastdue_tax_total(a.hesap_no)) + abs(round(( NVL(birikmis_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))   --tahsil_edilecek_Tutar -- vergi_tahakkuk_tutar,
                                                + case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end 
                                                + abs(round((  case when abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) > 0 then  abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))                                                                                   
                                                  
                        else
                             abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) + abs(pkg_odeme_plan.sf_pastdue_tax_total(a.hesap_no)) +
                             abs(round(nvl(a.gecenyil_gecikme_faiz ,0),2)) + abs(round(nvl(a.gecenay_gecikme_faiz ,0),2)) + 
                            +  abs(round(nvl(a.birikmis_gecikme_faiz_tutari,0),2)) + abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  +
                             + case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end 
                             + abs(round((  case when abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) > 0 then  abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))                                                                                   
                        end tahsil_edilecek_tutar                        
                  from cbs_hesap_kredi a ,cbs_hesap_bakiye c
                 where a.hesap_no = c.hesap_no and 
                       a.durum_kodu = 'A' and 
                       pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'  
                       and  nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' 
                       and  case when  a.kredi_vade <= ld_banka_tarihi  then  abs(c.bakiye) else 0 end  +---  ANAPARA ALINMALI 
                         case  when  a.faiz_tahakkuk_tarihi >  ld_onceki_banka_tarihi and a.faiz_tahakkuk_tarihi <= ld_banka_tarihi then 
                                                                                 abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no))  + abs(round(nvl(a.gecmis_aylarin_faizi,0),2))     + abs(round(nvl(a.gecenyil_faiz_tutari,0),2)) +  abs(round(nvl(birikmis_faiz_tutari,0),2))  
                                                                                  + abs(round(nvl(a.gecmis_aylarin_komisyonu,0),2)) + abs(round(nvl(a.gecenyil_komisyon_tutari,0),2)) + abs(round(nvl(birikmis_komisyon_tutari,0),2))
                                                                                  + abs(round(nvl(a.birikmis_gecikme_faiz_tutari,0),2)) + abs(round(nvl(a.gecenyil_gecikme_faiz ,0),2)) + abs(round(nvl(a.gecenay_gecikme_faiz ,0),2)) + 
                                                                                  + abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  --  faiz_tahakkuk_tutar,
                                                                                  + case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end 
                                                                                  + abs(round((  case when abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) > 0 then  abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))                                                                                   
                                                 --tahsil_edilecek_Tutar -- vergi_tahakkuk_tutar,
                        else
                             abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) + abs(pkg_odeme_plan.sf_pastdue_tax_total(a.hesap_no)) +
                             abs(round(nvl(a.gecenyil_gecikme_faiz ,0),2)) + abs(round(nvl(a.gecenay_gecikme_faiz ,0),2)) + 
                            +  abs(round(nvl(a.birikmis_gecikme_faiz_tutari,0),2))  
                            + case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end 
                           + abs(round((  case when abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) > 0 then  abs( nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))                                                                                   
                        end  > 0--tahsil_edilecek_tutar > 0  
                       and exists (select 1 from cbs_musteri m where m.musteri_no = a.musteri_no and musteri_tipi_kod in ('1','2') )  --seval.colak 13122021
                       and  a.otomatik_tahsilat = 'E'  --seval.colak 15082022
                       and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment  
                      order by kredi_hesap_no ) D
            where not exists(select 1 from cbs_rpt_kredi_transfer where BANKA_TARIHI = pkg_muhasebe.banka_tarihi_bul and from_account =d.iliskili_hesap_no)  --seval.colak 05052022 birden falz kredisi olanlarda iliskili hesapdan digerine 2 kere gereksiz transfer yapmayi onleme amacli.             
          GROUP BY   --    islem_tipi,
                         musteri_no ,  
                         iliskili_hesap_no,
                         pkg_hesap.hesaptandovizkodual(iliskili_hesap_no) 
          having sum(tahsil_edilecek_tutar) > nvl(pkg_hesap.kullanilabilir_bakiye_al(iliskili_hesap_no),0)  ;  
  
  cursor cur_hesap_tahsilat is
  select  a.hesap_no, 
          a.sube_kodu, 
          a.doviz_kodu,           
          pkg_kredi_tahsilat.tahsilat_hesap_bakiye_al(a.hesap_no , ls_iliskili_hesap_doviz ) tahsilat_hesap_bakiye
       from cbs_hesap  a
       where a.musteri_no = ln_musteri_no and 
             a.durum_kodu = 'A'  and
             a.hesap_no <>  ln_iliskili_hesap_no and 
             pkg_hesap.kullanilabilir_bakiye_al(a.hesap_no) >0 and  
             a.hesap_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where status = 'ACTIVE' and nvl(ortaklik_tipi, 'XX') <>'OY') and 
             a.urun_tur_kod not in (  'SWAP','SWAP-FW' ,'SPOT','FORWARD','CASH COLL.') --seval.colak 18012023
             and a.urun_tur_kod in ('CURRENT','DEMAND DEP' ) --seval.colak 18012023
             and a.urun_tur_kod not like '%CARD%'
             and a.urun_sinif_kod not like '%CARD%'
             and a.urun_sinif_kod not in ('OVERBALANCE-LC','OVERBALANCE-FC')
             and  exists (select 1 from cbs_hesap_bakiye c where c.hesap_no  =a.hesap_no and bakiye_karakteri ='P')
         order by  pkg_kredi_tahsilat.tahsilat_hesap_bakiye_al(a.hesap_no , ls_iliskili_hesap_doviz ) desc;
                   
  BEGIN
    
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 
    
    for c_hesap in cur_hesap loop          
            ln_kalan_tahsil_edilecek_tutar :=  nvl(c_hesap.tahsil_edilecek_tutar,0) - nvl(pkg_hesap.kullanilabilir_bakiye_al( c_hesap.iliskili_hesap_no),0);
            ln_iliskili_hesap_no := c_hesap.iliskili_hesap_no;
            ls_iliskili_hesap_doviz := c_hesap.iliskili_hesap_doviz;
            ln_musteri_no := c_hesap.musteri_no;
              
               if nvl(ln_kalan_tahsil_edilecek_tutar,0) > 0 then
                     for c_hesap_tahsilat in cur_hesap_tahsilat loop
                                -- onemli not :  pkg_hesap.kullanilabilir_bakiye_al( c_hesap.iliskili_hesap_no) altta her zaman kullanilabilir bakiye cagrilir.nedeni. virman(transfer) veya arbitraj muhasebe  fis sonrasi guncel bakiyesi alinmis olmali.      
                            ln_kalan_tahsil_edilecek_tutar := trunc(nvl(c_hesap.tahsil_edilecek_tutar,0),2) - nvl(pkg_hesap.kullanilabilir_bakiye_al( c_hesap.iliskili_hesap_no),0) ;
                                if nvl(ln_kalan_tahsil_edilecek_tutar,0) > 0 then  
                                    if ls_iliskili_hesap_doviz = c_hesap_tahsilat.doviz_kodu then 
                                        --virman 
                                                     tahsilat_transfer  (   pn_grup_no , 
                                                                             pn_log_no ,
                                                                            'TRANSFER' ,                       
                                                                              c_hesap.kredi_hesap_no ,  -- seval.colak 17112022 min loan acctno will be passed 0> c_hesap.kredi_hesap_no
                                                                              c_hesap_tahsilat.hesap_no ,
                                                                              ln_iliskili_hesap_no ,  
                                                                              ln_kalan_tahsil_edilecek_tutar ,  
                                                                              ln_islem_no );
                                                     else
                                                        tahsilat_arbitrage  (   pn_grup_no , 
                                                                             pn_log_no ,
                                                                            'ARBITRAGE' ,                       
                                                                              c_hesap.kredi_hesap_no , -- seval.colak 17112022 min loan acctno will be passed 0> c_hesap.kredi_hesap_no
                                                                              c_hesap_tahsilat.hesap_no ,
                                                                              ln_iliskili_hesap_no ,  
                                                                              ln_kalan_tahsil_edilecek_tutar ,  
                                                                              ln_islem_no );   
                                         
                                         end if; 
                               end if;                              
                                                               
                     end loop;
               end if;
          end loop; 
     commit;

   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
procedure TAHSILAT_HESAP(           pn_grup_no                              number, 
                                    pn_log_no                               number,
                                    ps_program_kod                          varchar2 ,                                    
                                    pn_islem_kod                            number  default 1323, 
                                    ps_tahsilat_islem_tipi                  varchar2 ,
                                    ps_repayment_type                       varchar2,
                                    ps_sube_kodu                            varchar2,
                                    pn_musteri_no                           number,                                 
                                    pn_kredi_hesap_no                       number ,
                                    pn_taksit_no                            number  default  0,
                                    pn_islem_no                             out number,
                                    pn_fis_no                               out number,
                                    pn_tahsilat_no                          out number,
                                    pd_vade_tarihi                          date default  null, 
                                    pd_faiz_tahakkuk_tarihi                 date  default  null,
                                    pn_kredi_Bakiye                         number default  null,
                                    ps_kredi_doviz_kodu                     varchar2 default  null,
                                    pn_iliskili_hesap_no                    number default  null, 
                                    ps_iliskili_hesap_doviz                 varchar2 default  null,
                                    pn_iliskili_hesap_bakiye                number default 0,
                                    pn_taksit_tutar                         number default 0    ,
                                    pn_taksit_tahsil_tutar                  number default 0,
                                    pn_tahsil_TOPLAM                        number default 0, 
                                    pn_tahsil_anapara                       number default 0,  
                                    pn_tahsil_faiz                          number default 0,                                                          
                                    pn_tahsil_vergi                         number default 0,                                              
                                    pn_tahsil_birikmis_gecikme_faiz         number default 0, 
                                    pn_tahsil_penalty_amount                number default 0, 
                                    pn_tahsil_penalty_tax                   number default 0,
                                    pn_tahsil_deferred_penalty_tax          number default 0,  --seval.colak 27042022                                              
                                    pn_tahsil_deferred_penalty_amount       number default 0,        
                                    pn_tahsil_deferred_interest             number default 0, 
                                    pn_tahsil_deferred_tax                  number default 0, 
                                    pn_tahsil_gecenyil_faiz                 number default 0, 
                                    pn_tahsil_gecmis_aylar_faiz             number default 0, 
                                    pn_tahsil_birikmis_faiz                 number default 0, 
                                    pn_tahsil_gecenyil_komisyon             number default 0, 
                                    pn_tahsil_gecmis_aylar_komisyon         number default 0, 
                                    pn_tahsil_birikmis_komisyon             number default 0, 
                                    pn_tahsil_gecenyil_gecikme_faiz         number default 0, 
                                    pn_tahsil_gecenay_gecikme_faiz          number default 0, 
                                    pn_tahsil_gecikme_faiz_tax              number default 0,
                                    pn_tahsil_vergi_fark                     number default 0,
                                    ps_tahakkuk_eh                              varchar2 default  null,
                                    ps_taksitli_mi                              varchar2 default  null,  
                                    pn_hesaplanan_anapara                       number default 0,  
                                    pn_hesaplanan_faiz                          number default 0,                                                          
                                    pn_hesaplanan_vergi                         number default 0,                                              
                                    pn_hesaplanan_birikmis_gecikme_faiz         number default 0, 
                                    pn_hesaplanan_penalty_amount                number default 0,          
                                    pn_hesaplanan_penalty_tax                   number default 0,
                                    pn_hesaplanan_deferred_penalty_tax          number default 0, --seval.colak 27042022
                                    pn_hesaplanan_deferred_penalty_amount       number default 0,        
                                    pn_hesaplanan_deferred_interest             number default 0, 
                                    pn_hesaplanan_deferred_tax                  number default 0, 
                                    pn_hesaplanan_gecenyil_faiz                 number default 0, 
                                    pn_hesaplanan_gecmis_aylar_faiz             number default 0, 
                                    pn_hesaplanan_birikmis_faiz                 number default 0, 
                                    pn_hesaplanan_gecenyil_komisyon             number default 0, 
                                    pn_hesaplanan_gecmis_aylar_komisyon         number default 0, 
                                    pn_hesaplanan_birikmis_komisyon             number default 0, 
                                    pn_hesaplanan_gecenyil_gecikme_faiz         number default 0, 
                                    pn_hesaplanan_gecenay_gecikme_faiz          number default 0, 
                                   -- pn_hesaplanan_gecikme_faiz_accruedtax       number default 0, 
                                   -- pn_hesaplanan_accrued_interest_tax          number default 0, 
                                    pn_hesaplanan_gecikme_faiz_tax              number default 0,
                                    pn_hesaplanan_toplam                        number default 0,
                                    pn_kalan_tahsil_tutar                       number default 0 ,
                                    --seval.colak 09122021
                                     pn_accrual_tahsil_Faiz                 number default 0 ,
                                     pn_nonaccrual_tahsil_faiz              number default 0 ,
                                     pn_accrual_tahsil_vergi                number default 0 ,
                                     pn_nonaccrual_tahsil_vergi             number default 0 ,
                                     pn_hspln_accrual_tahsil_Faiz           number default 0 ,
                                     pn_hspln_nonaccrual_tahsil_faiz        number default 0 ,
                                     pn_hspln_accrual_tahsil_vergi          number default 0 ,
                                     pn_hspln_nonaccrual_tahsil_vergi       number default 0 ,
                                     --seval.colak 16122021      
                                     pn_accrual_tahsil_gecikme_faiz     number default 0 ,
                                     pn_nonaccrual_tahsil_gecikme_faiz  number default 0 ,
                                     pn_hspln_accrual_tahsil_gecikme_faiz  number default 0 ,
                                     pn_hspln_nonaccrual_tahsil_gecikme_faiz number default 0 ,
                                     pn_accrual_tahsil_gecikme_faiz_tax     number default 0 ,
                                     pn_nonaccrual_tahsil_gecikme_faiz_tax  number default 0 ,
                                     pn_hspln_accrual_tahsil_gecikme_faiz_tax  number default 0 ,
                                     pn_hspln_nonaccrual_tahsil_gecikme_faiz_tax number default 0,
                                     --seval.colak 17122021
                                    pn_tahsil_deferred_delayed_interest    number default 0 ,   
                                    pn_hspln_deferred_delayed_interest    number default 0 ,   
                                    pn_tahsil_accrual_deferred_interest    number default 0 ,   
                                    pn_hspln_accrual_deferred_interest    number default 0 ,   
                                    pn_tahsil_nonaccrual_deferred_interest    number default 0 ,   
                                    pn_hspln_nonaccrual_deferred_interest    number default 0 ,   
                                    pn_tahsil_accrual_deferred_delayed_interest    number default 0 ,   
                                    pn_hspln_accrual_deferred_delayed_interest    number default 0 ,   
                                    pn_tahsil_nonaccrual_deferred_delayed_interest    number default 0 ,   
                                    pn_hspln_nonaccrual_deferred_delayed_interest    number default 0 ,   
                                     --seval.colak 17122021
                                     --seval.colak 28042022
                                     pn_tahsil_nonaccrual_deferred_tax    number default 0 ,   
                                     pn_hspln_nonaccrual_deferred_tax    number default 0  ,
                                     pn_tahsil_nonaccrual_deferred_delay_tax    number default 0 ,   
                                     pn_hspln_nonaccrual_deferred_delay_tax    number default 0   ,                                  
                                    --seval.colak 28042022
                                    --seval.colak 07062022
                                     pn_tahsil_accrual_deferred_tax    number default 0 ,   
                                     pn_hspln_accrual_deferred_tax    number default 0  ,
                                     pn_tahsil_accrual_deferred_delay_tax    number default 0 ,   
                                     pn_hspln_accrual_deferred_delay_tax    number default 0                                      
                                    --seval.colak 07062022
                                     
                                 )          
                                 
is pragma autonomous_transaction;
   ld_banka_tarihi          date   := pkg_muhasebe.banka_tarihi_bul;
   ln_islem_no              number ;
   ls_mesaj                 varchar2(2000):= '';
   ls_aciklama              varchar2(200);
   ls_hata_var              varchar2(1) := 'H';
   ln_tahsilat_log_no       number;
   ls_taksit_durum          cbs_hesap_kredi_Taksit.durum_kodu%type;
   ln_taksit_toplam         number := 0 ;     
   ln_tahsil_faiz           number := 0 ;
   ln_tahsil_vergi          number := 0 ;
   ln_tahakkuk_no           number;
   ln_kalan_tahsil_faiz     number := 0 ;
   ln_kalan_tahsil_vergi    number := 0 ;
 
begin   
        ln_islem_no   := pkg_batch.islem_yarat(pn_islem_kod ,ps_sube_kodu); 
        ls_aciklama   := pkg_genel.islem_adi_al(pn_islem_kod) ;
        pn_islem_no    := ln_islem_no;
        Pkg_Kredi.sp_kredihesap_isleme_at  ( pn_kredi_hesap_no,
                                             ln_islem_no,
                                             pn_islem_kod);
        update cbs_hesap_kredi_islem
        set         valor_tarihi = ld_banka_tarihi, 
                    sube_kodu   = ps_sube_kodu ,
                    kur = pkg_kur.doviz_doviz_karsilik(ps_kredi_doviz_kodu, pkg_genel.lc_al,null,1,1,null,null,'O','A'), 
                    iliskili_hesap_no = pn_iliskili_hesap_no, 
                    tahsil_hesap_no =   pn_iliskili_hesap_no, 
                    tahsil_hesap_doviz  = ps_iliskili_hesap_doviz,
                    anapara_tahsilat_tutar = pn_tahsil_anapara,               
                    aciklama = ls_aciklama,
                    geriodeme_kapama_secimi = 'GERI ODEME',
                    toplam_tahsil =  pn_tahsil_toplam,                    
                    toplam_tahsiledilecek_tutar       =     pn_tahsil_toplam,
                    tahsiledilecek_tahakkuk_faiz      =     pn_tahsil_faiz,
                    tahsiledilen_faiz_tutari          =     pn_tahsil_faiz, -- seval.colak 26042022
                    tahsiledilecek_tahakkuk_vergi     =     pn_tahsil_vergi,
                    tahsedil_gecenyil_faiz_tutari     =     pn_tahsil_gecenyil_faiz,
                    tahsedil_gecmis_aylar_faiz        =     pn_tahsil_gecmis_aylar_faiz,                                       
                    tahsil_anapara                    =     pn_tahsil_anapara,
                    tahsil_faiz                       =     pn_tahsil_faiz,
                    tahsil_vergi                      =     pn_tahsil_vergi,
                    tahsil_birikmis_gecikme_faiz      =     pn_tahsil_birikmis_gecikme_faiz,
                    tahsil_penalty_amount             =     pn_tahsil_penalty_amount,
                    tahsil_penalty_tax                =     pn_tahsil_penalty_tax,
                    tahsil_deferred_penalty_tax       =     pn_tahsil_deferred_penalty_tax,--seval.colak 27042022
                    tahsil_deferred_penalty_amount    =     pn_tahsil_deferred_penalty_amount,
                    tahsil_deferred_interest          =     pn_tahsil_deferred_interest,
                    tahsil_deferred_tax               =     pn_tahsil_deferred_tax,
                    tahsil_gecenyil_faiz              =     pn_tahsil_gecenyil_faiz,
                    tahsil_gecmis_aylar_faiz          =     pn_tahsil_gecmis_aylar_faiz,
                    tahsil_birikmis_faiz              =     pn_tahsil_birikmis_faiz,
                    tahsil_gecenyil_komisyon          =     pn_tahsil_gecenyil_komisyon,
                    tahsil_gecmis_aylar_komisyon      =     pn_tahsil_gecmis_aylar_komisyon,
                    tahsil_birikmis_komisyon          =     pn_tahsil_birikmis_komisyon,
                    tahsil_gecenyil_gecikme_faiz      =     pn_tahsil_gecenyil_gecikme_faiz,
                    tahsil_gecenay_gecikme_faiz       =     pn_tahsil_gecenay_gecikme_faiz,
                    tahsil_gecikme_faiz_tax           =     pn_tahsil_gecikme_faiz_tax,
                    tahsil_vergi_fark                 =     pn_tahsil_vergi_fark,
                    tahsil_taksit_no                  =     pn_taksit_no ,
                    tahsil_islem_tipi                 =     ps_tahsilat_islem_tipi  ,
                    --seval.colak 09122021
                    accrual_tahsil_faiz              =  pn_accrual_tahsil_faiz ,
                    nonaccrual_tahsil_faiz           =  pn_nonaccrual_tahsil_faiz ,
                    accrual_tahsil_vergi             =  pn_accrual_tahsil_vergi,
                    nonaccrual_tahsil_vergi          =  pn_nonaccrual_tahsil_vergi ,    
                    --seval.colak 09122021       
                    --seval.colak 16122021
                    accrual_tahsil_gecikme_faiz       =  pn_accrual_tahsil_gecikme_faiz ,
                    nonaccrual_tahsil_gecikme_faiz    =  pn_nonaccrual_tahsil_gecikme_faiz,
                    accrual_tahsil_gecikme_faiz_tax       =  pn_accrual_tahsil_gecikme_faiz_tax ,
                    nonaccrual_tahsil_gecikme_faiz_tax    =  pn_nonaccrual_tahsil_gecikme_faiz_tax ,
                    --seval.colak 16122021          
                    
                    --seval.colak 17122021
                    tahsil_deferred_delayed_interest    =   pn_tahsil_deferred_delayed_interest, 
                    accrual_tahsil_deferred_interest    =   pn_tahsil_accrual_deferred_interest,  
                    nonaccrual_tahsil_deferred_interest =   pn_tahsil_nonaccrual_deferred_interest,
                    accrual_tahsil_deferred_delayed_int =   pn_tahsil_accrual_deferred_delayed_interest,
                    nonaccrual_tahsil_deferred_delayed_int = pn_tahsil_nonaccrual_deferred_delayed_interest,
                    --seval.colak 17122021
                    --seval.colak 28042022
                     tahsil_nonaccrual_deferred_tax = pn_tahsil_nonaccrual_deferred_tax   ,  
                     tahsil_nonaccrual_deferred_delay_tax= pn_tahsil_nonaccrual_deferred_delay_tax ,  
                     --seval.colak 28042022      
                      --seval.colak 07062022
                     tahsil_accrual_deferred_tax = pn_tahsil_accrual_deferred_tax   ,  
                     tahsil_accrual_deferred_delay_tax= pn_tahsil_accrual_deferred_delay_tax   
                     --seval.colak 07062022                                   
         where tx_no = ln_islem_no;  
         
         update cbs_hesap_kredi_taksit_islem
         set   tahsil_anapara = nvl(tahsil_anapara,0) + nvl(pn_tahsil_anapara,0),
               tahsil_faiz = nvl(tahsil_faiz,0) + nvl(pn_tahsil_faiz,0),
               tahsil_bsmv = nvl(tahsil_bsmv,0) + nvl(pn_tahsil_vergi,0),
               tahsil_gecikme_faiz_tutari =  nvl(tahsil_gecikme_faiz_tutari,0) + nvl(pn_tahsil_birikmis_gecikme_faiz,0),
               paid_penalty_amount =  nvl(paid_penalty_amount,0) + nvl(pn_tahsil_penalty_amount,0),
               paid_deferred_penalty_amount =  nvl(paid_deferred_penalty_amount,0) + nvl(pn_tahsil_deferred_penalty_amount,0),  
               paid_deferred_penalty_tax =  nvl(paid_deferred_penalty_tax,0) + nvl(pn_tahsil_deferred_penalty_tax,0), --seval.colak 27042022
               paid_deferred_interest =  nvl(paid_deferred_interest,0) + nvl(pn_tahsil_deferred_interest,0),
               paid_deferred_delayed_interest =  nvl(paid_deferred_delayed_interest,0) + nvl(pn_tahsil_deferred_delayed_interest,0), --seval.colak 17122021  
               paid_deferred_tax =  nvl(paid_deferred_interest,0) + nvl(pn_tahsil_deferred_tax,0),  --seval.colak 27042022
               paid_nonaccrual_deferred_tax =  nvl(paid_nonaccrual_deferred_tax,0) + nvl(pn_tahsil_nonaccrual_deferred_tax,0) , --seval.colak 28042022                   
               paid_nonaccrual_deferred_delay_tax =  nvl(paid_nonaccrual_deferred_delay_tax,0) + nvl(pn_tahsil_nonaccrual_deferred_delay_tax,0),  --seval.colak 28042022
               paid_accrual_deferred_tax =  nvl(paid_accrual_deferred_tax,0) + nvl(pn_tahsil_accrual_deferred_tax,0) , --seval.colak 07062022                   
               paid_accrual_deferred_delay_tax =  nvl(paid_accrual_deferred_delay_tax,0) + nvl(pn_tahsil_accrual_deferred_delay_tax,0)  --seval.colak 07062022
         where tx_no = pn_islem_no and sira_no = nvl(pn_taksit_no,0) ;

         update cbs_hesap_kredi_taksit_islem
            set tahsil_taksit =  nvl(tahsil_anapara,0) +nvl(tahsil_faiz,0) + nvl(tahsil_bsmv,0) +
              nvl(paid_deferred_interest,0) +  nvl(paid_deferred_tax,0) +  nvl(paid_deferred_penalty_amount,0)+ nvl(paid_deferred_delayed_interest,0) --seval.colak 14022023
         where tx_no = pn_islem_no and sira_no = nvl(pn_taksit_no,0) ;
         
        pkg_tx1323.muhasebelesme(ln_islem_no);
        
        pn_fis_no:=  pkg_tx.fis_no(ln_islem_no);
        ln_tahsilat_log_no := pkg_genel.genel_kod_al('KREDI_TAHSILAT_NO');
        pn_tahsilat_no :=ln_tahsilat_log_no;
        insert into cbs_rpt_kredi_tahsilat (        tahsilat_log_no    ,
                                                    banka_tarihi    ,
                                                    islem_tipi    ,
                                                    musteri_no    ,
                                                    kredi_hesap_no    ,
                                                    kredi_doviz_kodu    ,
                                                    taksit_no    ,
                                                    vade_tarihi,
                                                    faiz_tahakkuk_tarihi,
                                                    kredi_bakiye    ,
                                                    iliskili_hesap_no    ,
                                                    iliskili_hesap_bakiye    ,
                                                    iliskili_hesap_doviz_kodu    ,
                                                    taksit_tutar    ,
                                                    taksit_tahsil_tutar    ,
                                                    tahsil_TOPLAM,  
                                                    --
                                                    tahsil_anapara,
                                                    tahsil_faiz,
                                                    tahsil_vergi,
                                                    tahsil_birikmis_gecikme_faiz    ,
                                                    tahsil_penalty_amount    ,
                                                    tahsil_penalty_tax,
                                                    tahsil_deferred_penalty_tax, --seval.colak 27042022
                                                    tahsil_deferred_penalty_amount    ,
                                                    tahsil_deferred_interest    ,
                                                    tahsil_deferred_tax    ,
                                                    tahsil_gecenyil_faiz    ,
                                                    tahsil_gecmis_aylar_faiz    ,
                                                    tahsil_birikmis_faiz    ,
                                                    tahsil_gecenyil_komisyon    ,
                                                    tahsil_gecmis_aylar_komisyon    ,
                                                    tahsil_birikmis_komisyon    ,
                                                    tahsil_gecenyil_gecikme_faiz    ,
                                                    tahsil_gecenay_gecikme_faiz    ,
                                                    tahsil_gecikme_faiz_tax,
                                                    tahsil_vergi_fark,
                                                    tahakkuk_eh,
                                                    taksitli_mi,
                                                    --
                                                    hesaplanan_anapara                       ,  
                                                    hesaplanan_faiz                          ,                                                          
                                                    hesaplanan_vergi                         ,                                              
                                                    hesaplanan_birikmis_gecikme_faiz         , 
                                                    hesaplanan_penalty_amount                ,
                                                    hesaplanan_penalty_tax ,            
                                                    hesaplanan_deferred_penalty_tax,        --seval.colak 27042022
                                                    hesaplanan_deferred_penalty_amount       ,        
                                                    hesaplanan_deferred_interest             ,
                                                     hesaplanan_deferred_tax                  , 
                                                    hesaplanan_gecenyil_faiz                 , 
                                                    hesaplanan_gecmis_aylar_faiz             , 
                                                    hesaplanan_birikmis_faiz                 , 
                                                    hesaplanan_gecenyil_komisyon             , 
                                                    hesaplanan_gecmis_aylar_komisyon         , 
                                                    hesaplanan_birikmis_komisyon             , 
                                                    hesaplanan_gecenyil_gecikme_faiz         , 
                                                    hesaplanan_gecenay_gecikme_faiz          , 
                                                    hesaplanan_gecikme_faiz_tax              ,
                                                    hesaplanan_toplam                        ,
                                                    kalan_tahsil_tutar,
                                                    --
                                                    grup_no    ,
                                                    log_no,
                                                    yaratan_islem_kod,
                                                    yaratan_tx_no,
                                                    muhasebe_fis_no,
                                                    --seval.colak 09122021
                                                    accrual_tahsil_faiz,
                                                    nonaccrual_tahsil_faiz,
                                                    accrual_tahsil_vergi,
                                                    nonaccrual_tahsil_vergi,
                                                    hspln_accrual_tahsil_faiz,
                                                    hspln_nonaccrual_tahsil_faiz,
                                                    hspln_accrual_tahsil_vergi,
                                                    hspln_nonaccrual_tahsil_vergi,
                                                    --seval.colak 09122021
                                                    --seval.colak 16122021
                                                     accrual_tahsil_gecikme_faiz,
                                                     nonaccrual_tahsil_gecikme_faiz,
                                                     hspln_accrual_tahsil_gecikme_faiz,
                                                     hspln_nonaccrual_tahsil_gecikme_faiz,
                                                     accrual_tahsil_gecikme_faiz_tax,
                                                     nonaccrual_tahsil_gecikme_faiz_tax,
                                                     hspln_accrual_tahsil_gecikme_faiz_tax,
                                                     hspln_nonaccrual_tahsil_gecikme_faiz_tax,
                                                    --seval.colak 16122021
                                                    --seval.colak 17122021
                                                    tahsil_deferred_delayed_interest,
                                                    hspln_deferred_delayed_interest,
                                                    tahsil_accrual_deferred_interest,
                                                    hspln_accrual_deferred_interest,
                                                    tahsil_nonaccrual_deferred_interest,
                                                    hspln_nonaccrual_deferred_interest,
                                                    tahsil_accrual_deferred_delayed_interest,
                                                    hspln_accrual_deferred_delayed_interest,
                                                    tahsil_nonaccrual_deferred_delayed_interest,
                                                    hspln_nonaccrual_deferred_delayed_interest,
                                               --seval.colak 17122021
                                                 --seval.colak 28042022
                                                    tahsil_nonaccrual_deferred_tax  ,   
                                                    hspln_nonaccrual_deferred_tax   ,
                                                    tahsil_nonaccrual_deferred_delay_tax ,   
                                                    hspln_nonaccrual_deferred_delay_tax ,
                                                   --seval.colak 28042022 
                                                   --seval.colak 07062022
                                                    tahsil_accrual_deferred_tax  ,   
                                                    hspln_accrual_deferred_tax   ,
                                                    tahsil_accrual_deferred_delay_tax ,   
                                                    hspln_accrual_deferred_delay_tax 
                                                   --seval.colak 07062022 
                                                  )
                                                values ( ln_tahsilat_log_no,
                                                        ld_banka_tarihi    ,
                                                        ps_tahsilat_islem_tipi    ,
                                                        pn_musteri_no    ,
                                                        pn_kredi_hesap_no    ,
                                                        ps_kredi_doviz_kodu    ,
                                                        pn_taksit_no    ,
                                                        pd_vade_tarihi,
                                                        pd_faiz_tahakkuk_tarihi,
                                                        pn_kredi_bakiye    ,
                                                        pn_iliskili_hesap_no    ,
                                                        pn_iliskili_hesap_bakiye  ,
                                                        ps_iliskili_hesap_doviz    ,
                                                        pn_taksit_tutar    ,
                                                        pn_taksit_tahsil_tutar    ,
                                                        pn_tahsil_toplam,
                                                        --
                                                        pn_tahsil_anapara,
                                                        pn_tahsil_faiz,
                                                        pn_tahsil_vergi,
                                                        pn_tahsil_birikmis_gecikme_faiz    ,
                                                        pn_tahsil_penalty_amount   ,
                                                        pn_tahsil_penalty_tax,
                                                        pn_tahsil_deferred_penalty_tax,      --seval.colak 27042022
                                                        pn_tahsil_deferred_penalty_amount    ,
                                                        pn_tahsil_deferred_interest    ,
                                                      --  pn_tahsil_deferred_delayed_interest    , --seval.colak 17122021
                                                        pn_tahsil_deferred_tax    ,
                                                        pn_tahsil_gecenyil_faiz    ,
                                                        pn_tahsil_gecmis_aylar_faiz    ,
                                                        pn_tahsil_birikmis_faiz    ,
                                                        pn_tahsil_gecenyil_komisyon    ,
                                                        pn_tahsil_gecmis_aylar_komisyon    ,
                                                        pn_tahsil_birikmis_komisyon    ,
                                                        pn_tahsil_gecenyil_gecikme_faiz    ,
                                                        pn_tahsil_gecenay_gecikme_faiz    ,
                                                        --pn_tahsil_gecikme_faiz_accruedtax    ,
                                                        --pn_tahsil_accrued_interest_tax    ,
                                                        pn_tahsil_gecikme_faiz_tax,
                                                        pn_tahsil_vergi_fark,
                                                        ps_tahakkuk_eh,
                                                        ps_taksitli_mi,                                                        
                                                        --  
                                                        pn_hesaplanan_anapara                       ,  
                                                        pn_hesaplanan_faiz                          ,                                                          
                                                        pn_hesaplanan_vergi                         ,                                              
                                                        pn_hesaplanan_birikmis_gecikme_faiz         , 
                                                        pn_hesaplanan_penalty_amount                ,  
                                                        pn_hesaplanan_penalty_tax                   ,
                                                        pn_hesaplanan_deferred_penalty_tax           ,  --seval.colak 27042022             
                                                        pn_hesaplanan_deferred_penalty_amount       ,        
                                                        pn_hesaplanan_deferred_interest             ,
                                                      --  pn_hspln_deferred_delayed_interest    , --seval.colak 17122021  
                                                        pn_hesaplanan_deferred_tax                  , 
                                                        pn_hesaplanan_gecenyil_faiz                 , 
                                                        pn_hesaplanan_gecmis_aylar_faiz             , 
                                                        pn_hesaplanan_birikmis_faiz                 , 
                                                        pn_hesaplanan_gecenyil_komisyon             , 
                                                        pn_hesaplanan_gecmis_aylar_komisyon         , 
                                                        pn_hesaplanan_birikmis_komisyon             , 
                                                        pn_hesaplanan_gecenyil_gecikme_faiz         , 
                                                        pn_hesaplanan_gecenay_gecikme_faiz          , 
                                                        --pn_hesaplanan_gecikme_faiz_accruedtax       , 
                                                        --pn_hesaplanan_accrued_interest_tax          , 
                                                        pn_hesaplanan_gecikme_faiz_tax              ,
                                                        pn_hesaplanan_toplam,
                                                        pn_kalan_tahsil_tutar,
                                                        --                                                      
                                                        pn_grup_no    ,
                                                        pn_log_no,
                                                        pn_islem_kod,
                                                        ln_islem_no,
                                                        pn_fis_no,
                                                         --seval.colak 09122021
                                                        pn_accrual_tahsil_faiz,
                                                        pn_nonaccrual_tahsil_faiz,
                                                        pn_accrual_tahsil_vergi,
                                                        pn_nonaccrual_tahsil_vergi,
                                                        pn_hspln_accrual_tahsil_faiz,
                                                        pn_hspln_nonaccrual_tahsil_faiz,
                                                        pn_hspln_accrual_tahsil_vergi,
                                                        pn_hspln_nonaccrual_tahsil_vergi,
                                                    --seval.colak 09122021
                                                        --seval.colak 16122021
                                                         pn_accrual_tahsil_gecikme_faiz,
                                                         pn_nonaccrual_tahsil_gecikme_faiz,
                                                         pn_hspln_accrual_tahsil_gecikme_faiz,
                                                         pn_hspln_nonaccrual_tahsil_gecikme_faiz,
                                                         pn_accrual_tahsil_gecikme_faiz_tax,
                                                         pn_nonaccrual_tahsil_gecikme_faiz_tax,
                                                         pn_hspln_accrual_tahsil_gecikme_faiz_tax,
                                                         pn_hspln_nonaccrual_tahsil_gecikme_faiz_tax,
                                                           --seval.colak 16122021
                                                           --seval.colak 17122021
                                                         pn_tahsil_deferred_delayed_interest,
                                                         pn_hspln_deferred_delayed_interest,
                                                         pn_tahsil_accrual_deferred_interest,
                                                         pn_hspln_accrual_deferred_interest,
                                                         pn_tahsil_nonaccrual_deferred_interest,
                                                         pn_hspln_nonaccrual_deferred_interest,
                                                         pn_tahsil_accrual_deferred_delayed_interest,
                                                         pn_hspln_accrual_deferred_delayed_interest,
                                                         pn_tahsil_nonaccrual_deferred_delayed_interest,
                                                         pn_hspln_nonaccrual_deferred_delayed_interest,
                                                         --seval.colak 28042022
                                                          pn_tahsil_nonaccrual_deferred_tax  ,   
                                                          pn_hspln_nonaccrual_deferred_tax   ,
                                                          pn_tahsil_nonaccrual_deferred_delay_tax ,   
                                                          pn_hspln_nonaccrual_deferred_delay_tax ,
                                                         --seval.colak 28042022 
                                                         --seval.colak 07062022
                                                          pn_tahsil_accrual_deferred_tax  ,   
                                                          pn_hspln_accrual_deferred_tax   ,
                                                          pn_tahsil_accrual_deferred_delay_tax ,   
                                                          pn_hspln_accrual_deferred_delay_tax 
                                                         --seval.colak 07062022 
                                                        );                                                          
                                      --seval.colak 17122021
        Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6829' || Pkg_Hata.getdelimiter || TO_CHAR(pn_kredi_hesap_no) || Pkg_Hata.getdelimiter || TO_CHAR(pn_fis_no) || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_no );                                       
 COMMIT;
 
EXCEPTION
       WHEN OTHERS THEN
         ROLLBACK;
          ls_mesaj := Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '6850' || Pkg_Hata.getdelimiter || TO_CHAR(pn_kredi_hesap_no) || Pkg_Hata.getdelimiter || TO_CHAR(pn_fis_no) || Pkg_Hata.getdelimiter ||  TO_CHAR(SQLCODE)|| ' ' ||SQLERRM  || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ;
          Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,ls_mesaj ,ln_islem_no);
          sp_insert_cbsrptkreditahsilat(pn_grup_no,pn_log_no,pn_kredi_hesap_no,ls_mesaj,pn_islem_kod,ln_tahsilat_log_no,ps_tahsilat_islem_tipi ,pn_taksit_no,ln_islem_no,pn_fis_no);
END;

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE ANAPARA_TAHSILAT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is
  ld_banka_tarihi                 date :=pkg_muhasebe.banka_tarihi_bul;
  ld_onceki_banka_tarihi          date :=pkg_muhasebe.onceki_banka_tarihi_bul;
  ln_kredi_tahsilat_log_no        number;  
  ln_islem_no                     number;
  ln_fis_no                       number;
  ln_islem_kod                    number := 1323;  
  ln_tahsil_anapara               number := 0; 
  ln_hesaplanan_anapara           number := 0;      
  ln_iliskili_hesap_bakiye        number := 0;
  ln_tahsilat_no    number := 0;
                         
   CURSOR cur_hesap IS
     SELECT 'TAKSITLI-ANAPARA' islem_tipi,
              nvl(b.tahakkuk_eh,'H')  tahakkuk_eh,
             'E' taksitli_mi,
             b.vade_tarih vade_tarih, --seval.colak 05122022
             a.musteri_no       musteri_no,
             a.hesap_no         kredi_hesap_no,
             a.doviz_kodu       kredi_doviz_kodu,
             a.sube_kodu        kredi_sube_kodu,
             sira_no            taksit_no,
             nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)  tahsil_anapara ,
             a.repayment_type,
             a.iliskili_hesap_no ,
            -- nvl(pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no),0) iliskili_hesap_bakiye ,
             pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
              nvl(b.anapara,0) taksit_tutar,
              nvl(b.tahsil_anapara,0) taksit_tahsil_tutar ,
              abs(pkg_hesap.hesapbakiyeal(a.hesap_no))  kredi_bakiye ,
              b.vade_tarih     vade_tarihi,
              a.faiz_tahakkuk_tarihi
     from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
     where a.hesap_no = b.hesap_no and 
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           b.vade_tarih <=ld_banka_tarihi and
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
           and a.repayment_type  = 'INSTALLMENT DATE' 
           and nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)> 0 
           --and pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no) > 0--seval.colak 28112022 performance tuning kapatilacak cursor icerisinde kontrol edilecek.
           and  a.otomatik_tahsilat = 'E' 
           and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment           
    union all
        SELECT 'TAKSITSIZ-ANAPARA' islem_tipi,
               case  when  a.faiz_tahakkuk_tarihi >  ld_onceki_banka_tarihi and a.faiz_tahakkuk_tarihi <= ld_banka_tarihi then 'E' else 'H' end  tahakkuk_eh,
               'H' taksitli_mi,         
             a.kredi_vade          vade_tarih, --seval.colak 05122022
             a.musteri_no          musteri_no    ,
             a.hesap_no            kredi_hesap_no,
             a.doviz_kodu          kredi_doviz_kodu,
             a.sube_kodu           kredi_sube_kodu,
             0                     taksit_no        ,             
             abs(nvl(c.bakiye,0))  tahsil_anapara,
             a.repayment_type  ,
             a.iliskili_hesap_no ,
             -- nvl(pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no),0) iliskili_hesap_bakiye ,
             pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
             0 taksit_tutar,
             0 taksit_tahsil_tutar,
              abs(c.bakiye)  kredi_bakiye ,
              a.kredi_vade  vade_tarihi,
              a.faiz_tahakkuk_tarihi
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and 
           a.durum_kodu = 'A' and 
           a.kredi_vade <= ld_banka_tarihi and
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'  
         --  not exists (Select 1 from cbs_hesap_kredi_taksit b where b.hesap_no = a.hesap_no )  and
           and nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE'  
           and abs(nvl(c.bakiye,0)) <> 0     
         --  and pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no) > 0   --seval.colak 28112022 performance tuning kapatilacak cursor icerisinde kontrol edilecek.
           and  a.otomatik_tahsilat = 'E'  --seval.colak 15082022   
           and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment     
          order by musteri_no asc,vade_tarih asc, kredi_hesap_no; --seval.colak 05122022 kapatildi. --  order by kredi_hesap_no,taksit_no,vade_tarihi;
                
  BEGIN

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    ld_banka_tarihi:=Pkg_Muhasebe.Banka_Tarihi_Bul;

 FOR c_hesap in cur_hesap loop
    ln_hesaplanan_anapara    := nvl(c_hesap.tahsil_anapara,0);
    ln_tahsil_anapara        := nvl(c_hesap.tahsil_anapara,0);
    ln_iliskili_hesap_bakiye := nvl(pkg_hesap.kullanilabilir_bakiye_al( c_hesap.iliskili_hesap_no),0);            
  IF nvl(ln_iliskili_hesap_bakiye,0)> 0 Then  --seval.colak 28112022 performance tuning eklendi.                   
    if nvl(c_hesap.tahsil_anapara,0) >= 0 and  nvl(ln_iliskili_hesap_bakiye,0) >= 0  then 
                            
        if  nvl(c_hesap.tahsil_anapara,0) >= nvl(ln_iliskili_hesap_bakiye,0)  then 
           ln_tahsil_anapara :=  nvl(ln_iliskili_hesap_bakiye,0) ;                    
        else
            ln_tahsil_anapara := nvl(c_hesap.tahsil_anapara,0);                     
        end if;        
        if nvl(ln_tahsil_anapara,0) <> 0 then                     
        TAHSILAT_HESAP(          pn_grup_no => pn_grup_no , 
                                 pn_log_no  => pn_log_no ,
                                 ps_program_kod => ps_program_kod  ,
                                 pn_islem_kod  => ln_islem_kod , 
                                 ps_tahsilat_islem_tipi => c_hesap.islem_tipi ,
                                 ps_repayment_type => c_hesap.repayment_type,
                                 ps_sube_kodu  => c_hesap.kredi_sube_kodu  ,
                                 pn_musteri_no => c_hesap.musteri_no,
                                 pn_kredi_hesap_no => c_hesap.kredi_hesap_no  ,
                                 pn_taksit_no => c_hesap.taksit_no,
                                 pn_islem_no => ln_islem_no ,
                                 pn_fis_no => ln_fis_no ,
                                 pn_Tahsilat_no => ln_Tahsilat_no ,
                                 pd_vade_tarihi => c_hesap.vade_tarihi, 
                                 pd_faiz_tahakkuk_tarihi => c_hesap.faiz_tahakkuk_tarihi, 
                                 pn_kredi_bakiye => c_hesap.kredi_bakiye,
                                 ps_kredi_doviz_kodu => c_hesap.kredi_doviz_kodu ,
                                 pn_iliskili_hesap_no => c_hesap.iliskili_hesap_no , 
                                 ps_iliskili_hesap_doviz=> c_hesap.iliskili_hesap_doviz ,
                                 pn_iliskili_hesap_bakiye => ln_iliskili_hesap_bakiye,
                                 pn_taksit_tutar => c_hesap.taksit_tutar ,
                                 pn_taksit_tahsil_tutar => c_hesap.taksit_tahsil_tutar,
                                 pn_tahsil_TOPLAM=> ln_tahsil_anapara,    
                                 pn_tahsil_anapara => ln_tahsil_anapara,         
                                 pn_hesaplanan_anapara => ln_hesaplanan_anapara,   
                                 pn_hesaplanan_toplam => ln_hesaplanan_anapara,   
                                 ps_tahakkuk_eh => c_hesap.tahakkuk_eh,
                                 ps_taksitli_mi => c_hesap.taksitli_mi                                    
                                 );  
                    end if;           
         end if;
     END IF;    --seval.colak 28112022 performance tuning eklendi.
   END LOOP; 
 
    commit;
 
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE FAIZ_VERGI_DEFERRRED_DELAYED_PENALTY(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is
    ld_banka_tarihi                     date :=pkg_muhasebe.banka_tarihi_bul;
    ld_onceki_banka_tarihi              date :=pkg_muhasebe.onceki_banka_tarihi_bul;
    ln_kredi_tahsilat_log_no            number;  
    ln_islem_no                         number;
    ln_fis_no                           number;
    ln_islem_kod                        number := 1323;  
    ln_tahsil_toplam                    number := 0;     
    ln_iliskili_hesap_bakiye            number := 0;
    ln_sales_tax_rate                   number := 0;        
--------------
    ln_tahsil_gecenyil_faiz             number := 0;
    ln_tahsil_gecmis_aylar_faiz         number := 0;
    ln_tahsil_birikmis_faiz             number := 0;
    ln_tahsil_gecenyil_komisyon         number := 0;
    ln_tahsil_gecmis_aylar_komisyon     number := 0;
    ln_tahsil_birikmis_komisyon         number := 0;
    ln_tahsil_vergi                     number := 0;
    ln_tahsil_faiz                      number := 0;
    ln_kalan_tahsil_tutar               number := 0;
    ln_tahsil_birikmis_gecikme_faiz     number := 0;
    ln_tahsil_gecenyil_gecikme_faiz     number := 0;
    ln_tahsil_gecenay_gecikme_faiz      number := 0;    
    ln_tahsil_gecikme_faiz_accruedtax   number := 0;
    ln_tahsil_accrued_interest_tax      number := 0;
    ln_tahsil_gecikme_faiz_tax          number := 0; 
    ln_tahsil_penalty_amount            number := 0; 
    ln_tahsil_deferred_penalty_amount   number := 0;        
    ln_tahsil_deferred_interest         number := 0;
    ln_tahsil_deferred_tax              number := 0; 
    ln_tahsil_penalty_tax              number := 0;
    --

    ln_hesaplanan_gecenyil_faiz             number := 0;
    ln_hesaplanan_gecmis_aylar_faiz         number := 0;
    ln_hesaplanan_birikmis_faiz             number := 0;
    ln_hesaplanan_gecenyil_komisyon         number := 0;
    ln_hesaplanan_gecmis_aylar_komisyon     number := 0;
    ln_hesaplanan_birikmis_komisyon         number := 0;
    ln_hesaplanan_vergi                     number := 0;
    ln_hesaplanan_faiz                      number := 0;
    ln_hesaplanan_birikmis_gecikme_faiz     number := 0;
    ln_hesaplanan_gecenyil_gecikme_faiz     number := 0;
    ln_hesaplanan_gecenay_gecikme_faiz      number := 0;    
    ln_hesaplanan_gecikme_faiz_tax          number := 0; 
    ln_hesaplanan_penalty_amount            number := 0; 
    ln_hesaplanan_deferred_penalty_amount   number := 0;        
    ln_hesaplanan_deferred_interest         number := 0; 
    ln_hesaplanan_deferred_tax              number := 0; 
    ln_hesaplanan_penalty_tax               number := 0; 
    ln_hesaplanan_tahsil_toplam             number := 0; 
    ln_tahsil_vergi_fark                    number := 0;
    ln_tahsilat_no                          number := 0;
    -- b-o-m seval.colak 09122021
    ln_accrual_tahsil_Faiz                  number := 0;  
    ln_nonaccrual_tahsil_faiz               number := 0; 
    ln_accrual_tahsil_vergi                 number := 0;   
    ln_nonaccrual_tahsil_vergi              number := 0;
    ln_hspln_accrual_tahsil_Faiz            number := 0;  
    ln_hspln_nonaccrual_tahsil_faiz         number := 0; 
    ln_hspln_accrual_tahsil_vergi           number := 0;   
    ln_hspln_nonaccrual_tahsil_vergi        number := 0;    
    -- e-o-m seval.colak 09122021
    
    --b-o-m seval.colak 16122021
    ln_accrual_tahsil_gecikme_faiz          number := 0;  
    ln_nonaccrual_tahsil_gecikme_faiz       number := 0;  
    ln_hspln_accrual_tahsil_gecikme_faiz    number := 0;  
    ln_hspln_nonaccrual_tahsil_gecikme_faiz number := 0; 
    
    ln_accrual_tahsil_gecikme_faiz_tax      number := 0;  
    ln_nonaccrual_tahsil_gecikme_faiz_tax   number := 0;  
    ln_hspln_accrual_tahsil_gecikme_faiz_tax  number := 0;  
    ln_hspln_nonaccrual_tahsil_gecikme_faiz_tax  number := 0;  
    --e-o-m seval.colak 16122021    
       
   --b-o-m seval.colak 17122021
    ln_tahsil_deferred_delayed_interest         number := 0; 
    ln_hspln_deferred_delayed_interest          number := 0;       
    ln_tahsil_accrual_deferred_interest         number := 0;
    ln_tahsil_nonaccrual_deferred_interest      number := 0;
    ln_tahsil_accrual_deferred_delayed_interest number := 0;
    ln_tahsil_nonaccrual_deferred_delayed_interest   number := 0;
    ln_hspln_accrual_deferred_interest               number := 0;
    ln_hspln_nonaccrual_deferred_interest            number := 0;
    ln_hspln_accrual_deferred_delayed_interest       number := 0;
    ln_hspln_nonaccrual_deferred_delayed_interest    number := 0;
    --e-o-m seval.colak 17122021
    --b-o-m seval.colak 27042022
    ln_Tahsil_deferred_penalty_tax                  number := 0; --seval.colak 27042022                                                                        
    ln_hesaplanan_deferred_penalty_tax                  number := 0; --seval.colak 27042022
    --e-o-m seval.colak 27042022
    
    --b-o-m seval.colak 28042022
    ln_tahsil_nonaccrual_deferred_tax    number default 0;
    ln_hspln_nonaccrual_deferred_tax     number default 0;  
    ln_tahsil_nonaccrual_deferred_delay_tax    number default 0;
    ln_hspln_nonaccrual_deferred_delay_tax     number default 0; 
    ln_tmp_tahsil_nonaccrual_deferred_delayed_interest    number default 0; 
    ln_tmp_tahsil_nonaccrual_deferred_interest    number default 0;    
    --e-o-m seval.colak 28042022
    --b-o-m seval.colak 07062022
    ln_tahsil_accrual_deferred_tax    number default 0;
    ln_hspln_accrual_deferred_tax     number default 0;  
    ln_tahsil_accrual_deferred_delay_tax    number default 0;
    ln_hspln_accrual_deferred_delay_tax     number default 0; 
    ln_tmp_tahsil_accrual_deferred_delayed_interest    number default 0; 
    ln_tmp_tahsil_accrual_deferred_interest    number default 0;    
    --e-o-m seval.colak 07062022
    --b-o-m seval.colak 08062022
    ln_tmp_accrual_tahsil_faiz                   number default 0;  
    ln_tmp_nonaccrual_tahsil_faiz                number default 0;  
    ln_tmp_accrual_tahsil_gecikme_faiz           number default 0; 
    ln_tmp_nonaccrual_tahsil_gecikme_faiz        number default 0; 
    ln_sf_pastdue_tax_total                      number default 0;  
    ln_accrual_vergi_tax                number default 0;  
    --e-o-m seval.colak 08062022
    
  --b-o-m seval.colak 03012023
    ln_tmp_tahsil_nonaccrual_interest            number default 0; 
    ln_tmp_tahsil_accrual_interest               number default 0;
  --e-o-m seval.colak 03012023  
    ln_tahsil_deferred_interest_tax              number default 0;--seval.colak 01022023
    ln_tahsil_deferred_delayed_interest_tax      number default 0;--seval.colak 01022023
  cursor cur_hesap IS
   select   'TAKSITLI'  islem_tipi,  
              nvl(b.tahakkuk_eh,'H')  tahakkuk_eh,
              'E' taksitli_mi,
              b.vade_tarih vade_tarih, --seval.colak 05122022
              a.non_accrual_status, --seval.colak 07062022
              a.musteri_no       musteri_no,
              a.hesap_no         kredi_hesap_no,
              a.doviz_kodu       kredi_doviz_kodu,
              a.sube_kodu        kredi_sube_kodu,
              sira_no           taksit_no, 
              a.repayment_type,
              a.iliskili_hesap_no ,
              pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
              0 taksit_tutar,
              0 taksit_tahsil_tutar ,
              abs(pkg_hesap.hesapbakiyeal(a.hesap_no))  kredi_bakiye ,
              vade_tarih  vade_tarihi,  -- b.vade_tarih     vade_tarihi,
              abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) faiz_tahakkuk_tutar,
              abs(nvl(b.bsmv,0) - nvl(b.tahsil_bsmv,0))  vergi_tahakkuk_tutar,             
              a.faiz_tahakkuk_tarihi,
              0     tahsil_gecenyil_faiz_tutari,
              0     tahsil_gecmis_aylar_faizi,
              abs(NVL(birikmis_faiz_tutari,0))     tahsil_birikmis_faiz_tutari,
              0     tahsil_gecenyil_komisyon_tutari,
              0     tahsil_gecmis_aylarin_komisyonu ,
              0     tahsil_birikmis_komisyon_tutari ,
              case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 then  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) else 0 end  tahsil_birikmis_gecikme_faiz_tutari ,
              abs(round(nvl(a.gecenyil_gecikme_faiz,0),2))          tahsil_gecenyil_gecikme_faiz ,
              abs(round(nvl(a.gecenay_gecikme_faiz,0),2))           tahsil_gecenay_gecikme_faiz,
              0        tahsil_gecikme_faiz_accruedtax,  
              abs(round((  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_gecikme_faiz_tax,
              0 tahsil_accrued_interest_tax,
              case when abs(nvl(b.penalty_amount,0) - nvl(b.paid_penalty_amount,0)) > 0 then abs(nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) else 0 end tahsil_penalty_amount,
              case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end tahsil_deferred_penalty_amount,
              abs(round(( case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))   tahsil_deferred_penalty_tax, --seval.colak 27042022
              abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0))  tahsil_deferred_interest,
              abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))  tahsil_deferred_delayed_interest,
              0 tahsil_deferred_tax, --seval.colak 29082022  deferred_tax artik kullanilmayacak --abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0))   tahsil_deferred_tax  ,
              abs(round((  case when abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) > 0 then  abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_penalty_tax,--penalty tax
               -- B-O-M seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) 
                else -- seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
                  case when abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
                        else
                           abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) 
                    end 
                 else 0 
                 end     --  kalan faiz -  accrual bakiye                   
                end ACCRUAL_TAHSIL_FAIZ, 
               abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) -( case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) 
                else -- seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
                  case when abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
                        else
                           abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) 
                    end 
                 else 0 
                 end     --  kalan faiz -  accrual bakiye                   
                end )  NONACCRUAL_TAHSIL_FAIZ  ,
                
                case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                else -- seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
                  case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
                        else
                            abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                    end 
                 else 0 
                 end                       
                end ACCRUAL_TAHSIL_GECIKME_FAIZ, 
                
                abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) - (case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                else -- seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
                  case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
                        else
                            abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                    end 
                 else 0 
                 end                       
                end ) NONACCRUAL_TAHSIL_GECIKME_FAIZ,
                
                abs(round(( ( (  case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                else 
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
                  case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
                        else
                            abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                    end 
                 else 0 
                 end                       
                end ) )* nvl(ln_sales_tax_rate,0) /100),2 ))  ACCRUAL_TAHSIL_GECIKME_FAIZ_TAX, 
                
                abs(round(( ( abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) - (case when nvl(a.non_accrual_status,'N') ='N' then 
                abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                else -- seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
                  case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
                             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
                        else
                            abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) 
                    end 
                 else 0 
                 end                       
                end )) * nvl(ln_sales_tax_rate,0) /100),2 ))  NONACCRUAL_TAHSIL_GECIKME_FAIZ_TAX,       
              -- E-O-M seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak                     
                accrual_int_account_no,
                accrual_tax_account_no,
                accrual_delayed_int_account_no,
                nonaccrual_int_account_no,
                nonaccrual_delayed_int_account_no,                         
            
            case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            else 
            (case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when  abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            end 
            else 0 
            end    )                    
            end ACCRUAL_TAHSIL_DEFERRED_INTEREST, 
            
            abs(round(((( case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            else 
            (case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when  abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            end 
            else 0 
            end    )                    
            end  )) * nvl(ln_sales_tax_rate,0) /100),2 ))  ACCRUAL_TAHSIL_DEFERRED_INTEREST_TAX, 
            
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) -(  case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            else 
            (case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when  abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            end 
            else 0 
            end    )                   
            end )   NONACCRUAL_TAHSIL_DEFERRED_INTEREST, 
                
             abs(round((( abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) -(  case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            else 
            (case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when  abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
            abs(nvl(b.deferred_interest,0) - nvl(b.paid_deferred_interest,0)) 
            end 
            else 0 
            end    )                   
            end )) * nvl(ln_sales_tax_rate,0) /100),2 )) NONACCRUAL_TAHSIL_DEFERRED_INTEREST_TAX ,  
               
            case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            else 
             case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            end 
            else 0 
            end                      
            end ACCRUAL_TAHSIL_DEFERRED_DELAYED_INT,  
          
            abs(round(((( case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            else 
             case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            end 
            else 0 
            end                      
            end) ) * nvl(ln_sales_tax_rate,0) /100),2 ))  ACCRUAL_TAHSIL_DEFERRED_DELAYED_INT_TAX, 
                
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0))-(  case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            else 
             case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            end 
            else 0 
            end                     
            end )  NONACCRUAL_TAHSIL_DEFERRED_DELAYED_INT, 
     
            abs(round(( (abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0))-(  case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            else 
             case when nvl(a.non_accrual_status,'N') ='Y' and abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(nvl(b.deferred_delayed_interest,0) - nvl(b.paid_deferred_delayed_interest,0)) 
            end 
            else 0 
            end                     
            end )) * nvl(ln_sales_tax_rate,0) /100),2 )) NONACCRUAL_TAHSIL_DEFERRED_DELAYED_INT_TAX  ,
            nvl(b.anapara,0)-nvl(b.tahsil_anapara,0)  tahsil_anapara_check     -- seval.colak 20022023  process sirali olarak calismasi icin  eklenen kontrol degerleri                                                                            
    -- E-O-M seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak  
     from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
     where a.hesap_no = b.hesap_no and  
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           b.vade_tarih <= ld_banka_tarihi and
           a.repayment_type = 'INSTALLMENT DATE' and  -- seval ekledim 16092021
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
           -- and pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no) > 0 --seval.colak 28112022 performance tuning kapatilacak cursor icerisinde kontrol edilecek.
           and  a.otomatik_tahsilat = 'E'  --seval.colak 15082022   
           and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment  
           --and  nvl(a.NON_ACCRUAL_STATUS ,'N') ='N' --seval.colak  18112022 logic degisene kadar non accrual status No olanlar icin calisacak  --seval.colak 05012022 artik hesaplanacakkontrol kapatildi.      
     union all      
     select distinct 'TAKSITSIZ' islem_tipi,
             case  when  a.faiz_tahakkuk_tarihi >  ld_onceki_banka_tarihi and a.faiz_tahakkuk_tarihi <= ld_banka_tarihi then 'E' else 'H' end  tahakkuk_eh,
              'H' taksitli_mi,
             nvl(faiz_tahakkuk_tarihi, kredi_vade) vade_tarih, --seval.colak 05122022
              a.non_accrual_status, --seval.colak 07062022
             a.musteri_no          musteri_no    ,
             a.hesap_no            kredi_hesap_no,
             a.doviz_kodu          kredi_doviz_kodu,
             a.sube_kodu           kredi_sube_kodu,
              0                     taksit_no ,
              a.repayment_type  ,
              a.iliskili_hesap_no ,
              pkg_hesap.hesaptandovizkodual(a.iliskili_hesap_no) iliskili_hesap_doviz,
              0 taksit_tutar,
              0 taksit_tahsil_tutar,
              abs(c.bakiye)  kredi_bakiye ,
              a.kredi_vade  vade_tarihi,
              abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) faiz_tahakkuk_tutar,
              abs(pkg_odeme_plan.sf_pastdue_tax_total(a.hesap_no))  vergi_tahakkuk_tutar,                                   
              a.faiz_tahakkuk_tarihi ,
               0   tahsil_gecenyil_faiz_tutari,
               0   tahsil_gecmis_aylar_faizi,
               abs(NVL(birikmis_faiz_tutari,0))   tahsil_birikmis_faiz_tutari,
               0   tahsil_gecenyil_komisyon_tutari,
               0   tahsil_gecmis_aylarin_komisyonu ,
               0   tahsil_birikmis_komisyon_tutari ,
              abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2))  tahsil_birikmis_gecikme_faiz_tutari ,
              0       tahsil_gecenyil_gecikme_faiz ,
              0   tahsil_gecenay_gecikme_faiz,   
              0   tahsil_gecikme_faiz_accruedtax,   
              abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_gecikme_faiz_tax,  
              0      tahsil_accrued_interest_tax ,         
               case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end tahsil_penalty_amount, -- seval.colak 21042022  onceki hali abs( nvl(a.penalty_amount,0 ))   tahsil_penalty_amount
              0 tahsil_deferred_penalty_amount ,
              0 tahsil_deferred_penalty_tax , --seval.colak 27042022
              0 tahsil_deferred_interest,
              0 tahsil_deferred_delayed_interest, 
              0 tahsil_deferred_tax ,
              round(case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100,2)  tahsil_penalty_tax,--penalty tax
            -- B-O-M seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
            case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no),0),2))  
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
                abs(round(nvl(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no),0),2))
            end 
            else 0 
            end                   
            end ACCRUAL_TAHSIL_FAIZ, 
          
            abs(round(nvl(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no),0),2)) - 
             case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no),0),2))
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_int_account_no) <= 0  then 
            case when abs(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_int_account_no)) 
            else
                 abs(round(nvl(pkg_odeme_plan.sf_pastdue_interest_total(a.hesap_no),0),2))
            end 
            else 0 
            end                   
            end  NONACCRUAL_TAHSIL_FAIZ  ,  
                            
            case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            end 
            else 0 
            end                        
            end ACCRUAL_TAHSIL_GECIKME_FAIZ, 
            
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) - (case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            end 
            else 0 
            end                       
            end)  NONACCRUAL_TAHSIL_GECIKME_FAIZ,  
           
            abs(round((  (  case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            end 
            else 0 
            end                        
            end )* nvl(ln_sales_tax_rate,0) /100),2 ))  ACCRUAL_TAHSIL_GECIKME_FAIZ_TAX, 
            
            abs(round( (( abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) - (case when nvl(a.non_accrual_status,'N') ='N' then 
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            else 
            case when nvl(a.non_accrual_status,'N') ='Y' and abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) > 0 and  pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no) < 0  then 
            case when  abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) >  abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) then
             abs(pkg_hesap.hesapbakiyeal(a.accrual_delayed_int_account_no)) 
            else
            abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2)) 
            end 
            else 0 
            end                       
            end)) * nvl(ln_sales_tax_rate,0) /100),2 ))  NONACCRUAL_TAHSIL_GECIKME_FAIZ_TAX,       
  -- E-O-M seval.colak 04012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak   
    
            accrual_int_account_no,
            accrual_tax_account_no,
            accrual_delayed_int_account_no,
            nonaccrual_int_account_no,
            nonaccrual_delayed_int_account_no ,          
              -- seval.colak 09122021
              ---seval.colak 17122021
          0  accrual_tahsil_deferred_interest,  -- tahsil accrual_tahsil_deferred_interest
          0  accrual_tahsil_deferred_interest_tax,  --seval.colak 07062022
          0  nonaccrual_tahsil_deferred_interest,  -- nonaccrual_tahsil_deferred_interes  -- nonaccrual_tahsil_deferred_delayed_interest
          0 nonaccrual_tahsil_deferred_interest_tax ,--seval.colak 28042022
          0  accrual_tahsil_deferred_delayed_int,  -- tahsil deferred_delayed_interest
          0  accrual_tahsil_deferred_delayed_int_tax,  --seval.colak 07062022
          0  nonaccrual_tahsil_deferred_delayed_int,  -- nonaccrual_tahsil_deferred_delayed_interest
          0  nonaccrual_tahsil_deferred_delayed_int_tax , --seval.colak 28042022
           case when  a.kredi_vade <= ld_banka_tarihi then  abs(nvl(c.bakiye,0)) else 0 end  tahsil_anapara_check     -- seval.colak 20022023  process sirali olarak calismasi icin  eklenen kontrol degerleri
     from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and  
           a.durum_kodu = 'A' and 
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and
           pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E'  and
          -- pkg_hesap.kullanilabilir_bakiye_al( a.iliskili_hesap_no) > 0 and  --seval.colak 28112022 performance tuning kapatilacak cursor icerisinde kontrol edilecek
           a.otomatik_tahsilat = 'E'  --seval.colak 15082022
           and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' )  --seval.colak 24112022 badlist customer will not be collected with automatic payment  
          -- and  nvl(a.NON_ACCRUAL_STATUS ,'N') ='N' --seval.colak  18112022 logic degisene kadar non accrual status No olanlar icin calisacak  --seval.colak 05012022 artik hesaplanacakkontrol kapatildi.      
          order by musteri_no asc,vade_tarih asc, kredi_hesap_no; --seval.colak 05122022 kapatildi.  -- order by kredi_hesap_no,taksit_no,vade_tarihi;        

    r_hesap  cur_hesap%ROWTYPE;          
  BEGIN

    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 
  FOR c_hesap in cur_hesap loop  
        r_hesap := c_hesap ;
        ln_iliskili_hesap_bakiye:= nvl(pkg_hesap.kullanilabilir_bakiye_al( c_hesap.iliskili_hesap_no),0);    
    IF   nvl(ln_iliskili_hesap_bakiye,0) > 0 then   ----seval.colak 28112022 performance tuning eklendi.
        --
                ln_Tahsil_faiz                               := 0;
                ln_Tahsil_vergi                              := 0;         
                ln_Tahsil_gecenyil_faiz                      := 0;
                ln_Tahsil_gecmis_aylar_faiz                  := 0;
                ln_Tahsil_birikmis_faiz                      := 0;
                ln_Tahsil_gecenyil_komisyon                  := 0;
                ln_Tahsil_gecmis_aylar_komisyon              := 0;
                ln_Tahsil_birikmis_komisyon                  := 0;
                ln_Tahsil_birikmis_gecikme_faiz              := 0;
                ln_Tahsil_gecenyil_gecikme_faiz              := 0;
                ln_Tahsil_gecenay_gecikme_faiz               := 0;
                ln_Tahsil_gecikme_faiz_accruedtax            := 0;
                ln_Tahsil_accrued_interest_tax               := 0;
                ln_Tahsil_gecikme_faiz_tax                   := 0;
                ln_Tahsil_penalty_amount                     := 0;
                ln_Tahsil_penalty_tax                        := 0;
                ln_Tahsil_deferred_penalty_tax               := 0; --seval.colak 27042022
                ln_Tahsil_deferred_penalty_amount            := 0;
                ln_Tahsil_deferred_interest                  := 0;
                ln_Tahsil_deferred_tax                       := 0;
                ln_accrual_tahsil_Faiz                       := 0;  
                ln_nonaccrual_tahsil_faiz                    := 0;  
                ln_accrual_tahsil_vergi                      := 0;   
                ln_nonaccrual_tahsil_vergi                   := 0;   
                 ln_accrual_tahsil_gecikme_faiz              := 0;  
                 ln_nonaccrual_tahsil_gecikme_faiz           := 0;  
                 ln_hspln_accrual_tahsil_gecikme_faiz        := 0;  
                 ln_hspln_nonaccrual_tahsil_gecikme_faiz     := 0;  
                 ln_accrual_tahsil_gecikme_faiz_tax          := 0;  
                 ln_nonaccrual_tahsil_gecikme_faiz_tax       := 0;  
                 ln_hspln_accrual_tahsil_gecikme_faiz_tax    := 0;  
                 ln_hspln_nonaccrual_tahsil_gecikme_faiz_tax := 0;                   
            --seval.colak 17122021
                ln_tahsil_deferred_delayed_interest  := 0; 
                ln_hspln_deferred_delayed_interest   := 0;       
                ln_tahsil_accrual_deferred_interest             := 0;
                ln_tahsil_nonaccrual_deferred_interest          := 0;
                ln_tahsil_accrual_deferred_delayed_interest         := 0;
                ln_tahsil_nonaccrual_deferred_delayed_interest      := 0;
                ln_hspln_accrual_deferred_interest              := 0;
                ln_hspln_nonaccrual_deferred_interest           := 0;
                ln_hspln_accrual_deferred_delayed_interest          := 0;
                ln_hspln_nonaccrual_deferred_delayed_interest       := 0;
             --seval.colak 17122021        
             --seval.colak 28042022
                ln_tahsil_nonaccrual_deferred_tax     := 0;
                ln_hspln_nonaccrual_deferred_tax      := 0;
                ln_tahsil_nonaccrual_deferred_delay_tax     := 0;
                ln_hspln_nonaccrual_deferred_delay_tax      := 0;
                ln_tmp_tahsil_nonaccrual_deferred_delayed_interest  :=0; 
                ln_tmp_tahsil_nonaccrual_deferred_interest    :=0;    
             --seval.colak 28042022
             --seval.colak 07062022
                ln_tahsil_accrual_deferred_tax     := 0;
                ln_hspln_accrual_deferred_tax      := 0;
                ln_tahsil_accrual_deferred_delay_tax     := 0;
                ln_hspln_accrual_deferred_delay_tax      := 0;
                ln_tmp_tahsil_accrual_deferred_delayed_interest  :=0; 
                ln_tmp_tahsil_accrual_deferred_interest    :=0;  
             --seval.colak 07062022
             
  IF  nvl(R_HESAP.TAHSIL_ANAPARA_CHECK,0) = 0 THEN  -- b-o-m seval.colak 20022023  process sirali olarak calismasi icin 1.sirada 1.'PRINCIPAL' genel kontrolu olacaktir.
-- Process calisma siralamasi asagidaki sekildedir Eklenecek kontroller bir onceki process degeri sifirlanmissa calissin seklinde olacaktir.
-- ONEMLI UNUTMA >Asagidaki siralama degisirse buradaki kontrollerin yeri de degistirilmeli..
--1.'PRINCIPAL' ,2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX',4.'DEFERRED-PENALTY-TAX',5.'INTEREST-TAX' ,6.'DELAYED-INTEREST-TAX',7.'PENALTY-INTEREST-TAX' --seval.colak 20022023  process sirali olarak calismasi icin  eklenen kontrol degerleri 

 --seval.colak 20022023 bundan once 2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX',4.'DEFERRED-PENALTY-TAX' degerleri tahsil edilmis olmali.
 if  nvl(r_hesap.tahsil_deferred_interest,0) +   nvl(r_hesap.tahsil_deferred_delayed_interest,0) +  nvl(r_hesap.tahsil_deferred_penalty_amount,0) = 0  then  --seval.colak 20022023  
    -- tahsilat islem tipine gore degerleri 0 layalim 
        --1.gruo.
        if ps_program_kod = 'INTEREST-TAX' then 
                ln_Tahsil_faiz                          := nvl(r_hesap.faiz_tahakkuk_tutar,0);
                
                ln_Tahsil_vergi                         := nvl(r_hesap.vergi_tahakkuk_tutar,0);         
                ln_Tahsil_gecenyil_faiz                 := nvl(r_hesap.tahsil_gecenyil_faiz_tutari,0);
                ln_Tahsil_gecmis_aylar_faiz             := nvl(r_hesap.tahsil_gecmis_aylar_faizi,0);
                ln_Tahsil_birikmis_faiz                 := nvl(r_hesap.tahsil_birikmis_faiz_tutari,0);
                ln_Tahsil_gecenyil_komisyon             := nvl(r_hesap.tahsil_gecenyil_komisyon_tutari,0); 
                ln_Tahsil_gecmis_aylar_komisyon         := nvl(r_hesap.tahsil_gecmis_aylarin_komisyonu,0);
                ln_Tahsil_birikmis_komisyon             := nvl(r_hesap.tahsil_birikmis_komisyon_tutari,0);
               -- ln_Tahsil_accrued_interest_tax          := nvl(r_hesap.tahsil_accrued_interest_tax,0);
               -- ln_tahsil_vergi_fark                    := nvl(r_hesap.tahsil_vergi_fark,0); 
                --seval.colak 09122021
                ln_accrual_tahsil_Faiz                  := nvl(r_hesap.accrual_tahsil_Faiz,0);  
                ln_nonaccrual_tahsil_faiz               := nvl(r_hesap.nonaccrual_tahsil_faiz,0);   
                
                  if  abs(nvl(ln_tahsil_vergi ,0)) > 0 then      --seval.colak 02022023
                     
                     ln_accrual_tahsil_vergi                 := abs(round((  nvl(ln_accrual_tahsil_Faiz,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ; --seval.colak 02022023
                     ln_nonaccrual_tahsil_vergi              := abs(round((  nvl(ln_nonaccrual_tahsil_faiz,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ;--seval.colak 02022023
                    
                      if ln_accrual_tahsil_vergi > ln_tahsil_Vergi  then
                             ln_accrual_tahsil_vergi :=  ln_tahsil_Vergi ;
                        end if;                 
                         ln_nonaccrual_tahsil_vergi:= abs( nvl(ln_tahsil_Vergi,0) - nvl(ln_accrual_tahsil_vergi,0))  ;                                   
                          -- e-o-m seval.colak 01022023
                         ln_tahsil_Vergi :=  nvl(ln_accrual_tahsil_vergi,0)  +  nvl(ln_nonaccrual_tahsil_vergi,0) ; 
                       else
                       ln_accrual_tahsil_vergi := 0;
                       ln_nonaccrual_tahsil_vergi := 0;
                    end if;                     
        
          end if;
   end if;
   
  -- seval.colak 20022023 1.'PRINCIPAL' ,2.'DEFERRED-INTEREST-TAX' bundan once principal calismis olmali. Genel kontrol anapara yeterli.
        --2.grup
        if ps_program_kod = 'DEFERRED-INTEREST-TAX' then
                ln_Tahsil_deferred_interest := nvl(r_hesap.tahsil_deferred_interest,0);     
                --seval.colak 17122021
                ln_tahsil_accrual_deferred_interest    := nvl(r_hesap.accrual_tahsil_deferred_interest,0);  
                ln_tahsil_nonaccrual_deferred_interest := nvl(r_hesap.nonaccrual_tahsil_deferred_interest,0);
                --seval.colak 17122021   
                ln_tahsil_nonaccrual_deferred_tax    :=  nvl(r_hesap.nonaccrual_tahsil_deferred_interest_tax,0); --seval.colak 28042022  
                ln_tahsil_accrual_deferred_tax    :=  nvl(r_hesap.accrual_tahsil_deferred_interest_tax,0); --seval.colak 07062022              
         end if;
         --2.2 grup --seval.colak 17122021
         
 --seval.colak 20022023  bundan once 2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX'
  if  nvl(r_hesap.tahsil_deferred_interest,0) = 0 then --seval.colak 20022023
        if ps_program_kod = 'DEFERRED-DELAYED-INTEREST-TAX' then
                ln_Tahsil_deferred_delayed_interest  := nvl(r_hesap.tahsil_deferred_delayed_interest,0);  
                 --seval.colak 17122021
                ln_tahsil_accrual_deferred_delayed_interest    := nvl(r_hesap.accrual_tahsil_deferred_delayed_int,0);  
                ln_tahsil_nonaccrual_deferred_delayed_interest := nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int,0);
                --seval.colak 17122021                       
                ln_tahsil_nonaccrual_deferred_delay_tax         := nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int_tax,0); --seval.colak 28042022 
                ln_tahsil_accrual_deferred_delay_tax         := nvl(r_hesap.accrual_tahsil_deferred_delayed_int_tax,0); --seval.colak 07062022 ;       
        end if;
   end if;       
        
         /* --seval.colak cancelled this process not used  20022023
        --3.grup
        if ps_program_kod = 'DEFERRED-TAX' then 
             ln_Tahsil_deferred_tax                     := nvl(r_hesap.tahsil_deferred_tax,0);
        end if;
        */
      
 --seval.colak 20022023  bundan once 2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX',4.'DEFERRED-PENALTY-TAX'
     if  nvl(r_hesap.tahsil_deferred_interest,0) +   nvl(r_hesap.tahsil_deferred_delayed_interest,0) = 0  then  --seval.colak 20022023  
         --4.grup
         if ps_program_kod = 'DEFERRED-PENALTY-TAX' then    --seval.colak 27042022  DEFERRED-PENALTY >DEFERRED-PENALTY-TAX
                ln_Tahsil_deferred_penalty_amount        := nvl(r_hesap.tahsil_deferred_penalty_amount,0);     
                ln_Tahsil_deferred_penalty_tax           :=abs(round(( nvl(r_hesap.tahsil_deferred_penalty_amount,0) * nvl(ln_sales_tax_rate,0) /100),2 )) ; --seval.colak 27042022                     
        end if;
    end if;
    
 --seval.colak 20022023  bundan once 2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX',4.'DEFERRED-PENALTY-TAX',5.'INTEREST-TAX' ,6.'DELAYED-INTEREST-TAX'
  if  nvl(r_hesap.tahsil_deferred_interest,0) +   nvl(r_hesap.tahsil_deferred_delayed_interest,0) +  nvl(r_hesap.tahsil_deferred_penalty_amount,0) +nvl(r_hesap.faiz_tahakkuk_tutar,0) +nvl(r_hesap.vergi_tahakkuk_tutar,0) = 0  then  --seval.colak 20022023  
        --5.grup
         if ps_program_kod = 'DELAYED-INTEREST-TAX' then 
                ln_Tahsil_birikmis_gecikme_faiz         := nvl(r_hesap.tahsil_birikmis_gecikme_faiz_tutari,0);
                ln_Tahsil_gecenyil_gecikme_faiz         := nvl(r_hesap.tahsil_gecenyil_gecikme_faiz,0);
                ln_Tahsil_gecenay_gecikme_faiz          := nvl(r_hesap.tahsil_gecenay_gecikme_faiz,0);
                ln_Tahsil_gecikme_faiz_tax              := nvl(r_hesap.tahsil_gecikme_faiz_tax,0);    
                --seval.colak 16122021
                ln_accrual_tahsil_gecikme_faiz          := nvl(r_hesap.accrual_tahsil_gecikme_faiz,0);  
                ln_nonaccrual_tahsil_gecikme_faiz       := nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz,0);
                ln_accrual_tahsil_gecikme_faiz_tax      := nvl(r_hesap.accrual_tahsil_gecikme_faiz_tax,0);  
                ln_nonaccrual_tahsil_gecikme_faiz_tax   := nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz_tax,0);        
                 --seval.colak 16122021      
        end if;
  end if;
  
   --seval.colak 20022023  bundan once 2.'DEFERRED-INTEREST-TAX',3.'DEFERRED-DELAYED-INTEREST-TAX',4.'DEFERRED-PENALTY-TAX',5.'INTEREST-TAX' ,6.'DELAYED-INTEREST-TAX',7.'PENALTY-INTEREST-TAX' --seval.colak 20022023  process sirali olarak calismasi icin  eklenen kontrol degerleri 
   if  nvl(r_hesap.tahsil_deferred_interest,0) +   nvl(r_hesap.tahsil_deferred_delayed_interest,0) +  nvl(r_hesap.tahsil_deferred_penalty_amount,0) +nvl(r_hesap.faiz_tahakkuk_tutar,0) +nvl(r_hesap.vergi_tahakkuk_tutar,0) + nvl(r_hesap.tahsil_birikmis_gecikme_faiz_tutari,0) = 0  then  --seval.colak 20022023  
    --6.grup
        if ps_program_kod = 'PENALTY-INTEREST-TAX'  then 
               ln_Tahsil_penalty_amount := nvl(r_hesap.tahsil_penalty_amount,0);            
               ln_Tahsil_penalty_tax    := abs(round(( nvl(r_hesap.tahsil_penalty_amount,0) * nvl(ln_sales_tax_rate,0) /100),2 )) ;   
        end if;   
   end if;      
         ln_hesaplanan_faiz                          := ln_tahsil_faiz                          ;
         ln_hesaplanan_vergi                         := ln_tahsil_vergi                         ;
         ln_hesaplanan_gecenyil_faiz                 := ln_tahsil_gecenyil_faiz                 ;
         ln_hesaplanan_gecmis_aylar_faiz             := ln_tahsil_gecmis_aylar_faiz             ;
         ln_hesaplanan_birikmis_faiz                 := ln_tahsil_birikmis_faiz                 ;
         ln_hesaplanan_gecenyil_komisyon             := ln_tahsil_gecenyil_komisyon             ;
         ln_hesaplanan_gecmis_aylar_komisyon         := ln_tahsil_gecmis_aylar_komisyon         ;
         ln_hesaplanan_birikmis_komisyon             := ln_tahsil_birikmis_komisyon             ;
         ln_hesaplanan_birikmis_gecikme_faiz         := ln_tahsil_birikmis_gecikme_faiz         ;
         ln_hesaplanan_gecenyil_gecikme_faiz         := ln_tahsil_gecenyil_gecikme_faiz         ;
         ln_hesaplanan_gecenay_gecikme_faiz          := ln_tahsil_gecenay_gecikme_faiz          ;
         ln_hesaplanan_gecikme_faiz_tax              := ln_tahsil_gecikme_faiz_tax              ;
         ln_hesaplanan_penalty_amount                := ln_tahsil_penalty_amount                ;
         ln_hesaplanan_penalty_tax                   := ln_tahsil_penalty_tax                   ;
         ln_hesaplanan_deferred_penalty_tax          := ln_tahsil_deferred_penalty_tax          ; --seval.colak 27042022
         ln_hesaplanan_deferred_penalty_amount       := ln_tahsil_deferred_penalty_amount       ;
         ln_hesaplanan_deferred_interest             := ln_tahsil_deferred_interest             ;
         ln_hspln_deferred_delayed_interest          := ln_tahsil_deferred_delayed_interest      ; --seval.colak 17122021
         ln_hesaplanan_deferred_tax                  := ln_tahsil_deferred_tax  ;
         --seval.colak 09122021
        ln_hspln_accrual_tahsil_Faiz                 := ln_accrual_tahsil_Faiz ;
        ln_hspln_nonaccrual_tahsil_faiz              := ln_nonaccrual_tahsil_faiz ;
        ln_hspln_accrual_tahsil_vergi                := ln_accrual_tahsil_vergi ;
        ln_hspln_nonaccrual_tahsil_vergi             := ln_nonaccrual_tahsil_vergi ;
        --seval.colak 09122021    
        
       --seval.colak 16122021
        ln_hspln_accrual_tahsil_gecikme_faiz        :=  ln_accrual_tahsil_gecikme_faiz ;
        ln_hspln_nonaccrual_tahsil_gecikme_faiz     :=  ln_nonaccrual_tahsil_gecikme_faiz ;     
        ln_hspln_accrual_tahsil_gecikme_faiz_tax    :=  ln_accrual_tahsil_gecikme_faiz_tax ;
        ln_hspln_nonaccrual_tahsil_gecikme_faiz_tax :=  ln_nonaccrual_tahsil_gecikme_faiz_tax ;                    
        --seval.colak 16122021         
        
       --seval.colak 17122021
         ln_hspln_accrual_deferred_interest         := ln_tahsil_accrual_deferred_interest ;  
         ln_hspln_nonaccrual_deferred_interest      := ln_tahsil_nonaccrual_deferred_interest;
         ln_hspln_accrual_deferred_delayed_interest := ln_tahsil_accrual_deferred_delayed_interest ;  
         ln_hspln_nonaccrual_deferred_delayed_interest := ln_tahsil_nonaccrual_deferred_delayed_interest;
        --seval.colak 17122021   
         ln_hspln_nonaccrual_deferred_tax             := ln_tahsil_nonaccrual_deferred_tax; --seval.colak 28042022
         ln_hspln_nonaccrual_deferred_delay_tax       := ln_tahsil_nonaccrual_deferred_delay_tax; --seval.colak 28042022
         ln_hspln_accrual_deferred_tax                := ln_tahsil_accrual_deferred_tax; --seval.colak 07062022
         ln_hspln_accrual_deferred_delay_tax          := ln_tahsil_accrual_deferred_delay_tax; --seval.colak 07062022
        
         ln_tahsil_toplam                       :=  ln_tahsil_faiz  +
                                                    ln_tahsil_vergi                         +   
                                                    ln_tahsil_gecenyil_faiz                 +
                                                    ln_tahsil_gecmis_aylar_faiz             +
                                                    --ln_tahsil_birikmis_faiz                 +
                                                    ln_tahsil_gecenyil_komisyon             +
                                                    ln_tahsil_gecmis_aylar_komisyon         +
                                                   --ln_tahsil_birikmis_komisyon             +
                                                    ln_tahsil_birikmis_gecikme_faiz         +
                                                    ln_tahsil_gecenyil_gecikme_faiz         +
                                                    ln_tahsil_gecenay_gecikme_faiz          +
                                                    ln_tahsil_gecikme_faiz_tax              +
                                                    ln_tahsil_penalty_amount                +
                                                    ln_tahsil_penalty_tax                   +
                                                    ln_tahsil_deferred_penalty_amount       +
                                                    ln_tahsil_deferred_interest             +
                                                    ln_tahsil_deferred_delayed_interest     + --seval.colak 17122021
                                                    ln_tahsil_deferred_tax                  +
                                                    ln_tahsil_deferred_penalty_tax          + --seval.colak 27042022
                                                    ln_tahsil_nonaccrual_deferred_tax       + --seval.colak 28042022
                                                    ln_tahsil_nonaccrual_deferred_delay_tax + --seval.colak 28042022
                                                    ln_tahsil_accrual_deferred_tax          + --seval.colak 07062022
                                                    ln_tahsil_accrual_deferred_delay_tax ;    --seval.colak 07062022
      
        ln_kalan_tahsil_tutar           :=  ln_tahsil_toplam  ; 
           
        if nvl(ln_tahsil_toplam,0) > 0 and  nvl(ln_iliskili_hesap_bakiye,0) > 0  then 
            
           if  nvl(ln_tahsil_toplam,0) > nvl(ln_iliskili_hesap_bakiye,0)  then 
               ln_tahsil_toplam := nvl(ln_iliskili_hesap_bakiye,0);
               ln_kalan_tahsil_tutar    := nvl(ln_tahsil_toplam,0) ;
            end if;
------------------------------------------------------------------------------------     
-- B-O-M Seval.colak 05012023 YENI EKLENDI. FAIZ+TAX beraber alinacak sekildedir.
--1.  start of grup 2  ps_program_kod =  'INTEREST-TAX'    
 if  ps_program_kod =   'INTEREST-TAX' then   
     if nvl(ln_tahsil_faiz,0) +  nvl(ln_tahsil_vergi,0)  > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                 ln_tahsil_faiz := ln_kalan_tahsil_tutar;
                if nvl(ln_tahsil_vergi,0)  <> 0   then    --seval.colak 27012023
                    if ln_tahsil_vergi > nvl(ln_tahsil_faiz,0) - round(((ln_tahsil_faiz*100)/(100+ln_sales_tax_rate)),2) then 
                        ln_tahsil_vergi := nvl(ln_tahsil_faiz,0) - round(((ln_tahsil_faiz*100)/(100+ln_sales_tax_rate)),2) ;                      
                    end if;   
                    
                  ln_tahsil_faiz := abs( nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_vergi,0)) ;                
                end if;
               
              if nvl(ln_tahsil_faiz,0) > 0 then 
                          -- B-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak                      
                          select  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_faiz,0)) 
                                        else 
                                               case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_faiz,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_faiz,0)) 
                                                    end 
                                                 else 0 
                                                 end                        
                                        end accrual_tahsil_faiz, 
                                            abs(nvl(ln_tahsil_faiz,0))  - ( case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_faiz,0)) 
                                        else 
                                               case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_faiz,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_faiz,0)) 
                                                    end 
                                                 else 0 
                                                 end                        
                                        end ) nonaccrual_tahsil_faiz                                             
                              into 
                                    ln_accrual_tahsil_Faiz,
                                    ln_nonaccrual_tahsil_faiz                                                              
                             from dual;   
                           -- E-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak 
                                                                  
                   end if;                         
            -- b-o-m seval.colak 01022023
             if nvl(ln_tahsil_vergi,0)  <> 0   then   
                 ln_accrual_tahsil_vergi :=    abs(round((  nvl(ln_accrual_tahsil_Faiz,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ;
                 if ln_accrual_tahsil_vergi > ln_tahsil_Vergi  then
                     ln_accrual_tahsil_vergi :=  ln_tahsil_Vergi ;
                  end if;                 
                 ln_nonaccrual_tahsil_vergi:= abs( nvl(ln_tahsil_Vergi,0) - nvl(ln_accrual_tahsil_vergi,0))  ;                                   
                  -- e-o-m seval.colak 01022023
                 ln_tahsil_Vergi :=  nvl(ln_accrual_tahsil_vergi,0)  +  nvl(ln_nonaccrual_tahsil_vergi,0) ; 
               else
               ln_accrual_tahsil_vergi := 0;
               ln_nonaccrual_tahsil_vergi := 0;
             end if;
                 
             ln_tahsil_faiz :=  nvl(ln_accrual_tahsil_Faiz,0)  +  nvl(ln_nonaccrual_tahsil_faiz,0) ; 
          
             ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_faiz,0) + nvl(ln_nonaccrual_tahsil_vergi,0) + nvl(ln_accrual_tahsil_vergi,0) ) ;     --seval.colak 07062022 ln_accrual_tahsil_vergi eklendi        
         else
            ln_tahsil_faiz := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_nonaccrual_tahsil_vergi   := 0;
            ln_accrual_tahsil_vergi   := 0;
         end if;   
     else  -- INTEREST 
                   if  ln_tahsil_Faiz > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_Faiz := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_Faiz := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_Faiz,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
           -- ACCRUAL TAX      --seval.colak 07062022          
                 if  ln_accrual_tahsil_vergi > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_accrual_tahsil_vergi := ln_kalan_tahsil_tutar;
                         else
                            ln_accrual_tahsil_vergi := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_accrual_tahsil_vergi,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;                
                    
           -- NON ACCRUAL TAX               
                 if  ln_nonaccrual_tahsil_vergi > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_nonaccrual_tahsil_vergi := ln_kalan_tahsil_tutar;
                         else
                            ln_nonaccrual_tahsil_vergi := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_nonaccrual_tahsil_vergi,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;
             
             ln_tahsil_faiz :=  nvl(ln_accrual_tahsil_Faiz,0)  +  nvl(ln_nonaccrual_tahsil_faiz,0) ; 
             ln_tahsil_Vergi :=  nvl(ln_accrual_tahsil_vergi,0)  +  nvl(ln_nonaccrual_tahsil_vergi,0) ;                
          
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if; 
     
 --1.  end of grup 1  ps_program_kod =  'INTEREST-TAX'  
 
 -- E-O-M Seval.colak 05012023 EKLENDI 
------------------------------------------------------------------------------------  
 --2.  start of grup 2  ps_program_kod =  'DEFERRED-INTEREST-TAX'    
 if  ps_program_kod =   'DEFERRED-INTEREST-TAX' then   
  if nvl(ln_tahsil_deferred_interest,0) +  nvl(ln_tahsil_nonaccrual_deferred_tax,0) + nvl(ln_tahsil_accrual_deferred_tax,0) > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                  ln_tahsil_deferred_interest := ln_kalan_tahsil_tutar;                 
                if nvl(ln_tahsil_nonaccrual_deferred_tax,0) + nvl(ln_tahsil_accrual_deferred_tax,0)  <> 0   then    -- b-o-m seval.colak 01022023
                  ln_tahsil_deferred_interest_tax  := abs(nvl(ln_tahsil_deferred_interest,0) - round(((ln_tahsil_deferred_interest*100)/(100+ln_sales_tax_rate)),2));
                  ln_tahsil_deferred_interest := abs(round(((ln_tahsil_deferred_interest*100)/(100+ln_sales_tax_rate)),2));                
                end if;                                                                                             -- e-o-m seval.colak 01022023
                  
                 if nvl(ln_tahsil_deferred_interest,0) > 0 then 
                          -- B-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak                      
                          select  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_deferred_interest,0)) 
                                        else 
                                               case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_deferred_interest,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_deferred_interest,0)) 
                                                    end 
                                                 else 0 
                                                 end                        
                                        end accrual_tahsil_deferred_interest, 
                                            abs(nvl(ln_tahsil_deferred_interest,0))  - ( case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_deferred_interest,0)) 
                                        else 
                                               case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_deferred_interest,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_deferred_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_deferred_interest,0)) 
                                                    end 
                                                 else 0 
                                                 end                        
                                        end ) nonaccrual_tahsil_deferred_interest                   
                              into 
                                    ln_tahsil_accrual_deferred_interest,
                                    ln_tahsil_nonaccrual_deferred_interest                                    
                             from dual;   
                           -- E-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak 
                                                                  
                   end if;                         
     
              -- b-o-m seval.colak 01022023
             ln_tahsil_accrual_deferred_tax :=    abs(round((  nvl(ln_tahsil_accrual_deferred_interest,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ;
             if ln_tahsil_accrual_deferred_tax > ln_tahsil_deferred_interest_tax  then
                 ln_tahsil_accrual_deferred_tax :=  ln_tahsil_deferred_interest_tax ;
              end if;                 
             ln_tahsil_nonaccrual_deferred_tax:= abs( nvl(ln_tahsil_deferred_interest_tax,0) - nvl(ln_tahsil_accrual_deferred_tax,0))  ;                                   
              -- e-o-m seval.colak 01022023
              
             ln_tahsil_deferred_interest :=  nvl(ln_tahsil_accrual_deferred_interest,0)  +  nvl(ln_tahsil_nonaccrual_deferred_interest,0) ; --seval.colak 28042022
             ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_deferred_interest,0) + nvl(ln_tahsil_nonaccrual_deferred_tax,0) + nvl(ln_tahsil_accrual_deferred_tax,0) ) ;     --seval.colak 07062022 ln_tahsil_accrual_deferred_tax eklendi        
         else
            ln_tahsil_deferred_interest := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_tahsil_nonaccrual_deferred_tax   := 0;
            ln_tahsil_accrual_deferred_tax := 0;
         end if;   
      else  -- INTEREST 
                   if  ln_tahsil_deferred_interest > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_deferred_interest := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_deferred_interest := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_interest,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
           -- ACCRUAL TAX      --seval.colak 07062022          
                 if  ln_tahsil_accrual_deferred_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_accrual_deferred_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_accrual_deferred_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_accrual_deferred_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;                
                    
           -- NON ACCRUAL TAX               
                 if  ln_tahsil_nonaccrual_deferred_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_nonaccrual_deferred_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_nonaccrual_deferred_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_nonaccrual_deferred_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;
             
                   
               ln_tahsil_deferred_interest :=  nvl(ln_tahsil_accrual_deferred_interest,0)  +  nvl(ln_tahsil_nonaccrual_deferred_interest,0) ; --seval.colak 28042022         
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if; 
     
 --2.  end of grup 2  ps_program_kod =  'DEFERRED-INTEREST-TAX'    
 ------------------------------------------------------------------------------------
 --seval.colak 17122021
--2.2  start of grup 2  ps_program_kod =  'DEFERRED-DELAYED-INTEREST-TAX'
  if  ps_program_kod =   'DEFERRED-DELAYED-INTEREST-TAX' then  
   if nvl(ln_tahsil_deferred_delayed_interest,0) +  nvl(ln_tahsil_nonaccrual_deferred_delay_tax,0) + nvl(ln_tahsil_accrual_deferred_delay_tax,0)   > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                  ln_tahsil_deferred_delayed_interest := ln_kalan_tahsil_tutar;
                 if nvl(ln_tahsil_nonaccrual_deferred_delay_tax,0) + nvl(ln_tahsil_accrual_deferred_delay_tax,0)  <> 0   then    -- b-o-m seval.colak 01022023
                      ln_tahsil_deferred_delayed_interest_tax  := abs(nvl(ln_tahsil_deferred_delayed_interest,0) - round(((ln_tahsil_deferred_delayed_interest*100)/(100+ln_sales_tax_rate)),2));
                      ln_tahsil_deferred_delayed_interest := abs(round(((ln_tahsil_deferred_delayed_interest*100)/(100+ln_sales_tax_rate)),2));                
                 end if;                                                                                                         -- e-o-m seval.colak 01022023
               
               if nvl(ln_tahsil_deferred_delayed_interest,0) > 0 then 
                       -- B-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak         
                                   select  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_deferred_delayed_interest,0)) 
                                        else 
                                              case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_deferred_delayed_interest,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_deferred_delayed_interest,0)) 
                                                    end 
                                                 else 0 
                                                 end                      
                                        end accrual_tahsil_deferred_delayed_interest, 
                                             abs(nvl(ln_tahsil_deferred_delayed_interest,0))  -(  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                            abs(nvl(ln_tahsil_deferred_delayed_interest,0)) 
                                        else 
                                              case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_deferred_delayed_interest,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_deferred_delayed_interest,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_deferred_delayed_interest,0)) 
                                                    end 
                                                 else 0 
                                                 end                      
                                        end) nonaccrual_tahsil_deferred_delayed_interest
                             into 
                                    ln_tahsil_accrual_deferred_delayed_interest,
                                    ln_tahsil_nonaccrual_deferred_delayed_interest
                             from dual;                                            
                         end if;                        
            -- E-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak 
            
            -- b-o-m seval.colak 01022023
             ln_tahsil_accrual_deferred_delay_tax :=    abs(round((  nvl(ln_tahsil_accrual_deferred_delayed_interest,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ;
             if ln_tahsil_accrual_deferred_delay_tax > ln_tahsil_deferred_delayed_interest_tax  then
                 ln_tahsil_accrual_deferred_delay_tax :=  ln_tahsil_deferred_delayed_interest_tax ;
              end if;                 
             ln_tahsil_nonaccrual_deferred_delay_tax:= abs( nvl(ln_tahsil_deferred_delayed_interest_tax,0) - nvl(ln_tahsil_accrual_deferred_delay_tax,0))  ;                                   
              -- e-o-m seval.colak 01022023
            
            ln_tahsil_deferred_delayed_interest :=  nvl(ln_tahsil_accrual_deferred_delayed_interest,0)  +  nvl(ln_tahsil_nonaccrual_deferred_delayed_interest,0) ; --seval.colak 28042022
            
            ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_deferred_delayed_interest,0) + nvl(ln_tahsil_nonaccrual_deferred_delay_tax,0) + nvl(ln_tahsil_accrual_deferred_delay_tax,0) ) ; -- seval.colak 07062022 ln_tahsil_accrual_deferred_delay_tax eklendi 
         else
            ln_tahsil_deferred_delayed_interest := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_tahsil_nonaccrual_deferred_delay_tax   := 0;
         end if;   
      else  -- INTEREST 
                   if  ln_tahsil_deferred_delayed_interest > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_deferred_delayed_interest := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_deferred_delayed_interest := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_delayed_interest,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
           -- ACCRUAL TAX      --seval.colak 07062022          
                 if  ln_tahsil_accrual_deferred_delay_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_accrual_deferred_delay_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_accrual_deferred_delay_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_accrual_deferred_delay_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;                
                    
           -- NON ACCRUAL TAX               
                 if  ln_tahsil_nonaccrual_deferred_delay_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_nonaccrual_deferred_delay_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_nonaccrual_deferred_delay_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_nonaccrual_deferred_delay_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;
             
                   
               ln_tahsil_deferred_delayed_interest :=  nvl(ln_tahsil_accrual_deferred_delayed_interest,0)  +  nvl(ln_tahsil_nonaccrual_deferred_delayed_interest,0) ; --seval.colak 28042022         
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if; 
         
 --2.2  end of grup 2  ps_program_kod =  'DEFERRED-DELAYED-INTEREST-TAX'    
 ------------------------------------------------------------------------------------
--3.  start of grup 3  ps_program_kod =  'DEFERRED-TAX'   
    if  ps_program_kod =  'DEFERRED-TAX' then       
         if  ln_tahsil_deferred_tax > ln_kalan_tahsil_tutar  then
                if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                    ln_tahsil_deferred_tax := ln_kalan_tahsil_tutar;
                 else
                    ln_tahsil_deferred_tax := 0;
                    ln_kalan_tahsil_tutar   := 0;
                 end if;   
           end if; 

            ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_tax,0) ;
           if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
            end if; 
    end if;            
  --3.  end of grup 3  ps_program_kod =  'DEFERRED-TAX'              
------------------------------------------------------------------------------------            
 --4  start of grup 4  ps_program_kod =  'DEFERRED-PENALTY-TAX'
 -- seval.colak 27042022  alttaki kisim kapatildi yerine tax alan hali eklendi.   
 if  ps_program_kod =   'DEFERRED-PENALTY-TAX' then    -- seval.colak 27042022  eklendi.
  if nvl(ln_tahsil_deferred_penalty_amount,0) +  nvl(ln_tahsil_deferred_penalty_tax,0) > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
             ln_tahsil_deferred_penalty_amount := round(((ln_kalan_tahsil_tutar*100)/(100+ln_sales_tax_rate)),2);
             ln_tahsil_deferred_penalty_tax  := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_penalty_amount,0);
             ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_deferred_penalty_amount,0) + nvl(ln_tahsil_deferred_penalty_tax,0) ) ;
         else
            ln_tahsil_deferred_penalty_amount := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_tahsil_deferred_penalty_tax   := 0;
         end if;   
      else  --6.1 penalty_amount 
                   if  ln_tahsil_deferred_penalty_amount > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_deferred_penalty_amount := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_deferred_penalty_amount := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_penalty_amount,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
                    
            --6.2. penalty_tax                
                 if  ln_tahsil_deferred_penalty_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_deferred_penalty_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_deferred_penalty_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_deferred_penalty_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;    
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if;
  --4  end of grup 4  ps_program_kod =  'DEFERRED-PENALTY-TAX'            

------------------------------------------------------------------------------------            
  --5  start of grup 5  ps_program_kod = 'DELAYED-INTEREST-TAX'
  if  ps_program_kod =  'DELAYED-INTEREST-TAX' then    
      --5.4.1 birikmis_gecikme_faiz + gecikme_faiz_tax
     if nvl(ln_tahsil_birikmis_gecikme_faiz,0) +  nvl(ln_tahsil_gecikme_faiz_tax,0) > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then          
              ln_tahsil_birikmis_gecikme_faiz := ln_kalan_tahsil_tutar;
                 if   nvl(ln_tahsil_gecikme_faiz_tax,0)  <> 0   then    -- b-o-m seval.colak 01022023
                       ln_tahsil_birikmis_gecikme_faiz := ABS(round(((ln_kalan_tahsil_tutar*100)/(100+ln_sales_tax_rate)),2));
                        ln_tahsil_gecikme_faiz_tax  :=  ABS(nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_birikmis_gecikme_faiz,0));
                                   
                 end if; 
                  if nvl(ln_tahsil_birikmis_gecikme_faiz,0) > 0 then 
                -- B-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak
                            select  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                        abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) 
                                  else 
                                            case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_birikmis_gecikme_faiz,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) 
                                                    end 
                                                 else 0 
                                               end                        
                                end accrual_tahsil_gecikme_faiz, 
                                 abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0))  - ( case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                        abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) 
                                  else 
                                            case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(ln_tahsil_birikmis_gecikme_faiz,0) > 0 and  pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no) <= 0  then 
                                                  case when  abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) >  abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) then
                                                             abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) 
                                                        else
                                                            abs(nvl(ln_tahsil_birikmis_gecikme_faiz,0)) 
                                                    end 
                                                 else 0 
                                               end                        
                                end) nonaccrual_tahsil_gecikme_faiz
                       into 
                            ln_accrual_tahsil_gecikme_faiz,
                            ln_nonaccrual_tahsil_gecikme_faiz
                       from dual;
                 -- E-O-M seval.colak 05012023  accrual_status Y ise accrual bakiyeden kalan olacak.once accrual bakiye tahsil edilecek kalan nonaccrual olacak    
                 end if;     
                     
              -- b-o-m seval.colak 01022023
             ln_accrual_tahsil_gecikme_faiz_tax :=    abs(round((  nvl(ln_accrual_tahsil_gecikme_faiz,0)  * nvl(ln_sales_tax_rate,0) /100),2 )) ;
             if ln_accrual_tahsil_gecikme_faiz_tax > ln_tahsil_gecikme_faiz_tax  then
                 ln_accrual_tahsil_gecikme_faiz_tax :=  ln_tahsil_gecikme_faiz_tax ;
              end if;                 
             ln_nonaccrual_tahsil_gecikme_faiz_tax:= abs( nvl(ln_tahsil_gecikme_faiz_tax,0) - nvl(ln_accrual_tahsil_gecikme_faiz_tax,0))  ;                                   
              -- e-o-m seval.colak 01022023
              
            ln_tahsil_birikmis_gecikme_faiz :=  nvl(ln_accrual_tahsil_gecikme_faiz,0)  +  nvl(ln_nonaccrual_tahsil_gecikme_faiz,0) ;
            ln_tahsil_gecikme_faiz_tax      :=  nvl(ln_accrual_tahsil_gecikme_faiz_tax,0)  +  nvl(ln_nonaccrual_tahsil_gecikme_faiz_tax,0) ; 
            ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_birikmis_gecikme_faiz,0) + nvl(ln_nonaccrual_tahsil_gecikme_faiz_tax,0) + nvl(ln_accrual_tahsil_gecikme_faiz_tax,0) ) ;  
                                
    ---seval.colak 16122021
         else
            ln_tahsil_birikmis_gecikme_faiz := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_tahsil_gecikme_faiz_tax   := 0;
            ---seval.colak 16122021
             ln_accrual_tahsil_gecikme_faiz :=0;
             ln_nonaccrual_tahsil_gecikme_faiz := 0;
             ln_accrual_tahsil_gecikme_faiz_tax :=0;
             ln_nonaccrual_tahsil_gecikme_faiz_tax := 0;        
            ---seval.colak 16122021 
            
         end if;   
    else  -- INTEREST 
                   if  ln_tahsil_birikmis_gecikme_faiz > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_birikmis_gecikme_faiz := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_birikmis_gecikme_faiz := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_birikmis_gecikme_faiz,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
           -- ACCRUAL TAX      --seval.colak 07062022          
                 if  ln_accrual_tahsil_gecikme_faiz_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_accrual_tahsil_gecikme_faiz_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_accrual_tahsil_gecikme_faiz_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_accrual_tahsil_gecikme_faiz_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;                
                    
           -- NON ACCRUAL TAX               
                 if  ln_nonaccrual_tahsil_gecikme_faiz_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_nonaccrual_tahsil_gecikme_faiz_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_nonaccrual_tahsil_gecikme_faiz_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_nonaccrual_tahsil_gecikme_faiz_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                   end if;
             
                   
               ln_tahsil_birikmis_gecikme_faiz :=  nvl(ln_accrual_tahsil_gecikme_faiz,0)  +  nvl(ln_nonaccrual_tahsil_gecikme_faiz,0) ; 
               ln_tahsil_gecikme_faiz_tax      :=  nvl(ln_accrual_tahsil_gecikme_faiz_tax,0)  +  nvl(ln_nonaccrual_tahsil_gecikme_faiz_tax,0) ;        
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if; 
--5  end of grup 5  ps_tahsilat_islem_tipi = 'DELAYED-INTEREST-TAX'                     
------------------------------------------------------------------------------------
--6  start of grup 6  ps_tahsilat_islem_tipi = 'PENALTY-INTEREST-TAX'
--6.1 penalty_amount +tax
 if  ps_program_kod =   'PENALTY-INTEREST-TAX' then   
  if nvl(ln_tahsil_penalty_amount,0) +  nvl(ln_tahsil_penalty_tax,0) > ln_kalan_tahsil_tutar  then
         if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
             ln_tahsil_penalty_amount := round(((ln_kalan_tahsil_tutar*100)/(100+ln_sales_tax_rate)),2);
             ln_tahsil_penalty_tax  := nvl(ln_kalan_tahsil_tutar,0) - (ln_tahsil_penalty_amount);
             ln_kalan_tahsil_tutar :=  nvl(ln_kalan_tahsil_tutar,0) - ( nvl(ln_tahsil_penalty_amount,0) + ln_tahsil_penalty_tax ) ;
         else
            ln_tahsil_penalty_amount := 0;
            ln_kalan_tahsil_tutar   := 0;
            ln_tahsil_penalty_tax   := 0;
         end if;   
      else  --6.1 penalty_amount 
                   if  ln_tahsil_penalty_amount > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_penalty_amount := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_penalty_amount := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 
                   ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_penalty_amount,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;      
                    
            --6.2. penalty_tax                
                 if  ln_tahsil_penalty_tax > ln_kalan_tahsil_tutar  then
                        if  nvl(ln_kalan_tahsil_tutar,0) > 0 then 
                            ln_tahsil_penalty_tax := ln_kalan_tahsil_tutar;
                         else
                            ln_tahsil_penalty_tax := 0;
                            ln_kalan_tahsil_tutar   := 0;
                         end if;   
                   end if; 

                    ln_kalan_tahsil_tutar := nvl(ln_kalan_tahsil_tutar,0) - nvl(ln_tahsil_penalty_tax,0) ;
                   if ln_kalan_tahsil_tutar < 0 then 
                      ln_kalan_tahsil_tutar := 0;
                    end if;    
    end if;                             
    if ln_kalan_tahsil_tutar < 0 then 
              ln_kalan_tahsil_tutar := 0;
     end if; 
    end if; 
--6  end of grup 6  ps_tahsilat_islem_tipi = 'PENALTY-INTEREST-TAX'    

------------------------------------------------------------------------------------
   ln_hesaplanan_tahsil_toplam :=       ln_hesaplanan_faiz  +
                                        ln_hesaplanan_vergi                         +   
                                        ln_hesaplanan_gecenyil_faiz                 +
                                        ln_hesaplanan_gecmis_aylar_faiz             +
                                        --ln_hesaplanan_birikmis_faiz                 +
                                        ln_hesaplanan_gecenyil_komisyon             +
                                        ln_hesaplanan_gecmis_aylar_komisyon         +
                                        --ln_hesaplanan_birikmis_komisyon             +
                                        ln_hesaplanan_birikmis_gecikme_faiz         +
                                        ln_hesaplanan_gecenyil_gecikme_faiz         +
                                        ln_hesaplanan_gecenay_gecikme_faiz          +
                                        ln_hesaplanan_gecikme_faiz_tax              +
                                        ln_hesaplanan_penalty_amount                +
                                        ln_hesaplanan_penalty_tax                   +
                                        ln_hesaplanan_deferred_penalty_amount       +
                                        ln_hesaplanan_deferred_interest             +
                                        ln_hspln_deferred_delayed_interest          +
                                        ln_hesaplanan_deferred_tax                  +
                                        ln_hesaplanan_deferred_penalty_tax          + --seval.colak 27042022
                                        ln_hspln_nonaccrual_deferred_tax            + --seval.colak 28042022
                                        ln_hspln_nonaccrual_deferred_delay_tax      + --seval.colak 28042022
                                        ln_hspln_accrual_deferred_tax               + --seval.colak 07062022
                                        ln_hspln_accrual_deferred_delay_tax;          --seval.colak 07062022
            
                    TAHSILAT_HESAP(      pn_grup_no => pn_grup_no , 
                                         pn_log_no  => pn_log_no ,
                                         ps_program_kod => ps_program_kod  ,
                                         pn_islem_kod  => ln_islem_kod , 
                                         ps_tahsilat_islem_tipi => c_hesap.islem_tipi ||'-'||ps_program_kod,
                                         ps_repayment_type => c_hesap.repayment_type,
                                         ps_sube_kodu  => c_hesap.kredi_sube_kodu  ,
                                         pn_musteri_no => c_hesap.musteri_no,
                                         pn_kredi_hesap_no => c_hesap.kredi_hesap_no  ,
                                         pn_taksit_no => c_hesap.taksit_no,
                                         pn_islem_no => ln_islem_no ,
                                         pn_fis_no => ln_fis_no ,
                                         pn_Tahsilat_no => ln_Tahsilat_no ,
                                         pd_vade_tarihi => c_hesap.vade_tarihi, 
                                         pd_faiz_tahakkuk_tarihi => c_hesap.faiz_tahakkuk_tarihi, 
                                         pn_kredi_bakiye => c_hesap.kredi_bakiye,
                                         ps_kredi_doviz_kodu => c_hesap.kredi_doviz_kodu ,
                                         pn_iliskili_hesap_no => c_hesap.iliskili_hesap_no , 
                                         ps_iliskili_hesap_doviz=> c_hesap.iliskili_hesap_doviz ,
                                         pn_iliskili_hesap_bakiye => ln_iliskili_hesap_bakiye,
                                         pn_taksit_tutar => c_hesap.taksit_tutar ,
                                         pn_taksit_tahsil_tutar => c_hesap.taksit_tahsil_tutar,
                                         pn_tahsil_TOPLAM=> ln_tahsil_toplam, 
                                         pn_tahsil_anapara => 0 ,  -- pn_tahsil_anapara      
                                         pn_hesaplanan_anapara => 0 ,  -- pn_hesaplanan_anapara
                                         ps_tahakkuk_eh => c_hesap.tahakkuk_eh,
                                         ps_taksitli_mi => c_hesap.taksitli_mi,                                    
                                         pn_tahsil_faiz                          =>  ln_tahsil_faiz ,                  
                                         pn_tahsil_vergi                         => ln_tahsil_vergi                         ,      
                                         pn_tahsil_birikmis_gecikme_faiz         => ln_tahsil_birikmis_gecikme_faiz         , 
                                         pn_tahsil_penalty_amount                => ln_tahsil_penalty_amount                , 
                                         pn_tahsil_penalty_tax                   => ln_tahsil_penalty_tax                   ,
                                         pn_tahsil_deferred_penalty_tax          => ln_tahsil_deferred_penalty_tax         ,   --seval.colak 27042022  
                                         pn_tahsil_deferred_penalty_amount       => ln_tahsil_deferred_penalty_amount       ,        
                                         pn_tahsil_deferred_interest             => ln_tahsil_deferred_interest             , 
                                         pn_tahsil_deferred_tax                  => ln_tahsil_deferred_tax                  , 
                                         pn_tahsil_gecenyil_faiz                 => ln_tahsil_gecenyil_faiz                 , 
                                         pn_tahsil_gecmis_aylar_faiz             => ln_tahsil_gecmis_aylar_faiz             , 
                                         pn_tahsil_birikmis_faiz                 => ln_tahsil_birikmis_faiz                 , 
                                         pn_tahsil_gecenyil_komisyon             => ln_tahsil_gecenyil_komisyon             , 
                                         pn_tahsil_gecmis_aylar_komisyon         => ln_tahsil_gecmis_aylar_komisyon         , 
                                         pn_tahsil_birikmis_komisyon             => ln_tahsil_birikmis_komisyon             , 
                                         pn_tahsil_gecenyil_gecikme_faiz         => ln_tahsil_gecenyil_gecikme_faiz         , 
                                         pn_tahsil_gecenay_gecikme_faiz          => ln_tahsil_gecenay_gecikme_faiz          , 
                                         pn_tahsil_gecikme_faiz_tax              => ln_tahsil_gecikme_faiz_tax              ,
                                         pn_tahsil_vergi_fark                     =>ln_tahsil_vergi_fark                     ,
                                         pn_hesaplanan_faiz                       => ln_hesaplanan_faiz                          ,                  
                                         pn_hesaplanan_vergi                      => ln_hesaplanan_vergi                         ,      
                                         pn_hesaplanan_birikmis_gecikme_faiz      => ln_hesaplanan_birikmis_gecikme_faiz         , 
                                         pn_hesaplanan_penalty_amount             => ln_hesaplanan_penalty_amount                , 
                                         pn_hesaplanan_penalty_tax                => ln_hesaplanan_penalty_tax                   ,
                                         pn_hesaplanan_deferred_penalty_tax       => ln_hesaplanan_deferred_penalty_tax   ,  --seval.colak 27042022    
                                         pn_hesaplanan_deferred_penalty_amount    => ln_hesaplanan_deferred_penalty_amount,        
                                         pn_hesaplanan_deferred_interest          => ln_hesaplanan_deferred_interest , 
                                         pn_hesaplanan_deferred_tax               => ln_hesaplanan_deferred_tax , 
                                         pn_hesaplanan_gecenyil_faiz              => ln_hesaplanan_gecenyil_faiz , 
                                         pn_hesaplanan_gecmis_aylar_faiz          => ln_hesaplanan_gecmis_aylar_faiz , 
                                         pn_hesaplanan_birikmis_faiz              => ln_hesaplanan_birikmis_faiz, 
                                         pn_hesaplanan_gecenyil_komisyon          => ln_hesaplanan_gecenyil_komisyon , 
                                         pn_hesaplanan_gecmis_aylar_komisyon      => ln_hesaplanan_gecmis_aylar_komisyon , 
                                         pn_hesaplanan_birikmis_komisyon          => ln_hesaplanan_birikmis_komisyon , 
                                         pn_hesaplanan_gecenyil_gecikme_faiz      => ln_hesaplanan_gecenyil_gecikme_faiz  , 
                                         pn_hesaplanan_gecenay_gecikme_faiz       => ln_hesaplanan_gecenay_gecikme_faiz, 
                                         pn_hesaplanan_gecikme_faiz_tax           => ln_hesaplanan_gecikme_faiz_tax   ,
                                         pn_hesaplanan_toplam                     => ln_hesaplanan_tahsil_toplam ,
                                         --seval.colak 09122021
                                         pn_accrual_tahsil_Faiz                 => ln_accrual_tahsil_Faiz,
                                         pn_nonaccrual_tahsil_faiz              => ln_nonaccrual_tahsil_faiz,
                                         pn_accrual_tahsil_vergi                => ln_accrual_tahsil_vergi,
                                         pn_nonaccrual_tahsil_vergi             => ln_nonaccrual_tahsil_vergi,
                                         pn_hspln_accrual_tahsil_Faiz           => ln_hspln_accrual_tahsil_Faiz,
                                         pn_hspln_nonaccrual_tahsil_faiz        => ln_hspln_nonaccrual_tahsil_faiz,
                                         pn_hspln_accrual_tahsil_vergi          => ln_hspln_accrual_tahsil_vergi,
                                         pn_hspln_nonaccrual_tahsil_vergi       => ln_hspln_nonaccrual_tahsil_vergi,
                                         --seval.colak 09122021       
                                         -- seval.colak 16122021
                                         pn_accrual_tahsil_gecikme_faiz     => ln_accrual_tahsil_gecikme_faiz,
                                         pn_nonaccrual_tahsil_gecikme_faiz  => ln_nonaccrual_tahsil_gecikme_faiz,
                                         pn_hspln_accrual_tahsil_gecikme_faiz => ln_hspln_accrual_tahsil_gecikme_faiz,
                                         pn_hspln_nonaccrual_tahsil_gecikme_faiz  => ln_hspln_nonaccrual_tahsil_gecikme_faiz,
                                         pn_accrual_tahsil_gecikme_faiz_tax => ln_accrual_tahsil_gecikme_faiz_tax,
                                         pn_nonaccrual_tahsil_gecikme_faiz_tax => ln_nonaccrual_tahsil_gecikme_faiz_tax,
                                         pn_hspln_accrual_tahsil_gecikme_faiz_tax => ln_hspln_accrual_tahsil_gecikme_faiz_tax,
                                         pn_hspln_nonaccrual_tahsil_gecikme_faiz_tax=> ln_hspln_nonaccrual_tahsil_gecikme_faiz_tax,
                                         --seval.colak 16122021
                                         --seval.colak 17122021
                                        pn_tahsil_deferred_delayed_interest    =>     ln_tahsil_deferred_delayed_interest,
                                        pn_hspln_deferred_delayed_interest    =>     ln_hspln_deferred_delayed_interest,
                                        pn_tahsil_accrual_deferred_interest    =>     ln_tahsil_accrual_deferred_interest,
                                        pn_hspln_accrual_deferred_interest    =>     ln_hspln_accrual_deferred_interest,
                                        pn_tahsil_nonaccrual_deferred_interest    =>     ln_tahsil_nonaccrual_deferred_interest,
                                        pn_hspln_nonaccrual_deferred_interest    =>     ln_hspln_nonaccrual_deferred_interest,
                                        pn_tahsil_accrual_deferred_delayed_interest    =>     ln_tahsil_accrual_deferred_delayed_interest,
                                        pn_hspln_accrual_deferred_delayed_interest    =>     ln_hspln_accrual_deferred_delayed_interest,
                                        pn_tahsil_nonaccrual_deferred_delayed_interest    =>     ln_tahsil_nonaccrual_deferred_delayed_interest,
                                        pn_hspln_nonaccrual_deferred_delayed_interest    =>     ln_hspln_nonaccrual_deferred_delayed_interest,
                                        --seval.colak 17122021                                          
                                       --seval.colak 07062022
                                        pn_tahsil_accrual_deferred_tax        => ln_tahsil_accrual_deferred_tax ,
                                        pn_hspln_accrual_deferred_tax         => ln_hspln_accrual_deferred_tax ,
                                        pn_tahsil_accrual_deferred_delay_tax  => ln_tahsil_accrual_deferred_delay_tax ,  
                                        pn_hspln_accrual_deferred_delay_tax   => ln_hspln_accrual_deferred_delay_tax  ,
                                        pn_tahsil_nonaccrual_deferred_tax        => ln_tahsil_nonaccrual_deferred_tax ,
                                        pn_hspln_nonaccrual_deferred_tax         => ln_hspln_nonaccrual_deferred_tax ,
                                        pn_tahsil_nonaccrual_deferred_delay_tax  => ln_tahsil_nonaccrual_deferred_delay_tax ,  
                                        pn_hspln_nonaccrual_deferred_delay_tax   => ln_hspln_nonaccrual_deferred_delay_tax                                         
                                          --seval.colak 07062022        
                                ); 
          end if;
          
       END IF;
      END IF ;  -- seval.colak 20022023  process sirali olarak calismasi icin  eklenen kontrol degerleri 
    END loop; 
 
    commit;
 
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
   
  EXCEPTION
    WHEN OTHERS THEN
     rollback;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;  
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE KREDI_TAHSILAT(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2  ,ps_transfer_Arbitrage_E varchar2 default 'H')
is 
Begin
    
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    
    if  (pkg_tarih.gun_ozellik(trunc(sysdate)) = 0  ) --working day  
        or  ( nvl(pn_grup_no,0) <> 0 and  nvl(pn_log_no,0) <> 0  ) then  -- called via eod process
        
    if ps_transfer_Arbitrage_E ='E' then 
        transfer_arbitrage  (pn_grup_no , pn_log_no ,'TRANSFER_ARBITRAGE') ;
    end if;    
    anapara_tahsilat    (pn_grup_no , pn_log_no ,'PRINCIPAL'  ) ; --1.
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'DEFERRED-INTEREST-TAX'); --2.
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'DEFERRED-DELAYED-INTEREST-TAX'); --3. --seval.colak 17122021
   -- faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'DEFERRED-TAX'); --seval.colak 31012023 bu kisim calismayacak DEFERRED-INTEREST-TAX  icinde tax aliniyor olacak 
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'DEFERRED-PENALTY-TAX');--4. --seval.colak 'DEFERRED-PENALTY' >'DEFERRED-PENALTY-TAX' olarak degistirildi.
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'INTEREST-TAX'); --5.
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'DELAYED-INTEREST-TAX');--6.
    faiz_vergi_deferrred_delayed_penalty  (pn_grup_no , pn_log_no ,'PENALTY-INTEREST-TAX');--7.
    Main_Loan_Accrual_Closing(pn_grup_no , pn_log_no ,'MAIN_LOAN_ACCRUAL_CLOSING');--seval.colak 08122022
    commit;
    else
     Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,'Non working days not running');
    end if;
    
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN 
      rollback;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE KREDI_TAHSILAT_TRANSFERSIZ(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is 
Begin
     
    pkg_kredi_tahsilat.kredi_tahsilat(pn_grup_no , pn_log_no ,ps_program_kod , 'H');
 END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE KREDI_TAHSILAT_TRANSFERLI(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) 
is 
Begin
    delete from cbs_rpt_kredi_transfer  --seval.colak 05052022
    where banka_tarihi =pkg_muhasebe.banka_tarihi_bul;
    
    commit;
     pkg_kredi_tahsilat.kredi_tahsilat(pn_grup_no , pn_log_no ,ps_program_kod , 'E');
 END;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--AccrualKrediHesapAcilis_Full tek sefer calistirilacatir. Conversion sirasinda mevcut olan tum acik kredilere accrual int ve tax hesaplarin acilmasi icin hazirlandi.
 PROCEDURE AccrualKrediHesapAcilis_Full(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ,pn_kredi_hesap_no number default null )
 IS
    ld_banka_tarihi                 DATE :=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ld_sonraki_banka_tarihi         DATE :=Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
    ld_onceki_banka_tarihi          DATE :=Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;
    
    ln_bugun                        NUMBER;
    ln_yarin                        NUMBER;
    ln_songun                       NUMBER;
    ln_gun_farki                    NUMBER;
    ln_durum_kodu                   NUMBER:=0;
    ln_faiz                         NUMBER ;
    ln_tutar                        NUMBER ;
    ln_komisyon                     NUMBER ;
    ln_penalty_faiz                 NUMBER ;
    ln_tx_no                        number := 0;       
    ln_fis_no                       number := 0;
    ln_accrual_tax_hesap_no         number := 0;
    ln_accrual_faiz_hesap_no        number := 0;
    ln_nonaccrual_int_account_no    number := 0;
    ln_nonaccrual_delayed_int_account_no   number := 0;
    ls_hata_var                     varchar2(1):= 'H';
    ls_banka_aciklama               varchar2(2000);
    ls_musteri_aciklama             varchar2(2000);  
    ls_islem_aciklama               varchar2(2000);
    ls_fis_aciklama                 varchar2(2000);
    ls_aciklama                     varchar2(2000);    
    ls_doviz_kodu                   varchar2(3);
    ls_mesaj                        varchar2(2000):= '';
    ls_bolum_kodu                    cbs_hesap_kredi.sube_kodu%type;
    ln_islem_no                      number;
    ln_hesap_no                      number:=0;   
  --  ln_vergi_tahakkuk_tutar          number:=0;  
    ls_accrual_tax_hesap_durum      varchar2(1) ;
    ls_accrual_faiz_hesap_durum     varchar2(1) ;
    ls_nonaccrual_delayed_int_account_durum  varchar2(1) ;
    ls_nonaccrual_int_account_durum  varchar2(1) ;
    ln_accrual_delayed_int_account_no   NUMBER;     --seval.colak 07122021
    ls_accrual_delayed_int_account_durum  varchar2(1) ;
   ---------------
   CURSOR cur_hesap IS
        select  hesap_no,
                a.modul_tur_kod,
                a.urun_tur_kod,
                a.urun_sinif_kod,
                accrual_tax_account_no,
                accrual_int_account_no,
                nonaccrual_int_account_no,
                nonaccrual_delayed_int_account_no,
                accrual_delayed_int_account_no,
                PKG_MUSTERI.SF_MUSTERI_DK_GRUP_KOD_AL(a.musteri_no) dk_grup_kod
         from cbs_hesap_kredi  a,cbs_urun_sinif b
         where a.hesap_no = nvl(pn_kredi_hesap_no,a.hesap_no) and
                a.durum_kodu = 'A' and 
               a.modul_tur_kod = b.modul_tur_kod and
               a.urun_tur_kod = b.urun_tur_kod and
               a.urun_sinif_kod = b.kod and
               b.nakdi= 'E' and
               a.urun_tur_kod <> 'PAST DUE' and 
               substr(a.urun_tur_kod,1,3) <> 'PD-' and
               a.urun_tur_kod not like '%CARD%' and
               a.urun_sinif_kod not like '%CARD%' and
               /*( nvl(accrual_tax_account_no,0) = 0 or nvl(accrual_int_account_no,0) = 0  or
                 nvl(nonaccrual_int_account_no,0) = 0 or nvl(nonaccrual_delayed_int_account_no,0) = 0 or 
                 nvl(accrual_delayed_int_account_no,0) = 0 
                )  and */
                 a.urun_tur_kod not in ('ACCRUAL','PAST DUE','NONACCRUAL')               
         order by hesap_no; 
         ls_hata_urun varchar2(2000);  
   BEGIN
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   for c_hesap in cur_hesap loop
      
        ln_hesap_no := c_hesap.hesap_no;
        ln_accrual_tax_hesap_no := c_hesap.accrual_tax_account_no;
        ln_accrual_faiz_hesap_no := c_hesap.accrual_int_account_no; 
        ln_nonaccrual_delayed_int_account_no := c_hesap.nonaccrual_delayed_int_account_no;
        ln_nonaccrual_int_account_no := c_hesap.nonaccrual_int_account_no;  
        ln_accrual_delayed_int_account_no   := c_hesap.accrual_delayed_int_account_no; 
         ls_hata_urun  := null;
        --accrual hesap acilis
       
        if nvl(ln_accrual_tax_hesap_no,0) <> 0 then  
            select durum_kodu
            into   ls_accrual_tax_hesap_durum 
            from cbs_hesap_kredi
            where hesap_no = ln_accrual_tax_hesap_no  ;
             if ls_accrual_tax_hesap_durum <> 'A' then 
                ln_accrual_tax_hesap_no := null;
             end if; 
        end if;    

         if nvl(ln_accrual_faiz_hesap_no,0) <> 0 then  
            select durum_kodu
            into   ls_accrual_faiz_hesap_durum 
            from cbs_hesap_kredi
            where hesap_no = ln_accrual_faiz_hesap_no  ;
             if ls_accrual_faiz_hesap_durum <> 'A' then 
                ln_accrual_faiz_hesap_no := null;
             end if; 
         end if;               
      -- seval.colak 26112021 
        if nvl(ln_nonaccrual_delayed_int_account_no,0) <> 0 then  
            select durum_kodu
            into   ls_nonaccrual_delayed_int_account_durum 
            from cbs_hesap_kredi
            where hesap_no = ln_nonaccrual_delayed_int_account_no  ;
             if ls_nonaccrual_delayed_int_account_durum <> 'A' then 
                ln_nonaccrual_delayed_int_account_no := null;
             end if; 
        end if;       
        if nvl(ln_nonaccrual_int_account_no,0) <> 0 then  
            select durum_kodu
            into   ls_nonaccrual_int_account_durum 
            from cbs_hesap_kredi
            where hesap_no = ln_nonaccrual_int_account_no  ;
             if ls_nonaccrual_int_account_durum <> 'A' then 
                ln_nonaccrual_int_account_no := null;
             end if; 
        end if;        
            
         if nvl(ln_accrual_delayed_int_account_no,0) <> 0 then      --seval.colak 07122021
            select durum_kodu
            into   ls_accrual_delayed_int_account_durum 
            from cbs_hesap_kredi
            where hesap_no = ln_accrual_delayed_int_account_no  ;
             if ls_accrual_delayed_int_account_durum <> 'A' then 
                ln_accrual_delayed_int_account_no := null;
             end if; 
        end if; 
       
        begin
         ls_hata_urun  := 'ACCRUAL-INTEREST';
         IF  nvl(ln_accrual_faiz_hesap_no,0) = 0 THEN
             PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(    c_hesap.hesap_no,
                                                  --  c_hesap.iliskili_hesap_no,
                                                    ln_islem_no,
                                                    ln_islem_no,
                                                    0,--c_hesap.faiz_tahakkuk_tutar,
                                                    'ACCRUAL-INTEREST',
                                                    ln_accrual_faiz_hesap_no
                                                    ) ;
                                                     
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_accrual_faiz_hesap_no)||Pkg_Hata.GetDelimiter||'ACCRUAL-INTEREST'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
            commit;                                                    
            END IF;  
         exception when others then  rollback;
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6869'||Pkg_Hata.GetDelimiter||ls_hata_urun||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetDelimiter||c_hesap.dk_grup_kod||';' || c_hesap.urun_tur_kod ||';'||c_hesap.urun_sinif_kod||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       end;
      
        begin
        ls_hata_urun  := 'ACCRUAL-TAX';
         IF  nvl( ln_accrual_tax_hesap_no,0) = 0  THEN
              PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(c_hesap.hesap_no,
                                                              --  c_hesap.iliskili_hesap_no,
                                                                ln_islem_no,
                                                                ln_islem_no,
                                                                0 ,--ln_vergi_tahakkuk_tutar,
                                                                'ACCRUAL-TAX',
                                                                ln_accrual_tax_hesap_no ) ;
                                                                
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_accrual_tax_hesap_no)||Pkg_Hata.GetDelimiter||'ACCRUAL-TAX'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
            commit;
          END IF;
           exception when others then  rollback;
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6869'||Pkg_Hata.GetDelimiter||ls_hata_urun||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetDelimiter||c_hesap.dk_grup_kod||';' || c_hesap.urun_tur_kod ||';'||c_hesap.urun_sinif_kod||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       end;
 
         -- B-O-M seval.colak 07122021
         begin
         ls_hata_urun  := 'ACCRUAL-DELAYED-INTEREST';
         IF  nvl(ln_accrual_delayed_int_account_no,0) = 0  AND  pkg_odeme_plan.sf_urun_tahakkuk_eh(C_hesap.modul_tur_kod,c_hesap.urun_tur_kod,c_hesap.urun_sinif_kod) = 'E'  THEN
             PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(    c_hesap.hesap_no,
                                                  --  c_hesap.iliskili_hesap_no,
                                                    ln_islem_no,
                                                    ln_islem_no,
                                                    0,--c_hesap.faiz_tahakkuk_tutar,
                                                    'ACCRUAL-DELAYED-INTEREST',
                                                    ln_accrual_delayed_int_account_no
                                                    ) ;
              Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_accrual_delayed_int_account_no)||Pkg_Hata.GetDelimiter||'ACCRUAL-DELAYED-INTEREST'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
              commit;
         END IF;  
          exception when others then  rollback;
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6869'||Pkg_Hata.GetDelimiter||ls_hata_urun||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetDelimiter||c_hesap.dk_grup_kod||';' || c_hesap.urun_tur_kod ||';'||c_hesap.urun_sinif_kod||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       end;
 
        -- E-O-M seval.colak 07122021
         begin
            ls_hata_urun  := 'NONACCRUAL-INTEREST';
         IF  nvl(ln_nonaccrual_int_account_no,0) = 0  AND  pkg_odeme_plan.sf_urun_tahakkuk_eh(C_hesap.modul_tur_kod,c_hesap.urun_tur_kod,c_hesap.urun_sinif_kod) = 'E'  THEN
            PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(    c_hesap.hesap_no,
                                                  --  c_hesap.iliskili_hesap_no,
                                                    ln_islem_no,
                                                    ln_islem_no,
                                                    0,--c_hesap.faiz_tahakkuk_tutar,
                                                    'NONACCRUAL-INTEREST',
                                                    ln_nonaccrual_int_account_no
                                                    ) ;
            Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_nonaccrual_int_account_no)||Pkg_Hata.GetDelimiter||'NONACCRUAL-INTEREST'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
            commit;
            END IF; 
            exception when others then  rollback;
           Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6869'||Pkg_Hata.GetDelimiter||ls_hata_urun||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetDelimiter||c_hesap.dk_grup_kod||';' || c_hesap.urun_tur_kod ||';'||c_hesap.urun_sinif_kod||Pkg_Hata.GetUCPOINTER,ln_islem_no);
        end;
     
         begin 
          ls_hata_urun  := 'NONACCRUAL-DELAYED-INTEREST';
         IF  nvl(ln_nonaccrual_delayed_int_account_no,0) = 0  AND  pkg_odeme_plan.sf_urun_tahakkuk_eh(C_hesap.modul_tur_kod,c_hesap.urun_tur_kod,c_hesap.urun_sinif_kod) = 'E'  THEN
            PKG_KREDI_TAHSILAT.sf_pastdue_accrual_kredi_hesap_ac(    c_hesap.hesap_no,
                                                  --  c_hesap.iliskili_hesap_no,
                                                    ln_islem_no,
                                                    ln_islem_no,
                                                    0,--c_hesap.faiz_tahakkuk_tutar,
                                                    'NONACCRUAL-DELAYED-INTEREST',
                                                    ln_nonaccrual_delayed_int_account_no
                                                    ) ;
              Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6857'||Pkg_Hata.GetDelimiter||TO_CHAR(ln_nonaccrual_delayed_int_account_no)||Pkg_Hata.GetDelimiter||'NONACCRUAL-DELAYED-INTEREST'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetUCPOINTER,ln_islem_no);
              commit;
         END IF;   
        commit;
        exception when others then  rollback;
          Pkg_Batch.Logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6869'||Pkg_Hata.GetDelimiter||ls_hata_urun||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_no)||Pkg_Hata.GetDelimiter||c_hesap.dk_grup_kod||';' || c_hesap.urun_tur_kod ||';'||c_hesap.urun_sinif_kod||Pkg_Hata.GetUCPOINTER,ln_islem_no);
       end;
        
        commit;
    end loop;
 commit;
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
  EXCEPTION
    WHEN OTHERS THEN
        rollback;
    LOG_AT('AccrualKrediHesapAcilis_Full',ln_hesap_no,ln_fis_no,TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM) );
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,'Account No:'||ln_hesap_no ||' '||TO_CHAR(SQLCODE) || ' ' ||TO_CHAR(SQLERRM));
  END;
-------------------------------------------------------------------------------------------------------------------------
--seval.colak 13042022
PROCEDURE NONACCRUAL_STATUS_UPDATE(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

        CURSOR c1 IS
        select hesap_no ,accrual_status_upd_date from CBS_HESAP_KREDI k 
        where K.durum_kodu= 'A' and 
             nvl(non_accrual_status,'N') = 'N' 
             and (  NVL(FAIZ_GECIKME_GUN_SAYISI,0) >=90 OR NVL(AP_GECIKME_GUN_SAYISI,0)  >=90 );             
        r_c1                         c1%ROWTYPE;
       
  BEGIN
        pkg_batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

        open c1;
        loop
            fetch c1 into r_c1;
            exit when c1%notfound;

            pkg_kredi_tahsilat.sf_nonaccrual_accounts_opening(r_c1.hesap_no);
            
            update cbs_hesap_kredi k
            set k.non_accrual_status = 'Y',
                k.non_accrual_status_upd_date = pkg_muhasebe.banka_tarihi_bul
             where hesap_no=r_c1.hesap_no;
            --b-o-m seval.colak 02112022 
            insert into cbs_hesap_kredi_accr_status_tx( banka_tarihi,
                                                        hesap_no,
                                                        non_accrual_status,
                                                        non_accrual_status_upd_date,
                                                        accrual_status_upd_date,
                                                        yaratan_tx_no,
                                                        grup_no,
                                                        log_no  )
                values  (pkg_muhasebe.banka_tarihi_bul,
                        r_c1.hesap_no,
                        'Y',
                        pkg_muhasebe.banka_tarihi_bul,
                        r_c1.accrual_status_upd_date,
                        0,
                         pn_grup_no,
                        pn_log_no);
            --e-o-m seval.colak 02112022
        
        end loop;
        close c1;

        commit;
      pkg_batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END; 
  --------------------------------------------------------------------------------------------------------
     Procedure sf_min_odenmemis_taksiti_bul (pn_hesap_no cbs_hesap_kredi.hesap_no%type,    --seval.colak  25052022
			 								 pn_taksit_sira_no  out number,
											 pd_taksit_vade out date )
	 is

	 Begin
	 	  select min(sira_no),min( vade_tarih)
		  into pn_taksit_sira_no  ,pd_taksit_vade
		  FROM CBS_hesap_kredi_taksit
		  where hesap_no = pn_hesap_no and		  	
				durum_kodu = 'A';

	  Exception when others then null;

	 End;
  
 PROCEDURE sp_tahsilat_tutar_bilgi_al(         pn_hesap_no number ,        --seval.colak 20052022
                                                 ps_geriodeme_kapama_Secimi varchar2 default NULL,
                                                 pn_tahsil_anapara    OUT number,
                                                 pn_tahsil_faiz    OUT number,
                                                 pn_tahsil_vergi    OUT number,                                              
                                                 pn_tahsil_birikmis_gecikme_faiz    OUT number,
                                                 pn_tahsil_gecikme_faiz_tax    OUT number,
                                                 pn_tahsil_penalty_amount    OUT number,
                                                 pn_tahsil_penalty_tax    OUT number ,
                                                 pn_tahsil_deferred_interest    out number,
                                                 pn_tahsil_deferred_interest_tax    out number,
                                                 pn_tahsil_deferred_delayed_interest    out number,
                                                 pn_tahsil_deferred_delayed_int_tax    out number,
                                                 pn_tahsil_deferred_tax    out number,
                                                 pn_tahsil_deferred_penalty_amount    out number,
                                                 pn_tahsil_deferred_penalty_tax    out number,
                                                 pn_min_odenmemis_taksit_no out number,
                                                 pd_min_odenmemis_taksit_vade out date                                                
                                                 )
 IS
 
     ld_banka_tarihi             date := Pkg_Muhasebe.Banka_Tarihi_Bul;
     ld_sonraki_banka_tarihi     date := Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
     ld_onceki_banka_tarihi      date := Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;
     ln_sales_tax_rate           number := 0;
     ln_taksit_no                number := 0;
     ld_taksit_vade              date  :=null; 
     ln_tahsil_birikmis_faiz          number := 0 ;
     ln_Bakiye                        number := 0 ;
     ln_ara_odeme_tutar               number := 0 ;
     ln_odeme_plan_no                 number := 0;
     ln_tahsil_birikmis_faiz_vergi    number := 0;         
       -- abs(pkg_kredi.sf_bakiye_al(a.hesap_no)) 
 cursor cur_hesap is  
 select  -- 'TAKSITLI'  islem_tipi,         
         sum(nvl(b.anapara,0)-nvl(b.tahsil_anapara,0))  tahsil_anapara   ,
        sum( abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) ) tahsil_Faiz,
        sum(abs(nvl(b.bsmv,0) - nvl(b.tahsil_bsmv,0)) ) tahsil_Vergi,        
        sum(case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 then  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) else 0 end )  tahsil_birikmis_gecikme_faiz,
        sum(abs(round((  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))* nvl(ln_sales_tax_rate,0) /100),2 )) )  tahsil_gecikme_faiz_tax,
        sum(case when abs(nvl(b.penalty_amount,0) - nvl(b.paid_penalty_amount,0)) > 0 then abs(nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) else 0 end ) tahsil_penalty_amount,
        sum(abs(round((  case when abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) > 0 then  abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 )))  tahsil_penalty_tax,
        sum(abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) )  tahsil_deferred_interest,
        sum( round((abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0))* nvl(ln_sales_tax_rate,0) /100),2 ) )  tahsil_deferred_interest_tax,
        sum(abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
        sum( round((abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))* nvl(ln_sales_tax_rate,0) /100),2 ) )  tahsil_deferred_delayed_int_tax,
        sum(0) tahsil_deferred_tax,   --seval.colak 29082022  deferred_tax artik kullanilmayacak -- sum(abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) )tahsil_deferred_tax ,  
        sum(case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end  ) tahsil_deferred_penalty_amount,
        sum(abs(round(( case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100),2 )))   tahsil_deferred_penalty_tax         
from cbs_hesap_kredi a,cbs_hesap_kredi_taksit b
where a.hesap_no = b.hesap_no and  
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           a.hesap_no = pn_hesap_no and 
           a.repayment_type = 'INSTALLMENT DATE' and          
           ( (  ps_geriodeme_kapama_Secimi = 'TAKSIT' and b.sira_no =ln_taksit_no ) or
             (  nvl(ps_geriodeme_kapama_Secimi,'ARA') in ('ARA','KAPAMA')) )             
           
union all      
       select-- distinct 'TAKSITSIZ' islem_tipi,
             abs(nvl(c.bakiye,0))  tahsil_anapara   ,
             round(abs(NVL(birikmis_faiz_tutari,0)),2) tahsil_faiz,
             abs(round(( NVL(birikmis_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_Vergi  ,
              abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2))  tahsil_birikmis_gecikme_faiz,
              abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_gecikme_faiz_tax,  
              case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end tahsil_penalty_amount,
              round(case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100,2)  tahsil_penalty_tax,
             0  tahsil_deferred_interest,
             0  tahsil_deferred_interest_tax,
             0  tahsil_deferred_delayed_interest,
             0  tahsil_deferred_delayed_int_tax,
             0 tahsil_deferred_tax  ,
             0 tahsil_deferred_penalty_amount ,
              0 tahsil_deferred_penalty_tax   
       from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and  
           a.durum_kodu = 'A' and 
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and
            a.hesap_no = pn_hesap_no ;
           
 BEGIN
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 
  
     
         select    round(abs(NVL(birikmis_faiz_tutari,0)),2)   tahsil_birikmis_faiz, 
                    abs(round(( NVL(birikmis_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 )) tahsil_birikmis_faiz_vergi,
                   abs(pkg_kredi.sf_bakiye_al(hesap_no)) bakiye,
                   abs(nvl(ara_odeme_tutar,0)) ln_ara_odeme_tutar,
                   odeme_plan_no
         into ln_tahsil_birikmis_faiz ,
              ln_tahsil_birikmis_faiz_vergi ,
              ln_Bakiye ,
              ln_ara_odeme_tutar,
              ln_odeme_plan_no
         from cbs_hesap_kredi 
         where hesap_No = pn_hesap_No ;    
      
  if  nvl(ps_geriodeme_kapama_Secimi,'KAPAMA') = 'TAKSIT' then
        pkg_kredi_tahsilat.sf_min_odenmemis_taksiti_bul(pn_hesap_no,ln_taksit_no,ld_taksit_vade );
          pn_min_odenmemis_taksit_no := ln_taksit_no;
          pd_min_odenmemis_taksit_vade := ld_taksit_vade;      
   end if;
         
       
    for c_hesap in cur_hesap loop
        pn_tahsil_anapara	                    :=	c_hesap.tahsil_anapara ;
        pn_tahsil_faiz	                        :=	c_hesap.tahsil_faiz	;
        pn_tahsil_vergi	                        :=	c_hesap.tahsil_vergi	;
        pn_tahsil_birikmis_gecikme_faiz     	:=	c_hesap.tahsil_birikmis_gecikme_faiz	;
        pn_tahsil_gecikme_faiz_tax	            :=	c_hesap.tahsil_gecikme_faiz_tax	;
        pn_tahsil_penalty_amount	            :=	c_hesap.tahsil_penalty_amount	;
        pn_tahsil_penalty_tax	                :=	c_hesap.tahsil_penalty_tax	;
        pn_tahsil_deferred_interest	            :=	c_hesap.tahsil_deferred_interest	;
        pn_tahsil_deferred_interest_tax         :=	c_hesap.tahsil_deferred_interest_tax	;
        pn_tahsil_deferred_delayed_interest	    :=	c_hesap.tahsil_deferred_delayed_interest	;
        pn_tahsil_deferred_delayed_int_tax      :=	c_hesap.tahsil_deferred_delayed_int_tax	;
        pn_tahsil_deferred_tax	                :=	c_hesap.tahsil_deferred_tax	;
        pn_tahsil_deferred_penalty_amount	    :=	c_hesap.tahsil_deferred_penalty_amount	;
        pn_tahsil_deferred_penalty_tax	        :=	c_hesap.tahsil_deferred_penalty_tax	;
     end loop;
            if  nvl(ps_geriodeme_kapama_Secimi,'KAPAMA') in ('ARA','KAPAMA') then            
                pn_tahsil_faiz := ln_tahsil_birikmis_faiz ;   
                 pn_tahsil_vergi := ln_tahsil_birikmis_faiz_vergi ;             
                pn_tahsil_anapara := ln_bakiye  ;                      
           end if;
          
                
  Exception when others then 
      log_at('PKG_KREDI_TAHSILAT','sp_tahsilat_tutar_bilgisi_al',pn_hesap_no,to_char(sqlcode) || ' ' ||to_char(sqlerrm) );
 END;
----------------------------------------------------------------------------------------------
  PROCEDURE sp_tahsilat_tutar_isl_bilgi_al(      pn_tx_no number,
                                                 pn_hesap_no number ,        --seval.colak 20052022
                                                 ps_geriodeme_kapama_Secimi varchar2 default NULL,
                                                 pn_tahsil_anapara    OUT number,
                                                 pn_tahsil_faiz    OUT number,
                                                 pn_tahsil_vergi    OUT number,                                              
                                                 pn_tahsil_birikmis_gecikme_faiz    OUT number,
                                                 pn_tahsil_gecikme_faiz_tax    OUT number,
                                                 pn_tahsil_penalty_amount    OUT number,
                                                 pn_tahsil_penalty_tax    OUT number ,
                                                 pn_tahsil_deferred_interest    out number,
                                                 pn_tahsil_deferred_interest_tax    out number,
                                                 pn_tahsil_deferred_delayed_interest    out number,
                                                 pn_tahsil_deferred_delayed_int_tax    out number,
                                                 pn_tahsil_deferred_tax    out number,
                                                 pn_tahsil_deferred_penalty_amount    out number,
                                                 pn_tahsil_deferred_penalty_tax    out number,
                                                 pn_min_odenmemis_taksit_no out number,
                                                 pd_min_odenmemis_taksit_vade out date                                                
                                                 )
 IS
 
     ld_banka_tarihi             date := Pkg_Muhasebe.Banka_Tarihi_Bul;
     ld_sonraki_banka_tarihi     date := Pkg_Muhasebe.Sonraki_Banka_Tarihi_Bul;
     ld_onceki_banka_tarihi      date := Pkg_Muhasebe.onceki_Banka_Tarihi_Bul;
     ln_sales_tax_rate           number := 0;
     ln_taksit_no                number := 0;
     ld_taksit_vade              date  :=null; 
     ln_tahsil_birikmis_faiz        number := 0 ;
     ln_Bakiye                    number := 0 ;
     ln_ara_odeme_tutar             number := 0 ;
     ln_odeme_plan_no                number := 0;
     ln_tahsil_birikmis_faiz_vergi   number := 0;
                
       -- abs(pkg_kredi.sf_bakiye_al(a.hesap_no)) 
 cursor cur_hesap is  
 select  -- 'TAKSITLI'  islem_tipi,         
         sum(nvl(b.anapara,0)-nvl(b.tahsil_anapara,0))  tahsil_anapara   ,
        sum( abs( nvl(b.faiz,0) - nvl(b.tahsil_faiz,0)) ) tahsil_Faiz,
        sum(abs(nvl(b.bsmv,0) - nvl(b.tahsil_bsmv,0)) ) tahsil_Vergi,        
        sum(case when  abs( nvl(b.gecikme_faiz_tutari,0) - nvl(b.tahsil_gecikme_faiz_tutari,0)) > 0 then  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0)) else 0 end )  tahsil_birikmis_gecikme_faiz,
        sum(abs(round((  abs( nvl(b.gecikme_faiz_tutari,0)-nvl(b.tahsil_gecikme_faiz_tutari,0))* nvl(ln_sales_tax_rate,0) /100),2 )) )  tahsil_gecikme_faiz_tax,
        sum(case when abs(nvl(b.penalty_amount,0) - nvl(b.paid_penalty_amount,0)) > 0 then abs(nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) else 0 end ) tahsil_penalty_amount,
        sum(abs(round((  case when abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0)) > 0 then  abs( nvl(b.penalty_amount,0)-nvl(b.paid_penalty_amount,0))  else 0 end * nvl(ln_sales_tax_rate,0) /100),2 )))  tahsil_penalty_tax,
        sum(abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0)) )  tahsil_deferred_interest,
        sum( round((abs(nvl(b.deferred_interest,0)-nvl(b.paid_deferred_interest,0))* nvl(ln_sales_tax_rate,0) /100),2 ) )  tahsil_deferred_interest_tax,
        sum(abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
        sum( round((abs(nvl(b.deferred_delayed_interest,0)-nvl(b.paid_deferred_delayed_interest,0))* nvl(ln_sales_tax_rate,0) /100),2 ) )  tahsil_deferred_delayed_int_tax,
        sum(0) tahsil_deferred_tax ,  --seval.colak 29082022  deferred_tax artik kullanilmayacak  -- sum(abs( nvl(b.deferred_tax,0)-nvl(b.paid_deferred_tax,0)) )tahsil_deferred_tax ,
        sum(case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end  ) tahsil_deferred_penalty_amount,
        sum(abs(round(( case when abs(nvl(b.deferred_penalty_amount,0)- nvl(b.paid_deferred_penalty_amount,0)) > 0 then abs(nvl(b.deferred_penalty_amount,0)-nvl(b.paid_deferred_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100),2 )))   tahsil_deferred_penalty_tax         
from cbs_hesap_kredi_islem a,cbs_hesap_kredi_taksit_islem b
where      a.tx_no = b.tx_no and
           a.tx_No = pn_tx_no and 
           a.hesap_no = b.hesap_no and  
           a.durum_kodu = 'A' and 
           b.durum_kodu = 'A' and 
           a.hesap_no = pn_hesap_no and 
           a.repayment_type = 'INSTALLMENT DATE' and          
           ( (  ps_geriodeme_kapama_Secimi = 'TAKSIT' and b.sira_no =ln_taksit_no ) or
             (  nvl(ps_geriodeme_kapama_Secimi,'ARA') in ('ARA','KAPAMA')) )             
           
union all      -- taksitsizlerde ana tablodan alinabilir ,taksitli ara odemelerde plan degistigi icin islemden alinmali.
       select-- distinct 'TAKSITSIZ' islem_tipi,
               abs(nvl(c.bakiye,0))  tahsil_anapara   ,
              round(abs(NVL(birikmis_faiz_tutari,0)),2) tahsil_faiz,
              abs(round(( NVL(birikmis_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_Vergi  ,
              abs(round(nvl(birikmis_gecikme_faiz_tutari,0),2))  tahsil_birikmis_gecikme_faiz,
              abs(round(( NVL(birikmis_gecikme_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_gecikme_faiz_tax,  
              case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end tahsil_penalty_amount,
              round(case when abs(nvl(a.penalty_amount,0) - nvl(a.paid_penalty_amount,0)) > 0 then abs(nvl(a.penalty_amount,0)-nvl(a.paid_penalty_amount,0)) else 0 end * nvl(ln_sales_tax_rate,0) /100,2)  tahsil_penalty_tax,
             0  tahsil_deferred_interest,
             0  tahsil_deferred_interest_tax,
             0  tahsil_deferred_delayed_interest,
             0  tahsil_deferred_delayed_int_tax,
             0  tahsil_deferred_tax  ,
             0  tahsil_deferred_penalty_amount ,
             0 tahsil_deferred_penalty_tax   
       from cbs_hesap_kredi a,cbs_hesap_bakiye c
     where a.hesap_no = c.hesap_no and  
           a.durum_kodu = 'A' and 
           nvl(a.repayment_type, 'MATURITY DATE') = 'MATURITY DATE' and
            a.hesap_no = pn_hesap_no ;
           
 BEGIN
    pkg_parametre.deger('G_SALES_TAX_RATE', ln_sales_tax_rate); 
         select    round(abs(NVL(birikmis_faiz_tutari,0)),2)   tahsil_birikmis_faiz, 
                   abs(round(( NVL(birikmis_faiz_tutari,0)* nvl(ln_sales_tax_rate,0) /100),2 ))  tahsil_birikmis_faiz_vergi, 
                   abs( pkg_kredi.sf_bakiye_al(hesap_no)) bakiye,
                   abs(nvl(ara_odeme_tutar,0)) ln_ara_odeme_tutar,
                   odeme_plan_no
         into ln_tahsil_birikmis_faiz ,
               ln_tahsil_birikmis_faiz_vergi,
               ln_Bakiye ,
               ln_ara_odeme_tutar,
               ln_odeme_plan_no
         from cbs_hesap_kredi 
         where hesap_No = pn_hesap_No ;    
      
  if  nvl(ps_geriodeme_kapama_Secimi,'KAPAMA') = 'TAKSIT' then
        pkg_kredi_Tahsilat.sf_min_odenmemis_taksiti_bul(pn_hesap_no,ln_taksit_no,ld_taksit_vade );
        pn_min_odenmemis_taksit_no := ln_taksit_no;
        pd_min_odenmemis_taksit_vade := ld_taksit_vade;
   end if;
         
       
    for c_hesap in cur_hesap loop
         pn_tahsil_anapara	                    :=	c_hesap.tahsil_anapara ;
        pn_tahsil_faiz	                        :=	c_hesap.tahsil_faiz	;
        pn_tahsil_vergi	                        :=	c_hesap.tahsil_vergi	;
        pn_tahsil_birikmis_gecikme_faiz     	:=	c_hesap.tahsil_birikmis_gecikme_faiz	;
        pn_tahsil_gecikme_faiz_tax	            :=	c_hesap.tahsil_gecikme_faiz_tax	;
        pn_tahsil_penalty_amount	            :=	c_hesap.tahsil_penalty_amount	;
        pn_tahsil_penalty_tax	                :=	c_hesap.tahsil_penalty_tax	;
        pn_tahsil_deferred_interest	            :=	c_hesap.tahsil_deferred_interest	;
        pn_tahsil_deferred_interest_tax         :=	c_hesap.tahsil_deferred_interest_tax	;
        pn_tahsil_deferred_delayed_interest	    :=	c_hesap.tahsil_deferred_delayed_interest	;
        pn_tahsil_deferred_delayed_int_tax      :=	c_hesap.tahsil_deferred_delayed_int_tax	;
        pn_tahsil_deferred_tax	                :=	c_hesap.tahsil_deferred_tax	;
        pn_tahsil_deferred_penalty_amount	    :=	c_hesap.tahsil_deferred_penalty_amount	;
        pn_tahsil_deferred_penalty_tax	        :=	c_hesap.tahsil_deferred_penalty_tax	;
     end loop;
            if  nvl(ps_geriodeme_kapama_Secimi,'KAPAMA') in ('ARA','KAPAMA') then            
                pn_tahsil_faiz := ln_tahsil_birikmis_faiz ; 
                pn_tahsil_vergi := ln_tahsil_birikmis_faiz_vergi ;
                  pn_tahsil_anapara := ln_bakiye  ;
            end if;   
         
                
  Exception when others then 
      log_at('PKG_KREDI_TAHSILAT','sp_tahsilat_tutar_bilgisi_al',pn_hesap_no,to_char(sqlcode) || ' ' ||to_char(sqlerrm) );
 END;
  --------------------------------------------------------
  -- b-o-m seval.colak 27072022
  PROCEDURE Accrual_Closing(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS

    varchar_list               Pkg_Muhasebe.varchar_array;
    number_list                   Pkg_Muhasebe.number_array;
    date_list                   Pkg_Muhasebe.date_array;
    boolean_list               Pkg_Muhasebe.boolean_array;

    pn_1324_karsi_dk   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_KARSI_DK');
    pn_1324_bolum_kodu   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_BOLUM_KODU');
    pn_1324_banka_aciklama   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_BANKA_ACIKLAMA');
    pn_1324_musteri_aciklama   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_MUSTERI_ACIKLAMA');
    pn_1324_doviz_kodu   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_DOVIZ_KODU');
    pn_1324_mb_kur   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_MB_KUR');
    pn_1324_hesap_no   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_HESAP_NO');
    pn_1324_accrued_amt_lc   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_ACCRUED_AMT_LC');
    pn_1324_accrued_amt_fc   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_ACCRUED_AMT_FC');
    pn_1324_accrual_acct_no   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_ACCRUAL_ACCT_NO');
    pn_1324_tutar_arti   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_TUTAR_ARTI');
    pn_1324_tutar_eksi   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_TUTAR_EKSI');
    pn_1324_lc   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_LC');
    pn_1324_fc   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_FC');
    pn_1324_kr   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_KR');
    pn_1324_vd   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_VD');
    
    pn_1324_ACCRUAL   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_ACCRUAL');       --b-o-m seval.colak 10022023
    pn_1324_NONACCRUAL   NUMBER := Pkg_Muhasebe.parametre_index_bul('1324_NONACCRUAL'); --e-o-m seval.colak 10022023


    CURSOR cur_hesap IS
     select 
            hesap_no,
            sube_kodu,
            accrual_int_account_no accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(accrual_int_account_no)   accrual_bakiye ,
            'VD' hesap_tur  ,
            'ACCRUAL-INT'  accrual_tur          
       from cbs_hesap_vadeli a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(accrual_int_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
            and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.accrual_int_account_no and nvl(k.bakiye,0) <> 0  )
            and exists (select 1 from cbs_hesap_vadeli k   where k.hesap_no =a.accrual_int_account_no and k.durum_kodu = 'A'  )
      UNION ALL
        select 
            hesap_no,
            sube_kodu,
            accrual_int_account_no  accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(accrual_int_account_no)   accrual_bakiye ,
            'KR' hesap_tur  ,
            'ACCRUAL-INT'  accrual_tur           
       from cbs_hesap_kredi a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(accrual_int_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
            and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.accrual_int_account_no and nvl(k.bakiye,0) <> 0  )
            and exists (select 1 from cbs_hesap_kredi k   where k.hesap_no =a.accrual_int_account_no and k.durum_kodu = 'A'  )
     UNION ALL     
    select 
            hesap_no,
            sube_kodu,
            accrual_tax_account_no  accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(accrual_tax_account_no)   accrual_bakiye ,
            'KR' hesap_tur  ,
            'ACCRUAL-TAX'  accrual_tur           
       from cbs_hesap_kredi a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(accrual_tax_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
             and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.accrual_tax_account_no and nvl(k.bakiye,0) <> 0  )
             and exists (select 1 from cbs_hesap_kredi k   where k.hesap_no =a.accrual_tax_account_no and k.durum_kodu = 'A'  )
        UNION ALL
        select 
            hesap_no,
            sube_kodu,
            accrual_delayed_int_account_no  accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(accrual_delayed_int_account_no)   accrual_bakiye ,
            'KR' hesap_tur  ,
            'ACCRUAL-DELAYED-INT'  accrual_tur           
       from cbs_hesap_kredi a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(accrual_delayed_int_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
             and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.accrual_delayed_int_account_no and nvl(k.bakiye,0) <> 0  )
             and exists (select 1 from cbs_hesap_kredi k   where k.hesap_no =a.accrual_delayed_int_account_no and k.durum_kodu = 'A'  )
        UNION ALL
         select 
            hesap_no,
            sube_kodu,
            nonaccrual_delayed_int_account_no  accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(nonaccrual_delayed_int_account_no)   accrual_bakiye ,
            'KR' hesap_tur  ,
            'NONACCRUAL-DELAYED-INT'  accrual_tur           
       from cbs_hesap_kredi a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(nonaccrual_delayed_int_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
             and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.nonaccrual_delayed_int_account_no and nvl(k.bakiye,0) <> 0  )
             and exists (select 1 from cbs_hesap_kredi k   where k.hesap_no =a.nonaccrual_delayed_int_account_no and k.durum_kodu = 'A'  )
         UNION ALL
          select 
            hesap_no,
            sube_kodu,
            nonaccrual_int_account_no  accrual_acct_no,  
            dk_grup_kod,
            doviz_kodu,
            a.modul_tur_kod,
            a.urun_tur_kod,
            a.urun_sinif_kod,  
            pkg_hesap.hesapbakiyeal(nonaccrual_int_account_no)   accrual_bakiye ,
            'KR' hesap_tur  ,
            'NONACCRUAL-INT'  accrual_tur           
       from cbs_hesap_kredi a,cbs_musteri b
       where a.musteri_no=b.musteri_no
             and a.durum_kodu='K'
             and nvl(nonaccrual_int_account_no,0)<>0
             and a.urun_tur_kod not in ('ACCRUAL','NONACCRUAL','PAST DUE')   
             and exists (select 1 from cbs_hesap_bakiye k  where k.hesap_no =a.nonaccrual_int_account_no and nvl(k.bakiye,0) <> 0  )
             and exists (select 1 from cbs_hesap_kredi k   where k.hesap_no =a.nonaccrual_int_account_no and k.durum_kodu = 'A'  )
        order by 1;
   
    r_hesap                              cur_hesap%ROWTYPE;

    ln_counter                            NUMBER:=0;
    ln_fis_numara                         CBS_FIS.numara%TYPE;
    ln_temp_numara                        CBS_FIS.numara%TYPE;
    ln_fark                               CBS_DKHESAP.evaluasyonlu_bakiye%TYPE;
    ln_islem_numara                       CBS_ISLEM.numara%TYPE;
    ln_islem_kod                          NUMBER:=1324;
    ls_fis_aciklama                       VARCHAR2(2000):='Accrual Account Closing';
    ls_iliskili_faiz_dk                   VARCHAR2(100);
    ls_gecikme_faiz_dk                    VARCHAR2(100);
    ls_sales_tax_dk                       VARCHAR2(100);
    ls_nonaccrual_int_credit_dk           VARCHAR2(100);
    ls_karsilik_dk                        VARCHAR2(100);  
  BEGIN
/*
Karsi D/K
Accrual int account = ILISKILI_FAIZ_DK
Accrual delayed int account = GECIKME_FAIZ_GL
Tax accrual account = G_DK_SALES_TAX
Non Accrual int account = G_DK_NONACCRUAL_INT_CREDIT
Non Accrual delayed int account = G_DK_NONACCRUAL_INT_CREDIT

*/
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
     
     Pkg_Parametre.deger('G_DK_NONACCRUAL_INT_CREDIT',ls_nonaccrual_int_credit_dk);
     Pkg_Parametre.deger('G_DK_SALES_TAX',ls_sales_tax_dk);     
        
   for c_hesap in cur_hesap loop
      r_hesap :=c_hesap;
      ln_islem_numara:=Pkg_Batch.islem_yarat(ln_islem_kod,r_hesap.sube_kodu);
        varchar_list(pn_1324_karsi_dk)  := NULL; 
        varchar_list(pn_1324_bolum_kodu)  := NULL; 
        varchar_list(pn_1324_banka_aciklama)  := NULL; 
        varchar_list(pn_1324_musteri_aciklama)  := NULL; 
        varchar_list(pn_1324_doviz_kodu)  := NULL; 
        number_list(pn_1324_mb_kur)  := 0;
        varchar_list(pn_1324_hesap_no)  := NULL; 
        number_list(pn_1324_accrued_amt_lc)  := 0;
        number_list(pn_1324_accrued_amt_fc)  := 0;
        varchar_list(pn_1324_accrual_acct_no)  := NULL; 
          
        boolean_list(pn_1324_tutar_arti)  := FALSE;
        boolean_list(pn_1324_tutar_eksi)  := FALSE;
        boolean_list(pn_1324_lc)  := FALSE;
        boolean_list(pn_1324_fc)  := FALSE;      
        boolean_list(pn_1324_kr)  := FALSE;
        boolean_list(pn_1324_vd)  := FALSE;    
         
        boolean_list(pn_1324_ACCRUAL)  := FALSE;   --b-o-m seval.colak 10022023
        boolean_list(pn_1324_NONACCRUAL)  := FALSE; 
      
        if c_hesap.accrual_tur like 'ACCRUAL%' then
            boolean_list(pn_1324_ACCRUAL)  := TRUE;
         end if;
        if c_hesap.accrual_tur like 'NONACCRUAL%' then
            boolean_list(pn_1324_NONACCRUAL)  := TRUE;
         end if;                                    --e-o-m seval.colak 10022023
        
      if c_hesap.hesap_tur='VD' then
        boolean_list(pn_1324_VD) := TRUE ;
        Pkg_Muhasebe.dk_bul(r_hesap.dk_grup_kod
                                         ,r_hesap.modul_tur_kod
                                            ,r_hesap.urun_tur_kod
                                            ,r_hesap.urun_sinif_kod
                                            ,3 --Faiz hesabi
                                            ,NULL
                                            ,NULL
                                            ,NULL
                                            ,ls_iliskili_faiz_dk);
          ls_karsilik_dk    :=ls_iliskili_faiz_dk;
                                          
       elsif c_hesap.hesap_tur='KR' then
         boolean_list(pn_1324_KR) := TRUE ;
                 Pkg_Muhasebe.dk_bul(r_hesap.dk_grup_kod
                                         ,r_hesap.modul_tur_kod
                                            ,r_hesap.urun_tur_kod
                                            ,r_hesap.urun_sinif_kod
                                            ,2 --Faiz hesabi
                                            ,NULL
                                            ,NULL
                                            ,NULL
                                            ,ls_iliskili_faiz_dk);   
             ls_karsilik_dk    :=ls_iliskili_faiz_dk ;
                                                                      
            Pkg_Muhasebe.dk_bul(r_hesap.dk_grup_kod
                                         ,r_hesap.modul_tur_kod
                                            ,r_hesap.urun_tur_kod
                                            ,r_hesap.urun_sinif_kod
                                            ,10 --gecikme hesabi
                                            ,NULL
                                            ,NULL
                                            ,NULL
                                            ,ls_gecikme_faiz_dk);   
             if c_hesap.accrual_tur = 'ACCRUAL-INT' then 
                 ls_karsilik_dk    :=ls_iliskili_faiz_dk ;
              elsif c_hesap.accrual_tur = 'ACCRUAL-TAX' then
                 ls_karsilik_dk    :=ls_sales_tax_dk ;
              elsif c_hesap.accrual_tur = 'ACCRUAL-DELAYED-INT' then
                 ls_karsilik_dk    :=ls_gecikme_faiz_dk ;
              elsif c_hesap.accrual_tur = 'NONACCRUAL-DELAYED-INT' then
                  ls_karsilik_dk    :=ls_nonaccrual_int_credit_dk ;
              elsif c_hesap.accrual_tur = 'NONACCRUAL-INT' then
                 ls_karsilik_dk    :=ls_nonaccrual_int_credit_dk ;
             end if;
       end if;
                           

           IF r_hesap.doviz_kodu = Pkg_Genel.lc_al THEN
               boolean_list(pn_1324_lc) := TRUE ;                          
           ELSE                         
               boolean_list(pn_1324_fc) := TRUE ;
           END IF;
           
           if nvl(r_hesap.accrual_bakiye,0) < 0 then 
              boolean_list(pn_1324_tutar_eksi)  := TRUE;
          else
             boolean_list(pn_1324_tutar_arti)  := TRUE;
           end if;
           
           varchar_list(pn_1324_bolum_kodu):=r_hesap.sube_kodu;
           varchar_list(pn_1324_doviz_kodu):=r_hesap.doviz_kodu;
           varchar_list(pn_1324_BANKA_ACIKLAMA):=  'Main Account No: '||r_hesap.hesap_No || ', Accrual Account No :'|| r_hesap.accrual_acct_no || ' Accrual Closing';
           varchar_list(pn_1324_MUSTERI_ACIKLAMA):= 'Main Account No: '||r_hesap.hesap_No || ', Accrual Account No :'|| r_hesap.accrual_acct_no || ' Accrual Closing';                     
           varchar_list(pn_1324_karsi_dk):= ls_karsilik_dk;
           varchar_list(pn_1324_ACCRUAL_ACCT_NO):= r_hesap.accrual_acct_no;
           varchar_list(pn_1324_hesap_no)   := r_hesap.hesap_No; 

                       IF r_hesap.doviz_kodu = Pkg_Genel.lc_al THEN
                          number_list(pn_1324_mb_kur):=1;
                       ELSE
                          number_list(pn_1324_mb_kur):=   Pkg_Kur.doviz_doviz_karsilik(r_hesap.doviz_kodu,
                                                                                Pkg_Genel.lc_al,
                                                                                NULL,
                                                                                1,
                                                                                1,
                                                                                NULL,
                                                                                NULL,
                                                                                'N',
                                                                                'A');
                       end if;
                       number_list(pn_1324_accrued_amt_fc):= abs(nvl(r_hesap.accrual_bakiye,0));
                       number_list(pn_1324_accrued_amt_lc):=Pkg_Kur.mb_dak_to_lc(r_hesap.doviz_kodu,abs(nvl(r_hesap.accrual_bakiye,0)));

                ln_fis_numara:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
                                null,
                                ln_islem_numara,
                                varchar_list ,
                                number_list  ,
                                date_list    ,
                                boolean_list ,
                                NULL,
                                FALSE,
                                0,
                                ls_fis_aciklama);
                             
                     Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_numara);
                    Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6872'||Pkg_Hata.GetDelimiter||r_hesap.sube_kodu||Pkg_Hata.GetDelimiter||TO_CHAR(r_hesap.hesap_No )||Pkg_Hata.GetDelimiter||Pkg_Hata.GetDelimiter||TO_CHAR(r_hesap.accrual_tur )||Pkg_Hata.GetDelimiter||TO_CHAR(r_hesap.accrual_Acct_No )||Pkg_Hata.GetDelimiter||Pkg_Hata.GetDelimiter||TO_CHAR(ln_fis_numara)||Pkg_Hata.GetUCPOINTER,ln_islem_numara);
            
               END LOOP;
        COMMIT;
  -- sifir bakiyeli accrual hesaplarin ana hesaplari kapali ise accrual hesaplari kapatalim.    
 --1. vadeli hesaplarin kapatilmasi.     
update cbs_hesap_vadeli h
set h.durum_kodu='K',
    h.KAPAMA_TARIHI= pkg_muhasebe.banka_tarihi_bul  
   -- select * from cbs_hesap_vadeli h
WHERE   h.urun_tur_kod  IN ('ACCRUAL','NONACCRUAL') and  
        h.durum_kodu = 'A' and exists (Select 1 from cbs_hesap_bakiye b where b.hesap_No = h.hesap_No  and nvl(b.bakiye,0)  = 0 ) 
        and exists (select 1 from cbs_hesap_vadeli a
            where a.accrual_int_account_no =h.hesap_No and a.durum_kodu = 'K'  );

 --2. kredi hesaplarin kapatilmasi.          
  update cbs_hesap_kredi h
set h.durum_kodu='K',
    h.kapanis_Tarihi= pkg_muhasebe.banka_tarihi_bul  
   -- select * from cbs_hesap_kredi h
WHERE   h.urun_tur_kod  IN ('ACCRUAL','NONACCRUAL') and  
        h.durum_kodu = 'A' and exists (Select 1 from cbs_hesap_bakiye b where b.hesap_No = h.hesap_No  and nvl(b.bakiye,0)  = 0 ) 
        and exists (select 1 from cbs_hesap_kredi a
            where a.hesap_no =h.ana_kredi_hesap_No and a.durum_kodu = 'K'  );

  commit;   

    Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod,ln_islem_numara);

  EXCEPTION
    WHEN OTHERS THEN
     ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM,ln_islem_numara);
  END;
  -------------------------------------
  --seval.colak 25082022 SIMUL dosya yukleme number convert format amacli olarak eklendi. 
     FUNCTION ConvertStringToNumber (ps_str VARCHAR2)
      RETURN NUMBER
   IS
   BEGIN
   
   -- 'FM999G999G999G999G999G999G999G999G999D00000'   '9999999999999999999999999999.999999999'
      RETURN NVL(TO_NUMBER (REPLACE (ps_str, ',', '.'), '9999999999999999999999999999.999999999' ), 0);
   EXCEPTION
        WHEN OTHERS THEN
            log_at('ConvertStringToNumber', ps_str);
            return 0;
   END;
-------------------------------------
PROCEDURE MAIN_LOAN_ACCRUAL_CLOSING(pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) IS
 ld_banka_tarihi  date := pkg_muhasebe.banka_tarihi_bul;
 
Cursor cur_hesap is
   select a.hesap_no
   from cbs_hesap_kredi a,cbs_hesap_bakiye b
   where a.hesap_no = b.hesap_no and 
    a.durum_kodu = 'A' and 
    a.kredi_vade <= ld_banka_tarihi 
    and pkg_odeme_plan.sf_urun_tahakkuk_eh(a.modul_tur_kod,a.urun_tur_kod,a.urun_sinif_kod) = 'E' 
   -- and a.repayment_type  in( 'INSTALLMENT DATE' ,'MATURITY DATE')
    and  nvl(b.bakiye,0) = 0 
    and  a.otomatik_tahsilat = 'E' 
    and not exists (select 1 from cbs_hesap h where h.musteri_no = a.musteri_no and nvl(h.badlist_flag,'H') = 'E' ) 
    and exists(select 1 from cbs_hesap_kredi h1  ,cbs_hesap_bakiye b1 where h1.hesap_no = b1.hesap_no and h1.hesap_no = a.accrual_int_account_no and nvl(b1.bakiye,0) = 0 )
    and exists(select 1 from cbs_hesap_kredi h2  ,cbs_hesap_bakiye b2 where h2.hesap_no = b2.hesap_no and h2.hesap_no = a.accrual_tax_account_no and nvl(b2.bakiye,0) = 0 ) 
    and exists(select 1 from cbs_hesap_kredi h3  ,cbs_hesap_bakiye b3 where h3.hesap_no = b3.hesap_no and h3.hesap_no = a.accrual_delayed_int_account_no and nvl(b3.bakiye,0) = 0 ) 
    and exists(select 1 from cbs_hesap_kredi h4  ,cbs_hesap_bakiye b4 where h4.hesap_no = b4.hesap_no and h4.hesap_no = a.nonaccrual_int_account_no and nvl(b4.bakiye,0) = 0 ) 
    and exists(select 1 from cbs_hesap_kredi h5  ,cbs_hesap_bakiye b5 where h5.hesap_no = b5.hesap_no and h5.hesap_no = a.nonaccrual_delayed_int_account_no and nvl(b5.bakiye,0) = 0 ) ;           

Begin
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
 
  --1. ana kredi hesaplarin kapatilmasi
   for c_hesap in cur_hesap loop   
        
        update cbs_hesap_kredi
        set durum_kodu = 'K',
            kapanis_tarihi =ld_banka_tarihi
           -- birikmis_faiz_tutari=0,           --seval.colak 08122022 loan conversion bitmeden 0 yapmak dogru gelmedi simdilik 0 yapma kismi kapali kalsin.
           -- birikmis_faiz_tutari_round=0
         where hesap_no = c_hesap.hesap_no;   
            
        Pkg_Batch.logla(pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.GetUCPOINTER||'6881'||Pkg_Hata.GetDelimiter||TO_CHAR(c_hesap.hesap_No )||Pkg_Hata.GetDelimiter||Pkg_Hata.GetUCPOINTER);
   end loop;
  
 --2. accural hesaplarin kapatilmasi.          
    update cbs_hesap_kredi h
    set h.durum_kodu='K',
        h.kapanis_tarihi= ld_banka_tarihi
       -- select * from cbs_hesap_kredi h
    where   h.urun_tur_kod  in ('ACCRUAL','NONACCRUAL') and  
            h.durum_kodu = 'A' and exists (select 1 from cbs_hesap_bakiye b where b.hesap_no = h.hesap_no  and nvl(b.bakiye,0)  = 0 ) 
            and exists (select 1 from cbs_hesap_kredi a
                where a.hesap_no =h.ana_kredi_hesap_no and a.durum_kodu = 'K'  );

  commit;   

  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
-----------------
--seval.colak 18012023 
FUNCTION Loan_BadListFlag(pn_hesap_no VARCHAR2) RETURN VARCHAR2 IS
         ls_badlistflag        VARCHAR2(1);
BEGIN
     SELECT BADLIST_FLAG
     INTO ls_badlistflag
     FROM cbs_vw_kredi_hesap_izleme
     WHERE hesap_no=pn_hesap_no;
    
 RETURN NVL(ls_badlistflag,'H');

EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN  ls_badlistflag;

END;
END;
/

