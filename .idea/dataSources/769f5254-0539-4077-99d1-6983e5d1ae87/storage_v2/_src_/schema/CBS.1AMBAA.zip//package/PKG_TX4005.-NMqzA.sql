create PACKAGE     Pkg_Tx4005 IS

/******************************************************************************
Name       : PKG_TX4005
Created By : Chyngyz Omurov
Purpose      : To create 4003 transactions for internet banking swift operations with value date
                     bigger than bank's date (within the scope of the request cq509)
Date :          18/03/2015                    
******************************************************************************/

-- TX Event Listesi

TYPE CursorReferenceType IS REF CURSOR;

PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);     -- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);    -- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);        -- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);        -- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);    -- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);        -- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);      -- Isleme iliskin formlar basildiktan sonra cagrilir

PROCEDURE Muhasebelesme(pn_islem_no NUMBER);        -- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);

PROCEDURE GERI_CEVIRME_SONRASI(pn_islem_no NUMBER) ;

PROCEDURE GetTransactions( ps_value_date_start VARCHAR2, 
                                                    ps_value_date_end VARCHAR2, 
                                                    ps_tx_date_start VARCHAR2, 
                                                    ps_tx_date_end VARCHAR2,
                                                    pn_custno NUMBER,
                                                    pn_accno NUMBER,
                                                    pc_ref OUT CursorReferenceType);
 
 Function Not_Completed_Tx_Exists RETURN VARCHAR2;                                                    
END;

/

