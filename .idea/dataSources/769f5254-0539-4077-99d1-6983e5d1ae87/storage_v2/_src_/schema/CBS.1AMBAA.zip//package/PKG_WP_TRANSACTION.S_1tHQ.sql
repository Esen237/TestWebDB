create PACKAGE     PKG_WP_TRANSACTION
IS
   TYPE CursorReferenceType IS REF CURSOR;

   FUNCTION set_nbkr_currencies (ls_currencies  IN VARCHAR2) return VARCHAR2;

END PKG_WP_TRANSACTION;

/

