create PACKAGE Pkg_Leasing IS
/******************************************************************************
   NAME       : PKG_LEASING
   Created By : Mutlu ?zdemir
   Date    	  : 18.03.04
   Purpose	  : Leasing ile ilgili fonksiyon ve procedurleri icerir
******************************************************************************/
   FUNCTION ana_mal_kodu_al RETURN NUMBER;
   FUNCTION detay_mal_kodu_al(pn_ana_kod NUMBER) RETURN NUMBER;
   FUNCTION sozlesme_baslangic_tarihi_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN DATE;
   FUNCTION sozlesme_bitis_tarihi_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN DATE;
   FUNCTION fatura_sira_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER,
                           pn_odeme_no NUMBER) RETURN NUMBER;
   FUNCTION odeme_plan_no_al(pn_musteri_no NUMBER, pn_sozlesme_no NUMBER) RETURN NUMBER;
   FUNCTION ana_mal_adi_al(pn_mal_kodu NUMBER) RETURN VARCHAR2;
   FUNCTION detay_mal_adi_al(pn_ana_kod NUMBER, pn_detay_kod NUMBER) RETURN VARCHAR2;
   FUNCTION doviz_kullanilir(pn_musteri_no NUMBER, pn_krd_tklf_str_no NUMBER,
                             ps_dvz VARCHAR2) RETURN NUMBER;
   FUNCTION odeme_plan_faiz_al(pn_hesap_no NUMBER) RETURN NUMBER;
   FUNCTION odeme_plan_kdv_al(pn_hesap_no NUMBER) RETURN NUMBER;
   FUNCTION masraf_kod_al RETURN NUMBER;
   FUNCTION modul_tur_al RETURN VARCHAR2;
   FUNCTION urun_tur_al RETURN VARCHAR2;
   PROCEDURE sp_isleme_at (pn_musteri_no       CBS_LEASING.musteri_no%TYPE,
   			 			   pn_sozlesme_no      CBS_LEASING.sozlesme_no%TYPE,
						   pn_odeme_plan_no		   CBS_LEASING.odeme_plan_no%TYPE,
  			   			   pn_tx_no   		   NUMBER,
						   pn_islem_tanim_kod  CBS_HESAP_KREDI_ISLEM.islem_tanim_kod%TYPE DEFAULT 3262);
   FUNCTION Sf_BitmemisIslem_Var_Mi(pn_musteri_no CBS_MUSTERI.musteri_no%TYPE,
 		  			 			  pn_sozlesme_no      CBS_LEASING.sozlesme_no%TYPE,
						   		  pn_odeme_plan_no		   CBS_LEASING.odeme_plan_no%TYPE,
 		  						  pn_islem_no CBS_ISLEM.numara%TYPE
								  ) RETURN NUMBER;

 PROCEDURE sf_min_odenmemis_taksiti_bul (pn_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE,
		 								 pd_vade_tarihi DATE ,
										 pn_taksit_sira_no  OUT NUMBER,
										 pd_taksit_vade OUT DATE );

 FUNCTION Sf_TahsilHesap_UrunUygunmu(ps_urun_tur_kod CBS_HESAP_KREDI.urun_tur_kod%TYPE ) RETURN VARCHAR2;
 FUNCTION sf_istatistikkod_uygunmu(ps_istatistik_kodu CBS_ISTATISTIK_KODLARI.istatistik_kodu%TYPE) RETURN VARCHAR2;
 FUNCTION teklif_referans_al(pn_islem_no NUMBER) RETURN VARCHAR2;
 PROCEDURE leasing_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2);
 FUNCTION son_gercek_taksit_tarihi(pn_islem_no NUMBER) RETURN DATE;
 FUNCTION odeme_plan_anapara_al(pn_hesap_no NUMBER) RETURN NUMBER;
 FUNCTION odeme_plan_kalan_faiz_al(pn_hesap_no NUMBER) RETURN NUMBER;
 FUNCTION odeme_plan_kalan_kdv_al(pn_hesap_no NUMBER) RETURN NUMBER;
 PROCEDURE leasing_masraf_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2);
 FUNCTION leasing_hesap_no_al(ps_ref VARCHAR2) RETURN NUMBER;
 FUNCTION leasing_plan_doviz_al(ps_ref VARCHAR2) RETURN VARCHAR2;
 FUNCTION masraf_cinsi_adi(pn_masraf_cinsi NUMBER) RETURN VARCHAR2;
 PROCEDURE leasing_tadilat_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2);
 PROCEDURE leasing_tadilat_yap(pn_islem_no NUMBER, ps_referans VARCHAR2);
 FUNCTION teklif_yaratan_tx_no(ps_ref VARCHAR2) RETURN NUMBER;
 FUNCTION son_gercek_taksit_sayisi(pn_hesap_no NUMBER) RETURN NUMBER ;

END Pkg_Leasing;


/

