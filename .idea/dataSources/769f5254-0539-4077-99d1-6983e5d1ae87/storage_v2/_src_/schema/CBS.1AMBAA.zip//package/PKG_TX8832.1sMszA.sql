create PACKAGE Pkg_Tx8832 IS

/******************************************************************************
   Name       : PKG_Tx8832
   Created By : Hakan SAMSA
   Date    	  : 09/12/2007
   Purpose	  : ATM NPC - Cash Withdrawal/Advance (BS Islem Kod = 0801)
******************************************************************************/
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

