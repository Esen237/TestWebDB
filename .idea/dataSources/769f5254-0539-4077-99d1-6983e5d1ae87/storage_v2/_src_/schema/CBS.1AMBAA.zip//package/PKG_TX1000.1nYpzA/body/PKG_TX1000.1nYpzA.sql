create PACKAGE BODY     PKG_TX1000 IS

	PROCEDURE yaratma_oncesi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE kontrol_sonrasi(pn_islem_no NUMBER) IS
		ln_adet 	 NUMBER := 0;
		l_ucpointer  VARCHAR2(3) := CBS.pkg_hata.getucpointer;
		ls_adres_kod CBS.cbs_musteri_basvuru.extre_adres_kod%TYPE;
		adres_yok	 EXCEPTION;
	BEGIN
		SELECT extre_adres_kod
		  INTO ls_adres_kod
		  FROM CBS.cbs_musteri_basvuru
		 WHERE tx_no = pn_islem_no;

		/*SELECT NVL(COUNT(*), 0)
		  INTO ln_adet
		  FROM CBS.cbs_musteri_basvuru_adres
		 WHERE tx_no = pn_islem_no AND adres_kod = ls_adres_kod; 

		IF ln_adet = 0 THEN
			RAISE adres_yok;
		END IF;*/ --Commented AntonPa CBS-395 250123
        
		CBS.pkg_black_list.chek_update(pn_islem_no);
	EXCEPTION
		WHEN adres_yok THEN
			raise_application_error(-20100, CBS.pkg_hata.getucpointer || '811' || CBS.pkg_hata.getdelimiter || ls_adres_kod || CBS.pkg_hata.getucpointer);
		WHEN OTHERS THEN
			raise_application_error(-20100, CBS.pkg_hata.getucpointer || '811' || CBS.pkg_hata.getdelimiter || ls_adres_kod || CBS.pkg_hata.getucpointer);
	END;

	PROCEDURE dogrulama_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE iptal_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE dogrulama_iptal_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE iptal_onay_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE iptal_reddetme_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE iptal_muhasebelestir_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE onay_sonrasi(pn_islem_no NUMBER) IS
		ls_kimlik_no		 VARCHAR2(2000);
		ln_musteri_no		 NUMBER := 0;
		ls_isim 			 VARCHAR2(2000);
        ls_ikinci_isim       VARCHAR2(2000);
        ls_soyadi            VARCHAR2(2000);
		ls_ticari_unvan 	 VARCHAR2(2000);
		ls_musteri_tipi_kod  CBS.cbs_musteri_basvuru.musteri_tipi_kod%TYPE;
		ls_yerlesim_kod 	 CBS.cbs_musteri_basvuru.yerlesim_kod%TYPE;
		ls_baba_adi 		 CBS.cbs_musteri_basvuru.baba_adi%TYPE;
		ld_dogum_tarihi 	 DATE;
		ln_mevcut_musteri_no CBS.cbs_musteri.musteri_no%TYPE;
		ls_tc_kimlik_no 	 CBS.cbs_musteri.tc_kimlik_no%TYPE;
		ls_ticari_sicil_no	 CBS.cbs_musteri.ticari_sicil_no%TYPE;
		ls_dogum_yeri		 CBS.cbs_musteri.dogum_yeri%TYPE;
		mevcut_musteri		 EXCEPTION;
		ls_vergi_no 		 VARCHAR2(2000);
		ls_vergi_daire		 VARCHAR2(2000);
		ls_kimlik_kod		 VARCHAR2(2000);
		ln_personel_sicil_no NUMBER;
		ls_ret_code 		 VARCHAR2(10); --AdiletK 02.10.2015 CQ5067 Add customer automation
		--B-O-M AdiletK CQ5359 200000th customer
		ls_bolum_kodu		 VARCHAR2(10);
		ln_count			 NUMBER;
		ls_cust_param		 VARCHAR2(100);
		ls_customer_name	 VARCHAR2(300);
		ls_email			 VARCHAR2(100);
		ls_email_group		 VARCHAR2(300);
		ls_header			 VARCHAR2(100);
		ls_content			 CLOB := '';
		ls_basvuru_no		 VARCHAR2(100);
		ls_uyruk_kod		 VARCHAR2(3);
		ls_cinsiyet_kod 	 VARCHAR2(1);
		--E-O-M AdiletK CQ5359 200000th customer

		ls_vat_seri_no       VARCHAR2(20);
		ls_lokal_unvan       VARCHAR2(200);

		/*modifications for webportal 01.08.2018*/
		/*CURSOR customer_curs  IS
			SELECT customer_no
			  FROM webportal.tbl_customer_info@webcaller_link
			 WHERE tx_no = pn_islem_no;

		res_customer		 customer_curs%ROWTYPE;*/

		--NurmilaZ Campus cbs-485 19072021
		CURSOR customer_cam_curs  IS
			SELECT customer_no
			  FROM cbs.campus_customer_info
			 WHERE tx_no = pn_islem_no;

        res_customer_cam_curs CUSTOMER_CAM_CURS%ROWTYPE;
	BEGIN
		SELECT isim, ikinci_isim, soyadi,
			   ticari_unvan, musteri_tipi_kod, yerlesim_kod,
			   baba_adi, dogum_tarihi, dogum_yeri,
			   kimlik_kod, DECODE(kimlik_kod,  '1', nufus_cuzdani_seri_no,	'2', ehliyet_belge_no,	'3', pasaport_no), vergi_no,
			   vergi_dairesi_adi, personel_sicil_no, musteri_no,
			   uyruk_kod, cinsiyet_kod, vat_seri_no, lokal_unvan
		  INTO ls_isim, ls_ikinci_isim, ls_soyadi,
			   ls_ticari_unvan, ls_musteri_tipi_kod, ls_yerlesim_kod,
			   ls_baba_adi, ld_dogum_tarihi, ls_dogum_yeri,
			   ls_kimlik_kod, ls_kimlik_no, ls_vergi_no,
			   ls_vergi_daire, ln_personel_sicil_no, ls_basvuru_no,
			   ls_uyruk_kod, ls_cinsiyet_kod, ls_vat_seri_no, ls_lokal_unvan
		  FROM CBS.cbs_musteri_basvuru
		 WHERE tx_no = pn_islem_no;

		IF ls_musteri_tipi_kod in ('1', '2') THEN
            IF ls_yerlesim_kod = '1' THEN
                CBS.PKG_MUSTERI.checkDuplicateTaxId(ls_musteri_tipi_kod, null, ls_vergi_no, ls_yerlesim_kod);
            ELSE
            	--BOM YadgarB CBS-258
                begin
                    CBS.PKG_MUSTERI.checkDuplicateCustomer(ls_musteri_tipi_kod, ls_isim, ls_soyadi, ld_dogum_tarihi, ls_uyruk_kod, ls_ikinci_isim, ls_cinsiyet_kod); --YadgarB CBS-258
                exception
                    when others then
                        IF SQLCODE = -20114
                            THEN null;
                        ELSE
                            log_at('error_customer_20115', SQLERRM, DBMS_UTILITY.format_error_backtrace);
                            raise_application_error(-20100, SQLERRM);
                        END IF;
                end;
                --EOM YadgarB CBS-258
            END IF;
        ELSE
            IF ls_yerlesim_kod = '2' THEN
                CBS.PKG_MUSTERI.check_duplicate_corp_nonres(ls_uyruk_kod, ls_lokal_unvan, ls_vat_seri_no);
            END IF;
        END IF;

		--      pkg_musteri.sp_musteri_no_bul(ls_isim, ls_ticari_unvan, ls_musteri_tipi_kod, ls_yerlesim_kod, ls_baba_adi,
		--                                    ld_dogum_tarihi, ls_dogum_yeri, ln_mevcut_musteri_no, ls_kimlik_kod, ls_kimlik_no,
		--                                    ls_vergi_no, ls_vergi_daire);
		--
		--
		--            -- sevalb 171007 tarihinde uyari kapatilmisti 050208 tarihinde acilmasi istendi acildi.
		--       if ln_mevcut_musteri_no is not null then --MaratM CBS-258
		--            raise mevcut_musteri;
		--       else
		--         select pkg_genel.genel_kod_al('MUSTERI_NO')
		--         into ln_musteri_no
		--         from dual;

		--BOM YadgarB 30.09.2022 pkg_wp_musteri extra musteri_no creation bug
		--ln_musteri_no := CBS.pkg_genel.genel_kod_al('MUSTERI_NO');
        
        select NVL(DECODE(musteri_no, 0, null, musteri_no), CBS.PKG_GENEL.genel_kod_al('MUSTERI_NO'))
        into ln_musteri_no
        from CBS.CBS_MUSTERI_BASVURU
        where tx_no = pn_islem_no;
        --EOM YadgarB 30.09.2022 pkg_wp_musteri extra musteri_no creation bug

		/*BEGIN
			OPEN customer_curs;

			FETCH customer_curs INTO res_customer;

			IF customer_curs%FOUND THEN
				IF (res_customer.customer_no = ls_basvuru_no) THEN
					ln_musteri_no := res_customer.customer_no;
				END IF;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				NULL;
		END;*/

		BEGIN
			OPEN customer_cam_curs;

			FETCH customer_cam_curs INTO res_customer_cam_curs;

			IF customer_cam_curs%FOUND THEN
				IF (res_customer_cam_curs.customer_no = ls_basvuru_no) THEN
					ln_musteri_no := res_customer_cam_curs.customer_no;
				END IF;
			END IF;

			CLOSE customer_cam_curs;
		EXCEPTION
			WHEN OTHERS THEN
				NULL;
		END;

		UPDATE CBS.cbs_musteri_basvuru
		   SET musteri_no = ln_musteri_no
		 WHERE tx_no = pn_islem_no
		   AND MUSTERI_NO IS NULL or MUSTERI_NO = 0; --YadgarB 30.09.2022 pkg_wp_musteri extra musteri_no creation bug

		IF NVL(ln_musteri_no, 0) <> 0 THEN
			CBS.pkg_musteri.sp_musteri_kaydi_olustur(pn_islem_no, ln_musteri_no);
			CBS.pkg_musteri.sp_personel_musterino_guncelle(ln_musteri_no, ln_personel_sicil_no);
			CBS.pkg_tx.tamam_mesaj_parametresi('Customer No: ' || TO_CHAR(ln_musteri_no)); --sevalb 23112012 onay_mesaj_parametresi replaced by tamam_mesaj_parametresi
		END IF;

		UPDATE CBS.cbs_islem
		   SET musteri_numara = ln_musteri_no
		 WHERE numara = pn_islem_no;

		ls_ret_code := CBS.pkg_soa_transaction.addtodynamicnotifylist(pn_islem_no, 1000, ln_musteri_no); --AdiletK 02.10.2015 CQ5067 Add customer automation
		--B-O-M AdiletK CQ5359 200000th customer
		ls_bolum_kodu := CBS.pkg_musteri.sf_bolum_kodu_al(ln_musteri_no);

		BEGIN
			IF INSTR('001, 010, 011, 012, 013, 014, 015, 030, 040, 041, 042, 060, 061, 062, 110, 130, 131', ls_bolum_kodu) > 0
		   AND ls_musteri_tipi_kod = '1' THEN
				CBS.pkg_parametre.deger('CUSTOMER_200000', ls_cust_param);

				IF ls_cust_param = 'YES' THEN
					SELECT COUNT(m.musteri_no)
					  INTO ln_count
					  FROM CBS.cbs_musteri m
					 WHERE m.durum_kodu = 'A'
					   AND EXISTS
							   (SELECT 1
								  FROM CBS.cbs_hesap h
								 WHERE m.musteri_no = h.musteri_no AND h.durum_kodu = 'A');

					IF ln_count >= 199999 THEN --199999
						UPDATE CBS.cbs_parametre
						   SET deger = '"NO"'
						 WHERE kod = 'CUSTOMER_200000';

						CBS.pkg_parametre.deger('CUST_200000_EMAIL', ls_email_group);

						SELECT NVL(email, '')
						  INTO ls_email
						  FROM CBS.cbs_islem i, CBS.cbs_kullanici k
						 WHERE i.numara = pn_islem_no AND i.kayit_kullanici_kodu = k.kodu;

						ls_customer_name := CBS.pkg_musteri.sf_musteri_eng_adi(ln_musteri_no);
						ls_header := ' 200000th CUSTOMER IS CREATED !!! CONGRATULATIONS !!!';
						ls_content := '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>';
						ls_content := ls_content || '<table width=570><tr><td align=center><font size="+1">200000th customer was just created !!! </td></tr><tr><td align=center>Congratulations to customer: '
                                        || ls_customer_name || ',</td></tr><tr><td align=center> having customer number: ' || ln_musteri_no || '.</font></td></tr></table>';
						ls_content := ls_content || '</body></html>';
						CBS.pkg_email.addtoemailqueue('CONGRATS', 50, 'info@demirbank.kg', ls_email || ls_email_group, ls_header, ls_content, 'HTML');
						CBS.pkg_email.sendautomessages('');
						--COMMIT;
					END IF;
				END IF;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN
				log_at('error_customer_200000', ln_count || ' ' || ln_musteri_no, SQLERRM, DBMS_UTILITY.format_error_backtrace);
		END;
	--E-O-M AdiletK CQ5359 200000th customer
	EXCEPTION
		WHEN mevcut_musteri THEN
			raise_application_error(-20100, CBS.pkg_hata.getucpointer || '99' || CBS.pkg_hata.getdelimiter || TO_CHAR(ln_mevcut_musteri_no) || CBS.pkg_hata.getucpointer);
		WHEN OTHERS THEN
			log_at('1000-hata', TO_CHAR(SQLCODE) || TO_CHAR(SQLERRM), DBMS_UTILITY.format_error_backtrace, pn_islem_no);
			raise_application_error(-20100, CBS.pkg_hata.getucpointer || '127' || CBS.pkg_hata.getdelimiter || TO_CHAR(SQLCODE) || TO_CHAR(SQLERRM) || CBS.pkg_hata.getucpointer);
	END;

	PROCEDURE reddetme_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE tamam_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE basim_sonrasi(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	PROCEDURE muhasebelesme(pn_islem_no NUMBER) IS
	BEGIN
		NULL;
	END;

	/*****************************************************************************************************************/
	/*   Function  dokuman_kontrol                                                                                                 */
	/*   dokuman getir calistirilip calistirilmadi kontrol edilir.                                                      */
	/*****************************************************************************************************************/
	FUNCTION dokuman_kontrol(ps_musteri_tipi_kod cbs_musteri.musteri_tipi_kod%TYPE, pn_islem_no NUMBER)
		RETURN NUMBER IS
		ln_adet 	   NUMBER;
		l_ucpointer    VARCHAR2(3) := CBS.pkg_hata.getucpointer;
		ls_dk_grup_kod CBS.cbs_musteri_basvuru.dk_grup_kod%TYPE;
		ln_mevcut	   NUMBER := 0;
	BEGIN
		/* Banka musterileri icin zorunlu olmas?n istenildiginden 1 geri dondurulur. iptal edildi.*/

		SELECT dk_grup_kod
		  INTO ls_dk_grup_kod
		  FROM CBS.cbs_musteri_basvuru
		 WHERE tx_no = pn_islem_no;

		SELECT NVL(COUNT(*), 0)
		  INTO ln_mevcut
		  FROM CBS.cbs_dokuman_kodlari
		 WHERE dk_grup_kodu = ls_dk_grup_kod;

		IF NVL(ln_mevcut, 0) <> 0 THEN
			BEGIN
				SELECT COUNT(*)
				  INTO ln_adet
				  FROM CBS.cbs_musteri_basvuru_dokuman
				 WHERE tx_no = pn_islem_no;
			EXCEPTION
				WHEN OTHERS THEN
					RETURN 0;
			END;
		ELSE
			RETURN 1; --yoksa mevcut de?il
		END IF;

		RETURN ln_adet;
	EXCEPTION -- dokuman mevcut de?il ise
		WHEN OTHERS THEN
			RETURN 1;
	END;

	/*****************************************************************************************************************/
	/*   Function  sf_ortaklik_kontrol                                                                                         */
	/*   ortakl?k kontrolu %100 a?mamal?d?r.                                                                          */
	/*****************************************************************************************************************/
	FUNCTION sf_ortaklik_kontrol(pn_islem_no NUMBER)
		RETURN NUMBER IS
        CURSOR LC_OWNERSHIP IS
            SELECT SUM(OWNERSHIP) OWNERSHIP
              FROM CBS.CBS_CUSTOMER_APP_SHAREHOLDERS
            WHERE tx_no = pn_islem_no
            GROUP BY COMPANY_INN;
		ln_oran 	NUMBER;
		l_ucpointer VARCHAR2(3) := CBS.pkg_hata.getucpointer;
	BEGIN
      --BOM CBS-395 AntonPa 27102022
        FOR R_OWNERSHIP IN LC_OWNERSHIP
        LOOP
            IF R_OWNERSHIP.OWNERSHIP > 100
            THEN
                RETURN R_OWNERSHIP.OWNERSHIP;
            END IF;
        END LOOP;
        
		RETURN 0;
      --EOM CBS-395 AntonPa 27102022
	EXCEPTION
		WHEN OTHERS THEN
			RETURN 0;
	END;

	/*****************************************************************************************************************/
	FUNCTION sf_tax_zorunlumu(ps_working_basis VARCHAR2, pn_dk_grup_kod NUMBER, ps_musteri_tipi_kod VARCHAR2 DEFAULT NULL)
		RETURN VARCHAR2 IS
	BEGIN
		IF ps_working_basis = 'PATENT' THEN
			RETURN 'H';
		ELSE
			IF ps_working_basis = 'PECERTIFICATE' OR pn_dk_grup_kod IN (1000, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1018, 1019, 1022) 
            THEN
				RETURN 'E';
			ELSE
				RETURN 'H';
			END IF;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			RETURN 'H';
	END;

	/*****************************************************************************************************************/

	FUNCTION sf_registration_zorunlumu(ps_working_basis VARCHAR2, pn_dk_grup_kod NUMBER, ps_musteri_tipi_kod VARCHAR2 DEFAULT NULL)
		RETURN VARCHAR2 IS
	BEGIN
		IF pn_dk_grup_kod IN (1000, 1002, 1003, 1004, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1018, 1019) THEN
			RETURN 'E';
		ELSE
			RETURN 'H';
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			RETURN 'H';
	END;

	/*****************************************************************************************************************/
	FUNCTION sf_okpo_social_zorunlumu(ps_working_basis VARCHAR2, pn_dk_grup_kod NUMBER, ps_musteri_tipi_kod VARCHAR2 DEFAULT NULL)
		RETURN VARCHAR2 IS
	BEGIN
		IF ps_working_basis = 'PATENT' THEN
			RETURN 'H';
		ELSE
			IF ps_working_basis = 'PECERTIFICATE'
			OR pn_dk_grup_kod IN (1000, 1008, 1011, 1014, 1018) THEN
				RETURN 'E';
			ELSE
				RETURN 'H';
			END IF;
		END IF;
	EXCEPTION
		WHEN OTHERS THEN
			RETURN 'H';
	END;
/*****************************************************************************************************************/
END;
/

