create package     pkg_rbo_limited authid current_user
is
    type gl_info is record (
        sum_lc number,
        sum_fc number,
        curr varchar2(10)
    );

    type gl_info_ntt is table of gl_info;

    function gl_sum_from_sql_statement(sql_statement_in in varchar2, pd_date_in in varchar2) return gl_info_ntt;
end pkg_rbo_limited;
/

