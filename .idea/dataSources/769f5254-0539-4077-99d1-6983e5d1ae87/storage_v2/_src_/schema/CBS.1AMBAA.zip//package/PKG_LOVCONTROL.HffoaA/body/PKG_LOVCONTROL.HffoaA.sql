create PACKAGE BODY Pkg_Lovcontrol  IS

 -------------------------------------------------------------------------------------
 FUNCTION UrunTur2000Uygun(ps_lovcode VARCHAR2, ps_modul VARCHAR2, ps_urun VARCHAR2) RETURN NUMBER IS
 		  ln_returncode			NUMBER:=0;
 BEGIN
	IF ps_lovcode = 'URUNTUR' THEN
		IF ps_urun IN ('FORWARD','SPOT','SWAP','SWAP-FW') THEN
		   ln_returncode := 0;
		ELSE
		   ln_returncode := 1;
		END IF;
	ELSIF ps_lovcode = 'BORCLU' THEN
		IF ps_urun IN ('BLOKE-TP','BLOKE-YP','TEMINAT-TP','TEMINAT-YP','IHRACAT') THEN
			ln_returncode := 0;
		ELSE
			ln_returncode := 1;
		END IF;
	END IF;

	RETURN ln_returncode;
 END;

 -------------------------------------------------------------------------------------
 FUNCTION UrunSinifUygun(ps_modul VARCHAR2, ps_urun VARCHAR2 , ps_sinif VARCHAR2) RETURN NUMBER IS
 		  ln_returncode			NUMBER:=0;
 BEGIN
 	IF ps_modul = 'CURRENT' THEN
		IF ps_urun IN ('VESAIK MUK', 'KKV MUK.', 'AKREDTF-YP') THEN
		   ln_returncode := 1;
		END IF;
	END IF;

	RETURN ln_returncode;
 END;
  -------------------------------------------------------------------------------------
 FUNCTION UrunTur_OBJ_IHRITH_Uygun(ps_urun VARCHAR2 ) RETURN VARCHAR2 IS
 		  ls_returncode			VARCHAR2(1) := 'E';
 BEGIN
		IF ps_urun IN ('CURRENT','DEMAND DEP') THEN
		   ls_returncode := 'E' ;
		ELSE
		   ls_returncode := 'H' ;
		END IF;

	RETURN ls_returncode;
 END;

 -------------------------------------------------------------------------------------
 FUNCTION UrunTur_2030_Urun_Uygun(ps_urun VARCHAR2 ) RETURN VARCHAR2 IS
 		  ls_returncode			VARCHAR2(1) := 'E';
 BEGIN
		IF ps_urun IN ('ADVANCE','DOC.COLL.','AG.GOODS','ACC.DOC.') THEN
		   ls_returncode := 'E' ;
		ELSE
		   ls_returncode := 'H' ;
		END IF;

	RETURN ls_returncode;
 END;

  -------------------------------------------------------------------------------------
 PROCEDURE CBS_URUN_GRUBU_LIMIT_KONTROL(pn_txno number,
 		  							   pn_limitvarYP out number,pn_limitvarTL out number,
 		  							   pn_limitvarnakdi out number,pn_limitvargnakdi out number) is

	CURSOR cursor_limit IS
		select LC_LIMIT, FC_LIMIT,pkg_menkul_rapor.urun_grubu_nakdi_mi(urun_grub_no) NAKDI_MI
		from CBS_MUSTERI_URUN_LIMIT_GUNCEL
		where TX_NO=pn_txno;

	 row_limit	  cursor_limit%ROWTYPE;

BEGIN
	pn_limitvarYP     := 0; -- Limit yok
	pn_limitvarTL 	  := 0; -- Limit yok
	pn_limitvarNakdi  := 0; -- Limit yok
	pn_limitvarGNakdi := 0; -- Limit yok


	open cursor_limit;
	fetch cursor_limit into row_limit;

	while cursor_limit%found
	LOOP
	BEGIN
	  	if 	nvl(row_limit.fc_limit,0)  <>0 then
	  		pn_limitvarYP := pn_limitvarYP + 1;
	  	end if;

	  	if 	nvl(row_limit.lc_limit,0)  <>0 then
	  		pn_limitvarTL := pn_limitvarTL + 1;
	  	end if;

		if row_limit.NAKDI_MI = 'E' then
			pn_limitvarNakdi := pn_limitvarNakdi + 1;
		end if;

		if row_limit.NAKDI_MI = 'H' then
			pn_limitvarGNakdi := pn_limitvarGNakdi + 1;
		end if;
	END;
	FETCH cursor_limit INTO row_limit;
	END LOOP;
	close cursor_limit;

END;
  -------------------------------------------------------------------------------------

END;
/

