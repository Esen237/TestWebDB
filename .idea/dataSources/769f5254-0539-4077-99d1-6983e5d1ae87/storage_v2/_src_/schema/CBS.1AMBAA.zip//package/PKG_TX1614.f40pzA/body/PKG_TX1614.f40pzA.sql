create PACKAGE BODY     PKG_TX1614 IS
    pn_1614_banka_aciklama           number;
    pn_1614_dekont_aciklama          number;
    pn_1614_islem_sube               number;
    pn_1614_OUTLET_CASH_GL           number;
    pn_1614_borc_sube                number;
    pn_1614_referans                 number;
    pn_1614_istatistik_kodu          number;
    pn_1614_musteri_aciklama         number;
    pn_1614_doviz_kodu               number;
    pn_1614_kur                      number;
    pn_1614_fc_islem                 number;
    pn_1614_lc_islem                 number;
    pn_1614_tutar                    number;
    pn_1614_tutar_tl                 number;
    pn_1614_tutar_ret                number;
    pn_1614_tutar_ret_tl             number;
    pn_1614_tutar_received           number;
     pn_1614_tutar_received_tl           number;
    pn_1614_nakit_kodu_lc            number;
    pn_1614_nakit_kodu_fc            number;
    pn_1614_nbk_hesap_sube           number;
    pn_1614_ATM                      number;
    pn_1614_NBKR                     number;
    pn_1614_BANK                     number;
    pn_1614_INTERBANK_TRANSIT        number;
    pn_1614_CASH_RET_ACCOUNT         number;
    pn_1614_DATE                     number;
    ls_dk_no                         varchar2(2000);
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye,
           b.nakit_kodu nakit_kodu_lc,
           b.nakit_kodu nakit_kodu_fc,
           transfer_edilen_kisi,
           nufus_seri_no,
           verildigi_yer, verildigi_tarih,
           prefix_istatistik_kodu,
           istatistik_kodu    ,
           alici_sube_kodu,
           gonderen_sube_kodu
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_aciklama varchar2(200);
     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
     deger_girilmeli  exception;
     ls_doviz        varchar2(200);
     nakit_lc_yok    exception;
      nakit_fc_yok    exception;
     ls_dekont_aciklama       varchar2(2000);
  Begin

      Bakiye_Kontrol(pn_islem_no);
    ls_islem_tipi := 'Y';
    pkg_parametre.deger('1614_DEKONT_ACIKLAMA',ls_dekont_aciklama);

       Begin
          DELETE From cbs_kasa_kupur_bakiye_islem
           where tx_no = pn_islem_no and
                      doviz_kodu  not in ( select doviz_kodu
                                             from cbs_kasa_sube_trnsf_det_islem
                                          where tx_no = pn_islem_no);
          Exception when others then null;
      End;

    for c_bakiye in cur_bakiye loop
        ls_doviz := c_bakiye.doviz_kodu;
        if ls_doviz = pkg_genel.lc_al then
                  if c_bakiye.nakit_kodu_lc is null then
                     raise nakit_lc_yok;
                end if;
        else
                if c_bakiye.nakit_kodu_fc is null then
                     raise nakit_fc_yok;
                end if;
        end if;
         
            pkg_tx1601.Kontrol_Sonrasi(pn_islem_no,
                                       '1614',
                                        c_bakiye.bakiye,
                                        c_bakiye.doviz_kodu,
                                        ls_islem_tipi,
                                        null,null,null,null,'H' );


  end loop;

  if ls_doviz is null then
     raise deger_girilmeli;
  end if;

     for c_bakiye in cur_bakiye loop
        ls_doviz := c_bakiye.doviz_kodu;
        ls_aciklama := ls_dekont_aciklama ||' '||c_bakiye.alici_sube_kodu; --||'-'|| --pkg_genel.bolum_adi_al(c_bakiye.alici_sube_kodu);
        if c_bakiye.doviz_kodu = PKG_GENEL.LC_AL Then
           pkg_parametre.deger('G_LC_KASA',ls_dk_no);
         else
          pkg_parametre.deger('G_FC_KASA',ls_dk_no);
         end if;

         BEGIN
         
         log_at('asd1706','1-pn_islem_no',pn_islem_no);
         log_at('asd1706','2-ls_doviz',ls_doviz);
         log_at('asd1706','3-c_bakiye.bakiye', c_bakiye.bakiye);
         log_at('asd1706','4-ls_aciklama',ls_aciklama);
         log_at('asd1706','5-nufus_seri_no',c_bakiye.nufus_seri_no);
         log_at('asd1706','6-ls_dk_no',ls_dk_no);
         log_at('asd1706','7-prefix_istatistik_kodu',c_bakiye.prefix_istatistik_kodu);
         log_at('asd1706','8-ls_doviz',ls_doviz);
         log_at('asd1706','9-istatistik_kodu',c_bakiye.istatistik_kodu);
         log_at('asd1706','10-verildigi_yer',c_bakiye.verildigi_yer);
         log_at('asd1706','11-verildigi_tarih',c_bakiye.verildigi_tarih);
         
            pkg_cash_slip.cash_slip( pn_islem_no,
                                          1,
                                          pkg_muhasebe.banka_tarihi_bul ,
                                          ls_doviz,
                                          c_bakiye.bakiye,
                                          ls_aciklama,
                                          c_bakiye.nufus_seri_no ,
                                          null,
                                          ls_dk_no,
                                          null,
                                          c_bakiye.prefix_istatistik_kodu,
                                          ls_doviz,
                                          c_bakiye.istatistik_kodu,
                                          c_bakiye.verildigi_yer,
                                          c_bakiye.verildigi_tarih);

         EXCEPTION WHEN OTHERS THEN
                    pkg_cash_slip.Delete_Cash_Slip(pn_islem_no);
        End;
    End loop;


  Exception
    when  deger_girilmeli then
               Raise_application_error(-20100,pkg_hata.getUCPOINTER || '736' || pkg_hata.getUCPOINTER);
     when  nakit_lc_yok then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '737' || pkg_hata.getUCPOINTER);
     when  nakit_fc_yok then
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '738' || pkg_hata.getUCPOINTER);
  End;


  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
  Begin

      Bakiye_Kontrol(pn_islem_no);

    ls_islem_tipi := 'Y';

    for c_bakiye in cur_bakiye loop

        pkg_tx1601.Dogrulama_Sonrasi(pn_islem_no,
                                   '1614',
                                    c_bakiye.bakiye,
                                    c_bakiye.doviz_kodu,
                                    ls_islem_tipi );
    end loop;
 
  End;


  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    iptal_edilebilir_mi(pn_islem_no);
  End;


  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin

    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    iptal_edilebilir_mi(pn_islem_no);
       pkg_tx1601.iptal_onay_sonrasi(pn_islem_no ,'1614' );

    update cbs_kasa_sube_transfer
    set durum_kodu = 'I'
    where transfer_no in( select transfer_no
                                from cbs_kasa_sube_transfer_islem a
                              where a.tx_no = pn_islem_no);


  End;

  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
    PKG_Tx1601.Iptal_Muhasebelestir_Sonrasi(pn_islem_no ,'1614');
 End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
   cursor cur_bakiye is
    select distinct
           doviz_kodu,
           urun_sinif_kod,
           tutar bakiye
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;

     ls_retval varchar2(200);
     ls_islem_tipi varchar2(1);
     ls_istatistik varchar2(200);
     ls_nakit_lc   varchar2(200);
     ls_nakit_fc   varchar2(200);

  Begin

      Bakiye_Kontrol(pn_islem_no);

    ls_islem_tipi := 'Y';

    for c_bakiye in cur_bakiye loop

            PKG_Tx1601.Onay_Sonrasi(pn_islem_no,
                                   '1614',
                                    c_bakiye.bakiye,
                                    c_bakiye.doviz_kodu,
                                    ls_islem_tipi );
    end loop;

     begin
          insert into cbs_kasa_sube_transfer(transfer_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                                              durum_kodu, kasa_kodu, gonderen_sube_kodu, alici_sube_kodu,
                                            kullanici_kodu, banka_tarihi, islem_kod,
                                            transfer_edilen_kisi, nufus_seri_no, verildigi_yer, verildigi_tarih,
                                            yaratan_tx_no,REFERENCE, VALUE_DATE, BANK_ACCOUNT, BANK_NAME
                                            )
         select transfer_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod,
                                              durum_kodu, kasa_kodu, gonderen_sube_kodu, alici_sube_kodu,
                                            kullanici_kodu, banka_tarihi, islem_kod,
                                            transfer_edilen_kisi, nufus_seri_no, verildigi_yer, verildigi_tarih,
                                            tx_no,REFERENCE, VALUE_DATE, BANK_ACCOUNT, BANK_NAME

         from cbs_kasa_sube_transfer_islem
         where tx_no = pn_islem_no ;

         exception when no_data_found then null;
     end ;
     begin
          insert into cbs_kasa_sube_transfer_detay(transfer_no, doviz_kodu, tutar,yaratan_tx_no,RECEIVED_AMOUNT,RETURNED_AMOUNT)
         select transfer_no, doviz_kodu, tutar,tx_no,RECEIVED_AMOUNT,RETURNED_AMOUNT
         from cbs_kasa_sube_trnsf_det_islem
         where tx_no = pn_islem_no ;
         exception when no_data_found then null;
     end ;

  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     null;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Muhasebelesme(pn_islem_no number) is

    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ln_fis_no                   cbs_fis.numara%type :=0;
    ls_islem_kod               cbs_islem.islem_kod%type :='1614';
    ls_musteri_aciklama        varchar2(2000);
    ls_banka_aciklama          varchar2(2000);
    ls_fis_aciklama            varchar2(2000);
    ls_aciklama                   varchar2(2000);
    ls_musteri_aciklama_2      varchar2(2000);
    ls_kasa_kodu                varchar2(2000);
    ls_doviz_kodu               varchar2(2000);
    ln_plan_no                   number;

    ls_durum varchar2(200);
    kasa_kapali exception;
    ln_bank_account_no            CBS_KASA_SUBE_TRANSFER_ISLEM.BANK_ACCOUNT%TYPE;
 


 cursor cur_islem_cursor is
    select gonderen_sube_kodu,
           alici_sube_kodu,
           doviz_kodu,
           urun_sinif_kod,
           tutar,
           DECODE ( a.secenek ,'NBKR',ISTATISTIK_KODU  ||'10',null )istatistik_kodu,
           b.nakit_kodu nakit_kodu_lc,
           b.nakit_kodu nakit_kodu_fc,
           DECODE('100025',NULL,NULL,pkg_hesap.HesapSubeAl('100025')) nbk_hesap_sube,
           a.secenek,
           a.VALUE_DATE,
           a.BANK_ACCOUNT,
           a.BANK_NAME,
           a.REFERENCE,
           a.TRANSFER_TO_BANK,
           b.RETURNED_AMOUNT,
           b.RECEIVED_AMOUNT           
    from cbs_kasa_sube_transfer_islem a,
         cbs_kasa_sube_trnsf_det_islem b
    where a.tx_no = pn_islem_no and
          a.tx_no = b.tx_no;
          
 CURSOR CUR_SUBE_CURSOR IS 
   SELECT GONDEREN_SUBE_KODU       
   FROM CBS_KASA_SUBE_TRANSFER a, CBS_KASA_SUBE_TRANSFER_DETAY b
WHERE a. yaratan_tx_no = b. yaratan_tx_no AND SECENEK<>'ATM' AND REFERENCE IS NOT NULL AND URUN_SINIF_KOD='SENDING'
and a.reference  in (select distinct a.REFERENCE from CBS_KASA_SUBE_TRANSFER a, CBS_KASA_SUBE_TRANSFER b where a.reference = b.reference and a.yaratan_tx_no = pn_islem_no);
       

     r_CUR_SUBE_CURSOR CUR_SUBE_CURSOR%ROWTYPE;     
  Begin

  /******** 1614 Muhasebe islemleri****/
    varchar_list(pn_1614_banka_aciklama)  := ls_aciklama;
    varchar_list(pn_1614_banka_aciklama) := NULL;
    varchar_list(pn_1614_doviz_kodu) := NULL;
    varchar_list(pn_1614_islem_sube) := NULL;
    varchar_list(pn_1614_OUTLET_CASH_GL) := NULL;
    varchar_list(pn_1614_istatistik_kodu) := NULL;
    varchar_list(pn_1614_nakit_kodu_lc) := NULL;
    varchar_list(pn_1614_nakit_kodu_fc) := NULL;
    varchar_list(pn_1614_musteri_aciklama) := NULL;
    varchar_list(pn_1614_referans) := NULL;
    varchar_list(pn_1614_INTERBANK_TRANSIT) := NULL;--AndreiD
    number_list(pn_1614_TUTAR_RET):= 0;
    number_list(pn_1614_TUTAR_RET_TL):= 0;
    number_list(pn_1614_TUTAR_RECEIVED):= 0;
     number_list(pn_1614_tutar_received_tl):= 0;
    number_list(pn_1614_TUTAR):= 0;
    number_list(pn_1614_TUTAR_TL):= 0;
    number_list(pn_1614_kur):= 0;
    varchar_list(pn_1614_CASH_RET_ACCOUNT):= 0;--AndreiD
    boolean_list(pn_1614_fc_islem):= FALSE;
    boolean_list(pn_1614_lc_islem):= FALSE;
    boolean_list(pn_1614_ATM):= FALSE;
    boolean_list(pn_1614_NBKR):= FALSE;
    boolean_list(pn_1614_BANK):= FALSE;--AndreiD
    date_list(pn_1614_DATE):= NULL;
    
 OPEN CUR_SUBE_CURSOR;
 
 FETCH CUR_SUBE_CURSOR INTO r_CUR_SUBE_CURSOR;


 
 
/*** Liste Deger Atama K?sm? **/

 pkg_parametre.deger('1614_BANKA_ACIKLAMA',ls_banka_aciklama);
  pkg_parametre.deger('1614_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
    
  
   
   ls_aciklama :=     varchar_list(pn_1614_banka_aciklama);
   ls_fis_aciklama :=    pkg_genel.ISLEM_ADI_AL(1614) ;

    for c_islem_cursor in cur_islem_cursor loop     
    --log_at('nbkr','doviz_kodu'||' '||c_islem_cursor.doviz_kodu) ; 
            varchar_list(pn_1614_CASH_RET_ACCOUNT):= pkg_tx1613.sf_merkezbankasi_hesap_al (c_islem_cursor.doviz_kodu);--100025; --NBKR account
            varchar_list(pn_1614_banka_aciklama) := ls_banka_aciklama ;
            varchar_list(pn_1614_musteri_aciklama) := ls_musteri_aciklama ;

            boolean_list(pn_1614_fc_islem):= FALSE;
            boolean_list(pn_1614_lc_islem):= FALSE;
            boolean_list(pn_1614_ATM):= FALSE;
            boolean_list(pn_1614_NBKR):= FALSE;
            boolean_list(pn_1614_BANK):= FALSE;--AndreiD
            date_list(pn_1614_DATE):= NULL;--AndreiD

             
            ls_doviz_kodu := c_islem_cursor.doviz_kodu;
            ln_bank_account_no := c_islem_cursor.transfer_to_bank;--AndreiD
            varchar_list(pn_1614_doviz_kodu) := c_islem_cursor.doviz_kodu;

            if sf_istatistik_kod_zorunlumu(c_islem_cursor.secenek,c_islem_cursor.doviz_kodu )='E' then
               varchar_list(pn_1614_istatistik_kodu) := c_islem_cursor.istatistik_kodu||'01';
            end if;

            varchar_list(pn_1614_nakit_kodu_lc) := c_islem_cursor.nakit_kodu_lc;
            varchar_list(pn_1614_nakit_kodu_fc) := c_islem_cursor.nakit_kodu_fc;
            varchar_list(pn_1614_islem_sube) := c_islem_cursor.alici_sube_kodu;   --c_islem_cursor.alici_sube_kodu;AndreiD 04.06.2020
            
            log_at('1614','pn_1614_islem_sube'||' '|| c_islem_cursor.gonderen_sube_kodu);
            varchar_list(pn_1614_borc_sube) := r_cur_sube_cursor.gonderen_sube_kodu;--c_islem_cursor.gonderen_sube_kodu;
            
            log_at('1614','pn_1614_borc_sube'||' '|| c_islem_cursor.gonderen_sube_kodu);
            
            
            varchar_list(pn_1614_referans) := c_islem_cursor.reference;
            varchar_list(pn_1614_nbk_hesap_sube):= c_islem_cursor.nbk_hesap_sube;
            number_list(pn_1614_tutar):= c_islem_cursor.tutar;
           
            number_list(pn_1614_tutar_tl):=  pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.TUTAR,1,null,null,'N','A'));
            number_list(pn_1614_tutar_ret):= c_islem_cursor.RETURNED_AMOUNT;
            number_list(pn_1614_tutar_ret_tl):=  pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.RETURNED_AMOUNT,1,null,null,'N','A'));
            number_list(pn_1614_tutar_received):=c_islem_cursor.RECEIVED_AMOUNT;
            number_list(pn_1614_tutar_received_tl):=pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,c_islem_cursor.RECEIVED_AMOUNT,1,null,null,'N','A'));
             
             
             
            number_list(pn_1614_kur) :=pkg_kur.yuvarla(pkg_genel.LC_AL, pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'));
            date_list(pn_1614_date):= c_islem_cursor.value_date;--AndreiD
            
            


          -- hs,20100118, for outlet
    if pkg_tx6200.sube_outlet_mi(varchar_list(pn_1614_islem_sube)) = 'H' then
              pkg_parametre.deger('G_DK_FC_CASH_GL',      varchar_list(pn_1614_OUTLET_CASH_GL));
          else
              pkg_parametre.deger('G_DK_OUTLET_CASH_GL', varchar_list(pn_1614_OUTLET_CASH_GL));
          end if;

          if c_islem_cursor.secenek = 'BANK' then         
                varchar_list(pn_1614_banka_aciklama) := 'Assets exchange with'||' '|| c_islem_cursor.BANK_NAME;
                varchar_list(pn_1614_musteri_aciklama) := 'Assets exchange with'||' '|| c_islem_cursor.BANK_NAME;
                ls_fis_aciklama := 'Assets exchange with'||' '||c_islem_cursor.BANK_NAME ;
                
                boolean_list(pn_1614_BANK):= true;
                

                
                if TRUNC(c_islem_cursor.value_date)<=Pkg_Muhasebe.BANKA_TARIHI_BUL THEN
                    pkg_parametre.deger('G_DK_ASSETS_SETTLEMENT', varchar_list(pn_1614_INTERBANK_TRANSIT));      --G_DK_ASSETS_SETTLEMENT             
                    
                     if c_islem_cursor.doviz_kodu = PKG_GENEL.LC_AL  then
                     varchar_list(pn_1614_OUTLET_CASH_GL) := '100025'; 
                     varchar_list(pn_1614_nbk_hesap_sube) :=  '001';--c_islem_cursor.nbk_hesap_sube;--001
                     varchar_list(pn_1614_islem_sube)  :=   r_cur_sube_cursor.gonderen_sube_kodu; --dep 1612       
                     else                
                        varchar_list(pn_1614_OUTLET_CASH_GL):=ln_bank_account_no;
                        varchar_list(pn_1614_nbk_hesap_sube) :=  c_islem_cursor.nbk_hesap_sube;--001
                        varchar_list(pn_1614_islem_sube)  :=   r_cur_sube_cursor.gonderen_sube_kodu; --dep 1612   
                    end if;   
 
                                  
                else
                    pkg_parametre.deger('G_DK_NBKR_TRANSIT', varchar_list(pn_1614_INTERBANK_TRANSIT));            --10003000
                   
                     if c_islem_cursor.doviz_kodu = PKG_GENEL.LC_AL  then
                     varchar_list(pn_1614_OUTLET_CASH_GL) := '100025'; 
                     varchar_list(pn_1614_nbk_hesap_sube) :=  c_islem_cursor.nbk_hesap_sube;--001
                     varchar_list(pn_1614_islem_sube)  :=   r_cur_sube_cursor.gonderen_sube_kodu; --dep 1612                
                        else                
                        varchar_list(pn_1614_OUTLET_CASH_GL):=ln_bank_account_no;
                        varchar_list(pn_1614_nbk_hesap_sube) :=  '001';--c_islem_cursor.nbk_hesap_sube;--001
                     varchar_list(pn_1614_islem_sube)  :=   r_cur_sube_cursor.gonderen_sube_kodu; --dep 1612 
                    end if;
                    
                end if;
            else
                boolean_list(pn_1614_NBKR):= true;
                varchar_list(pn_1614_islem_sube)  :=   r_cur_sube_cursor.gonderen_sube_kodu; --dep 1612
            end if;
           
/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            ln_plan_no,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            ln_fis_no,
                            ls_fis_aciklama);

  end loop;
  
  
   CLOSE CUR_SUBE_CURSOR;
    if nvl(ln_fis_no,0) <> 0 then
         pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
    end if;

      PKG_Tx1601.Muhasebelesme(pn_islem_no ,'1614');

  End;

Procedure Bakiye_Kontrol(pn_islem_no number)
  is
/*
   ls_urun_sinif varchar2(200) := null;
     ls_retval varchar2(200);
    ls_pkod     varchar2(200);
    ls_kasa_kodu varchar2(200);
    ls_sube_kodu varchar2(200);
    ls_doviz varchar2(200);
    ln_adet  number := 0;
    ln_max_adet number := 5;
    cursor cur_doviz_adet is
     select count(distinct doviz_kodu) adet
     from  CBS_KASA_SUBE_TRNSF_DET_ISLEM b
     where tx_no  = pn_islem_no ;

    cursor cur_doviz is
     select distinct doviz_kodu
     from  CBS_KASA_SUBE_TRNSF_DET_ISLEM b
     where tx_no  = pn_islem_no and
            doviz_kodu not in ( select distinct doviz_kodu
                                      from cbs_kasa_kupur_bakiye_islem
                                      where tx_no =pn_islem_no);


    bakiye_buyuk            exception;
    karsilanmadi            exception;
*/
 Begin
/*
         select distinct urun_sinif_kod ,kasa_kodu,GONDEREN_SUBE_KODU
       into ls_urun_sinif,ls_kasa_kodu ,ls_sube_kodu
       from CBS_KASA_SUBE_TRANSFER_ISLEM
       where tx_no = pn_islem_no ;


        for c_doviz in cur_doviz loop
            ls_doviz := c_doviz.doviz_kodu ;
        end loop;
        if ls_doviz is not null then
          raise karsilanmadi;
         end if;

     Exception
     when no_data_found then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '757' || pkg_hata.getUCPOINTER);
     when karsilanmadi then
                   Raise_application_error(-20100,pkg_hata.getUCPOINTER || '760' ||  pkg_hata.getdelimiter|| to_char(ls_doviz) || pkg_hata.getdelimiter || pkg_hata.getUCPOINTER);
*/
NULL;
  End;

    procedure iptal_edilebilir_mi(pn_islem_no  number)
    is
     ls_durum cbs_kasa_sube_transfer_islem.durum_kodu%type;
     iptal_edilemez exception;
    Begin

        select durum_kodu
        into ls_durum
        from cbs_kasa_sube_transfer a
        where transfer_no in( select transfer_no
                                from cbs_kasa_sube_transfer_islem a
                              where a.tx_no = pn_islem_no);

        if ls_durum <> 'A' Then
           raise iptal_edilemez ;
        end if;

    Exception
      when iptal_edilemez then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getdelimiter|| pkg_hata.getUCPOINTER);

    End;

  Function sf_istatistik_kod_uygunmu(ps_istatistik_kodu varchar2) return varchar2
  is
  Begin

        return 'E';

  End;


  Function sf_istatistik_kod_zorunlumu(ps_choice varchar2, ps_doviz varchar2) return varchar2
  is
  begin

  if ps_choice='NBKR' and ps_doviz<>pkg_genel.LC_al then
    return 'E';
  else
      return 'H';
  end if;

  end;


Begin
    pn_1614_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1614_BANKA_ACIKLAMA');
    pn_1614_dekont_aciklama :=pkg_muhasebe.parametre_index_bul('1614_DEKONT_ACIKLAMA');
    pn_1614_islem_sube :=pkg_muhasebe.parametre_index_bul('1614_ISLEM_SUBE');
    pn_1614_OUTLET_CASH_GL :=pkg_muhasebe.parametre_index_bul('1614_OUTLET_CASH_GL');
    pn_1614_borc_sube :=pkg_muhasebe.parametre_index_bul('1614_BORC_SUBE');
    pn_1614_doviz_kodu :=pkg_muhasebe.parametre_index_bul('1614_DOVIZ_KODU');
    pn_1614_fc_islem :=pkg_muhasebe.parametre_index_bul('1614_FC_ISLEM');
    pn_1614_referans :=pkg_muhasebe.parametre_index_bul('1614_REFERANS');
    pn_1614_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1614_ISTATISTIK_KODU');
    pn_1614_NAKIT_kodu_LC :=pkg_muhasebe.parametre_index_bul('1614_NAKIT_KODU_LC');
    pn_1614_NAKIT_kodu_FC :=pkg_muhasebe.parametre_index_bul('1614_NAKIT_KODU_FC');
    pn_1614_kur :=pkg_muhasebe.parametre_index_bul('1614_KUR');
    pn_1614_tutar_ret :=pkg_muhasebe.parametre_index_bul('1614_TUTAR_RET');
    pn_1614_tutar_ret_tl :=pkg_muhasebe.parametre_index_bul('1614_TUTAR_RET_TL');
    pn_1614_tutar :=pkg_muhasebe.parametre_index_bul('1614_TUTAR');
    pn_1614_tutar_tl :=pkg_muhasebe.parametre_index_bul('1614_TUTAR_TL');
    pn_1614_lc_islem :=pkg_muhasebe.parametre_index_bul('1614_LC_ISLEM');
    pn_1614_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1614_MUSTERI_ACIKLAMA');
    pn_1614_ATM :=pkg_muhasebe.parametre_index_bul('1614_ATM');
    pn_1614_NBKR :=pkg_muhasebe.parametre_index_bul('1614_NBKR');
    pn_1614_BANK :=pkg_muhasebe.parametre_index_bul('1614_BANK');
    pn_1614_INTERBANK_TRANSIT:=pkg_muhasebe.parametre_index_bul('1614_INTERBANK_TRANSIT');
    pn_1614_CASH_RET_ACCOUNT:=pkg_muhasebe.parametre_index_bul('1614_CASH_RET_ACCOUNT');
    pn_1614_TUTAR_RECEIVED:=pkg_muhasebe.parametre_index_bul('1614_TUTAR_RECEIVED');
    pn_1614_TUTAR_RECEIVED_TL:=pkg_muhasebe.parametre_index_bul('1614_TUTAR_RECEIVED_TL');
    pn_1614_DATE :=pkg_muhasebe.parametre_index_bul('1614_DATE');
    pn_1614_nbk_hesap_sube := pkg_muhasebe.parametre_index_bul('1614_NBK_HESAP_SUBE');

END;
/

