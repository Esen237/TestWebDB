create PACKAGE BODY Pkg_Dth IS
  /*****************************************************************************************************************/
  /*   Function	Sf_Hesap_Bloke_Konan_Urunmu													               				  */
  /*   Bloke konulabilen urunler icerisinde degilse lov de gorulmeyecektir.																	   		  */
  /****************************************************************************************************************/
 FUNCTION Sf_Hesap_Urun_Tipi_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2
   IS
	 ls_sonuc  VARCHAR2(1) := 'E';
	BEGIN

 /* bloke konulmayan urunler asagidaki kosul k?sm?na eklenir */
       IF ps_urun_tur_kod IN  ('CASH COLL.','NOSTRO-LC','NOSTRO-FC','SWAP','SWAP-FW','FORWARD','SPOT','OVERDRAFT') THEN
	    	ls_sonuc := 'H' ;
		ELSE
			ls_sonuc := 'E' ;
		END IF;

	 RETURN ls_sonuc;
    EXCEPTION
	  WHEN OTHERS THEN RETURN 'E';
    END  Sf_Hesap_Urun_Tipi_Uygunmu;
END;
/

