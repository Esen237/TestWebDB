create PACKAGE     PKG_TX2001 is

  -- Author  : TIMUCIN_A
  -- Created : 10.07.2003 10:49:54
  -- Purpose : Hesap Kapan??lar?nda kullan?lacakt?r.

  Procedure Yaratma_Oncesi(pn_islem_no number); 		-- Islem giris kontrolden once cagrilir
  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);				-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);		-- Islem iptal edilirse
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);
  Function  sf_vadesizhesap_urunuygun(ps_urun_tur_kod varchar2 ) return varchar2;
  Function  sf_teminat_tanimlimi(pn_hesap_no number) return varchar2;
  Function Hesap_NEXTINTERESTCALCDATE_al(pn_hesap_no number) return date;
  Function Kapamasi_yapilmayacak_urunmu(pn_hesap_no number) return varchar2;
end PKG_TX2001;


/

