create PACKAGE BODY     Pkg_Ithalat IS
/*--------------------------------------------------------------------------*/
 PROCEDURE referans_alim_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2) IS
 BEGIN
   INSERT INTO CBS_ITH_REFERANS_ALIM_ISLEM
                             ( tx_no, urun_turu, urun_sinif, ithalatci_musteri,
							   doviz_kodu, dosya_tutari, sight_tutar, vadeli_tutar,
							   kabul_kredili_tutar, pesin_tutar, ulke_kodu, yukleme_vadesi,
							   akreditif_vadesi, mal_cinsi, teyit_kodu, akreditifin_sekli,
							   ihracatci_firma_unvani, ihracatci_firma_adres_1, ihracatci_firma_adres_2,
							   ihracatci_firma_adres_3, ihracatci_firma_adres_4, referans, durum_kodu,
							   bolum_kodu, referans_alim_tarihi, referans_alimda_kapali, eski_referans)
			           (SELECT pn_islem_no, urun_turu, urun_sinif, ithalatci_musteri,
							   doviz_kodu, dosya_tutari, sight_tutar, vadeli_tutar,
							   kabul_kredili_tutar, pesin_tutar, ulke_kodu, yukleme_vadesi,
							   akreditif_vadesi, mal_cinsi, teyit_kodu, akreditifin_sekli,
							   ihracatci_firma_unvani, ihracatci_firma_adres_1, ihracatci_firma_adres_2,
							   ihracatci_firma_adres_3, ihracatci_firma_adres_4, referans, durum_kodu,
							   bolum_kodu, referans_alim_tarihi, referans_alimda_kapali, eski_referans
						  FROM CBS_ITH_REFERANS_ALIM
						 WHERE referans = ps_ref);
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE provizyon_kopyala(pn_islem NUMBER, ps_ref VARCHAR2, pn_provizyon_no NUMBER) IS
 BEGIN
 INSERT INTO CBS_ITH_PROVIZYON_ISLEM
                (tx_no, referans, provizyon_no, acilis_degisiklik,
				 tahmini_odeme_vadesi, tahmini_odeme_baz_tarih,
   				 yeni_vade, yeni_vade_kullanildi, yeni_teyit_kodu,
   				 yeni_teyit_kullanildi, yeni_rambursman_banka, yeni_rambursman_kullanildi,
   				 tutar_artirim_azaltim, artirim_azaltim_tutar, yeni_tutar_kullanildi,
   				 aciklama, durum_kodu, provizyon_alim_tarihi,
   				 onay_rambursman_banka, muhabir_banka_musteri_no, onay_red)
		(SELECT pn_islem, referans, provizyon_no, acilis_degisiklik,
		        tahmini_odeme_vadesi, tahmini_odeme_baz_tarih,
		        yeni_vade, yeni_vade_kullanildi, yeni_teyit_kodu,
		        yeni_teyit_kullanildi, yeni_rambursman_banka, yeni_rambursman_kullanildi,
		        tutar_artirim_azaltim, artirim_azaltim_tutar, yeni_tutar_kullanildi,
		        aciklama, durum_kodu, provizyon_alim_tarihi,
		        onay_rambursman_banka, muhabir_banka_musteri_no, onay_red
		   FROM CBS_ITH_PROVIZYON
		  WHERE referans = ps_ref
		    AND provizyon_no = pn_provizyon_no);
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE akreditif_acilis_bilgi_al(ps_referans VARCHAR2, pn_provizyon NUMBER,
	                                 pn_ithalatci OUT NUMBER, ps_doviz OUT VARCHAR2,
									 pn_dosya_tutari OUT NUMBER, pn_sight_tutar OUT NUMBER,
									 pn_vadeli_tutar OUT NUMBER, pn_kabul_kredili_tutar OUT NUMBER,
									 pn_pesin_tutar OUT NUMBER, ps_ulke_kodu OUT VARCHAR2,
									 pd_yukleme_vadesi OUT DATE, pd_akreditif_vadesi OUT DATE,
									 ps_mal_cinsi OUT VARCHAR2, ps_teyit_kodu OUT VARCHAR2,
									 ps_akreditifin_sekli OUT VARCHAR2, psihracatci_firma_unvani OUT VARCHAR2,
									 ps_ihrfirma_adr1 OUT VARCHAR2, ps_ihrfirma_adr2 OUT VARCHAR2,
									 ps_ihrfirma_adr3 OUT VARCHAR2, ps_ihrfirma_adr4 OUT VARCHAR2,
									 pn_muhabir_banka OUT NUMBER, pn_rambursman OUT NUMBER,
									 ps_urun_turu OUT VARCHAR2, ps_urun_sinif OUT VARCHAR2,
									 ps_bolum_kodu OUT VARCHAR2) IS
 BEGIN
  SELECT DISTINCT
         a.ithalatci_musteri, a.doviz_kodu, a.dosya_tutari, a.sight_tutar,
         a.vadeli_tutar, a.kabul_kredili_tutar, a.pesin_tutar, a.ulke_kodu,
		 a.yukleme_vadesi, a.akreditif_vadesi, a.mal_cinsi, a.teyit_kodu,
		 a.akreditifin_sekli, a.ihracatci_firma_unvani, a.ihracatci_firma_adres_1,
		 a.ihracatci_firma_adres_2, a.ihracatci_firma_adres_3, a.ihracatci_firma_adres_4,
		 a.urun_turu, a.urun_sinif, a.bolum_kodu
    INTO pn_ithalatci, ps_doviz, pn_dosya_tutari, pn_sight_tutar,
		 pn_vadeli_tutar, pn_kabul_kredili_tutar, pn_pesin_tutar, ps_ulke_kodu,
		 pd_yukleme_vadesi, pd_akreditif_vadesi, ps_mal_cinsi, ps_teyit_kodu,
		 ps_akreditifin_sekli, psihracatci_firma_unvani, ps_ihrfirma_adr1,
		 ps_ihrfirma_adr2, ps_ihrfirma_adr3, ps_ihrfirma_adr4,
		 ps_urun_turu, ps_urun_sinif, ps_bolum_kodu
	FROM cbs_vw_provizyon_onay a
   WHERE a.referans = ps_referans
     AND a.provizyon_no = pn_provizyon;

  SELECT a.muhabir_banka_musteri_no, a.onay_rambursman_banka
    INTO pn_muhabir_banka, pn_rambursman
    FROM CBS_ITH_PROVIZYON a
   WHERE a.referans = ps_referans
     AND a.provizyon_no = pn_provizyon;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION dv_tutar_hesapla(pn_tutar NUMBER, ps_doviz VARCHAR2) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
 /*
   ln_temp := pkg_kur.DOVIZ_DOVIZ_KARSILIK(ps_doviz, pkg_genel.lc_al,
                                           null, pn_tutar, 1, null,	null,
										   'N', 'S');
   ln_temp := pkg_kur.yuvarla(pkg_genel.LC_AL, ln_temp * 0.0045);

   damga vergisi kalkt?.......
   */
   ln_temp := 0;
   RETURN ln_temp;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION masraf_kontrol_yap(ps_odeyecek VARCHAR2) RETURN VARCHAR2 IS
 BEGIN
    IF ps_odeyecek IN ('IMPORTER') THEN
	 RETURN 'Y';
	ELSE
	 RETURN 'N';
	END IF;
 END;
 FUNCTION masraf_kontrol_yap_nonakr(ps_odeyecek VARCHAR2) RETURN VARCHAR2 IS
 BEGIN
    IF ps_odeyecek IN ('IMPORTER') THEN
	 RETURN 'Y';
	ELSE
	 RETURN 'N';
	END IF;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION masraf_odeyecek_kontrol(pn_islem_no NUMBER) RETURN VARCHAR2 IS
 ln_temp NUMBER;
 BEGIN
   SELECT COUNT(*)
     INTO ln_temp
	 FROM CBS_MASRAF_ITH_IHR_ISL
	WHERE islem_no = pn_islem_no
	  AND odeyecek IN ('IMPORTER') ;
   IF ln_temp > 0 THEN
     RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE akreditif_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2) IS
 BEGIN
   INSERT INTO CBS_ITH_AKREDITIF_ISLEM
               (tx_no, bolum_kodu, referans, urun_turu, urun_sinif,
			    ithalatci_musteri, doviz_kodu, dosya_tutari, sight_tutar,
				vadeli_tutar, kabul_kredili_tutar, pesin_tutar, ulke_kodu,
				yukleme_vadesi, akreditif_vadesi, mal_cinsi, teyit_kodu,
				akreditifin_sekli, ihracatci_firma_unvani, ihracatci_firma_adres_1,
				ihracatci_firma_adres_2, ihracatci_firma_adres_3, ihracatci_firma_adres_4,
				muhabir_banka_musteri_no, rambursman_banka, kismi_yukleme, tesvikli_mi,
				tesvikli_tutar, dv_tutar, dv_tahsil_hesap, istatistik_kodu, kredi_hesap_no,
				kredi_teklif_satir_no, masraf_hesap_no, akreditif_acilis_tarihi, durum_kodu,
				yaratan_kullanici, yaratildigi_tarih, kredi_urun_tur, kredi_urun_sinif,
				akreditif_bakiye, pesin_transfer_tutari, yukleme_tutari,
				teminatli_mi, pre_istatistik_kodu, istatistik_doviz_kodu)
		(SELECT pn_islem_no, bolum_kodu, referans, urun_turu, urun_sinif,
			    ithalatci_musteri, doviz_kodu, dosya_tutari, sight_tutar,
				vadeli_tutar, kabul_kredili_tutar, pesin_tutar, ulke_kodu,
				yukleme_vadesi, akreditif_vadesi, mal_cinsi, teyit_kodu,
				akreditifin_sekli, ihracatci_firma_unvani, ihracatci_firma_adres_1,
				ihracatci_firma_adres_2, ihracatci_firma_adres_3, ihracatci_firma_adres_4,
				muhabir_banka_musteri_no, rambursman_banka, kismi_yukleme, tesvikli_mi,
				tesvikli_tutar, dv_tutar, dv_tahsil_hesap, istatistik_kodu, kredi_hesap_no,
				kredi_teklif_satir_no, masraf_hesap_no, akreditif_acilis_tarihi, durum_kodu,
				yaratan_kullanici, yaratildigi_tarih, kredi_urun_tur, kredi_urun_sinif,
				akreditif_bakiye, pesin_transfer_tutari, yukleme_tutari,
				teminatli_mi, pre_istatistik_kodu, istatistik_doviz_kodu
		   FROM CBS_ITH_AKREDITIF
		  WHERE referans = ps_referans);
END;

/*--------------------------------------------------------------------------*/
PROCEDURE  BakiyeGuncelle(pn_islem_no NUMBER, ps_tur VARCHAR2,ps_islem_tur VARCHAR2,ps_referans VARCHAR2,pn_vesaikno NUMBER,pn_tutar NUMBER) IS
	 ln_last_tutar				 NUMBER;
BEGIN
	 IF ps_tur='A' THEN
	 	ln_last_tutar:=NVL(pn_tutar,0);
	 ELSE--'B'
	 	ln_last_tutar:= -1*NVL(pn_tutar,0);
	 END IF;
	 IF ps_islem_tur = 'DOSYA' THEN
	 	UPDATE CBS_ITH_DOSYA a
		   SET DOSYA_BAKIYESI = NVL(DOSYA_BAKIYESI,0)+NVL(ln_last_tutar,0)
		 WHERE a.REFERANS = ps_referans;
	 ELSIF ps_islem_tur = 'AKREDITIF' THEN
	 	UPDATE CBS_ITH_AKREDITIF a
		   SET akreditif_bakiye = NVL(akreditif_bakiye,0)+NVL(ln_last_tutar,0)
		 WHERE a.referans = ps_referans;
	 ELSIF ps_islem_tur = 'VESAIK' THEN
 	 	UPDATE CBS_ITH_VESAIK a
		   SET vesaik_bakiyesi = NVL(vesaik_bakiyesi,0)+NVL(ln_last_tutar,0)
		 WHERE a.referans = ps_referans
		   AND a.vesaik_no = pn_vesaikno;
	 ELSIF 	ps_islem_tur = 'PESIN' THEN
	 	UPDATE CBS_ITH_AKREDITIF a
		   SET pesin_transfer_tutari = NVL(pesin_transfer_tutari,0)+NVL(ln_last_tutar,0)
		 WHERE a.referans = ps_referans;
	 ELSIF 	ps_islem_tur = 'YUKLEME' THEN
	 	UPDATE CBS_ITH_AKREDITIF a
		   SET yukleme_tutari = NVL(yukleme_tutari,0)+NVL(ln_last_tutar,0)
		WHERE a.referans = ps_referans;
	 ELSIF ps_islem_tur = 'VESAIKRISK' THEN
 	 	UPDATE CBS_ITH_VESAIK a
		   SET vesaik_riski = NVL(vesaik_riski,0)+NVL(ln_last_tutar,0)
		 WHERE a.referans = ps_referans
		   AND a.vesaik_no = pn_vesaikno;
	 ELSIF ps_islem_tur = 'TERKIN' THEN
	    IF NVL(pn_vesaikno,0) > 0 THEN
	 	 	UPDATE CBS_ITH_VESAIK a
			   SET terkin_toplami = NVL(terkin_toplami,0)+NVL(ln_last_tutar,0)
			 WHERE a.referans = ps_referans
			   AND a.vesaik_no = pn_vesaikno;
		ELSE
		    UPDATE CBS_ITH_DOSYA
			   SET terkin_toplami = NVL(terkin_toplami,0)+NVL(ln_last_tutar,0)
			 WHERE referans = ps_referans;
	    END IF;
	 ELSIF ps_islem_tur = 'TAAHHUT' THEN
	    IF NVL(pn_vesaikno,0) > 0 THEN
	 	 	UPDATE CBS_ITH_VESAIK a
			   SET taahhut_kapama_toplami = NVL(taahhut_kapama_toplami,0)+NVL(ln_last_tutar,0)
			 WHERE a.referans = ps_referans
			   AND a.vesaik_no = pn_vesaikno;
		ELSE
		    UPDATE CBS_ITH_DOSYA
			   SET taahhut_kapama_toplami = NVL(taahhut_kapama_toplami,0)+NVL(ln_last_tutar,0)
			 WHERE referans = ps_referans;
	    END IF;
	 END IF;

	 INSERT INTO CBS_ITHALAT_BAKIYE_LOG
	 (islem_no, ISLEM_ID,TUR,ISLEM_TIPI, REFERANS, VESAIK_NO, TUTAR)
	 VALUES
	 (pn_islem_no, Pkg_Genel.genel_kod_al('ITHALAT_BAKIYE_LOG'),ps_tur,ps_islem_tur,ps_referans,pn_vesaikno,pn_tutar);

END;
/*--------------------------------------------------------------------------*/
PROCEDURE  DurumGuncelle(ps_islem_tur VARCHAR2,ps_referans VARCHAR2,pn_vesaikno NUMBER,ps_durum VARCHAR2) IS
BEGIN
	  IF ps_islem_tur = 'DOSYA' THEN
	 	UPDATE CBS_ITH_DOSYA a
		   SET DURUM_KODU=ps_durum
		 WHERE a.REFERANS = ps_referans;
	  ELSIF ps_islem_tur = 'POLICE' THEN
	 	UPDATE CBS_ITH_POLICE a
		   SET DURUM_KODU=ps_durum
		 WHERE a.REFERANS = ps_referans
		 AND POLICE_NO=pn_vesaikno;
	 END IF;
END;
/*--------------------------------------------------------------------------*/
PROCEDURE masraf_kopyala(pn_islem_no NUMBER, ps_referans VARCHAR2, pn_vesaikno NUMBER DEFAULT 0) IS
BEGIN
  INSERT INTO CBS_MASRAF_ITH_IHR_ISL(islem_no, referans, sira_no, masraf_kodu, adi, dvz,
  		 	                         komisyon_tipi, tahsil_toplam, tahsil_edilemeyen, odeyecek,
									 oran, tutar, devre_gun_sayisi, taksit_sayisi, taksit_bas_tarih,
									 taksit_bitis_tarih, hesaplanan, bsmv, durum, vs_no, SOURCE,
									 yillik_oran, yil_donem_sayisi)
							 (SELECT pn_islem_no, referans, sira_no, masraf_kodu, adi, dvz,
  		 	                         komisyon_tipi, tahsil_toplam, tahsil_edilemeyen, odeyecek,
									 oran, tutar, devre_gun_sayisi, taksit_sayisi, taksit_bas_tarih,
									 taksit_bitis_tarih, hesaplanan, bsmv, durum, vs_no, SOURCE,
									 yillik_oran, yil_donem_sayisi
								FROM CBS_MASRAF_ITH_IHR
					           WHERE referans = ps_referans
							     AND durum = 'VALID'
								 AND vs_no = pn_vesaikno);  --po veya vs olursa vs_no 0 olmaz...

  INSERT INTO CBS_MASRAF_TAKSIT_ISLEM(islem_no, referans, taksit_no, taksit_tarihi,
  		 	  						  taksit_tutari, taksit_odeme_tarih, odenen_tutar, bsmv, masraf_kodu, vs_no)
							  (SELECT pn_islem_no, referans, taksit_no, taksit_tarihi,
  		 	  						  taksit_tutari, taksit_odeme_tarih, odenen_tutar, bsmv, masraf_kodu, vs_no
								 FROM CBS_MASRAF_TAKSIT
					            WHERE referans = ps_referans
								  AND vs_no = pn_vesaikno);

END;
/*--------------------------------------------------------------------------*/
PROCEDURE IthalatDosyaBilgiAktar(pn_txno NUMBER,ps_refno VARCHAR2) IS
BEGIN

 	INSERT INTO CBS_ITH_DOSYA_ISLEM
	(TX_NO, REFERANS, ITHALATCI_MUSTERI_NO, DOVIZ_KODU, TUTAR, ULKE_KODU, VESAIK_GELIS_SEKLI, TESLIM_SEKLI, AVAL_KODU, MAL_CINSI, IHRACATCI_FIRMA_UNVANI, IHRACATCI_FIRMA_ADRES1, IHRACATCI_FIRMA_ADRES2, IHRACATCI_FIRMA_ADRES3, IHRACATCI_FIRMA_ADRES4, MUHABIR_BANKA_MUSTERI_NO, MUHABIR_BANKA_UNVANI, MUHABIR_BANKA_ADRES1, MUHABIR_BANKA_ADRES2, MUHABIR_BANKA_ADRES3, MUHABIR_BANKA_ADRES4, MUHABIR_REFERANS, TESVIKLI, TESVIKLI_KISIM_TUTARI, MASRAF_HESAP_NO, BOLUM_KODU, DURUM_KODU, YARATAN_TXNO, DOSYA_BAKIYESI, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MASRAF_ZAMANI, INDIRIM_TUTARI, BEDELSIZ_TESLIM)
	(SELECT pn_txno,REFERANS, ITHALATCI_MUSTERI_NO, DOVIZ_KODU, TUTAR, ULKE_KODU, VESAIK_GELIS_SEKLI, TESLIM_SEKLI, AVAL_KODU, MAL_CINSI, IHRACATCI_FIRMA_UNVANI, IHRACATCI_FIRMA_ADRES1, IHRACATCI_FIRMA_ADRES2, IHRACATCI_FIRMA_ADRES3, IHRACATCI_FIRMA_ADRES4, MUHABIR_BANKA_MUSTERI_NO, MUHABIR_BANKA_UNVANI, MUHABIR_BANKA_ADRES1, MUHABIR_BANKA_ADRES2, MUHABIR_BANKA_ADRES3, MUHABIR_BANKA_ADRES4, MUHABIR_REFERANS, TESVIKLI, TESVIKLI_KISIM_TUTARI, MASRAF_HESAP_NO, BOLUM_KODU, DURUM_KODU, YARATAN_TXNO, DOSYA_BAKIYESI, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, MASRAF_ZAMANI, INDIRIM_TUTARI, BEDELSIZ_TESLIM
	FROM CBS_ITH_DOSYA
	WHERE REFERANS=ps_refno);

	Pkg_Ithalat.masraf_kopyala(pn_txno,ps_refno);

END;
/*--------------------------------------------------------------------------*/
FUNCTION TransferToplami(ps_referans VARCHAR2, pn_vesaikno NUMBER DEFAULT 0) RETURN NUMBER IS
	ln_toplam NUMBER:=0;
	ln_toplam2 NUMBER:=0;
BEGIN
	 /* TODO transfer toplami select*/
	 SELECT SUM(transfer_tutari)
	   INTO ln_toplam
	   FROM CBS_ITH_TRANSFER
	  WHERE referans = ps_referans
	    AND NVL(vesaik_no,0) = NVL(pn_vesaikno,0)
		AND durum_kodu = 'A';

	 SELECT SUM(pesin_transfer_tutar)
	   INTO ln_toplam2
	   FROM CBS_ITH_VESAIK_TRANSFER
	  WHERE referans = ps_referans
	    AND vesaik_no = NVL(pn_vesaikno,0)
		AND durum_kodu = 'A';

	 RETURN (NVL(ln_toplam,0) + NVL(ln_toplam2,0));
	 Exception when others then return 0;
END;
/*--------------------------------------------------------------------------*/
FUNCTION pt_kullanilan_bakiye(ps_referans VARCHAR2, pn_odeme_no NUMBER) RETURN NUMBER IS
ln_po_tutar NUMBER;
BEGIN  --pe?in transfer kullanilan bakiyesi
  SELECT NVL(SUM(NVL(pesin_transfer_tutar,0)),0)
    INTO ln_po_tutar
    FROM CBS_ITH_VESAIK_TRANSFER a
   WHERE a.referans = ps_referans
     AND a.pesin_transfer_no = pn_odeme_no;
   RETURN ln_po_tutar;
END;
/*--------------------------------------------------------------------------*/
 FUNCTION ith_akr_acilis_tarihi_al(ps_ref VARCHAR2) RETURN DATE IS
 ld_tarih DATE;
 BEGIN
     SELECT akreditif_acilis_tarihi
       INTO ld_tarih
	   FROM CBS_ITH_AKREDITIF
	  WHERE referans = ps_ref;

	 RETURN ld_tarih;
  EXCEPTION
   WHEN NO_DATA_FOUND THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '622' || Pkg_Hata.getUCPOINTER);
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '623' || Pkg_Hata.getdelimiter|| TO_CHAR(SQLCODE)|| ' '|| SQLERRM  || Pkg_Hata.getUCPOINTER);

END;
/*--------------------------------------------------------------------------*/
 PROCEDURE ith_vesaik_tutar_uygun(ps_referans VARCHAR2, pn_tutar NUMBER,  ps_hata OUT VARCHAR2) IS
 ln_akr_tutar NUMBER;
 ln_yukleme_tutar NUMBER;
 ls_kismi_yukleme CBS_ITH_AKREDITIF.kismi_yukleme%TYPE;
 BEGIN
     ps_hata := 'H';
     SELECT dosya_tutari, yukleme_tutari, kismi_yukleme
       INTO ln_akr_tutar, ln_yukleme_tutar, ls_kismi_yukleme
	   FROM CBS_ITH_AKREDITIF
	  WHERE referans = ps_referans;

	 IF pn_tutar > (ln_akr_tutar - ln_yukleme_tutar) THEN
	 	  RAISE_APPLICATION_ERROR(-20100, Pkg_Hata.GetUCPOINTER || '1928' || Pkg_Hata.GetDELIMITER || LTRIM(TO_CHAR(ln_akr_tutar - ln_yukleme_tutar, '999,999,999,999,999,999.99')) || Pkg_Hata.GetUCPOINTER );
	 END IF;

	 IF NVL(ls_kismi_yukleme,'a') = 'NOT ALLOWED' THEN
	    IF pn_tutar < ln_akr_tutar THEN
		  ps_hata := 'E';
        END IF;
     END IF;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE akreditif_bilgi_al (
    pn_referans VARCHAR2, pn_ith_musteri OUT VARCHAR2, ps_display_ith_musteri OUT VARCHAR2,
    pn_akr_tutar OUT NUMBER, ps_akr_doviz OUT VARCHAR2, ps_urun_tur OUT VARCHAR2,
	ps_urun_sinif OUT VARCHAR2, ps_ihracat_ulke OUT VARCHAR2, ps_teyit_kodu OUT VARCHAR2) IS
 BEGIN
   SELECT ithalatci_musteri, Pkg_Musteri.Sf_Musteri_Adi(ithalatci_musteri),
          dosya_tutari, doviz_kodu, urun_turu, urun_sinif, ulke_kodu, teyit_kodu
     INTO pn_ith_musteri, ps_display_ith_musteri, pn_akr_tutar, ps_akr_doviz,
 	      ps_urun_tur, ps_urun_sinif, ps_ihracat_ulke, ps_teyit_kodu
	 FROM CBS_ITH_AKREDITIF
	WHERE referans = pn_referans;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION pesin_transfer_tarih_al(ps_referans VARCHAR2, pn_pes_trans_no NUMBER) RETURN DATE IS
 ld_date DATE;
 BEGIN
  SELECT transfer_tarihi
    INTO ld_date
    FROM CBS_ITH_TRANSFER a
   WHERE a.referans = ps_referans
     AND a.transfer_no = pn_pes_trans_no
	 AND a.transfer_pesin_transfer = 'P'
	 AND a.durum_kodu = 'A';
	RETURN ld_date;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION pt_kalan_bakiye(ps_referans VARCHAR2, pn_odeme_no NUMBER) RETURN NUMBER IS
 ln_po_kullanilan NUMBER;
 ln_po_tutar NUMBER;
 BEGIN
  SELECT NVL(toplam_transfer_tutari,0)
    INTO ln_po_tutar
    FROM CBS_ITH_TRANSFER a
   WHERE referans = ps_referans
	 AND a.transfer_pesin_transfer = 'P'
     AND a.transfer_no = pn_odeme_no
	 AND durum_kodu = 'A';

  ln_po_kullanilan := pt_kullanilan_bakiye(ps_referans, pn_odeme_no);

   RETURN NVL(ln_po_tutar,0)-ln_po_kullanilan;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION vs_pesin_transfer_tutar(ps_referans VARCHAR2, pn_vesaik_no NUMBER) RETURN NUMBER IS
 ln_po_tutar NUMBER;
 BEGIN
  SELECT NVL(SUM(NVL(pesin_transfer_tutar,0)),0)
    INTO ln_po_tutar
    FROM CBS_ITH_VESAIK_TRANSFER a
   WHERE a.referans = ps_referans
     AND a.vesaik_no = pn_vesaik_no
	 AND a.durum_kodu = 'A';
   RETURN ln_po_tutar;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION ith_akreditif_bakiye_al(ps_referans VARCHAR2) RETURN NUMBER IS
 ln_bakiye NUMBER;
 BEGIN
  SELECT akreditif_bakiye
    INTO ln_bakiye
    FROM CBS_ITH_AKREDITIF
   WHERE referans = ps_referans;

   RETURN ln_bakiye;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE vesaik_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER) IS
 BEGIN
	 INSERT INTO CBS_ITH_VESAIK_ISLEM
	           (tx_no, bolum_kodu, referans, vesaik_no, vesaiki_veren,
			    vesaik_gonderim_tarih, vesaik_tutari, indirim_tutari, vesaik_ibraz_tarihi,
				vesaik_bakiyesi, vesaik_riski, aciklama, masraf_hesap_no, durum_kodu,
				masraf_zamani, rezerv, mevcut_rezerv1, mevcut_rezerv2, mevcut_rezerv3,
				mevcut_rezerv4, mevcut_rezerv5, mevcut_rezerv6, mevcut_rezerv7,
				mevcut_rezerv8, mevcut_rezerv9, mevcut_rezerv10, mevcut_rezerv11,
				mevcut_rezerv12, mevcut_rezerv13, mevcut_rezerv14, mevcut_rezerv15,
				mevcut_rezerv16, mevcut_rezerv17, mevcut_rezerv18, mevcut_rezerv19,
				mevcut_rezerv20, mevcut_rezerv21, mevcut_rezerv22, mevcut_rezerv23,
				mevcut_rezerv24, mevcut_rezerv25, mevcut_rezerv26, mevcut_rezerv27,
				mevcut_rezerv28, mevcut_rezerv29, mevcut_rezerv30, mevcut_rezerv31,
				mevcut_rezerv32, mevcut_rezerv33, mevcut_rezerv34, mevcut_rezerv35,
				mevcut_rezerv36, mevcut_rezerv37, mevcut_rezerv38, mevcut_rezerv39,
				mevcut_rezerv40, teslim_sekli)
	    (SELECT pn_islem_no, bolum_kodu, referans, vesaik_no, vesaiki_veren,
			    vesaik_gonderim_tarih, vesaik_tutari, indirim_tutari, vesaik_ibraz_tarihi,
				vesaik_bakiyesi, vesaik_riski, aciklama, masraf_hesap_no, durum_kodu,
				masraf_zamani, rezerv, mevcut_rezerv1, mevcut_rezerv2, mevcut_rezerv3,
				mevcut_rezerv4, mevcut_rezerv5, mevcut_rezerv6, mevcut_rezerv7,
				mevcut_rezerv8, mevcut_rezerv9, mevcut_rezerv10, mevcut_rezerv11,
				mevcut_rezerv12, mevcut_rezerv13, mevcut_rezerv14, mevcut_rezerv15,
				mevcut_rezerv16, mevcut_rezerv17, mevcut_rezerv18, mevcut_rezerv19,
				mevcut_rezerv20, mevcut_rezerv21, mevcut_rezerv22, mevcut_rezerv23,
				mevcut_rezerv24, mevcut_rezerv25, mevcut_rezerv26, mevcut_rezerv27,
				mevcut_rezerv28, mevcut_rezerv29, mevcut_rezerv30, mevcut_rezerv31,
				mevcut_rezerv32, mevcut_rezerv33, mevcut_rezerv34, mevcut_rezerv35,
				mevcut_rezerv36, mevcut_rezerv37, mevcut_rezerv38, mevcut_rezerv39,
				mevcut_rezerv40, teslim_sekli
            FROM CBS_ITH_VESAIK
			WHERE referans = ps_ref
			  AND vesaik_no = pn_vs_no);
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION akreditif_yukleme_toplam_al(ps_referans VARCHAR2) RETURN NUMBER IS
 ln_bakiye NUMBER;
 BEGIN
  SELECT yukleme_tutari
    INTO ln_bakiye
    FROM CBS_ITH_AKREDITIF
   WHERE referans = ps_referans;

   RETURN ln_bakiye;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION akreditif_tutar_al(ps_referans VARCHAR2) RETURN NUMBER  IS
 ln_tutar NUMBER;
 BEGIN
  SELECT dosya_tutari
    INTO ln_tutar
    FROM CBS_ITH_AKREDITIF
   WHERE referans = ps_referans;

   RETURN ln_tutar;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION kismi_yukleme_al(ps_referans VARCHAR2) RETURN VARCHAR2 IS
		ls_kismi_yukleme CBS_ITH_AKREDITIF.KISMI_YUKLEME%TYPE;
 BEGIN
	 SELECT kismi_yukleme
	 INTO ls_kismi_yukleme
	 FROM CBS_ITH_AKREDITIF
	 WHERE referans=ps_referans;

	 RETURN ls_kismi_yukleme;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION akr_urun_turu_al(ps_ref VARCHAR2) RETURN VARCHAR2 IS
  ls_temp VARCHAR2(10);
  BEGIN
    SELECT urun_turu
	  INTO ls_temp
	  FROM CBS_ITH_AKREDITIF
	 WHERE referans = ps_ref;
	RETURN ls_temp;
  END;
/*--------------------------------------------------------------------------*/
 FUNCTION akr_urun_sinif_al(ps_ref VARCHAR2) RETURN VARCHAR2 IS
  ls_temp VARCHAR2(20);
  BEGIN
    SELECT urun_sinif
	  INTO ls_temp
	  FROM CBS_ITH_AKREDITIF
	 WHERE referans = ps_ref;
	RETURN ls_temp;
  END;
/*--------------------------------------------------------------------------*/
 PROCEDURE vs_pesin_transfer_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER) IS
 BEGIN
	  INSERT INTO CBS_ITH_VESAIK_TRANSFER_ISLEM
	           ( tx_no, referans, vesaik_no, pesin_transfer_no,
			     pesin_transfer_tutar, durum_kodu)
	     (SELECT pn_islem_no, ps_ref, pn_vs_no, pesin_transfer_no,
			     pesin_transfer_tutar, durum_kodu
            FROM CBS_ITH_VESAIK_TRANSFER
		   WHERE referans = ps_ref
		     AND vesaik_no = pn_vs_no);
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE vs_odeme_kopyala(pn_islem_no NUMBER, ps_ref VARCHAR2, pn_vs_no NUMBER) IS
 BEGIN
      INSERT INTO CBS_ITH_VESAIK_ODEME_ISLEM
	          (tx_no, sira_no, referans, vesaik_no, vade_valor,
			   tutar, faiz_tutari, muhabir_masrafi, durum_kodu)
		(SELECT pn_islem_no, sira_no, ps_ref, pn_vs_no, vade_valor,
		        tutar, faiz_tutari, muhabir_masrafi, durum_kodu
		   FROM CBS_ITH_VESAIK_ODEME
		  WHERE referans = ps_ref
		    AND vesaik_no = pn_vs_no);
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE ithalatci_musteri_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pn_ith_musteri OUT NUMBER) IS
 BEGIN
  SELECT ithalatci_musteri_no
    INTO pn_ith_musteri
	FROM cbs_vw_ithalat
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
  END;
/*--------------------------------------------------------------------------*/
 PROCEDURE dosya_doviz_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_doviz OUT VARCHAR2) IS
 BEGIN
  SELECT doviz_kodu
    INTO ps_doviz
	FROM cbs_vw_ithalat
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE dosya_teslim_sekli_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_teslim_sekli OUT VARCHAR2) IS
 BEGIN
  SELECT teslim_sekli
    INTO ps_teslim_sekli
	FROM cbs_vw_ithalat
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE dosya_rambursman_al(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_rambursman OUT VARCHAR2) IS
 BEGIN
  SELECT rambursman_banka
    INTO ps_rambursman
	FROM cbs_vw_ithalat
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE odeme_non_db_al(ps_ref VARCHAR2, pn_vesaik NUMBER,
	                          pn_bakiye OUT NUMBER, pn_dosya_tutar OUT NUMBER,
							  ps_urun_tur OUT VARCHAR2, ps_urun_sinif OUT VARCHAR2,
							  ps_ithalat_tipi OUT VARCHAR2) IS
 BEGIN
  SELECT dosya_vesaik_bakiyesi, dosya_vesaik_tutari, urun_tur_kod,
         urun_sinif_kod, ithalat_tipi
    INTO pn_bakiye, pn_dosya_tutar, ps_urun_tur,
	     ps_urun_sinif, ps_ithalat_tipi
	FROM cbs_vw_ithalat a
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE odeme_vade_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pd_valor OUT DATE) IS
 BEGIN
  SELECT MAX(vade_valor)
    INTO pd_valor
    FROM CBS_ITH_VESAIK_ODEME
   WHERE referans = ps_ref
     AND vesaik_no = pn_vesaik
	 AND durum_kodu = 'A';
  END;
/*--------------------------------------------------------------------------*/
 PROCEDURE pt_tutar_uygun(ps_referans VARCHAR2, pn_tutar NUMBER) IS
  ln_pt_tutar NUMBER;
  ln_akr_tutar NUMBER;
 BEGIN
     SELECT NVL(pesin_transfer_tutari,0), NVL(dosya_tutari,0)
       INTO ln_pt_tutar, ln_akr_tutar
	   FROM CBS_ITH_AKREDITIF
	  WHERE referans = ps_referans;

   IF pn_tutar + ln_pt_tutar > ln_akr_tutar THEN
	  RAISE_APPLICATION_ERROR(-20100, Pkg_Hata.GetUCPOINTER || '657' || Pkg_Hata.GetDELIMITER || TO_CHAR(ln_akr_tutar - ln_pt_tutar) || Pkg_Hata.GetUCPOINTER );
   END IF;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION dosya_bakiyesi(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
  SELECT dosya_vesaik_bakiyesi
    INTO ln_temp
	FROM cbs_vw_ithalat a
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = NVL(pn_vesaik,0);
	RETURN ln_temp;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION ithalat_tipi(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN VARCHAR2 IS
 ls_temp VARCHAR2(9);
 BEGIN
  SELECT ithalat_tipi
    INTO ls_temp
	FROM cbs_vw_ithalat a
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = pn_vesaik;
	RETURN ls_temp;
 END;
/*--------------------------------------------------------------------------*/
 PROCEDURE ihracatci_masraflar_toplami_al(pn_islem_no NUMBER, pn_ihr_masraflar OUT NUMBER) IS
 ln_temp NUMBER := 0;
 ln_temp1 NUMBER := 0;
 BEGIN

     SELECT SUM(NVL(tahsil_edilemeyen,0))
	   INTO ln_temp
	   FROM CBS_MASRAF_ITH_IHR_ISL
	  WHERE islem_no = pn_islem_no
	    AND komisyon_tipi NOT LIKE 'DONEMSEL%'
		AND NVL(tahsil_edilemeyen,0) > 0
		AND odeyecek IN ('EXPORTER')
		AND durum = 'VALID';

      SELECT SUM(taksit_tutari - NVL(odenen_tutar,0))
	    INTO ln_temp1
	    FROM CBS_MASRAF_ITH_IHR_ISL a, CBS_MASRAF_TAKSIT_ISLEM b
	   WHERE b.islem_no = pn_islem_no
	     AND a.islem_no = b.islem_no
		 AND a.masraf_kodu = b.masraf_kodu
		 AND a.vs_no = b.vs_no
		 AND a.odeyecek IN ('EXPORTER')
		 AND taksit_tarihi <= Pkg_Muhasebe.banka_tarihi_bul;

    pn_ihr_masraflar := NVL(ln_temp,0) + NVL(ln_temp1,0);

 END;
/*--------------------------------------------------------------------------*/
PROCEDURE IthalatPoliceBilgiAktar(pn_txno NUMBER,ps_refno VARCHAR2,pn_police_no NUMBER) IS
BEGIN

 	INSERT INTO CBS_ITH_POLICE_ISLEM
	(TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, REFERANS, VESAIK_NO, DOVIZ_KODU, DOSYA_VESAIK_TUTARI, DOSYA_VESAIK_BAKIYESI, POLICE_TUTARI, FAIZ_TUTARI, MUHABIR_MASRAFI, POLICE_VADESI, MASRAF_HESAP_NO, ACIKLAMA, KREDI_URUN_SINIF, KREDI_TEKLIF_SATIR_NO, KREDI_HESAP_NO, BOLUM_KODU, DURUM_KODU, ACILIS_TARIHI, POLICE_NO, ITHALATCI_MUSTERI_NO, MASRAF_ZAMANI, AVAL_KODU, POLICE_YERI, TRANSFER_TOPLAMI, VESAIK_TESLIM)
	(SELECT pn_txno,MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, REFERANS, VESAIK_NO, DOVIZ_KODU, DOSYA_VESAIK_TUTARI, DOSYA_VESAIK_BAKIYESI, POLICE_TUTARI, FAIZ_TUTARI, MUHABIR_MASRAFI, POLICE_VADESI, MASRAF_HESAP_NO, ACIKLAMA, KREDI_URUN_SINIF, KREDI_TEKLIF_SATIR_NO, KREDI_HESAP_NO, BOLUM_KODU, DURUM_KODU, ACILIS_TARIHI, POLICE_NO, ITHALATCI_MUSTERI_NO, MASRAF_ZAMANI, AVAL_KODU, POLICE_YERI, TRANSFER_TOPLAMI, VESAIK_TESLIM
	FROM CBS_ITH_POLICE
	WHERE REFERANS=ps_refno AND police_no=pn_police_no);

	Pkg_Ithalat.masraf_kopyala(pn_txno,ps_refno);

END;

/*--------------------------------------------------------------------------*/
FUNCTION kredi_teklif_satir_no(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN VARCHAR2 IS
		 ln_satir_no				  NUMBER;
BEGIN
	 SELECT KREDI_TEKLIF_SATIR_NO
	 INTO ln_satir_no
	 FROM cbs_vw_ithalat
	 WHERE referans=ps_ref
	 AND vesaik_no IS NULL;

	 RETURN ln_satir_no;
END;
/*--------------------------------------------------------------------------*/
 FUNCTION dosya_urun_turu_al(ps_ref VARCHAR2) RETURN VARCHAR2 IS
  ls_temp VARCHAR2(10);
  CURSOR c_0 IS
    SELECT urun_tur_kod
	  FROM cbs_vw_ithalat
	 WHERE referans = ps_ref;
  BEGIN
    OPEN c_0;
	FETCH c_0 INTO ls_temp;
	CLOSE c_0;
	RETURN ls_temp;
  END;

/*--------------------------------------------------------------------------*/
 FUNCTION dosya_tutar(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
  SELECT dosya_vesaik_tutari
    INTO ln_temp
	FROM cbs_vw_ithalat a
  WHERE referans = ps_ref
    AND NVL(vesaik_no,0) = NVL(pn_vesaik,0);
	RETURN ln_temp;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION Taahhut_Kapama_Toplami(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT taahhut_kapama_toplami
     INTO ln_temp
	 FROM cbs_vw_ithalat
	WHERE referans = ps_ref
	  AND NVL(vesaik_no,0) = NVL(pn_vesaik,0)
	  AND durum_kodu = 'A';
   RETURN ln_temp;
    Exception when others then return 0;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION Terkin_Toplami(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 BEGIN
   SELECT terkin_toplami
     INTO ln_temp
	 FROM cbs_vw_ithalat
	WHERE referans = ps_ref
	  AND NVL(vesaik_no,0) = NVL(pn_vesaik,0)
	  AND durum_kodu = 'A';
   RETURN ln_temp;
   Exception when others then return 0;
 END;
/*--------------------------------------------------------------------------*/
 FUNCTION dosya_urun_sinif(ps_ref VARCHAR2) RETURN VARCHAR2 IS
  ls_temp VARCHAR2(20);
  CURSOR c_0 IS
    SELECT urun_sinif_kod
	  FROM cbs_vw_ithalat
	 WHERE referans = ps_ref;
  BEGIN
    OPEN c_0;
	FETCH c_0 INTO ls_temp;
	CLOSE c_0;
	RETURN ls_temp;
  END;
/*--------------------------------------------------------------------------*/
FUNCTION teyit_kodu_al(ps_ref VARCHAR2) RETURN VARCHAR2 IS
	ls_teyit_kodu cbs_vw_ithalat.TEYIT_KODU%TYPE;
BEGIN

	 SELECT TEYIT_KODU
     INTO ls_teyit_kodu
	 FROM cbs_vw_ithalat
	WHERE referans = ps_ref
	  AND ITHALAT_TIPI='AKREDITIF';

     RETURN ls_teyit_kodu;

EXCEPTION
     WHEN NO_DATA_FOUND THEN
	 	  RETURN NULL;

END;
/*--------------------------------------------------------------------------*/
FUNCTION ithalatci_musteri_al(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
pn_mus_no NUMBER;
BEGIN
  ithalatci_musteri_al(ps_ref, pn_vesaik, pn_mus_no);
  RETURN (pn_mus_no);
END;
/*--------------------------------------------------------------------------*/
FUNCTION police_vade_al(ps_ref VARCHAR2, pn_police_no NUMBER) RETURN DATE IS
ld_date DATE;
BEGIN
 SELECT police_vadesi
   INTO ld_date
   FROM CBS_ITH_POLICE
  WHERE referans = ps_ref
    AND police_no = pn_police_no;
  RETURN ld_date;
END;
/*--------------------------------------------------------------------------*/
PROCEDURE odeme_vade_al(ps_ref VARCHAR2, pn_vesaik NUMBER, pn_odeme_no NUMBER, pd_valor OUT DATE) IS
 BEGIN
  SELECT vade_valor
    INTO pd_valor
    FROM CBS_ITH_VESAIK_ODEME
   WHERE referans = ps_ref
     AND vesaik_no = pn_vesaik
	 AND sira_no = pn_odeme_no
	 AND durum_kodu = 'A';
  END;
/*--------------------------------------------------------------------------*/
FUNCTION  sf_modul_tur_kodu_al(ps_modul_tur_kod CBS_URUN_TUR.MODUL_TUR_KOD%TYPE) RETURN VARCHAR2
IS
  ls_uygun  VARCHAR2(1) := 'H';
  BEGIN
		IF  ps_modul_tur_kod = 'IMPORT' THEN
	   	  ls_uygun := 'E';
		ELSE
		    ls_uygun := 'H';
		END IF;
		RETURN ls_uygun;
    EXCEPTION
	  WHEN OTHERS THEN RETURN 'H';
  END ;
------------------------------------------------------------------------------------------
FUNCTION Modul_Tur_Import RETURN VARCHAR2
IS
BEGIN
	 RETURN 'IMPORT';
END;
------------------------------------------------------------------------------------------
FUNCTION  sf_musteri_tipi_al(ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2
IS
  ls_uygun  VARCHAR2(1) := 'H';
  BEGIN
		IF  ps_musteri_tipi_kod IN ('2','3' ) THEN
	   	  ls_uygun := 'E';
		ELSE
		    ls_uygun := 'H';
		END IF;
		RETURN ls_uygun;
    EXCEPTION
	  WHEN OTHERS THEN RETURN 'H';
  END ;
------------------------------------------------------------------------------------------
FUNCTION  sf_durum_kodu_al(ps_durum_kodu CBS_MUSTERI.durum_kodu%TYPE) RETURN VARCHAR2
IS
  ls_uygun  VARCHAR2(1) := 'H';
  BEGIN
		IF  ps_durum_kodu IN ('A','G' ) THEN
	   	  ls_uygun := 'E';
		ELSE
		    ls_uygun := 'H';
		END IF;
		RETURN ls_uygun;
    EXCEPTION
	  WHEN OTHERS THEN RETURN 'H';
  END ;
------------------------------------------------------------------------------------------
FUNCTION Tanim_Tipi RETURN VARCHAR2
IS
BEGIN
	 RETURN 'IHR-FIRMA';
END;
------------------------------------------------------------------------------------------
FUNCTION Durum_Kodu RETURN VARCHAR2
IS
BEGIN
	 RETURN 'V';
END;
------------------------------------------------------------------------------------------
FUNCTION  Import_Loan_Urun_Tur RETURN VARCHAR2
IS
BEGIN
	 RETURN 'IMPORT L/C';
END;
/*--------------------------------------------------------------------------*/
 FUNCTION akreditif_urun_sinif_al(ps_modul_tur VARCHAR2,
 		  						  ps_urun_tur  VARCHAR2,
								  ps_covered   VARCHAR2,
								  ps_confirmed VARCHAR2	,
								  ps_lc_fc     VARCHAR2
 		  						  ) RETURN VARCHAR2 IS
  ls_temp VARCHAR2(20);

  BEGIN
    SELECT URUN_SINIF_KOD
	  INTO ls_temp
	  FROM CBS_AKREDITIF_URUN
	 WHERE MODUL_TUR_KOD  	 	  = ps_modul_tur
	 AND   URUN_TUR_KOD 		  = ps_urun_tur
	 AND   COVERED_UNCOVERED 	  = ps_covered
	 AND   CONFIRMED_UNCONFIRMED  = DECODE(ps_confirmed,'TEYITLI','CONFIRMED','UNCONFIRMED')
	 AND   LC_FC 				  = ps_lc_fc;

	RETURN ls_temp;
  END;
------------------------------------------------------------------------------------------
FUNCTION police_urun_uygunmu( ps_urun_tur VARCHAR2,ps_urun_sinif VARCHAR2) RETURN VARCHAR2 IS
BEGIN
   IF  (ps_urun_tur  IN ('L/C FC','L/C LC') AND ps_urun_sinif IN ('ACCEPTANCE','MIXED' ))
        OR ps_urun_tur IN('ACC.DOC.')  THEN
	  RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
FUNCTION police_vesaik_urun_uygunmu( ps_urun_tur VARCHAR2,ps_urun_sinif VARCHAR2) RETURN VARCHAR2 IS
BEGIN
   IF  ps_urun_tur  IN ('L/C FC','L/C LC') AND ps_urun_sinif IN ('ACCEPTANCE','MIXED' ) THEN
     RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
FUNCTION musteri_tip_uygunmu( ps_musteri_tipi_kod CBS_MUSTERI.MUSTERI_TIPI_KOD%TYPE) RETURN VARCHAR2 IS
BEGIN
--2-ticari
--3-kurumsal
   IF  ps_musteri_tipi_kod  IN ('2','3')   THEN
	  RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
FUNCTION loan_urun_tur_uygunmu(ps_urun_tur_kod CBS_URUN_SINIF.URUN_TUR_KOD%TYPE) RETURN VARCHAR2 IS
BEGIN
   IF  ps_urun_tur_kod  IN ('ACCEPTANCE')  THEN
     RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
FUNCTION loan_urun_tur RETURN VARCHAR2 IS
BEGIN
      RETURN 'ACCEPTANCE';
END;
FUNCTION urun_akreditifmi(ps_urun_tur_kod CBS_URUN_SINIF.URUN_TUR_KOD%TYPE) RETURN VARCHAR2 IS
BEGIN
   IF  ps_urun_tur_kod  IN ('L/C FC','L/C LC')  THEN
     RETURN 'E';
   ELSE
     RETURN 'H';
   END IF;
END;
PROCEDURE vesaik_teslim_guncelle(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_teslim VARCHAR2, pd_teslim DATE, pn_tx_no NUMBER) IS
 CURSOR c_0 IS
   SELECT *
     FROM CBS_ITH_VESAIK v
	WHERE v.referans = ps_ref
	  AND v.vesaik_no = pn_vesaik
	 FOR UPDATE;
  r_0 c_0%ROWTYPE;
  CURSOR c_1 IS
    SELECT *
	  FROM CBS_ITH_DOSYA d
	 WHERE d.referans = ps_ref
	   FOR UPDATE;
  r_1 c_1%ROWTYPE;
 BEGIN
   --bu vesaik ?zerinde ba?ka ?lem yap?lm??sa ve bu i?lem daha sonra iptal
   --edilirse vesaik ?zerindeki di?er i?lemler problemli olabilir.
   IF NVL(pn_vesaik,0) = 0 THEN --dosya update
      OPEN c_1;
	    FETCH c_1 INTO r_1;
		INSERT INTO CBS_ITH_VESAIK_TESLIM_LOG
		      (tx_no, referans, vesaik_no, durum_kodu,
			   from_teslim_edildi, to_teslim_edildi,
		       from_teslim_tarihi, to_teslim_tarihi)
		VALUES (pn_tx_no, ps_ref, pn_vesaik, 'A',
		        r_1.vesaik_cikis, ps_teslim,
		        r_1.vesaik_teslim_tarihi, pd_teslim);
		UPDATE CBS_ITH_DOSYA
		   SET vesaik_cikis = ps_teslim,
		       vesaik_teslim_tarihi = pd_teslim
		 WHERE CURRENT OF c_1;
	   CLOSE c_1;
   ELSE
      OPEN c_0;
	    FETCH c_0 INTO r_0;
		INSERT INTO CBS_ITH_VESAIK_TESLIM_LOG
		      (tx_no, referans, vesaik_no, durum_kodu,
			   from_teslim_edildi, to_teslim_edildi,
		       from_teslim_tarihi, to_teslim_tarihi)
		VALUES (pn_tx_no, ps_ref, pn_vesaik, 'A',
		        r_0.vesaik_cikis, ps_teslim,
		        r_0.vesaik_teslim_tarihi, pd_teslim);
		UPDATE CBS_ITH_VESAIK
		   SET vesaik_cikis = ps_teslim,
		       vesaik_teslim_tarihi = pd_teslim
		 WHERE CURRENT OF c_0;
	   CLOSE c_0;
   END IF;
 END;
/*--------------------------------------------------------------------------*/
PROCEDURE vesaik_teslim_guncelle_geri_al(pn_tx_no NUMBER) IS
 ls_ref VARCHAR2(16);
 ln_vesaik NUMBER;
 CURSOR c_0 IS
   SELECT *
     FROM CBS_ITH_VESAIK v
	WHERE v.referans = ls_ref
	  AND v.vesaik_no = ln_vesaik
	 FOR UPDATE;
  r_0 c_0%ROWTYPE;
  CURSOR c_1 IS
    SELECT *
	  FROM CBS_ITH_DOSYA d
	 WHERE d.referans = ls_ref
	   FOR UPDATE;
  r_1 c_1%ROWTYPE;
  CURSOR c_2 IS
    SELECT *
	  FROM CBS_ITH_VESAIK_TESLIM_LOG
	 WHERE tx_no = pn_tx_no
	   FOR UPDATE;
  r_2 c_2%ROWTYPE;
 BEGIN
   OPEN c_2;
	 FETCH c_2 INTO r_2;
	 IF c_2%NOTFOUND THEN
	   CLOSE c_2;
	   RETURN;
	 END IF;
	 ls_ref := r_2.referans;
	 ln_vesaik := r_2.vesaik_no;
	 IF ln_vesaik = 0 THEN --dosya update
	  OPEN c_1;
		FETCH c_1 INTO r_1;
		UPDATE CBS_ITH_DOSYA
		   SET vesaik_cikis = r_2.from_teslim_edildi,
		       vesaik_teslim_tarihi = r_2.from_teslim_tarihi
		 WHERE CURRENT OF c_1;
	  CLOSE c_1;
	 ELSE
	  OPEN c_0;
	    FETCH c_0 INTO r_0;
		UPDATE CBS_ITH_VESAIK
		   SET vesaik_cikis = r_2.from_teslim_edildi,
		       vesaik_teslim_tarihi = r_2.from_teslim_tarihi
		 WHERE CURRENT OF c_0;
	  CLOSE c_0;
	 END IF;
	 UPDATE CBS_ITH_VESAIK_TESLIM_LOG
	    SET durum_kodu = 'I'
      WHERE CURRENT OF c_2;
   CLOSE c_2;
 END;
 ------------------------------------------------------------------------------------------
FUNCTION vesaik_cikis_urun_uygun(ps_modul VARCHAR2, ps_urun VARCHAR2) RETURN NUMBER IS
 ln_ret NUMBER := 0;
 BEGIN
   IF ps_modul = Pkg_Ithalat.modul_tur_import THEN
      IF ps_urun IN ('DOC.COLL.', 'ACC.DOC.', 'L/C FC','L/C LC') THEN
	    ln_ret := 1;
	  END IF;
   END IF;
   RETURN ln_ret;
 END;
 /*--------------------------------------------------------------------------*/
FUNCTION vesaik_teslim_referans_uygun(ps_ref VARCHAR2, pn_vesaik NUMBER) RETURN NUMBER IS
 ln_ret NUMBER;
 CURSOR c_0 IS
  SELECT *
    FROM cbs_vw_ithalat
   WHERE referans = ps_ref
     AND NVL(vesaik_no,0) = NVL(pn_vesaik,0);
 r_0 c_0%ROWTYPE;
 CURSOR c_1 IS
  SELECT COUNT(*)
    FROM CBS_ITH_POLICE
   WHERE referans = ps_ref
     AND vesaik_no = NVL(pn_vesaik,0)
	 AND durum_kodu <> 'I';
 ln_sayi NUMBER;
 BEGIN
   OPEN c_0;
   FETCH c_0 INTO r_0;
   CLOSE c_0;
   IF (r_0.urun_tur_kod = 'DOC.COLL.')
      OR (Pkg_Ithalat.urun_akreditifmi(r_0.urun_tur_kod)='E' AND r_0.urun_sinif_kod = 'SIGHT') THEN
	   --bakiye sifir 0 olmali  , 'Vesaik  MUK.',
	   IF r_0.dosya_vesaik_bakiyesi = 0 THEN
	    ln_ret := 1;
	   ELSE
	    ln_ret := 0;
	  END IF;
   ELSIF (r_0.urun_tur_kod = 'ACC.DOC.')
      OR (Pkg_Ithalat.urun_akreditifmi(r_0.urun_tur_kod)='E' AND r_0.urun_sinif_kod = 'ACCEPTANCE') THEN
	   --police olmali
	   OPEN c_1;
	   FETCH c_1 INTO ln_sayi;
	   CLOSE c_1;
	   IF ln_sayi > 0 THEN
	    ln_ret := 1;
	   ELSE
	    ln_ret := 0;
	  END IF;
   ELSE
      ln_ret := 1;
   END IF;
   RETURN ln_ret;
 END;
/*--------------------------------------------------------------------------*/
PROCEDURE vesaik_cikis_bilgileri(ps_ref VARCHAR2, pn_vesaik NUMBER, ps_cikis OUT VARCHAR2, pd_cikis OUT DATE) IS
	ls_cikis cbs_vw_ithalat.vesaik_cikis%TYPE;
	ld_cikis cbs_vw_ithalat.vesaik_teslim_tarihi%TYPE;
 BEGIN
   BEGIN
	 SELECT vesaik_cikis, vesaik_teslim_tarihi
       INTO ls_cikis, ld_cikis
	   FROM cbs_vw_ithalat
	  WHERE referans = ps_ref
	    AND NVL(vesaik_no,0) = NVL(pn_vesaik,0)
		AND ithalat_tipi IN ('DOSYA', 'VESAIK');
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
	 	   ls_cikis := NULL;
		   ld_cikis := NULL;
	END;
	ps_cikis := ls_cikis;
	pd_cikis := ld_cikis;
 END;

END;
/

