create PACKAGE Pkg_Tx7051 IS
/******************************************************************************
Name       : PKG_TX7051
Created By : Hakan SAMSA
Purpose	  : Card Payment Definition
******************************************************************************/
PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 	-- Islem giris kontrolden gectikten sonra cagrilir

PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);	-- Islem dogrulandiktan sonra cagrilir
PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);		-- Islem iptal edildikten sonra cagrilir

PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);		-- Islem onaylandiktan sonra cagrilir
PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);	-- Islem reddedildikten sonra cagrilir

PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);		-- Islem tamamlandiktan sonra cagrilir
PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  	-- Isleme iliskin formlar basildiktan sonra cagrilir
PROCEDURE Muhasebelesme(pn_islem_no NUMBER);		-- Islemin muhasebelesmesi icin cagrilir

PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);

PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
PROCEDURE kayit_al(pn_musteri in number,
		  		   ps_komisyon_tipi in varchar2,
		  		   pn_kart_no in number,
				   ps_odeyecek out varchar2,
				   pn_odeyecek_musteri out number,
				   pn_odeyecek_musteri_hesap out number,
				   pd_expire_date out date,
				   ps_status out varchar2);
FUNCTION Onceden_Girilmis(pn_musteri number,pn_kart_no number,ps_komisyon_tipi varchar2) RETURN  VARCHAR2;
END;


/

