create PACKAGE BODY     PKG_SOA_INQUIRY IS
/******************************************************************************
   NAME        : FUNCTION GetCustomizeElements
   Prepared By : Almas Nurhozhaev
   Date        : 31.03.08
   Purpose     : Get Customization Elements Data
******************************************************************************/
FUNCTION GetCustomizeElements(pn_personCD IN VARCHAR2,
                              ps_element_type IN VARCHAR2,
                              ps_langCD IN VARCHAR2,
                              pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN

     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

     --Get Customization Elements Settings
      OPEN pc_ref FOR
           SELECT a.ELEMENT_ID, c.ELEMENT_TYPE, a.STATUS_CD, d.SUBJECT_TEXT, a.ELEMENT_LOCATION, a.SORT_ORDER, c.LEFT_POZ, c.MIDDLE_POZ, c.RIGHT_POZ, d.DESCRIPTION
                      FROM corpint.tbl_customize_person a , corpint.tbl_customize c, corpint.tbl_customize_description d
                    WHERE c.ELEMENT_ID = a.ELEMENT_ID
                 AND d.ELEMENT_ID = a.ELEMENT_ID
                    AND a.PERSON_ID = TO_NUMBER(pn_personCD)
                 AND c.ELEMENT_TYPE = ps_element_type
                 AND d.LANG_CD = ps_langCD
                 AND c.STATUS_CD = 'sENAB';
  RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
      ls_returncode:= '999';
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetExchangeRates
   Prepared By : Almas Nurhozhaev
   Date        : 05.07.2008
   Purpose     : Exchange Rates will be returned
******************************************************************************/
FUNCTION GetExchangeRates (p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                              p_personid  IN VARCHAR2,
                             p_channelcd IN VARCHAR2,
                           p_trancd    IN VARCHAR2,
                           pd_tarih IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                           pc_ref4 OUT CursorReferenceType,
                           pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    IF p_option='RATE' THEN
          IF pd_TARIH IS NULL THEN
              OPEN pc_ref2 FOR
                SELECT CBS_KUR.DVZ,
                     CBS_KUR.DVZALIS,
                     CBS_KUR.DVZSATIS,
                     CBS_KUR.EFALIS,
                     CBS_KUR.EFSATIS,
                     DECODE(p_customerid,'RUS',CBS_DOVIZ_KODLARI.ACIKLAMA,CBS_DOVIZ_KODLARI.aciklama),
                     CBS_MBKUR.DVZALIS MBKUR
               FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_MBKUR
               WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
               AND CBS_KUR.dvz=CBS_MBKUR.dvz
               AND CBS_KUR.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KZT')
               AND ((CBS_KUR.DVZ<>Pkg_Genel.lc_al) AND (CBS_KUR.DVZ <> 'TRL'))
               ORDER BY SIRA_NO;
          ELSE
              OPEN pc_ref2 FOR
              SELECT CBS_KURLOG.DVZ,
                     CBS_KURLOG.DVZALIS,
                     CBS_KURLOG.DVZSATIS,
                     CBS_KURLOG.EFALIS,
                     CBS_KURLOG.EFSATIS,
                     DECODE(p_customerid,'RUS',CBS_DOVIZ_KODLARI.ACIKLAMA,CBS_DOVIZ_KODLARI.aciklama),
                     CBS_MBKURLOG.DVZALIS MBKUR
               FROM CBS_KURLOG,CBS_DOVIZ_KODLARI,CBS_MBKURLOG
               WHERE CBS_KURLOG.dvz=doviz_kodu
               AND CBS_KURLOG.dvz=CBS_MBKURLOG.dvz
                  AND CBS_KURLOG.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KZT')
                  AND CBS_KURLOG.tarih BETWEEN  TO_DATE (pd_TARIH || ' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH || '23:59', 'YYYYMMDD HH24:MI')
               AND CBS_MBKURLOG.tarih BETWEEN  TO_DATE (pd_TARIH || ' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH || '23:59', 'YYYYMMDD HH24:MI')
               AND CBS_KURLOG.gecerli_kur='E'
               AND (CBS_KURLOG.DVZ<>Pkg_Genel.lc_al AND (CBS_KURLOG.DVZ <> 'TRL'))
               ORDER BY SIRA_NO;
            END IF;

    ELSE
          IF pd_TARIH IS NULL THEN
                  OPEN pc_ref FOR
                      SELECT CBS_KUR.DVZ,
                         CBS_KUR.DVZALIS,
                         CBS_KUR.DVZSATIS,
                         CBS_KUR.EFALIS,
                         CBS_KUR.EFSATIS,
                         CBS_DOVIZ_KODLARI.ACIKLAMA
                   FROM CBS_KUR,CBS_DOVIZ_KODLARI
                   WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                   AND CBS_KUR.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KZT')
                   ORDER BY SIRA_NO;
          ELSE
                  OPEN pc_ref FOR
                   SELECT CBS_KUR.DVZ,
                         CBS_KUR.DVZALIS,
                         CBS_KUR.DVZSATIS,
                         CBS_KUR.EFALIS,
                         CBS_KUR.EFSATIS,
                         CBS_DOVIZ_KODLARI.ACIKLAMA
                   FROM CBS_KUR,CBS_DOVIZ_KODLARI,CBS_KURLOG
                   WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                   AND CBS_KUR.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KZT')
                   AND CBS_KURLOG.tarih BETWEEN  TO_DATE (pd_TARIH || ' 00:00', 'YYYYMMDD HH24:MI') AND TO_DATE (pd_TARIH || '23:59', 'YYYYMMDD HH24:MI')
                   AND CBS_KURLOG.gecerli_kur='E'
                   ORDER BY SIRA_NO;
            END IF;

    END IF;
    RETURN ls_returncode;
EXCEPTION WHEN OTHERS THEN
    ls_returncode:='999';
    Log_At('Pkg_Soa_Account.GetExchangeRates',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetAccounts
   Prepared By : Almas Nurhozhaev
   Date        : 30.06.08
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetAccounts(p_option IN VARCHAR2,
                      p_customerid IN VARCHAR2,
                      p_personid  IN VARCHAR2,
                      p_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;
BEGIN
  OPEN pc_ref FOR SELECT '-' FROM dual;
  OPEN pc_ref2 FOR SELECT '-' FROM dual;
  OPEN pc_ref3 FOR SELECT '-' FROM dual;
  OPEN pc_ref4 FOR SELECT '-' FROM dual;
  OPEN pc_ref5 FOR SELECT '-' FROM dual;

            IF p_option =  'ALL' THEN
                 SELECT COUNT(*)
                 INTO ls_account_count
                 FROM CBS_vw_hesap_izleme a
                 WHERE musteri_no = TO_NUMBER(p_customerid)
                 AND a.DURUM_KODU='A'
                 AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid));

                 IF (ls_account_count= 0) THEN
                 RAISE noAccoutFound;
                 END IF;

            -----------------------------Current Account----------------------------
                 OPEN pc_ref FOR
                    SELECT  Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                            MUSTERI_NO,
                            ISIM_UNVAN,
                            sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                            HESAP_NO,
                            DOVIZ_KODU,
                            NVL(BAKIYE,0),
                            NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                            1 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2),
                            EXTERNAL_HESAP_NO,
                            URUN_SINIF_KOD,
			    TO_CHAR(acilis_tarihi,'YYYYMMDD') ACILIS_TARIHI --added FilippK 14.09.2022
                    FROM CBS_vw_hesap_izleme a
                    WHERE musteri_no = TO_NUMBER(p_customerid) AND
                    durum_kodu = 'A' AND
                    modul_tur_kod= 'CURRENT' AND
                    urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
                    HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu ;

            ---------------------------Time Deposite------------------------------
                   OPEN pc_ref2 FOR
                      SELECT Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                             MUSTERI_NO,
                             ISIM_UNVAN,
                             sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                             HESAP_NO,
                             DOVIZ_KODU,
                             NVL(BAKIYE,0),
                             NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                             2 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2), birikmis_faiz_poz+gecen_yil_faiz_toplami toplam,
                             EXTERNAL_HESAP_NO,
                             URUN_SINIF_KOD
                      FROM CBS_vw_hesap_izleme a
                      WHERE musteri_no = TO_NUMBER(p_customerid) AND
                      durum_kodu = 'A' AND
                      modul_tur_kod= 'TIME DEP.' AND
                      HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                      ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu ;

            ----------------------------Related Accounts---------------------------
                OPEN pc_ref3 FOR
                     SELECT 'Related Current Accounts' modul_tur_kod,
                             hizl.MUSTERI_NO,
                             hizl.ISIM_UNVAN,
                             hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
                             hizl.HESAP_NO,
                             hizl.DOVIZ_KODU,
                             NVL(hizl.BAKIYE,0),
                             NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
                             1 siralama, TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.KISA_ISIM, ROUND(hizl.BIRIKMIS_FAIZ_NEG,2),
                             hizl.URUN_SINIF_KOD
                    FROM CBS_JOIN_ACCOUNT jacc
                    JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
                    WHERE jacc.CUST_NO=TO_NUMBER(p_customerid)
                    AND jacc.STATUS_CD='sACTIV'
                    AND jacc.TRAN_TYPE IN ('sVIEW','sTRAN')
                    AND hizl.durum_kodu = 'A'
                    AND hizl.modul_tur_kod= 'CURRENT'
                    AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
                    and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama, HESAP_NO, SUBE, doviz_kodu;

               OPEN pc_ref4 FOR
                      SELECT Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
                             hizl.MUSTERI_NO,
                             hizl.ISIM_UNVAN,
                             hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
                             hizl.HESAP_NO,
                             hizl.DOVIZ_KODU,
                             NVL(hizl.BAKIYE,0),
                             NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
                             2 siralama, TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.KISA_ISIM, ROUND(hizl.BIRIKMIS_FAIZ_NEG,2),
                             hizl.URUN_SINIF_KOD
                    FROM CBS_JOIN_ACCOUNT jacc
                    JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
                    WHERE jacc.CUST_NO=TO_NUMBER(p_customerid)
                    AND jacc.STATUS_CD='sACTIV'
                    AND jacc.TRAN_TYPE IN ('sVIEW','sTRAN')
                    AND hizl.durum_kodu = 'A'
                    AND hizl.modul_tur_kod= 'TIME DEP.'
                    and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama, HESAP_NO, SUBE, doviz_kodu;
            END IF; ------------ IF p_option =  'ALL' THEN

  RETURN ls_returncode;
EXCEPTION
    WHEN noAccoutFound THEN
          ls_returncode:= '503';

    RETURN ls_returncode;

    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.GetAccounts',SQLERRM);
        ls_returncode:= '999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;

/******************************************************************************
   NAME          : FUNCTION StatementDetail
   Prepared By   : Almas Nurhozhaev
   Date          : 22.02.2008
   Purpose       : Get last financial ten transactions
******************************************************************************/
FUNCTION GetLastTenTran(pn_CustomerNo   IN VARCHAR2,
                        pn_langCD   IN VARCHAR2,
                        pc_ref          OUT CursorReferenceType,
                        pc_ref2      OUT CursorReferenceType,
                        pc_ref3      OUT CursorReferenceType,
                        pc_ref4      OUT CursorReferenceType,
                        pc_ref5      OUT CursorReferenceType)  RETURN VARCHAR2 IS

ls_returncode  VARCHAR2(3):= '000';
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
        SELECT  ROWNUM, NUMARA, ISLEM_KOD, DESCRIPTION, KAYIT_TARIH, TUTAR, DOVIZ_KOD
        FROM(
        SELECT  NUMARA, ISLEM_KOD, (SELECT ACIKLAMA FROM CBS_ISLEM_TANIM WHERE KOD=ISLEM_KOD) DESCRIPTION, KAYIT_TARIH, TUTAR, DOVIZ_KOD
        FROM cbs.CBS_ISLEM
        WHERE DURUM='P'
        AND FIS_NUMARA IS NOT NULL
        AND MUSTERI_NUMARA=TO_NUMBER(pn_CustomerNo)
        ORDER BY NUMARA DESC) a
        WHERE ROWNUM<=10
        ORDER BY NUMARA ASC;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
          ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
       RAISE_APPLICATION_ERROR(-20100,SQLERRM);
       OPEN pc_ref FOR SELECT '-' FROM dual;
       OPEN pc_ref2 FOR SELECT '-' FROM dual;
       OPEN pc_ref3 FOR SELECT '-' FROM dual;
       OPEN pc_ref4 FOR SELECT '-' FROM dual;
       OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME          : FUNCTION GetTranHistoryUNDP
   Prepared By   : Nurhat UCA
   Date          : 12.10.2012
   Purpose       : Get latest transactions with details by  date filter
******************************************************************************/
FUNCTION GetTranHistoryUNDP (
   ps_accountNo         IN     VARCHAR2,
   pd_startDate         IN     VARCHAR2,
   pd_endDate           IN     VARCHAR2,
   pc_ref          OUT CursorReferenceType
)
   RETURN VARCHAR2
IS
   ls_returncode   VARCHAR2 (3) := '000';
   ls_line   VARCHAR2(4000);
   ls_ouput CLOB;
   CURSOR transactionsCursor IS
        SELECT    K.NUMARA,
                  K.ISLEM_KOD,
                  Pkg_Musteri.SF_MUSTERI_ADI (MUSTERI_NO) MUSTERI_ADI,
                  FIS_MUHASEBELESTIGI_TARIH
          FROM   cbs_vw_fis_satir_vsziz A, CBS_ISLEM K
         WHERE   K.ISLEM_KOD IN (4003,3555,1203) AND SATIR_HESAP_NUMARA = ps_accountNo
                 AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (
                                                          pd_startDate,
                                                          'YYYYMMDD'
                                                       )
                                                   AND  TO_DATE (
                                                           pd_endDate,
                                                           'YYYYMMDD'
                                                        )
                 AND FIS_TUR = 'G'
                 AND K.NUMARA = A.FIS_ISLEM_NUMARA;

  row_transaction transactionsCursor%ROWTYPE;
BEGIN
   ls_ouput:='';

   OPEN transactionsCursor;
    FETCH transactionsCursor INTO row_transaction;
    WHILE  transactionsCursor%FOUND
    LOOP
         IF row_transaction.ISLEM_KOD =4003
         THEN
             SELECT     'S+'
                         || LPAD (
                               TRIM (TO_CHAR (NET_TRANSFER_TUTARI, '999999999999999999.99')),
                               18,
                               '0'
                            )
                         || OC_HESAP_NO_K
                         || DECODE (TRANSFER_DOVIZ_KODU,
                                    'USD',
                                    '01',
                                    'CHF',
                                    '07',
                                    'KZT',
                                    '51',
                                    'EUR',
                                    '53',
                                    'RUB',
                                    '59',
                                    TRANSFER_DOVIZ_KODU,
                                    '75')
                         || RPAD (OC_ISIM_ADRES_1, 35)
                         || RPAD (OC_ISIM_ADRES_1, 35)
                         || RPAD (SUBSTR (II_BIC, 1, 8), 15)
                         || RPAD ( (SELECT   BANKA_ADI
                                      FROM   CBS_BIC_KODLARI
                                     WHERE   BIC_KODU = C.II_BIC), 60)
                         || RPAD (SUBSTR (AWI_BIC, 1, 8), 15)
                         || RPAD ( (SELECT   BANKA_ADI
                                      FROM   CBS_BIC_KODLARI
                                     WHERE   BIC_KODU = C.AWI_BIC), 60)
                         || RPAD (' ', 60)
                         || RPAD (BC_ISIM_ADRES_1, 60)
                         || RPAD (BC_HESAP_NO_N, 30)
                         || RPAD (BC_ISIM_ADRES_2 || ' ' || BC_ISIM_ADRES_3, 100)
                         || RPAD (NVL (RI_1, ' ') || NVL (RI_2, ' ') || NVL (RI_3, ' ') || NVL (RI_4, ' '), 150)
                         || DECODE (NET_BRUT,
                                    'N',
                                    'O',
                                    NET_BRUT,
                                    'B')
                         || 'S'
                            INTO ls_line
                  FROM   CBS.CBS_YPHAVALE_GIDEN_ACILIS C
                 WHERE   C.TX_NO = row_transaction.NUMARA;
         ELSIF row_transaction.ISLEM_KOD =3555
         THEN
                   SELECT   'E+'
                             || LPAD (TRIM (TO_CHAR (C.AMOUNT, '999999999999999999.99')),
                                      18,
                                      '0')
                             || C.FROM_ACCOUNT_EXTERNAL_NUMBER
                             || '75'
                             || C.TO_ACCOUNT_EXTERNAL_NUMBER
                             || RPAD (C.FROM_DESCRIPTION, 35)
                             || RPAD (C.TO_NAME, 35)
                             || RPAD (NVL (SUBSTR (C.EXPLANATION, 1, 20), ' '), 20)
                             || RPAD (NVL (SUBSTR (C.EXPLANATION, 21, 40), ' '), 20)
                             || RPAD (NVL (SUBSTR (C.EXPLANATION, 41, 60), ' '), 20)
                             || RPAD (NVL (SUBSTR (C.EXPLANATION, 61, 80), ' '), 20)
                             || RPAD (NVL (SUBSTR (C.EXPLANATION, 81, 100), ' '), 20)
                             || RPAD (C.TO_BANK_BIC, 9)
                             || RPAD (C.CODE_OF_PAYMENT, 8,'0')
                             INTO ls_line
                      FROM   CBS.CBS_CLEARING_ISLEM C
                     WHERE   C.TX_NO = row_transaction.NUMARA;
         ELSIF row_transaction.ISLEM_KOD =1203
         THEN
                     SELECT      'B+'
                                 || LPAD (TRIM (TO_CHAR (C.TUTAR, '999999999999999999.99')), 18, '0')
                                 || C.BORC_EXTERNAL_HESAP
                                 || DECODE (DOVIZ_KODU,
                                            'USD',
                                            '01',
                                            'CHF',
                                            '07',
                                            'KZT',
                                            '51',
                                            'EUR',
                                            '53',
                                            'RUB',
                                            '59',
                                            DOVIZ_KODU,
                                            '75')
                                 || C.ALACAK_EXTERNAL_HESAP
                                 || RPAD (
                                       Pkg_Musteri.Sf_Musteri_Adi (
                                          Pkg_Hesap.HesaptanMusteriNoAl (ALACAK_HESAP_NO)
                                       ),
                                       35
                                    )
                                 || RPAD (
                                       Pkg_Musteri.Sf_Musteri_Adi (
                                          Pkg_Hesap.HesaptanMusteriNoAl (BORC_HESAP_NO)
                                       ),
                                       35
                                    )
                                 || RPAD (NVL (SUBSTR (C.ACIKLAMA, 1, 20), ' '), 20)
                                 || RPAD (NVL (SUBSTR (C.ACIKLAMA, 21, 40), ' '), 20)
                                 || RPAD (NVL (SUBSTR (C.ACIKLAMA, 41, 60), ' '), 20)
                                 || RPAD (NVL (SUBSTR (C.ACIKLAMA, 61, 80), ' '), 20)
                                 || RPAD (NVL (SUBSTR (C.ACIKLAMA, 81, 100), ' '), 20)
                                 || RPAD (' ', 9)
                                 || RPAD (NVL (C.ISTATISTIK_KODU, '0'), 8, '0')
                                 INTO ls_line
                  FROM   CBS.CBS_VIRMAN_ISLEM C
                  WHERE   C.TX_NO = row_transaction.NUMARA;
         END IF;
         ls_ouput :=ls_ouput || ls_line||CHR(13)||CHR(10);

    FETCH transactionsCursor INTO row_transaction;
    END LOOP;
    CLOSE transactionsCursor;
    OPEN pc_ref FOR SELECT   ls_ouput FROM DUAL;
   RETURN ls_returncode;
EXCEPTION
   WHEN OTHERS
   THEN
      OPEN pc_ref FOR SELECT   '' FROM DUAL;
      ls_returncode := Pkg_Int_Api.GetErrorCode (SQLERRM);
      log_at ('GetTranHistoryUNDP',ls_returncode, SQLERRM);
      RAISE_APPLICATION_ERROR (-20100, SQLERRM);
      RETURN ls_returncode;
END;
/******************************************************************************
   NAME          : FUNCTION GetLoanInstallment
   Prepared By   : Almas Nurhozhaev
   Date          : 22.02.2008
   Purpose       : Get Loan Installment
******************************************************************************/
FUNCTION GetLoanInstallment(pn_CustomerNo IN VARCHAR2,
                            pc_ref          OUT CursorReferenceType,
                            pc_ref2      OUT CursorReferenceType,
                            pc_ref3      OUT CursorReferenceType,
                            pc_ref4      OUT CursorReferenceType,
                            pc_ref5      OUT CursorReferenceType)  RETURN VARCHAR2 IS
ls_returncode  VARCHAR2(3):= '000';
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
        SELECT a.HESAP_NO, a.TAKSIT, a.VADE_TARIH, Pkg_Hesap.hesaptandovizkodual(a.hesap_no)  FROM CBS_HESAP_KREDI_TAKSIT a
        WHERE a.hesap_no IN (SELECT hesap_no FROM CBS_HESAP_KREDI WHERE musteri_no=pn_CustomerNo)
        AND a.durum_kodu='A'
        AND a.VADE_TARIH IN (SELECT MIN(c.VADE_TARIH) FROM CBS_HESAP_KREDI_TAKSIT c WHERE c.durum_kodu='A' AND c.hesap_no=a.hesap_no);

RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
          ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
       RAISE_APPLICATION_ERROR(-20100,SQLERRM);
       OPEN pc_ref FOR SELECT '-' FROM dual;
       OPEN pc_ref2 FOR SELECT '-' FROM dual;
       OPEN pc_ref3 FOR SELECT '-' FROM dual;
       OPEN pc_ref4 FOR SELECT '-' FROM dual;
       OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME          : FUNCTION GetUserWarnings
   Prepared By   : Almas Nurhozhaev
   Date          : 26.02.2008
   Purpose       : Get User Warnings
******************************************************************************/
FUNCTION GetUserWarnings (pn_warningType   IN     VARCHAR2,
                        ps_channel_cd   IN   VARCHAR2,--ernestk 14022014 cqdb00000504 news differ by channel
                        pn_langCD        IN     VARCHAR2,
                        pc_ref              OUT CursorReferenceType,
                        pc_ref2             OUT CursorReferenceType,
                        pc_ref3             OUT CursorReferenceType,
                        pc_ref4             OUT CursorReferenceType,
                        pc_ref5             OUT CursorReferenceType)
  RETURN VARCHAR2
IS
  ls_returncode   VARCHAR2 (3) := '000';
BEGIN
  OPEN pc_ref FOR SELECT   '-' FROM DUAL;

  OPEN pc_ref2 FOR SELECT   '-' FROM DUAL;

  OPEN pc_ref3 FOR SELECT   '-' FROM DUAL;

  OPEN pc_ref4 FOR SELECT   '-' FROM DUAL;

  OPEN pc_ref5 FOR SELECT   '-' FROM DUAL;

  OPEN pc_ref FOR
     SELECT   a.MESSAGE, a.TIP_URL
       FROM   CORPINT.TBL_USER_WARNINGS a
      WHERE       a.STATUS = 'sENAB'
              AND a.WARNING_TYPE = pn_warningType
              AND a.LANG_CD = pn_langCD
              AND A.CHANNEL_CD = ps_channel_cd;--ernestk 14022014 cqdb00000504 get by channel code

  RETURN ls_returncode;
EXCEPTION
  WHEN OTHERS
  THEN
     ls_returncode := Pkg_Int_Api.GetErrorCode (SQLERRM);
     RAISE_APPLICATION_ERROR (-20100, SQLERRM);
     Log_At ('Pkg_Soa_inquiry.GetUserWarnings', SQLERRM);

     OPEN pc_ref FOR SELECT   '-' FROM DUAL;

     OPEN pc_ref2 FOR SELECT   '-' FROM DUAL;

     OPEN pc_ref3 FOR SELECT   '-' FROM DUAL;

     OPEN pc_ref4 FOR SELECT   '-' FROM DUAL;

     OPEN pc_ref5 FOR SELECT   '-' FROM DUAL;

     RETURN ls_returncode;
END;

/******************************************************************************
   NAME          : FUNCTION GetTimeDepositRatesAll
   Prepared By   : Almas Nurhozhaev
   Date          : 30.06.2008
   Purpose       : Get All Time Deposit Rates
******************************************************************************/
FUNCTION GetTimeDepositRatesAll(pn_CustomerId  IN VARCHAR2,
                                pn_PersonId    IN VARCHAR2,
                                ps_ChannelCd   IN VARCHAR2,
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType,
                                pc_ref4 OUT CursorReferenceType,
                                pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    accountException  EXCEPTION;
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

     --Get Time Deposit Rate Info
      OPEN pc_ref   FOR
            SELECT VADE_1, VADE_2, TRL
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE TARIH=(SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO)
            AND musteri_tipi=1
            ORDER BY vade_1,vade_2;

      OPEN pc_ref2   FOR
            SELECT VADE_1, VADE_2, USD
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE TARIH=(SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO)
            AND musteri_tipi=1
            ORDER BY vade_1,vade_2;

      OPEN pc_ref3   FOR
            SELECT VADE_1, VADE_2, EUR
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE TARIH=(SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO)
            AND musteri_tipi=1
            ORDER BY vade_1,vade_2;

     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT TO_CHAR(Pkg_Muhasebe.BANKA_TARIHI_BUL,'YYYYMMDD') FROM dual;

  RETURN ls_returncode;
EXCEPTION
    WHEN accountException THEN
      ls_returncode:= '999';
     log_at('GetTimeDepositRatesAll',SQLERRM);
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME       : GetIntStatementHeader
   Prepared By: Almas Nurhozhaev
   Date          : 09.11.07
   Purpose      :
******************************************************************************/
FUNCTION GetIntStatementHeader(p_option IN VARCHAR2,
                                p_customerid IN VARCHAR2,
                                  p_personid  IN VARCHAR2,
                                 p_channelcd IN VARCHAR2,
                                p_account_no IN VARCHAR2,
                                pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                               pc_ref OUT CursorReferenceType,
                               pc_ref2 OUT CursorReferenceType,
                               pc_ref3 OUT CursorReferenceType,
                               pc_ref4 OUT CursorReferenceType,
                               pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2  IS

    ls_returncode VARCHAR2(3):='000';

BEGIN


        OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

                OPEN pc_ref FOR
                     SELECT
                        TO_CHAR(b.hesap_no) hesap_no,
                        EXTERNAL_HESAP_NO,
                        b.musteri_no musteri_no,
                        Pkg_Musteri.sf_musteri_adi(musteri_no) isim_unvan ,
                        Pkg_Musteri.sf_adres_al(b.musteri_no) adres,
                        b.urun_tur_kod || ' \ ' ||urun_sinif_kod hesap_turu,
                        DOVIZ_KODU hesap_doviz_kodu,
                        b.modul_tur_kod,
                        b.urun_tur_kod,
                        b.urun_sinif_kod,
                        b.durum_kodu,
                        b.sube_kodu,
                        SUBSTR(Pkg_Genel.bolum_adi_al(b.sube_kodu),1,50)  bolum_adi,
                        Pkg_Musteri.Sf_VergiNo_Al(b.musteri_no) rnn
                    FROM cbs_vw_hesap_izleme b
                    WHERE b.hesap_no=p_account_no;

   RETURN ls_returncode;

EXCEPTION WHEN OTHERS THEN
    ls_returncode:='999';
    Log_At('Pkg_Soa_Account.GetIntStatementHeader',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    RETURN ls_returncode;
END;

/******************************************************************************
         NAME       : GetAccountHistory
      Prepared By: Almas Nurhozhaev
      Date          : 09.11.07
      Purpose      :Customer Account History will be returned
******************************************************************************/
FUNCTION  GetAccountHistoryPaged(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                            p_channelcd IN VARCHAR2,
                            p_account_no IN VARCHAR2,
                            pd_start_date IN VARCHAR2,
                            pd_end_date      IN VARCHAR2,
                            pd_islem_tur        IN VARCHAR2 DEFAULT '%',
                            pd_hareket        IN VARCHAR2 DEFAULT '%',
                            pd_alt_sinir     IN VARCHAR2,
                            pd_ust_sinir     IN VARCHAR2,
                            pd_lang     IN VARCHAR2,
                            pn_pageSize     IN NUMBER,
                            pn_pageNumber     IN NUMBER,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType ) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ld_startdate  DATE;
  ld_enddate    DATE;

  not_valid_date EXCEPTION;
  PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- if wrong data entered
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
    ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');

    IF (p_channelcd = 'cDKBCIB' and p_option = 'OPTION2') THEN
       OPEN pc_ref2 FOR
        SELECT COUNT(*) CNT  FROM (
        SELECT 1
          FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD NOT IN (1203, 3555, 3556)
        UNION ALL
        SELECT 1
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_VIRMAN_ISLEM V
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND K.NUMARA = V.TX_NO
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 1203
        UNION ALL
        SELECT 1
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3555
        UNION ALL
        SELECT  1
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3556 ) T;
        OPEN pc_ref FOR
        SELECT * FROM(
        SELECT T.*,  ROWNUM AS ROW_NO
         FROM (
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH,--CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (I.KOD, 4003, 'SWIFT Outgoing', I.ACIKLAMA) ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (MUSTERI_NO) MUSTERI_VERGINO,
               MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               DECODE (I.KOD,
                       4003, (SELECT bc_isim_adres
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  Gonderen_Adi,
               DECODE (I.KOD,
                       4003, (SELECT bc_isim_adres
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               '000' REF_NO,
               PKG_MUSTERI.SF_OKPO_AL (MUSTERI_NO) OKPO,
               PKG_MUSTERI.SF_VERGINO_AL (MUSTERI_NO) RNN,
               DECODE (I.KOD,
                       4003, (SELECT TO_CHAR (BC_HESAP_NO)
                                FROM cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  TO_ACCOUNT_NO,
               DECODE (I.KOD,
                       4003, (SELECT NVL (alici_bic, muhabir_bic)
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  TO_BANK_BIC,
               DECODE (I.KOD,
                       4003, (SELECT banka_adi
                                FROM CBS_BIC_KODLARI
                               WHERE bic_kodu = (SELECT NVL (alici_bic, muhabir_bic)
                                                   FROM cbs.cbs_yphavale_giden_acilis
                                                  WHERE tx_no = K.NUMARA)),
                       ' ')
                  to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD NOT IN (1203, 3555, 3556)
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (K.URUN_SINIF_KOD,
                       'INTERNET OWN LC', 'Transfer between Accounts',
                       'INTERNET OTHER LC', 'Transfer to Other Accounts',
                       I.ACIKLAMA)
                  ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (MUSTERI_NO) MUSTERI_VERGINO,
               MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               Pkg_Musteri.SF_MUSTERI_ADI (
                  Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no))
                  Gonderen_Adi,
               Pkg_Musteri.SF_MUSTERI_ADI (
                  Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no))
                  Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               '000' REF_NO,
               PKG_MUSTERI.SF_OKPO_AL (
                  DECODE (
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no),
                     MUSTERI_NO, Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no),
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no)))
                  OKPO,
               PKG_MUSTERI.SF_VERGINO_AL (
                  DECODE (
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no),
                     MUSTERI_NO, Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no),
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no)))
                  RNN,
               TO_CHAR (V.alacak_hesap_no) TO_ACCOUNT_NO,
               '' TO_BANK_BIC,
               '' to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_VIRMAN_ISLEM V
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND K.NUMARA = V.TX_NO
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 1203
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS')FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (
                  k.URUN_SINIF_KOD,
                  'CIBGROSS', (SELECT ff.aciklama
                                 FROM cbs_urun_sinif ff
                                WHERE     ff.modul_tur_kod = k.MODUL_TUR_KOD
                                      AND ff.urun_tur_kod = k.URUN_TUR_KOD
                                      AND kod = k.URUN_SINIF_KOD),
                  I.ACIKLAMA)
                  ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (A.MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (A.MUSTERI_NO) MUSTERI_VERGINO,
               A.MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (A.MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               pkg_musteri.Sf_Musteri_Adi (
                  pkg_hesap.HesaptanMusteriNoAl (SATIR_HESAP_NUMARA))
                  Gonderen_Adi,
               ci.TO_NAME Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               NVL (ci.REF_NO, '000') REF_NO,
               ci.from_OKPO OKPO,
               ci.from_RNN RNN,
               ci.to_account_external_number TO_ACCOUNT_NO,
               ci.to_bank_bic TO_BANK_BIC,
               (SELECT banka_adi
                  FROM CBS_BANKA_KODLARI
                 WHERE banka_kodu = ci.TO_BANK_BIC)
                  to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3555
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS')FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               ci.EXPLANATION SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               I.ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (A.MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (A.MUSTERI_NO) MUSTERI_VERGINO,
               A.MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (A.MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               ci.FROM_DESCRIPTION Gonderen_Adi,
               ci.TO_NAME Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               NVL (ci.REF_NO, '000') REF_NO,
               ci.from_OKPO OKPO,
               ci.from_RNN RNN,
               ci.from_account_external_number TO_ACCOUNT_NO,
               '' TO_BANK_BIC,
               '' to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3556
        ORDER BY 1, 24, 25) T  where rownum < ((pn_pageNumber * pn_pageSize) + 1 )
        )WHERE ROW_NO >= (((pn_pageNumber-1) * pn_pageSize) + 1) ORDER BY ROW_NO;


    ELSIF (p_channelcd = 'cDKBCIB') THEN
        OPEN pc_ref2 for
        SELECT COUNT(*) FROM(
            SELECT 1
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
                   FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
                   AND FIS_TUR = 'G'
                   AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
                   AND K.NUMARA=A.FIS_ISLEM_NUMARA
                   AND I.KOD=K.ISLEM_KOD
                   AND K.ISLEM_KOD NOT IN (1203,3555,3556)
            UNION ALL
            --aisuluukas 23092015 cqdb1372 add case when islem_kod=1203
            SELECT  1
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_VIRMAN_ISLEM V
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
                   FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
                   AND FIS_TUR = 'G'
                   AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
                   AND K.NUMARA=A.FIS_ISLEM_NUMARA
                   AND K.NUMARA=V.TX_NO
                   AND I.KOD=K.ISLEM_KOD
                   AND K.ISLEM_KOD = 1203
            UNION ALL
            SELECT  1
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD = 3555
            UNION ALL
            SELECT 1
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD = 3556
           )T ;
      OPEN pc_ref FOR
        SELECT *  fROM(
            SELECT T.*, ROWNUM AS ROW_NO FROM (
            SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH,--CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                    TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                    A.SATIR_MUSTERI_ACIKLAMA,
                    A.SATIR_DV_TUTAR,
                    NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                    SATIR_DOVIZ_KOD,
                    decode(I.KOD,
                           4003, 'SWIFT Outgoing',
                            I.ACIKLAMA) ACIKLAMA, --chyngyzo cq509 08/10/2015
                    I.ACIKLAMA ACIKLAMA_2,
                    K.NUMARA,
                    K.ISLEM_KOD,
                    PD_LANG,
                    Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                    Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO) MUSTERI_ADRES,
                    Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO) MUSTERI_VERGINO,
                    MUSTERI_NO,
                    SATIR_MUSTERI_HESAP_NUMARA,
                    Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                    DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                    Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO) MUSTERI_ADI,
                    Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                    TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                    decode(I.KOD,
                           4003, (select bc_isim_adres_1 from cbs_yphavale_giden_acilis where tx_no =K.NUMARA),
                           6330, (Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO)),
                           5151, PKG_GENEL.BOLUM_ADI_AL(SATIR_HESAP_BOLUM_KODU), --AntonPa CBS-753 21092022
                            NULL) Gonderen_Adi, --chyngyzo cq509 08/10/2015
                    decode(I.KOD,
                           6330, (select KURUM_KODU || ' ' || TELEFON_ALAN_KOD || ' ' || TELEFON_NO || ' ' || TESISAT_NO  || ' ' ||  KURUM_OZEL_NO from cbs_tahsilat where TAHSILAT_FIS_NO =K.FIS_NUMARA),
                    NULL) Alici_Adi,
                    A.FIS_NUMARA,
                    A.SATIR_NUMARA
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
                   FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
                   AND FIS_TUR = 'G'
                   AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
                   AND K.NUMARA=A.FIS_ISLEM_NUMARA
                   AND I.KOD=K.ISLEM_KOD
                   AND K.ISLEM_KOD NOT IN (1203,3555,3556)
            UNION ALL
            --aisuluukas 23092015 cqdb1372 add case when islem_kod=1203
            SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, ---CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                    TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                    A.SATIR_MUSTERI_ACIKLAMA,
                    A.SATIR_DV_TUTAR,
                    NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                    SATIR_DOVIZ_KOD,
                    decode(K.URUN_SINIF_KOD,
                           'INTERNET OWN LC', 'Transfer between Accounts',
                           'INTERNET OTHER LC', 'Transfer to Other Accounts',
                           I.ACIKLAMA) ACIKLAMA,--aisuluukas 23092015 cqdb1372 decode description
                    I.ACIKLAMA ACIKLAMA_2,
                    K.NUMARA,
                    K.ISLEM_KOD,
                    PD_LANG,
                    Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                    Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO) MUSTERI_ADRES,
                    Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO) MUSTERI_VERGINO,
                    MUSTERI_NO,
                    SATIR_MUSTERI_HESAP_NUMARA,
                    Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                    DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                    Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO) MUSTERI_ADI,
                    Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                    TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                    Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.borc_hesap_no)) Gonderen_Adi,--aisuluukas 23092015 cqdb1372 sender name
                    Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.alacak_hesap_no)) Alici_Adi,--aisuluukas 23092015 cqdb1372 receiver name
                    A.FIS_NUMARA,
                    A.SATIR_NUMARA
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_VIRMAN_ISLEM V
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
                   FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
                   AND FIS_TUR = 'G'
                   AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
                   AND K.NUMARA=A.FIS_ISLEM_NUMARA
                   AND K.NUMARA=V.TX_NO
                   AND I.KOD=K.ISLEM_KOD
                   AND K.ISLEM_KOD = 1203
            UNION ALL
            SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                    TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                    A.SATIR_MUSTERI_ACIKLAMA,
                    A.SATIR_DV_TUTAR,
                    NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                    SATIR_DOVIZ_KOD,
                    decode(k.URUN_SINIF_KOD,
                           'CIBGROSS', (select ff.aciklama from cbs_urun_sinif ff where ff.modul_tur_kod=k.MODUL_TUR_KOD and ff.urun_tur_kod=k.URUN_TUR_KOD and kod=k.URUN_SINIF_KOD),
                           I.ACIKLAMA) ACIKLAMA,
                    I.ACIKLAMA ACIKLAMA_2,
                    K.NUMARA,
                    K.ISLEM_KOD,
                    PD_LANG,
                    Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                    Pkg_Musteri.SF_ADRES_AL(A.MUSTERI_NO) MUSTERI_ADRES,
                    Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
                    A.MUSTERI_NO,
                    SATIR_MUSTERI_HESAP_NUMARA,
                    Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                    DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                    Pkg_Musteri.SF_MUSTERI_ADI(A.MUSTERI_NO) MUSTERI_ADI,
                    Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                    TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                    pkg_musteri.Sf_Musteri_Adi(pkg_hesap.HesaptanMusteriNoAl(SATIR_HESAP_NUMARA)) Gonderen_Adi,
                    ci.TO_NAME Alici_Adi,
                    A.FIS_NUMARA,
                    A.SATIR_NUMARA
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD = 3555
            UNION ALL
            SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                    TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                    ci.EXPLANATION SATIR_MUSTERI_ACIKLAMA, --A.SATIR_MUSTERI_ACIKLAMA,
                    A.SATIR_DV_TUTAR,
                    NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                    SATIR_DOVIZ_KOD,
                    I.ACIKLAMA,
                    I.ACIKLAMA ACIKLAMA_2,
                    K.NUMARA,
                    K.ISLEM_KOD,
                    PD_LANG,
                    Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                    Pkg_Musteri.SF_ADRES_AL(A.MUSTERI_NO) MUSTERI_ADRES,
                    Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
                    A.MUSTERI_NO,
                    SATIR_MUSTERI_HESAP_NUMARA,
                    Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                    DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                    Pkg_Musteri.SF_MUSTERI_ADI(A.MUSTERI_NO) MUSTERI_ADI,
                    Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                    TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                    ci.FROM_DESCRIPTION Gonderen_Adi,
                    ci.TO_NAME Alici_Adi,
                    A.FIS_NUMARA,
                    A.SATIR_NUMARA
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD = 3556
            ORDER BY 1, 24, 25) T  where rownum < ((pn_pageNumber * pn_pageSize) + 1 )
        )WHERE ROW_NO >= (((pn_pageNumber-1) * pn_pageSize) + 1) ORDER BY ROW_NO;

    ELSE
    --IOS TemirlanT
    ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
    ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');
    if (pkg_tarih.gun_ozellik(ld_enddate)=1) then
        ld_enddate:=pkg_tarih.ileri_is_gunu(ld_enddate);
    end if;
    --IOS TemirlanT
     OPEN pc_ref2 FOR
        SELECT  COUNT(*) CNT
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
               FIS_MUHASEBELESTIGI_TARIH BETWEEN ld_startdate AND ld_enddate --IOS TemirlanT HH24MISS
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD ;
      OPEN pc_ref FOR
        SELECT * FROM(
        SELECT T.*,ROWNUM AS ROW_NO FROM (
            SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDDHH24MISS'), --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD'),--IOS TemirlanT HH24MISS
                    TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDDHH24MISS'),   --IOS TemirlanT HH24MISS
                    A.SATIR_MUSTERI_ACIKLAMA,
                    A.SATIR_DV_TUTAR,
                    NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                    SATIR_DOVIZ_KOD,
                    I.ACIKLAMA,
                    I.ACIKLAMA ACIKLAMA_1,
                    K.NUMARA,
                    K.ISLEM_KOD,
                    PD_LANG,
                    Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                    Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO),
                    Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO),
                    MUSTERI_NO,
                    SATIR_MUSTERI_HESAP_NUMARA,
                    Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA),
                    DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch'),
                    Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO),
                    Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA),
                    TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDDHH24MISS')
            FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
            WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
                   FIS_MUHASEBELESTIGI_TARIH BETWEEN ld_startdate AND ld_enddate --IOS TemirlanT HH24MISS
                   AND FIS_TUR = 'G'
                   AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
                   AND K.NUMARA=A.FIS_ISLEM_NUMARA
                   AND I.KOD=K.ISLEM_KOD
            ORDER BY A.FIS_YARATILDIGI_TARIH, A.FIS_NUMARA, A.SATIR_NUMARA) T  where rownum < ((pn_pageNumber * pn_pageSize) + 1 )
            )WHERE ROW_NO >= (((pn_pageNumber-1) * pn_pageSize) + 1) ORDER BY ROW_NO;

    END IF;

        ls_returncode := GetIntStatementHeader(p_option,p_customerid,p_personid,p_channelcd,p_account_no,pd_start_date,pd_end_date,pc_ref3,pc_ref4,pc_ref4,pc_ref4,pc_ref5);

  RETURN ls_returncode;
EXCEPTION
    WHEN not_valid_date THEN
        ls_returncode:='414';
    RETURN ls_returncode;
    WHEN OTHERS THEN
    ls_returncode:='999';
    Log_At('Pkg_Soa_Account.GetAccountHistoryPaged',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;

FUNCTION  GetAccountHistory(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                            p_channelcd IN VARCHAR2,
                            p_account_no IN VARCHAR2,
                            pd_start_date IN VARCHAR2,
                            pd_end_date      IN VARCHAR2,
                            pd_islem_tur        IN VARCHAR2 DEFAULT '%',
                            pd_hareket        IN VARCHAR2 DEFAULT '%',
                            pd_alt_sinir     IN VARCHAR2,
                            pd_ust_sinir     IN VARCHAR2,
                            pd_lang     IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ld_startdate  DATE;
  ld_enddate    DATE;

  not_valid_date EXCEPTION;
  PRAGMA EXCEPTION_INIT(not_valid_date,-01839); -- if wrong data entered
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
    ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');

    IF (p_channelcd = 'cDKBCIB' and p_option = 'OPTION2') THEN

        OPEN pc_ref FOR
        SELECT T.*,  ROWNUM AS ROW_NO
         FROM (
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH,--CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (I.KOD, 4003, 'SWIFT Outgoing', I.ACIKLAMA) ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (MUSTERI_NO) MUSTERI_VERGINO,
               MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               DECODE (I.KOD,
                       4003, (SELECT bc_isim_adres
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  Gonderen_Adi,
               DECODE (I.KOD,
                       4003, (SELECT bc_isim_adres
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               '000' REF_NO,
               PKG_MUSTERI.SF_OKPO_AL (MUSTERI_NO) OKPO,
               PKG_MUSTERI.SF_VERGINO_AL (MUSTERI_NO) RNN,
               DECODE (I.KOD,
                       4003, (SELECT TO_CHAR (BC_HESAP_NO)
                                FROM cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  TO_ACCOUNT_NO,
               DECODE (I.KOD,
                       4003, (SELECT NVL (alici_bic, muhabir_bic)
                                FROM cbs.cbs_yphavale_giden_acilis
                               WHERE tx_no = K.NUMARA),
                       ' ')
                  TO_BANK_BIC,
               DECODE (I.KOD,
                       4003, (SELECT banka_adi
                                FROM CBS_BIC_KODLARI
                               WHERE bic_kodu = (SELECT NVL (alici_bic, muhabir_bic)
                                                   FROM cbs.cbs_yphavale_giden_acilis
                                                  WHERE tx_no = K.NUMARA)),
                       ' ')
                  to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A, CBS_ISLEM K, CBS_ISLEM_TANIM I
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD NOT IN (1203, 3555, 3556)
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (K.URUN_SINIF_KOD,
                       'INTERNET OWN LC', 'Transfer between Accounts',
                       'INTERNET OTHER LC', 'Transfer to Other Accounts',
                       I.ACIKLAMA)
                  ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (MUSTERI_NO) MUSTERI_VERGINO,
               MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               Pkg_Musteri.SF_MUSTERI_ADI (
                  Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no))
                  Gonderen_Adi,
               Pkg_Musteri.SF_MUSTERI_ADI (
                  Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no))
                  Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               '000' REF_NO,
               PKG_MUSTERI.SF_OKPO_AL (
                  DECODE (
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no),
                     MUSTERI_NO, Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no),
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no)))
                  OKPO,
               PKG_MUSTERI.SF_VERGINO_AL (
                  DECODE (
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no),
                     MUSTERI_NO, Pkg_Hesap.HesaptanMusteriNoAl (V.alacak_hesap_no),
                     Pkg_Hesap.HesaptanMusteriNoAl (V.borc_hesap_no)))
                  RNN,
               TO_CHAR (V.alacak_hesap_no) TO_ACCOUNT_NO,
               '' TO_BANK_BIC,
               '' to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_VIRMAN_ISLEM V
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND K.NUMARA = V.TX_NO
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 1203
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS')FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               A.SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               DECODE (
                  k.URUN_SINIF_KOD,
                  'CIBGROSS', (SELECT ff.aciklama
                                 FROM cbs_urun_sinif ff
                                WHERE     ff.modul_tur_kod = k.MODUL_TUR_KOD
                                      AND ff.urun_tur_kod = k.URUN_TUR_KOD
                                      AND kod = k.URUN_SINIF_KOD),
                  I.ACIKLAMA)
                  ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (A.MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (A.MUSTERI_NO) MUSTERI_VERGINO,
               A.MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (A.MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               pkg_musteri.Sf_Musteri_Adi (
                  pkg_hesap.HesaptanMusteriNoAl (SATIR_HESAP_NUMARA))
                  Gonderen_Adi,
               ci.TO_NAME Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               NVL (ci.REF_NO, '000') REF_NO,
               ci.from_OKPO OKPO,
               ci.from_RNN RNN,
               ci.to_account_external_number TO_ACCOUNT_NO,
               ci.to_bank_bic TO_BANK_BIC,
               (SELECT banka_adi
                  FROM CBS_BANKA_KODLARI
                 WHERE banka_kodu = ci.TO_BANK_BIC)
                  to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3555
        UNION ALL
        SELECT TO_CHAR (A.FIS_YARATILDIGI_TARIH, 'YYYYMMDDHH24MISS') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR (A.FIS_MUHASEBELESTIGI_TARIH, 'YYYYMMDDHH24MISS')FIS_MUHASEBELESTIGI_TARIH,
               TO_CHAR (A.SATIR_VALOR_TARIHI, 'YYYYMMDDHH24MISS') SATIR_VALOR_TARIHI,
               ci.EXPLANATION SATIR_MUSTERI_ACIKLAMA,
               A.SATIR_DV_TUTAR,
               NVL (
                  pkg_passbook.HareketliBakiyeHesapla (A.SATIR_HESAP_NUMARA,
                                                       A.FIS_NUMARA,
                                                       A.SATIR_NUMARA),
                  0)
                  SON_BAKIYE,
               SATIR_DOVIZ_KOD,
               I.ACIKLAMA,
               I.ACIKLAMA ACIKLAMA_2,
               K.NUMARA,
               K.ISLEM_KOD,
               PD_LANG,
               Pkg_Report5.GETNBEQUIVALENT (SATIR_DOVIZ_KOD,
                                            FIS_MUHASEBELESTIGI_TARIH,
                                            SATIR_DV_TUTAR)
                  NBEQUIVALENT,
               Pkg_Musteri.SF_ADRES_AL (A.MUSTERI_NO) MUSTERI_ADRES,
               Pkg_Musteri.SF_VERGINO_AL (A.MUSTERI_NO) MUSTERI_VERGINO,
               A.MUSTERI_NO,
               SATIR_MUSTERI_HESAP_NUMARA,
               Pkg_Hesap.EXTERNAL_HESAPNO_AL (SATIR_MUSTERI_HESAP_NUMARA)
                  EXTERNAL_HESAPNO,
               DECODE (SATIR_HESAP_BOLUM_KODU,
                       '010', '010   Main Branch',
                       '020', '020   Osh Branch',
                       '030', '030   Center Branch',
                       '040', '040   Manas Branch')
                  SATIR_HESAP_BOLUM_KODU,
               Pkg_Musteri.SF_MUSTERI_ADI (A.MUSTERI_NO) MUSTERI_ADI,
               Pkg_Hesap.HESAPBAKIYEAL (SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
               TO_CHAR (K.KAYIT_SISTEM_TARIHI, 'YYYYMMDDHH24MISS')
                  KAYIT_SISTEM_TARIHI,
               ci.FROM_DESCRIPTION Gonderen_Adi,
               ci.TO_NAME Alici_Adi,
               A.FIS_NUMARA,
               A.SATIR_NUMARA,
               NVL (ci.REF_NO, '000') REF_NO,
               ci.from_OKPO OKPO,
               ci.from_RNN RNN,
               ci.from_account_external_number TO_ACCOUNT_NO,
               '' TO_BANK_BIC,
               '' to_bank_name,
               NVL ( (SELECT invoice_no
                        FROM corpint.tbl_invoice
                       WHERE tx_ref_id = k.NUMARA AND ROWNUM = 1),
                    '')
                  invoice_no
          FROM cbs_vw_fis_satir_vsziz A,
               CBS_ISLEM K,
               CBS_ISLEM_TANIM I,
               CBS_CLEARING_ISLEM ci
         WHERE     SATIR_HESAP_NUMARA = '117052'
               AND ci.TX_NO = k.NUMARA
               AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE (PD_START_DATE, 'YYYYMMDD')
                                                 AND TO_DATE (PD_END_DATE, 'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE (pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA = A.FIS_ISLEM_NUMARA
               AND I.KOD = K.ISLEM_KOD
               AND K.ISLEM_KOD = 3556
        ORDER BY 1, 24, 25) T; --CBS237 BAHIANAB 17042020 --ORDER BY 24, 25;


    ELSIF (p_channelcd = 'cDKBCIB') THEN

      OPEN pc_ref FOR
        SELECT T.*, ROWNUM AS ROW_NO FROM (
        SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH,--CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                A.SATIR_MUSTERI_ACIKLAMA,
                A.SATIR_DV_TUTAR,
                NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                decode(I.KOD,
                       4003, 'SWIFT Outgoing',
                        I.ACIKLAMA) ACIKLAMA, --chyngyzo cq509 08/10/2015
                I.ACIKLAMA ACIKLAMA_2,
                K.NUMARA,
                K.ISLEM_KOD,
                PD_LANG,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO) MUSTERI_ADRES,
                Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO) MUSTERI_VERGINO,
                MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO) MUSTERI_ADI,
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                decode(I.KOD,
                       4003, (select bc_isim_adres_1 from cbs_yphavale_giden_acilis where tx_no =K.NUMARA),
                       6330, (Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO)),
                        NULL) Gonderen_Adi, --chyngyzo cq509 08/10/2015
                decode(I.KOD,
                    6330, (select KURUM_KODU || ' ' || TELEFON_ALAN_KOD || ' ' || TELEFON_NO || ' ' || TESISAT_NO  || ' ' ||  KURUM_OZEL_NO from cbs_tahsilat where TAHSILAT_FIS_NO =K.FIS_NUMARA),
                    NULL) Alici_Adi,
                A.FIS_NUMARA,
                A.SATIR_NUMARA
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
               FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD NOT IN (1203,3555,3556)
        UNION ALL
        --aisuluukas 23092015 cqdb1372 add case when islem_kod=1203
        SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, ---CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                A.SATIR_MUSTERI_ACIKLAMA,
                A.SATIR_DV_TUTAR,
                NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                decode(K.URUN_SINIF_KOD,
                       'INTERNET OWN LC', 'Transfer between Accounts',
                       'INTERNET OTHER LC', 'Transfer to Other Accounts',
                       I.ACIKLAMA) ACIKLAMA,--aisuluukas 23092015 cqdb1372 decode description
                I.ACIKLAMA ACIKLAMA_2,
                K.NUMARA,
                K.ISLEM_KOD,
                PD_LANG,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO) MUSTERI_ADRES,
                Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO) MUSTERI_VERGINO,
                MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO) MUSTERI_ADI,
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.borc_hesap_no)) Gonderen_Adi,--aisuluukas 23092015 cqdb1372 sender name
                Pkg_Musteri.SF_MUSTERI_ADI(Pkg_Hesap.HesaptanMusteriNoAl(V.alacak_hesap_no)) Alici_Adi,--aisuluukas 23092015 cqdb1372 receiver name
                A.FIS_NUMARA,
                A.SATIR_NUMARA
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_VIRMAN_ISLEM V
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
               FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND K.NUMARA=V.TX_NO
               AND I.KOD=K.ISLEM_KOD
               AND K.ISLEM_KOD = 1203
        UNION ALL
        SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                A.SATIR_MUSTERI_ACIKLAMA,
                A.SATIR_DV_TUTAR,
                NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                decode(k.URUN_SINIF_KOD,
                       'CIBGROSS', (select ff.aciklama from cbs_urun_sinif ff where ff.modul_tur_kod=k.MODUL_TUR_KOD and ff.urun_tur_kod=k.URUN_TUR_KOD and kod=k.URUN_SINIF_KOD),
                       I.ACIKLAMA) ACIKLAMA,
                I.ACIKLAMA ACIKLAMA_2,
                K.NUMARA,
                K.ISLEM_KOD,
                PD_LANG,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(A.MUSTERI_NO) MUSTERI_ADRES,
                Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
                A.MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                Pkg_Musteri.SF_MUSTERI_ADI(A.MUSTERI_NO) MUSTERI_ADI,
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                pkg_musteri.Sf_Musteri_Adi(pkg_hesap.HesaptanMusteriNoAl(SATIR_HESAP_NUMARA)) Gonderen_Adi,
                ci.TO_NAME Alici_Adi,
                A.FIS_NUMARA,
                A.SATIR_NUMARA
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
           AND ci.TX_NO = k.NUMARA
           AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
           AND FIS_TUR = 'G'
           AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
           AND K.NUMARA=A.FIS_ISLEM_NUMARA
           AND I.KOD=K.ISLEM_KOD
           AND K.ISLEM_KOD = 3555
        UNION ALL
        SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDD') FIS_YARATILDIGI_TARIH, --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD') FIS_MUHASEBELESTIGI_TARIH,
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD') SATIR_VALOR_TARIHI,
                ci.EXPLANATION SATIR_MUSTERI_ACIKLAMA, --A.SATIR_MUSTERI_ACIKLAMA,
                A.SATIR_DV_TUTAR,
                NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                I.ACIKLAMA,
                I.ACIKLAMA ACIKLAMA_2,
                K.NUMARA,
                K.ISLEM_KOD,
                PD_LANG,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(A.MUSTERI_NO) MUSTERI_ADRES,
                Pkg_Musteri.SF_VERGINO_AL(A.MUSTERI_NO) MUSTERI_VERGINO,
                A.MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA) EXTERNAL_HESAPNO,
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch') SATIR_HESAP_BOLUM_KODU,
                Pkg_Musteri.SF_MUSTERI_ADI(A.MUSTERI_NO) MUSTERI_ADI,
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA) HESAPBAKIYE,
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDD') KAYIT_SISTEM_TARIHI,
                ci.FROM_DESCRIPTION Gonderen_Adi,
                ci.TO_NAME Alici_Adi,
                A.FIS_NUMARA,
                A.SATIR_NUMARA
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I, CBS_CLEARING_ISLEM ci
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO
           AND ci.TX_NO = k.NUMARA
           AND FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(PD_START_DATE,'YYYYMMDD') AND TO_DATE(PD_END_DATE,'YYYYMMDD')
           AND FIS_TUR = 'G'
           AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
           AND K.NUMARA=A.FIS_ISLEM_NUMARA
           AND I.KOD=K.ISLEM_KOD
           AND K.ISLEM_KOD = 3556
        ORDER BY 1, 24, 25) T; --CBS237 BAHIANAB 17042020 --ORDER BY 24, 25;



    ELSE
    --IOS TemirlanT
    ld_startdate:=TO_DATE(pd_start_date,'YYYYMMDD');
    ld_enddate:=TO_DATE(pd_end_date,'YYYYMMDD');
    if (pkg_tarih.gun_ozellik(ld_enddate)=1) then
        ld_enddate:=pkg_tarih.ileri_is_gunu(ld_enddate);
    end if;
    --IOS TemirlanT
      OPEN pc_ref FOR
        SELECT  TO_CHAR(A.FIS_YARATILDIGI_TARIH,'YYYYMMDDHH24MISS'), --CBS237 BAHIANAB 17042020 --TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD'),--IOS TemirlanT HH24MISS
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDDHH24MISS'),   --IOS TemirlanT HH24MISS
                A.SATIR_MUSTERI_ACIKLAMA,
                A.SATIR_DV_TUTAR,
                NVL(pkg_passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                I.ACIKLAMA,
                I.ACIKLAMA,
                K.NUMARA,
                K.ISLEM_KOD,
                PD_LANG,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO),
                Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO),
                MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA),
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch'),
                Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO),
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA),
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'YYYYMMDDHH24MISS'),   --IOS TemirlanT HH24MISS
                ROWNUM AS ROW_NO --NU, Ordering corrected for the same tx_no
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
        WHERE  SATIR_HESAP_NUMARA = P_ACCOUNT_NO AND
               FIS_MUHASEBELESTIGI_TARIH BETWEEN ld_startdate AND ld_enddate --IOS TemirlanT HH24MISS
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(pd_hareket, 'ALL', A.SATIR_TUR, pd_hareket)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
        ORDER BY A.FIS_YARATILDIGI_TARIH, A.FIS_NUMARA, A.SATIR_NUMARA; --CBS237 BAHIANAB 17042020 --ORDER BY A.FIS_NUMARA, A.SATIR_NUMARA;

    END IF;

        ls_returncode := GetIntStatementHeader(p_option,p_customerid,p_personid,p_channelcd,p_account_no,pd_start_date,pd_end_date,pc_ref3,pc_ref4,pc_ref4,pc_ref4,pc_ref5);

  RETURN ls_returncode;
EXCEPTION
    WHEN not_valid_date THEN
        ls_returncode:='414';
    RETURN ls_returncode;
    WHEN OTHERS THEN
    ls_returncode:='999';
    Log_At('Pkg_Soa_Account.GetAccountHistory',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME        : FUNCTION FinancialSummary
   Prepared By : Almas Nurhozhaev
   Date        : 10.12.2007
   Purpose     : Financial Summary
******************************************************************************/
FUNCTION FinancialSummary(pn_customerNo IN VARCHAR2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';

BEGIN

    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

    OPEN pc_ref FOR
    SELECT * FROM
       (SELECT 'KZT Current Accounts' hesap_tanim,
               NVL(SUM(a.BAKIYE),0) bakiye_toplam,
               1 siralama,
               1 varlikborcsiralama
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU=Pkg_Genel.lc_al
    UNION
           -- current accounts in USD
        SELECT 'USD Current Accounts' hesap_tanim,
               NVL(SUM(a.BAKIYE),0) bakiye_toplam,
               2 siralama,
               1 varlikborcsiralama
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'USD'
    UNION
           -- current accounts in EUR
        SELECT 'EUR Current Accounts' hesap_tanim,
               NVL(SUM(a.BAKIYE),0) bakiye_toplam,
               3 siralama,
               1 varlikborcsiralama
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'EUR'
    UNION
           -- current accounts in other currency
        SELECT 'Current Accounts in other currency' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam,
               4 siralama,
               1 varlikborcsiralama
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
     UNION
         SELECT
             'Cash Credits in KZT' hesap_tanim,
            ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
            5 siralama,
            2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = TO_NUMBER(pn_customerNo) AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = Pkg_Genel.LC_al
     UNION
         SELECT
             'Cash Credits in USD' hesap_tanim,
            ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
            6 siralama,
            2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = TO_NUMBER(pn_customerNo) AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'USD'
     UNION
         SELECT
             'cash Credits in EUR' hesap_tanim,
            ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam,
            7 siralama,
            2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = TO_NUMBER(pn_customerNo) AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'EUR'
     UNION
         SELECT
             'Cash Credits in Other currency ' hesap_tanim,
            ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0)) bakiye_toplam,
             8 siralama,
             2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = TO_NUMBER(pn_customerNo) AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        UNION

          SELECT
                 'FCY Credits in KZT' hesap_tanim,
               ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
               9 siralama,
               2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = TO_NUMBER(pn_customerNo) AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = Pkg_Genel.LC_al
        UNION
          SELECT
                 'FCY Credits in USD' hesap_tanim,
               ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
               10 siralama,
               2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = TO_NUMBER(pn_customerNo) AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'USD'
        UNION
          SELECT
                 'FCY Credits in EUR' hesap_tanim,
               ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam,
               11 siralama,
               2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = TO_NUMBER(pn_customerNo) AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'EUR'
        UNION
          SELECT
                 'FCY Credits in other currency' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam,
               12 siralama,
               2 varlikborcsiralama
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = TO_NUMBER(pn_customerNo) AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
   )
   ORDER BY siralama ;

   OPEN pc_ref2 FOR
    SELECT * FROM
    (
        SELECT NVL(SUM(bakiye_toplam),0),1 SIRALAMA FROM
        (
            -- currenct accounts in KZT
            SELECT 'Total Holdings in KZT' hesap_tanim,
                   NVL(SUM(a.BAKIYE),0) bakiye_toplam
            FROM CBS_vw_hesap_izleme a
            WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                    a.durum_kodu = 'A' AND
                 (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
                 a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
                 a.DOVIZ_KODU=Pkg_Genel.lc_al

       )UNION
           SELECT NVL(SUM(bakiye_toplam),0),2 SIRALAMA FROM
        (
            SELECT 'Total Holdings in USA' hesap_tanim,
                   NVL(SUM(a.BAKIYE),0) bakiye_toplam
            FROM CBS_vw_hesap_izleme a
            WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                    a.durum_kodu = 'A' AND
                 (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
                 a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
                 a.DOVIZ_KODU = 'USD'
       )
       UNION
           SELECT NVL(SUM(bakiye_toplam),0),3 SIRALAMA FROM
        (
            SELECT 'Current Account in EUR' hesap_tanim,
                   NVL(SUM(a.BAKIYE),0) bakiye_toplam
            FROM CBS_vw_hesap_izleme a
            WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                    a.durum_kodu = 'A' AND
                 (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
                 a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
                 a.DOVIZ_KODU = 'EUR'

       ) UNION
        SELECT NVL(SUM(bakiye_toplam),0),4 SIRALAMA FROM
        (
               -- current account in other currency
            SELECT 'Current Account in other currency' hesap_tanim,
                   NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
            FROM CBS_vw_hesap_izleme a
            WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                    a.durum_kodu = 'A' AND
                 (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
                  a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
                 a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
       )
   )ORDER BY SIRALAMA;

   OPEN pc_ref3 FOR
  SELECT * FROM
  (
        SELECT NVL(SUM(bakiye_toplam),0),1 SIRALAMA FROM
         (
             SELECT
                 'Cash Credits in KZT' hesap_tanim,
                ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
             WHERE
                 musteri_no = TO_NUMBER(pn_customerNo) AND
                    durum_kodu = 'A' AND
                 urun_tur_kod != 'LEASING' AND
                 modul_tur_kod= 'LOAN'     AND
                 Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                    Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
                 DOVIZ_KODU = Pkg_Genel.LC_al
               UNION
               SELECT
                     'FCY Credits in KZT' hesap_tanim,
                   ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
              WHERE
                    musteri_no = TO_NUMBER(pn_customerNo) AND
                      durum_kodu = 'A' AND
                   modul_tur_kod= 'LOAN'     AND
                      Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
                   a.DOVIZ_KODU = Pkg_Genel.LC_al
           )
        UNION
        SELECT NVL(SUM(bakiye_toplam),0),2 SIRALAMA FROM
         (
             SELECT
                 'Cash Credits in USD' hesap_tanim,
                ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
             WHERE
                 musteri_no = TO_NUMBER(pn_customerNo) AND
                    durum_kodu = 'A' AND
                 urun_tur_kod != 'LEASING' AND
                 modul_tur_kod= 'LOAN'     AND
                 Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                    Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
                 DOVIZ_KODU = 'USD'

               UNION
                 SELECT
                     'FCY Credits in USD' hesap_tanim,
                   ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
                FROM CBS_vw_hesap_izleme a
                WHERE
                    musteri_no = TO_NUMBER(pn_customerNo) AND
                      durum_kodu = 'A' AND
                   modul_tur_kod= 'LOAN'     AND
                      Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
                   a.DOVIZ_KODU = 'USD'
            )
        UNION
        SELECT NVL(SUM(bakiye_toplam),0),3 SIRALAMA FROM
        (
             SELECT
                 'Cash Credits in EUR' hesap_tanim,
                ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
             WHERE
                 musteri_no = TO_NUMBER(pn_customerNo) AND
                    durum_kodu = 'A' AND
                 urun_tur_kod != 'LEASING' AND
                 modul_tur_kod= 'LOAN'     AND
                 Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                    Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
                 DOVIZ_KODU = 'EUR'
          UNION
              SELECT
                     'FCY Credits in EUR' hesap_tanim,
                   ABS(NVL(SUM((SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
              WHERE
                    musteri_no = TO_NUMBER(pn_customerNo) AND
                      durum_kodu = 'A' AND
                   modul_tur_kod= 'LOAN'     AND
                      Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
                   a.DOVIZ_KODU = 'EUR'
        )
        UNION
        SELECT NVL(SUM(bakiye_toplam),0),4 SIRALAMA FROM
        (
             SELECT
                 'Cash credits in other currency' hesap_tanim,
                ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0)) bakiye_toplam
              FROM CBS_vw_hesap_izleme a
             WHERE
                 musteri_no = TO_NUMBER(pn_customerNo) AND
                    durum_kodu = 'A' AND
                 urun_tur_kod != 'LEASING' AND
                 modul_tur_kod= 'LOAN'     AND
                 Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                    Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
                 DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
          UNION
          SELECT
                 'FCY Credits in other currency' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = TO_NUMBER(pn_customerNo) AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
   )ORDER BY SIRALAMA;

   OPEN pc_ref4 FOR
    SELECT * FROM
    (
        SELECT 'Holdings in KZT' hesap_tanim,1 SIRALAMA,SUM(bakiye_toplam) FROM
        (
        -- current account in KZT
        SELECT 'Current Accounts in KZT' hesap_tanim,
               NVL(SUM(a.BAKIYE),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU=Pkg_Genel.lc_al
        UNION
           -- current account in USD
        SELECT 'Current Account in USD' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S') ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
              a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'USD'
        UNION
           -- current account in EUR
        SELECT 'Current Accounts in EUR' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
            (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
              a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'EUR'
        UNION
           -- Current Accounts in other currency
        SELECT 'Current Accounts in other currency' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
            (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
               a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
    UNION
        SELECT 'Holdings in USD' hesap_tanim,2 SIRALAMA,SUM(bakiye_toplam) FROM
        (
        -- currenst account in kzt
        SELECT 'Current Accounts in KZT' hesap_tanim,
               NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
               ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU=Pkg_Genel.lc_al
        UNION
           -- current account in usd
        SELECT 'Currenst Accounts in USD' hesap_tanim,
               NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
               ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
              a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'USD'
        UNION
           -- current account in eur
        SELECT 'Current Accounts in EUR' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'EUR'
        UNION
           -- current account in other account
        SELECT 'Current Account in other currency' hesap_tanim,
               NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
               ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
               a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
    UNION
        SELECT 'Holdings in EUR' hesap_tanim,3 SIRALAMA,SUM(bakiye_toplam) FROM
        (
        -- current accounts in kzt
        SELECT 'Current Accounts in KZT' hesap_tanim,
               NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
               ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
              a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU=Pkg_Genel.lc_al
        UNION
           -- Currenst Accounts in usd
        SELECT 'Currenst Accounts in USD' hesap_tanim,
               NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
               ),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'USD'
        UNION
           -- Currenst Accounts in EUR
        SELECT 'Currenst Accounts in EUR' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
             a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU = 'EUR'
        UNION
           -- current accounts in other currency
        SELECT 'Current Accounts in other currency' hesap_tanim,
               NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')),0) bakiye_toplam
        FROM CBS_vw_hesap_izleme a
        WHERE a.musteri_no = TO_NUMBER(pn_customerNo) AND
                a.durum_kodu = 'A' AND
             (a.modul_tur_kod= 'CURRENT' OR a.modul_tur_kod= 'TIME DEP.') AND
              a.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') AND
             a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
   )ORDER BY siralama;

   OPEN pc_ref5 FOR

    SELECT * FROM
    (
        SELECT 'Liabilities in KZT' hesap_tanim,1 SIRALAMA,SUM(bakiye_toplam) FROM
        (

         SELECT
             'Cash Credits in KZT' hesap_tanim,
            ABS(NVL(SUM(NVL(BAKIYE,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = Pkg_Genel.LC_al
         UNION
         SELECT
             'Cash Credits in USD' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'USD'
         UNION
         SELECT
             'Cash Credits in EURO' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'EUR'
         UNION
         SELECT
             'Cash Credits in Other Currency' hesap_tanim,
            ABS(NVL(SUM(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
            ,0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
            UNION
         SELECT
                 'FCY Credits in KZT' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
         FROM CBS_vw_hesap_izleme a
         WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = Pkg_Genel.LC_al
          UNION
         SELECT
                 'FCY Credits in USD' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'USD'
             UNION
          SELECT
                 'FCY Credits in EUR' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')
               ),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'EUR'
        UNION
          SELECT
                 'FCY Credits in Other Currency' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,Pkg_Genel.LC_al,NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
      UNION

         SELECT 'Liabilities in USD' hesap_tanim,2 SIRALAMA,SUM(bakiye_toplam) FROM
        (
         SELECT
             'Cash Credits in KZT' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = Pkg_Genel.LC_al
         UNION
         SELECT
             'Cash Credits in USD' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'USD'
         UNION
         SELECT
             'Cash Credits in EURO' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'EUR'
         UNION
         SELECT
             'Cash Credits in Other Currency' hesap_tanim,
            ABS(NVL(SUM(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
            ,0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
            UNION
         SELECT
                 'FCY Credits in KZT' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
         FROM CBS_vw_hesap_izleme a
         WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = Pkg_Genel.LC_al
          UNION
         SELECT
                 'FCY Credits in USD' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'USD'
             UNION
          SELECT
                 'FCY Credits in EUR' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')
               ),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'EUR'
        UNION
          SELECT
                 'FCY Credits in Other Currency' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'USD',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )

      UNION

         SELECT 'Liabilities in EUR' hesap_tanim,3 SIRALAMA,SUM(bakiye_toplam) FROM
        (
         SELECT
             'Cash Credits in KZT' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = Pkg_Genel.LC_al
         UNION
         SELECT
             'Cash Credits in USD' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'USD'
         UNION
         SELECT
             'Cash Credits in EURO' hesap_tanim,
            ABS(NVL(SUM(NVL(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S')
            ,0)),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU = 'EUR'
         UNION
         SELECT
             'Cash Credits in Other Currency' hesap_tanim,
            ABS(NVL(SUM(
            Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,a.BAKIYE,1,NULL,NULL,'O','S'))
            ,0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
         WHERE
             musteri_no = pn_customerNo AND
                durum_kodu = 'A' AND
             urun_tur_kod != 'LEASING' AND
             modul_tur_kod= 'LOAN'     AND
             Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E' AND
                Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'H' AND
             DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
            UNION
         SELECT
                 'FCY Credits in KZT' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,(SELECT NVL(endeks_doviz_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
         FROM CBS_vw_hesap_izleme a
         WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = Pkg_Genel.LC_al
          UNION
         SELECT
                 'FCY Credits in USD' hesap_tanim,
               ABS(NVL(SUM(Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'USD'
             UNION
          SELECT
                 'FCY Credits in EUR' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A')
               ,1,NULL,NULL,'O','S')
               ),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU = 'EUR'
        UNION
          SELECT
                 'FCY Credits in Other Currency' hesap_tanim,
               ABS(NVL(SUM(
               Pkg_Kur.doviz_doviz_karsilik(a.DOVIZ_KODU,'EUR',NULL,
               (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A'),1,NULL,NULL,'O','S')),0)) bakiye_toplam
          FROM CBS_vw_hesap_izleme a
          WHERE
                musteri_no = pn_customerNo AND
                  durum_kodu = 'A' AND
               modul_tur_kod= 'LOAN'     AND
                  Pkg_Kredi.sf_dovize_endeksli_kredimi('LOAN',urun_tur_kod,urun_sinif_kod) = 'E' AND
               a.DOVIZ_KODU NOT IN ('EUR','USD',Pkg_Genel.LC_al)
        )
    )ORDER BY siralama;

    RETURN ls_returncode;

EXCEPTION
         WHEN OTHERS THEN
               Log_At('FINSUM-1',SQLERRM);
              RAISE_APPLICATION_ERROR(-20100,SQLERRM);
              OPEN pc_ref FOR SELECT '-' FROM dual;
              OPEN pc_ref2 FOR SELECT '-' FROM dual;
              OPEN pc_ref3 FOR SELECT '-' FROM dual;
              OPEN pc_ref4 FOR SELECT '-' FROM dual;
              OPEN pc_ref5 FOR SELECT '-' FROM dual;
         RETURN ls_returncode;
END;

/******************************************************************************
   NAME       : GetAccountDetails
   Created By : Almas Nurhozhaev
   Date          : 08.11.07
   Purpose      :Customer Account Detail Informations will be returned
******************************************************************************/
FUNCTION GetAccountDetails(p_option IN VARCHAR2,
                             p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                           p_channelcd IN VARCHAR2,
                           p_account_no IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                             pc_ref2 OUT CursorReferenceType,
                             pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2

IS    ls_returncode VARCHAR2(3):='000';

BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
      SELECT    hesap_no,
                sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                trim(doviz_kodu),
                kisa_isim,
                modul_tur_kod,
                urun_tur_kod,
                urun_sinif_kod,
                TO_CHAR(acilis_tarihi,'YYYYMMDD') acilis_tarihi,
                TO_CHAR(vade_tarihi,'YYYYMMDD') vade_tarihi,
                NVL(faiz_orani,0),
                NVL(bakiye,0),
                NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                NVL(bloke_tutari,0) bloke_tutari,
                cek_karnesi,
                ekstre_basim_kodu,
                NVL(birikmis_faiz_poz,0) birikmis_faiz_poz,
                NVL(birikmis_faiz_neg,0) birikmis_faiz_neg,
                NVL(gecen_yil_faiz_toplami,0) gecen_yil_faiz_toplami,
                NVL(odenmis_faiz_toplami,0)   odenmis_faiz_toplami        ,
                Pkg_Int.GetAccountSort(modul_tur_kod,urun_tur_kod,urun_sinif_kod) siralama,
                vade_islem_bilgisi,
                otomatik_temdit,
                NVL(TO_CHAR(period_sure),' ') || NVL(period_cins,' ') temdit_periodu,
                (SELECT TO_CHAR(faiz_tahakkuk_tarihi,'YYYYMMDD') FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') faiz_tahakkuk_tarihi,
                (SELECT NVL(komisyon_orani,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') komisyon_orani,
                (SELECT NVL(birikmis_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') birikmis_komisyon_tutari,
                (SELECT NVL(tahsiledilen_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') tahsiledilen_komisyon_tutari,
                (SELECT NVL(gecenyil_komisyon_tutari,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') gecenyil_komisyon_tutari,
                Pkg_Kredi.sf_endeks_doviz_kodu_al(hesap_no) end_dovz_kodu,
                (SELECT NVL(endeks_doviz_tutari    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_doviz_tutari,
                (SELECT referans FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_referans,
                (SELECT NVL(tutar,0) FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) tm_tutar,
                (SELECT TO_CHAR(verilis_tarihi,'YYYYMMDD') FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_verilis_tarihi,
                (SELECT muhatap FROM CBS_TM_HG_ACILIS WHERE hesap_no = a.hesap_no) TM_muhatap    ,
                (SELECT referans FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) AKR_Referans,
                (SELECT NVL(dosya_tutari,0) FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) dosya_tutari,
                (SELECT urun_sinif FROM CBS_ITH_AKREDITIF WHERE kredi_hesap_no = a.hesap_no) akreditifin_cinsi,
                (SELECT NVL(acilis_kuru    ,0) FROM CBS_HESAP_KREDI WHERE hesap_no = a.hesap_no AND durum_kodu = 'A') endeks_acilis_kuru,
                ISIM_UNVAN,
                EXTERNAL_HESAP_NO,
                Pkg_Musteri.Sf_Musteri_Adi(musteri_no) MUSTERI_ADI,
                (select '118'||EFT_KODU from cbs_bolum where KODU = a.SUBE_KODU) BIC -- BIC code of bank Nursultan Mukhambet uulu
                --Pkg_Musteri.Sf_Musteri_Adi((select ORTAK_MUSTERI_NO from CBS.CBS_HESAP_ORTAK_BILGI where  ANA_HESAP_NO = p_account_No)) MUSTERI_ADI_2 -- Esen Omurchiev added for task ib-111
       FROM     CBS_vw_hesap_izleme a
       WHERE    HESAP_NO = TO_NUMBER(p_account_No);

  RETURN ls_returncode;
EXCEPTION WHEN OTHERS THEN
    Log_At('Pkg_Soa_Account.GetAccountDetails',SQLERRM);
    ls_returncode:= '999';
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetTranAccounts
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Get Customer Accounts
******************************************************************************/
FUNCTION GetTranAccounts(pn_musteri_no IN VARCHAR2,
                          ps_currcode IN VARCHAR2,
                         pn_person_id  IN VARCHAR2,
                         pn_channel_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     noAccoutFound        EXCEPTION;
     ls_account_count NUMBER:=0;
BEGIN
log_at('ACCOUNTS',pn_person_id,ps_currcode,pn_musteri_No);

   OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;

        SELECT COUNT(*)
        INTO ls_account_count
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no = pn_musteri_No
        AND durum_kodu = 'A'
        AND modul_tur_kod= 'CURRENT'
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
        AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
        AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id);

        IF (ls_account_count= 0) THEN
        RAISE noAccoutFound;
        END IF;

   OPEN pc_ref FOR
        SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
        ISIM_UNVAN,
        sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
        HESAP_NO,
        DOVIZ_KODU,
        NVL(BAKIYE,0),
        NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
        1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
        external_hesap_no,
        Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD, 
        URUN_SINIF_KOD --added for task ib-175 Bakdoolot 27.07.2022
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no = pn_musteri_No
        AND durum_kodu = 'A'
        AND modul_tur_kod= 'CURRENT'
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
        AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
        AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id)
   UNION
        SELECT Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
            hizl.MUSTERI_NO,
            hizl.ISIM_UNVAN,
            hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
            hizl.HESAP_NO,
            hizl.DOVIZ_KODU,
            NVL(hizl.BAKIYE,0),
            NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
            2 siralama , TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.kisa_isim,
            hizl.external_hesap_no,
            Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) STATCD, 
            URUN_SINIF_KOD --added for task ib-175 Bakdoolot 27.07.2022
        FROM CBS_JOIN_ACCOUNT jacc
        JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
        WHERE jacc.CUST_NO=TO_NUMBER(pn_musteri_no)
        AND jacc.STATUS_CD='sACTIV'
        AND jacc.TRAN_TYPE='sTRAN'
        AND hizl.durum_kodu = 'A'
        AND hizl.modul_tur_kod= 'CURRENT'
        AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND hizl.URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND hizl.URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND hizl.DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,hizl.DOVIZ_KODU)
        AND hizl.DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL')
        and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(pn_person_id))
        ORDER BY siralama, SUBE, HESAP_NO, doviz_kodu;

  RETURN ls_returncode;

EXCEPTION
    WHEN noAccoutFound THEN
    ls_returncode:= '503';
    RETURN ls_returncode;
END;

/******************************************************************************
      NAME        : FUNCTION EFTInquiry
      Prepared By : Almas Nurhozhaev
      Date        : 05.12.07
      Purpose     : Search clearing transactions
******************************************************************************/
FUNCTION EFTInquiry (pn_musterino   IN     VARCHAR2,
                        pn_sorguno     IN     VARCHAR2,
                        pd_startdate   IN     VARCHAR2,
                        pd_enddate     IN     VARCHAR2,
                        ps_payment_type IN      VARCHAR2,--ernestk 14022014 cqdb00000504 new filter payment type
                        pn_start_amount       IN VARCHAR2,--ernestk 14022014 cqdb000000504 new filter
                        pn_end_amount       IN VARCHAR2,--ernestk 14022014 cqdb000000504 new filter
                        ps_beneficiar_name IN   VARCHAR2,--ernestk 14022014 cqdb000000504 new filter
                        ps_status      IN     VARCHAR2,
                        pc_ref            OUT CursorReferenceType,
                        pc_ref2           OUT CursorReferenceType,
                        pc_ref3           OUT CursorReferenceType,
                        pc_ref4           OUT CursorReferenceType,
                        pc_ref5           OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
      ld_startdate    DATE;
      ld_enddate      DATE;
      ls_payment_type   VARCHAR2 (20) := '%';
      ls_beneficiar_name VARCHAR2 (200) := '%';
      not_valid_date EXCEPTION;
      PRAGMA EXCEPTION_INIT (not_valid_date, -01839);
   BEGIN
      IF LENGTH (pd_startdate) = 8
      THEN
         ld_startdate := TO_DATE (pd_startdate, 'YYYYMMDD');
         ld_enddate := TO_DATE (pd_enddate, 'YYYYMMDD');
      END IF;

      --B-O-M ernestk 14022014 cqdb00000504 add new filters and gross payments
      SELECT DECODE(ps_payment_type, 'CLEARING', 'CLEARING', 'GROSS', 'GROSS', '%') INTO ls_payment_type FROM dual;

      SELECT DECODE(ps_beneficiar_name, '', '%', '%'||ps_beneficiar_name||'%') INTO ls_beneficiar_name FROM dual;

      IF ps_status != 'I'
      THEN
         IF (pn_sorguno IS NULL)
         THEN
            OPEN pc_ref FOR
               SELECT   TO_CHAR (a.MATURITY_DATE, 'DD.MM.YYYY') MATURITY_DATE,
                        a.MSG_STATUS,
                        a.AMOUNT,
                        a.BOLUM_KODU,
                        TO_CHAR (a.YARATILDIGI_TARIH, 'DD.MM.YYYY')
                           YARATILDIGI_TARIH,
                        a.AMOUNT,
                        a.FROM_ACCOUNT,
                        pkg_musteri.Sf_Musteri_Adi (a.MUSTERI_NO),
                        FROM_RNN,
                        FROM_OKPO,
                        FROM_SOCIAL_FUND_NUMBER,
                        pkg_int_transfer.GetBranchName (a.BOLUM_KODU),
                        BOLUM_KODU,
                        TO_BANK_BIC,
                        TO_BANK_BIC,
                        a.TO_ACCOUNT_EXTERNAL_NUMBER,
                        a.TO_NAME,
                        '',
                        '',
                        '',
                        a.REF_NO,
                        a.URUN_TUR_KOD,
                        a.YARATAN_TX_NO,
                        TO_SUBACCOUNT_NAME,
                        Pkg_Soa_Common.GetBankName (BOLUM_KODU),
                        --Pkg_Soa_Common.GetBankName (TO_BANK_BIC)
                        PKG_GENEL.BANKA_ADI_AL_EFT(to_bank_bic),
                        A.CODE_OF_PAYMENT,
                        getPaymentCodeExplanation(a.code_of_payment, 'RUS'),
                        A.PAYMENT_TYPE,
                        A.EXPLANATION
                 FROM   CBS_CLEARING a, CBS_ISLEM b
                WHERE   a.YARATAN_TX_NO = b.NUMARA
                        AND a.from_account IN
                                 (SELECT to_char(hesap_no)
                                    FROM   CBS_HESAP
                                   WHERE   musteri_no =
                                              TO_NUMBER (pn_musterino))
                        AND a.YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY'))
                        AND a.YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1

                        AND UPPER(a.payment_type) LIKE UPPER(ls_payment_type)
                        AND UPPER(A.TO_NAME) LIKE UPPER(ls_beneficiar_name)
                        AND A.AMOUNT BETWEEN
                            DECODE(TO_NUMBER(pn_start_amount,'999999999999.99'),'',0,
                                TO_NUMBER(pn_start_amount, '999999999999.99'))
                            AND
                            DECODE(TO_NUMBER(pn_end_amount,'999999999999.99'),'',999999999999.99,
                                TO_NUMBER(pn_end_amount, '999999999999.99'))
               UNION
               SELECT   TO_CHAR (a.MATURITY_DATE, 'DD.MM.YYYY') MATURITY_DATE,
                        a.MSG_STATUS,
                        a.AMOUNT,
                        a.BOLUM_KODU,
                        TO_CHAR (a.YARATILDIGI_TARIH, 'DD.MM.YYYY')
                           YARATILDIGI_TARIH,
                        a.AMOUNT,
                        a.FROM_ACCOUNT,
                        pkg_musteri.Sf_Musteri_Adi (a.MUSTERI_NO),
                        FROM_RNN,
                        FROM_OKPO,
                        FROM_SOCIAL_FUND_NUMBER,
                        pkg_int_transfer.GetBranchName (a.BOLUM_KODU),
                        BOLUM_KODU,
                        TO_BANK_BIC,
                        TO_BANK_BIC,
                        a.TO_ACCOUNT_EXTERNAL_NUMBER,
                        a.TO_NAME,
                        '',
                        '',
                        '',
                        a.REF_NO,
                        a.URUN_TUR_KOD,
                        a.YARATAN_TX_NO,
                        TO_SUBACCOUNT_NAME,
                        Pkg_Soa_Common.GetBankName (BOLUM_KODU),
                        --Pkg_Soa_Common.GetBankName (TO_BANK_BIC)
                        PKG_GENEL.BANKA_ADI_AL_EFT(to_bank_bic),
                        A.CODE_OF_PAYMENT,
                        getPaymentCodeExplanation(a.code_of_payment, 'RUS'),
                        A.PAYMENT_TYPE,
                        A.EXPLANATION
                 FROM   CBS_CLEARING a
                WHERE   a.from_account IN
                              (SELECT   to_char(hesap_no)
                                 FROM   CBS_HESAP
                                WHERE   musteri_no = TO_NUMBER (pn_musterino))
                        AND a.MSG_STATUS = 'sDONE'
                        AND a.YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY'))
                        AND a.YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1

                    AND UPPER(a.payment_type) LIKE UPPER(ls_payment_type)
                    AND UPPER(A.TO_NAME) LIKE UPPER(ls_beneficiar_name)
                    AND A.AMOUNT BETWEEN
                            DECODE(TO_NUMBER(pn_start_amount,'999999999999.99'),'',0,
                                TO_NUMBER(pn_start_amount, '999999999999.99'))
                            AND
                            DECODE(TO_NUMBER(pn_end_amount,'999999999999.99'),'',999999999999.99,
                                TO_NUMBER(pn_end_amount, '999999999999.99'))
               ORDER BY   YARATILDIGI_TARIH;
         ELSE
            OPEN pc_ref FOR
                 SELECT   TO_CHAR (a.MATURITY_DATE, 'DD.MM.YYYY') MATURITY_DATE,
                          a.MSG_STATUS,
                          a.AMOUNT,
                          a.BOLUM_KODU,
                          TO_CHAR (a.YARATILDIGI_TARIH, 'DD.MM.YYYY')
                             YARATILDIGI_TARIH,
                          a.AMOUNT,
                          a.FROM_ACCOUNT,
                          pkg_musteri.Sf_Musteri_Adi (a.MUSTERI_NO),
                          FROM_RNN,
                          FROM_OKPO,
                          FROM_SOCIAL_FUND_NUMBER,
                          pkg_int_transfer.GetBranchName (a.BOLUM_KODU),
                          BOLUM_KODU,
                          TO_BANK_BIC,
                          TO_BANK_BIC,
                          a.TO_ACCOUNT_EXTERNAL_NUMBER,
                          a.TO_NAME,
                          '',
                          '',
                          '',
                          a.REF_NO,
                          a.URUN_TUR_KOD,
                          a.YARATAN_TX_NO,
                          TO_SUBACCOUNT_NAME,
                          Pkg_Soa_Common.GetBankName (BOLUM_KODU),
                          Pkg_Soa_Common.GetBankName (TO_BANK_BIC)
                   FROM   CBS_CLEARING a
                  WHERE   from_account IN
                                (SELECT   to_char(hesap_no)
                                   FROM   CBS_HESAP
                                  WHERE   musteri_no = TO_NUMBER (pn_musterino))
                          AND a.YARATILDIGI_TARIH>=NVL(ld_startdate,TO_DATE('01011900','DDMMYYYY'))
                          AND a.YARATILDIGI_TARIH< NVL(ld_enddate,TO_DATE('01012900','DDMMYYYY'))+1
               ORDER BY   MATURITY_DATE, ref_no;
         END IF;
      ELSE                                                 --only sWAIT status
         OPEN pc_ref FOR
              SELECT   TO_CHAR (a.MATURITY_DATE, 'DD.MM.YYYY') MATURITY_DATE,
                       a.MSG_STATUS,
                       a.AMOUNT,
                       a.BOLUM_KODU,
                       TO_CHAR (a.YARATILDIGI_TARIH, 'DD.MM.YYYY')
                          YARATILDIGI_TARIH,
                       a.AMOUNT,
                       a.FROM_ACCOUNT,
                       pkg_musteri.Sf_Musteri_Adi (a.MUSTERI_NO),
                       FROM_RNN,
                       FROM_OKPO,
                       FROM_SOCIAL_FUND_NUMBER,
                       pkg_int_transfer.GetBranchName (a.BOLUM_KODU),
                       BOLUM_KODU,
                       TO_BANK_BIC,
                       TO_BANK_BIC,
                       a.TO_ACCOUNT_EXTERNAL_NUMBER,
                       a.TO_NAME,
                       '',
                       '',
                       '',
                       a.REF_NO,
                       a.URUN_TUR_KOD,
                       a.YARATAN_TX_NO,
                       TO_SUBACCOUNT_NAME,
                       Pkg_Soa_Common.GetBankName (BOLUM_KODU),
                       Pkg_Soa_Common.GetBankName (TO_BANK_BIC)
                FROM   CBS_CLEARING a
               WHERE   a.from_account IN
                             (SELECT   to_char(hesap_no)
                                FROM   CBS_HESAP
                               WHERE   musteri_no = TO_NUMBER (pn_musterino))
                       AND a.MSG_STATUS = 'sNEW'
            ORDER BY   a.MATURITY_DATE, ref_no;
      END IF;                                         --status!='I' all status
      --E-O-M ernestk 14022014 cqdb00000504 add new filters and gross payments
      OPEN pc_ref2 FOR SELECT   '-' FROM DUAL;

      OPEN pc_ref3 FOR SELECT   '-' FROM DUAL;

      OPEN pc_ref4 FOR SELECT   '-' FROM DUAL;

      OPEN pc_ref5 FOR SELECT   '-' FROM DUAL;

      RETURN ls_returncode;
   EXCEPTION
      WHEN not_valid_date
      THEN
         ls_returncode := '414';

         OPEN pc_ref FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref2 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref3 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref4 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref5 FOR SELECT   SYSDATE FROM DUAL;

         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         ls_returncode := '999';
         Log_At (SQLERRM);

         OPEN pc_ref FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref2 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref3 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref4 FOR SELECT   SYSDATE FROM DUAL;

         OPEN pc_ref5 FOR SELECT   SYSDATE FROM DUAL;

         RETURN ls_returncode;
   END;

/******************************************************************************
   NAME        : FUNCTION GetPaymentCodes
   Prepared By : Almas Nurhozhaev
   Date        : 03.07.08
   Purpose     : Get Payment Codes
******************************************************************************/
FUNCTION GetPaymentCodes(ps_langcd IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     TransactionError      EXCEPTION;
     ls_returncode          VARCHAR2(3):='000';
BEGIN

    IF (ps_langcd='ENG') THEN
         OPEN pc_ref FOR
            SELECT t.KOD, SUBSTR(t.ACIKLAMA_ING,1,50) || CASE WHEN LENGTH(t.ACIKLAMA_ING)>50 THEN '...' END

            FROM cbs.CBS_PAYMENT_CODE t
            WHERE t.ACIKLAMA_ING IS NOT NULL

            ORDER BY t.KOD;
    ELSE
         OPEN pc_ref FOR
         SELECT t.KOD, SUBSTR(t.ACIKLAMA_RUS,1,50) || CASE WHEN LENGTH(t.ACIKLAMA_RUS)>50 THEN '...' END

            FROM cbs.CBS_PAYMENT_CODE t
            WHERE t.ACIKLAMA_RUS IS NOT NULL

            ORDER BY t.KOD;
    END IF;

     RETURN ls_returncode;
EXCEPTION
        WHEN TransactionError THEN
             RETURN ls_returncode;
END;

/******************************************************************************
   NAME       : FUNCTION GetCustomerInfo
   Created By : Almas Nurhozhaev
   Date       : 05.12.07
   Purpose    : Get Customer Info
******************************************************************************/
FUNCTION GetCustomerInfo(ps_customerid IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count      NUMBER := 0;
    no_data       EXCEPTION;
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;

        SELECT COUNT(*)
        INTO ln_count
        FROM CBS_MUSTERI m, CBS_MUSTERI_ADRES a , CBS_IL_KODLARI i, CBS_UYRUK_KODLARI u, CBS_ULKE_KODLARI b,
           CBS_ADRES_KODLARI k, CBS_MESLEK_KODLARI l, CBS_EGITIM_KODLARI g, CBS_CINSIYET_KODLARI c, CBS_MEDENI_HAL_KODLARI h
         WHERE m.musteri_no = TO_NUMBER(ps_customerid)
      AND m.musteri_no = a.musteri_no
      AND m.EXTRE_ADRES_KOD = a.ADRES_KOD(+)
      AND m.UYRUK_KOD  = u.UYRUK_KODU(+)
      AND a.ULKE_KOD   = b.ULKE_KODU(+)
      AND a.il_kod     = i.il_kodu(+)
      AND k.ADRES_TIPI = a.ADRES_KOD
      AND h.MEDENI_HAL_KODU(+) = m.MEDENI_HAL_KOD
      AND c.CINSIYET_KODU(+) = m.CINSIYET_KOD
      AND l.MESLEK_KODU(+) = m.MESLEK_KOD
      AND g.EGITIM_KODU(+) = m.EGITIM_KOD;

        IF (ln_count= 0) THEN
           RAISE no_data;
        END IF;

        OPEN pc_ref FOR
        SELECT Pkg_Musteri.Sf_Musteri_Adi(ps_customerid), NVL(TO_CHAR(m.DOGUM_TARIHI,'YYYYMMDD'),' '), NVL(m.DOGUM_YERI,' '), NVL(c.ACIKLAMA,' '), NVL(h.ACIKLAMA,' '),
             m.VERGI_NO, NVL(m.VERGI_DAIRESI_ADI,' '), NVL(m.UYRUK_KOD,' '), NVL(u.ACIKLAMA,' '), m.TC_KIMLIK_NO,
             NVL(a.ADRES,' '), NVL(a.SEMT,' '), NVL(a.IL_KOD,' '), NVL(i.IL_ADI,' '), a.POSTA_KOD,
             a.ULKE_KOD, NVL(b.ULKE_ADI,''), NVL(a.EMAIL,' '), a.TEL_ALAN_KOD, a.TEL_NO,
             a.GSM_ALAN_KOD, a.GSM_NO, NVL(k.ACIKLAMA,' '), m.MUSTERI_TIPI_KOD, NVL(TO_CHAR(m.DOGUM_TARIHI,'MMDD'),' '),
              NVL(TO_CHAR(SYSDATE,'MMDD'),' '), NVL(l.ACIKLAMA,' '), NVL(g.ACIKLAMA,' '), m.PERSONEL_SICIL_NO, m.MEDENI_HAL_KOD,
              m.CINSIYET_KOD, m.EXTRE_ADRES_KOD
         FROM CBS_MUSTERI m, CBS_MUSTERI_ADRES a , CBS_IL_KODLARI i, CBS_UYRUK_KODLARI u, CBS_ULKE_KODLARI b,
           CBS_ADRES_KODLARI k, CBS_MESLEK_KODLARI l, CBS_EGITIM_KODLARI g, CBS_CINSIYET_KODLARI c, CBS_MEDENI_HAL_KODLARI h
         WHERE m.musteri_no = TO_NUMBER(ps_customerid)
      AND m.musteri_no = a.musteri_no
      AND m.EXTRE_ADRES_KOD = a.ADRES_KOD(+)
      AND m.UYRUK_KOD  = u.UYRUK_KODU(+)
      AND a.ULKE_KOD   = b.ULKE_KODU(+)
      AND a.il_kod     = i.il_kodu(+)
      AND k.ADRES_TIPI = a.ADRES_KOD
      AND h.MEDENI_HAL_KODU(+) = m.MEDENI_HAL_KOD
      AND c.CINSIYET_KODU(+) = m.CINSIYET_KOD
      AND l.MESLEK_KODU(+) = m.MESLEK_KOD
      AND g.EGITIM_KODU(+) = m.EGITIM_KOD;

      OPEN pc_ref2 FOR
      SELECT a.ADRES_KOD, k.ACIKLAMA, a.ADRES,Pkg_Genel.sehir_adi_al_hatasiz(a.IL_KOD), a.IL_KOD, Pkg_Genel.ilce_adi_al_hatasiz(a.IL_KOD,a.ILCE_KOD),
             a.ILCE_KOD, a.POSTA_KOD, a.SEMT, a.TEL_ALAN_KOD, a.TEL_NO,
             a.GSM_ALAN_KOD, a.GSM_NO, a.EMAIL, Pkg_Genel.ulke_adi_al_hatasiz(a.ULKE_KOD),
             a.ULKE_KOD, a.ADRES ||' '||NVL(a.POSTA_KOD,'')||' '||a.SEMT||' '||
             Pkg_Genel.sehir_adi_al_hatasiz(a.IL_KOD)||' '||Pkg_Genel.ulke_adi_al_hatasiz(a.ULKE_KOD),'('||a.TEL_ALAN_KOD||') '||a.TEL_NO,'('||a.GSM_ALAN_KOD||') '||a.GSM_NO,
             ULKE_GSM_KOD_2, GSM_ALAN_KOD_2, GSM_NO_2, ULKE_GSM_KOD_3, GSM_ALAN_KOD_3, GSM_NO_3, ULKE_GSM_KOD
      FROM CBS_MUSTERI_ADRES a, CBS_ADRES_KODLARI k
      WHERE a.MUSTERI_NO = TO_NUMBER(ps_customerid)
      AND k.ADRES_TIPI = a.ADRES_KOD
      ORDER BY k.ADRES_TIPI DESC;

      OPEN pc_ref3 FOR
      SELECT  CUSTOMERID, DECODE(CURRINFOSMS,'sENAB','1','0'),DECODE(CURRINFOMAIL,'sENAB','1','0') ,CURRINFPERIOD,
              DECODE(FINREPSMS,'sENAB','2','0'),DECODE(FINREPMAIL,'sENAB','2','0') ,FINREPPERIOD,
              DECODE(MONTRANBETMASMS,'sENAB','3','0'), DECODE(MONTRANBETMAMAIL,'sENAB','3','0'),
              DECODE(MONINFOASMS,'sENAB','4','0'),DECODE(MONINFOAMAIL,'sENAB','4','0') ,
              DECODE(MONOUT2OASMS,'sENAB','5','0'), DECODE(MONOUT2OAMAIL,'sENAB','5','0'),
              DECODE(EXCHNGSMS,'sENAB','6','0'), DECODE(EXCHNGMAIL,'sENAB','6','0'), NOTIFYLANG
      FROM CBS_INT_INFORM
      WHERE CUSTOMERID = TO_NUMBER(ps_customerid);

      OPEN pc_ref4 FOR
      SELECT m.ISIM_ENG first_name_eng, m.SOYADI_ENG last_name_eng, m.IKINCI_ISIM_ENG middle_name_eng
      FROM CBS_MUSTERI m
      WHERE m.musteri_no = TO_NUMBER(ps_customerid);

      RETURN ls_returncode;
EXCEPTION
         WHEN NO_DATA_FOUND THEN
               RETURN '025';
         WHEN no_data THEN
               RETURN '025';
END;

/******************************************************************************
   NAME        : FUNCTION GetVirmanHesapInfo
   Prepared By : Almas Nurhozhaev
   Date        : 07.12.07
   Purpose     : GetVirmanHesapInfo
******************************************************************************/
FUNCTION GetVirmanHesapInfo(ps_account_no IN VARCHAR2,
                            ps_currcode IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
   ls_returncode        VARCHAR2(3):='000';
   ln_hesap_count        NUMBER:=0;
   noAccoutFound        EXCEPTION;
   ls_returncodetmp        VARCHAR2(3):='000';
   ls_currency_code CBS_vw_hesap_izleme.DOVIZ_KODU%TYPE;
BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;

    SELECT COUNT(*)
    INTO ln_hesap_count
    FROM CBS_vw_hesap_izleme
    WHERE EXTERNAL_HESAP_NO = ps_account_no; -- var ise detay?n? al?yorum ??nk? detay kodu bunu handle etmiyor

    IF (ln_hesap_count > 0) THEN
        IF (ps_currcode IS NULL OR ps_currcode = '') THEN
            SELECT DOVIZ_KODU
            INTO ls_currency_code
            FROM CBS_vw_hesap_izleme
            WHERE EXTERNAL_HESAP_NO = ps_account_no
            AND ROWNUM=1;
        ELSE
            ls_currency_code := ps_currcode;
        END IF;

        ls_returncode := Pkg_Int_Account.GetCustomerExtAccountDetails(ps_account_no,ls_currency_code,pc_ref); --  account bilgilerini al
    ELSE
        RAISE noAccoutFound;
    END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN noAccoutFound THEN
        ls_returncode:='505';
        RETURN ls_returncode;
    WHEN OTHERS THEN
        ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT SYSDATE FROM dual;
        RETURN ls_returncode;
END;

   /******************************************************************************
                                                                        NAME        : FUNCTION geteftdate
      Prepared By : Almas Nurhozhaev
      Date        : 06.12.07
      Purpose     : Get clearing transaction date
   ******************************************************************************/
   FUNCTION geteftdate (    pd_date IN VARCHAR2,
                            ps_transfer_option IN VARCHAR2,--ernestk 14022014 cqdb00000504 by payment type
                            pc_ref OUT cursorreferencetype)
      RETURN VARCHAR2
   IS
      ld_date         DATE;
      ls_returncode   VARCHAR2 (3) := '000';
      ps_starthour    VARCHAR2 (10);
      ps_endhour      VARCHAR2 (10);
      ps_tmp          NUMBER := 0;
      not_valid_date EXCEPTION;
      PRAGMA EXCEPTION_INIT (not_valid_date, -01839);
   BEGIN
      --ernestk 22042014 cqdb00000968 removed cause this function is used to get date not only for CLEARING and GROSS
      -- ps_tmp := Pkg_Int_Transfer.geteftsaatsinirlari (ps_starthour, ps_endhour);
      /*IF ps_transfer_option NOT IN ('CLEARING', 'GROSS') THEN
        RAISE not_valid_date;
      END IF;*/

      SELECT
        LPAD(start_hh24,2,'0')||':'||LPAD(start_mm,2,'0') AS start_hour,
        LPAD(end_hh24,2,'0')||':'||LPAD(end_mm,2,'0') AS end_hour
      INTO
        ps_starthour,
        ps_endhour
      FROM cbs.CBS_INT_TIME WHERE tran_cd=ps_transfer_option;

      IF (TO_DATE (pd_date, 'YYYYMMDD') < TRUNC (SYSDATE))
      THEN
         --ls_returncode := '413';
         ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD'));--aisuluud cq5205 25102016 changed from ileri_is_gunu to ileri_is_gunu_report
         ps_tmp := 1;
      ELSIF ( (TO_DATE (pd_date, 'YYYYMMDD') = TRUNC (SYSDATE)) AND ( (TO_DATE (pd_date, 'YYYYMMDD') < TRUNC(Pkg_Muhasebe.banka_tarihi_bul))))
      THEN
         ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD'));--aisuluud cq5205 25102016 changed from ileri_is_gunu to ileri_is_gunu_report
         ps_tmp := 1;
      ELSIF ( (TO_DATE (pd_date, 'YYYYMMDD') > TRUNC (SYSDATE)) AND ( (TO_DATE (pd_date, 'YYYYMMDD') <= TRUNC(Pkg_Muhasebe.banka_tarihi_bul))) AND (TRUNC(SYSDATE) = Pkg_Muhasebe.Banka_Tarihi_Bul))
      THEN
         ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD'));--aisuluud cq5205 25102016 changed from ileri_is_gunu to ileri_is_gunu_report
         ps_tmp := 1;
      ELSIF (TO_DATE (pd_date, 'YYYYMMDD') = TRUNC(Pkg_Muhasebe.banka_tarihi_bul)) AND (TRUNC(SYSDATE) = Pkg_Muhasebe.Banka_Tarihi_Bul)
      THEN
         IF ( (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_starthour) = 1)
             AND (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_endhour) = 2))
         THEN
         --BOM aisuluud CQ5205 25102016
            --ld_date :=  TO_DATE (pd_date, 'YYYYMMDD');
            ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD') - 1);
         --EOM aisuluud CQ5205 25102016
            ps_tmp := 0;
         ELSIF (checktime (TO_CHAR (SYSDATE, 'HH24:MI'), ps_starthour) = 2)
         THEN
         --BOM aisuluud CQ5205 25102016
            --ld_date := TO_DATE (pd_date, 'YYYYMMDD');
            ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD') - 1);
         --EOM aisuluud CQ5205 25102016
            ps_tmp := 0;
         ELSE
         --BOM aisuluud CQ5205 25102016
            --ld_date := Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date, 'YYYYMMDD'));
            ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD'));
         --EOM aisuluud CQ5205 25102016
            ps_tmp := 1;
         END IF;
      ELSIF TO_DATE (pd_date, 'YYYYMMDD') < TRUNC (Pkg_Muhasebe.sonraki_banka_tarihi_bul)
             AND TRUNC(SYSDATE) > TRUNC(Pkg_Muhasebe.banka_tarihi_bul)
      THEN
         ld_date := Pkg_Muhasebe.sonraki_banka_tarihi_bul;
         ps_tmp := 1;
      ELSE
         IF Pkg_Tarih.gun_ozellik (TO_DATE (pd_date, 'YYYYMMDD')) = 0
         THEN
         --BOM aisuluud CQ5205 25102016
            --ld_date := TO_DATE (pd_date, 'YYYYMMDD');
            ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD') - 1);
         --EOM aisuluud CQ5205 25102016
            ps_tmp := 1;
         ELSE
         --BOM aisuluud CQ5205 25102016
            --ld_date := Pkg_Tarih.ileri_is_gunu (TO_DATE (pd_date, 'YYYYMMDD'));
            ld_date := Pkg_Tarih.ileri_is_gunu_report (TO_DATE (pd_date, 'YYYYMMDD'));
         --EOM aisuluud CQ5205 25102016
            ps_tmp := 1;
         END IF;
      END IF;

      OPEN pc_ref FOR
         SELECT   TO_CHAR (ld_date, 'YYYYMMDD'),
                  ps_tmp,
                  TO_CHAR (
                  --BOM aisuluud CQ5205 25102016
                     --PKG_TARIH.ILERI_GUN (Pkg_Muhasebe.banka_tarihi_bul, 2),
                     PKG_TARIH.ILERI_GUN_REPORT (Pkg_Muhasebe.banka_tarihi_bul, 2),
                  --EOM aisuluud CQ5205 25102016
                     'YYYYMMDD'
                  ) ILERI_GUN_REPORT, --aisuluud CQ5205 25102016 added alias ILERI_GUN_REPORT
                  TO_CHAR (
                  --BOM aisuluud CQ5205 25102016
                     --PKG_TARIH.ILERI_IS_GUNU (Pkg_Muhasebe.banka_tarihi_bul),
                     PKG_TARIH.ILERI_IS_GUNU_REPORT (Pkg_Muhasebe.banka_tarihi_bul),
                  --EOM aisuluud CQ5205 25102016
                     'YYYYMMDD'
                  ) ILERI_IS_GUNU_REPORT, --aisuluud CQ5205 25102016 added alias ILERI_IS_GUNU_REPORT
                  TO_CHAR (
                  --BOM aisuluud CQ5205 25102016
                     --PKG_TARIH.ILERI_GUN (Pkg_Muhasebe.banka_tarihi_bul, 3),
                     PKG_TARIH.ILERI_GUN_REPORT (Pkg_Muhasebe.banka_tarihi_bul, 3),
                  --EOM aisuluud CQ5205 25102016
                     'YYYYMMDD'
                  ) ILERI_GUN_REPORT_2 --aisuluud CQ5205 25102016 added alias ILERI_GUN_REPORT_2
           FROM   DUAL;

      RETURN ls_returncode;
   EXCEPTION
      WHEN not_valid_date
      THEN
         ls_returncode := '414';

         OPEN pc_ref FOR SELECT   SYSDATE FROM DUAL;

         RETURN ls_returncode;
   END;

/******************************************************************************
   NAME        : FUNCTION checktime
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Check clearing transaction making time
******************************************************************************/
FUNCTION checktime (pd_desc IN VARCHAR2, pd_src IN VARCHAR2) RETURN NUMBER IS
BEGIN
  IF (TO_NUMBER (SUBSTR (pd_desc, 0, 2)) > TO_NUMBER (SUBSTR (pd_src, 0, 2))) THEN
     RETURN 1;
  ELSIF (TO_NUMBER (SUBSTR (pd_desc, 0, 2)) < TO_NUMBER (SUBSTR (pd_src, 0, 2))) THEN
     RETURN 2;
  ELSE
     IF (TO_NUMBER (SUBSTR (pd_desc, 4, 2)) > TO_NUMBER (SUBSTR (pd_src, 4, 2))) THEN
        RETURN 1;
     ELSE
        RETURN 2;
     END IF;
  END IF;
END;

/******************************************************************************
   NAME        : FUNCTION GetBankCodes
   Prepared By : Almas Nurhozhaev
   Date        : 06.12.07
   Purpose     : Get Banks Code
******************************************************************************/
FUNCTION GetBankCodes(ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
        SELECT BANKA_KODU,SUBSTR(BANKA_ADI,1,40)
        FROM CBS_BANKA_KODLARI
        ORDER BY BANKA_KODU;

    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetLoanAccount
   Prepared By : Almas Nurhozhaev
   Date        : 21.12.2007
   Purpose     : Get Loan Account
******************************************************************************/
FUNCTION GetLoanAccount(pn_CustomerId IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode  VARCHAR2(3):='000';
   ln_count       NUMBER;
   noLoanAccoutFound        EXCEPTION;
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

     SELECT COUNT(*)
     INTO ln_count
     FROM CBS_vw_hesap_izleme
     WHERE musteri_no = TO_NUMBER(pn_CustomerId)
     AND durum_kodu = 'A'
     AND urun_tur_kod != 'LEASING'
     AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
     AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
     AND modul_tur_kod= 'LOAN'
     AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';

     IF (ln_count= 0) THEN
        RAISE noLoanAccoutFound;
     END IF;


     OPEN pc_ref FOR
     SELECT 'Cash Credits' modul_tur_kod, MUSTERI_NO, ISIM_UNVAN, sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE, HESAP_NO,
            DOVIZ_KODU, NVL(BAKIYE,0), NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye, 3 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2)
     FROM CBS_vw_hesap_izleme
     WHERE musteri_no = TO_NUMBER(pn_CustomerId)
     AND durum_kodu = 'A'
     AND urun_tur_kod NOT IN ('LEASING')
     AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
     AND urun_sinif_kod NOT IN ('CREDIT CARD-LC','OVERLIMIT-LC')
     AND modul_tur_kod= 'LOAN'
     AND Pkg_Genel.urun_sinif_nakdimi('LOAN',urun_tur_kod,urun_sinif_kod) ='E';


     RETURN ls_returncode;
EXCEPTION
    WHEN noLoanAccoutFound THEN
         ls_returncode:= '058';
    RETURN ls_returncode;
    WHEN OTHERS THEN
          ls_returncode:=Pkg_Int_Api.GetErrorCode(SQLERRM);
          RAISE_APPLICATION_ERROR(-20100,SQLERRM);
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetTimeDepositRate
   Prepared By : Almas Nurhozhaev
   Date        : 05.06.2008
   Purpose     : Get Rates of Time Deposit
******************************************************************************/
FUNCTION GetTimeDepositRate(pn_CustomerId  IN VARCHAR2,
                            pn_PersonId    IN VARCHAR2,
                            ps_ChannelCd   IN VARCHAR2,
                            ps_CurrencyCd  IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    accountException  EXCEPTION;
BEGIN

     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

     OPEN pc_ref FOR
            SELECT VADE_1, VADE_2, 0, 0, DECODE(ps_CurrencyCd,'RUB',RUB,'USD',USD,'EUR',EUR,TRL)--cq6018
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE tarih=Pkg_Muhasebe.Banka_Tarihi_Bul
            AND musteri_tipi=1
            ORDER BY vade_1,vade_2;

     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT TO_CHAR(Pkg_Muhasebe.BANKA_TARIHI_BUL,'YYYYMMDD') FROM dual;

  RETURN ls_returncode;
EXCEPTION
    WHEN accountException THEN
      ls_returncode:= '999';
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME          : FUNCTION GetIntTranAccounts
   Created By    : Almas Nurhozhaev
   Create Date   : 07.07.2008
   Purpose       : Get Int Tran Accounts
******************************************************************************/
FUNCTION  GetIntTranAccounts(pn_musteri_no IN VARCHAR2,
                              ps_currcode IN VARCHAR2,
                             pn_person_id  IN VARCHAR2,
                             pn_channel_cd IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     noAccoutFound        EXCEPTION;
     ls_account_count NUMBER:=0;
BEGIN
     OPEN pc_ref FOR SELECT SYSDATE FROM dual;

         SELECT COUNT(*)
      INTO ls_account_count
      FROM CBS_vw_hesap_izleme a
      WHERE musteri_no = pn_musteri_No
         AND durum_kodu = 'A'
         AND modul_tur_kod= 'CURRENT'
         AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
         AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
         --AND DOVIZ_KODU=ps_currcode
         AND INSTR(ps_currcode, DOVIZ_KODU, 1, 1) <> 0
         AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id);

      IF (ls_account_count= 0) THEN
      RAISE noAccoutFound;
      END IF;

  OPEN pc_ref FOR
      SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
               external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
       FROM CBS_vw_hesap_izleme a
       WHERE musteri_no = pn_musteri_No
                AND durum_kodu = 'A'
         AND modul_tur_kod= 'CURRENT'
         AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
         AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
             --AND DOVIZ_KODU=ps_currcode
             AND INSTR(ps_currcode, DOVIZ_KODU, 1, 1) <> 0
             AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id)
             AND URUN_SINIF_KOD <> 'OVERBALANCE-LC'  AND URUN_SINIF_KOD <> 'OVERBALANCE-FC' --added By Esen 14-10-2021
     UNION
     SELECT  Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
             hizl.MUSTERI_NO,
             hizl.ISIM_UNVAN,
             hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
             hizl.HESAP_NO,
             hizl.DOVIZ_KODU,
             NVL(hizl.BAKIYE,0),
             NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
             2 siralama, TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.kisa_isim,
             hizl.external_hesap_no,
             Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) STATCD
        FROM CBS_JOIN_ACCOUNT jacc
        JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
        WHERE jacc.CUST_NO=TO_NUMBER(pn_musteri_no)
        AND jacc.STATUS_CD='sACTIV'
        AND jacc.TRAN_TYPE='sTRAN'
        AND hizl.durum_kodu = 'A'
        AND hizl.modul_tur_kod= 'CURRENT'
        AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND hizl.URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND hizl.URUN_SINIF_KOD <> 'OVERBALANCE-LC'  AND hizl.URUN_SINIF_KOD <> 'OVERBALANCE-FC' --added By Esen 14-10-2021
        AND INSTR(ps_currcode, hizl.DOVIZ_KODU, 1, 1) <> 0
        and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(pn_person_id))
        ORDER BY siralama, SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;
EXCEPTION
    WHEN noAccoutFound THEN
      ls_returncode:= '503';
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetCurrencyInfo
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Currency Info
******************************************************************************/
FUNCTION GetCurrencyInfo(ps_option        IN VARCHAR2,
                         ps_musterino      IN VARCHAR2,
                         ps_reservationno IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
    IF ps_option = 'DVZCOD' THEN
        OPEN pc_ref FOR
        SELECT DVZ , ACIKLAMA
        FROM CBS_KUR k,CBS_DOVIZ_KODLARI d
        WHERE k.dvz=d.doviz_kodu;
        --AND k.DVZ IN ('USD','EUR','TRY','GBP','CHF','RUB','KZT');
    ELSE
        OPEN pc_ref FOR SELECT '-' FROM dual;
    END IF;
    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        ls_returncode:= '999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetExchangeTranRate
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Exchange Tran Rate
******************************************************************************/
FUNCTION GetExchangeTranRate(ps_trantype IN VARCHAR2,
                              pn_musterino IN VARCHAR2,
                              pn_amount IN VARCHAR2,
                             ps_amountcurr     IN VARCHAR2,
                             ps_foreigncurr     IN VARCHAR2,
                             ps_rezervationno     IN VARCHAR2,
                              pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     ln_amount       NUMBER;

     ln_fromamount     NUMBER;
     ln_tax_kambiyo     NUMBER;
     ln_total_amount NUMBER;

     ls_destcurr   VARCHAR2(3);
     ls_destcurrname VARCHAR2(100);
     ln_desccurrBuyrate NUMBER;
     ln_desccurrSellrate NUMBER;
     ln_destamount     NUMBER;
     ln_rezamount     NUMBER;
     ErrorDifferentAmount    EXCEPTION;
     ErrorDifferentCurrency    EXCEPTION;
BEGIN
    ln_amount:=TO_NUMBER(pn_amount,'99999999999.99');
    IF ps_rezervationno IS NOT NULL THEN
       SELECT r.DOVIZ, r.MUSTERI_KUR, r.MUSTERI_KUR,d.ACIKLAMA,r.TUTAR
       INTO ls_destcurr , ln_desccurrBuyrate,ln_desccurrSellrate,ls_destcurrname,ln_rezamount
       FROM CBS_VW_KUR_REZERVASYON r,CBS_DOVIZ_KODLARI d
       WHERE r.REZERVASYON_NO=TO_NUMBER(ps_rezervationno)
       AND d.DOVIZ_KODU=r.DOVIZ
       AND d.DOVIZ_KODU=ps_foreigncurr
       AND r.MUSTERI_NO=pn_musterino;

       IF ln_rezamount!=ln_amount THEN
             RAISE ErrorDifferentAmount;
       END IF;

       IF ps_foreigncurr!=ls_destcurr THEN
             RAISE ErrorDifferentCurrency;
       END IF;

       IF ps_trantype='A' THEN-- alis
           ln_destamount:=ln_amount;
           ln_fromamount:=ln_amount*ln_desccurrBuyrate;
       ELSE--SATIS
           ln_destamount:=ln_amount;
           ln_fromamount:=ln_amount*ln_desccurrSellrate;
       END IF;

    ELSE

        SELECT DVZ, DVZALIS, DVZSATIS, ACIKLAMA
        INTO ls_destcurr , ln_desccurrBuyrate,ln_desccurrSellrate,ls_destcurrname
        FROM CBS_KUR k,CBS_DOVIZ_KODLARI d
        WHERE k.dvz=d.doviz_kodu
        AND k.DVZ=ps_foreigncurr;
        IF ps_trantype='A' THEN-- alis
            ln_destamount:=Pkg_Kur.YUVARLA(ps_foreigncurr,Pkg_Kur.doviz_doviz_karsilik(ps_amountcurr,ps_foreigncurr,NULL,ln_amount,1,NULL,NULL,'O','S'));
            ln_fromamount:=Pkg_Kur.YUVARLA(Pkg_Genel.LC_al,Pkg_Kur.doviz_doviz_karsilik(ls_destcurr,Pkg_Genel.LC_al,NULL,ln_destamount,1,NULL,NULL,'O','S'));
        ELSE--S : satis
            ln_destamount:=Pkg_Kur.YUVARLA(ps_foreigncurr,Pkg_Kur.doviz_doviz_karsilik(ps_amountcurr,ps_foreigncurr,NULL,ln_amount,1,NULL,NULL,'O','A'));
            ln_fromamount:=Pkg_Kur.YUVARLA(Pkg_Genel.LC_al,Pkg_Kur.doviz_doviz_karsilik(ls_destcurr,Pkg_Genel.LC_al,NULL,ln_destamount,1,NULL,NULL,'O','A'));
        END IF;

    END IF;

    OPEN pc_ref FOR
         SELECT
             ls_destcurr,
             ls_destcurrname,
             ROUND(ln_desccurrBuyrate,4),
             ROUND(ln_desccurrSellrate,4),
             ROUND(ln_fromamount,2),
             ROUND(ln_destamount,2),
             Pkg_Int.IntCalculateParity(ps_amountcurr,ps_foreigncurr)
         FROM dual;
    RETURN ls_returncode;
EXCEPTION
         WHEN ErrorDifferentAmount THEN
              OPEN pc_ref FOR
                 SELECT
                     ls_destcurr,
                     ls_destcurrname,
                     ln_desccurrBuyrate,
                     ln_desccurrSellrate,
                     ln_fromamount,
                     ln_destamount
                 FROM dual;
               RETURN '404';
         WHEN ErrorDifferentCurrency THEN
              OPEN pc_ref FOR
                 SELECT
                     ls_destcurr,
                     ls_destcurrname,
                     ln_desccurrBuyrate,
                     ln_desccurrSellrate,
                     ln_fromamount,
                     ln_destamount
                 FROM dual;
               RETURN '405';
         WHEN OTHERS THEN
               Log_At(SQLERRM);
               RETURN '444';
END;

/******************************************************************************
   NAME        : FUNCTION GetLoanAccount
   Prepared By : Almas Nurhozhaev
   Date        : 06.06.2008
   Purpose     : Get Loan Account
******************************************************************************/
FUNCTION GetLoanPaymentPlan(pn_AccountNo IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

    OPEN pc_ref FOR
    SELECT HESAP_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV, TAKSIT_FAIZ_ORANI, --FilippK MB-248 added TAKSIT_FAIZ_ORANI 06.06.2022
           TO_CHAR(VADE_TARIH,'YYYYMMDD'), KAL_ANAPARA, TAHSIL_EDILECEK_TAKSIT,
           DURUM_KODU, TO_CHAR(ODEME_TARIHI,'YYYYMMDD'), TO_CHAR(YARATILDIGI_TARIH,'YYYYMMDD'), --Bakdoolot IB-176 added  YARATILDIGI_TARIH 20.07.2022
	   (SELECT YEARLY_INT_RATE FROM CBS_VW_KREDI_HESAP_IZLEME WHERE HESAP_NO =pn_AccountNo) "interest_rate" --FilippK MB-417 27.09.2022
    FROM  CBS_HESAP_KREDI_TAKSIT
    WHERE HESAP_NO=TO_NUMBER(pn_AccountNo)
    ORDER BY VADE_TARIH;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        Log_At(SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
END;

/******************************************************************************
   NAME        : FUNCTION GetExchangeInfo
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Exchange Rates, Account Info,Limit Info will be returned
******************************************************************************/
FUNCTION GetExchangeInfo(p_option IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                            p_personid  IN VARCHAR2,
                           p_channelcd IN VARCHAR2,
                         p_trancd    IN VARCHAR2,
                         pd_tarih IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                         pc_ref2 OUT CursorReferenceType,
                         pc_ref3 OUT CursorReferenceType,
                         pc_ref4 OUT CursorReferenceType,
                         pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  exchangeRateException EXCEPTION;
  accountException  EXCEPTION;
  limitException    EXCEPTION;
  ratesDemandException EXCEPTION;
  ln_islemsekli VARCHAR2(20);
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

     --------------------------------Assign to pc_ref Exchange Rates---------------------------------------------
     ls_returncode := GetExchangeRates (p_option,p_customerid,p_personid,p_channelcd,p_trancd,pd_tarih,pc_ref,pc_ref2,pc_ref2,pc_ref2,pc_ref2);

    IF ls_returncode <> '000' THEN
        RAISE exchangeRateException;
    END IF;

      -----------------------------Assign to pc_ref2 LC Account Information--------------------------------------
     ls_returncode := GetTranAccounts (p_option,p_customerid,p_personid,p_channelcd,'LC',pc_ref2,pc_ref3,pc_ref3,pc_ref3,pc_ref3);

    IF ls_returncode <> '000' THEN
        RAISE accountException;
    END IF;

     ------------------------------Assign to pc_ref3 FC Account Information---------------------------------------
     ls_returncode := GetTranAccounts (p_option,p_customerid,p_personid,p_channelcd,'FC',pc_ref3,pc_ref4,pc_ref4,pc_ref4,pc_ref4);

      IF ls_returncode <> '000' THEN
       RAISE accountException;
      END IF;

     -----------------------------Check Customer Limit Info, Assign to pc_ref4 Customer Limit Information----------
     ls_returncode := corpint.pkg_cint_limit.GetLimitInfo(p_customerid,p_personid,p_trancd,p_channelcd,'',pc_ref4);

     ----------------If no data found, then raise exception------------------------------------------
     IF ls_returncode <> '000' THEN
       RAISE limitException;
     END IF;

     IF p_trancd <> 'FXORDER' THEN  --FXORDER Transaction does not need this control
        ls_returncode := Pkg_Soa_Common.IsRateDemandCustomer(p_customerid,pc_ref5);
        IF ls_returncode = '000' THEN
        ---------------If Reservation exists then get it-------------------------------------------------
        IF p_trancd = 'EXCHNGBUY' THEN
            ln_islemsekli := 'SATIS';
        ELSIF     p_trancd = 'EXCHNGSELL' THEN
            ln_islemsekli := 'ALIS';
        END IF;

        ls_returncode :=  GetRateDemandInquiry(p_customerid,'','','','','',ln_islemsekli,pc_ref5);

        IF ls_returncode <> '000' THEN
            RAISE ratesDemandException;
        END IF;

        END IF;
     END IF;

     RETURN ls_returncode;
   ----------------------------------------Exception Part----------------------------------------------------------------
EXCEPTION
     WHEN exchangeRateException THEN
         RETURN ls_returncode;
     WHEN accountException THEN
         RETURN ls_returncode;
     WHEN limitException THEN
         RETURN ls_returncode;
     WHEN ratesDemandException THEN
        ls_returncode:='000';
        RETURN ls_returncode;
     WHEN OTHERS THEN
        ls_returncode:='999';
        Log_At('Pkg_Soa_Account.GetExchangeInfo',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetTranAccounts
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Transaction Account Info will be returned
******************************************************************************/
FUNCTION GetTranAccounts(p_option  IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                         p_personid  IN VARCHAR2,
                         p_channelcd IN VARCHAR2,
                         p_currcode IN VARCHAR2,
                         pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     noAccoutFound        EXCEPTION;
     ls_account_count NUMBER:=0;
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

             SELECT COUNT(*)
          INTO ls_account_count
          FROM CBS_vw_hesap_izleme a
          WHERE musteri_no = p_customerid
             AND durum_kodu = 'A'
             AND modul_tur_kod= 'CURRENT'
             AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
             AND DOVIZ_KODU=DECODE(p_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
             AND DOVIZ_KODU<>DECODE(p_currcode,'FC',Pkg_Genel.LC_al,'ALL')
             AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = p_personid);

      IF (ls_account_count= 0) THEN-- If account not found
          RAISE noAccoutFound;
      END IF;

     OPEN pc_ref FOR
     ---------------------------Own Account---------------------------------------------
      SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
               external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
       FROM CBS_vw_hesap_izleme a
       WHERE musteri_no = p_customerid
             AND durum_kodu = 'A'
             AND modul_tur_kod= 'CURRENT'
             AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
             AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
             AND DOVIZ_KODU=DECODE(p_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
             AND DOVIZ_KODU<>DECODE(p_currcode,'FC',Pkg_Genel.LC_al,'ALL')
             AND URUN_SINIF_KOD <> 'OVERBALANCE-LC'
             AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = p_personid)
     UNION
     -----------------------------Related Account--------------------------------------------
     SELECT    Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
               hizl.MUSTERI_NO,
               hizl.ISIM_UNVAN,
               hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
               hizl.HESAP_NO,
               hizl.DOVIZ_KODU,
               NVL(hizl.BAKIYE,0),
               NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
               2 siralama ,TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.kisa_isim,
               hizl.external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) STATCD
        FROM CBS_JOIN_ACCOUNT jacc
        JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
        WHERE jacc.CUST_NO=TO_NUMBER(p_customerid)
        AND jacc.STATUS_CD='sACTIV'
        AND jacc.TRAN_TYPE='sTRAN'
        AND hizl.durum_kodu = 'A'
        AND hizl.modul_tur_kod= 'CURRENT'
        AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND hizl.URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND hizl.URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND hizl.DOVIZ_KODU=DECODE(p_currcode,'LC',Pkg_Genel.LC_al,hizl.DOVIZ_KODU)
        AND hizl.DOVIZ_KODU<>DECODE(p_currcode,'FC',Pkg_Genel.LC_al,'ALL')
        and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
        ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

    RETURN ls_returncode;

EXCEPTION
    WHEN noAccoutFound THEN
      ls_returncode:= '503';
    RETURN ls_returncode;
    WHEN OTHERS THEN
     ls_returncode:= '999';
      Log_At('Pkg_Soa_Account.GetTranAccounts',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetRateDemandInquiry
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Get Rezervations
******************************************************************************/
FUNCTION GetRateDemandInquiry(ps_customerid IN VARCHAR2,
                               ps_demandrezerv IN VARCHAR2,
                              ps_buysell  IN VARCHAR2,
                              ps_currcode IN VARCHAR2,
                              pd_startdate IN VARCHAR2,
                               pd_enddate IN VARCHAR2,
                              ps_islemsekli IN VARCHAR2,
                               pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ld_startdate  DATE;
    ld_enddate      DATE;
BEGIN
      IF pd_startdate IS NULL OR pd_enddate IS NULL THEN
          ld_startdate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
        ld_enddate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
      ELSE
           ld_startdate:=TO_DATE(pd_startdate,'YYYYMMDD');
         ld_enddate:=TO_DATE(pd_enddate,'YYYYMMDD');
      END IF;

      OPEN pc_ref FOR
        SELECT TO_CHAR(TARIH,'YYYYMMDD'), REZERVASYON_NO, MUSTERI_NO,ISLEM_TIPI,ISLEM_SEKLI, SUBE_KODU,DOVIZ, TUTAR, BAKIYE,
               MUSTERI_KUR, DURUM_KODU, MALIYET_KUR,
               Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(NVL(DOVIZ,Pkg_Genel.LC_AL),Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','S') BANK_ALIS_KURU,
               Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(NVL(DOVIZ,Pkg_Genel.LC_AL),Pkg_Genel.LC_AL,NULL,1,1,NULL,NULL,'O','A') BANK_SATIS_KURU
        FROM CBS_VW_KUR_REZERVASYON
        WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
        AND ISLEM_TIPI='M'
        AND BAKIYE<>0
        AND TARIH BETWEEN ld_startdate AND ld_enddate
        AND ISLEM_SEKLI=DECODE(NVL(ps_islemsekli,'-'),'ALIS','ALIS','SATIS','SATIS',ISLEM_SEKLI)
        ORDER BY TARIH;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        ls_returncode:='999';
        Log_At('Pkg_Soa_Account.GetRateDemandInquiry',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION ExchangeTransactions
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Limit Info, get Exchange Transaction
******************************************************************************/
FUNCTION ExchangeTransactions(p_option IN VARCHAR2,
                               p_customerid IN VARCHAR2,
                              p_personid IN VARCHAR2,
                              p_channelcd IN VARCHAR2,
                              p_trancd IN VARCHAR2,
                               p_trantype IN VARCHAR2,
                               p_amount IN VARCHAR2,
                              p_amountcurr     IN VARCHAR2,
                              p_foreigncurr     IN VARCHAR2,
                              p_rezervationno     IN VARCHAR2,
                               pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    limitException EXCEPTION;
    exchangeTranException EXCEPTION;
    ln_fxRates VARCHAR2(100);
    ln_usdRates NUMBER;
    ln_eurRates NUMBER;
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;

        FOR i IN (SELECT CBS_KUR.DVZ,
                DECODE(p_trantype,'A',DVZSATIS,'S',DVZALIS) RATE,
                CBS_KUR.EFALIS,
                CBS_KUR.EFSATIS,
                CBS_DOVIZ_KODLARI.ACIKLAMA
                FROM CBS_KUR,CBS_DOVIZ_KODLARI
                WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                AND CBS_KUR.DVZ IN ('USD','EUR')
                ORDER BY SIRA_NO) LOOP
            IF i.dvz = 'USD' THEN
                ln_usdRates := i.RATE;
            ELSIF i.dvz = 'EUR' THEN
                ln_eurRates := i.RATE;
            END IF;
        END LOOP;

        ln_fxRates := REPLACE(ln_usdRates||';'||ln_eurRates,'','.');

                    ----------------------Check Limit and Assign it to pc_ref----------------------------------------------------
                ls_returncode := corpint.pkg_cint_limit.CheckLimit(p_customerid,p_trancd,p_amount,p_personid,p_channelcd,ln_fxRates,p_amountcurr,pc_ref);

                IF ls_returncode <> '000' THEN
                   RAISE limitException;
                END IF;

                ----------------------Get Exchange Tran Rate and Assign it to pc_ref2--------------------------------
                ls_returncode := GetExchangeTranRate(p_trantype,p_customerid,p_amount,p_amountcurr,p_foreigncurr,p_rezervationno,pc_ref2);

                IF ls_returncode <> '000' THEN
                   RAISE exchangeTranException;
                END IF;

              RETURN ls_returncode;
EXCEPTION
  WHEN limitException THEN
      RETURN ls_returncode;
  WHEN exchangeTranException THEN
      RETURN ls_returncode;
  WHEN OTHERS THEN
       Log_At('pkg_soa_inquiry.ExchangeTransactions',SQLERRM);
      RAISE_APPLICATION_ERROR(-20100,SQLERRM);
      RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION CallExchangeTran
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Limit Info, get Exchange Transaction
******************************************************************************/
FUNCTION CallExchangeTran(p_option IN VARCHAR2,
                          p_customerid IN VARCHAR2,
                          p_personid IN VARCHAR2,
                          p_channelcd IN VARCHAR2,
                          p_trancd IN VARCHAR2,
                          p_trantype IN VARCHAR2,
                          p_fromaccount IN VARCHAR2,
                          p_toaccount IN VARCHAR2,
                          p_amount IN VARCHAR2,
                          p_amountcurr     IN VARCHAR2,
                          p_rate IN VARCHAR2,
                          p_rezervationno     IN VARCHAR2,
                          p_description IN VARCHAR2,
                          p_totalamount IN VARCHAR2,
                          p_expence   IN VARCHAR2,
                          p_statisticcode IN VARCHAR2,
                          pc_ref OUT CursorReferenceType,
                          pc_ref2 OUT CursorReferenceType,
                          pc_ref3 OUT CursorReferenceType,
                          pc_ref4 OUT CursorReferenceType,
                          pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';

    accountException EXCEPTION;
    FxBuySellTranException EXCEPTION;
    LimitUpadateException EXCEPTION;
    ln_fxRates VARCHAR2(100);
    ln_usdRates NUMBER;
    ln_eurRates NUMBER;
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

        FOR i IN (SELECT CBS_KUR.DVZ,
                DECODE(p_trantype,'A',DVZSATIS,'S',DVZALIS) RATE,
                CBS_KUR.EFALIS,
                CBS_KUR.EFSATIS,
                CBS_DOVIZ_KODLARI.ACIKLAMA
                FROM CBS_KUR,CBS_DOVIZ_KODLARI
                WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                AND CBS_KUR.DVZ IN ('USD','EUR')
                ORDER BY SIRA_NO) LOOP
            IF i.dvz = 'USD' THEN
                ln_usdRates := i.RATE;
            ELSIF i.dvz = 'EUR' THEN
                ln_eurRates := i.RATE;
            END IF;
        END LOOP;

        /*FOR i IN (

          SELECT CBS_KUR.DVZ,
                 CBS_KUR.DVZALIS,
                 CBS_KUR.DVZSATIS,
                 CBS_KUR.EFALIS,
                 CBS_KUR.EFSATIS,
                 CBS_DOVIZ_KODLARI.ACIKLAMA
                 FROM CBS_KUR,CBS_DOVIZ_KODLARI
                 WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                 AND CBS_KUR.DVZ IN ('USD','EUR')
                 ORDER BY SIRA_NO)
        LOOP
           IF i.dvz = 'USD' THEN
                  ln_usdRates := i.DVZALIS;
               ELSIF i.dvz = 'EUR' THEN
                  ln_eurRates := i.DVZALIS;
               END IF;
        END LOOP;*/

        ln_fxRates := ln_usdRates||';'||ln_eurRates;
         -------------------------------Check the Customer Account-----------------
         ls_returncode := Pkg_Soa_Inquiry.HesapMusteriKontrol(p_fromaccount,p_customerid,pc_ref);

         IF ls_returncode <> '000' THEN
                   RAISE accountException;
         END IF;

        --------------------------------Call FXBuySellTransaction------------------
         ls_returncode := Pkg_Soa_Transaction.FXBuySell(p_trantype,p_fromaccount,p_amountcurr,p_rate,p_amount,p_toaccount,p_statisticcode,p_description,p_rezervationno,p_expence,p_totalamount,pc_ref2);
        IF ls_returncode <> '000' THEN
                   RAISE FxBuySellTranException;
         END IF;

         ------------------------------Update Limit after transaction-------------
        ls_returncode := corpint.pkg_cint_limit.UpdateLimit(p_customerid,p_trancd,p_amount,p_amountcurr,p_personid,p_channelcd,ln_fxRates,pc_ref);

        IF ls_returncode <> '000' THEN
                   RAISE LimitUpadateException;
         END IF;
    RETURN ls_returncode;
EXCEPTION
  WHEN accountException THEN
      RETURN ls_returncode;
  WHEN FxBuySellTranException THEN
      RETURN ls_returncode;
  WHEN LimitUpadateException THEN
      RETURN ls_returncode;
  WHEN OTHERS THEN
       Log_At('pkg_soa_inquiry.CallExchangeTran',SQLERRM);
      RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION HesapMusteriKontrol
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Check Customer accounts
******************************************************************************/
FUNCTION HesapMusteriKontrol(pn_accountNo  IN VARCHAR2,
                             pn_customerNo IN VARCHAR2,
                             pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    ls_count NUMBER:=0;
    ls_count1 NUMBER:=0;
BEGIN
    OPEN pc_ref FOR SELECT SYSDATE FROM dual;

    SELECT COUNT(*)
    INTO ls_count
    FROM CBS_vw_hesap_izleme a
    WHERE a.HESAP_NO = TO_NUMBER(pn_accountNo)
    AND a.MUSTERI_NO = TO_NUMBER(pn_customerNo)
    AND a.DURUM_KODU = 'A';

    IF(ls_count = 0) THEN
        SELECT COUNT(*)
        INTO ls_count1
        FROM CBS_JOIN_ACCOUNT
        WHERE REL_ACCOUNT = TO_NUMBER(pn_accountNo)
        AND CUST_NO = TO_NUMBER(pn_customerNo);

        IF (ls_count1 = 0) THEN
           ls_returncode:='432';
        END IF;
    END IF;

    IF Pkg_Hesap.BadListFlag(pn_accountNo)='E' THEN
       ls_returncode:='431';
    END IF;

    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetArbitrajeInfo
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Controls Arbitraje, gets Account Info,Limit Info
******************************************************************************/
FUNCTION  GetArbitrajeInfo(p_option IN VARCHAR2,
                            p_customerid IN VARCHAR2,
                              p_personid  IN VARCHAR2,
                             p_channelcd IN VARCHAR2,
                           p_trancd    IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                           pc_ref4 OUT CursorReferenceType,
                           pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  arbitrajeControlException EXCEPTION;
  arbitrajeRateException EXCEPTION;
  accountException  EXCEPTION;
  limitException    EXCEPTION;
  ln_rubRates VARCHAR2(100); --ernestk 21042014 cqdb00000620 variable to hold RUB rates
  ln_usdRates VARCHAR2(100);
  ln_eurRates VARCHAR2(100);
  ln_fxRates VARCHAR2(100);
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

     --------------------------------Check for customer FC account, it must be more than 2---------------------------------------------
       ls_returncode := Pkg_Soa_Common.ArbitrageControl(p_customerid,pc_ref,pc_ref2,pc_ref2,pc_ref2,pc_ref2);

       IF ls_returncode <> '000' THEN
        RAISE arbitrajeControlException;
       END IF;

      -----------------------------Assign to pc_ref2 Arbitrafe Rates--------------------------------------------------------------------
       ls_returncode := Pkg_Soa_Inquiry.GetArbitrageRates(p_customerid,pc_ref,pc_ref3,pc_ref3,pc_ref3,pc_ref3);

      IF ls_returncode <> '000' THEN
       RAISE arbitrajeRateException;
      END IF;

     ------------------------------Assign to pc_ref3 FC Account Information---------------------------------------
     ls_returncode := GetTranAccounts (p_option,p_customerid,p_personid,p_channelcd,'FC',pc_ref2,pc_ref4,pc_ref4,pc_ref4,pc_ref4);

      IF ls_returncode <> '000' THEN
       RAISE accountException;
      END IF;

      FOR i IN (
           SELECT CBS_KUR.DVZ,
                               CBS_KUR.DVZALIS,
                             CBS_KUR.DVZSATIS,
                             CBS_KUR.EFALIS,
                             CBS_KUR.EFSATIS,
                             CBS_DOVIZ_KODLARI.ACIKLAMA
                       FROM CBS_KUR,CBS_DOVIZ_KODLARI
                       WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                       AND CBS_KUR.DVZ IN ('USD', 'EUR', 'RUB') --ernestk 21042014 cqdb00000620 added RUB currency
                       ORDER BY SIRA_NO)
        LOOP
           IF i.dvz = 'USD' THEN
                  ln_usdRates := i.DVZALIS;
               ELSIF i.dvz = 'EUR' THEN
                  ln_eurRates := i.DVZALIS;
           ELSIF I.DVZ = 'RUB' THEN        --ernestk 21042014 cqdb00000620 fetch RUB rates
                ln_rubRates   := I.DVZALIS; --ernestk 21042014 cqdb00000620 fetch RUB rates
               END IF;
        END LOOP;

    ln_fxRates := ln_usdRates||';'||ln_eurRates||';'||ln_rubRates;--ernestk 21042014 cqdb00000620 added RUB rates

     -----------------------------Check Customer Limit Info, Assign to pc_ref4 Customer Limit Information----------
     ls_returncode := corpint.pkg_cint_limit.GetLimitInfo(p_customerid,p_personid,p_trancd,p_channelcd,ln_fxRates,pc_ref3);

     ----------------If no data found, then raise exception------------------------------------------
     IF ls_returncode <> '000' THEN
       RAISE limitException;
      END IF;

    RETURN ls_returncode;
EXCEPTION
     WHEN arbitrajeControlException THEN
         RETURN ls_returncode;
     WHEN arbitrajeRateException THEN
         RETURN ls_returncode;
     WHEN limitException THEN
         RETURN ls_returncode;
     WHEN OTHERS THEN
        ls_returncode:='999';
        Log_At('Pkg_Soa_inquiry.GetArbitrajeInfo',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME       : FUNCTION GetArbitrageRates
   Created By : Almas Nurhozhaev
   Date       : 07.07.2008
   Purpose    : Get Arbitrage Rates
******************************************************************************/
FUNCTION GetArbitrageRates(ps_customerid IN VARCHAR2,
                           pc_ref OUT CursorReferenceType,
                           pc_ref2 OUT CursorReferenceType,
                           pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                             pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
BEGIN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;

      OPEN pc_ref FOR
          SELECT * FROM
          (
          SELECT 1 SIRALAMA, Pkg_Int.IntCalculateParity('USD','EUR'), 'USD###EUR', 'USD', 'EUR' FROM DUAL
          UNION
          SELECT 2 SIRALAMA, Pkg_Int.IntCalculateParity('EUR','USD'), 'EUR###USD', 'EUR', 'USD' FROM DUAL
          UNION
          SELECT 3 SIRALAMA, Pkg_Int.IntCalculateParity('USD','GBP'), 'USD###GBP', 'USD', 'GBP' FROM DUAL
          UNION
          SELECT 4 SIRALAMA, Pkg_Int.IntCalculateParity('GBP','USD'), 'GBP###USD', 'GBP', 'USD' FROM DUAL
          UNION
          SELECT 5 SIRALAMA, Pkg_Int.IntCalculateParity('USD','CHF'), 'USD###CHF', 'USD', 'CHF' FROM DUAL
          UNION
          SELECT 6 SIRALAMA, Pkg_Int.IntCalculateParity('CHF','USD'), 'CHF###USD', 'CHF', 'USD' FROM DUAL
          UNION
          SELECT 7 SIRALAMA, Pkg_Int.IntCalculateParity('USD','TRY'), 'USD###TRY', 'USD', 'TRY' FROM DUAL
          UNION
          SELECT 8 SIRALAMA, Pkg_Int.IntCalculateParity('TRY','USD'), 'TRY###USD', 'TRY', 'USD' FROM DUAL
          UNION
          SELECT 9 SIRALAMA, Pkg_Int.IntCalculateParity('USD','RUB'), 'USD###RUB', 'USD', 'RUB' FROM DUAL
          UNION
          SELECT 10 SIRALAMA, Pkg_Int.IntCalculateParity('RUB','USD'), 'RUB###USD', 'RUB', 'USD' FROM DUAL
          UNION
          SELECT 11 SIRALAMA, Pkg_Int.IntCalculateParity('USD','KZT'), 'USD###KZT', 'USD', 'KZT' FROM DUAL
          UNION
          SELECT 12 SIRALAMA, Pkg_Int.IntCalculateParity('KZT','USD'), 'KZT###USD', 'KZT', 'USD' FROM DUAL
          )
          ORDER BY SIRALAMA;

   RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION CheckArbitraje
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Controls Arbitraje, gets Account Info,Limit Info
******************************************************************************/
FUNCTION CheckArbitraje(p_option IN VARCHAR2,
                        p_customerid IN VARCHAR2,
                        p_personid  IN VARCHAR2,
                        p_channelcd IN VARCHAR2,
                        p_trancd    IN VARCHAR2,
                        p_toaccount IN VARCHAR2,
                        p_fromaccount IN VARCHAR2,
                        p_toaccountcurr IN VARCHAR2,
                        p_fromaccountcurr IN VARCHAR2,
                        p_amount     IN VARCHAR2,
                        p_amountcurr  IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  parityControlException EXCEPTION;
  parityException EXCEPTION;
  amountException EXCEPTION;
  ln_amount NUMBER := TO_NUMBER(p_amount,'99999999999.99');
   --aisuluukas 14072015 cqdb000001338 temporary ref cursor to store output of GetParity function
  temp_ref CursorReferenceType;
  --aisuluukas 14072015 cqdb000001338 temporary string to store return of GetParity function
  temp_returncode VARCHAR2(3):='000';
  --aisuluukas 14072015 cqdb000001338 first field of pc_ref2 containing amount
  amount NUMBER(11,2);
  --aisuluukas 14072015 cqdb000001338 second field of pc_ref2 containing calculated parity
  amountParity NUMBER(11,2);
BEGIN
         OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

     --------------------------------Check for customer parity---------------------------------------------
       ls_returncode :=    Pkg_Soa_Common.ParityControl(p_fromaccountcurr,p_toaccountcurr,pc_ref);

       IF ls_returncode <> '000' THEN
        RAISE parityControlException;
       END IF;

      -----------------------------Assign to pc_ref2 Get Parity Functions Result--------------------------------------------------------------------
       ls_returncode := Pkg_Soa_Inquiry.GetParity(p_fromaccountcurr,p_toaccountcurr,p_amount,p_amountcurr,pc_ref2);

      IF ls_returncode <> '000' THEN
       RAISE parityException;
      END IF;

     ------------------------------Check for amount that Customer has in his/her account---------------------------------------------------
      --aisuluukas 14072015 cqdb000001338 if currency is not FC then check entered amount
      IF (p_amountcurr<>'FC') THEN
        ls_returncode := Pkg_Soa_Common.BakiyeYeterlimi(p_fromaccount,p_amount,pc_ref3);
      --aisuluukas 14072015 cqdb000001338 else fetch calculated amount from ref cursor and check it
      ELSE
        temp_returncode := Pkg_Soa_Inquiry.GetParity(p_fromaccountcurr,p_toaccountcurr,p_amount,p_amountcurr,temp_ref);
        FETCH temp_ref INTO amount, amountParity;
        ls_returncode := Pkg_Soa_Common.BakiyeYeterlimi(p_fromaccount,TO_CHAR(amountParity,'99999999999.99'),pc_ref3);
      END IF;

      IF ls_returncode <> '000' THEN
       RAISE amountException;
      END IF;

    RETURN ls_returncode;
EXCEPTION
     WHEN parityControlException THEN
         RETURN ls_returncode;
     WHEN parityException THEN
         RETURN ls_returncode;
     WHEN amountException THEN
         RETURN ls_returncode;
     WHEN OTHERS THEN
        ls_returncode:='999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        Log_At('Pkg_Soa_inquiry.CheckArbitraje',SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetParity
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Get parity
******************************************************************************/
FUNCTION GetParity(p_fromaccount IN VARCHAR2,
                   p_toaccount IN VARCHAR2,
                   p_amount IN VARCHAR2,
                   p_amountcurreny IN VARCHAR2,
                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
        ls_returncode VARCHAR2(3):='000';
        ps_temp VARCHAR2(100);
BEGIN

    OPEN pc_ref FOR
    SELECT SYSDATE FROM dual;

    IF (p_amountcurreny = 'LC' ) THEN
    ps_temp := p_fromaccount;
    ELSE
    ps_temp := p_toaccount;
    END IF;

    IF ( Pkg_Kur_Rezervasyon.sf_base_doviz_hangisi(p_fromaccount,p_toaccount) = ps_temp) THEN
        OPEN pc_ref FOR
        SELECT
        TO_NUMBER(p_amount,'99999999999.99'),
        ROUND(TO_NUMBER(p_amount,'99999999999.99') * ROUND(Pkg_Soa_Common.IntCalculateParity(p_fromaccount,p_toaccount),5),2)
        FROM DUAL;
    ELSE
        OPEN pc_ref FOR
        SELECT
        TO_NUMBER(p_amount,'99999999999.99'),
        ROUND(TO_NUMBER(p_amount,'99999999999.99') / ROUND(Pkg_Soa_Common.IntCalculateParity(p_fromaccount,p_toaccount),5),2)
        FROM DUAL;
    END IF;

    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION CallArbitTran
   Prepared By : Almas Nurhozhaev
   Date        : 07.07.2008
   Purpose     : Checks for Customer Account, Calls Arbitraje Transaction, updates limits
******************************************************************************/
FUNCTION  CallArbitTran(p_option IN VARCHAR2,
                        p_customerid IN VARCHAR2,
                        p_personid  IN VARCHAR2,
                        p_channelcd IN VARCHAR2,
                        p_trancd    IN VARCHAR2,
                        p_toaccount IN VARCHAR2,
                        p_fromaccount IN VARCHAR2,
                        p_toaccountcurr IN VARCHAR2,
                        p_fromaccountcurr IN VARCHAR2,
                        p_parity  IN VARCHAR2,
                        p_toamount IN VARCHAR2,
                        p_fromamount IN VARCHAR2,
                        pc_ref OUT CursorReferenceType,
                        pc_ref2 OUT CursorReferenceType,
                        pc_ref3 OUT CursorReferenceType,
                        pc_ref4 OUT CursorReferenceType,
                        pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  accountException EXCEPTION;
  MakeArbitrageException EXCEPTION;
  LimitUpadateException EXCEPTION;
  LimitCheckException EXCEPTION;
  ln_amount VARCHAR2(100);
  ln_rubRates NUMBER;--ernestk 21042014 cqdb00000620 variable to hold RUB rates
  ln_usdRates NUMBER;
  ln_eurRates NUMBER;
  ln_fxRates VARCHAR2(100);
BEGIN
         OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

        FOR i IN (SELECT CBS_KUR.DVZ,
                         CBS_KUR.DVZALIS,
                         CBS_KUR.DVZSATIS,
                         CBS_KUR.EFALIS,
                         CBS_KUR.EFSATIS,
                         CBS_DOVIZ_KODLARI.ACIKLAMA
                   FROM CBS_KUR,CBS_DOVIZ_KODLARI
                   WHERE CBS_KUR.dvz=CBS_DOVIZ_KODLARI.doviz_kodu
                   AND CBS_KUR.DVZ IN ('USD', 'EUR', 'RUB') --ernestk 21042014 cqdb00000620 added RUB currency
                   ORDER BY SIRA_NO)
        LOOP
           IF i.dvz = 'USD' THEN
                  IF (p_fromaccountcurr=i.dvz) THEN ln_usdRates := i.DVZALIS; ELSE ln_usdRates := i.DVZSATIS; END IF;

               ELSIF i.dvz = 'EUR' THEN
                  IF (p_fromaccountcurr=i.dvz) THEN ln_eurRates := i.DVZALIS; ELSE ln_eurRates := i.DVZSATIS; END IF;
           --B-O-M ernestk 21042014 cqdb00000620 added RUB check
           ELSIF i.dvz = 'RUB' THEN
               IF (p_fromaccountcurr = i.dvz) THEN
                    ln_rubRates   := i.DVZALIS;
               ELSE
                    ln_rubRates   := i.DVZSATIS;
               END IF;
           --E-O-M ernestk 21042014 cqdb00000620 added RUB check
           END IF;
        END LOOP;

    ln_fxRates := REPLACE(ln_usdRates||';'||ln_eurRates||';'||ln_rubRates,',','.');--ernestk 21042014 cqdb00000620 added RUB rates

     -------------------------------Check Limit and Assign it to pc_ref----------------------------------------------------
        --ls_returncode := corpint.pkg_cint_limit.CheckLimit(p_customerid,p_trancd,p_fromamount,p_personid,p_channelcd,REPLACE(ln_fxRates,',','.'),p_fromaccountcurr,pc_ref4);
        ls_returncode := corpint.pkg_limit.CheckLimit(p_customerid,p_trancd,p_fromamount,p_personid,p_channelcd,ln_fxRates,p_fromaccountcurr,pc_ref4);

        IF ls_returncode <> '000' THEN
            RAISE LimitCheckException;
        END IF;

     --------------------------------Check the Customer Account------------------------------------
         ls_returncode := Pkg_Soa_Inquiry.HesapMusteriKontrol(p_fromaccount,p_customerid,pc_ref);

        IF ls_returncode <> '000' THEN
            RAISE accountException;
        END IF;

      --------------------------------Call FXBuySellTransaction------------------------------------
        ls_returncode := Pkg_Soa_Transaction.MakeArbitrage(p_fromaccount,p_toaccount,p_fromaccountcurr,p_toaccountcurr,p_parity,p_fromamount,p_toamount,pc_ref2);

        IF ls_returncode <> '000' THEN
            RAISE MakeArbitrageException;
        END IF;

      ------------------------------Update Limit after transaction----------------------------------
        ls_returncode := corpint.pkg_limit.UpdateLimit(p_customerid,p_trancd,p_fromamount,p_fromaccountcurr,p_personid,p_channelcd,ln_fxRates,pc_ref3);

        IF ls_returncode <> '000' THEN
            RAISE LimitUpadateException;
        END IF;

    RETURN ls_returncode;
EXCEPTION
     WHEN LimitCheckException THEN
         RETURN ls_returncode;
     WHEN accountException THEN
         RETURN ls_returncode;
     WHEN MakeArbitrageException THEN
         RETURN ls_returncode;
     WHEN LimitUpadateException THEN
         RETURN ls_returncode;
     WHEN OTHERS THEN
        ls_returncode:='999';
        Log_At('Pkg_Soa_inquiry.CallArbitrajeTran',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
   RETURN ls_returncode;
END;

/******************************************************************************
   NAME          : FUNCTION GetTranStatement
   Prepared By   : Almas Nurhozhaev
   Date          : 16.07.2008
   Purpose       : Get Transaction Statementt
******************************************************************************/
FUNCTION GetTranStatement(pn_txno IN VARCHAR2,
                           pn_custno IN VARCHAR2,
                           pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode                      VARCHAR2(3):='000';
  ln_txno                             NUMBER;
  ln_islemkod                            NUMBER;
  ld_tamamlanma                         DATE;
  NoStatementFound                     EXCEPTION;

    -------B-O-M chyngyzo cq1264 10122014 ------------------------
  ls_from_extaccno varchar2(16);
  ln_amount NUMBER;

  ls_from_biccode varchar2(16) := null;
  ls_from_bankname varchar2(200) := null;
  ls_to_biccode varchar2(16) := null;
  ls_to_bankname varchar2(200) := null;

  ls_from_account CBS_HESAP.HESAP_NO%TYPE;
  ls_to_account CBS_HESAP.HESAP_NO%TYPE;

  ls_payment_order_no VARCHAR2(16) := '';
  ls_tx_creator CBS_ISLEM.KAYIT_KULLANICI_KODU%TYPE;
  ld_maturity_date DATE;

  ls_eft_kodu CBS_BOLUM.EFT_KODU%TYPE;
  -------E-O-M chyngyzo cq1264 10122014 ------------------------
BEGIN
    ln_txno:=TO_NUMBER(pn_txno);

    SELECT islem_kod,TAMAMLANMA_TARIHI
    INTO ln_islemkod,ld_tamamlanma
    FROM CBS_ISLEM
    WHERE numara=ln_txno;

    IF ln_islemkod NOT IN ('6330', '2150', '1203','2102','4025','1202','7004','2130','1204','2012','2010','4003','3555','3556') THEN --ChyngyzO cq4960 28.12.15 2150 added --Bakdoolot ibc-29 added 6330 27.01.22
        --CBS-699 AdilK 03.08.2022 added 2010
       ls_returncode:='269';
       RAISE NoStatementFound;
    END IF;

    IF ln_islemkod='1203' THEN
     --INTERNAL MONEY TRANSFER

     -------B-O-M chyngyzo cq1264 10122014 ------------------------
      BEGIN
             SELECT  KAYIT_KULLANICI_KODU  INTO ls_tx_creator
             FROM CBS_ISLEM WHERE NUMARA =  ln_txno;

             IF ls_tx_creator = 'CINT_CALLER' THEN
                ls_payment_order_no := 'I' || pn_txno;
             ELSE
                ls_payment_order_no := pn_txno;
             END IF;

             SELECT VI.BORC_HESAP_NO, VI.ALACAK_HESAP_NO into ls_from_account, ls_to_account
             FROM CBS_VIRMAN_ISLEM vi
             WHERE VI.TX_NO = ln_txno;

             select B.EFT_KODU into ls_from_biccode
             from cbs_bolum b
             where B.KODU = Pkg_Hesap.HesapSubeAl(ls_from_account);

             select B.EFT_KODU into ls_to_biccode
             from cbs_bolum b
             where B.KODU = Pkg_Hesap.HesapSubeAl(ls_to_account);
     EXCEPTION
        WHEN OTHERS THEN
            ls_from_biccode := '';
            ls_to_biccode := '';
     END;
    -------E-O-M chyngyzo cq1264 10122014 ------------------------

         OPEN pc_ref FOR
            SELECT  TX_NO,
                    TO_CHAR(ld_tamamlanma,'DD/MM/YYYY') TRAN_DATE,
                    BORC_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)) BORCLU_ADI,
                    BORC_EXTERNAL_HESAP,
                    BORC_VERGI_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU,1,2) BORCLU_IIK,
                     '118'||ls_from_biccode BORCLU_BANKA, ---chyngyzo cq1264  10122014
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO))) BBANK_NAME,
                    ALACAK_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(ALACAK_HESAP_NO)) ALACAKLI_ADI,
                    ALACAK_EXTERNAL_HESAP,
                    ALACAK_VERGI_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU,3,2) ALACAK_IIK,
                     '118'||ls_to_biccode ALACAK_BANKA,---chyngyzo cq1264  10122014
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO))) ABANK_NAME,
                    DOVIZ_KODU,
                    TUTAR,
                    ACIKLAMA,
                    ISTATISTIK_KODU,
                    PREFIX_ISTATISTIK_KODU,
                    Pkg_Report.Number_To_Word_Eng( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
                    Pkg_Report.Number_To_Word_Rus( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_RUS,
                    '-' BCLASS,
                     NVL(REF_NO,  ls_payment_order_no) DOC_NO, ---chyngyzo cq1264 10122014  payment order number
                    ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022
                    CHARGE_AMOUNT,
                    PKG_MUSTERI.sf_OKPO_al(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)), ---chyngyzo cq1264 PAYER okpo code added
                    PKG_MUSTERI.SF_SOSYAL_FON_NO_AL(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)) ---chyngyzo cq1264 PAYER sosyal fon no added
             FROM CBS_VIRMAN_ISLEM
             WHERE  TX_NO=ln_txno;

    ELSIF ln_islemkod='7004' THEN
     --UTILITY PAYMENT
         OPEN pc_ref FOR
             SELECT TX_NO,
                     TO_CHAR(COLLECTION_DATE,'DD/MM/YYYY'),
                    ACCOUNT_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(CUSTOMER_NO) SENDER_NAME,
                    LPAD(Pkg_Hesap.External_HesapNo_Al(ACCOUNT_NO),9,'0'),
                    Pkg_Musteri.Sf_VergiNo_Al(CUSTOMER_NO) RNN,
                    SUBSTR(PREFIX_STATISTICAL_CODE,1,2),
                    Pkg_Genelkz.GetOurBICCode(BRANCH) BIC_CODE,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(BRANCH)) BANK_NAME,
                    COLLECTION_ACCOUNT_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(COLLECTION_ACCOUNT_NO)),
                    LPAD(Pkg_Hesap.External_HesapNo_Al(COLLECTION_ACCOUNT_NO),9,'0'),
                    Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(COLLECTION_ACCOUNT_NO)),
                    SUBSTR(PREFIX_STATISTICAL_CODE,3,2),
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(COLLECTION_ACCOUNT_NO)),
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(COLLECTION_ACCOUNT_NO))),
                    CURRENCY_CODE,
                    COLLECTION_AMOUNT,
                    EXPLANATION,
                    STATISTICAL_CODE,
                    PREFIX_STATISTICAL_CODE,
                    Pkg_Report.Number_To_Word_Eng( COLLECTION_AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_ENG,
                          Pkg_Report.Number_To_Word_Rus( COLLECTION_AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_RUS,
                    '-' BCLASS,
                    TX_NO DOC_NO,
                    ln_islemkod ":B2"--CBS-699 AdilK 03.08.2022
             FROM CBS_VW_COLLECTIONS
             WHERE  TX_NO=ln_txno
             AND CUSTOMER_NO=pn_custno;

    ELSIF ln_islemkod='2130' THEN
     --CARD PAYMENT
         OPEN pc_ref FOR
             SELECT TX_NO,
                     TO_CHAR(PAYMENT_DATE,'DD/MM/YYYY'),
                    FROM_ACCOUNT_NO,
                    FROM_NAME,
                    LPAD(Pkg_Hesap.External_HesapNo_Al(FROM_ACCOUNT_NO),9,'0'),
                    Pkg_Musteri.Sf_VergiNo_Al(FROM_CUSTOMER_NO) RNN,
                    Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO)),
                    FROM_BANK_CODE,
                    Pkg_Hesap.GetBankHQName(FROM_BANK_CODE) BANK_NAME,
                    '-',
                    TO_CARD_CUSTOMER_NAME,
                    TO_CARD_NO,
                    Pkg_Musteri.Sf_VergiNo_Al(TO_CARD_CUSTOMER_NO),
                    Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(TO_CARD_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(TO_CARD_CUSTOMER_NO)),
                    '-',--toBankCode,
                    '-',--ToBankName
                    CURRENCY_CODE,
                    AMOUNT,
                    PAYMENT_DESCRIPTION,
                    '-',--STATISTICAL_CODE,
                    '-',--PREFIX_STATISTICAL_CODE,
                    Pkg_Report.Number_To_Word_Eng( AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_ENG,
                          Pkg_Report.Number_To_Word_Rus( AMOUNT, CURRENCY_CODE) TUTAR_YAZI_ILE_RUS,
                    '-' BCLASS,
                    TX_NO DOC_NO,
                    ln_islemkod ":B2"--CBS-699 AdilK 03.08.2022
             FROM CBS_CARD_PAYMENT
             WHERE  TX_NO=ln_txno
             AND FROM_CUSTOMER_NO=pn_custno;

    -------B-O-M chyngyzo cq1264 10122014 ------------------------
    ELSIF ln_islemkod='3556' THEN
        --CLEARING INCOMING
        BEGIN
         select FROM_ACCOUNT_EXTERNAL_NUMBER, AMOUNT, TO_BANK_BIC, MATURITY_DATE
            into ls_from_extaccno, ln_amount, ls_to_biccode, ld_maturity_date
         FROM cbs_vw_clearing
         WHERE  YARATAN_TX_NO=ln_txno and ROWNUM = 1;

          select CM.FROM_BANKBICCODE, CM.FROM_BANKNAME,  CM.TO_BANKNAME
            into  ls_from_biccode, ls_from_bankname, ls_to_bankname
          from cbs_clearing_message cm
          where CM.FROM_ACCOUNT_EXTERNAL_NUMBER = ls_from_extaccno
                    and CM.AMOUNT = ln_amount
                    and CM.TO_BANKBICCODE = ls_to_biccode
                    and CM.MATURITY_DATE = ld_maturity_date
                    and ROWNUM = 1;

            EXCEPTION
                WHEN OTHERS  THEN
                    ls_from_biccode := ' ';
                    ls_to_bankname := ' ';
          END;

         OPEN pc_ref FOR
          SELECT  YARATAN_TX_NO,
             TO_CHAR(MATURITY_DATE,'DD/MM/YYYY'),
             ' ' BORC_HESAPNO,
             FROM_DESCRIPTION, --payer name
             FROM_ACCOUNT_EXTERNAL_NUMBER,
             FROM_RNN,
             ' ' ,
             nvl(ls_from_biccode, ' '), ---FROM BIC
               NVL(Pkg_Hesap.GetBankName(ls_from_biccode),ls_from_bankname), --FROM BANK NAME
             ' ' ALACAK_HESAP_NO,
             TO_NAME,
             TO_ACCOUNT_EXTERNAL_NUMBER,
             ' ' TO_RNN,
             ' ' ,
             TO_BANK_BIC,--TO BIC
              ls_to_bankname,-- TO BANK NAME
             ' ' TRAN_CURR,
             AMOUNT,
             EXPLANATION,
             CODE_OF_PAYMENT,
             ' ' ISTATISTIK_KOD,
             Pkg_Report.Number_To_Word_Eng(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE_ENG,
             Pkg_Report.Number_To_Word_Rus(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE,
             CODE_OF_PAYMENT,
             REF_NO,
             ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022
             CHARGE_AMOUNT,
             FROM_OKPO,
             FROM_SOCIAL_FUND_NUMBER
          FROM cbs_vw_clearing
      WHERE  YARATAN_TX_NO=ln_txno;
     -------E-O-M chyngyzo cq1264 10122014 ------------------------

    ELSIF ln_islemkod='2102' OR ln_islemkod='3555' THEN
    --CLEARING OUTGOING
    -------B-O-M chyngyzo cq1264 10122014 ------------------------
        BEGIN

            select B.EFT_KODU into ls_eft_kodu
            from cbs_vw_clearing cl
                left join
            cbs_hesap h on CL.FROM_ACCOUNT = h.hesap_no
                left join
            cbs_bolum b on H.SUBE_KODU = B.KODU
            where CL.YARATAN_TX_NO = ln_txno;

        EXCEPTION
            WHEN OTHERS THEN
              ls_eft_kodu := null;
        END;
    -------E-O-M chyngyzo cq1264 10122014 ------------------------

      OPEN pc_ref FOR
          /*SELECT  YARATAN_TX_NO,
         TO_CHAR(MATURITY_DATE,'DD/MM/YYYY'),
         ' ' BORC_HESAPNO,
         (decode(C.PAYMENT_TYPE, 'GROSS', '118'|| decode(ls_eft_kodu, null, B.EFT_KODU||' ', ls_eft_kodu||' ' ) , '') ) || Pkg_Musteri.Sf_Musteri_Adi(pn_custno), --chyngyzo cq1264 10122014
         pkg_hesap.External_HesapNo_Al(FROM_ACCOUNT),
         FROM_RNN,
         ' ' ,
         decode(C.PAYMENT_TYPE, 'GROSS', '118001' , '118'||B.EFT_KODU)  , --chyngyzo cq1264  10122014 'FROM BIC'
         'DEMIR KYRGYZ INTERNATIONAL BANK (DKIB)',----chyngyzo cq1264 'FROM BANK NAME'
         ' ' ALACAK_HESAP_NO,
         TO_NAME,
         TO_ACCOUNT_EXTERNAL_NUMBER,
         ' ' TO_RNN,
         '',
         LPAD(NVL(C.TO_BANK_BIC,0),9,'0'), --chyngyzo cq1264  10122014 'TO BIC'
         NVL(Pkg_Hesap.GetBankName(C.TO_BANK_BIC),' '), -- chyngyzo cq1264  10122014 'TO BANK NAME'
         ' ' TRAN_CURR,
         AMOUNT,--TRAN_AMOUNT,
         EXPLANATION,
         CODE_OF_PAYMENT,
         ' ' ISTATISTIK_KOD,
         Pkg_Report.Number_To_Word_Eng(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE_ENG,--chyngyzo cq1264 10122014 pkg_genel.lc_al added
         Pkg_Report.Number_To_Word_Rus(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE,--chyngyzo cq1264 10122014 pkg_genel.lc_al added
         CODE_OF_PAYMENT,
         nvl(trim(ref_no), ' ') DOC_NUM, --almasn 04112014 CQ864 IB UNDP project
         ln_islemkod ":B2", --CBS-699 AdilK 03.08.2022
         CHARGE_AMOUNT,
         C.FROM_OKPO, --chyngyzo cq1264 PAYER okpo code added
         C.FROM_SOCIAL_FUND_NUMBER --chyngyzo cq1264 PAYER sosyal fon no added
         FROM_ACCOUNT,--CBS-699 AdilK 03.08.2022
         PAYMENT_TYPE--CBS-699 AdilK 03.08.2022
       FROM cbs_vw_clearing C
      LEFT JOIN CBS_BOLUM B ON (C.BOLUM_KODU = B.KODU) --chyngyzo cq1264 10122014 left join added to get BIC CODE
      WHERE  YARATAN_TX_NO=ln_txno;*/
      --AND TO_NUMBER(pn_custno)=DECODE(URUN_TUR_KOD,'INCOMING',Pkg_Hesap.GetMusteriNoFromExternal(TO_ACCOUNT_EXTERNAL_NUMBER),Pkg_Hesap.GetMusteriNoFromExternal(FROM_ACCOUNT_EXTERNAL_NUMBER));
        SELECT  YARATAN_TX_NO,
         TO_CHAR(MATURITY_DATE,'DD/MM/YYYY'),
         ' ' BORC_HESAPNO,
         (decode(C.PAYMENT_TYPE, 'GROSS', '118'|| decode(ls_eft_kodu, null, B.EFT_KODU||' ', ls_eft_kodu||' ' ) , '') ) || Pkg_Musteri.Sf_Musteri_Adi(pn_custno), --chyngyzo cq1264 10122014
         pkg_hesap.External_HesapNo_Al(FROM_ACCOUNT),
         FROM_RNN,
         ' ' ,
         decode(C.PAYMENT_TYPE, 'GROSS', '118001' , '118'||B.EFT_KODU)  , --chyngyzo cq1264  10122014 'FROM BIC'
         'DEMIR KYRGYZ INTERNATIONAL BANK (DKIB)',----chyngyzo cq1264 'FROM BANK NAME'
         ' ' ALACAK_HESAP_NO,
         TO_NAME,
         TO_ACCOUNT_EXTERNAL_NUMBER,
         ' ' TO_RNN,
         '',
         LPAD(NVL(C.TO_BANK_BIC,0),9,'0'), --chyngyzo cq1264  10122014 'TO BIC'
         NVL(Pkg_Hesap.GetBankName(C.TO_BANK_BIC),' '), -- chyngyzo cq1264  10122014 'TO BANK NAME'
         ' ' TRAN_CURR,
         AMOUNT,--TRAN_AMOUNT,
         EXPLANATION,
         CODE_OF_PAYMENT,
         ' ' ISTATISTIK_KOD,
         Pkg_Report.Number_To_Word_Eng(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE_ENG,--chyngyzo cq1264 10122014 pkg_genel.lc_al added
         Pkg_Report.Number_To_Word_Rus(AMOUNT, PKG_GENEL.LC_AL) TUTAR_YAZI_ILE,--chyngyzo cq1264 10122014 pkg_genel.lc_al added
         CODE_OF_PAYMENT,
         nvl(trim(ref_no), ' ') DOC_NUM, --almasn 04112014 CQ864 IB UNDP project
         ln_islemkod ":B2", --CBS-699 AdilK 03.08.2022
         CHARGE_AMOUNT,
         C.FROM_OKPO, --chyngyzo cq1264 PAYER okpo code added
         C.FROM_SOCIAL_FUND_NUMBER --chyngyzo cq1264 PAYER sosyal fon no added
         FROM_ACCOUNT,--CBS-699 AdilK 03.08.2022
         PAYMENT_TYPE--CBS-699 AdilK 03.08.2022
       FROM cbs_vw_clearing C
      LEFT JOIN CBS_BOLUM B ON (C.BOLUM_KODU = B.KODU) --chyngyzo cq1264 10122014 left join added to get BIC CODE
      WHERE  YARATAN_TX_NO=ln_txno;
      
    ELSIF ln_islemkod IN ('4025') THEN
    --FX BUY
        OPEN pc_ref FOR
            SELECT  TX_NO,
                    TO_CHAR(ISLEM_TARIHI,'DD/MM/YYYY'),
                    MUSTERI_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(MUSTERI_NO),
                    pkg_hesap.External_HesapNo_Al(MUSTERI_HESAP_NO),
                    MUSTERI_VERGI_NO,
                    '-',
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(MUSTERI_HESAP_NO)) BORCLU_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(MUSTERI_HESAP_NO))) BBANK_NAME,
                    DTH_MUSTERI_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(DTH_MUSTERI_NO),
                    pkg_hesap.External_HesapNo_Al(MUSTERI_HESAP_NO),
                    DTH_MUSTERI_VERGI_NO,
                    '-',
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(DTH_MUSTERI_HESAP_NO)) BORCLU_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(DTH_MUSTERI_HESAP_NO))) BBANK_NAME,
                    DOVIZ_KODU,
                    DOVIZ_TUTARI,
                    ACIKLAMA,
                    '-',
                    '-',
                    Pkg_Report.Number_To_Word_Eng( DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
                    Pkg_Report.Number_To_Word_Rus( DOVIZ_TUTARI, DOVIZ_KODU) TUTAR_YAZI_ILE,
                    '' DOC_BCLASS,
                    TX_NO DOC_NUM,
                    ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022
                    KUR,
                    Pkg_Kur.yuvarla(Pkg_Genel.LC_al,DOVIZ_TUTARI*KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
                    ISLEM_SUBE
            FROM CBS_DTH_DOVIZ_SATIS_ISLEM
            WHERE  TX_NO=ln_txno;

    ELSIF ln_islemkod IN ('1202') THEN
    --FX SELL
        OPEN pc_ref FOR
            SELECT  TX_NO,
                    TO_CHAR(Pkg_Int_Account.GetTxDate(TX_NO),'DD/MM/YYYY'),
                    BORC_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(BORC_HESAP_NO)),
                    LPAD(BORC_EXTERNAL_HESAP,9,'0'),
                    BORC_VERGI_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,3,2),
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO)) BORCLU_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(BORC_HESAP_NO))) BBANK_NAME,
                    ALACAK_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(ALACAK_HESAP_NO)),
                    LPAD(ALACAK_EXTERNAL_HESAP,9,'0'),
                    ALACAK_VERGI_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,1,2),
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO)) BORCLU_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALACAK_HESAP_NO))) BBANK_NAME,
                    DOVIZ_KODU KUR_FCY,--CBS-699 AdilK 03.08.2022
                    TUTAR,
                    ACIKLAMA,
                    ISTATISTIK_KODU_ALIS,
                    ISTATISTIK_KODU_SATIS,
                    Pkg_Report.Number_To_Word_Eng( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
                    Pkg_Report.Number_To_Word_Rus( TUTAR, DOVIZ_KODU) TUTAR_YAZI_ILE,
                    '' DOC_BCLASS,
                    TX_NO DOC_NUM,
                    ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022
                    KUR,
                    Pkg_Kur.yuvarla(Pkg_Genel.LC_al,TUTAR*KUR) TAHSIL_ADILEN_TOPLAM_TUTAR,
                    '' ISLEM_SUBE,
                    DOVIZ_KODU KUR_FCY
        FROM CBS_DTH_TL_ODEME_ISLEM
        WHERE  TX_NO=ln_txno;

    ELSIF ln_islemkod IN ('1204') THEN
       --ARBITRAGE
        OPEN pc_ref FOR
            SELECT TX_NO,
                     TO_CHAR(ISLEM_TARIHI,'DD/MM/YYYY') TRAN_DATE,
                     ALIS_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(ALIS_HESAP_NO)) BORCLU_ADI,
                    DEBIT_EXTERNAL_ACCOUNT,
                    DEBIT_TAX_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU_ALIS,1,2) BORCLU_IIK,
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALIS_HESAP_NO)) BORCLU_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALIS_HESAP_NO))) BBANK_NAME,
                    SATIS_HESAP_NO,
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(SATIS_HESAP_NO)) ALACAKLI_ADI,
                    CREDIT_EXTERNAL_ACCOUNT,
                    CREDIT_TAX_NO,
                    SUBSTR(PREFIX_ISTATISTIK_KODU_SATIS,3,2) ALACAK_IIK,
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(SATIS_HESAP_NO)) ALACAK_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(SATIS_HESAP_NO))) ABANK_NAME,
                    ALIS_DOVIZ_KODU,
                    ALIS_TUTARI,
                    ACIKLAMA,
                    ISTATISTIK_KODU_ALIS,
                    PREFIX_ISTATISTIK_KODU_ALIS,
                    Pkg_Report.Number_To_Word_Eng( ALIS_TUTARI, ALIS_DOVIZ_KODU) TUTAR_YAZI_ILE_ALIS,
                          Pkg_Report.Number_To_Word_Rus( SATIS_TUTARI, SATIS_DOVIZ_KODU) TUTAR_YAZI_ILE_SATIS,
                    '-' BCLASS,
                    TX_NO DOC_NO,
                    ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022,
                    SATIS_DOVIZ_KODU sell_curr,--CBS-699 AdilK 03.08.2022
                    ALIS_DOVIZ_KODU buy_curr--CBS-699 AdilK 03.08.2022
        FROM CBS_ARBITRAJ_ISLEM
        WHERE  TX_NO=ln_txno;

    ELSIF ln_islemkod='2012' THEN
    --Incoming Money Transfer
              OPEN pc_ref FOR
             SELECT TX_NO,
                     TO_CHAR(ODEME_TARIHI,'DD/MM/YYYY'),
                    '-',--FROM_ACCOUNT_NO,
                    ACIKLAMA,--FROM_NAME,
                    '-',--LPAD(Pkg_Hesap.External_HesapNo_Al(FROM_ACCOUNT_NO),9,'0'),
                    '-',--Pkg_Musteri.Sf_VergiNo_Al(FROM_CUSTOMER_NO) RNN,
                    '-',--Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO)),
                    BOLUM_KODU,
                    Pkg_Hesap.GetBankHQName(BOLUM_KODU) BANK_NAME,
                    '-',
                    ALICI_MUSTERI_NO,
                    ALICI_HESAP_NO,
                    Pkg_Musteri.Sf_VergiNo_Al(ALICI_MUSTERI_NO),
                    Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(ALICI_MUSTERI_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(AlICI_MUSTERI_NO)),
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALICI_HESAP_NO)) ALACAK_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALICI_HESAP_NO))) ABANK_NAME,
                    'KZT',
                    ODEME_TUTARI,
                    ACIKLAMA,
                    '-',--STATISTICAL_CODE,
                    '-',--PREFIX_STATISTICAL_CODE,
                    Pkg_Report.Number_To_Word_Eng( ODEME_TUTARI, 'KZT') TUTAR_YAZI_ILE_ENG,
                          Pkg_Report.Number_To_Word_Rus( ODEME_TUTARI, 'KZT') TUTAR_YAZI_ILE_RUS,
                    '-' BCLASS,
                    TX_NO DOC_NO,
                    ln_islemkod ":B2"--CBS-699 AdilK 03.08.2022
             FROM CBS_YPHAVALE_GELEN_ODEME
             WHERE  TX_NO=ln_txno;
    ELSIF ln_islemkod='2010' THEN --CBS-699 AdilK 03.08.2022
              OPEN pc_ref FOR
             SELECT TX_NO,
                     TO_CHAR(VALOR_TARIHI,'DD/MM/YYYY'),
                    '-',--FROM_ACCOUNT_NO,
                    ACIKLAMA,--FROM_NAME,
                    '-',--LPAD(Pkg_Hesap.External_HesapNo_Al(FROM_ACCOUNT_NO),9,'0'),
                    '-',--Pkg_Musteri.Sf_VergiNo_Al(FROM_CUSTOMER_NO) RNN,
                    '-',--Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(FROM_CUSTOMER_NO)),
                    BOLUM_KODU,
                    Pkg_Hesap.GetBankHQName(BOLUM_KODU) BANK_NAME,
                    '-',
                    ALICI_MUSTERI_NO,
                    ALICI_HESAP_NO,
                    Pkg_Musteri.Sf_VergiNo_Al(ALICI_MUSTERI_NO),
                    --Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(ALICI_MUSTERI_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(AlICI_MUSTERI_NO)),
                    --Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALICI_HESAP_NO)) ALACAK_BANKA,
                    --Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(ALICI_HESAP_NO))) ABANK_NAME,
                    DOVIZ_KODU curr,
                    TUTAR amount,
                    ACIKLAMA,
                    '-',--STATISTICAL_CODE,
                    '-',--PREFIX_STATISTICAL_CODE,
                    '-' BCLASS,
                    TX_NO DOC_NO,
                    ln_islemkod ":B2"--CBS-699 AdilK 03.08.2022
             FROM cbs_yphavale_gelen_basvuru
             WHERE  TX_NO=ln_txno;    
    ELSIF ln_islemkod='4003' THEN
     --Outgoing Money Transfer Opening
         OPEN pc_ref FOR
             SELECT b.TX_NO,
                    TO_CHAR(a.VALOR_TARIHI,'DD/MM/YYYY'),
                    Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(a.BORCLU_HESAP_NO)),
                    '-',--a.FROM_NAME,
                    LPAD(Pkg_Hesap.External_HesapNo_Al(a.BORCLU_HESAP_NO),9,'0'),
                    Pkg_Musteri.Sf_VergiNo_Al(a.MUSTERI_NO) RNN,
                    Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.MUSTERI_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.MUSTERI_NO)),
                    a.GONDEREN_SUBE,
                    Pkg_Hesap.GetBankHQName(a.GONDEREN_SUBE) BANK_NAME,
                    '-',
                    a.MUH_BANK_MUSTERI_NO,
                    '-',--a.TO_CARD_NO,
                    Pkg_Musteri.Sf_VergiNo_Al(a.MUH_BANK_MUSTERI_NO),
                    Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.MUH_BANK_MUSTERI_NO))||Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.MUH_BANK_MUSTERI_NO)),
                    Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(a.MUH_BANK_HESAP_NO)) ALACAK_BANKA,
                    Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(a.MUH_BANK_HESAP_NO))) ABANK_NAME,
                    a.BORCLU_HESAP_NO FROM_ACC, --CBS-699 AdilK 03.08.2022
                    a.TRANSFER_DOVIZ_KODU,
                    a.TUTAR,
                    a.ACIKLAMA,
                    a.ISTATISTIK_KODU,
                    a.PREFIX_ISTATISTIK_KOD,
                    Pkg_Report.Number_To_Word_Eng( a.TUTAR, a.TRANSFER_DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
                          Pkg_Report.Number_To_Word_Rus( a.TUTAR, a.TRANSFER_DOVIZ_KODU) TUTAR_YAZI_ILE_RUS,
                    '-' BCLASS,
                    b.TX_NO DOC_NO,
                    ln_islemkod ":B2",--CBS-699 AdilK 03.08.2022
                    /*B-O-M chyngyzo cq509 07/09/2015*/
                    to_char(A.ACILIS_TARIHI, 'dd.mm.yyyy'),
                    substr(trim(A.OC_ISIM_ADRES_1) || trim(A.OC_ISIM_ADRES_2)  || A.OC_ISIM_ADRES_3, 1, 100 ) OC_ISIM_ADRES,
                    Pkg_Hesap.External_HesapNo_Al(a.BORCLU_HESAP_NO) OC_ACCOUNT_NO,
                    A.MUSTERI_NO OC_CUST_NO,
                    A.II_BIC,
                    PKG_SOA_INQUIRY.GetInterBankName(A.II_BIC) INTER_BANK_NAME,
                    A.AWI_BIC,
                    (select BANKA_ADI from CBS.CBS_BIC_KODLARI  where BIC_KODU=A.AWI_BIC) BEN_BANK_NAME,--CBS-849 Adilk
                    (select ULKE_ADI from CBS.CBS_BIC_KODLARI  where BIC_KODU=A.AWI_BIC) BEN_BANK_COUNTRY,--CBS-849 Adilk
                    pkg_tx4003.Bic_Ulkesi(A.AWI_BIC) BEN_BANK_COUNTRY,
                    A.BC_HESAP_NO_N BEN_ACC_NO,
                    substr(trim(A.BC_ISIM_ADRES_1) || trim(A.BC_ISIM_ADRES_2)  || A.BC_ISIM_ADRES_3, 1, 100 ) BC_ISIM_ADRES,
                    pkg_soa_inquiry.GetSwiftCommissionType(b.tx_no) COMM_TYPE,
                    PKG_MESSAGE.SPLIT(pkg_soa_inquiry.GetSwiftCommissionType(ln_txno),'###',0) ls_commType,--CBS-699 AdilK 03.08.2022
                    PKG_MESSAGE.SPLIT(pkg_soa_inquiry.GetSwiftCommissionType(ln_txno),'###',1) ln_fixed,--CBS-699 AdilK 03.08.2022
                    PKG_MESSAGE.SPLIT(pkg_soa_inquiry.GetSwiftCommissionType(ln_txno),'###',2) ln_proportional,--CBS-699 AdilK 03.08.2022
                    PKG_MESSAGE.SPLIT(pkg_soa_inquiry.GetSwiftCommissionType(ln_txno),'###',3) ln_cdf,--CBS-699 AdilK 03.08.2022
                    b.MASRAF_TOPLAMI alt_swift_com , --CBS-849 Adilk
                    (select DV_TUTAR from CBS_SATIR where FIS_ISLEM_NUMARA=ln_txno and HESAP_TUR_KODU='VS' and BANKA_ACIKLAMA like '%SALES TAX')  ln_salesTax,-- CBS-699 AdilK 03.08.2022
                    (select DOVIZ_KOD from CBS_SATIR where FIS_ISLEM_NUMARA=ln_txno and HESAP_TUR_KODU='VS' and BANKA_ACIKLAMA like '%SALES TAX') salesCurr, --CBS-849 Adilk
                    Pkg_Hesap.External_HesapNo_Al(a.MASRAF_KOMISYON_HESAP_NO) COMM_ACC_NO,
                    TRIM(b.RI_1 || b.RI_2 || b.RI_3 || b.RI_4),
                    /*E-O-M chyngyzo cq509 07/09/2015*/
                    '-' BC--CBS-699 AdilK 03.08.2022 Temp dum BC field not in prod yet
             FROM CBS_YPHAVALE_GIDEN a,
                  CBS_YPHAVALE_GIDEN_ACILIS b
             WHERE a.REFERANS = b.REFERANS
             AND   b.TX_NO=ln_txno
             AND   a.MUSTERI_NO=pn_custno;

                /*BOM ChyngyzO cq4960 28.12.15*/
    ELSIF ln_islemkod='2150' THEN
      OPEN pc_ref FOR
            select s.tx_no,
                       to_char(s.salary_date, 'dd/mm/yyyy'),
                       t.field1 company_account,
                       Pkg_Musteri.Sf_Musteri_Adi(Pkg_Hesap.HesaptanMusteriNoAl(t.field1)) company_name,
                       to_char(PKG_HESAP.External_HesapNo_Al(t.field1)) company_external_acc,
                       Pkg_Musteri.Sf_VergiNo_Al(Pkg_Hesap.HesaptanMusteriNoAl(t.field1)) company_inn,
                       ' ' from_stat_code,
                       '118'||B.EFT_KODU BORCLU_BANKA,
                       Pkg_Hesap.GetBankHQName(Pkg_Genelkz.GetOurBICCode(Pkg_Hesap.HesapSubeAl(t.field1))) bank_name,
                       '' ALACAK_HESAP_NO,
                         nvl(pkg_message.SPLIT( t.field10,';',1), ' ') || '     '  ALACAKLI_ADI, --AzatD 02.03.2021 ibc-59
                       ' ' ALACAK_EXTERNAL_HESAP,
                       '' ALACAK_VERGI_NO,
                       '' to_stat_code,
                       '118005', --Main Branch
                       Pkg_Hesap.GetBankHQName('118010') ABANK_NAME,
                       PKG_HESAP.HESAPTANDOVIZKODUAL(t.field1) CURRENCY,
                        S.TOTAL_AMOUNT,
                        t.field7,
                        '' STAT_CODE,
                        '' PREFIX_STAT_CODE,
                         Pkg_Report.Number_To_Word_Eng(  S.TOTAL_AMOUNT, PKG_HESAP.HESAPTANDOVIZKODUAL(t.field1)) TUTAR_YAZI_ILE_ENG,
                         Pkg_Report.Number_To_Word_Rus(  S.TOTAL_AMOUNT, PKG_HESAP.HESAPTANDOVIZKODUAL(t.field1)) TUTAR_YAZI_ILE_RUS,
                         '-' BCLASS,
                         S.TX_NO,
                         '2150' ":B2", --CBS 699 AdilK 03.08.2022
                         S.CHARGE_AMOUNT,
                         PKG_MUSTERI.sf_OKPO_al(Pkg_Hesap.HesaptanMusteriNoAl(t.field1)),
                         PKG_MUSTERI.SF_SOSYAL_FON_NO_AL(Pkg_Hesap.HesaptanMusteriNoAl(t.field1)),
                         sd.STAFF_ACCOUNT_NO to_acc --CBS-699 AdilK 03.08.2022
            from corpint.tbl_txtodo t,
                      cbs_salary s,
                      cbs_bolum b,
                       -- BOM CBS-699
                      CBS_SALARY_DETAIL sd
            where T.TRANCD = 'SALARY' and
            T.FIELD12 = to_char(S.TX_NO) and sd.TX_NO=s.TX_NO  and S.TX_NO = ln_txno
            and b.kodu = Pkg_Hesap.HesapSubeAl(t.field1)
            AND (((Pkg_Hesap.HesaptanMusteriNoAl(t.field1) = pn_custno)) or (Pkg_Hesap.HesaptanMusteriNoAl(sd.STAFF_ACCOUNT_NO) = pn_custno));
            

            /* old where  before CBS-699
                        where T.TRANCD = 'SALARY' and
            T.FIELD12 = S.TX_NO and S.TX_NO = ln_txno
            and b.kodu = Pkg_Hesap.HesapSubeAl(t.field1)
            AND Pkg_Hesap.HesaptanMusteriNoAl(t.field1) = pn_custno;
            */
            --EOM CBS-699


    /*EOM ChyngyzO cq4960 28.12.15*/
    /*Begin_Bakdoolot ibc-29 13.01.22*/
    ELSIF ln_islemkod='6330' THEN
        OPEN pc_ref FOR
            SELECT ci.ISLEM_NO,
            to_char(ci.TAHSILAT_TARIHI, 'dd/mm/yyyy'),
            ci.TUTAR,
            Pkg_Report.Number_To_Word_Rus( ci.TUTAR, ci.DOVIZ_KODU) TUTAR_YAZI_ILE,
            Pkg_Report.Number_To_Word_Eng( ci.TUTAR, ci.DOVIZ_KODU) TUTAR_YAZI_ILE_ENG,
            (select EXTERNAL_HESAP_NO from cbs_vw_hesap_izleme where hesap_no = CI.HESAP_NO) HESAP_NO, --????? ????? ???????????
            (select vergi_no from  cbs_musteri where musteri_no = CI.MUSTERI_NO) FROM_RNN,
            (select OKPO_CODE from cbs_musteri where musteri_no = CI.MUSTERI_NO) FROM_OKPO,
            (select SOSYAL_FON_NO from cbs_musteri where musteri_no =CI.MUSTERI_NO) FROM_SOCIAL_FUND_NUMBER,
            '118' || (select EFT_KODU from cbs_bolum where kodu = ci.SUBE_KODU) filial, --??? ???????????
            (select KURUM_ADI_2 from CBS_TAHSILAT_KURUM_TANIM where KURUM_KODU=ci.KURUM_KODU) KURUM_ADI_2, -- ???? ??????????
            ci.ISIM_UNVAN, --???????? ???????????
            ci.KURUM_KODU, --???????? ??????????
            ci.ABONE_ADI, --  ?????????? ???????
            ci.PAYMENT_ID,--??? ???????
            ci.KURUM_OZEL_NO,-- ??? ????? ?????
            ci.TELEFON_ALAN_KOD,--??? ????????
            ci.TELEFON_NO,--????? ????????
            ci.service_kodu service_code,--CBS-699 AdilK 03.08.2022
            ci.COMMISSION_AMOUNT_BANK+COMMISSION_AMOUNT_COMPANY Charge_amount, -- COMMISSION --CBS 699 AdilK 03.08.2022
            ci.HESAP_NO FROM_ACC,  --CBS 699 AdilK 03.08.2022
            ln_islemkod ":B2"--CBS-699 AdilK 03.08.2022
            FROM cbs_tahsilat ci
            WHERE ci.ISLEM_NO = ln_txno;
    /*End_Bakdoolot ibc-29 13.01.22*/
    END IF;


    RETURN ls_returncode;

EXCEPTION

 WHEN NoStatementFound THEN
   ls_returncode:='269';
   Log_At('GetTranStatement',ln_islemkod,ln_txno,ls_returncode);
   OPEN pc_ref FOR    SELECT SYSDATE FROM dual;
   RETURN ls_returncode;

 WHEN OTHERS THEN
    ls_returncode := '999';
    Log_At('GetTranStatement',SQLERRM,ln_txno);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    RETURN ls_returncode;
END;
/******************************************************************************
   NAME        : FUNCTION GetTimeDepositInfo
   Prepared By : Muzaffar Khaloyknaza
   Date        : 12.12.2007
   Purpose     : Get Time Deposit Info
******************************************************************************/
FUNCTION GetTimeDepositInfo(pn_CustomerId  IN VARCHAR2,
                            pn_PersonId    IN VARCHAR2,
                            ps_ChannelCd   IN VARCHAR2,
                            ps_CurrencyCd  IN VARCHAR2,
                            pc_ref OUT CursorReferenceType,
                            pc_ref2 OUT CursorReferenceType,
                            pc_ref3 OUT CursorReferenceType,
                            pc_ref4 OUT CursorReferenceType,
                            pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2
IS

    ls_returncode VARCHAR2(3):='000';
    ln_accountcount NUMBER:=0; --chyngyzo cq1325
    accountException  EXCEPTION;
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;
     --Get Time Deposit All Info
      OPEN pc_ref   FOR
            SELECT VADE_1, VADE_2, 0, 0, DECODE(ps_CurrencyCd,'RUB',RUB,'USD',USD,'EUR',EUR,TRL) INTEREST_RATE --cq6018
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE tarih=Pkg_Muhasebe.Banka_Tarihi_Bul
            AND musteri_tipi=1
            --AND period_code=1   ---cbs-33 TemirlanT
            ORDER BY vade_1,vade_2;

     --Get Time Deposit Date
     OPEN pc_ref2 FOR
            SELECT VADE_1, VADE_2, 0, 0, USD
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE tarih=Pkg_Muhasebe.Banka_Tarihi_Bul
            AND musteri_tipi=1
            --AND period_code=1   ---cbs-33 TemirlanT
            ORDER BY vade_1,vade_2;

     --Get Time Deposit Amount
     OPEN pc_ref3 FOR
            SELECT VADE_1, VADE_2, 0, 0, EUR
            FROM CBS_CARI_VADELI_MEVDUAT_FO
            WHERE tarih=Pkg_Muhasebe.Banka_Tarihi_Bul
            AND musteri_tipi=1
            --AND period_code=1   ---cbs-33 TemirlanT
            ORDER BY vade_1,vade_2;

     --Get Tran Accounts
    -- BOM chyngyzo cq1325-------------------------
    SELECT   COUNT(*)
    INTO ln_accountcount
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = pn_CustomerId
            AND durum_kodu = 'A'
         AND modul_tur_kod= 'CURRENT'
         AND urun_tur_kod IN ('CURRENT', 'COLLATERAL','DEMAND DEP')
         AND DOVIZ_KODU=ps_CurrencyCd;
    -- EOM chyngyzo cq1325-------------------------
     IF ln_accountcount > 0 THEN --chyngyzo cq1325
     ls_returncode:=Pkg_Soa_Inquiry.GetTranAccountsForCurrcode(pn_CustomerId,ps_CurrencyCd,pc_ref4);
     IF ls_returncode <> '000' THEN
       RAISE accountException;
         END IF;
     END IF;

      --Get Bank Date
     OPEN pc_ref5 FOR
            SELECT TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD') FROM DUAL;
        RETURN ls_returncode;

EXCEPTION
     WHEN accountException THEN
     RETURN ls_returncode;
    WHEN OTHERS THEN
        ls_returncode:='999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;
/******************************************************************************
   NAME        : FUNCTION GetTranAccountsForCurrcode
   Prepared By : Muzaffar Khalyknazarov
   Date        : 24.12.2007
   Purpose     : Get Tran Accounts for currency code
******************************************************************************/
FUNCTION GetTranAccountsForCurrcode(pn_musteri_no IN VARCHAR2,
                                    ps_currcode IN VARCHAR2,
                                    pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     ls_accountcount NUMBER:=0;
     noAccoutFound EXCEPTION;
BEGIN


      SELECT   COUNT(*)
      INTO ls_accountcount
       FROM CBS_vw_hesap_izleme a
       WHERE musteri_no = pn_musteri_No
                AND durum_kodu = 'A'
             AND modul_tur_kod= 'CURRENT'
             AND urun_tur_kod IN ('CURRENT', 'COLLATERAL','DEMAND DEP')
             AND DOVIZ_KODU=ps_currcode;--ernestk cqdb1116 show only accounts of selected currency

      IF (ls_accountcount= 0) THEN
      --RAISE noAccoutFound;
      ls_returncode:='503';
      END IF;

  OPEN pc_ref FOR
      SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,KISA_ISIM,
               URUN_SINIF_KOD --added for task ib-175 Bakdoolot 25.07.2022
       FROM CBS_vw_hesap_izleme a
       WHERE musteri_no = pn_musteri_No
                AND durum_kodu = 'A'
             AND modul_tur_kod= 'CURRENT'
             AND urun_tur_kod IN ('CURRENT', 'COLLATERAL','DEMAND DEP')
             AND DOVIZ_KODU=ps_currcode--ernestk cqdb1116 show only accounts of selected currency
       ORDER BY siralama , SUBE, HESAP_NO,doviz_kodu;

  RETURN ls_returncode;
    EXCEPTION
    WHEN noAccoutFound THEN
      ls_returncode:= '503';
    RETURN ls_returncode;


END;
/******************************************************************************
   NAME        : FUNCTION CheckTimeDepositDate
   Prepared By : Muzaffar khalyknazarov
   Date        : 21.12.2007
   Purpose     : Check time Depoosit Date
   Modified By   : Tastan Zhaylibayev
   Modified Date : 08.01.2008
******************************************************************************/
FUNCTION CheckTimeDepositDate(pn_CustomerId         IN VARCHAR2,
                              ps_MaturityDate       IN VARCHAR2,
                              ps_MaturityDay        IN VARCHAR2,
                              ps_vade_islem_belgisi IN VARCHAR2,
                              pn_Amount             IN VARCHAR2,
                              ps_CurrencyCd         IN VARCHAR2,
                              pn_ara_odeme_bilgisi  IN VARCHAR2,
                              pc_ref OUT CursorReferenceType,
                              pc_ref2 OUT CursorReferenceType,
                              pc_ref3 OUT CursorReferenceType,
                              pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

   ls_returncode        VARCHAR2(3):='000';
   ps_tmpdate           DATE;
   ps_kur               NUMBER:=0;
   vade_islem_belgisi VARCHAR2(1);
   pl_urunsinif           VARCHAR2(25):='DEPOSIT INSURANCE-LC';
   ls_net_faiz NUMBER := 0;
   ln_net_geri_donus_tutari NUMBER;
   ln_gun_sayisi   NUMBER;
   ln_msigv_orani   NUMBER;
   ln_brut            NUMBER;
   ln_msigv            NUMBER;
   ld_valor_tarihi     DATE;
   ln_ESAS_GUN_SAYISI NUMBER := 365;
   ln_FAIZ_ORANI       NUMBER;
   ld_vade_tarih VARCHAR2(10);
   ln_tutar NUMBER:= TO_NUMBER(REPLACE(REPLACE(pn_Amount,',',''),'.',','));
   gecmisgunhatasi      EXCEPTION;
   ps_sistem_tarih DATE:= Pkg_Muhasebe.BANKA_TARIHI_BUL;
   NoInterestRatesOnDate EXCEPTION;
   le_min_sum EXCEPTION;        --TemirlanT cbs-253
   ln_min_amount_kgs number;    --TemirlanT cbs-253
   ln_min_amount_usd number;    --TemirlanT cbs-253
   ln_min_amount_rub number;    --TemirlanT cbs-253

BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;
    --BOM --TemirlanT cbs-253 introduction of a minimum amount for opening a term deposit
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_KGS',ln_min_amount_kgs);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_USD',ln_min_amount_usd);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_RUB',ln_min_amount_rub);
    if ps_CurrencyCd = 'KGS' then
        if ln_tutar < ln_min_amount_kgs then
            ls_returncode := '215';
            raise le_min_sum;
        end if;
    elsif ps_CurrencyCd = 'USD' then
        if ln_tutar < ln_min_amount_usd then
            ls_returncode := '214';
            raise le_min_sum;
        end if;
    elsif ps_CurrencyCd = 'RUB' then
        if ln_tutar < ln_min_amount_rub then
            ls_returncode := '217';
            raise le_min_sum;
        end if;
    end if;
    --EOM --TemirlanT cbs-253
    IF ps_vade_islem_belgisi='1' THEN
        IF ( TO_DATE(ps_MaturityDate,'YYYYMMDD') < ps_sistem_tarih ) THEN
        RAISE NoInterestRatesOnDate;
        END IF;

        -- e?er kullan?c? vade sonu olarak belirli bir tarih belirlemi? ise o tarihden bir sonraki uygun tarih bulunur
        SELECT TRUNC(Pkg_Tarih.tarihten_sonraki_isgunu(TO_DATE(ps_MaturityDate,'YYYYMMDD')-1 ))
        INTO ps_tmpdate
        FROM DUAL;

        OPEN pc_ref FOR
        SELECT TO_CHAR(ps_tmpdate,'YYYYMMDD')
        FROM DUAL;

        SELECT DECODE(ps_CurrencyCd,'RUB',RUB,'USD',USD,'EUR',EUR,TRL)--cq6018
        INTO ps_kur
        FROM CBS_CARI_VADELI_MEVDUAT_FO
        WHERE TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO )
        AND VADE_1 <= (TO_DATE(ps_MaturityDate,'YYYYMMDD')- SYSDATE)
        AND VADE_2 >= (TO_DATE(ps_MaturityDate,'YYYYMMDD')-SYSDATE)
        AND MUSTERI_TIPI=1;
        --AND PERIOD_CODE=1; --TemirlanT cbs-33

        IF (ps_kur > 0) THEN
            OPEN pc_ref2 FOR
            SELECT ps_kur FROM DUAL;
        ELSE
           ls_returncode:='216';
        END IF;

        IF (ps_CurrencyCd = 'KGS') THEN
            pl_urunsinif:='LC';
        ELSE
            pl_urunsinif:='FC';
        END IF;

        OPEN pc_ref3 FOR
        SELECT MODUL_TUR, URUN_TUR, URUN_SINIF
        FROM corpint.TBL_VADELI_HESAP_PARAMETRE
        WHERE URUN_SINIF=pl_urunsinif
        AND VADE_1 <= (TO_DATE(ps_MaturityDate,'YYYYMMDD')-ps_sistem_tarih)
        AND VADE_2 >= (TO_DATE(ps_MaturityDate,'YYYYMMDD')-ps_sistem_tarih);
    ELSE
        SELECT Pkg_Tarih.tarihten_sonraki_isgunu(ps_sistem_tarih + TO_NUMBER(ps_MaturityDate)-1)
        INTO ps_tmpdate
        FROM DUAL;

        OPEN pc_ref FOR
        SELECT TO_CHAR(ps_tmpdate,'YYYYMMDD')
        FROM DUAL;

        SELECT DECODE(ps_CurrencyCd,'RUB',RUB,'USD',USD,'EUR',EUR,TRL)--cq6018
        INTO ps_kur
        FROM CBS_CARI_VADELI_MEVDUAT_FO
        WHERE TARIH = (SELECT MAX(TARIH) FROM CBS_CARI_VADELI_MEVDUAT_FO )
        AND VADE_1 <= TO_NUMBER(ps_MaturityDay)
        AND VADE_2 >= TO_NUMBER(ps_MaturityDay)
        AND MUSTERI_TIPI=1;
        --AND PERIOD_CODE=1;  -- TemirlanT cbs-33

        IF (ps_kur > 0) THEN
            OPEN pc_ref2 FOR SELECT ps_kur FROM DUAL;
        ELSE
            ls_returncode:='216';
        END IF;

            IF (ps_CurrencyCd = 'KGS') THEN
                pl_urunsinif:='LC';
            ELSE
                pl_urunsinif:='FC';
            END IF;

        OPEN pc_ref3 FOR
        SELECT MODUL_TUR, URUN_TUR, URUN_SINIF
        FROM corpint.TBL_VADELI_HESAP_PARAMETRE
        WHERE URUN_SINIF=pl_urunsinif
        AND VADE_1 <= TO_NUMBER(ps_MaturityDay)
        AND VADE_2 >= TO_NUMBER(ps_MaturityDay);
     END IF;

        IF ps_vade_islem_belgisi='1' THEN
            ld_vade_tarih:=ps_MaturityDate;
        ELSIF ps_vade_islem_belgisi='2' THEN
            ps_tmpdate:=Pkg_Tarih.tarihten_sonraki_isgunu(ps_sistem_tarih + TO_NUMBER(ps_MaturityDate)-1);
            ld_vade_tarih:=TO_CHAR(ps_tmpdate,'YYYYMMDD');
        END IF;

        --ls_net_faiz:=Pkg_Int_Account.NetFaizHesapla(TO_NUMBER(pn_CustomerId),TO_NUMBER(pn_ara_odeme_bilgisi),ps_CurrencyCd,ln_tutar,TO_DATE(ld_vade_tarih,'YYYYMMDD'),ln_brut,ln_msigv_orani,ln_msigv);

        vade_islem_belgisi:=ps_vade_islem_belgisi;

        IF vade_islem_belgisi='1' THEN
           ln_net_geri_donus_tutari:=ls_net_faiz+ln_tutar;
        ELSIF  vade_islem_belgisi='2' THEN
           ln_net_geri_donus_tutari:=ls_net_faiz;
        ELSIF  vade_islem_belgisi='3' THEN
           ln_net_geri_donus_tutari:=0;
        END IF;

        OPEN pc_ref4 FOR
        SELECT ls_net_faiz, ln_net_geri_donus_tutari,ln_brut,ln_msigv_orani,ln_msigv FROM dual;

        OPEN pc_ref5 FOR
        SELECT TO_CHAR(ps_sistem_tarih,'YYYYMMDD') FROM dual;

        RETURN ls_returncode;
EXCEPTION
    WHEN le_min_sum THEN
        RETURN ls_returncode; --TemirlanT cbs-253
    WHEN NoInterestRatesOnDate THEN
        RETURN ls_returncode;
    WHEN NO_DATA_FOUND THEN
        ls_returncode:='216';
        Log_At('CheckTimeDepositDate',SQLERRM,ls_returncode);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        OPEN pc_ref2 FOR SELECT '-' FROM dual;
        OPEN pc_ref3 FOR SELECT '-' FROM dual;
        OPEN pc_ref4 FOR SELECT '-' FROM dual;
        OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
    WHEN OTHERS THEN
        LOG_AT('CheckTimeDeposit',SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
END;
 /******************************************************************************
   NAME        : FUNCTION CheckTimeDepositClosingDate
   Prepared By : Muzaffar Khalyknazarov
   Date        : 25.12.2007
   Purpose     : CheckTimeDepositClosingDate
******************************************************************************/
FUNCTION CheckTimeDepositClosingDate(pd_date IN VARCHAR2,
                                     pn_vadegun IN VARCHAR2,
                                     pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_return_value     VARCHAR2(1);
    ln_value VARCHAR2(3);
    ln_vade_gunu     NUMBER;
    ld_vadedate     DATE;

BEGIN

  IF pn_vadegun='0' THEN
       ln_vade_gunu:=TO_DATE(pd_date,'YYYYMMDD')-Pkg_Muhasebe.Banka_Tarihi_Bul;
     ld_vadedate:=TO_DATE(pd_date,'YYYYMMDD');
  ELSE
         ld_vadedate:=Pkg_Muhasebe.Banka_Tarihi_Bul+TO_NUMBER(pn_vadegun);
      ln_vade_gunu:=TO_NUMBER(pn_vadegun);
  END IF;

   ln_value:=Pkg_Dates.is_work_day(ld_vadedate);

    OPEN pc_ref FOR
    SELECT ln_value, ln_vade_gunu,TO_CHAR(ld_vadedate,'YYYYMMDD'),TO_CHAR(ld_vadedate,'YYYY'),TO_NUMBER(TO_CHAR(ld_vadedate,'MM')),TO_NUMBER(TO_CHAR(ld_vadedate,'DD')) FROM dual;

    RETURN ls_returncode;

  EXCEPTION
    WHEN OTHERS THEN
    OPEN pc_ref FOR
    SELECT '-','-','-' FROM dual;
    Log_At(SQLERRM);
     ls_returncode:= '999';
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION GetCommission
   Prepared By : Muzaffar Khalyknazarov
   Date        : 28.01.2009
   Purpose     : GetCommission
******************************************************************************/
FUNCTION GetCommission(ps_TranCd     IN VARCHAR2,
                       pn_FromAccNo  IN VARCHAR2,
                       pn_ToAccNo    IN VARCHAR2,
                       pn_Amount     IN VARCHAR2,
                       ps_CurrCd     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_musterino  NUMBER;
    ln_islem_no NUMBER;
    ln_islem_kod NUMBER;
    ls_modul_tur_kod VARCHAR2(20);
    ls_urun_tur_kod VARCHAR2(20);
    ls_urun_sinif_kod VARCHAR2(20);
    ln_fromaccno NUMBER:=TO_NUMBER(pn_FromAccNo);
    ln_toaccno NUMBER;
    ln_tutar NUMBER:=TO_NUMBER(pn_Amount,'99999999999.99');
    ls_bolum_kodu VARCHAR2(3):=Pkg_Hesap.hesapsubeal(ln_fromaccno);
    ln_musteri_no NUMBER:=Pkg_Hesap.hesaptanmusterinoal(ln_fromaccno);
    ls_kasa_kod NUMBER;
    ln_commission NUMBER;
    ln_tax_rate NUMBER;
    ls_our_ben VARCHAR2(10);
    ls_urgent VARCHAR2(10);
    ln_staff_count NUMBER;
    ln_insider_count NUMBER;

    /* B-O-M chyngyzo cq509 03.08.2015 */
    ln_cdf_total_charge NUMBER := 0; --CHYNGYZO cq509 19.02.2015
    ln_spec_commission NUMBER := 0; --CHYNGYZO cq509 06.07.2015

    ln_const NUMBER:=0;
    ln_prop NUMBER:=0;
    ln_min NUMBER:=0;
    ln_max NUMBER:=0;

    ln_cdf_rate NUMBER:= 0;
    /* E-O-M chyngyzo cq509 03.08.2015 */
BEGIN
    ln_islem_no:=Pkg_Tx.islem_no_al;

    IF ps_TranCd='CLEARING' THEN
       SELECT DECODE(MUSTERI_TIPI_KOD,1,'RIBCLEARING','CIBCLEARING')
       INTO   ls_urun_sinif_kod
       FROM CBS_MUSTERI
       WHERE musteri_no=ln_musteri_no;

       ln_islem_kod:=3555;
       ls_modul_tur_kod:='CLEARING';
       ls_urun_tur_kod:='OUTGOING';
       --ls_urun_sinif_kod:='INTCLEARING';

    ELSIF ps_TranCd='TAXPYMNTS' THEN

       ln_islem_kod:=3555;
       ls_modul_tur_kod:='CLEARING';
       ls_urun_tur_kod:='OUTGOING';
       ls_urun_sinif_kod:='RIBTAXPAY';

    ELSIF ps_TranCd='B2OBHVL' THEN

       ln_toaccno := Pkg_Hesap.GetHesapNoFromExternal(pn_ToAccNo,ps_CurrCd);
       Pkg_Tx1203.sp_urun_tur_sinif_al(ln_fromaccno,
                                       ln_toaccno,
                                       ps_CurrCd,
                                       'E',
                                       ls_modul_tur_kod,
                                       ls_urun_tur_kod,
                                       ls_urun_sinif_kod);
       ln_islem_kod:='1203';
    /* B-O-M chyngyzo cq509 19.02.2015 */
    ELSIF pkg_message.SPLIT(ps_TranCd, '###', 0)='SWIFT' and  pkg_message.SPLIT(ps_TranCd, '###', 1)='CIB' THEN

        ls_our_ben := pkg_message.SPLIT(ps_TranCd, '###', 2);

        ln_islem_kod:=4003;
        ls_modul_tur_kod:='FCTRANSFER';
        ls_urun_tur_kod:='OUTGOING';

        ls_urun_sinif_kod:=UPPER('CIB' || ' ' || ls_our_ben || ' ' || ps_CurrCd);

    /* E-O-M chyngyzo cq509 19.02.2015 */
    ELSIF pkg_message.SPLIT(ps_TranCd, '###', 0)='SWIFT' THEN

       ls_our_ben := pkg_message.SPLIT(ps_TranCd, '###', 1);
       ls_urgent := pkg_message.SPLIT(ps_TranCd, '###', 2);

       ln_islem_kod:=4003;
       ls_modul_tur_kod:='FCTRANSFER';
       ls_urun_tur_kod:='OUTGOING';

       ls_urun_sinif_kod:=UPPER(ls_our_ben || ' ' || ls_urgent || ' ' || ps_CurrCd);

        -- THIS PART OF CODE FOR STAFF COMMISSION
        SELECT COUNT(*) INTO ln_staff_count
        FROM CBS_MUSTERI
        WHERE MUSTERI_NO = ln_musteri_no
        AND PERSONEL_SICIL_NO IS NOT NULL;

        SELECT COUNT(*) INTO ln_insider_count
        FROM CORPINT.TBL_SWIFT_INSIDERS
        WHERE PERSON_ID IN (SELECT person_id FROM corpint.tbl_person WHERE customer_id=ln_musteri_no);

        IF (ln_staff_count > 0) AND (ln_insider_count = 0) THEN
            ls_urun_sinif_kod := 'STAFF SWIFT';
        END IF;
        -----------------------------------------
     /*BOM ChyngyzO cq4960 28.12.15*/
     ELSIF ps_TranCd='SALARY' THEN

        ln_islem_kod:=2150;
        ls_modul_tur_kod:='CUSTOMER';
        ls_urun_tur_kod:='SALARY';
        ls_urun_sinif_kod:='CIBPAYMENT';

     /*EOM ChyngyzO cq4960 28.12.15*/
     --BOM AdiletK added gross commission
    ELSIF ps_TranCd='GROSS' THEN
        SELECT DECODE(MUSTERI_TIPI_KOD,1,'RIBGROSS','CIBGROSS')
        INTO   ls_urun_sinif_kod
        FROM CBS_MUSTERI
        WHERE musteri_no=ln_musteri_no;

       ln_islem_kod:=3555;
       ls_modul_tur_kod:='CLEARING';
       ls_urun_tur_kod:='OUTGOING';
     --EOM AdiletK added gross commission
    END IF;



log_at('1302swift', ln_islem_no || ' ' || ln_tutar);
 
       ln_commission := Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod,
                                                  ln_tutar, ls_bolum_kodu, ps_CurrCd, ln_musteri_no, ln_fromaccno, ls_kasa_kod);

       BEGIN
           SELECT TO_NUMBER(REPLACE(DEGER,'.',',')) INTO ln_tax_rate
           FROM CBS_PARAMETRE
           WHERE kod='G_SALES_TAX_RATE'
           AND ROWNUM=1;
       EXCEPTION
           WHEN OTHERS THEN
               BEGIN
                   SELECT TO_NUMBER(REPLACE(DEGER,',','.')) INTO ln_tax_rate
                   FROM CBS_PARAMETRE
                   WHERE kod='G_SALES_TAX_RATE'
                   AND ROWNUM=1;
               EXCEPTION
                   WHEN OTHERS THEN
                       ln_tax_rate:=0;
               END;
       END;

     /* B-O-M chyngyzo cq509 19.02.2015 */
     IF pkg_message.SPLIT(ps_TranCd, '###', 0)='SWIFT' and  pkg_message.SPLIT(ps_TranCd, '###', 1)='CIB' THEN
        ln_spec_commission := PKG_MASRAF.CALCULATE_COMMISSIONS_FOR_CIB(ln_islem_no, ls_urun_sinif_kod, nvl(ln_tutar, 0), ps_CurrCd, ln_musteri_no, ln_fromaccno);

        ln_cdf_total_charge := PKG_MASRAF.CALCULATE_CDF_FOR_CIB(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod,  nvl(ln_tutar, 0), ps_CurrCd, ln_musteri_no, ln_fromaccno);

        ln_commission :=  Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod,
                                                  ln_tutar, ls_bolum_kodu, ps_CurrCd, ln_musteri_no, ln_fromaccno, ls_kasa_kod);

        pkg_soa_inquiry.GetSwiftCommissionRates(ln_musteri_no, ln_fromaccno, ps_CurrCd, ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod, ln_const, ln_prop, ln_min, ln_max, ln_cdf_rate);
     END IF;
     /* E-O-M chyngyzo cq509 19.02.2015 */



     OPEN pc_ref FOR SELECT ln_commission, ln_tax_rate, TO_NUMBER(ln_commission)*ln_tax_rate/100, ln_cdf_total_charge, ln_const, ln_prop, ln_min, ln_max, ln_cdf_rate FROM dual; --chyngyzo cq509 ln_cdf_total_charge,ln_const, ln_prop, ln_min, ln_max, ln_cdf_rate are added

     RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        log_at('GetCommission',SQLERRM,  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
END;
/******************************************************************************
   NAME        : FUNCTION GetTimeDepAccounts
   Prepared By : Muzaffar Khalyknazarov
   Date        : 03.02.09
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetTimeDepAccounts(p_customerid IN VARCHAR2,
                             pc_ref OUT CursorReferenceType,
                             pc_ref2 OUT CursorReferenceType,
                             pc_ref3 OUT CursorReferenceType,
                             pc_ref4 OUT CursorReferenceType,
                              pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;
BEGIN
  OPEN pc_ref FOR SELECT '-' FROM dual;
  OPEN pc_ref2 FOR SELECT '-' FROM dual;
  OPEN pc_ref3 FOR SELECT '-' FROM dual;
  OPEN pc_ref4 FOR SELECT '-' FROM dual;
  OPEN pc_ref5 FOR SELECT '-' FROM dual;


  SELECT COUNT(*)
  INTO ls_account_count
  FROM CBS_vw_hesap_izleme a
  WHERE musteri_no = TO_NUMBER(p_customerid) AND
  durum_kodu = 'A' AND
  modul_tur_kod= 'TIME DEP.'
   AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
  ORDER BY acilis_tarihi;

  IF (ls_account_count= 0) THEN
    RAISE noAccoutFound;
  END IF;

  OPEN pc_ref FOR
    SELECT musteri_no, hesap_no, doviz_kodu, bakiye, TO_CHAR(acilis_tarihi,'yyyymmdd'), TO_CHAR(vade_tarihi,'yyyymmdd'), kisa_isim,
           NVL(birikmis_faiz_poz,0)+NVL(GECMIS_AYLARIN_FAIZI,0)+NVL(gecen_yil_faiz_toplami,0) faiz,
           GERI_DONUS_HESAPNO, FAIZ_ORANI
    FROM CBS_vw_hesap_izleme a
    WHERE musteri_no = TO_NUMBER(p_customerid) AND
    durum_kodu = 'A' AND
    modul_tur_kod= 'TIME DEP.'
     AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
    ORDER BY acilis_tarihi;

    RETURN ls_returncode;

EXCEPTION
    WHEN noAccoutFound THEN
          ls_returncode:= '503';

    RETURN ls_returncode;
    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.GetTimeDepAccounts',SQLERRM);
        ls_returncode:= '999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;
/******************************************************************************
   NAME        : FUNCTION GetWaitTran
   Prepared By : Almas Nurkhozhayev
   Date        : 12.01.2010
   Purpose     : Get All Waiting Transactions
******************************************************************************/
FUNCTION GetWaitTran(ps_OptionCd       IN VARCHAR2,
                     ps_TxNo           IN VARCHAR2,
                     pn_CustomerNo     IN VARCHAR2,
                     pn_PersonNo       IN VARCHAR2,
                     ps_LangCd         IN VARCHAR2,
                     ps_startdate      IN VARCHAR2 DEFAULT '20050101',
                     ps_enddate        IN VARCHAR2 DEFAULT '20990101',
                     ps_statuscd       IN VARCHAR2,
                     pc_ref OUT CursorReferenceType,
                     pc_ref2 OUT CursorReferenceType,
                     pc_ref3 OUT CursorReferenceType,
                     pc_ref4 OUT CursorReferenceType,
                     pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
BEGIN
     OPEN pc_ref FOR SELECT '-' FROM dual;
     OPEN pc_ref2 FOR SELECT '-' FROM dual;
     OPEN pc_ref3 FOR SELECT '-' FROM dual;
     OPEN pc_ref4 FOR SELECT '-' FROM dual;
     OPEN pc_ref5 FOR SELECT '-' FROM dual;

   IF ps_OptionCd='WAITTRAN' THEN

    UPDATE TBL_TXTODO T
    SET T.STATUS='sEXPIRED'
    WHERE T.CUSTOMER_ID = TO_NUMBER(pn_CustomerNo)
    AND TO_DATE(FIELD3,'YYYYMMDD') < TRUNC(SYSDATE)
    AND TRANCD='CLEARING'
    AND ( (t.STATUS ='sVERIFY') OR (t.STATUS ='sCHECK') OR (t.STATUS ='sAPPROVE'));

    OPEN pc_ref FOR
        SELECT  t.TX_NO,
                DECODE(T.TRANCD,'CLEARING',FIELD3,'CLEARCNCL',FIELD3,TO_CHAR(t.MAKEDATE,'YYYYMMDD')) TRAN_DATE,
                t.MAKERID,
                Pkg_Customer.GetPersonName(t.MAKERID),
                r.DEFINITION,
                t.STATUS,
                DECODE(T.TRANCD,'CLEARPENS',FIELD9,'CLEARCNCL',FIELD9,'UTILPAY',FIELD5,'B2OBHVL',FIELD3,'CLEARING',FIELD9,'EXCHNGBUY',FIELD9,'EXCHNGSELL',FIELD9,'B2BHVL',FIELD3,' ') AMOUNT,
                DECODE(T.TRANCD,'CLEARPENS',FIELD20,'CLEARCNCL',FIELD20,'UTILPAY',FIELD20,'B2OBHVL',FIELD5,'CLEARING','KGS','EXCHNGBUY',FIELD3,'EXCHNGSELL',FIELD3,'B2BHVL',FIELD5,' ')CURRENCY,
                DECODE(T.TRANCD,'CLEARPENS',FIELD1,'CLEARCNCL',FIELD7,'UTILPAY',FIELD2,'B2OBHVL',FIELD10,'CLEARING',FIELD10,'EXCHNGBUY',FIELD8,'EXCHNGSELL',FIELD8,'B2BHVL',' ',' ')PAYEE_NAME
        FROM CORPINT.TBL_TXTODO T,CORPINT.TBL_PERSON_APPROVAL A,CORPINT.TBL_TRANSACTION R
        WHERE
        T.CUSTOMER_ID = TO_NUMBER(pn_CustomerNo) AND
        A.PERSON_ID = TO_NUMBER(pn_PersonNo) AND
        T.STATUS IN ('sAPPROVE','sVERIFY','sCHECK') AND
        A.CHANNEL_CD = 'cDKBCIB'  AND
        A.AUTH_CD= T.AUTHCD AND
        r.LANGUAGE_CD = 'ENG' AND
        t.TRANCD = r.TRAN_CD;

   ELSIF ps_OptionCd='VWTTRAN' THEN

     UPDATE TBL_TXTODO T
     SET T.STATUS='sEXPIRED'
     WHERE TO_DATE(FIELD3,'YYYYMMDD') < Pkg_Muhasebe.Banka_Tarihi_Bul
     AND T.CUSTOMER_ID = TO_NUMBER(pn_CustomerNo)
     AND TRANCD='CLEARING'
     AND t.STATUS  IN ('sVERIFY','sCHECK','sAPPROVE');


   END IF;

RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
     LOG_AT('GetWaitTran',SQLERRM);
     ls_returncode:= '999';
    RETURN ls_returncode;
END;

FUNCTION SwiftBankInfo(ps_bankcountry  IN VARCHAR2,
                       ps_bankcity     IN VARCHAR2,
                       ps_bankname     IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS
ls_sqlstr        VARCHAR2(2000);
ln_count         NUMBER;
ls_returncode     VARCHAR2(3):='000';
NoBankFound      EXCEPTION;
BEGIN
    SELECT COUNT(*)
    INTO ln_count
    FROM CBS_BIC_KODLARI
    WHERE BIC_ULKE_KODU=ps_bankcountry
      AND LENGTH(ULKE_ADI)>0
      AND SUBSTR(BIC_KODU, 8,1) <> '1'
      AND BIC_SUBE_KODU='XXX';

        IF ln_count=0 THEN
           RAISE NoBankFound;
        END IF;
		
        IF (ps_bankcountry<>'TR') THEN
            OPEN pc_ref FOR
             SELECT BIC_KODU, BIC_SUBE_KODU, BANKA_ADI, NVL(SUBE_ADI,'(HEAD OFFICE)'), SEHIR_ADI,
                    ALTTIP_ISARETI, DEGER_EKLI_SRV, EK_BILGI, LOKASYON, ULKE_ADI,
                    POB_NUMARASI, POB_LOKASYON, POB_ULKE_ADI, BIC_BANKA_KODU,
                    BIC_ULKE_KODU, BIC_SEHIR_KODU, COUNTRY_NAME, ADRES_1,
                    ADRES_2, ADRES_3, ADRES_4, ADRES_5, ACIKLAMA2
               FROM CBS_BIC_KODLARI
              WHERE BIC_ULKE_KODU=ps_bankcountry
                AND LENGTH(ULKE_ADI)>0
                AND BIC_SUBE_KODU='XXX'
                AND SUBSTR(BIC_KODU, 8,1) <> '1'
                ORDER BY BIC_KODU;
        ELSE
            OPEN pc_ref FOR
             SELECT BIC_KODU, BIC_SUBE_KODU, BANKA_ADI, NVL(SUBE_ADI,'(HEAD OFFICE)'), SEHIR_ADI,
                    ALTTIP_ISARETI, DEGER_EKLI_SRV, EK_BILGI, LOKASYON, ULKE_ADI,
                    POB_NUMARASI, POB_LOKASYON, POB_ULKE_ADI, BIC_BANKA_KODU,
                    BIC_ULKE_KODU, BIC_SEHIR_KODU, COUNTRY_NAME, ADRES_1,
                    ADRES_2, ADRES_3, ADRES_4, ADRES_5, ACIKLAMA2
               FROM CBS_BIC_KODLARI
              WHERE BIC_ULKE_KODU=ps_bankcountry
                AND LENGTH(ULKE_ADI)>0
                AND BIC_SUBE_KODU='XXX'
                AND SUBSTR(BIC_KODU, 8,1) <> '1'
                AND BIC_KODU NOT IN ('HSBYTRISXXX', 'ISISTRISXXX', 'LBMDTRISXXX', 'MSMDTRISXXX', 'PMKATRISXXX', 'TCMBTR2AXXX', 'TVSBTRISXXX')
                ORDER BY BIC_KODU;
        END IF;

    RETURN ls_returncode;
EXCEPTION
    WHEN NoBankFound THEN
       OPEN pc_ref FOR SELECT '-' FROM dual;
     ls_returncode:= '510';
     RETURN ls_returncode;
END;

FUNCTION GetBankWorkingDays(ps_option VARCHAR2, pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
  ls_returncode VARCHAR2(3):='000';
  ln_i NUMBER:=0;
  ls_days VARCHAR2(1000);
BEGIN
    OPEN pc_ref FOR
        SELECT TO_CHAR(pkg_muhasebe.ONCEKI_BANKA_TARIHI_BUL,'yyyymmdd'),
               TO_CHAR(pkg_muhasebe.BANKA_TARIHI_BUL,'yyyymmdd'),
               TO_CHAR(pkg_muhasebe.SONRAKI_BANKA_TARIHI_BUL,'yyyymmdd'),
               TO_CHAR(SYSDATE,'yyyymmddhh24miss')
        FROM dual;

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
    log_at('CheckKCellPhoneNumber',SQLERRM);
    RAISE_APPLICATION_ERROR(-20100,SQLERRM);
END;

FUNCTION SwiftCountryName(ps_customer_no      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS

        ls_returncode     VARCHAR2(3):='000';

    BEGIN

    OPEN pc_ref FOR
    SELECT DISTINCT BIC_ULKE_KODU, COUNTRY_NAME FROM CBS_BIC_KODLARI
               WHERE country_name IS NOT NULL
               AND BIC_ULKE_KODU NOT IN (SELECT ULKE_KODU FROM CBS_ULKE_KODLARI WHERE ib_restricted = 'Y')
               ORDER BY BIC_ULKE_KODU;

     RETURN ls_returncode;

END;

FUNCTION GetCorrespondentAccountNo(ps_currcode IN VARCHAR2) RETURN NUMBER IS
     ln_account NUMBER;
BEGIN
     SELECT ACCOUNT_NO
     INTO ln_account
     FROM CORPINT.TBL_SWIFT_SETTINGS
     WHERE CURRENCY_CD=ps_currcode;

     RETURN ln_account;
END;

 FUNCTION GetPaymentCodesByOption(ps_option IN VARCHAR2,ps_langcd IN VARCHAR2,pc_ref OUT CursorReferenceType) RETURN VARCHAR2
  IS
  ls_returncode VARCHAR2(3):='000';
  BEGIN

      IF (ps_option='SWIFT') THEN
          OPEN pc_ref FOR
            SELECT ISTATISTIK_KODU,SUBSTR(ACIKLAMA,1,50),SUBSTR(ACIKLAMA2,1,50)
            FROM CBS_ISTATISTIK_KODLARI
            --WHERE ISTATISTIK_KODU IN ('040302', '',119,321,710,811,861,862,721,722,610,855,820)
            ORDER BY ISTATISTIK_KODU;
      ELSIF (ps_option='SWIFT_CORP') THEN
          --B-O-M chyngyzo cq509 return parent group of statistical codes for corporate internet banking users
      OPEN pc_ref FOR
           SELECT id, '- '||UPPER(TRIM(decode(ps_langcd, 'ENG', name,  name_rus)))
           FROM cbs_statistical_codes_cib
           WHERE parent_id IS NULL
           ORDER BY id;

       --E-O-M chyngyzo cq509 return parent group of statistical codes for corporate internet banking users

         /* OPEN pc_ref FOR
            SELECT ISTATISTIK_KODU,SUBSTR(ACIKLAMA,1,50),SUBSTR(ACIKLAMA2,1,50)
            FROM CBS_ISTATISTIK_KODLARI
            WHERE MOD(ISTATISTIK_KODU,2)=0
            ORDER BY ISTATISTIK_KODU;*/
      ELSE
          OPEN pc_ref FOR
            SELECT ISTATISTIK_KODU,SUBSTR(ACIKLAMA,1,50),SUBSTR(ACIKLAMA2,1,50)
            FROM CBS_ISTATISTIK_KODLARI
            ORDER BY ISTATISTIK_KODU;
      END IF;

   RETURN ls_returncode;
 END;

FUNCTION GetSWIFTInquiry(ps_customerid IN VARCHAR2,
                         pd_startdate IN VARCHAR2,
                         pd_enddate IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ld_startdate DATE;
    ld_enddate   DATE;
    ln_tax_rate  NUMBER := 0;
BEGIN

      IF pd_startdate IS NULL OR pd_enddate IS NULL THEN
          ld_startdate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
        ld_enddate:=Pkg_Muhasebe.Banka_Tarihi_Bul;
      ELSE
           ld_startdate:=TO_DATE(pd_startdate,'YYYYMMDD');
         ld_enddate:=TO_DATE(pd_enddate,'YYYYMMDD');
      END IF;

       BEGIN
           SELECT TO_NUMBER(REPLACE(DEGER,'.',',')) INTO ln_tax_rate
           FROM CBS_PARAMETRE
           WHERE kod='G_SALES_TAX_RATE'
           AND ROWNUM=1;
       EXCEPTION
           WHEN OTHERS THEN
               BEGIN
                   SELECT TO_NUMBER(REPLACE(DEGER,',','.')) INTO ln_tax_rate
                   FROM CBS_PARAMETRE
                   WHERE kod='G_SALES_TAX_RATE'
                   AND ROWNUM=1;
               EXCEPTION
                   WHEN OTHERS THEN
                       ln_tax_rate:=0;
               END;
       END;

      OPEN pc_ref FOR
        SELECT REFERANS, GONDEREN_SUBE, MUSTERI_NO, aa.MODUL_TUR_KOD, aa.URUN_TUR_KOD, aa.URUN_SINIF_KOD, ULKE_KODU, CEK_ILE_F, CEK_NO, TRANSFER_DOVIZ_KODU,
               aa.TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU, ss.durum, PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, TO_CHAR(VALOR_TARIHI,'YYYYMMDD'), TRANSFER_SEKLI,
               BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO, MUH_BANK_HESAP_NO, ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO, HAVALE_KOMISYONU, DOVIZ_AL_SAT_KOMISYONU, HABERLESME_MASRAFI,
               BOC, IC, IC_ACIKLAMA, TTC, VCA, CIA_DOVIZ, ER, OC, OC_BEI, OC_HESAP_NO,
               OC_ISIM_ADRES, OI, OI_PARTY_IDENTIFIER, OI_BIC, OI_ISIM, OI_ISIM_ADRES, SC, SC_PARTY_IDENTIFIER, SC_BIC, SC_LOCATION,
               SC_ISIM_ADRES, RC, RC_PARTY_IDENTIFIER, RC_BIC, RC_LOCATION, RC_ISIM_ADRES, TRI, TRI_PARTY_IDENTIFIER, TRI_BIC, TRI_LOCATION,
               TRI_ISIM_ADRES, II, II_PARTY_IDENTIFIER, II_BIC, II_LOCATION, II_ISIM_ADRES, AWI, AWI_PARTY_IDENTIFIER, AWI_BIC, AWI_LOCATION,
               AWI_ISIM_ADRES, BC, BC_BEI, BC_HESAP_NO, BC_ISIM_ADRES, RI, DOC, SENDERS_CHARGES, SENDERS_DVZ, RECEIVERS_CHARGES,
               RECEIVERS_DVZ, STRI, RR, DURUM_KODU, TO_CHAR(ACILIS_TARIHI,'YYYYMMDD'), SENDER_BIC, RECEIVER_BIC, MASRAF_TOPLAMI /*+ to_number(MASRAF_TOPLAMI)*ln_tax_rate/100*/, CIA_TUTAR, REZERVASYON_NO,
               SI_PARTY_IDENTIFIER, SI_BIC, SI, BI, BI_PARTY_IDENTIFIER, BI_BIC, BI_ISIM_ADRES, RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD, CHARGE_AMOUNT,
               'bankname', Pkg_Genel.ulke_adi_al(ULKE_KODU), ALICI_BIC, POST_STRI_1, BC_HESAP_NO_N, OC_ISIM_ADRES_1, OI_BIC, BC_ISIM_ADRES_1, NVL((SELECT BANKA_ADI FROM CBS_BIC_KODLARI WHERE bic_kodu=AWI_BIC),''),
               NVL((SELECT ii.ACIKLAMA FROM CBS_ISTATISTIK_KODLARI ii WHERE ii.istatistik_kodu=aa.ISTATISTIK_KODU AND ROWNUM=1),''),
               NVL((SELECT BANKA_ADI FROM CBS_BIC_KODLARI WHERE bic_kodu=ALICI_BIC),'')
        FROM CBS_YPHAVALE_GIDEN_ACILIS aa, CBS_ISLEM ss
        WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
        AND AA.TX_NO = ss.NUMARA
        AND VALOR_TARIHI BETWEEN ld_startdate AND ld_enddate;

        /*SELECT REFERANS, GONDEREN_SUBE, MUSTERI_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, ULKE_KODU, CEK_ILE_F, CEK_NO, TRANSFER_DOVIZ_KODU,
               TUTAR, NET_BRUT, TAHSIL_DOVIZ_KODU, KUR, PARITE, CARPMA_BOLME, TAHSIL_TUTARI, NET_TRANSFER_TUTARI, TO_CHAR(VALOR_TARIHI,'YYYYMMDD'), TRANSFER_SEKLI,
               BORCLU_HESAP_NO, BORCLU_DK_NO, MUH_BANK_MUSTERI_NO, MUH_BANK_HESAP_NO, ISTATISTIK_KODU, ACIKLAMA, MASRAF_KOMISYON_HESAP_NO, HAVALE_KOMISYONU, DOVIZ_AL_SAT_KOMISYONU, HABERLESME_MASRAFI,
               BOC, IC, IC_ACIKLAMA, TTC, VCA, CIA_DOVIZ, ER, OC, OC_BEI, OC_HESAP_NO,
               OC_ISIM_ADRES, OI, OI_PARTY_IDENTIFIER, OI_BIC, OI_ISIM, OI_ISIM_ADRES, SC, SC_PARTY_IDENTIFIER, SC_BIC, SC_LOCATION,
               SC_ISIM_ADRES, RC, RC_PARTY_IDENTIFIER, RC_BIC, RC_LOCATION, RC_ISIM_ADRES, TRI, TRI_PARTY_IDENTIFIER, TRI_BIC, TRI_LOCATION,
               TRI_ISIM_ADRES, II, II_PARTY_IDENTIFIER, II_BIC, II_LOCATION, II_ISIM_ADRES, AWI, AWI_PARTY_IDENTIFIER, AWI_BIC, AWI_LOCATION,
               AWI_ISIM_ADRES, BC, BC_BEI, BC_HESAP_NO, BC_ISIM_ADRES, RI, DOC, SENDERS_CHARGES, SENDERS_DVZ, RECEIVERS_CHARGES,
               RECEIVERS_DVZ, STRI, RR, DURUM_KODU, TO_CHAR(ACILIS_TARIHI,'YYYYMMDD'), SENDER_BIC, RECEIVER_BIC, MASRAF_TOPLAMI + to_number(MASRAF_TOPLAMI)*ln_tax_rate/100, CIA_TUTAR, REZERVASYON_NO,
               SI_PARTY_IDENTIFIER, SI_BIC, SI, BI, BI_PARTY_IDENTIFIER, BI_BIC, BI_ISIM_ADRES, RELATED_REFERENCE, PREFIX_ISTATISTIK_KOD, CHARGE_AMOUNT,
               'bankname', Pkg_Genel.ulke_adi_al(ULKE_KODU), ALICI_BIC, POST_STRI_1, BC_HESAP_NO_N, OC_ISIM_ADRES_1, OI_BIC, BC_ISIM_ADRES_1, nvl((select BANKA_ADI from CBS_BIC_KODLARI where bic_kodu=AWI_BIC),''),
               nvl((SELECT ii.ACIKLAMA FROM CBS_ISTATISTIK_KODLARI ii where ii.istatistik_kodu=aa.ISTATISTIK_KODU and rownum=1),''),
               nvl((select BANKA_ADI from CBS_BIC_KODLARI where bic_kodu=ALICI_BIC),'')
        FROM CBS_YPHAVALE_GIDEN aa
        WHERE MUSTERI_NO=TO_NUMBER(ps_customerid)
        AND VALOR_TARIHI BETWEEN ld_startdate AND ld_enddate;*/

    RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        LOG_AT('GetSWIFTInquiry',SQLERRM);
END;
 /******************************************************************************
   NAME        : FUNCTION GetAccountsForCCPayments
   Prepared By : Nurhat Uca
   Date        : 27.08.2012
   Purpose     : GetCreditCardPaymentAccounts - cq8574
******************************************************************************/
   FUNCTION GetAccountsForCCPayments(ps_customer_id IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN

        OPEN pc_ref FOR
        SELECT   hesap_no,
                 sube_kodu || ' ' || Pkg_Genel.bolum_adi_al (sube_kodu) sube,
                 NVL (BAKIYE, 0) bakiye,
                 NVL (Pkg_Hesap.Kullanilabilir_Bakiye_Al (HESAP_NO), 0)
                    kullanilabilir_bakiye
          FROM   CBS_vw_hesap_izleme
         WHERE       musteri_no = TO_NUMBER(ps_customer_id)
                 --AND pkg_hesap.Kullanilabilir_Bakiye_Al (hesap_no) > 0
                 AND durum_kodu = 'A'
                 AND hesap_no NOT IN (SELECT   ana_hesap_no
                                        FROM   CBS_HESAP_ORTAK_BILGI
                                       WHERE   STATUS = 'ACTIVE'  AND ortaklik_tipi<>'OY')
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al;
          RETURN ls_returncode;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ls_returncode := '503';
         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         Log_At ('GetAccountsForCCPayments', SQLERRM);
         ls_returncode := '999';
         RETURN ls_returncode;
   END;
    /*usip functions */
    FUNCTION GETPAYMENTSERVICES (PS_OPTION          IN      VARCHAR2,
                                          PS_GROUP             IN      VARCHAR2,
                                          PS_SUBGROUP         IN      VARCHAR2,
                                          PS_INSTITUTION     IN      VARCHAR2,
                                          PS_LANG             IN      VARCHAR2,
                                          PC_REF                  OUT CURSORREFERENCETYPE)
        RETURN VARCHAR2
    IS
        LS_RETURNCODE                          VARCHAR2 (3) := '000';
        LD_STARTDATE                          DATE;
        LD_ENDDATE                              DATE;
        LN_TAX_RATE                           NUMBER := 0;

        --variable to hold if kurum tanim has commission varied by amount ErnestK
        CURSOR KT_COMMISSION (
            RECIEVER                      VARCHAR2,
            KT_CODE                         VARCHAR2
        )
        IS
            SELECT    A.KURUM_KODU,
                        CASE RECIEVER
                            WHEN 'BANK' THEN A.USE_INTERVALS_FOR_BANK
                            ELSE A.USE_INTERVALS_FOR_COMPANY
                        END
                            AS USE_INTERVALS,
                        CASE RECIEVER
                            WHEN 'BANK' THEN A.COMMISSION_TYPE_BANK
                            ELSE A.COMMISSION_TYPE_COMPANY
                        END
                            AS COMMISSION_TYPE,
                        CASE RECIEVER
                            WHEN 'BANK' THEN A.COMMISSION_RATE_BANK
                            ELSE A.COMMISSION_RATE_COMPANY
                        END
                            COMMISSION_RATE,
                        CASE RECIEVER
                            WHEN 'BANK' THEN A.COMMISSION_AMOUNT_BANK
                            ELSE A.COMMISSION_AMOUNT_COMPANY
                        END
                            COMMISSION_AMOUNT
              FROM    CBS_TAHSILAT_KURUM_TANIM A
             WHERE    A.KURUM_KODU = KT_CODE;

        KT_COMMISSION_RECORDS_BANK       KT_COMMISSION%ROWTYPE;
        KT_COMMISSION_RECORDS_COMPANY   KT_COMMISSION%ROWTYPE;
    BEGIN
        OPEN PC_REF FOR SELECT     SYSDATE FROM DUAL;



        IF (PS_OPTION = 'GROUP') THEN
            IF PS_LANG = 'RUS' THEN
                OPEN PC_REF FOR
                      SELECT   GRUP_KODU, ACIKLAMA_2, GECERLIMI
                         FROM   CBS_TAHSILAT_KURUM_GRUP_TANIM
                        WHERE   GECERLIMI = 'E'
                    ORDER BY   ACIKLAMA_2;
            ELSE
                OPEN PC_REF FOR
                      SELECT   GRUP_KODU, ACIKLAMA, GECERLIMI
                         FROM   CBS_TAHSILAT_KURUM_GRUP_TANIM
                        WHERE   GECERLIMI = 'E'
                    ORDER BY   ACIKLAMA;
            END IF;
        ELSIF (PS_OPTION = 'SUBGROUP') THEN
            IF PS_LANG = 'RUS' THEN
                OPEN PC_REF FOR
                      SELECT   ALT_GRUP_KODU,
                                  ACIKLAMA_2,
                                  GECERLIMI,
                                  GRUP_KODU
                         FROM   CBS_TAHSILAT_KURUM_ALTGRUP_TAN
                        WHERE   GECERLIMI = 'E' AND GRUP_KODU = PS_GROUP
                    ORDER BY   ACIKLAMA_2;
            ELSE
                OPEN PC_REF FOR
                      SELECT   ALT_GRUP_KODU,
                                  ACIKLAMA,
                                  GECERLIMI,
                                  GRUP_KODU
                         FROM   CBS_TAHSILAT_KURUM_ALTGRUP_TAN
                        WHERE   GECERLIMI = 'E' AND GRUP_KODU = PS_GROUP
                    ORDER BY   ACIKLAMA;
            END IF;
        ELSIF (PS_OPTION = 'INSTITUTION') THEN
            IF PS_LANG = 'RUS' THEN
                OPEN PC_REF FOR
                      SELECT   KURUM_KODU,
                                  KURUM_ADI_2,
                                  DURUM_KODU,
                                  MUSTERI_NO,
                                  KURUM_GRUP_KOD,
                                  KURUM_ALT_GRUP_KOD,
                                  TAHSILAT_ALACAK_HESAP,
                                  KURUM_HESAP_NO,
                                  DK_NO,
                                  NULL KOMISYON_TIPI,
                                  NULL KOMISYON_ORANI,
                                  NULL KOMISYON_TUTARI,
                                  DK_NO_SUBESI,
                                  DK_NO_DOVIZ_KODU,
                                  OTOMATIK_TAHSILAT_HESAP_NO,
                                  KULLANIM_HESAP_NO,
                                  HESAPTA_AYRILAN_TUTAR,
                                  IBAN_NO,
                                  ANLASMA_SEKLI,
                                  ANLASMALI_BANKA_MUSTERI_NO,
                                  AKTIFLIK_TARIHI,
                                  MIN_DIGIT_NUMBER,
                                  MAX_DIGIT_NUMBER,
                                  KURUM_DIGIT_MESAJ,
                                  MIN_PAYMENT_AMOUNT,
                                  MAX_PAYMENT_AMOUNT,
                                  ILGILI_BANKA,
                                  ILGILI_SUBE,
                                  HESAP_NO,
                                  OTOMATIK_TAHSILAT,
                                  KISMI_TAHSILAT,
                                  GEC_ODEME,
                                  TIZB_SOZLESME_NO,
                                  TIZB_FATURA_NO,
                                  TIZB_TELEFON_NO,
                                  TIZB_TESISAT_NO,
                                  TIZB_KURUM_OZEL_NO,
                                  ACILIS_TARIHI,
                                  KAPANIS_TARIHI
                         FROM   CBS_TAHSILAT_KURUM_TANIM
                        WHERE         DURUM_KODU = 'AKTIF'
                                  AND KURUM_GRUP_KOD = PS_GROUP
                                  AND KURUM_ALT_GRUP_KOD = PS_SUBGROUP
                                  AND IB_VISIBLE = 'Y' --chyngyzo 08072014 cqdb00000728
                    ORDER BY   KURUM_ADI_2;
            ELSE
                OPEN PC_REF FOR
                      SELECT   KURUM_KODU,
                                  KURUM_ADI,
                                  DURUM_KODU,
                                  MUSTERI_NO,
                                  KURUM_GRUP_KOD,
                                  KURUM_ALT_GRUP_KOD,
                                  TAHSILAT_ALACAK_HESAP,
                                  KURUM_HESAP_NO,
                                  DK_NO,
                                  NULL KOMISYON_TIPI,
                                  NULL KOMISYON_ORANI,
                                  NULL KOMISYON_TUTARI,
                                  DK_NO_SUBESI,
                                  DK_NO_DOVIZ_KODU,
                                  OTOMATIK_TAHSILAT_HESAP_NO,
                                  KULLANIM_HESAP_NO,
                                  HESAPTA_AYRILAN_TUTAR,
                                  IBAN_NO,
                                  ANLASMA_SEKLI,
                                  ANLASMALI_BANKA_MUSTERI_NO,
                                  AKTIFLIK_TARIHI,
                                  MIN_DIGIT_NUMBER,
                                  MAX_DIGIT_NUMBER,
                                  KURUM_DIGIT_MESAJ,
                                  MIN_PAYMENT_AMOUNT,
                                  MAX_PAYMENT_AMOUNT,
                                  ILGILI_BANKA,
                                  ILGILI_SUBE,
                                  HESAP_NO,
                                  OTOMATIK_TAHSILAT,
                                  KISMI_TAHSILAT,
                                  GEC_ODEME,
                                  TIZB_SOZLESME_NO,
                                  TIZB_FATURA_NO,
                                  TIZB_TELEFON_NO,
                                  TIZB_TESISAT_NO,
                                  TIZB_KURUM_OZEL_NO,
                                  ACILIS_TARIHI,
                                  KAPANIS_TARIHI
                         FROM   CBS_TAHSILAT_KURUM_TANIM
                        WHERE         DURUM_KODU = 'AKTIF'
                                  AND KURUM_GRUP_KOD = PS_GROUP
                                  AND KURUM_ALT_GRUP_KOD = PS_SUBGROUP
                                  AND IB_VISIBLE = 'Y' --chyngyzo 08072014 cqdb00000728
                    ORDER BY   KURUM_ADI;
            END IF;
        ELSIF (PS_OPTION = 'PHONE_AREA_CODE') THEN
            OPEN PC_REF FOR
                SELECT    KURUM_KODU, ALAN_KODU, GECERLIMI
                  FROM    CBS_TAHSILAT_KURUM_TELALAN_KOD
                 WHERE    KURUM_KODU = PS_INSTITUTION AND GECERLIMI = 'E';
        ELSIF (PS_OPTION = 'SERVICE_CODE') THEN
            OPEN PC_REF FOR
                SELECT    KURUM_KODU, SERVICE_KODU, GECERLIMI
                  FROM    CBS_TAHSILAT_KURUM_SERVICE_KOD
                 WHERE    KURUM_KODU = PS_INSTITUTION AND GECERLIMI = 'E';
        --B-O-M ernestk 03032014 cqdb00000527 - commissioning rule for tahsilat tanim
        ELSIF (PS_OPTION = 'COMMISSIONING_RULE') THEN
  OPEN KT_COMMISSION('BANK', PS_INSTITUTION);

            FETCH KT_COMMISSION INTO    KT_COMMISSION_RECORDS_BANK;

            CLOSE KT_COMMISSION;

  OPEN KT_COMMISSION('COMPANY', PS_INSTITUTION);

            FETCH KT_COMMISSION INTO    KT_COMMISSION_RECORDS_COMPANY;

            CLOSE KT_COMMISSION;

            -- if bank and company use intervals
            IF (KT_COMMISSION_RECORDS_BANK.USE_INTERVALS = 'E'
                 AND KT_COMMISSION_RECORDS_COMPANY.USE_INTERVALS = 'E') THEN
                OPEN PC_REF FOR
                      SELECT   T1.USE_INTERVAL,
                                  T1.FROM_AMOUNT,
                                  T1.TO_AMOUNT,
                                  CASE
                                      WHEN T1.COMMISSION_TYPE = 'RATE'
                                             AND T2.COMMISSION_TYPE = 'RATE' THEN
                                          (T1.COMMISSION_VALUE + T2.COMMISSION_VALUE)
                                          || ' %'
                                      WHEN T1.COMMISSION_TYPE = 'RATE'
                                             AND T2.COMMISSION_TYPE = 'AMOUNT' THEN
                                              T1.COMMISSION_VALUE
                                          || ' % + '
                                          || T2.COMMISSION_VALUE
                                          || ' KGS'
                                      WHEN T1.COMMISSION_TYPE = 'AMOUNT'
                                             AND T2.COMMISSION_TYPE = 'RATE' THEN
                                              T1.COMMISSION_VALUE
                                          || ' KGS + '
                                          || T2.COMMISSION_VALUE
                                          || ' %'
                                      ELSE
                                          (T1.COMMISSION_VALUE + T2.COMMISSION_VALUE)
                                          || ' KGS'
                                  END
                                      AS COMMISSION_VALUE
                         FROM   (SELECT    'Y' AS USE_INTERVAL,
                                                A.BEGINING_AMOUNT AS FROM_AMOUNT,
                                                A.ENDING_AMOUNT AS TO_AMOUNT,
                                                A.COMMISSION_TYPE,
                                                CASE A.COMMISSION_TYPE
                                                    WHEN 'AMOUNT' THEN A.COMMISSION_AMOUNT
                                                    ELSE A.COMMISSION_RATE
                                                END
                                                    AS COMMISSION_VALUE
                                      FROM    CBS_USIP_COMMISSION_AMOUNT A
                                     WHERE    A.COMPANY_ID = PS_INSTITUTION
                                                AND A.COMMISSION_TYPE_FOR = 'BANK') T1,
                                  (SELECT    'Y' AS USE_INTERVAL,
                                                B.BEGINING_AMOUNT AS FROM_AMOUNT,
                                                B.ENDING_AMOUNT AS TO_AMOUNT,
                                                B.COMMISSION_TYPE,
                                                CASE B.COMMISSION_TYPE
                                                    WHEN 'AMOUNT' THEN B.COMMISSION_AMOUNT
                                                    ELSE B.COMMISSION_RATE
                                                END
                                                    AS COMMISSION_VALUE
                                      FROM    CBS_USIP_COMMISSION_AMOUNT B
                                     WHERE    B.COMPANY_ID = PS_INSTITUTION
                                                AND B.COMMISSION_TYPE_FOR = 'COMPANY') T2
                        WHERE         T1.USE_INTERVAL = T2.USE_INTERVAL
                                  AND T1.FROM_AMOUNT = T2.FROM_AMOUNT
                                  AND T1.TO_AMOUNT = T2.TO_AMOUNT
                    ORDER BY   FROM_AMOUNT ASC;
            ELSIF (KT_COMMISSION_RECORDS_BANK.USE_INTERVALS = 'E' AND KT_COMMISSION_RECORDS_COMPANY.USE_INTERVALS = 'H') THEN
                IF (KT_COMMISSION_RECORDS_COMPANY.COMMISSION_TYPE = 'RATE') THEN
                    OPEN PC_REF FOR
                          SELECT   'Y' AS USE_INTERVAL,
                                      A.BEGINING_AMOUNT AS FROM_AMOUNT,
                                      A.ENDING_AMOUNT AS TO_AMOUNT,
                                      CASE A.COMMISSION_TYPE
                                          WHEN 'RATE' THEN
                                              (A.COMMISSION_RATE
                                                + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_RATE)
                                              || ' %'
                                          ELSE
                                              A.COMMISSION_AMOUNT || ' KGS + '
                                              + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_RATE
                                              || ' %'
                                      END
                                          AS COMMISSION_VALUE
                             FROM   CBS_USIP_COMMISSION_AMOUNT A
                            WHERE   A.COMPANY_ID = PS_INSTITUTION
                                      AND A.COMMISSION_TYPE_FOR = 'BANK'
                        ORDER BY   FROM_AMOUNT ASC;
                ELSE
                    OPEN PC_REF FOR
                          SELECT   'Y' AS USE_INTERVAL,
                                      A.BEGINING_AMOUNT AS FROM_AMOUNT,
                                      A.ENDING_AMOUNT AS TO_AMOUNT,
                                      CASE A.COMMISSION_TYPE
                                          WHEN 'AMOUNT' THEN
                                              (A.COMMISSION_AMOUNT
                                                + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_AMOUNT)
                                              || ' KGS'
                                          ELSE
                                              A.COMMISSION_RATE || ' % + '
                                              + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_AMOUNT
                                              || ' KGS'
                                      END
                                          AS COMMISSION_VALUE
                             FROM   CBS_USIP_COMMISSION_AMOUNT A
                            WHERE   A.COMPANY_ID = PS_INSTITUTION
                                      AND A.COMMISSION_TYPE_FOR = 'BANK'
                        ORDER BY   FROM_AMOUNT ASC;
                END IF;
            ELSIF (KT_COMMISSION_RECORDS_BANK.USE_INTERVALS = 'H' AND KT_COMMISSION_RECORDS_COMPANY.USE_INTERVALS = 'E') THEN
                IF (KT_COMMISSION_RECORDS_BANK.COMMISSION_TYPE = 'RATE') THEN
                    OPEN PC_REF FOR
                          SELECT   'Y' AS USE_INTERVAL,
                                      A.BEGINING_AMOUNT AS FROM_AMOUNT,
                                      A.ENDING_AMOUNT AS TO_AMOUNT,
                                      CASE A.COMMISSION_TYPE
                                          WHEN 'RATE' THEN
                                              (A.COMMISSION_RATE
                                                + KT_COMMISSION_RECORDS_BANK.COMMISSION_RATE)
                                              || ' %'
                                          ELSE
                                                  A.COMMISSION_AMOUNT
                                              || ' KGS + '
                                              + KT_COMMISSION_RECORDS_BANK.COMMISSION_RATE
                                              || ' %'
                                      END
                                          AS COMMISSION_VALUE
                             FROM   CBS_USIP_COMMISSION_AMOUNT A
                            WHERE   A.COMPANY_ID = PS_INSTITUTION
                                      AND A.COMMISSION_TYPE_FOR = 'COMPANY'
                        ORDER BY   FROM_AMOUNT ASC;
                ELSE
                    OPEN PC_REF FOR
                          SELECT   'Y' AS USE_INTERVAL,
                                      A.BEGINING_AMOUNT AS FROM_AMOUNT,
                                      A.ENDING_AMOUNT AS TO_AMOUNT,
                                      CASE A.COMMISSION_TYPE
                                          WHEN 'AMOUNT' THEN
                                              (A.COMMISSION_AMOUNT
                                                + KT_COMMISSION_RECORDS_BANK.COMMISSION_AMOUNT)
                                              || ' KGS'
                                          ELSE
                                              A.COMMISSION_RATE || ' % + '
                                              + KT_COMMISSION_RECORDS_BANK.COMMISSION_AMOUNT
                                              || ' KGS'
                                      END
                                          AS COMMISSION_VALUE
                             FROM   CBS_USIP_COMMISSION_AMOUNT A
                            WHERE   A.COMPANY_ID = PS_INSTITUTION
                                      AND A.COMMISSION_TYPE_FOR = 'COMPANY'
                        ORDER BY   FROM_AMOUNT ASC;
                END IF;
            ELSE                                                            -- both do not use inservals
                IF (KT_COMMISSION_RECORDS_BANK.COMMISSION_TYPE = 'RATE'
                     AND KT_COMMISSION_RECORDS_COMPANY.COMMISSION_TYPE = 'AMOUNT') THEN
                    OPEN PC_REF FOR
                        SELECT    'N' AS USE_INTERVAL,
                                    '' AS FROM_AMOUNT,
                                    '' AS TO_AMOUNT,
                                        KT_COMMISSION_RECORDS_BANK.COMMISSION_RATE
                                    || ' % + '
                                    || KT_COMMISSION_RECORDS_COMPANY.COMMISSION_AMOUNT
                                    || ' KGS'
                                        AS COMMISSION_VALUE
                          FROM    DUAL;
                ELSIF (KT_COMMISSION_RECORDS_BANK.COMMISSION_TYPE = 'AMOUNT' AND KT_COMMISSION_RECORDS_COMPANY.COMMISSION_TYPE = 'RATE') THEN
                    OPEN PC_REF FOR
                        SELECT    'N' AS USE_INTERVAL,
                                    '' AS FROM_AMOUNT,
                                    '' AS TO_AMOUNT,
                                        KT_COMMISSION_RECORDS_BANK.COMMISSION_AMOUNT
                                    || ' KGS + '
                                    || KT_COMMISSION_RECORDS_COMPANY.COMMISSION_RATE
                                    || ' %'
                                        AS COMMISSION_VALUE
                          FROM    DUAL;
                ELSIF (KT_COMMISSION_RECORDS_BANK.COMMISSION_TYPE = 'RATE' AND KT_COMMISSION_RECORDS_COMPANY.COMMISSION_TYPE = 'RATE') THEN
                    OPEN PC_REF FOR
                        SELECT    'N' AS USE_INTERVAL,
                                    '' AS FROM_AMOUNT,
                                    '' AS TO_AMOUNT,
                                    (KT_COMMISSION_RECORDS_BANK.COMMISSION_RATE
                                     + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_RATE)
                                    || ' %'
                                        AS COMMISSION_VALUE
                          FROM    DUAL;
                ELSE
                    OPEN PC_REF FOR
                        SELECT    'N' AS USE_INTERVAL,
                                    '' AS FROM_AMOUNT,
                                    '' AS TO_AMOUNT,
                                    (KT_COMMISSION_RECORDS_BANK.COMMISSION_AMOUNT
                                     + KT_COMMISSION_RECORDS_COMPANY.COMMISSION_AMOUNT)
                                    || ' KGS'
                                        AS COMMISSION_VALUE
                          FROM    DUAL;
                END IF;
            END IF;
        --E-O-M ernestk 03032014 cqdb00000527 - commissioning rule for tahsilat tanim
        ELSIF (PS_OPTION = 'GET_FIELDS_INFO') THEN
            OPEN PC_REF FOR
                SELECT    PKG_TAHSILAT_ISLEMLERI.KURUM_MIN_DIGIT_AL (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.KURUM_MAX_DIGIT_AL (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.KURUM_DIGIT_MESAJ_AL (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.KURUM_MIN_PAYMENT_AMOUNT_AL (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.KURUM_MAX_PAYMENT_AMOUNT_AL (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.TELEFON_NO_ZORUNLU_MU (
                                PS_INSTITUTION
                            ),
                            PKG_TAHSILAT_ISLEMLERI.TESISAT_NO_ZORUNLU_MU (
                                PS_INSTITUTION
                            )
                  FROM    DUAL;
        END IF;

        RETURN LS_RETURNCODE;
    EXCEPTION
        WHEN OTHERS THEN
            LOG_AT ('GetPaymentServices', SQLERRM);
    END;
   FUNCTION GetCreatedPayments (ps_option        IN     VARCHAR2,
                                ps_payment_id    IN     VARCHAR2,
                                ps_person_id     IN     VARCHAR2,
                                ps_customer_id   IN     VARCHAR2,
                                pc_ref              OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN
      OPEN pc_ref FOR SELECT   SYSDATE FROM DUAL;

      IF (ps_option = 'LATEST')
      THEN
         OPEN pc_ref FOR
              SELECT   payment_id,
                       islem_no tx_no,
                       sira_no order_no,
                       kurum_kodu institution_code,
                       DECODE (telefon_alan_kod,
                               NULL, telefon_no,
                               telefon_alan_kod || ' - ' || telefon_no)
                          telefon_no,
                       DECODE (service_kodu,
                               NULL, kurum_ozel_no,
                               service_kodu || ' - ' || kurum_ozel_no)
                          service_no,
                       tutar amount,
                       TO_CHAR (tahsilat_tarihi, 'YYYYMMDD') payment_date,
                       hesap_no account_no,
                       abone_adi description,
                       isim_unvan name_desc
                FROM   CBS_TAHSILAT
               WHERE   tahsilat_tarihi >= pkg_muhasebe.onceki_banka_tarihi_bul
                       AND durum_kodu = 'ACIK'
                       AND MUSTERI_NO = ps_customer_id
                       AND pkg_tahsilat_islemleri.Kurum_iptal_max_datetime (
                             kurum_kodu,
                             tahsilat_saati
                          ) >= SYSDATE
            ORDER BY   payment_id DESC;
      ELSIF (ps_option = 'GET_PAYMENTS')
      THEN
         OPEN pc_ref FOR
              SELECT   payment_id,
                       islem_no tx_no,
                       sira_no order_no,
                       kurum_kodu institution_code,
                       DECODE (telefon_alan_kod,
                               NULL, telefon_no,
                               telefon_alan_kod || ' - ' || telefon_no)
                          telefon_no,
                       DECODE (service_kodu,
                               NULL, kurum_ozel_no,
                               service_kodu || ' - ' || kurum_ozel_no)
                          service_no,
                       tutar amount,
                       TO_CHAR (tahsilat_tarihi, 'YYYYMMDD') payment_date,
                       hesap_no account_no,
                       abone_adi description,
                       isim_unvan name_desc
                FROM   CBS_TAHSILAT
               WHERE   tahsilat_tarihi >= pkg_muhasebe.onceki_banka_tarihi_bul
                       AND durum_kodu = 'ACIK'
                       AND MUSTERI_NO = ps_customer_id
                       AND INSTR (ps_payment_id,
                                  ',' || TO_CHAR (payment_id) || ',') > 0
                       AND pkg_tahsilat_islemleri.Kurum_iptal_max_datetime (
                             kurum_kodu,
                             tahsilat_saati
                          ) >= SYSDATE
            ORDER BY   payment_id DESC;

      ELSIF (ps_option='GET_CANCELLED_PAYMENTS') THEN
        OPEN pc_ref FOR
            SELECT  payment_id, islem_no tx_no, sira_no order_no, kurum_kodu institution_code,
                    DECODE(telefon_alan_kod,NULL,telefon_no,telefon_alan_kod || ' - ' || telefon_no) telefon_no ,
                    DECODE(service_kodu,NULL,kurum_ozel_no,service_kodu || ' - ' || kurum_ozel_no) service_no,
                    tutar  amount, TO_CHAR(tahsilat_tarihi,'YYYYMMDD') payment_date,
                    hesap_no account_no,abone_adi description,isim_unvan name_desc
            FROM CBS_TAHSILAT
            WHERE MUSTERI_NO = ps_customer_id
            AND   INSTR(ps_payment_id, ',' || TO_CHAR(payment_id) || ',')>0
            ORDER BY payment_id DESC;
      END IF;

      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         LOG_AT ('GetCreatedPayments', SQLERRM);
   END;

   FUNCTION GetPaymentINQ (ps_customer_id   IN     VARCHAR2,
                           ps_group_code IN VARCHAR2,
                           ps_subgroup_code IN VARCHAR2,
                           ps_institution   IN     VARCHAR2,
                           ps_start_date    IN     VARCHAR2,
                           ps_end_date      IN     VARCHAR2,
                           ps_lang IN VARCHAR2,

                           pc_ref              OUT CursorReferenceType)
      RETURN VARCHAR2
   IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN

   IF ps_lang='RUS' THEN
       OPEN pc_ref FOR
             SELECT   TO_CHAR(A.YARATILDIGI_TARIH,'YYYYMMDD HH24:MI:SS'),
                      A.KURUM_GRUP_KOD,
                      A.KURUM_KODU,
                      NVL (A.KURUM_OZEL_NO, A.TELEFON_ALAN_KOD || A.TELEFON_NO)
                         MOBILESERVICE,
                      A.TUTAR,
                      A.ACIKLAMA,
                      (SELECT ACIKLAMA_2 FROM CBS_USIP_DURUM_KODLARI B WHERE B.DURUM_KODU=A.DURUM_KODU) DURUM_KODU,
                      TO_CHAR(A.IPTAL_FIS_YARATILDIGI_TARIH,'YYYYMMDD HH24:MI:SS'),
                      A.ISLEM_NO
               FROM   CBS_TAHSILAT A
              WHERE   A.MUSTERI_NO = TO_NUMBER(ps_customer_id)
                      AND A.kurum_kodu = NVL (ps_institution, kurum_kodu)
                      AND A.KURUM_GRUP_KOD=NVL (ps_group_code, KURUM_GRUP_KOD)
                      AND A.KURUM_ALT_GRUP_KOD=NVL (ps_subgroup_code, KURUM_ALT_GRUP_KOD)
                      AND TRUNC(A.YARATILDIGI_TARIH) BETWEEN NVL (TO_DATE(ps_start_date,'YYYYMMDD'),
                                                         A.yaratildigi_tarih)
                                                AND  NVL (TO_DATE(ps_end_date,'YYYYMMDD'),
                                                          A.yaratildigi_tarih) ORDER BY yaratildigi_tarih DESC ;

   ELSE
    OPEN pc_ref FOR
             SELECT   TO_CHAR(A.YARATILDIGI_TARIH,'YYYYMMDD HH24:MI:SS'),
                      A.KURUM_GRUP_KOD,
                      A.KURUM_KODU,
                      NVL (A.KURUM_OZEL_NO, A.TELEFON_ALAN_KOD || A.TELEFON_NO)
                         MOBILESERVICE,
                      A.TUTAR,
                      A.ACIKLAMA,
                      (SELECT aciklama FROM CBS_USIP_DURUM_KODLARI B WHERE B.DURUM_KODU=A.DURUM_KODU) DURUM_KODU,
                      TO_CHAR(A.IPTAL_FIS_YARATILDIGI_TARIH,'YYYYMMDD HH24:MI:SS'),
                      A.ISLEM_NO
               FROM   CBS_TAHSILAT A
              WHERE   A.MUSTERI_NO = TO_NUMBER(ps_customer_id)
                      AND A.kurum_kodu = NVL (ps_institution, kurum_kodu)
                      AND A.KURUM_GRUP_KOD=NVL (ps_group_code, KURUM_GRUP_KOD)
                      AND A.KURUM_ALT_GRUP_KOD=NVL (ps_subgroup_code, KURUM_ALT_GRUP_KOD)
                      AND TRUNC(A.YARATILDIGI_TARIH) BETWEEN NVL (TO_DATE(ps_start_date,'YYYYMMDD'),
                                                         A.yaratildigi_tarih)
                                                AND  NVL (TO_DATE(ps_end_date,'YYYYMMDD'),
                                                          A.yaratildigi_tarih) ORDER BY yaratildigi_tarih DESC ;

   END IF;



      RETURN ls_returncode;
   EXCEPTION
      WHEN OTHERS
      THEN
         LOG_AT ('GetPaymentINQ', SQLERRM);
         RETURN '999';

   END;

   FUNCTION GetAccountsForUsipPayments(pn_musteri_no IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
      ls_returncode   VARCHAR2 (3) := '000';
   BEGIN

        OPEN pc_ref FOR
        SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
               external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD
          FROM   CBS_vw_hesap_izleme
         WHERE       musteri_no = TO_NUMBER(pn_musteri_no)
                 --AND pkg_hesap.Kullanilabilir_Bakiye_Al (hesap_no) > 0
                 AND durum_kodu = 'A'
                 AND hesap_no NOT IN (SELECT   ana_hesap_no
                                        FROM   CBS_HESAP_ORTAK_BILGI
                                       WHERE   STATUS = 'ACTIVE'  AND ortaklik_tipi<>'OY')
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al;
          RETURN ls_returncode;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ls_returncode := '503';
         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         Log_At ('GetAccountsForUsipPayments', SQLERRM);
         ls_returncode := '999';
         RETURN ls_returncode;
   END;

--B-O-M ernestk 03032014 cqdb00000527 - calculate commission for usip service
/******************************************************************************
    Name        :calculate_ip_commission
    Prepared By : Ernest Kuttubaev
    Date:         :09.10.2013
    Purpose     : for calculation of tahsilat commission for amount by kurum tanim
******************************************************************************/
FUNCTION CALCULATE_IP_COMMISSION (
    PS_INSTITUTION   IN        VARCHAR2,
    PS_AMOUNT          IN        VARCHAR2,
    PS_LANG              IN        VARCHAR2,
    PC_REF                  OUT CURSORREFERENCETYPE
)
    RETURN VARCHAR2 IS

    LS_RETURNCODE           VARCHAR2 (3) := '000';
    LN_AMOUNT               NUMBER := TO_NUMBER (REPLACE (PS_AMOUNT, ',', ''), '99999999999.99') ;
    LN_BANK_COMMISSION      NUMBER := 0; --ernestk 14052014 cqdb00000524 default to zero
    LN_COMPANY_COMMISSION   NUMBER := 0; --ernestk 14052014 cqdb00000524 default to zero

    CURSOR KT_COMMISSION
    IS
        SELECT    A.KURUM_KODU,
                    A.USE_INTERVALS_FOR_COMPANY,
                    A.USE_INTERVALS_FOR_BANK,
                    A.COMMISSION_TYPE_BANK,
                    A.COMMISSION_TYPE_COMPANY,
                    A.COMMISSION_RATE_BANK,
                    A.COMMISSION_RATE_COMPANY,
                    A.COMMISSION_AMOUNT_BANK,
                    A.COMMISSION_AMOUNT_COMPANY
          FROM    CBS_TAHSILAT_KURUM_TANIM A
         WHERE    A.KURUM_KODU = PS_INSTITUTION;

    CURSOR KTI_COMMISSION (
        FOR_TYPE                      VARCHAR2
    )
    IS
        SELECT    *
          FROM    CBS_USIP_COMMISSION_AMOUNT A
         WHERE         A.COMPANY_ID = PS_INSTITUTION
                    AND A.BEGINING_AMOUNT <= LN_AMOUNT
                    AND A.ENDING_AMOUNT >= LN_AMOUNT
                    AND A.COMMISSION_TYPE_FOR = FOR_TYPE;

    KTR_COMMISSION             KT_COMMISSION%ROWTYPE;
    KTIR_COMMISSION            KTI_COMMISSION%ROWTYPE;
BEGIN
    OPEN PC_REF FOR SELECT     SYSDATE FROM DUAL;


    OPEN KT_COMMISSION;

    FETCH KT_COMMISSION INTO    KTR_COMMISSION;

    CLOSE KT_COMMISSION;

    IF KTR_COMMISSION.USE_INTERVALS_FOR_BANK = 'E' THEN
      OPEN KTI_COMMISSION('BANK');

        FETCH KTI_COMMISSION INTO     KTIR_COMMISSION;

        IF KTI_COMMISSION%FOUND THEN
            IF KTIR_COMMISSION.COMMISSION_TYPE = 'RATE' THEN
                LN_BANK_COMMISSION    :=
                    (KTIR_COMMISSION.COMMISSION_RATE * LN_AMOUNT) / 100;
            ELSE
                LN_BANK_COMMISSION    := KTIR_COMMISSION.COMMISSION_AMOUNT;
            END IF;
        END IF;

        CLOSE KTI_COMMISSION;
    ELSE
        IF KTR_COMMISSION.COMMISSION_TYPE_BANK = 'RATE' THEN
            LN_BANK_COMMISSION    :=
                (KTR_COMMISSION.COMMISSION_RATE_BANK * LN_AMOUNT) / 100;
        ELSE
            LN_BANK_COMMISSION    := KTR_COMMISSION.COMMISSION_AMOUNT_BANK;
        END IF;
    END IF;

    IF KTR_COMMISSION.USE_INTERVALS_FOR_COMPANY = 'E' THEN
      OPEN KTI_COMMISSION('COMPANY');

        FETCH KTI_COMMISSION INTO     KTIR_COMMISSION;

        IF KTI_COMMISSION%FOUND THEN
            IF KTIR_COMMISSION.COMMISSION_TYPE = 'RATE' THEN
                LN_COMPANY_COMMISSION    :=
                    (KTIR_COMMISSION.COMMISSION_RATE * LN_AMOUNT) / 100;
            ELSE
                LN_COMPANY_COMMISSION    := KTIR_COMMISSION.COMMISSION_AMOUNT;
            END IF;
        END IF;

        CLOSE KTI_COMMISSION;
    ELSE
        IF KTR_COMMISSION.COMMISSION_TYPE_COMPANY = 'RATE' THEN
            LN_COMPANY_COMMISSION    :=
                (KTR_COMMISSION.COMMISSION_RATE_COMPANY * LN_AMOUNT) / 100;
        ELSE
            LN_COMPANY_COMMISSION    :=
                KTR_COMMISSION.COMMISSION_AMOUNT_COMPANY;
        END IF;
    END IF;

    OPEN PC_REF FOR
        SELECT    (nvl(LN_BANK_COMMISSION,0) + nvl(LN_COMPANY_COMMISSION, 0)) FROM DUAL;--ernestk 14052014 cqdb00000524 cqdb if null return 0

    RETURN LS_RETURNCODE;
EXCEPTION
    WHEN OTHERS THEN
        LS_RETURNCODE     := '999';
        LOG_AT ('calculate_ip_commission', LS_RETURNCODE, SQLERRM);
        RETURN LS_RETURNCODE;
END;
--B-O-M ernestk 03032014 cqdb00000527 - calculate commission for usip service

/******************************************************************************
   NAME        : FUNCTION getPaymentCodeExplanation
   Prepared By : Ernest Kuttubaev
   Date        : 14.02.2014
   Purpose     : to get the explanation of the payment code
******************************************************************************/
FUNCTION getPaymentCodeExplanation( ps_payment_code     IN VARCHAR2,
                                    ps_lang_cd          IN VARCHAR2) RETURN VARCHAR2
IS
    ls_payment_explanation  VARCHAR2(200) := '';
BEGIN

    SELECT  CASE
            WHEN ps_lang_cd='RUS' THEN aciklama_rus
            ELSE aciklama_ing
            END
    INTO    ls_payment_explanation
    FROM    CBS.CBS_PAYMENT_CODE
    WHERE   kod=ps_payment_code;

    RETURN ls_payment_explanation;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '';
    WHEN OTHERS THEN
        Log_At('GetPaymentCodeExplanation', SQLERRM);
        RETURN '';
END;
--B-O-M ernestk cqdb00000824 add inquiry invoices and get invoice functions
/*******************************************************************************
        Name            :inquiryDDSInvoices
  Prepared By :Ernest Kuttubaev
     Date:         :20.12.2013
     Purpose      :To get tbl_invoices filtered by passed params
*******************************************************************************/
FUNCTION INQUIRYDDSINVOICES (
    PS_CUSTOMER_ID           IN        VARCHAR2,
    PS_VALUEDATE_START      IN        VARCHAR2,
    PS_VALUEDATE_END          IN        VARCHAR2,
    PS_DEBIT_ACCOUNT_NO      IN        VARCHAR2,
    PS_CREDIT_ACCOUNT_NO   IN        VARCHAR2,
    PS_AMOUNT                  IN        VARCHAR2,
    PS_STATUS                  IN        VARCHAR2,
    PC_REF                          OUT CURSORREFERENCETYPE
)
    RETURN VARCHAR2
IS
    LS_QUERY           VARCHAR2 (2000);
    LS_CONDITION      VARCHAR2 (500);
    LS_RETURN_CODE   VARCHAR2 (3) := '000';
BEGIN
    PKG_SOA_DDS.REFRESH_INVOICE_STATUSES (PS_CUSTOMER_ID);

    LS_QUERY         :=
        'SELECT   id,
                            customer_id,
                            file_upload_id,
                            invoice_no,
                            TO_CHAR(invoice_date,''YYYYMMDD''),
                            customer_okpo,
                            customer_inn,
                            customer_sfkr,
                            customer_bank_bic,
                            customer_name,
                            customer_debit_account_no,
                            customer_bank_name,
                            beneficiar_name,
                            beneficiar_credit_account_no,
                            beneficiar_account_no,
                            beneficiar_bank_bic,
                            beneficiar_bank_name,
                            payment_code,
                            payment_details,
                            amount,
                            status,
                            created_by,
                            TO_CHAR(created_at, ''YYYYMMDD''),
                            tx_ref_id,
                            amount_in_words,
                            alloc_reference,
                            customer_ref_id,
                            tran_cd,
                            currency,
                            error_code,
                            error_desc,
                            payment_method,
                            TO_CHAR(value_date,''YYYYMMDD'')
                FROM        CORPINT.TBL_INVOICE';

    LS_CONDITION    := 'WHERE customer_id=''' || PS_CUSTOMER_ID || '''';

    IF (PS_VALUEDATE_START IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' invoice_date>=to_date('''
                || PS_VALUEDATE_START
                || ''', ''YYYYMMDD'')';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND invoice_date>=to_date('''
                || PS_VALUEDATE_START
                || ''', ''YYYYMMDD'')';
        END IF;
    END IF;

    IF (PS_VALUEDATE_END IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' invoice_date<=to_date('''
                || PS_VALUEDATE_END
                || ''', ''YYYYMMDD'')';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND invoice_date<=to_date('''
                || PS_VALUEDATE_END
                || ''', ''YYYYMMDD'')';
        END IF;
    END IF;

    IF (PS_DEBIT_ACCOUNT_NO IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' customer_debit_account_no='''
                || PS_DEBIT_ACCOUNT_NO
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND customer_debit_account_no='''
                || PS_DEBIT_ACCOUNT_NO
                || '''';
        END IF;
    END IF;

    IF (PS_CREDIT_ACCOUNT_NO IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' beneficiar_credit_account_no='''
                || PS_CREDIT_ACCOUNT_NO
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND beneficiar_credit_account_no='''
                || PS_CREDIT_ACCOUNT_NO
                || '''';
        END IF;
    END IF;

    IF (PS_AMOUNT IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' amount='''
                || TO_NUMBER (PS_AMOUNT, '9,999,999,999,999.9999')
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND amount='''
                || TO_NUMBER (PS_AMOUNT, '9,999,999,999,999.9999')
                || '''';
        END IF;
    END IF;

    IF (PS_STATUS IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' lower(status)='''
                || LOWER (PS_STATUS)
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND lower(status)='''
                || LOWER (PS_STATUS)
                || '''';
        END IF;
    END IF;

    IF LS_CONDITION = 'WHERE' THEN
        LS_QUERY   := LS_QUERY || ' order by created_at desc';
    ELSE
        LS_QUERY   :=
            LS_QUERY || ' ' || LS_CONDITION || '  order by created_at desc';
    END IF;


    OPEN PC_REF FOR LS_QUERY;

    RETURN LS_RETURN_CODE;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '888';
    WHEN OTHERS THEN
        RETURN '999';
END;

/*******************************************************************************
     Name            :getDDSInvoice
     Prepared By :Ernest Kuttubaev
     Date:         :20.12.2013
     Purpose      :To get tbl_invoice data by invoice id
*******************************************************************************/
FUNCTION GETDDSINVOICE (PS_CUSTOMER_ID   IN        VARCHAR2,
                                PS_INVOICE_ID      IN        VARCHAR2,
                                PC_REF                  OUT CURSORREFERENCETYPE)
    RETURN VARCHAR2
IS
    LS_RETURN_CODE   VARCHAR2 (3) := '000';
BEGIN
    PKG_SOA_DDS.REFRESH_INVOICE_STATUSES (PS_CUSTOMER_ID);

    OPEN PC_REF FOR
        SELECT    ID,
                    CUSTOMER_ID,
                    FILE_UPLOAD_ID,
                    INVOICE_NO,
                    TO_CHAR (INVOICE_DATE, 'YYYYMMDD'),
                    CUSTOMER_OKPO,
                    CUSTOMER_INN,
                    CUSTOMER_SFKR,
                    CUSTOMER_BANK_BIC,
                    CUSTOMER_NAME,
                    CUSTOMER_DEBIT_ACCOUNT_NO,
                    CUSTOMER_BANK_NAME,
                    BENEFICIAR_NAME,
                    BENEFICIAR_CREDIT_ACCOUNT_NO,
                    BENEFICIAR_ACCOUNT_NO,
                    BENEFICIAR_BANK_BIC,
                    BENEFICIAR_BANK_NAME,
                    PAYMENT_CODE,
                    PAYMENT_DETAILS,
                    AMOUNT,
                    STATUS,
                    CREATED_BY,
                    TO_CHAR (CREATED_AT, 'YYYYMMDD'),
                    TX_REF_ID,
                    AMOUNT_IN_WORDS,
                    ALLOC_REFERENCE,
                    CUSTOMER_REF_ID,
                    TRAN_CD,
                    CURRENCY,
                    ERROR_CODE,
                    ERROR_DESC,
                    PAYMENT_METHOD,
                    TO_CHAR (VALUE_DATE, 'YYYYMMDD')
          FROM    CORPINT.TBL_INVOICE
         WHERE    CUSTOMER_ID = PS_CUSTOMER_ID
                    AND ID = TO_NUMBER (PS_INVOICE_ID, '9999999999999999');

    RETURN LS_RETURN_CODE;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '888';
    WHEN OTHERS THEN
        RETURN '999';
END;
/*******************************************************************************
    Name        :getDDSParserName
    Prepared By :Ernest Kuttubaev
    Date:       :13.03.2014
    Purpose     :to get the parser name for the give person
*******************************************************************************/
FUNCTION getDDSParserName(  pn_person_id      IN VARCHAR2,
                            ps_parser_name    OUT VARCHAR2) RETURN VARCHAR2
IS
    ls_return_code  VARCHAR2(3):='000';

BEGIN

    SELECT  parser_name INTO ps_parser_name
    FROM    corpint.tbl_dds_invparser_map
    WHERE person_id=TO_NUMBER(pn_person_id);

    RETURN ls_return_code;

    EXCEPTION
    WHEN OTHERS THEN
        log_at('pkg_soa_inquiry.getDDSParserName', SQLERRM);
        RETURN '999';
END;
--E-O-M ernestk cqdb00000824 add inquiry invoices and get invoice functions
--B-O-M ernestk 17032014 cqdb00000498 service name which should serve this user
/*******************************************************************************
    Name        :getDirectCreditingServiceName
    Prepared By :Ernest Kuttubaev
    Date:       :17.03.2014
    Purpose     :to get service name of the class that should service this user
*******************************************************************************/
FUNCTION getDirectCreditingServiceName(  pn_person_id      IN VARCHAR2,
                                         ps_service_name    OUT VARCHAR2) RETURN VARCHAR2
IS
    ls_return_code VARCHAR2(3):='000';

BEGIN

    SELECT  TBL.SERVICE_NAME INTO ps_service_name

    FROM    CORPINT.TBL_DCS_USER_SERVICE_MAP tbl
    WHERE   TBL.PERSON_ID = TO_NUMBER(pn_person_id);

    RETURN ls_return_code;



    EXCEPTION
    WHEN OTHERS THEN
        log_at('pkg_soa_inquiry.getDirectCreditingServiceName', SQLERRM);
        RETURN '999';
END;
--E-O-M ernestk 17032014 cqdb00000498 service name which should serve this user

/*******************************************************************************
    Name        :getAmountOfClearingsForOrderNumber
    Prepared By :Ernest Kuttubaev
    Date:       :03.07.2014
    Base Project : CQDB864 - UNDP channel
    Purpose     :to get the count of clearings of customer by order number
*******************************************************************************/
FUNCTION getCountOfClearings(   pn_customer_id      IN varchar2,
                                pn_person_id      IN varchar2,
                                ps_order_number    IN varchar2,
                                ps_count              OUT varchar2) return varchar2
IS
ln_txtodocount      number:=0;
ln_clearingcount    number:=0;
ls_returncode       varchar2(3):='000';
BEGIN
    select count(*) into ln_txtodocount
    from    corpint.tbl_txtodo td
    where   td.CUSTOMER_ID = TO_NUMBER(pn_customer_id)
            and td.trancd in ('CLEARING', 'GROSS')
            and td.field18=ps_order_number;


    select count(*) into ln_clearingcount
    from    cbs.cbs_clearing_islem clr
    where   clr.musteri_no=to_number(pn_customer_id)
            and clr.ref_no=ps_order_number;

   ps_count := ln_txtodocount + ln_clearingcount;

   return ls_returncode;
exception
    when others then
        return '999';
END;
/*******************************************************************************
    Name        :getCountOfBookToBooks
    Prepared By :Chyngyz Omurov
    Date:       :12.12.2014
    Base Project : cq1264
    Purpose     :to get the count of book-to-books of customer by order number
*******************************************************************************/
FUNCTION getCountOfBookToBooks(   pn_customer_id      IN varchar2,
                                pn_person_id      IN varchar2,
                                ps_order_number    IN varchar2,
                                ps_count              OUT varchar2) return varchar2
IS
ln_txtodo_count      number:=0;
ln_booktobook_count    number:=0;
ls_returncode       varchar2(3):='000';
BEGIN

    select count(*) into ln_txtodo_count
    from    corpint.tbl_txtodo td
    where   td.CUSTOMER_ID = TO_NUMBER(pn_customer_id)
            and td.trancd in ('B2BHVL', 'B2OBHVL')
            and td.field18=ps_order_number;

    select count(*) into ln_booktobook_count
    from CBS.CBS_VIRMAN_ISLEM b2b
    where PKG_HESAP.HESAPTANMUSTERINOAL(B2B.BORC_HESAP_NO) = pn_customer_id
    and upper(B2B.REF_NO) = 'I' || ps_order_number;

   ps_count := ln_txtodo_count + ln_booktobook_count;

   return ls_returncode;
exception
    when others then
        return '999';
END;

/*******************************************************************************
    Name        : FUNCTION getCreditCardDebt
    Prepared By : Adilet Kachkeev
    Date:       : 18.07.2014
    Base Project : CQDB954 - DKIB Notification Credit Card
    Purpose     : To get the debt information on credit card for particular customer
*******************************************************************************/
FUNCTION getCreditCardDebt(ps_customer_id IN varchar2,
                                              ps_date in varchar2,
                                              pc_ref         OUT CursorReferenceType) return varchar2
IS
   ls_returncode VARCHAR2(3):='60';
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_Principal VARCHAR2(100);
    ls_LoanInterest VARCHAR2(100);
    ls_DefaultInterest VARCHAR2(100);
    ls_Commissions VARCHAR2(100);
    ls_Tax VARCHAR2(100);
    ls_Total VARCHAR2(100);
    ls_InterestRate VARCHAR2(100);

    url_web VARCHAR2(200 CHAR);
BEGIN
    pkg_parametre.deger('PASTDUE_DEBT_LINK', url_web);
    serviceUrl := url_web;

    BEGIN
        namespace := 'http://services.demirbank.kg/';
        methodName := 'getCardDebtInfo';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';


        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'mustno', 'xsd:string', ps_customer_id);
        Pkg_Soap.add_parameter(req, 'todaysdate', 'xsd:string', ps_date);

        --call web service, and get response
         resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
        result := resp.doc.getstringval();
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newParser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'getCardDebtInfoResponse/getCardDebtInfoResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueOf(l_n,'Principal',ls_Principal);
        dbms_xslprocessor.valueOf(l_n,'LoanInterest',ls_LoanInterest);
        dbms_xslprocessor.valueOf(l_n,'DefaultInterest',ls_DefaultInterest);
        dbms_xslprocessor.valueOf(l_n,'Commissions',ls_Commissions);
        dbms_xslprocessor.valueOf(l_n,'Tax',ls_Tax);
        dbms_xslprocessor.valueOf(l_n,'Total',ls_Total);
        dbms_xslprocessor.valueOf(l_n,'InterestRate',ls_InterestRate);

        OPEN pc_ref FOR
            SELECT ls_Principal, ls_LoanInterest, ls_DefaultInterest, ls_Commissions, ls_Tax, ls_Total, ls_InterestRate FROM DUAL;

        result := resp.doc.getclobval();

    EXCEPTION
        WHEN OTHERS THEN
            result := SQLERRM;
            ls_returncode:='9999';
            log_at('pkg_soa_inquiry.getCreditCardDebt', SQLERRM);
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    END;

    return ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION getWsTaxInfo
    Prepared By : Almas Nurkhozhayev
    Date:       : 01.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : get info from tax house with Tax Identification Number
*******************************************************************************/
FUNCTION getWsTaxInfo(ps_tin_number IN varchar2,
                      pc_ref        OUT CursorReferenceType) return varchar2 IS

    ls_returncode VARCHAR2(3):='000';

    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_osmp_txn_id VARCHAR2(100);
    ls_result VARCHAR2(100);
    ls_comment VARCHAR2(100);
    ls_field1 VARCHAR2(100);
    ls_field2 VARCHAR2(100);

    url_web VARCHAR2(200 CHAR);
BEGIN
    pkg_parametre.deger('TAX_SERVICE_URL', url_web);
    serviceUrl := url_web;

    BEGIN
        namespace := 'http://services.demirbank.kg/';
        methodName := 'CheckLocTax';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'tin', 'xsd:string', ps_tin_number);

        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
        result := resp.doc.getstringval();
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newParser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'CheckLocTaxResponse/CheckLocTaxResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueOf(l_n,'response/osmp_txn_id',ls_osmp_txn_id);
        dbms_xslprocessor.valueOf(l_n,'response/result',ls_result);
        dbms_xslprocessor.valueOf(l_n,'response/comment',ls_comment);
        dbms_xslprocessor.valueOf(l_n,'response/fields/field1',ls_field1);
        dbms_xslprocessor.valueOf(l_n,'response/fields/field2',ls_field2);

        OPEN pc_ref FOR
            SELECT ls_osmp_txn_id, ls_result, ls_comment, ls_field1, ls_field2 FROM DUAL;

    EXCEPTION
        WHEN OTHERS THEN
            result := SQLERRM;
            ls_returncode:='999'; -- AdiletK CQ5440 31.03.2016 update returncode when other exception occurs
            log_at('getWsTaxInfo', result, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    END;

    return ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION getIntParams
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : get list of data from table
*******************************************************************************/
FUNCTION getIntParams(ps_param_code IN varchar2,
                      ps_parent_id  IN varchar2,
                      ps_lang_cd    IN varchar2,
                      pc_ref        OUT CursorReferenceType) return varchar2 IS

    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        select * from corpint.TBL_INT_PARAMETRE
        where param_code = ps_param_code
        and (parent_code = ps_parent_id or parent_code is null)
        and (param_option = nvl('', param_option) or param_option is null or param_option = 'DEFAULT')
        and lang_cd = ps_lang_cd
        and status_cd = 'sENAB'
        order by param_id;

    return ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        log_at('getIntParams', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
END;

/*******************************************************************************
    Name        : FUNCTION getTaxPaymentInfo
    Prepared By : Almas Nurkhozhayev
    Date:       : 04.09.2014
    Base Project: CQ001107 - Tax payment though IB, Payment Terminal
    Purpose     : return list of payments with options
*******************************************************************************/
FUNCTION getTaxPaymentInfo(ps_customer_id IN varchar2,
                          ps_tax_type_id  IN varchar2,
                          ps_start_date   IN varchar2,
                          ps_end_date     IN varchar2,
                          ps_tx_no        IN varchar2,
                          pc_ref          OUT CursorReferenceType) return varchar2 IS

    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        select aa.*, bb.*,
            nvl((select explanation from corpint.tbl_int_parametre where param_code='TAX_REGION' and param_val=Pkg_Message.Split(bb.field5, ';', 2) and lang_cd='RUS'), '') region,
            nvl((select explanation from corpint.tbl_int_parametre where param_code='TAX_DISTRICT' and param_val=Pkg_Message.Split(bb.field5, ';', 3) and lang_cd='RUS'), '') district,
            nvl((select explanation from corpint.tbl_int_parametre where param_code='TAX_SUB_DISTRICT' and param_val=Pkg_Message.Split(bb.field5, ';', 4) and lang_cd='RUS'), '') sub_district
        from cbs_clearing aa, corpint.tbl_txtodo bb
        where bb.trancd='TAXPAYMENT'
        and aa.from_account = bb.field1
        and aa.yaratan_tx_no = bb.field18
        and bb.field5 like ps_tax_type_id || '%'
        and aa.YARATILDIGI_TARIH >= nvl2(ps_start_date, to_date(ps_start_date,'yyyymmdd'), aa.YARATILDIGI_TARIH)
        and aa.YARATILDIGI_TARIH <= nvl2(ps_end_date, to_date(ps_end_date,'yyyymmdd') + 1, aa.YARATILDIGI_TARIH)
        and aa.yaratan_tx_no = nvl(ps_tx_no, aa.yaratan_tx_no)
        order by aa.yaratan_tx_no desc;

    return ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        log_at('getIntParams', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
END;

/*******************************************************************************
    Name        : FUNCTION GetPaymentById
    Prepared By : Almas Nurkhozhayev
    Date:       : 14.11.2014
    Base Project: CQ001098 - Printing of cheques about made instant payments in Internet Banking
    Purpose     : return the only record for instant payment
*******************************************************************************/
FUNCTION GetPaymentById(ps_tx_no  IN varchar2,
                        pc_ref    OUT CursorReferenceType) return varchar2 IS

    ls_returncode VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        select to_char(AA.TAHSIL_FIS_YARATILDIGI_TARIH, 'dd.mm.yyyy'), to_char(AA.TAHSIL_FIS_YARATILDIGI_TARIH, 'hh24:mi'),
               aa.*, bb.*
        from cbs_tahsilat aa, CBS_TAHSILAT_KURUM_TANIM bb
        where AA.KURUM_KODU = BB.KURUM_KODU
        and islem_no = ps_tx_no;

    return ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        log_at('GetPaymentById', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
        return '999';
END;

/*******************************************************************************
    Name        : FUNCTION getCreditCardOverdueReport
    Prepared By : Almas Nukrhozhayev
    Date:       : 04.06.2015
    Base Project : CQDB4768 - Automatically loading report  from card system to CBS every day
    Purpose     : Get credit card overdue report
*******************************************************************************/
FUNCTION getCreditCardOverdueReport(ps_date IN varchar2,
                                    pc_ref  OUT CursorReferenceType) return varchar2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_total number := 0;

    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_rcode varchar2(100);
    ls_rdesc varchar2(100);
    ls_orCardInsertDate varchar2(100);
    ls_orNameSurname varchar2(100);
    ls_orCRMNo varchar2(100);
    ls_orCardNo varchar2(100);
    ls_orExpireDate varchar2(100);
    ls_orBranchCode varchar2(100);
    ls_orDealerCode varchar2(100);
    ls_orStatementStatus varchar2(100);
    ls_orStatementCount varchar2(100);
    ls_orCustomerStatu varchar2(100);
    ls_orCardStatus varchar2(100);
    ls_orCustomerGroup varchar2(100);
    ls_orAssignLimit varchar2(100);
    ls_orCurrency varchar2(100);
    ls_orRiscCode varchar2(100);
    ls_orTotalDebt varchar2(100);
    ls_orPrincipalDebt varchar2(100);
    ls_orCreditInterest varchar2(100);
    ls_orLatePaymentInterest varchar2(100);
    ls_orSalesTax varchar2(100);
    ls_orCutOffInterest varchar2(100);
    ls_orOtherFees varchar2(100);
    ls_orSaleOverLimit varchar2(100);
    ls_orCashOverLimit varchar2(100);
    ls_orOverLimitInterest varchar2(100);
    ls_orCardIssuingFee varchar2(100);
    ls_orAnnualFee varchar2(100);
    ls_orTransactionFee varchar2(100);
    ls_orCurrentInterest varchar2(100);
    ls_orCurrentLatePaymentInterst varchar2(100);
    ls_orCurrentCutOffInterest varchar2(100);
    ls_orInstallmentInterest varchar2(100);
    ls_orCurrentFee varchar2(100);
    ls_orCurrentTax varchar2(100);
    ls_orCurrentTotalDebt varchar2(100);
    ls_orRecordDate varchar2(100);
    ls_orEODDate varchar2(100);

BEGIN
    pkg_parametre.deger('OVERDUE_CARDS_WS_LINK', serviceUrl); -- uses same link as getting credit card debt function

    BEGIN
        namespace := 'http://services.demirbank.kg/';
        methodName := 'getOverdueCards';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';

        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'date', 'xsd:string', ps_date);

        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11_cib_clob(req, serviceUrl, soapAction);
        result := resp.doc.getclobval();
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

        l_parser := dbms_xmlparser.newParser;

        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'getOverdueCardsResponse/getOverdueCardsResult');

        FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
            l_n := dbms_xmldom.item(l_nl, cur_emp);
            ln_total := ln_total + 1;
            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueOf(l_n,'RCODE',ls_rcode);
            dbms_xslprocessor.valueOf(l_n,'RDESC',ls_rdesc);
            dbms_xslprocessor.valueOf(l_n,'orCardInsertDate', ls_orCardInsertDate);
            dbms_xslprocessor.valueOf(l_n,'orNameSurname', ls_orNameSurname);
            dbms_xslprocessor.valueOf(l_n,'orCRMNo', ls_orCRMNo);
            dbms_xslprocessor.valueOf(l_n,'orCardNo', ls_orCardNo);
            dbms_xslprocessor.valueOf(l_n,'orExpireDate', ls_orExpireDate);
            dbms_xslprocessor.valueOf(l_n,'orBranchCode', ls_orBranchCode);
            dbms_xslprocessor.valueOf(l_n,'orDealerCode', ls_orDealerCode);
            dbms_xslprocessor.valueOf(l_n,'orStatementStatus', ls_orStatementStatus);
            dbms_xslprocessor.valueOf(l_n,'orStatementCount', ls_orStatementCount);
            dbms_xslprocessor.valueOf(l_n,'orCustomerStatu', ls_orCustomerStatu);
            dbms_xslprocessor.valueOf(l_n,'orCardStatus', ls_orCardStatus);
            dbms_xslprocessor.valueOf(l_n,'orCustomerGroup', ls_orCustomerGroup);
            dbms_xslprocessor.valueOf(l_n,'orAssignLimit', ls_orAssignLimit);
            dbms_xslprocessor.valueOf(l_n,'orCurrency', ls_orCurrency);
            dbms_xslprocessor.valueOf(l_n,'orRiscCode', ls_orRiscCode);
            dbms_xslprocessor.valueOf(l_n,'orTotalDebt', ls_orTotalDebt);
            dbms_xslprocessor.valueOf(l_n,'orPrincipalDebt', ls_orPrincipalDebt);
            dbms_xslprocessor.valueOf(l_n,'orCreditInterest', ls_orCreditInterest);
            dbms_xslprocessor.valueOf(l_n,'orLatePaymentInterest', ls_orLatePaymentInterest);
            dbms_xslprocessor.valueOf(l_n,'orSalesTax', ls_orSalesTax);
            dbms_xslprocessor.valueOf(l_n,'orCutOffInterest', ls_orCutOffInterest);
            dbms_xslprocessor.valueOf(l_n,'orOtherFees', ls_orOtherFees);
            dbms_xslprocessor.valueOf(l_n,'orSaleOverLimit', ls_orSaleOverLimit);
            dbms_xslprocessor.valueOf(l_n,'orCashOverLimit', ls_orCashOverLimit);
            dbms_xslprocessor.valueOf(l_n,'orOverLimitInterest', ls_orOverLimitInterest);
            dbms_xslprocessor.valueOf(l_n,'orCardIssuingFee', ls_orCardIssuingFee);
            dbms_xslprocessor.valueOf(l_n,'orAnnualFee', ls_orAnnualFee);
            dbms_xslprocessor.valueOf(l_n,'orTransactionFee', ls_orTransactionFee);
            dbms_xslprocessor.valueOf(l_n,'orCurrentInterest', ls_orCurrentInterest);
            dbms_xslprocessor.valueOf(l_n,'orCurrentLatePaymentInterest', ls_orCurrentLatePaymentInterst);
            dbms_xslprocessor.valueOf(l_n,'orCurrentCutOffInterest', ls_orCurrentCutOffInterest);
            dbms_xslprocessor.valueOf(l_n,'orInstallmentInterest', ls_orInstallmentInterest);
            dbms_xslprocessor.valueOf(l_n,'orCurrentFee', ls_orCurrentFee);
            dbms_xslprocessor.valueOf(l_n,'orCurrentTax', ls_orCurrentTax);
            dbms_xslprocessor.valueOf(l_n,'orCurrentTotalDebt', ls_orCurrentTotalDebt);
            dbms_xslprocessor.valueOf(l_n,'orRecordDate', ls_orRecordDate);
            dbms_xslprocessor.valueOf(l_n,'orEODDate', ls_orEODDate);

            insert into cbs.CBS_CARD_OVERDUE values
            (ls_rcode, ls_rdesc, ls_orCardInsertDate, ls_orNameSurname, ls_orCRMNo,
            ls_orCardNo, ls_orExpireDate, ls_orBranchCode, ls_orDealerCode, ls_orStatementStatus,
            ls_orStatementCount, ls_orCustomerStatu, ls_orCardStatus, ls_orCustomerGroup, ls_orAssignLimit,
            ls_orCurrency, ls_orRiscCode, ls_orTotalDebt, ls_orPrincipalDebt, ls_orCreditInterest,
            ls_orLatePaymentInterest, ls_orSalesTax, ls_orCutOffInterest, ls_orOtherFees, ls_orSaleOverLimit,
            ls_orCashOverLimit, ls_orOverLimitInterest, ls_orCardIssuingFee, ls_orAnnualFee, ls_orTransactionFee,
            ls_orCurrentInterest, ls_orCurrentLatePaymentInterst, ls_orCurrentCutOffInterest, ls_orInstallmentInterest, ls_orCurrentFee,
            ls_orCurrentTax,ls_orCurrentTotalDebt, ls_orRecordDate, to_date(SUBSTR(ls_orEODDate,1,10),'YYYY.MM.DD'), user, sysdate);
        END LOOP;

        log_at('pkg_soa_inquiry.getCreditCardOverdueReport', substr(REQ.BODY, 1, 2000), substr(result, 1, 2000), ln_total);

        OPEN pc_ref FOR
            SELECT ls_returncode, ln_total FROM DUAL;

    EXCEPTION
        WHEN OTHERS THEN
            ls_returncode:='999';
            log_at('pkg_soa_inquiry.getCreditCardOverdueReport', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;

    return ls_returncode;
END;

/*******************************************************************************
    Name        : FUNCTION getNotificationInfo
    Prepared By : Adilet Kachkeev
    Date:       : 06.03.2015
    Base Project: CQ00867 - E-mail Notification
    Purpose     : get customer notification preferences
*******************************************************************************/
FUNCTION getNotificationInfo(ps_customerid IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_count      NUMBER := 0;
    no_data       EXCEPTION;
BEGIN
      OPEN pc_ref FOR SELECT '-' FROM dual;

        SELECT COUNT(*)
        INTO ln_count
        FROM cbs_customer_notification
        WHERE customer_no = to_number(ps_customerid);

        IF (ln_count= 0) THEN
            OPEN pc_ref FOR
            SELECT 'K' status, 'NOW' frequency, 'H' outflows,
                        'H' inflows, 'H' other, 'H' ads,
                        'H' email, 'H' sms, 'H' push, 'RUS' lang
            FROM dual;
        ELSE
            OPEN pc_ref FOR
            SELECT status, frequency, outflows,
                        inflows, other, ads, email, sms, push, lang
            FROM cbs_customer_notification
            WHERE customer_no = to_number(ps_customerid);
        END IF;

      RETURN ls_returncode;
EXCEPTION
         WHEN OTHERS THEN
            LOG_AT('getNotificationInfo',SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

/*******************************************************************************
    Name        : FUNCTION getWsDealerInfo
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Get information about dealer
*******************************************************************************/
FUNCTION getWsDealerInfo(ps_company_id IN varchar2,
                         ps_dealer_id IN varchar2,
                         pc_ref OUT CursorReferenceType) return varchar2
IS
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_result VARCHAR2(100);
    ls_error_code VARCHAR2(100);
    ls_error_desc VARCHAR2(100);
    ls_dealer_name VARCHAR2(100);
    ls_amount VARCHAR2(100);
    ls_currency VARCHAR2(100);
    ls_date VARCHAR2(100);
    ls_cbs_txno VARCHAR2(100);
    ls_company_txno VARCHAR2(100);
    ls_receipt_no VARCHAR2(100);

    url_web VARCHAR2(200 CHAR);

BEGIN
    pkg_parametre.deger('DEALER_SERVICE_URL', url_web);
    serviceUrl := url_web;
    namespace := 'http://services.demirbank.kg/';
    methodName := 'checkDealer';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);

    --add parameters to request
    Pkg_Soap.add_parameter(req, 'companyId', 'xsd:string', htf.escape_sc(ps_company_id));
    Pkg_Soap.add_parameter(req, 'dealerAccNo', 'xsd:string', ps_dealer_id);

    --call web service, and get response
    resp := pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
    result := resp.doc.getstringval();
    result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');

    l_parser := dbms_xmlparser.newParser;
    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getDocument(l_parser);
    l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'checkDealerResponse/checkDealerResult');
    l_n := dbms_xmldom.item(l_nl, 0);

    -- Use XPATH syntax to assign values to he elements of the collection.
    dbms_xslprocessor.valueOf(l_n,'Result',ls_result);
    dbms_xslprocessor.valueOf(l_n,'ErrorCode',ls_error_code);
    dbms_xslprocessor.valueOf(l_n,'ErrorDesc',ls_error_desc);
    dbms_xslprocessor.valueOf(l_n,'DealerName',ls_dealer_name);
    dbms_xslprocessor.valueOf(l_n,'Amount',ls_amount);
    dbms_xslprocessor.valueOf(l_n,'Currency',ls_currency);
    dbms_xslprocessor.valueOf(l_n,'Date',ls_date);
    dbms_xslprocessor.valueOf(l_n,'CbsTxNo',ls_cbs_txno);
    dbms_xslprocessor.valueOf(l_n,'CompanyTxNo',ls_company_txno);
    dbms_xslprocessor.valueOf(l_n,'ReceiptNo',ls_receipt_no);

    OPEN pc_ref FOR
        SELECT ls_result, ls_error_code, ls_error_desc, ls_dealer_name
        FROM DUAL;

    log_at('getWsDealerInfo', substr(req.body, 1, 2000), substr(result, 1, 2000));

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        log_at('getWsDealerInfo', ps_company_id||'###'||ps_dealer_id||'###'||ls_result||'###'||ls_error_code||'###'||ls_error_desc, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        --Error occured during dealer checking
        OPEN pc_ref FOR
            SELECT 'ERROR', '354', ls_error_desc, ls_dealer_name
            FROM DUAL;

        RETURN '000';
END;

/*******************************************************************************
    Name        : FUNCTION isDealerPayment
    Prepared By : Chyngyz Omurov
    Date:       : 08.12.2015
    Base Project: CQ5220 - Dealer Payments
    Purpose     : Check if dealer payment
*******************************************************************************/
FUNCTION isDealerPayment(ps_company_id IN varchar2) return NUMBER
IS
    ls_provider_code    cbs.cbs_tahsilat_kurum_tanim.provider_code%type;
    ls_dealer_providers CBS_PARAMETRE.DEGER%TYPE;
BEGIN
   ls_provider_code := pkg_tahsilat_islemleri.Kurum_provider_code_al(ps_company_id);
   pkg_parametre.deger('NOT_USIP_REPORT_SERVICE_LIST',ls_dealer_providers);

   IF  INSTR(ls_dealer_providers, ','||ls_provider_code||',')>0 then
        RETURN 1;
   END IF;

   RETURN 0;
END;

/*******************************************************************************
    Name:   getCorrespondentBank
    Prepared By:    Chyngyz Omurov
    Date:   22.02.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    get the correspondent bank details for given properties of the swift transfer
*******************************************************************************/
FUNCTION getCorrespondentBank(pn_customer_no NUMBER,
                                                             ps_currency VARCHAR2,
                                                             ps_commBank VARCHAR2,  --('B', 'O', 'G')
                                                             pc_ref OUT CursorReferenceType)  RETURN VARCHAR2
IS
    ln_tmp_count      NUMBER:=0;
    ln_type VARCHAR2(10) := ' ';
    ln_bank_custno NUMBER:=0;
    ln_bank_accno NUMBER:=0;
    ln_bank_name CORPINT.TBL_SWIFT_SETTINGS_CIB.CORRBANK_NAME%TYPE;
    ln_party_identifier CORPINT.TBL_SWIFT_SETTINGS_CIB.PARTY_IDENTIFIER%TYPE; --IBC-74 YadgarB
    ls_returncode       VARCHAR2(3):='000';
BEGIN
    --check whether customer's activity code is charity !!!!!!!!!!!
    SELECT count (*)
    INTO ln_tmp_count
    FROM cbs_musteri m
    WHERE m.MUSTERI_NO = pn_customer_no AND m.FINANS_KOD = '25'; ---!!!!!!!!!!!!!!!!!!! ADD NEW FINANS KOD TO CBS_FINANS_KODLARI FOR "PUBLIC FUNDS AND CHARITY ORGANIZATIONS AND REPLACE 66666 WITH ITS CODE!!!!!!!!!!!1

    --DETERMINE TYPE


    /*IF NVL(ln_tmp_count, 0) <> 0 THEN --CUSTOMER IS PUBLIC FUND OR CHARITY ORGANIZATION
        ln_type := 'CHARITYORG';
    ELS*/IF UPPER(TRIM(ps_commBank)) IN ('B', 'O', 'G') THEN
        ln_type :=  UPPER(TRIM(ps_commBank));
    END IF;

    SELECT CORRBANK_CUSTNO, CORRBANK_ACCNO, CORRBANK_NAME, PARTY_IDENTIFIER  --IBC-74 YadgarB added PARTY_IDENTIFIER
    INTO ln_bank_custno, ln_bank_accno, ln_bank_name, ln_party_identifier
    FROM CORPINT.TBL_SWIFT_SETTINGS_CIB
    WHERE TYPE = DECODE(ln_type, 'CHARITYORG', 'CHARITYORG', 'B', 'BEN', 'O', 'OUR', 'G', 'GOUR', 'NOSUCHTYPE')
    AND CURRENCY = UPPER(TRIM(ps_currency));

    OPEN pc_ref FOR SELECT ln_bank_custno CUSTNO, ln_bank_accno ACCNO, ln_bank_name NAME, TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'DD/MM/YYYY') BANKDATE, ln_party_identifier PARTY_ID FROM DUAL;

    IF ln_bank_custno = NULL OR ln_bank_custno = 0 OR ln_bank_accno = NULL OR ln_bank_accno = 0 THEN
        RETURN '779'; --Correspondent Bank is not defined for this type of transfer! Please contact Bank.
    END IF;

    RETURN ls_returncode;
    EXCEPTION
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT ' ' CUSTNO, ' ' ACCNO, ' ' NAME, TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD') BANKDATE FROM DUAL;
            log_at('swiftcib', 'pkg_soa_inquiry.getCorrespondentBank', 'Error pn_customer_no='||pn_customer_no||' ps_currency=' || ps_currency||' ps_commBank=' || ps_commBank, SQLERRM);
            RETURN  '779';
END;

/*******************************************************************************
    Name:   getPaymentCodesCIB
    Prepared By:    Chyngyz Omurov
    Date:   24.02.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:    get the payment codes for Corp IB
*******************************************************************************/
FUNCTION getPaymentCodesCIB(pn_group_code NUMBER,
                                                         ps_lang VARCHAR2,
                                                         pc_ref OUT CursorReferenceType)  RETURN VARCHAR2
IS
    ls_returncode       VARCHAR2(3):='000';
BEGIN

    OPEN pc_ref FOR
        SELECT id || DECODE(stat_code, NULL, '', '#'||stat_code || '#' ||DECODE(UPPER(TRIM(ps_lang)), 'ENG', name, name_rus) ||'#' ||name), stat_code, /*DECODE(stat_code, NULL, '', stat_code) ||' - '|| */DECODE(UPPER(TRIM(ps_lang)), 'ENG', name, name_rus)
        FROM CBS_STATISTICAL_CODES_CIB
        WHERE parent_id = pn_group_code;

    RETURN ls_returncode;

EXCEPTION
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT ' ', ' ', ' '  FROM DUAL;
            log_at('swiftcib pkg_soa_inquiry.getPaymentCodesCIB', 'Error pn_group_code='||pn_group_code||' ps_lang=' || ps_lang, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN  '999';
END;

/*******************************************************************************
    Name:   getSwiftValueDate
    Prepared By:    Chyngyz Omurov
    Date:   04.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:   get the earliest value date for swift (according to customer group: special or standard)
*******************************************************************************/

FUNCTION getSwiftValueDate(pn_customer_id NUMBER,
                                                    pn_person_id NUMBER,
                                                    ps_date_selected VARCHAR2, --'DD/MM/YYYY'
                                                    ps_check VARCHAR2 DEFAULT 'N',
                                                    ps_currency VARCHAR2,
                                                    ps_commBank VARCHAR2, --B O G (ben, our, gour)
                                                    ps_value_date OUT VARCHAR2
                                                    ) RETURN VARCHAR2
IS
   ls_returncode       VARCHAR2(3):='000';
   ln_date_selected DATE;
   ln_earliest_value_date DATE;
   v_day number; --aisuluud cq5205 25102016

   ls_current_time VARCHAR2(5); --current time hh24:mm
   ln_current_hour NUMBER := 0; --current hour hh
   ln_current_minute NUMBER := 0; -- current minute mm

   ls_thr_time VARCHAR2(5); --threshold time hh24:mm
   ln_thr_hour NUMBER := 0; --threshold hour hh
   ln_thr_minute NUMBER := 0; -- threshold minute mm

   ls_group VARCHAR2(1) := 'N';

   pc_ref CursorReferenceType;
   ls_corrBankCountry CBS_UYRUK_KODLARI.UYRUK_KODU%TYPE;
   ln_corrBankHoliday NUMBER;

   ln_corrBankCustNo NUMBER;
   ln_corrBankAccNo NUMBER;
   ls_corrBankName VARCHAR2(2000);
   ls_dummyDate VARCHAR2(20);
   ln_party_identifier CORPINT.TBL_SWIFT_SETTINGS_CIB.PARTY_IDENTIFIER%TYPE; --IBC-74 YadgarB
   ls_corrBankReturn VARCHAR2(5);
BEGIN

    ln_earliest_value_date := PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL; --!!!!SHOULD BE CHANGED BELOW ACCORDING TO CUSTOMER GROUP (STANDARD OR SPECIAL)

    ls_current_time :=  TO_CHAR(SYSDATE, 'HH24:MI');

    ln_current_hour := pkg_message.SPLIT(ls_current_time,':', 0);
    ln_current_minute := pkg_message.SPLIT(ls_current_time,':', 1);

     BEGIN
        SELECT SPECIAL_TIME INTO ls_group
        FROM CORPINT.TBL_SWIFT_SPECIAL_CUSTOMER
        WHERE CUSTOMER_ID = pn_customer_id;
        EXCEPTION
            WHEN OTHERS THEN
            ls_group := 'N';
    END;

    IF ls_group = 'N' THEN ---for standard customers
        Pkg_Parametre.deger('4003_CIB_STANDARD_TIME',ls_thr_time);
    ELSIF ls_group =  'S' THEN ---for special customers
        Pkg_Parametre.deger('4003_CIB_SPECIAL_TIME',ls_thr_time);
    ELSIF ls_group = 'V' THEN ---for vip customers
         Pkg_Parametre.deger('4003_CIB_VIP_TIME',ls_thr_time);
    END IF;


     ln_thr_hour := pkg_message.SPLIT(ls_thr_time,':', 0);
     ln_thr_minute := pkg_message.SPLIT(ls_thr_time,':', 1);

     log_at('swiftcib pkg_soa_inquiry.getSwiftValueDate', 'current time ='|| ln_current_hour||':'||ln_current_minute||', threshold time ='|| ln_thr_hour||':'||ln_thr_minute);

     IF ln_current_hour < ln_thr_hour OR (ln_current_hour = ln_thr_hour AND ln_current_minute <= ln_thr_minute) THEN -- customer can select today's bank date
        ln_earliest_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
     ELSE --next bank date can be selected at earliest
        ln_earliest_value_date := PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL;
     END IF;

     --BOM aisuluud cq5205 25102016
     select count(*) into v_day from cbs_working_weekend
            where weekend = ln_earliest_value_date
            and is_report_weekend = 1;

            if v_day > 0 then
            ln_earliest_value_date :=PKG_TARIH.ILERI_IS_GUNU_REPORT (ln_earliest_value_date);
            end if;
      --EOM aisuluud cq5205 25102016

    ps_value_date := TO_CHAR(ln_earliest_value_date,'DD/MM/YYYY');

    IF ps_check = 'Y' THEN

        BEGIN
          ln_date_selected := TO_DATE(ps_date_selected, 'DD/MM/YYYY');

          --BOM aisuluud cq5205 05102016
                    select count(*) into v_day from cbs_working_weekend
                    where weekend = ln_date_selected
                    and is_report_weekend = 1;

                    if v_day > 0 then
                    ln_earliest_value_date :=PKG_TARIH.ILERI_IS_GUNU_REPORT (ln_date_selected);
                    end if;
          --EOM aisuluud cq5205  05102016

            IF ln_date_selected < ln_earliest_value_date THEN --selected date is earlier than allowed value date
                ls_returncode := 778;
            ELSIF  Pkg_Tarih.gun_ozellik(ln_date_selected)=1 THEN --selected date is non-working day for Bank
                ls_returncode := 778;
            END IF;

             --check for non-working days in corr.bank's country
            ls_corrBankReturn := PKG_SOA_INQUIRY.GETCORRESPONDENTBANK(pn_customer_id, ps_currency, ps_commBank, pc_ref);

            IF ls_corrBankReturn = '000' THEN --corr.bank is defined

                FETCH pc_ref INTO ln_corrBankCustNo, ln_corrBankAccNo, ls_corrBankName, ls_dummyDate, ln_party_identifier;

                SELECT  M.UYRUK_KOD INTO ls_corrBankCountry
                FROM  CBS_MUSTERI M
                WHERE M.MUSTERI_NO = ln_corrBankCustNo;

                ln_corrBankHoliday := PKG_TX4055.GET_COUNTRY_HOLIDAYS(ls_corrBankCountry, ln_date_selected);

                IF ln_corrBankHoliday = 1 THEN
                    ls_returncode:=788; --selected date is non-working day for Correspondent Bank
                END IF;

            END IF;

          EXCEPTION
                WHEN OTHERS THEN
                    ls_returncode := '778';
                    ps_value_date := TO_CHAR(PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL,'DD/MM/YYYY');
                    log_at('swiftcib 1 pkg_soa_inquiry.getSwiftValueDate', 'Error pn_customer_id='||pn_customer_id||' pn_person_id=' || pn_person_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

    END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
        log_at('swiftcib pkg_soa_inquiry.getSwiftValueDate', 'Error pn_customer_id='||pn_customer_id||' pn_person_id=' || pn_person_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ps_value_date := TO_CHAR(PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL,'DD/MM/YYYY');
        RETURN  '778';
END;


/*******************************************************************************
    Name:   getAttachedFileSwift
    Prepared By:    Chyngyz Omurov
    Date:   12.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - return name of the contract/invoice file uploaded by the customer for swift operation
                     - check if the user is authorized to view attachments
*******************************************************************************/
FUNCTION getAttachedFileSwift(pn_customer_id NUMBER,
                                            pn_person_id NUMBER,
                                            ps_txno VARCHAR2,
                                            ps_filename OUT VARCHAR2
                                           ) RETURN VARCHAR2 IS
             ls_filename VARCHAR2(200);
BEGIN

    BEGIN
        SELECT T.FIELD8 INTO ls_filename
        FROM CORPINT.TBL_TXTODO T LEFT JOIN CORPINT.TBL_PERSON P ON T.MAKERID = P.PERSON_ID
        WHERE T.TX_NO = ps_txno AND P.CUSTOMER_ID = pn_customer_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                ps_filename := '';
                RETURN '999';
    END;

    ps_filename := ls_filename;
    RETURN '000';
 EXCEPTION
    WHEN OTHERS THEN
       log_at('swiftcib pkg_soa_inquiry.getAttachedFileSwift', 'Error pn_customer_id='||pn_customer_id||' pn_person_id=' || pn_person_id||' ps_txno=' ||ps_txno, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ps_filename := '';
        RETURN  '999';
END;

/*******************************************************************************
    Name:   validateInterBankCode
    Prepared By:    Chyngyz Omurov
    Date:   12.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - validate intermediary bank bic code
*******************************************************************************/
FUNCTION validateInterBankCode(ps_bic_code VARCHAR2,
                                                            ps_dummy OUT VARCHAR2
                                           ) RETURN VARCHAR2
 IS
    ln_count NUMBER := 0;
 BEGIN

    SELECT COUNT(*) INTO ln_count
    FROM SWIFTGW.SWTBICPF  T
    WHERE UPPER(T.SBICKD) =  UPPER(ps_bic_code);

    IF ln_count = 0  THEN
        ps_dummy := 'Wrong II BIC!';
        RETURN '783';
    END IF;

    ps_dummy := 'OK!';
    RETURN '000';
 EXCEPTION
    WHEN OTHERS THEN
         log_at('swiftcib pkg_soa_inquiry.validateInterBankCode', 'Error ps_bic_code='||ps_bic_code, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ps_dummy := 'Error!';
        RETURN  '999';
END;

/*******************************************************************************
    Name:   fileUploadRequirement
    Prepared By:    Chyngyz Omurov
    Date:   27.03.2015
    Base Project:   CQ509 - SWIFT via CIB
    Purpose:  - decide whether customer must upload contract/invoice file or not
*******************************************************************************/
FUNCTION fileUploadRequired(pn_customer_id NUMBER,
                                                     ps_amount VARCHAR2, --cq5548 ChyngyzO 14.06.2016

                                                     ps_currency VARCHAR2,
                                                     ps_ben_account VARCHAR2,
                                                     ps_required OUT VARCHAR2 --'Y', or 'N'
                                           ) RETURN VARCHAR2
IS
    ln_amount_lc NUMBER := 0;
    ls_threshold_amount VARCHAR2(100);
    ln_threshold NUMBER;
    ln_count NUMBER := 0;

    ln_amount NUMBER := TO_NUMBER(ps_amount,'999999999999999.9999'); --cq5548 ChyngyzO 14.06.2016
BEGIN

    PKG_PARAMETRE.DEGER('4003_CIB_THRESHOLD_FOR_UPLOAD', ls_threshold_amount);
    ln_threshold := TO_NUMBER(ls_threshold_amount);

    ln_amount_lc := PKG_KUR.DOVIZ_DOVIZ_KARSILIK(ps_currency, PKG_GENEL.LC_AL, NULL, ln_amount, 3, NULL, NULL, 'N');

    log_at('swiftcib pkg_soa_inquiry.fileUploadRequired', 'ln_threshold='||ln_threshold||', ln_amount_lc='||ln_amount_lc);

    IF ln_amount_lc >= ln_threshold THEN
        --check if customer have sent to the same beneficiary before and uploaded file then
        ps_required := 'Y';
        SELECT COUNT(*) INTO ln_count
        FROM CORPINT.TBL_TXTODO T
           LEFT JOIN CORPINT.TBL_PERSON P ON T.MAKERID = P.PERSON_ID
        WHERE P.CUSTOMER_ID = pn_customer_id
            AND T.STATUS = 'sDONE'
            AND  T.TRANCD='SWIFT'
            AND UPPER(TRIM(T.FIELD10)) = UPPER(TRIM(ps_ben_account))
            AND LENGTH(TRIM( pkg_message.SPLIT(T.FIELD8,'###',0) )) > 0; --contract file attached
         IF ln_count > 0 THEN
            --exists previous swift(s) with same beneficiary account no, so no need for upload
            ps_required := 'N';
         ELSE
            --no similar previous swifts exist, so file upload is required
            ps_required := 'Y';
         END IF;
    ELSE
        --threshold is not exceeded, so file upload is not required (optional)
        ps_required := 'N';
    END IF;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
        log_at('swiftcib pkg_soa_inquiry.fileUploadRequired', '1='||pn_customer_id||' 2='||ln_amount||' 3='||ps_currency|| ' 4='||ps_ben_account, substr(SQLERRM,1, 2000),  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ps_required := 'Y';
        RETURN  '999';
END;


/******************************************************************************
 NAME : FUNCTION CheckBalance
 Prepared By : Chyngyz Omurov, cq509
 Date : 22.06.2015
 Purpose : Check balance with currency
******************************************************************************/
FUNCTION CheckBalance(pn_accNo IN VARCHAR2,
                                            ps_amount IN VARCHAR2,

                                            ps_currency IN VARCHAR2,
                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

 ls_returncode VARCHAR2(3):='000';
 ls_accCurrency VARCHAR(3);
 ln_equalAmount NUMBER;
 ln_amount NUMBER := TO_NUMBER(ps_amount,'999999999999999.9999'); --cq5548 ChyngyzO 14.06.2016


BEGIN

    OPEN pc_ref FOR SELECT SYSDATE FROM dual;

    ls_accCurrency := Pkg_Hesap.HesaptanDovizKoduAl(TO_NUMBER(pn_accNo));













    ln_equalAmount := Pkg_Kur.DOVIZ_DOVIZ_KARSILIK(ps_currency, ls_accCurrency,NULL,NVL(ln_amount, 0),1,NULL,NULL,'N','A');


     IF (Pkg_Hesap.Kullanilabilir_Bakiye_Al(pn_accNo) < TO_NUMBER( ln_equalAmount)) THEN
        RETURN '502';
     END IF;

 RETURN ls_returncode;
 EXCEPTION
    WHEN OTHERS THEN
        log_at('swiftcib pkg_soa_inquiry.CheckBalance', '1='||pn_accNo||' 2='||ps_amount||'#'||ln_amount||' 3='||ps_currency, substr(SQLERRM, 1, 2000), DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN  '999';
END;

/******************************************************************************
 NAME : PROCEDURE GetSwiftCommissionRates
 Prepared By : Chyngyz Omurov, cq509
 Date : 03.08.2015
 Purpose : Returns customer's swift commissions in CIB
******************************************************************************/
PROCEDURE GetSwiftCommissionRates(pn_customer_id NUMBER,
                                                             ps_account_no NUMBER,
                                                             ps_currency VARCHAR2,

                                                             ps_modul_tur VARCHAR2,
                                                             ps_product_type VARCHAR2,
                                                             ps_product_class VARCHAR2,

                                                             pn_const OUT NUMBER,
                                                             pn_prop OUT NUMBER,
                                                             pn_min OUT NUMBER,
                                                             pn_max OUT NUMBER,

                                                             pn_cdf OUT NUMBER)
IS
    ln_ben_const NUMBER:=0;
    ln_ben_prop NUMBER:=0;
    ln_ben_min NUMBER:=0;
    ln_ben_max NUMBER:=0;

    ln_our_const NUMBER:=0;
    ln_our_prop NUMBER:=0;
    ln_our_min NUMBER:=0;
    ln_our_max NUMBER:=0;

    ln_gour_const NUMBER:=0;
    ln_gour_prop NUMBER:=0;
    ln_gour_min NUMBER:=0;
    ln_gour_max NUMBER:=0;

    ln_const NUMBER:=0;
    ln_prop NUMBER:=0;
    ln_min NUMBER:=0;
    ln_max NUMBER:=0;

    ln_cdf_rate NUMBER:= 0;

    ln_cdf_rate_standard NUMBER:=0;
    ln_region NUMBER:=1;

    ln_std_prop NUMBER:=0;
    ln_std_prop_min NUMBER:=0;
    ln_std_prop_max NUMBER:=0;

    ln_std_const NUMBER:=0;
    ln_std_const_min NUMBER:=0;
    ln_std_const_max NUMBER:=0;

BEGIN

    --get region of the branch in which account was opened
    BEGIN
        select decode(B.REGION_NO, 1, 1, 2)
        INTO ln_region
        from cbs_hesap h, CBS_BOLUM b
        where H.SUBE_KODU=B.KODU and h.hesap_no= ps_account_no;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        ln_region := 1; --BISHKEK
    END;

    pkg_tx4054.Get_REGION_CDF_Rates(ps_currency, ln_region, ln_cdf_rate_standard);

    pkg_tx4052.Get_Special_Cdf_Rates(ps_currency,pn_customer_id, ln_cdf_rate,ln_ben_prop,ln_ben_const,
                                                                  ln_ben_min,ln_ben_max,ln_our_prop,ln_our_const,ln_our_min,
                                                                  ln_our_max,ln_gour_prop,ln_gour_const,ln_gour_min,ln_gour_max);

    pn_cdf := nvl(ln_cdf_rate, ln_cdf_rate_standard); --if cdf rate is not defined for this customer set standard rate

    if ps_product_class like 'CIB BEN%' then
            ln_const := ln_ben_const;
            ln_prop := ln_ben_prop;
            ln_min := ln_ben_min;
            ln_max := ln_ben_max;
    elsif ps_product_class like 'CIB OUR%' then
            ln_const := ln_our_const;
            ln_prop := ln_our_prop;
            ln_min := ln_our_min;
            ln_max := ln_our_max;
    elsif ps_product_class like 'CIB GOUR%' then
            ln_const := ln_gour_const;
            ln_prop := ln_gour_prop;
            ln_min := ln_gour_min;
            ln_max := ln_gour_max;
    end if;

     if ln_const is not null AND ln_prop is not null AND ln_min is not null AND ln_max is not null then
        pn_const := ln_const;
        pn_prop := ln_prop;
        pn_min := ln_min;
        pn_max := ln_max;
    else
    --SPECIAL COMMISSIONS NOT SET, SO TAKE STANDARD COMMISSIONS
        --proportional part
        SELECT min_tutar, max_tutar, yuzde INTO ln_std_prop_min, ln_std_prop_max, ln_std_prop
        FROM CBS_ISLEM_MASRAF_TANIM
        WHERE ISLEM_KOD=4003 AND MASRAF_KOD='IBFCTRNSFR'
                 AND MODUL_TUR_KOD=ps_modul_tur AND URUN_TUR_KOD=ps_product_type
                 AND URUN_SINIF_KOD=ps_product_class;
        --constant part
        SELECT min_tutar, max_tutar, tutar INTO ln_std_const_min, ln_std_const_max, ln_std_const
        FROM CBS_ISLEM_MASRAF_TANIM
        WHERE ISLEM_KOD=4003 AND MASRAF_KOD='IBFCTRNSF2'
                 AND MODUL_TUR_KOD=ps_modul_tur AND URUN_TUR_KOD=ps_product_type
                 AND URUN_SINIF_KOD=ps_product_class;

        pn_const :=  ln_std_const;
        pn_prop := ln_std_prop;
        pn_min := ln_std_prop_min + ln_std_const_min;
        pn_max := ln_std_prop_max + ln_std_const_max;
    end if;


    EXCEPTION
    WHEN OTHERS THEN
        log_at('swiftcib pkg_soa_inquiry.GetSwiftCommissionRates', 'pn_customer_id='||pn_customer_id||' ps_product_class='||ps_product_class, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RAISE;
END;


/******************************************************************************
 NAME : FUNCTION GetInterBankName
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns name of the intermediary bank
******************************************************************************/
FUNCTION GetInterBankName(ps_ii_bic VARCHAR2) RETURN VARCHAR2
IS
    ls_name VARCHAR2(100) := '';
BEGIN
     SELECT SUBSTR(NVL(sbictx,''), 1, 100) INTO ls_name  FROM SWIFTGW.SWTBICPF  T  WHERE sbickd=ps_ii_bic;
     RETURN ls_name;
     EXCEPTION
        WHEN OTHERS THEN
            RETURN '';
END;

/******************************************************************************
 NAME : FUNCTION GetSwiftBenBankBranch
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns branch of the beneficiary bank
******************************************************************************/
FUNCTION GetSwiftBenBankBranch(pn_tx_no NUMBER) RETURN VARCHAR2
IS
    ls_branch VARCHAR2(100) := '';
BEGIN

     select  substr(pkg_message.SPLIT(b.FIELD13,'###',2), 1, 100) INTO ls_branch
     from CBS_YPHAVALE_GIDEN_ACILIS a,
               CORPINT.TBL_TXTODO b
     where A.TX_NO=pn_tx_no and A.TODO_TXNO=B.TX_NO;

     RETURN ls_branch;
     EXCEPTION
        WHEN OTHERS THEN
            RETURN '';
END;

/******************************************************************************
 NAME : FUNCTION GetSwiftCommissionType
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns commission_type###fixed_commission###proportional_commission
                                 (commission type 'B', 'O', 'G' (BEN, OUR, GUARANTEED OUR, respectively))
 and fixed
******************************************************************************/
FUNCTION GetSwiftCommissionType(pn_tx_no NUMBER)  RETURN VARCHAR2
IS
    ls_commType VARCHAR2(2) := '';
    ln_fixed NUMBER;
    ln_proportional NUMBER;
    ln_cdf NUMBER;
    ln_salesTax NUMBER;

BEGIN

    BEGIN
     select  nvl(b.FIELD11, '') INTO ls_commType
     from CBS_YPHAVALE_GIDEN_ACILIS a,
               CORPINT.TBL_TXTODO b
     where A.TX_NO=pn_tx_no and A.TODO_TXNO=B.TX_NO;

     EXCEPTION
        WHEN OTHERS THEN
            ls_commType:= '';
     END;

     BEGIN
        SELECT NVL(M.HESAPLANAN, 0) into ln_fixed
        FROM CBS_MASRAF M
        WHERE M.ISLEM_NO=pn_tx_no and M.MASRAF_KODU='IBFCTRNSF2';

        EXCEPTION
            WHEN OTHERS THEN
                ln_fixed:= 0;
     END;

       BEGIN
        SELECT NVL(M.HESAPLANAN, 0) into ln_proportional
        FROM CBS_MASRAF M
        WHERE M.ISLEM_NO=pn_tx_no and M.MASRAF_KODU='IBFCTRNSFR';

        EXCEPTION
            WHEN OTHERS THEN
                ln_proportional:= 0;
     END;

       BEGIN
        SELECT NVL(M.HESAPLANAN, 0) into ln_cdf
        FROM CBS_MASRAF M
        WHERE M.ISLEM_NO=pn_tx_no and M.MASRAF_KODU='YPGDDALSAT';

        EXCEPTION
            WHEN OTHERS THEN
                ln_cdf:= 0;
     END;

     BEGIN
         select  nvl(pkg_message.SPLIT(b.FIELD19,'###',1), 0)  INTO ln_salesTax
         from CBS_YPHAVALE_GIDEN_ACILIS a,
                   CORPINT.TBL_TXTODO b
         where A.TX_NO=pn_tx_no and A.TODO_TXNO=B.TX_NO;

     EXCEPTION
        WHEN OTHERS THEN
            ln_salesTax:= 0;
     END;

     RETURN ls_commType||'###'||ln_fixed||'###'||ln_proportional || '###' || ln_cdf || '###' || ln_salesTax;
END;
/******************************************************************************
 NAME : FUNCTION GetSwiftMessage
 Prepared By : Chyngyz Omurov, cq509
 Date : 08.09.2015
 Purpose : Returns SWIFT message generated by SWIFT system (skyjava)
******************************************************************************/
FUNCTION GetSwiftMessage(ps_tx_no VARCHAR2,
                                                   ps_cust_no VARCHAR2,
                                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3) := '000';
    CURSOR swift_cursor  IS
        SELECT s.sadat, s.ssndr, s.srcvr, s.sblock1, s.sblock2, s.stype, s.sname, s.stransref, s.sblock4ext
        FROM swiftgw.swttrnpf s, CBS_YPHAVALE_GIDEN_ACILIS a
        WHERE S.TX_NO=A.TX_NO and  A.MUSTERI_NO=ps_cust_no and   s.ssts = 'ACK' AND s.stype IN ('101', '102', '103', '940', '950') and s.tx_no=to_number(ps_tx_no)
        order by TO_DATE(s.sadat, 'yyyyMMdd');

    ls_data         CLOB;
    ld_date         DATE;
    ls_receiver_bank_name CBS_BIC_KODLARI.BANKA_ADI%TYPE;
    ls_sender_bank_name  CBS_BIC_KODLARI.BANKA_ADI%TYPE;
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;

    FOR row_c IN swift_cursor
    LOOP
        BEGIN
             ld_date := TO_DATE(row_c.sadat, 'yyyyMMdd');

             BEGIN
                SELECT banka_adi
                INTO ls_sender_bank_name
                FROM cbs_bic_kodlari
                WHERE bic_kodu = row_c.ssndr AND ROWNUM = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    ls_sender_bank_name := row_c.ssndr;
            END;

              BEGIN
                SELECT banka_adi
                INTO ls_receiver_bank_name
                FROM cbs_bic_kodlari
                WHERE bic_kodu = row_c.srcvr AND ROWNUM = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    ls_receiver_bank_name := row_c.ssndr;
            END;

            OPEN pc_ref FOR SELECT '---------------------------------- Message Header ----------------------------------', --0
                                                         RPAD('Sender', 9) || ': ' || row_c.ssndr, --1
                                                         '           ' || ls_sender_bank_name, --2
                                                         RPAD('Receiver', 9) || ': ' || row_c.srcvr, --3
                                                         '           ' || ls_receiver_bank_name, --4
                                                         '----------------------------------- Message Text -----------------------------------', --5
                                                         to_char(row_c.sblock4ext)  --6
                        FROM dual;


        EXCEPTION
            WHEN OTHERS THEN
                Log_At('pkg_soa_inquiry.GetSwiftMessage Loop',SQLERRM);
        END;
    END LOOP;
  return ls_returncode;
 EXCEPTION
        WHEN OTHERS THEN
            ls_returncode:='999';
            log_at('pkg_soa_inquiry.GetSwiftMessage', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            return ls_returncode;
END;

--BOM CQ5453 MederT 30052016
/*******************************************************************************
    Name        : FUNCTION getCreditCardsOwned
    Prepared By : Adilet Kachkeev
    Date:       : 18.07.2014
    Base Project : CQDB1415 - Credit Card Calculator
    Purpose     : To get all credit cards owned by specified customer
*******************************************************************************/
FUNCTION getCreditCardsOwned(   ps_customer_id      IN varchar2,
                                pc_ref              OUT CursorReferenceType) return varchar2
IS
   ls_returncode VARCHAR2(3):='60';
    ln_total number := 0;
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ls_list_cards VARCHAR2(2000);
    ls_card_no VARCHAR2(100);
    ls_customer_no VARCHAR2(100);
    ls_pseudopan VARCHAR2(100); -- CQ5618 07.10.16 Adilet Kachkeev defect PCI-DSS

    url_web VARCHAR2(200 CHAR);
BEGIN
    pkg_parametre.deger('PASTDUE_DEBT_LINK', url_web);
    serviceUrl := url_web;

    BEGIN
        log_at('checkCreditCard', 0);
        namespace := 'http://services.demirbank.kg/';
        methodName := 'getCreditCardsOwned';
        soapAction := namespace || methodName;
        namespace := 'xmlns="' || namespace || '"';


        --create new request
        req := Pkg_Soap.new_request(methodName, namespace);

        --add parameters to request
        Pkg_Soap.add_parameter(req, 'musterino', 'xsd:string', ps_customer_id);
        log_at('checkCreditCard', 0.5);
        --call web service, and get response
        resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
        result := resp.doc.getstringval();
        log_at('checkCreditCard', 0.7);

        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');
        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/CardsInfo"','');


        log_at('checkCreditCard', 1, substr(result, 1, 1800), substr(result, 1800, 3600));

        l_parser := dbms_xmlparser.newParser;
        dbms_xmlparser.parseclob(l_parser, result);
        l_doc := dbms_xmlparser.getDocument(l_parser);
        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'getCreditCardsOwnedResponse/getCreditCardsOwnedResult');
        l_n := dbms_xmldom.item(l_nl, 0);

        FOR cur_emp IN 0 .. dbms_xmldom.getLength(l_nl) - 1 LOOP
            l_n := dbms_xmldom.item(l_nl, cur_emp);
            ln_total := ln_total + 1;
            -- Use XPATH syntax to assign values to he elements of the collection.
            dbms_xslprocessor.valueOf(l_n,'CardNo',ls_card_no);
            dbms_xslprocessor.valueOf(l_n,'CustomerNo',ls_customer_no);
            dbms_xslprocessor.valueOf(l_n,'Pseudopan',ls_pseudopan);

            if length(ls_customer_no) > 0 and length(ls_card_no) > 0 then
                ls_list_cards := ls_list_cards || ls_pseudopan || '!!' || ls_customer_no || ';';
            end if;

        END LOOP;

        --ls_list_cards := '1234852323255316!!95335;8585093234965384!!5943;';
        OPEN pc_ref FOR
            SELECT ls_list_cards FROM DUAL;

    log_at('checkCreditCard', 2, ls_list_cards);

    EXCEPTION
        WHEN OTHERS THEN
            ls_returncode:='999';
            log_at('pkg_soa_inquiry.getCreditCardsOwned', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    END;

    return ls_returncode;
END;

/*******************************************************************************
    Name        : PROCEDURE AutoCreditCardDebtPayment
    Prepared By : Meder Toitonov
    Date:       : 30.05.2016
    Base Project: CQDB 5453 Automatic payment of credit card debt
    Purpose     : Checks CCard debt and performs payment of this debt
*******************************************************************************/
PROCEDURE AutoCreditCardDebtPayment(pn_account_no IN NUMBER) IS
    TYPE CursorReferenceType IS REF CURSOR;
    ref_cursor CursorReferenceType;
    ref_cursor2 CursorReferenceType;
    ls_musteri_no VARCHAR2(50 CHAR);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req pkg_soap.request;
    resp pkg_soap.response;
    result CLOB;
    url_web VARCHAR2(200 CHAR);

    l_parser  dbms_xmlparser.Parser;
    l_doc     dbms_xmldom.DOMDocument;
    l_nl      dbms_xmldom.DOMNodeList;
    l_n       dbms_xmldom.DOMNode;

    ld_date DATE := pkg_muhasebe.banka_tarihi_bul - 1;
    ls_debt VARCHAR2(100);
    ln_debt NUMBER := 0;
    ln_available_balance NUMBER := 0;
    ls_list_cards VARCHAR2(2000 CHAR);
    ls_one_card VARCHAR2(50 CHAR);
    ls_resp VARCHAR2(10 CHAR);
    ls_resp2 VARCHAR2(10 CHAR);
BEGIN
    ls_musteri_no := TO_CHAR(pkg_hesap.HesaptanMusteriNoAl(pn_account_no));

    ls_resp := pkg_soa_inquiry.getCreditCardsOwned(ls_musteri_no, ref_cursor);

    IF ls_resp = '60' THEN
        FETCH ref_cursor INTO ls_list_cards;

        IF ref_cursor%NOTFOUND THEN
            close ref_cursor;
        ELSE
            IF (LENGTH(ls_list_cards) > 0) THEN
                WHILE INSTR(ls_list_cards, '!!') > 0
                LOOP
                    ls_one_card := SUBSTR(ls_list_cards, 0, INSTR(ls_list_cards, '!!') - 1);

                    pkg_parametre.deger('PASTDUE_DEBT_LINK', url_web);

                    BEGIN
                        namespace := 'http://services.demirbank.kg/';
                        methodName := 'getCCardDebtByCustomerNo';
                        soapAction := namespace || methodName;
                        namespace := 'xmlns="' || namespace || '"';

                        req := Pkg_Soap.new_request(methodName, namespace);

                        Pkg_Soap.add_parameter(req, 'pseudopan', 'xsd:string', ls_one_card); --CQ5618 07.10.16 Adilet Kachkeev defect PCI-DSS
                        Pkg_Soap.add_parameter(req, 'date', 'xsd:string', TO_CHAR(ld_date, 'YYYYMMDD'));

                        resp := Pkg_Soap.invoke_utf8_v11(req, url_web, soapAction);
                        result := resp.doc.getstringval();

                        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/"','');
                        result:= REPLACE(result,' xmlns="http://services.demirbank.kg/ResDebtInfo"','');

                        l_parser := dbms_xmlparser.newParser;
                        dbms_xmlparser.parseclob(l_parser, result);
                        l_doc := dbms_xmlparser.getDocument(l_parser);
                        l_nl := dbms_xslprocessor.selectNodes(dbms_xmldom.makeNode(l_doc),'getCCardDebtByCustomerNoResponse/getCCardDebtByCustomerNoResult');
                        l_n := dbms_xmldom.item(l_nl, 0);

                        dbms_xslprocessor.valueOf(l_n,'Total',ls_debt);

                        ln_debt := TO_NUMBER(REPLACE(ls_debt, '.', ','));

                        IF ln_debt != 0 THEN
                            ln_available_balance := pkg_hesap.kullanilabilir_bakiye_al(pn_account_no);

                            IF (ln_debt > ln_available_balance) THEN
                                ln_debt := ln_available_balance;
                            END IF;

                            ls_resp2 := pkg_int_tx.CreditCardCPaymentTx(ls_musteri_no, '', pn_account_no, ln_debt, '', ls_one_card, ref_cursor2); --CQ5618 07.10.16 Adilet Kachkeev defect PCI-DSS
                        END IF;
                    EXCEPTION
                        WHEN OTHERS THEN
                            log_at('AutoCreditCardDebtPayment LOOP', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                        END;

                    IF INSTR(ls_list_cards, ';') > 0 THEN
                        ls_list_cards := SUBSTR(ls_list_cards, INSTR(ls_list_cards, ';') + 1);
                    ELSE
                        ls_list_cards :=  '';
                    END IF;
                END LOOP;
            END IF;
            close ref_cursor;
        END IF;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        log_at('AutoCreditCardDebtPayment', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
--EOM CQ5453 MederT 30052016


/******************************************************************************
    Name: Check_B2b_Status
    Desc: Checking status of the b2b transaction (for Mobilnik)
    Prepared By:Chyngyz Omurov
    Modify Date: 06.06.2016
******************************************************************************/
FUNCTION Check_B2b_Status(pn_custno NUMBER, ps_reference_no VARCHAR2) RETURN VARCHAR2
IS
    ls_return VARCHAR2(3) := '000';
    ln_count NUMBER := 0;

    ln_tx_status VARCHAR2(20) := 'NOT_FOUND';

BEGIN

    SELECT COUNT(*) INTO ln_count
    FROM CBS_VIRMAN_ISLEM
    WHERE REF_NO = ps_reference_no
        and PKG_HESAP.HESAPTANMUSTERINOAL(BORC_HESAP_NO) = pn_custno;

    IF NVL(ln_count, 0) = 0 THEN --transaction is not created, check todo table

        SELECT COUNT(*) INTO ln_count
        FROM CORPINT.TBL_TXTODO
        WHERE TRIM(FIELD18) = TRIM(PS_REFERENCE_NO)
            AND MAKERID IN ( SELECT PERSON_ID FROM CORPINT.TBL_PERSON WHERE CUSTOMER_ID=pn_custno)
             AND trancd in ('B2OBHVL', 'B2BHVL') ;

        IF NVL(ln_count, 0) > 0 THEN

            SELECT STATUS INTO ln_tx_status
            FROM  CORPINT.TBL_TXTODO
            WHERE TRIM(FIELD18) = TRIM(PS_REFERENCE_NO)
                AND MAKERID IN ( SELECT PERSON_ID FROM CORPINT.TBL_PERSON WHERE CUSTOMER_ID=pn_custno)
                AND trancd in ('B2OBHVL', 'B2BHVL')
                AND ROWNUM = 1;

        END IF;

    ELSE

            SELECT I.DURUM INTO ln_tx_status
            FROM CBS_VIRMAN_ISLEM V
                LEFT JOIN CBS_ISLEM I ON V.TX_NO = I.NUMARA
            WHERE REF_NO = ps_reference_no
                AND PKG_HESAP.HESAPTANMUSTERINOAL(BORC_HESAP_NO) = pn_custno
                AND ROWNUM = 1;

    END IF;

    CASE ln_tx_status
        WHEN 'NOT_FOUND' THEN RETURN 'NOT_FOUND';
        WHEN 'sDONE' THEN RETURN 'DONE';
        WHEN 'sVERIFY' THEN RETURN 'WAITING_VERIFICATION';
        WHEN 'sCHECK' THEN RETURN 'WAITING_CHECK';
        WHEN 'sAPPROVE' THEN RETURN 'WAITING_APPROVE';
        WHEN 'sDELETE' THEN RETURN 'CANCELLED';
        WHEN 'P' THEN RETURN 'DONE';
        ELSE RETURN 'OTHER STATUS ('||ln_tx_status||')';
    END CASE;


EXCEPTION
   WHEN OTHERS THEN
        Log_At('getB2BStatus', SUBSTR(SQLERRM, 1, 2000), DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN '999';

END;

/*******************************************************************************
    Prepared By : Almas Nurkhozhayev
    Date:       : 09.03.2016
    Purpose     : get the list of transaction definitions with explanation
*******************************************************************************/
FUNCTION getIslemList(ps_islem_no IN VARCHAR2,
                      pc_ref OUT CursorReferenceType) return VARCHAR2 IS
    ls_returncode VARCHAR2(3) := '000';
BEGIN
    OPEN pc_ref FOR
        select * from cbs_islem_tanim
        where instr(ps_islem_no, kod) > 0;

    return ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
        log_at('getIslemList', sqlerrm, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        return '999';
END;

/*******************************************************************************
    Name        : FUNCTION getCompanyStaff
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get staff of the company
*******************************************************************************/
FUNCTION getCompanyStaff(pn_customer_no NUMBER,
                                                   pn_group_id NUMBER,
                                                   pc_ref OUT CursorReferenceType) return VARCHAR2
IS
    ls_currency VARCHAR2(5);
    pc_ref_local CursorReferenceType;
    ls_returncode VARCHAR2(3);
    ln_count NUMBER;
    ln_group_id NUMBER := pn_group_id;



BEGIN
    --TODO need to check in which currency company has salary project, then return that

    ls_returncode := PKG_SOA_INQUIRY.getSalaryCurrency(pn_customer_no, pc_ref_local);

    IF ls_returncode <> '000' THEN
        RETURN ls_returncode;
    END IF;

    FETCH pc_ref_local INTO ls_currency;

    select count(*) into ln_count
    from CORPINT.TBL_SALARY_GROUP
    where group_id = pn_group_id and  company_cust_no = pn_customer_no;

    if ln_count = 0 then
        ln_group_id := -1;
    end if;

     OPEN pc_ref FOR
        SELECT row_number() over(order by m.soyadi), --0 order
                     '', --1 branch (cannot be set because customer hasn't chosen account no)
                     '', --2 firm account (cannot be set because customer hasn't chosen account no)
                     '', --3 staff account branch (cannot be set, because staff can have more than one account opened in diff.branches)
                     to_char(H.EXTERNAL_HESAP_NO), --4 staff account no (staff can have more than one account opened in with the appropriate currency)--removed wm_contact by _GulkaiyrK
                     '', --5 amount
                     H.DOVIZ_KODU, --6 currency
                     M.ISIM, --7 name
                     M.SOYADI, --8 surname
                     M.IKINCI_ISIM, --9 patronymic
                     M.MUSTERI_NO, --10 customer no
                     to_char(H.EXTERNAL_HESAP_NO||':'||H.URUN_SINIF_KOD) product_classes   --removed wm_contact by _GulkaiyrK
        FROM CBS_MUSTERI M,
                    CBS_HESAP H
        WHERE M.MUSTERI_NO=H.MUSTERI_NO AND pn_customer_no IN (M.COMPANY_OF_THE_STAFF, M.COMPANY_OF_THE_STAFF_2, M.COMPANY_OF_THE_STAFF_3)
                     AND H.URUN_TUR_KOD = 'DEMAND DEP' AND  H.URUN_SINIF_KOD IN ('NON INT.BEARING-LC', 'NON INT.BEARING-FC', 'ELCARD NON INT.BR-LC')
                     AND H.EXTERNAL_HESAP_NO IS NOT NULL
                    AND DOVIZ_KODU = ls_currency
                     AND H.DURUM_KODU = 'A'
                    AND (ln_group_id = -1 OR H.EXTERNAL_HESAP_NO in (select staff_acc_no from corpint.tbl_salary_group_detail where group_id = ln_group_id and status='1') )
        GROUP BY M.MUSTERI_NO, M.ISIM, M.SOYADI, H.DOVIZ_KODU, M.IKINCI_ISIM, H.EXTERNAL_HESAP_NO,H.URUN_SINIF_KOD ; --H.EXTERNAL_HESAP_NO and H.URUN_SINIF_KOD added to group by -GulkaiyrK Den17


     RETURN '000';

END;

/*******************************************************************************
    Name        : FUNCTION getSalaryCurrency
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get salary currency of the company
*******************************************************************************/
FUNCTION getSalaryCurrency( pn_customer_no NUMBER,
                            pc_ref OUT CursorReferenceType) return VARCHAR2
IS
    ls_currency VARCHAR2(5);
BEGIN

    SELECT SETTINGS_VALUE
        INTO ls_currency
    FROM CORPINT.TBL_CUSTOMER_SETTINGS
    WHERE CUSTOMER_NO=pn_customer_no AND SETTINGS_CD='salary.currency' AND SETTINGS_VALUE IS NOT NULL ;

    SELECT doviz_kodu
        INTO ls_currency
    FROM CBS_DOVIZ_KODLARI
    WHERE DOVIZ_KODU=ls_currency;

    OPEN pc_ref FOR
        SELECT ls_currency FROM DUAL;

    RETURN '000';

EXCEPTION
    WHEN OTHERS THEN
        OPEN pc_ref FOR
            SELECT '' FROM DUAL;
         RETURN '791';
END;

/*******************************************************************************
    Name        : FUNCTION checkEmployeeAccount
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Check account of the employee (currency, active/not active, name/surname, etc)
*******************************************************************************/
FUNCTION checkEmployeeAccount(  pn_customer_no NUMBER,
                                ps_name VARCHAR2,
                                ps_surname VARCHAR2,
                                ps_account_no VARCHAR2, --external account no
                                pc_ref OUT CursorReferenceType) return VARCHAR2
IS
    ls_currency VARCHAR2(5);
    pc_ref_local CursorReferenceType;
    ls_returncode VARCHAR2(3);

    ls_cbs_name CBS_MUSTERI.ISIM%TYPE;
    ls_cbs_surname CBS_MUSTERI.SOYADI%TYPE;

    ln_staff_cust_no NUMBER;
    ln_count NUMBER := 0;
BEGIN

    ls_returncode := PKG_SOA_INQUIRY.getSalaryCurrency(pn_customer_no, pc_ref_local);

    IF ls_returncode <>'000' THEN
        RETURN ls_returncode;
    END IF;

    FETCH pc_ref_local INTO ls_currency;

    SELECT M.ISIM, M.SOYADI, M.MUSTERI_NO
        INTO ls_cbs_name, ls_cbs_surname, ln_staff_cust_no
    FROM CBS_MUSTERI M, CBS_HESAP H
    WHERE H.MUSTERI_NO = M.MUSTERI_NO AND H.EXTERNAL_HESAP_NO=ps_account_no
         AND H.DURUM_KODU = 'A'
            AND H.DOVIZ_KODU=ls_currency;


      SELECT COUNT(*)
        INTO ln_count
    FROM CBS_MUSTERI M
    WHERE M.MUSTERI_NO=ln_staff_cust_no AND (M.COMPANY_OF_THE_STAFF = pn_customer_no OR M.COMPANY_OF_THE_STAFF_2 = pn_customer_no OR M.COMPANY_OF_THE_STAFF_3 = pn_customer_no);
    --AzatD 22.07.2020
    IF UPPER( TRIM(REPLACE(ls_cbs_name,' ',''))) = UPPER(TRIM(ps_name)) AND UPPER( TRIM(REPLACE(ls_cbs_surname,' ','')) ) = UPPER(TRIM(ps_surname))
        OR ( UPPER(TRIM(ls_cbs_name)) = UPPER(TRIM(ps_name)) AND UPPER(TRIM(ls_cbs_surname)) = UPPER(TRIM(ps_surname)))
        THEN
        OPEN pc_ref FOR SELECT 'OK', ' ',  ln_count FROM DUAL;
    ELSE
        OPEN pc_ref FOR SELECT 'NAME_MATCH_ERROR',
                                                    UPPER(SUBSTR(ls_cbs_name, 1, 1) ||'***'|| Substr(ls_cbs_name, -1, 1) ||' / '|| SUBSTR(ls_cbs_surname, 1, 1) ||'***'|| Substr(ls_cbs_surname, -1, 1) ) ,
                                                    ln_count
                               FROM DUAL;
    END IF;

   RETURN '000';
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        OPEN pc_ref FOR
            SELECT 'ACCOUNT_DOES_NOT_EXIST', '', ln_count FROM DUAL;
        RETURN '000';
    WHEN OTHERS THEN
        OPEN pc_ref FOR
            SELECT '' FROM DUAL;
         RETURN '999';
END;


/*******************************************************************************
    Name        : FUNCTION getSalaryCommType
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get salary commission type of the company
*******************************************************************************/
FUNCTION getSalaryCommType(pn_customer_no NUMBER,
                           pc_ref OUT CursorReferenceType) return VARCHAR2
IS
    ls_commType VARCHAR2(100);
BEGIN


    SELECT SETTINGS_VALUE
        INTO ls_commType
    FROM CORPINT.TBL_CUSTOMER_SETTINGS
    WHERE CUSTOMER_NO=pn_customer_no AND SETTINGS_CD= 'salary.comm.type' AND SETTINGS_VALUE IS NOT NULL ; --comm type can be COMPANY, EMPLOYEE, FREE

    OPEN pc_ref FOR
        SELECT ls_commType FROM DUAL;

    RETURN '000';

EXCEPTION
    WHEN OTHERS THEN
        OPEN pc_ref FOR
            SELECT '' FROM DUAL;
         RETURN '792';
END;

/*******************************************************************************
    Name        : FUNCTION getSalaryFirmID
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get firm ID of the salary company
*******************************************************************************/
FUNCTION getSalaryFirmID( pn_customer_no NUMBER,
                          pc_ref OUT CursorReferenceType) return VARCHAR2
IS
    ls_firmID CBS_SALARY_PAYMENT_FIRM_DEF.FIRM_ID%TYPE;
BEGIN
    OPEN pc_ref FOR SELECT '' FROM DUAL;
    SELECT FIRM_ID
        INTO ls_firmID
    FROM   CBS_SALARY_PAYMENT_FIRM_DEF
    WHERE  FIRM_NO=pn_customer_no AND STATUS='A';

     OPEN pc_ref FOR SELECT ls_firmID FROM DUAL;
     RETURN '000';

EXCEPTION
    WHEN OTHERS  THEN
    RETURN '790';
END;


/*******************************************************************************
    Name        : FUNCTION checkSalaryValueDate
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Check value date
*******************************************************************************/
FUNCTION checkSalaryValueDate( ps_date_selected VARCHAR2,
                               ps_value_date OUT VARCHAR2) return VARCHAR2
IS
    ls_returncode       VARCHAR2(3):='000';
    ln_date_selected DATE;
    ln_earliest_value_date DATE;

    ls_current_time VARCHAR2(5); --current time hh24:mm
    ln_current_hour NUMBER := 0; --current hour hh
    ln_current_minute NUMBER := 0; -- current minute mm

    ls_thr_time VARCHAR2(5); --threshold time hh24:mm
    ln_thr_hour NUMBER := 0; --threshold hour hh
    ln_thr_minute NUMBER := 0; -- threshold minute mm

    ls_group VARCHAR2(1) := 'N';

    pc_ref CursorReferenceType;
    ls_corrBankCountry CBS_UYRUK_KODLARI.UYRUK_KODU%TYPE;
    ln_corrBankHoliday NUMBER;
BEGIN

    ln_earliest_value_date := PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL;

    ls_current_time :=  TO_CHAR(SYSDATE, 'HH24:MI');

    ln_current_hour := pkg_message.SPLIT(ls_current_time,':', 0);
    ln_current_minute := pkg_message.SPLIT(ls_current_time,':', 1);

     Pkg_Parametre.deger('2150_CIB_SALARY_TIME',ls_thr_time);

     ln_thr_hour := pkg_message.SPLIT(ls_thr_time,':', 0);
     ln_thr_minute := pkg_message.SPLIT(ls_thr_time,':', 1);

     IF ln_current_hour < ln_thr_hour OR (ln_current_hour = ln_thr_hour AND ln_current_minute <= ln_thr_minute) THEN -- customer can select today's bank date
        ln_earliest_value_date := PKG_MUHASEBE.BANKA_TARIHI_BUL;
     ELSE --next bank date can be selected at earliest
        ln_earliest_value_date := PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL;
     END IF;

    ps_value_date := TO_CHAR(ln_earliest_value_date,'DD/MM/YYYY');

    ln_date_selected := TO_DATE(ps_date_selected, 'DD/MM/YYYY');

    IF ln_date_selected < ln_earliest_value_date THEN --selected date is earlier than allowed value date
        ls_returncode := 778;
    ELSIF  Pkg_Tarih.gun_ozellik(ln_date_selected)=1 THEN --selected date is non-working day for Bank
        ls_returncode := 778;
    END IF;

    RETURN ls_returncode;

EXCEPTION
    WHEN OTHERS THEN
      log_at('pkg_soa_inquiry.checkSalaryValueDate', ' ps_date_selected='||ps_date_selected, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
       ps_value_date := TO_CHAR(PKG_MUHASEBE.SONRAKI_BANKA_TARIHI_BUL,'DD/MM/YYYY');
      RETURN  '778';
END;

/*******************************************************************************
    Name        : FUNCTION getSalaryPaymentDetails
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get Staff List of the given salary payment
*******************************************************************************/
FUNCTION getSalaryPaymentDetails( pn_todo_txno NUMBER,
                                  pn_person_id NUMBER,
                                  pn_customer_no NUMBER,
                                  pc_ref OUT CursorReferenceType) return VARCHAR2
IS

BEGIN
    OPEN pc_ref FOR
        SELECT L.ORDERING,
                     decode(L.COMPANY_ACC_NO, null, '', Pkg_Hesap.HesapSubeAl( L.COMPANY_ACC_NO)) ACC_BRANCH,
                     decode(L.COMPANY_ACC_NO, NULL, '', TO_CHAR(PKG_HESAP.External_HesapNo_Al( L.COMPANY_ACC_NO))) EXT_ACC_NO,
                     L.STAFF_ACC_NO,
                     L.AMOUNT,
                     L.CURRENCY,
                     T.FIELD11,
                     L.NAME,
                     L.SURNAME,
                     L.PATRONYMIC,
                     L.STATUS,
                     PKG_MUSTERI.SF_MUSTERI_ADI(L.COMPANY_CUST_NO),
                     to_char(SYSDATE, 'dd.mm.yyyy'),
                     T.FIELD7
        FROM CORPINT.TBL_TXTODO T,
                    CORPINT.TBL_SALARY_PAYMENT_TX L
        WHERE  T.TX_NO = L.TODO_TXNO AND  L.TODO_TXNO=pn_todo_txno
            AND
             T.CUSTOMER_ID = TO_NUMBER(pn_customer_no)
            AND  (      pn_person_id=T.MAKERID --PERSON IS MAKER
                             OR
                             pn_person_id IN (SELECT A.PERSON_ID
                                                             FROM CORPINT.TBL_PERSON_APPROVAL A
                                                             WHERE A.CHANNEL_CD='cDKBCIB' AND SUBSTR(A.AUTH_CD,6)=SUBSTR(T.AUTHCD,6)) --PERSON IS VERIFIER, CHECKER OR APPROVER
                             OR
                             pn_person_id IN (SELECT A.PERSON_ID
                                                             FROM CORPINT.TBL_PERSON_AUTH A
                                                             WHERE A.CHANNEL_CD='cDKBCIB' AND A.AUTH_CD='aVIEWSLRY') --PERSON HAS VIEW SALARY RIGHTS
                       )
        ORDER BY L.ORDERING ;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
     log_at('pkg_soa_inquiry.getSalaryPaymentDetails', ' pn_todo_txno='||pn_todo_txno ||', pn_person_id='||pn_person_id, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    RETURN '999';
END;

/*******************************************************************************
    Name        : FUNCTION getSalaryArchive
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of past salary payments
*******************************************************************************/
FUNCTION getSalaryArchive( pn_customer_no NUMBER,
                           pc_ref OUT CursorReferenceType) return VARCHAR2
IS

BEGIN

    OPEN PC_REF FOR
        SELECT T.TX_NO, to_char(T.MAKEDATE, 'dd.mm.yyyy HH24:MI'), T.FIELD2, T.FIELD3, T.FIELD7, T.FIELD11, I.DURUM--DECODE(I.DURUM, 'P', 'PROCESSED', 'WAITING')
        FROM CORPINT.TBL_TXTODO T
                    LEFT JOIN  CBS_SALARY S ON T.FIELD12=S.TX_NO
                    LEFT JOIN CBS_ISLEM I ON S.TX_NO = I.NUMARA
        WHERE TRANCD='SALARY' AND STATUS='sDONE' AND     T.CUSTOMER_ID = TO_NUMBER(PN_CUSTOMER_NO)
        ORDER BY MAKEDATE DESC;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
     log_at('pkg_soa_inquiry.getSalaryArchive', ' pn_customer_no='||PN_CUSTOMER_NO , SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    RETURN '999';
END;

/*******************************************************************************
    Name        : FUNCTION getSalaryGroupStaff
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of staff group
*******************************************************************************/
FUNCTION getSalaryGroupStaff( pn_customer_no NUMBER,
                             pn_group_id NUMBER,
                             ps_group_name VARCHAR2,
                             ps_group_staff VARCHAR2, --, , comma seperated
                             ps_action VARCHAR2,
                             pn_person_id NUMBER,
                             pc_ref      OUT CursorReferenceType,
                             pc_ref2   OUT CursorReferenceType,
                             pc_ref3    OUT CursorReferenceType,
                             pc_ref4    OUT CursorReferenceType,
                             pc_ref5    OUT CursorReferenceType) return VARCHAR2  IS PRAGMA autonomous_transaction;
   ls_currency VARCHAR2(5);
    pc_ref_local CursorReferenceType;
    ls_returncode VARCHAR2(3);
    ln_count NUMBER;

    ln_group_id NUMBER := pn_group_id;

BEGIN
       OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    ls_returncode := PKG_SOA_INQUIRY.getSalaryCurrency(pn_customer_no, pc_ref_local);

    IF ls_returncode <> '000' THEN
        RETURN ls_returncode;
    END IF;

    FETCH pc_ref_local INTO ls_currency;

    SELECT COUNT(*) INTO ln_count
    FROM CORPINT.TBL_SALARY_GROUP
    WHERE GROUP_ID = ln_group_id AND COMPANY_CUST_NO = PN_CUSTOMER_NO;

    IF ln_count = 0 and ln_group_id <> 0 THEN --group_id = 0 means creating new group
        log_at('pkg_soa_inquiry.getSalaryGroup GROUP NOT FOUND', ' pn_customer_no='||pn_customer_no||', ln_group_id='||ln_group_id );
        RETURN '799'; --'Staff salary group not found!'
    end if;

    if ps_action = 'save' and trim(ps_group_name) is null then
        RETURN '080'; --'Please, enter group name!'
    end if;

    if (ln_group_id = 0 and ps_action = 'save') and ln_count = 0 then --group_id = 0 means creating new group

        ln_group_id:=Pkg_Genel.genel_kod_al('SLRY_GROUP_ID');

        insert into corpint.tbl_salary_group(GROUP_ID, COMPANY_CUST_NO,  CREATED_DATE, CREATED_PERSON, UPDATED_DATE, UPDATED_PERSON, STATUS,  GROUP_NAME)
        values (ln_group_id, pn_customer_no, sysdate, pn_person_id, sysdate, pn_person_id, '1', ps_group_name);

    elsif (ln_group_id <> 0 and ps_action = 'save') and ln_count > 0 then

        update corpint.tbl_salary_group
        set group_name = ps_group_name, updated_date = sysdate, updated_person = pn_person_id
        where group_id = ln_group_id;

    end if;


    if ps_action = 'save' then

                --make all group staff status passive '0'
                update corpint.tbl_salary_group_detail
                set status='0', updated_date = sysdate, updated_person = pn_person_id
                where group_id=ln_group_id;


                FOR staff in ( SELECT H.EXTERNAL_HESAP_NO
                                         FROM CBS_MUSTERI M,  CBS_HESAP H
                                         WHERE  M.MUSTERI_NO=H.MUSTERI_NO AND pn_customer_no IN (M.COMPANY_OF_THE_STAFF, M.COMPANY_OF_THE_STAFF_2, M.COMPANY_OF_THE_STAFF_3 )
                                             AND H.URUN_TUR_KOD = 'DEMAND DEP' AND  H.URUN_SINIF_KOD IN ('NON INT.BEARING-LC', 'NON INT.BEARING-FC', 'ELCARD NON INT.BR-LC')
                                                     AND H.EXTERNAL_HESAP_NO IS NOT NULL
                                                     AND DOVIZ_KODU = ls_currency AND
                                                     INSTR(ps_group_staff, ','||H.EXTERNAL_HESAP_NO||',') > 0)
                LOOP

                    --check
                    select count(*) into ln_count from corpint.tbl_salary_group_detail where group_id = ln_group_id and staff_acc_no = staff.external_hesap_no;

                    if ln_count > 0 then
                        update corpint.tbl_salary_group_detail
                        set status = '1', updated_date = sysdate, updated_person = pn_person_id
                        where group_id = ln_group_id and staff_acc_no = staff.external_hesap_no;
                    else
                        insert into corpint.tbl_salary_group_detail(GROUP_ID, staff_acc_no,  CREATED_DATE, CREATED_PERSON, UPDATED_DATE, UPDATED_PERSON, STATUS)
                        values (ln_group_id, staff.external_hesap_no, sysdate, pn_person_id, sysdate, pn_person_id, '1');
                    end if;

                END LOOP;
    elsif ps_action = 'delete' then

        --make all group staff status passive '0'
        update corpint.tbl_salary_group_detail
        set status='3', updated_date = sysdate, updated_person = pn_person_id
        where group_id=ln_group_id;

        update corpint.TBL_SALARY_GROUP
        set status='3'
        where group_id=ln_group_id;

    end if;



     OPEN PC_REF FOR
        SELECT row_number() over(order by m.soyadi), --0 order
                     to_char(H.EXTERNAL_HESAP_NO), --1 staff account no (staff can have more than one account opened in with the appropriate currency)--removed wm_contact by _GulkaiyrK
                     H.DOVIZ_KODU, --2 currency
                     M.ISIM, --3 name
                     M.SOYADI, --4 surname
                     M.IKINCI_ISIM, --5 patronymic
                     M.MUSTERI_NO, --6 customer no
                     gd.staff_acc_no group_staff_accno --7
        FROM CBS_MUSTERI M,
                    CBS_HESAP H left outer join corpint.tbl_salary_group_detail gd on ( gd.group_id=ln_group_id and gd.status='1'  and H.EXTERNAL_HESAP_NO = gd.staff_acc_no) --status = '1' -> active
        WHERE
                     M.MUSTERI_NO=H.MUSTERI_NO AND pn_customer_no IN (M.COMPANY_OF_THE_STAFF, M.COMPANY_OF_THE_STAFF_2, M.COMPANY_OF_THE_STAFF_3)
                     AND H.URUN_TUR_KOD = 'DEMAND DEP' AND  H.URUN_SINIF_KOD IN ('NON INT.BEARING-LC', 'NON INT.BEARING-FC', 'ELCARD NON INT.BR-LC')
                     AND H.EXTERNAL_HESAP_NO IS NOT NULL
                     AND DOVIZ_KODU = ls_currency
         GROUP BY M.MUSTERI_NO, M.ISIM, M.SOYADI, H.DOVIZ_KODU, M.IKINCI_ISIM,  gd.staff_acc_no, H.EXTERNAL_HESAP_NO  --H.EXTERNAL_HESAP_NO added to group by -GulkaiyrK Den17
         order by m.soyadi asc;

     commit;

     OPEN pc_ref2 FOR SELECT ln_group_id FROM DUAL;

    RETURN '000';
EXCEPTION
    WHEN OTHERS THEN
    rollback;
     log_at('pkg_soa_inquiry.getSalaryGroupStaff', ' pn_customer_no='||pn_customer_no||', ln_group_id='||ln_group_id , SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
     OPEN pc_ref FOR SELECT '-' FROM dual;
      OPEN pc_ref2 FOR SELECT '-' FROM dual;
      OPEN pc_ref3 FOR SELECT '-' FROM dual;
      OPEN pc_ref4 FOR SELECT '-' FROM dual;
      OPEN pc_ref5 FOR SELECT '-' FROM dual;

    RETURN '999';

end;

/*******************************************************************************
    Name        : FUNCTION getSalaryGroups
    Prepared By : Chyngyz Omurov
    Date:       : 18.12.2015
    Base Project: CQ4960 - Automatic Salary Payments via CIB
    Purpose     : Get list of  salary groups
*******************************************************************************/
FUNCTION getSalaryGroups( pn_customer_no NUMBER,
                          pc_ref OUT CursorReferenceType) return VARCHAR2
IS

BEGIN

    OPEN pc_ref FOR
         SELECT GROUP_ID, GROUP_NAME
         FROM CORPINT.TBL_SALARY_GROUP
         WHERE STATUS = '1' AND COMPANY_CUST_NO = PN_CUSTOMER_NO;

    RETURN '000';

EXCEPTION
    WHEN OTHERS THEN
     log_at('pkg_soa_inquiry.getSalaryGroups', ' pn_customer_no='||pn_customer_no , SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    OPEN pc_ref FOR SELECT SYSDATE FROM DUAL;
    RETURN '999';
END;

/******************************************************************************
   NAME        : FUNCTION GetTimeDepReturnInterest
   Prepared By : Temirlan Talapkerov
   Date        : 11.01.2021
   Purpose     : Return of previosly paid interest amount
******************************************************************************/
FUNCTION  GetTimeDepReturnInterest(p_accountid IN VARCHAR2,
                                   pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

ls_returncode       VARCHAR2(3):='000';
ld_valor_tarihi     DATE;
ln_tutar_count      NUMBER;
noAccoutFound       EXCEPTION;
BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;

    select nvl(temdit_tarihi, valor_tarihi) into ld_valor_tarihi from cbs.cbs_hesap_vadeli where hesap_no=p_accountid;

    select count(dv_tutar) into ln_tutar_count from cbs.cbs_satir
            where HESAP_NUMARA=p_accountid
            and HESAP_TUR_KODU='VD'
            and TUR='B'
            and VALOR_TARIHI>ld_valor_tarihi;

    IF (ln_tutar_count= 0) THEN
        RAISE noAccoutFound;
    END IF;

    OPEN pc_ref FOR
        select nvl(sum(dv_tutar), 0) from cbs.cbs_satir
            where HESAP_NUMARA=p_accountid
            and HESAP_TUR_KODU='VD'
            and TUR='B'
            and VALOR_TARIHI>ld_valor_tarihi;

    RETURN ls_returncode;

EXCEPTION
    WHEN noAccoutFound THEN
        Log_At('Pkg_Soa_Account.GetTimeDepReturnInterest','503',SQLERRM);
        ls_returncode:= '503';
        RETURN ls_returncode;
    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.GetTimeDepReturnInterest','999',SQLERRM);
        ls_returncode:= '999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION INQUIRYSWIFTINVOICES
   Prepared By : Azat Dzhanybekov
   Date        : 03.03.2021
   Purpose     : Returns swift invoices
******************************************************************************/
FUNCTION INQUIRYSWIFTINVOICES (
    PS_CUSTOMER_ID           IN        VARCHAR2,
    PS_VALUEDATE_START      IN        VARCHAR2,
    PS_VALUEDATE_END          IN        VARCHAR2,
    PS_DEBIT_ACCOUNT_NO      IN        VARCHAR2,
    PS_CREDIT_ACCOUNT_NO   IN        VARCHAR2,
    PS_AMOUNT                  IN        VARCHAR2,
    PS_STATUS                  IN        VARCHAR2,
    PC_REF                          OUT CURSORREFERENCETYPE
)
    RETURN VARCHAR2
IS
    LS_QUERY           VARCHAR2 (2000);
    LS_CONDITION      VARCHAR2 (500);
    LS_RETURN_CODE   VARCHAR2 (3) := '000';
BEGIN
    PKG_SOA_DDS.REFRESH_INVOICE_STATUSES (PS_CUSTOMER_ID);
    log_at('INQUIRYSWIFTINVOICES',LS_QUERY);
    LS_QUERY         :=
        'SELECT   id,
                            customer_id,
                            file_upload_id,
                            invoice_no,
                            TO_CHAR(invoice_date,''YYYYMMDD''),
                            customer_okpo,
                            customer_inn,
                            customer_sfkr,
                            customer_bank_bic,
                            customer_name,
                            customer_debit_account_no,
                            customer_bank_name,
                            beneficiar_name,
                            beneficiar_credit_account_no,
                            beneficiar_account_no,
                            beneficiar_bank_bic,
                            beneficiar_bank_name,
                            payment_code,
                            payment_details,
                            amount,
                            status,
                            created_by,
                            TO_CHAR(created_at, ''YYYYMMDD''),
                            tx_ref_id,
                            amount_in_words,
                            alloc_reference,
                            customer_ref_id,
                            tran_cd,
                            currency,
                            error_code,
                            error_desc,
                            payment_method,
                            TO_CHAR(value_date,''YYYYMMDD''),
                            COMMISSION_ACCOUNT_NO,
                            beneficiar_country_code,
                            beneficiar_address
                FROM        CORPINT.TBL_INVOICE where currency!=''KGS''';

    LS_CONDITION    := 'AND customer_id=''' || PS_CUSTOMER_ID || '''';

    IF (PS_VALUEDATE_START IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' created_at>=to_date('''
                || PS_VALUEDATE_START
                || ''', ''YYYYMMDD'')';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND created_at>=to_date('''
                || PS_VALUEDATE_START
                || ''', ''YYYYMMDD'')';
        END IF;
    END IF;

    IF (PS_VALUEDATE_END IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' created_at<=to_date('''
                || PS_VALUEDATE_END
                || ''', ''YYYYMMDD'')';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND created_at<=to_date('''
                || PS_VALUEDATE_END
                || ''', ''YYYYMMDD'')';
        END IF;
    END IF;


/*
    IF (PS_DEBIT_ACCOUNT_NO IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' customer_debit_account_no='''
                || PS_DEBIT_ACCOUNT_NO
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND customer_debit_account_no='''
                || PS_DEBIT_ACCOUNT_NO
                || '''';
        END IF;
    END IF;

    IF (PS_CREDIT_ACCOUNT_NO IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' beneficiar_credit_account_no='''
                || PS_CREDIT_ACCOUNT_NO
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND beneficiar_credit_account_no='''
                || PS_CREDIT_ACCOUNT_NO
                || '''';
        END IF;
    END IF;

    IF (PS_AMOUNT IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' amount='''
                || TO_NUMBER (PS_AMOUNT, '9,999,999,999,999.9999')
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND amount='''
                || TO_NUMBER (PS_AMOUNT, '9,999,999,999,999.9999')
                || '''';
        END IF;
    END IF;

    IF (PS_STATUS IS NOT NULL) THEN
        IF LS_CONDITION = 'WHERE' THEN
            LS_CONDITION    :=
                    LS_CONDITION
                || ' lower(status)='''
                || LOWER (PS_STATUS)
                || '''';
        ELSE
            LS_CONDITION    :=
                    LS_CONDITION
                || ' AND lower(status)='''
                || LOWER (PS_STATUS)
                || '''';
        END IF;
    END IF;
*/
    IF LS_CONDITION = 'WHERE' THEN
        LS_QUERY   := LS_QUERY || ' order by created_at desc';
    ELSE
        LS_QUERY   :=
            LS_QUERY || ' ' || LS_CONDITION || '  order by created_at desc';
    END IF;
log_at('INQUIRYSWIFTINVOICES',LS_QUERY);

    OPEN PC_REF FOR LS_QUERY;

    RETURN LS_RETURN_CODE;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN '888';
    WHEN OTHERS THEN
        RETURN '999';
END;
/*******************************************************************************
    Name:   get payment  code name
    Prepared By:    Omurchiev Esen
    Date:   28.05.2021
    Base Project:   CQ509 - SWIFTINPUL
    Purpose:    get the payment code name for Colla swift_txt
*******************************************************************************/
FUNCTION getPaymentCodeName(id_payment NUMBER,
                                                   pn_payment_code NUMBER,
                                                   pc_ref OUT CursorReferenceType)  RETURN VARCHAR2
IS
    ls_returncode       VARCHAR2(3):='000';
BEGIN
    OPEN pc_ref FOR
        SELECT NAME
        FROM CBS_STATISTICAL_CODES_CIB
        WHERE STAT_CODE =pn_payment_code and ID=id_payment ;

    RETURN ls_returncode;

EXCEPTION
        WHEN OTHERS THEN
            OPEN pc_ref FOR SELECT ' ', ' ', ' '  FROM DUAL;
            log_at('swiftcib pkg_soa_inquiry.getPaymentCodeName', 'Error pn_payment_code='||pn_payment_code, SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN  '999';
END;
/******************************************************************************
NAME        : FUNCTION Check_Inn_Phone
Prepared By : Temirlan Talapkerov
Date        : 11.03.2021
Purpose     : If the phone number is correct, need to return the customer number and full name
******************************************************************************/
FUNCTION Check_Inn_Phone(ps_inn_no varchar2,
                            ps_phone_number varchar2,
                            ps_code_country varchar2,
                            ps_code_operator varchar2,
                            pn_customer_no OUT number,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS

    ls_returncode VARCHAR2(3):='000';
    ln_customer_no NUMBER;
    ln_type_code VARCHAR2(20);
    
    ln_country_code VARCHAR2(50);
    ln_area_code VARCHAR(50);
    ln_phone_no VARCHAR(50);
    
    
    ln_full_phone VARCHAR(150);
       
    not_retail boolean := false;
    
    notFound       EXCEPTION;
   
    phone_exists NUMBER := 0;
    

BEGIN
    OPEN pc_ref FOR SELECT '-' FROM dual;
        
    begin

        SELECT NVL(M.MUSTERI_NO,0), M.MUSTERI_TIPI_KOD INTO ln_customer_no, ln_type_code
        FROM cbs.cbs_musteri M
            JOIN cbs.cbs_hesap H ON M.MUSTERI_NO = H.MUSTERI_NO
        WHERE UPPER(ps_inn_no) in (UPPER(replace(M.VERGI_NO,' ','')),UPPER(replace(M.PASAPORT_NO,' ', '')),UPPER(regexp_replace(M.PASAPORT_NO,'#|-|№| ','')),UPPER(replace(M.NUFUS_CUZDANI_SERI_NO,' ',''))) --changed ESEN --ADILK CBS-815
            AND M.MUSTERI_TIPI_KOD in('1')
            AND H.DURUM_KODU = 'A'
        group by m.musteri_no,M.MUSTERI_TIPI_KOD;

    exception
        when NO_DATA_FOUND then
            not_retail:= true;
    end;

    if not_retail then 
    
     SELECT NVL(M.MUSTERI_NO,0), M.MUSTERI_TIPI_KOD INTO ln_customer_no, ln_type_code
        FROM cbs.cbs_musteri M
            JOIN cbs.cbs_hesap H ON M.MUSTERI_NO = H.MUSTERI_NO
        WHERE UPPER(ps_inn_no) in (UPPER(replace(M.VERGI_NO,' ','')),UPPER(replace(M.PASAPORT_NO,' ', '')),UPPER(regexp_replace(M.PASAPORT_NO,'#|-|№| ','')),UPPER(replace(M.NUFUS_CUZDANI_SERI_NO,' ',''))) --changed ESEN --ADILK CBS-815
            AND M.MUSTERI_TIPI_KOD in('2')
            AND H.DURUM_KODU = 'A'
        group by m.musteri_no,M.MUSTERI_TIPI_KOD;
        
        if ln_customer_no is not null and ln_type_code = '2' then 
        
            ls_returncode := '772';
            
        end if;
        
    end if;
    
    pn_customer_no := ln_customer_no;
   
    if(ln_customer_no is not null) then 
    
    	SELECT nvl ((
			SELECT 1
			FROM cbs.cbs_musteri_adres
			WHERE MUSTERI_NO =  ln_customer_no
			AND ULKE_GSM_KOD || GSM_ALAN_KOD || GSM_NO = ps_phone_number
			UNION
			SELECT 1
			FROM cbs.cbs_musteri_adres
			WHERE MUSTERI_NO =  ln_customer_no
			AND ULKE_GSM_KOD_2 || GSM_ALAN_KOD_2 || GSM_NO_2 = ps_phone_number
			UNION
			SELECT 1
			FROM cbs.cbs_musteri_adres
			WHERE MUSTERI_NO = ln_customer_no
			AND ULKE_GSM_KOD_3 || GSM_ALAN_KOD_3 || GSM_NO_3 = ps_phone_number
			), 0) INTO phone_exists FROM dual;
        
        if(phone_exists = 1) THEN
             
             OPEN pc_ref FOR
             SELECT soyadi, isim, ikinci_isim
                 FROM CBS.CBS_MUSTERI 
             WHERE MUSTERI_NO =  ln_customer_no
                 AND MUSTERI_TIPI_KOD = ln_type_code
                 AND GECERLILIK_TARIHI > to_date (sysdate);
        else
            RAISE notFound; 
        end if;
        
    
    end if;
   
    RETURN ls_returncode;

EXCEPTION

    WHEN notFound THEN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        RETURN '888';
    WHEN NO_DATA_FOUND THEN
        OPEN pc_ref FOR SELECT '-' FROM dual;
        RETURN '888';
    WHEN TOO_MANY_ROWS  then
        RETURN '771';
    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.Check_Inn_Phone', 'OTHERS', SQLERRM);
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
        OPEN pc_ref FOR SELECT '-' FROM dual;
        RETURN '999';
END;

/******************************************************************************
NAME        : FUNCTION Check_Join_acount
Prepared By : Omurchiev Esen
Date        : 21.05.2021
Purpose     : if the client has joint accounts we return false otherwise true
******************************************************************************/
FUNCTION Check_Join_account(pn_customer_no in number,
                                                result_card OUT varchar2) RETURN VARCHAR2 IS
    ls_returncode VARCHAR2(3):='000';
    count_1 number;
    debit_card_status VARCHAR2(7);
    credit_card_status VARCHAR2(7);
BEGIN

    select  count(*)  into count_1 from cbs_hesap where musteri_no = pn_customer_no and DURUM_KODU = 'A';



    begin

        select  distinct(decode (STATUS , 'A','Active','Closed')) into debit_card_status   from CBS_DEBIT_CARD where  customer_no= pn_customer_no  and STATUS='A';

    EXCEPTION
        when NO_DATA_FOUND then
            debit_card_status:='null';
    end;

    begin

        select distinct(decode (DURUM_KODU , 'A','Active','Closed')) into credit_card_status  from CBS_HESAP_KREDI where URUN_TUR_KOd='RT-CARD' and URUN_SINIF_KOD='CREDIT CARD-LC'
        and DURUM_KODU='A' and MUSTERI_NO= pn_customer_no;

    EXCEPTION
        when NO_DATA_FOUND then
            credit_card_status:='null';
    end;

  if (count_1 > 0) then
        ls_returncode := '000';


        if(debit_card_status = 'Active' or credit_card_status = 'Active') then
            result_card := '001';
        else
           result_card :='991' ;
        end if;
    else
       ls_returncode := '999';
    end if;

    RETURN ls_returncode;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        Log_At('Pkg_Soa_Account.Check_Inn_Phone', 'NO_DATA_FOUND', SQLERRM);
        RETURN '888';
    WHEN TOO_MANY_ROWS  then
        RETURN '771';
    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.Check_Join_account', 'OTHERS', SQLERRM);
        RETURN '777';
END;

/******************************************************************************
   NAME        : FUNCTION Get All Additional Accounts
   Prepared By : Esen Omurchiev
   Date        : 24.11.2021
   Purpose     : Customer Accounts Information will be returned
******************************************************************************/
FUNCTION  GetAllAdditionalAccounts(p_option IN VARCHAR2,
                      p_customerid IN VARCHAR2,
                      p_personid  IN VARCHAR2,
                      p_channelcd IN VARCHAR2,
                      pc_ref OUT CursorReferenceType,
                      pc_ref2 OUT CursorReferenceType,
                      pc_ref3 OUT CursorReferenceType,
                      pc_ref4 OUT CursorReferenceType,
                      pc_ref5 OUT CursorReferenceType) RETURN VARCHAR2 IS

ls_vergi_no VARCHAR2(20);
ls_returncode VARCHAR2(3):='000';
ls_account_count NUMBER := 0;
noAccoutFound        EXCEPTION;


BEGIN
  OPEN pc_ref FOR SELECT '-' FROM dual;
  OPEN pc_ref2 FOR SELECT '-' FROM dual;
  OPEN pc_ref3 FOR SELECT '-' FROM dual;
  OPEN pc_ref4 FOR SELECT '-' FROM dual;
  OPEN pc_ref5 FOR SELECT '-' FROM dual;

            Log_At('Pkg_Soa_Account.GetAccounts12', replace(p_customerid, ',', ''), SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            
            SELECT VERGI_NO INTO ls_vergi_no FROM CBS_MUSTERI WHERE MUSTERI_NO = replace(p_customerid, ',', '');


            IF ls_vergi_no is NOT NULL THEN


                 IF p_option =  'ALL' THEN
                    SELECT COUNT(*)
                    INTO ls_account_count
                    FROM CBS_vw_hesap_izleme a
                    WHERE musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                    AND a.DURUM_KODU='A';
                    --AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid));
                    IF (ls_account_count= 0) THEN
                        RAISE noAccoutFound;
                    END IF;

            -----------------------------Current Account----------------------------
                 OPEN pc_ref FOR

                    select Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                            MUSTERI_NO,
                            ISIM_UNVAN,
                            sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                            HESAP_NO,
                            DOVIZ_KODU,
                            NVL(BAKIYE,0),
                            NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                            1 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2),
                            EXTERNAL_HESAP_NO,
                            URUN_SINIF_KOD,
                            MUSTERI_TIPI_KOD,
                            Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
                            case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
                    from cbs_vw_hesap_izleme
                    where  modul_tur_kod= 'CURRENT'
                    AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') and musteri_no in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                    union
                    select Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                            MUSTERI_NO,
                            ISIM_UNVAN,
                            sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                            HESAP_NO,
                            DOVIZ_KODU,
                            NVL(BAKIYE,0),
                            NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                            1 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2),
                            EXTERNAL_HESAP_NO,
                            URUN_SINIF_KOD,
                            MUSTERI_TIPI_KOD,
                            Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
                            case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
                    from cbs_vw_hesap_izleme
                    where  modul_tur_kod= 'CURRENT'
                    AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL') and hesap_no in (
                                select ANA_HESAP_NO from  CBS_HESAP_ORTAK_BILGI where ortak_musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no) and STATUS = 'ACTIVE')
                    --AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama , HESAP_NO, SUBE, doviz_kodu;

            ---------------------------Time Deposite------------------------------
                   OPEN pc_ref2 FOR
                      SELECT Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                             MUSTERI_NO,
                             ISIM_UNVAN,
                             sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
                             HESAP_NO,
                             DOVIZ_KODU,
                             NVL(BAKIYE,0),
                             NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
                             2 siralama, TO_CHAR(vade_tarihi ,'YYYYMMDD') vade_tarihi, KISA_ISIM, ROUND(BIRIKMIS_FAIZ_NEG,2), birikmis_faiz_poz+gecen_yil_faiz_toplami toplam,
                             EXTERNAL_HESAP_NO,
                             URUN_SINIF_KOD,
                             MUSTERI_TIPI_KOD
                      FROM CBS_vw_hesap_izleme a
                      WHERE musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no) AND
                      durum_kodu = 'A' AND
                      modul_tur_kod= 'TIME DEP.'
                      --AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                      ORDER BY siralama , HESAP_NO, SUBE,doviz_kodu ;

            ----------------------------Related Accounts---------------------------
                OPEN pc_ref3 FOR
                     SELECT 'Related Current Accounts' modul_tur_kod,
                             hizl.MUSTERI_NO,
                             hizl.ISIM_UNVAN,
                             hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
                             hizl.HESAP_NO,
                             hizl.DOVIZ_KODU,
                             NVL(hizl.BAKIYE,0),
                             NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
                             1 siralama, TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.KISA_ISIM, ROUND(hizl.BIRIKMIS_FAIZ_NEG,2),
                             hizl.URUN_SINIF_KOD,
                             MUSTERI_TIPI_KOD
                    FROM CBS_JOIN_ACCOUNT jacc
                    JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
                    WHERE jacc.CUST_NO in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                    AND jacc.STATUS_CD='sACTIV'
                    AND jacc.TRAN_TYPE IN ('sVIEW','sTRAN')
                    AND hizl.durum_kodu = 'A'
                    AND hizl.modul_tur_kod= 'CURRENT'
                    AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
                    --and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama, HESAP_NO, SUBE, doviz_kodu;

               OPEN pc_ref4 FOR
                      SELECT Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
                             hizl.MUSTERI_NO,
                             hizl.ISIM_UNVAN,
                             hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
                             hizl.HESAP_NO,
                             hizl.DOVIZ_KODU,
                             NVL(hizl.BAKIYE,0),
                             NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
                             2 siralama, TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.KISA_ISIM, ROUND(hizl.BIRIKMIS_FAIZ_NEG,2),
                             hizl.URUN_SINIF_KOD,
                             MUSTERI_TIPI_KOD
                    FROM CBS_JOIN_ACCOUNT jacc
                    JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
                    WHERE jacc.CUST_NO in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                    AND jacc.STATUS_CD='sACTIV'
                    AND jacc.TRAN_TYPE IN ('sVIEW','sTRAN')
                    AND hizl.durum_kodu = 'A'
                    AND hizl.modul_tur_kod= 'TIME DEP.'
                    --and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(p_personid))
                    ORDER BY siralama, HESAP_NO, SUBE, doviz_kodu;
                 END IF;
            END IF; ------------ IF p_option =  'ALL' THEN

  RETURN ls_returncode;
EXCEPTION
    WHEN noAccoutFound THEN
          ls_returncode:= '503';
      Log_At('Pkg_Soa_Account.GetAccounts1', replace(p_customerid, ',', ''), SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    RETURN ls_returncode;

    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.GetAccounts', replace(p_customerid, ',', ''), SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        ls_returncode:= '999';
        RAISE_APPLICATION_ERROR(-20100,SQLERRM);
    OPEN pc_ref FOR SELECT '-' FROM dual;
    OPEN pc_ref2 FOR SELECT '-' FROM dual;
    OPEN pc_ref3 FOR SELECT '-' FROM dual;
    OPEN pc_ref4 FOR SELECT '-' FROM dual;
    OPEN pc_ref5 FOR SELECT '-' FROM dual;
        RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION Ge tAll Additional Tran Accounts
   Prepared By : Esen Omurchiev
   Date        : 29.11.2021
   Purpose     : Get Customer All Additional Tran Accounts
******************************************************************************/
FUNCTION GetAllAdditionalTranAccounts(pn_musteri_no IN VARCHAR2,
                          ps_currcode IN VARCHAR2,
                         pn_person_id  IN VARCHAR2,
                         pn_channel_cd IN VARCHAR2,
                         pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
     ls_returncode VARCHAR2(3):='000';
     noAccoutFound        EXCEPTION;
     ls_account_count NUMBER:=0;
     ls_vergi_no VARCHAR2(20);
BEGIN

   log_at('ACCOUNTS',pn_person_id,ps_currcode,pn_musteri_No);

   SELECT VERGI_NO INTO ls_vergi_no FROM CBS_MUSTERI WHERE MUSTERI_NO = pn_musteri_no;

   OPEN pc_ref FOR
        SELECT SYSDATE FROM dual;

        SELECT COUNT(*)
        INTO ls_account_count
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
        AND durum_kodu = 'A'
        AND modul_tur_kod= 'CURRENT'
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND DOVIZ_KODU=DECODE(ps_currcode,'LC',Pkg_Genel.LC_al,DOVIZ_KODU)
        AND DOVIZ_KODU<>DECODE(ps_currcode,'FC',Pkg_Genel.LC_al,'ALL');
        --AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id);
        IF (ls_account_count= 0) THEN
        RAISE noAccoutFound;
        END IF;

    OPEN pc_ref FOR
    SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
        ISIM_UNVAN,
        sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
        HESAP_NO,
        DOVIZ_KODU,
        NVL(BAKIYE,0),
        NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
        1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
        external_hesap_no,
        Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD,
        MUSTERI_TIPI_KOD,
        Pkg_Int.GetJoinAccountType(HESAP_NO,MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
        case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
        FROM CBS_vw_hesap_izleme a
        WHERE musteri_no in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
        AND durum_kodu = 'A'
        AND modul_tur_kod= 'CURRENT'
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND DOVIZ_KODU=DECODE('','LC',Pkg_Genel.LC_al,DOVIZ_KODU)
        AND DOVIZ_KODU<>DECODE('','FC',Pkg_Genel.LC_al,'ALL')
       -- AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id)

   UNION

        SELECT Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
        MUSTERI_NO,
        ISIM_UNVAN,
        sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
        HESAP_NO,
        DOVIZ_KODU,
        NVL(BAKIYE,0),
        NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
        1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
        external_hesap_no,
        Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD,
        MUSTERI_TIPI_KOD,
        Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
        case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
        FROM CBS_vw_hesap_izleme a
        WHERE
        durum_kodu = 'A'
        AND modul_tur_kod= 'CURRENT'
        AND urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND DOVIZ_KODU=DECODE('','LC',Pkg_Genel.LC_al,DOVIZ_KODU)
        AND DOVIZ_KODU<>DECODE('','FC',Pkg_Genel.LC_al,'ALL')
        and HESAP_NO in (select ANA_HESAP_NO from  CBS_HESAP_ORTAK_BILGI where ortak_musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no) and STATUS = 'ACTIVE' and ORTAKLIK_TIPI = 'OY' )
       -- AND HESAP_NO NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = pn_person_id)


   UNION
        SELECT Pkg_Int.GetAccountTypeName(hizl.modul_tur_kod) modul_tur_kod,
            hizl.MUSTERI_NO,
            hizl.ISIM_UNVAN,
            hizl.sube_kodu||' '|| Pkg_Genel.bolum_adi_al(hizl.sube_kodu) SUBE,
            hizl.HESAP_NO,
            hizl.DOVIZ_KODU,
            NVL(hizl.BAKIYE,0),
            NVL(Pkg_Hesap.Kullanilabilir_Bakiye_Al(hizl.HESAP_NO),0) kullanilabilir_bakiye,
            2 siralama , TO_CHAR(hizl.vade_tarihi ,'YYYYMMDD') vade_tarihi, hizl.kisa_isim,
            hizl.external_hesap_no,
            Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(hizl.MUSTERI_NO)) STATCD,
            MUSTERI_TIPI_KOD,
            Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
            case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
        FROM CBS_JOIN_ACCOUNT jacc
        JOIN CBS_vw_hesap_izleme hizl ON hizl.hesap_no = jacc.REL_ACCOUNT
        WHERE jacc.CUST_NO in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
        AND jacc.STATUS_CD='sACTIV'
        AND jacc.TRAN_TYPE='sTRAN'
        AND hizl.durum_kodu = 'A'
        AND hizl.modul_tur_kod= 'CURRENT'
        AND hizl.urun_tur_kod IN ('CURRENT','DEMAND DEP','COLLATERAL')
        AND hizl.URUN_TUR_KOD NOT IN ('ACCRUAL' ,'NONACCRUAL') --seval.colak 20112022 accrual modifications
        AND hizl.URUN_SINIF_KOD <> 'OVERBALANCE-LC'
        AND hizl.DOVIZ_KODU=DECODE('','LC',Pkg_Genel.LC_al,hizl.DOVIZ_KODU)
        AND hizl.DOVIZ_KODU<>DECODE('','FC',Pkg_Genel.LC_al,'ALL')
      --  and jacc.REL_ACCOUNT NOT IN (SELECT HESAP_NO FROM CORPINT.TBL_ACCOUNT_ASSIGN WHERE PERSON_ID = TO_NUMBER(pn_person_id))
        ORDER BY siralama, SUBE, HESAP_NO, doviz_kodu;

  RETURN ls_returncode;

EXCEPTION
    WHEN noAccoutFound THEN
    ls_returncode:= '503';
    RETURN ls_returncode;
END;

/******************************************************************************
   NAME        : FUNCTION Get All Additional ForCCPayments
   Prepared By : Omurhciev Esen
   Date        : 02.12.2021
   Purpose     : Get All Additional ForCCPayments
******************************************************************************/
   FUNCTION GetAllAdditionalForCCPayments(ps_customer_id IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
      ls_returncode   VARCHAR2 (3) := '000';
      ls_vergi_no VARCHAR2(20);
   BEGIN

        SELECT VERGI_NO INTO ls_vergi_no FROM CBS_MUSTERI WHERE MUSTERI_NO = ps_customer_id;

        OPEN pc_ref FOR
        SELECT   hesap_no,
                 sube_kodu || ' ' || Pkg_Genel.bolum_adi_al (sube_kodu) sube,
                 NVL (BAKIYE, 0) bakiye,
                 NVL (Pkg_Hesap.Kullanilabilir_Bakiye_Al (HESAP_NO), 0)
                    kullanilabilir_bakiye,
                    MUSTERI_TIPI_KOD,
                    Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
                    case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
          FROM   CBS_vw_hesap_izleme
         WHERE       musteri_no in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                 --AND pkg_hesap.Kullanilabilir_Bakiye_Al (hesap_no) > 0
                 AND durum_kodu = 'A'
                 /*AND hesap_no NOT IN (SELECT   ana_hesap_no
                                        FROM   CBS_HESAP_ORTAK_BILGI
                                       WHERE   STATUS = 'ACTIVE'  AND ortaklik_tipi<>'OY')*/ -- Esen Omurchiev 01.12.2021 task for ib-111
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al
        UNION
           SELECT   hesap_no,
                 sube_kodu || ' ' || Pkg_Genel.bolum_adi_al (sube_kodu) sube,
                 NVL (BAKIYE, 0) bakiye,
                 NVL (Pkg_Hesap.Kullanilabilir_Bakiye_Al (HESAP_NO), 0)
                    kullanilabilir_bakiye,
                    MUSTERI_TIPI_KOD,
                    Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
                    case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
          FROM   CBS_vw_hesap_izleme
         WHERE
                 --AND pkg_hesap.Kullanilabilir_Bakiye_Al (hesap_no) > 0
                  durum_kodu = 'A'
                 /*AND hesap_no NOT IN (SELECT   ana_hesap_no
                                        FROM   CBS_HESAP_ORTAK_BILGI
                                       WHERE   STATUS = 'ACTIVE'  AND ortaklik_tipi<>'OY')*/ -- Esen Omurchiev 01.12.2021 task for ib-111
                 AND hesap_no in (select ANA_HESAP_NO
                                   from  CBS_HESAP_ORTAK_BILGI
                                   where ortak_musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no) and STATUS = 'ACTIVE')
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al;
          RETURN ls_returncode;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ls_returncode := '503';
         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         Log_At ('GetAccountsForCCPayments', SQLERRM);
         ls_returncode := '999';
         RETURN ls_returncode;
   END;
/******************************************************************************
   NAME        : FUNCTION GetAllAdditionalForUsipPayments
   Prepared By : Omurchiev Esen
   Date        : 02.12.2021
   Purpose     : GetAllAdditionalForUsipPayments
******************************************************************************/
FUNCTION GetAllAdditionalForUsipPayments(pn_musteri_no IN VARCHAR2,
                            pc_ref OUT CursorReferenceType) RETURN VARCHAR2 IS
      ls_returncode   VARCHAR2 (3) := '000';
      ls_vergi_no VARCHAR2(20);
   BEGIN

        SELECT VERGI_NO INTO ls_vergi_no FROM CBS_MUSTERI WHERE MUSTERI_NO = pn_musteri_no;
        OPEN pc_ref FOR
        SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
               external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD,
               MUSTERI_TIPI_KOD,
               Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
               case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
          FROM   CBS_vw_hesap_izleme
         WHERE       musteri_no in(SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no)
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al
          UNION
          SELECT   Pkg_Int.GetAccountTypeName(modul_tur_kod) modul_tur_kod,   --added  Esen Omurchiev 01.12.2021 task for ib-111
                 MUSTERI_NO,
               ISIM_UNVAN,
               sube_kodu||' '|| Pkg_Genel.bolum_adi_al(sube_kodu) SUBE,
               HESAP_NO,
               DOVIZ_KODU,
               NVL(BAKIYE,0),
               NVL( Pkg_Hesap.Kullanilabilir_Bakiye_Al(HESAP_NO),0) kullanilabilir_bakiye,
               1 siralama    ,TO_CHAR(vade_tarihi ,'YYYYMMDD')     vade_tarihi,kisa_isim,
               external_hesap_no,
               Pkg_Hesap.GetIRSCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) || Pkg_Hesap.GetSECOCode(Pkg_Musteri.sf_musteri_dk_grup_kod_al(MUSTERI_NO)) STATCD,
               MUSTERI_TIPI_KOD,
               Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) ORTAK_MUSTERI_NO,
               case when  Pkg_Int.GetJoinAccountType(HESAP_NO, MUSTERI_TIPI_KOD) in ('OY','OX') then 'JOINT'
                            else
                                 case when MUSTERI_TIPI_KOD = '1' then 'SINGLE'
                                      when MUSTERI_TIPI_KOD = '2' then 'PE'
                                 end
                            end type_account
          FROM   CBS_vw_hesap_izleme
         WHERE
                 durum_kodu = 'A'
                AND hesap_no in (select ANA_HESAP_NO
                                   from  CBS_HESAP_ORTAK_BILGI
                                   where ortak_musteri_no in (SELECT MUSTERI_NO  FROM CBS_MUSTERI WHERE VERGI_NO = ls_vergi_no) and STATUS = 'ACTIVE')
                 AND urun_tur_kod = 'DEMAND DEP'
                 AND urun_sinif_kod IN
                          ('INTEREST BEARING-FC',
                           'INTEREST BEARING-LC',
                           'NON INT.BEARING-FC',
                           'NON INT.BEARING-LC')
                 AND doviz_kodu = pkg_genel.LC_al;
          RETURN ls_returncode;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ls_returncode := '503';
         RETURN ls_returncode;
      WHEN OTHERS
      THEN
         Log_At ('GetAccountsForUsipPayments', SQLERRM);
         ls_returncode := '999';
         RETURN ls_returncode;
   END;


/******************************************************************************
   NAME        : FUNCTION SwiftCountryName
   Prepared By : Esen Omurchiev
   Date        : 12.01.2010
   Purpose     : Swift Country Name
******************************************************************************/
FUNCTION SwiftCountryNameForIB(ps_customer_no      IN VARCHAR2,
                          ps_currency      IN VARCHAR2,
                          ps_type      IN VARCHAR2,
                          pc_ref OUT CursorReferenceType) RETURN VARCHAR2  IS

        ls_returncode     VARCHAR2(3):='000';

    BEGIN

    OPEN pc_ref FOR
     SELECT DISTINCT BIC_ULKE_KODU, COUNTRY_NAME FROM CBS_BIC_KODLARI
               WHERE country_name IS NOT NULL
               AND BIC_ULKE_KODU NOT IN (SELECT ULKE_KODU FROM CBS_ULKE_KODLARI WHERE ib_restricted = 'Y')
               AND BIC_ULKE_KODU NOT IN (SELECT COUNTRY_CODE FROM CBS_SWIFT_BANK_RESTRICTIONS
                                                             WHERE
                                                                   (BANK_CUSTOMER_NO in (select DISTINCT(CORRBANK_CUSTNO) from CORPINT.TBL_SWIFT_SETTINGS_CIB where CURRENCY = upper(ps_currency)
                                                                                                                                                               AND TYPE = upper(ps_type))
                                                                                         AND COUNTRY_BLOCK_FLAG = 'Y'))
               ORDER BY BIC_ULKE_KODU;

     RETURN ls_returncode;
EXCEPTION
    WHEN OTHERS THEN
         Log_At('Pkg_Soa_Account.SwiftCountryNameForIB', 'OTHERS', SQLERRM);
         RETURN  '999';
END;
/******************************************************************************
   NAME        : FUNCTION CheckSwiftCountry
   Prepared By : Esen Omurchiev
   Date        : 12.01.2010
   Purpose     : check Swift Country
******************************************************************************/
FUNCTION checkSwiftCountry(ps_customer_no      IN VARCHAR2,
                          result OUT varchar2) RETURN VARCHAR2
    IS
    ls_returncode     VARCHAR2(3):='000';
    countNum number;
BEGIN


    SELECT count(*) into countNum FROM CBS_SWIFT_BANK_RESTRICTIONS
                    WHERE (COUNTRY_CODE in (select upper(UYRUK_KOD) FROM CBS.CBS_MUSTERI
                                                                     WHERE MUSTERI_NO in(ps_customer_no))
                                                                      AND  CITIZEN_BLOCK_FLAG = 'Y');

    if(countNum > 0 ) then
         result := '001';
    else
         result := '000';
    end if;

    RETURN ls_returncode;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        Log_At('Pkg_Soa_Account.checkSwiftCountry', 'NO_DATA_FOUND', SQLERRM);
        RETURN '999';
    WHEN OTHERS THEN
        Log_At('Pkg_Soa_Account.checkSwiftCountry', 'OTHERS', SQLERRM);
        RETURN '888';
END;

FUNCTION Active_GetHesapNoFromExternal(ps_externalno VARCHAR2, ps_dvz varchar2) RETURN NUMBER IS -- CBS-731  ADILK         

         ln_hesapno                            NUMBER;

    BEGIN

         SELECT HESAP_NO

         INTO ln_hesapno

         FROM CBS_HESAP

         WHERE EXTERNAL_HESAP_NO=ps_externalno
           and doviz_kodu = ps_dvz and Durum_KODU='A'; -- CBS-731 AdilK



         RETURN ln_hesapno;

          Exception when others then return NULL;

    END;
    

FUNCTION Active_External_HesapNo_Al(pn_hesap_no NUMBER) RETURN NUMBER IS  -- CBS-731  ADILK         

         ln_external                   NUMBER;

BEGIN

     SELECT EXTERNAL_HESAP_NO

     INTO ln_external

     FROM CBS_HESAP

     WHERE hesap_no=pn_hesap_no AND DURUM_KODU='A'; -- CBS-731 AdilK



     RETURN ln_external;



     EXCEPTION



     WHEN NO_DATA_FOUND THEN

     RETURN NULL;

END;

END;
/

