create PACKAGE BODY     PKG_CAMPUS is

function get_customer_account(pn_musteri_no number, ps_doviz_kodu varchar2, ps_urun_tur_kod varchar2, ps_urun_sinif_kod varchar2) return number 
is
   ln_hesap_no number;
  
   cursor cur_hesap is
        select hesap_no
          from CBS.CBS_HESAP
         where musteri_no = pn_musteri_no 
           and doviz_kodu = nvl(ps_doviz_kodu, CBS.PKG_GENEL.LC_AL) 
           and urun_tur_kod = ps_urun_tur_kod 
           and urun_sinif_kod = ps_urun_sinif_kod
           and durum_kodu in ('A', 'D'); 
begin
    open cur_hesap;
    fetch cur_hesap into ln_hesap_no;
    close cur_hesap;

    return ln_hesap_no;
exception 
    when others then 
        return null;
end;

procedure update_campus_account_status(pn_tx_no number, pn_customer_no number, pn_status varchar2, pn_account_no number default null)
is
    ln_count number;
    ln_count2 number;
    ln_users varchar2(1000 byte);
    ls_query varchar2(4000 byte);
    no_document exception;
begin                
    CBS.PKG_PARAMETRE.DEGER('DRAFT_CREATERS',ln_users);
       
    ls_query := 'select count(*) from dual where user in  (' || ln_users || ')';
    
    select count(*) into ln_count2 from cbs_hesap
            where musteri_no=pn_customer_no and durum_kodu='D';
       
    execute immediate ls_query into ln_count;

    if ln_count > 0 and pn_status='D' and create_dokument_control(pn_customer_no)=0 then 
        update cbs_hesap set durum_kodu=pn_status
        where musteri_no=pn_customer_no and hesap_no=pn_account_no and durum_kodu='A';
    elsif pn_status='A' and ln_count2 > 0 then
        if update_dokument_control(pn_tx_no) > 0 then
            update cbs_hesap set durum_kodu=pn_status
            where musteri_no=pn_customer_no and durum_kodu='D';
                               
            update cbs_musteri_guncellenen set account_draft_status_update=pn_status
            where tx_no=pn_tx_no and musteri_no=pn_customer_no;
                               
            send_sms_campus_active_account(pn_customer_no);
        else
            raise no_document;
        end if;
    end if;
        
exception
    when no_document then
        raise_application_error(-20100, CBS.PKG_HATA.getucpointer || '282' || CBS.PKG_HATA.getdelimiter || CBS.PKG_HATA.getucpointer);
    when others then
        log_at('UPDATE_CAMPUS_ACCOUNT_STATUS', pn_tx_no, sqlerrm, dbms_utility.format_error_backtrace);
end;

function create_dokument_control(pn_customer_no number) return number
is
    ln_adet       number;
    l_ucpointer   varchar2 (3) := pkg_hata.getucpointer;
    ls_GBAA     varchar2(200); --YadgarB CBS-258
begin

    CBS.PKG_PARAMETRE.DEGER('GBAA_NAME', ls_GBAA); --YadgarB CBS-258
    select count(*) into ln_adet 
      from CBS.CBS_MUSTERI_BASVURU a, 
           CBS.CBS_MUSTERI b, 
           CBS.CBS_MUSTERI_BASVURU_DOKUMAN c 
     where a.tx_no=c.tx_no 
       and a.musteri_no=b.musteri_no 
       and trunc(c.yaratildigi_tarih) = trunc(sysdate)
       and a.musteri_no = pn_customer_no 
       and c.dokuman_adi= ls_GBAA
       and c.alindi_kutusu_f='E';
     return ln_adet;
      
exception
    when others then
        return 0;
end;

FUNCTION update_dokument_control(pn_islem_no number) return number
IS
    ln_adet     number;
    l_ucpointer varchar2 (3) := pkg_hata.getucpointer;
    ls_GBAA     varchar2(200); --YadgarB CBS-258
begin
    CBS.PKG_PARAMETRE.DEGER('GBAA_NAME', ls_GBAA); --YadgarB CBS-258
--    ls_GBAA :='General Banking Account Agreement';--Bakdoolot (CBS.PKG_PARAMETRE.DEGER('GBAA_NAME', ls_GBAA) is returning error)

    SELECT COUNT (*)
    INTO ln_adet
    FROM CBS.CBS_MUSTERI_GUNCEL_DOKUMAN d
    LEFT JOIN CBS.CBS_DOCUMENT_CODE c USING (DOC_ID) --YadgarB CBS-258
    WHERE TX_NO = pn_islem_no
      AND (d.DOKUMAN_ADI = ls_GBAA OR c.DOC_NAME = ls_GBAA) --YadgarB CBS-258
      AND ALINDI_KUTUSU_F = 'E';
    
log_at('bagdash112', ln_adet);
    return ln_adet;
    
exception
    when others then
        return 0;
end;

procedure send_sms_campus_active_account(pn_musteri_no number)
is
    ps_sms_body  varchar2(4000 byte);
    l_recipients corpint2.pkg_notification.recipientlist; 
    ls_ret       varchar2 (3);
begin
      l_recipients := corpint2.pkg_notification.recipientlist(1);
      ps_sms_body := 'Dorogoi uchastnik kampusnogo proekta! Dlya udobnogo polzovaniya schetom podklyuchite Internet/Mobilnyi-Banking online https://cutt.ly/EWr9pZt . Info 2222'; 
      l_recipients(1) := pkg_notif_sub.sf_get_cust_phone(pn_musteri_no); 
      ls_ret := corpint2.pkg_notification.addsmstoqueuenew (to_char(ps_sms_body),l_recipients); 
exception 
    when others then 
        log_at('SEND_SMS_CAMPUS_ACTIVE_ACCOUNT', pn_musteri_no, sqlerrm, dbms_utility.format_error_backtrace);
end;

function get_customer(p_first_name CBS.CBS_MUSTERI.isim%TYPE,
                                p_last_name CBS.CBS_MUSTERI.soyadi%TYPE,
                                p_birth_date VARCHAR2,
                                p_citizenship CBS.CBS_MUSTERI.uyruk_kod%TYPE,
                                p_middle_name CBS.CBS_MUSTERI.IKINCI_ISIM%TYPE,
                                p_gender CBS.CBS_MUSTERI.CINSIYET_KOD%TYPE,
                                pc_ref OUT CursorReferenceType) return varchar2
  IS
    ln_customer_count NUMBER;
    customer_not_found   EXCEPTION;
BEGIN

    --log_at('CAMPUS_PKG','get_customer', p_first_name || p_last_name || p_birth_date || p_citizenship || p_middle_name || p_gender);

    IF p_middle_name IS NOT NULL THEN

        SELECT count(1) into ln_customer_count FROM cbs.cbs_musteri
        WHERE durum_kodu = 'A' AND musteri_tipi_kod = '1'
        AND isim = UPPER(p_first_name)
        AND soyadi IS NOT NULL AND soyadi = UPPER(p_last_name)
        AND TO_CHAR(dogum_tarihi, 'YYYY-MM-DD') = p_birth_date
        AND uyruk_kod IS NOT NULL AND uyruk_kod = p_citizenship
        AND ikinci_isim IS NOT NULL AND ikinci_isim = UPPER(p_middle_name)
        AND cinsiyet_kod IS NOT NULL AND cinsiyet_kod = p_gender;

        IF ln_customer_count != 1 THEN
            RAISE customer_not_found;
        end if;

        OPEN pc_ref FOR

        SELECT musteri_no customer_no FROM cbs.cbs_musteri
        WHERE durum_kodu = 'A' AND musteri_tipi_kod = '1'
        AND isim = UPPER(p_first_name)
        AND soyadi IS NOT NULL AND soyadi = UPPER(p_last_name)
        AND TO_CHAR(dogum_tarihi, 'YYYY-MM-DD') = p_birth_date
        AND uyruk_kod IS NOT NULL AND uyruk_kod = p_citizenship
        AND ikinci_isim IS NOT NULL AND ikinci_isim = UPPER(p_middle_name)
        AND cinsiyet_kod IS NOT NULL AND cinsiyet_kod = p_gender;

        RETURN '000';

    ELSE

        SELECT count(1) into ln_customer_count FROM cbs.cbs_musteri
        WHERE durum_kodu = 'A' AND musteri_tipi_kod = '1'
        AND isim = UPPER(p_first_name)
        AND soyadi IS NOT NULL AND soyadi = UPPER(p_last_name)
        AND TO_CHAR(dogum_tarihi, 'YYYY-MM-DD') = p_birth_date
        AND uyruk_kod IS NOT NULL AND uyruk_kod = p_citizenship
        AND cinsiyet_kod IS NOT NULL AND cinsiyet_kod = p_gender;

        IF ln_customer_count != 1 THEN
            RAISE customer_not_found;
        end if;

        OPEN pc_ref FOR

        SELECT musteri_no customer_no FROM cbs.cbs_musteri
        WHERE durum_kodu = 'A' AND musteri_tipi_kod = '1'
        AND isim = UPPER(p_first_name)
        AND soyadi IS NOT NULL AND soyadi = UPPER(p_last_name)
        AND TO_CHAR(dogum_tarihi, 'YYYY-MM-DD') = p_birth_date
        AND uyruk_kod IS NOT NULL AND uyruk_kod = p_citizenship
        AND cinsiyet_kod IS NOT NULL AND cinsiyet_kod = p_gender;

        RETURN '000';

    END IF;

EXCEPTION
  WHEN customer_not_found THEN
     log_at('CAMPUS_PKG','get_customer', 'no data found');
     RETURN '999';
  WHEN OTHERS THEN
     log_at('CAMPUS_PKG','get_customer', sqlerrm, dbms_utility.format_error_backtrace);
     raise_application_error(-20100,sqlerrm);
     return '999';
END;

end pkg_campus;
/

