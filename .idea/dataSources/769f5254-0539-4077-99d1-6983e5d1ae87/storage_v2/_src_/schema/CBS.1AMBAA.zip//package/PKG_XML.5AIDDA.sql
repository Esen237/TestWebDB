create PACKAGE PKG_XML IS
/******************************************************************************
   Name       : PKG_XML
   Created By : Bilal G?L
   Date    	  : 27.05.2007
   Purpose	  : XML procedures
******************************************************************************/
out_file  utl_file.file_type;
in_file  utl_file.file_type;

Function Replace_special_chars(ps_str varchar) return varchar;
Procedure CreateXML_AntiMoney_Laundering(pd_date date);
Function sf_get_conv_legal_form_code(pn_code number) return varchar2;
Function Banka_Bic_Al(pn_musteri number) return varchar2 ;
Function Ulke_N3_Kodu_Al(ps_ulke varchar2) return varchar2 ;
Function Remove_Numbers(ps_str varchar) return varchar ;
Function Remove_Characters(ps_str varchar) return varchar ;
Procedure CreateXML_AntiMoney_Laund_New(pd_date date);
END;


/

