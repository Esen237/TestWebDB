create PACKAGE BODY     Pkg_Genel_2 IS
-------------------------------------------------
  g_tarih_sektor_1 date :=null;
  g_tarih_sektor_2 date :=null;
-------------------------------------
------
FUNCTION Muhasebe_Tarihi( pn_islem_no number) RETURN date
IS
	ld_onay_tar			  date;
	ld_dog_tar			  date;
	ld_kay_tar			  date;
	ld_ret	  			  date;

BEGIN
	SELECT ONAY_SISTEM_TARIHI, DOGRULAMA_SISTEM_TARIHI, KAYIT_SISTEM_TARIHI
	INTO ld_onay_tar,ld_dog_tar,ld_kay_tar
	FROM CBS_ISLEM
	WHERE  numara = pn_islem_no;

	if ld_onay_tar is not null
	then
		ld_ret := ld_onay_tar;
	elsif ld_dog_tar is not null
	then
		ld_ret := ld_dog_tar;
	else
		ld_ret := ld_kay_tar;
	end if;

	RETURN ld_ret;

	EXCEPTION
	WHEN OTHERS THEN
		return null;
END;
-----------------------------------------------------------------------------------
Function Kredi_Limit(pn_musteri_no number) return number is
	ln_ret     				 number;
	ln_TEKLIF_NO	  		 number;
begin
	begin
		select TEKLIF_NO
		into ln_TEKLIF_NO
		from CBS_KREDI_TEKLIF
		where musteri_no = pn_musteri_no
		and durum_kodu = 'A';
	exception
	when no_data_found
	then
		return null;
	end;

	begin
		select GENEL_MEVCUT_RISK_YP
		into ln_ret
		from CBS_KREDI_TEKLIF_LIMIT
		where teklif_no =ln_TEKLIF_NO;
	exception
	when no_data_found
	then
		return null;
	end;

	return ln_ret;
end;
-----------------------------------------------------------------------------------
Function Last_Payment_Date(pn_hesap_no number) return date is
	ld_ret_1  		  date;
	ld_ret_2  		  date;

	ld_bastar		  date;
	ld_sontar		  date;
begin
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pkg_muhasebe.Banka_Tarihi_Bul,-3));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pkg_muhasebe.Banka_Tarihi_Bul,-1));

	begin
		select max(payment_date)
		into ld_ret_1
		from CBS_SALARY_DETAIL
		where STAFF_ACCOUNT_NO = pn_hesap_no
		  and payment_date between ld_bastar and ld_sontar;

		exception
		when no_data_found
			then
				ld_ret_1 := to_date('01011900','ddmmyyyy');
	end;

	begin
		select max(VALOR_TARIHI)
		into ld_ret_2
		from CBS_SBA_SATIR_ISLEM C
		WHERE upper(c.banka_aciklama) LIKE '%SALARY%'
		and hesap_tur_kodu = 'VS'
		and tur = 'A'
		AND EXISTS (
		           SELECT  /*+ INDEX(i,PK_ISLEM_NUMARA) */  1
		             FROM cbs_islem i
		            WHERE i.numara = c.TX_NO
		                  AND i.durum IN ('P', '3'))
		and VALOR_TARIHI between ld_bastar and ld_sontar
		and HESAP_NUMARA = to_char(pn_hesap_no);

		exception
		when no_data_found
			then
				ld_ret_2 := to_date('01011900','ddmmyyyy');
	end;

	if nvl(ld_ret_1,to_date('01011900','ddmmyyyy')) > nvl(ld_ret_2,to_date('01011900','ddmmyyyy'))
	then
		return ld_ret_1;
	else
		return ld_ret_2;
	end if;

	exception
	when no_data_found
	then
		return null;
end;
-----------------------------------------------------------------------------------
Function Last_Salary_Amount(pn_hesap_no number) return number is
	ln_ret    		 	 number;
	ln_amount_1			 number;
	ln_amount_2			 number;
	ld_bastar		  date;
	ld_sontar		  date;
begin
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pkg_muhasebe.Banka_Tarihi_Bul,-1));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pkg_muhasebe.Banka_Tarihi_Bul,-1));

	select sum(AMOUNT)
	into ln_amount_1
	from CBS_SALARY_DETAIL
	where STAFF_ACCOUNT_NO = pn_hesap_no
	  and payment_date between ld_bastar and ld_sontar;

	select sum(DV_TUTAR)
	into ln_amount_2
	from CBS_SBA_SATIR_ISLEM C
	WHERE upper(c.banka_aciklama) LIKE '%SALARY%'
	and hesap_tur_kodu = 'VS'
	and tur = 'A'
	AND EXISTS (
	           SELECT  /*+ INDEX(i,PK_ISLEM_NUMARA) */  1
	             FROM cbs_islem i
	            WHERE i.numara = c.TX_NO
	                  AND i.durum IN ('P', '3'))
	and VALOR_TARIHI between ld_bastar and ld_sontar
	and HESAP_NUMARA = to_char(pn_hesap_no);

	ln_ret := nvl(ln_amount_1,0) + nvl(ln_amount_2,0);
	return ln_ret;

	exception
	when others
		then
			return null;
end;
-----------------------------------------------------------------------------------
Function Total_Salary_Amount(pn_hesap_no number) return number is
	ln_ret    		 number;
	ln_tutar_1		 number;
	ln_tutar_2		 number;
	ln_tutar_3		 number;
	ln_tutar_1_1	 number;
	ln_tutar_2_1	 number;
	ln_tutar_3_1	 number;
	ln_tutar_1_2	 number;
	ln_tutar_2_2	 number;
	ln_tutar_3_2	 number;
	ld_bastar 		 date;
	ld_sontar 		 date;
begin
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pkg_muhasebe.Banka_Tarihi_Bul,-3));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pkg_muhasebe.Banka_Tarihi_Bul,-3));

	select sum(nvl(amount,0))
	into ln_tutar_1_1
	from CBS_SALARY_DETAIL
	where STAFF_ACCOUNT_NO = pn_hesap_no
	  and payment_date between ld_bastar and ld_sontar;
---------------
	select sum(nvl(DV_TUTAR,0))
	into ln_tutar_1_2
	from CBS_SBA_SATIR_ISLEM C
	WHERE upper(c.banka_aciklama) LIKE '%SALARY%'
	and hesap_tur_kodu = 'VS'
	and tur = 'A'
	AND EXISTS (
	           SELECT  /*+ INDEX(i,PK_ISLEM_NUMARA) */  1
	             FROM cbs_islem i
	            WHERE i.numara = c.TX_NO
	                  AND i.durum IN ('P', '3'))
	and VALOR_TARIHI between ld_bastar and ld_sontar
	and HESAP_NUMARA = to_char(pn_hesap_no);

	ln_tutar_1 :=   nvl(ln_tutar_1_1,0) + nvl(ln_tutar_1_2,0);
--
--
--
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pkg_muhasebe.Banka_Tarihi_Bul,-2));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pkg_muhasebe.Banka_Tarihi_Bul,-2));

	select sum(nvl(amount,0))
	into ln_tutar_2_1
	from CBS_SALARY_DETAIL
	where STAFF_ACCOUNT_NO = pn_hesap_no
	  and payment_date between ld_bastar and ld_sontar;

---------------
	select sum(nvl(DV_TUTAR,0))
	into ln_tutar_2_2
	from CBS_SBA_SATIR_ISLEM C
	WHERE upper(c.banka_aciklama) LIKE '%SALARY%'
	and hesap_tur_kodu = 'VS'
	and tur = 'A'
	AND EXISTS (
	           SELECT  /*+ INDEX(i,PK_ISLEM_NUMARA) */  1
	             FROM cbs_islem i
	            WHERE i.numara = c.TX_NO
	                  AND i.durum IN ('P', '3'))
	and VALOR_TARIHI between ld_bastar and ld_sontar
	and HESAP_NUMARA = to_char(pn_hesap_no);

	ln_tutar_2 :=  nvl(ln_tutar_2_1,0) + nvl(ln_tutar_2_2,0);
--
--
--
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pkg_muhasebe.Banka_Tarihi_Bul,-1));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pkg_muhasebe.Banka_Tarihi_Bul,-1));

	select sum(nvl(amount,0))
	into ln_tutar_3_1
	from CBS_SALARY_DETAIL
	where STAFF_ACCOUNT_NO = pn_hesap_no
	  and payment_date between ld_bastar and ld_sontar;

	select sum(nvl(DV_TUTAR,0))
	into ln_tutar_3_2
	from CBS_SBA_SATIR_ISLEM C
	WHERE upper(c.banka_aciklama) LIKE '%SALARY%'
	and hesap_tur_kodu = 'VS'
	and tur = 'A'
	AND EXISTS (
	           SELECT  /*+ INDEX(i,PK_ISLEM_NUMARA) */  1
	             FROM cbs_islem i
	            WHERE i.numara = c.TX_NO
	                  AND i.durum IN ('P', '3'))
	and VALOR_TARIHI between ld_bastar and ld_sontar
	and HESAP_NUMARA = to_char(pn_hesap_no);

	ln_tutar_3 :=  nvl(ln_tutar_3_1,0) + nvl(ln_tutar_3_2,0);

	if nvl(ln_tutar_1,0) > 0 and nvl(ln_tutar_2,0) > 0 and nvl(ln_tutar_3,0) > 0
	then
		return nvl(ln_tutar_1,0) + nvl(ln_tutar_2,0) + nvl(ln_tutar_3,0);
	else
		return 0;
	end if;
end;
-------------------------------------------
FUNCTION Cust_Mark_Off_1( pn_musteri_no number) RETURN varchar2
IS
	ls_ret				  				varchar2(100);
	ln_PAZ_SICIL_NO_1					number;
BEGIN
	SELECT PAZARLAMA_SORUMLUSU_SICIL_NO_1
	INTO ln_PAZ_SICIL_NO_1
	FROM cbs_musteri
	WHERE  musteri_no = pn_musteri_no;

	select adi||' ' ||soyadi
	INTO ls_ret
	from cbs_personel
	where personel_numara = ln_PAZ_SICIL_NO_1;


	RETURN ls_ret;

	EXCEPTION
	WHEN OTHERS THEN
		return null;
END;
-----------------------------------------------------------------------------------
FUNCTION Cust_Mark_Off_2( pn_musteri_no number) RETURN varchar2
IS
	ls_ret				  				varchar2(100);
	ln_PAZ_SICIL_NO_2					number;
BEGIN
	SELECT PAZARLAMA_SORUMLUSU_SICIL_NO_2
	INTO ln_PAZ_SICIL_NO_2
	FROM cbs_musteri
	WHERE  musteri_no = pn_musteri_no;

	select adi||' ' ||soyadi
	INTO ls_ret
	from cbs_personel
	where personel_numara = ln_PAZ_SICIL_NO_2;


	RETURN ls_ret;

	EXCEPTION
	WHEN OTHERS THEN
		return null;
END;
-----------------------------------------------------------------------------------
procedure set_tarih_sektor_1 (p_tarih date )
is
begin
	g_tarih_sektor_1 := p_tarih;
end;
-----------------------------------------------------------------------------------
function get_tarih_sektor_1 return date
is
begin
	return g_tarih_sektor_1;
end;
-----------------------------------------------------------------------------------
procedure set_tarih_sektor_2 (p_tarih date )
is
begin
	g_tarih_sektor_2 := p_tarih;
end;
-----------------------------------------------------------------------------------
function get_tarih_sektor_2 return date
is
begin
	return g_tarih_sektor_2;
end;
-----------------------------------------------------------------------------------
FUNCTION GunBakiyeAl(pn_hesapno NUMBER,pd_date date) RETURN NUMBER IS
	ln_bakiye					  NUMBER;
BEGIN
	 SELECT b.BAKIYE
	 INTO ln_bakiye
	 FROM CBS_HESAP_GUNLUK_BAKIYE b
	 WHERE b.hesap_no=pn_hesapno
	 AND BALANCE_DATE=pd_date;

	 RETURN ln_bakiye;

EXCEPTION
	 WHEN OTHERS THEN
	 	  RETURN NULL;

END;
--------------------------------------------------------------------------------------
Function Last_3_Months_Salary(pn_hesap_no number, pd_date date) return number is
	ln_tutar_1		 number;
	ln_tutar_2		 number;
	ln_tutar_3		 number;
	ld_bastar 		 date;
	ld_sontar 		 date;

	say				 number;
	ln_cnt_1		 number;
	ln_cnt_2		 number;
	ln_cnt_3		 number;
begin
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pd_date,-3));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pd_date,-3));

	select sum(nvl(amount,0))
	into ln_tutar_1
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;

	select count(*)
	into ln_cnt_1
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;
---------------
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pd_date,-2));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pd_date,-2));

	select sum(nvl(amount,0))
	into ln_tutar_2
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;

	select count(*)
	into ln_cnt_2
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;
---------------
	ld_bastar := pkg_dates.get_first_day_in_month(add_months(pd_date,-1));
	ld_sontar := pkg_dates.get_last_day_in_month (add_months(pd_date,-1));

	select sum(nvl(amount,0))
	into ln_tutar_3
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;

	select count(*)
	into ln_cnt_3
	from cbs_islem i, CBS_SALARY_DETAIL s
	where i.numara = s.TX_NO
   	  and STAFF_ACCOUNT_NO = pn_hesap_no
	  and ONAY_SISTEM_TARIHI between ld_bastar and ld_sontar;

	say := ln_cnt_1 + ln_cnt_2 + ln_cnt_3;
	if say = 0
	then
		return 0;
	else
		return round(((nvl(ln_tutar_1,0) + nvl(ln_tutar_2,0) + nvl(ln_tutar_3,0))/say),2);
	end if;
end;
-------------------------------------------
/*BOM GulkaiyrK cbs_322 called by CUSFE screen*/
function get_exist_cust(ln_cust_no number) return VARCHAR2  IS
ln_count number;
l_uc_1 VARCHAR2(200);
       cursor c1 is     
     select account_no from cbs_customer_fee where customer_no = ln_cust_no;
  
  BEGIN
    select count(*) into ln_count from cbs_customer_fee where customer_no = ln_cust_no;
     
    if ln_count <> 0 then          
       for l_uc_2_rec in c1   
     loop                       
       l_uc_1 := substr (l_uc_1||' '||ln_cust_no ||' customer with account '|| l_uc_2_rec.account_no ||' already exist'||chr(10),1,200);                
    end loop; 
    else             
       l_uc_1 := substr (l_uc_1||' '||ln_cust_no ||' customer does not exist'||chr(10),1,200);
    end if; 
    RETURN  l_uc_1;   
  END;
/*EOM GulkaiyrK cbs_322 called by CUSFE screen*/
END;
/

