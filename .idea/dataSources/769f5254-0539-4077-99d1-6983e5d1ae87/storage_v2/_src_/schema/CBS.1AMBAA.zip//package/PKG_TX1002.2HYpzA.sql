create PACKAGE     PKG_TX1002 IS

/******************************************************************************
   Name       : PKG_TX1002
   Created By : Lev Bulishev
   Date          : 11.01.19
   Purpose      : RBO
******************************************************************************/


  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  Procedure upload(ps_customer_type varchar2,ps_form varchar2);
  procedure insert_data(pn_customer_no number,ps_branch varchar2,ps_full_address varchar2, ps_REGION varchar2,ps_CITY varchar2,ps_DISTRICT varchar2,ps_STREET varchar2,ps_STATEMENT_NO varchar2,ps_APPARTMENT varchar2);
   PROCEDURE select_musiz(pn_musteri_no number,ps_isim out varchar2,ps_ikinci_isim out varchar2,ps_soyadi out varchar2,ps_vergi_no out varchar2,ps_uyruk_kod out varchar2,ps_risk_level_code out varchar2,pd_dogum_tarihi out date,
pd_GECERLILIK_TARIHI out date ,ps_pasaport_no out varchar2); 
PROCEDURE Parsing_address(pn_musteri_no NUMBER,ps_full_address out varchar2,ps_city out varchar2,ps_district out varchar2,ps_statement out varchar2,ps_street out varchar2,ps_region out varchar2,ps_appartment out varchar2);
PROCEDURE Parsing_title_opf(pn_customer_no number,ps_title_rus out varchar2,ps_title_eng out varchar2);
  

END;

/

