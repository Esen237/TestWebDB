create Package PKG_SOZLESME is

/******************************************************************************
   NAME       : PKG_SOZLESME
   Created By : Seval Balci
   Date    	  : 15.12.03
   Purpose	  : SOZLESME procedure ve fonksiyonlarini icerir.
******************************************************************************/
 Procedure sp_sozlesme_modulurunsinif_al(ps_modul_tur_kod out varchar2,
		  								ps_urun_tur_kod out varchar2,
										ps_urun_sinif_kod out varchar2);

 Function sf_sozlesme_no_al(pn_musteri_no number)return number;
 Function sf_sozlesme_ekno_al(pn_musteri_no number ,pn_sozlesme_no number)return number;

 Procedure sp_sozlesme_anatabloya_at(pn_islem_no number);
 Function Sf_Bitmemis_HesapIslm_VarMi(pn_musteri_no cbs_musteri.musteri_no%type,
 		  								pn_islem_no cbs_islem.numara%type) return number;
 Procedure sp_sozlesmeyi_isleme_at(pn_islem_no number ,pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number);
 Function sf_sozlesme_turu_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return varchar2;
 procedure sp_sozlesme_guncelle(pn_islem_no number);
 Function sf_sozlesme_tutari_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return varchar2;
 Function sf_sozlesme_Durum_Al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return  varchar2;
  /*****************************************************************************************/
 /* A?a??daki k?s?m Teminat & Senet Kulland?r modulu i?erisinde kullan?lan 				  */
/* 	proc / fonks.
  /****************************************************************************************/
 Function  sf_sozlesme_bakiye_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return number;
 Function  sf_sozlesme_kullanilantutar_al( pn_musteri_no number,pn_sozlesme_no number,pn_ek_sozlesme_no number) return number;
 Function  sf_sozlesmeturteminata_uygunmu( ps_sozlesme_tur_kodu varchar2) return varchar2;
 Function  sozlesme_doviz return varchar2;
 Function  sozlesme_diger return varchar2;
 Function  sf_sozlesmeamaci_al(ps_urun_tur_kod varchar2,ps_urun_sinif_kod varchar2,ps_doviz_kodu varchar2) return varchar2;
End ;


/

