create PACKAGE     "PKG_SOA_SWIFT_STATEMENT" IS

/******************************************************************************
/*   Name         : PKG_SOA_SWIFT_STATEMENT
/*   Created By   : SevalB
/*   Date          : 19072012
/*   Purpose      : IB Excel swift message in (MT940) format
******************************************************************************/
--- B-O-M  sevalb 28062012 25691-Special statements for Coca-Cola Bishkek Bottlers via Internet Banking
 TYPE CursorReferenceType IS REF CURSOR;

 FUNCTION sf_Musteri_BIC_Kodu_Bul(pn_musteri_no NUMBER) RETURN VARCHAR2 ;
 FUNCTION sf_islem_aciklama_al(pn_fis_islem_numara NUMBER) RETURN VARCHAR2;
 PROCEDURE sp_ins_ib_swift_file_msg( pn_hesap_no number,pn_log_no number,pn_log_sira_no  number ,ps_mesaj varchar2 );
 PROCEDURE IB_MT940_Data_Hazirla(pn_hesap_no number,pd_baslangid_Tarih date ,pd_bitis_tarih date ,pn_log_no out number ) ;
 FUNCTION GetAccount_MT940_Statement(ps_acct_no          VARCHAR2,
                 pd_start_date       VARCHAR2,
                 pd_end_date         VARCHAR2,               
                 pc_ref               OUT   Cursorreferencetype) RETURN VARCHAR2;
  
 Function to_external_hesap_no(pn_tx_no number ,pn_islem_kod number ) return varchar2; 
 Function sf_musteri_swift_msg_uygun(ps_musteri_no varchar2,
                                     pc_ref  OUT CursorReferenceType ) return varchar2;
/******************************************************************************
/*   Name         : PKG_SOA_SWIFT_STATEMENT
/*   Created By   : Esen Omurchiev
/*   Date          : 20122021
/*   Purpose      : IB Txt swift message in (MT942) format-Special statements for Coca-Cola Bishkek Bottlers via Internet Banking
******************************************************************************/                                   
PROCEDURE IB_MT942_Data_Hazirla(pn_hesap_no number,pd_baslangid_Tarih date ,pd_bitis_tarih date, option_type varchar2, pn_log_no out number);
FUNCTION GetAccount_MT942_Statement(ps_acct_no          VARCHAR2,
                 pd_start_date       VARCHAR2,
                 pd_end_date         VARCHAR2, 
                 option_type         VARCHAR2,             
                 pc_ref               OUT   Cursorreferencetype) RETURN VARCHAR2;
Function from_external_hesap_no(pn_tx_no number ,pn_islem_kod number ) return varchar2; 
--customer_no=15685 
--- E-O-M  sevalb 28062012 25691-Special statements for Coca-Cola Bishkek Bottlers via Internet Banking
END;
/

