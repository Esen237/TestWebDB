create PACKAGE BODY     pkg_kg_report IS

   FUNCTION getresidentstatus(gl_no VARCHAR2) RETURN VARCHAR2 IS
      v VARCHAR2(1);
   BEGIN
      IF substr(gl_no, 5, 1) = '1' THEN
         v := 'R';
      ELSIF substr(gl_no, 5, 1) = '2' THEN
         v := 'N';
      ELSE
         v := '0';
      END IF;
      RETURN v;
   END;
   -------------------------------------------------------------------------------------------------
   FUNCTION getgl(id NUMBER) RETURN VARCHAR2 IS
      v VARCHAR2(1000);
   BEGIN
      v := '';
      FOR recin IN (SELECT *
                    FROM   cbs_kg_kod_gl
                    WHERE  code = id)
      LOOP
         v := v || recin.gl_no || ', ';
      END LOOP;
      v := substr(v, 1, length(v) - 2);
      RETURN v;
   END;
   -------------------------------------------------------------------------------------------------
   PROCEDURE rap09_temp_tablo(pd_date1       IN DATE
                             ,pd_date2       IN DATE
                             ,pd_date3       IN DATE
                             ,pd_date4       IN DATE
                             ,pd_date5       IN DATE
                             ,pd_date6       IN DATE
                             ,pd_date7       IN DATE
                             ,pn_usd_fark    IN NUMBER
                             ,pn_eur_fark    IN NUMBER
                             ,pn_jpy_fark    IN NUMBER
                             ,pn_rezerv_rate IN NUMBER
                             ,pn_work_days   IN NUMBER) IS

      l_initial_bakiye NUMBER;
      ln_bloke_tutari  NUMBER;
   BEGIN


      DELETE FROM cbs_rapor_9_temp;

      INSERT INTO cbs_rapor_9_temp
         SELECT rown ,num ,tan ,exp ,nvl(d1, 0) dat1 ,nvl(d2, 0) dat2 ,nvl(d3, 0) dat3 ,nvl(d4, 0) dat4 ,nvl(d5, 0) dat5 ,nvl(d6, 0) dat6 ,nvl(d7, 0) dat7
               ,(nvl(d1, 0) + nvl(d2, 0) + nvl(d3, 0) + nvl(d4, 0) + nvl(d5, 0) + nvl(d6, 0) + nvl(d7, 0)) / pn_work_days dat8
         FROM   (SELECT 1 rown
                       ,1 num
                       ,'Депозиты до востребования предприятий, организаций и др.юридических лиц' tan
                       ,'20002, 20003, 20013, 20014, 20015, 20016, 20017, 20018, 20021, 20022, 20027, 20028, 20029, 20030, 20031, 20032' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20002', '20003', '20013', '20014', '20015', '20016', '20017', '20018', '20021', '20022', '20027',
                                 '20028', '20029', '20030', '20031', '20032')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 2 rown
                       ,2 num
                       ,'Срочные депозиты предприятий, организаций и др.юридических лиц' tan
                       ,'20301, 20312, 20321, 20341, 20351' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 3 rown
                       ,3 num
                       ,'Депозиты Правительства' tan
                       ,'20801, 20803, 20805, 20806, 20807, 20808, 20809' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('20801', '20803', '20805', '20806', '20807', '20808', '20809')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('20801', '20803', '20805', '20806', '20807', '20808', '20809')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 4 rown
                       ,4 num
                       ,'Депозиты физических лиц' tan
                       ,'20211, 20212, 20213, 20214, 20215, 20216' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('20211', '20212', '20213', '20214', '20215', '20216')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('20211', '20212', '20213', '20214', '20215', '20216')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 5 rown
                       ,5 num
                       ,'Прочие обязательства' tan
                       ,'21199' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('21199')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('21199')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 8 rown
                       ,7 num
                       ,'Депозиты в иностранной валюте, cроком до погашения более 1 года' tan
                       ,' ' exp
                       ,(SELECT nvl(SUM(T.bakiye * decode(v.doviz_kodu, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   CBS_HESAP_GUNLUK_BAKIYE T, CBS_HESAP_VADELI v
                         WHERE -- yil = to_char(pd_date1, 'yyyy') AND AY = to_char(pd_date1, 'mm') AND    gun = to_char(pd_date1, 'dd')
                         t.balance_date=TRUNC(pd_date1)--CBS-475
                         AND    v.hesap_no = T.hesap_no
                         AND    v.vade_tarihi - v.acilis_tarihi >= 365
                         AND    substr(v.musteri_dk_no, 1, 5) IN ('20213', '20216', '20301', '20312', '20321', '20341', '20351')) d1
                       ,(SELECT nvl(SUM(T.bakiye * decode(v.doviz_kodu, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   CBS_HESAP_GUNLUK_BAKIYE T, CBS_HESAP_VADELI v
                         WHERE -- yil = to_char(pd_date2, 'yyyy') AND    AY = to_char(pd_date2, 'mm') AND    gun = to_char(pd_date2, 'dd')
                         t.balance_date=TRUNC(pd_date2)--CBS-475
                         AND    v.hesap_no = T.hesap_no
                         AND    v.vade_tarihi - v.acilis_tarihi >= 365
                         AND    substr(v.musteri_dk_no, 1, 5) IN ('20213', '20216', '20301', '20312', '20321', '20341', '20351')) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 UNION ALL

                 SELECT 9 rown
                       ,8 num
                       ,'Средства на депозитных счетах в НБКР' tan
                       ,'10631' exp
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date1, 'yyyy')
                         AND    AY = to_char(pd_date1, 'mm')
                         AND    gun = to_char(pd_date1, 'dd')
                         AND    substr(numara, 1, 5) IN ('10631')
                         AND    length(numara) = 8) d1
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date2, 'yyyy')
                         AND    AY = to_char(pd_date2, 'mm')
                         AND    gun = to_char(pd_date2, 'dd')
                         AND    substr(numara, 1, 5) IN ('10631')
                         AND    length(numara) = 8) d2
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date3, 'yyyy')
                         AND    AY = to_char(pd_date3, 'mm')
                         AND    gun = to_char(pd_date3, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d3
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date4, 'yyyy')
                         AND    AY = to_char(pd_date4, 'mm')
                         AND    gun = to_char(pd_date4, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d4
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date5, 'yyyy')
                         AND    AY = to_char(pd_date5, 'mm')
                         AND    gun = to_char(pd_date5, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d5
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date6, 'yyyy')
                         AND    AY = to_char(pd_date6, 'mm')
                         AND    gun = to_char(pd_date6, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d6
                       ,(SELECT nvl(SUM(bakiye * decode(doviz_kod, 'USD', pn_usd_fark, 'EUR', pn_eur_fark, 'JPY', pn_jpy_fark, 0)), 0)
                         FROM   cbs_dkhesap_gunluk_bakiye
                         WHERE  yil = to_char(pd_date7, 'yyyy')
                         AND    AY = to_char(pd_date7, 'mm')
                         AND    gun = to_char(pd_date7, 'dd')
                         AND    substr(numara, 1, 5) IN ('20301', '20312', '20321', '20341', '20351')
                         AND    length(numara) = 8) d7
                 FROM   dual

                 )

         UNION ALL
         SELECT 6, 6, 'Всего (1+2+3+4+5)'
                 , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         FROM   dual

         UNION ALL
         SELECT 7 ,NULL,'Обязательства, ','исключаемые из расчета обязательных резервов'
                  ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL
         FROM   dual

         UNION ALL
         SELECT 10, 9, 'Всего (7+8)'
                  ,NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         FROM   dual

         UNION ALL
         SELECT 11 ,NULL,'Итого-сумма обязательств для расчета резервных требований (6-9)'
                   ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL ,NULL
         FROM   dual

         UNION ALL
         SELECT 12, NULL, 'Обязательные  резервы'
                  , NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
         FROM   dual

                END;
       COMMIT;

      UPDATE cbs_rapor_9_temp t SET
      dat1=(SELECT SUM(Z.DAT1) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat2=(SELECT SUM(Z.DAT2) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat3=(SELECT SUM(Z.DAT3) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat4=(SELECT SUM(Z.DAT4) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat5=(SELECT SUM(Z.DAT5) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat6=(SELECT SUM(Z.DAT6) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat7=(SELECT SUM(Z.DAT7) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5),
      dat8=(SELECT SUM(Z.DAT8) FROM cbs_rapor_9_temp Z WHERE Z.NUM<=5)
      WHERE T.NUM=6;

      UPDATE cbs_rapor_9_temp t SET
      dat1=(SELECT SUM(Z.DAT1) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat2=(SELECT SUM(Z.DAT2) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat3=(SELECT SUM(Z.DAT3) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat4=(SELECT SUM(Z.DAT4) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat5=(SELECT SUM(Z.DAT5) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat6=(SELECT SUM(Z.DAT6) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat7=(SELECT SUM(Z.DAT7) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8)),
      dat8=(SELECT SUM(Z.DAT8) FROM cbs_rapor_9_temp Z WHERE Z.NUM IN (7,8))
      WHERE T.NUM=9; --ROWN=10

      UPDATE cbs_rapor_9_temp t SET
      dat1=(SELECT Z.DAT1 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat2=(SELECT Z.DAT2 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat3=(SELECT Z.DAT3 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat4=(SELECT Z.DAT4 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat5=(SELECT Z.DAT5 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat6=(SELECT Z.DAT6 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat7=(SELECT Z.DAT7 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6),
      dat8=(SELECT Z.DAT8 FROM cbs_rapor_9_temp Z WHERE Z.NUM =6)
      WHERE T.ROWN=11;

      UPDATE cbs_rapor_9_temp t SET
      dat1= dat1 - (SELECT Z2.DAT1 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat2= dat2 - (SELECT Z2.DAT2 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat3= dat3 - (SELECT Z2.DAT3 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat4= dat4 - (SELECT Z2.DAT4 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat5= dat5 - (SELECT Z2.DAT5 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat6= dat6 - (SELECT Z2.DAT6 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat7= dat7 - (SELECT Z2.DAT7 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9),
      dat8= dat8 - (SELECT Z2.DAT8 FROM cbs_rapor_9_temp Z2 WHERE Z2.NUM =9)
      WHERE T.ROWN=11;


      UPDATE cbs_rapor_9_temp t SET
      dat8=(SELECT Z.DAT8 * pn_rezerv_rate /100 FROM cbs_rapor_9_temp Z WHERE Z.ROWN =11)
      WHERE T.ROWN=12;

      COMMIT;

   END;
   -------------------------------------------------------------------------------------------------
   PROCEDURE rap01_temp_tablo(pd_date IN DATE ) IS

      l_initial_bakiye NUMBER;
      ln_bloke_tutari  NUMBER;
   BEGIN

      DELETE FROM cbs_rapor_1_temp;

      INSERT INTO cbs_rapor_1_temp
        SELECT pd_date datval
              ,'75' bank
              ,c.cur
              ,c.iso_code val
              ,(SELECT nvl(abs(SUM(bakiye)),0)
                FROM   cbs_dkhesap_gunluk_bakiye
                WHERE  yil = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'yyyy')
                AND    AY = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'mm')
                AND    gun = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'dd')
                AND    length(numara) = 8  AND    substr(numara, 1, 5) = '10001'       AND    doviz_kod = c.cur)
        OSTN,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                FROM   CBS_VW_FIS_SATIR t
                WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                AND    satir_doviz_kod = c.cur)
        PRIHOD,   (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                    AND    C.ISLEM_KOD IN ('6200','2000','2003') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080401')
                    AND    satir_doviz_kod = c.cur)
        POS_DEP,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('070111', '070121', '070301')
                    AND    satir_doviz_kod = c.cur)
        POG_KR,   (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080501','081101','080701')
                    AND    satir_doviz_kod = c.cur)
        POS_PER, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                  AND    C.ISLEM_KOD IN ('6202') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080401')
                  AND    satir_doviz_kod = c.cur)
        POKUPK, (SELECT nvl(ABS(SUM(NVL(satir_dv_tutar*T.kur,0))),0)
                 FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                 WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                 AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                 AND    C.ISLEM_KOD IN ('6202') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080401')
                 AND    satir_doviz_kod = c.cur)
                  / (SELECT DECODE(nvl(ABS(SUM(nvl(satir_dv_tutar,0))),0),0,1,ABS(SUM(NVL(satir_dv_tutar,0))))
                     FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                     WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                     AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                     AND    C.ISLEM_KOD IN ('6202') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080401')
                     AND    satir_doviz_kod = c.cur)
        KUR_POK,  0
        POKUP_NBK,0
        KUR_NBK1, 0
        POKUP_BR, 0
        KUR_BR1,  0
        POKUP_BN, 0
        KUR_BN1,  0
        POKUP_KR, 0
        KUR_KR1,  0
        POKUP_KN, 0
        KUR_KN1,  0
        POKUP_O,  0
        KUR_01,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('090201')
                  AND    satir_doviz_kod = c.cur)
        OBNAL,   (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK' AND C.NUMARA=T.fis_islem_numara
                  AND    C.ISLEM_KOD IN ('6202','6203','1207')  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080401')
                  AND    satir_doviz_kod = c.cur)
        KONVERT1,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                  AND    (C.ISLEM_KOD NOT IN ('6200','2000','2003','6202','6203','1207')  OR  SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN ('080401'))
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN ('090201','080501','081101','080701','070111', '070121', '070301')
                  AND    satir_doviz_kod = c.cur)
        PRPRIHOD,

               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                FROM   CBS_VW_FIS_SATIR t
                WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                AND    satir_doviz_kod = c.cur)
        RASHOD,    (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                    AND    C.ISLEM_KOD IN ('6201','2003') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080402')
                    AND    satir_doviz_kod = c.cur)
        VOZ_DEP,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('070112', '070122','070302')
                    AND    satir_doviz_kod = c.cur)
        VYD_KR,   (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080502','081102','080702')
                    AND    satir_doviz_kod = c.cur)
        VYPL_PER,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                  AND    C.ISLEM_KOD IN ('6203') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080402')
                  AND    satir_doviz_kod = c.cur)
        PRODANO , (SELECT nvl(ABS(SUM(NVL(satir_dv_tutar*T.kur,0))),0)
                   FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                   AND    C.ISLEM_KOD IN ('6203') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080402')
                   AND    satir_doviz_kod = c.cur)
                    / (SELECT DECODE(nvl(ABS(SUM(NVL(satir_dv_tutar,0))),0),0,1,ABS(SUM(NVL(satir_dv_tutar,0))))
                       FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                       WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                       AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                       AND    C.ISLEM_KOD IN ('6203') AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080402')
                       AND    satir_doviz_kod = c.cur)
        KUR_PR,   0
        PROD_NBK, 0
        KUR_NBK2, 0
        PROD_BR,  0
        KUR_BR2,  0
        PROD_BN,  0
        KUR_BN2,  0
        PROD_KR,  0
        KUR_KR2,  0
        PROD_KN,  0
        KUR_KN2,  0
        PROD_O,   0
        KUR_O2,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('090301')
                    AND    satir_doviz_kod = c.cur)
        OBEZNAL,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK' AND C.NUMARA=T.fis_islem_numara
                    AND    C.ISLEM_KOD IN ('6202','6203','1207')  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080402')
                    AND    satir_doviz_kod = c.cur)
        KONVERT2, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t, CBS_ISLEM C
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) = '10001'  AND satir_hesap_tur_kodu = 'DK'  AND C.NUMARA=T.fis_islem_numara
                    AND    (C.ISLEM_KOD NOT IN ('6201','2003','6202','6203','1207')  OR  SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN ('080402'))
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN ('090301','080502','081102','080702','070112', '070122','070302')
                    AND    satir_doviz_kod = c.cur)
        PRRASHOD, (SELECT abs(SUM(bakiye))
                    FROM   cbs_dkhesap_gunluk_bakiye
                    WHERE  yil = to_char(pd_date, 'yyyy')
                    AND    AY = to_char(pd_date, 'mm')
                    AND    gun = to_char(pd_date, 'dd')
                    AND    length(numara) = 8  AND    substr(numara, 1, 5) = '10001'       AND    doviz_kod = c.cur)
        OSTK

         FROM     (SELECT k.doviz_kod cur, iso_code
                    FROM   CBS_DKHESAP_GUNLUK_BAKIYE k, CBS_DOVIZ_KODLARI D
                    WHERE  substr(k.numara, 1, 5) = '10001'
                    AND    yil = to_char(pd_date, 'yyyy')
                    AND    AY = to_char(pd_date, 'mm')
                    AND    gun = to_char(pd_date, 'dd')
                    AND    k.doviz_kod <> 'KGS'
                    AND    d.doviz_kodu = k.doviz_kod
                    GROUP  BY k.doviz_kod, iso_code) c ;

       COMMIT;
   END;
   -------------------------------------------------------------------------------------------------
   PROCEDURE rap02_temp_tablo(pd_date IN DATE ) IS

      l_initial_bakiye NUMBER;
      ln_bloke_tutari  NUMBER;
   BEGIN

      DELETE FROM cbs_rapor_2_temp;

      INSERT INTO cbs_rapor_2_temp
        SELECT pd_date DATVAL
              ,'75' BANK
              ,c.cur
              ,c.iso_code VAL
              ,(SELECT nvl(abs(SUM(bakiye)),0)
                FROM   cbs_dkhesap_gunluk_bakiye
                WHERE  yil = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'yyyy')
                AND    AY = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'mm')
                AND    gun = to_char(to_date(pkg_dates.get_previous_work_date(pd_date)), 'dd')
                AND    length(numara) = 8  AND    substr(numara, 1, 5) IN ('10170','10180') AND doviz_kod = c.cur)
        OSTN,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                FROM   CBS_VW_FIS_SATIR t
                WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                AND    satir_doviz_kod = c.cur)
        PRIHOD, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('070111','070121','070201','070301')
                  AND    satir_doviz_kod = c.cur)
        KRED_PN,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('070122')
                  AND    satir_doviz_kod = c.cur)

        KRED_PS,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('070111','070121')
                  AND    satir_doviz_kod = c.cur)
        POG_KR,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('040301')
                  AND    satir_doviz_kod = c.cur)
        POS_DEP,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN
                  ('010011','010021','010031','010041','010051','010061','010071','010081','010091','010111','010121','010131',
                   '010141','010151','020391','020401','020501','020701','020801','020901','021201','020011','020021','020031',
                   '020041','020051','020061','020071','020081','020091','020111','020121','020131','020141','020151','020161',
                   '020171','020181','020191','020251','020261','020271','020281','020211','020221','020231','020241','020311',
                   '020321','020331','020341','020351','020361','020371','020381','021301','021401','021501','021601','021701',
                   '021801','021901','022001','022101','022201','022301','022401','022501','022601','022701','022801','022901')
                  AND    satir_doviz_kod = c.cur)
        EXPORT,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080201')
                  AND    satir_doviz_kod = c.cur)
        POS_BAN, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080101','080201')
                  AND    satir_doviz_kod = c.cur)
        SNYT_DEP, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080501','080701','081101')
                  AND    satir_doviz_kod = c.cur)
        POS_PER,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                   AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080301')
                   AND    satir_doviz_kod = c.cur)
        POKUPK,   (SELECT nvl(ABS(SUM(NVL(satir_dv_tutar*T.kur,0))),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                   AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080301')
                   AND    satir_doviz_kod = c.cur)
                    / (SELECT DECODE(nvl(ABS(SUM(nvl(satir_dv_tutar,0))),0),0,1,ABS(SUM(NVL(satir_dv_tutar,0))))
                       FROM   CBS_VW_FIS_SATIR t
                       WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                       AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                       AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080301')
                       AND    satir_doviz_kod = c.cur)
        KUR_POK,0 --         13
        POKUP_NBK,0 --       14
        KUR_NBK1,0 --        15
        POKUP_BR,0 --        16
        KUR_BR1,0 --         17
        POKUP_BN,0 --        18
        KUR_BN1,0 --         19
        POS_SVOP1,0 --       20
        POS_NBKR1,0 --       21
        POS_BANK1,0 --       22
        VOZ_SVOP1,0 --       23
        VOZ_NBKR1,0 --       24
        VOZ_BANK1, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5)IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('090301')
                    AND    satir_doviz_kod = c.cur)
        OBEZNAL,  (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5)IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('090101')
                    AND    satir_doviz_kod = c.cur)
        KONVERT1,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='B'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN
                    ('080301','080501','080701','081101','080101','080201','040301','070111','070121','070122','070111','070121',
                    '070201','070301','010011','010021','010031','010041','010051','010061','010071','010081','010091','010111',
                    '010121','010131','010141','010151','020391','020401','020501','020701','020801','020901','021201','020011',
                    '020021','020031','020041','020051','020061','020071','020081','020091','020111','020121','020131','020141',
                    '020151','020161','020171','020181','020191','020251','020261','020271','020281','020211','020221','020231',
                    '020241','020311','020321','020331','020341','020351','020361','020371','020381','021301','021401','021501',
                    '021601','021701','021801','021901','022001','022101','022201','022301','022401','022501','022601','022701',
                    '022801','022901')
                    AND    satir_doviz_kod = c.cur)
        PRPRIHOD,
               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                 FROM   CBS_VW_FIS_SATIR t
                 WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                 AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5)  IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                 AND    satir_doviz_kod = c.cur)
        RASHOD,
               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('070112','070122','070302')
                  AND    satir_doviz_kod = c.cur)
        KRED_VN,
               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('070122')
                  AND    satir_doviz_kod = c.cur)
        KRED_VS,
               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('070112','070122')
                  AND    satir_doviz_kod = c.cur)
        VYD_KR,--  33
               (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('040302')
                  AND    satir_doviz_kod = c.cur)

        VOZ_DEP,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                  FROM   CBS_VW_FIS_SATIR t
                  WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                  AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                  AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN
                  ('010012','010022','010032','010042','010052','010062','010072','010082','010092','010112','010122','010132',
                   '010142','010152','020392','020402','020502','020702','020802','020902','021202','020012','020022','020032',
                   '020042','020052','020062','020072','020082','020092','020112','020122','020132','020142','020152','020162',
                   '020172','020182','020192','020252','020262','020272','020282','020212','020222','020232','020242','020312',
                   '020322','020332','020342','020352','020362','020372','020382','021302','021402','021502','021602','021702',
                   '021802','021902','022002','022102','022202','022302','022402','022502','022602','022702','022802','022902')
                  AND    satir_doviz_kod = c.cur)
        KONTRAKT,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                   AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('080202','080102')
                   AND    satir_doviz_kod = c.cur)
        RAZM_DEP,(SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                   AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('080202')
                   AND    satir_doviz_kod = c.cur)
        VOZ_BAN, (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                   AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('080502','081102','080702')
                   AND    satir_doviz_kod = c.cur)
        VYPL_PER, --  38
                 (SELECT nvl(ABS(SUM(NVL(satir_dv_tutar*T.kur,0))),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                   AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080302')
                   AND    satir_doviz_kod = c.cur)
                    / (SELECT DECODE(nvl(ABS(SUM(nvl(satir_dv_tutar,0))),0),0,1,ABS(SUM(NVL(satir_dv_tutar,0))))
                       FROM   CBS_VW_FIS_SATIR t
                       WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                       AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180')  AND satir_hesap_tur_kodu = 'DK'
                       AND SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN ('080302')
                       AND    satir_doviz_kod = c.cur)
        PRODANO,0 --       39
        KUR_PR,0 --        40
        PROD_NBK,0 --      41
        KUR_NBK2,0 --      42
        PROD_BR,0 --       43
        KUR_BR2,0 --       44
        PROD_BN,0 --       45
        KUR_BN2,0 --       46
        POS_SVOP2,0 --     47
        POS_NBKR2,0 --     48
        POS_BANR2,0 --     49
        VOZ_SVOP2,0 --     50
        VOZ_NBKR2,0 --     51
        VOZ_BANK2,--       52
                 (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                   AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('090201')
                   AND    satir_doviz_kod = c.cur)
        OBNAL,  --    53
                (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                   FROM   CBS_VW_FIS_SATIR t
                   WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                   AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                   AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) IN  ('090102')
                   AND    satir_doviz_kod = c.cur)
        KONVERT2, --  54
                 (SELECT NVL(abs(sum(satir_dv_tutar)),0)
                    FROM   CBS_VW_FIS_SATIR t
                    WHERE  fis_muhasebelestigi_tarih = pd_date AND satir_tur='A'
                    AND    fis_tur = 'G'  AND  substr(satir_hesap_numara, 1, 5) IN ('10170','10180') AND satir_hesap_tur_kodu = 'DK'
                    AND    SUBSTR(NVL(T.satir_istatistik_kodu,0),1,6) NOT IN
                    ('070302','070112','070122','040302','080202','080102','080502','081102','080702','080302',
                     '010012','010022','010032','010042','010052','010062','010072','010082','010092','010112','010122','010132',
                     '010142','010152','020392','020402','020502','020702','020802','020902','021202','020012','020022','020032',
                     '020042','020052','020062','020072','020082','020092','020112','020122','020132','020142','020152','020162',
                     '020172','020182','020192','020252','020262','020272','020282','020212','020222','020232','020242','020312',
                     '020322','020332','020342','020352','020362','020372','020382','021302','021402','021502','021602','021702',
                     '021802','021902','022002','022102','022202','022302','022402','022502','022602','022702','022802','022902')
                    AND    satir_doviz_kod = c.cur)
        PRRASHOD, (SELECT abs(SUM(bakiye))
                    FROM   cbs_dkhesap_gunluk_bakiye
                    WHERE  yil = to_char(pd_date, 'yyyy')
                    AND    AY = to_char(pd_date, 'mm')
                    AND    gun = to_char(pd_date, 'dd')
                    AND    length(numara) = 8  AND    substr(numara, 1, 5)  IN ('10170','10180')  AND doviz_kod = c.cur)
        OSTK

        FROM     (SELECT k.doviz_kod cur, iso_code
                    FROM   CBS_DKHESAP_GUNLUK_BAKIYE k, CBS_DOVIZ_KODLARI D
                    WHERE  substr(k.numara, 1, 5)  IN ('10170','10180')
                    AND    yil = to_char(pd_date, 'yyyy')
                    AND    AY = to_char(pd_date, 'mm')
                    AND    gun = to_char(pd_date, 'dd')
                    AND    k.doviz_kod <> 'KGS'
                    AND    d.doviz_kodu = k.doviz_kod
                    GROUP  BY k.doviz_kod, iso_code) c;

       COMMIT;
   END;

END pkg_kg_report;
/

