create PACKAGE     Pkg_Tx1999 IS
/******************************************************************************
Name       : Pkg_Tx7157
Created By : Konstantin Zhukov, 26012016
Purpose      : CREDIT CARD INSERTATION    
******************************************************************************/
   PROCEDURE GET_PRIMARY_CARD_NO(pc_customer_no varchar2,holder_no varchar2 default null,pc_card_style varchar2 default 'VS',ps_Card_no out varchar2,ps_Card_pan_no out varchar2);
    FUNCTION GET_CARD_TYPES(pc_customer_no number,card_style varchar2, pr_group varchar2) return boolean; --Get card types MS or VC -BY GK
    FUNCTION GET_APPROVED_LIMIT_CUR(pc_customer_no varchar2) return varchar2;
    FUNCTION GET_APPROVED_LIMIT(pc_customer_no varchar2) return number;
    PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER);      -- Islem giris kontrolden gectikten sonra cagrilir
    PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);    -- Islem dogrulandiktan sonra cagrilir
    PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);        -- Islem iptal edildikten sonra cagrilir
    PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);         -- Islem onaylandiktan sonra cagrilir
    PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);     -- Islem reddedildikten sonra cagrilir
    PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);        -- Islem tamamlandiktan sonra cagrilir
    PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);        -- Isleme iliskin formlar basildiktan sonra cagrilir
    PROCEDURE Muhasebelesme(pn_islem_no NUMBER);        -- Islemin muhasebelesmesi icin cagrilir
    PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER);
    PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);
    PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER);
    PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER);
END;
/

