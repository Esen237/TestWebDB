create PACKAGE Pkg_Tx6105 IS

/******************************************************************************
   Name       : PKG_TX6105
   Created By : G?lnihal Cengiz
   Date    	  : 30/04/2004
   Purpose	  : Gecikme Faizi Grup Faizlerinin Tan?mlanmas?
******************************************************************************/
  TYPE Generic_CurType IS REF CURSOR;
  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER);

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  PROCEDURE Onceki_GecikmeFaizi_Oran_Aktar (pn_grup_no NUMBER, pn_log_no NUMBER,ps_program_kod VARCHAR2 ) ;
  PROCEDURE GecikmeFaizi_Oran_Bilgi_Aktar(pn_islem_no NUMBER)  ;
  FUNCTION  Guncelle_ctrl RETURN NUMBER ;
  PROCEDURE Mevcut_Bilgileri_getir(pn_islem_no NUMBER ,pRetCur IN OUT Pkg_Rapor.Generic_CurType);

END;


/

