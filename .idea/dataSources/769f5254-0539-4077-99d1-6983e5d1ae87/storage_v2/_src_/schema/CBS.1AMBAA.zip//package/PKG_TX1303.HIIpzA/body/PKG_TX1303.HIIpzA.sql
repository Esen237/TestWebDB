create PACKAGE BODY     "PKG_TX1303" IS
    pn_1303_borclu_doviz_kod                number;
    pn_1303_fc_tutar                        number;
    pn_1303_ekran_kurlu_tutar               number;
    pn_1303_banka_aciklama                  number;
    pn_1303_borclu_hesap_sube_kodu          number;
    pn_1303_borclu_hesap_no                 number;
    pn_1303_alacak_hesap_sube_kodu          number;
    pn_1303_alacak_hesap_no                 number;
    pn_1303_musteri_aciklama                number;
    pn_1303_referans                        number;
    pn_1303_fis_aciklama                    number;
    pn_1303_istatistik_kod                  number;
    pn_1303_tutar_bdak                      number;
    pn_1303_islem_sube                      number;
    pn_1303_alacak_doviz_kod                number;
    pn_1303_tl_tutar                        number;
    pn_1303_kur                             number;
    pn_1303_tl_ise                          number;
    pn_1303_yp_ise                          number;
    pn_1303_musteri_kuru_buyukse            number;
    pn_1303_musteri_kuru_kucukse            number;
    pn_1303_endeks_ise                      number;
    pn_1303_kullandirim_tl                  number;
    pn_1303_kullandirim_yp                  number;
    pn_1303_bdak_kur                        number;
    pn_1303_bdak_tutar                      number;
    pn_1303_endeks_doviz                    number;
    pn_1303_fark_tutar                      number;
    pn_1303_musteri_tutar                   number;
    pn_1303_maliyet_tutar                   number;
    pn_1303_bdak_fc_tutar                   number;
    pn_1303_borclu_teminat_hesap            number;
    pn_1303_alacak_teminat_hesap            number;
    pn_1303_teminat_doviz                   number;
    pn_1303_kullan_teminattutar             number;
    pn_1303_kullan_tl_teminattutar          number;
    pn_1303_borclu_teminhesapsube           number;
    ps_fis_mesaj                            varchar2(2000);
    pn_1303_hesap_tipi                      number;
    pn_1303_MUSTERI_HESAP_NO                number;
    pn_1303_MUSTERI_HESAP_TIPI              number;
    pn_1303_komisyon_dkno                   number;
    pn_1303_komisyon_hesap                  number;
    pn_1303_komisyon_tutari                 number;
    pn_1303_komisyon_tutari_lc              number;
    pn_1303_kom_kur                         number;
    pn_1303_komisyon_komtutar               number;
    pn_1303_komisyon_tl                     number;
    pn_1303_komisyon_yp                     number;
    pn_1303_mbdak_kur                       number;
    pn_1303_komisyon_var                    number;
    pn_1303_KOMISYON_DOVIZ                  number;
    pn_1303_KOMISYON_SUBE                   number;
    pn_1303_net_kom_lc                      number;
    pn_1303_vat_tax_kom_lc                  number;
    pn_1303_service_tax_kom_lc              number;
------------------------------------------------------------------------------------
  procedure sp_tahakkuk_dk_tanimlimi(pn_islem_no number)
  is
  ls_sube_kodu varchar2(200);
  ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
  ls_faiz_dk_numara varchar2(200);
  ls_vergi_dk_numara varchar2(200);
  Begin
         select sube_kodu ,doviz_kodu
       into ls_sube_kodu,ls_doviz_kodu
       from cbs_hesap_kredi_islem
       where tx_no = pn_islem_no;

       PKG_KREDI.SF_TAHAKKUK_DK_TANIMLIMI ( lS_SUBE_KODU, lS_DOVIZ_KODU, lS_FAIZ_DK_NUMARA, lS_VERGI_DK_NUMARA );
    End;
------------------------------------------------------------------------------------
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
-- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    ln_count NUMBER;
    maturity_date_exc     exception;
    real_limit_exc     exception;
    ld_maturity_date CBS_KREDI_TEKLIF_SATIR.maturity_date%TYPE;
    ln_real_limit CBS_KREDI_TEKLIF_SATIR.real_limit%TYPE;
    ls_lim_doviz_kodu CBS_KREDI_TEKLIF_SATIR.doviz_kodu%TYPE;
    ln_tutar CBS_HESAP_KREDI_ISLEM.tutar%TYPE;
    ls_doviz_kodu CBS_HESAP_KREDI_ISLEM.doviz_kodu%TYPE;    
    ls_kull_doviz_kodu CBS_HESAP_KREDI_ISLEM.kullandirim_doviz_kodu%TYPE;   
    ln_disbur_amount NUMBER;
    ln_risk NUMBER;
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date  
  Begin
     pkg_kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no);
     sp_kontrol_sonrasi_rezervasyon(pn_islem_no);
     Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);
     pkg_kredi.sp_pastdue_dk_tanimlimi(pn_islem_no);
-- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    select count(*)
    into ln_count
    from cbs_hesap_kredi_islem k,
         cbs_kredi_teklif_limit l,
         cbs_kredi_teklif_satir s,
         cbs_kredi_teklif t
    where k.tx_no = pn_islem_no and
          k.musteri_no = s.musteri_no and
          k.kredi_teklif_satir_numara = s.teklif_satir_no and
          l.teklif_no = s.teklif_no and
          t.teklif_no = s.teklif_no and
          t.durum_kodu = 'A' and
          (l.mevcut_yenileme_vade < pkg_muhasebe.banka_tarihi_bul or s.tranches = 'Y');
    
    IF ln_count > 0 THEN
        update cbs_hesap_kredi_islem
        set get_extra_approval = 'Y',
            approval_status = 'C'
        where tx_no = pn_islem_no;
    END IF;

    select DECODE(nvl(s.tranches, 'N'), 'Y', s.maturity_date, pkg_muhasebe.banka_tarihi_bul),
             s.real_limit,
             s.doviz_kodu,
             k.tutar,
             k.doviz_kodu,
             k.kullandirim_doviz_kodu,
             nvl(m.fc_risk, 0)
    into ld_maturity_date,
            ln_real_limit,
            ls_lim_doviz_kodu,
            ln_tutar,
            ls_doviz_kodu,
            ls_kull_doviz_kodu,
            ln_risk
    from cbs_hesap_kredi_islem k,
            cbs_kredi_teklif_satir s,
            cbs_kredi_teklif t,
            cbs_musteri_urun_limit m
    where k.tx_no = pn_islem_no and
              k.kredi_teklif_satir_numara = s.teklif_satir_no and
              t.teklif_no = s.teklif_no and
              t.durum_kodu = 'A' and
              t.musteri_no = s.musteri_no and
              m.musteri_no = t.musteri_no and
              m.kredi_teklif_satir_numara = k.kredi_teklif_satir_numara and --m.fc_doviz_kodu = k.doviz_kodu and  -- AdiletK 17022017 CQ5744 defect real limit
              m.urun_grub_no = s.kredi_turu;

    ln_disbur_amount := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,ls_lim_doviz_kodu,NULL, ln_tutar,1,NULL,NULL,'N','A');    
    
    if ln_real_limit is not null and ln_real_limit - ln_risk < ln_disbur_amount then
        raise real_limit_exc;
    end if; 
exception     
    when real_limit_exc then
        raise_application_error(-20100,pkg_hata.getucpointer || '4665' || pkg_hata.getdelimiter || pkg_kur.yuvarla(ls_lim_doviz_kodu,ln_disbur_amount) || ' ' || ls_lim_doviz_kodu || pkg_hata.getucpointer);                 
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
 End;
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
   null;
  End;
------------------------------------------------------------------------------------
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    /* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_no);
    pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);

  End;
------------------------------------------------------------------------------------
Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
------------------------------------------------------------------------------------
Procedure Iptal_Sonrasi(pn_islem_no number) is
Begin
    null;
End;
------------------------------------------------------------------------------------
Procedure Onay_Sonrasi(pn_islem_no number)
is
    ln_teklif_no    cbs_kredi_teklif.teklif_no%type;
    ls_durum_kodu   cbs_kredi_teklif.durum_kodu%type;
    ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
    ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
    ls_faiz_siklik_tipi      varchar2(100);
    ld_vade                  date;
-- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date    
    extra_approval           exception;
    ln_count                 number;
    ln_odeme_plan_no            number; -- b-o-m seval.colak 10102021
    ln_iliskili_hesap_no        number; 
    ls_repayment_type           varchar2(50);
    ln_tutar                    number; -- e-o-m seval.colak 10102021
Begin

    select count(*)
    into ln_count
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no and
          get_extra_approval = 'Y' and
          approval_status = 'C' and
          approval_date is null;
   
    if ln_count > 0 then
        raise extra_approval;
    end if;
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date

-- b-o-m seval.colak 10102021
    select faiz_siklik_tipi
          ,odeme_plan_no 
          ,iliskili_hesap_no
          ,tutar
          ,repayment_type
    into ls_faiz_siklik_tipi 
        ,ln_odeme_plan_no           --seval.colak 10102021
        ,ln_iliskili_hesap_no
        ,ln_tutar 
        ,ls_repayment_type       
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no;
    
    if ls_faiz_siklik_tipi = 'INSTALLMENT DATE' and nvl(ln_odeme_plan_no,0) = 0 then
       select min(vade_tarih)
       into ld_vade
       from cbs_hesap_kredi_taksit_islem
       where tx_no = pn_islem_no;

       update cbs_hesap_kredi_islem
       set faiz_tahakkuk_tarihi =ld_vade
       where tx_no = pn_islem_no;
    end if;
        
    if ls_repayment_type = 'INSTALLMENT DATE' and nvl(ln_odeme_plan_no,0) <> 0 then
       select min(vade_tarih)
       into ld_vade
       from cbs_hesap_kredi_taksit_islem
       where tx_no = pn_islem_no and nvl(faiz,0) <> 0;

       update cbs_hesap_kredi_islem
       set faiz_tahakkuk_tarihi =ld_vade
       where tx_no = pn_islem_no;
    end if;
  -- e-o-m seval.colak 10102021     
   
     Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);
     pkg_kredi.sp_pastdue_dk_tanimlimi(pn_islem_no);
     pkg_kredi.sp_taksit_sira_guncelle(pn_islem_no);
     pkg_kredi.sp_islemden_kredi_hesap_acilis(pn_islem_no,ln_hesap_no, ls_doviz_kodu);
     pkg_kredi_tahsilat.sf_accrual_int_tax_account_open(ln_hesap_no,pn_islem_no ); --seval.colak 29032022 aciyoruz. --seval.colak 17012022 simdilik kapatiyoruz.accrual devreye alindiginda acilacak.
     /* teminat Durum guncellenir */
     pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no,ln_hesap_no, ls_doviz_kodu);
      -- B-O-M   seval.colak 10102021
    if nvl(ln_odeme_plan_no,0) <> 0 then     
        update cbs_odeme_plan
        set kredi_hesap_no = ln_hesap_no,
             durum_kodu ='K',
             kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul 
        where odeme_plan_No = ln_odeme_plan_no;        
     end if;     
     --E-O-M   seval.colak 10102021 
     
exception when extra_approval then -- 04.01.2017 AdiletK CQ4714 extra approval
    raise_application_error(-20100,pkg_hata.getucpointer || '4660' || pkg_hata.getucpointer);
 End;
------------------------------------------------------------------------------------
Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ln_faiz_tahakkuk          cbs_hesap_kredi.hesap_no%type;
    ln_vergi_tahakkuk        cbs_hesap_kredi.hesap_no%type;
    ln_odeme_plan_no        number ; --seval.colak 10102021
    ln_cnt                  number; 
Begin
    sp_iptalkontrol(pn_islem_no);
    select hesap_no ,faiz_tahakkuk_hesap_no,vergi_tahakkuk_hesap_no
           ,odeme_plan_no           --seval.colak 10102021
    into ln_hesap_no,ln_faiz_tahakkuk,ln_vergi_tahakkuk
         ,ln_odeme_plan_no           --seval.colak 10102021
    from  cbs_hesap_kredi_islem
    where tx_no = pn_islem_no ;

    select nvl(count(*),0) into ln_cnt
      from cbs_hesap_kredi_taksit
     where hesap_no = ln_hesap_no
       and durum_kodu <> 'A';

    if ln_cnt > 0 then
      Raise_application_error(-20100,pkg_hata.getucpointer || '727' || pkg_hata.getucpointer);
    end if;
        
  /* hesap durum kodu I iptal statusune cevrilir */
    pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_hesap_no,'I');
    if ln_faiz_tahakkuk is not null then
          pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_faiz_tahakkuk,'I');
    end if;
    if ln_vergi_tahakkuk is not null then
       pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_vergi_tahakkuk,'I');
    end if;
    
     update cbs_hesap_kredi_islem
     set  durum_kodu = 'I'
     where tx_no = pn_islem_no;
     
     begin
     update cbs_hesap_kredi_taksit
     set durum_kodu = 'I'
     where hesap_no = ln_hesap_no;
     
     update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'I'
     where tx_no = pn_islem_no;     
     exception when others then null;
     end;
 -- B-O-M   seval.colak 10102021
       select odeme_plan_no   
        into ln_odeme_plan_no          
        from cbs_hesap_kredi_islem
        where tx_no = pn_islem_no;
                
    if nvl(ln_odeme_plan_no,0) <> 0 then 
       update cbs_odeme_plan
        set kredi_hesap_no = null,
             durum_kodu ='A',
             kapanis_tarihi = null 
        where odeme_plan_No = ln_odeme_plan_no;
     end if;
   --E-O-M   seval.colak 10102021  
        
     /* teminat Durum guncellenir */
      pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no,'ACILIS');
      Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
End;
------------------------------------------------------------------------------------
Procedure Reddetme_Sonrasi(pn_islem_no number) is
Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    /* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
    pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
End;
------------------------------------------------------------------------------------
Procedure Tamam_Sonrasi(pn_islem_no number) is
Begin
    Null;
End;
------------------------------------------------------------------------------------
Procedure Basim_Sonrasi(pn_islem_no number) is
Begin
    Null;
End;
------------------------------------------------------------------------------------
Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
Begin
    null;
End;
------------------------------------------------------------------------------------
Procedure Muhasebelesme(pn_islem_no number)
is
    varchar_list                   pkg_muhasebe.varchar_array;
    number_list                    pkg_muhasebe.number_array;
    date_list                      pkg_muhasebe.date_array;
    boolean_list                   pkg_muhasebe.boolean_array;
    ln_fis_no                      cbs_fis.numara%type ;
    ls_islem_kod                   cbs_islem.islem_kod%type :='1303';
    ls_banka_aciklama              varchar2(2000);
    ls_fis_aciklama                varchar2(2000);
    ls_aciklama                    varchar2(2000);
    ls_musteri_aciklama            varchar2(2000);
    ln_rezervasyon_no              number;
    ln_musteri_no                  cbs_musteri.musteri_no%TYPE;
    ln_borc_hesap_no               cbs_hesap_kredi.hesap_no%TYPE;
    ls_borc_hesap_sube_kodu        cbs_hesap_kredi.sube_kodu%TYPE;
    ls_borc_doviz_kodu             cbs_hesap_kredi.doviz_kodu%TYPE;
    ls_alacak_hesap_sube_kodu      cbs_hesap_kredi.sube_kodu%TYPE;
    ln_alacak_hesap_no             varchar2(200);
    ls_alacak_doviz_kodu           cbs_hesap_kredi.doviz_kodu%TYPE;
    ln_tutar                       cbs_hesap_kredi.tutar%type;
    ls_endeks_doviz_kodu           cbs_hesap_kredi.doviz_kodu%TYPE;
    ls_kullandirim_doviz_kodu      cbs_hesap_kredi.doviz_kodu%TYPE;
    ln_kur                         number;
    ln_musteri_kur                 number;
    ln_maliyet_kur                 number;
    ls_istatistik_kod              varchar2(2000);
    ls_dk_grup_kod                 CBS_MUSTERI.DK_GRUP_KOD%TYPE;
    ls_modul_tur_kod               CBS_HESAP.modul_tur_kod%TYPE;
    ls_urun_tur_kod                CBS_HESAP.urun_tur_kod%TYPE;
    ls_urun_sinif_kod              CBS_HESAP.urun_sinif_kod%TYPE;
    ls_musteri_tipi_kod            varchar2(100);
    ls_vergi_muafmi                varchar2(100);
    ln_service_tax_rate            number;
    ln_vat_tax_rate                number;
    ln_tl_kom_tutar                number := 0;
    ln_net_tax_oran                number := 0;
    cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
               select musteri_no,
                   sube_kodu,
                   hesap_no,
                   doviz_kodu,
                   decode(alacak_secimi,'DK',sube_kodu,pkg_hesap.HESAPSUBEAL(alacak_hesap_no)) ,
                   decode(alacak_secimi,'DK',alacak_dk_no,alacak_hesap_no),
                   decode(alacak_secimi,'DK',doviz_kodu,pkg_hesap.HESAPTANDOVIZKODUAL(alacak_hesap_no)),
                   nvl(tutar,0),
                   rezervasyon_no,
                   endeks_doviz_kodu,
                   kullandirim_doviz_kodu,
                   acilis_kuru,
                    prefix_istatistik_kodu||kullandirim_doviz_kodu||ISTATISTIK_KODU istatistik_kod ,
                   pkg_tx.Amir_BolumKodu_Al(tx_no),
                   'Account No:'|| to_char(hesap_no)|| ' Maturity Date:' || to_char(kredi_vade,'DD/MM/YYYY') ||' Interest Rate:'|| to_char(faiz_orani),
                   decode(alacak_secimi,'DK','DK','VS'),
                      Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
                      modul_tur_kod,
                    urun_tur_kod,
                   urun_sinif_kod,
                   COMMISSION_ACCOUNT_NO,
                   NVL(DISBURSEMENT_COMMISSION,0) komisyon_tutari,
                   pkg_kur.yuvarla(doviz_kodu,pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,nvl(DISBURSEMENT_COMMISSION,0),1,null,null,'N','A')) komisyon_tutari_yp,
                   pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A') mbdak_kur,
                   pkg_kur.doviz_doviz_karsilik(doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A') komisyon_kur,
                   pkg_musteri.sf_musteri_tipi_al(musteri_no) musteri_tipi_kod,
                   pkg_musteri.musteri_vergiden_muafmi(musteri_no) vergi_muafmi
            from cbs_hesap_kredi_islem
            where tx_no=pn_islemno;
  Begin
  ps_fis_mesaj  := null;
/* islem bilgisi detaylari alinir */

  number_list(pn_1303_net_kom_lc):= 0;
  number_list(pn_1303_service_tax_kom_lc):= 0;
  number_list(pn_1303_vat_tax_kom_lc):= 0;

  pkg_parametre.deger('G_SERVICE_TAX_RATE',ln_service_tax_rate);
  pkg_parametre.deger('G_VAT_RATE',ln_vat_tax_rate);


   if islem_cursor%isopen then
          close islem_cursor;
    end if;

         open islem_cursor(pn_islem_no);
           fetch islem_cursor into ln_musteri_no,
                                         ls_borc_hesap_sube_kodu,
                                   ln_borc_hesap_no,
                                   ls_borc_doviz_kodu,
                                         ls_alacak_hesap_sube_kodu,
                                   ln_alacak_hesap_no,
                                   ls_alacak_doviz_kodu,
                                   ln_tutar,
                                   ln_rezervasyon_no,
                                   ls_endeks_doviz_kodu,
                                   ls_kullandirim_doviz_kodu,
                                   ln_kur,
                                   ls_istatistik_kod,
                                   varchar_list(pn_1303_islem_sube),
                                   ls_banka_aciklama,
                                   varchar_list(pn_1303_hesap_tipi),
                                   ls_dk_grup_kod,
                                   ls_modul_tur_kod,
                                   ls_urun_tur_kod,
                                   ls_urun_sinif_kod,
                                   varchar_list(pn_1303_komisyon_hesap),
                                   number_list(pn_1303_komisyon_tutari),
                                   number_list(pn_1303_komisyon_tutari_lc),
                                   number_list(pn_1303_MBDAK_KUR),
                                   number_list(pn_1303_kom_kur),
                                   ls_musteri_tipi_kod,
                                   ls_vergi_muafmi  ;

    if islem_cursor%isopen then
          close islem_cursor;
    end if;

/*** Liste Deger Atama **/
     varchar_list(pn_1303_komisyon_dkno) :=Pkg_Muhasebe.Komisyon_DK_Bul( ls_dk_grup_kod,'DISBFEE');
     if varchar_list(pn_1303_komisyon_hesap) is not null then
         varchar_list(pn_1303_KOMISYON_SUBE):=pkg_hesap.HesapSubeAl(to_number(varchar_list(pn_1303_komisyon_hesap)));
     end if;
/**** varchar list ****/

  if ln_rezervasyon_no is null then
  /* o anki BDAK kuru ile guncellenir*/
     if  ls_endeks_doviz_kodu is not null then
           ln_kur := pkg_kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     else
          ln_kur := pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     end if;
        update cbs_hesap_kredi_islem
        set acilis_kuru =ln_kur
        where tx_no=pn_islem_no;
  end if;
   ls_aciklama :=   pkg_genel.ISLEM_ADI_AL(1303) ;
   ls_musteri_aciklama := ls_banka_aciklama ;
--   pkg_parametre.deger('1303_FIS_ACIKLAMA',ls_fis_aciklama);
--   pkg_parametre.deger('1303_BANKA_ACIKLAMA',ls_banka_aciklama);
--   pkg_parametre.deger('1303_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   varchar_list(pn_1303_fis_aciklama)      := nvl(ls_fis_aciklama,ls_aciklama) ;
   varchar_list(pn_1303_banka_aciklama)  := nvl(ls_banka_aciklama,ls_aciklama);
   varchar_list(pn_1303_musteri_aciklama):= nvl(ls_musteri_aciklama,ls_aciklama);
   varchar_list(pn_1303_referans)          := to_char(ln_borc_hesap_no);
   varchar_list(pn_1303_istatistik_kod)      := ls_istatistik_kod;

   varchar_list(pn_1303_borclu_hesap_no) := to_char(ln_borc_hesap_no);
   varchar_list(pn_1303_borclu_hesap_sube_kodu):=ls_borc_hesap_sube_kodu;
   varchar_list(pn_1303_borclu_doviz_kod):=ls_borc_doviz_kodu;
   varchar_list(pn_1303_endeks_doviz)    :=ls_endeks_doviz_kodu;

   varchar_list(pn_1303_alacak_hesap_no) := ln_alacak_hesap_no;
   varchar_list(pn_1303_alacak_hesap_sube_kodu):=ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1303_alacak_doviz_kod):=ls_alacak_doviz_kodu;
   varchar_list(pn_1303_komisyon_doviz) :=null;
   if varchar_list(pn_1303_hesap_tipi) ='DK' then
         varchar_list(pn_1303_musteri_hesap_no) := ' ';
         varchar_list(pn_1303_musteri_hesap_tipi) := ' ';
    else
        varchar_list(pn_1303_musteri_hesap_no) := ln_alacak_hesap_no;
        varchar_list(pn_1303_musteri_hesap_tipi) := 'VS';
    end if;

/**** boolean list ****/
    boolean_list(pn_1303_komisyon_tl):= FALSE;
    boolean_list(pn_1303_komisyon_yp):= FALSE;
    boolean_list(pn_1303_komisyon_var):= FALSE;
    boolean_list(pn_1303_tl_ise ):=false;
    boolean_list(pn_1303_yp_ise ):=false;
    boolean_list(pn_1303_endeks_ise):=false;
    boolean_list(pn_1303_musteri_kuru_buyukse ):=false;
    boolean_list(pn_1303_musteri_kuru_kucukse):= false;
    boolean_list(pn_1303_kullandirim_tl):=false;
    boolean_list(pn_1303_kullandirim_yp):=false;
/**** number list ****/
     if ls_endeks_doviz_kodu is not null then
     /* dovize endekli kredi */
         boolean_list(pn_1303_endeks_ise ):=true;
         number_list(pn_1303_fc_tutar) :=  pkg_kur.yuvarla(ls_borc_doviz_kodu,ln_tutar * ln_kur) ;
          number_list(pn_1303_tl_tutar) :=  number_list(pn_1303_fc_tutar) ;
          number_list(pn_1303_kur)       :=  1;
         number_list(pn_1303_bdak_tutar) :=  pkg_kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,pkg_genel.LC_AL,null,ln_tutar,1,null,null,'N','A');
         number_list(pn_1303_bdak_fc_tutar) := LN_TUTAR;
         number_list(pn_1303_bdak_kur) :=pkg_kur.doviz_doviz_karsilik(ls_endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A') ; --TRL
     else
         if ls_borc_doviz_kodu =pkg_genel.lc_al then
          /* trl kredi*/
             boolean_list(pn_1303_tl_ise ):=true;
              number_list(pn_1303_fc_tutar) := ln_tutar;
              number_list(pn_1303_tl_tutar) := pkg_kur.yuvarla(ls_borc_doviz_kodu,pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,LN_TUTAR,1,null,null,'N','A')); --m??teri al??) ;
              number_list(pn_1303_kur)       := pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'); --m??teri al?? ;
         else
          /* d?viz kredi*/
                 boolean_list(pn_1303_yp_ise ):=true;
                if ls_kullandirim_doviz_kodu = pkg_genel.lc_al then
                    /* kulland?r?m TRL ise */
                       boolean_list(pn_1303_kullandirim_tl):=true;

                    if nvl(ln_rezervasyon_no,0) != 0 then
                    /*rezervasyonlu */
                        pkg_kur_rezervasyon.rezervasyon_alis_bilgisi_al(ln_rezervasyon_no,ln_musteri_kur,ln_maliyet_kur);
                    else
                        ln_musteri_kur := pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'); --m??teri al??
                        ln_maliyet_kur := pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,1,3,null,null,'N','A'); --maliyet esas al??
                    end if;

                    if nvl(ln_musteri_kur,0) > nvl(ln_maliyet_kur,0) then
                            boolean_list( pn_1303_musteri_kuru_buyukse):=true;
                    else
                            boolean_list( pn_1303_musteri_kuru_kucukse):=true;
                    end if;

                    number_list(pn_1303_fc_tutar) := ln_tutar;
                   number_list(pn_1303_tl_tutar) := pkg_kur.yuvarla(ls_borc_doviz_kodu,ln_tutar * ln_kur) ;
                   number_list(pn_1303_kur)         := ln_maliyet_kur;
                   number_list(pn_1303_musteri_tutar)  := ln_tutar* ln_musteri_kur;
                   number_list(pn_1303_maliyet_tutar)  := ln_tutar* ln_maliyet_kur;
                   number_list(pn_1303_fark_tutar) := abs(    ln_musteri_kur -ln_maliyet_kur) * ln_tutar ;
                 else
                /* kulland?r?m YP ise */
                   boolean_list(pn_1303_kullandirim_yp):=true;
                   number_list(pn_1303_fc_tutar) := ln_tutar;
                     number_list(pn_1303_tl_tutar) := pkg_kur.yuvarla(ls_borc_doviz_kodu,pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,LN_TUTAR,1,null,null,'N','A')); --m??teri al??) ;
                     number_list(pn_1303_kur)       := pkg_kur.doviz_doviz_karsilik(ls_borc_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'); --m??teri al?? ;
                end if;
          end if;
     end if;

 number_list(pn_1303_komisyon_komtutar) := 0;
    if number_list(pn_1303_komisyon_tutari) <> 0 then
        boolean_list(pn_1303_komisyon_var):= true;
        /*Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
                        NULL,NULL, NULL,varchar_list(pn_1303_komisyon_dkno));
                       */
        number_list(pn_1303_komisyon_komtutar) :=pkg_kur.yuvarla(pkg_genel.lc_al,nvl(number_list(pn_1303_komisyon_tutari),0)  *  nvl(number_list(pn_1303_kom_kur),0)) ;
    else
        boolean_list(pn_1303_komisyon_var):= false;
    end if;

     if varchar_list(pn_1303_komisyon_hesap) is not null then
          varchar_list(pn_1303_komisyon_doviz):= pkg_hesap.HesaptanDovizKoduAl(  varchar_list(pn_1303_komisyon_hesap));

        if varchar_list(pn_1303_komisyon_doviz)  =pkg_genel.lc_al then
               boolean_list(pn_1303_komisyon_tl) := true;
         else
             boolean_list(pn_1303_komisyon_yp) := true;
         end if;
    end if;

-- B-O-M sevalb  KG degisiklikleri 181206
     if ls_borc_doviz_kodu <> pkg_genel.lc_al and  varchar_list(pn_1303_komisyon_doviz)  =pkg_genel.lc_al  then
           ln_tl_kom_tutar :=  abs(number_list(pn_1303_komisyon_komtutar));
    else
        ln_tl_kom_tutar :=  abs(number_list(pn_1303_komisyon_tutari_lc));
    end if;

    /*"Net Disb.com",Musteri tipi 1-Ind. Ise "Disb.com. / 1.24" formulu ile bulunur.
    Mus.tipi 1'den farkl? ise "Disb.com. * VAT tax rate/ 100+ VAT tax rate" formulu ile
    once tax amount bulunur;
    "Disb.com (-) tax amount" formulu ile Net Disb.com.bulunur.
    */
  if number_list(pn_1303_komisyon_tutari) <> 0 then
         if ls_vergi_muafmi = 'E' then
            number_list(pn_1303_net_kom_lc) := nvl(ln_tl_kom_tutar,0) ;
          number_list(pn_1303_service_tax_kom_lc) := 0;
             number_list(pn_1303_vat_tax_kom_lc) := 0;
       else
         if ls_musteri_tipi_kod = '1' then
                  ln_net_tax_oran := 1 + ( ( nvl(ln_service_tax_rate,0) + nvl(ln_vat_tax_rate,0)) /100 );
                  number_list(pn_1303_net_kom_lc) :=  pkg_kur.YUVARLA(pkg_genel.lc_al, nvl(ln_tl_kom_tutar,0) / nvl( ln_net_tax_oran,0));
               number_list(pn_1303_vat_tax_kom_lc)     := pkg_kur.YUVARLA(pkg_genel.lc_al,  number_list(pn_1303_net_kom_lc) * nvl(ln_vat_tax_rate,0) /100);
               number_list(pn_1303_service_tax_kom_lc) := nvl(ln_tl_kom_tutar,0) - ( nvl(number_list(pn_1303_net_kom_lc),0) + number_list(pn_1303_vat_tax_kom_lc));
         else

             number_list(pn_1303_vat_tax_kom_lc) :=  pkg_kur.YUVARLA(pkg_genel.lc_al,nvl(ln_tl_kom_tutar,0) *  (ln_vat_tax_rate / (100 + ln_vat_tax_rate)));
            number_list(pn_1303_net_kom_lc)   := nvl(ln_tl_kom_tutar,0) - number_list(pn_1303_vat_tax_kom_lc);
             number_list(pn_1303_service_tax_kom_lc) := 0;
         end if;
      end if;

  end if;
-- E-O-M sevalb  KG degisiklikleri 181206

/* kredi hesap acilis muhasebesi calistirilir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            null);


    pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

    pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,'ACILIS');
  Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '507' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

/***************************************************************************************************************/
/*    Procedure sp_Teminat_iptalsonrasi                                                               */
/***************************************************************************************************************/
Procedure sp_iptalkontrol(pn_islem_no number)
is
cursor cursor_islem is
       select max(distinct a.tx_no)   tx_no
       from  cbs_hesap_kredi_islem a,cbs_islem b
      where a.tx_no = b.numara and
              b.durum not in( '2','R') and
            a.tx_no > pn_islem_no and
            b.ISLEM_KOD not in(1304) and
            a.hesap_no in (select hesap_no
                             from cbs_hesap_kredi_islem
                            where tx_no = pn_islem_no );

  ln_tx_no              number;
  islemvar              exception;
  ln_teminat_no         number;
Begin
 /* islemden sonra bitmis ve de?i?iklik yap?lm?? islem varsa iptale izin verilemez. */

  for cur_islem in cursor_islem
  loop
        ln_tx_no := cur_islem.tx_no;
  end loop;

    if nvl(ln_tx_no,0) <> 0 then
       raise islemvar ;
    end if;

  Exception
   When  islemvar then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '725' || pkg_hata.getDelimiter ||to_char(ln_tx_no)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then null;

 End;
------------------------------------------------------------------------------------
 procedure sp_kontrol_sonrasi_rezervasyon(pn_islem_no number ) is
 ln_doviz_tutari number;
    ln_bakiye number;

    CURSOR islem_cursor IS
                SELECT * from CBS_HESAP_KREDI_ISLEM
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
   Begin

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    if row_islem.REZERVASYON_NO is not null then

       ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

       IF row_islem.TUTAR >ln_bakiye THEN --Bakiye Yetersiz..
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
       else
          Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                           pn_islem_no,
                                                           row_islem.TUTAR);
       END IF;
    end if;
 Exception when others then null;
 End;
------------------------------------------------------------------------------------
BEGIN
        pn_1303_borclu_doviz_kod :=pkg_muhasebe.parametre_index_bul('1303_BORCLU_DOVIZ_KOD');
        pn_1303_fc_tutar :=pkg_muhasebe.parametre_index_bul('1303_FC_TUTAR');
        pn_1303_ekran_kurlu_tutar :=pkg_muhasebe.parametre_index_bul('1303_EKRAN_KURLU_TUTAR');
        pn_1303_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1303_BANKA_ACIKLAMA');
        pn_1303_borclu_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1303_BORCLU_HESAP_SUBE_KODU');
        pn_1303_borclu_hesap_no :=pkg_muhasebe.parametre_index_bul('1303_BORCLU_HESAP_NO');
        pn_1303_alacak_hesap_sube_kodu :=pkg_muhasebe.parametre_index_bul('1303_ALACAK_HESAP_SUBE_KODU');
        pn_1303_alacak_hesap_no :=pkg_muhasebe.parametre_index_bul('1303_ALACAK_HESAP_NO');
        pn_1303_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_ACIKLAMA');
        pn_1303_referans :=pkg_muhasebe.parametre_index_bul('1303_REFERANS');
        pn_1303_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1303_FIS_ACIKLAMA');
        pn_1303_istatistik_kod :=pkg_muhasebe.parametre_index_bul('1303_ISTATISTIK_KOD');
        pn_1303_tutar_bdak :=pkg_muhasebe.parametre_index_bul('1303_TUTAR_BDAK');
        pn_1303_islem_sube :=pkg_muhasebe.parametre_index_bul('1303_ISLEM_SUBE');
        pn_1303_alacak_doviz_kod :=pkg_muhasebe.parametre_index_bul('1303_ALACAK_DOVIZ_KOD');
        pn_1303_tl_tutar :=pkg_muhasebe.parametre_index_bul('1303_TL_TUTAR');
        pn_1303_kur :=pkg_muhasebe.parametre_index_bul('1303_KUR');
        pn_1303_tl_ise :=pkg_muhasebe.parametre_index_bul('1303_TL_ISE');
        pn_1303_yp_ise :=pkg_muhasebe.parametre_index_bul('1303_YP_ISE');
        pn_1303_musteri_kuru_buyukse :=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_KURU_BUYUKSE');
        pn_1303_musteri_kuru_kucukse :=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_KURU_KUCUKSE');
        pn_1303_endeks_ise :=pkg_muhasebe.parametre_index_bul('1303_ENDEKS_ISE');
        pn_1303_kullandirim_tl :=pkg_muhasebe.parametre_index_bul('1303_KULLANDIRIM_TL');
        pn_1303_kullandirim_yp :=pkg_muhasebe.parametre_index_bul('1303_KULLANDIRIM_YP');
        pn_1303_bdak_kur :=pkg_muhasebe.parametre_index_bul('1303_BDAK_KUR');
        pn_1303_bdak_tutar :=pkg_muhasebe.parametre_index_bul('1303_BDAK_TUTAR');
        pn_1303_endeks_doviz :=pkg_muhasebe.parametre_index_bul('1303_ENDEKS_DOVIZ');
        pn_1303_fark_tutar :=pkg_muhasebe.parametre_index_bul('1303_FARK_TUTAR');
        pn_1303_musteri_tutar :=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_TUTAR');
        pn_1303_maliyet_tutar :=pkg_muhasebe.parametre_index_bul('1303_MALIYET_TUTAR');
        pn_1303_bdak_fc_tutar :=pkg_muhasebe.parametre_index_bul('1303_BDAK_FC_TUTAR');
        pn_1303_borclu_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1303_BORCLU_TEMINAT_HESAP');
        pn_1303_alacak_teminat_hesap :=pkg_muhasebe.parametre_index_bul('1303_ALACAK_TEMINAT_HESAP');
        pn_1303_teminat_doviz :=pkg_muhasebe.parametre_index_bul('1303_TEMINAT_DOVIZ');
        pn_1303_kullan_teminattutar :=pkg_muhasebe.parametre_index_bul('1303_KULLANILAN_TEMINAT_TUTARI');
        pn_1303_kullan_tl_teminattutar :=pkg_muhasebe.parametre_index_bul('1303_KULLANILAN_TL_TEMINAT_TUT');
        pn_1303_borclu_teminhesapsube :=pkg_muhasebe.parametre_index_bul('1303_BORCLU_TEMINAT_HESAP_SUBE');
        pn_1303_HESAP_TIPI :=pkg_muhasebe.parametre_index_bul('1303_HESAP_TIPI');
        pn_1303_MUSTERI_HESAP_NO:=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_HESAP_NO');
        pn_1303_MUSTERI_HESAP_TIPI:=pkg_muhasebe.parametre_index_bul('1303_MUSTERI_HESAP_TIPI');
        pn_1303_komisyon_dkno :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_DKNO');
        pn_1303_komisyon_tl :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_TL');
        pn_1303_komisyon_yp :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_YP');
        pn_1303_komisyon_hesap :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_HESAP');
        pn_1303_komisyon_tutari :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_TUTARI');
        pn_1303_komisyon_tutari_lc :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_TUTARI_LC');
        pn_1303_komisyon_komtutar :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_KOMTUTAR');
        pn_1303_kom_kur :=pkg_muhasebe.parametre_index_bul('1303_KOM_KUR');
        pn_1303_mbdak_kur :=pkg_muhasebe.parametre_index_bul('1303_MBDAK_KUR');
        pn_1303_komisyon_var :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_VAR');
        pn_1303_komisyon_doviz :=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_DOVIZ');
        pn_1303_KOMISYON_SUBE:=pkg_muhasebe.parametre_index_bul('1303_KOMISYON_SUBE');
        pn_1303_net_kom_lc :=pkg_muhasebe.parametre_index_bul('1303_NET_KOM_LC');
        pn_1303_vat_tax_kom_lc :=pkg_muhasebe.parametre_index_bul('1303_VAT_TAX_KOM_LC');
        pn_1303_service_tax_kom_lc :=pkg_muhasebe.parametre_index_bul('1303_SERVICE_TAX_KOM_LC');


END ;
/

