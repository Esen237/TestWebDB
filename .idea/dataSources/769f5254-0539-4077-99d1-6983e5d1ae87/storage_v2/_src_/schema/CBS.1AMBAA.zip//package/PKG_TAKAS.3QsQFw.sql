create PACKAGE Pkg_Takas IS

 FUNCTION takas_merkezi_mi(ps_bolum_kodu VARCHAR2) RETURN NUMBER;
 PROCEDURE cek_no_kontrol(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0);
 FUNCTION takas_merkezine_bagli(ps_takas_bolum VARCHAR2, ps_bolum VARCHAR2) RETURN NUMBER;
 FUNCTION cek_var(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER) RETURN NUMBER;
 FUNCTION bitmemis_islem_var_mi(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0) RETURN NUMBER;
 FUNCTION bitmemis_islem_var_mi(pn_ref_cek_no NUMBER, pn_islem_no NUMBER) RETURN NUMBER;
 FUNCTION cikis_yapilir_durum(ps_durum VARCHAR2, ps_bolum VARCHAR2) RETURN NUMBER;
 PROCEDURE takas_cek_detay_al(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2, pn_cek_no IN NUMBER,
                             ps_bolum_kodu OUT VARCHAR2, ps_bolum_adi OUT VARCHAR2,
							 pn_musteri_no OUT VARCHAR2, ps_musteri OUT VARCHAR2, ps_tahsil_teminat OUT VARCHAR2,
							 ps_tahsil_hesap OUT NUMBER, ps_tahsil_doviz OUT VARCHAR2, ps_masraf_hesap OUT VARCHAR2,
							 ps_masraf_doviz  OUT VARCHAR2, ps_kesideci_adi  OUT VARCHAR2, ps_tem_al_hesap  OUT VARCHAR2,
							 ps_tem_al_hes_dov  OUT VARCHAR2, pd_takas_tarihi OUT DATE, pn_cek_tutar OUT NUMBER,
							 ps_kesideci_hesap  OUT VARCHAR2, pd_keside_tarih OUT DATE, ps_keside_yeri  OUT VARCHAR2,
							 ps_cek_tipi  OUT VARCHAR2, ps_cek_durum  OUT VARCHAR2, ps_cek_doviz OUT VARCHAR2,
							 ps_masraf_alindi OUT VARCHAR2, pn_ref_cek_no OUT NUMBER, ps_tahsil_edilecek OUT VARCHAR2,
							 pn_masraf_tx OUT NUMBER);
 PROCEDURE cek_duzeltilebilir(pn_ref_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0);

 PROCEDURE takas_cek_klonla(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2,
                            pn_cek_no NUMBER, pn_tx_no NUMBER);

 FUNCTION iade_adi_al(ps_cikis_iade_kodu VARCHAR2) RETURN VARCHAR2;
 FUNCTION teminat_kullaniliyor_mu(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER) RETURN NUMBER;
 PROCEDURE takas_cek_elden_tahsil_al(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2, pn_cek_no IN NUMBER,
                                     pn_elden_thsl_nostrohsp OUT NUMBER, ps_elden_thsl_nostrohsp_dvz OUT VARCHAR2);
 FUNCTION bankamiz_cek_durum_al(ps_cek_durum VARCHAR2) RETURN VARCHAR2;
 PROCEDURE takas_giden_file_olustur(pd_tarih DATE, ps_cek_tipi VARCHAR2, ps_sube VARCHAR2);
 FUNCTION teminat_zorunluluk(pn_tx_no NUMBER) RETURN NUMBER;
 FUNCTION teminat_kullaniliyor_mu(pn_ref_cek_no NUMBER) RETURN NUMBER;
 FUNCTION teminat_islem_var(pn_tx_no NUMBER) RETURN NUMBER;
 FUNCTION DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER;
 PROCEDURE sehir_tasra_belirle(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2,
                               ps_sehir_tasra IN OUT VARCHAR2);
 PROCEDURE cek_no_kontrol_duzelt(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2,
                                 pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0,
								 pn_ref_cek_no NUMBER);
 PROCEDURE sp_takascek_tahstemin_guncelle ( pn_ref_cek_no   CBS_TAKAS_CEK.ref_cek_no%TYPE ,ps_tahsil_teminat CBS_TAKAS_CEK.tahsil_teminat%TYPE  );
 FUNCTION sf_takascek_durumu_al(pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN CBS_TAKAS_CEK.cek_durum%TYPE;
 FUNCTION sf_takascek_tutari_al(pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN CBS_TAKAS_CEK.cek_durum%TYPE;
 FUNCTION sf_takascek_vadetarihi_al(pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN DATE;
 FUNCTION sf_takascek_tahsiledilecek_al(pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN VARCHAR2;
 PROCEDURE takas_cek_dosya_kaydet(ps_satir VARCHAR2,ps_bolum_kodu VARCHAR2,ps_tahsil_teminat VARCHAR2,ps_keside_yeri VARCHAR2,
		  					     pn_tahsil_hesap_no NUMBER, pn_masraf_hesap_no NUMBER,pn_teminat_alacak_hesap_no NUMBER);

 END;

/

