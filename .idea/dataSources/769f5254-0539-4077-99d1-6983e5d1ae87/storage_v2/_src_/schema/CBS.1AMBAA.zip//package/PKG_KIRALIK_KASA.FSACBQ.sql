create PACKAGE     Pkg_Kiralik_Kasa IS

/******************************************************************************
   Name       : PKG_KIRALIK_KASA
   Created By : G?lnihal Cengiz
   Date    	  : 24/12/2004
   Purpose	  : Kiral?k Kasa ??lemleri
******************************************************************************/
 FUNCTION Sf_Kasa_Referans_No_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN VARCHAR2;
 FUNCTION Sf_Kasa_Musteri_No_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN NUMBER;
 FUNCTION Sf_Kasa_Vade_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN DATE;
 FUNCTION Sf_Yenileme_Tarihi_Al(pn_SAFE_BOX_NO CBS_KIRALIK_KASA_TANIM.SAFE_BOX_NO%TYPE,
 		  						pn_sube_kodu CBS_KIRALIK_KASA_TANIM.SUBE_KODU%TYPE) RETURN DATE;


END;
/

