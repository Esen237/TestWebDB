create PACKAGE BODY     PKG_PAYMENT_PLAN_WS IS
/******************************************************************************
NAME        : FUNCTION getPaymentPlan
Prepared By : Bahiana Bektemir kyzy
Date        : 27.05.2021
Purpose     : Generate payment plan for customers
******************************************************************************/
FUNCTION getPaymentPlan( ps_caller_payment_no in varchar2 default '0',
                         ps_caller_tx_no in varchar2 default '0',
                         ps_principal in varchar2,
                         ps_term in varchar2,
                         ps_interest_rate in varchar2,
                         ps_kkdf_rate in varchar2,
                         ps_bsmv_rate in varchar2,
                         ps_payment_day in varchar2,
                         ps_custom_first_payment_date in varchar2 default null,
                         ps_first_installment_type in varchar2,
                         ps_utilization_date in varchar2,
                         ps_interest_rate_type in varchar2,
                         ps_payment_plan_type in varchar2,
                         ps_calculation_type in varchar2,
                         ps_working_day_type in varchar2,
                         ps_duration in varchar2,
                         ps_no_payment_period in varchar2 default null,
                         ps_frequency_code in varchar2,
                         ps_additional_interest in varchar2,
                         ps_rate_divider in varchar2 default null,
                         ps_expense_amount  in varchar2,
                         ps_expense_payer_type in varchar2,
                         ps_expense_type in varchar2,
                         ps_commissions in varchar2 default null,
                         ps_commission_type in varchar2,
                         ps_commission_rate in varchar2,
                         ps_commission_amount in varchar2,
                         ps_increase_rate in varchar2,
                         ps_increase_frequency in varchar2,
                         ps_frequency_value in varchar2,
                         ps_fraction_digits in varchar2,
                         ps_yearly_cost_fraction_digits in varchar2,
                         ps_interest_usage_type in varchar2,
                         ps_tbl_type_extpaylist in type_extpaylist,
                         pn_tbl_type_extpaylist_cnt in number
                         ) RETURN VARCHAR2 
                          
IS PRAGMA AUTONOMOUS_TRANSACTION;

   ls_returncode varchar2(3):='000';
   ls_service_return_code varchar2(3):='000';
   ls_content varchar2(32767):='';
   ls_res clob;
   ls_pp_ws_service_url varchar2(300);
   ls_method_name varchar2(10) := 'POST';
   ln_rate_divider number;
   ln_counter number;
   ln_elapsed_milliseconds number;
   ln_yearly_cost_rate number;
   ln_monthly_cost_rate number;
   ln_total_days number;
   ln_payment_number number;
   ld_payment_date date;
   ln_amount number;
   ln_days number;
   ln_period_days number;
   ln_principal number;
   ln_interest number;
   ln_additional_interest number;
   ln_interest_portion number;
   ln_installment_amount number;
   ln_principal_portion number;
   ln_not_used_interest number;
   ln_principal_balance number;
   ln_kkdf number;
   ln_bsmv number;
   ln_kkdf_interest number;
   ln_bsmv_interest number;
   ln_total_interest number;
   ln_extra_payment_amount number;
   ld_real_payment_date date;
   ln_orj_interest number;
   ln_orj_kkdf number;
   ln_orj_bsmv number;
   ln_orj_interest_portion number;
   ln_interest_portion_diff number;
   ls_installment_type varchar2(100);
   ls_commission_type varchar2(50);
   ln_commission_rate number;
   ln_commission_amount number;
   l_resp_json json_object_t;
   l_payments json_array_t;
   l_payment_json json_object_t;
   l_yearly_cost_obj json_object_t;
   l_commissions_obj json_object_t;
   l_keys json_key_list; --NurmilaZ
   ln_ws_callid number;
      
   ld_starttime DATE;
   ld_endtime DATE;
   ln_errorMessage varchar2(4000 byte); 
   l_webservice_error  exception; 
BEGIN
    BEGIN       
        pkg_parametre.deger('PP_WS_SERVICE_URL',LS_PP_WS_SERVICE_URL);
        
        ld_starttime:=SYSDATE;
         
        log_at('PAYMENT_LOG_SIMUL','ps_caller_payment_no ' || ps_caller_payment_no || ' ' ||
        'ps_caller_tx_no ' || ps_caller_tx_no || ' ' ||
        'ps_principal ' || ps_principal || ' ' ||
        'ps_term '  || ps_term || ' ' ||
        'ps_interest_rate ' || ps_interest_rate || ' ' ||
        'ps_kkdf_rate ' || ps_kkdf_rate || ' ' ||
        'ps_bsmv_rate ' || ps_bsmv_rate || ' ' ||
        'ps_payment_day ' || ps_payment_day || ' ' ||
        'ps_custom_first_payment_date ' || ps_custom_first_payment_date || ' ' ||
        'ps_first_installment_type ' || ps_first_installment_type || ' ' ||
        'ps_utilization_date ' || ps_utilization_date || ' ' ||
        'ps_interest_rate_type ' || ps_interest_rate_type || ' ' ||
        'ps_payment_plan_type ' || ps_payment_plan_type || ' ' ||
        'ps_calculation_type ' || ps_calculation_type || ' ' ||
        'ps_working_day_type ' || ps_working_day_type || ' ' ||
        'ps_duration ' || ps_duration || ' ' ||
        'ps_no_payment_period ' || ps_no_payment_period || ' ' ||
        'ps_frequency_code ' || ps_frequency_code || ' ' ||
        'ps_additional_interest ' || ps_additional_interest || ' ' ||
        'ps_rate_divider ' || ps_rate_divider || ' ' ||
        'ps_expense_amount ' || ps_expense_amount || ' ' ||
        'ps_expense_payer_type ' || ps_expense_payer_type || ' ' ||
        'ps_expense_type ' || ps_expense_type || ' ' ||
        'ps_commissions ' || ps_commissions || ' ' ||
        'ps_commission_type ' || ps_commission_type || ' ' ||
        'ps_commission_rate ' || ps_commission_rate || ' ' ||
        'ps_commission_amount ' || ps_commission_amount || ' ' ||
        'ps_increase_rate ' || ps_increase_rate || ' ' ||
        'ps_increase_frequency ' || ps_increase_frequency || ' ' ||
        'ps_frequency_value ' || ps_frequency_value || ' ' ||
        'ps_fraction_digits ' || ps_fraction_digits || ' ' ||
        'ps_yearly_cost_fraction_digits ' || ps_yearly_cost_fraction_digits || ' ' ||
        'ps_interest_usage_type ' || ps_interest_usage_type || ' ' ||
        'pn_tbl_type_extpaylist_cnt ' || pn_tbl_type_extpaylist_cnt
        );
        
        ls_content := ls_content || '{';
        ls_content := ls_content || '"principal":' || ps_principal || ',';
        ls_content := ls_content || '"term":' || ps_term || ',';
        ls_content := ls_content || '"interestRate":' || ps_interest_rate || ',';
        ls_content := ls_content || '"kkdfRate":' || ps_kkdf_rate || ',';
        ls_content := ls_content || '"bsmvRate":' || ps_bsmv_rate || ',';
        ls_content := ls_content || '"paymentDay":' || ps_payment_day || ',';
        
        -- idate is not empty-> use "" and if it is empty then not use ""
        if ps_custom_first_payment_date is not null then
            ls_content := ls_content || '"customFirstPaymentDate":"' || ps_custom_first_payment_date || '",';
        else
            ls_content := ls_content || '"customFirstPaymentDate": null,';
        end if;
        
        ls_content := ls_content || '"firstInstallmentType":"' || ps_first_installment_type || '",';
        ls_content := ls_content || '"utilizationDate":"' || ps_utilization_date || '",';
        ls_content := ls_content || '"interestRateType":"' || ps_interest_rate_type || '",';
        ls_content := ls_content || '"paymentPlanType":"' || ps_payment_plan_type || '",';
        ls_content := ls_content || '"calculationType":"' || ps_calculation_type || '",';
        ls_content := ls_content || '"workingDayType":"' || ps_working_day_type || '",';
        ls_content := ls_content || '"duration":' || ps_duration || ',';
        
        if ps_no_payment_period is not null then
            ls_content := ls_content || '"noPaymentPeriod":' || ps_no_payment_period || ',';
        else
            ls_content := ls_content || '"noPaymentPeriod": null,';
        end if; 
           
        ls_content := ls_content || '"frequencyCode":"' || ps_frequency_code || '",';
        ls_content := ls_content || '"additionalInterest":' || ps_additional_interest || ',';
        
        if ps_rate_divider is not null then
            ls_content := ls_content || '"rateDivider":' || ps_rate_divider || ','; 
        else
            ls_content := ls_content || '"rateDivider": null,';
        end if;      
        
        ls_content := ls_content || '"expenses":[{';
        ls_content := ls_content || '"amount":' || ps_expense_amount || ',';
        ls_content := ls_content || '"payerType":"' || ps_expense_payer_type || '",';
        ls_content := ls_content || '"expenseType":"' || ps_expense_type || '"';
        ls_content := ls_content || '}],';
        
        if ps_commissions is not null then
            ls_content := ls_content || '"commissions":' || ps_commissions || ','; 
        else
            ls_content := ls_content || '"commissions": null,';
        end if;     
        
        ls_content := ls_content || '"commission":{';
        ls_content := ls_content || '"commissionType":"' || ps_commission_type || '",';
        ls_content := ls_content || '"commissionRate":' || ps_commission_rate || ',';
        ls_content := ls_content || '"commissionAmount":' || ps_commission_amount;
        ls_content := ls_content || '},';
            
        ls_content := ls_content || '"increaseRate":' || ps_increase_rate || ',';
        ls_content := ls_content || '"increaseFrequency":' || ps_increase_frequency || ',';
        ls_content := ls_content || '"frequencyValue":' || ps_frequency_value || ',';
        ls_content := ls_content || '"fractionDigits":' || ps_fraction_digits || ','; 
        ls_content := ls_content || '"yearlyCostFractionDigits":' || ps_yearly_cost_fraction_digits || ','; 
        ls_content := ls_content || '"interestUsageType":"' || ps_interest_usage_type || '",';
         
        if nvl(pn_tbl_type_extpaylist_cnt ,0) = 0  then
           ls_content := ls_content || '"extraPaymentList":' || '[]'; 
        else
            ls_content := ls_content || '"extraPaymentList":[';
            for i in 0..pn_tbl_type_extpaylist_cnt-1    
            loop
               if i > 0 then
                ls_content := ls_content || ',';
               end if;
               ls_content := ls_content || '{"paymentNumber":' || ps_tbl_type_extpaylist(i+1).paymentnumber;
               ls_content := ls_content || ',"amount":' || ps_tbl_type_extpaylist(i+1).amount;  
               ls_content := ls_content || ',"installmentType":"' || ps_tbl_type_extpaylist(i+1).installmenttypes || '"';  
               ls_content := ls_content || ',"totalDays": 0}';    
               log_At('bah', ps_tbl_type_extpaylist(i+1).paymentnumber , ps_tbl_type_extpaylist(i+1).amount,ps_tbl_type_extpaylist(i+1).installmenttypes);
            end loop;
            ls_content := ls_content || ']';
        end if; 
        
        ls_content := ls_content || '}';

        log_at('pkg_payment_plan_ws.getPaymentPlan', 1, sqlcode, sqlerrm);
        ls_service_return_code := CORPINT2.PKG_REST.SENDREQUESTJSON (ls_pp_ws_service_url, ls_method_name, ls_content, ls_res);
        log_at('pkg_payment_plan_ws.getPaymentPlan', 2, sqlcode, sqlerrm);
    
    
        IF ls_service_return_code <> '000' THEN
        log_at('pkg_payment_plan_ws.getPaymentPlan', 3, ls_service_return_code, sqlerrm);
            return ls_service_return_code;
        END IF; 
    
        ln_ws_callid:=pkg_genel.genel_kod_al('PAYMENTWSCALLID');
        
        
        l_resp_json := json_object_t.parse( ls_res );
        l_keys := l_resp_json.get_keys;
    
        if l_keys(3) <> 'errorMessage' then
                ln_rate_divider := l_resp_json.get('rateDivider').to_number;
                ln_counter :=l_resp_json.get('counter').to_number;
                ln_elapsed_milliseconds :=l_resp_json.get('elapsedMilliseconds').to_number;
                l_yearly_cost_obj := TREAT (l_resp_json.get('yearlyCostRate') AS json_object_t);
                ln_yearly_cost_rate :=l_yearly_cost_obj.get('yearlyCostRate').to_number;
                ln_monthly_cost_rate :=l_yearly_cost_obj.get('monthlyCostRate').to_number;
                ln_total_days :=l_resp_json.get('totalDays').to_number;
                l_payments := l_resp_json.get_array( 'paymentPlan' );
               

                FOR indx IN 0 .. l_payments.get_size() - 1 
                loop
                   l_payment_json := TREAT (l_payments.get (indx) AS json_object_t);
                   ln_payment_number := l_payment_json.get('paymentNumber').to_number;
                   ld_payment_date  := l_payment_json.get('paymentDate').to_date;
                   ln_amount  := l_payment_json.get('amount').to_number;
                   ln_days  := l_payment_json.get('days').to_number;
                   ln_period_days  := l_payment_json.get('periodDays').to_number;
                   ln_principal := l_payment_json.get('principal').to_number;
                   ln_interest := l_payment_json.get('interest').to_number;
                   ln_additional_interest := l_payment_json.get('additionalInterest').to_number;
                   ln_interest_portion := l_payment_json.get('interestPortion').to_number;
                   ln_installment_amount := l_payment_json.get('installmentAmount').to_number;
                   ln_principal_portion := l_payment_json.get('principalPortion').to_number;
                   ln_not_used_interest := l_payment_json.get('notUsedInterest').to_number;
                   ln_principal_balance := l_payment_json.get('principalBalance').to_number;
                   ln_kkdf := l_payment_json.get('kkdf').to_number;
                   ln_bsmv := l_payment_json.get('bsmv').to_number;
                   ln_kkdf_interest := l_payment_json.get('kkdfInterest').to_number;
                   ln_bsmv_interest := l_payment_json.get('bsmvInterest').to_number;
                   ln_total_interest := l_payment_json.get('totalInterest').to_number;
                   ln_extra_payment_amount := l_payment_json.get('extraPaymentAmount').to_number;
                   ld_real_payment_date := l_payment_json.get('realPaymentDate').to_date;
                   ln_orj_interest := l_payment_json.get('orjInterest').to_number;
                   ln_orj_kkdf := l_payment_json.get('orjKkdf').to_number;
                   ln_orj_bsmv := l_payment_json.get('orjBsmv').to_number;
                   ln_orj_interest_portion := l_payment_json.get('orjInterestPortion').to_number;
                   ln_interest_portion_diff := l_payment_json.get('interestPortionDiff').to_number;
                   ls_installment_type := l_payment_json.get_string('installmentType');
                  
                      dbms_output.put_line('number=' || ln_payment_number);
                      dbms_output.put_line('call id=' || ln_ws_callid);
                      
                l_commissions_obj := TREAT (l_resp_json.get('commission') AS json_object_t);
                ls_commission_type :=l_commissions_obj.get_string('commissionType');
                ln_commission_rate :=l_commissions_obj.get('commissionRate').to_number;
                ln_commission_amount :=l_commissions_obj.get('commissionAmount').to_number;
                      
                    INSERT INTO CBS.CBS_PAYMENT_PLAN_WS (
                       PAYMENT_WS_CALLID, PAYMENT_NUMBER, 
                       PAYMENT_DATE, AMOUNT, DAYS, 
                       PERIOD_DAYS, PRINCIPAL, INTEREST, 
                       ADDITIONAL_INTEREST, INTEREST_PORTION, INSTALLMENT_AMOUNT, 
                       PRINCIPAL_PORTION, NOT_USED_INTEREST, PRINCIPAL_BALANCE, 
                       KKDF, BSMV, KKDF_INTEREST, 
                       BSMV_INTEREST, TOTAL_INTEREST, EXTRA_PAYMENT_AMOUNT, 
                       REAL_PAYMENT_DATE, ORIJ_INTEREST, ORIJ_KKDF, 
                       ORIJ_BSMV, ORIJ_INT_PORTION, INT_PORTION_DIFF, 
                       INSTALLMENT_TYPE,RATE_DIVIDER,COUNTER,ELAPSED_MILLISECONDS,YEARLY_COST_RATE,MONTHLY_COST_RATE,TOTAL_DAYS,COMMISSION_TYPE,COMMISSION_RATE,COMMISSION_AMOUNT, CALLER_PAYMENT_NO, CALLER_TX_NO) 
                    VALUES ( ln_ws_callid, ln_payment_number,  
                     ld_payment_date, ln_amount, ln_days,
                     ln_period_days, ln_principal, ln_interest,
                     ln_additional_interest, ln_interest_portion, ln_installment_amount,
                     ln_principal_portion, ln_not_used_interest, ln_principal_balance,
                     ln_kkdf, ln_bsmv, ln_kkdf_interest,
                     ln_bsmv_interest, ln_total_interest, ln_extra_payment_amount,
                     ld_real_payment_date, ln_orj_interest, ln_orj_kkdf,
                     ln_orj_bsmv, ln_orj_interest_portion, ln_interest_portion_diff,
                     ls_installment_type,ln_rate_divider,ln_counter,ln_elapsed_milliseconds,ln_yearly_cost_rate,ln_monthly_cost_rate,ln_total_days,ls_commission_type,ln_commission_rate,ln_commission_amount,ps_caller_payment_no,ps_caller_tx_no);      
                end loop;
                
        elsif l_keys(3) = 'errorMessage' then
           ln_errorMessage := l_resp_json.get_string('errorMessage');
           ld_endtime:=SYSDATE;
           raise L_WEBSERVICE_ERROR ;
        end if;  
         
    ld_endtime:=SYSDATE;
    
    log_at('pkg_payment_plan_ws.getPaymentPlan', 3, sqlcode, sqlerrm);
    PKG_PAYMENT_PLAN_WS.payment_ws_log('PAYMENT PLAN',LS_PP_WS_SERVICE_URL,ls_method_name,ld_starttime,ld_endtime,ls_service_return_code,NULL, ln_ws_callid,ps_caller_payment_no,ps_caller_tx_no,ls_res,ls_content);
    log_at('pkg_payment_plan_ws.getPaymentPlan', 4, sqlcode, sqlerrm);

    commit;
        
    EXCEPTION
        WHEN L_WEBSERVICE_ERROR THEN
            ls_returncode:='999';
            ls_service_return_code := '999';
            log_at('pkg_payment_plan_ws.getPaymentPlan',sqlcode, ln_errorMessage);
            PKG_PAYMENT_PLAN_WS.payment_ws_log('PAYMENT PLAN',LS_PP_WS_SERVICE_URL,ls_method_name,ld_starttime,ld_endtime,ls_service_return_code,NULL, ln_ws_callid,ps_caller_payment_no,ps_caller_tx_no,ls_res,ls_content);
            raise_application_error(-20100,pkg_hata.getucpointer || '6709' || pkg_hata.getdelimiter  || ls_returncode ||' '||ln_errorMessage || pkg_hata.getdelimiter ||  pkg_hata.getucpointer );
            rollback;
        WHEN OTHERS THEN
            ls_returncode:='999';
            log_at('pkg_payment_plan_ws.getPaymentPlan',sqlcode, SQLERRM,DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            PKG_PAYMENT_PLAN_WS.payment_ws_log('PAYMENT PLAN',LS_PP_WS_SERVICE_URL,ls_method_name,ld_starttime,ld_endtime,'999',sqlcode||' '||sqlerrm || ' ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, ln_ws_callid,ps_caller_payment_no,ps_caller_tx_no,ls_res,ls_content);
            rollback;
    END;  

    return ls_returncode;
END;
/******************************************************************************
NAME        : Procedure Payment_WS_Log
Prepared By : Nurmila Zhetimishova
Date        : 28.05.2021
Purpose     : payment plan ws logs
******************************************************************************/
procedure payment_ws_log (p_wscode varchar2,p_url varchar2,p_method varchar2,p_starttime date,p_endtime date,p_status varchar2, p_errortext varchar2,pn_payment_ws_callid number,pn_caller_payment_no number default 0,pn_caller_tx_no number default 0,ps_result_msg clob default null,ps_send_message clob default null) is
    pragma autonomous_transaction;
    ln_logid number;
begin
  ln_logid:=pkg_genel.genel_kod_al('PAYMENTWSLOGID');

  insert into cbs_payment_plan_wslog
  (log_id, ws_code, ws_url, ws_method, ws_starttime, ws_endtime, caller_user,status_cd,error_txt,payment_ws_callid ,caller_payment_no ,caller_tx_no, result,send_message)
  values
  (ln_logid,p_wscode, p_url,p_method , p_starttime, p_endtime,user,trim(p_status),p_errortext,pn_payment_ws_callid,pn_caller_payment_no,pn_caller_tx_no, ps_result_msg,ps_send_message );

  commit;
exception when others then 
    log_at('PAYMENT_WS_LOG',p_wscode||' '||p_method||' '||pn_payment_ws_callid, sqlcode,sqlerrm );
    rollback;
end;
END;
/

