create PACKAGE BODY     pkg_tx10000 IS
--STEP1
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
       null;
  End;
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
  
 FUNCTION sf_get_loan_name(pn_loan CBS_LOAN_TYPES_DANIZAT.id_no%TYPE) RETURN VARCHAR2
   IS
    ls_loan_name         VARCHAR2(20) := NULL;
 BEGIN
    SELECT type_name
    INTO   ls_loan_name
    FROM   CBS_LOAN_TYPES_DANIZAT
    WHERE  id_no = pn_loan;
    RETURN ls_loan_name;
 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'1568'||Pkg_Hata.getdelimiter||TO_CHAR(SQLCODE)||' '||SQLERRM||Pkg_Hata.getdelimiter||''||Pkg_Hata.getUCPOINTER);
 END;
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
      null;
  End;
  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;
 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
 null;
 End;
Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
Procedure Onay_Sonrasi(pn_islem_no number) is
begin
 insert into CBS_DANIZAT_TEST(APPLICATION_NO,  CUSTOMER_NO,   ID_NO, NAME,  SECOND_NAME,   SURNAME,NATIONALITY,   DATE_OF_BIRTH, OCCUPATION_CODE,
  LOAN_TYPE , APPLICATION_CURRENCY, APPLICATION_AMOUNT)
 select APPLICATION_NO,  CUSTOMER_NO,   ID_NO, NAME,  SECOND_NAME,   SURNAME,NATIONALITY,   DATE_OF_BIRTH, OCCUPATION_CODE,
  LOAN_TYPE , APPLICATION_CURRENCY, APPLICATION_AMOUNT
   FROM CBS_DANIZAT_TEST_TX
  WHERE TX_NO=pn_islem_no;
End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    null;
  End;
  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;
  Procedure Muhasebelesme(pn_islem_no number) is
  --STEP3
    varchar_list                      Pkg_Muhasebe.varchar_array;
    number_list                      Pkg_Muhasebe.number_array;
    date_list                           Pkg_Muhasebe.date_array;
    boolean_list                      Pkg_Muhasebe.boolean_array;
    ln_plan_no                       NUMBER;
    ln_fis_no                          NUMBER;
    ln_tran_code                    NUMBER := 10000;
    ln_account_no                  NUMBER;
    ln_amount                       NUMBER;
    ls_explanation                  varchar2(2000);

BEGIN
null;
End;
begin
--STEP2
null;
END;
/

