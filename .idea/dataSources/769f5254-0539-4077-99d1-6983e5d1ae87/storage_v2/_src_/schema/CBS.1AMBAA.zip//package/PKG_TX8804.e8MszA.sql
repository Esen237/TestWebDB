create PACKAGE     PKG_TX8804 IS

/******************************************************************************
   Name       : PKG_Tx8804
   Created By : Seval BALCI
   Date    	  : 01/04/2007
   Purpose	  : ATM Fee Charge Transactions
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number ,
  						  pn_islem_kod number default 8804,
  						  pn_fis_no in out number,
						  ps_tum_hesaplardan_al varchar2 default 'H',
						  ps_muhasebelestir varchar2 default 'H',
						  pn_masraf_tx_no	number  default null); --dosya islemleri icin eklendi eski isleme istinaden yarat?lacak ise kullanilir.
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  procedure atm_masraf_tahsil_isleme_at(pn_islem_no       number,
 		   						pn_islem_kod      number,
								ps_masraf_kodu	  varchar2,
                         		pn_hesap_no       number,
								p_tahsil_edilecek_masraf_tutar number,
								p_tahsil_edilen_masraf_tutar number,
								p_masraf_doviz_kodu varchar2,
								p_hesap_dovizli_tahs_edilecek number,
								p_hesap_dovizli_tahs_edilen number);
END;

/

