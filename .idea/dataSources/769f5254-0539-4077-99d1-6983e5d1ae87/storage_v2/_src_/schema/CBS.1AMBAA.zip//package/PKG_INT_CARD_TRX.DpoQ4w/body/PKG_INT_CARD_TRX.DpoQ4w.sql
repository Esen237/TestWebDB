create PACKAGE BODY     PKG_INT_CARD_TRX IS

FUNCTION GetDebitCardAutoconversion(ps_pseudopan varchar2,
                                    ps_autoconversion varchar2,
                                    ps_customer_number varchar2) RETURN varchar2
IS
ls_debit_card_accounts number;
ln_tran_no number;
ln_tran_code number;
ls_module_type_code varchar2(10);
ls_customer_type varchar2(1 byte);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ls_tran_branch_code varchar2(3);
ls_branch_code varchar(10);
ln_role number := 7777;
ln_currency_code varchar2(3) := pkg_genel.lc_al;
ls_account_number varchar(20 byte);
ls_cash_code varchar2(10 byte);
ps_channel_code number := 1;
ps_user_code varchar2(20) := 'CINT_CALLER';
ls_status varchar2(3 byte);
ls_returncode varchar2(3):='000';
noaccountfound exception;
nomoreaccounts exception;
BEGIN

    ln_tran_code := 1001;
    ls_module_type_code := 'CUSTOMER';
    ls_customer_type := pkg_musteri.sf_musteri_tipi_al(ps_customer_number);
    ls_product_type_code := pkg_musteri.sf_musteri_urun_tur_al (ls_customer_type);
    ls_product_class_code := pkg_musteri.sf_musteri_urun_sinif_al (ls_module_type_code,
                                               ls_product_type_code);
    ls_tran_branch_code := pkg_musteri.sf_bolum_kodu_al(ps_customer_number);    
    ls_branch_code := pkg_musteri.sf_bolum_kodu_al(ps_customer_number);        
    
    select count(*) into ls_debit_card_accounts from cbs_debit_card_account where card_id_no = ps_pseudopan;
    if ls_debit_card_accounts = 0 then
        raise noaccountfound;
    elsif ls_debit_card_accounts = 1 then
        raise nomoreaccounts;
    end if;
    
    pkg_baglam.yarat(ls_branch_code, ln_role);
    
    ls_status := pkg_musteri.sf_musteri_kodu_al(ps_customer_number);
    
    if ls_status = 'A' then
    pkg_musteri.sp_musteri_guncel_kaydi_olus (ps_customer_number, 
                                                ln_tran_no, 
                                                ls_status);                                                  
    else
        raise noaccountfound;
    end if;

    update cbs_musteri_guncellenen set fx_convert = nvl(ps_autoconversion, fx_convert)--Bakdoolot
            where tx_no = ln_tran_no;
       
      pkg_int_api.create_transaction (ln_tran_no, ln_tran_code,
                                   ls_module_type_code, ls_product_type_code, ls_product_class_code,
                                   0, ls_tran_branch_code, ls_branch_code, ln_role,
                                   ln_currency_code, ps_customer_number, ls_account_number,
                                   ls_cash_code, to_number(ps_channel_code), ps_user_code);

      pkg_int_api.process_transaction (ln_tran_no);

   commit;
         
  return ls_returncode;

EXCEPTION
    when noaccountfound then
        rollback;
        return '606';
    when nomoreaccounts then
        rollback;
        return '608';
    when others then
        rollback;
        raise;
END;


FUNCTION CreditCardCPaymentTx(ps_fromaccount varchar2,
                               ps_amount varchar2,
                               ps_creditcardno varchar2,
                               ps_pseudopan varchar2, 
                               ps_currencycode varchar2,
                               ps_user_name varchar2,
                               pc_ref out cursorreferencetype) RETURN varchar2
IS
ls_returncode varchar2 (2000) := '000';
ln_tutar number;
ln_from_account_number number;
transactionnumber number;
ln_islem_kod number := 7723;
lc_modul_tur_kod varchar2 (10) := 'CURR.OPS.';
lc_urun_tur_kod varchar2 (10) := 'INTERNET';
lc_urun_sinif_kod varchar2 (20);
lc_doviz_kod varchar2 (3) := ps_currencycode;  
lc_hesap_no number := to_number(ps_fromaccount);
ln_musteri_no number := pkg_hesap.hesaptanmusterinoal(to_number(lc_hesap_no));
lc_bolum_kodu varchar2 (3) := pkg_hesap.hesapsubeal(lc_hesap_no);
lc_kasa_kod number;
ln_kanal_numara number := 1;
ln_detailid number := 1;
ld_date date := pkg_muhasebe.banka_tarihi_bul;
ls_date  varchar2(10) := to_char(ld_date,'YYYYMMDD');
lc_rol number := 7777;
ln_fisno number;
ls_ref_no varchar2 (16);
ls_description varchar2(250);
ls_maskedcreditcardno varchar2(19);
ps_reconcilation_no varchar2(7);
invalidcurrency exception;
BEGIN

   pkg_baglam.yarat(lc_bolum_kodu, lc_rol); --temporary

   ps_reconcilation_no:=to_char(sq_cbs_ccdebtpayment_reconcno.nextval);
   lc_urun_sinif_kod :=pkg_tx7723.sf_urun_tur_sinif_al(ps_fromaccount);
   --SELECT REGEXP_REPLACE(ps_creditCardNo,'([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})([[:digit:]]{4})','\1 XXXX XXXX \4') INTO ls_maskedcreditCardNo  FROM dual;
    
   select substr(regexp_replace(ps_creditcardno, '\s'),1,4)  || ' XXXX XXXX ' ||   substr(regexp_replace(ps_creditcardno, '\s'),13,16)   into ls_maskedcreditcardno  from dual;
  
   transactionnumber := pkg_tx.islem_no_al;
   ln_tutar := to_number (replace(ps_amount,',',''), '99999999999.9999');
   ln_from_account_number := to_number (ps_fromaccount);
   if pkg_hesap.kullanilabilir_bakiye_al (ln_from_account_number) < ln_tutar
   then
      ls_returncode := '051';
      return ls_returncode;
   else
      ls_ref_no := 'I' || transactionnumber;
      ls_description:='Credit Card Payment, RIB';
      insert into cbs.cbs_int_card_finansal_islem (tx_no,
                                                   modul_tur_kod,
                                                   urun_tur_kod,
                                                   urun_sinif_kod,
                                                   terminal_branch,
                                                   original_currency_code,
                                                   original_amount,
                                                   explanation,
                                                   card_number,
                                                   from_account_number,
                                                   terminal_id,
                                                   referance,
                                                   kayit_sistem_tarihi,
                                                   kayit_user,
                                                   pseudopan) -- AdiletK CQ5541 PCI DSS pseudopan
        values   (transactionnumber,
                  lc_modul_tur_kod,
                  lc_urun_tur_kod,
                  lc_urun_sinif_kod,
                  null,
                  lc_doviz_kod,
                  ln_tutar,
                  ls_description,
                  ls_maskedcreditcardno,
                  lc_hesap_no,
                  null,
                  ls_ref_no,
                  sysdate,
                  ps_user_name,
                  ps_pseudopan); -- AdiletK CQ5541 PCI DSS pseudopan
      pkg_int_api.create_transaction (transactionnumber,
                                      ln_islem_kod,
                                      lc_modul_tur_kod,
                                      lc_urun_tur_kod,
                                      lc_urun_sinif_kod,
                                      ln_tutar,
                                      lc_bolum_kodu,
                                      lc_bolum_kodu,
                                      lc_rol,
                                      lc_doviz_kod,
                                      ln_musteri_no,
                                      lc_hesap_no,
                                      lc_kasa_kod,
                                      ln_kanal_numara);


      select fis_numara into ln_fisno from cbs_islem where numara=transactionnumber;

      pkg_int_api.process_transaction (transactionnumber);
      commit;
   end if;

     -- AdiletK testing card emails
     log_at('CreditCardCPaymentTx 1');
     ls_returncode:= pkg_int_card_trx.ccdebtpayment (ps_creditcardno, ps_amount, lc_doviz_kod,
                                                     lc_bolum_kodu, ls_date, ls_date,
                                                     ls_description, ln_fisno, ls_date, ps_reconcilation_no, ps_pseudopan ); -- AdiletK CQ5541 PCI DSS pseudopan
      
      if ls_returncode = '456' then
      raise invalidcurrency;
      end if;
                                                     
      log_at('CreditCardCPaymentTx 3',ls_returncode);
      if ls_returncode <> '000' then
          update cbs_int_card_finansal_islem
          set explanation = substr(explanation || ls_returncode, 1, 30)
          where tx_no=transactionnumber;

          pkg_baglam.yarat(lc_bolum_kodu, to_number(lc_rol));

          -- make cancel transaction
          pkg_tx.iptal(transactionnumber);

          -- make cancel transaction
          pkg_tx.iptal_onay(transactionnumber);

          log_at('CreditCardCPaymentTx',ls_returncode,ls_maskedcreditcardno || ' ' || ps_fromaccount || ' ' ||  ps_amount || ' ' || ls_date  );
          ls_returncode :='999';
      end if;

    open pc_ref for
      select  transactionnumber transactionnumber  from dual;
      
   return ls_returncode;
   
EXCEPTION
    when invalidcurrency then
        rollback;
        return '456';
    when others then
        ls_returncode :='999';
        log_at('CreditCardCPaymentTx', ls_returncode, sqlerrm);
        rollback;
        raise;
END;

FUNCTION Ccdebtpayment(ps_cardno varchar2,
                       ps_amount varchar2,
                       ps_currency varchar2,
                       ps_branchcode varchar2, 
                       ps_trandate varchar2,
                       ps_valdate varchar2 ,
                       ps_trandesc varchar2 ,
                       ps_ficheno varchar2,
                       ps_fichedate varchar2,
                       ps_reconcilation_no varchar2,
                       ps_pseudopan varchar2) RETURN varchar2 
IS 
ls_returncode varchar2(2000) := '000';

serviceurl varchar2(2000);
soapaction varchar2(2000);
namespace varchar2(2000);
methodname varchar2(2000);
req pkg_soap.request;
resp pkg_soap.response;
result clob;

l_parser  dbms_xmlparser.parser;
l_doc     dbms_xmldom.domdocument;
l_nl      dbms_xmldom.domnodelist;
l_n       dbms_xmldom.domnode;

ld_starttime date;
ld_endtime date;

rcode  varchar2(3) := '0';
rdesc  varchar2(40) := '0';

ws_service_url varchar2(200)  := 'http://10.0.0.16/virtualcard/kirgizdemirws.asmx';
ls_scode varchar2(10) := '10'; --  02: Branch 10: Internet 11: Call Center
ls_ucode  varchar2(10) := 'IBANKING';
ls_msgcode varchar2(1) := '0'; --Message Code    0: odeme, 1: iptal
ls_trncur varchar2(3);--417 for KGS 840 for USD
ls_trntype varchar2(2);-- YI: for KGS payment YD: for USD payment
ls_trnscode varchar2(1):='I';--N: Cash payment from branch H: Payment from account Paymen A: Payment from ATM I:  Payment from Internet C: Payment from call center

invalid_currency  exception;
/*
DMMDDBBBBMMMMMMM
D: Direction 2
MM: Month
DD: Day
BBBB: BranchCode
MMMMMMM:  Reconcilation number When MSGCODE is 0, this value must be unique, When MSGCODE is 1, this value must be same as original request transaction.
*/
ls_reference varchar(16);
ls_branch varchar(4);
ls_trandesc varchar(15) := lpad(ps_trandesc, 15, ' ');
ls_ficheno varchar(6) := lpad(ps_ficheno, 6, '0');
ls_trandate date :=to_date(ps_trandate,'YYYYMMDD');
ls_cardno varchar2(30);

BEGIN

    pkg_parametre.deger('WS_DEBT_PAY_CARD_URL', ws_service_url); --AlmasN debt pay card system server was parametrized

    --select SQ_CBS_CCDEBTPAYMENT_RECONCNO.nextval into ls_RECONCILATION_NO from dual;
   ls_branch :=lpad(ps_branchcode, 4, '0');
   ls_reference := '2' || to_char(ls_trandate,'MM') || to_char(ls_trandate,'DD') || ls_branch || lpad(ps_reconcilation_no, 7, '0');

    if ps_currency = 'KGS' then
        ls_trncur := '417';
        ls_trntype := 'YI';
    elsif  ps_currency = 'USD' then
        ls_trncur := '840';
        ls_trntype := 'YD';
    else
        --raise error
        raise invalid_currency;
    end if;

    if ps_pseudopan is null or ps_pseudopan = '' then -- AdiletK CQ5541 PCI DSS pseudopan
        ls_cardno := ps_cardno;
    end if;

    ld_starttime:=sysdate;

    serviceurl := ws_service_url;


    namespace := 'http://www.banksoft.com.tr';
    methodname := 'Payment';
    soapaction := namespace || '/KirgizDemirWS/' || methodname;
    namespace := 'xmlns="' || namespace || '"';

    req := pkg_soap.new_request(methodname, namespace);

    pkg_soap.add_parameter(
    req, 'PT', null,
        '<MSGCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_msgcode || '</MSGCODE>' ||
        '<CARDNUMBER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_cardno || '</CARDNUMBER>' ||
        '<PSEUDOPAN xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_pseudopan || '</PSEUDOPAN>' || -- AdiletK CQ5541 PCI DSS pseudopan
        '<BRANCH xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_branch || '</BRANCH>' ||
        '<TRNDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_trandate || '</TRNDATE>' ||
        '<VALDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_valdate || '</VALDATE>' ||
        '<TRNCUR xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trncur || '</TRNCUR>' ||
        '<TRNAMOUNT xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_amount || '</TRNAMOUNT>' ||
        '<TRNSCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trnscode || '</TRNSCODE>' ||
        '<TRNTYPE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trntype || '</TRNTYPE>' ||
        '<REFERANCE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_reference || '</REFERANCE>' ||
        '<UCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_ucode || '</UCODE>' ||
        '<SCODE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_scode || '</SCODE>' ||
        '<TRNDESC xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_trandesc || '</TRNDESC>' ||
        '<FICHENUMBER xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ls_ficheno || '</FICHENUMBER>' ||
        '<FICHEDATE xmlns="http://www.banksoft.com.tr/KirgizDemirWS/PaymentType">' || ps_fichedate || '</FICHEDATE>');

    resp := pkg_soap.invoke_utf8_v11(req, serviceurl, soapaction);

    result := resp.doc.getclobval();
    result:= replace(result,' xmlns="http://www.banksoft.com.tr"','');
    result:= replace(result,' xmlns="http://www.banksoft.com.tr/KirgizDemirWS/ResponseType"','');

    l_parser := dbms_xmlparser.newparser;
    dbms_xmlparser.parseclob(l_parser, result);
    l_doc := dbms_xmlparser.getdocument(l_parser);
    l_nl := dbms_xslprocessor.selectnodes(dbms_xmldom.makenode(l_doc),'PaymentResponse/PaymentResult');

    for cur_emp in 0 .. dbms_xmldom.getlength(l_nl) - 1 loop
        l_n := dbms_xmldom.item(l_nl, cur_emp);
        -- Use XPATH syntax to assign values to he elements of the collection.
        dbms_xslprocessor.valueof(l_n,'RCODE/text()',rcode);
        dbms_xslprocessor.valueof(l_n,'RDESC/text()',rdesc);
    end loop;
    ld_endtime:=sysdate;
   
   log_at('card payment', rcode, rdesc);

    if (rcode <> '000') then
       log_at('CCDebtPayment',to_char(ld_endtime)||' '||to_char(ld_starttime)||' '|| ls_reference , rcode||' '||rdesc);
       ls_returncode :=rcode||' '||rdesc;
    else
       ls_returncode :=rcode;
    end if;
    
    return ls_returncode;
    
EXCEPTION
    when invalid_currency then
           return '456';
    when others then
          ls_returncode :='999';
          log_at('CCDebtPayment',to_char(ld_endtime)||' '||to_char(ld_starttime) ||' '|| ls_reference, sqlerrm, rdesc);
          return ls_returncode;
END;
END;
/

