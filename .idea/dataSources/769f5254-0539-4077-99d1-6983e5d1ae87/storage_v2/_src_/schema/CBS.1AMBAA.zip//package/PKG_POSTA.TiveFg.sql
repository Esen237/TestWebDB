create PACKAGE pkg_posta IS

 FUNCTION  email_sender(sender IN VARCHAR2,recipient IN VARCHAR2,subject IN VARCHAR2,message IN VARCHAR2) return BOOLEAN;
 Function  EpostaAdresBul(ps_alici_kullanici_kodu varchar2) return varchar2;
 PROCEDURE EpostaGonder(ps_alici varchar2,ps_konu varchar2 default 'CBS',ps_mesaj varchar2,ps_gonderen varchar2 default 'info@cbank.com.tr',ps_oncelik_kodu NUMBER default 50,ps_eposta_kodu varchar2 default 'INFO');
 Function  EpostaAdresKontrol(ps_eposta_adres varchar2) return BOOLEAN;
/*
  PROCEDURE baslik(isim IN VARCHAR2, baslik IN VARCHAR2);
  PROCEDURE gonder(ps_alici_kullanici_kodu varchar2,ps_mesaj varchar2) ;
  */
END;


/

