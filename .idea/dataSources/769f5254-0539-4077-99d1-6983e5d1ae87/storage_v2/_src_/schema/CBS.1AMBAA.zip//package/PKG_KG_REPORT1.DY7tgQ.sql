create Package PKG_KG_REPORT1 is
  Function GetGL(ID number) return varchar2;
  Function GetSenderBenef(pn_islemno number) return varchar2;
  Function GetBP_Customer(pn_islemno number) return varchar2;  
End PKG_KG_REPORT1;


/

