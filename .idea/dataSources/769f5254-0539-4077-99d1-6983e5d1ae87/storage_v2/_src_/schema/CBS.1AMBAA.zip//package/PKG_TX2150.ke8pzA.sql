create PACKAGE     PKG_TX2150 is
  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54

  Procedure Yaratma_Oncesi(pn_islem_no number);         -- Islem giris kontrolden once cagrilir
  Procedure Kontrol_Sonrasi(pn_islem_no number);         -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);            -- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number);

  Procedure Onay_Sonrasi(pn_islem_no number);                -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);        -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);            -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);          -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);            -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);    -- Islem dogrulandiktan sonra cagrilir

  Function GetSalaryInfoFile(ps_filename varchar2,pn_txno number, pn_customer_no number,pn_firm_id number default null) return varchar2 ;-- sevalb 10062011 SDLC10352_salary_payment devreye alininca null kaldirilacak
  FUNCTION payroll(pn_islem_no number) RETURN VARCHAR2 ;
  FUNCTION org_title(pn_firm_id number) RETURN VARCHAR2 ; --SDLC10352_salary_payment sevalb 10062011 kapatildi sonra acilacak
  FUNCTION ID_AL return number;     --SDLC10352_salary_payment sevalb 10062011 kapatildi sonra acilacak
  Procedure load_dbf_file_auca(ps_filename varchar2,pn_txno number, pn_customer_no number,pn_firm_id number default null) ;--sevalb 13062011 sdlc17857_salary_for_auca  
end;

/

