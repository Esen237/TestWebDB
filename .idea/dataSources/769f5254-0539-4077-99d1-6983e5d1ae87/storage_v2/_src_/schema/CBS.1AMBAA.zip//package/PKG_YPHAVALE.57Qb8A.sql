create package PKG_YPHAVALE is

  -- Author  : TIMUCIN_A
  -- Created : 20.06.2003 10:49:54
  -- Purpose : YP HAvale i?lemlerinde kullan?lacakt?r.


  Procedure YPHavaleGelenBilgiAl(pn_ref_no cbs_yphavale_gelen.REF_NO%TYPE,
  pn_doviz_kodu OUT CBS_YPHAVALE_GELEN.DOVIZ_KODU%TYPE,
  pn_tutar OUT CBS_YPHAVALE_GELEN.TUTAR%TYPE,
  pn_valor_tarihi OUT CBS_YPHAVALE_GELEN.VALOR_TARIHI%TYPE,
  pn_alici_musteri_no OUT CBS_YPHAVALE_GELEN.ALICI_MUSTERI_NO%TYPE,
  pn_alici_hesap_no OUT CBS_YPHAVALE_GELEN.ALICI_HESAP_NO%TYPE,
  pn_alici_adi OUT CBS_YPHAVALE_GELEN.ALICI_ADI%TYPE,
  pn_alici_adres OUT CBS_YPHAVALE_GELEN.ALICI_ADRES%TYPE,
  pn_mbanka_musteri_no OUT CBS_YPHAVALE_GELEN.MBANKA_MUSTERI_NO%TYPE,
  pn_mbanka_hesap_no OUT CBS_YPHAVALE_GELEN.MBANKA_HESAP_NO%TYPE,
  pn_modul_tur_kod OUT CBS_YPHAVALE_GELEN.MODUL_TUR_KOD%TYPE,
  pn_urun_tur_kod OUT CBS_YPHAVALE_GELEN.URUN_TUR_KOD%TYPE,
  pn_urun_sinif_kod OUT CBS_YPHAVALE_GELEN.URUN_SINIF_KOD%TYPE);
  -----------------------------------------------------------------------------------
  Function  giden_islemnoal(ps_referans in varchar2) return number;
  ------------------------------------------------------------------------------------
  Function  HavaleBakiyesiHesapla(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return NUMBER;
  ------------------------------------------------------------------------------------
  Function  HavaleOdemeToplami(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return NUMBER;
  ------------------------------------------------------------------------------------
  Function  BICUlkeAdiBul(ps_bic_kodu in CBS_BIC_KODLARI.BIC_KODU%TYPE) return VARCHAR2;
  ------------------------------------------------------------------------------------
  Procedure YPHavaleOdemeBilgiAktar(ps_ref_no IN VARCHAR2, pn_odeme_no IN NUMBER, pn_tx_no IN NUMBER);
  ------------------------------------------------------------------------------------
  Procedure YPHavaleGelenBilgiAktar(ps_ref_no IN VARCHAR2, pn_tx_no IN NUMBER);
  ------------------------------------------------------------------------------------
  Function GidenTutarBuyukLimit(pv_muhabir_banka IN cbs_yphavale_limit.muhabir_banka%type, pv_doviz_kodu IN cbs_yphavale_limit.DOVIZ_KODU%type, pn_tutar IN cbs_yphavale_limit.MAXIMUM_TUTAR%type) return varchar;
  ------------------------------------------------------------------------------------
  Function  GelenHavaleValorAl(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return DATE;
  ------------------------------------------------------------------------------------
  Function  OdemeIlkValorAl(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return DATE;
  ------------------------------------------------------------------------------------
  Function IhracatYPHavaleOdeme(p_REF_NO varchar2,
  								p_ODEME_SEKLI 	  number,
								p_ODEME_TUTARI 	  number,
								p_VALOR_TARIHI	  date,
								p_ALICI_MUSTERI_NO  number,
								p_ALICI_HESAP_NO	  number,
								p_ALICI_DK_NO		  varchar2,
								p_KUR				  number,
								p_KOMISYON_ORANI	  number,
								p_KOMISYON_TUTARI	  number,
								p_NET_ODENEN_TUTAR  number,
                                p_PREFIX_ISTATISTIK_KODU	  number,
								p_ISTATISTIK_KODU	  varchar2,
								p_ACIKLAMA		  varchar2,
								p_DURUM_KODU		  varchar2,
								p_ODEME_TARIHI	  date,
								p_BOLUM_KODU		  varchar2,
								p_TX_NO			  number,
								p_REZERVASYON_NO 	  number) return NUMBER;
------------------------------------------------------------------------------------
  Procedure IhracatYPHavaleOdemeIptal(ps_ref_no IN VARCHAR2, pn_odeme_no IN NUMBER);
------------------------------------------------------------------------------------
  Function  IleriValorluOdemeToplami(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return number;
------------------------------------------------------------------------------------
  Function  acilis_istatistik_kodu(ps_refno in CBS_YPHAVALE_GELEN.REF_NO%TYPE) return varchar2;
------------------------------------------------------------------------------------

end PKG_YPHAVALE;


/

