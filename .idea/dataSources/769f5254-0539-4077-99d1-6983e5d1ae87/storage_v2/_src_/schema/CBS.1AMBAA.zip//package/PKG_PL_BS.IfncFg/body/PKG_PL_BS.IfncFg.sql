create PACKAGE BODY PKG_PL_BS
IS

  FUNCTION GET_FORMATED_NUMBER(AMOUNT NUMBER, FORMAT NUMBER) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(1000);
  BEGIN
    IF AMOUNT = 0 THEN
	  RESULT := '(0)';
	ELSIF AMOUNT < 0 THEN
      RESULT := '('||trim(replace(to_char(abs(AMOUNT), '999,999,999,999,999'), ',', ' '))||')';
	ELSE
	  RESULT := trim(replace(to_char(abs(AMOUNT), '999,999,999,999,999'), ',', ' '));
	END IF;
	IF FORMAT in (2,3) THEN RESULT := '';
	END IF;
    RETURN RESULT || ' ';
  END;

  FUNCTION GET_FORMATED_NUMBER(AMOUNT NUMBER, FORMAT NUMBER, STR_NO NUMBER) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(1000);
  BEGIN
    IF (STR_NO = 64 AND AMOUNT < 0) OR (STR_NO = 65 AND AMOUNT > 0) THEN
	  RESULT := '(0)';
	ELSE
      IF AMOUNT = 0 THEN
	    RESULT := '(0)';
	  ELSIF AMOUNT < 0 THEN
        RESULT := '('||trim(replace(to_char(abs(AMOUNT), '999,999,999,999,999'), ',', ' '))||')';
	  ELSE
	    RESULT := trim(replace(to_char(abs(AMOUNT), '999,999,999,999,999'), ',', ' '));
	  END IF;
	  IF FORMAT in (2,3) THEN RESULT := '';
	  END IF;
	END IF;
    RETURN RESULT || ' ';
  END;


  FUNCTION GET_FORMATED_NUMBER_SM(AMOUNT NUMBER, STR_NO NUMBER) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(1000);
  BEGIN
    IF AMOUNT = 0 AND STR_NO <> 22 THEN
	  RESULT := '';
	ELSE
	  IF STR_NO IN (2, 19, 20) THEN
	    RESULT := trim(replace(to_char(AMOUNT, '999,999,999,999,999'), ',', ' '));
	  ELSE
	    RESULT := trim(replace(to_char(AMOUNT, '999,999,999,999,999.99'), ',', ' '));
	  END IF;
      IF STR_NO IN (1, 21) THEN
	    RESULT := RESULT || '%';
	  ELSIF STR_NO = 22 THEN
	    IF AMOUNT = 0 THEN
		  RESULT := 'NO';
		ELSIF AMOUNT = 1 THEN
		  RESULT := 'YES';
		ELSE
		  RESULT := '';
		END IF;
	  END IF;
	END IF;

	IF TRIM(RESULT) = '%' THEN
	  RESULT := '';
	END IF;

	IF SUBSTR(RESULT, 1, 1) = '.' THEN
	  RESULT := '0' || RESULT;
	END IF;

    RETURN RESULT || ' ';
  END;

  FUNCTION GET_FORMATED_NUMBER_RES(AMOUNT NUMBER, STR_NO NUMBER) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(1000);
  BEGIN
	IF STR_NO IN (4, 8) THEN
	    RESULT := trim(replace(to_char(AMOUNT/1000, '999,999,999,999,999'), ',', ' '));
	ELSIF STR_NO IN (9, 12) THEN
	  RESULT := trim(replace(to_char(AMOUNT, '999,999,999,999,999.99'), ',', ' ')) || '%';
	ELSIF STR_NO IN (13, 14) THEN
	  RESULT := trim(replace(to_char(AMOUNT/1000, '999,999,999,999,999.999'), ',', ' '));
	ELSE
	  RESULT := trim(replace(to_char(AMOUNT/1000, '999,999,999,999,999.99'), ',', ' '));
	END IF;

	IF TRIM(RESULT) IN ('%', '.00%', '.00', '0', '.000') THEN
	  RESULT := '';
	END IF;

	IF SUBSTR(RESULT, 1, 1) = '.' THEN
	  RESULT := '0' || RESULT;
	END IF;

    RETURN RESULT || ' ';
  END;


  FUNCTION GET_BEGIN_DATE_PER_WEEK(DATE_NO DATE, WEEK_NO NUMBER) RETURN DATE
  IS
    RESULT DATE;
  BEGIN
        select BEGIN_DATE
    	  INTO RESULT
          from (select ROWNUM ID, BEGIN_DATE, END_DATE
                  from cbs_RPT_PERIODS
                 where BEGIN_DATE <= (SELECT A.BEGIN_DATE
                    	                FROM CBS_RPT_PERIODS A
                    	               WHERE DATE_NO BETWEEN A.BEGIN_DATE AND A.END_DATE)
                 ORDER BY BEGIN_DATE DESC)
         where ID = WEEK_NO;
    RETURN RESULT;
  END;

  FUNCTION GET_END_DATE_PER_WEEK(DATE_NO DATE, WEEK_NO NUMBER) RETURN DATE
  IS
    RESULT DATE;
  BEGIN
        select END_DATE
    	  INTO RESULT
          from (select ROWNUM ID, BEGIN_DATE, END_DATE
                  from cbs_RPT_PERIODS
                 where BEGIN_DATE <= (SELECT A.BEGIN_DATE
                    	                FROM CBS_RPT_PERIODS A
                    	               WHERE DATE_NO BETWEEN A.BEGIN_DATE AND A.END_DATE)
                 ORDER BY BEGIN_DATE DESC)
         where ID = WEEK_NO;
    RETURN RESULT;
  END;


  FUNCTION GET_BEGIN_DATE_PER_MONTH(DATE_NO DATE, MONTH_NO NUMBER) RETURN DATE
  IS
    RESULT DATE;
  BEGIN
        select case
        	     when MONTH_NO = 0 then pkg_dates.get_first_day_in_month(DATE_NO)
        		 when MONTH_NO = 1 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)
        		 when MONTH_NO = 2 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)
        		 when MONTH_NO = 3 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)
        		 when MONTH_NO = 4 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)
        		 when MONTH_NO = 5 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)
        		 when MONTH_NO = 6 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1)
        		 when MONTH_NO = 7 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1)-1)
        		 when MONTH_NO = 8 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1)-1)-1)
        	   end
    	  INTO RESULT
          from dual;
        if to_char(DATE_NO, 'YYYY') = to_CHAR(RESULT, 'YYYY') then
		  RETURN RESULT;
		ELSE
		  RETURN NULL;
		END IF;
  END;

  FUNCTION GET_END_DATE_PER_MONTH(DATE_NO DATE, MONTH_NO NUMBER) RETURN DATE
  IS
    RESULT DATE;
  BEGIN
        select case
        	     when MONTH_NO = 0 then last_day(DATE_NO)
        		 when MONTH_NO = 1 then pkg_dates.get_first_day_in_month(DATE_NO)-1
        		 when MONTH_NO = 2 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1
        		 when MONTH_NO = 3 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1
        		 when MONTH_NO = 4 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1
        		 when MONTH_NO = 5 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1
        		 when MONTH_NO = 6 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1
        		 when MONTH_NO = 7 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1)-1
        		 when MONTH_NO = 8 then pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(pkg_dates.get_first_day_in_month(DATE_NO)-1)-1)-1)-1)-1)-1)-1)-1
        	   end
    	  INTO RESULT
          from dual;
        if to_char(DATE_NO, 'YYYY') = to_CHAR(RESULT, 'YYYY') then
		  RETURN RESULT;
		ELSE
		  RETURN NULL;
		END IF;
  END;

  FUNCTION GET_STR_NAME(P_TYPE_NO NUMBER, P_STR_NO NUMBER) RETURN VARCHAR2
  IS
    RESULT VARCHAR2(100);
  BEGIN
    select TRIM(SUBSTR(CBS_RPT_PL_BS.name, 1, 36))
	  into RESULT
      from CBS_RPT_PL_BS
     where CBS_RPT_PL_BS.type_no = P_TYPE_NO and
	       CBS_RPT_PL_BS.STR_no  = P_STR_NO;
    RETURN RESULT;
  EXCEPTION
    WHEN OTHERS THEN
	  RETURN '';
  END;

BEGIN
   NULL;
END PKG_PL_BS;
/

