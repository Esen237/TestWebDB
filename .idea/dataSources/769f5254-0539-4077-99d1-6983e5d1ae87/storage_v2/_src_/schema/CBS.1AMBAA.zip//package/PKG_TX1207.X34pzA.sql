create PACKAGE PKG_TX1207 IS

/******************************************************************************
   Name       : PKG_TX1207
   Created By : Seval Balci
   Date    	  : 01.06.05
   Purpose	  : Foreign Exchange
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		  -- Islem dogrulandiktan sonra cagrilir
  Procedure	Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			  -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		  -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			  -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			  -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );

  Function Sf_Urun_Tur_Uygunmu(pn_hesap_no cbs_bloke_islem.hesap_no%type ) return varchar2;

  Function debit_istatistikkod_zorunlumu(pn_borc_hesap_no number,
		 							ps_urun_tur varchar2,
		 							ps_ALIS_DOVIZ_KODU varchar2,
									ps_borc_dk_no varchar2
		 							) return varchar2;
 Function credit_istatistikkod_zorunlumu(pn_alacak_hesap_no number,
		 							     ps_urun_tur varchar2,
		 							     ps_satis_DOVIZ_KODU varchar2,
									     ps_alacak_dk_no varchar2
		 							   ) return varchar2;
Function debit_istatistikkod_al(pn_borc_hesap_no number,
		 						ps_urun_tur varchar2,
		 						ps_alis_doviz_kodu varchar2,
								ps_borc_dk_no varchar2,
								pn_alacak_hesap_no number,
								ps_istatistik_kod varchar2) return varchar2;
Function credit_istatistikkod_al(pn_alacak_hesap_no number,
		 						ps_urun_tur varchar2,
		 						ps_satis_doviz_kodu varchar2,
								ps_alacak_dk_no varchar2,
								pn_borc_hesap_no number,
								ps_istatistik_kod varchar2) return varchar2;

Function Sf_Baslik_Aciklama(pn_islem_no number) return varchar2;
Function Sf_Baslik_Aciklama2(pn_islem_no number) return varchar2;
Function Sf_Doviz_Aciklama_1(pn_islem_no number) return varchar2;
Function Sf_Doviz_Aciklama_2(pn_islem_no number) return varchar2;
END;

/

