create PACKAGE BODY     PKG_TX1108 IS
    pn_1108_cek_islem_sube        number;
    pn_1108_cek_tutar_1_tl        number;
    pn_1108_cek_yaprak_adet       number;
    pn_1108_banka_aciklama        number;
    pn_1108_musteri_aciklama      number;
    pn_1108_cek_referans          number;
    pn_1108_kur_lc                number;
    pn_1108_fis_aciklama          number;
    pn_1108_karne_continuous      number;
    pn_1108_karne_10              number;
    pn_1108_karne_25              number;
    pn_1108_doviz_tl              number;
    pn_1108_doviz_yp              number;

    pn_1108_KUR                      number;
    pn_1108_DOVIZ_KODU              number;
    pn_1108_LC_CEK_TUTAR_1_TL      number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;
 Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
             Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '699' || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;


  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_adet                         number := 0;
  ln_talep_edilen_karne_adedi   number := 0;
  ln_girisi_yapilan_karne_adedi number := 0;
  ln_musteri_no             cbs_cek_karne_islem.musteri_no%type;
  ln_karne_ref_tx_no             cbs_cek_karne_islem.tx_no%type;
  ln_ref_tx_no                     cbs_cek_karne_islem.tx_no%type;
  ls_karne_tipi_kodu            cbs_cek_karne_islem.karne_tipi_kodu%type;
  ls_durum_kodu                    cbs_cek_karne_islem.durum_kodu%type;
  ld_teslim_tarihi                cbs_cek_karne_islem.teslim_tarihi%type;
  teslim_edilmis                exception;
  karne_onceden_iptal_edilmis    exception;
  teslim_iptal_edilemez            exception;
  ln_baslangic_cek_no            number;
  ln_bitis_Cek_no                number;
  ls_bolum                         varchar2(20);
  Begin

/* karne ref. alinir */
     select ref_tx_no ,musteri_no ,baslangic_cek_no,bitis_Cek_no  ,nvl(nvl(hesap_sube_kodu,pkg_tx.Amir_BolumKodu_Al(pn_islem_no)),pkg_baglam.bolum_kodu    )
     into ln_karne_ref_tx_no   ,ln_musteri_no ,ln_baslangic_cek_no,ln_bitis_Cek_no ,ls_bolum
     from cbs_cek_karne_islem
     where tx_no =  pn_islem_no ;

     select durum_kodu,teslim_tarihi
     into   ls_durum_kodu,ld_teslim_tarihi
     from   cbs_cek_karne_islem
     where  tx_no =  ln_karne_ref_tx_no ;

/* karne bilgileri durum kodu kontrol edilir */
 if  ls_durum_kodu = 'A'  and   ld_teslim_tarihi is null then

/* islem bilgisi guncellenir */
    update cbs_cek_karne_islem
    set karne_giris_tarihi = pkg_muhasebe.banka_tarihi_bul ,
        durum_kodu = 'A',
        hesap_sube_kodu =ls_bolum
    where tx_no = pn_islem_no ;


     /* cek karne durum kodu KI iptal koduna guncellenmeli */
    update cbs_cek_karne_islem
    set  durum_kodu = 'KI'
    where tx_no = ln_karne_ref_tx_no ;

/* ceklerin silinmesi gerekmektedir */
     delete from cbs_cek
     where ref_tx_no = ln_karne_ref_tx_no ;

 /* musteri cek karnesi guncellenir */
       update cbs_musteri
       set cek_karnesi_f = 'H'
       where musteri_no = ln_musteri_no ;
 else
     if ld_teslim_tarihi is not null then
       raise teslim_edilmis;
    elsif ls_durum_kodu = 'KI' then
        raise karne_onceden_iptal_edilmis;
    else
        raise teslim_iptal_edilemez;
    end if;

 end if;

  Exception
     when teslim_edilmis then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '405' || pkg_hata.getDelimiter || to_char(ld_teslim_tarihi,'DD/MM/YYYY')|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     when karne_onceden_iptal_edilmis then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '404' || pkg_hata.getDelimiter || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
     when teslim_iptal_edilemez then
          Raise_application_error(-20100,pkg_hata.getUCPOINTER || '402' || pkg_hata.getDelimiter  || ls_durum_kodu|| pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
        When Others Then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '140' || pkg_hata.getDelimiter || to_char(sqlcode)||' '||SQLERRM || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     /* Red edildi */
    update cbs_cek_karne_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no ;

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ln_fis_no                   cbs_fis.numara%type ;
    ls_islem_kod               cbs_islem.islem_kod%type :='1108';
    ls_aciklama                varchar2(2000);
    ls_genel_aciklama          varchar2(2000);
    ln_musteri_no               cbs_musteri.musteri_no%TYPE;
    ln_hesap_no                      cbs_cek_karne_islem.hesap_no%TYPE;
    ls_hesap_sube_kodu              cbs_cek_karne_islem.hesap_sube_kodu%TYPE;
    ln_tutar                      cbs_cek_karne_islem.masraf_TUTARi%TYPE;
    ls_karne_tipi_kodu           cbs_cek_karne_islem.karne_tipi_kodu%TYPE;
    ls_doviz_kodu               cbs_hesap_basvuru.DOVIZ_KODU%TYPE;
    ln_cek_yaprak_adedi           cbs_cek_karne_islem.cek_yaprak_adedi%TYPE;
    ln_baslangic_cek_no           cbs_cek_karne_islem.baslangic_cek_no%type;
    ln_bitis_cek_no               cbs_cek_karne_islem.bitis_cek_no%type;
    ls_modul_tur_kod           cbs_cek_karne_islem.modul_tur_kod%type;
    ls_urun_tur_kod              cbs_cek_karne_islem.urun_tur_kod%type;


    cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
               select musteri_no,
                   hesap_sube_kodu,
                   hesap_no,
                   karne_tipi_kodu,
                   cek_yaprak_adedi,
                   baslangic_cek_no,
                   bitis_cek_no  ,
                   pkg_Genel.lc_al doviz_kodu, --sevalb 23022011
                   modul_tur_kod,
                   urun_tur_kod,
                    pkg_tx.Amir_BolumKodu_Al(tx_no)
            from cbs_cek_karne_islem
            where tx_no=pn_islemno;

  Begin
/* islem bilgisi detaylari alinir */
         open islem_cursor(pn_islem_no);
           fetch islem_cursor into ln_musteri_no,ls_hesap_sube_kodu,ln_hesap_no,
                                         ls_karne_tipi_kodu,ln_cek_yaprak_adedi ,
                                   ln_baslangic_Cek_no,ln_bitis_cek_no,ls_doviz_kodu,
                                       ls_modul_tur_kod, ls_urun_tur_kod,  varchar_list(pn_1108_cek_islem_sube) ;

           if islem_cursor%notfound then
              close islem_cursor;
           end if;
          close islem_cursor;

/*** Liste Deger Atama K?sm? **/

/**** varchar list ****/
   ls_genel_aciklama :=  Pkg_Genel.Islem_Adi_Al(1108);
   ls_genel_aciklama := ls_genel_aciklama  || ' Account No :' || to_char(ln_hesap_no) || ' Start No:' || to_char(ln_baslangic_cek_no) || ' End No:' || to_char(ln_bitis_cek_no);

   pkg_parametre.deger('1108_FIS_ACIKLAMA',ls_aciklama);
   varchar_list(pn_1108_fis_aciklama) :=  ls_aciklama ;

   varchar_list(pn_1108_banka_aciklama) :=  ls_genel_aciklama;
   varchar_list(pn_1108_musteri_aciklama):=  ls_genel_aciklama;
   varchar_list(pn_1108_cek_referans) :=ls_genel_aciklama ;

 /**** boolean list ****/
    boolean_list(pn_1108_karne_10):=false;
    boolean_list(pn_1108_karne_25):=false;
    boolean_list(pn_1108_karne_continuous):=false;
    boolean_list(pn_1108_doviz_tl):=false;
    boolean_list(pn_1108_doviz_yp):=false;

    number_list(pn_1108_KUR)                 := 0;
    number_list(pn_1108_LC_CEK_TUTAR_1_TL)   := 0;
    varchar_list(pn_1108_DOVIZ_KODU)         := ls_doviz_kodu;

    /* karne tipi atamalari */
   if  PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = 'CONTINUOUS' then
      boolean_list(pn_1108_karne_continuous):=true;
   elsif PKG_PARAMETRE.VARCHAR_AL ( ls_MODUL_TUR_KOD, ls_URUN_TUR_KOD,  ls_karne_tipi_kodu ,'KARNE_TIPI_KODU') = '10' then
      boolean_list(pn_1108_karne_10):=true;
   else
        boolean_list(pn_1108_karne_25):=true;
   end if;

/* d?viz tipi atamalari */
   if ls_doviz_kodu = pkg_genel.lc_al  then
      boolean_list(pn_1108_doviz_tl):=true;
   else
        boolean_list(pn_1108_doviz_yp):=true;
   end if;

/**** number list ****/
     pkg_parametre.deger('1108_CEK_TUTAR_1_TL',number_list(pn_1108_cek_tutar_1_tl));
     number_list(pn_1108_cek_yaprak_adet) := ln_cek_yaprak_adedi;
     number_list(pn_1108_kur_lc) := pkg_kur.doviz_doviz_karsilik(pkg_genel.LC_AL,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
/**** date list ****/

     number_list(pn_1108_KUR)                  := pkg_kur.doviz_doviz_karsilik(ls_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');
     number_list(pn_1108_LC_CEK_TUTAR_1_TL)   := number_list(pn_1108_cek_tutar_1_tl) * number_list(pn_1108_KUR) ;

/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            ls_aciklama);

    pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '185' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

  End;

Begin
/* parametre index numaralar? bulunur.*/
    pn_1108_cek_islem_sube       :=pkg_muhasebe.parametre_index_bul('1108_CEK_ISLEM_SUBE');
    pn_1108_cek_tutar_1_tl       :=pkg_muhasebe.parametre_index_bul('1108_CEK_TUTAR_1_TL');
    pn_1108_cek_yaprak_adet   :=pkg_muhasebe.parametre_index_bul('1108_CEK_YAPRAK_ADET');
    pn_1108_banka_aciklama       :=pkg_muhasebe.parametre_index_bul('1108_BANKA_ACIKLAMA');
    pn_1108_musteri_aciklama  :=pkg_muhasebe.parametre_index_bul('1108_MUSTERI_ACIKLAMA');
    pn_1108_cek_referans       :=pkg_muhasebe.parametre_index_bul('1108_CEK_REFERANS');
    pn_1108_kur_lc                :=pkg_muhasebe.parametre_index_bul('1108_KUR_LC');
    pn_1108_cek_referans       :=pkg_muhasebe.parametre_index_bul('1108_CEK_REFERANS');
    pn_1108_fis_aciklama       :=pkg_muhasebe.parametre_index_bul('1108_FIS_ACIKLAMA');
    pn_1108_karne_continuous  :=pkg_muhasebe.parametre_index_bul('1108_KARNE_CONTINUOUS');
    pn_1108_karne_10           :=pkg_muhasebe.parametre_index_bul('1108_KARNE_10');
    pn_1108_karne_25           :=pkg_muhasebe.parametre_index_bul('1108_KARNE_25');
    pn_1108_doviz_tl           :=pkg_muhasebe.parametre_index_bul('1108_DOVIZ_TL');
    pn_1108_doviz_yp           :=pkg_muhasebe.parametre_index_bul('1108_DOVIZ_YP');

    pn_1108_KUR                  :=pkg_muhasebe.parametre_index_bul('1108_KUR');
    pn_1108_DOVIZ_KODU          :=pkg_muhasebe.parametre_index_bul('1108_DOVIZ_KODU');
    pn_1108_LC_CEK_TUTAR_1_TL :=pkg_muhasebe.parametre_index_bul('1108_LC_CEK_TUTAR_1_TL');
End PKG_TX1108;
/

