create PACKAGE BODY pkg_qiwi_ws AS
 GS_BPKTRAN_SERVICE_URL VARCHAR2(200 CHAR):='http://10.0.0.138/services.demirbank.kg/qiwiService.asmx';--DKIB  ---  
 --GS_BPKTRAN_SERVICE_URL VARCHAR2(200 CHAR):='http://10.1.9.102/services.demirbank.kg/qiwiService.asmx'; --TR DEV
 QIWI_USERNAME VARCHAR2(200 CHAR):='demirbank'; 
 QIWI_PASSWORD VARCHAR2(200 CHAR):='CnGB9wXdLaN{wl0'; 

function checkAgent(pn_agentId number,pn_tran_code number default 0,pn_paymentId number default 0) return varchar2
is
    ls_agentId   CONSTANT VARCHAR2(10) := to_char(pn_agentId); 
    AgentName VARCHAR2(2000) := '';
    IsAgentExist VARCHAR2(2000) := '';
    IsEnabled VARCHAR2(2000) := '';
    ls_return varchar2(400 char);
    ls_hata varchar2(2000);
begin
    sp_checkAgent(pn_agentId ,pn_tran_code,pn_paymentId ,AgentName , IsAgentExist , IsEnabled );--SEVALB TEST AMACLI kapattim UNUTMAAA
    ls_return := AgentName||';'||IsAgentExist||';'||IsEnabled;
--  ls_return := 'TEST'||';'||'1'||';'||'0'; --SEVALB TEST AMACLI SILECEM UNUTMAAA

  return ls_return;

EXCEPTION    
    WHEN OTHERS THEN
        log_at('pkg_qiwi_ws.checkAgent',pn_paymentId,pn_agentid,substr(to_char(sqlcode)||' '||sqlerrm,1,2000));
        ls_hata := replace(substr(TO_CHAR(SQLCODE)|| ' ' || SQLERRM,1,1900),'&') ;       
        Raise_application_error(-20100,'5710' || sqlerrm);     --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi
        return null;
END;   

procedure addPayment(pn_tran_code number ,pn_paymentId number, pn_agentId number, pn_amount number, 
    ps_docNo varchar2,ps_Status out varchar2)
is
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req Pkg_Soap.request;
    resp Pkg_Soap.response;
    result  clob ;--VARCHAR2(4000 CHAR); --sevalb 

    ls_agentId   CONSTANT VARCHAR2(10) := '4'; 
    ls_amount    CONSTANT VARCHAR2(10) := '0.01'; 
    ls_docNumber CONSTANT VARCHAR2(20) := '2010-02-28T12:34:05'; 
    ls_paymentId CONSTANT VARCHAR2(10) := '223';
  
--    Status VARCHAR2(2000) := '';
    StatusDescription VARCHAR2(2000) := '';
    PaymentId VARCHAR2(2000) := '';
    ls_hata varchar2(2000);

begin
    serviceUrl := GS_BPKTRAN_SERVICE_URL;

    namespace := 'http://services.demirbank.kg/';
    methodName := 'QiwiAddPayment';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);
        
    --add parameters to request
    Pkg_Soap.add_parameter(req, 'agentId', 'xsd:long', pn_agentId);
    Pkg_Soap.add_parameter(req, 'amount', 'xsd:decimal', pn_amount);
    Pkg_Soap.add_parameter(req, 'docNumber', 'xsd:string', ps_docNo);
    Pkg_Soap.add_parameter(req, 'paymentId', 'xsd:long', pn_paymentId);
    Pkg_Soap.add_parameter(req, 'username', 'xsd:string', QIWI_USERNAME);    
    Pkg_Soap.add_parameter(req, 'password', 'xsd:string', QIWI_PASSWORD);    

    --call web service, and get response
    resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
    result := resp.doc.getstringval();
    --dbms_output.put_line(substr(result,1,2000));

    --extract data from xml
    SELECT XMLTYPE(result).EXTRACT('//QiwiAddPaymentResponse/QiwiAddPaymentResult/Status/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0,
           XMLTYPE(result).EXTRACT('//QiwiAddPaymentResponse/QiwiAddPaymentResult/StatusDescription/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_1,
           XMLTYPE(result).EXTRACT('//QiwiAddPaymentResponse/QiwiAddPaymentResult/PaymentId/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_2
    INTO ps_Status, StatusDescription, PaymentId
    FROM dual;

    --dbms_output.put_line(ps_Status||'+'||StatusDescription||'+'||PaymentId);        
    pkg_qiwi_ws.sp_ins_usip_qiwi_log( 'ADDPAYMENT',
                                 pn_tran_code, 
                                 pn_paymentId, 
                                 pn_agentid, 
                                 pn_amount, 
                                 ps_docno,
                                 ps_status,
                                 statusdescription,
                                 null,--agentname,
                                 null,--isagentexist, 
                                 null,--isenabled,
                                 null,--ls_return,
                                 req.body,
                                 result
                                 );        
 Exception    
    when others then
        log_at('pkg_qiwi_ws.addpayment',pn_paymentId,pn_agentId,substr(to_char(sqlcode)||' '||sqlerrm,1,2000));
        ls_hata := replace(substr(TO_CHAR(SQLCODE)|| ' ' || SQLERRM,1,1900),'&') ;
        Raise_application_error(-20100,'5711' || sqlerrm);     --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi 
End;

procedure cancelPayment(pn_tran_code number ,pn_paymentId number, pd_cancelDate date,ps_Status out varchar2)
is
    --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req Pkg_Soap.request;
    resp Pkg_Soap.response;
    result VARCHAR2(4000 CHAR);

    ls_agentId   CONSTANT VARCHAR2(10) := '4'; 
    ls_amount    CONSTANT VARCHAR2(10) := '0.01'; 
    ls_docNumber CONSTANT VARCHAR2(20) := '2010-02-28T12:34:05'; 
    ls_paymentId CONSTANT VARCHAR2(10) := '223';
    
    --Status VARCHAR2(2000) := '';
    StatusDescription VARCHAR2(2000) := '';
    PaymentId VARCHAR2(2000) := '';
    ls_hata varchar2(2000);
begin
    serviceUrl := GS_BPKTRAN_SERVICE_URL;

    namespace := 'http://services.demirbank.kg/';
    methodName := 'QiwiCancelPayment';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';
    
    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);
        
    --add parameters to request
    Pkg_Soap.add_parameter(req, 'CancelDate', 'xsd:DateTime', pd_cancelDate);        
    Pkg_Soap.add_parameter(req, 'paymentId', 'xsd:long', pn_paymentId);
    Pkg_Soap.add_parameter(req, 'username', 'xsd:string', QIWI_USERNAME);    
    Pkg_Soap.add_parameter(req, 'password', 'xsd:string', QIWI_PASSWORD);    

    --call web service, and get response
    resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);
    result := resp.doc.getstringval();
    --dbms_output.put_line(substr(result,1,2000));

    --extract data from xml
    SELECT XMLTYPE(result).EXTRACT('//QiwiCancelPaymentResponse/QiwiCancelPaymentResult/Status/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0,               
           XMLTYPE(result).EXTRACT('//QiwiCancelPaymentResponse/QiwiCancelPaymentResult/StatusDescription/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_1, --sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services 
           XMLTYPE(result).EXTRACT('//QiwiCancelPaymentResponse/QiwiCancelPaymentResult/PaymentId/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_2
    INTO ps_Status, StatusDescription,PaymentId
    FROM dual;

    --dbms_output.put_line(ps_Status||'+'||ps_StatusDescription||'+'||ps_PaymentId);        

    pkg_qiwi_ws.sp_ins_usip_qiwi_log( 'CANCELPAYMENT',
                                 pn_tran_code, 
                                 pn_paymentId, 
                                 null,--pn_agentid, 
                                 null,--pn_amount, 
                                 null,--ps_docno,
                                 ps_status,
                                 statusdescription,
                                 null,--agentname,
                                 null,--isagentexist, 
                                 null,--isenabled,
                                 null,--ls_return,
                                 req.body,
                                 result
                                 );        
EXCEPTION    
    WHEN OTHERS THEN
        log_at('pkg_qiwi_ws.CancelPayment',pn_paymentid,substr(to_char(sqlcode)||' '||sqlerrm,1,2000));
         ls_hata := replace(substr(TO_CHAR(SQLCODE)|| ' ' || SQLERRM,1,1900),'&') ;
         Raise_application_error(-20100,'5712' || sqlerrm);     --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi
end;
------------------------------------------------------------------------------------
--B-O-M sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services
procedure sp_ins_usip_qiwi_log(  ps_tran_type varchar2, 
                                 pn_tran_code number ,
                                 pn_paymentId number, 
                                 pn_agentId number, 
                                 pn_amount number, 
                                 ps_docNo varchar2 ,
                                 ps_Status  varchar2,
                                 ps_status_description varchar2,
                                 ps_agent_name varchar2,
                                 ps_IsAgentExist varchar2, 
                                 ps_IsEnabled   varchar2,
                                 ps_return_code varchar2,
                                 ps_REQUEST_XML   clob ,
                                 ps_RESPONSE_XML clob) 
is pragma autonomous_transaction;
Begin

 --dbms_output.put_line(AgentName||'+'||IsAgentExist||'+'||IsEnabled);
    insert into cbs_usip_qiwi_ws_call_log
    (   log_no    ,
        tran_type    ,        
        agent_id    ,
        tran_code,
        payment_id    ,
        amount    ,
        document_no    ,
        agent_name    ,
        status    ,
        status_description ,
        IsAgentExist,
        IsEnabled,
        return_code,
        request_xml    ,
        response_xml    ,
        bank_date )
    values
        (
        pkg_genel.genel_kod_al('USIPQIWI_LOG'),
        ps_tran_type,
        pn_agentid    ,
        pn_tran_code,
        pn_paymentid    ,
        pn_amount    ,
        ps_docNo    ,
        ps_agent_name    ,
        ps_status    ,
        ps_status_description,
        ps_IsAgentExist,
        ps_IsEnabled,
        ps_return_code,
        ps_request_xml    ,
        ps_response_xml    ,
        pkg_muhasebe.banka_tarihi_bul 
        );

    commit;

  Exception when others then        
        log_at('pkg_qiwi_ws.sp_ins_usip_qiwi_log-error',pn_paymentid,substr(sqlcode||' '||sqlerrm,1,2000));
        rollback;
End;
------------------------------------------------------------------------------------
Procedure sp_checkAgent(pn_agentId number,pn_tran_code number default 0,pn_paymentId number default 0,ps_AgentName out varchar2, ps_IsAgentExist out varchar2, ps_IsEnabled out varchar2)
is
  --ws variables
    serviceUrl VARCHAR2(300);
    soapAction VARCHAR2(100);
    namespace VARCHAR2(100);
    methodName VARCHAR2(100);
    req Pkg_Soap.request;
    resp Pkg_Soap.response;
    result clob;--  VARCHAR2(4000 CHAR); --sevalb 18042012

    ls_agentId   CONSTANT VARCHAR2(10) := to_char(pn_agentId); 
    ls_return varchar2(400 char);
    ls_hata varchar2(2000);
begin
    
    serviceUrl := GS_BPKTRAN_SERVICE_URL;

    namespace := 'http://services.demirbank.kg/';
    methodName := 'QiwiCheckAgent ';
    soapAction := namespace || methodName;
    namespace := 'xmlns="' || namespace || '"';

    --create new request
    req := Pkg_Soap.new_request(methodName, namespace);

    --add parameters to request
    Pkg_Soap.add_parameter(req, 'agentId', 'xsd:long', ls_agentId);    
    Pkg_Soap.add_parameter(req, 'username', 'xsd:string', QIWI_USERNAME);    
    Pkg_Soap.add_parameter(req, 'password', 'xsd:string', QIWI_PASSWORD);    
    
    --call web service, and get response
    resp := Pkg_Soap.invoke_utf8_v11(req, serviceUrl, soapAction);

    result := resp.doc.getstringval();


    --dbms_output.put_line(substr(result,1,2000));

    --extract data from xml
    SELECT XMLTYPE(result).EXTRACT('//QiwiCheckAgentResponse/QiwiCheckAgentResult/AgentName/text()', 'xmlns="http://services.demirbank.kg/"').getstringval() key_0,
           decode(XMLTYPE(result).EXTRACT('//QiwiCheckAgentResponse/QiwiCheckAgentResult/IsAgentExist/text()', 'xmlns="http://services.demirbank.kg/"').getstringval(),'false','0','true','1') key_1,
           decode(XMLTYPE(result).EXTRACT('//QiwiCheckAgentResponse/QiwiCheckAgentResult/IsEnabled/text()', 'xmlns="http://services.demirbank.kg/"').getstringval(),'false','0','true','1') key_2
    INTO ps_AgentName, ps_IsAgentExist, ps_IsEnabled
    FROM dual;

   
    ls_return := ps_AgentName||';'||ps_IsAgentExist||';'||ps_IsEnabled;
                
    pkg_qiwi_ws.sp_ins_usip_qiwi_log( 'CHECKAGENT',
                                 pn_tran_code, 
                                 pn_paymentId, 
                                 pn_agentId, 
                                 null,--pn_amount, 
                                 null,--ps_docno,
                                 null,--ps_status,
                                 null,--ps_status_description,
                                 ps_AgentName,
                                 ps_IsAgentExist, 
                                 ps_IsEnabled,
                                 ls_return,
                                 REQ.BODY,
                                 result
                                 );

EXCEPTION    
    WHEN OTHERS THEN
      log_at('pkg_qiwi_ws.sp_checkAgent',pn_paymentId,pn_agentid,substr(to_char(sqlcode)||' '||sqlerrm,1,2000));
      ls_hata := replace(substr(TO_CHAR(SQLCODE)|| ' ' || SQLERRM,1,1900),'&') ;
      Raise_application_error(-20100,'5709' || sqlerrm);     --sevalb pkg_hata kullanamadim cunku geri donen mesaji on yuze raise edemedi
             
End;


--E-O-M sevalb 19042012 sdlc23975_Modification for screens connected to USIP web-services
------------------------------------------------------------------------------------ 
END pkg_qiwi_ws;
/

