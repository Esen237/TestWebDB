create PACKAGE     PKG_TX4081 IS

  /******************************************************************************
   Name       : PKG_TX4081
   Created By : Bilal GUL
   Date	   	  : 05/12/2003
   Purpose	  : Alinan Garanti Cikisi
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number, ps_ref varchar2);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Procedure AlinanGarantiBilgisiAl(ps_referans cbs_tm_alinan_garanti.REFERANS%type,
  								   ps_ISLEM_TIPI out cbs_tm_alinan_garanti.ISLEM_TIPI%type,
								   PS_GON_BANKA_MUSTERI_NO out number,
								   ps_duzenleme_tarihi out date,
								   ps_GON_BANKA_REFERANSI out cbs_tm_alinan_garanti.GON_BANKA_REFERANSI%type,
								   ps_DOVIZ_KODU out cbs_tm_alinan_garanti.DOVIZ_KODU%type,
								   ps_TUTAR out number,
								   ps_BAKIYE out number,
								   ps_VADELI out cbs_tm_alinan_garanti.vadeli%type,
								   ps_VADE_TARIHI out date,
								   ps_MUHATAP_MUSTERI_NO out number,
								   ps_MUHATAP_UNVANI out cbs_tm_alinan_garanti.MUHATAP_UNVANI%type,
								   ps_MUHATAP_ADRESI out cbs_tm_alinan_garanti.MUHATAP_ADRESI%type,
								   ps_LEHDAR_MUSTERI_NO out number,
								   ps_KONU out cbs_tm_alinan_garanti.konu%type,
                                   ps_PRINCIPAL_TITLE out CBS_TM_ALINAN_GARANTI.PRINCIPAL_TITLE%type --cq1405 VictorK
								   );

  FUNCTION TxGonderReferansAl(pn_tx_no number) return varchar2 ;

END;

/

