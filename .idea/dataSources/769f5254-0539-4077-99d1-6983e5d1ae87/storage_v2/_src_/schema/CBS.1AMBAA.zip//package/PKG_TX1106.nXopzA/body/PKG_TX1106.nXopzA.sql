create PACKAGE BODY PKG_TX1106 IS
  Procedure Kontrol_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin
    Null;
  End;


  Procedure Iptal_Reddetme_Sonrasi (pn_islem_no number) is
  Begin
    Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;
  Procedure Onay_Sonrasi(pn_islem_no number) is
  ln_adet number := 0;
  ln_cek_no cbs_cek.cek_no%type;
  ls_odeme_yasak_neden_kodu cbs_cek.odeme_yasak_neden_kodu%type ;

    cursor cur_cek_islem is
     select cek_no ,odeme_yasak_neden_kodu
 	 from cbs_cek_islem
	 where tx_no = pn_islem_no ;

  Begin

/* islem bilgisi guncellenir */
    update cbs_cek_islem
	set duzeltme_tarihi = pkg_muhasebe.banka_tarihi_bul ,
	    durum_kodu = 'A'
	where tx_no = pn_islem_no ;

/* ilgili cek numarasinin karsiliksiz durum kodu  guncellenir. */
 if cur_cek_islem%isopen then
	   close cur_cek_islem;
 end if;

 open cur_cek_islem ;
  loop
  	  fetch cur_cek_islem into ln_cek_no , ls_odeme_yasak_neden_kodu  ;
    	exit when cur_cek_islem%notfound;

	    update cbs_cek
		set durum_kodu = 'D' ,duzeltme_tarihi =pkg_muhasebe.banka_tarihi_bul
		where  cek_no = ln_cek_no ;

  end loop;
  	 close 	 cur_cek_islem ;
  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '145' || pkg_hata.getDelimiter || SQLERRM || pkg_hata.getUCPOINTER);
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
 	/* Red edildi */
    update cbs_cek_karne_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no ;
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Muhasebelesme(pn_islem_no number) is
  Begin
   Null;--      Raise_application_error(-20100,'85;'||SQLERRM);
  End;
END;
/

