create Package Body PKG_KG_REPORT1 is
Function GetGL(ID number) return varchar2
  is
    v varchar2(1000);
  begin
  v:= '';
	for recin in(select *
			  	   from cbs_kg_kod_gl
				  where code = ID) loop
      v := v || recin.gl_no || ', ' ;
	  end loop;
	  v:=substr(v, 1, length(v)-2);
    return v;
  end;
Function GetSenderBenef(pn_islemno number) return varchar2
  is
    v VARCHAR2(10):= NULL;
  begin
	for recin in(
        SELECT GONDEREN_ULKE_KODU sender FROM CBS_YPHAVALE_GELEN_BASVURU WHERE tx_no=pn_islemno
        UNION ALL
        SELECT ADRES_ULKE_KOD sender
          from cbs_yphavale_gelen_iade_basvur ,cbs_yphavale_gelen
        			WHERE cbs_yphavale_gelen_iade_basvur.TX_NO  = pn_islemno 
                AND cbs_yphavale_gelen_iade_basvur.REF_NO = cbs_yphavale_gelen.REF_NO 
        UNION ALL
        SELECT GONDEREN_ULKE_KODU sender
        	from cbs_yphavale_gelen_odeme_basvu,cbs_yphavale_gelen
        			where cbs_yphavale_gelen_odeme_basvu.TX_NO=pn_islemno	
                AND cbs_yphavale_gelen_odeme_basvu.REF_NO=cbs_yphavale_gelen.REF_NO
        UNION ALL       
        SELECT GONDEREN_ULKE_KODU sender
          FROM CBS_YPHAVALE_GELEN_ODEME_G_BAS, CBS_YPHAVALE_GELEN_G_BASVURU 
        			where CBS_YPHAVALE_GELEN_ODEME_G_BAS.TX_NO=pn_islemno	
                AND CBS_YPHAVALE_GELEN_ODEME_G_BAS.REF_NO=CBS_YPHAVALE_GELEN_G_BASVURU.REF_NO
        UNION ALL
        SELECT ulke_kodu benefc FROM CBS_YPHAVALE_GIDEN_ACILIS WHERE tx_no=pn_islemno
          ) loop
      v := recin.sender;
	  end loop;
    return v;
  end;
  
 Function GetBP_Customer(pn_islemno number) return varchar2
  IS
    ccode VARCHAR2(10):= NULL;
    v VARCHAR2(10):= 'KG';
  begin
	for recin in(
      SELECT nvl(y.alici_musteri_no,17523) cust FROM CBS_YPHAVALE_GELEN_BASVURU y WHERE y.tx_no=pn_islemno
      UNION ALL
      
      SELECT nvl(cbs_yphavale_gelen.alici_musteri_no,17523) cust 
        from cbs_yphavale_gelen_iade_basvur ,cbs_yphavale_gelen 
      			WHERE cbs_yphavale_gelen_iade_basvur.TX_NO  = pn_islemno 
              AND cbs_yphavale_gelen_iade_basvur.REF_NO = cbs_yphavale_gelen.REF_NO 
      UNION ALL
      SELECT nvl(cbs_yphavale_gelen.alici_musteri_no,17523) cust  
      	from cbs_yphavale_gelen_odeme_basvu ,cbs_yphavale_gelen 
      			where cbs_yphavale_gelen_odeme_basvu.TX_NO=pn_islemno	
              AND cbs_yphavale_gelen_odeme_basvu.REF_NO=cbs_yphavale_gelen.REF_NO
      UNION ALL
      SELECT nvl(c.musteri_no,17523) Cust FROM CBS_YPHAVALE_GIDEN_ACILIS c WHERE tx_no=pn_islemno
          ) loop
      SELECT m.uyruk_kod 
      INTO ccode 
      FROM cbs_musteri m WHERE m.musteri_no=recin.cust;
      v := ccode;
	  end loop;
    return v;
  end;
  
End PKG_KG_REPORT1;
/

