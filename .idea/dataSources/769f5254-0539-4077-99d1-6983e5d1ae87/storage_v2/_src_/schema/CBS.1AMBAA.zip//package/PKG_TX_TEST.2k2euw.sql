create PACKAGE pkg_tx_test IS

/******************************************************************************
   Name       : PKG_TX
   Created By :
   Date    	  : 02.07.03
   Purpose	  : Test
******************************************************************************/

     Procedure Kontrol_Sonrasi(pn_islem_no number);
     Procedure Dogrulama_Sonrasi(pn_islem_no number);
     Procedure Onay_Sonrasi(pn_islem_no number);
	 Procedure Iptal_Onay_Sonrasi(pn_islem_no number);
	 Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);
	 Procedure Reddetme_Sonrasi(pn_islem_no number);
	 Procedure Iptal_Sonrasi(pn_islem_no number);
	 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);
     Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);
     Procedure Muhasebelesme(pn_islem_no number);
     Procedure Tamam_Sonrasi(pn_islem_no number);
END;


/

