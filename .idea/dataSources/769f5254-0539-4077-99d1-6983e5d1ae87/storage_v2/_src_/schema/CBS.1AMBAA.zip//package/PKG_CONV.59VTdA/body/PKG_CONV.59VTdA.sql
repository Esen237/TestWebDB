create PACKAGE BODY     Pkg_Conv IS

FUNCTION ESKI_MUSTERIDEN_YENIAL(PS_ESKI_MUSTERI_NO VARCHAR2) RETURN NUMBER IS


   ln_musteri_no NUMBER;
   ln_count		 NUMBER;
   cursor c_0 is
     select master_musteri_no
       from cbs_must_cift_kayit_detail
      where musteri_no=ps_eski_musteri_no;

	  ln_cnt number;
BEGIN
  open c_0;
  fetch c_0 into ln_musteri_no;
  if c_0%notfound then
     select count(*)
       into ln_cnt
       from cbs_musteri
      where eski_musteri_no = ps_eski_musteri_no;

	  if ln_cnt = 1
	  then
     select musteri_no
       into ln_musteri_no
       from cbs_musteri
      where eski_musteri_no = ps_eski_musteri_no;
	  end if;
  end if;
  close c_0;

 return ln_musteri_no ;

 exception
 when no_data_found then
      close c_0;
	  raise_application_error(-20100,pkg_hata.getucpointer || '1180' || pkg_hata.getdelimiter   || sqlerrm ||pkg_hata.getucpointer);

end;


PROCEDURE CONV_CSMASF_BANK IS
-- ger tablo drop edilip yaratliyorsa cs_cusno uzerine index yaratilmasi unutulmamali sevalb 140405
  CURSOR conv_cursor IS
  SELECT *
  FROM CONV_CSMASF_BANK
  WHERE CS_CUSNO NOT IN (SELECT ESKI_MUSTERI_NO FROM CBS_MUSTERI );

  row_conv conv_cursor%ROWTYPE;
  ln_musteri_no NUMBER ;
  BEGIN

        DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_N a
  	    WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_BANKA_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

        DELETE FROM  CBS_MUSTERI_ADRES_CONV_N a
    	WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_BANKA_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

	    DELETE FROM  CBS_MUSTERI_BANKA_CONV  a
     	WHERE AKTARILDIMI= 'H' ;

  COMMIT;

  	   OPEN conv_cursor;
	   FETCH conv_cursor INTO row_conv;
	   WHILE NOT conv_cursor%NOTFOUND
	   LOOP
	   	   BEGIN


		   ln_musteri_no:= Pkg_Genel.genel_kod_al('MUSTERI_NO');

		   		INSERT INTO CBS_MUSTERI_BANKA_CONV
				(MUSTERI_NO,
				 DURUM_KODU,
				 MUSTERI_TIPI_KOD,
				 TICARI_UNVAN,
				 HESAP_UCRETI_F,
				 CEK_KARNESI_F,
				 UYRUK_KOD,
				 EXTRE_ADRES_KOD,
				 YARATAN_KULLANICI_KODU,
				 YARATILDIGI_TARIH,
				 ESKI_MUSTERI_NO,
				 BOLUM_KODU,
				 vergi_no)

				VALUES
			   (ln_musteri_no,
				'A',
				'4',
				row_conv.CS_NAME_1||row_conv.CS_NAME_2,
				'H',
				'H',
				FindCountry(row_conv.CS_COUCODE),
				'3',
				'CONV',
				SYSDATE,
				row_conv.CS_CUSNO,
				SUBSTR(row_conv.CS_CUSNO,1,3),
				row_conv.vergi_no);

		   		INSERT INTO CBS_MUSTERI_ADRES_CONV_N
				(MUSTERI_NO,
				ADRES_KOD,
				ADRES,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH,
				EXTRE_ADRES_KOD_F
				)

				VALUES
			   (ln_musteri_no,
				'3',
				row_conv.CS_ADDRES_1 || row_conv.CS_ADDRES_2 || row_conv.CS_ADDRES_3 || row_conv.CS_ZIPCODE || row_conv.CS_PHONE,
				'CONV',
				SYSDATE,
				'E'
				);

	   	   END ;
	   	   FETCH conv_cursor INTO row_conv;
	   END LOOP;
 	   COMMIT;
	   CLOSE conv_cursor;

  END;
-------------------------------
PROCEDURE CONV_CSMASF_CORPORATE IS

  CURSOR conv_cursor IS
  select
  		    cs_cusno, cs_name_1, cs_name_2, cs_birthday,
			NULL cs_sex,
  			cs_coucode,
			cs_addres_1,
			cs_addres_2,
			cs_addres_3,
			cs_addres_4,
			cs_zipcode,
			pkg_conv.telefonduzenle(CS_PHONE) cs_PHONE,
  			vergi_no,
			cs_rnr,
			NULL dk_grup_kod,
			NULL   yerlesim_kod,
			null PAZARLAMA_SORUMLUSU_SICIL_NO_1,
			decode( to_number(CS_SECTCODE),0,24,to_number(CS_SECTCODE))	Finans_kod,
			CS_ID_TYPE ,
			CS_ID_NO ,
			substr(trim(CS_ID_ISSUEDBY),1,30)	VERILDIGI_YER,
			CS_BIC_ACC
  from  conv_csmasf_CORPORATE
  where cs_cusno not in (select nvl(b.eski_musteri_no,-1)  from cbs_musteri b)
  		AND CS_SEX IN ( 'C')
  order by cs_cusno;

  row_conv conv_cursor%ROWTYPE;
  ln_musteri_no NUMBER ;
  ls_id_type 	varchar2(1);
  ls_id_no	 	varchar2(20);
  ls_passport_no		varchar2(20);
  ls_ehliyet_no			varchar2(20);
  ls_addres_1 			varchar2(100);
  ls_addres_2 			varchar2(100);
  ls_addres_3 			varchar2(100);
  ls_addres_4 			varchar2(100);
  ls_uyruk_kod			VARCHAR2(10);
  ls_sosyalfonno 		VARCHAR2(50);
  ls_opcocode			VARCHAR2(50);
  ls_vergino			VARCHAR2(50);

  BEGIN

  DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_K a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_KURUMSAL_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_ADRES_CONV_K a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_KURUMSAL_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_KURUMSAL_CONV
  WHERE AKTARILDIMI= 'H' ;

  COMMIT;

  	   OPEN conv_cursor;
	   FETCH conv_cursor INTO row_conv;
	   WHILE NOT conv_cursor%NOTFOUND
	   LOOP
	   	      ln_musteri_no:= Pkg_Genel.genel_kod_al('MUSTERI_NO');
			  ls_id_type	  := null;
			  ls_passport_no  := null;
			  ls_ehliyet_no   := null;
			  ls_id_no		  := null;
			  ls_opcocode	  := null;
			  ls_sosyalfonno  := null;
			  ls_vergino	  := null;

			  ls_uyruk_kod :=FindCountry(row_conv.CS_COUCODE);

			 if row_conv.CS_ID_TYPE is not null and row_conv.CS_ID_NO is not null then
			   if upper(row_conv.CS_ID_TYPE) like 'PAS%' then
			   	  ls_id_type :=  '3';
				  ls_passport_no := trim(row_conv.CS_ID_NO);
				elsif  upper(row_conv.CS_ID_TYPE) like 'DRIV%' then
			   	  ls_id_type :=  '2';
				  ls_ehliyet_no := trim(row_conv.CS_ID_NO);
				else
			   	  ls_id_type :=  '1';
				  ls_id_no := trim(row_conv.CS_ID_NO);
				 end if;
			  end if;

 -- adres duzeltmeleri
		    	if instr(row_conv.CS_ADDRES_1,'9999') > 0 then
				    ls_addres_1 := ' ';
				else
					ls_addres_1 := 	row_conv.CS_ADDRES_1;
				end if;
				if instr(row_conv.CS_ADDRES_2,'9999') > 0 then
					ls_addres_2 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_2),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_2 := ' ';
						ls_opcocode := substr(trim(row_conv.CS_ADDRES_2),1,12) ;
					 else
						ls_addres_2 := 	row_conv.CS_ADDRES_2;
					 end if;

				end if;
				if instr(row_conv.CS_ADDRES_3,'9999') > 0 then
					ls_addres_3 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_3),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_3 := ' ';
						ls_vergino := substr(trim(row_conv.CS_ADDRES_3),1,20) ;
					 else
						ls_addres_3 := 	row_conv.CS_ADDRES_3;
					 end if;
				end if;
				if instr(row_conv.CS_ADDRES_4,'9999') > 0 then
					ls_addres_4 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_4),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_4 := ' ';
						ls_sosyalfonno := substr(trim(row_conv.CS_ADDRES_4),1,50) ;
					 else
						ls_sosyalfonno:=	row_conv.CS_ADDRES_4;
					 end if;
				end if;


			  Begin
				INSERT INTO CBS_MUSTERI_KURUMSAL_CONV
				(MUSTERI_NO,
				 DURUM_KODU,
				 MUSTERI_TIPI_KOD,
				 TICARI_UNVAN,
				 HESAP_UCRETI_F,
				 CEK_KARNESI_F,
				 UYRUK_KOD,
				 EXTRE_ADRES_KOD,
				 YARATAN_KULLANICI_KODU,
				 YARATILDIGI_TARIH,
				 ESKI_MUSTERI_NO,
				 BOLUM_KODU,
				 KIMLIK_KOD	,
				 EHLIYET_BELGE_NO,
				 NUFUS_CUZDANI_SERI_NO,
				 PASAPORT_NO,
				 DK_GRUP_KOD,
				 YERLESIM_KOD,
				 PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 FINANS_KOD	,
				 VERILDIGI_YER	,
				 EXTERNAL_ACCT_NO,
				 EKSTRE_UCRETI_ALINSIN ,
		 		 modul_tur_kod,
				 urun_tur_kod,
				 urun_sinif_kod,
				 VERGI_NO ,
				 OKPO_CODE,
				 SOSYAL_FON_NO,
				 VERGI_ZORUNLUMU
				 )

				VALUES
			   (ln_musteri_no,
				'A',
				'3',
				row_conv.CS_NAME_1||row_conv.CS_NAME_2,
				'E',
				'H',
				ls_uyruk_kod,
				'3',
				'CONV',
				SYSDATE,
				row_conv.CS_CUSNO,
				SUBSTR(row_conv.CS_CUSNO,1,3),
				ls_id_type,
				ls_ehliyet_no,
				ls_id_no,
				ls_passport_no,
				 row_conv.DK_GRUP_KOD,
				 row_conv.YERLESIM_KOD,
				 row_conv.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 row_conv.FINANS_KOD,
				 trim(row_conv.VERILDIGI_YER),
				 row_conv.CS_BIC_ACC,
				 'E',
 				 'CUSTOMER',
				  UPPER ( pkg_musteri.sf_musteri_urun_tur_al(3)) ,
		  		  'GENERAL',
				  ls_vergino,
				  ls_opcocode,
				  ls_sosyalfonno,
				  'E'
				);


	   		INSERT INTO CBS_MUSTERI_ADRES_CONV_K
				(MUSTERI_NO,
				ADRES_KOD,
				ADRES,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH,
				EXTRE_ADRES_KOD_F,
				TEL_NO,
				ulke_kod
				)
				VALUES
			   (ln_musteri_no,
				'3',
				Trim(ls_ADDRES_1 || ls_ADDRES_2 || ls_ADDRES_3 || ls_addres_4||' '|| row_conv.CS_ZIPCODE) ,
				'CONV',
				SYSDATE,
				'E',
				row_conv.CS_PHONE,
				ls_uyruk_kod
				);


		   Exception when others then
	  			log_at('CONV_CSMASF_CORPORATE',row_conv.CS_COUCODE,SQLCODE,SQLERRM);

	   	   END ;

	   	   FETCH conv_cursor INTO row_conv;
	   END LOOP;
 	   COMMIT;

	   CLOSE conv_cursor;

	  Exception when others then
	  log_at('CONV_CSMASF_CORPORATE',row_conv.CS_COUCODE,SQLCODE,SQLERRM);
  END;

--------------------------------------------------------------------------------------
  FUNCTION  textduzenle(ps_string VARCHAR2) RETURN  VARCHAR2
  IS
    ls_string VARCHAR2(2000) := UPPER(ps_string);
  BEGIN
       IF ls_string  IS NOT NULL THEN
		  ls_string := TRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(trim(ps_string),'.'),'/'),'-'),':'),','),';'));
	    END IF;
     RETURN NVL(ls_string,' ');
   END;
--------------------------------------------------------------------------------------
--sevalb 140507
  FUNCTION  telefonduzenle(ps_string VARCHAR2) RETURN  NUMBER
  IS
    ls_string VARCHAR2(2000) := UPPER(ps_string);
	ln_index  number;
	ln_Ret	  number;
  BEGIN
      IF ls_string  IS NOT NULL THEN
	   	  if length(ls_string) <= 6 then
		  	 ls_string :=  textduzenle(ls_string);
		  else
		  	ln_index := pkg_conv.sayi_olana_kadarki_index_al(ls_string);
			if ln_index > 6 then
			   ls_string := substr(ls_string,1,ln_index -1 );
			 else
			   ls_string :=  textduzenle(ls_string);
			end if;
		  end if;
		  if  sf_is_number(ls_string) = 0 then --sayi degilse
			  ls_string := textduzenle(ls_string);
			  ln_index:=pkg_conv.sayi_olana_kadarki_index_al(ls_string);
			  if nvl(ln_index ,0) > 1 then
			     ls_string := substr(ls_string,1,ln_index -1 );
			  end if;
		  end if;

		ln_ret :=to_number(ls_string) ;
	 END IF;

     RETURN ln_ret;

	 Exception
	   when others then
		  	 return null;
   END;
--------------------------------------------------------------------------------------
Function sayi_olana_kadarki_index_al(ps_str varchar2) return number is
 ln_len number;
 ln_ret number := 1;
 begin
  ln_len := length(ps_str);
  for i in 1..ln_len loop
    if substr(ps_str,i,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
	   null;
	else
	   ln_ret :=i;
	   exit;
	end if;
   end loop;


   return ln_ret;
 end;
--------------------------------------------------------------------------------------
-- genel kullanim icin birakildi.
Function sf_is_number(ps_str varchar2) return number is
 ln_len number;
 ln_ret number := 1;
 begin
  ln_len := length(ps_str);
  for i in 1..ln_len loop
    if substr(ps_str,i,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
	   null;
	else
	   ln_ret := 0;
	   exit;
	end if;
   end loop;
   return ln_ret;
 end;

-------------------------------
--- yapilacaklar
/*
1. adres 2,3,4 9999 ile baslayan adres bilgileri temizlenecek yerine bosluk atilacak
2. telefon numaralari temizlenecek
3. zipcode degeri adrese atanacak
4. RNR iceren
   Individual   N - 1023
   				R - 1021
	Priv. Ent
		  	 	N - 1024
				R - 1022
5. CS-OFCRCode : Personel scicil no 	- PAZARLAMA_SORUMLUSU_SICIL_NO_1 Ayni kod ile atilir.
6. CS-SECTCODE ayni kodlarla atiliyor olucak
7. CS-ID-TYPE ve CS-ID-NO dolu ise
   			   PAS% ile basliyorsa 	  id_type= 3,pasaport_no =CS-ID-NO
      		   DRIV% ile basliyorsa	  id_type= 2,ehliyet_no =CS-ID-NO
			   digerleri dolu ise 	  id_type =1 id_card_no	= CS-ID-NO
8. Issued By > Issued place atilir.
*/
PROCEDURE CONV_CSMASF_RETAIL IS

  CURSOR conv_cursor IS
  select
  		    cs_cusno, cs_name_1, cs_name_2, cs_birthday, cs_sex,
  			cs_coucode,
			cs_addres_1,
			cs_addres_2,
			cs_addres_3,
			cs_addres_4,
			cs_zipcode,
			pkg_conv.telefonduzenle(CS_PHONE) cs_PHONE,
  			vergi_no,
			cs_rnr,
			decode ( CS_RNR,'N',1023,1021) dk_grup_kod,
			decode ( CS_RNR,'N','2','1')   yerlesim_kod,
			CS_OFCRCode PAZARLAMA_SORUMLUSU_SICIL_NO_1,
			decode( to_number(CS_SECTCODE),0,24,to_number(CS_SECTCODE))	Finans_kod,
			CS_ID_TYPE ,
			CS_ID_NO ,
			substr(trim(CS_ID_ISSUEDBY),1,30)	VERILDIGI_YER,
			CS_BIC_ACC
  from  conv_csmasf_retail
  where cs_cusno not in (select nvl(b.eski_musteri_no,-1)  from cbs_musteri b)
  order by cs_cusno;

  row_conv conv_cursor%ROWTYPE;
  ln_musteri_no NUMBER ;
  ls_id_type 	varchar2(1);
  ls_id_no	 	varchar2(20);
  ls_passport_no		varchar2(20);
  ls_ehliyet_no			varchar2(20);
  ls_addres_1 			varchar2(100);
  ls_addres_2 			varchar2(100);
  ls_addres_3 			varchar2(100);
  ls_addres_4 			varchar2(100);
  ls_uyruk_kod			VARCHAR2(10);
  BEGIN

  DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_B a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_BIREYSEL_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_ADRES_CONV_B a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_BIREYSEL_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_BIREYSEL_CONV
  WHERE AKTARILDIMI= 'H' ;

  COMMIT;

  	   OPEN conv_cursor;
	   FETCH conv_cursor INTO row_conv;
	   WHILE NOT conv_cursor%NOTFOUND
	   LOOP
	   	      ln_musteri_no:= Pkg_Genel.genel_kod_al('MUSTERI_NO');
			  ls_id_type	  := null;
			  ls_passport_no  := null;
			  ls_ehliyet_no   := null;
			  ls_id_no		  := null;

			  ls_uyruk_kod :=FindCountry(row_conv.CS_COUCODE);

			 if row_conv.CS_ID_TYPE is not null and row_conv.CS_ID_NO is not null then
			   if upper(row_conv.CS_ID_TYPE) like 'PAS%' then
			   	  ls_id_type :=  '3';
				  ls_passport_no := trim(row_conv.CS_ID_NO);
				elsif  upper(row_conv.CS_ID_TYPE) like 'DRIV%' then
			   	  ls_id_type :=  '2';
				  ls_ehliyet_no := trim(row_conv.CS_ID_NO);
				else
			   	  ls_id_type :=  '1';
				  ls_id_no := trim(row_conv.CS_ID_NO);
				 end if;
			  end if;

			  Begin
				INSERT INTO CBS_MUSTERI_BIREYSEL_CONV
				(MUSTERI_NO,
				 DURUM_KODU,
				 MUSTERI_TIPI_KOD,
				 ISIM,
				 SOYADI,
				 DOGUM_TARIHI,
				 CINSIYET_KOD,
				 HESAP_UCRETI_F,
				 CEK_KARNESI_F,
				 UYRUK_KOD,
				 EXTRE_ADRES_KOD,
				 YARATAN_KULLANICI_KODU,
				 YARATILDIGI_TARIH,
				 ESKI_MUSTERI_NO,
				 BOLUM_KODU,
				 vergi_no,
				 KIMLIK_KOD	,
				 EHLIYET_BELGE_NO,
				 NUFUS_CUZDANI_SERI_NO,
				 PASAPORT_NO,
				 DK_GRUP_KOD,
				 YERLESIM_KOD,
				 PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 FINANS_KOD	,
				 VERILDIGI_YER	,
				 EXTERNAL_ACCT_NO,
				 EKSTRE_UCRETI_ALINSIN,
				 modul_tur_kod,
				 urun_tur_kod,
				 urun_sinif_kod,
				 VERGI_ZORUNLUMU
				 )

				VALUES
			   (ln_musteri_no,
				'A',
				'1',
				SUBSTR(row_conv.CS_NAME_1,1,30),
				trim(SUBSTR(row_conv.CS_NAME_2,1,30)),
				row_conv.CS_BIRTHDAY,
				row_conv.CS_SEX,
				'E',
				'H',
				ls_uyruk_kod,
				'3',
				'CONV',
				SYSDATE,
				row_conv.CS_CUSNO,
				SUBSTR(row_conv.CS_CUSNO,1,3),
				row_conv.vergi_no,
				ls_id_type,
				ls_ehliyet_no,
				ls_id_no,
				ls_passport_no,
				 row_conv.DK_GRUP_KOD,
				 row_conv.YERLESIM_KOD,
				 26,--row_conv.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 row_conv.FINANS_KOD,
				 trim(row_conv.VERILDIGI_YER),
				 row_conv.CS_BIC_ACC,
				 'E',
				 'CUSTOMER',
				  UPPER ( pkg_musteri.sf_musteri_urun_tur_al(1)) ,
		  		  'GENERAL',
				  'E'
				);

 -- adres duzeltmeleri
		    	if instr(row_conv.CS_ADDRES_1,'9999') > 0 then
				    ls_addres_1 := ' ';
				else
					ls_addres_1 := 	row_conv.CS_ADDRES_1;
				end if;
				if instr(row_conv.CS_ADDRES_2,'9999') > 0 then
					ls_addres_2 := ' ';
				else
					ls_addres_2 := 	row_conv.CS_ADDRES_2;
				end if;
				if instr(row_conv.CS_ADDRES_3,'9999') > 0 then
					ls_addres_3 := ' ';
				else
					ls_addres_3 := 	row_conv.CS_ADDRES_3;
				end if;
				if instr(row_conv.CS_ADDRES_4,'9999') > 0 then
					ls_addres_4 := ' ';
				else
					ls_addres_4 := 	row_conv.CS_ADDRES_4;
				end if;

	   		INSERT INTO CBS_MUSTERI_ADRES_CONV_B
				(MUSTERI_NO,
				ADRES_KOD,
				ADRES,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH,
				EXTRE_ADRES_KOD_F,
				TEL_NO,
				ulke_kod
				)
				VALUES
			   (ln_musteri_no,
				'3',
				Trim(ls_ADDRES_1 || ls_ADDRES_2 || ls_ADDRES_3 || ls_addres_4||' '|| row_conv.CS_ZIPCODE) ,
				'CONV',
				SYSDATE,
				'E',
				row_conv.CS_PHONE,
				ls_uyruk_kod
				);
		   Exception when others then
	  			log_at('CONV_CSMASF_RETAIL',row_conv.CS_COUCODE,SQLCODE,SQLERRM);

	   	   END ;

	   	   FETCH conv_cursor INTO row_conv;
	   END LOOP;
 	   COMMIT;

	   CLOSE conv_cursor;

	  Exception when others then
	  log_at('CONV_CSMASF_RETAIL',row_conv.CS_COUCODE,SQLCODE,SQLERRM);
  END;
------------------------------
PROCEDURE CONV_CSMASF_PRIVENT IS

  CURSOR conv_cursor IS
  select
  		    cs_cusno, cs_name_1, cs_name_2, cs_birthday, cs_sex,
  			cs_coucode,
			cs_addres_1,
			cs_addres_2,
			cs_addres_3,
			cs_addres_4,
			cs_zipcode,
			pkg_conv.telefonduzenle(CS_PHONE) cs_PHONE,
  			vergi_no,
			cs_rnr,
			decode ( CS_RNR,'N',1024,1022) dk_grup_kod,
			decode ( CS_RNR,'N','2','1')   yerlesim_kod,
			CS_OFCRCode PAZARLAMA_SORUMLUSU_SICIL_NO_1,
			decode( to_number(CS_SECTCODE),0,24,to_number(CS_SECTCODE))	Finans_kod,
			CS_ID_TYPE ,
			CS_ID_NO ,
			substr(trim(CS_ID_ISSUEDBY),1,30)	VERILDIGI_YER,
			CS_BIC_ACC
  from  conv_csmasf_PRIVENT
  where cs_cusno not in (select nvl(b.eski_musteri_no,-1)  from cbs_musteri b)
  order by cs_cusno;

  row_conv conv_cursor%ROWTYPE;
  ln_musteri_no NUMBER ;
  ls_id_type 	varchar2(1);
  ls_id_no	 	varchar2(20);
  ls_passport_no		varchar2(20);
  ls_ehliyet_no			varchar2(20);
  ls_addres_1 			varchar2(100);
  ls_addres_2 			varchar2(100);
  ls_addres_3 			varchar2(100);
  ls_addres_4 			varchar2(100);
  ls_uyruk_kod			VARCHAR2(10);
  ls_sosyalfonno 		VARCHAR2(50);
  ls_opcocode			VARCHAR2(50);
  ls_vergino			VARCHAR2(50);

  BEGIN

  DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_p a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_privent_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_ADRES_CONV_p a
  WHERE EXISTS (SELECT 1 FROM CBS_MUSTERI_privent_CONV WHERE musteri_no =a.musteri_no and AKTARILDIMI= 'H' ) ;

  DELETE FROM CBS_MUSTERI_privent_CONV
  WHERE AKTARILDIMI= 'H' ;

  COMMIT;

  	   OPEN conv_cursor;
	   FETCH conv_cursor INTO row_conv;
	   WHILE NOT conv_cursor%NOTFOUND
	   LOOP
	   	      ln_musteri_no:= Pkg_Genel.genel_kod_al('MUSTERI_NO');
			  ls_id_type	  := null;
			  ls_passport_no  := null;
			  ls_ehliyet_no   := null;
			  ls_id_no		  := null;
			  ls_opcocode	  := null;
			  ls_sosyalfonno  := null;
			  ls_vergino	  := null;

			  ls_uyruk_kod :=FindCountry(row_conv.CS_COUCODE);

			 if row_conv.CS_ID_TYPE is not null and row_conv.CS_ID_NO is not null then
			   if upper(row_conv.CS_ID_TYPE) like 'PAS%' then
			   	  ls_id_type :=  '3';
				  ls_passport_no := trim(row_conv.CS_ID_NO);
				elsif  upper(row_conv.CS_ID_TYPE) like 'DRIV%' then
			   	  ls_id_type :=  '2';
				  ls_ehliyet_no := trim(row_conv.CS_ID_NO);
				else
			   	  ls_id_type :=  '1';
				  ls_id_no := trim(row_conv.CS_ID_NO);
				 end if;
			  end if;

 -- adres duzeltmeleri
		    	if instr(row_conv.CS_ADDRES_1,'9999') > 0 then
				    ls_addres_1 := ' ';
				else
					ls_addres_1 := 	row_conv.CS_ADDRES_1;
				end if;
				if instr(row_conv.CS_ADDRES_2,'9999') > 0 then
					ls_addres_2 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_2),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_2 := ' ';
						ls_opcocode := substr(trim(row_conv.CS_ADDRES_2),1,12) ;
					 else
						ls_addres_2 := 	row_conv.CS_ADDRES_2;
					 end if;

				end if;
				if instr(row_conv.CS_ADDRES_3,'9999') > 0 then
					ls_addres_3 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_3),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_3 := ' ';
						ls_vergino := substr(trim(row_conv.CS_ADDRES_3),1,20) ;
					 else
						ls_addres_3 := 	row_conv.CS_ADDRES_3;
					 end if;
				end if;
				if instr(row_conv.CS_ADDRES_4,'9999') > 0 then
					ls_addres_4 := ' ';
				else
					if  substr(trim(row_conv.CS_ADDRES_4),1,1) in ('0', '1','2', '3', '4', '5', '6', '7', '8', '9') then
						ls_addres_4 := ' ';
						ls_sosyalfonno := substr(trim(row_conv.CS_ADDRES_4),1,50) ;
					 else
						ls_sosyalfonno:=	row_conv.CS_ADDRES_4;
					 end if;
				end if;


			  Begin
				INSERT INTO CBS_MUSTERI_PRIVENT_CONV
				(MUSTERI_NO,
				 DURUM_KODU,
				 MUSTERI_TIPI_KOD,
				 ISIM,
				 SOYADI,
				 DOGUM_TARIHI,
				 CINSIYET_KOD,
				 HESAP_UCRETI_F,
				 CEK_KARNESI_F,
				 UYRUK_KOD,
				 EXTRE_ADRES_KOD,
				 YARATAN_KULLANICI_KODU,
				 YARATILDIGI_TARIH,
				 ESKI_MUSTERI_NO,
				 BOLUM_KODU,
				 KIMLIK_KOD	,
				 EHLIYET_BELGE_NO,
				 NUFUS_CUZDANI_SERI_NO,
				 PASAPORT_NO,
				 DK_GRUP_KOD,
				 YERLESIM_KOD,
				 PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 FINANS_KOD	,
				 VERILDIGI_YER	,
				 EXTERNAL_ACCT_NO,
				 EKSTRE_UCRETI_ALINSIN ,
		 		 modul_tur_kod,
				 urun_tur_kod,
				 urun_sinif_kod,
				 VERGI_NO ,
				 OKPO_CODE,
				 SOSYAL_FON_NO,
				 VERGI_ZORUNLUMU
				 )

				VALUES
			   (ln_musteri_no,
				'A',
				'2',
				SUBSTR(row_conv.CS_NAME_1,1,30),
				trim(SUBSTR(row_conv.CS_NAME_2,1,30)),
				row_conv.CS_BIRTHDAY,
				row_conv.CS_SEX,
				'E',
				'H',
				ls_uyruk_kod,
				'3',
				'CONV',
				SYSDATE,
				row_conv.CS_CUSNO,
				SUBSTR(row_conv.CS_CUSNO,1,3),
				ls_id_type,
				ls_ehliyet_no,
				ls_id_no,
				ls_passport_no,
				 row_conv.DK_GRUP_KOD,
				 row_conv.YERLESIM_KOD,
				 26,--row_conv.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
				 row_conv.FINANS_KOD,
				 trim(row_conv.VERILDIGI_YER),
				 row_conv.CS_BIC_ACC,
				 'E',
 				 'CUSTOMER',
				  UPPER ( pkg_musteri.sf_musteri_urun_tur_al(2)) ,
		  		  'GENERAL',
				  ls_vergino,
				  ls_opcocode,
				  ls_sosyalfonno,
				  'E'
				);


	   		INSERT INTO CBS_MUSTERI_ADRES_CONV_P
				(MUSTERI_NO,
				ADRES_KOD,
				ADRES,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH,
				EXTRE_ADRES_KOD_F,
				TEL_NO,
				ulke_kod
				)
				VALUES
			   (ln_musteri_no,
				'3',
				Trim(ls_ADDRES_1 || ls_ADDRES_2 || ls_ADDRES_3 || ls_addres_4||' '|| row_conv.CS_ZIPCODE) ,
				'CONV',
				SYSDATE,
				'E',
				row_conv.CS_PHONE,
				ls_uyruk_kod
				);


		   Exception when others then
	  			log_at('CONV_CSMASF_PRIVENT',row_conv.CS_COUCODE,SQLCODE,SQLERRM);

	   	   END ;

	   	   FETCH conv_cursor INTO row_conv;
	   END LOOP;
 	   COMMIT;

	   CLOSE conv_cursor;

	  Exception when others then
	  log_at('CONV_CSMASF_PRIVENT',row_conv.CS_COUCODE,SQLCODE,SQLERRM);
  END;
  -----------------
PROCEDURE CONV_VADESIZ IS
	CURSOR conv_cursor IS
		SELECT *
		FROM CONV_CAMASF
		where NVL(CA_AKTARILDI,'H')= 'H'
--		  AND NVL(eski_musteriden_yenial_hatasiz(SUBSTR(ca_cano,1,13)),0) <> 0
		  and ca_cycode not in ('00','03', '17', '11', '19')  --DEM, ITL, FRF, BEC
		FOR update of CA_AKTARILDI;

	row_conv conv_cursor%ROWTYPE;
	ln_count NUMBER;

	ln_bakiye_turu number;
	Ln_musteri_no	 NUMBER ;
	ln_ekstre_siklik		number;
	ls_ekstre_kod 		varchar2(3);
	ln_musteri			number;
BEGIN
	DELETE FROM CBS_HESAP_CONV_ERR;
	COMMIT;

	OPEN conv_cursor;
	FETCH conv_cursor INTO row_conv;
	WHILE NOT conv_cursor%NOTFOUND
	LOOP
	BEGIN
		ls_ekstre_kod := null;
		ln_ekstre_siklik := null;
		ln_musteri := null;

		if nvl(row_conv.CA_INTRT,0) is not null and nvl(row_conv.CA_INTIND,0)<>0
		then
			ln_bakiye_turu := 1;
		else
			ln_bakiye_turu := null;
		end if;

		ln_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.ca_cano,1,13));

		if ln_musteri = 0
		then
			insert into cbs_hesap_conv_err
			(PS_ESKI_MUSTERI_NO)
			values
			(SUBSTR(row_conv.ca_cano,1,13));
		else
			if row_conv.CA_STMCYC = 'X'
			THEN
				ls_ekstre_kod := 'X';
				ln_ekstre_siklik := null;
			ELSE
				ls_ekstre_kod := 'P';

				if row_conv.CA_STMCYC = 'D'
				then
					ln_ekstre_siklik := 1;
				end if;
				if row_conv.CA_STMCYC = 'W'
				then
					ln_ekstre_siklik := 2;
				end if;
				if row_conv.CA_STMCYC = 'M'
				then
					ln_ekstre_siklik :=4;
				end if;
			END IF;

			INSERT INTO CBS_HESAP_CONV
			(
				HESAP_NO,
				MUSTERI_NO,
				KISA_ISIM,
				DOVIZ_KODU,
				TUTAR,
				CEK_KARNESI,
				HESAP_HAREKET_KODU,
				ESAS_GUN_SAYISI,
				FAIZ_ORANI,
				FAIZ_INDIKATORU,
				BAKIYE_TURU,
				EKSTRE_BASIM_KODU,
				EKSTRE_SIKLIGI,
				DURUM_KODU,
				SUBE_KODU,
				MODUL_TUR_KOD,
				ACILIS_TARIHI,
				BIRIKMIS_FAIZ_NEG,
				BIRIKMIS_FAIZ_POZ,
				ESKI_HESAP_NO,
				ESKI_HESAP_EKNO,
				ESKI_DK_NO,
				EXTERNAL_HESAP_NO,
				GECMIS_AYLARIN_FAIZI,
				GECMIS_AYLARIN_FAIZI_NEG
			)
			VALUES
			(
				Pkg_Genel.genel_kod_al('HESAP.VDSZ'),
				ln_musteri,
				row_conv.CA_SHNAME,
				Pkg_Conv.dvz(row_conv.CA_CYCODE),
				row_conv.CA_BOOKBAL,
				'H',
				1,
				row_conv.CA_INTDAYS,
				row_conv.CA_INTRT,
				decode(row_conv.CA_INTIND,0,null),
				ln_bakiye_turu,
				ls_ekstre_kod,
				ln_ekstre_siklik,
				'A',
				SUBSTR(row_conv.CA_CANO,1,3),
				'CURRENT',
				row_conv.CA_FTRDATE,
				row_conv.CA_CUMINT_N,
				row_conv.CA_CUMINT,
				to_number(SUBSTR(row_conv.CA_CANO,4,10)),
				SUBSTR(row_conv.CA_CANO,14,3),
				row_conv.CA_GLCODE,
				musteriden_external_al(ln_musteri),
				row_conv.CA_LSTMTHINT,
				row_conv.CA_LSTMTHINT_N
			);

			UPDATE CONV_CAMASF
			SET CA_AKTARILDI = 'E'
			where current of conv_cursor;
		end if;
	END ;
	FETCH conv_cursor INTO row_conv;
	END LOOP;

	COMMIT;
	CLOSE conv_cursor;
END;
------------------------------
PROCEDURE CONV_VADELI
IS
	CURSOR conv_cursor IS
	SELECT *
	FROM CONV_CRMASF
	where NVL(CR_AKTARILDI,'H')= 'H'
--	  AND NVL( eski_musteriden_yenial_hatasiz(SUBSTR(cr_cano,1,13)),0) <> 0
	FOR update of CR_AKTARILDI	;

	row_conv conv_cursor%ROWTYPE;
	ln_count NUMBER;
	ls_oto_temdit   varchar2(3);
	ls_ekstre_kod   varchar2(1);
	ln_ekstre_siklik	number;
	ln_musteri			number;
	period1				varchar2(1);
	period2				varchar2(1);
BEGIN
  DELETE FROM CBS_HESAP_VADELI_CONV_ERR;
  COMMIT;

	ls_ekstre_kod := null;
	ln_ekstre_siklik := null;
	ln_musteri :=  null;

	OPEN conv_cursor;
	FETCH conv_cursor INTO row_conv;
	WHILE NOT conv_cursor%NOTFOUND
	LOOP
		BEGIN
			ln_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.cr_cano,1,13));

			if ln_musteri = 0
			then
				insert into CBS_HESAP_VADELI_CONV_ERR
				(PS_ESKI_MUSTERI_NO,ERR_MSG)
				values
				(SUBSTR(row_conv.cr_cano,1,13),'New Customer no is not found.');
			else
				if row_conv.cr_STMCYC = 'X'
				THEN
					ls_ekstre_kod := 'X';
					ln_ekstre_siklik := null;
				ELSE
					ls_ekstre_kod := 'P';

					if row_conv.cr_STMCYC = 'D'
					then
						ln_ekstre_siklik := 1;
					end if;
					if row_conv.cr_STMCYC = 'W'
					then
						ln_ekstre_siklik := 2;
					end if;
					if row_conv.cr_STMCYC = 'M'
					then
						ln_ekstre_siklik :=4;
					end if;
				END IF;

				if Pkg_Conv.Optcode(row_conv.CR_OPTCODE) = '1'
				THEN
					ls_oto_temdit := null;
				ELSE
					ls_oto_temdit := 'YOK' ;
				END IF;

				period1 := substr(row_conv.cr_period,1,1);
				period2 := substr(row_conv.cr_period,2,1);

				INSERT INTO CBS_HESAP_VADELI_CONV
				(
					HESAP_NO,
					MUSTERI_NO,
					MODUL_TUR_KOD,
					KISA_ISIM,
					DOVIZ_KODU,
					TUTAR,
					VALOR_TARIHI,
					VADE_ISLEM_BILGISI ,
					ARA_ODEME_BILGISI ,
					PERIOD_SURE,
					PERIOD_CINS,
					SONRAKI_BASLANGIC_TARIHI,
					VADE_TARIHI,
					GERI_DONUS_HESAPNO,
					ESAS_GUN_SAYISI,
					FAIZ_ORANI,
					EKSTRE_BASIM_KODU,
					EKSTRE_SIKLIGI,
					SUBE_KODU,
					BIRIKMIS_FAIZ_POZ,
					ACILIS_TARIHI,
					DURUM_KODU,
					GECEN_YIL_FAIZ_TOPLAMI,
					BORC_KAYDI,
					ESKI_HESAP_NO,
					ESKI_HESAP_EKNO,
					ESKI_HESAP_REFNO,
					ESKI_DK_NO,
					MUHASEBE_TARIHI,
					GECMIS_AYLARIN_FAIZI,
					ODENMIS_FAIZ_TOPLAMI,
					ODENMIS_FAIZ_TOPLAMI_LC,
					OTOMATIK_TEMDIT
				)
				VALUES
				(
					Pkg_Genel.genel_kod_al('HESAP.VDSZ'),
					ln_musteri,
					'TIME DEP.' ,
					row_conv.CR_SHNAME,
					Pkg_Conv.dvz(row_conv.CR_CYCODE),
					row_conv.CR_BOOKBAL,
					row_conv.CR_FTRDATE,
					Pkg_Conv.Optcode(row_conv.CR_OPTCODE),
					1,
					period1,
					DECODE(PERIOD2,'M','A',PERIOD2),
					row_conv.CR_NPSDATE,
					row_conv.CR_MTRDATE,
					DECODE(row_conv.CR_RLTVCANO,null,NULL,Pkg_Conv.Rltv(SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),1,13),SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),14,3),Pkg_Conv.dvz(row_conv.CR_CYCODE))),
					row_conv.CR_INTDAYS,
					row_conv.CR_INTRT,
					ls_ekstre_kod,
					ln_ekstre_siklik,
					SUBSTR(row_conv.CR_CANO,1,3),
					row_conv.CR_CUMINT,
					row_conv.CR_FTRDATE,
					'A',
					row_conv.CR_LSTYRINT,
					3,
					SUBSTR(row_conv.CR_CANO,4,10),
					SUBSTR(row_conv.CR_CANO,14,3),
					row_conv.CR_refno,
					row_conv.CR_GLCODE,
					row_conv.CR_FTRDATE,
					row_conv.CR_LSTMTHINT,
					row_conv.CR_ANNINT,
					DECODE(row_conv.CR_CYCODE,'75',row_conv.CR_ANNINT,0),
					ls_oto_temdit
				);


--sevalb iliskili hesap sistemde bulunamadi
				if row_conv.CR_RLTVCANO is not null and
				   Pkg_Conv.Rltv(SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),1,13),SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),14,3),Pkg_Conv.dvz(row_conv.CR_CYCODE)) is null then
						insert into CBS_HESAP_VADELI_CONV_ERR
						(PS_ESKI_MUSTERI_NO,ERR_MSG)
						values
						(SUBSTR(row_conv.cr_cano,1,13),row_conv.CR_RLTVCANO || ' Related Account is nof found' );
				else

					UPDATE CONV_CRMASF
					SET CR_AKTARILDI = 'E'
					where current of conv_cursor;
				end if;
			end if;
		END ;

		FETCH conv_cursor INTO row_conv;
	END LOOP;
	COMMIT;
	CLOSE conv_cursor;
END;
------------------------------
PROCEDURE CONV_KREDI
IS
	CURSOR conv_cursor IS
	SELECT *
	FROM CONV_CRMASF_KREDI
	where NVL(CR_AKTARILDI,'H')= 'H'
--	  AND NVL( eski_musteriden_yenial_hatasiz(SUBSTR(cr_cano,1,13)),0) <> 0
	FOR update of CR_AKTARILDI	;

	row_conv conv_cursor%ROWTYPE;
	ln_count NUMBER;
	ln_musteri		number;
BEGIN
	DELETE FROM CBS_HESAP_KREDI_CONV_ERR;
	COMMIT;

	OPEN conv_cursor;
	FETCH conv_cursor INTO row_conv;
	WHILE NOT conv_cursor%NOTFOUND
	LOOP
		BEGIN

			ln_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.cr_cano,1,13));

			if ln_musteri = 0
			then
				insert into CBS_HESAP_KREDI_CONV_ERR
				(PS_ESKI_MUSTERI_NO,ERR_MESAJ)
				values
				(SUBSTR(row_conv.cr_cano,1,13),'New Customer no is not found.' );
			else
				INSERT INTO CBS_HESAP_KREDI_CONV
				(
					HESAP_NO,
					MUSTERI_NO,
					DOVIZ_KODU,
					TUTAR,
					DURUM_KODU,
					SUBE_KODU,
					MODUL_TUR_KOD,
					KREDI_VADE,
					FAIZ_ORANI,
					KOMISYON_ORANI,
					ILISKILI_HESAP_NO,
					BIRIKMIS_FAIZ_TUTARI,
					BIRIKMIS_KOMISYON_TUTARI,
					ESAS_GUN_SAYISI,
					ACILIS_TARIHI,
					GECENYIL_FAIZ_TUTARI,
					ESKI_HESAP_NO,
					ESKI_HESAP_EKNO,
					REPAYMENT_TYPE,
					ESKI_HESAP_REFNO,
					ESKI_DK_NO,
					SON_GUN_FAIZI,
					ALACAK_HESAP_NO,
					TAHSILEDILEN_FAIZ_TUTARI,
					TAHSILEDILEN_FAIZ_TUTARI_LC,
					GECMIS_AYLARIN_FAIZI
				)


				VALUES
				(
					Pkg_Genel.genel_kod_al('HESAP.VDSZ'),
					ln_musteri,
					Pkg_Conv.dvz(row_conv.CR_CYCODE),
					row_conv.CR_BOOKBAL,
					'A',
					SUBSTR(row_conv.CR_CANO,1,3),
					'LOAN',
					row_conv.CR_MTRDATE,
					row_conv.CR_INTRT,
					row_conv.CR_COMRT,
					DECODE(row_conv.CR_RLTVCANO,null,NULL,Pkg_Conv.Rltv(SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),1,13),SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),14,3),Pkg_Conv.dvz(row_conv.CR_CYCODE))) ,
					row_conv.CR_CUMINT,
					row_conv.CR_CUMCOM,
					row_conv.CR_INTDAYS,
					row_conv.CR_FTRDATE,
					row_conv.CR_LSTYRINT,
					SUBSTR(row_conv.CR_CANO,4,10),
					SUBSTR(row_conv.CR_CANO,14,3),
					'MATURITY DATE',
					row_conv.CR_REFNO,
					row_conv.CR_GLCODE,
					'H',
					DECODE(row_conv.CR_RLTVCANO,null,NULL,Pkg_Conv.Rltv(SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),1,13),SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),14,3),Pkg_Conv.dvz(row_conv.CR_CYCODE))) ,
					row_conv.CR_ANNINT,
					DECODE(row_conv.CR_CYCODE,'75',row_conv.CR_ANNINT,0),
					row_conv.CR_LSTMTHINT
				);

--sevalb iliskili hesap sistemde bulunamadi
				if row_conv.CR_RLTVCANO is not null and
				   Pkg_Conv.Rltv(SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),1,13),SUBSTR(TO_CHAR(row_conv.CR_RLTVCANO),14,3),Pkg_Conv.dvz(row_conv.CR_CYCODE)) is null then
						insert into CBS_HESAP_KREDI_CONV_ERR
						(PS_ESKI_MUSTERI_NO,ERR_MESAJ)
						values
						(SUBSTR(row_conv.cr_cano,1,13),row_conv.CR_RLTVCANO || ' Related Account is nof found' );
				else

						UPDATE CONV_CRMASF_KREDI
						SET CR_AKTARILDI = 'E'
						where current of conv_cursor;
				end if;
			end if;
		END ;
		FETCH conv_cursor INTO row_conv;
	END LOOP;
	COMMIT;


	CLOSE conv_cursor;
END;
------------------------------
  FUNCTION  FindCountry( ps_code  CBS.CONV_CSMASF_BANK.CS_COUCODE%TYPE) RETURN  VARCHAR
  IS
    ls_code VARCHAR(2) ;
  BEGIN
  	   IF ps_code = '004' THEN ls_code := 'AF' ;
	   END IF;
  	   IF ps_code = '008' THEN ls_code := 'AL' ;
	   END IF;
  	   IF ps_code = '036' THEN ls_code := 'AU' ;
	   END IF;
  	   IF ps_code = '040' THEN ls_code := 'AT' ;
	   END IF;
  	   IF ps_code = '050' THEN ls_code := 'BD' ;
	   END IF;
  	   IF ps_code = '056' THEN ls_code := 'BE' ;
	   END IF;
  	   IF ps_code = '076' THEN ls_code := 'BR' ;
	   END IF;
  	   IF ps_code = '100' THEN ls_code := 'BG' ;
	   END IF;
  	   IF ps_code = '110' THEN ls_code := 'RU' ;
	   END IF;
  	   IF ps_code = '120' THEN ls_code := 'CM' ;
	   END IF;
  	   IF ps_code = '124' THEN ls_code := 'CA' ;
	   END IF;
  	   IF ps_code = '130' THEN ls_code := 'UA' ;
	   END IF;
  	   IF ps_code = '144' THEN ls_code := 'LK' ;
	   END IF;
  	   IF ps_code = '150' THEN ls_code := 'BY' ;
	   END IF;
  	   IF ps_code = '156' THEN ls_code := 'CN' ;
	   END IF;
  	   IF ps_code = '158' THEN ls_code := 'TW' ;
	   END IF;
  	   IF ps_code = '170' THEN ls_code := 'UZ' ;
	   END IF;
  	   IF ps_code = '190' THEN ls_code := 'KZ' ;
	   END IF;
  	   IF ps_code = '191' THEN ls_code := 'HR' ;
	   END IF;
  	   IF ps_code = '192' THEN ls_code := 'CU' ;
	   END IF;
  	   IF ps_code = '196' THEN ls_code := 'CY' ;
	   END IF;
  	   IF ps_code = '203' THEN ls_code := 'CZ' ;
	   END IF;
  	   IF ps_code = '208' THEN ls_code := 'DK' ;
	   END IF;
  	   IF ps_code = '220' THEN ls_code := 'GE' ;
	   END IF;
  	   IF ps_code = '233' THEN ls_code := 'EE' ;
	   END IF;
  	   IF ps_code = '240' THEN ls_code := 'AZ' ;
	   END IF;
  	   IF ps_code = '246' THEN ls_code := 'FI' ;
	   END IF;
  	   IF ps_code = '250' THEN ls_code := 'FR' ;
	   END IF;
  	   IF ps_code = '276' THEN ls_code := 'DE' ;
	   END IF;
  	   IF ps_code = '280' THEN ls_code := 'MD' ;
	   END IF;
  	   IF ps_code = '288' THEN ls_code := 'GH' ;
	   END IF;
  	   IF ps_code = '300' THEN ls_code := 'GR' ;
	   END IF;
  	   IF ps_code = '336' THEN ls_code := 'VA' ;
	   END IF;
  	   IF ps_code = '344' THEN ls_code := 'HK' ;
	   END IF;
  	   IF ps_code = '348' THEN ls_code := 'HU' ;
	   END IF;
  	   IF ps_code = '350' THEN ls_code := 'TJ' ;
	   END IF;
  	   IF ps_code = '352' THEN ls_code := 'IS' ;
	   END IF;
  	   IF ps_code = '356' THEN ls_code := 'IN' ;
	   END IF;
  	   IF ps_code = '360' THEN ls_code := 'ID' ;
	   END IF;
  	   IF ps_code = '364' THEN ls_code := 'IR' ;
	   END IF;
  	   IF ps_code = '368' THEN ls_code := 'IQ' ;
	   END IF;
  	   IF ps_code = '370' THEN ls_code := 'AM' ;
	   END IF;
  	   IF ps_code = '372' THEN ls_code := 'IE' ;
	   END IF;
  	   IF ps_code = '376' THEN ls_code := 'IL' ;
	   END IF;
  	   IF ps_code = '380' THEN ls_code := 'IT' ;
	   END IF;
  	   IF ps_code = '390' THEN ls_code := 'TM' ;
	   END IF;
  	   IF ps_code = '392' THEN ls_code := 'JP' ;
	   END IF;
  	   IF ps_code = '400' THEN ls_code := 'JO' ;
	   END IF;
  	   IF ps_code = '404' THEN ls_code := 'KE' ;
	   END IF;
  	   IF ps_code = '408' THEN ls_code := 'KP' ;
	   END IF;
  	   IF ps_code = '410' THEN ls_code := 'KR' ;
	   END IF;
  	   IF ps_code = '414' THEN ls_code := 'KW' ;
	   END IF;
  	   IF ps_code = '422' THEN ls_code := 'LB' ;
	   END IF;
  	   IF ps_code = '428' THEN ls_code := 'LV' ;
	   END IF;
  	   IF ps_code = '434' THEN ls_code := 'LR' ;
	   END IF;
  	   IF ps_code = '438' THEN ls_code := 'LF' ;
	   END IF;
  	   IF ps_code = '440' THEN ls_code := 'LT' ;
	   END IF;
  	   IF ps_code = '442' THEN ls_code := 'LU' ;
	   END IF;
  	   IF ps_code = '458' THEN ls_code := 'MU' ;
	   END IF;
  	   IF ps_code = '466' THEN ls_code := 'ML' ;
	   END IF;
  	   IF ps_code = '470' THEN ls_code := 'MT' ;
	   END IF;
  	   IF ps_code = '484' THEN ls_code := 'MX' ;
	   END IF;
  	   IF ps_code = '496' THEN ls_code := 'MN' ;
	   END IF;
  	   IF ps_code = '504' THEN ls_code := 'MA' ;
	   END IF;
  	   IF ps_code = '524' THEN ls_code := 'NP' ;
	   END IF;
  	   IF ps_code = '528' THEN ls_code := 'NL' ;
	   END IF;
  	   IF ps_code = '554' THEN ls_code := 'NZ' ;
	   END IF;
  	   IF ps_code = '566' THEN ls_code := 'NG' ;
	   END IF;
  	   IF ps_code = '578' THEN ls_code := 'NO' ;
	   END IF;
  	   IF ps_code = '586' THEN ls_code := 'PK' ;
	   END IF;
  	   IF ps_code = '604' THEN ls_code := 'PE' ;
	   END IF;
  	   IF ps_code = '608' THEN ls_code := 'PH' ;
	   END IF;
  	   IF ps_code = '616' THEN ls_code := 'PL' ;
	   END IF;
  	   IF ps_code = '620' THEN ls_code := 'PT' ;
	   END IF;
  	   IF ps_code = '634' THEN ls_code := 'QA' ;
	   END IF;
  	   IF ps_code = '642' THEN ls_code := 'RO' ;
	   END IF;
  	   IF ps_code = '682' THEN ls_code := 'SA' ;
	   END IF;
  	   IF ps_code = '702' THEN ls_code := 'SG' ;
	   END IF;
  	   IF ps_code = '703' THEN ls_code := 'SK' ;
	   END IF;
  	   IF ps_code = '704' THEN ls_code := 'VN' ;
	   END IF;
  	   IF ps_code = '705' THEN ls_code := 'SI' ;
	   END IF;
  	   IF ps_code = '710' THEN ls_code := 'ZA' ;
	   END IF;
  	   IF ps_code = '716' THEN ls_code := 'ZW' ;
	   END IF;
  	   IF ps_code = '724' THEN ls_code := 'ES' ;
	   END IF;
  	   IF ps_code = '736' THEN ls_code := 'SD' ;
	   END IF;
  	   IF ps_code = '752' THEN ls_code := 'SE' ;
	   END IF;
  	   IF ps_code = '756' THEN ls_code := 'CH' ;
	   END IF;
  	   IF ps_code = '760' THEN ls_code := 'SY' ;
	   END IF;
  	   IF ps_code = '764' THEN ls_code := 'TH' ;
	   END IF;
  	   IF ps_code = '784' THEN ls_code := 'AE' ;
	   END IF;
  	   IF ps_code = '818' THEN ls_code := 'EG' ;
	   END IF;
  	   IF ps_code = '826' THEN ls_code := 'GB' ;
	   END IF;
  	   IF ps_code = '840' THEN ls_code := 'US' ;
	   END IF;
  	   IF ps_code = '888' THEN ls_code := 'TR' ;
	   END IF;
  	   IF ps_code = '891' THEN ls_code := 'YU' ;
	   END IF;
  	   IF ps_code = '895' THEN ls_code := 'EU' ;
	   END IF;
  	   IF ps_code = '897' THEN ls_code := 'XX' ;
	   END IF;
   	   IF ps_code = '999' THEN ls_code := 'KG' ;
	   END IF;
	  RETURN ls_code;
  END;
------------------------------
  FUNCTION  Optcode( ps_optcode  CBS.CONV_VADELI.CR_OPTCODE%TYPE) RETURN  VARCHAR
  IS
    ln_code NUMBER ;
  BEGIN
  	   IF ps_optcode = 'F' THEN ln_code := 1 ; END IF;
  	   IF ps_optcode = 'N' THEN ln_code := 2 ; END IF;
  	   IF ps_optcode = 'R' THEN ln_code := 3 ; END IF;
	  RETURN ln_code;
  END;
-------------------------
  FUNCTION  Dvz( ps_dvzcode  VARCHAR) RETURN  VARCHAR
  IS
    ls_code VARCHAR(3) ;
  BEGIN
  	   IF ps_dvzcode = '83' THEN ls_code := 'TRY' ; END IF;
  	   IF ps_dvzcode = '01' THEN ls_code := 'USD' ; END IF;
  	   IF ps_dvzcode = '03' THEN ls_code := 'DEM' ; END IF;
  	   IF ps_dvzcode = '05' THEN ls_code := 'GBP' ; END IF;
  	   IF ps_dvzcode = '07' THEN ls_code := 'CHF' ; END IF;
  	   IF ps_dvzcode = '09' THEN ls_code := 'JPY' ; END IF;
  	   IF ps_dvzcode = '11' THEN ls_code := 'FRF' ; END IF;
  	   IF ps_dvzcode = '13' THEN ls_code := 'NLG' ; END IF;
  	   IF ps_dvzcode = '15' THEN ls_code := 'ATS' ; END IF;
  	   IF ps_dvzcode = '17' THEN ls_code := 'ITL' ; END IF;
  	   IF ps_dvzcode = '19' THEN ls_code := 'BEC' ; END IF;
  	   IF ps_dvzcode = '21' THEN ls_code := 'DKK' ; END IF;
  	   IF ps_dvzcode = '23' THEN ls_code := 'SEK' ; END IF;
  	   IF ps_dvzcode = '25' THEN ls_code := 'NOK' ; END IF;
  	   IF ps_dvzcode = '27' THEN ls_code := 'SAR' ; END IF;
  	   IF ps_dvzcode = '29' THEN ls_code := 'KWD' ; END IF;
  	   IF ps_dvzcode = '31' THEN ls_code := 'CAD' ; END IF;
  	   IF ps_dvzcode = '33' THEN ls_code := 'AUD' ; END IF;
  	   IF ps_dvzcode = '35' THEN ls_code := 'FIM' ; END IF;
  	   IF ps_dvzcode = '37' THEN ls_code := 'ESP' ; END IF;
  	   IF ps_dvzcode = '39' THEN ls_code := 'PTE' ; END IF;
  	   IF ps_dvzcode = '41' THEN ls_code := 'GRD' ; END IF;
  	   IF ps_dvzcode = '43' THEN ls_code := 'EGP' ; END IF;
  	   IF ps_dvzcode = '45' THEN ls_code := 'IEP' ; END IF;
  	   IF ps_dvzcode = '47' THEN ls_code := 'A2M' ; END IF;
  	   IF ps_dvzcode = '49' THEN ls_code := 'BYB' ; END IF;
  	   IF ps_dvzcode = '51' THEN ls_code := 'KZT' ; END IF;
  	   IF ps_dvzcode = '53' THEN ls_code := 'EUR' ; END IF;
  	   IF ps_dvzcode = '55' THEN ls_code := 'LTL' ; END IF;
  	   IF ps_dvzcode = '57' THEN ls_code := 'MDL' ; END IF;
  	   IF ps_dvzcode = '59' THEN ls_code := 'RUB' ; END IF;
  	   IF ps_dvzcode = '61' THEN ls_code := 'UAK' ; END IF;
  	   IF ps_dvzcode = '63' THEN ls_code := 'EEK' ; END IF;
  	   IF ps_dvzcode = '65' THEN ls_code := 'UZS' ; END IF;
  	   IF ps_dvzcode = '67' THEN ls_code := 'TJS' ; END IF;
  	   IF ps_dvzcode = '69' THEN ls_code := 'TMM' ; END IF;
  	   IF ps_dvzcode = '71' THEN ls_code := 'AMM' ; END IF;
  	   IF ps_dvzcode = '73' THEN ls_code := 'GEL' ; END IF;
  	   IF ps_dvzcode = '75' THEN ls_code := 'KGS' ; END IF; -- sevalb 140405
  	   IF ps_dvzcode = '77' THEN ls_code := 'SDR' ; END IF;
  	   IF ps_dvzcode = '79' THEN ls_code := 'LVL' ; END IF;
  	   IF ps_dvzcode = '81' THEN ls_code := 'BYR' ; END IF;
  	   IF ps_dvzcode = '99' THEN ls_code := 'ECU' ; END IF;


	  RETURN nvl(ls_code,ps_dvzcode);
  END;
-------------------------
  FUNCTION  Rltv( in_acc  VARCHAR, in_sfx VARCHAR, in_dvz VARCHAR) RETURN  VARCHAR
  IS
    out_acc NUMBER ;
	 ls_acc varchar2(10);
  BEGIN
   if length(in_acc)>10 then
      ls_acc := substr(in_acc,-10);
   else
      ls_acc := in_acc;
   end if;
	   SELECT HESAP_NO
	   INTO out_acc
	   FROM CBS_HESAP
	   WHERE ESKI_HESAP_NO = TO_NUMBER(ls_acc) AND
	   ESKI_HESAP_EKNO = TO_NUMBER(in_sfx) AND
	   DOVIZ_KODU = in_dvz  ;
	   RETURN out_acc;
	 Exception when others then return null;
  END;
-------------------------
  FUNCTION  UrunTurAdKredi( in_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_TUR
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'LOAN';

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunTurAdVadeli( in_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_TUR
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'TIME DEP.';

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunTurAdVadesiz( in_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_TUR
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'CURRENT';

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunSinifAdKredi(in_kod  VARCHAR, in_urun_tur_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_SINIF
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'LOAN'
	   AND URUN_TUR_KOD = in_urun_tur_kod;

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunSinifAdVadeli(in_kod  VARCHAR, in_urun_tur_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_SINIF
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'TIME DEP.'
	   AND URUN_TUR_KOD = in_urun_tur_kod;

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunSinifAdVadesiz(in_kod  VARCHAR, in_urun_tur_kod  VARCHAR) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(200) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_URUN_SINIF
	   WHERE KOD = IN_KOD
	   AND MODUL_TUR_KOD = 'CURRENT'
	   AND URUN_TUR_KOD = in_urun_tur_kod;

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  KaynakAdi(in_kod  CBS.CBS_KAYNAK_KODLARI.KAYNAK_KODU%TYPE) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(100) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_KAYNAK_KODLARI
	   WHERE KAYNAK_KODU = in_kod;

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  IstAd(in_kod  CBS.CBS_ISTATISTIK_KODLARI.ISTATISTIK_KODU%TYPE) RETURN  VARCHAR
  IS
    out_aciklama VARCHAR(1000) ;
  BEGIN
	   SELECT ACIKLAMA
	   INTO out_aciklama
	   FROM CBS_ISTATISTIK_KODLARI
	   WHERE ISTATISTIK_KODU = in_kod;

	   RETURN out_aciklama;
  END;
-------------------------
  FUNCTION  UrunSinifKontrolKredi(in_urun_tur_kod  CBS.CBS_URUN_SINIF.URUN_TUR_KOD%TYPE,
  										     in_urun_sinif_kod  CBS.CBS_URUN_SINIF.KOD%TYPE,
											 in_dvz  VARCHAR) RETURN  VARCHAR
  IS
    out_LC VARCHAR(1) ;
    out_RET VARCHAR(1) ;
  BEGIN
	   SELECT LC
	   INTO out_LC
	   FROM CBS_URUN_SINIF
	   WHERE MODUL_TUR_KOD = 'LOAN' AND
	   		 		URUN_TUR_KOD = in_urun_tur_kod AND
					KOD = in_urun_sinif_kod;

		IF out_LC = 'E' AND in_dvz = 'KZT' OR out_LC = 'H' AND in_dvz <> 'KZT' THEN
		   out_ret := 'E' ;
		ELSE
		   out_ret := 'H';
		END IF;
	   RETURN out_ret;
  END;
-------------------------
  PROCEDURE Sp_Musteri_No_Bul_Bireysel(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_BIREYSEL_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_BIREYSEL_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_BIREYSEL_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE,
  						ps_kimlik_id CBS_MUSTERI_BIREYSEL_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2)
  IS
  	ln_musteri_no CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE ;
	CURSOR cur_musteri_bireysel1 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_BIREYSEL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_full_isim) AND
			   NVL(Pkg_Genel.sf_sil_turkce_char(baba_adi),' ') = NVL(Pkg_Genel.sf_sil_turkce_char(ps_baba_adi),' ') AND
			   TRUNC(dogum_tarihi) = TRUNC(pd_dogum_tarihi) AND
			  -- nvl(pkg_genel.sf_sil_turkce_char(dogum_yeri),' ')   = nvl(pkg_genel.sf_sil_turkce_char(ps_dogum_yeri),' ') and
	 		 ( (  ps_kimlik_id = '1' AND NUFUS_CUZDANI_SERI_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '2' AND EHLIYET_BELGE_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '3' AND PASAPORT_NO=  ps_kimlik_no));

	CURSOR cur_musteri_yurtici_kurumsal1 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_BIREYSEL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan) AND
		   	   vergi_no = ps_vergi_no ;

	CURSOR cur_musteri_yurtdisi_kurumsal1 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_BIREYSEL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);

	CURSOR cur_musteri_banka1 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_BIREYSEL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);
BEGIN
IF ps_musteri_tipi  = '1' THEN --bireysel
	  IF cur_musteri_bireysel1%isopen THEN
	     CLOSE cur_musteri_bireysel1;
	   END IF;
	    	OPEN cur_musteri_bireysel1;
			 LOOP
			  	FETCH cur_musteri_bireysel1 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_bireysel1%NOTFOUND;
			 END LOOP;
			 CLOSE cur_musteri_bireysel1;
 END IF;

/* kurumsal & ticari  musteriler */
IF ps_musteri_tipi  IN ('2','3') THEN -- kurumsal & ticari ise
  IF ps_yerlesim_kod = '1'  THEN  --yurtici
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtici_kurumsal1%isopen THEN
	     CLOSE cur_musteri_yurtici_kurumsal1;
	   END IF;
	    	OPEN cur_musteri_yurtici_kurumsal1;
			 LOOP
			  	FETCH cur_musteri_yurtici_kurumsal1 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtici_kurumsal1%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtici_kurumsal1;
    ELSE
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtdisi_kurumsal1%isopen THEN
	     CLOSE cur_musteri_yurtdisi_kurumsal1;
	   END IF;
	    	OPEN cur_musteri_yurtdisi_kurumsal1;
			 LOOP
			  	FETCH cur_musteri_yurtdisi_kurumsal1 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtdisi_kurumsal1%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtdisi_kurumsal1;
   END IF;
 END IF;

 /* banka musterileri */
 IF ps_musteri_tipi  IN ('4') THEN
       IF cur_musteri_banka1%isopen THEN
	     CLOSE cur_musteri_banka1;
	   END IF;
	    	OPEN cur_musteri_banka1;
			 LOOP
			  	FETCH cur_musteri_banka1 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_banka1%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_banka1;
 END IF;
   EXCEPTION
	  WHEN NO_DATA_FOUND THEN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '112' || Pkg_Hata.getDelimiter   || SQLERRM ||Pkg_Hata.getUCPOINTER);

 END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE Sp_Musteri_No_Bul_Kurumsal(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_KURUMSAL_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_KURUMSAL_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_KURUMSAL_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE,
  						ps_kimlik_id CBS_MUSTERI_KURUMSAL_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2)
  IS
  	ln_musteri_no CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE ;
	CURSOR cur_musteri_bireysel2 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_full_isim) AND
			   NVL(Pkg_Genel.sf_sil_turkce_char(baba_adi),' ') = NVL(Pkg_Genel.sf_sil_turkce_char(ps_baba_adi),' ') AND
			   TRUNC(dogum_tarihi) = TRUNC(pd_dogum_tarihi) AND
	 		 ( (  ps_kimlik_id = '1' AND NUFUS_CUZDANI_SERI_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '2' AND EHLIYET_BELGE_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '3' AND PASAPORT_NO=  ps_kimlik_no));

	CURSOR cur_musteri_yurtici_kurumsal2 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan) AND
		   	   vergi_no = ps_vergi_no ;

	CURSOR cur_musteri_yurtdisi_kurumsal2 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);

	CURSOR cur_musteri_banka2 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);
BEGIN
IF ps_musteri_tipi  = '1' THEN --bireysel
	  IF cur_musteri_bireysel2%isopen THEN
	     CLOSE cur_musteri_bireysel2;
	   END IF;
	    	OPEN cur_musteri_bireysel2;
			 LOOP
			  	FETCH cur_musteri_bireysel2 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_bireysel2%NOTFOUND;
			 END LOOP;
			 CLOSE cur_musteri_bireysel2;
 END IF;

/* kurumsal & ticari  musteriler */
IF ps_musteri_tipi  IN ('2','3') THEN -- kurumsal & ticari ise
  IF ps_yerlesim_kod = '1'  THEN  --yurtici
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtici_kurumsal2%isopen THEN
	     CLOSE cur_musteri_yurtici_kurumsal2;
	   END IF;
	    	OPEN cur_musteri_yurtici_kurumsal2;
			 LOOP
			  	FETCH cur_musteri_yurtici_kurumsal2 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtici_kurumsal2%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtici_kurumsal2;
    ELSE
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtdisi_kurumsal2%isopen THEN
	     CLOSE cur_musteri_yurtdisi_kurumsal2;
	   END IF;
	    	OPEN cur_musteri_yurtdisi_kurumsal2;
			 LOOP
			  	FETCH cur_musteri_yurtdisi_kurumsal2 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtdisi_kurumsal2%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtdisi_kurumsal2;
   END IF;
 END IF;

 /* banka musterileri */
 IF ps_musteri_tipi  IN ('4') THEN
       IF cur_musteri_banka2%isopen THEN
	     CLOSE cur_musteri_banka2;
	   END IF;
	    	OPEN cur_musteri_banka2;
			 LOOP
			  	FETCH cur_musteri_banka2 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_banka2%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_banka2;
 END IF;
   EXCEPTION
	  WHEN NO_DATA_FOUND THEN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '112' || Pkg_Hata.getDelimiter   || SQLERRM ||Pkg_Hata.getUCPOINTER);

 END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE Sp_Musteri_No_Bul_Banka(ps_full_isim VARCHAR2 ,ps_unvan VARCHAR2,
                        ps_musteri_tipi VARCHAR2,
						ps_yerlesim_kod VARCHAR2,
						ps_baba_adi CBS_MUSTERI_BANKA_CONV.baba_adi%TYPE ,
						pd_dogum_tarihi CBS_MUSTERI_BANKA_CONV.dogum_tarihi%TYPE ,
						ps_dogum_yeri CBS_MUSTERI_BANKA_CONV.dogum_yeri%TYPE ,
						pn_musteri_no OUT CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE,
  						ps_kimlik_id CBS_MUSTERI_BANKA_CONV.KIMLIK_KOD%TYPE ,
						ps_kimlik_no VARCHAR2,
						ps_vergi_no VARCHAR2 ,
						ps_vergi_daire VARCHAR2)
  IS
  	ln_musteri_no CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE ;
	CURSOR cur_musteri_bireysel3 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_BANKA_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_full_isim) AND
			   NVL(Pkg_Genel.sf_sil_turkce_char(baba_adi),' ') = NVL(Pkg_Genel.sf_sil_turkce_char(ps_baba_adi),' ') AND
			   TRUNC(dogum_tarihi) = TRUNC(pd_dogum_tarihi) AND
			  -- nvl(pkg_genel.sf_sil_turkce_char(dogum_yeri),' ')   = nvl(pkg_genel.sf_sil_turkce_char(ps_dogum_yeri),' ') and
	 		 ( (  ps_kimlik_id = '1' AND NUFUS_CUZDANI_SERI_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '2' AND EHLIYET_BELGE_NO=  ps_kimlik_no) OR
			  (  ps_kimlik_id = '3' AND PASAPORT_NO=  ps_kimlik_no));

	CURSOR cur_musteri_yurtici_kurumsal3 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan) AND
		   	   vergi_no = ps_vergi_no ;

	CURSOR cur_musteri_yurtdisi_kurumsal3 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);

	CURSOR cur_musteri_banka3 IS
	    SELECT MIN(musteri_no)
		FROM   CBS_MUSTERI_KURUMSAL_CONV
		WHERE  arama_isim = Pkg_Genel.sf_sil_turkce_char(ps_unvan);
BEGIN
IF ps_musteri_tipi  = '1' THEN --bireysel
	  IF cur_musteri_bireysel3%isopen THEN
	     CLOSE cur_musteri_bireysel3;
	   END IF;
	    	OPEN cur_musteri_bireysel3;
			 LOOP
			  	FETCH cur_musteri_bireysel3 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_bireysel3%NOTFOUND;
			 END LOOP;
			 CLOSE cur_musteri_bireysel3;
 END IF;

/* kurumsal & ticari  musteriler */
IF ps_musteri_tipi  IN ('2','3') THEN -- kurumsal & ticari ise
  IF ps_yerlesim_kod = '1'  THEN  --yurtici
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtici_kurumsal3%isopen THEN
	     CLOSE cur_musteri_yurtici_kurumsal3;
	   END IF;
	    	OPEN cur_musteri_yurtici_kurumsal3;
			 LOOP
			  	FETCH cur_musteri_yurtici_kurumsal3 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtici_kurumsal3%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtici_kurumsal3;
    ELSE
   /* cursor for  yurt ici musteriler */
	  IF cur_musteri_yurtdisi_kurumsal3%isopen THEN
	     CLOSE cur_musteri_yurtdisi_kurumsal3;
	   END IF;
	    	OPEN cur_musteri_yurtdisi_kurumsal3;
			 LOOP
			  	FETCH cur_musteri_yurtdisi_kurumsal3 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_yurtdisi_kurumsal3%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_yurtdisi_kurumsal3;
   END IF;
 END IF;

 /* banka musterileri */
 IF ps_musteri_tipi  IN ('4') THEN
       IF cur_musteri_banka3%isopen THEN
	     CLOSE cur_musteri_banka3;
	   END IF;
	    	OPEN cur_musteri_banka3;
			 LOOP
			  	FETCH cur_musteri_banka3 INTO pn_musteri_no;
	         	EXIT WHEN cur_musteri_banka3%NOTFOUND;
			 END LOOP;
	 	CLOSE cur_musteri_banka3;
 END IF;
   EXCEPTION
	  WHEN NO_DATA_FOUND THEN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '112' || Pkg_Hata.getDelimiter   || SQLERRM ||Pkg_Hata.getUCPOINTER);
 END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION  Sf_Musteri_Adi( pn_musteri_no CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE) RETURN VARCHAR2
  IS
    ls_musteri_adi 	 VARCHAR2(200) := NULL;

	cursor c_0	is
	SELECT   isim || ' ' || ikinci_isim || ' '||soyadi
	FROM   CBS_MUSTERI_BIREYSEL_CONV
	WHERE  musteri_no = pn_musteri_no
	union
	SELECT isim || ' ' || ikinci_isim || ' '||soyadi
	FROM   CBS_MUSTERI_PRIVENT_CONV
	WHERE  musteri_no = pn_musteri_no;


  BEGIN
  	open c_0;
 	fetch c_0 into ls_musteri_adi;
 	 close c_0;

	RETURN UPPER(trim(ls_musteri_adi)) ;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '111' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION  Sf_Musteri_Adi_Kurumsal( pn_musteri_no CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE) RETURN VARCHAR2
  IS
    ls_musteri_adi 	 VARCHAR2(200) := NULL;
  BEGIN
  	SELECT DECODE(musteri_tipi_kod, '1', isim || ' ' || ikinci_isim || ' '||soyadi, ticari_unvan)
	INTO   ls_musteri_adi
	FROM   CBS_MUSTERI_KURUMSAL_CONV
	WHERE  musteri_no = pn_musteri_no ;

	RETURN UPPER(trim(ls_musteri_adi)) ;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '111' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION  Sf_Musteri_Adi_Banka( pn_musteri_no CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE) RETURN VARCHAR2
  IS
    ls_musteri_adi 	 VARCHAR2(200) := NULL;
  BEGIN
  	SELECT DECODE(musteri_tipi_kod, '1', isim || ' ' || ikinci_isim || ' '||soyadi, ticari_unvan)
	INTO   ls_musteri_adi
	FROM   CBS_MUSTERI_BANKA_CONV
	WHERE  musteri_no = pn_musteri_no ;

	RETURN UPPER(trim(ls_musteri_adi)) ;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN NULL;
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '111' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE Document_Insert_B(pn_musteri_no CBS_MUSTERI_BIREYSEL_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_BIREYSEL_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_B.yaratildigi_tarih%TYPE)
  IS

  	CURSOR cur_doc (pn_dk CBS_ISLEM.numara%TYPE) IS
	SELECT DOKUMAN_KODU, DK_GRUP_KODU, ACIKLAMA, YARATAN_KULLANICI_KODU, YARATILDIGI_TARIH, SIRA_NO
	FROM   CBS_DOKUMAN_KODLARI
	WHERE  DK_GRUP_KODU  = pn_dk_kod ;

	row_doc  cur_doc%ROWTYPE;
	inc  NUMBER;
  BEGIN
    DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_B
    WHERE MUSTERI_NO = pn_musteri_no ;
	COMMIT;
     inc := 0 ;
	 OPEN cur_doc(pn_dk_kod);
	 LOOP
	 FETCH cur_doc INTO row_doc;
			EXIT WHEN cur_doc%NOTFOUND;
	       inc := inc + 1 ;
         	INSERT INTO CBS_MUSTERI_DOKUMAN_CONV_B
			   (MUSTERI_NO,
			    SIRA_NO,
				DOKUMAN_ADI,
				ALINDI_KUTUSU_F,
				DUZENLENME_TARIHI,
				GECERLILIK_TARIHI,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH)
			   VALUES(
			   pn_musteri_no,
			    inc,
				row_doc.DOKUMAN_KODU,
				'E',
				NULL,
				NULL,
				'CONV',
				pn_date);
	       END LOOP ;
	       CLOSE cur_doc;
COMMIT;
  EXCEPTION
   WHEN OTHERS THEN
   		LOG_AT('Dokuman Hata Bireysel',sqlcode,sqlerrm);
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4535' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;

--------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE Document_Insert_P(pn_musteri_no CBS_MUSTERI_PRIVENT_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_PRIVENT_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_P.yaratildigi_tarih%TYPE)
  IS

  	CURSOR cur_doc (pn_dk CBS_ISLEM.numara%TYPE) IS
	SELECT DOKUMAN_KODU, DK_GRUP_KODU, ACIKLAMA, YARATAN_KULLANICI_KODU, YARATILDIGI_TARIH, SIRA_NO
	FROM   CBS_DOKUMAN_KODLARI
	WHERE  DK_GRUP_KODU  = pn_dk_kod;

	row_doc  cur_doc%ROWTYPE;
	inc  NUMBER;
  BEGIN
    DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_P
    WHERE MUSTERI_NO = pn_musteri_no ;
	commit;
     inc := 0 ;
	 OPEN cur_doc(pn_dk_kod);
	 LOOP
	 FETCH cur_doc INTO row_doc;
			EXIT WHEN cur_doc%NOTFOUND;
	       inc := inc + 1 ;
		    BEGIN
         	INSERT INTO CBS_MUSTERI_DOKUMAN_CONV_P
			   (MUSTERI_NO,
			    SIRA_NO,
				DOKUMAN_ADI,
				ALINDI_KUTUSU_F,
				DUZENLENME_TARIHI,
				GECERLILIK_TARIHI,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH)
			   VALUES(
			   pn_musteri_no,
			    inc,
				row_doc.DOKUMAN_KODU,
				'E',
				NULL,
				NULL,
				'CONV',
				pn_date);
				EXCEPTION WHEN OTHERS THEN
				LOG_AT('DOK-P',SQLCODE,SQLERRM);
				END;
	       END LOOP ;
	       CLOSE cur_doc;
COMMIT;
  EXCEPTION
   WHEN OTHERS THEN
   		LOG_AT('Dokuman Hata Priv.',sqlcode,sqlerrm);
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4535' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE Document_Insert_K(pn_musteri_no CBS_MUSTERI_KURUMSAL_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_KURUMSAL_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_K.yaratildigi_tarih%TYPE)
  IS

  	CURSOR cur_doc (pn_dk CBS_ISLEM.numara%TYPE) IS
	SELECT DOKUMAN_KODU, DK_GRUP_KODU, ACIKLAMA, YARATAN_KULLANICI_KODU, YARATILDIGI_TARIH, SIRA_NO
	FROM   CBS_DOKUMAN_KODLARI
	WHERE  DK_GRUP_KODU  = pn_dk_kod;

	row_doc  cur_doc%ROWTYPE;
	inc  NUMBER;
  BEGIN
    DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_K
    WHERE MUSTERI_NO = pn_musteri_no ;
	commit;
     inc := 0 ;
	 OPEN cur_doc(pn_dk_kod);
	 LOOP
	 FETCH cur_doc INTO row_doc;
			EXIT WHEN cur_doc%NOTFOUND;
	       inc := inc + 1 ;
         	INSERT INTO CBS_MUSTERI_DOKUMAN_CONV_K
			   (MUSTERI_NO,
			    SIRA_NO,
				DOKUMAN_ADI,
				ALINDI_KUTUSU_F,
				DUZENLENME_TARIHI,
				GECERLILIK_TARIHI,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH)
			   VALUES(
			   pn_musteri_no,
			    inc,
				row_doc.DOKUMAN_KODU,
				'E',
				NULL,
				NULL,
				'CONV',
				pn_date);
	       END LOOP ;
	       CLOSE cur_doc;
COMMIT;
  EXCEPTION
   WHEN OTHERS THEN
      		LOG_AT('Dokuman Hata corp.',sqlcode,sqlerrm);
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4535' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  PROCEDURE Document_Insert_N(pn_musteri_no CBS_MUSTERI_BANKA_CONV.musteri_no%TYPE,
  										  		 pn_dk_kod CBS_MUSTERI_BANKA_CONV.dk_grup_kod%TYPE,
  										  		 pn_date CBS_MUSTERI_DOKUMAN_CONV_N.yaratildigi_tarih%TYPE)
  IS

  	CURSOR cur_doc (pn_dk CBS_ISLEM.numara%TYPE) IS
	SELECT DOKUMAN_KODU, DK_GRUP_KODU, ACIKLAMA, YARATAN_KULLANICI_KODU, YARATILDIGI_TARIH, SIRA_NO
	FROM   CBS_DOKUMAN_KODLARI
	WHERE  DK_GRUP_KODU  = pn_dk_kod;

	row_doc  cur_doc%ROWTYPE;
	inc  NUMBER;
  BEGIN

    DELETE FROM CBS_MUSTERI_DOKUMAN_CONV_N
    WHERE MUSTERI_NO = pn_musteri_no ;
	commit;
     inc := 0 ;
	 OPEN cur_doc(pn_dk_kod);
	 LOOP
	 FETCH cur_doc INTO row_doc;
			EXIT WHEN cur_doc%NOTFOUND;
	       inc := inc + 1 ;
         	INSERT INTO CBS_MUSTERI_DOKUMAN_CONV_N
			   (MUSTERI_NO,
			    SIRA_NO,
				DOKUMAN_ADI,
				ALINDI_KUTUSU_F,
				DUZENLENME_TARIHI,
				GECERLILIK_TARIHI,
				YARATAN_KULLANICI_KODU,
				YARATILDIGI_TARIH)
			   VALUES(
			   pn_musteri_no,
			    inc,
				row_doc.DOKUMAN_KODU,
				'E',
				NULL,
				NULL,
				'CONV',
				pn_date);
	       END LOOP ;
	       CLOSE cur_doc;
COMMIT;
  EXCEPTION
   WHEN OTHERS THEN
      		LOG_AT('Dokuman Hata Bank',sqlcode,sqlerrm);
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '4535' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION  Grup_Kodu_Bul( pn_musteri_no CBS_MUSTERI.musteri_no%TYPE) RETURN VARCHAR2
  IS
    ln_grup_kodu 	NUMBER ;
  BEGIN
  	SELECT DK_GRUP_KOD
	INTO   ln_grup_kodu
	FROM   CBS_MUSTERI
	WHERE  musteri_no = pn_musteri_no ;
	RETURN ln_grup_kodu;
  EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '111' || Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
 PROCEDURE hesap_bakiye_olustur( pn_hesap_no CBS_HESAP_BAKIYE.hesap_no%TYPE,pn_bakiye_karakteri  CBS_HESAP_BAKIYE.bakiye_karakteri%TYPE DEFAULT NULL) IS
  ln_count   NUMBER;
  BEGIN
    SELECT COUNT(*)
	INTO ln_count
	FROM CBS_HESAP_BAKIYE_CONV
	WHERE HESAP_NO = pn_hesap_no;

	IF ln_count = 0 THEN
	 	  INSERT INTO CBS_HESAP_BAKIYE_CONV (hesap_no,bakiye_karakteri,bloke_tutari)
          VALUES  (pn_hesap_no, pn_bakiye_karakteri,0);
	ELSE
	 	  UPDATE CBS_HESAP_BAKIYE_CONV
		  SET bakiye_karakteri = pn_bakiye_karakteri
          	 WHERE HESAP_NO = pn_hesap_no;
    END IF;
    EXCEPTION
	   WHEN OTHERS THEN
	     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '508' || Pkg_Hata.getDelimiter ||TO_CHAR('SQLCODE') || SQLERRM ||Pkg_Hata.getDelimiter|| Pkg_Hata.getUCPOINTER);
  END;



--------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE MOVE_MUSTERI_RETAIL IS

 CURSOR CUR_MUSTERI IS
  SELECT * FROM  CBS_MUSTERI_BIREYSEL_CONV a
   where a.musteri_no not in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no not in (select nvl(c.eski_musteri_no ,-1) from cbs_musteri c) and
		 a.dk_grup_kod is not null;


 CURSOR CUR_MUSTERI2 IS
  SELECT * FROM  CBS_MUSTERI_BIREYSEL_CONV a
   where a.musteri_no  in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no  in (select c.eski_musteri_no from cbs_musteri c) and
		 a.dk_grup_kod is not null AND AKTARILDIMI = 'H'
FOR UPDATE OF AKTARILDIMI ;


  ln_tx_no NUMBER := 0;
  ln_customer   NUMBER := 0;
   musteri_tanimi_eksik EXCEPTION;
  BEGIN
  /*SELECT MIN(musteri_no)
  INTO ln_customer
  FROM  CBS_MUSTERI_BIREYSEL_CONV
  WHERE dk_grup_kod IS NULL ;

 IF NVL(ln_customer,0)  <> 0 THEN
  RAISE musteri_tanimi_eksik;
 END IF;
 */

  FOR C_MUSTERI IN CUR_MUSTERI LOOP
      ln_tx_no := Pkg_Tx.islem_no_al;
  	   INSERT INTO CBS_MUSTERI
	   	  (MUSTERI_NO,
		  DURUM_KODU,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  ARAMA_ISIM,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  LIMIT_REVIZE_TARIHI,
		  LIMIT_REVIZE_TEKLIF_REFERANS,
		  LIMIT_REVIZE_ONAY_TARIHI,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
--sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.DURUM_KODU,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		   decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  C_MUSTERI.ARAMA_ISIM,
		  'CUSTOMER',
		  UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.LIMIT_REVIZE_TARIHI,
		  C_MUSTERI.LIMIT_REVIZE_TEKLIF_REFERANS,
		  C_MUSTERI.LIMIT_REVIZE_ONAY_TARIHI,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU ,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE,
--sevalb 160507
		  c_musteri.vergi_zorunlumu, c_musteri.sosyal_fon_no, c_musteri.ekstre_ucreti_alinsin,
		  c_musteri.working_basis, c_musteri.patent_no, c_musteri.patent_expiry_date, c_musteri.legal_form_code,
		  c_musteri.external_acct_no,
		  c_musteri.lokal_unvan
		   );

		  INSERT INTO CBS_MUSTERI_BASVURU
	   	  (
		  TX_NO,
		  MUSTERI_NO,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
		  --sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (ln_tx_no,
		  C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  C_MUSTERI.FINANS_KOD,
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE ,
		  C_MUSTERI.VERGI_ZORUNLUMU, C_MUSTERI.SOSYAL_FON_NO,
		   C_MUSTERI.EKSTRE_UCRETI_ALINSIN,
		   C_MUSTERI.WORKING_BASIS, C_MUSTERI.PATENT_NO, C_MUSTERI.PATENT_EXPIRY_DATE, C_MUSTERI.LEGAL_FORM_CODE,
		  C_MUSTERI.EXTERNAL_ACCT_NO,
		  c_musteri.LOKAL_UNVAN
		   );


	      Document_Insert_B( C_MUSTERI.MUSTERI_NO,
							   C_MUSTERI.DK_GRUP_KOD,
  							   SYSDATE);

		  MOVE_MUSTERI_ADRES_RETAIL(C_MUSTERI.musteri_no,ln_tx_no);
  		  MOVE_MUSTERI_DOKUMAN_RETAIL(C_MUSTERI.musteri_no,ln_tx_no);

	END LOOP;


	 FOR C_MUSTERI IN CUR_MUSTERI2 LOOP
		  update CBS_MUSTERI_BIREYSEL_CONV a
		  set a.aktarildimi = 'E'
		  where  CURRENT OF CUR_MUSTERI2;
     END LOOP;

	COMMIT;


   EXCEPTION
	  WHEN musteri_tanimi_eksik THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '982' || Pkg_Hata.getDelimiter   || TO_CHAR(ln_customer) ||Pkg_Hata.getUCPOINTER);
  END;
--------------------------------------------------------------------------------------------------------------------------------------------------------
PROCEDURE MOVE_MUSTERI_PRIVENT IS

 CURSOR CUR_MUSTERI IS
  SELECT * FROM  CBS_MUSTERI_PRIVENT_CONV a
   where a.musteri_no not in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no not in (select nvl(c.eski_musteri_no ,-1) from cbs_musteri c) and
		 a.dk_grup_kod is not null AND WORKING_BASIS is NOT null 	;

 CURSOR CUR_MUSTERI2 IS
  SELECT * FROM  CBS_MUSTERI_PRIVENT_CONV a
   where a.musteri_no  in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no  in (select c.eski_musteri_no from cbs_musteri c) and
		 a.dk_grup_kod is not null AND AKTARILDIMI = 'H'
FOR UPDATE OF AKTARILDIMI ;

  ln_tx_no NUMBER := 0;
  ln_customer   NUMBER := 0;
   musteri_tanimi_eksik EXCEPTION;
  BEGIN

  /*SELECT MIN(musteri_no)
  INTO ln_customer
  FROM  CBS_MUSTERI_PRIVENT_CONV
  WHERE dk_grup_kod IS NULL ;

 IF NVL(ln_customer,0)  <> 0 THEN
  RAISE musteri_tanimi_eksik;
 END IF;*/
  FOR C_MUSTERI IN CUR_MUSTERI LOOP
      ln_tx_no := Pkg_Tx.islem_no_al;
  	   INSERT INTO CBS_MUSTERI
	   	  (MUSTERI_NO,
		  DURUM_KODU,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  ARAMA_ISIM,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  LIMIT_REVIZE_TARIHI,
		  LIMIT_REVIZE_TEKLIF_REFERANS,
		  LIMIT_REVIZE_ONAY_TARIHI,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
--sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.DURUM_KODU,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  C_MUSTERI.ARAMA_ISIM,
		  'CUSTOMER',
		  UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.LIMIT_REVIZE_TARIHI,
		  C_MUSTERI.LIMIT_REVIZE_TEKLIF_REFERANS,
		  C_MUSTERI.LIMIT_REVIZE_ONAY_TARIHI,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU ,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE,
--sevalb 160507
		  C_MUSTERI.VERGI_ZORUNLUMU, C_MUSTERI.SOSYAL_FON_NO, C_MUSTERI.EKSTRE_UCRETI_ALINSIN,
		  C_MUSTERI.WORKING_BASIS, C_MUSTERI.PATENT_NO, C_MUSTERI.PATENT_EXPIRY_DATE, C_MUSTERI.LEGAL_FORM_CODE,
		  C_MUSTERI.EXTERNAL_ACCT_NO,
		  c_musteri.LOKAL_UNVAN
		   );

		  INSERT INTO CBS_MUSTERI_BASVURU
	   	  (
		  TX_NO,
		  MUSTERI_NO,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
		  --sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (ln_tx_no,
		  C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE ,
		  C_MUSTERI.VERGI_ZORUNLUMU, C_MUSTERI.SOSYAL_FON_NO,
		   C_MUSTERI.EKSTRE_UCRETI_ALINSIN,
		   C_MUSTERI.WORKING_BASIS, C_MUSTERI.PATENT_NO, C_MUSTERI.PATENT_EXPIRY_DATE, C_MUSTERI.LEGAL_FORM_CODE,
		  C_MUSTERI.EXTERNAL_ACCT_NO,
		  c_musteri.LOKAL_UNVAN
		   );

		   Document_Insert_P( C_MUSTERI.MUSTERI_NO,
		  					 C_MUSTERI.DK_GRUP_KOD,
  							SYSDATE);
		  MOVE_MUSTERI_ADRES_PRIVENT(C_MUSTERI.musteri_no,ln_tx_no);
  		  MOVE_MUSTERI_DOKUMAN_PRIVENT(C_MUSTERI.musteri_no,ln_tx_no);

	END LOOP;

	COMMIT;

 	 FOR C_MUSTERI IN CUR_MUSTERI2 LOOP
		  update CBS_MUSTERI_PRIVENT_CONV a
		  set a.aktarildimi = 'E'
		  where  CURRENT OF CUR_MUSTERI2;
     END LOOP;

	COMMIT;

   EXCEPTION
	  WHEN musteri_tanimi_eksik THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '982' || Pkg_Hata.getDelimiter   || TO_CHAR(ln_customer) ||Pkg_Hata.getUCPOINTER);
  END;
------------------------------
PROCEDURE MOVE_MUSTERI_BANK  IS

 CURSOR CUR_MUSTERI IS
  SELECT * FROM  CBS_MUSTERI_BANKA_CONV a
   where a.musteri_no not in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no not in (select nvl(c.eski_musteri_no ,-1) from cbs_musteri c) and
		 a.dk_grup_kod is not null
  for update of aktarildimi ;

  ln_tx_no NUMBER := 0;
  ln_customer   NUMBER := 0;
   musteri_tanimi_eksik EXCEPTION;
  BEGIN

  /*SELECT MIN(musteri_no)
  INTO ln_customer
  FROM  CBS_MUSTERI_BANKA_CONV
  WHERE dk_grup_kod IS NULL ;

 IF NVL(ln_customer,0)  <> 0 THEN
  RAISE musteri_tanimi_eksik;
 END IF;*/

  FOR C_MUSTERI IN CUR_MUSTERI LOOP
      LN_tx_no := Pkg_Tx.islem_no_al;
  	   INSERT INTO CBS_MUSTERI
	   	  (MUSTERI_NO,
		  DURUM_KODU,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  ARAMA_ISIM,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  LIMIT_REVIZE_TARIHI,
		  LIMIT_REVIZE_TEKLIF_REFERANS,
		  LIMIT_REVIZE_ONAY_TARIHI,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE)
	    VALUES
	     (C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.DURUM_KODU,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  C_MUSTERI.ARAMA_ISIM,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )),
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.LIMIT_REVIZE_TARIHI,
		  C_MUSTERI.LIMIT_REVIZE_TEKLIF_REFERANS,
		  C_MUSTERI.LIMIT_REVIZE_ONAY_TARIHI,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE  );

		  INSERT INTO CBS_MUSTERI_BASVURU
	   	  (
		  TX_NO,
		  MUSTERI_NO,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE)
	    VALUES
	     (ln_tx_no,
		  C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
	  	  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU ,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE );

		   Document_Insert_N( C_MUSTERI.MUSTERI_NO,
		  					 C_MUSTERI.DK_GRUP_KOD,
  							SYSDATE);
		  MOVE_MUSTERI_ADRES_BANK(C_MUSTERI.musteri_no,ln_tx_no);
  		  MOVE_MUSTERI_DOKUMAN_BANK(C_MUSTERI.musteri_no,ln_tx_no);



		  update CBS_MUSTERI_BANKA_CONV
		  set aktarildimi = 'E'
		  where current of cur_musteri;


	END LOOP;
	COMMIT;

   EXCEPTION
	  WHEN musteri_tanimi_eksik THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '982' || Pkg_Hata.getDelimiter   || TO_CHAR(ln_customer) ||Pkg_Hata.getUCPOINTER);
  END;
 ------------------------------
PROCEDURE MOVE_MUSTERI_CORPORATE IS
  CURSOR CUR_MUSTERI IS
  SELECT * FROM  CBS_MUSTERI_KURUMSAL_CONV a
   where a.musteri_no not in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no not in (select nvl(c.eski_musteri_no ,-1) from cbs_musteri c) and
		 a.dk_grup_kod is not null;
  --for update of aktarildimi ;
 CURSOR CUR_MUSTERI2 IS
  SELECT * FROM  CBS_MUSTERI_KURUMSAL_CONV a
   where a.musteri_no  in (select b.musteri_no from cbs_musteri b) and
   		 a.eski_musteri_no  in (select c.eski_musteri_no from cbs_musteri c) and
		 a.dk_grup_kod is not null AND AKTARILDIMI = 'H'
FOR UPDATE OF AKTARILDIMI ;

  ln_tx_no NUMBER := 0;
  ln_customer   NUMBER := 0;
   musteri_tanimi_eksik EXCEPTION;
  BEGIN

  /*SELECT MIN(musteri_no)
  INTO ln_customer
  FROM  CBS_MUSTERI_KURUMSAL_CONV
  WHERE dk_grup_kod IS NULL ;

 IF NVL(ln_customer,0)  <> 0 THEN
  RAISE musteri_tanimi_eksik;
 END IF;*/
  FOR C_MUSTERI IN CUR_MUSTERI LOOP
      LN_tx_no := Pkg_Tx.islem_no_al;
  	   INSERT INTO CBS_MUSTERI
	   	  (MUSTERI_NO,
		  DURUM_KODU,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  ARAMA_ISIM,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  LIMIT_REVIZE_TARIHI,
		  LIMIT_REVIZE_TEKLIF_REFERANS,
		  LIMIT_REVIZE_ONAY_TARIHI,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
		  MANAGER_NAME, MANAGER_SURNAME, MANAGER_PATRONYMIC_NAME,
		  MANAGER_COUNTRY_CODE, MANAGER_RESIDENT_CODE,
		  --sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.DURUM_KODU,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		   decode(C_MUSTERI.FINANS_KOD,'0','24',C_MUSTERI.FINANS_KOD),
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  C_MUSTERI.ARAMA_ISIM,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )) ,
		  'GENERAL',
		  C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.LIMIT_REVIZE_TARIHI,
		  C_MUSTERI.LIMIT_REVIZE_TEKLIF_REFERANS,
		  C_MUSTERI.LIMIT_REVIZE_ONAY_TARIHI,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU,
		  C_MUSTERI.VAT_SERI_NO, C_MUSTERI.VAT_SIRA_NO, C_MUSTERI.OKPO_CODE,
		  C_MUSTERI.MANAGER_NAME, C_MUSTERI.MANAGER_SURNAME,
		  C_MUSTERI.MANAGER_PATRONYMIC_NAME,
		  C_MUSTERI.MANAGER_COUNTRY_CODE,
		  C_MUSTERI. MANAGER_RESIDENT_CODE,
		  --sevalb 160507
		  C_MUSTERI.VERGI_ZORUNLUMU, C_MUSTERI.SOSYAL_FON_NO, C_MUSTERI.EKSTRE_UCRETI_ALINSIN,
		 C_MUSTERI.WORKING_BASIS, C_MUSTERI.PATENT_NO, C_MUSTERI.PATENT_EXPIRY_DATE, C_MUSTERI.LEGAL_FORM_CODE,
		 C_MUSTERI.EXTERNAL_ACCT_NO	,
		 c_musteri.LOKAL_UNVAN
		    );

		  INSERT INTO CBS_MUSTERI_BASVURU
	   	  (
		  TX_NO,
		  MUSTERI_NO,
		  MUSTERI_TIPI_KOD,
		  DK_GRUP_KOD,
		  ISIM,
		  IKINCI_ISIM,
		  SOYADI,
		  DOGUM_TARIHI,
		  DOGUM_YERI,
		  DOGUM_IL_KOD,
		  CINSIYET_KOD,
		  BABA_ADI,
		  ANNE_ADI,
		  ANNE_KIZLIK_SOYADI,
		  MESLEK_KOD,
		  EGITIM_KOD,
		  MEDENI_HAL_KOD,
		  TICARI_UNVAN,
		  HESAP_UCRETI_F,
		  CEK_KARNESI_F,
		  PERSONEL_SICIL_NO,
		  YERLESIM_KOD,
		  OZEL_KATEGORI_KOD,
		  VERGI_MUAF_KOD,
		  VERGI_DAIRESI_ADI,
		  VERGI_NO,
		  TESVIK_KOD,
		  UYRUK_KOD,
		  KIMLIK_KOD,
		  TC_KIMLIK_NO,
		  NUFUS_CUZDANI_SERI_NO,
		  PASAPORT_NO,
		  EHLIYET_BELGE_NO,
		  IL_KOD,
		  ILCE_KOD,
		  MAHALLE_KOY,
		  CILT_NO,
		  AILE_SIRA_NO,
		  SIRA_NO,
		  VERILDIGI_YER,
		  VERILDIGI_TARIH,
		  SEKTOR_KOD,
		  FINANS_KOD,
		  TICARI_SICIL_NO,
		  EXTRE_ADRES_KOD,
		  SERBEST_BOLGE_IZIN_TARIHI,
		  SERBEST_BOLGE_IZIN_NO,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  GRUP_KOD,
		  BIC_KOD,
		  SWIFT_MESAJ_KOD,
		  REUTERS_INFO_PAGE,
		  REUTERS_DEALING_KOD,
		  YARATAN_KULLANICI_KODU,
		  YARATILDIGI_TARIH,
		  MODUL_TUR_KOD,
		  URUN_TUR_KOD,
		  URUN_SINIF_KOD,
		  RATING_KODU,
		  ESKI_MUSTERI_NO,
		  SEKTOR_ALT1_KODU,
		  SEKTOR_ALT2_KODU,
		  BOLUM_KODU,
		  GECERLILIK_TARIHI,
		  VERGI_DAIRE_KODU,
  		  VAT_SERI_NO, VAT_SIRA_NO, OKPO_CODE,
		  MANAGER_NAME, MANAGER_SURNAME, MANAGER_PATRONYMIC_NAME,
		  MANAGER_COUNTRY_CODE, MANAGER_RESIDENT_CODE,
		  --sevalb 160507
		 VERGI_ZORUNLUMU, SOSYAL_FON_NO, EKSTRE_UCRETI_ALINSIN,
		 WORKING_BASIS, PATENT_NO, PATENT_EXPIRY_DATE, LEGAL_FORM_CODE,
		 EXTERNAL_ACCT_NO,
		 LOKAL_UNVAN
		  )
	    VALUES
	     (ln_tx_no,
		  C_MUSTERI.MUSTERI_NO,
		  C_MUSTERI.MUSTERI_TIPI_KOD,
		  C_MUSTERI.DK_GRUP_KOD,
		  C_MUSTERI.ISIM,
		  C_MUSTERI.IKINCI_ISIM,
		  C_MUSTERI.SOYADI,
		  C_MUSTERI.DOGUM_TARIHI,
		  C_MUSTERI.DOGUM_YERI,
		  C_MUSTERI.DOGUM_IL_KOD,
		  C_MUSTERI.CINSIYET_KOD,
		  C_MUSTERI.BABA_ADI,
		  C_MUSTERI.ANNE_ADI,
		  C_MUSTERI.ANNE_KIZLIK_SOYADI,
		  C_MUSTERI.MESLEK_KOD,
		  C_MUSTERI.EGITIM_KOD,
		  C_MUSTERI.MEDENI_HAL_KOD,
		  C_MUSTERI.TICARI_UNVAN,
		  C_MUSTERI.HESAP_UCRETI_F,
		  C_MUSTERI.CEK_KARNESI_F,
		  C_MUSTERI.PERSONEL_SICIL_NO,
		  C_MUSTERI.YERLESIM_KOD,
		  C_MUSTERI.OZEL_KATEGORI_KOD,
		  C_MUSTERI.VERGI_MUAF_KOD,
		  C_MUSTERI.VERGI_DAIRESI_ADI,
		  C_MUSTERI.VERGI_NO,
		  C_MUSTERI.TESVIK_KOD,
		  C_MUSTERI.UYRUK_KOD,
		  C_MUSTERI.KIMLIK_KOD,
		  C_MUSTERI.TC_KIMLIK_NO,
		  C_MUSTERI.NUFUS_CUZDANI_SERI_NO,
		  C_MUSTERI.PASAPORT_NO,
		  C_MUSTERI.EHLIYET_BELGE_NO,
		  C_MUSTERI.IL_KOD,
		  C_MUSTERI.ILCE_KOD,
		  C_MUSTERI.MAHALLE_KOY,
		  C_MUSTERI.CILT_NO,
		  C_MUSTERI.AILE_SIRA_NO,
		  C_MUSTERI.SIRA_NO,
		  C_MUSTERI.VERILDIGI_YER,
		  C_MUSTERI.VERILDIGI_TARIH,
		  C_MUSTERI.SEKTOR_KOD,
		  C_MUSTERI.FINANS_KOD,
    	  C_MUSTERI.TICARI_SICIL_NO,
		  C_MUSTERI.EXTRE_ADRES_KOD,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_TARIHI,
		  C_MUSTERI.SERBEST_BOLGE_IZIN_NO,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_1,
		  C_MUSTERI.PAZARLAMA_SORUMLUSU_SICIL_NO_2,
		  C_MUSTERI.GRUP_KOD,
		  C_MUSTERI.BIC_KOD,
		  C_MUSTERI.SWIFT_MESAJ_KOD,
		  C_MUSTERI.REUTERS_INFO_PAGE,
		  C_MUSTERI.REUTERS_DEALING_KOD,
		  C_MUSTERI.YARATAN_KULLANICI_KODU,
		  C_MUSTERI.YARATILDIGI_TARIH,
		  'CUSTOMER',
	      UPPER ( pkg_musteri.sf_musteri_urun_tur_al(c_musteri.MUSTERI_TIPI_KOD )),
		  'GENERAL',
		    C_MUSTERI.RATING_KODU,
		  C_MUSTERI.ESKI_MUSTERI_NO,
		  C_MUSTERI.SEKTOR_ALT1_KODU,
		  C_MUSTERI.SEKTOR_ALT2_KODU,
		  C_MUSTERI.BOLUM_KODU,
		  C_MUSTERI.GECERLILIK_TARIHI,
		  C_MUSTERI.VERGI_DAIRE_KODU,
		  C_MUSTERI.VAT_SERI_NO,
		  C_MUSTERI.VAT_SIRA_NO,
		  C_MUSTERI.OKPO_CODE,
		  C_MUSTERI.MANAGER_NAME,
		  C_MUSTERI.MANAGER_SURNAME,
		  C_MUSTERI.MANAGER_PATRONYMIC_NAME,
		  C_MUSTERI.MANAGER_COUNTRY_CODE,
		  C_MUSTERI.MANAGER_RESIDENT_CODE,
		  --sevalb 160507
		  C_MUSTERI.VERGI_ZORUNLUMU, C_MUSTERI.SOSYAL_FON_NO, C_MUSTERI.EKSTRE_UCRETI_ALINSIN,
		 C_MUSTERI.WORKING_BASIS, C_MUSTERI.PATENT_NO, C_MUSTERI.PATENT_EXPIRY_DATE, C_MUSTERI.LEGAL_FORM_CODE,
		 C_MUSTERI.EXTERNAL_ACCT_NO,
		 c_musteri.LOKAL_UNVAN

		   );

		  Document_Insert_K( C_MUSTERI.MUSTERI_NO,
		  					 C_MUSTERI.DK_GRUP_KOD,
  							SYSDATE);
		  MOVE_MUSTERI_ADRES_CORPORATE(C_MUSTERI.musteri_no,ln_tx_no);
  		  MOVE_MUSTERI_DOKUMAN_CORPORATE(C_MUSTERI.musteri_no,ln_tx_no);

	END LOOP;

	 FOR C_MUSTERI IN CUR_MUSTERI2 LOOP
		  update CBS_MUSTERI_KURUMSAL_CONV a
		  set a.aktarildimi = 'E'
		  where  CURRENT OF CUR_MUSTERI2;
     END LOOP;

	COMMIT;
  COMMIT;

   EXCEPTION
	  WHEN musteri_tanimi_eksik THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '982' || Pkg_Hata.getDelimiter   || TO_CHAR(ln_customer) ||Pkg_Hata.getUCPOINTER);
END;
------------------------------
PROCEDURE MOVE_MUSTERI_ADRES_RETAIL(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_ADRES
	   (MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_B
	   WHERE musteri_no =pn_musteri_no ;


	   INSERT INTO CBS_MUSTERI_BASVURU_ADRES
	   (tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    pn_tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_B
	   WHERE musteri_no =pn_musteri_no ;

  END;
------------------------------

PROCEDURE MOVE_MUSTERI_ADRES_PRIVENT(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_ADRES
	   (MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_p
	   WHERE musteri_no =pn_musteri_no ;


	   INSERT INTO CBS_MUSTERI_BASVURU_ADRES
	   (tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    pn_tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_P
	   WHERE musteri_no =pn_musteri_no ;

  END;
------------------------------
PROCEDURE MOVE_MUSTERI_ADRES_BANK (pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_ADRES
	   (MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	   SELECT
	    MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_N
   	   WHERE musteri_no =pn_musteri_no ;

	    INSERT INTO CBS_MUSTERI_BASVURU_ADRES
	   (tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    pn_tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_N
	   WHERE musteri_no =pn_musteri_no ;

  END;
------------------------------
PROCEDURE MOVE_MUSTERI_ADRES_CORPORATE(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_ADRES
	   (MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	   SELECT
	    MUSTERI_NO,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		SUBSTR(TEL_ALAN_KOD,1,10),
		TEL_NO,
		SUBSTR(GSM_ALAN_KOD,1,10),
		GSM_NO,
		SUBSTR(FAX_ALAN_KOD,1,10),
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	 FROM CBS_MUSTERI_ADRES_CONV_K
 	   WHERE musteri_no =pn_musteri_no ;

	  INSERT INTO CBS_MUSTERI_BASVURU_ADRES
	   (tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		TEL_ALAN_KOD,
		TEL_NO,
		GSM_ALAN_KOD,
		GSM_NO,
		FAX_ALAN_KOD,
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F)
	  SELECT
	    pn_tx_no,
	    ADRES_KOD,
	    ADRES, SEMT,
	    IL_KOD,
		POSTA_KOD,
		ULKE_KOD,
		EMAIL,
		SUBSTR(TEL_ALAN_KOD,1,10),
		TEL_NO,
		SUBSTR(GSM_ALAN_KOD,1,10),
		GSM_NO,
		SUBSTR(FAX_ALAN_KOD,1,10),
		FAX_NO,
		ILK_GECERLILIK_TARIHI,
		SON_GECERLILIK_TARIHI,
		ILCE_KOD,
		YARATAN_KULLANICI_KODU,
		YARATILDIGI_TARIH,
		EXTRE_ADRES_KOD_F
	   FROM CBS_MUSTERI_ADRES_CONV_K
	   WHERE musteri_no =pn_musteri_no ;

  END;
------------------------------
PROCEDURE MOVE_MUSTERI_DOKUMAN_RETAIL(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_DOKUMAN
	  (MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_B
   	   WHERE musteri_no =pn_musteri_no ;

	   INSERT INTO CBS_MUSTERI_BASVURU_DOKUMAN
	  (TX_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   pn_tx_no,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_B
   	   WHERE musteri_no =pn_musteri_no ;
  END;
------------------------------
PROCEDURE MOVE_MUSTERI_DOKUMAN_PRIVENT(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_DOKUMAN
	  (MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_P
   	   WHERE musteri_no =pn_musteri_no ;

	   INSERT INTO CBS_MUSTERI_BASVURU_DOKUMAN
	  (TX_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   pn_tx_no,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_P
   	   WHERE musteri_no =pn_musteri_no ;
  END;
------------------------------
PROCEDURE MOVE_MUSTERI_DOKUMAN_BANK (pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_DOKUMAN
	  (MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_N
	   WHERE musteri_no =pn_musteri_no ;


	   INSERT INTO CBS_MUSTERI_BASVURU_DOKUMAN
	  (TX_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   pn_tx_no,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_N
   	   WHERE musteri_no =pn_musteri_no ;
  END;
------------------------------
PROCEDURE MOVE_MUSTERI_DOKUMAN_CORPORATE(pn_musteri_no NUMBER ,pn_tx_no NUMBER) IS
  BEGIN
  	   INSERT INTO CBS_MUSTERI_DOKUMAN
	  (MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   MUSTERI_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_K
	   WHERE musteri_no =pn_musteri_no ;

	   INSERT INTO CBS_MUSTERI_BASVURU_DOKUMAN
	  (TX_NO,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH)
	   SELECT
	   pn_tx_no,
	   SIRA_NO,
	   DOKUMAN_ADI,
	   ALINDI_KUTUSU_F,
	   DUZENLENME_TARIHI,
	   GECERLILIK_TARIHI,
	   YARATAN_KULLANICI_KODU,
	   YARATILDIGI_TARIH
	   FROM CBS_MUSTERI_DOKUMAN_CONV_K
   	   WHERE musteri_no =pn_musteri_no ;

  END;


------------------------------
PROCEDURE sp_insert_vadesiz_hatamesaj(pn_hesap_no	number,
									  pn_musteri_no number,
									  ps_hata_kodu	varchar2,
									  ps_hata_mesaj	VARCHAR2) IS
PRAGMA autonomous_transaction;
 BEGIN
   insert into cbs_conv_vadesiz_hatali(HESAP_NO, MUSTERI_NO, HATA_KODU, HATA_MESAJ)
   VALUES (pn_hesap_no,pn_musteri_no,ps_hata_kodu,ps_hata_mesaj);

   COMMIT;
 END;
-----------------------------------------------
PROCEDURE sp_insert_vadeli_hatamesaj(pn_hesap_no		number,
									 pn_musteri_no   number,
									 ps_hata_kodu	varchar2,
									 ps_hata_mesaj	VARCHAR2) IS
PRAGMA autonomous_transaction;
 BEGIN
   insert into cbs_conv_vadeli_hatali(HESAP_NO, MUSTERI_NO, HATA_KODU, HATA_MESAJ)
   VALUES (pn_hesap_no,pn_musteri_no,ps_hata_kodu,ps_hata_mesaj);

   COMMIT;
 END;
-----------------------------------------------
PROCEDURE sp_insert_kredi_hatamesaj(pn_hesap_no		number,
									 pn_musteri_no   number,
									 ps_hata_kodu	varchar2,
									 ps_hata_mesaj	VARCHAR2) IS
PRAGMA autonomous_transaction;
 BEGIN
   insert into cbs_conv_kredi_hatali(HESAP_NO, MUSTERI_NO, HATA_KODU, HATA_MESAJ)
   VALUES (pn_hesap_no,pn_musteri_no,ps_hata_kodu,ps_hata_mesaj);

   COMMIT;
 END;
-----------------------------------------------
Function  yeni_hesapno_bul(ps_CA_CANO varchar2,ps_cr_refno  varchar2 , ps_cylecode varchar2) return number
is
	ln_hesap_no  number;
	ln_cnt		  number;
Begin
	if ps_CA_CANO is not null
	then
		select count(*)
		into ln_cnt
		from cbs_vw_hesap_izleme
		where SUBE_KODU = substr(ps_CA_CANO,1,3) and
		 	   ESKI_HESAP_NO = to_number(substr(ps_CA_CANO,4,10)) and
			   ESKI_HESAP_EKNO = substr(ps_CA_CANO,14,3) and
			   trim(nvl(ESKI_HESAP_REFNO,'X')) = trim(nvl(ps_cr_refno ,'X')) and
			   doviz_kodu = decode(nvl(ps_cylecode,'PP'), 'PP', doviz_kodu, dvz(ps_cylecode));

		if ln_cnt = 1
		then
			select hesap_no
			into ln_hesap_no
			from cbs_vw_hesap_izleme
			where SUBE_KODU = substr(ps_CA_CANO,1,3) and
			 	   ESKI_HESAP_NO = to_number(substr(ps_CA_CANO,4,10)) and
				   ESKI_HESAP_EKNO = substr(ps_CA_CANO,14,3) and
				   trim(nvl(ESKI_HESAP_REFNO,'X')) = trim(nvl(ps_cr_refno ,'X')) and
				   doviz_kodu = decode(nvl(ps_cylecode,'PP'), 'PP', doviz_kodu, dvz(ps_cylecode));
		else
		 	 ln_hesap_no := null;
		end if;
	end if;
	return ln_hesap_no ;
End  ;

----------------------------------------------
-- sevalb 120405 conv sorasi urun degisimi yap?l?rsa, musteri_dk_no guncellemesi gerekecektir.
--Bu ama?la kullanilmak uzere hazirlandi
 ----------------------------------------------
 Procedure HESAP_MUSTERIDKNO_GUNCELLE(pn_hesap_no number default null)
 is
   cursor cur_hesap is
   		  select *
		  from cbs_vw_hesap_izleme
		  where hesap_no = nvl(pn_hesap_no,hesap_no);
	   lv_modul_tur_kod 		   VARCHAR2(200);
	   lv_urun_tur_kod 			   VARCHAR2(200);
	   lv_urun_sinif_kod 		   VARCHAR2(200);
	   lv_musteri_dkno			   VARCHAR2(200);
	   lv_doviz_kod 			   VARCHAR2(200);
	   ls_dkgrup_kodu 			   VARCHAR2(200);
	   ls_bolum_kodu  			   VARCHAR2(200);
  Begin
  	   for c_hesap in cur_hesap loop
	       ls_dkgrup_kodu 	  := pkg_musteri.sf_musteri_dk_grup_kod_al( c_hesap.musteri_no);
	 	   lv_modul_tur_kod   := c_hesap.modul_tur_kod;
		   lv_urun_tur_kod 	  := c_hesap.urun_tur_kod ;
		   lv_urun_sinif_kod  := c_hesap.urun_sinif_kod ;
		   ls_bolum_kodu 	  := c_hesap.sube_kodu;
		   lv_doviz_kod := c_hesap.doviz_kodu ;

	   	   Pkg_Muhasebe.DK_BUL( ls_dkgrup_kodu, lv_modul_tur_kod, lv_urun_tur_kod,lv_urun_sinif_kod, 1, NULL, NULL, NULL, lv_musteri_dkno);

	    if c_hesap.modul_tur_kod = pkg_hesap.modul_tur_vadesiz then
		   update cbs_hesap
		   set musteri_dk_no = lv_musteri_dkno
		   where hesap_no = c_hesap.hesap_no ;
		elsif c_hesap.modul_tur_kod = pkg_hesap.modul_tur_vadeli then
	   	   update cbs_hesap_vadeli
		   set musteri_dk_no = lv_musteri_dkno
		   where hesap_no = c_hesap.hesap_no ;
		elsif c_hesap.modul_tur_kod = pkg_kredi.modul_tur_kod then
	   	   update cbs_hesap_kredi
		   set musteri_dk_no = lv_musteri_dkno
		   where hesap_no = c_hesap.hesap_no ;
		 else
		 	 raise no_data_found;
	   	 end if;
	   end loop;
  End;
------------------------------
PROCEDURE MOVE_HESAP_VADESIZ(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
	CURSOR Cur_hesap_upd IS
		SELECT *
		FROM CBS_HESAP_CONV a 
		where  not exists  (select 1 from cbs_hesap b
			   		   	where a.sube_kodu = b.sube_kodu and
							  a.eski_hesap_no = b.eski_hesap_no and 
							  a.eski_hesap_ekno = b.eski_hesap_ekno and
							  a.doviz_kodu = b.doviz_kodu ) 									   	   
			  and eski_hesap_no is not null and eski_hesap_ekno is not null 
			  and musteri_no  in (select musteri_no from cbs_musteri) -- musterisi tanimli olmayan atilmamasi istenirse acilmali
			  AND eski_hesap_ekno NOT IN ( 284,793)
 			  for update of URUN_SINIF_KOD, URUN_TUR_KOD;
--sevalb 010607 asagidaki kisim kapatildi.			  	 
	/*	SELECT *
		FROM CBS_HESAP_CONV
		where (sube_kodu,eski_hesap_no,eski_hesap_ekno ,doviz_kodu ) not in
			(select sube_kodu,eski_hesap_no,eski_hesap_ekno ,doviz_kodu
			from cbs_hesap
			where eski_hesap_no is not null and eski_hesap_ekno is not null)
			and  musteri_no  in (select musteri_no from cbs_musteri) -- musterisi tanimli olmayan atilmamasi istenirse acilmali
			AND eski_hesap_ekno NOT IN ( 284,793)	 --Atilmamasi gereken suffixler
			and hesap_no not in (select hesap_no from cbs_conv_vadesiz_hatali)
		for update of URUN_SINIF_KOD, URUN_TUR_KOD;
		*/

	CURSOR Cur_HESAP IS
		SELECT *
		FROM CBS_HESAP_CONV a 
		where  not exists  (select 1 from cbs_hesap b
			   		   	where a.sube_kodu = b.sube_kodu and
							  a.eski_hesap_no = b.eski_hesap_no and 
							  a.eski_hesap_ekno = b.eski_hesap_ekno and
							  a.doviz_kodu = b.doviz_kodu ) 									   	   
			  and eski_hesap_no is not null and eski_hesap_ekno is not null 
			  and musteri_no  in (select musteri_no from cbs_musteri) -- musterisi tanimli olmayan atilmamasi istenirse acilmali
			  AND eski_hesap_ekno NOT IN ( 284,793)
			for update of aktarildi ;
	/*	SELECT *
		FROM CBS_HESAP_CONV
		where (sube_kodu,eski_hesap_no,eski_hesap_ekno,doviz_kodu ) not in
			(select sube_kodu,eski_hesap_no,eski_hesap_ekno,doviz_kodu
			from cbs_hesap
			where eski_hesap_no is not null and eski_hesap_ekno is not null)
			and  musteri_no  in (select musteri_no from cbs_musteri) -- musterisi tanimli olmayan atilmamasi istenirse acilmali
			AND eski_hesap_ekno NOT IN ( 284,793) --Atilmamasi gereken suffixler
			and hesap_no not in (select hesap_no from cbs_conv_vadesiz_hatali)
		for update of aktarildi ;
		*/
	ls_bakiye_karakteri  		   VARCHAR2(1);
	ln_islem_no  				   NUMBER;
	hesap_tanimi_eksik 		   EXCEPTION;
	ln_hesap_no 				   NUMBER := 0;
	ls_bolum_kodu				   VARCHAR2(200);
	ls_dkgrup_kodu 			   VARCHAR2(200);
	lv_modul_tur_kod 			   VARCHAR2(200);
	lv_urun_tur_kod 			   VARCHAR2(200);
	lv_urun_sinif_kod 		   VARCHAR2(200);
	lv_musteri_dkno			   VARCHAR2(200);
	lv_doviz_kod 				   VARCHAR2(200);

	hatali_kayit_var				  exception;
	ln_adet						  number := 0;
	ls_overdraft				  varchar(1);
	lv_ovd_dkno					  varchar2(200);
BEGIN
	Pkg_Baglam.batch;

	delete from cbs_conv_vadesiz_hatali;

	COMMIT;
	log_At('vadesiz cov. basladi');	
	for c_hesap in cur_hesap_upd
	loop
		begin
			begin
				select modul_tur_kod, trim(URUN_TUR_KOD), trim(URUN_SINIF_KOD)
				into  lv_modul_tur_kod,lv_urun_tur_kod ,  lv_urun_sinif_kod
				from  cbs_conv_urun_ekno
				where ESKI_HESAP_EKNO = c_hesap.ESKI_HESAP_EKNO
				and ((c_hesap.doviz_kodu =pkg_genel.lc_al and  urun_sinif_kod like '%LC%' ) or
				(c_hesap.doviz_kodu <> pkg_genel.lc_al and  urun_sinif_kod like '%FC%' ) ) ;
				exception
					when others then
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,
												c_hesap.musteri_no,
												99,
												Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '961' || Pkg_Hata.getDelimiter ||c_hesap.ESKI_HESAP_EKNO ||  Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER));
			end;

			if  lv_urun_tur_kod is null or  lv_urun_sinif_kod is null
			then
				sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,98,Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER ||'961'||Pkg_Hata.getDelimiter||c_hesap.ESKI_HESAP_EKNO||Pkg_Hata.getDelimiter||Pkg_Hata.getUCPOINTER));
			else
				begin
					select dk_grup_kod
					into ls_dkgrup_kodu
					from cbs_musteri
					where musteri_no = c_hesap.musteri_no;
					exception when others then					
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,
					c_hesap.musteri_no,
					1,
					Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '962' || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER));
				end ;
				if  ls_dkgrup_kodu is null
				then
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,2,	 Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '962' || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER));
				else
					begin
						Pkg_Muhasebe.DK_BUL(ls_dkgrup_kodu,
											lv_modul_tur_kod,
											lv_urun_tur_kod,
											lv_urun_sinif_kod,
											1,
											NULL,
											NULL,
											NULL,
											lv_musteri_dkno);
						exception
							when others  then
							sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,3,	 Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '1704' || Pkg_Hata.getDelimiter || ls_dkgrup_kodu || Pkg_Hata.getDelimiter|| lv_modul_tur_kod || Pkg_Hata.getDelimiter || lv_urun_tur_kod || Pkg_Hata.getDelimiter ||lv_urun_sinif_kod || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER));
					end ;
				end if;
				if  lv_musteri_dkno is null
				then
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,4,	 Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '1704' || Pkg_Hata.getDelimiter || ls_dkgrup_kodu || Pkg_Hata.getDelimiter|| lv_modul_tur_kod || Pkg_Hata.getDelimiter || lv_urun_tur_kod || Pkg_Hata.getDelimiter ||lv_urun_sinif_kod || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER));
				else
					update cbs_hesap_conv
					set urun_tur_kod =   lv_urun_tur_kod,
					urun_sinif_kod = lv_urun_sinif_kod,
					musteri_dk_no  = lv_musteri_dkno
					where current of cur_hesap_upd;
					
				
				end if;
			end if;
			
			exception
			when others then 
				rollback; 
			sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,5,	 Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '963' ||Pkg_Hata.getDelimiter || TO_CHAR('SQLCODE') || SQLERRM || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER));
		end;
	end loop;

	commit;
	log_At('gusin kontrol basladi');
	--2. tum hesaplar?n gusin ve ilgili dk tanimlamalari yapilmis olmali.
	For c_hesap in cur_hesap
	loop
		ls_dkgrup_kodu 	  := pkg_musteri.sf_musteri_dk_grup_kod_al( c_hesap.musteri_no);
		lv_modul_tur_kod   := c_hesap.modul_tur_kod;
		lv_urun_tur_kod 	  := c_hesap.urun_tur_kod ;
		lv_urun_sinif_kod  := c_hesap.urun_sinif_kod ;
		ls_bolum_kodu 	  := c_hesap.sube_kodu;
		lv_doviz_kod 	  := c_hesap.doviz_kodu ;

		if  c_hesap.musteri_dk_no is null or
			ls_dkgrup_kodu is null or
			lv_modul_tur_kod is null or
			lv_urun_tur_kod  is null or
			lv_urun_sinif_kod  is null
		then
			sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,6,	 Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER || '983' || Pkg_Hata.getDelimiter   || TO_CHAR(ln_hesap_no) ||' '|| ls_dkgrup_kodu ||' ' || lv_modul_tur_kod ||' ' || lv_urun_tur_kod ||' ' ||lv_urun_sinif_kod||Pkg_Hata.getUCPOINTER));
		else
			if lv_urun_sinif_kod not in ('NON INT.BEARING-LC','NON INT.BEARING-FC')
			   AND
	   		   lv_urun_tur_kod not in ('CURRENT')
			then
				Pkg_Muhasebe.DK_BUL(ls_dkgrup_kodu,
									lv_modul_tur_kod,
									lv_urun_tur_kod,
									lv_urun_sinif_kod,
									3,
									NULL,
									NULL,
									NULL,
									lv_musteri_dkno);
				--faiz
				IF NOT Pkg_Hesap.GECERLIDKHESAP(lv_musteri_dkno,ls_bolum_kodu,Pkg_Genel.LC_AL)
				THEN
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,
												c_hesap.musteri_no,7,
												Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER ||'2040'||Pkg_Hata.getDelimiter||lv_musteri_dkno||'-'||ls_dkgrup_kodu||'-'||lv_modul_tur_kod||'-'||lv_urun_tur_kod||'-'||lv_urun_sinif_kod||Pkg_Hata.getDelimiter||Pkg_Genel.lc_al||Pkg_Hata.getUCPOINTER));
				END IF;
			end if;

--SEVALB 010607 
		if lv_urun_tur_kod  = 'DEMAND DEP' and lv_urun_sinif_kod in ('INTEREST BEARING-FC','INTEREST BEARING-LC' ) then 			
--			if lv_urun_sinif_kod not in ('NON INT.BEARING-LC','NON INT.BEARING-FC')
--			   AND
--	   		   lv_urun_tur_kod not in ('DEMAND DEP')
				--4-reeskont DK
				Pkg_Muhasebe.DK_BUL(ls_dkgrup_kodu,
									lv_modul_tur_kod,
									lv_urun_tur_kod,
									lv_urun_sinif_kod,
									4,
									NULL,
									NULL,
									NULL,
									lv_musteri_dkno);

				if not pkg_hesap.gecerlidkhesap(lv_musteri_dkno,ls_bolum_kodu,lv_doviz_kod )
				then
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,
												c_hesap.musteri_no,
												8,
												Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER ||'2040'||Pkg_Hata.getDelimiter||lv_musteri_dkno||'-'||ls_dkgrup_kodu||'-'||lv_modul_tur_kod||'-'||lv_urun_tur_kod||'-'||lv_urun_sinif_kod||Pkg_Hata.getDelimiter||Pkg_Genel.lc_al||Pkg_Hata.getUCPOINTER));
				end if;
			end if;


--sevalb 310507

			if lv_urun_tur_kod in ('DEMAND DEP')
			then
				--9-OVERDRAFT DK
				Pkg_Muhasebe.DK_BUL(ls_dkgrup_kodu,
									lv_modul_tur_kod,
									lv_urun_tur_kod,
									lv_urun_sinif_kod,
									9,
									NULL,
									NULL,
									NULL,
									lv_ovd_dkno);

				if not pkg_hesap.gecerlidkhesap(lv_ovd_dkno,ls_bolum_kodu,lv_doviz_kod ) or lv_ovd_dkno is null
				then
					sp_insert_vadesiz_hatamesaj(c_hesap.hesap_no,
												c_hesap.musteri_no,
												9,
												Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER ||'2040'||Pkg_Hata.getDelimiter||lv_ovd_dkno||'-'||ls_dkgrup_kodu||'-'||lv_modul_tur_kod||'-'||lv_urun_tur_kod||'-'||lv_urun_sinif_kod||Pkg_Hata.getDelimiter||Pkg_Genel.lc_al||Pkg_Hata.getUCPOINTER));
				end if;
			end if;


		end if;
	End Loop;

	log_At('vadesiz hesap atma basladi');	
	FOR C_HESAP IN CUR_HESAP
	LOOP
		ln_islem_no :=Pkg_Batch.Islem_Yarat(1399,C_hesap.sube_kodu);
		log_At('hesap basladi',c_hesap.hesap_no);
		ls_overdraft := null;

		if C_HESAP.URUN_TUR_KOD in ('DEMAND DEP','CURRENT')
		then
			ls_overdraft := 'H';
		end if;

		INSERT INTO CBS_HESAP
		(HESAP_NO,
		MUSTERI_NO,
		URUN_TUR_KOD,
		KISA_ISIM,
		DOVIZ_KODU,
		TUTAR,
		BORC_KAYDI,
		BORCLU_HESAP_NO,
		MUHABIR_HESAP_NO,
		DK_NO,
		CEK_KARNESI,
		HESAP_HAREKET_KODU,
		MIN_PARA_TUTARI,
		ACIKLAMA,
		ESAS_GUN_SAYISI,
		FAIZ_ORANI,
		FAIZ_INDIKATORU,
		BAKIYE_TURU,
		MIN_FAIZ_TUTARI,
		EKSTRE_BASIM_KODU,
		EKSTRE_SIKLIGI,
		DEKONT,
		DURUM_KODU,
		SUBE_KODU,
		URUN_SINIF_KOD,
		MODUL_TUR_KOD,
		ACILIS_TARIHI,
		BIRIKMIS_FAIZ_NEG,
		BIRIKMIS_FAIZ_POZ,
		ODENMIS_FAIZ_TOPLAMI,
		MUSTERI_DK_NO,
		MIN_IMZA_ADEDI,
		REPO_BLOKE_TUTARI,
		KAPAMA_TARIHI,
		ESKI_HESAP_NO,
		ESKI_HESAP_EKNO,
		BIRIKMIS_FAIZ_NEG_ROUND,
		BIRIKMIS_FAIZ_POZ_ROUND,
		AYS_BIRIKMIS_FAIZ_POZ_ROUND,
		CASH_CODE,
		STATISTICAL_CODE_USER,
		STATISTICAL_CODE_SYS,
		ODENMIS_FAIZ_TOPLAMI_LC,
		NEXT_INTEREST_CALC_DATE,
		BLOKE_KAYDI,
		BADLIST_FLAG,
		MASRAF_TUTARI,
		MAAS_HESAP_FLAG,
		ESKI_HESAP_REFNO,
		ESKI_DK_NO,
		SIRKET_HESABIMI,
		GECMISYIL_ODENMIS_FAIZ_TOPLAMI,
		INTEREST_ACCURATE_PERIOD,
		EXTERNAL_HESAP_NO,
		INTEREST_PAYMENT_PERIOD,
		GECMIS_AYLARIN_FAIZI,
		OVERDRAFT,
		OVD_ESAS_GUN_SAYISI,
		OVD_FAIZ_ORANI,
		OVD_FAIZ_INDIKATORU,
		OVD_INTEREST_PAYMENT_PERIOD,
		OVD_DK_NO,
		TAHSIL_EDILEN_FAIZ_FC,
		TAHSIL_EDILEN_FAIZ_LC,
		GECMIS_AYLARIN_FAIZI_NEG)
		VALUES
		(C_HESAP.HESAP_NO,
		C_HESAP.MUSTERI_NO,
		C_HESAP.URUN_TUR_KOD,
		C_HESAP.KISA_ISIM,
		C_HESAP.DOVIZ_KODU,
		C_HESAP.TUTAR,
		C_HESAP.BORC_KAYDI,
		C_HESAP.BORCLU_HESAP_NO,
		C_HESAP.MUHABIR_HESAP_NO,
		C_HESAP.DK_NO,
		C_HESAP.CEK_KARNESI,
		C_HESAP.HESAP_HAREKET_KODU,
		C_HESAP.MIN_PARA_TUTARI,
		C_HESAP.ACIKLAMA,
		C_HESAP.ESAS_GUN_SAYISI,
		C_HESAP.FAIZ_ORANI,
		C_HESAP.FAIZ_INDIKATORU,
		C_HESAP.BAKIYE_TURU,
		C_HESAP.MIN_FAIZ_TUTARI,
		C_HESAP.EKSTRE_BASIM_KODU,
		C_HESAP.EKSTRE_SIKLIGI,
		C_HESAP.DEKONT,
		C_HESAP.DURUM_KODU,
		C_HESAP.SUBE_KODU,
		C_HESAP.URUN_SINIF_KOD,
		C_HESAP.MODUL_TUR_KOD,
		C_HESAP.ACILIS_TARIHI,
		C_HESAP.BIRIKMIS_FAIZ_NEG,
		C_HESAP.BIRIKMIS_FAIZ_POZ,
		C_HESAP.ODENMIS_FAIZ_TOPLAMI,
		C_HESAP.MUSTERI_DK_NO,
		C_HESAP.MIN_IMZA_ADEDI,
		C_HESAP.REPO_BLOKE_TUTARI,
		C_HESAP.KAPAMA_TARIHI,
		C_HESAP.ESKI_HESAP_NO,
		C_HESAP.ESKI_HESAP_EKNO,
		C_HESAP.BIRIKMIS_FAIZ_NEG_ROUND,
		C_HESAP.BIRIKMIS_FAIZ_POZ_ROUND,
		C_HESAP.AYS_BIRIKMIS_FAIZ_POZ_ROUND,
		C_HESAP.CASH_CODE,
		C_HESAP.STATISTICAL_CODE_USER,
		C_HESAP.STATISTICAL_CODE_SYS,
		C_HESAP.ODENMIS_FAIZ_TOPLAMI_LC,
		C_HESAP.NEXT_INTEREST_CALC_DATE,
		C_HESAP.BLOKE_KAYDI,
		C_HESAP.BADLIST_FLAG,
		C_HESAP.MASRAF_TUTARI,
		C_HESAP.MAAS_HESAP_FLAG,
		C_HESAP.ESKI_HESAP_REFNO,
		C_HESAP.ESKI_DK_NO,
		C_HESAP.SIRKET_HESABIMI,
		C_HESAP.GECMISYIL_ODENMIS_FAIZ_TOPLAMI,
		C_HESAP.INTEREST_ACCURATE_PERIOD,
		C_HESAP.EXTERNAL_HESAP_NO,
		C_HESAP.INTEREST_PAYMENT_PERIOD,
		C_HESAP.GECMIS_AYLARIN_FAIZI,
		ls_overdraft,
		C_HESAP.OVD_ESAS_GUN_SAYISI,
		C_HESAP.OVD_FAIZ_ORANI,
		C_HESAP.OVD_FAIZ_INDIKATORU,
		C_HESAP.OVD_INTEREST_PAYMENT_PERIOD,
		lv_ovd_dkno,--C_HESAP.OVD_DK_NO,
		C_HESAP.TAHSIL_EDILEN_FAIZ_FC,
		C_HESAP.TAHSIL_EDILEN_FAIZ_LC,
		C_HESAP.GECMIS_AYLARIN_FAIZI_NEG
		);

		INSERT INTO CBS_HESAP_BASVURU
		(
		TX_NO, MUSTERI_NO, URUN_TUR_KOD, KISA_ISIM, HESAP_NUMARASI, DOVIZ_KODU, TUTAR, BORC_KAYDI,
		BORCLU_HESAP_NO, MUHABIR_HESAP_NO, DK_NO, CEK_KARNESI, HESAP_HAREKET_KODU, MIN_PARA_TUTARI, ACIKLAMA,
		ESAS_GUN_SAYISI, FAIZ_ORANI, FAIZ_INDIKATORU, BAKIYE_TURU, MIN_FAIZ_TUTARI, EKSTRE_BASIM_KODU,
		EKSTRE_SIKLIGI, DEKONT, SUBE_KODU, URUN_SINIF_KOD,
		MODUL_TUR_KOD, ACILIS_TARIHI, MIN_IMZA_ADEDI, EXTERNAL_HESAP_NO, CASH_CODE,
		STATISTICAL_CODE_USER, STATISTICAL_CODE_SYS, MASRAF_TUTARI, ESKI_HESAP_REFNO, SIRKET_HESABIMI,
		INTEREST_PAYMENT_PERIOD, OVERDRAFT, OVD_ESAS_GUN_SAYISI, OVD_FAIZ_ORANI,
		OVD_FAIZ_INDIKATORU, OVD_INTEREST_PAYMENT_PERIOD, OVD_DK_NO)
		VALUES
		(
		ln_islem_no,C_HESAP.MUSTERI_NO, C_HESAP.URUN_TUR_KOD, C_HESAP.KISA_ISIM, C_HESAP.HESAP_NO, C_HESAP.DOVIZ_KODU, C_HESAP.TUTAR, C_HESAP.BORC_KAYDI,
		C_HESAP.BORCLU_HESAP_NO, C_HESAP.MUHABIR_HESAP_NO, C_HESAP.DK_NO, C_HESAP.CEK_KARNESI, C_HESAP.HESAP_HAREKET_KODU, C_HESAP.MIN_PARA_TUTARI, C_HESAP.ACIKLAMA,
		C_HESAP.ESAS_GUN_SAYISI, C_HESAP.FAIZ_ORANI, C_HESAP.FAIZ_INDIKATORU, C_HESAP.BAKIYE_TURU, C_HESAP.MIN_FAIZ_TUTARI, C_HESAP.EKSTRE_BASIM_KODU,
		C_HESAP.EKSTRE_SIKLIGI, C_HESAP.DEKONT, C_HESAP.SUBE_KODU, C_HESAP.URUN_SINIF_KOD,
		C_HESAP.MODUL_TUR_KOD, C_HESAP.ACILIS_TARIHI, C_HESAP.MIN_IMZA_ADEDI, C_HESAP.EXTERNAL_HESAP_NO, C_HESAP.CASH_CODE,
		C_HESAP.STATISTICAL_CODE_USER, C_HESAP.STATISTICAL_CODE_SYS, C_HESAP.MASRAF_TUTARI, C_HESAP.ESKI_HESAP_REFNO, C_HESAP.SIRKET_HESABIMI,
		C_HESAP.INTEREST_PAYMENT_PERIOD, C_HESAP.OVERDRAFT, C_HESAP.OVD_ESAS_GUN_SAYISI, C_HESAP.OVD_FAIZ_ORANI,
		C_HESAP.OVD_FAIZ_INDIKATORU, C_HESAP.OVD_INTEREST_PAYMENT_PERIOD, lv_ovd_dkno);

		ls_bakiye_karakteri := Pkg_Parametre.DEGER(Pkg_Hesap.modul_tur_vadesiz,
								C_HESAP.URUN_TUR_KOD,
								C_HESAP.URUN_SINIF_KOD,
								'BAKIYE_KARAKTERI');

		MOVE_HESAP_BAKIYE(C_HESAP.HESAP_NO,ls_bakiye_karakteri);

		update cbs_hesap_conv
		set AKTARILDI = 'E'
		Where current of cur_hesap;
		
		log_At('hesap atildi',c_hesap.hesap_no);
	END LOOP;
--	Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.getUCPOINTER || '963' || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER);
	log_At('vadesiz cov.update basladi');
	COMMIT;
	update cbs_hesap
	set faiz_orani = null
	where faiz_orani=0;

	update cbs_hesap
	set birikmis_faiz_neg_round = null
	where birikmis_faiz_neg_round=0;

	update cbs_hesap
	set birikmis_faiz_poz_round = null
	where birikmis_faiz_poz_round=0;

	update cbs_hesap
	set ays_birikmis_faiz_poz_round = null
	where ays_birikmis_faiz_poz_round=0;
	commit;
	log_At('vadesiz cov.update bitti');	
	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

	EXCEPTION
		WHEN OTHERS THEN
			log_At('vadesiz hata',sqlcode,sqlerrm);
		Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.getUCPOINTER || '963' ||Pkg_Hata.getDelimiter || TO_CHAR('SQLCODE') || SQLERRM || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER);
END;
------------------------------
PROCEDURE MOVE_HESAP_VADELI(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
/*
	CURSOR Cur_HESAP IS
		SELECT *
		FROM CBS_HESAP_VADELI_CONV
		where   (sube_kodu,eski_hesap_no,eski_hesap_ekno,eski_hesap_refno )
		  not in
				(select sube_kodu,eski_hesap_no,eski_hesap_ekno,eski_hesap_refno
				 from cbs_hesap_vadeli
				 where eski_hesap_no is not null and eski_hesap_ekno is not null)
		for update of AKTARILDI ;
*/
		
	CURSOR Cur_HESAP IS
		SELECT *
		FROM CBS_HESAP_VADELI_CONV a 
		where  not exists  (select 1 from cbs_hesap_vadeli b
			   		   	where a.sube_kodu = b.sube_kodu and
							  a.eski_hesap_no = b.eski_hesap_no and 
							  a.eski_hesap_ekno = b.eski_hesap_ekno and
							  a.eski_hesap_refno = b.eski_hesap_refno ) 									   	   
			  and eski_hesap_no is not null and eski_hesap_ekno is not null 
			for update of aktarildi ;
		
	ls_bakiye_karakteri  VARCHAR2(1);
	ln_islem_no NUMBER := 0;
	hesap_tanimi_eksik EXCEPTION;
	ln_hesap_no NUMBER := 0;
BEGIN
	Pkg_Baglam.batch;

	delete from cbs_conv_vadeli_hatali;

	FOR c_hesap IN cur_hesap LOOP
		if  c_hesap.urun_tur_kod is null or c_hesap.urun_sinif_kod is null
		then
			sp_insert_vadeli_hatamesaj(c_hesap.hesap_no,c_hesap.musteri_no,98,Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER ||'961'||Pkg_Hata.getDelimiter||c_hesap.ESKI_HESAP_EKNO||Pkg_Hata.getDelimiter||Pkg_Hata.getUCPOINTER));
		else
			ln_islem_no :=Pkg_Batch.Islem_Yarat(1399,C_hesap.sube_kodu);
			INSERT INTO CBS_HESAP_VADELI
			   (
			    HESAP_NO,
				MUSTERI_NO,
				MODUL_TUR_KOD,
				URUN_TUR_KOD,
				URUN_SINIF_KOD,
				KISA_ISIM,
				DOVIZ_KODU,
				TUTAR,
				VALOR_TARIHI,
				BORC_KAYDI,
				BORCLU_HESAP_NO,
				MUHABIR_HESAP_NO,
				DK_NO,
				VADE_ISLEM_BILGISI,
				ARA_ODEME_BILGISI,
				OTOMATIK_TEMDIT,
				PERIOD_SURE,
				PERIOD_CINS,
				SONRAKI_BASLANGIC_TARIHI,
				ARA_ODEME_ISLEM_BILGISI,
				VADE_TARIHI,
				GERI_DONUS_HESAPNO,
				ESAS_GUN_SAYISI,
				FAIZ_ORANI,
				ACIKLAMA,
				EKSTRE_BASIM_KODU,
				EKSTRE_SIKLIGI,
				DEKONT,
				SUBE_KODU,
				BIRIKMIS_FAIZ_NEG,
				BIRIKMIS_FAIZ_POZ,
				ODENMIS_FAIZ_TOPLAMI,
				ACILIS_TARIHI,
				DURUM_KODU,
				MIN_IMZA_ADEDI,
				MUSTERI_DK_NO,
				GECEN_YIL_FAIZ_TOPLAMI,
				MUHASEBE_TARIHI,
				REFERANS,
				KAPAMA_TARIHI,
				SCH_FAIZ_ORANI,
				SCH_BIRIKMIS_FAIZI,
				SCH_GECENYIL_FAIZI,
				BIRIKMIS_FAIZ_NEG_ROUND,
				BIRIKMIS_FAIZ_POZ_ROUND,
				AYS_BIRIKMIS_FAIZ_POZ_ROUND,
				ISLEM_TURU,
				TAHAKKUK_EDEN_SCH_TUTARI,
				ISTATISTIK_KODU_ALIS,
				PREFIX_ISTATISTIK_KODU_ALIS,
				NAKIT_KODU_ALIS,
				ISTATISTIK_KODU_KAPAMA,
				PREFIX_ISTATISTIK_KODU_KAPAMA,
				ISTATISTIK_KODU_FAIZ,
				PREFIX_ISTATISTIK_KODU_FAIZ,
				HESAP_HAREKET_KODU,
				ODENMIS_FAIZ_TOPLAMI_LC,
				BADLIST_FLAG,
				ESKI_HESAP_NO,
				ESKI_HESAP_EKNO,
				ESKI_HESAP_REFNO,
				ESKI_DK_NO,
				SIRKET_HESABIMI,
				GECMISYIL_TAHAKKUK_SCH_FAIZ,
				GECMISYIL_ODENMIS_FAIZ_TOPLAMI,
				REF_STAFF,
				VERGI_ORANI,
				NET_FAIZ,
				GECMIS_AYLARIN_FAIZI,
				TEMDIT_TARIHI)
			   VALUES
			   (c_hesap.HESAP_NO,
			    c_hesap.MUSTERI_NO,
				c_hesap.MODUL_TUR_KOD,
				c_hesap.URUN_TUR_KOD,
				c_hesap.URUN_SINIF_KOD,
				c_hesap.KISA_ISIM,
				c_hesap.DOVIZ_KODU,
				c_hesap.TUTAR,
				c_hesap.VALOR_TARIHI,
				c_hesap.BORC_KAYDI,
				c_hesap.BORCLU_HESAP_NO,
				c_hesap.MUHABIR_HESAP_NO,
				c_hesap.DK_NO,
				c_hesap.VADE_ISLEM_BILGISI,
				c_hesap.ARA_ODEME_BILGISI,
				c_hesap.OTOMATIK_TEMDIT,
				c_hesap.PERIOD_SURE,
				c_hesap.PERIOD_CINS,
				c_hesap.SONRAKI_BASLANGIC_TARIHI,
				c_hesap.ARA_ODEME_ISLEM_BILGISI,
				c_hesap.VADE_TARIHI,
				c_hesap.GERI_DONUS_HESAPNO,
				c_hesap.ESAS_GUN_SAYISI,
				c_hesap.FAIZ_ORANI,
				c_hesap.ACIKLAMA,
				c_hesap.EKSTRE_BASIM_KODU,
				c_hesap.EKSTRE_SIKLIGI,
				c_hesap.DEKONT,
				c_hesap.SUBE_KODU,
				c_hesap.BIRIKMIS_FAIZ_NEG,
				c_hesap.BIRIKMIS_FAIZ_POZ,
				c_hesap.ODENMIS_FAIZ_TOPLAMI,
				c_hesap.ACILIS_TARIHI,
				c_hesap.DURUM_KODU,
				c_hesap.MIN_IMZA_ADEDI,
				c_hesap.MUSTERI_DK_NO,
				c_hesap.GECEN_YIL_FAIZ_TOPLAMI,
				c_hesap.MUHASEBE_TARIHI,
				c_hesap.REFERANS,
				c_hesap.KAPAMA_TARIHI,
				c_hesap.SCH_FAIZ_ORANI,
				c_hesap.SCH_BIRIKMIS_FAIZI,
				c_hesap.SCH_GECENYIL_FAIZI,
				c_hesap.BIRIKMIS_FAIZ_NEG_ROUND,
				c_hesap.BIRIKMIS_FAIZ_POZ_ROUND,
				c_hesap.AYS_BIRIKMIS_FAIZ_POZ_ROUND,
				c_hesap.ISLEM_TURU,
				c_hesap.TAHAKKUK_EDEN_SCH_TUTARI,
				c_hesap.ISTATISTIK_KODU_ALIS,
				c_hesap.PREFIX_ISTATISTIK_KODU_ALIS,
				c_hesap.NAKIT_KODU_ALIS,
				c_hesap.ISTATISTIK_KODU_KAPAMA,
				c_hesap.PREFIX_ISTATISTIK_KODU_KAPAMA,
				c_hesap.ISTATISTIK_KODU_FAIZ,
				c_hesap.PREFIX_ISTATISTIK_KODU_FAIZ,
				c_hesap.HESAP_HAREKET_KODU,
				c_hesap.ODENMIS_FAIZ_TOPLAMI_LC,
				c_hesap.BADLIST_FLAG,
				c_hesap.ESKI_HESAP_NO,
				c_hesap.ESKI_HESAP_EKNO,
				c_hesap.ESKI_HESAP_REFNO,
				c_hesap.ESKI_DK_NO,
				c_hesap.SIRKET_HESABIMI,
				c_hesap.GECMISYIL_TAHAKKUK_SCH_FAIZ,
				c_hesap.GECMISYIL_ODENMIS_FAIZ_TOPLAMI,
				c_hesap.REF_STAFF,
				c_hesap.VERGI_ORANI,
				c_hesap.NET_FAIZ,
				c_hesap.GECMIS_AYLARIN_FAIZI,
				c_hesap.TEMDIT_TARIHI);


		 	   INSERT INTO CBS_HESAP_VADELI_BASVURU
			   (
				TX_NO,
				HESAP_NUMARASI,
				MUSTERI_NO,
				MODUL_TUR_KOD,
				URUN_TUR_KOD,
				URUN_SINIF_KOD,
				KISA_ISIM,
				DOVIZ_KODU,
				TUTAR,
				VALOR_TARIHI,
				BORC_KAYDI,
				BORCLU_HESAP_NO,
				MUHABIR_HESAP_NO,
				DK_NO,
				VADE_ISLEM_BILGISI,
				ARA_ODEME_BILGISI,
				OTOMATIK_TEMDIT,
				PERIOD_SURE,
				PERIOD_CINS,
				SONRAKI_BASLANGIC_TARIHI,
				ARA_ODEME_ISLEM_BILGISI,
				VADE_TARIHI,
				GERI_DONUS_HESAPNO,
				ESAS_GUN_SAYISI,
				FAIZ_ORANI,
				ACIKLAMA,
				EKSTRE_BASIM_KODU,
				EKSTRE_SIKLIGI,
				DEKONT,
				SUBE_KODU,
				ACILIS_TARIHI,
				MIN_IMZA_ADEDI,
				MUSTERI_DK_NO,
				MUHASEBE_TARIHI,
				SCH_FAIZ_ORANI,
				ISTATISTIK_KODU_ALIS,
				PREFIX_ISTATISTIK_KODU_ALIS,
				NAKIT_KODU_ALIS,
				ISTATISTIK_KODU_KAPAMA,
				PREFIX_ISTATISTIK_KODU_KAPAMA,
				ISTATISTIK_KODU_FAIZ,
				PREFIX_ISTATISTIK_KODU_FAIZ,
				ESKI_HESAP_NO,
				ESKI_HESAP_EKNO,
				ESKI_HESAP_REFNO,
				SIRKET_HESABIMI,
				REF_STAFF,
				VERGI_ORANI,
				NET_FAIZ)
			   VALUES
			   (ln_islem_no,
				c_hesap.HESAP_NO,
				c_hesap.MUSTERI_NO,
				c_hesap.MODUL_TUR_KOD,
				c_hesap.URUN_TUR_KOD,
				c_hesap.URUN_SINIF_KOD,
				c_hesap.KISA_ISIM,
				c_hesap.DOVIZ_KODU,
				ABS(c_hesap.TUTAR),
				c_hesap.VALOR_TARIHI,
				c_hesap.BORC_KAYDI,
				c_hesap.BORCLU_HESAP_NO,
				c_hesap.MUHABIR_HESAP_NO,
				c_hesap.DK_NO,
				c_hesap.VADE_ISLEM_BILGISI,
				c_hesap.ARA_ODEME_BILGISI,
				c_hesap.OTOMATIK_TEMDIT,
				c_hesap.PERIOD_SURE,
				c_hesap.PERIOD_CINS,
				c_hesap.SONRAKI_BASLANGIC_TARIHI,
				c_hesap.ARA_ODEME_ISLEM_BILGISI,
				c_hesap.VADE_TARIHI,
				c_hesap.GERI_DONUS_HESAPNO,
				c_hesap.ESAS_GUN_SAYISI,
				c_hesap.FAIZ_ORANI,
				c_hesap.ACIKLAMA,
				c_hesap.EKSTRE_BASIM_KODU,
				c_hesap.EKSTRE_SIKLIGI,
				c_hesap.DEKONT,
				c_hesap.SUBE_KODU,
				c_hesap.ACILIS_TARIHI,
				c_hesap.MIN_IMZA_ADEDI,
				c_hesap.MUSTERI_DK_NO,
				c_hesap.MUHASEBE_TARIHI,
				c_hesap.SCH_FAIZ_ORANI,
				c_hesap.ISTATISTIK_KODU_ALIS,
				c_hesap.PREFIX_ISTATISTIK_KODU_ALIS,
				c_hesap.NAKIT_KODU_ALIS,
				c_hesap.ISTATISTIK_KODU_KAPAMA,
				c_hesap.PREFIX_ISTATISTIK_KODU_KAPAMA,
				c_hesap.ISTATISTIK_KODU_FAIZ,
				c_hesap.PREFIX_ISTATISTIK_KODU_FAIZ,
				c_hesap.ESKI_HESAP_NO,
				c_hesap.ESKI_HESAP_EKNO,
				c_hesap.ESKI_HESAP_REFNO,
				c_hesap.SIRKET_HESABIMI,
				c_hesap.REF_STAFF,
				c_hesap.VERGI_ORANI,
				c_hesap.NET_FAIZ);

			ls_bakiye_karakteri := Pkg_Parametre.DEGER(Pkg_Hesap.modul_tur_vadeli,
								   					   C_HESAP.URUN_TUR_KOD,
													   C_HESAP.URUN_SINIF_KOD,
													   'BAKIYE_KARAKTERI');

			MOVE_HESAP_BAKIYE(C_HESAP.HESAP_NO,ls_bakiye_karakteri);

			update cbs_hesap_vadeli_conv
			set AKTARILDI = 'E'
			Where current of cur_hesap;
		end if;
	END LOOP;

	COMMIT;

	update cbs_hesap
	set faiz_orani = null
	where faiz_orani=0;

	update cbs_hesap
	set birikmis_faiz_neg_round = null
	where birikmis_faiz_neg_round=0;

	update cbs_hesap
	set birikmis_faiz_poz_round = null
	where birikmis_faiz_poz_round=0;

	update cbs_hesap
	set ays_birikmis_faiz_poz_round = null
	where ays_birikmis_faiz_poz_round=0;
	commit;
	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
------------------------------
PROCEDURE MOVE_HESAP_KREDI(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) IS
	CURSOR Cur_HESAP IS
		SELECT *
		FROM CBS_HESAP_KREDI_CONV
		where (sube_kodu,eski_hesap_no,eski_hesap_ekno,eski_hesap_refno )
			  			not in
							(select sube_kodu,eski_hesap_no,eski_hesap_ekno,eski_hesap_refno
							from cbs_hesap_kredi
							where eski_hesap_no is not null and eski_hesap_ekno is not null)
		for update of aktarildi ;

	ls_bakiye_karakteri  VARCHAR2(1);
	ln_islem_no NUMBER;
	hesap_tanimi_eksik EXCEPTION;
	ln_hesap_no NUMBER := 0;

BEGIN
	Pkg_Baglam.batch;

	delete from cbs_conv_kredi_hatali;

	FOR c_hesap IN cur_hesap LOOP
		if  c_hesap.urun_tur_kod is null or c_hesap.urun_sinif_kod is null
		then
			sp_insert_kredi_hatamesaj(c_hesap.hesap_no,
										c_hesap.musteri_no,
										98,
										Pkg_Hata.generatemessage(Pkg_Hata.getUCPOINTER||'961'||Pkg_Hata.getDelimiter||c_hesap.ESKI_HESAP_EKNO||Pkg_Hata.getDelimiter||Pkg_Hata.getUCPOINTER));
		else
			ln_islem_no :=Pkg_Batch.Islem_Yarat(1399,C_hesap.sube_kodu);

			INSERT INTO CBS_HESAP_KREDI
			(HESAP_NO,
			 MUSTERI_NO,
			 DOVIZ_KODU,
			 TUTAR,
			 DURUM_KODU,
			 SUBE_KODU,
			 MUSTERI_DK_NO,
			 URUN_TUR_KOD,
			 URUN_SINIF_KOD,
			 MODUL_TUR_KOD,
			 KREDI_TEKLIF_SATIR_NUMARA,
			 KREDI_VADE,
			 KREDI_KULLANDIRIM_KODU,
			 ENDEKS_DOVIZ_KODU,
			 KULLANDIRIM_DOVIZ_KODU,
			 SON_GUN_FAIZI,
			 ACILIS_KURU,
			 FAIZ_ORANI,
			 FAIZ_SIKLIK,
			 FAIZ_SIKLIK_TIPI,
			 FAIZ_TAHAKKUK_TARIHI,
			 KOMISYON_ORANI,
			 KOMISYON_TUTARI,
			 KOMISYON_TAHSILAT_DONEMI,
			 FON_ORANI,
			 BSMV_ORANI,
			 ALACAK_HESAP_NO,
			 ILISKILI_HESAP_NO,
			 KUR_FARKI,
			 EXTRE_MASRAFI,
			 SINIRLAMA_KODU,
			 KAYNAK_KODU,
			 ISTATISTIK_KODU,
		 	 URUN_GRUP_NO,
			 REFERANS,
			 FAIZ_TAHAKKUK_HESAP_NO,
			 VERGI_TAHAKKUK_HESAP_NO,
			 BIRIKMIS_FAIZ_TUTARI,
			 BIRIKMIS_KOMISYON_TUTARI,
			 ESAS_GUN_SAYISI,
			 ACILIS_TARIHI,
			 KAPANIS_TARIHI,
			 BSMV_ALINSIN,
			 KKDF_ALINSIN,
			 ENDEKS_DOVIZ_TUTARI,
			 GECENYIL_FAIZ_TUTARI,
			 TAHSILEDILEN_FAIZ_TUTARI,
			 TAHSILEDILEN_KOMISYON_TUTARI,
			 GECENYIL_KOMISYON_TUTARI,
			 BIRIKMIS_SCH_FAIZI,
			 GECENYIL_SCH_FAIZI,
			 SON_ISLEM_KURU,
			 GECENYIL_ANAPARAKURFARK_GELIR,
			 GECENYIL_ANAPARAKURFARK_ZARAR,
			 GECENYIL_FAIZKURFARK_GELIR,
			 GECENYIL_FAIZKURFARK_ZARAR,
			 GECENYIL_KOMISKURFARK_GELIR,
			 GECENYIL_KOMISKURFARK_ZARAR,
			 FAIZ_BASLANGIC_TARIHI,
			 SCH_FAIZ_ORANI,
			 ESKI_HESAP_NO,
			 ESKI_HESAP_EKNO,
			 ESKI_HESAP_REFNO,
			 ESKI_FAIZHESAP_EKNO,
			 ESKI_KOMHESAP_EKNO,
			 BIRIKMIS_FAIZ_TUTARI_ROUND,
			 BIRIKMIS_KOMISYON_TUTARI_ROUND,
			 AYS_BIRIKMIS_FAIZ_TUTARI_ROUND,
			 AYS_BIRIKMIS_KOMISYON_TUTARI_R,
			 KREDI_TURU,
			 TAKSIT_SAYISI,
			 TAKSIT_ONCE_SONRA,
			 ARTIS_SIKLIK,
			 ARTIS_ORAN,
			 ARA_ODEME_SIKLIK,
			 ARA_ODEME_TUTAR,
			 DONEM_SIKLIK,
			 ODEME_TURU,
			 SCH_FAIZ_TUR,
			 TEMDIT_TARIHI,
			 TAHAKKUK_SCH_FAIZ_TUTARI,
			 REPAYMENT_TYPE,
			 PREFIX_ISTATISTIK_KODU,
			 PREFIX_ISTATISTIK_KODU_FAIZ,
			 ISTATISTIK_KODU_FAIZ,
			 PREFIX_ISTATISTIK_KODU_KAPAMA,
			 ISTATISTIK_KODU_KAPAMA,
			 TAHSILEDILEN_FAIZ_TUTARI_LC,
			 TAHSILEDILEN_KOMIS_TUTARI_LC)
			VALUES
			(C_hesap.HESAP_NO,
			 C_hesap.MUSTERI_NO,
			 C_hesap.DOVIZ_KODU,
			 ABS(C_hesap.TUTAR),
			 C_hesap.DURUM_KODU,
			 C_hesap.SUBE_KODU,
			 C_hesap.MUSTERI_DK_NO,
			 C_hesap.URUN_TUR_KOD,
			 C_hesap.URUN_SINIF_KOD,
			 C_hesap.MODUL_TUR_KOD,
			 C_hesap.KREDI_TEKLIF_SATIR_NUMARA,
			 C_hesap.KREDI_VADE,
			 C_hesap.KREDI_KULLANDIRIM_KODU,
			 C_hesap.ENDEKS_DOVIZ_KODU,
			 C_hesap.KULLANDIRIM_DOVIZ_KODU,
			 C_hesap.SON_GUN_FAIZI,
			 C_hesap.ACILIS_KURU,
			 C_hesap.FAIZ_ORANI,
			 C_hesap.FAIZ_SIKLIK,
			 C_hesap.FAIZ_SIKLIK_TIPI,
			 C_hesap.FAIZ_TAHAKKUK_TARIHI,
			 C_hesap.KOMISYON_ORANI,
			 C_hesap.KOMISYON_TUTARI,
			 C_hesap.KOMISYON_TAHSILAT_DONEMI,
			 C_hesap.FON_ORANI,
			 C_hesap.BSMV_ORANI,
			 C_hesap.ALACAK_HESAP_NO,
			 C_hesap.ILISKILI_HESAP_NO,
			 C_hesap.KUR_FARKI,
			 C_hesap.EXTRE_MASRAFI,
			 C_hesap.SINIRLAMA_KODU,
			 C_hesap.KAYNAK_KODU,
			 C_hesap.ISTATISTIK_KODU,
			 C_hesap.URUN_GRUP_NO,
			 C_hesap.REFERANS,
			 C_hesap.FAIZ_TAHAKKUK_HESAP_NO,
			 C_hesap.VERGI_TAHAKKUK_HESAP_NO,
			 C_hesap.BIRIKMIS_FAIZ_TUTARI,
			 C_hesap.BIRIKMIS_KOMISYON_TUTARI,
			 C_hesap.ESAS_GUN_SAYISI,
			 C_hesap.ACILIS_TARIHI,
			 C_hesap.KAPANIS_TARIHI,
			 C_hesap.BSMV_ALINSIN,
			 C_hesap.KKDF_ALINSIN,
			 C_hesap.ENDEKS_DOVIZ_TUTARI,
			 C_hesap.GECENYIL_FAIZ_TUTARI,
			 C_hesap.TAHSILEDILEN_FAIZ_TUTARI,
			 C_hesap.TAHSILEDILEN_KOMISYON_TUTARI,
			 C_hesap.GECENYIL_KOMISYON_TUTARI,
			 C_hesap.BIRIKMIS_SCH_FAIZI,
			 C_hesap.GECENYIL_SCH_FAIZI,
			 C_hesap.SON_ISLEM_KURU,
			 C_hesap.GECENYIL_ANAPARAKURFARK_GELIR,
			 C_hesap.GECENYIL_ANAPARAKURFARK_ZARAR,
			 C_hesap.GECENYIL_FAIZKURFARK_GELIR,
			 C_hesap.GECENYIL_FAIZKURFARK_ZARAR,
			 C_hesap.GECENYIL_KOMISKURFARK_GELIR,
			 C_hesap.GECENYIL_KOMISKURFARK_ZARAR,
			 C_hesap.FAIZ_BASLANGIC_TARIHI,
			 C_hesap.SCH_FAIZ_ORANI,
			 C_hesap.ESKI_HESAP_NO,
			 C_hesap.ESKI_HESAP_EKNO,
			 C_hesap.ESKI_HESAP_refno,
			 C_hesap.ESKI_FAIZHESAP_EKNO,
			 C_hesap.ESKI_KOMHESAP_EKNO,
			 C_hesap.BIRIKMIS_FAIZ_TUTARI_ROUND,
			 C_hesap.BIRIKMIS_KOMISYON_TUTARI_ROUND,
			 C_hesap.AYS_BIRIKMIS_FAIZ_TUTARI_ROUND,
			 C_hesap.AYS_BIRIKMIS_KOMISYON_TUTARI_R,
			 C_hesap.KREDI_TURU,
			 C_hesap.TAKSIT_SAYISI,
			 C_hesap.TAKSIT_ONCE_SONRA,
			 C_hesap.ARTIS_SIKLIK,
			 C_hesap.ARTIS_ORAN,
			 C_hesap.ARA_ODEME_SIKLIK,
			 C_hesap.ARA_ODEME_TUTAR,
			 C_hesap.DONEM_SIKLIK,
			 C_hesap.ODEME_TURU,
			 C_hesap.SCH_FAIZ_TUR,
			 C_hesap.TEMDIT_TARIHI,
			 C_hesap.TAHAKKUK_SCH_FAIZ_TUTARI,
			 C_hesap.REPAYMENT_TYPE,
			 C_hesap.PREFIX_ISTATISTIK_KODU,
			 C_hesap.PREFIX_ISTATISTIK_KODU_FAIZ,
			 C_hesap.ISTATISTIK_KODU_FAIZ,
			 C_hesap.PREFIX_ISTATISTIK_KODU_KAPAMA,
			 C_hesap.ISTATISTIK_KODU_KAPAMA,
			 C_hesap.TAHSILEDILEN_FAIZ_TUTARI_LC,
			 C_hesap.TAHSILEDILEN_KOMIS_TUTARI_LC) ;

			INSERT INTO CBS_HESAP_KREDI_ISLEM
			(TX_NO,
			ISLEM_TANIM_KOD,
			HESAP_NO,
			MUSTERI_NO,
			DOVIZ_KODU,
			TUTAR,
			DURUM_KODU,
			SUBE_KODU,
			MUSTERI_DK_NO,
			URUN_TUR_KOD,
			URUN_SINIF_KOD,
			MODUL_TUR_KOD,
			KREDI_TEKLIF_SATIR_NUMARA,
			KREDI_VADE,
			KREDI_KULLANDIRIM_KODU,
			ENDEKS_DOVIZ_KODU,
			KULLANDIRIM_DOVIZ_KODU,
			SON_GUN_FAIZI,
			ACILIS_KURU,
			FAIZ_ORANI,
			FAIZ_SIKLIK,
			FAIZ_SIKLIK_TIPI,
			FAIZ_TAHAKKUK_TARIHI,
			KOMISYON_ORANI,
			KOMISYON_TUTARI,
			KOMISYON_TAHSILAT_DONEMI,
			FON_ORANI,
			BSMV_ORANI,
			ALACAK_HESAP_NO,
			ILISKILI_HESAP_NO,
			KUR_FARKI,
			EXTRE_MASRAFI,
			SINIRLAMA_KODU,
			KAYNAK_KODU,
			ISTATISTIK_KODU,
			URUN_GRUP_NO,
			REFERANS,
			FAIZ_TAHAKKUK_HESAP_NO,
			VERGI_TAHAKKUK_HESAP_NO,
			BIRIKMIS_FAIZ_TUTARI,
			BIRIKMIS_KOMISYON_TUTARI,
			ESAS_GUN_SAYISI,
			ACILIS_TARIHI,
			KAPANIS_TARIHI,
			BSMV_ALINSIN,
			KKDF_ALINSIN,
			ENDEKS_DOVIZ_TUTARI,
			GECENYIL_FAIZ_TUTARI,
			TAHSILEDILEN_FAIZ_TUTARI,
			TAHSILEDILEN_KOMISYON_TUTARI,
			GECENYIL_KOMISYON_TUTARI,
			BIRIKMIS_SCH_FAIZI,
			GECENYIL_SCH_FAIZI,
			SON_ISLEM_KURU,
			GECENYIL_ANAPARAKURFARK_GELIR,
			GECENYIL_ANAPARAKURFARK_ZARAR,
			GECENYIL_FAIZKURFARK_GELIR,
			GECENYIL_FAIZKURFARK_ZARAR,
			GECENYIL_KOMISKURFARK_GELIR,
			GECENYIL_KOMISKURFARK_ZARAR,
			FAIZ_BASLANGIC_TARIHI,
			SCH_FAIZ_ORANI,
			ESKI_HESAP_NO,
			ESKI_HESAP_EKNO,
			ESKI_HESAP_REFNO,
			ESKI_FAIZHESAP_EKNO,
			ESKI_KOMHESAP_EKNO,
			BIRIKMIS_FAIZ_TUTARI_ROUND,
			BIRIKMIS_KOMISYON_TUTARI_ROUND,
			AYS_BIRIKMIS_FAIZ_TUTARI_ROUND,
			AYS_BIRIKMIS_KOMISYON_TUTARI_R,
			KREDI_TURU,
			TAKSIT_SAYISI,
			TAKSIT_ONCE_SONRA,
			ARTIS_SIKLIK,
			ARTIS_ORAN,
			ARA_ODEME_SIKLIK,
			ARA_ODEME_TUTAR,
			DONEM_SIKLIK,
			ODEME_TURU,
			SCH_FAIZ_TUR,
			TEMDIT_TARIHI,
			TAHAKKUK_SCH_FAIZ_TUTARI,
			REPAYMENT_TYPE,
			PREFIX_ISTATISTIK_KODU,
			PREFIX_ISTATISTIK_KODU_FAIZ,
			ISTATISTIK_KODU_FAIZ,
			PREFIX_ISTATISTIK_KODU_KAPAMA,
			ISTATISTIK_KODU_KAPAMA,
			TAHSILEDILEN_FAIZ_TUTARI_LC,
			TAHSILEDILEN_KOMIS_TUTARI_LC)
			VALUES
			( ln_islem_no,
			1399,
			C_hesap.HESAP_NO,
			C_hesap.MUSTERI_NO,
			C_hesap.DOVIZ_KODU,
			ABS(C_hesap.TUTAR),
			C_hesap.DURUM_KODU,
			C_hesap.SUBE_KODU,
			C_hesap.MUSTERI_DK_NO,
			C_hesap.URUN_TUR_KOD,
			C_hesap.URUN_SINIF_KOD,
			C_hesap.MODUL_TUR_KOD,
			C_hesap.KREDI_TEKLIF_SATIR_NUMARA,
			C_hesap.KREDI_VADE,
			C_hesap.KREDI_KULLANDIRIM_KODU,
			C_hesap.ENDEKS_DOVIZ_KODU,
			C_hesap.KULLANDIRIM_DOVIZ_KODU,
			C_hesap.SON_GUN_FAIZI,
			C_hesap.ACILIS_KURU,
			C_hesap.FAIZ_ORANI,
			C_hesap.FAIZ_SIKLIK,
			C_hesap.FAIZ_SIKLIK_TIPI,
			C_hesap.FAIZ_TAHAKKUK_TARIHI,
			C_hesap.KOMISYON_ORANI,
			C_hesap.KOMISYON_TUTARI,
			C_hesap.KOMISYON_TAHSILAT_DONEMI,
			C_hesap.FON_ORANI,
			C_hesap.BSMV_ORANI,
			C_hesap.ALACAK_HESAP_NO,
			C_hesap.ILISKILI_HESAP_NO,
			C_hesap.KUR_FARKI,
			C_hesap.EXTRE_MASRAFI,
			C_hesap.SINIRLAMA_KODU,
			C_hesap.KAYNAK_KODU,
			C_hesap.ISTATISTIK_KODU,
			C_hesap.URUN_GRUP_NO,
			C_hesap.REFERANS,
			C_hesap.FAIZ_TAHAKKUK_HESAP_NO,
			C_hesap.VERGI_TAHAKKUK_HESAP_NO,
			C_hesap.BIRIKMIS_FAIZ_TUTARI,
			C_hesap.BIRIKMIS_KOMISYON_TUTARI,
			C_hesap.ESAS_GUN_SAYISI,
			C_hesap.ACILIS_TARIHI,
			C_hesap.KAPANIS_TARIHI,
			C_hesap.BSMV_ALINSIN,
			C_hesap.KKDF_ALINSIN,
			C_hesap.ENDEKS_DOVIZ_TUTARI,
			C_hesap.GECENYIL_FAIZ_TUTARI,
			C_hesap.TAHSILEDILEN_FAIZ_TUTARI,
			C_hesap.TAHSILEDILEN_KOMISYON_TUTARI,
			C_hesap.GECENYIL_KOMISYON_TUTARI,
			C_hesap.BIRIKMIS_SCH_FAIZI,
			C_hesap.GECENYIL_SCH_FAIZI,
			C_hesap.SON_ISLEM_KURU,
			C_hesap.GECENYIL_ANAPARAKURFARK_GELIR,
			C_hesap.GECENYIL_ANAPARAKURFARK_ZARAR,
			C_hesap.GECENYIL_FAIZKURFARK_GELIR,
			C_hesap.GECENYIL_FAIZKURFARK_ZARAR,
			C_hesap.GECENYIL_KOMISKURFARK_GELIR,
			C_hesap.GECENYIL_KOMISKURFARK_ZARAR,
			C_hesap.FAIZ_BASLANGIC_TARIHI,
			C_hesap.SCH_FAIZ_ORANI,
			C_hesap.ESKI_HESAP_NO,
			C_hesap.ESKI_HESAP_EKNO,
			c_hesap.ESKI_HESAP_REFNO,
			C_hesap.ESKI_FAIZHESAP_EKNO,
			C_hesap.ESKI_KOMHESAP_EKNO,
			C_hesap.BIRIKMIS_FAIZ_TUTARI_ROUND,
			C_hesap.BIRIKMIS_KOMISYON_TUTARI_ROUND,
			C_hesap.AYS_BIRIKMIS_FAIZ_TUTARI_ROUND,
			C_hesap.AYS_BIRIKMIS_KOMISYON_TUTARI_R,
			C_hesap.KREDI_TURU,
			C_hesap.TAKSIT_SAYISI,
			C_hesap.TAKSIT_ONCE_SONRA,
			C_hesap.ARTIS_SIKLIK,
			C_hesap.ARTIS_ORAN,
			C_hesap.ARA_ODEME_SIKLIK,
			C_hesap.ARA_ODEME_TUTAR,
			C_hesap.DONEM_SIKLIK,
			C_hesap.ODEME_TURU,
			C_hesap.SCH_FAIZ_TUR,
			C_hesap.TEMDIT_TARIHI,
			C_hesap.TAHAKKUK_SCH_FAIZ_TUTARI,
			C_hesap.REPAYMENT_TYPE,
			C_hesap.PREFIX_ISTATISTIK_KODU,
			C_hesap.PREFIX_ISTATISTIK_KODU_FAIZ,
			C_hesap.ISTATISTIK_KODU_FAIZ,
			C_hesap.PREFIX_ISTATISTIK_KODU_KAPAMA,
			C_hesap.ISTATISTIK_KODU_KAPAMA,
			C_hesap.TAHSILEDILEN_FAIZ_TUTARI_LC,
			C_hesap.TAHSILEDILEN_KOMIS_TUTARI_LC) ;

			ls_bakiye_karakteri := Pkg_Parametre.DEGER(Pkg_Kredi.modul_tur_kod, C_HESAP.URUN_TUR_KOD, C_HESAP.URUN_SINIF_KOD,'BAKIYE_KARAKTERI');

			MOVE_HESAP_BAKIYE(C_HESAP.HESAP_NO,ls_bakiye_karakteri);

			update cbs_hesap_kredi_conv
			set AKTARILDI = 'E'
			Where current of cur_hesap;
		end if;
	END LOOP;

	COMMIT;
	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
END;
------------------------------
PROCEDURE MOVE_HESAP_BAKIYE(pn_hesap_no NUMBER ,ps_bakiye_karakteri VARCHAR2)
IS
ln_count NUMBER ;
  BEGIN

    SELECT COUNT(*)
	INTO ln_count
	FROM CBS_HESAP_BAKIYE
	WHERE HESAP_NO = pn_hesap_no;

	IF ln_count = 0 THEN
  	   INSERT INTO CBS_HESAP_BAKIYE
	   (HESAP_NO,
	    BAKIYE,
		BLOKE_TUTARI,
		VALORLU_BAKIYE,
		BAKIYE_KARAKTERI,
		AYLIK_ORTALAMA_BAKIYE,
		YILLIK_ORTALAMA_BAKIYE,
		ACILIS_YILLIK_ORTALAMA_BAKIYE)
	   VALUES(
	   	pn_HESAP_NO,
	    0,
		0,
		0,
		ps_BAKIYE_KARAKTERI,
		0,
		0,
		0
	    );
	 ELSE
	 	  UPDATE CBS_HESAP_BAKIYE
		  SET bakiye_karakteri = ps_BAKIYE_KARAKTERI
          	 WHERE HESAP_NO = pn_hesap_no;
    END IF;

  END;


------------------------------
PROCEDURE CONV_DK_BAKIYE_AT (pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) is
	CURSOR CUR_DK IS
		SELECT *
		FROM CONV_GLMASF
		where GL_AKTARILDI is null
		order by GL_BANK, GL_GLCODE
		for update of GL_AKTARILDI ;
BEGIN
	Pkg_Baglam.batch;

	delete from cbs_conv_dkhesap_bakiye;

	For c_dk in CUR_DK
	LOOP
		INSERT INTO cbs_conv_dkhesap_bakiye
		(BOLUM_KODU, NUMARA, DOVIZ_KOD, ALACAK_BAKIYE, BORC_BAKIYE)
		VALUES
		(c_dk.GL_BANK,rpad(c_dk.GL_GLCODE,8,'0'),Pkg_Conv.dvz(c_dk.GL_CYCODE),abs(c_dk.GL_CRAMT_RL_6),
		 abs(c_dk.GL_DBAMT_RL_6));

		update CONV_GLMASF
		set GL_AKTARILDI = 'E'
		Where current of CUR_DK;
	END LOOP;
	Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.getUCPOINTER || '6031' || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER);
	Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
	commit;
	EXCEPTION
		WHEN OTHERS THEN
		Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.getUCPOINTER || '963' ||Pkg_Hata.getDelimiter || TO_CHAR('SQLCODE') || SQLERRM || Pkg_Hata.getDelimiter   ||Pkg_Hata.getUCPOINTER);
End;

--TERS KESILECEK FISLER ICIN ATILIR
------------------------------
PROCEDURE CONV_HESAP_BAKIYE_AT (pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
is

CURSOR cur_hesap is
  SELECT PKG_CONV.yeni_hesapno_bul(CANO ,refno , CYCODE ) HESAP_NO,
	  	 rpad(GL_CODE,8,'0')	GL_CODE	,
	  	 nvl(BALANCE,0) BALANCE,
		 abs(nvl(to_number(CUMINT_N),0)) CUMINT_N,
		 abs(nvl(to_number(CUMINT),0)) CUMINT,
		 abs(nvl(to_number(LSTYRINT),0) ) LSTYRINT,
		 CANO,
  	     REFNO,
		 CYCODE
	from  CONV_HESAP_BAKIYE
	WHERE NVL(PKG_CONV.yeni_hesapno_bul(CANO ,refno , CYCODE ),0) <>  0;
	   
Begin

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

   delete from cbs_conv_HESAP_bakiye;
   
   for c_hesap in cur_hesap loop 
    insert into cbs_conv_hesap_bakiye  (HESAP_NO,
  		 	  						  ESKI_DK_NO,
  		 	  						  BAKIYE,
									  BIRIKMIS_FAIZ_NEG,
									  BIRIKMIS_FAIZ_POZ,
									  GECENYIL_FAIZ_TUTARI,
									  CANO,
									  REFNO,
									  CYCODE)
   values (c_hesap.HESAP_NO,
	  	 c_hesap.GL_CODE,
	  	 c_hesap.BALANCE,
		 c_hesap.CUMINT_N,
		 c_hesap.CUMINT,
		 c_hesap.LSTYRINT,
		 c_hesap.CANO,
  	     c_hesap.REFNO,
		 c_hesap.CYCODE);

		 commit;	 
   end loop ;
   
   commit;

   insert into cbs_convert_ters_dk  (BOLUM_KODU, NUMARA, DOVIZ_KOD)
   select distinct b.sube_kodu,
		   			a.eski_dk_no,
		   			b.doviz_kodu
	from cbs_conv_hesap_bakiye a,
		 cbs_vw_hesap_izleme b
    where a.hesap_no =b.hesap_no and
		 	  (  b.sube_kodu,a.eski_dk_No,b.doviz_kodu ) not in (select b.sube_kodu,
		   											   	 	 			a.eski_dk_no,
		   																b.doviz_kodu
																 from  cbs_convert_ters_dk );
   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

	commit;
	end;
-----------------------------
PROCEDURE HESAP_FAIZ_GUNCELLE (pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) is

begin

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

	-- vadesiz hesap birikmis alanlari guncellenir
	update cbs_hesap a
	set    (
		    tutar,
			BIRIKMIS_FAIZ_NEG,
			BIRIKMIS_FAIZ_NEG_ROUND,
			BIRIKMIS_FAIZ_POZ,
			BIRIKMIS_FAIZ_POZ_ROUND	,
			ESKI_DK_NO
			) = (select
		   						 abs(BAKIYE),
								 abs(BIRIKMIS_FAIZ_neg),
								 pkg_kur.YUVARLA(doviz_kodu, abs(BIRIKMIS_FAIZ_neg)),
								 abs(BIRIKMIS_FAIZ_POZ),
								 pkg_kur.YUVARLA(doviz_kodu, abs(BIRIKMIS_FAIZ_POZ)),
								 ESKI_DK_NO
		   				  from  cbs_conv_HESAP_bakiye
						  where hesap_no = a.hesap_no )
		where hesap_no in (select hesap_no from cbs_conv_HESAP_bakiye);

		commit;

	-- vadeli hesap birikmis alanlari guncellenir

	update cbs_hesap_vadeli a
	set    (
		    tutar,
			BIRIKMIS_FAIZ_NEG,
			BIRIKMIS_FAIZ_NEG_ROUND,
			BIRIKMIS_FAIZ_POZ,
			BIRIKMIS_FAIZ_POZ_ROUND	,
			ESKI_DK_NO
			) = (select
		   						 abs(BAKIYE),
								 abs(BIRIKMIS_FAIZ_neg),
								 pkg_kur.YUVARLA(doviz_kodu, abs(BIRIKMIS_FAIZ_neg)),
								 abs(BIRIKMIS_FAIZ_POZ),
								 pkg_kur.YUVARLA(doviz_kodu, abs(BIRIKMIS_FAIZ_POZ)),
								 ESKI_DK_NO
		   				  from  cbs_conv_HESAP_bakiye
						  where hesap_no = a.hesap_no )
		where hesap_no in (select hesap_no from cbs_conv_HESAP_bakiye);

		commit;
	--kredi birikmis faiz guncellemesi
	update cbs_hesap_kredi a
	set    (TUTAR,
	   	   BIRIKMIS_FAIZ_TUTARI,
		   BIRIKMIS_FAIZ_TUTARI_ROUND ,
		   GECENYIL_FAIZ_TUTARI	,
		   ESKI_DK_NO) = (select
		   						 abs(BAKIYE),
								 abs(BIRIKMIS_FAIZ_POZ),
								 pkg_kur.YUVARLA(doviz_kodu, abs(BIRIKMIS_FAIZ_POZ)),
								 abs(GECENYIL_FAIZ_TUTARI),
								 ESKI_DK_NO
		   				  from  cbs_conv_HESAP_bakiye
						  where hesap_no = a.hesap_no )
	 where hesap_no in (select hesap_no from cbs_conv_HESAP_bakiye);


	 Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

	commit;
End;

------------------------------
PROCEDURE HESAP_ACILIS_FISI_KES(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;
    ln_plan_no				   NUMBER := 1;
	ln_fis_no				   NUMBER := 0;
	ln_islem_no			   	   NUMBER := 0;
	ln_islem_kod               CBS_ISLEM.islem_kod%TYPE :=1399;
	ls_musteri_aciklama        VARCHAR2(2000);
	ls_banka_aciklama          VARCHAR2(2000);
	ls_fis_aciklama            VARCHAR2(2000);
	ls_modul_tur_kod           VARCHAR2(2000);
	ls_doviz_kodu			   VARCHAR2(2000);
	ls_sube_kodu			   VARCHAR2(2000);
	ls_aciklama				   VARCHAR2(2000);
	ln_1399_banka_aciklama         NUMBER;
	ln_1399_doviz_kodu             NUMBER;
	ln_1399_referans          	   NUMBER;
	ln_1399_musteri_aciklama       NUMBER;
	ln_1399_nakit_kodu             NUMBER;
	ln_1399_hesap_sube        	   NUMBER;
	ln_1399_istatistik_kodu        NUMBER;
	ln_1399_tutar        	   	   NUMBER;
	ln_1399_lc_tutar        	   NUMBER;
	ln_1399_hesap_no        	   NUMBER;
	ln_1399_hesap_tipi        	   NUMBER;
	ln_1399_kur					   NUMBER;

 CURSOR cur_hesap IS
  SELECT DISTINCT modul_tur_kod,
  		 A.sube_kodu,
  		 A.doviz_kodu,
  		 A.hesap_no,
		 B.BAKIYE tutar
  FROM 	 CBS_VW_HESAP_IZLEME A , cbs_conv_hesap_bakiye B
  WHERE  A.HESAP_NO = B.HESAP_NO AND NVL(B.BAKIYE,0)<> 0  AND
  		 A.modul_tur_kod = ls_modul_tur_kod AND
  		 A.sube_kodu = ls_sube_kodu AND
  		 A.doviz_kodu = ls_doviz_kodu AND
		 NVL(B.BAKIYE,0)<> 0 AND
		 b.fis_kesildi = 'H' ;
		 		 
 CURSOR cur_branch IS
  SELECT DISTINCT A.modul_tur_kod,
  		 A.sube_kodu,
  		 A.doviz_kodu
  FROM 	 CBS_VW_HESAP_IZLEME A , cbs_conv_hesap_bakiye B
  WHERE A.HESAP_NO = B.HESAP_NO AND NVL(B.BAKIYE,0)<> 0
  GROUP BY sube_kodu,
 	   	  modul_tur_kod,
  		  doviz_kodu
  ORDER BY sube_kodu,
 	   	  modul_tur_kod,
  		  doviz_kodu;
 BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    ln_1399_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1399_BANKA_ACIKLAMA');
	ln_1399_doviz_kodu :=Pkg_Muhasebe.parametre_index_bul('1399_DOVIZ_KODU');
	ln_1399_istatistik_kodu :=Pkg_Muhasebe.parametre_index_bul('1399_ISTATISTIK_KODU');
	ln_1399_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1399_MUSTERI_ACIKLAMA');
	ln_1399_referans :=Pkg_Muhasebe.parametre_index_bul('1399_REFERANS');
	ln_1399_tutar :=Pkg_Muhasebe.parametre_index_bul('1399_TUTAR');
	ln_1399_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1399_HESAP_SUBE');
	ln_1399_nakit_kodu :=Pkg_Muhasebe.parametre_index_bul('1399_NAKIT_KODU');
	ln_1399_lc_tutar :=Pkg_Muhasebe.parametre_index_bul('1399_LC_TUTAR');
	ln_1399_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1399_HESAP_NO');
	ln_1399_hesap_tipi :=Pkg_Muhasebe.parametre_index_bul('1399_HESAP_TIPI');
	ln_1399_kur :=Pkg_Muhasebe.parametre_index_bul('1399_KUR');

	varchar_list(ln_1399_banka_aciklama) := NULL;
	varchar_list(ln_1399_doviz_kodu) := NULL;
	varchar_list(ln_1399_hesap_sube) := NULL;
	varchar_list(ln_1399_istatistik_kodu) := NULL;
	varchar_list(ln_1399_musteri_aciklama) := NULL;
	varchar_list(ln_1399_nakit_kodu) := NULL;
	varchar_list(ln_1399_referans) := NULL;
	number_list(ln_1399_tutar):= 0;
	number_list(ln_1399_lc_tutar):= 0;
	varchar_list(ln_1399_hesap_tipi) := NULL;

    Pkg_Parametre.deger('1399_BANKA_ACIKLAMA',ls_banka_aciklama);
    Pkg_Parametre.deger('1399_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   FOR c_branch IN cur_branch LOOP
        ln_fis_no := 0;
		LN_PLAN_NO := 0;
        ls_sube_kodu := c_branch.sube_kodu ;
		ls_doviz_kodu := c_branch.doviz_kodu ;
		ls_modul_tur_kod := c_branch.modul_tur_kod ;
        ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,ls_sube_kodu);
	    ls_fis_aciklama :=    Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod ) ;
		Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '1495' || Pkg_Hata.getdelimiter ||ls_sube_kodu|| Pkg_Hata.getdelimiter ||' ' ||TO_CHAR(ln_islem_no) || Pkg_Hata.getdelimiter  || Pkg_Hata.getucpointer ),ln_islem_no );

		    FOR c_hesap IN cur_hesap LOOP

		   	    varchar_list(ln_1399_banka_aciklama) := NVL(ls_banka_aciklama,ls_fis_aciklama);
		   	    varchar_list(ln_1399_musteri_aciklama) :=	NVL(ls_musteri_aciklama,ls_fis_aciklama);
				varchar_list(ln_1399_hesap_no) :=c_hesap.hesap_no;
				varchar_list(ln_1399_doviz_kodu) := c_hesap.doviz_kodu;
				varchar_list(ln_1399_hesap_sube) := c_hesap.sube_kodu;
				varchar_list(ln_1399_referans) :=c_hesap.hesap_no;
				number_list(ln_1399_tutar):= ABS(NVL(c_hesap.tutar,0));
				number_list(ln_1399_lc_tutar) := Pkg_Kur.doviz_doviz_karsilik(c_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,number_list(ln_1399_tutar),1,NULL,NULL,'N','A');
				number_list(ln_1399_kur) := Pkg_Kur.doviz_doviz_karsilik(c_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');

				IF 	 c_hesap.modul_tur_kod = Pkg_Kredi.modul_tur_kod THEN
					 varchar_list(ln_1399_hesap_tipi) :='KR';
				ELSIF c_hesap.modul_tur_kod = Pkg_Hesap.modul_tur_vadesiz THEN
					 varchar_list(ln_1399_hesap_tipi) :='VS';
				ELSE
					varchar_list(ln_1399_hesap_tipi) :='VD';
				END IF;

				 IF  NVL(c_hesap.tutar,0) < 0 THEN
						ln_plan_no :=1;
				 ELSE
				 		ln_plan_no :=2;
				 END IF;

		    /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
			       ln_fis_no:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
										ln_plan_no,
										ln_islem_no,
										varchar_list ,
										number_list  ,
										date_list    ,
										boolean_list ,
										NULL,
										FALSE,
										ln_fis_no,
										ls_fis_aciklama);
				update cbs_conv_hesap_bakiye
				   set fis_kesildi = 'E'
				 where hesap_no = c_hesap.hesap_no;
		     END LOOP;

	    IF NVL(ln_fis_no,0) <> 0 THEN
		  BEGIN 
	     	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);

		  EXCEPTION
		    WHEN OTHERS THEN
		  	ROLLBACK;
		     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
 		   END;	
		END IF;
		 Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '981' || Pkg_Hata.getdelimiter || TO_CHAR(ln_fis_no)||Pkg_Hata.getdelimiter ||  ls_sube_kodu|| Pkg_Hata.getdelimiter ||Pkg_Hata.getdelimiter  ||ls_modul_tur_kod|| Pkg_Hata.getdelimiter  ||Pkg_Hata.getdelimiter || ls_doviz_kodu|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer) ,ln_islem_no );

	END LOOP;
  
  COMMIT;
  
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
  	ROLLBACK;
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;
------------------------------
PROCEDURE DK_ACILIS_ISLEMI_YARAT(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
    ln_islem_numara			  number;
    ln_numara			      number:=0;
	ls_cbs_dk_numara		  varchar2(1000);
	ln_islem_kod  			  number := 3199;
	ls_urun_sinif 			  varchar2(2000) := 'DBCR';
	ls_urun_tur 			  varchar2(2000) := pkg_fdbcr.urun_tur_al;
	ls_aciklama				  varchar2(2000) := 'G/L Balance Conversion' ;
	ls_bolum				  varchar2(3);
	ls_bolum2				  varchar2(3);
   cursor cur_bolum is
	  select distinct bolum_kodu
	    from cbs_conv_dkhesap_bakiye	
		order by bolum_kodu;

    cursor c1 is
	  select lpad(a.bolum_kodu,3,'0') BOLUM_KODU,
	  		 rpad(a.NUMARA,8,'0')		NUMARA,
	  		 a.doviz_kod,
			 abs(nvl(ALACAK_BAKIYE,0)) alacak_bakiye,
			 abs(nvl(BORC_BAKIYE,0)) borc_bakiye
	    from cbs_conv_dkhesap_bakiye a
		where bolum_kodu =ls_bolum
			 and (nvl(alacak_bakiye,0) <> 0 or nvl(borc_bakiye,0) <> 0 )
		 -- SEVALB 030607 ters fis kesilmesi yapilmasi istenmediginden dk acilisda acilmamasi istenenler icin
		 -- bu kisim ilave edildi		  
		  and (  lpad(bolum_kodu,3,'0'),  rpad(NUMARA,8,'0'), a.DOVIZ_KOD ) NOT  IN ( SELECT b.BOLUM_KODU, b.NUMARA, b.DOVIZ_KOD FROM cbs_convert_ters_dk  b)
		  and rpad(NUMARA,8,'0') not in( '11510000','11510100','11510200','11512000','11520000','11520100')
		  and substr(numara,1,1) <> '9' 	 
		order by bolum_kodu,numara;

	r_c1	 				  c1%rowtype;
  Begin
    Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);
    -- SBA i?lemi yarat
	for c_bolum in cur_bolum loop
		 ls_bolum:=c_bolum.bolum_kodu;
		 ln_islem_numara:=Pkg_Batch.islem_yarat(3199,ls_bolum);
		 UPDATE CBS_ISLEM
            SET durum  = 'C'
		  where numara = ln_islem_numara;
--     	 ln_islem_numara:= Pkg_tx.islem_no_al;

		 -- cbs_sba_fis_islem dosyas?na kay?t at
		 insert into cbs_sba_fis_islem (TX_NO,ACIKLAMA,YARATILDIGI_TARIH,GECERLI_OLDUGU_TARIH,YARATAN_KULLANICI_KODU,URUN_SINIF)
		 values (ln_islem_numara,ls_aciklama,pkg_muhasebe.Banka_Tarihi_Bul,pkg_muhasebe.Banka_Tarihi_Bul,user,ls_urun_sinif);

		 -- conversion.cbs_convert_dk dosyas?ndaki her bir kayit i?in
	    open c1;
		loop
		  fetch c1 into r_c1;
		  exit when c1%notfound;
			   -- DK numara mappingi KZ icin gerekli olmad?.
		  		ls_cbs_dk_numara :=r_c1.numara ;
				ls_bolum2 := r_C1.bolum_kodu;
			 /*
		 	    begin
				  select unique cbs_dk_numara
				    into ls_cbs_dk_numara
				    from cbs_dk_mapping
				   where yaz_numara=r_c1.numara
				     and ( yaz_detay_kod=r_c1.detay_kod or yaz_detay_kod is null);
				exception
				  when no_data_found then
				    ls_cbs_dk_numara:=rpad(r_c1.numara,8,'0');
				end;
			 */

			  if r_c1.alacak_bakiye > 0 then

				ln_numara:=ln_numara+1;

			    insert into cbs_sba_satir_islem(TX_NO,NUMARA,TUR,HESAP_BOLUM_KODU,HESAP_TUR_KODU,HESAP_NUMARA,VALOR_TARIHI,
			                                  LC_TUTAR,DV_TUTAR,DOVIZ_KOD,BANKA_ACIKLAMA,MUSTERI_ACIKLAMA,REFERANS,KUR)
									   values(ln_islem_numara,ln_numara,'A',ls_bolum2,'DK',ls_cbs_dk_numara,pkg_muhasebe.Banka_Tarihi_Bul,
									           Pkg_Kur.doviz_doviz_karsilik( r_c1.doviz_kod,Pkg_Genel.lc_al,NULL,nvl(r_c1.alacak_bakiye,0),1,NULL,NULL,'N','A'),
											  r_c1.alacak_bakiye,r_c1.doviz_kod,'Conversion','Conversion','Conversion',1);


			  end if;
			  if r_c1.borc_bakiye > 0 then

				ln_numara:=ln_numara+1;

			    insert into cbs_sba_satir_islem(TX_NO,NUMARA,TUR,HESAP_BOLUM_KODU,HESAP_TUR_KODU,HESAP_NUMARA,VALOR_TARIHI,
			                                  LC_TUTAR,DV_TUTAR,DOVIZ_KOD,BANKA_ACIKLAMA,MUSTERI_ACIKLAMA,REFERANS,KUR)
									   values(ln_islem_numara,ln_numara,'B',ls_bolum2,'DK',ls_cbs_dk_numara,pkg_muhasebe.Banka_Tarihi_Bul,
									           Pkg_Kur.doviz_doviz_karsilik( r_c1.doviz_kod,Pkg_Genel.lc_al,NULL,nvl(r_c1.borc_bakiye,0),1,NULL,NULL,'N','A'),
											   r_c1.borc_bakiye,r_c1.doviz_kod,'Conversion','Conversion','Conversion',1);
			  end if;

			 	End loop;
		  close c1;
		 IF Pkg_Tx.Dogrula_Kontrol(ln_islem_numara) THEN		 -- dogrulama gerekiyor
            null;
		 ELSIF Pkg_Tx.Onay_Kontrol(ln_islem_numara) THEN     --dogrulama gerekmiyor ama onay gerekiyor
            null;
		 ELSE						   			 	 	 --ne dogrulama ne onay gerekiyor. sadece muhasebele?tir..
		     Pkg_Tx.muhasebelestir(ln_islem_numara);
		 END IF;

		   Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '999' || Pkg_Hata.getdelimiter ||ls_bolum2|| Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer) ,ln_islem_numara );
	 End loop;

	   Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  End;

------------------------------
PROCEDURE DK_TERS_FIS_KES(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )

IS
    varchar_list	           Pkg_Muhasebe.varchar_array;
    number_list				   Pkg_Muhasebe.number_array;
    date_list				   Pkg_Muhasebe.date_array;
    boolean_list			   Pkg_Muhasebe.boolean_array;
    ln_plan_no				   NUMBER := 1;
	ln_fis_no				   NUMBER := 0;
	ln_islem_no			   	   NUMBER := 0;
	ln_islem_kod               CBS_ISLEM.islem_kod%TYPE :=1398;
	ls_musteri_aciklama        VARCHAR2(2000);
	ls_banka_aciklama          VARCHAR2(2000);
	ls_fis_aciklama            VARCHAR2(2000);
	ls_modul_tur_kod           VARCHAR2(2000);
	ls_doviz_kodu			   VARCHAR2(2000);
	ls_sube_kodu			   VARCHAR2(2000);
	ls_aciklama				   VARCHAR2(2000);
	ln_1398_banka_aciklama         NUMBER;
	ln_1398_doviz_kodu             NUMBER;
	ln_1398_referans          	   NUMBER;
	ln_1398_musteri_aciklama       NUMBER;
	ln_1398_nakit_kodu             NUMBER;
	ln_1398_hesap_sube        	   NUMBER;
	ln_1398_istatistik_kodu        NUMBER;
	ln_1398_tutar        	   	   NUMBER;
	ln_1398_lc_tutar        	   NUMBER;
	ln_1398_hesap_no        	   NUMBER;
	ln_1398_kur					   NUMBER;
	ls_numara					   CBS_DKHESAP.numara%type;
 cursor cur_branch is
  select distinct
  		 bolum_kodu
   from cbs_convert_ters_dk  ;


 cursor cur_hesap is
  select distinct
  		 bolum_kodu		  sube_kodu,
		 numara  	 	  hesap_no,
		 doviz_kod 		  doviz_kodu,
		 nvl(bakiye_lc,0) bakiye_lc,
		 nvl(bakiye,0) 	  bakiye
  from 	cbs_dkhesap a
  where bolum_kodu = ls_sube_kodu and
  		( nvl(bakiye_lc,0) <> 0 or nvl(bakiye,0) <> 0 ) and
  		exists (select 1
  			   from  cbs_convert_ters_dk
  			   where BOLUM_KODU = a.bolum_kodu and
			   		 numara =a.numara and
					 doviz_kod = a.doviz_kod) ;
 BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

    ln_1398_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1398_BANKA_ACIKLAMA');
	ln_1398_doviz_kodu :=Pkg_Muhasebe.parametre_index_bul('1398_DOVIZ_KODU');
	ln_1398_istatistik_kodu :=Pkg_Muhasebe.parametre_index_bul('1398_ISTATISTIK_KODU');
	ln_1398_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1398_MUSTERI_ACIKLAMA');
	ln_1398_referans :=Pkg_Muhasebe.parametre_index_bul('1398_REFERANS');
	ln_1398_tutar :=Pkg_Muhasebe.parametre_index_bul('1398_TUTAR');
	ln_1398_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1398_HESAP_SUBE');
	ln_1398_nakit_kodu :=Pkg_Muhasebe.parametre_index_bul('1398_NAKIT_KODU');
	ln_1398_lc_tutar :=Pkg_Muhasebe.parametre_index_bul('1398_LC_TUTAR');
	ln_1398_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1398_HESAP_NO');
	ln_1398_kur :=Pkg_Muhasebe.parametre_index_bul('1398_KUR');

	varchar_list(ln_1398_banka_aciklama) := NULL;
	varchar_list(ln_1398_doviz_kodu) := NULL;
	varchar_list(ln_1398_hesap_sube) := NULL;
	varchar_list(ln_1398_istatistik_kodu) := NULL;
	varchar_list(ln_1398_musteri_aciklama) := NULL;
	varchar_list(ln_1398_nakit_kodu) := NULL;
	varchar_list(ln_1398_referans) := NULL;
	number_list(ln_1398_tutar):= 0;
	number_list(ln_1398_lc_tutar):= 0;

    Pkg_Parametre.deger('1398_BANKA_ACIKLAMA',ls_banka_aciklama);
    Pkg_Parametre.deger('1398_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   FOR c_branch IN cur_branch LOOP
        ln_fis_no := 0;
		LN_PLAN_NO := 0;
        ls_sube_kodu := c_branch.bolum_kodu ;

        ln_islem_no:=Pkg_Batch.islem_yarat(ln_islem_kod ,ls_sube_kodu);
	    ls_fis_aciklama :=    Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod ) ;
		Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '1495' || Pkg_Hata.getdelimiter ||ls_sube_kodu|| Pkg_Hata.getdelimiter ||' ' ||TO_CHAR(ln_islem_no) || Pkg_Hata.getdelimiter  || Pkg_Hata.getucpointer ),ln_islem_no );

		    FOR c_hesap IN cur_hesap LOOP
			    varchar_list(ln_1398_banka_aciklama) := NVL(ls_banka_aciklama,ls_fis_aciklama);
		   	    varchar_list(ln_1398_musteri_aciklama) :=	NVL(ls_musteri_aciklama,ls_fis_aciklama);
				varchar_list(ln_1398_hesap_no) :=c_hesap.hesap_no;
				varchar_list(ln_1398_doviz_kodu) := c_hesap.doviz_kodu;
				varchar_list(ln_1398_hesap_sube) := c_hesap.sube_kodu;
				varchar_list(ln_1398_referans) :=c_hesap.hesap_no;
				number_list(ln_1398_tutar):= ABS(NVL(c_hesap.bakiye,0));
				number_list(ln_1398_lc_tutar) := ABS(NVL(c_hesap.bakiye_lc,0));
				number_list(ln_1398_kur) := Pkg_Kur.doviz_doviz_karsilik(c_hesap.doviz_kodu,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');

				 IF  NVL(c_hesap.bakiye,0) < 0 THEN  --bakiye borc ise alacak kesilecek.
						ln_plan_no :=2;
				 ELSE
				 		ln_plan_no :=1;	   -- bakiye alacak ise borc kesilecek
				 END IF;

		    /* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
			       ln_fis_no:=Pkg_Muhasebe.fis_kes(ln_islem_kod,
										ln_plan_no,
										ln_islem_no,
										varchar_list ,
										number_list  ,
										date_list    ,
										boolean_list ,
										NULL,
										FALSE,
										ln_fis_no,
										ls_fis_aciklama);

		     END LOOP;

	    IF NVL(ln_fis_no,0) <> 0 THEN
	     	Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
		END IF;
		 Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '981' || Pkg_Hata.getdelimiter || TO_CHAR(ln_fis_no)||Pkg_Hata.getdelimiter ||  ls_sube_kodu|| Pkg_Hata.getdelimiter ||Pkg_Hata.getdelimiter  ||ls_modul_tur_kod|| Pkg_Hata.getdelimiter  ||Pkg_Hata.getdelimiter || ls_doviz_kodu|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer) ,ln_islem_no );

	END LOOP;
  COMMIT;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);
  END;

  FUNCTION ESKI_MUSTERIDEN_YENIAL_hatasiz(PS_ESKI_MUSTERI_NO VARCHAR2) RETURN NUMBER IS
   ln_musteri_no NUMBER;
   cursor c_0 is
     select master_musteri_no
       from cbs_must_cift_kayit_detail
      where musteri_no=ps_eski_musteri_no;

BEGIN
  open c_0;
  fetch c_0 into ln_musteri_no;
  if c_0%notfound then
     select musteri_no
       into ln_musteri_no
       from cbs_musteri
      where eski_musteri_no = ps_eski_musteri_no;
  end if;
  close c_0;

 return ln_musteri_no ;

 exception
 when no_data_found then
      close c_0;
	  return 0;

end;

PROCEDURE CONV_HESAP_KREDI_TAKSIT(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) is
cursor c_0 is
  select branch, account, suffix, reference, sira_no, vade_tarih,
         taksit, faiz, anapara, kal_anapara,
         tahsil_edilecek_taksit, durum_kodu, odeme_tarihi, is_staff
    from conv_hesap_kredi_taksit
   where aktarildi_mi = 'H'
   for update;
 ln_islem number;
 ln_hesap number;
 err_place varchar2(5);
begin
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

  for r_0 in c_0 loop
    begin
	 err_place := 'LOOP';
	 if r_0.is_staff = 'H' then
	    err_place := 'STH';
        ln_hesap := yeni_hesapno_bul_kr(r_0.branch||lpad(r_0.account,10,'0')||r_0.suffix, r_0.reference) ;
	 else
	    err_place := 'STE';
	    ln_hesap := yeni_hesapno_bul(r_0.branch||lpad(r_0.account,10,'0')||r_0.suffix, r_0.reference, null) ;
	 end if;
	 err_place := 'MINTX';
	  select min(tx_no)
	    into ln_islem
	    from CBS_HESAP_KREDI_ISLEM
	   where hesap_no = ln_hesap
		 and islem_tanim_kod=1399;
	 err_place := 'INSRT';
    insert into cbs_hesap_kredi_taksit_conv
	  (yaratan_tx_no, hesap_no, sira_no,
	   taksit, anapara, faiz, kkdf, bsmv,
	   vade_tarih, kal_anapara, tahsil_edilecek_taksit,
	   yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, aktarildi_mi) values
       ( ln_islem, ln_hesap, r_0.sira_no,
         round(r_0.taksit,2), round(r_0.anapara,2), round(r_0.taksit,2) - round(r_0.anapara,2), 0, 0,
		 r_0.vade_tarih, round(r_0.kal_anapara,2), round(r_0.taksit,2),
		 sysdate, user, r_0.durum_kodu, r_0.odeme_tarihi, 'H');
	err_place := 'UPDTE';
	update  conv_hesap_kredi_taksit
	   set aktarildi_mi = 'E'
	 where current of c_0;
	err_place := 'EXCEP';
   EXCEPTION
    WHEN OTHERS THEN
      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '987' || Pkg_Hata.getdelimiter || err_place || '*' || sqlerrm
	                   ||Pkg_Hata.getdelimiter ||  r_0.branch||lpad(r_0.account,10,'0')||r_0.suffix ||'_'|| r_0.reference
					   ||Pkg_Hata.getdelimiter || ln_hesap||'-'||r_0.sira_no || Pkg_Hata.getucpointer) ,ln_islem );
   end;
  end loop;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);

end;

PROCEDURE MOVE_HESAP_KREDI_TAKSIT(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 ) is
cursor c_0 is
  select yaratan_tx_no, hesap_no, sira_no, taksit, anapara,
         faiz, kkdf, bsmv, vade_tarih, kal_anapara,
		 tahsil_edilecek_taksit, durum_kodu, odeme_tarihi, aktarildi_mi
    from cbs_hesap_kredi_taksit_conv
   where aktarildi_mi = 'H'
   for update;
begin
  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

  for r_0 in c_0 loop
    begin
    insert into cbs_hesap_kredi_taksit
	  (YARATAN_TX_NO, HESAP_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV,
	   VADE_TARIH, KAL_ANAPARA, KDV, KDVLI_TAKSIT, TAHSIL_EDILECEK_TAKSIT,
	   YARATILDIGI_TARIH, YARATAN_KULLANICI, DURUM_KODU, ODEME_TARIHI,
	   GECIKME_FAIZ_TUTARI, KUR_TRL, ANAPARA_TRL, FAIZ_TRL, KDV_TRL) values
       ( r_0.yaratan_tx_no, r_0.hesap_no, r_0.sira_no, r_0.taksit, r_0.anapara, r_0.faiz, 0, 0,
		 r_0.vade_tarih, r_0.kal_anapara, 0, r_0.taksit, r_0.taksit,
		 sysdate, user, r_0.durum_kodu, r_0.odeme_tarihi,
		 0,0,0,0,0);

	update  cbs_hesap_kredi_taksit_conv
	   set aktarildi_mi = 'E'
	 where current of c_0;
   EXCEPTION
    WHEN OTHERS THEN
      Pkg_Batch.logla (pn_grup_no,pn_log_no,ps_program_kod,Pkg_Hata.generatemessage(Pkg_Hata.getucpointer || '988' || Pkg_Hata.getdelimiter || sqlerrm
	                   ||Pkg_Hata.getdelimiter ||  r_0.hesap_no
					   ||Pkg_Hata.getdelimiter || r_0.sira_no || Pkg_Hata.getucpointer) );
   end;
  end loop;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);

  EXCEPTION
    WHEN OTHERS THEN
     Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,SQLERRM);

end;
----------------------------------------------
FUNCTION  YENI_HESAPNO_BUL_KR(ps_CA_CANO varchar2, ps_cr_refno  varchar2) return number is
 ln_hesap_no  number;
Begin

 if ps_CA_CANO is not null then
	 select hesap_no
	 into ln_hesap_no
	 from cbs_vw_hesap_izleme
	 where SUBE_KODU = substr(ps_CA_CANO,1,3) and
	 	   ESKI_HESAP_NO = to_number(substr(ps_CA_CANO,4,10)) and
		   ESKI_HESAP_EKNO = substr(ps_CA_CANO,14,3) and
		   substr(ESKI_HESAP_REFNO,-3) = substr(ps_cr_refno,-3);
  end if;

  return ln_hesap_no ;
End  ;

----------------------------------------------
FUNCTION  musteriden_external_al(pn_musteri number) return varchar is
 ls_ret varchar2(20);
Begin
	select EXTERNAL_ACCT_NO
	into ls_ret
	from cbs_musteri
	where musteri_no = pn_musteri;

	return ls_ret ;
End  ;
----------------------------------------------
PROCEDURE CONV_KART_TANIMLAMA
IS
	CURSOR conv_cursor IS
	SELECT *
	FROM CONV_KART_TANIMLAMA;

	row_conv conv_cursor%ROWTYPE;
	ln_musteri			number;
	ln_odeyecek_musteri number;
	ln_odeyecek_hesap	 number;
BEGIN
	OPEN conv_cursor;
	FETCH conv_cursor INTO row_conv;
	WHILE NOT conv_cursor%NOTFOUND
	LOOP
		BEGIN
			ln_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.HESAP_NO,1,13));
			ln_odeyecek_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.ODEYECEK_HESAP_NO,1,13));
			ln_odeyecek_hesap :=  yeni_hesapno_bul(substr(row_conv.ODEYECEK_HESAP_NO,1,16),null,substr(row_conv.ODEYECEK_HESAP_NO,17,2));

			if ln_musteri is null or ln_odeyecek_musteri is NULL or ln_odeyecek_hesap is null
			then
				insert into CONV_KART_TANIMLAMA_ERR
				(HESAP_NO, KART_NO, EXPIRE_DATE, ODEYECEK_HESAP_NO)
				values
				(row_conv.HESAP_NO,row_conv.KART_NO,row_conv.EXPIRE_DATE,row_conv.ODEYECEK_HESAP_NO);
			else
				INSERT INTO CBS_KART_TANIMLAMA
				(
				 YARATAN_TX_NO,
				 MUSTERI_NO,
				 KART_NO,
				 KOMISYONU_ODEYECEK_OLAN,
				 ODEYECEK_MUSTERI,
				 ODEYECEK_MUSTERI_HESAP,
				 YARATAN_KULLANICI,
				 KOMISYON_TIPI,
				 EXPIRE_DATE,
				 STATUS
				)
				VALUES
				(99999999,
				 ln_musteri,
				 row_conv.KART_NO,
				 'OTHER',
				 ln_odeyecek_musteri,
				 ln_odeyecek_hesap,
				 'CONV',
				 'DCF',
				 row_conv.EXPIRE_DATE,
				 'A');
			 end if;
		END ;
		FETCH conv_cursor INTO row_conv;
	END LOOP;
	COMMIT;
	CLOSE conv_cursor;
END;
------------------------------------------------------------------------------------------
PROCEDURE CONV_ACF
IS
	CURSOR conv_cursor IS
	SELECT *
	FROM CONV_ACF;

	row_conv conv_cursor%ROWTYPE;
	ln_musteri			number;
	ln_odeyecek_musteri number;
	ln_odeyecek_hesap	 number;
BEGIN
	OPEN conv_cursor;
	FETCH conv_cursor INTO row_conv;
	WHILE NOT conv_cursor%NOTFOUND
	LOOP
		BEGIN
			ln_musteri :=  eski_musteriden_yenial_hatasiz(SUBSTR(row_conv.account_no,1,13));

			if ln_musteri = 0
			then
				insert into CONV_ACF_ERR
				(CHARGE_CODE,ACCOUNT_NO,YIL,AY,GUN,CARD_NO,TOTAL_AMOUNT,DVZ,TAKEN_AMOUNT,REMAINING_AMOUNT,CUSTOMER_TYPE)
				values
				(row_conv.CHARGE_CODE,row_conv.ACCOUNT_NO,row_conv.YIL,row_conv.AY,row_conv.GUN,row_conv.CARD_NO,
				 row_conv.TOTAL_AMOUNT,row_conv.DVZ,row_conv.TAKEN_AMOUNT,row_conv.REMAINING_AMOUNT,row_conv.CUSTOMER_TYPE);
			else
				INSERT INTO cbs_fee_tahsil_edilemeyen
				(CHARGE_CODE,
				 MUSTERI_NO,
				 YIL,
				 AY,
				 GUN,
				 KART_NO,
				 MASRAF_TUTARI,
				 MASRAF_DOVIZ,
				 TOPLAM_TAHSIL_TUTAR,
				 TAHSIL_EDILEMEYEN,
				 CUSTOMER_TYPE)
				VALUES
				(row_conv.CHARGE_CODE,
				 ln_musteri,
				 row_conv.YIL,
				 row_conv.AY,
				 row_conv.GUN,
				 row_conv.CARD_NO,
				 row_conv.TOTAL_AMOUNT,
				 row_conv.DVZ,
				 row_conv.TAKEN_AMOUNT,
				 row_conv.REMAINING_AMOUNT,
				 DECODE(row_conv.CUSTOMER_TYPE,'C','CORPORATE','I','INDIVIDUAL'));
			 end if;
		END ;
		FETCH conv_cursor INTO row_conv;
	END LOOP;
	COMMIT;
	CLOSE conv_cursor;
END;
------------------------------------------------------------------------------------------
PROCEDURE MOVE_CEK(pn_grup_no NUMBER, pn_log_no NUMBER, ps_program_kod VARCHAR2 )
IS
CURSOR CUR_CEK IS
  SELECT   to_number(CS_CHEQNO) cek_no,
  		   PKG_CONV.YENI_HESAPNO_BUL (CS_CANO  , null,SUBSTR(CS_CANO ,17,2)) HESAP_NO,
		   CS_CURRENCY doviz_kodu,
		   CS_SERINO cek_yaprak_adet,
		   CS_CONTIN,
		   nvl(CS_GIVENDATE,to_date('01012006','DDMMYYYY')) teslim_tarihi
	FROM  Conv_Cek
	 where  (trim(CS_STATUS) is null OR   trim(CS_STATUS) = 'B' )
	 		and  PKG_CONV.YENI_HESAPNO_BUL (CS_CANO  , null,SUBSTR(CS_CANO ,17,2)) is not null
			and CS_CHEQNO not in (select cek_no from cbs_cek );

	ln_adet  number := 0;
	ln_i 	 number := 0;
	ln_cek_no	number := 0;
	ls_karne_tipi_kodu varchar2(20);
	ln_baslangic_cekno number;
	ln_bitis_cekno 	   number;
	ln_musteri_no	   number;
	ln_hesap_yok 	   number;
	ld_teslim_tarihi   date := to_date('01012006','DDMMYYYY');
	ld_talep_tarihi    date  := to_date('01012006','DDMMYYYY');
	ls_errmsg		   varchar2(2000);
	ls_sube_kodu 	   varchar2(2000);
	ls_doviz_kodu	   varchar2(2000);
	ln_doviz_hesap_farkli	number;
	hesap_bulunamadi   		 exception;
	karne_tip_uygun_Degil	 exception;
BEGIN

  Pkg_Batch.basla(pn_grup_no,pn_log_no,ps_program_kod);

  select count(*)
  into   ln_hesap_yok
  from   conv_cek
  where  PKG_CONV.YENI_HESAPNO_BUL (CS_CANO  , null,SUBSTR(CS_CANO ,17,2)) is null ;

   if nvl(ln_hesap_yok,0) <> 0 then
      ls_errmsg := 'Hesap tanimli olmayan kayitlar mevcut.'  ;
   	  raise hesap_bulunamadi;
   end if;

	select count(*)
	into ln_doviz_hesap_farkli
	from  conv_cek
	where  pkg_conv.Dvz(SUBSTR(CS_CANO ,17,2)) <>    pkg_hesap.HesaptanDovizKoduAl( PKG_CONV.YENI_HESAPNO_BUL (CS_CANO  , null,SUBSTR(CS_CANO ,17,2)))
		   and   PKG_CONV.YENI_HESAPNO_BUL (CS_CANO  , null,SUBSTR(CS_CANO ,17,2)) is not null;


   for c_cek in cur_cek loop
     if c_cek.hesap_no is not null then
   	  ls_sube_kodu :=  PKG_HESAP.HesapSubeAl( c_cek.hesap_no );
	  ln_musteri_no	  := PKG_HESAP.HesaptanMusteriNoAl( c_cek.hesap_no ) ;
	  ls_doviz_kodu	  := pkg_hesap.HesaptanDovizKoduAl(c_cek.hesap_no ) ;
	  ls_karne_tipi_kodu := null;

	  select decode(c_cek.CS_CONTIN,'Y','CONTINUOUS', c_Cek.cek_yaprak_adet) ||'-'||decode( c_cek.doviz_kodu ,pkg_genel.lc_al ,'LC','FC' )
	  into 	  ls_karne_tipi_kodu
	  from 	  dual;

	  if ls_karne_tipi_kodu not in ( 'CONTINUOUS-LC','CONTINUOUS-FC','25-LC','25-FC','10-LC','10-FC') then
	     ls_errmsg := '2.Karne tipi uygun degil ' ||ls_karne_tipi_kodu ;
	     raise karne_tip_uygun_Degil;
	  end if;
 	  insert into cbs_cek (modul_tur_kod,urun_tur_kod,cek_no, musteri_no, hesap_sube_kodu, hesap_no, doviz_kodu, durum_kodu, karne_tipi_kodu, baslangic_cek_no, bitis_cek_no,
	  		 	  		   cek_yaprak_adedi,teslim_tarihi, teslim_edilen_karne_adedi, cek_tutari ,talep_edilen_karne_adedi, talep_tarihi)
	  values (pkg_cek.modul_tur_kod,pkg_cek.urun_tur_kod, c_Cek.cek_no, ln_musteri_no,ls_sube_kodu, c_cek.hesap_no, ls_doviz_kodu	, 'A', ls_karne_tipi_kodu, ln_baslangic_cekno, ln_bitis_cekno , c_cek.cek_yaprak_adet,
			  c_cek.teslim_tarihi, 1, null,1, ld_talep_tarihi) ;

 	  end if;

	  UPDATE CBS_MUSTERI
	  SET  CEK_KARNESI_F = 'E'
	  WHERE MUSTERI_NO  = ln_musteri_no;

	  UPDATE CBS_HESAP
	  SET  CEK_KARNESI = 'E'
	  WHERE HESAP_NO =C_CEK.HESAP_NO;

   END LOOP;
  Pkg_Batch.bitir(pn_grup_no,pn_log_no,ps_program_kod);
 commit;
 Exception
    when others   then
		 	Pkg_Batch.hata_logla (pn_grup_no,pn_log_no,ps_program_kod,ls_errmsg||sqlcode ||' '||sqlerrm );
		    log_at( 'CEK HATA ',sqlcode,sqlerrm, ls_errmsg);
		    rollback ;

End;


------------------------------------------------------------------------------------------
END Pkg_Conv;
/

