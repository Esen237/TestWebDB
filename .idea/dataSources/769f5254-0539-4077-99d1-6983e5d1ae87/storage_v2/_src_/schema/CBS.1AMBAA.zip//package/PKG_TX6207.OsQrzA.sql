create PACKAGE Pkg_Tx6207 IS

/******************************************************************************
   Name       : Pkg_Tx6207
   Created By : Gulnihal Cengiz
   Date    	  : 07/08/2004
   Purpose	  : Kiralik Kasa Guncelleme islemleri
******************************************************************************/
  FUNCTION  Kiralik_Kasa_Acilis_Referansi RETURN VARCHAR2 ;
  FUNCTION  Sf_Bloke_Hesap_Urun_Uygunmu(ps_urun_tur_kod CBS_HESAP.URUN_TUR_KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  Sf_Bloke_Hesap_Sinif_Uygunmu(ps_urun_sinif_kod CBS_URUN_SINIF.KOD%TYPE ) RETURN VARCHAR2;
  FUNCTION  sf_guncelleme_ctrl(ps_Referans_kodu CBS_KIRALIK_KASA_ACILIS_GUNCEL.referans_no%TYPE) RETURN NUMBER;
  PROCEDURE Guncelleme_BilgiAktar(ps_Referans_Kodu CBS_KIRALIK_KASA_ACILIS.referans_no%TYPE,pn_txno IN NUMBER);

  PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER); 		  -- Islem giris kontrolden gectikten sonra cagrilir

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER);		  -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE	Dogrulama_Iptal_Sonrasi (pn_islem_no NUMBER); -- Islem dogrulamas? iptal edildikten onra cagrilir

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER);			  -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER);		  -- Islem reddedildikten sonra cagrilir

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER);			  -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER);  		  -- Isleme iliskin formlar basildiktan sonra cagrilir

  PROCEDURE Muhasebelesme(pn_islem_no NUMBER);			  -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER);			  -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER); -- Islem iptal edilip muhasebe geri al?nd?ktan sonra

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER );	  -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

END;


/

