create PACKAGE BODY     PKG_TX1001 IS
   ------------------------------------------------------------------------------------------
   procedure kontrol_sonrasi (pn_islem_no number)
   is
      ln_adet                      number := 0;
      l_ucpointer                  varchar2 (3) := pkg_hata.getucpointer;
      ls_adres_kod                 cbs_musteri_basvuru.extre_adres_kod%type;
      ln_musteri_no                number;
      ls_msg                       varchar2 (500);
      ls_durum_kodu                cbs_musteri_guncellenen.durum_kodu%type;
      ls_msg_kapatilabilir         varchar2 (200);
      LN_BLOCK_TX_NO               number;       --AntonPa CBS-643 120822
      ls_new_residency             varchar2 (1); --AntonPa CBS-643 120822
      ls_old_residency             varchar2 (1); --AntonPa CBS-643 120822

      NOT_ACTUAL_DATA              EXCEPTION;    --AntonPa CBS-643 120822
      adres_yok                    exception;
      musteri_kapatilamaz          exception;

      --B-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
      ln_firm_id                   number;
      ln_firm_musteri_no           number;
      ln_bs_companyno              number;
      ls_bs_webservice_err_raise   varchar2 (1);
      bs_companyno_tanimsiz        exception;
   --E-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
   begin
      select musteri_no, extre_adres_kod, durum_kodu, yerlesim_kod
        into ln_musteri_no, ls_adres_kod, ls_durum_kodu, ls_old_residency
        from CBS.CBS_MUSTERI_GUNCELLENEN
       where tx_no = pn_islem_no;
       
log_at('address1001',1,'ln_musteri_no'||'  '||ln_musteri_no||'/'||
                         'ls_adres_kod'||'  '||ls_adres_kod||'/'||
                         'ls_durum_kodu'||'  '||ls_durum_kodu||'/'||
                         'ls_old_residency'||'  '||ls_old_residency
                         );

log_at('address1001',2,'pn_islem_no'||'  '||pn_islem_no);
      /*select nvl (count (*), 0)
        into ln_adet
        from CBS.CBS_MUSTERI_GUNCEL_ADRES
       where tx_no = pn_islem_no and (adres_kod = ls_adres_kod OR ADRES_KOD <> LS_ADRES_KOD AND IS_SAME_ADDRESS = 'Y');*/ --AntonPa CBS-395 271022
       
      SELECT COUNT(*) INTO LN_ADET
      FROM CBS_MUSTERI_GUNCEL_ADRES
      WHERE TX_NO = PN_ISLEM_NO AND (ADRES_KOD = '3' OR IS_SAME_ADDRESS = 'Y'); --AntonPa CBS-395 230123
       
log_at('address1001',3,'pn_islem_no'||'  '||pn_islem_no);

      if ln_adet = 0 then
      log_at('address1001',4);
          raise adres_yok;
         -- null;
      end if;

      if ls_durum_kodu = 'K'
      then
         ls_msg := CBS.pkg_tx1001.sf_musteri_kapatilabilir (ln_musteri_no);
     log_at('address1001',5);
         if trim (ls_msg) != 'E' then
             raise musteri_kapatilamaz;
         end if;
      end if;

  --BOM AntonPa CBS-643 120822
      SELECT MIN(NUMARA) INTO LN_BLOCK_TX_NO FROM CBS.CBS_ISLEM
      WHERE ISLEM_KOD = 7010 AND DURUM = 'C' AND MUSTERI_NUMARA = LN_MUSTERI_NO;
    log_at('address1001',6,LN_BLOCK_TX_NO);
      SELECT YERLESIM_KOD INTO ls_NEW_residency FROM CBS.CBS_MUSTERI
      WHERE MUSTERI_NO = LN_MUSTERI_NO;
    log_at('address1001',7,ls_NEW_residency);
      IF LN_BLOCK_TX_NO IS NOT NULL OR ls_old_residency != ls_new_residency THEN
         RAISE NOT_ACTUAL_DATA;
      END IF;
  --EOM AntonPa CBS-643 120822

      --B-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
      -- salary firm ise bs company no tanimli olup olmadigi kontrol edilmeli.
      /*
	  if pkg_debit_card.sf_salary_firm_musteri_mi (ln_musteri_no) = 'E'
      then
         pkg_parametre.
          deger ('BS_WEBSERVICE_ERR_RAISE', ls_bs_webservice_err_raise);

         select firm_no, firm_id, bs_companyno
           into ln_firm_musteri_no, ln_firm_id, ln_bs_companyno
           from cbs_salary_payment_firm_def
          where firm_no = ln_musteri_no;

         if nvl (ln_bs_companyno, 0) = 0 and ls_bs_webservice_err_raise = 'Y'
         then
            raise bs_companyno_tanimsiz;
         end if;
      end if;
	  */
   --E-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
     pkg_black_list.chek_update(pn_islem_no);
        log_at('address1001',8); 
   exception
      when bs_companyno_tanimsiz
      then
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '6705'
            || pkg_hata.getdelimiter
            || to_char (ln_firm_musteri_no)
            || pkg_hata.getdelimiter
            || to_char (ln_firm_id)
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
      when musteri_kapatilamaz
      then
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '5070'
            || pkg_hata.getdelimiter
            || ls_msg
            || pkg_hata.getucpointer);
      when adres_yok
      then
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            --|| '811'
            || '838'
            || pkg_hata.getdelimiter
            || ls_adres_kod
            || pkg_hata.getucpointer);

 --BOM AntonPa CBS-643 120822
     WHEN NOT_ACTUAL_DATA THEN
        RAISE_APPLICATION_ERROR(-20100,
            pkg_hata.getucpointer ||
            '1407' ||
            pkg_hata.getdelimiter ||
            CASE WHEN LN_BLOCK_TX_NO IS NOT NULL THEN
                'NOT APPROVED TX ' || LN_BLOCK_TX_NO
            ELSE NULL END ||
            pkg_hata.getucpointer);
 --EOM AntonPa CBS-643 120822
      when others
      then
         raise_application_error (
            -20100,
               pkg_hata.getucpointer
            || '62'
            || pkg_hata.getdelimiter
            || sqlcode
            || ' '
            || sqlerrm
            || pkg_hata.getdelimiter
            || pkg_hata.getucpointer);
   end;

   ------------------------------------------------------------------------------------------
   procedure dogrulama_sonrasi (pn_islem_no number)
   is
      ln_musteri_no   cbs_musteri.musteri_no%type;
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure iptal_sonrasi (pn_islem_no number)
   is
      ln_musteri_no   cbs_musteri.musteri_no%type;
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure onay_sonrasi (pn_islem_no number)
   is
      ln_musteri_no                cbs_musteri.musteri_no%type := 0;
      ln_musteri_sicil_no          cbs_musteri.personel_sicil_no%type;
      ln_personel_sicil_no         cbs_musteri.personel_sicil_no%type;
      ln_hesap_no                  cbs_hesap.hesap_no%type;
      ls_cek_karnesi_f             cbs_musteri.cek_karnesi_f%type;
      ln_ret                       boolean;
      ls_durum_kodu                cbs_musteri.durum_kodu%type;
      ln_eski_sicil                cbs_musteri.personel_sicil_no%type;

      --B-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
      pn_app_id                    number;
      ps_response_code             varchar2 (2000);
      ps_response_desc             varchar2 (2000);

      cursor cur_sec
      is
         select a.customer_no,
                a.card_no,
                a.card_id_no,
                a.emboss_name_eng,
                a.emboss_second_name_eng,
                a.emboss_surname_eng,
                a.branch_code tx_branch_code
           from CBS.CBS_DEBIT_CARD a
          where customer_no = ln_musteri_no and a.status = 'A';

   --B-O-M KonstantinJ 13012016 4731 Credit Card

      cursor cur_cr_card
      is
         select a.customer_no,
                a.card_no,
                a.card_holder_no,
                    a.card_id_no,
                    a.banksoft_customer_no,
                a.emboss_name_eng,
                a.emboss_second_name_eng,
                a.emboss_surname_eng,
                a.branch_code tx_branch_code
           from CBS.CBS_CREDIT_CARD a
          where customer_no = ln_musteri_no;

     --E-O-M KonstantinJ 13012016 4731 Credit Card

      r_sec                        cur_sec%rowtype;
      r_cur                        cur_cr_card%rowtype;  --E-O-M KonstantinJ 13012016 4731 Credit Card

      ln_bscompanyno               number;
      ln_firm_id                   number;
      ls_contact_name              varchar2 (2000);
      ln_annual_fee_rate           number;
      ln_app_id                    number;
      ln_reason                    number; --MaratM CBS-258
      v_cnt                        number; --MaratM CBS-258
      ls_response_code             varchar2 (2000);
      ls_response_desc             varchar2 (2000);
      ls_bs_webservice_err_raise   varchar2 (1);
      ls_musteri_tipi_kod          varchar2 (1);
      ln_elcard_count              number; --NurmilaZ
      ln_elcard_return             number; --NurmilaZ
      webservice_general_error     exception;
      webservice_general_error_cc exception;
   --E-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system


      -- Adil Kamchibekov IBC-114
      lv_sendername varchar2(1000);
      cursor corp_persons is
        select person_id  from corpint.tbl_person where customer_id = ln_musteri_no;
      -- Adil Kamchibekov IBC-114;

   begin
      kontrol_sonrasi (pn_islem_no);                         --sevalb 18122012

      select musteri_no,
             personel_sicil_no,
             cek_karnesi_f,
             durum_kodu,
             reason
        into ln_musteri_no,
             ln_personel_sicil_no,
             ls_cek_karnesi_f,
             ls_durum_kodu,
             ln_reason
        from CBS.CBS_MUSTERI_GUNCELLENEN
       where tx_no = pn_islem_no;

      select personel_sicil_no
        into ln_eski_sicil
        from CBS.CBS_MUSTERI
       where musteri_no = ln_musteri_no;


      if ls_durum_kodu = 'A'
      then
         --  hesap cek bilgisi daha ?nceden al?n?yordu simdi al?nm?yora cevrildiyse ,hesabdaki
         -- ?ek talep edilebilir alan? guncellenir.

         if ls_cek_karnesi_f = 'H' and CBS.pkg_musteri.sf_cek_karnesi_istiyormu (ln_musteri_no) = 'E'
         then
            ln_ret := CBS.pkg_hesap.hesapcekbilgisisil (ln_musteri_no);
         end if;

         --bom nurzalata cbs-113
         CBS.pkg_notif_sub.sf_generate_notif(pn_islem_no, 1001);
         --eom nurzalata cbs-113
         --musteri ana tablosuna islem tablosundanki kay?tlar? aktar.
         CBS.pkg_musteri.sp_musteriyi_guncelle (pn_islem_no, ln_musteri_no);

         --230305 sevalb eski sicil degisirse  personeldeki musterino temizlenmeli
         --mutluo sicil number problem solved
         if ln_eski_sicil is not null and ln_personel_sicil_no is null
         then
            CBS.pkg_musteri.sp_personel_musterino_guncelle(null, ln_eski_sicil);
         elsif ln_eski_sicil is null and ln_personel_sicil_no is not null
         then
            CBS.pkg_musteri.sp_personel_musterino_guncelle(ln_musteri_no, ln_personel_sicil_no);
         elsif (ln_eski_sicil is not null and ln_personel_sicil_no is not null) and (ln_eski_sicil <> ln_personel_sicil_no)
         then
            CBS.pkg_musteri.sp_personel_musterino_guncelle(ln_musteri_no, ln_personel_sicil_no);
         end if;

         update CBS.CBS_MUSTERI
            set durum_kodu = 'A'
          where musteri_no = ln_musteri_no;

            --BOM MaratM CBS-258
            SELECT COUNT(*)
              INTO v_cnt
              FROM CBS_MUSTERI_CLOSE mc
             WHERE mc.MUSTERI_NO = ln_musteri_no;

            IF v_cnt > 0 THEN
                 DELETE FROM CBS_MUSTERI_CLOSE mc WHERE mc.MUSTERI_NO = ln_musteri_no;
            END IF;
            --EOM MaratM CBS-258

          --B-O-M KonstantinJ 13012016 4731 Credit Card
         for r_cur in  cur_cr_card loop

            select musteri_tipi_kod
              into ls_musteri_tipi_kod
              from CBS.cbs_musteri
             where musteri_no = r_cur.customer_no;

            if r_cur.card_no is not null then

               CBS.pkg_parametre.deger('BS_WEBSERVICE_ERR_RAISE', ls_bs_webservice_err_raise);

               CBS.pkg_credit_card.sp_ccard_update_app_call_ws(pn_islem_no,
                                                               r_cur.customer_no,
                                                               null,
                                                               r_cur.banksoft_customer_no,
                                                               ps_response_code,
                                                               ps_response_desc);

               if ps_response_code <> '000' and ls_bs_webservice_err_raise = 'Y'
               then
                  raise webservice_general_error_cc;
               end if;

               if ls_musteri_tipi_kod in ('1') then
                  exit;
               end if;

            end if;

         end loop;
          --E-O-M KonstantinJ 13012016 4731 Credit Card


         --B-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
         if CBS.pkg_debit_card.musteri_aktif_debit_kart_varmi(ln_musteri_no) = 'E'
         then
            CBS.pkg_parametre.deger('BS_WEBSERVICE_ERR_RAISE', ls_bs_webservice_err_raise);

            open cur_sec;

            fetch cur_sec into r_sec;

            close cur_sec;

            CBS.pkg_debit_card.sp_dcard_insert_app_call_ws(pn_islem_no,
                                                           r_sec.customer_no,
                                                           pn_app_id,
                                                           1001,
                                                           null,
                                                           'EXISTING CUSTOMER',
                                                           r_sec.card_no,
                                                           r_sec.card_id_no,
                                                           r_sec.tx_branch_code,
                                                           r_sec.emboss_name_eng,
                                                           r_sec.emboss_second_name_eng,
                                                           r_sec.emboss_surname_eng,
                                                           ls_response_code,
                                                           ls_response_desc);

            if ls_response_code <> '000' and ls_bs_webservice_err_raise = 'Y'
            then
               NULL;
               --raise webservice_general_error;  --MaratM CBS-520
            end if;
         end if;

         if pkg_debit_card.sf_salary_firm_musteri_mi (ln_musteri_no) = 'E'
         then
            CBS.pkg_parametre.deger('BS_WEBSERVICE_ERR_RAISE', ls_bs_webservice_err_raise);

            select firm_id,
                   contact_information,
                   annual_fee_rate,
                   bs_companyno
              into ln_firm_id,
                   ls_contact_name,
                   ln_annual_fee_rate,
                   ln_bscompanyno
              from cbs_salary_payment_firm_def
             where firm_no = ln_musteri_no;

            CBS.pkg_debit_card.sp_sfirm_insert_app_call_ws(ln_musteri_no,
                                                           ln_firm_id,
                                                           ln_bscompanyno,
                                                           'U', -- ps_insert_update_recordtype
                                                           ls_contact_name,
                                                           ln_annual_fee_rate,
                                                           pn_islem_no,
                                                           ln_app_id,
                                                           ls_response_code,
                                                           ls_response_desc);

            if ls_response_code <> '000' and ls_bs_webservice_err_raise = 'Y'
            then
               NULL;
               --raise webservice_general_error;  -- MaratM CBS-520
            end if;
         end if;
      --E-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system

       --BOM NurmilaZ cbs-313 26082020 _Automatic loading of customer information from CBS to IPC
         select count(*)
           into ln_elcard_count
           from CBS.CBS_HESAP p
          where p.musteri_no = ln_musteri_no
            and p.doviz_kodu = 'KGS'
            and p.urun_sinif_kod ='ELCARD NON INT.BR-LC'
            and p.durum_kodu='A';

         if ln_elcard_count > 0
         then
            ln_elcard_return := pkg_elcard.editcustomerelcard(ln_musteri_no, pn_islem_no); --bahianab cbs-531 Elcard optimization
         end if;
       --EOM NurmilaZ cbs-313 26082020

         --BOM NurmilaZ Campus cbs-485 19072021
         CBS.pkg_campus.update_campus_account_status(pn_islem_no, ln_musteri_no, 'A');
         --EOM NurmilaZ Campus cbs-48519072021

      elsif ls_durum_kodu = 'K'
      then                      --g?ncelleme s?ras?nda m??teri kapat?l?yor ise
         --bilalg 26.11.2004
         --?ncelikle silinecek m??terinin bilgilerini bagl? i?lem tablolar?na at(log ama?l?)
         --m??teri ile ba?l? tablolardan m??teri kay?tlar?n? sil
         --sonra m??teriyi cbs_m??teri tablosundan sil
            IF ln_reason IN (1, 2, 3) THEN

                --musteri ana tablosuna islem tablosundanki kay?tlar? aktar.
                CBS.pkg_musteri.sp_musteriyi_guncelle (pn_islem_no, ln_musteri_no);

                UPDATE CBS_MUSTERI
                    SET DURUM_KODU = 'K'
                 WHERE MUSTERI_NO = ln_musteri_no;

                --BOM YadgarB CBS-258
                --to avoid duplicate customer rows
                SELECT COUNT (*)
                  INTO v_cnt
                  FROM CBS_MUSTERI_CLOSE mc
                 WHERE mc.MUSTERI_NO = ln_musteri_no;

                IF v_cnt > 0 THEN
                    DELETE FROM CBS_MUSTERI_CLOSE mc WHERE mc.MUSTERI_NO = ln_musteri_no;
                END IF;
                --EOM YadgarB CBS-258

                INSERT INTO CBS_MUSTERI_CLOSE(MUSTERI_NO, REASON_ID) VALUES (ln_musteri_no, ln_reason);

            ELSE
                insert into cbs_musteri_silinen(yaratan_tx_no,
                                                musteri_no,
                                                durum_kodu,
                                                musteri_tipi_kod,
                                                dk_grup_kod,
                                                isim,
                                                ikinci_isim,
                                                soyadi,
                                                dogum_tarihi,
                                                dogum_yeri,
                                                dogum_il_kod,
                                                cinsiyet_kod,
                                                baba_adi,
                                                anne_adi,
                                                anne_kizlik_soyadi,
                                                meslek_kod,
                                                egitim_kod,
                                                medeni_hal_kod,
                                                ticari_unvan,
                                                hesap_ucreti_f,
                                                cek_karnesi_f,
                                                personel_sicil_no,
                                                yerlesim_kod,
                                                ozel_kategori_kod,
                                                vergi_muaf_kod,
                                                vergi_dairesi_adi,
                                                vergi_no,
                                                tesvik_kod,
                                                uyruk_kod,
                                                kimlik_kod,
                                                tc_kimlik_no,
                                                nufus_cuzdani_seri_no,
                                                pasaport_no,
                                                ehliyet_belge_no,
                                                il_kod,
                                                ilce_kod,
                                                mahalle_koy,
                                                cilt_no,
                                                aile_sira_no,
                                                sira_no,
                                                verildigi_yer,
                                                verildigi_tarih,
                                                sektor_kod,
                                                finans_kod,
                                                ticari_sicil_no,
                                                extre_adres_kod,
                                                serbest_bolge_izin_tarihi,
                                                serbest_bolge_izin_no,
                                                pazarlama_sorumlusu_sicil_no_1,
                                                pazarlama_sorumlusu_sicil_no_2,
                                                grup_kod,
                                                bic_kod,
                                                swift_mesaj_kod,
                                                reuters_info_page,
                                                reuters_dealing_kod,
                                                yaratan_kullanici_kodu,
                                                yaratildigi_tarih,
                                                modul_tur_kod,
                                                urun_tur_kod,
                                                urun_sinif_kod,
                                                rating_kodu,
                                                eski_musteri_no,
                                                sektor_alt1_kodu,
                                                sektor_alt2_kodu,
                                                bolum_kodu,
                                                gecerlilik_tarihi,
                                                vergi_daire_kodu,
                                                vat_seri_no,
                                                vat_sira_no,
                                                okpo_code,
                                                manager_name,
                                                manager_surname,
                                                manager_patronymic_name,
                                                manager_country_code,
                                                manager_resident_code,
                                                second_manager_name,
                                                vergi_zorunlumu,
                                                sosyal_fon_no,
                                                ekstre_ucreti_alinsin,
                                                working_basis,
                                                patent_no,
                                                patent_expiry_date,
                                                manager_id_type,-- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                                                manager_passport_number,
                                                manager_pass_issue_date,
                                                manager_pass_expiring_date,
                                                manager_pass_issue_place,
                                                manager_passport_series,--end  CQ578 KonstantinJ  03.04.2014 addtitional fields
                                              --BOM AntonPa CBS-395 271022
                                                MILITARY_CARD, 
                                                RESIDENCE_PERMIT,
                                                ECONOMY_SECTOR_CODE, 
                                                BANK_RELATION_CODE,
                                                CIVIL_STATUS_CODE, 
                                                CAPITAL_PARTICIPATION_CODE,
                                                CONTROL_FORM_CODE, 
                                                ECONOMIC_ACTIVITY_SUB,
                                                ECONOMIC_ACTIVITY_CODE, 
                                                TAX_INITIAL_REG_DATE,
                                                TAX_REG_AUTHORITY, 
                                                TAX_RE_REG_DATE,
                                                TAX_REG_COUNTRY_CODE, 
                                                IS_LICENSED,
                                                MANAGER_GENDER, 
                                                DECLARED_SHARE_CAPITAL,
                                                SHARE_CAPITAL_CURRENCY, 
                                                PAID_SHARE_CAPITAL,
                                                PDL_CODE, 
                                                BIRTH_CERTIFICATE,
                                                COMPANY_NAME_KYR,
                                                OPF_ID_CODE,
                                              --EOM AntonPa CBS-395 271022
                                                opn_by_third_person) --AISULUUD CQ5516 21112016
                select tx_no,
                       musteri_no,
                       durum_kodu,
                       musteri_tipi_kod,
                       dk_grup_kod,
                       isim,
                       ikinci_isim,
                       soyadi,
                       dogum_tarihi,
                       dogum_yeri,
                       dogum_il_kod,
                       cinsiyet_kod,
                       baba_adi,
                       anne_adi,
                       anne_kizlik_soyadi,
                       meslek_kod,
                       egitim_kod,
                       medeni_hal_kod,
                       ticari_unvan,
                       hesap_ucreti_f,
                       cek_karnesi_f,
                       personel_sicil_no,
                       yerlesim_kod,
                       ozel_kategori_kod,
                       vergi_muaf_kod,
                       vergi_dairesi_adi,
                       vergi_no,
                       tesvik_kod,
                       uyruk_kod,
                       kimlik_kod,
                       tc_kimlik_no,
                       nufus_cuzdani_seri_no,
                       pasaport_no,
                       ehliyet_belge_no,
                       il_kod,
                       ilce_kod,
                       mahalle_koy,
                       cilt_no,
                       aile_sira_no,
                       sira_no,
                       verildigi_yer,
                       verildigi_tarih,
                       sektor_kod,
                       finans_kod,
                       ticari_sicil_no,
                       extre_adres_kod,
                       serbest_bolge_izin_tarihi,
                       serbest_bolge_izin_no,
                       pazarlama_sorumlusu_sicil_no_1,
                       pazarlama_sorumlusu_sicil_no_2,
                       grup_kod,
                       bic_kod,
                       swift_mesaj_kod,
                       reuters_info_page,
                       reuters_dealing_kod,
                       yaratan_kullanici_kodu,
                       yaratildigi_tarih,
                       modul_tur_kod,
                       urun_tur_kod,
                       urun_sinif_kod,
                       rating_kodu,
                       eski_musteri_no,
                       sektor_alt1_kodu,
                       sektor_alt2_kodu,
                       bolum_kodu,
                       gecerlilik_tarihi,
                       vergi_daire_kodu,
                       vat_seri_no,
                       vat_sira_no,
                       okpo_code,
                       manager_name,
                       manager_surname,
                       manager_patronymic_name,
                       manager_country_code,
                       manager_resident_code,
                       second_manager_name,
                       vergi_zorunlumu,
                       sosyal_fon_no,
                       ekstre_ucreti_alinsin,
                       working_basis,
                       patent_no,
                       patent_expiry_date,
                       manager_id_type,-- start CQ578 KonstantinJ  03.04.2014 addtitional fields
                       manager_passport_number,
                       manager_pass_issue_date,
                       manager_pass_expiring_date,
                       manager_pass_issue_place,
                       manager_passport_series,-- end CQ578 KonstantinJ  03.04.2014 addtitional fields
                     --BOM AntonPa CBS-395 271022
                       MILITARY_CARD, 
                       RESIDENCE_PERMIT,
                       ECONOMY_SECTOR_CODE, 
                       BANK_RELATION_CODE,
                       CIVIL_STATUS_CODE, 
                       CAPITAL_PARTICIPATION_CODE,
                       CONTROL_FORM_CODE, 
                       ECONOMIC_ACTIVITY_SUB,
                       ECONOMIC_ACTIVITY_CODE, 
                       TAX_INITIAL_REG_DATE,
                       TAX_REG_AUTHORITY, 
                       TAX_RE_REG_DATE,
                       TAX_REG_COUNTRY_CODE, 
                       IS_LICENSED,
                       MANAGER_GENDER, 
                       DECLARED_SHARE_CAPITAL,
                       SHARE_CAPITAL_CURRENCY, 
                       PAID_SHARE_CAPITAL,
                       PDL_CODE, 
                       BIRTH_CERTIFICATE,
                       COMPANY_NAME_KYR,
                       OPF_ID_CODE,
                     --EOM AntonPa CBS-395 271022
                       opn_by_third_person --AISULUUD CQ5516 21112016
                  from cbs_musteri_guncellenen
                 where tx_no = pn_islem_no;

                delete from CBS.cbs_musteri_kontak where musteri_no = ln_musteri_no;

                delete from CBS.CBS_CUSTOMER_SHAREHOLDERS where CUSTOMER_NO = ln_musteri_no; --CBS-395 AntonPa 230123

                delete from CBS.cbs_musteri_notlar where musteri_no = ln_musteri_no;

                delete from CBS.cbs_musteri_dokuman where musteri_no = ln_musteri_no;

                delete from CBS.cbs_musteri_adres where musteri_no = ln_musteri_no;

                delete from CBS.cbs_customer_by_third_persons where customer_no = ln_musteri_no; --AISULUUD CQ5516 21112016

                delete from CBS.cbs_musteri_source where musteri_no = ln_musteri_no; --CBS-258 YadgarB

                delete from CBS.cbs_musteri where musteri_no = ln_musteri_no;

            END IF;
        end if;

      --ADIL K IBC-114
      select TICARI_UNVAN into lv_sendername from CBS.CBS_MUSTERI_GUNCELLENEN where tx_no = pn_islem_no;
      if lv_sendername is not null
      then
         FOR ln_preson_id in corp_persons LOOP
            update CORPINT.TBL_PAYEE set SENDERNAME =lv_sendername where CORPINT.TBL_PAYEE.person_id=ln_preson_id.person_id;
         END LOOP;
         log_at('ADILK',lv_sendername,ln_musteri_no);
      end if;
      --ADIL K IBC-114

   exception
      when webservice_general_error_cc then
         raise_application_error(-20100,pkg_hata.getucpointer || '6701' || pkg_hata.getdelimiter  || ps_response_code||' '||ps_response_desc || pkg_hata.getdelimiter ||  pkg_hata.getucpointer );
      when webservice_general_error then
         raise_application_error(-20100, CBS.pkg_hata.getucpointer || '6701' || CBS.pkg_hata.getdelimiter || ls_response_code || ' ' || ls_response_desc || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
      when others then
         log_at('mb-289_getDebitCardAutoconversion', sqlerrm,  dbms_utility.format_error_backtrace);
         raise_application_error(-20100, CBS.pkg_hata.getucpointer || '128' || CBS.pkg_hata.getdelimiter || sqlerrm || CBS.pkg_hata.getucpointer);
   end;

   ------------------------------------------------------------------------------------------
   procedure reddetme_sonrasi (pn_islem_no number)
   is
      ln_musteri_no   cbs_musteri.musteri_no%type;
   begin
      select musteri_no
        into ln_musteri_no
        from CBS.CBS_MUSTERI_GUNCELLENEN
       where tx_no = pn_islem_no;

      update CBS.CBS_MUSTERI
         set durum_kodu = 'A'
       where musteri_no = ln_musteri_no;
   end;

   ------------------------------------------------------------------------------------------
   procedure tamam_sonrasi (pn_islem_no number)
   is
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure basim_sonrasi (pn_islem_no number)
   is
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure muhasebelesme (pn_islem_no number)
   is
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure dogrulama_iptal_sonrasi (pn_islem_no number)
   is
      ln_musteri_no   cbs_musteri.musteri_no%type;
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure iptal_onay_sonrasi (pn_islem_no number)
   is
      ln_musteri_no   cbs_musteri.musteri_no%type;
   begin
      /*select musteri_no
        into  ln_musteri_no
        from  cbs_musteri_guncellenen
        where tx_no = pn_islem_no ;

       update cbs_musteri
       set durum_kodu ='A'
       where musteri_no = ln_musteri_no ;
       */

      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure iptal_reddetme_sonrasi (pn_islem_no number)
   is
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   procedure iptal_muhasebelestir_sonrasi (pn_islem_no number)
   is
   begin
      null;
   end;

   ------------------------------------------------------------------------------------------
   function dokuman_kontrol (pn_islem_no number)
      return number
   is
      ln_adet       number;
      l_ucpointer   varchar2 (3) := pkg_hata.getucpointer;
   begin
      select count (*)
        into ln_adet
        from CBS.CBS_MUSTERI_GUNCEL_DOKUMAN
       where tx_no = pn_islem_no;

      return ln_adet;
   exception
      when others
      then
         return 0;
   end;

   ------------------------------------------------------------------------------------------
   function sf_kontrol_ekstre_adres (pn_islem_no number)
      return number
   is
      ln_adet                 number;
      l_ucpointer             varchar2 (3) := pkg_hata.getucpointer;
      birden_fazla_secilmis   exception;
   begin
      select count (*)
        into ln_adet
        from CBS.CBS_MUSTERI_GUNCEL_ADRES
       where tx_no = pn_islem_no and extre_adres_kod_f = 'E';

      return ln_adet;
   exception
      when others
      then
         return 0;
   end;

   ------------------------------------------------------------------------------------------
   function sf_ekstre_adres_kodu_al (pn_islem_no number)
      return cbs_musteri_guncellenen.extre_adres_kod%type
   is
      ls_extre_adres_kod   cbs_musteri_guncellenen.extre_adres_kod%type;
   begin
      select adres_kod
        into ls_extre_adres_kod
        from CBS.CBS_MUSTERI_GUNCEL_ADRES
       where tx_no = pn_islem_no and extre_adres_kod_f = 'E';

      return ls_extre_adres_kod;
   exception
      when others
      then
         return 0;
   end;

   /*****************************************************************************************************************/
   /*   Function  sf_ortaklik_kontrol                                                                                         */
   /*   ortakl?k kontrolu %100 a?mamal?d?r.                                                                          */
   /*****************************************************************************************************************/
   function sf_ortaklik_kontrol (pn_islem_no number)
      return number
   is
      CURSOR LC_OWNERSHIP IS
        SELECT SUM(OWNERSHIP) OWNERSHIP
          FROM CBS.CBS_CUSTOMER_UPD_SHAREHOLDERS
        WHERE tx_no = pn_islem_no
        GROUP BY COMPANY_INN;
      ln_oran   number;
   begin
      --BOM CBS-395 AntonPa 27102022
        FOR R_OWNERSHIP IN LC_OWNERSHIP
        LOOP
            IF R_OWNERSHIP.OWNERSHIP > 100
            THEN
                RETURN R_OWNERSHIP.OWNERSHIP;
            END IF;
        END LOOP;
            
        RETURN 0;
      --EOM CBS-395 AntonPa 27102022
   exception
      when others
      then
         return 0;
   end;

   ------------------------------------------------------------------------------------------
   function sf_onay_bekleyen_varmi (
      pn_tx_no              cbs_islem.numara%type,
      pn_musteri_no         cbs_musteri.musteri_no%type,
      pn_islem_tanim_kod    cbs_islem.islem_kod%type default 1001)
      return cbs_cek_islem.tx_no%type
   is
      ln_tx_no                    cbs_islem.numara%type := 0;
      onayda_bekleyen_islem_var   exception;
   begin

       select min (numara)
        into ln_tx_no
        from CBS.CBS_ISLEM b, CBS.CBS_MUSTERI_GUNCELLENEN a
       where b.numara = a.tx_no
         and musteri_numara = pn_musteri_no
         and islem_kod = pn_islem_tanim_kod
         and numara <> nvl (pn_tx_no, 0)
         and CBS.pkg_tx.islem_bitmis_mi (b.numara) = 0;
      if nvl (ln_tx_no, 0) <> 0
      then
         raise onayda_bekleyen_islem_var;
      end if;
       return ln_tx_no;
   exception
      when onayda_bekleyen_islem_var then
         raise_application_error(-20100, CBS.pkg_hata.getucpointer || '685' || CBS.pkg_hata.getdelimiter || ln_tx_no || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
      when others then
         return null;
   end sf_onay_bekleyen_varmi;

   ------------------------------------------------------------------------------------------
   function dokuman_kontrol (
      ps_musteri_tipi_kod    cbs_musteri.musteri_tipi_kod%type,
      pn_islem_no            number)
      return number
   is
      ln_adet          number;
      l_ucpointer      varchar2 (3) := pkg_hata.getucpointer;
      ls_dk_grup_kod   cbs_musteri_guncellenen.dk_grup_kod%type;
      ln_mevcut        number := 0;
   begin
      /* Banka musterileri icin zorunlu olmas?n istenildiginden 1 geri dondurulur. iptal edildi.*/

      select dk_grup_kod
        into ls_dk_grup_kod
        from CBS.cbs_musteri_guncellenen
       where tx_no = pn_islem_no;

      select nvl (count (*), 0)
        into ln_mevcut
        from CBS.cbs_dokuman_kodlari
       where dk_grup_kodu = ls_dk_grup_kod;

      if nvl (ln_mevcut, 0) <> 0
      then
         begin
            select 0
              into ln_adet
              from CBS.cbs_dokuman_kodlari
             where dk_grup_kodu = ls_dk_grup_kod
               and upper(dokuman_kodu) not in (select upper(dokuman_adi) from CBS.cbs_musteri_guncel_dokuman where tx_no = pn_islem_no);
         exception
            when others then
               return 0;
         end;
      else
         return 1;                                        --yoksa mevcut de?il
      end if;

      return ln_adet;
   exception                                       -- dokuman mevcut de?il ise
      when others then
         return 1;
   end;

   ------------------------------------------------------------------------------------------
   procedure guncelleme_kontrolu (pn_islem_no          number,
                                  ps_block             varchar2,
                                  ps_rowid             varchar2,
                                  ps_column            varchar2,
                                  pd_column            varchar2,
                                  ps_oldvalue   in out varchar2)
   is
      guncellenmis_exception   exception;
      ln_retval                number := 0;
      ls_sqlstr                varchar2 (2000);
      ls_sql_template          varchar2 (2000);
      ls_source_table          varchar2 (2000);
      ls_dest_table            varchar2 (2000);
   begin
   log_at('MaxTest','test',pn_islem_no||' '||ps_block||' '||ps_rowid||' '||ps_column||' '||pd_column);    

      if ps_block = 'CBS_MUSTERI_GUNCELLENEN'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_MUSTERI_GUNCELLENEN';
         ls_dest_table := 'CBS_MUSTERI';

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (1);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;

      if ps_block = 'CBS_MUSTERI_GUNCEL_ADRES'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_MUSTERI_GUNCEL_ADRES';
         ls_dest_table := 'CBS_MUSTERI_ADRES';

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK2', 'ADRES_KOD');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK2', 'ADRES_KOD');

            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;

      if ps_block = 'CBS_MUSTERI_GUNCEL_ORTAKLIK'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_CUSTOMER_UPD_SHAREHOLDERS';
         ls_dest_table := 'CBS_CUSTOMER_SHAREHOLDERS';

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;

      if ps_block = 'CBS_MUSTERI_GUNCEL_NOTLAR'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_MUSTERI_GUNCEL_NOTLAR';
         ls_dest_table := 'CBS_MUSTERI_NOTLAR';
         
         log_at('MaxTest','CBS_MUSTERI_GUNCEL_NOTLAR',ls_source_table);    
            log_at('MaxTest','CBS_MUSTERI_NOTLAR',ls_dest_table);    

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');
               
            log_at('MaxTest','CBS_MUSTERI_GUNCEL_NOTLAR',ls_source_table);    
            log_at('MaxTest','CBS_MUSTERI_NOTLAR',ls_dest_table);               
         
            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;

      if ps_block = 'CBS_MUSTERI_GUNCEL_DOKUMAN'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_MUSTERI_GUNCEL_DOKUMAN';
         ls_dest_table := 'CBS_MUSTERI_DOKUMAN';

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;

      if ps_block = 'CBS_MUSTERI_GUNCEL_NOTLAR1'
      then
         --TODO 1: Set the source and destination table names
         ls_source_table := 'CBS_MUSTERI_GUNCEL_NOTLAR';
         ls_dest_table := 'CBS_MUSTERI_NOTLAR';

         if ps_column <> 'MUSTERI_NO' and ps_column <> 'TX_NO'
         then
            --TODO 2: Set the Primary Key Count (Default 1)
            ls_sql_template := CBS.pkg_guncel.differencetemplatesinglerecord (2);
            --TODO 3: Do not alter until next TODO :)
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_TABLE', ls_dest_table);
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_COLUMN', pd_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_TABLE', ls_source_table);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_COLUMN', ps_column);
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_ROWID', ps_rowid);
            --TODO 4: Set the Primary Keys bu suffixing the counts to DESTINATION_PK/SOURCE_PK

            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK1', 'MUSTERI_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'DESTINATION_PK2', 'SIRA_NO');
            ls_sql_template :=
               replace (ls_sql_template, 'SOURCE_PK2', 'SIRA_NO');

            --insert into cbs_yphavale_test values(ls_sql_template);
            execute immediate ls_sql_template into ln_retval, ps_oldvalue;
         end if;
      end if;
 
      if ln_retval <> 1
      then
         raise guncellenmis_exception;
      end if;
   exception
      when guncellenmis_exception then
         raise_application_error(-20100, CBS.pkg_hata.getucpointer || '449' || CBS.pkg_hata.getdelimiter || to_char ('SQLCODE') || sqlerrm || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
      when others then
         raise_application_error(-20100, CBS.pkg_hata.getucpointer || '449' || CBS.pkg_hata.getdelimiter || to_char ('SQLCODE') || sqlerrm || CBS.pkg_hata.getdelimiter || CBS.pkg_hata.getucpointer);
   end;

   function badlist_kontrol (pn_musteri_no number)
      return varchar2
   is
      ls_var varchar2 (1) := 'H';
      cursor cur_musteri
      is
         select distinct 'E' var
           from CBS.cbs_vw_hesap_izleme
          where musteri_no = pn_musteri_no
            and CBS.pkg_hesap.badlistflag (hesap_no) = 'E'
            and durum_kodu = 'A';
   begin
      for c_musteri in cur_musteri
      loop
         ls_var := 'E';
      end loop;

      return ls_var;
   exception
      when others then
         return 'H';
   end;

   ------------------------------------------------------------------------------------------
   function sf_musteri_kapatilabilir (pn_musteri_no number)
      return varchar
   is
      ln_count       number;
      ls_kisa_kod    varchar2 (30);
      my_exception   exception;
   begin
      select count (*)
        into ln_count
        from CBS.CBS_KIRALIK_KASA_ACILIS
       where musteri_no = pn_musteri_no
         and durum_kodu = 'A'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Safe Deposit';
         raise my_exception;
      end if;

      select count (*)
      into ln_count
      from CBS.CBS_HESAP h
      join CBS.CBS_HESAP_BAKIYE b using (HESAP_NO)
      where h.MUSTERI_NO = pn_musteri_no
      and h.DURUM_KODU = 'A'
      and NVL(b.BAKIYE, 0) = 0; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Account';
         raise my_exception;
      end if;

      select count (*)
      into ln_count
      from CBS.CBS_HESAP_VADELI h
      join CBS.CBS_HESAP_BAKIYE b using (HESAP_NO)
      where h.MUSTERI_NO = pn_musteri_no
      and h.DURUM_KODU = 'A'
      and NVL(b.BAKIYE, 0) = 0; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Time Deposit';
         raise my_exception;
      end if;

      select count (*)
      into ln_count
      from CBS.CBS_HESAP_KREDI h
      join CBS.CBS_HESAP_BAKIYE b using (HESAP_NO)
      where h.MUSTERI_NO = pn_musteri_no
      and h.DURUM_KODU = 'A'
      and NVL(b.BAKIYE, 0) = 0; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Loan Account';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_GB
       where musteri_no = pn_musteri_no
         and durum_kodu = 'A'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Customs Declaration';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_VW_ITHALAT
       where ITHALATCI_MUSTERI_NO = pn_musteri_no
         and DURUM_KODU = 'A'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Import';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_VW_IHRACAT
       where IHRACATCI_MUSTERI_NO = pn_musteri_no
         and DURUM_KODU = 'A'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Export';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_MUSTERI_LIMIT
       where musteri_no = pn_musteri_no
         and (nvl(lc_limit,0) <> 0
           or nvl(fc_limit,0) <> 0
           or nvl(LC_RISK,0) <> 0
           or nvl(FC_RISK,0) <> 0); --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Limit';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_SOZLESME
       where musteri_no = pn_musteri_no;

      if ln_count != 0
      then
         ls_kisa_kod := 'Agreement';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_LEASING_SOZLESME
       where musteri_no = pn_musteri_no;

      if ln_count != 0
      then
         ls_kisa_kod := 'Leasing Agreement';
         raise my_exception;
      end if;


      select count (*)
        into ln_count
        from CBS.CBS_SOZLESME
       where    kefil1_musteri_no = pn_musteri_no
             or kefil2_musteri_no = pn_musteri_no
             or kefil3_musteri_no = pn_musteri_no
             or kefil4_musteri_no = pn_musteri_no
             or kefil5_musteri_no = pn_musteri_no
             or kefil6_musteri_no = pn_musteri_no
             or kefil7_musteri_no = pn_musteri_no
             or kefil8_musteri_no = pn_musteri_no
             or kefil9_musteri_no = pn_musteri_no
             or kefil10_musteri_no = pn_musteri_no;

      if ln_count != 0
      then
         ls_kisa_kod := 'Personal Guarantee';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_AVANS
       where musteri_no = pn_musteri_no;

      if ln_count != 0
      then
         ls_kisa_kod := 'Advance';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_KREDI_TEMINAT_TANIM
       where MUSTERI_NO = pn_musteri_no
         and DURUM = 'ACIK'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Collateral';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_TM_ALINAN_GARANTI
       where LEHDAR_MUSTERI_NO = pn_musteri_no
         and DURUM_KODU = 'ON'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Received Guarantee';
         raise my_exception;
      end if;

      select count (*)
        into ln_count
        from CBS.CBS_TM_VERILEN_GARANTI
       where lehdar_musteri_no = pn_musteri_no;

      if ln_count != 0
      then
         ls_kisa_kod := 'Issued Guarantee';
         raise my_exception;
      end if;

      /*select count (*)
        into ln_count
        from CBS.CBS_YPHAVALE_GELEN
       where alici_musteri_no = pn_musteri_no
         and durum_kodu = 'A'; --CBS-258 YadgarB

      if ln_count != 0
      then
         ls_kisa_kod := 'Incoming Transfer Beneficiary';
         raise my_exception;
      end if;*/--AntonPa CBS-395 250123

      --B-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system
      select count (*)
        into ln_count
        from CBS.CBS_DEBIT_CARD
       where customer_no = pn_musteri_no and status = 'A';

      if ln_count != 0
      then
         ls_kisa_kod := 'Active Debit Card';
         raise my_exception;
      end if;

      if CBS.PKG_DEBIT_CARD.SF_SALARY_FIRM_MUSTERI_MI(pn_musteri_no) = 'E'
      then
         ls_kisa_kod := 'Active Salry Firm Definition';
         raise my_exception;
      end if;

      --E-O-M Sevalb 18122012 6270_Automatic loading of customer information from CBS to Card system


      return 'E';
   exception
      when my_exception
      then
         return ls_kisa_kod;
   end;

   ------------------------------------------------------------------------------------------
   procedure dokuman_sil (pn_tx_no number)
   is
   begin
      delete from CBS.cbs_musteri_guncel_dokuman
      where tx_no = pn_tx_no;
   exception
      when no_data_found then
         null;
   end;

   ------------------------------------------------------------------------------------------
   function sme_adi (ps_tip varchar2)
      return varchar2
   is
      ls_ret   varchar2 (20);
   begin
      select aciklama
        into ls_ret
        from CBS.cbs_musteri_sme_kodlari
       where musteri_tipi = ps_tip;

      return ls_ret;
   exception
      when others then
         return null;
   end;

   ------------------------------------------------------------------------------------------
   function report_customer_type (pn_musteri_no number)
      return varchar2
   is
      ls_ret varchar2 (1);
   begin
      select report_customer_type
        into ls_ret
        from CBS.CBS_MUSTERI
       where musteri_no = pn_musteri_no;

      return ls_ret;
   exception
      when others then
         return null;
   end;
   
   
/* AntonPa CBS-395 200223 used by cbs_pfc_once cbs_tx1001 */
   function check_licenses_validity (pn_tx_no number)
      return varchar2
   is
      cursor lc_licenses is
        select license_no, validity_date
        from cbs_customer_upd_licenses
        where tx_no = pn_tx_no;
   begin
      for r_license in lc_licenses
      loop
        if r_license.validity_date < trunc(PKG_MUHASEBE.BANKA_TARIHI_BUL)
        then
            return r_license.license_no;
        end if;
      end loop;

      return null;
   exception
      when others then
         return null;
   end;
------------------------------------------------------------------------
end;
/

