create PACKAGE BODY PKG_CASH_CODE_RPT IS

  g_uc_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getUCPOINTER;
  g_ara_delimiter CONSTANT VARCHAR2(3):=Pkg_Hata.getDELIMITER;


FUNCTION DKBaslangicBakiyeAl(ps_sube_kodu varchar2,pd_date date,ps_doviz CBS_DKHESAP.DOVIZ_KOD%TYPE) RETURN NUMBER
is
		 ln_bakiye				   NUMBER := 0;
		 ln_adet				   number := 0;
BEGIN

--sevalb 090405 cbs_dkhesap_gunluk_bakiye den ilgili tarih bulunacak sekilde degistirildi.
	 SELECT COUNT(*)
	 into ln_adet
	 FROM cbs_dkhesap_gunluk_bakiye   --sevalb 090405
     WHERE     bolum_kodu = ps_sube_kodu and
	 		   numara = decode(ps_doviz,pkg_genel.lc_al,'10011300','10012300')
		       and doviz_kod=ps_doviz
			   and to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY')  = pkg_tarih.geri_is_gunu(pd_date);

	  if nvl(ln_adet,0) <> 0 then
				 SELECT BAKIYE
				 INTO ln_bakiye
				 FROM cbs_dkhesap_gunluk_bakiye   --sevalb 090405
				 WHERE  bolum_kodu = ps_sube_kodu and
				 	   numara = decode(ps_doviz,pkg_genel.lc_al,'10011300','10012300')
				       and doviz_kod=ps_doviz
					   and to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY')  = pkg_tarih.geri_is_gunu(pd_date);  --sevalb 090405

	  else

	 	         SELECT BAKIYE
				 INTO ln_bakiye
				 FROM cbs_dkhesap_gunluk_bakiye   --sevalb 090405
				 WHERE  bolum_kodu = ps_sube_kodu and
				 	   numara = decode(ps_doviz,pkg_genel.lc_al,'10011300','10012300')
				       and doviz_kod=ps_doviz
					   and to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY')  =
					   	   (select max(to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY') )
						    FROM cbs_dkhesap_gunluk_bakiye   --sevalb 090405
						    WHERE  bolum_kodu = ps_sube_kodu and
								  numara = decode(ps_doviz,pkg_genel.lc_al,'10011300','10012300')
				       			  and doviz_kod=ps_doviz
								  and  to_date(gun ||'/'|| ay || '/' || yil,'DD/MM/YYYY')  <pkg_tarih.geri_is_gunu(pd_date)  );
	 end if;

	 RETURN nvl(NVL(ln_bakiye,0)/1000,0);
	 Exception   when
	 			 others then  return 0;
END;
FUNCTION DepositToplamAl(pd_date1 date,pd_date2 date,ps_doviz CBS_DKHESAP.DOVIZ_KOD%TYPE,ps_sube CBS_VW_CASH_CODE_REPORT.SUBE_KODU%TYPE) RETURN NUMBER
is
		 ln_deposit_toplam				   NUMBER;
BEGIN
     IF ps_doviz = pkg_genel.lc_al THEN
	     SELECT SUM(lc_tutar)
		 INTO ln_deposit_toplam
		 FROM CBS_VW_CASH_CODE_REPORT
		 WHERE doviz_kod = ps_doviz
		       and sube_kodu = ps_sube
			   and muhasebe_tarihi between pd_date1 and pd_date2
			   and karakter='D' ;
	 ELSE
		 SELECT SUM(dv_tutar)
		 INTO ln_deposit_toplam
		 FROM CBS_VW_CASH_CODE_REPORT
		 WHERE doviz_kod = ps_doviz
  		       and sube_kodu = ps_sube
			   and muhasebe_tarihi between pd_date1 and pd_date2
			   and karakter='D' ;
     END IF;
	 RETURN nvl(NVL(ln_deposit_toplam,0)/1000,0);
END;
FUNCTION WithdrwToplamAl(pd_date1 date,pd_date2 date,ps_doviz CBS_DKHESAP.DOVIZ_KOD%TYPE,ps_sube CBS_VW_CASH_CODE_REPORT.SUBE_KODU%TYPE) RETURN NUMBER
is
		 ln_Withdrw_toplam				   NUMBER;
BEGIN

   IF ps_doviz = pkg_genel.lc_al THEN
			 SELECT SUM(lc_tutar)
			 INTO ln_Withdrw_toplam
			 FROM CBS_VW_CASH_CODE_REPORT
			 WHERE doviz_kod = ps_doviz
         	       and sube_kodu = ps_sube
				   and muhasebe_tarihi between pd_date1 and pd_date2
				   and karakter='W' ;
   ELSE
            SELECT SUM(dv_tutar)
			 INTO ln_Withdrw_toplam
			 FROM CBS_VW_CASH_CODE_REPORT
			 WHERE doviz_kod = ps_doviz
			       and sube_kodu = ps_sube
				   and muhasebe_tarihi between pd_date1 and pd_date2
				   and karakter='W' ;
   END IF;
	 RETURN nvl(NVL(ln_Withdrw_toplam,0)/1000,0);
END;
FUNCTION DKBitisBakiyeAl(pd_date1 date,pd_date2 date,ps_doviz CBS_DKHESAP.DOVIZ_KOD%TYPE,ps_sube CBS_VW_CASH_CODE_REPORT.SUBE_KODU%TYPE) RETURN NUMBER
is
		 ln_bakiye				   NUMBER;
BEGIN

	 SELECT  decode(a,0,( b - c) , (NVL(A,0) + sign(A)* NVL(B,0)) -1*sign(A)* NVL(C,0))  --sevalb
	 into ln_bakiye
	 FROM(
     SELECT pkg_cash_code_rpt.DKBaslangicBakiyeAl(ps_sube,pd_date1,ps_doviz) A,
            pkg_cash_code_rpt.DepositToplamAl(pd_date1,pd_date2,ps_doviz,ps_sube) B,
	        pkg_cash_code_rpt.WithdrwToplamAl(pd_date1,pd_date2,ps_doviz,ps_sube) C
	 FROM DUAL	  ) ;


	 RETURN nvl(ln_bakiye,0);
END;
PROCEDURE NoAl(rapor_tip varchar2) IS
 ln_count number;
ln_say number:=1;
ln_doviz_kodu varchar2(3);

cursor cur_1 is
select distinct doviz_kod
from CBS_VW_CASH_CODE_REPORT
where doviz_kod<>pkg_genel.lc_al;

BEGIN

    delete CBS_CASH_CODE_RPT;
	IF rapor_tip ='FC' THEN
			OPEN cur_1;
			FETCH cur_1 INTO ln_doviz_kodu;
		  	WHILE NOT cur_1%NOTFOUND
			LOOP
		              insert into CBS_CASH_CODE_RPT (doviz_kodu,no)
		              select ln_doviz_kodu,ln_say from dual;

					  ln_say := ln_say + 1;


			FETCH cur_1 INTO ln_doviz_kodu;
		    END LOOP;
		    CLOSE cur_1;
    ELSE

	                  insert into CBS_CASH_CODE_RPT (doviz_kodu,no)
		              values(pkg_genel.lc_al,1);
	END IF;

	commit;


END;

END;
/

