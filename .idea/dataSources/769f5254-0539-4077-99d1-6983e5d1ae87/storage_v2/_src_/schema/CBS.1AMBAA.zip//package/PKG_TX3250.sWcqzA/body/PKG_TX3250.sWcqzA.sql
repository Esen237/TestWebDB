create PACKAGE BODY     "PKG_TX3250" IS
    p_3250_TL_KREDI number;        --LC KREDI
    p_3250_YP_KREDI number;        --YP KREDI
    p_3250_DE_KREDI number;        --D?V?ZE ENDEKSL? KREDI
    p_3250_TUTAR_LC number;        --A?ILI? TUTAR
    p_3250_TUTAR_MUS number;       --MUSTERI KURUNDAN BULUNAN A?ILI? TUTAR
    p_3250_KUR number;               --KUR
    p_3250_TUTAR_FC number;        --A?ILI? TUTAR FC
    p_3250_HESAP_SUBE number;      --HESAP ?UBE
    p_3250_ENDEKS_DOVIZ number;    --ENDEKS DOVIZ KODU
    p_3250_ISLEM_SUBE number;      --ISLEM SUBE
    p_3250_ALACAK_HESAP number;    --ALACAK HESAP NO
    p_3250_ALACAK_SUBE number;    --ALACAK HESAP NO
    p_3250_REFERANS number;        --REFERANS
    p_3250_ISTATISTIK number;      --?STATISTIK KODU
    p_3250_DOVIZ_KODU number;      --DOVIZ KODU
    p_3250_MUS_ACIKLAMA number;    --MUSTERI ACIKLAMA
    p_3250_BNK_ACIKLAMA number;    --BANKA ACIKLAMA
    p_3250_HESAP_NO number;        --HESAP NO
    ps_fis_mesaj                         varchar2(2000);

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_kredi_teklif_satir_numara             number;
   ln_kredi_hesap_tutar                   number;
   ls_kredi_hesap_doviz_kodu               cbs_doviz_kodlari.doviz_kodu%type;
   ls_dk_grup_kod                         cbs_musteri.DK_GRUP_KOD%type;
   ls_modul_tur_kod                         cbs_hesap.modul_tur_kod%type;
   ls_urun_tur_kod                         cbs_hesap.urun_tur_kod%type;
   ls_urun_sinif_kod                     cbs_hesap.urun_sinif_kod%type;
   ls_dk                                   varchar2(2000);
   ls_endeks_doviz_kodu                     cbs_doviz_kodlari.doviz_kodu%type;
   ls_sube                                 cbs_hesap_kredi.sube_kodu%type;
   ln_temp                                 number;
   ln_mus_no                              number;
   ln_sch_faiz_orani                     number;
    ln_doviz_tutari number;
    ln_bakiye number;
-- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    ln_count NUMBER;
    maturity_date_exc     exception;
    real_limit_exc     exception;
    ld_maturity_date CBS_KREDI_TEKLIF_SATIR.maturity_date%TYPE;
    ln_real_limit CBS_KREDI_TEKLIF_SATIR.real_limit%TYPE;
    ls_lim_doviz_kodu CBS_KREDI_TEKLIF_SATIR.doviz_kodu%TYPE;
    ln_tutar CBS_HESAP_KREDI_ISLEM.tutar%TYPE;
    ls_doviz_kodu CBS_HESAP_KREDI_ISLEM.doviz_kodu%TYPE;    
    ls_kull_doviz_kodu CBS_HESAP_KREDI_ISLEM.kullandirim_doviz_kodu%TYPE;   
    ln_disbur_amount NUMBER;
    ln_risk NUMBER;
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    CURSOR islem_cursor IS
                SELECT * from cbs_hesap_kredi_islem
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
    ln_tahsil_hesap_no                      number;  --seval.colak 20022023
    ln_iliskili_hesap_no                    number; --seval.colak 20022023
 
  Begin
   select count(*) into ln_temp
     from cbs_hesap_kredi_taksit_islem
    where tx_no = pn_islem_no;
   if nvl(ln_temp,0) = 0 then
      Raise_application_error(-20100,pkg_hata.getucpointer || '710' || pkg_hata.getucpointer);
   end if;

   select kredi_teklif_satir_numara, tutar, doviz_kodu,
          musteri_no, pkg_musteri.sf_musteri_dk_grup_kod_al(musteri_no),
          modul_tur_kod, urun_tur_kod, urun_sinif_kod,
          endeks_doviz_kodu, sube_kodu
     into ln_kredi_teklif_satir_numara, ln_kredi_hesap_tutar, ls_kredi_hesap_doviz_kodu,
          ln_mus_no, ls_dk_grup_kod,
          ls_modul_tur_kod, ls_urun_tur_kod, ls_urun_sinif_kod,
          ls_endeks_doviz_kodu, ls_sube
     from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no;

   pkg_kredi.sp_kredteklifdurumu_uygunmu(pn_islem_no);

   pkg_teminat.sp_teminat_kontrolsonra(pn_islem_no ,
               ln_kredi_teklif_satir_numara ,
             ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
             ls_endeks_doviz_kodu );

  --1-ana_dk
    PKG_MUHASEBE.DK_BUL(ls_dk_grup_kod, ls_modul_tur_kod, ls_urun_tur_kod,
                        ls_urun_sinif_kod, 1, Null, Null, Null, ls_dk);
    if not pkg_hesap.GECERLIDKHESAP(ls_dk, ls_sube, ls_kredi_hesap_doviz_kodu) then
          Raise_application_error(-20100,pkg_hata.getucpointer || '698' || pkg_hata.getdelimiter || 'Loan Account (1.):' || ls_dk || pkg_hata.getdelimiter || ls_kredi_hesap_doviz_kodu || pkg_hata.getucpointer);
    end if;
   --4-reeskont DK
    PKG_MUHASEBE.DK_BUL(ls_dk_grup_kod, ls_modul_tur_kod, ls_urun_tur_kod,
                        ls_urun_sinif_kod, 4, Null, Null, Null, ls_dk);
    if not pkg_hesap.GECERLIDKHESAP(ls_dk, ls_sube, ls_kredi_hesap_doviz_kodu) then
          Raise_application_error(-20100,pkg_hata.getucpointer || '698' || pkg_hata.getdelimiter || 'Accrual (4.): '|| ls_dk || pkg_hata.getdelimiter || ls_kredi_hesap_doviz_kodu || pkg_hata.getucpointer);
    end if;
   --3-Faiz dk
    PKG_MUHASEBE.DK_BUL(ls_dk_grup_kod, ls_modul_tur_kod, ls_urun_tur_kod,
                        ls_urun_sinif_kod, 2, Null, Null, Null, ls_dk);

/*    if not pkg_hesap.GECERLIDKHESAP(ls_dk, ls_sube, ls_kredi_hesap_doviz_kodu) then
          Raise_application_error(-20100,pkg_hata.getucpointer || '698' || pkg_hata.getdelimiter || 'Interest (2.) : ' || ls_dk || pkg_hata.getdelimiter || ls_kredi_hesap_doviz_kodu || pkg_hata.getucpointer);
    end if;
*/
    if not pkg_hesap.GECERLIDKHESAP(ls_dk, ls_sube, pkg_genel.LC_al) then
          Raise_application_error(-20100,pkg_hata.getucpointer || '698' || pkg_hata.getdelimiter || 'Interest (2.) : ' || ls_dk || pkg_hata.getdelimiter ||pkg_genel.LC_al || pkg_hata.getucpointer);
    end if;

    pkg_kredi.sp_pastdue_dk_tanimlimi(pn_islem_no); --sevalb 240105

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    if row_islem.REZERVASYON_NO is not null then

       ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

       IF row_islem.TUTAR>ln_bakiye THEN --Bakiye Yetersiz..
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
       else
          Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                           pn_islem_no,
                                                           row_islem.TUTAR);
       END IF;
    end if;
    ln_sch_faiz_orani := pkg_scf.Vadeli_sch_faiz_orani(ln_mus_no,
                                                       nvl(ls_endeks_doviz_kodu, ls_kredi_hesap_doviz_kodu),
                                                       ls_modul_tur_kod, ls_urun_tur_kod,
                                                       ls_urun_sinif_kod,
                                                       row_islem.kredi_vade - pkg_muhasebe.banka_tarihi_bul);
    update cbs_hesap_kredi_islem
       set sch_faiz_orani = ln_sch_faiz_orani,
           sch_faiz_tur = 'S'
     where tx_no = pn_islem_no;
     
-- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    select count(*)
    into ln_count
    from cbs_hesap_kredi_islem k,
         cbs_kredi_teklif_limit l,
         cbs_kredi_teklif_satir s,
         cbs_kredi_teklif t
    where k.tx_no = pn_islem_no and
          k.musteri_no = s.musteri_no and
          k.kredi_teklif_satir_numara = s.teklif_satir_no and
          l.teklif_no = s.teklif_no and
          t.teklif_no = s.teklif_no and
          t.durum_kodu = 'A' and          
          (l.mevcut_yenileme_vade < pkg_muhasebe.banka_tarihi_bul or s.tranches = 'Y');
    
    IF ln_count > 0 THEN
        update cbs_hesap_kredi_islem
        set get_extra_approval = 'Y',
            approval_status = 'C'
        where tx_no = pn_islem_no;
    END IF;
              
    select DECODE(nvl(s.tranches, 'N'), 'Y', s.maturity_date, pkg_muhasebe.banka_tarihi_bul),
             s.real_limit,
             s.doviz_kodu,
             k.tutar,
             k.doviz_kodu,
             k.kullandirim_doviz_kodu,
             nvl(m.fc_risk, 0)
             ,k.tahsil_hesap_no, k.iliskili_hesap_no 
    into ld_maturity_date,
            ln_real_limit,
            ls_lim_doviz_kodu,
            ln_tutar,
            ls_doviz_kodu,
            ls_kull_doviz_kodu,
            ln_risk,
            ln_tahsil_hesap_no, ln_iliskili_hesap_no 
    from cbs_hesap_kredi_islem k,
            cbs_kredi_teklif_satir s,
            cbs_kredi_teklif t,
            cbs_musteri_urun_limit m
    where k.tx_no = pn_islem_no and
              k.kredi_teklif_satir_numara = s.teklif_satir_no and
              t.teklif_no = s.teklif_no and
              t.durum_kodu = 'A' and
              t.musteri_no = s.musteri_no and
              m.musteri_no = t.musteri_no and
              m.kredi_teklif_satir_numara = k.kredi_teklif_satir_numara and --m.fc_doviz_kodu = k.doviz_kodu and -- AdiletK 17022017 CQ5744 defect real limit
              m.urun_grub_no = s.kredi_turu;      


--b-o-m seval.colak 18022023
 if  nvl(ln_iliskili_hesap_no,0) <> 0 and  nvl(ln_tahsil_hesap_no,0) = 0   and pkg_hesap.badlistflag(ln_iliskili_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;

 if  nvl(ln_tahsil_hesap_no,0) <> 0 and pkg_hesap.badlistflag(ln_tahsil_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;
--b-o-m seval.colak 18022023

    ln_disbur_amount := Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu,ls_lim_doviz_kodu,NULL, ln_tutar,1,NULL,NULL,'N','A');    
    
    if ln_real_limit is not null and ln_real_limit - ln_risk < ln_disbur_amount then
        raise real_limit_exc;
    end if;
exception 
    when real_limit_exc then
        raise_application_error(-20100,pkg_hata.getucpointer || '4665' || pkg_hata.getdelimiter || pkg_kur.yuvarla(ls_lim_doviz_kodu,ln_disbur_amount) || ' ' || ls_lim_doviz_kodu || pkg_hata.getucpointer);    
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
 End;

  FUNCTION sf_tutarkuryuvarla(pn_tutar NUMBER, ps_doviz VARCHAR2) RETURN NUMBER
  IS
  BEGIN
         IF ps_doviz IS NOT NULL THEN
              RETURN  Pkg_Kur.yuvarla(ps_doviz ,pn_tutar);
        ELSE
         RETURN  0;
        END IF;
  END;
-----------------------------------------------------------------------------
Function kredi_min_max_vade_uygun_mu( pn_kredi_turu number ,pn_odeme_plan_no number) return varchar2
is
    ln_taksit_sayisi    number := 0;
    ln_min_taksit       number := 0;
    ln_max_taksit       number := 0;
Begin
if nvl(pn_odeme_plan_no,0) <> 0  and nvl(pn_kredi_turu,0) <> 0 then 
    select count(*)
    into  ln_taksit_sayisi
    from  cbs_taksit_odeme_plan
    where odeme_plan_no = pn_odeme_plan_no;
   
    pkg_bireysel_kredi.min_max_vade_al(pn_kredi_turu, ln_max_taksit, ln_min_taksit);
   
    if  nvl(ln_taksit_sayisi,0)  between ln_min_taksit and ln_max_taksit then   
        return 'E';
     else 
        return 'H';
    end if;   
  else
        return 'E';  -- mevcut kredi akisinda sorun yasanmamasi icin  odeme plan yok ise return E 
   end if; 
   Exception when others then return 'H';
End;
 ------------------------------------------------------------------------------ 
  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
      Null;      
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;

    /* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_no);
    Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
     null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
        null;
   End;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
    ln_teklif_no    cbs_kredi_teklif.teklif_no%type;
    ls_durum_kodu   cbs_kredi_teklif.durum_kodu%type;
    ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
    ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
  -- B-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date
    extra_approval           exception;
    ln_count                 number;  
    ln_odeme_plan_no            number; -- b-o-m seval.colak 10102021
    ln_accrual_int_accountno    number; 
    ln_accrual_tax_accountno    number; 
    ln_iliskili_hesap_no        number; 
    ls_repayment_type           varchar2(50);
    ls_faiz_siklik_tipi         varchar2(100);
    ld_vade                     date;
    ld_kredi_vade               date;
    ln_tutar                    number; -- e-o-m seval.colak 10102021    
  Begin
    
    select count(*)
    into ln_count
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no and
          get_extra_approval = 'Y' and
          approval_status = 'C' and
          approval_date is null;
    
    if ln_count > 0 then
        raise extra_approval;
    end if;
-- E-O-M AdiletK 08032016 CQ4714, CQ4713 additional approval for tranches and expired renewal date 
 
     pkg_kredi.sp_pastdue_dk_tanimlimi(pn_islem_no); --sevalb 240105
     
     Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no); --seval.colak 10102021
     
     update cbs_hesap_kredi_islem
        set endeks_doviz_tutari=tutar
      where tx_no = pn_islem_no
        and endeks_doviz_kodu is not null;

-- b-o-m seval.colak 10102021
    select faiz_siklik_tipi
          ,odeme_plan_no 
          ,iliskili_hesap_no
          ,tutar
          ,repayment_type
          ,kredi_vade
    into ls_faiz_siklik_tipi 
        ,ln_odeme_plan_no           --seval.colak 10102021
        ,ln_iliskili_hesap_no
        ,ln_tutar 
        ,ls_repayment_type  
        ,ld_kredi_vade     
    from cbs_hesap_kredi_islem
    where tx_no = pn_islem_no;
    
    if ls_faiz_siklik_tipi = 'INSTALLMENT DATE' and nvl(ln_odeme_plan_no,0) = 0 then
       select min(vade_tarih)
       into ld_vade
       from cbs_hesap_kredi_taksit_islem
       where tx_no = pn_islem_no and durum_kodu = 'A' ;

       update cbs_hesap_kredi_islem
       set faiz_tahakkuk_tarihi =ld_vade
       where tx_no = pn_islem_no;
    end if;
        
    if ls_repayment_type = 'INSTALLMENT DATE' and nvl(ln_odeme_plan_no,0) <> 0 then
       select min(vade_tarih)
       into ld_vade
       from cbs_hesap_kredi_taksit_islem
       where tx_no = pn_islem_no  and durum_kodu = 'A'  and nvl(faiz,0) <> 0;
     
        if ld_vade is null then 
           select min(vade_tarih)
           into   ld_vade
           from   cbs_hesap_kredi_taksit_islem
           where  tx_no = pn_islem_no and durum_kodu = 'A' ;
           if  ld_vade is null then 
                ld_vade :=ld_kredi_vade;
           end if;
         end if;
  
       update cbs_hesap_kredi_islem
       set faiz_tahakkuk_tarihi =ld_vade
       where tx_no = pn_islem_no;
    end if;
  -- e-o-m seval.colak 10102021     
  
     pkg_kredi.sp_islemden_kredi_hesap_acilis(pn_islem_no, ln_hesap_no, ls_doviz_kodu);
     
     pkg_kredi_tahsilat.sf_accrual_int_tax_account_open(ln_hesap_no,pn_islem_no );  --seval.colak 29032022 aciyoruz.--seval.colak 17012022 simdilik kapatiyoruz.accrual devreye alindiginda acilacak.

     update cbs_hesap_kredi_taksit_islem
        set hesap_no = ln_hesap_no
      where tx_no = pn_islem_no;

     update cbs_hesap_kredi_ozel_tkst_isl
        set hesap_no = ln_hesap_no
      where tx_no = pn_islem_no;
   -- B-O-M   seval.colak 10102021
   
    if nvl(ln_odeme_plan_no,0) <> 0 then 
        update cbs_odeme_plan
        set kredi_hesap_no = ln_hesap_no,
             durum_kodu ='K',
             kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul 
        where odeme_plan_No = ln_odeme_plan_no;
     end if;
     --E-O-M   seval.colak 10102021 
     

     /* teminat Durum guncellenir */
     pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no,ln_hesap_no, ls_doviz_kodu);
     
     
exception when extra_approval then -- AdiletK CQ4714 extra approval
    raise_application_error(-20100,pkg_hata.getucpointer || '4660' || pkg_hata.getucpointer);    
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ln_cnt                  number;
    ln_odeme_plan_no        number ; --seval.colak 10102021
     ln_faiz_tahakkuk       cbs_hesap_kredi.hesap_no%type;
    ln_vergi_tahakkuk       cbs_hesap_kredi.hesap_no%type;
  Begin
--   Raise_application_error(-20100,pkg_hata.getucpointer || '699' || pkg_hata.getucpointer);

   select hesap_no ,faiz_tahakkuk_hesap_no,vergi_tahakkuk_hesap_no
           ,odeme_plan_no           --seval.colak 10102021
    into ln_hesap_no,ln_faiz_tahakkuk,ln_vergi_tahakkuk
         ,ln_odeme_plan_no           --seval.colak 10102021
    from  cbs_hesap_kredi_islem
    where tx_no = pn_islem_no ;

    select nvl(count(*),0) into ln_cnt
      from cbs_hesap_kredi_taksit
     where hesap_no = ln_hesap_no
       and durum_kodu <> 'A';

    if ln_cnt > 0 then
      Raise_application_error(-20100,pkg_hata.getucpointer || '727' || pkg_hata.getucpointer);
    end if;
  /* hesap durum kodu I iptal statusune cevrilir */

    pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_hesap_no,'I');
    if ln_faiz_tahakkuk is not null then
          pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_faiz_tahakkuk,'I');
    end if;
    if ln_vergi_tahakkuk is not null then
       pkg_kredi.SP_KREDI_HESAP_DURUM_GUNCELLE(ln_vergi_tahakkuk,'I');
    end if;
        
    update cbs_hesap_kredi_taksit
       set durum_kodu = 'I'
     where hesap_no = ln_hesap_no;

    update cbs_hesap_kredi_islem
       set  durum_kodu = 'I'
     where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'I'
     where tx_no = pn_islem_no;
    
 -- B-O-M   seval.colak 10102021
       select odeme_plan_no   
        into ln_odeme_plan_no          
        from cbs_hesap_kredi_islem
        where tx_no = pn_islem_no;
                
    if nvl(ln_odeme_plan_no,0) <> 0 then 
       update cbs_odeme_plan
        set kredi_hesap_no = null,
             durum_kodu ='A',
             kapanis_tarihi = null 
        where odeme_plan_No = ln_odeme_plan_no;
     end if;
   --E-O-M   seval.colak 10102021      
     
     /* teminat Durum guncellenir */
      pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no, 'ACILIS');
      Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);

  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;

    /* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
    Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);

  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

 Procedure Muhasebelesme(pn_islem_no number)
 is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ln_kur                       number;
    ln_maliyet_kur               number;
    ln_fis_no                   number;
 cursor c_0 is
  select *
    from cbs_hesap_kredi_islem
   where tx_no=pn_islem_no;
  r_0 c_0%rowtype;
  Begin
/* islem bilgisi detaylari alinir */
      open c_0;
     fetch c_0 into r_0;
    close c_0;

/*** Liste Deger Atama K?sm? **/
    boolean_list(p_3250_TL_KREDI) := FALSE;
    boolean_list(p_3250_YP_KREDI) := FALSE;
    boolean_list(p_3250_DE_KREDI) := FALSE;
    number_list(p_3250_TUTAR_LC) := 0;
    number_list(p_3250_TUTAR_MUS) := 0;
    number_list(p_3250_KUR) := 0;
    number_list(p_3250_TUTAR_FC) := 0;
    varchar_list(p_3250_HESAP_SUBE) := '';
    varchar_list(p_3250_ENDEKS_DOVIZ) := '';
    varchar_list(p_3250_ISLEM_SUBE) := '';
    varchar_list(p_3250_ALACAK_HESAP) := '';
    varchar_list(p_3250_REFERANS) := '.';
    varchar_list(p_3250_ISTATISTIK) := '';
    varchar_list(p_3250_DOVIZ_KODU) := '';
    varchar_list(p_3250_MUS_ACIKLAMA) := '';
    varchar_list(p_3250_BNK_ACIKLAMA) := '';
    varchar_list(p_3250_HESAP_NO) := '';

    varchar_list(p_3250_BNK_ACIKLAMA) := r_0.musteri_no || '-' || rtrim(pkg_musteri.Sf_Musteri_Adi(r_0.musteri_no)) || ' Disbursement of loan';
    varchar_list(p_3250_MUS_ACIKLAMA) := varchar_list(p_3250_BNK_ACIKLAMA);
    varchar_list(p_3250_HESAP_NO) := r_0.hesap_no;
    varchar_list(p_3250_DOVIZ_KODU) := r_0.doviz_kodu;
    varchar_list(p_3250_HESAP_SUBE) := r_0.sube_kodu;
    varchar_list(p_3250_ENDEKS_DOVIZ) := r_0.endeks_doviz_kodu;
    varchar_list(p_3250_ISLEM_SUBE) := pkg_tx.amir_bolumkodu_al(pn_islem_no); --pkg_baglam.bolum_kodu;
    varchar_list(p_3250_ALACAK_HESAP) := r_0.alacak_hesap_no;
    varchar_list(p_3250_ALACAK_SUBE) := pkg_hesap.HesapSubeAl(r_0.alacak_hesap_no);
    varchar_list(p_3250_REFERANS) := r_0.hesap_no;
    varchar_list(p_3250_ISTATISTIK) :=  r_0.prefix_istatistik_kodu||r_0.doviz_kodu||r_0.istatistik_kodu;

    if r_0.endeks_doviz_kodu is not null then
        --dovize endeksli kredi
        boolean_list(p_3250_DE_KREDI) := TRUE;
        if nvl(r_0.rezervasyon_no,0)= 0 then
        -- o anki BDAK kuru al?n?r
               ln_kur := pkg_kur.dak_to_LC(r_0.endeks_doviz_kodu, 1);
               
        else
        --rezervasyonlu
            pkg_kur_rezervasyon.rezervasyon_alis_bilgisi_al(r_0.rezervasyon_no, ln_kur, ln_maliyet_kur);
            
        end if;

        update cbs_hesap_kredi_islem
           set acilis_kuru =ln_kur,
               son_islem_kuru = ln_kur
         where tx_no=pn_islem_no;

        update cbs_hesap_kredi
           set acilis_kuru =ln_kur,
               son_islem_kuru = ln_kur
         where hesap_no=r_0.hesap_no;

        number_list(p_3250_KUR) := ln_kur;
        number_list(p_3250_TUTAR_FC) := r_0.tutar;
        number_list(p_3250_TUTAR_LC) := pkg_kur.DAK_to_LC(r_0.endeks_doviz_kodu, number_list(p_3250_TUTAR_FC));
        number_list(p_3250_TUTAR_MUS) :=  pkg_kur.yuvarla(pkg_genel.lc_al,
                                                 pkg_kur.doviz_doviz_karsilik(
                                                 p_doviz_kod_1 => varchar_list(p_3250_ENDEKS_DOVIZ)
                                               , p_doviz_kod_2 => pkg_genel.lc_al
                                               , p_tarih => null
                                                 , p_tutar => number_list(p_3250_TUTAR_FC)
                                                 , p_kur_tip  => 1
                                                 , p_kur_deger_1 => number_list(p_3250_KUR)
                                                 , p_kur_deger_2 => 1
                                                 , p_kur_tablo => 'O'
                                                 , p_alis_satis => 'A'));
                                               
     else
         if r_0.doviz_kodu =pkg_genel.lc_al then
          /* LC kredi*/
             boolean_list(p_3250_TL_KREDI) := TRUE;
             number_list(p_3250_KUR) := 1;
             number_list(p_3250_TUTAR_FC) := r_0.tutar;
             number_list(p_3250_TUTAR_LC) := number_list(p_3250_TUTAR_FC);
             number_list(p_3250_TUTAR_MUS) := number_list(p_3250_TUTAR_FC);
             
         else
          /* d?viz kredi*/
                boolean_list(p_3250_YP_KREDI) := TRUE;
             number_list(p_3250_KUR) := pkg_kur.DAK_to_LC(varchar_list(p_3250_DOVIZ_KODU),1);
             number_list(p_3250_TUTAR_FC) := r_0.tutar;
             number_list(p_3250_TUTAR_LC) := pkg_kur.DAK_to_LC(varchar_list(p_3250_DOVIZ_KODU),number_list(p_3250_TUTAR_FC));
             number_list(p_3250_TUTAR_MUS) := number_list(p_3250_TUTAR_LC);

             update cbs_hesap_kredi_islem
                set acilis_kuru =number_list(p_3250_KUR),
                    son_islem_kuru = number_list(p_3250_KUR)
              where tx_no=pn_islem_no;

             update cbs_hesap_kredi
                set acilis_kuru =number_list(p_3250_KUR),
                    son_islem_kuru = number_list(p_3250_KUR)
              where hesap_no=r_0.hesap_no;

          end if;
     end if;
     
/* kredi hesap acilis muhasebesi calistirilir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(3250,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            null);


     pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);

    pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no, ln_fis_no);


  Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '507' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;


BEGIN
    p_3250_TL_KREDI := pkg_muhasebe.parametre_index_bul('3250_TL_KREDI');
    p_3250_YP_KREDI := pkg_muhasebe.parametre_index_bul('3250_YP_KREDI');
    p_3250_DE_KREDI := pkg_muhasebe.parametre_index_bul('3250_DE_KREDI');
    p_3250_TUTAR_LC := pkg_muhasebe.parametre_index_bul('3250_TUTAR_LC');
    p_3250_TUTAR_MUS := pkg_muhasebe.parametre_index_bul('3250_TUTAR_MUS');
    p_3250_KUR := pkg_muhasebe.parametre_index_bul('3250_KUR');
    p_3250_TUTAR_FC := pkg_muhasebe.parametre_index_bul('3250_TUTAR_FC');
    p_3250_HESAP_SUBE := pkg_muhasebe.parametre_index_bul('3250_HESAP_SUBE');
    p_3250_ENDEKS_DOVIZ := pkg_muhasebe.parametre_index_bul('3250_ENDEKS_DOVIZ');
    p_3250_ISLEM_SUBE := pkg_muhasebe.parametre_index_bul('3250_ISLEM_SUBE');
    p_3250_ALACAK_HESAP := pkg_muhasebe.parametre_index_bul('3250_ALACAK_HESAP');
    p_3250_REFERANS := pkg_muhasebe.parametre_index_bul('3250_REFERANS');
    p_3250_ISTATISTIK := pkg_muhasebe.parametre_index_bul('3250_ISTATISTIK');
    p_3250_DOVIZ_KODU := pkg_muhasebe.parametre_index_bul('3250_DOVIZ_KODU');
    p_3250_MUS_ACIKLAMA := pkg_muhasebe.parametre_index_bul('3250_MUS_ACIKLAMA');
    p_3250_BNK_ACIKLAMA := pkg_muhasebe.parametre_index_bul('3250_BNK_ACIKLAMA');
    p_3250_HESAP_NO := pkg_muhasebe.parametre_index_bul('3250_HESAP_NO');
    p_3250_ALACAK_SUBE:= pkg_muhasebe.parametre_index_bul('3250_ALACAK_SUBE');
END ;
/

