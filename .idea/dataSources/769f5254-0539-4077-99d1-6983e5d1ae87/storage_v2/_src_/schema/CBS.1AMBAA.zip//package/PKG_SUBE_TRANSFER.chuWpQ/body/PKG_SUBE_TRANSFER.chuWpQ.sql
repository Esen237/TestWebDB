create PACKAGE BODY PKG_SUBE_TRANSFER IS

 Function urun_sinif_send return varchar2
 is
 Begin
   return 'SENDING';
 End;

 Function urun_sinif_receive return varchar2
 is
 Begin
   return 'RECEIVING';
 End;

  PROCEDURE sp_transfer_isleme_at (pn_transfer_no  	    CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
  			   			           pn_tx_no 	  		CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE,
								   pn_islem_tanim_kod   CBS_KASA_SUBE_TRANSFER.islem_kod%TYPE DEFAULT 1611,
								   ps_urun_sinif		CBS_KASA_SUBE_TRANSFER.urun_sinif_kod%TYPE
								  )
 is
 ln_tx_no number;

  cursor cur_islem  is
	select * from cbs_kasa_sube_trnsf_det_islem
	where tx_no = ln_tx_no;

 Begin

 	  insert into cbs_kasa_sube_transfer_islem(tx_no, transfer_no, modul_tur_kod, urun_tur_kod, urun_sinif_kod, durum_kodu, kasa_kodu, gonderen_sube_kodu,
	  		 	  							  alici_sube_kodu, kullanici_kodu, banka_tarihi,  islem_kod, transfer_edilen_kisi, nufus_seri_no,
											  verildigi_yer, verildigi_tarih)
	  select pn_tx_no, transfer_no, modul_tur_kod, urun_tur_kod, nvl(ps_urun_sinif,urun_sinif_kod), durum_kodu, kasa_kodu,
	  		 gonderen_sube_kodu,alici_sube_kodu, kullanici_kodu, banka_tarihi,  pn_islem_tanim_kod  ,
	  		 transfer_edilen_kisi, nufus_seri_no, verildigi_yer, verildigi_tarih
	 from cbs_kasa_sube_transfer
	  where transfer_no = pn_transfer_no ;

	  insert into cbs_kasa_sube_trnsf_det_islem(tx_no, transfer_no, doviz_kodu, tutar,gonderilen_tutar)
	  select pn_tx_no, transfer_no, doviz_kodu, tutar ,tutar
	  from cbs_kasa_sube_transfer_detay
	  where transfer_no = pn_transfer_no ;
 End;

 FUNCTION Sf_Bitmemis_Islem_VarMi(pn_transfer_no  	    CBS_KASA_SUBE_TRANSFER_ISLEM.transfer_no%TYPE,
  			   			          pn_tx_no 	  			CBS_KASA_SUBE_TRANSFER_ISLEM.tx_no%TYPE) return number
 IS

    ln_tx_no   CBS_ISLEM.numara%TYPE  := 0;
	onayda_bekleyen_islem_var 		 EXCEPTION;
  BEGIN
	   SELECT  MAX(tx_no)
	   INTO    ln_tx_no
	   FROM   cbs_kasa_sube_transfer_islem a , CBS_ISLEM b
	   WHERE  a.transfer_no = pn_transfer_no AND
	   		  a.tx_no = b.numara AND
			  a.tx_no <> pn_tx_no AND
			  Pkg_Tx.ISLEM_BITMIS_MI(b.numara)= 0 ;

	   IF  NVL(ln_tx_no,0) <> 0 THEN
	   	   RAISE 	onayda_bekleyen_islem_var;
	   END IF;

	   RETURN ln_tx_no ;

    EXCEPTION
	  WHEN OTHERS THEN
  	   	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '456' ||Pkg_Hata.getdelimiter|| ln_tx_no  || Pkg_Hata.getdelimiter ||  Pkg_Hata.getUCPOINTER);
	END;


END;
/

