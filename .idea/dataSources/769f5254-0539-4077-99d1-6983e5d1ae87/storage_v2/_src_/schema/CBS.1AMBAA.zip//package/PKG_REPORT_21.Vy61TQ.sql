create PACKAGE     pkg_report_21 AS
/******************************************************************************
   NAME:       pkg_report_21
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        12.10.2011  roman.shakirov   1. NBRK reports
   2.0        20.02.2013  sevalb           NBRK reports  
******************************************************************************/  
Function getregionname(pn_region_no in number) return varchar2;
function getRegionNoFromBic(pn_bic in number) return varchar2;
function getRegionNoFromBranch(ps_sube_kodu varchar2) return number;
function nbrk_hesap_mi(ps_external_account_no varchar2 ) return varchar2;
function is_budgetary(ps_payment_code varchar2,ps_external_account_no varchar2 ) return varchar2;
procedure load_21A(pd_start_date in date, pd_end_date in date ,ps_sube_kodu varchar2,pn_log_no out number);
procedure load_21B(pd_start_date in date, pd_end_date in date, ps_sube_kodu varchar2,pn_log_no out number);
procedure load_21C(pd_start_date in date, pd_end_date in date,ps_sube_kodu varchar2,pn_log_no out number);

END pkg_report_21;
/

