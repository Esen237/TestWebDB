create PACKAGE     PKG_TX2311 IS

  PROCEDURE Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir
  PROCEDURE Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  PROCEDURE Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir
  PROCEDURE Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir
  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir 
  PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  PROCEDURE Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir
  PROCEDURE Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  PROCEDURE Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir
  PROCEDURE Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  PROCEDURE Get_Account_Info ( ps_account varchar2,
                              ps_currency varchar2,
                              ps_penalty_basic  out  number,
                              ps_nsp_basic out  number,
                              ps_total_amount_basic out  number,
                              ps_penalty_interest out  number,
                              ps_nsp_interest out  number,
                              ps_total_amount_interest out  number);
                              
  PROCEDURE Entering_Ovd_Disb_Income (pn_tx_no number);                            
  PROCEDURE Counting_OVD(ps_account varchar2);  
  PROCEDURE Counting_Days(pd_final date,ps_account varchar2);
  PROCEDURE Update_Penalty (pd_final date,ps_account VARCHAR2);         
  PROCEDURE Calculate_Penalty (pn_tx_no_disb NUMBER, 
                             pn_tx_no_income NUMBER, 
                             ps_account VARCHAR2, 
                             pn_amount_disb NUMBER, 
                             pn_balance_disb NUMBER, 
                             pn_amount_income NUMBER,
                             pn_balance_income NUMBER, 
                             ps_currency VARCHAR2, 
                             pd_transdate_disb DATE, 
                             pd_transdate_income DATE, 
                             pn_count_day NUMBER); 
  PROCEDURE Count_Penalties(pd_final date,ps_account varchar2);                                                    
  PROCEDURE Update_Overdraft_Period (pd_final DATE,ps_account VARCHAR2);
  PROCEDURE Calculate_Interest_Penalty (ps_account VARCHAR2,pd_final DATE);
  PROCEDURE Customer_Account_Type (ps_account VARCHAR2,ps_account_number OUT VARCHAR2,ps_residency_code OUT VARCHAR2,ps_customer_type OUT VARCHAR2, ps_citizen_code OUT VARCHAR2,pn_nakit_kodu OUT NUMBER); 
  PROCEDURE Overdraft_Transaction(pn_islem_no NUMBER,ps_account VARCHAR2); 
  PROCEDURE Account_Blocking(ps_account varchar2);
  PROCEDURE Account_Unblocking(ps_account VARCHAR2);                           
  PROCEDURE Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  PROCEDURE COMPANY(ps_kod VARCHAR2);
  END;

/

