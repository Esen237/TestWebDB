create PACKAGE BODY Pkg_Eft_Mesaj_Gelen_Yap IS

 gs_satir_sonu VARCHAR2(2) := '@#'; --chr(13)||chr(10);
 gs_item_sonu  VARCHAR2(1) := '|'; --chr(7);
/* *********************************************************************************** */
 FUNCTION tarih_alan_degeri_al(pn_islem_no NUMBER, ps_tablo_adi VARCHAR2, ps_kolon_adi VARCHAR2) RETURN DATE IS
 ls_sql VARCHAR2(200);
 ls_deger DATE;
   BEGIN
     ls_sql := 'select ' || ps_kolon_adi || ' from ' || ps_tablo_adi || ' where tx_no = ' || pn_islem_no;
       EXECUTE IMMEDIATE ls_sql INTO ls_deger;
   RETURN ls_deger;
   EXCEPTION
     WHEN OTHERS  THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '119' || Pkg_Hata.getDELIMITER || pn_islem_no || Pkg_Hata.getDELIMITER || ps_kolon_adi || Pkg_Hata.getDELIMITER || ps_tablo_adi || Pkg_Hata.getUCPOINTER);
 END;
/* *********************************************************************************** */
 FUNCTION alan_degeri_al(pn_islem_no NUMBER, ps_tablo_adi VARCHAR2, ps_kolon_adi VARCHAR2) RETURN VARCHAR2 IS
 ls_sql VARCHAR2(200);
 ls_deger VARCHAR2(100);
   BEGIN
     ls_sql := 'select ' || ps_kolon_adi || ' from ' || ps_tablo_adi || ' where tx_no = ' || pn_islem_no;
       EXECUTE IMMEDIATE ls_sql INTO ls_deger;
     RETURN ls_deger;
   EXCEPTION
     WHEN OTHERS  THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '119' || Pkg_Hata.getDELIMITER || pn_islem_no || Pkg_Hata.getDELIMITER || ps_kolon_adi || Pkg_Hata.getDELIMITER || ps_tablo_adi || Pkg_Hata.getUCPOINTER);
 END;
/* *********************************************************************************** */
 FUNCTION mesaj_uzunluk_al(ps_mesaj_kod VARCHAR2) RETURN NUMBER IS
  ln_uzunluk NUMBER;
 BEGIN
	  SELECT SUM(uzunluk)
	    INTO ln_uzunluk
		FROM CBS_EFT_MESAJ_ALANLARI
	   WHERE mesaj_kodu = ps_mesaj_kod;
      RETURN ln_uzunluk;
 END;
/* *********************************************************************************** */
 FUNCTION satir_uzunluk_al(ps_mesaj_kod VARCHAR2, pn_satir NUMBER) RETURN NUMBER IS
  ln_uzunluk NUMBER;
 BEGIN
	  SELECT SUM(uzunluk)
	    INTO ln_uzunluk
		FROM CBS_EFT_MESAJ_ALANLARI
	   WHERE mesaj_kodu = ps_mesaj_kod
	     AND satir_pos = pn_satir;
	  IF NVL(ln_uzunluk,0) = 0 THEN
	     ln_uzunluk := 50;
	  END IF;
      RETURN ln_uzunluk;
 END;
/* *********************************************************************************** */
 PROCEDURE mesaj_olustur (pn_islem_no IN NUMBER) IS

 CURSOR cur_mesaj(ps_mesaj_kodu VARCHAR2) IS
       SELECT tnm.mesaj_kodu, aln.field_kodu, aln.baslik_veri, aln.sira, aln.tipi,
              aln.satir_pos, aln.sutun_pos, aln.ilk_col, aln.bicim,
              aln.sabit_uzunlukta, aln.uzunluk, aln.default_deger, aln.zorunlu,
              aln.tablo_adi, aln.kolon_adi, aln.degeri_veren
         FROM CBS_EFT_MESAJ_TANIM tnm, CBS_EFT_MESAJ_ALANLARI aln
        WHERE tnm.mesaj_kodu = ps_mesaj_kodu
		  AND tnm.mesaj_kodu = aln.mesaj_kodu
	 ORDER BY aln.sira;
 ls_mesaj_kod     CBS_EFT.mesaj_kodu%TYPE;
 TYPE typEftMesaji IS TABLE OF VARCHAR2(52) INDEX BY BINARY_INTEGER;
 lv_satirlar typEftMesaji;
 ls_deger VARCHAR2(100);
 ld_deger DATE;
 ls_mesaj CBS_EFT_MESAJ_LOG.mesaj%TYPE;
 ln_uzunluk NUMBER;

 BEGIN
    --done := -1;
	ls_mesaj := '';
    BEGIN
     SELECT mesaj_kodu
	   INTO ls_mesaj_kod
	   FROM CBS_EFT
	  WHERE tx_no = pn_islem_no
	  FOR UPDATE;
    EXCEPTION
	  WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '117' || Pkg_Hata.getDELIMITER || pn_islem_no || Pkg_Hata.getUCPOINTER);
    END;
	-- islemi buldu mesaj kodunu ald?.
	FOR i IN 1..10 LOOP
	   lv_satirlar(i) := '';
	END LOOP;
	FOR row_mesaj IN cur_mesaj(ls_mesaj_kod) LOOP
      IF row_mesaj.degeri_veren = 'AB' THEN -- aktar?c? bilgisayar taraf?ndan veriliyorsa
			    lv_satirlar(row_mesaj.satir_pos) := lv_satirlar(row_mesaj.satir_pos) || row_mesaj.default_deger;
	  ELSIF row_mesaj.degeri_veren IN ('SIS', 'KLN') THEN -- kullan?c? taraf?ndan giriliyor veya sistemimiz taraf?ndan veriliyorsa
	     IF row_mesaj.tipi = 'T' THEN
		   ld_deger := tarih_alan_degeri_al(pn_islem_no, row_mesaj.tablo_adi, row_mesaj.kolon_adi);
		 ELSE
		   ls_deger := alan_degeri_al(pn_islem_no, row_mesaj.tablo_adi, row_mesaj.kolon_adi);
		 END IF;
   		 IF row_mesaj.sabit_uzunlukta = 'E' THEN -- sabit uzunlukta ise
		    IF row_mesaj.tipi = 'K' THEN --karakter ise
			   ls_deger := RPAD(NVL(ls_deger,' '), row_mesaj.uzunluk);
			ELSIF row_mesaj.tipi = 'S' THEN --say? ise
			   ls_deger := LPAD(NVL(ls_deger,'0'), row_mesaj.uzunluk, '0');
			ELSIF  row_mesaj.tipi = 'T' THEN --tarih ise
			   ls_deger := TO_CHAR(ld_deger, row_mesaj.bicim);
			END IF;
		 END IF;
		-- gerekli format verildi ?imdi yerine koy.
		    lv_satirlar(row_mesaj.satir_pos) := lv_satirlar(row_mesaj.satir_pos) || ls_deger;
	  ELSE
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '118' || Pkg_Hata.getDELIMITER || pn_islem_no || Pkg_Hata.getUCPOINTER);
	  END IF;
   	END LOOP;
	FOR i IN 1..10 LOOP
	  ln_uzunluk := satir_uzunluk_al(ls_mesaj_kod, i);
	  IF lv_satirlar(i) IS NULL THEN
	     lv_satirlar(i) := ' ';
	  END IF;
	  ls_mesaj := ls_mesaj || RPAD(lv_satirlar(i),ln_uzunluk);
	END LOOP;

	INSERT INTO CBS_EFT_MESAJ_LOG (baslik_1, baslik_2, baslik_3, baslik_4,
	                               veri_1, veri_2, veri_3, veri_4, veri_5, veri_6,
								   gelen_giden, durum, giris_islem_no, mesaj)
						   VALUES (lv_satirlar(1), lv_satirlar(2), lv_satirlar(3), lv_satirlar(4),
						           lv_satirlar(5), lv_satirlar(6), lv_satirlar(7), lv_satirlar(8),
								   lv_satirlar(9), lv_satirlar(10),
								   'GIDEN', '2.ONAY', pn_islem_no, ls_mesaj);
	--done := 1;
 END;
/* *********************************************************************************** */
 FUNCTION gelen_islem_kod_al (ps_mesaj_kod VARCHAR2) RETURN NUMBER IS
  ln_islem NUMBER;
 BEGIN
   SELECT gelen_islem_kod
     INTO ln_islem
	 FROM CBS_EFT_MESAJ_TANIM
	WHERE mesaj_kodu = RTRIM(ps_mesaj_kod);
   RETURN(ln_islem);
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '120' || Pkg_Hata.getDELIMITER || ps_mesaj_kod  || Pkg_Hata.getUCPOINTER);
	 WHEN OTHERS THEN
	    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '121' || Pkg_Hata.getDELIMITER || ps_mesaj_kod  || Pkg_Hata.getUCPOINTER);
 END;
/* *********************************************************************************** */
 PROCEDURE batch_eft_islem_yurut(pn_islem_no NUMBER) IS
 ln_islem_no NUMBER;
 BEGIN
   ln_islem_no := pn_islem_no;
   IF Pkg_Tx.Dogrula_Kontrol(ln_islem_no) THEN		 -- dogrulama gerekiyor
    BEGIN
     Pkg_Tx.dogrula(ln_islem_no,TRUE); 			 	 -- dogrula
     UPDATE CBS_EFT
        SET odeme_dogru_oto = 'E'
      WHERE tx_no = ln_islem_no;
	 COMMIT;		   			   					 --dogrulama sonrasini DB yaz.
	 IF Pkg_Tx.Onay_Kontrol(ln_islem_no) THEN
	   Pkg_Tx.onay(ln_islem_no, TRUE );		 		 --onay gerekiyor o zaman onaylamaya ?al??.
	 END IF;
     UPDATE CBS_EFT
        SET odeme_onay_oto = 'E'
      WHERE tx_no = ln_islem_no;
	 COMMIT;		   			   	 	  			 --onaylad?, onay sonrasini DB yaz.
     UPDATE CBS_EFT
		SET odeme_otomatik = 'E'
	  WHERE tx_no = ln_islem_no;
	 Pkg_Tx.muhasebelestir(ln_islem_no);
	 EXCEPTION   --do?rulayam?yor veya onaylayam?yor veya hata olu?tu burada b?rak
	  WHEN OTHERS THEN
	      NULL;
	END;
   ELSIF Pkg_Tx.Onay_Kontrol(ln_islem_no) THEN     --dogrulama gerekmiyor ama onay gerekiyor
    BEGIN
	 COMMIT;							  			 --do?rulama sonras? yap?lanlar db yaz?ld?
	 Pkg_Tx.onay(ln_islem_no, TRUE );				 --onaylamaya calis
     UPDATE CBS_EFT
        SET odeme_onay_oto = 'E'
	  WHERE tx_no = ln_islem_no;
	 COMMIT;		  			  					 --onay sonrasini DB yaz.
     UPDATE CBS_EFT				   	  				 --onaylad? o zaman muhasebele?tir..
        SET odeme_onay_oto = 'E',
    	    odeme_otomatik = 'E'
	  WHERE tx_no = ln_islem_no;
  	 Pkg_Tx.muhasebelestir(ln_islem_no);
	 EXCEPTION   	--onaylayam?yor veya hata olu?tu burada b?rak
		WHEN OTHERS THEN
	       NULL;
    END;
   ELSE						   			 	 	 --ne dogrulama ne onay gerekiyor. sadece muhasebele?tir..
    BEGIN
     COMMIT;										 --dogrulama ve onay sonrasini DB yaz.
     UPDATE CBS_EFT
	    SET odeme_otomatik = 'E'
	  WHERE tx_no = ln_islem_no;
     Pkg_Tx.muhasebelestir(ln_islem_no);
     EXCEPTION   --muhasebele?tiremiyor veya hata olu?tu burada b?rak
	  WHEN OTHERS THEN
	    NULL;
	END;
   END IF;
 END;
/* *********************************************************************************** */
 PROCEDURE satir_ayir(ps_mesaj_kodu VARCHAR2, ps_insert IN OUT VARCHAR2, ps_values IN OUT VARCHAR2,
                      ps_satir IN VARCHAR2, pn_satir IN NUMBER) IS
 ln_value_sayi NUMBER;
 i             NUMBER;
 ln_uzunluk    NUMBER;
 ls_bicim      CBS_EFT_MESAJ_ALANLARI.bicim%TYPE;
 ls_tipi       CBS_EFT_MESAJ_ALANLARI.tipi%TYPE;
 ls_kolon_adi  CBS_EFT_MESAJ_ALANLARI.kolon_adi%TYPE;
 ls_value      VARCHAR2(80);
 ls_satir      VARCHAR2(80);
 BEGIN
   ls_satir:=ps_satir;

   SELECT MAX(sutun_pos)
     INTO ln_value_sayi
     FROM CBS_EFT_MESAJ_ALANLARI
	WHERE mesaj_kodu = ps_mesaj_kodu
	  AND satir_pos = pn_satir;
   i:= 1;
   WHILE i <= ln_value_sayi LOOP
		SELECT bicim, tipi, kolon_adi, uzunluk
          INTO ls_bicim, ls_tipi, ls_kolon_adi, ln_uzunluk
		  FROM CBS_EFT_MESAJ_ALANLARI
		 WHERE mesaj_kodu = ps_mesaj_kodu
		   AND satir_pos = pn_satir
		   AND sutun_pos = i;
		ls_value := SUBSTR(ls_satir, 1, ln_uzunluk);
		ls_satir := SUBSTR(ls_satir,ln_uzunluk+1);
		IF ls_tipi = 'K' THEN
		    ls_value := '''' || ls_value || '''';
		ELSIF ls_tipi = 'T' THEN
		    IF LTRIM(ls_value) IS NULL THEN
			  ls_value := 'null';
			 ELSE
			  ls_value := 'to_date(''' || ls_value || ''', ''' || ls_bicim || ''')';
			 END IF;
		END IF;
        ps_values := ps_values || ', ' || ls_value;
		ps_insert := ps_insert || ', ' ||ls_kolon_adi;
	  i := i + 1;
   END LOOP;
 END;
/* *********************************************************************************** */
 PROCEDURE mesaj_al IS
  CURSOR cur_gelenler IS
       SELECT * FROM CBS_EFT_MESAJ_LOG
	    WHERE gelen_giden = 'GELEN'
		  AND durum = 'EKLENDI'
		  AND RTRIM(SUBSTR(mesaj,68,9)) NOT IN ('MERB-ACI1', 'MERB-ACI2',
		                                        'MERB-DEF1', 'MERB-DEF2',
												'MERB-DOV1', 'MERB-DOV2',
												'MERB-PAR2', 'MERB-HAVL') --'MERB-PAR1'
	   FOR UPDATE;
  row_gelenler cur_gelenler%ROWTYPE;

  ln_islem_no         NUMBER;
  ls_mesaj_kod        VARCHAR2(9);
  ln_islem_kod        CBS_ISLEM.islem_kod%TYPE;
  lc_modul_tur_kod    CBS_ISLEM.modul_tur_kod%TYPE;
  lc_urun_tur_kod     CBS_ISLEM.urun_tur_kod%TYPE;
  lc_urun_sinif_kod   CBS_ISLEM.urun_sinif_kod%TYPE;
  ln_tutar            CBS_ISLEM.tutar%TYPE;
  lc_bolum_kodu       CBS_ISLEM.amir_bolum_kodu%TYPE;
  lc_doviz_kod        CBS_ISLEM.doviz_kod%TYPE;
  ln_musteri_numara   CBS_ISLEM.musteri_numara%TYPE;
  lc_hesap_numara     CBS_ISLEM.hesap_numara%TYPE;
  lc_kasa_kod         CBS_ISLEM.kasa_kod%TYPE;
  ls_insert_str       VARCHAR2(950);
  ls_values_str       VARCHAR2(950);
  ls_sql 			  VARCHAR2(2000);
  ls_mesaj            CBS_EFT_MESAJ_LOG.mesaj%TYPE;
  ln_uzunluk          NUMBER;
  ls_alan_sube        VARCHAR2(5);
  ln_musteri_no       NUMBER;
  BEGIN
  --Mesajlar? almak i?in EFT kullan?c?s? ile ba?lanmal?
    Pkg_Baglam.yarat('001',0);
	LOOP
     OPEN cur_gelenler;
	 FETCH cur_gelenler INTO row_gelenler;
	 IF cur_gelenler%NOTFOUND THEN
	    CLOSE cur_gelenler;
	    EXIT;
	 ELSE
	  --islem_numarasi belirle
	 ln_islem_no:=Pkg_Tx.islem_no_al;
     ls_mesaj_kod := RTRIM(SUBSTR(row_gelenler.mesaj,68,9)); --mesaj kodu 4. ba?l?k satirinda, 68. s?rada
     ln_islem_kod := gelen_islem_kod_al(ls_mesaj_kod);
     lc_modul_tur_kod  := 'EFT';
     lc_urun_tur_kod   := 'EFTGL';
     lc_urun_sinif_kod := ls_mesaj_kod;
     ln_tutar          := 0;
     lc_bolum_kodu     := Pkg_Baglam.bolum_kodu;
     lc_doviz_kod      := Pkg_Genel.lc_al;

     ls_insert_str := 'TX_NO, GELEN_GIDEN';
     ls_values_str := ln_islem_no || ', ''GELEN''';
	  --parcalay?p, islem yaratip, islem numarasiyla beraber tabloya at
	 ln_uzunluk := mesaj_uzunluk_al(ls_mesaj_kod);
 	 ls_mesaj := RPAD(row_gelenler.mesaj, ln_uzunluk);
	 FOR i IN 1..10 LOOP
	  ln_uzunluk := satir_uzunluk_al(ls_mesaj_kod, i);
	  satir_ayir(ls_mesaj_kod, ls_insert_str, ls_values_str, SUBSTR(ls_mesaj, 1, ln_uzunluk), i);
	  ls_mesaj := SUBSTR(ls_mesaj, ln_uzunluk + 1);
     END LOOP;
 	  ls_sql := 'insert into cbs_eft (' || ls_insert_str || ') values (' || ls_values_str || ')';
      EXECUTE IMMEDIATE ls_sql;

      SELECT NVL(tutar,0), alici_hesap_no, alan_sube_kodu
	    INTO ln_tutar, lc_hesap_numara, ls_alan_sube
	    FROM CBS_EFT
	   WHERE tx_no = ln_islem_no;

      Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                         ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

	  --bu tablodaki durumunu ve alan islem numaras?n? set et
	  UPDATE CBS_EFT_MESAJ_LOG
	     SET durum = 'ALDIM',
          giris_islem_no = ln_islem_no
	   WHERE CURRENT OF cur_gelenler;
	  CLOSE cur_gelenler;
	 --islemin devam?n? sagla
	 IF RTRIM(ls_mesaj_kod) IN ('KRED') THEN  -- otomatik ?deme yap?lacaklar buraya eklenmeli...
	    FOR i IN 1..19 LOOP
		  IF SUBSTR(lc_hesap_numara, i, 1) NOT IN ('0','1','2','3','4',
		                                           '5','6','7','8','9') THEN
             lc_hesap_numara := SUBSTR(lc_hesap_numara, 1, i-1) || '0' || SUBSTR(lc_hesap_numara, i + 1);
		  END IF;
		END LOOP;
		IF Pkg_Hesap.VadesizHesapVar(lc_hesap_numara, Pkg_Genel.lc_al) = FALSE  THEN
    	   --hesap yok....
    	    UPDATE CBS_EFT
			   SET durum = 'USER_INT'
             WHERE tx_no = ln_islem_no;
        	COMMIT;
		ELSE	   		   			   			--hesap_no varsa i?lemin devam?n? getir.
    	    UPDATE CBS_EFT						--?deme yap?lacak hesap numaras?n? set et.
			   SET odeme_musteri_hesap = lc_hesap_numara
             WHERE tx_no = ln_islem_no;
        	COMMIT;
            batch_eft_islem_yurut(ln_islem_no);
		END IF;
	 ELSE                                       --muhasebelesmesi gereken, kontrol olmayan mesajlar buraya eklenecek.
	    BEGIN
         batch_eft_islem_yurut(ln_islem_no);	-- !! D?KKAT !! sys'ye onaylama yetkisi verilmemeli.
		 EXCEPTION								--Aksi halde otomatik ?demeye ?al???r.....
		   WHEN OTHERS THEN
    	   --any error kullan?c? karar?
    	    UPDATE CBS_EFT
			   SET durum = 'USER_INT'
             WHERE tx_no = ln_islem_no;
			COMMIT;
		END;
	 END IF;
	 END IF;
	END LOOP;
	--done := 1;
  END;
/* *********************************************************************************** */
END;
/

