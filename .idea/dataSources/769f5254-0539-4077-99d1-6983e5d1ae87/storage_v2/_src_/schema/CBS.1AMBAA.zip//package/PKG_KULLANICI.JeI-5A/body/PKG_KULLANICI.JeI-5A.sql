create PACKAGE BODY     PKG_KULLANICI IS

  Procedure Coz (	pkodu varchar2,perr out varchar2,	pdurum in out boolean) is
    string varchar2(2000);
  begin
    -- Rol kontrolu yap
    string:= ' Alter user '||pkodu||' Account unlock ';
    pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
  end;
---------------------------------------------------------------------------------------------------
  Procedure Kilitle (	pkodu varchar2,perr out varchar2,pdurum in out boolean) is
    string varchar2(2000);
  begin
    -- Rol kontrolu yap
    string:= ' Alter user '||pkodu||' Account lock ';
    pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
  end;
---------------------------------------------------------------------------------------------------
  Procedure Oldur (	pkodu varchar2,perr out varchar2,pdurum in out boolean) is
    string varchar2(2000);
  begin
    -- Rol kontrolu yap
    string:= ' alter system kill session '||pkodu||' Account unlock ';
    pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
  end;
---------------------------------------------------------------------------------------------------
  Procedure Sifre_degistir (ps_kodu varchar2,ps_eski_sifre varchar2,ps_yeni_sifre varchar2) is
    ps_string 			   varchar2(2000):='';
    ps_durum 			   boolean;
	ps_error			   varchar2(2000):='';
	cursor_ad  INTEGER;
    ret  INTEGER;
	ls_err number;
  begin
    -- Rol kontrolu yap

    ps_string := ' Alter user '||ps_kodu||' identified by '||ps_yeni_sifre||' replace '||ps_eski_sifre;
    log_at('0203',ps_string);
    cursor_ad := dbms_sql.open_cursor;
    dbms_sql.parse(cursor_ad, ps_string, dbms_sql.native);
     ret := dbms_sql.EXECUTE(cursor_ad);
    dbms_sql.close_cursor(cursor_ad);
	exception
	  when others then
         ls_err := sqlCODE;
		 ps_error := sqlerrm;
		 sifre_hata_kontrol(ls_err, ps_error);
--		 log_at(ls_err, sqlerrm);
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '3243' || pkg_hata.getdelimiter || ps_error || pkg_hata.getUCPOINTER);
  end;
---------------------------------------------------------------------------------------------------
  Procedure Sil (	pkodu varchar2,perr out varchar2,pdurum in out boolean) is
    string varchar2(2000);
  begin
    -- Rol kontrolu yap
    string:= ' Drop user '||pkodu;
    pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
  end;
---------------------------------------------------------------------------------------------------
  Procedure Yarat (	pkodu varchar2,psifre varchar2,perr out varchar2,pdurum in out boolean) is
    string varchar2(2000);

   begin
--    string:= ' Create user '||pkodu||' identified by '||psifre||' ';
    string:= ' Create user '||pkodu||' identified by '||'C9'||pkodu||'Z1'||' ';
    pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
    if pdurum = TRUE then
      string:= ' Grant connect to '||pkodu;
      pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
      string:= ' Grant resource to '||pkodu;
      pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
      string:= ' Grant cbs_rol to '||pkodu;
      pkg_genel.pro_exec_dinamik_sql(string,pdurum,perr);
      string:= ' alter user '|| pkodu || ' profile cbs_profile';
      Pkg_Genel.pro_exec_dinamik_sql(string,pdurum,perr);
      string:= ' alter user '|| pkodu || ' password expire';
      Pkg_Genel.pro_exec_dinamik_sql(string,pdurum,perr);
    else
    	raise_application_error(-20100,'1;'||perr);
    end if;

  exception
    when others then
  	raise_application_error(-20100,'1;'||perr);
  end;
---------------------------------------------------------------------------------------------------
  Function Email_al return varchar2 is
    pc_email varchar2(2000);
  Begin
    Select email
	  into pc_email
	 from cbs_kullanici
	where kodu=user;
	return pc_email;
  End;
---------------------------------------------------------------------------------------------------
  Function Yazici_al return varchar2 is
    pc_yazici_adres varchar2(2000);
  Begin
    Select aciklama
	  into pc_yazici_adres
	  from cbs_kullanici,cbs_yazici_tanim yt
	 where kodu=user
	   and rapor_yazici=yt.numara;
	 return pc_yazici_adres;
  End;
---------------------------------------------------------------------------------------------------
  Function PersonelBilgiAl(ps_personno in varchar2) return varchar2 is
	ps_kullanici_adi varchar2(200);
  Begin
    Select k.ADI || ' ' || k.SOYADI
	  into ps_kullanici_adi
	  from cbs_kullanici k
	 where k.PERSONEL_NUMARA=to_number(ps_personno);

	 return ps_kullanici_adi;

  End;
---------------------------------------------------------------------------------------------------
Function GetManagerName(ps_kullanicikodu in varchar2) return varchar2 is
		 ps_kullanici_adi varchar2(200);
BEGIN
		select p.ADI ||' ' || p.SOYADI
		into ps_kullanici_adi
		from cbs_personel p,cbs_kullanici k
		where p.PERSONEL_NUMARA= (select p.MANAGER_NO from cbs_personel pp where pp.PERSONEL_NUMARA=p.PERSONEL_NUMARA)
		and k.KODU=ps_kullanicikodu;

		return ps_kullanici_adi;
END;
---------------------------------------------------------------------------------------------------
Function GetChiefAccountName(ps_kullanicikodu in varchar2) return varchar2 is
		 ps_kullanici_adi varchar2(200);
BEGIN
		select p.ADI ||' ' || p.SOYADI
		into ps_kullanici_adi
		from cbs_personel p,cbs_kullanici k
		where p.PERSONEL_NUMARA= (select p.CHIEF_ACC_NO from cbs_personel pp where pp.PERSONEL_NUMARA=p.PERSONEL_NUMARA)
		and k.KODU=ps_kullanicikodu;

		return ps_kullanici_adi;
END;
---------------------------------------------------------------------------------------------------
  Function KullaniciAdiSoyadi(ps_kodu in varchar2) return varchar2 is
	ps_kullanici_adi varchar2(200);
  Begin
    Select k.ADI || ' ' || k.SOYADI
	  into ps_kullanici_adi
	  from cbs_kullanici k
	 where k.kodu=ps_kodu;

	 return ps_kullanici_adi;
    exception
	 when others then
	   return(null);
  End;
---------------------------------------------------------------------------------------------------
  Function user_status(ps_kodu in varchar2) return varchar2 is
	ps_status varchar2(200);
  Begin
    Select account_status
	  into ps_status
	  from dba_users
	 where username=ps_kodu;

	 return ps_status;
    exception
	 when others then
	   return(null);
  End;
---------------------------------------------------------------------------------------------------
  Function password_expiry(ps_kodu in varchar2) return date is
	pd_date date;
  Begin
    Select expiry_date
	  into pd_date
	  from dba_users
	 where username=ps_kodu;

	 return pd_date;
    exception
	 when others then
	   return(null);
  End;
---------------------------------------------------------------------------------------------------
  Function lock_date(ps_kodu in varchar2) return date is
	pd_date date;
  Begin
    Select lock_date
	  into pd_date
	  from dba_users
	 where username=ps_kodu;

	 return pd_date;
    exception
	 when others then
	   return(null);
  End;
---------------------------------------------------------------------------------------------------
  Function user_profile(ps_kodu in varchar2) return varchar2 is
	ps_status varchar2(200);
  Begin
    Select profile
	  into ps_status
	  from dba_users
	 where username=ps_kodu;

	 return ps_status;
    exception
	 when others then
	   return(null);
  End;
---------------------------------------------------------------------------------------------------
  Procedure yeni_sifre_ver (ps_kodu varchar2, ps_yeni_sifre in out varchar2,
                            ps_mail_from in varchar2 default null, ps_mail_to in varchar2 default null) is
    ps_string 			   varchar2(2000):='';
    ps_durum 			   boolean;
	ps_error			   varchar2(2000):='';
	cursor_ad  integer;
    ret  integer;
	ls_err number;
	ls_email varchar2(2000);
	ret_val boolean;
	ls_adi varchar2(2000);
	ls_soyadi varchar2(2000);
	ls_mesaj varchar2(2000);
    
    /*BOM SURMALII 05.06.2018*/
    ls_json CLOB;
    ls_ret varchar2(3);
    pc_ref CORPINT2.PKG_NOTIFICATION.CURSORREFERENCETYPE;
    /*EOM*/
  begin
    if ps_yeni_sifre is null then
	  ps_yeni_sifre := upper(substr(ps_kodu,1,2));
	  ps_yeni_sifre := ps_yeni_sifre || substr(sys_guid(),2,8);
	end if;
    log_at('asyl14',ps_yeni_sifre);
    ps_string := ' Alter user '||ps_kodu||' identified by C9'||ps_yeni_sifre||'Z1' ;
    cursor_ad := dbms_sql.open_cursor;
    dbms_sql.parse(cursor_ad, ps_string, dbms_sql.native);
     ret := dbms_sql.EXECUTE(cursor_ad);
    dbms_sql.close_cursor(cursor_ad);

     SELECT email, adi, soyadi
   	   INTO ls_email, ls_adi, ls_soyadi
   	   FROM CBS_KULLANICI
   	  WHERE kodu=ps_kodu;

	ls_mesaj :=    ' Dear ' || ls_adi || ' ' || ls_soyadi || ', <br><br>'
	  			|| ' Your password has been changed.  <br>'
				|| ' New password : '|| ps_yeni_sifre || '<br><br>'
				|| ' Please change your password.';

	  --pkg_email.AddToEmailQueue('PASSWORD', 50, 'cbs@demirbank.kg', nvl(ps_mail_to, ls_email),  'Password change request',ls_mesaj);
	  --pkg_email.SendAutoMessages('cbs@demirbank.kg');
      
      /*BOM SURMALII 05.06.2018*/
      ls_json := '{';
      ls_json := ls_json || '"##BODY##":"' || ls_mesaj || '"}';
      --ls_ret := CORPINT2.PKG_NOTIFICATION.SENDHTMLEMAIL(nvl(ps_mail_to, ls_email), 'Password change request', to_char(ls_json), pc_ref);
      /*EOM*/

	exception
	  when others then
         log_at('pass_nur', SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
         ls_err := sqlCODE;
		 ps_error := sqlerrm;
		 sifre_hata_kontrol(ls_err, ps_error);
         Raise_application_error(-20100,pkg_hata.getUCPOINTER || '3243' || pkg_hata.getdelimiter || ps_error || pkg_hata.getUCPOINTER);
  end;
---------------------------------------------------------------------------------------------------
  Procedure expire_password(pkodu varchar2, perr out varchar2, pdurum in out boolean) is
    ps_str varchar2(2000);
  begin
    ps_str:= ' Alter user '|| pkodu ||' password expire ';
    pkg_genel.pro_exec_dinamik_sql(ps_str, pdurum, perr);
  end;
-----------------------------------------------------------------
FUNCTION  kullanici_personel_kodu_al(ps_kullanici_kodu CBS_KULLANICI.KODU%TYPE) RETURN NUMBER IS
	pn_personel_no VARCHAR2(40);
BEGIN
	if ps_kullanici_kodu is not null
	then
		SELECT CBS_KULLANICI.PERSONEL_NUMARA
		INTO pn_personel_no
		FROM CBS_KULLANICI
		WHERE KODU=ps_kullanici_kodu;
	end if;

	RETURN pn_personel_no;

	EXCEPTION
	WHEN OTHERS THEN
	log_at('hakan001',ps_kullanici_kodu);
	RAISE_APPLICATION_ERROR(-20100,SQLERRM);
END;
 ------------------------------------------------------------------------------------
  PROCEDURE kullanici_tanim_kopyala(pn_islemno NUMBER, ps_kullanici_kodu VARCHAR2) IS
    ln_count  NUMBER ;
  BEGIN

    SELECT COUNT(*)
	INTO   ln_count
	FROM   CBS_KULLANICI
	WHERE  kodu = ps_kullanici_kodu ;

	IF ln_count <> 0 THEN

		INSERT INTO CBS_KULLANICI_ISLEM
	    (TX_NO, KODU, SIFRE, ADI, SOYADI, PERSONEL_NUMARA, TUR, DEKONT_YAZICI, RAPOR_YAZICI, PROFIL_KOD,
		 YARATILDIGI_TARIH, YARATAN_KULLANICI_KODU, VERSIYON, AGENT, EMAIL, CALISILAN_BOLUM, GOREV_KODU,
		 RAPOR_SUNUCUSU)
		SELECT  pn_islemno,KODU, SIFRE, ADI, SOYADI, PERSONEL_NUMARA, TUR, DEKONT_YAZICI, RAPOR_YAZICI,
		  		PROFIL_KOD,YARATILDIGI_TARIH, YARATAN_KULLANICI_KODU, VERSIYON, AGENT, EMAIL,
				CALISILAN_BOLUM,GOREV_KODU, RAPOR_SUNUCUSU
		FROM	CBS_KULLANICI
		WHERE   kodu = ps_kullanici_kodu ;

		INSERT INTO CBS_ERISIM_ISLEM
		(TX_NO, KULLANICI_KODU, BOLUM_KODU, BASLANGIC_TARIHI, BITIS_TARIHI, YARATILDIGI_TARIH, YARATAN_KULLANICI_KODU)
		SELECT  pn_islemno,KULLANICI_KODU, BOLUM_KODU, BASLANGIC_TARIHI, BITIS_TARIHI, YARATILDIGI_TARIH,
				YARATAN_KULLANICI_KODU
		FROM    CBS_ERISIM
		WHERE   KULLANICI_KODU = ps_kullanici_kodu ;

		INSERT INTO CBS_ERISIM_ROL_ISLEM
		(TX_NO, ROL_NUMARA, ERISIM_KULLANICI_KODU, BOLUM_KODU, YARATILDIGI_TARIH, YARATAN_KULLANICI_KODU)
		SELECT  pn_islemno,ROL_NUMARA, ERISIM_KULLANICI_KODU, BOLUM_KODU, YARATILDIGI_TARIH, YARATAN_KULLANICI_KODU
		FROM    CBS_ERISIM_ROL
		WHERE   ERISIM_KULLANICI_KODU = ps_kullanici_kodu ;
	ELSE
		INSERT INTO CBS_KULLANICI_ISLEM
	    (TX_NO, KODU)
		VALUES (pn_islemno,ps_kullanici_kodu);

	END IF;

  END;
---------------------------------------------------------------------------------------------------
  procedure sifre_hata_kontrol(ls_err number, ps_error in out varchar2) is
  begin
	  if ls_err = -20001 then
       ps_error := 'CBS-Password and user cannot be the same.';
	  elsif ls_err = -20002 then
	  	 ps_error:= 'CBS-Password must be at least 6 characters.';
	  elsif ls_err = -20003 then
	  	 ps_error:= 'CBS-Password is too simple.';
	  elsif ls_err = -20004 then
	  	 ps_error:= 'CBS-Password must contain at least 1 digit.';
	  elsif ls_err = -20005 then
	  	 ps_error:= 'CBS-Password must contain at least 1 letter.';
	  elsif ls_err = -20006 then
	  	 ps_error:= 'CBS-Password cannot be same as your old password.';
	  elsif ls_err = -20007 then
	  	 ps_error:= 'CBS-There must be at least 3 different characters between old and new passwords.';
	  elsif ls_err = -988 then
	  	 ps_error:= 'CBS-Password must contain at least 1 letter and first character must be a letter.';
	  elsif ls_err = -28007 then
	  	 ps_error:= 'CBS-Old password cannot be used.';
	  elsif ls_err = -28008 then
	  	 ps_error:= 'CBS-Old password is wrong.';
	  end if;
  end;
---------------------------------------------------------------------
-------------------------------------------------------------------
 Function GetSecondPrinter(ps_kullanicikodu in varchar2) return varchar2 is
 		  pc_dekont_yazici					varchar2(50);
 Begin
 	  select aciklama
      into pc_dekont_yazici
      from cbs_kullanici, cbs_yazici_tanim
     where kodu=ps_kullanicikodu
	 and RAPOR_YAZICI=numara;

	 return pc_dekont_yazici;
 End;
---------------------------------------------------------------------------------------------------
  Function PersonelBolumAl(ps_kullanicikodu in varchar2) return varchar2 is
    ps_kullanici_bolum_no varchar2(200);
  Begin
    Select k.CALISILAN_BOLUM
      into ps_kullanici_bolum_no
      from cbs_kullanici k
     where k.kodu=ps_kullanicikodu;

     return ps_kullanici_bolum_no;

  End;
END;
/

