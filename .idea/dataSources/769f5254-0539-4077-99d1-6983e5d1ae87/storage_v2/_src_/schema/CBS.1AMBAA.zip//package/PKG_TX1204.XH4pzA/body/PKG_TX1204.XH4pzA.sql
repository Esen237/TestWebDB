create PACKAGE BODY     PKG_TX1204 IS
	pn_1204_alis_doviz_kod        		  number;
	pn_1204_alis_tutar        	  		  number;
	pn_1204_satis_tutar        	  		  number;
	pn_1204_banka_aciklama        		  number;
	pn_1204_borclu_hesap_sube_kodu        number;
	pn_1204_borclu_hesap_no        		  number;
	pn_1204_alacak_hesap_sube_kodu        number;
	pn_1204_alacak_hesap_no        		  number;
	pn_1204_musteri_aciklama        	  number;
	pn_1204_referans        			  number;
	pn_1204_fis_aciklama        		  number;
	pn_1204_istatistik_kod        		  number;
	pn_1204_satis_doviz_kod        		  number;
	pn_1204_masraf_hesap_sube_kodu        number;
	pn_1204_masraf_hesap_no        		  number;
	pn_1204_masraf_hesap_doviz_kod       number;
	pn_1204_masraf_tutari        		  number;
	pn_1204_alis_tl_tutari        		  number;
	pn_1204_satis_tl_tutari        		  number;
	pn_1204_alis_satis_fark_tutari        number;
	pn_1204_alis_buyuk_satis        	  number;
	pn_1204_alis_kucuk_satis        	  number;
	pn_1204_masraf_dvz_tl        		  number;
	pn_1204_masraf_dvz_yp        		  number;
	pn_1204_masraf_tl_tutar        		  number;
	pn_1204_islem_sube_kodu        		  number;
	pn_1204_bsmv_tl_tutar        		  number;
	pn_1204_bsmv_tutar        			  number;
	pn_1204_alis_kur        			  number;
	pn_1204_satis_kur        			  number;
	pn_1204_masraf_kur        			  number;
	pn_1204_dsb_istatistik_kodu           number;
	pn_1204_dab_istatistik_kodu           number;
	pn_1204_BORC_istatistik_kodu          number;
	pn_1204_alacak_istatistik_kodu        number;
	pn_1204_masraf_istatistik_kodu        number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
    ln_doviz_tutari number;
	ln_bakiye number;

	CURSOR islem_cursor IS
	   	 	SELECT * from CBS_ARBITRAJ_ISLEM
			where TX_NO=pn_islem_no;

	row_islem islem_cursor%ROWTYPE;
	ln_tutar  number := 0;
   Begin

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

	if row_islem.REZERVASYON_NO is not null then

	   ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

	   if PKG_KUR_Rezervasyon.Rezervasyon_Tutar_Turu_Al(row_islem.REZERVASYON_NO) = 'ALIS' then
	   	  ln_tutar :=row_islem.ALIS_TUTARI;
		else
		  ln_tutar :=row_islem.SATIS_TUTARI;
		end if;

		   IF ln_tutar  >ln_bakiye THEN --Bakiye Yetersiz..
		      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
		   else
		      Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
		 		    										  pn_islem_no,
		     												  ln_tutar);
		   END IF;
	end if;

	pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1204',row_islem.ALIS_HESAP_NO);

End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Onay_Sonrasi(pn_islem_no number) is
  Begin
  	 update cbs_arbitraj_islem
	  set MUSTERI_NO=pkg_hesap.HesaptanMusteriNoAl(ALIS_HESAP_NO),
	  	  ISLEM_TARIHI=pkg_muhasebe.Banka_Tarihi_Bul
	  where tx_no=pn_islem_no;
  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
  Begin

	PKG_KUR_REZERVASYON.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
/*     pkg_dab.DAB_IPTAL(pn_islem_no);
     pkg_dsb.DSB_IPTAL(pn_islem_no);
	 */
	 null;
 End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
   pkg_kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;


 Procedure Muhasebelesme(pn_islem_no number) is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
	ls_islem_kod			   cbs_islem.islem_kod%type := '1204';
	ln_fis_no				   cbs_fis.numara%type ;
	ls_alis_doviz_kodu		   cbs_hesap.doviz_kodu%type;
	ls_satis_doviz_kodu		   cbs_hesap.doviz_kodu%type;
	ls_masraf_doviz_kodu	   cbs_hesap.doviz_kodu%type;
	ln_banka_alis_kuru	   	   cbs_kur.dvzalis%TYPE;

	ls_musteri_aciklama        varchar2(2000);
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama            varchar2(2000);

	ls_islem_sube_kodu  	   cbs_hesap.sube_kodu%TYPE;
	ln_masraf_hesap_no		   cbs_hesap.hesap_no%TYPE;
	ls_masraf_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
	ln_alacak_hesap_no		   cbs_hesap.hesap_no%TYPE;
	ls_alacak_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
    ln_borclu_hesap_no		   cbs_hesap.hesap_no%TYPE;
	ls_borclu_hesap_sube_kodu  cbs_hesap.sube_kodu%TYPE;
    ln_alis_musteri		   	   cbs_musteri.musteri_no%type;
    ln_satis_musteri		   cbs_musteri.musteri_no%type;
	ln_alis_tl_tutari   	   cbs_arbitraj_islem.alis_tutari%TYPE;
	ln_alis_tutari   	       cbs_arbitraj_islem.alis_tutari%TYPE;

	ln_satis_tl_tutari	   	   cbs_arbitraj_islem.alis_tutari%TYPE;
	ln_satis_tutari	   	       cbs_arbitraj_islem.alis_tutari%TYPE;
	ln_masraf_tl_tutari	   	   cbs_masraf.alinan%TYPE;
	ln_masraf_tutari	       cbs_masraf.alinan%TYPE;
	ln_bsmv_tutari	   	       cbs_masraf.bsmv%TYPE;
	ln_bsmv_tl_tutari	   	   cbs_masraf.bsmv%TYPE;
	ls_dab_istatistik_kod		varchar2(2000);
	ls_dsb_istatistik_kod		varchar2(2000);
	ls_masraf_istatistik_kod	varchar2(2000);
    ln_rezervasyon_no		    number;
	ln_alis_kuru			    number;
	ln_satis_kuru 			    number;

	cursor islem_cursor is
	   select
		   alis_doviz_kodu,
		   satis_doviz_kodu,
		   nvl(alis_tutari,0) ,
		   nvl(satis_tutari,0)   ,
		   alis_hesap_no  ,
		   Pkg_Hesap.HesaptanSubeAl(alis_hesap_no),
		   satis_hesap_no ,
		   Pkg_Hesap.HesaptanSubeAl(satis_hesap_no),
		   masraf_hesap_no,
		   aciklama ,
		    pkg_tx.Amir_BolumKodu_Al(tx_no) ,
		   Pkg_Hesap.HESAPTANMUSTERINOAL(alis_hesap_no),
		   Pkg_Hesap.HESAPTANMUSTERINOAL(satis_hesap_no),
		   rezervasyon_no 	,
		   alis_kuru,
		   satis_kuru,
   		   TO_CHAR(NVL(prefix_ISTATISTIK_KODU_ALIS,0)) || alis_doviz_kodu  || TO_CHAR(NVL(ISTATISTIK_KODU_ALIS,0)) istatistik_kodu_alis  ,
		   TO_CHAR(NVL(prefix_ISTATISTIK_KODU_SATIS,0)) || satis_doviz_kodu|| TO_CHAR(NVL(ISTATISTIK_KODU_SATIS,0)) istatistik_kodu_satis
	  from cbs_arbitraj_islem a ,
		   cbs_islem c
	  where	a.tx_no = c.numara and
	  	    a.tx_no = pn_islem_no ;
  Begin

    varchar_list(pn_1204_alacak_hesap_no) := NULL;
	varchar_list(pn_1204_alacak_hesap_sube_kodu) := NULL;
	varchar_list(pn_1204_alacak_istatistik_kodu) := NULL;
	varchar_list(pn_1204_alis_doviz_kod) := NULL;
	varchar_list(pn_1204_banka_aciklama) := NULL;
	varchar_list(pn_1204_borclu_hesap_no) := NULL;
	varchar_list(pn_1204_borclu_hesap_sube_kodu) := NULL;
	varchar_list(pn_1204_borc_istatistik_kodu) := NULL;
	varchar_list(pn_1204_dab_istatistik_kodu) := NULL;
	varchar_list(pn_1204_dsb_istatistik_kodu) := NULL;
	varchar_list(pn_1204_fis_aciklama) := NULL;
	varchar_list(pn_1204_islem_sube_kodu) := NULL;
	varchar_list(pn_1204_masraf_hesap_doviz_kod) := NULL;
	varchar_list(pn_1204_masraf_hesap_no) := NULL;
	varchar_list(pn_1204_masraf_hesap_sube_kodu) := NULL;
	varchar_list(pn_1204_masraf_istatistik_kodu) := NULL;
	varchar_list(pn_1204_musteri_aciklama) := NULL;
	varchar_list(pn_1204_referans) := NULL;
	varchar_list(pn_1204_satis_doviz_kod) := NULL;
	number_list(pn_1204_alis_kur):= 0;
	number_list(pn_1204_alis_satis_fark_tutari):= 0;
	number_list(pn_1204_alis_tl_tutari):= 0;
	number_list(pn_1204_alis_tutar):= 0;
	number_list(pn_1204_bsmv_tl_tutar):= 0;
	number_list(pn_1204_bsmv_tutar):= 0;
	number_list(pn_1204_masraf_kur):= 0;
	number_list(pn_1204_masraf_tl_tutar):= 0;
	number_list(pn_1204_masraf_tutari):= 0;
	number_list(pn_1204_satis_kur):= 0;
	number_list(pn_1204_satis_tl_tutari):= 0;
	number_list(pn_1204_satis_tutar):= 0;
	boolean_list(pn_1204_alis_buyuk_satis):= FALSE;
	boolean_list(pn_1204_alis_kucuk_satis):= FALSE;
	boolean_list(pn_1204_masraf_dvz_tl):= FALSE;
	boolean_list(pn_1204_masraf_dvz_yp):= FALSE;
/* islem bilgisi detaylari alinir */
	 if islem_cursor%isopen then
	   close islem_cursor;
	 end if;

  	   open islem_cursor;
	    fetch islem_cursor into
			   ls_alis_doviz_kodu,
			   ls_satis_doviz_kodu,
			   ln_alis_tutari    ,
			   ln_satis_tutari   ,
			   ln_borclu_hesap_no  ,
			   ls_borclu_hesap_sube_kodu,
			   ln_alacak_hesap_no  ,
			   ls_alacak_hesap_sube_kodu,
			   ln_masraf_hesap_no  ,
			   ls_banka_aciklama ,
			   ls_islem_sube_kodu,
			   ln_alis_musteri,
			   ln_satis_musteri ,
			   ln_rezervasyon_no,
			   ln_alis_kuru,
			   ln_satis_kuru,
			   varchar_list(pn_1204_borc_istatistik_kodu),
		       varchar_list(pn_1204_alacak_istatistik_kodu);

	   close islem_cursor;

			 if nvl(ln_rezervasyon_no,0) = 0 or nvl(ln_alis_kuru,0) = 0 or nvl(ln_satis_kuru ,0) = 0 then

			 	--TA:O-N, O-S
		 	  	ln_alis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_alis_doviz_kodu ,pkg_genel.lc_al,null,1,1,null,null,'N','A');
				ln_satis_kuru:=pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,pkg_genel.lc_al,null,1,1,null,null,'N','S');

					update cbs_arbitraj_islem
					set alis_kuru = ln_alis_kuru ,
						satis_kuru = ln_Satis_kuru
					where tx_no = pn_islem_no;
			end if;

    boolean_list(pn_1204_masraf_dvz_tl) := false;
	boolean_list(pn_1204_masraf_dvz_yp) := false;
	boolean_list(pn_1204_alis_buyuk_satis) := false;
	boolean_list(pn_1204_alis_kucuk_satis) := false;

    if nvl(ln_masraf_hesap_no,0) <> 0 then

		select  Pkg_Hesap.HesaptanSubeAl(ln_masraf_hesap_no),
		   		Pkg_Hesap.hesaptandovizkodual(ln_masraf_hesap_no)
		into   ls_masraf_hesap_sube_kodu,
			   ls_masraf_doviz_kodu
		from dual;

		pkg_masraf.masraf_toplamlari ( pn_islem_no, ln_masraf_tutari, ln_bsmv_tutari );

-- masraf hesab?n?n doviz kodu ile al?? doviz kodu farkl? ise
	  if ls_alis_doviz_kodu <> ls_masraf_doviz_kodu  then
	  	 --TA:O-N,O-N
	   	 ln_masraf_tutari := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,ls_masraf_doviz_kodu,null,ln_masraf_tutari,1,null,null,'N','A');
		 ln_bsmv_tutari	  := pkg_kur.doviz_doviz_karsilik(ls_satis_doviz_kodu,ls_masraf_doviz_kodu,null,ln_bsmv_tutari,1,null,null,'N','S');
	  end if;

    end if;

	 if ls_masraf_doviz_kodu = pkg_genel.LC_AL then
		    boolean_list(pn_1204_masraf_dvz_tl) := true ;
	 else
			boolean_list(pn_1204_masraf_dvz_yp) := true ;
	 end if;

/*********** Liste Deger Atama K?sm? ***********/

/**** varchar list ****/
   pkg_parametre.deger('1204_FIS_ACIKLAMA',ls_fis_aciklama);
   pkg_parametre.deger('1204_DAB_ISTATISTIK_KODU',ls_dab_istatistik_kod);
   pkg_parametre.deger('1204_DSB_ISTATISTIK_KODU',ls_dsb_istatistik_kod);
   pkg_parametre.deger('1204_MASRAF_ISTATISTIK_KODU',ls_masraf_istatistik_kod);
  /* istatistik kod eslesme */

   varchar_list(pn_1204_masraf_istatistik_kodu) := ls_masraf_istatistik_kod;

   varchar_list(pn_1204_fis_aciklama) 	        := ls_fis_aciklama ;
   varchar_list(pn_1204_banka_aciklama)         := ls_banka_aciklama;
   varchar_list(pn_1204_musteri_aciklama)       := ls_banka_aciklama; --ls_musteri_aciklama;
   varchar_list(pn_1204_referans) 	   	 		:= to_char(ln_borclu_hesap_no);

   varchar_list(pn_1204_satis_doviz_kod ) 	    := ls_satis_doviz_kodu;
   varchar_list(pn_1204_alacak_hesap_sube_kodu) := ls_alacak_hesap_sube_kodu;
   varchar_list(pn_1204_alacak_hesap_no)        := to_char(ln_alacak_hesap_no);

   varchar_list(pn_1204_alis_doviz_kod ) 	    := ls_alis_doviz_kodu;
   varchar_list(pn_1204_borclu_hesap_sube_kodu) := ls_borclu_hesap_sube_kodu;
   varchar_list(pn_1204_borclu_hesap_no)        := to_char(ln_borclu_hesap_no);

   varchar_list(pn_1204_masraf_hesap_doviz_kod ) := ls_masraf_doviz_kodu;
   varchar_list(pn_1204_masraf_hesap_sube_kodu)  := ls_masraf_hesap_sube_kodu;
   varchar_list(pn_1204_masraf_hesap_no)         := to_char(ln_masraf_hesap_no);

   varchar_list(pn_1204_islem_sube_kodu)  		 := ls_islem_sube_kodu;

/**** number list ****/
   number_list(pn_1204_alis_tutar  ) 	 := ln_alis_tutari ;
   number_list(pn_1204_alis_tl_tutari  ) := pkg_kur.yuvarla(pkg_genel.LC_AL , ln_alis_tutari*ln_alis_kuru);
   number_list(pn_1204_alis_kur ) 	     := ln_alis_kuru;

   number_list(pn_1204_satis_tutar  )   := ln_satis_tutari ;
   number_list(pn_1204_satis_tl_tutari) := pkg_kur.yuvarla(pkg_genel.LC_AL ,ln_satis_tutari * ln_satis_kuru);
   number_list(pn_1204_satis_kur) 		:= ln_satis_kuru;

   if ls_masraf_doviz_kodu is not null then
	   number_list(pn_1204_masraf_tutari  ) := nvl(ln_masraf_tutari,0) ;
	   --TA:O-N
	   number_list(pn_1204_masraf_tl_tutar) := pkg_kur.yuvarla(pkg_genel.LC_AL ,pkg_kur.doviz_doviz_karsilik(ls_masraf_doviz_kodu,pkg_genel.LC_AL,null,ln_masraf_tutari,1,null,null,'N','A'));
	   number_list(pn_1204_masraf_kur) 		:= pkg_kur.doviz_doviz_karsilik(ls_masraf_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A');

	   number_list(pn_1204_bsmv_tutar  )    := nvl(ln_bsmv_tutari,0) ;
	   number_list(pn_1204_bsmv_tl_tutar)   := pkg_kur.yuvarla(pkg_genel.LC_AL ,pkg_kur.doviz_doviz_karsilik(ls_masraf_doviz_kodu,pkg_genel.LC_AL,null,ln_bsmv_tutari,1,null,null,'N','A'));
   end if;

   number_list(pn_1204_alis_satis_fark_tutari ) := pkg_kur.yuvarla(pkg_genel.LC_AL ,abs( number_list(pn_1204_alis_tl_tutari  ) - number_list(pn_1204_satis_tl_tutari))) ;


/* kosul atamalari */

    if  number_list(pn_1204_alis_tl_tutari  ) >= number_list(pn_1204_satis_tl_tutari) then
	    boolean_list(pn_1204_alis_buyuk_satis) := true;
	else
	    boolean_list(pn_1204_alis_kucuk_satis) := true;
    end if;

/* pkg_muhasebe fis_kes fonksiyonu  ile fis kesme tamamlanir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							null,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							0,
							ls_fis_aciklama);

	pkg_muhasebe.muhasebelestir(ln_fis_no);


/* dab duzenle */
/*   pkg_dab.DAB_DUZENLE(PN_TX_NO => pn_islem_no,
	                      PN_MUSTERI_NO => ln_alis_musteri,
						  PS_ISLEM_TIPI => 'N',
						  PS_DOVIZ_EFEKTIF => 'D',
						  PS_DOVIZ_KODU => ls_alis_doviz_kodu,
						  PS_ISTATISTIK_KODU => ls_dab_istatistik_kod,
						  PN_TUTAR =>  number_list(pn_1204_alis_tutar  ),
						  PN_KUR => number_list(pn_1204_alis_kur ),
						  PS_ACIKLAMA =>  varchar_list(pn_1204_musteri_aciklama) ,
						  PS_DOVIZI_SATAN => null);

-- dsb duzenle

   pkg_dsb.DSB_DUZENLE(PN_TX_NO => pn_islem_no,
	                      PN_MUSTERI_NO => ln_satis_musteri,
						  PS_ISLEM_TIPI => 'N',
						  PS_DOVIZ_EFEKTIF => 'D',
						  PS_DOVIZ_KODU => ls_satis_doviz_kodu,
						  PS_ISTATISTIK_KODU => ls_dsb_istatistik_kod,
						  PN_TUTAR =>  number_list(pn_1204_Satis_tutar  ),
						  PN_KUR => number_list(pn_1204_satis_kur ),
						  PS_ACIKLAMA =>  varchar_list(pn_1204_musteri_aciklama) ,
						  PS_DOVIZI_alan => null);

*/
 Exception
   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '448' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);

 End;

BEGIN
	pn_1204_alis_doviz_kod          :=pkg_muhasebe.parametre_index_bul('1204_ALIS_DOVIZ_KOD');
	pn_1204_alis_tutar              :=pkg_muhasebe.parametre_index_bul('1204_ALIS_TUTAR');
	pn_1204_satis_tutar             :=pkg_muhasebe.parametre_index_bul('1204_SATIS_TUTAR');
	pn_1204_banka_aciklama    	    :=pkg_muhasebe.parametre_index_bul('1204_BANKA_ACIKLAMA');
	pn_1204_borclu_hesap_sube_kodu  :=pkg_muhasebe.parametre_index_bul('1204_BORCLU_HESAP_SUBE_KODU');
	pn_1204_borclu_hesap_no         :=pkg_muhasebe.parametre_index_bul('1204_BORCLU_HESAP_NO');
	pn_1204_alacak_hesap_sube_kodu  :=pkg_muhasebe.parametre_index_bul('1204_ALACAK_HESAP_SUBE_KODU');
	pn_1204_alacak_hesap_no 	    :=pkg_muhasebe.parametre_index_bul('1204_ALACAK_HESAP_NO');
	pn_1204_musteri_aciklama 	    :=pkg_muhasebe.parametre_index_bul('1204_MUSTERI_ACIKLAMA');
	pn_1204_referans 			    :=pkg_muhasebe.parametre_index_bul('1204_REFERANS');
	pn_1204_fis_aciklama 		    :=pkg_muhasebe.parametre_index_bul('1204_FIS_ACIKLAMA');
	pn_1204_satis_doviz_kod 	    :=pkg_muhasebe.parametre_index_bul('1204_SATIS_DOVIZ_KOD');
	pn_1204_masraf_hesap_sube_kodu  :=pkg_muhasebe.parametre_index_bul('1204_MASRAF_HESAP_SUBE_KODU');
	pn_1204_masraf_hesap_no 	    :=pkg_muhasebe.parametre_index_bul('1204_MASRAF_HESAP_NO');
	pn_1204_masraf_hesap_doviz_kod  :=pkg_muhasebe.parametre_index_bul('1204_MASRAF_HESAP_DOVIZ_KODU');
	pn_1204_masraf_tutari 			:=pkg_muhasebe.parametre_index_bul('1204_MASRAF_TUTARI');
	pn_1204_alis_tl_tutari 			:=pkg_muhasebe.parametre_index_bul('1204_ALIS_TL_TUTARI');
	pn_1204_satis_tl_tutari 		:=pkg_muhasebe.parametre_index_bul('1204_SATIS_TL_TUTARI');
	pn_1204_alis_satis_fark_tutari  :=pkg_muhasebe.parametre_index_bul('1204_ALIS_SATIS_FARK_TUTARI');
	pn_1204_alis_buyuk_satis 		:=pkg_muhasebe.parametre_index_bul('1204_ALIS_BUYUK_SATIS');
	pn_1204_alis_kucuk_satis 		:=pkg_muhasebe.parametre_index_bul('1204_ALIS_KUCUK_SATIS');
	pn_1204_masraf_dvz_tl 			:=pkg_muhasebe.parametre_index_bul('1204_MASRAF_DVZ_TL');
	pn_1204_masraf_dvz_yp 			:=pkg_muhasebe.parametre_index_bul('1204_MASRAF_DVZ_YP');
	pn_1204_masraf_tl_tutar 		:=pkg_muhasebe.parametre_index_bul('1204_MASRAF_TL_TUTAR');
	pn_1204_islem_sube_kodu 		:=pkg_muhasebe.parametre_index_bul('1204_ISLEM_SUBE_KODU');
	pn_1204_bsmv_tl_tutar 			:=pkg_muhasebe.parametre_index_bul('1204_BSMV_TL_TUTAR');
	pn_1204_bsmv_tutar 				:=pkg_muhasebe.parametre_index_bul('1204_BSMV_TUTAR');
	pn_1204_alis_kur 				:=pkg_muhasebe.parametre_index_bul('1204_ALIS_KUR');
	pn_1204_satis_kur 				:=pkg_muhasebe.parametre_index_bul('1204_SATIS_KUR');
	pn_1204_masraf_kur 				:=pkg_muhasebe.parametre_index_bul('1204_MASRAF_KUR');
	pn_1204_borc_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1204_BORC_ISTATISTIK_KODU');
	pn_1204_alacak_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1204_ALACAK_ISTATISTIK_KODU');
	pn_1204_masraf_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1204_MASRAF_ISTATISTIK_KODU');
	pn_1204_dab_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1204_DAB_ISTATISTIK_KODU');
	pn_1204_dsb_istatistik_kodu :=pkg_muhasebe.parametre_index_bul('1204_DSB_ISTATISTIK_KODU');
END ;
/

