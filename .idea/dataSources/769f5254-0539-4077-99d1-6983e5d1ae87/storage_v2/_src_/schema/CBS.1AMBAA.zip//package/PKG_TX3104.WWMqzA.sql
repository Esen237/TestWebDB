create PACKAGE PKG_TX3104 IS

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 		-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);		-- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);-- Islem iptal edildikten sonra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);			-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);		-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);			-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  		-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);			-- Islemin muhasebelesmesi icin cagrilir
  Procedure bitmemis_iade_var_mi(pd_takas_tarih date, ps_bolum_kodu varchar2, ps_calisan_bolum varchar2, ps_all varchar2);

END;


/

