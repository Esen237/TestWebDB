create PACKAGE     "PKG_TX1710" IS

/******************************************************************************
   Name       : PKG_TX1710
   Created By : Seval Balci
   Date       : 04/02/2013
   Purpose   : Loading of Government accounts in National Bank System from the file
******************************************************************************/

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o gun icinde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir
  FUNCTION  satir_ayir( ps_mesaj IN OUT VARCHAR2 ) RETURN VARCHAR2;
  PROCEDURE sp_dosya_satir_yukle(ps_satir VARCHAR2,pn_tx_no NUMBER,pd_date date ,pn_dosya_no NUMBER ,pn_satir_no NUMBER);
  PROCEDURE sp_dosya_yukle( ps_dosya_adi VARCHAR2  ,pn_tx_no number, ps_hata OUT VARCHAR2,pn_dosya_no OUT NUMBER);
  
  Function Sf_BitmemisIslemVarMi(   pn_islem_no number  ) return number;
  Function to_sayi(ps_sayi varchar2) return number;

END;

/

