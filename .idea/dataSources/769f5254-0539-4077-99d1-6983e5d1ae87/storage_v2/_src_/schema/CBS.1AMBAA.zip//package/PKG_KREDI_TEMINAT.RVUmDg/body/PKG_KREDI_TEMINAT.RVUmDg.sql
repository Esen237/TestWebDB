create PACKAGE BODY PKG_KREDI_TEMINAT IS

  Function  KrediTeminatAltKodAdi(ps_ana_tem_kodu in cbs_teminat_alt_kodlari.TEMINAT_KODU%type,ps_alt_tem_kodu in cbs_teminat_alt_kodlari.TEMINAT_ALT_KODU%type) return varchar2
   is
    ls_aciklama	 cbs_teminat_alt_kodlari.aciklama%type;
  Begin
  	select aciklama
	into   ls_aciklama
	from   cbs_teminat_alt_kodlari
	where  TEMINAT_KODU = ps_ana_tem_kodu
	and  TEMINAT_ALT_KODU = ps_alt_tem_kodu;

	return ls_aciklama ;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2582' || pkg_hata.getUCPOINTER);
  End;

 Function  KrediTeminatAnaKodAdi(ps_ana_tem_kodu in cbs_teminat_kodlari.TEMINAT_KODU%type) return varchar2
   is
    ls_aciklama	 cbs_teminat_kodlari.ACIKLAMA %type;
  Begin
  	select aciklama
	into   ls_aciklama
	from   cbs_teminat_kodlari
	where  TEMINAT_KODU = ps_ana_tem_kodu;

	return ls_aciklama ;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2582' || pkg_hata.getUCPOINTER);
  End;




  Function  KrediTeminatKullanilmismi(pn_musteri_no in cbs_kredi_teminat_tanim.MUSTERI_NO%type,pn_teminat_sira_no in cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type) return varchar2
   is
    ln_kullanim_sayisi	 cbs_teminat.KULLANILAN_TUTAR%type;
  Begin
       select count(*)
     	into   ln_kullanim_sayisi
     	from   CBS_TEMINAT
     	where  musteri_no = pn_musteri_no
     	and  KREDI_TEMINAT_TANIM_SIRA_NO = pn_teminat_sira_no;

     	if ln_kullanim_sayisi>0 then return 'E';
     	else return 'H';
     	end if;

  Exception
	  When Others Then
	    null;
  End;


  Function  KrediTeminatKullanimTutari(pn_musteri_no in cbs_kredi_teminat_tanim.MUSTERI_NO%type,pn_teminat_sira_no in cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type) return number
   is
    ln_toplam_kullanim_tutari	 cbs_teminat.KULLANILAN_TUTAR%type;
  Begin

      if KrediTeminatKullanilmismi(pn_musteri_no,pn_teminat_sira_no)='E' then

       select sum(nvl(KULLANILAN_TUTAR,0))
    	into   ln_toplam_kullanim_tutari
    	from   cbs_teminat
    	where  musteri_no = pn_musteri_no
    	and  KREDI_TEMINAT_TANIM_SIRA_NO = pn_teminat_sira_no
		AND teminat_durumu = 'ACIK';

    	return ln_toplam_kullanim_tutari ;
      else
    	return 0;
      end if;

  Exception
	  When Others Then
	    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2602' || pkg_hata.getUCPOINTER);
  End;

  /******************************************************************************************************************/
  /*   Function Sf_Kredi_Teminat_SiraNo_Al										               			  			*/
  /*   Girilen musteri numaras? baz?nda Kredi Teminat S?ra Numaras? al?n?r 							   */
  /******************************************************************************************************************/
  Function  Sf_Kredi_Teminat_SiraNo_Al(pn_musteri_no cbs_musteri.musteri_no%type ) return cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type
  is
    ln_teminat_sirano   cbs_kredi_teminat_tanim.teminat_sira_no%type;
    ln_kayit_sayisi number;

  Begin

    select count(*)
     into ln_kayit_sayisi
	 from cbs_kredi_teminat_giris
	 where musteri_no=pn_musteri_no;

  if ln_kayit_sayisi>0 then
    select MAX(NVL(TEMINAT_SIRA_NO,0))+1
     into ln_teminat_sirano
	 from cbs_kredi_teminat_giris
	 where musteri_no=pn_musteri_no;

    return ln_teminat_sirano ;
   else
    return 1;
  end if;


	Exception
	when others then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '2644' || pkg_hata.getDelimiter ||to_char('SQLCODE') || SQLERRM ||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);

  End;



END;
/

