create PACKAGE BODY     PKG_INT_ACCOUNT_INQ IS

/***************************************************************************/

--BOM Generals

FUNCTION GetAccountNumberByIban(ps_iban varchar2) RETURN number 
IS
ln_account_no number;
BEGIN
      select hesap_no
         into ln_account_no
             from cbs_hesap
                   where external_hesap_no = ps_iban
                         and durum_kodu = 'A';

      return ln_account_no;

EXCEPTION 
    when too_many_rows then
        return null;
    when no_data_found then 
        return null;
    when others then 
        raise; 
END;

FUNCTION GetIbanByAccount(ps_account_number varchar2) RETURN varchar2 
IS
ln_account_no varchar2(16);
BEGIN
      select external_hesap_no
         into ln_account_no
             from cbs_hesap
                   where hesap_no = to_number(ps_account_number) 
                         and durum_kodu = 'A';

      return ln_account_no;

EXCEPTION 
    when no_data_found then 
        return null;
    when others then 
        raise; 
END;

FUNCTION GetCurrencyCodeByIban(ps_iban varchar2) RETURN varchar2
IS
currency_code varchar2(3);
BEGIN
    select doviz_kodu
            into currency_code
                  from cbs.cbs_hesap 
                     where external_hesap_no = ps_iban
                           and durum_kodu = 'A';
    
    return currency_code;
    
EXCEPTION
    when no_data_found then 
         return null;
    when others then 
        raise; 
END;

FUNCTION GetBranchCodeByAccount(ps_account_number varchar2) RETURN varchar2 
IS
ls_sube_kodu varchar2(10);
ls_count number;
ls_not_found_data exception;
BEGIN
       
   select count(*)  into ls_count  from cbs_vw_hesap_izleme where durum_kodu = 'A' and hesap_no = to_number(ps_account_number);

    if ls_count = 0 then
        raise ls_not_found_data;
    end if;
       
    select sube_kodu  into ls_sube_kodu  from cbs_vw_hesap_izleme where durum_kodu = 'A' and hesap_no = to_number(ps_account_number);
    
    return ls_sube_kodu;

EXCEPTION
     when ls_not_found_data then
         return '454';
     when others then
         raise;
END;

FUNCTION CheckBalanceByIban(ps_iban varchar2,
                            ps_amount varchar2,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS 
ln_account_number number;
ls_returncode varchar2(3) := '000';
BEGIN
     
     open pc_ref for select sysdate from dual;
     
      ln_account_number := getaccountnumberbyiban(ps_iban);
     
      if ln_account_number = 0 then
         return '456';
      end if;
      
      if (pkg_hesap.kullanilabilir_bakiye_al(ln_account_number) < to_number(ps_amount, '99999999999.9999999999999')) then
         return '456';
      end if;

     return ls_returncode;
     
EXCEPTION    
    when no_data_found then 
        return '456';
    when others then 
        raise;  
END;  

FUNCTION CheckJoinAccountByIban(ps_iban varchar2) RETURN boolean
IS
ln_count_join number;
ls_returncode varchar2(3) := '000';
BEGIN
     
   select count(*) into ln_count_join
         from cbs_hesap_ortak_bilgi 
             where ana_hesap_no = getaccountnumberbyiban(ps_iban);
             
    if ln_count_join > 0 then
        return true;
    end if;
     
     return false;
     
EXCEPTION    
    when no_data_found then 
        return false;
    when others then 
        raise;  
END; 


FUNCTION CheckJoinAccountByAccount(ps_account_number varchar2) RETURN boolean
IS
ln_count_join number;
ls_returncode varchar2(3) := '000';
BEGIN
     

    select count(*) into ln_count_join
         from cbs_hesap_ortak_bilgi 
             where ana_hesap_no = to_number(ps_account_number);
             
    if ln_count_join > 0 then
        return true;
    end if;
     
     return false;
     
EXCEPTION    
    when no_data_found then 
        return true;
    when others then 
        raise;  
END; 

--EOM Generals

/***************************************************************************/

--BOM Utility
FUNCTION GetCustomerMatchByIban(ps_customer_id varchar2, 
                                ps_iban varchar2) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_count number;
le_customer_not_found exception;
BEGIN

    ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
    if ln_customer_number is null then
        raise le_customer_not_found;
    end if;
    
    ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
 
    select count(*)
            into ls_count from
       (select external_hesap_no as iban from cbs.cbs_hesap 
                 where musteri_no = ln_customer_number 
                       and external_hesap_no = ps_iban
                       and durum_kodu = 'A'
        union               
             select external_hesap_no as iban from cbs.cbs_hesap 
                 where musteri_no = nvl(ln_customer_number_second, 0)
                       and external_hesap_no = ps_iban
                       and durum_kodu = 'A'
        union
             select ch.external_account_no as iban
                    from cbs_vw_checking_account ch
                           inner join cbs_hesap_ortak_bilgi joinacc
                           on joinacc.ana_hesap_no = ch.account_no
                           where joinacc.ortak_musteri_no = ln_customer_number 
                                 and ch.external_account_no = ps_iban
                                  and ch.status = 'A') a;
    
    return ls_count;
    
EXCEPTION
    when le_customer_not_found then
       return null;
    when no_data_found then 
       return null;
    when others then 
       log_at('GetCustomerMatchByIban', ln_customer_number, ps_iban);
       raise;  
END;

FUNCTION GetCustomerMatchByAccount(ps_customer_id varchar2, 
                                   ps_account_number varchar2) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_count number;
le_customer_not_found exception;
BEGIN

     ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
    if ln_customer_number is null then
        raise le_customer_not_found;
    end if;
    
    ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
  
    select count(*)
            into ls_count from
       (select hesap_no as account_number from cbs_vw_hesap_izleme
                 where musteri_no = ln_customer_number 
                       and hesap_no = to_number(ps_account_number)
        union               
             select hesap_no as account_number from cbs_vw_hesap_izleme
                 where musteri_no = nvl(ln_customer_number_second, 0) 
                       and hesap_no = to_number(ps_account_number)
        union
             select ch.account_no as account_number
                    from cbs_vw_checking_account ch
                           inner join cbs_hesap_ortak_bilgi joinacc
                           on joinacc.ana_hesap_no = ch.account_no
                           where joinacc.ortak_musteri_no = ln_customer_number 
                                 and ch.account_no = to_number(ps_account_number)
                                 and ch.status = 'A') a;

    return ls_count;
    
EXCEPTION
    when le_customer_not_found then
       return null;
    when no_data_found then 
       return null;
    when others then 
       raise;  
END;
--EOM Utility

/***************************************************************************/
/***************************************************************************/

--BOM  Accounts

FUNCTION GetAccountOperationProfile(ps_lang varchar2,
                                    ps_customer_id varchar2,
                                    ps_account_number varchar2,
                                    pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_account_number number;
lb_source_for_saving_account varchar(5 byte) := 'false';
lb_internal_money_transfer varchar(5 byte) := 'false';
lb_allow_clearing varchar(5 byte) := 'false';
lb_allow_swift varchar(5 byte) := 'false';
lb_allow_instant_payment varchar(5 byte) := 'false';
lb_allow_fx_operation varchar(5 byte) := 'false';
lb_allow_atm_qr varchar(5 byte) := 'false';
lb_allow_closing varchar(5 byte) := 'false';
ls_bad_list varchar2(1);
ln_balance number;
ls_currency_code varchar(10);
ls_module_type_code varchar2(10);
ls_product_type_code varchar2(10);
ls_product_class_code varchar2(20);
ln_customer_number number := 0;
ln_count_partner number := 0;
ln_partner_customer number := 0;
ls_partner_status varchar(2 byte);
ls_company_status varchar2(10 byte);
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN     

      ln_account_number := to_number(ps_account_number);
     
      select nvl(badlist_flag, 'H'), doviz_kodu, modul_tur_kod,  urun_tur_kod, urun_sinif_kod, musteri_no
        into ls_bad_list, ls_currency_code, ls_module_type_code, ls_product_type_code, ls_product_class_code, ln_customer_number
            from cbs_hesap
                where hesap_no = ln_account_number;

    
      if ls_bad_list = 'E' or ls_product_class_code in ('OVERBALANCE-LC', 'OVERBALANCE-FC') then
      
          lb_source_for_saving_account := 'false';
          lb_internal_money_transfer := 'false';
          lb_allow_clearing := 'false';
          lb_allow_swift := 'false';
          lb_allow_instant_payment := 'false';
          lb_allow_fx_operation := 'false';
          lb_allow_atm_qr := 'false';
          lb_allow_closing := 'false';
      else 
          lb_source_for_saving_account := 'true';
          lb_internal_money_transfer := 'true';
          lb_allow_clearing := 'true';
          lb_allow_swift := 'true';
          lb_allow_instant_payment := 'true';
          lb_allow_fx_operation := 'true';
          lb_allow_atm_qr := 'true';
          lb_allow_closing := 'true';
         
      end if; 
      
      if ls_currency_code not in ('USD', 'RUB', 'KGS') or ls_product_class_code = 'ELCARD NON INT.BR-LC' then
           lb_source_for_saving_account := 'false';
      end if;
      
      if ls_currency_code not in ('KGS') or ls_product_class_code = 'ELCARD NON INT.BR-LC' then
           lb_allow_clearing := 'false';
           lb_allow_instant_payment := 'false';
      end if;
      
      
      if ls_currency_code not in ('USD', 'EUR') then 
           lb_allow_swift := 'false';
      end if;
 
      
      if ls_currency_code not in ('USD', 'EUR', 'RUB', 'KZT', 'TRY', 'GBP', 'CHF', 'KGS') or ls_product_class_code = 'ELCARD NON INT.BR-LC' then
           lb_allow_fx_operation := 'false';
      end if;
      
      
      if ls_currency_code not in ('USD', 'KGS') or ls_product_class_code = 'ELCARD NON INT.BR-LC' then
           lb_allow_atm_qr := 'false';
      end if;
   


--     if Pkg_debit_Card.hesap_primary_karta_baglimi(ln_account_number) = 'E'  then
          lb_allow_closing := 'false'; 
--     end if;  
  
     ln_partner_customer := pkg_int_customer_inq.GetCustomerNo(ps_customer_id);
      
      
     if ln_partner_customer is null then
        raise le_customer_not_found;
     end if;
  
      
      if ln_partner_customer != ln_customer_number then
      
        begin
            select ortaklik_tipi into ls_partner_status from cbs_hesap_ortak_bilgi 
                            where ana_hesap_no = ln_account_number 
                                  and status = 'ACTIVE';

             if ls_partner_status = 'OX' or ls_partner_status = 'VX' then
                  lb_source_for_saving_account := 'false';
                  lb_internal_money_transfer := 'false';
                  lb_allow_clearing := 'false';
                  lb_allow_swift := 'false';
                  lb_allow_instant_payment := 'false';
                  lb_allow_fx_operation := 'false';
                  lb_allow_atm_qr := 'false';
                  lb_allow_closing := 'false';
             end if;
              lb_allow_closing := 'false';
        exception
            when others then 
              null;
         end;
      end if;
      

      open pc_ref for
                select
                    lb_source_for_saving_account as source_for_saving_account,
                    lb_internal_money_transfer as internal_money_transfer,
                    lb_allow_clearing as allow_clearing,
                    lb_allow_swift as allow_swift,
                    lb_allow_instant_payment as allow_instant_payment,
                    lb_allow_fx_operation as allow_fx_operation,
                    lb_allow_atm_qr as allow_atm_qr,
                    lb_allow_closing as allow_closing
                from dual;
                
    return ls_returncode;
    
EXCEPTION
    when le_customer_not_found then
       return '454';
    when no_data_found then
       return '455';
    when others then 
       log_at('GetAccountOperationProfile', ps_account_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
        raise;   
END;

FUNCTION GetAccountCredits(ps_lang varchar2,
                           ps_account_number varchar2,
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN


    open pc_ref for
             select 
               a.fc_doviz_kodu as currency_code,
               a.urun_grub_no as code,
               e.teklif_tarihi as create_date, 
               f.validity_date_of_line as due_date,        
               a.fc_limit as amount,                                                  
               a.fc_limit - nvl(a.fc_risk, 0) as available_amount, 
               nvl(a.fc_risk, 0) as total_debt_amount, 
               c.ovd_faiz_orani as interest_rate,
               c.ovd_interest_payment_period as period,
               c.ovd_faiz_indikatoru as interest_indicator
             from cbs_musteri b
                        inner join cbs_hesap c on 
                                                  b.musteri_no = c.musteri_no
                                                  and c.overdraft = 'E'
                                                  and c.durum_kodu = 'A'
                                                  and c.hesap_no = to_number(ps_account_number)               
                        inner join cbs_kredi_teklif e on e.musteri_no = b.musteri_no 
                                                  and e.durum_kodu = 'A'
                        inner join cbs_musteri_urun_limit a on 
                                                  a.musteri_no = b.musteri_no    
                                                  and a.fc_limit <> 0
                                                  and a.urun_grub_no in (18,19,20,44,59) 
                                                  and a.fc_doviz_kodu = c.doviz_kodu
                                                  and a.kredi_teklif_satir_numara = c.ovd_proposal_line_no                                                               
                        inner join cbs_kredi_teklif_limit f on e.teklif_no = f.teklif_no;                                                                                                                                                                         

                                                                                                                                                                        
    return ls_returncode;

EXCEPTION
    when others then 
       log_at('GetAccountCredits', ps_account_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
        raise;    
END;

FUNCTION GetAccountPartners(ps_lang varchar2,
                           ps_account_number varchar2,
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN


    open pc_ref for
           select 
              case
                 when m.vergi_no is not null 
                                 then replace(m.vergi_no,' ','')
                 when m.pasaport_no is not null 
                                 then replace(m.pasaport_no,' ','') 
                 when m.nufus_cuzdani_seri_no is not null 
                                 then replace( m.nufus_cuzdani_seri_no,' ','')  
              end customer_id ,
              case
                when ps_lang = 'en' then 
                     substr(decode(musteri_tipi_kod, 
                            '1', isim_eng || decode(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                            '2', isim_eng || decode(' ' || ikinci_isim_eng || ' ','  ',' ',' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                            lokal_unvan), 1, 200)
                when ps_lang = 'ru' then 
                     substr(decode(musteri_tipi_kod, 
                            '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                            '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                            ticari_unvan), 1, 200)
                else
                     substr(decode(musteri_tipi_kod, 
                            '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                            '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                            ticari_unvan), 1, 200)
              end full_name,
              m.musteri_no as customer_number,
              decode(ortaklik_tipi, 'OY', 'fullAccess', 'viewOnly') as partnership_type
              from cbs_hesap_ortak_bilgi j inner join cbs_musteri m
              on m.musteri_no = j.ortak_musteri_no 
              where ana_hesap_no = to_number(ps_account_number) 
          union
          select  
              case
                when m.vergi_no is not null 
                                then replace(m.vergi_no,' ','')
                when m.pasaport_no is not null 
                                then replace(m.pasaport_no,' ','') 
                when m.nufus_cuzdani_seri_no is not null 
                                 then replace( m.nufus_cuzdani_seri_no,' ','')  
              end customer_id,
              case
                    when ps_lang = 'en' then 
                         substr(decode(musteri_tipi_kod, 
                                '1', isim_eng || decode(' ' || ikinci_isim_eng || ' ', '  ', ' ', ' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                                '2', isim_eng || decode(' ' || ikinci_isim_eng || ' ','  ',' ',' ' || ikinci_isim_eng || ' ') || soyadi_eng,
                                lokal_unvan), 1, 200)
                    when ps_lang = 'ru' then 
                         substr(decode(musteri_tipi_kod, 
                                '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                                '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                                ticari_unvan), 1, 200)
                    else
                         substr(decode(musteri_tipi_kod, 
                                '1', isim || decode(' ' || ikinci_isim || ' ', '  ', ' ', ' ' || ikinci_isim || ' ') || soyadi,
                                '2', isim || decode(' ' || ikinci_isim || ' ','  ',' ',' ' || ikinci_isim || ' ') || soyadi,
                                ticari_unvan), 1, 200)
              end full_name,
                   m.musteri_no as customer_number,
                   'fullAccess' as partnership_type
                   from cbs_musteri m
                   where musteri_no = pkg_hesap.hesaptanmusterinoal(to_number(ps_account_number));
                                                                                                                                                         
    return ls_returncode;

EXCEPTION
    when others then 
       log_at('GetAccountPartners', ps_account_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
        raise;    
END;


FUNCTION GetAccountBlokageList(ps_lang varchar2,
                               ps_account_number varchar2,
                               pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

    open pc_ref for
        select
            bloke_neden_kodu as block_code,
            case
              when ps_lang = 'en' then
                 pkg_bloke.sf_bloke_nedeni_al(bloke_neden_kodu)
              else
                 pkg_soa_common.text_translation(pkg_bloke.sf_bloke_nedeni_al(bloke_neden_kodu), 'RUS')
            end block_name,
            aciklama as description,
            kayit_tarih as create_date,
            bloke_bitis_tarihi as due_date,
            bloke_tutari as amount
        from cbs_vw_bloke_izleme
           where hesap_no = to_number(ps_account_number)
                 and durum_kodu = 'A';

    return ls_returncode;

EXCEPTION
    when others then 
      log_at('GetAccountBlokageList', ps_account_number, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
        raise;       
END;


FUNCTION GetAccountTotalBalance(ps_customer_id varchar2,
                                pc_ref OUT CursorReferenceType,
                                pc_ref2 OUT CursorReferenceType,
                                pc_ref3 OUT CursorReferenceType,
                                pc_ref4 OUT CursorReferenceType,
                                pc_ref5 OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

     ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
          
      if ln_customer_number is null then
          raise le_customer_not_found;
      end if;
      

     open pc_ref for
          select b.* 
            from (select a.currency_code as currency_code, 
                  sum(pkg_hesap.kullanilabilir_bakiye_al(account_no)) as total_balance_amount
               from cbs_vw_checking_account a 
               where customer_no = ln_customer_number
                     and status = 'A'
                     and module_type_code = 'CURRENT'
                     and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                     and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                     group by a.currency_code)
                b order by
                     case when currency_code = 'KGS' then 1
                          when currency_code = 'USD' then 2
                          when currency_code = 'EUR' then 3
                          when currency_code = 'KZT' then 4
                          when currency_code = 'TRY' then 5
                     else 6 
                     end;             
         
      open pc_ref2 for
         select b.* 
            from (select a.currency_code as currency_code, 
                  sum(pkg_hesap.kullanilabilir_bakiye_al(account_no)) as total_balance_amount
               from cbs_vw_saving_account a 
               where customer_no = ln_customer_number
                     and status = 'A'
                     group by a.currency_code)
                 b order by
                     case when currency_code = 'KGS' then 1
                          when currency_code = 'USD' then 2
                          when currency_code = 'EUR' then 3
                          when currency_code = 'KZT' then 4
                          when currency_code = 'TRY' then 5
                     else 6 
                     end;      
                        
      open pc_ref3 for
           select b.* 
            from (select a.currency_code as currency_code, 
               sum(balance) as total_balance_amount
               from cbs_vw_credit_account a 
               where customer_no = ln_customer_number
                      and status = 'A'
                      and product_type_code not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL', 'PAST DUE', 'PD-FIXRATE') 
                      and product_class_code not in ('CREDIT CARD-LC', 'CREDIT CARD-FC', 'OVERLIMIT-LC', 'OVERLIMIT-FC')                 
                  group by currency_code)
                b order by
                     case when currency_code = 'KGS' then 1
                          when currency_code = 'USD' then 2
                          when currency_code = 'EUR' then 3
                          when currency_code = 'KZT' then 4
                          when currency_code = 'TRY' then 5
                     else 6 
                     end;  
       
      open pc_ref4 for
           select b.* 
            from (select doviz_kodu as currency_code, 
               sum(pkg_hesap.kullanilabilir_bakiye_al(hesap_no)) as total_balance_amount
               from cbs_vw_hesap_izleme
               where musteri_no = ln_customer_number
                     and durum_kodu = 'A'
                     and (modul_tur_kod = 'TIME DEP.'
                           or (modul_tur_kod = 'CURRENT'
                                  and urun_tur_kod in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                  and urun_sinif_kod not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')))
                      group by doviz_kodu)
                 b order by
                     case when currency_code = 'KGS' then 1
                          when currency_code = 'USD' then 2
                          when currency_code = 'EUR' then 3
                          when currency_code = 'KZT' then 4
                          when currency_code = 'TRY' then 5
                     else 6 
                     end;  
                
       open pc_ref5 for
           select b.* 
            from (select doviz_kodu as currency_code, 
               sum(bakiye) as total_balance_amount 
               from cbs_vw_hesap_izleme
               where musteri_no = ln_customer_number
                     and durum_kodu = 'A'
                     and ((modul_tur_kod = 'LOAN'
                           and urun_tur_kod not in ('LEASING', 'RT-CARD', 'PD-CARD', 'ACCRUAL', 'NONACCRUAL', 'PAST DUE', 'PD-FIXRATE') 
                           and urun_sinif_kod not in ('CREDIT CARD-LC', 'CREDIT CARD-FC', 'OVERLIMIT-LC', 'OVERLIMIT-FC'))
                       or (urun_sinif_kod in ('NON INT.BEARING-FC', 'NON INT.BEARING-LC') and bakiye < 0))
                       group by doviz_kodu)
                 b order by
                     case when currency_code = 'KGS' then 1
                          when currency_code = 'USD' then 2
                          when currency_code = 'EUR' then 3
                          when currency_code = 'KZT' then 4
                          when currency_code = 'TRY' then 5
                     else 6 
                     end;  
                        
             return ls_returncode;
         
EXCEPTION 
    when le_customer_not_found then
         return '454'; 
    when others then 
         raise; 
END; 

FUNCTION GetAccountAvailableCurrencies(ps_lang varchar2,
                                       ps_account_type varchar2,
                                       pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN

   if ps_account_type = 'checking' then
   
        open pc_ref for                 
           select all cbs_doviz_kodlari.doviz_kodu as currency_code,
                cbs_doviz_kodlari.aciklama as currency_name
                     from cbs_doviz_kodlari
                            where decode(doviz_kodu, pkg_genel.lc_al, 'E', 'H') in
                                (select lc from cbs_urun_sinif
                                       where  cbs_urun_sinif.modul_tur_kod = 'CURRENT'
                                            and cbs_urun_sinif.urun_tur_kod = 'DEMAND DEP'
                                            and cbs_urun_sinif.kod in ('NON INT.BEARING-LC', 'NON INT.BEARING-FC'))
                                            group by cbs_doviz_kodlari.doviz_kodu, cbs_doviz_kodlari.aciklama;
                                            
   else
   
        open pc_ref for                 
               select pkg_genel.lc_al as currency_code,
                      pkg_genel.doviz_adi_al(pkg_genel.lc_al) as currency_name
                         from dual
                union
                select 'RUB' as currency_code,
                      pkg_genel.doviz_adi_al('RUB') as currency_name
                         from dual
                union 
                select 'USD' as currency_code,
                      pkg_genel.doviz_adi_al('USD') as currency_name
                         from dual;                   
   end if;
    
    return ls_returncode;
    
EXCEPTION 
    when others then 
        raise; 
END; 

FUNCTION GetAccountTransactionHistory(ps_lang varchar2,
                                      ps_iban varchar2,
                                      pn_page_index number,
                                      pn_page_size number,
                                      ps_from_date varchar2, 
                                      ps_to_date varchar2,
                                      ps_direction varchar2,
                                      ps_transfer_code varchar2,
                                      pc_ref OUT CursorReferenceType) RETURN varchar2 
IS                         
ld_from_date date;
ld_to_date date;
ln_account_number number;
ls_returncode varchar2(3) := '000';
le_account_not_found exception; 
BEGIN
 
    ln_account_number := GetAccountNumberByIban(ps_iban);
    
    if ln_account_number = 0 then
        raise le_account_not_found;
    end if;
    
    
    ld_from_date := to_date(substr(ps_from_date, 1, 10), 'YYYY-MM-DD');
    ld_to_date := to_date(substr(ps_to_date, 1, 10), 'YYYY-MM-DD');
    
    if (pkg_tarih.gun_ozellik(ld_to_date) = 1) then
        ld_to_date := pkg_tarih.ileri_is_gunu(ld_to_date);
    end if;
               
    open pc_ref for
       select h.*, rownum as row_num from (select a.fis_yaratildigi_tarih as created_date, 
              a.satir_valor_tarihi as transaction_date,
                    k.islem_kod as transaction_code, 
                    pkg_genel.islem_adi_al(k.islem_kod) as transaction_name,   
                    a.satir_dv_tutar as amount, 
                    satir_doviz_kod as currency_code, 
                    i.aciklama as description,    
                    nvl(pkg_passbook.hareketlibakiyehesapla(a.satir_hesap_numara,a.fis_numara,a.satir_numara),0) as balance_after,                    
                    decode(a.satir_tur,'A','in','B','out') as direction,
                    k.numara as transaction_number                         
            from cbs_vw_fis_satir_vsziz a,cbs_islem k, cbs_islem_tanim i
            where  satir_hesap_numara = to_char(ln_account_number) 
                   and fis_tur = 'G'
                   and a.satir_tur = nvl(decode(ps_direction,'in','A','out','B'), a.satir_tur)
                   and k.islem_kod = nvl(ps_transfer_code, k.islem_kod)
                   and k.numara=a.fis_islem_numara
                   and i.kod=k.islem_kod
                   and fis_muhasebelestigi_tarih between nvl(ld_from_date, trunc(add_months(sysdate, -3))) and nvl(ld_to_date, trunc(sysdate))
               order by a.fis_yaratildigi_tarih, a.fis_numara, a.satir_numara) h order by row_num desc 
               offset ((pn_page_index-1) * pn_page_size) rows fetch next pn_page_size rows only;
        
  return ls_returncode;
  
EXCEPTION
       when le_account_not_found then
          return '454'; 
       when no_data_found then
          return '490'; 
       when others then
         log_at('GetAccountTransactionHistory', ps_iban, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
          raise;        
END;

FUNCTION GetAccountTransactionGeneral(ps_lang varchar2,
                                      ps_iban varchar2,
                                      ps_from_date varchar2, 
                                      ps_to_date varchar2,
                                      ps_direction varchar2,
                                      ps_transfer_code varchar2,
                                      pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ld_from_date date;
ld_to_date date;
ld_create_date date;
ln_account_number number;
ln_customer_number number;
ln_months number;
ls_returncode varchar2(3) := '000';  
le_account_not_found exception;
le_date exception; 
BEGIN

    ln_account_number := GetAccountNumberByIban(ps_iban);
    
    if ln_account_number = 0 then
        raise le_account_not_found;
    end if;
    
    ld_from_date := to_date(substr(ps_from_date, 1, 10), 'YYYY-MM-DD');
    ld_to_date := to_date(substr(ps_to_date, 1, 10), 'YYYY-MM-DD');
    
    if (pkg_tarih.gun_ozellik(ld_to_date) = 1) then
        ld_to_date := pkg_tarih.ileri_is_gunu(ld_to_date);
    end if;
               
    select months_between(ld_to_date, ld_from_date) into ln_months from dual;
    
    if ln_months > 6 then
        raise le_date;
    end if;
    
    ln_customer_number := PKG_HESAP.HesaptanMusteriNoAl(ln_account_number);
    
    ld_create_date := sysdate;
    
    open pc_ref for
               select  
                pkg_musteri.sf_musteri_adi(ln_customer_number) as name,
                pkg_musteri.sf_adres_al(ln_customer_number) as address,
                ld_create_date as statement_date,
                ln_customer_number as customer_number,
                ln_account_number as account_number,
                ps_iban as iban,
                pkg_musteri.Sf_VergiNo_Al(ln_customer_number) as tax_number,
                min(fis_yaratildigi_tarih) as opening_date,
                max(fis_yaratildigi_tarih) as closing_date,
                sum(case when a.satir_dv_tutar >= 0 then a.satir_dv_tutar else 0 end) as credit_amount,
                sum(case when a.satir_dv_tutar < 0 then a.satir_dv_tutar else 0 end) as debit_amount,
                count(*) as count_transaction                     
            from cbs_vw_fis_satir_vsziz a, cbs_islem k
            where  satir_hesap_numara = to_char(ln_account_number) 
                   and fis_tur = 'G'
                   and a.satir_tur = nvl(decode(ps_direction,'in','A','out','B'), a.satir_tur)
                   and k.islem_kod = nvl(ps_transfer_code, k.islem_kod)
                   and k.numara = a.fis_islem_numara
                   and fis_muhasebelestigi_tarih between ld_from_date and ld_to_date;
              
      return ls_returncode;

EXCEPTION
       when le_account_not_found then
          return '454'; 
       when le_date then
          return '453'; 
       when others then
         log_at('GetAccountTransactionGeneral', ps_iban, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace); 
             
         raise;        
END;                                 
                          
FUNCTION GetAccountTransactionStatement(ps_lang varchar2,
                                      ps_iban varchar2,
                                      ps_from_date varchar2, 
                                      ps_to_date varchar2,
                                      ps_direction varchar2,
                                      ps_transfer_code varchar2,
                                      pc_ref OUT CursorReferenceType) RETURN varchar2 
IS                         
ld_from_date date;
ld_to_date date;
ln_account_number number;
ln_months number;
ls_returncode varchar2(3) := '000';
le_account_not_found exception; 
le_date exception; 
BEGIN
 
    ln_account_number := GetAccountNumberByIban(ps_iban);
    
    if ln_account_number = 0 then
        raise le_account_not_found;
    end if;
    
    
    ld_from_date := to_date(substr(ps_from_date, 1, 10), 'YYYY-MM-DD');
    ld_to_date := to_date(substr(ps_to_date, 1, 10), 'YYYY-MM-DD');
    
    if (pkg_tarih.gun_ozellik(ld_to_date) = 1) then
        ld_to_date := pkg_tarih.ileri_is_gunu(ld_to_date);
    end if;
    
    select months_between(ld_to_date, ld_from_date) into ln_months from dual;
    
    if ln_months > 6 then
        raise le_date;
    end if;
               
    open pc_ref for
       select a.fis_yaratildigi_tarih as created_date, 
              a.satir_valor_tarihi as transaction_date,
                    k.islem_kod as transaction_code, 
                    pkg_genel.islem_adi_al(k.islem_kod) as transaction_name,   
                    a.satir_dv_tutar as amount, 
                    satir_doviz_kod as currency_code, 
                    a.satir_musteri_aciklama as description,     
                    nvl(pkg_passbook.hareketlibakiyehesapla(a.satir_hesap_numara,a.fis_numara,a.satir_numara),0) as balance_after,                    
                    decode(a.satir_tur,'A','in','B','out') as direction,
                    k.numara as transaction_number                         
            from cbs_vw_fis_satir_vsziz a, cbs_islem k
            where  satir_hesap_numara = to_char(ln_account_number) 
                   and fis_tur = 'G'
                   and a.satir_tur = nvl(decode(ps_direction,'in','A','out','B'), a.satir_tur)
                   and k.islem_kod = nvl(ps_transfer_code, k.islem_kod)
                   and k.numara = a.fis_islem_numara
                   and fis_muhasebelestigi_tarih between ld_from_date and ld_to_date
               order by a.fis_yaratildigi_tarih desc;
        
  return ls_returncode;
  
EXCEPTION
       when le_account_not_found then
          return '454'; 
       when le_date then
          return '453'; 
       when others then
         log_at(ps_iban,'GetAccountTransactionStatement', utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
 
         raise;       
END;                      

FUNCTION GetAccountTransactionReceipt(ps_lang varchar2,
                                      ps_iban varchar2,
                                      ps_transaction_number varchar2,
                                      pc_ref OUT cursorreferencetype,
                                      pc_ref2 OUT cursorreferencetype) RETURN varchar2 
IS
ln_transaction_number number;
ln_transaction_code number;
ld_completion_date date;
ln_source_iban number;
ln_amount number;
ls_source_bic varchar2(16) := null;
ls_source_bank_name varchar2(200) := null;
ls_target_bic varchar2(16) := null;
ls_target_bank_name varchar2(200) := null;
ls_source_account_number varchar(30);
ls_target_account_number varchar(30);
ln_transaction_number_b2b varchar2(50) := '';
ls_user_code cbs_islem.kayit_kullanici_kodu%type;
ld_maturity_date date;
ls_eft_kodu cbs_bolum.eft_kodu%type;
check_trans boolean := false;
ln_source_comm number := 0;
ln_target_comm number := 0;
ln_count_instant number := 0;
 
ls_returncode varchar2(3) := '000';
nostatementfound exception;
statementissalary exception;


cursor cur_rec is
    select hesap_numara, banka_aciklama, tur, pkg_tx.islem_kod(fis_islem_numara) as tx_code, fis_yaratan_kullanici_kodu
                 from cbs_satir 
                 where fis_islem_numara = ln_transaction_number
                 and hesap_numara = to_char(pkg_int_account_inq.GetAccountNumberByIban(ps_iban))
                 and fis_tur in ('G', 'T')
                 and hesap_tur_kodu <> 'DK';
   
row_cur_rec cur_rec%rowtype;
BEGIN

    ln_transaction_number := to_number(ps_transaction_number);
    
    select count(*) into ln_count_instant from cbs_tahsilat where islem_no = ln_transaction_number;
    
    if ln_count_instant > 0 then
    
        open pc_ref for 
                   select 
                    'source' as indicator, 
                    isim_unvan as source_customer_name,
                    ps_iban as source_iban,
                    'DEMIR KYRGYZ INTERNATIONAL BANK' as source_bank_name,
                    (select '118' || eft_kodu
                                 from cbs_bolum
                                                where kodu = sube_kodu) as source_bic,
                    ln_transaction_number as transaction_number, 
                    '0401060' as form_code,
                    yaratildigi_tarih as transaction_date, 
                    sysdate as receipt_date,
                    pkg_genel.islem_adi_al(pkg_tx.islem_kod(islem_no)) as send_method,
                    aciklama as description,
                    payment_id as payment_code,
                    doviz_kodu as currency_code,
                    tutar + commission_amount_bank + commission_amount_company as amount,
                    'KGS' as comm_tax_curr,
                    nvl(commission_amount_bank + commission_amount_company, 0) as commission_amount,
                    0 as tax_amount,
                    pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(hesap_no)) as tax_number
               from cbs_tahsilat where islem_no = ln_transaction_number and hesap_no = pkg_int_account_inq.GetAccountNumberByIban(ps_iban);
               
        open pc_ref2 for 
                       select 
                        'source' as indicator, 
                        kurum_kodu as target_customer_name,
                        coalesce(telefon_alan_kod || telefon_no, kurum_ozel_no) as target_iban,
                        'DEMIR KYRGYZ INTERNATIONAL BANK' as target_bank_name,
                        (select '118' || eft_kodu
                                     from cbs_bolum
                                                    where kodu = sube_kodu) as target_bic,
                        ln_transaction_number as transaction_number, 
                        '0401060' as form_code,
                        yaratildigi_tarih as transaction_date, 
                        sysdate as receipt_date,
                        pkg_genel.islem_adi_al(pkg_tx.islem_kod(islem_no)) as send_method,
                        aciklama as description,
                        payment_id as payment_code,
                        doviz_kodu as currency_code,
                        tutar + commission_amount_bank + commission_amount_company as amount,
                        'KGS' as comm_tax_curr,
                        nvl(commission_amount_bank + commission_amount_company, 0) as commission_amount,
                        0 as tax_amount,
                        pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(hesap_no)) as tax_number
                   from cbs_tahsilat where islem_no = ln_transaction_number and hesap_no = pkg_int_account_inq.GetAccountNumberByIban(ps_iban);

    else
    
             for row_cur_rec in cur_rec loop 
              
                 if row_cur_rec.tx_code = 2150 or (row_cur_rec.fis_yaratan_kullanici_kodu <>  'CINT_CALLER' and row_cur_rec.tx_code = 3199) then
                     raise statementissalary;
                 end if;
                 
                 if row_cur_rec.hesap_numara = to_char(pkg_int_account_inq.GetAccountNumberByIban(ps_iban)) then
                    check_trans := true;
                 end if;
                 
                 if lower(row_cur_rec.banka_aciklama) not like '%com%' 
                    and lower(row_cur_rec.banka_aciklama) not like '%tax%'
                    and lower(row_cur_rec.banka_aciklama) not like '%комиссия%' 
                    and row_cur_rec.tur = 'B' then
                    ls_source_account_number := row_cur_rec.hesap_numara;
                 elsif lower(row_cur_rec.banka_aciklama) not like '%com%' 
                    and lower(row_cur_rec.banka_aciklama) not like '%tax%'
                    and lower(row_cur_rec.banka_aciklama) not like '%комиссия%' 
                    and row_cur_rec.tur = 'A' then
                    ls_target_account_number := row_cur_rec.hesap_numara;
                 end if;
                 
                 if row_cur_rec.tur = 'B' then
                    ln_source_comm := ln_source_comm + 1;
                 elsif row_cur_rec.tur = 'A' then
                    ln_target_comm := ln_source_comm + 1;
                 end if;
                     
             end loop;
             
            if check_trans = false then 
                raise nostatementfound;
            end if; 
            
            if ls_source_account_number is not null and ls_target_account_number is not null then
                ls_source_account_number := null;
                ls_target_account_number := null;
            end if;            
            
            open pc_ref for 
                   select 
                    s.indicator, 
                    s.source_customer_name,
                    case 
                     when s.source_iban is not null then
                          s.source_iban             
                     else
                          s.source_account  
                    end source_iban,
                    s.source_bank_name,
                    s.source_bic,
                    s.transaction_number, 
                    '0401060' as form_code,
                    s.transaction_date, 
                    sysdate as receipt_date,
                    s.send_method,
                    s.description,
                    s.payment_code,
                    s.currency_code,
                    sum(s.amount) as amount,
                    'KGS' as comm_tax_curr,
                    nvl(commission_amount, 0) as commission_amount,
                    nvl(tax_amount, 0) as tax_amount,
                    s.tax_number
                      from (select s.*, commission_amount, tax_amount  from (
                            select  decode (tur, 'A', 'target', 'source') as indicator,
                                   fis_islem_numara as transaction_number,
                                   s.fis_yaratildigi_tarih as transaction_date,
                                   pkg_genel.islem_adi_al(pkg_tx.islem_kod(fis_islem_numara)) as send_method,
                                   case
                                      when pkg_tx.islem_kod (fis_islem_numara) in (3556, 2010) then
                                          (select distinct nvl(from_rnn, '') from cbs_clearing
                                             where yaratan_tx_no = fis_islem_numara
                                                     and urun_tur_kod = 'INCOMING')
                                      else
                                          pkg_musteri.sf_vergino_al(pkg_hesap.hesaptanmusterinoal(hesap_numara))  
                                   end tax_number,    
                                    case
                                      when pkg_tx.islem_kod (fis_islem_numara) in (3556, 2010) then
                                           (select substr(from_account_external_number, 1, 6)
                                                from cbs_clearing
                                               where yaratan_tx_no = fis_islem_numara
                                                     and urun_tur_kod = 'INCOMING' 
                                           union 
                                           select gbanka_bic_kodu from cbs_yphavale_gelen_basvuru where     tx_no = fis_islem_numara)
                                      else
                                           (select '118' || eft_kodu
                                              from cbs_bolum
                                                where kodu = hesap_bolum_kodu)
                                   end source_bic,     
                                   case
                                      when pkg_tx.islem_kod (fis_islem_numara) in (3556, 2010) then
                                           (select to_name
                                                from cbs_clearing
                                                  where yaratan_tx_no = fis_islem_numara
                                                     and urun_tur_kod = 'INCOMING' 
                                          union 
                                             select gonderen_adi from cbs_yphavale_gelen_basvuru  where tx_no = fis_islem_numara)
                                      else
                                        pkg_apex.sf_musteri_adi(pkg_hesap.hesaptanmusterinoal(hesap_numara))
                                   end source_customer_name,  
                                   case
                                      when pkg_tx.islem_kod(fis_islem_numara) in (3556, 2010) then
                                          (select upper(banka_adi)
                                                 from cbs_banka_kodlari where to_char (banka_kodu) = 
                                                     (select substr(from_account_external_number,1,3) || '001'  
                                                             from cbs_clearing 
                                                             where yaratan_tx_no = fis_islem_numara  and urun_tur_kod = 'INCOMING')
                                           union
                                                select banka_adi from cbs_bic_kodlari
                                                   where bic_kodu = (select gbanka_bic_kodu from cbs_yphavale_gelen_basvuru where tx_no = fis_islem_numara))
                                   else
                                      'DEMIR KYRGYZ INTERNATIONAL BANK'
                                   end source_bank_name,
                                   case
                                      when pkg_tx.islem_kod(fis_islem_numara) in (3556, 2010) then
                                          (select from_account_external_number from cbs_clearing where yaratan_tx_no = fis_islem_numara and urun_tur_kod = 'INCOMING'
                                            union            
                                           select to_char(gonderen_adres) from cbs_yphavale_gelen_basvuru where tx_no = fis_islem_numara)
                                      else
                                          to_char(pkg_hesap.external_hesapno_al(hesap_numara)) 
                                   end source_iban,
                                   hesap_numara source_account,
                                   dv_tutar amount,
                                   doviz_kod currency_code,
                                   (select nvl(musteri_aciklama, null) from cbs_satir 
                                            where fis_islem_numara = ln_transaction_number 
                                                    and fis_numara = s.fis_numara
                                                    and numara = 1 
                                                    and rownum = 1) description,
                                   (select nvl(istatistik_kodu, null) from cbs_satir 
                                            where fis_islem_numara = ln_transaction_number 
                                                    and fis_numara = s.fis_numara
                                                    and istatistik_kodu is not null 
                                                    and tur = 'B'
                                                    and rownum = 1) payment_code        
                         from cbs_satir s
                         where s.fis_islem_numara = ln_transaction_number
                               and (ls_source_account_number is null or hesap_numara = ls_source_account_number)
                               and hesap_tur_kodu <> 'DK'
                               and fis_tur in ('G', 'T')
                               and tur = 'B'
                               and (pkg_tx.islem_kod(fis_islem_numara) != 7000 or lower(banka_aciklama) not like '%комиссия%')
                               ) s
                         -----------------------------------COMMISSION AND TAX
                        left join 
                               (select fis_islem_numara, 
                                  nvl(sum(lc_tutar), 0) commission_amount  
                                  from cbs_satir 
                                   where (substr(hesap_numara, 1, 3) = '606'  
                                     or hesap_numara in ('21199951'))       
                                     and hesap_tur_kodu = 'DK'
                                     and fis_tur = 'G'
                                     and tur = 'A' group by fis_islem_numara) c
                               on fis_islem_numara = s.transaction_number
                        left join
                                (select fis_islem_numara, 
                                        nvl(lc_tutar, 0) tax_amount  
                                  from cbs_satir 
                                     where 
                                        substr(hesap_numara, 1, 6) = '211137' 
                                        and hesap_tur_kodu = 'DK'
                                        and fis_tur = 'G'
                                        and tur = 'A') t
                                        on t.fis_islem_numara = s.transaction_number ) s
                        group by 
                            s.indicator, 
                            s.source_customer_name,
                            s.source_iban,
                            s.source_account,
                            s.source_bank_name,
                            s.source_bic,
                            s.transaction_number, 
                            s.transaction_date, 
                            s.send_method,
                            s.description,
                            s.payment_code,
                            s.currency_code,
                            commission_amount,
                            tax_amount,
                            s.tax_number;

            open pc_ref2 for 
              select
                    r.indicator, 
                    r.target_customer_name,
                    case 
                     when r.target_iban is not null then
                          r.target_iban             
                     else
                          r.target_account  
                    end target_iban,
                    r.target_bank_name,
                    r.target_bic,
                    r.transaction_number, 
                    '0401060' as form_code,
                    r.transaction_date, 
                    sysdate as receipt_date,
                    r.send_method,
                    r.description,
                    r.payment_code,
                    r.currency_code,
                    sum(r.amount) as amount,
                    'KGS' as comm_tax_curr,
                    nvl(commission_amount, 0) as commission_amount,
                    nvl(tax_amount, 0) as tax_amount,
                    r.tax_number
                      from (select r.*, commission_amount, tax_amount  from (
                         select decode (tur, 'A', 'target', 'source') indicator,
                               fis_islem_numara transaction_number,
                               r.fis_yaratildigi_tarih as transaction_date,
                               pkg_genel.islem_adi_al(pkg_tx.islem_kod(fis_islem_numara)) as  send_method,
                               case
                                  when pkg_tx.islem_kod(fis_islem_numara) in (3555, 4003)
                                  then
                                    null
                                  else          
                                  pkg_musteri.sf_vergino_al (pkg_hesap.hesaptanmusterinoal (hesap_numara))  
                               end tax_number,   
                                case
                                  when pkg_tx.islem_kod (fis_islem_numara) in (3555, 4003)
                                  then
                                       (select to_bank_bic
                                        from cbs_clearing
                                           where yaratan_tx_no = fis_islem_numara
                                                 and urun_tur_kod = 'OUTGOING' 
                                           union 
                                             select alici_bic from cbs_yphavale_giden_acilis  where tx_no = fis_islem_numara)
                                  else
                                       (select '118' || eft_kodu
                                          from cbs_bolum
                                         where kodu = hesap_bolum_kodu)
                               end target_bic,         
                               case
                                  when pkg_tx.islem_kod(fis_islem_numara) in (3555, 4003, 6330) then
                                       (select to_name
                                        from cbs_clearing
                                       where     yaratan_tx_no = fis_islem_numara
                                             and urun_tur_kod = 'OUTGOING' 
                                      union 
                                      select   bc_isim_adres_1 from cbs_yphavale_giden_acilis   where     tx_no = fis_islem_numara
                                      union 
                                      select   kurum_kodu from cbs_tahsilat_detay_islem   where     islem_no = fis_islem_numara
                                      )
                                  else
                                      pkg_apex.sf_musteri_adi(pkg_hesap.hesaptanmusterinoal (hesap_numara))        
                               end target_customer_name,         
                               case
                                  when pkg_tx.islem_kod (fis_islem_numara) in (3555, 4003) then
                                      (select banka_adi from cbs_banka_kodlari
                                         where to_char (banka_kodu) = (select to_bank_bic from cbs_clearing where yaratan_tx_no = fis_islem_numara and urun_tur_kod = 'OUTGOING')
                                 union
                                      select banka_adi from cbs_bic_kodlari where bic_kodu = (select alici_bic from cbs_yphavale_giden_acilis where tx_no = fis_islem_numara))
                                  else
                                    'DEMIR KYRGYZ INTERNATIONAL BANK'
                               end target_bank_name,         
                               case
                                  when pkg_tx.islem_kod (fis_islem_numara) in (3555, 4003, 6330) then
                                        (select to_account_external_number  from cbs_clearing where     yaratan_tx_no = fis_islem_numara  and urun_tur_kod = 'OUTGOING'
                                             union            
                                        select bc_hesap_no_n from cbs_yphavale_giden_acilis where tx_no = fis_islem_numara
                                            union 
                                        select  coalesce(telefon_alan_kod || telefon_no, kurum_ozel_no) from cbs_tahsilat_detay_islem where islem_no = fis_islem_numara)
                                  else
                                         to_char(pkg_hesap.external_hesapno_al (hesap_numara))
                               end target_iban, 
                               hesap_numara target_account,          
                               dv_tutar amount,
                               doviz_kod currency_code,
                               (select nvl(musteri_aciklama, null) from cbs_satir 
                                                where fis_islem_numara = ln_transaction_number 
                                                and fis_numara = r.fis_numara
                                                and numara = 1 
                                                and rownum = 1) description,
                               (select nvl(istatistik_kodu, null) from cbs_satir 
                                            where fis_islem_numara = ln_transaction_number 
                                                    and fis_numara = r.fis_numara
                                                    and istatistik_kodu is not null 
                                                    and tur = 'B'
                                                    and rownum = 1) payment_code 
                          from cbs_satir r
                         where r.fis_islem_numara = ln_transaction_number
                               and (ls_target_account_number is null or hesap_numara = ls_target_account_number)
                               and hesap_tur_kodu <> 'DK'
                               and fis_tur in ('G', 'T')
                               and tur = 'A'
                               )  r 
                         left join 
                               (select fis_islem_numara, 
                                       nvl(sum(lc_tutar), 0) commission_amount  
                                  from cbs_satir 
                                   where (substr(hesap_numara, 1, 3) = '606'  
                                     or hesap_numara in ('21199951'))       
                                     and hesap_tur_kodu = 'DK'
                                     and fis_tur = 'G'
                                     and tur = 'A' group by fis_islem_numara) c
                               on fis_islem_numara = r.transaction_number
                        left join
                                (select fis_islem_numara, 
                                        nvl(lc_tutar, 0) tax_amount  
                                  from cbs_satir 
                                     where 
                                        substr(hesap_numara, 1, 6) = '211137' 
                                        and hesap_tur_kodu = 'DK'
                                        and fis_tur = 'G'
                                        and tur = 'A') t
                                        on t.fis_islem_numara = r.transaction_number) r
                    group by 
                            r.indicator, 
                            r.target_customer_name,
                            r.target_iban,
                            r.target_account,
                            r.target_bank_name,
                            r.target_bic,
                            r.transaction_number, 
                            r.transaction_date, 
                            r.send_method,
                            r.description,
                            r.payment_code,
                            r.currency_code,
                            amount,
                            commission_amount,
                            tax_amount,
                            r.tax_number;
    end if;


    return ls_returncode;

EXCEPTION
     when nostatementfound then
       open pc_ref for
         select ln_transaction_number as transaction_number from dual; 
          return '454'; 
     when statementissalary then
       open pc_ref for
         select ln_transaction_number as transaction_number from dual; 
          return '460'; 
     when others then
         log_at('GetAccountTransactionReceipt', ps_iban, utl_http.get_detailed_sqlerrm,
               sqlcode
            || ' '
            || sqlerrm
            || ' '
            || dbms_utility.format_error_backtrace);
         raise;        
END;

--EOM  Accounts

/***************************************************************************/
/***************************************************************************/

--BOM Checking Accounts
                         
FUNCTION GetCheckingAccount(ps_lang varchar2,
                            ps_iban varchar2,
                            pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_owner_type varchar(100 byte);
ls_customer_type varchar(1 byte);
ls_returncode varchar2(3) := '000';
BEGIN

   ls_customer_type := pkg_int_customer_inq.GetCustomerTypeByIban(ps_iban);
             
    if CheckJoinAccountByIban(ps_iban) then
         ls_owner_type := 'partner';
    elsif ls_customer_type is not null and ls_customer_type = '2' then
         ls_owner_type := 'company';
    else
         ls_owner_type := 'individual';
    end if;

    
    open pc_ref for
              select ch.short_name, 
                                   ch.external_account_no as iban,
                                   ch.account_no as account_number, 
                                  'checking' account_type, 
                                   ls_owner_type as owner_type,
                                   ch.currency_code,
                                   ch.opening_date, 
                                   decode(ch.status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
                                   ch.branch_code, 
                                   pkg_genel.bolum_adi_al(ch.branch_code) as branch_name, 
                                   (select '118'||eft_kodu from cbs_bolum where kodu = ch.branch_code) as bic_code, 
                                   ch.balance,
                                   pkg_hesap.kullanilabilir_bakiye_al(ch.account_no) available_balance, 
                                   ch.module_type_code, 
                                   pkg_genel.modul_tur_adi_al(ch.module_type_code) as module_type_name,
                                   ch.product_type_code,
                                   pkg_genel.urun_tur_adi_al(ch.module_type_code, ch.product_type_code) as product_type_name, 
                                   ch.product_class_code, 
                                   pkg_genel.urun_adi_al(ch.module_type_code, ch.product_type_code, ch.product_class_code) as product_class_name,
                                   nvl(l.fc_limit, 0) as credit_total_amount,
                                   nvl(l.fc_risk, 0) as credit_used_amount,
                                   nvl(l.fc_limit, 0) - nvl(l.fc_risk, 0) as credit_remained_amount,
                                   nvl(blockage_amount, 0) as blockage_amount
                                          from cbs_vw_checking_account ch
                                               left join cbs_musteri_urun_limit l 
                                               on l.musteri_no = ch.customer_no 
                                               and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                               and ch.overdraft = 'E' 
                                               where ch.external_account_no = ps_iban
                                                    and status = 'A' 
                                                    and module_type_code ='CURRENT'
                                                    and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                                    and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC');
           
    return ls_returncode;
    
EXCEPTION
    when others then
        return '490'; 
END;

FUNCTION GetCheckingAccountList(ps_lang varchar2,
                                ps_customer_id varchar2, 
                                ps_currency_code varchar2 default null,
                                pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN 
 
  ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
 
  if ln_customer_number is null then
    raise le_customer_not_found;
  end if;
  
  ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
                
  open pc_ref for
           select * from (select ch.short_name, 
                           ch.external_account_no as iban,
                           ch.account_no as account_number, 
                          'checking' account_type, 
                          'individual' as owner_type,
                           ch.currency_code,
                           ch.opening_date, 
                           decode(ch.status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name, 
                           (select '118'||eft_kodu from cbs_bolum where kodu = ch.branch_code) as bic_code,
                           ch.balance,
                           pkg_hesap.kullanilabilir_bakiye_al(ch.account_no) available_balance, 
                           ch.module_type_code, 
                           pkg_genel.modul_tur_adi_al(ch.module_type_code) as module_type_name,
                           ch.product_type_code,
                           pkg_genel.urun_tur_adi_al(ch.module_type_code, ch.product_type_code) as product_type_name, 
                           ch.product_class_code, 
                           pkg_genel.urun_adi_al(ch.module_type_code, ch.product_type_code, ch.product_class_code) as product_class_name,
                           nvl(l.fc_limit, 0) as credit_total_amount,
                           nvl(l.fc_risk, 0) as credit_used_amount,
                           nvl(l.fc_limit, 0) - nvl(l.fc_risk, 0) as credit_remained_amount,
                           nvl(blockage_amount, 0) as blockage_amount
                                  from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where customer_no = ln_customer_number
                                            and status = 'A' 
                                            and ch.account_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where ana_hesap_no = ch.account_no)
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                                            and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                           connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                                     or trim(ps_currency_code) is null)
                                
           union
           select ch.short_name, 
                           ch.external_account_no as iban,
                           ch.account_no as account_number, 
                          'checking' account_type, 
                          'company' as owner_type,
                           ch.currency_code,
                           ch.opening_date, 
                           decode(ch.status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name, 
                           (select '118'||eft_kodu from cbs_bolum where kodu = ch.branch_code) as bic_code,
                           ch.balance,
                           pkg_hesap.kullanilabilir_bakiye_al(ch.account_no) available_balance, 
                           ch.module_type_code, 
                           pkg_genel.modul_tur_adi_al(ch.module_type_code) as module_type_name,
                           ch.product_type_code,
                           pkg_genel.urun_tur_adi_al(ch.module_type_code, ch.product_type_code) as product_type_name, 
                           ch.product_class_code, 
                           pkg_genel.urun_adi_al(ch.module_type_code, ch.product_type_code, ch.product_class_code) as product_class_name,
                           nvl(l.fc_limit, 0) as credit_total_amount,
                           nvl(l.fc_risk, 0) as credit_used_amount,
                           nvl(l.fc_limit, 0) - nvl(l.fc_risk, 0) as credit_remained_amount,
                           nvl(blockage_amount, 0) as blockage_amount
                                  from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where ln_customer_number_second is not null
                                            and customer_no = ln_customer_number_second
                                            and status = 'A' 
                                            and ch.account_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where ana_hesap_no = ch.account_no)
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                                            and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                           connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                                     or trim(ps_currency_code) is null)
             union
               select 
                           ch.short_name, 
                           ch.external_account_no as iban,
                           ch.account_no as account_number, 
                          'checking' account_type, 
                          'partner' as owner_type,
                           ch.currency_code,
                           ch.opening_date, 
                           decode(ch.status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name, 
                           (select '118'||eft_kodu from cbs_bolum where kodu = ch.branch_code) as bic_code,
                           ch.balance,
                           pkg_hesap.kullanilabilir_bakiye_al(ch.account_no) available_balance, 
                           ch.module_type_code, 
                           pkg_genel.modul_tur_adi_al(ch.module_type_code) as module_type_name,
                           ch.product_type_code,
                           pkg_genel.urun_tur_adi_al(ch.module_type_code, ch.product_type_code) as product_type_name, 
                           ch.product_class_code, 
                           pkg_genel.urun_adi_al(ch.module_type_code, ch.product_type_code, ch.product_class_code) as product_class_name,
                           nvl(l.fc_limit, 0) as credit_total_amount,
                           nvl(l.fc_risk, 0) as credit_used_amount,
                           nvl(l.fc_limit, 0) - nvl(l.fc_risk, 0) as credit_remained_amount,
                           nvl(blockage_amount, 0) as blockage_amount
              from cbs_vw_checking_account ch
                   inner join cbs_hesap_ortak_bilgi joinacc
                   on joinacc.ana_hesap_no = ch.account_no
                   left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no 
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                   where (joinacc.ortak_musteri_no in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                         or joinacc.ana_hesap_no 
                           in (select ch.account_no from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where customer_no in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                            and status = 'A' 
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                                            and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                           connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                                     or trim(ps_currency_code) is null)))
                         and joinacc.status ='ACTIVE'
                         and ch.status = 'A'
                         and module_type_code = 'CURRENT'
                         and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                         and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                         and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                        connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                              or trim(ps_currency_code) is null));

         
    return ls_returncode;    
    
EXCEPTION 
    when le_customer_not_found then
          return '454'; 
    when others then
          raise;        
END;

FUNCTION GetCheckingAccountSummarized(ps_lang varchar2,
                                      ps_customer_id varchar2,
                                      pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
 
  if ln_customer_number is null then
    raise le_customer_not_found;
  end if;
  
  ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
                      
  open pc_ref for
           select ch.short_name, 
                           ch.external_account_no as iban, 
                          'individual' as owner_type,
                           ch.currency_code,
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name
                                  from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where customer_no = ln_customer_number
                                            and status = 'A' 
                                            and ch.account_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where ana_hesap_no = ch.account_no)
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')                
           union
            select ch.short_name, 
                           ch.external_account_no as iban, 
                          'company' as owner_type,
                           ch.currency_code,
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name
                                  from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where ln_customer_number_second is not null 
                                            and  customer_no =ln_customer_number_second
                                            and status = 'A' 
                                            and ch.account_no not in (select ana_hesap_no from cbs_hesap_ortak_bilgi where ana_hesap_no = ch.account_no)
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')    
             union
               select 
                           ch.short_name, 
                           ch.external_account_no as iban, 
                          'partner' as owner_type,
                           ch.currency_code,
                           ch.branch_code, 
                           pkg_genel.bolum_adi_al(ch.branch_code) as branch_name
              from cbs_vw_checking_account ch
                   inner join cbs_hesap_ortak_bilgi joinacc
                   on joinacc.ana_hesap_no = ch.account_no
                   left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no 
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                   where (joinacc.ortak_musteri_no in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                         or joinacc.ana_hesap_no 
                           in (select ch.account_no from cbs_vw_checking_account ch
                                       left join cbs_musteri_urun_limit l 
                                       on l.musteri_no = ch.customer_no
                                       and l.kredi_teklif_satir_numara = ch.ovd_proposal_line_no 
                                       and ch.overdraft = 'E' 
                                       where customer_no in (ln_customer_number, nvl(ln_customer_number_second, ln_customer_number))
                                            and status = 'A' 
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')))
                         and joinacc.status ='ACTIVE'
                         and ch.status = 'A'
                         and module_type_code = 'CURRENT'
                         and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                         and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC');
           
    return ls_returncode;
    
EXCEPTION 
    when le_customer_not_found then
          return '454'; 
    when others then
          raise;        
END;  

FUNCTION GetCheckingAccountByPhone(ps_lang varchar2,
                                   ps_customer_id varchar2,
                                   ps_phone_number varchar2,
                                   pc_ref OUT CursorReferenceType,
                                   pc_ref2 OUT CursorReferenceType) RETURN varchar2
IS 
ln_customer_number_second number;
ln_count_customer number := 1;
ls_tax_number_1 varchar2(20 byte);
ls_passport_1 varchar2(20 byte);
ls_identity_serial_no_1 varchar2(20 byte);
ls_customer_type_1 varchar2(1 byte);
ls_tax_number_2 varchar2(20 byte);
ls_passport_2 varchar2(20 byte);
ls_identity_serial_no_2 varchar2(20 byte);
ls_customer_type_2 varchar2(1 byte);
ls_owner varchar2(5 byte);
ls_owner_masked_full_name varchar2(150);

cursor cur_address is
   select distinct musteri_no
        from cbs_musteri_adres 
          where ((nvl(ulke_gsm_kod, '996') || gsm_alan_kod  || gsm_no) = ps_phone_number
                 or (nvl(ulke_gsm_kod_2, '996') || gsm_alan_kod_2  || gsm_no_2) = ps_phone_number
                 or (nvl(ulke_gsm_kod_3, '996') || gsm_alan_kod_3  || gsm_no_3) = ps_phone_number);
                 
ln_customer_list CustomerList := CustomerList();
   
row_cur_address cur_address%rowtype;

ls_returncode varchar2(3) := '000';
le_duplicate_phone_number exception;
le_phone_number_not_found exception;
BEGIN

   for row_cur_address in cur_address loop 
    ln_customer_list.extend;
    ln_customer_list(ln_count_customer) := row_cur_address.musteri_no;
     
    ln_count_customer := ln_count_customer + 1;
     
    if ln_count_customer > 3 then
       raise le_duplicate_phone_number;
    end if;
    
   end loop;
    
   
   if ln_count_customer = 1 then
       raise le_phone_number_not_found;
   end if;
    
    if ln_count_customer = 3 then
          
           begin
               select upper(replace(vergi_no,' ','')), 
                      upper(replace(pasaport_no,' ','')), 
                      upper(replace(nufus_cuzdani_seri_no,' ','')),
                      musteri_tipi_kod
               into ls_tax_number_1,
                    ls_passport_1,
                    ls_identity_serial_no_1,
                    ls_customer_type_1
                     from cbs_musteri 
                                where musteri_no = ln_customer_list(1)
                                 and durum_kodu = 'A';
                                 
              select  upper(replace(vergi_no,' ','')), 
                      upper(replace(pasaport_no,' ','')), 
                      upper(replace(nufus_cuzdani_seri_no,' ','')),
                     musteri_tipi_kod
               into ls_tax_number_2,
                    ls_passport_2,
                    ls_identity_serial_no_2,
                    ls_customer_type_2
                     from cbs_musteri 
                          where musteri_no = ln_customer_list(2)
                                 and durum_kodu = 'A';
                                 
                ln_customer_number_second := ln_customer_list(2);
                
                if (ls_customer_type_1 = ls_customer_type_2) then
                    raise le_duplicate_phone_number;
                end if;
                                 
                if (ls_tax_number_1 != ls_tax_number_2 and ls_passport_1 != ls_passport_2 and ls_identity_serial_no_1 != ls_identity_serial_no_2) then
                    raise le_duplicate_phone_number;
                end if;
 
           exception 
             when others then       
               return '456';          
           end;
    
    else
          select upper(replace(vergi_no,' ','')) ,
                 upper(replace(pasaport_no,' ','')) ,
                 upper(replace(nufus_cuzdani_seri_no,' ',''))
               into ls_tax_number_1,
                    ls_passport_1,
                    ls_identity_serial_no_1
                     from cbs_musteri 
                                where musteri_no = ln_customer_list(1)
                                 and durum_kodu = 'A';           
    end if;
            
   if  upper(ps_customer_id) in (ls_tax_number_1, ls_passport_1, ls_identity_serial_no_1, ls_tax_number_2, ls_passport_2, ls_identity_serial_no_2)   then
       ls_owner := 'true';
   else
       ls_owner := 'false';
   end if;
   
   ls_owner_masked_full_name := pkg_int_customer_inq.getcustomermaskedname(ps_lang, ln_customer_list(1));
   
    open pc_ref for
           select ls_owner as owner, 
                  ls_owner_masked_full_name as owner_masked_full_name
                             from dual;
     
   open pc_ref2 for
           select min(ch.external_account_no) as iban, 
                  ch.currency_code as currency_code
                             from cbs_vw_checking_account ch
                                       where customer_no in (ln_customer_list(1), nvl(ln_customer_number_second, ln_customer_list(1)))
                                            and status = 'A' 
                                            and module_type_code = 'CURRENT'
                                            and product_type_code in ('CURRENT', 'DEMAND DEP', 'COLLATERAL') 
                                            and product_class_code not in ('OVERBALANCE-LC', 'OVERBALANCE-FC')
                                            group by currency_code;
    return ls_returncode;
    
EXCEPTION 
    when le_phone_number_not_found then
          return '454'; 
    when le_duplicate_phone_number then
          return '456'; 
    when others then
          log_at('GetCheckingAccountByPhone', sqlerrm, dbms_utility.format_error_backtrace);
          raise;        
END;              
                      
FUNCTION GetNewCheckingAccount(ps_lang varchar2,
                               ps_customer_id varchar2,
                               ps_name varchar2,
                               ps_currency_code varchar2,
                               pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_transaction_number number;
ln_transaction_code number;
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ln_channel_code number; 
ln_cash_code number; 
ls_branch_code varchar(10);
ls_checkbook varchar2(1);
ln_account_transaction_code number;
ln_base_number_of_days number;
ls_extract_edition_code varchar2(1);
ls_direct_debit varchar2(1);
ls_direct_debit_annual varchar2(1);
ln_count number; 
ld_pass_exp_date date;
ln_customer_number number; 
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
le_account_limit exception;
le_bad_list exception;
le_blockage exception;
le_passport exception;
le_branch_not_active exception;
BEGIN

    ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
      
    if ln_customer_number is null then
        raise le_customer_not_found;
    end if;
      
    ls_branch_code  := pkg_musteri.sf_bolum_kodu_al(ln_customer_number);
    
    if pkg_int_customer_inq.checkcustbranchisnotactive(ls_branch_code) then
       raise le_branch_not_active;
    end if;
    
    select count(*) into ln_count from cbs_vw_checking_account where 
                                                    customer_no = ln_customer_number 
                                                    and currency_code = ps_currency_code
                                                    and status = 'A' 
                                                    and module_type_code = 'CURRENT'
                                                    and product_type_code ='DEMAND DEP'
                                                    and product_class_code in ('NON INT.BEARING-FC', 'NON INT.BEARING-LC');
                                                    
           
    if ln_count > 10 then
       raise le_account_limit;
    end if;
    
    select count(*) into ln_count from cbs_bad_list where 
                                    customer_no = ln_customer_number 
                                    and status_code = 'ACTIVE';
                                    
          
    if ln_count > 0 then
        raise le_bad_list;
    end if;
     
    select count(*) into ln_count from cbs_bloke where musteri_no = ln_customer_number 
                                                   and durum_kodu = 'A' 
                                                   and bloke_neden_kodu in (70, 1);
                                                   
    if ln_count > 0 then
        raise le_blockage;
    end if;
    
    ln_count := pkg_int_customer_inq.checkforpassportexpireddate(ps_customer_id); 
    
    if ln_count != 1 then
        raise le_passport;
    end if; 
    
    ls_module_type_code := 'CURRENT';
    ls_product_type_code := 'DEMAND DEP';
      
    if ps_currency_code = pkg_genel.lc_al then
         ls_product_class_code := 'NON INT.BEARING-LC';
    else
         ls_product_class_code := 'NON INT.BEARING-FC';
    end if;
      
    open pc_ref for
      select 
               ps_name as short_name, 
               '*****' as iban,
               '*****' as account_number, 
              'checking' account_type, 
              'individual' as owner_type,
               ps_currency_code as currency_code,
               pkg_muhasebe.banka_tarihi_bul as opening_date, 
              'draft' as status, 
               ls_branch_code as branch_code, 
               pkg_genel.bolum_adi_al(ls_branch_code) as branch_name, 
               0 as balance, 
               0 as available_balance, 
               ls_module_type_code as module_type_code, 
               pkg_genel.modul_tur_adi_al(ls_module_type_code) as module_type_name,
               ls_product_type_code as product_type_code,
               pkg_genel.urun_tur_adi_al(ls_module_type_code, ls_product_type_code) as product_type_name, 
               ls_product_class_code as product_class_code, 
               pkg_genel.urun_adi_al(ls_module_type_code, ls_product_type_code, ls_product_class_code) as product_class_name  
      from dual;
           
    return ls_returncode;
    
EXCEPTION 
    when le_customer_not_found then
          return '454'; 
    when le_account_limit then
          return '456'; 
    when le_bad_list then
          return '457'; 
    when le_blockage then  
          return '461';   
    when le_passport then
          return '463'; 
    when le_branch_not_active then
          return '464'; 
    when no_data_found then
          return '454';  
    when others then
          raise;      
END;                         
                          
FUNCTION GetCheckingAccountBalance(ps_iban varchar2,
                           pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_returncode varchar2(3) := '000';
BEGIN
 
        open pc_ref for
            select v.bakiye + v.bloke_tutari as balance, 
                   pkg_hesap.kullanilabilir_bakiye_al(v.hesap_no) as available_balance
            from cbs_vw_hesap_izleme v
            where v.external_hesap_no = ps_iban
                  and v.durum_kodu = 'A';

        return ls_returncode;
 
EXCEPTION 
    when others then
        raise;      
END;

--EOM Checking Accounts

/***************************************************************************/
/***************************************************************************/

--BOM Saving Accounts

FUNCTION GetSavingAccount(ps_lang varchar2,
                          ps_account_number varchar2,
                          pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ls_owner_type varchar(100 byte);
ls_customer_type varchar(1 byte);
ls_returncode varchar2(3) := '000';
BEGIN



    ls_customer_type := pkg_int_customer_inq.GetCustomerTypeByAccount(ps_account_number);
             
    if pkg_int_account_inq.CheckJoinAccountByAccount(ps_account_number) then
         ls_owner_type := 'partner';
    elsif ls_customer_type is not null and ls_customer_type = '2' then
         ls_owner_type := 'company';
    else
         ls_owner_type := 'individual';
    end if;
    
     open pc_ref for
        select 
               short_name, 
               account_no as account_number, 
              'saving' account_type, 
               ls_owner_type as owner_type,
               currency_code,
               opening_date + (sysdate - trunc(sysdate)) as opening_date, 
               expiry_date + (sysdate - trunc(sysdate)) as due_date,
               nvl(expiry_date - trunc(sysdate), 0) as remaining_days, 
               decode(status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
               branch_code, 
               pkg_genel.bolum_adi_al(branch_code) as branch_name, 
               balance, 
               pkg_hesap.kullanilabilir_bakiye_al(account_no) as available_balance, 
               nvl(interest_rate, 0) as rate,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as gross_amount,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as net_amount,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as gross_amount_on_expiry,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as net_amount_on_expiry,
               module_type_code, 
               Pkg_Genel.modul_tur_adi_al(module_type_code) as module_type_name,
               product_type_code,
               Pkg_Genel.urun_tur_adi_al(module_type_code, product_type_code) as product_type_name, 
               product_class_code, 
               Pkg_Genel.urun_adi_al(module_type_code, product_type_code, product_class_code) as product_class_name,
               nvl(blockage_amount, 0) as blockage_amount
          from cbs_vw_saving_account main_acc
               where account_no = to_number(ps_account_number)
                     and product_class_code not in ('INTEREST-LC','INTEREST-FC')
                     and status = 'A';
           
    return ls_returncode;
    
EXCEPTION
    when no_data_found then
        return '454';  
    when others then
        raise;      
END;

FUNCTION GetSavingAccountList(ps_lang varchar2,
                              ps_customer_id varchar2, 
                              ps_currency_code varchar2 default null,
                              pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_customer_number number;
ln_customer_number_second number;
ls_returncode varchar2(3) := '000';
le_customer_not_found exception;
BEGIN

  ln_customer_number := pkg_int_customer_inq.getcustomerno(ps_customer_id);
  
  if ln_customer_number is null then
    raise le_customer_not_found;
  end if;
  
  ln_customer_number_second := pkg_int_customer_inq.GetCustomerNoForTheSecondType(ps_customer_id);
  
    open pc_ref for    
       select 
               short_name, 
               account_no as account_number, 
              'saving' account_type, 
              'individual' as owner_type,
               currency_code,
               opening_date + (sysdate - trunc(sysdate)) as opening_date, 
               expiry_date + (sysdate - trunc(sysdate)) as due_date,
               nvl(expiry_date - trunc(sysdate), 0) as remaining_days, 
               decode(status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
               branch_code, 
               pkg_genel.bolum_adi_al(branch_code) as branch_name, 
               balance, 
               pkg_hesap.kullanilabilir_bakiye_al(account_no) as available_balance, 
               nvl(interest_rate, 0) as rate,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as gross_amount,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as net_amount,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as gross_amount_on_expiry,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as net_amount_on_expiry,
               module_type_code, 
               Pkg_Genel.modul_tur_adi_al(module_type_code) as module_type_name,
               product_type_code,
               Pkg_Genel.urun_tur_adi_al(module_type_code, product_type_code) as product_type_name, 
               product_class_code, 
               Pkg_Genel.urun_adi_al(module_type_code, product_type_code, product_class_code) as product_class_name,
               nvl(blockage_amount, 0) as blockage_amount
          from cbs_vw_saving_account main_acc
              where customer_no = ln_customer_number
                    and status = 'A'
                    and product_class_code not in ('INTEREST-LC','INTEREST-FC')
                    and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                        connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                              or trim(ps_currency_code) is null)
           union
           select 
               short_name, 
               account_no as account_number, 
              'saving' account_type, 
              'company' as owner_type,
               currency_code,
               opening_date + (sysdate - trunc(sysdate)) as opening_date, 
               expiry_date + (sysdate - trunc(sysdate)) as due_date,
               nvl(expiry_date - opening_date, 0) as remaining_days, 
               decode(status,'A', 'active', 'K', 'close', 'I', 'cancel', 'D', 'draft') as status, 
               branch_code, 
               pkg_genel.bolum_adi_al(branch_code) as branch_name, 
               balance, 
               pkg_hesap.kullanilabilir_bakiye_al(account_no) as available_balance, 
               nvl(interest_rate, 0) as rate,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as gross_amount,
               (select balance from cbs_vw_saving_account accrual where accrual.main_saving_account_no = main_acc.account_no) as net_amount,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as gross_amount_on_expiry,
               round(balance  * interest_rate * (expiry_date - coalesce(extension_date, value_date )) / (base_number_of_days * 100), 2) as net_amount_on_expiry,
               module_type_code, 
               Pkg_Genel.modul_tur_adi_al(module_type_code) as module_type_name,
               product_type_code,
               Pkg_Genel.urun_tur_adi_al(module_type_code, product_type_code) as product_type_name, 
               product_class_code, 
               Pkg_Genel.urun_adi_al(module_type_code, product_type_code, product_class_code) as product_class_name,
               nvl(blockage_amount, 0) as blockage_amount
          from cbs_vw_saving_account main_acc
              where ln_customer_number_second is not null
                    and customer_no = ln_customer_number_second
                    and status = 'A'
                    and product_class_code not in ('INTEREST-LC','INTEREST-FC')
                    and ((currency_code in (select trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) curr
                                               from dual
                                        connect by trim(regexp_substr(ps_currency_code, '[^,]+', 1, level)) is not null) and trim(ps_currency_code) is not null) 
                              or trim(ps_currency_code) is null);   
               
          
    return ls_returncode;
        
EXCEPTION 
     when le_customer_not_found then
          return '454'; 
     when no_data_found then
          return '490';  
     when others then
          raise;      
END;

FUNCTION GetSavingAccountRates(pc_currency_code varchar2,
                               ps_customer_id varchar2 default null,
                               pc_ref OUT CursorReferenceType) RETURN varchar2
IS
ln_min_amount_kgs number;
ln_min_amount_usd number;
ln_min_amount_rub number;
ls_returncode VARCHAR2(3) := '000';
BEGIN

    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_KGS',ln_min_amount_kgs);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_USD',ln_min_amount_usd);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_RUB',ln_min_amount_rub);
    
    open pc_ref for
       select vade_1 as starting_in_days, 
                vade_2 as finishing_in_days, 
                round(vade_1 / 30) as starting_in_months, 
                round(vade_2 / 30) as finishing_in_months,
                decode(pc_currency_code, 'RUB', rub, 'USD', usd, 'EUR', eur, trl) as rate,
                decode(pc_currency_code, 'RUB', ln_min_amount_rub, 'USD', ln_min_amount_usd, 'EUR', 0, ln_min_amount_kgs) as min_amount
                    from cbs_cari_vadeli_mevduat_fo
                         where tarih = pkg_muhasebe.banka_tarihi_bul 
                            and musteri_tipi = '1'
                                 order by vade_1, vade_2;
            
      return ls_returncode;
      
EXCEPTION 
    when others then
        raise;      
END;

FUNCTION GetNewSavingAccount(ps_lang varchar2,
                             ps_source_account varchar2,
                             ps_name varchar2,
                             ps_amount varchar2,
                             ps_day varchar2,
                             ps_due_date varchar2,
                             pc_ref OUT CursorReferenceType) RETURN varchar2 
IS
ls_module_type_code varchar2(20);
ls_product_type_code varchar2(20);
ls_product_class_code varchar2(20);
ld_due_date date;
ld_due_date2 date;
ln_amount number;
ln_interest_rate number := 0;
ln_account_number number;
ls_currency_code varchar(10);
ls_branch_code varchar2(10);
ln_min_amount_kgs number;
ln_min_amount_usd number;
ln_min_amount_rub number;

ls_returncode varchar2(3) := '000';

le_branch_not_active exception;
le_min_sum exception;
nointerestratesondate exception;
notenoughbalance exception;
BEGIN

    ln_amount := to_number(ps_amount,'999999999999999.999');
    ln_account_number := to_number(ps_source_account);
    ls_currency_code  := pkg_hesap.hesaptandovizkodual(ln_account_number);
    ls_branch_code  := pkg_hesap.hesapsubeal(ln_account_number);
    
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_KGS',ln_min_amount_kgs);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_USD',ln_min_amount_usd);
    pkg_parametre.deger('2003_MIN_AMOUNT_DEP_IB_RUB',ln_min_amount_rub);
    
    if ls_currency_code = 'KGS' then
        if ln_amount < ln_min_amount_kgs then
            raise le_min_sum;
        end if;
    elsif ls_currency_code = 'USD' then
        if ln_amount < ln_min_amount_usd then
            raise le_min_sum;
        end if;
    elsif ls_currency_code = 'RUB' then
        if ln_amount < ln_min_amount_rub then
            raise le_min_sum;
        end if;
    end if;
    
    if pkg_int_customer_inq.checkcustbranchisnotactive(ls_branch_code) then
       raise le_branch_not_active;
    end if;
    
    if pkg_hesap.kullanilabilir_bakiye_al(ln_account_number) < ln_amount then
         raise notenoughbalance;
    end if;
    
    
    if ps_day > 0 then
    
     select decode(ls_currency_code, 'RUB', rub, 'USD', usd, 'EUR', eur, trl)
        into ln_interest_rate
            from cbs_cari_vadeli_mevduat_fo
                where 
                    tarih = pkg_muhasebe.banka_tarihi_bul 
                    and vade_1 <= to_number(ps_day)
                    and vade_2 >= to_number(ps_day)
                    and musteri_tipi = '1';
        
        select to_date(to_char(sysdate + to_number(ps_day), 'YYYY-MM-DD'), 'YYYY-MM-DD') into ld_due_date from dual;
        
    elsif ps_due_date is not null then
    
     ld_due_date2 := to_date(substr(ps_due_date, 1, 10),'YYYY-MM-DD');
     
      if ld_due_date2 < pkg_muhasebe.banka_tarihi_bul then
        raise nointerestratesondate;
      end if;
    
      select decode(ls_currency_code,'RUB',rub,'USD',usd,'EUR',eur,trl)
            into ln_interest_rate
            from cbs_cari_vadeli_mevduat_fo
                where tarih = pkg_muhasebe.banka_tarihi_bul 
                    and vade_1 <= ld_due_date2 - sysdate
                    and vade_2 >= ld_due_date2 - sysdate
                    and musteri_tipi = '1';
        
        ld_due_date := ld_due_date2;
    else
      raise nointerestratesondate;
    end if;
    
    ld_due_date := Pkg_Tarih.tarihten_sonraki_isgunu(ld_due_date-1);
    
    if ld_due_date < pkg_muhasebe.banka_tarihi_bul   then
        raise nointerestratesondate;
    end if;
        
    if ls_currency_code = pkg_genel.lc_al then
        ls_product_class_code := 'LC';
    else
        ls_product_class_code := 'FC';
    end if;
    
    if ld_due_date - pkg_muhasebe.banka_tarihi_bul >= 366 then
        ls_module_type_code := 'TIME DEP.';
        ls_product_type_code := 'LONG TERM';
    else
        ls_module_type_code := 'TIME DEP.';
        ls_product_type_code := 'SHORT TERM';
    end if;
 
    open pc_ref for
         select 
                   ps_name as short_name, 
                   '******' as account_number, 
                  'saving' account_type, 
                   ls_currency_code as currency_code,
                   pkg_muhasebe.banka_tarihi_bul + (sysdate - trunc(sysdate)) as opening_date, 
                   ld_due_date + (sysdate - trunc(sysdate)) as due_date,
                   nvl(ld_due_date - pkg_muhasebe.banka_tarihi_bul, 0) as remaining_days, 
                   'draft' as status, 
                   ls_branch_code as branch_code, 
                   pkg_genel.bolum_adi_al(ls_branch_code) as branch_name, 
                   ln_amount as balance, 
                   ln_amount as available_balance, 
                   nvl(ln_interest_rate, 0) as rate,
                   0 as gross_amount,
                   0 as net_amount,
                   round(ln_amount  * ln_interest_rate * (ld_due_date - pkg_muhasebe.banka_tarihi_bul) / (365 * 100), 2) as gross_amount_on_expiry,
                   round(ln_amount  * ln_interest_rate * (ld_due_date - pkg_muhasebe.banka_tarihi_bul) / (365 * 100), 2) as net_amount_on_expiry,
                   ls_module_type_code as module_type_code, 
                   Pkg_Genel.modul_tur_adi_al(ls_module_type_code) as module_type_name,
                   ls_product_type_code as product_type_code,
                   Pkg_Genel.urun_tur_adi_al(ls_module_type_code, ls_product_type_code) as product_type_name, 
                   ls_product_class_code as product_class_code, 
                   Pkg_Genel.urun_adi_al(ls_module_type_code, ls_product_type_code, ls_product_class_code) as product_class_name  
              from dual;
               
    return ls_returncode;
    
EXCEPTION
    when le_branch_not_active then
          return '464'; 
    when le_min_sum then
          return '460'; 
    when notenoughbalance then
          return '456';
    when nointerestratesondate then
          return '461';
    when no_data_found then
          return '490';  
    when others then
          raise;      
END;

--EOM Saving Accounts

/***************************************************************************/   
    
END;
/

