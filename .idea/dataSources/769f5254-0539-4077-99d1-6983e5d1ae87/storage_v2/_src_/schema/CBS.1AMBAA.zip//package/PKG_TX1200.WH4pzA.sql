create PACKAGE     PKG_TX1200 IS

/******************************************************************************
   Name       : PKG_TX1200
   Created By : Seval Balci
   Date          : 27.08.03
   Purpose      : Hesaba Bloke Konulmas?
******************************************************************************/

 TYPE GenCurType IS REF CURSOR;

  Procedure Kontrol_Sonrasi(pn_islem_no number);           -- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);          -- Islem dogrulandiktan sonra cagrilir
  Procedure    Dogrulama_Iptal_Sonrasi (pn_islem_no number); -- Islem dogrulamas? iptal edildikten onra cagrilir

  Procedure Onay_Sonrasi(pn_islem_no number);              -- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);          -- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);              -- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);            -- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);              -- Islemin muhasebelesmesi icin cagrilir
  Procedure Iptal_Sonrasi(pn_islem_no number);              -- Islem muhasebesi o g?n i?inde iptal edilirse cagrilir

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );      -- Islem muhasebe iptalinin onay sonrasi cagrilir.
  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number );  -- Islem muhasebe iptalinin onay sonrasi cagrilir

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number );
  
  Procedure get_customer_accounts(pn_cust_no CBS_MUSTERI.MUSTERI_NO%TYPE, pRetCur IN OUT GenCurType); -- Get all accounts of the customer
  
  Procedure save_rows(pn_tx_no cbs_bloke_islem.tx_no%type, pn_cust_no cbs_musteri.musteri_no%type, pn_hesap_no cbs_bloke_islem.hesap_no%type, pc_doviz_kodu cbs_bloke_islem.doviz_kodu%type, pn_bloke_tutari cbs_bloke_islem.bloke_tutari%type,
    pn_bloke_neden_kodu cbs_bloke_islem.bloke_neden_kodu%type, pc_aciklama cbs_bloke_islem.aciklama%type, pd_bloke_tarihi cbs_bloke_islem.bloke_tarihi%type, pd_bloke_bitis_tarihi cbs_bloke_islem.bloke_bitis_tarihi%type); -- save row to cbs_bloke_islem
END;

/

