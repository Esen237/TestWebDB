create PACKAGE BODY     "PKG_JOBS" IS

           TEMPLATE_PATH VARCHAR2(100)   :='C:\CBSDATA\TEMPLATE';
        CURRENCY_PATH VARCHAR2(100)      :='C:\CBSDATA\CURRENCY';
        CURRARCHIVE_PATH VARCHAR2(100):='C:\CBSDATA\CURRENCY\ARCHIVE';
        UTILITY_PATH VARCHAR2(100):='C:\CBSDATA\UTILITY';
        UTILITY_ARCHIVE_PATH VARCHAR2(100):='C:\CBSDATA\UTILITY\ARCHIVE';

--------------------------------------------------------------------------------------
PROCEDURE SendKCELLCASHPayments( ps_externalno IN VARCHAR2) IS
   ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(250);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;

   CURSOR cursor_aps IS
        SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.DETAIL_ID, d.NAME_TITLE ABONE_NAME
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='KCELL'
        AND m.COLLECTION_TYPE IN ('CASH')
        AND m.TX_NO=d.TX_NO;

    row_aps    cursor_aps%ROWTYPE;
    i NUMBER:=1;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;
BEGIN
    ls_filepre:='dem' || TO_CHAR(SYSDATE,'HH24MISS');

    ls_fileext:= TO_CHAR(SYSDATE,'MM');
    IF ls_fileext='10' THEN
       ls_fileext:='a';
    ELSIF ls_fileext='11' THEN
       ls_fileext:='b';
    ELSIF ls_fileext='12' THEN
       ls_fileext:='c';
    ELSE
       ls_fileext:=SUBSTR(ls_fileext,2,1);
    END IF;
    ls_fileext:=ls_fileext ||  TO_CHAR(SYSDATE,'DD');

    ls_filename:=ls_filepre || '.'|| ls_fileext;

    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;

    IF cursor_aps%FOUND THEN

           f:=UTL_FILE.FOPEN(UTILITY_PATH || '\KCELL',ls_filename,'w',2100);

        ls_content:='190501788' || ls_ara || '1467612' || ls_ara || TO_CHAR(SYSDATE,'YYYY/MM/DD');
        ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        WHILE cursor_aps%FOUND
        LOOP

            ls_content:=TO_CHAR(row_aps.COLLECTION_DATE,'DD/MM/YYYY');
            ls_content:=ls_content || ls_ara || '0' || ls_ara;
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_AMOUNT*100);
            ls_content:=ls_content || ls_ara ;
            ls_content:=ls_content || To_Dos(row_aps.ABONE_NAME);
            ls_content:=ls_content || ls_ara || ls_ara;
            ls_content:=ls_content || '190501788';
            ls_content:=ls_content || ls_ara || ls_ara || ls_ara;
            ls_content:=ls_content || '701' || row_aps.PHONE_NO;
            ls_content:=ls_content || ls_ara || ls_ara;
            ls_content:=ls_content || '190501788';
            ls_content:=ls_content || LPAD(TO_CHAR(SYSDATE,'YYYYMMDDHH24MI'),17,' ') || row_aps.BRANCH;

            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

            UPDATE  CBS_COLLECTION_DETAIL
            SET STATUS_CD='sSEND'
            WHERE TX_NO = row_aps.TX_NO
            AND DETAIL_ID = row_aps.DETAIL_ID;

        FETCH cursor_aps INTO row_aps;
        END LOOP;


        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;
EXCEPTION
     WHEN OTHERS THEN
          ROLLBACK;
        ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

        ls_content:=SQLERRM;

        INSERT INTO CBS_EMAIL_MESSAGES
        (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
        VALUES
        (ln_messageid, 'KCELL', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-KCELL CASH PAYMENT JOB',ls_content);


END;
---------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
PROCEDURE SendKCELLNONCASHPayments( ps_externalno IN VARCHAR2) IS
   ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(250);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
   SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.DETAIL_ID, d.NAME_TITLE ABONE_NAME
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='KCELL'
        AND m.COLLECTION_TYPE IN ('CLEARING','ACCOUNT')
        AND m.TX_NO=d.TX_NO;

    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN
    ls_filepre:='dem' || TO_CHAR(SYSDATE,'HH24MISS');

    ls_fileext:= TO_CHAR(SYSDATE,'MM');
    IF ls_fileext='10' THEN
       ls_fileext:='a';
    ELSIF ls_fileext='11' THEN
       ls_fileext:='b';
    ELSIF ls_fileext='12' THEN
       ls_fileext:='c';
    ELSE
       ls_fileext:=SUBSTR(ls_fileext,2,1);
    END IF;
    ls_fileext:=ls_fileext ||  TO_CHAR(SYSDATE,'DD');

    ls_filename:=ls_filepre || ls_fileext || '.prn';

    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

           f:=UTL_FILE.FOPEN(UTILITY_PATH || '\KCELL',ls_filename,'w',2100);

        ls_content:='190501788' || ls_ara || '1467612' || ls_ara || TO_CHAR(SYSDATE,'YYYY/MM/DD');

        ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        WHILE cursor_aps%FOUND
        LOOP

            ls_content:=TO_CHAR(row_aps.COLLECTION_DATE,'DD/MM/YYYY');
            ls_content:=ls_content || ls_ara || '0' || ls_ara;
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_AMOUNT*100);
            ls_content:=ls_content || ls_ara ;
            ls_content:=ls_content || To_Dos(row_aps.ABONE_NAME);
            ls_content:=ls_content || ls_ara || ls_ara;
            ls_content:=ls_content || NVL(row_aps.FROMBANK_BIC,'190501788');
            ls_content:=ls_content || ls_ara || ls_ara || ls_ara;
            ls_content:=ls_content || '0000000';--PHONE NO
            ls_content:=ls_content || ls_ara || ls_ara;
            ls_content:=ls_content || NVL(row_aps.FROMBANK_BIC,'190501788');
            ls_content:=ls_content || LPAD(TO_CHAR(SYSDATE,'YYYYMMDDHH24MI'),17,' ') || row_aps.BRANCH;
            ls_content:=ls_content || To_Dos(row_aps.EXPLANATION);

            UPDATE  CBS_COLLECTION_DETAIL
            SET STATUS_CD='sSEND'
            WHERE TX_NO = row_aps.TX_NO
            AND DETAIL_ID = row_aps.DETAIL_ID;

            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        FETCH cursor_aps INTO row_aps;
        END LOOP;


        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;
EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM;

            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'KCELL', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-KCELL NONCASH PAYMENT JOB',ls_content);

END;
---------------------------------------------------------------------------------------
PROCEDURE SendKMOBILEPayments( ps_externalno IN VARCHAR2) IS
   ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
        SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.DETAIL_ID,d.NAME_TITLE ABONE_NAME
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='KMOBILE'
        AND m.TX_NO=d.TX_NO;

    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN
    ls_filepre:='db0' || TO_CHAR(SYSDATE,'HH24MI');

    ls_fileext:= TO_CHAR(SYSDATE,'MM');
    IF ls_fileext='10' THEN
       ls_fileext:='a';
    ELSIF ls_fileext='11' THEN
       ls_fileext:='b';
    ELSIF ls_fileext='12' THEN
       ls_fileext:='c';
    ELSE
       ls_fileext:=SUBSTR(ls_fileext,2,1);
    END IF;
    ls_fileext:=ls_fileext ||  TO_CHAR(SYSDATE,'DD');

    ls_filename:=ls_filepre || '.'|| ls_fileext;

    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\KMOBILE',ls_filename,'w',2100);

        WHILE cursor_aps%FOUND
        LOOP
            IF row_aps.COLLECTION_TYPE IN ('CASH','ACCOUNT') THEN
               ls_content:='333' ||row_aps.PHONE_NO;
            ELSE
               ls_content:='1000000';
            END IF;
            ls_content:=ls_content || ls_ara;
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD/MM/YYYY HH24:MI');
            ls_content:=ls_content || ls_ara;
            ls_content:=ls_content || LPAD(LTRIM(RTRIM(TO_CHAR(row_aps.COLLECTION_AMOUNT,'99999999.99'))),10,'0');
            ls_content:=ls_content || ls_ara ;
            ls_content:=ls_content || '000000000';--ACC NUM
            ls_content:=ls_content || ls_ara;
            ls_content:=ls_content || '0';--Doc number
            ls_content:=ls_content || ls_ara;
            ls_content:=ls_content || To_Dos(row_aps.ABONE_NAME);--ACC NUM
            ls_content:=ls_content || ls_ara2;
            ls_content:=ls_content || To_Dos(NVL(row_aps.EXPLANATION,' '));

            UPDATE  CBS_COLLECTION_DETAIL
            SET STATUS_CD='sSEND'
            WHERE TX_NO = row_aps.TX_NO
            AND DETAIL_ID = row_aps.DETAIL_ID;

            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN OTHERS THEN
             ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM;

            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'KMOBILE', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-KMOBILE PAYMENT JOB',ls_content);

END;
---------------------------------------------------------------------------------------
PROCEDURE SendALMATYTELPayments( ps_externalno IN VARCHAR2) IS
ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
           SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.INVOICE_NO,d.SUBSCRIPTION_NO,d.INSTITUTION_KEY_NO, d.DETAIL_ID
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ALMATY TELECOM'
        AND m.COLLECTION_DATE=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul)
        AND m.TX_NO=d.TX_NO;


    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    ln_recordcount      NUMBER;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN

    ls_filename:='db' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'DDMMYY') || '.txt';

    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\ALMATYTELECOM',ls_filename,'w',2100);

        SELECT  COUNT(m.TX_NO)
        INTO ln_recordcount
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE m.TX_NO=d.TX_NO
        AND d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ALMATY TELECOM';

        WHILE cursor_aps%FOUND
        LOOP

            ls_content:='0156    10';
            ls_content:=ls_content || LPAD(row_aps.INVOICE_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,10,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_AMOUNT,'9999999999.99');

            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM;

            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'ALMATYTELECOM', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-ALMATYTELECOM PAYMENT JOB',ls_content);
END;
---------------------------------------------------------------------------------------
PROCEDURE ProcessAPSPayments( ps_option IN VARCHAR2 DEFAULT NULL)IS

    CURSOR cursor_aps IS
        SELECT  o.*,i.INSTALMENT_ID, i.INSTALMENT_DATE, i.INSTALMENT_AMOUNT
        FROM CBS_APS_ORDERS o, CBS_APS_INSTALMENTS i
        WHERE o.ORDER_ID=i.ORDER_ID
        AND o.STATUS_CD='sVALID'
        AND i.STATUS_CD IN ('sWAIT')
        AND i.INSTALMENT_DATE<=Pkg_Muhasebe.Banka_Tarihi_Bul;

    row_aps     cursor_aps%ROWTYPE;
    ln_islem_no            NUMBER;
    ln_islem_kod        NUMBER;
    lc_modul_tur_kod  VARCHAR2(10);
    lc_urun_tur_kod   VARCHAR2(10);
    lc_urun_sinif_kod VARCHAR2(20);
    ln_tutar          NUMBER;
    lc_bolum_kodu     VARCHAR2(10);
    lc_doviz_kod      VARCHAR2(3);
    ln_musteri_numara NUMBER;
    lc_hesap_numara      NUMBER;
    lc_to_hesap_numara         NUMBER;
    lc_kasa_kod          VARCHAR2(10);
    ls_description       VARCHAR2(250);
    ln_detailid           NUMBER:=1;
    ls_content            CLOB;
    ln_messageid            NUMBER;
    ln_CHARGE_AMOUNT        NUMBER;
    ls_INSTITUTION_CODE        VARCHAR2(20);
    ls_COLLECTION_ACCOUNT_NO       NUMBER;
    ls_COLLECTION_ACCOUNT_BR       VARCHAR2(10);
    ls_COLLECTION_GL               VARCHAR2(8);
    ls_COLLECTION_GL_BR               VARCHAR2(10);
    ln_cpdetailid                       NUMBER;
    AmountZeroEzception                   EXCEPTION;
BEGIN

       OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;

    WHILE cursor_aps%FOUND
    LOOP
        BEGIN
            Pkg_Aps.AddNextPayment(row_aps.ORDER_ID);

            IF row_aps.ORDER_TYPE='CARD' THEN
                   BEGIN
                    ln_musteri_numara := row_aps.FROM_CUSTOMER_NO;--pkg_hesap.GetMusteriNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                    lc_hesap_numara   := row_aps.FROM_ACCOUNT_NO;--pkg_hesap.GetHesapNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                EXCEPTION
                WHEN OTHERS THEN
                     ln_musteri_numara:=NULL;
                     lc_hesap_numara:=NULL;
                END;

                ln_islem_no             :=Pkg_Tx.islem_no_al;
                ln_islem_kod      :=2130;
                lc_modul_tur_kod  :='CARD';
                lc_urun_tur_kod   :='TRANSFER';
                lc_urun_sinif_kod :='TOCARD';
                IF row_aps.PERCENTOFBALANCE IS NULL THEN
                   ln_tutar          := row_aps.INSTALMENT_AMOUNT;
                ELSE
                   ln_tutar          := (row_aps.PERCENTOFBALANCE/100)* Pkg_Hesap.HesapBakiyeAl(lc_hesap_numara);
                END IF;

                IF NVL(ln_tutar,0)=0 THEN
                   RAISE AmountZeroEzception;
                END IF;

                lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(lc_hesap_numara);
                BEGIN
                     lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(lc_hesap_numara);
                EXCEPTION
                    WHEN OTHERS THEN
                        lc_bolum_kodu:='010';
                END;

                IF Pkg_Card.IsSalaryCard(row_aps.TO_CARD_NO)='Y' THEN
                    ln_CHARGE_AMOUNT:=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                       ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);
                ELSE
                    ln_CHARGE_AMOUNT:=0;
                END IF;
                ls_description:=NVL(row_aps.PAYMENT_DESCRIPTION,'CARD PAYMENT');

                INSERT INTO CBS_CARD_PAYMENT_ISLEM
                (TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, FROM_CUSTOMER_NO, FROM_ACCOUNT_NO, FROM_EXTERNAL_ACCOUNT, FROM_TAX_NUMBER, FROM_NAME, FROM_BANK_CODE, TO_CARD_NO, BOLUM_KODU, PAYMENT_DESCRIPTION, AMOUNT, CURRENCY_CODE, TO_CARD_CUSTOMER_NO, TO_CARD_CUSTOMER_NAME,PAYMENT_TYPE_DESC,CHARGE_ACCOUNT,CHARGE_AMOUNT)
                VALUES
                (ln_islem_no, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod, ln_musteri_numara, lc_hesap_numara, row_aps.FROM_EXTERNAL_ACCOUNT, row_aps.FROM_TAX_NUMBER, row_aps.FROM_NAME, row_aps.FROM_BANK_CODE, row_aps.TO_CARD_NO, lc_bolum_kodu, ls_description,ln_tutar,row_aps.CURRENCY_CODE,Pkg_Card.GetCustomerFromCardNo(row_aps.TO_CARD_NO),row_aps.TO_NAME,'P2C',lc_hesap_numara,ln_CHARGE_AMOUNT);

                Pkg_Baglam.yarat(lc_bolum_kodu,2);

                Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);


                Pkg_Clearing.Process_Transaction(ln_islem_no);

            ELSIF row_aps.ORDER_TYPE='CLEARING' THEN

                ln_islem_no             :=Pkg_Tx.islem_no_al;
                ln_islem_kod      :=2102;
                lc_modul_tur_kod  :='CLEARING';
                lc_urun_tur_kod   :='OUTGOING';
                lc_urun_sinif_kod :='ACCOUNT-IND-1';
                lc_doviz_kod      :=Pkg_Genel.lc_al;

                BEGIN
                    IF row_aps.FROM_EXTERNAL_ACCOUNT='000711000' THEN--STAFF
                       ln_musteri_numara :=row_aps.FROM_CUSTOMER_NO;
                       lc_hesap_numara:=row_aps.FROM_ACCOUNT_NO;
                    ELSE
                        ln_musteri_numara :=Pkg_Hesap.GetMusteriNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                        lc_hesap_numara   :=Pkg_Hesap.GetHesapNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT,lc_doviz_kod);
                    END IF;
                EXCEPTION
                WHEN OTHERS THEN
                     ln_musteri_numara:=NULL;
                     lc_hesap_numara:=NULL;
                END;
                IF row_aps.PERCENTOFBALANCE IS NULL THEN
                   ln_tutar          := row_aps.INSTALMENT_AMOUNT;
                ELSE
                   ln_tutar          := (row_aps.PERCENTOFBALANCE/100)* Pkg_Hesap.HesapBakiyeAl(lc_hesap_numara);
                END IF;
                BEGIN
                     lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(lc_hesap_numara);
                EXCEPTION
                    WHEN OTHERS THEN
                        lc_bolum_kodu:='010';
                END;

                ls_description:=NVL(row_aps.PAYMENT_DESCRIPTION,'CLEARING PAYMENT');

                ln_CHARGE_AMOUNT  :=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

                INSERT INTO CBS_CLEARING_MT102_TRAN
                (TX_NO, MODUL_TUR_KOD, URUN_TUR_KOD, URUN_SINIF_KOD, PAYMENT_TYPE, REF_NO, VALUE_DATE, MSG_KIND,
                MSG_STATUS, TOTAL_TRAN_AMOUNT, TOTAL_TRAN_CURR, CHARGE_AMOUNT,
                CHARGE_USER_STAT, CHARGE_PAYMENTCODE, BRANCH_CODE)
                VALUES
                (ln_islem_no, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod, 'SCLEAR', NULL,row_aps.INSTALMENT_DATE, '100',
                'sNEW', ln_tutar, row_aps.CURRENCY_CODE, ln_CHARGE_AMOUNT,
                row_aps.STATISTICS_USER_FROM || row_aps.STATISTICS_USER_TO, row_aps.STATISTICS_PAYMENT_CODE,'010');

                INSERT INTO CBS_CLEARING_MT102_DETAIL_TRAN
                (TX_NO, MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR,
                TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME,
                FROM_RNN, FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO,
                FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT, TO_BRANCH, TO_HQ,
                TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO,
                DOC_NUM, DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_ASSIGN,
                DOC_BCLASS, REF_NO, CHK_TRAN_AMOUNT, CHK_FROM_ACCOUNT, CHK_TO_BRANCH, CHK_TO_ACCOUNT, CHK_TO_RNN, CHK_DOC_BCLASS)
                VALUES
                (ln_islem_no, NULL, ln_detailid, row_aps.INSTALMENT_DATE,  row_aps.CURRENCY_CODE,
                ln_tutar,'D', row_aps.FROM_EXTERNAL_ACCOUNT, row_aps.FROM_NAME,
                row_aps.FROM_TAX_NUMBER, NULL,NULL, SUBSTR(row_aps.STATISTICS_USER_FROM,1,1), SUBSTR(row_aps.STATISTICS_USER_FROM,2,1),
                row_aps.FROM_BANK_CODE, Pkg_Hesap.GetBankHQ(row_aps.FROM_BANK_CODE),NULL, row_aps.TO_BANK_CODE, Pkg_Hesap.GetBankHQ(row_aps.TO_BANK_CODE),
                NULL,row_aps.TO_EXTERNAL_ACCOUNT, row_aps.TO_NAME, row_aps.TO_RNN, SUBSTR(row_aps.STATISTICS_USER_TO,1,1), SUBSTR(row_aps.STATISTICS_USER_TO,2,1),
                0, row_aps.INSTALMENT_DATE, '07', '01', row_aps.STATISTICS_PAYMENT_CODE, '01', '50', row_aps.PAYMENT_DESCRIPTION,
                '000000', NULL, TO_NUMBER(REPLACE(row_aps.INSTALMENT_AMOUNT,',','.')), row_aps.FROM_EXTERNAL_ACCOUNT, row_aps.TO_BANK_CODE, row_aps.TO_EXTERNAL_ACCOUNT, row_aps.TO_RNN, '000000');

                Pkg_Baglam.yarat(lc_bolum_kodu,2);

                Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

                --pkg_clearing.Process_Transaction(ln_islem_no);

            ELSIF  row_aps.ORDER_TYPE='MT' THEN

                BEGIN
                    ln_musteri_numara := row_aps.FROM_CUSTOMER_NO;--pkg_hesap.GetMusteriNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                    lc_hesap_numara   := row_aps.FROM_ACCOUNT_NO;--pkg_hesap.GetHesapNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                    lc_to_hesap_numara:= row_aps.TO_ACCOUNT;--pkg_hesap.GetHesapNoFromExternal(row_aps.TO_EXTERNAL_ACCOUNT);

                EXCEPTION
                WHEN OTHERS THEN
                     ln_musteri_numara:=NULL;
                     lc_hesap_numara:=NULL;
                     lc_to_hesap_numara:=NULL;
                END;

                ln_islem_no             :=Pkg_Tx.islem_no_al;
                ln_islem_kod      :=1203;
                Pkg_Hesap.UrunBilgiAl(lc_hesap_numara,lc_modul_tur_kod,lc_urun_tur_kod,lc_urun_sinif_kod);
                IF row_aps.PERCENTOFBALANCE IS NULL THEN
                   ln_tutar          := row_aps.INSTALMENT_AMOUNT;
                ELSE
                   ln_tutar          := (row_aps.PERCENTOFBALANCE/100)* Pkg_Hesap.HesapBakiyeAl(lc_hesap_numara);
                END IF;

                lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(lc_hesap_numara);
                BEGIN
                     lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(lc_hesap_numara);
                EXCEPTION
                    WHEN OTHERS THEN
                        lc_bolum_kodu:='010';
                END;

                ls_description:=NVL(row_aps.PAYMENT_DESCRIPTION,'MONEY TRANSFER PAYMENT');

                INSERT INTO CBS_VIRMAN_ISLEM
                (TX_NO, BORC_HESAP_NO, DOVIZ_KODU, TUTAR, ALACAK_HESAP_NO, ACIKLAMA, DEKONT_BASIM_F, BORC_EXTERNAL_HESAP, BORC_VERGI_NO, ALACAK_EXTERNAL_HESAP, ALACAK_VERGI_NO)
                VALUES
                (ln_islem_no, lc_hesap_numara, lc_doviz_kod, ln_tutar, lc_to_hesap_numara, ls_description, NULL, row_aps.FROM_EXTERNAL_ACCOUNT, row_aps.FROM_TAX_NUMBER, row_aps.TO_EXTERNAL_ACCOUNT, row_aps.TO_RNN);

                Pkg_Baglam.yarat(lc_bolum_kodu,2);

                Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

                Pkg_Clearing.Process_Transaction(ln_islem_no);

            ELSIF  row_aps.ORDER_TYPE='KCELL' THEN

                BEGIN
                    ln_musteri_numara := row_aps.FROM_CUSTOMER_NO;--pkg_hesap.GetMusteriNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                    lc_hesap_numara   := row_aps.FROM_ACCOUNT_NO;--pkg_hesap.GetHesapNoFromExternal(row_aps.FROM_EXTERNAL_ACCOUNT);
                EXCEPTION
                WHEN OTHERS THEN
                     ln_musteri_numara:=NULL;
                     lc_hesap_numara:=NULL;
                     lc_to_hesap_numara:=NULL;
                END;

                ln_islem_no             :=Pkg_Tx.islem_no_al;
                ln_islem_kod      :=7004;
                lc_modul_tur_kod  :='COLLECTION';
                lc_urun_tur_kod   :='ACCOUNT';
                lc_urun_sinif_kod :='LC';

                IF row_aps.PERCENTOFBALANCE IS NULL THEN
                   ln_tutar          := row_aps.INSTALMENT_AMOUNT;
                ELSE
                   ln_tutar          := (row_aps.PERCENTOFBALANCE/100)* Pkg_Hesap.HesapBakiyeAl(lc_hesap_numara);
                END IF;

                lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(lc_hesap_numara);
                BEGIN
                     lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(lc_hesap_numara);
                EXCEPTION
                    WHEN OTHERS THEN
                        lc_bolum_kodu:='010';
                END;

                ls_description:=NVL(row_aps.PAYMENT_DESCRIPTION,'KCELL PAYMENT');

                INSERT INTO CBS_COLLECTION_MASTER_TRAN
                (TX_NO, COLLECTION_DATE, COLLECTION_TYPE, COLLECTION_CHANNEL, BRANCH, CUSTOMER_NO, ACCOUNT_NO, NAME_TITLE, CURRENCY_CODE, EXPLANATION, CASH_CODE, PREFIX_STATISTICAL_CODE, STATISTICAL_CODE, ACCOUNT_BRANCH)
                VALUES
                (ln_islem_no, Pkg_Muhasebe.Banka_Tarihi_Bul, lc_urun_tur_kod, 'APS', lc_bolum_kodu, ln_musteri_numara, lc_hesap_numara, Pkg_Musteri.Sf_Musteri_Adi(ln_musteri_numara), lc_doviz_kod, ls_description, NULL, row_aps.STATISTICS_USER_FROM || row_aps.STATISTICS_USER_TO, row_aps.STATISTICS_PAYMENT_CODE, lc_bolum_kodu);

                ls_INSTITUTION_CODE:='KCELL';
                Pkg_Tx7004.Collect_To(ls_INSTITUTION_CODE,
                                                 ls_COLLECTION_ACCOUNT_NO,
                                                 ls_COLLECTION_ACCOUNT_BR,
                                                 ls_COLLECTION_GL,
                                                 ls_COLLECTION_GL_BR);

                INSERT INTO CBS_COLLECTION_DETAIL_TRAN
                (TX_NO, INSTITUTION_CODE, COLLECTION_AMOUNT, AREA_CODE, PHONE_NO, SUBSCRIPTION_NO, INVOICE_NO, INSTITUTION_KEY_NO, COLLECTION_GL, COLLECTION_ACCOUNT_NO, COLLECTION_GL_BR, COLLECTION_ACCOUNT_BR, FROMBANK_BIC, STATUS_CD, DETAIL_ID,NAME_TITLE)
                VALUES
                (ln_islem_no, ls_INSTITUTION_CODE, ln_tutar, row_aps.AREA_CODE, row_aps.PHONE_NO, NULL, NULL, NULL, ls_COLLECTION_GL, ls_COLLECTION_ACCOUNT_NO,ls_COLLECTION_GL_BR,ls_COLLECTION_ACCOUNT_BR, NULL, 'sWAIT', Pkg_Genel.genel_kod_al('COLLECTION_DETAIL'),ls_description);

                Pkg_Baglam.yarat(lc_bolum_kodu,2);

                Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

                Pkg_Clearing.Process_Transaction(ln_islem_no);

            ELSIF  row_aps.ORDER_TYPE='INTERNET' THEN

                BEGIN
                    lc_hesap_numara   := row_aps.FROM_ACCOUNT_NO;
                    ln_musteri_numara := Pkg_Hesap.HesaptanMusteriNoAl(row_aps.FROM_ACCOUNT_NO);
                EXCEPTION
                WHEN OTHERS THEN
                     ln_musteri_numara:=NULL;
                     lc_hesap_numara:=NULL;
                END;

                ln_islem_no             :=Pkg_Tx.islem_no_al;
                ln_islem_kod      :=2170;
                lc_modul_tur_kod  :='COLLECTION';
                lc_urun_tur_kod   :='INTERNET';
                lc_urun_sinif_kod :='LC';
                lc_doviz_kod      :=Pkg_Hesap.HesaptanDovizKoduAl(lc_hesap_numara);
                lc_bolum_kodu     :=Pkg_Hesap.HesaptanSubeAl(lc_hesap_numara);

                ln_tutar   :=Pkg_Aps.ChargeAutoCalculate(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   1, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);
                --ln_tutar          := row_aps.INSTALMENT_AMOUNT;

                INSERT INTO CBS_INTERNET_MASRAF
                (TX_NO, FROM_ACCOUNT, TO_GL, CHARGE_DATE, CHARGE_AMOUNT, CURRENCY_CODE, STATUS_CD)
                VALUES
                (ln_islem_no, lc_hesap_numara,'46070600',Pkg_Muhasebe.Banka_Tarihi_Bul,ln_tutar, lc_doviz_kod,'sDONE');

                Pkg_Baglam.yarat(lc_bolum_kodu,2);

                Pkg_Tx.islem_yarat(ln_islem_no, ln_islem_kod, lc_modul_tur_kod, lc_urun_tur_kod, lc_urun_sinif_kod,
                                   ln_tutar, lc_bolum_kodu, lc_doviz_kod, ln_musteri_numara, lc_hesap_numara, lc_kasa_kod);

                Pkg_Clearing.Process_Transaction(ln_islem_no);


            END IF;

            UPDATE CBS_APS_INSTALMENTS
            SET STATUS_CD='sDONE',INSTALMENT_PAYMENT_DATE=Pkg_Muhasebe.Banka_Tarihi_Bul,
            INSTALMENT_PAYMENT_AMOUNT=ln_tutar,ERROR_DESC='Completed Successfully'
            WHERE ORDER_ID= row_aps.ORDER_ID
            AND INSTALMENT_ID= row_aps.INSTALMENT_ID;

            --her odeme icin COMMIT AT
            COMMIT;
        EXCEPTION
                WHEN AmountZeroEzception THEN
                    ROLLBACK;
                    ls_content:='Order Type:' || row_aps.ORDER_TYPE || '<BR>Payment Amount is 0 (Zero)<BR> Order ID:' || row_aps.ORDER_ID || '<BR> Installment ID:' || row_aps.INSTALMENT_ID ;

                    UPDATE CBS_APS_INSTALMENTS
                    SET ERROR_DESC=ls_content,STATUS_CD='sERROR'
                    WHERE ORDER_ID= row_aps.ORDER_ID
                    AND INSTALMENT_ID= row_aps.INSTALMENT_ID;

                    COMMIT;
                    Pkg_Email.AddToEmailQueue('APS', 50, 'info@demirbank.kg', 'ersainn@demirbank.kg;dinaraz@demirbank.kg;ITGroup@demirbank.kg', 'ALERT-APS JOB',ls_content,'HTML');

                 WHEN OTHERS THEN
                    ROLLBACK;
                    ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

                    ls_content:='Order Type:' || row_aps.ORDER_TYPE || '<BR>' || Pkg_Hata.GenerateMessage(SQLERRM)|| '<BR> Order ID:' || row_aps.ORDER_ID || '<BR> Installment ID:' || row_aps.INSTALMENT_ID ;

                    UPDATE CBS_APS_INSTALMENTS
                    SET ERROR_DESC=ls_content,STATUS_CD='sERROR'
                    WHERE ORDER_ID= row_aps.ORDER_ID
                    AND INSTALMENT_ID= row_aps.INSTALMENT_ID;

                    COMMIT;
                    Pkg_Email.AddToEmailQueue('APS', 50, 'info@demirbank.kg', 'ersainn@demirbank.kg;annag@demirbank.kg;ITGroup@demirbank.kg', 'ERROR-APS JOB',ls_content,'HTML');

        END;
    FETCH cursor_aps INTO row_aps;
    END LOOP;
    CLOSE cursor_aps;

    ls_content:='APS JOB completed.';
    Pkg_Email.AddToEmailQueue('APS', 50, 'info@demirbank.kg', 'ersainn@demirbank.kg;annag@demirbank.kg;ITGroup@demirbank.kg', 'ALERT-APS JOB',ls_content,'HTML');

    COMMIT;
EXCEPTION
         WHEN OTHERS THEN
            ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM;
            Log_At(SQLERRM);
            UPDATE CBS_APS_INSTALMENTS
            SET ERROR_DESC=Pkg_Hata.GenerateMessage(ls_content)
            WHERE ORDER_ID= row_aps.ORDER_ID
            AND INSTALMENT_ID= row_aps.INSTALMENT_ID;

            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'APS', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-APS PAYMENT JOB',ls_content);

END;

------------------------------------------------------------------------------------------
PROCEDURE SendCardPayments( ps_option IN VARCHAR2 DEFAULT NULL) IS

    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

    CURSOR cursor_card(ps_currencycd VARCHAR2,ps_type VARCHAR2) IS
        SELECT  *
        FROM CBS_CARD_PAYMENT
        WHERE STATUS_CD='sWAIT'
        AND CURRENCY_CODE=ps_currencycd
        AND PAYMENT_TYPE_DESC=ps_type;

   row_card     cursor_card%ROWTYPE;

   CURSOR cursor_curr (p_type IN VARCHAR2,ps_currencycd IN VARCHAR2) IS
        SELECT DISTINCT CURRENCY_CODE
        FROM CBS_CARD_PAYMENT
        WHERE STATUS_CD='sWAIT'
        --and PAYMENT_DATE=pkg_muhasebe.Banka_Tarihi_Bul
        AND PAYMENT_TYPE_DESC=p_type
        AND CURRENCY_CODE=ps_currencycd;

   row_curr     cursor_curr%ROWTYPE;

    CURSOR cursor_type IS
        SELECT DISTINCT PAYMENT_TYPE_DESC,CURRENCY_CODE
        FROM CBS_CARD_PAYMENT
        WHERE STATUS_CD='sWAIT';
        --and PAYMENT_DATE=pkg_muhasebe.Banka_Tarihi_Bul;

   row_type     cursor_type%ROWTYPE;


   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(250);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   ln_rownumber            NUMBER:=1;
   ln_filenumber        NUMBER;
   ln_documentnumber    NUMBER:=0;
   ln_totalamount        NUMBER:=0;
   ln_grosstotalamount        NUMBER:=0;
   ls_paymenttypedesc        VARCHAR2(32);
   ls_paymenttype        VARCHAR2(17);
   ls_debitcredit        VARCHAR2(1);

BEGIN


OPEN cursor_type;
FETCH cursor_type INTO row_type;
WHILE cursor_type%FOUND
LOOP

    OPEN cursor_curr(row_type.PAYMENT_TYPE_DESC,row_type.CURRENCY_CODE);
    FETCH cursor_curr INTO row_curr;
    IF cursor_curr%FOUND THEN

        ln_rownumber:=1;
        ln_documentnumber:=0;
        ln_totalamount:=0;
        ln_grosstotalamount:=0;

        ln_filenumber:=Pkg_Genel.genel_kod_al('CARD_FILE' || TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul, 'DDD'));
        ls_filename:='p4091_' || SUBSTR(LPAD(TO_CHAR(ln_filenumber),2,'0'),-2,2) || '.' || TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul, 'DDD');

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\CREDITCARD',ls_filename,'w',2100);

        ls_content:='FH' || LPAD(ln_rownumber,6,'0') ||  RPAD('PAYMENT',10,' ') || RPAD('10',3,' ') || RPAD('4091',6,' ');
        ls_content:=ls_content || TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') || '00' || LPAD(ln_filenumber,2,'0') || RPAD('4091',6,' ') || 'BCNBD' || LPAD('*',148,' ');
        ls_returncode:=Pkg_Message.WriteLine(f,To_Dos(ls_content));

        WHILE cursor_curr%FOUND
        LOOP

            IF row_type.PAYMENT_TYPE_DESC='P2C' THEN--To card
               ls_paymenttype:='PAYCARD';
               ls_paymenttypedesc:='PAYMENT TO CARD';
               ls_debitcredit:='C';
            ELSIF row_type.PAYMENT_TYPE_DESC='SD' THEN--Security Deposit
               ls_paymenttype:='PAYCARDSEC';
               ls_paymenttypedesc:='PAYMENT TO IRR BALANCE';
               ls_debitcredit:='C';
            ELSIF row_type.PAYMENT_TYPE_DESC='PFC' THEN--From card
               ls_paymenttype:='PAYDEBIT';
               ls_paymenttypedesc:='PAYMENT FROM CARD';
               ls_debitcredit:='D';
            END IF;


            ln_rownumber:=ln_rownumber+1;
            ls_returncode:=Pkg_Message.WriteLine(f,To_Dos('BH' || LPAD(ln_rownumber,6,'0') ||  RPAD('1',10,' ') || RPAD(ls_paymenttype,17,' ') || ls_debitcredit || Pkg_Card.GetISOCurrency(row_curr.CURRENCY_CODE) || TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'YYYYMMDD') || RPAD(ls_paymenttypedesc,32,' ') || LPAD('*',125,' ')));

            OPEN cursor_card(row_curr.CURRENCY_CODE,row_type.PAYMENT_TYPE_DESC);
            FETCH cursor_card INTO row_card;
            IF cursor_card%FOUND THEN
            WHILE cursor_card%FOUND
            LOOP
                ln_rownumber:=ln_rownumber+1;
                ln_documentnumber:=ln_documentnumber+1;

                ls_content:='RD' || LPAD(ln_rownumber,6,'0') || RPAD(ln_documentnumber,6,' ') ;
                ls_content:=ls_content || LPAD(row_card.AMOUNT*100,15,'0');
                ls_content:=ls_content || RPAD(row_card.TO_CARD_NO,32,' ');
                ls_content:=ls_content || RPAD(Pkg_Musteri.Sf_Musteri_Adi(Pkg_Card.GetCustomerFromCardNo(row_card.TO_CARD_NO)),60,' ');
                ls_content:=ls_content || RPAD(SUBSTR(NVL(row_card.PAYMENT_DESCRIPTION,ls_paymenttypedesc),1,32),32,' ');--rpad(ls_paymenttypedesc,32,' ');
                ls_content:=ls_content || LPAD('*',51,' ');

                ls_returncode:=Pkg_Message.WriteLine(f,To_Dos(ls_content));

                ln_totalamount:= ln_totalamount + row_card.AMOUNT;

                UPDATE CBS_CARD_PAYMENT
                SET STATUS_CD='sSEND',PAYMENT_FILE=ls_filename
                WHERE TX_NO= row_card.TX_NO
                AND      DETAIL_ID=row_card.DETAIL_ID;


            FETCH cursor_card INTO row_card;
            END LOOP;
            END IF;
            CLOSE cursor_card;

        ln_rownumber:=ln_rownumber+1;
        ls_returncode:=Pkg_Message.WriteLine(f,To_Dos('BT' || LPAD(ln_rownumber,6,'0') ||  LPAD(ln_documentnumber,6,'0') || LPAD(ln_totalamount*100,18,'0') || LPAD('*',172,' ')));

        ln_grosstotalamount:=ln_grosstotalamount+ln_totalamount;
        ln_totalamount:=0;

    FETCH cursor_curr INTO row_curr;
    END LOOP;

    ln_rownumber:=ln_rownumber+1;
    ls_returncode:=Pkg_Message.WriteLine(f,To_Dos('FT' || LPAD(ln_rownumber,6,'0') ||  LPAD(1,6,'0') || LPAD(ln_grosstotalamount*100,18,'0') || LPAD('*',172,' ')));

    --ls_content:=TO_DOS(ls_content);

    ls_returncode:=Pkg_Message.CloseFile(f);

    END IF;
    CLOSE cursor_curr;

FETCH cursor_type INTO row_type;
END LOOP;--type
CLOSE cursor_type;

    COMMIT;

EXCEPTION
     WHEN OTHERS THEN
        ROLLBACK;
        ls_returncode:=Pkg_Message.CloseFile(f);
        ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

        ls_content:=SQLERRM;

        INSERT INTO CBS_EMAIL_MESSAGES
        (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
        VALUES
        (ln_messageid, 'CARD', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-CARD PAYMENT JOB',ls_content);


END;
-------------------------------------------------------------------------------------------
PROCEDURE NBCurrencyLoader( ps_option IN VARCHAR2 DEFAULT NULL) IS
    f      UTL_FILE.FILE_TYPE;

    ls_outstr        VARCHAR2(4000);
    ls_filename        VARCHAR2(100);
    ls_currcode           VARCHAR2(3);
    ln_currrate           NUMBER;
    ln_messageid       NUMBER;
    ls_archievefolder  VARCHAR2(200);
    ls_delimiter       VARCHAR2(1):=';';
    ln_exist           NUMBER:=0;
    TimePeriodException             EXCEPTION;
    MissingRateException         EXCEPTION;
    ls_content                     VARCHAR2(2000);
    ls_strcurrdate                 VARCHAR2(50);
    ln_currcount                 NUMBER:=0;

BEGIN

    ls_filename:='NB_' || TO_CHAR(Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'DDMMYYYY') || '.csv';

    IF TO_CHAR(SYSDATE,'HH24') IN ('17') THEN
       RAISE TimePeriodException;
    END IF;

    IF TO_CHAR(SYSDATE,'HH24') IN ('18','19')  THEN

         f:=UTL_FILE.FOPEN(CURRENCY_PATH, ls_filename, 'r',2100);

        LOOP
            BEGIN
               UTL_FILE.GET_LINE(f, ls_outstr);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                EXIT;
            END;

            ls_currcode:= LTRIM(RTRIM(Pkg_Message.SPLIT(ls_outstr,ls_delimiter,9)));

            SELECT COUNT(*)
            INTO ln_exist
            FROM CBS_DOVIZ_KODLARI
            WHERE DOVIZ_KODU=ls_currcode;

            IF ln_exist=1 THEN

                ln_currcount:=ln_currcount+1;

                ln_currrate:=ROUND(TO_NUMBER(REPLACE(LTRIM(RTRIM(Pkg_Message.SPLIT(ls_outstr,ls_delimiter,6))),',','.')),2);

                INSERT INTO CBS_HTTP_TCMBKURAL_LOG
                SELECT *    FROM CBS_HTTP_TCMBKURAL
                WHERE doviz_kodu=ls_currcode;

                DELETE FROM CBS_HTTP_TCMBKURAL
                WHERE doviz_kodu=ls_currcode;

                INSERT INTO CBS_HTTP_TCMBKURAL
                (DOVIZ_KODU, ALIS, SATIS, EALIS, ESATIS, DLM)
                VALUES
                (ls_currcode,ln_currrate,ln_currrate,ln_currrate,ln_currrate,SYSDATE);

                 UPDATE CBS_HTTP_TCMBKURAL
                 SET DATE_LOAD=Pkg_Tarih.ileri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul);


            END IF;

            IF LTRIM(RTRIM(Pkg_Message.SPLIT(ls_outstr,ls_delimiter,0)))='23503' THEN
               ls_strcurrdate:=To_Win(LTRIM(RTRIM(Pkg_Message.SPLIT(ls_outstr,ls_delimiter,6))));
            END IF;

        EXIT WHEN  LENGTH(ls_outstr)<3;
        END LOOP;

        IF ln_currcount<15 THEN
           RAISE MissingRateException;
        END IF;

        UTL_FILE.FCLOSE(f);

        ls_archievefolder:=CURRARCHIVE_PATH;
        --log_at(CURRENCY_PATH,ls_filename,CURRARCHIVE_PATH);
        UTL_FILE.frename(CURRENCY_PATH, ls_filename,CURRARCHIVE_PATH, ls_filename);

        ls_content:='NB Rates as of : ' || ls_strcurrdate || ' loaded.';
        Pkg_Email.AddToEmailQueue('CURRENCY', 50, 'info@demirbank.kg', 'talgat@demirbank.kg;zaure@demirbank.kg;almat@demirbank.kg;maximp@demirbank.kg;ITGroup@demirbank.kg', 'NB CURRECNY RATES LOADED :' || ls_strcurrdate,ls_content,'HTML');


    END IF;

    COMMIT;

EXCEPTION
         WHEN TimePeriodException THEN

             ls_content:='Name of the File should be:: ' || ls_filename || '<BR>' || 'Do NOT forget to save in CSV format.';

            Pkg_Email.AddToEmailQueue('CURRENCY', 50, 'info@demirbank.kg', 'talgat@demirbank.kg;zaure@demirbank.kg;almat@demirbank.kg;maximp@demirbank.kg;ITGroup@demirbank.kg', 'PLEASE PREPARE NB CURRENCY RATES',ls_content,'HTML');

        WHEN MissingRateException THEN

             ls_content:='Missing Rate or Wrong File Format :' || ln_currcount || ' Currency Code found.';

            Pkg_Email.AddToEmailQueue('CURRENCY', 50, 'info@demirbank.kg', 'talgat@demirbank.kg;zaure@demirbank.kg;almat@demirbank.kg;maximp@demirbank.kg;ITGroup@demirbank.kg', 'ERROR-WRONG CURRENCY RATES FORMAT',ls_content,'HTML');

         WHEN OTHERS THEN
             ROLLBACK;
               UTL_FILE.FCLOSE(f);
            ls_content:=SQLERRM;

            Pkg_Email.AddToEmailQueue('CURRENCY', 50, 'info@demirbank.kg', 'talgat@demirbank.kg;zaure@demirbank.kg;almat@demirbank.kg;maximp@demirbank.kg;ITGroup@demirbank.kg', 'ERROR-NB CURRENCY LOADER JOB',ls_content,'HTML');

END;
------------------------------------------------------------------------------------------
PROCEDURE FutureDateClearing( ps_option IN VARCHAR2 DEFAULT NULL) IS
      ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

    CURSOR cursor_clearing IS
        SELECT *
        FROM cbs_vw_clearing_draft
        WHERE value_date=Pkg_Muhasebe.banka_tarihi_bul
        AND MSG_STATUS='sWAIT';

    row_clearing     cursor_clearing%ROWTYPE;

    CURSOR cursor_drafttx(pn_islemno NUMBER) IS
        SELECT *
        FROM CBS_ISLEM_GECICI
        WHERE numara=pn_islemno;

    row_drafttx     cursor_drafttx%ROWTYPE;

    ls_content                     VARCHAR2(2000);
    ln_masraf                     NUMBER;
    ln_balance                     NUMBER;
    ln_hesapno                     NUMBER;
    ln_amount                     NUMBER;
BEGIN

    IF TRUNC(SYSDATE) = Pkg_Muhasebe.banka_tarihi_bul THEN

        OPEN cursor_clearing;
        FETCH cursor_clearing INTO row_clearing;
        WHILE cursor_clearing%FOUND
        LOOP
            IF row_clearing.FROM_ACCOUNT IS NOT NULL THEN
                ln_hesapno:= Pkg_Hesap.GetHesapNoFromExternal(row_clearing.FROM_ACCOUNT,Pkg_Genel.LC_al);
                ln_masraf := NVL(row_clearing.CHARGE_AMOUNT,0);
                ln_amount := NVL(row_clearing.TOTAL_TRAN_AMOUNT,0);
                ln_balance:= NVL(Pkg_Hesap.kullanilabilir_bakiye_al(ln_hesapno),0);

                    OPEN cursor_drafttx(row_clearing.TX_NO);
                    FETCH cursor_drafttx INTO row_drafttx;
                    CLOSE cursor_drafttx;

                    IF row_clearing.DETAIL_ID IS NULL THEN
                        UPDATE  CBS_CLEARING_MT102_DETAIL_TRAN
                        SET  DETAIL_ID=1
                        WHERE DETAIL_ID IS NULL
                        AND tran_date=Pkg_Muhasebe.Banka_Tarihi_Bul
                        AND tx_no=row_drafttx.NUMARA;
                    END IF;

                    Pkg_Int_Api.create_transaction (row_drafttx.NUMARA,
                                      row_drafttx.ISLEM_KOD,
                                      row_drafttx.MODUL_TUR_KOD,
                                      row_drafttx.URUN_TUR_KOD,
                                      row_drafttx.URUN_SINIF_KOD,
                                      row_drafttx.TUTAR,
                                      row_drafttx.AMIR_BOLUM_KODU,
                                      row_drafttx.AMIR_BOLUM_KODU,
                                      row_drafttx.KAYIT_KULLANICI_ROL_NUMARA,
                                      row_drafttx.DOVIZ_KOD,
                                      row_drafttx.MUSTERI_NUMARA,
                                      row_drafttx.HESAP_NUMARA,
                                      row_drafttx.KASA_KOD,
                                      row_drafttx.kanal_numara,
                                      row_drafttx.KAYIT_KULLANICI_KODU);
                --end if;--enough balance
            END IF;
        FETCH cursor_clearing INTO row_clearing;
        END LOOP;
        CLOSE cursor_clearing;

     END IF;--only working days

    Pkg_Email.AddToEmailQueue('CLEARFUTURE', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'FUTURE DATE CLEARING PAYMENT JOB FINISHED',ls_content,'HTML');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        ls_content:=SQLERRM;
        Pkg_Email.AddToEmailQueue('CLEARFUTURE', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-FUTURE DATE CLEARING PAYMENT JOB',ls_content,'HTML');

END;
---------------------------------------------------------------------------------------------
PROCEDURE FXPositionControl( ps_option IN VARCHAR2 DEFAULT NULL) IS
    CURSOR c_1858 IS
        SELECT BOLUM_KODU, DOVIZ_KOD, BAKIYE_LC,NUMARA FROM CBS_DKHESAP
        WHERE numara IN ('18580000');
   r_1858      c_1858%ROWTYPE;

       CURSOR c_2859 (ps_bolum VARCHAR2,ps_doviz VARCHAR2) IS
        SELECT BOLUM_KODU, DOVIZ_KOD, BAKIYE_LC,NUMARA FROM CBS_DKHESAP
        WHERE numara IN ('28590000')
        AND BOLUM_KODU=ps_bolum
        AND DOVIZ_KOD=ps_doviz;

   r_2859      c_2859%ROWTYPE;

   CURSOR c_1859 IS
        SELECT BOLUM_KODU, DOVIZ_KOD, BAKIYE_LC,NUMARA FROM CBS_DKHESAP
        WHERE numara IN ('18590000');
   r_1859      c_1859%ROWTYPE;

       CURSOR c_2858 (ps_bolum VARCHAR2,ps_doviz VARCHAR2) IS
        SELECT BOLUM_KODU, DOVIZ_KOD, BAKIYE_LC,NUMARA FROM CBS_DKHESAP
        WHERE numara IN ('28580000')
        AND BOLUM_KODU=ps_bolum
        AND DOVIZ_KOD=ps_doviz;

   r_2858      c_2858%ROWTYPE;

   ls_message VARCHAR2(2000);
   ls_equal      VARCHAR2(1):='Y';
BEGIN
    OPEN c_1858;
    FETCH c_1858 INTO r_1858;
    WHILE c_1858%FOUND
    LOOP
        OPEN c_2859(r_1858.BOLUM_KODU,r_1858.DOVIZ_KOD);
        FETCH c_2859 INTO r_2859;
        IF c_2859%FOUND THEN
            IF ABS(r_2859.BAKIYE_LC)!=ABS(r_1858.BAKIYE_LC) THEN
               ls_equal:='N';
               ls_message:=ls_message || r_2859.BOLUM_KODU || '-' || r_2859.NUMARA ||'-' || r_2859.DOVIZ_KOD || ' NOT EQUAL TO ' || r_1858.BOLUM_KODU || '-' || r_1858.NUMARA ||'-' || r_1858.DOVIZ_KOD || '<BR>';
            END IF;
        END IF;
        CLOSE c_2859;
    FETCH c_1858 INTO r_1858;
    END LOOP;
    CLOSE c_1858;
    -------------------------------------------
    OPEN c_1859;
    FETCH c_1859 INTO r_1859;
    WHILE c_1859%FOUND
    LOOP
        OPEN c_2858(r_1859.BOLUM_KODU,r_1859.DOVIZ_KOD);
        FETCH c_2858 INTO r_2858;
        IF c_2858%FOUND THEN
            IF ABS(r_2858.BAKIYE_LC)!=ABS(r_1859.BAKIYE_LC) THEN
               ls_equal:='N';
               ls_message:=ls_message || r_2858.BOLUM_KODU || '-' || r_2858.NUMARA ||'-' || r_2858.DOVIZ_KOD || ' NOT EQUAL TO ' || r_1859.BOLUM_KODU || '-' || r_1859.NUMARA ||'-' || r_1859.DOVIZ_KOD || '<BR>';
            END IF;
        END IF;
        CLOSE c_2858;

    FETCH c_1859 INTO r_1859;
    END LOOP;
    CLOSE c_1859;
    -------------------------------------------
    IF ls_equal='N' THEN
      Pkg_Email.AddToEmailQueue('FXPOSITION', 50, 'info@demirbank.kg', 'accountinggroup@demirbank.kg;tatianaf@demirbank.kg;ITGroup@demirbank.kg', 'ERROR-IN FX POSITION',ls_message,'HTML');
    ELSE
      ls_message:='FX POSITIONS ARE EQUAL';
      Pkg_Email.AddToEmailQueue('FXPOSITION', 50, 'info@demirbank.kg', 'accountinggroup@demirbank.kg;tatianaf@demirbank.kg;ITGroup@demirbank.kg', 'FX POSITION IS CORRECT',ls_message,'HTML');
    END IF;

END;
-----------------------------------------------------------------------------------------
PROCEDURE SendKartelPayments( ps_externalno IN VARCHAR2) IS
   ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
        SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.DETAIL_ID,d.NAME_TITLE ABONE_NAME,d.AREA_CODE
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='KMOBILE'
        AND m.TX_NO=d.TX_NO;

    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3):='000';
    FileErrorException             EXCEPTION;
    HTTPErrorException                     EXCEPTION;
    ln_txno                                 NUMBER;
BEGIN

    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        WHILE cursor_aps%FOUND
        LOOP
            IF NOT row_aps.COLLECTION_TYPE IN ('CASH','ACCOUNT') THEN
               RAISE HTTPErrorException;
            END IF;

            ln_txno:=row_aps.TX_NO;
            ls_returncode:=Pkg_Utility.MakeKartelPayment(row_aps.TX_NO, row_aps.AREA_CODE ||row_aps.PHONE_NO, row_aps.COLLECTION_AMOUNT);

            IF ls_returncode<>'000' THEN
               RAISE HTTPErrorException;
            END IF;

            UPDATE  CBS_COLLECTION_DETAIL
            SET STATUS_CD='sSEND'
            WHERE TX_NO = row_aps.TX_NO
            AND DETAIL_ID = row_aps.DETAIL_ID;

            --ls_returncode:=pkg_message.WriteLine(f,ls_content);

        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN HTTPErrorException THEN
             ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM ||'--'|| ls_returncode || '--TXNO:' || ln_txno;
            Pkg_Email.AddToEmailQueue('KARTEL', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-HTTP KARTEL PAYMENT JOB',ls_content,'HTML');

         WHEN OTHERS THEN
             ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');

            ls_content:=SQLERRM || '--TXNO:' || ln_txno;
            Pkg_Email.AddToEmailQueue('KARTEL', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-KARTEL PAYMENT JOB',ls_content,'HTML');

END;
--------------------------------------------------------------------------------------------
PROCEDURE SendSubscription(ps_customeremail IN VARCHAR2) IS
   CURSOR cursor_subscribe IS
        SELECT e.*
        FROM corpint.TBL_EMAIL_SUBSCRIPTION e
        WHERE STATUS_CD='sENAB'
        AND TRUNC(NEXTRUNDATE)=TRUNC(SYSDATE);

   CURSOR cursor_advertisement IS
        SELECT ADVERTISE_TEXT, ADV_END_DATE
        FROM corpint.tbl_email_advertisement;

   row_subscribe  cursor_subscribe%ROWTYPE;

   ls_returncode VARCHAR2(3):='000';
   ls_content    CLOB :='';
   ls_subject VARCHAR2(100);
   startdate DATE;
   ls_advertisement CLOB :='';
   ld_adv_enddate DATE;
   ls_ret          VARCHAR2 (3); ----bahianab cbs-480 14072021
   l_recipients    CORPINT2.PKG_NOTIFICATION.RECIPIENTLIST; ----bahianab cbs-480 14072021

        CURSOR cursor_rate(ld_date DATE) IS
            SELECT k.*,m.DVZALIS NBRATE
            FROM CBS_KUR k, CBS_MBKUR m
            WHERE k.TARIH=m.tarih --Sevalb 17012012
              AND k.DVZ=m.DVZ
            AND k.TARIH=ld_date
            AND k.DVZ IN('USD','EUR','GBP','RUB','KGS','CHF','TRY');

        CURSOR cursor_movement(pn_account_no NUMBER) IS
            SELECT FIS_NUMARA, FIS_ACIKLAMA, FIS_ISLEM_NUMARA,
                          FIS_YARATILDIGI_TARIH, FIS_YARATILDIGI_BANKA_TARIH,
                          FIS_MUHASEBELESTIGI_TARIH, FIS_TUR, SATIR_NUMARA,
                          SATIR_HESAP_NUMARA, SATIR_LC_TUTAR, SATIR_DV_TUTAR,
                          SATIR_DOVIZ_KOD, SATIR_BANKA_ACIKLAMA, SATIR_MUSTERI_ACIKLAMA,
                          SATIR_MUSTERI_HESAP_NUMARA, MUSTERI_NO,
                          NVL(Pkg_Passbook.HAREKETLIBAKIYEHESAPLA(SATIR_HESAP_NUMARA,FIS_NUMARA,SATIR_NUMARA),0) SON_BAKIYE
            FROM CBS_VW_FIS_SATIR_VSZIZ a
            WHERE SATIR_HESAP_NUMARA = TO_CHAR(pn_account_no)
            AND fis_tur = 'G'
            AND  FIS_MUHASEBELESTIGI_TARIH BETWEEN TRUNC(Pkg_Jobs.GetSubscibeDate(pn_account_no))-1 AND SYSDATE --sevalb 17012012 FIS_YARATILDIGI_TARIH  yerine FIS_MUHASEBELESTIGI_TARIH konuldu
            ORDER BY A.FIS_YARATILDIGI_TARIH, A.FIS_NUMARA, A.SATIR_NUMARA; --bahianab cbs-480 14072021 --ORDER BY a.fis_numara, a.SATIR_NUMARA;  --sevalb 26062012 order by fis_numara eklendi.FIS_MUHASEBELESTIGI_TARIH silindi




      row_rate cursor_rate%ROWTYPE;
      row_advertisement  cursor_advertisement%ROWTYPE;
      row_movement  cursor_movement%ROWTYPE;
      ld_subscrdate DATE := SYSDATE;
      ln_tutar NUMBER;
      ls_header VARCHAR2(100):='';
      ln_rownum NUMBER:=0;
      ld_date DATE;
      ln_count NUMBER;
      ln_account_balance NUMBER :=0;
      ld_date1 DATE := SYSDATE;
      ld_date2 DATE := SYSDATE;
BEGIN

    OPEN cursor_subscribe;
    FETCH cursor_subscribe INTO row_subscribe;
    WHILE cursor_subscribe%FOUND
    LOOP
        IF row_subscribe.MSG_TYPE='CURRENCY' THEN

            ln_rownum := 0;

            SELECT COUNT(*) INTO ln_count FROM CBS_KUR WHERE TARIH=Pkg_Muhasebe.BANKA_TARIHI_BUL;
            IF ln_count>0 THEN
                ld_date:=Pkg_Muhasebe.BANKA_TARIHI_BUL;
            ELSE
                SELECT MAX(TARIH) INTO ld_date FROM CBS_KUR;
            END IF;

            ls_header := ' DKIB Electronic Rate of ' || TO_CHAR(ld_date,'DD/MM/YYYY');

            ls_content := '<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:p="urn:schemas-microsoft-com:office:powerpoint" xmlns:a="urn:schemas-microsoft-com:office:access" xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882" xmlns:s="uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882" xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema" xmlns:b="urn:schemas-microsoft-com:office:publisher" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:c="urn:schemas-microsoft-com:office:component:spreadsheet" xmlns:odc="urn:schemas-microsoft-com:office:odc" xmlns:oa="urn:schemas-microsoft-com:office:activation" xmlns:html="http://www.w3.org/TR/REC-html40" xmlns:q="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rtc="http://microsoft.com/officenet/conferencing" xmlns:D="DAV:" xmlns:Repl="http://schemas.microsoft.com/repl/" xmlns:mt="http://schemas.microsoft.com/sharepoint/soap/meetings/" xmlns:x2="http://schemas.microsoft.com/office/excel/2003/xml" xmlns:ppda="http://www.passport.com/NameSpace.xsd" xmlns:ois="http://schemas.microsoft.com/sharepoint/soap/ois/" xmlns:dir="http://schemas.microsoft.com/sharepoint/soap/directory/" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:dsp="http://schemas.microsoft.com/sharepoint/dsp" xmlns:udc="http://schemas.microsoft.com/data/udc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:sub="http://schemas.microsoft.com/sharepoint/soap/2002/1/alerts/" xmlns:ec="http://www.w3.org/2001/04/xmlenc#" xmlns:sp="http://schemas.microsoft.com/sharepoint/" xmlns:sps="http://schemas.microsoft.com/sharepoint/soap/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:udcs="http://schemas.microsoft.com/data/udc/soap" xmlns:udcxf="http://schemas.microsoft.com/data/udc/xmlfile" xmlns:udcp2p="http://schemas.microsoft.com/data/udc/parttopart" xmlns:wf="http://schemas.microsoft.com/sharepoint/soap/workflow/" xmlns:dsss="http://schemas.microsoft.com/office/2006/digsig-setup" xmlns:dssi="http://schemas.microsoft.com/office/2006/digsig" xmlns:mdssi="http://schemas.openxmlformats.org/package/2006/digital-signature" xmlns:mver="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns:mrels="http://schemas.openxmlformats.org/package/2006/relationships" xmlns:spwp="http://microsoft.com/sharepoint/webpartpages" xmlns:ex12t="http://schemas.microsoft.com/exchange/services/2006/types" xmlns:ex12m="http://schemas.microsoft.com/exchange/services/2006/messages" xmlns:pptsl="http://schemas.microsoft.com/sharepoint/soap/SlideLibrary/" xmlns:spsl="http://microsoft.com/webservices/SharePointPortalServer/PublishedLinksService" xmlns:Z="urn:schemas-microsoft-com:" xmlns:st="&#1;" xmlns="http://www.w3.org/TR/REC-html40">';
            ls_content := ls_content || '<head>';
            ls_content := ls_content || '    <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">';
            ls_content := ls_content || '    <meta name="Generator" content="Microsoft Word 12 (filtered medium)">';
            ls_content := ls_content || '    <title>Demir Kyrgyz International Bank</title>';
            ls_content := ls_content || '    <style type="text/css">';
            ls_content := ls_content || '        body {';
            ls_content := ls_content || '            font-family:"Calibri";';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '    </style>';
            ls_content := ls_content || '</head>';
            ls_content := ls_content || '<body>';
            ls_content := ls_content || '<table width=570 cellpadding=0 cellspacing=0 border=0 style="z-index:100">';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td align=left width="570" height="106"><img class="logo" src="https://ctechnology.kg/images/demirBank-logo.png" width="170" height="46" alt="Logo"></td>';
            ls_content := ls_content || '        <td align="right" width="186" align="right" height="46" style="color: #ffffff;"><img src="https://ctechnology.kg/images/demirAssistant-logo.png" alt="assistant-logo" width="170" height="46" /></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '</table>';
            ls_content := ls_content || '<table width=570 cellpadding=0 cellspacing=0 border=0 style="z-index:100">';
            ls_content := ls_content || '    <tr height="35">';
            ls_content := ls_content || '        <td align=center style="background-color:#ECECEC;font-size:16px;color:#2C2E2D;border-bottom:2px solid #FFF;">FX Rates of Demir Kyrgyz International Bank as of '||TO_CHAR(ld_date,'dd/mm/yyyy')||', 17:00</td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '</table>';
            ls_content := ls_content || '<table cellpadding=0 cellspacing=0 width=570 style="color:#2C2E2D;">';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td width="570" height="50" colspan=6>';
            ls_content := ls_content || '            <table border=0 cellpadding=0 cellspacing=0 width=100% height=100%>';
            ls_content := ls_content || '                <tr style="font-size:16px;background-color:#ebedec;">';
            ls_content := ls_content || '                    <td align=center width=70></td>';
            ls_content := ls_content || '                    <td align=center width=330>Demir Kyrgyz International Bank</td>';
            ls_content := ls_content || '                    <td align=center>National Bank of KR</td>';
            ls_content := ls_content || '                </tr>';
            ls_content := ls_content || '            </table>';
            ls_content := ls_content || '        </td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr height="30" align=center style="background-color:#f5f5f5;font-size:16px;">';
            ls_content := ls_content || '        <td style="border-bottom:2px solid #FFF;"></td>';
            ls_content := ls_content || '        <td style="border-bottom:2px solid #FFF;" colspan=2 align=center>NonCash</td>';
            ls_content := ls_content || '        <td style="border-bottom:2px solid #FFF;" colspan=2 align=center>Cash</td>';
            ls_content := ls_content || '        <td style="border-bottom:2px solid #FFF;"></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr align=center height="35">';
            ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;"></td>';
            ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">Buy</td>';
            ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">Sell</td>';
            ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">Buy</td>';
            ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">Sell</td>';
            ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;" width=70></td>';
            ls_content := ls_content || '    </tr>';

            OPEN cursor_rate(ld_date);
            FETCH cursor_rate INTO row_rate;
            WHILE cursor_rate%FOUND
            LOOP

                IF MOD(ln_rownum,2)=1 THEN
                    ls_content:=ls_content ||'    <tr align=center height="35">';
                    ls_content:=ls_content ||'        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">'||row_rate.DVZ||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.DVZALIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.DVZSATIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.EFALIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.EFSATIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.NBRATE,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'    </tr>';
                ELSE
                    ls_content:=ls_content ||'    <tr align=center height="35">';
                    ls_content:=ls_content ||'        <td style="background-color:#f5f7f6;border-bottom:2px solid #FFF;">'||row_rate.DVZ||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#eceeed;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.DVZALIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#f5f7f6;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.DVZSATIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#eceeed;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.EFALIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#f5f7f6;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.EFSATIS,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'        <td style="background-color:#eceeed;border-bottom:2px solid #FFF;">'||TO_CHAR(row_rate.NBRATE,'9999999.9999')||'</td>';
                    ls_content:=ls_content ||'    </tr>';
                END IF;

                ln_rownum:=ln_rownum+1;

            FETCH cursor_rate INTO row_rate;
            END LOOP;
            CLOSE cursor_rate;

            ls_content:=ls_content || '</table>';

            SELECT ADVERTISE_TEXT, ADV_END_DATE
            INTO ls_advertisement, ld_adv_enddate
            FROM corpint.tbl_email_advertisement;

        ELSIF row_subscribe.MSG_TYPE='MOVEMENT' THEN

            ln_rownum := 0;

            SELECT bakiye INTO ln_account_balance FROM cbs.CBS_HESAP_BAKIYE WHERE hesap_no=row_subscribe.ACCOUNT_NO;
            ld_subscrdate := Pkg_Jobs.GetSubscibeDate(row_subscribe.ACCOUNT_NO);

            ls_header := ' DKIB Electronic Statement of ' || TO_CHAR(Pkg_Muhasebe.Banka_Tarihi_Bul,'DD/MM/YYYY');

            ls_content := '<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:p="urn:schemas-microsoft-com:office:powerpoint" xmlns:a="urn:schemas-microsoft-com:office:access" xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882" xmlns:s="uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882" xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema" xmlns:b="urn:schemas-microsoft-com:office:publisher" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:c="urn:schemas-microsoft-com:office:component:spreadsheet" xmlns:odc="urn:schemas-microsoft-com:office:odc" xmlns:oa="urn:schemas-microsoft-com:office:activation" xmlns:html="http://www.w3.org/TR/REC-html40" xmlns:q="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rtc="http://microsoft.com/officenet/conferencing" xmlns:D="DAV:" xmlns:Repl="http://schemas.microsoft.com/repl/" xmlns:mt="http://schemas.microsoft.com/sharepoint/soap/meetings/" xmlns:x2="http://schemas.microsoft.com/office/excel/2003/xml" xmlns:ppda="http://www.passport.com/NameSpace.xsd" xmlns:ois="http://schemas.microsoft.com/sharepoint/soap/ois/" xmlns:dir="http://schemas.microsoft.com/sharepoint/soap/directory/" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:dsp="http://schemas.microsoft.com/sharepoint/dsp" xmlns:udc="http://schemas.microsoft.com/data/udc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:sub="http://schemas.microsoft.com/sharepoint/soap/2002/1/alerts/" xmlns:ec="http://www.w3.org/2001/04/xmlenc#" xmlns:sp="http://schemas.microsoft.com/sharepoint/" xmlns:sps="http://schemas.microsoft.com/sharepoint/soap/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:udcs="http://schemas.microsoft.com/data/udc/soap" xmlns:udcxf="http://schemas.microsoft.com/data/udc/xmlfile" xmlns:udcp2p="http://schemas.microsoft.com/data/udc/parttopart" xmlns:wf="http://schemas.microsoft.com/sharepoint/soap/workflow/" xmlns:dsss="http://schemas.microsoft.com/office/2006/digsig-setup" xmlns:dssi="http://schemas.microsoft.com/office/2006/digsig" xmlns:mdssi="http://schemas.openxmlformats.org/package/2006/digital-signature" xmlns:mver="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns:mrels="http://schemas.openxmlformats.org/package/2006/relationships" xmlns:spwp="http://microsoft.com/sharepoint/webpartpages" xmlns:ex12t="http://schemas.microsoft.com/exchange/services/2006/types" xmlns:ex12m="http://schemas.microsoft.com/exchange/services/2006/messages" xmlns:pptsl="http://schemas.microsoft.com/sharepoint/soap/SlideLibrary/" xmlns:spsl="http://microsoft.com/webservices/SharePointPortalServer/PublishedLinksService" xmlns:Z="urn:schemas-microsoft-com:" xmlns:st="&#1;" xmlns="http://www.w3.org/TR/REC-html40">';
            ls_content := ls_content || '<head>';
            ls_content := ls_content || '<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">';
            ls_content := ls_content || '<meta name="Generator" content="Microsoft Word 12 (filtered medium)">';
            ls_content := ls_content || '    <title>Demir Kyrgyz International Bank</title>';
            ls_content := ls_content || '    <style type="text/css">';
            ls_content := ls_content || '        body {';
            ls_content := ls_content || '            font-family:"Calibri";';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '    </style>';
            ls_content := ls_content || '</head>';
            ls_content := ls_content || '<body>';

            ld_date1 := Pkg_Tarih.GERI_IS_GUNU(ld_subscrdate);
            ld_date2 := Pkg_Tarih.GERI_IS_GUNU(SYSDATE);

            IF (ld_date1>ld_date2) THEN
                ld_date2 := ld_date1;
            END IF;

            ls_content := ls_content || '<table width=570 cellpadding=0 cellspacing=0 border=0>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td align=left width="570" height="106"><img class="logo" src="https://ctechnology.kg/images/demirBank-logo.png" width="170" height="46" alt="Logo"></td>';
            ls_content := ls_content || '        <td align="right" width="186" align="center" height="46" style="color: #ffffff;"><img src="https://ctechnology.kg/images/demirAssistant-logo.png" alt="assistant-logo" width="186" height="46" /></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '</table>';
            ls_content := ls_content || '<table width=570 cellpadding=0 cellspacing=0 border=0>';
            ls_content := ls_content || '    <tr height="35">';
            ls_content := ls_content || '        <td align=center style="background-color:#ECECEC;font-size:16px;color:#2C2E2D;">Period of Statement: '|| TO_CHAR(ld_date1,'dd/mm/yyyy')|| ' - ' || TO_CHAR(ld_date2,'dd/mm/yyyy') ||'</td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '</table>';
            ls_content := ls_content || '<table cellpadding=0 cellspacing=0 width=570 style="color:#2C2E2D;font-size:14px;background-color:#f5f5f5;">';
            ls_content := ls_content || '    <tr><td colspan=3></td></tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td width=50></td>';
            ls_content := ls_content || '        <td>Customer No : '||TO_CHAR(row_subscribe.CUSTOMER_NO)||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '        <td>Customer Name : '||to_char(pkg_musteri.Sf_Musteri_Eng_Adi(row_subscribe.CUSTOMER_NO))||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '        <td>Currency, Account No : '||TO_CHAR(Pkg_Hesap.HesaptanDovizKoduAl(row_subscribe.ACCOUNT_NO))||', '||TO_CHAR(row_subscribe.ACCOUNT_NO)||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '        <td>External Account No : '||TO_CHAR(Pkg_Hesap.External_HesapNo_Al(row_subscribe.ACCOUNT_NO))||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '        <td>Branch Code : '||TO_CHAR(Pkg_Hesap.HesaptanSubeAl(row_subscribe.ACCOUNT_NO)||' '||Pkg_Genel.bolum_adi_al(Pkg_Hesap.HesaptanSubeAl(row_subscribe.ACCOUNT_NO)))||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '        <td>Balance : '||TO_CHAR(ln_account_balance,'FM999G999G999G999G999G999G999G999G999D00')||'</td>';
            ls_content := ls_content || '        <td></td>';
            ls_content := ls_content || '    </tr>';
            ls_content := ls_content || '    <tr><td colspan=3></td></tr>';
            ls_content := ls_content || '</table>';

            --ls_content := ls_content || '<BR>';

            OPEN cursor_movement(row_subscribe.ACCOUNT_NO);
            FETCH cursor_movement INTO row_movement;
            WHILE cursor_movement%FOUND
            LOOP

                IF (row_movement.SATIR_DOVIZ_KOD='KGS') THEN ln_tutar := row_movement.SATIR_LC_TUTAR; ELSE ln_tutar := row_movement.SATIR_DV_TUTAR; END IF;

                IF (ln_rownum=0) THEN
                    ls_content := ls_content || '<table cellpadding=0 cellspacing=0 width=570 style="color:#2C2E2D;font-size:13px;">';
                    ls_content := ls_content || '        <td width="570" height="50" colspan=4 style="background-color:#ebedec;border-bottom:2px solid #FFF;">';
                    ls_content := ls_content || '            <table border=0 cellpadding=0 cellspacing=0 width=100% height=100%>';
                    ls_content := ls_content || '                <tr style="font-size:14px;">';
                    ls_content := ls_content || '                    <td width=10></td>';
                    ls_content := ls_content || '                    <td width=330>Opening Balance: '||TO_CHAR(ln_tutar*(-1)+row_movement.SON_BAKIYE,'999999999999999.99')||'</td>';
                    ls_content := ls_content || '                </tr>';
                    ls_content := ls_content || '            </table>';
                    ls_content := ls_content || '        </td>';
                    ls_content := ls_content || '    </tr>';
                    ls_content := ls_content || '    <tr align=center height="35">';
                    ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">Date</td>';
                    ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">Description</td>';
                    ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">Amount</td>';
                    ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">Balance</td>';
                    ls_content := ls_content || '    </tr>';
                END IF;

                IF MOD(ln_rownum,2)=1 THEN
                    ls_content := ls_content || '    <tr align=center height="35">';
                    ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">'||TO_CHAR(row_movement.FIS_YARATILDIGI_BANKA_TARIH,'dd/mm/yyyy')||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">'|| row_movement.SATIR_MUSTERI_ACIKLAMA||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#ebedec;border-bottom:2px solid #FFF;">'||TO_CHAR(ln_tutar,'999999999999999.99')||' '||row_movement.SATIR_DOVIZ_KOD||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#d9dbda;border-bottom:2px solid #FFF;">'||TO_CHAR(row_movement.SON_BAKIYE,'999999999999999.99')||' '||row_movement.SATIR_DOVIZ_KOD||'</td>';
                    ls_content := ls_content || '    </tr>';
                ELSE
                    ls_content := ls_content || '    <tr align=center height="35">';
                    ls_content := ls_content || '        <td style="background-color:#f5f7f6;border-bottom:2px solid #FFF;">'||TO_CHAR(row_movement.FIS_YARATILDIGI_BANKA_TARIH,'dd/mm/yyyy')||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#eceeed;border-bottom:2px solid #FFF;">'|| row_movement.SATIR_MUSTERI_ACIKLAMA||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#f5f7f6;border-bottom:2px solid #FFF;">'||TO_CHAR(ln_tutar,'999999999999999.99')||' '||row_movement.SATIR_DOVIZ_KOD||'</td>';
                    ls_content := ls_content || '        <td style="background-color:#eceeed;border-bottom:2px solid #FFF;">'||TO_CHAR(row_movement.SON_BAKIYE,'999999999999999.99')||' '||row_movement.SATIR_DOVIZ_KOD||'</td>';
                    ls_content := ls_content || '    </tr>';
                END IF;

                ln_rownum:=ln_rownum+1;
                ln_tutar:=row_movement.SON_BAKIYE;
                FETCH cursor_movement INTO row_movement;
            END LOOP;
            CLOSE cursor_movement;

            IF (ln_rownum>0) THEN
                ls_content := ls_content || '    <tr>';
                ls_content := ls_content || '        <td width="570" height="50" colspan=4 style="background-color:#ebedec;border-bottom:2px solid #FFF;">';
                ls_content := ls_content || '            <table border=0 cellpadding=0 cellspacing=0 width=100% height=100%>';
                ls_content := ls_content || '                <tr style="font-size:14px;">';
                ls_content := ls_content || '                    <td width=10></td>';
                ls_content := ls_content || '                    <td width=330>Closing Balance: '||TO_CHAR(ln_tutar,'999999999999999.99')||'</td>';
                ls_content := ls_content || '                </tr>';
                ls_content := ls_content || '            </table>';
                ls_content := ls_content || '        </td>';
                ls_content := ls_content || '    </tr>';
            END IF;

            ls_content := ls_content || '</table>';

        END IF;

        ls_content := ls_content || '<BR>';
        ls_content := ls_content || '<table cellpadding=0 cellspacing=0 width=570>';
        ls_content := ls_content || '   <tr style="font-size:14px;">';
        ls_content := ls_content || '     <td align=left>Call Center: 2222, + 996 (312) 610 610, 610 613</td>';
        ls_content := ls_content || '     <td align=right>www.demirbank.kg</td>';
        ls_content := ls_content || '   </tr>';
        ls_content := ls_content || '</table>';

        ls_content := ls_content || '</body></html>';

        --Pkg_Email.AddToEmailQueue('SUBSCRIPTION', 50, 'info@demirbank.kg',row_subscribe.EMAIL , ls_header, ls_content,'HTML'); --bahianab cbs-480 14072021 commented out

        /*BOM bahianab cbs-480 14072021*/
        if instr(row_subscribe.EMAIL, ';') > 0 then
                        l_recipients := corpint2.pkg_NOTIFICATION.RecipientList();
                        l_recipients:= CORPINT2.PKG_NOTIFICATION.SPLITTEXT(row_subscribe.EMAIL);
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(ls_content, ls_header, 'info@demirbank.kg',l_recipients, 'HTML', null,null,null);
                        log_at('SUBCRIPTION',1,sqlerrm,dbms_utility.format_error_backtrace);
                    else
                        l_recipients := corpint2.pkg_NOTIFICATION.RecipientList(1);
                        l_recipients(1) := row_subscribe.EMAIL;
                        LS_RET := CORPINT2.PKG_NOTIFICATION.ADDEMAILTOQUEUENEW(ls_content, ls_header, 'info@demirbank.kg',l_recipients, 'HTML', null,null,null);
                        log_at('SUBCRIPTION',2,sqlerrm,dbms_utility.format_error_backtrace);
                    end if;
        /*EOM bahianab cbs-480 14072021*/

        IF (row_subscribe.PERIOD = 'G') THEN
             startdate:=TRUNC(SYSDATE+1*row_subscribe.PERIOD_COUNT);
        ELSIF (row_subscribe.PERIOD = 'H') THEN
             startdate:=TRUNC(SYSDATE+7*row_subscribe.PERIOD_COUNT);
        ELSE
             startdate:=TRUNC(ADD_MONTHS(SYSDATE,+1*row_subscribe.PERIOD_COUNT));
        END IF;

        UPDATE corpint.TBL_EMAIL_SUBSCRIPTION
        SET NEXTRUNDATE=startdate
        WHERE EMAIL = row_subscribe.EMAIL
        AND MSG_TYPE = row_subscribe.MSG_TYPE;

    FETCH cursor_subscribe INTO row_subscribe;
    END LOOP;
    CLOSE cursor_subscribe;

EXCEPTION
    WHEN OTHERS THEN
        Log_At('SUBCRIPTION',SQLERRM,dbms_utility.format_error_backtrace);
END;

---------------------------------------------------------------------------------------
PROCEDURE SendSUARNASYPayments( ps_externalno IN VARCHAR2) IS
ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
           SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.INVOICE_NO,d.SUBSCRIPTION_NO,d.INSTITUTION_KEY_NO, d.DETAIL_ID, sa.FIO
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d, CBS_SU_ARNASY sa
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='SU ARNASY'
        AND m.COLLECTION_DATE=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul)
        AND m.TX_NO=d.TX_NO
        AND d.SUBSCRIPTION_NO = sa.LS;


    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    ln_recordcount      NUMBER;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN

    ls_filename:='db' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'DDMMYY') || '.txt';
    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\SUARNASY',ls_filename,'w',2100);

        SELECT  COUNT(m.TX_NO)
        INTO ln_recordcount
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE m.TX_NO=d.TX_NO
        AND d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='SU ARNASY';


        WHILE cursor_aps%FOUND
        LOOP
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD(row_aps.FIO,20,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_AMOUNT,'9999999999.99');
            ls_content:=ls_content || ' ';
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);

        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');
            ls_content:=SQLERRM;
            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'SU ARNASY', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-SU ARNASY PAYMENT JOB',ls_content);
END;

---------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTCORPayments( ps_externalno IN VARCHAR2) IS
ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
           SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.INVOICE_NO,d.SUBSCRIPTION_NO,d.INSTITUTION_KEY_NO, d.DETAIL_ID, an.FIO, an.ADDRESS,
                d.en103,d.en104, d.en106, d.en107, d.en108, d.en110, d.en12, d.en13
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d, CBS_AST_ENERGY an
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ENERGY SBYT COR'
        AND m.COLLECTION_DATE=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul)
        AND m.TX_NO=d.TX_NO
        AND d.SUBSCRIPTION_NO = an.LIC_ACC;

    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    ln_recordcount      NUMBER;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN

    ls_filename:='co' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'DDMMYY') || '.txt';
    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename,'w',2100);

        SELECT  COUNT(m.TX_NO)
        INTO ln_recordcount
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE m.TX_NO=d.TX_NO
        AND d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ENERGY SBYT COR';


        WHILE cursor_aps%FOUND
        LOOP
          IF row_aps.en103 IS NOT NULL AND row_aps.en103 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en103,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('103',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en104 IS NOT NULL AND row_aps.en104 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en104,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('104',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en106 IS NOT NULL AND row_aps.en106 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en106,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('106',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en107 IS NOT NULL AND row_aps.en107 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en107,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('107',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en108 IS NOT NULL AND row_aps.en108 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en108,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('108',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en110 IS NOT NULL AND row_aps.en110 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en110,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('110',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en12 IS NOT NULL AND row_aps.en12 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en12,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('12',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en13 IS NOT NULL AND row_aps.en13 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en13,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('13',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          END IF;


        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');
            ls_content:=SQLERRM;
            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'ENERGY SBYT', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-ENERGY SBYT PAYMENT JOB',ls_content);
END;

---------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTBUDPayments( ps_externalno IN VARCHAR2) IS
ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
           SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.INVOICE_NO,d.SUBSCRIPTION_NO,d.INSTITUTION_KEY_NO, d.DETAIL_ID, an.FIO, an.ADDRESS,
                d.en103,d.en104, d.en106, d.en107, d.en108, d.en110, d.en12, d.en13
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d, CBS_AST_ENERGY an
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ENERGY SBYT BUD'
        AND m.COLLECTION_DATE=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul)
        AND m.TX_NO=d.TX_NO
        AND d.SUBSCRIPTION_NO = an.LIC_ACC;


    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    ln_recordcount      NUMBER;
    f UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;

BEGIN

    ls_filename:='bu' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'DDMMYY') || '.txt';
    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN

        f:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename,'w',2100);

        SELECT  COUNT(m.TX_NO)
        INTO ln_recordcount
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d
        WHERE m.TX_NO=d.TX_NO
        AND d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ENERGY SBYT BUD';


        WHILE cursor_aps%FOUND
        LOOP
          IF row_aps.en103 IS NOT NULL AND row_aps.en103 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en103,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('103',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en104 IS NOT NULL AND row_aps.en104 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en104,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('104',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en106 IS NOT NULL AND row_aps.en106 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en106,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('106',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en107 IS NOT NULL AND row_aps.en107 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en107,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('107',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en108 IS NOT NULL AND row_aps.en108 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en108,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('108',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en110 IS NOT NULL AND row_aps.en110 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en110,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('110',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en12 IS NOT NULL AND row_aps.en12 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en12,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('12',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          ELSIF row_aps.en13 IS NOT NULL AND row_aps.en13 <> 0 THEN
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,15,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en13,'9999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,25,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY HH24:MI:SS');
            ls_content:=ls_content || LPAD('13',10,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,5,' ');
            ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
          END IF;


        FETCH cursor_aps INTO row_aps;
        END LOOP;

        ls_returncode:=Pkg_Message.CloseFile(f);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;

    END IF;
    CLOSE cursor_aps;

    COMMIT;

EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');
            ls_content:=SQLERRM;
            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'ENERGY SBYT', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-ENERGY SBYT PAYMENT JOB',ls_content);
END;
---------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTINDPayments( ps_externalno IN VARCHAR2) IS
   ls_fileext            VARCHAR2(3);
   ls_filepre            VARCHAR2(9);
   ls_filename            VARCHAR2(20);
   ls_filename103            VARCHAR2(20);
   ls_filename104            VARCHAR2(20);
   ls_filename106            VARCHAR2(20);
   ls_filename107            VARCHAR2(20);
   ls_filename108            VARCHAR2(20);
   ls_filename110            VARCHAR2(20);
   ls_ara                VARCHAR2(1):= CHR(43);
   ls_ara2                VARCHAR2(1):= CHR(42);
   ls_bodycontent        VARCHAR2(4000);
   ls_content            CLOB;
   ln_messageid            NUMBER;
   CURSOR cursor_aps IS
           SELECT  m.*,d.COLLECTION_AMOUNT,d.PHONE_NO,d.FROMBANK_BIC,d.INVOICE_NO,d.SUBSCRIPTION_NO,d.DETAIL_ID, an.FIO, an.ADDRESS,
                d.en103,d.en104, d.en106, d.en107, d.en108, d.en110, d.en12, d.en13
        FROM CBS_COLLECTION_MASTER m,CBS_COLLECTION_DETAIL d, CBS_AST_ENERGY an
        WHERE d.STATUS_CD='sWAIT'
        AND d.INSTITUTION_CODE='ENERGY SBYT IND'
        AND m.COLLECTION_DATE=Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul)
        AND m.TX_NO=d.TX_NO
        AND d.SUBSCRIPTION_NO = an.LIC_ACC;

    row_aps    cursor_aps%ROWTYPE;
    i        NUMBER:=1;
    f UTL_FILE.FILE_TYPE;
    f103 UTL_FILE.FILE_TYPE;
    f104 UTL_FILE.FILE_TYPE;
    f106 UTL_FILE.FILE_TYPE;
    f107 UTL_FILE.FILE_TYPE;
    f108 UTL_FILE.FILE_TYPE;
    f110 UTL_FILE.FILE_TYPE;
    ls_returncode         VARCHAR2(3);
    FileErrorException             EXCEPTION;
    en103count NUMBER := 0;
    en103amount NUMBER := 0;
    en104count NUMBER := 0;
    en104amount NUMBER := 0;
    en106count NUMBER := 0;
    en106amount NUMBER := 0;
    en107count NUMBER := 0;
    en107amount NUMBER := 0;
    en108count NUMBER := 0;
    en108amount NUMBER := 0;
    en110count NUMBER := 0;
    en110amount NUMBER := 0;
    endate VARCHAR2(10);
BEGIN
    ls_filename103:='103' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    ls_filename104:='104' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    ls_filename106:='106' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    ls_filename107:='107' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    ls_filename108:='108' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    ls_filename110:='110' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    OPEN cursor_aps;
    FETCH cursor_aps INTO row_aps;
    IF cursor_aps%FOUND THEN
        f103:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename103,'w',2100);
        f104:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename104,'w',2100);
        f106:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename106,'w',2100);
        f107:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename107,'w',2100);
        f108:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename108,'w',2100);
        f110:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename110,'w',2100);
        WHILE cursor_aps%FOUND LOOP
          IF row_aps.en103 IS NOT NULL AND row_aps.en103 <> 0 THEN
            en103count := en103count + 1;
            en103amount := en103amount + row_aps.en103;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en103,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f103,ls_content);
          END IF;
          IF row_aps.en104 IS NOT NULL AND row_aps.en104 <> 0 THEN
            en104count := en104count + 1;
            en104amount := en104amount + row_aps.en104;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en104,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f104,ls_content);
          END IF;
          IF row_aps.en106 IS NOT NULL AND row_aps.en106 <> 0 THEN
            en106count := en106count + 1;
            en106amount := en106amount + row_aps.en106;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en106,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f106,ls_content);
          END IF;
          IF row_aps.en107 IS NOT NULL AND row_aps.en107 <> 0 THEN
            en107count := en107count + 1;
            en107amount := en107amount + row_aps.en107;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en107,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f107,ls_content);
          END IF;
          IF row_aps.en108 IS NOT NULL AND row_aps.en108 <> 0 THEN
            en108count := en108count + 1;
            en108amount := en108amount + row_aps.en108;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en108,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f108,ls_content);
          END IF;
          IF row_aps.en110 IS NOT NULL AND row_aps.en110 <> 0 THEN
            en110count := en110count + 1;
            en110amount := en110amount + row_aps.en110;
            ls_content:=LPAD(row_aps.SUBSCRIPTION_NO,6,' ');
            ls_content:=ls_content || LPAD(row_aps.FIO,30,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.en110,'9999999999999999999.99');
            ls_content:=ls_content || LPAD(row_aps.ADDRESS,50,' ');
            ls_content:=ls_content || TO_CHAR(row_aps.COLLECTION_DATE,'DD.MM.YYYY');
            ls_content:=ls_content || '            ';
            ls_content:=ls_content || LPAD(row_aps.DETAIL_ID,19,' ');
            ls_content:=ls_content || LPAD(row_aps.BRANCH,3,' ');
            ls_returncode:=Pkg_Message.WriteLine(f110,ls_content);
          END IF;
        FETCH cursor_aps INTO row_aps;
        END LOOP;
        ls_returncode:=Pkg_Message.CloseFile(f103);
        ls_returncode:=Pkg_Message.CloseFile(f104);
        ls_returncode:=Pkg_Message.CloseFile(f106);
        ls_returncode:=Pkg_Message.CloseFile(f107);
        ls_returncode:=Pkg_Message.CloseFile(f108);
        ls_returncode:=Pkg_Message.CloseFile(f110);

        IF ls_returncode<>'000' THEN
           RAISE FileErrorException;
        END IF;
    END IF;
    CLOSE cursor_aps;

    endate := TO_CHAR(SYSDATE, 'dd/mm/yyyy');
    ls_filename:='registr' || TO_CHAR(Pkg_Tarih.geri_is_gunu(Pkg_Muhasebe.Banka_Tarihi_Bul),'MMDD') || '.txt';
    f:=UTL_FILE.FOPEN(UTILITY_PATH || '\ENERGYSBYT',ls_filename,'w',2100);
    ls_content:='                      ????? ????????? ????'; ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:='          ?????? ??????????? ???????????? ????????'; ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:='                       ?? ' || TO_CHAR(SYSDATE, 'dd.mm.yyyy') || ' ?.'; ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' '; ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' ?     ????????????              ????         ??????????  ????? ??????';ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:='?/?       ??????              ????????????     ???-?? ?      ?? ?????';ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:='                                 ?????          ?????';ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 1   ?????????               '||LPAD(endate, 10, ' ')||'      '||LPAD(en103count, 8, ' ')||'  '||LPAD(en103amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 2   ??????? ?????????????   '||LPAD(endate, 10, ' ')||'      '||LPAD(en104count, 8, ' ')||'  '||LPAD(en104amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 3   ?????????????           '||LPAD(endate, 10, ' ')||'      '||LPAD(en106count, 8, ' ')||'  '||LPAD(en106amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 4   ??????????????          '||LPAD(endate, 10, ' ')||'      '||LPAD(en107count, 8, ' ')||'  '||LPAD(en107amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 5   ????                    '||LPAD(endate, 10, ' ')||'      '||LPAD(en108count, 8, ' ')||'  '||LPAD(en108amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_content:=' 6   ??????? ??????          '||LPAD(endate, 10, ' ')||'      '||LPAD(en110count, 8, ' ')||'  '||LPAD(en110amount, 13, ' ');ls_returncode:=Pkg_Message.WriteLine(f,ls_content);
    ls_returncode:=Pkg_Message.CloseFile(f);
    IF ls_returncode<>'000' THEN
      RAISE FileErrorException;
    END IF;

    COMMIT;
EXCEPTION
         WHEN OTHERS THEN
         ROLLBACK;
               ln_messageid:=Pkg_Genel.genel_kod_al('EMAIL-MSGID');
            ls_content:=SQLERRM;
            INSERT INTO CBS_EMAIL_MESSAGES
            (MESSAGE_ID, MESSAGE_CODE, PRIORITY, SENDER, RECIPIENT, SUBJECT, BODY_CONTENT)
            VALUES
            (ln_messageid, 'ENERGY SBYT', 50, 'info@demirbank.kg', 'ITGroup@demirbank.kg', 'ERROR-ENERGY SBYT PAYMENT JOB',ls_content);
END;
------------------------------------------------------------------------------------------
FUNCTION GetSubscibeDate(pn_accountno IN VARCHAR2) RETURN DATE IS

  ld_date DATE;
  ls_period VARCHAR2(3);
  ln_period_count NUMBER:=1;

    BEGIN

            SELECT e.PERIOD, e.PERIOD_COUNT
            INTO ls_period, ln_period_count
            FROM corpint.TBL_EMAIL_SUBSCRIPTION e
            WHERE e.STATUS_CD='sENAB'
            AND e.ACCOUNT_NO=pn_accountno
            AND e.MSG_TYPE='MOVEMENT';

            IF (ls_period = 'G') THEN
                 ld_date:=TRUNC(SYSDATE-1*ln_period_count+1);
            ELSIF (ls_period = 'H') THEN
                 ld_date:=TRUNC(SYSDATE-7*ln_period_count+1);
            ELSE
                 ld_date:=TRUNC(ADD_MONTHS(SYSDATE,-1*ln_period_count)+1);
            END IF;

    RETURN ld_date;

    EXCEPTION
        WHEN OTHERS THEN
        Log_At('SUBSCRIBE_DATE',SQLERRM);
    END;
------------------------------------------------------------------------------------------
PROCEDURE SendDealSlip(ps_channel_cd IN VARCHAR2,
                       ps_email IN VARCHAR2,
                       ps_tx_no IN VARCHAR2,
                       ps_lang_cd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType) IS 

  ls_content CLOB;
  ls_subject VARCHAR2(500) := 'DKIB summary message';
  ln_tran_code NUMBER := 0;
  ls_customer_name VARCHAR2(100);
  ln_customer_no NUMBER;
  ls_tran_name VARCHAR2(100);
  ls_sysdate VARCHAR2(20) := TO_CHAR(SYSDATE, 'dd.mm.yyyy');
  ls_tran_date VARCHAR2(20);
  ln_debit_account_no NUMBER;
  ln_credit_account_no VARCHAR2(50);
  ln_transaction_amount NUMBER;
  ln_transaction_rate NUMBER;
  ls_transaction_curr VARCHAR2(10) := 'KGS';
  ls_description VARCHAR2(2000);
  ln_tx_no NUMBER := TO_NUMBER(ps_tx_no);
  ln_customer_no_count NUMBER := 0;
  ls_ulke_kodu VARCHAR2(300);
  ls_awi_bic VARCHAR2(300);
  ln_masraf_toplami NUMBER;
  ln_tax_rate NUMBER:=0;
 -- CC TEST
  -- B-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
  ls_body_text VARCHAR2(2000);
  ls_attachment_name VARCHAR2(500);
  ls_sender_email VARCHAR2(200);
  -- E-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
  ls_mobile_number varchar2(100);
  ls_service_number varchar2(100);

  ls_institution_cd CBS_TAHSILAT_KURUM_TANIM.KURUM_KODU%Type;
  ls_institution_name CBS_TAHSILAT_KURUM_TANIM.KURUM_ADI%Type;
  ls_group_cd CBS_TAHSILAT_KURUM_TANIM.KURUM_GRUP_KOD%Type;
  ls_group_name CBS_TAHSILAT_KURUM_GRUP_TANIM.ACIKLAMA%Type;
  ls_subgroup_cd CBS_TAHSILAT_KURUM_TANIM.KURUM_ALT_GRUP_KOD%Type;
  ls_subgroup_name CBS_TAHSILAT_KURUM_ALTGRUP_TAN.ACIKLAMA%Type;
  
    BEGIN

        SELECT ISLEM_KOD INTO ln_tran_code
        FROM CBS_ISLEM
        WHERE NUMARA = ps_tx_no;

        IF ln_tran_code=1207 THEN
            ls_tran_name := 'Arbitrage';
            SELECT PARITE, SATIS_HESAP_NO, ALIS_HESAP_NO, ACIKLAMA, ALIS_TUTARI, ALIS_DOVIZ_KODU
            INTO ln_transaction_rate, ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_ARBITRAJ_ISLEM
            WHERE TX_NO = ln_tx_no;
        ELSIF ln_tran_code=4025 THEN
            ls_tran_name := 'Foreign Exchange Buy';
            SELECT KUR, MUSTERI_HESAP_NO, DTH_MUSTERI_HESAP_NO, ACIKLAMA, DOVIZ_TUTARI, DOVIZ_KODU
            INTO ln_transaction_rate, ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_DTH_DOVIZ_SATIS_ISLEM
            WHERE TX_NO = ln_tx_no;
        ELSIF ln_tran_code=1202 THEN
            ls_tran_name := 'Foreign Exchange Sell';
            SELECT KUR, BORC_HESAP_NO, ALACAK_HESAP_NO, ACIKLAMA, TUTAR, DOVIZ_KODU
            INTO ln_transaction_rate, ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_DTH_TL_ODEME_ISLEM
            WHERE TX_NO = ln_tx_no;
        ELSIF ln_tran_code=2003 THEN
            ls_tran_name := 'Opening Time Deposit Account';
            SELECT BORCLU_HESAP_NO, HESAP_NUMARASI, ACIKLAMA, TUTAR, DOVIZ_KODU
            INTO ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_HESAP_VADELI_BASVURU
            WHERE TX_NO = ln_tx_no;
        ELSIF ln_tran_code=3555 THEN
            ls_tran_name := 'Clearing';
            SELECT FROM_ACCOUNT_EXTERNAL_NUMBER, TO_ACCOUNT_EXTERNAL_NUMBER, EXPLANATION, AMOUNT, Pkg_Genel.LC_AL
            INTO ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_CLEARING
            WHERE YARATAN_TX_NO = ln_tx_no;
        ELSIF ln_tran_code=1203 THEN
            SELECT BORC_HESAP_NO, ALACAK_HESAP_NO, ACIKLAMA, TUTAR, DOVIZ_KODU
            INTO ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr
            FROM CBS_VIRMAN_ISLEM
            WHERE TX_NO = ln_tx_no;

            SELECT COUNT(DISTINCT musteri_no) INTO ln_customer_no_count
            FROM CBS_HESAP
            WHERE hesap_no IN (ln_credit_account_no, ln_debit_account_no);

            IF (ln_customer_no_count > 1) THEN
                ls_tran_name := 'Book To Book Transfer to other accounts';
            ELSE
                ls_tran_name := 'Book To Book Transfer between own accounts';
            END IF;
        ELSIF ln_tran_code=4003 THEN

           BEGIN
               SELECT TO_NUMBER(REPLACE(DEGER,'.',',')) INTO ln_tax_rate
               FROM CBS_PARAMETRE
               WHERE kod='G_SALES_TAX_RATE'
               AND ROWNUM=1;
           EXCEPTION
               WHEN OTHERS THEN
                   BEGIN
                       SELECT TO_NUMBER(REPLACE(DEGER,',','.')) INTO ln_tax_rate
                       FROM CBS_PARAMETRE
                       WHERE kod='G_SALES_TAX_RATE'
                       AND ROWNUM=1;
                   EXCEPTION
                       WHEN OTHERS THEN
                           ln_tax_rate:=0;
                   END;
           END;

            ls_tran_name := 'International Money Transfer';
            SELECT BORCLU_HESAP_NO, BC_HESAP_NO_N, ACIKLAMA, TUTAR, TRANSFER_DOVIZ_KODU, ULKE_KODU, AWI_BIC, MASRAF_TOPLAMI + TO_NUMBER(MASRAF_TOPLAMI)*ln_tax_rate/100
            INTO ln_debit_account_no, ln_credit_account_no, ls_description, ln_transaction_amount, ls_transaction_curr, ls_ulke_kodu, ls_awi_bic, ln_masraf_toplami
            FROM CBS_YPHAVALE_GIDEN_ACILIS
            WHERE TX_NO = ln_tx_no;

            SELECT BANKA_ADI, ULKE_ADI INTO ls_awi_bic, ls_ulke_kodu
            FROM CBS_BIC_KODLARI
            WHERE BIC_KODU = ls_awi_bic
            AND BIC_ULKE_KODU = ls_ulke_kodu
            AND ROWNUM=1;
        elsif ln_tran_code=6330 then

            ls_tran_name := 'Payment for Services';

            select a.HESAP_NO, b.TUTAR, a.DOVIZ_KODU, b.ABONE_ADI, b.TELEFON_ALAN_KOD||'-'||b.TELEFON_NO, b.SERVICE_KODU||'-'||b.KURUM_OZEL_NO, b.KURUM_KODU
            into ln_debit_account_no, ln_transaction_amount, ls_transaction_curr, ls_description, ls_mobile_number, ls_service_number, ls_institution_cd
            from CBS_TAHSILAT_ANA_ISLEM a, CBS_TAHSILAT_DETAY_ISLEM b
            where a.ISLEM_NO = ln_tx_no
            and a.ISLEM_NO = B.ISLEM_NO;

            select KURUM_ADI, KURUM_GRUP_KOD, KURUM_ALT_GRUP_KOD
            into ls_institution_name, ls_group_cd, ls_subgroup_cd
            from CBS_TAHSILAT_KURUM_TANIM
            where KURUM_KODU=ls_institution_cd;

            select ACIKLAMA
            into ls_group_name
            from CBS_TAHSILAT_KURUM_GRUP_TANIM
            where GRUP_KODU = ls_group_cd;

            select ACIKLAMA
            into ls_subgroup_name
            from CBS_TAHSILAT_KURUM_ALTGRUP_TAN
            where GRUP_KODU = ls_group_cd
            and ALT_GRUP_KODU = ls_subgroup_cd;

        end if;

        SELECT MUSTERI_NUMARA, TO_CHAR(KAYIT_SISTEM_TARIHI,'dd.mm.yyyy hh24:mi') INTO ln_customer_no, ls_tran_date
        FROM CBS_ISLEM
        WHERE NUMARA = ln_tx_no;

        SELECT trim(ISIM || ' ' || IKINCI_ISIM || ' ' || SOYADI) INTO ls_customer_name
        FROM CBS_MUSTERI
        WHERE MUSTERI_NO = ln_customer_no;

        ls_subject := ls_tran_name || ' transaction e-summary';

        ls_content := ls_content || GetCreditCardDekontHeadFoot('HEADER',ps_lang_cd);

        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td style="padding-left:10px;padding-top:5px;font-size:13px;">';
        ls_content := ls_content || '                ' || GetLangLabels('DEALSLIP', 1, 1, ps_lang_cd) ||' <B>' || ls_customer_name ||'</B>,';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '            <td align="right" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                ' || ls_sysdate || '';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td align="right" colspan="2" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                <B>' || ls_tran_name ||'</B>';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr>';
        ls_content := ls_content || '            <td colspan="2" aling="center">';
        ls_content := ls_content || '                <table width="590" cellspacing="0" cellpadding="0" border="0" class="OuterDataTable1">';
        ls_content := ls_content || '                    <tr>';
        ls_content := ls_content || '                        <td>';
        ls_content := ls_content || '                            <table width="590" cellspacing="1" cellpadding="0" border="0" class="DataTable1">';
        ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
        ls_content := ls_content || '                                    <td width="200"><B>' || GetLangLabels('DEALSLIP', 1, 2, ps_lang_cd) ||'</B></td>';
        ls_content := ls_content || '                                    <td align="left">'|| ls_tran_date ||'</td>';
        ls_content := ls_content || '                                </tr>';
        ls_content := ls_content || '                                <tr style="background-color:#F8F8F8;font-size:13px;">';
        ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 3, ps_lang_cd) ||'</B></td>';
        ls_content := ls_content || '                                    <td align="left">' || ls_customer_name ||'</td>';
        ls_content := ls_content || '                                </tr>';
        IF ln_tran_code IN (4003) THEN
            ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 27, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_debit_account_no || '</td>';
            ls_content := ls_content || '                                </tr>';
            ls_content := ls_content || '                                <tr style="background-color:#F8F8F8;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 28, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_credit_account_no || '</td>';
            ls_content := ls_content || '                                </tr>';
            ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 24, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ls_awi_bic || '</td>';
            ls_content := ls_content || '                                </tr>';
            ls_content := ls_content || '                                <tr style="background-color:#F8F8F8;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 25, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ls_ulke_kodu || '</td>';
            ls_content := ls_content || '                                </tr>';
            ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 26, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_masraf_toplami || '</td>';
            ls_content := ls_content || '                                </tr>';
        ELSE
            ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 4, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_debit_account_no || '</td>';
            ls_content := ls_content || '                                </tr>';
            ls_content := ls_content || '                                <tr style="background-color:#F8F8F8;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 5, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_credit_account_no || '</td>';
            ls_content := ls_content || '                                </tr>';
        END IF;

        IF ln_tran_code IN (1207,4026,1202) THEN
            ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
            ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 6, ps_lang_cd) ||'</B></td>';
            ls_content := ls_content || '                                    <td align="left">' || ln_transaction_rate || '</td>';
            ls_content := ls_content || '                                </tr>';
        END IF;

        ls_content := ls_content || '                                <tr style="background-color:#F8F8F8;font-size:13px;">';
        ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 7, ps_lang_cd) ||'</B></td>';
        ls_content := ls_content || '                                    <td align="left">' || ln_transaction_amount || ' ' || ls_transaction_curr || '</td>';
        ls_content := ls_content || '                                </tr>';
        ls_content := ls_content || '                                <tr style="background-color:#FCFCFC;font-size:13px;">';
        ls_content := ls_content || '                                    <td><B>' || GetLangLabels('DEALSLIP', 1, 8, ps_lang_cd) ||'</B></td>';
        ls_content := ls_content || '                                    <td align="left">' || ls_description || '</td>';
        ls_content := ls_content || '                                </tr>';
        ls_content := ls_content || GetCreditCardDekontHeadFoot('FOOTER',ps_lang_cd);

        -- B-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
        pkg_parametre.deger('DEAL_SLIP_BODY', ls_body_text);
        pkg_parametre.deger('DEAL_SLIP_ATTACH_NAME', ls_attachment_name);
        pkg_parametre.deger('DEAL_SLIP_SENDER', ls_sender_email);
        if  ps_channel_cd='cDKBRIB' then
            --Pkg_Email.AddToEmailQueue('DEALSLIP', 51, 'info@demirbank.kg', ps_email, ls_subject, ls_content,'HTML');
            pkg_email.AddToEmailQueue_Atc('DEALSLIP', 51, ls_sender_email, ps_email, ls_subject, ls_body_text, ls_attachment_name, to_char(ls_content));
        elsif ps_channel_cd='cDKBCIB' then
            --Pkg_Email.AddToEmailQueue('DEALSLIP', 51, 'info@demirbank.kg', ps_email, ls_subject, ls_content,'HTML');
            pkg_email.AddToEmailQueue_Atc('DEALSLIP', 51, ls_sender_email, ps_email, ls_subject, ls_body_text, ls_attachment_name, to_char(ls_content));
        end if;
        -- E-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
        
    open pc_ref 
    for select 
        ln_customer_no as customer_no,
        ls_customer_name as customer_name,
        ls_tran_date as tran_date,
        ln_transaction_rate as transaction_rate,
        ln_debit_account_no as debit_account_no,
        ln_credit_account_no as credit_account_no,
        ls_description as description,
        ln_transaction_amount as transaction_amount,
        ls_transaction_curr as transaction_curr,
        ls_ulke_kodu as country_code,
        ls_awi_bic as awi_bic,
        ln_masraf_toplami as commission,
        ls_sysdate as today_date,
        ls_tran_name as tran_name,
        ls_institution_cd as institution,
        DECODE(ls_mobile_number, '', ls_service_number, ls_mobile_number) as service_number,
        GetLangLabels('DEALSLIP', 1, 1, ps_lang_cd) as customer_name_label_1,
        GetLangLabels('DEALSLIP', 1, 3, ps_lang_cd) as customer_name_label_2,
        GetLangLabels('DEALSLIP', 1, 2, ps_lang_cd) as tran_date_label,
        GetLangLabels('DEALSLIP', 1, 6, ps_lang_cd) as transaction_rate_label,
        GetLangLabels('DEALSLIP', 1, 4, ps_lang_cd) as debit_account_no_label_1,
        GetLangLabels('DEALSLIP', 1, 27, ps_lang_cd) as debit_account_no_label_2,
        GetLangLabels('DEALSLIP', 1, 29, ps_lang_cd) as debit_account_no_label_3,
        GetLangLabels('DEALSLIP', 1, 5, ps_lang_cd) as credit_account_no_label_1,
        GetLangLabels('DEALSLIP', 1, 28, ps_lang_cd) as credit_account_no_label_2,
        GetLangLabels('DEALSLIP', 1, 8, ps_lang_cd) as description_label,
        GetLangLabels('DEALSLIP', 1, 7, ps_lang_cd) as transaction_amount_label,
        GetLangLabels('DEALSLIP', 1, 25, ps_lang_cd) as country_code_label,
        GetLangLabels('DEALSLIP', 1, 24, ps_lang_cd) as awi_bic_label,
        GetLangLabels('DEALSLIP', 1, 26, ps_lang_cd) as commission_label,
        GetLangLabels('DEALSLIP', 1, 30, ps_lang_cd) as institution_label,
        GetLangLabels('DEALSLIP', 1, 33, ps_lang_cd) as card_no_label,
        GetLangLabels('DEALSLIP', 1, 34, ps_lang_cd) as card_holder_label,
        DECODE(ls_mobile_number, '', GetLangLabels('DEALSLIP', 1, 31, ps_lang_cd), GetLangLabels('DEALSLIP', 1, 32, ps_lang_cd))  as service_number_label,
        ln_tran_code
    from dual;

    EXCEPTION
        WHEN OTHERS THEN
        Log_At('DEALSLIP',SQLERRM, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;
------------------------------------------------------------------------------------------
PROCEDURE SendAccountHistory(ps_channel_cd IN VARCHAR2,
                             ps_lang_cd IN VARCHAR2,
                             ps_person_id IN VARCHAR2,
                             ps_email IN VARCHAR2,
                             ps_start_date IN VARCHAR2,
                             ps_end_date IN VARCHAR2,
                             ps_type IN VARCHAR2,
                             ps_account_no IN VARCHAR2) IS

  ls_content CLOB;
  ls_subject VARCHAR2(500) := 'DKIB summary message';
  ls_customer_name VARCHAR2(50);
  ln_customer_no NUMBER;
  ls_tran_name VARCHAR2(30);
  ls_sysdate VARCHAR2(20) := TO_CHAR(SYSDATE, 'dd.mm.yyyy');
  ln_rownum NUMBER := 0;
  ls_row_color VARCHAR2(10);


    CURSOR account_movement IS
        SELECT  TO_CHAR(A.FIS_MUHASEBELESTIGI_TARIH,'YYYYMMDD'),
                TO_CHAR(A.SATIR_VALOR_TARIHI,'YYYYMMDD'),
                A.SATIR_MUSTERI_ACIKLAMA satir_aciklama,
                A.SATIR_DV_TUTAR dvz_tutar,
                NVL(Pkg_Passbook.HareketliBakiyeHesapla(A.SATIR_HESAP_NUMARA,A.FIS_NUMARA,A.SATIR_NUMARA),0) SON_BAKIYE,
                SATIR_DOVIZ_KOD,
                I.ACIKLAMA aciklama,
                K.NUMARA,
                K.ISLEM_KOD,
                ps_lang_cd,
                Pkg_Report5.GETNBEQUIVALENT(SATIR_DOVIZ_KOD, FIS_MUHASEBELESTIGI_TARIH, SATIR_DV_TUTAR) NBEQUIVALENT,
                Pkg_Musteri.SF_ADRES_AL(MUSTERI_NO),
                Pkg_Musteri.SF_VERGINO_AL(MUSTERI_NO),
                MUSTERI_NO,
                SATIR_MUSTERI_HESAP_NUMARA,
                Pkg_Hesap.EXTERNAL_HESAPNO_AL(SATIR_MUSTERI_HESAP_NUMARA),
                DECODE(SATIR_HESAP_BOLUM_KODU,'010','010   Main Branch','020','020   Osh Branch','030','030   Center Branch','040','040   Manas Branch'),
                Pkg_Musteri.SF_MUSTERI_ADI(MUSTERI_NO),
                Pkg_Hesap.HESAPBAKIYEAL(SATIR_MUSTERI_HESAP_NUMARA),
                TO_CHAR(K.KAYIT_SISTEM_TARIHI,'DD.MM.YYYY') system_tarihi
        FROM cbs_vw_fis_satir_vsziz A,CBS_ISLEM K, CBS_ISLEM_TANIM I
        WHERE  SATIR_HESAP_NUMARA = ps_account_no AND
               FIS_MUHASEBELESTIGI_TARIH BETWEEN TO_DATE(ps_start_date,'DD/MM/YYYY') AND TO_DATE(ps_end_date,'DD/MM/YYYY')
               AND FIS_TUR = 'G'
               AND A.SATIR_TUR LIKE DECODE(ps_type, 'ALL', A.SATIR_TUR, ps_type)
               AND K.NUMARA=A.FIS_ISLEM_NUMARA
               AND I.KOD=K.ISLEM_KOD
        ORDER BY A.FIS_NUMARA, A.SATIR_NUMARA;

        row_movement  account_movement%ROWTYPE;
  -- B-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
  ls_body_text VARCHAR2(2000);
  ls_attachment_name VARCHAR2(500);
  ls_sender_email VARCHAR2(200);
  -- E-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
    BEGIN
        SELECT customer_id INTO ln_customer_no
        FROM corpint.tbl_person
        WHERE person_id = ps_person_id;

        SELECT trim(ISIM || ' ' || IKINCI_ISIM || ' ' || SOYADI) INTO ls_customer_name
        FROM CBS_MUSTERI
        WHERE MUSTERI_NO = ln_customer_no;

        ls_tran_name := 'Account History';

        ls_subject := ls_tran_name || ' e-summary';

        ls_content := ls_content || GetCreditCardDekontHeadFoot('HEADER',ps_lang_cd);

        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td style="padding-left:10px;padding-top:5px;font-size:13px;">';
        ls_content := ls_content || '                ' || GetLangLabels('DEALSLIP', 1, 1, ps_lang_cd) ||' <B>' || ls_customer_name ||'</B>,';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '            <td align="right" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                ' || ls_sysdate || '';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td align="right" colspan="2" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                <B>' || ls_tran_name ||'</B>';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr>';
        ls_content := ls_content || '            <td colspan="2" aling="center">';
        ls_content := ls_content || '                <table width="590" cellspacing="0" cellpadding="0" border="0" class="OuterDataTable1">';
        ls_content := ls_content || '                    <tr>';
        ls_content := ls_content || '                        <td>';
        ls_content := ls_content || '                            <table width="590" cellspacing="1" cellpadding="0" border="0" class="DataTable1">';

        ls_content := ls_content || '       <thead><tr>';
        ls_content := ls_content || '           <th class="tableHeader_style1">' || GetLangLabels('ACCHISTORY', 1, 6, ps_lang_cd) || '</th>';
        ls_content := ls_content || '           <th class="tableHeader_style1" align=left>' || GetLangLabels('ACCHISTORY', 1, 12, ps_lang_cd) || '</th>';
        ls_content := ls_content || '           <th class="tableHeader_style1">' || GetLangLabels('ACCHISTORY', 1, 52, ps_lang_cd) || '</th>';
        ls_content := ls_content || '           <th class="tableHeader_style1" align=right>' || GetLangLabels('ACCHISTORY', 1, 28, ps_lang_cd) || '</th>';
        ls_content := ls_content || '           <th class="tableHeader_style1" align=right>' || GetLangLabels('ACCHISTORY', 1, 27, ps_lang_cd) || '</th>';
        ls_content := ls_content || '       </tr></thead>';
        ls_content := ls_content || '       <tbody>';

        OPEN account_movement;
        FETCH account_movement INTO row_movement;
        WHILE account_movement%FOUND
        LOOP
            ln_rownum := ln_rownum + 1;
            IF (MOD(ln_rownum,2) = 0) THEN
                ls_row_color := 'FCFCFC';
                ELSE
                ls_row_color := 'F8F8F8';
            END IF;

            ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
            ls_content := ls_content || '<td>' || row_movement.system_tarihi || '</td>';
            ls_content := ls_content || '<td>' || row_movement.aciklama || '</td>';
            ls_content := ls_content || '<td>' || row_movement.satir_aciklama || '</td>';
            ls_content := ls_content || '<td align=right nowrap>' || row_movement.dvz_tutar || ' ' || row_movement.SATIR_DOVIZ_KOD || '</td>';
            ls_content := ls_content || '<td align=right nowrap>' || row_movement.SON_BAKIYE || ' ' || row_movement.SATIR_DOVIZ_KOD || '</td>';
            ls_content := ls_content || '</tr>';

            FETCH account_movement INTO row_movement;
        END LOOP;
        CLOSE account_movement;

        ls_content := ls_content || GetCreditCardDekontHeadFoot('FOOTER',ps_lang_cd);

        -- B-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending
        pkg_parametre.deger('DEAL_SLIP_BODY', ls_body_text);
        pkg_parametre.deger('DEAL_SLIP_ATTACH_NAME', ls_attachment_name);
        pkg_parametre.deger('DEAL_SLIP_SENDER', ls_sender_email);
        if  ps_channel_cd='cDKBRIB' then
            --Pkg_Email.AddToEmailQueue('DEALSLIP', 51, 'info@demirbank.kg', ps_email, ls_subject, ls_content,'HTML');
            pkg_email.AddToEmailQueue_Atc('DEALSLIP', 51, ls_sender_email, ps_email, ls_subject, ls_body_text, ls_attachment_name, to_char(ls_content));
        elsif ps_channel_cd='cDKBCIB' then
            --Pkg_Email.AddToEmailQueue('DEALSLIP', 51, 'info@demirbank.kg', ps_email, ls_subject, ls_content,'HTML');
            pkg_email.AddToEmailQueue_Atc('DEALSLIP', 51, ls_sender_email, ps_email, ls_subject, ls_body_text, ls_attachment_name, to_char(ls_content));
        end if;
        -- E-O-M CQ4980  AdiletK 28.08.2015 update e-mail sending

    EXCEPTION
        WHEN OTHERS THEN
        Log_At('AccountHistory_DEALSLIP',SQLERRM);
    END;
------------------------------------------------------------------------------------------
PROCEDURE SendCreditCardTranList(ps_TranCD IN VARCHAR2,
                                 ps_From IN VARCHAR2,
                                 ps_To IN VARCHAR2,
                                 ps_Subject IN VARCHAR2,
                                 ps_Data IN CLOB,
                                 ps_channel_cd IN VARCHAR2,
                                 ps_lang_cd IN VARCHAR2,
                                 ps_person_id IN VARCHAR2) IS

  ls_content CLOB;
  ls_subject VARCHAR2(500) := 'DKIB summary message';
  ls_customer_name VARCHAR2(50);
  ln_customer_no NUMBER;
  ls_tran_name VARCHAR2(30);
  ls_sysdate VARCHAR2(20) := TO_CHAR(SYSDATE, 'dd.mm.yyyy');
  ln_rownum NUMBER := 0;
  ls_row_color VARCHAR2(10);
  ls_list CLOB := '';

    BEGIN
        SELECT customer_id INTO ln_customer_no
        FROM corpint.tbl_person
        WHERE person_id = ps_person_id;

        SELECT trim(ISIM || ' ' || IKINCI_ISIM || ' ' || SOYADI) INTO ls_customer_name
        FROM CBS_MUSTERI
        WHERE MUSTERI_NO = ln_customer_no;

        IF (ps_TranCD = 'CARDTRANS') THEN
            ls_tran_name := 'Credit Card Transaction List';
        ELSIF (ps_TranCD = 'CARDPENDG') THEN
            ls_tran_name := 'Credit Card Pending Transactions';
        ELSIF (ps_TranCD = 'CARDLIMIT') THEN
            ls_tran_name := 'Credit Card Next Statement Transaction List';
        ELSIF (ps_TranCD = 'CARDHIST') THEN
            ls_tran_name := 'Credit Card Statement History';
        ELSE
            ls_tran_name := 'Credit Card Transaction List';
        END IF;

        ls_subject := ls_tran_name || ' e-summary';

        ls_content := ls_content || GetCreditCardDekontHeadFoot('HEADER',ps_lang_cd);
        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td style="padding-left:10px;padding-top:5px;font-size:13px;">';
        ls_content := ls_content || '                ' || GetLangLabels('DEALSLIP', 1, 1, ps_lang_cd) ||' <B>' || ls_customer_name ||'</B>,';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '            <td align="right" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                ' || ls_sysdate || '';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';



        ls_content := ls_content || '        <tr style="height:20px;">';
        ls_content := ls_content || '            <td align="right" colspan="2" style="padding-right:15px;font-size:13px;">';
        ls_content := ls_content || '                <B>' || ls_tran_name ||'</B>';
        ls_content := ls_content || '            </td>';
        ls_content := ls_content || '        </tr>';
        ls_content := ls_content || '        <tr>';



        ls_content := ls_content || '            <td colspan="2" aling="center">';
        ls_content := ls_content || '                <table width="590" cellspacing="0" cellpadding="0" border="0" class="OuterDataTable1">';
        ls_content := ls_content || '                    <tr>';
        ls_content := ls_content || '                        <td>';
        ls_content := ls_content || '                            <table width="590" cellspacing="1" cellpadding="0" border="0" class="DataTable1">';

        IF (ps_TranCD = 'CARDTRANS') THEN
            ls_content := ls_content || '       <thead><tr>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 10, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 11, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 12, ps_lang_cd) || '</th>';
            ls_content := ls_content || '       </tr></thead>';
            ls_content := ls_content || '       <tbody>';

            ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            WHILE (LENGTH(ls_list)>0) LOOP
                ln_rownum := ln_rownum + 1;
                IF (MOD(ln_rownum,2) = 0) THEN
                    ls_row_color := 'FCFCFC';
                    ELSE
                    ls_row_color := 'F8F8F8';
                END IF;

                ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 0) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 1) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 2) || '</td>';
                ls_content := ls_content || '</tr>';




                ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            END LOOP;
        ELSIF (ps_TranCD = 'CARDPENDG') THEN
            ls_content := ls_content || '       <thead><tr>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 10, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 13, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 12, ps_lang_cd) || '</th>';
            ls_content := ls_content || '       </tr></thead>';
            ls_content := ls_content || '       <tbody>';

            ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            WHILE (LENGTH(ls_list)>0) LOOP
                ln_rownum := ln_rownum + 1;
                IF (MOD(ln_rownum,2) = 0) THEN
                    ls_row_color := 'FCFCFC';
                    ELSE
                    ls_row_color := 'F8F8F8';
                END IF;

                ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 0) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 1) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 2) || '</td>';
                ls_content := ls_content || '</tr>';

                ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            END LOOP;
        ELSIF (ps_TranCD = 'CARDLIMIT') THEN
            ls_content := ls_content || '       <thead><tr>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 14, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 15, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 16, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 17, ps_lang_cd) || '</th>';
            ls_content := ls_content || '       </tr></thead>';
            ls_content := ls_content || '       <tbody>';

            ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            WHILE (LENGTH(ls_list)>0) LOOP
                ln_rownum := ln_rownum + 1;
                IF (MOD(ln_rownum,2) = 0) THEN
                    ls_row_color := 'FCFCFC';
                    ELSE
                    ls_row_color := 'F8F8F8';
                END IF;

                ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 0) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 1) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 2) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 3) || '</td>';
                ls_content := ls_content || '</tr>';

                ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            END LOOP;
        ELSIF (ps_TranCD = 'CARDHIST') THEN
            ls_content := ls_content || '       <thead><tr>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 18, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 19, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 20, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 21, ps_lang_cd) || '</th>';
            ls_content := ls_content || '       </tr></thead>';
            ls_content := ls_content || '       <tbody>';

            ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            WHILE (LENGTH(ls_list)>0) LOOP
                ln_rownum := ln_rownum + 1;
                IF (MOD(ln_rownum,2) = 0) THEN
                    ls_row_color := 'FCFCFC';
                    ELSE
                    ls_row_color := 'F8F8F8';
                END IF;

                ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 0) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 1) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 2) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 3) || '</td>';
                ls_content := ls_content || '</tr>';

                ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            END LOOP;
        ELSE
            ls_content := ls_content || '       <thead><tr>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 10, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 11, ps_lang_cd) || '</th>';
            ls_content := ls_content || '           <th>' || GetLangLabels('DEALSLIP', 1, 12, ps_lang_cd) || '</th>';
            ls_content := ls_content || '       </tr></thead>';
            ls_content := ls_content || '       <tbody>';

            ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            WHILE (LENGTH(ls_list)>0) LOOP
                ln_rownum := ln_rownum + 1;
                IF (MOD(ln_rownum,2) = 0) THEN
                    ls_row_color := 'FCFCFC';
                    ELSE
                    ls_row_color := 'F8F8F8';
                END IF;

                ls_content := ls_content || '<tr style="background-color:#'|| ls_row_color ||';font-size:13px;">';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 0) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 1) || '</td>';
                ls_content := ls_content || '<td>' || Pkg_Message.SPLIT(ls_list, '***', 2) || '</td>';
                ls_content := ls_content || '</tr>';

                ls_list := Pkg_Message.SPLIT(ps_Data, '###', ln_rownum);
            END LOOP;
        END IF;

        ls_content := ls_content || GetCreditCardDekontHeadFoot('FOOTER',ps_lang_cd);

        IF  ps_channel_cd='cDKBRIB' THEN
            Pkg_Email.AddToEmailQueue('CCDEALSLIP', 51, ps_From, ps_To, ls_subject, ls_content,'HTML');
        ELSIF ps_channel_cd='cDKBCIB' THEN
            Pkg_Email.AddToEmailQueue('CCDEALSLIP', 51, ps_From, ps_To, ls_subject, ls_content,'HTML');
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
        Log_At('SendCreditCardTranList',SQLERRM);
    END;
------------------------------------------------------------------------------------------
FUNCTION GetLangLabels(ps_tran_cd IN VARCHAR2,
                       pn_page_id IN NUMBER,
                       pn_label_id IN NUMBER,
                       ps_lang_cd IN VARCHAR2) RETURN VARCHAR2 IS
    ls_label VARCHAR2(2000);
BEGIN
    SELECT EXPLANATION INTO ls_label
    FROM corpint.tbl_lang_labels
    WHERE TRAN_CD=ps_tran_cd
    AND PAGE_ID=pn_page_id
    AND LABEL_ID=pn_label_id
    AND LANG_CD=ps_lang_cd;

    RETURN ls_label;
EXCEPTION
    WHEN OTHERS THEN
        RETURN 'NO LABEL';
END;
------------------------------------------------------------------------------------------
FUNCTION GetCreditCardDekontHeadFoot(ps_Option IN VARCHAR2, ps_lang_cd IN VARCHAR2) RETURN CLOB IS
    ls_content CLOB := '';
    BEGIN
        IF (ps_Option = 'HEADER') THEN

            ls_content := ls_content || '<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:p="urn:schemas-microsoft-com:office:powerpoint" xmlns:a="urn:schemas-microsoft-com:office:access" xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882" xmlns:s="uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882" xmlns:rs="urn:schemas-microsoft-com:rowset" xmlns:z="#RowsetSchema" xmlns:b="urn:schemas-microsoft-com:office:publisher" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:c="urn:schemas-microsoft-com:office:component:spreadsheet" xmlns:odc="urn:schemas-microsoft-com:office:odc" xmlns:oa="urn:schemas-microsoft-com:office:activation" xmlns:html="http://www.w3.org/TR/REC-html40" xmlns:q="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rtc="http://microsoft.com/officenet/conferencing" xmlns:D="DAV:" xmlns:Repl="http://schemas.microsoft.com/repl/" xmlns:mt="http://schemas.microsoft.com/sharepoint/soap/meetings/" xmlns:x2="http://schemas.microsoft.com/office/excel/2003/xml" xmlns:ppda="http://www.passport.com/NameSpace.xsd" xmlns:ois="http://schemas.microsoft.com/sharepoint/soap/ois/" xmlns:dir="http://schemas.microsoft.com/sharepoint/soap/directory/" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:dsp="http://schemas.microsoft.com/sharepoint/dsp" xmlns:udc="http://schemas.microsoft.com/data/udc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:sub="http://schemas.microsoft.com/sharepoint/soap/2002/1/alerts/" xmlns:ec="http://www.w3.org/2001/04/xmlenc#" xmlns:sp="http://schemas.microsoft.com/sharepoint/" xmlns:sps="http://schemas.microsoft.com/sharepoint/soap/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:udcs="http://schemas.microsoft.com/data/udc/soap" xmlns:udcxf="http://schemas.microsoft.com/data/udc/xmlfile" xmlns:udcp2p="http://schemas.microsoft.com/data/udc/parttopart" xmlns:wf="http://schemas.microsoft.com/sharepoint/soap/workflow/" xmlns:dsss="http://schemas.microsoft.com/office/2006/digsig-setup" xmlns:dssi="http://schemas.microsoft.com/office/2006/digsig" xmlns:mdssi="http://schemas.openxmlformats.org/package/2006/digital-signature" xmlns:mver="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns:mrels="http://schemas.openxmlformats.org/package/2006/relationships" xmlns:spwp="http://microsoft.com/sharepoint/webpartpages" xmlns:ex12t="http://schemas.microsoft.com/exchange/services/2006/types" xmlns:ex12m="http://schemas.microsoft.com/exchange/services/2006/messages" xmlns:pptsl="http://schemas.microsoft.com/sharepoint/soap/SlideLibrary/" xmlns:spsl="http://microsoft.com/webservices/SharePointPortalServer/PublishedLinksService" xmlns:Z="urn:schemas-microsoft-com:" xmlns:st="&#1;" xmlns="http://www.w3.org/TR/REC-html40"><head>';
            ls_content := ls_content || '<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">';
            ls_content := ls_content || '<meta name="Generator" content="Microsoft Word 12 (filtered medium)">';
            ls_content := ls_content || '<head>';
            ls_content := ls_content || '    <title>Demir Kyrgyz International Bank</title>';
            ls_content := ls_content || '    <style type="text/css">';
            ls_content := ls_content || '        body {';
            ls_content := ls_content || '            font-family:"Tahoma";';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '        .DataTable1 {';
            ls_content := ls_content || '            padding-left:15px ;';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '        .DataTable1 tr {';
            ls_content := ls_content || '            height:27px;';
            ls_content := ls_content || '            color:#484848;';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '        .OuterDataTable1 {';
            ls_content := ls_content || '            background-color:#E5E5E5;';
            ls_content := ls_content || '            color:#733838;';
            ls_content := ls_content || '            font-size:9px;';
            ls_content := ls_content || '            margin-top:10px;';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '        .WarnMsg1 {';
            ls_content := ls_content || '            padding-left:10px;';
            ls_content := ls_content || '            padding-right:90px;';
            ls_content := ls_content || '            padding-top:15px;';
            ls_content := ls_content || '            padding-bottom:10px;';
            ls_content := ls_content || '            font-size:9px;';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '        .tableHeader_style1 {';
            ls_content := ls_content || '            font-family: Tahoma;';
            ls_content := ls_content || '            font-size: 11px;';
            ls_content := ls_content || '            font-weight: bold;';
            ls_content := ls_content || '            background-color: #828282;';
            ls_content := ls_content || '            height: 34px;';
            ls_content := ls_content || '            color: #FFFFFF;';
            ls_content := ls_content || '            text-align: center;';
            ls_content := ls_content || '        }';
            ls_content := ls_content || '    </style>';
            ls_content := ls_content || '</head>';
            ls_content := ls_content || '<body>';
            ls_content := ls_content || '    <table border="0" cellpadding="0" cellspacing="0" width="600">';
            ls_content := ls_content || '        <tr>';
            ls_content := ls_content || '            <td colspan="2">';
            ls_content := ls_content || '                <img src="http://www.demirbank.kg/files/DSHeader.png">';
            ls_content := ls_content || '            </td>';
            ls_content := ls_content || '        </tr>';

        ELSIF (ps_Option = 'FOOTER') THEN

            ls_content := ls_content || '                               </tbody>';
            ls_content := ls_content || '                            </table>';
            ls_content := ls_content || '                        </td>';
            ls_content := ls_content || '                    </tr>';
            ls_content := ls_content || '                </table>';
            ls_content := ls_content || '            </td>';
            ls_content := ls_content || '        </tr>';
            ls_content := ls_content || '        <tr>';
            ls_content := ls_content || '            <td colspan="2" class="WarnMsg1">';
            ls_content := ls_content || '                ' || GetLangLabels('DEALSLIP', 1, 22, ps_lang_cd) ||'';
            ls_content := ls_content || '            </td>';
            ls_content := ls_content || '        </tr>';
            ls_content := ls_content || '        <tr>';
            ls_content := ls_content || '            <td colspan="2">';
            ls_content := ls_content || '                <img src="http://www.demirbank.kg/files/DSFooter.png">';
            ls_content := ls_content || '            </td>';
            ls_content := ls_content || '        </tr>';
            ls_content := ls_content || '    </table>';
            ls_content := ls_content || '</body>';
            ls_content := ls_content || '</html>';

        END IF;

        RETURN ls_content;

    EXCEPTION
        WHEN OTHERS THEN
        Log_At('SendCreditCardTranList',SQLERRM);
    END;
------------------------------------------------------------------------------------------
END;
/

