create PACKAGE body     pkg_report_21 AS
--------------------------------------------------------------------------------
function getregionname(pn_region_no in number) return varchar2
is
    ls_region_name      cbs_kg_regions.region_name%type;
begin
        select region_name
        into   ls_region_name
        from   cbs_kg_regions
        where  no =pn_region_no  ;

    return ls_region_name ;

Exception
   when others then return null;   
end;
--------------------------------------------------------------------------------
function getRegionNoFromBic(pn_bic in number) return varchar2 
is
    ls_return varchar2(200 char);
begin

    select region_no
      into ls_return
      from cbs_kg_regions a,
           (select bic_code, region_no from cbs_dkb_info
            union all
            select to_char (banka_kodu), region_no from cbs_banka_kodlari) b
     where a.no = b.region_no and b.bic_code = pn_bic;
           
    return ls_return;  
Exception 
    when others then
        return null;
end;
--------------------------------------------------------------------------------
function getRegionNoFromBranch(ps_sube_kodu varchar2) return number 
is
    ln_region_no number;
begin

      select region_no
      into ln_region_no
      from cbs_bolum
      where kodu =ps_sube_kodu;
           
    return ln_region_no;  
  Exception 
    when others then return null;
        
end;
--------------------------------------------------------------------------------
function nbrk_hesap_mi(ps_external_account_no varchar2 ) return varchar2
is
ln_Adet number := 0;
Begin
    select count(*)
    into ln_Adet 
    from cbs_nbrk_hesap
    where external_account_no =ps_external_account_no;
    
    if nvl(ln_Adet,0) <> 0 then 
        return 'E';
     else
        return 'H';
    end if;
 
 Exception 
    when others then return 'H';
End;
--------------------------------------------------------------------------------
function is_budgetary(ps_payment_code varchar2,ps_external_account_no varchar2 ) return varchar2
is
ln_Adet number := 0;
Begin
  if substr(ps_payment_code,1,1) = '1' and  pkg_report_21.nbrk_hesap_mi(ps_external_account_no) = 'E' then 
     return 'E';
  else
    return 'H';
  end if;     
 exception 
    when others then return 'H';
End;
--------------------------------------------------------------------------------
procedure load_21A(pd_start_date in date, pd_end_date in date ,ps_sube_kodu varchar2,pn_log_no out number) 
is pragma autonomous_transaction;
    ln_max_txno number;
    ln_min_txno number;
    ln_log_no number;
begin
     pn_log_no := pkg_genel.genel_kod_al('REPORT_21A_LOG_NO');
     select min(b.numara), max(b.numara)
     into  ln_min_txno, ln_max_txno
     from  cbs_islem b
     where b.kayit_tarih between pd_start_date and pd_end_date and
           b.durum in ( 'P','3') and
           b.islem_kod in ( 1203,6200,6201); 
                  
    insert into cbs_report_21a(log_no,
                            order_no,
                            region,
                            branch,
                            budget_payments_count,
                            budget_payments_amount,
                            other_payments_count,
                            other_payments_amount,
                            other_payments_fc_count,
                            other_payments_amount_fc_count)
    select pn_log_no,
           pkg_report_21.getRegionNoFromBranch(sube_kodu), --region_no
           pkg_report_21.getregionname(getRegionNoFromBranch(sube_kodu)), --region_name
           sube_kodu,   --branch
           0,   --budget_payments_tx
           0,   --budget_payments_amount
           sum(count_tx), --other_payments_tx
           round(sum(amount)/1000,2),     --other_payments_amount
           0,       --other_payments_amount
           0        --other_payments_amount_fc
    from (
        --1203
          select pkg_hesap.hesaptansubeal(a.borc_hesap_no) sube_kodu, count(*) count_tx, sum(a.tutar) amount
          from cbs_virman_islem a ,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.islem_kod = 1203 and
               pkg_hesap.hesaptansubeal(a.borc_hesap_no)=nvl(ps_sube_kodu, pkg_hesap.hesaptansubeal(a.borc_hesap_no)) and  
               b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and
               a.doviz_kodu = pkg_genel.lc_al and
               a.alacak_hesap_no is not null and  a.borc_hesap_no is not null and 
               pkg_hesap.hesaptansubeal(a.borc_hesap_no)  = pkg_hesap.hesaptansubeal(a.alacak_hesap_no) and
               pkg_hesap.hesaptansubeal(a.borc_hesap_no) =nvl(ps_sube_kodu,pkg_hesap.hesaptansubeal(a.borc_hesap_no)) and   --sevalb 07032013  with test result added
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.borc_hesap_no)) <>  '4' and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.alacak_hesap_no))  <>  '4'
               
         group by pkg_hesap.hesaptansubeal(a.borc_hesap_no)
        union all
        --6200
        select pkg_hesap.hesapsubeal(a.hesap_no) sube_kodu, count(*) count_tx,  sum(a.tutar) amount
          from cbs_cari_nakit_yatan_islem a ,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.amir_bolum_kodu= nvl(ps_sube_kodu,b.amir_bolum_kodu) and
               b.islem_kod = 6200 and  b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and         
               doviz_kodu = pkg_genel.lc_al and
               islem_sekli = 'ML' and
               b.amir_bolum_kodu= pkg_hesap.hesaptansubeal(a.hesap_no) and
               a.hesap_no is not null and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.hesap_no)) <>  '4'                 
         group by pkg_hesap.hesapsubeal(hesap_no)
        union all
        --6201
        select a.sube_kodu, count(*) count_tx, sum(a.tutar) amount
          from cbs_cari_nakit_cekilen_islem a,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.amir_bolum_kodu= nvl(ps_sube_kodu,b.amir_bolum_kodu) and
               b.islem_kod = 6201 and  b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and 
               doviz_kodu = pkg_genel.lc_al and
               islem_sekli = 'CL' and
               a.hesap_no is not null and
               b.amir_bolum_kodu =  a.sube_kodu and  --sevalb 13032013 -- b.amir_bolum_kodu= pkg_hesap.hesaptansubeal(a.hesap_no) and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.hesap_no)) <>  '4'                         
         group by a.sube_kodu )        
    group by sube_kodu;

/*    insert into cbs_report_21a (log_no,order_no, region,branch)
    select pn_log_no,no, region_name ,b.kodu 
    from cbs_kg_regions a,cbs_bolum  b
    where a.no = b.region_no and  
          b.eft_kodu is not null and
          b.kapanis_tarihi is  null and
          not exists (select  1 from  cbs_report_21a where log_no = pn_log_no and order_no  = b.region_no and branch = b.kodu);  
  */ 
 commit;  
exception
    when others then
        log_at('pkg_report_21.load_21A', sqlerrm);
        rollback;
            
end;
--------------------------------------------------------------------------------
procedure load_21B(pd_start_date in date, pd_end_date in date ,ps_sube_kodu varchar2,pn_log_no out number) 
is pragma autonomous_transaction;
    ln_max_txno number;
    ln_min_txno number;
    ln_log_no number;
begin
    
     pn_log_no := PKG_GENEL.GENEL_KOD_AL('REPORT_21B_LOG_NO');
     select min(b.numara), max(b.numara)
     into  ln_min_txno, ln_max_txno
     from  cbs_islem b
     where b.kayit_tarih between pd_start_date and pd_end_date and
           b.durum in ( 'P','3') and
           b.islem_kod in ( 1203,6200,6201,4310);       
    insert into cbs_report_21B(log_no,
                            from_region_no,
                            from_branch_code,
                            to_region_no,
                            to_branch_code,   
                            budget_payments_count,
                            budget_payments_amount,
                            other_payments_count,
                            other_payments_amount,
                            other_payments_fc_count,
                            other_payments_amount_fc_count)
    select pn_log_no,
           pkg_report_21.getRegionNoFromBranch(from_branch_code), --region_no
           from_branch_code,   --branch
           pkg_report_21.getRegionNoFromBranch(to_branch_code), --region_no
           to_branch_code,   --branch           
           0,   --budget_payments_tx
           0,   --budget_payments_amount
           sum(count_tx), --other_payments_tx
           round(sum(amount)/1000,2),     --other_payments_amount
           0,       --other_payments_amount
           0        --other_payments_amount_fc
  from (
        --1203
          select pkg_hesap.hesaptansubeal(a.borc_hesap_no) from_branch_code,
                 pkg_hesap.hesaptansubeal(a.alacak_hesap_no) to_branch_code,
                 count(*) count_tx, sum(a.tutar) amount
          from cbs_virman_islem a ,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.islem_kod = 1203 and
               b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and
               a.doviz_kodu = pkg_genel.lc_al and
               a.alacak_hesap_no is not null and  a.borc_hesap_no is not null and 
               pkg_hesap.hesaptansubeal(a.borc_hesap_no)  <> pkg_hesap.hesaptansubeal(a.alacak_hesap_no) and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.borc_hesap_no)) <>  '4' and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.alacak_hesap_no))  <>  '4' and
               ( (ps_sube_kodu is not null and ( ps_sube_kodu = pkg_hesap.hesaptansubeal(a.alacak_hesap_no) or ps_sube_kodu = pkg_hesap.hesaptansubeal(a.borc_hesap_no) ) )
                or
               ( ps_sube_kodu is  null ))
         group by pkg_hesap.hesaptansubeal(a.borc_hesap_no),pkg_hesap.hesaptansubeal(a.alacak_hesap_no)
         --4310 
        union all
           select k.bolum_kodu from_branch_code,
                 k.alici_sube to_branch_code,
                 count(*) count_tx, sum(K.tutar) amount
          from cbs_subelerarasi_hav_odeme a ,cbs_islem b ,cbs_subelerarasi_hav_gir k
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and a.referans = k.referans and  islem_sekli = 'PAYMENT' and
               b.islem_kod = 4310 and
               b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and
               k.doviz_kodu = pkg_genel.lc_al and k.bolum_kodu is not null and k.alici_sube is not null and
               k.bolum_kodu  <> k.alici_sube and
               decode( odenecek_musteri_no, null,1,pkg_musteri.sf_musteri_tipi_al(odenecek_musteri_no)) <>  '4' and
               decode( alici_musteri_no, null,1,pkg_musteri.sf_musteri_tipi_al(alici_musteri_no))   <>  '4' and
               ( (ps_sube_kodu is not null and ( ps_sube_kodu =  k.bolum_kodu or ps_sube_kodu = k.alici_sube) )
                or
               ( ps_sube_kodu is  null ))
         group by k.bolum_kodu, k.alici_sube
        union all
        --6200
        select  b.amir_bolum_kodu from_branch_code,
                pkg_hesap.hesapsubeal(a.hesap_no) to_branch_code, 
               count(*) count_tx, sum(a.tutar) amount
          from cbs_cari_nakit_yatan_islem a ,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.islem_kod = 6200 and  b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and         
               doviz_kodu = pkg_genel.lc_al and
               islem_sekli = 'ML' and
               b.amir_bolum_kodu <> pkg_hesap.hesaptansubeal(a.hesap_no) and
               a.hesap_no is not null and  
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.hesap_no)) <>  '4' and
                ( (ps_sube_kodu is not null and ( ps_sube_kodu = b.amir_bolum_kodu or ps_sube_kodu = pkg_hesap.hesaptansubeal(a.hesap_no)) )
                or
               ( ps_sube_kodu is  null ))
                                
         group by b.amir_bolum_kodu,pkg_hesap.hesapsubeal(hesap_no)
        union all
        --6201
        select a.sube_kodu from_branch_code, --sevalb 13032013 --pkg_hesap.hesaptansubeal(a.hesap_no) from_branch_code ,
               b.amir_bolum_kodu to_branch_code,  
               count(*) count_tx, sum(a.tutar) amount
          from cbs_cari_nakit_cekilen_islem a,cbs_islem b
         where a.tx_no  =b.numara and b.durum in ( 'P','3') and 
               b.islem_kod = 6201 and  b.kayit_tarih between pd_start_date and pd_end_date and
               a.tx_no between  ln_min_txno and ln_max_txno and
               b.numara between  ln_min_txno and ln_max_txno and 
               doviz_kodu = pkg_genel.lc_al and
               islem_sekli = 'CL' and
               b.amir_bolum_kodu <>  a.sube_kodu and --sevalb 13032013 --b.amir_bolum_kodu <> pkg_hesap.hesaptansubeal(a.hesap_no) and
               a.hesap_no is not null and
               pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.hesap_no)) <>  '4' and
               ( (ps_sube_kodu is not null and ( ps_sube_kodu = b.amir_bolum_kodu or ps_sube_kodu = a.sube_kodu) )
                or
               ( ps_sube_kodu is  null ))
         group by  a.sube_kodu, b.amir_bolum_kodu)         
    group by from_branch_code,to_branch_code;

  /*  insert into cbs_report_21b (log_no,order_no, region,branch)
    select pn_log_no,no, region_name ,b.ko  du 
    from cbs_kg_regions a,cbs_bolum  b
    where a.no = b.region_no and  
          b.eft_kodu is  not null and
          b.kapanis_tarihi is  null and
          not exists (select  1 from  cbs_report_21B where log_no = pn_log_no and order_no  = b.region_no and branch = b.kodu);  
   */
 commit;  
exception
    when others then
        log_at('pkg_report_21.load_21B', sqlerrm);
        rollback;
            
end;
--------------------------------------------------------------------------------
procedure load_21C(pd_start_date in date, pd_end_date in date ,ps_sube_kodu varchar2,pn_log_no out number) 
is pragma autonomous_transaction;
    ln_max_txno number;
    ln_min_txno number;
    ln_log_no number;
begin
    
     pn_log_no := pkg_genel.genel_kod_al('REPORT_21C_LOG_NO');
                  
    insert into cbs_report_21C(log_no,
                            from_region_no,
                            to_region_no,
                            budget_payments_count,
                            budget_payments_amount,
                            other_payments_count,
                            other_payments_amount
                           )
       select   pn_log_no,
                pkg_report_21.getregionnofrombranch( pkg_hesap.hesapsubeal(a.from_account)), --from_region_no
                pkg_report_21.getregionnofrombic(to_bank_bic) to_region,
                sum(decode(pkg_report_21.is_budgetary(code_of_payment,to_account_external_number),'E',1,0)) budgetary_count,
                ROUND(sum(decode(pkg_report_21.is_budgetary(code_of_payment,to_account_external_number),'E',nvl(a.amount,0),0))/1000,2) budgetary_amount,
                sum(decode(pkg_report_21.is_budgetary(code_of_payment,to_account_external_number),'E',0,1)) other_count,
                ROUND(sum(decode(pkg_report_21.is_budgetary(code_of_payment,to_account_external_number),'E',0,nvl(a.amount,0)))/1000,2) other_amount
       from cbs_clearing a
         where urun_tur_kod = 'OUTGOING'
           and msg_status <> 'sCANCEL'
           and maturity_date between pd_start_date and pd_end_date
           and a.bolum_kodu= nvl(ps_sube_kodu,a.bolum_kodu) 
           and a.from_account is not null 
           and  pkg_musteri.sf_musteri_tipi_al(pkg_hesap.hesaptanmusterinoal(a.from_account)) <>  '4'
       group by  pn_log_no,
                 pkg_report_21.getregionnofrombranch( pkg_hesap.hesapsubeal(a.from_account)),
                 pkg_report_21.getregionnofrombic(to_bank_bic);

  /*  insert into cbs_report_21C (log_no,order_no, region,branch)
    select pn_log_no,no, region_name ,b.kodu 
    from cbs_kg_regions a,cbs_bolum  b
    where a.no = b.region_no and  
          b.eft_kodu is  not null and
          b.kapanis_tarihi is  null and
          not exists (select  1 from  cbs_report_21C where log_no = pn_log_no and order_no  = b.region_no and branch = b.kodu);  
   */
 commit;  
exception
    when others then
        log_at('pkg_report_21.load_21C', sqlerrm);
        rollback;
            
end;
--------------------------------------------------------------------------------
END pkg_report_21;
/

