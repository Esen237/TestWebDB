create Package PKG_TEMINAT is

/******************************************************************************
   NAME       : PKG_TEMINAT
   Created By : Seval Balci
   Date    	  : 31.10.03
   Purpose	  : Teminat procedure ve fonksiyonlarini icerir.
******************************************************************************/
  Function sf_teminattutar_hesdovizcevir( pn_kullanilan_teminat_tutari cbs_teminat.KULLANILAN_TUTAR%type,
    		   						 ps_teminat_doviz_kodu   cbs_teminat.TEMINAT_DOVIZ_KODU%type,
									 ps_kredi_doviz_kodu     cbs_teminat.TEMINAT_DOVIZ_KODU%type,
									 ps_hesabin_dovizine	 varchar2 default null)
									 return  cbs_teminat.KULLANILAN_TUTAR%type;

  Function sf_teklif_teminat_tutari( pn_teklif_tutar cbs_kredi_teklif_satir_teminat.TUTAR%type,
      		   						 ps_teminat_doviz_kodu   cbs_teminat.TEMINAT_DOVIZ_KODU%type,
  		   							 pn_hesap_tutar	 		 cbs_hesap_kredi.TUTAR%type,
									 ps_hesap_doviz_kodu     cbs_hesap_kredi.doviz_kodu%type,
									 pn_marj				 cbs_kredi_teklif_satir_teminat.MARJ%type,
									 pn_katilim_orani    	 cbs_kredi_teklif_satir_teminat.KATILIM_ORANI%type,
									 ps_teklif_tutari_ise	 varchar2 default null)
									 return  number;

   PROCEDURE teklif_kosullari_karsilandimi (
   			 pn_islem_no	 			     number ,
   			 pn_kredi_teklif_satir_numara    number,
			 pn_kredi_hesap_tutar number,
             ps_kredi_hesap_doviz_kodu varchar2,
			 ps_karsilandimi out varchar2  ,
			 ps_mesaj		 out varchar2,
			 ps_kredi_endeksdoviz varchar2 default null);
  Function sf_teminat_nakdi_hesap_urunmu(ps_doviz_kodu cbs_doviz_kodlari.doviz_kodu%type,ps_urun_Tur varchar2,ps_urun_sinif varchar2) return varchar2;
  Function sf_teminat_hesap_uygunmu(pn_hesap_no cbs_hesap.hesap_no%type) return varchar2;
  Procedure Sp_Teminat_Ana_Tabloya_Aktar(pn_tx_no cbs_teminat_islem.tx_no%type);
  Function sf_teminat_kullanilan_tutar_al(pn_teminat_no cbs_teminat.teminat_no%type) return number;

  Function sf_teminat_islemde_varmi(pn_tx_no            cbs_teminat_islem.tx_no%type,
  								    pn_teminat_no       cbs_teminat.teminat_no%type) return varchar2;

  Procedure sp_teminat_isleme_at( pn_tx_no                    cbs_teminat_islem.tx_no%type,
  								 pn_teminat_no         		  cbs_teminat.teminat_no%type,
								 pn_musteri_no         		  cbs_teminat.musteri_no%type,
								 pn_cek_no	           		  cbs_teminat.cek_no%type,
 								 pn_senet_no	       		  cbs_teminat.senet_no%type ,
								 ps_teminat_turu       		  cbs_teminat.teminat_turu%type,
								 ps_teminat_kodu       		  cbs_teminat.teminat_kodu%type,
								 ps_teminat_alt_kodu   		  cbs_teminat.teminat_alt_kodu%type,
								 pn_teminat_tutari     		  cbs_teminat.teminat_tutari%type,
								 pn_kullanilan_tutar   		  cbs_teminat.kullanilan_tutar%type,
								 pn_banka_kodu		   		  cbs_takas_cek.banka_kodu%type,
								 ps_sube_kodu		   		  cbs_takas_cek.sube_kodu%type,
								 pn_ref_cek_no		   		  cbs_teminat.ref_cek_no%type,
								 ps_bolum_kodu		   		  cbs_teminat.bolum_kodu%type,
								 pn_teminat_hesap_no		  cbs_teminat.teminat_hesap_no%type,
								 ps_teminat_hesap_doviz		  cbs_teminat.teminat_hesap_doviz%type,
								 ps_aciklama			   	  cbs_teminat.aciklama%type,
								 ps_teminat_doviz_kodu        cbs_teminat.teminat_doviz_kodu%type,
								 ps_teminat_durumu            cbs_teminat.teminat_durumu%type,
								 pn_teklif_musteri_no		  cbs_teminat.teklif_musteri_no%type,
								 pn_kredi_teminat_tanim_sira_no  cbs_teminat.kredi_teminat_tanim_sira_no%type,
								 ps_hesap_urun_sinif	   	  cbs_teminat.hesap_urun_sinif%type,
								 ps_hesap_urun_tur_kod	   	  cbs_teminat.hesap_urun_tur_kod%type,
								 ps_hesap_modul_tur_kod   	  cbs_teminat.hesap_modul_tur_kod%type,
								 ps_borclu_teminat_hesap_no		  cbs_teminat.borclu_teminat_hesap_no%type,
								 ps_borclu_teminat_hesap_doviz 	  cbs_teminat.borclu_teminat_hesap_doviz%type,
								 ps_bloke_hesap_secimi		  cbs_teminat.bloke_hesap_secimi%type,
								 ps_nakdi_gayri_secimi		  cbs_teminat.nakdi_gayri_secimi%type default 'GAYRI',
								 PS_Referans				  cbs_teminat.REFERANS%type,
								 pn_kredi_teklif_satir_no	  cbs_teminat.kredi_teklif_satir_no%type,
								 pd_teminat_alis_tarihi     date default pkg_muhasebe.banka_tarihi_bul);

 Procedure Sp_Kredi_Teminat_Bloke_Yarat(pn_tx_no 	   cbs_teminat_islem.tx_no%type ,
 		   								pn_teminat_no cbs_teminat_islem.teminat_no%type );

 Function Sp_Kredi_Teminat_Vadesiz_Ac(pn_tx_no 	   cbs_teminat_islem.tx_no%type ,
 		   								pn_teminat_no cbs_teminat_islem.teminat_no%type ) return cbs_hesap.hesap_no%type;
 Function Sf_cek_tahsil_teminat_al(pn_ref_cek_no 	   cbs_takas_cek.ref_cek_no%type) return  cbs_takas_cek.TAHSIL_TEMINAT%type;
 FUNCTION sf_senet_tahsil_teminat_al (ps_bolum_kodu   cbs_teminat_islem.bolum_kodu%TYPE  default null,
 								      pn_senet_no     cbs_teminat_islem.senet_no%TYPE  default null  ) RETURN cbs_senet.urun_tur_kod%TYPE;

 Function sf_diger_gayri_nakdi_mi( ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return varchar2;
 Function sf_diger_gayrinakdi_doviz_al( pn_musteri_no cbs_kredi_teminat_tanim.musteri_no%type, pn_teminat_sira_no cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type ) return cbs_doviz_kodlari.doviz_kodu%type;
 Function sf_diger_gayrinakdi_tutar_al( pn_musteri_no cbs_kredi_teminat_tanim.musteri_no%type, pn_teminat_sira_no cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type ) return number;
 Function sf_teminat_turu_al(ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return cbs_teminat_kodlari.teminat_turu%type;
 Procedure sp_krediteminatlari_isleme_at(pn_tx_no cbs_teminat_islem.tx_no%type ,
 		   								 pn_hesap_no cbs_teminat.teminat_hesap_no%type,
 		   								 pn_musteri_no cbs_teminat.teklif_musteri_no%type default null);
 Function  sf_ihracat_dosya_tutari_al(ps_referans cbs_teminat_islem.referans%type) return number;
 Function  sf_alingaran_dosya_tutari_al(ps_referans cbs_teminat_islem.referans%type) return number;
 Procedure sp_teminatislem_hesapno_guncel(pn_islem_no number ,pn_hesap_no number ,ps_doviz_kodu varchar2);


/* KULLANILAN TUTARLAR */

 Function sf_cekin_kullanilan_tutari(  pn_ref_cek_no cbs_takas_cek.ref_cek_no%type ,
  		   							   pn_islem_no  cbs_teminat_islem.tx_no%type default null,
  		   							   ps_onaylimi varchar2 default 'H'  ) return number;
 FUNCTION sf_senet_kullanilan_tutari (
										      ps_bolum_kodu   cbs_teminat_islem.bolum_kodu%TYPE,
										      pn_senet_no     cbs_teminat_islem.senet_no%TYPE,
										      pn_islem_no     cbs_teminat_islem.tx_no%TYPE DEFAULT NULL,
											  ps_onaylimi varchar2 default 'H'  )  return number;

 Function sf_ihracat_kullanilan_tutari( ps_referans cbs_teminat_islem.referans%type ,
 		  							    pn_islem_no  cbs_teminat_islem.tx_no%type default null,
   		   							    ps_onaylimi varchar2 default 'H'  )  return number;
 Function sf_alingaran_kullanilan_tutari(ps_referans cbs_teminat_islem.referans%type ,
 		  								 pn_islem_no  cbs_teminat_islem.tx_no%type default null,
										 ps_onaylimi varchar2 default 'H'  )  return number;
 Function sf_diger_gayrin_kullan_tutari( pn_musteri_no cbs_kredi_teminat_tanim.musteri_no%type,
 		  								 pn_teminat_sira_no cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type,
 		  								 pn_islem_no  cbs_teminat_islem.tx_no%type default null,
										 ps_onaylimi varchar2 default 'H'     ) return number ;

 Function  sf_ihracat_durumu_al(ps_referans cbs_teminat_islem.referans%type) return VARCHAR2;
 Function  sf_alinangaranti_durumu_al(ps_referans cbs_teminat_islem.referans%type) return VARCHAR2;
 Procedure sp_teminat_onaya_uygunmu(pn_islem_no number ) ;
 Function  sf_Hesap_Durum_Al(pn_hesap_no	IN cbs_vw_hesap_izleme.HESAP_NO%TYPE) return varchar2;
 Function sf_diger_gayrinakdi_durum_al ( pn_musteri_no        cbs_kredi_teminat_tanim.musteri_no%type,
     	  							     pn_teminat_sira_no   cbs_kredi_teminat_tanim.teminat_sira_no%type) return varchar2;


 Procedure sp_teminat_ceksenetteminat_yap(pn_islem_no number);
 Procedure sp_teminat_blokekoy_hesap_ac(pn_islem_no number );
 procedure sp_teminat_gayrinakdikayitkont(pn_islem_no number);
/* procedure  sp_teklifno_teminatguncelle(  pn_eski_teklif_no cbs_teminat.teminat_hesap_no%type,
 										  pn_yeni_teklif_no cbs_teminat.kredi_teklif_no%type);
*/
 procedure sp_teminat_islem_durumguncelle(pn_islem_no number ,ps_durum cbs_teminat_islem.teminat_durumu%type default 'ACIK');
 procedure sp_teminat_durumguncelle(pn_islem_no number ,ps_durum cbs_teminat_islem.teminat_durumu%type default 'ACIK');
 Function  sf_ihracatta_teminatmi(ps_ref varchar2) return varchar2;
 Procedure sp_teminat_ceksenettahsil_yap(pn_islem_no number);
 procedure sp_teminat_nakdihesap_muhasebe(pn_islem_no number,pn_fis_no in  number,ps_islem_tipi varchar2 default 'ACILIS');
 procedure sp_teminat_senet_muhasebe(pn_islem_no number,pn_fis_no in  number);
 Function  sf_teminat_durumu_uygunmu(ps_teminat_kodu cbs_teminat.teminat_kodu%type,
 		   							ps_referans      cbs_teminat_islem.REFERANS%type default null,
									pn_ref_cek_no    cbs_teminat.ref_cek_no%type  default null,
									ps_bolum_kodu    cbs_teminat_islem.bolum_kodu%TYPE  default null,
									pn_senet_no      cbs_teminat_islem.senet_no%TYPE  default null,
									pn_musteri_no 	 cbs_kredi_teminat_tanim.musteri_no%type  default null,
  								    pn_teminat_sira_no cbs_kredi_teminat_tanim.TEMINAT_SIRA_NO%type  default null,
									pn_hesap_no       cbs_hesap.hesap_no%type  default null,
									pn_sozlesme_no	  cbs_sozlesme.sozlesme_no%type default null,
									pn_ek_sozlesme_no cbs_sozlesme.ek_sozlesme_no%type default null) return VARCHAR2;
Function  Sf_Teminat_Alt_Kod_Aciklamasi(ps_teminat_kodu cbs_teminat_alt_kodlari.teminat_kodu%type, ps_teminat_alt_kodu cbs_teminat_alt_kodlari.teminat_alt_kodu%type) return cbs_teminat_alt_kodlari.aciklama%type;
Function  Sf_Teminat_Kod_Aciklamasi(ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return cbs_teminat_kodlari.aciklama%type;
/* teminat hepsi proc & fonk. cbs_vw_teminat_hepsi view'si icin haz?rlandi*/
Procedure sp_teminat_hepsi_referans_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type,
									  ps_durum out varchar2 ,
									  ps_referans  out varchar2,
									  pn_teminat_tutari	out number,
  									  pn_bakiye out number);

 Function sf_teminat_hepsi_referdurum_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return varchar2;

 Function sf_teminat_hepsi_referans_al(pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return varchar2;
 Procedure sp_teminat_bloke_iptal(pn_islem_no number,ps_islem_tipi varchar2 default 'ACILIS');
 Procedure sp_onayoncesi_teminat_at(pn_islem_no number );
 Procedure sp_nakdihesapblokekoyac(pn_islem_no number ,pn_islem number);
 procedure sp_iptalonaysonrasi_teminat_at(pn_islem_no number,ps_islem_tipi varchar2 default 'ACILIS');

 Function Sf_BitmemisteminatIslemVarMi( pn_musteri_no cbs_musteri.musteri_no%type,
 		  								pn_islem_no cbs_islem.numara%type,
										pn_hesap_no  cbs_hesap_kredi.hesap_no%type) return number;

 Procedure sp_ciftkayitkontrolu(pn_islem_no number);
 Function sf_teminat_gunceltutari_al (pn_tx_no number, pn_teminat_no  number,
		 							  ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return number;
 Function sf_teminat_bakiye_al (pn_tx_no number, pn_teminat_no  number,
		 							   ps_teminat_kodu	cbs_teminat.teminat_kodu%type) return number;

 Procedure sp_teminattutarguncelle(pn_tx_no number);
/* Teminat i?lemlerinde kullan?lacak genel procedurler */
 Procedure sp_teminat_kontrolsonra(pn_islem_no number ,
		  	pn_kredi_teklif_satir_numara      number default 0,
		    pn_kredi_hesap_tutar 			  number default 0,
		    ps_kredi_hesap_doviz_kodu 		  varchar2  default null ,
			ps_kredi_hesap_endeksdoviz 		  varchar2  default null  );

 Procedure sp_teminat_onay_sonrasi(pn_islem_no number ,pn_hesap_no cbs_hesap_kredi.hesap_no%type  ,ps_doviz_kodu cbs_hesap_kredi.doviz_kodu%type,ps_islem_tipi varchar2 default 'ACILIS' );
 Procedure sp_teminat_fiskessonrasi(pn_islem_no number,pn_fis_no in  number,ps_islem_tipi varchar2 default 'ACILIS');
 Procedure sp_teminat_dogrulamaiptalsonra(pn_islem_no number);
 Procedure sp_teminat_iptalonaysonrasi(pn_islem_no number ,ps_islem_tipi varchar2 default 'ACILIS');
 Procedure sp_teminat_reddetmesonrasi(pn_islem_no number) ;
 Procedure sp_TeminatGuncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2,
							   ps_blokharic varchar2 default null);

 Procedure sp_Teminat_iptalsonrasi(pn_islem_no number);
 Function sf_teminatislemvarmi(pn_tx_no  number) return varchar2;
 Function sf_altkod_zorunlumu(ps_teminat_kodu cbs_teminat_kodlari.teminat_kodu%type) return varchar2 ;


 /* teminat kontrol sonrasi kosul islemleri */
 procedure sp_insert_teminat_kosul_islem(pn_tx_no number ,ps_teklif_kosul_karsilandi varchar2, ps_islem_dorgulama_gonderildi varchar2);
 Function sf_teminat_karsilandimi( pn_tx_no number,pn_kredi_teklif_satir_numara number ) return varchar2;
 Procedure sp_teminat_islem_guncelle( pn_tx_no                  cbs_teminat_islem.tx_no%type,
  								      pn_teminat_no         	cbs_teminat.teminat_no%type,
									  pn_kullanilan_tutar		number	  );

 Function sf_teminatno_varmi( pn_teminat_no         	    cbs_teminat.teminat_no%type) return varchar2;
 procedure sp_teminat_iptal_nakdihesap(pn_islem_no number) ;
 procedure sp_teminat_kapama_onaysonrasi(pn_islem_no number) ;
 procedure sp_teminat_uygundegilse_kapat(pn_islem_no number) ;
 Function sf_teminat_hesap_blokeuygunmu(pn_hesap_no cbs_hesap.hesap_no%type) return varchar2;
End PKG_TEMINAT;

/

