create PACKAGE BODY     PKG_TX3251 IS
    gn_eklenen_sira_no  number := 0;
    pn_3251_iliskili_hesap_sube    NUMBER;
    pn_3251_iliskili_hesap_no    NUMBER;
    pn_3251_kredi_hesap_no    NUMBER;
    pn_3251_kredi_hesap_sube    NUMBER;
    pn_3251_musteri_aciklama    NUMBER;
    pn_3251_referans    NUMBER;
    pn_3251_fis_aciklama    NUMBER;
    pn_3251_kur    NUMBER;
    pn_3251_kredi_tl    NUMBER;
    pn_3251_banka_aciklama    NUMBER;
    pn_3251_kredi_yp    NUMBER;
    pn_3251_kredi_doviz    NUMBER;
    pn_3251_iliskili_faiz_dk    NUMBER;
    pn_3251_islem_sube    NUMBER;
    pn_3251_musterikur_buyukse    NUMBER;
    pn_3251_musterikur_kucukse    NUMBER;
    pn_3251_iliskili_hesap_doviz    NUMBER;
    pn_3251_iliskili_faizdk    NUMBER;
    pn_3251_iliskili_komdk    NUMBER;
    pn_3251_deferred_interest    NUMBER;
    pn_3251_iliskili_faizreesdk    NUMBER;
    pn_3251_deferred_interest_lc    NUMBER;
    pn_3251_iliskili_komreesdk    NUMBER;
    pn_3251_deferred_tax    NUMBER;
    pn_3251_anapara_tahsil    NUMBER;
    pn_3251_deferred_tax_lc    NUMBER;
    pn_3251_anapara_tahsil_tl    NUMBER;
    pn_3251_accrual_gecikme_faiz    NUMBER;
    pn_3251_toplam_faiz    NUMBER;
    pn_3251_accrual_gecikme_faiz_lc    NUMBER;
    pn_3251_toplam_faiz_tl    NUMBER;
    pn_3251_gecikme_faiz_gl    NUMBER;
    pn_3251_gecenyil_faiz    NUMBER;
    pn_3251_accrual_gecikme_tax    NUMBER;
    pn_3251_accrual_gecikme_tax_lc    NUMBER;
    pn_3251_gecenyil_faiz_tl    NUMBER;
    pn_3251_fark_faiz    NUMBER;
    pn_3251_penalty_amount    NUMBER;
    pn_3251_fark_faiz_tl    NUMBER;
    pn_3251_penalty_amount_lc    NUMBER;
    pn_3251_tl_kredi    NUMBER;
    pn_3251_penalty_tax    NUMBER;
    pn_3251_yp_kredi    NUMBER;
    pn_3251_penalty_tax_lc    NUMBER;
    pn_3251_birikmis_sch_tl    NUMBER;
    pn_3251_anapara    NUMBER;
    pn_3251_gecenyil_sch_tl    NUMBER;
    pn_3251_anapara_lc    NUMBER;
    pn_3251_gecenyilbdak_sch_tl    NUMBER;
    pn_3251_birikmis_sch_acilis_tl    NUMBER;
    pn_3251_erken_odeme    NUMBER;
    pn_3251_erken_odeme_tl    NUMBER;
    pn_3251_istatistik_kapama    NUMBER;
    pn_3251_toplam_faiz_lc    NUMBER;
    pn_3251_istatistik_faiz    NUMBER;
    pn_3251_toplam_vergi    NUMBER;
    pn_3251_yp_tahsil    NUMBER;
    pn_3251_toplam_vergi_lc    NUMBER;
    pn_3251_tl_tahsil    NUMBER;
    pn_3251_penalty_toplam    NUMBER;
    pn_3251_tahsil_hesap_no    NUMBER;
    pn_3251_penalty_toplam_lc    NUMBER;
    pn_3251_anapara_tahsil_muskur    NUMBER;
    pn_3251_deferred_toplam    NUMBER;
    pn_3251_anapara_tahsil_malkur    NUMBER;
    pn_3251_deferred_toplam_lc    NUMBER;
    pn_3251_anapara_tahsil_farkkur    NUMBER;
    pn_3251_gecikme_faiz_toplam    NUMBER;
    pn_3251_toplam_faiz_muskur    NUMBER;
    pn_3251_gecikme_faiz_toplam_lc    NUMBER;
    pn_3251_fark_faiz_malkur    NUMBER;
    pn_3251_accrual_int_acct_no    NUMBER;
    pn_3251_accrual_tax_acct_no    NUMBER;
    pn_3251_gecenyil_faiz_malkur    NUMBER;
    pn_3251_erken_odeme_malkur    NUMBER;
    pn_3251_accrual_delay_int_acct_no    NUMBER;
    pn_3251_faiz_tahsilat_fark    NUMBER;
    pn_3251_nonaccrual_int_acct_no    NUMBER;
    pn_3251_musteri_kur    NUMBER;
    pn_3251_nonaccrual_delay_int_acct    NUMBER;
    pn_3251_accrual_tahsil_faiz    NUMBER;
    pn_3251_maliyet_kur    NUMBER;
    pn_3251_iliskili_hesap_tur    NUMBER;
    pn_3251_nonaccrual_tahsil_faiz    NUMBER;
    pn_3251_accrual_tahsil_vergi    NUMBER;
    pn_3251_nonaccrual_tahsil_vergi    NUMBER;
    pn_3251_accrual_tahsil_faiz_lc    NUMBER;
    pn_3251_tax_fc_1    NUMBER;
    pn_3251_nonaccrual_tahsil_faiz_lc    NUMBER;
    pn_3251_accrual_tahsil_vergi_lc    NUMBER;
    pn_3251_nonaccrual_tahsil_vergi_l    NUMBER;
    pn_3251_tax_aciklama    NUMBER;
    pn_3251_defer_pen_toplam    NUMBER;
    pn_3251_defer_pen_toplam_lc    NUMBER;
    pn_3251_defer_pen_tax    NUMBER;
    pn_3251_defer_pen_tax_lc    NUMBER;
    pn_3251_defer_penalty    NUMBER;
    pn_3251_defer_penalty_lc    NUMBER;
    pn_3251_nonaccrual_gecikme_faiz    NUMBER;
    pn_3251_nonaccrual_gecikme_faiz_l    NUMBER;
    pn_3251_nonaccrual_gecikme_tax    NUMBER;
    pn_3251_nonaccrual_gecikme_tax_lc    NUMBER;
    pn_3251_accr_defer_int    NUMBER;
    pn_3251_accr_defer_int_lc    NUMBER;
    pn_3251_nonaccr_defer_int    NUMBER;
    pn_3251_nonaccr_defer_int_lc    NUMBER;
    pn_3251_accr_defer_del_int    NUMBER;
    pn_3251_accr_defer_del_int_lc    NUMBER;
    pn_3251_nonaccr_defer_del_int    NUMBER;
    pn_3251_nonaccr_defer_del_int_lc    NUMBER;
    pn_3251_ack_principial    NUMBER;
    pn_3251_ack_int    NUMBER;
    pn_3251_ack_tax    NUMBER;
    pn_3251_ack_delay_int    NUMBER;
    pn_3251_ack_delay_int_tax    NUMBER;
    pn_3251_ack_defer_int    NUMBER;
    pn_3251_ack_defer_tax    NUMBER;
    pn_3251_ack_penalty    NUMBER;
    pn_3251_ack_penalty_tax    NUMBER;
    pn_3251_ack_defer_delay_int    NUMBER;
    pn_3251_nonaccr_defer_int_tax    NUMBER;
    pn_3251_nonaccr_defer_int_tax_lc    NUMBER;
    pn_3251_nonaccr_def_del_int_tax    NUMBER;
    pn_3251_nonaccr_def_del_int_tax_l    NUMBER;
    pn_3251_ack_defer_int_tax    NUMBER;
    pn_3251_ack_defer_delay_int_tax    NUMBER;
    pn_3251_tahsil_hesap_sube    NUMBER;

      -- b-o-m seval.colak 07062022
    pn_3251_accr_defer_int_tax    NUMBER;
    pn_3251_accr_defer_int_tax_lc    NUMBER;
    pn_3251_accr_def_del_int_tax    NUMBER;
    pn_3251_accr_def_del_int_tax_l    NUMBER;
    -- e-o-m  seval.colak 07062022
    
    --b-o-m seval.colak 14062022
        pn_3251_accrual_tahsil_faiz_lm    NUMBER;
        pn_3251_nonaccrual_tahsil_faiz_lm    NUMBER;
        pn_3251_accrual_tahsil_vergi_lm    NUMBER;
        pn_3251_nonaccr_tahsil_vergi_lm    NUMBER;
        pn_3251_defer_pen_toplam_lm    NUMBER;
        pn_3251_defer_pen_tax_lm    NUMBER;
        pn_3251_defer_penalty_lm    NUMBER;
        pn_3251_nonaccr_gecikme_faiz_lm    NUMBER;
        pn_3251_nonaccr_gecikme_tax_lm    NUMBER;
        pn_3251_accr_defer_int_lm    NUMBER;
        pn_3251_nonaccr_defer_int_lm    NUMBER;
        pn_3251_accr_defer_del_int_lm    NUMBER;
        pn_3251_nonaccr_defer_del_int_lm    NUMBER;
        pn_3251_nonaccr_defer_int_tax_lm    NUMBER;
        pn_3251_accr_defer_int_tax_lm    NUMBER;
        pn_3251_accr_def_del_int_tax_lm    NUMBER;
        pn_3251_toplam_faiz_lm    NUMBER;
        pn_3251_toplam_vergi_lm    NUMBER;
        pn_3251_penalty_amount_lm    NUMBER;
        pn_3251_anapara_lm    NUMBER;
        pn_3251_deferred_interest_lm    NUMBER;
        pn_3251_deferred_tax_lm    NUMBER;
        pn_3251_deferred_toplam_lm    NUMBER;
        pn_3251_penalty_toplam_lm    NUMBER;
        pn_3251_accr_gecikme_faiz_lm    NUMBER;
        pn_3251_accr_gecikme_tax_lm    NUMBER;
        pn_3251_gecikme_faiz_toplam_lm    NUMBER;
        pn_3251_penalty_tax_lm    NUMBER;
        pn_3251_nonaccr_def_del_int_tx_lm    NUMBER;
    --e-o-m seval.colak 14062022
    --b-o-m seval.colak 17062022
    pn_3251_toplam_faiz_fark_kur      NUMBER;
    pn_3251_toplam_vergi_fark_kur     NUMBER;
    pn_3251_erken_odeme_kom_tax       NUMBER;
    pn_3251_erken_odeme_kom_tax_lc    NUMBER;
    pn_3251_erken_odeme_kom_tax_lm    NUMBER;
    --e-o-m seval.colak 17062022
    pn_3251_penalty_gl    NUMBER;   --seval.colak 01112022


   Function sf_hesap_taksit_durum(
                                    pn_hesap_no number,
                                    pn_taksit_no in  number,
                                       ps_kucuk_buyuk varchar2 ) return number

  is
       ln_sira_no number;
  Begin

        select min(sira_no)
       into   ln_sira_no
       from   cbs_hesap_kredi_taksit
       where hesap_no = pn_hesap_no and
                ( ( ps_kucuk_buyuk = 'K'  and sira_no <   pn_taksit_no and durum_kodu = 'A') OR
              ( ps_kucuk_buyuk = 'B'  and sira_no  >   pn_taksit_no and durum_kodu in( 'O','K','T') ) )  ;

    return ln_sira_no;

    Exception when others then return null;

 End;

Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_kredi_teklif_satir_numara             number ;
   ln_kredi_hesap_tutar                   number :=0 ;
   ls_kredi_hesap_doviz_kodu               cbs_doviz_kodlari.doviz_kodu%type;
   ln_bakiye                              number := 0;
   ln_hesap_no                             cbs_hesap.hesap_no%type;
   ls_endeks_doviz_kodu                  cbs_doviz_kodlari.doviz_kodu%type;
   ln_adet                                 number := 0;
   ls_geriodeme                             varchar2(2000);
   ln_txno                                 number;
   ld_max_vade                             date;
   taksit_islem_yok                         exception;
   vade_tarihi_uygun_degil                  exception;
   ln_tahsil_hesap_no                      number;
   ln_iliskili_hesap_no                     number;
   ln_odeme_plan_no                        number;
    -- b-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
    ls_eod varchar2(1) := 'H';
    ls_eod_muhasebe varchar2(1) := 'H';
    eod_account_run_closing_not_allowed exception;
   -- e-o-m seval.colak 29122022 eod problem related addition of not allowing closing during eod accounting  
  Begin

   select kredi_teklif_satir_numara,
           abs(decode(endeks_doviz_kodu,null,pkg_kredi.sf_Bakiye_Al(hesap_no), pkg_kredi.sf_endeks_doviz_bakiye_al(hesap_no))),-- abs(nvl(tutar,0)),
          doviz_kodu ,
          hesap_no,
          endeks_doviz_kodu,
          geriodeme_kapama_secimi,
          odeme_plan_no
   into   ln_kredi_teklif_satir_numara,
             ln_kredi_hesap_tutar,
          ls_kredi_hesap_doviz_kodu,
          ln_hesap_no,
          ls_endeks_doviz_kodu,
          ls_geriodeme,
          ln_odeme_plan_no
   from cbs_hesap_kredi_islem
   where tx_no = pn_islem_no;

 -- b-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
     select eod,eod_muhasebe
     into ls_eod,ls_eod_muhasebe
     from  cbs_system;    
     
     if  ls_geriodeme = 'KAPAMA' then 
       if  nvl(ls_eod,'H') = 'E' or nvl(ls_eod_muhasebe,'H') = 'E' then         
           raise  eod_account_run_closing_not_allowed;
        end if;
    end if;
  -- e-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
  

 ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
                                  pn_islem_no,
                               ln_hesap_no) ;

  if  ls_geriodeme = 'TAKSIT' then
        select count(*)
        into ln_adet
        from cbs_hesap_kredi_taksit_islem
        where tx_no = pn_islem_no and
              taksit_secildi = 'E';
             if nvl(ln_adet,0) = 0 then
            raise taksit_islem_yok;
        end if;
  end if;
 
    pkg_teminat.sp_teminat_kontrolsonra(pn_islem_no ,
               ln_kredi_teklif_satir_numara ,
             ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
             ls_endeks_doviz_kodu);

     if  ls_geriodeme ='ARA' and nvl(ln_odeme_plan_no,0) = 0  then --seval.colak and nvl(ln_odeme_plan_no,0) = 0  eklendi. 07022022
           select max(vade_tarih)
          into  ld_max_vade
          from cbs_hesap_kredi_taksit_islem
          where tx_no = pn_islem_no and
                nvl(durum_kodu,'A') = 'A';

          if pkg_kredi.sf_acilis_vade_tarih_al(ln_hesap_no)  < ld_max_vade then
               raise vade_tarihi_uygun_degil;
           end if;
      end if;

  sp_hesap_taksit_kontrol(pn_islem_no); --seval.colak 30052022
 
  sp_kontrol_sonrasi_rezervasyon(pn_islem_no);


  SELECT  tahsil_hesap_no, iliskili_hesap_no 
   INTO ln_tahsil_hesap_no, ln_iliskili_hesap_no 
   FROM   cbs_hesap_kredi_islem
   WHERE  tx_no = pn_islem_no;

--b-o-m seval.colak 18022023
 if  nvl(ln_iliskili_hesap_no,0) <> 0 and  nvl(ln_tahsil_hesap_no,0) = 0   and pkg_hesap.badlistflag(ln_iliskili_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;

 if  nvl(ln_tahsil_hesap_no,0) <> 0 and pkg_hesap.badlistflag(ln_tahsil_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;
--b-o-m seval.colak 18022023
  if ln_tahsil_hesap_no is not null then
    pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'3251',ln_tahsil_hesap_no);
  elsif ln_iliskili_hesap_no is not null then
    pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'3251',ln_iliskili_hesap_no);
  end if;
  

  Exception
   When  vade_tarihi_uygun_degil     then
      raise_application_error(-20100,pkg_hata.getucpointer || '929' || pkg_hata.getucpointer);
   When taksit_islem_yok then
      raise_application_error(-20100,pkg_hata.getucpointer || '914' || pkg_hata.getucpointer);
   WHEN eod_account_run_closing_not_allowed THEN    -- seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
         raise_application_error(-20100,pkg_hata.getucpointer || '9900' || pkg_hata.getDelimiter || ln_hesap_no ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
  End;

   procedure sp_hesap_taksit_kontrol(pn_islem_no number)
   is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ln_sira_no                number := 0;
    ls_durum                varchar2(2000);
    ls_taksit_durum            varchar2(2000);
    ls_geriodeme             varchar2(2000);
    ln_taksit                number := 0;
    hesap_durum_uygundegil          exception;
    taksitdurum_uygundegil          exception;
    odemeplan_toplam_esit_degil     exception;

     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no;

        cursor cursor_taksit is
        select *
        from cbs_hesap_kredi_taksit_islem
        where     tx_no = pn_islem_no and
                taksit_secildi = 'E'
        order by sira_no desc    ;
 --B-O-M seval.colak 30052022 
    ln_odeme_plan_no        number;
     ln_isl_tahsil_deferred_interest      number := 0;
    ln_isl_tahsil_deferred_delayed_interest  number := 0;
    ln_isl_tahsil_deferred_tax   number := 0;
    ln_isl_tahsil_deferred_penalty_amount  number := 0;
    ln_isl_tahsil_delayed_interest   number := 0;
    ln_isl_tahsil_penalty_amount  number := 0;
    ln_hsp_tahsil_deferred_interest      number := 0;
    ln_hsp_tahsil_deferred_delayed_interest  number := 0;
    ln_hsp_tahsil_deferred_tax   number := 0;
    ln_hsp_tahsil_deferred_penalty_amount  number := 0;
    ln_hsp_tahsil_delayed_interest   number := 0;
     ln_hsp_tahsil_penalty_amount  number := 0;
    ls_sum_value_column     varchar2(200);
     ln_new_value       number := 0;  
     ln_existing_Value  number := 0;
     --E-O-M seval.colak 30052022 
    Begin
         for c_hesap in cur_hesap loop
            ln_hesap_no := c_hesap.hesap_no ;
            ln_odeme_plan_no := c_hesap.odeme_plan_no;
            ls_geriodeme := c_hesap.geriodeme_kapama_secimi;
        end loop;

        ls_durum := pkg_kredi.sf_kredi_hesap_durumu_al(ln_hesap_no);
        if ls_durum != 'A' then
           raise  hesap_durum_uygundegil;
        end if;

/* taksitlerin durum kodu uygun mu */
         for cur_taksit in cursor_taksit loop
          ln_sira_no := cur_taksit.sira_no;
           ln_taksit  := 0;
           ls_taksit_durum:= pkg_bireysel_kredi.sf_taksit_durumu_al( cur_taksit.hesap_no,cur_taksit.sira_no);
              if  ls_taksit_durum != 'A' Then
                 raise taksitdurum_uygundegil;
           end if;

           if ls_geriodeme = 'TAKSIT' then
                  ln_taksit:= sf_hesap_taksit_durum(cur_taksit.hesap_no,cur_taksit.sira_no, 'K');
                    if nvl(  ln_taksit,0) <> 0 and  ln_taksit<>  ln_sira_no then
                          ln_sira_no :=ln_taksit;
                         raise taksitdurum_uygundegil;
                 end if;
            end if;
        end loop;

  if ls_geriodeme = 'ARA' and nvl( ln_odeme_plan_no,0) <> 0 then     
      select 
            sum(abs( nvl(b.deferred_interest,0)) )  tahsil_deferred_interest,
            sum(abs( nvl(b.deferred_delayed_interest,0))) tahsil_deferred_delayed_interest,
            sum(0) tahsil_deferred_tax , --seval.colak 29082022  deferred_tax artik kullanilmayacak -sum(abs( nvl(b.deferred_tax,0)) )tahsil_deferred_tax ,
            sum(abs( nvl(b.deferred_penalty_amount,0)) )tahsil_deferred_penalty_amount,
            sum(abs( nvl(b.delayed_interest,0)) )tahsil_delayed_interest  ,
            sum(abs( nvl(b.penalty_amount,0)) )tahsil_penalty_amount
    into  ln_isl_tahsil_deferred_interest ,
          ln_isl_tahsil_deferred_delayed_interest,
          ln_isl_tahsil_deferred_tax,
          ln_isl_tahsil_deferred_penalty_amount,
          ln_isl_tahsil_delayed_interest   ,
          ln_isl_tahsil_penalty_amount
    from  cbs_taksit_odeme_plan b
    where      b.odeme_plan_no = ln_odeme_plan_no and
               b.durum_kodu = 'A' ; 
                    
    select 
            NVL(HSPLN_DEFERRED_INTEREST,0)    tahsil_deferred_interest,
            NVL(HSPLN_DEFERRED_DELAYED_INTEREST,0)  tahsil_deferred_delayed_interest,
            0  tahsil_deferred_tax , --seval.colak 29082022  deferred_tax artik kullanilmayacak --NVL(HSPLN_DEFERRED_TAX,0)    tahsil_deferred_tax ,
            NVL(HSPLN_DEFERRED_PENALTY_AMOUNT,0)   tahsil_deferred_penalty_amount,
            nvl(HSPLN_BIRIKMIS_GECIKME_FAIZ,0)    tahsil_delayed_interest ,
            NVL(HSPLN_PENALTY_AMOUNT,0)   tahsil_penalty_amount    
    into  ln_hsp_tahsil_deferred_interest ,
          ln_hsp_tahsil_deferred_delayed_interest,
          ln_hsp_tahsil_deferred_tax,
          ln_hsp_tahsil_deferred_penalty_amount,
          ln_hsp_tahsil_delayed_interest  ,
          ln_hsp_tahsil_penalty_amount
    from cbs_hesap_kredi_islem a
    where      a.tx_no = pn_islem_no ;               
                 
             ln_new_value := 0;  
             ln_existing_Value := 0;
              
          
          if   nvl(ln_isl_tahsil_deferred_interest,0) <>  nvl(ln_hsp_tahsil_deferred_interest,0) then  
               ls_sum_value_column := 'DEFERRED INTEREST';    
               ln_new_value         :=  ln_isl_tahsil_deferred_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_interest;     
               raise odemeplan_toplam_esit_degil;         
           end if;  
           
            if   nvl(ln_isl_tahsil_deferred_tax,0) <>  nvl(ln_hsp_tahsil_deferred_tax,0) then  
               ls_sum_value_column := 'DEFERRED TAX'; 
               ln_new_value         := ln_isl_tahsil_deferred_tax;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_tax;
               raise odemeplan_toplam_esit_degil;                 
           end if;  
         
            if   nvl(ln_isl_tahsil_deferred_delayed_interest,0) <>  nvl(ln_hsp_tahsil_deferred_delayed_interest,0) then  
               ls_sum_value_column := 'DEFERRED DELAYED INTEREST';   
               ln_new_value         := ln_isl_tahsil_deferred_delayed_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_delayed_interest;      
               raise odemeplan_toplam_esit_degil;         
           end if;   
           
           if   nvl(ln_isl_tahsil_delayed_interest,0) <>  nvl(ln_hsp_tahsil_delayed_interest,0)   then              
               ls_sum_value_column := 'DELAYED INTEREST';    
               ln_new_value         :=  ln_isl_tahsil_delayed_interest;
               ln_existing_Value    :=  ln_hsp_tahsil_delayed_interest;
                raise odemeplan_toplam_esit_degil;   
            end if;   
           
            if   nvl(ln_isl_tahsil_penalty_amount,0) <>  nvl(ln_hsp_tahsil_penalty_amount,0) then  
               ls_sum_value_column  := 'PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_tahsil_penalty_amount;
               ln_existing_Value    :=  ln_hsp_tahsil_penalty_amount; 
               raise odemeplan_toplam_esit_degil;               
           end if;  
           
           if   nvl(ln_isl_tahsil_deferred_penalty_amount,0) <>  nvl(ln_hsp_tahsil_deferred_penalty_amount,0) then  
               ls_sum_value_column  := 'DEFERRED PENALTY AMOUNT'; 
               ln_new_value         := ln_isl_tahsil_deferred_penalty_amount;
               ln_existing_Value    :=  ln_hsp_tahsil_deferred_penalty_amount; 
               raise odemeplan_toplam_esit_degil;               
           end if;  
           
             
 end if;
Exception
   When hesap_durum_uygundegil then
    raise_application_error(-20100,pkg_hata.getucpointer || '906' || pkg_hata.getDelimiter || ls_durum ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
   When taksitdurum_uygundegil then
       raise_application_error(-20100,pkg_hata.getucpointer || '907' ||  pkg_hata.getDelimiter || to_char(ln_sira_no) || pkg_hata.getDelimiter ||  ls_taksit_durum  || pkg_hata.getDelimiter|| pkg_hata.getucpointer);
   When  odemeplan_toplam_esit_degil then
       raise_application_error(-20100,pkg_hata.getucpointer || '941' ||  pkg_hata.getDelimiter || to_char(ls_sum_value_column) ||pkg_hata.getDelimiter||to_char(ln_new_value) ||pkg_hata.getDelimiter|| to_char(ln_existing_Value) ||pkg_hata.getDelimiter|| pkg_hata.getucpointer);
   When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '908' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   End;


    procedure sp_hesap_iptaloncetaksitkntr(pn_islem_no number)
   is
    ln_hesap_no             cbs_hesap_kredi.hesap_no%type;
    ln_sira_no                number := 0;
    ls_durum                varchar2(2000);
    ls_taksit_durum            varchar2(2000);
    ls_geriodeme             varchar2(2000);
    ln_taksit                number := 0;
    hesap_durum_uygundegil    exception;
    taksitdurum_uygundegil  exception;

     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no;

        cursor cursor_taksit is
        select *
        from cbs_hesap_kredi_taksit_islem
        where     tx_no = pn_islem_no and
                taksit_secildi = 'E'
        order by sira_no desc    ;

    Begin
           for c_hesap in cur_hesap loop
            ln_hesap_no := c_hesap.hesap_no ;
            ls_geriodeme := c_hesap.geriodeme_kapama_secimi;
        end loop;

        if ls_geriodeme !=  'KAPAMA' then
               ls_durum := pkg_kredi.sf_kredi_hesap_durumu_al(ln_hesap_no);
            if ls_durum != 'A' then
               raise  hesap_durum_uygundegil;
            end if;
        end if;
/* taksitlerin durum kodu uygun mu */
--  b-o-m seval.colak 30052022 kismi tahsilatda soruna yol aciyor. kapatildi.
      /*   for cur_taksit in cursor_taksit loop
              ln_sira_no := cur_taksit.sira_no;
           ln_taksit  := 0;
           ls_taksit_durum:= pkg_bireysel_kredi.sf_taksit_durumu_al( cur_taksit.hesap_no,cur_taksit.sira_no);
              if  ls_taksit_durum not in( 'T','O','K') Then
                 raise taksitdurum_uygundegil; 
            end if;
      end loop;
    */
   Exception
       When hesap_durum_uygundegil then
        raise_application_error(-20100,pkg_hata.getucpointer || '906' || pkg_hata.getDelimiter || ls_durum ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
       When    taksitdurum_uygundegil then
       raise_application_error(-20100,pkg_hata.getucpointer || '907' ||  pkg_hata.getDelimiter || to_char(ln_sira_no) || pkg_hata.getDelimiter ||  ls_taksit_durum  || pkg_hata.getDelimiter|| pkg_hata.getucpointer);
       When others then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '908' || pkg_hata.getDelimiter || to_char(SQLCODE) || ' ' ||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
   End;


  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  /*  sp_hesap_taksit_kontrol(pn_islem_no);
    sp_onayoncesi_kurtutarguncelle(pn_islem_no);
    */
    null;
  End;

 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block    varchar2,ps_rowid   varchar2,
                                 ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
 Begin
    pkg_teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue );

 End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;

     pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_No);
     PKG_KUR_REZERVASYON.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    /* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_islem_durumguncelle(pn_islem_no,'ACIK');

  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
        null;
   End;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
    ln_teklif_no    cbs_kredi_teklif.teklif_no%type;
    ls_durum_kodu   cbs_kredi_teklif.durum_kodu%type;
    ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
    ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
    ls_geriodeme_kapama_secimi    cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
    ln_odeme_plan_no    number;    
    
     -- b-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
    ls_eod varchar2(1) := 'H';
    ls_eod_muhasebe varchar2(1) := 'H';
    eod_account_run_closing_not_allowed exception;
   -- e-o-m seval.colak 29122022 eod problem related addition of not allowing closing during eod accounting   
    ln_iliskili_hesap_no number ;--seval.colak 18022023
    ln_tahsil_hesap_no   number;   --seval.colak 18022023
  Begin

    sp_hesap_taksit_kontrol(pn_islem_no);

      select hesap_no,
             doviz_kodu,
             geriodeme_kapama_secimi,
             odeme_plan_no,  --seval.colak 04022022
             iliskili_hesap_no, --seval.colak 18022023
             tahsil_hesap_no    --seval.colak 18022023
      into   ln_hesap_no,
             ls_doviz_kodu,
             ls_geriodeme_kapama_secimi,
             ln_odeme_plan_no  ,  --seval.colak 04022022
             ln_iliskili_hesap_no,  --seval.colak 18022023
             ln_tahsil_hesap_no     --seval.colak 18022023
      from cbs_hesap_kredi_islem
      where tx_no = pn_islem_no;
 
--b-o-m seval.colak 18022023
 if  nvl(ln_iliskili_hesap_no,0) <> 0 and  nvl(ln_tahsil_hesap_no,0) = 0   and pkg_hesap.badlistflag(ln_iliskili_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;

 if  nvl(ln_tahsil_hesap_no,0) <> 0 and pkg_hesap.badlistflag(ln_tahsil_hesap_no) = 'E'
 then
  raise_application_error(-20100,pkg_hata.getucpointer || '293' || pkg_hata.getucpointer);
 end if;
--b-o-m seval.colak 18022023

 -- b-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
     select eod,eod_muhasebe
     into ls_eod,ls_eod_muhasebe
     from  cbs_system;    
     
     if  ls_geriodeme_kapama_secimi = 'KAPAMA' then 
       if  nvl(ls_eod,'H') = 'E' or nvl(ls_eod_muhasebe,'H') = 'E' then         
           raise  eod_account_run_closing_not_allowed;
        end if;
    end if;
  -- e-o-m seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
  
  
    Pkg_Kredi.sp_onayonce_taksit_sakla(    pn_islem_no ,ln_hesap_no);
     -- B-O-M seval.colak 30052022
     begin
     insert into cbs_kredi_tahakkuk_onay_on_isl(
        islem_no	,
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	)
        select 
        pn_islem_no islem_no	,
        banka_tarihi	,
        musteri_no	,
        kredi_hesap_no	,
        kredi_doviz_kodu	,
        faiz_tahakkuk_tarihi	,
        vade_tarihi	,
        yeni_faiz_tahakkuk_tarihi	,
        faiz_tahakkuk_tutar	,
        vergi_tahakkuk_tutar	,
        faiz_tahakkuk_tutar_tahsil	,
        vergi_tahakkuk_tutar_tahsil	,
        odeme_tarihi	,
        durum_kodu	,
        yaratan_islem_kod	,
        yaratan_tx_no	,
        muhasebe_fis_no	,
        grup_no	,
        log_no	,
        yaratan_kullanici_kodu	,
        yaratildigi_tarih	,
        tahakkuk_no	,
        gecikme_gun_sayisi	,
        tahsilat_tx_no	
        from cbs_kredi_tahakkuk
        where kredi_hesap_no =ln_hesap_no;
         exception when others then null;
       end ;
     -- E-O-M seval.colak 30052022
     
    sp_araodeme_taksitsira_guncel(pn_islem_no);
    pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no ,ln_hesap_no,ls_doviz_kodu,ls_geriodeme_kapama_secimi);
    
     -- B-O-M   seval.colak 04022022   
    if nvl(ln_odeme_plan_no,0) <> 0 then
     Pkg_Kredi.sp_kredihesap_bilgisi_guncelle(pn_islem_no);   -- seval.colak 27012022 eklendi. 
      
        update cbs_odeme_plan
        set  durum_kodu ='K',
             kapanis_tarihi = pkg_muhasebe.banka_tarihi_bul 
        where odeme_plan_No = ln_odeme_plan_no;
     end if;
     --E-O-M   seval.colak 04022022 
     
   EXCEPTION
     WHEN eod_account_run_closing_not_allowed THEN    -- seval.colak 29122022  eod problem related addition of not allowing closing during eod accounting 
      raise_application_error(-20100,pkg_hata.getucpointer || '9900' || pkg_hata.getucpointer);
  End;

 PROCEDURE sp_araodeme_taksitsira_guncel(pn_islem_no NUMBER)
 IS
  ln_hesap_no             NUMBER;

   CURSOR cur_taksit IS
     SELECT sira_no
     FROM  CBS_HESAP_KREDI_TAKSIT_ISLEM
     WHERE tx_no = pn_islem_no AND
            NVL(durum_kodu,'A') = 'A'
     ORDER BY vade_tarih
     FOR UPDATE OF sira_no;

     ln_i           number := 0;
     ln_adet        number ;
     ln_tahsil_anapara      number := 0;
     ls_geriodeme_kapama_secimi     varchar2(200);
     ln_old                         NUMBER := 0;
     --b-o-m seval.colak 10022022
     ln_tahsil_faiz                 number := 0;
     ln_tahsil_tax                  number := 0;
     ln_rate                        number := 0;
     ln_taksit_toplam               number := 0;     
     --e-o-m seval.colak 10022022     
     --b-o-m seval.colak 02062022
     ln_tahsil_gecikme_faiz_tutari     number := 0;
     ln_tahsil_penalty_amount           number := 0; 
     ln_tahsil_penalty_tax              number := 0; 
     ln_tahsil_deferred_penalty_amount  number :=0;
     ln_tahsil_deferred_penalty_tax number := 0; 
     ln_tahsil_deferred_delayed_interest number := 0; 
     ln_tahsil_deferred_delay_int_tax number := 0;           
     ln_tahsil_deferred_interest  number := 0; 
     ln_tahsil_deferred_interest_tax  number := 0; 
     ln_tahsil_deferred_tax   number := 0; 
      --e-o-m seval.colak 02062022
  BEGIN
      Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
      select nvl(tahsil_anapara,0) tahsil_anapara, --seval.colak 14062022  nvl(araodeme_tutari,0) yerine tahsil_anapara
             geriodeme_kapama_secimi,
             hesap_no,
             nvl(tahsil_faiz,0) tahsil_faiz,
             NVL(tahsil_vergi,0)  tahsil_tax,
             nvl(tahsil_gecikme_faiz_tutari,0), --seval.colak 02062022
               nvl(tahsil_penalty_amount,0),
               nvl(tahsil_penalty_tax,0),
               nvl(tahsil_deferred_penalty_amount,0),
               nvl(tahsil_deferred_penalty_tax,0),
               nvl(tahsil_deferred_delayed_interest,0),
               nvl(tahsil_deferred_delay_int_tax,0),           
               nvl(tahsil_deferred_interest,0),
               nvl(tahsil_deferred_interest_tax,0),
               0 tahsil_deferred_tax --seval.colak 29082022  deferred_tax artik kullanilmayacak -- nvl(tahsil_deferred_tax,0)
      into ln_tahsil_anapara,
           ls_geriodeme_kapama_secimi,
           ln_hesap_no,
           ln_tahsil_faiz,
           ln_tahsil_tax,
           ln_tahsil_gecikme_faiz_tutari, --seval.colak 02062022
           ln_tahsil_penalty_amount,
           ln_tahsil_penalty_tax,
           ln_tahsil_deferred_penalty_amount,
           ln_tahsil_deferred_penalty_tax,
           ln_tahsil_deferred_delayed_interest,
           ln_tahsil_deferred_delay_int_tax,           
           ln_tahsil_deferred_interest,
           ln_tahsil_deferred_interest_tax,
           ln_tahsil_deferred_tax
      from cbs_hesap_kredi_islem
      where tx_no = pn_islem_no ;

     IF ls_GERIODEME_KAPAMA_SECIMI ='ARA' THEN
         SELECT MIN(sira_no)
         INTO ln_old
         FROM  CBS_HESAP_KREDI_TAKSIT_ISLEM
         WHERE tx_no = pn_islem_no AND
                NVL(durum_kodu,'A') = 'A';

        IF NVL(ln_old,0) = 0 THEN
             SELECT MAX(sira_no) + 1
             INTO  ln_old
             FROM  CBS_HESAP_KREDI_TAKSIT_ISLEM
              WHERE tx_no = pn_islem_no ;
         END IF;

           UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
           SET sira_no = sira_no + 10000
           WHERE tx_no = pn_islem_no AND
                    NVL(durum_kodu,'A') = 'A';

        ln_i := ln_old;

        FOR c_taksit IN cur_taksit LOOP
           ln_i:= NVL(ln_i,0) + 1;
           UPDATE CBS_HESAP_KREDI_TAKSIT_ISLEM
           SET sira_no = ln_i
           WHERE CURRENT OF cur_taksit;
        END LOOP;

        gn_eklenen_sira_no:=NVL(ln_old,1);
        
        ln_taksit_toplam := nvl(ln_tahsil_anapara,0) + nvl(ln_tahsil_faiz,0) + nvl(ln_tahsil_tax,0) +nvl(ln_tahsil_deferred_interest,0) + nvl(ln_tahsil_deferred_tax,0) +nvl(ln_tahsil_deferred_penalty_amount,0) + nvl(ln_tahsil_deferred_delayed_interest,0);

         INSERT INTO CBS_HESAP_KREDI_TAKSIT_ISLEM (TX_NO, SIRA_NO, TAKSIT, TAHSIL_EDILECEK_TAKSIT,ANAPARA,KDVLI_TAKSIT,VADE_TARIH, HESAP_NO, DURUM_KODU, ODEME_TARIHI 
         ,kal_anapara,FAIZ ,BSMV --seval.colak kal_anapara eklendi 10022022
         ,tahsil_taksit ,gecikme_faiz_tutari ,penalty_amount,  deferred_penalty_amount,  deferred_delayed_interest,  deferred_interest,  deferred_tax
         ,tahsil_anapara,tahsil_bsmv,tahsil_faiz,tahsil_gecikme_faiz_tutari,tahsil_kkdf  --seval.colak 23062022
         ,paid_penalty_amount,  paid_deferred_penalty_amount,  paid_deferred_delayed_interest,  paid_deferred_interest,  paid_deferred_tax
          ) --seval.colak 02062022
         VALUES (pn_islem_no,gn_eklenen_sira_no ,ln_taksit_toplam,ln_taksit_toplam,ln_tahsil_anapara,ln_taksit_toplam +nvl(ln_Tahsil_tax,0) ,Pkg_Muhasebe.banka_tarihi_bul,ln_hesap_no,'O',Pkg_Muhasebe.banka_tarihi_bul 
         , abs(abs(pkg_kredi.sf_bakiye_al(ln_hesap_no)) - nvl(ln_tahsil_anapara,0) ) ,ln_tahsil_faiz,ln_Tahsil_tax ,  --seval.colak kal_anapara eklendi 10022022
          ln_taksit_toplam , ln_tahsil_gecikme_faiz_tutari , ln_tahsil_penalty_amount,
           ln_tahsil_deferred_penalty_amount,   ln_tahsil_deferred_delayed_interest,ln_tahsil_deferred_interest,    ln_tahsil_deferred_tax,
           ln_tahsil_anapara,ln_Tahsil_tax,ln_tahsil_faiz,ln_tahsil_gecikme_faiz_tutari,0 , --seval.colak 23062022
           ln_tahsil_penalty_amount,  ln_tahsil_deferred_penalty_amount,  ln_tahsil_deferred_delayed_interest,  ln_tahsil_deferred_interest,  ln_tahsil_deferred_tax
          );--seval.colak 02062022

     END IF;

  END;
  Procedure  sp_muhasebesonrasi_guncelle(pn_islem_no number)
  is
     cursor cur_hesap is
      select *
        from cbs_hesap_kredi_islem
       where tx_no=pn_islem_no ;

      r_hesap cur_hesap%rowtype;

    cursor cursor_taksit is
    select *
    from cbs_hesap_kredi_taksit_islem
    where     tx_no = pn_islem_no and
            taksit_secildi = 'E'
    for update of  durum_kodu ,  odeme_tarihi
    order by sira_no;

     ln_aynigun  number := 0;
     ls_durum  cbs_hesap_kredi_taksit_islem.durum_kodu%type;
     ln_tahak_sch_faiz_tutari number :=0;
     ln_gecen_faiz              number := 0;
     ln_taksit_sayisi           number := 0;
     ln_gecmis_aylarin_faiz   number := 0;
     ln_orig_gecenYil_faiz      number := 0;
     ln_yeni_gecmisay_faiz      number := 0;
     ln_orig_gecmisay_faiz      number := 0;
     ln_orig_gecmisyil_faiz      number := 0;
     ln_yeni_gecenyil           number := 0;
  Begin
    /* islem bilgisi detaylari alinir */
          open cur_hesap;
         fetch cur_hesap into r_hesap;
        close cur_hesap;

    if r_hesap.GERIODEME_KAPAMA_SECIMI in ( 'ARA') THEN
          begin
              delete from CBS_HESAP_KREDI_OZEL_TKST
            where hesap_no =r_hesap.hesap_no;
            delete from cbs_hesap_kredi_taksit
            where hesap_no =r_hesap.hesap_no;
       exception when no_data_found then  null;
       end ;

          begin
               insert into  cbs_hesap_kredi_taksit (YARATAN_TX_NO, HESAP_NO, SIRA_NO, TAKSIT, ANAPARA, FAIZ, KKDF, BSMV, VADE_TARIH, KAL_ANAPARA, KDV, KDVLI_TAKSIT, TAHSIL_EDILECEK_TAKSIT, YARATILDIGI_TARIH, YARATAN_KULLANICI, DURUM_KODU, ODEME_TARIHI, GECIKME_FAIZ_TUTARI, KUR_TRL, ANAPARA_TRL, FAIZ_TRL, KDV_TRL,
                 TAKSIT_GUN_SAYISI	,HESAPLAMA_GUN_SAYISI	,TAKSIT_BAZ_ANAPARA	,TAKSIT_FAIZ_ORANI	,TAKSIT_BSMV_ORANI	,TAKSIT_KKDF_ORANI	,OZEL_ODEME_TUTARI	,ORJ_VERGI_TUTARI	,ORJ_FAIZ_TUTARI	,EK_FAIZ_TUTARI	,
                 DEFERRED_INTEREST	,DEFERRED_TAX	,PAID_DEFERRED_INTEREST	,PAID_DEFERRED_TAX	,TAHSIL_TAKSIT	,TAHSIL_ANAPARA	,TAHSIL_FAIZ	,TAHSIL_KKDF	,TAHSIL_BSMV	,TAHSIL_GECIKME_FAIZ_TUTARI	,DEFERRED_TAX2	,PAID_DEFERRED_TAX2	,TAHAKKUK_EH	,
                 PENALTY_AMOUNT	,PAID_PENALTY_AMOUNT	,DEFERRED_PENALTY_AMOUNT	,PAID_DEFERRED_PENALTY_AMOUNT	,AP_GECIKME_GUN_SAYISI	,FAIZ_GECIKME_GUN_SAYISI	,DEFERRED_DELAYED_INTEREST	,PAID_DEFERRED_DELAYED_INTEREST	,PAID_DEFERRED_PENALTY_TAX	,PAID_NONACCRUAL_DEFERRED_TAX	,PAID_NONACCRUAL_DEFERRED_DELAY_TAX	)
               select nvl(yaratan_tx_no,pn_islem_no), nvl(HESAP_NO,r_hesap.hesap_no), SIRA_NO, TAKSIT, ANAPARA, nvl(FAIZ,0), nvl(KKDF,0), nvl(BSMV,0), VADE_TARIH, KAL_ANAPARA, nvl(KDV,0), nvl(kdv,0) + nvl(taksit,0) , nvl(TAHSIL_EDILECEK_TAKSIT,taksit), nvl(YARATILDIGI_TARIH,sysdate), nvl(YARATAN_KULLANICI,user), nvl(DURUM_KODU,'A'), ODEME_TARIHI, GECIKME_FAIZ_TUTARI, KUR_TRL, ANAPARA_TRL, FAIZ_TRL, KDV_TRL,
                 TAKSIT_GUN_SAYISI	,HESAPLAMA_GUN_SAYISI	,TAKSIT_BAZ_ANAPARA	,TAKSIT_FAIZ_ORANI	,TAKSIT_BSMV_ORANI	,TAKSIT_KKDF_ORANI	,OZEL_ODEME_TUTARI	,ORJ_VERGI_TUTARI	,ORJ_FAIZ_TUTARI	,EK_FAIZ_TUTARI	,
                 DEFERRED_INTEREST	,DEFERRED_TAX	,PAID_DEFERRED_INTEREST	,PAID_DEFERRED_TAX	,TAHSIL_TAKSIT	,TAHSIL_ANAPARA	,TAHSIL_FAIZ	,TAHSIL_KKDF	,TAHSIL_BSMV	,TAHSIL_GECIKME_FAIZ_TUTARI	,DEFERRED_TAX2	,PAID_DEFERRED_TAX2	,TAHAKKUK_EH	,
                 PENALTY_AMOUNT	,PAID_PENALTY_AMOUNT	,DEFERRED_PENALTY_AMOUNT	,PAID_DEFERRED_PENALTY_AMOUNT	,AP_GECIKME_GUN_SAYISI	,FAIZ_GECIKME_GUN_SAYISI	,DEFERRED_DELAYED_INTEREST	,PAID_DEFERRED_DELAYED_INTEREST	,PAID_DEFERRED_PENALTY_TAX	,PAID_NONACCRUAL_DEFERRED_TAX	,PAID_NONACCRUAL_DEFERRED_DELAY_TAX	
            from  cbs_hesap_kredi_taksit_islem
            where tx_no = pn_islem_no ;

            insert into  CBS_HESAP_KREDI_OZEL_TKST (YARATAN_TX_NO, HESAP_NO, TAKSIT_SIRA_NO, ODEME, YARATILDIGI_TARIH, YARATAN_KULLANICI ,TAKSIT_TIPI)  --seval.colak 20012022
            select nvl(YARATAN_TX_NO,pn_islem_no), nvl(HESAP_NO,r_hesap.hesap_no), TAKSIT_SIRA_NO, ODEME, nvl(YARATILDIGI_TARIH,sysdate),nvl( YARATAN_KULLANICI,user), TAKSIT_TIPI --seval.colak 20012022
            from  CBS_HESAP_KREDI_OZEL_TKST_ISL
            where tx_no = pn_islem_no ;

       exception when no_data_found then  null;
       end ;
    end if;
    --b-o-m seval.colak  22062022    
     if r_hesap.GERIODEME_KAPAMA_SECIMI in ( 'KAPAMA') THEN          
            update  cbs_hesap_kredi_taksit_islem
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul,
                    tahsil_anapara = nvl(anapara,0),
                    tahsil_faiz = nvl(faiz,0) , 
                    tahsil_bsmv = nvl(bsmv,0) ,
                    tahsil_gecikme_faiz_tutari = nvl(gecikme_faiz_tutari,0) ,
                    paid_penalty_amount =  nvl(penalty_amount,0) ,
                    paid_deferred_penalty_amount =  nvl(deferred_penalty_amount,0) ,  
                    paid_deferred_interest =  nvl(deferred_interest,0),
                    paid_deferred_delayed_interest =  nvl(deferred_delayed_interest,0) ,
                    paid_deferred_tax =  nvl(deferred_tax,0)       
            where   tx_no = pn_islem_no and TAKSIT_SECILDI = 'E' AND  hesap_no=r_hesap.hesap_no and 
                    durum_kodu ='A' ;       
                    
            update  cbs_hesap_kredi_taksit
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul,
                    tahsil_anapara = nvl(anapara,0),
                    tahsil_faiz = nvl(faiz,0) , 
                    tahsil_bsmv = nvl(bsmv,0) ,
                    tahsil_gecikme_faiz_tutari = nvl(gecikme_faiz_tutari,0) ,
                    paid_penalty_amount =  nvl(penalty_amount,0) ,
                    paid_deferred_penalty_amount =  nvl(deferred_penalty_amount,0) ,  
                    paid_deferred_interest =  nvl(deferred_interest,0),
                    paid_deferred_delayed_interest =  nvl(deferred_delayed_interest,0) ,
                    paid_deferred_tax =  nvl(deferred_tax,0)   
            where   hesap_no=r_hesap.hesap_no and 
                    durum_kodu ='A' ;   
                    
                    
      --b-o-m  seval.colak 23062022  accrual ,nonaccrual hesaplarin kapatilmasi
              if   abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no)) = 0  then
                    update cbs_hesap_kredi
                    set     durum_kodu = 'K',
                            kapanis_tarihi =pkg_muhasebe.banka_tarihi_bul
                    where hesap_no = r_hesap.accrual_int_account_no;
               end if;
               
               if   abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_tax_account_no)) = 0  then
                    update cbs_hesap_kredi
                    set     durum_kodu = 'K',
                            kapanis_tarihi =pkg_muhasebe.banka_tarihi_bul
                    where hesap_no = r_hesap.accrual_tax_account_no;
               end if;       
              
               if   abs(pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no)) = 0  then
                    update cbs_hesap_kredi
                    set     durum_kodu = 'K',
                            kapanis_tarihi =pkg_muhasebe.banka_tarihi_bul
                    where hesap_no = r_hesap.accrual_delayed_int_account_no;
               end if;     
              
                if   abs(pkg_hesap.hesapbakiyeal(r_hesap.nonaccrual_int_account_no)) = 0   then
                    update cbs_hesap_kredi
                    set     durum_kodu = 'K',
                            kapanis_tarihi =pkg_muhasebe.banka_tarihi_bul
                    where hesap_no = r_hesap.nonaccrual_int_account_no;
               end if;     
               if   abs(pkg_hesap.hesapbakiyeal(r_hesap.nonaccrual_delayed_int_account_no)) = 0  then
                    update cbs_hesap_kredi
                    set     durum_kodu = 'K',
                            kapanis_tarihi =pkg_muhasebe.banka_tarihi_bul
                    where hesap_no = r_hesap.nonaccrual_delayed_int_account_no;
               end if;  
               --e-o-m  seval.colak 23062022  accrual ,nonaccrual hesaplarin kapatilmasi    
     end if;


       SELECT COUNT(*)
       into ln_taksit_sayisi
       FROM cbs_hesap_kredi_taksit
       where hesap_no = r_hesap.hesap_no;

      UPDATE   cbs_hesap_kredi
      SET   TAKSIT_SAYISI =ln_taksit_sayisi
      where hesap_no = r_hesap.hesap_no;

    update cbs_hesap_kredi
    set durum_kodu = decode(r_hesap.GERIODEME_KAPAMA_SECIMI,'KAPAMA','K',durum_kodu),
       kapanis_tarihi =decode(r_hesap.GERIODEME_KAPAMA_SECIMI,'KAPAMA',pkg_muhasebe.banka_tarihi_bul,kapanis_tarihi),
        kredi_vade =   decode(r_hesap.GERIODEME_KAPAMA_SECIMI,'ARA',R_HESAP.kredi_vade,kredi_vade),
        birikmis_faiz_tutari=decode(r_hesap.GERIODEME_KAPAMA_SECIMI,'KAPAMA',0,BIRIKMIS_FAIZ_TUTARI),
        birikmis_faiz_tutari_round=decode(r_hesap.GERIODEME_KAPAMA_SECIMI,'KAPAMA',0,BIRIKMIS_FAIZ_TUTARI_ROUND)
       where hesap_no = r_hesap.hesap_no;

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number)
  is
  Begin
        pkg_kredi.iptal_onay_sonrasi(pn_islem_no); --seval.colak 05102022
  End;

  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin
    update cbs_hesap_kredi_islem
    set durum_kodu = 'R'
    where tx_no = pn_islem_no;

    update cbs_hesap_kredi_taksit_islem
       set durum_kodu = 'R'
     where tx_no = pn_islem_no;
/* teminat islem Durum guncellenir */
    pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
    PKG_KUR_REZERVASYON.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
      Null;
  End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

 Procedure Muhasebelesme(pn_islem_no number)
 is
    varchar_list               pkg_muhasebe.varchar_array;
    number_list                   pkg_muhasebe.number_array;
    date_list                   pkg_muhasebe.date_array;
    boolean_list               pkg_muhasebe.boolean_array;
    ln_fis_no                   cbs_fis.numara%type ;
    ls_islem_kod               cbs_islem.islem_kod%type :='3251';
    ls_banka_aciklama          varchar2(2000);
    ls_fis_aciklama               varchar2(2000);
    ls_aciklama                varchar2(2000);
    ls_musteri_aciklama        varchar2(2000);

    ls_dk_grup_kod            cbs_musteri.DK_GRUP_KOD%type;
    ls_modul_tur_kod        cbs_hesap.modul_tur_kod%type;
    ls_urun_tur_kod            cbs_hesap.urun_tur_kod%type;
    ls_urun_sinif_kod        cbs_hesap.urun_sinif_kod%type;
    iliskili_faiz_dk_yok       exception;
    iliskili_faizrees_dk_yok   exception;
    iliskili_kom_dk_yok          exception;
    iliskili_komrees_dk_yok    exception;
    ln_rezervasyon_no           number;

    ln_kont1                     number:= 0;
    ln_kont2                     number:= 0;

    ls_geriodeme_kapama_secimi varchar2(2000);
    ls_tahsil_doviz               varchar2(2000);
    ls_kredi_doviz                varchar2(2000);
    ln_musteri_kur               NUMBER := 0;
    ln_maliyet_kur               NUMBER := 0;
    ln_fark_kur                   NUMBER := 0;
    ln_gecen_yil_faiz              NUMBER := 0;
    ln_toplam_faiz               NUMBER := 0;
    ln_araodeme_tutari           NUMBER := 0;
    ls_iliskili_gl_no           varchar2(8);
    --Yerzhan Tanatov
    ln_gecmis_aylarin_faizi    number := 0;
    ln_gecmis_aylarin_faizi_lc    number := 0;
    ln_rate     number;
    ln_rate_last_year number ;
   cursor islem_cursor is
        select
           pkg_musteri.sf_musteri_dk_grup_kod_al(musteri_no),
           rezervasyon_no,
           modul_tur_kod,
            urun_tur_kod,
           urun_sinif_kod,
              kur,
              iliskili_hesap_no,
           iliskili_gl_no,
           pkg_hesap.hesaptansubeal(iliskili_hesap_no),
           pkg_hesap.hesaptandovizkodual(iliskili_hesap_no),
              pkg_tx.Amir_BolumKodu_Al( TX_NO),
           doviz_kodu,
           hesap_no,
           pkg_hesap.hesaptansubeal(hesap_no),
           to_char(hesap_no),
           GERIODEME_KAPAMA_SECIMI,
           tahsil_hesap_no,
           tahsil_hesap_doviz,
           ISTATISTIK_KODU_faiz istatistik_kodu_faiz ,
           ISTATISTIK_KODU_kapama istatistik_kodu_kapama,
           abs(nvl(toplam_faiz,0)) +  abs(nvl(ERKEN_ODEME_KOMISYON,0)),
           abs(nvl(ERKEN_ODEME_KOMISYON,0)),
           0 , -- abs(nvl(GECENYIL_FAIZ_TUTARI,0)) + abs(nvl(GECMIS_AYLARIN_FAIZI,0)), --seval.colak 17062022  gecenyil ve gecmisaylar 0 olarak kabul edilecek kullanilmayacak
           abs(nvl(toplam_faiz,0)),
           nvl(tahsil_anapara,0) tahsil_anapara,  --seval.colak 14062022   ARAODEME_TUTARI yerine tahsil_anapara
           aciklama,
           0,-- abs(nvl(GECMIS_AYLARIN_FAIZI,0)), --seval.colak 17062022  gecenyil ve gecmisaylar 0 olarak kabul edilecek kullanilmayacak
           case when nvl(tahsil_hesap_no,0) <> 0 then  PKG_HESAP.HESAPTANSUBEAL( tahsil_hesap_no) else  pkg_hesap.hesaptansubeal(hesap_no) end tahsil_hesap_sube,
           abs(nvl(ERKEN_ODEME_KOMISYON_TAX,0)), --seval.colak 17062022
           ABS(nvl(tahsil_anapara,0))  --seval.colak 20062022
     from cbs_hesap_kredi_islem
     where tx_no = pn_islem_no ;

 ---------------   
    ld_banka_tarihi                         DATE :=Pkg_Muhasebe.Banka_Tarihi_Bul;
    ln_islem_kod                            number := 3251;       
    ln_pastdue_tax_hesap_no                 number := 0;
    ln_pastdue_faiz_hesap_no                number := 0;
    ls_hata_var                             VARCHAR2(1):= 'H';
     ls_islem_aciklama                       VARCHAR2(2000);
     ls_doviz_kodu                           VARCHAR2(3);
    ls_bolum_kodu                           CBS_HESAP_KREDI.sube_kodu%TYPE;
    ln_kredi_hesap_no                       number:=0;   
    ld_kredi_vade                           date;
    ls_aciklama_month   varchar2(100);
    ls_musteri_Adi      varchar2(200);  
    ls_taksit_durum          CBS_HESAP_KREDI_Taksit.durum_kodu%type;
    ln_taksit_toplam         number := 0 ;  
    ln_tahsil_faiz   number := 0 ;
    ln_tahsil_vergi  number := 0 ;
    ln_tahakkuk_no           number;
    ln_kalan_tahsil_faiz   number := 0 ;
    ln_kalan_tahsil_vergi  number := 0 ;
    ls_tahsil_hesap_sube    varchar2(20);
    --b-0-m seval.colak 13062022
    ln_accrual_int_account_bakiye               number := 0 ;
    ln_nonaccrual_int_account_bakiye            number := 0 ;
    ln_accrual_delayed_int_bakiye               number := 0 ;
    ln_nonaccrual_delayed_int_bakiye            number := 0 ;
    ln_org_accrual_int_account_bakiye           number := 0 ;
    ln_org_nonaccrual_int_account_bakiye        number := 0 ;
    ln_org_accrual_delayed_int_bakiye           number := 0 ;
    ln_org_nonaccrual_delayed_int_bakiye        number := 0 ;
    --e-0-m seval.colak 13062022
    ln_toplam_faiz_vergi_fark                   number :=0;  --seval.colak 17062022
    ln_accrual_tax_account_bakiye               number :=0;  --seval.colak 12012023
     gecikme_faiz_dk_yok              exception;
     faiz_tahakkuk_hesapno_yok        exception;
     vergi_tahakkuk_hesapno_yok       exception;
     iliskili_hesapno_yok             exception;
     deferred_interest_dk_yok         exception;
     kur_sifir_olamaz                 exception;

   cursor cur_hesap is
    select a.* ,Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.musteri_no) dk_grup_kod ,
                pkg_hesap.HesaptanDovizKoduAl(iliskili_hesap_no) iliskili_hesap_doviz,
                pkg_hesap.kullanilabilir_bakiye_al(iliskili_hesap_no) iliskili_hesap_bakiye,
                abs(pkg_hesap.hesapbakiyeal(a.hesap_no)) kredi_bakiye                
    from CBS_HESAP_KREDI_islem a
    where tx_No = pn_islem_No ;

    r_hesap  cur_hesap%ROWTYPE;

     cursor cur_tahakkuk is
     select kredi_hesap_no,tahakkuk_no ,
             case when  abs(nvl(b.faiz_tahakkuk_tutar,0)) > abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0)) then    abs(abs(nvl(b.faiz_tahakkuk_tutar,0)) -    abs(nvl(b.faiz_tahakkuk_tutar_tahsil,0))) else 0 end   faiz_tahakkuk_tutar,
             case when  abs(nvl(b.vergi_tahakkuk_tutar,0)) > abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0)) then  abs(abs(nvl(b.vergi_tahakkuk_tutar,0)) -    abs(nvl(b.vergi_tahakkuk_tutar_tahsil,0))) else 0 end   vergi_tahakkuk_tutar
     from cbs_kredi_tahakkuk b
     where  kredi_hesap_no =ln_kredi_hesap_no and 
            BANKA_TARIHI <=ld_banka_tarihi and
            durum_kodu ='A'  
      order by tahakkuk_no ; 
      r_tahakkuk  cur_hesap%ROWTYPE;
      
 Begin

   if islem_cursor%isopen then
          close islem_cursor;
    end if;
    /* ilk degerler atanir */
        boolean_list(pn_3251_musterikur_kucukse)  := FALSE;
        boolean_list(pn_3251_tl_kredi)  := FALSE;
        boolean_list(pn_3251_tl_tahsil)  := FALSE;
        boolean_list(pn_3251_kredi_yp)  := FALSE;
        boolean_list(pn_3251_musterikur_buyukse)  := FALSE;
        boolean_list(pn_3251_yp_tahsil)  := FALSE;
        boolean_list(pn_3251_kredi_tl)  := FALSE;
        boolean_list(pn_3251_yp_kredi)  := FALSE;
        number_list(pn_3251_fark_faiz_tl)  := 0;
        number_list(pn_3251_gecenyilbdak_sch_tl)  := 0;
        number_list(pn_3251_toplam_faiz_muskur)  := 0;
        number_list(pn_3251_anapara_tahsil_muskur)  := 0;
        number_list(pn_3251_toplam_faiz_tl)  := 0;
        number_list(pn_3251_erken_odeme)  := 0;
        number_list(pn_3251_birikmis_sch_tl)  := 0;
        number_list(pn_3251_toplam_faiz)  := 0;
        number_list(pn_3251_anapara_tahsil)  := 0;
        number_list(pn_3251_kur)  := 0;
         number_list(pn_3251_faiz_tahsilat_fark)  := 0;
        number_list(pn_3251_accrual_gecikme_tax_lc)  := 0;
        number_list(pn_3251_accrual_tahsil_faiz)  := 0;
        number_list(pn_3251_nonaccr_defer_int_tax_lc)  := 0;
        number_list(pn_3251_nonaccr_def_del_int_tax)  := 0;
        number_list(pn_3251_nonaccrual_gecikme_tax)  := 0;
        number_list(pn_3251_nonaccr_defer_int_lc)  := 0;
        number_list(pn_3251_accr_defer_int_lc)  := 0;
        number_list(pn_3251_gecenyil_sch_tl)  := 0;
        number_list(pn_3251_gecenyil_faiz_tl)  := 0;
        number_list(pn_3251_anapara_tahsil_farkkur)  := 0;
        number_list(pn_3251_maliyet_kur)  := 0;
        number_list(pn_3251_erken_odeme_malkur)  := 0;
       
        number_list(pn_3251_fark_faiz)  := 0;
        number_list(pn_3251_gecenyil_faiz)  := 0;
        number_list(pn_3251_gecenyil_faiz_malkur)  := 0;
        number_list(pn_3251_fark_faiz_malkur)  := 0;
        number_list(pn_3251_anapara_tahsil_malkur)  := 0;
        number_list(pn_3251_musteri_kur)  := 0;
        number_list(pn_3251_birikmis_sch_acilis_tl)  := 0;
        number_list(pn_3251_anapara_tahsil_tl)  := 0;
        number_list(pn_3251_erken_odeme_tl)  := 0;
        number_list(pn_3251_nonaccrual_tahsil_faiz)  := 0;
        number_list(pn_3251_toplam_faiz_lc)  := 0;
        number_list(pn_3251_accr_defer_del_int_lc)  := 0;
        number_list(pn_3251_nonaccr_defer_int_tax)  := 0;
        number_list(pn_3251_gecikme_faiz_toplam)  := 0;
        number_list(pn_3251_nonaccr_defer_int)  := 0;
        number_list(pn_3251_nonaccrual_tahsil_vergi_l)  := 0;
        number_list(pn_3251_accr_defer_del_int)  := 0;
        number_list(pn_3251_defer_pen_toplam_lc)  := 0;
        number_list(pn_3251_anapara_lc)  := 0;
        number_list(pn_3251_penalty_toplam)  := 0;
        number_list(pn_3251_nonaccrual_tahsil_faiz_lc)  := 0;
        number_list(pn_3251_defer_pen_tax)  := 0;
        number_list(pn_3251_defer_penalty)  := 0;
        number_list(pn_3251_toplam_vergi)  := 0;
        number_list(pn_3251_penalty_toplam_lc)  := 0;
        number_list(pn_3251_accrual_gecikme_faiz_lc)  := 0;
        number_list(pn_3251_deferred_toplam)  := 0;
        number_list(pn_3251_accr_defer_int)  := 0;
        number_list(pn_3251_accrual_tahsil_vergi)  := 0;
        number_list(pn_3251_deferred_toplam_lc)  := 0;
        number_list(pn_3251_defer_pen_toplam)  := 0;
        number_list(pn_3251_nonaccr_def_del_int_tax_l)  := 0;
        number_list(pn_3251_toplam_vergi_lc)  := 0;
        number_list(pn_3251_nonaccr_defer_del_int)  := 0;
        number_list(pn_3251_nonaccrual_tahsil_vergi)  := 0;
        number_list(pn_3251_accrual_tahsil_faiz_lc)  := 0;
        number_list(pn_3251_deferred_tax)  := 0;
        number_list(pn_3251_deferred_tax_lc)  := 0;
        number_list(pn_3251_nonaccrual_gecikme_faiz_l)  := 0;
        number_list(pn_3251_penalty_tax)  := 0;
        number_list(pn_3251_accrual_tahsil_vergi_lc)  := 0;
        number_list(pn_3251_penalty_tax_lc)  := 0;
        number_list(pn_3251_nonaccrual_gecikme_faiz)  := 0;
        number_list(pn_3251_nonaccrual_gecikme_tax_lc)  := 0;
        number_list(pn_3251_accrual_gecikme_tax)  := 0;
        number_list(pn_3251_defer_penalty_lc)  := 0;
        number_list(pn_3251_accrual_gecikme_faiz)  := 0;
        number_list(pn_3251_nonaccr_defer_del_int_lc)  := 0;
        number_list(pn_3251_defer_pen_tax_lc)  := 0;
        number_list(pn_3251_penalty_amount)  := 0;
        number_list(pn_3251_anapara)  := 0;
        number_list(pn_3251_deferred_interest_lc)  := 0;
        number_list(pn_3251_gecikme_faiz_toplam_lc)  := 0;
        number_list(pn_3251_penalty_amount_lc)  := 0;
        number_list(pn_3251_deferred_interest)  := 0;
         number_list(pn_3251_accrual_tahsil_faiz_lm)  := 0;
        number_list(pn_3251_nonaccrual_tahsil_faiz_lm)  := 0;
        number_list(pn_3251_accrual_tahsil_vergi_lm)  := 0;
        number_list(pn_3251_nonaccr_tahsil_vergi_lm)  := 0;
        number_list(pn_3251_defer_pen_toplam_lm)  := 0;
        number_list(pn_3251_defer_pen_tax_lm)  := 0;
        number_list(pn_3251_defer_penalty_lm)  := 0;
        number_list(pn_3251_nonaccr_gecikme_faiz_lm)  := 0;
        number_list(pn_3251_nonaccr_gecikme_tax_lm)  := 0;
        number_list(pn_3251_accr_defer_int_lm)  := 0;
        number_list(pn_3251_nonaccr_defer_int_lm)  := 0;
        number_list(pn_3251_accr_defer_del_int_lm)  := 0;
        number_list(pn_3251_nonaccr_defer_del_int_lm)  := 0;
        number_list(pn_3251_nonaccr_defer_int_tax_lm)  := 0;
        number_list(pn_3251_accr_defer_int_tax_lm)  := 0;
        number_list(pn_3251_accr_def_del_int_tax_lm)  := 0;
        number_list(pn_3251_toplam_faiz_lm)  := 0;
        number_list(pn_3251_toplam_vergi_lm)  := 0;
        number_list(pn_3251_penalty_amount_lm)  := 0;
        number_list(pn_3251_anapara_lm)  := 0;
        number_list(pn_3251_deferred_interest_lm)  := 0;
        number_list(pn_3251_deferred_tax_lm)  := 0;
        number_list(pn_3251_deferred_toplam_lm)  := 0;
        number_list(pn_3251_penalty_toplam_lm)  := 0;
        number_list(pn_3251_accr_gecikme_faiz_lm)  := 0;
        number_list(pn_3251_accr_gecikme_tax_lm)  := 0;
        number_list(pn_3251_gecikme_faiz_toplam_lm)  := 0;
        number_list(pn_3251_penalty_tax_lm)  := 0;
        number_list(pn_3251_nonaccr_def_del_int_tx_lm)  := 0;
        number_list(pn_3251_accr_defer_int_tax)  := 0;
        number_list(pn_3251_accr_defer_int_tax_lc)  := 0;
        number_list(pn_3251_accr_def_del_int_tax)  := 0;
        number_list(pn_3251_accr_def_del_int_tax_l)  := 0;
        number_list(pn_3251_toplam_faiz_fark_kur)  := 0;
        number_list(pn_3251_toplam_vergi_fark_kur)  := 0;
        number_list(pn_3251_erken_odeme_kom_tax)  := 0;
        number_list(pn_3251_erken_odeme_kom_tax_lc)  := 0;
        number_list(pn_3251_erken_odeme_kom_tax_lm)  := 0;

         
        varchar_list(pn_3251_islem_sube)  := NULL; 
        varchar_list(pn_3251_ack_defer_delay_int)  := NULL; 
        varchar_list(pn_3251_kredi_hesap_sube)  := NULL; 
        varchar_list(pn_3251_istatistik_kapama)  := NULL; 
        varchar_list(pn_3251_referans)  := NULL; 
        varchar_list(pn_3251_tax_aciklama)  := NULL; 
        varchar_list(pn_3251_iliskili_hesap_doviz)  := NULL; 
        varchar_list(pn_3251_iliskili_komdk)  := NULL; 
        varchar_list(pn_3251_nonaccrual_int_acct_no)  := NULL; 
        varchar_list(pn_3251_ack_defer_delay_int_tax)  := NULL; 
        varchar_list(pn_3251_ack_defer_tax)  := NULL; 
        varchar_list(pn_3251_accrual_tax_acct_no)  := NULL; 
        varchar_list(pn_3251_ack_delay_int)  := NULL; 
        varchar_list(pn_3251_kredi_doviz)  := NULL; 
        varchar_list(pn_3251_iliskili_hesap_sube)  := NULL; 
        varchar_list(pn_3251_iliskili_faizreesdk)  := NULL; 
        varchar_list(pn_3251_fis_aciklama)  := NULL; 
        varchar_list(pn_3251_kredi_hesap_no)  := NULL; 
        varchar_list(pn_3251_iliskili_komreesdk)  := NULL; 
        varchar_list(pn_3251_iliskili_hesap_no)  := NULL; 
        varchar_list(pn_3251_iliskili_faizdk)  := NULL; 
        varchar_list(pn_3251_tahsil_hesap_no)  := NULL; 
        varchar_list(pn_3251_banka_aciklama)  := NULL; 
        varchar_list(pn_3251_iliskili_hesap_tur)  := NULL; 
        varchar_list(pn_3251_musteri_aciklama)  := NULL; 
        varchar_list(pn_3251_gecikme_faiz_gl)  := NULL; 
        varchar_list(pn_3251_ack_penalty)  := NULL; 
        varchar_list(pn_3251_ack_defer_int_tax)  := NULL; 
        varchar_list(pn_3251_ack_delay_int_tax)  := NULL; 
        varchar_list(pn_3251_ack_tax)  := NULL; 
        varchar_list(pn_3251_accrual_int_acct_no)  := NULL; 
        varchar_list(pn_3251_ack_int)  := NULL; 
        varchar_list(pn_3251_ack_penalty_tax)  := NULL; 
        varchar_list(pn_3251_nonaccrual_delay_int_acct)  := NULL; 
        varchar_list(pn_3251_ack_principial)  := NULL; 
        varchar_list(pn_3251_iliskili_faiz_dk)  := NULL; 
        varchar_list(pn_3251_ack_defer_int)  := NULL; 
        varchar_list(pn_3251_accrual_delay_int_acct_no)  := NULL; 
         varchar_list(pn_3251_TAHSIL_HESAP_SUBE)  := NULL; 
        varchar_list(pn_3251_istatistik_faiz)  := NULL; 
        varchar_list(pn_3251_tax_aciklama):= 'Accrual Tax';
        varchar_list(pn_3251_penalty_gl)  := NULL;      --seval.colak 01112022


         open islem_cursor;
           fetch islem_cursor into
                   ls_dk_grup_kod ,
                   ln_rezervasyon_no,
                   ls_modul_tur_kod,
                   ls_urun_tur_kod,
                   ls_urun_sinif_kod,
                   number_list(pn_3251_kur),
                   varchar_list(pn_3251_iliskili_hesap_no),
                   ls_iliskili_gl_no,
                   varchar_list(pn_3251_iliskili_hesap_sube),
                      varchar_list(pn_3251_iliskili_hesap_doviz),
                    varchar_list(pn_3251_islem_sube),
                   ls_kredi_doviz ,
                   varchar_list(pn_3251_kredi_hesap_no),
                   varchar_list(pn_3251_kredi_hesap_sube),
                   varchar_list(pn_3251_referans),
                   ls_geriodeme_kapama_secimi,
                   varchar_list(pn_3251_tahsil_hesap_no),
                   ls_tahsil_doviz,
                   varchar_list(pn_3251_istatistik_faiz),
                   varchar_list(pn_3251_istatistik_kapama),
                   number_list(pn_3251_toplam_faiz),
                   number_list(pn_3251_erken_odeme),
                   ln_gecen_yil_faiz,
                   ln_toplam_faiz,
                   ln_araodeme_tutari,
                   ls_fis_aciklama,
                   ln_gecmis_aylarin_faizi,
                   ls_tahsil_hesap_sube,
                   number_list(pn_3251_erken_odeme_kom_tax),
                   number_list(pn_3251_anapara_tahsil);

        varchar_list(pn_3251_kredi_doviz) := ls_kredi_doviz ;

        if varchar_list(pn_3251_iliskili_hesap_no) is not null then
           varchar_list(pn_3251_ILISKILI_HESAP_TUR):='VS';
        elsif ls_iliskili_gl_no is not null then
            varchar_list(pn_3251_iliskili_hesap_no):=ls_iliskili_gl_no;
            varchar_list(pn_3251_iliskili_hesap_sube):=varchar_list(pn_3251_kredi_hesap_sube);
            varchar_list(pn_3251_ILISKILI_HESAP_TUR):='DK';
            varchar_list(pn_3251_iliskili_hesap_doviz):=varchar_list(pn_3251_kredi_doviz);
        end if;

         if nvl(ln_rezervasyon_no,0) <> 0 then
            /*rezervasyonlu */
                pkg_kur_rezervasyon.rezervasyon_satis_bilgisi_al(ln_rezervasyon_no,ln_musteri_kur,ln_maliyet_kur);
                number_list(pn_3251_kur) := nvl(ln_musteri_kur,0);                      
        else
                --ln_musteri_kur := pkg_kur.doviz_doviz_karsilik(ls_kredi_doviz,pkg_genel.LC_AL,null,1,1,null,null,'N','A'); --m??teri al??  --seval.colak 16062022 kapatildi alttaki 1306dan alinip eklendi.                
                 IF ls_kredi_doviz <> Pkg_Genel.lc_al AND ls_tahsil_doviz = Pkg_Genel.lc_al THEN
                     ln_musteri_kur:=Pkg_Kur.doviz_doviz_karsilik(ls_kredi_doviz ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','S');
                   ELSE
                   ln_musteri_kur:=Pkg_Kur.doviz_doviz_karsilik(ls_kredi_doviz ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
                 END IF;                
                
                ln_maliyet_kur := pkg_kur.doviz_doviz_karsilik(ls_kredi_doviz,pkg_genel.LC_AL,null,1,3,null,null,'N','S'); --maliyet esas al??
                                        
                number_list(pn_3251_kur) :=ln_musteri_kur;
        end if;
        
         if   nvl(ln_musteri_kur,0) = 0 or  nvl(ln_maliyet_kur,0) = 0 then 
                raise kur_sifir_olamaz ;
          end if;      
          
         number_list(pn_3251_maliyet_kur) := ln_maliyet_kur;
        number_list(pn_3251_musteri_kur) :=ln_musteri_kur;
        
        ln_fark_kur := abs( nvl(ln_musteri_kur,0) - nvl(ln_maliyet_kur,0));
        
        Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
        Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_rate_last_year); --sevalb24122010
  
/**** varchar list ****/
   ls_islem_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(ln_islem_kod) ;  
   ls_aciklama := ls_islem_aciklama;
   pkg_parametre.deger('3251_BANKA_ACIKLAMA',ls_banka_aciklama)  ;
   pkg_parametre.deger('3251_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   varchar_list(pn_3251_fis_aciklama) := ls_aciklama;
   varchar_list(pn_3251_banka_aciklama)  := nvl(ls_fis_aciklama,ls_aciklama);
   varchar_list(pn_3251_musteri_aciklama):= nvl(ls_fis_aciklama,ls_aciklama);
 
/*****DK ***/
--if  nvl(number_list(pn_3251_birikmis_faiz),0) <> 0 then
    PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
                        null,null, null,varchar_list(pn_3251_iliskili_faizdk));

      if     varchar_list(pn_3251_iliskili_faizdk) is null then
              raise iliskili_faiz_dk_yok;
      end if;
-- end if;

/*faiz reeskont dk */
 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
                        null,null, null,varchar_list(pn_3251_iliskili_faizreesdk));
      if     varchar_list(pn_3251_iliskili_faizreesdk) is null and nvl(number_list(pn_3251_gecenyil_faiz),0)  <> 0 then
              raise iliskili_faizrees_dk_yok;
      end if;

       Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
                        lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 5,
                        NULL,NULL, NULL,varchar_list(pn_3251_iliskili_komdk));

      if     varchar_list(pn_3251_iliskili_komdk) is null and nvl(number_list(pn_3251_erken_odeme),0)   <> 0 then
              raise iliskili_kom_dk_yok ;
      end if;
      
   -- B-O-M seval.colak 30052022      
   for c_hesap in cur_hesap loop
        r_hesap := c_hesap;
   end loop;     
  
        ln_kredi_hesap_no   := r_hesap.hesap_no;        
        ls_doviz_kodu       := r_hesap.doviz_kodu;
        
     if ls_doviz_kodu = pkg_genel.lc_al then
        boolean_list(pn_3251_kredi_tl) := true;
    else
        boolean_list(pn_3251_kredi_yp) := true;
    end if;        

    varchar_list(pn_3251_iliskili_faiz_dk)      := null; 
    varchar_list(pn_3251_tahsil_hesap_sube)     :=ls_tahsil_hesap_sube; 
    varchar_list(pn_3251_islem_sube)            := r_hesap.sube_kodu; 
    varchar_list(pn_3251_kredi_doviz)           := r_hesap.doviz_kodu; 
    varchar_list(pn_3251_kredi_hesap_no)        := r_hesap.hesap_no; 
    varchar_list(pn_3251_kredi_hesap_sube)      := r_hesap.sube_kodu;            
    varchar_list(pn_3251_referans)              := r_hesap.hesap_no; 
    varchar_list(pn_3251_iliskili_hesap_doviz)  := pkg_hesap.hesaptandovizkodual(r_hesap.iliskili_hesap_no);   
    varchar_list(pn_3251_iliskili_hesap_no)     := r_hesap.iliskili_hesap_no; 
    varchar_list(pn_3251_iliskili_hesap_sube)   := pkg_hesap.hesaptansubeal(r_hesap.iliskili_hesap_no);        

    varchar_list(pn_3251_accrual_int_acct_no)    := r_hesap.accrual_int_account_no; 
    varchar_list(pn_3251_accrual_tax_acct_no)    := r_hesap.accrual_tax_account_no; 
    varchar_list(pn_3251_accrual_delay_int_acct_no)  := r_hesap.accrual_delayed_int_account_no; 
    varchar_list(pn_3251_nonaccrual_int_acct_no)  := r_hesap.nonaccrual_int_account_no; 
    varchar_list(pn_3251_nonaccrual_delay_int_acct)  := r_hesap.nonaccrual_delayed_int_account_no;
    
  -------------------------      
    ls_bolum_kodu   := varchar_list(pn_3251_kredi_hesap_sube);
    ls_aciklama     := substr(ls_bolum_kodu || ' ' || ls_fis_aciklama || ls_islem_aciklama,1,200) ;
    varchar_list(pn_3251_fis_aciklama) := ls_aciklama ;
    
    ls_doviz_kodu   := varchar_list(pn_3251_kredi_doviz);
    ln_kredi_hesap_no     := varchar_list(pn_3251_kredi_hesap_no);
    varchar_list(pn_3251_banka_aciklama)  := TO_CHAR(ln_kredi_hesap_no) || ' ' || ls_banka_aciklama || ls_islem_aciklama ;
   -- varchar_list(pn_3251_musteri_aciklama):=  TO_CHAR(ln_kredi_hesap_no) ||  ' '|| ls_musteri_aciklama || ls_islem_aciklama ; --seval.colak 15112022 
     varchar_list(pn_3251_musteri_aciklama):=  substr(nvl(ls_fis_aciklama,ls_aciklama),1,200); -- --seval.colak 15112022 ekrandan girilen deger olmasi istendi
    varchar_list(pn_3251_tax_aciklama) :=  varchar_list(pn_3251_musteri_aciklama); -- 'Loan Payment - '||TO_CHAR(ln_kredi_hesap_no) ;
  
              
    --B-O-M seval.colak 13062022
        ln_nonaccrual_int_account_bakiye := pkg_hesap.hesapbakiyeal(r_hesap.nonaccrual_int_account_no) ;
        ln_accrual_int_account_bakiye    := pkg_hesap.hesapbakiyeal(r_hesap.accrual_int_account_no) ;
        ln_nonaccrual_delayed_int_bakiye := pkg_hesap.hesapbakiyeal(r_hesap.nonaccrual_delayed_int_account_no) ;
        ln_accrual_delayed_int_bakiye    := pkg_hesap.hesapbakiyeal(r_hesap.accrual_delayed_int_account_no) ; 
        ln_accrual_tax_account_bakiye    :=pkg_hesap.hesapbakiyeal(r_hesap.accrual_tax_account_no) ; --seval.colak 12012023
        
        ln_org_nonaccrual_int_account_bakiye := ln_nonaccrual_int_account_bakiye;
        ln_org_accrual_int_account_bakiye    := ln_accrual_int_account_bakiye;
        ln_org_nonaccrual_delayed_int_bakiye := ln_nonaccrual_delayed_int_bakiye;
        ln_org_accrual_delayed_int_bakiye    := ln_accrual_delayed_int_bakiye ;
      
   --E-O-M seval.colak 13062022
                          
   -- 1. 'DEFERRED-INTEREST-TAX'     
      -- seval.colak 20122022  oncelikle accrual amountdan alinacak sekilde logic degistirildi.
           if nvl(r_hesap.tahsil_deferred_interest,0) > 0 then 
                        select   case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                            abs(nvl(r_hesap.tahsil_deferred_interest,0) ) 
                        else --  non_accrual_status Y ise accrual bakiyeden alacak
                           (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_deferred_interest,0)  > 0 and  ln_accrual_int_account_bakiye <= 0  then 
                                  case when  abs(nvl(r_hesap.tahsil_deferred_interest,0) ) >  abs(ln_accrual_int_account_bakiye) then
                                             abs(ln_accrual_int_account_bakiye) 
                                        else
                                            abs(nvl(r_hesap.tahsil_deferred_interest,0) ) 
                                    end 
                                 else 0 
                                 end    ) --  kalan faiz - non accrual bakiye                   
                        end accrual_tahsil_deferred_interest, 
                        
                        abs(nvl(r_hesap.tahsil_deferred_interest,0) ) - (  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                            abs(nvl(r_hesap.tahsil_deferred_interest,0) ) 
                        else --  non_accrual_status Y ise accrual bakiyeden alacak
                           (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_deferred_interest,0)  > 0 and  ln_accrual_int_account_bakiye <= 0  then 
                                  case when  abs(nvl(r_hesap.tahsil_deferred_interest,0) ) >  abs(ln_accrual_int_account_bakiye) then
                                             abs(ln_accrual_int_account_bakiye) 
                                        else
                                            abs(nvl(r_hesap.tahsil_deferred_interest,0) ) 
                                    end 
                                 else 0 
                                 end    ) --  kalan faiz - non accrual bakiye                   
                        end) nonaccrual_tahsil_deferred_interest                
                        into 
                        r_hesap.accrual_tahsil_deferred_interest,
                        r_hesap.nonaccrual_tahsil_deferred_interest                                   
                        from dual;      
                             r_hesap.tahsil_accrual_deferred_tax    :=  abs(round(( nvl(r_hesap.accrual_tahsil_deferred_interest,0)  * nvl(ln_rate,0) /100),2 )) ;
                             r_hesap.tahsil_nonaccrual_deferred_tax :=  abs(round(( nvl(r_hesap.nonaccrual_tahsil_deferred_interest,0)  * nvl(ln_rate,0) /100),2 )) ;                                 
                     
                         
                         ln_accrual_int_account_bakiye :=  abs(nvl(ln_accrual_int_account_bakiye,0)) -   abs(nvl(r_hesap.accrual_tahsil_deferred_interest ,0)) ;            --seval.colak 13062022                   
                         ln_nonaccrual_int_account_bakiye :=  abs(nvl(ln_nonaccrual_int_account_bakiye,0)) -   abs(nvl(r_hesap.nonaccrual_tahsil_deferred_interest ,0)) ;            --seval.colak 13062022            
                     
                        if     nvl(ln_org_accrual_int_account_bakiye,0)  < 0  then 
                                ln_accrual_int_account_bakiye :=  nvl(ln_accrual_int_account_bakiye,0) * -1;
                         end if; 
                          if     nvl(ln_org_nonaccrual_int_account_bakiye,0)  <0  then 
                                ln_nonaccrual_int_account_bakiye :=  nvl(ln_nonaccrual_int_account_bakiye,0) * -1;
                         end if;   
                 end if; 
                 
--2. 'DEFERRED-DELAYED-INTEREST-TAX'   
       -- seval.colak 20122022  oncelikle accrual amountdan alinacak sekilde logic degistirildi.   
            if nvl(r_hesap.tahsil_deferred_delayed_interest,0) > 0 then 
                select  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                    abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) 
                                else --  non_accrual_status Y ise nonaccrual bakiyeden kalan olacak
                                       (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_deferred_delayed_interest,0) > 0 and  ln_accrual_delayed_int_bakiye <= 0  then 
                                          case when  abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) >  abs(ln_accrual_delayed_int_bakiye) then
                                                     abs(ln_accrual_delayed_int_bakiye) 
                                                else
                                                    abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) 
                                            end 
                                         else 0 
                                         end    ) --  kalan faiz - non accrual bakiye                   
                                end accrual_tahsil_deferred_delayed_interest, 
                                abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) -  ( case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                                    abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) 
                                else --  non_accrual_status Y ise nonaccrual bakiyeden kalan olacak
                                       (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_deferred_delayed_interest,0) > 0 and  ln_accrual_delayed_int_bakiye <= 0  then 
                                          case when  abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) >  abs(ln_accrual_delayed_int_bakiye) then
                                                     abs(ln_accrual_delayed_int_bakiye) 
                                                else
                                                    abs(nvl(r_hesap.tahsil_deferred_delayed_interest,0)) 
                                            end 
                                         else 0 
                                         end    )                   
                                end)  nonaccrual_tahsil_deferred_delayed_interest
                into 
                                r_hesap.accrual_tahsil_deferred_delayed_int,
                                r_hesap.nonaccrual_tahsil_deferred_delayed_int
                from dual; 
                                   r_hesap.tahsil_accrual_deferred_delay_tax    :=  abs(round(( nvl(r_hesap.accrual_tahsil_deferred_delayed_int,0)  * nvl(ln_rate,0) /100),2 )) ;
                                   r_hesap.tahsil_nonaccrual_deferred_delay_tax :=  abs(round(( nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int,0)  * nvl(ln_rate,0) /100),2 )) ;                                     
                         
             ln_accrual_delayed_int_bakiye :=  abs(nvl(ln_accrual_delayed_int_bakiye,0)) -   abs(nvl(r_hesap.accrual_tahsil_deferred_delayed_int ,0)) ;            --seval.colak 13062022                   
             ln_nonaccrual_delayed_int_bakiye :=  abs(nvl(ln_nonaccrual_delayed_int_bakiye,0)) -   abs(nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int ,0)) ;            --seval.colak 13062022     
             if   nvl(ln_org_accrual_delayed_int_bakiye,0)  < 0  then 
                    ln_accrual_delayed_int_bakiye :=  nvl(ln_accrual_delayed_int_bakiye,0) * -1;
             end if; 
              if     nvl(ln_org_nonaccrual_delayed_int_bakiye,0)  <0  then 
                    ln_nonaccrual_delayed_int_bakiye :=  nvl(ln_nonaccrual_delayed_int_bakiye,0) * -1;
             end if;  
        
          end if;   
          
 --3. 'INTEREST-TAX'     
  -- seval.colak 20122022  oncelikle accrual amountdan alinacak sekilde logic degistirildi.
           if nvl(r_hesap.tahsil_faiz,0)  > 0 then                              
                    select   case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                    abs(nvl(r_hesap.tahsil_faiz,0) ) 
                    else --  non_accrual_status Y ise accrual bakiyeden alacak
                    (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_faiz,0)  > 0 and  ln_accrual_int_account_bakiye <= 0  then 
                          case when  abs(nvl(r_hesap.tahsil_faiz,0) ) >  abs(ln_accrual_int_account_bakiye) then
                                     abs(ln_accrual_int_account_bakiye) 
                                else
                                    abs(nvl(r_hesap.tahsil_faiz,0) ) 
                            end 
                         else 0 
                         end    ) --  kalan faiz - non accrual bakiye                   
                    end accrual_tahsil_faiz, 
                    abs(nvl(r_hesap.tahsil_faiz,0) ) - (  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                    abs(nvl(r_hesap.tahsil_faiz,0) ) 
                    else --  non_accrual_status Y ise accrual bakiyeden alacak
                    (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_faiz,0)  > 0 and  ln_accrual_int_account_bakiye <= 0  then 
                          case when  abs(nvl(r_hesap.tahsil_faiz,0) ) >  abs(ln_accrual_int_account_bakiye) then
                                     abs(ln_accrual_int_account_bakiye) 
                                else
                                    abs(nvl(r_hesap.tahsil_faiz,0) ) 
                            end 
                         else 0 
                         end    ) --  kalan faiz - non accrual bakiye                   
                    end) nonaccrual_tahsil_faiz                                 
                    into 
                    r_hesap.accrual_tahsil_faiz,
                    r_hesap.nonaccrual_tahsil_faiz                                                                    
                    from dual;  
                    
                    ln_accrual_int_account_bakiye :=  abs(nvl(ln_accrual_int_account_bakiye,0)) -   abs(nvl(r_hesap.accrual_tahsil_faiz ,0)) ;            --seval.colak 13062022                   
                    ln_nonaccrual_int_account_bakiye :=  abs(nvl(ln_nonaccrual_int_account_bakiye,0)) -   abs(nvl(r_hesap.nonaccrual_tahsil_faiz ,0)) ;            --seval.colak 13062022

                    if     nvl(ln_org_accrual_int_account_bakiye,0)  < 0  then 
                        ln_accrual_int_account_bakiye :=  nvl(ln_accrual_int_account_bakiye,0) * -1;
                    end if; 
                    if     nvl(ln_org_nonaccrual_int_account_bakiye,0)  <0  then 
                        ln_nonaccrual_int_account_bakiye :=  nvl(ln_nonaccrual_int_account_bakiye,0) * -1;
                    end if;   
            end if; 
            
        
               if  abs(nvl(r_hesap.tahsil_vergi ,0)) > 0 then      --seval.colak 02022023                     
                     r_hesap.accrual_tahsil_vergi                 := abs(round((  nvl(r_hesap.accrual_tahsil_Faiz,0)  * nvl(ln_rate,0) /100),2 )) ; 
                     r_hesap.nonaccrual_tahsil_vergi              := abs(round((  nvl(r_hesap.nonaccrual_tahsil_faiz,0)  * nvl(ln_rate,0) /100),2 )) ;
                    
                      if r_hesap.accrual_tahsil_vergi > r_hesap.tahsil_Vergi  then
                             r_hesap.accrual_tahsil_vergi :=  r_hesap.tahsil_Vergi ;
                        end if;                 
                         r_hesap.nonaccrual_tahsil_vergi:= abs( nvl(r_hesap.tahsil_Vergi,0) - nvl(r_hesap.accrual_tahsil_vergi,0))  ;                                   
                          -- e-o-m seval.colak 01022023
                         r_hesap.tahsil_Vergi :=  nvl(r_hesap.accrual_tahsil_vergi,0)  +  nvl(r_hesap.nonaccrual_tahsil_vergi,0) ; 
                       else
                       r_hesap.accrual_tahsil_vergi := 0;
                       r_hesap.nonaccrual_tahsil_vergi := 0;
                end if;    
                 
          
 --4. 'DELAYED-INTEREST-TAX'      
-- seval.colak 20122022  oncelikle accrual amountdan alinacak sekilde logic degistirildi. 
    if  nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) > 0 then 
            select   case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                        abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) 
                 else --  non_accrual_status Y ise accrual bakiyeden alacak
                       (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0)  > 0 and  ln_accrual_delayed_int_bakiye <= 0  then 
                              case when  abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) >  abs(ln_accrual_delayed_int_bakiye) then
                                         abs(ln_accrual_delayed_int_bakiye) 
                                    else
                                        abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) 
                                end 
                             else 0 
                             end    ) --  kalan faiz - non accrual bakiye                   
                end accrual_tahsil_birikmis_gecikme_faiz, 
              abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) - (  case when nvl(r_hesap.non_accrual_status,'N') ='N' then 
                        abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) 
                 else --  non_accrual_status Y ise accrual bakiyeden alacak
                       (case when nvl(r_hesap.non_accrual_status,'N') ='Y' and nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0)  > 0 and  ln_accrual_delayed_int_bakiye <= 0  then 
                              case when  abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) >  abs(ln_accrual_delayed_int_bakiye) then
                                         abs(ln_accrual_delayed_int_bakiye) 
                                    else
                                        abs(nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) ) 
                                end 
                             else 0 
                             end    ) --  kalan faiz - non accrual bakiye                   
                end) nonaccrual_tahsil_birikmis_gecikme_faiz   
            into 
            r_hesap.accrual_tahsil_gecikme_faiz,
            r_hesap.nonaccrual_tahsil_gecikme_faiz
            from dual;   
                       
                       r_hesap.accrual_tahsil_gecikme_faiz_tax    :=  abs(round(( nvl(r_hesap.accrual_tahsil_gecikme_faiz,0)  * nvl(ln_rate,0) /100),2 )) ;
                       r_hesap.nonaccrual_tahsil_gecikme_faiz_tax :=  abs(round(( nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz,0)  * nvl(ln_rate,0) /100),2 ));    
                
                 ln_accrual_delayed_int_bakiye :=  abs(nvl(ln_accrual_delayed_int_bakiye,0)) -   abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz ,0)) ;            --seval.colak 13062022                   
                 ln_nonaccrual_delayed_int_bakiye :=  abs(nvl(ln_nonaccrual_delayed_int_bakiye,0)) -   abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz ,0)) ;            --seval.colak 13062022            
               
                 if   nvl(ln_org_accrual_delayed_int_bakiye,0)  < 0  then 
                        ln_accrual_delayed_int_bakiye :=  nvl(ln_accrual_delayed_int_bakiye,0) * -1;
                 end if; 
                  if     nvl(ln_org_nonaccrual_delayed_int_bakiye,0)  <0  then 
                        ln_nonaccrual_delayed_int_bakiye :=  nvl(ln_nonaccrual_delayed_int_bakiye,0) * -1;
                 end if;  
            end if;  
            
    number_list(pn_3251_anapara)                    :=  abs(nvl(r_hesap.tahsil_anapara,0));
    number_list(pn_3251_anapara_lc)                 :=  pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_3251_anapara)  * ln_musteri_kur);
    number_list(pn_3251_anapara_lm)                 :=  pkg_kur.yuvarla(pkg_genel.lc_al, number_list(pn_3251_anapara)  * ln_maliyet_kur);
    
    number_list(pn_3251_deferred_interest)          :=  abs(nvl(r_hesap.tahsil_deferred_interest,0));
    number_list(pn_3251_deferred_interest_lc)       :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_deferred_interest)  * ln_musteri_kur);
    number_list(pn_3251_deferred_interest_lm)       :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_deferred_interest)  * ln_maliyet_kur);
   
    number_list(pn_3251_deferred_tax)               :=  abs(nvl(r_hesap.tahsil_deferred_tax,0));
    number_list(pn_3251_deferred_tax_lc)             :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_deferred_tax)  * ln_musteri_kur);
    number_list(pn_3251_deferred_tax_lm)             :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_deferred_tax)  * ln_maliyet_kur);
    
    number_list(pn_3251_penalty_amount)              :=  abs(nvl(r_hesap.tahsil_penalty_amount,0));   
    number_list(pn_3251_penalty_amount_lc)           :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_penalty_amount)  * ln_musteri_kur);
    number_list(pn_3251_penalty_amount_lm)           :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_penalty_amount)  * ln_maliyet_kur);
        
    number_list(pn_3251_penalty_tax)                 :=  abs(nvl(r_hesap.tahsil_penalty_tax,0));   
    number_list(pn_3251_penalty_tax_lc)              :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_penalty_tax)  * ln_musteri_kur);   
    number_list(pn_3251_penalty_tax_lm)              :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_penalty_tax)  * ln_maliyet_kur);  
     
    number_list(pn_3251_accr_defer_int)              :=  abs(nvl(r_hesap.accrual_tahsil_deferred_interest,0)); --seval.colak 17122021
    number_list(pn_3251_accr_defer_int_lc)           :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_int)  * ln_musteri_kur);
     number_list(pn_3251_accr_defer_int_lm)           :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_int)  * ln_maliyet_kur);
     
    number_list(pn_3251_nonaccr_defer_int)           :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_interest,0)); --seval.colak 17122021
    number_list(pn_3251_nonaccr_defer_int_lc)        :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_int)  * ln_musteri_kur);
    number_list(pn_3251_nonaccr_defer_int_lm)        :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_int)  * ln_maliyet_kur);
    
    number_list(pn_3251_accr_defer_del_int)          :=  abs(nvl(r_hesap.accrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
    number_list(pn_3251_accr_defer_del_int_lc)       :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_del_int) * ln_musteri_kur);
    number_list(pn_3251_accr_defer_del_int_lm)       :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_del_int)  * ln_maliyet_kur);
    
  
    
    number_list(pn_3251_nonaccr_defer_del_int)       :=  abs(nvl(r_hesap.nonaccrual_tahsil_deferred_delayed_int,0)); --seval.colak 17122021
    number_list(pn_3251_nonaccr_defer_del_int_lc)    :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_del_int)  * ln_musteri_kur);
    number_list(pn_3251_nonaccr_defer_del_int_lm)    :=   pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_del_int)  * ln_maliyet_kur);
               
    number_list(pn_3251_nonaccr_defer_int_tax)      := abs(nvl(r_hesap.tahsil_nonaccrual_deferred_tax,0));--seval.colak 28042022 
    number_list(pn_3251_nonaccr_defer_int_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_int_tax)  * ln_musteri_kur);
    number_list(pn_3251_nonaccr_defer_int_tax_lm)   :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_defer_int_tax)  * ln_maliyet_kur);
    
    number_list(pn_3251_nonaccr_def_del_int_tax)    :=  abs(nvl(r_hesap.tahsil_nonaccrual_deferred_delay_tax,0));
    number_list(pn_3251_nonaccr_def_del_int_tax_l)  :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_def_del_int_tax)  * ln_musteri_kur);
    number_list(pn_3251_nonaccr_def_del_int_tx_lm)  :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccr_def_del_int_tax)  * ln_maliyet_kur);
     
    number_list(pn_3251_accr_defer_int_tax)      := abs(nvl(r_hesap.tahsil_accrual_deferred_tax,0));
    number_list(pn_3251_accr_defer_int_tax_lc)   := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_int_tax)  * ln_musteri_kur);
    number_list(pn_3251_accr_defer_int_tax_lm)   := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_defer_int_tax)  * ln_maliyet_kur);
    

    number_list(pn_3251_accr_def_del_int_tax)    :=  abs(nvl(r_hesap.tahsil_accrual_deferred_delay_tax,0));
    number_list(pn_3251_accr_def_del_int_tax_l)  := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_def_del_int_tax)  * ln_musteri_kur);
    number_list(pn_3251_accr_def_del_int_tax_lm)  := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accr_def_del_int_tax)  * ln_maliyet_kur);
      
    number_list(pn_3251_deferred_toplam)            := nvl(number_list(pn_3251_deferred_tax),0) + nvl(number_list(pn_3251_accr_defer_int),0) + nvl(number_list(pn_3251_accr_defer_del_int),0) + nvl(number_list(pn_3251_nonaccr_defer_int),0) + nvl(number_list(pn_3251_nonaccr_defer_del_int),0) + nvl(number_list(pn_3251_nonaccr_defer_int_tax),0)  + nvl(number_list(pn_3251_nonaccr_def_del_int_tax),0) + nvl(number_list(pn_3251_accr_defer_int_tax),0) + nvl(number_list(pn_3251_accr_def_del_int_tax),0);  
    number_list(pn_3251_deferred_toplam_lc)         := number_list(pn_3251_deferred_tax_lc) + number_list(pn_3251_accr_defer_int_lc) + number_list(pn_3251_accr_defer_del_int_lc)+ number_list(pn_3251_nonaccr_defer_int_lc) + number_list(pn_3251_nonaccr_defer_del_int_lc) + number_list(pn_3251_nonaccr_defer_int_tax_lc) +number_list(pn_3251_nonaccr_def_del_int_tax_l) +  number_list(pn_3251_accr_defer_int_tax_lc) +number_list(pn_3251_accr_def_del_int_tax_l) ;  
    number_list(pn_3251_deferred_toplam_lm)         := number_list(pn_3251_deferred_tax_lm) + number_list(pn_3251_accr_defer_int_lm) + number_list(pn_3251_accr_defer_del_int_lm)+ number_list(pn_3251_nonaccr_defer_int_lm) + number_list(pn_3251_nonaccr_defer_del_int_lm) + number_list(pn_3251_nonaccr_defer_int_tax_lm) +number_list(pn_3251_nonaccr_def_del_int_tx_lm) +  number_list(pn_3251_accr_defer_int_tax_lm) +number_list(pn_3251_accr_def_del_int_tax_lm) ; 
  
    number_list(pn_3251_penalty_toplam)             := number_list(pn_3251_penalty_amount) +  number_list(pn_3251_penalty_tax);
    number_list(pn_3251_penalty_toplam_lc)          := number_list(pn_3251_penalty_amount_lc) +  number_list(pn_3251_penalty_tax_lc);
    number_list(pn_3251_penalty_toplam_lm)          := number_list(pn_3251_penalty_amount_lm) +  number_list(pn_3251_penalty_tax_lm);
 ------------------------------------------------------------------------------------------------------------------------------------
   number_list(pn_3251_accrual_tahsil_faiz)          :=  abs(nvl(r_hesap.accrual_tahsil_faiz,0));
   number_list(pn_3251_accrual_tahsil_faiz_lc)       :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_tahsil_faiz)  * ln_musteri_kur);
   number_list(pn_3251_accrual_tahsil_faiz_lm)       :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_tahsil_faiz)  * ln_maliyet_kur);
    
   number_list(pn_3251_nonaccrual_tahsil_faiz)       :=  abs(nvl(r_hesap.nonaccrual_tahsil_faiz,0));
   number_list(pn_3251_nonaccrual_tahsil_faiz_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_tahsil_faiz)  * ln_musteri_kur);
   number_list(pn_3251_nonaccrual_tahsil_faiz_lm)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_tahsil_faiz)  * ln_maliyet_kur);
    
   number_list(pn_3251_accrual_tahsil_vergi)         :=  abs(nvl(r_hesap.accrual_tahsil_vergi,0));
   number_list(pn_3251_accrual_tahsil_vergi_lc)      :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_tahsil_vergi)  * ln_musteri_kur);
   number_list(pn_3251_accrual_tahsil_vergi_lm)      :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_tahsil_vergi)  * ln_maliyet_kur);
   
   number_list(pn_3251_nonaccrual_tahsil_vergi)      :=  abs(nvl(r_hesap.nonaccrual_tahsil_vergi,0));
   number_list(pn_3251_nonaccrual_tahsil_vergi_l)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_tahsil_vergi)  * ln_musteri_kur);
   number_list(pn_3251_nonaccr_tahsil_vergi_lm)      :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_tahsil_vergi)  * ln_maliyet_kur);
   
   number_list(pn_3251_toplam_faiz)            := number_list(pn_3251_accrual_tahsil_faiz)  + number_list(pn_3251_nonaccrual_tahsil_faiz) ;
   number_list(pn_3251_toplam_faiz_lc)         := number_list(pn_3251_accrual_tahsil_faiz_lc)  + number_list(pn_3251_nonaccrual_tahsil_faiz_lc);
   number_list(pn_3251_toplam_faiz_lm)         := number_list(pn_3251_accrual_tahsil_faiz_lm)  + number_list(pn_3251_nonaccrual_tahsil_faiz_lm);
   
   number_list(pn_3251_toplam_vergi)           := number_list(pn_3251_accrual_tahsil_vergi) + number_list(pn_3251_nonaccrual_tahsil_vergi) ;
   number_list(pn_3251_toplam_vergi_lc)        := number_list(pn_3251_accrual_tahsil_vergi_lc) + number_list(pn_3251_nonaccrual_tahsil_vergi_l) ;
   number_list(pn_3251_toplam_vergi_lm)        := number_list(pn_3251_accrual_tahsil_vergi_lm) + number_list(pn_3251_nonaccr_tahsil_vergi_lm) ;

   number_list(pn_3251_accrual_gecikme_faiz)     :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz,0));
   number_list(pn_3251_accrual_gecikme_faiz_lc)  :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_gecikme_faiz)  * ln_musteri_kur);
    number_list(pn_3251_accr_gecikme_faiz_lm)  :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_gecikme_faiz)  * ln_maliyet_kur);
    
   number_list(pn_3251_nonaccrual_gecikme_faiz)  :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz,0));
   number_list(pn_3251_nonaccrual_gecikme_faiz_l):=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_gecikme_faiz)  * ln_musteri_kur);
   number_list(pn_3251_nonaccr_gecikme_faiz_lm):=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_gecikme_faiz)  * ln_maliyet_kur);
   
   number_list(pn_3251_accrual_gecikme_tax)      :=  abs(nvl(r_hesap.accrual_tahsil_gecikme_faiz_tax,0));
   number_list(pn_3251_accrual_gecikme_tax_lc)   :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_gecikme_tax)  * ln_musteri_kur);
    number_list(pn_3251_accr_gecikme_tax_lm)   :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_accrual_gecikme_tax)  * ln_maliyet_kur);
    
   number_list(pn_3251_nonaccrual_gecikme_tax)   :=  abs(nvl(r_hesap.nonaccrual_tahsil_gecikme_faiz_tax,0));
   number_list(pn_3251_nonaccrual_gecikme_tax_lc):=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_gecikme_tax)  * ln_musteri_kur);
   number_list(pn_3251_nonaccr_gecikme_tax_lm):=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_nonaccrual_gecikme_tax)  * ln_maliyet_kur);
   
   number_list(pn_3251_gecikme_faiz_toplam)      := number_list(pn_3251_accrual_gecikme_faiz) +  number_list(pn_3251_accrual_gecikme_tax) + number_list(pn_3251_nonaccrual_gecikme_faiz) +  number_list(pn_3251_nonaccrual_gecikme_tax) ;
   number_list(pn_3251_gecikme_faiz_toplam_lc)   := number_list(pn_3251_accrual_gecikme_faiz_lc) +  number_list(pn_3251_accrual_gecikme_tax_lc) + number_list(pn_3251_nonaccrual_gecikme_faiz_l) +  number_list(pn_3251_nonaccrual_gecikme_tax_lc) ;
   number_list(pn_3251_gecikme_faiz_toplam_lm)   := number_list(pn_3251_accr_gecikme_faiz_lm) +  number_list(pn_3251_accr_gecikme_tax_lm) + number_list(pn_3251_nonaccr_gecikme_faiz_lm) +  number_list(pn_3251_nonaccr_gecikme_tax_lm) ;
    
    number_list(pn_3251_defer_penalty)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_amount,0));
    number_list(pn_3251_defer_penalty_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_defer_penalty)  * ln_musteri_kur);
    number_list(pn_3251_defer_penalty_lm)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_defer_penalty)  * ln_maliyet_kur);
      
    number_list(pn_3251_defer_pen_tax)       :=  abs(nvl(r_hesap.tahsil_deferred_penalty_tax,0));
    number_list(pn_3251_defer_pen_tax_lc)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_defer_pen_tax)  * ln_musteri_kur);
    number_list(pn_3251_defer_pen_tax_lm)    :=  pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_defer_pen_tax)  * ln_maliyet_kur);
       
    number_list(pn_3251_defer_pen_toplam)    := number_list(pn_3251_defer_penalty)  + number_list(pn_3251_defer_pen_tax);
    number_list(pn_3251_defer_pen_toplam_lc) :=  number_list(pn_3251_defer_penalty_lc)  + number_list(pn_3251_defer_pen_tax_lc);
    number_list(pn_3251_defer_pen_toplam_lm) :=  number_list(pn_3251_defer_penalty_lm)  + number_list(pn_3251_defer_pen_tax_lm);
   
   ---Kontroller 
    if number_list(pn_3251_anapara) +  number_list(pn_3251_toplam_faiz)  + number_list(pn_3251_toplam_vergi)<> 0 and  varchar_list(pn_3251_iliskili_hesap_no)  is null then
          raise iliskili_hesapno_yok;
     end if;
      
    if number_list(pn_3251_toplam_faiz) <> 0 and varchar_list(pn_3251_accrual_int_acct_no) is null then
        raise faiz_tahakkuk_hesapno_yok;
     end if;
     
     if number_list(pn_3251_toplam_vergi) <> 0 and varchar_list(pn_3251_accrual_tax_acct_no) is null then
        raise vergi_tahakkuk_hesapno_yok;
      end if;
                  
   --DK faiz ve reeeskont bulunur 
         /*faiz gl dk */
        if  r_hesap.dk_grup_kod is not null and r_hesap.modul_tur_kod is not null and r_hesap.urun_tur_kod is not null and r_hesap.urun_sinif_kod is not null then 
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 2,  null,null, null,varchar_list(pn_3251_iliskili_faiz_dk));
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 10,null,null, null,varchar_list(pn_3251_gecikme_faiz_gl)); --seval.colak 14012022
            pkg_muhasebe.dk_bul ( r_hesap.dk_grup_kod,r_hesap.modul_tur_kod,r_hesap.urun_tur_kod, r_hesap.urun_sinif_kod, 12,null,null, null,varchar_list(pn_3251_penalty_gl)); --seval.colak 01112022
        end if;  

        if  ( nvl(number_list(pn_3251_TOPLAM_faiz),0) <> 0 or 
                (nvl(number_list(pn_3251_NONACCR_DEFER_INT),0) +  nvl(number_list(pn_3251_NONACCRUAL_TAHSIL_FAIZ) ,0) <> 0  )) --seval.colak 14012022
             and  varchar_list(pn_3251_iliskili_faiz_dk) is null  then
                 raise iliskili_faiz_dk_yok;               
         end if;
             
        /*DELAY interest penalty deferred dk */
          if   (  number_list(pn_3251_PENALTY_AMOUNT) + number_list(pn_3251_DEFER_PENALTY) + number_list(pn_3251_NONACCR_DEFER_DEL_INT) +number_list(pn_3251_NONACCRUAL_GECIKME_FAIZ) <>0 )  and (varchar_list(pn_3251_gecikme_faiz_gl) is null )  then
                  raise gecikme_faiz_dk_yok;
         end if;
     
 -- E-O-M seval.colak 30052022 
            
        number_list(pn_3251_anapara_tahsil_farkkur)    := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_anapara_tahsil)  * ln_fark_kur );
        number_list(pn_3251_anapara_tahsil_malkur)     := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_anapara_tahsil)  * ln_maliyet_kur );
        number_list(pn_3251_anapara_tahsil_muskur)     := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_anapara_tahsil)  * ln_musteri_kur);
        number_list(pn_3251_anapara_tahsil_tl)         := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_anapara_tahsil)  * ln_musteri_kur);   --seval.colak 14062022 --pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(ls_kredi_doviz,pkg_genel.LC_AL,null,number_list(pn_3251_anapara_tahsil),1,null,null,'N','A'));

        number_list(pn_3251_TOPLAM_faiz_muskur)    := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_toplam_faiz) * ln_musteri_kur);
        number_list(pn_3251_toplam_faiz_tl)        := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_toplam_faiz) * ln_musteri_kur);--seval.colak 14062022 --pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(ls_kredi_doviz,pkg_genel.LC_AL,null, number_list(pn_3251_toplam_faiz),1,null,null,'N','A'));

        number_list(pn_3251_erken_odeme_malkur)    := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_erken_odeme) * ln_maliyet_kur);
        number_list(pn_3251_erken_odeme_tl)        := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_erken_odeme) * ln_musteri_kur);--seval.colak 14062022 pkg_kur.yuvarla(pkg_genel.lc_al,pkg_kur.doviz_doviz_karsilik(ls_kredi_doviz,pkg_genel.LC_AL,null, number_list(pn_3251_erken_odeme),1,null,null,'N','A'));
  
  --b-o-m seval.colak 17062022
    number_list(pn_3251_erken_odeme_kom_tax_lc)    := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_erken_odeme_kom_tax) * ln_musteri_kur);
    number_list(pn_3251_erken_odeme_kom_tax_lm)    := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_erken_odeme_kom_tax) * ln_maliyet_kur);
  
    ln_toplam_faiz_vergi_fark   := abs ( abs( number_list(pn_3251_toplam_faiz_lm) +  number_list(pn_3251_toplam_vergi_lm) +  number_list(pn_3251_erken_odeme_malkur)+ number_list(pn_3251_erken_odeme_kom_tax_lm) +
                                              number_list(pn_3251_deferred_toplam_lm) + number_list(pn_3251_penalty_toplam_lm) + number_list(pn_3251_gecikme_faiz_toplam_lm) + number_list(pn_3251_defer_pen_toplam_lm) )  
                                        -  abs( number_list(pn_3251_toplam_faiz_lc) + number_list(pn_3251_toplam_vergi_lc) +  number_list(pn_3251_erken_odeme_tl)+ number_list(pn_3251_erken_odeme_kom_tax_lc) +
                                                number_list(pn_3251_deferred_toplam_lc) + number_list(pn_3251_penalty_toplam_lc) + number_list(pn_3251_gecikme_faiz_toplam_lc) + number_list(pn_3251_defer_pen_toplam_lc) ) ) ;
      
    number_list(pn_3251_toplam_vergi_fark_kur) := abs(  abs( number_list(pn_3251_toplam_vergi_lm) +  number_list(pn_3251_erken_odeme_kom_tax_lm) +
                                                 number_list(pn_3251_deferred_tax_lm) + number_list(pn_3251_nonaccr_defer_int_tax_lm) +number_list(pn_3251_nonaccr_def_del_int_tx_lm) +  number_list(pn_3251_accr_defer_int_tax_lm) +number_list(pn_3251_accr_def_del_int_tax_lm)  + --deferred_toplam_tax_lm
                                                 number_list(pn_3251_penalty_tax_lm) +
                                                 number_list(pn_3251_accr_gecikme_tax_lm) +  number_list(pn_3251_nonaccr_gecikme_tax_lm) + --gecikme faiz toplam tax
                                                 number_list(pn_3251_defer_pen_tax_lm) ) 
                                               -                                                   
                                                abs( number_list(pn_3251_toplam_vergi_lc) +  number_list(pn_3251_erken_odeme_kom_tax_lc) +
                                                  number_list(pn_3251_deferred_tax_lc) + number_list(pn_3251_nonaccr_defer_int_tax_lc) +number_list(pn_3251_nonaccr_def_del_int_tax_l) +  number_list(pn_3251_accr_defer_int_tax_lc) +number_list(pn_3251_accr_def_del_int_tax_l) +
                                                  number_list(pn_3251_penalty_tax_lc) + 
                                                  number_list(pn_3251_accrual_gecikme_tax_lc) +  number_list(pn_3251_nonaccrual_gecikme_tax_lc) + 
                                                  number_list(pn_3251_defer_pen_tax_lc) ) );
                                                  
    number_list(pn_3251_toplam_faiz_fark_kur) := abs( nvl(ln_toplam_faiz_vergi_fark,0) - nvl( number_list(pn_3251_toplam_vergi_fark_kur),0) ) ;
    
 --b-o-m seval.colak 17062022
        number_list(pn_3251_fark_faiz)            := abs( nvl(ln_toplam_faiz,0) - nvl(number_list(pn_3251_gecenyil_faiz),0));
        number_list(pn_3251_fark_faiz_malkur)  := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_fark_faiz) * ln_maliyet_kur);
        number_list(pn_3251_fark_faiz_tl)        := pkg_kur.yuvarla(pkg_genel.lc_al,number_list(pn_3251_fark_faiz) * ln_musteri_kur);

        number_list(pn_3251_faiz_tahsilat_fark):= abs( nvl(number_list(pn_3251_TOPLAM_faiz_muskur),0) - ( number_list(pn_3251_fark_faiz_malkur) + number_list(pn_3251_gecenyil_faiz_malkur)+ number_list(pn_3251_erken_odeme_malkur)));

      if  ls_kredi_doviz = pkg_genel.lc_al then
         boolean_list(pn_3251_tl_kredi) := true;
        else
          boolean_list(pn_3251_yp_kredi) := true;
            if ls_tahsil_doviz = pkg_genel.lc_al then
               boolean_list(pn_3251_tl_tahsil) := true;
             else
                boolean_list(pn_3251_yp_tahsil) := true;
             end if;
      end if;

  if   number_list(pn_3251_musteri_kur) > number_list(pn_3251_maliyet_kur) then
       boolean_list(pn_3251_musterikur_buyukse) := true;
  else
       boolean_list(pn_3251_musterikur_kucukse):= true;
  end if;
  
 -- B-O-M seval.colak 30052022 
------------------------------------------------------------------------------------------------------------------------------------      
  /*
 Principal –                   ПОГАШЕНИЕ СУММЫ КРЕДИТА (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Interest –                      ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Tax –                              НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME
Delayed interest –       ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (NUMBER OF PAST DUE DAYS, FOR EXAMPLE 1 ДЕНЬ/DAY) ИМЯ ФАМИЛИЯ/NAME SURNAME
Delayed interest tax – НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Deferred interest –     ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Deferred tax –             НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА
Penalty amount –        ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Penalty tax –                НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА 1 ДЕНЬ/NUMBER OF PAST DUE DAYS НА ПРОСР. ПРОЦЕНТЫ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) ИМЯ ФАМИЛИЯ/NAME SURNAME
Deferred Delayed interest – ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ (КРЕДИТ СЧЕТ/LOAN ACCOUNT) (МЕС/MONTH) ИМЯ ФАМИЛИЯ/NAME SURNAME В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА
*/

    ls_aciklama_month :=null;
    ls_musteri_Adi :=  substr(trim(upper(Pkg_Musteri.Sf_Musteri_Adi(r_hesap.musteri_No))),1,100);
    if nvl(r_hesap.tahsil_taksit_no,0) <> 0 then 
        select to_char(vade_tarih,'MM/YYYY') 
        into ls_aciklama_month
        from cbs_hesap_kredi_Taksit
        where hesap_No = r_hesap.hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0);        
    end if;

        varchar_list(pn_3251_ack_principial)  := varchar_list(pn_3251_musteri_aciklama);   --seval.colak 15112022 --substr('ПОГАШЕНИЕ СУММЫ КРЕДИТА ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3251_ack_int)         := substr('ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200);
        varchar_list(pn_3251_ack_tax)         := substr('НАЛОГ С ПРОДАЖ ПО ПРОЦЕНТАМ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3251_ack_delay_int)   := substr('ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ + НСП ('||r_hesap.hesap_no ||') ('|| nvl(r_hesap.faiz_gecikme_gun_sayisi,0) || ' ДН) '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3251_ack_delay_int_tax):= substr('НАЛОГ С ПРОДАЖ НА ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '||ls_musteri_Adi,1,200); 
        varchar_list(pn_3251_ack_defer_int)   := substr('ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no||') ('|| ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200); 
        varchar_list(pn_3251_ack_defer_tax)   := substr('НАЛОГ С ПРОДАЖ НА ОТСРОЧЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ ЛЬГОТНОГО ПЕРИОДА',1,200);
        varchar_list(pn_3251_ack_penalty)     := substr('ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '|| ls_musteri_Adi,1,200); 
        varchar_list(pn_3251_ack_penalty_tax) := substr('НАЛОГ С ПРОДАЖ НА ПЕНИ ЗА ('||nvl(r_hesap.ap_gecikme_gun_sayisi,0)||' ДН) '||'НА ПРОСР. ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') '||ls_musteri_Adi,1,200);
        varchar_list(pn_3251_ack_defer_delay_int):= substr('ОТСРОЧЕННЫЕ ПОВЫШЕННЫЕ ПРОЦЕНТЫ ПО КРЕДИТУ ('||r_hesap.hesap_no ||') ('||ls_aciklama_month || ') '||ls_musteri_Adi||' В СВЯЗИ С ПРЕДОСТАВЛЕНИЕМ   ЛЬГОТНОГО ПЕРИОДА',1,200);
             
        varchar_list(pn_3251_ack_defer_int_tax)  := varchar_list(pn_3251_ack_delay_int_tax);
        varchar_list(pn_3251_ack_defer_delay_int_tax)  := varchar_list(pn_3251_ack_delay_int_tax); 
        -- E-O-M seval.colak 30052022 
------------------------------------------------------------------------------------------------------------------------------------

      ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
                            null,
                            pn_islem_no,
                            varchar_list ,
                            number_list  ,
                            date_list    ,
                            boolean_list ,
                            null,
                            false,
                            0,
                            null);

    pkg_muhasebe.muhasebelestir(ln_fis_no);
    
      --B-O-M seval.colak   30052022
-- muhasebe sonrasi guncellemeler
        update CBS_HESAP_KREDI_ISLEM
        set     accrual_tahsil_faiz =  r_hesap.accrual_tahsil_faiz,   
                nonaccrual_tahsil_faiz= r_hesap.nonaccrual_tahsil_faiz ,         
                accrual_tahsil_vergi =  r_hesap.accrual_tahsil_vergi,   
                nonaccrual_tahsil_vergi= r_hesap.nonaccrual_tahsil_vergi ,
                accrual_tahsil_deferred_interest = r_hesap.accrual_tahsil_deferred_interest,
                nonaccrual_tahsil_deferred_interest = r_hesap.nonaccrual_tahsil_deferred_interest ,
                tahsil_nonaccrual_deferred_tax = r_hesap.tahsil_nonaccrual_deferred_tax,                                   
                accrual_tahsil_deferred_delayed_int = r_hesap.accrual_tahsil_deferred_delayed_int,
                nonaccrual_tahsil_deferred_delayed_int = r_hesap.nonaccrual_tahsil_deferred_delayed_int,
                tahsil_nonaccrual_deferred_delay_tax = r_hesap.tahsil_nonaccrual_deferred_delay_tax,
                accrual_tahsil_gecikme_faiz = r_hesap.accrual_tahsil_gecikme_faiz,
                nonaccrual_tahsil_gecikme_faiz = r_hesap.nonaccrual_tahsil_gecikme_faiz,
                accrual_tahsil_gecikme_faiz_tax = r_hesap.accrual_tahsil_gecikme_faiz_tax,
                nonaccrual_tahsil_gecikme_faiz_tax = r_hesap.nonaccrual_tahsil_gecikme_faiz_tax ,
                tahsil_accrual_deferred_tax = r_hesap.tahsil_accrual_deferred_tax,   --seval.colak 07062022
                tahsil_accrual_deferred_delay_tax = r_hesap.tahsil_accrual_deferred_delay_tax , --seval.colak 07062022    
                tahsil_gecikme_faiz_tax     = nvl( r_hesap.accrual_tahsil_gecikme_faiz_tax,0 ) +  nvl( r_hesap.nonaccrual_tahsil_gecikme_faiz_tax,0 ),  --seval.colak 08062022             
                tahsiledilen_faiz_tutari     =  nvl(tahsiledilen_faiz_tutari,0)    +   number_list(pn_3251_toplam_faiz)  +   number_list(pn_3251_deferred_interest)  , -- b-o-m seval.colak 22062022
                tahsiledilen_faiz_tutari_lc  =  nvl(tahsiledilen_faiz_tutari_lc,0) +   number_list(pn_3251_toplam_faiz_lc) + number_list(pn_3251_deferred_interest_lc) ,
                tahsil_gecikme_faiz_tutari   =  nvl(tahsil_gecikme_faiz_tutari,0)  +   nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0),
                tahsiledilecek_tahakkuk_faiz =    number_list(pn_3251_toplam_faiz)  , 
                anapara_tahsilat_tutar      =     nvl(r_hesap.tahsil_anapara,0)  , 
                tahsil_araodeme_faiz        =     number_list(pn_3251_toplam_faiz) ,
                toplam_tahsiledilecek_tutar  =  nvl(r_hesap.toplam_tahsil,0)   -- e-o-m seval.colak 22062022                
            where tx_no = pn_islem_no;
        
        update CBS_HESAP_KREDI
        set         birikmis_faiz_tutari         =  case when  nvl(birikmis_faiz_tutari,0) >  nvl(number_list(pn_3251_toplam_faiz),0)  +  nvl(r_hesap.tahsil_deferred_interest,0)    then nvl(birikmis_faiz_tutari,0) -  ( nvl(number_list(pn_3251_toplam_faiz),0) + nvl(r_hesap.tahsil_deferred_interest,0)) else 0 end,  --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_interest,0) eklendi
                    birikmis_faiz_tutari_round   =  case when  nvl(birikmis_faiz_tutari,0) >  nvl(number_list(pn_3251_toplam_faiz),0)  +  nvl(r_hesap.tahsil_deferred_interest,0)    then  ROUND(nvl(birikmis_faiz_tutari,0) -  ( nvl(number_list(pn_3251_toplam_faiz),0) + nvl(r_hesap.tahsil_deferred_interest,0)),2) else 0 end,  --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_interest,0) eklendi
                    birikmis_gecikme_faiz_tutari =  case when  nvl(birikmis_gecikme_faiz_tutari,0) >  nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0) then nvl(birikmis_gecikme_faiz_tutari,0) -  (nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0)) else 0 end, --seval.colak 15042022  nvl(r_hesap.tahsil_deferred_delayed_interest,0) eklendi
                    paid_penalty_amount          =  nvl(paid_penalty_amount,0)         +   nvl(r_hesap.tahsil_penalty_amount,0) + nvl(r_hesap.tahsil_deferred_penalty_amount,0),  
                    tahsiledilen_faiz_tutari     =  nvl(tahsiledilen_faiz_tutari,0)    +   number_list(pn_3251_toplam_faiz)  +   number_list(pn_3251_deferred_interest)  ,
                    tahsiledilen_faiz_tutari_lc  =  nvl(tahsiledilen_faiz_tutari_lc,0) +   number_list(pn_3251_toplam_faiz_lc) + number_list(pn_3251_deferred_interest_lc) ,
                    tahsil_gecikme_faiz_tutari   =  nvl(tahsil_gecikme_faiz_tutari,0)  +   nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0)                      
        where hesap_no = ln_kredi_hesap_no ;  

        if nvl(r_hesap.tahsil_taksit_no,0) <> 0 then              
             update CBS_HESAP_KREDI_TAKSIT
             set   tahsil_anapara = nvl(tahsil_anapara,0) + nvl(r_hesap.tahsil_anapara,0),
                   tahsil_faiz = nvl(tahsil_faiz,0) + number_list(pn_3251_toplam_faiz),   -- nvl(r_hesap.tahsil_faiz,0),
                   tahsil_bsmv = nvl(tahsil_bsmv,0) + nvl(r_hesap.tahsil_vergi,0),
                   tahsil_gecikme_faiz_tutari =  nvl(tahsil_gecikme_faiz_tutari,0) + nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0)  ,
                   paid_penalty_amount =  nvl(paid_penalty_amount,0) + nvl(r_hesap.tahsil_penalty_amount,0),
                   paid_deferred_penalty_amount =  nvl(paid_deferred_penalty_amount,0) + nvl(r_hesap.tahsil_deferred_penalty_amount,0),  
                   paid_deferred_interest =  nvl(paid_deferred_interest,0) + nvl(r_hesap.tahsil_deferred_interest,0),  
                   paid_deferred_delayed_interest =  nvl(paid_deferred_delayed_interest,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0),  --seval.colak
                   paid_deferred_tax =  nvl(paid_deferred_tax,0) + nvl(r_hesap.tahsil_deferred_tax,0)      ,
                   --b-o-m seval.colak 07062022 
                     paid_accrual_deferred_delay_tax =  nvl(paid_accrual_deferred_delay_tax,0) + nvl(r_hesap.tahsil_accrual_deferred_delay_tax,0), 
                     paid_nonaccrual_deferred_delay_tax =  nvl(paid_nonaccrual_deferred_delay_tax,0) + nvl(r_hesap.tahsil_nonaccrual_deferred_delay_tax,0),   
                     paid_accrual_deferred_tax =  nvl(paid_accrual_deferred_tax,0) + nvl(r_hesap.tahsil_accrual_deferred_tax,0),  
                     paid_nonaccrual_deferred_tax =  nvl(paid_nonaccrual_deferred_tax,0) + nvl(r_hesap.tahsil_nonaccrual_deferred_tax,0),  
                     paid_deferred_penalty_tax =  nvl(paid_deferred_penalty_tax,0) + nvl(r_hesap.tahsil_deferred_penalty_tax,0)   
                    --e-o-m seval.colak 07062022                  
             where hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
               
              update cbs_hesap_kredi_taksit
              set tahsil_taksit =  nvl(tahsil_anapara,0) +nvl(tahsil_faiz,0) +  nvl(tahsil_bsmv,0) +
                                   nvl(paid_deferred_interest,0) +  nvl(paid_deferred_tax,0) +  nvl(paid_deferred_penalty_amount,0)+ nvl(paid_deferred_delayed_interest,0) --seval.colak 14022023
             where hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
       
                    
               
            update  cbs_hesap_kredi_taksit
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul
            where   hesap_no =  ln_kredi_hesap_no and 
                    sira_no <=  nvl(r_hesap.tahsil_taksit_no,0)  and  
                    durum_kodu ='A' and  
                    trunc(abs (nvl(anapara,0) - nvl(tahsil_anapara,0) ),2) +
                    trunc(abs (nvl(faiz,0) - nvl(tahsil_faiz,0) ) ,2) - trunc(abs (nvl(r_hesap.faiz_indirim_tutar,0)) ,2) +  --seval.colak 22062022 faiz_indirim_tutar eklendi
                  ( trunc(abs (nvl(bsmv,0) - nvl(tahsil_bsmv,0) ),2) - round( (nvl(r_hesap.faiz_indirim_tutar,0)  * nvl(r_hesap.BSMV_ORANI,0)   / 100 ),2)  ) + --seval.colak 22062022 faiz_indirim_tutar vergi 
                    trunc(abs (nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) ),2)+
                    trunc(abs (nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) ),2)+ 
                    trunc(abs (nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0) ) ,2)+
                    trunc(abs (nvl(deferred_interest,0) - nvl(paid_deferred_interest,0) ),2) +
                    trunc(abs (nvl(deferred_delayed_interest,0) - nvl(paid_deferred_delayed_interest,0) ) ,2)      --seval.colak 17122021
                   --seval.colak 29082022  deferred_tax artik kullanilmayacak -- + trunc(abs (nvl(deferred_tax,0) - nvl(paid_deferred_tax,0) ) ,2)  
                    =  0 ;
--
            update cbs_hesap_kredi_taksit_islem
             set   tahsil_anapara = nvl(tahsil_anapara,0) + nvl(r_hesap.tahsil_anapara,0),
                   tahsil_faiz = nvl(tahsil_faiz,0) + number_list(pn_3251_toplam_faiz),   -- nvl(r_hesap.tahsil_faiz,0),
                   tahsil_bsmv = nvl(tahsil_bsmv,0) + nvl(r_hesap.tahsil_vergi,0),
                   tahsil_gecikme_faiz_tutari =  nvl(tahsil_gecikme_faiz_tutari,0) + nvl(r_hesap.tahsil_birikmis_gecikme_faiz,0)  ,
                   paid_penalty_amount =  nvl(paid_penalty_amount,0) + nvl(r_hesap.tahsil_penalty_amount,0),
                   paid_deferred_penalty_amount =  nvl(paid_deferred_penalty_amount,0) + nvl(r_hesap.tahsil_deferred_penalty_amount,0),  
                   paid_deferred_interest =  nvl(paid_deferred_interest,0) + nvl(r_hesap.tahsil_deferred_interest,0),  
                   paid_deferred_delayed_interest =  nvl(paid_deferred_delayed_interest,0) + nvl(r_hesap.tahsil_deferred_delayed_interest,0),  --seval.colak
                   paid_deferred_tax =  nvl(paid_deferred_tax,0) + nvl(r_hesap.tahsil_deferred_tax,0)      ,
                   paid_accrual_deferred_delay_tax =  nvl(paid_accrual_deferred_delay_tax,0) + nvl(r_hesap.tahsil_accrual_deferred_delay_tax,0), 
                     paid_nonaccrual_deferred_delay_tax =  nvl(paid_nonaccrual_deferred_delay_tax,0) + nvl(r_hesap.tahsil_nonaccrual_deferred_delay_tax,0),   
                     paid_accrual_deferred_tax =  nvl(paid_accrual_deferred_tax,0) + nvl(r_hesap.tahsil_accrual_deferred_tax,0),  
                     paid_nonaccrual_deferred_tax =  nvl(paid_nonaccrual_deferred_tax,0) + nvl(r_hesap.tahsil_nonaccrual_deferred_tax,0),  
                     paid_deferred_penalty_tax =  nvl(paid_deferred_penalty_tax,0) + nvl(r_hesap.tahsil_deferred_penalty_tax,0)                                    
             where tx_no=pn_islem_no and hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
               
              update cbs_hesap_kredi_taksit_islem
              set tahsil_taksit =  nvl(tahsil_anapara,0) +nvl(tahsil_faiz,0) + nvl(tahsil_bsmv,0)  +
                                   nvl(paid_deferred_interest,0) +  nvl(paid_deferred_tax,0) +  nvl(paid_deferred_penalty_amount,0)+ nvl(paid_deferred_delayed_interest,0) --seval.colak 14022023
             where tx_no=pn_islem_no and hesap_no = ln_kredi_hesap_no and sira_no = nvl(r_hesap.tahsil_taksit_no,0) ;
       

            update  cbs_hesap_kredi_taksit_islem
            set     durum_kodu = 'O', 
                    odeme_tarihi= pkg_muhasebe.banka_tarihi_bul
            where   tx_no=pn_islem_no and hesap_no =  ln_kredi_hesap_no and 
                    sira_no <=  nvl(r_hesap.tahsil_taksit_no,0) and  
                    durum_kodu ='A' and  
                    trunc(abs (nvl(anapara,0) - nvl(tahsil_anapara,0) ),2) +
                   abs ( trunc(abs (nvl(faiz,0) - nvl(tahsil_faiz,0) ) ,2) - trunc(abs (nvl(r_hesap.faiz_indirim_tutar,0)) ,2) )  +  --seval.colak 22062022 faiz_indirim_tutar eklendi
                    ( trunc(abs (nvl(bsmv,0) - nvl(tahsil_bsmv,0) ),2) - round( (nvl(r_hesap.faiz_indirim_tutar,0)  * nvl(r_hesap.BSMV_ORANI,0)   / 100 ),2)  ) + --seval.colak 22062022 faiz_indirim_tutar vergi 
                    trunc(abs (nvl(gecikme_faiz_tutari,0) - nvl(tahsil_gecikme_faiz_tutari,0) ),2)+
                    trunc(abs (nvl(penalty_amount,0) - nvl(paid_penalty_amount,0) ),2)+ 
                    trunc(abs (nvl(deferred_penalty_amount,0) - nvl(paid_deferred_penalty_amount,0) ) ,2)+
                    trunc(abs (nvl(deferred_interest,0) - nvl(paid_deferred_interest,0) ),2) +
                    trunc(abs (nvl(deferred_delayed_interest,0) - nvl(paid_deferred_delayed_interest,0) ) ,2)     --seval.colak 17122021
                   --seval.colak 29082022  deferred_tax artik kullanilmayacak trunc(abs (nvl(deferred_tax,0) - nvl(paid_deferred_tax,0) ) ,2) 
                    =  0 ;   
           end if;                      
              
        ln_kalan_tahsil_faiz :=  nvl(r_hesap.tahsil_faiz,0);
        ln_kalan_tahsil_vergi := nvl(r_hesap.tahsil_vergi,0);
        
        for c_tahakkuk in cur_tahakkuk  
        loop 
                ln_tahakkuk_no :=  c_tahakkuk.tahakkuk_no;                
                ln_tahsil_faiz := 0;
                ln_tahsil_vergi := 0;
                
                if nvl(c_tahakkuk.faiz_tahakkuk_tutar,0)  >  ln_kalan_tahsil_faiz then 
                    ln_tahsil_faiz := ln_kalan_tahsil_faiz;
                else
                    ln_tahsil_faiz := nvl(c_tahakkuk.faiz_tahakkuk_tutar,0);
                end if;
                
                    ln_kalan_tahsil_faiz := nvl(ln_kalan_tahsil_faiz,0) - nvl(ln_tahsil_faiz,0);
                 if ln_kalan_tahsil_faiz <0 then 
                        ln_kalan_tahsil_faiz := 0;
                 end if;   
                
                if nvl(c_tahakkuk.vergi_tahakkuk_tutar,0)  >  ln_kalan_tahsil_vergi then 
                    ln_tahsil_vergi := ln_kalan_tahsil_vergi;
                else
                    ln_tahsil_vergi := nvl(c_tahakkuk.vergi_tahakkuk_tutar,0) ;                   
                end if;      
                
                 ln_kalan_tahsil_vergi := nvl(ln_kalan_tahsil_vergi,0) - nvl(ln_tahsil_vergi,0);
                 if ln_kalan_tahsil_vergi <0 then 
                        ln_kalan_tahsil_vergi := 0;
                 end if;  
                    
                update  cbs_kredi_tahakkuk
                set     faiz_tahakkuk_tutar_tahsil  = nvl(faiz_tahakkuk_tutar_tahsil,0) +  nvl(ln_tahsil_faiz,0),
                        vergi_tahakkuk_tutar_tahsil = nvl(vergi_tahakkuk_tutar_tahsil,0) + nvl(ln_tahsil_vergi,0),
                        tahsilat_tx_no = pn_islem_no
                where   kredi_hesap_no  = c_tahakkuk.kredi_hesap_no and
                        tahakkuk_no     = c_tahakkuk.tahakkuk_no and
                        durum_kodu='A' ; 
         end loop;
       
        update  cbs_kredi_tahakkuk
        set     durum_kodu = 'K', 
                odeme_tarihi= pkg_muhasebe.banka_tarihi_bul,
                tahsilat_tx_no = pn_islem_no
        where   kredi_hesap_no =  ln_kredi_hesap_no and
                durum_kodu ='A' and
                trunc( nvl(faiz_tahakkuk_tutar,0)  -  nvl(faiz_tahakkuk_tutar_tahsil,0),2) <= 0 and  
                trunc( nvl(vergi_tahakkuk_tutar,0) - nvl(vergi_tahakkuk_tutar_tahsil,0),2) <= 0 ;     
      --E-O-M seval.colak   30052022       
    sp_muhasebesonrasi_guncelle(pn_islem_no);

    pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,ls_geriodeme_kapama_secimi);

   if islem_cursor%isopen then
          close islem_cursor;
    end if;
           
       
 Exception
 when iliskili_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6828' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when faiz_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6826' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when vergi_tahakkuk_hesapno_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6827' || pkg_hata.getdelimiter || r_hesap.hesap_no || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  When iliskili_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '700' || pkg_hata.getdelimiter || varchar_list(pn_3251_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   When iliskili_faizrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter || varchar_list(pn_3251_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   When iliskili_kom_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '702' || pkg_hata.getdelimiter || varchar_list(pn_3251_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 -- when iliskili_komrees_dk_yok then
  --  raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when deferred_interest_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6851' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter ||  r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||  r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
 when gecikme_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '6863' || pkg_hata.getdelimiter ||  r_hesap.hesap_no || pkg_hata.getdelimiter ||r_hesap.dk_grup_kod || pkg_hata.getdelimiter || r_hesap.modul_tur_kod  || pkg_hata.getdelimiter ||   r_hesap.urun_tur_kod  || pkg_hata.getdelimiter || r_hesap.urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
  when kur_sifir_olamaz then  
    raise_application_error(-20100,pkg_hata.getucpointer || '6870' || pkg_hata.getdelimiter  || pkg_hata.getucpointer);
  when others then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '507' || pkg_hata.getDelimiter || to_char(sqlcode) ||'-'||to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER); 
 End;
 
 
--------------------------------------------------------------------------
 function sf_islemdenvadetarihal(pn_islem_no number, pn_hesap_no number ,pn_sira_no number) return date
 is
  ld_date date;
 Begin
       select vade_tarih
      into ld_date
      from cbs_hesap_kredi_taksit_islem
      where tx_no = pn_islem_no and
              hesap_no =pn_hesap_no and
            sira_no = pn_sira_no ;

    return ld_date;
 End;


  Function sf_min_acik_taksit_no_al(pn_islem_no number) return number
   is
   ln_sira_no number :=0;
   Begin

       select min(sira_no)
      into ln_sira_no
      from cbs_hesap_kredi_taksit_islem
      where tx_no = pn_islem_no and
              durum_kodu = 'A';

    return ln_sira_no;
  Exception when others then return 0;
 End;

 Function sf_iptal_edilebilirmi(pn_islem_no number ,pn_hesap_no number) return number
 is
  ln_tx_no number := 0 ;
  iptaledilemez            exception;
 Begin

       select max(numara)
      into   ln_tx_no
      from  cbs_islem
      where   durum  not in ('R','2') and
               islem_kod in( 3251,1323,1306,3252) and
             numara > pn_islem_no and
             hesap_numara = pn_hesap_no;

      if nvl(ln_tx_no,0) <> 0 then
        raise iptaledilemez;
      end if;

   return ln_tx_no ;

   Exception
    When iptaledilemez then
        raise_application_error(-20100,pkg_hata.getucpointer || '905' || pkg_hata.getDelimiter || to_char( ln_tx_no ) ||  pkg_hata.getDelimiter || pkg_hata.getucpointer);
        return ln_tx_no ;
     when others   then return 0;
 End;

 Function sf_maxtaksitno_al(pn_islem_no number) return number
 is
    ln_sira_no number :=0;
 Begin
      select max(sira_no)
      into   ln_sira_no
      from   cbs_hesap_kredi_taksit_islem
      where   tx_no = pn_islem_no;

  return ln_sira_no;

  Exception when others then return 0;
 End;
 Function sf_kapama_islemi(pn_islem_no number) return varchar2
 is
  ln_min_islem number := 0;
  ln_max_islem number := 0;
 Begin
       ln_min_islem :=  sf_min_acik_taksit_no_al(pn_islem_no ) ;
      ln_max_islem :=  sf_maxtaksitno_al(pn_islem_no);

      if ln_min_islem = 0 or ln_min_islem = ln_max_islem then
        return 'E';
      else
        return 'H';
      end if;

 End;

  procedure sp_kontrol_sonrasi_rezervasyon(pn_islem_no number ) is
 ln_doviz_tutari number;
    ln_bakiye number;

    CURSOR islem_cursor IS
                SELECT * from CBS_HESAP_KREDI_ISLEM
            where TX_NO=pn_islem_no;

    row_islem islem_cursor%ROWTYPE;
   Begin

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

    if row_islem.REZERVASYON_NO is not null then

       ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

       IF  nvl(row_islem.tahsil_anapara ,0)  >ln_bakiye THEN --Bakiye Yetersiz..
          RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
       else
          Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                                                           pn_islem_no,
                                                           row_islem.tahsil_anapara);
       END IF;

    end if;

 Exception when others then null;
 End;


BEGIN
        pn_3251_iliskili_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_HESAP_SUBE');
        pn_3251_iliskili_hesap_no    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_HESAP_NO');
        pn_3251_kredi_hesap_no    := Pkg_Muhasebe.parametre_index_bul('3251_KREDI_HESAP_NO');
        pn_3251_kredi_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('3251_KREDI_HESAP_SUBE');
        pn_3251_musteri_aciklama    := Pkg_Muhasebe.parametre_index_bul('3251_MUSTERI_ACIKLAMA');
        pn_3251_referans    := Pkg_Muhasebe.parametre_index_bul('3251_REFERANS');
        pn_3251_fis_aciklama    := Pkg_Muhasebe.parametre_index_bul('3251_FIS_ACIKLAMA');
        pn_3251_kur    := Pkg_Muhasebe.parametre_index_bul('3251_KUR');
        pn_3251_kredi_tl    := Pkg_Muhasebe.parametre_index_bul('3251_KREDI_TL');
        pn_3251_banka_aciklama    := Pkg_Muhasebe.parametre_index_bul('3251_BANKA_ACIKLAMA');
        pn_3251_kredi_yp    := Pkg_Muhasebe.parametre_index_bul('3251_KREDI_YP');
        pn_3251_kredi_doviz    := Pkg_Muhasebe.parametre_index_bul('3251_KREDI_DOVIZ');
        pn_3251_iliskili_faiz_dk    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_FAIZ_DK');
        pn_3251_islem_sube    := Pkg_Muhasebe.parametre_index_bul('3251_ISLEM_SUBE');
        pn_3251_musterikur_buyukse    := Pkg_Muhasebe.parametre_index_bul('3251_MUSTERIKUR_BUYUKSE');
        pn_3251_musterikur_kucukse    := Pkg_Muhasebe.parametre_index_bul('3251_MUSTERIKUR_KUCUKSE');
        pn_3251_iliskili_hesap_doviz    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_HESAP_DOVIZ');
        pn_3251_iliskili_faizdk    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_FAIZDK');
        pn_3251_iliskili_komdk    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_KOMDK');
        pn_3251_deferred_interest    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_INTEREST');
        pn_3251_iliskili_faizreesdk    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_FAIZREESDK');
        pn_3251_deferred_interest_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_INTEREST_LC');
        pn_3251_iliskili_komreesdk    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_KOMREESDK');
        pn_3251_deferred_tax    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TAX');
        pn_3251_anapara_tahsil    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_TAHSIL');
        pn_3251_deferred_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TAX_LC');
        pn_3251_anapara_tahsil_tl    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_TAHSIL_TL');
        pn_3251_accrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_GECIKME_FAIZ');
        pn_3251_toplam_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ');
        pn_3251_accrual_gecikme_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_GECIKME_FAIZ_LC');
        pn_3251_toplam_faiz_tl    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ_TL');
        pn_3251_gecikme_faiz_gl    := Pkg_Muhasebe.parametre_index_bul('3251_GECIKME_FAIZ_GL');
        pn_3251_gecenyil_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_GECENYIL_FAIZ');
        pn_3251_accrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_GECIKME_TAX');
        pn_3251_accrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_GECIKME_TAX_LC');
        pn_3251_gecenyil_faiz_tl    := Pkg_Muhasebe.parametre_index_bul('3251_GECENYIL_FAIZ_TL');
        pn_3251_fark_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_FARK_FAIZ');
        pn_3251_penalty_amount    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_AMOUNT');
        pn_3251_fark_faiz_tl    := Pkg_Muhasebe.parametre_index_bul('3251_FARK_FAIZ_TL');
        pn_3251_penalty_amount_lc    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_AMOUNT_LC');
        pn_3251_tl_kredi    := Pkg_Muhasebe.parametre_index_bul('3251_TL_KREDI');
        pn_3251_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TAX');
        pn_3251_yp_kredi    := Pkg_Muhasebe.parametre_index_bul('3251_YP_KREDI');
        pn_3251_penalty_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TAX_LC');
        pn_3251_birikmis_sch_tl    := Pkg_Muhasebe.parametre_index_bul('3251_BIRIKMIS_SCH_TL');
        pn_3251_anapara    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA');
        pn_3251_gecenyil_sch_tl    := Pkg_Muhasebe.parametre_index_bul('3251_GECENYIL_SCH_TL');
        pn_3251_anapara_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_LC');
        pn_3251_gecenyilbdak_sch_tl    := Pkg_Muhasebe.parametre_index_bul('3251_GECENYILBDAK_SCH_TL');
        pn_3251_birikmis_sch_acilis_tl    := Pkg_Muhasebe.parametre_index_bul('3251_BIRIKMIS_SCH_ACILIS_TL');
        pn_3251_erken_odeme    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME');
        pn_3251_erken_odeme_tl    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME_TL');
        pn_3251_istatistik_kapama    := Pkg_Muhasebe.parametre_index_bul('3251_ISTATISTIK_KAPAMA');
        pn_3251_toplam_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ_LC');
        pn_3251_istatistik_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_ISTATISTIK_FAIZ');
        pn_3251_toplam_vergi    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_VERGI');
        pn_3251_yp_tahsil    := Pkg_Muhasebe.parametre_index_bul('3251_YP_TAHSIL');
        pn_3251_toplam_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_VERGI_LC');
        pn_3251_tl_tahsil    := Pkg_Muhasebe.parametre_index_bul('3251_TL_TAHSIL');
        pn_3251_penalty_toplam    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TOPLAM');
        pn_3251_tahsil_hesap_no    := Pkg_Muhasebe.parametre_index_bul('3251_TAHSIL_HESAP_NO');
        pn_3251_penalty_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TOPLAM_LC');
        pn_3251_anapara_tahsil_muskur    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_TAHSIL_MUSKUR');
        pn_3251_deferred_toplam    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TOPLAM');
        pn_3251_anapara_tahsil_malkur    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_TAHSIL_MALKUR');
        pn_3251_deferred_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TOPLAM_LC');
        pn_3251_anapara_tahsil_farkkur    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_TAHSIL_FARKKUR');
        pn_3251_gecikme_faiz_toplam    := Pkg_Muhasebe.parametre_index_bul('3251_GECIKME_FAIZ_TOPLAM');
        pn_3251_toplam_faiz_muskur    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ_MUSKUR');
        pn_3251_gecikme_faiz_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3251_GECIKME_FAIZ_TOPLAM_LC');
        pn_3251_fark_faiz_malkur    := Pkg_Muhasebe.parametre_index_bul('3251_FARK_FAIZ_MALKUR');
        pn_3251_accrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_INT_ACCT_NO');
        pn_3251_accrual_tax_acct_no    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAX_ACCT_NO');
        pn_3251_gecenyil_faiz_malkur    := Pkg_Muhasebe.parametre_index_bul('3251_GECENYIL_FAIZ_MALKUR');
        pn_3251_erken_odeme_malkur    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME_MALKUR');
        pn_3251_accrual_delay_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_DELAY_INT_ACCT_NO');
        pn_3251_faiz_tahsilat_fark    := Pkg_Muhasebe.parametre_index_bul('3251_FAIZ_TAHSILAT_FARK');
        pn_3251_nonaccrual_int_acct_no    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_INT_ACCT_NO');
        pn_3251_musteri_kur    := Pkg_Muhasebe.parametre_index_bul('3251_MUSTERI_KUR');
        pn_3251_nonaccrual_delay_int_acct    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_DELAY_INT_ACCT');
        pn_3251_accrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_FAIZ');
        pn_3251_maliyet_kur    := Pkg_Muhasebe.parametre_index_bul('3251_MALIYET_KUR');
        pn_3251_iliskili_hesap_tur    := Pkg_Muhasebe.parametre_index_bul('3251_ILISKILI_HESAP_TUR');
        pn_3251_nonaccrual_tahsil_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_TAHSIL_FAIZ');
        pn_3251_accrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_VERGI');
        pn_3251_nonaccrual_tahsil_vergi    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_TAHSIL_VERGI');
        pn_3251_accrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_FAIZ_LC');
        pn_3251_nonaccrual_tahsil_faiz_lc    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_TAHSIL_FAIZ_LC');
        pn_3251_accrual_tahsil_vergi_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_VERGI_LC');
        pn_3251_nonaccrual_tahsil_vergi_l    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_TAHSIL_VERGI_L');
        pn_3251_tax_aciklama    := Pkg_Muhasebe.parametre_index_bul('3251_TAX_ACIKLAMA');
        pn_3251_defer_pen_toplam    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TOPLAM');
        pn_3251_defer_pen_toplam_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TOPLAM_LC');
        pn_3251_defer_pen_tax    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TAX');
        pn_3251_defer_pen_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TAX_LC');
        pn_3251_defer_penalty    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PENALTY');
        pn_3251_defer_penalty_lc    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PENALTY_LC');
        pn_3251_nonaccrual_gecikme_faiz    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_GECIKME_FAIZ');
        pn_3251_nonaccrual_gecikme_faiz_l    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_GECIKME_FAIZ_L');
        pn_3251_nonaccrual_gecikme_tax    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_GECIKME_TAX');
        pn_3251_nonaccrual_gecikme_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_GECIKME_TAX_LC');
        pn_3251_accr_defer_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT');
        pn_3251_accr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT_LC');
        pn_3251_nonaccr_defer_int    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT');
        pn_3251_nonaccr_defer_int_lc    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT_LC');
        pn_3251_accr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_DEL_INT');
        pn_3251_accr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_DEL_INT_LC');
        pn_3251_nonaccr_defer_del_int    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_DEL_INT');
        pn_3251_nonaccr_defer_del_int_lc    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_DEL_INT_LC');
        pn_3251_ack_principial    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_PRINCIPIAL');
        pn_3251_ack_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_INT');
        pn_3251_ack_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_TAX');
        pn_3251_ack_delay_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DELAY_INT');
        pn_3251_ack_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DELAY_INT_TAX');
        pn_3251_ack_defer_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DEFER_INT');
        pn_3251_ack_defer_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DEFER_TAX');
        pn_3251_ack_penalty    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_PENALTY');
        pn_3251_ack_penalty_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_PENALTY_TAX');
        pn_3251_ack_defer_delay_int    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DEFER_DELAY_INT');
        pn_3251_nonaccr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT_TAX');
        pn_3251_nonaccr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT_TAX_LC');
        pn_3251_nonaccr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEF_DEL_INT_TAX');
        pn_3251_nonaccr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEF_DEL_INT_TAX_L');
        pn_3251_ack_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DEFER_INT_TAX');
        pn_3251_ack_defer_delay_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACK_DEFER_DELAY_INT_TAX');
        pn_3251_tahsil_hesap_sube    := Pkg_Muhasebe.parametre_index_bul('3251_TAHSIL_HESAP_SUBE');
        pn_3251_accr_defer_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT_TAX');
        pn_3251_accr_defer_int_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT_TAX_LC');
        pn_3251_accr_def_del_int_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEF_DEL_INT_TAX');
        pn_3251_accr_def_del_int_tax_l    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEF_DEL_INT_TAX_L');
        pn_3251_accrual_tahsil_faiz_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_FAIZ_LM');
        pn_3251_nonaccrual_tahsil_faiz_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCRUAL_TAHSIL_FAIZ_LM');
        pn_3251_accrual_tahsil_vergi_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCRUAL_TAHSIL_VERGI_LM');
        pn_3251_nonaccr_tahsil_vergi_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_TAHSIL_VERGI_LM');
        pn_3251_defer_pen_toplam_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TOPLAM_LM');
        pn_3251_defer_pen_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PEN_TAX_LM');
        pn_3251_defer_penalty_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFER_PENALTY_LM');
        pn_3251_nonaccr_gecikme_faiz_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_GECIKME_FAIZ_LM');
        pn_3251_nonaccr_gecikme_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_GECIKME_TAX_LM');
        pn_3251_accr_defer_int_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT_LM');
        pn_3251_nonaccr_defer_int_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT_LM');
        pn_3251_accr_defer_del_int_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_DEL_INT_LM');
        pn_3251_nonaccr_defer_del_int_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_DEL_INT_LM');
        pn_3251_nonaccr_defer_int_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEFER_INT_TAX_LM');
        pn_3251_accr_defer_int_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEFER_INT_TAX_LM');
        pn_3251_accr_def_del_int_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_DEF_DEL_INT_TAX_LM');
        pn_3251_toplam_faiz_lm    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ_LM');
        pn_3251_toplam_vergi_lm    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_VERGI_LM');
        pn_3251_penalty_amount_lm    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_AMOUNT_LM');
        pn_3251_anapara_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ANAPARA_LM');
        pn_3251_deferred_interest_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_INTEREST_LM');
        pn_3251_deferred_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TAX_LM');
        pn_3251_deferred_toplam_lm    := Pkg_Muhasebe.parametre_index_bul('3251_DEFERRED_TOPLAM_LM');
        pn_3251_penalty_toplam_lm    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TOPLAM_LM');
        pn_3251_accr_gecikme_faiz_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_GECIKME_FAIZ_LM');
        pn_3251_accr_gecikme_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ACCR_GECIKME_TAX_LM');
        pn_3251_gecikme_faiz_toplam_lm    := Pkg_Muhasebe.parametre_index_bul('3251_GECIKME_FAIZ_TOPLAM_LM');
        pn_3251_penalty_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_TAX_LM');
        pn_3251_nonaccr_def_del_int_tx_lm    := Pkg_Muhasebe.parametre_index_bul('3251_NONACCR_DEF_DEL_INT_TX_LM');
        pn_3251_toplam_faiz_fark_kur    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_FAIZ_FARK_KUR');
        pn_3251_toplam_vergi_fark_kur    := Pkg_Muhasebe.parametre_index_bul('3251_TOPLAM_VERGI_FARK_KUR');
        pn_3251_erken_odeme_kom_tax    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME_KOM_TAX');
        pn_3251_erken_odeme_kom_tax_lc    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME_KOM_TAX_LC');
        pn_3251_erken_odeme_kom_tax_lm    := Pkg_Muhasebe.parametre_index_bul('3251_ERKEN_ODEME_KOM_TAX_LM');
        pn_3251_penalty_gl    := Pkg_Muhasebe.parametre_index_bul('3251_PENALTY_GL');   --seval.colak 01112022

END ;
/

