create PACKAGE     "PKG_JOBS" IS
  
TYPE CursorReferenceType IS REF CURSOR;
-----------------------------------------------------------------------------------
PROCEDURE SendKCELLCASHPayments( ps_externalno IN VARCHAR2) ;
-----------------------------------------------------------------------------------
PROCEDURE SendKCELLNONCASHPayments( ps_externalno IN VARCHAR2);
-----------------------------------------------------------------------------------
PROCEDURE SendKMOBILEPayments( ps_externalno IN VARCHAR2);
--------------------------------------------------------------------------------------
PROCEDURE SendALMATYTELPayments( ps_externalno IN VARCHAR2);
-------------------------------------------------------------------------------------
PROCEDURE ProcessAPSPayments( ps_option IN VARCHAR2 DEFAULT NULL);
-----------------------------------------------------------------------------------
PROCEDURE SendCardPayments( ps_option IN VARCHAR2 DEFAULT NULL);
-----------------------------------------------------------------------------------
PROCEDURE NBCurrencyLoader( ps_option IN VARCHAR2 DEFAULT NULL);
-----------------------------------------------------------------------------------
PROCEDURE FutureDateClearing( ps_option IN VARCHAR2 DEFAULT NULL);
-----------------------------------------------------------------------------------
PROCEDURE FXPositionControl( ps_option IN VARCHAR2 DEFAULT NULL);
---------------------------------------------------------------------------------
PROCEDURE SendKartelPayments( ps_externalno IN VARCHAR2);
-----------------------------------------------------------------------------------
PROCEDURE SendSubscription( ps_customeremail IN VARCHAR2);
------------------------------------------------------------------------------------
PROCEDURE SendSUARNASYPayments( ps_externalno IN VARCHAR2);
--------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTCORPayments( ps_externalno IN VARCHAR2);
-------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTBUDPayments( ps_externalno IN VARCHAR2);
-------------------------------------------------------------------------------------
PROCEDURE SendENERGYSBYTINDPayments( ps_externalno IN VARCHAR2);
-------------------------------------------------------------------------------------
FUNCTION GetSubscibeDate(pn_accountno IN VARCHAR2) RETURN DATE;
-------------------------------------------------------------------------------------
PROCEDURE SendDealSlip(ps_channel_cd IN VARCHAR2,
                       ps_email IN VARCHAR2,
                       ps_tx_no IN VARCHAR2,
                       ps_lang_cd IN VARCHAR2,
                       pc_ref OUT CursorReferenceType);
-------------------------------------------------------------------------------------
function GetLangLabels(ps_tran_cd in varchar2,
                       pn_page_id in number,
                       pn_label_id in number,
                       ps_lang_cd in varchar2) return varchar2;
-------------------------------------------------------------------------------------
PROCEDURE SendAccountHistory(ps_channel_cd IN VARCHAR2,
                             ps_lang_cd IN VARCHAR2,
                             ps_person_id IN VARCHAR2,
                             ps_email IN VARCHAR2,
                             ps_start_date IN VARCHAR2,
                             ps_end_date IN VARCHAR2,
                             ps_type IN VARCHAR2,
                             ps_account_no IN VARCHAR2);
-------------------------------------------------------------------------------------
PROCEDURE SendCreditCardTranList(ps_TranCD IN VARCHAR2,
                                 ps_From IN VARCHAR2,
                                 ps_To IN VARCHAR2,
                                 ps_Subject IN VARCHAR2,
                                 ps_Data IN CLOB,
                                 ps_channel_cd IN VARCHAR2,
                                 ps_lang_cd IN VARCHAR2,
                                 ps_person_id IN VARCHAR2);
-------------------------------------------------------------------------------------
FUNCTION GetCreditCardDekontHeadFoot(ps_Option IN VARCHAR2, ps_lang_cd IN VARCHAR2) RETURN CLOB;
-------------------------------------------------------------------------------------
END;
/

