create PACKAGE BODY     Pkg_Takas IS

/* *********************************************************************************** */
  FUNCTION  takas_merkezi_mi(ps_bolum_kodu VARCHAR2) RETURN NUMBER IS
  ln_cnt NUMBER;
  BEGIN
    SELECT COUNT(*)
	  INTO ln_cnt
      FROM CBS_BOLUM_TAKAS_BAGIMLI
     WHERE bagli_bolum_kodu = ps_bolum_kodu;
    IF ln_cnt > 0 THEN
	  RETURN 1;
	ELSE
	  RETURN 0;
    END IF;
	EXCEPTION
	 WHEN OTHERS THEN
	   RETURN -1;
  END;

/* *********************************************************************************** */
 PROCEDURE cek_no_kontrol(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0) IS
 ln_temp NUMBER;
 CURSOR cur_cek_var IS
    SELECT DISTINCT 1
     FROM CBS_TAKAS_CEK
	WHERE banka_kodu = ps_banka_kodu
	  AND sube_kodu = ps_sube_kodu
	  AND cek_no = pn_cek_no
      AND cek_durum NOT IN ('IPTAL', 'CIKIS', 'IADE');
 BEGIN
    OPEN cur_cek_var;
	FETCH cur_cek_var INTO ln_temp;
	IF cur_cek_var%NOTFOUND THEN
	  CLOSE cur_cek_var;
	ELSE
	  CLOSE cur_cek_var;
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '235' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
	ln_temp := bitmemis_islem_var_mi(ps_banka_kodu, ps_sube_kodu, pn_cek_no, pn_islem_no);
    IF ln_temp <> 0 THEN
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '257' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
 END;
/* *********************************************************************************** */
 FUNCTION takas_merkezine_bagli(ps_takas_bolum VARCHAR2, ps_bolum VARCHAR2) RETURN NUMBER IS
  ln_cnt NUMBER;
  BEGIN
    SELECT COUNT(*)
	  INTO ln_cnt
      FROM CBS_BOLUM_TAKAS_BAGIMLI
     WHERE bagli_bolum_kodu = ps_takas_bolum
	   AND bolum_kodu = ps_bolum;
    IF ln_cnt > 0 THEN
	  RETURN 1;
	ELSE
	  RETURN 0;
    END IF;
	EXCEPTION
	 WHEN OTHERS THEN
	   RETURN -1;
  END;
/* *********************************************************************************** */
  FUNCTION cek_var(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER) RETURN NUMBER IS
   -- 0 : cek yok
   -- any number  : ref_cek_no
   -- -1 : any error occurred
   ln_temp NUMBER;
   CURSOR c_01 IS
     SELECT ref_cek_no
       FROM CBS_TAKAS_CEK a
      WHERE a.cek_no = pn_cek_no
        AND a.banka_kodu = ps_banka_kodu
  	    AND a.sube_kodu = ps_sube_kodu;
   BEGIN
	OPEN c_01;
	FETCH c_01 INTO ln_temp;
	IF c_01%NOTFOUND THEN
	  ln_temp := 0;
	END IF;
	CLOSE c_01;
    RETURN ln_temp;
	EXCEPTION
	  WHEN OTHERS THEN
	    RETURN -1;
   END;
/* *********************************************************************************** */
FUNCTION bitmemis_islem_var_mi(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2,
                               pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0) RETURN NUMBER IS
 ln_temp NUMBER;

 CURSOR cur_bitmemis_islem IS
    SELECT DISTINCT 1
     FROM CBS_TAKAS_CEK_ISLEM a, CBS_TAKAS_CEK_ISLEM b, CBS_ISLEM c
	WHERE a.banka_kodu = ps_banka_kodu
	  AND a.sube_kodu = ps_sube_kodu
	  AND a.cek_no = pn_cek_no
	  AND b.ref_cek_no = a.ref_cek_no
	  AND b.tx_no = c.numara
	  AND c.numara <> pn_islem_no	  		 	   	  --kendisi d???ndaki i?lemlere bak
	  AND Pkg_Tx.islem_bitmis_mi(numara) = 0;

 BEGIN
	OPEN cur_bitmemis_islem;
	FETCH cur_bitmemis_islem INTO ln_temp;
	IF cur_bitmemis_islem%NOTFOUND THEN
	  CLOSE cur_bitmemis_islem;
	  RETURN 0;
	ELSE
	  CLOSE cur_bitmemis_islem;
	  RETURN 1;
	END IF;
 END;
/* *********************************************************************************** */
FUNCTION bitmemis_islem_var_mi(pn_ref_cek_no NUMBER, pn_islem_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;

 CURSOR cur_bitmemis_islem IS
    SELECT DISTINCT 1
     FROM CBS_TAKAS_CEK_ISLEM, CBS_ISLEM
	WHERE ref_cek_no = pn_ref_cek_no
	  AND tx_no = numara
	  AND numara <> pn_islem_no	  		 	   	  --kendisi d???ndaki i?lemlere bak
	  AND Pkg_Tx.islem_bitmis_mi(numara) = 0;

 BEGIN
	OPEN cur_bitmemis_islem;
	FETCH cur_bitmemis_islem INTO ln_temp;
	IF cur_bitmemis_islem%NOTFOUND THEN
	  CLOSE cur_bitmemis_islem;
	  RETURN 0;
	ELSE
	  CLOSE cur_bitmemis_islem;
	  RETURN 1;
	END IF;
 END;
/* *********************************************************************************** */
 FUNCTION cikis_yapilir_durum(ps_durum VARCHAR2, ps_bolum VARCHAR2) RETURN NUMBER IS
  BEGIN
   IF (ps_durum = 'TAKAS') OR (ps_durum = 'TAKASTA' AND takas_merkezi_mi(ps_bolum) = 1) THEN
      RETURN 1;
   ELSE
	  RETURN 0;
   END IF;
  END;
/* *********************************************************************************** */
 PROCEDURE takas_cek_detay_al(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2, pn_cek_no IN NUMBER,
                             ps_bolum_kodu OUT VARCHAR2, ps_bolum_adi OUT VARCHAR2,
							 pn_musteri_no OUT VARCHAR2, ps_musteri OUT VARCHAR2, ps_tahsil_teminat OUT VARCHAR2,
							 ps_tahsil_hesap OUT NUMBER, ps_tahsil_doviz OUT VARCHAR2, ps_masraf_hesap OUT VARCHAR2,
							 ps_masraf_doviz  OUT VARCHAR2, ps_kesideci_adi  OUT VARCHAR2, ps_tem_al_hesap  OUT VARCHAR2,
							 ps_tem_al_hes_dov  OUT VARCHAR2, pd_takas_tarihi OUT DATE, pn_cek_tutar OUT NUMBER,
							 ps_kesideci_hesap  OUT VARCHAR2, pd_keside_tarih OUT DATE, ps_keside_yeri  OUT VARCHAR2,
							 ps_cek_tipi  OUT VARCHAR2, ps_cek_durum  OUT VARCHAR2, ps_cek_doviz OUT VARCHAR2,
							 ps_masraf_alindi OUT VARCHAR2, pn_ref_cek_no OUT NUMBER, ps_tahsil_edilecek OUT VARCHAR2,
							 pn_masraf_tx OUT NUMBER) IS
BEGIN
SELECT a.bolum_kodu, Pkg_Genel.bolum_adi_al(a.bolum_kodu) bolum_adi,
       a.musteri_no, Pkg_Musteri.sf_musteri_adi(a.musteri_no) musteri_adi,
	   a.tahsil_teminat, a.tahsil_hesap_no, a.tahsil_hesap_doviz,
	   a.masraf_hesap_no, a.masraf_hesap_doviz, a.kesideci_adi,
	   a.teminat_alacak_hesap_no, a.teminat_alacak_hesap_doviz,
	   a.takas_tarihi, a.cek_tutari, a.kesideci_hesap_no, a.keside_tarih, a.keside_yeri,
	   a.cek_tipi, a.cek_durum, a.cek_doviz, masraf_alindi,
	   ref_cek_no, tahsil_edilecek, masraf_tx
  INTO ps_bolum_kodu, ps_bolum_adi, pn_musteri_no, ps_musteri,
	   ps_tahsil_teminat, ps_tahsil_hesap,ps_tahsil_doviz,
	   ps_masraf_hesap, ps_masraf_doviz, ps_kesideci_adi,
	   ps_tem_al_hesap, ps_tem_al_hes_dov, pd_takas_tarihi,
	   pn_cek_tutar, ps_kesideci_hesap, pd_keside_tarih,
	   ps_keside_yeri, ps_cek_tipi, ps_cek_durum, ps_cek_doviz, ps_masraf_alindi,
	   pn_ref_cek_no, ps_tahsil_edilecek, pn_masraf_tx
  FROM CBS_TAKAS_CEK a
 WHERE a.cek_no = pn_cek_no
   AND a.banka_kodu = ps_banka_kodu
   AND a.sube_kodu = ps_sube_kodu
   AND a.bolum_kodu = DECODE(takas_merkezine_bagli(Pkg_Baglam.bolum_kodu, a.bolum_kodu),
		                          1, a.bolum_kodu, Pkg_Baglam.bolum_kodu)
   AND bitmemis_islem_var_mi(a.ref_cek_no, 0) = 0;
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '264' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) ||
                              Pkg_Hata.getDelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
 END;
/* *********************************************************************************** */
 PROCEDURE cek_duzeltilebilir(pn_ref_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0) IS
 ln_temp       NUMBER;
 ls_banka_kodu CBS_TAKAS_CEK.banka_kodu%TYPE;
 ls_sube_kodu  CBS_TAKAS_CEK.sube_kodu%TYPE;
 ln_cek_no     CBS_TAKAS_CEK.cek_no%TYPE;
 CURSOR cur_cek_var IS
    SELECT DISTINCT 1
     FROM CBS_TAKAS_CEK
	WHERE banka_kodu = ls_banka_kodu
	  AND sube_kodu = ls_sube_kodu
	  AND cek_no = ln_cek_no
	  AND (   ref_cek_no <> pn_ref_cek_no
	       OR ( ref_cek_no = pn_ref_cek_no
		       AND cek_durum <> 'ACIK')
		  );
 CURSOR cur_cek IS
   SELECT banka_kodu, sube_kodu, cek_no
     FROM CBS_TAKAS_CEK
	WHERE ref_cek_no = pn_ref_cek_no;
 BEGIN
    OPEN cur_cek;
	 FETCH cur_cek INTO ls_banka_kodu, ls_sube_kodu, ln_cek_no;
	CLOSE cur_cek;

    OPEN cur_cek_var;
	FETCH cur_cek_var INTO ln_temp;
	IF cur_cek_var%NOTFOUND THEN
	  CLOSE cur_cek_var;
	ELSE
	  CLOSE cur_cek_var;
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '235' ||  Pkg_Hata.getDelimiter || TO_CHAR(ln_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
	ln_temp := bitmemis_islem_var_mi(pn_ref_cek_no, pn_islem_no);
    IF ln_temp <> 0 THEN
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '257' ||  Pkg_Hata.getDelimiter || TO_CHAR(ln_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
 END;
/* *********************************************************************************** */
 PROCEDURE takas_cek_klonla(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2,
                            pn_cek_no NUMBER, pn_tx_no NUMBER) IS
 BEGIN
   INSERT
	 INTO CBS_TAKAS_CEK_ISLEM(tx_no, cek_no, banka_kodu, sube_kodu, cek_tipi, cek_tutari, kesideci_hesap_no,
	                          keside_tarih, keside_yeri, tahsil_teminat, musteri_no, tahsil_hesap_no,
	                          teminat_alacak_hesap_no, masraf_alindi, masraf_hesap_no,
	                          cek_durum, takas_tarihi, iade_tarihi, cikis_iade_kodu,
	                          tahsil_tutari, tahsil_sekli, yaratan_kullanici, yaratildigi_tarih, bolum_kodu,
							  teminat_alacak_hesap_doviz, masraf_hesap_doviz, tahsil_hesap_doviz,
							  cek_doviz, kesideci_adi, giris_tarihi, ref_cek_no,
							  elden_tahsil_nostrohesap, elden_tahsil_nostrohesap_dvz, BLOKE_HESAP_NO,
							  KARSI_BANKA_KODU, KARSI_SUBE_KODU, BANKAMIZ_CEK, TAHSIL_EDILECEK, masraf_tx)
	                  (SELECT pn_tx_no, cek_no, banka_kodu, sube_kodu, cek_tipi, cek_tutari, kesideci_hesap_no,
	                          keside_tarih, keside_yeri, tahsil_teminat, musteri_no, tahsil_hesap_no,
	                          teminat_alacak_hesap_no, masraf_alindi, masraf_hesap_no,
	                          cek_durum, takas_tarihi, iade_tarihi, cikis_iade_kodu,
	                          tahsil_tutari, tahsil_sekli, Pkg_Baglam.kullanici_kodu, SYSDATE, bolum_kodu,
							  teminat_alacak_hesap_doviz, masraf_hesap_doviz, tahsil_hesap_doviz,
							  cek_doviz, kesideci_adi, Pkg_Muhasebe.BANKA_TARIHI_BUL, ref_cek_no,
							  elden_tahsil_nostrohesap, elden_tahsil_nostrohesap_dvz, BLOKE_HESAP_NO,
							  KARSI_BANKA_KODU, KARSI_SUBE_KODU, BANKAMIZ_CEK, TAHSIL_EDILECEK, masraf_tx
	                     FROM CBS_TAKAS_CEK
	                    WHERE banka_kodu = ps_banka_kodu
						  AND sube_kodu = ps_sube_kodu
						  AND cek_no = pn_cek_no);

   INSERT
	 INTO CBS_TEMINAT_ISLEM(tx_no, teminat_no, teminat_turu, teminat_kodu, musteri_no,
                            teminat_hesap_no, teminat_hesap_doviz, teminat_tutari,
                            kullanilan_tutar, teminat_doviz_kodu, teminat_durumu,
                            cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no)
                    (SELECT pn_tx_no, teminat_no, teminat_turu, teminat_kodu, musteri_no,
                            teminat_hesap_no, teminat_hesap_doviz, teminat_tutari,
                            kullanilan_tutar, teminat_doviz_kodu, teminat_durumu,
                            cek_banka_kodu, cek_sube_kodu, cek_no, ref_cek_no
                       FROM CBS_TEMINAT
		              WHERE cek_banka_kodu = ps_banka_kodu
					    AND cek_sube_kodu= ps_sube_kodu
						AND cek_no = pn_cek_no
						AND teminat_kodu = '01'
						AND teminat_turu = 'CEK');

	END;
/* *********************************************************************************** */
  FUNCTION iade_adi_al(ps_cikis_iade_kodu VARCHAR2) RETURN VARCHAR2 IS
  CURSOR cur_iade IS
    SELECT cikis_iade_neden
	  FROM CBS_TAKAS_CEK_IADE_NEDEN
	 WHERE cikis_iade_kodu = ps_cikis_iade_kodu;

  ls_adi  CBS_TAKAS_CEK_IADE_NEDEN.cikis_iade_neden%TYPE;

  BEGIN
    IF cur_iade%isopen THEN
	   CLOSE cur_iade;
	END IF;
	OPEN cur_iade;
	FETCH cur_iade INTO ls_adi;
	 IF cur_iade%NOTFOUND THEN
    	ls_adi := '?ade Kodu Bulunamad?.';
	 END IF;
	CLOSE cur_iade;
	RETURN(ls_adi);
  END;
/* *********************************************************************************** */
 FUNCTION teminat_kullaniliyor_mu(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 CURSOR cur_teminat_var IS
    SELECT DISTINCT 1
     FROM CBS_TEMINAT
	WHERE cek_banka_kodu = ps_banka_kodu
	  AND cek_sube_kodu = ps_sube_kodu
	  AND cek_no = pn_cek_no
	  AND teminat_durumu = 'ACIK'
	  AND NVL(kullanilan_tutar,0) > 0;
--	  AND teminat_durumu NOT IN ( 'IPTAL', 'CIKIS')
--	  AND NVL(kullanilan_tutar,0) > 0;
 BEGIN
    OPEN cur_teminat_var;
	FETCH cur_teminat_var INTO ln_temp;
	IF cur_teminat_var%NOTFOUND THEN
	  ln_temp := 0;
	  CLOSE cur_teminat_var;
	ELSE
	  CLOSE cur_teminat_var;
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '280' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
	RETURN ln_temp;
 END;
/* *********************************************************************************** */
 PROCEDURE takas_cek_elden_tahsil_al(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2, pn_cek_no IN NUMBER,
                                     pn_elden_thsl_nostrohsp OUT NUMBER, ps_elden_thsl_nostrohsp_dvz OUT VARCHAR2) IS
BEGIN
SELECT elden_tahsil_nostrohesap, elden_tahsil_nostrohesap_dvz
  INTO pn_elden_thsl_nostrohsp, ps_elden_thsl_nostrohsp_dvz
  FROM CBS_TAKAS_CEK a
 WHERE a.cek_no = pn_cek_no
   AND a.banka_kodu = ps_banka_kodu
   AND a.sube_kodu = ps_sube_kodu
   AND a.bolum_kodu = DECODE(takas_merkezine_bagli(Pkg_Baglam.bolum_kodu, a.bolum_kodu),
		                          1, a.bolum_kodu, Pkg_Baglam.bolum_kodu)
   AND bitmemis_islem_var_mi(a.banka_kodu, a.sube_kodu, a.cek_no, 0) = 0;
  EXCEPTION
   WHEN OTHERS THEN
     RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '264' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) ||
                              Pkg_Hata.getDelimiter || SQLERRM || Pkg_Hata.getUCPOINTER);
 END;
/* ***********************************************************************************
 Function yaratilan_islem_bul(ps_banka_kodu varchar2, ps_sube_kodu varchar2, pn_cek_no varchar2) return number is
 ln_dummy number;
 begin
   select max(b.tx_no)
     into ln_dummy
     from cbs_takas_cek_islem a, cbs_takas_cek_islem b, cbs_islem c
	where a.banka_kodu = ps_banka_kodu
	  and a.sube_kodu = ps_sube_kodu
	  and a.cek_no = pn_cek_no
	  and b.ref_cek_no = a.ref_cek_no
	  and c.numara = b.tx_no
	  and c.islem_kod in (3100, 3101)
	  and c.durum = 'P';
	return ln_dummy;
    exception when no_data_found then
	  return 0;
 end;
 *********************************************************************************** */
 FUNCTION bankamiz_cek_durum_al(ps_cek_durum VARCHAR2) RETURN VARCHAR2 IS
 ls_temp VARCHAR2(2000);
 CURSOR c_01 IS
   SELECT aciklama
     FROM CBS_CEK_DURUM_KODLARI
	WHERE durum_kodu = ps_cek_durum;
 CURSOR c_02 IS
   SELECT aciklama
     FROM CBS_TAKAS_CEK_DURUM_KODLARI
	WHERE durum_kodu = ps_cek_durum;
 BEGIN
   OPEN c_01;
   FETCH c_01 INTO ls_temp;
   IF c_01%NOTFOUND THEN
	   OPEN c_02;
	   FETCH c_02 INTO ls_temp;
	   IF c_02%NOTFOUND THEN
	   	  ls_temp := 'Durum Kodu Bulunamad?.';
	   END IF;
	   CLOSE c_02;
   END IF;
   CLOSE c_01;
   RETURN ls_temp;
 END;
/* *********************************************************************************** */
 PROCEDURE takas_giden_file_olustur(pd_tarih DATE, ps_cek_tipi VARCHAR2, ps_sube VARCHAR2) IS
 CURSOR c_01 IS
   SELECT *
     FROM CBS_TAKAS_CEK
    WHERE bankamiz_cek = 'H'
	  AND takas_tarihi = pd_tarih
	  AND cek_tipi = ps_cek_tipi
	  AND cek_doviz = pkg_genel.lc_al
	  AND cek_durum = 'TAKAS'
	  AND((     ps_sube = 'E'
	        AND bolum_kodu IN (SELECT DISTINCT b.kodu
                                FROM CBS_BOLUM_TAKAS_BAGIMLI a, CBS_BOLUM b
                               WHERE b.kodu = Pkg_Baglam.bolum_kodu
                                 OR (    a.bagli_bolum_kodu = Pkg_Baglam.bolum_kodu
                                     AND b.kodu = a.bolum_kodu
                                    )
							  )
		   )
		  OR
		   (    ps_sube <> 'E'
		    AND bolum_kodu = ps_sube
		    )
		  )
    FOR UPDATE;
/*   select *
     from cbs_takas_cek
    where bankamiz_cek = 'H'
	  and takas_tarihi = pd_tarih
	  and cek_tipi = ps_cek_tipi
	  and cek_durum = 'TAKAS'
	  and bolum_kodu = decode(ps_sube, 'E', bolum_kodu, ps_sube)
   for update;
   */
  r_01 c_01%ROWTYPE;
  ls_str VARCHAR2(50);
  ls_sube VARCHAR2(20);
  ls_ext VARCHAR2(3);
  ls_file VARCHAR2(100);
 BEGIN
	SELECT DECODE(ps_sube,'E','HEPSI',ps_sube)
	    INTO ls_sube
	    FROM dual;

	  SELECT DECODE(ps_cek_tipi,'T', 'TAS', 'IST')
	    INTO ls_ext
	    FROM dual;

  ls_file := TO_CHAR(pd_tarih, 'YYYY') || TO_CHAR(pd_tarih, 'MM')
                    || TO_CHAR(pd_tarih, 'DD') || '_' || Pkg_Baglam.bolum_kodu || '_'
                    || ls_sube || '.' || ls_ext;
  DELETE FROM CBS_TAKAS_CEK_GIDEN WHERE file_name = ls_file;
  OPEN c_01;
  LOOP
    FETCH c_01 INTO r_01;
	EXIT WHEN c_01%NOTFOUND;
	ls_str := '1 ';
	IF ps_cek_tipi = 'T' THEN
	  ls_str := ls_str || '1 ';
	ELSE
	  ls_str := ls_str || '0 ';
	END IF;
	ls_str := ls_str || SUBSTR('0000000' || LTRIM(RTRIM(TO_CHAR(r_01.cek_no))),-7);
	ls_str := ls_str || '  ';
	ls_str := ls_str || SUBSTR('000' || LTRIM(RTRIM(r_01.banka_kodu)),-3);
	ls_str := ls_str || ' ';
	ls_str := ls_str || SUBSTR('0000' || LTRIM(RTRIM(r_01.sube_kodu)),-4);
	ls_str := ls_str || '  ';
	ls_str := ls_str || SUBSTR('00000000' || LTRIM(RTRIM(r_01.kesideci_hesap_no)),-8);
	ls_str := ls_str || '  00  ';
	ls_str := ls_str || SUBSTR('000000000000' || LTRIM(RTRIM(TO_CHAR(r_01.cek_tutari,'999999999999'))),-12);
	INSERT INTO CBS_TAKAS_CEK_GIDEN (file_name, text1) VALUES (ls_file, ls_str);
	UPDATE CBS_TAKAS_CEK
	   SET cek_durum = 'TAKASTA'
	 WHERE CURRENT OF c_01;
  END LOOP;
--  commit;
  CLOSE c_01;
 END;
/* *********************************************************************************** */
 FUNCTION teminat_zorunluluk(pn_tx_no NUMBER) RETURN NUMBER IS
 CURSOR cur_teminat IS
   SELECT *
     FROM CBS_TEMINAT_ISLEM
    WHERE tx_no = pn_tx_no;
 row_teminat  cur_teminat%ROWTYPE;

 CURSOR cur_takas IS
   SELECT tahsil_teminat, cek_doviz
     FROM CBS_TAKAS_CEK_ISLEM
	WHERE tx_no = pn_tx_no;
 ls_tah_tem CBS_TAKAS_CEK_ISLEM.tahsil_teminat%TYPE;
 ls_cek_doviz CBS_TAKAS_CEK_ISLEM.cek_doviz%TYPE;
 BEGIN
   OPEN cur_takas;
   FETCH cur_takas INTO ls_tah_tem, ls_cek_doviz;
   CLOSE cur_takas;
   IF ls_tah_tem = 'TAHSIL' THEN
     RETURN 0;
   END IF;

   OPEN cur_teminat;
   FETCH cur_teminat INTO row_teminat;
   IF cur_teminat%NOTFOUND THEN
      CLOSE cur_teminat;
	  RETURN 1;
   END IF;
   LOOP
     IF row_teminat.teminat_hesap_doviz <> ls_cek_doviz THEN
	   CLOSE cur_teminat;
	   RETURN 1;
	 END IF;
	 FETCH cur_teminat INTO row_teminat;
	 EXIT WHEN cur_teminat%NOTFOUND;
   END LOOP;
   CLOSE cur_teminat;
   RETURN 0;
 END;
/* *********************************************************************************** */
 FUNCTION teminat_kullaniliyor_mu(pn_ref_cek_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 ln_cek NUMBER;
 CURSOR cur_teminat_var IS
    SELECT DISTINCT 1, cek_no
     FROM CBS_TEMINAT
	WHERE ref_cek_no = pn_ref_cek_no
	  AND teminat_durumu = 'ACIK'
	  AND NVL(kullanilan_tutar,0) > 0;
 BEGIN
    OPEN cur_teminat_var;
	FETCH cur_teminat_var INTO ln_temp, ln_cek;
	IF cur_teminat_var%NOTFOUND THEN
	  ln_temp := 0;
	  CLOSE cur_teminat_var;
	ELSE
	  CLOSE cur_teminat_var;
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '280' ||  Pkg_Hata.getDelimiter || TO_CHAR(ln_cek) || Pkg_Hata.getUCPOINTER);
	END IF;
	RETURN ln_temp;
 END;
/* *********************************************************************************** */
 FUNCTION teminat_islem_var(pn_tx_no NUMBER) RETURN NUMBER IS
 ln_temp NUMBER;
 CURSOR cur_teminat_var IS
    SELECT DISTINCT 1
     FROM CBS_TEMINAT_ISLEM
	WHERE tx_no = pn_tx_no;
 BEGIN
    OPEN cur_teminat_var;
	 FETCH cur_teminat_var INTO ln_temp;
	 IF cur_teminat_var%NOTFOUND THEN
	   ln_temp := 0;
	 END IF;
    CLOSE cur_teminat_var;
	RETURN ln_temp;
 END;
/* *********************************************************************************** */
 FUNCTION DAK_to_LC(ps_doviz_kodu VARCHAR2, pn_tutar NUMBER) RETURN NUMBER IS
 BEGIN
   RETURN( Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,
                           Pkg_Kur.doviz_doviz_karsilik(ps_doviz_kodu,
						                                Pkg_Genel.lc_al,
														NULL,
														pn_tutar,
														1,
														NULL,
														NULL,
														'O',
														'A')
							));
 END;
/* *********************************************************************************** */
 PROCEDURE sehir_tasra_belirle(ps_banka_kodu IN VARCHAR2, ps_sube_kodu IN VARCHAR2,
                               ps_sehir_tasra IN OUT VARCHAR2) IS

 BEGIN
   SELECT 'S'
     INTO ps_sehir_tasra
     FROM CBS_TAKAS_BANKA_SUBE_KODLARI a, CBS_BOLUM b
    WHERE b.il_kodu = a.il_kodu
      AND b.kodu = Pkg_Baglam.bolum_kodu
      AND a.takas_banka_kodu = ps_banka_kodu
      AND a.takas_sube_kodu = ps_sube_kodu;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
	   ps_sehir_tasra := 'T';
 END;
/* *********************************************************************************** */
PROCEDURE cek_no_kontrol_duzelt(ps_banka_kodu VARCHAR2, ps_sube_kodu VARCHAR2, pn_cek_no NUMBER, pn_islem_no NUMBER DEFAULT 0, pn_ref_cek_no NUMBER) IS
 ln_temp NUMBER;
 CURSOR cur_cek_var IS
    SELECT DISTINCT 1
     FROM CBS_TAKAS_CEK
	WHERE banka_kodu = ps_banka_kodu
	  AND sube_kodu = ps_sube_kodu
	  AND cek_no = pn_cek_no
      AND cek_durum NOT IN ('IPTAL', 'CIKIS', 'IADE')
	  AND ref_cek_no <> pn_ref_cek_no;
 BEGIN
    OPEN cur_cek_var;
	FETCH cur_cek_var INTO ln_temp;
	IF cur_cek_var%NOTFOUND THEN
	  CLOSE cur_cek_var;
	ELSE
	  CLOSE cur_cek_var;
      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '235' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
	ln_temp := bitmemis_islem_var_mi(ps_banka_kodu, ps_sube_kodu, pn_cek_no, pn_islem_no);
    IF ln_temp <> 0 THEN
	  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '257' ||  Pkg_Hata.getDelimiter || TO_CHAR(pn_cek_no) || Pkg_Hata.getUCPOINTER);
	END IF;
 END;

 /***************************************************************************************************************/
 /*   Procedure sp_takascek_tahstemin_guncelle   																 */
 /*   Teminat olarak kullan?lan takas ceklerin  teminat t?r? alan?n?n guncellenmesinde kullan?l?r.                      */
 /***************************************************************************************************************/
 PROCEDURE sp_takascek_tahstemin_guncelle ( pn_ref_cek_no   CBS_TAKAS_CEK.ref_cek_no%TYPE ,ps_tahsil_teminat CBS_TAKAS_CEK.tahsil_teminat%TYPE  )
   IS
   BEGIN
        UPDATE  CBS_TAKAS_CEK
        SET tahsil_teminat = ps_tahsil_teminat
        WHERE ref_cek_no = pn_ref_cek_no;

   EXCEPTION
      WHEN OTHERS   THEN
	  RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '538' || Pkg_Hata.getdelimiter || TO_CHAR (SQLCODE)  || ' '  || SQLERRM || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer );

   END;

 /***************************************************************************************************************/
 /*   Function sf_takascek_durumu_al   																 */
 /***************************************************************************************************************/
 FUNCTION sf_takascek_durumu_al(	pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN CBS_TAKAS_CEK.cek_durum%TYPE
  IS
   ls_cek_durum   CBS_TAKAS_CEK.cek_durum%TYPE;
  BEGIN
	   SELECT cek_durum
	   INTO ls_cek_durum
	   FROM CBS_TAKAS_CEK
	   WHERE ref_cek_no = pn_ref_cek_no;

	  RETURN ls_cek_durum;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
  	     RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '540' || Pkg_Hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

 END ;
 /***************************************************************************************************************/
 /*   Function sf_takascek_tutari_al  																 */
 /***************************************************************************************************************/
  FUNCTION sf_takascek_tutari_al(	pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN CBS_TAKAS_CEK.cek_durum%TYPE
   IS
   ln_cek_tutari NUMBER;
  BEGIN
	   SELECT cek_tutari
	   INTO ln_cek_tutari
	   FROM CBS_TAKAS_CEK
	   WHERE ref_cek_no = pn_ref_cek_no;

	  RETURN ln_cek_tutari;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN 0;
      WHEN OTHERS THEN
  	     RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '540' || Pkg_Hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

 END;

 /***************************************************************************************************************/
 /*   Function sf_takascek_vadetarihi_al   																 */
 /***************************************************************************************************************/
 FUNCTION sf_takascek_vadetarihi_al(	pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN DATE
   IS
   ld_keside_tarihi DATE :=NULL;
  BEGIN
	   SELECT keside_tarih
	   INTO ld_keside_tarihi
	   FROM CBS_TAKAS_CEK
	   WHERE ref_cek_no = pn_ref_cek_no;

	  RETURN ld_keside_tarihi;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
  	     RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '540' || Pkg_Hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

 END;

 /***************************************************************************************************************/
 /*   Function sf_takascek_tahsiledilecek_al 																 */
 /***************************************************************************************************************/
 FUNCTION sf_takascek_tahsiledilecek_al(pn_ref_cek_no CBS_TAKAS_CEK.ref_cek_no%TYPE) RETURN VARCHAR2
   IS
    ls_tahsil_edilecek CBS_TAKAS_CEK.tahsil_edilecek%TYPE :=NULL;
  BEGIN
	   SELECT tahsil_edilecek
	   INTO ls_tahsil_edilecek
	   FROM CBS_TAKAS_CEK
	   WHERE ref_cek_no = pn_ref_cek_no;

	  RETURN  ls_tahsil_edilecek;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN RETURN NULL;
      WHEN OTHERS THEN
  	     RAISE_APPLICATION_ERROR (-20100, Pkg_Hata.getucpointer || '540' || Pkg_Hata.getdelimiter|| TO_CHAR ('SQLCODE')|| SQLERRM|| Pkg_Hata.getdelimiter|| Pkg_Hata.getucpointer    );

 END;

-----------------------------------------------------------------------------------------
 /***************************************************************************************************************/
 /*   PROCEDURE takas_cek_dosya_kaydet
 /***************************************************************************************************************/

PROCEDURE takas_cek_dosya_kaydet(ps_satir VARCHAR2,ps_bolum_kodu VARCHAR2,ps_tahsil_teminat VARCHAR2,ps_keside_yeri VARCHAR2,
		  					     pn_tahsil_hesap_no NUMBER, pn_masraf_hesap_no NUMBER,pn_teminat_alacak_hesap_no NUMBER) IS
  ln_TX_NO                         NUMBER;
  ln_CEK_NO                        NUMBER;
  ls_BANKA_KODU                    VARCHAR2(4);
  ls_SUBE_KODU                     VARCHAR2(4);
  ls_CEK_TIPI                      VARCHAR2(1);
  ln_CEK_TUTARI                    NUMBER;
  ls_KESIDECI_HESAP_NO             VARCHAR2(30);
  ld_KESIDE_TARIH                  DATE;
  ls_KESIDE_YERI                   VARCHAR2(30);
  ls_TAHSIL_TEMINAT                VARCHAR2(7);
  ln_MUSTERI_NO                    NUMBER ;
  ln_TAHSIL_HESAP_NO               NUMBER;
  ln_TEMINAT_ALACAK_HESAP_NO       NUMBER;
  ls_MASRAF_ALINDI                 VARCHAR2(1);
  ln_MASRAF_HESAP_NO               NUMBER;
  ls_CEK_DURUM                     VARCHAR2(10);
  ld_TAKAS_TARIHI                  DATE;
  ld_IADE_TARIHI                   DATE;
  ls_CIKIS_IADE_KODU               VARCHAR2(2);
  ln_TAHSIL_TUTARI                 NUMBER;
  ls_TAHSIL_SEKLI                  VARCHAR2(5);
  ls_YARATAN_KULLANICI             VARCHAR2(30);
  ld_YARATILDIGI_TARIH             DATE;
  ls_BOLUM_KODU                    VARCHAR2(10);
  ls_TAHSIL_HESAP_DOVIZ            VARCHAR2(3);
  ls_TEMINAT_ALACAK_HESAP_DOVIZ    VARCHAR2(3);
  ls_MASRAF_HESAP_DOVIZ            VARCHAR2(3);
  ls_CEK_DOVIZ                     VARCHAR2(3);
  ls_KESIDECI_ADI                  VARCHAR2(25);
  ld_GIRIS_TARIHI                  DATE;
  ld_ODEME_TARIHI                  DATE;
  ln_REF_CEK_NO                    NUMBER;
  ln_ELDEN_TAHSIL_NOSTROHESAP      NUMBER;
  ls_ELDEN_TAHSIL_NOSTROHSP_DVZ  VARCHAR2(3);
  ln_BLOKE_HESAP_NO                NUMBER;
  ls_KARSI_BANKA_KODU              VARCHAR2(4);
  ls_KARSI_SUBE_KODU               VARCHAR2(4);
  ls_BANKAMIZ_CEK                  VARCHAR2(1);
  ls_TAHSIL_EDILECEK               VARCHAR2(1);
  ln_MASRAF_TX                     NUMBER;
  ln_ELDEN_ODENEN_MASRAF           NUMBER;
  ln_ELDEN_ODENEN_MASRAF_HESAP     NUMBER;
  ls_ELDEN_ODENEN_DOVIZ            VARCHAR2(3);
  ln_ELDEN_AVANS_HESAP             NUMBER;

BEGIN

  ln_TX_NO                         := Pkg_Tx.islem_no_al ;
  ln_CEK_NO                        := TO_NUMBER(LTRIM(RTRIM(SUBSTR(ps_satir,25,8)))) ;
  ls_BANKA_KODU                    := SUBSTR(ps_satir,22,3) ;
  ls_SUBE_KODU                     := SUBSTR(ps_satir,80,4) ;
  ls_CEK_TIPI                      := SUBSTR(ps_satir,33,1) ;
  ln_CEK_TUTARI                    := TO_NUMBER(SUBSTR(ps_satir,34,19),'9999999999999999.99') ;
  ls_KESIDECI_HESAP_NO             := TO_CHAR(TO_NUMBER(SUBSTR(ps_satir,72,8))) ;
  ld_KESIDE_TARIH                  := TO_DATE(SUBSTR(ps_satir,84,8),'dd/mm/yyyy') ;
  ls_KESIDE_YERI                   := SUBSTR(ps_satir,137,25) ;
  ls_TAHSIL_TEMINAT                := ps_tahsil_teminat;
  ln_MUSTERI_NO                    := TO_NUMBER(SUBSTR(ps_satir,1,8));
  ln_TAHSIL_HESAP_NO               := pn_tahsil_hesap_no;
  ln_TEMINAT_ALACAK_HESAP_NO       := pn_teminat_alacak_hesap_no ;
  ls_MASRAF_ALINDI                 := 'H' ;
  ln_MASRAF_HESAP_NO               := pn_masraf_hesap_no ;
  ls_CEK_DURUM                     := 'ACIK';

  ld_TAKAS_TARIHI                  := TO_DATE(SUBSTR(ps_satir,84,8),'dd/mm/yyyy') ;
  IF Pkg_Tarih.gun_ozellik(ld_TAKAS_TARIHI) = 1 THEN -- tatil gunu ise bir sonraki is gununu al
  	 ld_TAKAS_TARIHI := Pkg_Tarih.ileri_is_gunu(ld_TAKAS_TARIHI);
  END IF ;

  ld_IADE_TARIHI                   := NULL ;
  ls_CIKIS_IADE_KODU               := NULL ;
  ln_TAHSIL_TUTARI                 := NULL;
  ls_TAHSIL_SEKLI                  := NULL;
  ls_YARATAN_KULLANICI             := USER;
  ld_YARATILDIGI_TARIH             := Pkg_Muhasebe.banka_tarihi_bul;
  ls_BOLUM_KODU                    := ps_bolum_kodu ;
  ls_TAHSIL_HESAP_DOVIZ            := Pkg_Hesap.HesaptanDovizKoduAl(ln_TAHSIL_HESAP_NO) ;
  ls_TEMINAT_ALACAK_HESAP_DOVIZ    := Pkg_Hesap.HesaptanDovizKoduAl(pn_teminat_alacak_hesap_no) ;
  ls_MASRAF_HESAP_DOVIZ            := ls_TAHSIL_HESAP_DOVIZ ;
  ls_CEK_DOVIZ                     := Pkg_Genel.lc_al ;
  ls_KESIDECI_ADI                  := LTRIM(RTRIM(SUBSTR(ps_satir,109,25))) ;
  ld_GIRIS_TARIHI                  := Pkg_Muhasebe.banka_tarihi_bul ;
  ld_ODEME_TARIHI                  := NULL ;
  ln_REF_CEK_NO                    := Pkg_Genel.genel_kod_al('REF_TAKAS_CEK') ;
  ln_ELDEN_TAHSIL_NOSTROHESAP      := NULL;
  ls_ELDEN_TAHSIL_NOSTROHSP_DVZ    := NULL;
  ln_BLOKE_HESAP_NO                := NULL;
  ls_KARSI_BANKA_KODU              := NULL;
  ls_KARSI_SUBE_KODU               := NULL;
  ls_BANKAMIZ_CEK                  := 'H';
  ls_TAHSIL_EDILECEK               := 'E' ;
  ln_MASRAF_TX                     := ln_TX_NO ;
  ln_ELDEN_ODENEN_MASRAF           := NULL;
  ln_ELDEN_ODENEN_MASRAF_HESAP     := NULL;
  ls_ELDEN_ODENEN_DOVIZ            := NULL;
  ln_ELDEN_AVANS_HESAP             := NULL;

 INSERT INTO CBS_TAKAS_CEK_ISLEM
 (TX_NO, CEK_NO, BANKA_KODU, SUBE_KODU, CEK_TIPI, CEK_TUTARI, KESIDECI_HESAP_NO, KESIDE_TARIH,KESIDE_YERI,
  TAHSIL_TEMINAT, MUSTERI_NO, TAHSIL_HESAP_NO, TEMINAT_ALACAK_HESAP_NO, MASRAF_ALINDI,MASRAF_HESAP_NO,
  CEK_DURUM, TAKAS_TARIHI, IADE_TARIHI, CIKIS_IADE_KODU, TAHSIL_TUTARI, TAHSIL_SEKLI, YARATAN_KULLANICI,
  YARATILDIGI_TARIH, BOLUM_KODU, TAHSIL_HESAP_DOVIZ, TEMINAT_ALACAK_HESAP_DOVIZ,MASRAF_HESAP_DOVIZ, CEK_DOVIZ,
  KESIDECI_ADI, GIRIS_TARIHI, ODEME_TARIHI, REF_CEK_NO,ELDEN_TAHSIL_NOSTROHESAP, ELDEN_TAHSIL_NOSTROHESAP_DVZ,
  BLOKE_HESAP_NO, KARSI_BANKA_KODU, KARSI_SUBE_KODU,BANKAMIZ_CEK, TAHSIL_EDILECEK, MASRAF_TX,
  ELDEN_ODENEN_MASRAF, ELDEN_ODENEN_MASRAF_HESAP, ELDEN_ODENEN_DOVIZ, ELDEN_AVANS_HESAP)
 VALUES(ln_TX_NO,ln_CEK_NO,ls_BANKA_KODU,ls_SUBE_KODU,ls_CEK_TIPI ,ln_CEK_TUTARI,ls_KESIDECI_HESAP_NO,ld_KESIDE_TARIH ,
  ls_KESIDE_YERI,ls_TAHSIL_TEMINAT,ln_MUSTERI_NO ,ln_TAHSIL_HESAP_NO,ln_TEMINAT_ALACAK_HESAP_NO,ls_MASRAF_ALINDI,
  ln_MASRAF_HESAP_NO,ls_CEK_DURUM,ld_TAKAS_TARIHI,ld_IADE_TARIHI ,ls_CIKIS_IADE_KODU,ln_TAHSIL_TUTARI,
  ls_TAHSIL_SEKLI,ls_YARATAN_KULLANICI ,ld_YARATILDIGI_TARIH,ls_BOLUM_KODU,ls_TAHSIL_HESAP_DOVIZ,ls_TEMINAT_ALACAK_HESAP_DOVIZ,
  ls_MASRAF_HESAP_DOVIZ,ls_CEK_DOVIZ,ls_KESIDECI_ADI ,ld_GIRIS_TARIHI ,ld_ODEME_TARIHI,ln_REF_CEK_NO ,ln_ELDEN_TAHSIL_NOSTROHESAP,
  ls_ELDEN_TAHSIL_NOSTROHSP_DVZ,ln_BLOKE_HESAP_NO ,ls_KARSI_BANKA_KODU, ls_KARSI_SUBE_KODU ,ls_BANKAMIZ_CEK ,
  ls_TAHSIL_EDILECEK,ln_MASRAF_TX,ln_ELDEN_ODENEN_MASRAF,ln_ELDEN_ODENEN_MASRAF_HESAP,ls_ELDEN_ODENEN_DOVIZ,ln_ELDEN_AVANS_HESAP);

  Pkg_Tx.islem_yarat(ln_tx_no,3101,'CEK','TAKAS','GENEL',ln_cek_tutari,ls_bolum_kodu,
  				          Pkg_Genel.lc_al,ln_musteri_no,ln_tahsil_hesap_no,NULL);

  Pkg_Masraf.masraf_yarat(ln_tx_no,3101,'CEK','TAKAS','GENEL',ln_cek_tutari,ls_bolum_kodu,
  				          Pkg_Genel.lc_al,ln_musteri_no,ln_tahsil_hesap_no,NULL);

  Pkg_Masraf.validate_masraf(ln_tx_no) ;

   IF Pkg_Tx.Dogrula_Kontrol(ln_tx_no) THEN
     NULL;
   ELSIF Pkg_Tx.Onay_Kontrol(ln_tx_no) THEN
     NULL;
   ELSE
     Pkg_Tx.muhasebelestir(ln_tx_no);
   END IF;

END ;
--------------------------------------------------------------------------------------



END;
/

