create PACKAGE BODY     "PKG_TX1306" IS
pn_1306_tahsil_hesap_doviz        NUMBER;
pn_1306_tahsil_hesap_no        NUMBER;
pn_1306_tahsil_hesap_sube        NUMBER;
pn_1306_iliskili_hesap_no        NUMBER;
pn_1306_iliskili_faiz_dk        NUMBER;
pn_1306_iliskili_faizrees_dk        NUMBER;
pn_1306_iliskili_hesap_sube        NUMBER;
pn_1306_iliskili_kom_dk        NUMBER;
pn_1306_istatistik_faiz        NUMBER;
pn_1306_faiz_hesap_sube        NUMBER;
pn_1306_faiz_hesap_no        NUMBER;
pn_1306_banka_aciklama        NUMBER;
pn_1306_referans        NUMBER;
pn_1306_musteri_aciklama        NUMBER;
pn_1306_kredi_hesap_sube        NUMBER;
pn_1306_kredi_hesap_no        NUMBER;
pn_1306_kredi_doviz        NUMBER;
pn_1306_istatistik_kodu_kapama        NUMBER;
pn_1306_fis_aciklama        NUMBER;
pn_1306_islem_sube        NUMBER;
pn_1306_iliskili_komrees_dk        NUMBER;

pn_1306_tahak_top        NUMBER;
pn_1306_tahsil_top_muskur        NUMBER;
pn_1306_gecenyil_faiz        NUMBER;
pn_1306_gecenyil_faiz_tl        NUMBER;
pn_1306_gecenyil_kom_malkur        NUMBER;
pn_1306_birikmis_kom        NUMBER;
pn_1306_birikmis_faiz_tl        NUMBER;
pn_1306_birikmis_faiz_malkur        NUMBER;
pn_1306_birikmis_faiz        NUMBER;
pn_1306_anapara_tutar_tl        NUMBER;
pn_1306_anapara_tutar        NUMBER;
pn_1306_anapara_muskur        NUMBER;
pn_1306_anapara_malkur        NUMBER;
pn_1306_anapara_farkkur        NUMBER;
pn_1306_faiz_fark        NUMBER;
pn_1306_birikmis_sch_tl        NUMBER;
pn_1306_birikmis_kom_tl        NUMBER;
pn_1306_birikmis_kom_malkur        NUMBER;
pn_1306_musteri_kur        NUMBER;
pn_1306_maliyet_kur        NUMBER;
pn_1306_kur        NUMBER;
pn_1306_gecenyil_sch_tl        NUMBER;
pn_1306_gecenyil_kom_tl        NUMBER;
pn_1306_gecenyil_kom        NUMBER;
pn_1306_gecenyil_faiz_malkur        NUMBER;
pn_1306_gecenyilbdak_sch_tl        NUMBER;
pn_1306_tahak_top_tl        NUMBER;
pn_1306_valor_tarihi        NUMBER;
pn_1306_tahsil_doviz_tl        NUMBER;
pn_1306_musteri_kuru_buyukse        NUMBER;
pn_1306_musteri_kuru_kucukse        NUMBER;
pn_1306_kredi_yp        NUMBER;
pn_1306_kredi_tl        NUMBER;
pn_1306_tahsil_doviz_yp        NUMBER;
pn_1306_ILISKILI_HESAP_TUR    NUMBER;

pn_1306_gecenay_faiz_tl        number;
pn_1306_gecenay_faiz        number;
pn_1306_gecenay_kom_tl        number;
pn_1306_gecenay_kom        number;
pn_1306_gecenay_kom_malkur        number;
pn_1306_gecenay_faiz_malkur        number;

pn_1306_tax_fc_1        number;
pn_1306_tax_fc_2        number;
pn_1306_tax_fc_3        number;
pn_1306_tax_lc_1        number;
pn_1306_tax_lc_2        number;
pn_1306_tax_lc_3        number;
pn_1306_tax_aciklama        number;

 PROCEDURE Kontrol_Sonrasi(pn_islem_no NUMBER) IS
   ln_kredi_teklif_satir_numara    NUMBER;
   ln_kredi_hesap_tutar       NUMBER;
   ls_kredi_hesap_doviz_kodu      CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   iliskili_faizrees_dk_yok       EXCEPTION;
   iliskili_kom_dk_yok           EXCEPTION;
   iliskili_komrees_dk_yok        EXCEPTION;
   ln_faiz_orani       NUMBER;
   ln_komisyon_orani      NUMBER;
   ls_dk_grup_kod                CBS_MUSTERI.DK_GRUP_KOD%TYPE;
   ls_modul_tur_kod                CBS_HESAP.modul_tur_kod%TYPE;
   ls_urun_tur_kod                CBS_HESAP.urun_tur_kod%TYPE;
   ls_urun_sinif_kod               CBS_HESAP.urun_sinif_kod%TYPE;
   ls_komreesdk               VARCHAR2(2000);
   ls_faizreesdk                     VARCHAR2(2000);
   ls_hesap_no                 CBS_HESAP_KREDI.hesap_no%TYPE;
   ls_endeks_doviz_kodu      CBS_DOVIZ_KODLARI.doviz_kodu%TYPE;
   ln_hesap_No        NUMBER;
   ln_txno         NUMBER;
   LN_TOP_TUTAR        NUMBER;
   ls_geriodeme_kapama_secimi    varchar2(200);
   LN_BAKIYE     number:=0;
   ln_TAHSIL_HESAP_NO number;
   ln_ILISKILI_HESAP_NO number;
   ls_ILISKILI_GL_NO varchar2(8);

  BEGIN

   SELECT kredi_teklif_satir_numara,
       b.tutar,
    a.doviz_kodu,
    a.faiz_orani,
    a.komisyon_orani,
       Pkg_Musteri.sf_musteri_dk_grup_kod_al(a.musteri_no),
       a.modul_tur_kod,
     a.urun_tur_kod,
    a.urun_sinif_kod,
    endeks_doviz_kodu,
    hesap_no,
          ABS(NVL(ANAPARA_TAHSILAT_TUTAR,0)) tahsil_TOPLAM,
      geriodeme_kapama_secimi,
   TAHSIL_HESAP_NO,
   ILISKILI_HESAP_NO,
   ILISKILI_GL_NO
   INTO   ln_kredi_teklif_satir_numara,
       ln_kredi_hesap_tutar,
          ls_kredi_hesap_doviz_kodu,
    ln_faiz_orani,
    ln_komisyon_orani,
    ls_dk_grup_kod,
       ls_modul_tur_kod,
     ls_urun_tur_kod,
    ls_urun_sinif_kod,
    ls_endeks_doviz_kodu,
    ln_hesap_No,
    LN_TOP_TUTAR,
    ls_geriodeme_kapama_secimi,
    ln_TAHSIL_HESAP_NO,
    ln_ILISKILI_HESAP_NO,
    ls_ILISKILI_GL_NO
   FROM CBS_HESAP_KREDI_ISLEM a,CBS_ISLEM b
   WHERE tx_no = pn_islem_no AND
      a.tx_no = b.numara;

  ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
             pn_islem_no,
          ln_hesap_no) ;

  Pkg_Kredi.sp_kredteklifdurumu_uygunmu(pn_islem_no);

  SELECT ABS(NVL(BAKIYE,0))
  INTO LN_BAKIYE
  FROM CBS_HESAP_BAKIYE
  WHERE HESAP_NO = LN_HESAP_NO;


  if  ls_geriodeme_kapama_secimi <>'KAPAMA' then
    pkg_kredi.sp_taksit_geriodeme_tutarayni(pn_islem_no, nvl(ln_top_tutar,0) );
    Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_bakiye   );
  end if;


   Pkg_Teminat.sp_teminat_kontrolsonra(pn_islem_no ,
      ln_kredi_teklif_satir_numara ,
    ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
    ls_endeks_doviz_kodu );

  Pkg_Kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);

  sp_kontrol_sonrasi_rezervasyon(pn_islem_no);

  if ln_TAHSIL_HESAP_NO is not null then
    pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1306',ln_TAHSIL_HESAP_NO);
  elsif ln_ILISKILI_HESAP_NO is not null then
    pkg_personel.SP_LOG_PERSONEL_HESAP_ISLEM(pn_islem_no,'1306',ln_ILISKILI_HESAP_NO);
  end if;

 if pkg_hesap.BadListFlag(ln_ILISKILI_HESAP_NO) = 'E'
 then
  RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '293' || Pkg_Hata.getucpointer);
 end if;

 EXCEPTION
 WHEN iliskili_komrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '703' || Pkg_Hata.getdelimiter || ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
        WHEN iliskili_faizrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '701' || Pkg_Hata.getdelimiter ||ls_hesap_no || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);

 END;

  PROCEDURE Dogrulama_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   NULL;
  END;

  PROCEDURE Dogrulama_Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
  /* teminat islem durum guncellenir */
 Pkg_Teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_no);
   Pkg_Kur_Rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);
  END;

  PROCEDURE Iptal_Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   NULL;
  END;

  PROCEDURE Iptal_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
    NULL;
  END;

  PROCEDURE sp_onayoncesi_kurtutarguncelle(pn_islem_no NUMBER)
  IS
   ln_hesap_no  CBS_HESAP_KREDI.hesap_no%TYPE;
   ln_rezervasyon_no   NUMBER;
   ls_doviz_kodu    CBS_HESAP_KREDI.doviz_kodu%TYPE;
   ls_tahsil_hesap_doviz CBS_HESAP_KREDI.doviz_kodu%TYPE;
   ln_kur   NUMBER;
   ln_Tahsil_toplam  NUMBER;
   ln_birikmis_faiz_kkdf_tutari NUMBER;
   ln_birikmis_faiz_bsmv_tutari NUMBER;
   ln_birikmis_kom_bsmv_tutari  NUMBER;
   ln_gecenyil_faiz_kkdf_tutari NUMBER;
   ln_gecenyil_faiz_bsmv_tutari NUMBER;
   ln_gecenyil_kom_bsmv_tutari  NUMBER;
   LN_BAKIYE     number:=0;
  CURSOR cursor_islem IS
  SELECT
    hesap_no,
     rezervasyon_no,
  doviz_kodu,
  tahsil_hesap_doviz,
  TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,
  TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,
  TAHSEDIL_GECENYIL_FAIZ_TUTARI,
  NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI ,0)+ NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0) +
  NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0) + NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0) +
  NVL(ANAPARA_TAHSILAT_TUTAR,0) tahsil_TOPLAM,
  TAHSEDIL_GECENYIL_KOMIS_TUTARI

  FROM CBS_HESAP_KREDI_ISLEM
  WHERE tx_no = pn_islem_no;

  BEGIN
    FOR cur_islem IN cursor_islem LOOP
        ln_hesap_no := cur_islem.hesap_no;
     ln_rezervasyon_no := cur_islem.rezervasyon_no;
     ls_doviz_kodu     :=  cur_islem.doviz_kodu;
     ls_tahsil_hesap_doviz:= cur_islem.tahsil_hesap_doviz;

        IF NVL(ln_rezervasyon_no,0) = 0 THEN
     IF ls_doviz_kodu <> Pkg_Genel.lc_al AND ls_tahsil_hesap_doviz = Pkg_Genel.lc_al THEN
         ln_kur:=Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','S');
       ELSE
       ln_kur:=Pkg_Kur.doviz_doviz_karsilik(ls_doviz_kodu ,Pkg_Genel.lc_al,NULL,1,1,NULL,NULL,'N','A');
       END IF;

      ln_Tahsil_toplam  := cur_islem.Tahsil_toplam;
    END IF;
     END LOOP;

     IF NVL(ln_rezervasyon_no,0) = 0 THEN
    UPDATE CBS_HESAP_KREDI_ISLEM
     SET kur  =ln_kur,
      toplam_tahsiledilecek_tutar = ln_Tahsil_toplam
    WHERE tx_no = pn_islem_no;
    END IF;

  END;

  PROCEDURE Onay_Sonrasi(pn_islem_no NUMBER)
  IS
   ln_hesap_no          cbs_hesap_kredi.hesap_no%type ;
   ls_doviz_kodu        cbs_hesap_kredi.doviz_kodu%type;
   ls_geriodeme_kapama_secimi   cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
   ln_txno        number;
   ln_kredi_hesap_tutar     number;
   ln_top_tutar       number;
   ln_bakiye       number:=0;
   ls_faiz_siklik_tipi     varchar2(200);
   ld_vade        date;
   BEGIN
     select hesap_no,
           doviz_kodu ,
      geriodeme_kapama_secimi,
         abs(nvl(anapara_tahsilat_tutar,0)) tahsil_toplam,
    faiz_siklik_tipi
     into  ln_hesap_no,
           ls_doviz_kodu ,
      ls_geriodeme_kapama_secimi,
      ln_top_tutar,
      ls_faiz_siklik_tipi
     from  cbs_hesap_kredi_islem
    where tx_no = pn_islem_no;

    ln_txno:=Pkg_Kredi.Sf_Bitmemis_HesapIslm_VarMi(NULL,
             pn_islem_no,
          ln_hesap_no) ;

  SELECT ABS(NVL(BAKIYE,0))
  INTO LN_BAKIYE
  FROM CBS_HESAP_BAKIYE
  WHERE HESAP_NO = LN_HESAP_NO;

  if  ls_geriodeme_kapama_secimi <>'KAPAMA' then
  pkg_kredi.sp_taksit_geriodeme_tutarayni(pn_islem_no, nvl(ln_top_tutar,0) );
    Pkg_Kredi.sp_taksit_vade_tutar_kontrol(pn_islem_no , ln_bakiye   );
  end if;
     Pkg_Tx1306.sp_onayoncesi_kurtutarguncelle(pn_islem_no);
 /* teminat Durum guncellenir */
     Pkg_Teminat.sp_teminat_onay_sonrasi(pn_islem_no,ln_hesap_no, ls_doviz_kodu,ls_geriodeme_kapama_secimi);

   Pkg_Kredi.sp_onayonce_taksit_sakla(    pn_islem_no ,ln_hesap_no);

 if ls_geriodeme_kapama_secimi <>'KAPAMA' then
  IF ls_faiz_siklik_tipi = 'INSTALLMENT DATE' THEN
     SELECT MIN(vade_tarih)
     INTO ld_vade
     FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
     WHERE tx_no = pn_islem_no and
         NVL(durum_kodu,'A') = 'A';

     UPDATE CBS_HESAP_KREDI
     SET faiz_tahakkuk_tarihi =ld_vade
     WHERE hesap_no= ln_hesap_no;
  END IF;
    end if;
     Pkg_Kredi.sp_taksit_sira_guncelle(pn_islem_no);

  BEGIN
     DELETE  FROM CBS_HESAP_KREDI_TAKSIT
    WHERE hesap_no = ln_hesap_no ;

    INSERT INTO CBS_HESAP_KREDI_TAKSIT(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
    taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,deferred_interest,deferred_tax,paid_deferred_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh,penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi,deferred_delayed_interest,paid_deferred_delayed_interest --seval.colak 20012022
    )
    SELECT  pn_islem_no,ln_hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
     taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,deferred_interest,deferred_tax,paid_deferred_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh,penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi,deferred_delayed_interest,paid_deferred_delayed_interest --seval.colak 20012022
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
       WHERE tx_no = pn_islem_no;
   EXCEPTION WHEN OTHERS THEN NULL;
  END;

  END;

  PROCEDURE Iptal_Onay_Sonrasi(pn_islem_no NUMBER) IS
   ls_durum_kodu CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE;
   ln_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE;
   ln_tahsiledilen_faiz_tutari     NUMBER :=0;
   ln_tahsiledilen_komisyon_tutar    NUMBER := 0;
   ln_birikmis_faiz_tutari      NUMBER := 0;
   ln_birikmis_komisyon_tutari     NUMBER := 0;
   ln_gecenyil_faiz_tutari      NUMBER := 0;
   ln_gecenyil_kom_tutari      NUMBER := 0;
   ln_kur          NUMBER;
   ln_faiz_tahakkuk_hesap_no      CBS_HESAP_KREDI.hesap_no%TYPE;
   ln_vergi_tahakkuk_hesap_no      CBS_HESAP_KREDI.hesap_no%TYPE;
   ld_faiz_baslangic_tarihi      DATE;
   ls_geriodeme_kapama_secimi     CBS_HESAP_KREDI_ISLEM.geriodeme_kapama_secimi%TYPE;
     ln_gecenyil_sch_faiz_tutari     NUMBER :=0;
   ln_birikmis_sch_faiz_tutari     NUMBER :=0;
   ln_tahakkuk_sch_faiz_tutari     NUMBER :=0;
    ln_tahsiledilen_faiz_tutar_lc     NUMBER :=0;
   ln_tahsiledilen_kom_tutar_lc     NUMBER :=0;
   ln_txno          NUMBER;
   ls_faiz_siklik_tipi   VARCHAR2(2000);
   ld_faiz_tahak_tarihi     DATE;
   ln_gecmis_aylarin_faizi    NUMBER;
   ln_gecmis_aylarin_komisyonu   NUMBER;
   ln_tahsedil_gecmis_aylar_faiz   NUMBER;
   ln_tahsedil_gecmis_aylar_kom NUMBER;
    BEGIN

  SELECT durum_kodu ,
    hesap_no,
    ABS(NVL(TAHSILEDILEN_FAIZ_TUTARI,0)) ,
   ABS(NVL(TAHSILEDILEN_KOMISYON_TUTARI,0)) ,
   ABS(NVL(KAPAMAONCESI_BIRIKMISFAIZTUTAR,0)),
   ABS(NVL(KAPAMAONCESI_BIRIKMISKOMSTUTAR,0)),
   ABS(NVL(GECENYIL_FAIZ_TUTARI,0)),
   ABS(NVL(GECENYIL_KOMISYON_TUTARI,0)),
   ABS(kur) ,
   faiz_tahakkuk_hesap_no ,
   vergi_tahakkuk_hesap_no,
   kapamaonce_faizbaslangictarihi,
   geriodeme_kapama_secimi,
   birikmis_sch_faizi  ,
   gecenyil_sch_faizi ,
   tahakkuk_sch_faiz_tutari,
   ABS(NVL(TAHSILEDILEN_FAIZ_TUTARI_lc,0)) ,
   ABS(NVL(TAHSILEDILEN_KOMIS_TUTARI_lc,0)),
   faiz_tahakkuk_tarihi,
   faiz_siklik_tipi,
   abs(nvl(gecmis_aylarin_faizi,0)),
   abs(nvl(gecmis_aylarin_komisyonu,0)),
   abs(nvl(tahsedil_gecmis_aylar_faiz,0)),
   abs(nvl(tahsedil_gecmis_aylar_komisyon,0))
  INTO   ls_durum_kodu   ,
       ln_hesap_No,
   ln_tahsiledilen_faiz_tutari,
   ln_tahsiledilen_komisyon_tutar,
   ln_birikmis_faiz_tutari,
   ln_birikmis_komisyon_tutari,
   ln_gecenyil_Faiz_tutari,
   ln_gecenyil_kom_tutari,
   ln_kur,
   ln_faiz_tahakkuk_hesap_no ,
   ln_vergi_tahakkuk_hesap_no,
   ld_faiz_baslangic_tarihi,
   ls_geriodeme_kapama_secimi,
   ln_birikmis_sch_faiz_tutari,
   ln_gecenyil_sch_faiz_tutari,
   ln_tahakkuk_sch_faiz_tutari,
   ln_tahsiledilen_faiz_tutar_lc,
   ln_tahsiledilen_kom_tutar_lc,
   ld_faiz_tahak_tarihi,
   ls_faiz_siklik_tipi,
   ln_gecmis_aylarin_faizi,
   ln_gecmis_aylarin_komisyonu,
   ln_tahsedil_gecmis_aylar_faiz,
   ln_tahsedil_gecmis_aylar_kom
  FROM CBS_HESAP_KREDI_ISLEM
  WHERE tx_no = pn_islem_no;

    ln_txno := Pkg_Kredi.sf_islemvarsa_uyar(pn_islem_no,
            ln_hesap_no   );

   ln_txno := Pkg_Kredi.sf_islemvarsa_uyar(pn_islem_no,
            ln_hesap_no   );

 sp_iptalkontrol(pn_islem_no);

    UPDATE CBS_HESAP_KREDI
    SET    kapanis_tarihi = NULL,
        durum_kodu    = 'A',
        tahsiledilen_faiz_tutari    = NVL(ln_tahsiledilen_faiz_tutari,0) ,
     tahsiledilen_komisyon_tutari= NVL(LN_tahsiledilen_komisyon_tutar,0),
     birikmis_faiz_tutari    = ln_birikmis_faiz_tutari ,
     Birikmis_komisyon_tutari    = ln_birikmis_komisyon_tutari,
     gecenyil_faiz_tutari        = NVL(ln_gecenyil_Faiz_tutari,0) ,
     gecenyil_komisyon_tutari    = NVL(ln_gecenyil_kom_tutari,0),
     faiz_baslangic_tarihi      = ld_faiz_baslangic_tarihi,
/*07012005 sevalb eklendi*/
     tahsiledilen_faiz_tutari_lc    = NVL(ln_tahsiledilen_faiz_tutar_lc,0) ,
     tahsiledilen_komis_tutari_lc= NVL(LN_tahsiledilen_kom_tutar_lc,0),
     gecmis_aylarin_faizi     = NVL(ln_gecmis_aylarin_faizi,0) ,
     gecmis_aylarin_komisyonu    = NVL(ln_gecmis_aylarin_komisyonu,0)
/*07012005 sevalb subeler cari henuz olmadigindan kapali.*/
 /*   , birikmis_sch_faizi  =    ln_birikmis_sch_faiz_tutari,
     gecenyil_sch_faizi =  ln_gecenyil_sch_faiz_tutari,
     tahakkuk_sch_faiz_tutari =   ln_tahakkuk_sch_faiz_tutari
     */
    WHERE  hesap_no = ln_hesap_no;

 /* teminat Durum guncellenir */
 Pkg_Teminat.sp_teminat_iptalonaysonrasi(pn_islem_no,ls_geriodeme_kapama_secimi );
   Pkg_Kur_Rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);


   IF ls_faiz_siklik_tipi = 'INSTALLMENT DATE' THEN
    UPDATE CBS_HESAP_KREDI
    SET faiz_tahakkuk_tarihi =ld_faiz_tahak_tarihi
    WHERE hesap_no= ln_hesap_no;
 END IF;

  BEGIN
     DELETE  FROM CBS_HESAP_KREDI_TAKSIT
    WHERE hesap_no = ln_hesap_no ;

    INSERT INTO CBS_HESAP_KREDI_TAKSIT(yaratan_tx_no, hesap_no, sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
    taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,deferred_interest,deferred_tax,paid_deferred_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh,penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi,deferred_delayed_interest,paid_deferred_delayed_interest --seval.colak 20012022
    )
    SELECT  yaratan_tx_no, NVL(hesap_no,ln_hesap_no ), sira_no, taksit, anapara, faiz, kkdf, bsmv, vade_tarih, kal_anapara, kdv, kdvli_taksit, tahsil_edilecek_taksit, yaratildigi_tarih, yaratan_kullanici, durum_kodu, odeme_tarihi, gecikme_faiz_tutari, kur_trl, anapara_trl, faiz_trl, kdv_trl,
    taksit_gun_sayisi,hesaplama_gun_sayisi,taksit_baz_anapara,taksit_faiz_orani,taksit_bsmv_orani,taksit_kkdf_orani,ozel_odeme_tutari,orj_vergi_tutari,orj_faiz_tutari,ek_faiz_tutari,deferred_interest,deferred_tax,paid_deferred_interest,paid_deferred_tax,tahsil_taksit,tahsil_anapara,tahsil_faiz,tahsil_kkdf,tahsil_bsmv,tahsil_gecikme_faiz_tutari,deferred_tax2,paid_deferred_tax2,tahakkuk_eh,penalty_amount,paid_penalty_amount,deferred_penalty_amount,paid_deferred_penalty_amount,ap_gecikme_gun_sayisi,faiz_gecikme_gun_sayisi,deferred_delayed_interest,paid_deferred_delayed_interest --seval.colak 20012022
    FROM CBS_HESAP_KREDI_TAKS_ONAY_ISL
       WHERE tx_no = pn_islem_no;
   EXCEPTION WHEN OTHERS THEN NULL;
  END;
 EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
  END;


  PROCEDURE Reddetme_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN

    UPDATE CBS_HESAP_KREDI_ISLEM
 SET durum_kodu = 'R'
 WHERE tx_no = pn_islem_no;
 /* teminat islem Durum guncellenir */
 Pkg_Teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
 Pkg_Kur_Rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);
  END;

  PROCEDURE Tamam_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   NULL;
  END;

  PROCEDURE Basim_Sonrasi(pn_islem_no NUMBER) IS
  BEGIN
   NULL;
  END;

  PROCEDURE sp_muhasebesonrasi_guncelle(pn_islem_no NUMBER)
  IS
   ls_durum_kodu CBS_HESAP_KREDI_ISLEM.durum_kodu%TYPE;
   ln_hesap_no CBS_HESAP_KREDI.hesap_no%TYPE;
   ln_tahsiledilen_faiz_tutari     NUMBER :=0;
   ln_tahsiledilen_komisyon_tutar    NUMBER := 0;
   ln_tahsiledilen_birikmis_faiz     NUMBER := 0;
   ln_tahsiledilen_birikmis_kom     NUMBER := 0;
   ln_gecenyil_faiz_tutari      NUMBER := 0;
   ln_gecenyil_kom_tutari      NUMBER := 0;
     ln_faiz_tahakkuk_hesap_no      CBS_HESAP_KREDI.hesap_no%TYPE;
   ln_vergi_tahakkuk_hesap_no      CBS_HESAP_KREDI.hesap_no%TYPE;
   ld_faiz_baslangic_tarihi      DATE;
   ln_birikmis_faiz_tutari      NUMBER ;
   ln_birikmis_komisyon_tutari     NUMBER;
   ln_tahakeden_sch_faiz_tutari      NUMBER := 0;
   ln_gecenyil_sch_faiz_tutari     NUMBER :=0;
   ln_birikmis_sch_faiz_tutari     NUMBER :=0;
      ls_repayment_type        varchar2(200);
   ln_anapara_tutar        number :=0;
   ln_takstutar          number :=0;
     ln_gecmis_aylarin_faizi    NUMBER;
   ln_gecmis_aylarin_komisyonu   NUMBER;
   ln_tahsedil_gecmis_aylar_faiz   NUMBER;
   ln_tahsedil_gecmis_aylar_kom NUMBER;
   CURSOR cur_taksit IS
    SELECT hesap_No,
        SIRA_NO,
        vade_tarih,
        nvl(anapara,0) anapara,
     durum_kodu
    FROM CBS_HESAP_KREDI_TAKSIT_ISLEM
    WHERE tx_no = pn_islem_no AND
    nvl(durum_kodu,'A')  = 'A'
    ORDER BY vade_tarih
    for update of durum_kodu,odeme_tarihi;

 BEGIN
  SELECT durum_kodu ,
    hesap_no,
    Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0))) + Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))) + Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECMIS_AYLAR_FAIZ,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0))) +Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0))) +  Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECMIS_AYLAR_KOMISYON,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI ,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI ,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0))),
   faiz_tahakkuk_hesap_no ,
   vergi_tahakkuk_hesap_no,
   faiz_baslangic_tarihi,
   birikmis_faiz_tutari,
   birikmis_komisyon_tutari,
      ABS(NVL(GECENYIL_SCH_FAIZI,0)) +  ABS(NVL(BIRIKMIS_SCH_FAIZI,0)), --  number_list(pn_1309_gecenyilbdak_sch_tl),
   ABS(NVL(GECENYIL_SCH_FAIZI,0)),
   ABS(NVL(BIRIKMIS_SCH_FAIZI,0)),
   abs(nvl(anapara_tahsilat_tutar,0)),
   repayment_type,
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECMIS_AYLAR_FAIZ,0))),
   Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECMIS_AYLAR_komisyon,0)))
  INTO   ls_durum_kodu   ,
       ln_hesap_No,
   ln_tahsiledilen_faiz_tutari,
   LN_tahsiledilen_komisyon_tutar,
   ln_tahsiledilen_birikmis_faiz,
   ln_tahsiledilen_birikmis_kom,
   ln_gecenyil_Faiz_tutari,
   ln_gecenyil_kom_tutari,
   ln_faiz_tahakkuk_hesap_no ,
   ln_vergi_tahakkuk_hesap_no,
   ld_faiz_baslangic_tarihi ,
   ln_birikmis_faiz_tutari,
   ln_birikmis_komisyon_tutari,
   ln_tahakeden_sch_faiz_tutari,
   ln_gecenyil_sch_faiz_tutari,
   ln_birikmis_sch_faiz_tutari,
   ln_anapara_tutar,
   ls_repayment_type,
      ln_tahsedil_gecmis_aylar_faiz,
        ln_tahsedil_gecmis_aylar_kom
  FROM CBS_HESAP_KREDI_ISLEM
  WHERE tx_no = pn_islem_no;

/*  IF ld_faiz_baslangic_tarihi IS NOT NULL THEN
        ld_faiz_baslangic_tarihi :=  ld_faiz_baslangic_tarihi + 1;
     END IF;

 IF (ls_durum_kodu != 'K' )  AND
   (   ABS(  NVL( ln_tahsiledilen_birikmis_faiz,0 )) + ABS(NVL( ln_tahsiledilen_birikmis_kom ,0 )) = 0 ) THEN
   ln_tahakeden_sch_faiz_tutari := 0;
 ELSE
    ln_gecenyil_sch_faiz_tutari := 0;
   ln_birikmis_sch_faiz_tutari := 0;
 END IF;
*/

    UPDATE CBS_HESAP_KREDI
    SET    durum_kodu = ls_durum_kodu,
        kapanis_tarihi = DECODE(LS_Durum_kodu,'K',Pkg_Muhasebe.banka_tarihi_bul,NULL),
        tahsiledilen_faiz_tutari    = NVL(tahsiledilen_faiz_tutari,0) + NVL(ln_tahsiledilen_faiz_tutari,0) ,
     tahsiledilen_komisyon_tutari= NVL(tahsiledilen_komisyon_tutari,0) + NVL(LN_tahsiledilen_komisyon_tutar,0),
     birikmis_faiz_tutari    = DECODE(LS_Durum_kodu,'K', 0, ABS(  Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(ln_birikmis_faiz_tutari,0))) - ABS(NVL(ln_tahsiledilen_birikmis_faiz,0)))),
     Birikmis_komisyon_tutari    = DECODE(LS_Durum_kodu,'K', 0, ABS( Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(ln_birikmis_komisyon_tutari,0))) - ABS(NVL(ln_tahsiledilen_birikmis_kom,0)))),
     gecenyil_faiz_tutari        = DECODE(LS_Durum_kodu,'K', 0, ABS(NVL(gecenyil_faiz_tutari,0) - NVL(ln_gecenyil_Faiz_tutari,0))) ,
     gecenyil_komisyon_tutari    = DECODE(LS_Durum_kodu,'K', 0, ABS(NVL(gecenyil_komisyon_tutari,0)) - ABS(NVL(ln_gecenyil_kom_tutari,0))),
     GECMIS_AYLARIN_FAIZI    = DECODE(LS_Durum_kodu,'K', 0, ABS(NVL(GECMIS_AYLARIN_FAIZI,0) - NVL(ln_tahsedil_gecmis_aylar_faiz,0))) ,
     GECMIS_AYLARIN_KOMISYONU    = DECODE(LS_Durum_kodu,'K', 0, ABS(NVL(GECMIS_AYLARIN_KOMISYONU,0)) - ABS(NVL(ln_tahsedil_gecmis_aylar_kom,0))),
        faiz_baslangic_tarihi       = NVL(ld_faiz_baslangic_tarihi,faiz_baslangic_tarihi   ),
/*0701/05 sevalb*/
        tahsiledilen_faiz_tutari_lc  = NVL(tahsiledilen_faiz_tutari_lc,0) +Pkg_Kur.yuvarla(Pkg_Genel.lc_al, Pkg_Kur.doviz_doviz_karsilik(doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(ln_tahsiledilen_faiz_tutari,0),1,NULL,NULL,'N','A')),
        tahsiledilen_komis_tutari_lc  = NVL(tahsiledilen_komis_tutari_lc,0) +Pkg_Kur.yuvarla(Pkg_Genel.lc_al, Pkg_Kur.doviz_doviz_karsilik(doviz_kodu ,Pkg_Genel.lc_al,NULL,NVL(ln_tahsiledilen_komisyon_tutar,0),1,NULL,NULL,'N','A'))

/*      ,gecenyil_sch_faizi = ln_gecenyil_sch_faiz_tutari,
       birikmis_sch_faizi =ln_birikmis_sch_faiz_tutari,
     tahakkuk_sch_faiz_tutari  = ABS(NVL(  tahakkuk_sch_faiz_tutari ,0))+ln_tahakeden_sch_faiz_tutari
 */
    WHERE  hesap_no = ln_hesap_no;

     IF LS_Durum_kodu = 'K' THEN
      BEGIN
     UPDATE CBS_HESAP_KREDI_TAKSIT
    SET durum_kodu = 'O',
       ODEME_TARIHI =Pkg_Muhasebe.BANKA_TARIHI_BUL
    WHERE hesap_no = ln_hesap_no AND
      DURUM_KODU = 'A';
     EXCEPTION WHEN OTHERS THEN NULL;
    END;
   else
      if  ls_repayment_type  = 'INSTALLMENT DATE' then
    ln_takstutar := 0;
      for c_taksit in cur_taksit loop
         if nvl(ln_takstutar,0) < nvl(ln_anapara_tutar,0) then
         ln_takstutar := c_taksit.anapara + nvl(ln_takstutar,0);
          update  CBS_HESAP_KREDI_TAKSIT
       set durum_kodu = 'O',
           ODEME_TARIHI =Pkg_Muhasebe.BANKA_TARIHI_BUL
       where hesap_no = c_taksit.hesap_no and sira_no = c_taksit.sira_no;

       update  CBS_HESAP_KREDI_TAKSIT_islem
       set durum_kodu = 'O',
           ODEME_TARIHI =Pkg_Muhasebe.BANKA_TARIHI_BUL
       where current of cur_taksit;

      end if;
     end loop;
  end if;

 END IF;

  Exception when no_data_found then null;
  End;

 PROCEDURE Muhasebelesme(pn_islem_no NUMBER)
 IS
    varchar_list            Pkg_Muhasebe.varchar_array;
    number_list       Pkg_Muhasebe.number_array;
    date_list       Pkg_Muhasebe.date_array;
    boolean_list      Pkg_Muhasebe.boolean_array;
 ln_fis_no       CBS_FIS.numara%TYPE ;
 ls_islem_kod               CBS_ISLEM.islem_kod%TYPE :='1306';
 ls_banka_aciklama          VARCHAR2(2000);
 ls_fis_aciklama      VARCHAR2(2000);
 ls_aciklama                VARCHAR2(2000);
 ls_musteri_aciklama        VARCHAR2(2000);
 ls_yerlesim_kod      CBS_MUSTERI.yerlesim_kod%TYPE;
 ln_rezervasyon_no          NUMBER;
 ln_kur         NUMBER;
 ln_fark_kur       NUMBER;
 ln_musteri_kur        NUMBER;
 ln_maliyet_kur        NUMBER;
 ln_kkdf_Ara_tutar      NUMBER;
 ln_bsmv_ara_tutar     NUMBER;
 ln_TAHSIL_TAHAKKUK_FAIZ   number;
    ls_dk_grup_kod      CBS_MUSTERI.DK_GRUP_KOD%TYPE;
 ls_modul_tur_kod     CBS_HESAP.modul_tur_kod%TYPE;
 ls_urun_tur_kod      CBS_HESAP.urun_tur_kod%TYPE;
 ls_urun_sinif_kod     CBS_HESAP.urun_sinif_kod%TYPE;
 iliskili_faiz_dk_yok       EXCEPTION;
 iliskili_faizrees_dk_yok   EXCEPTION;
 iliskili_kom_dk_yok       EXCEPTION;
 iliskili_komrees_dk_yok    EXCEPTION;
    ls_geriodeme_kapama_secimi     CBS_HESAP_KREDI_ISLEM.geriodeme_kapama_secimi%TYPE;

 ln_iliskili_hesap_no number;
 ls_iliskili_gl_no varchar2(8);
 ln_rate     number;
 ln_top_lc   number;
 ln_top_fc   number;
 ln_rate_last_year number ;

 CURSOR islem_cursor (pn_islemno CBS_ISLEM.numara%TYPE) IS
      SELECT aciklama,
       iliskili_hesap_no,
       iliskili_gl_no,--TA 17012006
       Pkg_Hesap.HESAPTANSUBEAL(hesap_no),--TA:Pkg_Hesap.HESAPTANSUBEAL(iliskili_hesap_no),
       Pkg_Tx.Amir_BolumKodu_Al( tx_no),
       doviz_kodu,
       hesap_no,
       Pkg_Hesap.HESAPTANSUBEAL(hesap_no),
       TO_CHAR(Hesap_no),
       tahsil_hesap_doviz,
       tahsil_hesap_no,
       Pkg_Hesap.HESAPTANSUBEAL(tahsil_hesap_no),
       Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(ANAPARA_TAHSILAT_TUTAR,0))),
       ABS(NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ANAPARA_TAHSILAT_TUTAR),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0))),
       ABS(NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_BIRIKMIS_FAIZ_TUTARI),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0))),
       ABS(NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_BIRIKMIS_KOMIS_TUTARI),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))),
       ABS(NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_GECENYIL_FAIZ_TUTARI),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0))),
       ABS( NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_GECENYIL_KOMIS_TUTARI),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECMIS_AYLAR_FAIZ,0))),
       ABS(NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_GECMIS_AYLAR_FAIZ),0)),
       Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSEDIL_GECMIS_AYLAR_KOMISYON,0))),
       ABS( NVL(Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * TAHSEDIL_GECMIS_AYLAR_KOMISYON),0)),
       kur,
       abs(nvl(TAHSILEDILECEK_TAHAKKUK_FAIZ,0)) ,--TAHSILEDILECEK_TAHAKKUK_FAIZ
          Pkg_Kur.yuvarla(doviz_kodu,ABS(NVL(TAHSILEDILECEK_TAHAKKUK_FAIZ,0))) +Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))) +   Pkg_Kur.yuvarla(doviz_kodu,abs(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0))) + Pkg_Kur.yuvarla(doviz_kodu,abs(NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0))) + Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0)))
           + Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECMIS_AYLAR_FAIZ,0))) +  Pkg_Kur.yuvarla(doviz_kodu,ABS( NVL(TAHSEDIL_GECMIS_AYLAR_KOMISYON,0))),  -- nvl(TOPLAM_TAHSILEDILECEK_TUTAR,0),
       Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ABS(NVL(TAHSILEDILECEK_TAHAKKUK_FAIZ,0))) + Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ABS(NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))) +   Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ABS(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0))) + Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ABS(NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0))) + Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur * ABS(NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0))) +
         + Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur *ABS( NVL(TAHSEDIL_GECMIS_AYLAR_FAIZ,0))) + Pkg_Kur.YUVARLA(Pkg_Genel.lc_al,kur *ABS( NVL(TAHSEDIL_GECMIS_AYLAR_KOMISYON,0))),  -- nvl(TOPLAM_TAHSILEDILECEK_TUTAR,0),  , --number_list(pn_1306_tahak_top_tl)
               Pkg_Musteri.sf_musteri_dk_grup_kod_al(musteri_no),
       rezervasyon_no,
       Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI),0)) +  Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECENYIL_FAIZ_TUTARI),0)) + Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECMIS_AYLAR_FAIZ),0)) ,--kkdf ara tutar
       Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI),0)) + Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI),0)) + Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECENYIL_FAIZ_TUTARI),0)) + Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECMIS_AYLAR_FAIZ),0))+Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECENYIL_KOMIS_TUTARI),0))+ Pkg_Kur.yuvarla(doviz_kodu,NVL(ABS(TAHSEDIL_GECMIS_AYLAR_KOMISYON),0)), --bsmv ara tutar
       MODUL_TUR_KOD,
        URUN_TUR_KOD,
       URUN_SINIF_KOD,
       NVL(valor_tarihi,Pkg_Muhasebe.banka_tarihi_bul),
       Pkg_Musteri.SF_YERLESIM_KOD_AL(musteri_no),
          geriodeme_kapama_secimi,
/*290504*/
       DECODE(NVL(GECENYIL_SCH_FAIZI,0),0,0,Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.LC_AL,
     Pkg_Tarih.yilin_son_is_gunu(TRUNC(Pkg_Muhasebe.BANKA_TARIHI_BUL,'YYYY') -1),
     GECENYIL_SCH_FAIZI,1,NULL,NULL,'N','A')),--number_list(pn_3251_gecenyilbdak_sch_tl) onceki yila ait TCMB kurlu,
     Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.LC_AL,NULL,GECENYIL_SCH_FAIZI,1,NULL,NULL,'N','A'),--  number_list(pn_1306_gecenyilbdak_sch_tl),
     Pkg_Kur.doviz_doviz_karsilik(doviz_kodu,Pkg_Genel.LC_AL,NULL,BIRIKMIS_SCH_FAIZI,1,NULL,NULL,'N','A'),--  number_list(pn_1306_gecenyilbdak_sch_tl),
        null,--prefix_istatistik_kodu_faiz||tahsil_hesap_doviz||ISTATISTIK_KODU_faiz istatistik_kodu_faiz ,
        null --prefix_istatistik_kodu_kapama||doviz_kodu||ISTATISTIK_KODU_kapama istatistik_kodu_kapama
  FROM CBS_HESAP_KREDI_ISLEM
  WHERE tx_no=pn_islemno;

  BEGIN
 varchar_list(pn_1306_banka_aciklama) := NULL;
 varchar_list(pn_1306_faiz_hesap_no) := NULL;
 varchar_list(pn_1306_faiz_hesap_sube) := NULL;
 varchar_list(pn_1306_fis_aciklama) := NULL;
 varchar_list(pn_1306_iliskili_faizrees_dk) := NULL;
 varchar_list(pn_1306_iliskili_faiz_dk) := NULL;
 varchar_list(pn_1306_iliskili_hesap_no) := NULL;
 varchar_list(pn_1306_iliskili_hesap_sube) := NULL;
 varchar_list(pn_1306_iliskili_komrees_dk) := NULL;
 varchar_list(pn_1306_iliskili_kom_dk) := NULL;
 varchar_list(pn_1306_islem_sube) := NULL;
 varchar_list(pn_1306_istatistik_faiz) := NULL;
 varchar_list(pn_1306_istatistik_kodu_kapama) := NULL;
 varchar_list(pn_1306_kredi_doviz) := NULL;
 varchar_list(pn_1306_kredi_hesap_no) := NULL;
 varchar_list(pn_1306_kredi_hesap_sube) := NULL;
 varchar_list(pn_1306_musteri_aciklama) := NULL;
 varchar_list(pn_1306_referans) := NULL;
 varchar_list(pn_1306_tahsil_hesap_doviz) := NULL;
 varchar_list(pn_1306_tahsil_hesap_no) := NULL;
 varchar_list(pn_1306_tahsil_hesap_sube) := NULL;
 number_list(pn_1306_anapara_farkkur):= 0;
 number_list(pn_1306_anapara_malkur):= 0;
 number_list(pn_1306_anapara_muskur):= 0;
 number_list(pn_1306_anapara_tutar):= 0;
 number_list(pn_1306_anapara_tutar_tl):= 0;
 number_list(pn_1306_birikmis_faiz):= 0;
 number_list(pn_1306_birikmis_faiz_malkur):= 0;
 number_list(pn_1306_birikmis_faiz_tl):= 0;
 number_list(pn_1306_birikmis_kom):= 0;
 number_list(pn_1306_birikmis_kom_malkur):= 0;
 number_list(pn_1306_birikmis_kom_tl):= 0;
 number_list(pn_1306_birikmis_sch_tl):= 0;
 number_list(pn_1306_faiz_fark):= 0;
 number_list(pn_1306_gecenyilbdak_sch_tl):= 0;
 number_list(pn_1306_gecenyil_faiz):= 0;
 number_list(pn_1306_gecenyil_faiz_malkur):= 0;
 number_list(pn_1306_gecenyil_faiz_tl):= 0;
 number_list(pn_1306_gecenyil_kom):= 0;
 number_list(pn_1306_gecenyil_kom_malkur):= 0;
 number_list(pn_1306_gecenyil_kom_tl):= 0;
 number_list(pn_1306_gecenyil_sch_tl):= 0;
 number_list(pn_1306_kur):= 0;
 number_list(pn_1306_maliyet_kur):= 0;
 number_list(pn_1306_musteri_kur):= 0;
 number_list(pn_1306_gecenay_faiz):= 0;
 number_list(pn_1306_gecenay_faiz_malkur):= 0;
 number_list(pn_1306_gecenay_faiz_tl):= 0;
 number_list(pn_1306_gecenay_kom):= 0;
 number_list(pn_1306_gecenay_kom_malkur):= 0;
 number_list(pn_1306_gecenay_kom_tl):= 0;

 number_list(pn_1306_tax_fc_1):= 0;
 number_list(pn_1306_tax_fc_2):= 0;
 number_list(pn_1306_tax_fc_3):= 0;
 number_list(pn_1306_tax_lc_1):= 0;
 number_list(pn_1306_tax_lc_2):= 0;
 number_list(pn_1306_tax_lc_3):= 0;
 varchar_list(pn_1306_tax_aciklama):= 'Accrual Tax';

 number_list(pn_1306_tahak_top):= 0;
 number_list(pn_1306_tahak_top_tl):= 0;
 number_list(pn_1306_tahsil_top_muskur):= 0;
 date_list(pn_1306_valor_tarihi) := NULL;
 boolean_list(pn_1306_kredi_tl):= FALSE;
 boolean_list(pn_1306_kredi_yp):= FALSE;
 boolean_list(pn_1306_musteri_kuru_buyukse):= FALSE;
 boolean_list(pn_1306_musteri_kuru_kucukse):= FALSE;
 boolean_list(pn_1306_tahsil_doviz_tl):= FALSE;
 boolean_list(pn_1306_tahsil_doviz_yp):= FALSE;

/* islem bilgisi detaylari alinir */

   ls_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(1306) ;

   IF islem_cursor%isopen THEN
          CLOSE islem_cursor;
    END IF;

      OPEN islem_cursor(pn_islem_no);
     FETCH islem_cursor INTO
         ls_fis_aciklama,
      ln_iliskili_hesap_no,--varchar_list(pn_1306_iliskili_hesap_no),
      ls_iliskili_gl_no,
      varchar_list(pn_1306_iliskili_hesap_sube),
      varchar_list(pn_1306_islem_sube),
      varchar_list(pn_1306_kredi_doviz),
      varchar_list(pn_1306_kredi_hesap_no),
      varchar_list(pn_1306_kredi_hesap_sube),
      varchar_list(pn_1306_referans),
      varchar_list(pn_1306_tahsil_hesap_doviz),
      varchar_list(pn_1306_tahsil_hesap_no),
      varchar_list(pn_1306_tahsil_hesap_sube),
      number_list(pn_1306_anapara_tutar),
      number_list(pn_1306_anapara_tutar_tl),
      number_list(pn_1306_birikmis_faiz),
      number_list(pn_1306_birikmis_faiz_tl),
      number_list(pn_1306_birikmis_kom),
      number_list(pn_1306_birikmis_kom_tl),
      number_list(pn_1306_gecenyil_faiz),
      number_list(pn_1306_gecenyil_faiz_tl),
      number_list(pn_1306_gecenyil_kom),
      number_list(pn_1306_gecenyil_kom_tl),
      number_list(pn_1306_gecenay_faiz),
      number_list(pn_1306_gecenay_faiz_tl),
      number_list(pn_1306_gecenay_kom),
      number_list(pn_1306_gecenay_kom_tl),
      ln_kur,
      ln_TAHSIL_TAHAKKUK_FAIZ,
      number_list(pn_1306_tahak_top),
      number_list(pn_1306_tahak_top_tl),
         ls_dk_grup_kod,
      ln_rezervasyon_no,
         ln_kkdf_ara_tutar,
      ln_bsmv_ara_tutar,
         ls_modul_tur_kod,
          ls_urun_tur_kod,
         ls_urun_sinif_kod,
      date_list(pn_1306_valor_tarihi),
      ls_yerlesim_kod,
      ls_geriodeme_kapama_secimi,
       number_list(pn_1306_gecenyilbdak_sch_tl),
        number_list(pn_1306_gecenyil_sch_tl),
        number_list(pn_1306_birikmis_sch_tl),
       varchar_list(pn_1306_istatistik_faiz),
       varchar_list(pn_1306_istatistik_kodu_kapama);

 IF islem_cursor%isopen THEN
          CLOSE islem_cursor;
    END IF;

 if ln_iliskili_hesap_no is not null then
    varchar_list(pn_1306_iliskili_hesap_no):=to_char(ln_iliskili_hesap_no);
    varchar_list(pn_1306_iliskili_hesap_sube):=Pkg_Hesap.HESAPTANSUBEAL(ln_iliskili_hesap_no);
    varchar_list(pn_1306_ILISKILI_HESAP_TUR):='VS';
 elsif ls_iliskili_gl_no is not null then
  varchar_list(pn_1306_iliskili_hesap_no):=ls_iliskili_gl_no;
  varchar_list(pn_1306_iliskili_hesap_sube):=Pkg_Hesap.HESAPTANSUBEAL(to_number(varchar_list(pn_1306_kredi_hesap_no)));
  varchar_list(pn_1306_ILISKILI_HESAP_TUR):='DK';
 end if;

/*** Liste Deger Atama Kismi **/
IF  NVL(number_list(pn_1306_birikmis_faiz),0) <> 0 THEN
    Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
         lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
         NULL,NULL, NULL,varchar_list(pn_1306_iliskili_faiz_dk));
   IF  varchar_list(pn_1306_iliskili_faiz_dk) IS NULL THEN
     RAISE iliskili_faiz_dk_yok;
   END IF;
 END IF;
/*faiz reeskont dk */

IF  NVL(number_list(pn_1306_gecenyil_faiz),0) <> 0 or NVL(number_list(pn_1306_gecenay_faiz),0) <> 0 THEN
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
         lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
         NULL,NULL, NULL,varchar_list(pn_1306_iliskili_faizrees_dk));
   IF  varchar_list(pn_1306_iliskili_faizrees_dk) IS NULL AND  ( NVL(number_list(pn_1306_gecenyil_faiz),0)  <> 0  or NVL(number_list(pn_1306_gecenay_faiz),0) <> 0 ) THEN
     RAISE iliskili_faizrees_dk_yok;
   END IF;
END IF;

 IF  NVL(number_list(pn_1306_birikmis_kom),0) <> 0 THEN
/*komisyon dk */
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
         lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 5,
         NULL,NULL, NULL,varchar_list(pn_1306_iliskili_kom_dk));

   IF  varchar_list(pn_1306_iliskili_kom_dk) IS NULL THEN
     RAISE iliskili_kom_dk_yok;
   END IF;
  END IF;
 IF  NVL(number_list(pn_1306_gecenyil_kom),0) <> 0 or NVL(number_list(pn_1306_gecenay_kom),0) <> 0  THEN
/*komisyon reeskont dk */
 Pkg_Muhasebe.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
         lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 6,
         NULL,NULL, NULL,varchar_list(pn_1306_iliskili_komrees_dk));

   IF  varchar_list(pn_1306_iliskili_komrees_dk) IS NULL  AND  ( NVL(number_list(pn_1306_gecenyil_kom),0) <> 0 or  NVL(number_list(pn_1306_gecenay_kom),0) <> 0 ) THEN
     RAISE iliskili_komrees_dk_yok;
   END IF;
 END IF;

/**** varchar list ****/
   ls_aciklama :=   Pkg_Genel.ISLEM_ADI_AL(1306) ;

   Pkg_Parametre.deger('1306_BANKA_ACIKLAMA',ls_banka_aciklama);
   Pkg_Parametre.deger('1306_MUSTERI_ACIKLAMA',ls_musteri_aciklama);
   log_at('hakan_1306_001','ln_rate',ln_rate);
   Pkg_Parametre.deger('G_SALES_TAX_RATE',ln_rate);
   Pkg_Parametre.deger('G_SALES_TAX_RATE_LAST_YEAR',ln_rate_last_year); --sevalb24122010


   varchar_list(pn_1306_fis_aciklama) := ls_aciklama;
   varchar_list(pn_1306_banka_aciklama)  := NVL(ls_fis_aciklama,ls_aciklama);
   varchar_list(pn_1306_musteri_aciklama):= NVL(ls_fis_aciklama,ls_aciklama);

/**** boolean list ****/
 boolean_list(pn_1306_kredi_tl) := FALSE ;
 boolean_list(pn_1306_kredi_yp) :=FALSE ;
 boolean_list(pn_1306_musteri_kuru_buyukse) := FALSE ;
 boolean_list(pn_1306_musteri_kuru_kucukse) := FALSE ;
 boolean_list(pn_1306_tahsil_doviz_tl) := FALSE ;
 boolean_list(pn_1306_tahsil_doviz_yp) := FALSE ;


  IF varchar_list(pn_1306_kredi_doviz) = Pkg_Genel.lc_al THEN
   boolean_list(pn_1306_kredi_tl) := TRUE ;
  ELSE
    boolean_list(pn_1306_kredi_yp) := TRUE ;
  END IF;

  IF varchar_list(pn_1306_tahsil_hesap_doviz) = Pkg_Genel.lc_al THEN
    boolean_list(pn_1306_tahsil_doviz_tl) := TRUE;
  ELSE
   boolean_list(pn_1306_tahsil_doviz_yp) := TRUE;
  END IF;

/**** number list ****/
/*rezervasyon doluysa */
     number_list(pn_1306_kur) := ln_kur;

    IF NVL(ln_rezervasyon_no,0) != 0 THEN
  Pkg_Kur_Rezervasyon.rezervasyon_SATIS_bilgisi_al(ln_rezervasyon_no,number_list(pn_1306_musteri_kur),number_list(pn_1306_maliyet_kur));
  ELSE
  number_list(pn_1306_musteri_kur) := ln_kur; --musteri SATIr
  number_list(pn_1306_maliyet_kur) := NVL(Pkg_Kur.doviz_doviz_karsilik(varchar_list(pn_1306_kredi_doviz),Pkg_Genel.LC_AL,NULL,1,3,NULL,NULL,'N','S'),0); --maliyet esas satis
  END IF;

 IF varchar_list(pn_1306_kredi_doviz) <> Pkg_Genel.lc_al AND  varchar_list(pn_1306_tahsil_hesap_doviz) = Pkg_Genel.lc_al THEN
   IF NVL(number_list(pn_1306_musteri_kur),0) > NVL(number_list(pn_1306_maliyet_kur),0) THEN
    boolean_list( pn_1306_musteri_kuru_buyukse):=TRUE;
  ELSE
    boolean_list( pn_1306_musteri_kuru_kucukse):=TRUE;
 END IF;
 END IF;

/* hesaplamalar */
   ln_musteri_kur := number_list(pn_1306_musteri_kur);
   ln_maliyet_kur := number_list(pn_1306_maliyet_kur) ;
   ln_fark_kur :=  ABS(ln_musteri_kur - ln_maliyet_kur);

--   number_list(pn_1306_anapara_farkkur):= ln_fark_kur * number_list(pn_1306_anapara_tutar);
   number_list(pn_1306_anapara_malkur) :=  pkg_kur.yuvarla(pkg_genel.lc_al,ln_maliyet_kur * number_list(pn_1306_anapara_tutar));
   number_list(pn_1306_anapara_muskur) :=  pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur * number_list(pn_1306_anapara_tutar));
   number_list(pn_1306_anapara_farkkur):=  abs(number_list(pn_1306_anapara_malkur)  -number_list(pn_1306_anapara_muskur));

   number_list(pn_1306_birikmis_faiz_malkur)   :=pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur * number_list(pn_1306_birikmis_faiz));
   number_list(pn_1306_birikmis_kom_malkur)    :=pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur * number_list(pn_1306_birikmis_kom));

   number_list(pn_1306_gecenyil_faiz_malkur)   := pkg_kur.yuvarla(pkg_genel.lc_al,ln_maliyet_kur * number_list(pn_1306_gecenyil_faiz));
   number_list(pn_1306_gecenyil_kom_malkur)    := pkg_kur.yuvarla(pkg_genel.lc_al,ln_maliyet_kur * number_list(pn_1306_gecenyil_kom));
   number_list(pn_1306_gecenay_faiz_malkur)    := pkg_kur.yuvarla(pkg_genel.lc_al,ln_maliyet_kur * number_list(pn_1306_gecenay_faiz));
   number_list(pn_1306_gecenay_kom_malkur)    := pkg_kur.yuvarla(pkg_genel.lc_al,ln_maliyet_kur * number_list(pn_1306_gecenay_kom));

   number_list(pn_1306_tax_fc_2) :=  round(((number_list(pn_1306_birikmis_faiz)*ln_rate)/100),2);
   number_list(pn_1306_tax_lc_2) :=  round(((number_list(pn_1306_birikmis_faiz_tl)*ln_rate)/100),2);

log_at('hakan_1306_002','number_list(pn_1306_TAX_FC_1)',number_list(pn_1306_TAX_FC_1));
log_at('hakan_1306_003','number_list(pn_1306_TAX_FC_2)',number_list(pn_1306_TAX_FC_2));
log_at('hakan_1306_004','number_list(pn_1306_TAX_FC_3)',number_list(pn_1306_TAX_FC_3));

log_at('hakan_1306_005','number_list(pn_1306_TAX_LC_1)',number_list(pn_1306_TAX_LC_1));
log_at('hakan_1306_006','number_list(pn_1306_TAX_LC_2)',number_list(pn_1306_TAX_LC_2));
log_at('hakan_1306_007','number_list(pn_1306_TAX_LC_3)',number_list(pn_1306_TAX_LC_3));


   ln_top_fc := number_list(pn_1306_gecenay_faiz)+number_list(pn_1306_gecenay_kom)+
        number_list(pn_1306_gecenyil_faiz)+number_list(pn_1306_gecenyil_kom);

   ln_top_lc := number_list(pn_1306_gecenay_faiz_tl)+number_list(pn_1306_gecenay_kom_tl)+
        number_list(pn_1306_gecenyil_faiz_tl)+number_list(pn_1306_gecenyil_kom_tl);

--   number_list(pn_1306_tax_fc_1) :=  round(((ln_top_fc*2.5)/100),2); --Yerzhant 11.12.2010
--   number_list(pn_1306_tax_lc_1) :=  round(((ln_top_lc*2.5)/100),2); --Yerzhant 11.12.2010

   number_list(pn_1306_tax_fc_1) :=  round(
                                             (
                                               (
                                               (number_list(pn_1306_gecenay_faiz)+number_list(pn_1306_gecenay_kom))*ln_rate+
                                               (number_list(pn_1306_gecenyil_faiz)+number_list(pn_1306_gecenyil_kom))*ln_rate_last_year  --sevalb 24122010  2.5 yerine ln_rate_last_year eklendi
                                             )
                                             /100
                                            ),2
                                            ); --Yerzhant 11.12.2010
   number_list(pn_1306_tax_lc_1) :=  round(
                                             (
                                               (
                                               (number_list(pn_1306_gecenay_faiz_tl)+number_list(pn_1306_gecenay_kom_tl))*ln_rate+
                                               (number_list(pn_1306_gecenyil_faiz_tl)+number_list(pn_1306_gecenyil_kom_tl))*ln_rate_last_year
                                             )
                                             /100
                                            ),2
                                            ); --Yerzhant 11.12.2010

   number_list(pn_1306_tax_fc_3) :=  number_list(pn_1306_tax_fc_1)+number_list(pn_1306_tax_fc_2);
   number_list(pn_1306_tax_lc_3) :=  number_list(pn_1306_tax_lc_1)+number_list(pn_1306_tax_lc_2);

--   number_list(pn_1306_tahak_fon_tutar_malkur) :=ln_maliyet_kur * number_list(pn_1306_tahak_fon_tutar);
--   number_list(pn_1306_tahak_topbiriksz_mlkur) := ln_maliyet_kur * number_list(pn_1306_tahak_topbiriksiz);

-- eski hali--  number_list(pn_1306_TAHSIL_TOP_MUSKUR)  :=  --pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur * number_list(pn_1306_tahak_top));
 number_list(pn_1306_TAHSIL_TOP_MUSKUR)  :=(pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur * ln_TAHSIL_TAHAKKUK_FAIZ) +
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_gecenyil_faiz)) +
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_gecenyil_kom)) +
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_birikmis_faiz)) +
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_birikmis_kom))+
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_gecenay_faiz)) +
pkg_kur.yuvarla(pkg_genel.lc_al,ln_musteri_kur *number_list(pn_1306_gecenay_kom)));  -- nvl(TOPLAM_TAHSILEDILECEK_TUTAR,0),

--   number_list(pn_1306_kkdf_tutar_tl) :=Pkg_Kur.yuvarla(Pkg_Genel.lc_al, ln_kur * number_list(pn_1306_kkdf_tutar));
 --  number_list(pn_1306_bsmv_tutar_tl) := Pkg_Kur.yuvarla(Pkg_Genel.lc_al,ln_kur * number_list(pn_1306_bsmv_tutar));

    number_list(pn_1306_faiz_fark) :=   ABS(NVL(number_list(pn_1306_TAHSIL_TOP_MUSKUR),0) - ( NVL(number_list(pn_1306_GECENYIL_FAIZ_MALKUR),0)+NVL(number_list(pn_1306_GECENAY_FAIZ_MALKUR),0)+ NVL(number_list(pn_1306_GECENYIL_KOM_MALKUR),0)+ NVL(number_list(pn_1306_GECENAY_KOM_MALKUR),0) + NVL(number_list(pn_1306_birikmis_faiz_malkur),0)+NVL(number_list(pn_1306_birikmis_kom_malkur),0)));
/*   number_list(pn_1306_fon_arakkdf_tutar) := ABS(NVL( Pkg_Kredi.sf_kkdf_hesapla(varchar_list(pn_1306_kredi_hesap_no),
                      ln_kkdf_ara_tutar,
                 ln_musteri_kur,'E'),0));

   number_list(pn_1306_fon_arabsmv_tutar) := NVL(Pkg_Kredi.sf_bsmv_hesapla(varchar_list(pn_1306_kredi_hesap_no),
                      ln_bsmv_ara_tutar,
                 ln_musteri_kur,'E'),0);

   number_list(pn_1306_fon_aratoplam):= ABS( NVL(number_list(PN_1306_TAHAK_FON_TUTAR),0))*  ln_musteri_kur +
          ABS( NVL(number_list(pn_1306_FON_ARAKKDF_TUTAR),0))+
          ABS( NVL(number_list(pn_1306_FON_ARABSMV_TUTAR),0));

   number_list(pn_1306_fon_arafark_tutar) := ABS(NVL(number_list(PN_1306_FON_ARATOPLAM),0)-
               (ABS( NVL(number_list(PN_1306_TAHAK_FON_TUTAR_MALKUR),0))+
            ABS( NVL(number_list(PN_1306_FON_ARAKKDF_TUTAR),0))+
            ABS( NVL(number_list(PN_1306_FON_ARABSMV_TUTAR),0))));


   number_list(pn_1306_tahak_top_fon) := ABS( NVL(number_list(PN_1306_TAHAK_FON_TUTAR),0)) + ABS (NVL(number_list(pn_1306_kkdf_tutar),0)) + ABS (NVL(number_list(pn_1306_BSMV_tutar),0)) ;
   number_list(pn_1306_tahak_top_fon_tl) :=Pkg_Kur.yuvarla(Pkg_Genel.lc_al,number_list(pn_1306_tahak_top_fon) * ln_kur );
*/
/* 290504 subeler cari muhasebesi */
 IF (ls_geriodeme_kapama_secimi != 'KAPAMA' )  AND
   ( number_list(pn_1306_birikmis_faiz)+ number_list(pn_1306_birikmis_kom) = 0 ) THEN
        number_list(pn_1306_gecenyilbdak_sch_tl)  := 0;
        number_list(pn_1306_gecenyil_sch_tl)  := 0;
     number_list(pn_1306_birikmis_sch_tl):=0;
 END IF;


/* kredi hesap acilis muhasebesi calistirilir. */
    ln_fis_no:=Pkg_Muhasebe.fis_kes(ls_islem_kod,
       NULL,
       pn_islem_no,
       varchar_list ,
       number_list  ,
       date_list    ,
       boolean_list ,
       NULL,
       FALSE,
       0,
       NULL);
 Pkg_Muhasebe.MUHASEBELESTIR(ln_fis_no);
 sp_muhasebesonrasi_guncelle(pn_islem_no);
 Pkg_Teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,ls_geriodeme_kapama_secimi);
  EXCEPTION
   WHEN iliskili_faiz_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '700' || Pkg_Hata.getdelimiter || varchar_list(pn_1306_iliskili_hesap_no) || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_faizrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '701' || Pkg_Hata.getdelimiter || varchar_list(pn_1306_iliskili_hesap_no) || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_kom_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '702' || Pkg_Hata.getdelimiter || varchar_list(pn_1306_iliskili_hesap_no) || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);
   WHEN iliskili_komrees_dk_yok THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getucpointer || '703' || Pkg_Hata.getdelimiter || varchar_list(pn_1306_iliskili_hesap_no) || Pkg_Hata.getdelimiter ||ls_dk_grup_kod || Pkg_Hata.getdelimiter || ls_modul_tur_kod  || Pkg_Hata.getdelimiter ||  ls_urun_tur_kod  || Pkg_Hata.getdelimiter || ls_urun_sinif_kod || Pkg_Hata.getdelimiter || Pkg_Hata.getucpointer);

   WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER || '594' || Pkg_Hata.getDelimiter || TO_CHAR(SQLERRM) || Pkg_Hata.getDelimiter || Pkg_Hata.getUCPOINTER);
 END;

 PROCEDURE Iptal_Muhasebelestir_Sonrasi(pn_islem_no NUMBER ) IS
 BEGIN
  NULL;
 END;

 PROCEDURE Guncelleme_Kontrolu(pn_islem_no NUMBER,ps_block VARCHAR2,ps_rowid   VARCHAR2,
            ps_column VARCHAR2,pd_column VARCHAR2,ps_oldvalue IN OUT VARCHAR2)
 IS
 BEGIN
    Pkg_Teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue );

 END;

PROCEDURE sp_kontrol_sonrasi_rezervasyon(pn_islem_no NUMBER ) IS
    ln_doviz_tutari NUMBER;
 ln_bakiye NUMBER;
 ln_tutar NUMBER := 0;
 CURSOR islem_cursor IS
       SELECT * FROM CBS_HESAP_KREDI_ISLEM
   WHERE TX_NO=pn_islem_no;

 row_islem islem_cursor%ROWTYPE;
   BEGIN

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

 IF row_islem.REZERVASYON_NO IS NOT NULL THEN

    ln_bakiye:=Pkg_Kur_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);


  SELECT tutar
  INTO ln_tutar
  FROM CBS_ISLEM
  WHERE numara=pn_islem_no;

    IF ln_tutar >ln_bakiye THEN --Bakiye Yetersiz..
       RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
    ELSE
       Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
                    pn_islem_no,
                    ln_tutar);
    END IF;

 END IF;

 EXCEPTION WHEN OTHERS THEN NULL;
 END;

 Procedure sp_iptalkontrol(pn_islem_no number)
 is
 cursor cursor_islem is
    select max(distinct a.tx_no)   tx_no
    from  cbs_hesap_kredi_islem a,cbs_islem b
   where a.tx_no = b.numara and
     b.durum not in( '2','R') and
   a.tx_no > pn_islem_no and
   b.ISLEM_KOD not in(1304) and
   a.hesap_no in (select hesap_no
        from cbs_hesap_kredi_islem
       where tx_no = pn_islem_no );

  ln_tx_no     number;
  islemvar        exception;
  durumu_kapali      exception;
  ln_teminat_no   number;
  ls_durum    varchar2(200);
  ls_geriodeme_kapama_secimi varchar2(200);
 Begin

 /* islemden sonra bitmis ve degisiklik yapilmis islem varsa iptale izin verilemez. */

  select b.durum_kodu,
    geriodeme_kapama_secimi
  into  ls_durum,
    ls_geriodeme_kapama_secimi
  from  cbs_hesap_kredi_islem a, cbs_hesap_kredi b
  where  a.tx_no = pn_islem_no and
       a.hesap_no = b.hesap_no;

   if ls_durum <> 'A' and ls_geriodeme_kapama_secimi  <> 'KAPAMA' then
     raise durumu_kapali ;
   end if;

   for cur_islem in cursor_islem
   loop
   ln_tx_no := cur_islem.tx_no;
   end loop;

  if nvl(ln_tx_no,0) <> 0 then
     raise islemvar ;
  end if;

  Exception
   When  durumu_kapali then
           Raise_application_error(-20100,pkg_hata.getUCPOINTER || '906' || pkg_hata.getDelimiter ||to_char(ls_durum)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When  islemvar then
        Raise_application_error(-20100,pkg_hata.getUCPOINTER || '725' || pkg_hata.getDelimiter ||to_char(ln_tx_no)||pkg_hata.getDelimiter|| pkg_hata.getUCPOINTER);
   When Others Then null;
   END;
 BEGIN
 pn_1306_tahak_top :=Pkg_Muhasebe.parametre_index_bul('1306_TAHAK_TOP');
 pn_1306_tahsil_top_muskur :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_TOP_MUSKUR');
 pn_1306_tahak_top_tl :=Pkg_Muhasebe.parametre_index_bul('1306_TAHAK_TOP_TL');
 pn_1306_tahsil_doviz_tl :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_DOVIZ_TL');
 pn_1306_tahsil_doviz_yp :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_DOVIZ_YP');
 pn_1306_tahsil_hesap_doviz :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_HESAP_DOVIZ');
 pn_1306_tahsil_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_HESAP_NO');
 pn_1306_tahsil_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1306_TAHSIL_HESAP_SUBE');
 pn_1306_valor_tarihi :=Pkg_Muhasebe.parametre_index_bul('1306_VALOR_TARIHI');
 pn_1306_gecenyilbdak_sch_tl :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYILBDAK_SCH_TL');
 pn_1306_gecenyil_faiz :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_FAIZ');
 pn_1306_gecenyil_faiz_malkur :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_FAIZ_MALKUR');
 pn_1306_gecenyil_faiz_tl :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_FAIZ_TL');
 pn_1306_gecenyil_kom :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_KOM');
 pn_1306_gecenyil_kom_malkur :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_KOM_MALKUR');
 pn_1306_gecenyil_kom_tl :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_KOM_TL');
 pn_1306_gecenyil_sch_tl :=Pkg_Muhasebe.parametre_index_bul('1306_GECENYIL_SCH_TL');
 pn_1306_iliskili_faizrees_dk :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_FAIZREES_DK');
 pn_1306_iliskili_faiz_dk :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_FAIZ_DK');
 pn_1306_iliskili_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_HESAP_NO');
 pn_1306_iliskili_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_HESAP_SUBE');
 pn_1306_iliskili_komrees_dk :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_KOMREES_DK');
 pn_1306_iliskili_kom_dk :=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_KOM_DK');
 pn_1306_islem_sube :=Pkg_Muhasebe.parametre_index_bul('1306_ISLEM_SUBE');
 pn_1306_istatistik_faiz :=Pkg_Muhasebe.parametre_index_bul('1306_ISTATISTIK_FAIZ');
 pn_1306_istatistik_kodu_kapama :=Pkg_Muhasebe.parametre_index_bul('1306_ISTATISTIK_KODU_KAPAMA');
 pn_1306_kredi_doviz :=Pkg_Muhasebe.parametre_index_bul('1306_KREDI_DOVIZ');
 pn_1306_kredi_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1306_KREDI_HESAP_NO');
 pn_1306_kredi_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1306_KREDI_HESAP_SUBE');
 pn_1306_kredi_tl :=Pkg_Muhasebe.parametre_index_bul('1306_KREDI_TL');
 pn_1306_kredi_yp :=Pkg_Muhasebe.parametre_index_bul('1306_KREDI_YP');
 pn_1306_kur :=Pkg_Muhasebe.parametre_index_bul('1306_KUR');
 pn_1306_maliyet_kur :=Pkg_Muhasebe.parametre_index_bul('1306_MALIYET_KUR');
 pn_1306_musteri_aciklama :=Pkg_Muhasebe.parametre_index_bul('1306_MUSTERI_ACIKLAMA');
 pn_1306_musteri_kur :=Pkg_Muhasebe.parametre_index_bul('1306_MUSTERI_KUR');
 pn_1306_musteri_kuru_buyukse :=Pkg_Muhasebe.parametre_index_bul('1306_MUSTERI_KURU_BUYUKSE');
 pn_1306_musteri_kuru_kucukse :=Pkg_Muhasebe.parametre_index_bul('1306_MUSTERI_KURU_KUCUKSE');
 pn_1306_referans :=Pkg_Muhasebe.parametre_index_bul('1306_REFERANS');
 pn_1306_anapara_farkkur :=Pkg_Muhasebe.parametre_index_bul('1306_ANAPARA_FARKKUR');
 pn_1306_anapara_malkur :=Pkg_Muhasebe.parametre_index_bul('1306_ANAPARA_MALKUR');
 pn_1306_anapara_muskur :=Pkg_Muhasebe.parametre_index_bul('1306_ANAPARA_MUSKUR');
 pn_1306_anapara_tutar :=Pkg_Muhasebe.parametre_index_bul('1306_ANAPARA_TUTAR');
 pn_1306_anapara_tutar_tl :=Pkg_Muhasebe.parametre_index_bul('1306_ANAPARA_TUTAR_TL');
 pn_1306_banka_aciklama :=Pkg_Muhasebe.parametre_index_bul('1306_BANKA_ACIKLAMA');
 pn_1306_birikmis_faiz :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_FAIZ');
 pn_1306_birikmis_faiz_malkur :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_FAIZ_MALKUR');
 pn_1306_birikmis_faiz_tl :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_FAIZ_TL');
 pn_1306_birikmis_kom :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_KOM');
 pn_1306_birikmis_kom_malkur :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_KOM_MALKUR');
 pn_1306_birikmis_kom_tl :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_KOM_TL');
 pn_1306_birikmis_sch_tl :=Pkg_Muhasebe.parametre_index_bul('1306_BIRIKMIS_SCH_TL');
 pn_1306_faiz_fark :=Pkg_Muhasebe.parametre_index_bul('1306_FAIZ_FARK');
 pn_1306_faiz_hesap_no :=Pkg_Muhasebe.parametre_index_bul('1306_FAIZ_HESAP_NO');
 pn_1306_faiz_hesap_sube :=Pkg_Muhasebe.parametre_index_bul('1306_FAIZ_HESAP_SUBE');
 pn_1306_fis_aciklama :=Pkg_Muhasebe.parametre_index_bul('1306_FIS_ACIKLAMA');
 pn_1306_ILISKILI_HESAP_TUR:=Pkg_Muhasebe.parametre_index_bul('1306_ILISKILI_HESAP_TUR');
 pn_1306_gecenay_faiz_tl :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_FAIZ_TL');
 pn_1306_gecenay_faiz :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_FAIZ');
 pn_1306_gecenay_kom_tl :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_KOM_TL');
 pn_1306_gecenay_kom :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_KOM');
 pn_1306_gecenay_kom_malkur :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_KOM_MALKUR');
 pn_1306_gecenay_faiz_malkur :=pkg_muhasebe.parametre_index_bul('1306_GECENAY_FAIZ_MALKUR');

 pn_1306_tax_fc_1 :=pkg_muhasebe.parametre_index_bul('1306_tax_fc_1');
 pn_1306_tax_fc_2 :=pkg_muhasebe.parametre_index_bul('1306_tax_fc_2');
 pn_1306_tax_fc_3 :=pkg_muhasebe.parametre_index_bul('1306_tax_fc_3');
 pn_1306_tax_lc_1 :=pkg_muhasebe.parametre_index_bul('1306_tax_lc_1');
 pn_1306_tax_lc_2 :=pkg_muhasebe.parametre_index_bul('1306_tax_lc_2');
 pn_1306_tax_lc_3 :=pkg_muhasebe.parametre_index_bul('1306_tax_lc_3');

 pn_1306_tax_aciklama :=pkg_muhasebe.parametre_index_bul('1306_tax_aciklama');
 END;
/

