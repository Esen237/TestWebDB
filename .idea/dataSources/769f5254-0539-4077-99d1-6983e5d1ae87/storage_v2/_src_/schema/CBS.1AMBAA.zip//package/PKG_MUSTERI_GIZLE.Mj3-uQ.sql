create PACKAGE     pkg_musteri_gizle  is

 /******************************************************************************
   Name       : PKG_MUSTERI_GIZLE
   Created By : Chyngyz O.
   Date          : 18.01.2014
   Purpose      : For Customer Information Hiding project (Request No 617). 
                      Contains functions to determine whether certain customer should be hidden from specified CBS user.
                      They are called from Oracle Forms and Oracle Reports.
******************************************************************************/

-- Returns if customer (pn_customer_no) is defined as hidden or not ('E' or 'H')
FUNCTION is_customer_hidden(pn_customer_no CBS_MUSTERI.MUSTERI_NO%TYPE) RETURN VARCHAR2;

-- Returns if user (ps_kullanici) is authorized to view hidden customers or not ('E' or 'H')
FUNCTION is_user_authorized (ps_kullanici CBS_KULLANICI.KODU%TYPE) RETURN VARCHAR2;

-- Determines whether for current user (pkg_baglam.kullanici_kodu) customer (pn_musteri_no) should be hidden or not ('E' or 'H')
-- Called from Oracle Forms
FUNCTION musteri_gizlensin_mi(pn_musteri_no CBS_MUSTERI.MUSTERI_NO%TYPE) RETURN VARCHAR2;

-- Determines whether for current user (pc_kullanici_kodu) customer (pn_musteri_no) should be hidden or not ('E' or 'H')
-- Called from Oracle Reports.
FUNCTION musteri_gizlensin_mi(pn_musteri_no CBS_MUSTERI.MUSTERI_NO%TYPE, pc_kullanici_kodu CBS_KULLANICI.KODU%TYPE) RETURN VARCHAR2;

-- For given transaction no (pn_islem_no) determines whether transaction contains account of hidden customer ('E' or 'H')
FUNCTION fiste_gizli_hesap_var_mi( pn_islem_no number) return varchar2;

-- Returns a message which is shown when current CBS user is not authorized to view hidden customer accounts
FUNCTION not_authorized_message return varchar2;


end pkg_musteri_gizle ;
/

