create PACKAGE PKG_TX4117 IS

  /******************************************************************************
   Name       : PKG_TX4117
   Created By : Bilal GUL
   Date	   	  : 11/03/2004
   Purpose	  : VERILEN GARANTI - KEFALET CIKIS
  ******************************************************************************/

  -- TX Event Listesi

  Procedure Kontrol_Sonrasi(pn_islem_no number); 	-- Islem giris kontrolden gectikten sonra cagrilir

  Procedure Dogrulama_Sonrasi(pn_islem_no number);	-- Islem dogrulandiktan sonra cagrilir

  Procedure Iptal_Sonrasi(pn_islem_no number);		-- Islem iptal edildikten sonra cagrilir
  Procedure Iptal_Onay_Sonrasi(pn_islem_no number );-- Islem muhasebe iptalinin onay sonrasi cagrilir.

  Procedure Onay_Sonrasi(pn_islem_no number);		-- Islem onaylandiktan sonra cagrilir
  Procedure Reddetme_Sonrasi(pn_islem_no number);	-- Islem reddedildikten sonra cagrilir

  Procedure Tamam_Sonrasi(pn_islem_no number);		-- Islem tamamlandiktan sonra cagrilir
  Procedure Basim_Sonrasi(pn_islem_no number);  	-- Isleme iliskin formlar basildiktan sonra cagrilir

  Procedure Muhasebelesme(pn_islem_no number);		-- Islemin muhasebelesmesi icin cagrilir

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number);

  Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number);

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number);

  Function masraf_kontrol_yap(ps_odeyecek varchar2) return varchar2;

  Function TM_VERGAR_BAKIYE_AL(PS_REFERANS varchar2) RETURN NUMBER;

   Procedure TM_Verilen_Garanti_Bilgisi_Al(ps_referans CBS_TM_VERILEN_GARANTI.REFERANS%type,
                             			 ps_secenek out CBS_TM_VERILEN_GARANTI.secenek%type,
                         				 ps_lehdar_musteri_no out CBS_TM_VERILEN_GARANTI.lehdar_musteri_no%type,
                           				 ps_acilan_hesap_no out CBS_TM_VERILEN_GARANTI.hesap_no%type,
                           				 ps_doviz_kodu out CBS_TM_VERILEN_GARANTI.doviz_kodu%type,
                           				 ps_garanti_tutari out CBS_TM_VERILEN_GARANTI.tutar%type,
                           				 ps_bakiye out CBS_TM_VERILEN_GARANTI.bakiye%type,
                           				 ps_vade_tarihi out CBS_TM_VERILEN_GARANTI.vade_tarihi%type,
                         				 ps_muhatap_musteri_no out CBS_TM_VERILEN_GARANTI.muhatap%type,
                             			 ps_urun_tur out CBS_TM_VERILEN_GARANTI.urun_tur%type,
                         				 ps_urun_sinif out CBS_TM_VERILEN_GARANTI.urun_sinif%type,
                         				 ps_teklif_urun out CBS_TM_VERILEN_GARANTI.teklif_urun%type,
                         				 ps_masraf_hesap_no out CBS_TM_VERILEN_GARANTI.masraf_hesap_no%type,
										 ps_donem_bas_son out CBS_TM_VERILEN_GARANTI.donem_bas_son%type
										 );

  FUNCTION TxGonderReferansAl(pn_tx_no number) return varchar2;

  Procedure VG_MasrafAktar(pn_txno number,ps_refno varchar2);

END;


/

