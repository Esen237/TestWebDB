create PACKAGE PKG_SN_SRV IS
  -- Author  : MAXIMP

  PROCEDURE FILL_SN_SRV(P_DATE DATE);

  PROCEDURE FILL_SN_FIRST_LEVEL(P_DATE DATE);
  PROCEDURE FILL_SN_SECOND_LEVEL(P_DATE DATE);

  PROCEDURE FILL_SRV_FIRST_LEVEL(P_DATE DATE);
  PROCEDURE FILL_SRV_SECOND_LEVEL(P_DATE DATE);

  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ DATE) return number;
  function difference_5703_4703(gl_ varchar2, bakiye_ number, date_ DATE, bolum_kodu_ varchar2) return number;
  function val_pos(gl_ varchar2, date_ DATE) return number;

  FUNCTION IS_RPT_SN_EXIST(P_DATE DATE) RETURN NUMBER;

END PKG_SN_SRV;

/

