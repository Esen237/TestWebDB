create PACKAGE BODY     Pkg_Message IS

	   INPUT_PATH  varchar2(100):='C:\CBSDATA\MESSAGES\IN';
	   OUTPUT_PATH varchar2(100):='C:\CBSDATA\MESSAGES\OUT';
	   PREPARE_PATH varchar2(100):='C:\CBSDATA\MESSAGES\PREP';
   	   INST_PATH varchar2(100):='C:\CBSDATA\MESSAGES\INST';
	   BACKUP_PATH varchar2(100):='C:\CBSDATA\MESSAGES\ARCHIVE';
	   TEMP_PATH  varchar2(100) :='C:\CBSDATA\MESSAGES\TMP';
	   SCAN_PATH varchar2(100):='C:\CBSDATA\MESSAGES\SCAN';

----------------------------------------------------------------------------------------------
FUNCTION  OpenFile(ps_filename IN VARCHAR2,ps_type IN varchar2) RETURN utl_file.file_type IS
	 f	  utl_file.file_type;
BEGIN

	 if ps_type='w' then
	 	f:=utl_file.fopen(TEMP_PATH,ps_filename,'w',2100);
	 else
	 	f:=utl_file.fopen(OUTPUT_PATH,ps_filename,'r',2100);
	 end if;

	 RETURN f;
END;
--------------------------------------------------------------------------------------------------
FUNCTION  WriteLine(file_obj IN utl_file.file_type, ps_inputtext IN VARCHAR2) RETURN VARCHAR2 IS
BEGIN

	 utl_file.put_line(file_obj, ps_inputtext);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('WRITELN',sqlerrm);
	 	  RETURN '901';
END;
----------------------------------------------------------------------------------------------------
FUNCTION  ReadLine(file_obj IN utl_file.file_type, ps_outputtext OUT VARCHAR2) RETURN VARCHAR2 IS
BEGIN

	 utl_file.get_line(file_obj, ps_outputtext);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('READLN',sqlerrm);
	 	  RETURN '901';
END;
--------------------------------------------------------------------------------------------------
FUNCTION  CloseFile(file_obj IN OUT utl_file.file_type) RETURN VARCHAR2 IS
BEGIN

	 utl_file.fclose(file_obj);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('CLOSE',sqlerrm);
	 	  RETURN '902';
END;

--------------------------------------------------------------------------------------------------

FUNCTION  Write2File(ps_filename IN VARCHAR2, ps_inputtext IN VARCHAR2) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;
BEGIN

	 f:=utl_file.fopen(INPUT_PATH,ps_filename,'w',2100);
	 utl_file.put_line(f, ps_inputtext);
	 utl_file.fclose(f);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('WRITE',sqlerrm);
	 	  utl_file.fclose(f);
	 	  RETURN '997';
END;
-------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
FUNCTION Split(ps_str IN VARCHAR2,ps_delimeter IN VARCHAR2,pn_valindx IN NUMBER) RETURN VARCHAR2 IS
		ln_i				NUMBER:=1;
		ln_itemindx	   NUMBER:=0;
		ls_strOut		VARCHAR2(2000 CHAR);
BEGIN

	   LOOP
	   EXIT WHEN NOT (ln_i<=LENGTH(ps_str) OR INSTR(ps_str,ps_delimeter,ln_i)>0);
			IF ln_itemindx=pn_valindx THEN
			    IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
				   ls_strOut:=SUBSTR(ps_str,ln_i,INSTR(ps_str,ps_delimeter,ln_i)-ln_i);
				ELSE
				   ls_strOut:=SUBSTR(ps_str,ln_i);
				END IF;
			   RETURN ls_strOut;
			END IF;
			IF INSTR(ps_str,ps_delimeter,ln_i)>0 THEN
			   ln_i:=INSTR(ps_str,ps_delimeter,ln_i)+LENGTH(ps_delimeter);
			ELSE
				ln_i:=LENGTH(ps_str)+1;
			END IF;
			ln_itemindx:=ln_itemindx+1;

	   END LOOP;

	   RETURN '';
EXCEPTION
    when others then
        LOG_AT('Split',sqlerrm);
END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION PrepareMoneyField(ps_money IN VARCHAR2) RETURN VARCHAR2 IS
		 ls_money varchar2(19);
		 ls_digit varchar2(15);
		 ls_decimal	varchar2(2);
		 ls_sign	varchar2(1);
BEGIN
	 if instr(ps_money,'.')>0 then
	 	ls_digit:=lpad(substr(replace(ps_money,',',''),0,instr(replace(ps_money,',',''),'.')-1),15,'0');
		ls_decimal:=rpad(substr(replace(ps_money,',',''),instr(replace(ps_money,',',''),'.')+1),2,'0');
	 else
	 	ls_digit:=lpad(replace(ps_money,',',''),15,'0');
	 	ls_decimal:='00';
	 end if;

	 if substr(replace(ps_money,',',''),0,1)='-' then
	 	ls_sign:='-';
	 else
	 	ls_sign:='+';
	 end if;

	 ls_money:=ls_sign || ls_digit||'.'||ls_decimal;

	 return ls_money;
END;
---------------------------------------------------------------------------------------
FUNCTION PrepareField(ps_str IN VARCHAR2,pn_length IN NUMBER,
		 					 	ps_padchar IN VARCHAR2,ps_justification IN VARCHAR2,ps_fieldtype IN VARCHAR2 default 'CHAR')  RETURN VARCHAR2 IS
		 ls_outstr			 VARCHAR2(3000);
		 ls_padchar			 VARCHAR2(1):=' ';
BEGIN
	 IF ps_padchar IS NOT NULL THEN
	 	ls_padchar:=ps_padchar;
	 END IF;

	 if ps_fieldtype='MONEY' then
	 	ls_outstr:=PrepareMoneyField(ps_str);
	 else
		 IF ps_justification='R' THEN
		 	ls_outstr:=LPAD(nvl(ps_str,ps_padchar),pn_length,ps_padchar);
		 ELSIF ps_justification='L' THEN
		 	ls_outstr:=RPAD(nvl(ps_str,ps_padchar),pn_length,ps_padchar);
		 END IF;
	 end if;

	 RETURN ls_outstr;
END;
-------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
FUNCTION  GetMT100Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2 IS
	f	  utl_file.file_type;

	ls_dirlist		varchar2(2000);
	ln_filecount	number;
	ln_fileindex	number;
	ls_filename	varchar2(20);

	ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16):=1;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(9);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_ASSIGN      VARCHAR2(500);
	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;

BEGIN

 	ls_filename:=ps_filename;
 	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='INCOMING';
	ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);

	--:32A
	utl_file.get_line(f, ls_outstr);--:32A:
	if substr(ls_outstr,1,5)=':32A:' then
	 	ls_TRAN_DATE:=substr(ls_outstr,6,6);
		ls_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		ls_TOTAL_TRAN_DATE:=ls_TRAN_DATE;
		ls_TOTAL_TRAN_CURR:=ls_TRAN_CURR;
		ln_TOTAL_TRAN_AMOUNT:=ln_TRAN_AMOUNT;
		utl_file.get_line(f, ls_outstr);
	end if;


	--:50:
	if substr(ls_outstr,1,4)=':50:' then
		LOOP
			if instr(ls_outstr,'/D/')>0 then
			   ls_DC_TYPE:='D';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
			elsif instr(ls_outstr,'/C/')>0 then
			   ls_DC_TYPE:='C';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --log_at(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),convert(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),'RU8PC866','CL8MSWIN1251'));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_FROM_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
			elsif instr(ls_outstr,'/CHIEF/')>0 then
			   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
			elsif instr(ls_outstr,'/MAINBK/')>0 then
			   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;

			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--:50:

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53B:' then
	   ls_FROM_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54B:' then
	   ls_TO_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54C:' then
	   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':57B:' then
	   ls_TO_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;

	if ls_FROM_BRANCH is NULL then
	   ls_FROM_BRANCH:=ls_FROM_HQ;
	end if;
	if ls_TO_HQ is null then
	   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
	end if;

	--:59:
	if substr(ls_outstr,1,4)=':59:' then
		LOOP
			if substr(ls_outstr,1,4)=':59:' then
			   ls_TO_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_TO_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_TO_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_TO_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;
			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--59

	--:70:
	if substr(ls_outstr,1,4)=':70:' then
		LOOP
			if instr(ls_outstr,'/NUM/')>0 then
			   ls_DOC_NUM:=substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'));
			elsif instr(ls_outstr,'/DATE/')>0 then
			   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
			elsif instr(ls_outstr,'/SEND/')>0 then
			   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
			elsif instr(ls_outstr,'/VO/')>0 then
			   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
			elsif instr(ls_outstr,'/KNP/')>0 then
			   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
			elsif instr(ls_outstr,'/PSO/')>0 then
			   ls_DOC_PSO:=substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
			elsif instr(ls_outstr,'/BCLASS/')>0 then
			   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
			elsif instr(ls_outstr,'/PRT/')>0 then
			   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
			elsif instr(ls_outstr,'/ASSIGN/')>0 then
			   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
			else
			   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
			end if;

			utl_file.get_line(f, ls_outstr);--:
			EXIT WHEN substr(ls_outstr,1,2)='-}';
		END LOOP;
	end if;--70

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER,TOTAL_TRAN_DATE, TOTAL_TRAN_CURR, TOTAL_TRAN_AMOUNT)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILE_NAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER,ls_TOTAL_TRAN_DATE, ls_TOTAL_TRAN_CURR, ln_TOTAL_TRAN_AMOUNT);

	--INSERT THE DETAIL	MSG
	insert into cbs_clearing_messages_detail
	(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
	FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
	TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
	DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_BCLASS, DOC_ASSIGN)
	values
	(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
	ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, ls_FROM_BRANCH,
	ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
	ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
	ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_PRT, ls_DOC_BCLASS, ls_DOC_ASSIGN);

	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('CLEAR_IN',ls_outstr);
	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Unknown Error.'||chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';

/*	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ100ALLFILES',sqlerrm);
	 	  RETURN '998' || sqlerrm;*/
END;

-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  GetMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(2000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(20);

	 ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16);
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(9);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_ASSIGN      VARCHAR2(500);
	ls_DOC_OPV         VARCHAR2(17);
	ls_DOC_FM          VARCHAR2(60);
	ls_DOC_NM          VARCHAR2(60);
	ls_DOC_FT          VARCHAR2(60);
	ls_DOC_DT          VARCHAR2(8);
	ls_DOC_LA          VARCHAR2(9);
	ls_DOC_RNN         VARCHAR2(12);
	ls_DOC_FM2         VARCHAR2(60);
	ls_DOC_NM2         VARCHAR2(60);
	ls_DOC_FT2         VARCHAR2(60);
	ls_DOC_LA2         VARCHAR2(9);
	ls_DOC_RNN2        VARCHAR2(12);
	ls_DOC_PERIOD      VARCHAR2(6);

	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;

BEGIN

 	ls_filename:=ps_filename;
 	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='INCOMING';
	ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);


	--:50:
	utl_file.get_line(f, ls_outstr);
	if substr(ls_outstr,1,4)=':50:' then
		LOOP
			if instr(ls_outstr,'/D/')>0 then
			   ls_DC_TYPE:='D';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
			elsif instr(ls_outstr,'/C/')>0 then
			   ls_DC_TYPE:='C';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_FROM_RNN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/')));
			elsif instr(ls_outstr,'/CHIEF/')>0 then
			   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
			elsif instr(ls_outstr,'/MAINBK/')>0 then
			   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;

			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--:50:

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53B:' then
	   ls_FROM_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54B:' then
	   ls_TO_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54C:' then
	   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':57B:' then
	   ls_TO_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;

	if ls_FROM_HQ is NULL and ls_FROM_BRANCH is not null then
	   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
	end if;
	if ls_TO_HQ is null and ls_TO_BRANCH is not null then
	   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
	end if;

	--:59:
	if substr(ls_outstr,1,4)=':59:' then
		LOOP
			if substr(ls_outstr,1,4)=':59:' then
			   ls_TO_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_TO_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_TO_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_TO_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;
			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--59

	--:70:
	if substr(ls_outstr,1,4)=':70:' then
		LOOP
			if instr(ls_outstr,'/NUM/')>0 then
			   ls_DOC_NUM:=substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'));
			elsif instr(ls_outstr,'/DATE/')>0 then
			   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
			elsif instr(ls_outstr,'/PERIOD/')>0 then
			   ls_DOC_PERIOD:=substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'));
			elsif instr(ls_outstr,'/SEND/')>0 then
			   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
			elsif instr(ls_outstr,'/VO/')>0 then
			   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
			elsif instr(ls_outstr,'/KNP/')>0 then
			   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
			elsif instr(ls_outstr,'/PSO/')>0 then
			   ls_DOC_PSO:=substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
			elsif instr(ls_outstr,'/BCLASS/')>0 then
			   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
			elsif instr(ls_outstr,'/PRT/')>0 then
			   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
			elsif instr(ls_outstr,'/ASSIGN/')>0 then
			   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
			else
			   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
			end if;

			utl_file.get_line(f, ls_outstr);--:
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--70

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILE_NAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

	while substr(ls_outstr,1,4)=':21:'
	LOOP

		ls_DETAIL_ID:=substr(ls_outstr,instr(ls_outstr,':21:')+length(':21:'));

		utl_file.get_line(f, ls_outstr);

		if substr(ls_outstr,1,5)=':32B:' then
		 	ls_TRAN_CURR:=substr(ls_outstr,6,3);
			ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,9),',','.'));
			utl_file.get_line(f, ls_outstr);
		end if;

		if substr(ls_outstr,1,4)=':50:' then
			LOOP
				if instr(ls_outstr,'/D/')>0 then
				   ls_DC_TYPE:='D';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
				elsif instr(ls_outstr,'/C/')>0 then
				   ls_DC_TYPE:='C';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_FROM_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
				elsif instr(ls_outstr,'/CHIEF/')>0 then
				   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
				elsif instr(ls_outstr,'/MAINBK/')>0 then
				   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
				end if;

				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--:50:

		if substr(ls_outstr,1,5)=':52B:' then
		   ls_FROM_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53B:' then
		   ls_FROM_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53C:' then
		   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54B:' then
		   ls_TO_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54C:' then
		   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':57B:' then
		   ls_TO_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;

		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;

		--:59:
		if substr(ls_outstr,1,4)=':59:' then
			LOOP
				if substr(ls_outstr,1,4)=':59:' then
				   ls_TO_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_TO_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_TO_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_TO_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
				end if;
				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--59

		--:70:
		if substr(ls_outstr,1,4)=':70:' then
			LOOP
				if instr(ls_outstr,'/OPV/')>0 then
				   ls_DOC_OPV:=substr(ls_outstr,instr(ls_outstr,'/OPV/')+length('/OPV/'));
				elsif instr(ls_outstr,'//FM/')>0 then
				   ls_DOC_FM:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//FM/')+length('//FM/')));
				elsif instr(ls_outstr,'//NM/')>0 then
				   ls_DOC_NM:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//NM/')+length('//NM/')));
				elsif instr(ls_outstr,'//FT/')>0 then
				   ls_DOC_FT:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//FT/')+length('//FT/')));
				elsif instr(ls_outstr,'//DT/')>0 then
				   ls_DOC_DT:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//DT/')+length('//DT/')));
				elsif instr(ls_outstr,'//LA/')>0 then
				   ls_DOC_LA:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//LA/')+length('//LA/')));
				elsif instr(ls_outstr,'//RNN/')>0 then
				   ls_DOC_RNN:=substr(ls_outstr,instr(ls_outstr,'//RNN/')+length('//RNN/'));
				elsif instr(ls_outstr,'/FM/')>0 then
				   ls_DOC_FM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FM/')+length('/FM/')));
				elsif instr(ls_outstr,'/NM/')>0 then
				   ls_DOC_NM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NM/')+length('/NM/')));
				elsif instr(ls_outstr,'/FT/')>0 then
				   ls_DOC_FT2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FT/')+length('/FT/')));
				elsif instr(ls_outstr,'/LA/')>0 then
				   ls_DOC_LA2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/LA/')+length('/LA/')));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_DOC_RNN2:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
				elsif instr(ls_outstr,'/NUM/')>0 then
				   ls_DOC_NUM:=substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'));
				elsif instr(ls_outstr,'/DATE/')>0 then
				   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
				elsif instr(ls_outstr,'/SEND/')>0 then
				   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
				elsif instr(ls_outstr,'/VO/')>0 then
				   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
				elsif instr(ls_outstr,'/KNP/')>0 then
				   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
				elsif instr(ls_outstr,'/PSO/')>0 then
				   ls_DOC_PSO:=substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
				elsif instr(ls_outstr,'/BCLASS/')>0 then
				   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
				elsif instr(ls_outstr,'/PRT/')>0 then
				   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
				elsif instr(ls_outstr,'/PERIOD/')>0 then
				   ls_DOC_PERIOD:=substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'));
				elsif instr(ls_outstr,'/ASSIGN/')>0 then
				   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
				else
				   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
				end if;

				utl_file.get_line(f, ls_outstr);--:
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--70

		--INSERT THE DETAIL	MSG
		insert into cbs_clearing_messages_detail
		(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
		FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
		TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
		DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_OPV, DOC_FM, DOC_NM,
		DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2, DOC_RNN2,DOC_PERIOD)
		values
		(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
		ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, ls_FROM_BRANCH,
		ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
		ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
		ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_OPV,ls_DOC_FM,ls_DOC_NM,
		ls_DOC_FT,	ls_DOC_DT,	ls_DOC_LA,	ls_DOC_RNN,	ls_DOC_FM2,	ls_DOC_NM2,	ls_DOC_FT2,	ls_DOC_LA2,ls_DOC_RNN2,ls_DOC_PERIOD);


	END LOOP;--:21:

	if substr(ls_outstr,1,5)=':32A:' then
	    ls_TOTAL_TRAN_DATE:=substr(ls_outstr,6,6);
	 	ls_TOTAL_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TOTAL_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		utl_file.get_line(f, ls_outstr);
	end if;

	--UPDATE THE TOTAL AMOUNT
	update cbs_clearing_messages
	set TOTAL_TRAN_DATE=ls_TOTAL_TRAN_DATE,
	 	TOTAL_TRAN_CURR=ls_TOTAL_TRAN_CURR,
		TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
	where
		MSG_ID=ln_MSG_ID;

	update cbs_clearing_messages_detail
	set TRAN_DATE=ls_TOTAL_TRAN_DATE
	where
		MSG_ID=ln_MSG_ID;


	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);


	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('CLEAR_IN',ls_outstr);
	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Unknown Error.'||chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';

/*	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ102ALLFILES',sqlerrm);
	 	  RETURN '998' || sqlerrm;*/
END;

-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  GetPansionMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(2000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(30);

	 ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16);
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(10);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_ASSIGN      VARCHAR2(500);
	ls_DOC_OPV         VARCHAR2(17);
	ls_DOC_FM          VARCHAR2(60);
	ls_DOC_NM          VARCHAR2(60);
	ls_DOC_FT          VARCHAR2(60);
	ls_DOC_DT          VARCHAR2(8);
	ls_DOC_LA          VARCHAR2(9);
	ls_DOC_RNN         VARCHAR2(12);
	ls_DOC_FM2         VARCHAR2(60);
	ls_DOC_NM2         VARCHAR2(60);
	ls_DOC_FT2         VARCHAR2(60);
	ls_DOC_LA2         VARCHAR2(9);
	ls_DOC_RNN2        VARCHAR2(12);
	ls_DOC_PERIOD      VARCHAR2(6);

	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;
	ln_SUM_TRAN_AMOUNT			   NUMBER:=0;

	cursor cursor_clearchk(ps_FIELD_59 varchar2) is
	   		  select *
			   from cbs_clearing_checklist
			   where FIELD_59 = ps_FIELD_59;

	row_clearchk	 cursor_clearchk%rowtype;
	ErrorPERIODException					 exception;
	ErrorCheckException						 exception;
	TotalTranSumWrong						 exception;
	InvalidBankCode							 exception;
	ls_check_error							 varchar2(500);
	ToBankCodeAccountError					 exception;

BEGIN

 	ls_filename:=ps_filename;
 	f:=utl_file.fopen(PREPARE_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='PREPARE';
	ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	--ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	--ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,8,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=null;--substr(ls_outstr,5,16);
	ls_FIRST_HEADER:= '{1:F01K057880000000000000000}';
	ls_SECOND_HEADER:='{2:I102'|| ls_PAYMENT_TYPE || '000000U3003}';

	--:50:
	utl_file.get_line(f, ls_outstr);
	if substr(ls_outstr,1,4)=':50:' then
		LOOP
			if instr(ls_outstr,'/D/')>0 then
			   ls_DC_TYPE:='D';
			   ls_FROM_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'))));
			elsif instr(ls_outstr,'/C/')>0 then
			   ls_DC_TYPE:='C';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_FROM_RNN:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/')))));
			elsif instr(ls_outstr,'/CHIEF/')>0 then
			   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
			elsif instr(ls_outstr,'/MAINBK/')>0 then
			   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;

			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--:50:

	if ls_FROM_ACCOUNT in ('001882704','001882718','001882103','001882102','001882601','001882504') then
	   ls_MSG_TYPE:='PREPARE-GL';
	else
	   ls_MSG_TYPE:='PREPARE';
	end if;

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53B:' then
	   ls_FROM_HQ:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_NBACCOUNT:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54B:' then
	   ls_TO_HQ:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54C:' then
	   ls_TO_NBACCOUNT:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':57B:' then
	   ls_TO_BRANCH:=ltrim(rtrim(substr(ls_outstr,6)));
	   utl_file.get_line(f, ls_outstr);
	end if;

	begin
		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;
	exception
	    when others then
			 raise InvalidBankCode;
	end;

	--:59:
	if substr(ls_outstr,1,4)=':59:' then
		LOOP
			if substr(ls_outstr,1,4)=':59:' then
			   ls_TO_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'))));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_TO_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_TO_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_TO_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
			end if;
			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--59

	if pkg_hesap.Check_External_HesapNo(ls_TO_BRANCH,ls_TO_ACCOUNT)=0 then
	   raise ToBankCodeAccountError;
	end if;
	--:70:
	if substr(ls_outstr,1,4)=':70:' then
		LOOP

			if instr(ls_outstr,'/NUM/')>0 then
			   ls_DOC_NUM:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'))));
			elsif instr(ls_outstr,'/DATE/')>0 then
			   ls_DOC_DATE:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'))));
			elsif instr(ls_outstr,'/PERIOD/')>0 then
			   ls_DOC_PERIOD:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'))));
			elsif instr(ls_outstr,'/SEND/')>0 then
			   ls_DOC_SEND:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'))));
			elsif instr(ls_outstr,'/VO/')>0 then
			   ls_DOC_VO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'))));
			elsif instr(ls_outstr,'/KNP/')>0 then
			   ls_DOC_KNP:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'))));
			elsif instr(ls_outstr,'/PSO/')>0 then
			   ls_DOC_PSO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'))));
			elsif instr(ls_outstr,'/BCLASS/')>0 then
			   ls_DOC_BCLASS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'))));
			elsif instr(ls_outstr,'/PRT/')>0 then
			   ls_DOC_PRT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'))));
			elsif instr(ls_outstr,'/ASSIGN/')>0 then
			   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
			elsif ls_DOC_ASSIGN is not null then
			   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
			end if;
			utl_file.get_line(f, ls_outstr);--:
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--70


    OPEN cursor_clearchk(ls_TO_ACCOUNT);
	FETCH cursor_clearchk INTO row_clearchk;
	if cursor_clearchk%FOUND then

	   if instr(row_clearchk.FIELD_57B,ls_TO_BRANCH)=0 or
		   	  instr(row_clearchk.FIELD_RNN,ls_TO_RNN)=0 or
			  instr(nvl(row_clearchk.FIELD_54C,NVL(ls_TO_NBACCOUNT,'-')),NVL(ls_TO_NBACCOUNT,'-'))=0 or
			  instr(row_clearchk.FIELD_KNP,ls_DOC_KNP)=0 then
	  	  raise ErrorCheckException;
	   end if;

	end if;
	CLOSE cursor_clearchk;

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILE_NAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

	while substr(ls_outstr,1,4)=':21:'
	LOOP

		ls_DETAIL_ID:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':21:')+length(':21:'))));
		utl_file.get_line(f, ls_outstr);

		if substr(ls_outstr,1,5)=':32B:' then
		 	ls_TRAN_CURR:=substr(ls_outstr,6,3);
			ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,9),',','.'));
			ln_SUM_TRAN_AMOUNT:=ln_SUM_TRAN_AMOUNT+ln_TRAN_AMOUNT;
			utl_file.get_line(f, ls_outstr);
		end if;

		if substr(ls_outstr,1,4)=':50:' then
			LOOP
				if instr(ls_outstr,'/D/')>0 then
				   ls_DC_TYPE:='D';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
				elsif instr(ls_outstr,'/C/')>0 then
				   ls_DC_TYPE:='C';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				   --ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')))));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_FROM_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
				elsif instr(ls_outstr,'/CHIEF/')>0 then
				   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
				elsif instr(ls_outstr,'/MAINBK/')>0 then
				   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_FROM_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_FROM_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
				end if;

				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--:50:

		if substr(ls_outstr,1,5)=':52B:' then
		   ls_FROM_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53B:' then
		   ls_FROM_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53C:' then
		   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54B:' then
		   ls_TO_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54C:' then
		   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':57B:' then
		   ls_TO_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;

		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;

		--:59:
		if substr(ls_outstr,1,4)=':59:' then
			LOOP
				if substr(ls_outstr,1,4)=':59:' then
				   ls_TO_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'))));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				   --ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')))));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_TO_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_TO_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_TO_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
				end if;
				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--59

		--:70:
		if substr(ls_outstr,1,4)=':70:' then
			LOOP

				if instr(ls_outstr,'/OPV/')>0 then
				   ls_DOC_OPV:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/OPV/')+length('/OPV/')))));
				elsif instr(ls_outstr,'//FM/')>0 then
				   ls_DOC_FM:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'//FM/')+length('//FM/')))));
				elsif instr(ls_outstr,'//NM/')>0 then
				   ls_DOC_NM:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'//NM/')+length('//NM/')))));
				elsif instr(ls_outstr,'//FT/')>0 then
				   ls_DOC_FT:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//FT/')+length('//FT/')));
				elsif instr(ls_outstr,'//DT/')>0 then
				   ls_DOC_DT:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'//DT/')+length('//DT/')))));
				elsif instr(ls_outstr,'//LA/')>0 then
				   ls_DOC_LA:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//LA/')+length('//LA/')));
				elsif instr(ls_outstr,'//RNN/')>0 then
				   ls_DOC_RNN:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'//RNN/')+length('//RNN/')))));
				elsif instr(ls_outstr,'/FM/')>0 then
				   ls_DOC_FM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FM/')+length('/FM/')));
				elsif instr(ls_outstr,'/NM/')>0 then
				   ls_DOC_NM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NM/')+length('/NM/')));
				elsif instr(ls_outstr,'/FT/')>0 then
				   ls_DOC_FT2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FT/')+length('/FT/')));
				elsif instr(ls_outstr,'/LA/')>0 then
				   ls_DOC_LA2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/LA/')+length('/LA/')));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_DOC_RNN2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/')));
				elsif instr(ls_outstr,'/NUM/')>0 then
				   ls_DOC_NUM:=TO_WIN(rtrim(substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'))));
				elsif instr(ls_outstr,'/DATE/')>0 then
				   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
				elsif instr(ls_outstr,'/SEND/')>0 then
				   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
				elsif instr(ls_outstr,'/VO/')>0 then
				   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
				elsif instr(ls_outstr,'/KNP/')>0 then
				   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
				elsif instr(ls_outstr,'/PSO/')>0 then
				   ls_DOC_PSO:=substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
				elsif instr(ls_outstr,'/BCLASS/')>0 then
				   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
				elsif instr(ls_outstr,'/PRT/')>0 then
				   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
				elsif instr(ls_outstr,'/PERIOD/')>0 then
				   ls_DOC_PERIOD:=substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'));
				elsif instr(ls_outstr,'/ASSIGN/')>0 then
				   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
				--else
				--   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
				end if;
				--log_at(11,ls_filename,ls_DETAIL_ID,ls_outstr);

				utl_file.get_line(f, ls_outstr);--:
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--70

		if ls_DOC_PERIOD is not null then
		   if length(ls_DOC_PERIOD)<>6 then
		   	  raise ErrorPERIODException;
		   end if;
		end if;

		if length(ls_DOC_NUM)>9 then
		   ls_DOC_NUM:=substr(ls_DOC_NUM,2,9);
		end if;

		--INSERT THE DETAIL	MSG
		insert into cbs_clearing_messages_detail
		(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
		FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
		TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
		DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_OPV, DOC_FM, DOC_NM,
		DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2, DOC_RNN2,DOC_PERIOD)
		values
		(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
		ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, nvl(ls_FROM_BRANCH,ls_FROM_HQ),
		ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
		ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
		ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_OPV,ls_DOC_FM,ls_DOC_NM,
		ls_DOC_FT,	ls_DOC_DT,	ls_DOC_LA,	ls_DOC_RNN,	ls_DOC_FM2,	ls_DOC_NM2,	ls_DOC_FT2,	ls_DOC_LA2,ls_DOC_RNN2,ls_DOC_PERIOD);

		ls_DOC_FM:=null;
		ls_DOC_NM:=null;
		ls_DOC_FT:=null;
		ls_DOC_DT:=null;
		ls_DOC_LA:=null;
		ls_DOC_RNN:=null;
		ls_DOC_FM2:=null;
		ls_DOC_NM2:=null;
		ls_DOC_FT2:=null;

	END LOOP;--:21:

	if substr(ls_outstr,1,5)=':32A:' then
	    ls_TOTAL_TRAN_DATE:=substr(ls_outstr,6,6);
	 	ls_TOTAL_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TOTAL_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		if ln_SUM_TRAN_AMOUNT!=ln_TOTAL_TRAN_AMOUNT then
		   raise TotalTranSumWrong;
		end if;
		utl_file.get_line(f, ls_outstr);
	end if;

	--UPDATE THE TOTAL AMOUNT--ls_TOTAL_TRAN_DATE,
	update cbs_clearing_messages
	set TOTAL_TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD'),
	 	TOTAL_TRAN_CURR=ls_TOTAL_TRAN_CURR,
		TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
	where
		MSG_ID=ln_MSG_ID;

	update cbs_clearing_messages_detail
	set TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD')
	where
		MSG_ID=ln_MSG_ID;


	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);


	 RETURN '000';

EXCEPTION
	 when ErrorPERIODException then
	 	  ROLLBACK;
		  ls_check_error:=ls_DOC_PERIOD;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100, 'PERIOD is wrong or missing. PERIOD:'|| ls_check_error || chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13) ||' File Name:'|| TO_WIN(ls_filename));
	 	  RETURN '998';
	 when ErrorCheckException then
	 	  ROLLBACK;
  		  ls_check_error:=ls_TO_ACCOUNT || ':' || chr(10)||chr(13) || row_clearchk.FIELD_57B ||'='||ls_TO_BRANCH || chr(10)||chr(13) ||
			               row_clearchk.FIELD_RNN || '=' || ls_TO_RNN  || chr(10)||chr(13) ||
						   nvl(row_clearchk.FIELD_54C,NVL(ls_TO_NBACCOUNT,'-')) || '=' || NVL(ls_TO_NBACCOUNT,'-') || chr(10)||chr(13) ||
						   row_clearchk.FIELD_KNP || '=' || ls_DOC_KNP || chr(10)||chr(13);
		  utl_file.fclose(f);
		  Raise_application_error(-20100,'MT102 Checklist Does not match.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '997';
	 when TotalTranSumWrong then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ln_SUM_TRAN_AMOUNT) || '!=' || to_char(ln_TOTAL_TRAN_AMOUNT) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'MT102 Sum of Payments NOT equal to 32A Amount.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '996';
	 when InvalidBankCode then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ls_FROM_BRANCH) || ' or ' || to_char(ls_TO_BRANCH) || ' not correct.' || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Invalid Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';
	 when ToBankCodeAccountError then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ls_TO_BRANCH) || ' not in ' || to_char(ls_TO_ACCOUNT) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Wrong Receiver Account No for the Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '994';
	 WHEN OTHERS THEN
	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Unknown Error.'||chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';
END;

-------------------------------------------------------------------------------------------------------------------------------------------


/*
Function SendClearingMessages( ps_scm IN VARCHAR2 ) RETURN VARCHAR2 IS
	f utl_file.file_type;
    ls_returncode varchar2(3):='000';
	cursor get_name is
	   		  select m.MSG_ID MSG_ID, m.MSG_KIND MSG_KIND, m.FILE_NAME FILE_NAME, m.FIRST_HEADER FIRST_HEADER, m.SECOND_HEADER SECOND_HEADER, m.MSG_REFERENCE MSG_REFERENCE,
			         m.TOTAL_TRAN_DATE TOTAL_TRAN_DATE, m.TOTAL_TRAN_CURR TOTAL_TRAN_CURR, m.TOTAL_TRAN_AMOUNT TOTAL_TRAN_AMOUNT, md.DC_TYPE DC_TYPE,
					 md.FROM_ACCOUNT FROM_ACCOUNT, md.FROM_NAME FROM_NAME, md.FROM_RNN FROM_RNN, md.FROM_CHIEF FROM_CHIEF,md.FROM_MAINBK FROM_MAINBK,
					 md.FROM_IRS FROM_IRS, md.FROM_SECO FROM_SECO, md.FROM_BRANCH FROM_BRANCH, md.FROM_HQ FROM_HQ,md.FROM_NBACCOUNT FROM_NBACCOUNT, md.TO_BRANCH TO_BRANCH,
				     md.TO_HQ TO_HQ,md.TO_NBACCOUNT TO_NBACCOUNT,md.TO_ACCOUNT TO_ACCOUNT, md.TO_NAME TO_NAME, md.TO_RNN TO_RNN, md.TO_IRS TO_IRS, md.TO_SECO TO_SECO, md.DOC_NUM DOC_NUM,
					 md.DOC_DATE DOC_DATE, md.DOC_SEND DOC_SEND, md.DOC_VO DOC_VO, md.DOC_PSO DOC_PSO, md.DOC_KNP DOC_KNP, md.DOC_PRT DOC_PRT,
					 md.DOC_ASSIGN DOC_ASSIGN, md.DOC_BCLASS DOC_BCLASS,md.CANCEL_REFERENCE,md.CANCEL_KIND,md.CANCEL_DATE,md.CANCEL_REASON
			   from cbs_clearing_messages m, cbs_clearing_messages_detail md
			   where m.MSG_ID = md.MSG_ID
			     and m.MSG_TYPE = 'OUTGOING' and m.MSG_STATUS = 'sNEW'
	             for update of m.MSG_STATUS;

	row_getname	 get_name%rowtype;
Begin

	open get_name;
	fetch get_name into row_getname;

	while get_name%found
	LOOP
		if row_getname.MSG_KIND = '100' then
			ls_returncode:=pkg_message.SendMT100Message(row_getname);
		elsif row_getname.MSG_KIND = '102' then
			ls_returncode:=pkg_message.SendMT102Message(row_getname);
		elsif row_getname.MSG_KIND = '192' then
			ls_returncode:=pkg_message.SendMT192Message(row_getname);
		end if;

		UPDATE cbs_clearing_messages
		SET MSG_STATUS = 'sSEND'
		where current of get_name;

	fetch get_name into row_getname;
	END LOOP;

	close get_name;

	return ls_returncode;

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('SENDMESSAGES',sqlerrm);
	 	  RETURN '998' || sqlerrm;
End;
*/
-----------------------------------------------------------------------------------------------------------------------------------------------
Function SendMT100Message( pn_mesgid in NUMBER) RETURN VARCHAR2 IS
   	cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;

	cursor cursor_detail is
	   		  select *
			   from cbs_clearing_messages_detail
			   where MSG_ID = pn_mesgid
			   order by to_number(DETAIL_ID) asc;

	row_detail	 cursor_detail%rowtype;

   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin
	--dbms_output.put_line('TEST');
    OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;
	CLOSE cursor_clear;

	OPEN cursor_detail;
	FETCH cursor_detail INTO row_detail;
	CLOSE cursor_detail;

	f:=pkg_message.OpenFile(row_clear.MSG_REFERENCE||'.imp','w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);
	ls_returncode:=pkg_message.WriteLine(f,':32A:'||row_clear.TOTAL_TRAN_DATE||row_clear.TOTAL_TRAN_CURR|| replace(ltrim(TO_CHAR(row_clear.TOTAL_TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
	ls_returncode:=pkg_message.WriteLine(f,':50:/'||row_detail.DC_TYPE||'/'||row_detail.FROM_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.FROM_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.FROM_RNN);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/CHIEF/'||row_detail.FROM_CHIEF));
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/MAINBK/'||row_detail.FROM_MAINBK));
	ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.FROM_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.FROM_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':52B:'||row_detail.FROM_BRANCH);
	ls_returncode:=pkg_message.WriteLine(f,':53B:'||row_detail.FROM_HQ);
	if length(row_detail.FROM_NBACCOUNT)=9 then
	   ls_returncode:=pkg_message.WriteLine(f,':53C:'||row_detail.FROM_NBACCOUNT);
	end if;
	if row_clear.PAYMENT_TYPE='SCLEAR' then
	   ls_returncode:=pkg_message.WriteLine(f,':54B:'||row_detail.TO_HQ);
	end if;
	if length(row_detail.TO_NBACCOUNT)=9 then
	   ls_returncode:=pkg_message.WriteLine(f,':54C:'||row_detail.TO_NBACCOUNT);
	end if;
	ls_returncode:=pkg_message.WriteLine(f,':57B:'||row_detail.TO_BRANCH);
	ls_returncode:=pkg_message.WriteLine(f,':59:'||row_detail.TO_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.TO_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.TO_RNN);
    ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.TO_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.TO_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':70:/NUM/'||row_detail.DOC_NUM);
	ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_detail.DOC_DATE);
	ls_returncode:=pkg_message.WriteLine(f,'/SEND/07');
	ls_returncode:=pkg_message.WriteLine(f,'/VO/'||row_detail.DOC_VO);
	ls_returncode:=pkg_message.WriteLine(f,'/KNP/'||row_detail.DOC_KNP);
	ls_returncode:=pkg_message.WriteLine(f,'/PSO/'||nvl(row_detail.DOC_PSO,'01'));
	if length(row_detail.DOC_BCLASS)>0 then
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/'||row_detail.DOC_BCLASS);
	else
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/000000');
	end if;
	ls_returncode:=pkg_message.WriteLine(f,'/PRT/50');

	ln_reasonlength:=length(TO_DOS(row_detail.DOC_ASSIGN));
	while ln_index<=floor(ln_reasonlength/52)+1
	Loop
		 if ln_index=1 then
		 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/ASSIGN/'||substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),ln_index*52)));
		 else
		 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),52)));
		 end if;
		 ln_index:=ln_index+1;
	end Loop;

	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	return ls_returncode;

End;
-----------------------------------------------------------------------------------------------------------------------------------------------
Function SendMT102Message(pn_mesgid in NUMBER)  RETURN VARCHAR2 IS

	cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;

	cursor cursor_detail is
	   		  select *
			   from cbs_clearing_messages_detail
			   where MSG_ID = pn_mesgid
			   order by to_number(DETAIL_ID) asc;

	row_detail	 cursor_detail%rowtype;

   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
   ls_FROM_HQ		  varchar2(9);
begin

  	OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;

	f:=pkg_message.OpenFile(row_clear.MSG_REFERENCE||'.imp','w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);

	OPEN cursor_detail;
	FETCH cursor_detail INTO row_detail;

	ls_returncode:=pkg_message.WriteLine(f,':50:/'||row_detail.DC_TYPE||'/'||row_detail.FROM_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.FROM_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.FROM_RNN);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/CHIEF/'||row_detail.FROM_CHIEF));
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/MAINBK/'||row_detail.FROM_MAINBK));
	ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.FROM_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.FROM_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':52B:'||row_detail.FROM_BRANCH);
	if row_detail.FROM_BRANCH<>pkg_hesap.GetBankCode('010') then
		if row_detail.FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(row_detail.FROM_BRANCH);
		else
		   ls_FROM_HQ:=row_detail.FROM_HQ;
		end if;
	   ls_returncode:=pkg_message.WriteLine(f,':53B:'||ls_FROM_HQ);
	end if;
	--if row_detail.TO_HQ is not null then
	--   ls_returncode:=pkg_message.WriteLine(f,':54B:'||row_detail.TO_HQ);
	--end if;
	/*if row_detail.TO_NBACCOUNT is not null then
	   ls_returncode:=pkg_message.WriteLine(f,':54C:'||row_detail.TO_NBACCOUNT);
	end if;*/
	ls_returncode:=pkg_message.WriteLine(f,':57B:'||row_detail.TO_BRANCH);
	ls_returncode:=pkg_message.WriteLine(f,':59:'||row_detail.TO_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.TO_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.TO_RNN);
    ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.TO_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.TO_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':70:/NUM/'||row_detail.DOC_NUM);
	ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_detail.DOC_DATE);
	if row_detail.DOC_KNP in ('012','017') then
	   ls_returncode:=pkg_message.WriteLine(f,'/PERIOD/'||row_detail.DOC_PERIOD);
	end if;
	ls_returncode:=pkg_message.WriteLine(f,'/SEND/07');
	ls_returncode:=pkg_message.WriteLine(f,'/VO/'||row_detail.DOC_VO);
	ls_returncode:=pkg_message.WriteLine(f,'/KNP/'||row_detail.DOC_KNP);
	ls_returncode:=pkg_message.WriteLine(f,'/PSO/'||row_detail.DOC_PSO);
	if length(row_detail.DOC_BCLASS)>0 then
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/'||row_detail.DOC_BCLASS);
	else
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/000000');
	end if;
	ls_returncode:=pkg_message.WriteLine(f,'/PRT/'||row_detail.DOC_PRT);

	ln_reasonlength:=length(TO_DOS(row_detail.DOC_ASSIGN));
	while ln_index<=floor(ln_reasonlength/52)+1
	Loop
		 if ln_index=1 then
		 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/ASSIGN/'||substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),ln_index*52)));
		 else
		 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),52)));
		 end if;
		 ln_index:=ln_index+1;
	end Loop;

	--ls_returncode:=pkg_message.WriteLine(f,':32A:'||row_clearing.TOTAL_TRAN_DATE||row_clearing.TOTAL_TRAN_CURR||replace(row_clearing.TOTAL_TRAN_AMOUNT,'.',','));
	WHILE cursor_detail%FOUND
	LOOP
		ls_returncode:=pkg_message.WriteLine(f,':21:'||row_detail.DETAIL_ID);
		ls_returncode:=pkg_message.WriteLine(f,':32B:' || row_detail.TRAN_CURR || replace(ltrim(TO_CHAR(row_detail.TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
		ls_returncode:=pkg_message.WriteLine(f,':70:/OPV/'||row_detail.DOC_OPV);
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('//FM/'||row_detail.DOC_FM));
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('//NM/'||row_detail.DOC_NM));
		if row_detail.DOC_FT is not null then
		   ls_returncode:=pkg_message.WriteLine(f,TO_DOS('//FT/'||row_detail.DOC_FT));
		end if;
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('//DT/'||row_detail.DOC_DT));
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('//RNN/'||row_detail.DOC_RNN));
		if row_detail.DOC_KNP not in ('012','017') then
				ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/PERIOD/'||row_detail.DOC_PERIOD));
		end if;

	FETCH cursor_detail into row_detail;
	END LOOP;
	CLOSE cursor_detail;

	ls_returncode:=pkg_message.WriteLine(f,':32A:' || row_clear.TOTAL_TRAN_DATE|| row_clear.TOTAL_TRAN_CURR || replace(ltrim(TO_CHAR(row_clear.TOTAL_TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	CLOSE cursor_clear;

	return ls_returncode;

End;
----------------------------------------------------------------------------------------------------------
Function SendMT102TaxMessage(pn_mesgid in NUMBER)  RETURN VARCHAR2 IS

	cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;

	cursor cursor_detail is
	   		  select *
			   from cbs_clearing_messages_detail
			   where MSG_ID = pn_mesgid
			   order by to_number(DETAIL_ID) asc;

	row_detail	 cursor_detail%rowtype;

   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin

  	OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;

	f:=pkg_message.OpenFile(row_clear.MSG_REFERENCE||'.imp','w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);

	OPEN cursor_detail;
	FETCH cursor_detail INTO row_detail;

	ls_returncode:=pkg_message.WriteLine(f,':50:/'||row_detail.DC_TYPE||'/'||row_detail.FROM_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.FROM_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.FROM_RNN);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/CHIEF/'||row_detail.FROM_CHIEF));
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/MAINBK/'||row_detail.FROM_MAINBK));
	ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.FROM_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.FROM_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':52B:'||row_detail.FROM_BRANCH);
	/*ls_returncode:=pkg_message.WriteLine(f,':53B:'||row_detail.FROM_HQ);
	if row_detail.TO_HQ is not null then
	   ls_returncode:=pkg_message.WriteLine(f,':54B:'||row_detail.TO_HQ);
	end if;
	if row_detail.TO_NBACCOUNT is not null then
	   ls_returncode:=pkg_message.WriteLine(f,':54C:'||row_detail.TO_NBACCOUNT);
	end if;*/
	ls_returncode:=pkg_message.WriteLine(f,':57B:'||row_detail.TO_BRANCH);
	ls_returncode:=pkg_message.WriteLine(f,':59:'||row_detail.TO_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/NAME/'||row_detail.TO_NAME));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.TO_RNN);
    ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.TO_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.TO_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':70:');
	ls_returncode:=pkg_message.WriteLine(f,'/VO/'||row_detail.DOC_VO);
	if length(row_detail.DOC_BCLASS)>0 then
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/'||row_detail.DOC_BCLASS);
	else
	   ls_returncode:=pkg_message.WriteLine(f,'/BCLASS/000000');
	end if;
	ls_returncode:=pkg_message.WriteLine(f,'/SEND/07');
	ls_returncode:=pkg_message.WriteLine(f,'/PSO/'||row_detail.DOC_PSO);
	ls_returncode:=pkg_message.WriteLine(f,'/PRT/'||row_detail.DOC_PRT);

	--ls_returncode:=pkg_message.WriteLine(f,':32A:'||row_clearing.TOTAL_TRAN_DATE||row_clearing.TOTAL_TRAN_CURR||replace(row_clearing.TOTAL_TRAN_AMOUNT,'.',','));
	WHILE cursor_detail%FOUND
	LOOP
		ls_returncode:=pkg_message.WriteLine(f,':21:'||row_detail.DETAIL_ID);
		ls_returncode:=pkg_message.WriteLine(f,':32B:' || row_detail.TRAN_CURR || replace(ltrim(TO_CHAR(row_detail.TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
	    ls_returncode:=pkg_message.WriteLine(f,':70:');
	    ls_returncode:=pkg_message.WriteLine(f,'/NUM/'||row_detail.DOC_NUM);
		ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_detail.DOC_DATE);
		ls_returncode:=pkg_message.WriteLine(f,'/KNP/'||row_detail.DOC_KNP);
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/NAME/'||row_detail.DOC_NM));
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/RNN/'||row_detail.DOC_RNN));
		ln_index:=1;
		ln_reasonlength:=length(TO_DOS(row_detail.DOC_ASSIGN));
		while ln_index<=floor(ln_reasonlength/52)+1
		Loop
			 if ln_index=1 then
			 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/ASSIGN/'||substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),ln_index*52)));
			 else
			 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),52)));
			 end if;
			 ln_index:=ln_index+1;
		end Loop;

	FETCH cursor_detail into row_detail;
	END LOOP;
	CLOSE cursor_detail;

	ls_returncode:=pkg_message.WriteLine(f,':32A:' || row_clear.TOTAL_TRAN_DATE|| row_clear.TOTAL_TRAN_CURR || replace(ltrim(TO_CHAR(row_clear.TOTAL_TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	CLOSE cursor_clear;

	return ls_returncode;

End;
----------------------------------------------------------------------------------------------------------
Function SendMT102OrdMessage(pn_mesgid in NUMBER)  RETURN VARCHAR2 IS

	cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;

	cursor cursor_detail is
	   		  select *
			   from cbs_clearing_messages_detail
			   where MSG_ID = pn_mesgid
			   order by to_number(DETAIL_ID) asc;

	row_detail	 cursor_detail%rowtype;

   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin

  	OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;

	f:=pkg_message.OpenFile(row_clear.MSG_REFERENCE||'.imp','w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);

	OPEN cursor_detail;
	FETCH cursor_detail INTO row_detail;

	ls_returncode:=pkg_message.WriteLine(f,':50:/'||row_detail.DC_TYPE||'/'||row_detail.FROM_ACCOUNT);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.FROM_NAME,1,60)));
	ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.FROM_RNN);
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/CHIEF/'||row_detail.FROM_CHIEF));
	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/MAINBK/'||row_detail.FROM_MAINBK));
	ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.FROM_IRS);
	ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.FROM_SECO);
    ls_returncode:=pkg_message.WriteLine(f,':52B:'||row_detail.FROM_BRANCH);
	ls_returncode:=pkg_message.WriteLine(f,':53B:'||row_detail.FROM_HQ);
	if row_detail.TO_HQ is not null then
	   ls_returncode:=pkg_message.WriteLine(f,':54B:'||row_detail.TO_HQ);
	end if;
	if row_detail.TO_NBACCOUNT is not null then
	   ls_returncode:=pkg_message.WriteLine(f,':54C:'||row_detail.TO_NBACCOUNT);
	end if;
	ls_returncode:=pkg_message.WriteLine(f,':57B:'||row_detail.TO_BRANCH);
    ls_returncode:=pkg_message.WriteLine(f,':70:');
	ls_returncode:=pkg_message.WriteLine(f,'/SEND/07');
	ls_returncode:=pkg_message.WriteLine(f,'/VO/'||row_detail.DOC_VO);
	ls_returncode:=pkg_message.WriteLine(f,'/PRT/'||row_detail.DOC_PRT);

	--ls_returncode:=pkg_message.WriteLine(f,':32A:'||row_clearing.TOTAL_TRAN_DATE||row_clearing.TOTAL_TRAN_CURR||replace(row_clearing.TOTAL_TRAN_AMOUNT,'.',','));
	WHILE cursor_detail%FOUND
	LOOP
		ls_returncode:=pkg_message.WriteLine(f,':21:'||row_detail.DETAIL_ID);
		ls_returncode:=pkg_message.WriteLine(f,':32B:' || row_detail.TRAN_CURR || replace(ltrim(TO_CHAR(row_detail.TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
		ls_returncode:=pkg_message.WriteLine(f,':59:'||row_detail.TO_ACCOUNT);
		ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr('/NAME/'||row_detail.TO_NAME,1,60)));
		ls_returncode:=pkg_message.WriteLine(f,'/RNN/'||row_detail.TO_RNN);
	    ls_returncode:=pkg_message.WriteLine(f,'/IRS/'||row_detail.TO_IRS);
		ls_returncode:=pkg_message.WriteLine(f,'/SECO/'||row_detail.TO_SECO);
	    ls_returncode:=pkg_message.WriteLine(f,':70:/NUM/'||row_detail.DOC_NUM);
		ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_detail.DOC_DATE);
		ls_returncode:=pkg_message.WriteLine(f,'/KNP/'||row_detail.DOC_KNP);
		ln_index:=1;
		ln_reasonlength:=length(TO_DOS(row_detail.DOC_ASSIGN));
		while ln_index<=floor(ln_reasonlength/52)+1
		Loop
			 if ln_index=1 then
			 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS('/ASSIGN/'||substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),ln_index*52)));
			 else
			 	ls_returncode:=pkg_message.WriteLine(f,TO_DOS(substr(row_detail.DOC_ASSIGN,1+(ln_index*52-52),52)));
			 end if;
			 ln_index:=ln_index+1;
		end Loop;

	FETCH cursor_detail into row_detail;
	END LOOP;
	CLOSE cursor_detail;

	ls_returncode:=pkg_message.WriteLine(f,':32A:' || row_clear.TOTAL_TRAN_DATE|| row_clear.TOTAL_TRAN_CURR || replace(ltrim(TO_CHAR(row_clear.TOTAL_TRAN_AMOUNT, 'FM9999999999999990.0099')),'.',','));
	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	CLOSE cursor_clear;

	return ls_returncode;

End;


-----------------------------------------------------------------------------------------------------------
/*Function SendMT192Message(row_clearing IN cursor_clear%rowtype) RETURN VARCHAR2 IS
   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin

	f:=pkg_message.OpenFile(row_clearing.FILE_NAME,'w');
    ls_returncode:=pkg_message.WriteLine(f,row_clearing.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clearing.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clearing.MSG_REFERENCE);
	ls_returncode:=pkg_message.WriteLine(f,':21:'||row_clearing.CANCEL_REFERENCE);
	ls_returncode:=pkg_message.WriteLine(f,':11S:'||row_clearing.CANCEL_KIND);
	ls_returncode:=pkg_message.WriteLine(f,row_clearing.CANCEL_DATE);
	ln_reasonlength:=length(row_clearing.CANCEL_REASON);

	while ln_index<=floor(ln_reasonlength/70)+1
	Loop
		 if ln_index=1 then
		 	ls_returncode:=pkg_message.WriteLine(f,':79:'||substr(row_clearing.CANCEL_REASON,1+(ln_index*70-70),ln_index*70));
		 else
		 	ls_returncode:=pkg_message.WriteLine(f, substr(row_clearing.CANCEL_REASON,1+(ln_index*70-70),70));
		 end if;
		 ln_index:=ln_index+1;
	end Loop;

	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	return ls_returncode;

End;*/
-----------------------------------------------------------------------------------------
Function SendMT998Message(pn_mesgid in NUMBER) RETURN VARCHAR2 IS

    cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;

	cursor cursor_detail is
	   		  select *
			   from cbs_clearing_messages_detail
			   where MSG_ID = pn_mesgid
			   order by DETAIL_ID asc;

	row_detail	 cursor_detail%rowtype;

   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin

  	OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;
	CLOSE cursor_clear;

	OPEN cursor_detail;
	FETCH cursor_detail INTO row_detail;
	CLOSE cursor_detail;

	f:=pkg_message.OpenFile(row_clear.FILE_NAME,'w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);
	ls_returncode:=pkg_message.WriteLine(f,':12:'||row_detail.MSG_CODE);

	if row_detail.MSG_CODE='200' then--cash transfer
	    ls_returncode:=pkg_message.WriteLine(f,':77E:');
		ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_clear.TOTAL_TRAN_DATE);
		ls_returncode:=pkg_message.WriteLine(f,'/REQUESTER/'||row_detail.FROM_NBACCOUNT);
		ls_returncode:=pkg_message.WriteLine(f,'/ACCOUNT/'||row_detail.TO_NBACCOUNT);
		ls_returncode:=pkg_message.WriteLine(f,'/P1/UPDATE/'||row_detail.DC_TYPE || row_clear.TOTAL_TRAN_CURR  || row_clear.TOTAL_TRAN_AMOUNT);
	else--400--reservation
		ls_returncode:=pkg_message.WriteLine(f,':77E:GOVERNMENT MSPD 150');
		ls_returncode:=pkg_message.WriteLine(f,'/DATE/'||row_clear.TOTAL_TRAN_DATE);
		ls_returncode:=pkg_message.WriteLine(f,'/52B/'||row_detail.FROM_HQ);
		ls_returncode:=pkg_message.WriteLine(f,'/53C/'||row_detail.FROM_NBACCOUNT);
		ls_returncode:=pkg_message.WriteLine(f,'/NAME/'||row_detail.TO_HQ);
		ls_returncode:=pkg_message.WriteLine(f,pkg_hesap.GetBankHQName(row_detail.TO_HQ));
		ls_returncode:=pkg_message.WriteLine(f,'/FM/'||row_detail.DOC_FM);
		ls_returncode:=pkg_message.WriteLine(f,'/NM/'||row_detail.DOC_NM);
		ls_returncode:=pkg_message.WriteLine(f,'/FT/'||row_detail.DOC_FT);
		ls_returncode:=pkg_message.WriteLine(f,'/CT/'||TO_DOS(row_detail.DOC_ASSIGN));
		ls_returncode:=pkg_message.WriteLine(f,'/P1/'|| row_detail.DOC_DT ||'/'||row_clear.TOTAL_TRAN_CURR  || row_clear.TOTAL_TRAN_AMOUNT);
		ls_returncode:=pkg_message.WriteLine(f,'/56B/'||row_detail.TO_BRANCH);
		ls_returncode:=pkg_message.WriteLine(f,'/CHIEF/'||TO_DOS(row_detail.FROM_CHIEF));
		ls_returncode:=pkg_message.WriteLine(f,'/MAINBK/'||TO_DOS(row_detail.FROM_MAINBK));
	end if;

	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	return ls_returncode;

End;

-----------------------------------------------------------------------------------------
Function GetBankCodes(ps_gbc IN varchar2)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;

	ls_dirlist		varchar2(2000);
	ln_order	number:=1;

	ls_outstr		varchar2(4000);

	ls_BANK_BIC_CODE   VARCHAR2(9);
	ls_PIND            VARCHAR2(6);
	ls_BANKNAME        VARCHAR2(100);
	ls_HQ_BIC_CODE     VARCHAR2(9);
	ls_NB_BIC_CODE     VARCHAR2(9);
	ls_SYSNAME         VARCHAR2(8);
	ls_CLEARING        VARCHAR2(8);
	ls_ELDOC           VARCHAR2(1);
	ls_filename 	   varchar2(100):='BANKCODES.txt';

BEGIN

 	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	utl_file.get_line(f, ls_outstr);

 LOOP

	--:41:/BANK_BIC_CODE/
	if instr(ls_outstr,'//BIC/')>0 then
	   ls_BANK_BIC_CODE:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//BIC/')+length('//BIC/')));
	end if;

    --:41:/PIND/
	if instr(ls_outstr,'//TYPE/')>0 then
	   ls_PIND:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//TYPE/')+length('//TYPE/')));
	end if;

	 --:41:/BANKNAME/
	if instr(ls_outstr,'//NAME/')>0 then
	   ls_BANKNAME:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//NAME/')+length('//NAME/')));
	end if;

	--:41:/HQ_BIC_CODE/
	if instr(ls_outstr,'//HBIC/')>0 then
	   ls_HQ_BIC_CODE:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//HBIC/')+length('//HBIC/')));
	end if;

	--:41:/NB_BIC_CODE/
	if instr(ls_outstr,'//DBIC/')>0 then
	   ls_NB_BIC_CODE:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//DBIC/')+length('//DBIC/')));
	end if;

	--:41:/SYSNAME/
	--if substr(ls_outstr,1,13)=':41:/SYSNAME/' then
	   ls_SYSNAME:='';
   	--end if;
	--:41:/CLEARING/
	--if substr(ls_outstr,1,14)=':41:/CLEARING/' then
	   ls_CLEARING:='';
	--end if;
	--:41:/ELDOC/
	if instr(ls_outstr,'//STATUS/')>0 then
	   ls_ELDOC:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//STATUS/')+length('//STATUS/')));
	end if;

	if instr(ls_outstr,'//STATUS/')>0 then
	    if ls_HQ_BIC_CODE is null then
		   ls_HQ_BIC_CODE:=ls_BANK_BIC_CODE;
		end if;
		--INSERT TO TABLE
		insert into CBS_BANKCODES
		(BANK_BIC_CODE, PIND, BANKNAME, HQ_BIC_CODE, NB_BIC_CODE, SYSNAME, CLEARING, ELDOC,ORDER_NO)
		values
		(ls_BANK_BIC_CODE, ls_PIND, ls_BANKNAME, ls_HQ_BIC_CODE, ls_NB_BIC_CODE, ls_SYSNAME, ls_CLEARING, ls_ELDOC,ln_order);

		ls_BANK_BIC_CODE:=null;
		ls_PIND:=null;
		ls_BANKNAME:=null;
		ls_HQ_BIC_CODE:=null;
		ls_NB_BIC_CODE:=null;
		ls_SYSNAME:=null;
		ls_CLEARING:=null;
		ls_ELDOC:=null;
		ln_order:=ln_order+1;
	end if;

	utl_file.get_line(f, ls_outstr);--:
	--ls_outstr:=TO_WIN(ls_outstr);

	EXIT WHEN substr(ls_outstr,1,2)='-}';

END LOOP;


	utl_file.fclose(f);


	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('BANKCODES',sqlerrm,ls_outstr);
	 	  RETURN '98' || sqlerrm;
END;

-----------------------------------------------------------------------------------------------------------------------------------------------

Function GetMT900Messages(ps_filename IN varchar2 default null)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;
    ls_dirlist		varchar2(2000);
	ln_filecount	number;
	ln_fileindex	number;
	ls_filename	varchar2(20);

	ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16):=1;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_CANCEL_REFERENCE   VARCHAR2(16);
	ls_IDENTIF_BANK_SCHET   VARCHAR2(19);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
--	ls_DC_TYPE		   VARCHAR2(1);
--	ls_FROM_ACCOUNT    VARCHAR2(9);
--	ls_FROM_NAME       VARCHAR2(60);
--	ls_FROM_RNN        VARCHAR2(12);
--	ls_FROM_CHIEF      VARCHAR2(60);
--	ls_FROM_MAINBK     VARCHAR2(60);
--	ls_FROM_IRS        VARCHAR2(1);
--	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
    ls_FROM_HQ         VARCHAR2(19);
	ls_FROM_NBACCOUNT  VARCHAR2(9);
--	ls_TO_BRANCH       VARCHAR2(9);
--	ls_TO_HQ           VARCHAR2(19);
--	ls_TO_NBACCOUNT    VARCHAR2(9);
--	ls_TO_ACCOUNT      VARCHAR2(9);
--	ls_TO_NAME         VARCHAR2(60);
--	ls_TO_RNN          VARCHAR2(12);
--	ls_TO_IRS          VARCHAR2(1);
--	ls_TO_SECO         VARCHAR2(1);
--	ls_DOC_NUM         VARCHAR2(9);
--	ls_DOC_DATE        VARCHAR2(6);
--	ls_DOC_SEND        VARCHAR2(2);
--	ls_DOC_VO          VARCHAR2(2);
--	ls_DOC_KNP         VARCHAR2(3);
--	ls_DOC_PSO         VARCHAR2(2);
--	ls_DOC_BCLASS	   VARCHAR2(6);
--	ls_DOC_PRT         VARCHAR2(2);
	ls_MESSAGE      VARCHAR2(420);
--	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;
BEGIN

 	ls_filename:=ps_filename;
	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='INCOMING';
	--ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);
    utl_file.get_line(f, ls_outstr);--:21:
	ls_CANCEL_REFERENCE:=substr(ls_outstr,5,16);
    utl_file.get_line(f, ls_outstr);--:25:
	ls_IDENTIF_BANK_SCHET:=substr(ls_outstr,5,19);


	--:32A
	utl_file.get_line(f, ls_outstr);--:32A:
	if substr(ls_outstr,1,5)=':32A:' then
	 	ls_TRAN_DATE:=substr(ls_outstr,6,6);
		ls_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		ls_TOTAL_TRAN_DATE:=ls_TRAN_DATE;
		ls_TOTAL_TRAN_CURR:=ls_TRAN_CURR;
		ln_TOTAL_TRAN_AMOUNT:=ln_TRAN_AMOUNT;
		utl_file.get_line(f, ls_outstr);
	end if;

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if (substr(ls_outstr,1,5)=':53A:') OR (substr(ls_outstr,1,5)=':53B:') then
	   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;


	--:72:
	if instr(ls_outstr,':72:')>0 then
		LOOP
			if instr(ls_outstr,':72:')>0 then
		 		ls_MESSAGE:=substr(ls_outstr,instr(ls_outstr,':72:')+length(':72:'));
			else
				ls_MESSAGE:=ls_MESSAGE || ' ' || ls_outstr;
			end if;

			utl_file.get_line(f, ls_outstr);-- -}
			EXIT WHEN substr(ls_outstr,1,2)='-}';
		END LOOP;
	end if;

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER,TOTAL_TRAN_DATE, TOTAL_TRAN_CURR, TOTAL_TRAN_AMOUNT)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILENAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER,ls_TOTAL_TRAN_DATE, ls_TOTAL_TRAN_CURR, ln_TOTAL_TRAN_AMOUNT);

	--INSERT THE DETAIL	MSG
	insert into cbs_clearing_messages_detail
	(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
     CANCEL_REFERENCE, IDENTIF_BANK_SCHET, MESSAGE)
	values
	(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT,  ls_FROM_BRANCH,
	ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_CANCEL_REFERENCE, ls_IDENTIF_BANK_SCHET, ls_MESSAGE);

	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ900ALLFILES',sqlerrm);
	 	  RETURN '99' || sqlerrm;
END;

---------------------------------------------------------------------------------------------------------
Function GetMT940Messages(ps_filename IN varchar2 default null)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;
    ls_dirlist		varchar2(2000);
	ln_filecount	number;
	ln_fileindex	number;
	ls_filename	varchar2(20);

	ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16):=1;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	--ls_CANCEL_REFERENCE   VARCHAR2(16);
	ls_IDENTIF_BANK_SCHET   VARCHAR2(19);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
    ls_DC_TYPE		   VARCHAR2(1);
	ls_MESSAGE               VARCHAR2(420);
	ls_TOTAL_TRAN_DATE         VARCHAR2(6);
	ls_TOTAL_TRAN_CURR         VARCHAR2(3);
	ls_MSG_CODE                VARCHAR2(7);
	ls_NUM_PAGE                VARCHAR2(5);
	ls_FINAL_DC_TYPE           VARCHAR2(1);
	ls_FINAL_TRAN_DATE         VARCHAR2(6);
	ls_FINAL_TRAN_CURR         VARCHAR2(3);
	ln_FINAL_TRAN_AMOUNT            NUMBER;
	ln_TOTAL_TRAN_AMOUNT		    NUMBER;
BEGIN

 	ls_filename:=ps_filename;
	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='INCOMING';
	--ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);
    utl_file.get_line(f, ls_outstr);--:23:
	ls_MSG_CODE:=substr(ls_outstr,5,7);

    utl_file.get_line(f, ls_outstr);--:25:
	ls_IDENTIF_BANK_SCHET:=substr(ls_outstr,5,19);
    utl_file.get_line(f, ls_outstr);--:28:
	ls_NUM_PAGE:=substr(ls_outstr,5,5);
 	utl_file.get_line(f, ls_outstr);--:60F:-62F
	loop
		if substr(ls_outstr,1,5)=':60F:' then
		    ls_DC_TYPE:=substr(ls_outstr,6,1);
		 	ls_TRAN_DATE:=substr(ls_outstr,7,6);
			ls_TRAN_CURR:=substr(ls_outstr,13,3);
			ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,16),',','.'));
			ls_TOTAL_TRAN_DATE:=ls_TRAN_DATE;
			ls_TOTAL_TRAN_CURR:=ls_TRAN_CURR;
			ln_TOTAL_TRAN_AMOUNT:=ln_TRAN_AMOUNT;
		end if;
		if substr(ls_outstr,1,5)=':62F:' then
	        ls_FINAL_DC_TYPE:=substr(ls_outstr,6,1);
		 	ls_FINAL_TRAN_DATE:=substr(ls_outstr,7,6);
			ls_FINAL_TRAN_CURR:=substr(ls_outstr,13,3);
			ln_FINAL_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,16),',','.'));
	    end if;
	utl_file.get_line(f, ls_outstr);--:60F:-62F
	exit when substr(ls_outstr,1,2)='-}';
	end loop;

		--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER,TOTAL_TRAN_DATE, TOTAL_TRAN_CURR, TOTAL_TRAN_AMOUNT)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILENAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER,ls_TOTAL_TRAN_DATE, ls_TOTAL_TRAN_CURR, ln_TOTAL_TRAN_AMOUNT);

	--INSERT THE DETAIL	MSG
	insert into cbs_clearing_messages_detail
	(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE,
     IDENTIF_BANK_SCHET, MSG_CODE, NUM_PAGE, FINAL_TRAN_DATE, FINAL_TRAN_CURR, FINAL_TRAN_AMOUNT, FINAL_DC_TYPE)
	values
	(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE,
	 ls_IDENTIF_BANK_SCHET, ls_MSG_CODE, ls_NUM_PAGE,
	ls_FINAL_TRAN_DATE, ls_FINAL_TRAN_CURR, ln_FINAL_TRAN_AMOUNT, ls_FINAL_DC_TYPE);


	if ls_MSG_CODE='FINAL' then
	   pkg_clearing.UpdateClearingPosition('START',to_number(ln_FINAL_TRAN_AMOUNT),to_char(pkg_tarih.ileri_is_gunu(to_date(ls_FINAL_TRAN_DATE,'YYMMDD')),'YYMMDD'));
	end if;


	/*if ls_MSG_CODE='FINAL' then

	   insert into cbs_clearing_position
	   (VALUE_DATE, INITIAL_AMOUNT,OUTGOING_AMOUNT, INCOMING_AMOUNT)
	   values
	   (to_date(ls_FINAL_TRAN_DATE,'YYMMDD')+1, ln_FINAL_TRAN_AMOUNT, 0, 0);

	   --pkg_clearing.UpdateClearingPosition('START',ln_FINAL_TRAN_AMOUNT,to_char(to_date(ls_FINAL_TRAN_DATE,'YYMMDD')+1,'YYMMDD'));
	end if;*/

	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ940ALLFILES',sqlerrm);
	 	  RETURN '99' || sqlerrm;
END;
-------------------------------------------------------------------------------------------------------------
Function UploadInstClearingFile(ps_filename IN varchar2 default null)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;
	ls_dirlist		varchar2(2000);
	ls_outstr		varchar2(4000);

	ln_INST_ID		number;
	ln_ORDER_ID		number:=0;
	ld_INST_DATE	date;
	ls_TO_BRANCH varchar2(9);
	ls_TO_SOR varchar2(1);
	ls_TO_KNP varchar2(3);
	ln_AMOUNT	  number;
	ls_delimiter  varchar2(1);

	 --MT102
	 cursor cursor_inst is
	   		  select distinct TO_BRANCH
			   from cbs_clearing_inst
			   where STATUS_CD='sWAIT'
   			   and TO_BRANCH not in ('190501724','190501793')
			   and ltrim(DOC_BCLASS) is null;

	row_inst	 cursor_inst%rowtype;

	cursor cursor_instdetail(ps_TO_BRANCH varchar2) is
	   		  select *
			   from cbs_clearing_inst
			   where STATUS_CD='sWAIT'
			   and TO_BRANCH=ps_TO_BRANCH
			   and TO_BRANCH not in ('190501724','190501793')
			   and ltrim(DOC_BCLASS) is null;

	row_instdetail	 cursor_instdetail%rowtype;

	--MT100
	cursor cursor_ainstdetail is
	   		  select *
			   from cbs_clearing_inst
			   where STATUS_CD='sWAIT'
			   and TO_BRANCH in ('190501724','190501793')
			   and ltrim(DOC_BCLASS) is null;

	row_ainstdetail	 cursor_ainstdetail%rowtype;


	--BCLASS
	cursor cursor_bcinst is
	   		  select distinct TO_BRANCH,DOC_BCLASS,TO_RNN
			   from cbs_clearing_inst
			   where STATUS_CD='sWAIT'
   			   and TO_BRANCH not in ('190501724','190501793')
			   and DOC_BCLASS is not null;

	row_bcinst	 cursor_bcinst%rowtype;

	cursor cursor_bcinstdetail(ps_TO_BRANCH varchar2,ps_DOC_BCLASS varchar2,ps_TO_RNN varchar2) is
	   		  select *
			   from cbs_clearing_inst
			   where STATUS_CD='sWAIT'
			   and TO_BRANCH=ps_TO_BRANCH
			   and DOC_BCLASS=ps_DOC_BCLASS
			   and TO_RNN=ps_TO_RNN
			   and TO_BRANCH not in ('190501724','190501793')
			   and ltrim(DOC_BCLASS) is not null;

	row_bcinstdetail	 cursor_bcinstdetail%rowtype;

	ln_MSG_ID          NUMBER;
	ln_DETAIL_ID	   number;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	--ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(9);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_ASSIGN      VARCHAR2(250);
	ls_DOC_OPV         VARCHAR2(17);
	ls_DOC_FM          VARCHAR2(60);
	ls_DOC_NM          VARCHAR2(60);
	ls_DOC_FT          VARCHAR2(60);
	ls_DOC_DT          VARCHAR2(8);
	ls_DOC_LA          VARCHAR2(9);
	ls_DOC_RNN         VARCHAR2(12);
	ls_DOC_FM2         VARCHAR2(60);
	ls_DOC_NM2         VARCHAR2(60);
	ls_DOC_FT2         VARCHAR2(60);
	ls_DOC_LA2         VARCHAR2(9);
	ls_DOC_RNN2        VARCHAR2(12);
	ls_DOC_PERIOD      VARCHAR2(6);
	ls_FROM_GL		   VARCHAR2(8);

	ln_TOTAL_TRAN_AMOUNT		   NUMBER:=0;


BEGIN
 	f:=utl_file.fopen(INST_PATH, ps_filename, 'r',2100);

	ln_INST_ID:=pkg_genel.genel_kod_al('CLEARING_INST');
	LOOP
		begin
	       utl_file.get_line(f, ls_outstr);
		   ls_delimiter:=substr(ls_outstr,10,1);
	    EXCEPTION
	      WHEN NO_DATA_FOUND THEN
	        EXIT;
	    end;

		EXIT WHEN instr(ls_outstr,ls_delimiter)<1;

		ln_ORDER_ID:=ln_ORDER_ID+1;
		ld_INST_DATE:=pkg_muhasebe.Banka_Tarihi_Bul;
		ls_TO_BRANCH:=split(ls_outstr,ls_delimiter,0);
		ls_TO_ACCOUNT:=lpad(ltrim(split(ls_outstr,ls_delimiter,1)),9,'0');
		ls_TO_RNN:=split(ls_outstr,ls_delimiter,3);
		ln_AMOUNT:=to_number(split(ls_outstr,ls_delimiter,4),'9999999999999.99');
		ls_TO_NAME:=TO_WIN(split(ls_outstr,ls_delimiter,5));
		--From name of file we get date of file
		--ls_DOC_ASSIGN:= substr(ps_filename,7,2) ||'.'||substr(ps_filename,5,2) ||'.'||to_char(sysdate,'YYYY')||'-'|| TO_WIN(split(ls_outstr,ls_delimiter,6));
		if substr(ps_filename,1,4)='9000' then--ALSECO
		   ls_DOC_ASSIGN:= TO_WIN(split(ls_outstr,ls_delimiter,6)) ||', ???????? ????????? ????????????? ???????? ?? "??????" ?? '||substr(ps_filename,7,2) || substr(ps_filename,5,2) || to_char(sysdate,'YYYY') || '-(???? ?????)';
		elsif substr(ps_filename,1,4)='2420' then--IVTS
		   ls_DOC_ASSIGN:= TO_WIN(split(ls_outstr,ls_delimiter,6)) ||', ???????? ????????? ????????????? ???????? ?? "IVTS" ?? '||substr(ps_filename,7,2) || substr(ps_filename,5,2) || to_char(sysdate,'YYYY') || '-(???? ?????)';
		end if;

		ls_DOC_BCLASS:=rtrim(ltrim(split(ls_outstr,ls_delimiter,7)));
		if length(split(ls_outstr,ls_delimiter,8))=2 then
		   ls_TO_SOR:=substr(rtrim(ltrim(split(ls_outstr,ls_delimiter,8))),1,1);
		   ls_TO_SECO:=substr(rtrim(ltrim(split(ls_outstr,ls_delimiter,8))),2,1);
   		   ls_TO_KNP:=rtrim(ltrim(split(ls_outstr,ls_delimiter,9)));
		   ls_DOC_RNN:=rtrim(ltrim(split(ls_outstr,ls_delimiter,10)));
	       ls_DOC_NM:=rtrim(ltrim(split(ls_outstr,ls_delimiter,11)));
		else
			ls_TO_SOR:=split(ls_outstr,ls_delimiter,8);
			ls_TO_SECO:=split(ls_outstr,ls_delimiter,9);
			ls_TO_KNP:=split(ls_outstr,ls_delimiter,10);
			ls_DOC_RNN:=rtrim(ltrim(split(ls_outstr,ls_delimiter,11)));
			ls_DOC_NM:=rtrim(ltrim(split(ls_outstr,ls_delimiter,12)));
		end if;

		insert into CBS_CLEARING_INST
		(INST_ID, ORDER_ID, FILE_NAME,INST_DATE,TO_BRANCH, TO_ACCOUNT, TO_RNN, TO_NAME, DOC_ASSIGN, TO_SOR, TO_SECO, TO_KNP, DOC_BCLASS,AMOUNT,DOC_NM,DOC_RNN)
		values
		(ln_INST_ID, ln_ORDER_ID, ps_filename,ld_INST_DATE,ls_TO_BRANCH, ls_TO_ACCOUNT, ls_TO_RNN, ls_TO_NAME, ls_DOC_ASSIGN, ls_TO_SOR, ls_TO_SECO, ls_TO_KNP, ls_DOC_BCLASS,ln_AMOUNT,ls_DOC_NM,ls_DOC_RNN);

	END LOOP;

	utl_file.fclose(f);


	--MT102
 	OPEN cursor_inst;
 	FETCH cursor_inst INTO row_inst;
 	WHILE cursor_inst%FOUND
 	LOOP
 		ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
		ls_MSG_TYPE:='INST-ORD';
		ls_FIRST_HEADER:='{1:F01K057880000000000000000}';
		ls_SECOND_HEADER:='{2:I102SCLEAR000000U3003}';
		ls_MSG_KIND:='102';
		ls_PAYMENT_TYPE:='SCLEAR';
		ls_MSG_REFERENCE:=null;

   		--INSERT MASTER MSG
		insert into CBS_CLEARING_MESSAGES
		(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
		values
		(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ln_MSG_ID||'_'||ps_filename, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

		OPEN cursor_instdetail(row_inst.TO_BRANCH);
		FETCH cursor_instdetail INTO row_instdetail;
		ln_DETAIL_ID:=0;
		ln_TOTAL_TRAN_AMOUNT:=0;
		WHILE cursor_instdetail%FOUND
		LOOP
			--log_at('INST-1',row_instdetail.INST_ID,row_instdetail.ORDER_ID,row_instdetail.AMOUNT);
			ln_DETAIL_ID:=ln_DETAIL_ID+1;
			ls_TRAN_DATE:=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
			ls_TRAN_CURR:='KZT';
			ln_TRAN_AMOUNT:= row_instdetail.AMOUNT;
			ls_DC_TYPE:='D';
			if substr(row_instdetail.FILE_NAME,1,4)='9000' then--ALSECO
			   ls_FROM_ACCOUNT:='001902805';
			elsif substr(row_instdetail.FILE_NAME,1,4)='2420' then--IVTS
			   ls_FROM_ACCOUNT:='001902902';
			end if;
			--log_at('INST-11',ls_FROM_ACCOUNT);
			ls_FROM_NAME:= pkg_genelkz.GetGLExternalFromName(ls_FROM_ACCOUNT);
			--log_at('INST-111',ls_FROM_ACCOUNT);
			ls_FROM_RNN:='600400059451';
			ls_FROM_CHIEF:=pkg_genelkz.GetDKBChiefName('010');
			ls_FROM_MAINBK:=pkg_genelkz.GetDKBMainBKName('010');
			ls_FROM_IRS:='1';
			ls_FROM_SECO:='4';
			ls_FROM_BRANCH:='190501788';
			ls_FROM_HQ:='190501788';
			ls_FROM_NBACCOUNT:=null;
			ls_TO_BRANCH:= row_instdetail.TO_BRANCH;
			--log_at('INST-12',row_instdetail.TO_BRANCH);
			ls_TO_HQ:=pkg_hesap.GetBankHQ(row_instdetail.TO_BRANCH);
			ls_TO_NBACCOUNT:=null;
			ls_TO_ACCOUNT:= row_instdetail.TO_ACCOUNT;
			ls_TO_NAME:=row_instdetail.TO_NAME;
			ls_TO_RNN:=row_instdetail.TO_RNN;
			ls_TO_IRS:=row_instdetail.TO_SOR;
			ls_TO_SECO:=row_instdetail.TO_SECO;
			ls_DOC_NUM:=ln_DETAIL_ID;
			ls_DOC_DATE:= ls_TRAN_DATE;
			ls_DOC_SEND:='07';
			ls_DOC_VO:='01';
			ls_DOC_KNP:=row_instdetail.TO_KNP;
			ls_DOC_PSO:='01';
			ls_DOC_BCLASS:= row_instdetail.DOC_BCLASS;
			ls_DOC_PRT:='40' ;
			ls_DOC_ASSIGN:=row_instdetail.DOC_ASSIGN;
			ls_DOC_NM:=row_instdetail.DOC_NM;
			ls_DOC_RNN:=row_instdetail.DOC_RNN;

			ln_TOTAL_TRAN_AMOUNT:=ln_TOTAL_TRAN_AMOUNT+ln_TRAN_AMOUNT;

			insert into cbs_clearing_messages_detail
			(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
			FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
			TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
			DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_NM,DOC_RNN)
			values
			(ln_MSG_ID, ln_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
			ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, nvl(ls_FROM_BRANCH,ls_FROM_HQ),
			ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
			ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
			ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_NM,ls_DOC_RNN);

			update CBS_CLEARING_INST
			set STATUS_CD='sDONE'
			where INST_ID=row_instdetail.INST_ID
			and ORDER_ID=row_instdetail.ORDER_ID;
			--log_at('INST-2',row_instdetail.INST_ID,row_instdetail.ORDER_ID);
		FETCH cursor_instdetail into row_instdetail;
		END LOOP;
		CLOSE cursor_instdetail;

		update cbs_clearing_messages
		set TOTAL_TRAN_DATE=ls_TRAN_DATE,
		 	TOTAL_TRAN_CURR=ls_TRAN_CURR,
			TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
		where
			MSG_ID=ln_MSG_ID;

	FETCH cursor_inst into row_inst;
	END LOOP;
	CLOSE cursor_inst;

	--MT100
	OPEN cursor_ainstdetail;
	FETCH cursor_ainstdetail INTO row_ainstdetail;
 	WHILE cursor_ainstdetail%FOUND
 	LOOP
 		ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	    ls_MSG_TYPE:='INST-100';
		ls_FIRST_HEADER:='{1:F01K057880000000000000000}';
		ls_SECOND_HEADER:='{2:I100SCLEAR000000U3003}';
		ls_MSG_KIND:='100';
		ls_PAYMENT_TYPE:='SCLEAR';
		ls_MSG_REFERENCE:=null;

   		--INSERT MASTER MSG
		insert into CBS_CLEARING_MESSAGES
		(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
		values
		(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ln_MSG_ID||'_'||ps_filename, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

		ln_DETAIL_ID:=1;
		ln_TOTAL_TRAN_AMOUNT:=0;
		ls_TRAN_DATE:=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
		ls_TRAN_CURR:='KZT';
		ln_TRAN_AMOUNT:= row_ainstdetail.AMOUNT;
		ls_DC_TYPE:='D';
		if substr(row_ainstdetail.FILE_NAME,1,4)='9000' then--ALSECO
		   ls_FROM_ACCOUNT:='001902805';
		elsif substr(row_ainstdetail.FILE_NAME,1,4)='2420' then--IVTS
		   ls_FROM_ACCOUNT:='001902902';
		end if;
		ls_FROM_NAME:= pkg_genelkz.GetGLExternalFromName(ls_FROM_ACCOUNT);
		ls_FROM_RNN:='600400059451';
		ls_FROM_CHIEF:=pkg_genelkz.GetDKBChiefName('010');
		ls_FROM_MAINBK:=pkg_genelkz.GetDKBMainBKName('010');
		ls_FROM_IRS:='1';
		ls_FROM_SECO:='4';
		ls_FROM_BRANCH:='190501788';
		ls_FROM_HQ:='190501788';
		ls_FROM_NBACCOUNT:=null;
		ls_TO_BRANCH:= row_ainstdetail.TO_BRANCH;
		ls_TO_HQ:=pkg_hesap.GetBankHQ(row_ainstdetail.TO_BRANCH);
		ls_TO_NBACCOUNT:=null;
		ls_TO_ACCOUNT:= row_ainstdetail.TO_ACCOUNT;
		ls_TO_NAME:=row_ainstdetail.TO_NAME;
		ls_TO_RNN:=row_ainstdetail.TO_RNN;
		ls_TO_IRS:=row_ainstdetail.TO_SOR;
		ls_TO_SECO:=row_ainstdetail.TO_SECO;
		ls_DOC_NUM:=ln_DETAIL_ID;
		ls_DOC_DATE:= ls_TRAN_DATE;
		ls_DOC_SEND:='07';
		ls_DOC_VO:='01';
		ls_DOC_KNP:=row_ainstdetail.TO_KNP;
		ls_DOC_PSO:='01';
		ls_DOC_BCLASS:= row_ainstdetail.DOC_BCLASS;
		ls_DOC_PRT:='40' ;
		ls_DOC_ASSIGN:=row_ainstdetail.DOC_ASSIGN;
		ls_DOC_NM:=row_ainstdetail.DOC_NM;
		ls_DOC_RNN:=row_ainstdetail.DOC_RNN;

		ln_TOTAL_TRAN_AMOUNT:=ln_TOTAL_TRAN_AMOUNT+ln_TRAN_AMOUNT;

		insert into cbs_clearing_messages_detail
		(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
		FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
		TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
		DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_NM,DOC_RNN)
		values
		(ln_MSG_ID, ln_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
		ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, nvl(ls_FROM_BRANCH,ls_FROM_HQ),
		ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
		ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
		ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_NM,ls_DOC_RNN);

		update CBS_CLEARING_INST
		set STATUS_CD='sDONE'
		where INST_ID=row_ainstdetail.INST_ID
		and ORDER_ID=row_ainstdetail.ORDER_ID;

		update cbs_clearing_messages
		set TOTAL_TRAN_DATE=ls_TRAN_DATE,
		 	TOTAL_TRAN_CURR=ls_TRAN_CURR,
			TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
		where
			MSG_ID=ln_MSG_ID;

	FETCH cursor_ainstdetail into row_ainstdetail;
	END LOOP;
	CLOSE cursor_ainstdetail;

		----BCLASS
	OPEN cursor_bcinst;
	FETCH cursor_bcinst INTO row_bcinst;
	WHILE cursor_bcinst%FOUND
		LOOP
			ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
			if row_bcinst.TO_BRANCH in ('190501724','190501793') then
			    ls_MSG_TYPE:='INST-100';
				ls_FIRST_HEADER:='{1:F01K057880000000000000000}';
				ls_SECOND_HEADER:='{2:I100SCLEAR000000U3003}';
				ls_MSG_KIND:='100';
			else
				ls_MSG_TYPE:='INST-ORD';
				ls_FIRST_HEADER:='{1:F01K057880000000000000000}';
				ls_SECOND_HEADER:='{2:I102SCLEAR000000U3003}';
				ls_MSG_KIND:='102';
		    end if;
			ls_PAYMENT_TYPE:='SCLEAR';
			ls_MSG_REFERENCE:=null;

	   		--INSERT MASTER MSG
			insert into CBS_CLEARING_MESSAGES
			(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
			values
			(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ln_MSG_ID||'_'||ps_filename, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

			OPEN cursor_bcinstdetail(row_bcinst.TO_BRANCH,row_bcinst.DOC_BCLASS,row_bcinst.TO_RNN);
			FETCH cursor_bcinstdetail INTO row_bcinstdetail;
			ln_DETAIL_ID:=0;
			ln_TOTAL_TRAN_AMOUNT:=0;
			WHILE cursor_bcinstdetail%FOUND
			LOOP

				if row_bcinstdetail.DOC_BCLASS is not null then
					ls_MSG_TYPE:='INST-TAX';
					update CBS_CLEARING_MESSAGES
					set MSG_TYPE=ls_MSG_TYPE
					where  MSG_ID=ln_MSG_ID;
				end if;

				ln_DETAIL_ID:=ln_DETAIL_ID+1;
				ls_TRAN_DATE:=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
				ls_TRAN_CURR:='KZT';
				ln_TRAN_AMOUNT:= row_bcinstdetail.AMOUNT;
				ls_DC_TYPE:='D';
				if substr(row_bcinstdetail.FILE_NAME,1,4)='9000' then--ALSECO
				   ls_FROM_ACCOUNT:='001902805';
				elsif substr(row_bcinstdetail.FILE_NAME,1,4)='2420' then--IVTS
				   ls_FROM_ACCOUNT:='001902902';
				end if;
				ls_FROM_NAME:= pkg_genelkz.GetGLExternalFromName(ls_FROM_ACCOUNT);
				ls_FROM_RNN:='600400059451';
				ls_FROM_CHIEF:=pkg_genelkz.GetDKBChiefName('010');
				ls_FROM_MAINBK:=pkg_genelkz.GetDKBMainBKName('010');
				ls_FROM_IRS:='1';
				ls_FROM_SECO:='4';
				ls_FROM_BRANCH:='190501788';
				ls_FROM_HQ:='190501788';
				ls_FROM_NBACCOUNT:=null;
				ls_TO_BRANCH:= row_bcinstdetail.TO_BRANCH;
				ls_TO_HQ:=pkg_hesap.GetBankHQ(row_bcinstdetail.TO_BRANCH);
				ls_TO_NBACCOUNT:=null;
				ls_TO_ACCOUNT:= row_bcinstdetail.TO_ACCOUNT;
				ls_TO_NAME:=row_bcinstdetail.TO_NAME;
				ls_TO_RNN:=row_bcinstdetail.TO_RNN;
				ls_TO_IRS:=row_bcinstdetail.TO_SOR;
				ls_TO_SECO:=row_bcinstdetail.TO_SECO;
				ls_DOC_NUM:=ln_DETAIL_ID;
				ls_DOC_DATE:= ls_TRAN_DATE;
				ls_DOC_SEND:='07';
				ls_DOC_VO:='08';
				ls_DOC_KNP:=row_bcinstdetail.TO_KNP;
				ls_DOC_PSO:='01';
				ls_DOC_BCLASS:= row_bcinstdetail.DOC_BCLASS;
				ls_DOC_PRT:='40' ;
				ls_DOC_ASSIGN:=row_bcinstdetail.DOC_ASSIGN;
				ls_DOC_NM:=row_bcinstdetail.DOC_NM;
				ls_DOC_RNN:=row_bcinstdetail.DOC_RNN;

				ln_TOTAL_TRAN_AMOUNT:=ln_TOTAL_TRAN_AMOUNT+ln_TRAN_AMOUNT;

				insert into cbs_clearing_messages_detail
				(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
				FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
				TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
				DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_NM,DOC_RNN)
				values
				(ln_MSG_ID, ln_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
				ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, nvl(ls_FROM_BRANCH,ls_FROM_HQ),
				ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
				ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
				ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_NM,ls_DOC_RNN);

				update CBS_CLEARING_INST
				set STATUS_CD='sDONE'
				where INST_ID=row_bcinstdetail.INST_ID
				and ORDER_ID=row_bcinstdetail.ORDER_ID;

			FETCH cursor_bcinstdetail into row_bcinstdetail;
			END LOOP;
			CLOSE cursor_bcinstdetail;

			update cbs_clearing_messages
			set TOTAL_TRAN_DATE=ls_TRAN_DATE,
			 	TOTAL_TRAN_CURR=ls_TRAN_CURR,
				TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
			where
				MSG_ID=ln_MSG_ID;

		FETCH cursor_bcinst into row_bcinst;
		END LOOP;
		CLOSE cursor_bcinst;

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  log_at('UPLOAD INST FILE',sqlerrm);
 	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'UPLOAD INST FILE-Unknown Error.<BR>'||chr(10)||chr(13) || sqlerrm || TO_WIN('<BR>Amount:' || ln_TRAN_AMOUNT || '<BR>Branch Code:'|| ls_TO_BRANCH ) || chr(10)||chr(13));
	 	  RETURN '995';
END;

--------------------------------------------------------------------------------------------------------------
Function ReadCityCodes(ps_gbc IN varchar2)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;

	ls_dirlist		varchar2(2000);
	ln_order	number:=1;

	ls_outstr		varchar2(4000);
	ls_filename 	   varchar2(100):='open.txt';
	ls_IL_KODU		   varchar2(13);
	ls_IL_ADI		   varchar2(20);
	--ls_IL_KODU		    varchar2(3);
	ln_VERGI_DAIRE_KODU  number;
	ls_VERGI_DAIRE_ADI	   varchar2(100);

	ln_ILCE_KODU		   number;
	ls_ILCE_ADI			   varchar2(50);
	ln_CODE				   number;
	ls_EXPLANATION		   varchar2(2000);
	ln_MUSTERI_NO			   number;
	ls_ESKI_MUSTERI_NO		   varchar2(16);
	ls_ESKI_HESAP_NO		   varchar2(16);
	ls_ISIM				   varchar2(250);
	ls_currency_code	   varchar2(2);
	ls_FIELD1			   varchar2(20);
	ls_FIELD2			   varchar2(20);
	ls_FIELD3			   varchar2(20);
	ls_FIELD4			   varchar2(20);
	ls_FIELD5			   varchar2(20);
	ls_FIELD6			   varchar2(20);
BEGIN

 	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	utl_file.get_line(f, ls_outstr);
	--ls_outstr:=convert(ls_outstr,'RU8PC866','CL8MSWIN1251')

 LOOP

    --ls_IL_KODU:=lpad(split(ls_outstr,',',0),3,'0');
    --ls_IL_ADI:=substr(split(ls_outstr,',',1),1,20);

	--ls_IL_KODU:=lpad(split(ls_outstr,',',0),3,'0');
	--ln_VERGI_DAIRE_KODU:=to_number(split(ls_outstr,',',1));
	--ls_VERGI_DAIRE_ADI:=split(ls_outstr,',',2);

	--ls_IL_KODU:=lpad(split(ls_outstr,',',0),3,'0');
	--ln_ILCE_KODU:=to_number(split(ls_outstr,',',1));
	--ls_ILCE_ADI:=split(ls_outstr,',',2);

	--ls_IL_KODU:= split(ls_outstr,'*',0);
	--ln_ILCE_KODU:=to_number(split(ls_outstr,'*',1));
	/*ls_ESKI_MUSTERI_NO:=split(ls_outstr,'*',0);
	ls_ESKI_HESAP_NO:=split(ls_outstr,'*',1);
	ls_currency_code:=split(ls_outstr,'*',2);*/

	/*--INSERT TO TABLE
	insert into CBS_IL_KODLARI
	(IL_KODU, IL_ADI)
	values
	(ls_IL_KODU, ls_IL_ADI);*/

	/*
	insert into CBS_VERGI_DAIRE_KODLARI
	(IL_KODU, VERGI_DAIRE_KODU, VERGI_DAIRE_ADI)
	values
	(ls_IL_KODU, ln_VERGI_DAIRE_KODU, ls_VERGI_DAIRE_ADI);
	*/

	/*
	insert into CBS_ILCE_KODLARI
	(IL_KODU, ILCE_KODU, ILCE_ADI)
	values
	(ls_IL_KODU, ln_ILCE_KODU, ls_ILCE_ADI);


	insert into CBS_TAX_TYPES
	(CODE, EXPLANATION)
	values
	(ln_CODE, ls_EXPLANATION);
	*/
	ls_FIELD1:=split(ls_outstr,'*',0);
	ls_FIELD2:=split(ls_outstr,'*',1);
	ls_FIELD3:=split(ls_outstr,'*',2);
	ls_FIELD4:=split(ls_outstr,'*',3);
	ls_FIELD5:=split(ls_outstr,'*',4);
	ls_FIELD6:=split(ls_outstr,'*',5);
/*
	insert into OPENING_ERRORS
	(FIELD1, FIELD2, FIELD3, FIELD4, FIELD5, FIELD6)
	values
	(ls_FIELD1, ls_FIELD2, ls_FIELD3, ls_FIELD4, ls_FIELD5, ls_FIELD6);

*/
	utl_file.get_line(f, ls_outstr);--:

	EXIT WHEN substr(ls_outstr,1,6)='THEEND';

END LOOP;


	utl_file.fclose(f);


	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('CITYCODES',sqlerrm);
	 	  RETURN '98' || sqlerrm;
END;

---------------------------------------------------------------------------------------------------------------
FUNCTION  GetScanMT100Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2 IS
	f	  utl_file.file_type;

	ls_dirlist		varchar2(2000);
	ln_filecount	number;
	ln_fileindex	number;
	ls_filename	varchar2(30);

	ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16):=1;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(20);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_ASSIGN      VARCHAR2(500);
	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;

	ErrorPERIODException					 exception;
	ErrorCheckException						 exception;
	TotalTranSumWrong						 exception;
	InvalidBankCode							 exception;
	ls_check_error							 varchar2(500);
	ToBankCodeAccountError					 exception;

BEGIN

 	ls_filename:=ps_filename;
 	f:=utl_file.fopen(SCAN_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='SCAN';
	ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:='SCLEAR';--substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);

	--:32A
	utl_file.get_line(f, ls_outstr);--:32A:
	if substr(ls_outstr,1,5)=':32A:' then
	 	ls_TRAN_DATE:=substr(ls_outstr,6,6);
		ls_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		ls_TOTAL_TRAN_DATE:=ls_TRAN_DATE;
		ls_TOTAL_TRAN_CURR:=ls_TRAN_CURR;
		ln_TOTAL_TRAN_AMOUNT:=ln_TRAN_AMOUNT;
		utl_file.get_line(f, ls_outstr);
	end if;


	--:50:
	if substr(ls_outstr,1,4)=':50:' then
		LOOP
			if instr(ls_outstr,'/D/')>0 then
			   ls_DC_TYPE:='D';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
			elsif instr(ls_outstr,'/C/')>0 then
			   ls_DC_TYPE:='C';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --log_at(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),convert(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),'RU8PC866','CL8MSWIN1251'));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_FROM_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
			elsif instr(ls_outstr,'/CHIEF/')>0 then
			   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
			elsif instr(ls_outstr,'/MAINBK/')>0 then
			   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;

			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--:50:

	ls_FROM_ACCOUNT:=lpad(ls_FROM_ACCOUNT,9,'0');

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53B:' then
	   ls_FROM_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54B:' then
	   ls_TO_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54C:' then
	   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':57B:' then
	   ls_TO_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;

	begin
		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;
	exception
	    when others then
			 raise InvalidBankCode;
	end;

	/*if ls_FROM_BRANCH is NULL then
	   ls_FROM_BRANCH:=ls_FROM_HQ;
	end if;
	if ls_TO_HQ is null then
	   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
	end if;*/

	--:59:
	if substr(ls_outstr,1,4)=':59:' then
		LOOP
			if substr(ls_outstr,1,4)=':59:' then
			   ls_TO_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_TO_RNN:=substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_TO_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_TO_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;
			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--59

	if pkg_hesap.Check_External_HesapNo(ls_FROM_BRANCH,ls_FROM_ACCOUNT)=0 then
	   raise ToBankCodeAccountError;
	end if;

	ls_TO_ACCOUNT:=lpad(ls_TO_ACCOUNT,9,'0');

	if pkg_hesap.Check_External_HesapNo(ls_TO_BRANCH,ls_TO_ACCOUNT)=0 then
	   raise ToBankCodeAccountError;
	end if;

	--:70:
	if substr(ls_outstr,1,4)=':70:' then
		LOOP
			if instr(ls_outstr,'/NUM/')>0 then
			   ls_DOC_NUM:=rtrim(substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/')));
			elsif instr(ls_outstr,'/DATE/')>0 then
			   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
			elsif instr(ls_outstr,'/SEND/')>0 then
			   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
			elsif instr(ls_outstr,'/VO/')>0 then
			   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
			elsif instr(ls_outstr,'/KNP/')>0 then
			   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
			elsif instr(ls_outstr,'/PSO/')>0 then
			   ls_DOC_PSO:='01';--substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
			elsif instr(ls_outstr,'/BCLASS/')>0 then
			   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
			elsif instr(ls_outstr,'/PRT/')>0 then
			   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
			elsif instr(ls_outstr,'/ASSIGN/')>0 then
			   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
			else
			   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
			end if;

			utl_file.get_line(f, ls_outstr);--:
			EXIT WHEN substr(ls_outstr,1,2)='-}';
		END LOOP;
	end if;--70

	if ls_TOTAL_TRAN_DATE='000000' or ls_TRAN_DATE='000000' then
	   ls_TOTAL_TRAN_DATE:=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
	   ls_TRAN_DATE:=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD');
	end if;

	if length(ls_DOC_NUM)>9 then
	   ls_DOC_NUM:=substr(ls_DOC_NUM,-9);
	end if;

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER,TOTAL_TRAN_DATE, TOTAL_TRAN_CURR, TOTAL_TRAN_AMOUNT)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILE_NAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER,ls_TOTAL_TRAN_DATE, ls_TOTAL_TRAN_CURR, ln_TOTAL_TRAN_AMOUNT);

	--INSERT THE DETAIL	MSG
	insert into cbs_clearing_messages_detail
	(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
	FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
	TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
	DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_PRT, DOC_BCLASS, DOC_ASSIGN)
	values
	(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
	ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, ls_FROM_BRANCH,
	ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
	ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
	ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_PRT, ls_DOC_BCLASS, ls_DOC_ASSIGN);

	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);

	 RETURN '000';

EXCEPTION
	 when InvalidBankCode then
	  	  ROLLBACK;
 		  ls_check_error:=to_char(ls_TO_BRANCH) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Wrong Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '993';

	 when ToBankCodeAccountError then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ls_TO_BRANCH) || ' not in ' || to_char(ls_TO_ACCOUNT) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Wrong Receiver Account No for the Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '994';

	 WHEN OTHERS THEN
	 	  log_at('CLEAR_IN',ls_outstr);
	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Unknown Error.'||chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';

/*	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ100ALLFILES',sqlerrm);
	 	  RETURN '998' || sqlerrm;*/
END;
-------------------------------------------------------------------------------------------------------------------------------------------
FUNCTION  GetScanMT102Messages( ps_filename IN VARCHAR2 default null) RETURN VARCHAR2 IS
	 f	  utl_file.file_type;

	 ls_dirlist		varchar2(2000);
	 ln_filecount	number;
	 ln_fileindex	number;
	 ls_filename	varchar2(30);

	 ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16);
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
	ls_DC_TYPE		   VARCHAR2(1);
	ls_FROM_ACCOUNT    VARCHAR2(9);
	ls_FROM_NAME       VARCHAR2(60);
	ls_FROM_RNN        VARCHAR2(12);
	ls_FROM_CHIEF      VARCHAR2(60);
	ls_FROM_MAINBK     VARCHAR2(60);
	ls_FROM_IRS        VARCHAR2(1);
	ls_FROM_SECO       VARCHAR2(1);
	ls_FROM_BRANCH     VARCHAR2(9);
	ls_FROM_HQ         VARCHAR2(9);
	ls_FROM_NBACCOUNT  VARCHAR2(19);
	ls_TO_BRANCH       VARCHAR2(9);
	ls_TO_HQ           VARCHAR2(9);
	ls_TO_NBACCOUNT    VARCHAR2(19);
	ls_TO_ACCOUNT      VARCHAR2(9);
	ls_TO_NAME         VARCHAR2(60);
	ls_TO_RNN          VARCHAR2(12);
	ls_TO_IRS          VARCHAR2(1);
	ls_TO_SECO         VARCHAR2(1);
	ls_DOC_NUM         VARCHAR2(10);
	ls_DOC_DATE        VARCHAR2(6);
	ls_DOC_SEND        VARCHAR2(2);
	ls_DOC_VO          VARCHAR2(2);
	ls_DOC_KNP         VARCHAR2(3);
	ls_DOC_PSO         VARCHAR2(2);
	ls_DOC_PRT         VARCHAR2(2);
	ls_DOC_BCLASS	   VARCHAR2(6);
	ls_DOC_ASSIGN      VARCHAR2(500);
	ls_DOC_OPV         VARCHAR2(17);
	ls_DOC_FM          VARCHAR2(60);
	ls_DOC_NM          VARCHAR2(60);
	ls_DOC_FT          VARCHAR2(60);
	ls_DOC_DT          VARCHAR2(8);
	ls_DOC_LA          VARCHAR2(9);
	ls_DOC_RNN         VARCHAR2(12);
	ls_DOC_FM2         VARCHAR2(60);
	ls_DOC_NM2         VARCHAR2(60);
	ls_DOC_FT2         VARCHAR2(60);
	ls_DOC_LA2         VARCHAR2(9);
	ls_DOC_RNN2        VARCHAR2(12);
	ls_DOC_PERIOD      VARCHAR2(6);

	ls_FILE_NAME       VARCHAR2(30);
	ls_TOTAL_TRAN_DATE VARCHAR2(6);
	ls_TOTAL_TRAN_CURR VARCHAR2(3);
	ln_TOTAL_TRAN_AMOUNT		   NUMBER;
	ln_SUM_TRAN_AMOUNT			   NUMBER:=0;

	cursor cursor_clearchk(ps_FIELD_59 varchar2) is
	   		  select *
			   from cbs_clearing_checklist
			   where FIELD_59 = ps_FIELD_59;

	row_clearchk	 cursor_clearchk%rowtype;
	ErrorPERIODException					 exception;
	ErrorCheckException						 exception;
	TotalTranSumWrong						 exception;
	InvalidBankCode							 exception;
	ls_check_error							 varchar2(500);
	ToBankCodeAccountError					 exception;

BEGIN

 	ls_filename:=ps_filename;
 	f:=utl_file.fopen(SCAN_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='SCAN';
	ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	--ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	--ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:='SCLEAR';--substr(ls_outstr,8,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=null;--substr(ls_outstr,5,16);
	ls_FIRST_HEADER:= '{1:F01K057880000000000000000}';
	ls_SECOND_HEADER:='{2:I102'|| ls_PAYMENT_TYPE || '000000U3003}';

	--:50:
	utl_file.get_line(f, ls_outstr);
	if substr(ls_outstr,1,4)=':50:' then
		LOOP
			if instr(ls_outstr,'/D/')>0 then
			   ls_DC_TYPE:='D';
			   ls_FROM_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'))));
			elsif instr(ls_outstr,'/C/')>0 then
			   ls_DC_TYPE:='C';
			   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_FROM_RNN:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/')))));
			elsif instr(ls_outstr,'/CHIEF/')>0 then
			   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
			elsif instr(ls_outstr,'/MAINBK/')>0 then
			   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_FROM_IRS:=substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_FROM_SECO:=substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'));
			end if;

			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--:50:

	if substr(ls_outstr,1,5)=':52B:' then
	   ls_FROM_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53B:' then
	   ls_FROM_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':53C:' then
	   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54B:' then
	   ls_TO_HQ:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':54C:' then
	   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;
	if substr(ls_outstr,1,5)=':57B:' then
	   ls_TO_BRANCH:=substr(ls_outstr,6);
	   utl_file.get_line(f, ls_outstr);
	end if;

	begin
		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;
	exception
	    when others then
			 raise InvalidBankCode;
	end;

	--:59:
	if substr(ls_outstr,1,4)=':59:' then
		LOOP
			if substr(ls_outstr,1,4)=':59:' then
			   ls_TO_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'))));
			elsif instr(ls_outstr,'/NAME/')>0 then
			   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
			   --TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')));
			elsif instr(ls_outstr,'/RNN/')>0 then
			   ls_TO_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
			elsif instr(ls_outstr,'/IRS/')>0 then
			   ls_TO_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
			elsif instr(ls_outstr,'/SECO/')>0 then
			   ls_TO_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
			end if;
			utl_file.get_line(f, ls_outstr);
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--59

	if pkg_hesap.Check_External_HesapNo(ls_TO_BRANCH,ls_TO_ACCOUNT)=0 then
	   raise ToBankCodeAccountError;
	end if;
	--:70:
	if substr(ls_outstr,1,4)=':70:' then
		LOOP

			if instr(ls_outstr,'/NUM/')>0 then
			   ls_DOC_NUM:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'))));
			elsif instr(ls_outstr,'/DATE/')>0 then
			   ls_DOC_DATE:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'))));
			elsif instr(ls_outstr,'/PERIOD/')>0 then
			   ls_DOC_PERIOD:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'))));
			elsif instr(ls_outstr,'/SEND/')>0 then
			   ls_DOC_SEND:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'))));
			elsif instr(ls_outstr,'/VO/')>0 then
			   ls_DOC_VO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'))));
			elsif instr(ls_outstr,'/KNP/')>0 then
			   ls_DOC_KNP:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'))));
			elsif instr(ls_outstr,'/PSO/')>0 then
			   ls_DOC_PSO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'))));
			elsif instr(ls_outstr,'/BCLASS/')>0 then
			   ls_DOC_BCLASS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'))));
			elsif instr(ls_outstr,'/PRT/')>0 then
			   ls_DOC_PRT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'))));
			elsif instr(ls_outstr,'/ASSIGN/')>0 then
			   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
			else
			   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
			end if;
			utl_file.get_line(f, ls_outstr);--:
			EXIT WHEN substr(ls_outstr,1,1)=':';
		END LOOP;
	end if;--70


    OPEN cursor_clearchk(ls_TO_ACCOUNT);
	FETCH cursor_clearchk INTO row_clearchk;
	if cursor_clearchk%FOUND then

	   if instr(row_clearchk.FIELD_57B,ls_TO_BRANCH)=0 or
		   	  instr(row_clearchk.FIELD_RNN,ls_TO_RNN)=0 or
			  instr(nvl(row_clearchk.FIELD_54C,NVL(ls_TO_NBACCOUNT,'-')),NVL(ls_TO_NBACCOUNT,'-'))=0 or
			  instr(row_clearchk.FIELD_KNP,ls_DOC_KNP)=0 then
	  	  raise ErrorCheckException;
	   end if;

	end if;
	CLOSE cursor_clearchk;

	--INSERT MASTER MSG
	insert into CBS_CLEARING_MESSAGES
	(MSG_ID, MSG_TYPE, MSG_KIND, FILE_NAME, PAYMENT_TYPE, MSG_REFERENCE, FIRST_HEADER, SECOND_HEADER)
	values
	(ln_MSG_ID, ls_MSG_TYPE, ls_MSG_KIND, ls_FILE_NAME, ls_PAYMENT_TYPE, ls_MSG_REFERENCE, ls_FIRST_HEADER, ls_SECOND_HEADER);

	while substr(ls_outstr,1,4)=':21:'
	LOOP

		ls_DETAIL_ID:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':21:')+length(':21:'))));
		utl_file.get_line(f, ls_outstr);

		if substr(ls_outstr,1,5)=':32B:' then
		 	ls_TRAN_CURR:=substr(ls_outstr,6,3);
			ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,9),',','.'));
			ln_SUM_TRAN_AMOUNT:=ln_SUM_TRAN_AMOUNT+ln_TRAN_AMOUNT;
			utl_file.get_line(f, ls_outstr);
		end if;

		if substr(ls_outstr,1,4)=':50:' then
			LOOP
				if instr(ls_outstr,'/D/')>0 then
				   ls_DC_TYPE:='D';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/D/')+length('/D/'));
				elsif instr(ls_outstr,'/C/')>0 then
				   ls_DC_TYPE:='C';
				   ls_FROM_ACCOUNT:=substr(ls_outstr,instr(ls_outstr,'/C/')+length('/C/'));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_FROM_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				   --ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')))));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_FROM_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
				elsif instr(ls_outstr,'/CHIEF/')>0 then
				   ls_FROM_CHIEF:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/CHIEF/')+length('/CHIEF/')));
				elsif instr(ls_outstr,'/MAINBK/')>0 then
				   ls_FROM_MAINBK:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/MAINBK/')+length('/MAINBK/')));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_FROM_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_FROM_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
				end if;

				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--:50:

		if substr(ls_outstr,1,5)=':52B:' then
		   ls_FROM_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53B:' then
		   ls_FROM_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':53C:' then
		   ls_FROM_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54B:' then
		   ls_TO_HQ:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':54C:' then
		   ls_TO_NBACCOUNT:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;
		if substr(ls_outstr,1,5)=':57B:' then
		   ls_TO_BRANCH:=substr(ls_outstr,6);
		   utl_file.get_line(f, ls_outstr);
		end if;

		if ls_FROM_HQ is NULL then
		   ls_FROM_HQ:=pkg_hesap.GetBankHQ(ls_FROM_BRANCH);
		end if;
		if ls_TO_HQ is null then
		   ls_TO_HQ:=pkg_hesap.GetBankHQ(ls_TO_BRANCH);
		end if;

		--:59:
		if substr(ls_outstr,1,4)=':59:' then
			LOOP
				if substr(ls_outstr,1,4)=':59:' then
				   ls_TO_ACCOUNT:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,':59:')+length(':59:'))));
				elsif instr(ls_outstr,'/NAME/')>0 then
				   ls_TO_NAME:=TO_WIN(substr(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')),1,60));
				   --ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NAME/')+length('/NAME/')))));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_TO_RNN:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/'))));
				elsif instr(ls_outstr,'/IRS/')>0 then
				   ls_TO_IRS:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/IRS/')+length('/IRS/'))));
				elsif instr(ls_outstr,'/SECO/')>0 then
				   ls_TO_SECO:=ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/SECO/')+length('/SECO/'))));
				end if;
				utl_file.get_line(f, ls_outstr);
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--59

		--:70:
		if substr(ls_outstr,1,4)=':70:' then
			LOOP

				if instr(ls_outstr,'/OPV/')>0 then
				   ls_DOC_OPV:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'/OPV/')+length('/OPV/')))));
				elsif instr(ls_outstr,'//FM/')>0 then
				   ls_DOC_FM:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'//FM/')+length('//FM/')))));
				elsif instr(ls_outstr,'//NM/')>0 then
				   ls_DOC_NM:=TO_WIN(ltrim(rtrim(substr(ls_outstr,instr(ls_outstr,'//NM/')+length('//NM/')))));
				elsif instr(ls_outstr,'//FT/')>0 then
				   ls_DOC_FT:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//FT/')+length('//FT/')));
				elsif instr(ls_outstr,'//DT/')>0 then
				   ls_DOC_DT:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'//DT/')+length('//DT/')))));
				elsif instr(ls_outstr,'//LA/')>0 then
				   ls_DOC_LA:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'//LA/')+length('//LA/')));
				elsif instr(ls_outstr,'//RNN/')>0 then
				   ls_DOC_RNN:=ltrim(rtrim(TO_WIN(substr(ls_outstr,instr(ls_outstr,'//RNN/')+length('//RNN/')))));
				elsif instr(ls_outstr,'/FM/')>0 then
				   ls_DOC_FM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FM/')+length('/FM/')));
				elsif instr(ls_outstr,'/NM/')>0 then
				   ls_DOC_NM2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/NM/')+length('/NM/')));
				elsif instr(ls_outstr,'/FT/')>0 then
				   ls_DOC_FT2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/FT/')+length('/FT/')));
				elsif instr(ls_outstr,'/LA/')>0 then
				   ls_DOC_LA2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/LA/')+length('/LA/')));
				elsif instr(ls_outstr,'/RNN/')>0 then
				   ls_DOC_RNN2:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/RNN/')+length('/RNN/')));
				elsif instr(ls_outstr,'/NUM/')>0 then
				   ls_DOC_NUM:=TO_WIN(rtrim(substr(ls_outstr,instr(ls_outstr,'/NUM/')+length('/NUM/'))));
				elsif instr(ls_outstr,'/DATE/')>0 then
				   ls_DOC_DATE:=substr(ls_outstr,instr(ls_outstr,'/DATE/')+length('/DATE/'));
				elsif instr(ls_outstr,'/SEND/')>0 then
				   ls_DOC_SEND:=substr(ls_outstr,instr(ls_outstr,'/SEND/')+length('/SEND/'));
				elsif instr(ls_outstr,'/VO/')>0 then
				   ls_DOC_VO:=substr(ls_outstr,instr(ls_outstr,'/VO/')+length('/VO/'));
				elsif instr(ls_outstr,'/KNP/')>0 then
				   ls_DOC_KNP:=substr(ls_outstr,instr(ls_outstr,'/KNP/')+length('/KNP/'));
				elsif instr(ls_outstr,'/PSO/')>0 then
				   ls_DOC_PSO:=substr(ls_outstr,instr(ls_outstr,'/PSO/')+length('/PSO/'));
				elsif instr(ls_outstr,'/BCLASS/')>0 then
				   ls_DOC_BCLASS:=substr(ls_outstr,instr(ls_outstr,'/BCLASS/')+length('/BCLASS/'));
				elsif instr(ls_outstr,'/PRT/')>0 then
				   ls_DOC_PRT:=substr(ls_outstr,instr(ls_outstr,'/PRT/')+length('/PRT/'));
				elsif instr(ls_outstr,'/PERIOD/')>0 then
				   ls_DOC_PERIOD:=substr(ls_outstr,instr(ls_outstr,'/PERIOD/')+length('/PERIOD/'));
				elsif instr(ls_outstr,'/ASSIGN/')>0 then
				   ls_DOC_ASSIGN:=TO_WIN(substr(ls_outstr,instr(ls_outstr,'/ASSIGN/')+length('/ASSIGN/')));
				else
				   ls_DOC_ASSIGN:=ls_DOC_ASSIGN || ' ' || TO_WIN(ls_outstr);
				end if;
				--log_at(11,ls_filename,ls_DETAIL_ID,ls_outstr);

				utl_file.get_line(f, ls_outstr);--:
				EXIT WHEN substr(ls_outstr,1,1)=':';
			END LOOP;
		end if;--70

		if ls_DOC_PERIOD is not null then
		   if length(ls_DOC_PERIOD)<>6 then
		   	  raise ErrorPERIODException;
		   end if;
		end if;


		if length(ls_DOC_NUM)>9 then
		   ls_DOC_NUM:=substr(ls_DOC_NUM,2,9);
		end if;

		--INSERT THE DETAIL	MSG
		insert into cbs_clearing_messages_detail
		(MSG_ID, DETAIL_ID, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT, DC_TYPE, FROM_ACCOUNT, FROM_NAME, FROM_RNN,
		FROM_CHIEF, FROM_MAINBK, FROM_IRS, FROM_SECO, FROM_BRANCH, FROM_HQ, FROM_NBACCOUNT,
		TO_BRANCH, TO_HQ, TO_NBACCOUNT, TO_ACCOUNT, TO_NAME, TO_RNN, TO_IRS, TO_SECO, DOC_NUM,
		DOC_DATE, DOC_SEND, DOC_VO, DOC_KNP, DOC_PSO, DOC_BCLASS, DOC_PRT, DOC_ASSIGN,DOC_OPV, DOC_FM, DOC_NM,
		DOC_FT, DOC_DT, DOC_LA, DOC_RNN, DOC_FM2, DOC_NM2, DOC_FT2, DOC_LA2, DOC_RNN2,DOC_PERIOD)
		values
		(ln_MSG_ID, ls_DETAIL_ID, ls_TRAN_DATE, ls_TRAN_CURR, ln_TRAN_AMOUNT, ls_DC_TYPE, ls_FROM_ACCOUNT,
		ls_FROM_NAME, ls_FROM_RNN, ls_FROM_CHIEF, ls_FROM_MAINBK,ls_FROM_IRS, ls_FROM_SECO, nvl(ls_FROM_BRANCH,ls_FROM_HQ),
		ls_FROM_HQ, ls_FROM_NBACCOUNT, ls_TO_BRANCH, ls_TO_HQ, ls_TO_NBACCOUNT,
		ls_TO_ACCOUNT, ls_TO_NAME, ls_TO_RNN, ls_TO_IRS, ls_TO_SECO, ls_DOC_NUM, ls_DOC_DATE, ls_DOC_SEND,
		ls_DOC_VO, ls_DOC_KNP,ls_DOC_PSO, ls_DOC_BCLASS, ls_DOC_PRT, ls_DOC_ASSIGN,ls_DOC_OPV,ls_DOC_FM,ls_DOC_NM,
		ls_DOC_FT,	ls_DOC_DT,	ls_DOC_LA,	ls_DOC_RNN,	ls_DOC_FM2,	ls_DOC_NM2,	ls_DOC_FT2,	ls_DOC_LA2,ls_DOC_RNN2,ls_DOC_PERIOD);

		ls_DOC_FM:=null;
		ls_DOC_NM:=null;
		ls_DOC_FT:=null;
		ls_DOC_DT:=null;
		ls_DOC_LA:=null;
		ls_DOC_RNN:=null;
		ls_DOC_FM2:=null;
		ls_DOC_NM2:=null;
		ls_DOC_FT2:=null;

	END LOOP;--:21:

	if substr(ls_outstr,1,5)=':32A:' then
	    ls_TOTAL_TRAN_DATE:=substr(ls_outstr,6,6);
	 	ls_TOTAL_TRAN_CURR:=substr(ls_outstr,12,3);
		ln_TOTAL_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,15),',','.'));
		if ln_SUM_TRAN_AMOUNT!=ln_TOTAL_TRAN_AMOUNT then
		   raise TotalTranSumWrong;
		end if;
		utl_file.get_line(f, ls_outstr);
	end if;

	--UPDATE THE TOTAL AMOUNT--ls_TOTAL_TRAN_DATE,
	update cbs_clearing_messages
	set TOTAL_TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD'),
	 	TOTAL_TRAN_CURR=ls_TOTAL_TRAN_CURR,
		TOTAL_TRAN_AMOUNT=ln_TOTAL_TRAN_AMOUNT
	where
		MSG_ID=ln_MSG_ID;

	update cbs_clearing_messages_detail
	set TRAN_DATE=to_char(pkg_muhasebe.Banka_Tarihi_Bul,'YYMMDD')
	where
		MSG_ID=ln_MSG_ID;


	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);


	 RETURN '000';

EXCEPTION
	 when ErrorPERIODException then
	 	  ROLLBACK;
		  ls_check_error:=ls_DOC_PERIOD;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100, 'PERIOD is wrong or missing. PERIOD:'|| ls_check_error || chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13) ||' File Name:'|| TO_WIN(ls_filename));
	 	  RETURN '998';
	 when ErrorCheckException then
	 	  ROLLBACK;
  		  ls_check_error:=ls_TO_ACCOUNT || ':' || chr(10)||chr(13) || row_clearchk.FIELD_57B ||'='||ls_TO_BRANCH || chr(10)||chr(13) ||
			               row_clearchk.FIELD_RNN || '=' || ls_TO_RNN  || chr(10)||chr(13) ||
						   nvl(row_clearchk.FIELD_54C,NVL(ls_TO_NBACCOUNT,'-')) || '=' || NVL(ls_TO_NBACCOUNT,'-') || chr(10)||chr(13) ||
						   row_clearchk.FIELD_KNP || '=' || ls_DOC_KNP || chr(10)||chr(13);
		  utl_file.fclose(f);
		  Raise_application_error(-20100,'MT102 Checklist Does not match.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '997';
	 when TotalTranSumWrong then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ln_SUM_TRAN_AMOUNT) || '!=' || to_char(ln_TOTAL_TRAN_AMOUNT) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'MT102 Sum of Payments NOT equal to 32A Amount.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '996';
	 when InvalidBankCode then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ls_FROM_BRANCH) || ' or ' || to_char(ls_TO_BRANCH) || ' not correct.' || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Invalid Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';
	 when ToBankCodeAccountError then
	 	  ROLLBACK;
 		  ls_check_error:=to_char(ls_TO_BRANCH) || ' not in ' || to_char(ls_TO_ACCOUNT) || chr(10)||chr(13);

	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Wrong Receiver Account No for the Bank Code.'||chr(10)||chr(13) || ls_check_error || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '994';
	 WHEN OTHERS THEN
	 	  ROLLBACK;
	 	  utl_file.fclose(f);
		  Raise_application_error(-20100,'Unknown Error.'||chr(10)||chr(13) || sqlerrm || chr(10)||chr(13) || ls_outstr || chr(10)||chr(13));
	 	  RETURN '995';
END;
--------------------------------------------------------------------------------------------------------------------
Function GetMT950Messages(ps_filename IN varchar2 default null)  RETURN VARCHAR2 IS
    f	  utl_file.file_type;
    ls_dirlist		varchar2(2000);
	ln_filecount	number;
	ln_fileindex	number;
	ls_filename	varchar2(20);

	ls_outstr		varchar2(2000);

	ln_MSG_ID          NUMBER;
	ls_DETAIL_ID       VARCHAR2(16):=1;
	ls_MSG_TYPE        VARCHAR2(10);
	ls_MSG_KIND        VARCHAR2(3);
	ls_FIRST_HEADER    VARCHAR2(200);
	ls_SECOND_HEADER   VARCHAR2(200);
	ls_PAYMENT_TYPE    VARCHAR2(200);
	ls_MSG_REFERENCE   VARCHAR2(16);
	--ls_CANCEL_REFERENCE   VARCHAR2(16);
	ls_IDENTIF_BANK_SCHET   VARCHAR2(19);
	ls_TRAN_DATE       VARCHAR2(6);
	ls_TRAN_CURR       VARCHAR2(3);
	ln_TRAN_AMOUNT     NUMBER;
    ls_DC_TYPE		   VARCHAR2(1);
	ls_MESSAGE               VARCHAR2(420);
	ls_TOTAL_TRAN_DATE         VARCHAR2(6);
	ls_TOTAL_TRAN_CURR         VARCHAR2(3);
	ls_MSG_CODE                VARCHAR2(7);
	ls_NUM_PAGE                VARCHAR2(5);
	ls_FINAL_DC_TYPE           VARCHAR2(1);
	ls_FINAL_TRAN_DATE         VARCHAR2(6);
	ls_FINAL_TRAN_CURR         VARCHAR2(3);
	ln_FINAL_TRAN_AMOUNT            NUMBER;
	ln_TOTAL_TRAN_AMOUNT		    NUMBER;
	ls_TRAN_TIME         	   VARCHAR2(4);
	ln_posid						number;
	ln_detailid						number:=1;
BEGIN

 	ls_filename:=ps_filename;
	f:=utl_file.fopen(OUTPUT_PATH, ls_filename, 'r',2100);

	ln_MSG_ID:=pkg_genel.genel_kod_al('CLEARING_MSGID');
	ls_MSG_TYPE:='INCOMING';
	--ls_FILE_NAME:=ls_filename;

	utl_file.get_line(f, ls_outstr);--{1:
	ls_FIRST_HEADER:=ls_outstr;
	utl_file.get_line(f, ls_outstr);--{2:
	ls_SECOND_HEADER:=ls_outstr;
	ls_MSG_KIND:=substr(ls_outstr,5,3);
	ls_PAYMENT_TYPE:=substr(ls_outstr,18,6);
	utl_file.get_line(f, ls_outstr);--{4:
	utl_file.get_line(f, ls_outstr);--:20:
	ls_MSG_REFERENCE:=substr(ls_outstr,5,16);
    utl_file.get_line(f, ls_outstr);--:23:
	ls_MSG_CODE:=substr(ls_outstr,5,7);

    utl_file.get_line(f, ls_outstr);--:25:
	ls_IDENTIF_BANK_SCHET:=substr(ls_outstr,5,19);
    utl_file.get_line(f, ls_outstr);--:28:
	ls_NUM_PAGE:=substr(ls_outstr,5,5);
 	utl_file.get_line(f, ls_outstr);--:60F:-62F
    ls_DC_TYPE:=substr(ls_outstr,6,1);
 	ls_TRAN_DATE:=substr(ls_outstr,7,6);
	ls_TRAN_CURR:=substr(ls_outstr,13,3);

	ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,16),',','.'));

	ln_posid:=pkg_genel.genel_kod_al('CLEARPOSID');
	insert into CBS_CLEARING_POS
	(POS_ID, TRAN_TYPE,POS_DATE, INITIAL_AMOUNT,CURRENCY_CD,DLM)
	values
	(ln_posid,ls_DC_TYPE,to_date(ls_TRAN_DATE,'YYMMDD'),ln_TRAN_AMOUNT,ls_TRAN_CURR,sysdate);

	utl_file.get_line(f, ls_outstr);--:61:
	if substr(ls_outstr,1,4)=':61:' then
		loop

		    ls_TRAN_TIME:=substr(ls_outstr,5,4);
			ls_DC_TYPE:=substr(ls_outstr,9,1);
			ls_TRAN_DATE:=substr(ls_outstr,10,6);
			ls_TRAN_CURR:=substr(ls_outstr,16,3);
			ln_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,19,instr(ls_outstr,'S')-19),',','.'));

			insert into CBS_CLEARING_POS_DETAIL
			(POS_ID, DETAIL_ID, TRAN_TIME, TRAN_TYPE, TRAN_DATE, TRAN_CURR, TRAN_AMOUNT)
			values
			(ln_posid,ln_detailid,ls_TRAN_TIME,ls_DC_TYPE,to_date(ls_TRAN_DATE,'YYMMDD'),ls_TRAN_CURR,ln_TRAN_AMOUNT);

			ln_detailid:=ln_detailid+1;

			utl_file.get_line(f, ls_outstr);--:61:
		exit when substr(ls_outstr,1,4)!=':61:';
		end loop;
	end if;

	--utl_file.get_line(f, ls_outstr);--:62F:
	if substr(ls_outstr,1,5)=':62F:' then
        ls_FINAL_DC_TYPE:=substr(ls_outstr,6,1);
	 	ls_FINAL_TRAN_DATE:=substr(ls_outstr,7,6);
		ls_FINAL_TRAN_CURR:=substr(ls_outstr,13,3);
		ln_FINAL_TRAN_AMOUNT:=to_number(replace(substr(ls_outstr,16),',','.'));
    end if;

	update CBS_CLEARING_POS
	set FINAL_AMOUNT=ln_FINAL_TRAN_AMOUNT
	where POS_ID=ln_posid;

	utl_file.fclose(f);

	--move message to backup folder
	--utl_file.frename(OUTPUT_PATH, ls_filename,INPUT_PATH, ls_filename);

	 RETURN '000';

EXCEPTION
	 WHEN OTHERS THEN
	 	  utl_file.fclose(f);
		  log_at('READ940ALLFILES',sqlerrm);
	 	  RETURN '99' || sqlerrm;
END;
-------------------------------------------------------------------------------------------------------------
Function SendMT920Message(pn_mesgid in NUMBER) RETURN VARCHAR2 IS

    cursor cursor_clear is
	   		  select *
			   from cbs_clearing_messages
			   where MSG_ID = pn_mesgid;

	row_clear	 cursor_clear%rowtype;


   f utl_file.file_type;
   ls_returncode varchar2(3):='000';
   ln_reasonlength					number;
   ln_index number:=1;
begin

  	OPEN cursor_clear;
	FETCH cursor_clear INTO row_clear;
	CLOSE cursor_clear;


	f:=pkg_message.OpenFile(row_clear.FILE_NAME,'w');
    ls_returncode:=pkg_message.WriteLine(f,row_clear.FIRST_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,row_clear.SECOND_HEADER);
	ls_returncode:=pkg_message.WriteLine(f,'{4:');
	ls_returncode:=pkg_message.WriteLine(f,':20:'||row_clear.MSG_REFERENCE);
	ls_returncode:=pkg_message.WriteLine(f,':12:950');
	ls_returncode:=pkg_message.WriteLine(f,':25:190201125/700161588');
	ls_returncode:=pkg_message.WriteLine(f,':30:' || row_clear.TOTAL_TRAN_DATE);
	ls_returncode:=pkg_message.WriteLine(f,'-}');
	ls_returncode:=pkg_message.CloseFile(f);

	return ls_returncode;

End;
--------------------------------------------------------------------------------------------------------------
END;
/

