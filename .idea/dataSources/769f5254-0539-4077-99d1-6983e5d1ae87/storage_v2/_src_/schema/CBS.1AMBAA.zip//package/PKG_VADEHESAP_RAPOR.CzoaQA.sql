create PACKAGE     PKG_VADEHESAP_RAPOR is

/******************************************************************************
   NAME       : PKG_VADEHESAP_RAPOR
   Created By : Seval Balci
   Date          : 12.03.04
   Purpose      :Vadeli vadesiz hesap rapor fonk. icerir.
******************************************************************************/
/* ay yil sonu vadeli faiz listesi*/
 PROCEDURE vadeli_ayyilsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
/* gun sonu 2. faiz hesaplamas?ndan sonra ?al??t?r?lmal?d?r.*/
 Procedure vadeli_gunsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);

/* ay yil sonu vadesiz faiz listesi*/
 PROCEDURE vadesiz_ayyilsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);
/* gun sonu 2. faiz hesaplamas?ndan sonra ?al??t?r?lmal?d?r.*/
 Procedure vadesiz_gunsonu_faiz_raporu( pn_GRUP_NO number default 0, pn_LOG_NO number default 0 ,pd_date date default pkg_muhasebe.banka_tarihi_bul);

 /* hesap ekstre ,hareket izleme ekranlar?da kullan?l?r*/
 function sf_hesap_turu_al ( pn_hesap_no number) return varchar2;
 function sf_musteri_vergino_al (pn_hesap_no number) return varchar2;
 function sf_devirbakiyebul (pn_hesap_no number ,pd_baslangic_tarihi varchar2) return number ;
 function sf_devirbakiyebul_lc (pn_hesap_no number ,pd_baslangic_tarihi varchar2, type_no number) return number ;
 /* vadesiz adat izleme*/
 Function sf_faizorani_degistimi(pn_tx_no number ,pn_hesap_no number,pn_faiz_orani number) return varchar2;
 Function sf_valbakiye_al(pn_hesap_no number ,pd_bakiye_tarih date) return number;
 Function Sf_Hesap_UrunUygunmu( ps_urun_tur_kod cbs_hesap_kredi.urun_tur_kod%type ) return varchar2;
 function sf_prevhareket_tarihi (pn_hesap_no number ,pd_baslangic_tarihi varchar2) return varchar2;
 PROCEDURE UpdatePreviousHistory(pd_date IN DATE) ;

 FUNCTION vadesiz_bakiye_karakter_dknoal(pn_hesap_no NUMBER,pd_tarih  DATE  )RETURN VARCHAR2;
 FUNCTION sf_birikmisfaiz_al(pn_hesap_no NUMBER ,pd_tarih DATE) RETURN NUMBER;
 FUNCTION guncel_faiz_orani(pn_hesap_no NUMBER) RETURN NUMBER;
 FUNCTION guncel_faiz_tutari(pn_hesap_no NUMBER) RETURN NUMBER;
 FUNCTION vadesiz_bakiye_KMH_DKMI(pn_hesap_no NUMBER,pd_tarih  DATE  )RETURN VARCHAR2 ;
----------------------------------------------------------------------------------------------------
-- Asag?daki fonksiyonlar RAP08 Musteri Hesap Gunluk Bakiye Raporu icin eklenmistir.
----------------------------------------------------------------------------------------------------
 FUNCTION  gunluk_dk_bakiye_al(ps_numara VARCHAR2,ps_bolum_kodu VARCHAR2,ps_doviz_kodu varchar2,pd_tarih date default pkg_muhasebe.banka_tarihi_bul ) RETURN NUMBER;
 FUNCTION  gunluk_musteri_bakiye_al(pn_hesapno NUMBER ,pd_tarih date default pkg_muhasebe.banka_tarihi_bul ) RETURN NUMBER;
 FUNCTION  oncekiay_ortalama_bakiye_al(pn_hesapno NUMBER ,pd_tarih date default pkg_muhasebe.banka_tarihi_bul ) RETURN NUMBER;
 FUNCTION  bakiye_karakteri_al(pn_hesapno NUMBER  ) RETURN varchar2;

function musteri_vergino_al_dairesiz (pn_hesap_no number) return varchar2;
function sf_bakiyebul_statement (pn_hesap_no number ,pd_baslangic_tarihi varchar2) return number;
function ekstre_no_bul(pn_hesap_no number ,pd_date date) return number;
function ekstre_basilacak(pn_hesap_no number, pd_date date) return varchar2;
function ekstre_bas_donem(pn_hesap_no number ,pd_date date) return varchar2;
function ekstre_bas_tarih(pn_hesap_no number ,pd_date date) return date;
function ekstre_no_bul_yeni(pn_hesap_no number ,pd_date date) return number;
function ekstre_bas_donem_yeni(pn_hesap_no number ,pd_date date) return varchar2;
End ;

/

