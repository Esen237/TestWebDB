create PACKAGE BODY     PKG_TX1309 IS
	pn_1309_fon_hesap_no        		  number;
	pn_1309_kredi_doviz        			  number;
	pn_1309_banka_aciklama        		  number;
	pn_1309_iliskili_hesap_sube        	  number;
	pn_1309_iliskili_hesap_no        	  number;
	pn_1309_faiz_hesap_sube        		  number;
	pn_1309_faiz_hesap_no        		  number;
	pn_1309_fon_hesap_sube        	  number;
	pn_1309_musteri_aciklama        	  number;
	pn_1309_iliskili_komreesdk        	  number;
	pn_1309_iliskili_faizreesdk        	  number;
	pn_1309_iliskili_komdk        		  number;
	pn_1309_iliskili_faizdk        		  number;
	pn_1309_kredi_hesap_sube        	  number;
	pn_1309_kredi_hesap_no        		  number;
	pn_1309_iliskili_hesap_doviz          number;
	pn_1309_referans        			  number;
	pn_1309_fis_aciklama        		  number;
	pn_1309_islem_sube        			  number;
	pn_1309_kur        					  number;
	pn_1309_anapara_tahsil_toplam         number;
	pn_1309_anapara_tahsil_sonisl         number;
	pn_1309_alis_kur        			  number;
	pn_1309_son_islem_kur        		  number;
	pn_1309_fa_gecyil_komzarar        	  number;
	pn_1309_fa_gecyil_komgelir        	  number;
	pn_1309_fa_gecyil_faizzarar        	  number;
	pn_1309_fa_gecyil_faizgelir        	  number;
	pn_1309_fa_toplam_kkdf        		  number;
	pn_1309_fa_toplam_bsmv        		  number;
	pn_1309_tahsil_gecyilkom        	  number;
	pn_1309_tahsil_gecyilfaiz        	  number;
	pn_1309_tahsil_faizfark        		  number;
	pn_1309_tahsil_fonvergi        		  number;
	pn_1309_tahsil_faizkom         		  number;
	pn_1309_toplam_tahsiledil        	  number;
	pn_1309_anapara_fark_3        	 	  number;
	pn_1309_anapara_fark_2        		  number;
	pn_1309_anapara_tahsil_ekrkur   	  number;
	pn_1309_gecyil_kurfark       	 	  number;
	pn_1309_anapara_fark        		  number;
	pn_1309_kkdf_tutar        			  number;
	pn_1309_bsmv_tutar        			  number;
	pn_1309_tahsil_komfark        		  number;
	pn_1309_ekrankur_buyukse        	  number;
	pn_1309_komis_gelir        			  number;
	pn_1309_komis_zarar        			  number;
	pn_1309_faiz_zarari        			  number;
	pn_1309_gecenyil_gelir        		  number;
	pn_1309_ekrankur_kucuk        		  number;
	pn_1309_faiz_gelir        			  number;
	pn_1309_gecenyil_zarar        		  number;
	pn_1309_valor_tarihi        		  number;
	pn_1309_anapara_var					  number;
	pn_1309_anapara_bdak_tutar			  number;
	pn_1309_anapara_tutar				  number;
	pn_1309_bdak_kur					  number;
	pn_1309_endeks_doviz				  number;

/*290504*/
	pn_1309_gecenyilbdak_sch_tl        number;
	pn_1309_birikmis_sch_acilis_tl        	   number;

  Procedure Kontrol_Sonrasi(pn_islem_no number) is
   ln_kredi_teklif_satir_numara			 number;
   ln_kredi_hesap_tutar  				 number;
   ls_kredi_hesap_doviz_kodu  			 cbs_doviz_kodlari.doviz_kodu%type;
   iliskili_faizrees_dk_yok   			 exception;
   iliskili_kom_dk_yok   	   			 exception;
   iliskili_komrees_dk_yok    			 exception;
   ln_faiz_orani						 number;
   ln_komisyon_orani					 number;
   ls_dk_grup_kod			             cbs_musteri.DK_GRUP_KOD%type;
   ls_modul_tur_kod			             cbs_hesap.modul_tur_kod%type;
   ls_urun_tur_kod			             cbs_hesap.urun_tur_kod%type;
   ls_urun_sinif_kod		             cbs_hesap.urun_sinif_kod%type;
   ls_komreesdk  				         varchar2(2000);
   ls_faizreesdk      		             varchar2(2000);
   ls_hesap_no				             cbs_hesap_kredi.hesap_no%type;
   ls_endeks_doviz_kodu					 cbs_doviz_kodlari.doviz_kodu%type;
  Begin

   select kredi_teklif_satir_numara,
   		  b.tutar,
		  a.doviz_kodu,
		  a.faiz_orani,
		  a.komisyon_orani,
	      pkg_musteri.sf_musteri_dk_grup_kod_al(a.musteri_no),
	      a.modul_tur_kod,
 		  a.urun_tur_kod,
		  a.urun_sinif_kod,
		  endeks_doviz_kodu
   into   ln_kredi_teklif_satir_numara,
   		  ln_kredi_hesap_tutar,
          ls_kredi_hesap_doviz_kodu,
		  ln_faiz_orani,
		  ln_komisyon_orani,
		  ls_dk_grup_kod,
	      ls_modul_tur_kod,
 		  ls_urun_tur_kod,
		  ls_urun_sinif_kod,
		  ls_endeks_doviz_kodu
   from cbs_hesap_kredi_islem a,cbs_islem b
   where tx_no = pn_islem_no and
   		 a.tx_no = b.numara;

  pkg_kredi.sp_kredteklifdurumu_uygunmu(pn_islem_no);

 pkg_teminat.sp_teminat_kontrolsonra(pn_islem_no ,
  			 ln_kredi_teklif_satir_numara ,
			 ln_kredi_hesap_tutar,
             ls_kredi_hesap_doviz_kodu ,
			 ls_endeks_doviz_kodu );


   pkg_tx1303.sp_tahakkuk_dk_tanimlimi(pn_islem_no );
   pkg_kredi.sp_faizkom_dk_tanimlimi(pn_islem_no);

/*faiz reeskont dk */
 if nvl(ln_faiz_orani,0) <> 0  then

 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
 					   null,null, null,ls_faizreesdk);
	  if 	ls_faizreesdk is null then
	  		raise iliskili_faizrees_dk_yok;
	  end if;

end if;


 if nvl(ln_komisyon_orani,0) <> 0 then
/*komisyon reeskont dk */
 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 6,
 					   null,null, null,ls_komreesdk);

	  if 	ls_komreesdk is null then
	  		raise iliskili_komrees_dk_yok;
	  end if;
 end if;

  sp_kontrol_sonrasi_rezervasyon(pn_islem_no);
 Exception
 When iliskili_komrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter || ls_hesap_no || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   		   When iliskili_faizrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter ||ls_hesap_no || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);

 End;

  Procedure Dogrulama_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Dogrulama_Iptal_Sonrasi(pn_islem_no number) is
  Begin
   /* teminat islem durum guncellenir */
	pkg_teminat.sp_teminat_dogrulamaiptalsonra(pn_islem_no);
  	pkg_kur_rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);

  End;

  Procedure Iptal_Reddetme_Sonrasi(pn_islem_no number) is
  Begin
  	   NULL;
  End;

  Procedure Iptal_Sonrasi(pn_islem_no number) is
  Begin
    NULL;
  End;

  Procedure sp_onayoncesi_kurtutarguncelle(pn_islem_no number)
  is
   ln_hesap_no 	cbs_hesap_kredi.hesap_no%type;
   ln_rezervasyon_no 		number;
   ls_doviz_kodu	 		cbs_hesap_kredi.doviz_kodu%type;
   ls_endeks_doviz			cbs_hesap_kredi.doviz_kodu%type;
   ln_kur   number;
   ln_fark_kur	   number := 0;
   ln_gecenyil_faiz_kkdf_tutari number;
   ln_gecenyil_faiz_bsmv_tutari number;
   ln_gecenyil_kom_bsmv_tutari  number;
   ln_ANAPARA_KKDF_TUTARI  		NUMBER;
   ln_ANAPARA_BSMV_TUTARI		NUMBER;
   ln_toplam_faiz_kkdf_tutari   NUMBER;
   ln_toplam_faiz_BSMV_tutari   NUMBER;
   ln_toplam_kom_bsmv_tutari  number;
  cursor cursor_islem is
  select
  		hesap_no,
   		rezervasyon_no,
		doviz_kodu,
		endeks_doviz_kodu,
		acilis_kuru,
		kkdf_alinsin,
		bsmv_alinsin,
		kur,
		son_islem_kuru,
		abs(nvl(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0))  TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,
		abs(nvl(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0)) TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,
		abs(nvl(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0))  TAHSEDIL_GECENYIL_FAIZ_TUTARI,
		abs(nvl(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0)) TAHSEDIL_GECENYIL_KOMIS_TUTARI,
		abs(nvl(TAHSILEDILECEK_TAHAKKUK_FAIZ,0))   TAHSILEDILECEK_TAHAKKUK_FAIZ,
		abs(nvl(TAHSILEDILECEK_TAHAKKUK_VERGI,0))  TAHSILEDILECEK_TAHAKKUK_VERGI,
		abs(nvl(ANAPARA_TAHSILAT_TUTAR,0))		   ANAPARA_TAHSILAT_TUTAR,
		nvl(endeks_doviz_tutari,0)   ln_bakiye

  from cbs_hesap_kredi_islem
  where tx_no = pn_islem_no;

  ln_bakiye number :=0 ;

  Begin
	   for cur_islem in cursor_islem loop


	   	   ln_rezervasyon_no := cur_islem.rezervasyon_no;
	   	   ls_endeks_doviz := cur_islem.ENDEKS_DOVIZ_KODU;

		      if nvl(ln_rezervasyon_no,0) = 0 then
		  		  	ln_kur:=pkg_kur.doviz_doviz_karsilik(ls_endeks_doviz ,pkg_genel.lc_al,null,1,1,null,null,'O','A');
		  	 end if;

				 IF nvl(cur_islem.SON_ISLEM_KURU,0) < ln_kur THEN
		    	 	ln_fark_kur :=  abs(nvl(ln_kur,0)  - nvl(cur_islem.SON_ISLEM_KURU,0));
					   if ln_fark_kur > 0  and  nvl(cur_islem.ANAPARA_TAHSILAT_TUTAR,0) <> 0  then  /*gelir*/
		 					ln_ANAPARA_KKDF_TUTARI:= NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',cur_islem.DOVIZ_KODU,  cur_islem.HESAP_NO, ln_bakiye, ln_fark_kur , 'H', cur_islem.KKDF_ALINSIN, cur_islem.BSMV_ALINSIN ),0);
			  	   	    	ln_ANAPARA_BSMV_TUTARI:= NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',cur_islem.DOVIZ_KODU,  cur_islem.HESAP_NO,ln_bakiye, ln_fark_kur , 'H', cur_islem.KKDF_ALINSIN, cur_islem.BSMV_ALINSIN ),0);
					  else
					 	 ln_ANAPARA_KKDF_TUTARI := 0;
					 	 ln_ANAPARA_BSMV_TUTARI := 0;
					 end if;
			   	 end if;
				ln_toplam_faiz_kkdf_tutari := NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',cur_islem.DOVIZ_KODU, cur_islem.HESAP_NO, (cur_islem.TAHSEDIL_BIRIKMIS_FAIZ_TUTARI +cur_islem.TAHSEDIL_GECENYIL_FAIZ_TUTARI ) /cur_islem.ACILIS_KURU, ln_KUR, 'E', cur_islem.KKDF_ALINSIN, cur_islem.BSMV_ALINSIN ),0) + NVL(ln_ANAPARA_KKDF_TUTARI,0);
				ln_toplam_faiz_bsmv_tutari := NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',cur_islem.DOVIZ_KODU, cur_islem.HESAP_NO, (cur_islem.TAHSEDIL_BIRIKMIS_FAIZ_TUTARI +cur_islem.TAHSEDIL_GECENYIL_FAIZ_TUTARI ) /cur_islem.ACILIS_KURU, ln_KUR, 'E', cur_islem.KKDF_ALINSIN, cur_islem.BSMV_ALINSIN ),0) + NVL(ln_ANAPARA_KKDF_TUTARI,0);
				ln_toplam_kom_bsmv_tutari := NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',cur_islem.DOVIZ_KODU, cur_islem.HESAP_NO, (cur_islem.TAHSEDIL_BIRIKMIS_KOMIS_TUTARI +cur_islem.TAHSEDIL_GECENYIL_KOMIS_TUTARI ) /cur_islem.ACILIS_KURU, ln_KUR, 'E', cur_islem.KKDF_ALINSIN, cur_islem.BSMV_ALINSIN ),0);

	    end loop;

	    if nvl(ln_rezervasyon_no,0) = 0 then
			 update cbs_hesap_kredi_islem
			  set kur  =ln_kur,
				  birikmis_faiz_kkdf_tutari = ln_toplam_faiz_kkdf_tutari ,
				  birikmis_faiz_bsmv_tutari = ln_toplam_faiz_bsmv_tutari,
				  birikmis_kom_bsmv_tutari  = ln_toplam_kom_bsmv_tutari,
				  ANAPARA_KKDF_TUTARI  = ln_ANAPARA_KKDF_TUTARI,
				  ANAPARA_BSMV_TUTARI =ln_ANAPARA_BSMV_TUTARI
				where tx_no = pn_islem_no;

	   end if;

  end;

  Procedure Onay_Sonrasi(pn_islem_no number)
  is
   ln_hesap_no    cbs_hesap_kredi.hesap_no%type ;
   ls_doviz_kodu  cbs_hesap_kredi.doviz_kodu%type;
   ls_geriodeme_kapama_secimi	 cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
   Begin
   		select hesap_no,
  		       doviz_kodu,
   			   geriodeme_kapama_secimi
  		 into ln_hesap_no,
 	   	 	  ls_doviz_kodu,
			  ls_geriodeme_kapama_secimi
	    from  cbs_hesap_kredi_islem
  		where tx_no = pn_islem_no;

     pkg_tx1309.sp_onayoncesi_kurtutarguncelle(pn_islem_no);
  /* teminat Durum guncellenir */
     pkg_teminat.sp_teminat_onay_sonrasi(pn_islem_no,ln_hesap_no, ls_doviz_kodu,ls_geriodeme_kapama_secimi	);

  End;

  Procedure Iptal_Onay_Sonrasi(pn_islem_no number) is
	  ls_durum_kodu cbs_hesap_kredi_islem.durum_kodu%type;
	  ln_hesap_no	cbs_hesap_kredi.hesap_no%type;
	  ln_tahsiledilen_faiz_tutari				 number :=0;
	  ln_tahsiledilen_komisyon_tutar			 number := 0;
	  ln_birikmis_faiz_tutari					 number := 0;
	  ln_birikmis_komisyon_tutari				 number := 0;
	  ln_gecenyil_faiz_tutari					 number := 0;
	  ln_gecenyil_kom_tutari					 number := 0;
	  ln_son_islem_kuru							 number := 0;
	  ln_faiz_tahakkuk_hesap_no 				 cbs_hesap_kredi.hesap_No%type;
	  ln_vergi_tahakkuk_hesap_no 				 cbs_hesap_kredi.hesap_No%type;
	  ln_gecenyil_anaparakurfark_gel			 number := 0;
	  ln_gecenyil_anaparakurfark_zar 			 number := 0;
	  ln_gecenyil_faizkurfark_gelir				 number := 0;
	  ln_gecenyil_faizkurfark_zarar				 number := 0;
  	  ln_gecenyil_komiskurfark_gelir			 number := 0;
	  ln_gecenyil_komiskurfark_zarar	  		 number := 0;
	  ln_endeks_doviz_tutari			  		 number := 0;
	  ld_faiz_baslangic_tarihi					 date;
 	  ls_geriodeme_kapama_secimi				 cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
	  ln_tahakeden_sch_faiz_tutari 				 number := 0;
	  ln_gecenyil_sch_faiz_tutari				 number :=0;
	  ln_birikmis_sch_faiz_tutari				 number :=0;
	  ln_tahakkuk_sch_faiz_tutari				 number :=0;

    Begin

	 select durum_kodu ,
	 		hesap_no,
			tahsiledilen_faiz_tutari,
			tahsiledilen_komisyon_tutari,
			abs(nvl(kapamaoncesi_birikmisfaiztutar,0)),
			abs(nvl(kapamaoncesi_birikmiskomstutar,0)),
			abs(nvl(gecenyil_faiz_tutari,0)),
			abs(nvl(gecenyil_komisyon_tutari,0)),
			son_islem_kuru,
			faiz_tahakkuk_hesap_no ,
			vergi_tahakkuk_hesap_no,
			abs(nvl(gecenyil_anaparakurfark_gelir,0)),
			abs(nvl(gecenyil_anaparakurfark_zarar,0)),
			abs(nvl(gecenyil_faizkurfark_gelir,0)),
			abs(nvl(gecenyil_faizkurfark_zarar,0)),
			abs(nvl(gecenyil_komiskurfark_gelir,0)),
			abs(nvl(gecenyil_komiskurfark_zarar,0))	,
			abs(nvl(endeks_doviz_tutari,0)),
			kapamaonce_faizbaslangictarihi,
			geriodeme_kapama_secimi,
			birikmis_sch_faizi 	,
			gecenyil_sch_faizi	,
			tahakkuk_sch_faiz_tutari
	 into   ls_durum_kodu   ,
	 	    ln_hesap_No,
			ln_tahsiledilen_faiz_tutari,
			LN_tahsiledilen_komisyon_tutar,
			ln_birikmis_faiz_tutari,
			ln_birikmis_komisyon_tutari,
			ln_gecenyil_Faiz_tutari,
			ln_gecenyil_kom_tutari,
			ln_son_islem_kuru,
			ln_faiz_tahakkuk_hesap_no ,
			ln_vergi_tahakkuk_hesap_no,
			ln_gecenyil_anaparakurfark_gel,
			ln_gecenyil_anaparakurfark_zar,
			ln_gecenyil_faizkurfark_gelir,
			ln_gecenyil_faizkurfark_zarar,
			ln_gecenyil_komiskurfark_gelir,
			ln_gecenyil_komiskurfark_zarar,
			ln_endeks_doviz_tutari,
			ld_faiz_baslangic_tarihi,
			ls_geriodeme_kapama_secimi,
			ln_birikmis_sch_faiz_tutari,
			ln_gecenyil_sch_faiz_tutari,
			ln_tahakkuk_sch_faiz_tutari
	 from cbs_hesap_kredi_islem
	 where tx_no = pn_islem_no;

	   update cbs_hesap_kredi
	   set    kapanis_tarihi = null,
	   		  durum_kodu			 = 'A',
	   		  tahsiledilen_faiz_tutari    = ln_tahsiledilen_faiz_tutari,
			  tahsiledilen_komisyon_tutari= LN_tahsiledilen_komisyon_tutar,
			  birikmis_faiz_tutari		  = ln_birikmis_faiz_tutari ,
			  Birikmis_komisyon_tutari    = ln_birikmis_komisyon_tutari,
			  gecenyil_faiz_tutari        = ln_gecenyil_Faiz_tutari,
			  gecenyil_komisyon_tutari    = ln_gecenyil_kom_tutari,
			  son_islem_kuru = ln_son_islem_kuru,
			  gecenyil_anaparakurfark_gelir	= ln_gecenyil_anaparakurfark_gel,
			  gecenyil_anaparakurfark_zarar	= ln_gecenyil_anaparakurfark_zar,
			  gecenyil_faizkurfark_gelir	= ln_gecenyil_faizkurfark_gelir,
			  gecenyil_faizkurfark_zarar	= ln_gecenyil_faizkurfark_zarar,
			  gecenyil_komiskurfark_gelir	= ln_gecenyil_komiskurfark_gelir,
			  gecenyil_komiskurfark_zarar	= ln_gecenyil_komiskurfark_zarar,
			  endeks_doviz_tutari  			= ln_endeks_doviz_tutari,
			  faiz_baslangic_tarihi =		 ld_faiz_baslangic_tarihi,
/*290504*/
			  birikmis_sch_faizi 	= 		 ln_birikmis_sch_faiz_tutari,
			  gecenyil_sch_faizi	=		ln_gecenyil_sch_faiz_tutari,
			  tahakkuk_sch_faiz_tutari =   ln_tahakkuk_sch_faiz_tutari
	   where  hesap_no = ln_hesap_no;

	/*   kredi tahakkuk hesaplar? a??l?r */
	if ls_durum_kodu = 'K' then
		  update cbs_hesap_kredi
		  set  durum_kodu = 'A'
		  where hesap_no in(   ln_faiz_tahakkuk_hesap_no ,ln_vergi_tahakkuk_hesap_no);
	 end if;

  	pkg_teminat.sp_teminat_iptalonaysonrasi(pn_islem_no,ls_geriodeme_kapama_secimi	);
  	Pkg_Kur_rezervasyon.REZERVASYON_KULLANIM_IPTAL(pn_islem_no);
  End;


  Procedure Reddetme_Sonrasi(pn_islem_no number) is
  Begin

    update cbs_hesap_kredi_islem
	set durum_kodu = 'R'
	where tx_no = pn_islem_no;
	/* teminat islem Durum guncellenir */
	pkg_teminat.sp_teminat_reddetmesonrasi(pn_islem_no);
	pkg_kur_rezervasyon.rezervasyon_kullanim_iptal(pn_islem_no);
  End;

  Procedure Tamam_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure Basim_Sonrasi(pn_islem_no number) is
  Begin
  	Null;
  End;

  Procedure sp_muhasebesonrasi_guncelle(pn_islem_no number)
  is
	  ls_durum_kodu cbs_hesap_kredi_islem.durum_kodu%type;
	  ln_hesap_no	cbs_hesap_kredi.hesap_no%type;
	  ln_tahsiledilen_faiz_tutari				 number :=0;
	  ln_tahsiledilen_komisyon_tutar			 number := 0;
	  ln_tahsiledilen_birikmis_faiz				 number := 0;
	  ln_tahsiledilen_birikmis_kom				 number := 0;
	  ln_gecenyil_faiz_tutari					 number := 0;
	  ln_gecenyil_kom_tutari					 number := 0;
	  ln_anapara_Tahsilat_tutari				 number := 0;
	  ln_kur									 number := 0;
	  ln_son_islem_kuru							 number := 0;
	  ln_faiz_tahakkuk_hesap_no 				 cbs_hesap_kredi.hesap_No%type;
	  ln_vergi_tahakkuk_hesap_no 				 cbs_hesap_kredi.hesap_No%type;
	  ld_faiz_baslangic_tarihi					 date := null;
 	  ln_birikmis_faiz_tutari					 number := 0;
	  ln_birikmis_kom_tutari					 number := 0;
	  ln_tahakeden_sch_faiz_tutari 				 number := 0;
	  ln_gecenyil_sch_faiz_tutari				 number :=0;
	  ln_birikmis_sch_faiz_tutari				 number :=0;

	Begin
	 select durum_kodu ,
	 		hesap_no,
	 		abs(nvl(tahsedil_birikmis_faiz_tutari,0)) + abs( nvl(tahsedil_gecenyil_faiz_tutari,0)) +  abs(nvl(tahsiledilecek_tahakkuk_faiz,0)),
			abs(nvl(tahsedil_birikmis_komis_tutari,0)) + abs(nvl(tahsedil_gecenyil_komis_tutari,0)),
			abs(nvl(tahsedil_birikmis_faiz_tutari ,0)),
			abs(nvl(tahsedil_birikmis_komis_tutari ,0)),
			abs(nvl(tahsedil_gecenyil_faiz_tutari,0)),
			abs(nvl(tahsedil_gecenyil_komis_tutari,0)),
			abs(nvl(anapara_tahsilat_tutar,0)),
			nvl(son_islem_kuru,0),
			kur,
			faiz_tahakkuk_hesap_no,
			vergi_tahakkuk_hesap_no,
			DECODE(faiz_baslangic_tarihi,NULL,NULL, faiz_baslangic_tarihi + 1) faiz_baslangic_tarihi,
			abs(birikmis_faiz_tutari),
			abs(birikmis_komisyon_tutari),
		    abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, (GECENYIL_SCH_FAIZI / acilis_kuru )*(pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A')))) + --		number_list(pn_1309_gecenyilbdak_sch_tl),
			abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, (BIRIKMIS_SCH_FAIZI / acilis_kuru )*(pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A')))),--		number_list(pn_1309_birikmis_sch_acilis_tl),
			abs(nvl(GECENYIL_SCH_FAIZI,0)),
			abs(nvl(BIRIKMIS_SCH_FAIZI,0))
	 into   ls_durum_kodu   ,
	 	    ln_hesap_no,
			ln_tahsiledilen_faiz_tutari,
			ln_tahsiledilen_komisyon_tutar,
			ln_tahsiledilen_birikmis_faiz,
			ln_tahsiledilen_birikmis_kom,
			ln_gecenyil_faiz_tutari,
			ln_gecenyil_kom_tutari,
			ln_anapara_tahsilat_tutari,
			ln_son_islem_kuru,
			ln_kur,
			ln_faiz_tahakkuk_hesap_no ,
			ln_vergi_tahakkuk_hesap_no,
			ld_faiz_baslangic_tarihi,
			ln_birikmis_faiz_tutari,
			ln_birikmis_kom_tutari,
			ln_tahakeden_sch_faiz_tutari,
			ln_gecenyil_sch_faiz_tutari,
			ln_birikmis_sch_faiz_tutari
	 from cbs_hesap_kredi_islem
	 where tx_no = pn_islem_no;


	 if nvl(ln_anapara_tahsilat_tutari,0) >0 and ln_kur  > ln_son_islem_kuru then
	    ln_son_islem_kuru := ln_kur;
	end if;
/* 290504 subeler cari */

if (ls_durum_kodu != 'K' )  and
   (   abs(  nvl( ln_tahsiledilen_birikmis_faiz,0 )) + abs(nvl( ln_tahsiledilen_birikmis_kom ,0 )) = 0 ) then
			ln_tahakeden_sch_faiz_tutari := 0;
 else
 			ln_gecenyil_sch_faiz_tutari := 0;
			ln_birikmis_sch_faiz_tutari := 0;
 end if;


	   update cbs_hesap_kredi
	   set    durum_kodu = ls_durum_kodu,
	   		  kapanis_tarihi = decode(LS_Durum_kodu,'K',pkg_muhasebe.banka_tarihi_bul,null),
	   		  tahsiledilen_faiz_tutari    = abs(nvl(tahsiledilen_faiz_tutari,0)) + nvl(ln_tahsiledilen_faiz_tutari,0) ,
			  tahsiledilen_komisyon_tutari= abs(nvl(tahsiledilen_komisyon_tutari,0)) + nvl(LN_tahsiledilen_komisyon_tutar,0),
			  birikmis_faiz_tutari		  =  abs(decode(LS_Durum_kodu,'K',0,pkg_kur.yuvarla(doviz_kodu,ABS(nvl(ln_birikmis_faiz_tutari,0))) - ABS(nvl(ln_tahsiledilen_birikmis_faiz,0)))),
			  Birikmis_komisyon_tutari    =  abs(decode(LS_Durum_kodu,'K',0,pkg_kur.yuvarla(doviz_kodu,abs(nvl(ln_birikmis_kom_tutari,0))) - abs(nvl(ln_tahsiledilen_birikmis_kom,0)))),
			  gecenyil_faiz_tutari        =  abs(decode(LS_Durum_kodu,'K',0,ABS(nvl(gecenyil_faiz_tutari,0)) - ABS(nvl(ln_gecenyil_Faiz_tutari,0))))	,
			  gecenyil_komisyon_tutari    =  abs(decode(LS_Durum_kodu,'K',0,ABS(nvl(gecenyil_komisyon_tutari,0) - nvl(ln_gecenyil_kom_tutari,0)))),
			  son_islem_kuru			  =  ln_son_islem_kuru,
			  GECENYIL_ANAPARAKURFARK_GELIR	= abs(decode(LS_Durum_kodu,'K',0, decode(nvl(ln_anapara_tahsilat_tutari,0),0,abs(GECENYIL_ANAPARAKURFARK_GELIR),0))),
			  GECENYIL_ANAPARAKURFARK_ZARAR	= abs(decode(LS_Durum_kodu,'K',0,decode(nvl(ln_anapara_tahsilat_tutari,0),0,abs(GECENYIL_ANAPARAKURFARK_ZARAR),0))),
			  GECENYIL_FAIZKURFARK_GELIR	= abs(decode(LS_Durum_kodu,'K',0, decode(nvl(ln_gecenyil_faiz_tutari,0),0,abs(GECENYIL_FAIZKURFARK_GELIR),0))),
			  GECENYIL_FAIZKURFARK_ZARAR	= abs(decode(LS_Durum_kodu,'K',0,decode(nvl(ln_gecenyil_faiz_tutari,0),0,abs(GECENYIL_FAIZKURFARK_ZARAR),0))),
			  GECENYIL_KOMISKURFARK_GELIR	= abs(decode(LS_Durum_kodu,'K',0,decode(nvl(ln_gecenyil_kom_tutari,0),0,abs(GECENYIL_KOMISKURFARK_GELIR),0))),
			  GECENYIL_KOMISKURFARK_ZARAR	= abs(decode(LS_Durum_kodu,'K',0,decode(nvl(ln_gecenyil_kom_tutari,0),0,abs(GECENYIL_KOMISKURFARK_ZARAR),0))),
			  ENDEKS_DOVIZ_TUTARI  = abs(ABS(ENDEKS_DOVIZ_TUTARI) - ABS(nvl(ln_anapara_tahsilat_tutari,0))),
			  faiz_baslangic_tarihi = nvl(ld_faiz_baslangic_tarihi ,faiz_baslangic_tarihi),
/*090504*/	  gecenyil_sch_faizi = ln_gecenyil_sch_faiz_tutari,
		  	  birikmis_sch_faizi =ln_birikmis_sch_faiz_tutari,
			  tahakkuk_sch_faiz_tutari  = abs(nvl(  tahakkuk_sch_faiz_tutari ,0))+ln_tahakeden_sch_faiz_tutari
	   where  hesap_no = ln_hesap_no;

/*   kredi tahakkuk hesaplar? kapat?l?r */
    if ls_durum_kodu = 'K' then
  	  update cbs_hesap_kredi
	  set  durum_kodu = 'K' ,kapanis_tarihi =  pkg_muhasebe.banka_tarihi_bul
	  where hesap_no in(   ln_faiz_tahakkuk_hesap_no ,ln_vergi_tahakkuk_hesap_no);
	 end if;

	   IF LS_Durum_kodu = 'K' THEN
	   	 BEGIN
	 	  UPDATE CBS_HESAP_KREDI_TAKSIT
		  SET durum_kodu = 'O',
		  	  ODEME_TARIHI =Pkg_Muhasebe.BANKA_TARIHI_BUL
		  WHERE hesap_no = ln_hesap_no AND
		  		DURUM_KODU = 'A';
		   EXCEPTION WHEN OTHERS THEN NULL;
		  END;
	    END IF;
  End;

 Procedure Muhasebelesme(pn_islem_no number)
 is
    varchar_list	           pkg_muhasebe.varchar_array;
    number_list				   pkg_muhasebe.number_array;
    date_list				   pkg_muhasebe.date_array;
    boolean_list			   pkg_muhasebe.boolean_array;
	ln_fis_no				   cbs_fis.numara%type ;
	ls_islem_kod               cbs_islem.islem_kod%type :='1309';
	ls_banka_aciklama          varchar2(2000);
	ls_fis_aciklama			   varchar2(2000);
	ls_aciklama                varchar2(2000);
	ls_musteri_aciklama        varchar2(2000);
	ln_rezervasyon_no          number;
	ln_kur  				   number;
	ln_fark_kur 			   number;
	ln_musteri_kur   		   number;
	ln_maliyet_kur   		   number;
	ln_kkdf_Ara_tutar 		   number;
	ln_bsmv_ara_tutar		   number;
    ls_dk_grup_kod			   cbs_musteri.DK_GRUP_KOD%type;
	ls_modul_tur_kod		   cbs_hesap.modul_tur_kod%type;
	ls_urun_tur_kod			   cbs_hesap.urun_tur_kod%type;
	ls_urun_sinif_kod		   cbs_hesap.urun_sinif_kod%type;
	iliskili_faiz_dk_yok       exception;
	iliskili_faizrees_dk_yok   exception;
	iliskili_kom_dk_yok   	   exception;
	iliskili_komrees_dk_yok    exception;
    ln_gecyil_anapkurfark_gelir number;
	ln_gecyil_anapkurfark_zarar number;
    ln_anapara_ekrankurlu		number;
	ls_endeks_doviz_kodu		varchar2(3);
	LN_fa_toplam_bsmv			NUMBER;
	LN_fa_toplam_kkdf			NUMBER;
	ls_kkdf_alinsin				varchar2(1);
	ls_bsmv_alinsin				varchar2(1);
    ln_anapara_tahsilat 			number;
    ln_faiz_orani			   number;
	ln_komisyon_orani		   number;
    ln_tahsedil_birikmis_faiz_tut  number := 0;
	ln_tahsedil_birikmis_komis_tut number:= 0;
    ln_ara_deger  number := 0;
	ln_hesap_no   number:= 0;
	ln_bakiye	  number := 0;
	ln_fark_aciliskur	 number := 0;
    ls_geriodeme_kapama_secimi				 cbs_hesap_kredi_islem.geriodeme_kapama_secimi%type;
	cursor islem_cursor (pn_islemno cbs_islem.numara%type) is
		   	select aciklama,
				   nvl(FAIZ_TAHAKKUK_HESAP_NO,0) ,
				   pkg_hesap.HESAPTANSUBEAL(FAIZ_TAHAKKUK_HESAP_NO),
				   nvl(VERGI_tahakkuk_HESAP_NO,0),
				   pkg_hesap.HESAPTANSUBEAL(VERGI_tahakkuk_HESAP_NO),
				   pkg_hesap.HESAPTANDOVIZKODUAL(iliskili_hesap_no),
				   iliskili_hesap_no,
				   pkg_hesap.HESAPTANSUBEAL(iliskili_hesap_no),
				   pkg_tx.Amir_BolumKodu_Al( tx_no),
				   doviz_kodu,
				   hesap_no,
				   pkg_hesap.HESAPTANSUBEAL(hesap_no),
				   to_char(hesap_no),
				   acilis_kuru,
				   kur,
				   son_islem_kuru,
				   pkg_kur.yuvarla(pkg_genel.lc_al,NVL(anapara_tahsilat_tutar * acilis_kuru,0)),
				   abs(NVL(GECENYIL_ANAPARAKURFARK_GELIR,0)),
				   abs(NVL(GECENYIL_ANAPARAKURFARK_ZARAR,0)),
				   abs(  pkg_kur.yuvarla(pkg_genel.lc_al,NVL(anapara_tahsilat_tutar * kur,0) )),
				   endeks_doviz_kodu,
				   abs(NVL(TAHSILEDILECEK_TAHAKKUK_FAIZ,0)),
				   abs(NVL( TAHSILEDILECEK_TAHAKKUK_VERGI,0)),
				   abs(NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0)),
				   abs(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0)),
				   abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL,(ABS( ABS((((NVL(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0)	+ NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0)) / NVL(ACILIS_KURU,0) )* KUR) ) -  ABS( NVL(TAHSEDIL_GECENYIL_FAIZ_TUTARI,0)))))),
 				   abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL,(ABS( ABS((((NVL(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0)	+ NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0)) / NVL(ACILIS_KURU,0))* KUR )) -  ABS(NVL(TAHSEDIL_GECENYIL_KOMIS_TUTARI,0)))))),
				   abs(nvl(GECENYIL_FAIZKURFARK_GELIR,0)),
				   abs(nvl(GECENYIL_FAIZKURFARK_ZARAR,0)),
				   abs(nvl(GECENYIL_KOMISKURFARK_GELIR,0)),
				   abs(nvl( GECENYIL_KOMISKURFARK_ZARAR,0)),
				   pkg_musteri.sf_musteri_dk_grup_kod_al(musteri_no),
		 		   modul_tur_kod,
				   urun_tur_kod,
				   urun_sinif_kod,
			       nvl(valor_tarihi,pkg_muhasebe.banka_tarihi_bul),
				   KKDF_ALINSIN,
				   BSMV_ALINSIN ,
				   abs(nvl(anapara_tahsilat_tutar,0)),
				   faiz_orani,
		   		   komisyon_orani,
				   abs(nvl(TAHSEDIL_BIRIKMIS_FAIZ_TUTARI,0)),
				   abs(nvl(TAHSEDIL_BIRIKMIS_KOMIS_TUTARI,0)),
				   pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,anapara_tahsilat_tutar,1,null,null,'O','A'),
				   pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'O','A'),
			   	   abs(nvl(endeks_doviz_tutari,0)),
			   	   geriodeme_kapama_secimi,
				   abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, (GECENYIL_SCH_FAIZI / acilis_kuru )*(pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A')))),--		number_list(pn_1309_gecenyilbdak_sch_tl),
				   abs(PKG_KUR.YUVARLA(PKG_GENEL.LC_AL, (BIRIKMIS_SCH_FAIZI / acilis_kuru )*(pkg_kur.doviz_doviz_karsilik(endeks_doviz_kodu,pkg_genel.LC_AL,null,1,1,null,null,'N','A'))))--		number_list(pn_1309_birikmis_sch_acilis_tl),
			from cbs_hesap_kredi_islem
			where tx_no=pn_islemno;

  Begin
   varchar_list(pn_1309_iliskili_faizdk) :=0;
   varchar_list(pn_1309_iliskili_komdk) :=0;
   varchar_list(pn_1309_iliskili_faizreesdk) :=0;
   varchar_list(pn_1309_iliskili_komreesdk) :=0;

    number_list(pn_1309_kur) := 0;
	number_list(pn_1309_anapara_tahsil_toplam) := 0;
	number_list(pn_1309_anapara_tahsil_sonisl) := 0;
	number_list(pn_1309_alis_kur) := 0;
	number_list(pn_1309_son_islem_kur) := 0;
	number_list(pn_1309_gecyil_kurfark) := 0;
	number_list(pn_1309_anapara_fark) := 0;
	number_list(pn_1309_kkdf_tutar) := 0;
	number_list(pn_1309_bsmv_tutar) := 0;
	number_list(pn_1309_anapara_tahsil_ekrkur) := 0;
	number_list(pn_1309_anapara_fark_2) := 0;
	number_list(pn_1309_anapara_fark_3) := 0;
	number_list(pn_1309_toplam_tahsiledil) := 0;
	number_list(pn_1309_tahsil_faizkom) := 0;
	number_list(pn_1309_tahsil_fonvergi) := 0;
	number_list(pn_1309_tahsil_faizfark) := 0;
	number_list(pn_1309_tahsil_komfark) := 0;
	number_list(pn_1309_tahsil_gecyilfaiz) := 0;
	number_list(pn_1309_tahsil_gecyilkom) := 0;
	number_list(pn_1309_fa_toplam_bsmv) := 0;
	number_list(pn_1309_fa_toplam_kkdf) := 0;
	number_list(pn_1309_fa_gecyil_faizgelir) := 0;
	number_list(pn_1309_fa_gecyil_faizzarar) := 0;
	number_list(pn_1309_fa_gecyil_komgelir) := 0;
	number_list(pn_1309_fa_gecyil_komzarar) := 0;
	number_list(pn_1309_anapara_bdak_tutar) := 0;
	number_list(pn_1309_anapara_tutar) := 0;
/*290504*/
   number_list(pn_1309_gecenyilbdak_sch_tl):=0;
   number_list(pn_1309_birikmis_sch_acilis_tl) :=0;

/* islem bilgisi detaylari alinir */

   ls_aciklama :=   pkg_genel.ISLEM_ADI_AL(1309) ;

   if islem_cursor%isopen then
          close islem_cursor;
    end if;

  	   open islem_cursor(pn_islem_no);
		fetch islem_cursor into
		  ls_fis_aciklama,
		   varchar_list(pn_1309_faiz_hesap_no),
		   varchar_list(pn_1309_faiz_hesap_sube),
		   varchar_list(pn_1309_fon_hesap_no),
		   varchar_list(pn_1309_fon_hesap_sube),
		   varchar_list(pn_1309_iliskili_hesap_doviz),
		   varchar_list(pn_1309_iliskili_hesap_no),
		   varchar_list(pn_1309_iliskili_hesap_sube),
		   varchar_list(pn_1309_islem_sube),
		   varchar_list(pn_1309_kredi_doviz),
		   varchar_list(pn_1309_kredi_hesap_no),
		   varchar_list(pn_1309_kredi_hesap_sube),
		   varchar_list(pn_1309_referans),
		   number_list(pn_1309_alis_kur),
		   number_list(pn_1309_kur),
		   number_list(pn_1309_son_islem_kur),
  		   number_list(pn_1309_anapara_tahsil_sonisl),
		   ln_gecyil_anapkurfark_gelir,
		   ln_gecyil_anapkurfark_zarar,
		   ln_anapara_ekrankurlu,
		   ls_endeks_doviz_kodu,
   		   number_list(pn_1309_tahsil_faizkom),
		   number_list(pn_1309_tahsil_fonvergi),
		   number_list(pn_1309_tahsil_gecyilfaiz),
		   number_list(pn_1309_tahsil_gecyilkom),
   		   number_list(pn_1309_tahsil_faizfark),
     	   number_list(pn_1309_tahsil_komfark),
		   number_list(pn_1309_fa_gecyil_faizgelir),
		   number_list(pn_1309_fa_gecyil_faizzarar),
		   number_list(pn_1309_fa_gecyil_komgelir),
		   number_list(pn_1309_fa_gecyil_komzarar),
		   ls_dk_grup_kod,
		   ls_modul_tur_kod,
		   ls_urun_tur_kod,
		   ls_urun_sinif_kod,
		   date_list(pn_1309_valor_tarihi),
		   ls_kkdf_alinsin,
		   ls_bsmv_alinsin,
		   ln_anapara_tahsilat,
		   ln_faiz_orani,
		   ln_komisyon_orani,
  		   ln_tahsedil_birikmis_faiz_tut,
		   ln_tahsedil_birikmis_komis_tut,
   		   number_list(pn_1309_anapara_bdak_tutar),
   		   number_list(pn_1309_bdak_kur),
  	       ln_bakiye,
		   ls_geriodeme_kapama_secimi,
   		   number_list(pn_1309_gecenyilbdak_sch_tl),
		   number_list(pn_1309_birikmis_sch_acilis_tl);

	ln_hesap_no := varchar_list(pn_1309_kredi_hesap_no);
	varchar_list(pn_1309_endeks_doviz) := ls_endeks_doviz_kodu;
	number_list(pn_1309_anapara_tutar) := ln_anapara_tahsilat;

	if islem_cursor%isopen then
          close islem_cursor;
    end if;

/*** Liste Deger Atama K?sm? **/
if     nvl(ln_tahsedil_birikmis_faiz_tut,0) <> 0 then

 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 2,
 					   null,null, null,varchar_list(pn_1309_iliskili_faizdk));
	  if 	varchar_list(pn_1309_iliskili_faizdk) is null then
	  		raise iliskili_faiz_dk_yok;
	  end if;
 end if;
/*faiz reeskont dk */
 if  nvl(number_list(pn_1309_tahsil_gecyilfaiz),0) <> 0 then
	 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
	 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 4,
	 					   null,null, null,varchar_list(pn_1309_iliskili_faizreesdk));
		  if 	varchar_list(pn_1309_iliskili_faizreesdk) is null and  (nvl( number_list(pn_1309_tahsil_gecyilfaiz),0) <> 0)  then
		  		raise iliskili_faizrees_dk_yok;
		  end if;
end if;
if   nvl(ln_tahsedil_birikmis_komis_tut,0 ) <> 0 then
/*komisyon dk */
 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 5,
 					   null,null, null,varchar_list(pn_1309_iliskili_komdk));

	  if 	varchar_list(pn_1309_iliskili_komdk) is null  and  nvl( number_list(pn_1309_tahsil_gecyilkom),0) <> 0  then
	  		raise iliskili_kom_dk_yok;
	  end if;
 end if;
  if nvl(number_list(pn_1309_tahsil_gecyilkom),0) <> 0 then
/*komisyon reeskont dk */
 PKG_MUHASEBE.DK_BUL ( ls_dk_grup_kod,lS_MODUL_TUR_KOD,
 					   lS_URUN_TUR_KOD, lS_URUN_SINIF_KOD, 6,
 					   null,null, null,varchar_list(pn_1309_iliskili_komreesdk));

	  if 	varchar_list(pn_1309_iliskili_komreesdk) is null then
	  		raise iliskili_komrees_dk_yok;
	  end if;
end if;
/**** varchar list ****/
   ls_aciklama :=   pkg_genel.ISLEM_ADI_AL(1309) ;

   pkg_parametre.deger('1309_BANKA_ACIKLAMA',ls_banka_aciklama);
   pkg_parametre.deger('1309_MUSTERI_ACIKLAMA',ls_musteri_aciklama);

   varchar_list(pn_1309_fis_aciklama) := ls_aciklama;
   varchar_list(pn_1309_banka_aciklama)  := nvl(ls_fis_aciklama,ls_aciklama);
   varchar_list(pn_1309_musteri_aciklama):= nvl(ls_fis_aciklama,ls_aciklama);

/**** boolean list ****/
			boolean_list(pn_1309_ekrankur_buyukse) :=false;
			boolean_list(pn_1309_ekrankur_kucuk) :=false;
			boolean_list(pn_1309_faiz_gelir) :=false;
			boolean_list(pn_1309_faiz_zarari) :=false;
			boolean_list(pn_1309_gecenyil_gelir) :=false;
			boolean_list(pn_1309_gecenyil_zarar) :=false;
			boolean_list(pn_1309_komis_gelir) :=false;
			boolean_list(pn_1309_komis_zarar) :=false;
			boolean_list(pn_1309_anapara_var) :=false;

/* ANAPARA */
	 number_list(pn_1309_anapara_tahsil_ekrkur):=	 NVL(ln_anapara_ekrankurlu,0);

	if nvl( ln_anapara_tahsilat,0) <> 0 then
	   	boolean_list(pn_1309_anapara_var) :=true;
	end if;

 /* boolean list */
/*ekran kuru buyukse acilis kurundan */
     if   number_list(pn_1309_kur) > number_list(pn_1309_alis_kur) then
	  		boolean_list(pn_1309_ekrankur_buyukse) :=true;
	 else
	 		boolean_list(pn_1309_ekrankur_kucuk) :=true;
	 end if;
	 /* 090204 sbalci kkdf hesaplan?rken ln_ara_deger yerine ln_bakiye yap?ld?. */

		 if  nvl(number_list(pn_1309_kur),0) > nvl(number_list(pn_1309_son_islem_kur),0) then
			 ln_fark_kur := abs( nvl( number_list(pn_1309_kur),0) - nvl( number_list(pn_1309_son_islem_kur),0));
		  	    if	nvl(ln_BAkiye,0 ) <> 0 	and boolean_list(pn_1309_anapara_var) = true and nvl(ln_fark_kur,0) <> 0 then
				    number_list(pn_1309_kkdf_tutar):= NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',pkg_genel.lc_al,   varchar_list(pn_1309_kredi_hesap_no), 	ln_bakiye * ln_fark_kur,1 , 'E', ls_kkdf_alinsin, ls_bsmv_alinsin),0);
			     else
			 	  number_list(pn_1309_kkdf_tutar):= 0;
			    end if;

	     else
			 	  number_list(pn_1309_kkdf_tutar):= 0;
        end if;

 		   if  nvl(number_list(pn_1309_kur),0) > nvl(number_list(pn_1309_alis_kur),0) then
 			   ln_fark_aciliskur := abs( nvl( number_list(pn_1309_kur),0) - nvl( number_list(pn_1309_alis_kur),0));
			   if  ln_fark_aciliskur >0 then
			       number_list(pn_1309_bsmv_tutar) :=NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',pkg_genel.lc_al,   varchar_list(pn_1309_kredi_hesap_no), ln_anapara_tahsilat* ln_fark_aciliskur,1 , 'E', ls_kkdf_alinsin, ls_bsmv_alinsin),0);
				else
  				   number_list(pn_1309_bsmv_tutar) := 0;
				end if;
			else
				  number_list(pn_1309_bsmv_tutar) := 0;
			end if;

	 number_list(pn_1309_anapara_tahsil_toplam) := abs(NVL(number_list(pn_1309_anapara_tahsil_ekrkur),0)) +  abs(NVL(number_list(pn_1309_kkdf_tutar),0)) +	 abs(NVL(number_list(pn_1309_bsmv_tutar),0));
	 number_list(pn_1309_anapara_fark) := abs( number_list(pn_1309_anapara_tahsil_toplam) - (   abs(NVL(number_list(pn_1309_anapara_tahsil_sonisl),0)) +  abs(NVL(number_list(pn_1309_kkdf_tutar),0)) +	abs( NVL(number_list(pn_1309_bsmv_tutar),0))));

/*FA?Z */

			LN_fa_toplam_bsmv := NVL(number_list(pn_1309_tahsil_gecyilfaiz),0) + NVL(number_list(pn_1309_tahsil_gecyilkom),0) +   NVL( number_list(pn_1309_tahsil_faizfark),0) + NVL(number_list(pn_1309_tahsil_komfark),0);
			if nvl(LN_fa_toplam_bsmv,0) <> 0 then
				number_list(pn_1309_fa_toplam_bsmv) := NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'BSMV',pkg_genel.lc_al,   varchar_list(pn_1309_kredi_hesap_no),LN_fa_toplam_bsmv, 1 , 'E', ls_kkdf_alinsin, ls_bsmv_alinsin),0);
			else
				number_list(pn_1309_fa_toplam_bsmv) := 0;
			end if;

			   LN_fa_toplam_kkdf := NVL(number_list(pn_1309_tahsil_gecyilfaiz),0) +  NVL( number_list(pn_1309_tahsil_faizfark),0) ;
			if nvl(LN_fa_toplam_kkdf,0) <> 0 then
				number_list(pn_1309_fa_toplam_kkdf) := NVL(PKG_KREDI.SF_KKDFBSMV_HESAPLA ( 'KKDF',pkg_genel.lc_al,   varchar_list(pn_1309_kredi_hesap_no),LN_fa_toplam_kkdf, 1 , 'E', ls_kkdf_alinsin, ls_bsmv_alinsin),0);
			else
				number_list(pn_1309_fa_toplam_kkdf) := 0;
			end if;
			number_list(pn_1309_toplam_tahsiledil) :=   	nvl( number_list(pn_1309_tahsil_faizkom),0) + nvl( number_list(pn_1309_tahsil_fonvergi),0) + NVL(number_list(pn_1309_tahsil_gecyilfaiz),0) + NVL(number_list(pn_1309_tahsil_gecyilkom),0) +   NVL( number_list(pn_1309_tahsil_faizfark),0) + NVL(number_list(pn_1309_tahsil_komfark),0) + nvl(number_list(pn_1309_fa_toplam_kkdf),0) + 	nvl(number_list(pn_1309_fa_toplam_bsmv),0) ;

 /* boolean list */

	 if	 nvl( number_list(pn_1309_tahsil_gecyilfaiz),0 ) > 0 then
 	 	if  nvl(number_list(pn_1309_fa_gecyil_faizgelir),0) > 0 then
		 	 boolean_list(pn_1309_faiz_gelir) :=true;
		elsif nvl(number_list(pn_1309_fa_gecyil_faizzarar),0) > 0 then
		  	 boolean_list(pn_1309_faiz_zarari) :=true;
		end if;
	end if;

	 if	 nvl( number_list(pn_1309_tahsil_gecyilkom),0 ) > 0 then
 	 	if  nvl(number_list(pn_1309_fa_gecyil_komgelir),0) > 0 then
		 	 boolean_list(pn_1309_komis_gelir) :=true;
		elsif nvl(number_list(pn_1309_fa_gecyil_komzarar),0) > 0 then
			  	 boolean_list(pn_1309_komis_zarar) :=true;
		end if;
	end if;

/* 290504 subeler cari muhasebesi */
 if (ls_geriodeme_kapama_secimi != 'KAPAMA' )  and
   (   ln_tahsedil_birikmis_faiz_tut +  ln_tahsedil_birikmis_komis_tut = 0 ) then
   		   number_list(pn_1309_gecenyilbdak_sch_tl)  := 0;
		   number_list(pn_1309_birikmis_sch_acilis_tl):=0;
 end if;
/* kredi hesap acilis muhasebesi calistirilir. */
    ln_fis_no:=pkg_muhasebe.fis_kes(ls_islem_kod,
							null,
							pn_islem_no,
							varchar_list ,
							number_list  ,
							date_list    ,
							boolean_list ,
							null,
							false,
							0,
							null);

	pkg_muhasebe.MUHASEBELESTIR(ln_fis_no);
	sp_muhasebesonrasi_guncelle(pn_islem_no);
    pkg_teminat.sp_teminat_fiskessonrasi(pn_islem_no,ln_fis_no,ls_geriodeme_kapama_secimi);

  Exception
   When iliskili_faiz_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '700' || pkg_hata.getdelimiter || varchar_list(pn_1309_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   When iliskili_faizrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '701' || pkg_hata.getdelimiter || varchar_list(pn_1309_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   When iliskili_kom_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '702' || pkg_hata.getdelimiter || varchar_list(pn_1309_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);
   When iliskili_komrees_dk_yok then
    raise_application_error(-20100,pkg_hata.getucpointer || '703' || pkg_hata.getdelimiter || varchar_list(pn_1309_iliskili_hesap_no) || pkg_hata.getdelimiter ||ls_dk_grup_kod || pkg_hata.getdelimiter || ls_modul_tur_kod  || pkg_hata.getdelimiter ||  ls_urun_tur_kod  || pkg_hata.getdelimiter || ls_urun_sinif_kod || pkg_hata.getdelimiter || pkg_hata.getucpointer);

   When Others Then
    Raise_application_error(-20100,pkg_hata.getUCPOINTER || '594' || pkg_hata.getDelimiter || to_char(SQLERRM) || pkg_hata.getDelimiter || pkg_hata.getUCPOINTER);
 End;

 Procedure Iptal_Muhasebelestir_Sonrasi(pn_islem_no number ) is
 Begin
  null;
 End;

 Procedure Guncelleme_Kontrolu(pn_islem_no number,ps_block	varchar2,ps_rowid   varchar2,
  							   ps_column varchar2,pd_column varchar2,ps_oldvalue in out varchar2)
 is
 Begin
    pkg_teminat.sp_TeminatGuncelleme_Kontrolu (pn_islem_no ,ps_block,ps_rowid,ps_column,pd_column ,ps_oldvalue );
 End;

 procedure sp_kontrol_sonrasi_rezervasyon(pn_islem_no number ) is
 ln_doviz_tutari number;
	ln_bakiye number;

	CURSOR islem_cursor IS
	   	 	SELECT b.tutar,a.rezervasyon_no from cbs_hesap_kredi_islem a,CBS_ISLEM b
			where numara=pn_islem_no and
				  a.tx_no = b.numara;

	row_islem islem_cursor%ROWTYPE;
   Begin

    OPEN islem_cursor;
    FETCH islem_cursor INTO row_islem;
    CLOSE islem_cursor;

	if row_islem.REZERVASYON_NO is not null then

	   ln_bakiye:=PKG_KUR_Rezervasyon.Rezervasyon_Bakiye( row_islem.REZERVASYON_NO,pn_islem_no);

	   IF row_islem.TUTAR >ln_bakiye THEN --Bakiye Yetersiz..
	      RAISE_APPLICATION_ERROR(-20100,Pkg_Hata.getUCPOINTER||'2038'|| Pkg_Hata.getUCPOINTER);
	   else
	      Pkg_Kur_Rezervasyon.Rezervasyon_Kullanim_Kaydet(row_islem.REZERVASYON_NO,
	 		    										  pn_islem_no,
	     												  row_islem.TUTAR);
	   END IF;

	end if;

 Exception when others then null;
 End;


 BEGIN
    pn_1309_valor_tarihi :=pkg_muhasebe.parametre_index_bul('1309_VALOR_TARIHI');
	pn_1309_fon_hesap_no :=pkg_muhasebe.parametre_index_bul('1309_FON_HESAP_NO');
	pn_1309_kredi_doviz :=pkg_muhasebe.parametre_index_bul('1309_KREDI_DOVIZ');
	pn_1309_banka_aciklama :=pkg_muhasebe.parametre_index_bul('1309_BANKA_ACIKLAMA');
	pn_1309_iliskili_hesap_sube :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_HESAP_SUBE');
	pn_1309_iliskili_hesap_no :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_HESAP_NO');
	pn_1309_faiz_hesap_sube :=pkg_muhasebe.parametre_index_bul('1309_FAIZ_HESAP_SUBE');
	pn_1309_faiz_hesap_no :=pkg_muhasebe.parametre_index_bul('1309_FAIZ_HESAP_NO');
	pn_1309_musteri_aciklama :=pkg_muhasebe.parametre_index_bul('1309_MUSTERI_ACIKLAMA');
	pn_1309_referans :=pkg_muhasebe.parametre_index_bul('1309_REFERANS');
	pn_1309_fis_aciklama :=pkg_muhasebe.parametre_index_bul('1309_FIS_ACIKLAMA');
	pn_1309_islem_sube :=pkg_muhasebe.parametre_index_bul('1309_ISLEM_SUBE');
	pn_1309_kur :=pkg_muhasebe.parametre_index_bul('1309_KUR');
	pn_1309_fon_hesap_sube :=pkg_muhasebe.parametre_index_bul('1309_FON_HESAP_SUBE');
	pn_1309_anapara_tahsil_toplam :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_TAHSIL_TOPLAM');
	pn_1309_anapara_tahsil_sonisl :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_TAHSIL_SONISLEM');
	pn_1309_alis_kur :=pkg_muhasebe.parametre_index_bul('1309_ALIS_KUR');
	pn_1309_son_islem_kur :=pkg_muhasebe.parametre_index_bul('1309_SON_ISLEM_KUR');
	pn_1309_gecyil_kurfark :=pkg_muhasebe.parametre_index_bul('1309_GECYIL_KURFARK');
	pn_1309_anapara_fark :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_FARK');
	pn_1309_kkdf_tutar :=pkg_muhasebe.parametre_index_bul('1309_KKDF_TUTAR');
	pn_1309_bsmv_tutar :=pkg_muhasebe.parametre_index_bul('1309_BSMV_TUTAR');
	pn_1309_ekrankur_buyukse :=pkg_muhasebe.parametre_index_bul('1309_EKRANKUR_BUYUKSE');
	pn_1309_gecenyil_gelir :=pkg_muhasebe.parametre_index_bul('1309_GECENYIL_GELIR');
	pn_1309_ekrankur_kucuk :=pkg_muhasebe.parametre_index_bul('1309_EKRANKUR_KUCUK');
	pn_1309_gecenyil_zarar :=pkg_muhasebe.parametre_index_bul('1309_GECENYIL_ZARAR');
	pn_1309_iliskili_hesap_doviz :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_HESAP_DOVIZ');
	pn_1309_kredi_hesap_no :=pkg_muhasebe.parametre_index_bul('1309_KREDI_HESAP_NO');
	pn_1309_kredi_hesap_sube :=pkg_muhasebe.parametre_index_bul('1309_KREDI_HESAP_SUBE');
	pn_1309_anapara_tahsil_ekrkur :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_TAHSIL_EKRKURLU');
	pn_1309_anapara_fark_2 :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_FARK_2');
	pn_1309_anapara_fark_3 :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_FARK_3');
	pn_1309_toplam_tahsiledil :=pkg_muhasebe.parametre_index_bul('1309_TOPLAM_TAHSILEDIL');
	pn_1309_tahsil_faizkom :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_FAIZKOM');
	pn_1309_tahsil_fonvergi :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_FONVERGI');
	pn_1309_tahsil_faizfark :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_FAIZFARK');
	pn_1309_tahsil_komfark :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_KOMFARK');
	pn_1309_iliskili_faizdk :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_FAIZDK');
	pn_1309_iliskili_komdk :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_KOMDK');
	pn_1309_iliskili_faizreesdk :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_FAIZREESDK');
	pn_1309_tahsil_gecyilfaiz :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_GECYILFAIZ');
	pn_1309_tahsil_gecyilkom :=pkg_muhasebe.parametre_index_bul('1309_TAHSIL_GECYILKOM');
	pn_1309_fa_toplam_bsmv :=pkg_muhasebe.parametre_index_bul('1309_FA_TOPLAM_BSMV');
	pn_1309_fa_toplam_kkdf :=pkg_muhasebe.parametre_index_bul('1309_FA_TOPLAM_KKDF');
	pn_1309_fa_gecyil_faizgelir :=pkg_muhasebe.parametre_index_bul('1309_FA_GECYIL_FAIZGELIR');
	pn_1309_fa_gecyil_faizzarar :=pkg_muhasebe.parametre_index_bul('1309_FA_GECYIL_FAIZZARAR');
	pn_1309_fa_gecyil_komgelir :=pkg_muhasebe.parametre_index_bul('1309_FA_GECYIL_KOMGELIR');
	pn_1309_fa_gecyil_komzarar :=pkg_muhasebe.parametre_index_bul('1309_FA_GECYIL_KOMZARAR');
	pn_1309_iliskili_komreesdk :=pkg_muhasebe.parametre_index_bul('1309_ILISKILI_KOMREESDK');
	pn_1309_faiz_gelir :=pkg_muhasebe.parametre_index_bul('1309_FAIZ_GELIR');
	pn_1309_faiz_zarari :=pkg_muhasebe.parametre_index_bul('1309_FAIZ_ZARARI');
	pn_1309_komis_gelir :=pkg_muhasebe.parametre_index_bul('1309_KOMIS_GELIR');
	pn_1309_komis_zarar :=pkg_muhasebe.parametre_index_bul('1309_KOMIS_ZARAR');
	pn_1309_anapara_var :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_VAR');
	pn_1309_anapara_bdak_tutar :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_BDAK_TUTAR');
	pn_1309_anapara_tutar :=pkg_muhasebe.parametre_index_bul('1309_ANAPARA_TUTAR');
	pn_1309_bdak_kur :=pkg_muhasebe.parametre_index_bul('1309_BDAK_KUR');
	pn_1309_endeks_doviz :=pkg_muhasebe.parametre_index_bul('1309_ENDEKS_DOVIZ');
/* 290504*/
	pn_1309_birikmis_sch_acilis_tl :=pkg_muhasebe.parametre_index_bul('1309_birikmis_sch_acilis_tl');
	pn_1309_gecenyilbdak_sch_tl :=pkg_muhasebe.parametre_index_bul('1309_GECENYILBDAK_SCH_TL');

 END;
/

